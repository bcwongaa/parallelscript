package toolchain_test

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/toolchain"
	"gotest.tools/v3/assert"
)

// TestReview8ProbesUnderSanitizers builds each C file named in REVIEW8_C (colon-separated)
// with AddressSanitizer and UndefinedBehaviorSanitizer and runs it; the output goes to
// the file's name with .san.out. Review-only overlay, not part of the repository.
func TestReview8ProbesUnderSanitizers(t *testing.T) {
	list := os.Getenv("REVIEW8_C")
	if list == "" {
		t.Skip("REVIEW8_C unset")
	}
	for _, source := range strings.Split(list, ":") {
		t.Run(filepath.Base(source), func(t *testing.T) {
			exe := buildC(t, toolchain.Sanitize, source)
			result := runWithEnv(t, exe, []string{"TZ=America/New_York", "ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0"}, "")
			out := "exit " + string(rune('0'+result.exitCode)) + "\n" + result.stdout + "--- stderr\n" + result.stderr
			assert.NilError(t, os.WriteFile(strings.TrimSuffix(source, ".c")+".san.out", []byte(out), 0o644))
			assert.Equal(t, result.exitCode, 0, "stderr:\n%s", result.stderr)
		})
	}
}
