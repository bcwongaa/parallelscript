// Non-string, non-number keys through `any` (JS converts them with ToPropertyKey): booleans,
// null, undefined, an array and an object whose string form is a method name.
const arr: any = [1, 2];
const map: any = new Map();
const obj: any = { true: 1, null: 2, push: 3 };
const keys: any[] = [true, false, null, undefined, ["push"], { toString() { return "push"; } }, ["0"], [1]];
for (const k of keys) {
  const r: string[] = [];
  for (const v of [arr, map, obj]) { try { r.push(String(k in v)); } catch (e) { r.push((e as Error).name); } }
  console.log(JSON.stringify(k) ?? String(k), r.join(" "));
}
