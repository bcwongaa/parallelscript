// The generator path's 16-byte buffer: keys of 14–17 bytes, NULs at each position of
// "next", an async generator, a very long key, and each method name.
function* gen(): Generator<number> { yield 1; }
async function* agen(): AsyncGenerator<number> { yield 1; }
const g: any = gen();
const a: any = agen();
const keys: string[] = ["next", "return", "throw", "nex", "nextt", "x".repeat(14), "x".repeat(15), "x".repeat(16), "x".repeat(17),
  "next" + "\0".repeat(11), "next" + "\0".repeat(12), "\0next", "n\0ext", "ne\0xt", "nex\0t", "next\0", "", "x".repeat(100000), "ñext"];
for (const [name, v] of [["gen", g], ["agen", a]] as [string, any][]) {
  console.log(name, keys.map((k) => (k.length > 20 ? "long" + k.length : JSON.stringify(k)) + "=" + (k in v ? 1 : 0)).join(" "));
}
