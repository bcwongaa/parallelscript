// R7-F1's in-place name comparison: keys with embedded NULs, empty and long keys, Unicode,
// numeric strings and numbers, on every library kind through `any`, against Node.
function* gen(): Generator<number> { yield 1; }
const long = "push".padEnd(5000, "x");
const kinds: [string, any][] = [
  ["array", [1, 2]], ["map", new Map([["k", 1]])], ["set", new Set([1])], ["fn", (x: number) => x],
  ["gen", gen()], ["typed", new Uint8Array(2)], ["regexp", /a/g], ["date", new Date(0)],
  ["promise", Promise.resolve(1)], ["object", { a: 1, "": 2 }], ["record", { z: 1 } as Record<string, number>],
];
const keys: any[] = ["push\0", "push\0x", "\0push", "next\0", "next\0x", "size\0", "get\0", "exec\0", "getTime\0", "then\0",
  "", long, "pușh", "0", "01", "-0", "1e0", "1.5", 0, -1, 1.5, NaN, Infinity, -0, "length", "next", "a"];
const show = (k: any): string => typeof k === "string" ? JSON.stringify(k.length > 20 ? k.slice(0, 8) + "…" + k.length : k) : String(k);
for (const [name, v] of kinds) {
  const answers: string[] = [];
  for (const k of keys) {
    try { answers.push(show(k) + "=" + (k in v ? 1 : 0)); } catch (e) { answers.push(show(k) + "=" + (e as Error).name); }
  }
  console.log(name, answers.join(" "));
}
