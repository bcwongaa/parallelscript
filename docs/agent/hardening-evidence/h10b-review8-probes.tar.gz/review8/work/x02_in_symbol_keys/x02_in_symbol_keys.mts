// Symbol keys with `in` through `any` on library kinds (snap9 converted every key to text first).
const sym: any = Symbol("k");
const kinds: [string, any][] = [["array", [1]], ["map", new Map()], ["set", new Set()], ["fn", (x: number) => x], ["object", { a: 1 }], ["typed", new Uint8Array(1)]];
for (const [name, v] of kinds) {
  try { console.log(name, sym in v); } catch (e) { console.log(name, (e as Error).name, (e as Error).message); }
}
