// Command lvl lowers each file given with each of lower.Fallbacks alone (driver.EmitCWith,
// no fallback) and prints, per level, OK with the lines of C (and, with CLANG=1, whether
// clang -fsyntax-only accepts it, with the runtime's include dirs, and how long that took),
// or ERR with the number of diagnostics and the first three, formatted relative to the
// file's directory. It then prints which level `pts emit-c` ends at (the first that lowers)
// and, with CLANG=1, which `pts build` ends at (the first that lowers and clang accepts;
// a link failure isn't simulated). DUMP=dir writes each level's C to dir/<base>.<level>.c.
// Run with PTS_HOME=<tree>.
package main

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/microsoft/typescript-go/pts/diagnostic"
	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

var names = map[lower.Specialization]string{
	lower.AllInstances:      "All",
	lower.ValueInstances:    "Value",
	lower.DeclaredInstances: "Declared",
}

var clangError = regexp.MustCompile(`(?m)error: (.*)$`)

func describe(err error, dir string) string {
	var compile *diagnostic.Error
	var internal *diagnostic.InternalError
	switch {
	case errors.As(err, &compile):
		parts := []string{}
		for i, d := range compile.Diagnostics {
			if i == 3 {
				break
			}
			parts = append(parts, d.Format(dir))
		}
		return fmt.Sprintf("%d diag: %s", len(compile.Diagnostics), strings.Join(parts, " | "))
	case errors.As(err, &internal):
		return "INTERNAL " + internal.Format(dir)
	}
	return "OTHER " + strings.SplitN(err.Error(), "\n", 2)[0]
}

func main() {
	ctx := context.Background()
	clang := os.Getenv("CLANG") == "1"
	dump := os.Getenv("DUMP")
	var tc *toolchain.Toolchain
	var rt *toolchain.Runtime
	if clang {
		var err error
		if tc, err = toolchain.New(); err == nil {
			rt, err = tc.Runtime(ctx, toolchain.Release)
		}
		if err != nil {
			fmt.Println("toolchain:", err)
			os.Exit(2)
		}
	}
	os.MkdirAll("/tmp/h09b5b/repro2/tmp", 0o755)
	tmp, _ := os.MkdirTemp("/tmp/h09b5b/repro2/tmp", "lvl-")
	defer os.RemoveAll(tmp)
	for _, file := range os.Args[1:] {
		dir := filepath.Dir(file)
		fmt.Println("==", filepath.Base(file))
		emitPick, buildPick := "none", "none"
		for _, s := range lower.Fallbacks {
			start := time.Now()
			code, err := driver.EmitCWith(ctx, file, s)
			took := time.Since(start)
			if err != nil {
				fmt.Printf("  %-8s ERR %s\n", names[s], describe(err, dir))
				continue
			}
			if dump != "" {
				os.WriteFile(filepath.Join(dump, strings.TrimSuffix(filepath.Base(file), ".pts")+"."+names[s]+".c"), []byte(code), 0o644)
			}
			status := ""
			if clang {
				c := filepath.Join(tmp, "main.c")
				os.WriteFile(c, []byte(code), 0o644)
				args := []string{"-fsyntax-only", "-std=c11", "-w", "-ferror-limit=3"}
				for _, include := range rt.IncludeDirs {
					args = append(args, "-I", include)
				}
				cstart := time.Now()
				out, cerr := exec.Command(tc.CC, append(args, c)...).CombinedOutput()
				ctook := time.Since(cstart)
				if cerr != nil {
					msg := "?"
					if m := clangError.FindStringSubmatch(string(out)); m != nil {
						msg = m[1]
					}
					status = fmt.Sprintf(" CLANG-REJECTS(%.2fs) %s", ctook.Seconds(), msg)
				} else {
					status = fmt.Sprintf(" clang-ok(%.2fs)", ctook.Seconds())
					if buildPick == "none" {
						buildPick = names[s]
					}
				}
			}
			if emitPick == "none" {
				emitPick = names[s]
			}
			fmt.Printf("  %-8s OK %d lines (lower %.2fs)%s\n", names[s], strings.Count(code, "\n"), took.Seconds(), status)
		}
		fmt.Printf("  emit-c=%s", emitPick)
		if clang {
			fmt.Printf(" build=%s", buildPick)
		}
		fmt.Println()
	}
}
