// Command scan lowers each file listed on stdin with lower.AllInstances alone
// (driver.EmitCWith); where that fails, with ValueInstances, then DeclaredInstances, and
// prints which level the driver's fallback ends at. Where AllInstances lowers, it checks the
// C with clang -fsyntax-only (as TestCompilerFailsCleanly does with PTS_SMOKE_CLANG=1): a
// rejection there is C that `pts emit-c` prints and `pts build` doesn't compile. One line per
// file: "<level>\t<file>\t<AllInstances' first error or clang's>". Run with PTS_HOME=<tree>.
package main

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

var clangError = regexp.MustCompile(`(?m)error: (.*)$`)

func firstLine(err error) string {
	return strings.ReplaceAll(strings.SplitN(err.Error(), "\n", 2)[0], "\t", " ")
}

func main() {
	ctx := context.Background()
	tc, err := toolchain.New()
	if err != nil {
		panic(err)
	}
	rt, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		panic(err)
	}
	dir, _ := os.MkdirTemp("/tmp/h09b5b/repro2/tmp", "scan-")
	defer os.RemoveAll(dir)
	in := bufio.NewScanner(os.Stdin)
	for in.Scan() {
		file := in.Text()
		done := make(chan string, 1)
		go func() {
			defer func() {
				if r := recover(); r != nil {
					done <- fmt.Sprintf("PANIC\t%s\t%v", file, r)
				}
			}()
			code, err := driver.EmitCWith(ctx, file, lower.AllInstances)
			if err == nil {
				c := filepath.Join(dir, "main.c")
				os.WriteFile(c, []byte(code), 0o644)
				args := []string{"-fsyntax-only", "-std=c11", "-w", "-ferror-limit=3"}
				for _, include := range rt.IncludeDirs {
					args = append(args, "-I", include)
				}
				out, cerr := exec.Command(tc.CC, append(args, c)...).CombinedOutput()
				if cerr != nil {
					first := clangError.FindStringSubmatch(string(out))
					msg := "?"
					if first != nil {
						msg = first[1]
					}
					done <- fmt.Sprintf("ALL-CLANG-REJECTS\t%s\t%s", file, msg)
					return
				}
				done <- fmt.Sprintf("ALL\t%s\t", file)
				return
			}
			allErr := firstLine(err)
			if _, err := driver.EmitCWith(ctx, file, lower.ValueInstances); err == nil {
				done <- fmt.Sprintf("VALUE\t%s\t%s", file, allErr)
				return
			}
			if _, err := driver.EmitCWith(ctx, file, lower.DeclaredInstances); err == nil {
				done <- fmt.Sprintf("DECLARED\t%s\t%s", file, allErr)
				return
			}
			done <- fmt.Sprintf("NONE\t%s\t%s", file, allErr)
		}()
		select {
		case line := <-done:
			fmt.Println(line)
		case <-time.After(90 * time.Second):
			fmt.Printf("HANG\t%s\t\n", file)
		}
	}
}
