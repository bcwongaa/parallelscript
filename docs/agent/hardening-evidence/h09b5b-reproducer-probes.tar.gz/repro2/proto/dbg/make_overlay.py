#!/usr/bin/env python3
"""Makes the debug overlay: lower.go whose report() prints, with PTS_DBG_REPORT set, the
specialization, the trial state and the diagnostic to stderr (PTS_DBG_REPORT=stack: also
the Go stack). A throwaway tracing aid, never applied to the worktree."""
import json
WT = '/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a'
src = WT + '/pts/lower/lower.go'
p = '/tmp/h09b5b/repro2/proto/dbg/lower.go'
s = open(src).read()
s = s.replace('import (\n\t"context"\n\t"fmt"\n', 'import (\n\t"context"\n\t"fmt"\n\t"os"\n\t"runtime/debug"\n', 1)
old = '''func (l *lowerer) report(d diagnostic.Diagnostic) {
	l.reports++'''
new = '''func (l *lowerer) report(d diagnostic.Diagnostic) {
	if os.Getenv("PTS_DBG_REPORT") != "" {
		inTrial, making, owns, foreign := l.trial != nil, 0, false, false
		if l.trial != nil {
			making, owns, foreign = l.trial.making, l.trial.owns(l.function), l.trial.foreign
		}
		fn := "<nil>"
		if l.function != nil {
			fn = l.function.Name
		}
		fmt.Fprintf(os.Stderr, "DBG-REPORT spec=%d trial=%v making=%d owns=%v foreign=%v fn=%s subst=%v: %s:%d %s\\n", l.specialization, inTrial, making, owns, foreign, fn, l.subst != nil, d.File, d.Line, d.Message)
		if os.Getenv("PTS_DBG_REPORT") == "stack" {
			os.Stderr.Write(debug.Stack())
		}
	}
	l.reports++'''
assert old in s
s = s.replace(old, new, 1)
open(p, 'w').write(s)
json.dump({"Replace": {src: p}}, open('/tmp/h09b5b/repro2/proto/dbg/overlay.json', 'w'))
