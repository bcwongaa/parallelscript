#!/bin/sh
# A PTS_CC that appends its arguments to $CC_LOG (one invocation per line) and runs clang.
echo "$*" >> "${CC_LOG:-/tmp/h09b5b/repro2/tmp/cc.log}"
exec clang "$@"
