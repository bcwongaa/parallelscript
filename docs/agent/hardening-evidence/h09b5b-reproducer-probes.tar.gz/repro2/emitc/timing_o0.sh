#!/bin/bash
# timing_o0.sh FILE.pts... : per program, wall seconds of clang -c -O0 (an object, no link) and of
# clang -O0 compile + link against the release runtime's archives (what would also catch
# undefined references), against the -O2 build's.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
PTS=$WT/pts-bin/pts
INC="-I $WT/pts/runtime/include -I $WT/pts/third_party/bdwgc/include -I $WT/pts/third_party/libuv/include -I $WT/pts/third_party/ryu -I $WT/pts/third_party/libbacktrace -I $WT/pts/third_party/pcre2-config"
CACHE=${PTS_CACHE_DIR:-$HOME/.cache/pts}
# the release runtime's archives, as a `pts build` with logging_cc.sh showed them
ARCH=$(grep main.c /tmp/h09b5b/repro2/tmp/cc.log | tail -1 | tr ' ' '\n' | grep '\.a$' | tr '\n' ' ')
echo "archives:$ARCH"
mkdir -p /tmp/h09b5b/repro2/tmp
t() { local s=$(date +%s.%N); "$@" > /tmp/h09b5b/repro2/tmp/o0.log 2>&1; local c=$?; local e=$(date +%s.%N); echo "$(echo "$e - $s" | bc) $c"; }
for f in "$@"; do
  d=$(mktemp -d /tmp/h09b5b/repro2/tmp/o0.XXXXXX)
  PTS_HOME=$WT "$PTS" emit-c "$(readlink -f "$f")" -o "$d/main.c"
  c=$(t clang -c -O0 -std=c11 -w $INC "$d/main.c" -o "$d/main.o")
  l=$(t clang -O0 -std=c11 -w $INC "$d/main.c" $ARCH -lpthread -ldl -lm -static-libgcc -o "$d/exe")
  echo "$(basename "$f") lines=$(wc -l < "$d/main.c") cO0=$c linkO0=$l"
  rm -rf "$d"
done
