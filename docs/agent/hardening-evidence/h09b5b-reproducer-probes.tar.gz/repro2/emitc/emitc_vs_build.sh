#!/bin/bash
# emitc_vs_build.sh CC MARKER FILE.pts... : for each program, `pts emit-c` (no C compiler) and
# `pts build` with PTS_CC=CC (rejecting_cc.sh or unlinking_cc.sh, REJECT_MARKER=MARKER), then
# compares the C emit-c printed with the C the build compiled (COMPILED_COPY), counts the marker
# in each, runs the built program (deleting it at once) and prints its output.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
PTS=$WT/pts-bin/pts
cc=$1
marker=$2
shift 2
mkdir -p /tmp/h09b5b/repro2/tmp
for f in "$@"; do
  abs=$(readlink -f "$f")
  d=$(mktemp -d /tmp/h09b5b/repro2/tmp/ecb.XXXXXX)
  echo "=== $(basename "$f")  CC=$(basename "$cc") marker=$marker"
  PTS_HOME=$WT "$PTS" emit-c "$abs" -o "$d/emit.c" > "$d/emit.log" 2>&1
  echo "emit-c exit=$? lines=$(wc -l < "$d/emit.c" 2>/dev/null) marker-count=$(grep -c "$marker" "$d/emit.c" 2>/dev/null)"
  start=$(date +%s.%N)
  PTS_HOME=$WT PTS_CC=$cc REJECT_MARKER=$marker COMPILED_COPY=$d/built.c "$PTS" build "$abs" -o "$d/exe" > "$d/build.log" 2>&1
  code=$?
  end=$(date +%s.%N)
  echo "build exit=$code seconds=$(echo "$end - $start" | bc) stderr: $(head -c 300 "$d/build.log" | tr '\n' ' ')"
  if [ -f "$d/built.c" ]; then
    echo "built C lines=$(wc -l < "$d/built.c") marker-count=$(grep -c "$marker" "$d/built.c")"
    if cmp -s "$d/emit.c" "$d/built.c"; then echo "emit-c C == built C"; else echo "emit-c C != built C ($(diff "$d/emit.c" "$d/built.c" | grep -c '^[<>]') differing lines)"; fi
  else
    echo "no C compiled"
  fi
  if [ -x "$d/exe" ]; then
    (cd "$d" && TZ=America/New_York timeout 30 ./exe 2>&1 | head -8; echo "run exit=${PIPESTATUS[0]}")
    rm -f "$d/exe"
  fi
  rm -rf "$d"
done
