#!/bin/bash
# run_timing.sh : the timing table for typical (3 runs, minimum) and large (1 run) programs.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
M4=/tmp/h09b5b/repro2/old/repro/matrix/cases/m4_growth
cd /tmp/h09b5b/repro2/emitc
./timing.sh p/none__iface.pts $WT/pts/tests/run/generic_instances_many_calls.pts $WT/pts/tests/run/array_pattern_lazy.pts \
  $WT/pts/tests/run/abort_signal_shared_threads.pts $WT/pts/tests/corpus/text/sql_query_parser.pts \
  $WT/pts/tests/run/generic_polymorphic_recursion_dispatched.pts > timing_typical.txt 2>&1
RUNS=1 ./timing.sh $M4/esc_40x50.pts $M4/decls_60.pts $M4/esc_150x50.pts > timing_large.txt 2>&1
