#!/bin/sh
# A PTS_CC whose compile of a program's C (*/main.c) holding $REJECT_MARKER (default
# pts_method_instance_find) succeeds but whose link fails as ld does for a function the C calls
# and nothing defines ("undefined reference to `pts_fn_x'"), and that compiles and links
# anything else with clang, copying the last program C it linked to $COMPILED_COPY (if set).
marker=${REJECT_MARKER:-pts_method_instance_find}
for arg in "$@"; do
  case "$arg" in
  */main.c)
    if grep -q "$marker" "$arg"; then
      echo "/usr/bin/ld: /tmp/main-0d1e2f.o: in function \`pts_fn_main':" >&2
      echo "$arg:(.text+0x2a): undefined reference to \`pts_fn_x'" >&2
      echo "clang: error: linker command failed with exit code 1 (use -v to see invocation)" >&2
      exit 1
    fi
    if [ -n "$COMPILED_COPY" ]; then cp "$arg" "$COMPILED_COPY"; fi
    ;;
  esac
done
exec clang "$@"
