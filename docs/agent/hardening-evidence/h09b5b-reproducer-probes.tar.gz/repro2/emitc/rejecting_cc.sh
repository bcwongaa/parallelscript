#!/bin/sh
# A PTS_CC that rejects, as clang rejects C it can't compile, a program's C (*/main.c) holding
# $REJECT_MARKER (default pts_method_instance_find), and compiles anything else with clang,
# copying the last program C it compiled to $COMPILED_COPY (if set). Runtime archives (no
# main.c among the arguments) build as usual.
marker=${REJECT_MARKER:-pts_method_instance_find}
for arg in "$@"; do
  case "$arg" in
  */main.c)
    if grep -q "$marker" "$arg"; then
      echo "$arg:1:1: error: rejected by the test's C compiler" >&2
      exit 1
    fi
    if [ -n "$COMPILED_COPY" ]; then cp "$arg" "$COMPILED_COPY"; fi
    ;;
  esac
done
exec clang "$@"
