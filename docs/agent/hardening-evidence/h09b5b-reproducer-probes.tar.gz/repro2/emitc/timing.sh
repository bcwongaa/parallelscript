#!/bin/bash
# timing.sh FILE.pts... : per program, the wall seconds of `pts emit-c`, of clang -fsyntax-only
# on that C with the build's include dirs (-std=c11 -w, as TestCompilerFailsCleanly's
# PTS_SMOKE_CLANG check), of clang -fsyntax-only with the build's own flags (-O2 -g ...), and
# of a full `pts build` (lower + clang -O2 compile + link), with the C's lines. Each 3 runs, the
# minimum reported. Binaries deleted at once.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
PTS=$WT/pts-bin/pts
INC="-I $WT/pts/runtime/include -I $WT/pts/third_party/bdwgc/include -I $WT/pts/third_party/libuv/include -I $WT/pts/third_party/ryu -I $WT/pts/third_party/libbacktrace -I $WT/pts/third_party/pcre2-config"
mkdir -p /tmp/h09b5b/repro2/tmp
t() { local s=$(date +%s.%N); "$@" > /dev/null 2>&1; local c=$?; local e=$(date +%s.%N); echo "$(echo "$e - $s" | bc) $c"; }
min() { printf '%s\n' "$@" | sort -n | head -1; }
printf "%-48s %7s %8s %8s %8s %8s\n" program lines emit-c syntax syntaxO2 build
for f in "$@"; do
  abs=$(readlink -f "$f")
  d=$(mktemp -d /tmp/h09b5b/repro2/tmp/tim.XXXXXX)
  e=(); s=(); o=(); b=()
  for i in $(seq 1 ${RUNS:-3}); do
    r=$(PTS_HOME=$WT t "$PTS" emit-c "$abs" -o "$d/main.c"); e+=(${r% *})
    r=$(t clang -fsyntax-only -std=c11 -w -ferror-limit=3 $INC "$d/main.c"); s+=(${r% *}); sc=${r#* }
    r=$(t clang -fsyntax-only -O2 -g -ffp-contract=off -fno-math-errno -falign-functions=32 -std=c11 $INC "$d/main.c"); o+=(${r% *})
    r=$(PTS_HOME=$WT t "$PTS" build "$abs" -o "$d/exe"); b+=(${r% *}); bc=${r#* }
    rm -f "$d/exe"
  done
  printf "%-48s %7s %8.3f %8.3f %8.3f %8.3f  (syntax exit %s, build exit %s)\n" "$(basename "$f")" "$(wc -l < "$d/main.c")" "$(min "${e[@]}")" "$(min "${s[@]}")" "$(min "${o[@]}")" "$(min "${b[@]}")" "$sc" "$bc"
  rm -rf "$d"
done
