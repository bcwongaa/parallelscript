#!/bin/bash
# duo.sh FILE.pts... : run each probe with Node (.mts copy) and HEAD's CLI (this reproducer's
# worktree build). Writes FILE.node / FILE.<SUF> (output + "exit=N") beside the probe and prints them.
# NO_NODE=1 skips Node; SUF (default head) names the pts output; PTS/PTSHOME pick the CLI and runtime.
# Node's output is cached: an existing FILE.node is kept unless NODE_AGAIN=1.
NODE=${NODE:-$HOME/.local/node/bin/node}
PTSHOME=${PTSHOME:-/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a}
PTS=${PTS:-$PTSHOME/pts-bin/pts}
SUF=${SUF:-head}
mkdir -p /tmp/h09b5b/repro2/tmp
for f in "$@"; do
  abs=$(readlink -f "$f"); dir=$(dirname "$abs"); b=$(basename "$abs" .pts)
  d=$(mktemp -d /tmp/h09b5b/repro2/tmp/t.XXXXXX)
  cp "$abs" "$d/$b.mts"
  if [ -z "$NO_NODE" ] && { [ ! -f "$dir/$b.node" ] || [ -n "$NODE_AGAIN" ]; }; then
    (cd "$d" && TZ=America/New_York timeout 60 "$NODE" --no-warnings --experimental-transform-types "$b.mts" > "$dir/$b.node" 2>&1; echo "exit=$?" >> "$dir/$b.node")
  fi
  (cd "$d" && PTS_HOME=$PTSHOME TZ=America/New_York timeout ${PTS_TIMEOUT:-300} "$PTS" run "$abs" > "$dir/$b.$SUF" 2>&1; echo "exit=$?" >> "$dir/$b.$SUF")
  echo "=== $f"
  for k in node $SUF; do [ -f "$dir/$b.$k" ] && { echo "--- $k"; head -c 3000 "$dir/$b.$k"; }; done
  if cmp -s "$dir/$b.node" "$dir/$b.$SUF"; then echo "--- $SUF SAME as node"; else echo "--- $SUF DIFF from node"; fi
  rm -rf "$d"
done
