#!/usr/bin/env python3
"""pool_list.py : writes /tmp/h09b5b/repro2/pool_new_files.txt, the .pts files under pool_new/
(H09b5a's parent and review probes) whose content isn't already in the old pool (by sha256),
one per distinct content, skipping bin/ and overlay/ directories."""
import hashlib, os
R = "/tmp/h09b5b/repro2"
seen = set()
for line in open(R + "/pool_old_files.txt"):
    p = line.strip()
    if os.path.exists(p):
        seen.add(hashlib.sha256(open(p, "rb").read()).hexdigest())
out = []
for root, dirs, files in os.walk(R + "/pool_new"):
    dirs[:] = sorted(d for d in dirs if d not in ("bin", "overlay"))
    for f in sorted(files):
        if f.endswith(".pts"):
            p = os.path.join(root, f)
            h = hashlib.sha256(open(p, "rb").read()).hexdigest()
            if h not in seen:
                seen.add(h)
                out.append(p)
open(R + "/pool_new_files.txt", "w").write("".join(p + "\n" for p in out))
print(len(out), "new distinct programs")
