#!/usr/bin/env python3
"""stacks.py < dbg.sh-stack-output : prints, per DBG-REPORT, its line and the pts/lower and
pts/driver frames of its stack (function and file:line), innermost first, up to N (env N, 14)."""
import os, re, sys
N = int(os.environ.get("N", "14"))
lines = sys.stdin.read().split("\n")
i = 0
while i < len(lines):
    line = lines[i]
    if line.startswith("== ") or "  All " in line or "  Value " in line or "  Declared " in line or "emit-c=" in line:
        print(line[:220])
        i += 1
        continue
    if line.startswith("DBG-REPORT"):
        print(line.replace("/tmp/h09b5b/repro2/", "")[:260])
        i += 1
        frames = []
        func = None
        while i < len(lines) and not lines[i].startswith("DBG-REPORT") and not lines[i].startswith("  ") or (i < len(lines) and lines[i].startswith("\t")):
            l = lines[i]
            if l.startswith("\t"):
                m = re.search(r"/pts/(lower|driver)/([a-z_]+\.go):(\d+)", l)
                if m and func:
                    frames.append("%s %s:%s" % (func, m.group(2), m.group(3)))
            else:
                func = l.split("/")[-1].rsplit("(", 1)[0]
            i += 1
        for f in frames[1:N + 1]:  # frames[0] is report itself
            print("     ", f)
        continue
    i += 1
