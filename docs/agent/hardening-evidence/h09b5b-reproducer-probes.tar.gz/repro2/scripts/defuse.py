#!/usr/bin/env python3
"""defuse.py : writes /tmp/h09b5b/repro2/red/defused/<test>.pts, each RED run test with its
trigger neutralised in a way Node can't tell apart (the expect block kept): Weird's
`return v;` becomes `return v.slice();` (a new array, which D-094 copies), Derived's and Key's
other-typed optional property becomes a string or the interface's a number, the optional
argument before the rest parameter is given (1), five of the six recursions go. If a defused
test prints its expect block on HEAD at AllInstances, its victims and the trigger's other
pairings print Node's output once only the failing unit is out of the way."""
import os, re

SRC = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a/pts/tests/run"
OUT = "/tmp/h09b5b/repro2/red/defused"
os.makedirs(OUT, exist_ok=True)
for name in sorted(os.listdir(SRC)):
    if not name.startswith("generic_fallback_spares") or not name.endswith(".pts"):
        continue
    s = open(os.path.join(SRC, name)).read()
    s = re.sub(r"^// skip:.*\n", "", s, flags=re.M)
    t = s.replace("      return v;\n", "      return v.slice();\n")
    t = t.replace("  tag = 5;\n}\n", '  tag = "5";\n}\n', 1) if "class Derived" in t else t
    t = t.replace("interface Tagged {\n  id: number;\n  tag?: string;\n}", "interface Tagged {\n  id: number;\n  tag?: number;\n}") if "class Num" in t else t
    t = t.replace("interface Labelled {\n  key: number;\n  label?: string;\n}", "interface Labelled {\n  key: number;\n  label?: number;\n}")
    t = t.replace("(maybe(), 1, 2)", "(1, 1, 2)")
    t = t.replace("mm?.err({ kind: \"empty\" })", "mm?.err<PE>({ kind: \"empty\" })")
    if "R5" in t:
        t = t.replace("[new R0(), new R1(), new R2(), new R3(), new R4(), new R5()]", "[new R0()]")
        t = re.sub(r"class R[1-5] implements Rec \{\n(?:  .*\n|    .*\n|      .*\n)*?\}\n", "", t)
    if t == s:
        print("unchanged", name)
    open(os.path.join(OUT, name), "w").write(t)
print("wrote", OUT)
