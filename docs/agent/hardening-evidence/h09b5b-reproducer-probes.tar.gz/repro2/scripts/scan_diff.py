#!/usr/bin/env python3
"""scan_diff.py OLD NEW : compares two scan outputs (level<TAB>file<TAB>msg) by file name relative
to the pool root, printing each program whose level changed, and the counts."""
import sys, collections

def load(p, root):
    d = {}
    for line in open(p):
        parts = line.rstrip("\n").split("\t")
        if len(parts) < 2:
            continue
        f = parts[1]
        for r in root:
            f = f.replace(r, "")
        d[f] = (parts[0], parts[2] if len(parts) > 2 else "")
    return d

roots = ["/tmp/h09b5/repro/pool/", "/tmp/h09b5b/repro2/old/repro/pool/", "/tmp/h09b5b/repro2/pool_new/"]
old, new = load(sys.argv[1], roots), load(sys.argv[2], roots)
changes = collections.Counter()
for f in sorted(new):
    if f in old and old[f][0] != new[f][0]:
        changes[(old[f][0], new[f][0])] += 1
        print("%s -> %s\t%s\t%s" % (old[f][0], new[f][0], f, new[f][1][:200]))
print(dict(changes))
print("only new:", collections.Counter(v[0] for f, v in new.items() if f not in old))
