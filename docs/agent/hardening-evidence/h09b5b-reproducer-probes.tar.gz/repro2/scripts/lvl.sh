#!/bin/bash
# lvl.sh OUT FILE.pts... : runs tools/lvl/lvl (CLANG=1) on the files, output to OUT.
export PTS_HOME=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
export CLANG=${CLANG:-1}
out=$1
shift
start=$(date +%s)
/tmp/h09b5b/repro2/tools/lvl/lvl "$@" > "$out" 2>&1
echo "exit=$? seconds=$(( $(date +%s) - start ))" >> "$out"
