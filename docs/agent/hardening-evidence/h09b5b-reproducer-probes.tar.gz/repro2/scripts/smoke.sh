#!/bin/bash
# smoke.sh TAG FILTER MUTANTS SEED : TestCompilerFailsCleanly on the seeds matching FILTER with
# MUTANTS mutants each (seed SEED), clang -fsyntax-only on every C, 2 jobs; failures written to
# /tmp/h09b5b/repro2/smoke/TAG/; log in /tmp/h09b5b/repro2/smoke/TAG.log, TAG.done at the end.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
out=/tmp/h09b5b/repro2/smoke
mkdir -p $out
rm -f $out/$1.done
cd $WT
start=$(date +%s)
GOMAXPROCS=2 PTS_SMOKE_FILTER="$2" PTS_SMOKE_MUTANTS=$3 PTS_SMOKE_SEED=$4 PTS_SMOKE_CLANG=1 PTS_SMOKE_JOBS=2 PTS_SMOKE_OUT=$out/$1 \
  go test -count=1 -timeout 60m -run 'TestCompilerFailsCleanly$' -v ./pts/tests/ > $out/$1.log 2>&1
echo "exit=$? seconds=$(( $(date +%s) - start ))" > $out/$1.done
