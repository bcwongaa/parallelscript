#!/bin/bash
# make_reds.sh : writes each red/src/*.pts with Node's `// expect:` block into the worktree's
# pts/tests/run/ (RED tests), and a copy into red/run/.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
mkdir -p /tmp/h09b5b/repro2/red/run
for f in /tmp/h09b5b/repro2/red/src/*.pts; do
  b=$(basename "$f")
  python3 -I /tmp/h09b5b/repro2/scripts/make_test.py "$f" "/tmp/h09b5b/repro2/red/run/$b" || exit 1
  cp "/tmp/h09b5b/repro2/red/run/$b" "$WT/pts/tests/run/$b"
done
