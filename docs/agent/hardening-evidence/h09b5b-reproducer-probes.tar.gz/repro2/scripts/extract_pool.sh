#!/bin/bash
# extract_pool.sh : extracts the H09b5a probe archives (parent and review rounds 1-6) into
# /tmp/h09b5b/repro2/pool_new/<archive>/ for the pool scan.
EV=/home/bryan/projects/parallelscript/docs/agent/hardening-evidence
mkdir -p /tmp/h09b5b/repro2/pool_new
for a in h09b5a-parent-probes h09b5a-review1-probes h09b5a-review2-probes h09b5a-review3-probes h09b5a-review4-probes h09b5a-review5-probes h09b5a-review6-probes; do
  mkdir -p /tmp/h09b5b/repro2/pool_new/$a
  tar xzf $EV/$a.tar.gz -C /tmp/h09b5b/repro2/pool_new/$a
done
find /tmp/h09b5b/repro2/pool_new -name "*.pts" | wc -l
