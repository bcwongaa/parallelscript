#!/bin/bash
# dbg.sh MODE FILE.pts... : runs the debug lvl (report() traced; MODE "1" one line per report,
# "stack" with Go stacks) on the files, without clang.
export PTS_HOME=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
export CLANG=0
export PTS_DBG_REPORT=$1
shift
/tmp/h09b5b/repro2/tools/lvl/lvl-dbg "$@" 2>&1
