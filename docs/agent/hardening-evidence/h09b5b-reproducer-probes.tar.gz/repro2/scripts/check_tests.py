#!/usr/bin/env python3
"""check_tests.py FILE.pts... : checks repo-format tests with the CLI, ignoring `// skip:`.

run tests (with an // expect: block): `pts run` (PTS, PTS_HOME) must print the block and exit
with // exit: (default 0); with NODE_TOO=1 Node (.mts copy) must print the same too.
errors tests (// error: lines): `pts emit-c` must fail and its output contain each line.
Prints PASS/FAIL per file with the first differing lines."""
import os, re, shutil, subprocess, sys, tempfile

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a"
PTS = os.environ.get("PTS", WT + "/pts-bin/pts")
PTS_HOME = os.environ.get("PTS_HOME", WT)
NODE = os.path.expanduser("~/.local/node/bin/node")
SCRATCH = "/tmp/h09b5b/repro2/tmp"
directive = re.compile(r"^//\s*([a-z-]+):(.*)$")


def spec(path):
    lines = open(path).read().split("\n")
    out, exit_code, errors, i = None, 0, [], 0
    while i < len(lines):
        m = directive.match(lines[i].strip())
        if m:
            name, value = m.group(1), m.group(2).strip()
            if name == "expect":
                block = []
                i += 1
                while i < len(lines) and lines[i].startswith("//"):
                    t = lines[i][2:]
                    block.append(t[1:] if t.startswith(" ") else t)
                    i += 1
                out = "".join(b + "\n" for b in block)
                continue
            if name == "exit":
                exit_code = int(value)
            if name == "error":
                errors.append(value)
        i += 1
    if out is None and os.path.exists(path[:-4] + ".out"):
        out = open(path[:-4] + ".out").read()
    return out, exit_code, errors


def run(cmd, cwd, env=None, timeout=300):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
    return p.returncode, p.stdout, p.stderr


def main():
    os.makedirs(SCRATCH, exist_ok=True)
    env = dict(os.environ, PTS_HOME=PTS_HOME, TZ="America/New_York")
    for path in sys.argv[1:]:
        path = os.path.abspath(path)
        out, exit_code, errors = spec(path)
        d = tempfile.mkdtemp(dir=SCRATCH)
        try:
            if errors:
                code, stdout, stderr = run([PTS, "emit-c", path, "-o", os.path.join(d, "x.c")], os.path.dirname(path), env)
                text = stdout + stderr
                missing = [e for e in errors if e not in text]
                if code != 0 and not missing:
                    print("PASS", path)
                else:
                    print("FAIL", path, "exit=%d" % code, "missing:", missing, "| got:", text.strip().replace("\n", " | ")[:600])
                continue
            code, stdout, stderr = run([PTS, "run", path], d, env)
            ok = stdout == out and code == exit_code
            node_note = ""
            if os.environ.get("NODE_TOO") == "1":
                b = os.path.basename(path)[:-4]
                shutil.copy(path, os.path.join(d, b + ".mts"))
                ncode, nout, nerr = run([NODE, "--no-warnings", "--experimental-transform-types", b + ".mts"], d, env, 60)
                node_note = " node=%s" % ("same-as-expect" if nout == out and ncode == exit_code else "DIFFERS(exit=%d) %r" % (ncode, nout[:300]))
            if ok:
                print("PASS", path + node_note)
            else:
                want, got = out.split("\n"), stdout.split("\n")
                diff = [("-" + a, "+" + b) for a, b in zip(want, got) if a != b][:3]
                print("FAIL", path, "exit=%d" % code, diff, "stderr:", stderr.strip().replace("\n", " | ")[:400], node_note)
        finally:
            shutil.rmtree(d, ignore_errors=True)


main()
