#!/usr/bin/env python3
"""make_test.py SRC.pts DEST.pts : runs SRC under Node (a .mts copy, --no-warnings
--experimental-transform-types, TZ=America/New_York) and writes DEST: SRC followed by an
`// expect:` block of Node's stdout (and `// exit: N` if Node exits non-zero). Refuses if
Node writes to stderr."""
import os, shutil, subprocess, sys, tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
src, dest = sys.argv[1], sys.argv[2]
d = tempfile.mkdtemp(dir="/tmp/h09b5b/repro2/tmp")
try:
    b = os.path.basename(src)[:-4]
    shutil.copy(src, os.path.join(d, b + ".mts"))
    p = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", b + ".mts"], cwd=d,
                       capture_output=True, text=True, timeout=60, env=dict(os.environ, TZ="America/New_York"))
finally:
    shutil.rmtree(d, ignore_errors=True)
if p.stderr:
    sys.exit("node wrote to stderr:\n" + p.stderr)
text = open(src).read().rstrip("\n") + "\n"
if p.returncode != 0:
    text += "// exit: %d\n" % p.returncode
text += "// expect:\n" + "".join("// " + line + "\n" if line else "//\n" for line in p.stdout.rstrip("\n").split("\n"))
open(dest, "w").write(text)
print("wrote", dest, "node exit", p.returncode)
print(p.stdout)
