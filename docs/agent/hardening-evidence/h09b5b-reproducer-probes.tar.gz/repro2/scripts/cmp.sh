#!/bin/bash
# cmp.sh SUF FILE.pts... : prints SAME/DIFF of FILE.node against FILE.SUF, with the first
# differing lines.
suf=$1
shift
for f in "$@"; do
  b=${f%.pts}
  if cmp -s "$b.node" "$b.$suf"; then
    echo "SAME $(basename "$f")"
  else
    echo "DIFF $(basename "$f")"
    diff "$b.node" "$b.$suf" | head -8 | sed "s#$(dirname "$(readlink -f "$f")")/##g" | cut -c1-220
  fi
done
