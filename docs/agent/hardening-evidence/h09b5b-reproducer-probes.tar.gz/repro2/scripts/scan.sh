#!/bin/bash
# scan.sh LIST OUT : runs tools/scan/scan over the files in LIST (one per line), output to OUT,
# stderr to OUT.err; writes OUT.done when finished.
export PTS_HOME=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a
export GOMAXPROCS=2
rm -f "$2.done"
start=$(date +%s)
/tmp/h09b5b/repro2/tools/scan/scan < "$1" > "$2" 2> "$2.err"
echo "exit=$? seconds=$(( $(date +%s) - start ))" > "$2.done"
