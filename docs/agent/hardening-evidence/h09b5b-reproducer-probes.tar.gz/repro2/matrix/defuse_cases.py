#!/usr/bin/env python3
"""defuse_cases.py OUT DIR... : copies every case (*.pts, and its .node: Node prints the same) into
OUT with its trigger neutralised as tools' defuse.py does for the RED tests (Weird returns a copy,
the other-typed optional properties agree, the optional argument before the rest parameter is
given, the `?.` call names its type argument, one recursion instead of six). A defused case
that prints Node's output on HEAD at AllInstances shows that the case's victim and the trigger's
other lines print Node's output once the failing unit alone is out of the way."""
import os, re, shutil, sys

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
for d in sys.argv[2:]:
    for name in sorted(os.listdir(d)):
        if not name.endswith(".pts"):
            continue
        s = open(os.path.join(d, name)).read()
        t = s.replace("      return v;\n", "      return v.slice();\n")
        t = t.replace("class Derived extends Base {\n  tag = 5;\n}", 'class Derived extends Base {\n  tag = "5";\n}')
        if "class Num" in t:
            t = t.replace("interface Tagged {\n  id: number;\n  tag?: string;\n}", "interface Tagged {\n  id: number;\n  tag?: number;\n}")
        t = t.replace("(maybe(), 1, 2)", "(1, 1, 2)").replace("(maybe2(), 1, 2)", "(1, 1, 2)")
        t = t.replace('mm?.err({ kind: "empty" })', 'mm?.err<PE>({ kind: "empty" })')
        t = t.replace("[new R0(), new R1(), new R2(), new R3(), new R4(), new R5()]", "[new R0()]")
        t = re.sub(r"class R[1-5] implements Rec \{\n(?:  .*\n)*?\}\n", "", t)
        t = t.replace("[r0, r1, r2, r3, r4, r5]", "[r0]")
        t = re.sub(r"const r[1-5] = \{\n(?:  .*\n)*?\};\n", "", t)
        open(os.path.join(out, name), "w").write(t)
        node = os.path.join(d, name[:-4] + ".node")
        if os.path.exists(node):
            shutil.copy(node, os.path.join(out, name[:-4] + ".node"))
print("wrote", out)
