#!/usr/bin/env python3
"""Generates the H09b5b C176 matrix (family m9, extending the H09b5 reproducer's m6) into
OUT/<case>.pts (default /tmp/h09b5b/repro2/matrix/cases):

  <trigger>__<victim>__<placement>
    trigger    a part of the program whose instances fail in a way no trial takes back (TRIGGERS)
    victim     an unrelated generic call that needs one of the three fallback levels (VICTIMS);
               every victim prints "victim 6" when it finds its instance
    placement  other: the victim in a function of its own; same: in the trigger's function
  <trigger>__samevalue   the victim another call of the trigger's own value or method, through
                         a pairing (or site) that lowers (the narrowest unit is then the pairing
                         or the site, not the value)
  <trigger>__alone       control: the trigger alone (its own lines lose their instances too)
  none__<victim>         control: the victim alone

The trigger's own lines print what Node prints whether or not its failing unit keeps its
instances (a failing call's own result is printed as a fixed string)."""
import os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/h09b5b/repro2/matrix/cases"
ONLY = sys.argv[2].split(",") if len(sys.argv) > 2 else None  # generate only these triggers' cases

BLOCKS = {
    "BOX": "class Box<T> {\n  constructor(public value: T) {}\n}\n",
    "ATTEMPT": """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
""",
    "ANIMALS": """class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
""",
    "USEDOGS": """function useDogs(f: <T>(x: T) => Box<T>): number {
  const b: Box<Dog[]> = f([new Dog()]);
  return b.value.length;
}
""",
    "USENUM": """function useNum(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
""",
    "USEW": """function useW(f: <T>(x: T) => Weird<T>): string {
  const a: Weird<number> = f(1);
  return String(a.value + 5);
}
""",
    "TAGGED": """interface Tagged {
  id: number;
  tag?: string;
}
class Base {
  id = 1;
}
class Derived extends Base {
  tag = 5;
}
class Plain extends Base {
  other = 5;
}
function useBase(f: <T extends Base>(x: T) => Box<T>): number {
  return f(new Base()).value.id;
}
function usePlain(f: <T extends Base>(x: T) => Box<T>): string {
  const b: Box<Plain> = f(new Plain());
  return String(b.value.other + 1);
}
""",
    "MREST": """interface M {
  f<T>(a?: number, ...xs: T[]): Box<T[]>;
  g<T>(a?: number, ...xs: T[]): Box<T[]>;
}
class CM implements M {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
  g<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs.slice(1));
  }
}
function maybe(): number | undefined {
  return undefined;
}
function pickKey(n: number): "f" | "g" {
  return n > 0 ? "f" : "g";
}
""",
    "RESULT": """type Ok<T> = { ok: true; value: Box<T> };
type Err<E> = { ok: false; error: Box<E> };
type Result<T, E> = Ok<T> | Err<E>;
type PE = { kind: "empty" } | { kind: "bad"; at: number };
interface ErrMaker {
  err<E>(e: E): Err<E>;
}
class ClassErrMaker implements ErrMaker {
  err<E>(e: E): Err<E> {
    return { ok: false, error: new Box(e) };
  }
}
function pick<X>(flag: boolean, x: X): X | undefined {
  return flag ? x : undefined;
}
""",
    "WEIRDMAKER": """class WeirdMaker {
  make<T>(x: T): Box<T> {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  }
}
""",
    "WEIRDLITERAL": """interface DogMaker {
  make<T>(x: T): Box<T>;
}
class ClassDogMaker implements DogMaker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const weirdLiteral = {
  make<T>(x: T): Box<T> {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  },
};
""",
    "TWIN": """interface DogMaker {
  make<T>(x: T): Box<T>;
}
class ClassDogMaker implements DogMaker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Twin {
  make<T>(x: T): Box<T> {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  }
}
""",
    "HOLDER": """class Holder<T> {
  constructor(public value: T) {}
  count(f: <U>(x: U) => Box<U>): number {
    const b: Box<T[]> = f([this.value]);
    return b.value.length;
  }
}
function useDog(f: <T>(x: T, label: string) => Box<T>): string {
  const b: Box<Dog> = f(new Dog(), "dog");
  return b.value.name;
}
""",
    "HASID": """interface HasId {
  id: number;
}
interface Tagged {
  id: number;
  tag?: string;
}
class Item {
  id = 1;
}
class Num {
  id = 2;
  tag = 5;
}
function useNumHas(f: <T extends HasId>(x: T) => Box<T>): string {
  const b: Box<Num> = f(new Num());
  return String(b.value.tag + 1);
}
function useItem(f: <T extends HasId>(x: T) => Box<T>): string {
  const b: Box<Item> = f(new Item());
  return String(b.value.id + 5);
}
""",
    "CONV": """class Conv<T extends HasId> {
  constructor(public value: T) {}
  asHasId(): HasId {
    return this.value;
  }
}
""",
    "MAYBE2": """function maybe2(): number | undefined {
  return undefined;
}
""",
    "USEDOGSP": """async function useDogsP(f: <T>(x: T) => Promise<Box<T>>): Promise<number> {
  const b = await f([new Dog()]);
  return b.value.length;
}
""",
}


def rec_classes(kind):
    s = "interface Rec {\n  rec<T>(x: T, n: number): Box<T>;\n}\n"
    for i in range(6):
        body = (f"  rec<T>(x: T, n: number): Box<T> {{\n    if (n > 0) {{\n      this.rec<[T]>([x], n - 1);\n"
                f"      this.rec<{{ v{i}: T }}>({{ v{i}: x }}, n - 1);\n    }}\n    return new Box(x);\n  }}")
        if kind == "class":
            s += f"class R{i} implements Rec {{\n{body}\n}}\n"
        else:
            s += f"const r{i} = {{\n{body},\n}};\n"
    return s


BLOCKS["RECCLASS"] = rec_classes("class")
BLOCKS["RECLIT"] = rec_classes("literal")

ORDER = ["BOX", "ATTEMPT", "ANIMALS", "TAGGED", "MREST", "RESULT", "HASID", "USEDOGS", "USENUM", "USEW", "USEDOGSP", "MAYBE2", "CONV",
         "WEIRDMAKER", "WEIRDLITERAL", "TWIN", "HOLDER", "RECCLASS", "RECLIT"]

RAN = 'try {\n    %s;\n    console.log("%s ran");\n  } catch (error: any) {\n    console.log("%s ran");\n  }\n'

# trigger: (blocks, body statements of `function trigger()`, same-value victim statements or None,
# async). The body's statements are indented by two spaces.
TRIGGERS = {
    "classbody_taken": (["ANIMALS", "USEDOGS", "USEW"], """  const w = <T,>(x: T): Weird<T> => new Weird(x);
  const d: any = w;
  console.log("trigger", d(1).animals().length);
  attempt("dogs", () => String(useDogs(<T,>(x: T): Box<T> => new Box(x))));
""", '  attempt("victim", () => useW(w));\n', False),
    "classbody_kept": (["ANIMALS", "USEDOGS", "USENUM"], """  const w = <T,>(x: T): Box<T> => {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  };
  const d: any = w;
  console.log("trigger", d(1).value);
  attempt("dogs", () => String(useDogs(<T,>(x: T): Box<T> => new Box(x))));
""", '  attempt("victim", () => useNum(w));\n', False),
    "relaxed": (["TAGGED"], """  const boxed = <T extends Base>(x: T): Box<T> => {
    const tagged: Tagged = x;
    return new Box(x);
  };
  const d: any = boxed;
  console.log("trigger", d(new Base()).value.id, new Derived().tag);
  if (d.length > 5) {
    console.log(useBase(boxed));
  }
""", '  attempt("victim", () => usePlain(boxed));\n', False),
    "callsite_iface": (["MREST"], "  const m: M = new CM();\n  " + RAN % ("m.f(maybe(), 1, 2)", "trigger", "trigger"),
                       '  attempt("victim", () => {\n    const b: Box<number[]> = m.f(1, 1, 2, 3, 4, 5, 6);\n    return String(b.value.length);\n  });\n', False),
    "callsite_keyed": (["MREST"], "  const m: M = new CM();\n  " + RAN % ('m["f"](maybe(), 1, 2)', "trigger", "trigger"),
                       '  attempt("victim", () => {\n    const b: Box<number[]> = m["f"](1, 1, 2, 3, 4, 5, 6);\n    return String(b.value.length);\n  });\n', False),
    "callsite_unionkey": (["MREST"], "  const m: M = new CM();\n  const key = pickKey(1);\n  " + RAN % ("m[key](maybe(), 1, 2)", "trigger", "trigger"),
                          '  attempt("victim", () => {\n    const b: Box<number[]> = m[key](1, 1, 2, 3, 4, 5, 6);\n    return String(b.value.length);\n  });\n', False),
    "callsite_optional": (["RESULT"], """  const em: ErrMaker = new ClassErrMaker();
  const mm: ErrMaker | undefined = pick(true, em);
  try {
    const r: Result<number, PE> | undefined = mm?.err({ kind: "empty" });
    console.log("trigger ran", r !== undefined);
  } catch (error: any) {
    console.log("trigger ran", true);
  }
""", '  attempt("victim", () => {\n    const e: Err<number> = em.err(6);\n    return String(e.error.value);\n  });\n', False),
    "forwarder": (["ANIMALS", "USEDOGS", "USENUM", "WEIRDMAKER"], """  const mv = new WeirdMaker().make;
  const d: any = mv;
  console.log("trigger", d(1).value);
  attempt("dogs", () => String(useDogs(<T,>(x: T): Box<T> => new Box(x))));
""", '  attempt("victim", () => useNum(mv));\n', False),
    "literal": (["ANIMALS", "WEIRDLITERAL"], """  const dm: DogMaker = new ClassDogMaker();
  attempt("dogs", () => String(dm.make([new Dog()]).value.length));
  const d: any = weirdLiteral;
  console.log("trigger", d.make(1).value);
""", '  attempt("victim", () => String(weirdLiteral.make(5).value + 1));\n', False),
    "twin": (["ANIMALS", "TWIN"], """  const dm: DogMaker = new ClassDogMaker();
  attempt("dogs", () => String(dm.make([new Dog()]).value.length));
  console.log("twin", new Twin().make(1).value);
""", '  const tm: DogMaker = new Twin();\n  attempt("victim", () => String(tm.make(5).value + 1));\n', False),
    "adapter": (["ANIMALS"], """  const w = <T,>(x: T): Box<T> => {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  };
  const d: any = w;
  console.log("trigger", d(1).value);
  const mk = <T,>(x: T): Box<T> => new Box(x);
  const t: (x: Dog[]) => Box<Dog[]> = mk;
  attempt("adapted", () => String(t([new Dog()]).value.length));
""", '  const tn: (x: number) => Box<number> = w;\n  attempt("victim", () => String(tn(5).value + 1));\n', False),
    "total_iface": (["RECCLASS"], "  const recs: Rec[] = [new R0(), new R1(), new R2(), new R3(), new R4(), new R5()];\n  "
                    + RAN % ("recs[0].rec(5, 3)", "trigger", "trigger"), None, False),
    "total_literal": (["RECLIT"], "  const recs: Rec[] = [r0, r1, r2, r3, r4, r5];\n  "
                      + RAN % ("recs[0].rec(5, 3)", "trigger", "trigger"), None, False),
    "chain": (["ANIMALS", "HOLDER"], """  const h = <T,>(x: T, label: string): Box<T> => {
    const holder = new Holder(x);
    console.log(label, holder.count(<U,>(y: U): Box<U> => new Box(y)));
    return new Box(x);
  };
  const w = <T,>(x: T): Box<T> => {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  };
  const escaped: any[] = [h, w];
  attempt("through any", () => String(escaped.length + escaped[1](2).value));
  attempt("dog", () => useDog(<T,>(x: T, label: string): Box<T> => new Box(x)));
""", None, False),
    "programcast": (["HASID"], """  const mk = <T extends HasId>(x: T): Box<T> => {
    const h: HasId = x;
    return new Box(x);
  };
  const d: any = mk;
  console.log("trigger", d(new Item()).value.id);
  attempt("num", () => useNumHas(<T extends HasId>(x: T): Box<T> => new Box(x)));
  const hasId: HasId = new Item();
  const t: Tagged = hasId;
  console.log("cast", t.id, t.tag);
""", '  attempt("victim", () => useItem(mk));\n', False),
    "dynresult": (["ANIMALS", "USEDOGSP"], """  const w = async <T,>(x: T): Promise<Box<T>> => {
    const weird = new Weird(x);
    console.log("weird", weird.animals().length);
    return new Box(x);
  };
  const d: any = w;
  console.log("trigger", (await d(1)).value);
  try {
    console.log("dogs", await useDogsP(async <T,>(x: T): Promise<Box<T>> => new Box(x)));
  } catch (error: any) {
    console.log("dogs", error.name, error.message);
  }
""", None, True),
    "callsite_value": (["MAYBE2"], """  const f: <T>(a?: number, ...xs: T[]) => Box<T[]> = <T,>(a?: number, ...xs: T[]): Box<T[]> => new Box(xs);
  try {
    const b: Box<number[]> = f(maybe2(), 1, 2);
    console.log("trigger ran", b.value.length);
  } catch (error: any) {
    console.log("trigger ran", 2);
  }
""", '  attempt("victim", () => {\n    const b: Box<number[]> = f(1, 1, 2, 3, 4, 5, 6);\n    return String(b.value.length);\n  });\n', False),
    "programcast_class": (["HASID", "CONV"], """  const mk = <T extends HasId>(x: T): Box<T> => {
    const conv = new Conv(x);
    return new Box(conv.value);
  };
  const d: any = mk;
  console.log("trigger", d(new Item()).value.id);
  attempt("num", () => useNumHas(<T extends HasId>(x: T): Box<T> => new Box(x)));
  const hasId: HasId = new Item();
  const t: Tagged = hasId;
  console.log("cast", t.id, t.tag);
""", '  attempt("victim", () => useItem(mk));\n', False),
}

# victim: (module declarations, statements, expression); the expression is "6" when the victim
# finds its instance.
VICTIMS = {
    "value": ("""function useG(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
""", "const g = <T,>(x: T): Box<T> => new Box(x);", "useG(g)"),
    "decl": ("""function make<T>(x: T): Box<T> {
  return new Box(x);
}
function useG(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
""", "", "useG(make)"),
    "iface": ("""interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
""", "const maker: Maker = new ClassMaker();", "String(maker.make(5).value + 1)"),
    "literal": ("""const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
""", "", "String(lit.make(5).value + 1)"),
    "localarrow": ("", "const named = <T,>(x: T): Box<T> => new Box(x);", "String(named(5).value + 1)"),
    "methodvalue": ("""class Maker2 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function useG(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
""", "", "useG(new Maker2().make)"),
    "adapter": ("", "const mk2 = <T,>(x: T): Box<T> => new Box(x);\n    const t2: (x: number) => Box<number> = mk2;", "String(t2(5).value + 1)"),
}

# the level a victim needs to find its instance
NEEDS = {"value": "Value", "decl": "Declared", "iface": "All", "literal": "All", "localarrow": "Value",
         "methodvalue": "All", "adapter": "All"}


def victim_lambda(name):
    _, stmts, expr = VICTIMS[name]
    if stmts:
        return '  attempt("victim", () => {\n    %s\n    return %s;\n  });\n' % (stmts, expr)
    return '  attempt("victim", () => %s);\n' % expr


def program(trigger, victim, placement):
    blocks = ["BOX", "ATTEMPT"]
    body, same, is_async = "", None, False
    if trigger:
        tblocks, body, same, is_async = TRIGGERS[trigger]
        blocks += tblocks
    s = "".join(BLOCKS[b] for b in ORDER if b in blocks)
    if victim:
        s += VICTIMS[victim][0]
    head = f"// C176 matrix (H09b5b): trigger {trigger or 'none'}, victim {victim or 'none'}"
    if victim:
        head += f" (needs {NEEDS[victim]}Instances)"
    head += f", placement {placement}.\n"
    if victim and placement == "other":
        _, stmts, expr = VICTIMS[victim]
        s += "function victim(): string {\n" + (f"  {stmts}\n" if stmts else "") + f"  return {expr};\n}}\n"
    if trigger:
        inner = ""
        if victim and placement == "same":
            inner += victim_lambda(victim).replace("\n    ", "\n    ")
        inner += body
        if placement == "samevalue":
            inner += same
        s += ("async " if is_async else "") + "function trigger(): " + ("Promise<void>" if is_async else "void") + " {\n" + inner + "}\n"
    if victim and placement == "other":
        s += 'attempt("victim", victim);\n'
    if victim and not trigger:
        s += 'attempt("victim", victim);\n' if placement == "other" else ""
    if trigger:
        s += "trigger();\n"
    return head + s


def write(name, text):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name + ".pts"), "w") as f:
        f.write(text)


n = 0
for t in TRIGGERS:
    if ONLY and t not in ONLY:
        continue
    for v in VICTIMS:
        for p in ("other", "same"):
            write(f"{t}__{v}__{p}", program(t, v, p))
            n += 1
    if TRIGGERS[t][2] is not None:
        write(f"{t}__samevalue", program(t, None, "samevalue"))
        n += 1
    write(f"{t}__alone", program(t, None, "alone"))
    n += 1
for v in VICTIMS if not ONLY else []:
    write(f"none__{v}", program(None, v, "other"))
    n += 1
print(n, "cases in", OUT)
