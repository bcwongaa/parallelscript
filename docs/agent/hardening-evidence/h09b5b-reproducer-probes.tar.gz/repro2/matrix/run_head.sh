#!/bin/bash
# run_head.sh JOBS : the whole matrix on HEAD's CLI; log in matrix_head.log, results_head.tsv;
# matrix_head.done at the end.
cd /tmp/h09b5b/repro2/matrix
rm -f matrix_head.done
start=$(date +%s)
python3 -I run.py --jobs ${1:-1} --out /tmp/h09b5b/repro2/matrix/results_head.tsv cases > matrix_head.log 2>&1
echo "exit=$? seconds=$(( $(date +%s) - start ))" > matrix_head.done
