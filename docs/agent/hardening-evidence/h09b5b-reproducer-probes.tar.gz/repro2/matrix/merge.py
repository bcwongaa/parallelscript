#!/usr/bin/env python3
"""merge.py : the final matrix. final/cases/ holds cases/ (259) with cases2/ (two more triggers,
32), cases3/ (the call sites' same-value victims reading a typed result, 5) and cases4/ (the chain
without h's erased copy reaching Holder<any>.count, 15) copied over it, each with .node and
.head; final/defused/ the same for the defused copies (.defused outputs). results_final.tsv and
results_final_defused.tsv merge the runs' rows by case name, later runs winning."""
import os, shutil

M = "/tmp/h09b5b/repro2/matrix"


def merge_dirs(dirs, out):
    os.makedirs(out, exist_ok=True)
    for d in dirs:
        for f in os.listdir(os.path.join(M, d)):
            shutil.copy(os.path.join(M, d, f), os.path.join(out, f))


def merge_tsv(paths, out):
    head, rows = None, {}
    for p in paths:
        lines = open(os.path.join(M, p)).read().rstrip("\n").split("\n")
        head = lines[0]
        for l in lines[1:]:
            rows[l.split("\t")[0]] = l
    open(os.path.join(M, out), "w").write(head + "\n" + "".join(rows[k] + "\n" for k in sorted(rows)))
    return len(rows)


merge_dirs(["cases", "cases2", "cases3", "cases4"], os.path.join(M, "final", "cases"))
merge_dirs(["cases_defused", "cases4_defused"], os.path.join(M, "final", "defused"))
print(merge_tsv(["results_head.tsv", "results_head2.tsv", "results_head3.tsv", "results_head4.tsv"], "results_final.tsv"), "cases")
print(merge_tsv(["results_defused.tsv", "results_defused4.tsv"], "results_final_defused.tsv"), "defused cases")
