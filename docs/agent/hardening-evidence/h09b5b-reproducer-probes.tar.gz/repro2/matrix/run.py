#!/usr/bin/env python3
"""Runs the H09b5b matrix: run.py [--jobs N] [--out results.tsv] CASEDIR

For each case (*.pts): Node runs a .mts copy (cached beside it as .node: stdout, then "exit=N");
`pts build` builds it (300 s limit, wall time kept) and the binary runs (60 s limit) and is deleted
at once (output kept beside the case as .head); then tools/lvl/lvl (CLANG=1) lowers every case at
each fallback level alone, which gives the level `pts emit-c` ends at (the first that lowers) and
the level `pts build` ends at (the first that lowers and that clang -fsyntax-only accepts; a link
failure isn't simulated), and AllInstances' first diagnostic. Classes:
  OK        stdout and exit code as Node's
  PTS1001   a compile error (first line kept)      PTS9001  an internal compiler error
  BUILDFAIL another build failure                   CRASH    a signal or a timeout at run time
  TYPEERR   ran, and printed or threw a TypeError "Expected …" that Node didn't
  WRONG     ran, with other output or exit code
and the victim's line: VOK (as Node's), VLOST (other), - (no victim). Environment: PTS, PTS_HOME."""
import argparse, concurrent.futures, os, re, shutil, subprocess, tempfile, time

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-af8c2d6cf3dc1ad6a"
PTS = os.environ.get("PTS", WT + "/pts-bin/pts")
PTS_HOME = os.environ.get("PTS_HOME", WT)
NODE = os.path.expanduser("~/.local/node/bin/node")
LVL = "/tmp/h09b5b/repro2/tools/lvl/lvl"
SCRATCH = "/tmp/h09b5b/repro2/tmp"
SUF = os.environ.get("SUF", "head")


def run(cmd, cwd, timeout, env=None):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        return p.returncode, p.stdout, p.stderr, False
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        return -1, out, "", True


def node_result(case):
    cache = case[:-4] + ".node"
    if not os.path.exists(cache):
        d = tempfile.mkdtemp(dir=SCRATCH)
        try:
            b = os.path.basename(case)[:-4]
            shutil.copy(case, os.path.join(d, b + ".mts"))
            code, out, err, timed = run([NODE, "--no-warnings", "--experimental-transform-types", b + ".mts"], d, 60,
                                        dict(os.environ, TZ="America/New_York"))
            with open(cache, "w") as f:
                f.write(out + err + "exit=%d\n" % (124 if timed else code))
        finally:
            shutil.rmtree(d, ignore_errors=True)
    text = open(cache).read()
    out, _, code = text.rpartition("exit=")
    return out, int(code.strip())


def victim_line(out):
    for line in out.split("\n"):
        if line.startswith("victim"):
            return line
    return None


def one(case):
    nout, ncode = node_result(case)
    d = tempfile.mkdtemp(dir=SCRATCH)
    env = dict(os.environ, PTS_HOME=PTS_HOME, TZ="America/New_York")
    try:
        exe = os.path.join(d, "a.out")
        start = time.time()
        code, out, err, timed = run([PTS, "build", case, "-o", exe], d, 300, env)
        build_s = time.time() - start
        if code != 0 or timed:
            text = out + err
            first = text.strip().split("\n")[0] if text.strip() else ""
            cls = "PTS9001" if "PTS9001" in text else "PTS1001" if "PTS1001" in text else "BUILDFAIL"
            with open(case[:-4] + "." + SUF, "w") as f:
                f.write(text + "exit=%d\n" % code)
            return case, cls, "-" if victim_line(nout) is None else "VLOST", build_s, first
        rcode, rout, rerr, rtimed = run([exe], d, 60, env)
        os.remove(exe)
        with open(case[:-4] + "." + SUF, "w") as f:
            f.write(rout + rerr + "exit=%d\n" % rcode)
        nv, pv = victim_line(nout), victim_line(rout)
        vs = "-" if nv is None else "VOK" if nv == pv else "VLOST"
        if rout == nout and rcode == ncode:
            return case, "OK", vs, build_s, ""
        diff = [b for a, b in zip(nout.split("\n"), (rout + rerr).split("\n")) if a != b]
        first = diff[0] if diff else (rout + rerr)[-200:]
        if rtimed or rcode < 0:
            return case, "CRASH", vs, build_s, first
        if re.search(r"TypeError.*Expected", rout + rerr) and not re.search(r"TypeError.*Expected", nout):
            return case, "TYPEERR", vs, build_s, first
        return case, "WRONG", vs, build_s, first
    finally:
        shutil.rmtree(d, ignore_errors=True)


def levels(cases):
    env = dict(os.environ, PTS_HOME=PTS_HOME, CLANG="1")
    p = subprocess.run([LVL] + cases, capture_output=True, text=True, env=env, timeout=7200)
    result, cur = {}, None
    for line in p.stdout.split("\n"):
        if line.startswith("== "):
            cur = line[3:].strip()
            result[cur] = {"all": ""}
        elif cur and line.strip().startswith("All ") and "ERR" in line:
            m = re.search(r"\.pts:(\d+:\d+) - error (PTS\d+): (.*)", line)
            result[cur]["all"] = ("%s %s %s" % (m.group(2), m.group(1), m.group(3)[:110])) if m else line.strip()[:140]
        elif cur and "emit-c=" in line:
            m = re.search(r"emit-c=(\S+) build=(\S+)", line)
            result[cur]["emit"], result[cur]["build"] = m.group(1), m.group(2)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--out", default="/tmp/h09b5b/repro2/matrix/results_%s.tsv" % SUF)
    ap.add_argument("dir")
    a = ap.parse_args()
    os.makedirs(SCRATCH, exist_ok=True)
    cases = sorted(os.path.join(os.path.abspath(a.dir), f) for f in os.listdir(a.dir) if f.endswith(".pts"))
    rows = {}
    with concurrent.futures.ThreadPoolExecutor(a.jobs) as ex:
        for case, cls, vs, build_s, first in ex.map(one, cases):
            rows[case] = (cls, vs, build_s, first)
            print(os.path.basename(case), cls, vs, flush=True)
    lv = levels(cases)
    with open(a.out, "w") as f:
        f.write("case\ttrigger\tvictim\tplacement\tclass\tvictim_line\temit_level\tbuild_level\tbuild_s\tall_first_diag\tfirst_diff\n")
        for case in cases:
            name = os.path.basename(case)[:-4]
            parts = name.split("__") + ["", ""]
            trig, vic, pl = parts[0], parts[1], parts[2]
            if vic in ("alone", "samevalue"):
                pl, vic = vic, ""
            if trig == "none":
                pl = "control"
            cls, vs, build_s, first = rows[case]
            l = lv.get(os.path.basename(case), {})
            f.write("\t".join([name, trig, vic, pl, cls, vs, l.get("emit", "?"), l.get("build", "?"), "%.2f" % build_s,
                               l.get("all", ""), first.replace("\t", " ")[:160]]) + "\n")
    print("wrote", a.out)


main()
