#!/usr/bin/env python3
"""report.py RESULTS.tsv... : the matrix's tables: per trigger, its fallback level (emit-c and
build), AllInstances' first diagnostic, and per victim x placement the case's class and whether
the victim's line matched Node's (VOK/VLOST); then counts per class and per victim line."""
import collections, sys

rows = []
for p in sys.argv[1:]:
    lines = open(p).read().rstrip("\n").split("\n")
    head = lines[0].split("\t")
    rows += [dict(zip(head, l.split("\t"))) for l in lines[1:]]

victims = ["value", "decl", "iface", "literal", "localarrow", "methodvalue", "adapter"]
short = {"OK": "OK", "TYPEERR": "TE", "PTS1001": "CE", "PTS9001": "ICE", "WRONG": "WR", "CRASH": "CR", "BUILDFAIL": "BF"}
by = collections.defaultdict(dict)
info = {}
for r in rows:
    key = r["victim"] + "/" + r["placement"] if r["victim"] else r["placement"]
    by[r["trigger"]][key] = r
    info.setdefault(r["trigger"], r)

def cell(r):
    if r is None:
        return "   .   "
    v = {"VOK": "v", "VLOST": "x", "-": "-"}[r["victim_line"]]
    return "%-3s %s" % (short[r["class"]], v)

print("Cells: class (OK, TE = TYPEERR, CE = compile error, ICE, WR = WRONG) and the victim line (v = as Node's, x = lost, - = none).")
print("o = victim in a function of its own, s = in the trigger's function.\n")
hdr = "%-18s %-9s %-9s" % ("trigger", "emit-c", "build") + "".join(" %-13s" % v for v in victims) + " %-7s %-7s" % ("samevl", "alone")
print(hdr)
print(" " * 38 + "".join(" %-13s" % "o     s" for _ in victims))
order = ["none"] + sorted(t for t in by if t != "none")
for t in order:
    first = info[t]
    line = "%-18s %-9s %-9s" % (t, first["emit_level"], first["build_level"])
    for v in victims:
        line += " %-6s %-6s" % (cell(by[t].get(v + "/other") or by[t].get(v + "/control")), cell(by[t].get(v + "/same")))
    line += " %-7s %-7s" % (cell(by[t].get("samevalue")), cell(by[t].get("alone")))
    print(line)
print()
print("AllInstances' first diagnostic per trigger:")
for t in order:
    print("  %-18s %s" % (t, info[t]["all_first_diag"] or "(none: lowers)"))
print()
cls = collections.Counter(r["class"] for r in rows)
print("classes:", dict(cls), "of", len(rows))
vl = collections.Counter(r["victim_line"] for r in rows if r["victim_line"] != "-")
print("victim lines:", dict(vl))
lost = collections.Counter((r["trigger"], r["victim"]) for r in rows if r["victim_line"] == "VLOST")
needs = {"value": "Value", "decl": "Declared", "iface": "All", "literal": "All", "localarrow": "Value", "methodvalue": "All", "adapter": "All"}
rank = {"All": 0, "Value": 1, "Declared": 2}
unexpected = [r for r in rows if r["victim"] and r["trigger"] != "none" and
              ((r["victim_line"] == "VOK") != (rank[needs[r["victim"]]] >= rank[r["build_level"]]))]
print("victim lines that the levels don't explain (lost though the build level serves the victim, or kept though it doesn't):")
for r in unexpected:
    print("  ", r["case"], r["class"], r["victim_line"], r["build_level"], r["first_diff"][:120])
mismatch = [r for r in rows if r["emit_level"] != r["build_level"]]
print("emit-c / build level mismatches:", len(mismatch), [r["case"] for r in mismatch])
