const rows: number[][] = Array.from({ length: 2_000 }, (_, i) => Array.from({ length: 100 }, (_, j) => i + j));
let total = 0;
for (let round = 0; round < 5; round++) {
  const flat = rows.flat();
  total += flat.length + flat[flat.length - 1];
}
console.log(total);
