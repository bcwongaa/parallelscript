const xs = Array.from({ length: 200_000 }, (_, i) => i);
let total = 0;
for (let round = 0; round < 5; round++) {
  const ys = xs.flatMap((x) => [x, x + 1]);
  total += ys.length + ys[ys.length - 1];
}
console.log(total);
