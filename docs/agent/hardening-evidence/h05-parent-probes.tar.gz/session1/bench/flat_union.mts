const mixed: (number | number[])[] = Array.from({ length: 200_000 }, (_, i) => (i % 2 ? i : [i, i]));
let total = 0;
for (let round = 0; round < 5; round++) {
  const flat = mixed.flat();
  total += flat.length + flat[flat.length - 1];
}
console.log(total);
