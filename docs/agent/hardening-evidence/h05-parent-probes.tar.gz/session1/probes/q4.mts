const values: number[] = [1, 2];
console.log(values.par.flatMap<number | number[]>((x) => (x === 1 ? x : [[x]])));
