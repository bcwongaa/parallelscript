const values: number[] = [1, 2];
console.log(values.flatMap((x) => [x, String(x)]));
console.log(values.flatMap((x) => [x, String(x)] as [number, string]));
const pairs: [string, number][] = [["a", 1], ["b", 2]];
console.log(pairs.flatMap((p) => [...p]));
console.log(pairs.flatMap((p) => [p[0], p[1]]));
console.log(values.flatMap((x) => (x > 1 ? ([x, "s"] as [number, string]) : x)));
