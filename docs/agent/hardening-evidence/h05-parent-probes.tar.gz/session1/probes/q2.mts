const holes = new Array<string>(3);
holes[1] = "b";
console.log(holes.flatMap((s) => [s, s]));
