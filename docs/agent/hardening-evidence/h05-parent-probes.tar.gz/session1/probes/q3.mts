const a: any = new Array(3);
a[1] = [1, , 2];
a[2] = "x";
console.log(a.flat(), a.flatMap((x: any) => x));
