interface HasLength { length: number }
const arr: number[] = [1, 2];
const h: HasLength = arr;
const xs: (HasLength | number)[] = [h, 3];
console.log(xs.flat());
