#!/bin/bash
# usage: t.sh file.pts [nonode] -- runs the current tree's CLI, the base CLI, and Node on a .mts copy
f=$1; d=$(dirname $f); b=$(basename $f .pts)
export PATH=$HOME/.local/node/bin:$PATH
echo "--- NEW"; (cd $d && PTS_HOME=/home/bryan/projects/parallelscript timeout 300 /home/bryan/projects/parallelscript/pts-bin/pts run $b.pts 2>&1; echo "exit=$?")
echo "--- BASE"; (cd $d && PTS_HOME=/tmp/h05-base timeout 120 /tmp/h05-base/pts-bin/pts run $b.pts 2>&1; echo "exit=$?")
if [ "$2" != nonode ]; then
cp $f $d/$b.mts; echo "--- NODE"; (cd $d && timeout 60 node --no-warnings --experimental-transform-types $b.mts 2>&1; echo "exit=$?")
fi
