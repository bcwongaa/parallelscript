import json,sys
res={};out={}
for l in open(sys.argv[1]):
    try: d=json.loads(l)
    except: continue
    t=d.get('Test')
    if not t: continue
    if d['Action'] in('pass','fail','skip'): res[t]=d['Action']
    if d['Action']=='output': out.setdefault(t,[]).append(d['Output'])
from collections import Counter
print(Counter(v for k,v in res.items() if '/' in k))
for t in sorted(res):
    if '/' in t and res[t]=='fail':
        o=''.join(out.get(t,[]))
        lines=[x for x in o.splitlines() if x.strip() and '---' not in x and '=== ' not in x]
        print('FAIL', t, ' | '.join(lines[:8])[:900])
