I found 8 problems in the snapshot. Five are regressions against the base and one adds a new false TypeError. The parent's suite (`/tmp/h05/suite1.jsonl`) is green, so no existing test catches any of them.

**How I ran things.** Your working tree changed after the snapshot: `pts_stack_check`, an `append_loaded` fast path, `ReadonlyArray<U>` in `parallel.pts` and `run/flat_cycles.pts`. I didn't review those edits. `pts run` builds the runtime from `PTS_HOME`, so every "new" run used a copy of the snapshot's runtime with the 01:27 snapshot CLI:
- new: `cd <dir> && PTS_HOME=/tmp/tmp.jUgch9FEbM/home /home/bryan/projects/parallelscript/pts-bin/pts run f.pts`
- base: `PTS_HOME=/tmp/h05-base /tmp/h05-base/pts-bin/pts run f.pts`
- Node: `node --no-warnings --experimental-transform-types f.mts`

The probes are under `/tmp/tmp.jUgch9FEbM/{p,x,b,d,c,u,e,m,l}/`. Everything below marked VERIFIED was run on all three.

## 1. HIGH, regression: `?.flat()` and `?.flatMap()` no longer compile (VERIFIED)
- **Where:**
  - `pts/lower/arrays.go:526-529`, `flat`
  - `pts/lower/callbacks.go:105-108`, `key.flattened`
- **Cause:** both take tsc's type at the call node. In an optional chain that type is `X[] | undefined`, so the `*ir.Array` assertion fails and the code returns nil without reporting anything.
- **Repro** (`p/oc1.pts`, `p/oc2.pts`):
```ts
const c = Math.random() < 2;
const maybe: number[][] | undefined = c ? [[3]] : undefined;
console.log(maybe?.flat());            // oc2: maybe?.flatMap((x) => x)
```
- **New:** `oc1.pts:3:13 - error PTS1001: call expression (which the compiler failed to lower without saying why) is not supported yet`
- **Base and Node:** `[ 3 ]`
- `b.items?.flat()` on an optional property fails the same way (`p/oc3.pts`; Node gives `[ 1, 2, 3 ] undefined`).
- **Fix:** strip the chain's `undefined`, for example by taking the resolved signature's return type, and report when the assertion fails.

## 2. MEDIUM, regression: unmatched regex groups are dropped as holes (VERIFIED)
- **Where:**
  - `array.c:915` (`is_hole` in `flatten_element`)
  - `array.c:975` (`pts_array_has`)
  - `dynamic_methods.c:625`
- **Cause:** match arrays and their copies store `undefined` as a zero word, which looks like a hole. `pts_has_undefined_holes()` already exists in `pts.h:1932` for this, but the new code doesn't use it.
- **Repro** (`x/x3.pts`):
```ts
const m = /(a)|(b)/.exec("b")!;
const anyM: any = m;
console.log(anyM.flatMap((g: any) => [g ?? "none"]));
console.log(anyM.flat());
```
- **New:** `[ 'b', 'b' ]` twice.
- **Base and Node:** `[ 'b', 'none', 'b' ]` and `[ 'b', undefined, 'b' ]`.
- **Typed `flatMap`** (`x/x2.pts`): `m.flatMap((g) => [g ?? "none"])` now silently gives `[ 'b', 'b' ]`. The base threw an honest TypeError ("group 1 of the match took no part in it"); Node gives `[ 'b', 'none', 'b' ]`.
- **`split` with capture groups** (`x/x3` original): `"a,b".split(/(,)|(;)/).flatMap(p => [p ?? "none"])` gives `[ 'a', ',', 'b' ]`; the base threw RangeError; Node gives `[ 'a', ',', 'none', 'b' ]`.
- **Pre-existing, base equally wrong:** typed `m.flat()` and `[m].flat()` (`x/x4.pts`).

## 3. MEDIUM, regression to SIGSEGV: cyclic arrays under `flat(Infinity)` (VERIFIED on the snapshot)
- **Where:** `array.c:944`. The recursive `flatten_into` has no `pts_stack_check()`.
- **Repro** (`d/cy1.pts`):
```ts
const a: any[] = [1];
a.push(a);
try { console.log(a.flat(Infinity).length); } catch (e) { console.log("caught", (e as Error).name); }
```
- **New:** exit 139.
- **Base:** `2` (wrong, but no crash).
- **Node:** `caught RangeError`.
- The same happens for `object[]` (`d/cy6`). Through `any` (`d/cy5`) the base segfaults too, so that path is pre-existing.
- Your in-progress tree adds the check and `flat_cycles.pts`; I haven't verified it.

## 4. MEDIUM, new false TypeError: i64/u64 values above 2^53 going into a `number` result (VERIFIED)
- **Where:** `array.c:893-913`. `kind_holds(NUMBER/F32)` rejects boxed INT64/UINT64, and `pts_store_value_in_slot` would not convert them anyway.
- **Rule broken:** the GUIDE says any integer converts implicitly to `number` and rounds.
- **Repro** (`b/i7.pts`, `b/i9.pts`):
```ts
const big: i64 = (1 as i64) << (62 as i64);
const xs: i64[] = [big];
const n: (number | i64[])[] = [1.5, xs];
console.log(n.flat());                                   // also [1.5].flatMap((v) => (v > 1 ? xs : v))
const asNumber: number = big; console.log(asNumber);     // 4611686018427388000
```
- **New:** `TypeError: Expected number, got int`, from both `flat` and `flatMap`. A u64 gives `Expected number, got u64`.
- **Base:** didn't throw (it didn't flatten).
- **Expected:** `[ 1.5, 4611686018427388000 ]`.

## 5. MEDIUM-LOW, compile regression: explicit union type arguments with two array members (VERIFIED)
- **Where:**
  - `unions.go:306` (`holdsAsItIs`)
  - `lower.go:3365` (`takesContextualUnion`)
- **Cause:** every array-literal branch now takes the contextual union. When the literal's element type is a union that is only a subset of an array member's element union, `holdsAsItIs` doesn't match it, and with two array members `holdingArray` returns nil.
- **Repro A** (`p/r6.pts`):
```ts
console.log([1, 2].map<number | number[] | (number | string | number[])[]>((x) => (x > 1 ? [String(x), x] : x)));
```
  - New: `PTS1001: converting (number | string)[] to (number | number[] | string)[] | number | number[] is not supported yet`
  - Base and Node: `[ 1, [ '2', 2 ] ]`
  - `p/r12.pts` (strings) behaves the same.
- **Repro B**, which is H05's own scope (`p/p3.pts`):
```ts
const values: number[] = [1, 2];
console.log(values.flatMap<number | string | number[]>((x) => (x > 1 ? [String(x), x] : x)));
```
  - New: PTS1001.
  - Base: wrong, `[ 1, [ '2', 2 ] ]`.
  - Node: `[ 1, '2', 2 ]`.
  - The `.par` form fails on both base and new.
- **Fix:** let a union whose members are all in `place`'s union count as held as it is, or fall back to the old path when `memberFor` fails.

## 6. LOW, C20 acceptance gaps (VERIFIED; pre-existing, not regressions)
C20 says `.par.flatMap` should accept the type arguments Array's `flatMap` does. Two cases still don't:
- `values.par.flatMap<number | number[]>(fn)`, where `fn(x: number): number | number[][]` is a named function (`p/fr.pts`). New: `converting number | number[][] to (number | number[])[] | number | number[] is not supported yet`. Array's `flatMap` with the same argument prints `[ 1, [ 2 ] ]` on new, matching Node.
- `values.par.flatMap<number | string>((x) => (x > 1 ? shared : x))`, where `shared` is an existing `number[]` (`p/s2.pts`). It's PTS1001, while Array's `flatMap` gives `[ 1, 7, 8 ]`.

The header of `run/parallel_flatmap_unions.pts` ("takes what Array's flatMap takes") overstates this.

## 7. LOW: `flatMap` with a tuple or array type argument (VERIFIED)
- `[1, 2].flatMap<[number, string]>((x) => [x, "a"])` (`p/tu1.pts`): new throws `TypeError: Expected object, got number`. The base silently printed `[ [ 1, 'a' ], [ 2, 'a' ] ]`. Node prints `4 [ 1, 'a', 2, 'a' ]`.
- `flatMap<number[]>` (`p/tu4.pts`) throws on both base and new.
- The kind check keeps this memory-safe. tsc's type is wrong here, as it is for odd depths, so a compile-time PTS1001 would be better.
- The message names the slot kind (`object`), not the type. It comes from `pts_check_declared(into, NULL)->name` at `array.c:927`.

## 8. LOW: diagnostics (VERIFIED)
- **Internal name leaks:** `xs.flat(a)` with `a: any` reports "`flat` with a depth of type value" (`arrays.go:560`).
- **Wrong fix advice:** for `depths: 1 | -2`, the message says "JS flattens as `flat(0)` does, so write that", which is wrong whenever the depth is 1. `errors/flat_odd_depths.pts` cuts off that expectation, so the advice isn't pinned.
- **`number | undefined` depths are PTS1001:** that covers the common `depth?: number` parameter, where JS treats undefined as 1.
- **Odd enum depths:** `cube.flat(E.Neg)` and `cube.flat(E.Half)` (`b/en.pts`) ran correctly on the base and are now PTS1001. That follows D-180's choice, but it's still a change.

## Checked and fine
- **Depths:**
  - 0, 1, 2, 25, Infinity, NaN.
  - `0 | 2` unions, `number` variables, `int` depths, enum members.
  - A generic `D extends number`, including an instance with -1, which is correctly reported.
  - Receiver-before-depth evaluation order.
  - Lying `as 1` / `as 2` depth casts throw a TypeError rather than crash.
- **Element types:** u8, i64 (2^62 kept exact), `(u8 | u8[])`, `(i64[] | u8[])`, and `int[][]`, whose result stays `int[]`.
- **Tuples:** optional elements and explicit `undefined`, rest elements (both forms), nested tuples, readonly tuples, frozen tuples and arrays.
- **Object types:** interface and class shapes in different layouts, subclasses, Set, Map, Uint8Array, functions, null.
- **`Iterable`/`object`/`{}` elements:** typed reads afterwards match JS.
- **Generics:** monomorphized cases.
- **`flatMap` callbacks mutating the source:** pushing, shrinking and filling a later hole all match Node on the typed and dynamic paths.
- **`.par.flatMap`:** 300k elements at 1/2/4 threads, run 3 times each (union results, holes, tuples, all matching Node). Ranges and typed arrays with union `U` work.
- **C20 closure adoption and conditional unions:** I tried user HOFs, `Promise.then`, `Promise.resolve`, `map`, `find ??`, `push`, `Map.set`, object literals, recursive named functions, interface arrays and integer contexts. No silent identity loss: D-094 still rejects kept or mutated copies (`c/keep*.pts`, `c/id*.pts`). Integer range errors stay PTS2002/PTS2001.
- **GC:** the runtime relies on bdwgc's conservative stack scan, so locals holding pointers during pushes are fine.
- **Performance:** callgrind shows new `flat` uses fewer instructions than the base (149M vs 207M).

## Missing tests
`?.flat()`/`?.flatMap()`, match arrays with unmatched groups, i64/u64 leaves into a number result, cycles (in progress), explicit union type arguments with two array members, and a `.par.flatMap` callback that is a named function.
