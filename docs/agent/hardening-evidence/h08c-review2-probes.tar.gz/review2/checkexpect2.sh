#!/bin/bash
# checkexpect2.sh file.pts...: Node's stdout vs the expect block's stdout lines; each `stderr:` line must appear in Node's stderr
for f in "$@"; do b=$(basename $f .pts); d=$(mktemp -d /tmp/h08c/review2/ce.XXXX); cp $f $d/$b.mts
  (cd $d && ~/.local/node/bin/node --no-warnings --experimental-transform-types $b.mts > out.txt 2> err.txt; echo "$?" > code.txt)
  sed -n '/^\/\/ expect:$/,$p' $f | tail -n +2 | sed 's#^// \?##' > $d/all.txt
  grep -v '^stderr: ' $d/all.txt > $d/exp.txt; grep '^stderr: ' $d/all.txt | sed 's/^stderr: //' > $d/experr.txt
  ok=1; cmp -s $d/exp.txt $d/out.txt || { ok=0; diff $d/exp.txt $d/out.txt | head; }
  while IFS= read -r line; do grep -qF -- "$line" $d/err.txt || { ok=0; echo "stderr lacks: $line"; }; done < $d/experr.txt
  echo "$b: $([ $ok = 1 ] && echo 'expect==node' || echo 'EXPECT DIFFERS') (exit $(cat $d/code.txt), stderr $(wc -l < $d/err.txt) lines)"
  rm -rf $d; done
