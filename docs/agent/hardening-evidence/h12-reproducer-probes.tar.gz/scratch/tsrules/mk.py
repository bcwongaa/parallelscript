import os
HERE = os.path.dirname(os.path.abspath(__file__))
P = {
    "decl_other": 'const src: { a?: number } = {};\nconst { a = "x" } = src;\nconsole.log(a);\n',
    "decl_other_exact": 'const { a = "x" } = { a: undefined };\nconsole.log(a);\n',
    "param_whole_unannotated_other": 'const src: { a?: number } = {};\nfunction f({ a = "x" } = src) { console.log(a); }\nf();\n',
    "param_whole_unannotated_exact": 'function f({ a = 10, b } = { a: undefined, b: 2 }) { console.log(a, b); }\nf();\n',
    "param_whole_unannotated_exact_call": 'function f({ a = 10, b } = { a: undefined, b: 2 }) { console.log(a, b); }\nf({ a: undefined, b: 3 });\n',
    "catch_any": 'try { throw { b: 2 }; } catch ({ a = 10, b }: any) { console.log(a, b); }\n',
    "catch_unknown_arr": 'try { throw [2]; } catch ([b, a = 10]: any) { console.log(a, b); }\n',
    "forof_typed_exact": 'const items: Array<{ a: undefined; b: number }> = [{ a: undefined, b: 2 }];\nfor (const { a = 10, b } of items) console.log(a, b);\n',
    "assign_other": 'const src: { a?: number } = {};\nlet a: number | string;\n({ a = "x" } = src);\nconsole.log(a);\n',
    "arr_param_unannotated_whole": 'function f([b, a = 10] = [2, undefined]) { console.log(a, b); }\nf();\n',
    "arr_param_unannotated_whole_typed": 'const src: [number, undefined] = [2, undefined];\nfunction f([b, a = "x"] = src) { console.log(a, b); }\nf();\n',
}
for k, v in P.items():
    open(os.path.join(HERE, k + ".pts"), "w").write(v)
