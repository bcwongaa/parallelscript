import os
HERE = os.path.dirname(os.path.abspath(__file__))
P = {
    "v1_undef_literal": 'const t: [[number | undefined] | undefined, string] = [undefined, "s"];\nconst [[x = 7] = [undefined], y] = t;\nconsole.log(x, y);\n',
    "v2_number_literal": 'const t: [[number | undefined] | undefined, string] = [undefined, "s"];\nconst [[x = 7] = [5], y] = t;\nconsole.log(x, y);\n',
    "v3_typed_default": 'const t: [[number | undefined] | undefined, string] = [undefined, "s"];\nconst dflt: [number | undefined] = [undefined];\nconst [[x = 7] = dflt, y] = t;\nconsole.log(x, y);\n',
    "v4_object_outer": 'const t: { p?: [number | undefined] } = {};\nconst { p: [x = 7] = [undefined] } = t;\nconsole.log(x);\n',
    "v5_obj_in_tuple": 'const t: [{ k?: number } | undefined, string] = [undefined, "s"];\nconst [{ k = 7 } = {}, y] = t;\nconsole.log(k, y);\n',
    "v6_plain_nested_tuple_union": 'const t: [[number] | undefined] = [undefined];\nconst [[x] = [3]] = t;\nconsole.log(x);\n',
    "v7_assign": 'const t: [[number | undefined] | undefined, string] = [undefined, "s"];\nlet x: number, y: string;\n[[x = 7] = [undefined], y] = t;\nconsole.log(x, y);\n',
}
for k, v in P.items():
    open(os.path.join(HERE, k + ".pts"), "w").write(v)
