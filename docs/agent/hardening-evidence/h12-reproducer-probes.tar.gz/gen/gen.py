#!/usr/bin/env python3
"""H12 differential matrix generator (destructuring defaults).

usage: gen.py --seed 12 --out DIR

Writes DIR/<id>.pts and DIR/cases.jsonl. Deterministic for a seed: the grids are full cross
products and the extra sample uses random.Random(seed). Families:
  obj.*    object patterns: source x context x default (grids A, B, C + sample)
  arr.*    array patterns:  source x context x default (grids A, B, C + sample)
  nest.*   nested patterns (object in array, array in object, deeper, rests) x context
  order.*  evaluation order and side effects (hand-written)
  param.*  parameter defaults reading earlier parameters (C306 family)
  c307.*   array defaults of another type, nested tuple defaults, default before a rest
  bind.*   annotated bindings, generic instances, numeric ParallelScript types (no-node)
Each case records expect = "node" or "by design: <decision>: <why>".
"""
import argparse, itertools, json, os, random

HEADER = """const log: string[] = [];
function d<T>(tag: string, v: T): T { log.push("d:" + tag); return v; }
"""
TRAILER = 'console.log("log:", log.join(","));\n'

# ------------------------------------------------------------------ object sources
# key: (setup, expr, ts, a_core, b_ts)
# a_core: the property's type without undefined ("never" when it is exactly undefined)
OBJ_SOURCES = {
    "lit_undef": ("", "{ a: undefined, b: 2 }", "{ a: undefined; b: number }", "never", "number"),
    "lit_void0": ("", "{ a: void 0, b: 2 }", "{ a: undefined; b: number }", "never", "number"),
    "decl_undef": ("const src: { a: undefined; b: number } = { a: undefined, b: 2 };", "src", "{ a: undefined; b: number }", "never", "number"),
    "inferred_undef": ("const src = { a: undefined, b: 2 };", "src", "typeof src", "never", "number"),
    "opt_absent": ("const src: { a?: number; b: number } = { b: 2 };", "src", "{ a?: number; b: number }", "number", "number"),
    "opt_undef": ("const src: { a?: number; b: number } = { a: undefined, b: 2 };", "src", "{ a?: number; b: number }", "number", "number"),
    "opt_present": ("const src: { a?: number; b: number } = { a: 3, b: 2 };", "src", "{ a?: number; b: number }", "number", "number"),
    "union_undef": ("const src: { a: number | undefined; b: number } = { a: undefined, b: 2 };", "src", "{ a: number | undefined; b: number }", "number", "number"),
    "union_present": ("const src: { a: number | undefined; b: number } = { a: 3, b: 2 };", "src", "{ a: number | undefined; b: number }", "number", "number"),
    "null_val": ("const src: { a: number | null; b: number } = { a: null, b: 2 };", "src", "{ a: number | null; b: number }", "number | null", "number"),
    "opt_null": ("const src: { a?: number | null; b: number } = { a: null, b: 2 };", "src", "{ a?: number | null; b: number }", "number | null", "number"),
    "str_opt_absent": ("const src: { a?: string; b: number } = { b: 2 };", "src", "{ a?: string; b: number }", "string", "number"),
    "obj_opt_absent": ("const src: { a?: { k: number }; b: number } = { b: 2 };", "src", "{ a?: { k: number }; b: number }", "{ k: number }", "number"),
    "class_field_union": ("class C1 { a: number | undefined = undefined; b = 2; }", "new C1()", "C1", "number", "number"),
    "class_field_exact": ("class C2 { a: undefined = undefined; b = 2; }", "new C2()", "C2", "never", "number"),
    "class_unset_opt": ("class C3 { a?: number; b = 2; }", "new C3()", "C3", "number", "number"),
    "class_getter_union": ('class C4 { get a(): number | undefined { log.push("get a"); return undefined; } b = 2; }', "new C4()", "C4", "number", "number"),
    "class_getter_exact": ('class C5 { get a() { log.push("get a"); return undefined; } b = 2; }', "new C5()", "C5", "never", "number"),
    "iface_opt_lit": ("interface I1 { a?: number; b: number }\nconst src: I1 = { b: 2 };", "src", "I1", "number", "number"),
    "iface_from_class": ("interface I2 { a?: number; b: number }\nclass K2 implements I2 { b = 2; }\nconst src: I2 = new K2();", "src", "I2", "number", "number"),
    "iface_union_from_class": ("interface I3 { a: number | undefined; b: number }\nclass K3 implements I3 { a: number | undefined = undefined; b = 2; }\nconst src: I3 = new K3();", "src", "I3", "number", "number"),
    "any_missing": ("const src: any = { b: 2 };", "src", "any", "any", "any"),
    "any_undef": ("const src: any = { a: undefined, b: 2 };", "src", "any", "any", "any"),
    "json_any": ("const src = JSON.parse('{\"b\":2}');", "src", "any", "any", "any"),
    "unknown_guard": ('function isR(u: unknown): u is { a?: number; b: number } { return typeof u === "object" && u !== null; }\nconst raw: unknown = { b: 2 };\nif (!isR(raw)) throw new Error("no");\nconst src = raw;', "src", "{ a?: number; b: number }", "number", "number"),
    "partial": ("const src: Partial<{ a: number; b: number }> = { b: 2 };", "src", "Partial<{ a: number; b: number }>", "number", "number | undefined"),
    "record_union_missing": ("const src: Record<string, number | undefined> = { b: 2 };", "src", "Record<string, number | undefined>", "number", "number | undefined"),
    "record_union_undef": ("const src: Record<string, number | undefined> = { a: undefined, b: 2 };", "src", "Record<string, number | undefined>", "number", "number | undefined"),
    "record_plain_missing": ("const src: Record<string, number> = { b: 2 };", "src", "Record<string, number>", "number", "number"),
    "fn_result": ('function mk(): { a?: number; b: number } { log.push("mk"); return { b: 2 }; }', "mk()", "{ a?: number; b: number }", "number", "number"),
    "fn_result_exact": ('function mk() { log.push("mk"); return { a: undefined, b: 2 }; }', "mk()", "ReturnType<typeof mk>", "never", "number"),
}

# ------------------------------------------------------------------ array sources
# pattern [b, a = D]: b is element 0, a element 1
ARR_SOURCES = {
    "lit_undef": ("", "[2, undefined]", "[number, undefined]", "never", "number"),
    "lit_void0": ("", "[2, void 0]", "[number, undefined]", "never", "number"),
    "tuple_exact": ("const src: [number, undefined] = [2, undefined];", "src", "[number, undefined]", "never", "number"),
    "tuple_opt_absent": ("const src: [number, number?] = [2];", "src", "[number, number?]", "number", "number"),
    "tuple_opt_undef": ("const src: [number, number?] = [2, undefined];", "src", "[number, number?]", "number", "number"),
    "tuple_union_undef": ("const src: [number, number | undefined] = [2, undefined];", "src", "[number, number | undefined]", "number", "number"),
    "tuple_union_present": ("const src: [number, number | undefined] = [2, 3];", "src", "[number, number | undefined]", "number", "number"),
    "tuple_null": ("const src: [number, number | null] = [2, null];", "src", "[number, number | null]", "number | null", "number"),
    "tuple_str_opt": ("const src: [number, string?] = [2];", "src", "[number, string?]", "string", "number"),
    "readonly_const": ("const src = [2, undefined] as const;", "src", "readonly [2, undefined]", "never", "2"),
    "num_arr_short": ("const src: number[] = [2];", "src", "number[]", "number", "number"),
    "num_arr_present": ("const src: number[] = [2, 3];", "src", "number[]", "number", "number"),
    "num_arr_hole": ("const src: number[] = new Array<number>(2);\nsrc[0] = 2;", "src", "number[]", "number", "number"),
    "bool_arr_short": ("const src: boolean[] = [true];", "src", "boolean[]", "boolean", "boolean"),
    "str_arr_short": ('const src: string[] = ["s"];', "src", "string[]", "string", "string"),
    "str_arr_hole": ('const src: string[] = new Array<string>(2);\nsrc[0] = "s";', "src", "string[]", "string", "string"),
    "obj_arr_short": ("const src: { k: number }[] = [{ k: 2 }];", "src", "{ k: number }[]", "{ k: number }", "{ k: number }"),
    "maybe_arr_undef": ("const src: (number | undefined)[] = [2, undefined];", "src", "(number | undefined)[]", "number", "number | undefined"),
    "maybe_arr_short": ("const src: (number | undefined)[] = [2];", "src", "(number | undefined)[]", "number", "number | undefined"),
    "rest_tuple": ("const src: [number, ...number[]] = [2];", "src", "[number, ...number[]]", "number", "number"),
    "rest_tuple_mixed": ("const src: [number, ...string[]] = [2];", "src", "[number, ...string[]]", "string", "number"),
    "any_val": ("const src: any = [2];", "src", "any", "any", "any"),
    "any_arr_undef": ("const src: any[] = [2, undefined];", "src", "any[]", "any", "any"),
    "unknown_arr": ("const src: unknown[] = [2];", "src", "unknown[]", "unknown", "unknown"),
    "map_entry": ("const m = new Map<number, number | undefined>([[2, undefined]]);\nconst src = [...m][0];", "src", "[number, number | undefined]", "number", "number"),
    "generator": ('function* gen(): Generator<number | undefined> {\n  try { log.push("n0"); yield 2; log.push("n1"); yield undefined; log.push("n2"); yield 9; } finally { log.push("closed"); }\n}', "gen()", "Iterable<number | undefined>", "number", "number | undefined"),
    "iterable_class": ('class It implements Iterable<number | undefined> {\n  *[Symbol.iterator](): Generator<number | undefined> { log.push("i0"); yield 2; log.push("i1"); yield undefined; log.push("i2"); }\n}', "new It()", "It", "number", "number | undefined"),
    "set_src": ("", "new Set<number | undefined>([2, undefined])", "Set<number | undefined>", "number", "number | undefined"),
    "string_src": ('const src: string = "x";', "src", "string", "string", "string"),
    "fn_result": ('function mk(): (number | undefined)[] { log.push("mk"); return [2]; }', "mk()", "(number | undefined)[]", "number", "number | undefined"),
    "typed_array": ("const src = new Float64Array([2]);", "src", "Float64Array", "number", "number"),
}

SAME = {"never": ("10", "number"), "number": ("10", "number"), "string": ('"s"', "string"), "boolean": ("false", "boolean"),
        "{ k: number }": ("{ k: 5 }", "{ k: number }"), "any": ("10", "number"), "unknown": ("10", "number"),
        "number | null": ("10", "number"), "2": ("10", "number")}
OTHER = {"number": ('"dflt"', "string"), "never": ('"dflt"', "string"), "string": ("10", "number"), "boolean": ('"dflt"', "string"),
         "{ k: number }": ("10", "number"), "any": ('"dflt"', "string"), "unknown": ('"dflt"', "string"), "number | null": ('"dflt"', "string")}

DEFAULTS = ["same", "other", "undef", "side", "earlier", "closure", "null", "object", "any", "unknown"]
CONTEXTS = ["const_mod", "let_fn", "assign_stmt", "assign_value", "assign_member", "assign_elem", "param", "param_whole_default",
            "arrow", "method", "ctor", "forof", "forof_assign", "catch", "generator", "async"]


def default_expr(kind, a_core):
    """(expression, its TS type, whether the pattern lists b first)"""
    same, same_t = SAME[a_core]
    if kind == "same":
        return same, same_t, False
    if kind == "other":
        o, ot = OTHER[a_core]
        return o, ot, False
    if kind == "undef":
        return "undefined", "undefined", False
    if kind == "side":
        return f'd("a", {same})', same_t, False
    if kind == "earlier":
        return "Number(b) * 2", "number", True
    if kind == "closure":
        # the closure's result type is written: tsc can't infer it through the pattern (TS7024)
        return f'((): {same_t} => {{ log.push("c" + String(b)); return {same}; }})()', same_t, True
    if kind == "null":
        return "null", "null", False
    if kind == "object":
        return "{ k: 1 }", "{ k: number }", False
    if kind == "any":
        return "anyTen", "any", False
    if kind == "unknown":
        return "unk", "unknown", False
    raise ValueError(kind)


def union_type(a_core, dtype):
    if a_core == "any" or dtype == "any":
        return "any"
    if a_core == "unknown" or dtype == "unknown":
        return "unknown"
    parts = []
    for t in ([] if a_core == "never" else [x.strip() for x in a_core.split("|")]) + [dtype]:
        if t not in parts:
            parts.append(t)
    return " | ".join(parts)


def init_for(at):
    if at in ("any", "unknown") or "number" in at.split(" | "):
        return "-1"
    parts = at.split(" | ")
    if "string" in parts:
        return '"init"'
    if "boolean" in parts:
        return "true"
    if "undefined" in parts:
        return "undefined"
    if "null" in parts:
        return "null"
    if "{ k: number }" in parts:
        return "{ k: -1 }"
    if "2" in parts:
        return "2"
    raise ValueError(at)


# sources whose tested part's declared type has no undefined (an `undefined` default isn't
# assignable to it in an annotated parameter)
NO_UNDEFINED = {"obj": {"null_val", "record_plain_missing"},
                "arr": {"tuple_null", "num_arr_short", "num_arr_present", "num_arr_hole", "bool_arr_short", "str_arr_short",
                        "str_arr_hole", "obj_arr_short", "rest_tuple", "rest_tuple_mixed", "string_src", "typed_array"}}
ANNOTATED_PARAMS = {"param", "arrow", "method", "ctor", "generator", "async"}


def valid_in_annotated_param(kind, src, a_core, dflt):
    """Whether tsc accepts the default against the parameter's declared part type (TS2322 otherwise)."""
    if a_core == "never":
        return dflt == "undef"  # tsc checks a default against the part's type without undefined: never
    if a_core in ("any", "unknown") or dflt == "any":
        return True
    parts = [x.strip() for x in a_core.split("|")]
    if dflt == "undef":
        return src not in NO_UNDEFINED[kind]
    if dflt in ("same", "side", "closure"):
        return a_core != "never"
    if dflt == "earlier":
        return "number" in parts
    if dflt == "null":
        return "null" in parts
    if dflt == "object":
        return "{ k: number }" in parts
    return False  # other, unknown


def init_b(bt):
    return {"number": "0", "number | undefined": "0", "any": "0", "string": '""', "boolean": "false",
            "{ k: number }": "{ k: 0 }", "unknown": "0", "2": "2"}[bt]


def pattern_case(kind, src, ctx, dflt):
    """kind 'obj' or 'arr'; returns (program, expect), or None where the case isn't valid TypeScript."""
    setup, expr, ts, a_core, b_ts = (OBJ_SOURCES if kind == "obj" else ARR_SOURCES)[src]
    if ctx in ANNOTATED_PARAMS and not valid_in_annotated_param(kind, src, a_core, dflt):
        return None
    dexpr, dtype, b_first = default_expr(dflt, a_core)
    at = union_type(a_core, dtype)
    bt = f"{b_ts} = {init_b(b_ts)}"  # initialised: tsc doesn't count a pattern's earlier assignment for its later default
    extra = ""
    if dflt == "any":
        extra += "const anyTen: any = 10;\n"
    if dflt == "unknown":
        extra += 'const unk: unknown = "u";\n'

    def pat(a_target):
        if kind == "obj":
            a_el = f"a = {dexpr}" if a_target == "a" else f"a: {a_target} = {dexpr}"
            return "{ b, " + a_el + " }" if b_first else "{ " + a_el + ", b }"
        return f"[b, {a_target} = {dexpr}]"

    p = pat("a")
    show = "console.log(a, b);"
    body = ""
    trailer = TRAILER
    if ctx == "const_mod":
        body = f"const {p} = {expr};\n{show}\n"
    elif ctx == "let_fn":
        body = f"function run() {{\n  let {p} = {expr};\n  {show}\n}}\nrun();\n"
    elif ctx == "assign_stmt":
        body = f"let a: {at};\nlet b: {bt};\n({p} = {expr});\n{show}\n" if kind == "obj" else f"let a: {at};\nlet b: {bt};\n{p} = {expr};\n{show}\n"
    elif ctx == "assign_value":
        tail = "r.b" if kind == "obj" else "typeof r"
        body = f"let a: {at};\nlet b: {bt};\nconst r = ({p} = {expr});\nconsole.log(a, b, {tail});\n"
    elif ctx == "assign_member":
        pm = pat("o.x")
        stmt = f"({pm} = {expr});" if kind == "obj" else f"{pm} = {expr};"
        body = f"const o: {{ x: {at} }} = {{ x: {init_for(at)} }};\nlet b: {bt};\n{stmt}\nconsole.log(o.x, b);\n"
    elif ctx == "assign_elem":
        pm = pat("arr[0]")
        stmt = f"({pm} = {expr});" if kind == "obj" else f"{pm} = {expr};"
        body = f"const arr: Array<{at}> = [{init_for(at)}];\nlet b: {bt};\n{stmt}\nconsole.log(arr[0], b);\n"
    elif ctx == "param":
        body = f"function f({p}: {ts}) {{\n  {show}\n}}\nf({expr});\n"
    elif ctx == "param_whole_default":  # unannotated: tsc types the parameter from its default, as a declaration
        body = f"function f({p} = {expr}) {{\n  {show}\n}}\nf();\n"
    elif ctx == "arrow":
        body = f"const f = ({p}: {ts}) => {{\n  {show}\n}};\nf({expr});\n"
    elif ctx == "method":
        body = f"class M {{\n  m({p}: {ts}) {{\n    {show}\n  }}\n}}\nnew M().m({expr});\n"
    elif ctx == "ctor":
        body = f"class M {{\n  constructor({p}: {ts}) {{\n    {show}\n  }}\n}}\nnew M({expr});\n"
    elif ctx == "forof":  # a typed array keeps the source's own type (a literal in `[...]` would widen)
        body = f"const items: Array<{ts}> = [{expr}];\nfor (const {p} of items) {{\n  {show}\n}}\n"
    elif ctx == "forof_assign":
        body = f"const items: Array<{ts}> = [{expr}];\nlet a: {at};\nlet b: {bt};\nfor ({p} of items) {{\n  {show}\n}}\n"
    elif ctx == "catch":
        body = f"try {{\n  throw {expr};\n}} catch ({p}: any) {{\n  {show}\n}}\n"
    elif ctx == "generator":
        body = f"function* g({p}: {ts}) {{\n  yield a;\n  yield b;\n}}\nconsole.log([...g({expr})]);\n"
    elif ctx == "async":
        body = (f"async function f({p}: {ts}) {{\n  await null;\n  return [a, b];\n}}\n"
                f"f({expr}).then((r) => {{\n  console.log(r[0], r[1]);\n  {TRAILER.strip()}\n}});\n")
        trailer = ""
    else:
        raise ValueError(ctx)
    prog = HEADER + extra + (setup + "\n" if setup else "") + body + trailer
    expect = "node"
    if kind == "arr" and src == "num_arr_hole":
        expect = "by design: D-085: an array of numbers has no holes; its unset slot reads 0, where JS reads undefined and applies the default"
    elif ctx == "catch":
        expect = "out of scope: destructuring a caught exception is PTS1001 (exceptions.go), not a default's"
    elif ctx == "forof_assign":
        expect = "out of scope: `for…of` without a declaration of its variable is PTS1001, not a default's"
    elif ctx in ANNOTATED_PARAMS and dflt == "any" and a_core not in ("any", "unknown") and "number" not in a_core.split(" | "):
        expect = "by design: D-070: the any default (10) enters a part typed " + (a_core if a_core != "never" else "undefined") + " and is checked (TypeError), where JS keeps 10"
    return prog, expect


# ------------------------------------------------------------------ nested patterns
NESTED = [
    # (key, pattern, ts, sources[(key, expr)], leaves {name: type}, shows)
    ("obj_in_obj", "{ a: { b = 1 } = {} }", "{ a?: { b?: number } }",
     [("empty", "{}"), ("a_undef", "{ a: undefined }"), ("b_undef", "{ a: { b: undefined } }"), ("b5", "{ a: { b: 5 } }"), ("a_empty", "{ a: {} }")],
     {"b": "number"}, "b"),
    ("obj_in_obj_default_value", "{ a: { b = 1 } = { b: 2 } }", "{ a?: { b?: number } }",
     [("empty", "{}"), ("a_empty", "{ a: {} }")], {"b": "number"}, "b"),
    ("arr_in_obj", "{ a: [x = 1, y = 2] = [] }", "{ a?: (number | undefined)[] }",
     [("empty", "{}"), ("holes", "{ a: [undefined, 3] }"), ("short", "{ a: [4] }")], {"x": "number", "y": "number"}, "x, y"),
    ("obj_and_arr_in_arr", "[{ k = 1 } = {}, [m = 2] = []]", "[{ k?: number }?, (number | undefined)[]?]",
     [("empty", "[]"), ("undefs", "[undefined, undefined]"), ("inner_undef", "[{}, [undefined]]"), ("given", "[{ k: 5 }, [6]]")],
     {"k": "number", "m": "number"}, "k, m"),
    ("deep_obj", "{ a: { b: { c = 3 } = {} } = {} }", "{ a?: { b?: { c?: number } } }",
     [("empty", "{}"), ("a_empty", "{ a: {} }"), ("b_empty", "{ a: { b: {} } }"), ("c9", "{ a: { b: { c: 9 } } }")], {"c": "number"}, "c"),
    ("tuple_in_tuple", "[x, [y, z = 9]]", "[number, [string, number?]]",
     [("short", '[1, ["s"]]'), ("undef", '[1, ["s", undefined]]'), ("given", '[1, ["s", 4]]')], {"x": "number", "y": "string", "z": "number"}, "x, y, z"),
    ("tuple_default_nested", "[[x = 7] = [undefined], y]", "[[number | undefined] | undefined, string]",
     [("outer_undef", '[undefined, "s"]'), ("inner_undef", '[[undefined], "s"]'), ("given", '[[3], "s"]')], {"x": "number", "y": "string"}, "x, y"),
    ("obj_rest", "{ a = 1, ...rest }", "{ a?: number; b: number; c: string }",
     [("absent", '{ b: 2, c: "c" }'), ("undef", '{ a: undefined, b: 2, c: "c" }'), ("given", '{ a: 5, b: 2, c: "c" }')],
     {"a": "number", "rest": "{ b: number; c: string }"}, "a, rest"),
    ("arr_rest", "[a = 1, ...rest]", "(number | undefined)[]",
     [("empty", "[]"), ("undef", "[undefined, 2]"), ("given", "[5, undefined, 3]")], {"a": "number", "rest": "(number | undefined)[]"}, "a, rest"),
    ("rest_tuple_default", '[h, i = "d", ...rest]', "[number, ...string[]]",
     [("short", "[1]"), ("long", '[1, "x", "y"]')], {"h": "number", "i": "string", "rest": "string[]"}, "h, i, rest"),
    ("rest_tuple_union_default", "[a = 5, ...rest]", "[number | undefined, ...string[]]",
     [("undef", '[undefined, "r1"]'), ("given", '[3, "r1", "r2"]')], {"a": "number", "rest": "string[]"}, "a, rest"),
    ("arr_obj_in_obj", "{ list: [{ v = 0 } = {}] = [] }", "{ list?: ({ v?: number } | undefined)[] }",
     [("empty", "{}"), ("empty_list", "{ list: [] }"), ("empty_obj", "{ list: [{}] }"), ("given", "{ list: [{ v: 3 }] }")], {"v": "number"}, "v"),
    ("exact_outer", "{ a: { b = 1 } = {} }", None, [("lit", "{ a: undefined }")], {"b": "number"}, "b"),
    ("exact_inner", "{ a: { b = 1 } }", None, [("lit", "{ a: { b: undefined } }")], {"b": "number"}, "b"),
    ("exact_arr_arr", "[[a = 1]]", None, [("lit", "[[undefined]]")], {"a": "number"}, "a"),
    ("exact_arr_in_obj", "{ a: [b = 1] }", None, [("lit", "{ a: [undefined] }")], {"b": "number"}, "b"),
    ("exact_obj_in_arr", "[{ a = 1 }]", None, [("lit", "[{ a: undefined }]")], {"a": "number"}, "a"),
    ("exact_obj_in_obj_two", "{ p: { a = 1, b = 2 } }", None, [("lit", "{ p: { a: undefined, b: undefined } }")], {"a": "number", "b": "number"}, "a, b"),
]
NEST_CONTEXTS = ["const_mod", "let_fn", "param", "param_whole_default", "assign", "forof"]


def to_assignment(pattern):
    """`{ a: { b = 1 } = {} }` as an assignment pattern is the same text; `...rest` too."""
    return pattern


def nested_case(key, pattern, ts, src_expr, leaves, shows, ctx):
    """With a type, the source is a typed variable `src`; without one (exact undefined), the literal itself."""
    show = f"console.log({shows});"
    setup = ""
    if ts is not None:
        setup = f"const src: {ts} = {src_expr};\n"
        src_expr = "src"
    if ctx == "const_mod":
        body = f"const {pattern} = {src_expr};\n{show}\n"
    elif ctx == "let_fn":
        body = f"function run() {{\n  let {pattern} = {src_expr};\n  {show}\n}}\nrun();\n"
    elif ctx == "param":
        if ts is None:
            return None
        body = f"function f({pattern}: {ts}) {{\n  {show}\n}}\nf({src_expr});\n"
    elif ctx == "param_whole_default":
        t = f": {ts}" if ts else ""
        body = f"function f({pattern}{t} = {src_expr}) {{\n  {show}\n}}\nf();\n"
    elif ctx == "assign":
        decls = "".join(f"let {n}: {t};\n" for n, t in leaves.items())
        stmt = f"({pattern} = {src_expr});" if pattern.startswith("{") else f"{pattern} = {src_expr};"
        body = f"{decls}{stmt}\n{show}\n"
    elif ctx == "forof":
        body = f"for (const {pattern} of [{src_expr}]) {{\n  {show}\n}}\n"
    return HEADER + setup + body + TRAILER


def nested_cases():
    out = []
    for key, pattern, ts, sources, leaves, shows in NESTED:
        for skey, sexpr in sources:
            for ctx in NEST_CONTEXTS:
                prog = nested_case(key, pattern, ts, sexpr, leaves, shows, ctx)
                if prog is not None:
                    out.append((f"nest.{key}.{skey}.{ctx}", "nest", prog, "node"))
    return out


# ------------------------------------------------------------------ evaluation order (hand-written)
ORDER = {
    "getters_once_in_order": """
class G {
  get x(): number | undefined { log.push("get x"); return undefined; }
  get y(): number | undefined { log.push("get y"); return 2; }
  get z(): number | undefined { log.push("get z"); return undefined; }
}
const { z = d("z", 3), x = d("x", 1), y = d("y", 9) } = new G();
console.log(x, y, z);
""",
    "getters_exact_undefined_literal_var": """
const src = { get a() { log.push("get a"); return undefined; }, get b() { log.push("get b"); return 2; } };
const { a = d("a", 1), b = d("b", 2) } = src;
console.log(a, b);
""",
    "getters_exact_undefined_inline": """
const { a = d("a", 1), b = d("b", 2) } = { get a() { log.push("get a"); return undefined; }, get b() { log.push("get b"); return 2; } };
console.log(a, b);
""",
    "default_only_when_undefined": """
const src: { a?: number; b?: number; c?: number | null } = { a: 0, c: null };
const { a = d("a", 1), b = d("b", 2), c = d("c", 3) } = src;
console.log(a, b, c);
""",
    "defaults_left_to_right_exact": """
const { p = d("p", 1), q = d("q", 2), r = d("r", 3) } = { p: undefined, q: undefined, r: undefined };
console.log(p, q, r);
""",
    "default_after_earlier_reads_class": """
class S {
  get a(): number | undefined { log.push("get a"); return undefined; }
  get b(): number { log.push("get b"); return 2; }
}
const { b, a = d("a", b * 10) } = new S();
console.log(a, b);
""",
    "default_mutates_source": """
const src: { a?: number; b: number } = { b: 2 };
const { a = (src.b = 5, 1), b } = src;
console.log(a, b);
""",
    "default_mutates_source_exact": """
const src = { a: undefined, b: 2 };
const { a = (src.b = 5, 1), b } = src;
console.log(a, b);
""",
    "source_evaluated_once": """
function mk(): { a?: number; b?: number } { log.push("mk"); return {}; }
const { a = d("a", 1), b = d("b", 2) } = mk();
console.log(a, b);
""",
    "source_evaluated_once_exact": """
function mk() { log.push("mk"); return { a: undefined, b: undefined }; }
const { a = d("a", 1), b = d("b", 2) } = mk();
console.log(a, b);
""",
    "iterator_interleaving_generator": """
function* gen(): Generator<number | undefined> {
  try {
    log.push("n0"); yield undefined;
    log.push("n1"); yield 2;
    log.push("n2"); yield undefined;
    log.push("n3"); yield 4;
  } finally { log.push("closed"); }
}
const [a = d("a", 1), b = d("b", 9), c = d("c", 3)] = gen();
console.log(a, b, c);
""",
    "iterator_interleaving_done_early": """
function* gen(): Generator<number | undefined> {
  log.push("n0"); yield undefined;
  log.push("end");
}
const [a = d("a", 1), b = d("b", 2), c = d("c", 3)] = gen();
console.log(a, b, c);
""",
    "iterator_interleaving_assignment": """
function* gen(): Generator<number | undefined> {
  try { log.push("n0"); yield undefined; log.push("n1"); yield undefined; } finally { log.push("closed"); }
}
let a: number, b: number;
[a = d("a", 1), b = d("b", 2)] = gen();
console.log(a, b);
""",
    "iterator_interleaving_param": """
function* gen(): Generator<number | undefined> {
  try { log.push("n0"); yield undefined; log.push("n1"); yield 5; } finally { log.push("closed"); }
}
function f([a = d("a", 1), b = d("b", 2)]: Iterable<number | undefined>) { console.log(a, b); }
f(gen());
""",
    "iterator_interleaving_forof": """
function* gen(): Generator<number | undefined> {
  try { log.push("n0"); yield undefined; log.push("n1"); yield undefined; } finally { log.push("closed"); }
}
for (const [a = d("a", 1), b = d("b", 2)] of [gen()]) console.log(a, b);
""",
    "iterator_throwing_default_closes": """
function* gen(): Generator<number | undefined> {
  try { log.push("n0"); yield undefined; log.push("n1"); yield undefined; } finally { log.push("closed"); }
}
function boom(): number { log.push("boom"); throw new Error("boom"); }
try {
  const [a = boom(), b = d("b", 2)] = gen();
  console.log(a, b);
} catch (e) {
  console.log("caught", (e as Error).message);
}
""",
    "throwing_default_stops_object": """
function boom(): number { log.push("boom"); throw new Error("boom"); }
try {
  const { a = boom(), b = d("b", 2) } = { a: undefined, b: undefined };
  console.log(a, b);
} catch (e) {
  console.log("caught", (e as Error).message);
}
""",
    "throwing_default_stops_object_union": """
function boom(): number { log.push("boom"); throw new Error("boom"); }
const src: { a?: number; b?: number } = {};
try {
  const { a = boom(), b = d("b", 2) } = src;
  console.log(a, b);
} catch (e) {
  console.log("caught", (e as Error).message);
}
""",
    "computed_key_before_read": """
function k<K extends string>(s: K): K { log.push("key " + s); return s; }
const src: { a?: number; b?: number } = { b: 2 };
const { [k("a")]: a = d("a", 1), [k("b")]: b = d("b", 3) } = src;
console.log(a, b);
""",
    "assign_member_target_before_read_object": """
class O {
  get a(): number | undefined { log.push("get a"); return undefined; }
}
const box = { x: 0 };
function target() { log.push("target"); return box; }
({ a: target().x = d("a", 1) } = new O());
console.log(box.x);
""",
    "assign_member_target_before_read_object_exact": """
const box = { x: 0 };
function target() { log.push("target"); return box; }
({ a: target().x = d("a", 1) } = { a: undefined });
console.log(box.x);
""",
    "assign_member_target_before_next": """
function* gen(): Generator<number | undefined> {
  try { log.push("n0"); yield undefined; log.push("n1"); yield 5; } finally { log.push("closed"); }
}
const box = { x: 0, y: 0 };
function target(t: string) { log.push("target " + t); return box; }
[target("x").x = d("x", 1), target("y").y = d("y", 2)] = gen();
console.log(box.x, box.y);
""",
    "assign_member_target_before_element_array": """
const box = { x: 0, y: 0 };
function target(t: string) { log.push("target " + t); return box; }
const src: (number | undefined)[] = [undefined];
[target("x").x = d("x", 1), target("y").y = d("y", 2)] = src;
console.log(box.x, box.y);
""",
    "assign_element_key_before_read": """
const arr = [0, 0];
function idx(i: number) { log.push("idx " + i); return i; }
const src: { a?: number; b?: number } = { b: 7 };
({ a: arr[idx(0)] = d("a", 1), b: arr[idx(1)] = d("b", 2) } = src);
console.log(arr);
""",
    "assign_element_key_before_read_exact": """
const arr = [0, 0];
function idx(i: number) { log.push("idx " + i); return i; }
({ a: arr[idx(0)] = d("a", 1), b: arr[idx(1)] = d("b", 2) } = { a: undefined, b: 7 });
console.log(arr);
""",
    "assign_setter_target": """
class T {
  set v(n: number) { log.push("set " + n); }
}
const t = new T();
({ a: t.v = d("a", 1) } = { a: undefined });
const src: { a?: number } = {};
({ a: t.v = d("a2", 2) } = src);
console.log("done");
""",
    "parameter_defaults_order": """
function mkobj(): { b?: number } { log.push("mkobj"); return {}; }
function f(a = d("a", 1), { b = d("b", 2) } = mkobj(), c = d("c", 3)) {
  console.log(a, b, c);
}
f();
f(undefined, { b: undefined }, 4);
f(5, { b: 6 });
""",
    "parameter_pattern_exact_default_object": """
function f({ b = d("b", 2), c = d("c", 3) } = { b: undefined, c: 9 }) {
  console.log(b, c);
}
f();
f({ b: undefined, c: 4 });
""",
    "generator_parameter_default_order": """
function* g(a = d("a", 1), { b = d("b", 2) }: { b?: number } = {}) {
  log.push("body");
  yield a + b;
}
const it = g();
log.push("created");
console.log([...it]);
""",
    "generator_method_pattern_order": """
class K {
  *m({ a = d("a", 1) }: { a?: number }) { log.push("body"); yield a; }
}
const it = new K().m({});
log.push("created");
console.log([...it]);
""",
    "earlier_names_object": """
const { a = 1, b = a * 2, c = a + b } = { a: undefined, b: undefined, c: undefined };
console.log(a, b, c);
""",
    "earlier_names_object_union": """
const src: { a?: number; b?: number; c?: number } = { a: 5 };
const { a = 1, b = a * 2, c = a + b } = src;
console.log(a, b, c);
""",
    "earlier_names_array": """
const src: (number | undefined)[] = [undefined, undefined];
const [a = 1, b = a * 2, c = a + b] = src;
console.log(a, b, c);
""",
    "earlier_names_params": """
function f(a: number, { b = a * 2 }: { b?: number } = {}, [c = b + 1]: (number | undefined)[] = []) {
  console.log(a, b, c);
}
f(1);
f(1, { b: undefined }, [undefined]);
f(1, { b: 5 }, [7]);
""",
    "closure_in_default_captures": """
const fns: Array<() => number> = [];
const { a = (fns.push(() => b * 10), 1), b = 2 } = { a: undefined, b: undefined };
console.log(a, b, fns[0]());
""",
    "closure_default_value": """
const src: { f?: (n: number) => number } = {};
const { f = (n: number) => n + 1 } = src;
console.log(f(1));
const { g = (n: number) => n * 2 } = { g: undefined };
console.log(g(4));
""",
    "default_not_evaluated_for_null": """
const src: { a: number | null; b?: number | null } = { a: null, b: null };
const { a = d("a", 1), b = d("b", 2) } = src;
console.log(a, b);
""",
    "default_not_evaluated_for_falsy": """
const src: { a?: number; s?: string; f?: boolean } = { a: 0, s: "", f: false };
const { a = d("a", 1), s = d("s", "x"), f = d("f", true) } = src;
console.log(a, JSON.stringify(s), f);
""",
    "async_pattern_param_order": """
async function f({ a = d("a", 1) }: { a?: number }, [b = d("b", 2)]: (number | undefined)[]) {
  log.push("body");
  await null;
  return [a, b];
}
const p = f({}, []);
log.push("after call");
p.then((r) => { console.log(r[0], r[1]); console.log("log:", log.join(",")); });
""",
    "generator_pattern_param_order": """
function* g({ a = d("a", 1) }: { a?: number }) {
  log.push("body");
  yield a;
}
const it = g({ a: undefined });
log.push("created");
console.log([...it]);
""",
}

# ------------------------------------------------------------------ parameter defaults reading earlier parameters (C306)
PARAM = {
    "split_element_union": ("""
function f(s: string, p: string | undefined = s.split(":")[1]) {
  return p === undefined ? "none" : p;
}
console.log(f("a:b"), f("a"), f("a", undefined), f("a", "given"));
""", "node"),
    "split_element_union_printed": ("""
function f(s: string, p: string | undefined = s.split(":")[1]) {
  console.log(p);
}
f("a:b"); f("a");
""", "node"),
    "element_read_union": ("""
function f(xs: number[], p: number | undefined = xs[5]) {
  return p ?? -1;
}
console.log(f([1, 2]), f([0, 1, 2, 3, 4, 5]));
""", "node"),
    "element_read_inferred_tested": ("""
function f(xs: string[], p = xs[5]) {
  return p === undefined ? "missing" : p;
}
console.log(f(["a"]), f(["a", "b", "c", "d", "e", "f"]));
""", "node (design question: D-090's tested-local rule applied to a parameter tsc types string)"),
    "element_read_inferred_untested": ("""
function f(xs: string[], p = xs[5]) {
  return p.length;
}
console.log(f(["a", "b", "c", "d", "e", "f"]));
try { console.log(f(["a"])); } catch (e) { console.log("threw", (e as Error).name); }
""", "by design: D-090/D-015: an element read past the end where a string is required throws RangeError, JS a TypeError later"),
    "element_read_inferred_untested_printed": ("""
function f(xs: string[], p = xs[5]) {
  console.log(p);
}
f(["a"]);
""", "by design: D-090: an element read past the end into a place typed string (the parameter, which tsc types string) throws where JS prints undefined"),
    "optional_property_default": ("""
function f(o: { a?: string }, p = o.a) {
  return p ?? "none";
}
console.log(f({}), f({ a: "x" }));
""", "node"),
    "optional_chain_default": ("""
function f(o?: { a: number }, v = o?.a) {
  return v === undefined ? "none" : v;
}
console.log(f(), f({ a: 3 }));
""", "node"),
    "map_get_default": ("""
function f(m: Map<string, number>, k: string, v = m.get(k)) {
  return v ?? 0;
}
const m = new Map([["a", 1]]);
console.log(f(m, "a"), f(m, "b"), f(m, "b", 7));
""", "node"),
    "find_default": ("""
function f(xs: number[], v = xs.find((x) => x > 10)) {
  return v === undefined ? "none" : v;
}
console.log(f([1, 20]), f([1]));
""", "node"),
    "nullish_default": ("""
function f(s: string, p: string = s.split(":")[1] ?? "z") {
  return p;
}
console.log(f("a:b"), f("a"));
""", "node"),
    "exact_undefined_default": ("""
function f(a: number, b: number | undefined = undefined) {
  return b === undefined ? a : a + b;
}
console.log(f(1), f(1, 2), f(1, undefined));
""", "node"),
    "exact_undefined_default_only": ("""
function f(a: number | undefined = undefined) {
  return a;
}
console.log(f(), f(3));
""", "node"),
    "conditional_undefined_default": ("""
function f(c: boolean, x: string | undefined = c ? "y" : undefined) {
  return x ?? "none";
}
console.log(f(true), f(false), f(false, "g"));
""", "node"),
    "maybe_function_default": ("""
function maybe(n: number): number | undefined { return n > 0 ? n : undefined; }
function f(n: number, p: number | undefined = maybe(n)) {
  return p === undefined ? "none" : p * 2;
}
console.log(f(2), f(0), f(0, 5));
""", "node"),
    "closure_default_captures_param": ("""
function f(a: number, g = () => a * 2) {
  return g();
}
console.log(f(2), f(3, () => 1));
""", "node"),
    "pattern_default_from_param": ("""
function f(n: number, { a = n }: { a?: number } = {}) {
  return a;
}
console.log(f(4), f(4, {}), f(4, { a: undefined }), f(4, { a: 9 }));
""", "node"),
    "arrow_split_default": ("""
const f = (s: string, p: string | undefined = s.split("=")[1]) => p ?? "none";
console.log(f("k=v"), f("k"));
""", "node"),
    "method_this_default": ("""
class K {
  parts = ["a"];
  m(i: number, p: string | undefined = this.parts[i]) { return p ?? "none"; }
}
const k = new K();
console.log(k.m(0), k.m(3));
""", "node"),
    "ctor_split_default": ("""
class P {
  v: string;
  constructor(s: string, p: string | undefined = s.split(":")[1]) { this.v = p ?? "none"; }
}
console.log(new P("a:b").v, new P("a").v);
""", "node"),
    "union_default_other_type": ("""
function f(n: number, p: string | number | undefined = n > 0 ? "pos" : undefined) {
  return p === undefined ? "none" : p;
}
console.log(f(1), f(0), f(0, 5));
""", "node"),
    "regex_match_group_default": ("""
function f(s: string, g: string | undefined = s.match(/(\\d+)/)?.[1]) {
  return g ?? "none";
}
console.log(f("ab12"), f("ab"));
""", "node"),
    "record_entry_default": ("""
function f(r: Record<string, string>, k: string, v: string | undefined = r[k]) {
  return v ?? "none";
}
console.log(f({ a: "x" }, "a"), f({ a: "x" }, "b"));
""", "node"),
    "generic_default_from_param": ("""
function f<T>(xs: T[], v: T | undefined = xs[0]) {
  return v === undefined ? "none" : v;
}
console.log(f([1]), f<number>([]), f(["s"]), f<string>([]));
""", "node"),
}

# ------------------------------------------------------------------ C307 family
C307 = {
    "num_arr_string_default": ('const nums: number[] = [1];\nconst [a, b = "none"] = nums;\nconsole.log(a, b);\n', "node"),
    "num_arr_string_default_present": ('const nums: number[] = [1, 2];\nconst [a, b = "none"] = nums;\nconsole.log(a, b);\n', "node"),
    "num_arr_inferred_string_default": ('const nums = [1];\nconst [a, b = "none"] = nums;\nconsole.log(a, b);\n', "node"),
    "bool_arr_null_default": ("const flags: boolean[] = [];\nconst [f = null] = flags;\nconsole.log(f);\n", "node"),
    "bool_arr_null_default_present": ("const flags = [true];\nconst [f = null, g = null] = flags;\nconsole.log(f, g);\n", "node"),
    "num_arr_object_default": ("const nums: number[] = [];\nconst [o = { k: 1 }] = nums;\nconsole.log(o);\n", "node"),
    "num_arr_undefined_default": ("const nums: number[] = [];\nconst [u = undefined] = nums;\nconsole.log(u);\n", "node"),
    "num_arr_union_default": ('const nums: number[] = [];\nconst c = nums.length === 0;\nconst [v = c ? "s" : 0] = nums;\nconsole.log(v);\n', "node"),
    "num_arr_any_default": ('const nums: number[] = [];\nconst z: any = "any";\nconst [v = z] = nums;\nconsole.log(v);\n', "node"),
    "num_arr_unknown_default": ('const nums: number[] = [];\nconst z: unknown = "unk";\nconst [v = z] = nums;\nconsole.log(v);\n', "node"),
    "num_arr_string_default_assign": ('const nums: number[] = [1];\nlet a: number, b: number | string;\n[a, b = "none"] = nums;\nconsole.log(a, b);\n', "node"),
    "num_arr_string_default_param": ('const nums: number[] = [1];\nfunction f([a, b = "none"] = nums) { console.log(a, b); }\nf();\nf([1, 2]);\n', "node"),
    "num_arr_string_default_forof": ('const rows: number[][] = [[1], [1, 2]];\nfor (const [a, b = "none"] of rows) console.log(a, b);\n', "node"),
    "num_arr_string_default_side": ('const nums: number[] = [1];\nconst [a, b = d("b", "none")] = nums;\nconsole.log(a, b);\n', "node"),
    "bool_arr_null_default_param": ("const flags: boolean[] = [];\nfunction f([x = null] = flags) { console.log(x); }\nf();\nf([false]);\n", "node"),
    "str_arr_number_default": ('const strs: string[] = ["a"];\nconst [a, b = 0] = strs;\nconsole.log(a, b);\n', "node"),
    "obj_arr_number_default": ("const objs: { k: number }[] = [];\nconst [o = 0] = objs;\nconsole.log(o);\n", "node"),
    "nested_tuple_optional_default": ('const t: [number, [string, number?]] = [1, ["s"]];\nconst [x, [y, z = 9]] = t;\nconsole.log(x, y, z);\n', "node"),
    "nested_tuple_outer_default": ('const t: [[number | undefined] | undefined, string] = [undefined, "s"];\nconst [[x = 7] = [undefined], y] = t;\nconsole.log(x, y);\n', "node"),
    "nested_tuple_outer_default_empty": ('const t: [[number?]?, string?] = [];\nconst [[x = 7] = [], y = "y"] = t;\nconsole.log(x, y);\n', "node"),
    "nested_tuple_outer_default_param": ('function f([[x = 7] = [undefined], y]: [[number | undefined] | undefined, string]) { console.log(x, y); }\nf([undefined, "s"]);\nf([[3], "s"]);\n', "node"),
    "default_before_rest_rest_tuple": ('const r: [number, ...string[]] = [1];\nconst [h, i = "d", ...rest] = r;\nconsole.log(h, i, rest);\n', "node"),
    "default_before_rest_union_rest_tuple": ('const t: [number | undefined, ...string[]] = [undefined, "r1", "r2"];\nconst [a = 5, ...rest] = t;\nconsole.log(a, rest);\n', "node"),
    "rest_only_rest_tuple": ("const r: [number, ...string[]] = [1, \"x\"];\nconst [h, ...rest] = r;\nconsole.log(h, rest);\n", "node"),
    "default_before_rest_num_arr": ("const r: number[] = [1];\nconst [h, i = 5, ...rest] = r;\nconsole.log(h, i, rest);\n", "node"),
    "default_before_rest_str_arr": ('const r: string[] = ["a"];\nconst [h, i = "d", ...rest] = r;\nconsole.log(h, i, rest);\n', "node"),
    "default_before_rest_rest_tuple_param": ('function f([h, i = "d", ...rest]: [number, ...string[]]) { console.log(h, i, rest); }\nf([1]);\nf([1, "x", "y"]);\n', "node"),
    "default_before_rest_rest_tuple_assign": ('const r: [number, ...string[]] = [1];\nlet h: number, i: string, rest: string[];\n[h, i = "d", ...rest] = r;\nconsole.log(h, i, rest);\n', "node"),
}

# ------------------------------------------------------------------ binding types, generics, numeric types
BIND = {
    "annotated_object": ("const { a = 1 }: { a?: number } = {};\nconsole.log(a);\n", "node", None),
    "annotated_object_exact": ("const { a = 1 }: { a?: undefined | number } = { a: undefined };\nconsole.log(a);\n", "node", None),
    "annotated_array": ("const [a = 1]: (number | undefined)[] = [];\nconsole.log(a);\n", "node", None),
    "declared_tuple_exact": ("const src: [undefined, number?] = [undefined];\nconst [a = 1, b = 2] = src;\nconsole.log(a, b);\n", "node", None),
    "generic_object_param": ("""
function g<T>(def: T, { a = def }: { a?: T } = {}): T { return a; }
console.log(g(1), g("s"), g({ k: 1 }), g(1, { a: undefined }), g(1, { a: 5 }));
""", "node", None),
    "generic_array_param": ("""
function h<T>(def: T, [x = def]: (T | undefined)[]): T { return x; }
console.log(h(1, []), h("s", [undefined]), h(0, [4]));
""", "node", None),
    "generic_exact_instance": ("""
function pick<T extends { a?: number }>(o: T) { const { a = 5 } = o; return a; }
console.log(pick({ a: undefined }), pick({ a: 2 }), pick({}));
""", "node", None),
    "generic_tuple_instance": ("""
function first<T extends (number | undefined)[]>(xs: T) { const [x = 0] = xs; return x; }
console.log(first([undefined] as [undefined]), first([4]), first([] as number[]));
""", "node", None),
    "map_entries_default": ("""
const m = new Map<string, number | undefined>([["a", undefined], ["b", 2]]);
for (const [k, v = 0] of m) console.log(k, v);
""", "node", None),
    "map_entries_exact_undefined": ("""
const m = new Map<string, undefined>([["a", undefined]]);
for (const [k, v = 0] of m) console.log(k, v);
""", "node", None),
    "int_object_default": ("const { a = 3 }: { a?: int } = {};\nconsole.log(a);\n", "no-node", "3\n"),
    "int_exact_undefined_default": ("const { a = 4 as int } = { a: undefined };\nconsole.log(a);\n", "no-node", "4\n"),
    "u8_array_default": ("const xs: u8[] = [1];\nconst [p, q = 7] = xs;\nconsole.log(p, q);\n", "no-node", "1 7\n"),
    "int_array_other_type_default": ('const xs: int[] = [1];\nconst [p, q = "none"] = xs;\nconsole.log(p, q);\n', "no-node", "1 none\n"),
    "int_param_pattern_default": ("function f({ n = 2 }: { n?: int } = {}): int { return n * 2; }\nconsole.log(f(), f({ n: 5 }));\n", "no-node", "4 10\n"),
    "int_tuple_optional_default": ("const t: [int, int?] = [1];\nconst [x, y = 9] = t;\nconsole.log(x, y);\n", "no-node", "1 9\n"),
    "int_union_exact": ("const src: { a: int | undefined } = { a: undefined };\nconst { a = 4 } = src;\nconsole.log(a);\n", "no-node", "4\n"),
    "catch_message_default": ("""
try { throw new Error(""); } catch ({ message = "m" }: any) { console.log(JSON.stringify(message)); }
try { throw { code: 1 }; } catch ({ message = "m" }: any) { console.log(message); }
""", "out of scope: destructuring a caught exception is PTS1001 (exceptions.go), not a default's", None),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=12)
    ap.add_argument("--out", required=True)
    ap.add_argument("--sample", type=int, default=250)
    args = ap.parse_args()
    rng = random.Random(args.seed)
    os.makedirs(args.out, exist_ok=True)
    cases = {}
    skipped_invalid = {}

    def add(cid, family, prog, expect, no_node=False, expect_stdout=None):
        cases[cid] = dict(id=cid, family=family, expect=expect, no_node=no_node, expect_stdout=expect_stdout, prog=prog)

    for kind, sources in (("obj", OBJ_SOURCES), ("arr", ARR_SOURCES)):
        triples = set()
        for s, c in itertools.product(sources, CONTEXTS):  # grid A: every source in every context
            triples.add((s, c, "side"))
        for s, df in itertools.product(sources, DEFAULTS):  # grid B: every source with every default
            for c in ("const_mod", "param", "assign_stmt"):
                triples.add((s, c, df))
        anchors = ["lit_undef", "opt_absent", "class_getter_exact"] if kind == "obj" else ["lit_undef", "num_arr_short", "generator"]
        for s, c, df in itertools.product(anchors, CONTEXTS, DEFAULTS):  # grid C
            triples.add((s, c, df))
        rest = sorted(set(itertools.product(sources, CONTEXTS, DEFAULTS)) - triples)
        for t in rng.sample(rest, min(args.sample, len(rest))):
            triples.add(t)
        for s, c, df in sorted(triples):
            if c in ("catch", "forof_assign") and df != "side":
                continue  # PTS1001 whatever the default (exceptions.go; `for…of` without a declaration): grid A documents it
            made = pattern_case(kind, s, c, df)
            if made is None:
                skipped_invalid[kind] = skipped_invalid.get(kind, 0) + 1
                continue
            add(f"{kind}.{s}.{c}.{df}", kind, made[0], made[1])
    for cid, fam, prog, expect in nested_cases():
        add(cid, fam, prog, expect)
    for name, body in ORDER.items():
        prog = HEADER + body.lstrip("\n")
        if "console.log(\"log:\"" not in body:
            prog += TRAILER
        expect = "node"
        if name == "computed_key_before_read":
            expect = "out of scope: computed property names in object patterns are PTS1001 (D-054), not H12's"
        add(f"order.{name}", "order", prog, expect)
    for name, (body, expect) in PARAM.items():
        add(f"param.{name}", "param", HEADER + body.lstrip("\n") + TRAILER, expect)
    for name, (body, expect) in C307.items():
        add(f"c307.{name}", "c307", HEADER + body + TRAILER, expect)
    for name, (body, expect, stdout) in BIND.items():
        no_node = expect == "no-node"
        add(f"bind.{name}", "bind", HEADER + body.lstrip("\n") + TRAILER, "no-node: ParallelScript number types" if no_node else expect,
            no_node=no_node, expect_stdout=(stdout + "log: \n") if stdout is not None else None)

    with open(os.path.join(args.out, "cases.jsonl"), "w") as f:
        for cid in sorted(cases):
            c = cases[cid]
            with open(os.path.join(args.out, cid + ".pts"), "w") as p:
                p.write(c["prog"])
            meta = {k: v for k, v in c.items() if k != "prog"}
            f.write(json.dumps(meta) + "\n")
    fams = {}
    for c in cases.values():
        fams[c["family"]] = fams.get(c["family"], 0) + 1
    print(len(cases), "cases", json.dumps(fams, sort_keys=True), "dropped as invalid TS in annotated parameters:", json.dumps(skipped_invalid))


if __name__ == "__main__":
    main()
