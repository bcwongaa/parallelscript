#!/usr/bin/env python3
"""merge.py OLD.jsonl NEW.jsonl CASES_DIR OUT.jsonl: results for CASES_DIR's ids, NEW's where it has them."""
import json, sys

old_path, new_path, cases, out = sys.argv[1:5]
old = {json.loads(l)["id"]: l for l in open(old_path)}
new = {json.loads(l)["id"]: l for l in open(new_path)}
ids = [json.loads(l)["id"] for l in open(cases + "/cases.jsonl")]
missing = [i for i in ids if i not in new and i not in old]
with open(out, "w") as f:
    for i in ids:
        if i in new or i in old:
            f.write(new.get(i) or old[i])
print("merged", len(ids) - len(missing), "missing", missing)
