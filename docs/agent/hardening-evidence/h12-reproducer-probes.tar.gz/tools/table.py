#!/usr/bin/env python3
"""table.py BASE.jsonl PROTO.jsonl: per family and expectation, the class counts on the base
and the prototype, as a Markdown table; then per pattern context and per source for the obj/arr
families (Node-expected only)."""
import collections, json, sys

base = [json.loads(l) for l in open(sys.argv[1])]
proto = {json.loads(l)["id"]: json.loads(l) for l in open(sys.argv[2])}


def eg(e):
    for k in ("node", "by design", "out of scope", "no-node"):
        if e.startswith(k):
            return k
    return e


def fmt(c):
    order = ["OK", "WRONG", "TypeError", "RangeError", "PTS1001", "PTS9001", "COMPILE", "crash", "timeout"]
    return ", ".join(f"{k} {c[k]}" for k in order if c.get(k))


groups = collections.defaultdict(lambda: (collections.Counter(), collections.Counter()))
for r in base:
    g = groups[(r["family"], eg(r["expect"]))]
    g[0][r["cls"]] += 1
    g[1][proto[r["id"]]["cls"]] += 1
print("| family | expected | cases | base | prototype |")
print("|---|---|---:|---|---|")
for (fam, e), (b, p) in sorted(groups.items()):
    print(f"| {fam} | {e} | {sum(b.values())} | {fmt(b)} | {fmt(p)} |")
tb, tp = collections.Counter(), collections.Counter()
for b, p in groups.values():
    tb.update(b)
    tp.update(p)
print(f"| all | | {sum(tb.values())} | {fmt(tb)} | {fmt(tp)} |")

for axis, idx in (("context", 2), ("source", 1), ("default", 3)):
    print(f"\n| obj/arr {axis} (Node-expected) | cases | base OK | proto OK |")
    print("|---|---:|---:|---:|")
    c = collections.defaultdict(lambda: [0, 0, 0])
    for r in base:
        if r["family"] in ("obj", "arr") and eg(r["expect"]) == "node":
            key = r["family"] + "." + r["id"].split(".")[idx]
            c[key][0] += 1
            c[key][1] += r["cls"] == "OK"
            c[key][2] += proto[r["id"]]["cls"] == "OK"
    for k, (n, b, p) in sorted(c.items()):
        if b < n or p < n:
            print(f"| {k} | {n} | {b} | {p} |")
