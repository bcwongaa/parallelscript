#!/usr/bin/env python3
"""emitc_sweep.py OUT.json [--jobs N]: emit C for every pts/tests/run, corpus and docs/examples
program with the base CLI and the prototype CLI and record which programs' C differs (or fails
to compile with one of them). The C is compared after dropping #line paths. No clang runs."""
import concurrent.futures as cf, glob, json, os, re, subprocess, sys, tempfile

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4625cf9703fcd106"
BASE = ("/tmp/h12/base/pts-bin/pts", "/tmp/h12/base")
PROTO = ("/tmp/h12/repro/proto/pts-bin/pts", "/tmp/h12/base")
out = sys.argv[1]
jobs = int(sys.argv[sys.argv.index("--jobs") + 1]) if "--jobs" in sys.argv else 4
files = sorted(glob.glob(f"{WT}/pts/tests/run/*.pts") + glob.glob(f"{WT}/pts/tests/corpus/*/*.pts") + glob.glob(f"{WT}/docs/examples/*.pts"))


def emit(cli, path):
    exe, home = cli
    with tempfile.NamedTemporaryFile(suffix=".c", dir="/tmp/h12/repro/work", delete=False) as f:
        target = f.name
    try:
        p = subprocess.run([exe, "emit-c", os.path.basename(path), "-o", target], cwd=os.path.dirname(path), capture_output=True,
                           timeout=300, env=dict(os.environ, PTS_HOME=home))
        text = open(target).read() if p.returncode == 0 else ""
        return p.returncode, re.sub(r'#line (\d+) "[^"]*"', r"#line \1", text), p.stderr.decode()[:400]
    finally:
        os.unlink(target)


def one(path):
    b, p = emit(BASE, path), emit(PROTO, path)
    return dict(file=os.path.relpath(path, WT), base_rc=b[0], proto_rc=p[0], same=b[1] == p[1] and b[0] == p[0],
                base_err=b[2] if b[0] else "", proto_err=p[2] if p[0] else "")


with cf.ThreadPoolExecutor(jobs) as ex:
    results = list(ex.map(one, files))
json.dump(results, open(out, "w"), indent=1)
changed = [r for r in results if not r["same"]]
print(len(results), "programs;", len(changed), "with different C or result")
for r in changed:
    print(f"  {r['file']} base rc={r['base_rc']} proto rc={r['proto_rc']} {r['proto_err'][:160]}")
