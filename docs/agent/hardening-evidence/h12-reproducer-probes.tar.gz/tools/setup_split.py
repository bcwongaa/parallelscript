#!/usr/bin/env python3
"""setup_split.py BASE.jsonl PROTO.jsonl: the matrix's nested cases whose source declaration
itself fails (N7, a literal in a context holding undefined) share messages with RC3/RC4;
this counts them apart."""
import json, re, sys

setup = re.compile(r"^nest\.(arr_in_obj\.short|arr_obj_in_obj\.(empty_obj|given)|tuple_default_nested\.(given|inner_undef))\.")
base = [json.loads(l) for l in open(sys.argv[1])]
proto = {json.loads(l)["id"]: json.loads(l) for l in open(sys.argv[2])}
n = [r for r in base if r["expect"].startswith(("node", "no-node"))]
s = [r for r in n if setup.search(r["id"])]
print("node-expected", len(n), "base OK", sum(r["cls"] == "OK" for r in n), "proto OK", sum(proto[r["id"]]["cls"] == "OK" for r in n))
print("setup-literal (N7) cases", len(s), "base OK", sum(r["cls"] == "OK" for r in s), "proto OK", sum(proto[r["id"]]["cls"] == "OK" for r in s))
for key in ("changed or kept", "using a `["):
    rs = [r for r in n if key in (r.get("pts_diag") or "") and r["cls"] != "OK"]
    print(repr(key), "base failures", len(rs), "of which setup", sum(1 for r in rs if setup.search(r["id"])))
