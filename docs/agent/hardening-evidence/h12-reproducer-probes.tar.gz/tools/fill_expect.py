#!/usr/bin/env python3
"""fill_expect.py file.pts...: replaces each file's `// expect:` block with Node's stdout
(run on a .mts copy in a fresh temp dir, strict ESM). Refuses if Node exits non-zero unless
--allow-exit is given, in which case it also writes `// exit: N`."""
import os, shutil, subprocess, sys, tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
allow_exit = "--allow-exit" in sys.argv
for path in [a for a in sys.argv[1:] if not a.startswith("--")]:
    lines = open(path).read().split("\n")
    if "// expect:" in lines:
        lines = lines[:lines.index("// expect:")]
    lines = [l for l in lines if not l.startswith("// exit:")]
    while lines and lines[-1] == "":
        lines.pop()
    body = "\n".join(lines) + "\n"
    d = tempfile.mkdtemp(prefix="fill.", dir="/tmp/h12/repro/work")
    try:
        open(os.path.join(d, "p.mts"), "w").write(body)
        p = subprocess.run([NODE, "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, timeout=30,
                           env=dict(os.environ, TZ="America/New_York"))
    finally:
        shutil.rmtree(d, ignore_errors=True)
    if p.returncode != 0 and not allow_exit:
        print(f"{path}: node exited {p.returncode}: {p.stderr.decode()[:400]}")
        continue
    out = p.stdout.decode()
    block = ["", "// expect:"] + [("// " + l) if l else "//" for l in out.rstrip("\n").split("\n")]
    if p.returncode != 0:
        block.append(f"// exit: {p.returncode}")
    open(path, "w").write(body + "\n".join(block) + "\n")
    print(f"{path}: {len(out.splitlines())} lines, node rc={p.returncode}")
