#!/bin/bash
# Focused pts/tests run (TestRun, TestRunMatchesNode, TestErrors) of the destructuring- and
# default-related tests in the reproducer's worktree, with its (prototype) compiler.
# usage: focused_tests.sh OUT.log
set -u
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4625cf9703fcd106
export PATH=$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH
export GOMAXPROCS=4
cd "$WT" || exit 2
PAT='(destructuring|array_pattern|pattern_|default|record|loose_locals|parameter|array_assignment|for_of|generic_any_instance|callback|defaults|narrowed_never|element_reads|optional|generators|dynamic_casts|holes|find_|tuple|generic_destructured|generic_array_pattern|builtin_property_patterns|for_let|exceptions_not_yet|arrays_not_yet|destructuring_not_yet|array_assignment_patterns_not_yet)'
# taskset: 4 CPUs, so the harness's min(NumCPU, 6) heavy jobs is 4 (the shared host's budget)
taskset -c 0-3 go test -count=1 -timeout 40m ./pts/tests/ -run "Test(Run|RunMatchesNode|Errors)/$PAT" -v > "$1" 2>&1
echo "exit=$?" >> "$1"
