#!/usr/bin/env python3
"""show.py results.jsonl [--all] [--id REGEX]: prints each case's class, Node's and pts's output."""
import json, re, sys

args = sys.argv[1:]
path = args[0]
show_all = "--all" in args
rx = re.compile(args[args.index("--id") + 1]) if "--id" in args else None
for l in open(path):
    r = json.loads(l)
    if rx and not rx.search(r["id"]):
        continue
    if not show_all and r["cls"] == "OK" and not rx:
        print(f"OK        {r['id']}")
        continue
    print(f"{r['cls']:<9} {r['id']}  (node rc={r['node_rc']}, pts build rc={r['pts_build_rc']} run rc={r['pts_rc']})")
    if r.get("node_stdout") is not None:
        print("  node stdout: " + repr(r["node_stdout"]) + ("  node error: " + r["node_error"] if r.get("node_error") else ""))
    print("  pts  stdout: " + repr(r["pts_stdout"]))
    if r.get("pts_diag"):
        print("  pts  diag:   " + r["pts_diag"])
