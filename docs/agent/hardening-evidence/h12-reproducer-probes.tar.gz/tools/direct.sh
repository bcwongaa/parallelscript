#!/bin/bash
# direct.sh CLI FILE...: runs each file with `pts run` (PTS_HOME=/tmp/h12/base) and with Node on a
# .mts copy, printing the exact commands, outputs and exit codes.
CLI=$1; shift
NODE=$HOME/.local/node/bin/node
for f in "$@"; do
  d=$(mktemp -d /tmp/h12/repro/work/direct.XXXX)
  cp "$f" "$d/p.pts"; cp "$f" "$d/p.mts"
  echo "### $(basename "$f")"
  echo "\$ PTS_HOME=/tmp/h12/base $CLI run p.pts"
  (cd "$d" && PTS_HOME=/tmp/h12/base "$CLI" run p.pts 2>&1); echo "[exit $?]"
  echo "\$ node --experimental-transform-types --no-warnings p.mts"
  (cd "$d" && "$NODE" --experimental-transform-types --no-warnings p.mts 2>&1); echo "[exit $?]"
  rm -rf "$d"
done
