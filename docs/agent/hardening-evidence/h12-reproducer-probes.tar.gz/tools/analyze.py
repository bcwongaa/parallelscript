#!/usr/bin/env python3
"""analyze.py results.jsonl [--examples N] [--compare other.jsonl]

Summarises a matrix run: classes per family split by expectation (Node / by design / out of
scope / no-node), root-cause buckets for the failing Node-expected cases, distinct diagnostics.
With --compare (a base run), lists cases whose class changed.
"""
import collections, json, re, sys

args = sys.argv[1:]
path = args[0]
nex = int(args[args.index("--examples") + 1]) if "--examples" in args else 3
cmp_path = args[args.index("--compare") + 1] if "--compare" in args else None

EXACT_OBJ = {"lit_undef", "lit_void0", "decl_undef", "inferred_undef", "class_field_exact", "class_getter_exact", "fn_result_exact"}


def expect_group(e):
    if e.startswith("node"):
        return "node"
    if e.startswith("by design"):
        return "by-design"
    if e.startswith("out of scope"):
        return "out-of-scope"
    if e.startswith("no-node"):
        return "no-node"
    return e


def bucket(r):
    """root-cause bucket for a non-OK case"""
    cid, diag, cls = r["id"], r.get("pts_diag") or "", r["cls"]
    parts = cid.split(".")
    fam = parts[0]
    src = parts[1] if len(parts) > 1 else ""
    if "destructuring a caught exception" in diag:
        return "N:catch-pattern-PTS1001"
    if "`for...of` without a declaration" in diag:
        return "N:for-of-assignment-target-PTS1001"
    if "with an array pattern is not supported yet" in diag:
        return "N:array-assignment-pattern-over-non-array-PTS1001"
    if "where it may be changed or kept" in diag:
        return "RC3:rest-of-rest-tuple"
    if re.search(r"using a `\[", diag):
        return "RC4:nested-tuple-default-tuple-classes"
    if "Object has no property" in diag:
        return "RC6:record-missing-key-in-pattern"
    ctx = parts[2] if len(parts) > 2 else ""
    if fam == "param" and (re.search(r"converting .*undefined to ", diag) or "got undefined" in diag or cls == "RangeError" and "Array index" in diag):
        return "RC5:parameter-default-may-be-undefined"
    numeric_src = src.startswith(("num_arr", "bool_arr", "typed_array")) or src == "rest_tuple"
    if fam in ("arr", "c307", "bind") and (re.search(r"converting [^|]*?(\| [^|]*?)* to (number|boolean|i64|u8|int)\b", diag) or "Expected number, got" in diag or "Expected boolean, got" in diag) and (
            fam == "c307" or numeric_src or "int_array" in cid or "u8" in cid):
        return "RC2:default-of-other-type-over-number-or-boolean-array"
    if fam in ("obj", "arr") and ctx in ("assign_member", "assign_elem") and ("converting" in diag or "Expected" in diag):
        return "RC2b:assignment-target-default-typed-as-the-part"
    if src == "rest_tuple_mixed" and "converting number | string to number" in diag:
        return "RC3b:assignment-pattern-over-rest-tuple-element"
    if re.search(r"destructuring the property `\w+` of a undefined", diag):
        return "RC1:exact-undefined-part-default-skipped(nested pattern)"
    if re.search(r"converting undefined to ", diag):
        return "RC1:exact-undefined-part-default-skipped(PTS1001)"
    if cls == "WRONG" and fam == "obj" and src in EXACT_OBJ:
        return "RC1:exact-undefined-part-default-skipped(silent WRONG)"
    if cls == "TypeError" and "Expected" in diag:
        return "TypeError:" + re.sub(r"\d+", "N", diag[:80])
    return f"other:{cls}:" + re.sub(r"p\.pts:\d+:\d+ - ", "", diag)[:120]


rows = [json.loads(l) for l in open(path)]
by_fam = collections.defaultdict(collections.Counter)
for r in rows:
    by_fam[(r["family"], expect_group(r["expect"]))][r["cls"]] += 1
classes = ["OK", "WRONG", "TypeError", "RangeError", "PTS1001", "PTS9001", "COMPILE", "crash", "timeout"]
print(f"{'family':<8} {'expect':<13} {'total':>5} " + " ".join(f"{c:>9}" for c in classes))
tot = collections.Counter()
for (fam, eg), c in sorted(by_fam.items()):
    print(f"{fam:<8} {eg:<13} {sum(c.values()):>5} " + " ".join(f"{c.get(k, 0):>9}" for k in classes))
    tot.update(c)
print(f"{'all':<8} {'':<13} {sum(tot.values()):>5} " + " ".join(f"{tot.get(k, 0):>9}" for k in classes))

print("\nNode-expected failures by root-cause bucket:")
buckets = collections.defaultdict(list)
for r in rows:
    if expect_group(r["expect"]) in ("node", "no-node") and r["cls"] != "OK":
        buckets[bucket(r)].append(r)
for b, rs in sorted(buckets.items(), key=lambda kv: -len(kv[1])):
    cls = collections.Counter(r["cls"] for r in rs)
    fams = collections.Counter(r["family"] for r in rs)
    print(f"  {len(rs):>5}  {b}   {dict(cls)} {dict(fams)}")
    for r in rs[:nex]:
        print(f"           e.g. {r['id']}: {(r.get('pts_diag') or '')[:150]}")

print("\nBy-design / out-of-scope cases (class counts):")
for r_group in ("by-design", "out-of-scope"):
    c = collections.Counter((r["expect"][:90], r["cls"]) for r in rows if expect_group(r["expect"]) == r_group)
    for (e, cl), n in sorted(c.items()):
        print(f"  {n:>5} {cl:<10} {e}")

if cmp_path:
    base = {json.loads(l)["id"]: json.loads(l) for l in open(cmp_path)}
    changes = collections.Counter()
    regress = []
    for r in rows:
        b = base.get(r["id"])
        if b is None:
            continue
        if b["cls"] != r["cls"]:
            changes[(b["cls"], r["cls"])] += 1
            if b["cls"] == "OK":
                regress.append(r)
    print("\nClass changes vs", cmp_path)
    for (a, b), n in sorted(changes.items(), key=lambda kv: -kv[1]):
        print(f"  {n:>5} {a} -> {b}")
    print(f"\nRegressions (OK before): {len(regress)}")
    for r in regress[:40]:
        print(f"  {r['id']} {r['cls']} {(r.get('pts_diag') or '')[:150]}")
