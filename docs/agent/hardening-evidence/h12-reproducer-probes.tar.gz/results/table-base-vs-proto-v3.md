| family | expected | cases | base | prototype |
|---|---|---:|---|---|
| arr | by design | 55 | WRONG 34, TypeError 10, PTS1001 11 | WRONG 43, TypeError 10, PTS1001 2 |
| arr | node | 1440 | OK 1213, TypeError 18, PTS1001 209 | OK 1325, PTS1001 115 |
| arr | out of scope | 60 | PTS1001 60 | PTS1001 60 |
| bind | no-node | 7 | OK 5, PTS1001 2 | OK 7 |
| bind | node | 10 | OK 8, PTS1001 2 | OK 10 |
| bind | out of scope | 1 | PTS1001 1 | PTS1001 1 |
| c307 | node | 28 | OK 6, TypeError 2, PTS1001 20 | OK 27, PTS1001 1 |
| nest | node | 258 | OK 172, PTS1001 86 | OK 224, PTS1001 34 |
| obj | by design | 2 | TypeError 2 | TypeError 2 |
| obj | node | 1451 | OK 1055, WRONG 60, TypeError 5, RangeError 85, PTS1001 246 | OK 1442, PTS1001 9 |
| obj | out of scope | 62 | PTS1001 62 | PTS1001 62 |
| order | node | 39 | OK 22, WRONG 3, PTS1001 14 | OK 34, WRONG 3, PTS1001 2 |
| order | out of scope | 1 | PTS1001 1 | PTS1001 1 |
| param | by design | 2 | WRONG 1, RangeError 1 | WRONG 1, RangeError 1 |
| param | node | 22 | OK 3, TypeError 2, RangeError 1, PTS1001 16 | OK 22 |
| all | | 3438 | OK 2484, WRONG 98, TypeError 39, RangeError 87, PTS1001 730 | OK 3091, WRONG 47, TypeError 12, RangeError 1, PTS1001 287 |

| obj/arr context (Node-expected) | cases | base OK | proto OK |
|---|---:|---:|---:|
| arr.assign_elem | 76 | 42 | 55 |
| arr.assign_member | 72 | 44 | 56 |
| arr.assign_stmt | 300 | 207 | 240 |
| arr.assign_value | 83 | 54 | 65 |
| arr.const_mod | 300 | 279 | 300 |
| arr.forof | 72 | 65 | 72 |
| arr.let_fn | 81 | 73 | 81 |
| arr.param_whole_default | 85 | 78 | 85 |
| obj.arrow | 42 | 38 | 41 |
| obj.assign_elem | 74 | 39 | 74 |
| obj.assign_member | 75 | 35 | 75 |
| obj.assign_stmt | 310 | 227 | 310 |
| obj.assign_value | 79 | 46 | 79 |
| obj.async | 44 | 40 | 43 |
| obj.const_mod | 310 | 226 | 309 |
| obj.ctor | 38 | 34 | 37 |
| obj.forof | 82 | 52 | 82 |
| obj.generator | 36 | 33 | 35 |
| obj.let_fn | 74 | 47 | 73 |
| obj.method | 42 | 37 | 41 |
| obj.param | 160 | 148 | 159 |
| obj.param_whole_default | 85 | 53 | 84 |

| obj/arr source (Node-expected) | cases | base OK | proto OK |
|---|---:|---:|---:|
| arr.any_val | 51 | 36 | 36 |
| arr.bool_arr_short | 37 | 21 | 37 |
| arr.generator | 116 | 76 | 76 |
| arr.iterable_class | 43 | 30 | 30 |
| arr.maybe_arr_short | 45 | 44 | 45 |
| arr.maybe_arr_undef | 41 | 40 | 41 |
| arr.num_arr_present | 42 | 32 | 42 |
| arr.num_arr_short | 110 | 70 | 110 |
| arr.rest_tuple | 46 | 29 | 46 |
| arr.rest_tuple_mixed | 41 | 24 | 41 |
| arr.set_src | 42 | 27 | 27 |
| arr.str_arr_hole | 40 | 39 | 40 |
| arr.str_arr_short | 39 | 37 | 39 |
| arr.string_src | 42 | 25 | 25 |
| arr.tuple_opt_undef | 43 | 41 | 43 |
| arr.tuple_str_opt | 45 | 41 | 45 |
| arr.tuple_union_present | 43 | 42 | 43 |
| arr.typed_array | 40 | 25 | 25 |
| obj.class_field_exact | 31 | 3 | 31 |
| obj.class_field_union | 43 | 42 | 43 |
| obj.class_getter_exact | 86 | 14 | 86 |
| obj.decl_undef | 34 | 5 | 34 |
| obj.fn_result_exact | 30 | 4 | 30 |
| obj.iface_from_class | 45 | 44 | 45 |
| obj.iface_opt_lit | 40 | 39 | 40 |
| obj.inferred_undef | 30 | 3 | 30 |
| obj.lit_undef | 86 | 14 | 86 |
| obj.lit_void0 | 32 | 4 | 32 |
| obj.obj_opt_absent | 42 | 32 | 33 |
| obj.opt_absent | 116 | 106 | 116 |
| obj.opt_undef | 43 | 42 | 43 |
| obj.record_plain_missing | 46 | 0 | 46 |
| obj.record_union_missing | 39 | 0 | 39 |
| obj.record_union_undef | 46 | 45 | 46 |
| obj.str_opt_absent | 41 | 38 | 41 |
| obj.union_undef | 42 | 41 | 42 |

| obj/arr default (Node-expected) | cases | base OK | proto OK |
|---|---:|---:|---:|
| arr.any | 128 | 112 | 117 |
| arr.closure | 132 | 120 | 122 |
| arr.earlier | 121 | 107 | 111 |
| arr.null | 98 | 67 | 88 |
| arr.object | 102 | 75 | 93 |
| arr.other | 94 | 66 | 85 |
| arr.same | 137 | 126 | 128 |
| arr.side | 396 | 368 | 372 |
| arr.undef | 135 | 101 | 122 |
| arr.unknown | 97 | 71 | 87 |
| obj.any | 132 | 92 | 132 |
| obj.closure | 126 | 89 | 126 |
| obj.earlier | 129 | 94 | 129 |
| obj.null | 95 | 59 | 95 |
| obj.object | 95 | 60 | 95 |
| obj.other | 96 | 58 | 96 |
| obj.same | 135 | 100 | 135 |
| obj.side | 392 | 299 | 383 |
| obj.undef | 149 | 139 | 149 |
| obj.unknown | 102 | 65 | 102 |
