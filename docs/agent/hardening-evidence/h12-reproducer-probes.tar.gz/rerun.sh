#!/bin/bash
# H12 reproducer: how to rerun everything (from /tmp/h12/repro after extracting the archive).
# Needs: the base CLI at /tmp/h12/base (main 9765ca1b6, `make build`), Node at ~/.local/node/bin,
# and for the prototype a worktree of main with h12-prototype.patch applied, built to
# /tmp/h12/repro/proto/pts-bin/pts (`go build -o /tmp/h12/repro/proto/pts-bin/pts ./cmd/pts`;
# it uses the base's runtime through PTS_HOME=/tmp/h12/base).
set -eu
R=/tmp/h12/repro
BASE=/tmp/h12/base/pts-bin/pts
PROTO=$R/proto/pts-bin/pts
J=${JOBS:-4}

# 1. the named claims (C12, C306, C307, ordering, C297 guard) and the parent's probes
python3 $R/named/make_named.py
python3 $R/tools/runner.py --cli $BASE --home /tmp/h12/base --cases $R/named --out $R/results/named-base.jsonl --jobs $J
python3 $R/tools/show.py $R/results/named-base.jsonl --all
python3 $R/tools/runner.py --cli $BASE --home /tmp/h12/base --cases $R/parent-probes --out $R/results/parent-probes-base.jsonl --jobs $J

# 2. the matrix (seeded; 3438 cases)
rm -rf $R/cases2 && python3 $R/gen/gen.py --seed 12 --out $R/cases2
python3 $R/tools/runner.py --cli $BASE --home /tmp/h12/base --cases $R/cases2 --out $R/results/matrix2-base.jsonl --jobs $J --node-cache $R/results/node-cache.jsonl
python3 $R/tools/runner.py --cli $PROTO --home /tmp/h12/base --cases $R/cases2 --out $R/results/matrix2-proto-v3.jsonl --jobs $J --node-cache $R/results/node-cache.jsonl
python3 $R/tools/analyze.py $R/results/matrix2-base.jsonl --examples 2
python3 $R/tools/analyze.py $R/results/matrix2-proto-v3.jsonl --examples 2 --compare $R/results/matrix2-base.jsonl
python3 $R/tools/table.py $R/results/matrix2-base.jsonl $R/results/matrix2-proto-v3.jsonl

# 3. RED and guard tests (copies of the worktree's pts/tests/run files), and the new findings
python3 $R/tools/runner.py --cli $BASE --home /tmp/h12/base --cases $R/redtests --out $R/results/redtests-base.jsonl --jobs $J
python3 $R/tools/runner.py --cli $PROTO --home /tmp/h12/base --cases $R/redtests --out $R/results/redtests-proto.jsonl --jobs $J
python3 $R/nfind/mk.py
python3 $R/tools/runner.py --cli $BASE --home /tmp/h12/base --cases $R/nfind --out $R/results/nfind-base.jsonl --jobs $J
python3 $R/tools/runner.py --cli $PROTO --home /tmp/h12/base --cases $R/nfind --out $R/results/nfind-proto.jsonl --jobs $J

# 4. prototype checks: emit-C sweep of every run/corpus/docs program, costs, focused suite
python3 $R/tools/emitc_sweep.py $R/results/emitc-sweep.json --jobs $J
python3 $R/cost/mk.py && python3 $R/tools/cost.py $R/cost
bash $R/tools/focused_tests.sh $R/results/focused-proto.log   # in the patched worktree (third_party symlinked)
