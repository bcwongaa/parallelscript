#!/usr/bin/env python3
"""New-finding minimal repros (N1...), run with runner.py against base and the prototype."""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
P = {
    # generator parameters (defaults, patterns) are bound at the first next(), not at the call
    "n_generator_param_default_order": """
const log: string[] = [];
function d(n: number): number { log.push("default"); return n; }
function* g(a = d(1)) { log.push("body"); yield a; }
const it = g();
log.push("created");
console.log([...it], log.join(","));
""",
    "n_generator_param_pattern_order": """
const log: string[] = [];
function* g({ a }: { a: number }) { log.push("body"); yield a; }
const src = { get a() { log.push("get a"); return 1; } };
const it = g(src);
log.push("created");
console.log([...it], log.join(","));
""",
    "n_generator_param_pattern_throws_at_call": """
function* g([a]: Iterable<number>) { yield a; }
const bad: any = 5;
try { g(bad); console.log("no throw at call"); } catch (e) { console.log("threw at call", (e as Error).name); }
""",
    # array assignment patterns over non-arrays (iterables, sets, typed arrays, any)
    "n_array_assignment_over_generator": """
function* gen() { yield 1; yield 2; }
let a = 0, b = 0;
[a, b] = gen();
console.log(a, b);
""",
    "n_array_assignment_over_set": """
let a = 0, b = 0;
[a, b] = new Set([1, 2]);
console.log(a, b);
""",
    "n_array_assignment_over_any": """
const src: any = [1, 2];
let a: any, b: any;
[a, b] = src;
console.log(a, b);
""",
    "n_array_assignment_over_string": """
let a = "", b = "";
[a, b] = "xy";
console.log(a, b);
""",
    # catch-clause patterns
    "n_catch_pattern": """
try { throw new Error("boom"); } catch ({ message }: any) { console.log(message); }
""",
    # for…of with an assignment target
    "n_for_of_assignment_target": """
let x = 0;
for (x of [1, 2]) {}
console.log(x);
""",
    "n_for_of_assignment_pattern": """
let a = 0, b = 0;
for ([a, b] of [[1, 2]]) {}
console.log(a, b);
""",
    # an assignment pattern over a rest tuple whose elements differ
    "n_assignment_over_rest_tuple": """
const r: [number, ...string[]] = [1, "x"];
let h = 0, s = "";
[h, s] = r;
console.log(h, s);
""",
    "n_declaration_over_rest_tuple": """
const r: [number, ...string[]] = [1, "x"];
const [h, s] = r;
console.log(h + 1, s);
""",
    # an object literal with an optional shape inside an array that holds undefined
    "n_literal_optional_shape_in_maybe_array": """
const src: { list?: ({ v?: number } | undefined)[] } = { list: [{ v: 3 }] };
console.log(src.list);
""",
    # an array literal of numbers where an optional `(number | undefined)[]` property goes
    "n_literal_array_in_optional_maybe_array": """
const src: { a?: (number | undefined)[] } = { a: [4] };
console.log(src.a);
""",
    # a generic default in a declaration whose inferred type holds undefined, object-typed
    "n_generic_default_object_union_declaration": """
function d<T>(v: T): T { return v; }
const src: { a?: { k: number } } = {};
const { a = d({ k: 5 }) } = src;
console.log(a);
""",
    # a generic default whose inferred type holds undefined into a name of an object type
    "n_generic_default_object_union": """
function d<T>(v: T): T { return v; }
const f = ({ a = d({ k: 5 }) }: { a?: { k: number } }) => a;
console.log(f({}));
""",
    "n_generic_default_number_union": """
function d<T>(v: T): T { return v; }
const f = ({ a = d(5) }: { a?: number }) => a;
console.log(f({}));
""",
    # a nested tuple literal argument where the context is a union of a tuple and undefined
    "n_nested_tuple_literal_union_context": """
function f(t: [[number | undefined] | undefined, string]) { return t[0]; }
console.log(f([[3], "s"]));
""",
    # a nested object default in for…of
    "n_forof_nested_object_default": """
const src: { a?: { b?: { c?: number } } } = {};
for (const { a: { b: { c = 3 } = {} } = {} } of [src]) console.log(c);
""",
    "n_forof_nested_object_default_array": """
const src: { list?: ({ v?: number } | undefined)[] } = {};
for (const { list: [{ v = 0 } = {}] = [] } of [src]) console.log(v);
""",
    # numbers arrays without holes: a hole reads 0, by design (D-085)
    "n_number_array_hole_default": """
const xs: number[] = new Array<number>(2);
xs[0] = 1;
const [a, b = 9] = xs;
console.log(a, b);
""",
}
for k, v in P.items():
    open(os.path.join(HERE, k + ".pts"), "w").write(v.lstrip("\n"))
print(len(P))
