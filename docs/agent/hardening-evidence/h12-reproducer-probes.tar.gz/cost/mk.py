#!/usr/bin/env python3
"""Cost probes: each program runs its loop N times (argv[2], default 1000000); callgrind
instruction counts of N and 0 iterations are compared between the base and the prototype."""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
P = {
    # a parameter whose default may be undefined (`v = m.get(k)`) now holds `number | undefined`
    "param_map_get_default": """
import process from "pts:process";
const n = Number(process.argv[2] ?? "1000000");
function f(m: Map<string, number>, k: string, v = m.get(k)): number { return v ?? 0; }
const m = new Map([["a", 1]]);
let s = 0;
for (let i = 0; i < n; i++) s += f(m, "a");
console.log(s);
""",
    # a record's entry under a default: a dynamic read and a checked conversion
    "record_default_present": """
import process from "pts:process";
const n = Number(process.argv[2] ?? "1000000");
const rec: Record<string, number> = { a: 1, b: 2 };
let s = 0;
for (let i = 0; i < n; i++) {
  const { a = 0, b = 0 } = rec;
  s += a + b;
}
console.log(s);
""",
    # a same-type default over a number[]: the IR should not change
    "number_array_same_default": """
import process from "pts:process";
const n = Number(process.argv[2] ?? "1000000");
const rows: number[][] = [[1, 2], [3]];
let s = 0;
for (let i = 0; i < n; i++) {
  const [x, y = 0] = rows[i & 1];
  s += x + y;
}
console.log(s);
""",
    # a union-typed property default (unchanged path)
    "object_union_default": """
import process from "pts:process";
const n = Number(process.argv[2] ?? "1000000");
const objs: { a?: number; b: number }[] = [{ b: 1 }, { a: 2, b: 3 }];
let s = 0;
for (let i = 0; i < n; i++) {
  const { a = 5, b } = objs[i & 1];
  s += a + b;
}
console.log(s);
""",
}
for k, v in P.items():
    open(os.path.join(HERE, k + ".pts"), "w").write(v.lstrip("\n"))
print(len(P))
