#!/usr/bin/env python3
"""Writes the named-claim probes (C12, C306, C307, ordering, C297 guard) next to this file."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))

PROBES = {
    "c12_object_exact_undefined": """
const { value = 4 } = { value: undefined };
console.log(value);
""",
    "c12_declared_undefined_property": """
const src: { a: undefined; b: number } = { a: undefined, b: 2 };
const { a = 10, b = 20 } = src;
console.log(a, b);
""",
    "c12_assignment": """
let x: number;
({ x = 5 } = { x: undefined });
console.log(x);
""",
    "c12_parameter_whole_default": """
function f({ p = "dflt" } = { p: undefined }) { return p; }
console.log(f());
""",
    "c12_void0": """
const { q = 7 } = { q: void 0 };
console.log(q);
""",
    "c12_function_local": """
function g() {
  const { value = 4 } = { value: undefined };
  return value;
}
console.log(g());
""",
    "c306_param_default_element": """
function f(s: string, p: string | undefined = s.split(":")[1]) {
  return p === undefined ? "none" : p;
}
console.log(f("a:b"));
console.log(f("a"));
console.log(f("a", "given"));
""",
    "c307_a_number_array_other_type": """
const nums: number[] = [1];
const [a, b = "none"] = nums;
console.log(a, b);
""",
    "c307_b_boolean_array_null": """
const flags: boolean[] = [];
const [f = null] = flags;
console.log(f);
""",
    "c307_c_nested_tuple_default": """
const t: [number, [string, number?]] = [1, ["s"]];
const [x, [y, z = 9]] = t;
console.log(x, y, z);
""",
    "c307_d_default_before_rest": """
const r: [number, ...string[]] = [1];
const [h, i = "d", ...rest] = r;
console.log(h, i, rest);
""",
    "ordering_getters": """
function log(s: string) { console.log(s); }
function d(n: number): number { log("default " + n); return n; }
const { a = d(1), b = d(2) } = {
  get a(): number | undefined { log("get a"); return undefined; },
  get b(): number | undefined { log("get b"); return undefined; },
};
console.log(a, b);
""",
    "c307_e_review_nested_tuple_default": """
const t: [[number | undefined] | undefined, string] = [undefined, "s"];
const [[x = 7] = [undefined], y] = t;
console.log("nested tuple default", x, y);
""",
    "c307_f_review_rest_after_default": """
const t: [number | undefined, ...string[]] = [undefined, "r1", "r2"];
const [a = 5, ...rest] = t;
console.log("rest after default", a, rest);
""",
    "ordering_getters_unannotated": """
function log(s: string) { console.log(s); }
function d(n: number): number { log("default " + n); return n; }
const { a = d(1), b = d(2) } = {
  get a() { log("get a"); return undefined; },
  get b() { log("get b"); return undefined; },
};
console.log(a, b);
""",
    "c297_guard": """
let a: number;
[a = 1] = [undefined];
console.log(a);
const [b = 2] = [undefined];
console.log(b);
""",
}

for name, body in PROBES.items():
    with open(os.path.join(HERE, name + ".pts"), "w") as f:
        f.write(body.lstrip("\n"))
print(len(PROBES), "probes")
