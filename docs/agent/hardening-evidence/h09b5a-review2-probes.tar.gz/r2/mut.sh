#!/bin/bash
# mut.sh <overlay-name>: the slice's tests under an overlay mutation of snap-b.
m=$1; cd /tmp/h09b5/snap-b; ov=/tmp/h09b5/review-a/r2/overlay/$m.json; out=/tmp/h09b5/review-a/r2/mut_$m.txt
{
echo "### lower+driver"
timeout 900 go test -overlay $ov -count=1 -run 'TestPastTheInstanceCapACallIsACompileErrorNotAnInternalError|TestInterfaceCallsMakeNoDemandsInTheFallbackBuilds' ./pts/lower/ ./pts/driver/ 2>&1 | grep -E "^(--- |ok|FAIL|    )" | head -30
echo "### tests"
timeout 2400 go test -overlay $ov -count=1 -parallel 2 -v -run '^(TestRun|TestErrors)$/^(generic_polymorphic_recursion_.*|generic_instances_many_calls|generic_speculative_.*|generic_value_calls_many_class_instances|generic_values_read_back_from_any|generic_class_instance_failure_value_calls|generic_instance_cap_methods|generics_not_yet)$' ./pts/tests/ 2>&1 | grep -E "^(--- |ok|FAIL|    --- |        )" | grep -v "^        ---\|^        +++" | head -80
} > $out 2>&1
echo done > $out.done
