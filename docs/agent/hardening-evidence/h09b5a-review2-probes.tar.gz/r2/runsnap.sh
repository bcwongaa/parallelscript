#!/bin/bash
# runsnap.sh file.pts [timeout]: build+run with the snap-b CLI only (time, max RSS), then Node.
f=$1; to=${2:-600}; name=$(basename "$f" .pts); dir=/tmp/h09b5/review-a/r2/bin; out=$dir/$name.snapb.bin
( PTS_HOME=/tmp/h09b5/snap-b /usr/bin/time -f "wall=%es maxrss=%MkB" timeout $to /tmp/h09b5/snap-b-pts build "$f" -o "$out" ) > $dir/$name.snapb.build.txt 2>&1
code=$?
echo "== snap-b build exit=$code $(tail -1 $dir/$name.snapb.build.txt)"
grep -v "^wall=" $dir/$name.snapb.build.txt | head -c 1200
if [ -f "$out" ]; then timeout 20 "$out" > $dir/$name.snapb.out.txt 2>&1; echo "-- run exit=$?"; head -c 1200 $dir/$name.snapb.out.txt; rm -f "$out"; fi
cp "$f" $dir/$name.mts; echo "== node: $(timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts 2>&1 | head -5 | tr '\n' '|' | cut -c1-400)"; rm -f $dir/$name.mts
