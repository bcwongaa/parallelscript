class Box<T> { constructor(public value: T, public origin: number) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value, 0); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 0); } }
function use0(value: Maker): void { const box = value.make(new C0()); console.log(box.origin, box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value, 1); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 1); } }
function use1(value: Maker): void { const box = value.make(new C1()); console.log(box.origin, box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value, 2); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 2); } }
function use2(value: Maker): void { const box = value.make(new C2()); console.log(box.origin, box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value, 3); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 3); } }
function use3(value: Maker): void { const box = value.make(new C3()); console.log(box.origin, box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value, 4); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 4); } }
function use4(value: Maker): void { const box = value.make(new C4()); console.log(box.origin, box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value, 5); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 5); } }
function use5(value: Maker): void { const box = value.make(new C5()); console.log(box.origin, box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value, 6); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 6); } }
function use6(value: Maker): void { const box = value.make(new C6()); console.log(box.origin, box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value, 7); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 7); } }
function use7(value: Maker): void { const box = value.make(new C7()); console.log(box.origin, box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value, 8); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 8); } }
function use8(value: Maker): void { const box = value.make(new C8()); console.log(box.origin, box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value, 9); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 9); } }
function use9(value: Maker): void { const box = value.make(new C9()); console.log(box.origin, box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value, 10); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 10); } }
function use10(value: Maker): void { const box = value.make(new C10()); console.log(box.origin, box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value, 11); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 11); } }
function use11(value: Maker): void { const box = value.make(new C11()); console.log(box.origin, box.value.tag); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value, 12); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 12); } }
function use12(value: Maker): void { const box = value.make(new C12()); console.log(box.origin, box.value.tag); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value, 13); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 13); } }
function use13(value: Maker): void { const box = value.make(new C13()); console.log(box.origin, box.value.tag); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value, 14); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 14); } }
function use14(value: Maker): void { const box = value.make(new C14()); console.log(box.origin, box.value.tag); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value, 15); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 15); } }
function use15(value: Maker): void { const box = value.make(new C15()); console.log(box.origin, box.value.tag); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value, 16); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 16); } }
function use16(value: Maker): void { const box = value.make(new C16()); console.log(box.origin, box.value.tag); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value, 17); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 17); } }
function use17(value: Maker): void { const box = value.make(new C17()); console.log(box.origin, box.value.tag); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value, 18); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 18); } }
function use18(value: Maker): void { const box = value.make(new C18()); console.log(box.origin, box.value.tag); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value, 19); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 19); } }
function use19(value: Maker): void { const box = value.make(new C19()); console.log(box.origin, box.value.tag); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value, 20); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 20); } }
function use20(value: Maker): void { const box = value.make(new C20()); console.log(box.origin, box.value.tag); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value, 21); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 21); } }
function use21(value: Maker): void { const box = value.make(new C21()); console.log(box.origin, box.value.tag); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value, 22); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 22); } }
function use22(value: Maker): void { const box = value.make(new C22()); console.log(box.origin, box.value.tag); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value, 23); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 23); } }
function use23(value: Maker): void { const box = value.make(new C23()); console.log(box.origin, box.value.tag); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value, 24); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 24); } }
function use24(value: Maker): void { const box = value.make(new C24()); console.log(box.origin, box.value.tag); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value, 25); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 25); } }
function use25(value: Maker): void { const box = value.make(new C25()); console.log(box.origin, box.value.tag); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value, 26); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 26); } }
function use26(value: Maker): void { const box = value.make(new C26()); console.log(box.origin, box.value.tag); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value, 27); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 27); } }
function use27(value: Maker): void { const box = value.make(new C27()); console.log(box.origin, box.value.tag); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value, 28); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 28); } }
function use28(value: Maker): void { const box = value.make(new C28()); console.log(box.origin, box.value.tag); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value, 29); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 29); } }
function use29(value: Maker): void { const box = value.make(new C29()); console.log(box.origin, box.value.tag); }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value, 30); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 30); } }
function use30(value: Maker): void { const box = value.make(new C30()); console.log(box.origin, box.value.tag); }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value, 31); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 31); } }
function use31(value: Maker): void { const box = value.make(new C31()); console.log(box.origin, box.value.tag); }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value, 32); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 32); } }
function use32(value: Maker): void { const box = value.make(new C32()); console.log(box.origin, box.value.tag); }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value, 33); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 33); } }
function use33(value: Maker): void { const box = value.make(new C33()); console.log(box.origin, box.value.tag); }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value, 34); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 34); } }
function use34(value: Maker): void { const box = value.make(new C34()); console.log(box.origin, box.value.tag); }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value, 35); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 35); } }
function use35(value: Maker): void { const box = value.make(new C35()); console.log(box.origin, box.value.tag); }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value, 36); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 36); } }
function use36(value: Maker): void { const box = value.make(new C36()); console.log(box.origin, box.value.tag); }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value, 37); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 37); } }
function use37(value: Maker): void { const box = value.make(new C37()); console.log(box.origin, box.value.tag); }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value, 38); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 38); } }
function use38(value: Maker): void { const box = value.make(new C38()); console.log(box.origin, box.value.tag); }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value, 39); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 39); } }
function use39(value: Maker): void { const box = value.make(new C39()); console.log(box.origin, box.value.tag); }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value, 40); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 40); } }
function use40(value: Maker): void { const box = value.make(new C40()); console.log(box.origin, box.value.tag); }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value, 41); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 41); } }
function use41(value: Maker): void { const box = value.make(new C41()); console.log(box.origin, box.value.tag); }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value, 42); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 42); } }
function use42(value: Maker): void { const box = value.make(new C42()); console.log(box.origin, box.value.tag); }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value, 43); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 43); } }
function use43(value: Maker): void { const box = value.make(new C43()); console.log(box.origin, box.value.tag); }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value, 44); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 44); } }
function use44(value: Maker): void { const box = value.make(new C44()); console.log(box.origin, box.value.tag); }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value, 45); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 45); } }
function use45(value: Maker): void { const box = value.make(new C45()); console.log(box.origin, box.value.tag); }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value, 46); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 46); } }
function use46(value: Maker): void { const box = value.make(new C46()); console.log(box.origin, box.value.tag); }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value, 47); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 47); } }
function use47(value: Maker): void { const box = value.make(new C47()); console.log(box.origin, box.value.tag); }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value, 48); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 48); } }
function use48(value: Maker): void { const box = value.make(new C48()); console.log(box.origin, box.value.tag); }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value, 49); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 49); } }
function use49(value: Maker): void { const box = value.make(new C49()); console.log(box.origin, box.value.tag); }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value, 50); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 50); } }
function use50(value: Maker): void { const box = value.make(new C50()); console.log(box.origin, box.value.tag); }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value, 51); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 51); } }
function use51(value: Maker): void { const box = value.make(new C51()); console.log(box.origin, box.value.tag); }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value, 52); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 52); } }
function use52(value: Maker): void { const box = value.make(new C52()); console.log(box.origin, box.value.tag); }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value, 53); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 53); } }
function use53(value: Maker): void { const box = value.make(new C53()); console.log(box.origin, box.value.tag); }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value, 54); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 54); } }
function use54(value: Maker): void { const box = value.make(new C54()); console.log(box.origin, box.value.tag); }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value, 55); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 55); } }
function use55(value: Maker): void { const box = value.make(new C55()); console.log(box.origin, box.value.tag); }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value, 56); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 56); } }
function use56(value: Maker): void { const box = value.make(new C56()); console.log(box.origin, box.value.tag); }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value, 57); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 57); } }
function use57(value: Maker): void { const box = value.make(new C57()); console.log(box.origin, box.value.tag); }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value, 58); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 58); } }
function use58(value: Maker): void { const box = value.make(new C58()); console.log(box.origin, box.value.tag); }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value, 59); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 59); } }
function use59(value: Maker): void { const box = value.make(new C59()); console.log(box.origin, box.value.tag); }
const selected0: Maker = new M0();
const rows0 = ({ branch: [{ value: selected0 }] }).branch;
const row0 = rows0[0]; const alias0 = row0;
use0(alias0.value);
const selected1: Maker = new M1();
const rows1 = ({ branch: [{ value: selected1 }] }).branch;
const row1 = rows1[0]; const alias1 = row1;
use1(alias1.value);
const selected2: Maker = new M2();
const rows2 = ({ branch: [{ value: selected2 }] }).branch;
const row2 = rows2[0]; const alias2 = row2;
use2(alias2.value);
const selected3: Maker = new M3();
const rows3 = ({ branch: [{ value: selected3 }] }).branch;
const row3 = rows3[0]; const alias3 = row3;
use3(alias3.value);
const selected4: Maker = new M4();
const rows4 = ({ branch: [{ value: selected4 }] }).branch;
const row4 = rows4[0]; const alias4 = row4;
use4(alias4.value);
const selected5: Maker = new M5();
const rows5 = ({ branch: [{ value: selected5 }] }).branch;
const row5 = rows5[0]; const alias5 = row5;
use5(alias5.value);
const selected6: Maker = new M6();
const rows6 = ({ branch: [{ value: selected6 }] }).branch;
const row6 = rows6[0]; const alias6 = row6;
use6(alias6.value);
const selected7: Maker = new M7();
const rows7 = ({ branch: [{ value: selected7 }] }).branch;
const row7 = rows7[0]; const alias7 = row7;
use7(alias7.value);
const selected8: Maker = new M8();
const rows8 = ({ branch: [{ value: selected8 }] }).branch;
const row8 = rows8[0]; const alias8 = row8;
use8(alias8.value);
const selected9: Maker = new M9();
const rows9 = ({ branch: [{ value: selected9 }] }).branch;
const row9 = rows9[0]; const alias9 = row9;
use9(alias9.value);
const selected10: Maker = new M10();
const rows10 = ({ branch: [{ value: selected10 }] }).branch;
const row10 = rows10[0]; const alias10 = row10;
use10(alias10.value);
const selected11: Maker = new M11();
const rows11 = ({ branch: [{ value: selected11 }] }).branch;
const row11 = rows11[0]; const alias11 = row11;
use11(alias11.value);
const selected12: Maker = new M12();
const rows12 = ({ branch: [{ value: selected12 }] }).branch;
const row12 = rows12[0]; const alias12 = row12;
use12(alias12.value);
const selected13: Maker = new M13();
const rows13 = ({ branch: [{ value: selected13 }] }).branch;
const row13 = rows13[0]; const alias13 = row13;
use13(alias13.value);
const selected14: Maker = new M14();
const rows14 = ({ branch: [{ value: selected14 }] }).branch;
const row14 = rows14[0]; const alias14 = row14;
use14(alias14.value);
const selected15: Maker = new M15();
const rows15 = ({ branch: [{ value: selected15 }] }).branch;
const row15 = rows15[0]; const alias15 = row15;
use15(alias15.value);
const selected16: Maker = new M16();
const rows16 = ({ branch: [{ value: selected16 }] }).branch;
const row16 = rows16[0]; const alias16 = row16;
use16(alias16.value);
const selected17: Maker = new M17();
const rows17 = ({ branch: [{ value: selected17 }] }).branch;
const row17 = rows17[0]; const alias17 = row17;
use17(alias17.value);
const selected18: Maker = new M18();
const rows18 = ({ branch: [{ value: selected18 }] }).branch;
const row18 = rows18[0]; const alias18 = row18;
use18(alias18.value);
const selected19: Maker = new M19();
const rows19 = ({ branch: [{ value: selected19 }] }).branch;
const row19 = rows19[0]; const alias19 = row19;
use19(alias19.value);
const selected20: Maker = new M20();
const rows20 = ({ branch: [{ value: selected20 }] }).branch;
const row20 = rows20[0]; const alias20 = row20;
use20(alias20.value);
const selected21: Maker = new M21();
const rows21 = ({ branch: [{ value: selected21 }] }).branch;
const row21 = rows21[0]; const alias21 = row21;
use21(alias21.value);
const selected22: Maker = new M22();
const rows22 = ({ branch: [{ value: selected22 }] }).branch;
const row22 = rows22[0]; const alias22 = row22;
use22(alias22.value);
const selected23: Maker = new M23();
const rows23 = ({ branch: [{ value: selected23 }] }).branch;
const row23 = rows23[0]; const alias23 = row23;
use23(alias23.value);
const selected24: Maker = new M24();
const rows24 = ({ branch: [{ value: selected24 }] }).branch;
const row24 = rows24[0]; const alias24 = row24;
use24(alias24.value);
const selected25: Maker = new M25();
const rows25 = ({ branch: [{ value: selected25 }] }).branch;
const row25 = rows25[0]; const alias25 = row25;
use25(alias25.value);
const selected26: Maker = new M26();
const rows26 = ({ branch: [{ value: selected26 }] }).branch;
const row26 = rows26[0]; const alias26 = row26;
use26(alias26.value);
const selected27: Maker = new M27();
const rows27 = ({ branch: [{ value: selected27 }] }).branch;
const row27 = rows27[0]; const alias27 = row27;
use27(alias27.value);
const selected28: Maker = new M28();
const rows28 = ({ branch: [{ value: selected28 }] }).branch;
const row28 = rows28[0]; const alias28 = row28;
use28(alias28.value);
const selected29: Maker = new M29();
const rows29 = ({ branch: [{ value: selected29 }] }).branch;
const row29 = rows29[0]; const alias29 = row29;
use29(alias29.value);
const selected30: Maker = new M30();
const rows30 = ({ branch: [{ value: selected30 }] }).branch;
const row30 = rows30[0]; const alias30 = row30;
use30(alias30.value);
const selected31: Maker = new M31();
const rows31 = ({ branch: [{ value: selected31 }] }).branch;
const row31 = rows31[0]; const alias31 = row31;
use31(alias31.value);
const selected32: Maker = new M32();
const rows32 = ({ branch: [{ value: selected32 }] }).branch;
const row32 = rows32[0]; const alias32 = row32;
use32(alias32.value);
const selected33: Maker = new M33();
const rows33 = ({ branch: [{ value: selected33 }] }).branch;
const row33 = rows33[0]; const alias33 = row33;
use33(alias33.value);
const selected34: Maker = new M34();
const rows34 = ({ branch: [{ value: selected34 }] }).branch;
const row34 = rows34[0]; const alias34 = row34;
use34(alias34.value);
const selected35: Maker = new M35();
const rows35 = ({ branch: [{ value: selected35 }] }).branch;
const row35 = rows35[0]; const alias35 = row35;
use35(alias35.value);
const selected36: Maker = new M36();
const rows36 = ({ branch: [{ value: selected36 }] }).branch;
const row36 = rows36[0]; const alias36 = row36;
use36(alias36.value);
const selected37: Maker = new M37();
const rows37 = ({ branch: [{ value: selected37 }] }).branch;
const row37 = rows37[0]; const alias37 = row37;
use37(alias37.value);
const selected38: Maker = new M38();
const rows38 = ({ branch: [{ value: selected38 }] }).branch;
const row38 = rows38[0]; const alias38 = row38;
use38(alias38.value);
const selected39: Maker = new M39();
const rows39 = ({ branch: [{ value: selected39 }] }).branch;
const row39 = rows39[0]; const alias39 = row39;
use39(alias39.value);
const selected40: Maker = new M40();
const rows40 = ({ branch: [{ value: selected40 }] }).branch;
const row40 = rows40[0]; const alias40 = row40;
use40(alias40.value);
const selected41: Maker = new M41();
const rows41 = ({ branch: [{ value: selected41 }] }).branch;
const row41 = rows41[0]; const alias41 = row41;
use41(alias41.value);
const selected42: Maker = new M42();
const rows42 = ({ branch: [{ value: selected42 }] }).branch;
const row42 = rows42[0]; const alias42 = row42;
use42(alias42.value);
const selected43: Maker = new M43();
const rows43 = ({ branch: [{ value: selected43 }] }).branch;
const row43 = rows43[0]; const alias43 = row43;
use43(alias43.value);
const selected44: Maker = new M44();
const rows44 = ({ branch: [{ value: selected44 }] }).branch;
const row44 = rows44[0]; const alias44 = row44;
use44(alias44.value);
const selected45: Maker = new M45();
const rows45 = ({ branch: [{ value: selected45 }] }).branch;
const row45 = rows45[0]; const alias45 = row45;
use45(alias45.value);
const selected46: Maker = new M46();
const rows46 = ({ branch: [{ value: selected46 }] }).branch;
const row46 = rows46[0]; const alias46 = row46;
use46(alias46.value);
const selected47: Maker = new M47();
const rows47 = ({ branch: [{ value: selected47 }] }).branch;
const row47 = rows47[0]; const alias47 = row47;
use47(alias47.value);
const selected48: Maker = new M48();
const rows48 = ({ branch: [{ value: selected48 }] }).branch;
const row48 = rows48[0]; const alias48 = row48;
use48(alias48.value);
const selected49: Maker = new M49();
const rows49 = ({ branch: [{ value: selected49 }] }).branch;
const row49 = rows49[0]; const alias49 = row49;
use49(alias49.value);
const selected50: Maker = new M50();
const rows50 = ({ branch: [{ value: selected50 }] }).branch;
const row50 = rows50[0]; const alias50 = row50;
use50(alias50.value);
const selected51: Maker = new M51();
const rows51 = ({ branch: [{ value: selected51 }] }).branch;
const row51 = rows51[0]; const alias51 = row51;
use51(alias51.value);
const selected52: Maker = new M52();
const rows52 = ({ branch: [{ value: selected52 }] }).branch;
const row52 = rows52[0]; const alias52 = row52;
use52(alias52.value);
const selected53: Maker = new M53();
const rows53 = ({ branch: [{ value: selected53 }] }).branch;
const row53 = rows53[0]; const alias53 = row53;
use53(alias53.value);
const selected54: Maker = new M54();
const rows54 = ({ branch: [{ value: selected54 }] }).branch;
const row54 = rows54[0]; const alias54 = row54;
use54(alias54.value);
const selected55: Maker = new M55();
const rows55 = ({ branch: [{ value: selected55 }] }).branch;
const row55 = rows55[0]; const alias55 = row55;
use55(alias55.value);
const selected56: Maker = new M56();
const rows56 = ({ branch: [{ value: selected56 }] }).branch;
const row56 = rows56[0]; const alias56 = row56;
use56(alias56.value);
const selected57: Maker = new M57();
const rows57 = ({ branch: [{ value: selected57 }] }).branch;
const row57 = rows57[0]; const alias57 = row57;
use57(alias57.value);
const selected58: Maker = new M58();
const rows58 = ({ branch: [{ value: selected58 }] }).branch;
const row58 = rows58[0]; const alias58 = row58;
use58(alias58.value);
const selected59: Maker = new M59();
const rows59 = ({ branch: [{ value: selected59 }] }).branch;
const row59 = rows59[0]; const alias59 = row59;
use59(alias59.value);
