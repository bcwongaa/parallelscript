import collections
import hashlib
import json
import pathlib
import subprocess
import sys

mode, path = sys.argv[1:3]
path = pathlib.Path(path)
if mode == 'events':
    counts = collections.Counter()
    packages, failures, corpus = [], [], collections.Counter()
    for line in path.open():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        action, test = event.get('Action'), event.get('Test')
        if test and action in ('pass', 'skip', 'fail'):
            counts[action] += 1
            if test.startswith('TestCorpusMatchesNode/'):
                corpus[action] += 1
        if not test and action in ('pass', 'fail'):
            packages.append({'package': event.get('Package'), 'action': action})
        if action == 'fail':
            failures.append(event)
    result = {'events': dict(counts), 'packages': packages, 'corpus': dict(corpus), 'failures': failures}
else:
    root = pathlib.Path('/home/bryan/projects/parallelscript')
    sources = {}
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=root).decode().split('\0')
    for name in names:
        item = root / name
        if name and item.is_file() and (name.startswith(('pts/', 'cmd/', 'internal/')) or name in ('go.mod', 'go.sum', 'Makefile')):
            sources[name] = hashlib.sha256(item.read_bytes()).hexdigest()
    cli = root / 'pts-bin/pts'
    result = {'sources': sources, 'cli': hashlib.sha256(cli.read_bytes()).hexdigest() if cli.exists() else None}
    path.write_text(json.dumps(result, indent=2) + '\n')
    print('source hashes:', len(sources))
    sys.exit(0)
print(json.dumps(result, indent=2))
