import json
import pathlib
import subprocess
import sys

repo, output = map(pathlib.Path, sys.argv[1:3])
output.mkdir()
path = repo / 'pts/lower/container_sources.go'
original = path.read_text()
mutants = {
    'skip_component_uses': ('if !tree.projectionUse(read, steps, depth, aliasUse) {', 'if false && !tree.projectionUse(read, steps, depth, aliasUse) {'),
    'skip_first_contract': ('if !l.nestedContainerTypes(selected, contract, steps, depth) {', 'if false && !l.nestedContainerTypes(selected, contract, steps, depth) {'),
    'cache_root_not_child': ('return check(alias, target, selected, depth)', 'return check(alias, target, data, depth)'),
}
rows = []
for name, (old, new) in mutants.items():
    assert original.count(old) == 1, name
    directory = output / name
    directory.mkdir()
    replacement = directory / path.name
    replacement.write_text(original.replace(old, new, 1))
    overlay = directory / 'overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(path): str(replacement)}}) + '\n')
    with (directory / 'result.jsonl').open('wb') as stdout, (directory / 'result.stderr').open('wb') as stderr:
        run = subprocess.run(['go', 'test', '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '15m', '-overlay', str(overlay), './pts/lower', '-run', '^TestInlineContainer'], cwd=repo, stdout=stdout, stderr=stderr, timeout=1100)
    events = []
    for line in (directory / 'result.jsonl').read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            pass
    assertions = [event for event in events if event.get('Action') == 'output' and 'assertion failed' in event.get('Output', '')]
    failures = [event['Test'] for event in events if event.get('Action') == 'fail' and event.get('Test')]
    errors = (directory / 'result.stderr').read_text() + (directory / 'result.jsonl').read_text()
    assert run.returncode == 1 and assertions and failures and 'build failed' not in errors and '[build failed]' not in errors, (name, run.returncode, errors[-1500:])
    rows.append({'name': name, 'exit': run.returncode, 'compiled': True, 'assertions': len(assertions), 'failed_test_events': len(failures), 'first_failures': failures[:5]})
    (output / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, rows[-1], flush=True)
