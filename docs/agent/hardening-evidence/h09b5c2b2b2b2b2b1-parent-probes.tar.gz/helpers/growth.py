import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys
import time


def source(kind, count, unknown):
    lines = ['class Box<T> { constructor(public value: T, public origin: number) {} }',
             'type Factory = <T>(value: T) => Box<T>;',
             'interface Maker { make<T>(value: T): Box<T>; }']
    for i in range(count):
        lines += [f'class C{i} {{ tag = {i}; }}',
                  f'function source{i}<T>(value: T): Box<T> {{ return new Box(value, {i}); }}',
                  f'class M{i} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value, {i}); }} }}']
        if kind == 'receiver':
            lines += [f'function use{i}(value: Maker): void {{ const box = value.make(new C{i}()); console.log(box.origin, box.value.tag); }}']
        else:
            lines += [f'function use{i}(value: Factory): void {{ const box = value(new C{i}()); console.log(box.origin, box.value.tag); }}']
        if kind == 'captured_receiver':
            lines += [f'function read{i}(value: Maker): Factory {{ return value.make; }}']
        elif kind == 'wrapper':
            lines += [f'function read{i}(): Factory {{ const receiver: Maker = new M{i}(); return receiver.make; }}']
    for i in range(count):
        value, value_type = f'source{i}', 'Factory'
        if kind in ('receiver', 'captured_receiver'):
            value, value_type = f'new M{i}()', 'Maker'
        elif kind == 'wrapper':
            value = f'read{i}()'
        lines += [f'const selected{i}: {value_type} = {value};',
                  f'{"let" if unknown else "const"} rows{i} = ({{ branch: [{{ value: selected{i} }}] }}).branch;',
                  f'const row{i} = rows{i}[0]; const alias{i} = row{i};']
        expression = f'alias{i}.value'
        if kind == 'captured_receiver':
            expression = f'read{i}({expression})'
        lines += [f'use{i}({expression});']
    return '\n'.join(lines) + '\n'


def run(args, stdout, stderr, env):
    start = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(args, stdout=out, stderr=err, env=env, timeout=300)
    if result.returncode:
        raise RuntimeError(f'{args} exited {result.returncode}: {stderr.read_text()[:1500]}')
    return time.monotonic() - start


repo, directory, base, current = map(pathlib.Path, sys.argv[1:5])
directory.mkdir(parents=True, exist_ok=True)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
node = pathlib.Path.home() / '.local/node/bin/node'
rows = []
for kind in ('function', 'receiver', 'captured_receiver', 'wrapper'):
    for count, unknown in ((12, False), (60, False), (12, True)):
        name = f'{kind}_{"unknown" if unknown else "known"}{count}'
        entry = directory / (name + '.pts')
        text = source(kind, count, unknown)
        entry.write_text(text)
        twin = entry.with_suffix('.mts')
        twin.write_text(text)
        run([str(node), '--no-warnings', '--experimental-transform-types', str(twin)], directory / (name+'.node.stdout'), directory / (name+'.node.stderr'), env)
        expected = ''.join(f'{i} {i}\n' for i in range(count))
        assert (directory / (name+'.node.stdout')).read_text() == expected
        observations = {}
        order = [('base', base), ('current', current)] if count == 12 and not unknown else [('current', current), ('base', base)]
        for label, compiler in order:
            prefix = directory / (name + '.' + label)
            c = pathlib.Path(str(prefix)+'.c')
            binary = pathlib.Path(str(prefix)+'.bin')
            elapsed = run([str(compiler), str(entry), str(c), str(binary)], pathlib.Path(str(prefix)+'.compile.stdout'), pathlib.Path(str(prefix)+'.compile.stderr'), env)
            emitted = c.read_text()
            pattern = r'pts_fn_source(\d+)_C(\d+)\(' if kind == 'function' else r'pts_fn_M(\d+)_make_C(\d+)\('
            pairs = sorted(set((int(a), int(b)) for a,b in re.findall(pattern, emitted)))
            required = {(i,j) for i in range(count) for j in range(count) if label == 'base' or unknown or i == j}
            assert set(pairs) == required, (name, label, len(pairs), len(required), pairs[:10])
            run([str(binary)], pathlib.Path(str(prefix)+'.stdout'), pathlib.Path(str(prefix)+'.stderr'), env)
            assert pathlib.Path(str(prefix)+'.stdout').read_text() == expected, (name,label)
            binary.unlink()
            observations[label] = {'pairs': len(pairs), 'lines': len(emitted.splitlines()), 'bytes': c.stat().st_size,
                                   'sha256': hashlib.sha256(c.read_bytes()).hexdigest(), 'compile_seconds': elapsed, 'native_matches_node': True}
        if unknown:
            assert observations['base']['sha256'] == observations['current']['sha256'], name
        rows.append({'name': name, 'kind': kind, 'count': count, 'unknown': unknown, 'observations': observations})
        (directory/'results.json').write_text(json.dumps(rows, indent=2)+'\n')
        print(name, {k: (v['pairs'], v['lines']) for k,v in observations.items()}, flush=True)
