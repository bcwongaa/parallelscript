import gzip
import hashlib
import io
import json
import pathlib
import re
import sys
import tarfile

repo, root = map(pathlib.Path, sys.argv[1:3])
result = json.loads((root / 'final-result.json').read_text())
summary = json.loads((root / 'final-summary.json').read_text())
assert result['green'] and result['suite_exit'] == 0 and result['stderr_bytes'] == 0
assert result['sources_and_cli_unchanged'] and result['reviewed_files_unchanged']
assert len(summary['packages']) == 10 and all(row['action'] == 'pass' for row in summary['packages'])
assert not summary['failures']
base = repo / 'docs/agent/hardening-evidence/h09b5c2b2b2b2b2b1'
archive = pathlib.Path(str(base) + '-parent-probes.tar.gz')
stream = pathlib.Path(str(base) + '-final-suite.jsonl.gz')
receipt = pathlib.Path(str(base) + '-final-summary.json')
for path in (archive, stream, receipt):
    assert not path.exists(), path
with stream.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed:
    with (root / 'final.jsonl').open('rb') as incoming:
        while block := incoming.read(1024 * 1024):
            compressed.write(block)
receipt.write_text(json.dumps(dict(summary, verification=result), indent=2) + '\n')
include_dirs = {'helpers', 'debug1', 'growth', 'mutants', 'prior-input', 'review-native', 'review-native2', 'review-native3', 'review-snapshot1', 'review-snapshot2', 'review-snapshot3', 'reviewer-input', 'reviewer-plan', 'semantics'}
exclude_files = {'strict-base', 'strict-current', 'review-helper-base', 'review-helper-current', 'final.jsonl', 'parent-archive-manifest.json', 'parent-archive-receipt.json'}
files = []
for path in sorted(root.iterdir()):
    if path.is_dir():
        if path.name not in include_dirs:
            continue
        files.extend(p for p in sorted(path.rglob('*')) if p.is_file())
    elif path.name not in exclude_files:
        files.append(path)
files = [path for path in files if path.suffix not in ('.bin', '.o', '.a', '.so')]
secrets = re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|sk-ant-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}')
manifest = {}
for path in files:
    name = path.relative_to(root).as_posix()
    assert not path.is_symlink() and path.is_file() and '..' not in pathlib.PurePosixPath(name).parts
    assert path.name != '.env' and not path.name.endswith('.env')
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), name
    assert not secrets.search(data), ('potential secret marker', name)
    manifest[name] = hashlib.sha256(data).hexdigest()
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
(root / 'parent-archive-manifest.json').write_bytes(manifest_data)
with archive.open('xb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as compressed, tarfile.open(fileobj=compressed, mode='w') as tar:
    for path in files:
        info = tar.gettarinfo(str(path), arcname=path.relative_to(root).as_posix())
        assert info.isfile()
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = ''
        info.mode = 0o644
        with path.open('rb') as payload:
            tar.addfile(info, payload)
    info = tarfile.TarInfo('archive-contents-sha256.json')
    info.size = len(manifest_data)
    info.mode = 0o644
    tar.addfile(info, io.BytesIO(manifest_data))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(manifest) + 1
    assert all(item.isfile() and not pathlib.PurePosixPath(item.name).is_absolute() and '..' not in pathlib.PurePosixPath(item.name).parts for item in members)
    for name, digest in manifest.items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == digest, name
artifacts = {}
for path in (archive, stream, receipt):
    artifacts[path.name] = {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
output = {'payload_files': len(manifest), 'regular_archive_entries': len(members), 'artifacts': artifacts, 'binaries_and_duplicate_runtime_homes_excluded': True, 'payload_hashes_reverified': True}
(root / 'parent-archive-receipt.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps(output, indent=2))
