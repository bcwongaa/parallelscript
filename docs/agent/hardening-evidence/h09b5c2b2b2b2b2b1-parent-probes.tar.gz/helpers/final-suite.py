import hashlib
import json
import os
import pathlib
import subprocess
import sys

repo, output = map(pathlib.Path, sys.argv[1:3])
assert not (output / 'final-result.json').exists()
assert not (output / 'final-summary.json').exists()
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
manifest = json.loads((output / 'review-snapshot3/hashes.json').read_text())
def reviewed_unchanged():
    return all(hashlib.sha256((repo / name).read_bytes()).hexdigest() == digest for name, digest in manifest.items())
def run(command, name):
    with (output / (name + '.out')).open('wb') as stdout, (output / (name + '.err')).open('wb') as stderr:
        return subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr).returncode
assert reviewed_unchanged()
build_status = run(['make', 'build'], 'final-build')
if build_status:
    (output / 'final-result.json').write_text(json.dumps({'build_exit': build_status, 'green': False}) + '\n')
    sys.exit(build_status)
helper = output / 'helpers/summarize.py'
subprocess.run(['python3', '-I', str(helper), 'hashes', str(output / 'final-before-hashes.json')], cwd=repo, check=True)
command = ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']
with (output / 'final.jsonl').open('wb') as stdout, (output / 'final.err').open('wb') as stderr:
    status = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr).returncode
with (output / 'final-summary.json').open('wb') as stdout:
    subprocess.run(['python3', '-I', str(helper), 'events', str(output / 'final.jsonl')], cwd=repo, stdout=stdout, check=True)
subprocess.run(['python3', '-I', str(helper), 'hashes', str(output / 'final-after-hashes.json')], cwd=repo, check=True)
before = json.loads((output / 'final-before-hashes.json').read_text())
after = json.loads((output / 'final-after-hashes.json').read_text())
summary = json.loads((output / 'final-summary.json').read_text())
unchanged = before == after
reviewed = reviewed_unchanged()
packages_green = len(summary['packages']) == 10 and all(item['action'] == 'pass' for item in summary['packages'])
green = status == 0 and unchanged and reviewed and packages_green and not summary['failures']
result = {'build_exit': build_status, 'suite_exit': status, 'sources_and_cli_unchanged': unchanged, 'reviewed_files_unchanged': reviewed, 'source_files': len(before['sources']), 'reviewed_files': len(manifest), 'cli_sha256': before['cli'], 'events': summary['events'], 'corpus': summary['corpus'], 'all_ten_packages_pass': packages_green, 'stderr_bytes': (output / 'final.err').stat().st_size, 'green': green}
(output / 'final-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2), flush=True)
sys.exit(0 if green else status or 2)
