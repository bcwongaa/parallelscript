import json
import os
import pathlib
import subprocess
import sys

repo, output, base, current = map(pathlib.Path, sys.argv[1:5])
output.mkdir()
source = repo / 'pts/tests/run/generic_inline_container_sources.pts'
text = source.read_text()
expected = ''.join(line.removeprefix('// ') + '\n' for line in text.split('// expect:\n', 1)[1].splitlines() if line.startswith('// '))
assert len(expected.splitlines()) == 22
node = pathlib.Path.home() / '.local/node/bin/node'
twin = output / 'fixture.mts'
twin.write_text(text)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
rows = []
def run(command, prefix):
    result = subprocess.run(command, env=env, capture_output=True, timeout=300)
    (output / (prefix + '.stdout')).write_bytes(result.stdout)
    (output / (prefix + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (prefix, result.returncode, result.stderr.decode())
    return result.stdout.decode()
assert run([str(node), '--no-warnings', '--experimental-transform-types', str(twin)], 'node') == expected
for label, compiler in [('base', base), ('current', current)]:
    c = output / (label + '.c')
    binary = output / (label + '.bin')
    run([str(compiler), str(source), str(c), str(binary)], label + '-compile')
    assert run([str(binary)], label + '-native') == expected
    binary.unlink()
    rows.append({'compiler': label, 'strict_allinstances_native_matches_node': True, 'expected_lines': 22})
(output / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows))
