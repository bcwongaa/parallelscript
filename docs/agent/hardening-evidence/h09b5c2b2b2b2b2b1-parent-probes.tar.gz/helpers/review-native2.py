import ast
import hashlib
import json
import os
import pathlib
import subprocess
import sys

repo, inputs, output, base, current = map(pathlib.Path, sys.argv[1:6])
output.mkdir()
module = ast.parse((inputs.parent / 'native_cases.py').read_text())
constants = {}
for statement in module.body:
    if isinstance(statement, ast.Assign) and len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name) and statement.targets[0].id in ('PRELUDE', 'CASES'):
        constants[statement.targets[0].id] = ast.literal_eval(statement.value)
for name, body in constants['CASES'].items():
    expected = constants['PRELUDE'] + body
    assert (inputs / (name + '.pts')).read_text() == expected
    assert (inputs / (name + '.mts')).read_text() == expected
assert len(constants['CASES']) == 8
node = pathlib.Path.home() / '.local/node/bin/node'
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1', PTS_THREADS='1')
rows = []
unsupported = []
def run(command, prefix, run_env):
    result = subprocess.run(command, env=run_env, capture_output=True, timeout=300)
    (output / (prefix + '.stdout')).write_bytes(result.stdout)
    (output / (prefix + '.stderr')).write_bytes(result.stderr)
    return result
for source in sorted(inputs.glob('*.pts')):
    name = source.stem
    oracle = run([str(node), '--no-warnings', '--experimental-transform-types', str(source.with_suffix('.mts'))], name + '.node', env)
    assert oracle.returncode == 0, (name, oracle.stderr)
    for mode in ('all', 'default'):
        for label, compiler in [('base', base), ('current', current)]:
            prefix = name + '.' + label + '.' + mode
            c = output / (prefix + '.c')
            binary = output / (prefix + '.bin')
            compiled = run([str(compiler), mode, str(source), str(c), str(binary)], prefix + '.compile', env)
            row = {'case': name, 'compiler': label, 'mode': mode, 'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}
            if name == 'declared_method_contract':
                assert compiled.returncode == 1 and b'error PTS1001: using a' in compiled.stderr and b'whose `make` it doesn\'t provide with the same types, is not supported yet' in compiled.stderr, (prefix, compiled.returncode, compiled.stderr)
                assert not compiled.stdout and not binary.exists()
                unsupported.append(compiled.stderr)
                row['status'] = 'unchanged unsupported PTS1001'
            else:
                assert compiled.returncode == 0, (prefix, compiled.returncode, compiled.stderr)
                native_env = dict(env)
                if name == 'closure_gc':
                    native_env.update(GC_INITIAL_HEAP_SIZE='65536', GC_FREE_SPACE_DIVISOR='1', GC_PRINT_STATS='1')
                native = run([str(binary)], prefix + '.native', native_env)
                assert native.returncode == 0 and native.stdout == oracle.stdout, (prefix, native.returncode, native.stderr)
                binary.unlink()
                gc = native.stderr.count(b'Complete collection took')
                if name == 'closure_gc':
                    assert gc > 0, (prefix, native.stderr[:1500])
                row.update(status='native matches strict Node', c_sha256=hashlib.sha256(c.read_bytes()).hexdigest(), completed_gc_markers=gc)
            rows.append(row)
            (output / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
            print(prefix, row['status'], row.get('completed_gc_markers', ''), flush=True)
assert len(rows) == 32 and len(unsupported) == 4 and all(error == unsupported[0] for error in unsupported)
assert sum(row['status'] == 'native matches strict Node' for row in rows) == 28
print('28 strict/default base/current native matches; four byte-identical unsupported PTS1001 outcomes')
