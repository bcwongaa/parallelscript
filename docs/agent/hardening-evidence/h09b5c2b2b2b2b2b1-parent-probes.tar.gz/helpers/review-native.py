import ast
import hashlib
import json
import os
import pathlib
import subprocess
import sys

repo, inputs, output, base, current = map(pathlib.Path, sys.argv[1:6])
output.mkdir()
module = ast.parse((inputs.parent / 'native_cases.py').read_text())
constants = {}
for statement in module.body:
    if isinstance(statement, ast.Assign) and len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name) and statement.targets[0].id in ('PRELUDE', 'CASES'):
        constants[statement.targets[0].id] = ast.literal_eval(statement.value)
for name, body in constants['CASES'].items():
    expected = constants['PRELUDE'] + body
    assert (inputs / (name + '.pts')).read_text() == expected
    assert (inputs / (name + '.mts')).read_text() == expected
assert len(constants['CASES']) == 8
node = pathlib.Path.home() / '.local/node/bin/node'
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1', PTS_THREADS='1')
rows = []
def run(command, prefix, run_env):
    result = subprocess.run(command, env=run_env, capture_output=True, timeout=300)
    (output / (prefix + '.stdout')).write_bytes(result.stdout)
    (output / (prefix + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (prefix, result.returncode, result.stderr.decode()[:1500])
    return result
for source in sorted(inputs.glob('*.pts')):
    name = source.stem
    oracle = run([str(node), '--no-warnings', '--experimental-transform-types', str(source.with_suffix('.mts'))], name + '.node', env)
    for label, compiler in [('base', base), ('current', current)]:
        prefix = name + '.' + label
        c = output / (prefix + '.c')
        binary = output / (prefix + '.bin')
        run([str(compiler), str(source), str(c), str(binary)], prefix + '.compile', env)
        native_env = dict(env)
        if name == 'closure_gc':
            native_env.update(GC_INITIAL_HEAP_SIZE='65536', GC_FREE_SPACE_DIVISOR='1', GC_PRINT_STATS='1')
        native = run([str(binary)], prefix + '.native', native_env)
        assert native.stdout == oracle.stdout, prefix
        binary.unlink()
        gc = native.stderr.count(b'Complete collection took')
        if name == 'closure_gc':
            assert gc > 0, (prefix, native.stderr.decode()[:1500])
        rows.append({'case': name, 'compiler': label, 'strict_allinstances_node_match': True, 'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'c_sha256': hashlib.sha256(c.read_bytes()).hexdigest(), 'completed_gc_markers': gc})
        (output / 'results.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(prefix, 'match', 'GC markers', gc, flush=True)
assert len(rows) == 16
