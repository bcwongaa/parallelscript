# D-212 parent evidence and replay

2026-10-22. Source base50d8ed087bf5836cb2fc912076e905d629b570e6, planning checkpointa53542e52. Named isolated reproducera41c84f2e415eee69/revieweradf3eb54bc2755e96; inherited gpt-6.1-sol, configured/requested xhigh. No nested agents. Only the bounded fresh-inline-extraction slice is reviewed, not H09b5b or broader flow.

Unpack evidence into a new empty DATA directory, inspect source before execution, and copy trusted helpers into a separate HELPER directory. Run Python with `-I` from the repository, not an extracted-data cwd. Overlay paths preserve the original absolute execution paths for provenance; rebase both repository and snapshot/helper prefixes in copied JSON before replay. Initialize the repository's documented third-party submodules for native compilation. Binaries and duplicate full runtime sources are deliberately omitted.

## Replay commands and original outputs

Commands below are equivalent replay recipes with paths rebased by the reader; raw receipts and preserved scripts retain the original execution context. The full baseline/final suite command is exact. The wrapper additionally hashes selected sources and CLI before/after and verifies final eight reviewed hashes:

```sh
make build
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/
```

Frozen new source/driver tables RED on unchanged base, then GREEN (no new-test byte changed between RED and corrected GREEN):

```sh
GOMAXPROCS=2 go test -count=1 -json -p 1 -parallel 2 -timeout 15m ./pts/lower ./pts/driver -run '^TestInlineContainer'
GOMAXPROCS=2 go test -count=1 -json -p 1 -parallel 2 -timeout 15m ./pts/lower ./pts/driver
```

`red.*` is the original339pass/125fail; `green.*` preserves the incomplete428pass/36fail first candidate; `green2.*` is corrected464pass. `affected1.*` retains2371pass/2fail for the obsolete safe-inline negative; `affected2.*` is2372pass after only that negative is removed, its exact source retained as a dual-kind positive. `review-snapshot1/` preserves the first candidate and `debug1/` the nested-checker-identity diagnosis; snapshot2 production equals final snapshot3. Historical wrong inputs/expectations are never silently overwritten.

Parent strict/default native and explicit generic clang gates:

```sh
GOMAXPROCS=1 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 1 -parallel 1 -timeout 20m ./pts/tests -run '^(TestRun|TestRunMatchesNode)$/^generic_inline_container_sources$'
GOMAXPROCS=1 PTS_REQUIRE_NODE=1 PTS_SMOKE_CLANG=1 PTS_SMOKE_MUTANTS=0 PTS_SMOKE_JOBS=1 PTS_SMOKE_FILTER=generic go test -count=1 -json -p 1 -parallel 1 -timeout 20m ./pts/tests -run '^TestCompilerFailsCleanly$'
```

Strict helper emits `driver.EmitCWith(..., lower.AllInstances)`, then compiles exactly that C. From repository cwd:

```sh
GOMAXPROCS=1 go build -overlay "$HELPER/base/overlay.json" -o "$OUT/strict-base" "$HELPER/strict.go"
GOMAXPROCS=1 go build -o "$OUT/strict-current" "$HELPER/strict.go"
python3 -I "$HELPER/growth.py" "$REPO" "$NEW_GROWTH_OUTPUT" "$OUT/strict-base" "$OUT/strict-current"
python3 -I "$HELPER/semantics.py" "$REPO" "$NEW_SEMANTICS_OUTPUT" "$OUT/strict-base" "$OUT/strict-current"
python3 -I "$HELPER/mutants.py" "$REPO" "$NEW_MUTANT_OUTPUT"
```

Production source overlays, not stash/worktree restoration, construct exact base. The base's two production files and hashes are retained under `helpers/base/`. For final-snapshot replay rather than checked-out current, add the eight snapshot paths to a Go overlay. Growth stores exact required/excluded target inventories, generated C, line/byte/hash counts and Node/native stdout, interleaves base/current order and removes per-case binaries. Timings diagnostic only. `growth/final-current-hashes.json` is the independent final-source re-emission receipt. Mutation kills require actual assertion failures and no build failure; `mutants/results.json` records all three compiling kills.

Independent reviewer source replay uses inspected frozen new Go probes in `reviewer-input/`, plus separately written parent overlay JSON in `helpers/review-{base,current}-overlay.json`:

```sh
GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 15m -overlay "$HELPER/review-base-overlay.json" ./pts/lower ./pts/driver -run '^TestReviewerD212'
GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 15m -overlay "$HELPER/review-current-overlay.json" ./pts/lower ./pts/driver -run '^TestReviewerD212'
```

The raw logs are authoritative for test names/commands if relocating overlays. Parent helper `native-reviewed.go` separately calls exact AllInstances/default APIs; build exact-base/current variants with the same production overlays, then run:

```sh
python3 -I "$HELPER/review-native3.py" "$REPO" "$DATA/reviewer-input/inputs" "$NEW_NATIVE_OUTPUT" "$OUT/review-helper-base" "$OUT/review-helper-current"
```

The parent does not execute the supplied reviewer Python. Their generator's literal PRELUDE/CASES is statically parsed and checked against all eight unchanged .pts/.mts twins. The trusted runner requires all24 supported native stdout/exit matches and the exact eight unchanged unsupported PTS1001 outcomes across both compilers/APIs. First fail-fast replay scripts/results remain under `review-native/` and `review-native2/`; authoritative completed classification is `review-native3/results.json`. Each of four closure_gc executions observes168 completed collection markers with PTS_THREADS=1, not a general parallel-race proof.

Reviewer original snapshots/setup failures and first missing-submodule native replay live in the separate reviewer archive. Parent retains1516-file runtime manifest/submodule versions, not the duplicate runtime home. Reproducer's optional local worktree-verifier denials live in the separate reproducer archive, are not provider refusals and do not count as executions. No denied optional wrapper is replayed to bypass that boundary.

## Raw streams and immutable receipts

Baseline raw JSONL is retained in this parent archive. Final raw JSONL is compressed separately beside it as the task's `-final-suite.jsonl.gz`; final summary/result and before/after source/CLI hashes are also retained here. `helpers/final-suite.py` records actual exit codes, all ten package results, corpus counts, stderr size and hash invariants. No compiler/runtime/test inputs or child heavy jobs overlapped that final suite. Both child archives are independently path/type/hash validated; their scripts are data, not automatically executed. No CI command ran after the sole startup query.
