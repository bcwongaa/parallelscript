module helloreset

go 1.26
