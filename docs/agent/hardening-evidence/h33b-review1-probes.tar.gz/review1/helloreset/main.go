// Sends a whole ClientHello and resets the connection a moment later, many times: does the server survive?
package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"math/rand/v2"
	"net"
	"os"
	"strconv"
	"time"
)

func main() {
	addr := os.Args[1]
	n, _ := strconv.Atoi(os.Args[2])
	client, server := net.Pipe()
	go func() { tls.Client(client, &tls.Config{ServerName: "localhost"}).Handshake(); client.Close() }()
	header := make([]byte, 5)
	io.ReadFull(server, header)
	body := make([]byte, int(header[3])<<8|int(header[4]))
	io.ReadFull(server, body)
	hello := append(header, body...)
	for i := 0; i < n; i++ {
		c, err := net.Dial("tcp", addr)
		if err != nil {
			fmt.Println("attempt", i, "dial:", err)
			return
		}
		c.Write(hello)
		time.Sleep(time.Duration(rand.IntN(1500)) * time.Microsecond)
		c.(*net.TCPConn).SetLinger(0)
		c.Close()
	}
	fmt.Println("server survived", n, "attempts")
}
