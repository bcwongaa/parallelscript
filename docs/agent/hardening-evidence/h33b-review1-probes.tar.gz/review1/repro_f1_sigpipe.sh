#!/bin/bash
# R1-F1: clients that pipeline requests for large answers and then reset kill a pts:http server by SIGPIPE.
# Usage: repro_f1_sigpipe.sh <path to pts> plain|tls   (tls needs the change's compiler)
PTS=$1; mode=$2
D=/tmp/h33b/review1
src=$D/srv/probe_server_plain.pts; [ $mode = tls ] && src=$D/srv/probe_server.pts
"$PTS" build $src -o $D/f1_server.bin >/dev/null || exit 1
P=0; flag=""; [ $mode = plain ] && { P=1; flag=-plain; }
PLAIN=$P CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 $D/f1_server.bin > $D/f1.out 2> $D/f1.err &
pid=$!
for i in $(seq 1 50); do grep -q '^port' $D/f1.out && break; sleep 0.1; done
port=$(awk '/^port/{print $2}' $D/f1.out)
$D/sigpipe/sigpipe 127.0.0.1:$port $mode
kill -0 $pid 2>/dev/null && $D/stress/stress -addr 127.0.0.1:$port -ca $D/certs/ca.pem $flag -workers 8 -d 5s -modes pipeline-reset | head -1
kill $pid 2>/dev/null; wait $pid; st=$?
echo "$mode with $PTS: server exit status $st $( [ $st -gt 128 ] && kill -l $((st-128)) ) (143 = still alive and killed by the script), stderr $(wc -c < $D/f1.err) bytes"
rm -f $D/f1_server.bin
