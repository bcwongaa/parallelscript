#!/bin/bash
# usage: stop_under_load.sh <binary> <tag> <stop-path> [stress args]: stops the server while the stress runs
bin=$1; tag=$2; stoppath=$3; shift 3
[ "${IGNPIPE:-1}" = 1 ] && trap "" PIPE
ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=print_stacktrace=1 CERT_FILE=/tmp/h33b/review1/certs/ec.pem KEY_FILE=/tmp/h33b/review1/certs/ec-key.pem PTS_THREADS=${THREADS:-4} REUSE=${REUSE:-1} taskset -c ${CPUS:-0,1} "$bin" > $tag.out 2> $tag.err &
pid=$!
for i in $(seq 1 100); do grep -q '^port' $tag.out 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2; exit}' $tag.out)
GOMAXPROCS=2 taskset -c ${CPUS:-0,1} /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca /tmp/h33b/review1/certs/ca.pem "$@" > $tag.stress 2>&1 &
spid=$!
sleep ${AFTER:-4}
curl -s -m 5 --cacert /tmp/h33b/review1/certs/ca.pem "https://localhost:$port$stoppath"; echo
for i in $(seq 1 200); do kill -0 $pid 2>/dev/null || break; sleep 0.05; done
if kill -0 $pid 2>/dev/null; then echo "HANG: server alive 10 s after $stoppath"; ls -la /proc/$pid/fd | wc -l; ss -tnp 2>/dev/null | grep -c "pid=$pid,"; kill -9 $pid; fi
wait $pid; st=$?
echo "server exit status $st $( [ $st -gt 128 ] && kill -l $((st-128)) )"
wait $spid; head -3 $tag.stress
echo "stderr bytes: $(wc -c < $tag.err)"; head -c 3000 $tag.err
