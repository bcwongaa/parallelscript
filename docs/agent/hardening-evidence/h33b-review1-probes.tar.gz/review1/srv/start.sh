#!/bin/bash
# usage: start.sh <binary> <tag> [env...]; writes <tag>.pid, <tag>.port, <tag>.out, <tag>.err
bin=$1; tag=$2; shift 2
env CERT_FILE=/tmp/h33b/review1/certs/ec.pem KEY_FILE=/tmp/h33b/review1/certs/ec-key.pem "$@" setsid "$bin" > "$tag.out" 2> "$tag.err" &
echo $! > "$tag.pid"
for i in $(seq 1 100); do
  if grep -q '^port' "$tag.out" 2>/dev/null; then break; fi
  sleep 0.05
done
awk '/^port/{print $2; exit}' "$tag.out" > "$tag.port"
echo "pid $(cat $tag.pid) port $(cat $tag.port)"
