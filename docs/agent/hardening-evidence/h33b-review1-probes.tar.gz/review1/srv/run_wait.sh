#!/bin/bash
# usage: run_wait.sh <binary> <tag> <stress args...>: runs the server, stresses it, reports how it ended
bin=$1; tag=$2; shift 2
[ "${IGNPIPE:-1}" = 1 ] && trap "" PIPE
ASAN_OPTIONS=${ASAN_OPTIONS:-detect_leaks=0:detect_stack_use_after_return=0} UBSAN_OPTIONS=print_stacktrace=1 CERT_FILE=/tmp/h33b/review1/certs/ec.pem KEY_FILE=/tmp/h33b/review1/certs/ec-key.pem PTS_THREADS=${THREADS:-4} REUSE=${REUSE:-1} PLAIN=${PLAIN:-0} taskset -c ${CPUS:-0,1} "$bin" > $tag.out 2> $tag.err &
pid=$!
for i in $(seq 1 100); do grep -q '^port' $tag.out 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2; exit}' $tag.out)
GOMAXPROCS=2 taskset -c ${CPUS:-0,1} /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca /tmp/h33b/review1/certs/ca.pem "$@" | head -8
if kill -0 $pid 2>/dev/null; then
  echo "server alive; stopping"
  curl -s --cacert /tmp/h33b/review1/certs/ca.pem https://localhost:$port/stop -o /dev/null; curl -s http://127.0.0.1:$port/stop -o /dev/null
  sleep 1; kill -0 $pid 2>/dev/null && { echo "still alive after /stop; killing"; kill -9 $pid; }
fi
wait $pid; st=$?
echo "server exit status $st $( [ $st -gt 128 ] && kill -l $((st-128)) )"
echo "stderr bytes: $(wc -c < $tag.err)"; head -c 2000 $tag.err
