// Posts bodies at and over the 64 MB limit over TLS (or plain) and reports what comes back.
package main

import (
	"bytes"
	"crypto/tls"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"time"
)

func main() {
	base := os.Args[1]
	client := &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}}, Timeout: 120 * time.Second}
	for _, size := range []int{64 << 20, 64<<20 + 1} {
		start := time.Now()
		resp, err := client.Post(base+"/len", "text/plain", bytes.NewReader(bytes.Repeat([]byte("a"), size)))
		if err != nil {
			fmt.Println(size, "error:", err)
			continue
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		n, _ := strconv.Atoi(string(body))
		fmt.Println(size, resp.Status, "server saw", n, "ok:", n == size || resp.StatusCode == 413, time.Since(start).Round(time.Millisecond))
	}
	resp, err := client.Get(base + "/big?" + strconv.Itoa(60<<20))
	if err != nil {
		fmt.Println("big get error:", err)
		return
	}
	body, _ := io.ReadAll(resp.Body)
	fmt.Println("60 MB answer:", len(body) == 60<<20)
}
