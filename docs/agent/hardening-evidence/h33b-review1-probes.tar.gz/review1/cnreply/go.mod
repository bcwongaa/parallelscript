module cnreply

go 1.26
