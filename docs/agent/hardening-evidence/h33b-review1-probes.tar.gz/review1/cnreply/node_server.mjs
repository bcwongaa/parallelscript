import https from "node:https";
import fs from "node:fs";
const server = https.createServer({ cert: fs.readFileSync(process.argv[2]), key: fs.readFileSync(process.argv[3]) }, (req, res) => res.end("hello"));
server.listen(0, "127.0.0.1", () => console.log("port", server.address().port));
