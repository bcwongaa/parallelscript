// After a request is answered, the client sends close_notify (CloseWrite) on the idle keep-alive
// connection: does the server answer with a close_notify of its own before its TCP close?
package main

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"sync"
	"time"
)

type rec struct {
	net.Conn
	mu      sync.Mutex
	pending []byte
	types   []byte
}

func (c *rec) Read(p []byte) (int, error) {
	n, err := c.Conn.Read(p)
	c.mu.Lock()
	c.pending = append(c.pending, p[:n]...)
	for len(c.pending) >= 5 {
		l := int(c.pending[3])<<8 | int(c.pending[4])
		if len(c.pending) < 5+l {
			break
		}
		c.types = append(c.types, c.pending[0])
		c.pending = c.pending[5+l:]
	}
	c.mu.Unlock()
	return n, err
}

func main() {
	for _, v := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		tcp, err := net.Dial("tcp", os.Args[1])
		if err != nil {
			panic(err)
		}
		r := &rec{Conn: tcp}
		c := tls.Client(r, &tls.Config{InsecureSkipVerify: true, MinVersion: v, MaxVersion: v})
		c.SetDeadline(time.Now().Add(5 * time.Second))
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
		br := bufio.NewReader(c)
		resp, err := http.ReadResponse(br, nil)
		if err != nil {
			fmt.Println(err)
			continue
		}
		io.ReadAll(resp.Body)
		r.mu.Lock()
		before := len(r.types)
		r.mu.Unlock()
		c.CloseWrite()
		_, err = io.ReadAll(br)
		r.mu.Lock()
		after := r.types[before:]
		r.mu.Unlock()
		fmt.Printf("%s: after the client's close_notify the server sent records of types %v, then read ended with %v\n", tls.VersionName(v), after, err)
		c.Close()
	}
}
