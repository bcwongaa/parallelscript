# Sends a request on a TLS connection, reads the answer, then does a TLS shutdown (unwrap), which waits for the peer's close_notify.
import socket, ssl, sys
port, ca = int(sys.argv[1]), sys.argv[2]
for version in (ssl.TLSVersion.TLSv1_2, ssl.TLSVersion.TLSv1_3):
    ctx = ssl.create_default_context(cafile=ca)
    ctx.minimum_version = ctx.maximum_version = version
    with socket.create_connection(("127.0.0.1", port)) as raw:
        s = ctx.wrap_socket(raw, server_hostname="localhost")
        s.sendall(b"GET /hello HTTP/1.1\r\nHost: a\r\n\r\n")
        data = b""
        while not data.endswith(b"hello"):
            data += s.recv(4096)
        try:
            s.unwrap()
            print(version.name, "unwrap: the server answered close_notify")
        except Exception as e:
            print(version.name, "unwrap:", type(e).__name__, e)
