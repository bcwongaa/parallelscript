// One client that pipelines requests for large responses, then resets: the server's next write gets EPIPE.
package main

import (
	"crypto/tls"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

func main() {
	addr, useTLS := os.Args[1], len(os.Args) > 2 && os.Args[2] == "tls"
	for i := 0; i < 20; i++ {
		tcp, err := net.Dial("tcp", addr)
		if err != nil {
			fmt.Println("attempt", i, "dial:", err)
			return
		}
		var c net.Conn = tcp
		if useTLS {
			t := tls.Client(tcp, &tls.Config{InsecureSkipVerify: true})
			if err := t.Handshake(); err != nil {
				fmt.Println("handshake:", err)
				return
			}
			c = t
		}
		c.Write([]byte(strings.Repeat("GET /big?100000 HTTP/1.1\r\nHost: a\r\n\r\n", 100)))
		time.Sleep(20 * time.Millisecond)
		tcp.(*net.TCPConn).SetLinger(0)
		tcp.Close()
		time.Sleep(50 * time.Millisecond)
	}
	fmt.Println("server survived 20 attempts")
}
