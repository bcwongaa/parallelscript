module sigpipe

go 1.26
