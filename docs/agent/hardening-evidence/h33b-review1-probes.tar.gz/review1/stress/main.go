// Review stress client for H33b: mixes good requests with abusive clients against one server.
package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"flag"
	"fmt"
	"io"
	"math/rand/v2"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var (
	addr     = flag.String("addr", "127.0.0.1:0", "server")
	caFile   = flag.String("ca", "", "CA PEM")
	workers  = flag.Int("workers", 16, "goroutines")
	duration = flag.Duration("d", 10*time.Second, "how long")
	plain    = flag.Bool("plain", false, "plain HTTP")
	modes    = flag.String("modes", "", "comma list of modes (default all)")
)

var roots *x509.CertPool

func cfg() *tls.Config {
	return &tls.Config{RootCAs: roots, ServerName: "localhost", MinVersion: tls.VersionTLS12, MaxVersion: []uint16{tls.VersionTLS12, tls.VersionTLS13}[rand.IntN(2)]}
}

func dial() (net.Conn, error) {
	c, err := net.DialTimeout("tcp", *addr, 5*time.Second)
	if err != nil {
		return nil, err
	}
	if *plain {
		return c, nil
	}
	t := tls.Client(c, cfg())
	t.SetDeadline(time.Now().Add(10 * time.Second))
	if err := t.Handshake(); err != nil {
		c.Close()
		return nil, err
	}
	return t, nil
}

func reset(c net.Conn) {
	if t, ok := c.(*tls.Conn); ok {
		c = t.NetConn()
	}
	if tc, ok := c.(*net.TCPConn); ok {
		tc.SetLinger(0)
	}
	c.Close()
}

var (
	ok, bad, errs atomic.Int64
	badMu         sync.Mutex
	badSamples    []string
)

func fail(format string, args ...any) {
	bad.Add(1)
	badMu.Lock()
	if len(badSamples) < 20 {
		badSamples = append(badSamples, fmt.Sprintf(format, args...))
	}
	badMu.Unlock()
}

func request(c net.Conn, raw string, want string) bool {
	c.SetDeadline(time.Now().Add(15 * time.Second))
	if _, err := c.Write([]byte(raw)); err != nil {
		errs.Add(1)
		return false
	}
	r := bufio.NewReader(c)
	resp, err := http.ReadResponse(r, nil)
	if err != nil {
		fail("read response: %v", err)
		return false
	}
	body, err := io.ReadAll(resp.Body)
	resp.Body.Close()
	if err != nil {
		fail("read body: %v", err)
		return false
	}
	if want != "" && string(body) != want {
		fail("body %q... want %q", trunc(string(body)), trunc(want))
		return false
	}
	ok.Add(1)
	return true
}

func trunc(s string) string {
	if len(s) > 40 {
		return s[:40]
	}
	return s
}

var hello []byte

func run(mode string) {
	switch mode {
	case "fresh": // a whole request on a fresh connection
		c, err := dial()
		if err != nil {
			fail("dial fresh: %v", err)
			return
		}
		request(c, "GET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n", "hello")
		c.Close()
	case "keepalive":
		c, err := dial()
		if err != nil {
			fail("dial keepalive: %v", err)
			return
		}
		r := bufio.NewReader(c)
		for i := 0; i < 20; i++ {
			body := strings.Repeat("k", rand.IntN(20000))
			c.SetDeadline(time.Now().Add(15 * time.Second))
			fmt.Fprintf(c, "POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: %d\r\n\r\n%s", len(body), body)
			resp, err := http.ReadResponse(r, nil)
			if err != nil {
				fail("keepalive response %d: %v", i, err)
				break
			}
			got, err := io.ReadAll(resp.Body)
			resp.Body.Close()
			if err != nil || string(got) != body {
				fail("keepalive body %d: %v len %d want %d", i, err, len(got), len(body))
				break
			}
			ok.Add(1)
		}
		c.Close()
	case "pipeline":
		c, err := dial()
		if err != nil {
			fail("dial pipeline: %v", err)
			return
		}
		n := 50 + rand.IntN(200)
		go func() { c.Write([]byte(strings.Repeat("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n", n))) }()
		r := bufio.NewReader(c)
		c.SetDeadline(time.Now().Add(15 * time.Second))
		for i := 0; i < n; i++ {
			resp, err := http.ReadResponse(r, nil)
			if err != nil {
				fail("pipeline %d/%d: %v", i, n, err)
				break
			}
			got, _ := io.ReadAll(resp.Body)
			resp.Body.Close()
			if string(got) != "hello" {
				fail("pipeline body %q", got)
				break
			}
			ok.Add(1)
		}
		c.Close()
	case "pipeline-reset": // pipelines many and resets without reading
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte(strings.Repeat("GET /big?100000 HTTP/1.1\r\nHost: a\r\n\r\n", 100)))
		time.Sleep(time.Duration(rand.IntN(20)) * time.Millisecond)
		reset(c)
	case "bigread-reset": // reads part of a big response, then resets
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte("GET /big?3000000 HTTP/1.1\r\nHost: a\r\n\r\n"))
		buf := make([]byte, rand.IntN(200000)+1)
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadFull(c, buf)
		reset(c)
	case "bigread-close":
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte("GET /bigclose?2000000 HTTP/1.1\r\nHost: a\r\n\r\n"))
		buf := make([]byte, rand.IntN(200000)+1)
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadFull(c, buf)
		c.Close()
	case "closewrite-after-request": // request then close_notify, keep reading
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
		if t, ok := c.(*tls.Conn); ok {
			t.CloseWrite()
		} else {
			c.(*net.TCPConn).CloseWrite()
		}
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadAll(c)
		c.Close()
	case "closewrite-hold":
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte("GET /hold HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(time.Duration(rand.IntN(10)) * time.Millisecond)
		if t, ok := c.(*tls.Conn); ok {
			t.CloseWrite()
		} else {
			c.(*net.TCPConn).CloseWrite()
		}
		c.SetDeadline(time.Now().Add(5 * time.Second))
		io.ReadAll(c)
		c.Close()
	case "hold-reset":
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte("GET /hold HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(time.Duration(rand.IntN(10)) * time.Millisecond)
		reset(c)
	case "sleep-reset": // reset while the handler sleeps, then it answers into a closed connection
		c, err := dial()
		if err != nil {
			return
		}
		c.Write([]byte(fmt.Sprintf("GET /sleep?%d HTTP/1.1\r\nHost: a\r\n\r\n", rand.IntN(20))))
		time.Sleep(time.Duration(rand.IntN(20)) * time.Millisecond)
		reset(c)
	case "handshake-reset": // partial handshake then reset
		if *plain {
			return
		}
		c, err := net.DialTimeout("tcp", *addr, 5*time.Second)
		if err != nil {
			return
		}
		c.Write(hello[:rand.IntN(len(hello))])
		time.Sleep(time.Duration(rand.IntN(5)) * time.Millisecond)
		reset(c)
	case "handshake-mid": // a Go handshake killed at a random moment
		if *plain {
			return
		}
		c, err := net.DialTimeout("tcp", *addr, 5*time.Second)
		if err != nil {
			return
		}
		t := tls.Client(c, cfg())
		go func() { time.Sleep(time.Duration(rand.IntN(3000)) * time.Microsecond); reset(c) }()
		t.Handshake()
	case "garbage":
		c, err := net.DialTimeout("tcp", *addr, 5*time.Second)
		if err != nil {
			return
		}
		g := make([]byte, rand.IntN(3000)+1)
		for i := range g {
			g[i] = byte(rand.IntN(256))
		}
		if rand.IntN(2) == 0 {
			g[0] = 0x16
		}
		c.Write(g)
		c.SetDeadline(time.Now().Add(3 * time.Second))
		io.ReadAll(c)
		c.Close()
	case "tls-then-garbage": // a good handshake then bytes that aren't records
		if *plain {
			return
		}
		c, err := dial()
		if err != nil {
			return
		}
		c.(*tls.Conn).NetConn().Write([]byte("\x17\x03\x03\x00\x20garbagegarbagegarbagegarbage1234"))
		c.SetDeadline(time.Now().Add(3 * time.Second))
		io.ReadAll(c)
		c.Close()
	case "split": // a request whose records come in random sizes, a request straddling records
		c, err := dial()
		if err != nil {
			return
		}
		body := strings.Repeat("s", rand.IntN(70000))
		raw := fmt.Sprintf("POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: %d\r\n\r\n%s", len(body), body)
		go func() {
			for len(raw) > 0 {
				n := rand.IntN(3000) + 1
				if n > len(raw) {
					n = len(raw)
				}
				c.Write([]byte(raw[:n]))
				raw = raw[n:]
			}
		}()
		r := bufio.NewReader(c)
		c.SetDeadline(time.Now().Add(15 * time.Second))
		resp, err := http.ReadResponse(r, nil)
		if err != nil {
			fail("split: %v", err)
		} else {
			got, _ := io.ReadAll(resp.Body)
			if string(got) != body {
				fail("split body len %d want %d", len(got), len(body))
			} else {
				ok.Add(1)
			}
		}
		c.Close()
	case "idle": // a connection that handshakes and then sits
		c, err := dial()
		if err != nil {
			return
		}
		time.Sleep(time.Duration(rand.IntN(300)) * time.Millisecond)
		c.Close()
	case "throw":
		c, err := dial()
		if err != nil {
			fail("dial throw: %v", err)
			return
		}
		request(c, "GET /throw HTTP/1.1\r\nHost: a\r\n\r\n", "error: thrown on purpose")
		c.Close()
	case "badreq": // a malformed request, 400 then close_notify
		c, err := dial()
		if err != nil {
			return
		}
		c.SetDeadline(time.Now().Add(5 * time.Second))
		c.Write([]byte("NOT HTTP\r\n\r\n"))
		got, _ := io.ReadAll(c)
		if !strings.HasPrefix(string(got), "HTTP/1.1 400") {
			fail("badreq got %q", trunc(string(got)))
		} else {
			ok.Add(1)
		}
		c.Close()
	}
}

func main() {
	flag.Parse()
	if !*plain {
		pemBytes, err := os.ReadFile(*caFile)
		if err != nil {
			panic(err)
		}
		roots = x509.NewCertPool()
		roots.AppendCertsFromPEM(pemBytes)
		hello = clientHello()
	}
	all := []string{"fresh", "keepalive", "pipeline", "pipeline-reset", "bigread-reset", "bigread-close", "closewrite-after-request", "closewrite-hold", "hold-reset", "sleep-reset", "handshake-reset", "handshake-mid", "garbage", "tls-then-garbage", "split", "idle", "throw", "badreq"}
	if *modes != "" {
		all = strings.Split(*modes, ",")
	}
	end := time.Now().Add(*duration)
	var wg sync.WaitGroup
	for w := 0; w < *workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for time.Now().Before(end) {
				run(all[rand.IntN(len(all))])
			}
		}()
	}
	wg.Wait()
	// a final check that the server still answers
	if c, err := dial(); err == nil {
		request(c, "GET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n", "hello")
		c.Close()
	} else {
		fail("final dial: %v", err)
	}
	fmt.Printf("ok=%d bad=%d writeerrs=%d\n", ok.Load(), bad.Load(), errs.Load())
	for _, s := range badSamples {
		fmt.Println("  ", s)
	}
}

func clientHello() []byte {
	client, server := net.Pipe()
	defer server.Close()
	go func() { tls.Client(client, &tls.Config{ServerName: "localhost"}).Handshake(); client.Close() }()
	header := make([]byte, 5)
	io.ReadFull(server, header)
	body := make([]byte, int(header[3])<<8|int(header[4]))
	io.ReadFull(server, body)
	return append(header, body...)
}
