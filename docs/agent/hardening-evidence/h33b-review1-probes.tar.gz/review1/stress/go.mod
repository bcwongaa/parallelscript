module reviewstress

go 1.26
