#!/bin/bash
# R1-F2: the server doesn't answer a client's close_notify with its own (RFC 8446 6.1, RFC 5246 7.2.1); Node does.
D=/tmp/h33b/review1
/tmp/h33b/snap1/pts-bin/pts build $D/srv/probe_server.pts -o $D/f2_server.bin >/dev/null || exit 1
CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 $D/f2_server.bin > $D/f2.out 2> $D/f2.err &
pid=$!
for i in $(seq 1 50); do grep -q '^port' $D/f2.out && break; sleep 0.1; done
port=$(awk '/^port/{print $2}' $D/f2.out)
echo "== pts"; $D/cnreply/cnreply 127.0.0.1:$port; timeout 20 python3 -I $D/pyunwrap/unwrap.py $port $D/certs/ca.pem
kill $pid; wait $pid 2>/dev/null
~/.local/node/bin/node $D/cnreply/node_server.mjs $D/certs/ec.pem $D/certs/ec-key.pem > $D/f2n.out 2>&1 &
npid=$!; sleep 0.8; nport=$(awk '/^port/{print $2}' $D/f2n.out)
echo "== Node"; $D/cnreply/cnreply 127.0.0.1:$nport; timeout 20 python3 -I $D/pyunwrap/unwrap.py $nport $D/certs/ca.pem
kill $npid; wait $npid 2>/dev/null; rm -f $D/f2_server.bin
