module slowread

go 1.26
