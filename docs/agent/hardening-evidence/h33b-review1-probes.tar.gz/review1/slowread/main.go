// A keep-alive client that asks for 5 MB and reads it slowly while another client asks the server to stop.
package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"time"
)

func main() {
	addr, mode := os.Args[1], os.Args[2]
	tcp, _ := net.Dial("tcp", addr)
	tcp.(*net.TCPConn).SetReadBuffer(16 * 1024)
	var c net.Conn = tcp
	scheme := "http"
	if mode == "tls" {
		t := tls.Client(tcp, &tls.Config{InsecureSkipVerify: true})
		t.Handshake()
		c, scheme = t, "https"
	}
	c.Write([]byte("GET /big?5000000 HTTP/1.1\r\nHost: a\r\n\r\n"))
	time.Sleep(300 * time.Millisecond) // the answer is queued, the client hasn't read it
	client := &http.Client{Transport: &http.Transport{TLSClientConfig: &tls.Config{InsecureSkipVerify: true}}}
	if r, err := client.Get(scheme + "://" + addr + "/stop"); err == nil {
		io.ReadAll(r.Body)
		r.Body.Close()
	}
	c.SetReadDeadline(time.Now().Add(60 * time.Second))
	total := 0
	buf := make([]byte, 64*1024)
	var err error
	for {
		var n int
		n, err = c.Read(buf)
		total += n
		if err != nil {
			break
		}
	}
	fmt.Printf("%s: read %d of %d bytes before %v\n", mode, total, 5000000+117, err)
}
