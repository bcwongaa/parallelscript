// Sends a request, then half-closes (FIN for plain, close_notify for TLS), and reads what comes back.
package main

import (
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"os"
	"strings"
	"time"
)

func main() {
	addr, mode, path := os.Args[1], os.Args[2], os.Args[3]
	tcp, err := net.Dial("tcp", addr)
	if err != nil {
		panic(err)
	}
	var c net.Conn = tcp
	if mode == "tls" {
		t := tls.Client(tcp, &tls.Config{InsecureSkipVerify: true})
		if err := t.Handshake(); err != nil {
			panic(err)
		}
		c = t
	}
	c.Write([]byte("GET " + path + " HTTP/1.1\r\nHost: a\r\n\r\n"))
	if t, ok := c.(*tls.Conn); ok {
		t.CloseWrite()
	} else {
		tcp.(*net.TCPConn).CloseWrite()
	}
	c.SetReadDeadline(time.Now().Add(5 * time.Second))
	got, err := io.ReadAll(c)
	head, _, _ := strings.Cut(string(got), "\r\n")
	fmt.Printf("%s %s: %d bytes (%q), err=%v\n", mode, path, len(got), head, err)
}
