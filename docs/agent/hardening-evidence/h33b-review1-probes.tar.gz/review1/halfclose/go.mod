module halfclose

go 1.26
