module bytewise

go 1.26
