// A TLS client whose TCP writes go out one byte at a time, so the server sees every record split at every byte.
package main

import (
	"bufio"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"time"
)

type bytewise struct{ net.Conn }

func (b bytewise) Write(p []byte) (int, error) {
	for i := range p {
		if _, err := b.Conn.Write(p[i : i+1]); err != nil {
			return i, err
		}
		time.Sleep(50 * time.Microsecond)
	}
	return len(p), nil
}

func main() {
	addr, caFile := os.Args[1], os.Args[2]
	pemBytes, _ := os.ReadFile(caFile)
	roots := x509.NewCertPool()
	roots.AppendCertsFromPEM(pemBytes)
	for _, v := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		tcp, err := net.Dial("tcp", addr)
		if err != nil {
			panic(err)
		}
		tcp.(*net.TCPConn).SetNoDelay(true)
		c := tls.Client(bytewise{tcp}, &tls.Config{RootCAs: roots, ServerName: "localhost", MinVersion: v, MaxVersion: v})
		c.SetDeadline(time.Now().Add(60 * time.Second))
		if err := c.Handshake(); err != nil {
			fmt.Println(tls.VersionName(v), "handshake:", err)
			continue
		}
		body := strings.Repeat("z", 3000)
		fmt.Fprintf(c, "POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: %d\r\n\r\n%sGET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n", len(body), body)
		r := bufio.NewReader(c)
		for i := 0; i < 2; i++ {
			resp, err := http.ReadResponse(r, nil)
			if err != nil {
				fmt.Println(tls.VersionName(v), "response:", err)
				break
			}
			got, _ := io.ReadAll(resp.Body)
			fmt.Println(tls.VersionName(v), resp.Status, len(got))
		}
		rest, err := io.ReadAll(r)
		fmt.Println(tls.VersionName(v), "then", len(rest), "bytes and", err)
		c.Close()
	}
}
