#!/usr/bin/env python3
"""Reruns review probes (rounds 1-5) under Node, HEAD's CLI and the new CLI; prints per probe
the class of each CLI (OK, PTS1001, PTS9001, TYPEERR, WRONG) and flags rows where new differs."""
import subprocess, os, sys, json, shutil, concurrent.futures as cf, glob
OUT = sys.argv[1]; NEW = sys.argv[2]
clis = dict(head='/tmp/h10/s6/base/pts-bin/pts', new=NEW)
env = dict(os.environ, PTS_HOME='/tmp/h10/s6/base', TZ='America/New_York')
NODE = os.path.expanduser('~/.local/node/bin/node')
def run(cmd, cwd, extra=None):
    e = dict(env, **(extra or {}))
    try:
        p = subprocess.run(cmd, cwd=cwd, env=e, capture_output=True, text=True, timeout=120, errors='replace')
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return None, '', 'TIMEOUT'
def threads_of(src):
    for line in src.splitlines():
        if line.startswith('// threads:'):
            return line.split(':', 1)[1].split()
    return [None]
def classify(nc, no, c, o, e):
    if c == nc and o == no: return 'OK'
    if 'PTS1001' in e: return 'PTS1001'
    if 'PTS9001' in e: return 'PTS9001'
    if 'TypeError' in e or 'TypeError' in o: return 'TYPEERR'
    return 'WRONG'
def one(path):
    d, f = os.path.split(path); name = f[:-4]
    tag = d.split('/')[3] + '/' + name
    work = os.path.join(OUT, tag.replace('/', '__')); os.makedirs(work, exist_ok=True)
    src = open(path).read()
    for g in glob.glob(os.path.join(d, '*')):
        if os.path.isdir(g): shutil.copytree(g, os.path.join(work, os.path.basename(g)), dirs_exist_ok=True)
    open(os.path.join(work, name + '.mts'), 'w').write(src.replace('.par.', '.'))
    nc, no, ne = run([NODE, '--no-warnings', '--experimental-transform-types', name + '.mts'], work)
    res = {'probe': tag, 'node': [nc, no]}
    for k, cli in clis.items():
        classes = []
        for t in threads_of(src):
            c, o, e = run([cli, 'run', path], d, {'PTS_THREADS': t} if t else None)
            classes.append(classify(nc, no, c, o, e))
            res[k + (t or '')] = [c, o[-1500:], e[-800:]]
        res[k] = sorted(set(classes))[0] if len(set(classes)) == 1 else '/'.join(classes)
    return res
files = sorted(glob.glob('/tmp/h10/review[1-5]-unpacked/review[1-5]/p/*.pts'))
with cf.ThreadPoolExecutor(2) as ex:
    results = list(ex.map(one, files))
json.dump(results, open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
for r in results:
    flag = '' if r['head'] == r['new'] else '  <== changed'
    print(f"{r['probe']:58s} {r['head']:8s} {r['new']:8s}{flag}")
