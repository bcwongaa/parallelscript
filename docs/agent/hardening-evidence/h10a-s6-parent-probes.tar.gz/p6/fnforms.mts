interface Source<T> { current(): T; }
class Emitter<T> implements Source<T> {
  listeners: ((value: T) => string)[] = [];
  maybe?: (value: T) => string;
  constructor(public last: T) {}
  current(): T { return this.last; }
}
const e = new Emitter<number>(3);
e.listeners.push((v) => "a" + v, (v) => "b" + v);
e.maybe = (v) => "m" + v;
function apply(f: (v: number) => string, v: number): string { return f(v); }
function run(s: Source<number>): void {
  if (!(s instanceof Emitter)) return;
  const h = s.listeners[0];
  const m = s.maybe;
  const all = s.listeners.map((f) => f(1));
  console.log(h(2), h?.(3), m?.(4), h.call(null, 5), h.apply(null, [6]), typeof h, apply(h, 7), [1, 2].map(h), all);
  const k = h.bind(null);
  console.log(k(8), h.length, h.name === s.listeners[0].name, s.listeners.includes(h));
}
run(e);
