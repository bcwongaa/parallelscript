#!/usr/bin/env python3
"""Runs CLI on every reproducer probe that has saved .node/.head/.new outputs and compares."""
import subprocess, os, sys, glob, concurrent.futures as cf
CLI = sys.argv[1]; ROOT = sys.argv[2]; SUFFIX = sys.argv[3]
env = dict(os.environ, PTS_HOME='/tmp/h10/s6/base', TZ='America/New_York')
def one(f):
    d, b = os.path.dirname(f), os.path.basename(f)[:-4]
    node = os.path.join(d, b + '.node')
    if not os.path.exists(node):
        return None
    try:
        p = subprocess.run([CLI, 'run', b + '.pts'], cwd=d, env=env, capture_output=True, text=True, timeout=300, errors='replace')
        out = p.stdout + p.stderr + f"exit={p.returncode}\n"
    except subprocess.TimeoutExpired:
        out = "TIMEOUT\nexit=124\n"
    open(os.path.join(d, b + SUFFIX), 'w').write(out)
    rd = lambda s: open(os.path.join(d, b + s)).read() if os.path.exists(os.path.join(d, b + s)) else None
    n, h, x = rd('.node'), rd('.head'), rd('.new')
    return (os.path.relpath(f, ROOT), n == h, n == x, n == out, out == x)
files = sorted(glob.glob(ROOT + '/**/*.pts', recursive=True))
with cf.ThreadPoolExecutor(3) as ex:
    rows = [r for r in ex.map(one, files) if r]
for name, head_ok, new_ok, now_ok, same_as_new in rows:
    tag = 'OK' if now_ok else 'DIFF'
    change = '' if same_as_new else ('  FIXED' if now_ok else ('  REGRESSED' if new_ok else '  CHANGED'))
    print(f"{tag:5s} head={'ok' if head_ok else '--'} new1={'ok' if new_ok else '--'} {name}{change}")
