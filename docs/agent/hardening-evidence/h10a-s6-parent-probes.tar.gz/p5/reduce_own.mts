// H10a review round 7 (R7-F1, R7-F3; the reviewer's r7f1_reduce_fresh_accumulators.pts,
// r7f3_hands_to_named_callback.pts, kept/l_inline_push_annotated.pts): by-reference reducers
// whose initial accumulator is their own (a new object, a new Map, a local of the
// accumulator's type) get it as it is; a by-reference function that only reads its array and
// hands it to a named one-parameter callback only reads it; an annotated inline callback an
// array member keeps (`push`) holds what the instance later hands it. All as in Node.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val, val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
  }
}
function groupInto(acc: Record<string, any[]>, x: any): Record<string, any[]> {
  (acc["n"] ??= []).push(x);
  return acc;
}
function count(acc: Map<any, any[]>, x: any): Map<any, any[]> {
  acc.set(x, [x]);
  return acc;
}
function collect(acc: any[], x: any): any[] {
  acc.push(x);
  return acc;
}
function show(x: any): void {
  console.log("item", x);
}
function each(_x: any, i: number, arr: any[]): void {
  if (i === 0) arr.forEach(show);
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const start: any[] = [];
  console.log(c.items.reduce(groupInto, {}), c.items.reduce(count, new Map<any, any[]>()), c.items.reduce(collect, start));
  c.items.forEach(each);
  c.list.push((rows: any[][]) => {
    rows.push([8]);
  });
}
const m = new MapLRU<string, number>("k", 3);
run(m);
m.fire();
console.log(m.matrix.length);
