// R6-F4: new PTS1001s for nested objects and method results that are only read, fresh, or unreached (ran as Node on fix5)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  tags: V[] = [];
  matrix: V[][] = [[], []];
  store = new Map<K, V[]>();
  constructor(public key: K, public val: V) {
    this.items.push(val);
    this.store.set(key, []);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function positives(c: Cache<string, number>): any[] {
  if (c instanceof MapLRU) return c.items.filter((x) => x > 0);
  return [];
}
function doubled(c: Cache<string, number>): number {
  if (c instanceof MapLRU) return c.items.filter((x) => x > 0).map((x) => x * 2).length;
  return 0;
}
const m = new MapLRU<string, number>("k", 3);
m.matrix[0].push(1);
const plain: Cache<string, number> = { get: () => 1 };
console.log(positives(m), doubled(m));
