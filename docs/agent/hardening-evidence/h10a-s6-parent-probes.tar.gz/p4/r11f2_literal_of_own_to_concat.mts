// R11-F2: an array literal of the instance's own functions given to concat is PTS1001 on fix11 (fix10 printed Node's output)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  constructor(public key: K, public val: V) {
    this.list.push((rows) => rows.push([]));
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.list = c.list.concat([c.list[0]]);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
m.fire();
console.log(m.matrix.length, m.list.length);
