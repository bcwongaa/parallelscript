// identity of functions held by an inferred or uninferred narrowing's members
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  list: ((rows: V[][]) => void)[] = [];
  cb: (rows: V[][]) => void = () => {};
  plain: (() => number)[] = [];
  constructor(public key: K, public val: V) {
    this.list.push(() => {}, () => {});
    this.plain.push(() => 1);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function inferred(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const f = c.cb;
  const g = c.list[1];
  const p = c.plain[0];
  console.log("inferred", f === c.cb, c.list.indexOf(g), c.list.lastIndexOf(c.list[1]), c.plain.indexOf(p), new Set([c.cb, c.cb]).size);
}
function uninferred(o: object): void {
  if (!(o instanceof MapLRU)) return;
  const g = o.list[1];
  console.log("uninferred", o.list.indexOf(g), o.cb === o.cb);
}
const m = new MapLRU<string, number>("k", 0);
inferred(m);
uninferred(m);
