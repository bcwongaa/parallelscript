// round 9: a value that holds the instance's own function or a copying function (conditional, ??, ||, a local of one)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  maybe?: (rows: V[][]) => void;
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {
    this.list.push(() => {});
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
const m = new MapLRU<string, number>("k", 0);
let flag = false;
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const h = c.maybe ?? addRow;
  c.list.push(h);
}
run(m);
m.fire();
console.log(m.matrix.length);
