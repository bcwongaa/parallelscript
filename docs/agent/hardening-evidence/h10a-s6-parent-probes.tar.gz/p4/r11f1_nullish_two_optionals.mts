// R11-F1: `??` between two optional function members of the instance keeps an adapter (identity lost)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  list: ((x: V) => string)[] = [];
  maybe?: (x: V) => string;
  also?: (x: V) => string;
  constructor(public key: K, public val: V) {
    this.list.push((x) => "a" + x, (x) => "b" + x);
    this.also = this.list[1];
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const z = c.maybe ?? c.also;
  console.log(z === c.also, c.list.indexOf(z!), (c.maybe || c.also) === c.also);
}
run(new MapLRU<string, number>("k", 0));
