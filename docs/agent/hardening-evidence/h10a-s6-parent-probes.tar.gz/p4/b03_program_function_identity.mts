// identity of the program's functions stored into an inferred narrowing's function-array member
interface Source<T> {
  current(): T;
}
class Emitter<T> implements Source<T> {
  listeners: ((value: T) => void)[] = [];
  constructor(public last: T) {}
  current(): T {
    return this.last;
  }
}
const seen: string[] = [];
function typedHandler(v: number): void {
  seen.push("t" + v);
}
function anyHandler(v: any): void {
  seen.push("a" + v);
}
function wire(s: Source<number>): void {
  if (!(s instanceof Emitter)) return;
  s.listeners.push(typedHandler, anyHandler);
  console.log(s.listeners.indexOf(typedHandler), s.listeners.indexOf(anyHandler), s.listeners.includes(anyHandler));
  s.listeners.splice(s.listeners.indexOf(anyHandler), 1);
}
const e = new Emitter<number>(0);
wire(e);
for (const f of e.listeners) f(1);
console.log(seen, e.listeners.length, e.listeners.indexOf(typedHandler));
