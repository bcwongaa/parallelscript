// control for R8-F1: a function read out of an `any` into a typed local, no instanceof
class Box<T> {
  constructor(public v: T) {}
}
const fs: ((x: number) => void)[] = [(x) => {}, (x) => {}];
const a: any = fs;
const h: (x: any) => void = a[0];
console.log(a.indexOf(h), h === a[0], fs.indexOf(h), new Box(1).v);
