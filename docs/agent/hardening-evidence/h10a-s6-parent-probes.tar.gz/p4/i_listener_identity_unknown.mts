// R8-F1 with an unknown source
interface Source<T> {
  current(): T;
}
class Emitter<T> implements Source<T> {
  listeners: ((value: T) => void)[] = [];
  last: T;
  constructor(v: T) {
    this.last = v;
  }
  current(): T {
    return this.last;
  }
  on(f: (value: T) => void): void {
    this.listeners.push(f);
  }
  emit(v: T): void {
    for (const f of this.listeners) f(v);
  }
}
const seen: string[] = [];
const e = new Emitter<number>(0);
e.on((v) => seen.push("a" + v));
e.on((v) => seen.push("b" + v));
function offFirst(s: unknown): void {
  if (!(s instanceof Emitter)) return;
  const h = s.listeners[0];
  const i = s.listeners.indexOf(h);
  console.log("index", i, h === s.listeners[0]);
  if (i >= 0) s.listeners.splice(i, 1);
}
offFirst(e);
e.emit(1);
console.log(seen, e.listeners.length);
