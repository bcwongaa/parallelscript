// removing a listener by identity through an inferred narrowing (indexOf + splice)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  opt?: (rows: V[][]) => void;
  cfgs: { onRows: (rows: V[][]) => void }[] = [{ onRows: () => {} }];
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  boxes: { cb: (rows: V[][]) => void }[] = [];
  constructor(public key: K, public val: V) {
    this.list.push((rows) => rows.push([]), (rows) => rows.push([], []));
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.opt?.(this.matrix);
    for (const c of this.cfgs) c.onRows(this.matrix);
    this.cfg.onRows(this.matrix);
    for (const b of this.boxes) b.cb(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
const m = new MapLRU<string, number>("k", 0);
function removeFirst(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const h = c.list[0];
  const i = c.list.indexOf(h);
  c.list.splice(i, 1);
}
removeFirst(m);
m.fire();
console.log(m.matrix.length, m.list.length);
