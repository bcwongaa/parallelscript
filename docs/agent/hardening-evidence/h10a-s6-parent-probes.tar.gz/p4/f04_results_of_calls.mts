// results of calling function locals bound from an inferred narrowing: arrays, objects, generic class instances
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class Inner<T> {
  constructor(public v: T) {}
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  mkList: () => V[];
  mkObj: () => { list: V[] };
  mkInner: () => Inner<V>;
  constructor(public key: K, public val: V) {
    this.mkList = () => this.items;
    const o = { list: this.items };
    this.mkObj = () => o;
    this.mkInner = () => new Inner(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const mkList = c.mkList;
  const xs: number[] = mkList();
  xs.push(1);
  mkList().push(2);
  const mkObj = c.mkObj;
  mkObj().list.push(3);
  console.log(c.items, mkList() === c.items, mkObj().list === c.items);
  const mkInner = c.mkInner;
  console.log(mkInner().v);
}
run(new MapLRU<string, number>("k", 0));
