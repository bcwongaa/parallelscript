// control for b03: typed code storing an (any) => void function in a (number) => void array
const listeners: ((value: number) => void)[] = [];
function anyHandler(v: any): void {}
listeners.push(anyHandler);
console.log(listeners.indexOf(anyHandler), listeners.includes(anyHandler));
