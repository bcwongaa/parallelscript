// R9-F2: storing the instance's own functions through an array or object literal is PTS1001 on fix9 (fix8 printed Node's output)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  maybe?: (rows: V[][]) => void;
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {
    this.list.push(() => {});
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
}
const m = new MapLRU<string, number>("k", 0);
m.list.push((rows) => rows.push([], []));
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  [c.list[0], c.list[1]] = [c.list[1], c.list[0]];
  Object.assign(c.cfg, { onRows: c.list[0] });
}
run(m);
m.fire();
console.log(m.matrix.length, m.list.length);
