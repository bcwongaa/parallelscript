// R8-F3: destructuring assignment and Object.assign store a copying function without fix8's check
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [() => {}];
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  more: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
    this.more.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  [c.list[0]] = [addRow];
  ({ f: c.cfg.onRows } = { f: addRow });
  Object.assign(c.more, { onRows: addRow });
}
const m = new MapLRU<string, number>("k", 0);
run(m);
m.fire();
console.log(m.matrix.length);
