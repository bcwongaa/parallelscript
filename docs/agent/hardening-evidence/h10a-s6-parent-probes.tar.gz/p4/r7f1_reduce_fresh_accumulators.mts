// R7-F1: by-reference reducers whose initial accumulator is a fresh object, Map or a local the program owns are PTS1001 on fix7
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val, val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function groupInto(acc: Record<string, any[]>, x: any): Record<string, any[]> {
  (acc["n"] ??= []).push(x);
  return acc;
}
function count(acc: Map<any, any[]>, x: any): Map<any, any[]> {
  acc.set(x, [x]);
  return acc;
}
function collect(acc: any[], x: any): any[] {
  acc.push(x);
  return acc;
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const start: any[] = [];
  console.log(c.items.reduce(groupInto, {}), c.items.reduce(count, new Map<any, any[]>()), c.items.reduce(collect, start));
}
run(new MapLRU<string, number>("k", 3));
