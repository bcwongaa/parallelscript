// R10-F1: reads of a concat/with result that holds the program's function count as the instance's own (fix8: PTS1001)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {
    this.list.push(() => {});
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
const m = new MapLRU<string, number>("k", 0);
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.cfg.onRows = c.list.concat([addRow])[1];
  const h = c.list.with(0, addRow).at(0)!;
  c.list.push(h);
  c.list.concat([addRow]).concat([]).forEach((f, i) => { if (i === 1) c.list.push(f); });
}
run(m);
m.fire();
console.log(m.matrix.length);
