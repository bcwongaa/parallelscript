// R7-F2: functions with a copying parameter kept by an inferred narrowing's members through push, element,
// property and array-literal assignment, then called by typed code with the instance's own arrays
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.list.push(addRow);
  c.list.push((rows: any[][]) => { rows.push([8]); });
  c.list[2] = addRow;
  c.cfg.onRows = addRow;
}
const m = new MapLRU<string, number>("k", 0);
run(m);
m.fire();
console.log(m.matrix.length);
