// logical operators over non-function and mixed values of an inferred narrowing (should be unchanged by fix11)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  maybe?: (x: V) => string;
  label?: string;
  meta?: { tags: V[] };
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function fallback(x: any): string {
  return "f" + x;
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const a = c.maybe || "none";
  const b = c.items.length && c.items[0];
  const d = { tags: [] as number[] };
  const e = c.label ?? "nolabel";
  const f = c.maybe ?? fallback;
  const g = c.val || c.key;
  const h = c.items[5] ?? -1;
  console.log(a, b, d.tags.length, e, f(1), g, h, (c.maybe || fallback)(2), c.maybe && "yes");
}
run(new MapLRU<string, number>("k", 7));
