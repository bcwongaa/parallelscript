// R9-F1: a value holding either the instance's own function or a writer with a copying parameter (fix8: PTS1001)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  maybe?: (rows: V[][]) => void;
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  reader: (row: V[]) => void = () => {};
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
function pushRow(row: any[]): void {
  row.push(1);
}
let flag = false;
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.cfg.onRows = c.maybe ?? addRow;
  const h = flag ? c.list[0] : addRow;
  c.list.push(h);
  const r = flag ? c.reader : pushRow;
  c.matrix.forEach(r);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
m.fire();
console.log(m.matrix.length, m.matrix[0].length);
