// R7-F3: a by-reference function that only reads its array but hands it to a named one-parameter callback is PTS1001 on fix7
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val, val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function show(x: any): void {
  console.log("item", x);
}
function each(_x: any, i: number, arr: any[]): void {
  if (i === 0) arr.forEach(show);
}
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) c.items.forEach(each);
}
run(new MapLRU<string, number>("k", 3));
