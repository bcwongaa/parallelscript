// round 10: function locals that are wholly the instance's own (should keep identity and be storable)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  maybe?: (rows: V[][]) => void;
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  constructor(public key: K, public val: V) {
    this.list.push((rows) => rows.push([]), (rows) => rows.push([], []));
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.cfg.onRows(this.matrix);
  }
  each(f: (g: (rows: V[][]) => void) => void): void {
    for (const g of this.list) f(g);
  }
}
let flag = true;
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const a = flag ? c.list[0] : c.list[1];
  const b = c.maybe ?? c.list[1];
  const d = c.list.find((f) => f === c.list[1])!;
  const e = c.maybe ?? undefined;
  console.log(a === c.list[0], b === c.list[1], d === c.list[1], e === undefined, c.list.indexOf(b));
  c.cfg.onRows = b;
  let seen = 0;
  c.list.forEach((f) => { if (f === c.list[seen]) seen++; });
  c.each((g) => { if (c.list.includes(g)) seen++; });
  c.list = [...c.list];
  console.log(seen);
}
interface Has<T> {
  key: string;
}
function generic<T>(h: Has<T>): number {
  if (!(h instanceof MapLRU)) return -1;
  const f = flag ? h.list[1] : h.list[0];
  return h.list.indexOf(f);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
m.fire();
console.log(m.matrix.length, m.list.length, generic(m), generic(new MapLRU<string, string>("s", "t")));
