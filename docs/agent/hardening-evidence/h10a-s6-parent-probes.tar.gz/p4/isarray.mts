const xs: number[] = [1];
const s: any = xs;
if (Array.isArray(s)) s.push(2);
let t;
t = [xs][0] as any;
t.push(3);
console.log(xs);
