const xs: number[] = [1];
let s;
s = xs;
s.push(2);
const rows: number[][] = [[1]];
function firstPush(r: any[][]): void { r[0].push(3); }
firstPush(rows);
console.log(xs, rows);
