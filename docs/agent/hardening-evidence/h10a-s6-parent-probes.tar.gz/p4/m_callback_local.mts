// a local holding either the instance's own function or a writer with a copying parameter, given as a callback
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  reader: (row: V[]) => void = () => {};
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function pushRow(row: any[]): void {
  row.push(1);
}
let flag = false;
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const h = flag ? c.reader : pushRow;
  c.matrix.forEach(h);
  const k = c.reader ?? pushRow;
  console.log(typeof k);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.matrix);
