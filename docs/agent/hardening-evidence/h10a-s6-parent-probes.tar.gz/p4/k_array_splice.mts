// a function kept by an inferred narrowing's member and called later by typed code with the instance's own arrays
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  list: ((rows: V[][]) => void)[] = [];
  onRows: (rows: V[][]) => void = () => {};
  handlers = new Map<string, (rows: V[][]) => void>();
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  fire(): void {
    for (const f of this.list) f(this.matrix);
    this.onRows(this.matrix);
  }
}
function addRow(rows: any[][]): void {
  rows.push([9]);
}
const m = new MapLRU<string, number>("k", 0);
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.list.splice(0, 0, addRow);
}
run(m);
m.fire();
console.log(m.matrix.length);
