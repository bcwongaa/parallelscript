// results of calling a function local bound from an inferred narrowing's member
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  mkList: () => V[];
  constructor(public key: K, public val: V) {
    this.mkList = () => this.items;
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.mkList().push(1);
  const mk = c.mkList;
  mk().push(2);
  const ys = mk();
  ys.push(3);
  console.log(c.items, mk() === c.items, c.mkList() === c.items);
}
run(new MapLRU<string, number>("k", 0));
