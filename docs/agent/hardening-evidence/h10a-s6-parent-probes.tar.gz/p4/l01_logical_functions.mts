// round 11: ?? || && over functions of an inferred narrowing's members (isInstanceOwnFunction)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  list: ((x: V) => string)[] = [];
  maybe?: (x: V) => string;
  also?: (x: V) => string;
  constructor(public key: K, public val: V) {
    this.list.push((x) => "a" + x, (x) => "b" + x);
    this.also = this.list[1];
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const z = c.maybe ?? c.also;
  const y = c.maybe || c.also;
  const w = c.also && c.list[0];
  const v = c.maybe && c.list[0];
  const u = c.maybe || c.also || c.list[0];
  const t = c.maybe ?? c.maybe;
  console.log(z === c.also, y === c.also, w === c.list[0], v, u === c.list[1], t);
  console.log((c.maybe ?? c.list[0])(1), (c.maybe || c.list[1])(2), (c.also && c.list[0])!(3), (c.maybe ?? c.also)?.(4));
  console.log(typeof (c.maybe ?? c.list[0]), !!(c.maybe || c.also), c.list.indexOf((c.maybe ?? c.list[1])!), [c.maybe ?? c.list[0]].length);
  const typed: (x: number) => string = c.maybe ?? c.list[0];
  console.log(typed(5));
}
run(new MapLRU<string, number>("k", 0));
