#!/bin/bash
# emit-c of every program with HEAD's CLI and the new one; prints SAME/DIFF/ERR per file.
cd /home/bryan/projects/parallelscript
export PTS_HOME=/tmp/h10/s6/base
B=/tmp/h10/s6/base/pts-bin/pts; X=/tmp/h10/s6/pts-new1; W=/tmp/h10/s6/sweep
for f in pts/tests/run/*.pts pts/tests/errors/*.pts pts/tests/corpus/*/*.pts pts/tests/stress/*.pts docs/examples/*.pts; do
  b=$(timeout 120 $B emit-c "$f" -o $W/b.c 2>$W/b.err; echo $?)
  x=$(timeout 120 $X emit-c "$f" -o $W/x.c 2>$W/x.err; echo $?)
  if [ "$b" != "$x" ]; then echo "EXIT $b $x $f"; continue; fi
  if [ "$b" != 0 ]; then
    if cmp -s $W/b.err $W/x.err; then echo "SAMEERR $f"; else echo "DIFFERR $f"; fi
    continue
  fi
  if cmp -s $W/b.c $W/x.c; then echo "SAME $f"; else echo "DIFF $f $(wc -l < $W/b.c) $(wc -l < $W/x.c)"; fi
  rm -f $W/b.c $W/x.c
done
echo done > $W/done
