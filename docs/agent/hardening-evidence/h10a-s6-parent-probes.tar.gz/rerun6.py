#!/usr/bin/env python3
"""Runs the round-6 reviewer's probes under Node, fix5 (HEAD), fix6 (snap1) and the current CLI."""
import subprocess, os, sys, json, shutil, concurrent.futures as cf, glob
OUT = sys.argv[1]; NEW = sys.argv[2]; FILES = sys.argv[3:]
clis = dict(fix5='/tmp/h10/s6/base/pts-bin/pts', fix6='/tmp/h10/s6/snap1/pts-bin/pts', now=NEW)
env = dict(os.environ, PTS_HOME='/tmp/h10/s6/base', TZ='America/New_York')
NODE = os.path.expanduser('~/.local/node/bin/node')
def run(cmd, cwd, extra=None):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=dict(env, **(extra or {})), capture_output=True, text=True, timeout=300, errors='replace')
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return None, '', 'TIMEOUT'
def threads_of(src):
    for line in src.splitlines():
        if line.startswith('// threads:'):
            return line.split(':', 1)[1].split()
    return [None]
def classify(nc, no, c, o, e):
    if c == nc and o == no: return 'OK'
    for k in ('PTS1001', 'PTS9001', 'TIMEOUT'):
        if k in e: return k
    if 'TypeError' in e or 'TypeError' in o: return 'TYPEERR'
    return 'WRONG'
def one(path):
    d, f = os.path.split(path); name = f[:-4]
    work = os.path.join(OUT, name); os.makedirs(work, exist_ok=True)
    src = open(path).read()
    open(os.path.join(work, name + '.mts'), 'w').write(src.replace('.par.', '.'))
    nc, no, ne = run([NODE, '--no-warnings', '--experimental-transform-types', name + '.mts'], work)
    res = {'probe': os.path.relpath(path, '/tmp/h10/s6/review6/p'), 'node': [nc, no]}
    for k, cli in clis.items():
        classes = []
        for t in threads_of(src):
            c, o, e = run([cli, 'run', path], d, {'PTS_THREADS': t} if t else None)
            classes.append(classify(nc, no, c, o, e))
            res[k + 'out'] = (o[-600:], e[-400:])
        res[k] = classes[0] if len(set(classes)) == 1 else '/'.join(classes)
    return res
with cf.ThreadPoolExecutor(3) as ex:
    results = list(ex.map(one, sorted(FILES)))
json.dump(results, open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
for r in results:
    print(f"{r['probe']:52s} fix5={r['fix5']:8s} fix6={r['fix6']:8s} now={r['now']:8s}")
