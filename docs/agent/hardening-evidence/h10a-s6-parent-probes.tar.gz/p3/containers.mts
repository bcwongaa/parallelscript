// skip: H10b (D-218, R6-F3, C285): objects inside an instanceof narrowing's member that a spread, an iterator, `Array.from`, `new Set`/`new Map` or `Promise.all` puts into a new container are copied into the container's tsc type (`any[]` elements), so writes through them are lost silently (the base threw a checked TypeError)
// H10a review round 6 (R6-F3) and session 6's reproducer (N13): the objects stay the
// instance's own in Node.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  store = new Map<K, V[]>();
  constructor(public key: K, public val: V) {
    this.store.set(key, []);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
async function run(c: Cache<string, number>): Promise<void> {
  if (!(c instanceof MapLRU)) return;
  [...c.matrix][0].push(1);
  [...c.matrix, []][1].push(2);
  for (const [, row] of c.matrix.entries()) row.push(3);
  for (const row of new Set(c.matrix)) row.push(4);
  Array.from(c.store.values())[0].push(5);
  [...c.store][0][1].push(6);
  new Map(c.store).get("k")!.push(7);
  c.store.values().next().value!.push(8);
  const rows = await Promise.all(c.matrix);
  rows[0].push(9);
}
const m = new MapLRU<string, number>("k", 0);
await run(m);
console.log(m.matrix, m.store.get("k"));
