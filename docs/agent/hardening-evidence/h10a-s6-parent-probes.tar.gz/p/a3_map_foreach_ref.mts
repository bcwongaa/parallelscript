// Map member's forEach by reference with an any[] value parameter.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V[]>();
  constructor(public key: K, public val: V) { this.store.set(key, [val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function addTo(v: any[], _k: any): void { v.push(9); }
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.store.forEach(addTo);
    c.store.forEach((v: any[]) => v.push(8));
  }
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.store.get("k")!.length);
