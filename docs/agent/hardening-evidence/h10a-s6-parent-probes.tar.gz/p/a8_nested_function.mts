// Callbacks nested in object and array arguments of the narrowed instance's own methods.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  run(o: { cb: (items: V[]) => void }): void { o.cb(this.items); }
  all(fs: ((items: V[]) => void)[]): void { for (const f of fs) f(this.items); }
}
function addOne(items: any[]): void { items.push(1); }
function go(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.run({ cb: (items: any[]) => items.push(2) });
    c.run({ cb: addOne });
    c.all([addOne, (items: any[]) => items.push(3)]);
    console.log(c.items.length);
  }
}
go(new MapLRU<string, number>("k", 0));
