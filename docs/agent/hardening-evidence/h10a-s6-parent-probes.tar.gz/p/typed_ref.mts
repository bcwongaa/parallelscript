function pushOne(_x: any, _i: number, arr: any[]): void {
  arr.push(1);
}
const xs: number[] = [0];
xs.forEach(pushOne);
console.log(xs.length);
class Box<T> {
  items: T[] = [];
  each(f: (items: T[]) => void): void { f(this.items); }
}
const b = new Box<number>();
b.each((items: any[]) => items.push(5));
b.each(function (items: any[]) { items.push(6); });
console.log(b.items.length);
