// reduce without an initial value hands its callback the first element as the accumulator.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { this.matrix.push([val], [val, val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function go(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.matrix.reduce((acc: any[], row: any[]) => { acc.push(...row); return acc; });
    console.log(c.matrix[0].length);
  }
}
go(new MapLRU<string, number>("k", 0));
