interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  slots: (V[] | undefined)[] = [[], undefined];
  meta?: { tags: V[] } = { tags: [] };
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function go(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const s = c.slots[0];
  s?.push(1);
  c.slots[1]?.push(2);
  c.meta?.tags.push(3);
  const t = c.meta?.tags;
  t?.push(4);
  console.log(c.slots[0]?.length, c.meta?.tags.length);
}
const m = new MapLRU<string, number>("k", 0);
go(m);
console.log(m.slots, m.meta);
