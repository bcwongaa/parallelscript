interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  each(f: (items: V[]) => void): void { f(this.items); }
}
function addOne(items: any[]): void { items.push(1); }
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.each(addOne);
    console.log(c.items.length);
  }
}
run(new MapLRU<string, number>("k", 0));
