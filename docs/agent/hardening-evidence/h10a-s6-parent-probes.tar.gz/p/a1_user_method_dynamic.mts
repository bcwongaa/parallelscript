// A user method of an instance an uninferred narrowing holds as a dynamic value, given
// callbacks whose annotated any[] parameter the method hands the instance's own array.
class Box<T> {
  items: T[] = [];
  constructor(v: T) { this.items.push(v); }
  each(f: (items: T[]) => void): void { f(this.items); }
}
function addOne(items: any[]): void { items.push(1); }
function run(o: object): void {
  if (o instanceof Box) {
    o.each((items: any[]) => items.push(2));
    o.each(addOne);
    console.log(o.items.length);
  }
}
run(new Box<number>(0));
