// A user method of a member tsc types Inner<any> of an inferred narrowing.
interface Cache<K, V> { get(key: K): V | undefined; }
class Inner<T> {
  items: T[] = [];
  each(f: (items: T[]) => void): void { f(this.items); }
}
class MapLRU<K, V> implements Cache<K, V> {
  inner = new Inner<V>();
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function addOne(items: any[]): void { items.push(1); }
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.inner.each(addOne);
    c.inner.each((items: any[]) => items.push(2));
    console.log(c.inner.items.length);
  }
}
run(new MapLRU<string, number>("k", 0));
