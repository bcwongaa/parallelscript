// The narrowed instance's own method, given inline callbacks whose parameters have no type.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  each(f: (items: V[]) => void): void { f(this.items); }
  run(o: { cb: (items: V[]) => void }): void { o.cb(this.items); }
}
function go(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.each((items) => items.push(2));
    c.each(function (items) { items.push(3); });
    c.run({ cb: (items) => items.push(4) });
    c.run({ cb(items) { items.push(5); } });
    console.log(c.items.length);
  }
}
go(new MapLRU<string, number>("k", 0));
