interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { this.matrix.push([val], [val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function go(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const r = c.matrix[0];
  const f = c.matrix.find((row) => row.length > 0);
  console.log(r === c.matrix[0], f === c.matrix[0], c.matrix[0] === c.matrix[0]);
}
go(new MapLRU<string, number>("k", 1));
