// By-reference callbacks that only read, a reduce accumulator, a rest parameter: run as Node.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) { this.items.push(val, val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
let total = 0;
function measure(_x: any, _i: number, arr: any[]): void { total += arr.length; }
const collect = (acc: any[], x: any) => { acc.push(x * 2); return acc; };
const seen: number[] = [];
function logAll(...args: any[]): void { seen.push(args.length); }
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    c.items.forEach(measure);
    const doubled = c.items.reduce(collect, []);
    c.items.forEach(logAll);
    console.log(total, doubled, seen);
  }
}
run(new MapLRU<string, number>("k", 3));
