interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { this.matrix.push([val], [val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function go(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.matrix[0].push(5);
  const r = c.matrix[1];
  r.push(6);
  const same = c.matrix[0] === c.matrix[0];
  const xs: any = [[1]];
  console.log(same, xs[0] === xs[0]);
}
const m = new MapLRU<string, number>("k", 1);
go(m);
console.log(m.matrix);
