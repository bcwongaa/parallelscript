// Reads inside members tsc types with any of an inferred narrowing, then writes through them.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], [], []];
  meta: { tags: V[]; inner: { list: V[] } } = { tags: [], inner: { list: [] } };
  store = new Map<K, V[]>();
  slots: (V[] | undefined)[] = [[]];
  pairs: [K, V[]][] = [];
  constructor(public key: K, public val: V) { this.store.set(key, []); this.pairs.push([key, []]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function check(name: string, f: (c: Cache<string, number>) => void, seen: (m: MapLRU<string, number>) => number): void {
  const m = new MapLRU<string, number>("k", 0);
  try {
    f(m);
    console.log(name, seen(m));
  } catch (e: any) {
    console.log(name, "threw", e.message);
  }
}
check("element push", (c) => { if (c instanceof MapLRU) c.matrix[0].push(5); }, (m) => m.matrix[0].length);
check("element local", (c) => { if (c instanceof MapLRU) { const r = c.matrix[1]; r.push(6); } }, (m) => m.matrix[1].length);
check("element write", (c) => { if (c instanceof MapLRU) c.matrix[0][0] = 4; }, (m) => m.matrix[0].length);
check("property push", (c) => { if (c instanceof MapLRU) c.meta.tags.push(1); }, (m) => m.meta.tags.length);
check("property element", (c) => { if (c instanceof MapLRU) c.meta.tags[0] = 9; }, (m) => m.meta.tags.length);
check("nested property", (c) => { if (c instanceof MapLRU) c.meta.inner.list.push(1); }, (m) => m.meta.inner.list.length);
check("tuple element", (c) => { if (c instanceof MapLRU) c.pairs[0][1].push(7); }, (m) => m.pairs[0][1].length);
check("filter element", (c) => { if (c instanceof MapLRU) c.matrix.filter(() => true)[1].push(8); }, (m) => m.matrix[1].length);
check("array pattern", (c) => { if (c instanceof MapLRU) { const [first] = c.matrix; first.push(1); } }, (m) => m.matrix[0].length);
check("object pattern", (c) => { if (c instanceof MapLRU) { const { tags } = c.meta; tags.push(1); } }, (m) => m.meta.tags.length);
check("nested pattern", (c) => { if (c instanceof MapLRU) { const { inner: { list } } = c.meta; list.push(1); } }, (m) => m.meta.inner.list.length);
check("identity", (c) => { if (c instanceof MapLRU) console.log(c.matrix[0] === c.matrix[0], c.meta.tags === c.meta.tags); }, () => 0);
