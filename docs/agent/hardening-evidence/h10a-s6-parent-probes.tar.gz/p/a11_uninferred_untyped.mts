// A user method of an instance an uninferred narrowing holds, given untyped inline callbacks.
class Box<T> {
  items: T[] = [];
  constructor(v: T) { this.items.push(v); }
  each(f: (items: T[]) => void): void { f(this.items); }
  run(o: { cb: (items: T[]) => void }): void { o.cb(this.items); }
}
function go(o: object): void {
  if (o instanceof Box) {
    o.each((items) => items.push(2));
    o.run({ cb: (items) => items.push(4) });
    console.log(o.items.length);
  }
}
go(new Box<number>(0));
