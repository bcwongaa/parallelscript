// reduce accumulators of callbacks of a member tsc types any[] (inferred narrowing).
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { this.items.push(val, val); this.matrix.push([val], [val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function go(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const a = c.items.reduce((acc, x) => { acc.push(x); return acc; }, [] as any[]);
  const b = c.items.reduce((acc: any[], x) => { acc.push(x); return acc; }, []);
  const d = c.matrix.reduce((acc, row) => acc.concat(row), [] as any[]);
  const e = c.matrix.reduce((acc, row) => { acc.push(...row); return acc; });
  console.log(a, b, d, e, c.matrix[0]);
}
go(new MapLRU<string, number>("k", 1));
