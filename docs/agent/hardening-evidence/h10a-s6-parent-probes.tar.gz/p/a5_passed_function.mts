// A function value that a parameter holds, given to a method of a member tsc types any[].
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function apply(c: Cache<string, number>, f: (x: any, i: number, arr: any[]) => void): void {
  if (c instanceof MapLRU) {
    c.items.forEach(f);
    console.log(c.items.length);
  }
}
apply(new MapLRU<string, number>("k", 3), (_x, _i, arr) => arr.push(1));
