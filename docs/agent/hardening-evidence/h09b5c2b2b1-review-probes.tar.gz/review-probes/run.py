import json
import os
import pathlib
import subprocess
import sys

root=pathlib.Path(sys.argv[1])
manifest=json.loads((root/'manifest.json').read_text())
env=dict(os.environ,PTS_HOME='/home/bryan/projects/parallelscript',GOMAXPROCS='1')
node='/home/bryan/.local/node/bin/node'
rows=[]
def execute(command):
    try:
        p=subprocess.run(command,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
        return {'exit':p.returncode,'out':p.stdout,'err':p.stderr}
    except subprocess.TimeoutExpired as e:
        return {'exit':124,'out':str(e.stdout),'err':str(e.stderr)}
for case in manifest:
    name=case['name']
    source=root/'cases'/(name+'.pts')
    row={'name':name,'node':execute([node,'--experimental-transform-types',str(source.with_suffix('.mts'))])}
    for label,tool in [('base','allinstances-base'),('current','allinstances')]:
        c=root/'results'/(name+'-'+label+'.c')
        emit=execute([str(root/tool),'emit',str(source),str(c)])
        data={'emit':emit}
        if emit['exit']==0:
            code=c.read_text()
            data['targets']={key:('pts_fn_'+key+'(') in code for key in case['required']+case['excluded']}
            data['precision_ok']=all(data['targets'][key] for key in case['required']) and all(not data['targets'][key] for key in case['excluded'])
            if case['native']:
                binary=root/'results'/(name+'-'+label+'.bin')
                build=execute([str(root/tool),'build',str(source),str(binary)])
                data['build']=build
                if build['exit']==0:
                    data['run']=execute([str(binary)])
                    data['node_match']=data['run']['exit']==row['node']['exit'] and data['run']['out']==row['node']['out']
                binary.unlink(missing_ok=True)
        row[label]=data
    rows.append(row)
    print(name, 'emit',row['base']['emit']['exit'],row['current']['emit']['exit'],'precision',row['current'].get('precision_ok'),'matches',row['base'].get('node_match'),row['current'].get('node_match'),flush=True)
    (root/'results'/'native.json').write_text(json.dumps(rows,indent=2))
