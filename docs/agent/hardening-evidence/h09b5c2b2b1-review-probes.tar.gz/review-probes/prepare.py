import json
import pathlib
import sys

repo=pathlib.Path(sys.argv[1]).resolve()
probe=pathlib.Path(sys.argv[2]).resolve()
production=['instances.go','returned_values.go','value_flow.go','wrapper_sources.go','receiver_sources.go']
base={str(repo/'pts/lower'/name):str(probe/'originals'/name) for name in production}
final={str(repo/path.relative_to(probe/'snapshot')):str(path) for path in (probe/'snapshot').rglob('*') if path.is_file()}
round1=dict(final)
round1[str(repo/'pts/lower/value_flow.go')]=str(probe/'originals/value_flow-round1.go')
for name, mapping in [('base-overlay',base),('final-overlay',final),('round1-overlay',round1)]:
    (probe/(name+'.json')).write_text(json.dumps({'Replace':mapping},indent=2))
