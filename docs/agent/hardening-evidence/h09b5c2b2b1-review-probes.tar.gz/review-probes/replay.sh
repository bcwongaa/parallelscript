#!/usr/bin/env bash
set -euo pipefail
repo=${1:?pass an isolated repository at base d56b514c9}
probe=${2:?pass the extracted review-probes directory}
export GOMAXPROCS=1
export PTS_HOME=${PTS_HOME:-/home/bryan/projects/parallelscript}
python3 -I "$probe/prepare.py" "$repo" "$probe"
# Run from the isolated repository root, never the parent's checkout.
[[ $PWD = "$repo" ]]
go build -p 1 -overlay "$probe/base-overlay.json" -o "$probe/allinstances-base" "$probe/cmd"
go build -p 1 -overlay "$probe/final-overlay.json" -o "$probe/allinstances" "$probe/cmd"
set +e
go test -count=1 -v -p 1 -parallel 1 -timeout 10m -overlay "$probe/round1-overlay.json" -run '^TestReviewReceiverClassWriteForms$' "$repo/pts/lower" > "$probe/results/replay-red.txt" 2>&1
red=$?
set -e
[[ $red = 1 ]]
grep -F -- '--- FAIL: TestReviewReceiverClassWriteForms/(A_as_any)_=_B;' "$probe/results/replay-red.txt"
go test -count=1 -v -p 1 -parallel 1 -timeout 15m -overlay "$probe/final-overlay.json" -run '^(TestReview|TestReceiver|TestConstructed|TestUnknownReceiver|TestGenericReceiver|TestABuildThatOnlyItsDemandsByNameStopKeeps)' "$repo/pts/lower" "$repo/pts/driver" > "$probe/results/replay-green.txt" 2>&1
python3 -I "$probe/generate.py" "$probe"
python3 -I "$probe/run.py" "$probe" > "$probe/results/replay-native.stdout" 2>&1
