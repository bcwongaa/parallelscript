import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
cases = root / 'cases'
base = '''class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
'''
classes = ''.join(f'class M{i} implements Maker {{ tag="M{i}"; make<T>(value:T):Box<T> {{ console.log(this.tag); return new Box(value); }} }}\n' for i in range(3))
use = 'function use(receiver:Maker):void { const b:Box<number> = receiver.make(7); console.log(b.value); }\n'
manifest = []
def add(name, source, required=None, excluded=None, native=True):
    path=cases/(name+'.pts')
    path.write_text(source)
    path.with_suffix('.mts').write_text(source)
    manifest.append(dict(name=name, required=required or [], excluded=excluded or [], native=native))
def regular(name, prefix, body, targets=None, call=None):
    add(name, base+classes+(call or use)+prefix+'\n'+body+'\n', [f'M{i}_make_number' for i in (range(3) if targets is None else targets)], [f'M{i}_make_number' for i in range(3) if targets is not None and i not in targets])
regular('direct', '', 'use(new M1());', [1])
regular('aliases', '', 'const one:Maker=new M1(); const two=one; use(two);', [1])
regular('conditional', '', 'const one:Maker=choose()?new M0():new M1(); use(one);', [0,1])
regular('logical', '', 'const one:Maker|undefined=choose()?new M0():undefined; use(one ?? new M1());', [0,1])
regular('returned', 'function make():Maker { return new M1(); }', 'use(make());', [1])
regular('returned_callable_parameter', 'function make():Maker { return new M1(); } function invoke(f:()=>Maker):Maker { return f(); }', 'use(invoke(make));', [1])
regular('returned_shared_parameter', 'function identity(x:Maker):Maker { return x; }', 'use(identity(new M0())); use(identity(new M1()));', [0,1])
regular('returned_finally', 'function make():Maker { try { return new M0(); } finally { return new M1(); } }', 'use(make());', [0,1])
regular('unknown_array', '', 'const held:Maker[]=[new M1()]; use(held[0]);')
regular('unknown_any_narrowed', '', 'const held:any=new M1(); if(held instanceof M1) use(held);')
regular('unknown_alias_ctor', '', 'const C=M1; use(new C());')
regular('unknown_mutable', '', 'let x:Maker=new M0(); x=new M1(); use(x);')
regular('unknown_assertion', '', 'use(new M1() as Maker);')
regular('unknown_constructor_return', 'class Replacement implements Maker { constructor() { return new M1(); } make<T>(value:T):Box<T> { console.log("replacement-original"); return new Box(value); } }', 'use(new Replacement());')
regular('unknown_inherited_return', 'class Replacement implements Maker { constructor() { return new M1(); } make<T>(value:T):Box<T> { console.log("replacement-original"); return new Box(value); } } class Inherited extends Replacement {}', 'use(new Inherited());')
for name, call in [('optional_receiver','receiver?.make(7)'),('optional_call','receiver.make?.(7)'),('optional_both','receiver?.make?.(7)'),('constant_key','receiver["make"](7)'),('runtime_key','receiver[key](7)')]:
    regular(name, 'let key:"make"="make";', 'use(new M1());',[1],f'function use(receiver:Maker):void {{ const b:Box<number>={call}; console.log(b.value); }}\n')
for name, ctor in [('bare_ctor','return;'),('nested_ctor','const f=()=>new M2(); f();'),('nested_class_ctor','class Inner { constructor(){return new M2();} } new Inner();')]:
    source=base+classes+f'class Keep extends M1 {{ constructor(){{super(); {ctor} }} }}\n'+use+'use(new Keep());\n'
    add(name,source,['M1_make_number'],['M0_make_number','M2_make_number'])
add('inherited_and_overridden',base+'''class Parent implements Maker { tag="parent"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class Inherited extends Parent { tag="inherited"; }
class Override extends Parent { tag="override"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class Unreached extends Parent { make<T>(value:T):Box<T> { console.log("unreached"); return new Box(value); } }
function use0(receiver:Maker):void { console.log(receiver.make(7).value); }
function use1(receiver:Maker):void { console.log(receiver.make("str").value); }
use0(new Inherited()); use1(new Override());
''',['Parent_make_number','Parent_make_string','Override_make_string'],['Override_make_number','Unreached_make_number','Unreached_make_string'])
add('dispatched',base+'''abstract class Parent { abstract make<T>(value:T):Box<T>; }
class A extends Parent { make<T>(value:T):Box<T> { console.log("A"); return new Box(value); } }
class B extends Parent { make<T>(value:T):Box<T> { console.log("B"); return new Box(value); } }
function use(receiver:Parent):void { console.log(receiver.make(7).value); }
use(new B());
''',['B_make_number'],['A_make_number'])
add('override_barrier',base+'''class Parent implements Maker { make<T>(value:T):Box<T> { console.log("parent"); return new Box(value); } }
class Override extends Parent { make<T>(value:T):Box<T> { console.log("override"); const held:any=[new Box("wrong")]; return held[0]; } }
function use(receiver:Maker):void { try { console.log(receiver.make(7).value); } catch(e:any) { console.log("caught",e.name); } }
use(new Override());
''',[],[])
add('class_arrow_field',base+'''class A implements Maker { tag="A"; make=<T>(value:T):Box<T>=> { console.log(this.tag); return new Box(value); }; }
class B implements Maker { tag="B"; make=<T>(value:T):Box<T>=> { console.log(this.tag); return new Box(value); }; }
'''+use+'use(new A());\n')
add('function_sources_regression',base+classes+'''function f<T>(x:T):Box<T>{return new Box(x);}
function g<T>(x:T):Box<T>{return new Box(x);}
function factory(flag:boolean):typeof f { if(flag) return f; return g; }
function useFn(fn:typeof f):void { console.log(fn(9).value); }
useFn(factory(false));
'''+use+'use(new M1());\n',['f_number','g_number','M1_make_number'],['M0_make_number','M2_make_number'])
add('captured_wrapper_receiver_deferred',base+classes+'''type Factory=<T>(v:T)=>Box<T>;
function read(receiver:Maker):Factory { return receiver.make.bind(receiver); }
function invoke(fn:Factory):void {console.log(fn(11).value);}
invoke(read(new M1()));
''',['M0_make_number','M1_make_number','M2_make_number'])
for name, write in [('asserted_class_write','(M0 as any) = M1;'),('asserted_class_destructure','[(M0 as any)] = [M1];')]:
    add(name,base+classes+use+write+'\nuse(new M0());\n',native=True)
(root/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(f'generated {len(manifest)} probes')
