package main

import (
 "context"
 "fmt"
 "os"
 "path/filepath"

 "github.com/microsoft/typescript-go/pts/driver"
 "github.com/microsoft/typescript-go/pts/lower"
 "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
 if len(os.Args) != 4 { fmt.Fprintln(os.Stderr, "usage: allinstances emit|build|default entry output"); os.Exit(2) }
 ctx := context.Background()
 action, entry, output := os.Args[1], os.Args[2], os.Args[3]
 var err error
 if action == "default" { err = driver.Build(ctx, entry, output) } else {
  var code string
  code, err = driver.EmitCWith(ctx, entry, lower.AllInstances)
  if err == nil {
   if action == "emit" { err = os.WriteFile(output, []byte(code), 0600) } else {
    dir, e := os.MkdirTemp("", "pts-b1-review-c-")
    if e != nil { err = e } else {
     defer os.RemoveAll(dir)
     cFile := filepath.Join(dir, "main.c")
     err = os.WriteFile(cFile, []byte(code), 0600)
     if err == nil {
      var tc *toolchain.Toolchain
      tc, err = toolchain.New()
      if err == nil {
       rt, e := tc.Runtime(ctx, toolchain.Release)
       if e != nil { err = e } else { err = tc.CompileProgram(ctx, rt, []string{cFile}, output) }
      }
     }
    }
   }
  }
 }
 if err != nil { fmt.Fprintf(os.Stderr, "%+v\n", err); os.Exit(1) }
}
