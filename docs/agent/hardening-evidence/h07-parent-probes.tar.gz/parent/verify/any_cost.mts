// Parent probe (C119): n followers of one long-lived signal made by AbortSignal.any, on one thread.
const n = Number(process.argv[2]);
const shared = new AbortController();
const start = performance.now();
for (let i = 0; i < n; i++) {
  AbortSignal.any([shared.signal]);
}
console.log(`${n} any followers: ${Math.round(performance.now() - start)} ms`);
