function attempt(label: string, make: () => unknown): void {
  try {
    make();
    console.log(label, "constructed");
  } catch (e) {
    console.log(label, (e as Error).name, (e as Error).message);
  }
}
attempt("plain", () => new AbortSignal());
attempt("undefined", () => new AbortSignal(undefined));
const anything: any = {};
attempt("any object", () => new AbortSignal(anything));
const nothing: any = undefined;
attempt("any undefined", () => new AbortSignal(nothing));
class Mine extends AbortSignal {}
attempt("subclass", () => new Mine());
const c = new AbortController();
console.log(c.signal instanceof AbortSignal, c.signal instanceof EventTarget, c.signal);
console.log(AbortSignal.abort("r").reason, AbortSignal.any([c.signal]).aborted);
