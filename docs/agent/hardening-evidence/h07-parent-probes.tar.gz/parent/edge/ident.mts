const a = {};
const b = {};
const ua: unknown = {};
const ub: unknown = {};
console.log(a === b, ua === ub, (a as unknown) === ua);
function attempt(label: string, make: () => unknown): void {
  try {
    make();
    console.log(label, "constructed");
  } catch (e) {
    console.log(label, (e as Error).name, (e as Error).message);
  }
}
attempt("literal", () => new AbortSignal({}));
attempt("const", () => new AbortSignal(a));
attempt("number", () => new AbortSignal(1));
attempt("null", () => new AbortSignal(null));
