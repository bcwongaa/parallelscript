import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path('/home/bryan/projects/parallelscript/.claude/worktrees/agent-aa11f95bde4a6f9e3')
evidence = Path('/tmp/pts-literal-reproducer.huUO9N')
helper = evidence / 'strict-base'
node = '/home/bryan/.local/node/bin/node'
env = os.environ.copy()
env.update(GOMAXPROCS='1', PTS_REQUIRE_NODE='1', PTS_HOME='/home/bryan/projects/parallelscript')
records = []


def run(label, command):
    started = time.time()
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=180)
    (evidence / (label + '.stdout')).write_bytes(result.stdout)
    (evidence / (label + '.stderr')).write_bytes(result.stderr)
    record = {
        'label': label, 'command': [str(part) for part in command], 'cwd': str(root),
        'environment': {key: env[key] for key in ['GOMAXPROCS', 'PTS_REQUIRE_NODE', 'PTS_HOME']},
        'exit': result.returncode, 'elapsed_seconds': round(time.time() - started, 3),
        'stdout': label + '.stdout', 'stderr': label + '.stderr',
    }
    records.append(record)
    return result


observations = []
for name in ['generic_literal_projection_sources', 'generic_literal_projection_unknowns']:
    original = root / 'pts/tests/run' / (name + '.pts')
    source = evidence / (name + '.pts')
    shutil.copyfile(original, source)
    strict_node = evidence / (name + '.mts')
    shutil.copyfile(original, strict_node)
    code = evidence / (name + '.c')
    binary = evidence / (name + '.bin')
    node_result = run(name + '.node', [node, '--no-warnings', '--experimental-transform-types', strict_node])
    emitted = run(name + '.emit', [helper, 'emit', source, code])
    observation = {
        'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'node_exit': node_result.returncode, 'emit_exit': emitted.returncode,
    }
    if emitted.returncode == 0:
        compiled = run(name + '.compile', [helper, 'compile', code, binary])
        observation['compile_exit'] = compiled.returncode
        if compiled.returncode == 0:
            native = run(name + '.native', [binary])
            expected_lines = source.read_text().split('// expect:\n', 1)[1].splitlines()
            expected = ''.join(line[3:] + '\n' for line in expected_lines if line.startswith('// ')).encode()
            observation.update(native_exit=native.returncode,
                               native_matches_node=(native.stdout == node_result.stdout and native.returncode == node_result.returncode),
                               native_matches_expected=(native.stdout == expected and native.returncode == 0),
                               node_matches_expected=(node_result.stdout == expected and node_result.returncode == 0))
            binary.unlink()
    observations.append(observation)
(evidence / 'fixture-commands.json').write_text(json.dumps(records, indent=2) + '\n')
(evidence / 'fixture-observations.json').write_text(json.dumps(observations, indent=2) + '\n')
print(json.dumps(observations, indent=2))
if not all(item.get('native_matches_node') and item.get('native_matches_expected') and item.get('node_matches_expected') for item in observations):
    sys.exit(1)
