import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/home/bryan/projects/parallelscript/.claude/worktrees/agent-aa11f95bde4a6f9e3')
evidence = Path('/tmp/pts-literal-reproducer.huUO9N')
label, *command = sys.argv[1:]
assert command and '/' not in label
started = time.time()
env = os.environ.copy()
env.update(GOMAXPROCS='1', PTS_REQUIRE_NODE='1', PTS_HOME='/home/bryan/projects/parallelscript')
with (evidence / (label + '.stdout')).open('wb') as stdout, (evidence / (label + '.stderr')).open('wb') as stderr:
    process = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=600)
record = {
    'command': command,
    'cwd': str(root),
    'environment': {key: env[key] for key in ['GOMAXPROCS', 'PTS_REQUIRE_NODE', 'PTS_HOME']},
    'exit': process.returncode,
    'elapsed_seconds': round(time.time() - started, 3),
    'stdout': label + '.stdout',
    'stderr': label + '.stderr',
}
(evidence / (label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
sys.exit(process.returncode)
