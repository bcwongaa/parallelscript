// Rest patterns and destructuring of a Box<any> place's member reached by a call or a cast,
// for a Box<number>: as-is TypeError or a silent copy?
type Meta = { name: string; tags: any[] };
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
  getMeta(): { name: string; tags: T[] } { return this.meta; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("rest member", () => { const { name, ...r } = b.meta; r.tags.push("rm"); return r.tags.length; });
  t("rest call", () => { const { name, ...r } = b.getMeta(); r.tags.push("rc"); return r.tags.length; });
  t("rest cast", () => { const { name, ...r } = b.meta as Meta; r.tags.push("rx"); return r.tags.length; });
  t("pattern call", () => { const { tags } = b.getMeta(); tags.push("pc"); return tags.length; });
  t("pattern cast", () => { const { tags } = b.meta as Meta; tags.push("px"); return tags.length; });
  t("assign call", () => { let tags: any[] = []; ({ tags } = b.getMeta()); tags.push("ac"); return tags.length; });
}
const num = new Box<number>(0);
forms(num as Box<any>);
console.log("number", JSON.stringify(num.meta.tags));
const any = new Box<any>(0);
forms(any);
console.log("any", JSON.stringify(any.meta.tags));
