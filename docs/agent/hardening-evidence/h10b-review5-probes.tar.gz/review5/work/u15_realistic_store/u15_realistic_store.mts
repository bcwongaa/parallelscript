// Realistic: a registry of Store<any> objects reached through getters, fields and calls;
// subscribe/unsubscribe by identity, options copied by spreads and rest patterns, `in`
// checks on options, generic map over a store, a Store<number> in a Store<any> place.
type Options = { name: string; maxHistory?: number; tags: string[]; describe(): string };
class Store<S> {
  listeners: ((s: S[]) => void)[] = [];
  history: S[] = [];
  options: Options;
  constructor(public state: S, name: string) {
    this.options = { name, tags: [], describe() { return "store " + name; } };
  }
  subscribe(f: (s: S[]) => void): () => boolean {
    this.listeners.push(f);
    return () => { const i = this.listeners.indexOf(f); if (i >= 0) this.listeners.splice(i, 1); return i >= 0; };
  }
  unsubscribe(f: (s: S[]) => void): boolean { const i = this.listeners.indexOf(f); if (i >= 0) this.listeners.splice(i, 1); return i >= 0; }
  set(s: S): void { this.history.push(this.state); this.state = s; for (const l of this.listeners) l(this.history); }
  map<R>(f: (s: S) => R): Store<R> { return new Store<R>(f(this.state), this.options.name + "'"); }
}
class Registry {
  stores = new Map<string, Store<any>>();
  calls = 0;
  get main(): Store<any> { this.calls++; return this.stores.get("main")!; }
  byName(n: string): Store<any> { this.calls++; return this.stores.get(n)!; }
}
const seen: string[] = [];
function onHistory(h: any[]): void { seen.push("h" + h.length); }
const reg = new Registry();
reg.stores.set("main", new Store<any>({ n: 0 }, "main"));
reg.stores.set("count", new Store<any>(0, "count"));
reg.main.subscribe(onHistory);
reg.main.set({ n: 1 });
console.log("unsub main", reg.main.unsubscribe(onHistory), reg.main.listeners.length, reg.calls);
const off = reg.byName("count").subscribe(onHistory);
reg.byName("count").set(1);
console.log("off", off(), reg.byName("count").listeners.length, seen.join(","));
const opts = { ...reg.main.options, maxHistory: 10 };
console.log("opts", Object.keys(opts).join(","), opts.describe(), "maxHistory" in opts);
const { name, describe, ...restOpts } = reg.byName("count").options;
console.log("rest", name, Object.keys(restOpts).join(","), "maxHistory" in restOpts, "tags" in restOpts);
reg.main.options.tags.push("t1");
const copy = { ...reg.main.options };
copy.tags.push("t2");
console.log("tags", JSON.stringify(reg.main.options.tags));
const doubled = reg.byName("count").map((s) => s * 2);
console.log("map", doubled.state, doubled.options.name);
const typed = new Store<number>(5, "typed");
reg.stores.set("typed", typed);
try { const t = { ...reg.byName("typed").options }; t.tags.push("x"); console.log("typed spread", JSON.stringify(typed.options.tags)); }
catch (e) { console.log("typed spread", (e as Error).name); }
reg.byName("typed").subscribe(onHistory);
console.log("typed unsub", reg.byName("typed").unsubscribe(onHistory), typed.listeners.length);
console.log("calls", reg.calls);
