// Kept roots in stores and calls: `buses[i++].handler = f`, order of a key call against the
// right side, chained and value-used assignments, computed element-access calls, a
// parenthesized `as`, a non-null root, a conditional root, a nested root in the arguments.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  handler: ((rows: T[]) => void) | null = null;
  second: ((rows: T[]) => void) | null = null;
  cfg: { onRows: ((rows: T[]) => void) | null } = { onRows: null };
  on(h: (rows: T[]) => void): number { this.handlers.push(h); return this.handlers.length; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
const order: string[] = [];
const buses: Emitter<any>[] = [new Emitter<any>(), new Emitter<any>()];
function log(rows: any[]): void { rows.push(1); }
function mk(): (rows: any[]) => void { order.push("mk"); return log; }
function k(): number { order.push("k"); return 1; }
let i = 0;
buses[i++].handler = log;
console.log("index store", i, buses[0].handler === log, buses[1].handler === null);
buses[k()].cfg.onRows = mk();
console.log("order", order.join(","), buses[1].cfg.onRows === log);
order.length = 0;
function busOf(tag: string): Emitter<any> { order.push(tag); return buses[0]; }
const r = (busOf("a").second = mk());
console.log("value", r === log, buses[0].second === log, order.join(","));
order.length = 0;
busOf("b").handler = busOf("c").second = log;
console.log("chained", buses[0].handler === log, buses[0].second === log, order.join(","));
order.length = 0;
const key: "on" | "off" = i > 0 ? "on" : "off";
busOf("d")[key](log);
console.log("computed", busOf("e").off(log), order.join(","));
order.length = 0;
(busOf("f") as Emitter<any>).on(log);
console.log("as", (busOf("g") as Emitter<any>).off(log), order.join(","));
order.length = 0;
const maybe: Emitter<any> | undefined = buses[0];
const holder = { get bus(): Emitter<any> | undefined { order.push("h"); return maybe; } };
holder.bus!.on(log);
console.log("nonnull", holder.bus!.off(log), order.join(","));
order.length = 0;
(i > 0 ? busOf("x") : buses[1]).on(log);
console.log("cond", buses[0].off(log), order.join(","));
order.length = 0;
busOf("outer").on(busOf("inner").off(log) ? log : mk());
console.log("nested", busOf("o2").off(log), order.join(","));
