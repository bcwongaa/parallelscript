// `in` on a dynamic value that is a primitive at run time, whose type declares the key: an
// erased generic called through `any` with a string (JS: TypeError), and with an object.
function hasLen<T extends { length: number }>(x: T): boolean { return "length" in x; }
const viaAny: any = hasLen;
try { console.log("string", viaAny("abc")); } catch (e) { console.log("string", (e as Error).name); }
console.log("array", viaAny([1]), "object", viaAny({ length: 1 }));
console.log("direct", hasLen([1, 2]), hasLen({ length: 0 }));
try { console.log("direct string", hasLen("abc")); } catch (e) { console.log("direct string", (e as Error).name); }
