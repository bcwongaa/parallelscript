// A spread of a narrowing's member straight into a read-only parameter and into console.log.
interface Shape { kind(): string; }
class Box<T> implements Shape {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
  kind(): string { return "box"; }
}
function count(m: { name: string; tags: unknown[] }): number { return m.tags.length; }
function show(s: Shape): void {
  if (s instanceof Box) { console.log(count({ ...s.meta }), { ...s.meta, extra: 1 }); }
}
const b = new Box<number>(0); b.meta.tags.push(4);
show(b);
