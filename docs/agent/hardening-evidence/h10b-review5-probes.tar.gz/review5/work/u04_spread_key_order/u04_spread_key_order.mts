// Key order of a spread of a Box<any> place's member: JS copies the object's own keys in its
// own order (here the initializer's, which differs from the type's declaration order).
type Meta = { name: string; count: number };
class Box<T> {
  meta: Meta = { count: 1, name: "m" };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
console.log("direct", JSON.stringify(b.meta), Object.keys(b.meta).join(","));
const s = { ...b.meta };
console.log("spread", JSON.stringify(s), Object.keys(s).join(","));
const t = { ...b.meta, extra: true };
console.log("spread extra", JSON.stringify(t));
const { name, ...rest } = b.meta;
console.log("rest", name, JSON.stringify(rest));
function viaParam(p: Box<any>): string { return JSON.stringify({ ...p.meta }); }
console.log("param", viaParam(b));
const typed = new Box<number>(0);
console.log("typed", JSON.stringify({ ...typed.meta }));
