// u05's deeper receivers without a suspension, and with a call root and `await`/`yield`: how
// often the root is evaluated, and whether the function keeps its identity.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  cfg: { list: ((rows: T[]) => void)[] } = { list: [] };
}
const order: string[] = [];
const e = new Emitter<any>();
function busOf(tag: string): Emitter<any> { order.push(tag); return e; }
function log(rows: any[]): void { rows.push(1); }
busOf("a").handlers.push(log);
console.log("push", e.handlers.indexOf(log), order.join(","));
order.length = 0;
busOf("b").cfg.list.push(log);
console.log("cfg push", e.cfg.list.indexOf(log), order.join(","));
order.length = 0;
busOf("c").handlers.splice(0, 1);
busOf("d").handlers.unshift(log);
console.log("unshift", e.handlers.indexOf(log), order.join(","));
order.length = 0;
async function main(): Promise<void> {
  e.handlers.length = 0;
  busOf("e").handlers.push(await Promise.resolve(log));
  console.log("await push", e.handlers.indexOf(log), order.join(","));
  order.length = 0;
  busOf("f").cfg.list.push(log, await Promise.resolve(log));
  console.log("await cfg push", e.cfg.list.lastIndexOf(log), order.join(","));
  order.length = 0;
  busOf("g").handlers[0] = await Promise.resolve(log);
  console.log("await store", e.handlers[0] === log, order.join(","));
  order.length = 0;
}
main();
