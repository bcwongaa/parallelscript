// Kept C<any> roots in other call and store forms: ?. calls, element-access calls, ??=, await in arguments, nested roots
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  handler: ((rows: T[]) => void) | null = null;
  on(h: (rows: T[]) => void): Emitter<T> { this.handlers.push(h); return this; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
const order: string[] = [];
const e = new Emitter<any>();
const maybe: { bus?: Emitter<any> } = { bus: e };
function busOf(tag: string): Emitter<any> { order.push(tag); return e; }
function h(rows: any[]): void { rows.push(1); }
function g(rows: any[]): void { rows.push(2); }
maybe.bus?.on(h);
console.log("optional", maybe.bus?.off(h), e.handlers.length);
busOf("a")["on"](h);
console.log("element", busOf("b")["off"](h), e.handlers.length, order.join(","));
busOf("c").handler ??= h;
busOf("d").handler ??= g;
console.log("nullish", e.handler === h, order.join(","));
busOf("e").on(h).on(g);
console.log("chain", busOf("f").off(g), busOf("g").off(h), e.handlers.length, order.join(","));
async function main(): Promise<void> {
  busOf("h").on(await Promise.resolve(h));
  console.log("await", busOf("i").off(h), e.handlers.length, order.join(","));
  const inner = new Emitter<any>();
  busOf("j").on((rows: any[]) => { inner.on(h); rows.push(inner.off(h)); });
  const rows: any[] = [];
  for (const f of e.handlers) f(rows);
  console.log("nested", rows, order.join(","));
}
main();
