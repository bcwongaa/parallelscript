class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): number { this.handlers.push(h); return this.handlers.length; }
}
function h(rows: any[]): void { rows.push(1); }
const buses: Emitter<any>[] = [new Emitter<any>(), new Emitter<any>()];
let i = 0;
buses[i++].on(h);
console.log("index", i, buses[0].handlers.length, buses[1].handlers.length);
