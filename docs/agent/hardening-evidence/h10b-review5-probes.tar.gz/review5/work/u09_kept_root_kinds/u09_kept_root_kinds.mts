// Kept roots that are an `await`, a `yield`, `super.bus`, a narrowed `this.o`, a comma
// expression: evaluated once, in order, identity kept.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): number { this.handlers.push(h); return this.handlers.length; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
const order: string[] = [];
const e = new Emitter<any>();
function log(rows: any[]): void { rows.push(1); }
function la(rows: any): void { rows.push(1); }
async function getBus(): Promise<Emitter<any>> { order.push("get"); return e; }
async function main(): Promise<void> {
  (await getBus()).on(log);
  console.log("await root", (await getBus()).off(log), order.join(","));
  order.length = 0;
}
function* gen(): Generator<number, void, Emitter<any>> {
  (yield 1).on(log);
  console.log("yield root", e.off(log));
}
class Base { get bus(): Emitter<any> { order.push("super"); return e; } }
class Derived extends Base {
  attach(): boolean { super.bus.on(log); return super.bus.off(log); }
}
class Holder {
  o: object = e;
  run(): string {
    if (this.o instanceof Emitter) { this.o.on(la); return String(this.o.off(la)) + " " + e.handlers.length; }
    return "no";
  }
}
const it = gen(); it.next(); it.next(e);
console.log("super", new Derived().attach(), order.join(","));
order.length = 0;
console.log("narrowed this.o", new Holder().run());
(order.push("comma"), e).on(log);
console.log("comma", e.off(log), order.join(","));
order.length = 0;
main();
