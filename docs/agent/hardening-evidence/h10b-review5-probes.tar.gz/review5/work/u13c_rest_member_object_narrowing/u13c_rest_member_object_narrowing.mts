// A rest pattern of a member of an `object` narrowing (D-218's PTS1001 expected, as for spreads in snapshot 6).
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
function fromObject(o: object): number {
  if (!(o instanceof Box)) return -1;
  const { name, ...r } = o.meta; r.tags.push(1);
  return r.tags.length;
}
const num = new Box<number>(0);
console.log(fromObject(num), JSON.stringify(num.meta.tags));
