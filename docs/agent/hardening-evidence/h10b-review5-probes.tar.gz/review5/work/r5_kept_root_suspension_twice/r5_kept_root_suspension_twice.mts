// R5-F5: with an `await` (or `yield`) in the arguments or the right side, a C<any> root that
// isn't itself the call's receiver or the store's object (`busOf().handlers.push(await f)`,
// `busOf().handlers[0] = await f`) is evaluated twice: once by the suspension's hoisting of
// the receiver, once more by keepingAnyInstanceRoot, after the suspension.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
}
const order: string[] = [];
const e = new Emitter<any>();
function busOf(tag: string): Emitter<any> { order.push(tag); return e; }
function log(rows: any[]): void { rows.push(1); }
class Service { bus = e; get viaGetter(): Emitter<any> { order.push("get"); return this.bus; } }
const svc = new Service();
async function main(): Promise<void> {
  busOf("push").handlers.push(await Promise.resolve(log));
  busOf("store").handlers[1] = await Promise.resolve(log);
  svc.viaGetter.handlers.push(await Promise.resolve(log));
  console.log(order.join(","), e.handlers.indexOf(log), e.handlers.lastIndexOf(log));
}
function* gen(): Generator<number, void, (rows: any[]) => void> {
  svc.viaGetter.handlers.push(yield 1);
  console.log("yield", order.join(","));
  order.length = 0;
}
const it = gen(); it.next(); it.next(log);
main();
// Node: yield get / push,store,get 0 2
