class Box<T> {
  constructor(public v: T) {}
  zorkify(): number { return 1; }
}
const b: Box<any> = new Box<number>(1);
console.log("zorkify" in b, "nope" in b);
const { v, ...rest } = b;
console.log("zorkify" in rest, "v" in rest, v);
