// Spreads of a Box<any> place's members before an `await`/`yield` in the same literal
// (D-188's kept spreads, which use spreadNames): methods, optional keys, as-is arrays.
class Box<T> {
  lit: { f(): number; x: number } = { f() { return 4; }, x: 5 };
  meta: { name: string; opt?: number; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
async function main(): Promise<void> {
  const s = { ...b.lit, extra: await Promise.resolve(1) };
  console.log("await lit", Object.keys(s).join(","), s.f(), s.x, s.extra);
  const m = { ...b.meta, extra: await Promise.resolve(2) };
  m.tags.push(7);
  console.log("await meta", Object.keys(m).join(","), "opt" in m, JSON.stringify(b.meta.tags));
}
function* gen(): Generator<number, void, number> {
  const m = { ...b.meta, y: yield 1 };
  m.tags.push(8);
  console.log("yield meta", Object.keys(m).join(","), JSON.stringify(b.meta.tags));
}
const it = gen(); it.next(); it.next(3);
main();
