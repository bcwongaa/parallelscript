// Destructuring assignments from a Box<any> place holding a Box<number> (and a Box<any>):
// shorthand `({ items } = b)`, renamed `({ items: it } = b)`, a member `({ tags } = b.meta)`,
// a rest `({ v, ...r } = b)`, an array pattern `[first] = b.rows`.
class Box<T> {
  items: T[] = [];
  rows: T[][] = [[]];
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("shorthand", () => { let items: any[] = []; ({ items } = b); items.push("s"); return items.length; });
  t("renamed", () => { let it: any[] = []; ({ items: it } = b); it.push("r"); return it.length; });
  t("member", () => { let tags: any[] = []; ({ tags } = b.meta); tags.push("m"); return tags.length; });
  t("member renamed", () => { let tg: any[] = []; ({ tags: tg } = b.meta); tg.push("mr"); return tg.length; });
  t("decl shorthand", () => { const { items } = b; items.push("d"); return items.length; });
}
const num = new Box<number>(0);
forms(num as Box<any>);
console.log("number", JSON.stringify(num.items), JSON.stringify(num.meta.tags),);
const any = new Box<any>(0);
forms(any);
console.log("any", JSON.stringify(any.items), JSON.stringify(any.meta.tags),);
