// `"k" in v` for dynamic values whose tsc type declares k (propertyIn's new DynamicHas):
// members of a Box<any> place of library kinds (Map, Set, Error, Date, function, Promise,
// array, regexp), a class's method and getter, and a type-guarded unknown.
class Item { n = 1; get g(): number { return 2; } m(): number { return 3; } }
class Box<T> {
  map = new Map<string, T>();
  set = new Set<T>();
  err = new Error("x");
  date = new Date(0);
  fn = (x: T) => x;
  p = Promise.resolve(1);
  arr: T[] = [];
  re = /a/g;
  item = new Item();
  opt?: number;
  constructor(public v: T) {}
}
const b: Box<any> = new Box<any>(0);
console.log("map", "size" in b.map, "get" in b.map);
console.log("set", "size" in b.set, "has" in b.set);
console.log("err", "message" in b.err, "stack" in b.err, "name" in b.err);
console.log("date", "getTime" in b.date);
console.log("fn", "length" in b.fn, "call" in b.fn);
console.log("p", "then" in b.p);
console.log("arr", "length" in b.arr, "push" in b.arr);
console.log("re", "lastIndex" in b.re, "source" in b.re, "exec" in b.re);
console.log("item", "n" in b.item, "g" in b.item, "m" in b.item);
console.log("box", "v" in b, "map" in b, "opt" in b);
function isSized(u: unknown): u is { size: number } { return typeof u === "object" && u !== null; }
const u: unknown = new Map([["a", 1]]);
if (isSized(u)) console.log("guard", "size" in u);
