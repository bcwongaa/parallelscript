// A spread of a narrowing's member only read afterwards (JSON, a length): correct as a copy.
interface Shape { kind(): string; }
class Box<T> implements Shape {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
  kind(): string { return "box"; }
}
function show(s: Shape): string {
  if (s instanceof Box) { const m = { ...s.meta }; return JSON.stringify(m) + " " + m.tags.length; }
  return "";
}
const b = new Box<number>(0); b.meta.tags.push(4);
console.log(show(b));
