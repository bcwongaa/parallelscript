// A spread of a narrowing's member typed any (D-218: members tsc types any taken as any),
// and of a member without arrays.
interface Shape { kind(): string; }
class Box<T> implements Shape {
  info: any = { tags: [1] };
  plain: { name: string; n: number } = { name: "p", n: 2 };
  constructor(public v: T) {}
  kind(): string { return "box"; }
}
function show(s: Shape): void {
  if (s instanceof Box) {
    const i = { ...s.info }; i.tags.push(2);
    const p = { ...s.plain, more: true };
    console.log(JSON.stringify(i), JSON.stringify(p), JSON.stringify(s.info));
  }
}
show(new Box<number>(0));
