// Pre-existing (runtime pts_dynamic_has): common duck-typing idioms on values of library kinds.
function isPromiseLike(x: unknown): x is PromiseLike<unknown> { return typeof x === "object" && x !== null && "then" in x; }
function isSized(x: object): boolean { return "size" in x; }
console.log(isPromiseLike(Promise.resolve(1)), isSized(new Map()), isSized(new Set()), isSized({ size: 1 }));
