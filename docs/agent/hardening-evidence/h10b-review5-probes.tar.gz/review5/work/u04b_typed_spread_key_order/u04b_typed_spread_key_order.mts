// Key order of spreads of typed objects (no Box<any>): for comparison with u04 and u15.
type Meta = { name: string; count: number };
type Opt = { name: string; max?: number; tags: string[] };
const m: Meta = { count: 1, name: "m" };
console.log("typed full", JSON.stringify({ ...m }));
console.log("typed extra", JSON.stringify({ ...m, extra: true }));
const o: Opt = { name: "o", tags: [] };
console.log("absent optional", Object.keys({ ...o, max: 3 }).join(","));
class Box<T> { meta: Meta = { count: 1, name: "b" }; constructor(public v: T) {} }
const b = new Box<number>(0);
console.log("typed box", JSON.stringify({ ...b.meta }));
