// Rest patterns and destructuring of a member (`b.meta`) for a Box<number>: in a Box<any>
// place, from an `object` narrowing and from an `unknown` narrowing.
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function place(b: Box<any>): void {
  t("place rest", () => { const { name, ...r } = b.meta; r.tags.push("pr"); return r.tags.length; });
  t("place pattern", () => { const { tags } = b.meta; tags.push("pp"); return tags.length; });
  t("place assign", () => { let tags: any[] = []; ({ tags } = b.meta); tags.push("pa"); return tags.length; });
  t("place rest assign", () => { let r: { tags: any[] } = { tags: [] }; let name = ""; ({ name, ...r } = b.meta); r.tags.push("pra"); return r.tags.length; });
}
function fromUnknown(u: unknown): void {
  if (!(u instanceof Box)) return;
  t("unknown rest", () => { const { name, ...r } = u.meta; r.tags.push("ur"); return r.tags.length; });
  t("unknown pattern", () => { const { tags } = u.meta; tags.push("up"); return tags.length; });
}
const num = new Box<number>(0);
place(num as Box<any>);
fromUnknown(num);
console.log("number", JSON.stringify(num.meta.tags));
