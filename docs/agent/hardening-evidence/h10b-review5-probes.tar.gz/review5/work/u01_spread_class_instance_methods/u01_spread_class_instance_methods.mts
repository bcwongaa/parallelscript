// R4-F4 follow-on: spreadNames now lists an object type's methods for dynamic values. A class
// instance held where such an object type goes has its methods on the prototype: JS's spread
// copies own properties only, so the method is absent (undefined) in the copy.
interface Shape { kind(): string; x: number; }
class ShapeImpl implements Shape { x = 7; kind(): string { return "impl"; } }
class Box<T> {
  meta: Shape = { kind() { return "lit"; }, x: 5 };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const s1 = { ...b.meta };
console.log("lit", Object.keys(s1).join(","), s1.x, s1.kind());
b.meta = new ShapeImpl();
const s2 = { ...b.meta };
console.log("impl keys", Object.keys(s2).join(","), s2.x, typeof s2.kind);
try { console.log("call", s2.kind()); } catch (e) { console.log("call", (e as Error).name); }
const nb = new Box<number>(0);
nb.meta = new ShapeImpl();
const viaPlace = (p: Box<any>) => { const s = { ...p.meta }; return Object.keys(s).join(",") + " " + s.x; };
console.log("place", viaPlace(nb), viaPlace(b));
