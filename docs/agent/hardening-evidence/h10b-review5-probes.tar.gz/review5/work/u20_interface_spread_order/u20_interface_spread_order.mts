// From the emit-c sweep (corpus functional/transducers.pts lost pts_object_take_order):
// a spread of an interface-typed value, then a later property replacing one of its keys.
// JS keeps the source's own key order.
interface Reading { sensor: string; value: number; ok: boolean; }
const r: Reading = { ok: true, value: 1.4, sensor: "a" };
const round = (x: Reading) => ({ ...x, value: Math.round(x.value) });
console.log(JSON.stringify(round(r)), Object.keys(round(r)).join(","));
const copy = (x: Reading) => ({ ...x });
console.log(JSON.stringify(copy(r)));
type Pt = { y: number; x: number };
const p: Pt = { x: 1, y: 2 };
console.log(JSON.stringify({ ...p, y: 5 }));
