// Logical assignments storing functions through C<any> roots reached by a getter or a call:
// evaluated once, identity kept (p08 covered `??=` through a call).
class Emitter<T> {
  handler: ((rows: T[]) => void) | null = null;
  cfg: { on: ((rows: T[]) => void) | null } = { on: null };
}
const order: string[] = [];
const e = new Emitter<any>();
class Svc { get bus(): Emitter<any> { order.push("get"); return e; } }
const svc = new Svc();
function log(rows: any[]): void { rows.push(1); }
function other(rows: any[]): void { rows.push(2); }
svc.bus.handler ||= log;
svc.bus.handler ||= other;
console.log("||=", e.handler === log, order.join(","));
order.length = 0;
svc.bus.handler &&= other;
console.log("&&=", e.handler === other, order.join(","));
order.length = 0;
svc.bus.cfg.on ??= log;
console.log("cfg ??=", e.cfg.on === log, order.join(","));
order.length = 0;
const fns = [log];
let k = 0;
svc.bus.cfg.on = fns[k++];
console.log("element value", e.cfg.on === log, k, order.join(","));
