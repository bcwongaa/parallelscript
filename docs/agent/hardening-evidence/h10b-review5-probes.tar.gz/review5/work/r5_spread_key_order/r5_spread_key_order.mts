// R5-F6: a spread that copies all of a Box<any> place's member copies its keys in the order
// tsc declares them, not the object's own order (the base kept the source's order).
type Meta = { name: string; count: number };
class Box<T> {
  meta: Meta = { count: 1, name: "m" };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
console.log(JSON.stringify(b.meta), JSON.stringify({ ...b.meta }), Object.keys({ ...b.meta }).join(","));
// Node and base: {"count":1,"name":"m"} {"count":1,"name":"m"} count,name
