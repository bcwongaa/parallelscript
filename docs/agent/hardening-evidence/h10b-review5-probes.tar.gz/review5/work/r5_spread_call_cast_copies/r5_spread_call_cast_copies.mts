// R5-F3: R4-F3's as-is rule for spreads reaches a C<any> value's members through property
// and element accesses only (anyInstanceRoot): the same member reached by a method call, an
// `as` cast or `find(…)!` is copied silently for a Box<number> in a Box<any> place and for an
// `unknown` narrowed to Box. (`const m: Meta = b.getMeta()` is the as-is TypeError.)
type Meta = { name: string; tags: any[] };
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  metas: { name: string; tags: T[] }[] = [this.meta];
  constructor(public v: T) {}
  getMeta(): { name: string; tags: T[] } { return this.meta; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function fromPlace(b: Box<any>): void {
  t("call", () => { const m = { ...b.getMeta() }; m.tags.push("c"); return m.tags.length; });
  t("cast", () => { const m = { ...(b.meta as Meta) }; m.tags.push("x"); return m.tags.length; });
  t("find", () => { const m = { ...b.metas.find(() => true)! }; m.tags.push("f"); return m.tags.length; });
}
function fromUnknown(u: unknown): void {
  if (u instanceof Box) t("unknown call", () => { const m = { ...u.getMeta() }; m.tags.push("u"); return m.tags.length; });
}
const num = new Box<number>(0);
fromPlace(num as Box<any>);
fromUnknown(num);
console.log("tags", JSON.stringify(num.meta.tags));
// Node: call 1 / cast 2 / find 3 / unknown call 4 / tags ["c","x","f","u"]
