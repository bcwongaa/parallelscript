// For comparison with u02: `"k" in v` through keyIn (a key the type doesn't declare, or `any`),
// on the same library kinds: whether the runtime's DynamicHas gap is older than snapshot 5.
const vals: any[] = [new Map(), new Set(), (x: number) => x, Promise.resolve(1), [1], new Error("e")];
const keys = ["size", "size", "length", "then", "push", "message"];
for (let i = 0; i < vals.length; i++) console.log(keys[i], keys[i] in vals[i]);
const o: object = new Map();
console.log("object size", "size" in o);
