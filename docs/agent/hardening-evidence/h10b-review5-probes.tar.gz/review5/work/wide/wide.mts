class Box<T> {
  wide: { k: number } = { k: 6, extra: 7 } as { k: number };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
console.log("wide", JSON.stringify({ ...b.wide }));
const c = new Box<number>(0);
console.log("wideTyped", JSON.stringify({ ...c.wide }));
