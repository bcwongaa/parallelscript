// A spread of the narrowing itself, only read.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function show(o: object): string {
  if (o instanceof Box) { const c = { ...o }; return JSON.stringify(c) + c.items.length; }
  return "";
}
const b = new Box<number>(0); b.items.push(1);
console.log(show(b));
