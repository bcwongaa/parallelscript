// From the emit-c sweep: transducers.pts's `mapT((r: Reading) => ({ ...r, value: … }))`
// lost pts_object_take_order on snapshot 6. Readings whose own key order differs from the
// interface's, printed: JS keeps each source's own order.
// Transducers: composable reducer transformers for single-pass collection processing.

type Reducer<A, T> = (acc: A, x: T) => A;
type Transducer<T, U> = <A>(next: Reducer<A, U>) => Reducer<A, T>;

const mapT = <T, U>(f: (x: T) => U): Transducer<T, U> => (next) => (acc, x) => next(acc, f(x));
const filterT = <T>(p: (x: T) => boolean): Transducer<T, T> => (next) => (acc, x) => (p(x) ? next(acc, x) : acc);
const tapT = <T>(f: (x: T) => void): Transducer<T, T> => (next) => (acc, x) => {
  f(x);
  return next(acc, x);
};
const flatMapT = <T, U>(f: (x: T) => U[]): Transducer<T, U> => (next) => (acc, x) => f(x).reduce(next, acc);
const dedupeT = <T>(): Transducer<T, T> => (next) => {
  let first = true;
  let prev: T | undefined;
  return (acc, x) => {
    if (!first && x === prev) return acc;
    first = false;
    prev = x;
    return next(acc, x);
  };
};

function comp<A, B, C>(t1: Transducer<A, B>, t2: Transducer<B, C>): Transducer<A, C>;
function comp<A, B, C, D>(t1: Transducer<A, B>, t2: Transducer<B, C>, t3: Transducer<C, D>): Transducer<A, D>;
function comp<A, B, C, D, E>(t1: Transducer<A, B>, t2: Transducer<B, C>, t3: Transducer<C, D>, t4: Transducer<D, E>): Transducer<A, E>;
function comp(...ts: Array<Transducer<any, any>>): Transducer<any, any> {
  return (next) => ts.reduceRight((r, t) => t(r), next);
}

function transduce<T, U, A>(xf: Transducer<T, U>, rf: Reducer<A, U>, init: A, xs: Iterable<T>): A {
  const step = xf(rf);
  let acc = init;
  for (const x of xs) acc = step(acc, x);
  return acc;
}

const intoArray = <T>(acc: T[], x: T): T[] => { acc.push(x); return acc; };
interface Reading { sensor: string; value: number; ok: boolean; }
const readings: Reading[] = [{ ok: true, value: 21.5, sensor: "t1" }, { value: 3.2, sensor: "t2", ok: true }];
const valid = comp(filterT((r: Reading) => r.ok), mapT((r: Reading) => ({ ...r, value: Math.round(r.value) })));
const out = transduce(valid, intoArray, [] as Reading[], readings);
console.log(JSON.stringify(out));
const direct = readings.map((r: Reading) => ({ ...r, value: Math.round(r.value) }));
console.log(JSON.stringify(direct));
