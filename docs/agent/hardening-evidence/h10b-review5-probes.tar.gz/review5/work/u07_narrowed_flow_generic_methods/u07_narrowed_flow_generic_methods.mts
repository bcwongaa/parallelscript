// R4-F2's exclusion (narrowedByInstanceof) against other flows of a narrowing's object into
// generic method calls: an array literal's element, an annotated local, ident(o), a
// destructured local, a captured const, `as`, a callback's parameter, a `let` assigned later.
class Box<T> {
  next: Box<T> | null = null;
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).message); }
};
function ident<X>(x: X): X { return x; }
function run(o: object): void {
  if (!(o instanceof Box)) return;
  t("element", () => { const arr = [o]; return arr[0].map((v) => 1).v; });
  t("ident", () => ident(o).map((v) => 2).v);
  t("destructured", () => { const { m } = { m: o }; return m.map((v) => 3).v; });
  t("captured", () => { const m = o; const g = () => m.map((v) => 4).v; return g(); });
  t("as", () => (o as Box<any>).map((v) => 5).v);
  t("callback", () => [o].map((x) => x.map((v) => 6).v));
  t("let", () => { let m = o; m = o; return m.map((v) => 7).v; });
  t("chain", () => o.map((v) => 8).map((w) => w + 1).v);
  t("ternary", () => (o.v ? o : o).map((v) => 10).v);
  t("next", () => { const n = o.next; return n ? n.map((v) => 11).v : null; });
  t("annotated", () => { const m: Box<any> = o; return m.map((v) => 12).v; });
}
const b = new Box<number>(1);
b.next = new Box<number>(2);
run(b);
