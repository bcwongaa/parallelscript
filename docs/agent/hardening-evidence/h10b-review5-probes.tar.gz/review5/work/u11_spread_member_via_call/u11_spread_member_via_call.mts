// R4-F3's as-is rule for spreads reaches members (`{ ...b.meta }`) through property and
// element accesses only (anyInstanceRoot). Spreads of the same object reached by a method
// call, a cast or a deeper member, for a Box<number> in a Box<any> place: as-is TypeError
// or a silent copy?
type Meta = { name: string; tags: any[] };
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  metas: { name: string; tags: T[] }[] = [this.meta];
  sub = { inner: this.meta };
  constructor(public v: T) {}
  getMeta(): { name: string; tags: T[] } { return this.meta; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("member", () => { const m = { ...b.meta }; m.tags.push("member"); return m.tags.length; });
  t("element", () => { const m = { ...b.metas[0] }; m.tags.push("element"); return m.tags.length; });
  t("deeper", () => { const m = { ...b.sub.inner }; m.tags.push("deeper"); return m.tags.length; });
  t("call", () => { const m = { ...b.getMeta() }; m.tags.push("call"); return m.tags.length; });
  t("cast", () => { const m = { ...(b.meta as Meta) }; m.tags.push("cast"); return m.tags.length; });
  t("find", () => { const m = { ...b.metas.find(() => true)! }; m.tags.push("find"); return m.tags.length; });
  t("annotated", () => { const m: Meta = b.getMeta(); m.tags.push("ann"); return m.tags.length; });
}
const any = new Box<any>(0);
forms(any);
console.log("any shared", JSON.stringify(any.meta.tags));
const num = new Box<number>(0);
forms(num as Box<any>);
console.log("number shared", JSON.stringify(num.meta.tags));
