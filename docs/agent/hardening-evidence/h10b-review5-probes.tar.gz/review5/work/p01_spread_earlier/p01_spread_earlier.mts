// Spreads of a Box<any> member over earlier properties; rest of a member; optional absent
class LitClass { x = 3; f(): number { return 9; } }
class Box<T> {
  meta: { name: string; opt?: number } = { name: "m" };
  full: { name: string; opt?: number } = { name: "n", opt: 5 };
  undef: { name: string; opt?: number } = { name: "u", opt: undefined };
  lit: { f(): number; x: number } = { f() { return 4; }, x: 5 };
  cls: { f(): number; x: number } = new LitClass();
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message.slice(0, 60)); } };
t("over", () => { const o = { opt: 1, ...b.meta }; return [JSON.stringify(o), Object.keys(o)]; });
t("overFull", () => { const o = { opt: 1, ...b.full }; return [JSON.stringify(o), Object.keys(o)]; });
t("overUndef", () => { const o = { opt: 1, ...b.undef }; return [JSON.stringify(o), Object.keys(o), "opt" in o]; });
t("after", () => { const o = { ...b.meta, opt: 2 }; return [JSON.stringify(o), Object.keys(o)]; });
t("twice", () => { const o = { ...b.full, ...b.meta }; return [JSON.stringify(o), Object.keys(o)]; });
t("rest", () => { const { name, ...rest } = b.meta; return [name, Object.keys(rest), "opt" in rest]; });
t("restFull", () => { const { name, ...rest } = b.full; return [name, Object.keys(rest), rest.opt]; });
t("restUndef", () => { const { name, ...rest } = b.undef; return [name, Object.keys(rest), "opt" in rest]; });
t("litCall", () => { const o = { ...b.lit }; return [o.f(), o.x]; });
t("clsSpread", () => { const o = { ...b.cls }; return [typeof (o as any).f, o.x]; });
