// Function identity through `any` and through an instanceof narrowing's dynamic value
// (D-075's adapter): `on(f)` then `off(f)` on the same object.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): number { this.handlers.push(h); return this.handlers.length; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
function la(rows: any): void { rows.push(1); }
function lv(rows: any[]): void { rows.push(1); }
const e = new Emitter<any>();
const a: any = e;
a.on(la); console.log("any la", a.off(la), e.handlers.length);
a.on(lv); console.log("any lv", a.off(lv), e.handlers.length);
const x: object = e;
if (x instanceof Emitter) { x.on(la); console.log("local narrowing la", x.off(la), e.handlers.length); }
const holder = { o: e as object };
if (holder.o instanceof Emitter) { holder.o.on(la); console.log("member narrowing la", holder.o.off(la), e.handlers.length); }
const n = new Emitter<number>();
const nx: object = n;
if (nx instanceof Emitter) { nx.on(la); console.log("number narrowing la", nx.off(la), n.handlers.length); }
