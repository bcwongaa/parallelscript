// The snapshot-6 PTS1001 for `{ ...o.meta }` of a narrowing: the same object reached by a
// method call, a cast or `find(...)!`, for `object` and `unknown` sources holding a Box<number>.
type Meta = { name: string; tags: any[] };
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  metas: { name: string; tags: T[] }[] = [this.meta];
  constructor(public v: T) {}
  getMeta(): { name: string; tags: T[] } { return this.meta; }
}
function fromObject(o: object): number {
  if (!(o instanceof Box)) return -1;
  const a = { ...o.getMeta() }; a.tags.push(1);
  const b = { ...(o.meta as Meta) }; b.tags.push(2);
  const c = { ...o.metas.find(() => true)! }; c.tags.push(3);
  return a.tags.length + b.tags.length + c.tags.length;
}
function fromUnknown(u: unknown): number {
  if (!(u instanceof Box)) return -1;
  const a = { ...u.getMeta() }; a.tags.push(4);
  const b = { ...(u.meta as Meta) }; b.tags.push(5);
  return a.tags.length + b.tags.length;
}
const n = new Box<number>(0);
console.log(fromObject(n), fromUnknown(n), JSON.stringify(n.meta.tags));
