// Spreads of members of instanceof narrowings (object and interface sources), holding Box<number> and Box<any>
interface Shape { kind(): string; }
class Box<T> implements Shape {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
  kind(): string { return "box"; }
}
const t = (name: string, f: () => unknown) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message.slice(0, 50)); } };
function fromObject(o: object): string[] { if (o instanceof Box) { const m = { ...o.meta }; m.tags.push(1); return Object.keys(m); } return []; }
function fromShape(s: Shape): string[] { if (s instanceof Box) { const m = { ...s.meta }; m.tags.push(2); return Object.keys(m); } return []; }
const nb = new Box<number>(0), ab = new Box<any>(0);
t("object number", () => fromObject(nb));
t("shape number", () => fromShape(nb));
t("object any", () => fromObject(ab));
t("shape any", () => fromShape(ab));
console.log(JSON.stringify(nb.meta.tags), JSON.stringify(ab.meta.tags));
