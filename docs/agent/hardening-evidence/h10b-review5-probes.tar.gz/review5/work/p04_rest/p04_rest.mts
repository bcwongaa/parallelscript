class Box<T> {
  meta: { name: string; opt?: number } = { name: "m" };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const { name, ...rest } = b.meta;
console.log(name, Object.keys(rest), "opt" in rest);
