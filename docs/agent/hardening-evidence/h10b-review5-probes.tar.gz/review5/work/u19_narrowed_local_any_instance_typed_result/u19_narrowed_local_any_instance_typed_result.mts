// R4-F2 sends generic methods on a narrowing's locals through any. With Box's instance for
// any in the narrowing and the result going to a typed Box<number>: the erased copy's
// result (R2-F5's concern) against the base.
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).message); }
};
function run(o: object): void {
  if (!(o instanceof Box)) return;
  t("narrowing typed", () => { const r: Box<number> = o.map((v) => 1); return r.v + 1; });
  t("local typed", () => { const m = o; const r: Box<number> = m.map((v) => 2); return r.v + 1; });
  t("local chain", () => { const m = o; return m.map((v) => 3).map((w: number) => w * 2).v; });
}
run(new Box<any>("a"));
run(new Box<string>("s"));
