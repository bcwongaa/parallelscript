// A spread of the narrowing itself (`{ ...o }`, Box with an array field), then a write.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function grow(o: object): string {
  if (o instanceof Box) { const c = { ...o }; c.items.push(5); return JSON.stringify(c); }
  return "";
}
const b = new Box<number>(0);
console.log(grow(b), JSON.stringify(b.items));
