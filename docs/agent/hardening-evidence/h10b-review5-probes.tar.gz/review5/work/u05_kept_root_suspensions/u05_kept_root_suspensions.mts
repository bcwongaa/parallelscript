// keepingAnyInstanceRoot with a suspension in the arguments: a getter root read once and
// in order, the function keeping its identity; also a receiver deeper than the root
// (`svc.viaGetter.handlers.push(await …)`), where the hoisted receiver isn't the root.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void, tag?: unknown): number { this.handlers.push(h); return this.handlers.length; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
const order: string[] = [];
class Service {
  bus: Emitter<any> = new Emitter<any>();
  get viaGetter(): Emitter<any> { order.push("get"); return this.bus; }
}
function log(rows: any[]): void { rows.push(1); }
const svc = new Service();
async function main(): Promise<void> {
  svc.viaGetter.on(log, await Promise.resolve("t"));
  console.log("await tag", svc.bus.off(log), order.join(","));
  order.length = 0;
  svc.viaGetter.on(await Promise.resolve(log));
  console.log("await fn", svc.bus.off(log), order.join(","));
  order.length = 0;
  svc.viaGetter.handlers.push(await Promise.resolve(log));
  console.log("await push", svc.bus.off(log), order.join(","));
  order.length = 0;
  svc.viaGetter.handlers.push(log, await Promise.resolve(log));
  console.log("await push2", svc.bus.off(log), svc.bus.off(log), order.join(","));
  order.length = 0;
}
function* gen(): Generator<number, void, (rows: any[]) => void> {
  svc.viaGetter.on(yield 1);
  console.log("yield fn", svc.bus.off(log), order.join(","));
  order.length = 0;
  svc.viaGetter.on(log, yield 2);
  console.log("yield tag", svc.bus.off(log), order.join(","));
  order.length = 0;
  svc.viaGetter.handlers.push(yield 3);
  console.log("yield push", svc.bus.off(log), order.join(","));
  order.length = 0;
}
const it = gen();
it.next();
it.next(log);
it.next(log);
it.next(log);
main();
