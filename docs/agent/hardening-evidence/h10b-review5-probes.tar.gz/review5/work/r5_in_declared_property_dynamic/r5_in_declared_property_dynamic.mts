// R5-F1: `"k" in v` for a dynamic value whose type declares k is now looked up at run time
// (propertyIn's new DynamicHas), and the runtime's lookup misses what library objects have on
// their prototypes: false for a Map's size, a Set's has, a function's length, a promise's
// then, an array's push. Also outside H10b: an `unknown` a type guard narrowed.
class Box<T> {
  map = new Map<string, T>();
  set = new Set<T>();
  fn = (x: T) => x;
  p = Promise.resolve(1);
  arr: T[] = [];
  constructor(public v: T) {}
}
const b: Box<any> = new Box<any>(0);
console.log("box members", "size" in b.map, "has" in b.set, "length" in b.fn, "then" in b.p, "push" in b.arr);
function isSized(u: unknown): u is { size: number } { return typeof u === "object" && u !== null; }
const u: unknown = new Map([["a", 1]]);
if (isSized(u)) console.log("guarded", "size" in u);
// Node: box members true true true true true / guarded true
