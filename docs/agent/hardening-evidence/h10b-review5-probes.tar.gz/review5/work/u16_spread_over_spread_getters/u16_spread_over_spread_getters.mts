// copiedOwnProperty's `earlier` from an earlier spread of a dynamic member: JS reads every
// own property of the first spread (running its getters) before the second spread's. If the
// earlier read sits in the later conditional, a getter may run late, or not at all.
type Meta = { name: string; opt?: string };
class Box<T> {
  meta: Meta = { name: "m" };
  constructor(public v: T) {}
}
const log: string[] = [];
const c = new Box<any>(0);
const b = new Box<any>(0);
c.meta = { name: "c", get opt() { log.push("c.opt"); return "c"; } } as any;
b.meta = { name: "b", get opt() { log.push("b.opt"); return "b"; } } as any;
const s = { ...c.meta, ...b.meta };
console.log("both own", JSON.stringify(s), log.join(","));
log.length = 0;
b.meta = { name: "b2" };
const s2 = { ...c.meta, ...b.meta };
console.log("first own", JSON.stringify(s2), log.join(","));
log.length = 0;
function f(x: Box<any>, y: Box<any>): string { const o = { ...x.meta, ...y.meta }; return JSON.stringify(o); }
console.log("params", f(c, c), log.join(","));
