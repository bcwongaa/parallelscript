// `in` on values a C<any> place, an unknown narrowing and an erased generic hold: fields, optional fields, getters, methods
class Box<T> {
  items: T[] = [];
  opt?: number;
  get size(): number { return this.items.length; }
  constructor(public v: T) {}
  push(x: T): void { this.items.push(x); }
}
const b: Box<any> = new Box<any>(0);
const n: Box<any> = new Box<number>(1);
console.log("place", "items" in b, "opt" in b, "size" in b, "push" in b, "v" in n, "push" in n);
function viaUnknown(u: unknown): string {
  if (u instanceof Box) return `${"items" in u} ${"size" in u} ${"push" in u}`;
  return "no";
}
console.log("unknown", viaUnknown(n));
function has<T extends { items: number[] }>(t: T): boolean { return "items" in t; }
console.log("generic", has({ items: [1] }), has(new Box<number>(2) as any));
const m = { ...b.items.length ? b : n };
console.log("spreadIn", "v" in m);
