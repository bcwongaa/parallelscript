// R5-F4: destructuring assignments from a Box<any> place holding a Box<number> copy silently
// in two forms: a shorthand property `({ items } = b)` (assignShorthand converts plainly) and
// any pattern over a member `({ tags } = b.meta)` (asIs is holdsAnyInstance of the value only).
// The renamed form `({ items: it } = b)` and declarations are the as-is TypeError.
class Box<T> {
  items: T[] = [];
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("shorthand", () => { let items: any[] = []; ({ items } = b); items.push("s"); return items.length; });
  t("member", () => { let tags: any[] = []; ({ tags } = b.meta); tags.push("m"); return tags.length; });
  t("member renamed", () => { let tg: any[] = []; ({ tags: tg } = b.meta); tg.push("r"); return tg.length; });
  t("renamed", () => { let it: any[] = []; ({ items: it } = b); it.push("i"); return it.length; });
}
const num = new Box<number>(0);
forms(num as Box<any>);
console.log("number", JSON.stringify(num.items), JSON.stringify(num.meta.tags));
// Node: shorthand 1 / member 1 / member renamed 2 / renamed 2 / number ["s","i"] ["m","r"]
