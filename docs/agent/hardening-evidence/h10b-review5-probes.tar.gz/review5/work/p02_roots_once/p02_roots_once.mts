// Kept roots: evaluated once per call, in order; stores; identity through stores on non-local roots
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  handler: ((rows: T[]) => void) | null = null;
  cfg: { onRows: ((rows: T[]) => void) | null } = { onRows: null };
  on(h: (rows: T[]) => void): number { this.handlers.push(h); return this.handlers.length; }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
}
const log: string[] = [];
let calls = 0;
const e = new Emitter<any>();
function busOf(): Emitter<any> { calls++; log.push("busOf"); return e; }
function h(rows: any[]): void { rows.push(1); }
function arg(): (rows: any[]) => void { log.push("arg"); return h; }
class Svc {
  inner = new Emitter<any>();
  reads = 0;
  get bus(): Emitter<any> { this.reads++; log.push("get"); return this.inner; }
}
const s = new Svc();
console.log(busOf().on(arg()), calls, log.join(","));
console.log(busOf().off(h), calls, e.handlers.length);
log.length = 0;
console.log(s.bus.on(arg()), s.reads, log.join(","));
console.log(s.bus.off(h), s.reads, s.inner.handlers.length);
busOf().handler = h;
console.log("stored", e.handler === h, calls);
busOf().cfg.onRows = h;
console.log("cfg", e.cfg.onRows === h, calls);
s.bus.handler = h;
console.log("getterStore", s.inner.handler === h, s.reads);
const buses: Emitter<any>[] = [new Emitter<any>(), new Emitter<any>()];
let i = 0;
buses[i++].on(h);
console.log("index", i, buses[0].handlers.length, buses[1].handlers.length, buses[0].off(h));
const rows: any[] = [];
for (const f of e.handlers) f(rows);
console.log(rows.length);
