// R5-F2: a rest pattern of a member copies the member's arrays silently: for an `object`
// narrowing (the rest twin of errors/generic_instanceof_member_spread_copies.pts, PTS1001 on
// the base), and for a Box<number> in a Box<any> place or narrowed from `unknown` (where the
// spread `{ ...b.meta }` is the as-is TypeError since R4-F3).
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function fromObject(o: object): void {
  if (o instanceof Box) t("object", () => { const { name, ...r } = o.meta; r.tags.push("o"); return r.tags.length; });
}
function fromPlace(b: Box<any>): void {
  t("place", () => { const { name, ...r } = b.meta; r.tags.push("p"); return r.tags.length; });
}
function fromUnknown(u: unknown): void {
  if (u instanceof Box) t("unknown", () => { const { name, ...r } = u.meta; r.tags.push("u"); return r.tags.length; });
}
const num = new Box<number>(0);
fromObject(num);
fromPlace(num as Box<any>);
fromUnknown(num);
console.log("tags", JSON.stringify(num.meta.tags));
// Node: object 1 / place 2 / unknown 3 / tags ["o","p","u"]
