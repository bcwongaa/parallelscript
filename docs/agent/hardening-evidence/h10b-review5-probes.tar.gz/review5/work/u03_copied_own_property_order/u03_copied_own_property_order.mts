// copiedOwnProperty: a spread of a Box<any> place's member whose object has own getters
// (an object literal's), read order against later parts with side effects, key order of the
// runtime object against tsc's, a required property the object lacks, spreads over spreads.
const log: string[] = [];
type Meta = { name: string; count: number; opt?: string };
class Box<T> {
  meta: Meta = { name: "m", count: 1 };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
let reads = 0;
b.meta = { get count() { reads++; log.push("count"); return 10 + reads; }, get name() { log.push("name"); return "g"; } } as any;
const side = () => { log.push("later"); return 99; };
const s1 = { ...b.meta, later: side() };
console.log("getters", JSON.stringify(s1), reads, log.join(","));
log.length = 0;
const s1b = { first: side(), ...b.meta };
console.log("before", JSON.stringify(s1b), log.join(","));
b.meta = { count: 2, opt: "o", name: "n" };
const s2 = { ...b.meta };
console.log("order", Object.keys(s2).join(","), JSON.stringify(s2));
b.meta = { name: "only", count: 0 };
const c = new Box<any>(0);
c.meta = { name: "c", count: 3, opt: "co" };
const s5 = { ...c.meta, ...b.meta };
console.log("spread over spread", JSON.stringify(s5), Object.keys(s5).join(","));
const s6 = { ...b.meta, ...c.meta };
console.log("spread over spread 2", JSON.stringify(s6), Object.keys(s6).join(","));
b.meta = { name: "u", count: 4, opt: undefined };
const s7 = { opt: "earlier", ...b.meta };
console.log("own undefined", JSON.stringify(s7), "opt" in s7);
const { name = "dflt", opt = "dopt", ...rest } = b.meta;
console.log("rest defaults", name, opt, JSON.stringify(rest));
b.meta = { count: 6, name: "six" };
const { name: n2 = "dflt", ...rest2 } = b.meta;
console.log("rest defaults 2", n2, JSON.stringify(rest2), Object.keys(rest2).join(","));
