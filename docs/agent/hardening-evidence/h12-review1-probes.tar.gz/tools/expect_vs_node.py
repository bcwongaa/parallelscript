import sys, subprocess, tempfile, shutil, os, re
# For each test file, compare Node's output on a .mts copy with the file's // expect: block.
for path in open(sys.argv[1]).read().split():
    src = open(path).read()
    m = re.search(r'^// expect:\n((?://.*\n?)*)', src, re.M)
    if not m:
        print("NOEXPECT", path); continue
    exp = "\n".join(l[3:] if l.startswith("// ") else l[2:] for l in m.group(1).rstrip("\n").split("\n"))
    d = tempfile.mkdtemp(dir="/tmp/h12/review1")
    shutil.copy(path, os.path.join(d, "p.mts"))
    r = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=60)
    shutil.rmtree(d)
    out = (r.stdout).rstrip("\n")
    print("OK  " if out == exp else "DIFF", os.path.basename(path))
    if out != exp:
        import difflib
        print("\n".join(list(difflib.unified_diff(exp.split("\n"), out.split("\n"), "expect", "node", lineterm=""))[:20]))
