#!/bin/bash
# usage: both.sh file.pts... — node, base and snap2 outputs side by side
for f in "$@"; do
  abs=$(readlink -f "$f")
  d=$(mktemp -d /tmp/h12/review1/run.XXXX)
  cp "$abs" "$d/p.mts"; cp "$abs" "$d/p.pts"
  echo "=== $f"
  echo "--- node"; (cd "$d" && timeout 20 /home/bryan/.local/node/bin/node --experimental-transform-types --no-warnings p.mts 2>&1 | head -${LINES_SHOWN:-30}; echo "rc=${PIPESTATUS[0]}")
  echo "--- base"; (cd "$d" && PTS_HOME=/tmp/h12/base timeout 120 /tmp/h12/base/pts-bin/pts run p.pts 2>&1 | head -${LINES_SHOWN:-30}; echo "rc=${PIPESTATUS[0]}")
  echo "--- snap2"; (cd "$d" && PTS_HOME=/tmp/h12/snap2 timeout 120 /tmp/h12/snap2/pts-bin/pts run p.pts 2>&1 | head -${LINES_SHOWN:-30}; echo "rc=${PIPESTATUS[0]}")
  rm -rf "$d"
done
