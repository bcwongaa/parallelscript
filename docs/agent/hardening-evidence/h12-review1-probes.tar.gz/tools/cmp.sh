#!/bin/bash
# usage: cmp.sh PTS_CLI PTS_HOME file.pts...  — runs each under node (.mts copy) and pts, prints both outputs on diff
cli=$1; home=$2; shift 2
for f in "$@"; do
  abs=$(readlink -f "$f")
  d=$(mktemp -d /tmp/h12/review1/run.XXXX)
  cp "$abs" "$d/p.mts"; cp "$abs" "$d/p.pts"
  nout=$(cd "$d" && timeout 20 /home/bryan/.local/node/bin/node --experimental-transform-types --no-warnings p.mts 2>&1); nrc=$?
  pout=$(cd "$d" && PTS_HOME=$home timeout 120 "$cli" run p.pts 2>&1); prc=$?
  if [ "$nout" == "$pout" ] && [ $nrc == $prc ]; then echo "OK    $f"; else echo "DIFF  $f (node rc=$nrc, pts rc=$prc)"; diff <(echo "$nout") <(echo "$pout") | head -${LINES_SHOWN:-14}; fi
  rm -rf "$d"
done
