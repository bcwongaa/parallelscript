#!/bin/bash
# Reruns the probes behind the round-1 findings against node, the base CLI and snapshot 2.
cd /tmp/h12/review1/p
LINES_SHOWN=${LINES_SHOWN:-10} /tmp/h12/review1/tools/both.sh \
  s27_rest_tuple_assign_declared.pts s32_rest_tuple_generic.pts \
  s20_mutual_loose.pts s20b_mutual_loose_order.pts \
  s35_generic_unknown_first.pts s36_generic_string_first.pts s33_generic_instances.pts \
  g01_starter_recursion.pts \
  p02_iface_method_default.pts p03_override_default.pts p07_abstract.pts \
  o08_nested_default_required_forof.pts o01_nested_obj_default.pts o04_nested_default_getter_order.pts \
  r01b_record_tostring.pts r05b_record_proto.pts \
  s10b_num_ops.pts
