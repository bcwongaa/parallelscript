#!/bin/bash
# emitc_cmp.sh file: emit-c with the base and fix CLIs; prints whether the C (or errors) differ.
f=$1; cd $(dirname $f)
a=$(PTS_HOME=/tmp/h09b5b/base timeout 300 /tmp/h09b5b/base/pts-bin/pts emit-c $f 2>&1 | sha1sum)
b=$(PTS_HOME=/tmp/h09b5b/snap-f timeout 300 /tmp/h09b5b/snap-f/pts-bin/pts emit-c $f 2>&1 | sha1sum)
[ "$a" == "$b" ] && echo "same $f" || echo "DIFF $f"
