package lower

// Review H09b5b round 3 (not part of the repository; added with go test -overlay): a differential
// test of blameOf's per-query caching of cut results (round 3) against round 2's blameOf, which
// didn't cache cut results, and, for graphs without `outer`, against plain reachability (the
// union over what reaches the use, which the round-3 comment says the search computes).

import (
	"fmt"
	"math/rand"
	"slices"
	"sort"
	"strings"
	"testing"
)

// blameOfRound2 is round 2's blameOf (578b12d9f), cut results not cached.
func (l *lowerer) blameOfRound2(u use, search *blames) (b blame, cut bool) {
	switch {
	case u.pairings != nil:
		return blame{pairings: u.pairings}, false
	case u.subst == nil:
		return blame{own: true}, false
	}
	if found, ok := search.found[u.subst]; ok {
		if found == nil {
			return blame{}, true
		}
		return *found, false
	}
	if outer := u.subst.outer; outer != nil {
		if found, ok := search.found[outer]; ok && found == nil {
			return blame{}, true
		}
	}
	if search.steps++; search.steps > maxBlameSteps {
		return blame{own: true}, false
	}
	search.found[u.subst] = nil
	b = blame{own: u.subst.ownUse}
	for _, user := range u.subst.users {
		if b.own {
			break
		}
		ub, c := l.blameOfRound2(user, search)
		b, cut = b.merge(ub), cut || c
	}
	if outer := u.subst.outer; outer != nil {
		class, c := l.blameOfRound2(use{subst: outer}, search)
		cut = cut || c
		if !class.own && len(class.pairings) > 0 && (b.own || len(b.pairings) == 0 || class.level() < b.level()) {
			b = class
		}
	}
	if cut {
		delete(search.found, u.subst)
	} else {
		search.found[u.subst] = &b
	}
	return b, cut
}

// reach is the union over the substitutions that reach s through users: own if one is the
// program's own, else every pairing user's pairings.
func reach(s *substitution) blame {
	seen := map[*substitution]bool{}
	var b blame
	var walk func(s *substitution)
	walk = func(s *substitution) {
		if seen[s] {
			return
		}
		seen[s] = true
		if s.ownUse {
			b.own = true
		}
		for _, u := range s.users {
			switch {
			case u.pairings != nil:
				b = b.with(u.pairings)
			case u.subst != nil:
				walk(u.subst)
			}
		}
	}
	walk(s)
	return b
}

func blameString(b blame) string {
	if b.own {
		return "own"
	}
	var names []string
	for _, p := range b.pairings {
		names = append(names, fmt.Sprintf("%s/L%d", p.name, p.level))
	}
	sort.Strings(names)
	return "{" + strings.Join(slices.Compact(names), " ") + "}"
}

type reviewGraph struct {
	nodes    []*substitution
	describe string
}

func randomGraph(r *rand.Rand, n int, withOuter bool) reviewGraph {
	nodes := make([]*substitution, n)
	for i := range nodes {
		nodes[i] = &substitution{used: true}
	}
	pairings := []pairing{{name: "P0", level: AllInstances}, {name: "P1", level: ValueInstances}, {name: "P2", level: AllInstances}, {name: "P3", level: ValueInstances}}
	var desc strings.Builder
	for i, s := range nodes {
		if r.Intn(6) == 0 {
			s.ownUse = true
		}
		fmt.Fprintf(&desc, "n%d own=%v users=[", i, s.ownUse)
		if !s.ownUse {
			for k := r.Intn(4); k > 0; k-- {
				if r.Intn(3) == 0 {
					p := pairings[r.Intn(len(pairings))]
					s.users = append(s.users, use{pairings: []pairing{p}})
					fmt.Fprintf(&desc, " %s", p.name)
				} else {
					j := r.Intn(n)
					if j == i {
						continue
					}
					s.users = append(s.users, use{subst: nodes[j]})
					fmt.Fprintf(&desc, " n%d", j)
				}
			}
		}
		desc.WriteString(" ]")
		if withOuter && r.Intn(3) == 0 && i+1 < n {
			j := i + 1 + r.Intn(n-i-1) // outers are made before what is nested in them: acyclic
			if j != i {
				s.outer = nodes[j]
				fmt.Fprintf(&desc, " outer=n%d", j)
			}
		}
		desc.WriteString("; ")
	}
	return reviewGraph{nodes: nodes, describe: desc.String()}
}

func TestReviewBlameOfCachingWithoutOuterIsReachability(t *testing.T) {
	r := rand.New(rand.NewSource(1))
	l := &lowerer{}
	mismatches := 0
	for trial := 0; trial < 200000; trial++ {
		g := randomGraph(r, 2+r.Intn(8), false)
		root := g.nodes[0]
		got, _ := l.blameOf(use{subst: root}, newBlames())
		want := reach(root)
		if blameString(got) != blameString(want) {
			mismatches++
			if mismatches <= 5 {
				t.Errorf("graph %s: blameOf %s, reachability %s", g.describe, blameString(got), blameString(want))
			}
		}
	}
	t.Logf("mismatches without outer: %d", mismatches)
}

func TestReviewBlameOfCachingAgainstRound2(t *testing.T) {
	r := rand.New(rand.NewSource(2))
	l := &lowerer{}
	mismatches, ownFlips, round3Own, round3Narrowable := 0, 0, 0, 0
	for trial := 0; trial < 200000; trial++ {
		g := randomGraph(r, 2+r.Intn(7), true)
		root := g.nodes[0]
		got, _ := l.blameOf(use{subst: root}, newBlames())
		want, _ := l.blameOfRound2(use{subst: root}, newBlames())
		if blameString(got) != blameString(want) {
			mismatches++
			if got.own != want.own {
				ownFlips++
				if got.own {
					round3Own++
				} else {
					round3Narrowable++
				}
			}
			if mismatches <= 8 {
				t.Logf("graph %s: round 3 %s, round 2 %s", g.describe, blameString(got), blameString(want))
			}
		}
	}
	t.Logf("mismatches with outer: %d (own vs narrowable: %d; round 3 own where round 2 narrowable: %d; round 3 narrowable where round 2 own: %d)", mismatches, ownFlips, round3Own, round3Narrowable)
}

// made is the least fixed point of which substitutions are made with the pairings in removed
// left out: one is made if the program's own code uses it or a user is made (a pairing user is
// unless removed), and its outer (a method instance's class instance) is made.
func made(nodes []*substitution, removed map[string]bool) map[*substitution]bool {
	m := map[*substitution]bool{}
	for changed := true; changed; {
		changed = false
		for _, s := range nodes {
			if m[s] {
				continue
			}
			ok := s.ownUse
			for _, u := range s.users {
				switch {
				case u.pairings != nil:
					for _, p := range u.pairings {
						ok = ok || !removed[p.name]
					}
				case u.subst != nil:
					ok = ok || m[u.subst]
				}
			}
			if ok && (s.outer == nil || m[s.outer]) {
				m[s], changed = true, true
			}
		}
	}
	return m
}

// TestReviewBlameOfAgainstLeastFixedPoint classifies each answer for the root: own where the root
// is made even with every pairing left out (else a missed narrowing), or pairings whose leaving
// out unmakes the root (else a lowering that fails again).
func TestReviewBlameOfAgainstLeastFixedPoint(t *testing.T) {
	all := map[string]bool{"P0": true, "P1": true, "P2": true, "P3": true}
	for _, withOuter := range []bool{false, true} {
		r := rand.New(rand.NewSource(3))
		l := &lowerer{}
		stats := map[string]int{}
		shown := 0
		for trial := 0; trial < 200000; trial++ {
			g := randomGraph(r, 2+r.Intn(7), withOuter)
			root := g.nodes[0]
			if !made(g.nodes, nil)[root] {
				continue // not made at all: no report
			}
			trueOwn := made(g.nodes, all)[root]
			for name, b := range map[string]blame{"round3": func() blame { b, _ := l.blameOf(use{subst: root}, newBlames()); return b }(),
				"round2": func() blame { b, _ := l.blameOfRound2(use{subst: root}, newBlames()); return b }()} {
				switch {
				case b.own && trueOwn:
					stats[name+" own ok"]++
				case b.own:
					stats[name+" own, narrowable (missed)"]++
				case len(b.pairings) == 0:
					stats[name+" empty"]++
				default:
					removed := map[string]bool{}
					for _, p := range b.pairings {
						removed[p.name] = true
					}
					if made(g.nodes, removed)[root] {
						stats[name+" pairings insufficient"]++
						if name == "round3" && shown < 3 {
							shown++
							t.Logf("outer=%v %s: round 3 %s still made (trueOwn=%v)", withOuter, g.describe, blameString(b), trueOwn)
						}
					} else {
						stats[name+" pairings ok"]++
					}
				}
			}
		}
		t.Logf("withOuter=%v: %v", withOuter, stats)
	}
}

// blameOfFreshOuter is round 3's blameOf with the suggested change: a method instance's class
// instance is blamed in a search of its own (with the method instance cut out of it), so no
// partial result of the enclosing search decides the outer rule.
func (l *lowerer) blameOfFreshOuter(u use, search *blames) (b blame, cut bool) {
	switch {
	case u.pairings != nil:
		return blame{pairings: u.pairings}, false
	case u.subst == nil:
		return blame{own: true}, false
	}
	if found, ok := search.found[u.subst]; ok {
		if found == nil {
			return blame{}, true
		}
		return *found, false
	}
	if outer := u.subst.outer; outer != nil {
		if found, ok := search.found[outer]; ok && found == nil {
			return blame{}, true
		}
	}
	if search.steps++; search.steps > maxBlameSteps {
		return blame{own: true}, false
	}
	search.found[u.subst] = nil
	b = blame{own: u.subst.ownUse}
	for _, user := range u.subst.users {
		if b.own {
			break
		}
		ub, c := l.blameOfFreshOuter(user, search)
		b, cut = b.merge(ub), cut || c
	}
	if outer := u.subst.outer; outer != nil {
		fresh := newBlames()
		for s, f := range search.found {
			if f == nil {
				fresh.found[s] = nil // in progress (the method instance among them): cut
			}
		}
		class, _ := l.blameOfFreshOuter(use{subst: outer}, fresh)
		if !class.own && len(class.pairings) > 0 && (b.own || len(b.pairings) == 0 || class.level() < b.level()) {
			b = class
		}
	}
	search.found[u.subst] = &b
	return b, cut
}

func TestReviewBlameOfFreshOuterAgainstLeastFixedPoint(t *testing.T) {
	all := map[string]bool{"P0": true, "P1": true, "P2": true, "P3": true}
	r := rand.New(rand.NewSource(3))
	l := &lowerer{}
	stats := map[string]int{}
	for trial := 0; trial < 200000; trial++ {
		g := randomGraph(r, 2+r.Intn(7), true)
		root := g.nodes[0]
		if !made(g.nodes, nil)[root] {
			continue
		}
		trueOwn := made(g.nodes, all)[root]
		b, _ := l.blameOfFreshOuter(use{subst: root}, newBlames())
		switch {
		case b.own && trueOwn:
			stats["own ok"]++
		case b.own:
			stats["own, narrowable (missed)"]++
		case len(b.pairings) == 0:
			stats["empty"]++
		default:
			removed := map[string]bool{}
			for _, p := range b.pairings {
				removed[p.name] = true
			}
			if made(g.nodes, removed)[root] {
				stats["pairings insufficient"]++
			} else {
				stats["pairings ok"]++
			}
		}
	}
	t.Logf("fresh outer: %v", stats)
}
