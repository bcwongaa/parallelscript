#!/usr/bin/env python3
"""runexp.py CLI HOME test.pts...: run each test with the CLI (own process group, 120 s) and compare with its // expect: block."""
import os, subprocess, sys, tempfile, shutil
cli, home = sys.argv[1], sys.argv[2]
for t in sys.argv[3:]:
    s = open(t).read()
    exp = s.split('// expect:\n', 1)[1]
    exp = '\n'.join(l[3:] if l.startswith('// ') else l[2:] for l in exp.rstrip('\n').split('\n')) + '\n'
    w = tempfile.mkdtemp(dir='/tmp/h12/work'); shutil.copy(t, os.path.join(w, 'p.pts'))
    p = subprocess.Popen([cli, 'run', 'p.pts'], cwd=w, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, PTS_HOME=home), start_new_session=True)
    try:
        out, err = p.communicate(timeout=120); rc = p.returncode
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, 9); out, err = p.communicate(); rc = 124
    out = out.decode(errors='replace'); err = err.decode(errors='replace')
    print(f"{'PASS' if out == exp and rc == 0 else 'FAIL'} rc={rc} {os.path.basename(t)}" + ('' if out == exp and rc == 0 else f"\n   stdout: {out[:300]!r}\n   stderr: {err[:300]!r}"))
    shutil.rmtree(w, ignore_errors=True)
