#!/usr/bin/env python3
"""replay.py OUT.json DIR [name=CLI:HOME ...] [--jobs N]: run each DIR/*.pts under Node (.mts copy)
and each named CLI; record stdout+stderr and exit codes; print, per probe, which builds match Node
and whether the last build differs from each earlier one."""
import concurrent.futures as cf, glob, json, os, shutil, subprocess, sys, tempfile
args = [a for a in sys.argv[1:] if not a.startswith('--')]
jobs = int(sys.argv[sys.argv.index('--jobs') + 1]) if '--jobs' in sys.argv else 4
if '--jobs' in sys.argv: args.remove(str(jobs))
out, d, clis = args[0], args[1], [a.split('=', 1) for a in args[2:]]
NODE = os.path.expanduser('~/.local/node/bin/node')

def run(cmd, cwd, env=None, timeout=120):
    # its own process group, killed whole on a timeout: `pts run`'s binary outlived it (C342's probe ran for hours)
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return out.decode(errors='replace').replace(cwd, 'DIR'), p.returncode
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, 9)
        p.communicate()
        return 'TIMEOUT', 124

def one(path):
    w = tempfile.mkdtemp(prefix='rp.', dir='/tmp/h12/work')
    try:
        shutil.copy(path, os.path.join(w, 'p.mts')); shutil.copy(path, os.path.join(w, 'p.pts'))
        r = {'probe': os.path.basename(path), 'node': run([NODE, '--experimental-transform-types', '--no-warnings', 'p.mts'], w)}
        for name, spec in clis:
            cli, home = spec.split(':')
            r[name] = run([cli, 'run', 'p.pts'], w, env=dict(os.environ, PTS_HOME=home))
        return r
    finally:
        shutil.rmtree(w, ignore_errors=True)

files = sorted(glob.glob(os.path.join(d, '*.pts')))
with cf.ThreadPoolExecutor(jobs) as ex:
    rows = list(ex.map(one, files))
json.dump(rows, open(out, 'w'), indent=1)
names = [n for n, _ in clis]
for r in rows:
    marks = ' '.join(f"{n}:{'OK' if r[n] == r['node'] else 'x'}" for n in names)
    last = names[-1]
    changed = ','.join(n for n in names[:-1] if r[n] != r[last])
    print(f"{r['probe']:<44} {marks}  last differs from: {changed or '-'}")
