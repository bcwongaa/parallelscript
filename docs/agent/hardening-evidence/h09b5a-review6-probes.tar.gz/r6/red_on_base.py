#!/usr/bin/env python3
"""For each of the slice's run and error tests, build it with the base CLI (and snap-f), and say
whether the test would pass there: a run test's stdout against its // expect: block, an error
test's // error: lines against the build's errors."""
import os, re, subprocess, sys, tempfile
T = "/tmp/h09b5/snap-f/pts/tests"
clis = {"base": ("/tmp/h09b5/base/pts-bin/pts", "/tmp/h09b5/base"), "snapf": ("/tmp/h09b5/snap-f-pts", "/tmp/h09b5/snap-f")}
names = sys.argv[1:]
for path in names:
    src = open(path).read()
    kind = "run" if "/run/" in path else "errors"
    expect = None
    if kind == "run":
        m = re.search(r"(?ms)^// expect:\n(.*)", src)
        expect = "".join(l[3:] + "\n" if l.startswith("// ") else "\n" for l in m.group(1).splitlines()) if m else None
    wants = re.findall(r"(?m)^// error: (.*)$", src)
    row = [os.path.basename(path)]
    for side, (cli, home) in clis.items():
        with tempfile.TemporaryDirectory() as d:
            out = os.path.join(d, "a.bin")
            try:
                b = subprocess.run([cli, "build", path, "-o", out], capture_output=True, text=True, env={**os.environ, "PTS_HOME": home}, timeout=600)
            except subprocess.TimeoutExpired:
                row.append(f"{side}=BUILD-TIMEOUT"); continue
            if kind == "run":
                if b.returncode != 0:
                    first = (re.findall(r"error (PTS\d+: .{0,70})", b.stderr) or ["?"])[0]
                    row.append(f"{side}=RED(build {b.returncode}: {first})"); continue
                r = subprocess.run([out], capture_output=True, text=True, timeout=60)
                ok = expect is None or r.stdout == expect
                row.append(f"{side}={'PASS' if ok else 'RED(output: ' + r.stdout.strip().replace(chr(10), '|')[:90] + ')'}")
            else:
                errs = b.stderr
                missing = [w for w in wants if w not in errs]
                if b.returncode == 3:
                    row.append(f"{side}=RED(PTS9001)")
                elif b.returncode == 0:
                    row.append(f"{side}=RED(compiled)")
                else:
                    row.append(f"{side}={'PASS' if not missing else 'RED(missing ' + missing[0][:80] + '; got ' + (re.findall(r'error (PTS\d+: .{0,60})', errs) or ['?'])[0] + ')'}")
    print("\t".join(row), flush=True)
