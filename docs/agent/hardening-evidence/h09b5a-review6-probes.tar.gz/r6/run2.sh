#!/bin/bash
# run2.sh file.pts: base and snap-f builds (wall, RSS, 6 GB limit, 600 s) + runs, and Node; one line.
f=$1; name=$(basename "$f" .pts); dir=/tmp/h09b5/review-a/r6/bin
res=()
for side in base snapf; do
  if [ $side = base ]; then cli=/tmp/h09b5/base/pts-bin/pts; home=/tmp/h09b5/base; else cli=/tmp/h09b5/snap-f-pts; home=/tmp/h09b5/snap-f; fi
  out=$dir/$name.$side.bin
  ( ulimit -v 6000000; PTS_HOME=$home /usr/bin/time -f "TIME %e %M" timeout 600 $cli build "$f" -o "$out" ) > $dir/$name.$side.build.txt 2>&1
  t=$(grep '^TIME' $dir/$name.$side.build.txt | tail -1 | awk '{printf "%ss/%dMB", $2, $3/1024}')
  if [ -f "$out" ]; then o=$(timeout 20 "$out" 2>&1 | tr '\n' '|' | cut -c1-160); rm -f "$out"; else o="ERR $(grep -m1 -o 'error PTS[0-9]*: .*' $dir/$name.$side.build.txt | cut -c1-110)"; fi
  res+=("$t" "$o")
done
cp "$f" $dir/$name.mts; n=$(timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts 2>&1 | tr '\n' '|' | cut -c1-160); rm -f $dir/$name.mts
s=DIFF; [ "${res[3]}" = "$n" ] && s=SAME
printf "%s\t%s\tbase %s [%s]\tsnapf %s [%s]\tnode [%s]\n" "$name" "$s" "${res[0]}" "${res[1]}" "${res[2]}" "${res[3]}" "$n"
