#!/bin/bash
# usage: run.sh probe.pts...  -> out/<name>/{node,base,snap3,snap4}.txt
# Node (.mts copy, --experimental-transform-types), base (/tmp/h09b4b/base), snap3 (fix commit
# 29e2aaeb9) and snap4 (round-1 changes). Set SKIP_BASE=1 / SKIP_SNAP3=1 to skip those CLIs.
export TZ=America/New_York
R=/tmp/h09b4b/s2/review2
cli() { # name home file dir
  (cd "$4" && PTS_HOME=$2 PTS_CACHE_DIR=$R/.cache-$1 timeout 300 $2/pts-bin/pts run "$3" > "$4/$1.txt" 2>&1; echo "exit=$?" >> "$4/$1.txt")
}
for f0 in "$@"; do
  f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n
  mkdir -p "$d"
  cp "$f" "$d/$n.mts"
  (cd "$d" && timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" > "$d/node.txt" 2>&1; echo "exit=$?" >> "$d/node.txt")
  [ -z "$SKIP_BASE" ] && cli base /tmp/h09b4b/base "$f" "$d"
  [ -z "$SKIP_SNAP3" ] && cli snap3 /tmp/h09b4b/s2/snap3 "$f" "$d"
  cli snap4 /tmp/h09b4b/s2/snap4 "$f" "$d"
  st() { [ -f "$d/$1.txt" ] && (cmp -s "$d/node.txt" "$d/$1.txt" && echo SAME || echo DIFF) || echo -; }
  echo "== $n: base=$(st base) snap3=$(st snap3) snap4=$(st snap4)"
  if [ "$(st snap4)" = DIFF ]; then diff "$d/node.txt" "$d/snap4.txt" | head -14; fi
done
