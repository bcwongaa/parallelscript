// Command emitwith prints, for each of lower.Fallbacks, whether the program lowers with that
// specialization alone (driver.EmitCWith), its errors, and the C's line count.
package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func main() {
	names := []string{"AllInstances", "ValueInstances", "DeclaredInstances"}
	for i, s := range lower.Fallbacks {
		c, err := driver.EmitCWith(context.Background(), os.Args[1], s)
		if err != nil {
			msg := err.Error()
			if len(msg) > 1500 {
				msg = msg[:1500] + "..."
			}
			fmt.Printf("%s: FAIL\n%s\n", names[i], msg)
			continue
		}
		fmt.Printf("%s: OK lines=%d instance_find=%v\n", names[i], strings.Count(c, "\n"), strings.Contains(c, "pts_method_instance_find") || strings.Contains(c, "instance_find"))
	}
}
