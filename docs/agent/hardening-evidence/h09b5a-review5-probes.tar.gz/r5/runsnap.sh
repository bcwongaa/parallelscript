#!/bin/bash
# runsnap.sh file.pts: snap-c build (wall, RSS) + run, compared with Node's output.
f=$1; name=$(basename "$f" .pts); dir=/tmp/h09b5/review-a/r5/bin; out=$dir/$name.snape2.bin
r=$( { PTS_HOME=/tmp/h09b5/snap-e /usr/bin/time -f "%es %MkB" timeout 600 /tmp/h09b5/snap-e-pts build "$f" -o "$out" > $dir/$name.snape2.build.txt 2>&1; } 2>&1 | tail -1 )
t=$(tail -1 $dir/$name.snape2.build.txt)
if [ -f "$out" ]; then o=$(timeout 20 "$out" 2>&1 | tr '\n' '|' | cut -c1-200); rm -f "$out"; else o="BUILD FAILED: $(grep -m1 'error PTS' $dir/$name.snape2.build.txt | sed 's/.* - error //' | cut -c1-120)"; fi
cp "$f" $dir/$name.mts; n=$(timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts 2>&1 | tr '\n' '|' | cut -c1-200); rm -f $dir/$name.mts
s=DIFF; [ "$o" = "$n" ] && s=SAME
printf "%-36s %-5s %-24s snap=[%s] node=[%s]\n" "$name" "$s" "$t" "$o" "$n"
