#!/bin/bash
# mut.sh <overlay-name>: the slice's Go, run and error tests under an overlay of snap-e.
m=$1; cd /tmp/h09b5/snap-e; ov=/tmp/h09b5/review-a/r5/overlay/$m.json; out=/tmp/h09b5/review-a/r5/mut_$m.txt
{
echo "### lower"
timeout 900 go test -overlay $ov -count=1 -run 'TestInstancesMadeSideBySideDontCountAgainstTheLimits|TestPolymorphicRecursionCountsTheInstancesItMakesPerRoot|TestPolymorphicRecursion' ./pts/lower/ 2>&1 | grep -E "^(--- |ok|FAIL|    )" | head -20
echo "### tests"
timeout 2400 go test -overlay $ov -count=1 -parallel 2 -v -run '^(TestRun|TestErrors)$/^(generic_polymorphic_recursion_.*|generic_instances_many_calls|generic_speculative_.*|generic_value_calls_many_class_instances|generic_class_instance_failure_value_calls|generics_not_yet)$' ./pts/tests/ 2>&1 | grep -E "^(--- FAIL|    --- FAIL|ok|FAIL)" | head -40
} > $out 2>&1
echo done > $out.done
