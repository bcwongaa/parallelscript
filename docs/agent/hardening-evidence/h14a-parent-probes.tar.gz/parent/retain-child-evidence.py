import hashlib
import json
import pathlib
import re
import shutil
import sys
import tarfile
import tempfile

source = pathlib.Path(sys.argv[1]).resolve()
expected = sys.argv[2]
destination = pathlib.Path(sys.argv[3]).resolve()
receipt = pathlib.Path(sys.argv[4]).resolve()
actual = hashlib.sha256(source.read_bytes()).hexdigest()
if actual != expected:
    raise RuntimeError("archive hash mismatch")
root = pathlib.Path(tempfile.mkdtemp(prefix="pts-h14a-inspected-"))
private_key = re.compile(rb"-----BEGIN (?:[A-Z ]*PRIVATE KEY)-----")
files = {}
with tarfile.open(source, "r:gz") as archive:
    for member in archive.getmembers():
        name = pathlib.PurePosixPath(member.name)
        if not member.isfile() or name.is_absolute() or ".." in name.parts or member.size > 64 * 1024 * 1024:
            raise RuntimeError("unsafe archive member: " + member.name)
        data = archive.extractfile(member).read()
        if private_key.search(data) or data.startswith(b"\x7fELF"):
            raise RuntimeError("private key or binary: " + member.name)
        if member.name in files:
            raise RuntimeError("duplicate archive member")
        files[member.name] = hashlib.sha256(data).hexdigest()
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
if destination.exists():
    raise RuntimeError("refusing to overwrite existing retained archive")
shutil.copyfile(source, destination)
result = dict(source=str(source), retained=str(destination), archive_sha256=actual, inspected_directory=str(root),
              files=files, regular_files_only=True, private_keys=0, elf_binaries=0)
receipt.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
