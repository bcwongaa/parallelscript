import collections
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

parent = pathlib.Path(sys.argv[1]).resolve()
base = pathlib.Path(sys.argv[2]).resolve()
out = parent / "pts-bin/h14a-parent"
selector = "^(TestHTTPServerPreDispatchDeadlines|TestHTTPSServerHandshakeDeadline|TestHTTPSServerStartsHeaderDeadlineAfterHandshake|TestHTTPServerDeadlineTimersLeaveDisconnectSignalsWorking|TestHTTPServerDeadlineOptionsRejectInvalidMilliseconds|TestHTTPServerExpiredConnectionsReleaseResources)"

def manifest(repo):
    names = subprocess.check_output(["git", "ls-files", "-co", "--exclude-standard"], cwd=repo).decode().splitlines()
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in sorted(set(names))
            if name.startswith(("pts/", "cmd/", "internal/")) and (repo / name).is_file()}

results = []
for label, repo, sanitize, expected in (("red-v2", base, False, 1), ("green-v2", parent, False, 0), ("sanitize-v2", parent, True, 0)):
    if len(sys.argv) > 3 and label not in sys.argv[3:]:
        continue
    before = manifest(repo)
    (out / (label + "-before.json")).write_text(json.dumps(before, indent=2) + "\n")
    env = dict(os.environ, GOMAXPROCS="1", PTS_REQUIRE_NODE="1")
    env.pop("PTS_BUILD_PROFILE", None)
    if sanitize:
        env.update(PTS_BUILD_PROFILE="sanitize", ASAN_OPTIONS="detect_leaks=0:detect_stack_use_after_return=0", UBSAN_OPTIONS="halt_on_error=1")
    command = ["go", "test", "-count=1", "-json", "-p", "1", "-parallel", "1", "-timeout", "10m", "./pts/tests", "-run", selector]
    started = time.time()
    print("starting " + label, flush=True)
    with (out / (label + ".jsonl")).open("wb") as stdout, (out / (label + ".stderr")).open("wb") as stderr:
        run = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=660)
    after = manifest(repo)
    (out / (label + "-after.json")).write_text(json.dumps(after, indent=2) + "\n")
    counts = collections.Counter()
    failures = []
    for line in (out / (label + ".jsonl")).read_text().splitlines():
        item = json.loads(line)
        if "Test" in item and item.get("Action") in ("pass", "fail", "skip"):
            counts[item["Action"]] += 1
            if item["Action"] == "fail":
                failures.append(item["Test"])
    changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    result = dict(label=label, repo=str(repo), command=command, exit=run.returncode, expected_exit=expected,
                  counts=dict(counts), failed_tests=failures, changed=changed, monitored_files=len(before),
                  elapsed_seconds=time.time()-started, stderr_bytes=(out / (label + ".stderr")).stat().st_size)
    (out / (label + "-summary.json")).write_text(json.dumps(result, indent=2) + "\n")
    results.append(result)
    print(json.dumps(result), flush=True)
    if run.returncode != expected or changed:
        sys.exit(1)
(out / "v2-summary.json").write_text(json.dumps(results, indent=2) + "\n")
