import collections
import hashlib
import json
import pathlib
import re
import sys
import tarfile

baseline = pathlib.Path(sys.argv[1]).resolve()
probes = pathlib.Path(sys.argv[2]).resolve()
final = pathlib.Path(sys.argv[3]).resolve()
destination = pathlib.Path(sys.argv[4]).resolve()
if destination.exists():
    raise RuntimeError("refusing to overwrite existing retained archive")
files = {}
for name, source in (("baseline", baseline), ("parent", probes), ("final", final)):
    for path in source.iterdir():
        if path.is_file() and not path.is_symlink() and path.suffix in (
            ".txt", ".stdout", ".stderr", ".jsonl", ".json", ".py", ".pts", ".patch", ".go", ".c"
        ):
            files[name + "/" + path.name] = path
private_key = re.compile(rb"-----BEGIN (?:[A-Z ]*PRIVATE KEY)-----")
manifest = {}
for name, path in files.items():
    data = path.read_bytes()
    if private_key.search(data):
        raise RuntimeError("private key material in " + name)
    if b"\x7fELF" == data[:4]:
        raise RuntimeError("binary in " + name)
    manifest[name] = hashlib.sha256(data).hexdigest()
with tarfile.open(destination, "w:gz") as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
manifest_path = destination.with_suffix(destination.suffix + ".json")
manifest_path.write_text(json.dumps({"files": manifest, "archive_sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2) + "\n")
print(len(files), "files", destination)
print("sha256", hashlib.sha256(destination.read_bytes()).hexdigest())
