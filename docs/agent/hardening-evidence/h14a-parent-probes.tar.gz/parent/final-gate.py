import collections
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time

repo = pathlib.Path(sys.argv[1]).resolve()
out = pathlib.Path(tempfile.mkdtemp(prefix="pts-h14a-final-"))
print("gate output: " + str(out), flush=True)
env = dict(os.environ, GOMAXPROCS="4", PTS_REQUIRE_NODE="1")

def manifest():
    names = subprocess.check_output(["git", "ls-files", "-co", "--exclude-standard"], cwd=repo).decode().splitlines()
    hashes = {}
    policy = ("go.mod", "go.sum", "Makefile", "README.md", "docs/GUIDE.md", "docs/SPEC.md", "docs/ARCHITECTURE.md", "docs/DECISIONS.md")
    for name in sorted(set(names)):
        path = repo / name
        if path.is_file() and (name.startswith(("pts/", "cmd/", "internal/")) or name in policy):
            hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    hashes["pts-bin/pts"] = hashlib.sha256((repo / "pts-bin/pts").read_bytes()).hexdigest()
    return hashes

commands = [["make", "build"], ["go", "test", "-count=1", "-json", "-p", "4", "-parallel", "4", "-timeout", "40m", "./pts/...", "./cmd/pts/"]]
started = time.time()
with (out / "build.stdout").open("wb") as stdout, (out / "build.stderr").open("wb") as stderr:
    build = subprocess.run(commands[0], cwd=repo, env=env, stdout=stdout, stderr=stderr)
if build.returncode:
    print("build failed: " + str(build.returncode), flush=True)
    sys.exit(build.returncode)
before = manifest()
(out / "before.json").write_text(json.dumps(before, indent=2) + "\n")
with (out / "suite.jsonl").open("wb") as stdout, (out / "suite.stderr").open("wb") as stderr:
    suite = subprocess.run(commands[1], cwd=repo, env=env, stdout=stdout, stderr=stderr)
after = manifest()
(out / "after.json").write_text(json.dumps(after, indent=2) + "\n")
counts = collections.Counter()
corpus = collections.Counter()
packages = {}
for line in (out / "suite.jsonl").read_text().splitlines():
    item = json.loads(line)
    action = item.get("Action")
    if action not in ("pass", "fail", "skip"):
        continue
    if "Test" in item:
        counts[action] += 1
        if item["Test"].startswith("TestCorpusMatchesNode/"):
            corpus[action] += 1
    else:
        packages[item["Package"]] = action
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
summary = dict(repo=str(repo), head=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).decode().strip(),
               commands=commands, build_exit=build.returncode, suite_exit=suite.returncode,
               counts=dict(counts), corpus=dict(corpus), packages=packages, monitored_files=len(before), changed=changed,
               stderr_bytes={name: (out / name).stat().st_size for name in ("build.stderr", "suite.stderr")},
               elapsed_seconds=time.time()-started)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2), flush=True)
print("gate output: " + str(out), flush=True)
sys.exit(suite.returncode or bool(changed))
