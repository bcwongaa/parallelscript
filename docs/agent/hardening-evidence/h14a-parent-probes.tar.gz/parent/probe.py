import os
import pathlib
import selectors
import signal
import socket
import subprocess
import sys
import time

exe = pathlib.Path(sys.argv[1]).resolve()
process = subprocess.Popen([str(exe)], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           env=dict(os.environ, PTS_THREADS="1"), start_new_session=True)
try:
    ready = selectors.DefaultSelector()
    ready.register(process.stdout, selectors.EVENT_READ)
    if not ready.select(5):
        raise RuntimeError("server did not announce port")
    port = int(process.stdout.readline())
    ready.close()
    with socket.create_connection(("127.0.0.1", port), timeout=2) as control:
        control.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
        response = b""
        while True:
            data = control.recv(4096)
            if not data:
                break
            response += data
        if not response.startswith(b"HTTP/1.1 200 ") or not response.endswith(b"\r\n\r\nok"):
            raise RuntimeError(f"valid control failed: {response!r}")
    print("valid HTTP control: PASS", flush=True)
    with socket.create_connection(("127.0.0.1", port), timeout=2) as incomplete:
        incomplete.settimeout(1.5)
        incomplete.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\n")
        start = time.monotonic()
        try:
            data = incomplete.recv(4096)
        except TimeoutError:
            print("incomplete headers: FAIL still open at finite 1.5s observation (policy 200ms)", flush=True)
            sys.exit(1)
        elapsed = time.monotonic() - start
        if data or elapsed < 0.1:
            raise RuntimeError(f"expected deadline EOF, got {data!r} after {elapsed:.3f}s")
        print(f"incomplete headers: PASS EOF after {elapsed:.3f}s, no response", flush=True)
finally:
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
    stdout, stderr = process.communicate(timeout=5)
    print("remaining stdout:", stdout.decode().strip(), flush=True)
    print("stderr:", stderr.decode().strip(), flush=True)
