#!/bin/bash
# Runs the proposed RED tests (copied into the worktree's pts/tests/run/) under TestRun and TestRunMatchesNode.
set -u
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660
OUT=${1:-/tmp/h06b/repro/newred}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 9
NAMES='parallel_views_skip_holes|array_callbacks_length_once|array_from_mapper_reads_holes|array_patterns_read_holes|set_of_array_holes|array_has_own_skips_holes|match_callbacks_wide_parameters|union_arrays_iteration_reads_holes|any_concat_match_groups|array_map_numbers_at_holes'
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -parallel 2 -timeout 40m -json \
  -run "^(TestRun|TestRunMatchesNode)\$/^(${NAMES})\$" ./pts/tests/ > "$OUT.jsonl" 2> "$OUT.stderr"
echo "exit $?" > "$OUT.exit"
