#!/usr/bin/env python3
"""Run each probe under Node (strict-ESM .mts copy, or <stem>.oracle.mts beside it, a
sequential twin) and under pts (built once, run per `// threads:` value), and print the
outputs paired line by line: '=' same, '-' node, '+' pts. Exit 1 if any differs.

Usage: pair.py [--json out.json] probe.pts...
"""
import argparse
import json
import os
import re
import resource
import shutil
import subprocess
import sys
from pathlib import Path

WT = Path("/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660")
PTS = WT / "pts-bin" / "pts"
NODE = Path.home() / ".local/node/bin/node"
SCRATCH = Path("/tmp/h06b/repro/work")
CAP = 4 << 30


def env(extra=None):
    e = dict(os.environ)
    e["PTS_HOME"] = str(WT)
    e["PATH"] = f"{Path.home()}/.local/node/bin:{Path.home()}/.local/go/bin:" + e.get("PATH", "")
    e["TZ"] = "America/New_York"
    if extra:
        e.update(extra)
    return e


def capped():
    resource.setrlimit(resource.RLIMIT_AS, (CAP, CAP))


def run(cmd, timeout, cwd, extra=None, cap=False):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env(extra), capture_output=True, timeout=timeout,
                           preexec_fn=capped if cap else None)
        return p.returncode, p.stdout.decode("utf8", "replace"), p.stderr.decode("utf8", "replace")
    except subprocess.TimeoutExpired:
        return "timeout", "", ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json")
    ap.add_argument("probes", nargs="+")
    a = ap.parse_args()
    results, worst = [], 0
    for p in a.probes:
        path = Path(p).resolve()
        src = path.read_text()
        work = SCRATCH / path.stem
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True)
        oracle = path.with_name(path.stem + ".oracle.mts")
        mts = work / (path.stem + ".mts")
        shutil.copy(oracle if oracle.exists() else path, mts)
        nexit, nout, nerr = run([str(NODE), "--no-warnings", "--experimental-transform-types", str(mts)], 60, work)
        binary = work / (path.stem + "-native")
        bexit, bout, berr = run([str(PTS), "build", str(path), "-o", str(binary)], 900, work)
        r = {"probe": str(path), "oracle": str(oracle) if oracle.exists() else None, "node_exit": nexit,
             "node_out": nout, "node_err": nerr[-1500:], "build_exit": bexit, "build_err": (bout + berr)[-3000:], "runs": []}
        tag = f" (oracle {oracle.name})" if oracle.exists() else ""
        print(f"=== {path.name}  node exit {nexit}{tag}  build exit {bexit}")
        if nerr.strip():
            print("  node stderr:", " / ".join(nerr.strip().splitlines()[-3:]))
        if bexit != 0:
            print("  build:", "\n  ".join((bout + berr).strip().splitlines()[:10]))
            r["class"] = "DIAG"
            worst = 1
            results.append(r)
            continue
        m = re.search(r"^// threads: (.*)$", src, re.M)
        counts = m.group(1).split() if m else [None]
        classes = []
        for t in counts:
            rexit, rout, rerr = run([str(binary)], 60, work, {"PTS_THREADS": t} if t else None, cap=True)
            same = rexit == nexit and rout == nout
            classes.append("OK" if same else "WRONG")
            r["runs"].append({"threads": t, "exit": rexit, "out": rout, "err": rerr[-1500:]})
            print(f"  -- pts threads={t} exit={rexit} {'SAME' if same else 'DIFF'}")
            nl, pl = nout.splitlines(), rout.splitlines()
            for i in range(max(len(nl), len(pl))):
                x = nl[i] if i < len(nl) else "<none>"
                y = pl[i] if i < len(pl) else "<none>"
                if x == y:
                    print("   =", x)
                else:
                    print("   - node:", x)
                    print("   + pts :", y)
            if rerr.strip():
                print("     pts stderr:", " / ".join(rerr.strip().splitlines()[:3]))
        r["class"] = "OK" if all(c == "OK" for c in classes) else "WRONG"
        if r["class"] != "OK":
            worst = 1
        results.append(r)
    if a.json:
        Path(a.json).write_text(json.dumps(results, indent=1))
    sys.exit(worst)


if __name__ == "__main__":
    main()
