#!/usr/bin/env python3
"""Run h06-probes/families.py (which imports classify and gen from its own directory)
under `python3 -I`: puts that directory on sys.path explicitly, then runs it.

Usage: families_run.py <h06-probes dir> results.json...
"""
import runpy
import sys

probes = sys.argv[1]
sys.path.insert(0, probes)
sys.argv = [probes + "/families.py"] + sys.argv[2:]
runpy.run_path(probes + "/families.py", run_name="__main__")
