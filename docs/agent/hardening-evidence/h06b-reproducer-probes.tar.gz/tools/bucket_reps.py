#!/usr/bin/env python3
"""Count the matrix's by-design cases of given buckets for given reps, by method.

Usage: bucket_reps.py <h06-probes dir> results.json BUCKET[,BUCKET] rep[,rep]
"""
import json
import sys
from collections import Counter

sys.path.insert(0, sys.argv[1])
import classify  # noqa: E402

buckets = set(sys.argv[3].split(","))
reps = set(sys.argv[4].split(","))
count = Counter()
for p in json.load(open(sys.argv[2]))["programs"]:
    rep, mode, group = p["name"].rsplit("-", 2)
    if rep not in reps:
        continue
    for label, c in p["cases"].items():
        if c["class"] == "OK":
            continue
        content, method = label.split(".", 1)
        bucket, _ = classify.classify(rep, mode, group, content, method, c)
        if bucket in buckets:
            count[(bucket, rep, mode, method)] += 1
for k, v in sorted(count.items()):
    print(*k, v)
print("total", sum(count.values()))
