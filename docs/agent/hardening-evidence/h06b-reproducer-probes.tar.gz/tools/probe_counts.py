#!/usr/bin/env python3
"""Per probe: lines equal to Node's and lines that differ (first run), and whether all
thread counts printed the same.

Usage: probe_counts.py probes-all.json
"""
import json
import sys
from pathlib import Path

for r in json.load(open(sys.argv[1])):
    name = Path(r["probe"]).name
    if r.get("class") == "DIAG":
        print(f"{name}: DIAG (build exit {r['build_exit']})")
        continue
    node = r["node_out"].splitlines()
    first = r["runs"][0]["out"].splitlines()
    same = sum(1 for a, b in zip(node, first) if a == b)
    differ = max(len(node), len(first)) - same
    threads = "same at all thread counts" if len({x["out"] for x in r["runs"]}) == 1 else "DIFFERS BY THREADS"
    exits = sorted({str(x["exit"]) for x in r["runs"]})
    print(f"{name}: {same} lines match Node, {differ} differ; exits {','.join(exits)}; {threads if len(r['runs']) > 1 else ''}")
