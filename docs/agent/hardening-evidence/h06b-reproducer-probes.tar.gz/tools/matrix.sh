#!/bin/bash
# Re-runs H06's generated matrix on this worktree's CLI and runtime.
# Usage: matrix.sh <jobs> <out.json>
set -u
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660
JOBS=${1:-2}
OUT=${2:-/tmp/h06b/repro/matrix-base.json}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd /tmp/h06b/repro || exit 9
python3 -I "$WT/h06-probes/run_matrix.py" --dir /tmp/h06b/repro/matrix --out "$OUT" \
  --scratch /tmp/h06b/repro/matrix-work --jobs "$JOBS" > "${OUT%.json}.log" 2>&1
echo "run_matrix exit: $?" >> "${OUT%.json}.log"
