#!/bin/bash
# Compiler smoke test (no ICE, panic or hang) over the proposed tests and one mutant each.
set -u
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 9
NAMES='parallel_views_skip_holes|array_callbacks_length_once|array_from_mapper_reads_holes|array_patterns_read_holes|set_of_array_holes|array_has_own_skips_holes|match_callbacks_wide_parameters|union_arrays_iteration_reads_holes|any_concat_match_groups|array_map_numbers_at_holes'
PTS_SMOKE_FILTER="run/(${NAMES})\.pts" PTS_SMOKE_JOBS=2 GOMAXPROCS=2 go test -count=1 -v ./pts/tests/ -run '^TestCompilerFailsCleanly$' > /tmp/h06b/repro/smoke.txt 2>&1
echo "exit $?" >> /tmp/h06b/repro/smoke.txt
