#!/usr/bin/env python3
"""Break the matrix's DEFECT families down by method and by rep/mode, and compare two
runs (e.g. H06's final run and this base) case by case.

Usage: breakdown.py <h06-probes dir> new.json [old.json[.gz]]
"""
import gzip
import json
import re
import sys
from collections import Counter, defaultdict

probes = sys.argv[1]
sys.path.insert(0, probes)
import classify  # noqa: E402


def load(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt") as f:
        return {p["name"]: p for p in json.load(f)["programs"]}


def label_of(name, label, c):
    rep, mode, group = name.rsplit("-", 2)
    content, method = label.split(".", 1)
    if c["class"] == "OK":
        return rep, mode, group, content, method, "OK", "OK"
    bucket, _ = classify.classify(rep, mode, group, content, method, c)
    fam = classify.family(rep, mode, group, content, method, c) if bucket == "DEFECT" else bucket
    return rep, mode, group, content, method, bucket, fam


def table(progs):
    rows = {}
    for name, p in progs.items():
        for label, c in p["cases"].items():
            rows[(name, label)] = label_of(name, label, c) + (c,)
    return rows


new = table(load(sys.argv[2]))
fam_method = defaultdict(Counter)
fam_rep = defaultdict(Counter)
for (name, label), (rep, mode, group, content, method, bucket, fam, c) in new.items():
    if bucket == "OK":
        continue
    fam_method[fam][method] += 1
    fam_rep[fam][f"{rep}/{mode}"] += 1
for fam in sorted(fam_method):
    print(f"{fam}: {sum(fam_method[fam].values())}")
    print("   by method:", dict(sorted(fam_method[fam].items())))
    print("   by rep/mode:", dict(sorted(fam_rep[fam].items())))

if len(sys.argv) > 3:
    old = table(load(sys.argv[3]))
    moves = Counter()
    for key, row in old.items():
        n = new.get(key)
        if n is None:
            moves[(row[6], "MISSING")] += 1
            continue
        moves[(row[6], n[6])] += 1
    print("\nold family -> new family (cases):")
    for (a, b), k in sorted(moves.items()):
        if a != b:
            print(f"   {a} -> {b}: {k}")
    print("unchanged non-OK:", sum(k for (a, b), k in moves.items() if a == b and a != "OK"))

# Sort residue: is it UNREPR once console.log's line wrapping is ignored?
ws = re.compile(r"\s+")
print("\nsort-family residue with whitespace collapsed (UNREPR test):")
for (name, label), (rep, mode, group, content, method, bucket, fam, c) in sorted(new.items()):
    if fam in ("F1", "F2", "F3", "F1+F3", "F2+F3"):
        pts = ws.sub(" ", classify.render_holes_as_undefined(c.get("pts") or ""))
        node = ws.sub(" ", classify.normalize_node(c.get("node") or ""))
        print(f"   {name} {label}: same-as-UNREPR={pts == node}")
