#!/usr/bin/env python3
"""Check that a threaded test's subtests (threads=1/2/4) failed with the same diff.

Usage: threads_same.py diffs.txt test-name
"""
import re
import sys

text = open(sys.argv[1]).read()
name = sys.argv[2]
bodies = {}
for m in re.finditer(r"##### TestRun/%s/threads=(\d+) \(fail\)\n(.*?)--- FAIL" % re.escape(name), text, re.S):
    body = "\n".join(l for l in m.group(2).splitlines() if not l.startswith("=== "))
    bodies[m.group(1)] = body
print({k: len(v) for k, v in bodies.items()})
print("identical:", len(set(bodies.values())) == 1)
