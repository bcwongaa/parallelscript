#!/usr/bin/env python3
"""Summarize a `go test -json` stream: the final action of every test, counts, and the
output of each failing subtest written to <out>.

Usage: jsonl_summary.py events.jsonl out.txt
"""
import json
import sys
from collections import Counter

final, out = {}, {}
for line in open(sys.argv[1]):
    e = json.loads(line)
    t = e.get("Test")
    if not t:
        continue
    if e.get("Action") in ("pass", "fail", "skip"):
        final[t] = e["Action"]
    elif e.get("Action") == "output":
        out.setdefault(t, []).append(e["Output"])
for t in sorted(final):
    print(final[t], t)
print(Counter(final.values()))
with open(sys.argv[2], "w") as f:
    for t in sorted(out):
        if final.get(t) in ("fail", "skip") and "/" in t:
            f.write("##### " + t + " (" + final[t] + ")\n" + "".join(out[t]) + "\n")
