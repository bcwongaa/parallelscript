#!/bin/bash
# Appends Node's stdout as the expect block of each plain-TypeScript proposed RED test.
set -u
MK=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660/h06-probes/mkexpect.py
cd /tmp/h06b/repro/red-tests || exit 9
for t in array_callbacks_length_once array_from_mapper_reads_holes array_patterns_read_holes set_of_array_holes \
         array_has_own_skips_holes match_callbacks_wide_parameters union_arrays_iteration_reads_holes any_concat_match_groups; do
  echo "## $t"
  python3 -I "$MK" --write "/tmp/h06b/repro/red-tests/$t.pts"
  echo "exit $?"
done
