#!/bin/bash
# Re-runs every probe (pts vs Node or its sequential twin) into one transcript and one JSON.
set -u
cd /tmp/h06b/repro/probes || exit 9
python3 -I /tmp/h06b/repro/tools/pair.py --json /tmp/h06b/repro/results/probes-all.json \
  par_small.pts par_big.pts par_match.pts mutate.pts any_grow.pts edges.pts keys_match.pts \
  any_iter.pts concat.pts adjacent.pts destructure.pts destructure_match.pts set_holes.pts \
  match_callbacks.pts union_nulls.pts assign_diag.pts spread_object_diag.pts adjacent_diag.pts \
  destructure_diag.pts > /tmp/h06b/repro/results/probes-all.txt 2>&1
echo "pair.py exit $?" >> /tmp/h06b/repro/results/probes-all.txt
