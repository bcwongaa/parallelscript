#!/usr/bin/env python3
"""Print the non-OK matrix cases of the given programs whose method matches.

Usage: show_cases.py results.json method program...
"""
import json
import sys

results, method, names = sys.argv[1], sys.argv[2], sys.argv[3:]
progs = {p["name"]: p for p in json.load(open(results))["programs"]}
for n in names:
    for label, c in progs[n]["cases"].items():
        if label.split(".", 1)[1] == method and c["class"] != "OK":
            print(n, label, c["class"])
            print("  node:", c.get("node"))
            print("  pts :", c.get("pts"), "|", (c.get("pts_msg") or "")[:100])
