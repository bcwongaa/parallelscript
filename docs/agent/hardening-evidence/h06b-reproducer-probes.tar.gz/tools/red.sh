#!/bin/bash
# Runs H06b's 9 RED tests (skip lines removed in the worktree) under TestRun and TestRunMatchesNode.
# Usage: red.sh <out-prefix>
set -u
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae746c1dbf6eb5660
OUT=${1:-/tmp/h06b/repro/red}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 9
NAMES='array_callbacks_skip_holes|any_array_callbacks_skip_holes|array_find_holes|array_search_undefined_holes|array_keys_skip_holes|array_in_skips_holes|array_iteration_reads_holes|any_concat_keeps_holes|match_spreads_keep_undefined'
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -parallel 2 -timeout 40m -json \
  -run "^(TestRun|TestRunMatchesNode)\$/^(${NAMES})\$" ./pts/tests/ > "$OUT.jsonl" 2> "$OUT.stderr"
echo "exit $?" > "$OUT.exit"
