// .par views over small arrays with holes (one piece), compared with the sequential
// method's Node result (par_small.oracle.mts: `.par.X` as `.X`, count as filter().length,
// sum/min/max as a reduce over the elements). forEach marks each visited index in its own
// slot of a pre-sized array (distinct indices, so no race).
// threads: 1 2 4
class P {
  constructor(public x: number) {}
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 60));
  }
}
function strings(): string[] {
  const a = new Array<string>(4);
  a[1] = "b";
  a[3] = "d";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(4);
  a[0] = "a";
  a[2] = undefined;
  return a;
}
function mixed(): any[] {
  const a: any[] = new Array(3);
  a[0] = 1;
  a[2] = "z";
  return a;
}
function numStrings(): string[] {
  const a = new Array<string>(4);
  a[1] = "2";
  a[3] = "5";
  return a;
}
function marks(n: number): number[] {
  return new Array<number>(n).fill(0);
}
show("strings map", () => strings().map((x) => x + "!"));
show("strings forEach", () => {
  const m = marks(4);
  strings().forEach((x, i) => {
    m[i] = 1;
  });
  return m;
});
show("strings filter", () => strings().filter((x) => x !== "zz"));
show("strings some", () => strings().some((x) => x === undefined));
show("strings every", () => strings().every((x) => typeof x === "string"));
show("strings find", () => strings().find((x) => x === "d"));
show("strings reduce", () => strings().reduce((a, b) => a + b, ""));
show("strings count", () => strings().filter(() => true).length);
show("numStrings sum", () => numStrings().reduce((s, x) => s + Number(x), 0));
show("numStrings min", () => numStrings().reduce((s, x) => Math.min(s, Number(x)), Infinity));
show("numStrings max", () => numStrings().reduce((s, x) => Math.max(s, Number(x)), -Infinity));
show("points map", () => points().map((p) => p.x));
show("points filter", () => points().filter((p) => p.x > 0));
show("points every", () => points().every((p) => p.x === 1));
show("points count", () => points().filter((p) => p.x === 1).length);
show("maybe map", () => maybe().map((x) => String(x)));
show("maybe forEach", () => {
  const m = marks(4);
  maybe().forEach((x, i) => {
    m[i] = 1;
  });
  return m;
});
show("maybe filter", () => maybe().filter(() => true));
show("maybe some", () => maybe().some((x) => x === undefined));
show("maybe every", () => maybe().every((x) => x !== undefined));
show("maybe count", () => maybe().filter((x) => x === undefined).length);
show("maybe reduce", () => maybe().reduce((a, b) => String(a) + String(b), ""));
show("any map", () => mixed().map((x) => typeof x));
show("any filter", () => mixed().filter(() => true));
show("any count", () => mixed().filter(() => true).length);
show("any sum", () => mixed().reduce((s, x) => s + Number(x), 0));
show("holes only every", () => new Array<string>(3).every(() => false));
show("holes only some", () => new Array<string>(3).some(() => true));
show("holes only map", () => new Array<string>(2).map((x) => x + "!"));
