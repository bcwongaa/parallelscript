// .par views over 6000-slot arrays (several pieces) whose every third slot is a hole,
// against the sequential method's Node result (par_big.oracle.mts). Results are printed as
// summaries: lengths, present-element counts through `any` filter (which skips holes in
// pts already), and the first slots.
// threads: 1 2 4
class P {
  constructor(public x: number) {}
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
const N = 6000;
function strings(): string[] {
  const a = new Array<string>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = String(i % 10);
    }
  }
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = i % 7 === 0 ? undefined : String(i % 10);
    }
  }
  return a;
}
function points(): P[] {
  const a = new Array<P>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = new P(i);
    }
  }
  return a;
}
function present(a: any): number {
  return a.filter(() => true).length;
}
function summary(a: any): unknown[] {
  return [a.length, present(a), a.slice(0, 4)];
}
function marked(f: (m: number[]) => void): number {
  const m = new Array<number>(N).fill(0);
  f(m);
  let s = 0;
  for (let i = 0; i < N; i++) {
    s += m[i];
  }
  return s;
}
show("strings map", () => summary(strings().map((x) => x + "!")));
show("strings forEach", () => marked((m) => strings().forEach((x, i) => { m[i] = 1; })));
show("strings filter", () => summary(strings().filter((x) => x !== "3")));
show("strings some", () => strings().some((x) => x === undefined));
show("strings every", () => strings().every((x) => typeof x === "string"));
show("strings count", () => strings().filter((x) => x === "0").length);
show("strings reduce", () => strings().reduce((a, b) => a + b, "").length);
show("strings sum", () => strings().reduce((s, x) => s + Number(x), 0));
show("strings min max", () => [strings().reduce((s, x) => Math.min(s, Number(x)), Infinity), strings().reduce((s, x) => Math.max(s, Number(x)), -Infinity)]);
show("maybe map", () => summary(maybe().map((x) => String(x))));
show("maybe forEach", () => marked((m) => maybe().forEach((x, i) => { m[i] = 1; })));
show("maybe filter", () => summary(maybe().filter((x) => x !== "3")));
show("maybe count", () => maybe().filter((x) => x === undefined).length);
show("maybe every", () => maybe().every((x) => x === undefined || x.length === 1));
show("maybe reduce", () => String(maybe().reduce((a, b) => String(a) + String(b), "")).length);
show("points map", () => summary(points().map((p) => "p" + p.x)));
show("points filter", () => summary(points().filter((p) => p.x % 2 === 0)));
show("points count", () => points().filter((p) => p.x >= 0).length);
show("points every", () => points().every((p) => p.x >= 0));
show("points find", () => points().find((p) => p.x === 5999));
show("points sum", () => points().map((p) => p.x).reduce((s, x) => s + Number(x), 0));
