// .par views over a match array whose group took no part (an undefined element, D-133),
// with callbacks whose parameter takes undefined, against the sequential methods
// (par_match.oracle.mts). Through Array's own methods the typed versions throw too
// (match_callbacks.pts); this shows the library path.
// threads: 1 2 4
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
const m = /(a)|(b)/.exec("xb")!;
show("par map", () => m.map((x: string | undefined) => x ?? "u"));
show("par filter", () => m.filter((x: string | undefined) => x !== "b"));
show("par count", () => m.filter((x: string | undefined) => x === undefined).length);
show("par some", () => m.some((x: string | undefined) => x === undefined));
show("par toArray", () => m.slice());
