package driver_test

import (
	"bufio"
	"context"
	"fmt"
	"os"
	"strings"
	"sync"
	"testing"


	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

// A throwaway scan (H09b5b parent): for each file in POOL_LIST, the first fallback that
// lowers it plainly (the base's driver) and the first that lowers it narrowed (this one).
func TestPoolScan(t *testing.T) {
	list, err := os.ReadFile(os.Getenv("POOL_LIST"))
	if err != nil {
		t.Fatal(err)
	}
	files := strings.Fields(string(list))
	out, _ := os.Create(os.Getenv("POOL_OUT"))
	defer out.Close()
	w := bufio.NewWriter(out)
	defer w.Flush()
	var mu sync.Mutex
	jobs := make(chan string)
	var wg sync.WaitGroup
	names := []string{"ALL", "VALUE", "DECLARED"}
	for range 2 {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for f := range jobs {
				ctx, cancel := context.WithCancel(context.Background())
				plain, narrowed := "NONE", "NONE"
				for i, s := range lower.Fallbacks {
					if plain == "NONE" {
						if _, err := driver.EmitCWith(ctx, f, s); err == nil {
							plain = names[i]
						}
					}
					if narrowed == "NONE" {
						if _, err := driver.EmitCNarrowedWith(ctx, f, s); err == nil {
							narrowed = names[i]
							if _, err := driver.EmitCWith(ctx, f, s); err != nil {
								narrowed += "-NARROWED"
							}
						}
					}
				}
				if ctx.Err() != nil {
					plain, narrowed = "HANG", "HANG"
				}
				cancel()
				mu.Lock()
				fmt.Fprintf(w, "%s\t%s\t%s\n", plain, narrowed, f)
				w.Flush()
				mu.Unlock()
			}
		}()
	}
	for _, f := range files {
		jobs <- f
	}
	close(jobs)
	wg.Wait()
}
