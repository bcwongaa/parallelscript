#!/bin/bash
# probes.sh OUTDIR CLI HOME FILE...: runs each probe with the CLI, compares with Node (cached in OUTDIR/<name>.node).
out=$1; cli=$2; home=$3; shift 3
for f in "$@"; do
  n=$(basename $f .pts)
  if [ ! -s $out/$n.node ]; then d=$(mktemp -d); cp $f $d/$n.mts; (cd $d && timeout 120 ~/.local/node/bin/node --no-warnings --experimental-transform-types $n.mts > $out/$n.node 2>/dev/null; echo "exit=$?" >> $out/$n.node); rm -rf $d; fi
  s=$(date +%s.%N); bin=$(mktemp -u /tmp/h09b5b/bin.XXXX)
  PTS_HOME=$home timeout 600 $cli build $f -o $bin > $out/$n.build 2>&1; b=$?
  if [ $b -eq 0 ]; then timeout 120 $bin > $out/$n.out 2>/dev/null; echo "exit=$?" >> $out/$n.out; rm -f $bin; else cp $out/$n.build $out/$n.out; fi
  e=$(date +%s.%N)
  if cmp -s $out/$n.out $out/$n.node; then r=OK; else r=DIFF; fi
  printf "%-40s %s %.1fs\n" $n $r $(echo "$e - $s" | bc)
done
