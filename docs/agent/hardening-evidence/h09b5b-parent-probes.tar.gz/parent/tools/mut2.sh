#!/bin/bash
cd /home/bryan/projects/parallelscript
M=/tmp/h09b5b/parent/mut2
for j in $M/w*.json; do m=$(basename $j .json)
  GOMAXPROCS=2 PTS_REQUIRE_NODE=1 PATH=$HOME/.local/node/bin:$PATH go test -overlay $j -count=1 -p 2 -parallel 2 -timeout 20m -run 'TestRun/generic_fallback|TestRunMatchesNode/generic_fallback|TestRun/generic_instances_fall_back|TestErrors/generic_fallback|TestErrors/generic_polymorphic|Narrow|EmitC|Fall|Failing|Failure|ABuild|AValue|Interface' ./pts/tests/ ./pts/driver/ > $M/$m.log 2>&1
  echo "$m: $(grep -cE -- '^    --- FAIL|^--- FAIL: Test[A-Z][a-zA-Z]*Build|^--- FAIL: TestA|^--- FAIL: TestEmit|^--- FAIL: TestInterface' $M/$m.log) failing; $(grep -c 'build failed' $M/$m.log) build-failed; $(grep -oE -- '--- FAIL: [^ ]+' $M/$m.log | grep -v 'FAIL: TestRun \|FAIL: TestRunMatchesNode \|FAIL: TestErrors ' | head -3 | tr '\n' ' ')"
done
echo DONE
