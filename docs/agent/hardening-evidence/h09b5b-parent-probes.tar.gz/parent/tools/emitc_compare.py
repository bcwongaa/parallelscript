#!/usr/bin/env python3
"""emit-c of every test, corpus, docs and stress program with two CLIs; prints the programs whose
C or exit differ. usage: emitc_compare.py BASE_CLI BASE_HOME FIX_CLI FIX_HOME OUT_DIR"""
import concurrent.futures, glob, os, subprocess, sys
base, base_home, fix, fix_home, out = sys.argv[1:6]
R = '/home/bryan/projects/parallelscript/pts'
files = sorted(set(glob.glob(R + '/tests/run/*.pts') + glob.glob(R + '/tests/errors/*.pts') + glob.glob(R + '/tests/corpus/*/*.pts')
                   + glob.glob('/home/bryan/projects/parallelscript/docs/examples/*.pts') + glob.glob(R + '/tests/stress/*.pts')))
os.makedirs(out, exist_ok=True)
def emit(cli, home, f):
    p = subprocess.run([cli, 'emit-c', f], capture_output=True, text=True, env=dict(os.environ, PTS_HOME=home), timeout=600)
    return p.returncode, p.stdout, p.stderr
def one(f):
    b, x = emit(base, base_home, f), emit(fix, fix_home, f)
    return f, b, x
diff = []
with concurrent.futures.ThreadPoolExecutor(2) as ex:
    for f, b, x in ex.map(one, files):
        if b[0] != x[0] or b[1] != x[1] or (b[0] != 0 and b[2] != x[2]):
            diff.append(f)
            name = f.replace('/', '_')
            open(os.path.join(out, name + '.base'), 'w').write('exit=%d\n%s\n---stderr\n%s' % b)
            open(os.path.join(out, name + '.fix'), 'w').write('exit=%d\n%s\n---stderr\n%s' % x)
print('programs', len(files), 'differing', len(diff))
for f in diff:
    print(f)
