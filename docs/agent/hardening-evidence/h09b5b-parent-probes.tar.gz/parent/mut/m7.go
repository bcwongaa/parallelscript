package lower

import (
	"slices"

	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/pts/diagnostic"
	"github.com/microsoft/typescript-go/pts/ir"
)

// A build's lowering may fail in code that only its speculative instances make, in ways a
// trial can't take back (D-190): a generic class instance a trial made, whose body is
// lowered later; a relaxed cast in a kept instance, checked after lowering; a call whose
// demand doesn't lower at its own site, or whose result doesn't fit where it goes. The
// driver then lowers the program again leaving out only what the failures came from (C176,
// D-199): each report is blamed on the pairing of a demand with an erased value or generic
// method whose trial made the code that reported, or on the call site whose demand reported
// or made what the statement reporting uses, where the last fallback (DeclaredInstances)
// doesn't make that pairing or demand. A report of the program's own code, or of a pairing
// every fallback makes, stands, as before.

// pairing is a demand's call (and for a demand by name, its name) paired with an erased
// value or generic method, by declaration; or a call site (site) whose demand the last
// fallback doesn't make, with nothing.
type pairing struct {
	call  *ast.Node
	name  string
	value *ast.Node
	site  siteKind
}

// siteKind is what a call site that a narrower lowering lowers as the last fallback does
// lowers otherwise: none for a pairing.
type siteKind int

const (
	notASite        siteKind = iota
	byNameSite               // a demand by name (keyedInstanceCall, D-191, D-194)
	constantKeySite          // a constant key's call lowered as its dotted call (constantKeyCall, C185)
	demandSite               // a value's or dispatched method's demand with a rest parameter or a dynamic result (siteDemandAt)
)

// Narrowing is what a lowering leaves out of the instances it would make: the pairings
// whose trials specialize skips, and the call sites that make no demand, lowering as the
// last fallback that doesn't make it does. The zero Narrowing leaves out nothing.
type Narrowing struct {
	pairings map[pairing]bool
}

// Len is how many pairings and call sites n leaves out.
func (n *Narrowing) Len() int {
	if n == nil {
		return 0
	}
	return len(n.pairings)
}

func (n *Narrowing) leavesOut(p pairing) bool {
	return n != nil && n.pairings[p]
}

// with is n and the pairings more.
func (n *Narrowing) with(more []pairing) *Narrowing {
	next := &Narrowing{pairings: map[pairing]bool{}}
	if n != nil {
		for p := range n.pairings {
			next.pairings[p] = true
		}
	}
	for _, p := range more {
		next.pairings[p] = true
	}
	return next
}

// blame is what a diagnostic's reports, or a cast's sources, are blamed on: the pairings
// or call sites a narrower lowering leaves out, unless one of them was of code that is the
// program's own, or that every fallback makes (own).
type blame struct {
	own      bool
	pairings []pairing
}

// add merges into b what one report is blamed on (blameHere): the program's own code if
// pairings is nil.
func (b blame) add(pairings []pairing) blame {
	if pairings == nil {
		b.own = true
		return b
	}
	return b.with(pairings)
}

// with is b blamed on pairings too.
func (b blame) with(pairings []pairing) blame {
	for _, p := range pairings {
		if !slices.Contains(b.pairings, p) {
			b.pairings = append(slices.Clip(b.pairings), p)
		}
	}
	return b
}

// reported is what lowering has reported so far, which code taken back restores: report
// only appends to errors and blames, and copies blames before it changes one.
type reported struct {
	errors           []diagnostic.Diagnostic
	blames           []blame
	reports          int
	unexplained      *ast.Node
	unexplainedBlame []pairing
}

func (l *lowerer) reportedSoFar() reported {
	return reported{errors: l.errors, blames: l.blames, reports: l.reports, unexplained: l.unexplained, unexplainedBlame: l.unexplainedBlame}
}

func (l *lowerer) restoreReported(r reported) {
	l.errors, l.blames, l.reports, l.unexplained, l.unexplainedBlame = r.errors, r.blames, r.reports, r.unexplained, r.unexplainedBlame
}

// blameHere is what a report of the code being lowered is blamed on, or nil if it stands:
// the call site whose demand is being lowered (site); or else the innermost pairing that a
// narrower lowering leaves out whose trial made the code: the trial being run, or one that
// made the instance being lowered, or one the instance was made in; or else the call sites
// whose demands made what the statement being lowered uses (statementSites).
func (l *lowerer) blameHere() []pairing {
	if l.site != nil {
		return []pairing{*l.site}
	}
	if t := l.trial; t != nil && t.narrowable {
		return []pairing{t.pairing}
	}
	for s := l.subst; s != nil; s = s.made {
		if t := s.trial; t != nil && t.narrowable {
			return []pairing{t.pairing}
		}
	}
	return slices.Clone(l.statementSites)
}

// blameReport records what a report of d, at index i of errors (a new one if i is
// len(errors)), is blamed on: pairings, or the program's own code if they are nil.
func (l *lowerer) blameReport(i int, pairings []pairing) {
	if i == len(l.blames) {
		l.blames = append(l.blames, blame{})
	} else {
		l.blames = slices.Clone(l.blames) // saved reported values keep theirs
	}
	l.blames[i] = l.blames[i].add(pairings)
}

// narrower is the narrowing that leaves out what the errors are blamed on, besides what
// l.narrowing leaves out, if every error is blamed on something it doesn't leave out yet;
// else nil.
func (l *lowerer) narrower() *Narrowing {
	if len(l.errors) == 0 {
		return nil
	}
	var more []pairing
	for _, b := range l.blames {
		if b.own || len(b.pairings) == 0 {
			return nil
		}
		for _, p := range b.pairings {
			if l.narrowing.leavesOut(p) {
				return nil // left out already: it can't be what failed
			}
			if !slices.Contains(more, p) {
				more = append(more, p)
			}
		}
	}
	return l.narrowing.with(more)
}

// blamingSite blames the reports of what is lowered next, the part of the call at node that
// only its demand lowers (kind), on the call site, until restore.
func (l *lowerer) blamingSite(node *ast.Node, kind siteKind) (restore func()) {
	outer := l.site
	l.site = &pairing{call: node, site: kind}
	return func() { l.site = outer }
}

// usedSite records that the statement being lowered uses what the demand of the call at
// node (kind) made: the rest of the statement's reports are blamed on it too, a result
// that doesn't fit where it goes among them.
func (l *lowerer) usedSite(node *ast.Node, kind siteKind) {
	if p := (pairing{call: node, site: kind}); false && !slices.Contains(l.statementSites, p) {
		l.statementSites = append(slices.Clip(l.statementSites), p)
	}
}

// leavesOutSite reports whether the call at node is lowered as the last fallback that
// doesn't make its demand (kind) lowers it (Narrowing).
func (l *lowerer) leavesOutSite(node *ast.Node, kind siteKind) bool {
	return l.narrowing.leavesOut(pairing{call: node, site: kind})
}

// leavesOut reports whether specialize skips the pairing of a demand with an erased value
// or generic method declared at value (Narrowing).
func (l *lowerer) leavesOut(d *demand, value *ast.Node) bool {
	return l.narrowing.leavesOut(pairing{call: d.node, name: d.name, value: value})
}

// valueNarrowable reports whether the last fallback doesn't list instances in v: a generic
// arrow function's or function expression's erased copy (D-190), an object literal's
// generic method (D-191) or a wrapper (D-194).
func valueNarrowable(v *erasedValue) bool {
	return v.forward != nil || v.generic.closure != nil || v.generic.field != nil
}

// classBlame is what the existence of class is blamed on: the trial that made it, for a
// generic class's instance (blameHere's chain), else nil, the program's own.
func (l *lowerer) classBlame(class *ir.Class) []pairing {
	inst := l.classInstances[class]
	if inst == nil {
		return nil
	}
	for s := inst.subst; s != nil; s = s.made {
		if t := s.trial; t != nil && t.narrowable {
			return []pairing{t.pairing}
		}
	}
	return nil
}

// merge is what b and other are blamed on together: own if either is.
func (b blame) merge(other blame) blame {
	merged := b.with(other.pairings)
	merged.own = b.own || other.own
	return merged
}
