class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
abstract class Maker {
  abstract make<T>(x: T): Box<T>;
}
class WeirdMaker extends Maker {
  make<T>(x: T): Box<T> {
    console.log(new Weird(x).animals().length);
    return new Box(x);
  }
}
const m: Maker = new WeirdMaker();
const b: Box<Dog[]> = m.make([new Dog()]);
console.log(b.value.length);
