// Review round 3: aborting a signal that n `{ signal }` listeners use. Each removal listener is now
// `once`, so the abort takes each one out of the signal's list (indexOf + splice).
const N = Number(process.argv[2] ?? "50000");
const c = new AbortController();
const targets: EventTarget[] = [];
for (let i = 0; i < N; i++) {
  const t = new EventTarget();
  t.addEventListener("ping", () => {}, { signal: c.signal });
  targets.push(t);
}
const start = performance.now();
c.abort();
console.log(`n ${N}: abort ${Math.round(performance.now() - start)} ms`);
