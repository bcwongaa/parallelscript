// Review round 3: n `{ signal }` listeners on one long-lived signal: the time to add them and to abort.
const N = Number(process.argv[2] ?? "20000");
const c = new AbortController();
const targets: EventTarget[] = [];
let start = performance.now();
for (let i = 0; i < N; i++) {
  const t = new EventTarget();
  t.addEventListener("ping", () => {}, { signal: c.signal });
  targets.push(t);
}
const added = performance.now() - start;
start = performance.now();
c.abort();
console.log(`n ${N}: add ${Math.round(added)} ms, abort ${Math.round(performance.now() - start)} ms`);
