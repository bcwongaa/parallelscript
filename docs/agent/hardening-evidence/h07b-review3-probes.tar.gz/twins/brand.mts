// Review round 3: the { signal } option given something that isn't an AbortSignal (through any):
// signal.#add is a private call on it now. It must throw a TypeError, not crash.
function tryAdd(name: string, signal: any): void {
  const t = new EventTarget();
  try {
    t.addEventListener("ping", () => console.log(name, "listener ran"), { signal });
    console.log(name, "added");
    t.dispatchEvent(new Event("ping"));
  } catch (error) {
    console.log(name, "threw", (error as Error).name);
  }
}
tryAdd("plain object", {});
tryAdd("object with aborted false", { aborted: false });
tryAdd("an EventTarget", new EventTarget());
tryAdd("a number", 42);
tryAdd("null", null);
console.log("end");
