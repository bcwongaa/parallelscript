// Review round 3: stopImmediatePropagation against the { signal } option's resisting removal listener, vs Node.
function log(...parts: unknown[]): void {
  console.log(parts.map(String).join(" "));
}
{
  log("-- 1. a non-abort event: later listeners skipped, a once listener after the stop kept");
  const t = new EventTarget();
  t.addEventListener("ping", (e) => {
    log("first stops");
    e.stopImmediatePropagation();
  }, { once: true });
  t.addEventListener("ping", () => log("once listener"), { once: true });
  t.addEventListener("ping", () => log("plain listener"));
  log("dispatch 1");
  t.dispatchEvent(new Event("ping"));
  log("dispatch 2");
  t.dispatchEvent(new Event("ping"));
  log("dispatch 3");
  t.dispatchEvent(new Event("ping"));
}
{
  log("-- 2. abort stopped: the removal runs, later plain and once listeners don't, the once one is kept");
  const c = new AbortController();
  const t = new EventTarget();
  c.signal.addEventListener("abort", (e) => {
    log("stopper");
    e.stopImmediatePropagation();
  });
  t.addEventListener("ping", () => log("SHOULD NOT RUN: removed by the signal"), { signal: c.signal });
  c.signal.addEventListener("abort", () => log("once abort listener"), { once: true });
  c.signal.addEventListener("abort", () => log("plain abort listener"));
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("an untrusted abort event afterwards:");
  c.signal.dispatchEvent(new Event("abort"));
}
{
  log("-- 3. two { signal } removals around a stopping listener");
  const c = new AbortController();
  const t = new EventTarget();
  t.addEventListener("a", () => log("SHOULD NOT RUN a"), { signal: c.signal });
  c.signal.addEventListener("abort", (e) => e.stopImmediatePropagation());
  t.addEventListener("b", () => log("SHOULD NOT RUN b"), { signal: c.signal });
  c.signal.addEventListener("abort", () => log("SHOULD NOT RUN plain"));
  c.abort();
  t.dispatchEvent(new Event("a"));
  t.dispatchEvent(new Event("b"));
  log("done 3");
}
{
  log("-- 4. re-entrancy: the stopping listener dispatches an untrusted abort to the same signal");
  const c = new AbortController();
  const t = new EventTarget();
  let depth = 0;
  c.signal.addEventListener("abort", (e) => {
    depth++;
    log("stopper, depth", depth, "trusted", e.isTrusted);
    e.stopImmediatePropagation();
    if (depth === 1) {
      c.signal.dispatchEvent(new Event("abort"));
    }
  });
  t.addEventListener("ping", () => log("SHOULD NOT RUN"), { signal: c.signal });
  c.signal.addEventListener("abort", () => log("plain, never"));
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done 4");
}
{
  log("-- 5. re-entrancy: a listener before the stop dispatches untrusted abort (uses the removal up), then the real one");
  const c = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("ping listener");
  let first = true;
  c.signal.addEventListener("abort", () => {
    if (first) {
      first = false;
      c.signal.dispatchEvent(new Event("abort"));
      t.addEventListener("ping", l);
    }
  });
  t.addEventListener("ping", l, { signal: c.signal });
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done 5");
}
{
  log("-- 6. self-signal once listener with a stopper before it");
  const c = new AbortController();
  c.signal.addEventListener("abort", (e) => e.stopImmediatePropagation());
  c.signal.addEventListener("abort", () => log("SHOULD NOT RUN"), { once: true, signal: c.signal });
  c.abort();
  c.signal.dispatchEvent(new Event("abort"));
  log("done 6");
}
{
  log("-- 7. preventDefault and the return value with a stop");
  const t = new EventTarget();
  t.addEventListener("x", (e) => {
    e.preventDefault();
    e.stopImmediatePropagation();
  });
  t.addEventListener("x", () => log("SHOULD NOT RUN"));
  log("dispatch returned", t.dispatchEvent(new Event("x", { cancelable: true })));
}
{
  log("-- 8. stopped follower: a follower's { signal } listener when the follower's earlier listener stops");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  const t = new EventTarget();
  d.addEventListener("abort", (e) => e.stopImmediatePropagation());
  t.addEventListener("ping", () => log("SHOULD NOT RUN"), { signal: d });
  a.abort();
  t.dispatchEvent(new Event("ping"));
  log("done 8");
}
