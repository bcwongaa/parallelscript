#!/bin/bash
# ir.sh <binary> <N> <section>: total instructions (callgrind) for one section at N, minus the same at N=0
bin=$1; n=$2; sec=$3
ir() { PTS_THREADS=1 GC_INITIAL_HEAP_SIZE=200000000 valgrind --tool=callgrind --callgrind-out-file=/dev/null "$bin" $1 $sec 2>&1 >/dev/null | awk '/Collected/{print $4}'; }
a=$(ir 0); b=$(ir $n)
echo "$(basename $bin) section $sec: $(( (b - a) / n )) instructions/op"
