#!/bin/bash
# loop.sh <binary> <expected-file> <threads> <runs> [timeout-s]: run a test binary repeatedly and count matches
bin=$1; exp=$2; threads=$3; runs=$4; to=${5:-30}
pass=0; fail=0
for ((r=1; r<=runs; r++)); do
  start=$(date +%s.%N)
  out=$(PTS_THREADS=$threads TZ=America/New_York timeout $to "$bin" 2>&1); code=$?
  end=$(date +%s.%N)
  if [[ $code -eq 0 && "$out" == "$(cat "$exp")" ]]; then pass=$((pass+1)); else fail=$((fail+1)); echo "FAIL run $r (exit $code, $(echo "$end - $start" | bc)s):"; diff <(echo "$out") "$exp" | head -12; fi
  last=$(echo "$end - $start" | bc)
done
echo "$(basename $bin) threads=$threads pass=$pass fail=$fail last=${last}s"
