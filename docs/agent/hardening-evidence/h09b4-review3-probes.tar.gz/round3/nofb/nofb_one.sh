#!/bin/bash
# nofb_one.sh file.pts -> "name|base AllInstances result|snap7 AllInstances result" (no fallback)
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap7/pts/tests/||; s|/|__|g; s|.pts$||')
b=$(PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/review/nofb/nofb-base all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
s=$(PTS_HOME=/tmp/h09b4/snap7 timeout 120 /tmp/h09b4/review/round3/nofb/nofb-snap7 all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
echo "$n|$b|$s"
