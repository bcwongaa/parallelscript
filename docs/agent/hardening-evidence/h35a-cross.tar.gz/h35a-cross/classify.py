# Classifies a cross-compiled suite's failed leaf tests by their output: a sanitizer
# runtime the cross clang lacks, the tests' program deadline under emulation, or other.
import json, sys, collections
out = collections.defaultdict(list)
results, counts = {}, collections.Counter()
for line in open(sys.argv[1]):
    try: e = json.loads(line)
    except ValueError: continue
    t, a = e.get('Test'), e.get('Action')
    if not t: continue
    key = (e['Package'], t)
    if a == 'output': out[key].append(e.get('Output', ''))
    if a in ('pass', 'fail', 'skip'): results[key] = a; counts[a] += 1
leaves = [k for k, a in results.items() if a == 'fail' and not any(o[0] == k[0] and o[1].startswith(k[1] + '/') for o in results)]
kinds = collections.defaultdict(list)
for k in leaves:
    text = ''.join(out[k])
    if 'libclang_rt' in text: kind = 'sanitizer runtime missing for aarch64'
    elif 'signal: killed' in text or 'context deadline exceeded' in text or 'deadline' in text: kind = 'program deadline under emulation'
    else: kind = 'other'
    kinds[kind].append(k[1])
print(dict(counts), 'leaf failures:', len(leaves))
for kind, tests in kinds.items():
    print(f'{kind}: {len(tests)}')
    for t in sorted(tests): print('   ', t)
