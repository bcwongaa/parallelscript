from pathlib import Path
import subprocess, os, json, sys
root = Path('/tmp/c251-caps-review.2Pez0ecw')
repo = Path('/home/bryan/projects/parallelscript')
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo))
clis = {'base': '/tmp/h09b5c2b.8x5wR1nC/base-pts', 'current': str(root / 'current-pts')}
results = []

def run(command, timeout=90):
    try:
        p = subprocess.run(command, cwd=str(repo), env=env, capture_output=True, text=True, timeout=timeout)
        return {'command': command, 'exit': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    except subprocess.TimeoutExpired as e:
        return {'command': command, 'exit': 'TIMEOUT', 'stdout': str(e.stdout), 'stderr': str(e.stderr)}

for source in sorted((root / 'cases').glob('*.pts')):
    mts = source.with_suffix('.mts')
    mts.write_bytes(source.read_bytes())
    row = {'source': str(source), 'node': run(['/home/bryan/.local/node/bin/node', '--no-warnings', '--experimental-transform-types', str(mts)])}
    for label, cli in clis.items():
        binary = root / ('probe-' + label + '.bin')
        binary.unlink(missing_ok=True)
        build = run([cli, 'build', str(source), '-o', str(binary)])
        entry = {'build': build}
        if build['exit'] == 0:
            entry['run'] = run([str(binary)], timeout=20)
            entry['node_match'] = all(entry['run'][field] == row['node'][field] for field in ['exit', 'stdout'])
        binary.unlink(missing_ok=True)
        row[label] = entry
    results.append(row)
    (root / 'native-results.json').write_text(json.dumps(results, indent=2) + '\n')
    def desc(label):
        entry = row[label]
        return f"build={entry['build']['exit']} run={entry.get('run', {}).get('exit', '-')} node_match={entry.get('node_match', '-')}"
    print(source.name + ': node=' + str(row['node']['exit']) + ' base(' + desc('base') + ') current(' + desc('current') + ')', flush=True)
