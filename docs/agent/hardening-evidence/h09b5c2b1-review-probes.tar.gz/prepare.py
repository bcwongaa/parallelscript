from pathlib import Path
import json, subprocess, hashlib
ROOT = Path('/home/bryan/projects/parallelscript')
OUT = Path('/tmp/c251-caps-review.2Pez0ecw')
(OUT / 'snapshot').mkdir(exist_ok=True)
(OUT / 'cases').mkdir(exist_ok=True)
files = ['pts/lower/lower.go', 'pts/lower/narrowing.go', 'pts/lower/containing_code.go', 'pts/lower/containing_code_test.go', 'pts/lower/containing_code_caps_test.go', 'pts/driver/containing_code_caps_test.go', 'pts/tests/run/generic_containing_value_pairing.pts']
overlay = {}
hashes = {}
for rel in files:
    raw = (ROOT / rel).read_bytes()
    dest = OUT / 'snapshot' / rel.replace('/', '__')
    dest.write_bytes(raw)
    hashes[rel] = hashlib.sha256(raw).hexdigest()
    overlay[str(ROOT / rel)] = str(dest)
(OUT / 'snapshot-hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')
(OUT / 'plain-overlay.json').write_text(json.dumps({'Replace': overlay}, indent=2) + '\n')
raw = (OUT / 'snapshot/pts__lower__lower.go').read_text()
raw = raw.replace('return result, l.errors, l.narrower()', 'reviewLastLowering = l\n\treturn result, l.errors, l.narrower()', 1)
raw += '\nvar reviewLastLowering *lowerer\n'
(OUT / 'instrumented-lower.go').write_text(raw)
overlay[str(ROOT / 'pts/lower/lower.go')] = str(OUT / 'instrumented-lower.go')
overlay[str(ROOT / 'pts/lower/c251_review_test.go')] = str(OUT / 'c251_review_test.go')
(OUT / 'review-overlay.json').write_text(json.dumps({'Replace': overlay}, indent=2) + '\n')
base = (OUT / 'snapshot/pts__tests__run__generic_containing_value_pairing.pts').read_text()
(OUT / 'cases/fixture.pts').write_text(base)
roots = {
    'own': 'const own = new Bad().make([new Dog()]); console.log("own", own.value.length);',
    'value': '''function valueRoot(): void {
 const via = <T,>(value: T): Box<T> => new Bad().make(value);
 const box: Box<Dog[]> = via([new Dog()]);
 console.log("value", box.value.length);
}
valueRoot();''',
}
for name, root in roots.items():
    for placement in ['before', 'after']:
        source = base.replace('function main(): void {', root + '\nfunction main(): void {', 1) if placement == 'before' else base + '\n' + root + '\n'
        (OUT / f'cases/shared-{name}-{placement}.pts').write_text(source)
# A single AST body can be shared by generic outer instances.
for name, root in {'own': roots['own'], 'value': roots['value']}.items():
    source = base.replace('class Bad implements Maker', 'class Bad<U> implements Maker').replace('new Bad()', 'new Bad<number>()')
    source += '\n' + root.replace('new Bad()', 'new Bad<number>()') + '\n'
    (OUT / f'cases/class-shared-{name}.pts').write_text(source)
# Erased and typed nested closure bodies use erasing substitutions, not the first maker.
for wrapper in ['arrow', 'function']:
    poison = '<T,>(value: T): Weird<T> => new Weird(value)' if wrapper == 'arrow' else 'function <T>(value: T): Weird<T> { return new Weird(value); }'
    source = base.replace('const poison = <T,>(value: T): Weird<T> => new Weird(value);', 'const wrap = (seed: number): Factory => { const poison = ' + poison + '; return poison; };\n  const poison = wrap(1);')
    (OUT / f'cases/nested-{wrapper}.pts').write_text(source)
# Calls with different source declarations may share a descriptor entry/signature.
source = base.replace('const result: Box<T> = f(value);', 'const result: Box<T> = f(value);\n    const again: Box<T> = f(value);')
(OUT / 'cases/second-demand.pts').write_text(source)
# Identical constant-key and rest sites across the method's erased/typed code.
for form, call in [('constant', 'f(value); const keyed = new Good()["make"](value)'), ('rest', 'f(...[value])')]:
    source = base.replace('const result: Box<T> = f(value);', 'const result: Box<T> = ' + call + ';')
    (OUT / f'cases/site-{form}.pts').write_text(source)
# A trial can be rolled back by an AllInstances-only by-name/defaulted method site.
optional = '''interface OptionalMaker { f<T>(a?: number, ...xs: T[]): Box<T[]>; }
class OptionalCM implements OptionalMaker { f<T>(a?: number, ...xs: T[]): Box<T[]> { return new Box(xs); } }
function maybe(): number | undefined { return undefined; }
const opt: OptionalMaker = new OptionalCM();
'''
for order in ['before', 'after']:
    site = 'try { const b: Box<T[]> = opt.f(maybe(), value); console.log("inner", b.value.length); } catch (e: any) { console.log("inner", 1); }'
    body = site + '\n const result = new Bad().make(value); return new Box(result.value);' if order == 'before' else 'const result = new Bad().make(value);\n ' + site + '\n return new Box(result.value);'
    root = '''function valueRoot(): void {
 const via = <T,>(value: T): Box<T> => { ''' + body + ''' };
 const box: Box<Dog[]> = via([new Dog()]); console.log("value", box.value.length);
}
valueRoot();'''
    (OUT / f'cases/rolledback-{order}.pts').write_text(base + '\n' + optional + root + '\n')
print('prepared', len(list((OUT / 'cases').glob('*.pts'))), 'source probes')
