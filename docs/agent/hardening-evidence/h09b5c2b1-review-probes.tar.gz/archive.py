from pathlib import Path
import tarfile, hashlib, json
root = Path('/tmp/c251-caps-review.2Pez0ecw')
repo = Path('/home/bryan/projects/parallelscript')
archive = root.with_name(root.name + '-probes.tar.gz')
hashes = json.loads((root / 'snapshot-hashes.json').read_text())
for rel in ['pts/lower/lower.go', 'pts/lower/narrowing.go', 'pts/lower/containing_code.go']:
    actual = hashlib.sha256((repo / rel).read_bytes()).hexdigest()
    print(rel + ': production_unchanged=' + str(actual == hashes[rel]))
with tarfile.open(archive, 'w:gz') as out:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.is_symlink() or path.name == 'current-pts' or path.suffix == '.bin':
            continue
        if path.parent.name == 'snapshot' and '__' not in path.name:
            continue # Obsolete basenames from the corrected snapshot-harness setup.
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic == b'\x7fELF':
            raise SystemExit('unexpected executable: ' + str(path))
        out.add(path, arcname=str(path.relative_to(root)), recursive=False)
with tarfile.open(archive, 'r:gz') as inp:
    members = inp.getmembers()
    assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in members)
print('archive=' + str(archive))
print('members=' + str(len(members)))
print('sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
results = json.loads((root / 'native-results.json').read_text())
for row in results:
    if Path(row['source']).stem in ['fixture', 'rolledback-before', 'rolledback-after']:
        print('CASE', Path(row['source']).name)
        for label in ['base', 'current']:
            entry = row[label].get('run', row[label]['build'])
            print(label, 'exit=' + str(entry['exit']), 'stdout=' + repr(entry['stdout']), 'stderr=' + repr(entry['stderr']))
        print('node', 'exit=' + str(row['node']['exit']), 'stdout=' + repr(row['node']['stdout']))
