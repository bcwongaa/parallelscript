package driver_test

import (
	"os"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"gotest.tools/v3/assert"
)

func TestContainingCodeAllowsANarrowerAllInstancesLowering(t *testing.T) {
	t.Parallel()
	entry := writeSource(t, containingCodeSource(t))

	c, err := driver.EmitCNarrowedWith(t.Context(), entry, lower.AllInstances)

	assert.NilError(t, err)
	assert.Assert(t, strings.Contains(c, "pts_method_instance_find"), "leaving out a nested value pairing must retain the unrelated by-name call")
}

func TestContainingCodeKeepsTheDriversByNameInstances(t *testing.T) {
	t.Parallel()
	entry := writeSource(t, containingCodeSource(t))

	c, err := driver.EmitC(t.Context(), entry)

	assert.NilError(t, err)
	assert.Assert(t, strings.Contains(c, "pts_method_instance_find"), "an AllInstances-only containing instance must not send the whole program to ValueInstances")
}

func containingCodeSource(t *testing.T) string {
	t.Helper()
	source, err := os.ReadFile("../tests/run/generic_containing_value_pairing.pts")
	assert.NilError(t, err)
	return string(source)
}
