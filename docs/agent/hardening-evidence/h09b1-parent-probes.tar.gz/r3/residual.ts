class Box<T> {
  constructor(public value: T) {}
}
type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
const Ops = {
  wrap<T>(x: T): Opt<T> {
    return { tag: "some", value: [x] };
  },
  first<T>(xs: T[]): Box<T> {
    return new Box(xs[0]);
  },
};
const o = Ops["wrap"](7);
if (o.tag === "some") {
  const xs: number[] = o.value;
  try {
    const b: Box<number> = Ops.first(xs);
    console.log("first", b.value);
  } catch (e: any) {
    console.log("first", e.name, e.message);
  }
  console.log("typed read", xs[0] + 1);
}
