class Box<T> {
  constructor(public value: T) {}
}
class Pair<A, B> {
  constructor(public first: A, public second: B) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
interface Paired<U> {
  pair<T>(x: T): Pair<T, U>;
}
interface Named extends Maker {
  name(): string;
}
class Base implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Derived extends Base {}
abstract class Abstract implements Maker {
  abstract make<T>(x: T): Box<T>;
}
class Concrete extends Abstract {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Tagged<U> implements Paired<U> {
  constructor(private tag: U) {}
  pair<T>(x: T): Pair<T, U> {
    return new Pair(x, this.tag);
  }
}
class Both implements Named {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  name(): string {
    return "both";
  }
}
function viaParam(m: Maker): string {
  const b: Box<number> = m.make(1);
  const s: Box<string> = m.make("xy");
  return `${b.value + 1} ${s.value.length}`;
}
attempt("inherited", () => viaParam(new Derived()));
attempt("abstract base", () => viaParam(new Concrete()));
attempt("extended interface", () => viaParam(new Both()));
const tagged: Paired<string> = new Tagged("t");
attempt("generic interface", () => {
  const p: Pair<number, string> = tagged.pair(3);
  return `${p.first + 1} ${p.second}`;
});
let counter = 10;
const literal = {
  base: 100,
  make<T>(x: T): Box<T> {
    counter++;
    return new Box(x);
  },
  offset<T>(x: T): Pair<T, number> {
    return new Pair(x, this.base + counter);
  },
};
attempt("literal with captures and this", () => {
  const b: Box<number> = literal.make(2);
  const p: Pair<string, number> = literal.offset("o");
  return `${b.value} ${p.first} ${p.second}`;
});
const makers: Maker[] = [new Base(), literal, { make: <T>(x: T): Box<T> => new Box(x) }, new Concrete()];
attempt("mixed array", () => makers.map((m) => { const b: Box<number> = m.make(7); return b.value; }).join(","));
const optional: Maker | undefined = new Base();
attempt("optional chain", () => {
  const b: Box<number> | undefined = optional?.make(8);
  return String(b?.value);
});
interface AsyncMaker {
  later<T>(x: T): Promise<Box<T>>;
}
class Later implements AsyncMaker {
  async later<T>(x: T): Promise<Box<T>> {
    return new Box(x);
  }
}
const asyncMaker: AsyncMaker = new Later();
async function main(): Promise<void> {
  try {
    const b: Box<number> = await asyncMaker.later(9);
    console.log("promise", b.value + 1);
  } catch (error: any) {
    console.log("promise", error.name, error.message);
  }
}
const fromAny: any = new Base();
attempt("cast from any", () => {
  const b: Box<number> = (fromAny as Maker).make(11);
  return String(b.value + 1);
});
function factory(n: number): Maker {
  return {
    make<T>(x: T): Box<T> {
      n++;
      return new Box(x);
    },
  };
}
attempt("factory literal", () => viaParam(factory(1)));
main();
