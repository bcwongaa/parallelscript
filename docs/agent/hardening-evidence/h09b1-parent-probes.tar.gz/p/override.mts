class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Base implements Maker {
  make<T>(x: T): Box<T> {
    console.log("base make");
    return new Box(x);
  }
}
class Sub extends Base {
  make(x: any): Box<any> {
    console.log("sub make");
    return new Box(x);
  }
}
const items: Base[] = [new Base(), new Sub()];
for (const item of items) {
  const b: Box<number> = item.make(4);
  console.log(b.value + 1);
}
const m: Maker = new Sub();
const c: Box<number> = m.make(5);
console.log(c.value + 1);
