class Box<T> { constructor(public value: T) {} }
function main(): void {
  const make = <T>(x: T): Box<T> => new Box(x);
  const b: Box<number> = make(5);
  console.log(b.value + 1);
  const wrap = function <T>(x: T): Box<T> { return new Box(x); };
  console.log(wrap("s").value.length);
}
main();
function run(f: <T>(x: T) => Box<T>): number { return f(3).value * 2; }
console.log(run(<T>(x: T) => new Box(x)));
console.log(run(function <T>(x: T) { return new Box(x); }));
const anyf: any = <T>(x: T) => new Box(x);
const typed: <T>(x: T) => Box<T> = anyf;
console.log(typed(4).value);
