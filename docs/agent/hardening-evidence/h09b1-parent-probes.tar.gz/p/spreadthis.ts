class Box<T> {
  constructor(public value: T) {}
}
const literal = {
  base: 100,
  make<T>(x: T): Box<T> {
    console.log("base is", this.base);
    return new Box(x);
  },
};
const copy = { extra: "e", ...literal };
const b: Box<number> = copy.make(5);
console.log(b.value + 1);
const copy2 = { ...literal, base: 7 };
const c: Box<string> = copy2.make("s");
console.log(c.value);
