interface Pairs { pair<T>(...items: [T, T]): T[]; }
class P implements Pairs { pair<T>(...items: [T, T]): T[] { return items; } }
const p: Pairs = new P();
console.log(p.pair(1, 2));
