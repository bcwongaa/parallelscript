#!/bin/bash
# cmp.sh PTS_HOME file.pts...: build and run each program with that tree's CLI and with Node (an .mts copy), print both outputs and whether they match.
set -uo pipefail
home=$1; shift
node=$HOME/.local/node/bin/node; cli=${PTS_CLI:-$home/pts-bin/pts}
for f0 in "$@"; do f=$(realpath "$f0")
  b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/cmp.XXXX)
  cp "$f" "$d/$b.mts"
  pts_out=$(cd "$d" && PTS_HOME=$home timeout 120 "$cli" run "$f" 2>&1; echo "[exit $?]")
  node_out=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  if [ "$pts_out" == "$node_out" ]; then echo "== $b: MATCH"; else echo "== $b: DIFFER"; fi
  echo "-- pts"; echo "$pts_out"; echo "-- node"; echo "$node_out"
  rm -rf "$d"
done
