# bf.py FIX_HOME OUT.json files...: run each program with the base CLI and FIX_HOME's CLI (2 jobs);
# where they differ, run Node too. Prints counts; OUT.json has every result.
import json, os, subprocess, sys, tempfile, shutil
from concurrent.futures import ThreadPoolExecutor
fix, out, files = sys.argv[1], sys.argv[2], sys.argv[3:]
base = "/tmp/h09b/base/tree"
node = os.path.expanduser("~/.local/node/bin/node")
def run(home, f):
    try:
        r = subprocess.run([home + "/pts-bin/pts", "run", f], env=dict(os.environ, PTS_HOME=home, TZ="America/New_York"), capture_output=True, text=True, timeout=300, cwd=os.path.dirname(f))
        return r.stdout + r.stderr + f"[exit {r.returncode}]"
    except subprocess.TimeoutExpired:
        return "[timeout]"
def node_run(f):
    d = tempfile.mkdtemp(dir="/tmp/h09b/tmp")
    m = os.path.join(d, os.path.basename(f)[:-4] + ".mts")
    shutil.copy(f, m)
    try:
        r = subprocess.run([node, "--no-warnings", "--experimental-transform-types", m], capture_output=True, text=True, timeout=60, cwd=d, env=dict(os.environ, TZ="America/New_York"))
        return r.stdout + r.stderr + f"[exit {r.returncode}]"
    except subprocess.TimeoutExpired:
        return "[timeout]"
    finally:
        shutil.rmtree(d)
def one(f):
    b, x = run(base, f), run(fix, f)
    res = {"file": f, "base": b, "fix": x}
    if b != x:
        res["node"] = node_run(f)
    return res
os.makedirs("/tmp/h09b/tmp", exist_ok=True)
with ThreadPoolExecutor(2) as pool:
    results = list(pool.map(one, files))
json.dump(results, open(out, "w"), indent=1)
same = sum(r["base"] == r["fix"] for r in results)
better = [r["file"] for r in results if r["base"] != r["fix"] and r["fix"] == r.get("node")]
worse = [r["file"] for r in results if r["base"] != r["fix"] and r["base"] == r.get("node")]
other = [r["file"] for r in results if r["base"] != r["fix"] and r["fix"] != r.get("node") and r["base"] != r.get("node")]
print("total", len(results), "same", same, "fix=node (was not)", len(better), "base=node (fix not)", len(worse), "both differ from node", len(other))
for f in worse: print("WORSE", f)
for f in other: print("OTHER", f)
