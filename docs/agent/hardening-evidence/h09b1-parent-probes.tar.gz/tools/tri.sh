#!/bin/bash
# tri.sh FIX_HOME file.pts...: run each program with the base CLI, FIX_HOME's CLI and Node v24 (.mts copy,
# --no-warnings --experimental-transform-types, TZ=America/New_York); print all three and whether they agree.
set -uo pipefail
fix=$1; shift
node=$HOME/.local/node/bin/node
mkdir -p /tmp/h09b/tmp
for f0 in "$@"; do f=$(realpath "$f0")
  b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09b/tmp/tri.XXXX)
  cp "$f" "$d/$b.mts"
  base_out=$(cd "$d" && TZ=America/New_York PTS_HOME=/tmp/h09b/base/tree timeout 300 /tmp/h09b/base/tree/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  fix_out=$(cd "$d" && TZ=America/New_York PTS_HOME=$fix timeout 300 $fix/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  node_out=$(cd "$d" && TZ=America/New_York timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  tag=""
  [ "$fix_out" == "$node_out" ] && tag="$tag fix=node" || tag="$tag fix!=node"
  [ "$base_out" == "$fix_out" ] && tag="$tag base=fix" || tag="$tag base!=fix"
  [ "$base_out" == "$node_out" ] && tag="$tag base=node" || tag="$tag base!=node"
  echo "== $b:$tag"
  echo "-- base"; echo "$base_out"; echo "-- fix"; echo "$fix_out"; echo "-- node"; echo "$node_out" | head -40
  rm -rf "$d"
done
