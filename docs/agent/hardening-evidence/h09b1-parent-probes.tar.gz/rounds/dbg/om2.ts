type Option<T> = { readonly tag: "some"; readonly value: T } | { readonly tag: "none" };
const some = <T>(value: T): Option<T> => ({ tag: "some", value });
const none: Option<never> = { tag: "none" };
interface Customer {
  id: number;
  zip?: string;
}
function fromNullable<T>(x: T | null | undefined): Option<T> {
  return x === null || x === undefined ? none : some(x);
}
function flatMap<T, U>(o: Option<T>, f: (x: T) => Option<U>): Option<U> {
  return o.tag === "some" ? f(o.value) : none;
}
const Opt = {
  fromNullable<T>(x: T | null | undefined): Option<T> {
    return x === null || x === undefined ? none : some(x);
  },
  flatMap<T, U>(o: Option<T>, f: (x: T) => Option<U>): Option<U> {
    return o.tag === "some" ? f(o.value) : none;
  },
};
const zipOf = (c: Customer): Option<string> => fromNullable(c.zip);
const raw: any = { id: 1, zip: "1100" };
const viaValue = (fromNullable as <T>(x: T | null | undefined) => Option<T>)<Customer>(raw);
try {
  console.log("declared", flatMap(viaValue, zipOf));
} catch (e: any) {
  console.log("declared", e.message);
}
const viaLiteral = Opt.fromNullable<Customer>(raw);
try {
  console.log("literal", Opt.flatMap(viaLiteral, zipOf));
} catch (e: any) {
  console.log("literal", e.message);
}
