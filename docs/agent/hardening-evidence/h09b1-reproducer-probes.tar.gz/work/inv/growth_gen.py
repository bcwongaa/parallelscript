"""Write a program with N object literals and N classes, each with a generic `make`, behind
one interface, and M typed interface calls of distinct type arguments, to measure how
pairing every named demand with every method of the name grows the C (H09b1 risk).

Usage: python3 -I growth_gen.py N M OUT.pts
"""
import sys

n, m, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
lines = ["class Box<T> {", "  constructor(public value: T) {}", "}",
         "interface Maker {", "  make<T>(x: T): Box<T>;", "}"]
for i in range(m):
    lines.append(f"class K{i} {{ constructor(public k: number) {{}} }}")
makers = []
for i in range(n):
    lines += [f"class C{i} implements Maker {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
    lines += [f"const l{i}: Maker = {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  },", "};"]
    makers += [f"new C{i}()", f"l{i}"]
lines.append(f"const makers: Maker[] = [{', '.join(makers)}];")
lines.append("let total = 0;")
lines.append("for (const mk of makers) {")
for i in range(m):
    lines.append(f"  const b{i}: Box<K{i}> = mk.make(new K{i}({i}));")
    lines.append(f"  total += b{i}.value.k;")
lines.append("}")
lines.append("console.log(total);")
open(out, "w").write("\n".join(lines) + "\n")
