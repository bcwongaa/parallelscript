"""Write a program with N object literals, each with a generic `make`, each called once
through its own type with its own type argument (and N classes each called once through
the interface with its own type argument): N calls a program needs, which pairing every
named demand with every method of the name makes N x N instances of (H09b1 risk:
speculative growth, C172).

Usage: python3 -I growth2_gen.py N OUT.pts
"""
import sys

n, out = int(sys.argv[1]), sys.argv[2]
lines = ["class Box<T> {", "  constructor(public value: T) {}", "}",
         "interface Maker {", "  make<T>(x: T): Box<T>;", "}", "let total = 0;"]
for i in range(n):
    lines.append(f"class K{i} {{ constructor(public k: number) {{}} }}")
    lines += [f"const l{i} = {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  },", "};"]
    lines.append(f"const lb{i}: Box<K{i}> = l{i}.make(new K{i}({i}));")
    lines.append(f"total += lb{i}.value.k;")
    lines += [f"class C{i} implements Maker {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
    lines.append(f"const cm{i}: Maker = new C{i}();")
    lines.append(f"const cb{i}: Box<K{i}> = cm{i}.make(new K{i}({i}));")
    lines.append(f"total += cb{i}.value.k;")
lines.append("console.log(total);")
open(out, "w").write("\n".join(lines) + "\n")
