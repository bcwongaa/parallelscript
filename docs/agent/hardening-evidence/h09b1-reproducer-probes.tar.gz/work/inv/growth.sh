#!/bin/bash
# growth.sh HOME CLI LABEL files...: lines of C (`pts emit-c`) and wall time of `pts build`
# for each program, with that CLI and PTS_HOME.
home=$1; cli=$2; label=$3; shift 3
mkdir -p /tmp/h09b1-repro/work/tmp/growth
for f in "$@"; do
  b=$(basename "$f" .pts)
  lines=$(PTS_HOME=$home "$cli" emit-c "$f" 2>/dev/null | wc -l)
  start=$(date +%s.%N)
  PTS_HOME=$home "$cli" build -o "/tmp/h09b1-repro/work/tmp/growth/$b-$label" "$f" > /dev/null 2>&1
  code=$?
  end=$(date +%s.%N)
  out=$("/tmp/h09b1-repro/work/tmp/growth/$b-$label" 2>&1 | head -2 | tr '\n' ' ')
  printf '%s %s C-lines=%s build-exit=%s build-seconds=%.1f output=%s\n' "$label" "$b" "$lines" "$code" "$(echo "$end - $start" | bc)" "$out"
done
