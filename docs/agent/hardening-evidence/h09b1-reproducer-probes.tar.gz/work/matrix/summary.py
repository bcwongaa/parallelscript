"""Summarize a matrix results file: verdict counts overall, by definition form, by use
site and by shape; and per-type-argument line verdicts.

Usage: python3 -I summary.py RESULTS.json [cases.json]
"""
import collections
import json
import os
import sys

results = json.load(open(sys.argv[1]))
meta_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(sys.argv[1]), "cases", "cases.json")
meta = json.load(open(meta_path))


def table(key):
    counts = collections.defaultdict(collections.Counter)
    for name, r in results.items():
        m = meta.get(name)
        if m is None:
            continue
        counts[m[key]][r["verdict"]] += 1
    verdicts = sorted({v for c in counts.values() for v in c})
    print(f"\n## by {key}")
    print(f"{key:28s} " + " ".join(f"{v:>8s}" for v in verdicts))
    for k in sorted(counts):
        print(f"{k:28s} " + " ".join(f"{counts[k][v]:8d}" for v in verdicts))


total = collections.Counter(r["verdict"] for r in results.values())
print("## overall", dict(sorted(total.items())), "cases", len(results))
for key in ("definition", "use", "shape"):
    table(key)
lines = collections.defaultdict(collections.Counter)
for name, r in results.items():
    for label, v in r["lines"].items():
        lines[label][v] += 1
print("\n## per type argument line (cases that ran)")
for label in sorted(lines):
    print(f"{label:10s}", dict(sorted(lines[label].items())))
diags = collections.Counter(r["diag"] for r in results.values() if r["verdict"] in ("DIAG", "ICE", "CRASH", "TSERR"))
print("\n## diagnostics")
for d, n in diags.most_common():
    print(n, d[:200].replace("\n", " | "))
wrong = [n for n, r in results.items() if r["verdict"] == "WRONG"]
print("\n## WRONG cases", wrong)
