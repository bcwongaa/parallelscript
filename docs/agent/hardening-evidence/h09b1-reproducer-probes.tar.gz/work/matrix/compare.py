"""Compare two matrix results files case by case: verdict counts of each, and every case
whose verdict changed (and whether it got better or worse).

Usage: python3 -I compare.py A.json B.json CASES/cases.json
"""
import collections
import json
import sys

a, b = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
meta = json.load(open(sys.argv[3]))
print("A", dict(sorted(collections.Counter(r["verdict"] for r in a.values()).items())), len(a))
print("B", dict(sorted(collections.Counter(r["verdict"] for r in b.values()).items())), len(b))
changes = collections.Counter()
rank = {"OK": 0, "TYPEERR": 1, "WRONG": 2, "DIAG": 2, "TSERR": 0, "NODEERR": 0, "ICE": 3, "CRASH": 3}
worse = []
for name in sorted(a):
    va, vb = a[name]["verdict"], b[name]["verdict"]
    if va != vb:
        changes[(va, vb)] += 1
        if rank[vb] > rank[va]:
            worse.append(name)
    elif va == vb == "OK" and a[name]["pts"] != b[name]["pts"]:
        worse.append(name + " (OK output differs)")
print("changes", dict(changes))
by_def = collections.Counter(meta[n]["definition"] + ":" + meta[n]["use"] for n in a if a[n]["verdict"] != b[n]["verdict"])
print("changed by definition:use", dict(sorted(by_def.items())))
print("worse", worse)
left = collections.Counter(meta[n]["definition"] for n in b if b[n]["verdict"] == "TYPEERR")
print("TYPEERR left in B by definition", dict(sorted(left.items())))
left_use = collections.Counter(meta[n]["use"] for n in b if b[n]["verdict"] == "TYPEERR")
print("TYPEERR left in B by use", dict(sorted(left_use.items())))
