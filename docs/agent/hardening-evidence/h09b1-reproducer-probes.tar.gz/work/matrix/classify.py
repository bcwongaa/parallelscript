"""List the interface-method and object-literal-method matrix cases with their verdicts, split
into calls through the interface or the literal (H09b1: uses `direct`, `explicit`) and method
values passed on (`im.mk` / `o.mk` as a value: param, var, field, iface_sig, through_*, map_ctx,
bind, call, apply), which are later H09b slices.

Usage: python3 -I classify.py RESULTS.json CASES/cases.json [OTHER_RESULTS.json]
"""
import collections
import json
import sys

results = json.load(open(sys.argv[1]))
meta = json.load(open(sys.argv[2]))
other = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else None
CALLS = ("direct", "explicit")
groups = collections.defaultdict(list)
for name in sorted(results):
    m = meta[name]
    kind = "call" if m["use"] in CALLS else "value"
    groups[(m["definition"], kind)].append(name)
for key in sorted(groups):
    counts = collections.Counter(results[n]["verdict"] for n in groups[key])
    line = f"{key[0]:14s} {key[1]:6s} {dict(sorted(counts.items()))}"
    if other:
        oc = collections.Counter(other[n]["verdict"] for n in groups[key])
        line += f"  -> {dict(sorted(oc.items()))}"
    print(line)
print()
for key in sorted(groups):
    for n in groups[key]:
        v = results[n]["verdict"]
        extra = ""
        if other:
            extra = f" -> {other[n]['verdict']}"
        first = ""
        for l in results[n]["pts"].splitlines():
            if "Error" in l:
                first = l
                break
        print(f"{key[0]:14s} {key[1]:6s} {v:8s}{extra:12s} {n}  {first[:90]}")
