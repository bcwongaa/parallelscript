"""Copy the interface-method and object-literal-method families of the H09 matrix into CASES.

Usage: python3 -I select.py ALLCASES CASES
"""
import collections
import json
import os
import shutil
import sys

src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)
meta = json.load(open(os.path.join(src, "cases.json")))
sel = {k: v for k, v in meta.items() if v["definition"] in ("iface_method", "object_method")}
for k in sel:
    shutil.copy(os.path.join(src, k + ".pts"), os.path.join(dst, k + ".pts"))
json.dump(sel, open(os.path.join(dst, "cases.json"), "w"), indent=1, sort_keys=True)
print(len(sel), dict(collections.Counter(v["definition"] for v in sel.values())))
