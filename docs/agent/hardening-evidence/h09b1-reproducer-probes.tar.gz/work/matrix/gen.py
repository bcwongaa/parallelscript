"""H09 matrix generator: generic callables (definition form x use site x result shape) whose
results depend on the call reaching a specialized instance (D-148). One program per case;
each program tries four type arguments (number, string, a class, an array), each in its own
try/catch, so one throw doesn't hide the others.

Usage: python3 -I gen.py OUTDIR
Writes OUTDIR/<case>.pts and OUTDIR/cases.json (case -> {def, use, shape}).
"""
import json
import os
import sys

PRELUDE = """class Box<T> {
  constructor(public value: T) {}
}
class Point {
  constructor(public x: number) {}
}
"""

# Type arguments: (label, TS type, argument, expression of the value v that depends on it).
TYPE_ARGS = [
    ("number", "number", "5", "{v} + 1"),
    ("string", "string", '"ab"', "{v}.length"),
    ("class", "Point", "new Point(3)", "{v}.x + 1"),
    ("array", "number[]", "[1, 2]", "{v}.length + {v}[0]"),
]

# Result shapes: result type R(T), factory body (x: T), how to reach the T value from b.
SHAPES = {
    "box": dict(R="Box<{T}>", body="new Box(x)", value="b.value"),
    "array": dict(R="Box<{T}>[]", body="[new Box(x)]", value="b[0].value"),
    "tuple": dict(R="[Box<{T}>, {T}]", body="[new Box(x), x]", value="b[0].value"),
    "union": dict(R="Box<{T}> | undefined", body="new Box(x)", value="b!.value"),
    "nested": dict(R="Box<Box<{T}>>", body="new Box(new Box(x))", value="b.value.value"),
    "map": dict(R="Map<string, {T}>", body='new Map([["k", x]])', value='b.get("k")!'),
    "mapbox": dict(R="Map<string, Box<{T}>>", body='new Map([["k", new Box(x)]])', value='b.get("k")!.value'),
    "shape": dict(R="{{ value: {T} }}", body="({ value: x })", value="b.value"),
    "promise": dict(R="Promise<Box<{T}>>", body="new Box(x)", value="b.value", is_async=True),
}


def shape_parts(shape):
    s = SHAPES[shape]
    R = lambda t: s["R"].format(T=t)
    a = "async " if s.get("is_async") else ""
    ft = f"<T>(x: T) => {R('T')}"
    arrow = f"{a}<T>(x: T): {R('T')} => ({s['body']})"
    fnexpr = f"{a}function <T>(x: T): {R('T')} {{ return {s['body']}; }}"
    decl = lambda name: f"{a}function {name}<T>(x: T): {R('T')} {{ return {s['body']}; }}"
    method = lambda name, static="": f"{static}{a}{name}<T>(x: T): {R('T')} {{ return {s['body']}; }}"
    return dict(R=R, FT=ft, ARROW=arrow, FNEXPR=fnexpr, decl=decl, method=method, body=s["body"], a=a)


# Definition forms: top-level code, code in the host before the uses, the expression that
# is the generic callable, and the host the uses run in.
def definitions(p):
    R, FT, ARROW, FNEXPR, body, a = p["R"], p["FT"], p["ARROW"], p["FNEXPR"], p["body"], p["a"]
    rt = R("T")
    return {
        "decl_module": dict(top=p["decl"]("mk"), mk="mk"),
        "decl_nested_fn": dict(local=p["decl"]("mk"), mk="mk"),
        "decl_nested_method": dict(local=p["decl"]("mk"), mk="mk", host="method"),
        # PTS1002 by design (namespaces), see smoke.json:         "decl_namespace": dict(top="namespace N {\n  export " + p["decl"]("mk") + "\n}", mk="N.mk"),
        "static_method": dict(top="class K {\n  " + p["method"]("mk", "static ") + "\n}", mk="K.mk"),
        "instance_method_value": dict(top="class C {\n  " + p["method"]("mk") + "\n}", local="const c = new C();", mk="c.mk"),
        "iface_method": dict(top="interface IM {\n  mk<T>(x: T): " + rt + ";\n}\nclass CI implements IM {\n  " + p["method"]("mk") + "\n}",
                             local="const im: IM = new CI();", mk="im.mk"),
        "const_arrow_module": dict(top=f"const mk = {ARROW};", mk="mk"),
        "const_fnexpr_module": dict(top=f"const mk = {FNEXPR};", mk="mk"),
        "let_arrow_module": dict(top=f"let mk = {ARROW};", mk="mk"),
        # PTS1002 by design (var), see smoke.json:         "var_arrow_module": dict(top=f"var mk = {ARROW};", mk="mk"),
        "const_typed_module": dict(top=f"const mk: {FT} = (x) => ({body});" if not a else f"const mk: {FT} = async (x) => ({body});", mk="mk"),
        "const_arrow_local": dict(local=f"const mk = {ARROW};", mk="mk"),
        "let_arrow_local": dict(local=f"let mk = {ARROW};", mk="mk"),
        "const_fnexpr_local": dict(local=f"const mk = {FNEXPR};", mk="mk"),
        "inline_arrow": dict(mk=f"({ARROW})"),
        "inline_fnexpr": dict(mk=f"({FNEXPR})"),
        "factory_returned": dict(top=f"function boxer() {{\n  return {ARROW};\n}}", local="const mk = boxer();", mk="mk"),
        "factory_repeated": dict(top=f"function boxer() {{\n  return {ARROW};\n}}", mk="boxer()"),
        "factory_capture_param": dict(top=f"function boxer(tag: string) {{\n  return {a}<T>(x: T): {rt} => {{\n    if (tag.length > 9) console.log(tag);\n    return {body};\n  }};\n}}",
                                      local='const mk = boxer("t");', mk="mk"),
        "factory_capture_cell": dict(top=f"function boxer() {{\n  let count = 0;\n  return {a}<T>(x: T): {rt} => {{\n    count++;\n    return {body};\n  }};\n}}",
                                     local="const mk = boxer();", mk="mk"),
        "curried": dict(top=f"const outerF = <A>(tag: A) => {ARROW};", local='const mk = outerF("a");', mk="mk"),
        "capture_cell_local": dict(local=f"let count = 0;\nconst mk = {a}<T>(x: T): {rt} => {{\n  count++;\n  return {body};\n}};", mk="mk"),
        "capture_const_local": dict(local=f"const tag = \"t\";\nconst mk = {a}<T>(x: T): {rt} => {{\n  if (tag.length > 9) console.log(tag);\n  return {body};\n}};", mk="mk"),
        "capture_this": dict(top=f"class Th {{\n  tag = 1;\n  maker() {{\n    return {a}<T>(x: T): {rt} => {{\n      this.tag++;\n      return {body};\n    }};\n  }}\n}}",
                             local="const mk = new Th().maker();", mk="mk"),
        "class_field": dict(top=f"class H {{\n  mk = {ARROW};\n}}", local="const h = new H();", mk="h.mk"),
        "static_field": dict(top=f"class SH {{\n  static mk = {ARROW};\n}}", mk="SH.mk"),
        "object_prop": dict(top=f"const o = {{ mk: {ARROW} }};", mk="o.mk"),
        "object_method": dict(top="const o = {\n  " + p["method"]("mk") + "\n};", mk="o.mk"),
        "array_elem": dict(top=f"const fs = [{ARROW}];", mk="fs[0]"),
        "map_value": dict(top=f"const fm = new Map<string, {FT}>([[\"a\", {ARROW}]]);", mk='fm.get("a")!'),
        "iife": dict(top=f"const mk = (() => {ARROW})();", mk="mk"),
        "default_param": dict(host="default", mk="mk"),
        "in_generic_fn": dict(local=f"const mk = {ARROW};", mk="mk", host="generic_fn"),
        "in_generic_method": dict(local=f"const mk = {ARROW};", mk="mk", host="generic_method"),
        "calls_other_generic_local": dict(top=p["decl"]("make"), local=f"const mk = {a}<T>(x: T): {rt} => make(x);", mk="mk"),
        "calls_other_generic_module": dict(top=p["decl"]("make") + f"\nconst mk = {a}<T>(x: T): {rt} => make(x);", mk="mk"),
        "recursive_local": dict(local=f"const rec = {a}<T>(x: T, n: number): {rt} => (n > 0 ? rec(x, n - 1) : {body});\nconst mk = {a}<T>(x: T): {rt} => rec(x, 2);", mk="mk"),
        "decl_value_alias": dict(top=p["decl"]("make"), local="const mk = make;", mk="mk"),
    }


# Use sites: top-level code, code in the host, and the call of the uses (a template with
# {MK} and {ARG}, {A} the type argument), or None where it doesn't apply.
def uses(p, shape):
    R, FT = p["R"], p["FT"]
    return {
        "direct": dict(call="{MK}({ARG})"),
        "explicit": dict(call="{MK}<{A}>({ARG})"),
        "param": dict(top=f"function use(f: {FT}): void {{\n@CASES@\n}}", local="use({MK});", call="f({ARG})", cases_in="top"),
        "var": dict(local=f"const f: {FT} = {{MK}};", call="f({ARG})"),
        "field": dict(top=f"class Holder {{\n  constructor(public f: {FT}) {{}}\n}}", local="const holder = new Holder({MK});", call="holder.f({ARG})"),
        "iface_sig": dict(top=f"interface Maker {{\n  <T>(x: T): {R('T')};\n}}", local="const f: Maker = {MK};", call="f({ARG})"),
        "through_decl": dict(top=f"function through<V>(f: {FT}, v: V): {R('V')} {{\n  return f(v);\n}}", call="through({MK}, {ARG})"),
        "through_value": dict(top=f"function through<V>(f: {FT}, v: V): {R('V')} {{\n  return f(v);\n}}\nfunction run(g: <V>(f: {FT}, v: V) => {R('V')}, f: {FT}): void {{\n@CASES@\n}}",
                              local="run(through, {MK});", call="g(f, {ARG})", cases_in="top"),
        "call": dict(call="{MK}.call(undefined, {ARG})"),
        "apply": dict(call="{MK}.apply(undefined, [{ARG}])"),
        "bind": dict(call="{MK}.bind(undefined)({ARG})"),
        "map_ctx": dict(call="[{ARG}].map({MK})[0]", wraps_array=True),
    }


def cases_code(p, shape, call, mk, indent):
    out = []
    s = SHAPES[shape]
    for label, t, arg, expr in TYPE_ARGS:
        c = call.replace("{MK}", mk).replace("{ARG}", arg).replace("{A}", t)
        rtype = p["R"](t)
        if s.get("is_async"):
            stmt = f"const b: Box<{t}> = await {c};"
        else:
            stmt = f"const b: {rtype} = {c};"
        v = s["value"]
        e = expr.replace("{v}", v)
        out += [
            "try {",
            f"  {stmt}",
            f'  console.log("{label}", {e}, b);',
            "} catch (error: any) {",
            f'  console.log("{label}", error.name, error.message);',
            "}",
        ]
    return "\n".join(indent + line for line in out)


def program(def_name, d, use_name, u, shape, p):
    s = SHAPES[shape]
    is_async = s.get("is_async", False)
    mk = d["mk"]
    host = d.get("host", "fn")
    top = [PRELUDE]
    if d.get("top"):
        top.append(d["top"])
    cases_in_top = u.get("cases_in") == "top"
    if u.get("top"):
        t = u["top"]
        if cases_in_top:
            t = t.replace("@CASES@", cases_code(p, shape, u["call"], mk, "  "))
            if is_async:
                t = t.replace("): void {", "): Promise<void> {").replace("function use(", "async function use(").replace("function run(", "async function run(")
        top.append(t)
    local = []
    if d.get("local"):
        local.append(d["local"])
    if u.get("local"):
        local.append(u["local"].replace("{MK}", mk))
    if is_async and cases_in_top:
        local[-1] = "await " + local[-1]
    if not cases_in_top:
        local.append(cases_code(p, shape, u["call"], mk, ""))
    body = "\n".join(local)
    ind = lambda text, n: "\n".join(("  " * n + line) if line else line for line in text.split("\n"))
    aw = "async " if is_async else ""
    ret = "Promise<void>" if is_async else "void"
    if host == "fn":
        top.append(f"{aw}function main(): {ret} {{\n{ind(body, 1)}\n}}\nmain();")
    elif host == "method":
        top.append(f"class Host {{\n  {aw}run(): {ret} {{\n{ind(body, 2)}\n  }}\n}}\nnew Host().run();")
    elif host == "generic_fn":
        top.append(f"{aw}function main<U>(u: U): {ret} {{\n{ind(body, 1)}\n}}\nmain(1);")
    elif host == "generic_method":
        top.append(f"class GHost<U> {{\n  {aw}run(u: U): {ret} {{\n{ind(body, 2)}\n  }}\n}}\nnew GHost<number>().run(1);")
    elif host == "default":
        top.append(f"{aw}function main(mk: {p['FT']} = {p['ARROW']}): {ret} {{\n{ind(body, 1)}\n}}\nmain();")
    return "\n".join(top) + "\n"


def applicable(def_name, use_name, shape):
    if shape == "promise" and use_name in ("map_ctx", "through_value", "through_decl", "apply", "call", "bind"):
        return False
    return True


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    meta = {}
    full_shapes = ["box"]
    subset_shapes = [s for s in SHAPES if s != "box"]
    subset_defs = ["decl_module", "static_method", "const_arrow_module", "const_arrow_local", "inline_arrow", "factory_returned",
                   "object_method", "class_field", "decl_nested_fn", "iface_method"]
    subset_uses = ["direct", "param", "var", "through_decl"]
    for shape in SHAPES:
        p = shape_parts(shape)
        defs = definitions(p)
        us = uses(p, shape)
        for dn, d in defs.items():
            if shape not in full_shapes and dn not in subset_defs:
                continue
            for un, u in us.items():
                if shape not in full_shapes and un not in subset_uses:
                    continue
                if not applicable(dn, un, shape):
                    continue
                name = f"{shape}__{dn}__{un}"
                with open(os.path.join(out, name + ".pts"), "w") as f:
                    f.write(program(dn, d, un, u, shape, p))
                meta[name] = dict(shape=shape, definition=dn, use=un)
    with open(os.path.join(out, "cases.json"), "w") as f:
        json.dump(meta, f, indent=1, sort_keys=True)
    print(len(meta), "cases")


if __name__ == "__main__":
    main()
