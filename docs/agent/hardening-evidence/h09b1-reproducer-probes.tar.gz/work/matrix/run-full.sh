#!/bin/bash
# run-full.sh: the whole 754-case H09 matrix on HEAD's CLI, then on the prototype CLI, 2 jobs each.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a7e1d288759a50a05
M=/tmp/h09b1-repro/work/matrix
cd "$M" || exit 2
PTS_HOME=$W python3 -I run.py "$M/all-cases" "$M/results-full-head.json" 2 > "$M/run-full-head.log" 2>&1
echo "exit=$?" >> "$M/run-full-head.log"
PTS_CACHE_DIR=/tmp/h09b1-repro/cache-proto PTS_CLI=/tmp/h09b1-repro/pts-proto PTS_HOME=$W python3 -I run.py "$M/all-cases" "$M/results-full-proto.json" 2 > "$M/run-full-proto.log" 2>&1
echo "exit=$?" >> "$M/run-full-proto.log"
