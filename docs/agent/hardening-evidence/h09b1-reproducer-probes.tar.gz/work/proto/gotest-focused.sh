#!/bin/bash
# gotest-focused.sh TREE LOG: the parent's focused run tests (TestRun, TestRunMatchesNode on
# generic*, dispatched*, interface*, object_literal*), 2 parallel subtests, in TREE.
tree=$1; log=$2
cd "$tree" || exit 2
PTS_CACHE_DIR=/tmp/h09b1-repro/cache-gotest GOMAXPROCS=2 PTS_REQUIRE_NODE=1 \
  go test -count=1 -parallel 2 -timeout 40m \
  -run '^(TestRun|TestRunMatchesNode)$/^(generic.*|dispatched.*|interface.*|object_literal.*)$' \
  ./pts/tests/ -v > "$log" 2>&1
echo "exit=$?" >> "$log"
