#!/bin/bash
# gotest-broad.sh TREE LOG: TestRun, TestRunMatchesNode, TestCorpusMatchesNode and
# TestCompilerFailsCleanly over everything, 2 parallel subtests, in TREE.
tree=$1; log=$2
cd "$tree" || exit 2
PTS_CACHE_DIR=/tmp/h09b1-repro/cache-gotest GOMAXPROCS=2 PTS_REQUIRE_NODE=1 PTS_SMOKE_JOBS=2 \
  go test -count=1 -parallel 2 -timeout 60m \
  -run '^(TestRun|TestRunMatchesNode|TestCorpusMatchesNode|TestCompilerFailsCleanly)$' \
  ./pts/tests/ -v > "$log" 2>&1
echo "exit=$?" >> "$log"
