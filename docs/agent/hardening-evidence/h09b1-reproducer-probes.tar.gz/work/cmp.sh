#!/bin/bash
# cmp.sh PTS_HOME file.pts...: build and run each program with that tree's CLI (or $PTS_CLI)
# and with Node v24 (a strict-ESM .mts copy, --no-warnings --experimental-transform-types,
# as pts/tests/run_test.go does), print both outputs with exit codes and whether they match.
set -uo pipefail
home=$1; shift
node=$HOME/.local/node/bin/node; cli=${PTS_CLI:-$home/pts-bin/pts}
mkdir -p /tmp/h09b1-repro/work/tmp
for f0 in "$@"; do f=$(realpath "$f0")
  b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09b1-repro/work/tmp/cmp.XXXX)
  cp "$f" "$d/$b.mts"
  pts_out=$(cd "$d" && TZ=America/New_York PTS_HOME=$home timeout 180 "$cli" run "$f" 2>&1; echo "[exit $?]")
  node_out=$(cd "$d" && TZ=America/New_York timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  if [ "$pts_out" == "$node_out" ]; then echo "== $b: MATCH"; else echo "== $b: DIFFER"; fi
  echo "-- pts"; echo "$pts_out"; echo "-- node"; echo "$node_out"
  rm -rf "$d"
done
