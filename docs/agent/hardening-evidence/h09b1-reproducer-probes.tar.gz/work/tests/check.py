"""Check proposed run tests: Node's output must equal each test's `// expect:` block (except
for no-diff tests, where it is reported), and PTS's output is compared with it too.

Usage: python3 -I check.py [--pts CLI] [--home PTS_HOME] test.pts...
Prints, per test: node=MATCH|DIFFER (or no-diff) and pts=PASS|FAIL with a diff summary.
"""
import argparse
import difflib
import os
import shutil
import subprocess
import tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")


def expected(path):
    lines, inside = [], False
    for line in open(path).read().splitlines():
        if line == "// expect:":
            inside = True
            continue
        if inside:
            if not line.startswith("//"):
                break
            lines.append(line[3:] if line.startswith("// ") else line[2:])
    return "\n".join(lines) + "\n"


def run(cmd, cwd, env):
    r = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=180)
    return r.returncode, r.stdout, r.stderr


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts")
    ap.add_argument("--home")
    ap.add_argument("tests", nargs="+")
    args = ap.parse_args()
    for path in args.tests:
        path = os.path.abspath(path)
        name = os.path.basename(path)[:-4]
        want = expected(path)
        no_diff = open(path).read().startswith("// no-diff:")
        d = tempfile.mkdtemp(prefix="h09t.", dir="/tmp/h09b1-repro/work/tmp")
        try:
            shutil.copy(path, os.path.join(d, name + ".mts"))
            env = dict(os.environ, TZ="America/New_York")
            ncode, nout, nerr = run([NODE, "--no-warnings", "--experimental-transform-types", name + ".mts"], d, env)
            status = "no-diff" if no_diff else ("MATCH" if nout == want and ncode == 0 else "DIFFER")
            print(f"== {name}: node={status} (exit {ncode})")
            if status == "DIFFER" or (no_diff and nout != want):
                print("".join(difflib.unified_diff(want.splitlines(True), nout.splitlines(True), "expect", "node")), nerr[-500:])
            if args.pts:
                env["PTS_HOME"] = args.home
                pcode, pout, perr = run([args.pts, "run", path], d, env)
                ok = pout == want and pcode == 0
                print(f"   pts={'PASS' if ok else 'FAIL'} (exit {pcode})")
                if not ok:
                    print("".join(difflib.unified_diff(want.splitlines(True), (pout + perr).splitlines(True), "expect", "pts")))
        finally:
            shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    main()
