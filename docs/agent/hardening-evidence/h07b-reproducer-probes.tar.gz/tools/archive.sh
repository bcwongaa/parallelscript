#!/bin/bash
# Archive H07b reproducer evidence (no binaries) into /tmp/h07b/repro/h07b-reproducer-probes.tar.gz.
set -eu
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ac2576d660f32ee23
R=/tmp/h07b/repro
rm -rf "$R/archive"
mkdir -p "$R/archive/worktree/pts/tests/run" "$R/archive/worktree/docs/agent/hardening-evidence/probes"
cp "$W"/pts/tests/run/abort_signal_shared_threads.pts "$W"/pts/tests/run/abort_signal_any_cost.pts \
   "$W"/pts/tests/run/abort_signal_any_dependents.pts "$W"/pts/tests/run/fetch_abort_other_thread.pts \
   "$R/archive/worktree/pts/tests/run/"
cp -r "$W/docs/agent/hardening-evidence/probes/h07b" "$R/archive/worktree/docs/agent/hardening-evidence/probes/"
cp -r "$R/probes" "$R/oracles" "$R/c119" "$R/c121" "$R/retention" "$R/tools" "$R/logs" "$R/archive/"
cp "$R/cmds.txt" "$R/archive/"
cd "$R/archive"
tar --exclude='*.o' -czf "$R/h07b-reproducer-probes.tar.gz" .
sha256sum "$R/h07b-reproducer-probes.tar.gz"
tar -tzf "$R/h07b-reproducer-probes.tar.gz" | wc -l
