// H07b C116 probe: one AbortSignal (and one EventTarget) shared by threads, facets a-g.
// Each section prints a tally; the expected line is what Node prints for the program run
// sequentially (`.par.map` as `map`, `parallel e` as `Promise.resolve(e)`).
// threads: 1 2 4
function range(start: number, end?: number): number[] & { toArray(): number[] } {
  if (end === undefined) {
    end = start;
    start = 0;
  }
  const items = Array.from({ length: end - start }, (_, i) => start + i) as number[] & { toArray(): number[] };
  items.toArray = () => [...items];
  return items;
}
class AtomicInt {
  #value: number;
  constructor(value = 0) {
    this.#value = value;
  }
  add(delta: number): number {
    const old = this.#value;
    this.#value += delta;
    return old;
  }
  load(): number {
    return this.#value;
  }
  store(value: number): void {
    this.#value = value;
  }
}

const COUNT = 10_000; // followers: O(1) each once fixed
const LISTENERS = 3_000; // the program's own listeners: addEventListener scans for duplicates, in Node too
const ROUNDS = 1_000;

function failure(error: unknown): string {
  return error instanceof Error ? `${error.name}: ${error.message.split(";")[0]}` : "non-Error thrown";
}

// How many times each outcome occurs, outcomes sorted.
function tally(outcomes: string[]): string {
  const counts = new Map<string, number>();
  for (const outcome of outcomes) {
    counts.set(outcome, (counts.get(outcome) ?? 0) + 1);
  }
  return [...counts.keys()].sort().map((outcome) => `${outcome} ${counts.get(outcome)}`).join(", ");
}

function calls(counts: number[]): string {
  return tally(counts.map((n) => `called ${n}`));
}

// A follower of source, or what making it threw.
function follow(source: AbortSignal): AbortSignal | string {
  try {
    return AbortSignal.any([source]);
  } catch (error) {
    return failure(error);
  }
}

function judge(followers: (AbortSignal | string)[], reason: string): string {
  return tally(followers.map((f) => (typeof f === "string" ? f : f.aborted && f.reason === reason ? "aborted" : "not aborted")));
}

// Waits (boundedly: one thread runs the pieces in turn) until `count` threads have arrived.
function rendezvous(arrived: AtomicInt, count: int): void {
  arrived.add(1);
  for (let spin = 0; spin < 20_000 && arrived.load() < count; spin++) {}
}

// a1. parallel for
{
  const shared = new AbortController();
  const followers = new Array<AbortSignal | string>(COUNT).fill("unset");
  for (const i of range(0, COUNT)) {
    followers[i] = follow(shared.signal);
  }
  try {
    shared.abort("stop");
    console.log("a1 parallel for:", judge(followers, "stop"));
  } catch (error) {
    console.log("a1 parallel for: abort threw", failure(error));
  }
}

// a2. parallel tasks
{
  const shared = new AbortController();
  const many = (count: number): (AbortSignal | string)[] => {
    const made: (AbortSignal | string)[] = [];
    for (let i = 0; i < count; i++) {
      made.push(follow(shared.signal));
    }
    return made;
  };
  const parts = await Promise.all([0, 1, 2, 3].map(() => Promise.resolve(many(COUNT / 4))));
  try {
    shared.abort("stop");
    console.log("a2 parallel tasks:", judge(parts.flat(), "stop"));
  } catch (error) {
    console.log("a2 parallel tasks: abort threw", failure(error));
  }
}

// b. followers made on many threads while one of them aborts the source, half-way through
{
  const shared = new AbortController();
  const made = new AtomicInt(0);
  const followers = range(0, COUNT).map((i): AbortSignal | string => {
    if (made.add(1) === COUNT / 2) {
      try {
        shared.abort("stop");
      } catch (error) {
        return `abort threw ${failure(error)}`;
      }
    }
    return follow(shared.signal);
  });
  console.log("b any while aborting:", judge(followers, "stop"));
}

// c. the program's own listeners on one shared signal, added from many threads
{
  const shared = new AbortController();
  const counts = new Array<number>(LISTENERS).fill(0);
  const added = range(0, LISTENERS).map((i) => {
    try {
      shared.signal.addEventListener("abort", () => {
        counts[i]++;
      });
      return "added";
    } catch (error) {
      return failure(error);
    }
  });
  let threw = "";
  try {
    shared.abort();
  } catch (error) {
    threw = ` | abort threw ${failure(error)}`;
  }
  console.log(`c listeners: ${tally(added)} | ${calls(counts)}${threw}`);
}

// d. one controller aborted from two threads at once, many rounds
{
  let wrong = 0;
  const thrown: string[] = [];
  for (let round = 0; round < ROUNDS; round++) {
    const controller = new AbortController();
    const events = new AtomicInt(0);
    const first = new AtomicInt(0);
    const second = new AtomicInt(0);
    controller.signal.onabort = () => events.add(1);
    controller.signal.addEventListener("abort", () => first.add(1));
    controller.signal.addEventListener("abort", () => second.add(1), { once: true });
    const arrived = new AtomicInt(0);
    const outcomes = range(0, 2).map((t) => {
      rendezvous(arrived, 2);
      try {
        controller.abort(`r${t}`);
        return "ok";
      } catch (error) {
        return failure(error);
      }
    });
    const reason: unknown = controller.signal.reason;
    if (events.load() !== 1 || first.load() !== 1 || second.load() !== 1 || (reason !== "r0" && reason !== "r1")) {
      wrong++;
    }
    thrown.push(...outcomes.filter((o) => o !== "ok"));
  }
  console.log(`d concurrent abort: rounds ${ROUNDS}, wrong ${wrong}${thrown.length === 0 ? "" : `, threw ${tally(thrown)}`}`);
}

// e. removeEventListener racing adds of other listeners
{
  const shared = new AbortController();
  const half = LISTENERS / 2;
  const removedCalls = new Array<number>(half).fill(0);
  const addedCalls = new Array<number>(half).fill(0);
  const removable: ((event: Event) => void)[] = [];
  for (let k = 0; k < half; k++) {
    const listener = (event: Event): void => {
      removedCalls[k]++;
    };
    removable.push(listener);
    shared.signal.addEventListener("abort", listener);
  }
  const outcomes = range(0, LISTENERS).map((i) => {
    try {
      const k = Math.floor(i / 2);
      if (i % 2 === 0) {
        shared.signal.removeEventListener("abort", removable[k]);
      } else {
        shared.signal.addEventListener("abort", () => {
          addedCalls[k]++;
        });
      }
      return "ok";
    } catch (error) {
      return failure(error);
    }
  });
  let threw = "";
  try {
    shared.abort();
  } catch (error) {
    threw = ` | abort threw ${failure(error)}`;
  }
  console.log(`e remove vs add: ${tally(outcomes)} | removed ${calls(removedCalls)} | added ${calls(addedCalls)}${threw}`);
}

// f. addEventListener(type, l, { signal }) on targets of their own while the signal aborts on another thread
{
  const shared = new AbortController();
  const targets = range(0, COUNT).toArray().map(() => new EventTarget());
  const counts = new Array<number>(COUNT).fill(0);
  const started = new AtomicInt(0);
  const outcomes = range(0, COUNT).map((i) => {
    try {
      if (started.add(1) === COUNT / 2) {
        shared.abort();
      }
      targets[i].addEventListener("ping", () => {
        counts[i]++;
      }, { signal: shared.signal });
      return "ok";
    } catch (error) {
      return failure(error);
    }
  });
  for (const target of targets) {
    target.dispatchEvent(new Event("ping"));
  }
  console.log(`f signal option: ${tally(outcomes)} | ${calls(counts)}`);
}

// g. one shared EventTarget with a once listener, dispatched from two threads at once
{
  let wrong = 0;
  const thrown: string[] = [];
  for (let round = 0; round < ROUNDS; round++) {
    const target = new EventTarget();
    const once = new AtomicInt(0);
    const always = new AtomicInt(0);
    target.addEventListener("ping", () => once.add(1), { once: true });
    target.addEventListener("ping", () => always.add(1));
    const arrived = new AtomicInt(0);
    const outcomes = range(0, 2).map(() => {
      rendezvous(arrived, 2);
      try {
        target.dispatchEvent(new Event("ping"));
        return "ok";
      } catch (error) {
        return failure(error);
      }
    });
    if (once.load() !== 1 || always.load() !== 2) {
      wrong++;
    }
    thrown.push(...outcomes.filter((o) => o !== "ok"));
  }
  console.log(`g once from threads: rounds ${ROUNDS}, wrong ${wrong}${thrown.length === 0 ? "" : `, threw ${tally(thrown)}`}`);
}
