#!/bin/bash
# run.sh variant: only the given bins, no node; appends to file.f2out
f=$1; shift
d=$(dirname $f); b=$(basename $f .pts)
out=$d/$b.f2out
: > $out
for bin in "$@"; do
  echo "== $bin" >> $out
  ( cd $d && PTS_HOME=/home/bryan/projects/parallelscript timeout 300 /tmp/h09b5d/pts-$bin run $b.pts ) >> $out 2>&1
  echo "[exit $?]" >> $out
  rm -f $d/$b 2>/dev/null
done
