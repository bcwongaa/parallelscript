#!/bin/bash
# count.sh TEST FN... : builds TEST from the snapshot's run tests with base and new CLIs and
# prints how often the functions FN (erased copies) run in each, via gdb hit counts.
t=$1; shift
cp /tmp/h09b3/snap2r/pts/tests/run/$t.pts .
PTS_HOME=/tmp/h09b3/base /tmp/h09b3/pts-head build $t.pts -o base_$t >/dev/null 2>&1 || echo "base build failed"
PTS_HOME=/tmp/h09b3/snap2r /tmp/h09b3/snap2r/pts-bin/pts build $t.pts -o new_$t >/dev/null 2>&1 || echo "new build failed"
for b in base new; do
  echo "== $b $t"
  {
    echo "set pagination off"
    echo "set breakpoint pending on"
    for fn in "$@"; do echo "break $fn"; done
    echo "python"
    echo "import gdb"
    echo "for bp in gdb.breakpoints():"
    echo "    bp.silent = True"
    echo "    bp.commands = 'continue'"
    echo "end"
    echo "run > /dev/null"
    echo "python"
    echo "for bp in gdb.breakpoints():"
    echo "    print('HIT', bp.location, bp.hit_count)"
    echo "end"
  } > cmds_$b.gdb
  gdb -q -batch -x cmds_$b.gdb ./${b}_$t 2>&1 | grep "^HIT"
done
