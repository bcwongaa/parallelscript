#!/bin/bash
# emit_new2.sh: emit-c with round 2's CLI for snap2r's run tests, then the other test dirs and examples.
CLI=/tmp/h09b3/snap2r/pts-bin/pts; HOME_=/tmp/h09b3/snap2r
cd /tmp/h09b3/snap2r/pts/tests/run
for f in *.pts; do b=${f%.pts}; PTS_HOME=$HOME_ timeout 120 $CLI emit-c $f > /tmp/h09b3/review2/emit/new/$b.c 2> /tmp/h09b3/review2/emit/new/$b.err; echo "$b $?" >> /tmp/h09b3/review2/emit/new/exits.txt; done
cd /tmp/h09b3/snap2r
for f in $(find pts/tests/corpus pts/tests/stress pts/tests/errors pts/tests/http examples -name "*.pts" | sort); do
  b=$(echo $f | tr '/' '_'); (cd $(dirname $f) && PTS_HOME=$HOME_ timeout 120 $CLI emit-c $(basename $f) > /tmp/h09b3/review2/emit2/new/$b.c 2> /tmp/h09b3/review2/emit2/new/$b.err); echo "$b $?" >> /tmp/h09b3/review2/emit2/new/exits.txt
done
touch /tmp/h09b3/review2/emit/DONE
