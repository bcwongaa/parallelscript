# split.py FILE.pts OUTDIR: one file per top-level `attempt(` statement (single- or multi-line,
# a multi-line one ending at a line `});`), the rest of the program kept.
import sys, os
src = open(sys.argv[1]).read().split("\n")
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
base = os.path.basename(sys.argv[1])[:-4]
blocks, i = [], 0
while i < len(src):
    if src[i].startswith("attempt("):
        j = i
        if not src[i].rstrip().endswith(");"):
            while not src[j].startswith("});"):
                j += 1
        blocks.append((i, j))
        i = j + 1
    else:
        i += 1
inblock = lambda k: any(a <= k <= b for a, b in blocks)
for n, (a, b) in enumerate(blocks):
    keep = [l for k, l in enumerate(src) if (a <= k <= b) or not inblock(k)]
    open(os.path.join(out, f"{base}_{n:02d}.pts"), "w").write("\n".join(keep))
print(len(blocks))
