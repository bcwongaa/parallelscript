#!/bin/bash
# rerun_r1.sh: runs every round-1 probe with round 2's CLI and Node (no base), into out/r1rerun.txt.
cd /tmp/h09b3/review1/p
for f in $(cat /tmp/h09b3/review2/r1probes/list.txt); do
  NO_BASE=1 /tmp/h09b3/review2/tools/tri.sh $f
done > /tmp/h09b3/review2/out/r1rerun.txt 2>&1
# multi-file probe dirs
for d in r05; do
  for f in /tmp/h09b3/review1/p/$d/*.pts; do NO_BASE=1 /tmp/h09b3/review2/tools/tri.sh $f; done
done >> /tmp/h09b3/review2/out/r1rerun.txt 2>&1
touch /tmp/h09b3/review2/out/r1rerun.DONE
