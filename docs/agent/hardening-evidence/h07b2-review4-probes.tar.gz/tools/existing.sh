#!/bin/bash
# existing.sh <which> <src.pts> <reps>: builds a repo run test and checks stdout (expect block or .out, else Node's) and exit code at each `// threads:` value
which=$1; src=$2; reps=$3; name=$(basename $src .pts); dir=$(dirname $src)
if [ "$which" = fix ]; then home=/home/bryan/projects/parallelscript; else home=/tmp/h07b2/base; fi
bin=/tmp/h07b2/review4/existing/$which.$name
( cd $dir && PTS_HOME=$home $home/pts-bin/pts build $src -o $bin >/tmp/h07b2/review4/existing/$which.$name.build 2>&1 ) || { echo "$name: BUILD FAILED"; exit; }
exp=/tmp/h07b2/review4/existing/$name.expect
if grep -q "^// expect:" $src; then awk '/^\/\/ expect:/{on=1;next} on && /^\/\/( |$)/{sub(/^\/\/ ?/,""); print; next} on{exit}' $src > $exp
elif [ -f $dir/$name.out ]; then cp $dir/$name.out $exp
else cp $src /tmp/h07b2/review4/existing/$name.mts; (cd /tmp/h07b2/review4/existing && timeout 60 ~/.local/node/bin/node --no-warnings $name.mts > $exp 2>/dev/null); fi
code=$(sed -n 's|^// exit: *\([0-9]*\).*|\1|p' $src | head -1); code=${code:-0}
threads=$(sed -n 's|^// threads: *||p' $src | head -1); threads=${threads:-default}
res=""
for t in $threads; do bad=0; for r in $(seq 1 $reps); do
  if [ $t = default ]; then (cd $dir && timeout 60 $bin > $bin.out 2>$bin.err); c=$?; else (cd $dir && PTS_THREADS=$t timeout 60 $bin > $bin.out 2>$bin.err); c=$?; fi
  if ! diff -q $exp $bin.out >/dev/null || [ $c != $code ]; then bad=$((bad+1)); cp $bin.out $bin.t$t.r$r.bad; fi
done; res="$res t$t:$bad/$reps"; done
echo "$name:$res"
