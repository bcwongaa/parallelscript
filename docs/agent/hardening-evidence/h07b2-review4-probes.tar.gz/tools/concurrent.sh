#!/bin/bash
# concurrent.sh <name> <threads> <copies> <rounds>: runs copies at once, rounds times; reports runs whose stdout differs from the expect block
name=$1; t=$2; c=$3; rounds=$4
src=/tmp/h07b2/review4/probes/$name.pts
exp=$(mktemp); awk '/^\/\/ expect:/{on=1;next} on && /^\/\/ ?/{sub(/^\/\/ ?/,""); print}' "$src" > "$exp"
bad=0
for r in $(seq 1 $rounds); do
  for i in $(seq 1 $c); do PTS_THREADS=$t timeout 60 /tmp/h07b2/review4/bin/fix/$name > /tmp/h07b2/review4/out/conc.$name.$t.$i.out 2>&1 & done; wait
  for i in $(seq 1 $c); do if ! diff -q $exp /tmp/h07b2/review4/out/conc.$name.$t.$i.out >/dev/null; then bad=$((bad+1)); echo "  bad round $r copy $i:"; diff $exp /tmp/h07b2/review4/out/conc.$name.$t.$i.out | head -6 | sed 's/^/    /'; fi; done
done
echo "$name t$t x$c concurrent, $rounds rounds: $bad bad"
rm -f $exp
