#!/bin/bash
# contended.sh <name> <threads> <copies> <burners> <rounds>: runs copies plus CPU burners all pinned to CPUs 6-7
name=$1; t=$2; c=$3; b=$4; rounds=$5
src=/tmp/h07b2/review4/probes/$name.pts
exp=$(mktemp); awk '/^\/\/ expect:/{on=1;next} on && /^\/\/ ?/{sub(/^\/\/ ?/,""); print}' "$src" > "$exp"
bad=0
for r in $(seq 1 $rounds); do
  pids=""; for i in $(seq 1 $b); do taskset -c 6,7 timeout 30 sh -c 'while :; do :; done' & pids="$pids $!"; done
  for i in $(seq 1 $c); do PTS_THREADS=$t taskset -c 6,7 timeout 60 /tmp/h07b2/review4/bin/fix/$name > /tmp/h07b2/review4/out/cont.$name.$i.out 2>&1 & cp="$cp $!"; done
  for p in $cp; do wait $p; done; cp=""
  kill $pids 2>/dev/null; wait 2>/dev/null
  for i in $(seq 1 $c); do if ! diff -q $exp /tmp/h07b2/review4/out/cont.$name.$i.out >/dev/null; then bad=$((bad+1)); echo "  bad round $r copy $i:"; diff $exp /tmp/h07b2/review4/out/cont.$name.$i.out | head -6 | sed 's/^/    /'; fi; done
done
echo "$name t$t x$c with $b burners on 2 CPUs, $rounds rounds: $bad bad"
rm -f $exp
