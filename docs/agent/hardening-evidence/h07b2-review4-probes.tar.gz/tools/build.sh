#!/bin/bash
# build.sh <fix|base> <src.pts> : builds into /tmp/h07b2/review4/bin/<which>/<name>
which=$1; src=$2; name=$(basename "$src" .pts)
if [ "$which" = fix ]; then home=/home/bryan/projects/parallelscript; else home=/tmp/h07b2/base; fi
cd /tmp/h07b2/review4/bin/$which && PTS_HOME=$home $home/pts-bin/pts build "$src" -o /tmp/h07b2/review4/bin/$which/$name 2>&1 | tail -5
