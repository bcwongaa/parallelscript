package driver_test

import (
	"os"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

// Review round 3 (read-only overlay): how the shared lowering handles d01/d06 at each
// fallback, with and without narrowing.
func TestReview3SharedFallbacks(t *testing.T) {
	for _, entry := range []string{os.Getenv("R3_D01"), os.Getenv("R3_D06")} {
		for _, s := range lower.Fallbacks {
			_, err := driver.EmitCWith(t.Context(), entry, s)
			t.Logf("%s spec=%d plain err=%v", entry, s, err)
			_, err = driver.EmitCNarrowedWith(t.Context(), entry, s)
			t.Logf("%s spec=%d narrowed err=%v", entry, s, err)
		}
	}
}
