#!/usr/bin/env python3
"""emitc_sweep.py OUT.json BASE_CLI BASE_HOME NEW_CLI NEW_HOME [--jobs N]: emit C for every
pts/tests/run, stress, corpus and docs/examples program of the main tree with both CLIs and
record which programs' C differs (after dropping #line paths) or fails with one of them."""
import concurrent.futures as cf, glob, json, os, re, subprocess, sys, tempfile

ROOT = "/home/bryan/projects/parallelscript"
out, base, new = sys.argv[1], (sys.argv[2], sys.argv[3]), (sys.argv[4], sys.argv[5])
jobs = int(sys.argv[sys.argv.index("--jobs") + 1]) if "--jobs" in sys.argv else 4
files = sorted(glob.glob(f"{ROOT}/pts/tests/run/*.pts") + glob.glob(f"{ROOT}/pts/tests/stress/*.pts") +
               glob.glob(f"{ROOT}/pts/tests/corpus/*/*.pts") + glob.glob(f"{ROOT}/docs/examples/*.pts"))


def emit(cli, path):
    exe, home = cli
    with tempfile.NamedTemporaryFile(suffix=".c", dir="/tmp/h12/review3b/sweepwork", delete=False) as f:
        target = f.name
    try:
        try:
            p = subprocess.run([exe, "emit-c", os.path.basename(path), "-o", target], cwd=os.path.dirname(path), capture_output=True,
                               timeout=120, env=dict(os.environ, PTS_HOME=home))
        except subprocess.TimeoutExpired:
            return 124, "", "timeout"
        text = open(target).read() if p.returncode == 0 else ""
        return p.returncode, re.sub(r'#line (\d+) "[^"]*"', r"#line \1", text), p.stderr.decode()[:400]
    finally:
        os.unlink(target)


def one(path):
    b, n = emit(base, path), emit(new, path)
    return dict(file=os.path.relpath(path, ROOT), base_rc=b[0], new_rc=n[0], same=b[1] == n[1] and b[0] == n[0],
                base_err=b[2] if b[0] else "", new_err=n[2] if n[0] else "")


with cf.ThreadPoolExecutor(jobs) as ex:
    results = list(ex.map(one, files))
json.dump(results, open(out, "w"), indent=1)
changed = [r for r in results if not r["same"]]
print(len(results), "programs;", len(changed), "with different C or result")
for r in changed:
    print(f"  {r['file']} base rc={r['base_rc']} new rc={r['new_rc']} {r['new_err'][:160]}")
