#!/bin/bash
# Reruns round 3's finding probes against Node, base, snap3 and snap4 (tools/run.py), 1 worker.
cd /tmp/h12/review3b
P=p
S2=1 W=3 python3 tools/run.py rerun-findings.json \
  $P/x/x01_or_fallback_elem.pts $P/x/x03_and_elem.pts $P/x/x04_init_or_fallback.pts $P/x/x08_comma_elem.pts \
  $P/x/x15_or_assign_or.pts $P/x/x16_number_or.pts $P/x/x20_loose_and_left.pts $P/x/x21_loose_and_left_init.pts \
  $P/x/x22_elem_or_param.pts $P/x/x24_elem_or_generic.pts $P/x/x25_elem_or_record.pts \
  $P/pr/pr02_return_or.pts $P/pr/pr03_generator_or.pts $P/pr/pr04_try_finally_or.pts $P/pr/pr05_foreach_param.pts $P/d/d02_05.pts \
  $P/lead/g20_generic_dep_from_module.pts $P/lead/g24_generic_dep_order.pts $P/g/g30_generic_method_module.pts $P/g/g32_generic_module_read_first.pts $P/g/g34_generic_tested.pts $P/g/g35_generic_module_var_read.pts $P/g/g36_generic_tested_alone.pts \
  $P/d/d03_shorthand_default_tested.pts $P/m/mod3 $P/m/mod6 $P/lead/f06_reduced.pts
