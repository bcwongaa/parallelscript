#!/usr/bin/env python3
# usage: expect.py BUILD[,BUILD...] test.pts... — runs each test with each build (CLI dir /tmp/h12/<b> or a path to a dir with pts-bin/pts; PTS_HOME from env RT or that dir) and Node, compares with its `// expect:` block
import sys, subprocess, tempfile, shutil, os, re
builds = sys.argv[1].split(",")
for path in sys.argv[2:]:
    src = open(path).read()
    m = re.search(r"^// expect:\n((?://.*\n?)*)", src, re.M)
    want = "".join(l[3:] + "\n" if l.startswith("// ") else "\n" for l in m.group(1).rstrip("\n").split("\n")) if m else None
    d = tempfile.mkdtemp(dir="/tmp/h12/review3b/work")
    shutil.copy(path, os.path.join(d, "p.pts")); shutil.copy(path, os.path.join(d, "p.mts"))
    res = []
    r = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=60)
    res.append(("node", r.returncode, r.stdout == want))
    for b in builds:
        cli = (b if b.startswith("/") else "/tmp/h12/" + b) + "/pts-bin/pts"
        home = os.environ.get("RT") if b.startswith("/") else "/tmp/h12/" + b
        try:
            r = subprocess.run([cli, "run", "p.pts"], cwd=d, capture_output=True, text=True, timeout=int(os.environ.get("T", "120")), env=dict(os.environ, PTS_HOME=home))
            res.append((os.path.basename(b), r.returncode, r.stdout == want, (r.stdout + r.stderr)[-300:].replace(d, "<d>")))
        except subprocess.TimeoutExpired:
            res.append((os.path.basename(b), 124, False, "TIMEOUT"))
    shutil.rmtree(d, ignore_errors=True)
    print(os.path.basename(path), " ".join(f"{x[0]}:{'PASS' if x[2] else 'FAIL'}(rc{x[1]})" for x in res))
    for x in res[1:]:
        if not x[2] and os.environ.get("V"): print("   ", x[0], repr(x[3]))
