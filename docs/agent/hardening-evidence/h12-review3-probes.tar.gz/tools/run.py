#!/usr/bin/env python3
# usage: run.py OUT.json probe.pts...  — node (.mts copy), base, snap3, snap4 (and snap2 if S2=1) per probe; W workers (default 3)
# A probe dir (containing main.pts) is copied whole; node runs main.mts copies of every .pts.
import sys, json, subprocess, tempfile, shutil, os, concurrent.futures, glob, re
CLIS = {"base": ("/tmp/h12/base/pts-bin/pts", "/tmp/h12/base")}
if os.environ.get("S2"): CLIS["snap2"] = ("/tmp/h12/snap2/pts-bin/pts", "/tmp/h12/snap2")
CLIS["snap3"] = ("/tmp/h12/snap3/pts-bin/pts", "/tmp/h12/snap3")
CLIS["snap4"] = ("/tmp/h12/snap4/pts-bin/pts", "/tmp/h12/snap4")
NODE = "/home/bryan/.local/node/bin/node"
def prep(path, d):
    if os.path.isdir(path):
        shutil.rmtree(d); shutil.copytree(path, d)
        for f in glob.glob(os.path.join(d, "**", "*.pts"), recursive=True):
            src = open(f).read()
            open(f[:-4] + ".mts", "w").write(re.sub(r'from "(\.{1,2}/[^"]+)\.pts"', r'from "\1.mts"', src))
        return "main"
    shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
    return "p"
def run(path):
    d = tempfile.mkdtemp(dir="/tmp/h12/review3b/work")
    try:
        main = prep(path, d)
        res = {}
        try:
            r = subprocess.run([NODE, "--experimental-transform-types", "--no-warnings", main + ".mts"], cwd=d, capture_output=True, text=True, timeout=30)
            res["node"] = (r.returncode, r.stdout + r.stderr)
        except subprocess.TimeoutExpired:
            res["node"] = (124, "")
        for name, (cli, home) in CLIS.items():
            try:
                r = subprocess.run([cli, "run", main + ".pts"], cwd=d, capture_output=True, text=True, timeout=int(os.environ.get("T", "120")), env=dict(os.environ, PTS_HOME=home))
                res[name] = (r.returncode, (r.stdout + r.stderr).replace(d, "<d>"))
            except subprocess.TimeoutExpired:
                res[name] = (124, "TIMEOUT")
        return path, res
    finally:
        shutil.rmtree(d, ignore_errors=True)
out = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "3"))) as ex:
    for path, res in ex.map(run, sys.argv[2:]):
        out[path] = res
        n = res["node"]
        tag = lambda k: "=" if res[k] == n else ("x%d" % res[k][0])
        print(f"{os.path.basename(path.rstrip('/')):45s} " + " ".join(f"{k}{tag(k):5s}" for k in CLIS) + ("   <-- snap4 differs from snap3" if res['snap4'] != res['snap3'] else ""), flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1)
