"""Replay retained probes with the checkpoint/final CLI and strict-ESM Node twins."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import signal
import subprocess
import time


def command(argv, env, timeout=180):
    start = time.monotonic()
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=env, start_new_session=True)
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        stdout, stderr = proc.communicate()
        return dict(argv=argv, exit='timeout', stdout=stdout.decode(errors='replace'),
                    stderr=stderr.decode(errors='replace'), seconds=time.monotonic()-start)
    return dict(argv=argv, exit=proc.returncode, stdout=stdout.decode(errors='replace'),
                stderr=stderr.decode(errors='replace'), seconds=time.monotonic()-start)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('probe_root', type=Path)
    parser.add_argument('out', type=Path)
    parser.add_argument('--compiler', action='append', nargs=3, metavar=('LABEL', 'CLI', 'HOME'), default=[])
    parser.add_argument('--node', default='/home/bryan/.local/node/bin/node')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, GOMAXPROCS='2')

    def probe(source):
        name = source.relative_to(args.probe_root).with_suffix('')
        dest = args.out / name
        dest.mkdir(parents=True)
        twin = dest / 'main.mts'
        twin.write_bytes(source.read_bytes())
        results = {'node': command([args.node, '--no-warnings', '--experimental-transform-types', str(twin)], env)}
        for label, cli, home in args.compiler:
            binary = dest / (label + '.bin')
            result = command([cli, 'build', str(source), '-o', str(binary)], dict(env, PTS_HOME=home))
            results[label + '_build'] = result
            if result['exit'] == 0:
                results[label] = command([str(binary)], env)
            binary.unlink(missing_ok=True)
        (dest/'results.json').write_text(json.dumps(results, indent=2)+'\n')
        def observation(label):
            r = results.get(label, results.get(label+'_build'))
            return (r['exit'], r['stdout'], r['stderr'])
        comparisons = {label: observation(label) == observation('node') for label, _, _ in args.compiler}
        if len(args.compiler) == 2:
            comparisons['unchanged'] = observation(args.compiler[0][0]) == observation(args.compiler[1][0])
        print(json.dumps({'probe': str(name), 'matches': comparisons}), flush=True)
        return {'probe': str(name), 'matches': comparisons}

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(probe, sorted(args.probe_root.rglob('*.pts'))))
    (args.out/'summary.json').write_text(json.dumps(results, indent=2)+'\n')


if __name__ == '__main__':
    main()
