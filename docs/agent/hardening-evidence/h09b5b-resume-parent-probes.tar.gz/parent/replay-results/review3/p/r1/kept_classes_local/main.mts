// Review H09b5b r1: errors/generic_polymorphic_recursion_kept_classes.pts with val a function-local
// arrow (ValueInstances' pairing, narrowable) instead of a module-scope const (D-102).
class Box<T> {
  constructor(public value: T) {}
}
const kept: Map<string, unknown>[] = [];
let g: <U>(x: U, n: number) => Box<U>;
class Node<T> {
  constructor(public v: T) {}
  left(n: number): Box<[T]> {
    return g<[T]>([this.v], n - 1);
  }
  right(n: number): Box<{ v: T }> {
    return g<{ v: T }>({ v: this.v }, n - 1);
  }
}
function main(): void {
const val = <U,>(x: U, n: number): Box<U> => {
  const node = new Node<U>(x);
  kept.push(new Map<string, U>());
  if (n > 0) {
    node.left(n);
    node.right(n);
  }
  return new Box(x);
};
g = val;
try {
  const b: Box<number> = g(1, 2);
  console.log(b.value, kept.length);
} catch (error: any) {
  console.log(error.name, error.message);
}
}
main();
