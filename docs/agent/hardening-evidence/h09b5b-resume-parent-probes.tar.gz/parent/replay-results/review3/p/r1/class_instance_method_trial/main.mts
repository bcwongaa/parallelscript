// Review H09b5b r1: a failure only a narrowable pairing's code leads to, through a generic
// method of a class instance that pairing made. The escaping arrow w's speculative instance for
// Dog[] (paired with use's demand; ValueInstances' alone) makes Holder<Dog[]>; the dispatched
// demand b.make(...) pairs with Holder<Dog[]>'s make (a pairing every level makes once
// Holder<Dog[]> exists), whose instance makes Weird<Dog[]>, whose method doesn't lower (D-094).
// That instance's substitution was made in the demand's code (made: d.subst), not in
// Holder<Dog[]>, so the report is the program's own: the whole build falls back, as on the base.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
abstract class Maker {
  abstract make<U>(u: U): Box<U>;
}
class Holder<T> extends Maker {
  constructor(public value: T) {
    super();
  }
  make<U>(u: U): Box<U> {
    const w = new Weird(this.value);
    console.log("weird", w.animals().length);
    return new Box(u);
  }
}
class Plain extends Maker {
  make<U>(u: U): Box<U> {
    return new Box(u);
  }
}
function use(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs", b.value.length);
}
function main(): void {
  const named = <T>(x: T): Box<T> => new Box(x);
  try {
    const b: Box<number> = named(5);
    console.log("victim", b.value + 1);
  } catch (e: any) {
    console.log("victim threw", e.message);
  }
  const w = <T>(x: T): Holder<T> => new Holder(x);
  const d: any = w;
  console.log("holder", d(1).value);
  const m: Maker = new Plain();
  console.log("dispatched", m.make(7).value + 1);
  use(named);
}
main();
