// The total (maxRecursiveTotal) met in trials that only AllInstances makes: an interface call of
// a generic method (a demand by name, D-191) pairs with 6 classes' methods, each a branching
// polymorphic recursion by direct calls with Box results, so their trials together spend Box's total
// (1024); past it the report stands (D-198), the build falls back to ValueInstances, where interface
// calls make no demands, and the unrelated interface call loses its instance too. Recursion 3 deep.
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
interface Rec {
  rec<T>(x: T, n: number): Box<T>;
}
class R0 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v0: T }>({ v0: x }, n - 1);
    }
    return new Box(x);
  }
}
class R1 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v1: T }>({ v1: x }, n - 1);
    }
    return new Box(x);
  }
}
class R2 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v2: T }>({ v2: x }, n - 1);
    }
    return new Box(x);
  }
}
class R3 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v3: T }>({ v3: x }, n - 1);
    }
    return new Box(x);
  }
}
class R4 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v4: T }>({ v4: x }, n - 1);
    }
    return new Box(x);
  }
}
class R5 implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      this.rec<[T]>([x], n - 1);
      this.rec<{ v5: T }>({ v5: x }, n - 1);
    }
    return new Box(x);
  }
}
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
const maker: Maker = new ClassMaker();
attempt("unrelated interface call", () => maker.make(4).value + 1);
const recs: Rec[] = [new R0(), new R1(), new R2(), new R3(), new R4(), new R5()];
attempt("recursion", () => recs[0].rec(5, 3).value + 1);
