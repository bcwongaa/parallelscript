// Review H09b5b r1: the call_site trigger through an element access whose key isn't one name
// (D-194's keyedCall, a demand by the name the key holds): the site is left out, and the
// unrelated interface call and local arrow keep their instances.
class Box<T> {
  constructor(public value: T) {}
}
interface M {
  f<T>(a?: number, ...xs: T[]): Box<T[]>;
  g<T>(a?: number, ...xs: T[]): Box<T[]>;
}
class CM implements M {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
  g<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function maybe(): number | undefined {
  return undefined;
}
function main(key: "f" | "g"): void {
  const maker: Maker = new ClassMaker();
  console.log("interface victim", maker.make(4).value + 1);
  const named = <T>(x: T): Box<T> => new Box(x);
  console.log("value victim", named(5).value + 1);
  const m: M = new CM();
  try {
    const b: Box<number[]> = m[key](maybe(), 1, 2);
    console.log("trigger ran", b.value.length);
  } catch (error: any) {
    console.log("trigger ran", 2);
  }
}
main(Math.random() > 2 ? "g" : "f");
