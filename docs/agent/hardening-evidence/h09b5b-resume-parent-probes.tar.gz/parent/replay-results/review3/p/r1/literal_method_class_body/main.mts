// Review H09b5b r1: C176's class-body trigger through an object literal's generic method (D-191):
// the demand by name o.make<Dog[]> pairs with the literal's method, whose instance makes
// Weird<Dog[]>, whose method doesn't lower (D-094) after the trial. Only that pairing should be
// left out; the unrelated interface call and local arrow keep their instances.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
function main(): void {
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  const named = <T>(x: T): Box<T> => new Box(x);
  attempt("value victim", () => named(5).value + 1);
  const o = {
    make<T>(x: T): Box<T> {
      const w = new Weird(x);
      console.log("weird", w.animals().length);
      return new Box(x);
    },
  };
  attempt("literal", () => o.make([new Dog()]).value.length);
}
main();
