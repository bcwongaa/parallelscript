// Review H09b5b r2 (the working tree's removal of reportInstanceLimit's making++): a total met by a
// trial's own instance, reported in tryInstance outside the instance being made. rec is a local
// generic arrow that recurses through the generic value g, a demand and a trial at each level
// (C184); 6 of the program's calls for 6 types are 6 roots, whose speculative trees together
// reach rec's total (1024, D-198), so a later trial's own instance is past it.
class Box<T> {
  constructor(public value: T) {}
}
let g: <U>(x: U, n: number) => Box<U>;
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function main(): void {
  const rec = <U,>(x: U, n: number): Box<U> => {
    if (n > 0) {
      g<[U]>([x], n - 1);
      g<{ v: U }>({ v: x }, n - 1);
    }
    return new Box(x);
  };
  g = rec;
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  attempt("root0", () => g({ k0: 0 }, 3).value.k0);
  attempt("root1", () => g({ k1: 1 }, 3).value.k1);
  attempt("root2", () => g({ k2: 2 }, 3).value.k2);
  attempt("root3", () => g({ k3: 3 }, 3).value.k3);
  attempt("root4", () => g({ k4: 4 }, 3).value.k4);
  attempt("root5", () => g({ k5: 5 }, 3).value.k5);
}
main();
