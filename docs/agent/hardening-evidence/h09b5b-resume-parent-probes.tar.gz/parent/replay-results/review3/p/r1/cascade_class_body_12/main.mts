// Review H09b5b r1: 12 typed calls of one generic function type, each a demand, pair with the
// escaping arrow w, whose instance for Dog[] makes Weird<Dog[]>, whose method doesn't lower
// (D-094), after the trial. Each lowering blames only the first trial that made Weird<Dog[]>; the
// next trial makes it again in the next lowering: one more lowering per demand (cascade).
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
function use0(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs0", b.value.length);
}
function use1(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs1", b.value.length);
}
function use2(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs2", b.value.length);
}
function use3(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs3", b.value.length);
}
function use4(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs4", b.value.length);
}
function use5(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs5", b.value.length);
}
function use6(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs6", b.value.length);
}
function use7(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs7", b.value.length);
}
function use8(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs8", b.value.length);
}
function use9(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs9", b.value.length);
}
function use10(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs10", b.value.length);
}
function use11(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs11", b.value.length);
}
function main(): void {
  const named = <T>(x: T): Box<T> => new Box(x);
  const w = <T>(x: T): Weird<T> => new Weird(x);
  const d: any = w;
  console.log("weird", d(1).animals().length);
  use0(named);
  use1(named);
  use2(named);
  use3(named);
  use4(named);
  use5(named);
  use6(named);
  use7(named);
  use8(named);
  use9(named);
  use10(named);
  use11(named);
}
main();
