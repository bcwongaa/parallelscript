// Review H09b5b r1: the cascade of cascade_class_body_12 with 10 demands and an unrelated
// interface call (a demand by name, AllInstances' alone) and local arrow: past 8 lowerings at a
// level the build falls back, with every pairing left out so far.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
function use0(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs0", b.value.length);
}
function use1(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs1", b.value.length);
}
function use2(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs2", b.value.length);
}
function use3(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs3", b.value.length);
}
function use4(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs4", b.value.length);
}
function use5(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs5", b.value.length);
}
function use6(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs6", b.value.length);
}
function use7(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs7", b.value.length);
}
function use8(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs8", b.value.length);
}
function use9(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs9", b.value.length);
}
function main(): void {
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  const named = <T>(x: T): Box<T> => new Box(x);
  attempt("value victim", () => named(5).value + 1);
  const w = <T>(x: T): Weird<T> => new Weird(x);
  const d: any = w;
  console.log("weird", d(1).animals().length);
  use0(named);
  use1(named);
  use2(named);
  use3(named);
  use4(named);
  use5(named);
  use6(named);
  use7(named);
  use8(named);
  use9(named);
}
main();
