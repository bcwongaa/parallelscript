// Review H09b5b r2: a call site is left out by its node, for every instance of the generic
// function it is in. f<T>'s statement makes the demand by name m.make(1), then (for T = Dog[]
// only) passes the Dog[] as a kept Animal[] (D-094). f<Dog[]> is made only in the trial of la's
// speculative pairing with use's demand; the failure there is the trial's own and the base takes
// the trial back. Here the statement is the site's (statementSites), so the report stands, the
// site is left out, and the program's own f<number> loses m.make(1)'s instance with it.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
const kept: Animal[][] = [];
function keepAnimals(a: Animal[]): number {
  kept.push(a);
  return a.length;
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const maker: Maker = new ClassMaker();
function f<T>(m: Maker, x: T): number {
  return m.make(1).value + (Array.isArray(x) ? keepAnimals(x) : 0);
}
function use(g: <T>(x: T) => Box<T>): number {
  const b: Box<Dog[]> = g([new Dog()]);
  return b.value.length;
}
function main(): void {
  console.log("own instance", f(maker, 5));
  const named = <T,>(x: T): Box<T> => new Box(x);
  const la = <T,>(x: T): Box<T> => {
    f(maker, x);
    return new Box(x);
  };
  const d: any = la;
  console.log("la", d(2).value);
  console.log("use", use(named));
}
main();
