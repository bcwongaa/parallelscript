// Review H09b5b r1 (padded with 600 classes and functions, about 9,000 lines): the cascade of cascade_class_body_12 with 20 demands and an unrelated
// interface call (a demand by name, AllInstances' alone) and local arrow: past 8 lowerings at a
// level the build falls back, with every pairing left out so far.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
function use0(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs0", b.value.length);
}
function use1(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs1", b.value.length);
}
function use2(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs2", b.value.length);
}
function use3(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs3", b.value.length);
}
function use4(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs4", b.value.length);
}
function use5(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs5", b.value.length);
}
function use6(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs6", b.value.length);
}
function use7(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs7", b.value.length);
}
function use8(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs8", b.value.length);
}
function use9(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs9", b.value.length);
}
function use10(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs10", b.value.length);
}
function use11(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs11", b.value.length);
}
function use12(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs12", b.value.length);
}
function use13(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs13", b.value.length);
}
function use14(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs14", b.value.length);
}
function use15(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs15", b.value.length);
}
function use16(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs16", b.value.length);
}
function use17(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs17", b.value.length);
}
function use18(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs18", b.value.length);
}
function use19(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs19", b.value.length);
}
function main(): void {
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  const named = <T>(x: T): Box<T> => new Box(x);
  attempt("value victim", () => named(5).value + 1);
  const w = <T>(x: T): Weird<T> => new Weird(x);
  const d: any = w;
  console.log("weird", d(1).animals().length);
  use0(named);
  use1(named);
  use2(named);
  use3(named);
  use4(named);
  use5(named);
  use6(named);
  use7(named);
  use8(named);
  use9(named);
  use10(named);
  use11(named);
  use12(named);
  use13(named);
  use14(named);
  use15(named);
  use16(named);
  use17(named);
  use18(named);
  use19(named);
}
main();
let total = 0;
total += pad0(3);
total += pad50(3);
total += pad100(3);
total += pad150(3);
total += pad200(3);
total += pad250(3);
total += pad300(3);
total += pad350(3);
total += pad400(3);
total += pad450(3);
total += pad500(3);
total += pad550(3);
console.log(total);

class P0 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad0(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 0);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P0(n, "x").m(2).length;
}
class P1 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad1(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 1);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P1(n, "x").m(2).length;
}
class P2 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad2(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 2);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P2(n, "x").m(2).length;
}
class P3 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad3(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 3);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P3(n, "x").m(2).length;
}
class P4 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad4(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 4);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P4(n, "x").m(2).length;
}
class P5 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad5(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 5);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P5(n, "x").m(2).length;
}
class P6 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad6(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 6);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P6(n, "x").m(2).length;
}
class P7 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad7(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 7);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P7(n, "x").m(2).length;
}
class P8 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad8(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 8);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P8(n, "x").m(2).length;
}
class P9 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad9(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 9);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P9(n, "x").m(2).length;
}
class P10 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad10(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 10);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P10(n, "x").m(2).length;
}
class P11 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad11(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 11);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P11(n, "x").m(2).length;
}
class P12 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad12(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 12);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P12(n, "x").m(2).length;
}
class P13 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad13(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 13);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P13(n, "x").m(2).length;
}
class P14 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad14(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 14);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P14(n, "x").m(2).length;
}
class P15 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad15(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 15);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P15(n, "x").m(2).length;
}
class P16 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad16(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 16);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P16(n, "x").m(2).length;
}
class P17 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad17(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 17);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P17(n, "x").m(2).length;
}
class P18 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad18(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 18);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P18(n, "x").m(2).length;
}
class P19 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad19(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 19);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P19(n, "x").m(2).length;
}
class P20 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad20(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 20);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P20(n, "x").m(2).length;
}
class P21 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad21(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 21);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P21(n, "x").m(2).length;
}
class P22 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad22(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 22);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P22(n, "x").m(2).length;
}
class P23 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad23(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 23);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P23(n, "x").m(2).length;
}
class P24 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad24(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 24);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P24(n, "x").m(2).length;
}
class P25 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad25(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 25);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P25(n, "x").m(2).length;
}
class P26 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad26(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 26);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P26(n, "x").m(2).length;
}
class P27 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad27(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 27);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P27(n, "x").m(2).length;
}
class P28 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad28(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 28);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P28(n, "x").m(2).length;
}
class P29 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad29(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 29);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P29(n, "x").m(2).length;
}
class P30 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad30(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 30);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P30(n, "x").m(2).length;
}
class P31 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad31(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 31);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P31(n, "x").m(2).length;
}
class P32 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad32(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 32);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P32(n, "x").m(2).length;
}
class P33 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad33(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 33);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P33(n, "x").m(2).length;
}
class P34 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad34(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 34);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P34(n, "x").m(2).length;
}
class P35 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad35(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 35);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P35(n, "x").m(2).length;
}
class P36 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad36(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 36);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P36(n, "x").m(2).length;
}
class P37 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad37(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 37);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P37(n, "x").m(2).length;
}
class P38 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad38(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 38);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P38(n, "x").m(2).length;
}
class P39 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad39(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 39);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P39(n, "x").m(2).length;
}
class P40 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad40(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 40);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P40(n, "x").m(2).length;
}
class P41 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad41(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 41);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P41(n, "x").m(2).length;
}
class P42 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad42(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 42);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P42(n, "x").m(2).length;
}
class P43 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad43(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 43);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P43(n, "x").m(2).length;
}
class P44 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad44(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 44);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P44(n, "x").m(2).length;
}
class P45 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad45(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 45);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P45(n, "x").m(2).length;
}
class P46 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad46(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 46);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P46(n, "x").m(2).length;
}
class P47 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad47(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 47);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P47(n, "x").m(2).length;
}
class P48 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad48(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 48);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P48(n, "x").m(2).length;
}
class P49 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad49(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 49);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P49(n, "x").m(2).length;
}
class P50 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad50(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 50);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P50(n, "x").m(2).length;
}
class P51 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad51(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 51);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P51(n, "x").m(2).length;
}
class P52 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad52(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 52);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P52(n, "x").m(2).length;
}
class P53 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad53(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 53);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P53(n, "x").m(2).length;
}
class P54 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad54(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 54);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P54(n, "x").m(2).length;
}
class P55 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad55(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 55);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P55(n, "x").m(2).length;
}
class P56 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad56(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 56);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P56(n, "x").m(2).length;
}
class P57 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad57(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 57);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P57(n, "x").m(2).length;
}
class P58 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad58(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 58);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P58(n, "x").m(2).length;
}
class P59 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad59(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 59);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P59(n, "x").m(2).length;
}
class P60 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad60(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 60);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P60(n, "x").m(2).length;
}
class P61 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad61(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 61);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P61(n, "x").m(2).length;
}
class P62 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad62(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 62);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P62(n, "x").m(2).length;
}
class P63 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad63(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 63);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P63(n, "x").m(2).length;
}
class P64 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad64(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 64);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P64(n, "x").m(2).length;
}
class P65 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad65(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 65);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P65(n, "x").m(2).length;
}
class P66 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad66(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 66);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P66(n, "x").m(2).length;
}
class P67 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad67(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 67);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P67(n, "x").m(2).length;
}
class P68 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad68(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 68);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P68(n, "x").m(2).length;
}
class P69 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad69(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 69);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P69(n, "x").m(2).length;
}
class P70 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad70(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 70);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P70(n, "x").m(2).length;
}
class P71 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad71(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 71);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P71(n, "x").m(2).length;
}
class P72 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad72(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 72);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P72(n, "x").m(2).length;
}
class P73 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad73(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 73);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P73(n, "x").m(2).length;
}
class P74 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad74(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 74);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P74(n, "x").m(2).length;
}
class P75 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad75(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 75);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P75(n, "x").m(2).length;
}
class P76 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad76(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 76);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P76(n, "x").m(2).length;
}
class P77 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad77(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 77);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P77(n, "x").m(2).length;
}
class P78 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad78(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 78);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P78(n, "x").m(2).length;
}
class P79 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad79(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 79);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P79(n, "x").m(2).length;
}
class P80 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad80(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 80);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P80(n, "x").m(2).length;
}
class P81 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad81(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 81);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P81(n, "x").m(2).length;
}
class P82 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad82(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 82);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P82(n, "x").m(2).length;
}
class P83 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad83(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 83);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P83(n, "x").m(2).length;
}
class P84 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad84(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 84);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P84(n, "x").m(2).length;
}
class P85 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad85(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 85);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P85(n, "x").m(2).length;
}
class P86 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad86(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 86);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P86(n, "x").m(2).length;
}
class P87 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad87(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 87);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P87(n, "x").m(2).length;
}
class P88 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad88(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 88);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P88(n, "x").m(2).length;
}
class P89 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad89(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 89);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P89(n, "x").m(2).length;
}
class P90 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad90(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 90);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P90(n, "x").m(2).length;
}
class P91 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad91(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 91);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P91(n, "x").m(2).length;
}
class P92 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad92(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 92);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P92(n, "x").m(2).length;
}
class P93 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad93(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 93);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P93(n, "x").m(2).length;
}
class P94 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad94(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 94);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P94(n, "x").m(2).length;
}
class P95 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad95(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 95);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P95(n, "x").m(2).length;
}
class P96 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad96(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 96);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P96(n, "x").m(2).length;
}
class P97 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad97(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 97);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P97(n, "x").m(2).length;
}
class P98 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad98(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 98);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P98(n, "x").m(2).length;
}
class P99 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad99(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 99);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P99(n, "x").m(2).length;
}
class P100 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad100(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 100);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P100(n, "x").m(2).length;
}
class P101 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad101(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 101);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P101(n, "x").m(2).length;
}
class P102 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad102(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 102);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P102(n, "x").m(2).length;
}
class P103 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad103(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 103);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P103(n, "x").m(2).length;
}
class P104 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad104(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 104);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P104(n, "x").m(2).length;
}
class P105 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad105(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 105);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P105(n, "x").m(2).length;
}
class P106 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad106(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 106);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P106(n, "x").m(2).length;
}
class P107 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad107(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 107);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P107(n, "x").m(2).length;
}
class P108 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad108(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 108);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P108(n, "x").m(2).length;
}
class P109 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad109(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 109);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P109(n, "x").m(2).length;
}
class P110 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad110(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 110);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P110(n, "x").m(2).length;
}
class P111 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad111(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 111);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P111(n, "x").m(2).length;
}
class P112 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad112(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 112);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P112(n, "x").m(2).length;
}
class P113 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad113(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 113);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P113(n, "x").m(2).length;
}
class P114 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad114(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 114);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P114(n, "x").m(2).length;
}
class P115 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad115(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 115);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P115(n, "x").m(2).length;
}
class P116 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad116(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 116);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P116(n, "x").m(2).length;
}
class P117 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad117(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 117);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P117(n, "x").m(2).length;
}
class P118 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad118(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 118);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P118(n, "x").m(2).length;
}
class P119 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad119(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 119);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P119(n, "x").m(2).length;
}
class P120 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad120(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 120);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P120(n, "x").m(2).length;
}
class P121 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad121(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 121);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P121(n, "x").m(2).length;
}
class P122 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad122(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 122);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P122(n, "x").m(2).length;
}
class P123 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad123(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 123);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P123(n, "x").m(2).length;
}
class P124 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad124(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 124);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P124(n, "x").m(2).length;
}
class P125 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad125(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 125);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P125(n, "x").m(2).length;
}
class P126 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad126(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 126);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P126(n, "x").m(2).length;
}
class P127 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad127(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 127);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P127(n, "x").m(2).length;
}
class P128 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad128(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 128);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P128(n, "x").m(2).length;
}
class P129 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad129(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 129);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P129(n, "x").m(2).length;
}
class P130 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad130(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 130);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P130(n, "x").m(2).length;
}
class P131 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad131(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 131);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P131(n, "x").m(2).length;
}
class P132 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad132(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 132);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P132(n, "x").m(2).length;
}
class P133 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad133(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 133);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P133(n, "x").m(2).length;
}
class P134 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad134(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 134);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P134(n, "x").m(2).length;
}
class P135 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad135(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 135);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P135(n, "x").m(2).length;
}
class P136 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad136(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 136);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P136(n, "x").m(2).length;
}
class P137 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad137(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 137);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P137(n, "x").m(2).length;
}
class P138 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad138(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 138);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P138(n, "x").m(2).length;
}
class P139 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad139(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 139);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P139(n, "x").m(2).length;
}
class P140 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad140(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 140);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P140(n, "x").m(2).length;
}
class P141 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad141(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 141);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P141(n, "x").m(2).length;
}
class P142 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad142(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 142);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P142(n, "x").m(2).length;
}
class P143 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad143(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 143);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P143(n, "x").m(2).length;
}
class P144 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad144(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 144);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P144(n, "x").m(2).length;
}
class P145 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad145(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 145);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P145(n, "x").m(2).length;
}
class P146 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad146(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 146);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P146(n, "x").m(2).length;
}
class P147 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad147(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 147);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P147(n, "x").m(2).length;
}
class P148 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad148(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 148);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P148(n, "x").m(2).length;
}
class P149 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad149(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 149);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P149(n, "x").m(2).length;
}
class P150 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad150(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 150);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P150(n, "x").m(2).length;
}
class P151 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad151(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 151);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P151(n, "x").m(2).length;
}
class P152 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad152(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 152);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P152(n, "x").m(2).length;
}
class P153 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad153(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 153);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P153(n, "x").m(2).length;
}
class P154 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad154(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 154);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P154(n, "x").m(2).length;
}
class P155 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad155(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 155);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P155(n, "x").m(2).length;
}
class P156 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad156(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 156);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P156(n, "x").m(2).length;
}
class P157 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad157(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 157);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P157(n, "x").m(2).length;
}
class P158 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad158(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 158);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P158(n, "x").m(2).length;
}
class P159 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad159(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 159);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P159(n, "x").m(2).length;
}
class P160 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad160(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 160);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P160(n, "x").m(2).length;
}
class P161 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad161(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 161);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P161(n, "x").m(2).length;
}
class P162 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad162(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 162);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P162(n, "x").m(2).length;
}
class P163 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad163(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 163);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P163(n, "x").m(2).length;
}
class P164 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad164(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 164);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P164(n, "x").m(2).length;
}
class P165 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad165(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 165);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P165(n, "x").m(2).length;
}
class P166 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad166(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 166);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P166(n, "x").m(2).length;
}
class P167 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad167(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 167);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P167(n, "x").m(2).length;
}
class P168 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad168(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 168);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P168(n, "x").m(2).length;
}
class P169 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad169(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 169);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P169(n, "x").m(2).length;
}
class P170 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad170(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 170);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P170(n, "x").m(2).length;
}
class P171 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad171(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 171);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P171(n, "x").m(2).length;
}
class P172 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad172(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 172);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P172(n, "x").m(2).length;
}
class P173 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad173(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 173);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P173(n, "x").m(2).length;
}
class P174 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad174(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 174);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P174(n, "x").m(2).length;
}
class P175 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad175(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 175);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P175(n, "x").m(2).length;
}
class P176 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad176(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 176);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P176(n, "x").m(2).length;
}
class P177 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad177(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 177);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P177(n, "x").m(2).length;
}
class P178 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad178(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 178);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P178(n, "x").m(2).length;
}
class P179 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad179(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 179);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P179(n, "x").m(2).length;
}
class P180 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad180(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 180);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P180(n, "x").m(2).length;
}
class P181 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad181(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 181);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P181(n, "x").m(2).length;
}
class P182 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad182(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 182);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P182(n, "x").m(2).length;
}
class P183 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad183(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 183);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P183(n, "x").m(2).length;
}
class P184 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad184(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 184);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P184(n, "x").m(2).length;
}
class P185 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad185(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 185);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P185(n, "x").m(2).length;
}
class P186 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad186(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 186);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P186(n, "x").m(2).length;
}
class P187 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad187(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 187);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P187(n, "x").m(2).length;
}
class P188 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad188(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 188);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P188(n, "x").m(2).length;
}
class P189 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad189(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 189);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P189(n, "x").m(2).length;
}
class P190 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad190(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 190);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P190(n, "x").m(2).length;
}
class P191 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad191(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 191);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P191(n, "x").m(2).length;
}
class P192 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad192(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 192);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P192(n, "x").m(2).length;
}
class P193 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad193(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 193);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P193(n, "x").m(2).length;
}
class P194 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad194(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 194);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P194(n, "x").m(2).length;
}
class P195 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad195(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 195);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P195(n, "x").m(2).length;
}
class P196 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad196(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 196);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P196(n, "x").m(2).length;
}
class P197 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad197(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 197);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P197(n, "x").m(2).length;
}
class P198 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad198(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 198);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P198(n, "x").m(2).length;
}
class P199 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad199(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 199);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P199(n, "x").m(2).length;
}
class P200 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad200(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 200);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P200(n, "x").m(2).length;
}
class P201 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad201(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 201);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P201(n, "x").m(2).length;
}
class P202 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad202(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 202);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P202(n, "x").m(2).length;
}
class P203 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad203(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 203);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P203(n, "x").m(2).length;
}
class P204 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad204(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 204);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P204(n, "x").m(2).length;
}
class P205 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad205(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 205);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P205(n, "x").m(2).length;
}
class P206 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad206(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 206);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P206(n, "x").m(2).length;
}
class P207 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad207(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 207);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P207(n, "x").m(2).length;
}
class P208 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad208(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 208);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P208(n, "x").m(2).length;
}
class P209 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad209(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 209);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P209(n, "x").m(2).length;
}
class P210 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad210(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 210);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P210(n, "x").m(2).length;
}
class P211 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad211(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 211);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P211(n, "x").m(2).length;
}
class P212 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad212(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 212);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P212(n, "x").m(2).length;
}
class P213 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad213(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 213);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P213(n, "x").m(2).length;
}
class P214 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad214(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 214);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P214(n, "x").m(2).length;
}
class P215 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad215(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 215);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P215(n, "x").m(2).length;
}
class P216 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad216(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 216);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P216(n, "x").m(2).length;
}
class P217 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad217(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 217);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P217(n, "x").m(2).length;
}
class P218 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad218(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 218);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P218(n, "x").m(2).length;
}
class P219 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad219(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 219);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P219(n, "x").m(2).length;
}
class P220 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad220(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 220);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P220(n, "x").m(2).length;
}
class P221 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad221(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 221);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P221(n, "x").m(2).length;
}
class P222 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad222(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 222);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P222(n, "x").m(2).length;
}
class P223 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad223(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 223);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P223(n, "x").m(2).length;
}
class P224 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad224(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 224);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P224(n, "x").m(2).length;
}
class P225 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad225(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 225);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P225(n, "x").m(2).length;
}
class P226 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad226(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 226);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P226(n, "x").m(2).length;
}
class P227 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad227(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 227);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P227(n, "x").m(2).length;
}
class P228 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad228(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 228);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P228(n, "x").m(2).length;
}
class P229 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad229(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 229);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P229(n, "x").m(2).length;
}
class P230 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad230(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 230);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P230(n, "x").m(2).length;
}
class P231 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad231(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 231);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P231(n, "x").m(2).length;
}
class P232 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad232(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 232);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P232(n, "x").m(2).length;
}
class P233 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad233(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 233);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P233(n, "x").m(2).length;
}
class P234 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad234(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 234);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P234(n, "x").m(2).length;
}
class P235 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad235(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 235);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P235(n, "x").m(2).length;
}
class P236 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad236(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 236);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P236(n, "x").m(2).length;
}
class P237 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad237(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 237);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P237(n, "x").m(2).length;
}
class P238 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad238(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 238);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P238(n, "x").m(2).length;
}
class P239 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad239(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 239);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P239(n, "x").m(2).length;
}
class P240 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad240(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 240);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P240(n, "x").m(2).length;
}
class P241 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad241(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 241);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P241(n, "x").m(2).length;
}
class P242 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad242(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 242);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P242(n, "x").m(2).length;
}
class P243 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad243(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 243);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P243(n, "x").m(2).length;
}
class P244 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad244(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 244);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P244(n, "x").m(2).length;
}
class P245 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad245(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 245);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P245(n, "x").m(2).length;
}
class P246 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad246(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 246);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P246(n, "x").m(2).length;
}
class P247 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad247(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 247);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P247(n, "x").m(2).length;
}
class P248 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad248(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 248);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P248(n, "x").m(2).length;
}
class P249 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad249(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 249);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P249(n, "x").m(2).length;
}
class P250 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad250(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 250);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P250(n, "x").m(2).length;
}
class P251 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad251(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 251);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P251(n, "x").m(2).length;
}
class P252 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad252(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 252);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P252(n, "x").m(2).length;
}
class P253 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad253(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 253);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P253(n, "x").m(2).length;
}
class P254 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad254(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 254);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P254(n, "x").m(2).length;
}
class P255 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad255(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 255);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P255(n, "x").m(2).length;
}
class P256 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad256(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 256);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P256(n, "x").m(2).length;
}
class P257 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad257(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 257);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P257(n, "x").m(2).length;
}
class P258 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad258(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 258);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P258(n, "x").m(2).length;
}
class P259 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad259(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 259);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P259(n, "x").m(2).length;
}
class P260 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad260(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 260);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P260(n, "x").m(2).length;
}
class P261 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad261(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 261);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P261(n, "x").m(2).length;
}
class P262 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad262(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 262);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P262(n, "x").m(2).length;
}
class P263 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad263(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 263);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P263(n, "x").m(2).length;
}
class P264 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad264(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 264);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P264(n, "x").m(2).length;
}
class P265 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad265(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 265);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P265(n, "x").m(2).length;
}
class P266 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad266(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 266);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P266(n, "x").m(2).length;
}
class P267 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad267(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 267);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P267(n, "x").m(2).length;
}
class P268 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad268(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 268);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P268(n, "x").m(2).length;
}
class P269 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad269(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 269);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P269(n, "x").m(2).length;
}
class P270 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad270(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 270);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P270(n, "x").m(2).length;
}
class P271 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad271(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 271);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P271(n, "x").m(2).length;
}
class P272 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad272(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 272);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P272(n, "x").m(2).length;
}
class P273 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad273(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 273);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P273(n, "x").m(2).length;
}
class P274 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad274(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 274);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P274(n, "x").m(2).length;
}
class P275 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad275(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 275);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P275(n, "x").m(2).length;
}
class P276 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad276(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 276);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P276(n, "x").m(2).length;
}
class P277 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad277(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 277);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P277(n, "x").m(2).length;
}
class P278 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad278(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 278);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P278(n, "x").m(2).length;
}
class P279 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad279(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 279);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P279(n, "x").m(2).length;
}
class P280 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad280(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 280);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P280(n, "x").m(2).length;
}
class P281 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad281(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 281);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P281(n, "x").m(2).length;
}
class P282 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad282(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 282);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P282(n, "x").m(2).length;
}
class P283 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad283(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 283);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P283(n, "x").m(2).length;
}
class P284 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad284(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 284);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P284(n, "x").m(2).length;
}
class P285 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad285(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 285);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P285(n, "x").m(2).length;
}
class P286 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad286(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 286);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P286(n, "x").m(2).length;
}
class P287 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad287(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 287);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P287(n, "x").m(2).length;
}
class P288 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad288(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 288);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P288(n, "x").m(2).length;
}
class P289 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad289(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 289);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P289(n, "x").m(2).length;
}
class P290 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad290(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 290);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P290(n, "x").m(2).length;
}
class P291 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad291(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 291);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P291(n, "x").m(2).length;
}
class P292 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad292(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 292);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P292(n, "x").m(2).length;
}
class P293 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad293(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 293);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P293(n, "x").m(2).length;
}
class P294 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad294(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 294);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P294(n, "x").m(2).length;
}
class P295 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad295(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 295);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P295(n, "x").m(2).length;
}
class P296 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad296(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 296);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P296(n, "x").m(2).length;
}
class P297 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad297(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 297);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P297(n, "x").m(2).length;
}
class P298 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad298(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 298);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P298(n, "x").m(2).length;
}
class P299 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad299(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 299);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P299(n, "x").m(2).length;
}
class P300 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad300(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 300);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P300(n, "x").m(2).length;
}
class P301 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad301(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 301);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P301(n, "x").m(2).length;
}
class P302 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad302(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 302);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P302(n, "x").m(2).length;
}
class P303 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad303(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 303);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P303(n, "x").m(2).length;
}
class P304 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad304(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 304);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P304(n, "x").m(2).length;
}
class P305 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad305(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 305);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P305(n, "x").m(2).length;
}
class P306 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad306(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 306);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P306(n, "x").m(2).length;
}
class P307 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad307(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 307);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P307(n, "x").m(2).length;
}
class P308 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad308(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 308);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P308(n, "x").m(2).length;
}
class P309 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad309(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 309);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P309(n, "x").m(2).length;
}
class P310 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad310(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 310);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P310(n, "x").m(2).length;
}
class P311 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad311(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 311);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P311(n, "x").m(2).length;
}
class P312 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad312(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 312);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P312(n, "x").m(2).length;
}
class P313 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad313(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 313);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P313(n, "x").m(2).length;
}
class P314 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad314(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 314);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P314(n, "x").m(2).length;
}
class P315 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad315(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 315);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P315(n, "x").m(2).length;
}
class P316 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad316(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 316);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P316(n, "x").m(2).length;
}
class P317 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad317(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 317);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P317(n, "x").m(2).length;
}
class P318 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad318(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 318);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P318(n, "x").m(2).length;
}
class P319 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad319(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 319);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P319(n, "x").m(2).length;
}
class P320 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad320(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 320);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P320(n, "x").m(2).length;
}
class P321 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad321(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 321);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P321(n, "x").m(2).length;
}
class P322 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad322(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 322);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P322(n, "x").m(2).length;
}
class P323 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad323(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 323);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P323(n, "x").m(2).length;
}
class P324 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad324(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 324);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P324(n, "x").m(2).length;
}
class P325 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad325(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 325);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P325(n, "x").m(2).length;
}
class P326 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad326(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 326);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P326(n, "x").m(2).length;
}
class P327 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad327(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 327);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P327(n, "x").m(2).length;
}
class P328 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad328(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 328);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P328(n, "x").m(2).length;
}
class P329 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad329(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 329);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P329(n, "x").m(2).length;
}
class P330 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad330(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 330);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P330(n, "x").m(2).length;
}
class P331 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad331(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 331);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P331(n, "x").m(2).length;
}
class P332 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad332(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 332);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P332(n, "x").m(2).length;
}
class P333 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad333(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 333);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P333(n, "x").m(2).length;
}
class P334 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad334(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 334);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P334(n, "x").m(2).length;
}
class P335 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad335(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 335);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P335(n, "x").m(2).length;
}
class P336 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad336(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 336);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P336(n, "x").m(2).length;
}
class P337 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad337(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 337);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P337(n, "x").m(2).length;
}
class P338 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad338(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 338);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P338(n, "x").m(2).length;
}
class P339 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad339(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 339);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P339(n, "x").m(2).length;
}
class P340 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad340(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 340);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P340(n, "x").m(2).length;
}
class P341 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad341(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 341);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P341(n, "x").m(2).length;
}
class P342 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad342(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 342);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P342(n, "x").m(2).length;
}
class P343 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad343(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 343);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P343(n, "x").m(2).length;
}
class P344 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad344(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 344);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P344(n, "x").m(2).length;
}
class P345 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad345(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 345);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P345(n, "x").m(2).length;
}
class P346 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad346(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 346);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P346(n, "x").m(2).length;
}
class P347 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad347(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 347);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P347(n, "x").m(2).length;
}
class P348 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad348(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 348);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P348(n, "x").m(2).length;
}
class P349 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad349(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 349);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P349(n, "x").m(2).length;
}
class P350 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad350(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 350);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P350(n, "x").m(2).length;
}
class P351 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad351(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 351);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P351(n, "x").m(2).length;
}
class P352 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad352(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 352);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P352(n, "x").m(2).length;
}
class P353 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad353(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 353);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P353(n, "x").m(2).length;
}
class P354 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad354(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 354);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P354(n, "x").m(2).length;
}
class P355 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad355(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 355);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P355(n, "x").m(2).length;
}
class P356 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad356(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 356);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P356(n, "x").m(2).length;
}
class P357 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad357(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 357);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P357(n, "x").m(2).length;
}
class P358 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad358(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 358);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P358(n, "x").m(2).length;
}
class P359 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad359(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 359);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P359(n, "x").m(2).length;
}
class P360 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad360(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 360);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P360(n, "x").m(2).length;
}
class P361 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad361(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 361);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P361(n, "x").m(2).length;
}
class P362 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad362(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 362);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P362(n, "x").m(2).length;
}
class P363 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad363(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 363);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P363(n, "x").m(2).length;
}
class P364 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad364(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 364);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P364(n, "x").m(2).length;
}
class P365 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad365(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 365);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P365(n, "x").m(2).length;
}
class P366 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad366(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 366);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P366(n, "x").m(2).length;
}
class P367 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad367(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 367);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P367(n, "x").m(2).length;
}
class P368 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad368(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 368);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P368(n, "x").m(2).length;
}
class P369 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad369(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 369);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P369(n, "x").m(2).length;
}
class P370 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad370(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 370);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P370(n, "x").m(2).length;
}
class P371 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad371(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 371);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P371(n, "x").m(2).length;
}
class P372 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad372(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 372);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P372(n, "x").m(2).length;
}
class P373 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad373(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 373);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P373(n, "x").m(2).length;
}
class P374 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad374(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 374);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P374(n, "x").m(2).length;
}
class P375 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad375(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 375);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P375(n, "x").m(2).length;
}
class P376 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad376(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 376);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P376(n, "x").m(2).length;
}
class P377 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad377(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 377);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P377(n, "x").m(2).length;
}
class P378 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad378(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 378);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P378(n, "x").m(2).length;
}
class P379 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad379(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 379);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P379(n, "x").m(2).length;
}
class P380 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad380(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 380);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P380(n, "x").m(2).length;
}
class P381 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad381(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 381);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P381(n, "x").m(2).length;
}
class P382 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad382(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 382);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P382(n, "x").m(2).length;
}
class P383 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad383(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 383);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P383(n, "x").m(2).length;
}
class P384 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad384(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 384);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P384(n, "x").m(2).length;
}
class P385 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad385(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 385);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P385(n, "x").m(2).length;
}
class P386 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad386(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 386);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P386(n, "x").m(2).length;
}
class P387 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad387(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 387);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P387(n, "x").m(2).length;
}
class P388 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad388(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 388);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P388(n, "x").m(2).length;
}
class P389 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad389(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 389);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P389(n, "x").m(2).length;
}
class P390 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad390(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 390);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P390(n, "x").m(2).length;
}
class P391 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad391(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 391);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P391(n, "x").m(2).length;
}
class P392 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad392(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 392);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P392(n, "x").m(2).length;
}
class P393 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad393(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 393);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P393(n, "x").m(2).length;
}
class P394 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad394(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 394);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P394(n, "x").m(2).length;
}
class P395 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad395(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 395);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P395(n, "x").m(2).length;
}
class P396 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad396(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 396);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P396(n, "x").m(2).length;
}
class P397 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad397(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 397);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P397(n, "x").m(2).length;
}
class P398 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad398(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 398);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P398(n, "x").m(2).length;
}
class P399 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad399(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 399);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P399(n, "x").m(2).length;
}
class P400 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad400(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 400);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P400(n, "x").m(2).length;
}
class P401 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad401(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 401);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P401(n, "x").m(2).length;
}
class P402 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad402(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 402);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P402(n, "x").m(2).length;
}
class P403 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad403(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 403);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P403(n, "x").m(2).length;
}
class P404 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad404(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 404);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P404(n, "x").m(2).length;
}
class P405 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad405(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 405);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P405(n, "x").m(2).length;
}
class P406 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad406(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 406);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P406(n, "x").m(2).length;
}
class P407 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad407(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 407);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P407(n, "x").m(2).length;
}
class P408 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad408(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 408);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P408(n, "x").m(2).length;
}
class P409 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad409(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 409);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P409(n, "x").m(2).length;
}
class P410 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad410(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 410);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P410(n, "x").m(2).length;
}
class P411 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad411(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 411);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P411(n, "x").m(2).length;
}
class P412 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad412(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 412);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P412(n, "x").m(2).length;
}
class P413 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad413(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 413);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P413(n, "x").m(2).length;
}
class P414 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad414(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 414);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P414(n, "x").m(2).length;
}
class P415 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad415(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 415);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P415(n, "x").m(2).length;
}
class P416 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad416(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 416);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P416(n, "x").m(2).length;
}
class P417 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad417(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 417);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P417(n, "x").m(2).length;
}
class P418 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad418(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 418);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P418(n, "x").m(2).length;
}
class P419 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad419(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 419);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P419(n, "x").m(2).length;
}
class P420 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad420(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 420);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P420(n, "x").m(2).length;
}
class P421 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad421(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 421);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P421(n, "x").m(2).length;
}
class P422 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad422(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 422);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P422(n, "x").m(2).length;
}
class P423 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad423(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 423);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P423(n, "x").m(2).length;
}
class P424 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad424(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 424);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P424(n, "x").m(2).length;
}
class P425 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad425(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 425);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P425(n, "x").m(2).length;
}
class P426 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad426(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 426);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P426(n, "x").m(2).length;
}
class P427 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad427(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 427);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P427(n, "x").m(2).length;
}
class P428 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad428(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 428);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P428(n, "x").m(2).length;
}
class P429 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad429(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 429);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P429(n, "x").m(2).length;
}
class P430 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad430(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 430);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P430(n, "x").m(2).length;
}
class P431 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad431(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 431);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P431(n, "x").m(2).length;
}
class P432 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad432(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 432);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P432(n, "x").m(2).length;
}
class P433 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad433(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 433);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P433(n, "x").m(2).length;
}
class P434 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad434(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 434);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P434(n, "x").m(2).length;
}
class P435 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad435(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 435);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P435(n, "x").m(2).length;
}
class P436 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad436(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 436);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P436(n, "x").m(2).length;
}
class P437 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad437(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 437);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P437(n, "x").m(2).length;
}
class P438 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad438(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 438);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P438(n, "x").m(2).length;
}
class P439 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad439(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 439);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P439(n, "x").m(2).length;
}
class P440 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad440(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 440);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P440(n, "x").m(2).length;
}
class P441 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad441(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 441);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P441(n, "x").m(2).length;
}
class P442 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad442(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 442);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P442(n, "x").m(2).length;
}
class P443 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad443(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 443);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P443(n, "x").m(2).length;
}
class P444 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad444(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 444);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P444(n, "x").m(2).length;
}
class P445 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad445(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 445);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P445(n, "x").m(2).length;
}
class P446 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad446(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 446);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P446(n, "x").m(2).length;
}
class P447 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad447(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 447);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P447(n, "x").m(2).length;
}
class P448 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad448(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 448);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P448(n, "x").m(2).length;
}
class P449 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad449(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 449);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P449(n, "x").m(2).length;
}
class P450 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad450(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 450);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P450(n, "x").m(2).length;
}
class P451 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad451(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 451);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P451(n, "x").m(2).length;
}
class P452 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad452(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 452);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P452(n, "x").m(2).length;
}
class P453 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad453(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 453);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P453(n, "x").m(2).length;
}
class P454 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad454(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 454);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P454(n, "x").m(2).length;
}
class P455 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad455(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 455);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P455(n, "x").m(2).length;
}
class P456 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad456(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 456);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P456(n, "x").m(2).length;
}
class P457 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad457(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 457);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P457(n, "x").m(2).length;
}
class P458 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad458(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 458);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P458(n, "x").m(2).length;
}
class P459 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad459(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 459);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P459(n, "x").m(2).length;
}
class P460 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad460(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 460);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P460(n, "x").m(2).length;
}
class P461 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad461(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 461);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P461(n, "x").m(2).length;
}
class P462 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad462(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 462);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P462(n, "x").m(2).length;
}
class P463 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad463(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 463);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P463(n, "x").m(2).length;
}
class P464 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad464(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 464);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P464(n, "x").m(2).length;
}
class P465 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad465(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 465);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P465(n, "x").m(2).length;
}
class P466 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad466(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 466);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P466(n, "x").m(2).length;
}
class P467 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad467(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 467);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P467(n, "x").m(2).length;
}
class P468 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad468(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 468);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P468(n, "x").m(2).length;
}
class P469 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad469(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 469);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P469(n, "x").m(2).length;
}
class P470 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad470(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 470);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P470(n, "x").m(2).length;
}
class P471 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad471(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 471);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P471(n, "x").m(2).length;
}
class P472 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad472(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 472);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P472(n, "x").m(2).length;
}
class P473 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad473(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 473);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P473(n, "x").m(2).length;
}
class P474 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad474(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 474);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P474(n, "x").m(2).length;
}
class P475 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad475(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 475);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P475(n, "x").m(2).length;
}
class P476 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad476(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 476);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P476(n, "x").m(2).length;
}
class P477 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad477(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 477);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P477(n, "x").m(2).length;
}
class P478 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad478(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 478);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P478(n, "x").m(2).length;
}
class P479 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad479(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 479);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P479(n, "x").m(2).length;
}
class P480 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad480(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 480);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P480(n, "x").m(2).length;
}
class P481 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad481(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 481);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P481(n, "x").m(2).length;
}
class P482 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad482(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 482);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P482(n, "x").m(2).length;
}
class P483 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad483(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 483);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P483(n, "x").m(2).length;
}
class P484 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad484(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 484);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P484(n, "x").m(2).length;
}
class P485 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad485(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 485);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P485(n, "x").m(2).length;
}
class P486 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad486(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 486);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P486(n, "x").m(2).length;
}
class P487 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad487(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 487);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P487(n, "x").m(2).length;
}
class P488 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad488(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 488);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P488(n, "x").m(2).length;
}
class P489 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad489(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 489);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P489(n, "x").m(2).length;
}
class P490 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad490(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 490);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P490(n, "x").m(2).length;
}
class P491 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad491(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 491);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P491(n, "x").m(2).length;
}
class P492 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad492(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 492);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P492(n, "x").m(2).length;
}
class P493 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad493(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 493);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P493(n, "x").m(2).length;
}
class P494 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad494(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 494);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P494(n, "x").m(2).length;
}
class P495 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad495(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 495);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P495(n, "x").m(2).length;
}
class P496 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad496(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 496);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P496(n, "x").m(2).length;
}
class P497 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad497(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 497);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P497(n, "x").m(2).length;
}
class P498 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad498(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 498);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P498(n, "x").m(2).length;
}
class P499 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad499(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 499);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P499(n, "x").m(2).length;
}
class P500 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad500(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 500);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P500(n, "x").m(2).length;
}
class P501 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad501(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 501);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P501(n, "x").m(2).length;
}
class P502 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad502(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 502);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P502(n, "x").m(2).length;
}
class P503 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad503(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 503);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P503(n, "x").m(2).length;
}
class P504 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad504(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 504);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P504(n, "x").m(2).length;
}
class P505 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad505(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 505);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P505(n, "x").m(2).length;
}
class P506 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad506(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 506);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P506(n, "x").m(2).length;
}
class P507 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad507(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 507);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P507(n, "x").m(2).length;
}
class P508 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad508(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 508);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P508(n, "x").m(2).length;
}
class P509 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad509(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 509);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P509(n, "x").m(2).length;
}
class P510 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad510(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 510);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P510(n, "x").m(2).length;
}
class P511 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad511(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 511);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P511(n, "x").m(2).length;
}
class P512 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad512(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 512);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P512(n, "x").m(2).length;
}
class P513 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad513(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 513);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P513(n, "x").m(2).length;
}
class P514 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad514(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 514);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P514(n, "x").m(2).length;
}
class P515 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad515(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 515);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P515(n, "x").m(2).length;
}
class P516 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad516(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 516);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P516(n, "x").m(2).length;
}
class P517 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad517(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 517);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P517(n, "x").m(2).length;
}
class P518 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad518(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 518);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P518(n, "x").m(2).length;
}
class P519 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad519(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 519);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P519(n, "x").m(2).length;
}
class P520 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad520(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 520);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P520(n, "x").m(2).length;
}
class P521 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad521(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 521);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P521(n, "x").m(2).length;
}
class P522 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad522(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 522);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P522(n, "x").m(2).length;
}
class P523 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad523(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 523);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P523(n, "x").m(2).length;
}
class P524 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad524(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 524);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P524(n, "x").m(2).length;
}
class P525 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad525(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 525);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P525(n, "x").m(2).length;
}
class P526 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad526(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 526);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P526(n, "x").m(2).length;
}
class P527 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad527(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 527);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P527(n, "x").m(2).length;
}
class P528 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad528(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 528);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P528(n, "x").m(2).length;
}
class P529 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad529(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 529);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P529(n, "x").m(2).length;
}
class P530 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad530(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 530);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P530(n, "x").m(2).length;
}
class P531 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad531(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 531);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P531(n, "x").m(2).length;
}
class P532 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad532(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 532);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P532(n, "x").m(2).length;
}
class P533 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad533(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 533);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P533(n, "x").m(2).length;
}
class P534 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad534(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 534);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P534(n, "x").m(2).length;
}
class P535 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad535(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 535);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P535(n, "x").m(2).length;
}
class P536 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad536(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 536);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P536(n, "x").m(2).length;
}
class P537 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad537(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 537);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P537(n, "x").m(2).length;
}
class P538 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad538(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 538);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P538(n, "x").m(2).length;
}
class P539 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad539(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 539);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P539(n, "x").m(2).length;
}
class P540 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad540(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 540);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P540(n, "x").m(2).length;
}
class P541 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad541(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 541);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P541(n, "x").m(2).length;
}
class P542 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad542(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 542);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P542(n, "x").m(2).length;
}
class P543 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad543(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 543);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P543(n, "x").m(2).length;
}
class P544 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad544(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 544);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P544(n, "x").m(2).length;
}
class P545 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad545(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 545);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P545(n, "x").m(2).length;
}
class P546 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad546(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 546);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P546(n, "x").m(2).length;
}
class P547 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad547(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 547);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P547(n, "x").m(2).length;
}
class P548 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad548(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 548);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P548(n, "x").m(2).length;
}
class P549 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad549(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 549);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P549(n, "x").m(2).length;
}
class P550 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad550(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 550);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P550(n, "x").m(2).length;
}
class P551 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad551(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 551);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P551(n, "x").m(2).length;
}
class P552 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad552(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 552);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P552(n, "x").m(2).length;
}
class P553 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad553(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 553);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P553(n, "x").m(2).length;
}
class P554 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad554(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 554);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P554(n, "x").m(2).length;
}
class P555 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad555(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 555);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P555(n, "x").m(2).length;
}
class P556 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad556(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 556);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P556(n, "x").m(2).length;
}
class P557 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad557(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 557);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P557(n, "x").m(2).length;
}
class P558 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad558(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 558);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P558(n, "x").m(2).length;
}
class P559 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad559(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 559);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P559(n, "x").m(2).length;
}
class P560 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad560(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 560);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P560(n, "x").m(2).length;
}
class P561 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad561(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 561);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P561(n, "x").m(2).length;
}
class P562 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad562(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 562);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P562(n, "x").m(2).length;
}
class P563 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad563(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 563);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P563(n, "x").m(2).length;
}
class P564 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad564(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 564);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P564(n, "x").m(2).length;
}
class P565 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad565(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 565);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P565(n, "x").m(2).length;
}
class P566 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad566(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 566);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P566(n, "x").m(2).length;
}
class P567 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad567(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 567);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P567(n, "x").m(2).length;
}
class P568 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad568(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 568);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P568(n, "x").m(2).length;
}
class P569 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad569(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 569);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P569(n, "x").m(2).length;
}
class P570 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad570(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 570);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P570(n, "x").m(2).length;
}
class P571 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad571(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 571);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P571(n, "x").m(2).length;
}
class P572 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad572(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 572);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P572(n, "x").m(2).length;
}
class P573 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad573(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 573);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P573(n, "x").m(2).length;
}
class P574 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad574(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 574);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P574(n, "x").m(2).length;
}
class P575 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad575(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 575);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P575(n, "x").m(2).length;
}
class P576 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad576(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 576);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P576(n, "x").m(2).length;
}
class P577 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad577(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 577);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P577(n, "x").m(2).length;
}
class P578 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad578(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 578);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P578(n, "x").m(2).length;
}
class P579 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad579(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 579);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P579(n, "x").m(2).length;
}
class P580 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad580(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 580);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P580(n, "x").m(2).length;
}
class P581 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad581(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 581);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P581(n, "x").m(2).length;
}
class P582 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad582(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 582);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P582(n, "x").m(2).length;
}
class P583 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad583(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 583);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P583(n, "x").m(2).length;
}
class P584 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad584(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 584);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P584(n, "x").m(2).length;
}
class P585 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad585(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 585);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P585(n, "x").m(2).length;
}
class P586 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad586(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 586);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P586(n, "x").m(2).length;
}
class P587 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad587(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 587);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P587(n, "x").m(2).length;
}
class P588 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad588(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 588);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P588(n, "x").m(2).length;
}
class P589 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad589(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 589);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P589(n, "x").m(2).length;
}
class P590 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad590(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 590);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P590(n, "x").m(2).length;
}
class P591 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad591(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 591);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P591(n, "x").m(2).length;
}
class P592 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad592(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 592);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P592(n, "x").m(2).length;
}
class P593 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad593(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 593);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P593(n, "x").m(2).length;
}
class P594 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad594(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 594);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P594(n, "x").m(2).length;
}
class P595 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad595(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 595);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P595(n, "x").m(2).length;
}
class P596 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad596(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 596);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P596(n, "x").m(2).length;
}
class P597 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad597(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 597);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P597(n, "x").m(2).length;
}
class P598 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad598(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 598);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P598(n, "x").m(2).length;
}
class P599 {
  constructor(public a: number, public b: string) {}
  m(x: number): string {
    let s = this.b;
    for (let k = 0; k < x; k++) {
      s += String(this.a + k);
    }
    return s.length > 3 ? s.slice(0, 3) : s;
  }
}
function pad599(n: number): number {
  const arr: number[] = [];
  for (let k = 0; k < n; k++) arr.push(k * 599);
  return arr.filter((v) => v % 2 === 0).map((v) => v + 1).reduce((a, b) => a + b, 0) + new P599(n, "x").m(2).length;
}
