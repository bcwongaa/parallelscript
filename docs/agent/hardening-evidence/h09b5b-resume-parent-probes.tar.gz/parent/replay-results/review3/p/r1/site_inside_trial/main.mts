// Review H09b5b r1: the call_site trigger (an interface call by name whose AllInstances lowering
// fails at its own site) inside a local arrow's instance body. The report is the trial's own, so
// the trial is taken back silently and use's call keeps the erased copy, at AllInstances, where
// ValueInstances (no demands by name) would keep la's instance. Base and fix alike (pre-existing).
class Box<T> {
  constructor(public value: T) {}
}
interface M {
  f<T>(a?: number, ...xs: T[]): Box<T[]>;
}
class CM implements M {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
}
function maybe(): number | undefined {
  return undefined;
}
const m: M = new CM();
function use(g: <T>(x: T) => Box<T>): number {
  return g(5).value + 1;
}
function main(): void {
  const la = <T>(x: T): Box<T> => {
    try {
      const b: Box<T[]> = m.f(maybe(), x);
      console.log("inner", b.value.length);
    } catch (e: any) {
      console.log("inner", 1);
    }
    return new Box(x);
  };
  console.log("value call", use(la));
}
main();
