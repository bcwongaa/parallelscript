// Review H09b5b r2 (the working tree's removal of reportInstanceLimit's making++): a total met by
// a trial's own instance whose demand is in the program's own code. f is the program's own direct
// polymorphic recursion (one root per type, 6 of them); each of its instances calls the generic
// value g, a demand paired with the local arrow rec, which recurses through g too. Together the
// roots' trees reach rec's total (1024, D-198); a later trial for a demand in an f instance
// (the program's own code) is past it. With making++ that report is the trial's (its pairing,
// which ValueInstances makes too); without it, it is the code the demand is in, the program's own.
class Box<T> {
  constructor(public value: T) {}
}
let g: <U>(x: U, n: number) => Box<U>;
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function f<T>(x: T, n: number): number {
  if (n > 0) {
    f<[T]>([x], n - 1);
  }
  return g(x, 1).value === x ? 1 : 0;
}
function main(): void {
  const rec = <U,>(x: U, n: number): Box<U> => {
    if (n > 0) {
      g<[U]>([x], n - 1);
      g<{ v: U }>({ v: x }, n - 1);
    }
    return new Box(x);
  };
  g = rec;
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  attempt("root0", () => f({ k0: 0 }, 2));
  attempt("root1", () => f({ k1: 1 }, 2));
  attempt("root2", () => f({ k2: 2 }, 2));
  attempt("root3", () => f({ k3: 3 }, 2));
  attempt("root4", () => f({ k4: 4 }, 2));
  attempt("root5", () => f({ k5: 5 }, 2));
}
main();
