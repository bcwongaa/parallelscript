// Review H09b5b r2 (the working tree's removal of reportInstanceLimit's making++): a total met by
// a trial's own instance for a demand in the program's own code. f1 and f2 are the program's own
// linear polymorphic recursions (9 roots each, 64 instances deep at compile time: 1,152
// instances, under each one's total); each instance calls the generic value g, a demand paired with
// the local arrow rec, whose instance there is recursion's (its chain repeats f1 or f2), so the
// 1,152 trials reach rec's total (1024, D-198), and the trials after it, for demands in the program's
// own f instances, are past it, reported by tryInstance. With making++ that report is the trial's
// pairing (ValueInstances makes it too, and leaves it out there); without it, it is the program's own.
class Box<T> {
  constructor(public value: T) {}
}
let g: <U>(x: U) => Box<U>;
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function f1<T>(x: T, n: number): number {
  if (n > 0) {
    f1<[T]>([x], n - 1);
  }
  return g(x).value === x ? 1 : 0;
}
function f2<T>(x: T, n: number): number {
  if (n > 0) {
    f2<[T]>([x], n - 1);
  }
  return g(x).value === x ? 1 : 0;
}
function main(): void {
  const rec = <U,>(x: U): Box<U> => new Box(x);
  g = rec;
  const maker: Maker = new ClassMaker();
  attempt("interface victim", () => maker.make(4).value + 1);
  attempt("f1 root0", () => f1({ k0: 0 }, 0));
  attempt("f1 root1", () => f1({ k1: 1 }, 0));
  attempt("f1 root2", () => f1({ k2: 2 }, 0));
  attempt("f1 root3", () => f1({ k3: 3 }, 0));
  attempt("f1 root4", () => f1({ k4: 4 }, 0));
  attempt("f1 root5", () => f1({ k5: 5 }, 0));
  attempt("f1 root6", () => f1({ k6: 6 }, 0));
  attempt("f1 root7", () => f1({ k7: 7 }, 0));
  attempt("f1 root8", () => f1({ k8: 8 }, 0));
  attempt("f2 root0", () => f2({ j9: 9 }, 0));
  attempt("f2 root1", () => f2({ j10: 10 }, 0));
  attempt("f2 root2", () => f2({ j11: 11 }, 0));
  attempt("f2 root3", () => f2({ j12: 12 }, 0));
  attempt("f2 root4", () => f2({ j13: 13 }, 0));
  attempt("f2 root5", () => f2({ j14: 14 }, 0));
  attempt("f2 root6", () => f2({ j15: 15 }, 0));
  attempt("f2 root7", () => f2({ j16: 16 }, 0));
  attempt("f2 root8", () => f2({ j17: 17 }, 0));
}
main();
