// Review H09b5b r1: the call_site test's trigger (an optional argument before a rest parameter,
// `converting boolean to given` in the interface call's demand by name) written with a constant
// key, m["f"]. AllInstances blames the call site; lowered again without it, the site's call reads
// m["f"] as a generic function value and calls it, whose demand with a rest parameter fails too
// (own). ValueInstances is then lowered with the site still left out (the same failure), where
// the base's ValueInstances lowered the constant-key call as m.f and compiled; the build ends at
// DeclaredInstances and the unrelated local arrow `named` loses its instance.
class Box<T> {
  constructor(public value: T) {}
}
interface M {
  f<T>(a?: number, ...xs: T[]): Box<T[]>;
}
class CM implements M {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
}
function maybe(): number | undefined {
  return undefined;
}
function main(): void {
  const named = <T>(x: T): Box<T> => new Box(x);
  try {
    const b: Box<number> = named(5);
    console.log("victim", b.value + 1);
  } catch (e: any) {
    console.log("victim threw", e.message);
  }
  const m: M = new CM();
  try {
    const b: Box<number[]> = m["f"](maybe(), 1, 2);
    console.log("trigger ran", b.value.length);
  } catch (error: any) {
    console.log("trigger ran", 2);
  }
}
main();
