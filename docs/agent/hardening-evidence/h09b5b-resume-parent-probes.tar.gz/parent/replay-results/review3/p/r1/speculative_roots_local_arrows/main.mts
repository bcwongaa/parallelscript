// Review H09b5b r1 variant: r0..r2 are function-local generic arrows (ValueInstances' pairings,
// narrowable) calling declared branching recursions. Original:
// 3 branching polymorphic recursions passed as values of one generic function type and 6 typed calls
// through that type for 6 base types: specialize pairs every call with every value (D-190), each
// trial's instance a root of its own, so up to 3 x 6 trees of up to 256 instances per declaration,
// of which the program runs 6. It recurses 3 levels at run time.
class Box<T> {
  constructor(public value: T) {}
}
function d0<T>(x: T, n: number): Box<T> {
  if (n > 0) {
    d0<[T]>([x], n - 1);
    d0<{ v: T }>({ v: x }, n - 1);
  }
  return new Box(x);
}
function d1<T>(x: T, n: number): Box<T> {
  if (n > 0) {
    d1<[T]>([x], n - 1);
    d1<{ v: T }>({ v: x }, n - 1);
  }
  return new Box(x);
}
function d2<T>(x: T, n: number): Box<T> {
  if (n > 0) {
    d2<[T]>([x], n - 1);
    d2<{ v: T }>({ v: x }, n - 1);
  }
  return new Box(x);
}
function use(g: <T>(x: T, n: number) => Box<T>): number {
  let s = 0;
  s += g({ k0: 0 }, 3).value.k0;
  s += g({ k1: 1 }, 3).value.k1;
  s += g({ k2: 2 }, 3).value.k2;
  s += g({ k3: 3 }, 3).value.k3;
  s += g({ k4: 4 }, 3).value.k4;
  s += g({ k5: 5 }, 3).value.k5;
  return s;
}
function main(): void {
  const r0 = <T,>(x: T, n: number): Box<T> => d0(x, n);
  const r1 = <T,>(x: T, n: number): Box<T> => d1(x, n);
  const r2 = <T,>(x: T, n: number): Box<T> => d2(x, n);
  const all: unknown[] = [r1, r2];
  console.log(use(r0), all.length);
}
main();
