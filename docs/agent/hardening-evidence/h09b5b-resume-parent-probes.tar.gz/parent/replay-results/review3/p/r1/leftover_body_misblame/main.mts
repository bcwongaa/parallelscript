// Review H09b5b r1: a failed trial's leftover erased copy, lowered in the next trial, records that
// trial on the class instance it makes. The demand by name hm.hold (AllInstances' alone, never run)
// pairs with HolderMaker's hold; its instance for Dog[] doesn't fit (Holder<Dog[]> where a
// Box<Dog[]> goes), so the trial is taken back before lowering its pending bodies, but Holder<Dog[]>
// stays, and the erased copy of its make, queued, is lowered by the next trial, the victim's
// (named(5) with named), which then makes Weird<Dog[]> (D-094: its method doesn't lower). The
// report is blamed on the victim's pairing, which is left out. Base: AllInstances fails,
// ValueInstances (no demands by name) compiles with named's instance.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
abstract class Maker {
  abstract make<U>(u: U): Box<U>;
}
class Holder<T> extends Maker {
  constructor(public value: T) {
    super();
  }
  make<U>(u: U): Box<U> {
    const w = new Weird(this.value);
    console.log("weird", w.animals().length);
    return new Box(u);
  }
}
class Plain extends Maker {
  make<U>(u: U): Box<U> {
    return new Box(u);
  }
}
interface HM {
  hold<T>(x: T): Box<T>;
}
class HolderMaker implements HM {
  hold<T>(x: T): Holder<T> {
    return new Holder(x);
  }
}
const hm: HM = new HolderMaker();
if (process.argv.length > 100) {
  console.log("never", hm.hold([new Dog()]).value.length);
}
function main(): void {
  const named = <T>(x: T): Box<T> => new Box(x);
  try {
    const b: Box<number> = named(5);
    console.log("victim", b.value + 1);
  } catch (e: any) {
    console.log("victim threw", e.message);
  }
  const m: Maker = new Plain();
  console.log("dispatched", m.make(7).value + 1);
}
main();
