// Review H09b5b r2: statementSites inside a trial. Bad.make<Dog[]> (only m.make's demand by name
// makes it, paired speculatively; m is never a Bad) has a statement whose first call is a value
// call with a rest parameter (a demandSite, which lowers fine), after which the same statement
// passes the Dog[] as a kept Animal[] (D-094), the trial's own failure. On the base the trial is
// taken back and the build stays at AllInstances. With statementSites preceding the trial, the
// report is the site's, stands (atSites), and can't be left out (Within: ValueInstances never
// makes that instance), so the build falls back to ValueInstances and m.make loses its instance.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
const kept: Animal[][] = [];
function keepAnimals(a: Animal[]): number {
  kept.push(a);
  return a.length;
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Good implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Bad implements Maker {
  make<T>(x: T): Box<T> {
    const g = <U,>(a: number, ...xs: U[]): Box<U[]> => new Box(xs);
    console.log("bad", g(1, x).value.length, Array.isArray(x) ? keepAnimals(x) : 0);
    return new Box(x);
  }
}
const makers: Maker[] = [new Good(), new Bad()];
const m: Maker = makers[0];
console.log("by name", m.make([new Dog()]).value.length);
