// Review H09b5b r2: a value call with a rest parameter (a demandSite, which ValueInstances makes
// too) fails at its own site (optional-before-rest: `converting boolean to given`) inside an
// instance only a demand by name makes (Bad.make<number>, paired speculatively with m.make's
// demand; m is never a Bad). On the base the trial owns the report and is taken back: the build
// stays at AllInstances and m.make(4) keeps Good.make's instance. With atSites the report stands;
// the site's level is ValueInstances, which never lowers that instance, so Within fails and the
// whole build falls back to ValueInstances, where m.make(4) has no instance.
class Box<T> {
  constructor(public value: T) {}
}
function maybe(): number | undefined {
  return undefined;
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Good implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Bad implements Maker {
  make<T>(x: T): Box<T> {
    const g = <U,>(a?: number, ...xs: U[]): Box<U[]> => new Box(xs);
    try {
      const b: Box<T[]> = g(maybe(), x);
      console.log("bad", b.value.length);
    } catch (e: any) {
      console.log("bad", 1);
    }
    return new Box(x);
  }
}
const makers: Maker[] = [new Good(), new Bad()];
const m: Maker = makers[0];
console.log("by name", m.make(4).value + 1);
