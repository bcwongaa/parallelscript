// Review H09b5b r1 probe: a constant-key call through a union of classes whose AllInstances
// lowering fails at its own site (the call_site test's optional-before-rest trigger).
class Box<T> {
  constructor(public value: T) {}
}
class C1 {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
}
class C2 {
  f<T>(a?: number, ...xs: T[]): Box<T[]> {
    return new Box(xs);
  }
}
function maybe(): number | undefined {
  return undefined;
}
const u: C1 | C2 = Math.random() > 2 ? new C2() : new C1();
const b: Box<number[]> = u["f"](maybe(), 1, 2);
console.log(b.value.length);
