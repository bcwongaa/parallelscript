// Review H09b5b r1: the program's own relaxed cast (D-066) of a Base to Tagged fails only because a
// trial (use's demand paired with the escaping arrow mk, a pairing the last fallback doesn't make)
// made Sub<number>, a subclass of Base that holds `tag` as a number. The report is blamed on where
// the cast was made (the program's own code), so it stands: the whole build falls back and the
// unrelated arrow `named` loses its instance, as on the base.
class Box<T> {
  constructor(public value: T) {}
}
interface Tagged {
  id: number;
  tag?: string;
}
class Base {
  id = 1;
}
class Sub<T> extends Base {
  constructor(public tag: T) {
    super();
  }
}
function use(f: <T>(x: T) => Box<T>): void {
  const b: Box<number> = f(3);
  console.log("used", b.value);
}
function main(): void {
  const named = <T>(x: T): Box<T> => new Box(x);
  try {
    const b: Box<number> = named(5);
    console.log("victim", b.value + 1);
  } catch (e: any) {
    console.log("victim threw", e.message);
  }
  const mk = <T>(x: T): Box<T> => {
    const s = new Sub(x);
    return new Box(x);
  };
  const d: any = mk;
  console.log("mk", d(1).value);
  const base: Base = new Base();
  const t: Tagged = base;
  console.log("tagged", t.id);
  use(named);
}
main();
