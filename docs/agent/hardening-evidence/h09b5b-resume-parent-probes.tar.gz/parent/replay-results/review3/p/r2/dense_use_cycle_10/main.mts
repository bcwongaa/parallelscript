// Review H09b5b r2: blameOf over a dense cycle of uses: 10 generic declarations that all call
// each other (one instance each per type, a strongly connected use graph), each making Weird<T>,
// whose method fails for Dog[] (D-094). Only the local arrow la's speculative pairing with use's
// demand makes the Dog[] instances; it should be left out, the victims keeping theirs.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function f0<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f1<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f2<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f3<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f4<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f5<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f6<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f7<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f8(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f8<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f9(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function f9<T>(x: T, k: number): Box<T> {
  if (k > 0) {
    f0(x, k - 1);
    f1(x, k - 1);
    f2(x, k - 1);
    f3(x, k - 1);
    f4(x, k - 1);
    f5(x, k - 1);
    f6(x, k - 1);
    f7(x, k - 1);
    f8(x, k - 1);
  }
  const w = new Weird<T>(x);
  if (k < -100) console.log(w.animals().length);
  return new Box(x);
}
function use(f: <T>(x: T) => Box<T>): void {
  const b: Box<Dog[]> = f([new Dog()]);
  console.log("dogs", b.value.length);
}
function main(): void {
  const maker: Maker = new ClassMaker();
  console.log("interface victim", maker.make(4).value + 1);
  const named = <T,>(x: T): Box<T> => new Box(x);
  console.log("value victim", named(5).value + 1);
  const la = <T,>(x: T): Box<T> => f0(x, 0);
  const d: any = la;
  console.log("la", d(3).value);
  console.log("direct", f0(7, 1).value);
  use(named);
}
main();
