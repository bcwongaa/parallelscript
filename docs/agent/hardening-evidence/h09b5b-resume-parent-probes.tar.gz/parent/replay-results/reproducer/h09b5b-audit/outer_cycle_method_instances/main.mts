// H09b5b audit: Holder<T>.make and Peer<T>.make use each other's class instances.
// Their dispatched pairings exist at every fallback, but each Dog[] outer class
// exists only through speculative arrow pairings and must not cost the victim.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const value = this.value;
    if (Array.isArray(value)) return value;
    return [];
  }
}
abstract class Maker {
  abstract make<U>(u: U): Box<U>;
}
class Holder<T> extends Maker {
  constructor(public value: T) { super(); }
  make<U>(u: U): Box<U> {
    const peer = new Peer(this.value);
    const again = new Holder(peer.value);
    const weird = new Weird(again.value);
    console.log("holder weird", weird.animals().length);
    return new Box(u);
  }
}
class Peer<T> extends Maker {
  constructor(public value: T) { super(); }
  make<U>(u: U): Box<U> {
    const holder = new Holder(this.value);
    const again = new Peer(holder.value);
    const weird = new Weird(again.value);
    console.log("peer weird", weird.animals().length);
    return new Box(u);
  }
}
class Plain extends Maker {
  make<U>(u: U): Box<U> { return new Box(u); }
}
function use(f: <T>(x: T) => Box<T>): void {
  const dogs: Box<Dog[]> = f([new Dog()]);
  console.log("dogs", dogs.value.length);
}
function main(): void {
  const victim = <T,>(x: T): Box<T> => new Box(x);
  try {
    const b: Box<number> = victim(5);
    console.log("victim", b.value + 1);
  } catch (error: any) {
    console.log("victim", error.name, error.message);
  }
  const holder = <T,>(x: T): Holder<T> => new Holder(x);
  const peer = <T,>(x: T): Peer<T> => new Peer(x);
  const dynamicHolder: any = holder;
  const dynamicPeer: any = peer;
  console.log("holder", dynamicHolder(1).value);
  console.log("peer", dynamicPeer(2).value);
  const maker: Maker = new Plain();
  console.log("dispatched", maker.make(7).value + 1);
  use(victim);
}
main();
// expect:
// victim 6
// holder 1
// peer 2
// dispatched 8
// dogs 1
