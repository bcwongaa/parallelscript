// H09b5b audit: a constant-key call succeeds before the trial's own later failure.
// That failure must take back the trial, not remove this call site from f<number>.
class Box<T> {
  constructor(public value: T) {}
}
class Animal { name = "a"; }
class Dog extends Animal { bark = 1; }
interface Maker { make<T>(x: T): Box<T>; }
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> { return new Box(x); }
}
const maker: Maker = new ClassMaker();
const kept: Animal[][] = [];
function keepAnimals(animals: Animal[]): number {
  kept.push(animals);
  return animals.length;
}
function f<X>(x: X): number {
  return maker["make"](4).value + (Array.isArray(x) ? keepAnimals(x) : 0);
}
function useDogs(g: <T>(x: T) => Box<T>): number {
  const dogs: Box<Dog[]> = g([new Dog()]);
  return dogs.value.length;
}
function main(): void {
  try {
    console.log("own", f(2));
  } catch (error: any) {
    console.log("own", error.name, error.message);
  }
  const w = <T,>(x: T): Box<T> => {
    f(x);
    return new Box(x);
  };
  const dynamic: any = w;
  console.log("dynamic", dynamic(3).value);
  const good = <T,>(x: T): Box<T> => new Box(x);
  console.log("dogs", useDogs(good));
}
main();
// expect:
// own 4
// dynamic 3
// dogs 1
