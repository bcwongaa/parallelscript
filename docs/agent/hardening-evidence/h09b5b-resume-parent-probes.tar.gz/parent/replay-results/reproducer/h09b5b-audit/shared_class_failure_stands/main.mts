// H09b5b audit guard: Weird<Dog[]> is used by both a speculative pairing and the
// program's own code. Every fallback's class-body error must stand.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const value = this.value;
    if (Array.isArray(value)) return value;
    return [];
  }
}
function relay<X>(f: <T>(x: T) => Box<T>, x: X): Box<X> {
  return f(x);
}
function main(): void {
  const w = <T,>(x: T): Weird<T> => new Weird(x);
  const dynamic: any = w;
  console.log(dynamic(1).animals().length);
  const good = <T,>(x: T): Box<T> => new Box(x);
  console.log(relay(good, [new Dog()]).value.length);
  const owned = new Weird([new Dog()]);
  console.log(owned.animals().length);
}
main();
// error: PTS1001
// error: using a Dog[] as a Animal[] where it may be changed or kept
