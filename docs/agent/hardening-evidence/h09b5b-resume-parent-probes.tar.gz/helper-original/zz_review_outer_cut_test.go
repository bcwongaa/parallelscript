package lower

import "testing"

// TestReviewOuterCutMustUnmakeItsRoot is a five-node reduction of the retained
// review3 seed-3 graph. All outer edges point to one class substitution, all
// users are distinct from their node, and program-own nodes have no users.
func TestReviewOuterCutMustUnmakeItsRoot(t *testing.T) {
	p := pairing{name: "P", level: AllInstances}
	root := &substitution{used: true}
	helper := &substitution{used: true}
	method := &substitution{used: true, ownUse: true}
	class := &substitution{used: true}
	own := &substitution{used: true, ownUse: true}
	root.outer, method.outer = class, class
	root.users = []use{{subst: helper}}
	helper.users = []use{{subst: method}, {subst: own}}
	class.users = []use{{pairings: []pairing{p}}, {subst: helper}}
	nodes := []*substitution{root, helper, method, class, own}

	// Independent monotone reachability, not the implementation being tested:
	// a node needs any surviving source AND its outer (if it has one).
	made := func(removed map[pairing]bool) bool {
		live := map[*substitution]bool{}
		for changed := true; changed; {
			changed = false
			for _, s := range nodes {
				if live[s] {
					continue
				}
				source := s.ownUse
				for _, u := range s.users {
					if u.pairings != nil {
						for _, pair := range u.pairings {
							source = source || !removed[pair]
						}
					} else if u.subst != nil {
						source = source || live[u.subst]
					} else {
						source = true
					}
				}
				if source && (s.outer == nil || live[s.outer]) {
					live[s], changed = true, true
				}
			}
		}
		return live[root]
	}
	if !made(nil) || !made(map[pairing]bool{p: true}) {
		t.Fatal("invalid review graph: root must survive with all pairings removed")
	}
	b, _ := (&lowerer{}).blameOf(use{subst: root}, newBlames())
	removed := map[pairing]bool{}
	for _, pair := range b.pairings {
		removed[pair] = true
	}
	if !b.own && made(removed) {
		t.Fatalf("insufficient cut: blameOf returned own=%v, pairings=%v, but root is still made", b.own, b.pairings)
	}
}
