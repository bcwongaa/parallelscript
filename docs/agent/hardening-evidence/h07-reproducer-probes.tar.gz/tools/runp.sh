#!/usr/bin/env bash
# Builds a .pts program with the worktree's CLI and runtime and runs it under each
# PTS_THREADS given, RUNS times each (default 1), printing stdout+stderr and exit codes.
# Usage: runp.sh <file.pts> <threads...>
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a812d2515ec2b93a8
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
src=$1
shift
exe=/tmp/h07-repro/bin-out/$(basename "${src%.pts}")
mkdir -p /tmp/h07-repro/bin-out
PTS_HOME=$W "${CLI:-$W/pts-bin/pts}" build "$src" -o "$exe"
built=$?
echo "build exit=$built"
if [ "$built" -ne 0 ]; then
  exit "$built"
fi
for t in "$@"; do
  for ((r = 1; r <= ${RUNS:-1}; r++)); do
    echo "-- PTS_THREADS=$t run $r"
    start=$(date +%s.%N)
    PTS_THREADS=$t timeout ${TIMEOUT:-60} "$exe" 2>&1 | head -${LINES_MAX:-40}
    status=${PIPESTATUS[0]}
    echo "exit=$status elapsed=$(echo "$(date +%s.%N) - $start" | bc)s"
  done
done
