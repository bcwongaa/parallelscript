#!/usr/bin/env python3
"""Summarise a run_probes.py JSON record: per probe and thread count, how many runs
differ from Node and, for each distinct outcome, its count, exit code and stdout lines
(shortened). Usage: summarize.py probes.json [max_outcomes]"""
import json
import sys

record = json.load(open(sys.argv[1]))
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 4
print("source", record["source_sha"], "cli", record["cli_sha256"][:16], "PTS_HOME", record.get("pts_home", "?"))
for result in record["results"]:
    name = result["probe"].rsplit("/", 1)[-1]
    print(f"== {name}: {result['outcome']} as_expected={result['as_expected']}")
    print("   node:", result["node"]["stdout"].strip().replace("\n", " | ")[:200])
    if result["build"]["exit"] != 0:
        print("   build failed:", result["build"]["stderr"][:400])
    for per in result["pts_runs"]:
        print(f"   {per['threads']}t: {per['runs_not_matching_node']}/{per['runs']} runs differ from Node; {len(per['outcomes'])} distinct outcomes")
        for group in per["outcomes"][:limit]:
            sample = group["sample"]
            out = sample["stdout"].strip().replace("\n", " | ")[:260]
            err = sample["stderr"].strip().splitlines()
            err_text = (" stderr: " + err[0][:160]) if err else ""
            print(f"      x{group['count']} exit={sample['exit']} match={group['matches_node']}: {out}{err_text}")
