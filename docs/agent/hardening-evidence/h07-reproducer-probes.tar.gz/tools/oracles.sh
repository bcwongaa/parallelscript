#!/usr/bin/env bash
# Runs each given .mts oracle under the LTS Node, printing its stdout and exit code.
set -u
export PATH=$HOME/.local/node/bin:$PATH
for f in "$@"; do
  echo "== $(basename "$f")"
  node --no-warnings --experimental-transform-types "$f"
  echo "exit=$?"
done
