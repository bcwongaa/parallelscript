#!/usr/bin/env bash
# Runs a focused `go test` of ./pts/tests/ in the worktree (GOMAXPROCS=2, -count=1, -v)
# and writes its output and exit code to OUT. Usage: gotest.sh <run-pattern> <out-file>
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a812d2515ec2b93a8
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
pattern=$1
out=$2
mkdir -p "$(dirname "$out")"
cd "$W" || exit 1
echo "+ GOMAXPROCS=2 go test -count=${COUNT:-1} -v -run '$pattern' ./pts/tests/" > "$out"
start=$(date +%s)
GOMAXPROCS=2 go test -count=${COUNT:-1} -v -run "$pattern" ./pts/tests/ >> "$out" 2>&1
status=$?
echo "exit=$status elapsed=$(( $(date +%s) - start ))s" >> "$out"
exit $status
