#!/usr/bin/env bash
# The final record runs: every H07 probe and H01b C07 probe on the base CLI, then on the
# throwaway candidate CLI (both with the worktree's runtime), one after the other.
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a812d2515ec2b93a8
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$W" || exit 1
probes=(docs/agent/hardening-evidence/probes/h07/*.pts docs/agent/hardening-evidence/probes/h01b/c07-*.pts docs/agent/hardening-evidence/probes/h01b/parent/c07-*.pts)
for which in base candidate; do
  if [ "$which" = base ]; then cli=$W/pts-bin/pts; else cli=/tmp/h07-repro/pts-candidate; fi
  out=/tmp/h07-repro/final-$which
  rm -rf "$out"
  mkdir -p "$out"
  PTS_HOME=$W python3 -I docs/agent/hardening-evidence/probes/h07/run_probes.py --pts "$cli" --node "$HOME/.local/node/bin/node" \
    --scratch "$out/scratch" --out "$out/probes.json" "${probes[@]}" > "$out/out.txt" 2>&1
  echo "exit=$?" >> "$out/out.txt"
  rm -rf "$out/scratch"
done
echo done > /tmp/h07-repro/final-done
