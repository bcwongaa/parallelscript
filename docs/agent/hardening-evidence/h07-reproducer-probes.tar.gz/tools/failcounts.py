#!/usr/bin/env python3
"""Per probe and thread count: runs differing from Node, and the min/median/max number of
failures per run, where a run's failures are the sum of its `failed N` counts, of the counts
of tally lines other than `ok: N` (`X: N`, also inside `name: X: N, ok: M`), of
`constructed N` and of `listeners lost N` / `construction failures N`.
Usage: failcounts.py probes.json..."""
import json
import re
import statistics
import sys


def failures(stdout):
    total = 0
    for line in stdout.splitlines():
        found = False
        for pattern in (r"failed (\d+)", r"constructed (\d+)", r"listeners lost (\d+)", r"construction failures (\d+)"):
            for m in re.finditer(pattern, line):
                total += int(m.group(1))
                found = True
        if found:
            continue
        body = line.split(": ", 1)[1] if re.match(r"^(handled|plain): ", line) else line
        for part in body.split(", "):
            m = re.match(r"^(.*): (\d+)$", part)
            if m and m.group(1) != "ok" and not m.group(1).startswith("error handler calls"):
                total += int(m.group(2))
    return total


for path in sys.argv[1:]:
    record = json.load(open(path))
    for result in record["results"]:
        name = result["probe"].rsplit("/", 1)[-1]
        cells = []
        for per in result["pts_runs"]:
            counts = []
            for group in per["outcomes"]:
                counts += [failures(group["sample"]["stdout"])] * group["count"]
            exits = sorted({g["sample"]["exit"] for g in per["outcomes"]})
            cells.append(f"{per['threads']}t {per['runs_not_matching_node']}/{per['runs']} differ, failures/run min {min(counts)} med {int(statistics.median(counts))} max {max(counts)}, exits {exits}")
        print(f"{name}: {result['outcome']}; " + "; ".join(cells))
