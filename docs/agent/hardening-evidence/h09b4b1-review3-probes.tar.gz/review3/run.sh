#!/bin/bash
# usage: run.sh probe.pts...  -> out/<name>/{node,base,snap4,snap5}.txt
# Node (.mts copy, --experimental-transform-types), base (/tmp/h09b4b/base), snap4 (round-1
# fix commit's code) and snap5 (round-2 changes). SKIP_BASE=1 / SKIP_SNAP4=1 skip those CLIs.
export TZ=America/New_York
R=/tmp/h09b4b/s2/review3
cli() { # name home file dir
  (cd "$4" && PTS_HOME=$2 PTS_CACHE_DIR=$R/.cache-$1 timeout 300 $2/pts-bin/pts run "$3" > "$4/$1.txt" 2>&1; echo "exit=$?" >> "$4/$1.txt")
}
for f0 in "$@"; do
  f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n
  mkdir -p "$d"
  cp "$f" "$d/$n.mts"
  (cd "$d" && timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" > "$d/node.txt" 2>&1; echo "exit=$?" >> "$d/node.txt")
  [ -z "$SKIP_BASE" ] && cli base /tmp/h09b4b/base "$f" "$d"
  [ -z "$SKIP_SNAP4" ] && cli snap4 /tmp/h09b4b/s2/snap4 "$f" "$d"
  cli snap5 /tmp/h09b4b/s2/snap5 "$f" "$d"
  st() { [ -f "$d/$1.txt" ] && (cmp -s "$d/node.txt" "$d/$1.txt" && echo SAME || echo DIFF) || echo -; }
  echo "== $n: base=$(st base) snap4=$(st snap4) snap5=$(st snap5)"
  if [ "$(st snap5)" = DIFF ]; then diff "$d/node.txt" "$d/snap5.txt" | head -14; fi
done
