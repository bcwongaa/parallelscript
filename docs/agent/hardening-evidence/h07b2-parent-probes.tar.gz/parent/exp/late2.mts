import { test } from "node:test";
test("a", () => { console.log("running a"); });
await new Promise((r) => setTimeout(r, 200));
console.log("registering b");
test("b", () => {});
