import { test } from "node:test";
test("a", () => {});
await new Promise((r) => setTimeout(r, 20));
test("b", () => {});
