// Same writes through a variable declared any (the base's D-070 behaviour)
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
const n = new Box<number>(1);
const o: any = n;
const xs: any[] = [];
o.items = xs;
xs.push(5);
console.log("any", n.items);
