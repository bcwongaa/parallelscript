// Member forms through Box<any> places that HEAD ran typed: length writes, element compounds, swaps, Object.assign, in-place sorts
class Box<T> {
  items: T[] = [];
  m = new Map<string, T[]>();
  x = 1;
  y = 2;
  opt?: { z: number };
  hits = 0;
  flag = false;
  constructor(...xs: T[]) { this.items.push(...xs); }
}
function work(b: Box<any>): string {
  b.items[0] += 5;
  b.items[1]++;
  [b.x, b.y] = [b.y, b.x];
  b.m.set("k", []);
  b.m.get("k")!.push(b.x);
  for (const [k, v] of b.m) v.push(k);
  b.items.sort((p, q) => q - p);
  b.items.reverse();
  b.hits += 0.5;
  b.flag ||= b.hits > 0;
  b.opt ??= { z: 3 };
  b.opt.z **= 2;
  const out = `${b.items} ${b.x},${b.y} ${JSON.stringify([...b.m])} ${b.hits.toFixed(2)} ${b.flag} ${b.opt?.z} ${b.items.length}`;
  b.items.length = 1;
  Object.assign(b, { x: 10 });
  return out + ` ${b.items} ${b.x}`;
}
console.log(work(new Box<any>(1, 2, 3)));
