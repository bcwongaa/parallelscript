// C285 container literals that mix the instance's rows with the program's own new arrays
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[1 as V]];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const rows = [c.matrix[0], [1, 2], ["a"]];
    rows[1].push("x");
    rows[2].push(3);
    rows.push([true]);
    rows[0].push(9);
    console.log(JSON.stringify(rows));
    const more = [...c.matrix, [5]];
    more[1].push("y");
    console.log(JSON.stringify(more), JSON.stringify(c.matrix));
  }
}
probe(new MapLRU<string, number>("k", 1));
