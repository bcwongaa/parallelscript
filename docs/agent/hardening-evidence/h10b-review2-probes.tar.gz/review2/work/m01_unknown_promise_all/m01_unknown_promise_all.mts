// H10b matrix case: {"elem": "number", "family": "unknown", "flow": "promise_all", "id": "K_unknown__promise_all__number", "par": false, "part": "K", "threads": [null]}
interface Cache<K, V> {
  get(k: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  hits = 0;
  items: V[] = [];
  matrix: V[][] = [[], []];
  store = new Map<string, V[]>([["k", []]]);
  rec: Record<string, V[]> = { a: [] };
  pending: Promise<V[]>;
  next: MapLRU<K, V> | undefined = undefined;
  #secret: V;
  constructor(public key: K, public val: V) { this.#secret = val; this.items.push(val); this.pending = Promise.resolve(this.matrix[0]); }
  get current(): V { return this.val; }
  read(): V { return this.val; }
  secret(): V { return this.#secret; }
  #bump(): number { return ++this.hits; }
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
class Other<K, V> implements Cache<K, V> {
  get(k: K): V | undefined { return undefined; }
}
function pushRow(r: any[]): void {
  r.push(v2);
}
async function probe(x: unknown): Promise<void> {
  if (x instanceof MapLRU) {
    try {
      (await Promise.all(x.matrix))[0].push(v2);
    } catch (e) {
      console.log("ERR", String(e));
    }
  }
}
const v1: number = 7;
const v2: number = 8.5;
const obj: MapLRU<string, number> = new MapLRU<string, number>("k", v1);
await probe(obj);
await probe(42);
console.log(JSON.stringify(obj.matrix), JSON.stringify([...obj.store]), JSON.stringify(obj.rec));
