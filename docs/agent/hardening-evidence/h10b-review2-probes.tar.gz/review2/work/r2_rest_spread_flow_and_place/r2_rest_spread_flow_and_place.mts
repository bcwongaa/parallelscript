// R2: rows spread into a copying rest parameter (`...rows: any[][]`) from a value that flowed out of an
// instanceof narrowing (const m2 = c) or from a MapLRU<any, any> place holding a MapLRU<string, number>:
// copied, the write lost silently. The narrowed reference itself (`...c.matrix`) is PTS1001 (R1-F12's fix).
// HEAD: TypeError at the flow; PTS1001 at the place.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function pushRest(...rows: any[][]): void { rows[0].push(9); }
function viaFlow(c: Cache<string, number>): void {
  if (c instanceof MapLRU) { const m2 = c; pushRest(...m2.matrix); }
}
function viaPlace(b: MapLRU<any, any>): void { pushRest(...b.matrix.slice(1)); }
const m = new MapLRU<string, number>("k", 0);
viaFlow(m);
viaPlace(m);
console.log(JSON.stringify(m.matrix));
