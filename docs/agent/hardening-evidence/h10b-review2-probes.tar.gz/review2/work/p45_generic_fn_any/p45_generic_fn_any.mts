// Generic functions over Box<T> instantiated for any (T = any): returns of members, pushes, private-free
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
}
function itemsOf<T>(b: Box<T>): T[] { return b.items; }
function firstOf<T>(bs: Box<T>[]): Box<T> { return bs[0]; }
function keep<T>(b: Box<T>, out: T[][]): void { out.push(b.items); }
const a = new Box<any>(1);
itemsOf(a).push("x");
const out: any[][] = [];
keep(a, out);
out[0].push("y");
console.log(a.items, firstOf([a]) === a);
