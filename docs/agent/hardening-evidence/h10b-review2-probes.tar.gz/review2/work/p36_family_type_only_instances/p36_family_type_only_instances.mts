// FamilyCall/FamilySetField when some of the class's instances are only named in types, or made in dead code
class Box<T> {
  #v: T;
  constructor(v: T) { this.#v = v; }
  #show(): string { return `${this.#v}`; }
  static show(o: object): string { if (o instanceof Box) { o.#v = o.#v; return o.#show(); } return "no"; }
}
type OnlyType = Box<boolean>;
function neverCalled(b: Box<Date>, c: OnlyType): string { return `${b} ${c}`; }
const maybe: Box<string[]> | null = Math.random() > 2 ? new Box<string[]>([]) : null;
console.log(Box.show(new Box<number>(1)), Box.show({}), maybe === null, typeof neverCalled);
