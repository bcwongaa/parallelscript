// The same typed sinks through an uninferred instanceof narrowing (object source)
class Box<T> {
  pairs: [T, T][] = [];
  m = new Map<string, T>();
  constructor(public v: T) {}
}
function f(o: object): void {
  if (o instanceof Box) {
    const mm: Map<string, number> = o.m;
    mm.set("k", 1);
    const ps: [number, number][] = o.pairs;
    ps.push([1, 2]);
  }
}
const n = new Box<number>(1);
f(n);
console.log(n.m.size, n.pairs.length);
