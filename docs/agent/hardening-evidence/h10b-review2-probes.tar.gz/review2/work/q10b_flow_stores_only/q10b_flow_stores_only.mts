// Stores of functions with copying parameters through flows out of a narrowing (inferred source) and Box<any> places
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  cfg: { onRows: (rows: V[][]) => void } = { onRows: () => {} };
  list: ((row: V[]) => void)[] = [() => {}];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
  fire(): void { this.cfg.onRows(this.matrix); this.list[0](this.matrix[0]); }
}
function addAll(rows: any[][]): void { rows[1].push(2); }
function addRow(row: any[]): void { row.push(1); }
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const m2 = c;
    m2.cfg.onRows = addAll;
    m2.list[0] = addRow;
    m2.fire();
  }
}
const m = new MapLRU<string, number>("k", 0);
probe(m);
console.log(JSON.stringify(m.matrix));
