// A generic class's own code reading another instance's T[] member (Box<T> parameter), used for `any`
class Box<T> {
  items: T[] = [];
  next: Box<T> | null = null;
  constructor(public v: T) { this.items.push(v); }
  itemsOf(other: Box<T>): T[] { return other.items; }
  firstOf(other: Box<T>): T { return other.items[0]; }
  join(other: Box<T>): T[] { const all: T[] = other.items; return all; }
  swap(other: Box<T>): void { const mine = this.items; this.items = other.items; other.items = mine; }
  static pairOf<U>(a: Box<U>, b: Box<U>): [U[], U[]] { return [a.items, b.items]; }
}
const a = new Box<any>(1);
const b = new Box<any>("b");
console.log(a.itemsOf(b), a.firstOf(b), a.join(b) === b.items);
a.swap(b);
console.log(a.items, b.items, Box.pairOf(a, b));
const n = new Box<number>(1);
console.log(n.itemsOf(new Box<number>(2)));
