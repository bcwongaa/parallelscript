// C285 containers into annotated locals and returns with declared types
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function rowsOf(c: Cache<string, number>): any[][] {
  if (c instanceof MapLRU) return [...c.matrix];
  return [];
}
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const rows: any[][] = [...c.matrix];
    rows[0].push(1);
    const s: Set<any[]> = new Set(c.matrix);
    [...s][1].push(2);
  }
}
const m = new MapLRU<string, number>("k", 0);
probe(m);
rowsOf(m)[0].push(3);
console.log(JSON.stringify(m.matrix));
