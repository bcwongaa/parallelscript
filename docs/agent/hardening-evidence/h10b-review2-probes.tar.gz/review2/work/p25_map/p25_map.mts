// Box<any> members converted to typed places (number[], a shape, a Map) and written through them
class Box<T> {
  items: T[] = [];
  pairs: [T, T][] = [];
  m = new Map<string, T>();
  constructor(public v: T) { this.items.push(v); }
}
const a = new Box<any>(1);
const mm: Map<string, number> = a.m;
mm.set("k", 1);
console.log("map", a.m.size);
