// A generic private method whose result nests T (Box<[T, U]>), called on a dynamic receiver; and the name's visibility through any
class Box<T> {
  constructor(public v: T) {}
  #pair<U>(u: U): [T, U] { return [this.v, u]; }
  static run(o: object): string {
    if (!(o instanceof Box)) return "no";
    return JSON.stringify(o.#pair("x"));
  }
  static peek(o: any): string { return typeof o["#pair"]; }
}
console.log(Box.run(new Box<number>(1)), Box.peek(new Box<number>(2)));
