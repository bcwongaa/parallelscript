// Box<any> members converted to typed places (number[], a shape, a Map) and written through them
class Box<T> {
  items: T[] = [];
  pairs: [T, T][] = [];
  m = new Map<string, T>();
  constructor(public v: T) { this.items.push(v); }
}
const a = new Box<any>(1);
const xs: number[] = a.items;
xs.push(5);
console.log("number[]", a.items.length, xs === a.items);
const ps: [number, number][] = a.pairs;
ps.push([1, 2]);
console.log("tuples", a.pairs.length);
const mm: Map<string, number> = a.m;
mm.set("k", 1);
console.log("map", a.m.size);
function sum(ns: number[]): number { return ns.reduce((p, c) => p + c, 0); }
console.log("sum", sum(a.items));
