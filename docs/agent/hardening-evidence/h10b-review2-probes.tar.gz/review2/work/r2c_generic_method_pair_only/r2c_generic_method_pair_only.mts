// R2: a generic method whose result nests T (`Box<[T, U]>`), called on a Box<any> value: PTS1001
// "polymorphic recursion more than 64 instances deep" where HEAD compiled and ran it.
class Box<T> {
  constructor(public v: T) {}
  pair<U>(u: U): Box<[T, U]> { return new Box<[T, U]>([this.v, u]); }
}
const a = new Box<any>(1);
const p = a.pair("x");
console.log("pair", p.v[1]);
