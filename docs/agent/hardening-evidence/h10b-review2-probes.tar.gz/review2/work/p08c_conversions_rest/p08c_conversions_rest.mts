// Box<any> values (new Box<any>, and Box<number> given to Box<any>) into other places
interface Getter<V> { get(): V; readonly v: V; }
interface Named { name: string; }
class Box<T> {
  items: T[] = [];
  name = "box";
  constructor(public v: T) { this.items.push(v); }
  get(): T { return this.v; }
}
function viaIface(g: Getter<any>): any { return g.get(); }
function viaObj(o: { v: any; items: any[] }): number { o.items.push(o.v); return o.items.length; }
function viaNamed(n: Named): string { return n.name; }
function viaObject(o: object): boolean { return o instanceof Box; }
function generic<T>(b: Box<T>): T { b.items.push(b.v); return b.get(); }
function take(b: Box<any>): void {
  const g = b;
  const { v, items } = b;
  items.push("d");
  const sp = Object.assign({}, b);
  console.log("iface", g.get(), viaObj(b), viaNamed(b), viaObject(b), generic(b));
  console.log("destructure", v, items === b.items, b.items.length);
  console.log("spread", JSON.stringify(sp), Object.keys(b).join(","), JSON.stringify(b));
  const u: unknown = b;
  const ob: {} = b;
  console.log("unknown", u === b, ob === b, typeof b);
  for (const k in b) console.log("key", k);
}
take(new Box<any>(1));
