// compile time: a member chain of depth 24 through Box<any> places, and nested literals
class Box<T> {
  items: T[] = [];
  next: Box<T> | null = null;
  matrix: T[][] = [];
  constructor(public v: T) {}
}
interface Holder { readonly items: unknown; }
let a = new Box<any>(0);
let cur = a;
for (let i = 0; i < 25; i++) { const n = new Box<any>(i + 1); cur.next = n; cur = n; }
console.log(a.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.v);
a.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.items.push(1);
console.log(a.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.items.length);
function f(h: object) {
  if (h instanceof Box) {
    const c = h;
    console.log(c.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.next!.v);
    const deep = [[[[[[[[[[[[c.matrix[0]]]]]]]]]]]]];
    console.log(JSON.stringify(deep));
  }
}
const root = new Box<number>(5);
let r = root;
for (let i = 0; i < 25; i++) { const n = new Box<number>(i); r.next = n; r = n; }
root.matrix.push([1]);
f(root);
