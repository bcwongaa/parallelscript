// R2: an object spread / rest of a Box<any> place lists Box's fields only (spreadNames from C's instance for
// any), so a subclass object's own fields, or the properties of another object held there, are dropped.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
class Labelled extends Box<number> {
  label = "L";
}
function spread(b: Box<any>): string {
  const copy = { ...b };
  const { v, ...rest } = b;
  return `${JSON.stringify(copy)} ${Object.keys(copy).join(",")} ${JSON.stringify(rest)}`;
}
console.log(spread(new Labelled(3)));
console.log(spread(new Box<any>(1)));
