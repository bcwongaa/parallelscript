// A Box<number> held as a dynamic value (object-source narrowing, a Box<any> place, a flow) converted to Getter<any>
interface Getter<V> { get(): V; readonly v: V; }
interface Lister<V> { items: V[]; }
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  get(): T { return this.v; }
}
function fromObject(o: object): string {
  if (!(o instanceof Box)) return "no";
  try { const g: Getter<any> = o; return `obj ${g.get()}`; } catch (e) { return `obj ${(e as Error).message}`; }
}
function fromPlace(b: Box<any>): string {
  try { const g: Getter<any> = b; return `place ${g.get()}`; } catch (e) { return `place ${(e as Error).message}`; }
}
function lister(b: Box<any>): string {
  try { const l: Lister<any> = b; l.items.push("x"); return `lister ${b.items.length}`; } catch (e) { return `lister ${(e as Error).message}`; }
}
const n = new Box<number>(1);
console.log(fromObject(n));
console.log(fromPlace(n));
console.log(lister(n), lister(new Box<any>(2)));
