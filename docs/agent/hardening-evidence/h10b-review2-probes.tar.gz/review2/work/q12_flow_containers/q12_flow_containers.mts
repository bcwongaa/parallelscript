// C285 containers made from a flowed-out value's members (const m2 = c, inferred source) and from a Box<any> place
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], [], [], [], [], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function pushRest(...rows: any[][]): void { rows[0].push(9); }
async function probe(c: Cache<string, number>, b: MapLRU<any, any>): Promise<void> {
  if (c instanceof MapLRU) {
    const m2 = c;
    [...m2.matrix][0].push(1);
    [...new Set(m2.matrix)][1].push(2);
    Array.from(m2.matrix)[2].push(3);
    (await Promise.all(m2.matrix))[3].push(4);
    pushRest(...m2.matrix.slice(4));
    for (const [i, row] of m2.matrix.entries()) if (i === 5) row.push(5);
  }
  [...b.matrix][0].push(10);
  pushRest(...b.matrix.slice(1));
}
const m = new MapLRU<string, number>("k", 0);
await probe(m, m);
console.log(JSON.stringify(m.matrix));
