// C289's class through Box<any> places holding Box<number>: object literals into T-mentioning shapes
class Box<T> {
  groups: { list: T[]; name: string }[] = [];
  constructor(public v: T) {}
  add(g: { list: T[]; name: string }): number { return this.groups.push(g); }
}
function fill(b: Box<any>): void {
  b.groups.push({ list: [], name: "g" });
  b.add({ list: [b.v], name: "h" });
}
const n = new Box<number>(1);
fill(n);
console.log(JSON.stringify(n.groups));
