// .par over members of a value that flowed out of a narrowing (const m2 = c) and of a MapLRU<any, any> place holding a MapLRU<string, number>:
// element writes inside the callbacks must reach the instance's rows
// threads: 1 4
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { for (let i = 0; i < 8; i++) this.matrix.push([]); }
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function viaFlow(c: Cache<string, number>): void {
  if (c instanceof MapLRU) { const m2 = c; m2.matrix.forEach((r) => { r.push(1); }); }
}
function viaPlace(b: MapLRU<any, any>): void { b.matrix.forEach((r) => { r.push(2); }); }
const m = new MapLRU<string, number>("k", 0);
viaFlow(m);
viaPlace(m);
console.log(JSON.stringify(m.matrix));
