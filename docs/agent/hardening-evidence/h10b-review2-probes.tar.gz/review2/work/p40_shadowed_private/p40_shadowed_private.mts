// The same private name declared by a base class and its subclass: dynamic reads, writes and calls must pick the lexical class's member
class Base<T> {
  #x = "base";
  #m(): string { return "base-m"; }
  static read(o: any): string { return `${o.#x} ${o.#m()}`; }
  static write(o: any, v: string): void { o.#x = v; }
  baseX(): string { return this.#x; }
}
class Sub extends Base<number> {
  #x = "sub";
  #m(): string { return "sub-m"; }
  static readSub(o: any): string { return `${o.#x} ${o.#m()}`; }
  static writeSub(o: any, v: string): void { o.#x = v; }
  subX(): string { return this.#x; }
}
class GSub<U> extends Base<U> {
  #x = "gsub";
  static readG(o: any): string { return o.#x; }
  static writeG(o: any, v: string): void { o.#x = v; }
  gX(): string { return this.#x; }
}
const s = new Sub();
const g = new GSub<string>();
console.log(Base.read(s), Sub.readSub(s), Base.read(g), GSub.readG(g));
Base.write(s, "B1");
Sub.writeSub(s, "S1");
Base.write(g, "B2");
GSub.writeG(g, "G2");
console.log(s.baseX(), s.subX(), g.baseX(), g.gX());
