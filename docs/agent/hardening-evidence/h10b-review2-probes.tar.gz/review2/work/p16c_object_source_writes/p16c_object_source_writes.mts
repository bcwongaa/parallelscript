// The same write through an uninferred instanceof narrowing (object source), H10a's territory
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function setItems(o: object, xs: any[]): void { if (o instanceof Box) o.items = xs; }
const n = new Box<number>(1);
const xs: any[] = [];
setItems(n, xs);
xs.push(5);
console.log("object source", n.items);
