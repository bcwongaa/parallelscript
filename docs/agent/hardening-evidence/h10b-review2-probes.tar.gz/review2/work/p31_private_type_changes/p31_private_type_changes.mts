// Private writes of values of other types through dynamic receivers: must be checked TypeErrors, never corrupt fields
class Cell<T> {
  #n = 0;
  #t: T;
  #u: T | undefined = undefined;
  #arr: T[] = [];
  #obj: { k: T } | null = null;
  #f: (x: T) => T = (x) => x;
  constructor(t: T) { this.#t = t; }
  static tryAll(o: any): string[] {
    const out: string[] = [];
    const attempt = (label: string, f: () => void) => { try { f(); out.push(`${label} ok`); } catch (e) { out.push(`${label} ${(e as Error).name}`); } };
    attempt("n=str", () => { o.#n = "str"; });
    attempt("n=1.5", () => { o.#n = 1.5; });
    attempt("t=obj", () => { o.#t = { a: 1 }; });
    attempt("u=undef", () => { o.#u = undefined; });
    attempt("u=str", () => { o.#u = "s"; });
    attempt("arr=strs", () => { o.#arr = ["a", "b"]; });
    attempt("arr=nums", () => { o.#arr = [1, 2]; });
    attempt("obj=null", () => { o.#obj = null; });
    attempt("obj=lit", () => { o.#obj = { k: 5 }; });
    attempt("f=fn", () => { o.#f = (x: any) => x * 2; });
    attempt("f=num", () => { o.#f = 3; });
    attempt("n+=str", () => { o.#n += "x"; });
    return out;
  }
  show(): string { return `${this.#n}|${this.#t}|${this.#u}|${JSON.stringify(this.#arr)}|${JSON.stringify(this.#obj)}|${this.#f(this.#t)}`; }
}
const c = new Cell<number>(7);
console.log(Cell.tryAll(c).join(", "));
console.log(c.show());
