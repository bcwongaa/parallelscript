// Private fields holding functions called on dynamic receivers: optional calls, undefined, args conversions
class Hook<T> {
  #cb?: (x: T) => string;
  #fns: ((x: T) => T)[] = [];
  constructor(cb?: (x: T) => string) { this.#cb = cb; this.#fns.push((x) => x); }
  static fire(o: object, x: any): string {
    if (!(o instanceof Hook)) return "no";
    const r = o.#cb?.(x) ?? "none";
    const f = o.#fns[0](x);
    o.#fns.push((y: any) => y);
    return `${r} ${f} ${o.#fns.length}`;
  }
}
console.log(Hook.fire(new Hook<number>((n) => `n${n}`), 3));
console.log(Hook.fire(new Hook<number>(), 4));
console.log(Hook.fire(new Hook<string>((s) => s.toUpperCase()), "abc"));
