// Abstract generic base with Shape<any>[] places of non-generic and generic subclasses; overrides, super, protected
abstract class Shape<T> {
  protected tag: T;
  constructor(tag: T) { this.tag = tag; }
  abstract area(): number;
  describe(): string { return `${this.tag}:${this.area().toFixed(1)}`; }
}
class Circle extends Shape<string> { constructor(public r: number) { super("c"); } area(): number { return Math.PI * this.r ** 2; } }
class Sq<U> extends Shape<U> { constructor(t: U, public s: number) { super(t); } area(): number { return this.s ** 2; } override describe(): string { return "sq " + super.describe(); } }
const shapes: Shape<any>[] = [new Circle(1), new Sq<number>(7, 2), new Sq<boolean>(true, 3)];
let total = 0;
for (const s of shapes) total += s.area();
console.log(shapes.map((s) => s.describe()).join(", "), total.toFixed(2));
shapes.sort((a, b) => a.area() - b.area());
console.log(shapes.map((s) => s instanceof Circle ? "C" : "S").join(""), shapes.find((s): s is Circle => s instanceof Circle)?.r);
