// R2: r2_generic_method_result without the pair method (map only)
// HEAD called the typed instance (map<any[]>) and ran as Node; the snapshot calls it through any, whose
// erased copy makes a Box<any>, and the checked conversion to tsc's Box<any[]> throws.
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const a = new Box<any>(1);
const m = a.map((v) => [v]);
console.log("map", m.v, m instanceof Box);
const s: Box<string> = a.map((v) => String(v));
console.log("typed", s.v.length);
function len(b: Box<number>): number { return b.v; }
console.log("param", len(a.map((v) => 7)));
