// .par over Box<any>[] holding Box<number> and Box<string>, with allocation, getters, private reads/writes, own-element writes
class Box<T> {
  #hits = 0;
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
  get label(): string { return `L${this.v}`; }
  touch(): number { this.#hits++; return this.#hits; }
  static bump(o: Box<any>): number { o.#hits += 2; return o.#hits; }
  static call(o: Box<any>): string { return o.#fmt(o.v); }
  #fmt(x: any): string { return `<${x}>`; }
}
const boxes: Box<any>[] = [];
for (let i = 0; i < 400; i++) boxes.push(i % 2 === 0 ? new Box<number>(i) : new Box<string>(`s${i}`));
const labels = boxes.map((b) => b.label + ":" + JSON.stringify([b.v, b.items.length, String(b.v).repeat(3)]));
console.log("labels", labels.length, labels[0], labels[399]);
const bumped = boxes.map((b) => Box.bump(b) + b.touch());
console.log("bumped", bumped.reduce((a, b) => a + b, 0));
const called = boxes.map((b) => Box.call(b));
console.log("called", called[1], called[398]);
boxes.forEach((b) => { b.items.push(b.v); });
console.log("items", boxes.reduce((a, b) => a + b.items.length, 0));
const found = boxes.filter((b) => typeof b.v === "string").map((b) => b.v);
console.log("found", found.length, found[0]);
