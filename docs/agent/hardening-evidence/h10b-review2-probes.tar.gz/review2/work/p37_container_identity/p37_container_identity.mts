// C285 containers: identity of the instance's rows inside new Sets/Maps/arrays (has, indexOf, get ===)
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[1 as V], [2 as V, 3 as V]];
  store = new Map<string, V[]>([["a", [4 as V]]]);
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const s = new Set(c.matrix);
    console.log(s.size, s.has(c.matrix[0]), [...s].indexOf(c.matrix[1]), [...c.matrix].includes(c.matrix[0]));
    const m = new Map(c.store);
    console.log(m.get("a") === c.store.get("a"), [...m.values()][0] === c.store.get("a"));
    const it = c.store.values();
    const step = it.next();
    console.log(step.done, step.value === c.store.get("a"));
    const arr = Array.from(c.store.values());
    console.log(arr[0] === c.store.get("a"), Object.values({ k: 1 }).length);
    for (const [k, v] of c.store.entries()) console.log(k, v === c.store.get(k));
  }
}
probe(new MapLRU<string, number>("k", 1));
