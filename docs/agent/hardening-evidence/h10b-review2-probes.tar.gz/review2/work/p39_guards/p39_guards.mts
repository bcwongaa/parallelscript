// User type guards and assertion functions to Box<any>, satisfies, and Box<any> in catch/throw
class Box<T> { items: T[] = []; constructor(public v: T) {} }
function isBox(x: unknown): x is Box<any> { return x instanceof Box; }
function assertBox(x: unknown): asserts x is Box<any> { if (!(x instanceof Box)) throw new Error("not"); }
const xs: unknown[] = [new Box<number>(1), "s", new Box<string>("t")];
const boxes = xs.filter(isBox);
boxes[0].items.push(5);
console.log(boxes.length, boxes.map((b) => b.v), (xs[0] as Box<number>).items);
const y: unknown = xs[2];
assertBox(y);
y.items.push("u");
y.v = "w";
console.log((xs[2] as Box<string>).items, (xs[2] as Box<string>).v);
const sat = new Box<number>(3) satisfies Box<any>;
console.log(sat.v + 1);
try { throw new Box<number>(9); } catch (e) { if (isBox(e)) { e.items.push(1); console.log("caught", e.v, e.items); } }
