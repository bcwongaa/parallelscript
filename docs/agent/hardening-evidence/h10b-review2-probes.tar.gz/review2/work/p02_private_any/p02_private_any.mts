// Private members reached through Box<T> parameters in the instance for any, and through Box<any> places
class Box<T> {
  #v: T;
  #count = 0;
  static #made = 0;
  constructor(v: T) { this.#v = v; Box.#made++; }
  get #twice(): string { return `${this.#v}${this.#v}`; }
  set #val(x: T) { this.#v = x; this.#count++; }
  #bump(by: number): number { this.#count += by; return this.#count; }
  copyFrom(other: Box<T>): void { this.#v = other.#v; other.#count++; }
  setOther(other: Box<T>, x: T): void { other.#val = x; }
  twiceOf(other: Box<T>): string { return other.#twice; }
  bumpOther(other: Box<T>): number { return other.#bump(2); }
  incOther(other: Box<T>): number { other.#count += 5; other.#count++; ++other.#count; return other.#count; }
  hasV(o: any): boolean { return #v in o; }
  static made(): number { return Box.#made; }
  show(): string { return `${this.#v}/${this.#count}`; }
}
const a = new Box<any>(1);
const b = new Box<any>("x");
a.copyFrom(b);
console.log("copy", a.show(), b.show());
a.setOther(b, 42);
console.log("set", b.show());
console.log("twice", a.twiceOf(b));
console.log("bump", a.bumpOther(b));
console.log("inc", a.incOther(b));
console.log("in", a.hasV(b), a.hasV({}));
console.log("made", Box.made());
const n = new Box<number>(7);
const nn = new Box<number>(8);
n.copyFrom(nn);
console.log("typed", n.show(), nn.show(), n.bumpOther(nn), n.incOther(nn), n.twiceOf(nn));
