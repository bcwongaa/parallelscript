// Destructuring Box<any> values holding Box<number>/Box<string>: for…of patterns, parameters, assignments
class Box<T> {
  items: T[] = [];
  meta = { tags: [] as T[] };
  constructor(public v: T) { this.items.push(v); }
}
const boxes: Box<any>[] = [new Box<number>(1), new Box<string>("s")];
for (const { v, items, meta: { tags } } of boxes) { items.push(v); tags.push(v); }
function take({ items }: Box<any>): void { items.push("p" as any); }
take(new Box<string>("t"));
let it: any[] = [];
({ items: it } = boxes[1]);
it.push("q");
for (const b of boxes) console.log(JSON.stringify(b.items), JSON.stringify(b.meta.tags));
