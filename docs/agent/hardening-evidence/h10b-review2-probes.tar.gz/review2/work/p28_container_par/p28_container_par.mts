// C285 containers used with .par (threads 1 2 4): reads of the instance's rows on other threads, and writes after
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { for (let i = 0; i < 50; i++) this.matrix.push([]); }
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const rows = [...c.matrix];
    const lens = rows.map((r) => r.length + 1);
    console.log("lens", lens.reduce((a, b) => a + b, 0));
    rows.forEach((r, i) => r.push(i));
    const set = new Set(c.matrix);
    console.log("set", [...set].map((r) => r[0] * 2).reduce((a, b) => a + b, 0));
    Array.from(c.matrix).forEach((r) => { r.push(-1); });
  }
}
const m = new MapLRU<string, number>("k", 1);
probe(m);
console.log(m.matrix.reduce((a, r) => a + r.length, 0), m.matrix[49]);
