// compile time: private member chains of depth 22 on dynamic receivers, reads and writes
class Node2<T> {
  #next: Node2<T> | null = null;
  #v: T;
  constructor(v: T) { this.#v = v; }
  static link(a: Node2<any>, b: Node2<any>): void { a.#next = b; }
  static deep(o: object): string {
    if (!(o instanceof Node2)) return "no";
    o.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#v = 99;
    return `${o.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#next!.#v}`;
  }
}
const nodes: Node2<number>[] = [];
for (let i = 0; i <= 22; i++) nodes.push(new Node2<number>(i));
for (let i = 0; i < 22; i++) Node2.link(nodes[i], nodes[i + 1]);
console.log(Node2.deep(nodes[0]));
