// Private members on Box<any> | undefined receivers: optional chains, non-null, side-effecting receivers evaluated once
let calls = 0;
class Box<T> {
  #v: T;
  constructor(v: T) { this.#v = v; }
  #m(): T { return this.#v; }
  static pick(xs: (Box<any> | undefined)[], i: number): Box<any> | undefined { calls++; return xs[i]; }
  static run(xs: (Box<any> | undefined)[]): string {
    const a = Box.pick(xs, 0)!.#v;
    const c = Box.pick(xs, 0)!.#m();
    Box.pick(xs, 0)!.#v += 10;
    Box.pick(xs, 0)!.#v++;
    const e = Box.pick(xs, 0)!.#m();
    return `${a} ${c} ${e} calls=${calls}`;
  }
}
console.log(Box.run([new Box<number>(1), undefined]));
