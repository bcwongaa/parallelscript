// Subclasses of Box<any> and generic subclasses; super calls; statics typed Box<any>; overrides through Box<any> places
class Box<T> {
  static registry: Box<any>[] = [];
  static last: Box<any> | null = null;
  #secret = 0;
  constructor(public v: T) { Box.registry.push(this); Box.last = this; }
  describe(): string { return `box ${this.v}`; }
  peek(other: Box<T>): number { return other.#secret; }
  bump(): this { this.#secret++; return this; }
  clone(): Box<T> { return new Box(this.v); }
}
class Labelled extends Box<any> {
  constructor(v: any, public label: string) { super(v); }
  override describe(): string { return `${this.label}: ${super.describe()}`; }
  override clone(): Box<any> { const c = super.clone(); c.v = [c.v]; return c; }
}
class Pair<U> extends Box<[U, U]> {
  override describe(): string { return `pair ${super.describe()}`; }
}
const l = new Labelled(1, "L");
const p = new Pair<number>([1, 2]);
const n = new Box<number>(3);
for (const b of Box.registry) console.log(b.describe(), b instanceof Labelled, b instanceof Pair);
console.log(Box.last === n, Box.registry.indexOf(l), l.bump().bump().peek(l), l.clone().v);
const asAny: Box<any> = l;
console.log(asAny.describe(), (asAny as Labelled).label, asAny.bump() === l);
function relabel(b: Box<any>): void { if (b instanceof Labelled) b.label = "R"; }
relabel(l);
console.log(l.label, Box.registry.map((b) => b.clone().v));
