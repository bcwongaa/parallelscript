// Unions mixing Box<any> with typed classes, primitives and arrays
class Box<T> { constructor(public v: T) {} }
class Bag<T> { constructor(public list: T[]) {} }
function f(x: Box<any> | Bag<number> | string | number[]): string {
  if (typeof x === "string") return `s:${x}`;
  if (Array.isArray(x)) { x.push(9); return `a:${x.length}`; }
  if (x instanceof Bag) { x.list.push(1); return `bag:${x.list}`; }
  return `box:${x.v}`;
}
const arr = [1];
console.log(f("q"), f(arr), arr.length, f(new Bag([0])), f(new Box<string>("z")), f(new Box<any>(5)));
const list: (Box<any> | null)[] = [null, new Box<number>(2)];
console.log(list.map((b) => b?.v ?? "null"));
