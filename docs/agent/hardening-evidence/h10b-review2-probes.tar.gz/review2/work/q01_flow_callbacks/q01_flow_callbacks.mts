// Flows out of an instanceof narrowing (const m2 = c, ident(c), [c][0]) then H10a's callback-by-reference and stored-function forms
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  handlers: ((rows: V[][]) => void)[] = [];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
  each(f: (row: V[]) => void): void { this.matrix.forEach(f); }
  fire(): void { for (const h of this.handlers) h(this.matrix); }
}
function addRow(row: any[]): void { row.push(1); }
function addAll(rows: any[][]): void { rows[1].push(2); }
function ident<T>(t: T): T { return t; }
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const m2 = c;
    m2.matrix.forEach(addRow);
    ident(c).each(addRow);
    m2.handlers.push(addAll);
    m2.fire();
  }
}
const m = new MapLRU<string, number>("k", 0);
probe(m);
console.log(JSON.stringify(m.matrix));
