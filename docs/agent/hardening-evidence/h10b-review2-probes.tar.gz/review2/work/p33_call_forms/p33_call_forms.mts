// Method call forms through Box<any> places: spreads, rest, optional and default parameters, overloads, getters returning functions
class Box<T> {
  items: T[] = [];
  addAll(...xs: T[]): number { this.items.push(...xs); return this.items.length; }
  opt(a: T, b?: T, c: string = "d"): string { return `${a}/${b}/${c}`; }
  get adder(): (x: T) => number { return (x) => this.items.push(x); }
  over(x: string): string;
  over(x: number): number;
  over(x: any): any { return x; }
}
const b: Box<any> = new Box<number>();
const xs = [1, 2, 3];
console.log(b.addAll(...xs), b.addAll(), b.opt(1), b.opt(1, 2), b.opt(1, 2, "e"), b.adder(4), b.over("s"), b.over(5));
const a = new Box<any>();
console.log(a.addAll(...["x", 1]), a.opt("q"), a.adder(true), a.items);
