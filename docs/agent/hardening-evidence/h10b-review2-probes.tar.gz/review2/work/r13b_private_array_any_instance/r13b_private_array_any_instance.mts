// R1-F13b: the same through a Box<any> place, Box<any> objects only (no instanceof): HEAD ran
// it as Node (typed private field); the snapshot loses the writes (and then throws RangeError).
class Box<T> {
  #items: T[] = [];
  #byKey = new Map<string, T>();
  items(): string { return `${JSON.stringify(this.#items)} ${this.#byKey.size}`; }
  static viaPlace(b: Box<any>, x: any): void { b.#items.push(x); b.#byKey.set("k", x); b.#items[1] = x; }
  static copyFrom(dst: Box<any>, src: Box<any>): void { dst.#items = src.#items; src.#items.push("shared"); }
}
const a = new Box<any>();
Box.viaPlace(a, "s");
console.log("any instance", a.items());
const c = new Box<any>();
Box.copyFrom(c, a);
console.log("shared", c.items(), a.items());
