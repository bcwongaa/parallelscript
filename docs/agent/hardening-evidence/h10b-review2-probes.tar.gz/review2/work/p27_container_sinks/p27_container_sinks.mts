// C285 containers flowing into typed places: parameters, returns, fields, tuples
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function pushFirst(rows: any[][]): void { rows[0].push(1); }
function wrap(c: Cache<string, number>) {
  if (c instanceof MapLRU) return [c.matrix[0]];
  return [];
}
class Keep { rows: any[][] = []; }
function probe(c: Cache<string, number>, k: Keep): void {
  if (c instanceof MapLRU) {
    pushFirst([c.matrix[0]]);
    pushFirst([...c.matrix]);
    k.rows = [...c.matrix];
    const t = [c.matrix[1], 5] as const;
    t[0].push(3);
    const tup: [any[], number] = [c.matrix[1], 6];
    tup[0].push(4);
  }
}
const m = new MapLRU<string, number>("k", 1);
const k = new Keep();
probe(m, k);
k.rows[1].push(2);
wrap(m)[0].push(7);
console.log(JSON.stringify(m.matrix));
