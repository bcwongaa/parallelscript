// Pre-existing (HEAD too): `#v in o` in a static method of a generic class is PTS9001 (nil
// currentClass in privateIn, classes.go:1138).
class Box<T> {
  #v: T;
  constructor(v: T) { this.#v = v; }
  static isBox(o: Box<number>): boolean { return #v in o; }
}
console.log(Box.isBox(new Box<number>(1)));
