// partsAsIs (destructuring assignment of a Box<any> value) must not leak into a nested destructuring assignment of an `any` value
class Box<T> { items: T[] = []; constructor(public v: T) {} }
const raw: any = { list: [1, 2] };
const typedNums: number[] = [3, 4];
const anyHoldingNums: any = { list: typedNums };
let it: any[] = [];
let other: any[] = [];
({ items: it = (() => { ({ list: other } = anyHoldingNums); return []; })() } = new Box<any>(0) as any as Box<any>);
({ v: it = (() => { ({ list: other } = anyHoldingNums); return []; })() } = { v: undefined } as any as Box<any>);
other.push(5);
console.log(other.length, it.length, typedNums.length);
