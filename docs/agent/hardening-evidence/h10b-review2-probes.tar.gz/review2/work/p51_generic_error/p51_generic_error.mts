// A generic Error subclass narrowed in catch (unknown binding) and flowing out; rethrown; collected
class AppError<T> extends Error {
  details: T[] = [];
  constructor(message: string, public code: T) { super(message); this.name = "AppError"; }
}
const seen: AppError<any>[] = [];
function risky(n: number): void { if (n % 2) throw new AppError<number>(`odd ${n}`, n); throw new AppError<string>("even", "E"); }
for (let i = 0; i < 4; i++) {
  try { risky(i); } catch (e) {
    if (e instanceof AppError) {
      e.details.push(e.code);
      const kept = e;
      seen.push(kept);
      kept.details.push(kept.code);
    }
  }
}
console.log(seen.map((e) => `${e.name}:${e.message}:${e.code}:${JSON.stringify(e.details)}`).join(" | "));
try { try { risky(1); } catch (e) { if (e instanceof AppError) { const f = e; throw f; } } } catch (e2) { console.log("rethrown", e2 instanceof AppError, (e2 as AppError<any>).code); }
