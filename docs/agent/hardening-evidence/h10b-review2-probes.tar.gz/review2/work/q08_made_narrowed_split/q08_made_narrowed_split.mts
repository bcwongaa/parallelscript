// The made/narrowed split: forms one step out of a narrowing (const m2 = c, ident(c), [c][0], a C<any> param) into
// any[] places: read-only uses (copies are fine), writes (as-is TypeError or PTS1001), never silent
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function count(xs: any[]): number { return xs.length; }
function countRows(rows: any[][]): number { let n = 0; for (const r of rows) n += r.length; return n; }
function grow(xs: any[]): void { xs.push(1); }
function ident<T>(t: T): T { return t; }
function viaParam(m: MapLRU<any, any>): number { return count(m.items) + countRows(m.matrix); }
function probe(c: Cache<string, number>): string[] {
  const out: string[] = [];
  if (!(c instanceof MapLRU)) return out;
  const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).name}`); } };
  const m2 = c;
  t("readOnly", () => { count(m2.items); countRows(m2.matrix); viaParam(c); });
  t("grow", () => grow(m2.items));
  t("growIdent", () => grow(ident(c).items));
  t("growArr", () => grow([c][0].items));
  t("rowLocal", () => { const r: any[] = m2.matrix[0]; r.push(2); });
  t("spreadRows", () => { const rs = [...m2.matrix]; rs[1].push(3); });
  return out;
}
const m = new MapLRU<string, number>("k", 0);
console.log(probe(m).join(" "));
console.log(JSON.stringify([m.items, m.matrix]));
