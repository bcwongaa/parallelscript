// Programs using new Box<any> with Box<any> places (compiled on HEAD)
class Box<T> {
  items: T[] = [];
  next: Box<T> | null = null;
  constructor(public v: T) { this.items.push(v); }
  link(other: Box<T>): Box<T> { this.next = other; return other; }
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
function itemsOf(b: Box<any>): any[] { return b.items; }
const a = new Box<any>(1);
const xs = itemsOf(a);
xs.push("two");
console.log("items", a.items, xs === a.items);
const kept: any[] = a.items;
kept.push(3);
console.log("kept", a.items.length);
const b = new Box<any>("b");
a.link(b);
console.log("link", a.next === b, a.next!.v);
const m = a.map((v) => [v]);
console.log("map", m.v, m instanceof Box);
function sum(bs: Box<any>[]): number { let t = 0; for (const x of bs) t += x.v as number; return t; }
console.log("sum", sum([new Box<any>(1), new Box<any>(2)]));
const arr: Box<any>[] = [];
arr.push(a);
arr[0].items.push(9);
console.log("arr", a.items, arr.indexOf(a), arr.includes(b));
const mm = new Map<string, Box<any>>();
mm.set("a", a);
console.log("map get", mm.get("a") === a, mm.get("a")!.items.length);
let n: Box<any> | null = a;
let count = 0;
while (n) { count++; n = n.next; }
console.log("walk", count);
