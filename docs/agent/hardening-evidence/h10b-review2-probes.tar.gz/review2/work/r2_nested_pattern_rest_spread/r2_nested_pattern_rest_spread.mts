// R2: Box<any> places holding a Box<number> (and a value flowed out of an instanceof narrowing):
// a nested object pattern under for…of, a rest object and an object spread copy the object's
// arrays, so writes through them are lost silently. HEAD: PTS1001 at the Box<any> place / a
// TypeError at the flow. (`const { meta: { tags } } = b` keeps the array.)
interface Cache<K, V> { get(key: K): V | undefined; }
class Box<K, V> implements Cache<K, V> {
  items: V[] = [];
  meta = { tags: [] as V[] };
  constructor(public key: K) {}
  get(k: K): V | undefined { return undefined; }
}
function viaPlace(b: Box<any, any>): void {
  for (const { meta: { tags } } of [b]) tags.push(1);
  const { key, ...rest } = b;
  rest.items.push(2);
  const copy = { ...b };
  (copy as any).items.push(3);
  const { meta: { tags: kept } } = b;
  kept.push(4);
}
function viaFlow(c: Cache<string, number>): void {
  if (c instanceof Box) {
    for (const { meta: { tags } } of [c]) tags.push(5);
  }
}
const n = new Box<string, number>("k");
viaPlace(n);
viaFlow(n);
console.log(JSON.stringify([n.items, n.meta.tags]));
