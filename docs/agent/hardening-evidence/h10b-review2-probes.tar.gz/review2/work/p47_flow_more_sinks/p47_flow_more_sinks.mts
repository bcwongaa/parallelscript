// More ways a C<any> place's member reaches an any[] binding: callback patterns, map results, class fields, closures, Map values
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
class Holder { m: MapLRU<any, any> | null = null; }
function probe(c: Cache<string, number>, h: Holder): void {
  if (c instanceof MapLRU) {
    [c].forEach(({ items }) => items.push(1));
    [c].map((m) => m)[0].items.push(2);
    h.m = c;
    const byKey = new Map<string, MapLRU<any, any>>([["k", c]]);
    byKey.get("k")!.items.push(3);
    for (const [, { items }] of byKey) items.push(4);
    const arr = [c];
    const [{ items: first }] = arr;
    first.push(5);
  }
}
const m = new MapLRU<string, number>("k", 0);
const h = new Holder();
probe(m, h);
h.m!.items.push(6);
const { items } = h.m!;
items.push(7);
console.log(JSON.stringify(m.items));
