// R1-F14: a narrowed instance's rows spread into a call's rest parameter (any[][]) are copied: the write is lost silently (snapshot and HEAD). C285's "spreads into calls".
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function pushRest(...rows: any[][]): void { rows[0].push(1); }
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    pushRest(...c.matrix);
  }
}
const m = new MapLRU<string, number>("k", 1);
probe(m);
console.log(JSON.stringify(m.matrix)); // Node: [[1],[]]
