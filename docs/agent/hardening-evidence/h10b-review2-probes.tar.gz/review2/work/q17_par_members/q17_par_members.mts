// .par views over a Box<any> object's members (Box<any> objects only), threads 1 2 4
class Box<T> {
  items: T[] = [];
  matrix: T[][] = [];
  constructor(n: number, f: (i: number) => T) { for (let i = 0; i < n; i++) { this.items.push(f(i)); this.matrix.push([f(i)]); } }
}
const b = new Box<any>(40, (i) => i);
console.log(b.items.map((x) => x * 2).reduce((p: number, c: number) => p + c, 0));
console.log(b.matrix.map((r) => r.length + r[0]).reduce((p: number, c: number) => p + c, 0));
const sorted = b.items.filter((x) => x % 3 === 0);
console.log(sorted.length);
