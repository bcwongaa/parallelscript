// Operations HEAD did on typed Box<any> objects that a dynamic value may not support
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  get(): T { return this.v; }
  add(x: T): number { return this.items.push(x); }
}
const b = new Box<any>(1);
const g = b.get;
console.log("call", b.add.call(b, 2), b.add.apply(b, [3]), typeof b.get);
console.log("in", "v" in b, "get" in b, b.hasOwnProperty("v"));
console.log("elem", b["v"], b["items"].length);
const key = "v" as const;
b[key] = 5;
console.log("key", b.v);
const { v, ...rest } = b;
console.log("rest", v, JSON.stringify(rest));
console.log("method ref", [b].map(Box.prototype.get.call.bind(Box.prototype.get)).length);
