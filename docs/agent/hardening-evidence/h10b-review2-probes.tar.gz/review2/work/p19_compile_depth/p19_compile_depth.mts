// compile time: nested literals, conditionals and ?? chains of depth 40 over narrowed rows and Box<any> places
class Box<T> {
  matrix: T[][] = [[1 as any]];
  next: Box<T> | null = null;
  constructor(public v: T) {}
}
function f(h: object, flag: boolean, b: Box<any>) {
  if (h instanceof Box) {
    const deep = [[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[h.matrix[0]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]];
    console.log(JSON.stringify(deep).length);
    const cond = flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : flag ? h.matrix[0] : h.matrix[0];
    cond.push(2);
    const nn = b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b.next ?? b;
    console.log(nn.v, h.matrix[0].length);
    const sp = [...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix, ...h.matrix];
    console.log(sp.length);
  }
}
f(new Box<number>(5), true, new Box<any>(1));
