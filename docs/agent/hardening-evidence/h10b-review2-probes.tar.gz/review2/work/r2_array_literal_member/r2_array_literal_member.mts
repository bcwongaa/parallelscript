// R2: an array literal of a Box<any> object's any[] member converted to an annotated any[][] (Box<any> objects
// only, no instanceof): HEAD ran it as Node; snapshot 2 throws the as-is TypeError although the object is Box<any>.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
}
const b = new Box<any>(1);
const all: any[][] = [b.items];
all[0].push(2);
function rows(x: Box<any>): any[][] { return [x.items, x.items]; }
rows(b)[1].push(3);
const pair: [any[], number] = [b.items, 0];
pair[0].push(4);
console.log(b.items, all.length);
