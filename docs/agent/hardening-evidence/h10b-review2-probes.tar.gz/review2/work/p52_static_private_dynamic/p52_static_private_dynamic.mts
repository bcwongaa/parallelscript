// Static private members reached through the class (typed) and through dynamic receivers holding instances
class Reg<T> {
  static #count = 0;
  static #bump(): number { return ++Reg.#count; }
  #id: number;
  constructor(public v: T) { this.#id = Reg.#bump(); }
  static idOf(o: object): number { return o instanceof Reg ? o.#id : -1; }
  static total(): number { return Reg.#count; }
  static tryStaticOnInstance(o: any): string { try { return `${o.#count}`; } catch (e) { return (e as Error).name; } }
}
const a = new Reg<number>(1), b = new Reg<string>("b");
console.log(Reg.idOf(a), Reg.idOf(b), Reg.total(), Reg.tryStaticOnInstance(a));
