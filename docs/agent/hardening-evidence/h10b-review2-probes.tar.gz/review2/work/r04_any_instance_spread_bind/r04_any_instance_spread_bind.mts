// R1-F4: object spread, rest destructuring and call/apply/bind of a Box<any> value's method.
// Box<any> objects only, no instanceof. HEAD ran it as Node; the snapshot is PTS1001
// (spreading a value into an object; `bind`/`call` on a value).
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  add(x: T): number { this.items.push(x); return this.items.length; }
}
const b = new Box<any>(1);
const copy = { ...b };
const { v, ...rest } = b;
const add = b.add.bind(b);
console.log(JSON.stringify(copy), v, JSON.stringify(rest), add("x"), b.add.call(b, "y"), b.add.apply(b, ["z"]), b.items);
