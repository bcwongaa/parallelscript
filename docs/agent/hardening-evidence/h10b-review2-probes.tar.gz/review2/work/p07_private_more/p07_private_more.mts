// Private names: `this` in private function fields, evaluation order, nested/shadowing classes, anonymous classes
let log: string[] = [];
function arg(x: number): number { log.push(`arg${x}`); return x; }
class Cell<T> {
  #v: T;
  #self = function (this: any): string { return this === undefined ? "undef-this" : "has-this"; };
  constructor(v: T) { this.#v = v; }
  #m(a: number, b: number): number { return a + b; }
  static run(o: any): string {
    const r1 = o.#self();
    let r2: string;
    try { r2 = `${o.#m(arg(1), arg(2))}`; } catch (e) { r2 = "threw"; }
    return `${r1} ${r2} ${log.join(",")}`;
  }
  static inner(o: any, p: any): string {
    class Inner {
      #v = "inner";
      read(x: any): string { return `${x.#v}`; }
      write(x: any, y: any): void { x.#v = y; }
    }
    const i = new Inner();
    i.write(i, "inner2");
    let other: string;
    try { other = i.read(o); } catch (e) { other = (e as Error).message; }
    const viaOuter = (() => { p.#v = 77; return p.#v; })();
    return `${i.read(i)} ${other} ${viaOuter}`;
  }
}
console.log(Cell.run(new Cell<number>(1)));
log = [];
console.log(Cell.run({ }).replace(/^.*?undef-this|^/, "x"));
console.log(Cell.inner(new Cell<number>(1), new Cell<number>(2)));
const Anon = class<T> {
  #w: T;
  constructor(w: T) { this.#w = w; }
  static set(o: any, w: any): any { o.#w = w; return o.#w; }
  static call(o: any): any { return o.#g(); }
  #g(): string { return `g:${this.#w}`; }
};
const an = new Anon<number>(1);
console.log("anon", Anon.set(an, 5), Anon.call(an));
