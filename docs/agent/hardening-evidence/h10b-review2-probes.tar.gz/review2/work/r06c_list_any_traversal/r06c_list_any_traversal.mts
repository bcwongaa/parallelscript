// R1-F6c: a generic linked list used for any: the class's own traversal (ListNode<T> locals and
// fields are dynamic values in the instance for any); stderr has ms
class ListNode<T> {
  next: ListNode<T> | null = null;
  constructor(public value: T) {}
  sum(): number { let t = 0; let c: ListNode<T> | null = this; while (c) { t += c.value as number; c = c.next; } return t; }
}
let head = new ListNode<any>(0);
for (let i = 1; i < 2000; i++) { const n = new ListNode<any>(i); n.next = head; head = n; }
const t0 = Date.now();
let total = 0;
for (let k = 0; k < 1000; k++) total += head.sum();
console.log(total);
console.error("list", Date.now() - t0);
