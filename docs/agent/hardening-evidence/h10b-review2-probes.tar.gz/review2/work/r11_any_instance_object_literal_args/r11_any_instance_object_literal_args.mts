// R1-F11: object literals given to a Box<any> value's methods and fields whose types are object
// shapes (C289's class, now on every Box<any> value). Box<any> objects only, no instanceof.
// HEAD ran it as Node.
interface Meta { name: string; tags: string[] }
class Box<T> {
  metas: Meta[] = [];
  meta: Meta = { name: "", tags: [] };
  constructor(public v: T) {}
  setMeta(m: Meta): number { this.meta = m; return m.tags.length; }
  make(f: () => Meta): string { return f().name; }
}
const b = new Box<any>(1);
console.log(b.setMeta({ name: "a", tags: ["x"] }));
b.metas.push({ name: "b", tags: [] });
b.meta = { name: "c", tags: ["y", "z"] };
console.log(b.make(() => ({ name: "d", tags: [] })), b.metas.length, b.meta.tags.length);
