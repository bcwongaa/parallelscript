// Box<any> places: iteration protocol, async methods, setters, optional calls, method values, callbacks
class Bag<T> {
  #items: T[] = [];
  onAdd?: (x: T) => void;
  constructor(...xs: T[]) { this.#items.push(...xs); }
  *[Symbol.iterator](): Generator<T> { yield* this.#items; }
  async load(x: T): Promise<number> { await null; this.#items.push(x); return this.#items.length; }
  set last(x: T) { this.#items[this.#items.length - 1] = x; }
  get last(): T { return this.#items[this.#items.length - 1]; }
  each(f: (x: T, i: number) => void): void { this.#items.forEach(f); }
  add(x: T): this { this.#items.push(x); this.onAdd?.(x); return this; }
  get size(): number { return this.#items.length; }
}
async function main(b: Bag<any>): Promise<void> {
  for (const x of b) console.log("iter", x);
  console.log("spread", [...b], Array.from(b).length);
  console.log("load", await b.load("z"));
  b.last = "LAST";
  console.log("last", b.last);
  b.each((x, i) => console.log("each", i, x));
  b.onAdd = (x) => console.log("added", x);
  b.add(9).add(10);
  const f = b.add.bind(b);
  f(11);
  console.log("size", b.size);
  const [first, second] = b;
  console.log("destructure", first, second);
}
await main(new Bag<number>(1, 2));
await main(new Bag<any>("a"));
