// Generic private methods on dynamic receivers: explicit type args, callbacks, this returns, subclasses, recursion, wrong receivers, any receivers
class Tree<T> {
  kids: Tree<T>[] = [];
  constructor(public v: T) {}
  #map<U>(f: (x: T) => U): U[] { return [f(this.v), ...this.kids.flatMap((k) => (k as any).#map(f))]; }
  #pair<U, W>(u: U, w: W): [T, U, W] { return [this.v, u, w]; }
  #self<U>(u: U): this { return this; }
  static run(o: object): string {
    if (!(o instanceof Tree)) return "no";
    const a = o.#map((x) => `<${x}>`);
    const b = o.#pair<string, number>("s", 1);
    const c = o.#self(0) === o;
    return `${a} ${JSON.stringify(b)} ${c}`;
  }
  static viaAny(o: any): string { try { return JSON.stringify(o.#pair(1, 2)); } catch (e) { return (e as Error).message; } }
  static viaPlace(t: Tree<any>): string { return JSON.stringify(t.#map((x) => typeof x)); }
}
class NumTree extends Tree<number> {}
const t = new Tree<number>(1);
t.kids.push(new Tree<number>(2), new NumTree(3));
console.log(Tree.run(t));
console.log(Tree.run(new Tree<string>("s")));
console.log(Tree.viaAny(new NumTree(9)), Tree.viaAny({}));
console.log(Tree.viaPlace(t), Tree.viaPlace(new Tree<any>(true)));
