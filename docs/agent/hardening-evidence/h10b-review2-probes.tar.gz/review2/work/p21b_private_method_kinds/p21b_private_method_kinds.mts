// Private methods of many kinds called on dynamic receivers (object-source narrowing and `any`)
class Svc<T> {
  #log: string[] = [];
  constructor(public v: T) {}
  #gen<U>(x: U): U[] { return [x, x]; }
  async #load(n: number): Promise<number> { await null; return n * 2; }
  *#walk(n: number): Generator<number> { for (let i = 0; i < n; i++) yield i; }
  #opt(a: number, b = 10, ...rest: number[]): string { return `${a}+${b}+${rest.length}`; }
  #self(): this { this.#log.push("self"); return this; }
  #cb(f: (x: T) => string): string { return f(this.v); }
  static async run(o: object): Promise<string> {
    if (!(o instanceof Svc)) return "no";
    const g = "s,s";
    const l = await o.#load(4);
    const w = [...o.#walk(3)];
    const op = `${o.#opt(1)} ${o.#opt(1, 2)} ${o.#opt(1, 2, 3, 4)}`;
    const s = o.#self() === o;
    const c = o.#cb((x) => `cb:${x}`);
    return `${g} ${l} ${w} ${op} ${s} ${c} ${o.#log}`;
  }
  static async runAny(o: any): Promise<string> {
    return `1,1 ${await o.#load(1)} ${[...o.#walk(2)]} ${o.#opt(5)} ${o.#self() === o}`;
  }
}
console.log(await Svc.run(new Svc<number>(1)));
console.log(await Svc.runAny(new Svc<string>("a")));
