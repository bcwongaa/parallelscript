// Writes through private containers of dynamically held instances: arrays of functions, objects holding arrays, Map values, Set
class Hold<T> {
  #fns: ((x: T) => T)[] = [];
  #meta = { tags: [] as T[] };
  #byKey = new Map<string, T[]>([["k", []]]);
  #set = new Set<T>();
  state(): string { return `${this.#fns.length} ${JSON.stringify(this.#meta)} ${JSON.stringify([...this.#byKey])} ${this.#set.size}`; }
  static poke(o: object, x: any): void {
    if (!(o instanceof Hold)) return;
    o.#fns.push((y: any) => y);
    o.#meta.tags.push(x);
    o.#byKey.get("k")!.push(x);
    o.#set.add(x);
  }
  static pokePlace(h: Hold<any>, x: any): void { h.#meta.tags.push(x); h.#fns.push((y: any) => y); }
}
const h = new Hold<number>();
Hold.poke(h, 1);
console.log(h.state());
Hold.pokePlace(h, 2);
console.log(h.state());
