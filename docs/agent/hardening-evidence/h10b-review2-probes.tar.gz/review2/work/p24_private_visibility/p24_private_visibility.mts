// Private names must not be visible as string keys on dynamic values
class Box<T> {
  #v: T;
  #m(): number { return 1; }
  get #g(): number { return 2; }
  constructor(v: T) { this.#v = v; }
}
class Plain { #p = 3; q = 4; }
const o: any = new Box<number>(1);
const p: any = new Plain();
console.log(o["#v"], o["#m"], o["#g"], Object.keys(o), JSON.stringify(o), "#v" in o);
console.log(p["#p"], Object.keys(p), JSON.stringify(p), "#p" in p);
const anyBox: Box<any> = new Box<any>(5);
console.log(Object.keys(anyBox), JSON.stringify(anyBox));
