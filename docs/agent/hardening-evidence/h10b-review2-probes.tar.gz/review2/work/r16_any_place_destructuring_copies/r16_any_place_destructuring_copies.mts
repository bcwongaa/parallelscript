// R1-F16: Box<any> places holding a Box<number>: names bound by destructuring (a for…of
// pattern over Box<any>[], a parameter pattern, a destructuring assignment) are copies of the
// object's arrays, so writes through them are lost silently. HEAD was PTS1001 at the Box<any>
// places. (`const { items } = b` and `const items = b.items` keep the array.)
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
const n = new Box<number>(0);
const boxes: Box<any>[] = [n];
for (const { items } of boxes) items.push(1);
function take({ items }: Box<any>): void { items.push(2); }
take(n);
let it: any[] = [];
({ items: it } = boxes[0]);
it.push(3);
const b: Box<any> = n;
const { items } = b;
items.push(4);
const direct = b.items;
direct.push(5);
console.log(JSON.stringify(n.items));
