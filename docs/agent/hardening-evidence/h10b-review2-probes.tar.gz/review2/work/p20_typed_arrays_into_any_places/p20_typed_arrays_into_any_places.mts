// Typed Box<number>[] and Map<string, Box<number>> given to Box<any>[] / Map<string, Box<any>> places that change them
class Box<T> { constructor(public v: T) {} }
function addAll(bs: Box<any>[]): void { bs.push(new Box<any>(9)); bs[0].v = 100; }
function readAll(bs: Box<any>[]): number { return bs.length; }
function addMap(m: Map<string, Box<any>>): void { m.set("z", new Box<any>(0)); }
const typed: Box<number>[] = [new Box(1)];
addAll(typed);
console.log("array", typed.length, typed[0].v, readAll(typed));
const tm = new Map<string, Box<number>>();
addMap(tm);
console.log("map", tm.size);
const held: Box<any>[] = typed;
held.push(new Box("s"));
console.log("held", typed.length);
