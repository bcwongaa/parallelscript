// `#f in o` semantics: generic family, subclasses, non-objects, static privates, methods, dynamic receivers, static methods
class Box<T> {
  #v: T;
  static #count = 0;
  #m(): number { return 1; }
  constructor(v: T) { this.#v = v; Box.#count++; }
  static has(o: any): string {
    const r: string[] = [];
    for (const f of [() => #v in o, () => #m in o, () => #count in o]) {
      try { r.push(String(f())); } catch (e) { r.push((e as Error).name); }
    }
    return r.join(",");
  }
  hasOther(o: Box<number>): boolean { return #v in o; }
  static hasObj(o: object): boolean { return #v in o; }
}
class Sub extends Box<string> { constructor() { super("s"); } }
class Plain { #v = 1; static has(o: any): boolean { return #v in o; } }
const n = new Box<number>(1);
console.log("number box", Box.has(n));
console.log("string box", Box.has(new Box<string>("x")));
console.log("sub", Box.has(new Sub()));
console.log("plain obj", Box.has({}));
console.log("plain class", Box.has(new Plain()), Plain.has(n), Plain.has(new Plain()));
console.log("primitive", Box.has(5));
console.log("null", Box.has(null));
console.log("typed", new Box<string>("q").hasOther(n), Box.hasObj(n), Box.hasObj([]));
