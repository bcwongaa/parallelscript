// R1-F9: a parameter that only reads, and a read-only .par view, of a container made from a narrowed instance's rows (a spread,
// new Set). HEAD ran it as Node (the copy is only read); the snapshot is PTS1001.
// threads: 1 2 4
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  constructor(public key: K, public val: V) { for (let i = 0; i < 50; i++) this.matrix.push([i as V]); }
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function count(rows: any[][]): number { let n = 0; for (const r of rows) n += r.length; return n; }
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const rows = [...c.matrix];
    console.log("count", count([...c.matrix]));
    console.log("lens", rows.map((r) => r.length + 1).reduce((a, b) => a + b, 0));
    console.log("set", [...new Set(c.matrix)].map((r) => r[0] * 2).reduce((a, b) => a + b, 0));
  }
}
probe(new MapLRU<string, number>("k", 1));
