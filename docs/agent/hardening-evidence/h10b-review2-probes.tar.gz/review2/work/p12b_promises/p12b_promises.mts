// C285: promises of a narrowed instance's rows: allSettled results, race, any, then callbacks inline
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], [], []];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
async function probe(c: Cache<string, number>): Promise<void> {
  if (c instanceof MapLRU) {
    const settled = await Promise.allSettled(c.matrix);
    const first = settled[0];
    if (first.status === "fulfilled") first.value.push(1);
    (await Promise.any(c.matrix))[0] ?? 0;
    const r = await Promise.any(c.matrix);
    r.push(3);
    await Promise.resolve(c.matrix[2]).then((row) => { row.push(4); });
    const p = Promise.all(c.matrix);
    const rows = await p;
    rows[2].push(5);
  }
}
async function probeU(c: unknown): Promise<void> {
  if (c instanceof MapLRU) {
    const settled = await Promise.allSettled(c.matrix);
    const first = settled[0];
    if (first.status === "fulfilled") first.value.push(6);
    const r = await Promise.race(c.matrix);
    r.push(7);
  }
}
const m = new MapLRU<string, number>("k", 1);
await probe(m);
console.log(JSON.stringify(m.matrix));
await probeU(m);
console.log(JSON.stringify(m.matrix));
