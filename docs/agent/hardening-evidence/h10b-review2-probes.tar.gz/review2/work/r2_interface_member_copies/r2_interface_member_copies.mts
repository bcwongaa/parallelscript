// R2: a Box<number> held as a dynamic value converted to an interface whose member is any[]
// (`Lister<any>`): writes through the interface's member are lost silently (the member read
// copies number[] to any[]). The interface exemption in copiesInstanceofDynamicValue lets it
// through for an instanceof narrowing itself (object source; HEAD: PTS1001) and for a Box<any>
// place (HEAD: PTS1001 at the place).
interface Lister<V> { items: V[]; }
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function fromObject(o: object): void {
  if (o instanceof Box) { const l: Lister<any> = o; l.items.push(5); }
}
function fromPlace(b: Box<any>): void { const l: Lister<any> = b; l.items.push(6); }
const n = new Box<number>(1);
fromObject(n);
fromPlace(n);
console.log(n.items);
