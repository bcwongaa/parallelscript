// C285 containers given to parameters that only read them, and kept in locals read later
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[1 as V], [2 as V, 3 as V]];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function count(rows: any[][]): number { let n = 0; for (const r of rows) n += r.length; return n; }
function first(rows: any[]): any { return rows[0]; }
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    console.log(count([...c.matrix]), count(Array.from(c.matrix)), first([...c.matrix[1]]), count([c.matrix[0]]));
    const s = new Set(c.matrix);
    console.log(s.size, s.has(c.matrix[0]), [...s].indexOf(c.matrix[1]));
    const m = new Map(c.matrix.map((r, i) => [i, r] as const));
    console.log(m.get(1) === c.matrix[1]);
  }
}
probe(new MapLRU<string, number>("k", 1));
