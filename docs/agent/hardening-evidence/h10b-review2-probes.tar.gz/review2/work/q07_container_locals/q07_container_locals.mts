// C285 containers bound to locals: let reassigned, captured by closures, passed to functions, iterator steps across loops
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], [], []];
  store = new Map<string, V[]>([["a", []], ["b", []]]);
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function probe(c: Cache<string, number>): (() => void) {
  if (!(c instanceof MapLRU)) return () => {};
  let rows = [...c.matrix];
  rows[0].push(1);
  const later = () => rows[1].push(2);
  const it = c.store.values();
  let step = it.next();
  while (!step.done) { step.value.push(3); step = it.next(); }
  const s = new Set(c.matrix);
  s.forEach((r) => r.push(4));
  const arr = Array.from(c.store.values());
  const second = arr[1];
  second.push(5);
  const e = c.store.entries().next();
  if (!e.done) e.value[1].push(6);
  rows = [[9], [8]];
  return later;
}
const m = new MapLRU<string, number>("k", 0);
const later = probe(m);
later();
console.log(JSON.stringify(m.matrix), JSON.stringify([...m.store]));
