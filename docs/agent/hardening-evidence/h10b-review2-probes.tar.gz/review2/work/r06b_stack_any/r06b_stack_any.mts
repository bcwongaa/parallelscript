// R1-F6b: a generic Stack used for `any` (new Stack<any>()), push/pop in a loop; stderr has ms
class Stack<T> {
  items: T[] = [];
  push(x: T): void { this.items.push(x); }
  pop(): T | undefined { return this.items.pop(); }
  get size(): number { return this.items.length; }
}
const s = new Stack<any>();
const t0 = Date.now();
let total = 0;
for (let i = 0; i < 2000000; i++) {
  s.push(i);
  if (s.size > 10) total += s.pop() as number;
}
console.log(total, s.size);
console.error("stack", Date.now() - t0);
