// Private writes/calls on dynamic receivers: narrowed from object, any, unknown; subclasses; accessors
class Counter<T> {
  #n = 0;
  #last: T | undefined = undefined;
  #fn: (x: number) => number = (x) => x * 2;
  get #twice(): number { return this.#n * 2; }
  set #setn(v: number) { this.#n = v; }
  #step(by: number, tag: T): number { this.#n += by; this.#last = tag; return this.#n; }
  static poke(o: object, v: any): string {
    if (o instanceof Counter) {
      o.#n = 10;
      o.#n += 5;
      o.#n++;
      ++o.#n;
      o.#last = v;
      const r = o.#step(3, v);
      o.#setn = o.#twice + 1;
      return `${r}:${o.#n}:${o.#last}:${o.#fn(4)}:${o.#twice}`;
    }
    return "no";
  }
  static pokeAny(o: any, tag: any): string {
    o.#n = 1;
    o.#n *= 7;
    return `${o.#step(1, tag)}:${o.#n}:${o.#fn(5)}`;
  }
  static pokeUnknown(o: unknown): string {
    if (o instanceof Counter) { o.#n = 2; o.#n **= 3; return `${o.#step(1, true)}:${o.#n}`; }
    return "no";
  }
  static pokeWrong(o: any): string {
    try { o.#n = 1; return "set ok"; } catch (e) { return `set ${(e as Error).constructor.name}: ${(e as Error).message}`; }
  }
  static callWrong(o: any): string {
    try { return `${o.#step(1, 0)}`; } catch (e) { return `call ${(e as Error).constructor.name}: ${(e as Error).message}`; }
  }
  static readWrong(o: any): string {
    try { return `${o.#n}`; } catch (e) { return `read ${(e as Error).constructor.name}: ${(e as Error).message}`; }
  }
  show(): string { return `${this.#n}/${this.#last}`; }
}
class Sub extends Counter<string> { extra = 1; }
class GSub<U> extends Counter<U> { more: U[] = []; }
const c = new Counter<number>();
console.log("object", Counter.poke(c, 9), c.show());
const sub = new Sub();
console.log("sub", Counter.poke(sub, "s"), sub.show());
const g = new GSub<boolean>();
console.log("gsub", Counter.poke(g, true), g.show());
console.log("any", Counter.pokeAny(c, 0), Counter.pokeAny(sub, "a"), c.show(), sub.show());
console.log("unknown", Counter.pokeUnknown(g), g.show());
console.log(Counter.pokeWrong({}));
console.log(Counter.callWrong({}));
console.log(Counter.readWrong({}));
console.log(Counter.pokeWrong(5));
