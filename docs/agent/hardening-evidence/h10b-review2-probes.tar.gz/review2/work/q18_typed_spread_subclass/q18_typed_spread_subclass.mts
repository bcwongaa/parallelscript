// Pre-existing check: spread of a typed Box<number> place holding a subclass object
class Box<T> { items: T[] = []; constructor(public v: T) {} }
class Labelled extends Box<number> { label = "L"; }
const b: Box<number> = new Labelled(3);
console.log(JSON.stringify({ ...b }));
