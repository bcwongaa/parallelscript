// Box<any> places in hot loops: a local of new Box<any>, a Box<any> parameter, a Box<any>[] array
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  get(): T { return this.v; }
}
function readAll(b: Box<any>, n: number): number {
  let t = 0;
  for (let i = 0; i < n; i++) { b.v = i; t += b.get() + b.v; }
  return t;
}
const N = 3000000;
const hot = new Box<any>(0);
let total = 0;
const t0 = Date.now();
for (let i = 0; i < N; i++) { hot.v = i; total += hot.v; }
const t1 = Date.now();
const r = readAll(new Box<any>(0), N);
const t2 = Date.now();
const arr: Box<any>[] = [];
for (let i = 0; i < 100; i++) arr.push(new Box<any>(i));
let s = 0;
for (let k = 0; k < N / 100; k++) for (const b of arr) s += b.v;
const t3 = Date.now();
console.log(total, r, s);
console.error("local", t1 - t0, "param", t2 - t1, "array", t3 - t2);
