// The program's only async call is a private async method called on a dynamic receiver (FamilyCall)
class Svc<T> {
  constructor(public v: T) {}
  async #load(n: number): Promise<number> { return n * 2; }
  static run(o: object): void {
    if (o instanceof Svc) o.#load(21).then((v) => console.log("loaded", v));
  }
}
Svc.run(new Svc<number>(1));
console.log("sync end");
