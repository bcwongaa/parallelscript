// A generic linked list used for `any`: the class's own code reads Node<T> fields (Node<any> in its instance for any)
class ListNode<T> {
  next: ListNode<T> | null = null;
  items: T[] = [];
  constructor(public value: T) { this.items.push(value); }
  append(v: T): ListNode<T> { const n = new ListNode(v); this.next = n; return n; }
  all(): T[] { const out: T[] = []; let c: ListNode<T> | null = this; while (c) { out.push(c.value); c = c.next; } return out; }
  merge(other: ListNode<T>): T[] { const xs = other.items; xs.push(this.value); return xs; }
}
const head = new ListNode<any>(1);
head.append("two").append(3);
const typed = new ListNode<number>(1);
typed.append(2);
