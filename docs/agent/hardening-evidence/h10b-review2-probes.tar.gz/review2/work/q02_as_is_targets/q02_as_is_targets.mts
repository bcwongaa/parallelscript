// As-is conversions of a Box<any> place's members (holding Box<any> and Box<number>) into places that hold dynamic values
class Box<T> {
  items: T[] = [];
  matrix: T[][] = [[]];
  m = new Map<string, T>();
  meta = { tags: [] as T[] };
  pairs: [T, T][] = [];
  rec: Record<string, T[]> = { a: [] };
  maybe: T[] | undefined = [];
  constructor(public v: T) { this.items.push(v); }
}
function grow(xs: any[]): void { xs.push("g"); }
function ret(b: Box<any>): any[] { return b.items; }
function run(label: string, b: Box<any>): void {
  const out: string[] = [];
  const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).name}`); } };
  t("local", () => { const xs: any[] = b.items; xs.push(1); });
  t("union", () => { const xs: any[] | undefined = b.items; xs?.push(2); });
  t("unknownArr", () => { const xs: unknown[] = b.items; xs.push(3); });
  t("nested", () => { const xs: any[][] = b.matrix; xs[0].push(4); });
  t("map", () => { const mm: Map<string, any> = b.m; mm.set("k", 5); });
  t("shape", () => { const o: { tags: any[] } = b.meta; o.tags.push(6); });
  t("tuples", () => { const ps: [any, any][] = b.pairs; ps.push([7, 7]); });
  t("record", () => { const r: Record<string, any[]> = b.rec; r.a.push(8); });
  t("optional", () => { const xs: any[] | undefined = b.maybe; xs!.push(9); });
  t("param", () => { grow(b.items); });
  t("return", () => { ret(b).push(10); });
  t("nullish", () => { const xs: any[] = b.maybe ?? []; xs.push(11); });
  t("ternary", () => { const xs: any[] = Math.random() < 2 ? b.items : []; xs.push(12); });
  t("assign", () => { let xs: any[] = []; xs = b.items; xs.push(13); });
  t("field", () => { const h = { xs: [] as any[] }; h.xs = b.items; h.xs.push(14); });
  t("arrayLit", () => { const all: any[][] = [b.items]; all[0].push(15); });
  console.log(label, out.join(" "));
  console.log(label, JSON.stringify([b.items, b.matrix, [...b.m], b.meta, b.pairs, b.rec, b.maybe]));
}
run("any", new Box<any>(0));
run("num", new Box<number>(0));
