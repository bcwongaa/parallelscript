// Spreads, rest patterns and call/apply/bind of Box<any> values holding subclass objects, objects with extra properties, and others
class Box<T> {
  items: T[] = [];
  opt?: string;
  #secret = 1;
  constructor(public v: T) {}
  get doubled(): number { return Number(this.v) * 2; }
  add(x: T): number { this.items.push(x); return this.items.length; }
  who(): string { return `${this.v}`; }
}
class Labelled extends Box<number> {
  label = "L";
  constructor(v: number) { super(v); this.opt = "set"; }
}
function show(b: Box<any>): void {
  const copy = { ...b };
  const { v, ...rest } = b;
  const rec: Record<string, any> = { ...b };
  console.log(JSON.stringify(copy), Object.keys(copy).join(","), v, JSON.stringify(rest), Object.keys(rec).join(","));
  rest.items.push("r");
  (copy as any).items.push("c");
  console.log("shared", b.items.length, (copy as any).items === b.items);
  const bound = b.add.bind(b);
  const other = new Box<string>("o");
  console.log("bind", bound(b.v), b.add.call(other, "x"), other.items, b.who.apply(other, []), b.who.call(b));
}
show(new Box<any>(1));
show(new Box<number>(2));
show(new Labelled(3));
show({ v: 4, items: [], extra: true, add(x: any) { return 0; }, who() { return "lit"; } } as any as Box<any>);
