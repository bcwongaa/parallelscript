// R1-F8b: an any[] (or an object holding one) stored into a Box<number>'s typed field through a Box<any> place is copied: later writes through it are lost silently. HEAD was PTS1001 at the Box<any> places.
class Box<T> {
  items: T[] = [];
  meta: { tags: T[] } = { tags: [] };
  constructor(public v: T) {}
}
function setItems(b: Box<any>, xs: any[]): void { b.items = xs; }
function setMeta(b: Box<any>, m: any): void { b.meta = m; }
const n = new Box<number>(1);
const xs: any[] = [];
setItems(n, xs);
xs.push(5);
console.log("items", n.items);
const m = { tags: [] as any[] };
setMeta(n, m);
m.tags.push(6);
console.log("meta", n.meta.tags);
const ys: any[] = [7];
const b: Box<any> = n;
b.items = ys;
ys.push(8);
console.log("direct", n.items);
