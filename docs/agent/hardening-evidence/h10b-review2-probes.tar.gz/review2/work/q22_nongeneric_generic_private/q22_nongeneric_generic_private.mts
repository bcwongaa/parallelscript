// A generic private method of a non-generic class, called on an `any` receiver and an object-source narrowing
class Plain {
  constructor(public tag: string) {}
  #g<U>(u: U): [string, U] { return [this.tag, u]; }
  static run(o: any): string { try { return JSON.stringify(o.#g(1)); } catch (e) { return (e as Error).message; } }
  static runObj(o: object): string { return o instanceof Plain ? JSON.stringify(o.#g("x")) : "no"; }
}
class SubPlain extends Plain {}
console.log(Plain.run(new Plain("p")), Plain.run(new SubPlain("s")), Plain.run({}), Plain.runObj(new SubPlain("o")));
