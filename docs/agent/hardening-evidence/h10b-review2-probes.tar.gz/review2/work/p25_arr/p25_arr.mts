// Box<any> members converted to typed places (number[], a shape, a Map) and written through them
class Box<T> {
  items: T[] = [];
  pairs: [T, T][] = [];
  m = new Map<string, T>();
  constructor(public v: T) { this.items.push(v); }
}
const a = new Box<any>(1);
const xs: number[] = a.items;
xs.push(5);
console.log("number[]", a.items.length);
