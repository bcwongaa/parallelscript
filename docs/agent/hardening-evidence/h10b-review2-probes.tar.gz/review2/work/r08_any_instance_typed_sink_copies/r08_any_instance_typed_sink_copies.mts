// R1-F8: a Box<any> object's members converted to typed places that are then changed: the
// snapshot copies silently (writes lost), where HEAD was PTS1001 for the tuple array and the
// Map (the number[] line was a silent copy on HEAD too). No instanceof anywhere.
class Box<T> {
  items: T[] = [];
  pairs: [T, T][] = [];
  m = new Map<string, T>();
  constructor(public v: T) {}
}
const a = new Box<any>(1);
const ps: [number, number][] = a.pairs;
ps.push([1, 2]);
const mm: Map<string, number> = a.m;
mm.set("k", 1);
const xs: number[] = a.items;
xs.push(5);
console.log(a.pairs.length, a.m.size, a.items.length);
