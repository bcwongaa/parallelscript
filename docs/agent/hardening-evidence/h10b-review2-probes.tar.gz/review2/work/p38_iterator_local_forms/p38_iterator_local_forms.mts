// C285: iterators of a narrowed instance's members kept in locals, then consumed (for…of, spread, Array.from, destructuring)
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<string, V[]>([["a", []]]);
  matrix: V[][] = [[]];
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function probe(c: Cache<string, number>): void {
  if (c instanceof MapLRU) {
    const it = c.store.values();
    for (const v of it) v.push(1);
    const it2 = c.matrix.values();
    [...it2][0].push(2);
    const it3 = c.store.values();
    Array.from(it3)[0].push(3);
    const [first] = c.store.values();
    first.push(4);
    const [[k, v]] = c.store;
    v.push(5);
    const { value } = c.matrix.values().next();
    value!.push(6);
  }
}
const m = new MapLRU<string, number>("k", 1);
probe(m);
console.log(JSON.stringify([...m.store]), JSON.stringify(m.matrix));
