// Destructuring Box<any> values: nested member patterns, defaults, renames, rest objects, array patterns of members, assignment forms
class Box<T> {
  items: T[] = [];
  meta = { tags: [] as T[], deep: { list: [] as T[] } };
  matrix: T[][] = [[], []];
  constructor(public v: T) {}
}
function probe(b: Box<any>): void {
  const { meta: { tags } } = b;
  tags.push(1);
  const { meta: { deep: { list } } } = b;
  list.push(2);
  const { items: renamed = [] } = b;
  renamed.push(3);
  const { v, ...rest } = b;
  rest.items.push(4);
  const [row0] = b.matrix;
  row0.push(5);
  const { matrix: [, row1] } = b;
  row1.push(6);
  for (const { meta: { tags: t2 } } of [b]) t2.push(7);
  [b].forEach(({ meta }) => meta.tags.push(8));
  let tg: any[] = [];
  ({ meta: { tags: tg } } = b);
  tg.push(9);
}
for (const b of [new Box<any>(0), new Box<number>(0)]) {
  try { probe(b); } catch (e) { console.log("ERR", (e as Error).message); }
  console.log(JSON.stringify([b.items, b.meta, b.matrix]));
}
