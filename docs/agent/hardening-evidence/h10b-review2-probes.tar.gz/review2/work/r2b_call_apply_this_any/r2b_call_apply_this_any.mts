// R2: the same `.call(thisArg)` / `.apply(thisArg)` on a method read from a value declared any
class Box<T> {
  constructor(public v: T) {}
  who(): string { return `${this.v}`; }
}
const o: any = new Box<string>("b");
const other = new Box<string>("o");
const f = o.who;
console.log(o.who.call(other), o.who.apply(other, []), f.call(other));
