// Box<any> in promises, generators, closures, optional fields, class fields with defaults
class Box<T = any> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
}
async function load(flag: boolean): Promise<Box<any>> { await null; return flag ? new Box<number>(1) : new Box("s"); }
function* gen(): Generator<Box<any>, Box<any>, Box<any> | undefined> {
  const got = yield new Box<number>(2);
  if (got) got.items.push(99);
  return new Box<boolean>(true);
}
const a = await load(true);
a.items.push(5);
console.log("async", a.items, (await load(false)).v);
const it = gen();
const first = it.next();
const fb = first.value;
console.log("gen first", fb.v, first.done);
const sent = new Box<number>(7);
const last = it.next(sent);
console.log("gen last", last.value.v, last.done, sent.items);
let captured: Box = new Box<number>(3);
const bump = () => { captured.v = captured.v + 1; return captured.v; };
console.log("closure", bump(), bump());
captured = new Box("x");
console.log("reassigned", bump());
class Holder { slot?: Box; list: Box[] = []; }
const h = new Holder();
h.slot = new Box<number>(4);
h.list.push(new Box<string>("y"), h.slot);
h.slot.v += 1;
console.log("holder", h.list.map((b) => b.v), h.slot?.items);
