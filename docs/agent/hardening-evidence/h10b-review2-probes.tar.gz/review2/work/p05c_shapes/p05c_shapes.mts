// tsc type shapes around Box<any>: unions, Readonly, nested generics, intersections, tuples
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
  get(): T { return this.v; }
}
class Bag<T> {
  list: T[] = [];
  constructor(public v: T) {}
  get(): T { return this.v; }
}
const n = new Box(1);
const s = new Box("s");
function opt(b: Box<any> | undefined): string { return b ? `${b.get()}` : "none"; }
console.log("opt", opt(n), opt(undefined), opt(s));
function ro(b: Readonly<Box<any>>): number { b.items.push(b.v); return b.items.length; }
console.log("ro", ro(n), n.items.length);
function either(x: Box<any> | Bag<any>): string { return `${x.get()}:${x instanceof Box}`; }
console.log("either", either(n), either(new Bag<number>(3)), either(s));
const nested = new Box<Box<number>>(n);
const outerAny: Box<any> = nested;
outerAny.v.v = 101;
console.log("outerAny", n.v, outerAny.get() === n);
const tup: [Box<any>, Box<any>] = [n, s];
tup[1].v = "z";
console.log("tuple", s.v, tup[0] === n);
const mb = new Map<Box<any>, number>();
mb.set(n, 1); mb.set(s, 2);
console.log("mapkey", mb.get(n), mb.get(s), mb.has(new Box(1)));
const st = new Set<Box<any>>([n, s, n]);
console.log("set", st.size, st.has(s));
const u: Box<any> | number = Math.random() > 2 ? 1 : n;
console.log("union num", typeof u, u === n);
