// An event emitter used for any (Emitter<any>): handlers added and removed by identity through dynamic calls
class Emitter<T> {
  handlers: ((x: T) => void)[] = [];
  on(h: (x: T) => void): void { this.handlers.push(h); }
  off(h: (x: T) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
  emit(x: T): void { for (const h of this.handlers) h(x); }
}
const e = new Emitter<any>();
const log = (x: any) => console.log("got", x);
function named(x: any): void { console.log("named", x); }
e.on(log);
e.on(named);
e.emit(1);
console.log(e.off(log), e.off(named), e.handlers.length, e.handlers.includes(log));
e.emit(2);
const typedE = new Emitter<number>();
const h = (n: number) => console.log("typed", n);
typedE.on(h);
const viaAny: Emitter<any> = typedE;
console.log(viaAny.off(h), typedE.handlers.length);
