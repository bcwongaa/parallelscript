// C285 container forms the tests don't cover: objects of a narrowed instance's any-typed members
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  store = new Map<string, V[]>([["k", []]]);
  constructor(public key: K, public val: V) {}
  get(k: K): V | undefined { return k === this.key ? this.val : undefined; }
}
function pushTo(...rows: any[][]): void { rows[0].push(1); }
function run(label: string, c: Cache<string, number>, f: (m: any) => void): void {
  if (c instanceof MapLRU) {
    try { f(c); } catch (e) { console.log(label, "ERR", String(e)); }
    console.log(label, JSON.stringify(c.matrix), JSON.stringify([...c.store]));
    c.matrix = [[], []];
    c.store = new Map([["k", []]]);
  }
}
const mk = () => new MapLRU<string, number>("k", 1);
run("concat", mk(), (c) => { if (c instanceof MapLRU) { const all = c.matrix.concat([]); all[0].push(2); } });
run("concat2", mk(), (c) => { if (c instanceof MapLRU) { const all = [[9]].concat(c.matrix); all[1].push(3); } });
run("slice", mk(), (c) => { if (c instanceof MapLRU) { c.matrix.slice(0, 1)[0].push(4); } });
run("flat", mk(), (c) => { if (c instanceof MapLRU) { const rows = [c.matrix].flat(); rows[0].push(5); } });
run("fromEntries", mk(), (c) => { if (c instanceof MapLRU) { const o = Object.fromEntries(c.store); o.k.push(6); } });
run("groupBy", mk(), (c) => { if (c instanceof MapLRU) { const g = Map.groupBy(c.matrix, (r) => "a"); g.get("a")![0].push(7); } });
run("spreadCall", mk(), (c) => { if (c instanceof MapLRU) { pushTo(...c.matrix); } });
run("destructAssign", mk(), (c) => { if (c instanceof MapLRU) { let a: any[] = [], b: any[] = []; [a, b] = c.matrix; a.push(8); } });
run("destructSpread", mk(), (c) => { if (c instanceof MapLRU) { const [first, ...rest] = c.matrix; rest[0].push(9); } });
run("structuredClone", mk(), (c) => { if (c instanceof MapLRU) { const cl = structuredClone(c.matrix); cl[0].push(10); } });
run("toReversed", mk(), (c) => { if (c instanceof MapLRU) { c.matrix.toReversed()[1].push(11); } });
run("mapIdent", mk(), (c) => { if (c instanceof MapLRU) { c.matrix.map((r) => r)[0].push(12); } });
run("arrayOfSpread", mk(), (c) => { if (c instanceof MapLRU) { Array.of(...c.matrix)[0].push(13); } });
run("setThenArray", mk(), (c) => { if (c instanceof MapLRU) { [...new Set(c.matrix)][0].push(14); } });
run("mapValuesArray", mk(), (c) => { if (c instanceof MapLRU) { [...c.store.values()][0].push(15); } });
run("entriesForOf", mk(), (c) => { if (c instanceof MapLRU) { for (const [k, v] of c.store) v.push(16); } });
run("objValues", mk(), (c) => { if (c instanceof MapLRU) { const o = { a: c.matrix[0] }; Object.values(o)[0].push(17); } });
