// Box<any> values printed, stringified, compared, used in templates and with toString
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
  toString(): string { return `Box(${this.v})`; }
}
const a = new Box<any>(1);
const b: Box<any> = new Box<any>("x");
console.log(a, b);
console.log(`${a} ${b}`, String(a), a + "!", [a, b].join("|"));
console.log(JSON.stringify({ a, b }));
console.log(a == b, a === a, a != null, typeof a, a instanceof Box);
const maybe: Box<any> | undefined = Math.random() > 2 ? undefined : a;
console.log(maybe?.v, maybe ?? "none", maybe?.items.length);
const arr = [a, b];
console.log(arr.map(String), arr.sort((x, y) => String(x.v).localeCompare(String(y.v))).map((x) => x.v));
console.log(Object.entries(a).length);
