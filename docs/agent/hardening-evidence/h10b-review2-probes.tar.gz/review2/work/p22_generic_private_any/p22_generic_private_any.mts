// A generic private method called on another instance (Box<T> parameter) in the class's instance for any
class Box<T> {
  constructor(public v: T) {}
  #pair<U>(x: U): [T, U] { return [this.v, x]; }
  pairWith(other: Box<T>, tag: string): string { return JSON.stringify(other.#pair(tag)); }
}
const a = new Box<any>(1);
const b = new Box<any>("b");
console.log(a.pairWith(b, "t"));
const n = new Box<number>(1);
console.log(n.pairWith(new Box<number>(2), "u"));
