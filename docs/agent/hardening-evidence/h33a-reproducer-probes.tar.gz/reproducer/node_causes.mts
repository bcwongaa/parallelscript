// Node's full causes for the protocol failures of fetch_tls.pts (reproducer probe, H33a).
const bases = new Map<string, string>();
for (const arg of process.argv.slice(2)) {
  const equals = arg.indexOf("=");
  bases.set(arg.slice(0, equals), arg.slice(equals + 1));
}
for (const name of ["plain-as-https", "closes", "tls10", "requires-client-cert", "untrusted", "self-signed", "wrong-host"]) {
  try {
    const response = await fetch(bases.get(name) + "/hello");
    console.log(name, "fulfilled", response.status);
  } catch (e) {
    const cause = (e as Error).cause as any;
    console.log(name, JSON.stringify({ ctor: cause?.constructor?.name, code: cause?.code, message: cause?.message, library: cause?.library, reason: cause?.reason, errno: cause?.errno, syscall: cause?.syscall }));
  }
}
