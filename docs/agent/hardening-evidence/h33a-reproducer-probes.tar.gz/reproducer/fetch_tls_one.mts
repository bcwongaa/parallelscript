// One fetch, of the URL that is the first argument, for the trust-store tests of
// https_test.go (H33): the response's status, or the error and its cause's code and message.

type Coded = Error & { code: string };

try {
  const response = await fetch(process.argv[2]);
  console.log(response.status);
} catch (e) {
  const error = e as Error;
  const cause = error.cause as Coded | undefined;
  console.log(`${error.name}: ${error.message} | ${cause?.code} | ${cause?.message}`);
}
