package h33probe

import (
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

// ---------------------------------------------------------------- throwaway certificates

// authority is a CA's certificate and key, which sign other certificates.
type authority struct {
	cert *x509.Certificate
	key  crypto.Signer
}

// newKey makes a private key of kind: "p256", "p384" or "rsa" (2048 bits).
func newKey(t *testing.T, kind string) crypto.Signer {
	t.Helper()
	var key crypto.Signer
	var err error
	switch kind {
	case "p256":
		key, err = ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	case "p384":
		key, err = ecdsa.GenerateKey(elliptic.P384(), rand.Reader)
	case "rsa":
		key, err = rsa.GenerateKey(rand.Reader, 2048)
	default:
		t.Fatalf("no key of kind %q", kind)
	}
	assert.NilError(t, err)
	return key
}

// certify makes the certificate template describes, for key, signed by issuer, or by key itself if issuer is nil.
func certify(t *testing.T, template *x509.Certificate, key crypto.Signer, issuer *authority) *x509.Certificate {
	t.Helper()
	serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 127))
	assert.NilError(t, err)
	template.SerialNumber = serial
	parent, signer := template, key
	if issuer != nil {
		parent, signer = issuer.cert, issuer.key
	}
	der, err := x509.CreateCertificate(rand.Reader, template, parent, key.Public(), signer)
	assert.NilError(t, err)
	cert, err := x509.ParseCertificate(der)
	assert.NilError(t, err)
	return cert
}

// newAuthority makes a CA called name with a key of kind, signed by issuer (an intermediate
// CA) or by itself (a root), valid from an hour ago for a day unless edit changes that.
func newAuthority(t *testing.T, name string, kind string, issuer *authority, edit func(*x509.Certificate)) *authority {
	t.Helper()
	key := newKey(t, kind)
	now := time.Now()
	template := &x509.Certificate{
		Subject:               pkix.Name{CommonName: name, Organization: []string{"ParallelScript tests"}},
		NotBefore:             now.Add(-time.Hour),
		NotAfter:              now.Add(24 * time.Hour),
		IsCA:                  true,
		BasicConstraintsValid: true,
		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
	}
	if edit != nil {
		edit(template)
	}
	return &authority{certify(t, template, key, issuer), key}
}

// serverCert makes a server's certificate, signed by issuer (by itself if nil), and the
// chain the server sends: the certificate, then sent. By default the certificate is for
// localhost, 127.0.0.1 and ::1, valid from an hour ago for a day, for TLS servers, with a
// P-256 key; edit changes that.
func serverCert(t *testing.T, issuer *authority, kind string, edit func(*x509.Certificate), sent ...*x509.Certificate) tls.Certificate {
	t.Helper()
	key := newKey(t, kind)
	now := time.Now()
	template := &x509.Certificate{
		Subject:               pkix.Name{CommonName: "localhost"},
		DNSNames:              []string{"localhost"},
		IPAddresses:           []net.IP{net.IPv4(127, 0, 0, 1), net.IPv6loopback},
		NotBefore:             now.Add(-time.Hour),
		NotAfter:              now.Add(24 * time.Hour),
		KeyUsage:              x509.KeyUsageDigitalSignature,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	if kind == "rsa" {
		template.KeyUsage |= x509.KeyUsageKeyEncipherment
	}
	if edit != nil {
		edit(template)
	}
	chain := tls.Certificate{Certificate: [][]byte{certify(t, template, key, issuer).Raw}, PrivateKey: key}
	for _, cert := range sent {
		chain.Certificate = append(chain.Certificate, cert.Raw)
	}
	return chain
}

// writePEM writes certs to a new PEM file in dir and returns its path.
func writePEM(t *testing.T, dir string, name string, certs ...*x509.Certificate) string {
	t.Helper()
	var out []byte
	for _, cert := range certs {
		out = append(out, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: cert.Raw})...)
	}
	path := filepath.Join(dir, name)
	assert.NilError(t, os.WriteFile(path, out, 0o644))
	return path
}

// ---------------------------------------------------------------- the servers

// tlsLab is the servers the TLS tests fetch from, each named (the programs get their base
// URLs as name=url arguments), the CA files that trust them or not, and the state of the
// servers that hold, drop or refuse connections, which the programs ask the plain server
// about, so that they know a failure came from the stage it was meant to.
type tlsLab struct {
	args      []string
	trusted   string   // a PEM file of the CAs the servers' good certificates come from
	untrusted string   // a PEM file of a CA that signs some servers' certificates, which no test trusts
	absent    []string // the labels of fetch_tls.pts's lines for servers this host can't have
	hellos    sync.Map
	mu        sync.Mutex
	states    map[string]string // what happened to the last connection of a server whose state the programs ask
}

// statePaths are the paths the plain server answers with the state of another server, or
// of those whose certificates don't verify (/unverified: the names of those a request reached).
var statePaths = []string{"/holds", "/closes", "/plain-as-https", "/tls10", "/requires-client-cert", "/stalled", "/unverified"}

// state is what happened to the last connection of the server that path names ("none" before one).
func (lab *tlsLab) state(path string) string {
	lab.mu.Lock()
	defer lab.mu.Unlock()
	if state, ok := lab.states[path]; ok {
		return state
	}
	return "none"
}

func (lab *tlsLab) setState(path string, state string) {
	lab.mu.Lock()
	defer lab.mu.Unlock()
	lab.states[path] = state
}

// mustNotReach is mux for the server called name, whose certificate no client may accept:
// a request that reaches it, which the client sent after a handshake it should have
// failed, adds name to the state of /unverified.
func (lab *tlsLab) mustNotReach(name string, mux http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		lab.mu.Lock()
		if reached := lab.states["/unverified"]; reached != "" {
			lab.states["/unverified"] = reached + ", " + name
		} else {
			lab.states["/unverified"] = name
		}
		lab.mu.Unlock()
		mux.ServeHTTP(w, r)
	})
}

// reset forgets the states, before a program runs.
func (lab *tlsLab) reset() {
	lab.mu.Lock()
	defer lab.mu.Unlock()
	lab.states = map[string]string{}
}

// name gives the server at base (a URL without a path) a name for the programs.
func (lab *tlsLab) name(name string, base string) {
	lab.args = append(lab.args, name+"="+base)
}

// base is the base URL of the server called name.
func (lab *tlsLab) base(name string) string {
	for _, arg := range lab.args {
		if found, ok := strings.CutPrefix(arg, name+"="); ok {
			return found
		}
	}
	panic("no server called " + name)
}

// listen listens on address and closes the listener when the test ends.
func listen(t *testing.T, address string) net.Listener {
	t.Helper()
	listener, err := net.Listen("tcp", address)
	assert.NilError(t, err)
	t.Cleanup(func() { _ = listener.Close() })
	return listener
}

// port is the port listener listens on.
func port(listener net.Listener) string {
	return strconv.Itoa(listener.Addr().(*net.TCPAddr).Port)
}

// serve serves mux on listener, quietly (a handshake that fails is what many tests want).
func serve(t *testing.T, listener net.Listener, mux http.Handler) {
	server := &http.Server{Handler: mux, ErrorLog: log.New(io.Discard, "", 0)}
	go func() { _ = server.Serve(listener) }()
	t.Cleanup(func() { _ = server.Close() })
}

// serveTLS serves handler over TLS with cert on a new listener at address (127.0.0.1 if
// empty), edit changing the TLS configuration, and returns the listener's port. It
// remembers what each client offered in its hello, for /hello to answer, and, if
// statePath isn't empty, that a hello came, as statePath's state.
func (lab *tlsLab) serveTLS(t *testing.T, handler http.Handler, address string, cert tls.Certificate, edit func(*tls.Config), statePath string) string {
	t.Helper()
	if address == "" {
		address = "127.0.0.1:0"
	}
	config := &tls.Config{
		Certificates: []tls.Certificate{cert},
		NextProtos:   []string{"http/1.1"},
		GetConfigForClient: func(hello *tls.ClientHelloInfo) (*tls.Config, error) {
			lab.hellos.Store(hello.Conn.RemoteAddr().String(), offered(hello))
			if statePath != "" {
				lab.setState(statePath, "hello")
			}
			return nil, nil
		},
	}
	if edit != nil {
		edit(config)
	}
	listener := listen(t, address)
	serve(t, tls.NewListener(listener, config), handler)
	return port(listener)
}

// offered is what a client's hello offers that a client of the contract offers alike: the
// application protocols and the TLS versions (not the cipher suites, groups or signature
// algorithms, which OpenSSL and the TLS library differ in).
func offered(hello *tls.ClientHelloInfo) string {
	var versions []string
	for _, version := range hello.SupportedVersions {
		if version&0x0f0f != 0x0a0a { // not GREASE
			versions = append(versions, tls.VersionName(version))
		}
	}
	return fmt.Sprintf("offered alpn=%q versions=%q", hello.SupportedProtos, versions)
}

// handlers are the routes of every server of the lab, plain and TLS.
func (lab *tlsLab) handlers() *http.ServeMux {
	mux := http.NewServeMux()
	mux.HandleFunc("/hello", func(w http.ResponseWriter, r *http.Request) {
		if r.TLS == nil {
			fmt.Fprintf(w, "%s plain", r.Method)
			return
		}
		hello, _ := lab.hellos.Load(r.RemoteAddr)
		fmt.Fprintf(w, "%s sni=%q alpn=%q %s, %s", r.Method, r.TLS.ServerName, r.TLS.NegotiatedProtocol, tls.VersionName(r.TLS.Version), hello)
	})
	mux.HandleFunc("/n/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "n %s", strings.TrimPrefix(r.URL.Path, "/n/"))
	})
	mux.HandleFunc("/echo", func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		fmt.Fprintf(w, "%s tls=%v length=%d type=%q authorization=%q cookie=%q x-kept=%q body=%q", r.Method, r.TLS != nil, r.ContentLength,
			r.Header.Get("Content-Type"), r.Header.Get("Authorization"), r.Header.Get("Cookie"), r.Header.Get("X-Kept"), body)
	})
	mux.HandleFunc("/redirect", func(w http.ResponseWriter, r *http.Request) {
		status, err := strconv.Atoi(r.URL.Query().Get("status"))
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		w.Header().Set("Location", r.URL.Query().Get("to"))
		w.WriteHeader(status)
	})
	mux.HandleFunc("/chunked", func(w http.ResponseWriter, r *http.Request) {
		for _, part := range []string{"one ", "two ", "three"} {
			_, _ = io.WriteString(w, part)
			w.(http.Flusher).Flush()
		}
	})
	mux.HandleFunc("/big", func(w http.ResponseWriter, r *http.Request) {
		piece := strings.Repeat("y", 64*1024)
		for range 319 {
			_, _ = io.WriteString(w, piece)
		}
		_, _ = io.WriteString(w, piece[:64*1024-3]+"end")
	})
	// hijacked writes raw itself, then ends the connection as end says: "close_notify"
	// (TLS's alert, then the TCP connection's end), "abruptly" (the TCP connection's end
	// alone) or "reset" (a TCP reset).
	hijacked := func(raw string, end string) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			conn, _, err := http.NewResponseController(w).Hijack()
			if err != nil {
				panic(err)
			}
			_, _ = io.WriteString(conn, raw)
			if secure, ok := conn.(*tls.Conn); ok && end != "close_notify" {
				conn = secure.NetConn()
			}
			if end == "reset" {
				_ = conn.(*net.TCPConn).SetLinger(0)
			}
			_ = conn.Close()
		}
	}
	const untilTheEnd = "HTTP/1.1 200 OK\r\ncontent-type: text/plain\r\n\r\nread until the end"
	const truncated = "HTTP/1.1 200 OK\r\ncontent-length: 100\r\n\r\nonly this"
	mux.HandleFunc("/close", hijacked(untilTheEnd, "close_notify"))
	mux.HandleFunc("/close-abruptly", hijacked(untilTheEnd, "abruptly"))
	mux.HandleFunc("/truncated", hijacked(truncated, "close_notify"))
	mux.HandleFunc("/truncated-abruptly", hijacked(truncated, "abruptly"))
	mux.HandleFunc("/reset", hijacked(truncated, "reset"))
	mux.HandleFunc("/stall", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Length", "100")
		_, _ = io.WriteString(w, "partial")
		w.(http.Flusher).Flush()
		lab.setState("/stalled", "sent")
		select {
		case <-r.Context().Done():
			lab.setState("/stalled", "left")
		case <-time.After(20 * time.Second):
		}
	})
	for _, path := range statePaths {
		mux.HandleFunc(path, func(w http.ResponseWriter, r *http.Request) { _, _ = io.WriteString(w, lab.state(path)) })
	}
	return mux
}

// What a raw server does after reading a client's first bytes.
const (
	closeAfterHello  = iota // closes the connection
	holdAfterHello          // holds it until the client closes it
	answerAfterHello        // answers as a plain HTTP server answers bytes that aren't HTTP, then closes
)

// serveRaw accepts TCP connections on 127.0.0.1 and reads what each client sends first,
// a ClientHello for a TLS client; then does what after says, recording each step as the
// state of path.
func (lab *tlsLab) serveRaw(t *testing.T, path string, after int) string {
	t.Helper()
	listener := listen(t, "127.0.0.1:0")
	go func() {
		for {
			conn, err := listener.Accept()
			if err != nil {
				return
			}
			go func() {
				defer conn.Close()
				lab.setState(path, "connected")
				_ = conn.SetReadDeadline(time.Now().Add(20 * time.Second))
				first := make([]byte, 16*1024)
				n, _ := conn.Read(first)
				if n == 0 || first[0] != 0x16 { // not a TLS handshake record
					lab.setState(path, fmt.Sprintf("read %q", first[:n]))
					return
				}
				lab.setState(path, "hello")
				switch after {
				case holdAfterHello:
					if _, err := io.Copy(io.Discard, conn); !isTimeout(err) {
						lab.setState(path, "left")
					}
				case answerAfterHello:
					_, _ = io.WriteString(conn, "HTTP/1.1 400 Bad Request\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\n400 Bad Request")
				}
			}()
		}
	}()
	return port(listener)
}

// isTimeout reports whether err is a read deadline passing.
func isTimeout(err error) bool {
	var netErr net.Error
	return errors.As(err, &netErr) && netErr.Timeout()
}

// wildcardNames are the names under pts.localhost the wildcard certificates are tested
// with, which resolve to the loopback addresses where the C library resolves *.localhost
// (systemd's nss-myhostname or resolved).
var wildcardNames = []string{"a.pts.localhost", "a.b.pts.localhost", "pts.localhost", "a.localhost", "ab.pts.localhost"}

// resolvesToLoopback reports whether the C library resolves each of names to a loopback
// address, as pts's and Node's getaddrinfo would; Go's own resolver answers for
// *.localhost without asking it.
func resolvesToLoopback(names ...string) bool {
	for _, name := range names {
		out, err := exec.Command("getent", "ahostsv4", name).Output()
		if err != nil || !strings.HasPrefix(string(out), "127.") {
			return false
		}
	}
	return true
}

// startTLSLab makes the lab's certificates and starts its servers, named for fetch_tls.pts:
//   - localhost, 127.0.0.1 and [::1] (if IPv6's loopback works): a certificate for all three from the trusted CA;
//     localhost-as-http is the localhost server at an http URL;
//   - tls12, tls13, rsa, rsa-tls12, p384, hello-retry, asks-for-client-cert: such servers, whose certificates verify;
//   - untrusted, untrusted-root-sent, untrusted-intermediate-sent, self-signed, expired, not-yet-valid, wrong-host
//     (for other.example), wrong-host-by-ip, untrusted-wrong-host, expired-wrong-host, intermediate-not-sent,
//     intermediate-sent, issuer-not-ca, client-auth-only, common-name-only (no subjectAltName), ip-as-dns-name
//     (127.0.0.1 as a DNS name), only-wildcard (*.localhost, at localhost), expired-untrusted, self-signed-expired,
//     intermediate-expired, common-name-wrong,
//     no-names (neither a subjectAltName nor a common name), ips-and-common-name (no DNS name in the
//     subjectAltName) and other-ip (127.0.0.2, if it listens): certificates to verify or not, and those that
//     shouldn't verify record a request that reaches them;
//   - wildcard, wildcard-two-deep, wildcard-bare (*.pts.localhost at a.pts.localhost, a.b.pts.localhost and
//     pts.localhost), wildcard-tld (*.localhost at a.localhost) and wildcard-partial (a*.pts.localhost at
//     ab.pts.localhost), if those names resolve;
//   - plain and plain-other: plain HTTP servers; plain-as-https answers a ClientHello as a plain HTTP server does;
//   - closes (closes the connection after the ClientHello), holds (holds it), tls10, requires-client-cert.
func startTLSLab(t *testing.T) *tlsLab {
	t.Helper()
	dir := t.TempDir()
	lab := &tlsLab{states: map[string]string{}}
	mux := lab.handlers()
	now := time.Now()
	expired := func(c *x509.Certificate) { c.NotBefore, c.NotAfter = now.Add(-48*time.Hour), now.Add(-24*time.Hour) }
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	rsaRoot := newAuthority(t, "PTS Test RSA Root CA", "rsa", nil, nil)
	p384Root := newAuthority(t, "PTS Test P-384 Root CA", "p384", nil, nil)
	other := newAuthority(t, "PTS Untrusted Root CA", "p256", nil, nil)
	intermediate := newAuthority(t, "PTS Test Intermediate CA", "p256", root, nil)
	otherIntermediate := newAuthority(t, "PTS Untrusted Intermediate CA", "p256", other, nil)
	expiredIntermediate := newAuthority(t, "PTS Expired Intermediate CA", "p256", root, expired)
	lab.trusted = writePEM(t, dir, "trusted.pem", root.cert, rsaRoot.cert, p384Root.cert)
	lab.untrusted = writePEM(t, dir, "untrusted.pem", other.cert)

	certFor := func(names ...string) func(*x509.Certificate) { // a certificate for names alone, the first its common name
		return func(c *x509.Certificate) {
			c.Subject.CommonName = names[0]
			c.DNSNames, c.IPAddresses = names, nil
		}
	}
	otherHost := certFor("other.example")
	good := serverCert(t, root, "p256", nil)

	main := lab.serveTLS(t, mux, "", good, nil, "")
	lab.name("localhost", "https://localhost:"+main)
	lab.name("127.0.0.1", "https://127.0.0.1:"+main)
	lab.name("localhost-as-http", "http://localhost:"+main)
	if listener, err := net.Listen("tcp", "[::1]:0"); err == nil {
		_ = listener.Close()
		lab.name("[::1]", "https://[::1]:"+lab.serveTLS(t, mux, "[::1]:0", good, nil, ""))
	} else {
		lab.absent = append(lab.absent, "by IPv6 address ")
	}
	if listener, err := net.Listen("tcp", "127.0.0.2:0"); err == nil { // Linux's loopback is 127/8, macOS's 127.0.0.1 alone
		_ = listener.Close()
		lab.name("other-ip", "https://127.0.0.2:"+lab.serveTLS(t, lab.mustNotReach("other-ip", mux), "127.0.0.2:0", good, nil, ""))
	} else {
		lab.absent = append(lab.absent, "by another IP address ")
	}
	// A certificate whose issuer isn't a CA (basicConstraints CA:FALSE); the server sends both.
	notCAKey := newKey(t, "p256")
	notCA := certify(t, &x509.Certificate{
		Subject: pkix.Name{CommonName: "PTS Not A CA"}, NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature, BasicConstraintsValid: true, IsCA: false,
	}, notCAKey, root)
	servers := []struct {
		name     string
		cert     tls.Certificate
		config   func(*tls.Config)
		verifies bool
	}{
		{"tls12", good, func(c *tls.Config) { c.MaxVersion = tls.VersionTLS12 }, true},
		{"tls13", good, func(c *tls.Config) { c.MinVersion = tls.VersionTLS13 }, true},
		{"rsa", serverCert(t, rsaRoot, "rsa", nil), nil, true},
		{"rsa-tls12", serverCert(t, rsaRoot, "rsa", nil), func(c *tls.Config) { c.MaxVersion = tls.VersionTLS12 }, true},
		{"p384", serverCert(t, p384Root, "p256", nil), nil, true},
		{"hello-retry", good, func(c *tls.Config) {
			c.MinVersion = tls.VersionTLS13
			c.CurvePreferences = []tls.CurveID{tls.CurveP384} // a key share clients don't send first
		}, true},
		{"asks-for-client-cert", good, func(c *tls.Config) { c.ClientAuth = tls.RequestClientCert }, true},
		{"untrusted", serverCert(t, other, "p256", nil), nil, false},
		{"untrusted-root-sent", serverCert(t, other, "p256", nil, other.cert), nil, false},
		{"untrusted-intermediate-sent", serverCert(t, otherIntermediate, "p256", nil, otherIntermediate.cert), nil, false},
		{"self-signed", serverCert(t, nil, "p256", nil), nil, false},
		{"expired", serverCert(t, root, "p256", expired), nil, false},
		{"not-yet-valid", serverCert(t, root, "p256", func(c *x509.Certificate) { c.NotBefore, c.NotAfter = now.Add(24*time.Hour), now.Add(48*time.Hour) }), nil, false},
		{"wrong-host", serverCert(t, root, "p256", otherHost), nil, false},
		{"untrusted-wrong-host", serverCert(t, other, "p256", otherHost), nil, false},
		{"expired-wrong-host", serverCert(t, root, "p256", func(c *x509.Certificate) { otherHost(c); expired(c) }), nil, false},
		{"intermediate-not-sent", serverCert(t, intermediate, "p256", nil), nil, false},
		{"intermediate-sent", serverCert(t, intermediate, "p256", nil, intermediate.cert), nil, true},
		{"issuer-not-ca", serverCert(t, &authority{notCA, notCAKey}, "p256", nil, notCA), nil, false},
		{"client-auth-only", serverCert(t, root, "p256", func(c *x509.Certificate) { c.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth} }), nil, false},
		{"common-name-only", serverCert(t, root, "p256", func(c *x509.Certificate) { c.DNSNames, c.IPAddresses = nil, nil }), nil, true},
		{"only-wildcard", serverCert(t, root, "p256", certFor("*.localhost")), nil, false},
		{"expired-untrusted", serverCert(t, other, "p256", expired), nil, false},
		{"self-signed-expired", serverCert(t, nil, "p256", expired), nil, false},
		{"intermediate-expired", serverCert(t, expiredIntermediate, "p256", nil, expiredIntermediate.cert), nil, false},
		{"common-name-wrong", serverCert(t, root, "p256", func(c *x509.Certificate) {
			c.Subject.CommonName = "other.example"
			c.DNSNames, c.IPAddresses = nil, nil
		}), nil, false},
		{"no-names", serverCert(t, root, "p256", func(c *x509.Certificate) {
			c.Subject = pkix.Name{Organization: []string{"ParallelScript tests"}}
			c.DNSNames, c.IPAddresses = nil, nil
		}), nil, false},
		{"ips-and-common-name", serverCert(t, root, "p256", func(c *x509.Certificate) { c.DNSNames = nil }), nil, true},
	}
	for _, server := range servers {
		handler := http.Handler(mux)
		if !server.verifies {
			handler = lab.mustNotReach(server.name, mux)
		}
		lab.name(server.name, "https://localhost:"+lab.serveTLS(t, handler, "", server.cert, server.config, ""))
	}
	lab.name("wrong-host-by-ip", strings.Replace(lab.base("wrong-host"), "localhost", "127.0.0.1", 1))
	lab.name("ip-as-dns-name", "https://127.0.0.1:"+lab.serveTLS(t, lab.mustNotReach("ip-as-dns-name", mux), "", serverCert(t, root, "p256", certFor("127.0.0.1")), nil, ""))
	lab.name("tls10", "https://localhost:"+lab.serveTLS(t, mux, "", good, func(c *tls.Config) { c.MinVersion, c.MaxVersion = tls.VersionTLS10, tls.VersionTLS10 }, "/tls10"))
	lab.name("requires-client-cert", "https://localhost:"+lab.serveTLS(t, mux, "", good, func(c *tls.Config) { c.ClientAuth = tls.RequireAnyClientCert }, "/requires-client-cert"))
	if !resolvesToLoopback(wildcardNames...) {
		lab.absent = append(lab.absent, "wildcard")
	} else {
		wildcard := lab.serveTLS(t, mux, "", serverCert(t, root, "p256", certFor("*.pts.localhost")), nil, "")
		lab.name("wildcard", "https://a.pts.localhost:"+wildcard)
		lab.name("wildcard-two-deep", "https://a.b.pts.localhost:"+wildcard)
		lab.name("wildcard-bare", "https://pts.localhost:"+wildcard)
		lab.name("wildcard-tld", "https://a.localhost:"+strings.TrimPrefix(lab.base("only-wildcard"), "https://localhost:"))
		lab.name("wildcard-partial", "https://ab.pts.localhost:"+lab.serveTLS(t, mux, "", serverCert(t, root, "p256", certFor("a*.pts.localhost")), nil, ""))
	}

	plain := listen(t, "127.0.0.1:0")
	serve(t, plain, mux)
	lab.name("plain", "http://127.0.0.1:"+port(plain))
	plainOther := listen(t, "127.0.0.1:0")
	serve(t, plainOther, mux)
	lab.name("plain-other", "http://127.0.0.1:"+port(plainOther))
	lab.name("plain-as-https", "https://127.0.0.1:"+lab.serveRaw(t, "/plain-as-https", answerAfterHello))
	lab.name("closes", "https://localhost:"+lab.serveRaw(t, "/closes", closeAfterHello))
	lab.name("holds", "https://localhost:"+lab.serveRaw(t, "/holds", holdAfterHello))
	return lab
}

