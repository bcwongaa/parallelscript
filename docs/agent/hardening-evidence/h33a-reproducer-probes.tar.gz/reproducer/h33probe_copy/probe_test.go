package h33probe

// TEMPORARY reproducer probe (H33a); not to be committed. Serves the TLS lab until
// /tmp/h33/reproducer/lab/serving is removed, writing its arguments and CA files there.

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

func TestH33ProbeServe(t *testing.T) {
	if os.Getenv("H33_PROBE") == "" {
		t.Skip("probe only")
	}
	lab := startTLSLab(t)
	dir := "/tmp/h33/reproducer/lab"
	assert.NilError(t, os.MkdirAll(dir, 0o755))
	assert.NilError(t, os.WriteFile(filepath.Join(dir, "args.txt"), []byte(strings.Join(lab.args, "\n")+"\n"), 0o644))
	for _, f := range []string{lab.trusted, lab.untrusted} {
		data, err := os.ReadFile(f)
		assert.NilError(t, err)
		assert.NilError(t, os.WriteFile(filepath.Join(dir, filepath.Base(f)), data, 0o644))
	}
	marker := filepath.Join(dir, "serving")
	assert.NilError(t, os.WriteFile(marker, []byte("remove me to stop\n"), 0o644))
	deadline := time.Now().Add(90 * time.Minute)
	for time.Now().Before(deadline) {
		if _, err := os.Stat(marker); err != nil {
			return
		}
		if _, err := os.Stat(filepath.Join(dir, "reset")); err == nil {
			lab.reset()
			_ = os.Remove(filepath.Join(dir, "reset"))
		}
		time.Sleep(100 * time.Millisecond)
	}
}
