#!/bin/bash
# Usage: pts_run.sh <binary in bin/> <outname> [NAME=value ...]
# Runs a pts-built program against the running lab (env URL= replaces the lab args), trust vars cleared.
set -u
R=/tmp/h33/reproducer
bin=$1
out=$2
shift 2
touch "$R/lab/reset"
sleep 0.3
args=$(cat "$R/lab/args.txt")
if [ -n "${URL:-}" ]; then args=$URL; fi
unset SSL_CERT_FILE SSL_CERT_DIR NODE_EXTRA_CA_CERTS NODE_OPTIONS NODE_USE_SYSTEM_CA URL
env TZ=America/New_York "$@" timeout 90 "$R/bin/$bin" $args >"$R/$out.out" 2>"$R/$out.err"
echo "exit=$?" >"$R/$out.exit"
