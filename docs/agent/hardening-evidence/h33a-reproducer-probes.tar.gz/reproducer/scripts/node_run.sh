#!/bin/bash
# Usage: node_run.sh <program basename in http/> <outname> [NAME=value ...] [-- node flags...]
# Runs a worktree http/ program under Node against the running lab. Env URL= replaces the lab args.
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a125c731616982e9a
R=/tmp/h33/reproducer
export PATH=$HOME/.local/node/bin:$PATH
prog=$1
out=$2
shift 2
envs=()
while [ $# -gt 0 ] && [ "$1" != "--" ]; do
  envs+=("$1")
  shift
done
if [ "${1:-}" = "--" ]; then shift; fi
flags=("$@")
cp "$W/pts/tests/http/$prog.pts" "$R/$prog.mts"
touch "$R/lab/reset"
sleep 0.3
args=$(cat "$R/lab/args.txt")
if [ -n "${URL:-}" ]; then args=$URL; fi
unset SSL_CERT_FILE SSL_CERT_DIR NODE_EXTRA_CA_CERTS NODE_OPTIONS NODE_USE_SYSTEM_CA URL
env TZ=America/New_York "${envs[@]}" timeout 90 node --no-warnings --experimental-transform-types "${flags[@]}" "$R/$prog.mts" $args >"$R/$out.out" 2>"$R/$out.err"
echo "exit=$?" >"$R/$out.exit"
