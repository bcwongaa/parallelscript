"""Round-3 edits to https_test.go: an expired intermediate and an expired self-signed leaf (reproducer, H33a)."""
import sys

path = sys.argv[1]
s = open(path).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old)
    s = s.replace(old, new)


rep('''// newAuthority makes a CA called name with a key of kind, signed by issuer (an intermediate CA) or by itself (a root).
func newAuthority(t *testing.T, name string, kind string, issuer *authority) *authority {''',
    '''// newAuthority makes a CA called name with a key of kind, signed by issuer (an intermediate
// CA) or by itself (a root), valid from an hour ago for a day unless edit changes that.
func newAuthority(t *testing.T, name string, kind string, issuer *authority, edit func(*x509.Certificate)) *authority {''')
rep('''		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
	}
	return &authority{certify(t, template, key, issuer), key}''', '''		KeyUsage:              x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
	}
	if edit != nil {
		edit(template)
	}
	return &authority{certify(t, template, key, issuer), key}''')
rep('''	root := newAuthority(t, "PTS Test Root CA", "p256", nil)
	rsaRoot := newAuthority(t, "PTS Test RSA Root CA", "rsa", nil)
	p384Root := newAuthority(t, "PTS Test P-384 Root CA", "p384", nil)
	other := newAuthority(t, "PTS Untrusted Root CA", "p256", nil)
	intermediate := newAuthority(t, "PTS Test Intermediate CA", "p256", root)
	otherIntermediate := newAuthority(t, "PTS Untrusted Intermediate CA", "p256", other)
''', '''	now := time.Now()
	expired := func(c *x509.Certificate) { c.NotBefore, c.NotAfter = now.Add(-48*time.Hour), now.Add(-24*time.Hour) }
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	rsaRoot := newAuthority(t, "PTS Test RSA Root CA", "rsa", nil, nil)
	p384Root := newAuthority(t, "PTS Test P-384 Root CA", "p384", nil, nil)
	other := newAuthority(t, "PTS Untrusted Root CA", "p256", nil, nil)
	intermediate := newAuthority(t, "PTS Test Intermediate CA", "p256", root, nil)
	otherIntermediate := newAuthority(t, "PTS Untrusted Intermediate CA", "p256", other, nil)
	expiredIntermediate := newAuthority(t, "PTS Expired Intermediate CA", "p256", root, expired)
''')
rep('''
	now := time.Now()
	certFor := func''', '''
	certFor := func''')
rep('''	otherHost := certFor("other.example")
	expired := func(c *x509.Certificate) { c.NotBefore, c.NotAfter = now.Add(-48*time.Hour), now.Add(-24*time.Hour) }
''', '''	otherHost := certFor("other.example")
''')
rep('''		{"expired-untrusted", serverCert(t, other, "p256", expired), nil, false},''', '''		{"expired-untrusted", serverCert(t, other, "p256", expired), nil, false},
		{"self-signed-expired", serverCert(t, nil, "p256", expired), nil, false},
		{"intermediate-expired", serverCert(t, expiredIntermediate, "p256", nil, expiredIntermediate.cert), nil, false},''')
rep('''	extra := writePEM(t, dir, "extra.pem", newAuthority(t, "PTS Extra CA", "p256", nil).cert)''',
    '''	extra := writePEM(t, dir, "extra.pem", newAuthority(t, "PTS Extra CA", "p256", nil, nil).cert)''')
rep('''//     (127.0.0.1 as a DNS name), only-wildcard (*.localhost, at localhost), expired-untrusted, common-name-wrong,''',
    '''//     (127.0.0.1 as a DNS name), only-wildcard (*.localhost, at localhost), expired-untrusted, self-signed-expired,
//     intermediate-expired, common-name-wrong,''')
open(path, 'w').write(s)
print("ok")
