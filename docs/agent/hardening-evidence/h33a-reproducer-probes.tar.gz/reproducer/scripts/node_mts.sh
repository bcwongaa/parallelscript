#!/bin/bash
# Usage: node_mts.sh <file.mts> [NAME=value ...]: runs a probe .mts under Node with the lab's args.
R=/tmp/h33/reproducer
file=$1
shift
args=$(cat "$R/lab/args.txt")
unset SSL_CERT_FILE SSL_CERT_DIR NODE_EXTRA_CA_CERTS NODE_OPTIONS NODE_USE_SYSTEM_CA
env "$@" timeout 90 "$HOME/.local/node/bin/node" --no-warnings --experimental-transform-types "$file" $args
echo "exit=$?"
