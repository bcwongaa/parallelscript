"""Copies the lab half of the worktree's https_test.go into the throwaway h33probe package."""
import re

W = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a125c731616982e9a"
src = open(W + "/pts/tests/https_test.go").read()
lab = src[: src.index("// ---------------------------------------------------------------- running the programs")]
lab = lab.replace("package tests", "package h33probe", 1)
body = lab[lab.index(")\n") :]
for m in ["bytes", "context", "slices", "os/exec"]:
    name = m.split("/")[-1]
    if not re.search(r"\b" + re.escape(name) + r"\.[A-Z]", body):
        lab = lab.replace('\t"%s"\n' % m, "")
open(W + "/pts/tests/h33probe/lab_test.go", "w").write(lab)
print("copied")
