"""Replaces fetchTLSOutput in the worktree's https_test.go with a recorded Node output file."""
import sys

W = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a125c731616982e9a"
path = W + "/pts/tests/https_test.go"
out = open(sys.argv[1]).read()
assert "`" not in out
s = open(path).read()
start = s.index("const fetchTLSOutput = `") + len("const fetchTLSOutput = `")
end = s.index("`\n\n// expectedTLSOutput")
s = s[:start] + out + s[end:]
open(path, "w").write(s)
print("recorded", out.count("\n"), "lines")
