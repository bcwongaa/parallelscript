"""Applies the second round of lab additions to the staged https_test.go (reproducer, H33a)."""
import sys

path = sys.argv[1]
s = open(path).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old)
    s = s.replace(old, new)


rep('''	ipv6      bool   // whether the [::1] server listens
	wildcards bool   // whether names under pts.localhost resolve, for the wildcard certificates
''', '''	absent    []string // the labels of fetch_tls.pts's lines for servers this host can't have
''')
rep('''// statePaths are the paths the plain server answers with the state of another server.
var statePaths = []string{"/holds", "/closes", "/plain-as-https", "/tls10", "/requires-client-cert", "/stalled"}
''', '''// statePaths are the paths the plain server answers with the state of another server, or
// of those whose certificates don't verify (/unverified: the names of those a request reached).
var statePaths = []string{"/holds", "/closes", "/plain-as-https", "/tls10", "/requires-client-cert", "/stalled", "/unverified"}
''')
rep('''// reset forgets the states, before a program runs.''', '''// mustNotReach is mux for the server called name, whose certificate no client may accept:
// a request that reaches it, which the client sent after a handshake it should have
// failed, adds name to the state of /unverified.
func (lab *tlsLab) mustNotReach(name string, mux http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		lab.mu.Lock()
		if reached := lab.states["/unverified"]; reached != "" {
			lab.states["/unverified"] = reached + ", " + name
		} else {
			lab.states["/unverified"] = name
		}
		lab.mu.Unlock()
		mux.ServeHTTP(w, r)
	})
}

// reset forgets the states, before a program runs.''')
rep('''// serveTLS serves mux over TLS with cert on a new listener at address (127.0.0.1 if
// empty), edit changing the TLS configuration, and returns the listener's port. It
// remembers what each client offered in its hello, for /hello to answer, and, if
// statePath isn't empty, that a hello came, as statePath's state.
func (lab *tlsLab) serveTLS(t *testing.T, mux http.Handler, address string, cert tls.Certificate, edit func(*tls.Config), statePath string) string {''',
    '''// serveTLS serves handler over TLS with cert on a new listener at address (127.0.0.1 if
// empty), edit changing the TLS configuration, and returns the listener's port. It
// remembers what each client offered in its hello, for /hello to answer, and, if
// statePath isn't empty, that a hello came, as statePath's state.
func (lab *tlsLab) serveTLS(t *testing.T, handler http.Handler, address string, cert tls.Certificate, edit func(*tls.Config), statePath string) string {''')
rep('''	serve(t, tls.NewListener(listener, config), mux)''', '''	serve(t, tls.NewListener(listener, config), handler)''')
rep('''	untilClose := func(abruptly bool) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			conn, _, err := http.NewResponseController(w).Hijack()
			if err != nil {
				panic(err)
			}
			_, _ = conn.Write([]byte("HTTP/1.1 200 OK\\r\\ncontent-type: text/plain\\r\\n\\r\\nread until the end"))
			if secure, ok := conn.(*tls.Conn); ok && abruptly {
				_ = secure.NetConn().Close() // the TCP connection ends without TLS's close_notify
				return
			}
			_ = conn.Close()
		}
	}
	mux.HandleFunc("/close", untilClose(false))
	mux.HandleFunc("/close-abruptly", untilClose(true))
''', '''	// hijacked writes raw itself, then ends the connection as end says: "close_notify"
	// (TLS's alert, then the TCP connection's end), "abruptly" (the TCP connection's end
	// alone) or "reset" (a TCP reset).
	hijacked := func(raw string, end string) http.HandlerFunc {
		return func(w http.ResponseWriter, r *http.Request) {
			conn, _, err := http.NewResponseController(w).Hijack()
			if err != nil {
				panic(err)
			}
			_, _ = io.WriteString(conn, raw)
			if secure, ok := conn.(*tls.Conn); ok && end != "close_notify" {
				conn = secure.NetConn()
			}
			if end == "reset" {
				_ = conn.(*net.TCPConn).SetLinger(0)
			}
			_ = conn.Close()
		}
	}
	const untilTheEnd = "HTTP/1.1 200 OK\\r\\ncontent-type: text/plain\\r\\n\\r\\nread until the end"
	const truncated = "HTTP/1.1 200 OK\\r\\ncontent-length: 100\\r\\n\\r\\nonly this"
	mux.HandleFunc("/close", hijacked(untilTheEnd, "close_notify"))
	mux.HandleFunc("/close-abruptly", hijacked(untilTheEnd, "abruptly"))
	mux.HandleFunc("/truncated", hijacked(truncated, "close_notify"))
	mux.HandleFunc("/truncated-abruptly", hijacked(truncated, "abruptly"))
	mux.HandleFunc("/reset", hijacked(truncated, "reset"))
''')
rep('''//     (127.0.0.1 as a DNS name) and only-wildcard (*.localhost, at localhost): certificates to verify or not;''',
    '''//     (127.0.0.1 as a DNS name), only-wildcard (*.localhost, at localhost), expired-untrusted, common-name-wrong,
//     no-names (neither a subjectAltName nor a common name), ips-and-common-name (no DNS name in the
//     subjectAltName) and other-ip (127.0.0.2, if it listens): certificates to verify or not, and those that
//     shouldn't verify record a request that reaches them;''')
rep('''		lab.ipv6 = true
		lab.name("[::1]", "https://[::1]:"+lab.serveTLS(t, mux, "[::1]:0", good, nil, ""))
	}''', '''		lab.name("[::1]", "https://[::1]:"+lab.serveTLS(t, mux, "[::1]:0", good, nil, ""))
	} else {
		lab.absent = append(lab.absent, "by IPv6 address ")
	}
	if listener, err := net.Listen("tcp", "127.0.0.2:0"); err == nil { // Linux's loopback is 127/8, macOS's 127.0.0.1 alone
		_ = listener.Close()
		lab.name("other-ip", "https://127.0.0.2:"+lab.serveTLS(t, lab.mustNotReach("other-ip", mux), "127.0.0.2:0", good, nil, ""))
	} else {
		lab.absent = append(lab.absent, "by another IP address ")
	}''')
rep('''	servers := []struct {
		name   string
		cert   tls.Certificate
		config func(*tls.Config)
	}{''', '''	servers := []struct {
		name     string
		cert     tls.Certificate
		config   func(*tls.Config)
		verifies bool
	}{''')
# Mark each server whether its certificate verifies.
verifying = ["tls12", "tls13", "rsa", "rsa-tls12", "p384", "hello-retry", "asks-for-client-cert", "intermediate-sent", "common-name-only"]
start = s.index('	servers := []struct {')
end = s.index('	for _, server := range servers {')
table = s[start:end]
lines = table.split('\n')
out = []
for line in lines:
    stripped = line.strip()
    if stripped.startswith('{"') and stripped.endswith('},'):
        name = stripped[2:stripped.index('"', 2)]
        line = line[: line.rindex('},')] + (', true},' if name in verifying else ', false},')
    out.append(line)
table = '\n'.join(out)
# hello-retry spans several lines; mark its closing line.
table = table.replace('''			c.CurvePreferences = []tls.CurveID{tls.CurveP384} // a key share clients don't send first
		}},''', '''			c.CurvePreferences = []tls.CurveID{tls.CurveP384} // a key share clients don't send first
		}, true},''')
table = table.replace('''		{"only-wildcard", serverCert(t, root, "p256", certFor("*.localhost")), nil, false},''', '''		{"only-wildcard", serverCert(t, root, "p256", certFor("*.localhost")), nil, false},
		{"expired-untrusted", serverCert(t, other, "p256", expired), nil, false},
		{"common-name-wrong", serverCert(t, root, "p256", func(c *x509.Certificate) {
			c.Subject.CommonName = "other.example"
			c.DNSNames, c.IPAddresses = nil, nil
		}), nil, false},
		{"no-names", serverCert(t, root, "p256", func(c *x509.Certificate) {
			c.Subject = pkix.Name{Organization: []string{"ParallelScript tests"}}
			c.DNSNames, c.IPAddresses = nil, nil
		}), nil, false},
		{"ips-and-common-name", serverCert(t, root, "p256", func(c *x509.Certificate) { c.DNSNames = nil }), nil, true},''')
s = s[:start] + table + s[end:]
rep('''	for _, server := range servers {
		lab.name(server.name, "https://localhost:"+lab.serveTLS(t, mux, "", server.cert, server.config, ""))
	}''', '''	for _, server := range servers {
		handler := http.Handler(mux)
		if !server.verifies {
			handler = lab.mustNotReach(server.name, mux)
		}
		lab.name(server.name, "https://localhost:"+lab.serveTLS(t, handler, "", server.cert, server.config, ""))
	}''')
rep('''	lab.name("ip-as-dns-name", "https://127.0.0.1:"+lab.serveTLS(t, mux, "", serverCert(t, root, "p256", certFor("127.0.0.1")), nil, ""))''',
    '''	lab.name("ip-as-dns-name", "https://127.0.0.1:"+lab.serveTLS(t, lab.mustNotReach("ip-as-dns-name", mux), "", serverCert(t, root, "p256", certFor("127.0.0.1")), nil, ""))''')
rep('''	if resolvesToLoopback(wildcardNames...) {
		lab.wildcards = true
''', '''	if !resolvesToLoopback(wildcardNames...) {
		lab.absent = append(lab.absent, "wildcard")
	} else {
''')
rep('''		ctx, cancel := context.WithTimeout(t.Context(), 2*programTimeout)''', '''		ctx, cancel := context.WithTimeout(t.Context(), tlsProgramTimeout)''', 0) if False else None
rep('''	ctx, cancel := context.WithTimeout(t.Context(), 2*programTimeout)''', '''	ctx, cancel := context.WithTimeout(t.Context(), tlsProgramTimeout)''')
rep('''// trustVars are the environment variables that choose which certificates a client trusts.''',
    '''// tlsProgramTimeout is how long a TLS program may run: longer than other programs, for
// the thousand handshakes of fetch_tls_parallel.pts built with sanitizers on a busy host.
const tlsProgramTimeout = 3 * programTimeout

// trustVars are the environment variables that choose which certificates a client trusts.''')
rep('''// expectedTLSOutput is fetchTLSOutput without the lines of servers this lab lacks: the
// one by IPv6 address where [::1] doesn't listen, the wildcard ones where the names don't resolve.
func (lab *tlsLab) expectedTLSOutput() string {
	var kept []string
	for _, line := range strings.SplitAfter(fetchTLSOutput, "\\n") {
		if (lab.ipv6 || !strings.HasPrefix(line, "by IPv6 address ")) && (lab.wildcards || !strings.HasPrefix(line, "wildcard")) {
			kept = append(kept, line)
		}
	}
	return strings.Join(kept, "")
}''', '''// expectedTLSOutput is fetchTLSOutput without the lines of servers this lab lacks: by
// IPv6 address where [::1] doesn't listen, by another IP address where 127.0.0.2 doesn't,
// the wildcard ones where their names don't resolve.
func (lab *tlsLab) expectedTLSOutput() string {
	var kept []string
	for _, line := range strings.SplitAfter(fetchTLSOutput, "\\n") {
		if !slices.ContainsFunc(lab.absent, func(label string) bool { return strings.HasPrefix(line, label) }) {
			kept = append(kept, line)
		}
	}
	return strings.Join(kept, "")
}''')
rep('''requests: 300
''', '''requests: 1000
''')
rep('''// tasks, to a server whose certificate verifies and to one whose doesn't, each checked;
// fetches aborted at random stages of their handshakes; and hundreds of them, after which
// the process has the files it had and hasn't grown much.''', '''// tasks, to a server whose certificate verifies and to one whose doesn't, each checked;
// an abort during the handshake, which closes the connection; fetches aborted at random
// stages of their handshakes; and a thousand more, after which the process has the files it
// had and hasn't grown by more than 40 kB a connection.''')
open(path, 'w').write(s)
print("ok")
