// Prints what Go's resolvers make of the wildcard test names.
package main

import (
	"context"
	"fmt"
	"net"
)

func main() {
	for _, preferGo := range []bool{false, true} {
		r := &net.Resolver{PreferGo: preferGo}
		for _, host := range []string{"a.pts.localhost", "a.b.pts.localhost", "pts.localhost", "a.localhost", "ab.pts.localhost"} {
			addrs, err := r.LookupHost(context.Background(), host)
			fmt.Println("preferGo", preferGo, host, addrs, err)
		}
	}
}
