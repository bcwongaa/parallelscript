"""Review fixes to https_test.go: shared builds, lab resets, the public site's skip, doc wording (reproducer, H33a)."""
import sys

path = sys.argv[1]
s = open(path).read()


def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (s.count(old), old)
    s = s.replace(old, new)


rep('''	"gotest.tools/v3/assert"
)''', '''	"github.com/microsoft/typescript-go/pts/driver"
	"gotest.tools/v3/assert"
)''')
rep('''// nodeProgram writes http/<name>.pts''', '''// buildShared builds http/<name>.pts once for every test that runs it (as runPts builds
// run tests), and returns the executable's path.
func buildShared(t *testing.T, name string) string {
	t.Helper()
	source, err := filepath.Abs(filepath.Join("http", name+".pts"))
	assert.NilError(t, err)
	entry, _ := builds.LoadOrStore(source, &programBuild{})
	build := entry.(*programBuild)
	build.once.Do(func() {
		heavyJobs <- struct{}{}
		defer func() { <-heavyJobs }()
		build.exe = filepath.Join(buildDir, "http_"+name+".pts")
		build.err = driver.Build(context.Background(), source, build.exe)
	})
	assert.NilError(t, build.err)
	return build.exe
}

// nodeProgram writes http/<name>.pts''')
for name in ["fetch_tls", "fetch_tls_parallel"]:
    rep('''	exe := buildServer(t, "%s")''' % name, '''	exe := buildShared(t, "%s")''' % name)
rep('''	exe := buildServer(t, "fetch_tls_one")''', '''	exe := buildShared(t, "fetch_tls_one")''', 2)
rep('''// for each certificate that doesn't verify, failures of the protocol, and aborts during
// the handshake and the body, which close the connection.''', '''// for each certificate that doesn't verify (and that no request reaches its server),
// failures of the protocol, and aborts during the handshake and the body (whose
// connection closes).''')
rep('''	for _, threads := range []string{"1", "4"} {
		got := runTLSProgram(t, []string{"NODE_EXTRA_CA_CERTS=" + lab.trusted, "PTS_THREADS=" + threads}, exe, lab.args...)''', '''	for _, threads := range []string{"1", "4"} {
		lab.reset()
		got := runTLSProgram(t, []string{"NODE_EXTRA_CA_CERTS=" + lab.trusted, "PTS_THREADS=" + threads}, exe, lab.args...)''')
rep('''// (the system's directories are still read), and requires Node's status. It skips when
// the site can't be reached.''', '''// (the system's directories are still read), and requires a 200, as Node gets. It skips
// when the site can't be reached, or Node can't fetch it (a proxy that intercepts TLS).''')
rep('''		got := runTLSProgram(t, nil, node, append(nodeProgram(t, "fetch_tls_one"), "https://"+publicSite+"/")...)
		want = got.stdout
		assert.Equal(t, want, "200\\n", "Node; stderr:\\n%s", got.stderr)
	}''', '''		got := runTLSProgram(t, nil, node, append(nodeProgram(t, "fetch_tls_one"), "https://"+publicSite+"/")...)
		if got.stdout != want {
			t.Skipf("Node can't fetch %s either: %s%s", publicSite, got.stdout, got.stderr)
		}
	}''')
open(path, 'w').write(s)
print("ok")
