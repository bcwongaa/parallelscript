#!/bin/bash
# Node --use-system-ca: colon-separated SSL_CERT_DIR, missing SSL_CERT_FILE, untrusted file plus empty dir.
R=/tmp/h33/reproducer
S=$R/scripts
U=$(grep '^localhost=' $R/lab/args.txt | cut -d= -f2)/hello
run() {
  name=$1
  shift
  URL=$U bash $S/node_run.sh fetch_tls_one "trust_$name" "$@"
  printf '%-40s %s | %s | stderr: %s\n' "$name" "$(cat $R/trust_$name.exit)" "$(cat $R/trust_$name.out)" "$(head -c 300 $R/trust_$name.err | tr '\n' ' ')"
}
run sys_colon SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir:$R/trustdir -- --use-system-ca
run sys_untrusted_empty SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir -- --use-system-ca
run sys_missing_file SSL_CERT_FILE=$R/missing.pem SSL_CERT_DIR=$R/emptydir -- --use-system-ca
run sys_missing_dir_trusted_file SSL_CERT_FILE=$R/lab/trusted.pem SSL_CERT_DIR=$R/missingdir -- --use-system-ca
run sys_extra_plus SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir NODE_EXTRA_CA_CERTS=$R/lab/trusted.pem -- --use-system-ca
