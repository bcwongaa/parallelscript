#!/bin/bash
# Runs fetch_tls under Node N times against the lab and compares each output with the reference.
# Usage: node_repeat.sh <reference outname> <count>
R=/tmp/h33/reproducer
ref=$1
count=$2
for n in $(seq 1 "$count"); do
  bash $R/scripts/node_run.sh fetch_tls "repeat$n" NODE_EXTRA_CA_CERTS=$R/lab/trusted.pem
  if cmp -s "$R/$ref.out" "$R/repeat$n.out"; then
    echo "run $n: $(cat $R/repeat$n.exit) same"
  else
    echo "run $n: $(cat $R/repeat$n.exit) DIFFERENT"
    diff "$R/$ref.out" "$R/repeat$n.out"
  fi
done
