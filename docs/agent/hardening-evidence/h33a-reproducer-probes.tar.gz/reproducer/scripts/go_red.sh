#!/bin/bash
# Runs the new TLS tests against the current compiler (RED), on 2 CPUs (heavyJobs = NumCPU = 2).
# Usage: go_red.sh <outname> [-run regexp]
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a125c731616982e9a
R=/tmp/h33/reproducer
out=$1
pattern=${2:-TestFetchHTTPS}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$W" || exit 1
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 taskset -c 0,1 go test -count=1 -p 1 -timeout 40m -v -run "$pattern" ./pts/tests/ >"$R/$out.log" 2>&1
echo "exit=$?" >>"$R/$out.log"
