#!/bin/bash
# Node's trust-store behaviour against the lab's localhost server (whose CA is lab/trusted.pem).
R=/tmp/h33/reproducer
S=$R/scripts
U=$(grep '^localhost=' $R/lab/args.txt | cut -d= -f2)/hello
mkdir -p $R/trustdir $R/emptydir
cp $R/lab/trusted.pem $R/trustdir/test-cas.pem
run() {
  name=$1
  shift
  URL=$U bash $S/node_run.sh fetch_tls_one "trust_$name" "$@"
  printf '%-40s %s | %s | stderr: %s\n' "$name" "$(cat $R/trust_$name.exit)" "$(cat $R/trust_$name.out)" "$(head -c 300 $R/trust_$name.err | tr '\n' ' ')"
}
run default
run extra NODE_EXTRA_CA_CERTS=$R/lab/trusted.pem
run extra_untrusted NODE_EXTRA_CA_CERTS=$R/lab/untrusted.pem
run extra_missing NODE_EXTRA_CA_CERTS=$R/missing.pem
run certfile SSL_CERT_FILE=$R/lab/trusted.pem
run certdir SSL_CERT_DIR=$R/trustdir
run certfile_openssl SSL_CERT_FILE=$R/lab/trusted.pem -- --use-openssl-ca
run certdir_openssl SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/trustdir -- --use-openssl-ca
run certfile_system SSL_CERT_FILE=$R/lab/trusted.pem -- --use-system-ca
run certdir_system SSL_CERT_DIR=$R/trustdir -- --use-system-ca
run env_system NODE_USE_SYSTEM_CA=1 SSL_CERT_FILE=$R/lab/trusted.pem
