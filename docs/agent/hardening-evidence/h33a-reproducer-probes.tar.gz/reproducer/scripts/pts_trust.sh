#!/bin/bash
# TestFetchHTTPSTrustStore's table, by hand, under pts (fetch_tls_one) against the lab's localhost server.
R=/tmp/h33/reproducer
S=$R/scripts
U=$(grep '^localhost=' $R/lab/args.txt | cut -d= -f2)/hello
mkdir -p $R/trustdir $R/emptydir
cp $R/lab/trusted.pem $R/trustdir/test-cas.pem
run() {
  name=$1
  shift
  URL=$U bash $S/pts_run.sh fetch_tls_one "ptstrust_$name" "$@"
  printf '%-32s %s | %s | stderr: %s\n' "$name" "$(cat $R/ptstrust_$name.exit)" "$(cat $R/ptstrust_$name.out)" "$(head -c 200 $R/ptstrust_$name.err | tr '\n' ' ')"
}
run system
run certfile_trusted SSL_CERT_FILE=$R/lab/trusted.pem SSL_CERT_DIR=$R/emptydir
run certfile_untrusted SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir
run certfile_missing SSL_CERT_FILE=$R/missing.pem SSL_CERT_DIR=$R/emptydir
run certdir_trusted SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/trustdir
run certdir_second SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir:$R/trustdir
run extra_adds SSL_CERT_FILE=$R/lab/untrusted.pem SSL_CERT_DIR=$R/emptydir NODE_EXTRA_CA_CERTS=$R/lab/trusted.pem
run extra_untrusted NODE_EXTRA_CA_CERTS=$R/lab/untrusted.pem
run extra_missing NODE_EXTRA_CA_CERTS=$R/missing.pem
