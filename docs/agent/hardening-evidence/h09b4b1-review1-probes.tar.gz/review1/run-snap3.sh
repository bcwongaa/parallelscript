#!/bin/bash
# usage: run-main.sh probe.pts...  -> out/<name>/snap3.txt, run with the snap3 CLI
# (/tmp/h09b4b/s2/snap3/pts-bin/pts, PTS_HOME there).
export TZ=America/New_York
R=/tmp/h09b4b/s2/review1
M=/tmp/h09b4b/s2/snap3
for f0 in "$@"; do
  f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n
  mkdir -p "$d"
  (cd "$d" && PTS_HOME=$M PTS_CACHE_DIR=$R/.cache-snap3 timeout 300 $M/pts-bin/pts run "$f" > "$d/snap3.txt" 2>&1; echo "exit=$?" >> "$d/snap3.txt")
  sha256sum $M/pts-bin/pts | cut -c1-16 > "$d/snap3.cli-sha"
  s=$(cmp -s "$d/node.txt" "$d/snap3.txt" && echo SAME || echo DIFF)
  echo "== $n: snap3-vs-node=$s"
  if [ "$s" = DIFF ]; then diff "$d/node.txt" "$d/snap3.txt" | head -12; fi
done
