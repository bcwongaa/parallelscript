#!/bin/bash
# usage: run.sh probe.pts [probe.pts...]  -> out/<name>.{node,base,snap}
# Runs Node (.mts copy), the base CLI and the snapshot CLI; prints a compact diff summary.
export TZ=America/New_York
R=/tmp/h09b4b/s2/review1
for f0 in "$@"; do
  f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n
  mkdir -p "$d"
  cp "$f" "$d/$n.mts"
  (cd "$d" && timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" > "$d/node.txt" 2>&1; echo "exit=$?" >> "$d/node.txt")
  (cd "$d" && PTS_HOME=/tmp/h09b4b/base PTS_CACHE_DIR=$R/.cache-base timeout 300 /tmp/h09b4b/base/pts-bin/pts run "$f" > "$d/base.txt" 2>&1; echo "exit=$?" >> "$d/base.txt")
  (cd "$d" && PTS_HOME=/tmp/h09b4b/s2/snap1 PTS_CACHE_DIR=$R/.cache-snap timeout 300 /tmp/h09b4b/s2/snap1/pts-bin/pts run "$f" > "$d/snap.txt" 2>&1; echo "exit=$?" >> "$d/snap.txt")
  s1=$(cmp -s "$d/node.txt" "$d/snap.txt" && echo SAME || echo DIFF)
  s2=$(cmp -s "$d/node.txt" "$d/base.txt" && echo SAME || echo DIFF)
  echo "== $n: snap-vs-node=$s1 base-vs-node=$s2"
  if [ "$s1" = DIFF ]; then diff "$d/node.txt" "$d/snap.txt" | head -20; fi
done
