#!/bin/bash
# usage: run-main.sh probe.pts...  -> out/<name>/main.txt, run with the main tree's CLI
# (/home/bryan/projects/parallelscript/pts-bin/pts, PTS_HOME there; sha in main-cli.sha at run time).
export TZ=America/New_York
R=/tmp/h09b4b/s2/review1
M=/home/bryan/projects/parallelscript
for f0 in "$@"; do
  f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n
  mkdir -p "$d"
  (cd "$d" && PTS_HOME=$M PTS_CACHE_DIR=$R/.cache-main timeout 300 $M/pts-bin/pts run "$f" > "$d/main.txt" 2>&1; echo "exit=$?" >> "$d/main.txt")
  sha256sum $M/pts-bin/pts | cut -c1-16 > "$d/main.cli-sha"
  s=$(cmp -s "$d/node.txt" "$d/main.txt" && echo SAME || echo DIFF)
  echo "== $n: main-vs-node=$s"
  if [ "$s" = DIFF ]; then diff "$d/node.txt" "$d/main.txt" | head -12; fi
done
