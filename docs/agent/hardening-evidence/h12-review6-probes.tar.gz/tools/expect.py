#!/usr/bin/env python3
# usage: expect.py BUILD[,BUILD...] test.pts... — runs each test with each build (CLI dir /tmp/h12/<b> or a path to a dir with pts-bin/pts; PTS_HOME from env RT or that dir) and Node, compares with its `// expect:` block
import sys, subprocess, tempfile, shutil, os, re, signal
def sh(cmd, cwd, timeout, env=None):
    q = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, start_new_session=True)
    try:
        o, e = q.communicate(timeout=timeout); return q.returncode, o, e
    except subprocess.TimeoutExpired:
        os.killpg(q.pid, signal.SIGKILL); q.communicate(); return 124, '', 'TIMEOUT'
builds = sys.argv[1].split(",")
for path in sys.argv[2:]:
    src = open(path).read()
    m = re.search(r"^// expect:\n((?://.*\n?)*)", src, re.M)
    want = "".join(l[3:] + "\n" if l.startswith("// ") else "\n" for l in m.group(1).rstrip("\n").split("\n")) if m else None
    d = tempfile.mkdtemp(dir="/tmp/h12/review6/work")
    shutil.copy(path, os.path.join(d, "p.pts")); shutil.copy(path, os.path.join(d, "p.mts"))
    res = []
    rc, o, e = sh(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], d, 60)
    res.append(("node", rc, o == want))
    for b in builds:
        cli = (b if b.startswith("/") else "/tmp/h12/" + b) + "/pts-bin/pts"
        home = os.environ.get("RT") if b.startswith("/") else "/tmp/h12/" + b
        rc, o, e = sh([cli, "run", "p.pts"], d, int(os.environ.get("T", "120")), dict(os.environ, PTS_HOME=home))
        res.append((os.path.basename(b), rc, o == want, (o + e)[-300:].replace(d, "<d>")))
    shutil.rmtree(d, ignore_errors=True)
    print(os.path.basename(path), " ".join(f"{x[0]}:{'PASS' if x[2] else 'FAIL'}(rc{x[1]})" for x in res))
    for x in res[1:]:
        if not x[2] and os.environ.get("V"): print("   ", x[0], repr(x[3]))
