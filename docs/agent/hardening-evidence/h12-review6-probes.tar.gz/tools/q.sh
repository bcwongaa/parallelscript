#!/bin/bash
# usage: q.sh [builds] probe.pts... — node and the given builds (default "snap4"), sequentially
B=${B:-snap4}
for f in "$@"; do
  d=$(mktemp -d /tmp/h12/review6/work/q.XXXX); cp "$f" $d/p.pts; cp "$f" $d/p.mts
  echo "=== $(basename $f)"
  n=$(cd $d && timeout 30 ~/.local/node/bin/node --experimental-transform-types --no-warnings p.mts 2>&1); echo "--- node rc=$?"; echo "$n" | head -${L:-12}
  for b in $B; do
    o=$(cd $d && PTS_HOME=/tmp/h12/$b timeout ${T:-120} /tmp/h12/$b/pts-bin/pts run p.pts 2>&1); rc=$?
    if [ "$o" == "$n" ] && [ $rc == 0 ]; then echo "--- $b rc=$rc SAME"; else echo "--- $b rc=$rc"; echo "$o" | sed "s#$d#<d>#g" | head -${L:-12}; fi
  done
  rm -rf $d
done
