#!/bin/bash
# Round 6 had no findings; reruns its behaviour and gap probes against Node, base, snap4, snap6 and snapshot 7 (/tmp/h12/fix3).
cd /tmp/h12/review6
B=base,snap4,snap6,fix3 W=4 python3 tools/run.py rerun-probes.json p/f/*.pts p/h/*.pts p/k/*.pts
