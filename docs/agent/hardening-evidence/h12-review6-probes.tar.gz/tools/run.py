#!/usr/bin/env python3
# usage: run.py OUT.json probe.pts|probe-dir ...  — Node (.mts copy) and builds B (env, comma list; default
# "base,snap6,fix3") per probe; W workers (default 4). Each subprocess runs in its own session and its whole
# process group is killed on timeout, so no compiled binary outlives its run. A dir probe holds main.pts.
import sys, json, subprocess, tempfile, shutil, os, concurrent.futures, glob, re, signal
BUILDS = os.environ.get("B", "base,snap6,fix3").split(",")
NODE = "/home/bryan/.local/node/bin/node"
WORK = "/tmp/h12/review6/work"
def sh(cmd, cwd, timeout, env=None):
    p = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, start_new_session=True)
    try:
        out, _ = p.communicate(timeout=timeout)
        return p.returncode, out
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL); p.communicate()
        return 124, "TIMEOUT"
def prep(path, d):
    if os.path.isdir(path):
        shutil.rmtree(d); shutil.copytree(path, d)
        for f in glob.glob(os.path.join(d, "**", "*.pts"), recursive=True):
            src = open(f).read()
            open(f[:-4] + ".mts", "w").write(re.sub(r'from "(\.{1,2}/[^"]+)\.pts"', r'from "\1.mts"', src))
        return "main"
    shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
    return "p"
def run(path):
    d = tempfile.mkdtemp(dir=WORK)
    try:
        main = prep(path, d)
        res = {"node": sh([NODE, "--experimental-transform-types", "--no-warnings", main + ".mts"], d, 30)}
        for b in BUILDS:
            rc, out = sh(["/tmp/h12/%s/pts-bin/pts" % b, "run", main + ".pts"], d, int(os.environ.get("T", "120")), dict(os.environ, PTS_HOME="/tmp/h12/" + b))
            res[b] = (rc, out.replace(d, "<d>"))
        return path, res
    finally:
        shutil.rmtree(d, ignore_errors=True)
out = {}
paths = [p for p in sys.argv[2:] if "g02_plain_recursion" not in p]
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "4"))) as ex:
    for path, res in ex.map(run, paths):
        out[path] = res
        n = res["node"]
        tag = lambda k: "=" if res[k] == n else ("x%d" % res[k][0])
        last = BUILDS[-1]; prev = BUILDS[-2] if len(BUILDS) > 1 else None
        print(f"{os.path.basename(path.rstrip('/')):45s} " + " ".join(f"{k}{tag(k):5s}" for k in BUILDS) + (f"   <-- {last} differs from {prev}" if prev and res[last] != res[prev] else ""), flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1)
