package driver_test

import (
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"gotest.tools/v3/assert"
)

// Replays the parent's additional call-form guards against this worktree's helper.
func TestConstructedReceiverCallFormsPreserveRequiredMethodPairs(t *testing.T) {
	t.Parallel()
	for _, form := range []string{"element", "optional_receiver", "optional_call", "dispatched"} {
		t.Run(form, func(t *testing.T) {
			t.Parallel()
			source := constructedReceiverFlowSource("direct", false)
			switch form {
			case "element":
				source = strings.ReplaceAll(source, "receiver.make(", "receiver[\"make\"](")
			case "optional_receiver":
				source = strings.ReplaceAll(source, "receiver.make(", "receiver?.make(")
			case "optional_call":
				source = strings.ReplaceAll(source, "receiver.make(", "receiver.make?.(")
			case "dispatched":
				source = strings.ReplaceAll(source, "interface Maker { make<T>(value: T): Box<T>; }", "class Maker { make<T>(value: T): Box<T> { return new Box(value); } }")
				source = strings.ReplaceAll(source, "implements Maker", "extends Maker")
			}
			entry := writeSource(t, source)

			c, err := driver.EmitCWith(t.Context(), entry, lower.AllInstances)

			assert.NilError(t, err)
			assertConstructedReceiverPairs(t, c, "direct")
		})
	}
}
