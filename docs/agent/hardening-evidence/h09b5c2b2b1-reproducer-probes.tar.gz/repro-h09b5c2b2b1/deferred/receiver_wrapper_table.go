package driver_test

import (
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"gotest.tools/v3/assert"
)

// Deferred wrapper-inner receiver precision; apply beside receiver_value_sources_test.go
// only in a separately authorized slice, not the direct constructed-receiver b1 slice.
func TestConstructedReceiverWrappersForwardOnlyTheirProvenMethods(t *testing.T) {
	t.Parallel()
	for _, origin := range []string{"direct", "const_aliases", "returned", "merged_returns", "shared_callers"} {
		t.Run(origin, func(t *testing.T) {
			t.Parallel()
			entry := writeSource(t, constructedReceiverFlowSource(origin, true))

			c, err := driver.EmitCWith(t.Context(), entry, lower.AllInstances)

			assert.NilError(t, err)
			assertConstructedReceiverPairs(t, c, origin)
		})
	}
}
