class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
class Left implements Maker {
  make<T>(value: T): Box<T> { return new Box(value, "left"); }
}
class Right implements Maker {
  make<T>(value: T): Box<T> { return new Box(value, "right"); }
}
Left = Right;
function use(receiver: Maker): void {
  const box: Box<number> = receiver.make(3);
  console.log(box.origin, box.value + 1);
}
use(new Left());
