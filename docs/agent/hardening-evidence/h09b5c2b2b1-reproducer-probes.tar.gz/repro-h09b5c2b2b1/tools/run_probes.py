import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time


def invoke(command, cwd, env, output, label, timeout=180):
    start = time.monotonic()
    try:
        process = subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True, timeout=timeout)
        result = {"exit": process.returncode, "timeout": False}
        stdout, stderr = process.stdout, process.stderr
    except subprocess.TimeoutExpired as failure:
        result = {"exit": None, "timeout": True}
        stdout = failure.stdout or b""
        stderr = failure.stderr or b""
        if isinstance(stdout, bytes):
            stdout = stdout.decode(errors="replace")
        if isinstance(stderr, bytes):
            stderr = stderr.decode(errors="replace")
    stdout_path = output / (label + ".stdout")
    stderr_path = output / (label + ".stderr")
    stdout_path.write_text(stdout)
    stderr_path.write_text(stderr)
    result.update(command=command, cwd=str(cwd), seconds=time.monotonic() - start,
                  stdout=str(stdout_path), stderr=str(stderr_path))
    return result


def receiver_source(size, unknown=False):
    lines = ["class Box<T> { constructor(public value: T) {} }",
             "interface Maker { make<T>(value: T): Box<T>; }"]
    for index in range(size):
        lines.append(f"class C{index} {{ tag = {index}; }}")
        lines.append(f"class M{index} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value); }} }}")
        lines.append(f"function use{index}(receiver: Maker): void {{ const box: Box<C{index}> = receiver.make(new C{index}()); console.log(box.value.tag); }}")
    if unknown:
        lines.append("const held: any[] = [" + ", ".join(f"new M{i}()" for i in range(size)) + "];")
    for index in range(size):
        argument = f"held[{index}]" if unknown else f"new M{index}()"
        lines.append(f"use{index}({argument});")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--probe", type=Path, required=True)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--node", type=Path, required=True)
    parser.add_argument("--growth-only", action="store_true")
    parser.add_argument("--native-only", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update(PTS_HOME=str(args.runtime), GOMAXPROCS="1")
    results = {"runtime": str(args.runtime), "specialization": "AllInstances", "commands": [], "growth": [], "native": []}
    if not args.native_only:
        for size, unknown in [(3, False), (12, False), (60, False), (12, True)]:
            label = ("unknown" if unknown else "known") + str(size)
            source = args.output / (label + ".pts")
            source.write_text(receiver_source(size, unknown))
            c_path = args.output / (label + ".c")
            emitted = invoke([str(args.probe), str(source), str(c_path), "-"], args.repo, env, args.output, label + ".emit")
            results["commands"].append(emitted)
            row = {"label": label, "size": size, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "emit_exit": emitted["exit"]}
            if emitted["exit"] == 0:
                code = c_path.read_text()
                pairs = sorted({(int(a), int(b)) for a, b in re.findall(r"pts_fn_M(\d+)_make_C(\d+)\(", code)})
                required = {(i, j) for i in range(size) for j in range(size) if unknown or i == j}
                row.update(pairs=pairs, required=sorted(required), missing=sorted(required - set(pairs)),
                           excluded_present=sorted(set(pairs) - required), pair_count=len(pairs),
                           c_lines=code.count("\n"), c_bytes=c_path.stat().st_size,
                           c_sha256=hashlib.sha256(c_path.read_bytes()).hexdigest())
            twin = source.with_suffix(".mts")
            shutil.copyfile(source, twin)
            binary = source.with_suffix(".bin")
            compiled = invoke([str(args.probe), str(source), str(c_path), str(binary)], args.repo, env, args.output, label + ".compile", timeout=600)
            results["commands"].append(compiled)
            node = invoke([str(args.node), "--no-warnings", "--experimental-transform-types", str(twin)], args.repo, env, args.output, label + ".node", timeout=30)
            results["commands"].append(node)
            row.update(compile_exit=compiled["exit"], node_exit=node["exit"])
            if compiled["exit"] == 0:
                native = invoke([str(binary)], args.repo, env, args.output, label + ".native", timeout=30)
                results["commands"].append(native)
                row.update(native_exit=native["exit"], match=native["exit"] == node["exit"] and Path(native["stdout"]).read_bytes() == Path(node["stdout"]).read_bytes())
                binary.unlink(missing_ok=True)
            results["growth"].append(row)
            print(json.dumps({key: value for key, value in row.items() if key not in {"pairs", "required", "missing", "excluded_present"}}), flush=True)
    if not args.growth_only:
        fixture_dir = args.repo / "pts/tests/run"
        fixtures = sorted(fixture_dir.glob("generic_receiver_flow_*.pts"))
        fixtures += sorted((args.repo / "repro-h09b5c2b2b1/probes").glob("*.pts"))
        for fixture in fixtures:
            label = fixture.stem
            source = args.output / fixture.name
            shutil.copyfile(fixture, source)
            twin = source.with_suffix(".mts")
            shutil.copyfile(source, twin)
            c_path = source.with_suffix(".c")
            binary = source.with_suffix(".bin")
            emitted = invoke([str(args.probe), str(source), str(c_path), str(binary)], args.repo, env, args.output, label + ".compile")
            results["commands"].append(emitted)
            node = invoke([str(args.node), "--no-warnings", "--experimental-transform-types", str(twin)], args.repo, env, args.output, label + ".node", timeout=30)
            results["commands"].append(node)
            row = {"label": label, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "compile_exit": emitted["exit"], "node_exit": node["exit"]}
            if emitted["exit"] == 0:
                native = invoke([str(binary)], args.repo, env, args.output, label + ".native", timeout=30)
                results["commands"].append(native)
                row.update(native_exit=native["exit"], match=native["exit"] == node["exit"] and Path(native["stdout"]).read_bytes() == Path(node["stdout"]).read_bytes())
                binary.unlink(missing_ok=True)
            results["native"].append(row)
            print(json.dumps(row), flush=True)
    (args.output / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    growth_failed = any(row["emit_exit"] != 0 or row.get("missing") or row.get("excluded_present") or not row.get("match", False) for row in results["growth"])
    native_failed = any(row["label"].startswith("generic_receiver_flow_") and not row.get("match", False) for row in results["native"])
    return 1 if growth_failed or native_failed else 0


if __name__ == "__main__":
    sys.exit(main())
