import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cwd", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--env", action="append", default=[])
    parser.add_argument("--timeout", type=int, default=1200)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    args.output.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    overrides = dict(item.split("=", 1) for item in args.env)
    env.update(overrides)
    started = time.monotonic()
    timed_out = False
    with (args.output / "stdout").open("w") as stdout, (args.output / "stderr").open("w") as stderr:
        process = subprocess.Popen(command, cwd=args.cwd, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=args.timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 124
    counts = {"pass": 0, "fail": 0, "skip": 0}
    packages = []
    for line in (args.output / "stdout").read_text().splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if event.get("Test") and event.get("Action") in counts:
            counts[event["Action"]] += 1
        elif not event.get("Test") and event.get("Action") in counts:
            packages.append({"package": event.get("Package"), "action": event.get("Action")})
    receipt = {"command": command, "cwd": str(args.cwd), "environment_overrides": overrides,
               "exit": code, "timeout": timed_out, "seconds": time.monotonic() - started,
               "test_events": counts, "packages": packages,
               "stdout": str(args.output / "stdout"), "stderr": str(args.output / "stderr")}
    (args.output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)
    return code


if __name__ == "__main__":
    sys.exit(main())
