import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve()
    evidence = repo / "repro-h09b5c2b2b1"
    files = []
    for directory in ["results", "probes", "deferred", "tools", "green-snapshot"]:
        files.extend(path for path in (evidence / directory).rglob("*") if path.is_file())
    files.append(evidence / "green-overlay.json")
    files.extend(repo / "pts/driver" / name for name in [
        "receiver_value_sources_test.go", "receiver_literal_candidates_test.go", "receiver_call_forms_test.go",
    ])
    files.extend(sorted((repo / "pts/tests/run").glob("generic_receiver_flow_*.pts")))
    manifest = evidence / "results/archive-input-manifest.json"
    files = sorted(set(files) - {manifest})
    for path in files:
        if path.is_symlink() or path.suffix == ".bin" or path.read_bytes().startswith(b"\x7fELF"):
            raise ValueError("not an allowed regular evidence input: " + str(path))
    hashes = {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    manifest.write_text(json.dumps({"base": "978027b9bae9c053abc9f7c66158d6a8b8fdf085", "sha256": hashes}, indent=2) + "\n")
    files.append(manifest)
    with tarfile.open(args.output, "x:gz") as archive:
        for path in sorted(files):
            archive.add(path, arcname=str(path.relative_to(repo)), recursive=False)
    with tarfile.open(args.output, "r:gz") as archive:
        members = archive.getmembers()
        assert all(member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts for member in members)
    print(json.dumps({"archive": str(args.output), "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      "bytes": args.output.stat().st_size, "members": len(members), "all_members_regular": True}, sort_keys=True))


if __name__ == "__main__":
    main()
