#!/bin/bash
# rerun.sh FILE.pts...: build and run each with the round-3 CLI; compare with round 2's Node and fix outputs
# (REF, default /tmp/h08/rev2/out). Prints NAME: node=OK|DIFF r2=SAME|CHANGED. Outputs in /tmp/h08/rev3/out/rerun.
set -u
cli=/tmp/h08/review3/pts-bin/pts; ref=${REF:-/tmp/h08/rev2/out}; out=/tmp/h08/rev3/out/rerun; mkdir -p "$out/bin"
for f in "$@"; do
  name=$(basename "$f" .pts); dir=$(cd "$(dirname "$f")" && pwd); bin="$out/bin/$name.bin"; rm -f "$bin"
  PTS_HOME=/tmp/h08/review3 timeout 300 "$cli" build "$dir/$name.pts" -o "$bin" > "$out/$name.build.txt" 2>&1; be=$?
  if [ $be -ne 0 ]; then { cat "$out/$name.build.txt"; echo "[build exit $be]"; } > "$out/$name.fix3.txt"
  else (cd "$ref" && timeout 30 "$bin" > "$out/$name.fix3.txt" 2>&1; echo "[exit $?]" >> "$out/$name.fix3.txt"); fi
  rm -f "$bin"
  n=$( [ -f "$ref/$name.node.txt" ] && { cmp -s "$out/$name.fix3.txt" "$ref/$name.node.txt" && echo OK || echo DIFF; } || echo NONE)
  s=$( [ -f "$ref/$name.fix.txt" ] && { cmp -s "$out/$name.fix3.txt" "$ref/$name.fix.txt" && echo SAME || echo CHANGED; } || echo NONE)
  echo "$name: node=$n r2=$s"
done
