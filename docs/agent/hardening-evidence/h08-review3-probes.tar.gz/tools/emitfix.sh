#!/bin/bash
# emitfix.sh: emit C for every pts/tests/{run,errors}/*.pts of the round-3 snapshot with the round-3 compiler,
# for comparison with round 2's emits in /tmp/h08/rev2/emitc/{base,fix}.
mkdir -p /tmp/h08/rev3/emitc/fix3
cd /tmp/h08/review3/pts/tests
for f in run/*.pts errors/*.pts; do
  n=$(echo $f | tr / _)
  PTS_HOME=/tmp/h08/review3 /tmp/h08/review3/pts-bin/pts emit-c $f -o /tmp/h08/rev3/emitc/fix3/$n.c > /tmp/h08/rev3/emitc/fix3/$n.err 2>&1; echo "exit $?" >> /tmp/h08/rev3/emitc/fix3/$n.err
done
touch /tmp/h08/rev3/emitc/DONE
