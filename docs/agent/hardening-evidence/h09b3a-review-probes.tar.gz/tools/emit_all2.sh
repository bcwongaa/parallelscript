#!/bin/bash
# emit_all2.sh base|new : emit C for pts/tests/{corpus,stress,errors,http} and examples entry files.
which=$1
if [ $which = base ]; then CLI=/tmp/h09b3/pts-head; HOME_=/tmp/h09b3/base; else CLI=/tmp/h09b3/snap1r/pts-bin/pts; HOME_=/tmp/h09b3/snap1r; fi
out=/tmp/h09b3/review1/emit2/$which
cd /tmp/h09b3/snap1r
for f in $(find pts/tests/corpus pts/tests/stress pts/tests/errors pts/tests/http examples -name "*.pts" | sort); do
  b=$(echo $f | tr '/' '_')
  (cd $(dirname $f) && PTS_HOME=$HOME_ timeout 120 $CLI emit-c $(basename $f) > $out/$b.c 2> $out/$b.err)
  echo "$b $?" >> $out/exits.txt
done
echo done > $out/DONE
