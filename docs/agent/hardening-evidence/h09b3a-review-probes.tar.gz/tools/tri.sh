#!/bin/bash
# tri.sh FILE.pts... : runs each with the base CLI, the change's CLI and Node (.mts copy).
# NO_NODE=1 skips Node; NO_BASE=1 skips the base.
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
for f in "$@"; do
  b=$(basename "$f" .pts)
  d=$(mktemp -d /tmp/h09b3/review1/scratch/run.XXXX)
  cp "$f" "$d/$b.pts"; cp "$f" "$d/$b.mts"
  echo "=== $f"
  if [ -z "$NO_BASE" ]; then
    echo "--- base"
    (cd "$d" && PTS_HOME=/tmp/h09b3/base timeout 300 /tmp/h09b3/review1/pts-base-dbg run "$b.pts" 2>&1)
    echo "[base exit=$?]"
  fi
  echo "--- new"
  (cd "$d" && PTS_HOME=/tmp/h09b3/snap1r timeout 300 /tmp/h09b3/review1/pts-new-dbg run "$b.pts" 2>&1)
  echo "[new exit=$?]"
  if [ -z "$NO_NODE" ]; then
    echo "--- node"
    (cd "$d" && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types "$b.mts" 2>&1)
    echo "[node exit=$?]"
  fi
  rm -rf "$d"
done
