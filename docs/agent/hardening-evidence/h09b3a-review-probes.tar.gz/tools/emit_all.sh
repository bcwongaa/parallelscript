#!/bin/bash
# emit_all.sh base|new : emit C for every pts/tests/run/*.pts of the snapshot with one CLI.
which=$1
if [ $which = base ]; then CLI=/tmp/h09b3/pts-head; HOME_=/tmp/h09b3/base; else CLI=/tmp/h09b3/snap1r/pts-bin/pts; HOME_=/tmp/h09b3/snap1r; fi
out=/tmp/h09b3/review1/emit/$which
cd /tmp/h09b3/snap1r/pts/tests/run
for f in *.pts; do
  b=${f%.pts}
  PTS_HOME=$HOME_ timeout 120 $CLI emit-c $f > $out/$b.c 2> $out/$b.err
  echo "$b $?" >> $out/exits.txt
done
echo done > $out/DONE
