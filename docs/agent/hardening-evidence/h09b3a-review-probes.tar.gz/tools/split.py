# split.py FILE.pts OUTDIR: writes one file per top-level `attempt(` line (prelude kept),
# named FILE_NN.pts, so each line's verdict is seen alone.
import sys, os, re
src = open(sys.argv[1]).read().split("\n")
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
base = os.path.basename(sys.argv[1])[:-4]
lines = [i for i, l in enumerate(src) if l.startswith("attempt(")]
for n, i in enumerate(lines):
    keep = [l for j, l in enumerate(src) if j == i or j not in lines]
    open(os.path.join(out, f"{base}_{n:02d}.pts"), "w").write("\n".join(keep))
print(len(lines))
