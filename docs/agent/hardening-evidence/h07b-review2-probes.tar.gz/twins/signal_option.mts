// Review round 2: addEventListener's { signal } option against Node, beyond abort_listener_signal_option.pts.
function log(...parts: unknown[]): void {
  console.log(parts.map(String).join(" "));
}
{
  log("-- a. stopImmediatePropagation in an earlier abort listener");
  const c = new AbortController();
  const t = new EventTarget();
  c.signal.addEventListener("abort", (e) => e.stopImmediatePropagation());
  t.addEventListener("ping", () => log("ping listener after the abort (Node: removed anyway)"), { signal: c.signal });
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done a");
}
{
  log("-- b. an untrusted abort event dispatched to the signal, then the listener re-added, then the real abort");
  const c = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("listener");
  t.addEventListener("ping", l, { signal: c.signal });
  c.signal.dispatchEvent(new Event("abort"));
  t.dispatchEvent(new Event("ping"));
  t.addEventListener("ping", l);
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done b");
}
{
  log("-- c. after the abort, the listener re-added without a signal, then an untrusted abort event");
  const c = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("listener");
  t.addEventListener("ping", l, { signal: c.signal });
  c.abort();
  t.addEventListener("ping", l);
  c.signal.dispatchEvent(new Event("abort"));
  t.dispatchEvent(new Event("ping"));
  log("done c");
}
{
  log("-- d. once + signal: fired once, re-added without a signal, then the abort");
  const c = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("listener");
  t.addEventListener("ping", l, { once: true, signal: c.signal });
  t.dispatchEvent(new Event("ping"));
  t.addEventListener("ping", l);
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done d");
}
{
  log("-- e. self-signal once listener");
  const c = new AbortController();
  c.signal.addEventListener("abort", () => log("SHOULD NOT RUN"), { once: true, signal: c.signal });
  c.signal.addEventListener("abort", () => log("plain listener"));
  c.abort();
}
{
  log("-- f. the same listener with two signals: either abort removes it");
  const a = new AbortController();
  const b = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("listener");
  t.addEventListener("ping", l, { signal: a.signal });
  t.addEventListener("ping", l, { signal: b.signal });
  b.abort();
  t.dispatchEvent(new Event("ping"));
  log("done f");
}
{
  log("-- g. a { signal } listener of a follower; the source's listener dispatches first");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  const t = new EventTarget();
  t.addEventListener("ping", () => log("ping"), { signal: d });
  a.signal.addEventListener("abort", () => t.dispatchEvent(new Event("ping")));
  a.abort();
  t.dispatchEvent(new Event("ping"));
  log("done g");
}
{
  log("-- h. the signal's listener order: a program listener added before runs before the removal");
  const c = new AbortController();
  const t = new EventTarget();
  c.signal.addEventListener("abort", () => t.dispatchEvent(new Event("ping")));
  t.addEventListener("ping", () => log("ping during the abort"), { signal: c.signal });
  c.abort();
  t.dispatchEvent(new Event("ping"));
  log("done h");
}
{
  log("-- i. self-signal, stopImmediatePropagation in an earlier listener");
  const c = new AbortController();
  c.signal.addEventListener("abort", (e) => {
    log("first");
    e.stopImmediatePropagation();
  });
  c.signal.addEventListener("abort", () => log("SHOULD NOT RUN"), { signal: c.signal });
  c.abort();
}
