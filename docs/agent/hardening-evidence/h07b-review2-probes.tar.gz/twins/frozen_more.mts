// Review round 2: frozen signals beyond abort_signal_frozen.pts. Every step must end (no hang).
function log(...parts: unknown[]): void {
  console.error(parts.map(String).join(" ")); // stderr: unbuffered, so a hang still shows how far it got
}
function attempt(name: string, f: () => void): void {
  try {
    f();
    log(name, "returned");
  } catch (error) {
    log(name, "threw", (error as Error).name);
  }
}
{
  log("-- a. any() of a frozen source, then the source's abort, twice");
  const c = new AbortController();
  Object.freeze(c.signal);
  const d = AbortSignal.any([c.signal]);
  d.addEventListener("abort", () => log("SHOULD NOT RUN: d"));
  attempt("abort 1", () => c.abort("x"));
  attempt("abort 2", () => c.abort("y"));
  const e = AbortSignal.any([c.signal, d]);
  log("d", d.aborted, d.reason, "| e", e.aborted, "| source reason", c.signal.reason);
}
{
  log("-- b. one frozen follower among 100");
  const c = new AbortController();
  const followers: AbortSignal[] = [];
  let events = 0;
  for (let i = 0; i < 100; i++) {
    const f = AbortSignal.any([c.signal]);
    f.addEventListener("abort", () => events++);
    followers.push(f);
  }
  Object.freeze(followers[50]);
  attempt("abort", () => c.abort("stop"));
  log("aborted", followers.filter((f) => f.aborted).length, "events", events, "| frozen", followers[50].aborted, followers[50].reason);
}
{
  log("-- c. two frozen followers: the first one's error, both left as they were");
  const c = new AbortController();
  const f1 = AbortSignal.any([c.signal]);
  const f2 = AbortSignal.any([c.signal]);
  const f3 = AbortSignal.any([c.signal]);
  Object.freeze(f1);
  Object.freeze(f3);
  attempt("abort", () => c.abort("stop"));
  log("f1", f1.aborted, "f2", f2.aborted, f2.reason, "f3", f3.aborted);
}
{
  log("-- d. frozen with onabort and a once listener set before the freeze");
  const c = new AbortController();
  c.signal.onabort = () => log("SHOULD NOT RUN: onabort");
  c.signal.addEventListener("abort", () => log("SHOULD NOT RUN: once"), { once: true });
  Object.freeze(c.signal);
  attempt("abort", () => c.abort());
  attempt("onabort set after the freeze", () => {
    c.signal.onabort = () => log("SHOULD NOT RUN: onabort 2");
  });
  attempt("dispatch an untrusted abort", () => {
    c.signal.dispatchEvent(new Event("abort"));
  });
  log("aborted", c.signal.aborted);
}
{
  log("-- e. a frozen follower of two sources: each source's abort throws, neither hangs");
  const a = new AbortController();
  const b = new AbortController();
  const d = AbortSignal.any([a.signal, b.signal]);
  Object.freeze(d);
  attempt("a.abort", () => a.abort("a"));
  attempt("b.abort", () => b.abort("b"));
  log("d", d.aborted, "a", a.signal.aborted, "b", b.signal.aborted);
}
{
  log("-- f. a frozen follower's { signal } listeners and throwIfAborted");
  const c = new AbortController();
  const d = AbortSignal.any([c.signal]);
  const t = new EventTarget();
  t.addEventListener("ping", () => log("ping listener still there"), { signal: d });
  Object.freeze(d);
  attempt("abort", () => c.abort("x"));
  attempt("throwIfAborted", () => d.throwIfAborted());
  t.dispatchEvent(new Event("ping"));
}
{
  log("-- g. AbortSignal.abort and timeout unaffected; a frozen EventTarget still works");
  const t = new EventTarget();
  Object.freeze(t);
  t.addEventListener("ping", () => log("frozen target's listener"));
  t.dispatchEvent(new Event("ping"));
  log("AbortSignal.abort", AbortSignal.abort("z").reason);
}
log("end");
