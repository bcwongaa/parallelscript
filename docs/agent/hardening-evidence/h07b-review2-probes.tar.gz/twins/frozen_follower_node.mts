// Node 24: a frozen follower (with a listener, so following) when its source aborts.
const source = new AbortController();
const frozen = AbortSignal.any([source.signal]);
const other = AbortSignal.any([source.signal]);
frozen.addEventListener("abort", () => console.log("frozen follower's listener"));
other.addEventListener("abort", () => console.log("other follower's listener"));
source.signal.addEventListener("abort", () => console.log("source's listener"));
Object.freeze(frozen);
try {
  source.abort("stop");
} catch (error) {
  console.log("abort threw", (error as Error).name, "| source", source.signal.aborted, "| other", other.aborted, "| frozen", frozen.aborted);
}
