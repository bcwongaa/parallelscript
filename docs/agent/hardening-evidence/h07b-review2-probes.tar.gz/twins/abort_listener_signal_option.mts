// addEventListener's `signal` option as Node has it (H07b1): the signal's own listener goes in
// first, so that aborting a signal removes a listener added to that signal itself before it
// could run, and it goes in for a listener that is there already too, whose abort then removes
// it. A signal aborted already adds nothing; a null listener adds nothing to the signal either.
function log(...parts: unknown[]): void {
  console.log(parts.map(String).join(" "));
}

{
  const controller = new AbortController();
  controller.signal.addEventListener("abort", () => log("removed before it ran: no"), { signal: controller.signal });
  controller.signal.addEventListener("abort", () => log("a later listener runs"));
  controller.abort();
}

{
  const owner = new AbortController();
  const target = new EventTarget();
  const listener: EventListener = () => log("the listener ran");
  target.addEventListener("ping", listener);
  target.addEventListener("ping", listener, { signal: owner.signal });
  target.dispatchEvent(new Event("ping"));
  owner.abort();
  target.dispatchEvent(new Event("ping"));
  log("after the abort: the listener added twice is gone");
}

{
  const target = new EventTarget();
  target.addEventListener("ping", () => log("SHOULD NOT RUN: its signal had aborted"), { signal: AbortSignal.abort() });
  const owner = new AbortController();
  let removals = 0;
  owner.signal.addEventListener("abort", () => removals++);
  target.addEventListener("ping", null, { signal: owner.signal });
  owner.abort();
  target.dispatchEvent(new Event("ping"));
  log("listeners the null listener added to its signal:", removals === 1 ? "none" : removals - 1);
}

{
  const owner = new AbortController();
  const target = new EventTarget();
  target.addEventListener("ping", () => log("once, until the signal aborts"), { once: true, signal: owner.signal });
  target.addEventListener("ping", () => log("every time, until the signal aborts"), { signal: owner.signal });
  target.dispatchEvent(new Event("ping"));
  target.dispatchEvent(new Event("ping"));
  owner.abort();
  target.dispatchEvent(new Event("ping"));
  log("done");
}

// expect:
// a later listener runs
// the listener ran
// after the abort: the listener added twice is gone
// listeners the null listener added to its signal: none
// once, until the signal aborts
// every time, until the signal aborts
// every time, until the signal aborts
// done
