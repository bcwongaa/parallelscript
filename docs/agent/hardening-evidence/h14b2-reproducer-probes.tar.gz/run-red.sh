#!/usr/bin/env bash
set -uo pipefail
root=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a41b7de34d0d7998b
out="$root/.h14b2-reproducer-evidence/original-red"
mkdir -p "$out/sources"
cp "$root/pts/tests/http_request_deadlines_test.go" "$out/sources/http_request_deadlines_test.go"
cp "$root/pts/tests/http/request_deadlines.pts" "$out/sources/request_deadlines.pts"
printf '%s\n' 'env PTS_HOME=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a41b7de34d0d7998b GOMAXPROCS=2 go -C /home/bryan/projects/parallelscript/.claude/worktrees/agent-a41b7de34d0d7998b test -json ./pts/tests -p 1 -parallel 1 -count 1 -timeout 15m -run "^(TestHTTPServerRequestDeadline|TestHTTPSServerRequestDeadline)"' > "$out/command.txt"
git -C "$root" rev-parse HEAD > "$out/base.txt"
sha256sum "$root/pts/tests/http_request_deadlines_test.go" "$root/pts/tests/http/request_deadlines.pts" "$root/pts/runtime/src/http.c" "$root/pts/lib/http.pts" > "$out/before.sha256"
env PTS_HOME="$root" GOMAXPROCS=2 go -C "$root" test -json ./pts/tests -p 1 -parallel 1 -count 1 -timeout 15m -run '^(TestHTTPServerRequestDeadline|TestHTTPSServerRequestDeadline)' > "$out/stdout.jsonl" 2> "$out/stderr.txt"
code=$?
printf '%d\n' "$code" > "$out/exit.txt"
sha256sum "$root/pts/tests/http_request_deadlines_test.go" "$root/pts/tests/http/request_deadlines.pts" "$root/pts/runtime/src/http.c" "$root/pts/lib/http.pts" > "$out/after.sha256"
printf 'Original RED go test exit=%d\n' "$code"
exit "$code"
