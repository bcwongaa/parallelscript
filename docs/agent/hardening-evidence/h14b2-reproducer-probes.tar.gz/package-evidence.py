import collections
import json
from pathlib import Path
import re
import sys
import tarfile

root = Path(sys.argv[1]).resolve()
evidence = root / ".h14b2-reproducer-evidence"
raw = evidence / "original-red"
events = [json.loads(line) for line in (raw / "stdout.jsonl").read_text().splitlines() if line.strip()]
completed = [event for event in events if event.get("Test") and event.get("Action") in ("pass", "fail", "skip")]
names = {event["Test"] for event in completed}
leaves = [event for event in completed if not any(other.startswith(event["Test"] + "/") for other in names)]
counts = {
    "base": (raw / "base.txt").read_text().strip(),
    "exit_code": int((raw / "exit.txt").read_text().strip()),
    "all_test_events": dict(collections.Counter(event["Action"] for event in completed)),
    "leaf_test_events": dict(collections.Counter(event["Action"] for event in leaves)),
    "failed_leaves": [event["Test"] for event in leaves if event["Action"] == "fail"],
    "sources_unchanged": (raw / "before.sha256").read_bytes() == (raw / "after.sha256").read_bytes(),
    "stderr_bytes": (raw / "stderr.txt").stat().st_size,
}
(raw / "counts.json").write_text(json.dumps(counts, indent=2) + "\n")
patches = [(evidence / name).read_bytes() for name in ("test-go.patch", "test-fixture.patch")]
if not all(patch.startswith(b"diff --git ") for patch in patches):
    raise RuntimeError("expected the two plain-git diff receipts")
(evidence / "new-tests.patch").write_bytes(b"".join(patches))
private_key = re.compile(rb"(?m)^-----BEGIN [^-\r\n]*PRIVATE KEY-----")
files = sorted(path for path in evidence.rglob("*") if path.is_file())
for path in files:
    if path.is_symlink() or private_key.search(path.read_bytes()):
        raise RuntimeError(f"unsafe archive member: {path}")
archive = root / "h14b2-reproducer-safe.tar.gz"
with tarfile.open(archive, "w:gz") as output:
    for path in files:
        output.add(path, arcname=str(path.relative_to(evidence)), recursive=False)
with tarfile.open(archive, "r:gz") as check:
    for member in check.getmembers():
        if not member.isfile() or member.name.startswith("/") or ".." in Path(member.name).parts:
            raise RuntimeError(f"unsafe tar member: {member.name}")
print(json.dumps(counts, indent=2))
print(f"archive={archive}")
