package tests

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"strconv"
	"strings"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

const (
	requestDeadlineBudget      = 600 * time.Millisecond
	requestDeadlineObservation = 1800 * time.Millisecond
	requestDeadlinePhasePause  = 1200 * time.Millisecond
	requestWholeBudget         = time.Second
	requestHeadPause           = 650 * time.Millisecond
	requestWholeLatest         = 1400 * time.Millisecond
	requestShortHeaderBudget   = 250 * time.Millisecond
	requestLongHeaderBudget    = 1800 * time.Millisecond
	requestIncompleteHead      = "POST /echo HTTP/1.1\r\nHost: loopback\r\nContent-Length: 2\r\n"
	requestIncompleteBody      = requestIncompleteHead + "\r\na"
)

type requestDeadlinePolicy struct {
	request   time.Duration
	headers   time.Duration
	undefined bool
}

func startRequestDeadlineEndpoint(t *testing.T, exe string, secure bool, threads int, policy requestDeadlinePolicy) resourceEndpoint {
	t.Helper()
	requestOption := strconv.FormatInt(policy.request.Milliseconds(), 10)
	if policy.undefined {
		requestOption = "undefined"
	}
	env := []string{
		fmt.Sprintf("PTS_THREADS=%d", threads),
		"H14_REQUEST_TIMEOUT=" + requestOption,
		fmt.Sprintf("H14_HEADERS_TIMEOUT=%d", policy.headers.Milliseconds()),
		fmt.Sprintf("H14_HANDSHAKE_TIMEOUT=%d", (2 * resourceObservation).Milliseconds()),
	}
	protocol := "http"
	var config *tls.Config
	if secure {
		protocol = "https"
		certFile, keyFile, root := serverFiles(t, t.TempDir())
		env = append(env, "H14_TLS_CERT_FILE="+certFile, "H14_TLS_KEY_FILE="+keyFile)
		config = &tls.Config{RootCAs: pool(root.cert), ServerName: "127.0.0.1", NextProtos: []string{"http/1.1"}}
	}
	server, ports := startServer(t, exe, env...)
	assert.Equal(t, len(ports), 1)
	endpoint := resourceEndpoint{
		server: server, address: "127.0.0.1:" + ports[0], tlsConfig: config,
		client: &http.Client{Transport: &http.Transport{TLSClientConfig: config, DisableKeepAlives: true}, Timeout: resourceObservation},
		exited: make(chan error, 1),
	}
	endpoint.base = protocol + "://" + endpoint.address
	go func() { endpoint.exited <- server.cmd.Wait() }()
	t.Cleanup(endpoint.client.CloseIdleConnections)
	return endpoint
}

func requestDeadlineMatrix(t *testing.T, run func(t *testing.T, secure bool, threads int)) {
	t.Helper()
	for _, threads := range []int{1, 4} {
		for _, secure := range []bool{false, true} {
			t.Run(fmt.Sprintf("threads=%d/TLS=%v", threads, secure), func(t *testing.T) {
				run(t, secure, threads)
			})
		}
	}
}

func waitRequestDeadlinePhase(t *testing.T, duration time.Duration) {
	t.Helper()
	timer := time.NewTimer(duration)
	defer timer.Stop()
	select {
	case <-timer.C:
	case <-t.Context().Done():
		t.Fatal(t.Context().Err())
	}
}

func readRequestDeadlineResponse(t *testing.T, reader *bufio.Reader) string {
	t.Helper()
	response, err := http.ReadResponse(reader, nil)
	assert.NilError(t, err)
	assert.Equal(t, response.StatusCode, http.StatusOK)
	body, err := io.ReadAll(response.Body)
	assert.NilError(t, err)
	assert.NilError(t, response.Body.Close())
	return string(body)
}

func observeRequestClosure(t *testing.T, conn net.Conn, started time.Time, progress string) resourceRead {
	t.Helper()
	assert.NilError(t, conn.SetReadDeadline(time.Now().Add(requestDeadlineObservation)))
	if progress == "" {
		return readResourceClosure(conn, started)
	}
	return trickleUntilResourceClosure(t, conn, started, func() []byte { return []byte(progress) })
}

type requestExpiryExpectation struct {
	budget time.Duration
	latest time.Duration
	calls  int
}

func checkRequestClosure(t *testing.T, endpoint resourceEndpoint, got resourceRead, want requestExpiryExpectation) {
	t.Helper()
	t.Logf("request deadline: elapsed=%s wire=%q read_error=%v", got.elapsed, got.bytes, got.err)
	assert.Check(t, resourceConnectionClosed(got.err), "request expiry must close, not merely go quiet: %v", got.err)
	assert.Check(t, len(got.bytes) == 0, "request expiry sends no final or interim response: %q", got.bytes)
	assert.Check(t, got.elapsed >= want.budget/2, "requestTimeout uses milliseconds, not an immediate close: %s", got.elapsed)
	assert.Check(t, got.elapsed < want.latest, "absolute request budget was not enforced: %s >= %s", got.elapsed, want.latest)
	assert.Equal(t, endpoint.count(t), want.calls, "an incomplete expired request must never dispatch")
}

// Every chunk, HTTP line and advertised length is valid. Only completion is delayed.
func TestHTTPServerRequestDeadlinesBoundIncompleteRequests(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{request: requestDeadlineBudget})
		defer endpoint.stop(t)
		assert.Equal(t, endpoint.get(t, "/ok"), "ok")
		for _, test := range []struct {
			name      string
			wire      string
			progress  string
			continued bool
		}{
			{name: "silent_initial_request"},
			{name: "incomplete_headers", wire: requestIncompleteHead},
			{name: "content_length_body_stalls", wire: requestIncompleteBody},
			{name: "chunked_body_stalls", wire: "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n8\r\nab"},
			{name: "chunked_body_needs_terminal_chunk", wire: "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nab\r\n"},
			{name: "content_length_progress_does_not_refresh", wire: "POST /echo HTTP/1.1\r\nHost: loopback\r\nContent-Length: 64\r\n\r\na", progress: "a"},
			{name: "chunked_progress_does_not_refresh", wire: "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n", progress: "1\r\na\r\n"},
			{name: "expect_continue_does_not_end_request_budget", wire: "POST /echo HTTP/1.1\r\nHost: loopback\r\nExpect: 100-continue\r\nContent-Length: 2\r\n\r\n", continued: true},
		} {
			t.Run(test.name, func(t *testing.T) {
				before := endpoint.count(t)
				conn := endpoint.dial(t)
				defer conn.Close()
				started := time.Now()
				if test.wire != "" {
					_, err := io.WriteString(conn, test.wire)
					assert.NilError(t, err)
				}
				if test.continued {
					reader := bufio.NewReader(conn)
					response, err := http.ReadResponse(reader, nil)
					assert.NilError(t, err)
					assert.Equal(t, response.StatusCode, http.StatusContinue)
					assert.NilError(t, response.Body.Close())
					assert.Equal(t, reader.Buffered(), 0)
				}
				got := observeRequestClosure(t, conn, started, test.progress)
				checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
					budget: requestDeadlineBudget, latest: 2 * requestDeadlineBudget, calls: before,
				})
			})
		}
		t.Run("later_request_rearms_after_idle", func(t *testing.T) {
			conn := endpoint.dial(t)
			defer conn.Close()
			reader := bufio.NewReader(conn)
			assert.Equal(t, resourceRoundTrip(t, conn, reader, "/ok", ""), "ok")
			waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
			before := endpoint.count(t)
			started := time.Now()
			_, err := io.WriteString(conn, requestIncompleteBody)
			assert.NilError(t, err)
			assert.Equal(t, reader.Buffered(), 0)
			got := observeRequestClosure(t, conn, started, "")
			checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
				budget: requestDeadlineBudget, latest: 2 * requestDeadlineBudget, calls: before,
			})
		})
		t.Run("pipelined_partial_body_gets_a_new_budget", func(t *testing.T) {
			before := endpoint.count(t)
			conn := endpoint.dial(t)
			defer conn.Close()
			started := time.Now()
			_, err := io.WriteString(conn, "GET /ok HTTP/1.1\r\nHost: loopback\r\n\r\n"+requestIncompleteBody)
			assert.NilError(t, err)
			reader := bufio.NewReader(conn)
			assert.Equal(t, readRequestDeadlineResponse(t, reader), "ok")
			assert.Equal(t, reader.Buffered(), 0)
			got := observeRequestClosure(t, conn, started, "")
			checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
				budget: requestDeadlineBudget, latest: 2 * requestDeadlineBudget, calls: before + 1,
			})
		})
		assert.Equal(t, endpoint.get(t, "/ok"), "ok", "expired requests must not stop the listener")
	})
}

func TestHTTPServerRequestDeadlineIncludesHeaderTime(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{request: requestWholeBudget})
		defer endpoint.stop(t)
		for _, test := range []struct {
			name string
			head string
			body string
		}{
			{name: "content_length", head: requestIncompleteHead, body: "\r\na"},
			{name: "chunked", head: "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n", body: "\r\n2\r\na"},
		} {
			t.Run(test.name, func(t *testing.T) {
				before := endpoint.count(t)
				conn := endpoint.dial(t)
				defer conn.Close()
				started := time.Now()
				_, err := io.WriteString(conn, test.head)
				assert.NilError(t, err)
				waitRequestDeadlinePhase(t, requestHeadPause)
				_, err = io.WriteString(conn, test.body)
				assert.NilError(t, err)
				got := observeRequestClosure(t, conn, started, "")
				checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
					budget: requestWholeBudget, latest: requestWholeLatest, calls: before,
				})
			})
		}
	})
}

func TestHTTPServerRequestDeadlineEarlierPhaseWins(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		for _, test := range []struct {
			name     string
			policy   requestDeadlinePolicy
			earliest time.Duration
		}{
			{name: "request_before_header", policy: requestDeadlinePolicy{request: requestDeadlineBudget, headers: requestLongHeaderBudget}, earliest: requestDeadlineBudget},
			{name: "header_before_request", policy: requestDeadlinePolicy{request: requestDeadlinePhasePause, headers: requestShortHeaderBudget}, earliest: requestShortHeaderBudget},
			{name: "disabled_request_keeps_header_deadline", policy: requestDeadlinePolicy{headers: requestShortHeaderBudget}, earliest: requestShortHeaderBudget},
		} {
			t.Run(test.name, func(t *testing.T) {
				endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, test.policy)
				defer endpoint.stop(t)
				before := endpoint.count(t)
				conn := endpoint.dial(t)
				defer conn.Close()
				started := time.Now()
				_, err := io.WriteString(conn, requestIncompleteHead)
				assert.NilError(t, err)
				got := observeRequestClosure(t, conn, started, "")
				checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
					budget: test.earliest, latest: test.earliest + requestDeadlineBudget, calls: before,
				})
			})
		}
	})
}

func TestHTTPServerRequestDeadlinePhaseExclusions(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{request: requestDeadlineBudget})
		defer endpoint.stop(t)
		t.Run("complete_slow_handler_is_not_request_timed", func(t *testing.T) {
			for _, test := range []struct {
				name string
				wire string
			}{
				{name: "content_length", wire: "POST /slow HTTP/1.1\r\nHost: loopback\r\nContent-Length: 2\r\n\r\nab"},
				{name: "chunked", wire: "POST /slow HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nab\r\n0\r\n\r\n"},
			} {
				t.Run(test.name, func(t *testing.T) {
					conn := endpoint.dial(t)
					defer conn.Close()
					_, err := io.WriteString(conn, test.wire)
					assert.NilError(t, err)
					assert.Equal(t, readRequestDeadlineResponse(t, bufio.NewReader(conn)), "slow:false")
				})
			}
		})
		t.Run("complete_chunked_and_pipelined_requests_work", func(t *testing.T) {
			before := endpoint.count(t)
			conn := endpoint.dial(t)
			defer conn.Close()
			_, err := io.WriteString(conn, "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n2\r\nab\r\n1\r\nc\r\n0\r\n\r\n"+
				"POST /echo HTTP/1.1\r\nHost: loopback\r\nContent-Length: 2\r\n\r\nde")
			assert.NilError(t, err)
			reader := bufio.NewReader(conn)
			assert.Equal(t, readRequestDeadlineResponse(t, reader), "abc")
			assert.Equal(t, readRequestDeadlineResponse(t, reader), "de")
			assert.Equal(t, endpoint.count(t), before+2)
		})
		t.Run("queued_response_is_not_request_timed", func(t *testing.T) {
			conn := endpoint.dial(t)
			defer conn.Close()
			_, err := io.WriteString(conn, "GET /large HTTP/1.1\r\nHost: loopback\r\n\r\n")
			assert.NilError(t, err)
			waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
			readResourceLargeResponse(t, conn, bufio.NewReader(conn))
		})
		t.Run("next_partial_body_waits_for_preceding_output", func(t *testing.T) {
			before := endpoint.count(t)
			conn := endpoint.dial(t)
			defer conn.Close()
			_, err := io.WriteString(conn, "GET /large HTTP/1.1\r\nHost: loopback\r\n\r\n"+requestIncompleteBody)
			assert.NilError(t, err)
			waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
			reader := bufio.NewReader(conn)
			readResourceLargeResponse(t, conn, reader)
			assert.Equal(t, reader.Buffered(), 0)
			started := time.Now()
			got := observeRequestClosure(t, conn, started, "")
			checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
				budget: requestDeadlineBudget, latest: 2 * requestDeadlineBudget, calls: before + 1,
			})
		})
	})
}

func TestHTTPServerRequestDeadlineCanBeDisabled(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{})
		defer endpoint.stop(t)
		for _, test := range []struct {
			name   string
			prefix string
			end    string
			body   string
		}{
			{name: "headers", prefix: requestIncompleteHead, end: "\r\nab", body: "ab"},
			{name: "content_length_body", prefix: requestIncompleteBody, end: "b", body: "ab"},
			{name: "chunked_body", prefix: "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\n\r\n2\r\na", end: "b\r\n0\r\n\r\n", body: "ab"},
		} {
			t.Run(test.name, func(t *testing.T) {
				conn := endpoint.dial(t)
				defer conn.Close()
				_, err := io.WriteString(conn, test.prefix)
				assert.NilError(t, err)
				waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
				_, err = io.WriteString(conn, test.end)
				assert.NilError(t, err)
				assert.Equal(t, readRequestDeadlineResponse(t, bufio.NewReader(conn)), test.body)
			})
		}
	})
}

func TestHTTPServerRequestDeadlineUndefinedUsesLongDefault(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{undefined: true})
		defer endpoint.stop(t)
		conn := endpoint.dial(t)
		defer conn.Close()
		_, err := io.WriteString(conn, requestIncompleteBody)
		assert.NilError(t, err)
		waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
		_, err = io.WriteString(conn, "b")
		assert.NilError(t, err)
		assert.Equal(t, readRequestDeadlineResponse(t, bufio.NewReader(conn)), "ab")
	})
}

func TestHTTPServerRequestDeadlineLeavesHeaderBodySeparation(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{request: 2 * requestDeadlinePhasePause, headers: requestShortHeaderBudget})
		defer endpoint.stop(t)
		conn := endpoint.dial(t)
		defer conn.Close()
		_, err := io.WriteString(conn, requestIncompleteBody)
		assert.NilError(t, err)
		waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
		_, err = io.WriteString(conn, "b")
		assert.NilError(t, err)
		assert.Equal(t, readRequestDeadlineResponse(t, bufio.NewReader(conn)), "ab", "headersTimeout must stop when complete headers enter the body phase")
	})
}

func TestHTTPSServerRequestDeadlineStartsAfterHandshake(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	for _, threads := range []int{1, 4} {
		t.Run(fmt.Sprintf("threads=%d", threads), func(t *testing.T) {
			endpoint := startRequestDeadlineEndpoint(t, exe, true, threads, requestDeadlinePolicy{request: requestDeadlineBudget})
			defer endpoint.stop(t)
			before := endpoint.count(t)
			conn := endpoint.raw(t)
			defer conn.Close()
			waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
			secured := tls.Client(conn, endpoint.tlsConfig)
			assert.NilError(t, secured.HandshakeContext(t.Context()))
			assert.Assert(t, len(secured.ConnectionState().VerifiedChains) > 0)
			started := time.Now()
			_, err := io.WriteString(secured, requestIncompleteBody)
			assert.NilError(t, err)
			got := observeRequestClosure(t, secured, started, "")
			checkRequestClosure(t, endpoint, got, requestExpiryExpectation{
				budget: requestDeadlineBudget, latest: 2 * requestDeadlineBudget, calls: before,
			})
		})
	}
}

func TestHTTPServerRequestDeadlineOptionsValidateBeforeListening(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	occupied, err := net.Listen("tcp4", "127.0.0.1:0")
	assert.NilError(t, err)
	defer occupied.Close()
	port := occupied.Addr().(*net.TCPAddr).Port
	result := execute(t, ".", []string{"PTS_THREADS=1", "H14_REQUEST_VALIDATE=1", fmt.Sprintf("H14_REQUEST_OCCUPIED_PORT=%d", port)}, exe)
	t.Logf("request option validation: exit=%d stdout=%q stderr=%q", result.exitCode, result.stdout, result.stderr)
	assert.Equal(t, result.exitCode, 0)
	assert.Equal(t, result.stderr, "")
	var expected []string
	for _, label := range []string{"undefined", "zero", "negative-zero", "one", "maximum"} {
		expected = append(expected, label+" accepted")
	}
	for _, label := range []string{"negative", "fraction", "nan", "infinity", "negative-infinity", "above-maximum", "unsafe-integer", "before-listening"} {
		expected = append(expected, label+" true true")
	}
	expected = append(expected, "omitted accepted")
	assert.Equal(t, result.stdout, strings.Join(expected, "\n")+"\n")
}

func TestHTTPServerRequestDeadlineDisconnectCleanup(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	requestDeadlineMatrix(t, func(t *testing.T, secure bool, threads int) {
		endpoint := startRequestDeadlineEndpoint(t, exe, secure, threads, requestDeadlinePolicy{request: requestDeadlineBudget})
		defer endpoint.stop(t)
		for count := 1; count <= 3; count++ {
			conn := endpoint.dial(t)
			_, err := io.WriteString(conn, "GET /until-abort HTTP/1.1\r\nHost: loopback\r\n\r\n")
			assert.NilError(t, err)
			awaitResourceState(t, endpoint, fmt.Sprintf("%d:%d", count, count-1))
			if count == 1 {
				waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
				assert.Equal(t, endpoint.get(t, "/held"), "1:0", "a complete handler must not be cancelled by the request timer")
			}
			assert.NilError(t, conn.Close())
			awaitResourceState(t, endpoint, fmt.Sprintf("%d:%d", count, count))
		}
		before := endpoint.count(t)
		for range 12 {
			conn := endpoint.dial(t)
			_, err := io.WriteString(conn, requestIncompleteBody)
			assert.NilError(t, err)
			assert.NilError(t, conn.Close())
		}
		waitRequestDeadlinePhase(t, requestDeadlinePhasePause)
		assert.Equal(t, endpoint.count(t), before, "closed incomplete bodies must not dispatch later")
		assert.Equal(t, endpoint.get(t, "/held"), "3:3")
		assert.Equal(t, endpoint.get(t, "/ok"), "ok", "disconnecting timed bodies leaves the listener usable")
	})
}

func TestHTTPServerRequestDeadlineExpiryReleasesResources(t *testing.T) {
	t.Parallel()
	exe := buildShared(t, "request_deadlines")
	for _, secure := range []bool{false, true} {
		t.Run(fmt.Sprintf("TLS=%v", secure), func(t *testing.T) {
			endpoint := startRequestDeadlineEndpoint(t, exe, secure, 4, requestDeadlinePolicy{request: requestDeadlineBudget})
			defer endpoint.stop(t)
			assert.Equal(t, endpoint.get(t, "/ok"), "ok")
			pid := endpoint.server.cmd.Process.Pid
			baselineFiles := openFiles(t, pid)
			baselineRSS := residentMB(t, pid)
			before := endpoint.count(t)
			for batch := 0; batch < 2; batch++ {
				connections := make([]net.Conn, 0, 16)
				deadline := time.Now().Add(requestDeadlineObservation)
				for range 16 {
					conn := endpoint.dial(t)
					_, err := io.WriteString(conn, requestIncompleteBody)
					assert.NilError(t, err)
					assert.NilError(t, conn.SetReadDeadline(deadline))
					connections = append(connections, conn)
				}
				for _, conn := range connections {
					got := readResourceClosure(conn, time.Now())
					assert.Check(t, resourceConnectionClosed(got.err), "batch=%d an incomplete body stayed open past requestTimeout: %v", batch, got.err)
					assert.Check(t, len(got.bytes) == 0, "an expired body produced a response: %q", got.bytes)
					_ = conn.Close()
				}
				awaitResourceFiles(t, pid, baselineFiles)
				assert.Equal(t, endpoint.count(t), before)
			}
			growth := residentMB(t, pid) - baselineRSS
			t.Logf("request expiry resources: TLS=%v files_before=%d files_after=%d rss_growth_mb=%.3f", secure, baselineFiles, openFiles(t, pid), growth)
			assert.Check(t, growth < 16, "32 expired requests retained too much memory: %.3f MiB", growth)
		})
	}
}
