#!/bin/bash
# nofb_one.sh file.pts -> "name|base AllInstances result|snap8 AllInstances result" (no fallback)
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap8/pts/tests/||; s|/|__|g; s|.pts$||')
b=$(PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/review/nofb/nofb-base all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
s=$(PTS_HOME=/tmp/h09b4/snap8 timeout 120 /tmp/h09b4/review/round4/nofb/nofb-snap8 all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
echo "$n|$b|$s"
