#!/bin/bash
# emit_one.sh file.pts -> "relname base_exit snap8_exit same|diff"; keeps the C only when it differs
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap8/pts/tests/||; s|/|__|g; s|.pts$||')
o=/tmp/h09b4/review/round4/emit/out
PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/base/pts-bin/pts emit-c "$f" > $o/$n.base.c 2>$o/$n.base.err; be=$?
PTS_HOME=/tmp/h09b4/snap8 timeout 120 /tmp/h09b4/snap8/pts-bin/pts emit-c "$f" > $o/$n.snap.c 2>$o/$n.snap.err; se=$?
if cmp -s $o/$n.base.c $o/$n.snap.c; then
  same=same
  rm -f $o/$n.base.c $o/$n.snap.c $o/$n.base.err $o/$n.snap.err
else
  same=diff
fi
echo "$n $be $se $same"
