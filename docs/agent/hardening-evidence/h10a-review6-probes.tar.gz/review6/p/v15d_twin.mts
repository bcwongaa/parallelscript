// threads: 1 2 4
// parallel tasks and for over objects nested in an inferred narrowing's dynamic member
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {
    for (let i = 0; i < 64; i++) this.matrix[0].push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function sumOf(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0);
}
function grow(xs: number[]): number {
  xs.push(1);
  return xs.length;
}
async function run(c: Cache<string, number>): Promise<void> {
  if (!(c instanceof MapLRU)) return;
  const f = await Promise.resolve(sumOf(c.matrix[0]));
  const g = await Promise.resolve(grow(c.matrix[1]));
  let n = 0;
  for (const v of c.matrix[0]) {
    if (v < 0) console.log("neg");
  }
  console.log(f, g, c.matrix[1].length);
}
run(new MapLRU<string, number>("k", 3));
