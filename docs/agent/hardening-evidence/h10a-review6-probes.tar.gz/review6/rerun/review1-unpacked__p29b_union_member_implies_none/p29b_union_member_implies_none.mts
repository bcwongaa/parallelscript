// A union of an interface that implies MapLRU<string, number> and a member that implies no
// instance but can hold any MapLRU (object, a plain base class, an interface without the
// type parameters): the inferred MapLRU<string, number> isn't every object's instance.
class Shape {
  kind = "shape";
}
interface Cache<K, V> {
  get(key: K): V | undefined;
}
interface Sized {
  size(): number;
}
class MapLRU<K, V> extends Shape implements Cache<K, V>, Sized {
  constructor(public key: K, public val: V) {
    super();
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  size(): number {
    return 1;
  }
}
function viaObject(c: Cache<string, number> | object): string {
  return c instanceof MapLRU ? `object ${c.key} ${c.val}` : "other";
}
function viaShape(c: Cache<string, number> | Shape): string {
  return c instanceof MapLRU ? `shape ${c.key} ${c.val}` : "other";
}
function viaSized(c: Cache<string, number> | Sized): string {
  return c instanceof MapLRU ? `sized ${c.key} ${c.val}` : "other";
}
const fs = [
  () => viaObject(new MapLRU<string, number>("a", 1)),
  () => viaObject(new MapLRU<boolean, string>(true, "b")),
  () => viaShape(new MapLRU<string, number>("c", 3)),
  () => viaSized(new MapLRU<number, number[]>(3, [4])),
];
for (const f of fs) {
  try {
    console.log(f());
  } catch (e: any) {
    console.log("threw", e.message);
  }
}
