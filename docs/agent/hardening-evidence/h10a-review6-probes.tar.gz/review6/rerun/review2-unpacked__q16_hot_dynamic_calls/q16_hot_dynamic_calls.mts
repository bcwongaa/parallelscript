// A hot loop of method calls with an arrow argument through an inferred narrowing (fix2
// makes them dynamic calls), against the same calls through a typed parameter.
interface Counter<V> {
  peek(): V;
}
class Cell<V> implements Counter<V> {
  constructor(public v: V) {}
  peek(): V {
    return this.v;
  }
  update(f: (old: V) => V): V {
    this.v = f(this.v);
    return this.v;
  }
}
function narrowed(c: Counter<number>): number {
  if (c instanceof Cell) for (let i = 0; i < 2_000_000; i++) c.update((o) => o + 1);
  return c.peek();
}
function typed(c: Cell<number>): number {
  for (let i = 0; i < 2_000_000; i++) c.update((o) => o + 1);
  return c.peek();
}
let t = Date.now();
console.log(narrowed(new Cell<number>(0)));
const t1 = Date.now() - t;
t = Date.now();
console.log(typed(new Cell<number>(0)));
console.error(`ms narrowed=${t1} typed=${Date.now() - t}`);
