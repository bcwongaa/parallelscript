// Members tsc types Promise<any>, (v: any) => any, Map<any, any> through the inferred
// narrowing, bound to locals or awaited.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V>();
  constructor(public key: K, public val: V) {
    this.store.set(key, val);
  }
  get(key: K): V | undefined {
    return this.store.get(key);
  }
  async load(): Promise<V> {
    return this.val;
  }
  mapper(): (v: V) => V {
    return (v) => v;
  }
}
async function main(c: Cache<string, number>): Promise<void> {
  if (c instanceof MapLRU) {
    console.log("await", (await c.load()) + 1);
    const p = c.load();
    console.log("promise", await p);
    const s = c.store;
    console.log("map", s.size, s.get("k"));
    const f = c.mapper();
    console.log("fn", f(4));
  }
}
main(new MapLRU<string, number>("k", 2));
