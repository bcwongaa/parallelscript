// The r15 sinks fix4 doesn't reject: are their writes kept? (Node: every line "true".)
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  groups: { list: V[] }[] = [];
  constructor(public key: K, public val: V) {
    this.groups.push({ list: [] });
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Keeper {
  kept: any[] = [];
}
function fillAny(a: any[]): void {
  a.push(1);
}
const flag = Math.random() < 2;
type Sink = (c: MapLRU<string, number>) => boolean;
function make(name: string, f: (c: Cache<string, number>) => void, seen: (c: MapLRU<string, number>) => number): void {
  const m = new MapLRU<string, number>("k", 0);
  f(m);
  console.log(name, seen(m) > 0);
}
const len = (c: MapLRU<string, number>) => c.items.length;
make("conditional", (c) => { if (c instanceof MapLRU) { const a = flag ? c.items : []; a.push(1); } }, len);
make("or", (c) => { if (c instanceof MapLRU) { const a = c.items || []; a.push(1); } }, len);
make("satisfies", (c) => { if (c instanceof MapLRU) { const a = c.items satisfies any[]; a.push(1); } }, len);
make("for-of destructuring", (c) => { if (c instanceof MapLRU) for (const { list } of c.groups) list.push(1); }, (c) => c.groups[0].list.length);
make("local shorthand", (c) => { if (c instanceof MapLRU) { const it = c.items; const o = { it }; o.it.push(1); } }, len);
make("local conditional", (c) => { if (c instanceof MapLRU) { const it = c.items; const t = flag ? it : []; t.push(1); } }, len);
make("control: local", (c) => { if (c instanceof MapLRU) { const it = c.items; it.push(1); } }, len);
