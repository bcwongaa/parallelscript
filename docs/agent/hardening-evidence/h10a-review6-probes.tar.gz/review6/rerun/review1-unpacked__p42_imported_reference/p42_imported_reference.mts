// An imported const (an alias symbol) narrowed by instanceof to a generic class.
import { shared, MapLRU } from "./p42_mod/lib.pts";
if (shared instanceof MapLRU) console.log("imported", shared.key, shared.val + 1);
