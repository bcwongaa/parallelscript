// Calls that fix2 makes dynamic (literal arguments for parameters tsc types with any, and
// function-valued fields) through an inferred narrowing: `this` inside them, argument
// conversions and checks, defaults, rest parameters, generic methods, fluent returns.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V>();
  log: string[] = [];
  onSet: ((k: K, v: V) => void) | undefined;
  get(key: K): V | undefined {
    return this.store.get(key);
  }
  put(key: K, value: V, note = "none", ...tags: string[]): this {
    this.store.set(key, value);
    this.log.push(`${String(key)}:${note}:${tags.join("+")}`);
    this.onSet?.(key, value);
    return this;
  }
  putAll(entries: [K, V][]): number {
    for (const [k, v] of entries) this.store.set(k, v);
    return this.store.size;
  }
  update(key: K, f: (old: V | undefined) => V): V {
    const v = f(this.store.get(key));
    this.store.set(key, v);
    return v;
  }
  mapAll<R>(f: (v: V, k: K) => R): R[] {
    const out: R[] = [];
    this.store.forEach((v, k) => out.push(f(v, k)));
    return out;
  }
  merge(other: { key: K; value: V }): string {
    this.store.set(other.key, other.value);
    return `${this.store.size}`;
  }
}
function uses(c: Cache<string, number[]>): void {
  if (!(c instanceof MapLRU)) return;
  c.onSet = (k, v) => console.log("onSet", k, v.length);
  c.put("a", [1, 2]);
  c.put("b", [3], "note", "x", "y");
  console.log("1", c.log, c.get("b"));
  console.log("2", c.putAll([["c", [4, 5, 6]], ["d", []]]), c.store.size);
  console.log("3", c.update("a", (old) => [...(old ?? []), 9]), c.get("a"));
  console.log("4", c.mapAll((v, k) => `${k}=${v.length}`));
  console.log("5", c.merge({ key: "e", value: [7] }), c.get("e"));
  console.log("6", c.put("f", [8]).put("g", [0]).log.length);
  try {
    c.put("bad", ["not a number" as any]);
    console.log("7", c.get("bad"));
  } catch (e: any) {
    console.log("7 threw", e.message);
  }
}
uses(new MapLRU<string, number[]>());
