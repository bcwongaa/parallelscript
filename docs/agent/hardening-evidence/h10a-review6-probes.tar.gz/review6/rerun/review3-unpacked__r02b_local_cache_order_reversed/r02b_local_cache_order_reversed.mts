// `const it = x.items; it.push(9)` in a generic function: for S = Shape, x is an uninferred
// (dynamic) narrowing and `it` a dynamic local; for S = Box<number>, x is typed. The call (here: Box<number> first)
// order decides which instance is lowered first.
class Shape {}
class Box<T> extends Shape {
  items: T[] = [];
  constructor(v: T) {
    super();
    this.items.push(v);
  }
}
function grow<S>(x: S): number {
  if (x instanceof Box) {
    const it = x.items;
    it.push(9);
    return it.length;
  }
  return -1;
}
const a = new Box<number>(1);
const b = new Box<number>(2);
const second = grow<Box<number>>(b);
console.log(grow<Shape>(a), second, a.items, b.items);
