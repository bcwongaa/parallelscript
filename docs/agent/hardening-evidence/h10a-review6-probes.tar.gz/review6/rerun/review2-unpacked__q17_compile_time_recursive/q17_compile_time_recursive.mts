// Compile time: a member whose tsc type is a recursive anonymous object type with six
// optional self-references, read many times through an inferred narrowing (mentionsAny
// walks it to depth 8 on each read).
type Tree = { a?: Tree; b?: Tree; c?: Tree; d?: Tree; e?: Tree; f?: Tree; v: number };
interface Holder<V> {
  peek(): V;
}
class Box<V> implements Holder<V> {
  tree: Tree = { v: 1 };
  constructor(public val: V) {}
  peek(): V {
    return this.val;
  }
}
function sum(c: Holder<number>): number {
  let total = 0;
  if (c instanceof Box) {
    total += c.tree.v + (c.tree.a?.v ?? 0) + 0;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 1;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 2;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 3;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 4;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 5;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 6;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 7;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 8;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 9;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 10;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 11;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 12;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 13;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 14;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 15;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 16;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 17;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 18;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 19;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 20;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 21;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 22;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 23;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 24;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 25;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 26;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 27;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 28;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 29;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 30;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 31;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 32;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 33;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 34;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 35;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 36;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 37;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 38;
    total += c.tree.v + (c.tree.a?.v ?? 0) + 39;
  }
  return total;
}
console.log(sum(new Box<number>(1)));
