// Box<any> object (from an any value) held as a non-generic base class: a private method
// call through the narrowing, inside the class (base: checked downcast to Box<any> succeeds).
class Shape {
  name = "shape";
}
class Box<T> extends Shape {
  constructor(public v: T) {
    super();
  }
  bump(s: Shape): void {
    if (s instanceof Box) s.#tick();
  }
  #tick(): void {
    console.log("tick", this.v);
  }
}
const raw: any = JSON.parse('"x"');
const b = new Box(raw);
b.bump(b);
console.log("done");
