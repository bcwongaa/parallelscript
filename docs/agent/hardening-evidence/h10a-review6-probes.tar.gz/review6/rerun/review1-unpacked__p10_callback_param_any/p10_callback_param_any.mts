// A callback whose parameters tsc types any (MapLRU<any, any>'s each) passed to the
// inferred instance's method (MapLRU<string, number>'s each takes (number, string) => void).
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  each(f: (v: V, k: K) => void): void {
    f(this.val, this.key);
  }
}
class Fixed implements Cache<string, number> {
  get(_k: string): number | undefined {
    return 1;
  }
}
function uses(c: Cache<string, number>): void {
  if (c instanceof MapLRU) c.each((v, k) => console.log(v * 3, k + "!"));
  else console.log("fixed");
}
uses(new Fixed());
uses(new MapLRU<string, number>("k", 1));
