// x: S narrowed by instanceof MapLRU: `S & MapLRU<any, any>`. S = Twin, a class with the
// same public shape as MapLRU<string, number> (structural inference succeeds, the branch
// can't run); S = MapLRU<string, number>; S = a subclass; S = number; S = Cache.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  hits = 0;
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Twin {
  hits = 0;
  constructor(public key: string, public val: number) {}
  get(key: string): number | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Sub extends MapLRU<string, number> {
  extra = 1;
}
function probe<S>(x: S): string {
  if (x instanceof MapLRU) {
    x.hits++;
    return `lru ${x.key} ${x.val} ${x.hits}`;
  }
  return `other ${typeof x}`;
}
console.log(probe(new Twin("t", 1)));
console.log(probe(new MapLRU<string, number>("m", 2)));
console.log(probe(new Sub("s", 3)));
console.log(probe(5));
console.log(probe<Cache<string, number>>(new MapLRU<string, number>("c", 4)));
console.log(probe<Cache<string, number>>(new Twin("u", 5)));
console.log(probe<object>(new MapLRU<boolean, string>(true, "o")));
