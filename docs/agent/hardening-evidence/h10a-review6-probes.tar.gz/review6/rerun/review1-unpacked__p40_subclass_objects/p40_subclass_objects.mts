// Inferred MapLRU<string, number> holding subclass objects: non-generic, generic, flipped.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  #hits = 0;
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    this.#hits++;
    return key === this.key ? this.val : undefined;
  }
  describe(): string {
    return "base";
  }
  static hitsOf(c: Cache<string, number>): number {
    return c instanceof MapLRU ? c.#hits : -1;
  }
}
class StrLRU extends MapLRU<string, number> {
  describe(): string {
    return "str";
  }
}
class Sub<K, V> extends MapLRU<K, V> {
  extra = 1;
}
class Flip<V, K> extends MapLRU<K, V> {
  describe(): string {
    return "flip";
  }
}
function show(c: Cache<string, number>): string {
  return c instanceof MapLRU ? `${c.describe()} ${c.key} ${c.val + 1} ${c.get(c.key)}` : "other";
}
const objs: Cache<string, number>[] = [new StrLRU("s", 1), new Sub<string, number>("u", 2), new Flip<number, string>("f", 3)];
for (const o of objs) console.log(show(o), MapLRU.hitsOf(o));
