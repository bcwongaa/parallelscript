// `Cache<string, number> | object` holding a MapLRU<boolean, string>, narrowed by
// instanceof MapLRU: which check runs, and is the object read as the wrong instance?
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function viaObject(c: Cache<string, number> | object): string {
  if (c instanceof MapLRU) {
    const v = c.val;
    console.log("val read", typeof v);
    return `object ${c.key}`;
  }
  return "other";
}
try {
  console.log(viaObject(new MapLRU<boolean, string>(true, "b")));
} catch (e: any) {
  console.log("threw", e.message);
}
