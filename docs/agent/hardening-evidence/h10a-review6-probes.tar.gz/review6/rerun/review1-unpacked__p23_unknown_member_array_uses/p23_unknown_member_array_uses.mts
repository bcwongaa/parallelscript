// x: unknown narrowed to Box<any> (dynamic since D-179): uses of its any[] member, which
// H10a now keeps as the object's own typed array instead of a converted copy.
class Box<T> {
  items: T[] = [];
  names: string[] = ["b", "a"];
  constructor(...vs: T[]) {
    this.items.push(...vs);
  }
}
function takeAny(a: any[]): number {
  return a.length;
}
function takeNums(a: number[]): number {
  a.push(0);
  return a.length;
}
function uses(x: unknown): void {
  if (!(x instanceof Box)) return;
  console.log("1", x.items.length, x.items[1], x.items.join("-"), [...x.items]);
  console.log("2", x.items.map((v) => v * 2), x.items.filter((v) => v > 1), x.items.reduce((a, b) => a + b, 0));
  for (const v of x.items) console.log("3", v);
  console.log("4", Array.isArray(x.items), x.items.includes(2), x.items.indexOf(3), x.items.slice(1));
  x.items.sort((a, b) => b - a);
  console.log("5", x.items, x.names.sort(), x.names.reverse());
  console.log("6", takeAny(x.items), takeNums(x.items), x.items.length);
  console.log("7", JSON.stringify(x.items), String(x.items), `${x.items}`, x.items.concat([9]));
  x.items.length = 1;
  console.log("8", x.items, x.items.at(-1), typeof x.items, x.items === x.items);
  x.items.splice(0, 1, 5, 6);
  x.items.unshift(4);
  console.log("9", x.items, x.items.pop(), x.items.shift(), x.items);
  const [first, ...rest] = x.items;
  console.log("10", first, rest);
}
const b = new Box<number>(1, 2, 3);
uses(b);
console.log("after", b.items, b.names);
