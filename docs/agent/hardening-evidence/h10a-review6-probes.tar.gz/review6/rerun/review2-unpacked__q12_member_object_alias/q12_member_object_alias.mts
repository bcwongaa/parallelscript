// Tuple, object and array-of-object members (tsc: [any, any], { label: any; weight: any },
// { k: any; v: any }[]) bound to locals or iterated through an inferred narrowing, then
// changed: in JS the changes reach the object.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  pair: [K, V];
  meta: { label: K; weight: V };
  entries: { k: K; v: V }[] = [];
  constructor(public key: K, public val: V) {
    this.pair = [key, val];
    this.meta = { label: key, weight: val };
    this.entries.push({ k: key, v: val });
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function bump(m: { label: string; weight: number }): void {
  m.weight += 100;
}
function uses(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const p = c.pair;
  p[1] = 99;
  const meta = c.meta;
  meta.weight = 7;
  bump(c.meta);
  for (const e of c.entries) e.v += 1;
  const first = c.entries[0];
  first.k = "renamed";
}
const m = new MapLRU<string, number>("k", 1);
uses(m);
console.log("after", m.pair, m.meta, m.entries);
