// More ways a member tsc types with any reaches code that changes it, through an inferred
// narrowing: destructuring, a let, the third argument of forEach, Object.assign, a method
// of another object that keeps it.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  meta: { label: K; weight: V };
  constructor(public key: K, public val: V) {
    this.items.push(val, val);
    this.meta = { label: key, weight: val };
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Keeper {
  kept: any[] = [];
  keep(a: any[]): void {
    this.kept = a;
  }
}
function uses(c: Cache<string, number>, k: Keeper): void {
  if (!(c instanceof MapLRU)) return;
  c.items.push(3);
  let list = c.items;
  list[0] = 9;
  c.items.forEach((x, i, arr) => (arr[i] = x * 2));
  Object.assign(c.meta, { weight: 50 });
  k.keep(c.items);
  k.kept.push(77);
}
const m = new MapLRU<string, number>("k", 1);
const k = new Keeper();
uses(m, k);
console.log("after", m.items, m.meta, k.kept);
