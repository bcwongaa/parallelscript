// Sinks a member tsc types any[] (c.items) of an inferred narrowing can reach, each followed
// by a write that JS makes to the member itself: conditional and ?? initializers, `as`,
// object-literal shorthand of a dynamic local, a default parameter, `await`, a tagged
// template, an array literal iterated, logical assignment.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function tag(_s: TemplateStringsArray, a: any[]): number {
  a.push(-1);
  return a.length;
}
const flag = Math.random() < 2;
async function sinks(c: Cache<string, number>): Promise<void> {
  if (!(c instanceof MapLRU)) return;
  const a = flag ? c.items : [];
  a.push(1);
  const b = c.items ?? [];
  b.push(2);
  const d = c.items as any[];
  d.push(3);
  const items = c.items;
  const o = { items };
  o.items.push(4);
  const g = (arr = c.items) => arr.push(5);
  g();
  const w = await c.items;
  w.push(6);
  tag`${c.items}`;
  for (const it of [c.items]) it.push(7);
  let z: any[] | undefined;
  z ||= c.items;
  z.push(8);
  console.log("items", c.items);
}
sinks(new MapLRU<string, number>("k", 0));
