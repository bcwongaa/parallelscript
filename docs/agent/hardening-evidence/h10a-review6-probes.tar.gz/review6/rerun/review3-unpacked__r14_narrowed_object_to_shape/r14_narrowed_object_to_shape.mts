// The narrowed object itself passed where an object type with an array member goes: an
// uninferred (dynamic) narrowing and an inferred one; the callee writes through it.
class Shape {}
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class Box<T> extends Shape implements Cache<string, T> {
  items: T[] = [];
  constructor(v: T) {
    super();
    this.items.push(v);
  }
  get(_k: string): T | undefined {
    return this.items[0];
  }
}
function grow(h: { items: number[] }): void {
  h.items.push(9);
  h.items = [...h.items, 10];
}
function viaShape(s: Shape): void {
  if (s instanceof Box) grow(s);
}
function viaCache(c: Cache<string, number>): void {
  if (c instanceof Box) grow(c);
}
const a = new Box<number>(1);
const b = new Box<number>(2);
viaShape(a);
viaCache(b);
console.log(a.items, b.items);
