// `Cache<string, number> | object` holding MapLRU<number, string>, narrowed by instanceof
// MapLRU: the reference is taken as MapLRU<string, number>, and `c.key` (a number) is read
// as a string.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function viaObject(c: Cache<string, number> | object): string {
  if (c instanceof MapLRU) return `key ${c.key} len ${c.key.length}`;
  return "other";
}
console.log(viaObject(new MapLRU<number, string>(12345.5, "b")));
console.log(viaObject(new MapLRU<string, number>("ok", 1)));
