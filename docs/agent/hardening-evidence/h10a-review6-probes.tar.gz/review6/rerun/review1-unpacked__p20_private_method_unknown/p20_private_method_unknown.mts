// Private method call, private method read, private setter write on an `unknown` narrowed by
// instanceof, from static methods.
class Box<T> {
  #v: T;
  constructor(v: T) {
    this.#v = v;
  }
  #show(): string {
    return `show ${this.#v}`;
  }
  set #value(x: T) {
    this.#v = x;
  }
  get value(): T {
    return this.#v;
  }
  static call(o: unknown): unknown {
    return o instanceof Box ? o.#show() : "no";
  }
  static read(o: unknown): unknown {
    return o instanceof Box ? typeof o.#show : "no";
  }
  static set(o: unknown): unknown {
    if (o instanceof Box) o.#value = 9;
    return o instanceof Box ? o.value : "no";
  }
  static write(o: unknown): unknown {
    if (o instanceof Box) o.#v = 8;
    return o instanceof Box ? o.value : "no";
  }
}
const fs = [() => Box.call(new Box<number>(1)), () => Box.read(new Box<number>(2)), () => Box.set(new Box<number>(3)), () => Box.write(new Box<number>(4))];
for (const f of fs) {
  try {
    console.log(f());
  } catch (e: any) {
    console.log("threw", e.message);
  }
}
