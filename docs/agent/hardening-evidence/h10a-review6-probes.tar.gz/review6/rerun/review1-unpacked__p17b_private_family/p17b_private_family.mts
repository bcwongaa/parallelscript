// `o.#v` on a dynamically held narrowing (o: object), with subclass instances (generic and
// non-generic), a subclass that declares its own #v, an instance made only after the read's
// code, a private getter, and `#v in o`.
class Box<T> {
  #v: T;
  constructor(v: T) {
    this.#v = v;
  }
  peek(o: object): unknown {
    return o instanceof Box ? o.#v : "no";
  }
  peekGetter(o: object): unknown {
    return o instanceof Box ? o.#doubled : "no";
  }
  get #doubled(): string {
    return `${this.#v}${this.#v}`;
  }
}
class NumBox extends Box<number> {
  constructor() {
    super(42);
  }
}
class Sub<T> extends Box<T[]> {
  #v: string;
  constructor(x: T) {
    super([x]);
    this.#v = "sub-own";
  }
  ownPeek(o: object): unknown {
    return o instanceof Sub ? o.#v : "no";
  }
}
const b = new Box<number>(1);
console.log(b.peek(new Box("s")), b.peek(new NumBox()), b.peek(new Sub(true)), b.peek({}));
console.log(new Sub(1).ownPeek(new Sub("z")), new Sub(1).ownPeek(b));
function late(): unknown {
  return b.peek(new Box<boolean[]>([false]));
}
console.log(late());
try {
  console.log(b.peekGetter(new Box("g")));
} catch (e: any) {
  console.log("threw", e.message);
}
