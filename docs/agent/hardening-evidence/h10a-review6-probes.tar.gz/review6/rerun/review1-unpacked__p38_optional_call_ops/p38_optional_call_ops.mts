// Optional calls and optional member reads through an inferred narrowing, where tsc types
// the result any, used in operators.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  peek?: () => V;
}
function f(c: Cache<string, number> | undefined): void {
  if (c instanceof MapLRU) {
    console.log(c?.get("k") + "x", c?.key + c?.val, c.peek?.() ?? "none", c?.val.toFixed(1));
  }
}
f(new MapLRU<string, number>("k", 2));
