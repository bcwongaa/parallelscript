// A member tsc types any[] (K[] of MapLRU<any, any>) bound to a local in the narrowed branch.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
  keys(): K[] {
    return [this.key];
  }
}
class Fixed implements Cache<string, number> {
  get(_k: string): number | undefined {
    return 1;
  }
}
function stats(c: Cache<string, number>): number {
  if (c instanceof MapLRU) {
    const ks = c.keys();
    ks.push("z");
    return ks.length;
  }
  return 0;
}
console.log(stats(new Fixed()));
console.log(stats(new MapLRU<string, number>("a", 1)));
