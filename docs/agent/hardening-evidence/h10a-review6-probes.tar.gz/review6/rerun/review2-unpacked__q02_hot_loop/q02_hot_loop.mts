// A hot loop over a member array through the inferred narrowing (tsc: any[]) and through a
// typed parameter (Store<number>), same data.
interface Source<T> {
  first(): T | undefined;
}
class Store<T> implements Source<T> {
  items: T[] = [];
  first(): T | undefined {
    return this.items[0];
  }
}
function viaNarrowing(c: Source<number>): number {
  let s = 0;
  if (c instanceof Store) {
    for (let r = 0; r < 20; r++) for (let i = 0; i < c.items.length; i++) s += c.items[i];
  }
  return s;
}
function typed(c: Store<number>): number {
  let s = 0;
  for (let r = 0; r < 20; r++) for (let i = 0; i < c.items.length; i++) s += c.items[i];
  return s;
}
const st = new Store<number>();
for (let i = 0; i < 1_000_000; i++) st.items.push(i % 7);
const which = process.argv[2] ?? "both";
let t = Date.now();
if (which !== "typed") console.log("narrowed", viaNarrowing(st));
const t1 = Date.now() - t;
t = Date.now();
if (which !== "narrowed") console.log("typed", typed(st));
const t2 = Date.now() - t;
console.error(`ms narrowed=${t1} typed=${t2}`);
