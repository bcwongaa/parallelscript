// A member array tsc types any[] returned from the narrowed branch (inferred return type
// any[]), then changed by the caller.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function itemsOf(c: Cache<string, number>) {
  if (c instanceof MapLRU) return c.items;
  return [];
}
const m = new MapLRU<string, number>("k", 1);
itemsOf(m).push(2);
console.log(m.items);
