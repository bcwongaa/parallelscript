// Members declared with any in the class itself (not through its type parameters), read
// through an inferred narrowing: the instance's member type is tsc's, so binding one to a
// local must keep the object's own array or map.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  extras: any[] = [];
  bag = new Map<string, any>();
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function uses(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const ex = c.extras;
  ex.push("e");
  const bag = c.bag;
  bag.set("b", 1);
  console.log("in", ex === c.extras, bag === c.bag);
}
const m = new MapLRU<string, number>("k", 1);
uses(m);
console.log("after", m.extras, m.bag.size);
