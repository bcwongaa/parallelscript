// A dynamic local (`const it = c.items` after an inferred narrowing) going on into places a
// dynamic value converts to by a copy: an any[] parameter, a field, an array literal, an
// object literal, a returned value with an inferred any[] type, an annotated any[] local.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Keeper {
  kept: any[] = [];
}
function fillAny(a: any[]): void {
  a.push(1);
}
function pass(c: Cache<string, number>, k: Keeper) {
  if (!(c instanceof MapLRU)) return [];
  const it = c.items;
  fillAny(it);
  k.kept = it;
  k.kept.push(2);
  const arr = [it];
  arr[0].push(3);
  const obj = { it };
  obj.it.push(4);
  const typed: any[] = it;
  typed.push(5);
  return it;
}
const m = new MapLRU<string, number>("k", 0);
pass(m, new Keeper()).push(6);
console.log(m.items);
