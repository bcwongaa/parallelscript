// x: T narrowed by instanceof Box in a generic function, for T = Box<number> and for T = a
// non-generic subclass of Box<number>: the narrowing is `T & Box<any>`.
class Box<T> {
  items: T[] = [];
  constructor(v: T) {
    this.items.push(v);
  }
}
class NumBox extends Box<number> {
  label = "num";
}
function grow<T>(x: T): string {
  if (x instanceof Box) {
    const it = x.items;
    it.push(it[0]);
    return `grew ${x.items.length}`;
  }
  return "other";
}
const a = new Box<number>(1);
const b = new NumBox(2);
console.log(grow(a), grow(b), a.items, b.items);
