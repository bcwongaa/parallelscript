// A member tsc types any[] passed through a generic identity function and an optional any[]
// parameter, after an inferred narrowing, then written through what comes back.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function ident<T>(t: T): T {
  return t;
}
function maybeFill(a?: any[]): void {
  a?.push(3);
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  ident(c.items).push(1);
  const r = ident(c.items);
  r.push(2);
  maybeFill(c.items);
  console.log(c.items);
}
run(new MapLRU<string, number>("k", 0));
