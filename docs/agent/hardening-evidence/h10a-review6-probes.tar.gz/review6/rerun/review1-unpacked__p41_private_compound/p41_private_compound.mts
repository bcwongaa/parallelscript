// Compound and increment writes of a private field on an `unknown` narrowed by instanceof.
class Box<T> {
  #n: number = 0;
  constructor(public v: T) {}
  static bump(o: unknown): unknown {
    if (o instanceof Box) {
      o.#n += 2;
      o.#n++;
      return o.#n;
    }
    return "no";
  }
}
try {
  console.log(Box.bump(new Box<string>("x")));
} catch (e: any) {
  console.log("threw", e.message);
}
