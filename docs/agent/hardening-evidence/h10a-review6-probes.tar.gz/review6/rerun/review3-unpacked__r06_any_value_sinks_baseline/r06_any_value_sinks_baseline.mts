// Baseline (no instanceof): a number[] held as `any` going into an any[] parameter, a field,
// an array literal, an object literal and an annotated any[] local, then written.
class Keeper {
  kept: any[] = [];
}
function fillAny(a: any[]): void {
  a.push(1);
}
const items: number[] = [0];
const it: any = items;
fillAny(it);
const k = new Keeper();
k.kept = it;
k.kept.push(2);
const arr: any[][] = [it];
arr[0].push(3);
const obj: { it: any[] } = { it };
obj.it.push(4);
const typed: any[] = it;
typed.push(5);
console.log(items);
