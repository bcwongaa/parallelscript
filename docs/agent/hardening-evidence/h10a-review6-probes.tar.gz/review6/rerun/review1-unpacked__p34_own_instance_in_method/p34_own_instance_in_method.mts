// Methods of a generic class that make instances of their own class for other type
// arguments mid-body: destructured and defaulted parameters, rest parameters, a closure
// capturing them, a constructor doing it, a static method, a getter and a generic method.
class Box<T> {
  constructor(public val: T, public tag = "t") {
    if (tag === "outer") {
      const inner = new Box<string>("in", "inner");
      this.tag = `${tag}/${inner.tag}/${val}`;
    }
  }
  make({ a, b }: { a: number; b: string }, scale = 2, ...rest: number[]): string {
    const other = new Box<boolean>(true);
    const f = () => a * scale + rest.length;
    const third = new Box<number[]>([a]);
    return `${b}:${f()}:${other.val}:${third.val.length}:${this.val}`;
  }
  get twin(): string {
    const c = new Box<bigint>(1n);
    return `${c.val}-${this.val}`;
  }
  static from(x: number, y = "s"): string {
    const d = new Box<number>(x);
    const e = new Box<string>(y);
    return `${d.val}${e.val}${x}${y}`;
  }
  map<R>(f: (v: T) => R, extra: number): Box<R> {
    const g = new Box<symbol>(Symbol("z"));
    return new Box<R>(f(this.val), `${extra}${typeof g.val}`);
  }
  check(o: object, n: number): string {
    if (o instanceof Box) return `box ${n} ${o.tag}`;
    return `not ${n}`;
  }
}
const b = new Box<number>(7, "outer");
console.log(b.tag, b.make({ a: 3, b: "x" }, undefined, 1, 2), b.twin, Box.from(4));
console.log(b.map((v) => `${v}!`, 9).tag, b.check(new Box<string>("q", "qq"), 1), b.check({}, 2));
