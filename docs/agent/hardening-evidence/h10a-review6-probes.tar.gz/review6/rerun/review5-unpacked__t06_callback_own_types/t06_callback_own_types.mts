// Callback parameters annotated with the instance's own types (number[], a shape of number[])
// on members tsc types with any (inferred narrowing), written through. Node: "true" each.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  groups: { list: V[] }[] = [];
  constructor(public key: K, public val: V) {
    this.matrix.push([val]);
    this.groups.push({ list: [val] });
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function check(name: string, f: (c: Cache<string, number>) => void, seen: (m: MapLRU<string, number>) => boolean): void {
  const m = new MapLRU<string, number>("k", 0);
  f(m);
  console.log(name, seen(m));
}
check("row: number[]", (c) => { if (c instanceof MapLRU) c.matrix.forEach((row: number[]) => row.push(1)); }, (m) => m.matrix[0].length === 2);
check("g: { list: number[] }", (c) => { if (c instanceof MapLRU) c.groups.forEach((g: { list: number[] }) => g.list.push(1)); }, (m) => m.groups[0].list.length === 2);
check("arr: number[][]", (c) => { if (c instanceof MapLRU) c.matrix.forEach((_r, _i, arr: number[][]) => arr.push([9])); }, (m) => m.matrix.length === 2);
