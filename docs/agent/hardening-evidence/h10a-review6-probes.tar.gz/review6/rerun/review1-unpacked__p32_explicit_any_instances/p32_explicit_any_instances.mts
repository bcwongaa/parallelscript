// Explicit Box<any> declarations and unions holding them, narrowed by instanceof, typeof, a
// discriminant, `in`, a type predicate and `as`: none of these is an inferred instance.
class Box<T> {
  readonly kind = "box";
  constructor(public v: T) {}
}
class Other {
  readonly kind = "other";
  w = 1;
}
function a(b: Box<any>): string {
  return b instanceof Box ? `a ${b.v}` : "a-";
}
function b(x: Box<any> | Other): string {
  if (x instanceof Box) return `b ${x.v}`;
  return `b other ${x.w}`;
}
function c(x: Box<any> | Other): string {
  if (x.kind === "box") return `c ${x.v}`;
  return "c-";
}
function d(x: Box<any> | Other): string {
  if ("v" in x) return `d ${x.v}`;
  return "d-";
}
function isBox(x: unknown): x is Box<any> {
  return x instanceof Box;
}
function e(x: Other | Box<any>): string {
  return isBox(x) ? `e ${x.v}` : "e-";
}
function f(x: Box<any> | string): string {
  return typeof x === "string" ? x : `f ${x.v}`;
}
function g(x: Box<any> | undefined): string {
  return x ? `g ${(x as Box<any>).v}` : "g-";
}
const anyBox: Box<any> = new Box<any>("any");
for (const x of [anyBox, new Box<any>(2)]) console.log(a(x), b(x), c(x), d(x), e(x), f(x), g(x));
console.log(b(new Other()), c(new Other()), d(new Other()), e(new Other()), f("s"), g(undefined));
