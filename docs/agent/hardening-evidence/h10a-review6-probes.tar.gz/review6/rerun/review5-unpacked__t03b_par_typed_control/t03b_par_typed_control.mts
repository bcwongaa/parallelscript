// threads: 1 2 4
// Control for t03 without instanceof: `.map` over a typed number[][] whose callback
// writes to its row.
const rows: number[][] = [];
for (let i = 0; i < 64; i++) rows.push([i, i + 1]);
const anyRows: any[][] = [];
for (let i = 0; i < 64; i++) anyRows.push([i, i + 1]);
const lens = rows.map((row) => {
  row.push(0);
  return row.length;
});
const anyLens = anyRows.map((row) => {
  row.push(0);
  return row.length;
});
console.log(lens.reduce((a, b) => a + b, 0), rows[63].length, anyLens.reduce((a, b) => a + b, 0), anyRows[63].length);
