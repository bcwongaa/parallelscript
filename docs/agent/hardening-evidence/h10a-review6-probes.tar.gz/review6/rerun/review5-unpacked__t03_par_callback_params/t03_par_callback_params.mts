// threads: 1 2 4
// `.par` callbacks over members tsc types with any (inferred narrowing), whose parameters
// fix5 treats as dynamic locals: elements that are arrays, written through, and read.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  rows: V[][] = [];
  items: V[] = [];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  for (let i = 0; i < 64; i++) {
    c.rows.push([i, i + 1]);
    c.items.push(i);
  }
  const sums = c.rows.map((row) => row[0] + row[1]);
  console.log(sums.reduce((a, b) => a + b, 0));
  const lens = c.rows.map((row) => {
    row.push(0);
    return row.length;
  });
  console.log(lens.reduce((a, b) => a + b, 0), c.rows[63].length);
  const scaled = c.items.map((x, i) => x * 2 + i);
  console.log(scaled[63]);
}
run(new MapLRU<string, number>("k", 0));
