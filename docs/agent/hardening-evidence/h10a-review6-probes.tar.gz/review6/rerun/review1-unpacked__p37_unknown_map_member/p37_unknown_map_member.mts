// x: unknown narrowed to Box<any>: uses of its Map and tuple members, which H10a keeps as the
// object's own (dynamic) values instead of converted copies.
class Box<T> {
  index = new Map<string, T>();
  pair: [string, T];
  constructor(v: T) {
    this.index.set("first", v);
    this.pair = ["p", v];
  }
}
function takeMap(m: Map<string, number>): number {
  return m.size;
}
function uses(x: unknown): void {
  if (!(x instanceof Box)) return;
  for (const [k, v] of x.index) console.log("1", k, v);
  x.index.forEach((v, k) => console.log("2", k, v));
  console.log("3", [...x.index.keys()], x.index.get("first") + 1, x.index.has("first"));
  console.log("4", new Map(x.index).size, takeMap(x.index));
  const [a, b] = x.pair;
  console.log("5", a, b, x.pair.length, x.pair[1] * 2);
  x.pair[1] = 99;
  x.index.delete("first");
  console.log("6", x.pair, x.index.size);
}
const b = new Box<number>(7);
uses(b);
console.log("after", b.pair, b.index.size);
