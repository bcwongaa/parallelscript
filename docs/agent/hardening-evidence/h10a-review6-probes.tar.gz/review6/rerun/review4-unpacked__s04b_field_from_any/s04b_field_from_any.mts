// A member tsc types any[] (and a dynamic local holding it) going through super(), a field
// initializer and a static field, after an inferred narrowing. Node: every line "true".
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Base {
  constructor(public kept: any[]) {}
}
let pending: any = [];
class Later {
  kept: any[] = pending;
}
function check(name: string, f: (m: MapLRU<string, number>) => void): void {
  const m = new MapLRU<string, number>("k", 0);
  try {
    f(m);
    console.log(name, m.items.length > 1);
  } catch (e: any) {
    console.log(name, "threw", e.message);
  }
}
check("field initializer from any", (m) => {
  const c: Cache<string, number> = m;
  if (c instanceof MapLRU) {
    const it = c.items;
    pending = it;
    new Later().kept.push(1);
  }
});
