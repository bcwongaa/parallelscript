// MapLRU<any, any> objects held at interface places: Cache<string, number> and Cache<any, any>.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function viaAnyCache(c: Cache<any, any>): string {
  if (c instanceof MapLRU) return `any ${c.key} ${c.val} ${c.get(c.key)}`;
  return "other";
}
const raw: any = JSON.parse('["k", 3]');
const anyLRU = new MapLRU(raw[0], raw[1]); // MapLRU<any, any>
console.log(viaAnyCache(anyLRU));
console.log(viaAnyCache(new MapLRU<string, number>("s", 1)));
function viaTyped(c: Cache<string, number>): string {
  if (c instanceof MapLRU) return `typed ${c.key} ${c.val}`;
  return "other";
}
console.log(viaTyped(anyLRU));
