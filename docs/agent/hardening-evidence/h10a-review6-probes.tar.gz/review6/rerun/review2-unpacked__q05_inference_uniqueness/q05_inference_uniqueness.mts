// Declared types whose members don't tell instances apart: Cache<string, number> (get
// returns V | undefined) holding a MapLRU<string, number | undefined>; literal-union and
// enum keys (Cache<"a" | "b", 1 | 2>, Cache<Color, number>).
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
enum Color {
  Red = "red",
  Blue = "blue",
}
function viaOptional(c: Cache<string, number>): string {
  return c instanceof MapLRU ? `optional ${c.key} ${c.val}` : "other";
}
function viaLiterals(c: Cache<"a" | "b", 1 | 2>): string {
  return c instanceof MapLRU ? `literals ${c.key} ${c.val + 1}` : "other";
}
function viaEnum(c: Cache<Color, number>): string {
  return c instanceof MapLRU ? `enum ${c.key} ${c.val * 2}` : "other";
}
const maybe: Cache<string, number> = new MapLRU<string, number | undefined>("m", undefined);
const fs = [
  () => viaOptional(maybe),
  () => viaOptional(new MapLRU<string, number>("n", 1)),
  () => viaLiterals(new MapLRU<"a" | "b", 1 | 2>("a", 2)),
  () => viaEnum(new MapLRU<Color, number>(Color.Blue, 3)),
];
for (const f of fs) {
  try {
    console.log(f());
  } catch (e: any) {
    console.log("threw", e.message);
  }
}
