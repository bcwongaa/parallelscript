// Callbacks given by reference (a function declaration, a const arrow, a method of an object)
// to array methods of a member tsc types with any (inferred narrowing), writing through
// their array parameter. Node: every line "true".
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  constructor(public key: K, public val: V) {
    this.items.push(val);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function pushOne(_x: any, _i: number, arr: any[]): void {
  arr.push(1);
}
const pushTwo = (_x: any, _i: number, arr: any[]) => {
  arr.push(2);
};
const keeper = {
  push(_x: any, _i: number, arr: any[]): void {
    arr.push(3);
  },
};
function check(name: string, f: (c: Cache<string, number>) => void): void {
  const m = new MapLRU<string, number>("k", 0);
  f(m);
  console.log(name, m.items.length === 2);
}
check("function declaration", (c) => { if (c instanceof MapLRU) c.items.forEach(pushOne); });
check("const arrow", (c) => { if (c instanceof MapLRU) c.items.forEach(pushTwo); });
check("object method", (c) => { if (c instanceof MapLRU) c.items.forEach(keeper.push); });
check("function expression", (c) => { if (c instanceof MapLRU) c.items.forEach(function (_x, _i, arr) { arr.push(4); }); });
