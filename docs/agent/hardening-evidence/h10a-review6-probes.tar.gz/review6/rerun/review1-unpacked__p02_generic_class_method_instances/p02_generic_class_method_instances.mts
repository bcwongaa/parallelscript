// A generic class's method narrows a parameter of its own type parameters' interface: each
// class instance (Holder<string, number>, Holder<number, string>) has its own declared type.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
class Holder<K, V> {
  constructor(public c: Cache<K, V>) {}
  show(): string {
    if (this.c instanceof MapLRU) return `${typeof this.c.key}:${this.c.key} ${typeof this.c.val}:${this.c.val}`;
    return "other";
  }
}
console.log(new Holder(new MapLRU<string, number>("a", 1)).show());
console.log(new Holder(new MapLRU<number, string>(2, "b")).show());
