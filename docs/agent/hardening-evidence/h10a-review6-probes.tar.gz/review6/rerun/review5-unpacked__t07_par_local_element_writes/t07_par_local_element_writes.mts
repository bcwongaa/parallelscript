// threads: 1 2 4
// `.map` over a dynamic local holding a member tsc types any[][] (inferred narrowing),
// whose callback writes to its row; and `.filter` doing the same.
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  rows: V[][] = [];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  for (let i = 0; i < 32; i++) c.rows.push([i]);
  const rows = c.rows;
  rows.map((row) => row.push(1));
  c.rows.filter((row) => row.push(2) > 0);
  console.log(c.rows[0], c.rows[31]);
}
run(new MapLRU<string, number>("k", 0));
