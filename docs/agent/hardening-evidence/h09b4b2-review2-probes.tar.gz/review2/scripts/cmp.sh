#!/bin/bash
# usage: cmp.sh file.pts -> node / snap2 / snap1 / base outputs
f="$1"; name=$(basename "$f" .pts); d=/tmp/h09b4b2/review2
out=$d/out/$name; mkdir -p $out
cp "$f" $out/$name.mts
( cd $out && TZ=America/New_York timeout 20 ~/.local/node/bin/node --no-warnings --experimental-transform-types $name.mts > node.txt 2>&1; echo "exit=$?" >> node.txt )
for which in snap2 snap1 base; do
  case $which in snap2) home=/tmp/h09b4b2/s/snap2;; snap1) home=/tmp/h09b4b2/s/snap1;; base) home=/tmp/h09b4b2/base;; esac
  if [ -n "$ONLY2" ] && [ $which != snap2 ]; then continue; fi
  bin=$d/bin/$name.$which.bin
  PTS_HOME=$home timeout 300 $home/pts-bin/pts build "$f" -o $bin > $out/$which.txt 2>&1
  rc=$?
  if [ $rc -eq 0 ]; then
    ( cd $out && TZ=America/New_York timeout 20 $bin >> $out/$which.txt 2>&1; echo "exit=$?" >> $out/$which.txt )
  else
    echo "BUILD exit=$rc" >> $out/$which.txt
  fi
  rm -f $bin
done
if [ -z "$QUIET" ]; then for which in node snap2 snap1 base; do [ -f $out/$which.txt ] && { echo "=== $which"; cat $out/$which.txt; }; done; fi
s2=$(cat $out/snap2.txt); n=$(cat $out/node.txt); b=$(cat $out/base.txt 2>/dev/null)
st="snap2"; [ "$s2" = "$n" ] && st="$st=node"; [ "$s2" = "$b" ] && st="$st=base"
echo "SUMMARY $name $st"
