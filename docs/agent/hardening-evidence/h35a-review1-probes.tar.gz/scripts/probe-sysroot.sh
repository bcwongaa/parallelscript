#!/bin/bash
# R1-F2: PTS_SYSROOT set to what the help calls the default breaks the link; a bogus sysroot is ignored by clang.
cd /tmp/h35s/review1/sysroot
printf '#include <stdio.h>\n#include <math.h>\nint main(void){printf("%%f\\n", sqrt(2.0));return 0;}\n' > s.c
for s in "" /usr/aarch64-linux-gnu / /nonexistent; do echo "--- sysroot=[$s]"; clang --target=aarch64-linux-gnu ${s:+--sysroot=$s} s.c -o s.out -lm 2>&1 | head -3; echo "exit=${PIPESTATUS[0]}"; done
. /tmp/h35s/review1/scripts/env.sh; cd /tmp/h35s/review1/p
PTS_SYSROOT=/usr/aarch64-linux-gnu taskset -c 6,7 $P build hello.pts --target aarch64-linux -o hs > out.txt 2> err.txt; echo "pts exit=$?"; tail -c 400 err.txt
