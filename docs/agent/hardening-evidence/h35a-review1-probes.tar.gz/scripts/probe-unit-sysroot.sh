#!/bin/bash
# R1-F3: a unit test that fails when the developer has PTS_SYSROOT set.
cd /tmp/h35s/wt-x && PTS_SYSROOT=/opt/my-arm-root taskset -c 6,7 go test -count=1 -p 1 -run '^TestOtherTargetPassesItsTripleAndSysroot$' ./pts/toolchain/
