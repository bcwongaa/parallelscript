#!/bin/bash
# R1-F9 (pre-existing, base too): String() of a 2,000,000-deep nested array overflows the C stack (SIGSEGV); Node: RangeError.
cd /tmp/h35s/review1/stack
PTS_HOME=/tmp/h35s/wt-ci PTS_CACHE_DIR=/tmp/h35s/review1/cache-base taskset -c 6,7 /tmp/h35s/wt-ci/pts-bin/pts build j3.pts -o j3-base && { taskset -c 6,7 ./j3-base; echo "base exit=$?"; }
. /tmp/h35s/review1/scripts/env.sh
taskset -c 6,7 $P build j3.pts --target aarch64-linux -o j3-arm && { taskset -c 6,7 $QEMU ./j3-arm; echo "arm exit=$?"; }
cp j3.pts j3.mts; ~/.local/node/bin/node j3.mts; echo "node exit=$?"
rm -f j3-base j3-arm
