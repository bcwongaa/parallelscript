#!/bin/bash
# The host's vendored archive keys are those of the base CLI (wt-ci = 2baeba1d0 + tests).
cd /tmp/h35s/review1/p
PTS_HOME=/tmp/h35s/wt-ci PTS_CACHE_DIR=/tmp/h35s/review1/cache-base taskset -c 6,7 /tmp/h35s/wt-ci/pts-bin/pts build hello.pts -o hb
ls /tmp/h35s/review1/cache-base | grep -v lock | sort > /tmp/h35s/review1/keys-base.txt
ls /tmp/h35s/review1/cache | grep -v lock | sort > /tmp/h35s/review1/keys-new.txt
comm -12 /tmp/h35s/review1/keys-base.txt /tmp/h35s/review1/keys-new.txt
