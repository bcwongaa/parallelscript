typedef int (*fp)(int);
static long g(long x, long y) { return x + y; }
int main(void) {
  fp f = g;                 /* incompatible function pointer types: DefaultError in clang 16+ */
  int *p = 5;               /* int-conversion: DefaultError */
  return h(3) + f(1) + *p;  /* implicit function declaration: error in C99+ by default */
}
