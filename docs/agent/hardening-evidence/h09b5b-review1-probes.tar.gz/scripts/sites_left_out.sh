#!/bin/bash
# sites_left_out.sh file...: for each program, build with the debug CLI at AllInstances (0) and
# ValueInstances (1) with every call site left out (PTS_FORCE_LEAVE_SITES), and at
# DeclaredInstances (2); run each and compare outputs with the DeclaredInstances run.
out=/tmp/h09b5b/review1/out/sites; mkdir -p $out
for f in "$@"; do
  name=$(basename $f .pts)
  for mode in 2 0 1; do
    env_extra=""; [ $mode != 2 ] && env_extra="PTS_FORCE_LEAVE_SITES=1"
    bin=$out/$name.$mode.bin
    ( cd $(dirname $f) && env PTS_HOME=/tmp/h09b5b/snap-a PTS_FORCE_SPEC=$mode $env_extra timeout 300 /tmp/h09b5b/review1/pts-debug build $f -o $bin ) > $out/$name.$mode.build.txt 2>&1
    if [ -f $bin ]; then ( cd $(dirname $f) && timeout 20 $bin ) > $out/$name.$mode.out.txt 2>&1; echo "exit=$?" >> $out/$name.$mode.out.txt; rm -f $bin; else echo "BUILD FAILED" > $out/$name.$mode.out.txt; fi
  done
  for mode in 0 1; do
    if cmp -s $out/$name.2.out.txt $out/$name.$mode.out.txt; then r=same; else r=DIFF; fi
    echo "$name mode=$mode vs declared: $r $(head -c 200 $out/$name.$mode.build.txt | tr '\n' ' ')"
  done
done
