#!/bin/bash
# sites_left_out_vs_value.sh file: emit-c with the debug CLI at AllInstances with every call site
# left out (PTS_FORCE_LEAVE_SITES) and at plain ValueInstances; report where the first fails to
# compile (or crashes) and the second compiles.
f=$1; name=$(basename $f .pts); out=/tmp/h09b5b/review1/out/sweep; mkdir -p $out
cd $(dirname $f)
PTS_HOME=/tmp/h09b5b/snap-a PTS_FORCE_SPEC=0 PTS_FORCE_LEAVE_SITES=1 timeout 300 /tmp/h09b5b/review1/pts-debug emit-c $f > /dev/null 2> $out/$name.left.txt; a=$?
PTS_HOME=/tmp/h09b5b/snap-a PTS_FORCE_SPEC=1 timeout 300 /tmp/h09b5b/review1/pts-debug emit-c $f > /dev/null 2> $out/$name.value.txt; b=$?
echo "$name left=$a value=$b $( [ $a != 0 ] && [ $b == 0 ] && echo REGRESS; [ $a == 3 ] && echo CRASH) $(head -c 160 $out/$name.left.txt | tr '\n' ' ')"
