	.text
	.file	"a.c"
	.globl	fib_frame                       // -- Begin function fib_frame
	.p2align	2
	.type	fib_frame,@function
fib_frame:                              // @fib_frame
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset b8, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB0_4
// %bb.1:
	fmov	d1, #2.00000000
	fcmp	d0, d1
	b.mi	.LBB0_3
// %bb.2:
	fmov	d1, #-1.00000000
	fmov	d8, d0
	fadd	d1, d0, d1
	fmov	d0, d1
	bl	fib_frame
	fmov	d1, #-2.00000000
	fadd	d1, d8, d1
	fmov	d8, d0
	fmov	d0, d1
	bl	fib_frame
	fadd	d0, d8, d0
.LBB0_3:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB0_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end0:
	.size	fib_frame, .Lfunc_end0-fib_frame
	.cfi_endproc
                                        // -- End function
	.globl	fib_sp                          // -- Begin function fib_sp
	.p2align	2
	.type	fib_sp,@function
fib_sp:                                 // @fib_sp
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset b8, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	//APP
	mov	x9, sp
	//NO_APP
	cmp	x9, x8
	b.lo	.LBB1_4
// %bb.1:
	fmov	d1, #2.00000000
	fcmp	d0, d1
	b.mi	.LBB1_3
// %bb.2:
	fmov	d1, #-1.00000000
	fmov	d8, d0
	fadd	d1, d0, d1
	fmov	d0, d1
	bl	fib_sp
	fmov	d1, #-2.00000000
	fadd	d1, d8, d1
	fmov	d8, d0
	fmov	d0, d1
	bl	fib_sp
	fadd	d0, d8, d0
.LBB1_3:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB1_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end1:
	.size	fib_sp, .Lfunc_end1-fib_sp
	.cfi_endproc
                                        // -- End function
	.globl	leaf_frame                      // -- Begin function leaf_frame
	.p2align	2
	.type	leaf_frame,@function
leaf_frame:                             // @leaf_frame
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB2_2
// %bb.1:
	fadd	d0, d0, d0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB2_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end2:
	.size	leaf_frame, .Lfunc_end2-leaf_frame
	.cfi_endproc
                                        // -- End function
	.globl	leaf_sp                         // -- Begin function leaf_sp
	.p2align	2
	.type	leaf_sp,@function
leaf_sp:                                // @leaf_sp
	.cfi_startproc
// %bb.0:
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	//APP
	mov	x9, sp
	//NO_APP
	cmp	x9, x8
	b.lo	.LBB3_2
// %bb.1:
	fadd	d0, d0, d0
	ret
.LBB3_2:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_throw_stack_overflow
.Lfunc_end3:
	.size	leaf_sp, .Lfunc_end3-leaf_sp
	.cfi_endproc
                                        // -- End function
	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
