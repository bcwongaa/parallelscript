#include <stdint.h>
extern _Thread_local uintptr_t pts_stack_limit;
_Noreturn void pts_throw_stack_overflow(void);
static inline void check_frame(void) {
  if (__builtin_expect((uintptr_t)__builtin_frame_address(0) < pts_stack_limit, 0)) pts_throw_stack_overflow();
}
static inline void check_sp(void) {
  uintptr_t sp;
  __asm__("mov %0, sp" : "=r"(sp));
  if (__builtin_expect(sp < pts_stack_limit, 0)) pts_throw_stack_overflow();
}
double fib_frame(double n) { check_frame(); return n < 2 ? n : fib_frame(n - 1) + fib_frame(n - 2); }
double fib_sp(double n) { check_sp(); return n < 2 ? n : fib_sp(n - 1) + fib_sp(n - 2); }
double leaf_frame(double n) { check_frame(); return n * 2; }
double leaf_sp(double n) { check_sp(); return n * 2; }
