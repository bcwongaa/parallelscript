// Probe (item 9, one loop, plain TypeScript): a timer set after 300 ms of synchronous work
// at the top level, and one set in a timer callback after 300 ms of work. Node counts each
// from the time it was set (getLibuvNow updates libuv's time first).
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {
    // busy
  }
}
function waitFrom(ms: number): Promise<number> {
  const start = performance.now();
  return new Promise((resolve) => setTimeout(() => resolve(Math.round(performance.now() - start)), ms));
}
spin(300);
const top = await waitFrom(200);
console.log("top level, 200 ms timer after 300 ms of work fired after at least 195:", top >= 195, top);
const inCallback = await new Promise<number>((resolve) =>
  setTimeout(() => {
    spin(300);
    void waitFrom(200).then(resolve);
  }, 1),
);
console.log("in a callback, 200 ms timer after 300 ms of work fired after at least 195:", inCallback >= 195, inCallback);
