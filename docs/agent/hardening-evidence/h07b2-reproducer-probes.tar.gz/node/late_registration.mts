// Probe (pre-existing, one thread): a test registered after the runner has finished. Node
// runs "a" and "b" once each and prints one summary at the end.
import { test } from "node:test";

test("a", () => {
  console.log("running a");
});
await new Promise((resolve) => setTimeout(resolve, 200));
test("b", () => {
  console.log("running b");
});
