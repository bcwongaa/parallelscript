// Probe (C120, risk: CPU while sleeping): three tasks each leave a 1 ms interval on their loop,
// unref'd unless REFERENCED; the main loop waits 2 s with a referenced timer, then clears them.
// Measure user+system CPU from outside (/usr/bin/time). cpu_interval_ref.pts: referenced.
const REFERENCED = false;
const counts = { ticks: 0 };
function leave(): ReturnType<typeof setInterval> {
  const interval = setInterval(() => {
    counts.ticks++;
  }, 1);
  if (!REFERENCED) {
    interval.unref();
  }
  return interval;
}
const hold = setTimeout(() => {}, 10_000);
const intervals = await Promise.all([0, 1, 2].map(() => Promise.resolve(leave())));
await new Promise((resolve) => setTimeout(resolve, 2_000));
for (const interval of intervals) {
  clearInterval(interval);
}
clearTimeout(hold);
console.log("ticks:", counts.ticks);
