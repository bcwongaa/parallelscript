// Probe (item 9, one loop, plain TypeScript): timers set in one synchronous stretch with
// work between them. Node: each is due its delay after it was set (a, due at 3 ms, before
// b, set after 20 ms of work with 1 ms). Also at the top level and in a callback.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {
    // busy
  }
}
const order: string[] = [];
setTimeout(() => order.push("a"), 3);
spin(20);
setTimeout(() => order.push("b"), 1);
await new Promise((resolve) => setTimeout(resolve, 50));
console.log("top level:", order.join(","));
order.length = 0;
await new Promise<void>((resolve) =>
  setTimeout(() => {
    setTimeout(() => order.push("c"), 3);
    spin(20);
    setTimeout(() => order.push("d"), 1);
    setTimeout(resolve, 50);
  }, 1),
);
console.log("in a callback:", order.join(","));
