"""compare_final.py: for each deliverable test in /tmp/h07b2/repro/final, compares each base run
(3 per thread count) and each Node twin run with the test's `// expect:` block, and prints
the exit code, wall time and whether the output matched; distinct mismatching outputs are
shown once each."""
import glob
import os
import re

root = "/tmp/h07b2/repro/final"
directive = re.compile(r"^//\s*(expect|exit|stderr|error|no-diff|skip|threads):\s?(.*)$")


def expected(path):
    lines = open(path, encoding="utf-8").read().split("\n")
    for i, line in enumerate(lines):
        if line.strip() == "// expect:":
            out = []
            for text in lines[i + 1:]:
                t = text.strip()
                if not t.startswith("//") or directive.match(t):
                    break
                body = t[2:]
                out.append(body[1:] if body.startswith(" ") else body)
            return "\n".join(out) + "\n"
    return None


for src in sorted(glob.glob(f"{root}/src/*.pts")):
    name = os.path.basename(src)[:-4]
    want = expected(src)
    print(f"== {name}")
    shown = set()
    for threads in ("1", "2", "4"):
        cells = []
        for run in ("1", "2", "3"):
            base = f"{root}/out/{name}.t{threads}.r{run}"
            got = open(base + ".stdout", encoding="utf-8").read()
            code, ms = open(base + ".meta").read().split()
            ok = got == want
            cells.append(f"{'match' if ok else 'DIFF'}(exit {code}, {ms} ms)")
            if not ok and got not in shown:
                shown.add(got)
                print(f"   threads={threads} run={run} output:")
                for line in got.splitlines()[:12]:
                    print(f"     | {line}")
                if len(got.splitlines()) > 12:
                    print(f"     | ... {len(got.splitlines())} lines")
        print(f"   threads={threads}: " + ", ".join(cells))
    nodes = sorted(glob.glob(f"{root}/node/{name}.node.r*.out"))
    if nodes:
        verdicts = ["match" if open(n, encoding="utf-8").read() == want else "DIFF" for n in nodes]
        print(f"   node: {', '.join(verdicts)}")
