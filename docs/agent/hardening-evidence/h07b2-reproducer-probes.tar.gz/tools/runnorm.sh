#!/bin/bash
# runnorm.sh name threads runs [timeout_s]: like runn.sh, but prints stdout with the spec
# reporter's durations as N (and drops its constant summary lines), for pts:test probes.
set -uo pipefail
name=$1; threads=$2; runs=$3; to=${4:-20}
bindir=${BINDIR:-/tmp/h07b2/repro/bin}
outdir=${OUTDIR:-/tmp/h07b2/repro/out}
for i in $(seq 1 "$runs"); do
  o="$outdir/$name.t$threads.r$i"
  s=$(date +%s%N)
  PTS_THREADS=$threads timeout -k 2 "$to" "$bindir/$name" > "$o.stdout" 2> "$o.stderr"
  rc=$?
  e=$(date +%s%N)
  echo "$rc $(( (e - s) / 1000000 ))" > "$o.meta"
  echo "--- $name threads=$threads run=$i exit=$rc wall_ms=$(( (e - s) / 1000000 ))"
  sed -E -e 's/\([0-9.]+ms\)/(Nms)/' -e 's/duration_ms [0-9.]+/duration_ms N/' "$o.stdout" | grep -v -e '^ℹ cancelled' -e '^ℹ skipped' -e '^ℹ todo' -e '^ℹ duration'
  if [ -s "$o.stderr" ]; then echo "[stderr]"; head -8 "$o.stderr"; fi
done
