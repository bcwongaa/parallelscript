#!/bin/bash
# summarize_runner.sh name threads runs: for runs kept by runnorm.sh, prints the exit code,
# the count of "hook ... ran" lines, and the other lines with durations as N, collapsing
# repeated identical lines into "line x count".
set -uo pipefail
name=$1; threads=$2; runs=$3
outdir=${OUTDIR:-/tmp/h07b2/repro/out}
for i in $(seq 1 "$runs"); do
  o="$outdir/$name.t$threads.r$i"
  echo "--- $name threads=$threads run=$i exit/wall=$(cat "$o.meta") hook_lines=$(grep -c 'hook registered off the main thread ran' "$o.stdout")"
  grep -v 'hook registered off the main thread ran' "$o.stdout" | sed -E -e 's/\([0-9.]+ms\)/(Nms)/' -e 's/duration_ms [0-9.]+/duration_ms N/' \
    | grep -v -e '^ℹ cancelled' -e '^ℹ skipped' -e '^ℹ todo' -e '^ℹ duration' | uniq -c | sed -E 's/^ +1 //; s/^ +([0-9]+) (.*)$/\2  [x\1]/' | head -40
  if [ -s "$o.stderr" ]; then echo "[stderr]"; head -5 "$o.stderr"; fi
done
