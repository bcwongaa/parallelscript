#!/bin/bash
# runn.sh name threads runs [timeout_s]: runs $BINDIR/<name> `runs` times at PTS_THREADS=threads;
# prints the exit code, wall ms and stdout of each run; keeps them in $OUTDIR.
set -uo pipefail
name=$1; threads=$2; runs=$3; to=${4:-20}
bindir=${BINDIR:-/tmp/h07b2/repro/bin}
outdir=${OUTDIR:-/tmp/h07b2/repro/out}
for i in $(seq 1 "$runs"); do
  o="$outdir/$name.t$threads.r$i"
  s=$(date +%s%N)
  PTS_THREADS=$threads timeout -k 2 "$to" "$bindir/$name" > "$o.stdout" 2> "$o.stderr"
  rc=$?
  e=$(date +%s%N)
  ms=$(( (e - s) / 1000000 ))
  echo "$rc $ms" > "$o.meta"
  echo "--- $name threads=$threads run=$i exit=$rc wall_ms=$ms"
  cat "$o.stdout"
  if [ -s "$o.stderr" ]; then echo "[stderr]"; head -5 "$o.stderr"; fi
done
