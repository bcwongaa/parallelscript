"""registry_summary.py out.txt...: summarizes pts:test spec-reporter output of the C117 probes.

For each file: runner starts (summaries), "tests N" values, test lines run, test lines whose
name says another suite than the heading they ran under, test lines at the root, and
suites run, so a run can be compared with Node's single run.
"""
import re
import sys

suite_head = re.compile(r"^(\s*)▶ (.*)$")
test_line = re.compile(r"^(\s*)[✔✖﹣] (.*?) \(\d+(?:\.\d+)?ms\)")
for path in sys.argv[1:]:
    stack = []  # (indent, name)
    summaries, totals, tests, misfiled, at_root, suites = 0, [], 0, 0, 0, 0
    for line in open(path, encoding="utf-8"):
        line = line.rstrip("\n")
        m = suite_head.match(line)
        if m:
            indent = len(m.group(1))
            while stack and stack[-1][0] >= indent:
                stack.pop()
            stack.append((indent, m.group(2)))
            suites += 1
            continue
        if line.startswith("ℹ tests "):
            summaries += 1
            totals.append(int(line.split()[-1]))
            stack = []
            continue
        m = test_line.match(line)
        if m:
            indent = len(m.group(1))
            name = m.group(2)
            while stack and stack[-1][0] >= indent:
                stack.pop()  # the line that ends a suite, or a test after it
            if name.startswith("suite ") and " test " in name:
                tests += 1
                owner = name.split(" test ")[0]
                if not stack:
                    at_root += 1
                elif stack[-1][1] != owner:
                    misfiled += 1
            elif not stack and name.startswith("main"):
                tests += 1
    print(f"{path}: starts={summaries} totals={totals} test_lines={tests} misfiled={misfiled} at_root={at_root} suite_headings={suites}")
