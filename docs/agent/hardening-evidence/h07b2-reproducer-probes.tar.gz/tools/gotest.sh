#!/bin/bash
# gotest.sh WORKTREE OUT PACKAGE RUN_PATTERN: runs `go test PACKAGE -run RUN_PATTERN` in WORKTREE (GOMAXPROCS=2, no PTS_HOME); output in OUT.
set -uo pipefail
wt=$1; out=$2; pkg=$3; pattern=$4
unset PTS_HOME
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2
cd "$wt" || exit 2
s=$(date +%s)
timeout 1500 go test "$pkg" -run "$pattern" -count=1 -v > "$out" 2>&1
rc=$?
echo "go test exit $rc after $(( $(date +%s) - s )) s" >> "$out"
exit $rc
