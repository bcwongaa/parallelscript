#!/bin/bash
# gdbbt.sh threads exe: runs exe under gdb at PTS_THREADS=threads and prints the crashing thread's backtrace.
set -uo pipefail
threads=$1; exe=$2
PTS_THREADS=$threads timeout 60 gdb -q -batch -ex "handle SIGPWR SIGXCPU SIG32 SIG33 SIG34 SIG35 SIG36 nostop noprint pass" -ex run -ex "bt 25" -ex "info registers rip" "$exe" 2>&1 | grep -v "^\[New Thread\|^\[Thread .* exited\|^\[Inferior" | tail -45
