#!/bin/bash
# final.sh: builds the deliverable run tests (copied from the reproducer's worktree) with the
# base compiler and runs each 3 times at PTS_THREADS 1, 2 and 4; then the Node twins of the
# ones Node can run. Everything goes to /tmp/h07b2/repro/final/.
set -uo pipefail
wt=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3f0dbcfb2085c7a7
root=/tmp/h07b2/repro/final
mkdir -p "$root/src" "$root/bin" "$root/out" "$root/node"
tests="timers_unref_sleeping_loops timers_unref_program_end timers_count_from_when_set timers_after_sleep pts_test_registry_threads"
for n in $tests; do cp "$wt/pts/tests/run/$n.pts" "$root/src/"; done
grep -v '^// skip:' "$wt/pts/tests/run/abort_timeouts_sleeping_loops.pts" > "$root/src/abort_timeouts_sleeping_loops.pts"
tests="$tests abort_timeouts_sleeping_loops"
for n in $tests; do
  BINDIR=$root/bin /tmp/h07b2/repro/tools/build.sh "$root/src/$n.pts" || exit 1
done
for n in $tests; do
  for t in 1 2 4; do
    BINDIR=$root/bin OUTDIR=$root/out /tmp/h07b2/repro/tools/runn.sh "$n" "$t" 3 30 > "$root/out/$n.t$t.log" 2>&1
  done
done
# Node twins: `parallel X` -> `Promise.resolve(X)` for the call forms these tests use.
for n in timers_unref_sleeping_loops timers_unref_program_end timers_after_sleep abort_timeouts_sleeping_loops; do
  sed -E -e 's/await parallel ([a-zA-Z]+\([^)]*\))/await Promise.resolve(\1)/' \
    -e 's/=> parallel ([a-zA-Z.]+\([^)]*\))\)/=> Promise.resolve(\1))/' \
    -e 's/= parallel work\(300, \(\) => markStarted\(\)\)/= Promise.resolve(work(300, () => markStarted()))/' \
    "$root/src/$n.pts" > "$root/node/$n.mts"
done
cp "$root/src/timers_count_from_when_set.pts" "$root/node/timers_count_from_when_set.mts"
for n in timers_unref_sleeping_loops timers_unref_program_end timers_after_sleep abort_timeouts_sleeping_loops timers_count_from_when_set; do
  left=$(grep -v '^ *//' "$root/node/$n.mts" | grep -c '\bparallel ')
  for i in 1 2 3; do
    timeout 30 "$HOME/.local/node/bin/node" --no-warnings --experimental-transform-types "$root/node/$n.mts" > "$root/node/$n.node.r$i.out" 2> "$root/node/$n.node.r$i.err"
    echo "node $n run $i exit $? (parallel left in twin: $left)" >> "$root/node/summary.txt"
  done
done
echo done
