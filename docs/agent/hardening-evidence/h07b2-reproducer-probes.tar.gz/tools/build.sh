#!/bin/bash
# build.sh file.pts...: builds each with the base compiler into $BINDIR/<name> (default /tmp/h07b2/repro/bin).
# COMPILER and PTSHOME override the compiler and runtime (default: the parent's base worktree).
set -uo pipefail
pts=${COMPILER:-/tmp/h07b2/base/pts-bin/pts}
home=${PTSHOME:-/tmp/h07b2/base}
bindir=${BINDIR:-/tmp/h07b2/repro/bin}
rc=0
for f in "$@"; do
  n=$(basename "$f" .pts)
  PTS_HOME=$home "$pts" build "$f" -o "$bindir/$n" > "$bindir/$n.build.txt" 2>&1
  r=$?
  echo "build $n exit $r"
  if [ $r -ne 0 ]; then cat "$bindir/$n.build.txt"; rc=1; fi
done
exit $rc
