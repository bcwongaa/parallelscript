#!/bin/bash
# ctest.sh WORKTREE OUT [RUN_PATTERN]: runs the runtime's C tests that match RUN_PATTERN
# (default: scheduler_test.c under TSan and under ASan/UBSan) in WORKTREE; output in OUT.
set -uo pipefail
wt=$1; out=$2
pattern=${3:-'TestThreadedRuntimeTestsPassUnderThreadSanitizer/scheduler_test.c|TestRuntimeUnitTestsPassUnderSanitizers/scheduler_test.c'}
unset PTS_HOME
export PATH="$HOME/.local/go/bin:$PATH" GOMAXPROCS=2
cd "$wt" || exit 2
s=$(date +%s)
timeout 1500 go test ./pts/toolchain -run "$pattern" -count=1 -v > "$out" 2>&1
rc=$?
echo "go test exit $rc after $(( $(date +%s) - s )) s" >> "$out"
exit $rc
