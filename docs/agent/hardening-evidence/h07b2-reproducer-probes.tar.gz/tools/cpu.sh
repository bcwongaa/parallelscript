#!/bin/bash
# cpu.sh threads exe [args...]: runs exe at PTS_THREADS=threads under /usr/bin/time; prints its stdout and user/sys/wall.
set -uo pipefail
threads=$1; shift
PTS_THREADS=$threads /usr/bin/time -f "user %U s sys %S s wall %e s maxrss %M KB" "$@"
