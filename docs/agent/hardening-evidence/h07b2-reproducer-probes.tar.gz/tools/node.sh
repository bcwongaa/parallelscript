#!/bin/bash
# node.sh file.pts [twin.mts]: runs the sequential twin under Node 24 and prints its exit code, wall ms and output.
# Without a twin it makes one: pts:test -> node:test, pts:assert -> node:assert/strict,
# `parallel X` (up to the end of the line's expression, a crude rule) -> Promise.resolve(X).
set -uo pipefail
f=$1; n=$(basename "$f" .pts)
d=/tmp/h07b2/repro/node
mts="$d/$n.mts"
if [ $# -ge 2 ]; then
  cp "$2" "$mts"
else
  sed -E -e 's/"pts:test"/"node:test"/g' -e 's/"pts:assert"/"node:assert\/strict"/g' \
    -e 's/"pts:(path|process|fs)"/"node:\1"/g' "$f" > "$mts"
fi
s=$(date +%s%N)
timeout -k 2 30 "$HOME/.local/node/bin/node" --no-warnings --experimental-transform-types "$mts" > "$d/$n.node.out" 2> "$d/$n.node.err"
rc=$?
e=$(date +%s%N)
echo "--- node $n exit=$rc wall_ms=$(( (e - s) / 1000000 ))"
cat "$d/$n.node.out"
if [ -s "$d/$n.node.err" ]; then echo "[stderr]"; head -5 "$d/$n.node.err"; fi
