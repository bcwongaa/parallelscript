#!/bin/bash
# repeat.sh name threads rounds width expected_file: runs $BINDIR/<name> `width` copies at once,
# `rounds` times, at PTS_THREADS=threads, and counts runs whose stdout differs from expected_file
# or whose exit code isn't 0. Prints the distinct differing outputs.
set -uo pipefail
name=$1; threads=$2; rounds=$3; width=$4; expected=$5
bindir=${BINDIR:-/tmp/h07b2/repro/bin}
dir=$(mktemp -d /tmp/h07b2/repro/out/repeat.XXXXXX)
bad=0; total=0
for r in $(seq 1 "$rounds"); do
  pids=()
  for w in $(seq 1 "$width"); do
    ( PTS_THREADS=$threads timeout -k 2 30 "$bindir/$name" > "$dir/$r.$w.out" 2> "$dir/$r.$w.err"; echo $? > "$dir/$r.$w.rc" ) &
    pids+=($!)
  done
  for p in "${pids[@]}"; do wait "$p"; done
  for w in $(seq 1 "$width"); do
    total=$((total + 1))
    if ! cmp -s "$dir/$r.$w.out" "$expected" || [ "$(cat "$dir/$r.$w.rc")" != 0 ]; then
      bad=$((bad + 1))
      echo "differs: round $r copy $w exit $(cat "$dir/$r.$w.rc")"
      diff "$expected" "$dir/$r.$w.out" | head -6
    fi
  done
done
echo "$name threads=$threads: $bad of $total runs differ"
