// Probe (C120, item 3): a task's unref'd 10 ms setInterval on its own loop, which then sleeps.
// The main loop keeps running 300 ms with a referenced timer; then clears the interval from
// the main thread, waits 200 ms more, and ends. Prints ticks seen at 300 ms, after the
// clear, and 200 ms later; and the late starts (ticks begun after clearInterval returned).
const state = { ticks: 0, cleared: false, lateStarts: 0 };
function startInterval(): ReturnType<typeof setInterval> {
  const interval = setInterval(() => {
    if (state.cleared) {
      state.lateStarts++;
    }
    state.ticks++;
  }, 10);
  interval.unref();
  return interval;
}
const t0 = performance.now();
const interval = await Promise.resolve(startInterval());
await new Promise((resolve) => setTimeout(resolve, 300));
const at300 = state.ticks;
clearInterval(interval);
state.cleared = true;
const atClear = state.ticks;
await new Promise((resolve) => setTimeout(resolve, 200));
console.log("ticks by 300 ms:", at300, "at clear:", atClear, "200 ms after:", state.ticks, "late starts:", state.lateStarts);
console.log("elapsed ms:", Math.round(performance.now() - t0));
