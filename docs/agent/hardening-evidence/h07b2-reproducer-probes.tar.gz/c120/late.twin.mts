// Probe (C120, item 8): when does a `parallel` task's own unref'd 20 ms timer fire while the
// main loop's referenced timer keeps the program running? At 300 ms the main loop starts
// tasks that set a referenced 1 ms timer each (making their loops alive); the deadline is
// 1000 ms. Prints each timer's fire time (ms after start) or "never".
const t0 = performance.now();
const state = { kicked: -1 };
function arm(delay: number): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => resolve(`${Math.round(performance.now() - t0)}`), delay).unref();
  });
}
function kick(): Promise<number> {
  return new Promise((resolve) => setTimeout(() => resolve(1), 1));
}
function within(ms: number, p: Promise<string>): Promise<string> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => resolve("never"), ms);
    p.then((v) => {
      clearTimeout(timer);
      resolve(v);
    });
  });
}
const pending = [0, 1, 2, 3, 4, 5].map(() => within(1000, Promise.resolve(arm(20))));
setTimeout(() => {
  state.kicked = Math.round(performance.now() - t0);
  for (let i = 0; i < 6; i++) {
    void Promise.resolve(kick());
  }
}, 300);
const times = await Promise.all(pending);
console.log("kicked at", state.kicked, "fired at", times.join(","));
