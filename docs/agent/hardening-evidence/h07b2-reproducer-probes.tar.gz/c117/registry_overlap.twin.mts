// Probe (C117): two `parallel` tasks meet at a barrier (an AtomicInt, given up after 300 ms),
// then each registers a suite whose body registers a test, spins 100 ms and registers
// another, so the bodies overlap at 2+ loops. Afterwards the main thread registers a test
// of its own. Node's twin registers the suites one after another.
import { describe, test } from "node:test";
class AtomicInt { constructor(private v: number) {} add(d: number): number { const o = this.v; this.v += d; return o; } load(): number { return this.v; } }

const arrived = new AtomicInt(0);

function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {
    // spin
  }
}

function register(task: number): number {
  arrived.add(1);
  const end = performance.now() + 300;
  while (arrived.load() < 2 && performance.now() < end) {
    // the barrier
  }
  describe(`suite ${task}`, () => {
    test(`suite ${task} test first`, () => {});
    spin(100);
    test(`suite ${task} test second`, () => {});
  });
  return task;
}

const keepAlive = setTimeout(() => {}, 2_000); // referenced: the main loop doesn't take the tasks itself
await Promise.all([0, 1].map((task) => Promise.resolve(register(task))));
clearTimeout(keepAlive);
test("main test", () => {});
