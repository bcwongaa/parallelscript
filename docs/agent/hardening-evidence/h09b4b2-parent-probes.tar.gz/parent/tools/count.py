import json,collections,sys
c=collections.Counter(); pk=set(); nopk=set(); corpus=collections.Counter(); fails=[]
for line in open(sys.argv[1]):
    try: e=json.loads(line)
    except: continue
    a=e.get('Action'); t=e.get('Test')
    if a in ('pass','fail','skip') and t:
        c[a]+=1
        if a=='fail': fails.append(t)
        if t.startswith('TestCorpusMatchesNode/'): corpus[a]+=1
    if a in ('pass','fail') and not t: pk.add(e['Package'])
    if a=='skip' and not t: nopk.add(e['Package'])
print(dict(c), 'tested', len(pk), 'no-test', len(nopk), 'corpus', dict(corpus), 'fails', fails[:10])
