#!/bin/bash
# suite.sh NAME : build the snapshot's CLI and run the full suite (4 jobs); writes NAME-suite.{jsonl,err,exit}
S=/tmp/h09b4b2/s/$1; O=/tmp/h09b4b2/s/$1-suite
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd $S && GOMAXPROCS=4 go build -p 4 -o pts-bin/pts ./cmd/pts || { echo "exit=build" > $O.exit; exit 1; }
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/ > $O.jsonl 2> $O.err
echo "exit=$?" > $O.exit
