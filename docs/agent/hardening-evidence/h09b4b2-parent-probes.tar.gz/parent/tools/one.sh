#!/bin/bash
# one.sh FILE : emit-c FILE with the base and new CLIs; prints FILE, then exit, bytes, md5 for each
f=$1; line="$f"
for side in base:/tmp/h09b4b2/base new:/home/bryan/projects/parallelscript; do
  label=${side%%:*}; home=${side#*:}
  c=$(cd /home/bryan/projects/parallelscript && PTS_HOME=$home timeout 120 $home/pts-bin/pts emit-c $f 2>/tmp/h09b4b2/csize/err/$(echo $f | tr / _).$label); rc=$?
  line="$line	$rc	${#c}	$(printf %s "$c" | md5sum | cut -c1-12)"
done
echo "$line"
