// Literals with capturing generic methods made inside `.par` callbacks on many threads and
// called there through their own type and an interface (instances run with each closure).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Offset implements Maker {
  constructor(public by: number) {}
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const indexes: number[] = [];
for (let i = 0; i < 20000; i++) {
  indexes.push(i);
}
const sums = indexes.map((i) => {
  let calls = 0;
  const lit = {
    base: i,
    make<T>(x: T): Box<T> {
      calls += this.base % 3;
      return new Box(x);
    },
  };
  const m: Maker = i % 2 === 0 ? lit : new Offset(i);
  const a: Box<number> = lit.make(i);
  const b: Box<string> = m.make(`#${i}`);
  return a.value + b.value.length + calls;
});
let total = 0;
for (const s of sums) {
  total += s;
}
console.log(sums.length, total);
