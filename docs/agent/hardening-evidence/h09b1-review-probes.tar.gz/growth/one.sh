#!/bin/bash
# one.sh file.pts: AllInstances-only emit-c with base and snapshot; prints file, exit, C lines, seconds for each.
f=$1
out=/tmp/h09b1-review/growth/c
mkdir -p $out
n=$(echo "$f" | sed 's|/tmp/h09b/snap1/pts/tests/||; s|/|__|g')
for t in base_tree snap1; do
  s=$(date +%s.%N)
  timeout 300 /tmp/h09b1-review/allinst/ptsall_$t "$f" > $out/$n.$t.c 2> $out/$n.$t.err
  e=$?
  d=$(echo "$(date +%s.%N) - $s" | bc)
  l=$(wc -l < $out/$n.$t.c)
  printf "%s\t%s\t%s\t%s\t%.2f\n" "$n" "$t" "$e" "$l" "$d"
  rm -f $out/$n.$t.c
done
