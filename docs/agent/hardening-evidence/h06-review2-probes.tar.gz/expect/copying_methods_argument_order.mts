// toSorted and toSpliced evaluate their arguments before they copy the array, as JS's
// methods do, so an argument that changes the array is seen in the copy; with already did.
// pts copied first (review round 1, F6).
const log: string[] = [];
const values = [3, 1, 2];
function optional(): ((a: number, b: number) => number) | undefined {
    values.push(0);
    log.push("comparator");
    return undefined;
}
function required(): (a: number, b: number) => number {
    values.push(-1);
    return (a, b) => a - b;
}
function item(): number {
    values.push(9);
    return 7;
}
console.log("toSorted optional", String(values.toSorted(optional())));
console.log("toSorted required", String(values.toSorted(required())));
console.log("toSpliced", String(values.toSpliced(0, 1, item())));
console.log("with", String(values.with(0, item())));
console.log("values", String(values), log);

// expect:
// toSorted optional 0,1,2,3
// toSorted required -1,0,1,2,3
// toSpliced 7,1,2,0,-1,9
// with 7,1,2,0,-1,9,9
// values 3,1,2,0,-1,9,9 [ 'comparator' ]
