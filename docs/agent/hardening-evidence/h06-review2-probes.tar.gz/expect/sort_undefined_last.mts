// sort() and toSorted() without a comparator put every undefined after all the defined
// elements, which compare by their strings (SortCompare, ECMA-262 23.1.3.30.2), for
// arrays of strings, numbers, booleans, class instances, object literals and any, typed
// and through `any` (dynamic dispatch); toSorted leaves its source unchanged. pts gave
// undefined the string "" and sorted it first (C06, H06).
class P {
  constructor(public x: number) {}
  toString(): string {
    return "P" + this.x;
  }
}
interface Rec {
  n: number;
}
const strings: (string | undefined)[] = ["z", undefined, "a", undefined, "v"];
console.log(strings.sort(), strings);
const numbers: (number | undefined)[] = [20, undefined, 3, 100];
console.log(numbers.toSorted(), numbers);
const flags: (boolean | undefined)[] = [true, undefined, false];
console.log(flags.sort());
const points: (P | undefined)[] = [new P(2), undefined, new P(10)];
console.log(points.sort());
const records: (Rec | undefined)[] = [undefined, { n: 2 }, { n: 1 }];
console.log(records.sort());
const mixed: any[] = [3, undefined, "b", 10];
console.log(mixed.sort());
const unknowns: unknown[] = [undefined, "u", 1];
console.log(unknowns.toSorted());
const onlyUndefined: (string | undefined)[] = [undefined, undefined];
console.log(onlyUndefined.sort(), [undefined, "a"].sort(), ["a", undefined].toSorted());
const viaAny: any = [20, undefined, 3, 100];
console.log(viaAny.sort(), viaAny.toSorted());
const stringsViaAny: any = ["z", undefined, "a"];
console.log(stringsViaAny.toSorted(), stringsViaAny.sort());
// A match's group that took no part is undefined (D-133), so it sorts last too.
const match = /(nz)?(q)?(a)/.exec("nza")!;
console.log(match.toSorted(), match.sort());

// expect:
// [ 'a', 'v', 'z', undefined, undefined ] [ 'a', 'v', 'z', undefined, undefined ]
// [ 100, 20, 3, undefined ] [ 20, undefined, 3, 100 ]
// [ false, true, undefined ]
// [ P { x: 10 }, P { x: 2 }, undefined ]
// [ { n: 2 }, { n: 1 }, undefined ]
// [ 10, 3, 'b', undefined ]
// [ 1, 'u', undefined ]
// [ undefined, undefined ] [ 'a', undefined ] [ 'a', undefined ]
// [ 100, 20, 3, undefined ] [ 100, 20, 3, undefined ]
// [ 'a', 'z', undefined ] [ 'a', 'z', undefined ]
// [ 'a', 'nz', 'nza', undefined ] [
//   'a',
//   'nz',
//   'nza',
//   undefined,
//   index: 0,
//   input: 'nza',
//   groups: undefined
// ]
