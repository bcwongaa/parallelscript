# H06a review 2 (opus-reviewer, claude-opus-5-5)

**What I reviewed:** the main tree against `HEAD` `3999ab359`. The code diff hash (`git diff -- pts | sha256sum`) was `be52510c…989e` both when I built the CLI and when I finished.

**Tools:**
- CLI: `/tmp/h06/review2/pts`, built from that tree; programs run with `PTS_HOME=/home/bryan/projects/parallelscript`.
- Base: `/tmp/h06-base`.
- Helper: `/tmp/h06/review2/run3.sh <file> [threads]` runs the new CLI, base and Node (a `.oracle.mts` twin if present).
- Archive: probes in `/tmp/h06/review2/h06-review2-probes.tar.gz`, without binaries.

## Verdict

**Ready.** No blockers and no should-fix findings. Each of round 1's F1–F9 is fixed or honestly recorded in D-182. I found no regression in the rework's behaviour, apart from a 13–18% slowdown of `.par.sort(cmp)` (R2-2, minor). There are two minor issues and two notes; all are pre-existing or performance.

## Verified evidence

### Round-1 findings, re-checked

**F1. Typed arrays: fixed.**
- `typed_sort_undefined.pts` matches Node at 1, 2 and 4 threads.
- New probe `typed_kinds.pts` covers `toSorted(undefined)`, `toSorted(cmp)`, `sort(undefined)` and an optional comparator on Int8, Uint16, Float32 and Uint8Clamped arrays, plus a Float64Array `sort(undefined)` through `any`. All match Node, including -0 and NaN.
- A typed array with a comparator through `any` is still the documented "not supported yet" TypeError.

**F2. `.par.sort` writes all or nothing: fixed.**
- `par_sort_edges.pts` and `par_observe.pts` match Node at 1, 2 and 4 threads.
- After a throwing comparator or `toString`, the array is unchanged.
- A comparator that reads the array sees it as it was.

**F3. Frozen arrays: fixed.**
- `frozen_messages.pts` matches Node at 1, 2 and 4: index `'0'`, thrown after the comparator calls.
- `par_sort_edges.pts`: `Object.freeze([1]).par.sort()` gives `[ 1 ]`.
- `frozen_holes.pts`: a frozen array of holes only doesn't throw on any path. Its one remaining difference is `toSorted` of a `string[]`, which is the by-design D-182 case.
- `frozen_match.pts`: a frozen match array throws `'0'` on both paths, at 1 and 4 threads. Node agrees.

**F4. Dynamic comparators: fixed.**
- `optional_map_get.pts`, `sort_any_comparator.pts` (undefined and function cases), and the new `lowering_regress.pts` all match Node. The last covers an `any` property, an `any` element and a missing `Record` key.
- Still different: a non-function's message (`Expected (number, number) => number, got null`, where V8 says `The comparison function must be either a function or undefined`). D-182's known gaps record it.

**F5. Spellings and a shadowed `undefined`: fixed.**
- `shadowed_undefined.pts` and `sort_undefined_spellings.pts` match Node.
- `identifier()` (`lower.go:1522-1528`) binds a local named `undefined` before the global one, so the decision by lowered type is sound.

**F6. Copy order: fixed for `toSorted` and `toSpliced`.**
- `copy_order.pts` matches Node.
- The generated C (`probes/emit_shapes.c`) shows receiver, then arguments, then copy.
- One residue remains for typed arrays' in-place `sort(cmp)` (R2-1).

**F7. Default sort after a growing `toString`: fixed.** `tostring_mutates.pts` matches Node.

**F8. Comparator that shrinks the array: recorded, not fixed.**
- `comparator_mutates.pts` still differs in `pop` and `shrink`.
- D-182's known gaps record it.

**F9. Docs and tests: fixed.**
- D-182 is now in `docs/DECISIONS.md`.
- The wording is narrowed in D-182, C96, SPEC and REVIEW_LATER, and the stale comments are fixed.
- The two new unit tests run in `main`.
- The cited oracles exist in `h06-reproducer-probes.tar.gz`; see R2-3 for one gap.

**Other round-1 probes.** All 24 re-run at 1, 2 and 4 threads. The only differences from Node are:
- by design (D-182): `by_design.pts`, and the `toSorted` line of `frozen_holes.pts`;
- recorded (F8): `comparator_mutates.pts`;
- unrelated to sort, and the same on base: `par_disguised.pts`, `union_copy_checked.pts`, `union_without_undefined.pts`.

### Generated matrix

- I ran `gen.pts` with three seeds (12345, 777 and 99991), each at 1, 2 and 4 threads: 231 output lines per run, 0 differing lines from Node in all 9 runs (`/tmp/h06/review2/diff/`).

### Tests

- **Against Node.** I checked all 17 non-skipped H06a run tests (7 new, 10 from round 1). Each expect block equals Node's output. For the 3 `.par` tests I used my own sequential twins: `.par.sort` changed to `.sort`, and AtomicInt replaced by a counter class.
- **Both CLIs.** Each test passes on the new CLI at every thread count its `// threads:` line lists, and fails on base at those counts.
- **Harness sweep.** The 59 run tests that use sort, the copying methods, `.par` or `pts:parallel` went through `TestRun` and `TestRunMatchesNode` (`PTS_REQUIRE_NODE=1`, `-parallel 2`): 145 PASS, 0 FAIL, exit 0. The skips are the expected "no expected output" cases and Node-comparison skips of ParallelScript-only programs.
- **Unit and Go tests.**
  - `TestRuntimeUnitTestsPassUnderSanitizers/array_test.c`: PASS. The test program is compiled fresh each run.
  - `go test ./pts/lower/... ./pts/cgen/...`: ok. `go vet ./pts/lower/ ./pts/cgen/ ./pts/ir/`: clean.

### Rework regressions I looked for and didn't find

- **Order and side effects in the new Bind/Conditional trees:**
  - `copy_order.pts`;
  - `typed_compare_order.pts`: optional typed comparators, `toSorted`, `Array` `sort`, and receiver/comparator logging;
  - `lowering_regress.pts`: optional-chain receivers `?.sort` and `?.toSorted`, a missing receiver, a comparator that needs an adapter, and each receiver evaluated once;
  - `emit_shapes.c`: `void f()` is called after the receiver is bound; `toSpliced` keeps non-constant operands in locals, in order, before the copy. `l.splice` fills a left-out delete count with the constant `toEnd`, so hoisting the operands can't refer to the copy before it exists.
- **Generic and erased code:**
  - `sort_generic_optional.pts`;
  - an erased `Box<T>.sorted(c?)` at two instantiations;
  - a generic function with an `any` comparator, `undefined` or a function.
- **Frozen and match arrays through the write-back:** `par_match.pts` and `frozen_match.pts` at 1, 2 and 4 threads.
- **GC and races:**
  - `sorted = items.slice()` is an ordinary GC'd array held in a library local while the pool works.
  - The gather writes only that private copy.
  - `write_sorted` reads each slot of the copy once and stores each slot of the array once.
  - The original isn't written until the sort succeeds, so comparators on other threads read it unchanged.
- **Readability:** the C for `toSorted(cmp)`, a typed `toSorted(cmp?)`, `sort(void f())` and `toSpliced` is one readable statement-expression per call, under its `#line`.

## Findings

### R2-1: minor, pre-existing (the residue of F6). A typed array's in-place `sort(cmp)` copies its elements before evaluating the comparator

**Where:** `pts/lower/arrays.go:447`. When the comparator can't be undefined and nothing is copied, `sortWith` calls `steps.byComparator(receiver, compare)` directly. The typed array's `byComparator` (`pts/lower/typed_arrays.go:582-590`) binds `sorted`, then copies `numbers = pts_typed_array_to_array(sorted)`, and only then evaluates `compare` inside `ArraySortWith`.

**Effect:** an argument expression that writes to the typed array is lost, because the write-back overwrites it.

**Repros:** `/tmp/h06/review2/probes/typed_compare_order.pts` and `typed_compare_order_base.pts`.

```
const ta = new Int32Array([3, 1, 2]);
function changes() { ta[0] = 0; return (a, b) => a - b; }
ta.sort(changes())
NODE Int32Array(3) [ 0, 1, 2 ]     PTS (new and base) Int32Array(3) [ 1, 2, 3 ]
```

**Paths that are already right:** the optional comparator (`tb.sort(changesOptional())` gives `[ 0, 1, 2 ]`), typed `toSorted(cmp)`, and Array `sort(cmp)`.

**Fix:** don't take the `steps.copy == nil` shortcut for typed steps; the Bind path evaluates the comparator before `byComparator`. Alternatively, have the typed `byComparator` bind `compare` after `sorted` and before the copy.

**Test:** add one line to `copying_methods_argument_order.pts` or `sort_typed_array_undefined_comparator.pts`.

### R2-2: minor, new in the rework (performance). `.par.sort(cmp)` on plain arrays is 13–18% slower than base at 2–4 threads; the default order is faster

**Where:** `pts/lib/parallel.pts:189-199`. On more than one thread, the calling thread now makes three sequential O(n) passes: `items.slice()`, `pts_parallel_gather_sortable` (`array.c:923`) and `pts_array_write_sorted` (`array.c:946`). `sortInPlace`'s own `items.slice(0, count)` merge buffer comes on top of those.

**Measurement** (`/tmp/h06/review2/bench/bench2.pts`): best of 5 runs inside each program, 1M elements, new and base interleaved ×3. The host was busier than in round 1, so absolute numbers are higher.

| Threads | Comparator, numbers (new / base) | Default order, strings (new / base) | 10% undefined, comparator (new / base) |
|---|---|---|---|
| 4 | 146–169 / 123–135 ms | 794–824 / 894–956 ms | 149–166 / 154–158 ms |
| 2 | 167–171 / 148–151 ms | 1078–1082 / 1276–1297 ms | equal |
| 1 | within noise | 1159–1258 / 2056–2203 ms | — |

- At 1 thread `.par.sort` is now Array's own sort, hence the large gain in the default order.
- Against round 1 (`bench.pts`, one sample per run): the comparator path's new/base ratio went from about 1.1 to about 1.2–1.36, because of the added copy and write-back. The default order's ratio (about 0.88) is unchanged.
- Peak memory is one more n-element array than base.

**Suggested fixes:**
- Skip the gather for element kinds that can't hold holes or undefined (number, boolean, the integer kinds): `count` is just the length.
- Do the write-back with `pts_parallel_for`, or fold it into the final copy `sortRun` already makes.

None of the project's tracked benchmarks use `.par.sort`, so I'm calling this minor.

### R2-3: note. The archived oracle for `parallel_sort_undefined` predates its new `big kept` line

`pts/tests/run/parallel_sort_undefined.pts:7-8` cites `h06-probes/parallel/` in `docs/agent/hardening-evidence/h06-reproducer-probes.tar.gz`. That oracle prints everything except the expect block's new first line, `big kept true true true`.

The comment says "with review round 1's sums", and my own twin (`/tmp/h06/review2/expect/parallel_sort_undefined.mts`) reproduces the whole block. Still, archive the current twins of the three `.par` tests next to the evidence, so each expect line has stored Node evidence.

Comparison: `/tmp/h06/review2/oracle/` (`parallel_sort_holes` matches its archived oracle).

### R2-4: note, pre-existing, outside sort. `arrayOperands` still decides "left out" by the identifier's text

**Where:** `pts/lower/arrays.go:490`. `isUndefined(args[i])` treats a parameter named `undefined` as a left-out operand. `toSpliced`, `slice` and the other fixed-operand methods go through this.

**Repro:** `/tmp/h06/review2/probes/shadowed_operand.pts`.

```
function f(undefined: number) { return [[1,2,3].toSpliced(undefined, 1), [1,2,3].slice(undefined)]; }  f(2)
NODE [ [ 1, 2 ], [ 3 ] ]    PTS (new and base) [ [ 2, 3 ], [ 1, 2, 3 ] ]
```

The other text-based `isUndefined` callers (`maps.go`, `console.go`, `numbers.go`, `strings.go`, `unions.go`, `records.go`) have the same property. This is the F5 pattern outside H06a's methods: give it to H29, or decide by lowered type there too.

## On the split and D-182

The split stays defensible. H06b's RED tests are untouched by the rework and still fail as before.

The D-182 text now matches the code:
- copies of dynamic-value arrays, `(string | null)[]` included, get undefined; `string[]` and arrays of a single object type keep the hole;
- its Alternatives section records the twin-descriptor option;
- its Known gaps section records F8 and the non-function message.
