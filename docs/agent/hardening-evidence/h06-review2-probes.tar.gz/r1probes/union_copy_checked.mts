function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const a = new Array<string | null>(3);
a[0] = "x";
a[2] = null;
show("source via any", () => { const x: any = a; const y = x as (string | null)[]; return y; });
show("copy via any", () => { const x: any = a.toReversed(); const y = x as (string | null)[]; return y; });
show("copy via any toSorted", () => { const x: any = a.toSorted(); return (x as (string | null)[]).length; });
function takes(xs: (string | null)[]): number { return xs.length; }
show("copy to param", () => takes(a.toReversed()));
const m: any[] = new Array(2);
m[1] = "q";
show("any copy as string[]", () => { const x: any = m.toReversed(); return (x as string[]); });
show("any source as string[]", () => { const x: any = m; return (x as string[]); });
