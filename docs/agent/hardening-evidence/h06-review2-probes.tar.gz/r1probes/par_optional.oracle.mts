const a: (number | undefined)[] = [10, undefined, 9, 1, 100];
console.log(a.slice().sort(undefined));
let maybe: ((x: number | undefined, y: number | undefined) => number) | undefined;
console.log(a.slice().sort(maybe));
maybe = (x, y) => x! - y!;
console.log(a.slice().sort(maybe));
const f = new Float64Array([10, 9, 1, 100]);
console.log(f.sort(undefined));
