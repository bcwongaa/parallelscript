// Generic code: an optional comparator forwarded to sort/toSorted.
function sortAll<T>(a: T[], compare?: (x: T, y: T) => number): T[] {
  return a.sort(compare);
}
function copySorted<T>(a: T[], compare?: (x: T, y: T) => number): T[] {
  return a.toSorted(compare);
}
console.log(sortAll([10, 9, 1, 100]), sortAll([10, 9, 1, 100], (x, y) => x - y));
console.log(sortAll(["b", undefined, "a"]), sortAll(["b", undefined, "a", null], (x, y) => String(x).length - String(y).length));
console.log(copySorted([10, 9, 1, 100]), copySorted([true, false]));
class Box<T> {
  constructor(public items: T[]) {}
  sorted(compare?: (x: T, y: T) => number): T[] {
    return this.items.slice().sort(compare);
  }
}
console.log(new Box([10, 9, 1]).sorted(), new Box([10, 9, 1]).sorted((a, b) => a - b));
// a generic function value (erased)
const g = <T,>(a: T[], c?: (x: T, y: T) => number): T[] => a.sort(c);
console.log(g([10, 9, 1]), g([10, 9, 1], (a, b) => a - b));
// union of two comparator types plus undefined
type C1 = (a: number, b: number) => number;
type C2 = (a: number, b: number) => -1 | 0 | 1;
let pick: C1 | C2 | undefined = Math.random() < 2 ? ((a: number, b: number) => (a < b ? -1 : a > b ? 1 : 0)) as C2 : undefined;
console.log([10, 9, 1].sort(pick));
