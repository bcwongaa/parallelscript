const t: [number, string?] = [3];
console.log(t.toSorted(), t.toReversed(), t.length);
const u: [number, (number | undefined)?, string?] = [3, undefined];
console.log(u.toSorted(), u.toSorted((a, b) => Number(a) - Number(b)), u.toReversed(), u.length);
const w: [string, number?, boolean?] = ["b", 2, true];
console.log(w.toSorted(), w.toReversed());
