type C = (a: number, b: number) => number;
const m = new Map<string, C>();
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
show("map get", () => [10, 9, 1, 100].sort(m.get("x")));
show("map get toSorted", () => [10, 9, 1, 100].toSorted(m.get("x")));
m.set("x", (a, b) => a - b);
show("map get set", () => [10, 9, 1, 100].sort(m.get("x")));
