function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
// pushes during the sort
const p: (number | undefined)[] = [3, undefined, 1, undefined, 2];
let pushed = false;
show("push", () => p.sort((x, y) => { if (!pushed) { pushed = true; p.push(0); } return x! - y!; }));
// pops during the sort (shrinks by one)
const q: (number | undefined)[] = [3, undefined, 1, 2, undefined];
let popped = false;
show("pop", () => q.sort((x, y) => { if (!popped) { popped = true; q.pop(); } return x! - y!; }));
console.log("pop length", q.length);
// shrink to zero
const r: (string | undefined)[] = ["c", undefined, "a", "b"];
let shrunk = false;
show("shrink", () => r.sort((x, y) => { if (!shrunk) { shrunk = true; r.length = 0; } return x! < y! ? -1 : x! > y! ? 1 : 0; }));
console.log("shrink length", r.length);
// the comparator sees the array as it was
const s: (number | undefined)[] = [undefined, 2, 1];
const seen: string[] = [];
s.sort((x, y) => { seen.push(String(s[0])); return x! - y!; });
console.log("seen", seen, s);
// nested sorts inside a comparator
const outer: (number | undefined)[] = [3, undefined, 1, 2];
show("nested", () => outer.sort((x, y) => { const inner: (number | undefined)[] = [undefined, y, x]; inner.sort((m, n) => m! - n!); return inner[0] === x ? -1 : 1; }));
const anyOuter: any = [3, undefined, 1, 2];
show("nested any", () => anyOuter.sort((x: any, y: any) => { const inner: any = ["b", undefined, "a"]; inner.sort((m: any, n: any) => (m < n ? -1 : 1)); return x - y; }));
