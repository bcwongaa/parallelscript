// A comparator typed any that holds undefined (or null, or a function) in typed code.
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
const anyUndefined: any = undefined;
show("sort any undefined", () => [3, 20, 100].sort(anyUndefined));
show("toSorted any undefined", () => [3, 20, 100].toSorted(anyUndefined));
const anyNull: any = null;
show("sort any null", () => [3, 20, 100].sort(anyNull));
const anyFn: any = (a: number, b: number) => a - b;
show("sort any fn", () => [3, 20, 100].sort(anyFn));
const anyNumber: any = 5;
show("sort any number", () => [3, 20, 100].sort(anyNumber));
const maybe: ((a: number, b: number) => number) | undefined = Math.random() > 2 ? (a, b) => a - b : undefined;
show("toSorted maybe", () => [3, 20, 100].toSorted(maybe));
const strs: (string | undefined)[] = ["b", undefined, "a"];
show("strs toSorted maybe", () => strs.toSorted(undefined));
