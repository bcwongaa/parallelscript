type C = (a: number, b: number) => number;
interface Opts {
  cmp?: C;
}
function viaProperty(o: Opts): number[] {
  return [10, 9, 1, 100].sort(o.cmp);
}
console.log(viaProperty({}), viaProperty({ cmp: (a, b) => a - b }));
class Sorter {
  cmp?: C;
  run(): number[] {
    return [10, 9, 1, 100].toSorted(this.cmp);
  }
}
const s = new Sorter();
console.log(s.run());
s.cmp = (a, b) => b - a;
console.log(s.run());
const t: [C?] = [];
console.log([10, 9, 1, 100].sort(t[0]));
const m = new Map<string, C>();
console.log([10, 9, 1, 100].sort(m.get("x")));
const r: Record<string, C | undefined> = {};
console.log([10, 9, 1, 100].sort(r["x"]));
const opt: Opts | undefined = Math.random() > 2 ? { cmp: (a, b) => a - b } : undefined;
console.log([10, 9, 1, 100].sort(opt?.cmp));
