class P {
  constructor(public n: number) {}
}
const a = new Array<string | null>(3);
a[0] = "x";
a[2] = null;
console.log(a.toSorted(), a.toReversed(), a.with(0, "y"), a.toSpliced(0, 1));
const b = new Array<P | null>(2);
b[1] = new P(1);
console.log(b.toSorted(), b.toReversed());
const c = new Array<number | string>(2);
c[0] = 1;
console.log(c.toSorted(), c.with(0, "z"));
