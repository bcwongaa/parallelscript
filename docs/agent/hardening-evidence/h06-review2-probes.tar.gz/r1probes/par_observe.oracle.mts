class Bad {
  constructor(public n: number) {}
  toString(): string {
    if (this.n === 2) throw new Error("no");
    return "b" + this.n;
  }
}
const a: (Bad | undefined)[] = [undefined, new Bad(1), undefined, new Bad(2)];
try {
  a.sort();
} catch (e) {
  console.log("threw", (e as Error).message);
}
console.log(a);
const b: (number | undefined)[] = [undefined, 2, 1];
const seen: string[] = [];
b.sort((x, y) => {
  seen.push(String(b[0]));
  return x! - y!;
});
console.log(seen, b);
