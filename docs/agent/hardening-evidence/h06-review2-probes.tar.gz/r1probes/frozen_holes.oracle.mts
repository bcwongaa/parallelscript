function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
show("holes only sort", () => Object.freeze(new Array<string>(2)).toSorted());
show("holes only seq", () => (Object.freeze(new Array<string>(2)) as string[]).sort());
show("holes only cmp", () => (Object.freeze(new Array<string>(2)) as string[]).sort((a, b) => a.length - b.length));
show("holes only par", () => (Object.freeze(new Array<string>(2)) as string[]).sort());
show("sorted then holes par", () => (Object.freeze(["a", "b", undefined]) as (string | undefined)[]).sort());
