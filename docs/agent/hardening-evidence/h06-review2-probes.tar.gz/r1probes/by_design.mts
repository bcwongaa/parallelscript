function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
const s = new Array<string>(3);
s[0] = "b";
s[2] = "a";
const sorted = s.toSorted();
show("toSorted", () => sorted);
show("as any", () => { const x: any = sorted[2]; return x; });
show("required", () => { const x: string = sorted[2]; return x.length; });
show("toReversed", () => s.toReversed());
show("with", () => s.with(0, "z"));
show("toSpliced", () => s.toSpliced(0, 1));
show("json", () => JSON.stringify(sorted));
show("join", () => sorted.join("-"));
class P { constructor(public n: number) {} }
const p = new Array<P>(2);
p[1] = new P(1);
show("objects toReversed", () => p.toReversed());
show("objects with", () => p.with(1, new P(2)));
