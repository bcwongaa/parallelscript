// .sort edge cases; the Node twin is par_sort_edges.oracle.mts (.sort as .sort).
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
// A comparator that throws: JS leaves the array as it was.
const thrown: (number | undefined)[] = [undefined, 3, undefined, 1, 2];
show("throwing comparator", () => thrown.sort((a, b) => { throw new Error("no"); }));
console.log("after throw", thrown);
const thrownDefault: (string | undefined)[] = [undefined, "b", "a"];
// frozen arrays
show("frozen sorted", () => (Object.freeze([1, 2, 3]) as number[]).sort());
show("frozen undefined first", () => (Object.freeze([undefined, 2, 1]) as (number | undefined)[]).sort());
show("frozen compare", () => (Object.freeze([undefined, 2, 1]) as (number | undefined)[]).sort((a, b) => a! - b!));
show("frozen one", () => (Object.freeze([1]) as number[]).sort());
show("frozen one+undefined", () => (Object.freeze([1, undefined]) as (number | undefined)[]).sort());
// default order, stable for equal strings, 5000 objects with 10 distinct strings
class K {
  constructor(public k: number, public i: number) {}
  toString(): string {
    return "k" + this.k;
  }
}
const ks: (K | undefined | null)[] = [];
for (let i = 0; i < 5000; i++) {
  ks.push(i % 7 === 0 ? undefined : i % 11 === 0 ? null : new K((i * 31) % 10, i));
}
ks.sort();
let stable = true;
let undefinedsAt = -1;
let nullsSeen = 0;
for (let i = 1; i < ks.length; i++) {
  const p = ks[i - 1], q = ks[i];
  if (p instanceof K && q instanceof K && (String(p) > String(q) || (String(p) === String(q) && p.i > q.i))) stable = false;
  if (q === undefined && undefinedsAt < 0) undefinedsAt = i;
  if (q === null) nullsSeen++;
}
console.log("default stable", stable, undefinedsAt, nullsSeen, ks.length, String(ks[0]), String(ks[undefinedsAt - 1]), ks[ks.length - 1]);
// numbers > 2048 in default (string) order
const ns: number[] = [];
for (let i = 0; i < 5000; i++) ns.push((i * 7919) % 5000);
ns.sort();
console.log("numbers", ns.slice(0, 5), ns.slice(4995));
// ParallelRange.sort
function range(n: number) { return Array.from({ length: n }, (_, i) => i); }
console.log("range", range(5).sort((a, b) => b - a));
