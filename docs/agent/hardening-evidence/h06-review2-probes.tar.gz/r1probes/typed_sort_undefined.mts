// Typed arrays: sort(undefined), toSorted(undefined) and an optional comparator are the numeric default order.
const f = new Float64Array([10, 9, 1, 100, -0, 0]);
console.log(f.sort(undefined));
const i = new Int32Array([10, 9, 1, 100]);
console.log(i.toSorted(undefined), i);
function sortTyped(a: Uint8Array, compare?: (x: number, y: number) => number): Uint8Array {
  return a.sort(compare);
}
console.log(sortTyped(new Uint8Array([10, 9, 1, 100])));
console.log(sortTyped(new Uint8Array([10, 9, 1, 100]), (x, y) => y - x));
function toSortedTyped(a: Float32Array, compare?: (x: number, y: number) => number): Float32Array {
  return a.toSorted(compare);
}
console.log(toSortedTyped(new Float32Array([10, 9, 1, 100])));
