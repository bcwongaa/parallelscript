function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const typed: any = new Float64Array([3, 1, 2]);
show("typed as array", () => (typed as number[]).par.sort());
const tuple: any = [3, undefined] as [number, undefined];
show("tuple as array", () => (tuple as (number | undefined)[]).par.sort());
