const m = /(nz)?(q)?(a)/.exec("nza")!;
console.log(m.sort());
const n = /(nz)?(q)?(a)(z)?/.exec("nza")!;
console.log(n.sort((a, b) => b.length - a.length));
const o = /(nz)?(q)?(a)/.exec("nza")!;
console.log(o.toReversed(), o.with(0, "w"), o.toSpliced(0, 1));
