function sorted(values: number[], compare?: (a: number, b: number) => number): number[] {
  return values.toSorted(compare);
}
console.log(sorted([10, 9, 1]));
