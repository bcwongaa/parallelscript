// JS evaluates the arguments before toSorted/toSpliced copy the receiver.
const a = [3, 1, 2];
function optional(): ((x: number, y: number) => number) | undefined {
  a.push(0);
  return undefined;
}
console.log("toSorted(optional)", a.toSorted(optional()));
const b = [3, 1, 2];
function required(): (x: number, y: number) => number {
  b.push(0);
  return (x, y) => x - y;
}
console.log("toSorted(required)", b.toSorted(required()));
const c = [3, 1, 2];
function item(): number {
  c.push(0);
  return 9;
}
console.log("toSpliced", c.toSpliced(0, 1, item()));
const d = [3, 1, 2];
function value(): number {
  d.push(0);
  return 9;
}
console.log("with", d.with(0, value()));
