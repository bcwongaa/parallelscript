// Other spellings of an undefined comparator.
console.log([3, 20, 100].sort((undefined)));
console.log([3, 20, 100].sort(void 0));
const u = undefined;
console.log([3, 20, 100].sort(u));
const anyCompare: any = undefined;
console.log([3, 20, 100].sort(anyCompare));
console.log([3, 20, 100].toSorted(anyCompare));
let maybe: ((a: number, b: number) => number) | undefined = Math.random() > 2 ? (a, b) => a - b : undefined;
console.log([3, 20, 100].toSorted(maybe));
