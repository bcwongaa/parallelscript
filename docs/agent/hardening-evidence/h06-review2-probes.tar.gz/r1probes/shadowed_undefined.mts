// A parameter named `undefined` shadows the global one.
function descending(undefined: (a: number, b: number) => number): number[][] {
  return [[3, 20, 100].sort(undefined), [3, 20, 100].toSorted(undefined)];
}
console.log(descending((a, b) => a - b));
