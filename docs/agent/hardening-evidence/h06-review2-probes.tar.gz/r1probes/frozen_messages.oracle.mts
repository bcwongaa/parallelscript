function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const a = Object.freeze([1, undefined, 2]) as (number | undefined)[];
show("seq sort", () => a.sort());
show("par sort", () => a.sort());
show("seq compare", () => a.sort((x, y) => x! - y!));
show("par compare", () => a.sort((x, y) => x! - y!));
console.log(a);
