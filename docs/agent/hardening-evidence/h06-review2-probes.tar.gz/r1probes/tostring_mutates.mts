// A toString that changes the array during the default sort.
const arr: (T | undefined)[] = [];
let grow = true;
class T {
  constructor(public n: number) {}
  toString(): string {
    if (grow) {
      grow = false;
      for (let i = 0; i < 100; i++) arr.push(undefined);
    }
    return "t" + this.n;
  }
}
arr.push(new T(3), undefined, new T(1), new T(2));
arr.sort();
console.log(arr.slice(0, 5), arr.length);
