type C = (a: number, b: number) => number;
interface Opts {
  cmp?: C;
}
const r: Record<string, C | undefined> = {};
console.log([10, 9, 1, 100].sort(r["x"]));
const opt: Opts | undefined = Math.random() > 2 ? { cmp: (a, b) => a - b } : undefined;
console.log([10, 9, 1, 100].sort(opt?.cmp));
const arr: (C | undefined)[] = [undefined];
console.log([10, 9, 1, 100].sort(arr[0]));
