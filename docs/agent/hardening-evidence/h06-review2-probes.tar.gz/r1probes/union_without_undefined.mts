// A copy of a (string | null)[] with a hole: the element type can't hold undefined.
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const a = new Array<string | null>(3);
a[0] = "x";
a[2] = null;
const c = a.toReversed();
show("copy", () => c);
show("typeof", () => { const v: string | null = c[1]; return typeof v; });
show("narrowed length", () => {
  const v: string | null = c[1];
  if (v !== null) {
    return v.length;
  }
  return "null";
});
show("toUpperCase", () => {
  const v = c[1];
  return v === null ? "null" : v.toUpperCase();
});
show("source narrowed", () => {
  const v: string | null = a[1];
  return v === null ? "null" : v.length;
});
