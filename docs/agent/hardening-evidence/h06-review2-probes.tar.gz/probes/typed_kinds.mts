function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const t: any = new Float64Array([10, 9, 1, NaN, -0, 0]);
show("any typed sort(undefined)", () => t.sort(undefined));
const u: any = new Int32Array([10, 9, 1]);
show("any typed sort(cmp)", () => u.sort((a: number, b: number) => b - a));
const a = new Int8Array([10, 9, 1, -5]);
console.log(a.toSorted(undefined), a.toSorted((p, q) => q - p), a.sort(undefined), a);
const b = new Uint16Array([10, 9, 1]);
console.log(b.toSorted(undefined), b.toSorted((p, q) => q - p), b.sort(undefined), b);
const c = new Float32Array([10, 9, 1, NaN, -0]);
console.log(c.toSorted(undefined), c.toSorted((p, q) => q - p), c.sort(undefined), c);
const d = new Uint8ClampedArray([10, 9, 1]);
let maybe: ((p: number, q: number) => number) | undefined;
console.log(d.toSorted(maybe), d.sort(maybe));
