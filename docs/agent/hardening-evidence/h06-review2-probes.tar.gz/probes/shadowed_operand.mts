// A parameter named `undefined` as a start index.
function f(undefined: number): number[][] {
  return [[1, 2, 3].toSpliced(undefined, 1), [1, 2, 3].slice(undefined)];
}
console.log(f(2));
