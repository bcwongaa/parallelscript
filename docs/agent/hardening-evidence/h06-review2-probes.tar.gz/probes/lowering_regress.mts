type C = (a: number, b: number) => number;
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
// optional-chain receivers
const maybeArr: number[] | undefined = Math.random() < 2 ? [10, 9, 1] : undefined;
const noArr: number[] | undefined = Math.random() > 2 ? [10, 9, 1] : undefined;
let maybeCmp: C | undefined;
show("?.sort(undefined cmp)", () => maybeArr?.sort(maybeCmp));
show("?.toSorted(undefined cmp)", () => maybeArr?.toSorted(maybeCmp));
show("missing ?.toSorted", () => noArr?.toSorted(maybeCmp));
maybeCmp = (a, b) => a - b;
show("?.toSorted(cmp)", () => maybeArr?.toSorted(maybeCmp));
// dynamic comparators from various places
const o: any = {};
show("any property missing", () => [10, 9, 1].sort(o.cmp));
const arr: any = [];
show("any element missing", () => [10, 9, 1].toSorted(arr[3]));
const rec: Record<string, C> = {};
show("record missing", () => [10, 9, 1].sort(rec["x"]));
// comparator needing an adapter
const wide: ((a: number | undefined, b: number | undefined) => number) | undefined = (a, b) => (a ?? 0) - (b ?? 0);
show("adapter", () => [10, 9, 1].toSorted(wide));
// erased generic class with an optional comparator, two instantiations
class Box<T> {
  constructor(public items: T[]) {}
  sorted(c?: (a: T, b: T) => number): T[] {
    return this.items.toSorted(c);
  }
}
show("box numbers", () => new Box([10, 9, 1]).sorted());
show("box strings", () => new Box(["b", undefined, "a"]).sorted((a, b) => String(a).localeCompare(String(b))));
// generic function with a comparator typed any
function sortAny<T>(xs: T[], c: any): T[] {
  return xs.sort(c);
}
show("generic any undefined", () => sortAny([10, 9, 1], undefined));
show("generic any fn", () => sortAny([10, 9, 1], (a: number, b: number) => a - b));
// sort result used in an expression; statement form with effects
let n = 0;
function getArr(): number[] { n++; return [3, 1, 2]; }
getArr().sort(undefined);
getArr().toSorted(maybeCmp);
show("receiver evaluated once each", () => n);
