function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const m = /(nz)?(q)?(a)/.exec("nza")!;
Object.freeze(m);
show("frozen match par.sort", () => m.sort());
show("frozen match sort", () => m.sort());
const n = /(nz)?(q)?(a)/.exec("nza")!;
show("match par.sort cmp", () => n.sort((a, b) => a.length - b.length));
