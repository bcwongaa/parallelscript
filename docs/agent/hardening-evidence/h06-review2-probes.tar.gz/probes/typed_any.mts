function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name + ": " + (e as Error).message);
  }
}
const t: any = new Float64Array([10, 9, 1, NaN, -0, 0]);
show("any typed sort(undefined)", () => t.sort(undefined));
const u: any = new Int32Array([10, 9, 1]);
show("any typed sort(cmp)", () => u.sort((a: number, b: number) => b - a));
for (const make of [() => new Int8Array([10, 9, 1, -5]), () => new Uint16Array([10, 9, 1]), () => new Float32Array([10, 9, 1, NaN, -0])]) {
  const x = make();
  console.log(x.toSorted(undefined), x.toSorted((a, b) => b - a), x.sort(undefined), x);
}
