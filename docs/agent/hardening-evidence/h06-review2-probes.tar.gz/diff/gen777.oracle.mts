// Seeded differential cases for sort/toSorted/.sort over arrays with undefined, null and holes.
// The Node twin (gen.oracle.mts) is this file with `.sort` as `.sort`.
let seed = 777;
function next(n: number): number {
  seed = (seed * 48271) % 2147483647;
  return seed % n;
}
function token(a: any, i: number): string {
  if (a.slice(i, i + 1).flat().length === 0) {
    return "_";
  }
  const v: any = a[i];
  if (v === undefined) return "u";
  if (v === null) return "n";
  if (typeof v === "number") return "#" + v;
  if (typeof v === "string") return "'" + v;
  return "o" + String(v.k);
}
function digest(label: string, a: any): void {
  let h = 7;
  const counts = [0, 0, 0];
  const head: string[] = [];
  for (let i = 0; i < a.length; i++) {
    const t = token(a, i);
    if (t === "_") counts[2]++;
    else if (t === "u") counts[1]++;
    else counts[0]++;
    if (head.length < 12) head.push(t);
    for (let j = 0; j < t.length; j++) {
      h = (h * 31 + t.charCodeAt(j)) % 1000000007;
    }
    h = (h * 31 + 44) % 1000000007;
  }
  console.log(label, a.length, counts.join("/"), h, head.join(","));
}
let sawUndefined = 0;
function key(v: any): number {
  if (v === undefined) {
    sawUndefined++;
    return -1000;
  }
  if (v === null) return -1;
  if (typeof v === "number") return v % 37;
  if (typeof v === "string") return v.length;
  return v.k % 13;
}
function cmp(a: any, b: any): number {
  return key(a) - key(b);
}
interface O {
  k: number;
}
function anyArray(n: number): any[] {
  const a: any[] = new Array(n);
  for (let i = 0; i < n; i++) {
    const r = next(10);
    if (r === 0) continue; // hole
    if (r === 1) a[i] = undefined;
    else if (r === 2) a[i] = null;
    else if (r < 6) a[i] = next(500);
    else a[i] = "s" + next(300);
  }
  return a;
}
function unionArray(n: number): (string | number | null | undefined)[] {
  const a = new Array<string | number | null | undefined>(n);
  for (let i = 0; i < n; i++) {
    const r = next(10);
    if (r === 0) continue;
    if (r === 1) a[i] = undefined;
    else if (r === 2) a[i] = null;
    else if (r < 6) a[i] = next(500);
    else a[i] = "s" + next(300);
  }
  return a;
}
function stringArray(n: number): string[] {
  const a = new Array<string>(n);
  for (let i = 0; i < n; i++) {
    if (next(6) !== 0) a[i] = "t" + next(200);
  }
  return a;
}
function objectArray(n: number): (O | undefined)[] {
  const a = new Array<O | undefined>(n);
  for (let i = 0; i < n; i++) {
    const r = next(8);
    if (r === 0) continue;
    a[i] = r === 1 ? undefined : { k: next(100) };
  }
  return a;
}
function numberArray(n: number): number[] {
  const a: number[] = [];
  for (let i = 0; i < n; i++) a.push(next(1000) - 300);
  return a;
}
const sizes = [0, 1, 2, 7, 100, 2047, 2048, 2049, 4500, 9000];
for (const n of sizes) {
  const base = anyArray(n);
  digest("any sort " + n, base.slice().sort());
  digest("any sort cmp " + n, base.slice().sort(cmp));
  digest("any toSorted " + n, base.toSorted());
  digest("any toSorted cmp " + n, base.toSorted(cmp));
  digest("any par " + n, base.slice().sort());
  digest("any par cmp " + n, base.slice().sort(cmp));
  const viaAny: any = base.slice();
  digest("viaAny sort cmp " + n, viaAny.sort(cmp));
  digest("viaAny toSorted " + n, viaAny.toSorted());
  const u = unionArray(n);
  digest("union sort " + n, u.slice().sort());
  digest("union sort cmp " + n, u.slice().sort(cmp));
  digest("union toSorted " + n, u.toSorted());
  digest("union par " + n, u.slice().sort());
  digest("union par cmp " + n, u.slice().sort(cmp));
  const s = stringArray(n);
  digest("strings sort " + n, s.slice().sort());
  digest("strings sort cmp " + n, s.slice().sort(cmp));
  digest("strings par " + n, s.slice().sort());
  digest("strings par cmp " + n, s.slice().sort(cmp));
  const o = objectArray(n);
  digest("objects sort cmp " + n, o.slice().sort(cmp));
  digest("objects par cmp " + n, o.slice().sort(cmp));
  digest("objects par " + n, o.slice().sort());
  const m = numberArray(n);
  digest("numbers sort " + n, m.slice().sort());
  digest("numbers par " + n, m.slice().sort());
  digest("numbers par cmp " + n, m.slice().sort(cmp));
}
console.log("comparator saw undefined", sawUndefined);
