#!/bin/bash
# run_a64_2.sh: the larger in2/ inputs (file FN[_suffix].bin) through the aarch64 harnesses and arm64 Node, and x86 harness vs x86 Node.
cd /tmp/pts-h36/review1/math
mkdir -p out2
for f in in2/*.bin; do b=$(basename $f .bin); n=${b%%_*}
  ./h_new_a64 $n < $f > out2/$b.a64 || echo "rc=$?"
  ./h_head_a64 $n < $f > out2/$b.a64head || echo "rc=$?"
  ./h_new_x86 $n < $f > out2/$b.x86 || echo "rc=$?"
  /tmp/pts-h36/arm64-node-bin/node node_eval.mjs $n $f out2/$b.nodea64 || echo "node rc=$?"
  ~/.local/node/bin/node node_eval.mjs $n $f out2/$b.nodex86 || echo "node rc=$?"
  echo "$b a64new-vs-a64node: $(python3 -I cmp.py out2/$b.a64 out2/$b.nodea64) a64head-vs-a64node: $(python3 -I cmp.py out2/$b.a64head out2/$b.nodea64) x86new-vs-x86node: $(python3 -I cmp.py out2/$b.x86 out2/$b.nodex86)"
done
