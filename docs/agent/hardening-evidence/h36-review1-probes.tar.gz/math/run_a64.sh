#!/bin/bash
# run_a64.sh: each function's inputs through the aarch64 harnesses (new, HEAD) and arm64 Node, all under qemu; mismatch counts vs arm64 Node.
cd /tmp/pts-h36/review1/math
mkdir -p out/a64 out/a64head out/nodea64
for f in in/*.bin; do n=$(basename $f .bin)
  ./h_new_a64 $n < $f > out/a64/$n.bin || echo "harness rc=$? $n"
  ./h_head_a64 $n < $f > out/a64head/$n.bin || echo "head harness rc=$? $n"
  /tmp/pts-h36/arm64-node-bin/node node_eval.mjs $n $f out/nodea64/$n.bin || echo "node rc=$? $n"
  echo "$n new: $(python3 -I cmp.py out/a64/$n.bin out/nodea64/$n.bin) head: $(python3 -I cmp.py out/a64head/$n.bin out/nodea64/$n.bin) x86node-vs-a64node: $(python3 -I cmp.py out/nodex86/$n.bin out/nodea64/$n.bin)"
done
