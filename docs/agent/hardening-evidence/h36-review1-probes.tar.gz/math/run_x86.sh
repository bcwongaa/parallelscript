#!/bin/bash
# run_x86.sh: each function's inputs through the x86-64 harness and x86-64 Node; mismatch counts.
cd /tmp/pts-h36/review1/math
mkdir -p out/x86 out/nodex86
for f in in/*.bin; do n=$(basename $f .bin)
  ./h_new_x86 $n < $f > out/x86/$n.bin || echo "harness rc=$? $n"
  ~/.local/node/bin/node node_eval.mjs $n $f out/nodex86/$n.bin || echo "node rc=$? $n"
  echo "$n $(python3 -I cmp.py out/x86/$n.bin out/nodex86/$n.bin)"
done
