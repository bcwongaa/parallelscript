"""cmp.py A B: count differing doubles (by bits) between two raw files."""
import sys
a, b = open(sys.argv[1], 'rb').read(), open(sys.argv[2], 'rb').read()
if len(a) != len(b): print('LENGTH', len(a), len(b)); sys.exit(1)
d = sum(1 for i in range(0, len(a), 8) if a[i:i+8] != b[i:i+8])
print(d, len(a) // 8)
