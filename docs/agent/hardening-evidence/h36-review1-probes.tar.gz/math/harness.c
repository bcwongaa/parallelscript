/* harness FN < in.bin > out.bin: raw little-endian doubles in, pts_ieee754_FN of each out (atan2: (y, x) pairs). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pts.h"
typedef double (*unary)(double);
static const struct { const char *name; unary f; } fns[] = {
  {"acos", pts_ieee754_acos}, {"acosh", pts_ieee754_acosh}, {"asin", pts_ieee754_asin}, {"asinh", pts_ieee754_asinh},
  {"atan", pts_ieee754_atan}, {"atanh", pts_ieee754_atanh}, {"cbrt", pts_ieee754_cbrt}, {"cos", pts_ieee754_cos},
  {"cosh", pts_ieee754_cosh}, {"exp", pts_ieee754_exp}, {"expm1", pts_ieee754_expm1}, {"log", pts_ieee754_log},
  {"log10", pts_ieee754_log10}, {"log1p", pts_ieee754_log1p}, {"log2", pts_ieee754_log2}, {"sin", pts_ieee754_sin},
  {"sinh", pts_ieee754_sinh}, {"tan", pts_ieee754_tan}, {"tanh", pts_ieee754_tanh},
};
int main(int argc, char **argv) {
  if (argc != 2) return 2;
  double buf[2];
  if (strcmp(argv[1], "atan2") == 0) {
    while (fread(buf, sizeof(double), 2, stdin) == 2) { double r = pts_ieee754_atan2(buf[0], buf[1]); fwrite(&r, sizeof r, 1, stdout); }
    return 0;
  }
  for (size_t i = 0; i < sizeof fns / sizeof fns[0]; i++) {
    if (strcmp(argv[1], fns[i].name) == 0) {
      while (fread(buf, sizeof(double), 1, stdin) == 1) { double r = fns[i].f(buf[0]); fwrite(&r, sizeof r, 1, stdout); }
      return 0;
    }
  }
  return 3;
}
