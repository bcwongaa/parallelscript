// node node_eval.mjs FN IN OUT: Math[FN] of each raw double in IN (atan2: (y, x) pairs), raw doubles to OUT.
import { readFileSync, writeFileSync } from "node:fs";
const [fn, inPath, outPath] = process.argv.slice(2);
const b = readFileSync(inPath);
const input = new Float64Array(b.buffer, b.byteOffset, b.byteLength / 8);
const f = Math[fn];
let out;
if (fn === "atan2") {
  out = new Float64Array(input.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = f(input[2 * i], input[2 * i + 1]);
} else {
  out = new Float64Array(input.length);
  for (let i = 0; i < input.length; i++) out[i] = f(input[i]);
}
writeFileSync(outPath, out);
