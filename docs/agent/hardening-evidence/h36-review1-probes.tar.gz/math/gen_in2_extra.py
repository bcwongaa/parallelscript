"""gen_in2_extra.py: the extra in2/ inputs (log/log10/log2 near sqrt(2) and 1/sqrt(2) times powers of two; cbrt over the exponent range)."""
import random, struct, math
rng = random.Random(4242)
n = 300000
def g():
    r = rng.random()
    if r < 0.4: return rng.uniform(1.38, 1.45) * 2.0 ** rng.choice((0, 0, 0, 1, -1, 5, -7, 100))
    if r < 0.8: return rng.uniform(0.69, 0.73) * 2.0 ** rng.choice((0, 0, 0, 1, -1, 5, -7, 100))
    return rng.uniform(0.5, 2.0)
for name in ('log', 'log10', 'log2'):
    open(f'in2/{name}_sqrt2.bin', 'wb').write(struct.pack(f'<{n}d', *(g() for _ in range(n))))
def c():
    return rng.uniform(-1e3, 1e3) if rng.random() < 0.5 else math.ldexp(rng.uniform(1, 8), rng.randint(-1070, 1020)) * rng.choice((-1, 1))
open('in2/cbrt_b.bin', 'wb').write(struct.pack(f'<{n}d', *(c() for _ in range(n))))
