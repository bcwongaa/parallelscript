"""gen_inputs.py OUTDIR N SEED: N raw doubles per Math function, drawn from the reviewer's own mixes of ranges."""
import math, random, struct, sys

out, n, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
rng = random.Random(seed)

def logu(lo, hi):  # log-uniform magnitude in [lo, hi], random sign
    return rng.choice((-1, 1)) * math.exp(rng.uniform(math.log(lo), math.log(hi)))

def bits_near(x, k=64):  # x moved by up to k ulps
    if x == 0 or not math.isfinite(x):
        return x
    b = struct.unpack('<q', struct.pack('<d', x))[0] + rng.randint(-k, k)
    return struct.unpack('<d', struct.pack('<q', b))[0]

def rnd_bits():  # any finite double
    while True:
        x = struct.unpack('<d', struct.pack('<Q', rng.getrandbits(64)))[0]
        if math.isfinite(x):
            return x

def trig():
    r = rng.random()
    if r < 0.2: return rng.uniform(-math.pi / 4, math.pi / 4)
    if r < 0.45: return rng.uniform(-3e5, 3e5)
    if r < 0.6: return bits_near(rng.randint(-400000, 400000) * math.pi / 2, 1 << 20)
    if r < 0.8: return logu(1e6, 1e308)
    if r < 0.9: return rng.uniform(0.6, 0.8) * rng.choice((-1, 1))
    return rnd_bits()

def unit():
    r = rng.random()
    if r < 0.4: return rng.uniform(-1, 1)
    if r < 0.6: return bits_near(rng.choice((-0.5, 0.5)), 1 << 40)
    if r < 0.8: return rng.uniform(0.97, 1.0) * rng.choice((-1, 1))
    return logu(1e-12, 1)

def atan_in():
    r = rng.random()
    if r < 0.7: return logu(0.3, 3.0)
    return logu(1e-12, 1e25)

def explike(lo, hi):
    def g():
        r = rng.random()
        if r < 0.5: return rng.uniform(lo, hi)
        if r < 0.8: return rng.uniform(-1.2, 1.2)
        return logu(1e-12, 1)
    return g

def logs():
    r = rng.random()
    if r < 0.3: return abs(logu(1e-310, 1e308))
    if r < 0.5: return 1 + rng.uniform(-0.3, 0.42)
    if r < 0.7: return math.ldexp(1 + rng.uniform(-1, 1) * 2.0 ** -rng.randint(18, 52), rng.randint(-1000, 1000))
    if r < 0.85: return bits_near(math.sqrt(2) * 2.0 ** rng.randint(-60, 60), 1 << 30)
    return rng.uniform(0, 1e6)

def log1p_in():
    r = rng.random()
    if r < 0.3: return rng.uniform(-0.999, 3)
    if r < 0.5: return logu(1e-20, 0.4)
    if r < 0.7: return math.ldexp(1 + rng.uniform(-1, 1) * 2.0 ** -rng.randint(18, 40), rng.randint(1, 60)) - 1
    if r < 0.85: return abs(logu(1, 1e300))
    return bits_near(math.sqrt(2) - 1, 1 << 40)

def acosh_in():
    r = rng.random()
    if r < 0.4: return rng.uniform(1, 2)
    if r < 0.8: return math.exp(rng.uniform(math.log(2), math.log(2.0 ** 28)))
    return abs(logu(2.0 ** 28, 1e300))

def asinh_in():
    r = rng.random()
    if r < 0.4: return rng.uniform(-2, 2)
    if r < 0.8: return logu(2, 2.0 ** 28)
    return logu(1e-12, 1e300)

def atanh_in():
    r = rng.random()
    if r < 0.6: return rng.uniform(-1, 1)
    return logu(1e-12, 0.6)

def cbrt_in():
    return logu(1e-320, 1e308) if rng.random() < 0.7 else rng.uniform(-100, 100)

def hyp():
    r = rng.random()
    if r < 0.6: return rng.uniform(-23, 23)
    if r < 0.8: return logu(1e-10, 1)
    return logu(22, 711)

gens = {
    'sin': trig, 'cos': trig, 'tan': trig, 'asin': unit, 'acos': unit, 'atan': atan_in,
    'exp': explike(-745, 709.7), 'expm1': explike(-40, 709.7), 'log': logs, 'log2': logs, 'log10': logs,
    'log1p': log1p_in, 'acosh': acosh_in, 'asinh': asinh_in, 'atanh': atanh_in, 'cbrt': cbrt_in,
    'sinh': hyp, 'cosh': hyp, 'tanh': hyp,
}
for name, g in gens.items():
    with open(f'{out}/{name}.bin', 'wb') as f:
        f.write(struct.pack(f'<{n}d', *(g() for _ in range(n))))
with open(f'{out}/atan2.bin', 'wb') as f:
    vals = []
    for _ in range(n):
        y, x = logu(1e-30, 1e30), logu(1e-30, 1e30)
        if rng.random() < 0.2: y = x * 2.0 ** rng.randint(55, 70)
        vals += [y, x]
    f.write(struct.pack(f'<{2 * n}d', *vals))
