"""gen_probes.py OUT_BASENAME SEED: Date (MakeTime/MakeDate callers) and parseInt probes, one console.log per line; writes OUT.pts and OUT.mjs."""
import random, sys

out, seed = sys.argv[1], int(sys.argv[2])
rng = random.Random(seed)
lines = []

def f(x):  # a JS number literal for the double nearest to the integer x
    return repr(float(x))

# MakeTime: products that are inexact and cancel, in each pair of fields.
for _ in range(150):
    H = rng.randint(10**12, 10**20) * rng.choice((-1, 1))
    M = -(H * 60) + rng.randint(-10**6, 10**6)
    lines.append(f"Date.UTC(1970, 0, 1, {f(H)}, {f(M)})")
    S = -(H * 3600) + rng.randint(-10**6, 10**6)
    lines.append(f"Date.UTC(1970, 0, 1, {f(H)}, 0, {f(S)})")
    Mi = rng.randint(10**12, 10**19) * rng.choice((-1, 1))
    S2 = -(Mi * 60) + rng.randint(-10**6, 10**6)
    lines.append(f"Date.UTC(2000, 5, 15, 0, {f(Mi)}, {f(S2)})")
    S3 = rng.randint(10**13, 10**19) * rng.choice((-1, 1))
    lines.append(f"Date.UTC(1970, 0, 1, {f(H)}, {f(M)}, {f(S3)}, {f(-S3 * 1000 + rng.randint(-10**6, 10**6))})")
    # three-way: hours, minutes and seconds all large
    A = rng.randint(10**14, 10**18)
    lines.append(f"Date.UTC(1970, 0, 1, {f(A)}, {f(-A * 30)}, {f(-A * 1800 + rng.randint(-10**5, 10**5))})")
    # setters run MakeTime and MakeDate too
    lines.append(f"new Date(0).setUTCHours({f(H)}, {f(M)})")
    lines.append(f"new Date(86400000 * 1234).setUTCMinutes({f(Mi)}, {f(S2)})")
    lines.append(f"new Date(2000, 0, 1).setHours({f(H)}, {f(M)})")
    lines.append(f"new Date(2000, 0, 1, {f(H)}, {f(M)}).getTime()")
    # MakeDate: a huge day count against a huge time, through each caller
    D = rng.randint(10**10, 10**12) * rng.choice((-1, 1))
    T = -(D * 86400000) + rng.randint(-10**9, 10**9)
    lines.append(f"Date.UTC(1970, 0, {f(D)}, 0, 0, 0, {f(T)})")
    lines.append(f"new Date(0).setUTCDate({f(D)})")
    lines.append(f"new Date(Date.UTC(1970, 0, {f(D)}, 0, 0, 0, {f(T)})).setUTCDate(5)")
    lines.append(f"new Date(1970, 0, {f(D)}, 0, 0, 0, {f(T)}).getTime()")
    lines.append(f"new Date(1e12).setUTCFullYear(1970, 0, {f(D)})")

# parseInt: other radixes with leading zeros, signs, whitespace, junk, prefixes.
alphabet = "0123456789abcdefghijklmnopqrstuvwxyz"
spaces = ["", " ", "\\t", "\\n", "\\u00a0", "\\ufeff", "\\u2003", "\\u3000"]
radixes = [r for r in range(2, 37) if r not in (2, 4, 8, 10, 16, 32)]
for _ in range(1500):
    r = rng.choice(radixes)
    n = rng.choice((1, 2, 5, 7, 8, 13, 20, 40, 80, 200))
    digits = "".join(rng.choice(alphabet[:r]) for _ in range(n))
    if rng.random() < 0.5:
        digits = digits.upper() if rng.random() < 0.3 else digits
    zeros = "0" * rng.choice((0, 0, 1, 2, 3, 5, 6, 7, 11, 20))
    sign = rng.choice(("", "", "-", "+"))
    junk = rng.choice(("", "", "!", ".5", " 12", "_"))
    s = rng.choice(spaces) + sign + zeros + digits + junk
    lines.append(f'parseInt("{s}", {r})')
for r in radixes + [36]:
    for s in ("0", "00", "-000", "+0000", "0000000000000000000000000000000001", "0x1z", "00x1z", "-0x0", "0.", "  -00"):
        lines.append(f'parseInt("{s}", {r})')
        lines.append(f'Object.is(parseInt("{s}", {r}), -0)')
for s in ("0x1f", "0X0001f", "-0x000000000000000000000000000001ffffffffffffffffff", "000000000000000000017"):
    lines.append(f'parseInt("{s}")')
    lines.append(f'parseInt("{s}", 16)')

body = "".join(f"console.log({l});\n" for l in lines)
open(out + ".pts", "w").write(body)
open(out + ".mjs", "w").write(body)
print(len(lines))
