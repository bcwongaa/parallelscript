// x.toString(r) for random doubles and radixes; with a fixed LCG so both Nodes see the same inputs.
let s = 12345n;
const next = () => { s = (s * 6364136223846793005n + 1442695040888963407n) & 0xFFFFFFFFFFFFFFFFn; return s; };
const buf = new DataView(new ArrayBuffer(8));
const out = [];
for (let i = 0; i < 30000; i++) {
  let x;
  if (i % 3 === 0) { buf.setBigUint64(0, next()); x = buf.getFloat64(0); if (!Number.isFinite(x)) continue; }
  else x = (Number(next() >> 11n) / 2 ** 53) * 10 ** (Number(next() % 40n) - 20);
  const r = 2 + Number(next() % 35n);
  out.push(x.toString(r), (x * 1.5).toFixed(Number(next() % 21n)), x.toPrecision(1 + Number(next() % 21n)), (x ** 0.37).toString(), (x % 7.3).toString());
}
console.log(out.join("\n"));
