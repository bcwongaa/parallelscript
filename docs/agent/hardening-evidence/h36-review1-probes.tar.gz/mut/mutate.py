"""mutate.py SRC OUT OLD NEW: OUT is SRC with the one occurrence of OLD replaced by NEW (fails unless exactly one)."""
import sys
src, out, old, new = sys.argv[1:]
text = open(src).read()
assert text.count(old) == 1, (old, text.count(old))
open(out, 'w').write(text.replace(old, new))
