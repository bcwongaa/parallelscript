H36 CI-fix review round 1 probes (reviewer). Regenerate inputs, then run the scripts:
  math/:  python3 -I gen_inputs.py in 40000 20261026; python3 -I gen_inputs.py in2 400000 777 (keep cbrt/log/log10/log1p), python3 -I gen_in2_extra.py
          build: see the clang lines in the review (harness.c + pts/runtime/src/ieee754.c with ../stub/pts.h), run_x86.sh, run_a64.sh, run_a64_2.sh
  probes/: python3 -I gen_probes.py dp 90210; TZ=America/New_York node dp.mjs; pts build [--target aarch64-linux] dp.pts
  mut/:    mutate.py (7 site mutants), blockmut/: make_mutants.py + tsv_inputs.py + run_mutants.sh (52 unfused-block mutants)
  pp/:     pp_check.sh (preprocessor/object equivalence)
  tsv/:    exprs.mjs from the TSV, both Nodes' outputs; fidelity/: qemu Node vs the CI runner's values
  logs/:   go test logs (RED/GREEN, qemu differential runs)
