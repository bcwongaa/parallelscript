"""tsv_inputs.py TSV OUTDIR: the Math rows of TSV as OUTDIR/<fn>.bin inputs and OUTDIR/<fn>.want (arm64 column) raw doubles."""
import re, struct, sys, collections
rows = collections.defaultdict(list)
for line in open(sys.argv[1]):
    if line.startswith('#'): continue
    expr, x64, a64 = line.rstrip('\n').split('\t')
    m = re.fullmatch(r'Math\.(\w+)\((.*)\)', expr)
    if not m: continue
    args = [float(a) for a in m.group(2).split(',')]
    rows[m.group(1)].append((args, float(a64)))
for fn, rs in rows.items():
    open(f'{sys.argv[2]}/{fn}.bin', 'wb').write(b''.join(struct.pack(f'<{len(a)}d', *a) for a, _ in rs))
    open(f'{sys.argv[2]}/{fn}.want', 'wb').write(b''.join(struct.pack('<d', w) for _, w in rs))
    print(fn, len(rs))
