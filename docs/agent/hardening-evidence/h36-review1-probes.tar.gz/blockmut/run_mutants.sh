#!/bin/bash
# run_mutants.sh: build each m<k>.c into an aarch64 harness; count TSV rows (tsvin/) and random inputs (../math/in, in2) that differ from arm64 Node.
cd /tmp/pts-h36/review1/blockmut
H=../math/harness_a64.o
for c in m??.c; do k=${c%.c}
  clang --target=aarch64-linux-gnu -O2 -g0 -ffp-contract=off -fno-math-errno -I ../stub -I /home/bryan/projects/parallelscript/pts/runtime/src -c $c -o $k.o 2>/dev/null && clang --target=aarch64-linux-gnu -static $H $k.o -lm -o $k.bin || { echo "$k BUILD FAILED"; continue; }
  tsv=0; for f in tsvin/*.bin; do n=$(basename $f .bin); ./$k.bin $n < $f > $k.$n.tsvout; d=$(python3 -I ../math/cmp.py $k.$n.tsvout tsvin/$n.want | cut -d' ' -f1); tsv=$((tsv+d)); done
  rnd=0; for f in ../math/in/*.bin; do n=$(basename $f .bin); ./$k.bin $n < $f > $k.$n.rout; d=$(python3 -I ../math/cmp.py $k.$n.rout ../math/out/nodea64/$n.bin | cut -d' ' -f1); rnd=$((rnd+d)); done
  for f in ../math/in2/*.bin; do b=$(basename $f .bin); n=${b%%_*}; ./$k.bin $n < $f > $k.$b.r2out; d=$(python3 -I ../math/cmp.py $k.$b.r2out ../math/out2/$b.nodea64 | cut -d' ' -f1); rnd=$((rnd+d)); done
  echo "$k tsv_rows_failing=$tsv random_inputs_failing=$rnd"
  rm -f $k.*out $k.o
done
