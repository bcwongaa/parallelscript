"""make_mutants.py SRC OUTDIR: for each `#if PTS_V8_GCC_FMA` block k, OUTDIR/m<k>.c is SRC with that block's fused branch replaced by its #else branch; prints k, the first line and the enclosing function of each block."""
import os, re, sys
src, outdir = sys.argv[1], sys.argv[2]
lines = open(src).read().split('\n')
blocks = []  # (if_line, else_line or None, endif_line)
i = 0
while i < len(lines):
    if lines[i].strip() == '#if PTS_V8_GCC_FMA':
        j = i + 1; e = None
        while lines[j].strip() != '#endif':
            if lines[j].strip() == '#else': e = j
            j += 1
        blocks.append((i, e, j)); i = j
    i += 1
func = None
for k, (a, e, b) in enumerate(blocks):
    fused = lines[a + 1:e if e else b]
    unfused = lines[e + 1:b] if e else []
    out = lines[:a] + unfused + lines[b + 1:]
    open(os.path.join(outdir, f'm{k:02d}.c'), 'w').write('\n'.join(out))
    fn = next((l for l in reversed(lines[:a]) if re.match(r'^(static |double |int )\S.*\(', l)), '?')
    print(k, a + 1, fn.split('(')[0].split()[-1], '|', fused[0].strip()[:70])
