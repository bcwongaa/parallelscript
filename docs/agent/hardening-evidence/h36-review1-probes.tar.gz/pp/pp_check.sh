#!/bin/bash
# pp_check.sh: preprocess HEAD's, the new and the reproducer's prototype ieee754.c for x86-64 and aarch64 Linux and compare
# (whitespace-normalised); then strip the fused branches from the new file and diff with HEAD byte-for-byte; then compare
# x86-64 object code of HEAD and new. Inputs: head_ieee754.c (git show HEAD:pts/runtime/src/ieee754.c), new_ieee754.c,
# proto_ieee754.c (/tmp/pts-h36/fma/proto.c) with protoinc/v8_fma_internal.h (/tmp/pts-h36/fma/proto_v8.h), newinc/v8_fma_internal.h.
cd "$(dirname "$0")"
for t in x86_64-linux-gnu aarch64-linux-gnu; do for v in head new proto; do clang --target=$t -E -P -I ../stub -I ${v}inc ${v}_ieee754.c -o $v-$t.i; done; done
norm() { tr -s ' \t\n' ' ' < $1 | sed 's/ *\([(),;{}*+=-]\) */\1/g'; }
for t in x86_64-linux-gnu aarch64-linux-gnu; do for p in head proto; do norm new-$t.i > n.txt; norm $p-$t.i > p.txt; cmp -s n.txt p.txt && echo "new == $p on $t" || echo "new != $p on $t"; done; done
for t in x86_64-linux-gnu aarch64-linux-gnu; do for v in head new; do clang --target=$t -O2 -g0 -ffp-contract=off -fno-math-errno -falign-functions=32 -std=c11 -Wall -Wextra -Wshadow -I ../stub -I ${v}inc -c ${v}_ieee754.c -o $v-$t.o 2> $v-$t.warn; echo "$v $t rc=$? warnings=$(grep -c warning: $v-$t.warn)"; done; done
for v in head new; do objdump -d --no-show-raw-insn $v-x86_64-linux-gnu.o | sed 1,3d | sed 's/^ *[0-9a-f]*://' > $v-x86.dis; done
cmp head-x86.dis new-x86.dis && echo "x86 object code identical"
