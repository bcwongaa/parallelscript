#!/bin/bash
printf '%q ' "$@" >> /tmp/h06b/review3/cc/cc.log; echo >> /tmp/h06b/review3/cc/cc.log
exec clang "$@"
