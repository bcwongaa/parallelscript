class Base { name: string; constructor(n: string) { this.name = n; } }
class P extends Base { x: number; constructor(x: number) { super("p"); this.x = x; } }
interface I { x: number }
type Pair = [number, string];
type Fn = (x: number) => number;
function show(label: string, f: () => unknown): void {
  try { const v = f(); console.log(label, typeof v === "function" ? "fn" : v); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
function holey<T>(value: T): T[] { const a = new Array<T>(3); a[1] = value; return a; }
const a = holey<P>(new P(1));
show("findIndex", () => a.findIndex((v: Base | undefined) => v === undefined));
show("findLastIndex", () => a.findLastIndex((v: Base | undefined) => v === undefined));
show("find", () => a.find((v: Base | undefined) => v !== undefined));
show("findLast", () => a.findLast((v: Base | undefined) => v !== undefined));
show("from", () => Array.from(a, (v: Base | undefined) => (v === undefined ? "hole" : "el")));
show("forEach", () => { let k = 0; a.forEach((v: Base | undefined) => { k++; }); return k; });
show("filter", () => a.filter((v: Base | undefined) => true).length);
show("some", () => a.some((v: Base | undefined) => v === undefined));
show("map", () => Object.keys(a.map((v: Base | undefined) => 1)).length);
