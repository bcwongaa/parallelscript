import os, sys
out = sys.argv[1]
prelude = '''class Base { name: string; constructor(n: string) { this.name = n; } }
class P extends Base { x: number; constructor(x: number) { super("p"); this.x = x; } }
interface I { x: number }
type Pair = [number, string];
type Fn = (x: number) => number;
function show(label: string, f: () => unknown): void {
  try { const v = f(); console.log(label, typeof v === "function" ? "fn" : v); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
function holey<T>(value: T): T[] { const a = new Array<T>(3); a[1] = value; return a; }
'''
fams = {
  'P': ('P', 'new P(1)', 'v.x'),
  'I': ('I', '{ x: 2 }', 'v.x'),
  'Pair': ('Pair', '[3, "c"] as Pair', 'v[1]'),
  'Arr': ('number[]', '[4.5]', 'v[0]'),
  'Fn': ('Fn', '((x: number) => x * 5) as Fn', 'v(2)'),
  'Map': ('Map<string, number>', 'new Map([["k", 6.5]])', 'v.get("k")'),
  'Str': ('string', '"s"', 'v.length'),
  'Lit': ('"a" | "b"', '"b" as "a" | "b"', 'v'),
  'Nul': ('string | null', '"n" as string | null', 'v'),
  'Uni': ('P | I', '{ x: 7 } as P | I', 'v.x'),
}
wider = {
  'P': ['Base | undefined', '{ x: number } | undefined'],
  'I': ['{ x: number | string } | undefined'],
  'Pair': ['(number | string)[] | undefined', 'readonly [number, string] | undefined'],
  'Arr': ['(number | string)[] | undefined', 'readonly number[] | undefined', 'unknown[] | undefined'],
  'Fn': ['((x: number) => unknown) | undefined', '((y: number) => number) | undefined'],
  'Map': ['Map<string, unknown> | undefined', 'ReadonlyMap<string, number> | undefined'],
  'Str': ['string | number | undefined', '{ length: number } | undefined'],
  'Lit': ['string | undefined', '"a" | "b" | "c" | undefined'],
  'Nul': ['string | null | number | undefined'],
  'Uni': ['P | I | string | undefined', 'I | undefined'],
}
n = 0
for fam, (t, val, use) in fams.items():
    params = [t if '|' not in t else t, f'{t} | undefined' if '|' not in t else f'{t} | undefined', 'unknown', 'any'] + wider[fam]
    params = list(dict.fromkeys([f'({t}) | undefined' if '|' in t else f'{t} | undefined', 'unknown', 'any'] + wider[fam]))
    for i, p in enumerate(params):
        n += 1
        name = f'{out}/g_{fam}_{i}.pts'
        test = 'v === undefined'
        body = prelude + f'const a = holey<{t}>({val});\n'
        body += f'show("findIndex", () => a.findIndex((v: {p}) => {test}));\n'
        body += f'show("findLastIndex", () => a.findLastIndex((v: {p}) => {test}));\n'
        body += f'show("find", () => a.find((v: {p}) => v !== undefined));\n'
        body += f'show("findLast", () => a.findLast((v: {p}) => v !== undefined));\n'
        body += f'show("from", () => Array.from(a, (v: {p}) => (v === undefined ? "hole" : "el")));\n'
        body += f'show("forEach", () => {{ let k = 0; a.forEach((v: {p}) => {{ k++; }}); return k; }});\n'
        body += f'show("filter", () => a.filter((v: {p}) => true).length);\n'
        body += f'show("some", () => a.some((v: {p}) => v === undefined));\n'
        body += f'show("map", () => Object.keys(a.map((v: {p}) => 1)).length);\n'
        open(name, 'w').write(body)
print(n)
