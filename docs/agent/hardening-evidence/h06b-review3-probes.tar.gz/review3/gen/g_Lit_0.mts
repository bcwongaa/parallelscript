class Base { name: string; constructor(n: string) { this.name = n; } }
class P extends Base { x: number; constructor(x: number) { super("p"); this.x = x; } }
interface I { x: number }
type Pair = [number, string];
type Fn = (x: number) => number;
function show(label: string, f: () => unknown): void {
  try { const v = f(); console.log(label, typeof v === "function" ? "fn" : v); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
function holey<T>(value: T): T[] { const a = new Array<T>(3); a[1] = value; return a; }
const a = holey<"a" | "b">("b" as "a" | "b");
show("findIndex", () => a.findIndex((v: ("a" | "b") | undefined) => v === undefined));
show("findLastIndex", () => a.findLastIndex((v: ("a" | "b") | undefined) => v === undefined));
show("find", () => a.find((v: ("a" | "b") | undefined) => v !== undefined));
show("findLast", () => a.findLast((v: ("a" | "b") | undefined) => v !== undefined));
show("from", () => Array.from(a, (v: ("a" | "b") | undefined) => (v === undefined ? "hole" : "el")));
show("forEach", () => { let k = 0; a.forEach((v: ("a" | "b") | undefined) => { k++; }); return k; });
show("filter", () => a.filter((v: ("a" | "b") | undefined) => true).length);
show("some", () => a.some((v: ("a" | "b") | undefined) => v === undefined));
show("map", () => Object.keys(a.map((v: ("a" | "b") | undefined) => 1)).length);
