function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 70)); }
}
class P { x: number; constructor(x: number) { this.x = x; } }
show("string pop", () => { const a = new Array<string>(3); a[0] = "a"; const v = a.pop(); return [v, v === undefined, a.length, a]; });
show("string shift", () => { const a = new Array<string>(3); a[2] = "c"; const v = a.shift(); return [v, v === undefined, a.length, a]; });
show("P pop", () => { const a = new Array<P>(2); a[0] = new P(1); const v = a.pop(); return [v, v === undefined, a.length]; });
show("maybe pop", () => { const a = new Array<number | undefined>(2); a[0] = 1; return [a.pop(), a.length, a.pop(), a.length, a.pop(), a.length]; });
show("any pop", () => { const a: any = new Array(2); a[0] = 1; return [a.pop(), a.length, a.shift(), a.length]; });
show("any[] shift", () => { const a: any[] = new Array(2); a[1] = "b"; return [a.shift(), a.length, a]; });
show("pop!", () => { const a = new Array<string>(2); return a.pop()!; });
show("shift!", () => { const a = new Array<string>(2); return a.shift()!; });
show("match pop", () => { const m = /(a)|(b)/.exec("xb")!; return [m.pop(), m.pop(), m.length]; });
show("match shift", () => { const m = /(a)|(b)/.exec("xb")!; return [m.shift(), m.shift(), m.length, m]; });
show("match pop any", () => { const m: any = /(a)|(b)/.exec("xb")!; return [m.pop(), m.pop(), m.length]; });
show("match copy pop!", () => { const m = /(a)|(b)/.exec("xb")!.slice(0, 2); return m.pop()!; });
show("frozen pop", () => { const a = Object.freeze(new Array<string>(2)); return (a as string[]).pop(); });
show("frozen empty pop", () => { const a: string[] = []; Object.freeze(a); return a.pop(); });
show("frozen empty shift any", () => { const a: any = Object.freeze([]); return a.shift(); });
show("frozen any pop hole", () => { const a: any = Object.freeze(new Array(2)); return a.pop(); });
show("empty pop", () => { const a: string[] = []; return [a.pop(), a.shift(), a.length]; });
show("pop then push", () => { const a = new Array<string>(2); a.pop(); a.push("z"); return [a, Object.keys(a)]; });
show("shift holey keys", () => { const a = new Array<string>(3); a[1] = "b"; a.shift(); return [a, Object.keys(a), 0 in a]; });
show("number pop", () => { const a = new Array<number>(2); return [a.pop(), a.length]; });
show("bool shift", () => { const a = new Array<boolean>(2); return [a.shift(), a.length]; });
show("narrow after pop", () => { const a = new Array<string | null>(2); const v = a.pop(); return v === undefined ? "undef" : v === null ? "null" : v.length; });
