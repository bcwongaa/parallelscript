function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 60)); }
}
class P { x: number; constructor(x: number) { this.x = x; } }
function holeyP(): P[] { const a = new Array<P>(3); a[1] = new P(1); return a; }
function firstMissing<T>(xs: T[]): number { return xs.findIndex((x: T | undefined) => x === undefined); }
const erased = <T,>(xs: T[]): number => xs.findIndex((x: T | undefined) => x === undefined);
const erasedFilter = <T,>(xs: T[]): number => xs.filter((x: T | undefined) => x !== undefined).length;
show("mono P", () => firstMissing(holeyP()));
show("mono fn", () => firstMissing([() => 1, () => 2]));
show("mono nested", () => firstMissing([[1], [2]]));
show("erased P", () => erased(holeyP()));
show("erased filter", () => erasedFilter(holeyP()));
show("erased strings", () => erased(new Array<string>(2)));
function findBy<T>(xs: T[], p: (x: T | undefined) => boolean): T | undefined { return xs.find(p); }
show("findBy fn", () => typeof findBy([(n: number) => n * 2], (f) => f !== undefined && f(2) === 4));
show("findBy arrays", () => findBy([[1.5], [2]], (a) => a !== undefined && a[0] === 2));
show("par find widened", () => holeyP().par.find((p: P | undefined) => p !== undefined)?.x);
show("par map widened", () => holeyP().par.map((p: P | undefined) => p?.x ?? -1));
