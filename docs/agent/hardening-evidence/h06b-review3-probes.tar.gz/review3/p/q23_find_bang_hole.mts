class P { x: number; constructor(x: number) { this.x = x; } }
function holeyP(): P[] { const a = new Array<P>(3); a[1] = new P(1); return a; }
try { const p = holeyP().find((q: P | undefined) => q === undefined)!; console.log("got", p); } catch (e) { console.log("threw", (e as Error).name, (e as Error).message); }
const m = /(a)|(b)/.exec("xb")!;
try { const s = m.find((x: string | undefined) => x === undefined)!; console.log("got", s); } catch (e) { console.log("threw", (e as Error).name, (e as Error).message); }
try { const s = m.slice(1).reduce((acc: string, x: string | undefined) => acc + x); console.log("got", s); } catch (e) { console.log("threw", (e as Error).name, (e as Error).message); }
