function holey(): string[] { const a = new Array<string>(2); a[1] = "h"; return a; }
const m = /(a)|(b)/.exec("xb")!;
const c = m.concat(holey());
console.log("concat", c, Object.keys(c), 3 in c);
const d = m.slice().concat(holey());
console.log("copy concat", d, Object.keys(d));
const e: string[] = ["q"];
e.push(...m);
const f = e.concat(holey());
console.log("switched concat", f, Object.keys(f));
const g = [...m, ...holey()];
console.log("spread", g, Object.keys(g));
