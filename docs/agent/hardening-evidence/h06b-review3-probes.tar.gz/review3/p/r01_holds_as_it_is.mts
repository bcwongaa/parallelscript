function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 70)); }
}
class P { x: number; constructor(x: number) { this.x = x; } }
interface I { x: number }
type Pair = [number, string];
type Fn = (x: number) => number;
function holey<T>(value: T): T[] { const a = new Array<T>(3); a[1] = value; return a; }
show("class", () => { const a = holey(new P(1)); const i = a.findIndex((p: P | undefined) => p === undefined); a.find((p: P | undefined) => { if (p) p.x = 9; return false; }); return [i, a[1].x]; });
show("interface", () => { const a = holey<I>({ x: 1 }); const i = a.findLastIndex((p: I | undefined) => p === undefined); a.find((p: I | undefined) => { if (p) p.x = 8; return false; }); return [i, a[1].x]; });
show("tuple", () => { const a = holey<Pair>([1, "a"]); const i = a.findIndex((t: Pair | undefined) => t === undefined); a.find((t: Pair | undefined) => { if (t) t[0] = 7; return false; }); return [i, a[1][0]]; });
show("array", () => { const a = holey<number[]>([1.5]); const i = a.findIndex((t: number[] | undefined) => t === undefined); a.find((t: number[] | undefined) => { t?.push(2.5); return false; }); return [i, a[1]]; });
show("readonly array", () => { const a = holey<number[]>([1.5]); return a.findIndex((t: readonly number[] | undefined) => t !== undefined && t[0] === 1.5); });
show("function", () => { const a = holey<Fn>((x) => x * 3); const i = a.findIndex((f: Fn | undefined) => f === undefined); const j = a.findIndex((f: Fn | undefined) => f !== undefined && f(2) === 6); return [i, j]; });
show("function renamed", () => { const a = holey<Fn>((x) => x * 3); return a.findIndex((f: ((y: number) => number) | undefined) => f !== undefined && f(2) === 6); });
show("map", () => { const a = holey(new Map<string, number>()); a.find((m: Map<string, number> | undefined) => { m?.set("k", 1.5); return false; }); return [a.findIndex((m: Map<string, number> | undefined) => m === undefined), a[1].get("k")]; });
show("set", () => { const a = holey(new Set<string>()); a.find((s: Set<string> | undefined) => { s?.add("q"); return false; }); return a[1]; });
show("literals", () => { const a = holey<"a" | "b">("b"); return [a.findIndex((x: "a" | "b" | undefined) => x === undefined), a.find((x: "a" | "b" | undefined) => x === "b")]; });
show("union elem", () => { const a = holey<P | I>({ x: 2 }); return [a.findIndex((u: P | I | undefined) => u === undefined), a.findIndex((u: P | I | string | undefined) => u !== undefined)]; });
show("nullable", () => { const a = holey<string | null>(null); return [a.findIndex((x: string | null | undefined) => x === undefined), a.findIndex((x: string | null | undefined) => x === null)]; });
show("from", () => Array.from(holey(new P(4)), (p: P | undefined) => (p === undefined ? "hole" : p.x)));
show("from tuple", () => Array.from(holey<Pair>([1, "z"]), (t: Pair | undefined) => (t === undefined ? "hole" : t[1])));
type A = { x: number };
type B = { x: number };
show("alias shapes", () => { const a = holey<A>({ x: 5 }); return a.findIndex((b: B | undefined) => b === undefined); });
show("unknown", () => { const a = holey<Pair>([3, "u"]); return a.findIndex((t: unknown) => t === undefined); });
