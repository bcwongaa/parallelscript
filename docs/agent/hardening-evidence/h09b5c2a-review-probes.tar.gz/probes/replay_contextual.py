import argparse
import json
import os
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repo", type=Path)
parser.add_argument("--original", action="store_true")
args = parser.parse_args()
repo = args.repo.resolve()
here = Path(__file__).resolve().parent
replacements = {
    str(repo / "pts/lower/review_c2a_contextual_test.go"): str(here / "contextual_generic_test.go")
}
if args.original:
    replacements[str(repo / "pts/lower/returned_values.go")] = str(here / "original-returned_values.go")
overlay = here / ("replay-original-overlay.json" if args.original else "replay-corrected-overlay.json")
overlay.write_text(json.dumps({"Replace": replacements}, indent=2) + "\n")
command = [
    "go", "test", "-count=1", "-json", "-p", "1", "-parallel", "1",
    "-timeout", "10m", "-overlay", str(overlay), "./pts/lower",
    "-run", "TestReviewC2aContextualGenericFactoryBoundary",
]
environment = os.environ.copy()
environment["GOMAXPROCS"] = "1"
completed = subprocess.run(command, cwd=repo, env=environment)
sys.exit(completed.returncode)
