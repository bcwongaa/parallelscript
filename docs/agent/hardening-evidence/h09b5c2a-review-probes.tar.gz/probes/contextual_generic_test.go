package lower

import (
	"testing"

	"gotest.tools/v3/assert"
)

func TestReviewC2aContextualGenericFactoryBoundary(t *testing.T) {
	for _, body := range []string{
		"const returned: <U>(x: U) => Fn = x => first; const probe = returned(0); probe;",
		"const returned: <U>(x: U) => Fn = function(x) { return first; }; const probe = returned(0); probe;",
	} {
		t.Run(body, func(t *testing.T) {
			l, probe := valueFlowProbe(t, returnedSourcesPrelude+body)
			call := l.target(probe).ValueDeclaration.Initializer().AsCallExpression()
			steps := maxValueFlowSteps
			callees := l.valueSources(call.Expression, &steps, 0)
			assert.Equal(t, len(callees), 1)
			for fn := range callees {
				assert.Equal(t, len(fn.TypeParameters()), 0, "these factories are generic through context, not explicit syntax")
				typeParameters := l.checker.GetSignatureFromDeclaration(fn).TypeParameters()
				assert.Assert(t, len(typeParameters) > 0, "the checker must actually classify the contextual factory as generic")
				t.Logf("syntactic type parameters=%d, checker type parameters=%d", len(fn.TypeParameters()), len(typeParameters))
			}
			steps = maxValueFlowSteps
			sources := l.valueSources(probe, &steps, 0)
			if sources != nil {
				t.Logf("proven sources=%v", returnedSourceNames(sources))
			}
			assert.Assert(t, sources == nil, "D-202 excludes generic factories, including factories generic through context")
		})
	}
}
