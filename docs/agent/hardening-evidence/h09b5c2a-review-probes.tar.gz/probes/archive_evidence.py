import hashlib
import json
from pathlib import Path
import tarfile

here = Path(__file__).resolve().parent
repo = here.parent
snapshot_names = [
    "pts/lower/value_flow.go",
    "pts/lower/returned_values.go",
    "pts/lower/returned_value_sources_test.go",
    "pts/driver/returned_value_sources_test.go",
    "pts/tests/run/generic_value_flow_returned_sources.pts",
    "pts/tests/run/generic_value_flow_returned_unknowns.pts",
]
allowed_suffixes = {".go", ".py", ".json", ".jsonl", ".stderr", ".stdout", ".txt", ".diff", ".pts", ".mts", ".c"}
files = [p for p in sorted(here.iterdir()) if p.is_file() and not p.is_symlink() and p.suffix in allowed_suffixes and p.name != "manifest.json"]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

manifest = {
    "base": "9988a04c3",
    "runtime_surfaced": "gpt-6.1-sol",
    "snapshot_sha256": {name: sha(repo / name) for name in snapshot_names},
    "probe_sha256": {p.name: sha(p) for p in files},
    "binaries_included": False,
    "archive_is_review_evidence_not_acceptance_of_h09b5b": True,
}
manifest_path = here / "manifest.json"
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
archive = here / "h09b5c2a-review-probes.tar.gz"
with tarfile.open(archive, "w:gz") as output:
    for path in files + [manifest_path]:
        output.add(path, arcname="probes/" + path.name, recursive=False)
    for name in snapshot_names:
        output.add(repo / name, arcname="snapshot/" + name, recursive=False)
with tarfile.open(archive, "r:gz") as check:
    members = check.getmembers()
    assert all(member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts for member in members)
    assert all(not member.name.endswith((".bin", ".a", ".o", ".so")) for member in members)
print(archive)
print("members", len(members), "compressed_bytes", archive.stat().st_size)
print("sha256", sha(archive))
