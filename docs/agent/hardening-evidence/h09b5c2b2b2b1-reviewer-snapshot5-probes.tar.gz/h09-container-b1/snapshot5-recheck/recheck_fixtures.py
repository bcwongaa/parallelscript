#!/usr/bin/env python3
"""Serial exact-base/current/native/strict-Node recheck of snapshot5 fixtures.

Run from any directory with Python -I. The saved probe executables are built from
cmd/main.go one directory above; the compiler's native mode uses AllInstances
alone and clang, never the driver's fallback. No repository source is modified.
"""
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

scratch = pathlib.Path(__file__).resolve().parent
previous = scratch.parent
root = previous.parents[1]
env = dict(os.environ, GOMAXPROCS="1", PTS_HOME="/home/bryan/projects/parallelscript", PTS_CC="clang")

def command(args, timeout=180):
    result = subprocess.run([str(a) for a in args], capture_output=True, text=True,
                            timeout=timeout, cwd=root, env=env)
    return {"cmd": [str(a) for a in args], "returncode": result.returncode,
            "stdout": result.stdout, "stderr": result.stderr}

cases = (
    ("original_safe", scratch / "original_safe.pts", scratch / "original_safe.mts", True),
    ("positive", root / "pts/tests/run/generic_literal_projection_dispatched_total.pts", scratch / "positive.mts", True),
    ("negative", root / "pts/tests/errors/generic_fallback_keeps_dispatched_totals.pts", scratch / "negative.mts", False),
)
records = []
problems = []
for name, source, mts, current_success in cases:
    node = command(["/home/bryan/.local/node/bin/node", "--experimental-transform-types",
                    "--disable-warning=ExperimentalWarning", mts], 30)
    record = {"name": name, "source": str(source),
              "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "node": node}
    if node["returncode"] != 0 or node["stdout"] != "recursion 6\n" or node["stderr"]:
        problems.append(name + ": unexpected strict-Node result")
    for version in ("base", "current"):
        output = scratch / (name + "." + version + ".bin")
        built = command([previous / (version + "-probe"), "native", source, output])
        item = {"build": built}
        wanted_success = version == "current" and current_success
        if built["returncode"] == 0:
            item["run"] = command([output], 30)
            code = pathlib.Path(str(output) + ".c").read_bytes()
            item["c_sha256"] = hashlib.sha256(code).hexdigest()
            item["c_bytes"] = len(code)
            item["rec_method_owner_rows"] = sorted(set(re.findall(rb"\bpts_fn_R([0-5])_rec_", code)))
            item["rec_method_owner_rows"] = [x.decode() for x in item["rec_method_owner_rows"]]
            if item["run"]["returncode"] != 0 or item["run"]["stdout"] != node["stdout"] or item["run"]["stderr"]:
                problems.append(name + "/" + version + ": native disagrees with strict Node")
            output.unlink()
        if (built["returncode"] == 0) != wanted_success:
            problems.append(name + "/" + version + ": unexpected compilation outcome")
        if not wanted_success and ("PTS1001" not in built["stderr"] or "more than 1024 instances (`Box`)" not in built["stderr"]):
            problems.append(name + "/" + version + ": original total diagnostic not retained")
        record[version] = item
    records.append(record)
    print(json.dumps({"name": name, "node_stdout": node["stdout"],
                      "base_build": record["base"]["build"]["returncode"],
                      "current_build": record["current"]["build"]["returncode"],
                      "current_owner_rows": record["current"].get("rec_method_owner_rows")}), flush=True)
receipt = {"records": records, "problems": problems,
           "clang_version": command(["clang", "--version"], 10)}
(scratch / "fixture-native-node-results.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"cases": len(records), "problems": problems}), flush=True)
sys.exit(bool(problems))
