#!/usr/bin/env python3
"""Replay only snapshot5's targeted harness/clang checks, one serial job.

Usage: python3 -I replay_harness_checks.py /absolute/path/to/parallelscript
The repository must already contain frozen snapshot5. Source files are unchanged;
the exact-base check uses a generated Go overlay and the archived base source.
"""
import argparse
import json
import os
import pathlib
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=pathlib.Path)
args = parser.parse_args()
root = args.repository.resolve(strict=True)
scratch = pathlib.Path(__file__).resolve().parent
overlay = scratch / "portable-exact-base-overlay.json"
overlay.write_text(json.dumps({"Replace": {
    str(root / "pts/lower/value_flow.go"): str(scratch / "base-value-flow.go"),
    str(root / "pts/lower/container_sources.go"): str(scratch / "empty-container.go"),
}}, indent=2) + "\n")
env = dict(os.environ, GOMAXPROCS="1", PTS_HOME="/home/bryan/projects/parallelscript",
           PTS_CC="clang", PTS_REQUIRE_NODE="1", PTS_SMOKE_CLANG="1",
           PTS_SMOKE_MUTANTS="0", PTS_SMOKE_JOBS="1",
           PTS_SMOKE_FILTER=r"(generic_fallback_keeps_dispatched_totals|generic_literal_projection_dispatched_total)\.pts$")
common = ["go", "test", "-count=1", "-json", "-p", "1", "-parallel", "1", "-timeout", "15m"]
commands = (
    ("replay-current-harness-clang.jsonl", common + ["-run", r"^(TestErrors|TestRun|TestRunMatchesNode|TestCompilerFailsCleanly)$/^(generic_fallback_keeps_dispatched_totals|generic_literal_projection_dispatched_total)$", "./pts/tests"]),
    ("replay-base-error-harness.jsonl", common + ["-overlay", str(overlay), "-run", r"^TestErrors$/^generic_fallback_keeps_dispatched_totals$", "./pts/tests"]),
)
status = 0
for receipt, command in commands:
    print(json.dumps({"cwd": str(root), "command": command, "receipt": receipt}), flush=True)
    with (scratch / receipt).open("w") as output:
        result = subprocess.run(command, cwd=root, env=env, stdout=output)
    status = status or result.returncode
sys.exit(status)
