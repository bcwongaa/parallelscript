"""Summarize a matrix results JSON: counts by family and by each dimension, whether each case
meets the planned rule (`want`), and per-case lines.

Run: python3 -I summarize.py RESULTS_JSON [--cases] [--family F]

`meets`: want "node" needs OK; want "node|trap" takes OK or a TypeError (the trap's, or
another checked conversion's) where Node printed none.
"""

import json
import sys
from collections import Counter, defaultdict

CLASSES = ["OK", "WRONG", "TYPEERR", "RANGEERR", "PTS1001", "PTS9001", "TSERR", "CRASH", "TIMEOUT", "BUILDFAIL", "NODEFAIL"]
KEYS = {"form": ["narrowing", "use", "kind", "decl"], "lie": ["lie", "use", "group"], "stale": ["narrowing", "ref", "use"],
        "stalelive": ["narrowing", "ref", "use", "changes"], "region": ["shape", "variant"], "tail": ["shape"],
        "generic": ["narrowing", "use", "context"], "decl": ["decl", "narrowing", "use"]}


def meets(r):
    if r["cls"] == "OK":
        return True
    return r.get("want") == "node|trap" and r["cls"] == "TYPEERR"


def table(rows, title):
    used = [c for c in CLASSES if any(r[1][c] for r in rows)]
    print("\n%s" % title)
    print("| value | " + " | ".join(used) + " | meets plan |")
    print("|---|" + "---|" * len(used) + "---|")
    for name, cnt in rows:
        total = sum(cnt[c] for c in CLASSES)
        print("| %s | " % name + " | ".join(str(cnt[c]) if cnt[c] else "" for c in used) + " | %d/%d |" % (cnt["meets"], total))


def count(rs):
    c = Counter(r["cls"] for r in rs)
    c["meets"] = sum(1 for r in rs if meets(r))
    return c


def main():
    results = json.load(open(sys.argv[1]))
    if any("want" not in r for r in results):  # results of an older run.py: take want from cases.json beside them
        import os
        wants = {c["id"]: c.get("want", "node") for c in json.load(open(os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), "cases.json")))}
        for r in results:
            r.setdefault("want", wants.get(r["id"], "node"))
    only = sys.argv[sys.argv.index("--family") + 1] if "--family" in sys.argv else None
    table([("all (%d)" % len(results), count(results))], "## Totals")
    fam = defaultdict(list)
    for r in results:
        fam[r["family"]].append(r)
    table(sorted((k, count(v)) for k, v in fam.items()), "## By family")
    for family, keys in KEYS.items():
        if only and family != only:
            continue
        rs = fam.get(family, [])
        for k in keys:
            by = defaultdict(list)
            order = []
            for r in rs:
                v = r["dims"].get(k, "-")
                if v not in by:
                    order.append(v)
                by[v].append(r)
            table([(v, count(by[v])) for v in order], "## %s by %s" % (family, k))
    if "--cases" in sys.argv:
        print("\n## Cases (id, class, meets plan, want, detail)")
        for r in results:
            if only and r["family"] != only:
                continue
            print("%-70s %-9s %-4s %-9s %s" % (r["id"], r["cls"], "yes" if meets(r) else "no", r.get("want", ""),
                                             r.get("detail", "")[:150].replace("\n", " ")))


if __name__ == "__main__":
    main()
