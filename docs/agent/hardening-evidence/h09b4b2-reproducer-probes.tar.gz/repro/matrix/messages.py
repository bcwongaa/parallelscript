"""Group a results file's non-OK cases by family, class and message (numbers and names blurred).

Run: python3 -I messages.py RESULTS_JSON [--family F] [--examples N]
"""

import json
import re
import sys
from collections import defaultdict


def main():
    results = json.load(open(sys.argv[1]))
    only = sys.argv[sys.argv.index("--family") + 1] if "--family" in sys.argv else None
    n = int(sys.argv[sys.argv.index("--examples") + 1]) if "--examples" in sys.argv else 3
    groups = defaultdict(list)
    for r in results:
        if r["cls"] == "OK" or (only and r["family"] != only):
            continue
        msg = re.sub(r"`[^`]*`", "`…`", r.get("detail", ""))
        groups[(r["family"], r["cls"], msg)].append(r["id"])
    for (family, cls, msg), ids in sorted(groups.items(), key=lambda kv: (kv[0][0], -len(kv[1]))):
        print("%-9s %-8s %3d  %s" % (family, cls, len(ids), msg[:150]))
        for i in ids[:n]:
            print("            " + i)


if __name__ == "__main__":
    main()
