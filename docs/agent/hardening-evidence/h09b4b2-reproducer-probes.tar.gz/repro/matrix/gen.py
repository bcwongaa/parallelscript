"""Generate the H09b4b2 matrix: plain code (and generic code tsc already types never) that tsc
narrows to never or to an intersection no value has. One small program per case; run.py
compares pts with Node.

Run: python3 -I gen.py OUTDIR   (writes OUTDIR/cases/<id>.pts and OUTDIR/cases.json)

Families:
  form      plain narrowing forms (dead, no lie) x uses; the narrowed reference is a parameter
  lie       lies and holes that reach a never/intersection region (lying predicates and
            assertions, cast discriminants, literal unions from a cast, numeric enums out of
            range with no cast, D-090 loose locals) x uses
  stale     staleness of the narrowed reference (const, parameter, lets, module let, property,
            this, tuple element, getter, ...) x {dead typeof, dead Array.isArray, lying predicate}
  stalelive no lie: a first test narrows a union place, a call/await/yield/closure tsc doesn't
            follow changes it, a second test types the live value never or an intersection;
            plus the no-change twins (dead)
  region    dead-region shapes (H09b4's) in plain code x {dead, lie typed use, lie any use}
  tail      hoisted functions and captured bindings around a dead statement
  generic   generic code tsc already types never (x: T & string, ...) x uses x {direct, value}
  decl      declared types x narrowing tests x {typed use, log}

Each case carries `want`: "node" (must print what Node prints) or "node|trap" (a lie used as
its narrowed type: D-195's trap TypeError is the documented outcome; Node's output also fine).
"""

import json
import os
import re
import sys

HELPERS = [
    ("Box", "class Box<T> {\n  constructor(public value: T) {}\n}\n"),
    ("Pt", "class Pt {\n  constructor(public v: number) {}\n}\n"),
    ("Other", "class Other {\n  constructor(public w: number) {}\n}\n"),
    ("Third", "class Third {\n  constructor(public t: number) {}\n}\n"),
    ("Base", "class Base {\n  constructor(public n: number) {}\n}\n"),
    ("Sub1", "class Sub1 extends Base {\n  a = \"a\";\n}\n"),
    ("Sub2", "class Sub2 extends Base {\n  b = \"b\";\n}\n"),
    ("Sq", 'interface Sq {\n  kind: "sq";\n  side: number;\n}\n'),
    ("Ci", 'interface Ci {\n  kind: "ci";\n  r: number;\n}\n'),
    ("Shape", "type Shape = Sq | Ci;\n"),
    ("HasK", "interface HasK {\n  k: number;\n}\n"),
    ("Color", "enum Color {\n  Red,\n  Green,\n}\n"),
    ("Dir", 'type Dir = "up" | "down";\n'),
    ("num", 'function num(v: number): string {\n  return "num " + (v + 1);\n}\n'),
    ("str", 'function str(v: string): string {\n  return "str " + v.length;\n}\n'),
    ("len", 'function len(v: unknown[]): string {\n  return "len " + v.length;\n}\n'),
    ("nums", 'function nums(v: number[]): string {\n  return "nums " + v.length;\n}\n'),
    ("ptv", 'function ptv(p: Pt): string {\n  return "pt " + p.v;\n}\n'),
    ("oth", 'function oth(o: Other): string {\n  return "other " + o.w;\n}\n'),
    ("nul", 'function nul(n: null): string {\n  return "nul " + n;\n}\n'),
    ("und", 'function und(u: undefined): string {\n  return "und " + u;\n}\n'),
    ("nu", 'function nu(v: null | undefined): string {\n  return "nu " + v;\n}\n'),
    ("bool", 'function bool(b: boolean): string {\n  return "bool " + b;\n}\n'),
    ("shp", 'function shp(s: Shape): string {\n  return "shape " + s.kind;\n}\n'),
    ("col", 'function col(c: Color): string {\n  return "color " + c;\n}\n'),
    ("dir", 'function dir(d: Dir): string {\n  return "dir " + d;\n}\n'),
    ("sn", 'function sn(v: string | number): string {\n  return "sn " + typeof v;\n}\n'),
    ("hk", 'function hk(h: HasK): string {\n  return "hk " + h.k;\n}\n'),
    ("sub2", 'function sub2(s: Sub2): string {\n  return "sub2 " + s.b;\n}\n'),
    ("show", 'function show(v: unknown): string {\n  return "show " + String(v);\n}\n'),
    ("flip", "function flip(): boolean {\n  return [1].length > 0;\n}\n"),
    ("isNum", 'function isNum(v: unknown): v is number {\n  return typeof v === "number";\n}\n'),
    ("isArr", "function isArr(v: unknown): v is unknown[] {\n  return Array.isArray(v);\n}\n"),
    ("isPt", "function isPt(v: unknown): v is Pt {\n  return v instanceof Pt;\n}\n"),
    ("isCi", 'function isCi(s: Shape): s is Ci {\n  return s.kind === "ci";\n}\n'),
    ("assertNum", 'function assertNum(v: unknown): asserts v is number {\n  if (typeof v !== "number") {\n    throw new TypeError("not a number: " + String(v));\n  }\n}\n'),
    ("lyingIsNum", "function lyingIsNum(v: unknown): v is number {\n  return true;\n}\n"),
    ("lyingIsArr", "function lyingIsArr(v: unknown): v is unknown[] {\n  return true;\n}\n"),
    ("lyingIsPt", "function lyingIsPt(v: unknown): v is Pt {\n  return true;\n}\n"),
    ("lyingIsOther", "function lyingIsOther(v: unknown): v is Other {\n  return true;\n}\n"),
    ("lyingIsBool", "function lyingIsBool(v: unknown): v is boolean {\n  return true;\n}\n"),
    ("lyingIsNull", "function lyingIsNull(v: unknown): v is null {\n  return true;\n}\n"),
    ("lyingAssertNum", "function lyingAssertNum(v: unknown): asserts v is number {}\n"),
    ("lyingAssertArr", "function lyingAssertArr(v: unknown): asserts v is unknown[] {}\n"),
    ("assertNever", 'function assertNever(x: never): never {\n  throw new Error("unexpected " + JSON.stringify(x));\n}\n'),
    ("maybe", "function maybe(): string | undefined {\n  return undefined;\n}\n"),
    ("note", 'function note(label: string): boolean {\n  console.log("cond", label);\n  return true;\n}\n'),
]
DEPENDS = {"Sub1": ["Base"], "Sub2": ["Base"], "Shape": ["Sq", "Ci"], "shp": ["Shape"], "sub2": ["Sub2"],
           "ptv": ["Pt"], "oth": ["Other"], "hk": ["HasK"], "col": ["Color"], "dir": ["Dir"], "isPt": ["Pt"],
           "lyingIsPt": ["Pt"], "isCi": ["Shape"], "lyingIsOther": ["Other"]}


def prelude(text):
    """The helpers the text names, in a fixed order, with what they need."""
    names = set(h for h, _ in HELPERS if re.search(r"\b%s\b" % h, text))
    changed = True
    while changed:
        changed = False
        for n in list(names):
            for d in DEPENDS.get(n, []):
                if d not in names:
                    names.add(d)
                    changed = True
    return "".join(code for h, code in HELPERS if h in names)


def indent(text, n):
    pad = " " * n
    return "\n".join((pad + line) if line.strip() else line for line in text.strip("\n").split("\n"))


def fill(template, body):
    """Replace each line holding only @BODY@ with body, indented as that line."""
    out = []
    for line in template.split("\n"):
        if line.strip() == "@BODY@":
            out.append(indent(body, len(line) - len(line.lstrip())))
        else:
            out.append(line)
    return "\n".join(out)


def ends_flow(body):
    last = body.strip().split("\n")[-1].strip()
    return last.startswith("return ") or last.startswith("throw ") or last.startswith("assertNever(")


def caught(call):
    return ('try {\n  console.log("result", %s);\n} catch (error: any) {\n  console.log("caught", error.name, error.message);\n}\n' % call)


CASES = []


def add(cid, family, dims, code, want="node", note=""):
    text = prelude(code) + code
    CASES.append({"id": cid, "family": family, "dims": dims, "code": text, "want": want, "note": note})


# ------------------------------------------------------------------------------------- uses
# A use is (name, group, needs, body template). {R} is the reference, {C} the consumer of
# the tested type, {T} the tested type, {DC} the consumer of the declared type, {D} the
# declared type, {M} the member an intersection's tested type has, {L} a live value of the
# declared type. needs: "never" (only where tsc says never), "inter" (only intersections),
# "arith" (where `R + 1` type-checks), "" (always).
USES = [
    ("arith", "typed", "arith", 'console.log("region", {R} + 1);'),
    ("param", "typed", "", 'console.log("region", {C}({R}));'),
    ("member", "typed", "inter", 'console.log("region", {R}{M});'),
    ("copy_typed", "typed", "", "const t: {T} = {R};\nconsole.log(\"region\", t);"),
    ("copy_untyped", "typed", "", "const y = {R};\nconsole.log(\"region\", {C}(y));"),
    ("new_box", "typed", "", 'console.log("region", new Box({R}).value);'),
    ("cond_boxes", "typed", "", "const b = flip() ? new Box({R}) : new Box({L});\nconsole.log(\"region\", b.value);"),
    ("compare", "typed", "arith", 'console.log("region", {R} > 1);'),
    ("log", "any", "", 'console.log("region", {R});'),
    ("string", "any", "", 'console.log("region", String({R}));'),
    ("json", "any", "", 'console.log("region", JSON.stringify({R}));'),
    ("template", "any", "", "console.log(`region ${{R}}`);"),
    ("typeof", "any", "", 'console.log("region", typeof {R});'),
    ("eqeqeq", "any", "", 'console.log("region", {R} === null);'),
    ("concat", "any", "", 'console.log("region " + {R});'),
    ("unknown_param", "any", "", 'console.log("region", show({R}));'),
    ("assert_never", "never", "never", "assertNever({R});"),
    ("never_const", "never", "never", "const u: never = {R};\nconsole.log(\"region\", JSON.stringify(u));"),
    ("return_never", "never", "never", None),  # special: a never-returning function returns it
    ("cast_tested", "typed", "", 'console.log("region", {C}({R} as {T}));'),
    ("cast_decl", "cast", "", 'console.log("region", {DC}({R} as {D}));'),
    ("cast_any", "cast", "", 'console.log("region", {R} as any);'),
    ("cast_any_member", "cast", "", 'console.log("region", ({R} as any).length);'),
    ("cast_unknown_tested", "typed", "", 'console.log("region", {C}({R} as unknown as {T}));'),
    ("cast_unknown_decl", "cast", "", 'console.log("region", {DC}({R} as unknown as {D}));'),
]
USE = {u[0]: u for u in USES}
DECL_CONSUMER = {"string": "str", "number": "num", "Pt": "ptv", "number[]": "nums", "string | number": "sn",
                 "Shape": "shp", "HasK": "hk", "Color": "col", "Dir": "dir", "boolean": "bool", "null": "nul",
                 "string | undefined": "show", "number | undefined": "show", "Pt | undefined": "show",
                 "Base": "show", "Sub1 | Sub2": "show", "number | string[]": "show", "string | null": "show",
                 "Pt | null": "show"}


def applicable(use, spec):
    needs = USE[use][2]
    kind = spec["kind"]
    if needs == "never" and kind != "never":
        return False
    if needs == "inter" and not spec.get("member"):
        return False
    if needs == "arith" and not spec.get("arith", kind == "never"):
        return False
    if use == "cond_boxes" and not spec.get("live"):
        return False
    return True


def use_body(use, spec, ref):
    template = USE[use][3]
    decl = spec["decl"]
    return (template.replace("{R}", ref).replace("{C}", spec.get("cons", "num")).replace("{T}", spec.get("tested", "number"))
            .replace("{DC}", DECL_CONSUMER.get(decl, "show")).replace("{D}", decl).replace("{M}", spec.get("member") or "")
            .replace("{L}", spec.get("live") or "0"))


def want_of(use, lie):
    if not lie:
        return "node"
    return "node|trap" if USE[use][1] == "typed" else "node"


# ------------------------------------------------------------------------------- form family
# The narrowed reference is the parameter x; the wrap is the region around @BODY@ in f.
def F(decl, arg, kind, wrap, tested="number", cons="num", member=None, arith=None, live=None, returns=False, top=False):
    d = dict(decl=decl, arg=arg, kind=kind, wrap=wrap, tested=tested, cons=cons, member=member, live=live, returns=returns, top=top)
    if arith is not None:
        d["arith"] = arith
    return d


IF = lambda test: "if (%s) {\n  @BODY@\n}" % test
FORMS = {
    "typeof_eq": F("string", '"s"', "never", IF('typeof x === "number"'), live='"o"'),
    "typeof_neq_else": F("string", '"s"', "never", 'if (typeof x !== "number") {\n  console.log("live", x.length);\n} else {\n  @BODY@\n}', live='"o"'),
    "typeof_undefined": F("string", '"s"', "never", IF('typeof x === "undefined"'), tested="undefined", cons="und", live='"o"'),
    "typeof_object": F("number", "2", "never", IF('typeof x === "object"'), tested="object | null", cons="show", live="3"),
    "typeof_string_class": F("Pt", "new Pt(1)", "never", IF('typeof x === "string"'), tested="string", cons="str", live="new Pt(9)"),
    "typeof_union_absent": F("string | number", "3", "never", IF('typeof x === "boolean"'), tested="boolean", cons="bool", live="4"),
    "aliased_cond": F("string", '"s"', "never", 'const isNumber = typeof x === "number";\nif (isNumber) {\n  @BODY@\n}', live='"o"'),
    "isarray": F("number", "2", "inter", IF("Array.isArray(x)"), tested="any[]", cons="len", member=".length", arith=True, live="3"),
    "isarray_else": F("number[]", "[1, 2]", "never", IF("!Array.isArray(x)"), tested="number[]", cons="nums", live="[3]"),
    "instanceof_array": F("number[]", "[1, 2]", "inter", IF("x instanceof Pt"), tested="Pt", cons="ptv", member=".v", arith=False, live="[3]"),
    "instanceof_unrelated": F("Pt", "new Pt(1)", "inter", IF("x instanceof Other"), tested="Other", cons="oth", member=".w", arith=False, live="new Pt(9)"),
    "instanceof_else": F("Pt", "new Pt(1)", "never", IF("!(x instanceof Pt)"), tested="Pt", cons="ptv", live="new Pt(9)"),
    "instanceof_union_member": F("string | number[]", "[1, 2]", "inter", IF("x instanceof Pt"), tested="Pt", cons="ptv", member=".v", arith=False, live="[3]"),
    "instanceof_primitive": F("string", '"s"', "never", IF("x instanceof Pt"), tested="Pt", cons="ptv", live='"o"'),
    "eq_null": F("string", '"s"', "never", IF("x === null"), tested="null", cons="nul", live='"o"'),
    "eq_undefined": F("string", '"s"', "never", IF("x === undefined"), tested="undefined", cons="und", live='"o"'),
    "loose_null": F("number", "2", "never", IF("x == null"), tested="null | undefined", cons="nu", live="3"),
    "eq_null_class": F("Pt", "new Pt(1)", "never", IF("x === null"), tested="null", cons="nul", live="new Pt(9)"),
    "falsy_obj": F("Pt", "new Pt(1)", "never", IF("!x"), tested="null", cons="nul", live="new Pt(9)"),
    "truthy_obj_else": F("Pt", "new Pt(1)", "never", 'if (x) {\n  console.log("live", x.v);\n} else {\n  @BODY@\n}', tested="null", cons="nul", live="new Pt(9)"),
    "falsy_array": F("number[]", "[1, 2]", "never", IF("!x"), tested="null", cons="nul", live="[3]"),
    "truthy_null": F("null", "null", "never", IF("x"), tested="Pt", cons="ptv", live="null"),
    "predicate": F("string", '"s"', "never", IF("isNum(x)"), live='"o"'),
    "predicate_inter": F("number", "2", "inter", IF("isArr(x)"), tested="unknown[]", cons="len", member=".length", arith=True, live="3"),
    "predicate_class": F("number[]", "[1, 2]", "inter", IF("isPt(x)"), tested="Pt", cons="ptv", member=".v", arith=False, live="[3]"),
    "assertion": F("string", '"s"', "never", 'try {\n  assertNum(x);\n  @BODY@\n} catch (error: any) {\n  console.log("caught in f", error.message);\n}', live='"o"'),
    "assertion_stmt": F("string", '"s"', "never", "assertNum(x);\n@BODY@", live='"o"', top=True),
    "switch_typeof": F("string", '"s"', "never", 'switch (typeof x) {\n  case "number":\n    @BODY@\n    @BREAK@\n  case "string":\n    console.log("live", x.length);\n    break;\n}', live='"o"'),
    "switch_typeof_fall": F("string", '"s"', "never", 'switch (typeof x) {\n  case "number":\n    @BODY@\n  case "string":\n    console.log("live or fell through", typeof x);\n    break;\n}', live='"o"'),
    "switch_true": F("string", '"s"', "never", 'switch (true) {\n  case typeof x === "number":\n    @BODY@\n    @BREAK@\n  default:\n    console.log("live default");\n}', live='"o"'),
    "exhausted_if": F("Shape", '{ kind: "sq", side: 2 }', "never", 'if (x.kind === "sq") {\n  console.log("live", x.side);\n} else if (x.kind === "ci") {\n  console.log("live", x.r);\n} else {\n  @BODY@\n}', tested="Shape", cons="shp", live='{ kind: "ci", r: 1 }'),
    "exhausted_switch": F("Shape", '{ kind: "sq", side: 2 }', "never", 'switch (x.kind) {\n  case "sq":\n    console.log("live", x.side);\n    break;\n  case "ci":\n    console.log("live", x.r);\n    break;\n  default:\n    @BODY@\n}', tested="Shape", cons="shp", live='{ kind: "ci", r: 1 }'),
    "in_false": F("HasK", "{ k: 1 }", "never", IF('!("k" in x)'), tested="HasK", cons="hk", live="{ k: 2 }"),
    "literal_exhausted": F("Dir", '"up"', "never", 'if (x === "up") {\n  console.log("live up");\n} else if (x === "down") {\n  console.log("live down");\n} else {\n  @BODY@\n}', tested="Dir", cons="dir", live='"down"'),
    "enum_exhausted": F("Color", "Color.Red", "never", 'switch (x) {\n  case Color.Red:\n    console.log("live red");\n    break;\n  case Color.Green:\n    console.log("live green");\n    break;\n  default:\n    @BODY@\n}', tested="Color", cons="col", live="Color.Green"),
    "bool_exhausted": F("boolean", "true", "never", 'if (x === true) {\n  console.log("live true");\n} else if (x === false) {\n  console.log("live false");\n} else {\n  @BODY@\n}', tested="boolean", cons="bool", live="false"),
}
FORM_USES = ["arith", "param", "member", "copy_typed", "copy_untyped", "new_box", "cond_boxes", "compare", "log", "string",
             "concat", "typeof", "assert_never", "never_const", "return_never", "cast_tested", "cast_decl", "cast_any",
             "cast_unknown_tested"]


def form_program(spec, use, ref="x", setup="", arg=None, fname="f"):
    """f(x: decl) with the form's region holding the use; the call prints its result or what it threw."""
    arg = arg if arg is not None else spec["arg"]
    if use == "return_never":
        if spec["returns"]:
            return None
        body = "return %s;" % ref
        region = fill(spec["wrap"], body).replace("@BREAK@", "").replace("\n    \n", "\n")
        region = "\n".join(l for l in region.split("\n") if l.strip() != "")
        code = ("function fail(x: %s): never {\n%s\n  throw new Error(\"fail \" + typeof x);\n}\n"
                "function f(x: %s): string {\n  const r = fail(x);\n  return \"returned \" + String(r);\n}\n"
                % (spec["decl"], indent(region, 2), spec["decl"]))
        return setup + code + caught("f(%s)" % arg)
    body = use_body(use, spec, ref)
    region = fill(spec["wrap"], body)
    region = region.replace("@BREAK@", "" if ends_flow(body) else "break;")
    region = "\n".join(l for l in region.split("\n") if l.strip() != "")
    code = "function f(x: %s): string {\n%s\n  return \"done \" + typeof x;\n}\n" % (spec["decl"], indent(region, 2))
    return setup + code + caught("f(%s)" % arg)


for name, spec in FORMS.items():
    uses = FORM_USES if name != "instanceof_primitive" else ["log", "param"]
    for use in uses:
        if not applicable(use, spec):
            continue
        code = form_program(spec, use)
        if code is None:
            continue
        add("form-%s-%s" % (name, use), "form", {"narrowing": name, "use": use, "kind": spec["kind"], "decl": spec["decl"]}, code)

# -------------------------------------------------------------------------------- lie family
LIE_USES = ["arith", "param", "member", "copy_typed", "copy_untyped", "new_box", "cond_boxes", "compare", "log", "string",
            "json", "template", "typeof", "eqeqeq", "concat", "unknown_param", "assert_never", "never_const", "return_never",
            "cast_tested", "cast_decl", "cast_any", "cast_any_member", "cast_unknown_tested", "cast_unknown_decl"]
LIES = {
    # lying predicates and assertions in f itself
    "pred_never": (F("string", '"s"', "never", IF("lyingIsNum(x)"), live='"o"'), "", None, "lying predicate: string & number"),
    "pred_inter": (F("number", "2", "inter", IF("lyingIsArr(x)"), tested="unknown[]", cons="len", member=".length", arith=True, live="3"), "", None, "lying predicate: number & unknown[]"),
    "pred_class": (F("number[]", "[1, 2]", "inter", IF("lyingIsPt(x)"), tested="Pt", cons="ptv", member=".v", arith=False, live="[3]"), "", None, "lying predicate: number[] & Pt"),
    "pred_unrelated": (F("Pt", "new Pt(1)", "inter", IF("lyingIsOther(x)"), tested="Other", cons="oth", member=".w", arith=False, live="new Pt(9)"), "", None, "lying predicate: Pt & Other"),
    "pred_union": (F("string | number", "3", "never", IF("lyingIsBool(x)"), tested="boolean", cons="bool", live="4"), "", None, "lying predicate: a union to never"),
    "pred_null": (F("string", '"s"', "never", IF("lyingIsNull(x)"), tested="null", cons="nul", live='"o"'), "", None, "lying predicate: string & null"),
    "assert_stmt": (F("string", '"s"', "never", "lyingAssertNum(x);\n@BODY@", live='"o"', top=True), "", None, "lying assertion statement"),
    "assert_inter": (F("number", "2", "inter", "lyingAssertArr(x);\n@BODY@", tested="unknown[]", cons="len", member=".length", arith=True, live="3", top=True), "", None, "lying assertion: number & unknown[]"),
    # a value the declared type's IR type holds, which the tests exclude: reached by a cast or with none
    "discr_switch": (FORMS["exhausted_switch"], 'const lie = { kind: "tri", side: 1, r: 1 } as unknown as Sq;\n', "lie", "cast discriminant reaches an exhausted switch's default"),
    "discr_if": (FORMS["exhausted_if"], 'const lie = { kind: "tri", side: 1, r: 1 } as unknown as Sq;\n', "lie", "cast discriminant reaches an exhausted if chain's end"),
    "literal_cast": (FORMS["literal_exhausted"], 'const raw: string = "left";\n', "raw as Dir", "a string cast to a literal union reaches the chain's end"),
    "enum_no_cast": (FORMS["enum_exhausted"], "const seven: number = 7;\n", "seven", "a number that Color doesn't name, with no cast"),
}
for name, (spec, setup, arg, note) in LIES.items():
    for use in LIE_USES:
        if not applicable(use, spec):
            continue
        code = form_program(spec, use, setup=setup, arg=arg)
        if code is None:
            continue
        lie = name.startswith(("pred", "assert", "discr", "literal"))
        want = want_of(use, lie)
        if name == "enum_no_cast":
            want = "node"  # no lie in the program
        add("lie-%s-%s" % (name, use), "lie", {"lie": name, "use": use, "kind": spec["kind"], "group": USE[use][1]}, code, want, note)

# D-090's loose locals: an element or a record entry read into a const that the program tests
# for undefined; tsc types the tested branch never, Node runs it with undefined. No lie.
LOOSE = {
    "elem_eq_undefined": ("const a: string[] = [\"a\"];\nconst y = a[i];", "y === undefined", "string"),
    "elem_typeof_undefined": ("const a: string[] = [\"a\"];\nconst y = a[i];", 'typeof y === "undefined"', "string"),
    "elem_loose_null": ("const a: number[] = [1];\nconst y = a[i];", "y == null", "number"),
    "elem_falsy_object": ("const a: Pt[] = [new Pt(1)];\nconst y = a[i];", "!y", "Pt"),
    "record_eq_undefined": ("const d: Record<string, number> = { a: 1 };\nconst y = d[\"k\" + i];", "y === undefined", "number"),
    "pattern_eq_undefined": ("const [first, y] = \"a\".split(\"=\");", "y === undefined", "string"),
}
LOOSE_USES = [("log", 'console.log("region", y);', "node"), ("string", 'console.log("region", String(y));', "node"),
              ("concat", 'console.log("region " + y);', "node"), ("typeof", 'console.log("region", typeof y);', "node"),
              ("copy_undefined", 'const u: undefined = y;\nconsole.log("region", u);', "node"),
              ("param_undefined", 'console.log("region", und(y));', "node"),
              ("param_declared", 'console.log("region", show(y));', "node"),
              ("nullish", 'console.log("region", y ?? "fallback");', "node"),
              ("never_const", 'const u: never = y;\nconsole.log("region", u);', "node"),
              ("assert_never", "assertNever(y);", "node"),
              ("new_box", 'console.log("region", new Box(y).value);', "node"),
              ("return", "return y;", "node")]
for name, (setup, test, decl) in LOOSE.items():
    for use, body, want in LOOSE_USES:
        result = "string | undefined" if use == "return" else "string"
        if use == "return" and decl != "string":
            result = "%s | string | undefined" % decl
        code = ("function f(i: number): %s {\n%s\n  if (%s) {\n%s\n  }\n  return \"present \" + String(y);\n}\n%s"
                % (result, indent(setup, 2), test, indent(body, 4), caught("f(5)")))
        add("lie-loose_%s-%s" % (name, use), "lie", {"lie": "loose_" + name, "use": use, "kind": "never", "group": "loose"}, code, want,
            "D-090 loose local; no lie")

# --------------------------------------------------------------------------- stale family
# The reference's staleness; declared type string (typeof number: never), number
# (Array.isArray: number & any[]) or string under a lying predicate.
STALE_REFS = {
    # name: (setup inside f before the region, the reference, f's parameters, the call's argument text, module-level setup, wrap-in)
    "param": ("", "x", "x: {D}", "{A}", "", None),
    "param_reassigned": ("x = {A2};", "x", "x: {D}", "{A}", "", None),
    "const_local": ("const y: {D} = x;", "y", "x: {D}", "{A}", "", None),
    "const_inferred": ("const y = x;", "y", "x: {D}", "{A}", "", None),
    "let_own": ("let y: {D} = x;", "y", "x: {D}", "{A}", "", None),
    "let_reassigned": ("let y: {D} = {A2};\ny = x;", "y", "x: {D}", "{A}", "", None),
    "let_loop": ("let y: {D} = {A2};", "y", "x: {D}", "{A}", "", "for (const s of [x, {A2}]) {\n  y = s;\n  @REGION@\n}"),
    "let_closure_assigns": ("let y: {D} = x;\nconst set = (): void => {\n  y = {A2};\n};\nset();", "y", "x: {D}", "{A}", "", None),
    "param_closure_assigns": ("const set = (): void => {\n  x = {A2};\n};\nset();", "x", "x: {D}", "{A}", "", None),
    "module_let_other_fn": ("setM();", "m", "x: {D}", "{A}", "let m: {D} = {A};\nfunction setM(): void {\n  m = {A2};\n}\n", None),
    "module_const": ("", "mc", "x: {D}", "{A}", "const mc: {D} = {A};\n", None),
    "property": ("", "o.v", "o: { v: {D} }", "{ v: {A} }", "", None),
    "readonly_property": ("", "o.v", "o: { readonly v: {D} }", "{ v: {A} }", "", None),
    "nested_property": ("", "o.p.v", "o: { p: { v: {D} } }", "{ p: { v: {A} } }", "", None),
    "this_property": (None, "this.v", None, None, "", None),
    "tuple_element": ("", "t[0]", "t: [{D}, number]", "[{A}, 0]", "", None),
    "array_element": ("", "a[0]", "a: {D}[]", "[{A}]", "", None),
    "getter": ("", "g.v", "g: G", "new G()", "class G {\n  get v(): {D} {\n    return {A};\n  }\n}\n", None),
    "static_property": ("", "S.v", "x: {D}", "{A}", "class S {\n  static v: {D} = {A};\n}\n", None),
    "destructured": ("const { v } = o;", "v", "o: { v: {D} }", "{ v: {A} }", "", None),
    "closure_reads_param": ("", "x", "x: {D}", "{A}", "", "const g = (): void => {\n  @REGION@\n};\ng();"),
}
STALE_FORMS = {
    # name: (declared, value, second value, test, uses as (name, body, want))
    "typeof_dead": ("string", '"s"', '"z"', 'typeof {R} === "number"',
                    [("param", 'console.log("region", num({R}));', "node"), ("log", 'console.log("region", {R});', "node"),
                     ("assert_never", "assertNever({R});", "node"), ("new_box", 'console.log("region", new Box({R}).value);', "node")]),
    "isarray_dead": ("number", "2", "3", "Array.isArray({R})",
                     [("member", 'console.log("region", {R}.length);', "node"), ("log", 'console.log("region", {R});', "node")]),
    "lying_predicate": ("string", '"s"', '"z"', "lyingIsNum({R})",
                        [("param", 'console.log("region", num({R}));', "node|trap"), ("log", 'console.log("region", {R});', "node"),
                         ("string", 'console.log("region", String({R}));', "node"), ("assert_never", "assertNever({R});", "node")]),
}
for fname, (decl, val, val2, test, uses) in STALE_FORMS.items():
    for rname, (setup, ref, params, argt, module, around) in STALE_REFS.items():
        for use, body, want in uses:
            b = body.replace("{R}", ref)
            t = test.replace("{R}", ref)
            region = "if (%s) {\n%s\n}" % (t, indent(b, 2))
            if rname == "this_property":
                code = ("class C {\n  constructor(public v: %s) {}\n  run(): string {\n%s\n    return \"done \" + typeof this.v;\n  }\n}\n%s"
                        % (decl, indent(region, 4), caught("new C(%s).run()" % val)))
            else:
                sub = lambda s: s.replace("{D}", decl).replace("{A2}", val2).replace("{A}", val)
                inner = region if around is None else fill(sub(around).replace("@REGION@", "@BODY@"), region)
                fbody = (sub(setup) + "\n" if setup else "") + inner
                code = (sub(module) + "function f(%s): string {\n%s\n  return \"done\";\n}\n%s"
                        % (sub(params), indent(fbody, 2), caught("f(%s)" % sub(argt))))
            add("stale-%s-%s-%s" % (fname, rname, use), "stale", {"narrowing": fname, "ref": rname, "use": use}, code, want)

# ----------------------------------------------------------------------- stalelive family
# A union place narrowed by a first test, changed by what tsc doesn't follow, then typed
# never (or an intersection) by a second test: live, no lie. `change` true: Node runs the
# branch; false: the no-change twin, where it is dead.
SL_FORMS = {
    # name: (declared, first value, changed value, first test, second test, uses)
    "typeof_never": ("string | number", '"s"', "5", 'typeof {R} === "string"', 'typeof {R} === "number"', [
        ("arith", 'return "region " + ({R} + 1);'), ("param", 'return "region " + num({R});'),
        ("copy_typed", 'const n: number = {R};\nreturn "region " + n;'), ("copy_untyped", 'const y = {R};\nreturn "region " + num(y);'),
        ("new_box", 'return "region " + new Box({R}).value;'), ("cond_boxes", 'const b = flip() ? new Box({R}) : new Box(0);\nreturn "region " + b.value;'),
        ("compare", 'return "region " + ({R} > 1);'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("string", 'return "region " + String({R});'),
        ("json", 'return "region " + JSON.stringify({R});'), ("template", "return `region ${{R}}`;"),
        ("typeof", 'return "region " + typeof {R};'), ("eqeqeq", 'return "region " + ({R} === 5);'),
        ("concat", 'return "region " + {R};'), ("unknown_param", 'return "region " + show({R});'),
        ("assert_never", "return assertNever({R});"), ("never_const", 'const u: never = {R};\nreturn "region " + JSON.stringify(u);'),
        ("cast_decl", 'return "region " + sn({R} as string | number);'), ("cast_any", 'return "region " + ({R} as any);'),
        ("return_value", "return {R};")]),
    "null_never": ("string | null", '"s"', "null", "{R} !== null", "{R} === null", [
        ("copy_typed", 'const n: null = {R};\nreturn "region " + n;'), ("param", 'return "region " + nul({R});'),
        ("new_box", 'return "region " + new Box({R}).value;'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("string", 'return "region " + String({R});'),
        ("assert_never", "return assertNever({R});"), ("return_value", "return {R};")]),
    "falsy_never": ("Pt | null", "new Pt(1)", "null", "{R}", "!{R}", [
        ("copy_typed", 'const n: null = {R};\nreturn "region " + n;'), ("param", 'return "region " + nul({R});'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("string", 'return "region " + String({R});'),
        ("assert_never", "return assertNever({R});"), ("return_value", "return {R};")]),
    "isarray_inter": ("number | string[]", "1", '["x", "y"]', 'typeof {R} === "number"', "Array.isArray({R})", [
        ("member", 'return "region " + {R}.length;'), ("param", 'return "region " + len({R});'),
        ("copy_typed", 'const a: string[] = {R};\nreturn "region " + a.length;'), ("arith", 'return "region " + ({R} + 1);'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("string", 'return "region " + String({R});'),
        ("json", 'return "region " + JSON.stringify({R});'), ("return_value", "return {R};")]),
    "instanceof_siblings": ("Base", "new Sub1(1)", "new Sub2(2)", "{R} instanceof Sub1", "{R} instanceof Sub2", [
        ("member", 'return "region " + {R}.b;'), ("member_base", 'return "region " + {R}.n;'), ("param", 'return "region " + sub2({R});'),
        ("copy_typed", 'const s: Sub2 = {R};\nreturn "region " + s.b;'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("string", 'return "region " + String({R});'),
        ("return_value", "return {R};")]),
    "instanceof_sibling_union": ("Sub1 | Sub2", "new Sub1(1)", "new Sub2(2)", "{R} instanceof Sub1", "{R} instanceof Sub2", [
        ("member", 'return "region " + {R}.b;'), ("param", 'return "region " + sub2({R});'),
        ("log", 'console.log("region", {R});\nreturn "logged";'), ("return_value", "return {R};")]),
    "discriminant_never": ("Shape", '{ kind: "sq", side: 2 }', '{ kind: "ci", r: 3 }', '{R}.kind === "sq"', "isCi({R})", [
        ("param", 'return "region " + shp({R});'), ("log", 'console.log("region", {R});\nreturn "logged";'),
        ("json", 'return "region " + JSON.stringify({R});'), ("assert_never", "return assertNever({R});"),
        ("cast_decl", 'return "region " + ({R} as Shape).kind;'), ("return_value", "return {R};")]),
    "pred_inter": ("number | string[]", "1", '["x", "y"]', 'typeof {R} === "number"', "isArr({R})", [
        ("member", 'return "region " + {R}.length;'), ("log", 'console.log("region", {R});\nreturn "logged";')]),
}
# How the place changes: (ref, f's parameters, the call's argument setup, call text, change statement in f, kind)
SL_REFS = {
    "property_call": ("o.v", "o: { v: {D} }, change: () => void", "const o: { v: {D} } = { v: {A} };\n", "f(o, () => {\n  o.v = {B};\n})", "change();", "sync"),
    "nested_property_call": ("o.p.v", "o: { p: { v: {D} } }, change: () => void", "const o: { p: { v: {D} } } = { p: { v: {A} } };\n", "f(o, () => {\n  o.p.v = {B};\n})", "change();", "sync"),
    "tuple_element_call": ("t[0]", "t: [{D}], change: () => void", "const t: [{D}] = [{A}];\n", "f(t, () => {\n  t[0] = {B};\n})", "change();", "sync"),
    "array_element_call": ("a[0]", "a: ({D})[], change: () => void", "const a: ({D})[] = [{A}];\n", "f(a, () => {\n  a[0] = {B};\n})", "change();", "sync"),
    "this_method": ("this.v", None, None, None, "this.flip();", "method"),
    "static_call": ("S.v", "change: () => void", "", "f(() => {\n  S.v = {B};\n})", "change();", "static"),
    "let_closure": ("v", "", "", "f()", "set();", "let_closure"),
    "param_closure": ("p", "p: {D}", "", "f({A})", "set();", "param_closure"),
    "module_let": ("m", "", "", "f()", "setM();", "module"),
    "property_await": ("o.v", "o: { v: {D} }", "const o: { v: {D} } = { v: {A} };\n", "f(o)", "await Promise.resolve();", "async"),
    "property_yield": ("o.v", "o: { v: {D} }", "const o: { v: {D} } = { v: {A} };\n", "f(o)", 'yield "first";', "gen"),
    "getter_flip": ("g.v", "g: G", "", "f(new G())", "", "getter"),
}
SL_FULL_USES_REF = "property_call"  # every use for this ref; two uses for the others
for fname, (decl, a, b, test1, test2, uses) in SL_FORMS.items():
    for rname, (ref, params, setup, call, change, kind) in SL_REFS.items():
        chosen = uses if rname == SL_FULL_USES_REF else [u for u in uses if u[0] in ("log", uses[0][0])]
        for changes in (True, False):
            if not changes and rname not in ("property_call", "let_closure", "this_method", "getter_flip"):
                continue
            for use, body in chosen:
                if not changes and use not in ("log", uses[0][0]):
                    continue
                sub = lambda s: s.replace("{D}", decl).replace("{A}", a).replace("{B}", b if changes else a)
                rb = body.replace("{R}", ref)
                result = decl if use == "return_value" else "string"
                if use == "return_value" and kind in ("async",):
                    result = decl
                inner = "if (%s) {\n%s\n}" % (test2.replace("{R}", ref), indent(rb, 2))
                chg = change
                region = "if (%s) {\n%s\n%s\n}" % (test1.replace("{R}", ref), indent(chg, 2) if chg else "", indent(inner, 2))
                region = "\n".join(l for l in region.split("\n") if l.strip() != "")
                printed = ('try {\n  console.log("result", %s);\n} catch (error: any) {\n  console.log("caught", error.name, error.message);\n}\n')
                if kind == "sync" or kind == "static":
                    pre = "class S {\n  static v: %s = %s;\n}\n" % (decl, a) if kind == "static" else ""
                    code = (pre + "function f(%s): %s {\n%s\n  return \"kept\";\n}\n%s%s"
                            % (sub(params), result if use == "return_value" else "string", indent(region, 2), sub(setup), printed % sub(call)))
                    if use == "return_value":
                        code = code.replace('  return "kept";\n', "  return %s;\n" % ref)
                elif kind == "method":
                    code = ("class C {\n  v: %s = %s;\n  flip(): void {\n    this.v = %s;\n  }\n  run(): %s {\n%s\n    return %s;\n  }\n}\n%s"
                            % (decl, a, b if changes else a, result, indent(region, 4), '"kept"' if use != "return_value" else "this.v",
                               printed % "new C().run()"))
                elif kind == "let_closure":
                    code = ("function f(): %s {\n  let v: %s = %s;\n  const set = (): void => {\n    v = %s;\n  };\n%s\n  return %s;\n}\n%s"
                            % (result, decl, a, b if changes else a, indent(region, 2), '"kept"' if use != "return_value" else "v", printed % "f()"))
                elif kind == "param_closure":
                    code = ("function f(p: %s): %s {\n  const set = (): void => {\n    p = %s;\n  };\n%s\n  return %s;\n}\n%s"
                            % (decl, result, b if changes else a, indent(region, 2), '"kept"' if use != "return_value" else "p", printed % sub(call)))
                elif kind == "module":
                    code = ("let m: %s = %s;\nfunction setM(): void {\n  m = %s;\n}\nfunction f(): %s {\n%s\n  return %s;\n}\n%s"
                            % (decl, a, b if changes else a, result, indent(region, 2), '"kept"' if use != "return_value" else "m", printed % "f()"))
                elif kind == "async":
                    code = ("async function f(%s): Promise<%s> {\n%s\n  return %s;\n}\n%s"
                            "const pending = f(o);\no.v = %s;\npending.then(\n  (r) => console.log(\"result\", r),\n  (error: any) => console.log(\"caught\", error.name, error.message),\n);\n"
                            % (sub(params), result, indent(region, 2), '"kept"' if use != "return_value" else "o.v", sub(setup), b if changes else a))
                elif kind == "gen":
                    if use == "return_value" or use.startswith("assert"):
                        continue
                    region_g = region.replace("return ", "yield ")
                    code = ("function* f(%s): Generator<string, void, unknown> {\n%s\n}\n%s"
                            "const it = f(o);\ntry {\n  console.log(\"result\", it.next().value);\n  o.v = %s;\n  console.log(\"result\", it.next().value);\n} catch (error: any) {\n  console.log(\"caught\", error.name, error.message);\n}\n"
                            % (sub(params), indent(region_g, 2), sub(setup), b if changes else a))
                elif kind == "getter":
                    code = ("class G {\n  reads = 0;\n  get v(): %s {\n    return this.reads++ >= 1 ? %s : %s;\n  }\n}\nfunction f(%s): %s {\n%s\n  return %s;\n}\n%s"
                            % (decl, b if changes else a, a, sub(params), result, indent(region, 2), '"kept"' if use != "return_value" else "g.v", printed % sub(call)))
                else:
                    raise ValueError(kind)
                add("stalelive-%s-%s-%s%s" % (fname, rname, use, "" if changes else "-nochange"), "stalelive",
                    {"narrowing": fname, "ref": rname, "use": use, "changes": "yes" if changes else "no"}, code, "node",
                    "live with no lie" if changes else "the no-change twin: dead")

# --------------------------------------------------------------------------- region family
TN = 'typeof x === "number"'
SHAPES = {
    "if_then": ('if (@T@) {\n  console.log("dead", @U@);\n}\nconsole.log("after");\nreturn x;', False),
    "if_side_effect_first": ('if (@T@) {\n  console.log("side effect");\n  console.log("dead", @U@);\n}\nreturn x;', False),
    "else": ('if (!(@T@)) {\n  console.log("live");\n} else {\n  console.log("dead", @U@);\n}\nreturn x;', False),
    "elseif_chain": ('if (typeof x === "boolean") {\n  console.log("boolean");\n} else if (@T@) {\n  console.log("number", @U@);\n} else {\n  console.log("other", String(x));\n}\nreturn x;', False),
    "nested_if": ('if (x !== undefined) {\n  if (@T@) {\n    console.log("dead", @U@);\n  }\n  console.log("outer live");\n}\nreturn x;', False),
    "early_return": ('if (!(@T@)) {\n  console.log("early");\n  return x;\n}\nconsole.log("rest", @U@);\nreturn x;', False),
    "early_throw": ('if (!(@T@)) {\n  throw new Error("thrown " + String(x));\n}\nconsole.log("rest", @U@);\nreturn x;', True),
    "continue": ('for (let i = 0; i < 2; i++) {\n  if (!(@T@)) continue;\n  console.log("rest", @U@);\n}\nconsole.log("loop done");\nreturn x;', False),
    "break": ('while (true) {\n  if (!(@T@)) break;\n  console.log("rest", @U@);\n  break;\n}\nconsole.log("loop done");\nreturn x;', False),
    "do_while_break": ('do {\n  if (!(@T@)) break;\n  console.log("rest", @U@);\n} while (false);\nconsole.log("loop done");\nreturn x;', False),
    "cond_expr": ('const s = @T@ ? @U@ : "not";\nconsole.log("cond", s);\nreturn x;', False),
    "cond_expr_box": ('const b = @T@ ? new Box(x) : new Box(x);\nconsole.log("box", b.value);\nreturn x;', False),
    "and_rhs": ('const s = @T@ && @U@;\nconsole.log("and", s);\nreturn x;', False),
    "or_rhs": ('const s = !(@T@) || @U@;\nconsole.log("or", s);\nreturn x;', False),
    "cond_and_rhs": ('if (@T@ && x > 1) {\n  console.log("dead", @U@);\n}\nreturn x;', False),
    "nullish_rhs_in_dead": ('const s = !(@T@) ? "not" : maybe() ?? @U@;\nconsole.log("nullish", s);\nreturn x;', False),
    "and_assign_rhs": ('let s = "s";\ns &&= @T@ ? @U@ : "kept";\nconsole.log("&&=", s);\nreturn x;', False),
    "or_assign_rhs": ('let s = "";\ns ||= @T@ ? @U@ : "kept";\nconsole.log("||=", s);\nreturn x;', False),
    "nullish_assign_rhs": ('let s: string | undefined = undefined;\ns ??= @T@ ? @U@ : "kept";\nconsole.log("??=", s);\nreturn x;', False),
    "switch_case": ('switch (typeof x) {\n  case "number":\n    console.log("dead", @U@);\n    break;\n  default:\n    console.log("default");\n}\nreturn x;', False),
    "switch_true_case": ('switch (true) {\n  case @T@:\n    console.log("dead", @U@);\n    break;\n  default:\n    console.log("default");\n}\nreturn x;', False),
    "while_body": ('let i = 0;\nwhile (@T@ && i < 1) {\n  console.log("dead", @U@);\n  i++;\n}\nconsole.log("after while");\nreturn x;', False),
    "for_body": ('for (let i = 0; @T@ && i < 1; i++) {\n  console.log("dead", @U@);\n}\nconsole.log("after for");\nreturn x;', False),
    "forof_in_dead": ('if (@T@) {\n  for (const k of [1, 2]) {\n    console.log("dead", k, @U@);\n  }\n}\nconsole.log("after");\nreturn x;', False),
    "labelled_block": ('block: {\n  if (!(@T@)) break block;\n  console.log("dead", @U@);\n}\nconsole.log("after block");\nreturn x;', False),
    "try_around": ('try {\n  if (@T@) {\n    console.log("dead", @U@);\n  }\n} finally {\n  console.log("finally");\n}\nreturn x;', False),
    "try_inside": ('if (@T@) {\n  try {\n    console.log("dead", @U@);\n  } catch (error) {\n    console.log("caught inside");\n  } finally {\n    console.log("finally inside");\n  }\n}\nreturn x;', False),
    "throw_in_try": ('try {\n  if (@T@) {\n    throw new Error(@U@);\n  }\n  console.log("no throw");\n} catch (error: any) {\n  console.log("caught", error.message);\n}\nreturn x;', False),
    "catch_body": ('try {\n  throw new Error("boom");\n} catch (error: any) {\n  if (@T@) {\n    console.log("dead", @U@);\n  }\n  console.log("caught", error.message);\n}\nreturn x;', False),
    "finally_body": ('try {\n  console.log("try");\n} finally {\n  if (@T@) {\n    console.log("dead", @U@);\n  }\n}\nreturn x;', False),
    "arrow_expr_capture": ('if (@T@) {\n  const g = () => @U@;\n  console.log("dead", g());\n}\nreturn x;', False),
    "arrow_body_dead": ('const g = (): string => (@T@ ? @U@ : "arrow live");\nconsole.log(g());\nreturn x;', False),
    "arrow_block_capture": ('if (@T@) {\n  const g = () => {\n    const r = @U@;\n    return r;\n  };\n  console.log("dead", g());\n}\nreturn x;', False),
    "closure_narrows_inside": ('const g = (): string => {\n  if (@T@) {\n    return "dead " + @U@;\n  }\n  return "closure live";\n};\nconsole.log(g());\nreturn x;', False),
    "arrow_escapes": ('let g: () => string = () => "live closure";\nif (@T@) {\n  g = () => @U@;\n}\nconsole.log(g());\nreturn x;', False),
    "const_alias": ('if (@T@) {\n  const y = x;\n  console.log("dead", @UY@);\n}\nreturn x;', False),
    "dead_assignment": ('let y: string = x;\nif (@T@) {\n  y = x;\n  console.log("dead", @U@);\n}\nreturn y;', False),
    "dead_generic_call": ('if (@T@) {\n  const inner = new Box(x);\n  console.log("dead", @UB@);\n}\nreturn x;', False),
    "dead_local_class": ('if (@T@) {\n  class Local {\n    constructor(public n: string) {}\n  }\n  console.log("dead", new Local(@U@).n);\n}\nreturn x;', False),
}
GEN_SHAPES = {
    "generator": ('yield "start";\nif (@T@) {\n  yield @U@;\n}\nyield "end";', "gen"),
    "async": ('await null;\nif (@T@) {\n  const y = await Promise.resolve(x);\n  console.log("dead", @UY@);\n}\nreturn x;', "async"),
}
VARIANTS = {
    # name: (test, use of x, use of y, use of a Box's value, want)
    "dead": (TN, "num(x)", "num(y)", "num(inner.value)", "node"),
    "lie_typed": ("lyingIsNum(x)", "num(x)", "num(y)", "num(inner.value)", "node|trap"),
    "lie_any": ("lyingIsNum(x)", "String(x)", "String(y)", "String(inner.value)", "node"),
}


def region_code(body, variant, kind="sync", catches=False):
    test, ux, uy, ub, _ = VARIANTS[variant]
    text = body.replace("@T@", test).replace("@UY@", uy).replace("@UB@", ub).replace("@U@", ux)
    if variant != "dead" and "@T@" not in body and "typeof x" in body and "lyingIsNum" not in text:
        return None  # a switch on typeof x can't lie
    if kind == "gen":
        return ("function* f(x: string): Generator<string, void, unknown> {\n%s\n}\n"
                "try {\n  for (const s of f(\"s\")) {\n    console.log(\"yielded\", s);\n  }\n} catch (error: any) {\n  console.log(\"caught\", error.name, error.message);\n}\n" % indent(text, 2))
    if kind == "async":
        return ("async function f(x: string): Promise<string> {\n%s\n}\n"
                "f(\"s\").then(\n  (r) => console.log(\"result\", r),\n  (error: any) => console.log(\"caught\", error.name, error.message),\n);\n" % indent(text, 2))
    return "function f(x: string): string {\n%s\n}\n%s" % (indent(text, 2), caught('f("s")'))


for name, (body, catches) in SHAPES.items():
    for variant in VARIANTS:
        code = region_code(body, variant)
        if code is None:
            continue
        add("region-%s-%s" % (name, variant), "region", {"shape": name, "variant": variant}, code, VARIANTS[variant][4])
for name, (body, kind) in GEN_SHAPES.items():
    for variant in VARIANTS:
        code = region_code(body, variant, kind)
        add("region-%s-%s" % (name, variant), "region", {"shape": name, "variant": variant}, code, VARIANTS[variant][4])

# ----------------------------------------------------------------------------- tail family
# A dead statement in a list: the statements after it, hoisted functions and the variables
# closures capture (D-195's statementList in plain code).
TAIL = {
    "hoisted_after_dead": ('if (typeof x !== "number") {\n  return helper(x);\n}\nconsole.log("dead", num(x));\nreturn x;\nfunction helper(v: string): string {\n  console.log("helper ran");\n  return v + "!";\n}', '"s!"'),
    "hoisted_captures_before": ('let count = 1;\nif (typeof x !== "number") {\n  return helper();\n}\nconsole.log("dead", num(x));\nreturn x;\nfunction helper(): string {\n  count++;\n  return "helper " + count;\n}', ""),
    "hoisted_uses_tail_let": ('if (typeof x !== "number") {\n  return helper();\n}\nconsole.log("dead", num(x));\nlet tail = "t";\nreturn tail;\nfunction helper(): string {\n  try {\n    return "helper " + tail;\n  } catch (error: any) {\n    return "helper " + error.name;\n  }\n}', ""),
    "closure_before_captures_tail": ('const read = (): string => {\n  try {\n    return "read " + tail;\n  } catch (error: any) {\n    return "read " + error.name;\n  }\n};\nif (typeof x !== "number") {\n  return read();\n}\nconsole.log("dead", num(x));\nconst tail = "t";\nreturn read();', ""),
    "closure_before_captures_tail_var": ('const read = (): string => "read " + String(tail);\nif (typeof x !== "number") {\n  return read();\n}\nconsole.log("dead", num(x));\nvar tail = "t";\nreturn read();', ""),
    "closure_before_assigns_outer": ('let seen = "none";\nconst mark = (): void => {\n  seen = "marked";\n};\nif (typeof x !== "number") {\n  mark();\n  return seen;\n}\nconsole.log("dead", num(x));\nmark();\nreturn seen;', ""),
    "side_effect_before_dead": ('console.log("before");\nif (typeof x !== "number") {\n  console.log("live early");\n  return x;\n}\nconsole.log("dead", num(x));\nreturn x;', ""),
    "dead_tail_in_case": ('switch (x.length) {\n  case 1:\n    if (typeof x !== "number") {\n      return "case live";\n    }\n    console.log("dead", num(x));\n    return x;\n  default:\n    return "default";\n}', ""),
    "dead_tail_in_closure": ('const g = (): string => {\n  if (typeof x !== "number") {\n    return "closure live";\n  }\n  return num(x);\n};\nreturn g();', ""),
    "dead_tail_in_method": (None, ""),
    "dead_tail_lie": ('if (!lyingIsNum(x)) {\n  return "live";\n}\nconsole.log("after the lie", String(x));\nconst n = num(x);\nreturn n;', ""),
}
for name, (body, _) in TAIL.items():
    if body is None:
        code = ('class M {\n  run(x: string): string {\n    if (typeof x !== "number") {\n      return helper(x);\n    }\n    return num(x);\n    function helper(v: string): string {\n      return "method helper " + v;\n    }\n  }\n}\n'
                + caught('new M().run("s")'))
    else:
        code = "function f(x: string): string {\n%s\n}\n%s" % (indent(body, 2), caught('f("s")'))
    add("tail-%s" % name, "tail", {"shape": name}, code, "node|trap" if "lie" in name else "node")

# -------------------------------------------------------------------------- generic family
# Generic code that tsc itself types never (in the generic code, not just for an instance).
GEN = {
    # name: (type parameters, parameter type, test, kind, tested, consumer, member, type argument, value)
    "typeof_inter": ("<T extends string>", "T & string", 'typeof x === "number"', "never", "number", "num", None, "string", '"s"'),
    "typeof_inter_unconstrained": ("<T>", "T & string", 'typeof x === "number"', "never", "number", "num", None, "string", '"s"'),
    "typeof_constraint": ("<T extends string>", "T", 'typeof x === "number"', "never", "number", "num", None, "string", '"s"'),
    "eq_null_inter": ("<T extends string>", "T & string", "x === null", "never", "null", "nul", None, "string", '"s"'),
    "isarray_inter": ("<T extends number>", "T & number", "Array.isArray(x)", "inter", "any[]", "len", ".length", "number", "3"),
    "instanceof_inter": ("<T extends number[]>", "T & number[]", "x instanceof Pt", "inter", "Pt", "ptv", ".v", "number[]", "[1]"),
    "falsy_inter": ("<T extends Pt>", "T & Pt", "!x", "never", "null", "nul", None, "Pt", "new Pt(1)"),
    "predicate_inter": ("<T extends string>", "T & string", "isNum(x)", "never", "number", "num", None, "string", '"s"'),
    "union_absent": ("<T extends string | number>", "T & (string | number)", 'typeof x === "boolean"', "never", "boolean", "bool", None, "string | number", "3"),
    "lying_predicate": ("<T extends string>", "T & string", "lyingIsNum(x)", "never", "number", "num", None, "string", '"s"'),
}
GEN_USES = ["arith", "param", "member", "copy_typed", "new_box", "cond_boxes", "log", "string", "concat", "assert_never", "never_const", "cast_any"]
for name, (tps, ptype, test, kind, tested, cons, member, targ, value) in GEN.items():
    spec = F(ptype, value, kind, IF(test), tested=tested, cons=cons, member=member, arith=(kind == "never" or member == ".length"), live=value)
    for use in GEN_USES:
        if not applicable(use, spec):
            continue
        body = use_body(use, spec, "x")
        region = fill(spec["wrap"], body)
        for form in ("direct", "value"):
            fn = "function f%s(x: %s): string {\n%s\n  return \"done \" + typeof x;\n}\n" % (tps, ptype, indent(region, 2))
            if form == "direct":
                code = fn + caught("f<%s>(%s)" % (targ, value))
            else:
                code = fn + ("function use(g: %s(x: %s) => string): string {\n  return g<%s>(%s);\n}\n" % (tps, ptype, targ, value)) + caught("use(f)")
            lie = name == "lying_predicate"
            add("generic-%s-%s-%s" % (name, use, form), "generic", {"narrowing": name, "use": use, "context": form}, code, want_of(use, lie))
# The generic exhausted switch (a guard) and its typed uses.
GEN_SWITCH = ('function f<T extends Shape>(x: T): string {\n  switch (x.kind) {\n    case "sq":\n      return "sq " + x.side;\n    case "ci":\n      return "ci " + x.r;\n    default:\n%s\n  }\n}\n'
              'const lie = { kind: "tri", side: 1, r: 1 } as unknown as Sq;\nfor (const s of [{ kind: "sq", side: 2 } as Shape, lie]) {\n%s\n}\n')
for use, body in (("assert_never", "return assertNever(x);"), ("never_const", 'const u: never = x;\nreturn "never " + JSON.stringify(u);'),
                  ("param", 'return "param " + shp(x);'), ("cast_decl", 'return "cast " + (x as Shape).kind;'), ("cast_any", 'return "any " + (x as any).kind;'),
                  ("log", 'console.log("default", x);\nreturn "logged";')):
    code = GEN_SWITCH % (indent(body, 6), indent(caught("f<Shape>(s)"), 2))
    add("generic-exhausted_switch-%s-direct" % use, "generic", {"narrowing": "exhausted_switch", "use": use, "context": "direct"}, code, "node")

# ----------------------------------------------------------------------------- decl family
DECLS = {
    "string": ('"s"', True), "literal_union": ('"up" as Dir', True), "number": ("2", True), "enum": ("Color.Red", True),
    "boolean": ("true", True), "null": ("null", True), "undefined": ("undefined", True), "class": ("new Pt(1)", False),
    "array": ("[1, 2]", False), "tuple": ('[1, "a"]', False), "readonly_array": ('["a"]', False), "map": ("new Map<string, number>()", False),
    "set": ("new Set<number>()", False), "date": ("new Date(0)", False), "error": ('new Error("e")', False), "function": ("() => 1", False),
    "union_prims": ('"s"', True), "union_classes": ("new Pt(1)", False), "record": ("{ a: 1 }", False), "object_type": ("{ v: 1 }", False),
}
DECL_TYPES = {"string": "string", "literal_union": "Dir", "number": "number", "enum": "Color", "boolean": "boolean", "null": "null",
              "undefined": "undefined", "class": "Pt", "array": "number[]", "tuple": "[number, string]", "readonly_array": "readonly string[]",
              "map": "Map<string, number>", "set": "Set<number>", "date": "Date", "error": "Error", "function": "() => number",
              "union_prims": "string | boolean", "union_classes": "Pt | Other", "record": "Record<string, number>", "object_type": "{ v: number }"}
DECL_TESTS = {
    "typeof_number": ('typeof x === "number"', "num(x)"),
    "typeof_string": ('typeof x === "string"', "str(x)"),
    "isarray": ("Array.isArray(x)", "len(x)"),
    "instanceof_third": ("x instanceof Third", "String(x.t)"),
    "eq_null": ("x === null", "nul(x)"),
    "falsy": ("!x", "show(x)"),
}
for dname, (value, primitive) in DECLS.items():
    decl = DECL_TYPES[dname]
    for tname, (test, typed) in DECL_TESTS.items():
        if tname == "instanceof_third" and primitive:
            continue  # TS2358: instanceof's left operand must be an object
        for use, body in (("typed", 'console.log("region", %s);' % typed), ("log", 'console.log("region", x);')):
            code = ("function f(x: %s): string {\n  if (%s) {\n    %s\n  }\n  return \"done\";\n}\n%s" % (decl, test, body, caught("f(%s)" % value)))
            add("decl-%s-%s-%s" % (dname, tname, use), "decl", {"decl": dname, "narrowing": tname, "use": use}, code, "node")


def main():
    out = sys.argv[1]
    cases_dir = os.path.join(out, "cases")
    os.makedirs(cases_dir, exist_ok=True)
    meta = []
    seen = set()
    for c in CASES:
        assert c["id"] not in seen, c["id"]
        seen.add(c["id"])
        path = os.path.join(cases_dir, c["id"] + ".pts")
        with open(path, "w") as f:
            f.write(c["code"])
        meta.append({k: c[k] for k in ("id", "family", "dims", "want", "note")} | {"file": path})
    with open(os.path.join(out, "cases.json"), "w") as f:
        json.dump(meta, f, indent=1)
    by = {}
    for c in CASES:
        by[c["family"]] = by.get(c["family"], 0) + 1
    print(len(CASES), by)


if __name__ == "__main__":
    main()
