"""Print pts's and Node's output for matrix cases.

Run: python3 -I show.py RESULTS_JSON ID_OR_REGEX... [--src]
"""

import json
import re
import sys


def main():
    results = json.load(open(sys.argv[1]))
    pats = [a for a in sys.argv[2:] if not a.startswith("--")]
    for r in results:
        if not any(p == r["id"] or re.search(p, r["id"]) for p in pats):
            continue
        print("== %s  %s  %s" % (r["id"], r["cls"], r.get("detail", "")[:160]))
        if r.get("build_output"):
            print("  build:", r["build_output"].strip().replace("\n", "\n         ")[:600])
        else:
            print("  pts :", repr(r.get("pts_stdout", "")), repr(r.get("pts_stderr", "")[:240]))
        print("  node:", repr(r["node_stdout"]), repr(r.get("node_stderr", "")[:160]) if r.get("node_exit") else "")
        if "--src" in sys.argv:
            print(open("cases/%s.pts" % r["id"]).read())


if __name__ == "__main__":
    main()
