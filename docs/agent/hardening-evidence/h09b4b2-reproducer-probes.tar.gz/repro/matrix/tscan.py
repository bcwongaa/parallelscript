"""Fast scan: pts emit-c of each case (no C compile), to find TypeScript errors (generator
mistakes) and the base's PTS errors before the full run.

Run: python3 -I tscan.py CASES_JSON OUT_JSON [--filter RE]
"""

import concurrent.futures
import json
import os
import re
import subprocess
import sys

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-aefce719334430348"
ENV = dict(os.environ, PTS_HOME=WT, PTS_CACHE_DIR="/tmp/h09b4b2/repro/.cache", GOMAXPROCS="2")


def scan(case):
    p = subprocess.run([os.path.join(WT, "pts-bin/pts"), "emit-c", case["file"], "-o", "/dev/null"], capture_output=True, env=ENV, timeout=120)
    text = (p.stdout + p.stderr).decode(errors="replace")
    ts = re.findall(r"error (TS\d+): (.*)", text)
    pe = re.findall(r"error (PTS\d+): (.*)", text)
    return {"id": case["id"], "exit": p.returncode, "ts": ts[:3], "pts": pe[:3]}


def main():
    cases = json.load(open(sys.argv[1]))
    if "--filter" in sys.argv:
        rx = sys.argv[sys.argv.index("--filter") + 1]
        cases = [c for c in cases if re.search(rx, c["id"])]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        results = list(ex.map(scan, cases))
    json.dump(results, open(sys.argv[2], "w"), indent=1)
    ts = [r for r in results if r["ts"]]
    print(len(results), "cases;", len(ts), "with TS errors")
    for r in ts:
        print(r["id"], r["ts"][0])


if __name__ == "__main__":
    main()
