#!/bin/bash
# run_limited.sh side file.pts timeout_s: build with a 6 GB address-space limit, report time and max RSS.
side=$1; f=$2; to=${3:-300}
if [ $side = base ]; then cli=/tmp/h09b5/base/pts-bin/pts; home=/tmp/h09b5/base; else cli=/tmp/h09b5/snap-a-pts; home=/tmp/h09b5/snap-a; fi
out=/tmp/h09b5/review-a/bin/$(basename $f .pts).$side.bin
( ulimit -v 6000000; PTS_HOME=$home /usr/bin/time -f "wall=%es maxrss=%MkB" timeout $to $cli build "$f" -o "$out" ) > /tmp/h09b5/review-a/bin/$(basename $f .pts).$side.limited.txt 2>&1
echo "exit=$?"
head -c 1200 /tmp/h09b5/review-a/bin/$(basename $f .pts).$side.limited.txt; echo
tail -2 /tmp/h09b5/review-a/bin/$(basename $f .pts).$side.limited.txt
[ -f "$out" ] && { timeout 20 "$out"; echo "run exit=$?"; rm -f "$out"; }
