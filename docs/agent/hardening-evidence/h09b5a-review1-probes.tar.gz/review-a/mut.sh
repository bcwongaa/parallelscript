#!/bin/bash
# mut.sh <overlay-name>: run the slice's tests under an overlay mutation of the snapshot.
m=$1
cd /tmp/h09b5/snap-a
ov=/tmp/h09b5/review-a/overlay/$m.json
out=/tmp/h09b5/review-a/mut_$m.txt
{
echo "### lower+driver"
timeout 900 go test -overlay $ov -count=1 -run 'TestPastTheInstanceCapACallIsACompileErrorNotAnInternalError|TestInterfaceCallsMakeNoDemandsInTheFallbackBuilds' ./pts/lower/ ./pts/driver/ 2>&1 | grep -E "^(--- |ok|FAIL|    )" | head -40
echo "### tests"
timeout 1800 go test -overlay $ov -count=1 -parallel 2 -run '^(TestRun|TestErrors)$/^(generic_polymorphic_recursion_.*|generic_fallback_spares_unrelated_interface_call|generic_instances_many_calls|generic_speculative_.*|generic_value_calls_many_class_instances|generic_values_read_back_from_any|generic_class_instance_failure_value_calls|generics_not_yet)$' ./pts/tests/ 2>&1 | grep -E "^(--- |ok|FAIL|    --- |        )" | head -80
} > $out 2>&1
echo done > $out.done
