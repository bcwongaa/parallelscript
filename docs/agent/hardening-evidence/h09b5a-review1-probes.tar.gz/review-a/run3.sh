#!/bin/bash
# run3.sh file.pts [timeout_s]: build+run with base, snapshot; run Node on a .mts copy.
# Prints exit codes, build wall time, C line counts (emit-c) and outputs.
f=$1; to=${2:-300}
name=$(basename "$f" .pts)
dir=/tmp/h09b5/review-a/bin
mkdir -p "$dir"
for side in base snap; do
  if [ $side = base ]; then cli=/tmp/h09b5/base/pts-bin/pts; home=/tmp/h09b5/base; else cli=/tmp/h09b5/snap-a-pts; home=/tmp/h09b5/snap-a; fi
  out=$dir/$name.$side.bin
  start=$(date +%s.%N)
  PTS_HOME=$home timeout $to $cli build "$f" -o "$out" > $dir/$name.$side.build.txt 2>&1
  code=$?
  end=$(date +%s.%N)
  printf "== %s build exit=%s wall=%.2fs\n" $side $code $(echo "$end - $start" | bc)
  head -c 1500 $dir/$name.$side.build.txt
  if [ $code = 0 ]; then
    timeout 20 "$out" > $dir/$name.$side.out.txt 2>&1; echo "-- run exit=$?"; head -c 1500 $dir/$name.$side.out.txt
    rm -f "$out"
  fi
done
cp "$f" $dir/$name.mts
echo "== node"
timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts 2>&1 | head -c 1500
rm -f $dir/$name.mts
