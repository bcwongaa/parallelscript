const c: any = undefined;
try { console.log([3, 1, 20].sort(c)); } catch (e) { console.log(String(e)); }
const d: any = (a: number, b: number) => a - b;
console.log([3, 1, 20].sort(d), [3, 1, 20].toSorted(c));
const u: unknown[] = [3, undefined, null, 1];
console.log(u.sort());
