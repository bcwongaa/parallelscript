// sort(undefined), toSorted(undefined) and a comparator that may be undefined sort in the
// default order (SortCompare with comparefn undefined), typed; the receiver is evaluated
// before the comparator. pts rejected them with PTS1001 (`converting undefined to
// (number, number) => number is not supported yet`; H06, C95).
function sorted(values: number[], compare?: (a: number, b: number) => number): number[] {
    return values.slice().sort(compare);
}
function copied(values: string[], compare?: (a: string, b: string) => number): string[] {
    return values.toSorted(compare);
}
const numbers = [10, 9, 1, 100];
console.log(sorted(numbers), sorted(numbers, (a, b) => a - b), numbers);
console.log(copied(["b", "c", "a"]), copied(["b", "c", "a"], (a, b) => (a < b ? 1 : a > b ? -1 : 0)));
console.log([3, 20, 100].sort(undefined), [3, 20, 100].toSorted(undefined));

const maybe: (number | undefined)[] = [3, undefined, 20, 1];
let byNumber: ((a: number | undefined, b: number | undefined) => number) | undefined;
console.log(maybe.slice().sort(byNumber));
byNumber = (a, b) => (a ?? 0) - (b ?? 0);
console.log(maybe.slice().sort(byNumber));

const log: string[] = [];
function receiver(): number[] {
    log.push("receiver");
    return [2, 10, 1];
}
function comparator(): ((a: number, b: number) => number) | undefined {
    log.push("comparator");
    return undefined;
}
console.log(receiver().sort(comparator()), receiver().toSorted(comparator()), log);

// expect:
