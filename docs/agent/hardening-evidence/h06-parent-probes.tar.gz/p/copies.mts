function holes(): (number | undefined)[] {
  const a = new Array<number | undefined>(4);
  a[1] = 2;
  a[2] = undefined;
  return a;
}
console.log(holes().toSorted(), holes().toReversed(), holes().with(1, 9), holes().toSpliced(0, 1));
const d: any = holes();
console.log(d.toSorted(), d.toReversed(), d.with(1, 9), d.toSpliced(0, 1));
const loose: any[] = new Array(3);
loose[1] = null;
console.log(loose.toSorted(), loose.sort(), loose.toSorted((a: any, b: any) => 0));
const s = new Array<string>(3);
s[1] = "b";
console.log(s.toSorted(), s.sort());
const frozen = Object.freeze([3, undefined, 1] as (number | undefined)[]);
try { (frozen as (number | undefined)[]).sort(); } catch (e) { console.log(String(e)); }
console.log([3, null, undefined, 1].sort((a, b) => (a ?? 0) - (b ?? 0)));
