const a = new Array<string | undefined>(3);
a[0] = "x";
console.log(1 in a, 0 in a, a);
const b = new Array<string>(3);
b[0] = "x";
console.log(1 in b, 0 in b, b);
