
const n = 9000;
function make(): (string | undefined | null)[] {
  const values = new Array<string | undefined | null>(n);
  for (let i = 0; i < n; i++) {
    if (i % 7 === 3) continue; // a hole
    values[i] = i % 11 === 0 ? undefined : i % 13 === 0 ? null : String((i * 7919) % n);
  }
  return values;
}
const values = make();
const bad = { n: 0, add(k: number) { this.n += k; }, load() { return this.n; } };
values.sort((a, b) => {
  if (a === undefined || b === undefined) bad.add(1);
  const x = a === null ? -1 : Number(a), y = b === null ? -1 : Number(b);
  return x - y;
});
console.log("cmp undefined", bad.load(), values.length);
console.log(values.slice(0, 3), values.slice(7010, 7013), values.slice(7712, 7716), values.slice(8998));
const copy = make();
copy.sort();
console.log(copy.slice(0, 4), copy.slice(7010, 7013), copy.slice(7712, 7716), copy.slice(8998));
const strs = new Array<string>(5000);
for (let i = 0; i < 5000; i += 2) strs[i] = String(5000 - i);
strs.sort((a, b) => Number(a) - Number(b));
console.log(strs.slice(0, 3), strs.slice(2498, 2502));
const strs2 = new Array<string>(5000);
for (let i = 0; i < 5000; i += 2) strs2[i] = String(5000 - i);
strs2.sort();
console.log(strs2.slice(0, 3), strs2.slice(2498, 2502));
