
const n = 9000;
const values = new Array<string | undefined | null>(n);
for (let i = 0; i < n; i++) {
  if (i % 7 === 3) continue; // a hole
  values[i] = i % 11 === 0 ? undefined : i % 13 === 0 ? null : String((i * 7919) % n);
}
const copy = values.slice();
const bad = { n: 0, add(k: number) { this.n += k; }, load() { return this.n; } };
values.sort((a, b) => {
  if (a === undefined || b === undefined) bad.add(1);
  const x = a === null ? -1 : Number(a), y = b === null ? -1 : Number(b);
  return x - y;
});
let holes = 0, undef = 0, firstUndef = -1, firstHole = -1;
for (let i = 0; i < n; i++) {
  if (!(i in values)) { holes++; if (firstHole < 0) firstHole = i; }
  else if (values[i] === undefined) { undef++; if (firstUndef < 0) firstUndef = i; }
}
console.log("cmp undefined", bad.load(), "holes", holes, "undef", undef, firstUndef, firstHole, values.length);
console.log(values.slice(0, 5), values.slice(firstUndef - 2, firstUndef + 1));
copy.sort();
let h2 = 0, u2 = 0, fu = -1, fh = -1;
for (let i = 0; i < n; i++) {
  if (!(i in copy)) { h2++; if (fh < 0) fh = i; }
  else if (copy[i] === undefined) { u2++; if (fu < 0) fu = i; }
}
console.log("default holes", h2, "undef", u2, fu, fh, copy.slice(0, 4), copy.slice(fu - 2, fu + 1));
