// `.sort` leaves an array as Array's sort does (SortCompare): the elements it compares
// first, then every undefined, then the holes, and its comparator never sees undefined or a
// hole. With 2+ threads and more than 2048 elements the library's merge called the
// comparator itself, with undefined, and the default order put holes first (H06, C06). The
// expected output is Node's for the same program with `.sort` and a plain counter.
// threads: 1 2 4


const n = 9000;

function make(): (string | undefined | null)[] {
    const values = new Array<string | undefined | null>(n);
    for (let i = 0; i < n; i++) {
        if (i % 7 === 3) {
            continue;
        }
        values[i] = i % 11 === 0 ? undefined : i % 13 === 0 ? null : String((i * 7919) % n);
    }
    return values;
}

const values = make();
const undefinedArguments = { n: 0, add(k: number) { this.n += k; }, load() { return this.n; } };
values.sort((a, b) => {
    if (a === undefined || b === undefined) {
        undefinedArguments.add(1);
    }
    const x = a === null ? -1 : Number(a);
    const y = b === null ? -1 : Number(b);
    return x - y;
});
console.log("comparator saw undefined:", undefinedArguments.load() > 0, values.length);
console.log(values.slice(0, 3), values.slice(7010, 7013), values.slice(7712, 7716), values.slice(8998));

const byStrings = make();
byStrings.sort();
console.log(byStrings.slice(0, 4), byStrings.slice(7010, 7013), byStrings.slice(7712, 7716), byStrings.slice(8998));

const words = new Array<string>(5000);
for (let i = 0; i < 5000; i += 2) {
    words[i] = String(5000 - i);
}
words.sort((a, b) => Number(a) - Number(b));
console.log(words.slice(0, 3), words.slice(2498, 2502));

// expect:
// comparator saw undefined: false 9000
// [ null, null, null ] [ '8998', '8999', undefined ] [ undefined, undefined, <2 empty items> ] [ <2 empty items> ]
// [ '10', '1000', '1002', '1004' ] [ null, null, undefined ] [ undefined, undefined, <2 empty items> ] [ <2 empty items> ]
// [ '2', '4', '6' ] [ '4998', '5000', <2 empty items> ]
