Sequential Node twins of H06a's `.par` run tests: each is the test up to its expect block with
the `pts:sync` import removed, `new AtomicInt()` replaced by a plain counter object and `.par.sort`
replaced by `.sort` (sed in h06.md). `<name>.node.out` is Node v24.21.0's stdout, equal to the
test's expect block.
