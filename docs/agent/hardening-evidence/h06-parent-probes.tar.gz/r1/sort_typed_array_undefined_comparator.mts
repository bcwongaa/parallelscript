// A typed array's sort(undefined), toSorted(undefined) and a comparator that may be
// undefined sort in its own default order, numerically (-0 before 0, NaN last), as with
// no argument. H06a's first version sorted them in Array's string order (review round 1,
// F1); before it they were PTS1001.
function sorted(values: Float64Array, compare?: (a: number, b: number) => number): Float64Array {
    return values.slice().sort(compare);
}
function copied(values: Int32Array, compare?: (a: number, b: number) => number): Int32Array {
    return values.toSorted(compare);
}
const doubles = new Float64Array([10, 9, NaN, 0, -0, 100, 1]);
console.log(sorted(doubles), doubles);
console.log(sorted(new Float64Array([10, 9, 100]), (a, b) => b - a));
const ints = new Int32Array([100, 9, 10, 1]);
console.log(copied(ints), copied(ints, (a, b) => b - a), ints);
console.log(new Uint8Array([100, 9, 10, 1]).sort(undefined), new Uint8Array([100, 9, 10, 1]).toSorted(undefined));
let descending: ((a: number, b: number) => number) | undefined;
console.log(new Float64Array([10, 9, 100]).sort(descending));
descending = (a, b) => b - a;
console.log(new Float64Array([10, 9, 100]).sort(descending));

// expect:
