// The comparator argument is evaluated before the sort reads the elements.
const ta = new Int32Array([3, 1, 2]);
function changes(): (a: number, b: number) => number {
  ta[0] = 0;
  return (a, b) => a - b;
}
console.log("typed sort(changes())", ta.sort(changes()));
const tb = new Int32Array([3, 1, 2]);
function changesOptional(): ((a: number, b: number) => number) | undefined {
  tb[0] = 0;
  return (a, b) => a - b;
}
console.log("typed sort(optional)", tb.sort(changesOptional()));
const tc = new Int32Array([3, 1, 2]);
function changesC(): (a: number, b: number) => number {
  tc[0] = 0;
  return (a, b) => b - a;
}
console.log("typed toSorted(changes())", tc.toSorted(changesC()), tc);
const arr = [3, 1, 2];
function changesArr(): (a: number, b: number) => number {
  arr.push(0);
  return (a, b) => a - b;
}
console.log("array sort(changes())", arr.sort(changesArr()));
const log: string[] = [];
function recv(): Float64Array { log.push("receiver"); return new Float64Array([2, 10, 1]); }
function cmp(): (a: number, b: number) => number { log.push("comparator"); return (a, b) => a - b; }
console.log(recv().sort(cmp()), recv().toSorted(cmp()), log);
