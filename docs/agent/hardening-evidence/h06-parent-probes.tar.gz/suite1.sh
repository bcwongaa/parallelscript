#!/bin/bash
set -o pipefail
cd /tmp/h06-suite
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
GOMAXPROCS=2 go build -p 2 ./... > /tmp/h06/suite1-build.txt 2>&1 || { echo "build $?" > /tmp/h06/suite1.exit; exit 1; }
GOMAXPROCS=2 make build >> /tmp/h06/suite1-build.txt 2>&1 || { echo "make $?" > /tmp/h06/suite1.exit; exit 1; }
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 2 -parallel 2 -timeout 40m ./pts/... ./cmd/pts/ > /tmp/h06/suite1.jsonl 2> /tmp/h06/suite1.stderr
echo "test $?" > /tmp/h06/suite1.exit
