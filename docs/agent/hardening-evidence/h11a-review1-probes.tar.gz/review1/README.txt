H11a review round 1 (reviewer, snapshot /tmp/h11/snap2 vs base /tmp/h11/base).
tools/run.sh FILE...    run under Node (.mts copy), the snapshot and the base CLI; outputs in out/<name>.{node,snap,base}[.err|.build]
tools/summ.py LOG       summarize run.sh logs
tools/run_matrix.py     the reproducer's runner with review paths; matrix/results-snap2.jsonl = families A,B,C,F,G on snap2
repro/                  minimal reproducers for the findings (r1..r11)
probes/                 exploratory probes (bi/, bi2/: builtins; el/: element reads and present values; nar/: narrowed loose locals; split/: per-case splits)
perf/                   callgrind programs; perf/callgrind.txt instruction counts (base vs snap)
