"""Run H11's matrix: each case under Node and pts, classified.

Classes: OK (pts prints what Node prints and exits alike), TYPEERR / RANGEERR (pts
throws that error where Node doesn't: the first differing line is pts's "threw
TypeError" / "threw RangeError"), THREW (another error), WRONG (other output), PTS1001,
PTS9001 (an internal compiler error, exit 3), TSERR (tsc rejects the case: a generator
bug), BUILDERR (another build failure), CRASH (a signal or an uncaught exit), TIMEOUT.

Usage: python3 -I run_matrix.py CASES.jsonl RESULTS.jsonl [--jobs N] [--filter REGEX]
       [--pts PATH] [--home DIR]
Jobs: at most 1 build at a time until /tmp/h11/baseline.done exists, then up to N.
Results are appended; cases already in RESULTS are skipped (resume).
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor

NODE = os.path.expanduser("~/.local/node/bin/node")
MARKER = "/tmp/h11/suite-snap2.done"
BIN_DIR = "/tmp/h11/review1/bin"


class Slots:
    """At most one heavy job before the marker exists, then up to n."""

    def __init__(self, n):
        self.n = n
        self.active = 0
        self.cond = threading.Condition()

    def allowed(self):
        return self.n if os.path.exists(MARKER) else 1

    def __enter__(self):
        with self.cond:
            while self.active >= self.allowed():
                self.cond.wait(timeout=5)
            self.active += 1

    def __exit__(self, *exc):
        with self.cond:
            self.active -= 1
            self.cond.notify_all()


def run(cmd, timeout, env=None, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, timeout=timeout, env=env, cwd=cwd)
        return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace")
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode("utf-8", "replace")
        err = (e.stderr or b"").decode("utf-8", "replace")
        return "timeout", out, err


def run_node(path, scratch):
    mts = os.path.join(scratch, os.path.basename(path)[:-4] + ".mts")
    shutil.copyfile(path, mts)
    env = dict(os.environ, TZ="America/New_York")
    code, out, err = run([NODE, "--no-warnings", "--experimental-transform-types", mts], 30, env=env)
    os.remove(mts)
    return code, out, err


def run_pts(path, pts, home, ident):
    env = dict(os.environ, TZ="America/New_York", PTS_HOME=home)
    binary = os.path.join(BIN_DIR, ident + ".bin")
    code, out, err = run([pts, "build", path, "-o", binary], 300, env=env)
    build = out + err
    if code != 0:
        if os.path.exists(binary):
            os.remove(binary)
        return dict(build_exit=code, build=build)
    try:
        rcode, rout, rerr = run([binary], 30, env=env)
    finally:
        if os.path.exists(binary):
            os.remove(binary)
    return dict(build_exit=0, build=build, exit=rcode, stdout=rout, stderr=rerr)


def classify(node, pts):
    ncode, nout, _ = node
    if pts["build_exit"] != 0:
        text = pts["build"]
        if pts["build_exit"] == "timeout":
            return "TIMEOUT"
        if pts["build_exit"] == 3 or "PTS9001" in text or "internal compiler error" in text:
            return "PTS9001"
        if "PTS1001" in text:
            return "PTS1001"
        if re.search(r"error TS\d+", text):
            return "TSERR"
        return "BUILDERR"
    if pts["exit"] == "timeout":
        return "TIMEOUT"
    if pts["stdout"] == nout and pts["exit"] == ncode:
        return "OK"
    if isinstance(pts["exit"], int) and (pts["exit"] < 0 or pts["exit"] >= 128):
        return "CRASH"
    plines, nlines = pts["stdout"].split("\n"), nout.split("\n")
    for i, line in enumerate(plines):
        other = nlines[i] if i < len(nlines) else None
        if line == other:
            continue
        m = re.match(r"threw (\w+)", line)
        if m and not (other or "").startswith("threw " + m.group(1)):
            return {"TypeError": "TYPEERR", "RangeError": "RANGEERR"}.get(m.group(1), "THREW")
        break
    if pts["exit"] != ncode:
        if "Uncaught TypeError" in pts["stderr"]:
            return "TYPEERR"
        if "Uncaught RangeError" in pts["stderr"]:
            return "RANGEERR"
        return "CRASH"
    return "WRONG"


def message(stderr):
    for line in stderr.split("\n"):
        if line.startswith("message:"):
            return line[len("message:"):].strip()
    return stderr.strip().split("\n")[0][:300] if stderr.strip() else ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cases")
    ap.add_argument("results")
    ap.add_argument("--jobs", type=int, default=1)
    ap.add_argument("--filter", default="")
    ap.add_argument("--force", action="store_true", help="rerun matching cases even if they have results")
    ap.add_argument("--pts", default="/home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83/pts-bin/pts")
    ap.add_argument("--home", default="/home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83")
    args = ap.parse_args()
    os.makedirs(BIN_DIR, exist_ok=True)
    done = set()
    if os.path.exists(args.results):
        with open(args.results) as f:
            for line in f:
                done.add(json.loads(line)["id"])
    with open(args.cases) as f:
        cases = [json.loads(line) for line in f]
    pattern = re.compile(args.filter)
    todo = [c for c in cases if (args.force or c["id"] not in done) and pattern.search(json.dumps(c))]
    print(len(todo), "cases to run", flush=True)
    slots = Slots(args.jobs)
    lock = threading.Lock()
    scratch = tempfile.mkdtemp(prefix="h11-node-")
    out = open(args.results, "a")
    count = [0]

    def one(case):
        with slots:
            node = run_node(case["path"], scratch)
            pts = run_pts(case["path"], args.pts, args.home, case["id"])
        cls = classify(node, pts)
        record = dict(case)
        record.update(cls=cls, node_exit=node[0], node_stdout=node[1][-2000:],
                      pts_exit=pts.get("exit"), pts_stdout=pts.get("stdout", "")[-2000:],
                      pts_message=message(pts.get("stderr", "")), build=pts["build"][-1500:] if pts["build_exit"] != 0 else "")
        with lock:
            out.write(json.dumps(record) + "\n")
            out.flush()
            count[0] += 1
            if count[0] % 25 == 0:
                print(count[0], "done", flush=True)

    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        list(pool.map(one, todo))
    out.close()
    shutil.rmtree(scratch, ignore_errors=True)
    print("finished", count[0], flush=True)


if __name__ == "__main__":
    main()
