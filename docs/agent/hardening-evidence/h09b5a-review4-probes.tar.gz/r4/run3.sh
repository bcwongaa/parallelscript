#!/bin/bash
# run3.sh file.pts [timeout_s]: base CLI and snap-c CLI build (6 GB limit, wall/RSS) + run, then Node (.mts copy).
f=$1; to=${2:-300}; name=$(basename "$f" .pts); dir=/tmp/h09b5/review-a/r4/bin; mkdir -p $dir
for side in base snapd; do
  if [ $side = base ]; then cli=/tmp/h09b5/base/pts-bin/pts; home=/tmp/h09b5/base; else cli=/tmp/h09b5/snap-d-pts; home=/tmp/h09b5/snap-d; fi
  out=$dir/$name.$side.bin
  ( ulimit -v 6000000; PTS_HOME=$home /usr/bin/time -f "wall=%es maxrss=%MkB" timeout $to $cli build "$f" -o "$out" ) > $dir/$name.$side.build.txt 2>&1
  code=$?
  echo "== $side build exit=$code $(grep '^wall=' $dir/$name.$side.build.txt | tail -1)"
  grep -v '^wall=\|^Command exited' $dir/$name.$side.build.txt | head -c 1200
  if [ -f "$out" ]; then timeout 20 "$out" > $dir/$name.$side.out.txt 2>&1; echo "-- run exit=$?"; head -c 1200 $dir/$name.$side.out.txt; rm -f "$out"; fi
done
cp "$f" $dir/$name.mts; echo "== node"; timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts 2>&1 | head -c 1200; rm -f $dir/$name.mts
