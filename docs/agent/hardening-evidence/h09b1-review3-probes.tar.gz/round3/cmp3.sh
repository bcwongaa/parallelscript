#!/bin/bash
# cmp3.sh file.pts...: run each program with the base CLI, the snapshot CLI and Node v24
# (.mts copy, --no-warnings --experimental-transform-types, TZ=America/New_York) and print all three.
set -uo pipefail
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0")
  b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09b1-review/tmp/cmp.XXXX)
  cp "$f" "$d/$b.mts"
  base_out=$(cd "$d" && TZ=America/New_York PTS_CACHE_DIR=/tmp/h09b1-review/cache-base PTS_HOME=/tmp/h09b/base/tree timeout 300 /tmp/h09b/base/tree/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  snap_out=$(cd "$d" && TZ=America/New_York PTS_CACHE_DIR=/tmp/h09b1-review/cache-snap5 PTS_HOME=/tmp/h09b/snap5 timeout 300 /tmp/h09b1-review/round3/pts-snap5 run "$f" 2>&1; echo "[exit $?]")
  node_out=$(cd "$d" && TZ=America/New_York timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  tag=""
  [ "$snap_out" == "$node_out" ] && tag="$tag snap=node" || tag="$tag snap!=node"
  [ "$base_out" == "$snap_out" ] && tag="$tag base=snap" || tag="$tag base!=snap"
  echo "== $b:$tag"
  echo "-- base"; echo "$base_out"; echo "-- snap"; echo "$snap_out"; echo "-- node"; echo "$node_out" | head -40
  rm -rf "$d"
done
