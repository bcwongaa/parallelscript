#!/bin/bash
# one.sh file.pts: emit C with snap5 alone in All, Value and Declared modes; prints file, tree, mode, exit, C lines.
f=$1
out=/tmp/h09b1-review/round3/growth/c
mkdir -p $out
n=$(echo "$f" | sed 's|/tmp/h09b/snap5/pts/tests/||; s|/|__|g')
for m in all value declared; do
  arg=""; [ $m != all ] && arg=$m
  timeout 300 /tmp/h09b1-review/allinst/ptsall_snap5 "$f" $arg > $out/$n.$m.c 2> $out/$n.$m.err
  e=$?
  printf "%s\t%s\t%s\t%s\t%s\n" "$n" "snap5" "$m" "$e" "$(wc -l < $out/$n.$m.c)"
  rm -f $out/$n.$m.c
done
