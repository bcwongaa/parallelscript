// ptsall: emit C with lower.AllInstances alone (no fallback), printing its errors.
package main

import (
	"context"
	"fmt"
	"os"

	"errors"

	"github.com/microsoft/typescript-go/pts/diagnostic"
	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func main() {
	spec := lower.AllInstances
	if len(os.Args) > 2 && os.Args[2] == "value" {
		spec = lower.ValueInstances
	}
	if len(os.Args) > 2 && os.Args[2] == "declared" {
		spec = lower.DeclaredInstances
	}
	code, err := driver.EmitCWith(context.Background(), os.Args[1], spec)
	if err != nil {
		fmt.Fprintln(os.Stderr, "ERROR:", err)
		var internal *diagnostic.InternalError
		if os.Getenv("DETAIL") != "" && errors.As(err, &internal) {
			fmt.Fprintln(os.Stderr, internal.Detail)
			for _, d := range internal.Earlier {
				fmt.Fprintln(os.Stderr, "earlier:", d.Format(""))
			}
		}
		os.Exit(1)
	}
	fmt.Print(code)
}
