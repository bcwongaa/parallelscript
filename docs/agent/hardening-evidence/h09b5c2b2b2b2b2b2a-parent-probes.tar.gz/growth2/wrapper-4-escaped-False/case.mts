class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
function escape(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(value: Factory): void { const box: Box<C0> = value(new C0()); console.log(box.value.tag); }
function read0(): Factory { const value: Maker = new M0(); return value.make; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(value: Factory): void { const box: Box<C1> = value(new C1()); console.log(box.value.tag); }
function read1(): Factory { const value: Maker = new M1(); return value.make; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(value: Factory): void { const box: Box<C2> = value(new C2()); console.log(box.value.tag); }
function read2(): Factory { const value: Maker = new M2(); return value.make; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(value: Factory): void { const box: Box<C3> = value(new C3()); console.log(box.value.tag); }
function read3(): Factory { const value: Maker = new M3(); return value.make; }
const selected0: Factory = read0(); const other0: Factory = read1();
const root0 = { branch: { child: { value: selected0, alternate: other0 }, side: [other0] } };
const { branch: { child: child0, side: side0 } } = root0;
const alias0 = child0; const ignored0 = side0[0];
use0(alias0.value);
const selected1: Factory = read1(); const other1: Factory = read2();
const root1 = { branch: { child: { value: selected1, alternate: other1 }, side: [other1] } };
const { branch: { child: child1, side: side1 } } = root1;
const alias1 = child1; const ignored1 = side1[0];
use1(alias1.value);
const selected2: Factory = read2(); const other2: Factory = read3();
const root2 = { branch: { child: { value: selected2, alternate: other2 }, side: [other2] } };
const { branch: { child: child2, side: side2 } } = root2;
const alias2 = child2; const ignored2 = side2[0];
use2(alias2.value);
const selected3: Factory = read3(); const other3: Factory = read0();
const root3 = { branch: { child: { value: selected3, alternate: other3 }, side: [other3] } };
const { branch: { child: child3, side: side3 } } = root3;
const alias3 = child3; const ignored3 = side3[0];
use3(alias3.value);
