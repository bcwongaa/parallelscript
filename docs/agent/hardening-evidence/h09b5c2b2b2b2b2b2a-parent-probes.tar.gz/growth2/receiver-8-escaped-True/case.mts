class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
function escape(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(value: Maker): void { const box: Box<C0> = value.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(value: Maker): void { const box: Box<C1> = value.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(value: Maker): void { const box: Box<C2> = value.make(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(value: Maker): void { const box: Box<C3> = value.make(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(value: Maker): void { const box: Box<C4> = value.make(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(value: Maker): void { const box: Box<C5> = value.make(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(value: Maker): void { const box: Box<C6> = value.make(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(value: Maker): void { const box: Box<C7> = value.make(new C7()); console.log(box.value.tag); }
const selected0: Maker = new M0(); const other0: Maker = new M1();
const root0 = { branch: { child: { value: selected0, alternate: other0 }, side: [other0] } };
const { branch: { child: child0, side: side0 } } = root0;
const alias0 = child0; const ignored0 = side0[0];
escape(child0);
use0(alias0.value);
const selected1: Maker = new M1(); const other1: Maker = new M2();
const root1 = { branch: { child: { value: selected1, alternate: other1 }, side: [other1] } };
const { branch: { child: child1, side: side1 } } = root1;
const alias1 = child1; const ignored1 = side1[0];
escape(child1);
use1(alias1.value);
const selected2: Maker = new M2(); const other2: Maker = new M3();
const root2 = { branch: { child: { value: selected2, alternate: other2 }, side: [other2] } };
const { branch: { child: child2, side: side2 } } = root2;
const alias2 = child2; const ignored2 = side2[0];
escape(child2);
use2(alias2.value);
const selected3: Maker = new M3(); const other3: Maker = new M4();
const root3 = { branch: { child: { value: selected3, alternate: other3 }, side: [other3] } };
const { branch: { child: child3, side: side3 } } = root3;
const alias3 = child3; const ignored3 = side3[0];
escape(child3);
use3(alias3.value);
const selected4: Maker = new M4(); const other4: Maker = new M5();
const root4 = { branch: { child: { value: selected4, alternate: other4 }, side: [other4] } };
const { branch: { child: child4, side: side4 } } = root4;
const alias4 = child4; const ignored4 = side4[0];
escape(child4);
use4(alias4.value);
const selected5: Maker = new M5(); const other5: Maker = new M6();
const root5 = { branch: { child: { value: selected5, alternate: other5 }, side: [other5] } };
const { branch: { child: child5, side: side5 } } = root5;
const alias5 = child5; const ignored5 = side5[0];
escape(child5);
use5(alias5.value);
const selected6: Maker = new M6(); const other6: Maker = new M7();
const root6 = { branch: { child: { value: selected6, alternate: other6 }, side: [other6] } };
const { branch: { child: child6, side: side6 } } = root6;
const alias6 = child6; const ignored6 = side6[0];
escape(child6);
use6(alias6.value);
const selected7: Maker = new M7(); const other7: Maker = new M0();
const root7 = { branch: { child: { value: selected7, alternate: other7 }, side: [other7] } };
const { branch: { child: child7, side: side7 } } = root7;
const alias7 = child7; const ignored7 = side7[0];
escape(child7);
use7(alias7.value);
