import hashlib, json, os, pathlib, subprocess, sys, time
ROOT = pathlib.Path('/home/bryan/projects/parallelscript')
OUT = pathlib.Path('/tmp/pts-destructure-20261022-parent') / sys.argv[1]
OUT.mkdir()
def sources():
    result = {}
    for base in ('pts', 'cmd/pts', 'internal'):
        for p in (ROOT / base).rglob('*'):
            if p.is_file() and p.suffix in ('.go', '.pts', '.c', '.h', '.ts', '.json'):
                result[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return result
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
before = sources(); save('sources-before.json', before)
start = time.monotonic()
with (OUT/'build.stdout').open('w') as out, (OUT/'build.stderr').open('w') as err:
    build = subprocess.run(['make', 'build'], cwd=ROOT, env=env, stdout=out, stderr=err)
if build.returncode:
    save('summary.json', {'build_exit': build.returncode}); sys.exit(build.returncode)
cli_before = hashlib.sha256((ROOT/'pts-bin/pts').read_bytes()).hexdigest()
command = ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']
with (OUT/'suite.jsonl').open('w') as out, (OUT/'suite.stderr').open('w') as err:
    run = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=err)
counts = {k:0 for k in ('pass', 'skip', 'fail')}; packages = {}; corpus = {k:0 for k in counts}
for line in (OUT/'suite.jsonl').read_text().splitlines():
    item = json.loads(line); action = item.get('Action'); test = item.get('Test')
    if test and action in counts:
        counts[action] += 1
        if test.startswith('TestCorpusMatchesNode/'):
            corpus[action] += 1
    elif not test and action in counts: packages[item['Package']] = action
save('sources-after.json', sources())
summary = {'command': command, 'build_exit': build.returncode, 'suite_exit': run.returncode, 'counts':counts, 'packages':packages, 'corpus':corpus, 'elapsed_seconds':time.monotonic()-start, 'source_count':len(before), 'sources_unchanged':before==sources(), 'cli_unchanged':cli_before==hashlib.sha256((ROOT/'pts-bin/pts').read_bytes()).hexdigest(), 'cli_sha256':cli_before, 'stderr_bytes':{name:(OUT/name).stat().st_size for name in ('build.stderr','suite.stderr')}}
save('summary.json', summary); print(json.dumps(summary), flush=True)
sys.exit(run.returncode or (0 if summary['sources_unchanged'] and summary['cli_unchanged'] else 2))
