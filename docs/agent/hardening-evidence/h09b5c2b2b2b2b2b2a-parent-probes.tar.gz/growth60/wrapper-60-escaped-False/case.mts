class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
function escape(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(value: Factory): void { const box: Box<C0> = value(new C0()); console.log(box.value.tag); }
function read0(): Factory { const value: Maker = new M0(); return value.make; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(value: Factory): void { const box: Box<C1> = value(new C1()); console.log(box.value.tag); }
function read1(): Factory { const value: Maker = new M1(); return value.make; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(value: Factory): void { const box: Box<C2> = value(new C2()); console.log(box.value.tag); }
function read2(): Factory { const value: Maker = new M2(); return value.make; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(value: Factory): void { const box: Box<C3> = value(new C3()); console.log(box.value.tag); }
function read3(): Factory { const value: Maker = new M3(); return value.make; }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(value: Factory): void { const box: Box<C4> = value(new C4()); console.log(box.value.tag); }
function read4(): Factory { const value: Maker = new M4(); return value.make; }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(value: Factory): void { const box: Box<C5> = value(new C5()); console.log(box.value.tag); }
function read5(): Factory { const value: Maker = new M5(); return value.make; }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(value: Factory): void { const box: Box<C6> = value(new C6()); console.log(box.value.tag); }
function read6(): Factory { const value: Maker = new M6(); return value.make; }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(value: Factory): void { const box: Box<C7> = value(new C7()); console.log(box.value.tag); }
function read7(): Factory { const value: Maker = new M7(); return value.make; }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(value: Factory): void { const box: Box<C8> = value(new C8()); console.log(box.value.tag); }
function read8(): Factory { const value: Maker = new M8(); return value.make; }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(value: Factory): void { const box: Box<C9> = value(new C9()); console.log(box.value.tag); }
function read9(): Factory { const value: Maker = new M9(); return value.make; }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(value: Factory): void { const box: Box<C10> = value(new C10()); console.log(box.value.tag); }
function read10(): Factory { const value: Maker = new M10(); return value.make; }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(value: Factory): void { const box: Box<C11> = value(new C11()); console.log(box.value.tag); }
function read11(): Factory { const value: Maker = new M11(); return value.make; }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(value: Factory): void { const box: Box<C12> = value(new C12()); console.log(box.value.tag); }
function read12(): Factory { const value: Maker = new M12(); return value.make; }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(value: Factory): void { const box: Box<C13> = value(new C13()); console.log(box.value.tag); }
function read13(): Factory { const value: Maker = new M13(); return value.make; }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(value: Factory): void { const box: Box<C14> = value(new C14()); console.log(box.value.tag); }
function read14(): Factory { const value: Maker = new M14(); return value.make; }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(value: Factory): void { const box: Box<C15> = value(new C15()); console.log(box.value.tag); }
function read15(): Factory { const value: Maker = new M15(); return value.make; }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(value: Factory): void { const box: Box<C16> = value(new C16()); console.log(box.value.tag); }
function read16(): Factory { const value: Maker = new M16(); return value.make; }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(value: Factory): void { const box: Box<C17> = value(new C17()); console.log(box.value.tag); }
function read17(): Factory { const value: Maker = new M17(); return value.make; }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(value: Factory): void { const box: Box<C18> = value(new C18()); console.log(box.value.tag); }
function read18(): Factory { const value: Maker = new M18(); return value.make; }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(value: Factory): void { const box: Box<C19> = value(new C19()); console.log(box.value.tag); }
function read19(): Factory { const value: Maker = new M19(); return value.make; }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(value: Factory): void { const box: Box<C20> = value(new C20()); console.log(box.value.tag); }
function read20(): Factory { const value: Maker = new M20(); return value.make; }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(value: Factory): void { const box: Box<C21> = value(new C21()); console.log(box.value.tag); }
function read21(): Factory { const value: Maker = new M21(); return value.make; }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(value: Factory): void { const box: Box<C22> = value(new C22()); console.log(box.value.tag); }
function read22(): Factory { const value: Maker = new M22(); return value.make; }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(value: Factory): void { const box: Box<C23> = value(new C23()); console.log(box.value.tag); }
function read23(): Factory { const value: Maker = new M23(); return value.make; }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(value: Factory): void { const box: Box<C24> = value(new C24()); console.log(box.value.tag); }
function read24(): Factory { const value: Maker = new M24(); return value.make; }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(value: Factory): void { const box: Box<C25> = value(new C25()); console.log(box.value.tag); }
function read25(): Factory { const value: Maker = new M25(); return value.make; }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(value: Factory): void { const box: Box<C26> = value(new C26()); console.log(box.value.tag); }
function read26(): Factory { const value: Maker = new M26(); return value.make; }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(value: Factory): void { const box: Box<C27> = value(new C27()); console.log(box.value.tag); }
function read27(): Factory { const value: Maker = new M27(); return value.make; }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(value: Factory): void { const box: Box<C28> = value(new C28()); console.log(box.value.tag); }
function read28(): Factory { const value: Maker = new M28(); return value.make; }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(value: Factory): void { const box: Box<C29> = value(new C29()); console.log(box.value.tag); }
function read29(): Factory { const value: Maker = new M29(); return value.make; }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(value: Factory): void { const box: Box<C30> = value(new C30()); console.log(box.value.tag); }
function read30(): Factory { const value: Maker = new M30(); return value.make; }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(value: Factory): void { const box: Box<C31> = value(new C31()); console.log(box.value.tag); }
function read31(): Factory { const value: Maker = new M31(); return value.make; }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(value: Factory): void { const box: Box<C32> = value(new C32()); console.log(box.value.tag); }
function read32(): Factory { const value: Maker = new M32(); return value.make; }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(value: Factory): void { const box: Box<C33> = value(new C33()); console.log(box.value.tag); }
function read33(): Factory { const value: Maker = new M33(); return value.make; }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(value: Factory): void { const box: Box<C34> = value(new C34()); console.log(box.value.tag); }
function read34(): Factory { const value: Maker = new M34(); return value.make; }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(value: Factory): void { const box: Box<C35> = value(new C35()); console.log(box.value.tag); }
function read35(): Factory { const value: Maker = new M35(); return value.make; }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(value: Factory): void { const box: Box<C36> = value(new C36()); console.log(box.value.tag); }
function read36(): Factory { const value: Maker = new M36(); return value.make; }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(value: Factory): void { const box: Box<C37> = value(new C37()); console.log(box.value.tag); }
function read37(): Factory { const value: Maker = new M37(); return value.make; }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(value: Factory): void { const box: Box<C38> = value(new C38()); console.log(box.value.tag); }
function read38(): Factory { const value: Maker = new M38(); return value.make; }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(value: Factory): void { const box: Box<C39> = value(new C39()); console.log(box.value.tag); }
function read39(): Factory { const value: Maker = new M39(); return value.make; }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(value: Factory): void { const box: Box<C40> = value(new C40()); console.log(box.value.tag); }
function read40(): Factory { const value: Maker = new M40(); return value.make; }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(value: Factory): void { const box: Box<C41> = value(new C41()); console.log(box.value.tag); }
function read41(): Factory { const value: Maker = new M41(); return value.make; }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(value: Factory): void { const box: Box<C42> = value(new C42()); console.log(box.value.tag); }
function read42(): Factory { const value: Maker = new M42(); return value.make; }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(value: Factory): void { const box: Box<C43> = value(new C43()); console.log(box.value.tag); }
function read43(): Factory { const value: Maker = new M43(); return value.make; }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(value: Factory): void { const box: Box<C44> = value(new C44()); console.log(box.value.tag); }
function read44(): Factory { const value: Maker = new M44(); return value.make; }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(value: Factory): void { const box: Box<C45> = value(new C45()); console.log(box.value.tag); }
function read45(): Factory { const value: Maker = new M45(); return value.make; }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(value: Factory): void { const box: Box<C46> = value(new C46()); console.log(box.value.tag); }
function read46(): Factory { const value: Maker = new M46(); return value.make; }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(value: Factory): void { const box: Box<C47> = value(new C47()); console.log(box.value.tag); }
function read47(): Factory { const value: Maker = new M47(); return value.make; }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(value: Factory): void { const box: Box<C48> = value(new C48()); console.log(box.value.tag); }
function read48(): Factory { const value: Maker = new M48(); return value.make; }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(value: Factory): void { const box: Box<C49> = value(new C49()); console.log(box.value.tag); }
function read49(): Factory { const value: Maker = new M49(); return value.make; }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(value: Factory): void { const box: Box<C50> = value(new C50()); console.log(box.value.tag); }
function read50(): Factory { const value: Maker = new M50(); return value.make; }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(value: Factory): void { const box: Box<C51> = value(new C51()); console.log(box.value.tag); }
function read51(): Factory { const value: Maker = new M51(); return value.make; }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(value: Factory): void { const box: Box<C52> = value(new C52()); console.log(box.value.tag); }
function read52(): Factory { const value: Maker = new M52(); return value.make; }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(value: Factory): void { const box: Box<C53> = value(new C53()); console.log(box.value.tag); }
function read53(): Factory { const value: Maker = new M53(); return value.make; }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(value: Factory): void { const box: Box<C54> = value(new C54()); console.log(box.value.tag); }
function read54(): Factory { const value: Maker = new M54(); return value.make; }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(value: Factory): void { const box: Box<C55> = value(new C55()); console.log(box.value.tag); }
function read55(): Factory { const value: Maker = new M55(); return value.make; }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(value: Factory): void { const box: Box<C56> = value(new C56()); console.log(box.value.tag); }
function read56(): Factory { const value: Maker = new M56(); return value.make; }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(value: Factory): void { const box: Box<C57> = value(new C57()); console.log(box.value.tag); }
function read57(): Factory { const value: Maker = new M57(); return value.make; }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(value: Factory): void { const box: Box<C58> = value(new C58()); console.log(box.value.tag); }
function read58(): Factory { const value: Maker = new M58(); return value.make; }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(value: Factory): void { const box: Box<C59> = value(new C59()); console.log(box.value.tag); }
function read59(): Factory { const value: Maker = new M59(); return value.make; }
const selected0: Factory = read0(); const other0: Factory = read1();
const root0 = { branch: { child: { value: selected0, alternate: other0 }, side: [other0] } };
const { branch: { child: child0, side: side0 } } = root0;
const alias0 = child0; const ignored0 = side0[0];
use0(alias0.value);
const selected1: Factory = read1(); const other1: Factory = read2();
const root1 = { branch: { child: { value: selected1, alternate: other1 }, side: [other1] } };
const { branch: { child: child1, side: side1 } } = root1;
const alias1 = child1; const ignored1 = side1[0];
use1(alias1.value);
const selected2: Factory = read2(); const other2: Factory = read3();
const root2 = { branch: { child: { value: selected2, alternate: other2 }, side: [other2] } };
const { branch: { child: child2, side: side2 } } = root2;
const alias2 = child2; const ignored2 = side2[0];
use2(alias2.value);
const selected3: Factory = read3(); const other3: Factory = read4();
const root3 = { branch: { child: { value: selected3, alternate: other3 }, side: [other3] } };
const { branch: { child: child3, side: side3 } } = root3;
const alias3 = child3; const ignored3 = side3[0];
use3(alias3.value);
const selected4: Factory = read4(); const other4: Factory = read5();
const root4 = { branch: { child: { value: selected4, alternate: other4 }, side: [other4] } };
const { branch: { child: child4, side: side4 } } = root4;
const alias4 = child4; const ignored4 = side4[0];
use4(alias4.value);
const selected5: Factory = read5(); const other5: Factory = read6();
const root5 = { branch: { child: { value: selected5, alternate: other5 }, side: [other5] } };
const { branch: { child: child5, side: side5 } } = root5;
const alias5 = child5; const ignored5 = side5[0];
use5(alias5.value);
const selected6: Factory = read6(); const other6: Factory = read7();
const root6 = { branch: { child: { value: selected6, alternate: other6 }, side: [other6] } };
const { branch: { child: child6, side: side6 } } = root6;
const alias6 = child6; const ignored6 = side6[0];
use6(alias6.value);
const selected7: Factory = read7(); const other7: Factory = read8();
const root7 = { branch: { child: { value: selected7, alternate: other7 }, side: [other7] } };
const { branch: { child: child7, side: side7 } } = root7;
const alias7 = child7; const ignored7 = side7[0];
use7(alias7.value);
const selected8: Factory = read8(); const other8: Factory = read9();
const root8 = { branch: { child: { value: selected8, alternate: other8 }, side: [other8] } };
const { branch: { child: child8, side: side8 } } = root8;
const alias8 = child8; const ignored8 = side8[0];
use8(alias8.value);
const selected9: Factory = read9(); const other9: Factory = read10();
const root9 = { branch: { child: { value: selected9, alternate: other9 }, side: [other9] } };
const { branch: { child: child9, side: side9 } } = root9;
const alias9 = child9; const ignored9 = side9[0];
use9(alias9.value);
const selected10: Factory = read10(); const other10: Factory = read11();
const root10 = { branch: { child: { value: selected10, alternate: other10 }, side: [other10] } };
const { branch: { child: child10, side: side10 } } = root10;
const alias10 = child10; const ignored10 = side10[0];
use10(alias10.value);
const selected11: Factory = read11(); const other11: Factory = read12();
const root11 = { branch: { child: { value: selected11, alternate: other11 }, side: [other11] } };
const { branch: { child: child11, side: side11 } } = root11;
const alias11 = child11; const ignored11 = side11[0];
use11(alias11.value);
const selected12: Factory = read12(); const other12: Factory = read13();
const root12 = { branch: { child: { value: selected12, alternate: other12 }, side: [other12] } };
const { branch: { child: child12, side: side12 } } = root12;
const alias12 = child12; const ignored12 = side12[0];
use12(alias12.value);
const selected13: Factory = read13(); const other13: Factory = read14();
const root13 = { branch: { child: { value: selected13, alternate: other13 }, side: [other13] } };
const { branch: { child: child13, side: side13 } } = root13;
const alias13 = child13; const ignored13 = side13[0];
use13(alias13.value);
const selected14: Factory = read14(); const other14: Factory = read15();
const root14 = { branch: { child: { value: selected14, alternate: other14 }, side: [other14] } };
const { branch: { child: child14, side: side14 } } = root14;
const alias14 = child14; const ignored14 = side14[0];
use14(alias14.value);
const selected15: Factory = read15(); const other15: Factory = read16();
const root15 = { branch: { child: { value: selected15, alternate: other15 }, side: [other15] } };
const { branch: { child: child15, side: side15 } } = root15;
const alias15 = child15; const ignored15 = side15[0];
use15(alias15.value);
const selected16: Factory = read16(); const other16: Factory = read17();
const root16 = { branch: { child: { value: selected16, alternate: other16 }, side: [other16] } };
const { branch: { child: child16, side: side16 } } = root16;
const alias16 = child16; const ignored16 = side16[0];
use16(alias16.value);
const selected17: Factory = read17(); const other17: Factory = read18();
const root17 = { branch: { child: { value: selected17, alternate: other17 }, side: [other17] } };
const { branch: { child: child17, side: side17 } } = root17;
const alias17 = child17; const ignored17 = side17[0];
use17(alias17.value);
const selected18: Factory = read18(); const other18: Factory = read19();
const root18 = { branch: { child: { value: selected18, alternate: other18 }, side: [other18] } };
const { branch: { child: child18, side: side18 } } = root18;
const alias18 = child18; const ignored18 = side18[0];
use18(alias18.value);
const selected19: Factory = read19(); const other19: Factory = read20();
const root19 = { branch: { child: { value: selected19, alternate: other19 }, side: [other19] } };
const { branch: { child: child19, side: side19 } } = root19;
const alias19 = child19; const ignored19 = side19[0];
use19(alias19.value);
const selected20: Factory = read20(); const other20: Factory = read21();
const root20 = { branch: { child: { value: selected20, alternate: other20 }, side: [other20] } };
const { branch: { child: child20, side: side20 } } = root20;
const alias20 = child20; const ignored20 = side20[0];
use20(alias20.value);
const selected21: Factory = read21(); const other21: Factory = read22();
const root21 = { branch: { child: { value: selected21, alternate: other21 }, side: [other21] } };
const { branch: { child: child21, side: side21 } } = root21;
const alias21 = child21; const ignored21 = side21[0];
use21(alias21.value);
const selected22: Factory = read22(); const other22: Factory = read23();
const root22 = { branch: { child: { value: selected22, alternate: other22 }, side: [other22] } };
const { branch: { child: child22, side: side22 } } = root22;
const alias22 = child22; const ignored22 = side22[0];
use22(alias22.value);
const selected23: Factory = read23(); const other23: Factory = read24();
const root23 = { branch: { child: { value: selected23, alternate: other23 }, side: [other23] } };
const { branch: { child: child23, side: side23 } } = root23;
const alias23 = child23; const ignored23 = side23[0];
use23(alias23.value);
const selected24: Factory = read24(); const other24: Factory = read25();
const root24 = { branch: { child: { value: selected24, alternate: other24 }, side: [other24] } };
const { branch: { child: child24, side: side24 } } = root24;
const alias24 = child24; const ignored24 = side24[0];
use24(alias24.value);
const selected25: Factory = read25(); const other25: Factory = read26();
const root25 = { branch: { child: { value: selected25, alternate: other25 }, side: [other25] } };
const { branch: { child: child25, side: side25 } } = root25;
const alias25 = child25; const ignored25 = side25[0];
use25(alias25.value);
const selected26: Factory = read26(); const other26: Factory = read27();
const root26 = { branch: { child: { value: selected26, alternate: other26 }, side: [other26] } };
const { branch: { child: child26, side: side26 } } = root26;
const alias26 = child26; const ignored26 = side26[0];
use26(alias26.value);
const selected27: Factory = read27(); const other27: Factory = read28();
const root27 = { branch: { child: { value: selected27, alternate: other27 }, side: [other27] } };
const { branch: { child: child27, side: side27 } } = root27;
const alias27 = child27; const ignored27 = side27[0];
use27(alias27.value);
const selected28: Factory = read28(); const other28: Factory = read29();
const root28 = { branch: { child: { value: selected28, alternate: other28 }, side: [other28] } };
const { branch: { child: child28, side: side28 } } = root28;
const alias28 = child28; const ignored28 = side28[0];
use28(alias28.value);
const selected29: Factory = read29(); const other29: Factory = read30();
const root29 = { branch: { child: { value: selected29, alternate: other29 }, side: [other29] } };
const { branch: { child: child29, side: side29 } } = root29;
const alias29 = child29; const ignored29 = side29[0];
use29(alias29.value);
const selected30: Factory = read30(); const other30: Factory = read31();
const root30 = { branch: { child: { value: selected30, alternate: other30 }, side: [other30] } };
const { branch: { child: child30, side: side30 } } = root30;
const alias30 = child30; const ignored30 = side30[0];
use30(alias30.value);
const selected31: Factory = read31(); const other31: Factory = read32();
const root31 = { branch: { child: { value: selected31, alternate: other31 }, side: [other31] } };
const { branch: { child: child31, side: side31 } } = root31;
const alias31 = child31; const ignored31 = side31[0];
use31(alias31.value);
const selected32: Factory = read32(); const other32: Factory = read33();
const root32 = { branch: { child: { value: selected32, alternate: other32 }, side: [other32] } };
const { branch: { child: child32, side: side32 } } = root32;
const alias32 = child32; const ignored32 = side32[0];
use32(alias32.value);
const selected33: Factory = read33(); const other33: Factory = read34();
const root33 = { branch: { child: { value: selected33, alternate: other33 }, side: [other33] } };
const { branch: { child: child33, side: side33 } } = root33;
const alias33 = child33; const ignored33 = side33[0];
use33(alias33.value);
const selected34: Factory = read34(); const other34: Factory = read35();
const root34 = { branch: { child: { value: selected34, alternate: other34 }, side: [other34] } };
const { branch: { child: child34, side: side34 } } = root34;
const alias34 = child34; const ignored34 = side34[0];
use34(alias34.value);
const selected35: Factory = read35(); const other35: Factory = read36();
const root35 = { branch: { child: { value: selected35, alternate: other35 }, side: [other35] } };
const { branch: { child: child35, side: side35 } } = root35;
const alias35 = child35; const ignored35 = side35[0];
use35(alias35.value);
const selected36: Factory = read36(); const other36: Factory = read37();
const root36 = { branch: { child: { value: selected36, alternate: other36 }, side: [other36] } };
const { branch: { child: child36, side: side36 } } = root36;
const alias36 = child36; const ignored36 = side36[0];
use36(alias36.value);
const selected37: Factory = read37(); const other37: Factory = read38();
const root37 = { branch: { child: { value: selected37, alternate: other37 }, side: [other37] } };
const { branch: { child: child37, side: side37 } } = root37;
const alias37 = child37; const ignored37 = side37[0];
use37(alias37.value);
const selected38: Factory = read38(); const other38: Factory = read39();
const root38 = { branch: { child: { value: selected38, alternate: other38 }, side: [other38] } };
const { branch: { child: child38, side: side38 } } = root38;
const alias38 = child38; const ignored38 = side38[0];
use38(alias38.value);
const selected39: Factory = read39(); const other39: Factory = read40();
const root39 = { branch: { child: { value: selected39, alternate: other39 }, side: [other39] } };
const { branch: { child: child39, side: side39 } } = root39;
const alias39 = child39; const ignored39 = side39[0];
use39(alias39.value);
const selected40: Factory = read40(); const other40: Factory = read41();
const root40 = { branch: { child: { value: selected40, alternate: other40 }, side: [other40] } };
const { branch: { child: child40, side: side40 } } = root40;
const alias40 = child40; const ignored40 = side40[0];
use40(alias40.value);
const selected41: Factory = read41(); const other41: Factory = read42();
const root41 = { branch: { child: { value: selected41, alternate: other41 }, side: [other41] } };
const { branch: { child: child41, side: side41 } } = root41;
const alias41 = child41; const ignored41 = side41[0];
use41(alias41.value);
const selected42: Factory = read42(); const other42: Factory = read43();
const root42 = { branch: { child: { value: selected42, alternate: other42 }, side: [other42] } };
const { branch: { child: child42, side: side42 } } = root42;
const alias42 = child42; const ignored42 = side42[0];
use42(alias42.value);
const selected43: Factory = read43(); const other43: Factory = read44();
const root43 = { branch: { child: { value: selected43, alternate: other43 }, side: [other43] } };
const { branch: { child: child43, side: side43 } } = root43;
const alias43 = child43; const ignored43 = side43[0];
use43(alias43.value);
const selected44: Factory = read44(); const other44: Factory = read45();
const root44 = { branch: { child: { value: selected44, alternate: other44 }, side: [other44] } };
const { branch: { child: child44, side: side44 } } = root44;
const alias44 = child44; const ignored44 = side44[0];
use44(alias44.value);
const selected45: Factory = read45(); const other45: Factory = read46();
const root45 = { branch: { child: { value: selected45, alternate: other45 }, side: [other45] } };
const { branch: { child: child45, side: side45 } } = root45;
const alias45 = child45; const ignored45 = side45[0];
use45(alias45.value);
const selected46: Factory = read46(); const other46: Factory = read47();
const root46 = { branch: { child: { value: selected46, alternate: other46 }, side: [other46] } };
const { branch: { child: child46, side: side46 } } = root46;
const alias46 = child46; const ignored46 = side46[0];
use46(alias46.value);
const selected47: Factory = read47(); const other47: Factory = read48();
const root47 = { branch: { child: { value: selected47, alternate: other47 }, side: [other47] } };
const { branch: { child: child47, side: side47 } } = root47;
const alias47 = child47; const ignored47 = side47[0];
use47(alias47.value);
const selected48: Factory = read48(); const other48: Factory = read49();
const root48 = { branch: { child: { value: selected48, alternate: other48 }, side: [other48] } };
const { branch: { child: child48, side: side48 } } = root48;
const alias48 = child48; const ignored48 = side48[0];
use48(alias48.value);
const selected49: Factory = read49(); const other49: Factory = read50();
const root49 = { branch: { child: { value: selected49, alternate: other49 }, side: [other49] } };
const { branch: { child: child49, side: side49 } } = root49;
const alias49 = child49; const ignored49 = side49[0];
use49(alias49.value);
const selected50: Factory = read50(); const other50: Factory = read51();
const root50 = { branch: { child: { value: selected50, alternate: other50 }, side: [other50] } };
const { branch: { child: child50, side: side50 } } = root50;
const alias50 = child50; const ignored50 = side50[0];
use50(alias50.value);
const selected51: Factory = read51(); const other51: Factory = read52();
const root51 = { branch: { child: { value: selected51, alternate: other51 }, side: [other51] } };
const { branch: { child: child51, side: side51 } } = root51;
const alias51 = child51; const ignored51 = side51[0];
use51(alias51.value);
const selected52: Factory = read52(); const other52: Factory = read53();
const root52 = { branch: { child: { value: selected52, alternate: other52 }, side: [other52] } };
const { branch: { child: child52, side: side52 } } = root52;
const alias52 = child52; const ignored52 = side52[0];
use52(alias52.value);
const selected53: Factory = read53(); const other53: Factory = read54();
const root53 = { branch: { child: { value: selected53, alternate: other53 }, side: [other53] } };
const { branch: { child: child53, side: side53 } } = root53;
const alias53 = child53; const ignored53 = side53[0];
use53(alias53.value);
const selected54: Factory = read54(); const other54: Factory = read55();
const root54 = { branch: { child: { value: selected54, alternate: other54 }, side: [other54] } };
const { branch: { child: child54, side: side54 } } = root54;
const alias54 = child54; const ignored54 = side54[0];
use54(alias54.value);
const selected55: Factory = read55(); const other55: Factory = read56();
const root55 = { branch: { child: { value: selected55, alternate: other55 }, side: [other55] } };
const { branch: { child: child55, side: side55 } } = root55;
const alias55 = child55; const ignored55 = side55[0];
use55(alias55.value);
const selected56: Factory = read56(); const other56: Factory = read57();
const root56 = { branch: { child: { value: selected56, alternate: other56 }, side: [other56] } };
const { branch: { child: child56, side: side56 } } = root56;
const alias56 = child56; const ignored56 = side56[0];
use56(alias56.value);
const selected57: Factory = read57(); const other57: Factory = read58();
const root57 = { branch: { child: { value: selected57, alternate: other57 }, side: [other57] } };
const { branch: { child: child57, side: side57 } } = root57;
const alias57 = child57; const ignored57 = side57[0];
use57(alias57.value);
const selected58: Factory = read58(); const other58: Factory = read59();
const root58 = { branch: { child: { value: selected58, alternate: other58 }, side: [other58] } };
const { branch: { child: child58, side: side58 } } = root58;
const alias58 = child58; const ignored58 = side58[0];
use58(alias58.value);
const selected59: Factory = read59(); const other59: Factory = read0();
const root59 = { branch: { child: { value: selected59, alternate: other59 }, side: [other59] } };
const { branch: { child: child59, side: side59 } } = root59;
const alias59 = child59; const ignored59 = side59[0];
use59(alias59.value);
