package main

import (
    "context"
    "fmt"
    "os"
    "path/filepath"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
    if len(os.Args) < 4 { panic("usage: emit all|default input output.c [output-bin]") }
    ctx := context.Background()
    var code string
    var err error
    if os.Args[1] == "all" {
        code, err = driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
    } else if os.Args[1] == "default" {
        code, err = driver.EmitC(ctx, os.Args[2])
    } else { panic("unknown emission mode") }
    if err == nil { err = os.WriteFile(os.Args[3], []byte(code), 0600) }
    if err == nil && len(os.Args) == 5 {
        var tc *toolchain.Toolchain
        tc, err = toolchain.New()
        if err == nil {
            var rt *toolchain.Runtime
            rt, err = tc.Runtime(ctx, toolchain.Release)
            if err == nil {
                var cPath, binPath string
                cPath, err = filepath.Abs(os.Args[3])
                if err == nil { binPath, err = filepath.Abs(os.Args[4]) }
                if err == nil { err = tc.CompileProgram(ctx, rt, []string{cPath}, binPath) }
            }
        }
    }
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
}
