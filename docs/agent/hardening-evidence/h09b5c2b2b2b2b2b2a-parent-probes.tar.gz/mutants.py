import json
import os
import pathlib
import subprocess

ROOT = pathlib.Path('/home/bryan/projects/parallelscript')
OUT = pathlib.Path('/tmp/pts-destructure-20261022-parent/mutants')
OUT.mkdir()
ENV = dict(os.environ, GOMAXPROCS='1')
cases = [
    ('unchecked_component_uses', 'container_sources.go', 'for _, read := range uses.reads {', 'for _, read := range uses.reads[:0] {', '^TestDestructuredContainerUnsafeUsesPoisonTheCompleteRoot/(selected_write|passed_sibling|unselected_root_write)$'),
    ('unchecked_pattern_siblings', 'destructured_container_sources.go', 'for _, element := range pattern.AsBindingPattern().Elements.Nodes {', 'for index, element := range pattern.AsBindingPattern().Elements.Nodes {\n if index > 0 { return true }', '^TestDestructuredContainerUnsupportedPatternsAndOriginsStayUnknown/(terminal_function_sibling|terminal_primitive_sibling|nested_terminal_leaf)$'),
    ('wrong_selected_subtree', 'container_sources.go', 'component[declaration] = tree', 'component[declaration] = data', '^TestDestructuredContainerSourcesResolveSelectedChildren/receivers_false/named_renamed$'),
    ('unchecked_raw_alias_contract', 'container_sources.go', '} else if !l.containerDataTypes(l.containerReadType(read, steps, depth), contract, steps) {', '} else if false && !l.containerDataTypes(l.containerReadType(read, steps, depth), contract, steps) {', '^TestDestructuredContainerDeclaredContractsCannotBeNarrowedAway$'),
]
results = []
for name, filename, before, after, pattern in cases:
    case = OUT/name
    case.mkdir()
    production = ROOT/'pts/lower'/filename
    original = production.read_text()
    assert original.count(before) == 1
    mutant = case/filename
    mutant.write_text(original.replace(before, after))
    overlay = case/'overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(production): str(mutant)}}, indent=2)+'\n')
    binary = case/'mutant.test'
    build = subprocess.run(['go', 'test', '-c', '-overlay', str(overlay), '-o', str(binary), './pts/lower'], cwd=ROOT, env=ENV, capture_output=True)
    (case/'build.stdout').write_bytes(build.stdout)
    (case/'build.stderr').write_bytes(build.stderr)
    assert build.returncode == 0, (name, build.stderr)
    run = subprocess.run([str(binary), '-test.run', pattern, '-test.parallel', '1', '-test.timeout', '5m'], cwd=ROOT, env=ENV, capture_output=True)
    (case/'run.stdout').write_bytes(run.stdout)
    (case/'run.stderr').write_bytes(run.stderr)
    assert run.returncode == 1 and b'--- FAIL:' in run.stdout and b'assertion failed' in run.stdout and b'build failed' not in run.stdout, (name, run)
    binary.unlink()
    result = dict(mutant=name, build_exit=build.returncode, run_exit=run.returncode, assertion_failures=run.stdout.count(b'assertion failed'), failed_events=run.stdout.count(b'--- FAIL:'), pattern=pattern)
    results.append(result)
    print(json.dumps(result), flush=True)
(OUT/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
