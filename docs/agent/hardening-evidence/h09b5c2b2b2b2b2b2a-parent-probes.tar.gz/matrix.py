import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/home/bryan/projects/parallelscript')
OUT = pathlib.Path(sys.argv[1])
OUT.mkdir()
BASE, CURRENT = sys.argv[2:4]
ENV = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(ROOT))

def source(kind, count, escaped):
    lines = ['class Box<T> { constructor(public value: T) {} }',
             'interface Maker { make<T>(value: T): Box<T>; }',
             'type Factory = <T>(value: T) => Box<T>;',
             'function escape(value: unknown): void {}']
    for i in range(count):
        lines += [f'class C{i} {{ tag = {i}; }}',
                  f'function source{i}<T>(value: T): Box<T> {{ return new Box(value); }}',
                  f'class M{i} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value); }} }}']
        if kind == 'receiver':
            lines += [f'function use{i}(value: Maker): void {{ const box: Box<C{i}> = value.make(new C{i}()); console.log(box.value.tag); }}']
        else:
            lines += [f'function use{i}(value: Factory): void {{ const box: Box<C{i}> = value(new C{i}()); console.log(box.value.tag); }}']
        if kind == 'captured_receiver':
            lines += [f'function read{i}(value: Maker): Factory {{ return value.make; }}']
        elif kind == 'wrapper':
            lines += [f'function read{i}(): Factory {{ const value: Maker = new M{i}(); return value.make; }}']
    for i in range(count):
        other = (i + 1) % count
        value_type = 'Maker' if kind in ('receiver', 'captured_receiver') else 'Factory'
        value = f'new M{i}()' if value_type == 'Maker' else f'read{i}()' if kind == 'wrapper' else f'source{i}'
        alternate = f'new M{other}()' if value_type == 'Maker' else f'read{other}()' if kind == 'wrapper' else f'source{other}'
        lines += [f'const selected{i}: {value_type} = {value}; const other{i}: {value_type} = {alternate};',
                  f'const root{i} = {{ branch: {{ child: {{ value: selected{i}, alternate: other{i} }}, side: [other{i}] }} }};',
                  f'const {{ branch: {{ child: child{i}, side: side{i} }} }} = root{i};',
                  f'const alias{i} = child{i}; const ignored{i} = side{i}[0];']
        if escaped:
            lines += [f'escape(child{i});']
        terminal = f'alias{i}.value'
        if kind == 'captured_receiver':
            terminal = f'read{i}({terminal})'
        lines += [f'use{i}({terminal});']
    return '\n'.join(lines) + '\n'

results = []
large = len(sys.argv) > 4 and sys.argv[4] == 'large'
for kind in ('function', 'receiver', 'captured_receiver', 'wrapper'):
    for count in ((60,) if large else (4, 8)):
        for escaped in ((False,) if large else (False, True)):
            case = OUT / f'{kind}-{count}-escaped-{escaped}'
            case.mkdir()
            pts = case / 'case.pts'
            pts.write_text(source(kind, count, escaped))
            mts = case / 'case.mts'
            mts.write_text(pts.read_text())
            node = subprocess.run([str(pathlib.Path.home()/'.local/node/bin/node'), '--disable-warning=ExperimentalWarning', '--experimental-transform-types', str(mts)], capture_output=True, env=ENV)
            (case/'node.stdout').write_bytes(node.stdout)
            (case/'node.stderr').write_bytes(node.stderr)
            assert node.returncode == 0 and node.stdout.decode() == ''.join(str(i) + chr(10) for i in range(count)), (node.returncode, node.stderr, node.stdout)
            for label, helper in (('base', BASE), ('current', CURRENT)):
                cpath, binary = case / f'{label}.c', case / f'{label}.bin'
                start = time.monotonic()
                emit = subprocess.run([helper, 'all', str(pts), str(cpath), str(binary)], capture_output=True, env=ENV, cwd=ROOT)
                elapsed = time.monotonic() - start
                (case/f'{label}.stderr').write_bytes(emit.stderr)
                assert emit.returncode == 0, (case, label, emit.stderr)
                code = cpath.read_text()
                wanted = {(v, d) for v in range(count) for d in range(count) if label == 'base' or escaped or v == d}
                actual = set()
                for value in range(count):
                    for demand in range(count):
                        target = f'pts_fn_source{value}_C{demand}(' if kind == 'function' else f'pts_fn_M{value}_make_C{demand}('
                        if target in code:
                            actual.add((value, demand))
                        if kind != 'function':
                            assert ('return ' + target in code) == ((value, demand) in wanted), (case, label, target, 'registration')
                assert actual == wanted, (case, label, sorted(wanted - actual), sorted(actual - wanted))
                native = subprocess.run([str(binary)], capture_output=True, env=ENV)
                (case/f'{label}.stdout').write_bytes(native.stdout)
                assert native.returncode == 0 and native.stdout == node.stdout and not native.stderr, (case, label, native)
                binary.unlink()
                result = dict(case=case.name, compiler=label, count=count, escaped=escaped, kind=kind,
                              pairs=len(actual), lines=code.count('\n'), bytes=len(code), sha256=hashlib.sha256(code.encode()).hexdigest(),
                              emit_and_clang_seconds=elapsed, native_node_match=True)
                results.append(result)
                print(json.dumps(result), flush=True)
                (OUT/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
