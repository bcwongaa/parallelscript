import collections
import hashlib
import json
import os
import pathlib
import re
import subprocess

root = pathlib.Path('/home/bryan/projects/parallelscript')
parent = pathlib.Path('/tmp/pts-destructure-20261022-parent')
review = pathlib.Path('/tmp/pts-d213-review-D56redQm')
out = parent / 'review-replay'
out.mkdir()
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(root), PTS_THREADS='1', GC_MARKERS='1')
extra = {str(root/'pts/lower/reviewer_d213_sources_test.go'):str(review/'reviewer_d213_sources_test.go'), str(root/'pts/driver/reviewer_d213_driver_test.go'):str(review/'reviewer_d213_driver_test.go')}
base = json.loads((parent/'base-overlay.json').read_text())['Replace']
summary = {'guards': [], 'native': []}
for label, replacements in [('base', dict(base, **extra)), ('current', extra)]:
    overlay = out / (label+'.overlay.json')
    overlay.write_text(json.dumps({'Replace':replacements}, indent=2)+'\n')
    command = ['go','test','-overlay',str(overlay),'-count=1','-json','-p','1','-parallel','1','-timeout','15m','./pts/lower','./pts/driver','-run','^TestReviewerD213']
    with (out/(label+'.jsonl')).open('w') as stdout, (out/(label+'.stderr')).open('w') as stderr:
        run = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
    counts = collections.Counter()
    for line in (out/(label+'.jsonl')).read_text().splitlines():
        item = json.loads(line)
        if item.get('Test') and item['Action'] in ('pass','fail','skip'):
            counts[item['Action']] += 1
    row = dict(label=label, exit=run.returncode, counts=dict(counts), command=command)
    summary['guards'].append(row)
    print(json.dumps(row), flush=True)
    assert (run.returncode,counts['pass'],counts['fail']) == ((1,80,37) if label=='base' else (0,117,0)), row

inputs = [root/'pts/tests/run/generic_destructured_container_sources.pts'] + [review/(name+'.pts') for name in ('order_poison','checked_any','captures_only','receivers_compiling','checked_any_stage','captures_receivers_supported','captures_receivers')]
for src in inputs:
    case = out/src.stem
    case.mkdir()
    (case/'input.pts').write_bytes(src.read_bytes())
    mts = case/'input.mts'
    mts.write_bytes(src.read_bytes())
    node = subprocess.run(['/home/bryan/.local/node/bin/node','--no-warnings','--experimental-transform-types',str(mts)],env=env,capture_output=True,timeout=120)
    (case/'node.stdout').write_bytes(node.stdout)
    (case/'node.stderr').write_bytes(node.stderr)
    assert node.returncode == 0, (src,node)
    unsupported = src.stem in ('captures_receivers_supported','captures_receivers')
    checked = src.stem == 'checked_any_stage'
    for label in ('base','current'):
        for api in ('all','default'):
            prefix = case/(label+'-'+api)
            code, binary = pathlib.Path(str(prefix)+'.c'), pathlib.Path(str(prefix)+'.bin')
            command = [str(parent/'helpers'/(label+'-emit')),api,str(case/'input.pts'),str(code),str(binary)]
            build = subprocess.run(command,cwd=root,env=env,capture_output=True,timeout=180)
            pathlib.Path(str(prefix)+'.build.stdout').write_bytes(build.stdout)
            pathlib.Path(str(prefix)+'.build.stderr').write_bytes(build.stderr)
            row = dict(input=src.stem,label=label,api=api,emit_compile_exit=build.returncode,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest())
            if unsupported:
                assert build.returncode == 1 and b'PTS1001' in build.stderr and b'another object as' in build.stderr, (row,build.stderr)
                row['classification'] = 'unchanged unsupported PTS1001'
            else:
                assert build.returncode == 0, (row,build.stderr)
                runenv = dict(env)
                if src.stem in ('captures_only','receivers_compiling'):
                    runenv.update(GC_PRINT_STATS='1',GC_INITIAL_HEAP_SIZE='65536',GC_FREE_SPACE_DIVISOR='64')
                run = subprocess.run([str(binary)],env=runenv,capture_output=True,timeout=120)
                pathlib.Path(str(prefix)+'.run.stdout').write_bytes(run.stdout)
                pathlib.Path(str(prefix)+'.run.stderr').write_bytes(run.stderr)
                assert run.returncode == 0, (row,run)
                if checked:
                    assert run.stdout == b'first 7\nsecond 7\nchecked type error true write\n', run.stdout
                    assert node.stdout == b'first 7\nsecond 7\nchecked type error true call\n', node.stdout
                    row['classification'] = 'PTS checked-write oracle; intentional Node timing difference'
                else:
                    assert run.stdout == node.stdout, (row,run.stdout,node.stdout)
                    row['classification'] = 'strict Node match'
                row.update(native_exit=run.returncode,gc_completed=len(re.findall(rb'Complete collection',run.stderr)),c_sha256=hashlib.sha256(code.read_bytes()).hexdigest())
                if src.stem in ('captures_only','receivers_compiling'):
                    assert row['gc_completed'] > 0, row
                binary.unlink()
            summary['native'].append(row)
            (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
            print(json.dumps(row),flush=True)
manifest = json.loads((parent/'review-snapshot-3/manifest.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in manifest.items())
summary['reviewed_hashes_unchanged'] = True
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PARENT_REPLAY_PASS',flush=True)
