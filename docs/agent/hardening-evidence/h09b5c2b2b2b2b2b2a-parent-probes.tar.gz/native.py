import json
import os
import pathlib
import shutil
import subprocess
import sys

ROOT = pathlib.Path('/home/bryan/projects/parallelscript')
OUT = pathlib.Path(sys.argv[1])
OUT.mkdir()
ENV = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(ROOT), PTS_THREADS='1')
inputs = [('fixture', ROOT/'pts/tests/run/generic_destructured_container_sources.pts', True),
          ('checked-any-write', pathlib.Path('/tmp/h09-destructured-reproducer.DAPeJc/checked_any_write.pts'), False)]
results = []
for name, src, compare in inputs:
    case = OUT/name
    case.mkdir()
    pts = case/'case.pts'
    shutil.copyfile(src, pts)
    expected = '\n'.join(x[3:] for x in pts.read_text().split('// expect:\n', 1)[1].splitlines() if x.startswith('// '))+'\n'
    node = None
    if compare:
        mts = case/'case.mts'
        shutil.copyfile(pts, mts)
        node = subprocess.run([str(pathlib.Path.home()/'.local/node/bin/node'), '--disable-warning=ExperimentalWarning', '--experimental-transform-types', str(mts)], env=ENV, capture_output=True)
        (case/'node.stdout').write_bytes(node.stdout)
        (case/'node.stderr').write_bytes(node.stderr)
        assert node.returncode == 0 and node.stdout.decode() == expected, (name, node)
    for label in ('base', 'current'):
        helper = f'/tmp/pts-destructure-20261022-parent/helpers/{label}-emit'
        for mode in ('all', 'default'):
            stem = label+'-'+mode
            cpath, binary = case/(stem+'.c'), case/(stem+'.bin')
            emit = subprocess.run([helper, mode, str(pts), str(cpath), str(binary)], cwd=ROOT, env=ENV, capture_output=True)
            (case/(stem+'.emit.stderr')).write_bytes(emit.stderr)
            assert emit.returncode == 0, (name, stem, emit.stderr)
            run = subprocess.run([str(binary)], env=ENV, capture_output=True)
            (case/(stem+'.stdout')).write_bytes(run.stdout)
            (case/(stem+'.stderr')).write_bytes(run.stderr)
            assert run.returncode == 0 and run.stdout.decode() == expected and not run.stderr, (name, stem, run)
            if compare:
                assert run.stdout == node.stdout
            binary.unlink()
            results.append(dict(input=name, compiler=label, mode=mode, lines=len(expected.splitlines()), node_match=compare, expected_match=True))
            print(json.dumps(results[-1]), flush=True)
(OUT/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
