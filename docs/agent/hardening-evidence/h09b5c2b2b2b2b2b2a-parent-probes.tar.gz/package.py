import gzip
import hashlib
import io
import json
import pathlib
import tarfile

root = pathlib.Path('/tmp/pts-destructure-20261022-parent')
repo = pathlib.Path('/home/bryan/projects/parallelscript')
evidence = repo/'docs/agent/hardening-evidence'
stem = 'h09b5c2b2b2b2b2b2a'
final = json.loads((root/'final/summary.json').read_text())
assert final['build_exit'] == final['suite_exit'] == final['counts']['fail'] == 0, final
assert final['sources_unchanged'] and final['cli_unchanged'], final
assert all(value in ('pass','skip') for value in final['packages'].values()), final
assert all(value == 0 for value in final['stderr_bytes'].values()), final
assert sum(value == 'pass' for value in final['packages'].values()) == 10, final
manifest = json.loads((root/'review-snapshot-3/manifest.json').read_text())
assert all(hashlib.sha256((repo/path).read_bytes()).hexdigest() == sha for path,sha in manifest.items())
for source,target in [(root/'final/summary.json',evidence/(stem+'-final-summary.json'))]:
    assert not target.exists(), target
    target.write_bytes(source.read_bytes())
raw = evidence/(stem+'-final-suite.jsonl.gz')
assert not raw.exists(), raw
with (root/'final/suite.jsonl').open('rb') as src, raw.open('wb') as dest:
    with gzip.GzipFile(fileobj=dest, mode='wb', mtime=0) as zipped:
        for block in iter(lambda: src.read(1024*1024),b''):
            zipped.write(block)
files = {}
excluded = []
for p in sorted(root.rglob('*')):
    name = p.relative_to(root).as_posix()
    if not p.is_file() or p.is_symlink():
        continue
    if p.parts[len(root.parts)] == 'helpers' or name == 'final/suite.jsonl' or p.suffix in ('.bin','.test') or name.endswith('.tar.gz'):
        excluded.append(name)
        continue
    data = p.read_bytes()
    if data[:4] == b'\x7fELF':
        excluded.append(name)
        continue
    files[name] = data
payload_hashes = {name:hashlib.sha256(data).hexdigest() for name,data in files.items()}
files['SHA256SUMS.json'] = (json.dumps(payload_hashes,indent=2)+'\n').encode()
files['ARCHIVE-CONTENTS.json'] = (json.dumps({'regular_payloads':len(payload_hashes),'excluded':excluded,'final_stream_external':raw.name,'reviewed_hashes_unchanged':True},indent=2)+'\n').encode()
archive = evidence/(stem+'-parent-probes.tar.gz')
assert not archive.exists(), archive
with archive.open('wb') as dest:
    with gzip.GzipFile(fileobj=dest,mode='wb',mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w|') as tar:
            for name,data in files.items():
                path = pathlib.PurePosixPath(name)
                assert not path.is_absolute() and '..' not in path.parts
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(files)
    assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts for m in members)
    for m in members:
        assert hashlib.sha256(tar.extractfile(m).read()).hexdigest() == hashlib.sha256(files[m.name]).hexdigest(), m.name
receipts = {'parent_archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'regular_members':len(files),'verified_payload_hashes':len(payload_hashes)},'final_stream':{'path':raw.name,'bytes':raw.stat().st_size,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()},'final_summary':final,'reviewed_hashes_unchanged':True}
receipt_path = evidence/(stem+'-artifacts.json')
assert not receipt_path.exists(), receipt_path
receipt_path.write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts,indent=2),flush=True)
