counts: {'DIAG': 13, 'ICE': 48, 'OK': 136, 'TYPEERR': 378} cases 575
  fcall  {'ICE': 2, 'TYPEERR': 18}
  key    {'DIAG': 5, 'TYPEERR': 30}
  susp   {'OK': 20, 'TYPEERR': 6}
  val    {'DIAG': 8, 'ICE': 46, 'OK': 116, 'TYPEERR': 324}

(family/form) x kind

| row \ kind | decl | arrow | local | inline | cls | gcls | disp | iface | ifacelit | lit | static | liar |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| val/val | ok20 | ok20 | ok5 TE15 | ok5 TE15 | ok15 TE5 | ok15 TE5 | ICE20 | TE20 | TE20 | TE20 | ok20 | TE4 |
| val/held | ok2 TE6 | ok2 TE6 | ok2 TE6 | - | TE8 | TE8 | ICE8 | TE8 | TE8 | TE8 | ok2 TE6 | - |
| val/bind | TE12 | TE12 | TE12 | - | TE12 | TE12 | ICE12 | TE12 | TE12 | TE12 | TE12 | TE4 |
| val/field | ok1 TE1 | ok1 TE1 | ok1 TE1 | - | TE2 | TE2 | ICE2 | TE2 | TE2 | TE2 | ok1 TE1 | - |
| val/ret | ok1 TE1 | ok1 TE1 | ok1 TE1 | - | TE2 | TE2 | ICE2 | TE2 | TE2 | TE2 | ok1 TE1 | - |
| val/opt | - | - | - | - | TE2 | TE2 | ICE2 | TE2 | TE2 | TE2 | - | - |
| val/destr | - | - | - | - | D2 | D2 | D2 | TE2 | TE2 | TE2 | D2 | - |
| key/unionparam | - | - | - | - | TE1 | TE1 | TE1 | TE1 | TE1 | TE1 | D1 | - |
| key/litparam | - | - | - | - | TE1 | TE1 | TE1 | TE1 | TE1 | TE1 | D1 | - |
| key/let | - | - | - | - | TE1 | TE1 | TE1 | TE1 | TE1 | TE1 | D1 | - |
| key/elemkey | - | - | - | - | TE1 | TE1 | TE1 | TE1 | TE1 | TE1 | D1 | - |
| key/anykey | - | - | - | - | TE1 | TE1 | TE1 | TE1 | TE1 | TE1 | D1 | - |
| susp/yield | ok1 | ok1 | ok1 | - | ok1 | ok1 | ok1 | TE1 | TE1 | TE1 | ok1 | - |
| susp/yieldelem | - | - | - | - | ok1 | ok1 | ok1 | TE1 | TE1 | TE1 | - | - |
| susp/await | ok1 | ok1 | ok1 | - | ok1 | ok1 | ok1 | ok1 | ok1 | ok1 | ok1 | - |
| fcall/call | TE1 | TE1 | TE1 | - | TE1 | TE1 | ICE1 | TE1 | TE1 | TE1 | TE1 | - |
| fcall/apply | TE1 | TE1 | TE1 | - | TE1 | TE1 | ICE1 | TE1 | TE1 | TE1 | TE1 | - |

family val: consumer x kind (all forms)

| row \ kind | decl | arrow | local | inline | cls | gcls | disp | iface | ifacelit | lit | static | liar |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| gparam | ok9 TE3 | ok9 TE3 | ok9 TE3 | ok5 | D1 TE13 | D1 TE13 | D1 ICE13 | TE14 | TE14 | TE14 | D1 ok9 TE3 | TE2 |
| const | ok5 TE7 | ok5 TE7 | TE12 | TE5 | D1 ok5 TE8 | D1 ok5 TE8 | D1 ICE13 | TE14 | TE14 | TE14 | D1 ok5 TE7 | TE2 |
| map | ok5 TE5 | ok5 TE5 | TE10 | TE5 | ok5 TE5 | ok5 TE5 | ICE10 | TE10 | TE10 | TE10 | ok5 TE5 | TE2 |
| hof | ok5 TE5 | ok5 TE5 | TE10 | TE5 | ok5 TE5 | ok5 TE5 | ICE10 | TE10 | TE10 | TE10 | ok5 TE5 | TE2 |

family val, form val: consumer x kind

| row \ kind | decl | arrow | local | inline | cls | gcls | disp | iface | ifacelit | lit | static | liar |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| gparam | ok5 | ok5 | ok5 | ok5 | TE5 | TE5 | ICE5 | TE5 | TE5 | TE5 | ok5 | TE1 |
| const | ok5 | ok5 | TE5 | TE5 | ok5 | ok5 | ICE5 | TE5 | TE5 | TE5 | ok5 | TE1 |
| map | ok5 | ok5 | TE5 | TE5 | ok5 | ok5 | ICE5 | TE5 | TE5 | TE5 | ok5 | TE1 |
| hof | ok5 | ok5 | TE5 | TE5 | ok5 | ok5 | ICE5 | TE5 | TE5 | TE5 | ok5 | TE1 |

by shape_type: {'arr_str': {'TYPEERR': 88, 'ICE': 12, 'OK': 24}, 'box_cls': {'OK': 20, 'TYPEERR': 20, 'ICE': 4}, 'box_num': {'TYPEERR': 194, 'ICE': 20, 'DIAG': 13, 'OK': 52}, 'prom_num': {'TYPEERR': 56, 'ICE': 8, 'OK': 20}, 'union_arr': {'OK': 20, 'TYPEERR': 20, 'ICE': 4}}

diagnostics and other non-OK, non-TypeError results:
    2 DIAG PTS1001: destructuring the property `make` of a Base is not supported yet
    2 DIAG PTS1001: destructuring the property `make` of a C is not supported yet
    2 DIAG PTS1001: destructuring the property `make` of a G is not supported yet
    7 DIAG PTS1001: the class `C` as a value is not supported yet; to test a value's class, use `instanceof C` (in `assert.throws`, `(e) => e instanceof C`)
   48 ICE PTS9001: internal compiler error while lowering: runtime error: invalid memory address or nil pointer dereference

TypeError lines: {'TypeError Expected Box<number>, got Box<any>': 217, 'TypeError Expected (value) => value, got undefined': 2, 'TypeError Expected Box[], got Array': 94, 'TypeError Expected Box[][], got Array': 23, 'TypeError Expected Box<number>, got Box<string>': 7, 'TypeError Expected Box<Point>, got Box<any>': 15, 'TypeError Expected Box | Two, got Box<any>': 15, 'TypeError Expected (Box | Two)[], got Array': 5}
