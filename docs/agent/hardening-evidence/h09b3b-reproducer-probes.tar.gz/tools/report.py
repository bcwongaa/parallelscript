#!/usr/bin/env python3
"""Summarises an H09b3b matrix result (run_matrix.py output).

usage: python3 -I report.py RESULT.json [BASE.json]
Case names are family__form__kind__consumer__shape_type (gen.py). Prints the counts, per
family, a (family/form) x kind table and a (consumer) x kind table for family `val`, the
diagnostics, and with BASE the moves and every case whose output changed.
"""
import json
import re
import sys
from collections import Counter, defaultdict

ABBR = {"OK": "ok", "TYPEERR": "TE", "MISREAD": "W", "ERRDIFF": "ED", "CRASH": "CR", "DIAG": "D", "ICE": "ICE", "TSERR": "TS",
        "TIMEOUT": "TO", "NODEERR": "NE", "OTHER": "?"}
KINDS = ["decl", "arrow", "local", "inline", "cls", "gcls", "disp", "iface", "ifacelit", "lit", "static", "liar"]


def load(p):
    with open(p) as f:
        return {r["name"]: r for r in json.load(f)}


def cells(counter):
    return " ".join(f"{ABBR.get(c, c)}{n}" for c, n in sorted(counter.items())) or "-"


def table(title, rows, res, key):
    grid = defaultdict(Counter)
    for name, r in res.items():
        k = key(name)
        if k:
            grid[k][r["cls"]] += 1
    kinds = [k for k in KINDS if any(g[1] == k for g in grid)]
    print(f"\n{title}\n")
    print("| row \\ kind | " + " | ".join(kinds) + " |")
    print("|---|" + "---|" * len(kinds))
    for row in rows:
        if not any((row, k) in grid for k in kinds):
            continue
        print(f"| {row} | " + " | ".join(cells(grid.get((row, k), Counter())) for k in kinds) + " |")


def main():
    res = load(sys.argv[1])
    base = load(sys.argv[2]) if len(sys.argv) > 2 else None
    print("counts:", dict(sorted(Counter(r["cls"] for r in res.values()).items())), "cases", len(res))
    fam = defaultdict(Counter)
    for name, r in res.items():
        fam[name.split("__")[0]][r["cls"]] += 1
    for f, c in fam.items():
        print(f"  {f:6}", dict(sorted(c.items())))
    forms = ["val/val", "val/held", "val/bind", "val/field", "val/ret", "val/opt", "val/destr", "key/unionparam", "key/litparam",
             "key/let", "key/elemkey", "key/anykey", "susp/yield", "susp/yieldelem", "susp/await", "fcall/call", "fcall/apply"]
    table("(family/form) x kind", forms, res, lambda n: ("/".join(n.split("__")[:2]), n.split("__")[2]))
    table("family val: consumer x kind (all forms)", ["gparam", "const", "map", "hof"], res,
          lambda n: (n.split("__")[3], n.split("__")[2]) if n.startswith("val__") else None)
    table("family val, form val: consumer x kind", ["gparam", "const", "map", "hof"], res,
          lambda n: (n.split("__")[3], n.split("__")[2]) if n.startswith("val__val__") else None)
    shapes = defaultdict(Counter)
    for name, r in res.items():
        shapes[name.split("__")[4]][r["cls"]] += 1
    print("\nby shape_type:", {k: dict(v) for k, v in sorted(shapes.items())})
    diags = Counter()
    for r in res.values():
        if r["cls"] in ("DIAG", "ICE", "TSERR", "CRASH", "OTHER", "MISREAD"):
            m = re.search(r"error (PTS\d+|TS\d+): ([^\n]*)", r["pts_err"] + r["pts_out"])
            diags[(r["cls"], m.group(1) + ": " + m.group(2)[:150] if m else (r["pts_err"] or r["pts_out"])[-150:])] += 1
    if diags:
        print("\ndiagnostics and other non-OK, non-TypeError results:")
        for (c, d), n in sorted(diags.items()):
            print(f"  {n:3} {c} {d}")
    tes = Counter()
    for r in res.values():
        if r["cls"] == "TYPEERR":
            line = next((l for l in r["pts_out"].splitlines() if "Error" in l), "")
            tes[line] += 1
    print("\nTypeError lines:", dict(tes))
    if base:
        moves = Counter((base[n]["cls"], res[n]["cls"]) for n in res if n in base and base[n]["cls"] != res[n]["cls"])
        print("\nmoves against base:", dict(moves))
        worse = [n for n in sorted(res) if n in base and base[n]["cls"] == "OK" and res[n]["cls"] != "OK"]
        print("OK -> not OK:", worse or "none")
        changed = [n for n in sorted(res) if n in base and base[n]["cls"] == res[n]["cls"] and base[n]["pts_out"] != res[n]["pts_out"]]
        print("same class, other output:", changed or "none")


if __name__ == "__main__":
    main()
