#!/usr/bin/env python3
"""Generates the H09b3b matrix: generic VALUES (method values, bind, non-generic contexts,
adapters) and the two call forms that read a method as a value (C196 element keys, C205 yield).

usage: python3 -I gen.py OUTDIR

Each case is one program printing one line (or, for `anykey`, the line `wrap` first): the result
read through its typed place, or `error.name error.message` if it throws. Case names are
  family__form__kind__consumer__shape_type

Family `val` (C169's second half): value form x definition kind x consumer x (shape, type)
  forms      val    the value written at the consumer (`make`, `recv.make`, `C.make`, an inline arrow)
             held   `const v = <value>;` then `v` at the consumer
             bind   `<value>.bind(recv)` (`.bind(undefined)` for functions and statics)
             field  `const holder = { f: <value> };` then `holder.f`
             ret    `function get() { return <value>; }` then `get()`
             opt    `recvMaybe?.make!` (method kinds but static)
             destr  `const { make: v } = recv;` (method kinds; a class's is PTS1001 on HEAD, generic or not)
  kinds      decl   generic function declaration            arrow   module-scope generic arrow const (D-102)
             local  function-local generic arrow const      inline  generic arrow written at the consumer
             cls    class's generic method                  gcls    generic class's generic method
             disp   abstract class's generic method, receiver typed as the base (dispatched, D-101)
             iface  interface's generic method, class instance
             ifacelit interface's generic method, object literal   lit  object literal's generic method
             static static generic method                   liar    a class whose method returns Box<string> as any (guard)
  consumers  gparam passed for `f: <T>(x: T) => R<T>`, called `f(a)` (a value call through a generic function type)
             const  `const t: (x: A) => R<A> = <value>; t(arg)`   (a non-generic function type)
             map    `[arg].map(<value>)[0]`                       (a library non-generic context)
             hof    passed for `f: (x: A) => R<A>`, called `f(a)` (a user non-generic context)
  shapes     box Box<T>, arr Box<T>[], prom Promise<Box<T>>, union Box<T> | Two<T>
  types      num number, str string, cls Point, arr number[]
Family `key` (C196): key form x method kind (box/num); consumer `call`
  unionparam `recv[key](a)` for a parameter key: "make" | "wrap"   litparam  key: "make"
  let        `let k: "make" | "wrap" = "make"; recv[k](a)`           elemkey   `recv[keys[1]](a)`, keys `as const`
  anykey     `recv[anyKey as "make"](a)` where anyKey: any = "wrap": Node calls wrap (prints `wrap`)
Family `susp` (C205): `yield` / `await` / `yieldelem` (`recv["make"](yield 1)`) x kind (box/num)
Family `fcall`: `.call` / `.apply` x kind, the result `as R<A>` (tsc types the call's T as unknown) (box/num)
"""
import os
import sys

TYPES = {
    "num": ("number", "5", lambda v: f"{v} + 1"),
    "str": ("string", '"ab"', lambda v: f"{v}.length"),
    "cls": ("Point", "new Point(3)", lambda v: f"{v}.x + 1"),
    "arr": ("number[]", "[1, 2]", lambda v: f"{v}.length + {v}[0]"),
}
SHAPES = {"box": "Box<T>", "arr": "Box<T>[]", "prom": "Promise<Box<T>>", "union": "Box<T> | Two<T>"}
METHOD_KINDS = ["cls", "gcls", "disp", "iface", "ifacelit", "lit", "static"]
VALUE_KINDS = ["decl", "arrow", "local"] + METHOD_KINDS
CONSUMERS = ["gparam", "const", "map", "hof"]
CORE = [("box", "num"), ("box", "cls"), ("arr", "str"), ("prom", "num"), ("union", "arr")]
BIND = [("box", "num"), ("arr", "str"), ("prom", "num")]
HELD = [("box", "num"), ("arr", "str")]


def r_of(shape, t):
    return SHAPES[shape].replace("T", t) if shape != "union" else f"Box<{t}> | Two<{t}>"


def body(shape, marker=False):
    ret = "return [new Box(x)];" if shape == "arr" else "return new Box(x);"
    return ('console.log("wrap"); ' if marker else "") + ret


def definitions(kind, shape, wrap):
    """Lines declaring the definition (module scope), and the local lines (inside main)."""
    a = "async " if shape == "prom" else ""
    sig = "<T>(x: T): R<T>"
    meth = f"{a}make{sig} {{ {body(shape)} }}"
    wmeth = f"{a}wrap{sig} {{ {body(shape, True)} }}" if wrap else ""
    ifsig = [f"  make{sig};"] + ([f"  wrap{sig};"] if wrap else [])
    mod, loc = [], []
    if kind == "decl":
        mod = [f"{a}function make{sig} {{ {body(shape)} }}"]
    elif kind == "arrow":
        mod = [f"const make = {a}<T,>(x: T): R<T> => {{ {body(shape)} }};"]
    elif kind == "local":
        loc = [f"const make = {a}<T,>(x: T): R<T> => {{ {body(shape)} }};"]
    elif kind == "cls":
        mod = ["class C {", f"  {meth}"] + ([f"  {wmeth}"] if wrap else []) + ["}", "const recv = new C();"]
    elif kind == "gcls":
        mod = ["class G<U> {", "  constructor(public u: U) {}", f"  {meth}"] + ([f"  {wmeth}"] if wrap else []) + ["}", 'const recv = new G<string>("g");']
    elif kind == "disp":
        mod = ["abstract class Base {", f"  abstract make{sig};"] + ([f"  abstract wrap{sig};"] if wrap else []) + ["}",
               "class Impl extends Base {", f"  {meth}"] + ([f"  {wmeth}"] if wrap else []) + ["}", "const recv: Base = new Impl();"]
    elif kind == "iface":
        mod = ["interface M {"] + ifsig + ["}", "class C implements M {", f"  {meth}"] + ([f"  {wmeth}"] if wrap else []) + ["}", "const recv: M = new C();"]
    elif kind == "ifacelit":
        mod = ["interface M {"] + ifsig + ["}", "const recv: M = {", f"  {meth},"] + ([f"  {wmeth},"] if wrap else []) + ["};"]
    elif kind == "lit":
        mod = ["const recv = {", f"  {meth},"] + ([f"  {wmeth},"] if wrap else []) + ["};"]
    elif kind == "static":
        mod = ["class C {", f"  static {meth}"] + ([f"  static {wmeth}"] if wrap else []) + ["}"]
    elif kind == "liar":
        mod = ["class L {", f'  make{sig} {{ return new Box("lie") as any; }}', "}", "const recv = new L();"]
    elif kind == "inline":
        pass
    return mod, loc


def value_expr(kind, shape):
    a = "async " if shape == "prom" else ""
    if kind in ("decl", "arrow", "local"):
        return "make"
    if kind == "static":
        return "C.make"
    if kind == "inline":
        return f"{a}<T,>(x: T): R<T> => {{ {body(shape)} }}"
    return "recv.make"


def this_arg(kind):
    return "undefined" if kind in ("decl", "arrow", "local", "static", "inline") else "recv"


def show(shape, t, r="r"):
    _, _, sh = TYPES[t]
    if shape == "box":
        return [f"console.log({sh(r + '.value')});"]
    if shape == "arr":
        return [f"console.log({sh(r + '[0].value')});"]
    if shape == "union":
        return [f'console.log({r} instanceof Box ? {sh(r + ".value")} : "two");']
    return [f"const b = await {r};", f"console.log({sh('b.value')});"]


def header(name, shape, t, consumer):
    tt = TYPES[t][0]
    helpers = []
    if consumer == "gparam":
        helpers = ["function use(f: <T>(x: T) => R<T>, a: A): R<A> {", "  return f(a);", "}"]
    elif consumer == "hof":
        helpers = ["function useN(f: (x: A) => R<A>, a: A): R<A> {", "  return f(a);", "}"]
    return [
        f"// generated by gen.py: {name}",
        "class Box<T> {",
        "  constructor(public value: T) {}",
        "}",
        "class Two<T> {",
        "  constructor(public first: T, public second: T) {}",
        "}",
        "class Point {",
        "  constructor(public x: number) {}",
        "}",
        f"type R<T> = {SHAPES[shape]};",
        f"type A = {tt};",
        "function pick<X>(x: X): X | undefined {",
        "  return Math.random() < 2 ? x : undefined;",
        "}",
    ] + helpers


def wrap_main(lines, shape, mod, loc):
    a = "async " if shape == "prom" else ""
    out = mod + [f"{a}function main(): {'Promise<void>' if a else 'void'} {{", "  try {"]
    out += ["    " + l for l in loc + lines]
    out += ["  } catch (error: any) {", "    console.log(error.name, error.message);", "  }", "}", "main();"]
    return out


def value_case(form, kind, consumer, shape, t):
    _, arg, _ = TYPES[t]
    mod, loc = definitions(kind, shape, False)
    v = value_expr(kind, shape)
    setup = []
    if form == "held":
        setup, V = [f"const v = {v};"], "v"
    elif form == "bind":
        V = f"{v}.bind({this_arg(kind)})"
    elif form == "field":
        setup, V = [f"const holder = {{ f: {v} }};"], "holder.f"
    elif form == "ret":
        setup, V = [f"function get() {{ return {v}; }}"], "get()"
    elif form == "opt":
        setup, V = ["const recvMaybe = pick(recv);"], "recvMaybe?.make!"
    elif form == "destr":
        setup, V = [f"const {{ make: v }} = {'C' if kind == 'static' else 'recv'};"], "v"
    else:
        V = v
    if consumer == "gparam":
        use = [f"const r: R<A> = use({V}, {arg});"]
    elif consumer == "const":
        use = [f"const t: (x: A) => R<A> = {V};", f"const r: R<A> = t({arg});"]
    elif consumer == "map":
        use = [f"const rs: R<A>[] = [{arg}].map({V});", "const r: R<A> = rs[0];"]
    else:
        use = [f"const r: R<A> = useN({V}, {arg});"]
    return mod, loc, setup + use + show(shape, t)


def key_case(form, kind):
    _, arg, _ = TYPES["num"]
    mod, loc = definitions(kind, "box", True)
    recv = "C" if kind == "static" else "recv"
    if form == "unionparam":
        mod += ['function callWith(key: "make" | "wrap"): R<A> {', f"  return {recv}[key]({arg});", "}"]
        use = ['const r: R<A> = callWith("make");']
    elif form == "litparam":
        mod += ['function callWith(key: "make"): R<A> {', f"  return {recv}[key]({arg});", "}"]
        use = ['const r: R<A> = callWith("make");']
    elif form == "let":
        use = ['let k: "make" | "wrap" = "make";', f"const r: R<A> = {recv}[k]({arg});"]
    elif form == "elemkey":
        use = ['const keys = ["wrap", "make"] as const;', f"const r: R<A> = {recv}[keys[1]]({arg});"]
    else:  # anykey
        use = ['const anyKey: any = "wrap";', f'const r: R<A> = {recv}[anyKey as "make"]({arg});']
    return mod, loc, use + show("box", "num")


def susp_case(form, kind):
    _, arg, _ = TYPES["num"]
    mod, loc = definitions(kind, "box", False)
    callee = value_expr(kind, "box")
    if form == "yieldelem":
        callee = 'recv["make"]'
    if form in ("yield", "yieldelem"):
        lines = ["function* gen(): Generator<number, void, A> {", f"  const r: R<A> = {callee}(yield 1);", "  " + show("box", "num")[0], "}",
                 "const it = gen();", "it.next();", f"it.next({arg});"]
        return mod, loc, lines, False
    lines = [f"async function later(): Promise<A> {{ return {arg}; }}", "async function run(): Promise<void> {",
             f"  const r: R<A> = {callee}(await later());", "  " + show("box", "num")[0], "}", "await run();"]
    return mod, loc, lines, True


def fcall_case(form, kind):
    _, arg, _ = TYPES["num"]
    mod, loc = definitions(kind, "box", False)
    v = value_expr(kind, "box")
    if form == "call":
        expr = f"{v}.call({this_arg(kind)}, {arg})"
    else:
        expr = f"{v}.apply({this_arg(kind)}, [{arg}])"
    return mod, loc, [f"const r = {expr} as R<A>;"] + show("box", "num")


def emit(out, name, shape, t, mod, loc, lines, force_async=False):
    hdr = header(name, shape, t, name.split("__")[3])
    body_lines = wrap_main(lines, "prom" if force_async else shape, mod, loc)
    with open(os.path.join(out, name + ".pts"), "w") as f:
        f.write("\n".join(hdr + body_lines) + "\n")


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    n = 0
    plan = []
    for kind in VALUE_KINDS + ["inline"]:
        for consumer in CONSUMERS:
            for shape, t in CORE:
                plan.append(("val", kind, consumer, shape, t))
    for form, combos in (("held", HELD), ("bind", BIND)):
        for kind in VALUE_KINDS:
            for consumer in CONSUMERS:
                for shape, t in combos:
                    plan.append((form, kind, consumer, shape, t))
    for form in ("field", "ret"):
        for kind in VALUE_KINDS:
            for consumer in ("gparam", "const"):
                plan.append((form, kind, consumer, "box", "num"))
    for kind in METHOD_KINDS:
        for consumer in ("gparam", "const"):
            if kind != "static":
                plan.append(("opt", kind, consumer, "box", "num"))
            plan.append(("destr", kind, consumer, "box", "num"))
    for form in ("val", "bind"):
        for consumer in CONSUMERS:
            plan.append((form, "liar", consumer, "box", "num"))
    for form, kind, consumer, shape, t in plan:
        mod, loc, lines = value_case(form, kind, consumer, shape, t)
        emit(out, f"val__{form}__{kind}__{consumer}__{shape}_{t}", shape, t, mod, loc, lines)
        n += 1
    for form in ("unionparam", "litparam", "let", "elemkey", "anykey"):
        for kind in METHOD_KINDS:
            mod, loc, lines = key_case(form, kind)
            emit(out, f"key__{form}__{kind}__call__box_num", "box", "num", mod, loc, lines)
            n += 1
    for form in ("yield", "await", "yieldelem"):
        kinds = ["cls", "gcls", "disp", "iface", "ifacelit", "lit"] if form == "yieldelem" else VALUE_KINDS
        for kind in kinds:
            mod, loc, lines, asy = susp_case(form, kind)
            emit(out, f"susp__{form}__{kind}__call__box_num", "box", "num", mod, loc, lines, asy)
            n += 1
    for form in ("call", "apply"):
        for kind in VALUE_KINDS:
            mod, loc, lines = fcall_case(form, kind)
            emit(out, f"fcall__{form}__{kind}__call__box_num", "box", "num", mod, loc, lines)
            n += 1
    print(n, "cases")


if __name__ == "__main__":
    main()
