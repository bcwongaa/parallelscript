#!/bin/bash
# suite.sh OUTPREFIX : TestRun and TestCompilerFailsCleanly (pts/tests) on the reproducer worktree as
# it is (apply a prototype diff first), 2 parallel programs. Writes OUTPREFIX.jsonl/.err/.exit.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-abc741676604e62de
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 1
GOMAXPROCS=2 go test -count=1 -p 1 -parallel 2 -timeout 60m ./pts/tests -run '^(TestRun|TestCompilerFailsCleanly)$' -json > "$1.jsonl" 2> "$1.err"
echo "exit=$?" > "$1.exit"
