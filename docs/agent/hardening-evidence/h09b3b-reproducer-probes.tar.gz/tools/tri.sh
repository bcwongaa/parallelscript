#!/bin/bash
# tri.sh FILE.pts... : run each probe with PTS and with Node (an .mts copy, as the harness does).
# Env: PTS (CLI, default the reproducer worktree's pts-bin/pts), PTS_HOME (default that worktree),
# NODE (default ~/.local/node/bin/node), NO_NODE=1 skips Node.
# Prints both outputs with their exit codes, then SAME or DIFF (with a diff).
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-abc741676604e62de
PTS=${PTS:-$W/pts-bin/pts}
export PTS_HOME=${PTS_HOME:-$W}
NODE=${NODE:-$HOME/.local/node/bin/node}
for f in "$@"; do
  d=$(mktemp -d /tmp/h09b3b/repro/tmp.XXXXXX)
  b=$(basename "$f" .pts)
  abs=$(readlink -f "$f")
  cp "$f" "$d/$b.mts"
  echo "=== $f"
  if [ -z "$NO_NODE" ]; then
    (cd "$d" && TZ=America/New_York timeout 60 "$NODE" --no-warnings --experimental-transform-types "$b.mts" > "$d/node.out" 2>&1)
    ne=$?
    echo "--- node exit=$ne"
    cat "$d/node.out"
  fi
  (cd "$d" && TZ=America/New_York timeout 300 "$PTS" run "$abs" > "$d/pts.out" 2>&1)
  pe=$?
  echo "--- pts exit=$pe"
  cat "$d/pts.out"
  if [ -z "$NO_NODE" ]; then
    if cmp -s "$d/node.out" "$d/pts.out" && [ "$ne" = "$pe" ]; then
      echo "--- SAME"
    else
      echo "--- DIFF"
      diff "$d/node.out" "$d/pts.out" | head -80
    fi
  fi
  rm -rf "$d"
done
