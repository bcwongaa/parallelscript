#!/usr/bin/env python3
"""Runs each .pts case's .mts twin with Node only and writes a node cache for run_matrix.py.

usage: python3 -I node_only.py --node NODE --scratch DIR --out NODE.json FILES...
Prints the cases where Node fails (a generator bug).
"""
import argparse
import json
import os
import shutil
import subprocess
import tempfile


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--node", required=True)
    ap.add_argument("--scratch", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    os.makedirs(args.scratch, exist_ok=True)
    results = []
    for path in sorted(args.files):
        name = os.path.basename(path)[:-4]
        d = tempfile.mkdtemp(prefix="node.", dir=args.scratch)
        try:
            shutil.copy(path, os.path.join(d, name + ".mts"))
            env = dict(os.environ, TZ="America/New_York")
            p = subprocess.run([args.node, "--no-warnings", "--experimental-transform-types", name + ".mts"], cwd=d, env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            r = dict(name=name, node_code=p.returncode, node_out=p.stdout.decode(errors="replace"), node_err=p.stderr.decode(errors="replace")[-2000:])
            results.append(r)
            if p.returncode != 0 or "Error" in r["node_out"]:
                print("NODE FAILED/ERROR LINE", name, r["node_out"][-300:], r["node_err"][-500:])
        finally:
            shutil.rmtree(d, ignore_errors=True)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=1)
    print(len(results), "node runs")


if __name__ == "__main__":
    main()
