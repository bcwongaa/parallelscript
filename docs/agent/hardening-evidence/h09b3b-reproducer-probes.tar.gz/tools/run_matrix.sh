#!/bin/bash
# run_matrix.sh PTS HOME OUT.json [NODE] : runs the H09b3b matrix (matrix/cases, 575 programs) with
# the CLI PTS (PTS_HOME=HOME picks the runtime) at 2 jobs, Node outputs from matrix/node.json
# (recorded with Node v24.21.0; pass NODE and delete --node-cache below to rerun Node), then prints
# the report against HEAD's results (matrix/head.json). About 5 minutes on an unloaded host.
set -e
here=$(cd "$(dirname "$0")/.." && pwd)
PTS=$1
HOME_TREE=$2
OUT=$3
NODE=${4:-$HOME/.local/node/bin/node}
mkdir -p "$here/scratch"
python3 -I "$here/tools/run_matrix.py" --pts "$PTS" --home "$HOME_TREE" --node "$NODE" --scratch "$here/scratch" \
  --out "$OUT" --jobs 2 --node-cache "$here/matrix/node.json" "$here"/matrix/cases/*.pts
python3 -I "$here/tools/report.py" "$OUT" "$here/matrix/head.json"
