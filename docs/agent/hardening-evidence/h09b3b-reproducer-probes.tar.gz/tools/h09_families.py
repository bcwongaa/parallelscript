#!/usr/bin/env python3
"""Breaks the H09 754-case matrix's TYPEERRs down by H09b3b family.

usage: python3 -I h09_families.py RESULTS.json CASES.json [BASE_RESULTS.json]
Families: bind (use=bind), map context (use=map_ctx), method values (definition
instance_method_value), interface/literal method values (definitions iface_method and
object_method, uses other than bind and map_ctx), other (anything else).
With BASE, also prints the verdict moves base -> results.
"""
import json
import sys
from collections import Counter, defaultdict


def family(c):
    if c["use"] == "bind":
        return "bind"
    if c["use"] == "map_ctx":
        return "map context"
    if c["definition"] == "instance_method_value":
        return "method values (class)"
    if c["definition"] in ("iface_method", "object_method"):
        return "interface/literal method values"
    return "other"


def main():
    res = json.load(open(sys.argv[1]))
    cases = json.load(open(sys.argv[2]))
    counts = defaultdict(Counter)
    for name, r in res.items():
        counts[family(cases[name])][r["verdict"]] += 1
    total = Counter()
    for fam in ("bind", "map context", "method values (class)", "interface/literal method values", "other"):
        print(f"{fam:34} {dict(sorted(counts[fam].items()))}")
        total.update(counts[fam])
    print(f"{'total':34} {dict(sorted(total.items()))}")
    print()
    print("TYPEERR by definition x use:")
    cell = Counter()
    for name, r in res.items():
        if r["verdict"] == "TYPEERR":
            cell[(cases[name]["definition"], cases[name]["use"])] += 1
    for (d, u), n in sorted(cell.items()):
        print(f"  {d:30} {u:14} {n}")
    if len(sys.argv) > 3:
        base = json.load(open(sys.argv[3]))
        moves = Counter((base[n]["verdict"], res[n]["verdict"]) for n in res if n in base and base[n]["verdict"] != res[n]["verdict"])
        print()
        print("moves base -> results:", dict(moves))
        worse = [n for n in res if n in base and base[n]["verdict"] == "OK" and res[n]["verdict"] != "OK"]
        print("OK -> not OK:", worse or "none")


if __name__ == "__main__":
    main()
