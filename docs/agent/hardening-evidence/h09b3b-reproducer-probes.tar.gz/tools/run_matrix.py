#!/usr/bin/env python3
"""Runs each .pts case with pts (PTS_HOME picks the runtime) and its .mts twin with Node, and classifies it.

usage: run_matrix.py --pts PTS --home PTS_HOME --node NODE --scratch DIR --out OUT.json [--jobs 2] [--node-cache NODE.json] FILES...

Classes:
  OK        pts prints what Node prints (stdout and exit code)
  MISREAD   pts exits as Node does but prints another value on an R/L line, without a TypeError there
  TYPEERR   pts prints a TypeError (or another error) on a line where Node prints a value
  CRASH     pts dies by a signal (exit >= 128 or negative) or aborts
  DIAG      pts rejects the program with a PTS diagnostic (PTS1001, ...)
  TSERR     pts rejects it with a tsc error (TS....)
  ICE       PTS9001 (internal compiler error)
  TIMEOUT   pts or Node timed out
  NODEERR   Node itself failed (a broken case)
  OTHER     anything else
"""
import argparse
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile


def run(cmd, cwd, env, timeout):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        return p.returncode, p.stdout.decode(errors="replace"), p.stderr.decode(errors="replace")
    except subprocess.TimeoutExpired:
        return "timeout", "", ""


def classify(pc, po, pe, nc, no, ne):
    if nc == "timeout" or pc == "timeout":
        return "TIMEOUT"
    if nc != 0:
        return "NODEERR"
    if "PTS9001" in pe or "PTS9001" in po:
        return "ICE"
    if pc != 0 and re.search(r"\bTS\d{4}\b|error TS", pe) and not po:
        return "TSERR"
    if pc != 0 and re.search(r"PTS\d{4}", pe) and not po:
        return "DIAG"
    if isinstance(pc, int) and (pc < 0 or pc >= 128):
        return "CRASH"
    if pc == nc and po == no:
        return "OK"
    plines, nlines = po.splitlines(), no.splitlines()
    for a, b in zip(plines, nlines):
        if a != b:
            if re.search(r"\b(TypeError|RangeError|Error)\b", a) and not re.search(r"\b(TypeError|RangeError)\b", b):
                return "TYPEERR"
            if re.search(r"\b(TypeError|RangeError)\b", a) and re.search(r"\b(TypeError|RangeError)\b", b):
                return "ERRDIFF"
            return "MISREAD"
    if pc != nc:
        return "OTHER"
    return "MISREAD" if len(plines) != len(nlines) else "OTHER"


def one(path, args, node_cache):
    name = os.path.basename(path)[:-4]
    d = tempfile.mkdtemp(prefix=name[:40] + ".", dir=args.scratch)
    try:
        shutil.copy(path, os.path.join(d, name + ".pts"))
        shutil.copy(path, os.path.join(d, name + ".mts"))
        env = dict(os.environ)
        env["PTS_HOME"] = args.home
        env["TZ"] = "America/New_York"
        if name in node_cache:
            nc, no, ne = node_cache[name]
        else:
            nc, no, ne = run([args.node, "--no-warnings", "--experimental-transform-types", name + ".mts"], d, env, 60)
        pc, po, pe = run([args.pts, "run", name + ".pts"], d, env, 180)
        return dict(name=name, cls=classify(pc, po, pe, nc, no, ne), pts_code=pc, pts_out=po, pts_err=pe[-2000:], node_code=nc, node_out=no, node_err=ne[-2000:])
    finally:
        shutil.rmtree(d, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--node", required=True)
    ap.add_argument("--scratch", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--node-cache")
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    os.makedirs(args.scratch, exist_ok=True)
    node_cache = {}
    if args.node_cache and os.path.exists(args.node_cache):
        with open(args.node_cache) as f:
            for r in json.load(f):
                node_cache[r["name"]] = (r["node_code"], r["node_out"], r["node_err"])
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        futs = {ex.submit(one, p, args, node_cache): p for p in sorted(args.files)}
        for i, fut in enumerate(concurrent.futures.as_completed(futs)):
            r = fut.result()
            results.append(r)
            print(f"[{i + 1}/{len(futs)}] {r['cls']:8} {r['name']}", flush=True)
    results.sort(key=lambda r: r["name"])
    with open(args.out, "w") as f:
        json.dump(results, f, indent=1)
    counts = {}
    for r in results:
        counts[r["cls"]] = counts.get(r["cls"], 0) + 1
    print(json.dumps(counts, sort_keys=True))


if __name__ == "__main__":
    main()
