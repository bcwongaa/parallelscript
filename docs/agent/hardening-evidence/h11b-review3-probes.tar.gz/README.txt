H11b review round 3 probes (reviewer). Snapshot 5 = /tmp/h11b/snap5 (873ef9448); snapshot 3 and base as before.
scripts/run.sh [-w "snap5 snap3 base"] file.pts : builds with each CLI, runs, prints Node's output (.mts copy).
  replay/        all 85 earlier probes (r2/ = round 2's archive, with round 1's under r2/r1) on snap5, snap3, base, Node; summary.txt
  d/             callee-side defaults of unknown/any parameters across function kinds (e01, e02)
  s/             `+` forms: elements of arrays/strings/records/typed arrays, templates, `+=`, optional chains, literal unions (g01-g05)
  cost/          callgrind: element-pair concatenation (rc3_*), D-221's strings probe and round 2's union for…of on snap5
  t/             transducers.pts emit-c nondeterminism (determinism.txt: 12 snap5 and 8 base emits)
  sweep-summary/ emit-c sweeps (1,062 run tests + 329 other programs), snap3 vs snap5: no new diagnostics
