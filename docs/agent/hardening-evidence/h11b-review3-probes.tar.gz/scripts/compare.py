import sys, re, glob, os
# Parse run.sh outputs into {cli: text} per probe and classify snap3 against snap2, base and Node.
def parse(path):
    secs, cur, buf = {}, None, []
    for line in open(path):
        m = re.match(r'^-- (\w+)( build failed)?:$', line.rstrip('\n'))
        if m:
            if cur: secs[cur] = ''.join(buf)
            cur, buf = m.group(1), ([ 'BUILD FAILED\n'] if m.group(2) else [])
            continue
        if line.startswith('======== '): continue
        buf.append(line)
    if cur: secs[cur] = ''.join(buf)
    return secs
def norm(s):
    return re.sub(r'/tmp/h11b/review3/bin/node-\w+/', '', s or '').replace('.mts', '.pts')
for path in sorted(glob.glob(sys.argv[1] + '/*.out')):
    s = parse(path)
    n3, n2, nb, nn = (norm(s.get(k)) for k in ('snap5', 'snap3', 'base', 'node'))
    tags = []
    if 'exit=139' in n3 or 'exit=134' in n3: tags.append('SNAP5-CRASH')
    if n3 == nn: tags.append('snap5==node')
    if n2 == nn and n3 != nn: tags.append('REGRESSION-vs-snap3')
    if nb == nn and n3 != nn: tags.append('REGRESSION-vs-base')
    if n3 != n2: tags.append('changed-vs-snap3')
    print(os.path.basename(path), ' '.join(tags))
