#!/bin/bash
# Callgrind loop counts (reps=REPS minus reps=0) for each probe, per CLI (default: base snap3 snap5).
# Usage: cost.sh REPS file.pts...   Binaries deleted.
reps=$1; shift
D=/tmp/h11b/review3/cost
for src in "$@"; do
  n=$(basename "$src" .pts)
  for which in ${WHICH:-base snap3 snap5}; do
    bin=/tmp/h11b/review3/bin/$n.$which.cost.bin
    PTS_HOME=/tmp/h11b/$which /tmp/h11b/$which/pts-bin/pts build "$src" -o "$bin" > $D/$n.$which.build.log 2>&1 || { echo "$n $which build failed"; continue; }
    out=$("$bin" 2)
    for r in "$reps" 0; do
      valgrind --tool=callgrind --callgrind-out-file=/dev/null "$bin" "$r" > /dev/null 2> $D/$n.$which.r$r.vg
    done
    ir=$(grep -o 'Collected : [0-9]*' $D/$n.$which.r$reps.vg | grep -o '[0-9]*')
    ir0=$(grep -o 'Collected : [0-9]*' $D/$n.$which.r0.vg | grep -o '[0-9]*')
    echo "$n $which reps=$reps loop=$((ir - ir0)) out(reps=2)=$out"
    rm -f "$bin"
  done
  tmp=$(mktemp -d /tmp/h11b/review3/bin/node-XXXX); cp "$src" "$tmp/$n.mts"
  echo "$n node out(reps=2)=$(cd $tmp && ~/.local/node/bin/node --no-warnings "$n.mts" 2)"; rm -rf "$tmp"
done
