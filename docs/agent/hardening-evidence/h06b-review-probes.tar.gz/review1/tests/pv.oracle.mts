// `.par` views skip an array's holes as Array's methods do: map keeps them as holes in its
// result, forEach, filter, some, every, reduce and count never call the callback for them,
// and sum, min and max fold only the elements there are (as `reduce` folds them, D-151),
// at every thread count. pts:parallel read every index: arrays of strings and of one class
// threw RangeError at the first hole, and arrays of unions and `any` passed the holes to
// the callback as undefined (`maybe count` 3 for 1); sum, min and max were NaN (H06b's
// reproducer). The expected output is the sequential methods' under Node: the twin in
// h06b-reproducer-probes.tar.gz (`red-tests/parallel_views_skip_holes.oracle.mts`)
// differs only by `.par.m(…)` → `.m(…)`, `count(p)` → `filter(p).length` and
// `sum`/`min`/`max` → a reduce. Arrays of numbers have no holes (D-085).
// threads: 1 2 4
class P {
  constructor(public x: number) {}
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
function strings(): string[] {
  const a = new Array<string>(4);
  a[1] = "2";
  a[3] = "5";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(4);
  a[0] = "a";
  a[2] = undefined;
  return a;
}
function mixed(): any[] {
  const a: any[] = new Array(3);
  a[0] = 1;
  a[2] = "z";
  return a;
}
function marks(n: number): number[] {
  return new Array<number>(n).fill(0);
}
function sum(a: any[]): number {
  return a.reduce((s: number, x: any) => s + Number(x), 0);
}
function min(a: any[]): number {
  return a.reduce((s: number, x: any) => Math.min(s, Number(x)), Infinity);
}
function max(a: any[]): number {
  return a.reduce((s: number, x: any) => Math.max(s, Number(x)), -Infinity);
}
show("strings map", () => strings().map((x) => x + "!"));
show("strings forEach", () => {
  const m = marks(4);
  strings().forEach((x, i) => {
    m[i] = 1;
  });
  return m;
});
show("strings filter", () => strings().filter((x) => x !== "zz"));
show("strings some every", () => [strings().some((x) => x === undefined), strings().every((x) => typeof x === "string")]);
show("strings find", () => strings().find((x) => x === "5"));
show("strings reduce", () => strings().reduce((a, b) => a + b, ""));
show("strings count", () => strings().filter(() => true).length);
show("strings sum min max", () => [sum(strings()), min(strings()), max(strings())]);
show("points map", () => points().map((p) => "p" + p.x));
show("points filter every count", () => [points().filter((p) => p.x > 0), points().every((p) => p.x === 1), points().filter((p) => p.x === 1).length]);
show("maybe map", () => maybe().map((x) => String(x)));
show("maybe forEach", () => {
  const m = marks(4);
  maybe().forEach((x, i) => {
    m[i] = 1;
  });
  return m;
});
show("maybe filter", () => maybe().filter(() => true));
show("maybe count", () => maybe().filter((x) => x === undefined).length);
show("maybe reduce", () => maybe().reduce((a, b) => String(a) + String(b), ""));
show("any map", () => mixed().map((x) => typeof x));
show("any filter count", () => [mixed().filter(() => true), mixed().filter(() => true).length]);
show("holes only every some", () => [new Array<string>(3).every(() => false), new Array<string>(3).some(() => true)]);
show("holes only map", () => new Array<string>(2).map((x) => x + "!"));

// Arrays of several pieces: every third slot of 6000 is a hole.
const N = 6000;
function bigStrings(): string[] {
  const a = new Array<string>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = String(i % 10);
    }
  }
  return a;
}
function bigMaybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = i % 7 === 0 ? undefined : String(i % 10);
    }
  }
  return a;
}
function bigPoints(): P[] {
  const a = new Array<P>(N);
  for (let i = 0; i < N; i++) {
    if (i % 3 !== 1) {
      a[i] = new P(i);
    }
  }
  return a;
}
function present(a: any): number {
  return a.filter(() => true).length;
}
function summary(a: any): unknown[] {
  return [a.length, present(a), a.slice(0, 4)];
}
function visited(f: (m: number[]) => void): number {
  const m = marks(N);
  f(m);
  let s = 0;
  for (let i = 0; i < N; i++) {
    s += m[i];
  }
  return s;
}
show("big strings map", () => summary(bigStrings().map((x) => x + "!")));
show("big strings forEach", () => visited((m) => bigStrings().forEach((x, i) => { m[i] = 1; })));
show("big strings filter", () => summary(bigStrings().filter((x) => x !== "3")));
show("big strings count sum", () => [bigStrings().filter((x) => x === "0").length, sum(bigStrings())]);
show("big maybe map", () => summary(bigMaybe().map((x) => String(x))));
show("big maybe filter count", () => [summary(bigMaybe().filter((x) => x !== "3")), bigMaybe().filter((x) => x === undefined).length]);
show("big points filter count", () => [summary(bigPoints().filter((p) => p.x % 2 === 0)), bigPoints().filter((p) => p.x >= 0).length]);
