// map, forEach, filter, some, every, reduce and reduceRight skip an array's holes (the
// callback isn't called for them; map keeps them as holes in its result), as JS does,
// for arrays of strings, class instances, unions with undefined and any; reduce with no
// initial value starts at the first element that is there, and throws TypeError when
// there is none. pts read each element as a required one and threw RangeError at the
// first hole (C74, H06). Arrays of numbers and booleans have no holes (D-085): map's
// result of one has zeros there (array_map_numbers_at_holes.pts).
class P {
  constructor(public x: number) {}
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
function strings(): string[] {
  const a = new Array<string>(4);
  a[1] = "b";
  a[3] = "d";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(4);
  a[0] = "a";
  a[2] = undefined;
  return a;
}
function mixed(): any[] {
  const a: any[] = new Array(3);
  a[0] = 1;
  a[2] = "z";
  return a;
}
let visited: number[] = [];
function visits(): number[] {
  const v = visited;
  visited = [];
  return v;
}
show("strings map", () => strings().map((x) => x + "!"));
show("strings forEach", () => {
  strings().forEach((x, i) => {
    visited.push(i);
  });
  return visits();
});
show("strings filter", () => strings().filter((x) => x !== "zz"));
show("strings some", () => [strings().some((x, i) => (visited.push(i), false)), visits()]);
show("strings every", () => [strings().every((x, i) => (visited.push(i), true)), visits()]);
show("strings reduce", () => strings().reduce((acc, x, i) => acc + i + x, ""));
show("strings reduce no initial", () => strings().reduce((acc, x) => acc + x));
show("strings reduceRight", () => strings().reduceRight((acc, x, i) => acc + i + x, ""));
show("strings reduceRight no initial", () => strings().reduceRight((acc, x) => acc + x));
show("points map", () => points().map((p) => "x" + p.x));
show("points filter", () => points().filter((p) => p.x > 0));
show("points every", () => points().every((p) => p.x === 1));
show("points reduce", () => points().reduce((acc, p) => acc + p.x, 0));
show("maybe map", () => maybe().map((x) => String(x)));
show("maybe forEach", () => {
  maybe().forEach((x, i) => {
    visited.push(i);
  });
  return visits();
});
show("maybe filter", () => maybe().filter(() => true));
show("maybe some", () => maybe().some((x) => x === undefined));
show("maybe reduceRight", () => maybe().reduceRight((acc: string, x, i) => acc + i + String(x), ""));
show("any map", () => mixed().map((x) => typeof x));
show("any filter", () => mixed().filter(() => true));
show("any reduce", () => mixed().reduce((acc, x) => acc + String(x), ""));
show("only holes reduce no initial", () => new Array<string>(2).reduce((acc, x) => acc + x));

// expect:
// strings map [ <1 empty item>, 'b!', <1 empty item>, 'd!' ]
// strings forEach [ 1, 3 ]
// strings filter [ 'b', 'd' ]
// strings some [ false, [ 1, 3 ] ]
// strings every [ true, [ 1, 3 ] ]
// strings reduce 1b3d
// strings reduce no initial bd
// strings reduceRight 3d1b
// strings reduceRight no initial db
// points map [ <1 empty item>, 'x1', <1 empty item> ]
// points filter [ P { x: 1 } ]
// points every true
// points reduce 1
// maybe map [ 'a', <1 empty item>, 'undefined', <1 empty item> ]
// maybe forEach [ 0, 2 ]
// maybe filter [ 'a', undefined ]
// maybe some true
// maybe reduceRight 2undefined0a
// any map [ 'number', <1 empty item>, 'string' ]
// any filter [ 1, 'z' ]
// any reduce 1z
// only holes reduce no initial threw TypeError
