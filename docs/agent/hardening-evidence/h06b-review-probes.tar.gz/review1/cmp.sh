#!/bin/bash
# usage: cmp.sh file.pts  -> runs node (.mts copy), new pts, base pts; prints outputs and exit codes
f="$1"; b="${f%.pts}"
cp "$f" "$b.mts"
echo "--- node"; $HOME/.local/node/bin/node "$b.mts" > "$b.node.out" 2>&1; echo "exit=$?" >> "$b.node.out"; cat "$b.node.out"
echo "--- new"; PTS_THREADS=${PTS_THREADS:-} PTS_HOME=/tmp/h06b-review1 timeout 120 /tmp/h06b-review1/pts-bin/pts run "$f" > "$b.new.out" 2>&1; echo "exit=$?" >> "$b.new.out"; cat "$b.new.out"
if [ -z "$NOBASE" ]; then echo "--- base"; PTS_HOME=/tmp/h06b-base timeout 120 /tmp/h06b/pts-base run "$f" > "$b.base.out" 2>&1; echo "exit=$?" >> "$b.base.out"; cat "$b.base.out"; fi
echo "--- diff node new"; diff "$b.node.out" "$b.new.out" && echo SAME
