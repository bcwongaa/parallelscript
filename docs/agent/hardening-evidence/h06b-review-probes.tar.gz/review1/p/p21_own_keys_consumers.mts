function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 80)); }
}
function holey(): string[] { const a = new Array<string>(3); a[1] = "b"; return a; }
const m = /(a)|(b)/.exec("xb")!;
show("json", () => JSON.stringify(holey()));
show("json match", () => JSON.stringify(m));
show("hasOwnProperty", () => [holey().hasOwnProperty(0), holey().hasOwnProperty(1)]);
show("entries any", () => Object.entries(holey() as any));
show("keys match", () => Object.keys(m));
show("values match any", () => Object.values(m as any));
show("for in match", () => { const ks: string[] = []; for (const k in m) ks.push(k); return ks; });
show("keys frozen", () => Object.keys(Object.freeze(holey())));
show("in typed", () => [0 in holey(), 1 in holey(), 1 in m, 2 in m]);
