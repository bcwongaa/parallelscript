enum Color { Red, Green, Blue }
const cs: Color[] = [Color.Red, Color.Blue];
cs.forEach((c) => console.log(c));
console.log(cs.map((c) => c + 1), cs.filter((c) => c !== Color.Red), cs.reduce((a, c) => a + c, 0));
console.log(cs.findIndex((c?: Color) => c === Color.Blue), cs.filter((c: Color | undefined) => c !== undefined));
type Dir = "n" | "s";
const ds: Dir[] = ["n", "s"];
console.log(ds.filter((d: Dir | undefined) => d === "s"), ds.find((d: Dir | undefined) => d === "n")!);
const lit: (1 | 2)[] = [1, 2];
console.log(lit.filter((x: 1 | 2 | undefined) => x === 2));
