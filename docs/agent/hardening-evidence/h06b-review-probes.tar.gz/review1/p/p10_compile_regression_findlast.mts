const words: string[] = ["a", "bb", "c"];
console.log(words.findLast((x: string | undefined) => x !== undefined && x.length === 2)!.length);
console.log(words.reduceRight((acc: string, x?: string | undefined) => acc + x));
