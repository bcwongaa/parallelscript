const m = "x".match(/(y)?x/)!;
const a: string[] = new Array<string>(2);
a.push(...m);
console.log(a.length, Object.keys(a));
a.forEach((x, i) => console.log("forEach", i, x === undefined));
console.log(0 in a, 2 in a, 3 in a);
const b: string[] = new Array<string>(1);
const c = b.concat(m);
console.log(Object.keys(c));
c.forEach((x, i) => console.log("concat forEach", i));
try { const s: string = a[0]; console.log("read", s); } catch (e) { console.log("threw", (e as Error).name); }
