class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
function isDefined<T>(x: T | undefined): x is T {
  return x !== undefined;
}
const ps: P[] = [new P(1), new P(2)];
console.log(ps.filter(isDefined).length);
const firstBig = ps.find((p: P | undefined) => (p?.x ?? 0) > 1);
console.log(firstBig);
const ws: string[] = ["a", "bb"];
console.log(ws.filter(isDefined));
console.log(ws.find(isDefined)!.length);
