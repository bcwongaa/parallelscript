class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
const ps: P[] = [new P(1), new P(2)];
console.log(ps.find((p: P | undefined) => p !== undefined && p.x === 2)!.x);
