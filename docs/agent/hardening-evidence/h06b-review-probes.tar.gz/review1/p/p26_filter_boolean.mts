class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
const ps: P[] = [new P(1)];
console.log(ps.filter(Boolean).length);
const ws: string[] = ["a", ""];
console.log(ws.filter(Boolean));
const ns: (string | null)[] = ["a", null];
console.log(ns.filter(Boolean));
console.log(ws.find(Boolean)!);
