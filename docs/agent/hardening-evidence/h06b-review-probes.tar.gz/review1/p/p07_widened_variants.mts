function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 60)); }
}
const m = /(a)|(b)/.exec("xb")!;
show("optional map", () => m.map((x?: string) => x ?? "u"));
show("unknown map", () => m.map((x: unknown) => String(x)));
show("any map", () => m.map((x: any) => String(x)));
show("unknown find", () => m.find((x: unknown) => x === undefined));
show("any findIndex", () => m.findIndex((x: any) => x === undefined));
show("unknown filter", () => m.filter((x: unknown) => x === undefined));
show("unknown filter len", () => m.filter((x: unknown) => true).length);
class P { constructor(public x: number) {} }
function points(): P[] { const a = new Array<P>(3); a[1] = new P(1); return a; }
show("P find", () => points().find((p: P | undefined) => p === undefined));
show("P findIndex", () => points().findIndex((p: P | undefined) => p === undefined));
show("P findLast", () => points().findLast((p: P | undefined) => p !== undefined));
show("P find!", () => points().find((p: P | undefined) => p !== undefined)!.x);
show("P unknown find", () => points().findIndex((p: unknown) => p === undefined));
show("P optional findIndex", () => points().findIndex((p?: P) => p === undefined));
show("str findIndex", () => new Array<string>(2).findIndex((s: string | undefined) => s === undefined));
show("nested findIndex", () => new Array<string[]>(2).findIndex((s: string[] | undefined) => s === undefined));
show("fn findIndex", () => new Array<() => number>(2).findIndex((s: (() => number) | undefined) => s === undefined));
show("from widened", () => Array.from(points(), (p: P | undefined) => p === undefined));
show("from widened match", () => Array.from(m, (x: string | undefined) => x ?? "u"));
show("reduce widened no init", () => m.slice(1).reduce((acc: string, x: string | undefined) => acc + String(x)));
