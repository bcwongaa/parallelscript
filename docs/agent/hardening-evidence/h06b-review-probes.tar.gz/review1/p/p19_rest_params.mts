function f(...xs: (string | undefined)[]): unknown[] {
  const out: unknown[] = [];
  out.push(xs.toSorted(), xs.with(0, "w"), [...xs], xs.findIndex((x) => x === undefined));
  xs.forEach((x) => out.push(x));
  for (const x of xs) out.push(x);
  out.push(Array.from(xs), new Set(xs).size);
  return out;
}
console.log(f("b", undefined, "a"));
function g(...ys: string[]): unknown[] {
  return [ys.toReversed(), [...ys], ys.find((y: string | undefined) => y === "b"), ys.filter((y: unknown) => y !== "a")];
}
console.log(g("a", "b"));
const h = (...zs: any[]) => [zs.with(0, 1), [...zs]];
console.log(h(3, 4));
