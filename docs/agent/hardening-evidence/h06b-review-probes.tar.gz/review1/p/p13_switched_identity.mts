const m = /(a)|(b)/.exec("xb")!;
const xs: string[] = ["q"];
xs.push(...m);
const v: any = xs;
const back: string[] = v;
console.log(back === xs);
back.push("z");
console.log(xs.length, xs);
const ys: string[] = ["q"];
const w: any = ys;
const back2: string[] = w;
console.log(back2 === ys);
function takes(a: string[]): number { a.push("t"); return a.length; }
console.log(takes(v), xs.length);
console.log(Object.isFrozen(xs), Array.isArray(v));
Object.freeze(xs);
try { xs.push("n"); } catch (e) { console.log("frozen push", (e as Error).name); }
console.log(Object.isFrozen(xs));
