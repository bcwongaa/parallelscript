class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
const ps: P[] = [new P(1), new P(2)];
console.log(ps.flatMap((p: P | undefined) => (p ? [p.x] : [])));
console.log(ps.some((p: P | undefined) => p?.x === 2), ps.every((p: P | undefined) => p !== undefined));
console.log(ps.map((p: P | undefined) => p?.x ?? -1));
console.log(ps.reduce((acc: number, p: P | undefined) => acc + (p?.x ?? 0), 0));
console.log(ps.findLastIndex((p: P | undefined) => p !== undefined));
