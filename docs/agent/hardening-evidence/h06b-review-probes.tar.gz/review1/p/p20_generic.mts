class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
function keep<T>(xs: T[], p: (x: T | undefined) => boolean): T[] {
  return xs.filter(p);
}
console.log(keep([new P(1), new P(2)], (q) => q !== undefined && q.x > 1));
console.log(keep(["a", "bb"], (q) => q !== undefined && q.length > 1));
console.log(keep([1, 2], (q) => q !== undefined && q > 1));
const keeper = <T,>(xs: T[], p: (x: T | undefined) => boolean): T[] => xs.filter(p);
console.log(keeper([new P(3)], (q) => q !== undefined));
