function isDefined<T>(x: T | undefined): x is T {
  return x !== undefined;
}
const sn: (string | number)[] = ["a", 1];
console.log(sn.filter((x: string | number | undefined) => x !== 1));
console.log(sn.filter(isDefined));
const nul: (string | null)[] = ["a", null];
console.log(nul.filter(isDefined));
console.log(nul.find((x: string | null | undefined) => x === null));
console.log(sn.find((x: string | number | undefined) => x === 1)!);
const bools: boolean[] = [true];
console.log(bools.filter(isDefined));
const nums: number[] = [1, 2];
console.log(nums.filter(isDefined), nums.find(isDefined)!);
