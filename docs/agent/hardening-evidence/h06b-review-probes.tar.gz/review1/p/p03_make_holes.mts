const a: any[] = [1, 2, 3, 4];
try { a.length = 6; console.log("grow ok", a.length, a); } catch (e) { console.log("grow threw", (e as Error).message); }
const s: string[] = ["a", "b", "c"];
const x: any = ["a", "b"];
try { x[4] = "z"; console.log("write past end ok", x); } catch (e) { console.log("write past end threw", (e as Error).message); }
try { x.length = 9; console.log("any grow", x); } catch (e) { console.log("any grow threw", (e as Error).message); }
