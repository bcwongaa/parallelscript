class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
const ps: P[] = [new P(1), new P(2)];
console.log(ps.findLast((p: P | undefined) => p !== undefined)!.x);
console.log(ps.reduceRight((acc: P, p: P | undefined) => (p !== undefined && p.x > acc.x ? p : acc)).x);
