function holes(): any[] { const h: any[] = new Array(2); h[1] = "b"; return h; }
function maybe(): (string | undefined)[] { const h = new Array<string | undefined>(2); h[1] = "b"; return h; }
const a: any[] = [1];
a.push(...holes());
console.log("push any", a, Object.keys(a));
const b: any[] = [1];
b.unshift(...holes());
console.log("unshift any", b, Object.keys(b));
const d: (string | undefined)[] = ["x"];
d.push(...maybe());
console.log("push maybe", d, Object.keys(d));
const e: (string | undefined)[] = ["x"];
e.push("y", ...maybe());
console.log("push maybe 2", e, Object.keys(e));
function rest(...xs: any[]): string { return Object.keys(xs).join(",") + " " + xs.length; }
console.log("rest", rest(...holes()));
console.log("max", Math.max(...[1, ...holes().map(() => 2)]));
const f: any[] = [...holes()];
console.log("spread", f, Object.keys(f));
const g = new Set<any>([...holes()]);
console.log("set spread", g);
