const m = /(a)|(b)/.exec("xb")!;
function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
show("forEach", () => { m.forEach((x) => { console.log(x.length); }); });
show("map", () => m.map((x) => x.length));
show("filter", () => m.filter((x) => x.length > 0));
show("for of", () => { for (const x of m) console.log(x.length); });
show("copy forEach", () => { m.slice().forEach((x) => { console.log(x.length); }); });
show("find", () => m.find((x) => x.length > 5));
show("par", () => 0);
