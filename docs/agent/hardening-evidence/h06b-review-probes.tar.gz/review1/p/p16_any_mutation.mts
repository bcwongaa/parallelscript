function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
function holey(): any[] { const a: any[] = new Array(4); a[0] = "a"; a[2] = "c"; return a; }
show("forEach unshift holes", () => {
  const s: string[] = ["a", "b", "c"];
  const v: any = s;
  const seen: string[] = [];
  v.forEach((x: any, i: number) => { if (i === 0) s.unshift(...new Array<string>(2)); seen.push(i + ":" + x); });
  return seen;
});
show("map shrink regrow", () => {
  const v: any = ["a", "b", "c"];
  return v.map((x: any, i: number) => { if (i === 0) { v.length = 0; v.push("z"); } return x; });
});
show("filter any holey", () => holey().filter(() => true));
show("reduce any holey", () => (holey() as any).reduce((a: any, b: any) => a + b));
show("reduceRight any holey", () => (holey() as any).reduceRight((a: any, b: any) => a + b));
show("every any holey", () => (holey() as any).every((x: any) => x !== undefined));
show("some any holey", () => (holey() as any).some((x: any) => x === undefined));
show("find any holey", () => (holey() as any).findLastIndex((x: any) => x === undefined));
show("map any holey", () => (holey() as any).map((x: any) => x + "!"));
show("flatMap any holey", () => (holey() as any).flatMap((x: any) => [x, x]));
show("indexOf undef", () => { const a: any = holey(); a[1] = undefined; return [a.indexOf(undefined), a.lastIndexOf(undefined), a.includes(undefined)]; });
show("indexOf undef from", () => { const a: any = holey(); return [a.indexOf(undefined, 2), a.lastIndexOf(undefined, -2), a.includes(undefined, 3)]; });
show("concat holey", () => (holey() as any).concat(holey(), [1]));
show("entries", () => [...(holey() as any).entries()]);
show("values", () => [...(holey() as any).values()]);
show("keys", () => Object.keys(holey() as any));
show("in", () => { const a: any = holey(); return [0 in a, 1 in a, "1" in a, 5 in a]; });
show("hasOwn", () => { const a: any = holey(); return [Object.hasOwn(a, 1), Object.hasOwn(a, 2), Object.hasOwn(a, "length")]; });
show("for in", () => { const a: any = holey(); const ks: string[] = []; for (const k in a) ks.push(k); return ks; });
show("values()", () => Object.values(holey() as any));
show("entries()", () => Object.entries(holey() as any));
show("toSorted", () => (holey() as any).toSorted());
show("with", () => (holey() as any).with(0, "z"));
show("Array.from", () => Array.from(holey() as any));
show("spread", () => [...(holey() as any)]);
show("set", () => new Set(holey() as any));
