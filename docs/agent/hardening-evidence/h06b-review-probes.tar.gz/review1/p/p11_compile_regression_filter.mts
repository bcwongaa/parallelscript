class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
const ps: P[] = [new P(1), new P(2)];
console.log(ps.filter((p: P | undefined) => p !== undefined && p.x > 1).length);
const qs: P[][] = [[new P(1)], []];
console.log(qs.filter((q: P[] | undefined) => q !== undefined && q.length > 0).length);
const ws: string[] = ["a", "bb"];
console.log(ws.filter((w: string | undefined) => w !== undefined && w.length > 1));
console.log(ws.filter((w: unknown) => typeof w === "string"));
