function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 80)); }
}
function holey(): string[] { const a = new Array<string>(2); a[1] = "b"; return a; }
const m = /(a)|(b)/.exec("xb")!;
show("wide", () => { const xs: (string | undefined)[] = [...holey(), ...m]; return xs; });
show("narrow", () => { const ys: string[] = [...m, ...holey()]; return [ys, Object.keys(ys)]; });
show("narrow2", () => { const ys: string[] = [...holey(), ...m]; return [ys, Object.keys(ys)]; });
show("any", () => { const zs: any[] = [...holey(), ...m]; return zs; });
show("unknown", () => { const zs: unknown[] = [...m]; return zs; });
show("str", () => [..."ab", ...m]);
show("nested", () => [[...m], [...holey()]]);
show("set narrow", () => new Set(m));
show("from wide", () => { const w: (string | undefined)[] = Array.from(holey()); return w; });
