const words: string[] = ["a", "b", "c"];
console.log(words.reduce((acc: string, x: string | undefined) => acc + (x ?? "-")));
