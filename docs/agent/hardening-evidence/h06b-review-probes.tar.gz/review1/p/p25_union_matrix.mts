class P {
  x: number;
  constructor(x: number) { this.x = x; }
}
function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
function sn(): (string | null)[] { const a = new Array<string | null>(4); a[0] = "a"; a[2] = null; return a; }
function pn(): (P | null)[] { const a = new Array<P | null>(3); a[1] = new P(1); a[2] = null; return a; }
function ns(): (number | string)[] { const a = new Array<number | string>(3); a[0] = 1; a[2] = "z"; return a; }
show("sn forEach", () => { const o: string[] = []; sn().forEach((x, i) => o.push(i + ":" + x)); return o; });
show("sn map", () => sn().map((x) => String(x)));
show("sn filter", () => sn().filter((x) => x !== "q"));
show("sn some", () => sn().some((x) => x === null));
show("sn every", () => sn().every((x) => x !== undefined));
show("sn reduce", () => sn().reduce((a, x) => a + String(x), ""));
show("sn reduce no init", () => sn().reduce((a, x) => (a ?? "") + String(x)));
show("sn flatMap", () => sn().flatMap((x) => [x]));
show("sn find", () => sn().find((x) => x === null));
show("sn findIndex", () => sn().findIndex((x) => x === null));
show("sn includes null", () => sn().includes(null));
show("sn indexOf null", () => sn().indexOf(null));
show("sn keys", () => Object.keys(sn()));
show("sn toSorted", () => sn().toSorted());
show("sn concat", () => sn().concat(["q"]));
show("pn forEach", () => { const o: string[] = []; pn().forEach((p, i) => o.push(i + ":" + (p === null ? "null" : p.x))); return o; });
show("pn map", () => pn().map((p) => (p === null ? "null" : "p" + p.x)));
show("pn filter", () => pn().filter((p) => p !== null));
show("pn every", () => pn().every((p) => p === null || p.x === 1));
show("pn findLast", () => pn().findLast((p) => p !== null));
show("ns map", () => ns().map((x) => typeof x));
show("ns filter", () => ns().filter((x) => x !== 0));
show("ns reduceRight", () => ns().reduceRight((a, x) => a + String(x), ""));
show("ns for of", () => { const o: string[] = []; for (const x of ns()) o.push(String(x)); return o; });
show("ns spread", () => [...ns()]);
