#!/bin/bash
# usage: csize.sh LABEL CLI PTS_HOME OUTDIR : emit-c of every run, errors, corpus and docs program
label=$1; cli=$2; home=$3; out=$4; mkdir -p $out
cd /home/bryan/projects/parallelscript
for f in pts/tests/run/*.pts pts/tests/errors/*.pts pts/tests/corpus/*/*.pts docs/examples/*.pts; do
  n=$(echo $f | tr '/' '_')
  PTS_HOME=$home PTS_CACHE_DIR=/tmp/h09b4b/.cache-$label timeout 120 $cli emit-c $f > $out/$n.c 2> $out/$n.err
  echo "$? $f" >> $out/status.txt
done
