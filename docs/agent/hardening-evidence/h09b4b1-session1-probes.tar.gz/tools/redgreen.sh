#!/bin/bash
# usage: redgreen.sh OUT CLI_LABEL CLI_PATH PTS_HOME tests...  -> prints per test: label, exit, match-expect, match-node
out=$1; label=$2; cli=$3; home=$4; shift 4
work=/tmp/h09b4b/rg-$label; mkdir -p $work
for t in "$@"; do
  name=$(basename $t .pts)
  sed -n '/^\/\/ expect:/,$p' $t | sed '1d; s#^// \{0,1\}##' > $work/$name.exp
  cp $t $work/$name.mts
  (cd $work && TZ=America/New_York ~/.local/node/bin/node --no-warnings --experimental-transform-types $name.mts > $name.node 2>/dev/null)
  PTS_HOME=$home PTS_CACHE_DIR=/tmp/h09b4b/.cache-$label timeout 300 $cli run $t > $work/$name.out 2> $work/$name.err; rc=$?
  e=$(cmp -s $work/$name.out $work/$name.exp && echo expect-ok || echo expect-DIFF)
  n=$(cmp -s $work/$name.out $work/$name.node && echo node-ok || echo node-DIFF)
  ne=$(cmp -s $work/$name.node $work/$name.exp && echo node=expect || echo node!=expect)
  first=$(cat $work/$name.err $work/$name.out | grep -m1 -E "error|Error" | cut -c1-200)
  echo "$label $name exit=$rc $e $n $ne :: $first"
done >> $out
