type Id = string & { __brand: "id" };
const id = "x" as Id;
console.log(id.__brand, typeof id.__brand);
const brands: { __brand: "id" } = id;
console.log(brands.__brand);
