// plain twin of s02: tsc keeps o.v narrowed to string across change(), so the inner test narrows it to never; live.
function g(o: { v: string | number }, change: () => void): string {
  if (typeof o.v !== "number") {
    change();
    if (typeof o.v === "number") {
      const n: number = o.v;
      return "number now " + (n + 1);
    }
  }
  return "kept";
}
const o: { v: string | number } = { v: "s" };
console.log(g(o, () => { o.v = 5; }));
let w: string | number = "s";
function setW() { w = 7; }
function h(): string {
  if (typeof w === "string") {
    setW();
    if (typeof w === "number") {
      return "w now " + (w + 1);
    }
  }
  return "w kept";
}
console.log(h());
