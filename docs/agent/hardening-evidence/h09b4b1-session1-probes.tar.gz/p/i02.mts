function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
const xs: (string | number)[] = ["ab", "c"];
if (isStrings(xs)) {
  console.log(xs[0].length, xs.join("-"), xs.length);
  xs.push("d");
}
console.log(xs);
