function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function lyingIsStrings(v: unknown): v is string[] {
  return Array.isArray(v);
}
function f(x: number[]): string {
  if (isStrings(x)) {
    return "len " + x.length;
  }
  return "other";
}
try {
  console.log(f([]));
} catch (error: any) {
  console.log("caught", error.name);
}
