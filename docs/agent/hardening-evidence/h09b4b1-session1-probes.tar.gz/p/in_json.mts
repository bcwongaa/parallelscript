interface NoK {
  m: string;
}
function describe(x: NoK): string {
  if ("k" in x) {
    return "has k";
  }
  return "no k";
}
console.log(describe(JSON.parse('{"m":"j","k":9}') as NoK));
