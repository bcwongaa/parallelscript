function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function takes(xs: string[]): number { return xs.length; }
function f<T>(x: T): string {
  if (isStrings(x)) {
    const first = x.length > 0 ? x[0].toUpperCase() : "-";
    x.push("z");
    return "strings " + x.join("-") + " " + first + " " + takes(x) + " " + x.map((s) => s.length).join(",");
  }
  return "other";
}
const mixed: (string | number)[] = ["ab", "c"];
const nums: number[] = [];
console.log(f(mixed), mixed, f(nums), nums, f([3]));
