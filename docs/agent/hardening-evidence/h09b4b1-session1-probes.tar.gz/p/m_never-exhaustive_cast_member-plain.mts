interface Sq {
  kind: "sq";
  side: number;
}
interface Ci {
  kind: "ci";
  r: number;
}
type Shape = Sq | Ci;
function assertNever(x: never): never {
  throw new Error("unexpected " + JSON.stringify(x));
}
function area(s: Shape): number {
  switch (s.kind) {
    case "sq":
      return s.side * s.side;
    case "ci":
      return 3 * s.r * s.r;
    default: {
      throw new Error("unexpected kind " + (s as Shape).kind);
    }
  }
}
const lie = { kind: "tri", side: 1, r: 1 } as unknown as Sq;
for (const s of [{ kind: "sq", side: 2 } as Shape, { kind: "ci", r: 1 } as Shape, lie]) {
  try {
    console.log("area", area(s));
  } catch (error: any) {
    console.log("caught", error.message);
  }
}
