function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
const ns: number[] = [];
if (isStrings(ns)) {
  const first = ns.length > 0 ? ns[0].length : -1;
  console.log("strings", ns.join("-"), first, ns.length);
}
