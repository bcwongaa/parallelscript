function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function lyingIsStrings(v: unknown): v is string[] {
  return Array.isArray(v);
}
function f<T>(x: T): string {
  if (isStrings(x)) {
    return "slice " + x.slice(0).length;
  }
  return "other";
}
try {
  console.log(f<number[]>([]));
} catch (error: any) {
  console.log("caught", error.name);
}
