type Id = string & { __brand: "id" };
type Usd = number & { readonly __unit: "usd" };

type Email = string & { readonly __email: true };
type Loose = string & {};
function asId(s: string): Id { return s as Id; }
const ids: Id[] = [asId("a"), asId("bb")];
const byId = new Map<Id, number>([[ids[0], 1], [ids[1], 2]]);
console.log(ids.map((i) => i.length), byId.get(asId("bb")), ids.join("+"));
const price = 5 as Usd;
const total: number = price * 2;
console.log(total, (price as number).toFixed(2), price + 1);
const e = "x@y" as Email;
console.log(e.includes("@"), e.split("@"));
const l: Loose = "loose";
console.log(l.toUpperCase(), typeof l);
function first<T>(xs: T[]): T | undefined { return xs[0]; }
console.log(first(ids), first<Usd>([price]));
class Holder<T> { constructor(public v: T) {} get(): T { return this.v; } }
const h = new Holder(asId("hh"));
console.log(h.get().length, h.v);
function show(x: Id | number): string {
  if (typeof x === "string") return "id " + x.toUpperCase();
  return "num " + (x + 1);
}
console.log(show(asId("q")), show(3));
const u: Id | undefined = Math.random() > 2 ? undefined : asId("z");
console.log(u?.length, u ?? "none");
const o = { id: asId("k"), n: 1 };
console.log(JSON.stringify(o), String(ids[0]), `${ids[1]}`);
function eq(a: Id, b: string): boolean { return a === b; }
console.log(eq(asId("m"), "m"), ids.includes(asId("a")), ids.indexOf(asId("bb")));
const s: Set<Id> = new Set(ids);
console.log(s.has(asId("a")), [...s].length);
