type Id = string & { __brand: "id" };
type Usd = number & { __unit: "usd" };
const a = "a" as Id;
const b = "b" as Id;
let s = a + "x";
s += b;
console.log(s, a < b, `${a}-${b}`, a === b, a !== b, a == "a");
const p = 3 as Usd;
const q = 4 as Usd;
let t: number = p + q;
t += p;
console.log(t, p < q, p * q, p - 1, -p, p % 2, p ** 2, p === 3, Math.max(p, q));
const rec: Record<string, number> = { a: 1, b: 2 };
console.log(rec[a], rec[b], { [a]: 9 }, Object.keys({ [b]: 1 }));
switch (a) {
  case "a":
    console.log("case a");
    break;
  default:
    console.log("default");
}
console.log(a.localeCompare(b), a.startsWith("a"), a.charAt(0), a[0], [...a], a.at(-1));
const sorted = [b, a].sort();
console.log(sorted, [q, p].sort((x, y) => x - y), [p, q].reduce((m, x) => m + x, 0));
const counts = new Map<Id, Usd>();
counts.set(a, p);
for (const [k, v] of counts) console.log(k, v, typeof k, typeof v);
function key(x: Id): string { return x; }
function num(x: Usd): number { return x; }
console.log(key(a), num(p), String(p), p.toString(), parseInt(a, 36), Number(p));
const u: unknown = a;
if (typeof u === "string") console.log("unknown", u.length);
const anyId: any = a;
const back: Id = anyId;
console.log(back.length, (anyId as Id).toUpperCase());
