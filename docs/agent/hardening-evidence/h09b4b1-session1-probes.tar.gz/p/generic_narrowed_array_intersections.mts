// An honest `v is string[]` predicate on a T of an array type narrows x to `T & string[]`,
// which for T = `(string | number)[]` is a string[] (as tsc narrows it in plain code) and
// for T = `number[]` is `number[] & string[]`, an intersection no IR type holds that an
// array of no elements has: there x is read dynamically (C227, H09b4a review round 2's
// i01). Both were PTS1001 (`` `x.length` is not supported yet ``, `calling `x.join``),
// and taking `number[] & string[]` as a number[] read `x[0].length` from a double (PTS9001).
function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function takes(xs: string[]): number {
  return xs.length;
}
function f<T>(x: T): string {
  if (isStrings(x)) {
    const first = x.length > 0 ? x[0].length : -1;
    return "strings " + x.join("-") + " " + first;
  }
  return "other";
}
const mixed: (string | number)[] = ["ab", "c"];
const nums: number[] = [];
console.log(f(mixed), f<(string | number)[]>([1, "a"]), f(nums), f([3]));
function grow<T>(x: T): string {
  if (isStrings(x)) {
    const upper = x.length > 0 ? x[0].toUpperCase() : "-";
    x.push("z");
    return upper + " " + x.length + " " + takes(x) + " " + x.join("");
  }
  return "other";
}
const words: (string | number)[] = ["ab"];
console.log(grow(words), words, grow([1]));

// expect:
// strings ab-c 2 other strings  -1 other
// AB 2 2 abz [ 'ab', 'z' ] other
