// No lie: a call changes o.v between two typeof tests; tsc keeps o.v narrowed across it.
function g<T>(o: { v: T | number }, change: () => void): string {
  if (typeof o.v !== "number") {
    change();
    if (typeof o.v === "number") {
      const n: number = o.v;
      return "number now " + (n + 1);
    }
  }
  return "kept";
}
const o: { v: string | number } = { v: "s" };
try {
  console.log(g<string>(o, () => {
    o.v = 5;
  }));
} catch (e) {
  console.log("caught", (e as Error).message);
}
