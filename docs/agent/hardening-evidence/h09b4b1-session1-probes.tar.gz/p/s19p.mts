function isNumOrUndefined(v: unknown): v is number | undefined {
  return v === undefined || typeof v === "number";
}
function f(o: { v: string } | undefined): string {
  if (isNumOrUndefined(o?.v)) {
    const n = o?.v;
    return "n " + n;
  }
  return "other";
}
console.log(f(undefined), f({ v: "s" }));
function g(o: { v: string | number } | undefined): string {
  if (typeof o?.v === "number") {
    return "num " + (o?.v + 1);
  }
  if (o?.v === undefined) {
    return "undef " + o?.v;
  }
  return "str " + o?.v.length;
}
console.log(g(undefined), g({ v: 2 }), g({ v: "abc" }));
