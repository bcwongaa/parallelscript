type Id = string & { __brand: "id" };
const id = "x" as Id;
function f<T>(x: T): number {
  if (typeof x === "number") {
    return x + 1;
  }
  return 0;
}
function g<T>(x: T): string {
  if (typeof x === "string") {
    return x.toUpperCase();
  }
  return "no";
}
console.log(f(id), f("s"), f(2), g(id), g(5));
