// Honest live branches whose narrowed type intersects an array type argument with another
// array type (`(string | number)[] & string[]`), which narrowedInstance's `includes` now
// keeps as the type argument.
function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function f<T>(x: T): string {
  if (isStrings(x)) {
    const first = x.length > 0 ? x[0].length : -1;
    return "strings " + x.join("-") + " " + first;
  }
  return "other";
}
const mixed: (string | number)[] = ["ab", "c"];
const nums: number[] = [];
console.log(f(mixed), f<(string | number)[]>([1, "a"]), f(nums), f([3]));
