// No lie: an honest predicate narrows `o?.v` to `(T & undefined) | (T & number) | undefined`;
// o === undefined reaches the branch. Intersecting with v's declared type T drops the
// chain's own undefined, so the read looks dead for a string T.
function isNumOrUndefined(v: unknown): v is number | undefined {
  return v === undefined || typeof v === "number";
}
function f<T>(o: { v: T } | undefined): string {
  if (isNumOrUndefined(o?.v)) {
    const n = o?.v;
    return "n " + n;
  }
  return "other";
}
try {
  console.log(f<string>(undefined));
} catch (e) {
  console.log("caught", (e as Error).message);
}
console.log(f<string>({ v: "s" }), f<number>({ v: 1 }), f<number>(undefined));
