"""Write overlay.json mapping the worktree's pts/lower files to the prototype's copies in src/."""
import json
import os

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a48453b6f736176fb"
SRC = "/tmp/h09b4b/repro/proto/src"
replace = {}
for name in sorted(os.listdir(SRC)):
    if name.endswith(".go"):
        replace[os.path.join(WT, "pts/lower", name)] = os.path.join(SRC, name)
json.dump({"Replace": replace}, open("/tmp/h09b4b/repro/proto/overlay.json", "w"), indent=1)
print(len(replace), "files")
