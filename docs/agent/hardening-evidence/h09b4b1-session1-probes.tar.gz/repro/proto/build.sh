#!/bin/bash
# build.sh : rebuild the throwaway prototype compiler (/tmp/h09b4b/repro/proto/pts) from the
# worktree's sources with the prototype's pts/lower files overlaid (the worktree stays clean).
set -e
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a48453b6f736176fb
export PATH=$HOME/.local/go/bin:$PATH GOMAXPROCS=2
python3 -I /tmp/h09b4b/repro/proto/mkoverlay.py
cd "$WT"
go build -overlay /tmp/h09b4b/repro/proto/overlay.json -o /tmp/h09b4b/repro/proto/pts ./cmd/pts
echo built
