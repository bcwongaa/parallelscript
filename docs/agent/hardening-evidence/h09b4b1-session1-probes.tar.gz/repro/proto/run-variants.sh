#!/bin/bash
# run-variants.sh TAG : both matrices with the prototype compiler, P6 off (variant B: dynamic
# never reads only) and on (variant A: also plain-code traps). Results under out/matrix/.
TAG=${1:-proto}
M=/tmp/h09b4b/repro/out/matrix
P=/tmp/h09b4b/repro/proto/pts
cd /tmp/h09b4b/repro/work || exit 1
for v in B A; do
  if [ "$v" = A ]; then export PTS_PROTO_P6=1; else unset PTS_PROTO_P6; fi
  python3 -I $M/run.py $M/gen633/cases.json $M/results-633-$TAG-$v.json --jobs 2 --pts $P --work /tmp/h09b4b/repro/work/m633-$TAG-$v
  python3 -I $M/run.py $M/genb/cases.json $M/results-b-$TAG-$v.json --jobs 2 --pts $P --work /tmp/h09b4b/repro/work/mb-$TAG-$v
done
echo "variants done"
