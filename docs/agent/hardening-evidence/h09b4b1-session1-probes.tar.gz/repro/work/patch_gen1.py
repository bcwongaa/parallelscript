p = "/tmp/h09b4b/repro/out/matrix/gen_b.py"
t = open(p).read()
rep = [
    ('''    "copy": "if (x.kind === \\"sq\\") {\\n  const s = x;\\n  return \\"side \\" + s.side;\\n}\\nreturn x.kind;",\n''', ''),
    ('''new Box(x).value.side''', '''new Box<Sq>(x).value.side'''),
    ('''        for form in ("plain", "generic"):
            if form == "plain":
                fn = "function describe(x: NoK)''', '''        for form in ("plain", "generic"):
            if form == "generic" and uname == "m_too":
                continue  # tsc: no m on T & Record<"k", unknown>
            if form == "plain":
                fn = "function describe(x: NoK)'''),
    ('''        for form in ("generic", "plain"):
            if form == "generic":
                fn = "function f<T>(x: T): string {\\n  if (%s(x)) {''', '''        for form in ("generic", "plain"):
            if form == "plain" and uname in ("guarded_elem", "unguarded_elem_member", "i01", "for_of", "map"):
                continue  # tsc: the plain element is never (number & string), or a number to the callback
            if form == "generic":
                fn = "function f<T>(x: T): string {\\n  if (%s(x)) {'''),
    ('''    for form in ("plain", "generic"):
        tp, pt, targ = ("", "string", "") if form == "plain" else ("<T>", "T", "<string>")''', '''    for form in ("plain", "generic"):
        if form == "plain" and name == "method":
            continue  # tsc: no toFixed on never
        tp, pt, targ = ("", "string", "") if form == "plain" else ("<T>", "T", "<string>")'''),
    ('''    "typeof_function_call": ("string", '"s"', 'if (typeof x === "function") {\\n  console.log("dead", x());\\n}'),\n''', ''),
    ('''    uses = NUMBER_USES if kind == "number" else STRING_USES
    for name, use in uses.items():''', '''    uses = NUMBER_USES if kind == "number" else STRING_USES
    for name, use in uses.items():
        if kind in ("unique_symbol", "readonly_prop") and name not in ("length", "method"):
            continue  # PTS1002: symbol types are left out by design (D-O14)'''),
]
for a, b in rep:
    assert a in t, a[:60]
    t = t.replace(a, b)
open(p, "w").write(t)
print("patched")
