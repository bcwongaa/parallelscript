import re

# P7: an object read narrowed to an interface its IR type doesn't provide: checked conversion.
p = "/tmp/h09b4b/repro/proto/src/unions.go"
t = open(p).read()
old = '''				return l.checkedConversion(x, narrow, node)
			}
		}
		return x
	}'''
new = '''				return l.checkedConversion(x, narrow, node)
			}
		}
		// PROTO(H09b4b P7): an object narrowed to an object type its IR type doesn't
		// provide (`x.kind === "sq"` for an x of Ci's IR type through `T extends Sq | Ci`,
		// C223; `"k" in x` for an x without k, C222): the object as that type, checked as a
		// dynamic value converting to it is (as it is where it has the members).
		if isObjectOfProgram(x.Type()) {
			if t := l.typeAt(node); t.Flags()&(checker.TypeFlagsObject|checker.TypeFlagsIntersection) != 0 {
				if iface, ok := l.irType(t, node).(*ir.Interface); ok && iface != x.Type() && unprovided(x.Type(), iface) != "" && !holdsOptionally(x.Type(), iface) {
					return l.checkedConversion(x, iface, node)
				}
			}
		}
		return x
	}'''
assert old in t, "p7"
t = t.replace(old, new)
open(p, "w").write(t)

# P8: test operands read what the place holds: keyed elements in valueExpression; instanceof's left.
p = "/tmp/h09b4b/repro/proto/src/lower.go"
t = open(p).read()
old = '''	case ast.IsAccessExpression(inner) && l.isNarrowedDynamic(inner.Expression()):
		return l.dynamicRead(inner) // what it holds, undefined past the end or for a missing key (D-179)
	}
	return unnarrowed(l.expression(node))'''
new = '''	case ast.IsAccessExpression(inner) && l.isNarrowedDynamic(inner.Expression()):
		return l.dynamicRead(inner) // what it holds, undefined past the end or for a missing key (D-179)
	case l.isKeyedElement(inner) && !l.isTupleElementNode(inner):
		return l.keyedElementValue(inner) // PROTO(H09b4b P8): `typeof o["v"]` reads what o["v"] holds, not tsc's (stale) narrowed type
	}
	return unnarrowed(l.expression(node))'''
assert old in t, "p8a"
t = t.replace(old, new)
old = '''	if t := l.typeAt(node); target == nil && isUnionValue(t) {
		return l.asUnion(node, t)
	}'''
new = '''	if t := l.typeAt(node); target == nil && isUnionValue(t) && isUnion(l.irType(t, node)) { // PROTO(H09b4b P3c): `"up" as Dir` of a brand over literals is a string
		return l.asUnion(node, t)
	}'''
assert old in t, "p3c"
t = t.replace(old, new)
old = '''func (l *lowerer) coveringMember(t *checker.Type) *checker.Type {'''
new = '''// isTupleElementNode reports whether node is an element access of a tuple (read by its
// own path). PROTO(H09b4b P8).
func (l *lowerer) isTupleElementNode(node *ast.Node) bool {
	return node.Kind == ast.KindElementAccessExpression && checker.IsTupleType(l.checker.GetNonNullableType(l.typeAt(node.Expression())))
}

func (l *lowerer) coveringMember(t *checker.Type) *checker.Type {'''
assert old in t, "p8b"
t = t.replace(old, new)
open(p, "w").write(t)

p = "/tmp/h09b4b/repro/proto/src/classes.go"
t = open(p).read()
old = '''	if !ok {
		l.notSupportedYet(expr.Right, "`instanceof` of anything but a class of the program is")
		return nil
	}
	x := l.expression(expr.Left)'''
new = '''	if !ok {
		l.notSupportedYet(expr.Right, "`instanceof` of anything but a class of the program is")
		return nil
	}
	x := l.valueExpression(expr.Left) // PROTO(H09b4b P8): what the place holds, not tsc's (stale) narrowed class'''
assert old in t, "p8c"
t = t.replace(old, new)
open(p, "w").write(t)
print("patched")
