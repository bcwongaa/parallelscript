p = "/tmp/h09b4b/repro/proto/src/unions.go"
t = open(p).read()
old = '''	if t := l.typeAt(node); t.Flags()&checker.TypeFlagsNever != 0 && x.Type() != ir.Void {
		return box(x)
	}
	union, ok := x.Type().(*ir.Union)'''
new = '''	// A union stays the declared union (`(s as Shape).kind` in an exhaustive default reads
	// it as it is); convert takes it to other types with a check (P1b).
	if t := l.typeAt(node); t.Flags()&checker.TypeFlagsNever != 0 && x.Type() != ir.Void && !isUnion(x.Type()) {
		return box(x)
	}
	union, ok := x.Type().(*ir.Union)'''
assert old in t
t = t.replace(old, new)
open(p, "w").write(t)

p = "/tmp/h09b4b/repro/proto/src/lower.go"
t = open(p).read()
old = '''	default:
		l.notSupportedYet(node, fmt.Sprintf("converting %s to %s is", value.Type(), target))
		return nil
	}
}'''
new = '''	case isUnion(value.Type()) && node != nil && l.typeAt(node).Flags()&checker.TypeFlagsNever != 0:
		// PROTO(H09b4b P1b): a read tsc types never (stale, or a lie) holds a value of its
		// declared union, converted to the type its context needs with a check.
		return l.checkedConversion(value, target, node)
	default:
		l.notSupportedYet(node, fmt.Sprintf("converting %s to %s is", value.Type(), target))
		return nil
	}
}'''
assert old in t
t = t.replace(old, new)
open(p, "w").write(t)

p = "/tmp/h09b4b/repro/proto/src/dead_code.go"
t = open(p).read()
old = '''	case t.Flags()&(checker.TypeFlagsAny|checker.TypeFlagsUnknown|checker.TypeFlagsNever) != 0:
		return t
	case l.isDynamicIRType(t):'''
new = '''	case t.Flags()&(checker.TypeFlagsAny|checker.TypeFlagsUnknown|checker.TypeFlagsNever) != 0:
		return t
	case l.brandedPrimitive(t) != nil: // PROTO(H09b4b P3b): a branded primitive's IR type is its primitive's
		return l.checker.GetBaseTypeOfLiteralType(l.brandedPrimitive(t))
	case l.isDynamicIRType(t):'''
assert old in t
t = t.replace(old, new)
open(p, "w").write(t)
print("patched")
