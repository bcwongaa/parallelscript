import re

def strip_expect(t):
    i = t.find("\n// expect:")
    return t[:i + 1] if i >= 0 else t

# in-narrowing: move `called` out
p = "/tmp/h09b4b/repro/out/tests/in_narrowing_absent_member_routes.pts"
t = strip_expect(open(p).read())
old = '''function called(x: NoK): string {
  if ("k" in x && typeof x.k === "function") {
    return "k() " + x.k();
  }
  return "no k()";
}
'''
assert old in t
t = t.replace(old, "")
old = '''console.log(called({ m: "f", k: () => 42 } as NoK), called(withK), called(without));
'''
assert old in t
t = t.replace(old, "")
t = t.replace("and for a union of which neither member has k, and for a k that is a function. The base",
              "and for a union of which neither member has k. The base")
t = t.replace('''// goes: PTS9001 (`incompatible pointer to integer conversion passing 'pts_object *'`), or
// PTS1001 (`calling x.k`). (Parsed JSON cast to X is copied into X's shape, D-071, which
// drops k: not here.)''', '''// goes: PTS9001 (`incompatible pointer to integer conversion passing 'pts_object *'`).
// (Parsed JSON cast to X is copied into X's shape, D-071, which drops k: not here; a k that
// is a function and is called: in_narrowing_absent_method.pts.)''')
open(p, "w").write(t)

q = "/tmp/h09b4b/repro/out/tests/in_narrowing_absent_method.pts"
open(q, "w").write('''// `"k" in x && typeof x.k === "function"` for an x whose type has no k (H09b4b, C222): x.k
// is unknown narrowed to Function, and calling it calls what the object holds, as in Node.
// The base: PTS1001 (`calling x.k is not supported yet`); so does the reproducer's prototype.
interface NoK {
  m: string;
}
function called(x: NoK): string {
  if ("k" in x && typeof x.k === "function") {
    return "k() " + x.k();
  }
  return "no k()";
}
const withK = { m: "s", k: 5 };
console.log(called({ m: "f", k: () => 42 } as NoK), called(withK), called({ m: "t" }));
''')

# array intersections: move indexOf out
p = "/tmp/h09b4b/repro/out/tests/array_type_intersections.pts"
t = strip_expect(open(p).read())
t = t.replace(''' + " indexOf " + x.indexOf("a") + " slice "''', ''' + " slice "''')
t = t.replace(''' + "] indexOf " + x.indexOf("a") + " slice "''', ''' + "] slice "''')
assert "indexOf" not in t.split("// made")[1] if "// made" in t else True
t = t.replace("`length`,\n// `join`, `indexOf`, `slice` and a copy work", "`length`,\n// `join`, `slice` and a copy work")
open(p, "w").write(t)
q = "/tmp/h09b4b/repro/out/tests/array_type_intersection_searches.pts"
open(q, "w").write('''// Searching an intersection of array types (H09b4b, C227): `indexOf`, `includes` and
// `lastIndexOf` of a string in a `number[] & string[]` (an honest `v is string[]` on a
// number[]: an empty array) find nothing, as in Node; for a mixed array narrowed to string[]
// they search it. The base: PTS1001 (`calling x.indexOf is not supported yet`); the
// reproducer's prototype: PTS1001 (`converting string to number`, the argument converted to
// the instance's element type).
function isStrings(v: unknown): v is string[] {
  return Array.isArray(v) && v.every((e) => typeof e === "string");
}
function search<T>(x: T): string {
  if (isStrings(x)) {
    return x.indexOf("a") + " " + x.includes("a") + " " + x.lastIndexOf("b");
  }
  return "other";
}
function plain(x: number[]): string {
  if (isStrings(x)) {
    return "plain " + x.indexOf("a") + " " + x.includes("a");
  }
  return "plain other";
}
console.log(search<number[]>([]), search<(string | number)[]>(["a", "b"]), search<number[]>([1]));
console.log(plain([]), plain([2]));
''')
print("ok")
