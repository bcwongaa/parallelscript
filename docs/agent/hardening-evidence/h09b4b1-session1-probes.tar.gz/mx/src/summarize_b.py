"""Summarize an H09b4b matrix result: totals, by family, by each family's dimensions, then one
line per case.

Run: python3 -I summarize_b.py RESULTS.json [--cases] [--only-bad]
"""

import collections
import json
import sys

ORDER = ["OK", "WRONG", "TYPEERR", "RANGEERR", "PTS1001", "PTS1002", "PTS9001", "CRASH", "TIMEOUT", "TSERR", "BUILDFAIL", "NODEFAIL"]
DIMS = {
    "stale": ["read", "use", "form", "run"],
    "never": ["form"],
    "brand": ["brand", "use"],
    "in": ["route", "use", "form"],
    "cdisc": ["body", "targ"],
    "ochain": ["pred", "use", "form", "targ"],
    "arrint": ["use", "arg", "form"],
}


def table(title, groups):
    classes = [c for c in ORDER if any(g.get(c) for g in groups.values())]
    out = ["## " + title, "| value | " + " | ".join(classes) + " |", "|---|" + "---|" * len(classes)]
    for key, counts in groups.items():
        out.append("| %s | %s |" % (key, " | ".join(str(counts.get(c, "")) for c in classes)))
    return "\n".join(out) + "\n"


def main():
    results = json.load(open(sys.argv[1]))
    cases = "--cases" in sys.argv
    only_bad = "--only-bad" in sys.argv
    print(table("Totals", {"all (%d)" % len(results): collections.Counter(r["cls"] for r in results)}))
    fam = collections.OrderedDict()
    for r in results:
        fam.setdefault(r["family"], collections.Counter())[r["cls"]] += 1
    print(table("By family", fam))
    for family, dims in DIMS.items():
        rows = [r for r in results if r["family"] == family]
        if not rows:
            continue
        for d in dims:
            g = collections.OrderedDict()
            for r in rows:
                g.setdefault(str(r["dims"].get(d, "-")), collections.Counter())[r["cls"]] += 1
            print(table("%s by %s" % (family, d), g))
    if cases:
        print("## Cases")
        for r in results:
            if only_bad and r["cls"] == "OK":
                continue
            print("%-9s %-62s %s" % (r["cls"], r["id"], r.get("detail", "")[:150]))


if __name__ == "__main__":
    main()
