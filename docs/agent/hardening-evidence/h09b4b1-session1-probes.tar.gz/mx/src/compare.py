"""Compare two matrix results files: transition counts and the cases that left OK.

Run: python3 -I compare.py BEFORE_JSON AFTER_JSON
"""

import json
import sys
from collections import Counter


def main():
    before = {r["id"]: r for r in json.load(open(sys.argv[1]))}
    after = {r["id"]: r for r in json.load(open(sys.argv[2]))}
    moves = Counter()
    for cid, a in after.items():
        b = before.get(cid)
        if b:
            moves[(b["cls"], a["cls"])] += 1
    print("## Transitions (before -> after: count)")
    for (x, y), n in sorted(moves.items(), key=lambda kv: -kv[1]):
        print("%-9s -> %-9s %d" % (x, y, n))
    print("\n## Left OK (regressions)")
    for cid, a in after.items():
        b = before.get(cid)
        if b and b["cls"] == "OK" and a["cls"] != "OK":
            print("%s: %s %s" % (cid, a["cls"], a.get("detail", "")[:120]))
            print("   after: %r" % (a.get("pts_stdout", "") + a.get("pts_stderr", "")[:160]))
            print("   node : %r" % a["node_stdout"])
    print("\n## WRONG or CRASH after")
    for cid, a in after.items():
        if a["cls"] in ("WRONG", "CRASH"):
            print("%s (before %s): %r | node %r" % (cid, before.get(cid, {}).get("cls"), (a.get("pts_stdout", "") + a.get("pts_stderr", ""))[:200], a["node_stdout"]))


if __name__ == "__main__":
    main()
