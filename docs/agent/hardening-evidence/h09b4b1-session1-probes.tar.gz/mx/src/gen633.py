"""Generate the H09b4 matrix: one small program per case, compared HEAD vs Node by run.py.

Run: python3 -I gen.py OUTDIR   (writes OUTDIR/cases/<id>.pts and OUTDIR/cases.json)

Families:
  narrow   narrowing forms x {direct, value, plain} x {dead, live}
  shape    dead-region shapes (typeof x === "number", dead for string) x {direct, value, plain, live}
  call     call forms x {typeof-number body, Array.isArray body} x {dead, live}
  targ     narrowing forms x type arguments x {direct, value}
  control  soundness controls (live branches, lying predicates, branded and inhabited intersections)
  never    C194: type arguments inferred never
"""

import json
import os
import re
import sys

BOX = "class Box<T> {\n  constructor(public value: T) {}\n}\n"

HELPERS = {
    "Pt": "class Pt {\n  constructor(public v: number) {}\n}\n",
    "SubPt": "class SubPt extends Pt {\n  extra = 1;\n}\n",
    "num": 'function num(v: number): string {\n  return "num " + (v + 1);\n}\n',
    "isNum": 'function isNum(v: unknown): v is number {\n  return typeof v === "number";\n}\n',
    "isStr": 'function isStr(v: unknown): v is string {\n  return typeof v === "string";\n}\n',
    "assertNum": 'function assertNum(v: unknown): asserts v is number {\n  if (typeof v !== "number") {\n    throw new TypeError("not a number: " + String(v));\n  }\n}\n',
    "lyingIsNum": "function lyingIsNum(v: unknown): v is number {\n  return true;\n}\n",
    "lyingAssertNum": "function lyingAssertNum(v: unknown): asserts v is number {}\n",
    "Sq": 'interface Sq {\n  kind: "sq";\n  side: number;\n}\n',
    "Ci": 'interface Ci {\n  kind: "ci";\n  r: number;\n}\n',
    "HasK": "interface HasK {\n  k: number;\n}\n",
    "NoK": "interface NoK {\n  m: string;\n}\n",
    "Id": 'type Id = string & { __brand: "id" };\n',
    "Lengthy": "interface Lengthy {\n  length: number;\n}\n",
    "note": 'function note(label: string): boolean {\n  console.log("cond", label);\n  return true;\n}\n',
    "maybe": "function maybe(): string | undefined {\n  return undefined;\n}\n",
}
HELPER_ORDER = ["Pt", "SubPt", "num", "isNum", "isStr", "assertNum", "lyingIsNum", "lyingAssertNum",
                "Sq", "Ci", "HasK", "NoK", "Id", "Lengthy", "note", "maybe"]


def prelude(text):
    """Box plus the helpers the text names (SubPt pulls in Pt)."""
    out = BOX
    names = [h for h in HELPER_ORDER if re.search(r"\b%s\b" % h, text)]
    if "SubPt" in names and "Pt" not in names:
        names.insert(0, "Pt")
    for h in names:
        out += HELPERS[h]
    return out


def subst_t(text, ta):
    return re.sub(r"\bT\b", "(%s)" % ta if " " in ta or "&" in ta else ta, text)


def indent(text, n):
    pad = " " * n
    return "\n".join((pad + line) if line.strip() else line for line in text.strip("\n").split("\n"))


class Fn:
    """A generic function: type parameters, parameters, result, body; kind sync|async|gen."""

    def __init__(self, body, tparams="<T>", params="x: T", ret="Box<T>", kind="sync", argfmt="{v}"):
        self.body, self.tparams, self.params, self.ret, self.kind, self.argfmt = body, tparams, params, ret, kind, argfmt

    def full_ret(self, ret=None):
        r = ret or self.ret
        if self.kind == "async":
            return "Promise<%s>" % r
        if self.kind == "gen":
            return "Generator<string, %s, unknown>" % r
        return r

    def fn_type(self):
        return "%s(%s) => %s" % (self.tparams, self.params, self.full_ret())

    def header_kw(self):
        return {"sync": "function", "async": "async function", "gen": "function*"}[self.kind]


def call_and_print(call, kind, catches, pad=0):
    if kind == "async":
        code = "%s.then(\n  (b) => console.log(\"result\", b.value),\n  (error: any) => console.log(\"caught\", error.name, error.message),\n);" % call
        return indent(code, pad)
    if kind == "gen":
        code = ("const it = %s;\nlet step = it.next();\nwhile (!step.done) {\n  console.log(\"yielded\", step.value);\n"
                "  step = it.next();\n}\nconsole.log(\"result\", step.value.value);") % call
    else:
        code = "const b = %s;\nconsole.log(\"result\", b.value);" % call
    if catches:
        code = "try {\n%s\n} catch (error: any) {\n  console.log(\"caught\", error.name, error.message);\n}" % indent(code, 2)
    return indent(code, pad)


def program(fn, form, ta, value, catches=False):
    """The whole program for fn called by form with type argument ta and argument value."""
    arg = fn.argfmt.format(v=value)
    body = indent(fn.body, 2)
    kw = fn.header_kw()
    fr = fn.full_ret()
    tp, ps = fn.tparams, fn.params
    if form == "plain":
        ps2, fr2, body2 = subst_t(ps, ta), subst_t(fr, ta), subst_t(body, ta)
        code = "%s f(%s): %s {\n%s\n}\n%s\n" % (kw, ps2, fr2, body2, call_and_print("f(%s)" % arg, fn.kind, catches))
    elif form == "direct":
        code = "%s f%s(%s): %s {\n%s\n}\n%s\n" % (kw, tp, ps, fr, body, call_and_print("f<%s>(%s)" % (ta, arg), fn.kind, catches))
    elif form == "value":
        code = ("%s f%s(%s): %s {\n%s\n}\nfunction use(g: %s): void {\n%s\n}\nuse(f);\n"
                % (kw, tp, ps, fr, body, fn.fn_type(), call_and_print("g<%s>(%s)" % (ta, arg), fn.kind, catches, 2)))
    elif form == "const_arrow":
        code = "const f = %s(%s): %s => {\n%s\n};\n%s\n" % (tp, ps, fr, body, call_and_print("f<%s>(%s)" % (ta, arg), fn.kind, catches))
    elif form == "const_arrow_value":
        code = ("const f = %s(%s): %s => {\n%s\n};\nfunction use(g: %s): void {\n%s\n}\nuse(f);\n"
                % (tp, ps, fr, body, fn.fn_type(), call_and_print("g<%s>(%s)" % (ta, arg), fn.kind, catches, 2)))
    elif form == "local_arrow":
        code = ("function main(): void {\n  const f = %s(%s): %s => {\n%s\n  };\n%s\n}\nmain();\n"
                % (tp, ps, fr, indent(fn.body, 4), call_and_print("f<%s>(%s)" % (ta, arg), fn.kind, catches, 2)))
    elif form == "local_arrow_value":
        code = ("function use(g: %s): void {\n%s\n}\nfunction main(): void {\n  const f = %s(%s): %s => {\n%s\n  };\n  use(f);\n}\nmain();\n"
                % (fn.fn_type(), call_and_print("g<%s>(%s)" % (ta, arg), fn.kind, catches, 2), tp, ps, fr, indent(fn.body, 4)))
    elif form in ("method", "method_value", "static", "abstract", "interface", "objlit", "objlit_iface"):
        star = "*" if fn.kind == "gen" else ""
        asy = "async " if fn.kind == "async" else ""
        mbody = indent(fn.body, 4)
        meth = "%s%smake%s(%s): %s {\n%s\n  }" % (asy, star, tp, ps, fr, mbody)
        if form == "method":
            code = "class M {\n  %s\n}\n%s\n" % (meth, call_and_print("new M().make<%s>(%s)" % (ta, arg), fn.kind, catches))
        elif form == "method_value":
            code = ("class M {\n  %s\n}\nfunction use(g: %s): void {\n%s\n}\nuse(new M().make);\n"
                    % (meth, fn.fn_type(), call_and_print("g<%s>(%s)" % (ta, arg), fn.kind, catches, 2)))
        elif form == "static":
            code = "class U {\n  static %s\n}\n%s\n" % (meth, call_and_print("U.make<%s>(%s)" % (ta, arg), fn.kind, catches))
        elif form == "abstract":
            code = ("abstract class Base {\n  abstract make%s(%s): %s;\n}\nclass Impl extends Base {\n  %s\n}\n"
                    "const m: Base = new Impl();\n%s\n" % (tp, ps, fr, meth, call_and_print("m.make<%s>(%s)" % (ta, arg), fn.kind, catches)))
        elif form == "interface":
            code = ("interface Maker {\n  make%s(%s): %s;\n}\nclass Impl implements Maker {\n  %s\n}\n"
                    "const m: Maker = new Impl();\n%s\n" % (tp, ps, fr, meth, call_and_print("m.make<%s>(%s)" % (ta, arg), fn.kind, catches)))
        elif form == "objlit":
            code = "const o = {\n  %s,\n};\n%s\n" % (meth, call_and_print("o.make<%s>(%s)" % (ta, arg), fn.kind, catches))
        else:
            code = ("interface Maker {\n  make%s(%s): %s;\n}\nconst o: Maker = {\n  %s,\n};\n%s\n"
                    % (tp, ps, fr, meth, call_and_print("o.make<%s>(%s)" % (ta, arg), fn.kind, catches)))
    elif form == "class_tparam":
        cls_tp = fn.tparams
        code = ("class C%s {\n  m(%s): %s {\n%s\n  }\n}\n%s\n"
                % (cls_tp, ps, fr, indent(fn.body, 4), call_and_print("new C<%s>().m(%s)" % (ta, arg), fn.kind, catches)))
    elif form in ("nested", "nested_value"):
        inner = "%s inner%s(%s): %s {\n%s\n}\n" % (kw, tp, ps, fr, body)
        outer = "function f%s(%s): %s {\n  console.log(\"outer\");\n  return inner(%s);\n}\n" % (tp, ps, fr, ps.split(":")[0])
        if form == "nested":
            code = inner + outer + call_and_print("f<%s>(%s)" % (ta, arg), fn.kind, catches) + "\n"
        else:
            code = inner + outer + ("function use(g: %s): void {\n%s\n}\nuse(f);\n"
                                    % (fn.fn_type(), call_and_print("g<%s>(%s)" % (ta, arg), fn.kind, catches, 2)))
    else:
        raise ValueError(form)
    return code


CASES = []


def add(cid, family, dims, code, note=""):
    text = prelude(code) + code
    CASES.append({"id": cid, "family": family, "dims": dims, "code": text, "note": note})


# ---------------------------------------------------------------- narrowing forms
# name: (fn, dead (type, value), live (type, value), plain dead (type, value) or None, catches)
NARROW = {
    "typeof_eq": (Fn('if (typeof x === "number") {\n  console.log("dead", x + 1);\n}\nreturn new Box(x);'),
                  ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "typeof_neq_else": (Fn('if (typeof x !== "number") {\n  console.log("not a number");\n} else {\n  console.log("number", num(x));\n}\nreturn new Box(x);'),
                        ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "isarray": (Fn('if (Array.isArray(x)) {\n  console.log("array of", x.length);\n}\nreturn new Box(x);'),
                ("number", "2"), ("number[]", "[1, 2]"), ("number", "2"), False),
    "instanceof": (Fn('if (x instanceof Pt) {\n  console.log("pt", x.v + 1);\n}\nreturn new Box(x);'),
                   ("string", '"s"'), ("Pt", "new Pt(1)"), ("number[]", "[1, 2]"), False),
    "eq_null": (Fn('if (x === null) {\n  const n: null = x;\n  console.log("null", n);\n}\nreturn new Box(x);', tparams="<T extends string | null>"),
                ("string", '"s"'), ("null", "null"), ("string", '"s"'), False),
    "eq_undefined": (Fn('if (x === undefined) {\n  const u: undefined = x;\n  console.log("undefined", u);\n}\nreturn new Box(x);', tparams="<T extends string | undefined>"),
                     ("string", '"s"'), ("undefined", "undefined"), ("string", '"s"'), False),
    "loose_null": (Fn('if (x == null) {\n  const u: null | undefined = x;\n  console.log("nullish", u);\n}\nreturn new Box(x);', tparams="<T extends number | null | undefined>"),
                   ("number", "2"), ("null", "null"), ("number", "2"), False),
    "truthy": (Fn('if (x) {\n  const t: number = x;\n  console.log("truthy", t + 1);\n}\nreturn new Box(x);',
                  tparams="<T extends number | null>"),
               ("null", "null"), ("number", "2"), ("null", "null"), False),
    "falsy": (Fn('if (!x) {\n  const n: null = x;\n  console.log("falsy", n);\n}\nreturn new Box(x);', tparams="<T extends Pt | null>"),
              ("Pt", "new Pt(1)"), ("null", "null"), ("Pt", "new Pt(1)"), False),
    "discriminant": (Fn('if (x.kind === "sq") {\n  console.log("square", x.side + 1);\n}\nreturn new Box(x);', tparams="<T extends Sq | Ci>"),
                     ("Ci", '{ kind: "ci", r: 1 }'), ("Sq", '{ kind: "sq", side: 2 }'), None, False),
    "prop_typeof": (Fn('if (typeof o.v === "number") {\n  console.log("dead", o.v + 1);\n}\nreturn new Box(o.v);',
                       params="o: { v: T }", argfmt="{{ v: {v} }}"),
                    ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "elem_typeof": (Fn('if (typeof t[0] === "number") {\n  console.log("dead", t[0] + 1);\n}\nreturn new Box(t[0]);',
                       params="t: [T, number]", argfmt="[{v}, 0]"),
                    ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "in_operator": (Fn('if ("k" in x) {\n  console.log("has k", x.k);\n}\nreturn new Box(x);', tparams="<T extends HasK | NoK>"),
                    ("NoK", '{ m: "s" }'), ("HasK", "{ k: 1 }"), ("NoK", '{ m: "s" }'), False),
    "predicate": (Fn('if (isNum(x)) {\n  console.log("dead", x + 1);\n}\nreturn new Box(x);'),
                  ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "assertion": (Fn('try {\n  assertNum(x);\n  console.log("asserted", x + 1);\n} catch (error: any) {\n  console.log("caught", error.message);\n}\nreturn new Box(x);'),
                  ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "assertion_stmt": (Fn('assertNum(x);\nconsole.log("asserted", x + 1);\nreturn new Box(x);'),
                       ("string", '"s"'), ("number", "2"), ("string", '"s"'), True),
    "switch_typeof": (Fn('switch (typeof x) {\n  case "number":\n    console.log("number", x + 1);\n    break;\n  case "string":\n    console.log("string", x.length);\n    break;\n}\nreturn new Box(x);'),
                      ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "switch_typeof_fall": (Fn('switch (typeof x) {\n  case "number":\n    console.log("number", x + 1);\n  case "string":\n    console.log("string or fell through", typeof x);\n    break;\n}\nreturn new Box(x);'),
                           ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "switch_true": (Fn('switch (true) {\n  case typeof x === "number":\n    console.log("number", x + 1);\n    break;\n  default:\n    console.log("default");\n}\nreturn new Box(x);'),
                    ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
    "eq_literal": (Fn('if (x === 1) {\n  const one: 1 = x;\n  console.log("one", one + 1);\n}\nreturn new Box(x);', tparams="<T extends string | number>"),
                   ("string", '"s"'), ("number", "1"), None, False),
    "typeof_function": (Fn('if (typeof x === "function") {\n  console.log("function", x.name);\n}\nreturn new Box(x);'),
                        ("string", '"s"'), ("() => void", "() => {}"), None, False),
    "typeof_object": (Fn('if (typeof x === "object" && x !== null) {\n  console.log("object keys", Object.keys(x).length);\n}\nreturn new Box(x);'),
                      ("number", "2"), ("Pt", "new Pt(1)"), ("number", "2"), False),
    "aliased_cond": (Fn('const isNumber = typeof x === "number";\nif (isNumber) {\n  console.log("dead", x + 1);\n}\nreturn new Box(x);'),
                     ("string", '"s"'), ("number", "2"), ("string", '"s"'), False),
}

for name, (fn, dead, live, plain, catches) in NARROW.items():
    for form in ("direct", "value"):
        for which, (ta, v) in (("dead", dead), ("live", live)):
            add("narrow-%s-%s-%s" % (name, form, which), "narrow",
                {"narrowing": name, "context": form, "branch": which, "targ": ta}, program(fn, form, ta, v, catches))
    if plain:
        add("narrow-%s-plain-dead" % name, "narrow", {"narrowing": name, "context": "plain", "branch": "dead", "targ": plain[0]},
            program(fn, "plain", plain[0], plain[1], catches))

# ---------------------------------------------------------------- dead-region shapes
TN = 'typeof x === "number"'
SHAPES = {
    "if_then": ('if (%s) {\n  console.log("dead", num(x));\n}\nconsole.log("after");\nreturn new Box(x);' % TN, "sync", False),
    "if_side_effect_first": ('if (%s) {\n  console.log("side effect");\n  console.log("dead", num(x));\n}\nreturn new Box(x);' % TN, "sync", False),
    "else": ('if (typeof x !== "number") {\n  console.log("live");\n} else {\n  console.log("dead", num(x));\n}\nreturn new Box(x);', "sync", False),
    "elseif_chain": ('if (typeof x === "boolean") {\n  console.log("boolean", x ? 1 : 0);\n} else if (%s) {\n  console.log("number", num(x));\n} else {\n  console.log("other", String(x));\n}\nreturn new Box(x);' % TN, "sync", False),
    "nested_if": ('if (x !== undefined) {\n  if (%s) {\n    console.log("dead", num(x));\n  }\n  console.log("outer live");\n}\nreturn new Box(x);' % TN, "sync", False),
    "early_return": ('if (typeof x !== "number") {\n  console.log("early");\n  return new Box(x);\n}\nconsole.log("rest", num(x));\nreturn new Box(x);', "sync", False),
    "early_return_box": ('if (%s) {\n  return new Box(x);\n}\nreturn new Box(x);' % TN, "sync", False),
    "early_throw": ('if (typeof x !== "number") {\n  throw new Error("thrown " + String(x));\n}\nconsole.log("rest", num(x));\nreturn new Box(x);', "sync", True),
    "continue": ('for (let i = 0; i < 2; i++) {\n  if (typeof x !== "number") continue;\n  console.log("rest", num(x));\n}\nconsole.log("loop done");\nreturn new Box(x);', "sync", False),
    "break": ('while (true) {\n  if (typeof x !== "number") break;\n  console.log("rest", num(x));\n  break;\n}\nconsole.log("loop done");\nreturn new Box(x);', "sync", False),
    "do_while_break": ('do {\n  if (typeof x !== "number") break;\n  console.log("rest", num(x));\n} while (false);\nconsole.log("loop done");\nreturn new Box(x);', "sync", False),
    "cond_expr": ('const s = %s ? num(x) : "not";\nconsole.log("cond", s);\nreturn new Box(x);' % TN, "sync", False),
    "cond_expr_box": ('return %s ? new Box(x) : new Box(x);' % TN, "sync", False),
    "and_rhs": ('const s = %s && num(x);\nconsole.log("and", s);\nreturn new Box(x);' % TN, "sync", False),
    "or_rhs": ('const s = typeof x !== "number" || num(x);\nconsole.log("or", s);\nreturn new Box(x);', "sync", False),
    "cond_and_rhs": ('if (%s && x > 1) {\n  console.log("dead", num(x));\n}\nreturn new Box(x);' % TN, "sync", False),
    "nullish_rhs_in_dead": ('const s = typeof x !== "number" ? "not" : maybe() ?? num(x);\nconsole.log("nullish", s);\nreturn new Box(x);', "sync", False),
    "and_assign_rhs": ('let s = "s";\ns &&= %s ? num(x) : "kept";\nconsole.log("&&=", s);\nreturn new Box(x);' % TN, "sync", False),
    "or_assign_rhs": ('let s = "";\ns ||= %s ? num(x) : "kept";\nconsole.log("||=", s);\nreturn new Box(x);' % TN, "sync", False),
    "nullish_assign_rhs": ('let s: string | undefined = undefined;\ns ??= %s ? num(x) : "kept";\nconsole.log("??=", s);\nreturn new Box(x);' % TN, "sync", False),
    "switch_case": ('switch (typeof x) {\n  case "number":\n    console.log("dead", num(x));\n    break;\n  default:\n    console.log("default");\n}\nreturn new Box(x);', "sync", False),
    "while_body": ('let i = 0;\nwhile (%s && i < 1) {\n  console.log("dead", num(x));\n  i++;\n}\nconsole.log("after while");\nreturn new Box(x);' % TN, "sync", False),
    "for_body": ('for (let i = 0; %s && i < 1; i++) {\n  console.log("dead", num(x));\n}\nconsole.log("after for");\nreturn new Box(x);' % TN, "sync", False),
    "forof_in_dead": ('if (%s) {\n  for (const k of [1, 2]) {\n    console.log("dead", num(x + k));\n  }\n}\nconsole.log("after");\nreturn new Box(x);' % TN, "sync", False),
    "labelled_block": ('block: {\n  if (typeof x !== "number") break block;\n  console.log("dead", num(x));\n}\nconsole.log("after block");\nreturn new Box(x);', "sync", False),
    "try_around": ('try {\n  if (%s) {\n    console.log("dead", num(x));\n  }\n} finally {\n  console.log("finally");\n}\nreturn new Box(x);' % TN, "sync", False),
    "try_inside": ('if (%s) {\n  try {\n    console.log("dead", num(x));\n  } catch (error) {\n    console.log("caught");\n  } finally {\n    console.log("finally");\n  }\n}\nreturn new Box(x);' % TN, "sync", False),
    "throw_in_try": ('try {\n  if (%s) {\n    throw new Error(num(x));\n  }\n  console.log("no throw");\n} catch (error: any) {\n  console.log("caught", error.message);\n}\nreturn new Box(x);' % TN, "sync", False),
    "return_in_finally_dead": ('try {\n  console.log("try");\n} finally {\n  if (%s) {\n    console.log("dead", num(x));\n  }\n}\nreturn new Box(x);' % TN, "sync", False),
    "arrow_expr_capture": ('if (%s) {\n  const g = () => num(x);\n  console.log("dead", g());\n}\nreturn new Box(x);' % TN, "sync", False),
    "arrow_block_capture": ('if (%s) {\n  const g = () => {\n    const r = num(x);\n    return r;\n  };\n  console.log("dead", g());\n}\nreturn new Box(x);' % TN, "sync", False),
    "fn_expr_capture": ('if (%s) {\n  const g = function () {\n    return num(x);\n  };\n  console.log("dead", g());\n}\nreturn new Box(x);' % TN, "sync", False),
    "arrow_escapes": ('let g: () => string = () => "live closure";\nif (%s) {\n  g = () => num(x);\n}\nconsole.log(g());\nreturn new Box(x);' % TN, "sync", False),
    "generator": ('yield "start";\nif (%s) {\n  yield num(x);\n}\nyield "end";\nreturn new Box(x);' % TN, "gen", False),
    "async": ('await null;\nif (%s) {\n  const y = await Promise.resolve(x);\n  console.log("dead", num(y));\n}\nreturn new Box(x);' % TN, "async", False),
    "const_alias": ('if (%s) {\n  const y = x;\n  console.log("dead", num(y));\n}\nreturn new Box(x);' % TN, "sync", False),
    "hoisted_fn_in_dead": ('if (typeof x !== "number") {\n  return new Box(helper(x));\n}\nconsole.log("dead", num(x));\nreturn new Box(x);\nfunction helper(v: T): T {\n  console.log("helper");\n  return v;\n}', "sync", False),
    "dead_local_class": ('if (%s) {\n  class Local {\n    constructor(public n: number) {}\n  }\n  console.log("dead", new Local(x).n);\n}\nreturn new Box(x);' % TN, "sync", False),
    "dead_generic_call": ('if (%s) {\n  const inner = new Box(x);\n  console.log("dead", num(inner.value));\n}\nreturn new Box(x);' % TN, "sync", False),
    "dead_assignment": ('let y: T = x;\nif (%s) {\n  y = x;\n  console.log("dead", num(x));\n}\nreturn new Box(y);' % TN, "sync", False),
}

for name, (body, kind, catches) in SHAPES.items():
    fn = Fn(body, kind=kind)
    forms = [("direct", "string", '"s"', "dead"), ("value", "string", '"s"', "dead"),
             ("plain", "string", '"s"', "dead"), ("direct", "number", "2", "live")]
    for form, ta, v, which in forms:
        add("shape-%s-%s-%s" % (name, form, which), "shape", {"shape": name, "context": form, "branch": which, "targ": ta},
            program(fn, form, ta, v, catches))

# ---------------------------------------------------------------- call forms
BODIES = {
    "typeof": (Fn('if (typeof x === "number") {\n  console.log("dead", num(x));\n}\nreturn new Box(x);'), ("string", '"s"'), ("number", "2")),
    "isarray": (Fn('if (Array.isArray(x)) {\n  console.log("array of", x.length);\n}\nreturn new Box(x);'), ("number", "2"), ("number[]", "[1, 2]")),
}
CALL_FORMS = ["direct", "value", "const_arrow", "const_arrow_value", "local_arrow", "local_arrow_value", "method",
              "method_value", "static", "abstract", "interface", "objlit", "objlit_iface", "class_tparam", "nested",
              "nested_value", "plain"]
for bname, (fn, dead, live) in BODIES.items():
    for form in CALL_FORMS:
        for which, (ta, v) in (("dead", dead), ("live", live)):
            if form == "plain" and which == "live":
                continue
            add("call-%s-%s-%s" % (bname, form, which), "call", {"callform": form, "body": bname, "branch": which, "targ": ta},
                program(fn, form, ta, v))

# ---------------------------------------------------------------- type arguments
TARGS = [("string", "string", '"s"'), ("number", "number", "2"), ("boolean", "boolean", "true"),
         ("numarr", "number[]", "[1, 2]"), ("class", "Pt", "new Pt(1)"), ("null", "null", "null"),
         ("undefined", "undefined", "undefined"), ("union", "string | number", "3"), ("lit_str", '"a"', '"a"'),
         ("lit_num", "1", "1"), ("brand", "Id", '"id1" as Id'), ("unknown", "unknown", "2")]
TFORMS = {
    "typeof_number": Fn('if (typeof x === "number") {\n  console.log("number", x + 1);\n}\nreturn new Box(x);'),
    "typeof_string": Fn('if (typeof x === "string") {\n  console.log("string", x.length);\n}\nreturn new Box(x);'),
    "isarray": Fn('if (Array.isArray(x)) {\n  console.log("array", x.length);\n}\nreturn new Box(x);'),
    "eq_null": Fn('if (x === null) {\n  console.log("null", x);\n}\nreturn new Box(x);'),
    "instanceof": Fn('if (x instanceof Pt) {\n  console.log("pt", x.v + 1);\n}\nreturn new Box(x);'),
    "is_str_predicate": Fn('if (isStr(x)) {\n  console.log("isStr", x.length);\n}\nreturn new Box(x);'),
    "falsy": Fn('if (!x) {\n  console.log("falsy", String(x));\n} else {\n  console.log("truthy");\n}\nreturn new Box(x);'),
    "typeof_object": Fn('if (typeof x === "object") {\n  console.log("object", x === null ? "null" : "not null");\n}\nreturn new Box(x);'),
}
for fname, fn in TFORMS.items():
    for tname, ta, v in TARGS:
        for form in ("direct", "value"):
            add("targ-%s-%s-%s" % (fname, tname, form), "targ", {"narrowing": fname, "targ": tname, "context": form},
                program(fn, form, ta, v))

# ---------------------------------------------------------------- soundness controls
CONTROLS = {
    # A predicate that lies: tsc narrows a string to never (string & number); Node runs the branch.
    "lying_predicate_agnostic": (Fn('if (lyingIsNum(x)) {\n  console.log("lied", typeof x, String(x));\n}\nreturn new Box(x);'), "string", '"s"', "lying predicate, type-agnostic use"),
    "lying_predicate_demanding": (Fn('if (lyingIsNum(x)) {\n  console.log("lied", x + 1);\n}\nreturn new Box(x);'), "string", '"s"', "lying predicate, x + 1 (Node: s1)"),
    "lying_assertion": (Fn('lyingAssertNum(x);\nconsole.log("after", typeof x, x + 1);\nreturn new Box(x);'), "string", '"s"', "assertion that doesn't throw"),
    "side_effect_before_return": (Fn('console.log("hi");\nif (typeof x !== "number") {\n  return new Box(x);\n}\nconsole.log("dead", num(x));\nreturn new Box(x);'), "string", '"s"', "hi must print"),
    "side_effect_before_throw": (Fn('console.log("hi");\nif (typeof x !== "number") {\n  console.log("bye");\n  return new Box(x);\n}\nthrow new Error(num(x));'), "string", '"s"', "hi, bye must print"),
    "cond_side_effect_lhs": (Fn('if (note("lhs") && typeof x === "number") {\n  console.log("dead", num(x));\n}\nreturn new Box(x);'), "string", '"s"', "cond lhs must print"),
    "cond_side_effect_or_rhs": (Fn('if (typeof x === "number" || note("rhs")) {\n  console.log("live then");\n}\nreturn new Box(x);'), "string", '"s"', "|| rhs is live"),
    "cond_side_effect_dead_rhs": (Fn('if (typeof x === "number" && note(num(x))) {\n  console.log("dead");\n}\nconsole.log("after");\nreturn new Box(x);'), "string", '"s"', "&& rhs dead"),
    "fallthrough_live": (Fn('switch (typeof x) {\n  case "number":\n    console.log("dead", num(x));\n  case "string":\n    console.log("live case");\n}\nreturn new Box(x);'), "string", '"s"', "fallthrough into live case"),
    "in_extra_property": (Fn('if ("k" in x) {\n  console.log("has k at run time", x.k);\n}\nreturn new Box(x);', tparams="<T extends HasK | NoK>"), "NoK", "withK", "NoK value with an extra k: Node runs the branch"),
    "isarray_lengthy": (Fn('if (Array.isArray(x)) {\n  console.log("array", x.length);\n}\nreturn new Box(x);'), "Lengthy", "[1, 2, 3]", "Lengthy & any[] is inhabited"),
    "instanceof_subclass": (Fn('if (x instanceof SubPt) {\n  console.log("sub", x.extra);\n}\nreturn new Box(x);'), "Pt", "new SubPt(1)", "Pt narrowed to SubPt"),
    "instanceof_iface": (Fn('if (x instanceof Pt) {\n  console.log("pt", x.v);\n}\nreturn new Box(x);'), "{ v: number }", "new Pt(4)", "structural T, class value"),
    "typeof_object_null": (Fn('if (typeof x === "object") {\n  console.log("object", x);\n}\nreturn new Box(x);'), "null", "null", "typeof null is object"),
    "brand_is_str": (Fn('if (isStr(x)) {\n  console.log("brand string", x.length);\n}\nreturn new Box(x);'), "Id", '"id1" as Id', "brand narrowed by predicate: live"),
    "brand_typeof_string": (Fn('if (typeof x === "string") {\n  console.log("brand typeof", x.toUpperCase());\n}\nreturn new Box(x);'), "Id", '"id1" as Id', "brand typeof string: live"),
    "brand_typeof_number": (Fn('if (typeof x === "number") {\n  console.log("dead", x + 1);\n}\nreturn new Box(x);'), "Id", '"id1" as Id', "brand typeof number: dead"),
    "any_input": (Fn('if (typeof x === "number") {\n  console.log("number at run time", x + 1);\n}\nreturn new Box(x);'), "string", "5 as any", "any value of the wrong type: D-155 boundary"),
    "unknown_targ": (Fn('if (typeof x === "number") {\n  console.log("number", x + 1);\n}\nreturn new Box(x);'), "unknown", "5", "T = unknown: live"),
    "union_live_other": (Fn('if (typeof x === "number") {\n  console.log("number", x + 1);\n} else {\n  console.log("not number", x);\n}\nreturn new Box(x);'), "string | number", '"u"', "union: else live"),
    "hoisted_fn_live": (Fn('if (typeof x !== "number") {\n  return new Box(helper(x));\n}\nconsole.log("dead", num(x));\nreturn new Box(x);\nfunction helper(v: T): T {\n  console.log("helper ran");\n  return v;\n}'), "string", '"s"', "hoisted declaration in the dead tail, called live"),
    "erased_through_any": (None, None, None, "erased copy through any"),
}
for name, (fn, ta, v, note) in CONTROLS.items():
    if fn is None:
        code = ('function f<T>(x: T): Box<T> {\n  if (typeof x === "number") {\n    console.log("number", x + 1);\n  }\n  return new Box(x);\n}\n'
                'const g: any = f;\nconsole.log("result", g("s").value, g(2).value);\n')
        add("control-%s" % name, "control", {"control": name, "context": "any"}, code, note)
        continue
    setup = ""
    if v == "withK":
        setup = 'const withKLiteral = { m: "s", k: 5 };\nconst withK: NoK = withKLiteral;\n'
    contexts = ["direct", "value", "plain"]
    if name in ("unknown_targ", "any_input", "brand_typeof_number", "union_live_other"):
        contexts = ["direct", "value"]
    for form in contexts:
        catches = name in ("side_effect_before_throw",)
        add("control-%s-%s" % (name, form), "control", {"control": name, "context": form, "targ": ta},
            setup + program(fn, form, ta, v, catches), note)

# ---------------------------------------------------------------- extra narrowings
EXTRA_HELPERS = 'class Other {\n  constructor(public w: number) {}\n}\n'
EXTRA = {
    # Pt & Other: two unrelated classes, which no value is at run time.
    "instanceof_unrelated": (Fn('if (x instanceof Other) {\n  console.log("other", x.w + 1);\n}\nreturn new Box(x);'),
                             "Pt", "new Pt(1)", ["direct", "value", "plain"]),
    # The false branch of instanceof for an instance of the class: never.
    "instanceof_else": (Fn('if (!(x instanceof Pt)) {\n  console.log("not a pt", x);\n}\nreturn new Box(x);'),
                        "Pt", "new Pt(1)", ["direct", "value", "plain"]),
    # A union narrowed to never in plain code (narrowedValue keeps the union).
    "union_to_never": (Fn('if (typeof x === "boolean") {\n  const b: boolean = x;\n  console.log("boolean", b);\n}\nreturn new Box(x);'),
                       "string | number", "3", ["direct", "value", "plain"]),
    # A discriminant that tsc says can't match, though a cast put that kind in the object.
    "discriminant_cast_lie": (Fn('if (x.kind === "sq") {\n  console.log("square at run time", x.side + 1);\n}\nreturn new Box(x);', tparams="<T extends Sq | Ci>"),
                              "Ci", "lie", ["direct", "value"]),
    # typeof undefined for a string, with the value used as undefined.
    "typeof_undefined": (Fn('if (typeof x === "undefined") {\n  console.log("undefined", x);\n}\nreturn new Box(x);'),
                         "string", '"s"', ["direct", "value", "plain"]),
}
ASSERT_NEVER = '''function assertNever(x: never): never {
  throw new Error("unexpected " + JSON.stringify(x));
}
function area%(tp)s(s: %(pt)s): number {
  switch (s.kind) {
    case "sq":
      return s.side * s.side;
    case "ci":
      return 3 * s.r * s.r;
    default:
      return assertNever(s);
  }
}
const lie = { kind: "tri", side: 1, r: 1 } as unknown as Sq;
for (const s of [{ kind: "sq", side: 2 } as Sq, { kind: "ci", r: 1 } as Ci, lie]) {
  try {
    console.log("area", area%(call)s(s));
  } catch (error: any) {
    console.log("caught", error.message);
  }
}
'''
add("extra-assert_never-plain", "extra", {"narrowing": "assert_never", "context": "plain", "targ": "Sq | Ci"},
    ASSERT_NEVER % {"tp": "", "pt": "Sq | Ci", "call": ""}, "exhaustive switch with assertNever; a cast lie reaches the default")
add("extra-assert_never-direct", "extra", {"narrowing": "assert_never", "context": "direct", "targ": "Sq | Ci"},
    ASSERT_NEVER % {"tp": "<T extends Sq | Ci>", "pt": "T", "call": "<Sq | Ci>"}, "generic exhaustive switch with assertNever")
for name, (fn, ta, v, contexts) in EXTRA.items():
    for form in contexts:
        setup = EXTRA_HELPERS if "Other" in fn.body else ""
        if v == "lie":
            setup += 'const lie = { kind: "sq", side: 2, r: 1 } as unknown as Ci;\n'
        add("extra-%s-%s" % (name, form), "extra", {"narrowing": name, "context": form, "targ": ta}, setup + program(fn, form, ta, v))

# ---------------------------------------------------------------- C194: never type arguments
FIRST = "function first<T>(xs: readonly T[]): Box<T> {\n  return new Box(xs[0]);\n}\n"
NEVER = {
    "value_call": FIRST + "const firstValue: <T>(xs: readonly T[]) => Box<T> = first;\nconsole.log(\"value\", String(firstValue([]).value));\n",
    "direct_call": FIRST + "console.log(\"direct\", String(first([]).value));\n",
    "explicit_never": FIRST + "console.log(\"explicit\", String(first<never>([]).value));\n",
    "cast_never_array": FIRST + "console.log(\"cast\", String(first([] as never[]).value));\n",
    "box_printed": FIRST + "console.log(first([]));\n",
    "value_nullish": FIRST + "const firstValue: <T>(xs: readonly T[]) => Box<T> = first;\nconst v = firstValue([]).value ?? \"fallback\";\nconsole.log(\"nullish\", v);\n",
    "const_arrow": "const firstArrow = <T>(xs: readonly T[]): Box<T> => new Box(xs[0]);\nconsole.log(\"arrow\", String(firstArrow([]).value));\n",
    "local_arrow": "function main(): void {\n  const firstLocal = <T>(xs: readonly T[]): Box<T> => new Box(xs[0]);\n  console.log(\"local\", String(firstLocal([]).value));\n}\nmain();\n",
    "interface_method": ("interface Firsts {\n  first<T>(xs: readonly T[]): Box<T>;\n}\nclass F implements Firsts {\n  first<T>(xs: readonly T[]): Box<T> {\n    return new Box(xs[0]);\n  }\n}\n"
                         "const fs: Firsts = new F();\nconsole.log(\"interface\", String(fs.first([]).value));\n"),
    "class_method": ("class F {\n  first<T>(xs: readonly T[]): Box<T> {\n    return new Box(xs[0]);\n  }\n}\nconsole.log(\"method\", String(new F().first([]).value));\n"),
    "objlit_method": ("const o = {\n  first<T>(xs: readonly T[]): Box<T> {\n    return new Box(xs[0]);\n  },\n};\nconsole.log(\"object literal\", String(o.first([]).value));\n"),
    "objlit_iface": ("interface Firsts {\n  first<T>(xs: readonly T[]): Box<T>;\n}\nconst o: Firsts = {\n  first<T>(xs: readonly T[]): Box<T> {\n    return new Box(xs[0]);\n  },\n};\nconsole.log(\"object literal interface\", String(o.first([]).value));\n"),
    "returns_t_direct": "function firstPlain<T>(xs: readonly T[]): T {\n  return xs[0];\n}\nconsole.log(String(firstPlain([])));\n",
    "returns_t_logged": "function firstPlain<T>(xs: readonly T[]): T {\n  return xs[0];\n}\nconsole.log(\"logged\", firstPlain([]));\n",
    "returns_t_value": "function firstPlain<T>(xs: readonly T[]): T {\n  return xs[0];\n}\nconst fv: <T>(xs: readonly T[]) => T = firstPlain;\nconsole.log(String(fv([])));\n",
    "returns_t_const": "function firstPlain<T>(xs: readonly T[]): T {\n  return xs[0];\n}\nconst got = firstPlain([]);\nconsole.log(\"const\", String(got));\n",
    "returns_t_or_undefined": "function lastOf<T>(xs: readonly T[]): T | undefined {\n  return xs[xs.length - 1];\n}\nconsole.log(String(lastOf([])));\n",
    "async_box": "async function firstAsync<T>(xs: readonly T[]): Promise<Box<T>> {\n  return new Box(xs[0]);\n}\nfirstAsync([]).then((b) => console.log(\"async\", String(b.value)), (e: any) => console.log(\"async rejected\", e.name));\n",
    "async_t": "async function firstAsync<T>(xs: readonly T[]): Promise<T> {\n  return xs[0];\n}\nfirstAsync([]).then((v) => console.log(\"async t\", String(v)), (e: any) => console.log(\"async rejected\", e.name));\n",
    "generator_box": "function* each<T>(xs: readonly T[]): Generator<Box<T>> {\n  yield new Box(xs[0]);\n}\nfor (const b of each([])) {\n  console.log(\"generator\", String(b.value));\n}\n",
    "narrow_in_never": ("function g<T>(xs: readonly T[]): Box<T> {\n  const x = xs[0];\n  if (typeof x === \"number\") {\n    console.log(\"number\", x + 1);\n  }\n  return new Box(x);\n}\nconsole.log(\"narrowed\", String(g([]).value));\n"),
    "narrow_in_never_value": ("function g<T>(xs: readonly T[]): Box<T> {\n  const x = xs[0];\n  if (typeof x === \"number\") {\n    console.log(\"number\", x + 1);\n  }\n  return new Box(x);\n}\nconst gv: <T>(xs: readonly T[]) => Box<T> = g;\nconsole.log(\"narrowed value\", String(gv([]).value));\n"),
    "length_only": "function count<T>(xs: readonly T[]): Box<number> {\n  return new Box(xs.length);\n}\nconsole.log(\"count\", count([]).value);\n",
    "map_empty": "function wrapAll<T>(xs: readonly T[]): Box<T>[] {\n  return xs.map((x) => new Box(x));\n}\nconsole.log(\"mapped\", wrapAll([]).length);\n",
    "plain_never_string": "const e: never[] = [];\nconsole.log(\"plain\", String(e[0]));\n",
    "plain_never_unknown_arrow": "const e: never[] = [];\nconst read = (): unknown => e[0];\nconsole.log(\"plain unknown\", String(read()));\n",
    "control_number_empty": FIRST + "const empty: number[] = [];\ntry {\n  console.log(\"number[]\", String(first(empty).value));\n} catch (error: any) {\n  console.log(\"number[]\", error.name);\n}\n",
}
for name, code in NEVER.items():
    add("never-%s" % name, "never", {"form": name}, code)


def main():
    out = sys.argv[1]
    cases_dir = os.path.join(out, "cases")
    os.makedirs(cases_dir, exist_ok=True)
    meta = []
    seen = set()
    for c in CASES:
        assert c["id"] not in seen, c["id"]
        seen.add(c["id"])
        path = os.path.join(cases_dir, c["id"] + ".pts")
        with open(path, "w") as f:
            f.write(c["code"])
        meta.append({k: c[k] for k in ("id", "family", "dims", "note")} | {"file": path})
    with open(os.path.join(out, "cases.json"), "w") as f:
        json.dump(meta, f, indent=1)
    by = {}
    for c in CASES:
        by[c["family"]] = by.get(c["family"], 0) + 1
    print(len(CASES), by)


if __name__ == "__main__":
    main()
