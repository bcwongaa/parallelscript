"""Summarize a matrix results JSON: counts by family and by each dimension, and per-case lines.

Run: python3 -I summarize.py RESULTS_JSON [--cases]
"""

import json
import sys
from collections import Counter, defaultdict

CLASSES = ["OK", "WRONG", "TYPEERR", "RANGEERR", "PTS1001", "PTS9001", "TSERR", "CRASH", "TIMEOUT", "BUILDFAIL", "NODEFAIL"]
KEYS = {"narrow": ["narrowing", "context", "branch"], "shape": ["shape", "context", "branch"],
        "call": ["callform", "body", "branch"], "targ": ["narrowing", "targ", "context"],
        "control": ["control", "context"], "never": ["form"], "extra": ["narrowing", "context"]}


def table(rows, title):
    used = [c for c in CLASSES if any(r[1][c] for r in rows)]
    print("\n%s" % title)
    print("| value | " + " | ".join(used) + " |")
    print("|---|" + "---|" * len(used))
    for name, cnt in rows:
        print("| %s | " % name + " | ".join(str(cnt[c]) if cnt[c] else "" for c in used) + " |")


def main():
    results = json.load(open(sys.argv[1]))
    total = Counter(r["cls"] for r in results)
    table([("all (%d)" % len(results), total)], "## Totals")
    fam = defaultdict(Counter)
    for r in results:
        fam[r["family"]][r["cls"]] += 1
    table(sorted(fam.items()), "## By family")
    for family, keys in KEYS.items():
        rs = [r for r in results if r["family"] == family]
        for k in keys:
            by = defaultdict(Counter)
            order = []
            for r in rs:
                v = r["dims"].get(k, "-")
                if v not in by:
                    order.append(v)
                by[v][r["cls"]] += 1
            table([(v, by[v]) for v in order], "## %s by %s" % (family, k))
    if "--cases" in sys.argv:
        print("\n## Cases")
        for r in results:
            print("%-55s %-9s %s" % (r["id"], r["cls"], r.get("detail", "")[:150].replace("\n", " ")))


if __name__ == "__main__":
    main()
