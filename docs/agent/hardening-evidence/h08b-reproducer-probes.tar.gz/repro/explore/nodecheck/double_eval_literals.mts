// A spread of `m.keys()`, `s.values()`, `a.values()` or `t.values()` whose receiver is a
// call, in an array literal before a later suspension: keep() evaluates the whole
// operand (a live map iterator for maps and sets, D-110) before the suspension; the
// literal's spread (spreadParts -> mapIterableOf / arrayIteration / typedArrayIteration)
// evaluates the receiver again after it.
const trace: string[] = [];
const log = (s: string): void => {
  trace.push(s);
};
const show = (label: string, result: string): void => {
  console.log(`${label}: ${trace.join(",")} => ${result}`);
  trace.length = 0;
};
const m = new Map<number, number>([[1, 10], [2, 20]]);
const getM = (): Map<number, number> => {
  log("getM");
  return m;
};
const st = new Set([1, 2]);
const getSet = (): Set<number> => {
  log("getSet");
  return st;
};
const xs = [1, 2];
const getXs = (): number[] => {
  log("getXs");
  return xs;
};
const ta = new Float64Array([1, 2]);
const getTa = (): Float64Array => {
  log("getTa");
  return ta;
};
function drive(label: string, steps: Generator<number, string, number>): void {
  let step = steps.next();
  while (!step.done) {
    log("yielded");
    step = steps.next(10);
  }
  show(label, step.value);
}
drive("[...getM().keys(), yield]", (function* (): Generator<number, string, number> {
  return [...getM().keys(), yield 0].join("/");
})());
drive("[...getM().values(), yield]", (function* (): Generator<number, string, number> {
  return [...getM().values(), yield 0].join("/");
})());
drive("[...getSet().values(), yield]", (function* (): Generator<number, string, number> {
  return [...getSet().values(), yield 0].join("/");
})());
drive("[...getXs().values(), yield]", (function* (): Generator<number, string, number> {
  return [...getXs().values(), yield 0].join("/");
})());
drive("[...getTa().values(), yield]", (function* (): Generator<number, string, number> {
  return [...getTa().values(), yield 0].join("/");
})());
drive("[...getM(), [yield, 0]] as pairs", (function* (): Generator<number, string, number> {
  const pairs: [number, number][] = [...getM(), [yield 0, 0]];
  return pairs.map((p) => p.join(":")).join("/");
})());
drive("Math.max(...getM().values(), yield)", (function* (): Generator<number, string, number> {
  return String(Math.max(...getM().values(), yield 0));
})());
drive("Math.max(...getSet().values(), yield)", (function* (): Generator<number, string, number> {
  return String(Math.max(...getSet().values(), yield 0));
})());
drive("Math.max(...getTa().values(), yield)", (function* (): Generator<number, string, number> {
  return String(Math.max(...getTa().values(), yield 0));
})());
