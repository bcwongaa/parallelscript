// More spread sites before a later suspension.
const trace: string[] = [];
const log = (s: string): void => {
  trace.push(s);
};
const show = (label: string, result: string): void => {
  console.log(`${label}: ${trace.join(",")} => ${result}`);
  trace.length = 0;
};
function drive(label: string, steps: Generator<number, string, number>, change: () => void): void {
  let step = steps.next();
  while (!step.done) {
    log("yielded");
    change();
    step = steps.next(10);
  }
  show(label, step.value);
}
const xs = [3, 4];
drive("Math.hypot(...xs, yield)", (function* (): Generator<number, string, number> {
  return String(Math.hypot(...xs, yield 0));
})(), () => xs.push(12));
xs.length = 2;
const codes = [72, 105];
drive("String.fromCodePoint(...codes, yield)", (function* (): Generator<number, string, number> {
  return String.fromCodePoint(...codes, (yield 0) + 23);
})(), () => codes.push(63));
drive("new Float64Array([...xs, yield])", (function* (): Generator<number, string, number> {
  return new Float64Array([...xs, yield 0]).join("/");
})(), () => xs.push(100));
xs.length = 2;
const sources = [{ a: 1 }, { b: 2 }];
drive("Object.assign({}, ...sources, { z: yield })", (function* (): Generator<number, string, number> {
  return JSON.stringify(Object.assign({}, ...sources, { z: yield 0 }));
})(), () => {
  sources.push({ a: 5 });
});
const record: Record<string, number> = { a: 1 };
drive("Object.assign({}, record, { z: yield })", (function* (): Generator<number, string, number> {
  return JSON.stringify(Object.assign({}, record, { z: yield 0 }));
})(), () => {
  record.a = 5;
});

// a spread of the array a yield resumes with, before a later yield
const sent = [7];
function* resumed(): Generator<number, string, number[]> {
  return [...(yield 0), ...(yield 1)].join("/");
}
const r = resumed();
r.next();
r.next(sent);
sent.push(100);
show("[...(yield), ...(yield)]", String(r.next([9]).value));
