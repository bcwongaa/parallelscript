// Spreads before a suspension in other function and statement forms.
const trace: string[] = [];
const log = (s: string): void => {
  trace.push(s);
};
const show = (label: string, result: string): void => {
  console.log(`${label}: ${trace.join(",")} => ${result}`);
  trace.length = 0;
};
const list = (...ns: number[]): string => ns.join("/");
const later = (change: () => void): Promise<number> => {
  log("await");
  queueMicrotask(() => {
    log("changed");
    change();
  });
  return Promise.resolve(10);
};

// top-level await
const top = [1, 2];
show("top-level list(...top, await)", list(...top, await later(() => top.push(100))));

// async generator: await and yield
const ag = [1, 2];
async function* asyncGen(): AsyncGenerator<string, void, number> {
  yield list(...ag, await later(() => ag.push(100)));
  yield [...ag, yield "first"].join("/");
}
const agi = asyncGen();
show("async generator await", String((await agi.next()).value));
show("async generator yield (1)", String((await agi.next()).value));
ag.push(200);
show("async generator yield (2)", String((await agi.next(10)).value));

// a class's generator method spreading this's array
class Holder {
  items = [1, 2];
  *g(): Generator<number, string, number> {
    return list(...this.items, yield 0);
  }
}
const holder = new Holder();
const hg = holder.g();
hg.next();
holder.items.push(100);
show("list(...this.items, yield)", String(hg.next(10).value));

// in a conditional's branch
const cx = [1, 2];
function* conditional(c: boolean): Generator<number, string, number> {
  return c ? [...cx, yield 0].join("/") : "none";
}
const ci = conditional(true);
ci.next();
cx.push(100);
show("c ? [...cx, yield] : …", String(ci.next(10).value));

// two suspensions, a spread between them
const two = [1, 2];
function* twoSuspensions(): Generator<number, string, number> {
  return [...two, yield 0, ...two, yield 1].join("/");
}
const ti = twoSuspensions();
ti.next();
two.push(100);
ti.next(10);
two.push(200);
show("[...two, yield, ...two, yield]", String(ti.next(20).value));

// a spread of what a yield resumes with, then a later spread before another yield
const later2 = [1, 2];
function* resumedSpread(): Generator<number, string, number[]> {
  const got = [...(yield 0), ...later2, (yield 1)[0]];
  return got.join("/");
}
const ri = resumedSpread();
ri.next();
ri.next([7, 8]);
later2.push(100);
show("[...(yield), ...later2, (yield)[0]]", String(ri.next([9]).value));

// a spread in a for...of's iterated value and in a throw
const fo = [1, 2];
function* forOf(): Generator<number, string, number> {
  const seen: number[] = [];
  for (const x of [...fo, yield 0]) seen.push(x);
  return seen.join("/");
}
const fi = forOf();
fi.next();
fo.push(100);
show("for (x of [...fo, yield])", String(fi.next(10).value));
