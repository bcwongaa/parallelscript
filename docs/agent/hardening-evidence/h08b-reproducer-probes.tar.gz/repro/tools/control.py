#!/usr/bin/env python3
"""control.py IN.pts OUT.pts: the control twin of a RED test: every `yield <word>` becomes
`(10 as number)`, `await later(` becomes `nowLater(` (defined to log "await" and return 10
at once, without running its change), and `await Promise.resolve(N).then(` becomes
`nowThen(N, ` (runs the callback at once). The expect block is dropped. The twin has no
suspension left, so PTS must already match Node on it."""
import re
import sys

src = open(sys.argv[1]).read()
src = src[: src.index("// expect:")]
src = re.sub(r"\byield (\w+)", "(10 as number)", src)
src = src.replace("await later(", "nowLater(")
src = re.sub(r"await Promise\.resolve\((\d+)\)\.then\(", r"nowThen(\1, ", src)
src += """
function nowLater(change: () => void): number {
  log("await");
  return 10;
}
function nowThen(v: number, f: (v: number) => number): number {
  return f(v);
}
"""
open(sys.argv[2], "w").write(src)
