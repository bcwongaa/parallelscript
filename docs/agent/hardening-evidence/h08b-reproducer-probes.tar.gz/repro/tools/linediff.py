#!/usr/bin/env python3
"""linediff.py NODE.txt PTS.txt: pairs the outputs line by line (same count expected) and
prints each line that differs as `node | pts`, then the counts."""
import sys

node = open(sys.argv[1]).read().splitlines()
pts = open(sys.argv[2]).read().splitlines()
same = differ = 0
for i in range(max(len(node), len(pts))):
    a = node[i] if i < len(node) else "<missing>"
    b = pts[i] if i < len(pts) else "<missing>"
    if a == b:
        same += 1
    else:
        differ += 1
        print(f"  node: {a}\n  pts:  {b}")
print(f"{sys.argv[1]}: {same} lines the same, {differ} differ")
