#!/usr/bin/env python3
"""check_expect.py FILE.pts...: runs each program under Node (a strict-ESM .mts copy, as the
harness does) and checks that its stdout is exactly the `// expect:` block (each line
`// ` + text, or `//` for an empty line) and that Node exits 0 with nothing on stderr."""
import os
import subprocess
import sys
import tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
bad = 0
for path in sys.argv[1:]:
    src = open(path).read()
    marker = "// expect:\n"
    block = src[src.index(marker) + len(marker):]
    want = "".join(line[3:] + "\n" if line.startswith("// ") else "\n" for line in block.splitlines())
    with tempfile.TemporaryDirectory() as d:
        mts = os.path.join(d, os.path.basename(path)[:-4] + ".mts")
        open(mts, "w").write(src)
        p = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", mts], capture_output=True, text=True, timeout=60, cwd=d)
    ok = p.returncode == 0 and not p.stderr and p.stdout == want
    bad += not ok
    print(f"{'OK  ' if ok else 'FAIL'} {os.path.basename(path)}: node exit {p.returncode}, {len(p.stdout.splitlines())} lines, stderr {len(p.stderr)} bytes, stdout {'==' if p.stdout == want else '!='} expect block")
sys.exit(1 if bad else 0)
