#!/bin/bash
# pts.sh ARGS...: the base CLI of this worktree, with PTS_HOME set to it.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-aa4b4f961e6ae4462
export PTS_HOME=${PTS_HOME:-$W}
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
exec ${PTS_CLI:-$W/pts-bin/pts} "$@"
