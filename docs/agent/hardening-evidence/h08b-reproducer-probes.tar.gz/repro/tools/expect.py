#!/usr/bin/env python3
"""expect.py FILE.pts...: runs each program under Node (a strict-ESM .mts copy, as the
harness does) and rewrites its `// expect:` block with Node's stdout. Refuses if Node exits
non-zero or prints to stderr."""
import os
import subprocess
import sys
import tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
for path in sys.argv[1:]:
    src = open(path).read()
    marker = "// expect:\n"
    assert marker in src, path
    with tempfile.TemporaryDirectory() as d:
        mts = os.path.join(d, os.path.basename(path)[:-4] + ".mts")
        open(mts, "w").write(src)
        p = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", mts], capture_output=True, text=True, timeout=60, cwd=d)
    if p.returncode != 0 or p.stderr:
        sys.exit(f"{path}: node exit {p.returncode}\n{p.stderr}")
    head = src[: src.index(marker) + len(marker)]
    body = "".join(("// " + line).rstrip() + "\n" for line in p.stdout.splitlines())
    open(path, "w").write(head + body)
    print(f"{path}: {len(p.stdout.splitlines())} lines")
