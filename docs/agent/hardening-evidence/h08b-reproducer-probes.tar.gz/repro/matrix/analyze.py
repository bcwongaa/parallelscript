#!/usr/bin/env python3
"""analyze.py MATRIXDIR WHAT: groups of results.json with a sample each.
WHAT: ctlwrong (WRONG whose const control is WRONG), diag (DIAG messages), ice, tserr,
okwrong (WRONG with const OK and sync WRONG: kinds), sites."""
import collections
import json
import os
import re
import sys

matrix, what = sys.argv[1], sys.argv[2]
results = json.load(open(os.path.join(matrix, "results.json")))["results"]


def cls(r):
    real, sync, const = r["real"], r["sync"], r["const"]
    if real["verdict"] == "WRONG":
        if const["verdict"] == "OK" and sync["verdict"] == "OK":
            return "WRONG"
        return f"WRONG(ctl:{const['verdict']}/{sync['verdict']})"
    return real["verdict"]


if what == "ctlwrong":
    groups = collections.defaultdict(list)
    for cid, r in results.items():
        if cls(r).startswith("WRONG(ctl:WRONG"):
            groups[r["dims"]["kind"]].append(cid)
    for kind, cids in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        sites = collections.Counter(results[c]["dims"]["site"] for c in cids)
        print(f"{len(cids):4d} {kind}: sites {dict(sites)}")
        c = results[cids[0]]
        print(f"      e.g. {cids[0]}\n        const pts:  {c['const']['pts']}\n        const node: {c['const']['node']}")
elif what in ("diag", "ice", "tserr"):
    want = {"diag": "DIAG", "ice": "ICE", "tserr": "TSERR"}[what]
    groups = collections.defaultdict(list)
    for cid, r in results.items():
        if r["real"]["verdict"] == want:
            msg = re.sub(r"\(line \d+\)", "", str(r["real"]["pts"]))
            msg = re.sub(r"c\d+\.real\.pts:\d+:\d+ - error ", "", msg)
            msg = re.sub(r"_\d+", "_N", msg)
            groups[msg[:160]].append(cid)
    for msg, cids in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        kinds = collections.Counter(results[c]["dims"]["kind"] for c in cids)
        sites = collections.Counter(results[c]["dims"]["site"] for c in cids)
        print(f"{len(cids):4d} {msg}\n      kinds {dict(kinds)}\n      sites {dict(sites)}")
elif what == "okwrong":
    groups = collections.defaultdict(collections.Counter)
    for cid, r in results.items():
        groups[r["dims"]["kind"]][cls(r)] += 1
    for kind, counter in sorted(groups.items()):
        print(f"{kind:34s} " + "  ".join(f"{k}={v}" for k, v in sorted(counter.items())))
