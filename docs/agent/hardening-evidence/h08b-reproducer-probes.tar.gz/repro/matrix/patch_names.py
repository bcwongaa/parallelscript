"""One-off edit of matrix.py: unique program names; no tuple-typed literal for optional tuples."""
p = "/tmp/h08b/repro/matrix/matrix.py"
s = open(p).read()
old1 = '''                programs[f"{mode}_spread_{slug(kind['name'])}_{slug(mut_name)}"] = group'''
old2 = '''                programs[f"{mode}_object_{slug(kind['name'])}_{slug(mut_name)}"] = group'''
assert old1 in s and old2 in s
s = s.replace(old1, '''                name = f"{mode}_spread_{slug(kind['name'])}_{slug(mut_name)}"
                while name in programs:  # slugs collide: tuple [number, number] and [number, number?]
                    name += "_"
                programs[name] = group''')
s = s.replace(old2, '''                name = f"{mode}_object_{slug(kind['name'])}_{slug(mut_name)}"
                while name in programs:
                    name += "_"
                programs[name] = group''')
s = s.replace('''      tuple=dict(g="(a: number, b?: number, z?: number): string => [a, b, z]", tt="number, number?")),''',
              '''      tuple=dict(g="(a: number, b?: number, z?: number): string => [a, b, z]", tt="number, number?", optional=True)),''')
s = s.replace('''needs="tuple"),
    S("destructuring''', '''needs="tuple no optional"),
    S("destructuring''')
s = s.replace('''    if need == "tuple head":
        return tup is not None
''', '''    if need == "tuple head":
        return tup is not None
    if need == "tuple no optional":
        return tup is not None and not tup.get("optional")
''')
assert 'needs="tuple no optional"' in s and "optional=True)" in s and 'name += "_"' in s
open(p, "w").write(s)
print("patched")
