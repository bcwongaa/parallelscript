#!/usr/bin/env python3
"""sync_table.py MATRIXDIR: the synchronous order bug (no suspension): for each kind and
each site, how many cases have the sync control WRONG while the const control is OK, out
of the cases whose const control is OK; with a sample."""
import collections
import json
import os
import sys

results = json.load(open(os.path.join(sys.argv[1], "results.json")))["results"]
for key in ("kind", "site"):
    table = collections.defaultdict(lambda: [0, 0, None])
    for cid, r in results.items():
        if r["const"]["verdict"] != "OK":
            continue
        row = table[(r["dims"]["family"], r["dims"][key])]
        row[1] += 1
        if r["sync"]["verdict"] == "WRONG":
            row[0] += 1
            row[2] = row[2] or cid
    print(f"\nsync WRONG / const OK, by {key}:")
    for (family, name), (bad, total, sample) in sorted(table.items()):
        print(f"  {family:7s} {name:48s} {bad:4d}/{total:<4d}" + (f"  e.g. {results[sample]['sync']['pts']} node {results[sample]['sync']['node']}"[:200] if sample and key == 'kind' else ""))
