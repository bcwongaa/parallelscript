"""compare_manifests.py OLD NEW: case numbering of the common ids, and the new program names."""
import json
import sys

a = json.load(open(sys.argv[1]))["programs"]
b = json.load(open(sys.argv[2]))["programs"]
ida = {c["id"]: c["n"] for g in a.values() for c in g}
idb = {c["id"]: c["n"] for g in b.values() for c in g}
print("old cases", len(ida), "new cases", len(idb))
print("numbering changed for common ids:", sum(1 for k in ida if k in idb and ida[k] != idb[k]))
print("ids only in new:", len([k for k in idb if k not in ida]), "ids only in old:", len([k for k in ida if k not in idb]))
print("new program names:", [n for n in b if n not in a])
