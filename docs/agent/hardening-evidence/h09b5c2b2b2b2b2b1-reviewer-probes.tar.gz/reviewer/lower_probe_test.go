package lower

import (
	"fmt"
	"slices"
	"strings"
	"testing"

	"gotest.tools/v3/assert"
)

func TestReviewerD212FreshRootFirstEdge(t *testing.T) {
	for _, receivers := range []bool{false, true} {
		for _, tt := range []struct {
			name  string
			body  string
			known bool
		}{
			{"object", "const held = ({ unused: { value: second }, selected: { value: first } }).selected;", true},
			{"array_object", "const held = [{ value: first }, { value: second }][0];", true},
			{"array_array", "const held = [[first, second], [second, first]][1];", true},
			{"mixed_path", "const held = ({ unused: { value: second }, branch: [{ selected: { value: first } }] }).branch[0].selected;", true},
			{"parentheses", "const held = (((({ selected: ({ value: first }) })).selected));", true},
			{"readonly_data", "const held: Readonly<{ value: Value }> = ({ selected: { value: first } }).selected;", true},
			{"changed_any", "const held: { value: any } = ({ selected: { value: first } }).selected;", false},
			{"changed_unknown", "const held: { value: unknown } = ({ selected: { value: first } }).selected;", false},
			{"changed_optional", "const held: { value?: Value } = ({ selected: { value: first } }).selected;", false},
			{"changed_key_set", "// @ts-ignore: defensive first-edge changed-key proof guard, not supported native syntax\nconst held: { value: Value } = ({ selected: { value: first, other: second } }).selected;", false},
			{"declared_union", "const held: { value: Value } | { other: Value } = ({ selected: { value: first } }).selected;", false},
			{"readonly_array", "const held: readonly Value[] = ({ selected: [first, second] }).selected;", false},
			{"first_binding_any", "const held: any = ({ selected: { value: first } }).selected;", false},
			{"first_binding_mutable", "let held = ({ selected: { value: first } }).selected;", false},
			{"first_binding_exported", "export const held = ({ selected: { value: first } }).selected;", false},
			{"first_binding_asserted", "const held = (({ selected: { value: first } }).selected as { value: Value });", false},
			{"first_binding_nonnull", "const held = ({ selected: { value: first } }).selected!;", false},
			{"first_binding_satisfies", "const held = ({ selected: { value: first } }).selected satisfies { value: Value };", false},
			{"unselected_accessor", "const held = ({ selected: { value: first }, unused: { get value(): Value { return second; } } }).selected;", false},
			{"unselected_spread", "const held = ({ selected: { value: first }, unused: { ...{ value: second } } }).selected;", false},
			{"unselected_hole", "const held = ({ selected: { value: first }, unused: [first, , second] }).selected;", false},
			{"unselected_computed", "const key = 'value'; const held = ({ selected: { value: first }, unused: { [key]: second } }).selected;", false},
			{"unselected_proto", "const held = ({ selected: { value: first }, unused: { __proto__: { value: second } } }).selected;", false},
			{"unselected_asserted_literal", "const held = ({ selected: { value: first }, unused: ({ value: second } as { value: Value }) }).selected;", false},
			{"nonliteral_selected", "const original = { value: first }; const held = ({ selected: original }).selected;", false},
			{"call_selected", "function original(): { value: Value } { return { value: first }; } const held = ({ selected: original() }).selected;", false},
			{"conditional_root", "const held = (choose() ? { selected: { value: first } } : { selected: { value: second } }).selected;", false},
			{"asserted_root", "const held = (({ selected: { value: first } }) as { selected: { value: Value } }).selected;", false},
			{"dynamic_key", "let key: 'selected' = 'selected'; const held = ({ selected: { value: first } })[key];", false},
		} {
			t.Run(fmt.Sprintf("receivers_%t/%s", receivers, tt.name), func(t *testing.T) {
				projection := "held.value"
				want := "first"
				if tt.name == "array_array" {
					projection = "held[1]"
					want = "first"
				}
				if tt.name == "readonly_array" {
					projection = "held[0]"
				}
				l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+tt.body+" const probe = "+projection+"; probe;")
				steps := maxValueFlowSteps
				sources := (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0)
				if tt.known {
					assert.Assert(t, sources != nil, "the unchanged safe control must reach the fresh extraction proof")
					if receivers {
						want = "A"
					}
					assert.DeepEqual(t, returnedSourceNames(sources), []string{want})
				} else {
					assert.Assert(t, sources == nil, "first declared edge or complete literal validation must reject uncertainty")
				}
				assert.Equal(t, len(l.valueFlow.active), 0)
				assert.Equal(t, len(l.valueFlow.receivers.active), 0)
			})
		}
	}
}

func TestReviewerD212FreshFunctionMethodContract(t *testing.T) {
	for _, body := range []string{
		"const held: { value(): void } = ({ selected: { value: first } }).selected;",
		"interface Read { get value(): Value; } const held: Read = ({ selected: { value: first } }).selected;",
	} {
		l, probe := valueFlowProbe(t, nestedContainerPrelude(false)+body+" const probe = held.value; probe;")
		steps := maxValueFlowSteps
		assert.Assert(t, l.valueSources(probe, &steps, 0) == nil)
	}
}

func TestReviewerD212EveryFreshAliasUseBeforeAnyPositiveCache(t *testing.T) {
	for _, receivers := range []bool{false, true} {
		for _, unsafe := range []string{
			"", "other.value = second;", "sibling.value = second;", "held.plain = second;",
			"function later(): void { sibling.value = second; }", "consume(sibling);",
			"const stored = { other };", "function returned(): unknown { return other; }",
			"const spread = { ...sibling };", "const copied = [...[other]];", "let mutable = sibling;",
			"const dynamic: any = other;", "const opaque: unknown = sibling;", "export { sibling };",
			"const changed: { value?: Value } = other;", "const changed: { value: any } = other;",
			"const changed = other as { value: Value };", "const changed = sibling!;",
			"({ value: other.value } = { value: second });", "for (other.value of [second]) {}",
			"(other.value as Value) = second;", "delete (other as any).value;", "other.count++;",
			"let key: 'value' = 'value'; const dynamicRead = sibling[key];", "other.replace();",
			"(other.replace)();", "((other.replace<number>))?.(1);", "other.replace``;",
		} {
			for _, reverse := range []bool{false, true} {
				name := unsafe
				if name == "" {
					name = "unmodified"
				}
				t.Run(fmt.Sprintf("receivers_%t/reverse_%t/%s", receivers, reverse, name), func(t *testing.T) {
					source := nestedContainerPrelude(receivers) + `function replace<T>(this: { value: Value }, input?: T): void { this.value = second; }
const held = ({ selected: { child: { value: first, count: 0, replace }, side: { value: first, count: 0, replace }, plain: first }, discarded: { value: second } }).selected;
const child = held.child; const other = child; const sibling = held.side;
` + unsafe + `
const check_child = child.value; const check_other = other.value; const check_sibling = sibling.value; const check_plain = held.plain;
const probe = check_child; probe;`
					l, _ := valueFlowProbe(t, source)
					projections := containerAliasProbeExpressions(l)
					assert.Equal(t, len(projections), 4)
					if reverse {
						slices.Reverse(projections)
					}
					for _, projection := range projections {
						steps := maxValueFlowSteps
						sources := (sourceProof{l: l, receivers: receivers}).valueSources(projection, &steps, 0)
						if unsafe != "" {
							assert.Assert(t, sources == nil, "unsafe sibling/transitive use must poison every member regardless of query order")
						} else {
							want := "first"
							if receivers {
								want = "A"
							}
							assert.DeepEqual(t, returnedSourceNames(sources), []string{want})
						}
					}
					assert.Equal(t, len(l.valueFlow.active), 0)
					assert.Equal(t, len(l.valueFlow.receivers.active), 0)
				})
			}
		}
	}
}

func TestReviewerD212FreshFanoutAndExhaustion(t *testing.T) {
	fanout := func(count int, poison bool) string {
		var body strings.Builder
		body.WriteString("const held = ({ selected: { child: { value: first }, side: { value: first } } }).selected;\n")
		for i := 0; i < count; i++ {
			fmt.Fprintf(&body, "const alias%d = held.child; const terminal%d = alias%d.value;\n", i, i, i)
		}
		if poison {
			body.WriteString("const escaped = held.side; consume(escaped);\n")
		}
		body.WriteString("const check_first = alias0.value; const check_last = held.side.value; const probe = check_first; probe;")
		return nestedContainerPrelude(false) + body.String()
	}
	l, probe := valueFlowProbe(t, fanout(maxValueFlowDepth+2, false))
	steps := maxValueFlowSteps
	assert.DeepEqual(t, returnedSourceNames(l.valueSources(probe, &steps, 0)), []string{"first"})
	assert.Assert(t, steps > 0, "shallow siblings consume work rather than cumulative recursion depth")
	for _, count := range []int{12, maxValueFlowDepth + 2, maxValueFlowSteps + 1} {
		for _, budget := range []int{18, 160, 480} {
			t.Run(fmt.Sprintf("fanout_%d/budget_%d", count, budget), func(t *testing.T) {
				l, _ := valueFlowProbe(t, fanout(count, true))
				projections := containerAliasProbeExpressions(l)
				steps := budget
				assert.Assert(t, l.valueSources(projections[0], &steps, 0) == nil)
				t.Logf("initial work consumed=%d of %d; cached declarations=%d", budget-steps, budget, len(l.valueFlow.containers))
				for _, projection := range projections {
					steps = maxValueFlowSteps
					assert.Assert(t, l.valueSources(projection, &steps, 0) == nil, "an exhausted traversal cannot publish an unchecked positive")
				}
				for _, tree := range l.valueFlow.containers {
					assert.Assert(t, tree == nil)
				}
			})
		}
	}
}

func TestReviewerD212FreshFunctionReceiverCachesDisjoint(t *testing.T) {
	for _, receiverFirst := range []bool{false, true} {
		l, probe := valueFlowProbe(t, "class A {} const held = ({ selected: [{ value: new A() }] }).selected; const row = held[0]; const other = row; const probe = other.value; probe;")
		function := func() { steps := maxValueFlowSteps; assert.Assert(t, l.valueSources(probe, &steps, 0) == nil) }
		receiver := func() {
			steps := maxValueFlowSteps
			assert.DeepEqual(t, returnedSourceNames(l.receiverSources(probe, &steps, 0)), []string{"A"})
		}
		if receiverFirst {
			receiver()
			function()
		} else {
			function()
			receiver()
		}
		function()
		receiver()
		assert.Equal(t, len(l.valueFlow.active), 0)
		assert.Equal(t, len(l.valueFlow.receivers.active), 0)
	}
}
