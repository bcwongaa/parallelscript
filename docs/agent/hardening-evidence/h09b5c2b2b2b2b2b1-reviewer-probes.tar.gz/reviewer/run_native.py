import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--worktree', required=True)
parser.add_argument('--helper', action='append', required=True, help='label=absolute-helper-path')
parser.add_argument('--inputs', required=True)
parser.add_argument('--out', required=True)
parser.add_argument('--node', default='/home/bryan/.local/node/bin/node')
parser.add_argument('--modes', default='all,default')
args = parser.parse_args()
wt = Path(args.worktree).resolve()
inputs = Path(args.inputs).resolve()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
helpers = [item.split('=', 1) for item in args.helper]
commands = []
results = []

def run(command, stem, timeout):
    started = time.monotonic()
    stdout = stem.with_suffix(stem.suffix + '.stdout')
    stderr = stem.with_suffix(stem.suffix + '.stderr')
    try:
        completed = subprocess.run(command, cwd=wt, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        rc = completed.returncode
        stdout.write_bytes(completed.stdout)
        stderr.write_bytes(completed.stderr)
    except subprocess.TimeoutExpired as error:
        rc = 124
        stdout.write_bytes(error.stdout or b'')
        stderr.write_bytes((error.stderr or b'') + b'\nreview runner timeout\n')
    record = dict(command=command, cwd=str(wt), returncode=rc, seconds=time.monotonic()-started, stdout=str(stdout), stderr=str(stderr))
    commands.append(record)
    (out / 'commands.json').write_text(json.dumps(commands, indent=2))
    return record

for entry in sorted(inputs.glob('*.pts')):
    name = entry.stem
    twin = entry.with_suffix('.mts')
    node = run([args.node, str(twin)], out/(name+'.node'), 45)
    node_stdout = Path(node['stdout']).read_bytes()
    for mode in args.modes.split(','):
        for label, helper in helpers:
            stem = out / (name + '.' + label + '.' + mode)
            c_file = Path(str(stem) + '.c')
            binary = Path(str(stem) + '.bin')
            compile_result = run(['env', 'GOMAXPROCS=1', 'PTS_HOME='+str(wt), helper, mode, str(entry), str(c_file), str(binary)], Path(str(stem)+'.compile'), 120)
            record = dict(case=name,label=label,mode=mode,input_sha256=hashlib.sha256(entry.read_bytes()).hexdigest(),node=node,compile=compile_result)
            if c_file.exists(): record['c_sha256'] = hashlib.sha256(c_file.read_bytes()).hexdigest()
            if compile_result['returncode'] == 0:
                command = ['env', 'PTS_THREADS=1']
                if name == 'closure_gc': command += ['GC_INITIAL_HEAP_SIZE=65536','GC_FREE_SPACE_DIVISOR=1','GC_PRINT_STATS=1']
                command.append(str(binary))
                native = run(command, Path(str(stem)+'.run'), 45)
                record['native'] = native
                record['status'] = 'match' if node['returncode']==0 and native['returncode']==0 and Path(native['stdout']).read_bytes()==node_stdout else 'mismatch'
                if name=='closure_gc':
                    stderr=Path(native['stderr']).read_text(errors='replace')
                    record['gc_completed_markers']=stderr.count('Complete collection took')
            else:
                record['status'] = 'compile-error'
            binary.unlink(missing_ok=True)
            results.append(record)
            (out/'results.json').write_text(json.dumps(results,indent=2))
            print(label,mode,name,record['status'],flush=True)
summary = {}
for row in results:
    key = (row['label'],row['mode'],row['status'])
    text = '/'.join(key)
    summary[text] = summary.get(text,0)+1
(out/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,sort_keys=True))
