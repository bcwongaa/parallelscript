package driver_test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"gotest.tools/v3/assert"
)

func reviewerD212Inventory(kind, origin string, poisoned bool) string {
	var source strings.Builder
	source.WriteString(literalProjectionFlowPrelude())
	for i := 0; i < 3; i++ {
		fmt.Fprintf(&source, "class C%d { tag = %d; }\nfunction source%d<T>(value:T): Box<T> { return new Box(value); }\nclass M%d implements Maker { count=0; make<T>(value:T):Box<T> { this.count++; return new Box(value); } }\n", i, i, i, i)
		if kind == "receiver" {
			fmt.Fprintf(&source, "function use%d(value:Maker):void { const box:Box<C%d> = value.make(new C%d()); console.log(box.value.tag); }\n", i, i, i)
		} else {
			fmt.Fprintf(&source, "function use%d(value:Factory):void { const box:Box<C%d> = value(new C%d()); console.log(box.value.tag); }\n", i, i, i)
		}
		if kind == "captured_receiver" {
			fmt.Fprintf(&source, "function read%d(value:Maker):Factory { return value.make; }\n", i)
		} else if kind == "wrapper" {
			fmt.Fprintf(&source, "function read%d():Factory { const value:Maker=new M%d(); return value.make; }\n", i, i)
		}
	}
	valueType := "Factory"
	if kind == "receiver" || kind == "captured_receiver" {
		valueType = "Maker"
	}
	if origin == "shared" {
		resultType := valueType
		selected := "leaf.value"
		if kind == "captured_receiver" {
			resultType = "Factory"
			selected += ".make"
		}
		for _, name := range []string{"joined", "separate"} {
			fmt.Fprintf(&source, "function %s(value:%s):%s { const rows=({selected:[{value}]}).selected; const leaf=rows[0]; const alias=leaf; return %s; }\n", name, valueType, resultType, strings.Replace(selected, "leaf.", "alias.", 1))
		}
	}
	for i := 0; i < 3; i++ {
		value := fmt.Sprintf("source%d", i)
		if kind == "receiver" || kind == "captured_receiver" {
			value = fmt.Sprintf("new M%d()", i)
		}
		if kind == "wrapper" {
			value = fmt.Sprintf("read%d()", i)
		}
		fmt.Fprintf(&source, "const first%d:%s=%s;\n", i, valueType, value)
		if origin == "shared" {
			fn := "joined"
			if i == 2 {
				fn = "separate"
			}
			fmt.Fprintf(&source, "use%d(%s(first%d));\n", i, fn, i)
			continue
		}
		if origin == "array" {
			fmt.Fprintf(&source, "const held%d=[[{value:first%d}]][0]; const row%d=held%d[0]; const alias%d=row%d;\n", i, i, i, i, i, i)
		} else {
			fmt.Fprintf(&source, "const held%d=({discarded:{value:first%d},selected:{child:{value:first%d},side:{value:first%d}}}).selected; const row%d=held%d.child; const alias%d=row%d; const side%d=held%d.side; const ignored%d=side%d.value;\n", i, i, i, i, i, i, i, i, i, i, i, i)
		}
		if poisoned {
			fmt.Fprintf(&source, "function escape%d(value:unknown):void {} escape%d(alias%d);\n", i, i, i)
		}
		expression := fmt.Sprintf("alias%d.value", i)
		if kind == "captured_receiver" {
			expression = fmt.Sprintf("read%d(%s)", i, expression)
		}
		fmt.Fprintf(&source, "use%d(%s);\n", i, expression)
	}
	return source.String()
}

func TestReviewerD212FreshAllInstancesPairInventory(t *testing.T) {
	for _, kind := range []string{"function", "receiver", "captured_receiver", "wrapper"} {
		for _, origin := range []string{"object", "array", "shared"} {
			for _, poisoned := range []bool{false, true} {
				if origin == "shared" && poisoned {
					continue
				}
				t.Run(fmt.Sprintf("%s/%s/poisoned_%t", kind, origin, poisoned), func(t *testing.T) {
					entry := writeSource(t, reviewerD212Inventory(kind, origin, poisoned))
					c, err := driver.EmitCWith(t.Context(), entry, lower.AllInstances)
					assert.NilError(t, err)
					pairs := 0
					for value := 0; value < 3; value++ {
						for demand := 0; demand < 3; demand++ {
							required := poisoned || value == demand
							if origin == "shared" {
								required = value < 2 && demand < 2 || value == 2 && demand == 2
							}
							name := literalProjectionTarget(kind, value, demand)
							present := strings.Contains(c, name)
							if present {
								pairs++
							}
							assert.Check(t, present == required, "%s: got=%t required=%t", name, present, required)
							if kind != "function" {
								assert.Check(t, strings.Contains(c, "return "+name) == required, "descriptor registration must match %s", name)
							}
						}
					}
					t.Logf("review inventory target pairs=%d", pairs)
					if kind == "captured_receiver" && origin != "shared" {
						for i := 0; i < 3; i++ {
							assertCapturedReceiverWrapperSignatures(t, c, fmt.Sprintf("read%d_make", i), []int{i})
						}
					}
					if kind == "captured_receiver" && origin == "shared" {
						assertCapturedReceiverWrapperSignatures(t, c, "joined_make", []int{0, 1})
						assertCapturedReceiverWrapperSignatures(t, c, "separate_make", []int{2})
					}
				})
			}
		}
	}
}
