package lower

import (
	"fmt"
	"testing"

	"gotest.tools/v3/assert"
)

func TestReviewerD212FreshGenericAndArrayBarriers(t *testing.T) {
	for _, receivers := range []bool{false, true} {
		for _, body := range []string{
			"function outer<T>(input:T):void { const held=({selected:{value:first}}).selected; const probe=held.value; probe; } outer(1);",
			"const outer:<T>(input:T)=>void = input => { const held=({selected:{value:first}}).selected; const probe=held.value; probe; }; outer(1);",
			"class Outer<T> { method():void { const held=({selected:{value:first}}).selected; const probe=held.value; probe; } } new Outer<number>().method();",
			"const readonlyChild:readonly Value[]=[second]; const held=[[first],readonlyChild][0]; const probe=held[0]; probe;",
		} {
			t.Run(fmt.Sprintf("receivers_%t/%s", receivers, body), func(t *testing.T) {
				l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+body)
				steps := maxValueFlowSteps
				assert.Assert(t, (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0) == nil)
			})
		}
	}
}

func TestReviewerD212FreshDepthFailureIsNotAPartialPositive(t *testing.T) {
	body := "const held=({selected:{branch:[{value:first}]}}).selected; const rows=held.branch; const row=rows[0]; const alias=row; const probe=alias.value; probe;"
	for _, receivers := range []bool{false, true} {
		l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+body)
		steps := maxValueFlowSteps
		assert.Assert(t, (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0) != nil)
		l, probe = valueFlowProbe(t, nestedContainerPrelude(receivers)+body)
		steps = maxValueFlowSteps
		assert.Assert(t, (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, maxValueFlowDepth-12) == nil)
		assert.Assert(t, steps > 0)
		for _, tree := range l.valueFlow.containers {
			assert.Assert(t, tree == nil)
		}
		steps = maxValueFlowSteps
		assert.Assert(t, (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0) == nil, "cached exhausted source stays unknown")
		assert.Equal(t, steps, maxValueFlowSteps)
	}
}
