package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 5 {
		fmt.Fprintln(os.Stderr, "usage: helper all|default entry.pts output.c output.bin")
		os.Exit(2)
	}
	ctx := context.Background()
	entry, err := filepath.Abs(os.Args[2])
	if err != nil {
		fail(err)
	}
	var code string
	if os.Args[1] == "all" {
		code, err = driver.EmitCWith(ctx, entry, lower.AllInstances)
	} else if os.Args[1] == "default" {
		code, err = driver.EmitC(ctx, entry)
	} else {
		fail(fmt.Errorf("unknown mode %q", os.Args[1]))
	}
	if err != nil {
		fail(err)
	}
	if err = os.WriteFile(os.Args[3], []byte(code), 0600); err != nil {
		fail(err)
	}
	tc, err := toolchain.New()
	if err != nil {
		fail(err)
	}
	runtime, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		fail(err)
	}
	if err = tc.CompileProgram(ctx, runtime, []string{os.Args[3]}, os.Args[4]); err != nil {
		fail(err)
	}
}

func fail(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
