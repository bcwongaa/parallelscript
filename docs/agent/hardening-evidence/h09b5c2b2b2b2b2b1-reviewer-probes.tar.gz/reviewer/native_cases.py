from pathlib import Path
import sys

ROOT = Path(sys.argv[1]).resolve()
ROOT.mkdir(parents=True, exist_ok=True)
PRELUDE = '''class Box<T> { constructor(public value:T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; } class C1 { tag=1; } class C2 { tag=2; }
function source0<T>(value:T):Box<T> { console.log("source",0); return new Box(value); }
function source1<T>(value:T):Box<T> { console.log("source",1); return new Box(value); }
function source2<T>(value:T):Box<T> { console.log("source",2); return new Box(value); }
const f0:Factory=source0; const f1:Factory=source1; const f2:Factory=source2;
function use0(value:Factory):void { const b:Box<C0>=value(new C0()); console.log("tag",b.value.tag); }
function use1(value:Factory):void { const b:Box<C1>=value(new C1()); console.log("tag",b.value.tag); }
function use2(value:Factory):void { const b:Box<C2>=value(new C2()); console.log("tag",b.value.tag); }
'''
CASES = {
"functions_evaluation": '''function effect(value:string):number { console.log("effect",value); return 1; }
const held=({ discarded:effect("before"), child:[{value:f0},{value:f1}], after:effect("after") }).child;
const leaf=held[0]; const alias=leaf; use0(alias.value); use1(held[1].value);
function shared(value:Factory):Factory { const selected=({rows:[{value}]}).rows; const row=selected[0]; const alias=row; return alias.value; }
use0(shared(f0)); use1(shared(f1)); use2(shared(f2));
''',
"mutated_function_alias": '''const held=({ discarded:{value:f2}, selected:{child:{value:f0},side:{value:f0}} }).selected;
const child=held.child; const other=child; const sibling=held.side;
function change():void { other.value=f1; sibling.value=f2; }
change(); use0(other.value); use1(sibling.value); use2(held.child.value);
''',
"mutated_array_alias": '''const held=({selected:[f0,f1,f2]}).selected; const alias=held;
alias.reverse(); use0(held[0]); use1(alias[1]); use2(held[2]);
''',
"declared_method_contract": '''const held:{make<T>(value:T):Box<T>} = ({selected:{make:f0}}).selected;
const other=held; const box:Box<C0>=other.make(new C0()); console.log("method",box.value.tag);
''',
"dynamic_first_edge": '''const held:any=({selected:{value:f0}}).selected; const alias:any=held; alias.value=f1;
const selected:Factory=held.value; use0(selected); use1(selected);
''',
"receiver_state": '''class M0 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
class M1 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
function shared(value:Maker):Maker { const held=({selected:{rows:[{value}]}}).selected.rows; const row=held[0]; const alias=row; return alias.value; }
const left=shared(new M0("left",10)); const right=shared(new M1("right",20));
console.log(left.make(new C0()).value.tag); console.log(right.make(new C1()).value.tag); console.log(left.make(new C2()).value.tag); console.log(right.make(new C0()).value.tag);
''',
"explicit_bind_captures": '''class M0 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
class M1 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
function shared(lookup:Maker,receiver:Maker):Factory { const held=({selected:[{value:lookup.make.bind(receiver)}]}).selected; const row=held[0]; const alias=row; return alias.value; }
const left:Maker=new M0("left",10); const right:Maker=new M1("right",20);
const runRight=shared(left,right); const runLeft=shared(right,left);
use0(runRight); use1(runLeft); use2(runRight); use0(runLeft);
''',
"closure_gc": '''function fresh(seed:number):Factory {
let count=seed;
const fn:Factory=<T>(value:T):Box<T> => { count++; console.log("closure",count); return new Box(value); };
const held=({discarded:{note:"unused"},selected:{rows:[{value:fn}]}}).selected.rows;
const row=held[0]; const alias=row; return alias.value;
}
function churn():void { let total=0; for(let i=0;i<36000;i++) { const entry={ text:"churn".repeat(40)+i, index:i }; total+=entry.text.length; } console.log("churn",total>0); }
const left=fresh(10); const right=fresh(20);
use0(left); churn(); use1(right); churn(); use2(left); churn(); use0(right);
''',
}
for name, body in CASES.items():
    text = PRELUDE + body
    (ROOT / (name + '.pts')).write_text(text)
    (ROOT / (name + '.mts')).write_text(text)
print(f'prepared {len(CASES)} native/strict-ESM input pairs in {ROOT}')
