class Box<T> { constructor(public value:T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; } class C1 { tag=1; } class C2 { tag=2; }
function source0<T>(value:T):Box<T> { console.log("source",0); return new Box(value); }
function source1<T>(value:T):Box<T> { console.log("source",1); return new Box(value); }
function source2<T>(value:T):Box<T> { console.log("source",2); return new Box(value); }
const f0:Factory=source0; const f1:Factory=source1; const f2:Factory=source2;
function use0(value:Factory):void { const b:Box<C0>=value(new C0()); console.log("tag",b.value.tag); }
function use1(value:Factory):void { const b:Box<C1>=value(new C1()); console.log("tag",b.value.tag); }
function use2(value:Factory):void { const b:Box<C2>=value(new C2()); console.log("tag",b.value.tag); }
const held=({ discarded:{value:f2}, selected:{child:{value:f0},side:{value:f0}} }).selected;
const child=held.child; const other=child; const sibling=held.side;
function change():void { other.value=f1; sibling.value=f2; }
change(); use0(other.value); use1(sibling.value); use2(held.child.value);
