class Box<T> { constructor(public value:T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; } class C1 { tag=1; } class C2 { tag=2; }
function source0<T>(value:T):Box<T> { console.log("source",0); return new Box(value); }
function source1<T>(value:T):Box<T> { console.log("source",1); return new Box(value); }
function source2<T>(value:T):Box<T> { console.log("source",2); return new Box(value); }
const f0:Factory=source0; const f1:Factory=source1; const f2:Factory=source2;
function use0(value:Factory):void { const b:Box<C0>=value(new C0()); console.log("tag",b.value.tag); }
function use1(value:Factory):void { const b:Box<C1>=value(new C1()); console.log("tag",b.value.tag); }
function use2(value:Factory):void { const b:Box<C2>=value(new C2()); console.log("tag",b.value.tag); }
class M0 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
class M1 implements Maker { constructor(public label:string,public count:number) {} make<T>(value:T):Box<T> { this.count++; console.log(this.label,this.count); return new Box(value); } }
function shared(lookup:Maker,receiver:Maker):Factory { const held=({selected:[{value:lookup.make.bind(receiver)}]}).selected; const row=held[0]; const alias=row; return alias.value; }
const left:Maker=new M0("left",10); const right:Maker=new M1("right",20);
const runRight=shared(left,right); const runLeft=shared(right,left);
use0(runRight); use1(runLeft); use2(runRight); use0(runLeft);
