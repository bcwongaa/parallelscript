class Box<T> { constructor(public value:T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; } class C1 { tag=1; } class C2 { tag=2; }
function source0<T>(value:T):Box<T> { console.log("source",0); return new Box(value); }
function source1<T>(value:T):Box<T> { console.log("source",1); return new Box(value); }
function source2<T>(value:T):Box<T> { console.log("source",2); return new Box(value); }
const f0:Factory=source0; const f1:Factory=source1; const f2:Factory=source2;
function use0(value:Factory):void { const b:Box<C0>=value(new C0()); console.log("tag",b.value.tag); }
function use1(value:Factory):void { const b:Box<C1>=value(new C1()); console.log("tag",b.value.tag); }
function use2(value:Factory):void { const b:Box<C2>=value(new C2()); console.log("tag",b.value.tag); }
function fresh(seed:number):Factory {
let count=seed;
const fn:Factory=<T>(value:T):Box<T> => { count++; console.log("closure",count); return new Box(value); };
const held=({discarded:{note:"unused"},selected:{rows:[{value:fn}]}}).selected.rows;
const row=held[0]; const alias=row; return alias.value;
}
function churn():void { let total=0; for(let i=0;i<36000;i++) { const entry={ text:"churn".repeat(40)+i, index:i }; total+=entry.text.length; } console.log("churn",total>0); }
const left=fresh(10); const right=fresh(20);
use0(left); churn(); use1(right); churn(); use2(left); churn(); use0(right);
