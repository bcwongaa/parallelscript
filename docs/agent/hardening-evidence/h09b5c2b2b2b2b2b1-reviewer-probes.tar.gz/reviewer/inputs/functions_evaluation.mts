class Box<T> { constructor(public value:T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; } class C1 { tag=1; } class C2 { tag=2; }
function source0<T>(value:T):Box<T> { console.log("source",0); return new Box(value); }
function source1<T>(value:T):Box<T> { console.log("source",1); return new Box(value); }
function source2<T>(value:T):Box<T> { console.log("source",2); return new Box(value); }
const f0:Factory=source0; const f1:Factory=source1; const f2:Factory=source2;
function use0(value:Factory):void { const b:Box<C0>=value(new C0()); console.log("tag",b.value.tag); }
function use1(value:Factory):void { const b:Box<C1>=value(new C1()); console.log("tag",b.value.tag); }
function use2(value:Factory):void { const b:Box<C2>=value(new C2()); console.log("tag",b.value.tag); }
function effect(value:string):number { console.log("effect",value); return 1; }
const held=({ discarded:effect("before"), child:[{value:f0},{value:f1}], after:effect("after") }).child;
const leaf=held[0]; const alias=leaf; use0(alias.value); use1(held[1].value);
function shared(value:Factory):Factory { const selected=({rows:[{value}]}).rows; const row=selected[0]; const alias=row; return alias.value; }
use0(shared(f0)); use1(shared(f1)); use2(shared(f2));
