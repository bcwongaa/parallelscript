import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True,exist_ok=False)
env = dict(os.environ, GOMAXPROCS='2', PTS_HOME=str(repo))
source=repo/'pts/tests/run/generic_container_alias_sources.pts'
entry=out/'fixture.pts'
shutil.copyfile(source,entry)
twin=entry.with_suffix('.mts')
shutil.copyfile(source,twin)
commands=[]
def run(args):
    p=subprocess.run(list(map(str,args)),cwd=repo,env=env,capture_output=True,text=True,timeout=180)
    commands.append(dict(command=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    (out/'commands.json').write_text(json.dumps(commands,indent=2))
    assert p.returncode==0, commands[-1]
    return p.stdout
node=run([Path.home()/'.local/node/bin/node','--no-warnings','--experimental-transform-types',twin])
expected='\n'.join(line.removeprefix('// ') for line in source.read_text().split('// expect:\n')[1].splitlines() if line.startswith('// '))+'\n'
assert node==expected,(node,expected)
for label, helper, cli in [('base','proof-base','pts-base'),('current','proof-current',str(repo/'pts-bin/pts'))]:
    strict=out/(label+'-all.bin')
    run([Path('/tmp/h09-container-alias')/helper,entry,out/(label+'.c'),strict])
    assert run([strict])==node
    strict.unlink()
    default=out/(label+'-default.bin')
    cli_path=Path(cli) if Path(cli).is_absolute() else Path('/tmp/h09-container-alias')/cli
    run([cli_path,'build',entry,'-o',default])
    assert run([default])==node
    default.unlink()
print('4 strict/default base/current native outputs match strict Node and the unchanged expected fixture output',flush=True)
