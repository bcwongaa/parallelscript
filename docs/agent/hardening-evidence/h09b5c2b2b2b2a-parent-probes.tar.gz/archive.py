import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import sys

root, target = map(Path, sys.argv[1:])
assert not target.exists()
allowed={'.go','.pts','.mts','.py','.sh','.c','.h','.json','.jsonl','.stderr','.stdout','.out','.err','.exit','.log','.command','.sha256','.patch'}
payload={}
for path in sorted(root.rglob('*')):
    if not path.is_file() or path.is_symlink() or '__pycache__' in path.parts or path.suffix not in allowed:
        continue
    relative=path.relative_to(root).as_posix()
    if relative=='final-suite/suite.jsonl':
        continue
    data=path.read_bytes()
    assert not data.startswith(b'\x7fELF'),relative
    data.decode('utf-8')
    payload[relative]=data
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in payload.items()}
payload['MANIFEST.json']=json.dumps(manifest,indent=2).encode()
with target.open('xb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(mode='w',fileobj=compressed) as tar:
            for name,data in payload.items():
                info=tarfile.TarInfo(name)
                info.size=len(data)
                info.mode=0o644
                info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(target,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(payload)
    for member in members:
        name=PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts
        assert tar.extractfile(member).read()==payload[member.name]
receipt=dict(archive=target.name,bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),regular_utf8_members=len(payload),payload=manifest)
target.with_suffix('.manifest.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({k:v for k,v in receipt.items() if k!='payload'},indent=2))
