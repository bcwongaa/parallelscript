package lower

import (
	"fmt"
	"os"
	"slices"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/internal/ast"
	"gotest.tools/v3/assert"
)

// These independent review probes deliberately use only the pre-D209 proof API,
// so the same bytes can be run with the exact-base production-file overlay.
func TestReviewD209AliasContracts(t *testing.T) {
	for _, tt := range []struct {
		name  string
		body  string
		known bool
	}{
		{"inferred", "const root = { value: first }; const alias = root;", true},
		{"named_contract", "interface Held { value: Value; } const root: Held = { value: first }; const alias: Held = root;", true},
		{"readonly_contract", "const root: { value: Value } = { value: first }; const alias: Readonly<{ value: Value }> = root;", true},
		{"readonly_to_mutable_contract", "const root: Readonly<{ value: Value }> = { value: first }; const alias: { value: Value } = root;", true},
		{"reordered_properties", "const root: { value: Value; other: Value } = { value: first, other: second }; const alias: { other: Value; value: Value } = root;", true},
		{"finite_record_contract", "const root: { value: Value } = { value: first }; const alias: Record<\"value\", Value> = root;", true},
		{"optional_same_contract", "interface Held { value?: Value; } const root: Held = { value: first }; const alias: Readonly<Held> = root;", true},
		{"inferred_equivalent_but_distinct_member", "const root = { value: first }; const alias: { value: Value } = root;", false},
		{"method_conversion", "const root: { value: Value } = { value: first }; const alias: { value(): void } = root;", false},
		{"accessor_conversion", "const root: { value: Value } = { value: first }; const alias: { get value(): Value } = root;", false},
		{"optional_conversion", "const root: { value: Value } = { value: first }; const alias: { value?: Value } = root;", false},
		{"indexed_conversion", "const root: { value: Value } = { value: first }; const alias: { [key: string]: Value } = root;", false},
		{"extra_optional_conversion", "const root: { value: Value } = { value: first }; const alias: { value: Value; other?: Value } = root;", false},
		{"changed_callable_contract", "const root: { value: Value } = { value: first }; const alias: { value: (x?: number) => void } = root;", false},
		{"unknown_intermediary", "const root: { value: Value } = { value: first }; const opaque: unknown = root; const alias = opaque as { value: Value };", false},
		{"dynamic_intermediary", "const root = { value: first }; const opaque: any = root; const alias: { value: Value } = opaque;", false},
		{"asserted_intermediary", "const root = { value: first }; const middle = root as { value: Value }; const alias = middle;", false},
		{"satisfies_intermediary", "const root = { value: first }; const middle = root satisfies { value: Value }; const alias = middle;", false},
		{"nonnull_intermediary", "const root = { value: first }; const middle = root!; const alias = middle;", false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			l, _ := valueFlowProbe(t, literalProjectionPrelude(false)+tt.body+"const view_root = root.value; const view_alias = alias.value; const probe = view_alias; probe;")
			views := reviewD209Views(l)
			assert.Equal(t, len(views), 2)
			for _, view := range views {
				steps := maxValueFlowSteps
				sources := l.valueSources(view, &steps, 0)
				known := tt.known && os.Getenv("D209_REVIEW_BASE") == ""
				if known {
					assert.DeepEqual(t, returnedSourceNames(sources), []string{"first"})
				} else {
					assert.Assert(t, sources == nil, "the exact base or an uncertain edge must retain compatible sources")
				}
			}
		})
	}
}

func TestReviewD209WholeComponentOrders(t *testing.T) {
	for _, receiver := range []bool{false, true} {
		for _, tt := range []struct {
			name  string
			use   string
			known bool
		}{
			{"safe", "", true},
			{"shadow_is_separate", "function shadow(): void { const leaf = { value: second }; leaf.value = second; }", true},
			{"nested_named_alias", "function nested(): Value { const inside = sibling; return inside.value; }", true},
			{"nested_destructured_assignment", "({ x: [leaf.value] } = { x: [second] });", false},
			{"logical_assignment", "leaf.value ||= second;", false},
			{"dead_sibling_mutation", "function unused(): void { sibling.value = second; }", false},
			{"late_transitive_mutation", "const escape = sibling; function unused(): void { escape.value = second; }", false},
			{"default_parameter_escape", "function unused(value = sibling): void {}", false},
			{"arrow_return_escape", "const unused = () => sibling;", false},
			{"array_pattern_escape", "const [unused] = [sibling];", false},
			{"qualified_export_escape", "export { sibling as outside };", false},
			{"asserted_alias_sibling", "const unused = sibling as { value: Value };", false},
			{"narrowing_annotation_sibling", "const unused: { value: any } = sibling;", false},
		} {
			for _, reverse := range []bool{false, true} {
				t.Run(fmt.Sprintf("receiver_%t/%s/reverse_%t", receiver, tt.name, reverse), func(t *testing.T) {
					source := literalProjectionPrelude(receiver) + "const root = { value: first }; const alias = root, leaf = alias, sibling = root;\n" + tt.use + "\nconst view_root = root.value; const view_alias = alias.value; const view_leaf = leaf.value; const view_sibling = sibling.value; const probe = view_root; probe;"
					l, _ := valueFlowProbe(t, source)
					views := reviewD209Views(l)
					if reverse {
						slices.Reverse(views)
					}
					for _, view := range views {
						wrongSteps := maxValueFlowSteps
						wrong := (sourceProof{l: l, receivers: !receiver}).valueSources(view, &wrongSteps, 0)
						assert.Assert(t, wrong == nil, "the other source kind remains unknown")
						steps := maxValueFlowSteps
						sources := (sourceProof{l: l, receivers: receiver}).valueSources(view, &steps, 0)
						if tt.known && os.Getenv("D209_REVIEW_BASE") == "" {
							want := "first"
							if receiver {
								want = "A"
							}
							assert.DeepEqual(t, returnedSourceNames(sources), []string{want})
						} else {
							assert.Assert(t, sources == nil)
						}
					}
					if !tt.known {
						for _, members := range l.valueFlow.containers {
							assert.Assert(t, members == nil, "no positive component facts after an unsafe transitive use")
						}
					}
					assert.Equal(t, len(l.valueFlow.active), 0)
					assert.Equal(t, len(l.valueFlow.receivers.active), 0)
				})
			}
		}
	}
}

func TestReviewD209FanoutAndBudgetPoison(t *testing.T) {
	for _, count := range []int{300, 1024, 1400} {
		for _, poisoned := range []bool{false, true} {
			t.Run(fmt.Sprintf("width_%d/poison_%t", count, poisoned), func(t *testing.T) {
				var source strings.Builder
				source.WriteString(literalProjectionPrelude(false) + "const root = { value: first };\n")
				for i := 0; i < count; i++ {
					fmt.Fprintf(&source, "const branch%d = root; const read%d = branch%d.value;\n", i, i, i)
				}
				if poisoned {
					fmt.Fprintf(&source, "const escaped = branch%d; consume(escaped);\n", count-1)
				}
				source.WriteString("const view_root = root.value; const view_leaf = branch0.value; const probe = view_root; probe;")
				l, _ := valueFlowProbe(t, source.String())
				for _, view := range reviewD209Views(l) {
					steps := maxValueFlowSteps
					sources := l.valueSources(view, &steps, 0)
					known := !poisoned && count <= 1024 && os.Getenv("D209_REVIEW_BASE") == ""
					if known {
						assert.DeepEqual(t, returnedSourceNames(sources), []string{"first"})
					} else {
						assert.Assert(t, sources == nil)
					}
				}
				if poisoned {
					for _, members := range l.valueFlow.containers {
						assert.Assert(t, members == nil)
					}
				}
			})
		}
	}
	for _, budget := range []int{1, 5, 12, 128, 4096} {
		t.Run(fmt.Sprintf("poison_budget_%d", budget), func(t *testing.T) {
			source := literalProjectionPrelude(false) + "const root={value:first}; const alias=root; const leaf=alias; const sibling=root; const late=sibling; consume(late); const view_root=root.value; const view_alias=alias.value; const view_leaf=leaf.value; const view_sibling=sibling.value; const probe=view_root; probe;"
			l, _ := valueFlowProbe(t, source)
			views := reviewD209Views(l)
			steps := budget
			assert.Assert(t, l.valueSources(views[2], &steps, 0) == nil)
			for _, view := range views {
				steps = maxValueFlowSteps
				assert.Assert(t, l.valueSources(view, &steps, 0) == nil)
			}
			for _, members := range l.valueFlow.containers {
				assert.Assert(t, members == nil)
			}
		})
	}
}

func TestReviewD209SelectedSourceUnionLimit(t *testing.T) {
	for _, count := range []int{256, 257} {
		t.Run(fmt.Sprint(count), func(t *testing.T) {
			var source strings.Builder
			source.WriteString("type Value=()=>void; function shared(value:Value):void { const root={value}; const alias=root; const leaf=alias; const probe=leaf.value; probe; }\n")
			for i := 0; i < count; i++ {
				fmt.Fprintf(&source, "function f%d():void {} shared(f%d);\n", i, i)
			}
			l, probe := valueFlowProbe(t, source.String())
			steps := maxValueFlowSteps
			sources := l.valueSources(probe, &steps, 0)
			if count == 256 && os.Getenv("D209_REVIEW_BASE") == "" {
				assert.Equal(t, len(sources), 256)
			} else {
				assert.Assert(t, sources == nil)
			}
		})
	}
}

func reviewD209Views(l *lowerer) []*ast.Node {
	var views []*ast.Node
	var visit ast.Visitor
	visit = func(node *ast.Node) bool {
		if node.Kind == ast.KindVariableDeclaration && node.Name().Kind == ast.KindIdentifier && strings.HasPrefix(node.Name().Text(), "view_") {
			views = append(views, node.Initializer())
		}
		node.ForEachChild(visit)
		return false
	}
	for _, file := range l.valueFlow.files {
		file.AsNode().ForEachChild(visit)
	}
	return views
}
