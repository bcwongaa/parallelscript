import json
import pathlib
import sys

out = pathlib.Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
# Direct extracted methods are stateless so strict Node and native have the same
# observable behavior despite Node not doing ParallelScript's method capture.
prelude = '''class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag=10; } class C1 { tag=20; }
function source0<T>(value:T):Box<T>{return new Box(value,"fn0");}
function source1<T>(value:T):Box<T>{return new Box(value,"fn1");}
function source2<T>(value:T):Box<T>{return new Box(value,"fn2");}
class M0 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M0");}}
class M1 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M1");}}
class M2 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M2");}}
function use0(factory:Factory):void{const box:Box<C0>=factory(new C0());console.log(box.origin,box.value.tag);}
function use1(factory:Factory):void{const box:Box<C1>=factory(new C1());console.log(box.origin,box.value.tag);}
const keepFunctions:any[]=[source0,source1,source2];const keepMakers:Maker[]=[new M0(),new M1(),new M2()];
'''
diag=[[0,0],[1,1]]
first_unknown=[[0,0],[1,0],[2,0],[1,1]]
all_unknown=[[v,d] for v in range(3) for d in range(2)]
shared=[[v,d] for v in range(2) for d in range(2)]
cases=[]
def add(name,body,current,base,kind="receiver",descriptors=True):
    source=prelude+body+"\n"
    for extension in ["pts","mts"]:(out/(name+"."+extension)).write_text(source)
    cases.append(dict(name=name,kind=kind,current=current,base=base,descriptors=descriptors))
add("direct_captured_method_sites",'''function read0(receiver:Maker):Factory{return receiver.make;}function read1(receiver:Maker):Factory{return receiver.make;}
const root:{value:Maker}={value:new M0()};const alias=root;const leaf=alias;
const wrappers={value:read0(leaf.value)};const wa=wrappers;const wl=wa;use0(wl.value);use1(read1(new M1()));''',diag,first_unknown)
add("direct_captured_method_shared_site",'''function read(receiver:Maker):Factory{const root={value:receiver};const alias=root;const leaf=alias;return leaf.value.make;}
use0(read(new M0()));use1(read(new M1()));''',shared,all_unknown)
add("direct_wrappers_from_returns",'''function read0():Factory{const receiver:Maker=new M0();return receiver.make;}function read1():Factory{const receiver:Maker=new M1();return receiver.make;}function read2():Factory{const receiver:Maker=new M2();return receiver.make;}
const wrappers={value:read0(),other:read1()};const alias=wrappers;const leaf=alias;const keep:any[]=[read2()];use0(leaf.value);use1(leaf.other);''',diag,all_unknown)
add("closure_capture_allocation_churn",'''function capture(label:string):Factory{let calls=0;const f=<T,>(value:T):Box<T>=>{calls++;return new Box(value,label+"/"+calls);};const root={value:f};const alias=root;const leaf=alias;return leaf.value;}
const a=capture("a"),b=capture("b");const noise:string[]=[];for(let i=0;i<30000;i++){const temp:Box<number>=new Box(i,"noise");noise.push(temp.origin+temp.value);}console.log(noise.length,noise[29999]);use0(a);use1(b);use1(a);''',[],all_unknown,kind="function",descriptors=False)
(out/"cases.json").write_text(json.dumps(cases,indent=2)+"\n")
print(len(cases))
