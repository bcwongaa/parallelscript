class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag=10; } class C1 { tag=20; }
function source0<T>(value:T):Box<T>{return new Box(value,"fn0");}
function source1<T>(value:T):Box<T>{return new Box(value,"fn1");}
function source2<T>(value:T):Box<T>{return new Box(value,"fn2");}
class M0 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M0");}}
class M1 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M1");}}
class M2 implements Maker{make<T>(value:T):Box<T>{return new Box(value,"M2");}}
function use0(factory:Factory):void{const box:Box<C0>=factory(new C0());console.log(box.origin,box.value.tag);}
function use1(factory:Factory):void{const box:Box<C1>=factory(new C1());console.log(box.origin,box.value.tag);}
const keepFunctions:any[]=[source0,source1,source2];const keepMakers:Maker[]=[new M0(),new M1(),new M2()];
function read(receiver:Maker):Factory{const root={value:receiver};const alias=root;const leaf=alias;return leaf.value.make;}
use0(read(new M0()));use1(read(new M1()));
