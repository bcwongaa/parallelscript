import json
import os
import pathlib
import subprocess
import sys

root=pathlib.Path(sys.argv[1]).resolve()
scratch=root/".review-d209"
case=scratch/"capture-probes/closure_capture_allocation_churn.pts"
expected=(scratch/"capture-results/closure_capture_allocation_churn.node.out").read_bytes()
env=dict(os.environ,PTS_HOME=str(root),GOMAXPROCS="1",PTS_CC=str(scratch/"serial-clang.sh"),D209_COMPILER_LOCK=str(scratch/"compiler.lock"),GC_PRINT_STATS="1",GC_INITIAL_HEAP_SIZE="65536")
results=[]
commands=[]
for version in ["base","current"]:
    prefix=scratch/("gc-stress-"+version)
    build=[str(scratch/("strict-"+version)),"build",str(case),str(prefix)]
    commands.append(dict(argv=build,env={key:env[key] for key in ["PTS_HOME","GOMAXPROCS","PTS_CC","D209_COMPILER_LOCK","GC_PRINT_STATS","GC_INITIAL_HEAP_SIZE"]}))
    cp=subprocess.run(build,env=env,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
    pathlib.Path(str(prefix)+".build.out").write_bytes(cp.stdout)
    pathlib.Path(str(prefix)+".build.err").write_bytes(cp.stderr)
    result=dict(version=version,build_rc=cp.returncode)
    binary=pathlib.Path(str(prefix)+".bin")
    if cp.returncode==0:
        commands.append(dict(argv=[str(binary)],env={key:env[key] for key in ["PTS_HOME","GOMAXPROCS","PTS_CC","D209_COMPILER_LOCK","GC_PRINT_STATS","GC_INITIAL_HEAP_SIZE"]}))
        cp=subprocess.run([str(binary)],env=env,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
        pathlib.Path(str(prefix)+".out").write_bytes(cp.stdout)
        pathlib.Path(str(prefix)+".err").write_bytes(cp.stderr)
        result.update(native_rc=cp.returncode,node_match=cp.returncode==0 and cp.stdout==expected,statistics_lines=len(cp.stderr.splitlines()),collections=cp.stderr.count(b"collection #"))
    binary.unlink(missing_ok=True)
    results.append(result)
(scratch/"gc-stress-results.json").write_text(json.dumps(results,indent=2)+"\n")
(scratch/"gc-stress-commands.json").write_text(json.dumps(commands,indent=2)+"\n")
print(json.dumps(results))
