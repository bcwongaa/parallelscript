class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 10; }
class C1 { tag = 20; }
function source0<T>(value: T): Box<T> { return new Box(value, "fn0"); }
function source1<T>(value: T): Box<T> { return new Box(value, "fn1"); }
function source2<T>(value: T): Box<T> { return new Box(value, "fn2"); }
class M0 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M0/" + this.calls); } }
class M1 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M1/" + this.calls); } }
class M2 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M2/" + this.calls); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.origin, box.value.tag); }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.origin, box.value.tag); }
function ruse0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.origin, box.value.tag); }
function ruse1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.origin, box.value.tag); }
const keepFunctions: any[] = [source0, source1, source2];
const keepMakers: Maker[] = [new M0(), new M1(), new M2()];
const root = {value:source0}; const alias = root as {value:Factory}; const leaf = alias;
use0(leaf.value); use1(source1);
