#!/bin/sh
# Keep native compilation within the review's serial heavy subprocess budget.
exec flock "${D209_COMPILER_LOCK:?}" clang "$@"
