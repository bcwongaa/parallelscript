package main

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 || (os.Args[1] != "emit" && os.Args[1] != "build") {
		fmt.Fprintln(os.Stderr, "usage: review-d209 emit|build input.pts output-prefix")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	c, err := driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
	if err != nil {
		fail("strict emission", err)
	}
	file := os.Args[3] + ".c"
	if err := os.WriteFile(file, []byte(c), 0644); err != nil {
		fail("write C", err)
	}
	if os.Args[1] == "emit" {
		return
	}
	tc, err := toolchain.New()
	if err != nil {
		fail("toolchain", err)
	}
	rt, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		fail("runtime", err)
	}
	if err := tc.CompileProgram(ctx, rt, []string{file}, os.Args[3]+".bin"); err != nil {
		fail("compile C", err)
	}
}

func fail(phase string, err error) {
	fmt.Fprintf(os.Stderr, "%s: %v\n", phase, err)
	os.Exit(1)
}
