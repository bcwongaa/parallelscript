import hashlib
import json
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(sys.argv[1]).resolve()
scratch = root / ".review-d209"
source_dir = scratch / sys.argv[2]
output_dir = pathlib.Path(sys.argv[3]).resolve()
output_dir.mkdir(parents=True, exist_ok=False)
cases = json.loads((source_dir / "cases.json").read_text())
corrections = json.loads(pathlib.Path(sys.argv[4]).read_text())["overrides"] if len(sys.argv)>4 else {}
env = dict(os.environ, PTS_HOME=str(root), GOMAXPROCS="1", PTS_CC=str(scratch / "serial-clang.sh"), D209_COMPILER_LOCK=str(scratch / "compiler.lock"))
commands=[]
results=[]

def run(argv,prefix,timeout=180):
    commands.append(dict(argv=list(map(str,argv)),cwd=str(root),env={key:env[key] for key in ["PTS_HOME","GOMAXPROCS","PTS_CC","D209_COMPILER_LOCK"]}))
    try:
        cp=subprocess.run(list(map(str,argv)),env=env,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
        rc,stdout,stderr=cp.returncode,cp.stdout,cp.stderr
    except subprocess.TimeoutExpired as e:
        rc,stdout,stderr=124,e.stdout or b"",(e.stderr or b"")+b"\nREVIEW TIMEOUT\n"
    pathlib.Path(str(prefix)+".out").write_bytes(stdout)
    pathlib.Path(str(prefix)+".err").write_bytes(stderr)
    return rc,stdout,stderr

for original in cases:
    case=dict(original)
    case.update(corrections.get(case["name"],{}))
    name=case["name"]
    nrc,nout,nerr=run(["/home/bryan/.local/node/bin/node","--no-warnings","--experimental-transform-types",source_dir/(name+".mts")],output_dir/(name+".node"))
    result=dict(name=name,node_rc=nrc,corrected_metadata=name in corrections,versions={})
    for version in ["base","current"]:
        prefix=output_dir/(name+"."+version)
        brc,bout,berr=run([scratch/("strict-"+version),"build",source_dir/(name+".pts"),prefix],pathlib.Path(str(prefix)+".build"))
        data=dict(build_rc=brc,c_sha256=None,pairs=None,pair_check=None,descriptor_check=None,native_rc=None,node_match=False)
        cf=pathlib.Path(str(prefix)+".c")
        if cf.exists():
            code=cf.read_text()
            data["c_sha256"]=hashlib.sha256(cf.read_bytes()).hexdigest()
            names={(v,d):(f"pts_fn_source{v}_C{d}(" if case["kind"]=="function" else f"pts_fn_M{v}_make_C{d}(") for v in range(3) for d in range(2)}
            actual=sorted([list(pair) for pair,target in names.items() if target in code])
            data["pairs"]=actual
            if case[version] is not None:
                data["pair_check"]=actual==sorted(case[version])
                if case["descriptors"]:
                    registered=sorted([list(pair) for pair,target in names.items() if "return "+target in code])
                    data["registered_pairs"]=registered
                    data["descriptor_check"]=registered==sorted(case[version])
        diagnostic=case.get("unchanged_unsupported_diagnostic")
        if diagnostic:
            data["unsupported_check"]=brc!=0 and diagnostic in berr.decode()
        binary=pathlib.Path(str(prefix)+".bin")
        if brc==0:
            rc,out,err=run([binary],prefix,timeout=30)
            data.update(native_rc=rc,node_match=nrc==rc==0 and nout==out,native_stderr_empty=err==b"")
        binary.unlink(missing_ok=True)
        result["versions"][version]=data
    result["same_c"]=result["versions"]["base"]["c_sha256"] is not None and result["versions"]["base"]["c_sha256"]==result["versions"]["current"]["c_sha256"]
    results.append(result)
    (output_dir/"results.json").write_text(json.dumps(results,indent=2)+"\n")
    (output_dir/"commands.json").write_text(json.dumps(commands,indent=2)+"\n")
    print(json.dumps(result),flush=True)
