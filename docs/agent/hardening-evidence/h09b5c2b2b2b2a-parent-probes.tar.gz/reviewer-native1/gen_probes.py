import json
import pathlib
import sys

out = pathlib.Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
prelude = '''class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 10; }
class C1 { tag = 20; }
function source0<T>(value: T): Box<T> { return new Box(value, "fn0"); }
function source1<T>(value: T): Box<T> { return new Box(value, "fn1"); }
function source2<T>(value: T): Box<T> { return new Box(value, "fn2"); }
class M0 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M0/" + this.calls); } }
class M1 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M1/" + this.calls); } }
class M2 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "M2/" + this.calls); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.origin, box.value.tag); }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.origin, box.value.tag); }
function ruse0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.origin, box.value.tag); }
function ruse1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.origin, box.value.tag); }
const keepFunctions: any[] = [source0, source1, source2];
const keepMakers: Maker[] = [new M0(), new M1(), new M2()];
'''
diag = [[0, 0], [1, 1]]
first_unknown = [[0, 0], [1, 0], [2, 0], [1, 1]]
all_unknown = [[value, demand] for value in range(3) for demand in range(2)]
shared = [[value, demand] for value in range(2) for demand in range(2)]
cases = []
def add(name, body, kind="function", current=None, base=None, descriptors=False):
    source = prelude + body + "\n"
    (out / (name + ".pts")).write_text(source)
    (out / (name + ".mts")).write_text(source)
    cases.append(dict(name=name, kind=kind, current=current, base=base, descriptors=descriptors))

def function_case(name, storage, selected="leaf.value", known=True):
    add(name, storage + "\nuse0(" + selected + "); use1(source1);", current=diag if known else first_unknown, base=first_unknown)

function_case("typed_readonly", 'const root: { value: Factory } = { value: source0 }; const alias: Readonly<{ value: Factory }> = root; const leaf = (alias);')
function_case("numeric_key", 'const root: { 16: Factory } = { 16: source0 }; const alias = root; const leaf = alias;', "leaf[16]")
function_case("finite_record", 'const root: { value: Factory } = { value: source0 }; const alias: Record<"value", Factory> = root; const leaf = alias;')
function_case("array_alias", 'const root: Factory[] = [source0, source2]; const alias = root; const leaf = alias;', "leaf[0]")
function_case("sibling_escape_mutation", 'const root = { value: source0 }; const alias = root; const leaf = alias; const sibling = root; function mutate(v: {value: Factory}): void {v.value=source2;} mutate(sibling);', known=False)
function_case("dynamic_intermediary_mutation", 'const root = { value: source0 }; const alias = root; const leaf = alias; const dynamic: any = leaf; dynamic.value = source1;', known=False)
function_case("asserted_intermediary", 'const root = {value:source0}; const alias = root as {value:Factory}; const leaf = alias;', known=False)
function_case("readonly_array_conversion", 'const root: Factory[] = [source0, source2]; const alias: readonly Factory[] = root; const leaf = alias;', "leaf[0]", known=False)
function_case("tuple_array_conversion", 'const root: [Factory, Factory] = [source0, source2]; const alias: Factory[] = root; const leaf = alias;', "leaf[0]", known=False)
function_case("optional_contract_conversion", 'const root: {value:Factory} = {value:source0}; const alias: {value?:Factory} = root; const leaf=alias;', "leaf.value!", known=False)
function_case("container_parameter", 'function select(holder:{value:Factory}):Factory {const alias=holder;const leaf=alias;return leaf.value;} const root={value:source0}; const leaf={value:select(root)};', known=False)
function_case("returned_container", 'function holder():{value:Factory} {return {value:source0};} const root=holder();const alias=root;const leaf=alias;', known=False)
function_case("nested_container", 'const root={inner:{value:source0}};const alias=root;const leaf=alias.inner;', known=False)
function_case("changed_method_contract", 'const root:{value:Factory}={value:source0};const alias:{value<T>(v:T):Box<T>}=root;const leaf=alias;', known=False)
add("shared_function_site", '''function select(value:Factory):Factory {const root={value};const alias=root;const leaf=alias;return leaf.value;}
use0(select(source0));use1(select(source1));''', current=shared, base=all_unknown)
add("shared_closure_identity", '''function capture(label:string):Factory {let count=0;const fn=<T,>(value:T):Box<T>=>{count++;return new Box(value,label+"/"+count);};const root={value:fn};const alias=root;const leaf=alias;return leaf.value;}
const a=capture("a"),b=capture("b");use0(a);use1(b);use1(a);''', current=[], base=all_unknown)
add("receiver_readonly", '''const root:{value:Maker}={value:new M0()};const alias:Readonly<{value:Maker}>=root;const leaf=alias;ruse0(leaf.value);ruse1(new M1());''', kind="receiver", current=diag, base=first_unknown, descriptors=True)
add("receiver_sibling_mutation", '''const root:{value:Maker}={value:new M0()};const alias=root;const leaf=alias;const sibling=root;const late=sibling;late.value=new M2();ruse0(leaf.value);ruse1(new M1());''', kind="receiver", current=first_unknown, base=first_unknown, descriptors=True)
add("receiver_shared_site", '''function select(value:Maker):Maker {const root={value};const alias=root;const leaf=alias;return leaf.value;}ruse0(select(new M0()));ruse1(select(new M1()));''', kind="receiver", current=shared, base=all_unknown, descriptors=True)
add("captured_method_sites", '''function read0(receiver:Maker):Factory{return receiver.make.bind(receiver);}function read1(receiver:Maker):Factory{return receiver.make.bind(receiver);}
const root:{value:Maker}={value:new M0()};const alias=root;const leaf=alias;
const wrappers={value:read0(leaf.value)};const wa=wrappers;const wl=wa;use0(wl.value);use1(read1(new M1()));''', kind="receiver", current=diag, base=first_unknown, descriptors=True)
add("captured_method_shared_site", '''function read(receiver:Maker):Factory {const root={value:receiver};const alias=root;const leaf=alias;return leaf.value.make.bind(leaf.value);}
use0(read(new M0()));use1(read(new M1()));''', kind="receiver", current=shared, base=all_unknown, descriptors=True)
add("capture_before_after_mutation", '''function read(receiver:Maker):Factory{return receiver.make.bind(receiver);}const root:{value:Maker}={value:new M0()};const alias=root;const leaf=alias;const before=read(leaf.value);leaf.value=new M2();const after=read(root.value);use0(before);use1(after);use1(before);''', kind="receiver", current=all_unknown, base=all_unknown, descriptors=True)
add("explicit_bind_actual_this", '''class Parent implements Maker {calls=0;constructor(public label:string){}make<T>(value:T):Box<T>{this.calls++;return new Box(value,this.label+"/parent/"+this.calls);}}
class Child extends Parent{}class Override extends Parent{make<T>(value:T):Box<T>{this.calls++;return new Box(value,this.label+"/override/"+this.calls);}}
const lookup=new Parent("lookup");const actual=new Child("actual");const root={value:lookup.make.bind(actual)};const alias=root;const leaf=alias;use0(leaf.value);use1(leaf.value);
const receivers:{value:Maker,other:Maker}={value:new Child("child"),other:new Override("override")};const ra=receivers;const rl=ra;ruse0(rl.value);ruse1(rl.other);''', current=None, base=None)
(out / "cases.json").write_text(json.dumps(cases, indent=2)+"\n")
print(len(cases))
