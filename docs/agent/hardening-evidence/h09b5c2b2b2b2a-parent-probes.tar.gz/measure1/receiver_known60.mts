class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T> { console.log('source',0); return new Box(value); }
class M0 implements Maker { make<T>(value:T):Box<T> { console.log('method',0); return new Box(value); } }
function use0(receiver:Maker):void { const box:Box<C0>=receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag=1; }
function source1<T>(value:T):Box<T> { console.log('source',1); return new Box(value); }
class M1 implements Maker { make<T>(value:T):Box<T> { console.log('method',1); return new Box(value); } }
function use1(receiver:Maker):void { const box:Box<C1>=receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag=2; }
function source2<T>(value:T):Box<T> { console.log('source',2); return new Box(value); }
class M2 implements Maker { make<T>(value:T):Box<T> { console.log('method',2); return new Box(value); } }
function use2(receiver:Maker):void { const box:Box<C2>=receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag=3; }
function source3<T>(value:T):Box<T> { console.log('source',3); return new Box(value); }
class M3 implements Maker { make<T>(value:T):Box<T> { console.log('method',3); return new Box(value); } }
function use3(receiver:Maker):void { const box:Box<C3>=receiver.make(new C3()); console.log(box.value.tag); }
class C4 { tag=4; }
function source4<T>(value:T):Box<T> { console.log('source',4); return new Box(value); }
class M4 implements Maker { make<T>(value:T):Box<T> { console.log('method',4); return new Box(value); } }
function use4(receiver:Maker):void { const box:Box<C4>=receiver.make(new C4()); console.log(box.value.tag); }
class C5 { tag=5; }
function source5<T>(value:T):Box<T> { console.log('source',5); return new Box(value); }
class M5 implements Maker { make<T>(value:T):Box<T> { console.log('method',5); return new Box(value); } }
function use5(receiver:Maker):void { const box:Box<C5>=receiver.make(new C5()); console.log(box.value.tag); }
class C6 { tag=6; }
function source6<T>(value:T):Box<T> { console.log('source',6); return new Box(value); }
class M6 implements Maker { make<T>(value:T):Box<T> { console.log('method',6); return new Box(value); } }
function use6(receiver:Maker):void { const box:Box<C6>=receiver.make(new C6()); console.log(box.value.tag); }
class C7 { tag=7; }
function source7<T>(value:T):Box<T> { console.log('source',7); return new Box(value); }
class M7 implements Maker { make<T>(value:T):Box<T> { console.log('method',7); return new Box(value); } }
function use7(receiver:Maker):void { const box:Box<C7>=receiver.make(new C7()); console.log(box.value.tag); }
class C8 { tag=8; }
function source8<T>(value:T):Box<T> { console.log('source',8); return new Box(value); }
class M8 implements Maker { make<T>(value:T):Box<T> { console.log('method',8); return new Box(value); } }
function use8(receiver:Maker):void { const box:Box<C8>=receiver.make(new C8()); console.log(box.value.tag); }
class C9 { tag=9; }
function source9<T>(value:T):Box<T> { console.log('source',9); return new Box(value); }
class M9 implements Maker { make<T>(value:T):Box<T> { console.log('method',9); return new Box(value); } }
function use9(receiver:Maker):void { const box:Box<C9>=receiver.make(new C9()); console.log(box.value.tag); }
class C10 { tag=10; }
function source10<T>(value:T):Box<T> { console.log('source',10); return new Box(value); }
class M10 implements Maker { make<T>(value:T):Box<T> { console.log('method',10); return new Box(value); } }
function use10(receiver:Maker):void { const box:Box<C10>=receiver.make(new C10()); console.log(box.value.tag); }
class C11 { tag=11; }
function source11<T>(value:T):Box<T> { console.log('source',11); return new Box(value); }
class M11 implements Maker { make<T>(value:T):Box<T> { console.log('method',11); return new Box(value); } }
function use11(receiver:Maker):void { const box:Box<C11>=receiver.make(new C11()); console.log(box.value.tag); }
class C12 { tag=12; }
function source12<T>(value:T):Box<T> { console.log('source',12); return new Box(value); }
class M12 implements Maker { make<T>(value:T):Box<T> { console.log('method',12); return new Box(value); } }
function use12(receiver:Maker):void { const box:Box<C12>=receiver.make(new C12()); console.log(box.value.tag); }
class C13 { tag=13; }
function source13<T>(value:T):Box<T> { console.log('source',13); return new Box(value); }
class M13 implements Maker { make<T>(value:T):Box<T> { console.log('method',13); return new Box(value); } }
function use13(receiver:Maker):void { const box:Box<C13>=receiver.make(new C13()); console.log(box.value.tag); }
class C14 { tag=14; }
function source14<T>(value:T):Box<T> { console.log('source',14); return new Box(value); }
class M14 implements Maker { make<T>(value:T):Box<T> { console.log('method',14); return new Box(value); } }
function use14(receiver:Maker):void { const box:Box<C14>=receiver.make(new C14()); console.log(box.value.tag); }
class C15 { tag=15; }
function source15<T>(value:T):Box<T> { console.log('source',15); return new Box(value); }
class M15 implements Maker { make<T>(value:T):Box<T> { console.log('method',15); return new Box(value); } }
function use15(receiver:Maker):void { const box:Box<C15>=receiver.make(new C15()); console.log(box.value.tag); }
class C16 { tag=16; }
function source16<T>(value:T):Box<T> { console.log('source',16); return new Box(value); }
class M16 implements Maker { make<T>(value:T):Box<T> { console.log('method',16); return new Box(value); } }
function use16(receiver:Maker):void { const box:Box<C16>=receiver.make(new C16()); console.log(box.value.tag); }
class C17 { tag=17; }
function source17<T>(value:T):Box<T> { console.log('source',17); return new Box(value); }
class M17 implements Maker { make<T>(value:T):Box<T> { console.log('method',17); return new Box(value); } }
function use17(receiver:Maker):void { const box:Box<C17>=receiver.make(new C17()); console.log(box.value.tag); }
class C18 { tag=18; }
function source18<T>(value:T):Box<T> { console.log('source',18); return new Box(value); }
class M18 implements Maker { make<T>(value:T):Box<T> { console.log('method',18); return new Box(value); } }
function use18(receiver:Maker):void { const box:Box<C18>=receiver.make(new C18()); console.log(box.value.tag); }
class C19 { tag=19; }
function source19<T>(value:T):Box<T> { console.log('source',19); return new Box(value); }
class M19 implements Maker { make<T>(value:T):Box<T> { console.log('method',19); return new Box(value); } }
function use19(receiver:Maker):void { const box:Box<C19>=receiver.make(new C19()); console.log(box.value.tag); }
class C20 { tag=20; }
function source20<T>(value:T):Box<T> { console.log('source',20); return new Box(value); }
class M20 implements Maker { make<T>(value:T):Box<T> { console.log('method',20); return new Box(value); } }
function use20(receiver:Maker):void { const box:Box<C20>=receiver.make(new C20()); console.log(box.value.tag); }
class C21 { tag=21; }
function source21<T>(value:T):Box<T> { console.log('source',21); return new Box(value); }
class M21 implements Maker { make<T>(value:T):Box<T> { console.log('method',21); return new Box(value); } }
function use21(receiver:Maker):void { const box:Box<C21>=receiver.make(new C21()); console.log(box.value.tag); }
class C22 { tag=22; }
function source22<T>(value:T):Box<T> { console.log('source',22); return new Box(value); }
class M22 implements Maker { make<T>(value:T):Box<T> { console.log('method',22); return new Box(value); } }
function use22(receiver:Maker):void { const box:Box<C22>=receiver.make(new C22()); console.log(box.value.tag); }
class C23 { tag=23; }
function source23<T>(value:T):Box<T> { console.log('source',23); return new Box(value); }
class M23 implements Maker { make<T>(value:T):Box<T> { console.log('method',23); return new Box(value); } }
function use23(receiver:Maker):void { const box:Box<C23>=receiver.make(new C23()); console.log(box.value.tag); }
class C24 { tag=24; }
function source24<T>(value:T):Box<T> { console.log('source',24); return new Box(value); }
class M24 implements Maker { make<T>(value:T):Box<T> { console.log('method',24); return new Box(value); } }
function use24(receiver:Maker):void { const box:Box<C24>=receiver.make(new C24()); console.log(box.value.tag); }
class C25 { tag=25; }
function source25<T>(value:T):Box<T> { console.log('source',25); return new Box(value); }
class M25 implements Maker { make<T>(value:T):Box<T> { console.log('method',25); return new Box(value); } }
function use25(receiver:Maker):void { const box:Box<C25>=receiver.make(new C25()); console.log(box.value.tag); }
class C26 { tag=26; }
function source26<T>(value:T):Box<T> { console.log('source',26); return new Box(value); }
class M26 implements Maker { make<T>(value:T):Box<T> { console.log('method',26); return new Box(value); } }
function use26(receiver:Maker):void { const box:Box<C26>=receiver.make(new C26()); console.log(box.value.tag); }
class C27 { tag=27; }
function source27<T>(value:T):Box<T> { console.log('source',27); return new Box(value); }
class M27 implements Maker { make<T>(value:T):Box<T> { console.log('method',27); return new Box(value); } }
function use27(receiver:Maker):void { const box:Box<C27>=receiver.make(new C27()); console.log(box.value.tag); }
class C28 { tag=28; }
function source28<T>(value:T):Box<T> { console.log('source',28); return new Box(value); }
class M28 implements Maker { make<T>(value:T):Box<T> { console.log('method',28); return new Box(value); } }
function use28(receiver:Maker):void { const box:Box<C28>=receiver.make(new C28()); console.log(box.value.tag); }
class C29 { tag=29; }
function source29<T>(value:T):Box<T> { console.log('source',29); return new Box(value); }
class M29 implements Maker { make<T>(value:T):Box<T> { console.log('method',29); return new Box(value); } }
function use29(receiver:Maker):void { const box:Box<C29>=receiver.make(new C29()); console.log(box.value.tag); }
class C30 { tag=30; }
function source30<T>(value:T):Box<T> { console.log('source',30); return new Box(value); }
class M30 implements Maker { make<T>(value:T):Box<T> { console.log('method',30); return new Box(value); } }
function use30(receiver:Maker):void { const box:Box<C30>=receiver.make(new C30()); console.log(box.value.tag); }
class C31 { tag=31; }
function source31<T>(value:T):Box<T> { console.log('source',31); return new Box(value); }
class M31 implements Maker { make<T>(value:T):Box<T> { console.log('method',31); return new Box(value); } }
function use31(receiver:Maker):void { const box:Box<C31>=receiver.make(new C31()); console.log(box.value.tag); }
class C32 { tag=32; }
function source32<T>(value:T):Box<T> { console.log('source',32); return new Box(value); }
class M32 implements Maker { make<T>(value:T):Box<T> { console.log('method',32); return new Box(value); } }
function use32(receiver:Maker):void { const box:Box<C32>=receiver.make(new C32()); console.log(box.value.tag); }
class C33 { tag=33; }
function source33<T>(value:T):Box<T> { console.log('source',33); return new Box(value); }
class M33 implements Maker { make<T>(value:T):Box<T> { console.log('method',33); return new Box(value); } }
function use33(receiver:Maker):void { const box:Box<C33>=receiver.make(new C33()); console.log(box.value.tag); }
class C34 { tag=34; }
function source34<T>(value:T):Box<T> { console.log('source',34); return new Box(value); }
class M34 implements Maker { make<T>(value:T):Box<T> { console.log('method',34); return new Box(value); } }
function use34(receiver:Maker):void { const box:Box<C34>=receiver.make(new C34()); console.log(box.value.tag); }
class C35 { tag=35; }
function source35<T>(value:T):Box<T> { console.log('source',35); return new Box(value); }
class M35 implements Maker { make<T>(value:T):Box<T> { console.log('method',35); return new Box(value); } }
function use35(receiver:Maker):void { const box:Box<C35>=receiver.make(new C35()); console.log(box.value.tag); }
class C36 { tag=36; }
function source36<T>(value:T):Box<T> { console.log('source',36); return new Box(value); }
class M36 implements Maker { make<T>(value:T):Box<T> { console.log('method',36); return new Box(value); } }
function use36(receiver:Maker):void { const box:Box<C36>=receiver.make(new C36()); console.log(box.value.tag); }
class C37 { tag=37; }
function source37<T>(value:T):Box<T> { console.log('source',37); return new Box(value); }
class M37 implements Maker { make<T>(value:T):Box<T> { console.log('method',37); return new Box(value); } }
function use37(receiver:Maker):void { const box:Box<C37>=receiver.make(new C37()); console.log(box.value.tag); }
class C38 { tag=38; }
function source38<T>(value:T):Box<T> { console.log('source',38); return new Box(value); }
class M38 implements Maker { make<T>(value:T):Box<T> { console.log('method',38); return new Box(value); } }
function use38(receiver:Maker):void { const box:Box<C38>=receiver.make(new C38()); console.log(box.value.tag); }
class C39 { tag=39; }
function source39<T>(value:T):Box<T> { console.log('source',39); return new Box(value); }
class M39 implements Maker { make<T>(value:T):Box<T> { console.log('method',39); return new Box(value); } }
function use39(receiver:Maker):void { const box:Box<C39>=receiver.make(new C39()); console.log(box.value.tag); }
class C40 { tag=40; }
function source40<T>(value:T):Box<T> { console.log('source',40); return new Box(value); }
class M40 implements Maker { make<T>(value:T):Box<T> { console.log('method',40); return new Box(value); } }
function use40(receiver:Maker):void { const box:Box<C40>=receiver.make(new C40()); console.log(box.value.tag); }
class C41 { tag=41; }
function source41<T>(value:T):Box<T> { console.log('source',41); return new Box(value); }
class M41 implements Maker { make<T>(value:T):Box<T> { console.log('method',41); return new Box(value); } }
function use41(receiver:Maker):void { const box:Box<C41>=receiver.make(new C41()); console.log(box.value.tag); }
class C42 { tag=42; }
function source42<T>(value:T):Box<T> { console.log('source',42); return new Box(value); }
class M42 implements Maker { make<T>(value:T):Box<T> { console.log('method',42); return new Box(value); } }
function use42(receiver:Maker):void { const box:Box<C42>=receiver.make(new C42()); console.log(box.value.tag); }
class C43 { tag=43; }
function source43<T>(value:T):Box<T> { console.log('source',43); return new Box(value); }
class M43 implements Maker { make<T>(value:T):Box<T> { console.log('method',43); return new Box(value); } }
function use43(receiver:Maker):void { const box:Box<C43>=receiver.make(new C43()); console.log(box.value.tag); }
class C44 { tag=44; }
function source44<T>(value:T):Box<T> { console.log('source',44); return new Box(value); }
class M44 implements Maker { make<T>(value:T):Box<T> { console.log('method',44); return new Box(value); } }
function use44(receiver:Maker):void { const box:Box<C44>=receiver.make(new C44()); console.log(box.value.tag); }
class C45 { tag=45; }
function source45<T>(value:T):Box<T> { console.log('source',45); return new Box(value); }
class M45 implements Maker { make<T>(value:T):Box<T> { console.log('method',45); return new Box(value); } }
function use45(receiver:Maker):void { const box:Box<C45>=receiver.make(new C45()); console.log(box.value.tag); }
class C46 { tag=46; }
function source46<T>(value:T):Box<T> { console.log('source',46); return new Box(value); }
class M46 implements Maker { make<T>(value:T):Box<T> { console.log('method',46); return new Box(value); } }
function use46(receiver:Maker):void { const box:Box<C46>=receiver.make(new C46()); console.log(box.value.tag); }
class C47 { tag=47; }
function source47<T>(value:T):Box<T> { console.log('source',47); return new Box(value); }
class M47 implements Maker { make<T>(value:T):Box<T> { console.log('method',47); return new Box(value); } }
function use47(receiver:Maker):void { const box:Box<C47>=receiver.make(new C47()); console.log(box.value.tag); }
class C48 { tag=48; }
function source48<T>(value:T):Box<T> { console.log('source',48); return new Box(value); }
class M48 implements Maker { make<T>(value:T):Box<T> { console.log('method',48); return new Box(value); } }
function use48(receiver:Maker):void { const box:Box<C48>=receiver.make(new C48()); console.log(box.value.tag); }
class C49 { tag=49; }
function source49<T>(value:T):Box<T> { console.log('source',49); return new Box(value); }
class M49 implements Maker { make<T>(value:T):Box<T> { console.log('method',49); return new Box(value); } }
function use49(receiver:Maker):void { const box:Box<C49>=receiver.make(new C49()); console.log(box.value.tag); }
class C50 { tag=50; }
function source50<T>(value:T):Box<T> { console.log('source',50); return new Box(value); }
class M50 implements Maker { make<T>(value:T):Box<T> { console.log('method',50); return new Box(value); } }
function use50(receiver:Maker):void { const box:Box<C50>=receiver.make(new C50()); console.log(box.value.tag); }
class C51 { tag=51; }
function source51<T>(value:T):Box<T> { console.log('source',51); return new Box(value); }
class M51 implements Maker { make<T>(value:T):Box<T> { console.log('method',51); return new Box(value); } }
function use51(receiver:Maker):void { const box:Box<C51>=receiver.make(new C51()); console.log(box.value.tag); }
class C52 { tag=52; }
function source52<T>(value:T):Box<T> { console.log('source',52); return new Box(value); }
class M52 implements Maker { make<T>(value:T):Box<T> { console.log('method',52); return new Box(value); } }
function use52(receiver:Maker):void { const box:Box<C52>=receiver.make(new C52()); console.log(box.value.tag); }
class C53 { tag=53; }
function source53<T>(value:T):Box<T> { console.log('source',53); return new Box(value); }
class M53 implements Maker { make<T>(value:T):Box<T> { console.log('method',53); return new Box(value); } }
function use53(receiver:Maker):void { const box:Box<C53>=receiver.make(new C53()); console.log(box.value.tag); }
class C54 { tag=54; }
function source54<T>(value:T):Box<T> { console.log('source',54); return new Box(value); }
class M54 implements Maker { make<T>(value:T):Box<T> { console.log('method',54); return new Box(value); } }
function use54(receiver:Maker):void { const box:Box<C54>=receiver.make(new C54()); console.log(box.value.tag); }
class C55 { tag=55; }
function source55<T>(value:T):Box<T> { console.log('source',55); return new Box(value); }
class M55 implements Maker { make<T>(value:T):Box<T> { console.log('method',55); return new Box(value); } }
function use55(receiver:Maker):void { const box:Box<C55>=receiver.make(new C55()); console.log(box.value.tag); }
class C56 { tag=56; }
function source56<T>(value:T):Box<T> { console.log('source',56); return new Box(value); }
class M56 implements Maker { make<T>(value:T):Box<T> { console.log('method',56); return new Box(value); } }
function use56(receiver:Maker):void { const box:Box<C56>=receiver.make(new C56()); console.log(box.value.tag); }
class C57 { tag=57; }
function source57<T>(value:T):Box<T> { console.log('source',57); return new Box(value); }
class M57 implements Maker { make<T>(value:T):Box<T> { console.log('method',57); return new Box(value); } }
function use57(receiver:Maker):void { const box:Box<C57>=receiver.make(new C57()); console.log(box.value.tag); }
class C58 { tag=58; }
function source58<T>(value:T):Box<T> { console.log('source',58); return new Box(value); }
class M58 implements Maker { make<T>(value:T):Box<T> { console.log('method',58); return new Box(value); } }
function use58(receiver:Maker):void { const box:Box<C58>=receiver.make(new C58()); console.log(box.value.tag); }
class C59 { tag=59; }
function source59<T>(value:T):Box<T> { console.log('source',59); return new Box(value); }
class M59 implements Maker { make<T>(value:T):Box<T> { console.log('method',59); return new Box(value); } }
function use59(receiver:Maker):void { const box:Box<C59>=receiver.make(new C59()); console.log(box.value.tag); }
const root0:{value:Maker}={value:new M0()};
const alias0=(root0); const leaf0=alias0; const sibling0=root0; const spare0=sibling0.value;
use0(leaf0.value);
const root1:{value:Maker}={value:new M1()};
const alias1=(root1); const leaf1=alias1; const sibling1=root1; const spare1=sibling1.value;
use1(leaf1.value);
const root2:{value:Maker}={value:new M2()};
const alias2=(root2); const leaf2=alias2; const sibling2=root2; const spare2=sibling2.value;
use2(leaf2.value);
const root3:{value:Maker}={value:new M3()};
const alias3=(root3); const leaf3=alias3; const sibling3=root3; const spare3=sibling3.value;
use3(leaf3.value);
const root4:{value:Maker}={value:new M4()};
const alias4=(root4); const leaf4=alias4; const sibling4=root4; const spare4=sibling4.value;
use4(leaf4.value);
const root5:{value:Maker}={value:new M5()};
const alias5=(root5); const leaf5=alias5; const sibling5=root5; const spare5=sibling5.value;
use5(leaf5.value);
const root6:{value:Maker}={value:new M6()};
const alias6=(root6); const leaf6=alias6; const sibling6=root6; const spare6=sibling6.value;
use6(leaf6.value);
const root7:{value:Maker}={value:new M7()};
const alias7=(root7); const leaf7=alias7; const sibling7=root7; const spare7=sibling7.value;
use7(leaf7.value);
const root8:{value:Maker}={value:new M8()};
const alias8=(root8); const leaf8=alias8; const sibling8=root8; const spare8=sibling8.value;
use8(leaf8.value);
const root9:{value:Maker}={value:new M9()};
const alias9=(root9); const leaf9=alias9; const sibling9=root9; const spare9=sibling9.value;
use9(leaf9.value);
const root10:{value:Maker}={value:new M10()};
const alias10=(root10); const leaf10=alias10; const sibling10=root10; const spare10=sibling10.value;
use10(leaf10.value);
const root11:{value:Maker}={value:new M11()};
const alias11=(root11); const leaf11=alias11; const sibling11=root11; const spare11=sibling11.value;
use11(leaf11.value);
const root12:{value:Maker}={value:new M12()};
const alias12=(root12); const leaf12=alias12; const sibling12=root12; const spare12=sibling12.value;
use12(leaf12.value);
const root13:{value:Maker}={value:new M13()};
const alias13=(root13); const leaf13=alias13; const sibling13=root13; const spare13=sibling13.value;
use13(leaf13.value);
const root14:{value:Maker}={value:new M14()};
const alias14=(root14); const leaf14=alias14; const sibling14=root14; const spare14=sibling14.value;
use14(leaf14.value);
const root15:{value:Maker}={value:new M15()};
const alias15=(root15); const leaf15=alias15; const sibling15=root15; const spare15=sibling15.value;
use15(leaf15.value);
const root16:{value:Maker}={value:new M16()};
const alias16=(root16); const leaf16=alias16; const sibling16=root16; const spare16=sibling16.value;
use16(leaf16.value);
const root17:{value:Maker}={value:new M17()};
const alias17=(root17); const leaf17=alias17; const sibling17=root17; const spare17=sibling17.value;
use17(leaf17.value);
const root18:{value:Maker}={value:new M18()};
const alias18=(root18); const leaf18=alias18; const sibling18=root18; const spare18=sibling18.value;
use18(leaf18.value);
const root19:{value:Maker}={value:new M19()};
const alias19=(root19); const leaf19=alias19; const sibling19=root19; const spare19=sibling19.value;
use19(leaf19.value);
const root20:{value:Maker}={value:new M20()};
const alias20=(root20); const leaf20=alias20; const sibling20=root20; const spare20=sibling20.value;
use20(leaf20.value);
const root21:{value:Maker}={value:new M21()};
const alias21=(root21); const leaf21=alias21; const sibling21=root21; const spare21=sibling21.value;
use21(leaf21.value);
const root22:{value:Maker}={value:new M22()};
const alias22=(root22); const leaf22=alias22; const sibling22=root22; const spare22=sibling22.value;
use22(leaf22.value);
const root23:{value:Maker}={value:new M23()};
const alias23=(root23); const leaf23=alias23; const sibling23=root23; const spare23=sibling23.value;
use23(leaf23.value);
const root24:{value:Maker}={value:new M24()};
const alias24=(root24); const leaf24=alias24; const sibling24=root24; const spare24=sibling24.value;
use24(leaf24.value);
const root25:{value:Maker}={value:new M25()};
const alias25=(root25); const leaf25=alias25; const sibling25=root25; const spare25=sibling25.value;
use25(leaf25.value);
const root26:{value:Maker}={value:new M26()};
const alias26=(root26); const leaf26=alias26; const sibling26=root26; const spare26=sibling26.value;
use26(leaf26.value);
const root27:{value:Maker}={value:new M27()};
const alias27=(root27); const leaf27=alias27; const sibling27=root27; const spare27=sibling27.value;
use27(leaf27.value);
const root28:{value:Maker}={value:new M28()};
const alias28=(root28); const leaf28=alias28; const sibling28=root28; const spare28=sibling28.value;
use28(leaf28.value);
const root29:{value:Maker}={value:new M29()};
const alias29=(root29); const leaf29=alias29; const sibling29=root29; const spare29=sibling29.value;
use29(leaf29.value);
const root30:{value:Maker}={value:new M30()};
const alias30=(root30); const leaf30=alias30; const sibling30=root30; const spare30=sibling30.value;
use30(leaf30.value);
const root31:{value:Maker}={value:new M31()};
const alias31=(root31); const leaf31=alias31; const sibling31=root31; const spare31=sibling31.value;
use31(leaf31.value);
const root32:{value:Maker}={value:new M32()};
const alias32=(root32); const leaf32=alias32; const sibling32=root32; const spare32=sibling32.value;
use32(leaf32.value);
const root33:{value:Maker}={value:new M33()};
const alias33=(root33); const leaf33=alias33; const sibling33=root33; const spare33=sibling33.value;
use33(leaf33.value);
const root34:{value:Maker}={value:new M34()};
const alias34=(root34); const leaf34=alias34; const sibling34=root34; const spare34=sibling34.value;
use34(leaf34.value);
const root35:{value:Maker}={value:new M35()};
const alias35=(root35); const leaf35=alias35; const sibling35=root35; const spare35=sibling35.value;
use35(leaf35.value);
const root36:{value:Maker}={value:new M36()};
const alias36=(root36); const leaf36=alias36; const sibling36=root36; const spare36=sibling36.value;
use36(leaf36.value);
const root37:{value:Maker}={value:new M37()};
const alias37=(root37); const leaf37=alias37; const sibling37=root37; const spare37=sibling37.value;
use37(leaf37.value);
const root38:{value:Maker}={value:new M38()};
const alias38=(root38); const leaf38=alias38; const sibling38=root38; const spare38=sibling38.value;
use38(leaf38.value);
const root39:{value:Maker}={value:new M39()};
const alias39=(root39); const leaf39=alias39; const sibling39=root39; const spare39=sibling39.value;
use39(leaf39.value);
const root40:{value:Maker}={value:new M40()};
const alias40=(root40); const leaf40=alias40; const sibling40=root40; const spare40=sibling40.value;
use40(leaf40.value);
const root41:{value:Maker}={value:new M41()};
const alias41=(root41); const leaf41=alias41; const sibling41=root41; const spare41=sibling41.value;
use41(leaf41.value);
const root42:{value:Maker}={value:new M42()};
const alias42=(root42); const leaf42=alias42; const sibling42=root42; const spare42=sibling42.value;
use42(leaf42.value);
const root43:{value:Maker}={value:new M43()};
const alias43=(root43); const leaf43=alias43; const sibling43=root43; const spare43=sibling43.value;
use43(leaf43.value);
const root44:{value:Maker}={value:new M44()};
const alias44=(root44); const leaf44=alias44; const sibling44=root44; const spare44=sibling44.value;
use44(leaf44.value);
const root45:{value:Maker}={value:new M45()};
const alias45=(root45); const leaf45=alias45; const sibling45=root45; const spare45=sibling45.value;
use45(leaf45.value);
const root46:{value:Maker}={value:new M46()};
const alias46=(root46); const leaf46=alias46; const sibling46=root46; const spare46=sibling46.value;
use46(leaf46.value);
const root47:{value:Maker}={value:new M47()};
const alias47=(root47); const leaf47=alias47; const sibling47=root47; const spare47=sibling47.value;
use47(leaf47.value);
const root48:{value:Maker}={value:new M48()};
const alias48=(root48); const leaf48=alias48; const sibling48=root48; const spare48=sibling48.value;
use48(leaf48.value);
const root49:{value:Maker}={value:new M49()};
const alias49=(root49); const leaf49=alias49; const sibling49=root49; const spare49=sibling49.value;
use49(leaf49.value);
const root50:{value:Maker}={value:new M50()};
const alias50=(root50); const leaf50=alias50; const sibling50=root50; const spare50=sibling50.value;
use50(leaf50.value);
const root51:{value:Maker}={value:new M51()};
const alias51=(root51); const leaf51=alias51; const sibling51=root51; const spare51=sibling51.value;
use51(leaf51.value);
const root52:{value:Maker}={value:new M52()};
const alias52=(root52); const leaf52=alias52; const sibling52=root52; const spare52=sibling52.value;
use52(leaf52.value);
const root53:{value:Maker}={value:new M53()};
const alias53=(root53); const leaf53=alias53; const sibling53=root53; const spare53=sibling53.value;
use53(leaf53.value);
const root54:{value:Maker}={value:new M54()};
const alias54=(root54); const leaf54=alias54; const sibling54=root54; const spare54=sibling54.value;
use54(leaf54.value);
const root55:{value:Maker}={value:new M55()};
const alias55=(root55); const leaf55=alias55; const sibling55=root55; const spare55=sibling55.value;
use55(leaf55.value);
const root56:{value:Maker}={value:new M56()};
const alias56=(root56); const leaf56=alias56; const sibling56=root56; const spare56=sibling56.value;
use56(leaf56.value);
const root57:{value:Maker}={value:new M57()};
const alias57=(root57); const leaf57=alias57; const sibling57=root57; const spare57=sibling57.value;
use57(leaf57.value);
const root58:{value:Maker}={value:new M58()};
const alias58=(root58); const leaf58=alias58; const sibling58=root58; const spare58=sibling58.value;
use58(leaf58.value);
const root59:{value:Maker}={value:new M59()};
const alias59=(root59); const leaf59=alias59; const sibling59=root59; const spare59=sibling59.value;
use59(leaf59.value);
