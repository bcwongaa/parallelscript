class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T> { console.log('source',0); return new Box(value); }
class M0 implements Maker { make<T>(value:T):Box<T> { console.log('method',0); return new Box(value); } }
function use0(factory:Factory):void { const box:Box<C0>=factory(new C0()); console.log(box.value.tag); }
function read0(receiver:Maker):Factory { return receiver.make; }
class C1 { tag=1; }
function source1<T>(value:T):Box<T> { console.log('source',1); return new Box(value); }
class M1 implements Maker { make<T>(value:T):Box<T> { console.log('method',1); return new Box(value); } }
function use1(factory:Factory):void { const box:Box<C1>=factory(new C1()); console.log(box.value.tag); }
function read1(receiver:Maker):Factory { return receiver.make; }
class C2 { tag=2; }
function source2<T>(value:T):Box<T> { console.log('source',2); return new Box(value); }
class M2 implements Maker { make<T>(value:T):Box<T> { console.log('method',2); return new Box(value); } }
function use2(factory:Factory):void { const box:Box<C2>=factory(new C2()); console.log(box.value.tag); }
function read2(receiver:Maker):Factory { return receiver.make; }
class C3 { tag=3; }
function source3<T>(value:T):Box<T> { console.log('source',3); return new Box(value); }
class M3 implements Maker { make<T>(value:T):Box<T> { console.log('method',3); return new Box(value); } }
function use3(factory:Factory):void { const box:Box<C3>=factory(new C3()); console.log(box.value.tag); }
function read3(receiver:Maker):Factory { return receiver.make; }
class C4 { tag=4; }
function source4<T>(value:T):Box<T> { console.log('source',4); return new Box(value); }
class M4 implements Maker { make<T>(value:T):Box<T> { console.log('method',4); return new Box(value); } }
function use4(factory:Factory):void { const box:Box<C4>=factory(new C4()); console.log(box.value.tag); }
function read4(receiver:Maker):Factory { return receiver.make; }
class C5 { tag=5; }
function source5<T>(value:T):Box<T> { console.log('source',5); return new Box(value); }
class M5 implements Maker { make<T>(value:T):Box<T> { console.log('method',5); return new Box(value); } }
function use5(factory:Factory):void { const box:Box<C5>=factory(new C5()); console.log(box.value.tag); }
function read5(receiver:Maker):Factory { return receiver.make; }
class C6 { tag=6; }
function source6<T>(value:T):Box<T> { console.log('source',6); return new Box(value); }
class M6 implements Maker { make<T>(value:T):Box<T> { console.log('method',6); return new Box(value); } }
function use6(factory:Factory):void { const box:Box<C6>=factory(new C6()); console.log(box.value.tag); }
function read6(receiver:Maker):Factory { return receiver.make; }
class C7 { tag=7; }
function source7<T>(value:T):Box<T> { console.log('source',7); return new Box(value); }
class M7 implements Maker { make<T>(value:T):Box<T> { console.log('method',7); return new Box(value); } }
function use7(factory:Factory):void { const box:Box<C7>=factory(new C7()); console.log(box.value.tag); }
function read7(receiver:Maker):Factory { return receiver.make; }
class C8 { tag=8; }
function source8<T>(value:T):Box<T> { console.log('source',8); return new Box(value); }
class M8 implements Maker { make<T>(value:T):Box<T> { console.log('method',8); return new Box(value); } }
function use8(factory:Factory):void { const box:Box<C8>=factory(new C8()); console.log(box.value.tag); }
function read8(receiver:Maker):Factory { return receiver.make; }
class C9 { tag=9; }
function source9<T>(value:T):Box<T> { console.log('source',9); return new Box(value); }
class M9 implements Maker { make<T>(value:T):Box<T> { console.log('method',9); return new Box(value); } }
function use9(factory:Factory):void { const box:Box<C9>=factory(new C9()); console.log(box.value.tag); }
function read9(receiver:Maker):Factory { return receiver.make; }
class C10 { tag=10; }
function source10<T>(value:T):Box<T> { console.log('source',10); return new Box(value); }
class M10 implements Maker { make<T>(value:T):Box<T> { console.log('method',10); return new Box(value); } }
function use10(factory:Factory):void { const box:Box<C10>=factory(new C10()); console.log(box.value.tag); }
function read10(receiver:Maker):Factory { return receiver.make; }
class C11 { tag=11; }
function source11<T>(value:T):Box<T> { console.log('source',11); return new Box(value); }
class M11 implements Maker { make<T>(value:T):Box<T> { console.log('method',11); return new Box(value); } }
function use11(factory:Factory):void { const box:Box<C11>=factory(new C11()); console.log(box.value.tag); }
function read11(receiver:Maker):Factory { return receiver.make; }
class C12 { tag=12; }
function source12<T>(value:T):Box<T> { console.log('source',12); return new Box(value); }
class M12 implements Maker { make<T>(value:T):Box<T> { console.log('method',12); return new Box(value); } }
function use12(factory:Factory):void { const box:Box<C12>=factory(new C12()); console.log(box.value.tag); }
function read12(receiver:Maker):Factory { return receiver.make; }
class C13 { tag=13; }
function source13<T>(value:T):Box<T> { console.log('source',13); return new Box(value); }
class M13 implements Maker { make<T>(value:T):Box<T> { console.log('method',13); return new Box(value); } }
function use13(factory:Factory):void { const box:Box<C13>=factory(new C13()); console.log(box.value.tag); }
function read13(receiver:Maker):Factory { return receiver.make; }
class C14 { tag=14; }
function source14<T>(value:T):Box<T> { console.log('source',14); return new Box(value); }
class M14 implements Maker { make<T>(value:T):Box<T> { console.log('method',14); return new Box(value); } }
function use14(factory:Factory):void { const box:Box<C14>=factory(new C14()); console.log(box.value.tag); }
function read14(receiver:Maker):Factory { return receiver.make; }
class C15 { tag=15; }
function source15<T>(value:T):Box<T> { console.log('source',15); return new Box(value); }
class M15 implements Maker { make<T>(value:T):Box<T> { console.log('method',15); return new Box(value); } }
function use15(factory:Factory):void { const box:Box<C15>=factory(new C15()); console.log(box.value.tag); }
function read15(receiver:Maker):Factory { return receiver.make; }
class C16 { tag=16; }
function source16<T>(value:T):Box<T> { console.log('source',16); return new Box(value); }
class M16 implements Maker { make<T>(value:T):Box<T> { console.log('method',16); return new Box(value); } }
function use16(factory:Factory):void { const box:Box<C16>=factory(new C16()); console.log(box.value.tag); }
function read16(receiver:Maker):Factory { return receiver.make; }
class C17 { tag=17; }
function source17<T>(value:T):Box<T> { console.log('source',17); return new Box(value); }
class M17 implements Maker { make<T>(value:T):Box<T> { console.log('method',17); return new Box(value); } }
function use17(factory:Factory):void { const box:Box<C17>=factory(new C17()); console.log(box.value.tag); }
function read17(receiver:Maker):Factory { return receiver.make; }
class C18 { tag=18; }
function source18<T>(value:T):Box<T> { console.log('source',18); return new Box(value); }
class M18 implements Maker { make<T>(value:T):Box<T> { console.log('method',18); return new Box(value); } }
function use18(factory:Factory):void { const box:Box<C18>=factory(new C18()); console.log(box.value.tag); }
function read18(receiver:Maker):Factory { return receiver.make; }
class C19 { tag=19; }
function source19<T>(value:T):Box<T> { console.log('source',19); return new Box(value); }
class M19 implements Maker { make<T>(value:T):Box<T> { console.log('method',19); return new Box(value); } }
function use19(factory:Factory):void { const box:Box<C19>=factory(new C19()); console.log(box.value.tag); }
function read19(receiver:Maker):Factory { return receiver.make; }
class C20 { tag=20; }
function source20<T>(value:T):Box<T> { console.log('source',20); return new Box(value); }
class M20 implements Maker { make<T>(value:T):Box<T> { console.log('method',20); return new Box(value); } }
function use20(factory:Factory):void { const box:Box<C20>=factory(new C20()); console.log(box.value.tag); }
function read20(receiver:Maker):Factory { return receiver.make; }
class C21 { tag=21; }
function source21<T>(value:T):Box<T> { console.log('source',21); return new Box(value); }
class M21 implements Maker { make<T>(value:T):Box<T> { console.log('method',21); return new Box(value); } }
function use21(factory:Factory):void { const box:Box<C21>=factory(new C21()); console.log(box.value.tag); }
function read21(receiver:Maker):Factory { return receiver.make; }
class C22 { tag=22; }
function source22<T>(value:T):Box<T> { console.log('source',22); return new Box(value); }
class M22 implements Maker { make<T>(value:T):Box<T> { console.log('method',22); return new Box(value); } }
function use22(factory:Factory):void { const box:Box<C22>=factory(new C22()); console.log(box.value.tag); }
function read22(receiver:Maker):Factory { return receiver.make; }
class C23 { tag=23; }
function source23<T>(value:T):Box<T> { console.log('source',23); return new Box(value); }
class M23 implements Maker { make<T>(value:T):Box<T> { console.log('method',23); return new Box(value); } }
function use23(factory:Factory):void { const box:Box<C23>=factory(new C23()); console.log(box.value.tag); }
function read23(receiver:Maker):Factory { return receiver.make; }
class C24 { tag=24; }
function source24<T>(value:T):Box<T> { console.log('source',24); return new Box(value); }
class M24 implements Maker { make<T>(value:T):Box<T> { console.log('method',24); return new Box(value); } }
function use24(factory:Factory):void { const box:Box<C24>=factory(new C24()); console.log(box.value.tag); }
function read24(receiver:Maker):Factory { return receiver.make; }
class C25 { tag=25; }
function source25<T>(value:T):Box<T> { console.log('source',25); return new Box(value); }
class M25 implements Maker { make<T>(value:T):Box<T> { console.log('method',25); return new Box(value); } }
function use25(factory:Factory):void { const box:Box<C25>=factory(new C25()); console.log(box.value.tag); }
function read25(receiver:Maker):Factory { return receiver.make; }
class C26 { tag=26; }
function source26<T>(value:T):Box<T> { console.log('source',26); return new Box(value); }
class M26 implements Maker { make<T>(value:T):Box<T> { console.log('method',26); return new Box(value); } }
function use26(factory:Factory):void { const box:Box<C26>=factory(new C26()); console.log(box.value.tag); }
function read26(receiver:Maker):Factory { return receiver.make; }
class C27 { tag=27; }
function source27<T>(value:T):Box<T> { console.log('source',27); return new Box(value); }
class M27 implements Maker { make<T>(value:T):Box<T> { console.log('method',27); return new Box(value); } }
function use27(factory:Factory):void { const box:Box<C27>=factory(new C27()); console.log(box.value.tag); }
function read27(receiver:Maker):Factory { return receiver.make; }
class C28 { tag=28; }
function source28<T>(value:T):Box<T> { console.log('source',28); return new Box(value); }
class M28 implements Maker { make<T>(value:T):Box<T> { console.log('method',28); return new Box(value); } }
function use28(factory:Factory):void { const box:Box<C28>=factory(new C28()); console.log(box.value.tag); }
function read28(receiver:Maker):Factory { return receiver.make; }
class C29 { tag=29; }
function source29<T>(value:T):Box<T> { console.log('source',29); return new Box(value); }
class M29 implements Maker { make<T>(value:T):Box<T> { console.log('method',29); return new Box(value); } }
function use29(factory:Factory):void { const box:Box<C29>=factory(new C29()); console.log(box.value.tag); }
function read29(receiver:Maker):Factory { return receiver.make; }
const root0:{value:Maker}={value:new M0()};
const alias0=(root0); const leaf0=alias0; const sibling0=root0; const spare0=sibling0.value;
use0(read0(leaf0.value));
const root1:{value:Maker}={value:new M1()};
const alias1=(root1); const leaf1=alias1; const sibling1=root1; const spare1=sibling1.value;
use1(read1(leaf1.value));
const root2:{value:Maker}={value:new M2()};
const alias2=(root2); const leaf2=alias2; const sibling2=root2; const spare2=sibling2.value;
use2(read2(leaf2.value));
const root3:{value:Maker}={value:new M3()};
const alias3=(root3); const leaf3=alias3; const sibling3=root3; const spare3=sibling3.value;
use3(read3(leaf3.value));
const root4:{value:Maker}={value:new M4()};
const alias4=(root4); const leaf4=alias4; const sibling4=root4; const spare4=sibling4.value;
use4(read4(leaf4.value));
const root5:{value:Maker}={value:new M5()};
const alias5=(root5); const leaf5=alias5; const sibling5=root5; const spare5=sibling5.value;
use5(read5(leaf5.value));
const root6:{value:Maker}={value:new M6()};
const alias6=(root6); const leaf6=alias6; const sibling6=root6; const spare6=sibling6.value;
use6(read6(leaf6.value));
const root7:{value:Maker}={value:new M7()};
const alias7=(root7); const leaf7=alias7; const sibling7=root7; const spare7=sibling7.value;
use7(read7(leaf7.value));
const root8:{value:Maker}={value:new M8()};
const alias8=(root8); const leaf8=alias8; const sibling8=root8; const spare8=sibling8.value;
use8(read8(leaf8.value));
const root9:{value:Maker}={value:new M9()};
const alias9=(root9); const leaf9=alias9; const sibling9=root9; const spare9=sibling9.value;
use9(read9(leaf9.value));
const root10:{value:Maker}={value:new M10()};
const alias10=(root10); const leaf10=alias10; const sibling10=root10; const spare10=sibling10.value;
use10(read10(leaf10.value));
const root11:{value:Maker}={value:new M11()};
const alias11=(root11); const leaf11=alias11; const sibling11=root11; const spare11=sibling11.value;
use11(read11(leaf11.value));
const root12:{value:Maker}={value:new M12()};
const alias12=(root12); const leaf12=alias12; const sibling12=root12; const spare12=sibling12.value;
use12(read12(leaf12.value));
const root13:{value:Maker}={value:new M13()};
const alias13=(root13); const leaf13=alias13; const sibling13=root13; const spare13=sibling13.value;
use13(read13(leaf13.value));
const root14:{value:Maker}={value:new M14()};
const alias14=(root14); const leaf14=alias14; const sibling14=root14; const spare14=sibling14.value;
use14(read14(leaf14.value));
const root15:{value:Maker}={value:new M15()};
const alias15=(root15); const leaf15=alias15; const sibling15=root15; const spare15=sibling15.value;
use15(read15(leaf15.value));
const root16:{value:Maker}={value:new M16()};
const alias16=(root16); const leaf16=alias16; const sibling16=root16; const spare16=sibling16.value;
use16(read16(leaf16.value));
const root17:{value:Maker}={value:new M17()};
const alias17=(root17); const leaf17=alias17; const sibling17=root17; const spare17=sibling17.value;
use17(read17(leaf17.value));
const root18:{value:Maker}={value:new M18()};
const alias18=(root18); const leaf18=alias18; const sibling18=root18; const spare18=sibling18.value;
use18(read18(leaf18.value));
const root19:{value:Maker}={value:new M19()};
const alias19=(root19); const leaf19=alias19; const sibling19=root19; const spare19=sibling19.value;
use19(read19(leaf19.value));
const root20:{value:Maker}={value:new M20()};
const alias20=(root20); const leaf20=alias20; const sibling20=root20; const spare20=sibling20.value;
use20(read20(leaf20.value));
const root21:{value:Maker}={value:new M21()};
const alias21=(root21); const leaf21=alias21; const sibling21=root21; const spare21=sibling21.value;
use21(read21(leaf21.value));
const root22:{value:Maker}={value:new M22()};
const alias22=(root22); const leaf22=alias22; const sibling22=root22; const spare22=sibling22.value;
use22(read22(leaf22.value));
const root23:{value:Maker}={value:new M23()};
const alias23=(root23); const leaf23=alias23; const sibling23=root23; const spare23=sibling23.value;
use23(read23(leaf23.value));
const root24:{value:Maker}={value:new M24()};
const alias24=(root24); const leaf24=alias24; const sibling24=root24; const spare24=sibling24.value;
use24(read24(leaf24.value));
const root25:{value:Maker}={value:new M25()};
const alias25=(root25); const leaf25=alias25; const sibling25=root25; const spare25=sibling25.value;
use25(read25(leaf25.value));
const root26:{value:Maker}={value:new M26()};
const alias26=(root26); const leaf26=alias26; const sibling26=root26; const spare26=sibling26.value;
use26(read26(leaf26.value));
const root27:{value:Maker}={value:new M27()};
const alias27=(root27); const leaf27=alias27; const sibling27=root27; const spare27=sibling27.value;
use27(read27(leaf27.value));
const root28:{value:Maker}={value:new M28()};
const alias28=(root28); const leaf28=alias28; const sibling28=root28; const spare28=sibling28.value;
use28(read28(leaf28.value));
const root29:{value:Maker}={value:new M29()};
const alias29=(root29); const leaf29=alias29; const sibling29=root29; const spare29=sibling29.value;
use29(read29(leaf29.value));
