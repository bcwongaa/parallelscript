class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T> { console.log('source',0); return new Box(value); }
class M0 implements Maker { make<T>(value:T):Box<T> { console.log('method',0); return new Box(value); } }
function use0(receiver:Maker):void { const box:Box<C0>=receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag=1; }
function source1<T>(value:T):Box<T> { console.log('source',1); return new Box(value); }
class M1 implements Maker { make<T>(value:T):Box<T> { console.log('method',1); return new Box(value); } }
function use1(receiver:Maker):void { const box:Box<C1>=receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag=2; }
function source2<T>(value:T):Box<T> { console.log('source',2); return new Box(value); }
class M2 implements Maker { make<T>(value:T):Box<T> { console.log('method',2); return new Box(value); } }
function use2(receiver:Maker):void { const box:Box<C2>=receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag=3; }
function source3<T>(value:T):Box<T> { console.log('source',3); return new Box(value); }
class M3 implements Maker { make<T>(value:T):Box<T> { console.log('method',3); return new Box(value); } }
function use3(receiver:Maker):void { const box:Box<C3>=receiver.make(new C3()); console.log(box.value.tag); }
class C4 { tag=4; }
function source4<T>(value:T):Box<T> { console.log('source',4); return new Box(value); }
class M4 implements Maker { make<T>(value:T):Box<T> { console.log('method',4); return new Box(value); } }
function use4(receiver:Maker):void { const box:Box<C4>=receiver.make(new C4()); console.log(box.value.tag); }
class C5 { tag=5; }
function source5<T>(value:T):Box<T> { console.log('source',5); return new Box(value); }
class M5 implements Maker { make<T>(value:T):Box<T> { console.log('method',5); return new Box(value); } }
function use5(receiver:Maker):void { const box:Box<C5>=receiver.make(new C5()); console.log(box.value.tag); }
class C6 { tag=6; }
function source6<T>(value:T):Box<T> { console.log('source',6); return new Box(value); }
class M6 implements Maker { make<T>(value:T):Box<T> { console.log('method',6); return new Box(value); } }
function use6(receiver:Maker):void { const box:Box<C6>=receiver.make(new C6()); console.log(box.value.tag); }
class C7 { tag=7; }
function source7<T>(value:T):Box<T> { console.log('source',7); return new Box(value); }
class M7 implements Maker { make<T>(value:T):Box<T> { console.log('method',7); return new Box(value); } }
function use7(receiver:Maker):void { const box:Box<C7>=receiver.make(new C7()); console.log(box.value.tag); }
class C8 { tag=8; }
function source8<T>(value:T):Box<T> { console.log('source',8); return new Box(value); }
class M8 implements Maker { make<T>(value:T):Box<T> { console.log('method',8); return new Box(value); } }
function use8(receiver:Maker):void { const box:Box<C8>=receiver.make(new C8()); console.log(box.value.tag); }
class C9 { tag=9; }
function source9<T>(value:T):Box<T> { console.log('source',9); return new Box(value); }
class M9 implements Maker { make<T>(value:T):Box<T> { console.log('method',9); return new Box(value); } }
function use9(receiver:Maker):void { const box:Box<C9>=receiver.make(new C9()); console.log(box.value.tag); }
const root0:{value:Maker}={value:new M0()};
const alias0=(root0); const leaf0=alias0; const sibling0=root0; const spare0=sibling0.value;
use0(leaf0.value);
const root1:{value:Maker}={value:new M1()};
const alias1=(root1); const leaf1=alias1; const sibling1=root1; const spare1=sibling1.value;
use1(leaf1.value);
const root2:{value:Maker}={value:new M2()};
const alias2=(root2); const leaf2=alias2; const sibling2=root2; const spare2=sibling2.value;
use2(leaf2.value);
const root3:{value:Maker}={value:new M3()};
const alias3=(root3); const leaf3=alias3; const sibling3=root3; const spare3=sibling3.value;
use3(leaf3.value);
const root4:{value:Maker}={value:new M4()};
const alias4=(root4); const leaf4=alias4; const sibling4=root4; const spare4=sibling4.value;
use4(leaf4.value);
const root5:{value:Maker}={value:new M5()};
const alias5=(root5); const leaf5=alias5; const sibling5=root5; const spare5=sibling5.value;
use5(leaf5.value);
const root6:{value:Maker}={value:new M6()};
const alias6=(root6); const leaf6=alias6; const sibling6=root6; const spare6=sibling6.value;
use6(leaf6.value);
const root7:{value:Maker}={value:new M7()};
const alias7=(root7); const leaf7=alias7; const sibling7=root7; const spare7=sibling7.value;
use7(leaf7.value);
const root8:{value:Maker}={value:new M8()};
const alias8=(root8); const leaf8=alias8; const sibling8=root8; const spare8=sibling8.value;
use8(leaf8.value);
const root9:{value:Maker}={value:new M9()};
const alias9=(root9); const leaf9=alias9; const sibling9=root9; const spare9=sibling9.value;
use9(leaf9.value);
