import json
import os
from pathlib import Path
import subprocess
import sys

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
production = repo/'pts/lower/container_sources.go'
source = production.read_text()
env = dict(os.environ, GOMAXPROCS='2')
rows = []
mutants = [
    ('skip_transitive_uses', ' || !check(alias, target, referenceDepth)', '', '^TestContainerAliasUnsafeUsesPoisonTheWholeComponent$'),
    ('ignore_contracts', 'from, to := l.checker.GetTypeOfSymbol(source), l.checker.GetTypeOfSymbol(target)', 'if steps != nil { return true }\n\tfrom, to := l.checker.GetTypeOfSymbol(source), l.checker.GetTypeOfSymbol(target)', '^TestContainerAliasUnsupportedOriginsStayUnknown$'),
]
for name, old, new, pattern in mutants:
    assert source.count(old) == 1
    path = out/(name+'.go')
    path.write_text(source.replace(old,new))
    overlay = out/(name+'.overlay.json')
    overlay.write_text(json.dumps({'Replace':{str(production):str(path)}}))
    command = ['go','test','-overlay',str(overlay),'-count=1','-json','-p','1','-parallel','2','./pts/lower','-run',pattern]
    p = subprocess.run(command,cwd=repo,env=env,capture_output=True,text=True,timeout=300)
    (out/(name+'.jsonl')).write_text(p.stdout)
    (out/(name+'.stderr')).write_text(p.stderr)
    events = [json.loads(line) for line in p.stdout.splitlines()]
    failures = [e['Test'] for e in events if e['Action']=='fail' and e.get('Test')]
    assertions = [e['Output'] for e in events if e['Action']=='output' and 'assertion failed' in e.get('Output','')]
    row = dict(name=name,command=command,exit=p.returncode,failed_tests=failures,assertions=assertions,stderr=p.stderr)
    rows.append(row)
    (out/'results.json').write_text(json.dumps(rows,indent=2))
    assert p.returncode != 0 and failures and assertions and 'build failed' not in p.stdout+p.stderr, row
    print(name, 'compiled; rejected by', len(failures), 'failed test events', flush=True)
