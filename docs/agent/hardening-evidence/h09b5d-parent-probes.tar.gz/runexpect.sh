#!/bin/bash
# usage: runexpect.sh BIN file.pts -> "MATCH|DIFF name first-line"
bin=$1; f=$2; n=$(basename $f .pts)
d=$(mktemp -d /tmp/h09b5d/rx.XXXXXX)
sed '/^\/\/ expect:/,$!d' $f | tail -n +2 | sed 's|^// \{0,1\}||' > $d/expect
grep -q '^// expect-exit:\|^// exit:' $f
(cd $d && PTS_HOME=/home/bryan/projects/parallelscript timeout 300 $bin run $f > $d/out 2>&1)
if diff -q $d/expect $d/out >/dev/null; then echo "MATCH $n"; else echo "DIFF $n $(head -1 $d/out | cut -c1-150)"; fi
rm -rf $d
