#!/bin/bash
# usage: compare.sh file.pts -> prints "same|diff|base-fail|new-fail <file>" comparing emit-c of base and new
f="$1"
h=$(echo "$f" | sha1sum | cut -c1-12)
out=/tmp/h09b5d/emitc/out
mkdir -p $out
export PTS_HOME=/home/bryan/projects/parallelscript
cd /home/bryan/projects/parallelscript
timeout 300 /tmp/h09b5d/pts-base emit-c "$f" > $out/$h.base.c 2> $out/$h.base.err; eb=$?
timeout 300 ./pts-bin/pts emit-c "$f" > $out/$h.new.c 2> $out/$h.new.err; en=$?
if cmp -s $out/$h.base.c $out/$h.new.c && cmp -s $out/$h.base.err $out/$h.new.err && [ $eb = $en ]; then
  echo "same $eb $f"; rm -f $out/$h.*
else
  echo "diff $eb $en $f $h"
fi
