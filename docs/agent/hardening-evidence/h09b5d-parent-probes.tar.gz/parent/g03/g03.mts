// The base's genericInstance, for direct calls: T = Promise<number> and T = any are both
// `value`, so the second call's instance is the first's.
class Box<T> {
  constructor(public value: T) {}
}
function settled<T>(x: T, v: number): Box<T extends Promise<infer U> ? U : T> {
  return new Box(v as any);
}
const a = settled(Promise.resolve(1), 1);
console.log("promise:", a.value + 1);
const b = settled<any>(2, 2);
console.log("any:", b.value);
