"""Prints the whole output of one test from a `go test -json` log. Usage: show_test.py <log.jsonl> <test name> [head chars]"""
import json
import sys

path, name = sys.argv[1], sys.argv[2]
limit = int(sys.argv[3]) if len(sys.argv) > 3 else 4000
text = []
for line in open(path):
    try:
        event = json.loads(line)
    except ValueError:
        continue
    if event.get('Test') == name and event.get('Action') == 'output':
        text.append(event['Output'])
print(''.join(text)[:limit])
