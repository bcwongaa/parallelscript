#!/bin/bash
# Runs focused tests natively (programs built for this host unless the test says otherwise)
# and saves the verbose log. Usage: run-focused.sh <label> <cache dir> <-run pattern> <package> [NAME=value env...]
set -uo pipefail
label=$1 cache=$2 pattern=$3 package=$4
shift 4
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32 || exit 2
export PATH="$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH" PTS_CACHE_DIR="$cache" GOMAXPROCS=4
log=/tmp/h35s/repro/logs/$label.log
env "$@" go test -count=1 -p 4 -parallel 4 -timeout 60m -run "$pattern" -v "$package" >"$log" 2>&1
status=$?
echo "exit $status" >>"$log"
grep -v '^\s*$' "$log" | grep -v 'warning:\|note:\|^\s*[0-9]* |\|^\s*|' | tail -"${TAIL:-60}"
exit $status
