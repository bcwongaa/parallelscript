#!/bin/bash
# Writes red-tests.patch: the RED test files (new, untracked in the reproducer's worktree) as
# a diff against HEAD that `git apply` can take, without touching the worktree's index.
set -uo pipefail
wt=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32
out=/tmp/h35s/repro/red-tests.patch
: >"$out"
cd "$wt" || exit 2
for file in cmd/pts/cross_target_test.go pts/toolchain/cross_test.go pts/tests/memory_order_test.go pts/tests/stress/race_publication.pts; do
  git diff --no-index -- /dev/null "$file" >>"$out"
done
grep -c '^+++ ' "$out"
