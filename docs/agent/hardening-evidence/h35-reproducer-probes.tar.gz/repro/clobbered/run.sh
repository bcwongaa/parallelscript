#!/bin/bash
# GCC's -Wclobbered on the runtime's sources, for aarch64 and for x86-64: the locals a
# longjmp may leave with a stale value, as each target's register allocation keeps them.
# Clang has no such warning. Usage: run.sh <pts home>
set -uo pipefail
home=$1
out=/tmp/h35s/repro/clobbered
includes=(-I "$home/pts/runtime/include" -I "$home/pts/third_party/bdwgc/include" -I "$home/pts/third_party/libuv/include"
  -I "$home/pts/third_party/ryu" -I "$home/pts/third_party/libbacktrace" -I "$home/pts/third_party/pcre2-config"
  -I "$home/pts/third_party/mbedtls-config" -I "$home/pts/third_party/mbedtls/include")
flags=('-D__builtin_bitreverse64(x)=((uint64_t)(x))' -O2 -std=gnu11 -ffp-contract=off -fno-math-errno -Wclobbered -Wno-attributes '-DMBEDTLS_USER_CONFIG_FILE="pts_mbedtls_config.h"')
for compiler in aarch64-linux-gnu-gcc gcc; do
  log="$out/$compiler.log"
  : >"$log"
  for source in "$home"/pts/runtime/src/*.c; do
    taskset -c 6,7 "$compiler" "${flags[@]}" "${includes[@]}" -c "$source" -o /dev/null >>"$log" 2>&1
  done
  echo "$compiler: $(grep -c 'Wclobbered' "$log") clobbered warnings, $(grep -c ' error: ' "$log") errors"
done
