#!/bin/bash
# Triage of the programs that failed under aarch64/qemu with empty or cut-off output: each
# run alone with no deadline, two at a time.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32/pts/tests
T=/tmp/h35s/repro/triage.sh
bash "$T" "$W/corpus/text/cron_describer.pts" &
bash "$T" "$W/run/long_string_scans.pts" &
wait
bash "$T" "$W/run/parallel_sort_all_or_nothing.pts" PTS_THREADS=1 &
bash "$T" "$W/run/timers_refused_no_leak.pts" PTS_THREADS=2 &
wait
