#!/bin/bash
# Prints a line of progress every few minutes for a run-cross-suite.sh run, and the names of
# tests that failed since the last line; exits when the run's .exit file appears.
# Usage: watch-suite.sh <label> [seconds between lines]
label=$1
interval=${2:-240}
log=/tmp/h35s/repro/logs/$label.jsonl
done_file=/tmp/h35s/repro/logs/$label.exit
seen=0
while [ ! -f "$done_file" ]; do
  sleep "$interval"
  passes=$(grep -c '"Action":"pass"' "$log" 2>/dev/null)
  fails=$(grep -c '"Action":"fail"' "$log" 2>/dev/null)
  free=$(df -h /tmp | awk 'NR==2{print $4}')
  echo "progress $label: pass=$passes fail=$fails free=$free"
  if [ "$fails" != "$seen" ]; then
    grep '"Action":"fail"' "$log" | grep -o '"Test":"[^"]*"' | tail -n +"$((seen + 1))" | head -8
    seen=$fails
  fi
done
echo "finished $label: $(cat "$done_file")"
