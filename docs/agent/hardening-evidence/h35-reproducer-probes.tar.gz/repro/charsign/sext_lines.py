"""Prints file:line for every i8 sign extension in the signed-char IR that the unsigned-char IR zero-extends."""
import collections
import re
import sys


def locations(path):
    text = open(path).read()
    files = {m.group(1): (m.group(3), m.group(2)) for m in re.finditer(r'^(!\d+) = !DIFile\(filename: "([^"]*)", directory: "([^"]*)"', text, re.M)}
    scopes = {}
    for m in re.finditer(r'^(!\d+) = (?:distinct )?!(DISubprogram|DILexicalBlock|DILexicalBlockFile)\((.*)\)$', text, re.M):
        f = re.search(r'file: (!\d+)', m.group(3))
        s = re.search(r'scope: (!\d+)', m.group(3))
        scopes[m.group(1)] = (f.group(1) if f else None, s.group(1) if s else None)
    locs = {}
    for m in re.finditer(r'^(!\d+) = !DILocation\(line: (\d+), column: (\d+), scope: (!\d+)', text, re.M):
        scope = m.group(4)
        file = None
        while scope and file is None:
            file, scope = scopes.get(scope, (None, None))
        name = files.get(file, ('?', '?'))[1] if file else '?'
        locs[m.group(1)] = (name.split('/')[-1], int(m.group(2)))
    result = collections.Counter()
    for m in re.finditer(r'= (sext|zext) i8 [^\n]*!dbg (!\d+)', text):
        result[(m.group(1), locs.get(m.group(2), ('?', 0)))] += 1
    return result


signed, unsigned = locations(sys.argv[1]), locations(sys.argv[2])
for (kind, where), count in sorted(signed.items(), key=lambda item: item[0][1]):
    if kind == 'sext' and unsigned.get(('sext', where), 0) < count:
        print(f'{where[0]}:{where[1]}')
