#!/bin/bash
# Lists the source lines of the runtime where a plain char is widened: sign-extended with
# -fsigned-char (x86-64) but zero-extended with -funsigned-char (aarch64). Each is a place
# whose result differs between the two for bytes >= 0x80. Usage: lines.sh <pts home> name...
set -euo pipefail
home=$1
shift
out=/tmp/h35s/repro/charsign/ir
mkdir -p "$out"
includes=(-I "$home/pts/runtime/include" -I "$home/pts/third_party/bdwgc/include" -I "$home/pts/third_party/libuv/include"
  -I "$home/pts/third_party/ryu" -I "$home/pts/third_party/libbacktrace" -I "$home/pts/third_party/pcre2-config"
  -I "$home/pts/third_party/mbedtls-config" -I "$home/pts/third_party/mbedtls/include")
flags=(-O0 -g -std=c11 -S -emit-llvm -w '-DMBEDTLS_USER_CONFIG_FILE="pts_mbedtls_config.h"')
for name in "$@"; do
  source="$home/pts/runtime/src/$name.c"
  taskset -c 6,7 clang "${flags[@]}" "${includes[@]}" -fsigned-char "$source" -o "$out/$name.s.ll"
  taskset -c 6,7 clang "${flags[@]}" "${includes[@]}" -funsigned-char "$source" -o "$out/$name.u.ll"
  python3 -I /tmp/h35s/repro/charsign/sext_lines.py "$out/$name.s.ll" "$out/$name.u.ll"
done
