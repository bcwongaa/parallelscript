#!/bin/bash
# Compiles every runtime source with -fsigned-char and with -funsigned-char (aarch64's
# default) on x86-64 and lists the objects whose code differs: the functions that depend
# on char's signedness. Usage: compare.sh <pts home>
set -euo pipefail
home=$1
out=/tmp/h35s/repro/charsign
mkdir -p "$out/s" "$out/u"
includes=(-I "$home/pts/runtime/include" -I "$home/pts/third_party/bdwgc/include" -I "$home/pts/third_party/libuv/include"
  -I "$home/pts/third_party/ryu" -I "$home/pts/third_party/libbacktrace" -I "$home/pts/third_party/pcre2-config"
  -I "$home/pts/third_party/mbedtls-config" -I "$home/pts/third_party/mbedtls/include")
flags=(-O2 -ffp-contract=off -fno-math-errno -std=c11 '-DMBEDTLS_USER_CONFIG_FILE="pts_mbedtls_config.h"')
for source in "$home"/pts/runtime/src/*.c; do
  name=$(basename "$source" .c)
  taskset -c 6,7 clang "${flags[@]}" "${includes[@]}" -fsigned-char -c "$source" -o "$out/s/$name.o" &
  taskset -c 6,7 clang "${flags[@]}" "${includes[@]}" -funsigned-char -c "$source" -o "$out/u/$name.o"
  wait
done
for object in "$out"/s/*.o; do
  name=$(basename "$object")
  cmp -s "$object" "$out/u/$name" || echo "DIFF $name"
done
