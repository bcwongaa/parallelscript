"""Prints the source line of each site in sites.txt (file:line), for review. Usage: show.py <pts home> [file]"""
import sys

home = sys.argv[1]
only = sys.argv[2] if len(sys.argv) > 2 else None
cache = {}
for site in open('/tmp/h35s/repro/charsign/sites.txt'):
    name, line = site.strip().rsplit(':', 1)
    if only and name != only:
        continue
    path = f'{home}/pts/runtime/include/{name}' if name.endswith('.h') else f'{home}/pts/runtime/src/{name}'
    if path not in cache:
        cache[path] = open(path).read().split('\n')
    print(f'{name}:{line}: {cache[path][int(line) - 1].strip()[:170]}')
