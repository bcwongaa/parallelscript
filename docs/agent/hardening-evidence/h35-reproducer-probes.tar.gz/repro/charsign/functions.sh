#!/bin/bash
# For each object that differs between -fsigned-char and -funsigned-char, lists the
# functions whose disassembly differs. Usage: functions.sh name.o...
set -euo pipefail
out=/tmp/h35s/repro/charsign
for name in "$@"; do
  for variant in s u; do
    objdump -d --no-show-raw-insn "$out/$variant/$name" | sed -E 's/^ *[0-9a-f]+:\t//; s/<[^>]*\+0x[0-9a-f]+>//g; s/[0-9a-f]+ <([^>]*)>/<\1>/g' >"$out/$variant/$name.dis"
  done
  python3 -I - "$out/s/$name.dis" "$out/u/$name.dis" "$name" <<'EOF'
import re, sys
def functions(path):
    result, current = {}, None
    for line in open(path):
        m = re.match(r'^(?:[0-9a-f]+ )?<([^>]+)>:', line)
        if m:
            current = m.group(1); result[current] = []
        elif current and line.strip():
            result[current].append(re.sub(r'\s+', ' ', line.strip()))
    return result
s, u = functions(sys.argv[1]), functions(sys.argv[2])
for f in sorted(set(s) | set(u)):
    if s.get(f) != u.get(f):
        print(sys.argv[3], f)
EOF
done
