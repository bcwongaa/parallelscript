	.text
	.file	"ready_flag.c"
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	bl	pts_runtime_init
	bl	pts_loop_init
	adrp	x0, pts_function_names
	add	x0, x0, :lo12:pts_function_names
	mov	w1, #1                          // =0x1
	bl	pts_register_function_names
	adrp	x1, pts_step_main
	add	x1, x1, :lo12:pts_step_main
	mov	w0, #112                        // =0x70
	bl	pts_generator_new
	bl	pts_async_start
	mov	x19, x0
	bl	pts_run_microtasks
	bl	pts_run_loop
	mov	x0, x19
	bl	pts_check_top_level
	mov	w0, wzr
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_runtime_exit
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_step_main
	.type	pts_step_main,@function
pts_step_main:                          // @pts_step_main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	d11, d10, [sp, #16]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB1_10
// %bb.1:
	ldr	w20, [x0, #16]
	mov	x19, x0
	mov	w8, #-1                         // =0xffffffff
	str	w8, [x0, #16]
	cmp	w20, #1
	b.ne	.LBB1_6
// %bb.2:
	ldr	w8, [x19, #20]
	ldr	x0, [x19, #24]
	cmp	w8, #1
	b.eq	.LBB1_12
// %bb.3:
	lsr	x8, x0, #49
	cbz	x8, .LBB1_11
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB1_5:
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	ldr	d1, [x19, #88]
	mov	w10, #7                         // =0x7
	mov	x1, sp
	mov	w0, #2                          // =0x2
	str	d0, [x19, #104]
	add	x8, x8, x9
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	fcmp	d1, #0.0
	mov	w9, #6                          // =0x6
	csel	x9, x10, x9, gt
	stp	x8, x9, [sp]
	bl	pts_console_log
	mov	w8, #-2                         // =0xfffffffe
	mov	w9, #10                         // =0xa
	b	.LBB1_9
.LBB1_6:
	adrp	x0, pts_static_parallel
	add	x0, x0, :lo12:pts_static_parallel
	bl	pts_parallel
	mov	x8, #145685290680320            // =0x848000000000
	movi	d8, #0000000000000000
	movi	d9, #0000000000000000
	movk	x8, #16702, lsl #48
	fmov	d10, #1.00000000
	str	x0, [x19, #80]
	fmov	d11, x8
.LBB1_7:                                // =>This Inner Loop Header: Depth=1
	fmov	d0, d8
	fmov	d1, #7.00000000
	bl	fmod
	fadd	d8, d8, d10
	fadd	d9, d0, d9
	fcmp	d8, d11
	b.mi	.LBB1_7
// %bb.8:
	adrp	x0, pts_type_object1
	add	x0, x0, :lo12:pts_type_object1
	stp	d9, d8, [x19, #88]
	bl	pts_object_new
	mov	x8, #4631107791820423168        // =0x4045000000000000
	adrp	x9, pts_global_config
	adrp	x10, pts_global_config_ready
	str	x8, [x0, #8]
	mov	w8, #1                          // =0x1
	str	x0, [x9, :lo12:pts_global_config]
	ldr	x9, [x19, #80]
	strb	w8, [x10, :lo12:pts_global_config_ready]
.LBB1_9:
	cmp	w20, #1
	str	x9, [x19, #32]
	cset	w0, eq
	str	w8, [x19, #16]
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB1_10:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB1_11:
	bl	pts_value_to_number_slow
	b	.LBB1_5
.LBB1_12:
	bl	pts_throw
.Lfunc_end1:
	.size	pts_step_main, .Lfunc_end1-pts_step_main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel
	.type	pts_fn_parallel,@function
pts_fn_parallel:                        // @pts_fn_parallel
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB2_2
// %bb.1:
	bl	pts_fn_limitWhenReady
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB2_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end2:
	.size	pts_fn_parallel, .Lfunc_end2-pts_fn_parallel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel
	.type	pts_dynamic_fn_parallel,@function
pts_dynamic_fn_parallel:                // @pts_dynamic_fn_parallel
	.cfi_startproc
// %bb.0:
	ldr	x1, [x0, #8]
	br	x1
.Lfunc_end3:
	.size	pts_dynamic_fn_parallel, .Lfunc_end3-pts_dynamic_fn_parallel
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_2
	.type	pts_adapt_2,@function
pts_adapt_2:                            // @pts_adapt_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_2
	add	x0, x0, :lo12:pts_type_adapter_2
	bl	pts_object_new
	adrp	x8, pts_adapter_2
	add	x8, x8, :lo12:pts_adapter_2
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end4:
	.size	pts_adapt_2, .Lfunc_end4-pts_adapt_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_2
	.type	pts_adapter_2,@function
pts_adapter_2:                          // @pts_adapter_2
	.cfi_startproc
// %bb.0:
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	b	pts_dynamic_call_closure
.Lfunc_end5:
	.size	pts_adapter_2, .Lfunc_end5-pts_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_limitWhenReady
	.type	pts_fn_limitWhenReady,@function
pts_fn_limitWhenReady:                  // @pts_fn_limitWhenReady
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #400
	.cfi_def_cfa_offset 400
	stp	x29, x30, [sp, #336]            // 16-byte Folded Spill
	stp	x28, x23, [sp, #352]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #368]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #384]            // 16-byte Folded Spill
	add	x29, sp, #336
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w28, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	mov	x9, x29
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x19, TPIDR_EL0
	ldr	x8, [x19, x8]
	cmp	x8, x29
	b.hi	.LBB6_14
// %bb.1:
	adrp	x20, :gottprel:pts_handlers
	mov	x21, sp
	ldr	x20, [x20, :gottprel_lo12:pts_handlers]
	add	x0, x21, #24
	ldr	x9, [x19, x20]
	str	xzr, [sp, #16]
	str	x9, [sp]
	str	x21, [x19, x20]
	bl	_setjmp
	cbz	w0, .LBB6_9
// %bb.2:
	adrp	x22, :got:pts_type_builtin_ReferenceError
	mov	x23, #-65537                    // =0xfffffffffffeffff
	ldr	x22, [x22, :got_lo12:pts_type_builtin_ReferenceError]
	movk	x23, #1, lsl #48
.LBB6_3:                                // =>This Loop Header: Depth=1
                                        //     Child Loop BB6_5 Depth 2
	ldr	x0, [sp, #8]
	sub	x8, x0, #16, lsl #12            // =65536
	cmp	x8, x23
	b.hi	.LBB6_15
// %bb.4:                               //   in Loop: Header=BB6_3 Depth=1
	mov	x9, x0
.LBB6_5:                                //   Parent Loop BB6_3 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	x9, [x9]
	cmp	x9, x22
	mov	x8, x9
	b.eq	.LBB6_7
// %bb.6:                               //   in Loop: Header=BB6_5 Depth=2
	add	x9, x9, #24
	cbnz	x8, .LBB6_5
.LBB6_7:                                //   in Loop: Header=BB6_3 Depth=1
	cbz	x8, .LBB6_15
// %bb.8:                               //   in Loop: Header=BB6_3 Depth=1
	ldr	x9, [x19, x20]
	add	x0, x21, #24
	str	xzr, [sp, #16]
	str	x9, [sp]
	str	x21, [x19, x20]
	bl	_setjmp
	cbnz	w0, .LBB6_3
.LBB6_9:
	adrp	x8, pts_global_config_ready
	ldrb	w8, [x8, :lo12:pts_global_config_ready]
	tbz	w8, #0, .LBB6_16
// %bb.10:
	adrp	x8, pts_global_config
	ldr	x0, [x8, :lo12:pts_global_config]
	adrp	x8, pts_fn_limitWhenReady.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_limitWhenReady.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB6_12
// %bb.11:
	add	x8, x0, x8, lsr #48
	b	.LBB6_13
.LBB6_12:
	adrp	x1, pts_fn_limitWhenReady.pts_site1
	add	x1, x1, :lo12:pts_fn_limitWhenReady.pts_site1
	adrp	x2, .L.str.5
	add	x2, x2, :lo12:.L.str.5
	adrp	x3, pts_check_1
	add	x3, x3, :lo12:pts_check_1
	bl	pts_field_address_slow
	mov	x8, x0
.LBB6_13:
	ldr	d0, [x8]
	ldr	x8, [sp]
	str	x8, [x19, x20]
	.cfi_def_cfa wsp, 400
	ldp	x20, x19, [sp, #384]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #368]            // 16-byte Folded Reload
	ldp	x28, x23, [sp, #352]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #336]            // 16-byte Folded Reload
	add	sp, sp, #400
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_14:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB6_15:
	bl	pts_throw
.LBB6_16:
	adrp	x0, .L.str.4
	add	x0, x0, :lo12:.L.str.4
	bl	pts_throw_uninitialized
.Lfunc_end6:
	.size	pts_fn_limitWhenReady, .Lfunc_end6-pts_fn_limitWhenReady
	.cfi_endproc
                                        // -- End function
	.type	pts_function_names,@object      // @pts_function_names
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_function_names:
	.xword	.L.str
	.xword	.L.str.1
	.byte	0                               // 0x0
	.zero	7
	.size	pts_function_names, 24

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"pts_fn_limitWhenReady"
	.size	.L.str, 22

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"limitWhenReady"
	.size	.L.str.1, 15

	.type	pts_static_parallel,@object     // @pts_static_parallel
	.data
	.p2align	3, 0x0
pts_static_parallel:
	.xword	pts_type_closure_parallel
	.xword	pts_fn_parallel
	.size	pts_static_parallel, 16

	.type	pts_type_object1,@object        // @pts_type_object1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_object1:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.7
	.xword	0
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_fields_object1
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_object1, 136

	.type	pts_global_config,@object       // @pts_global_config
	.local	pts_global_config
	.comm	pts_global_config,8,8
	.type	pts_global_config_ready,@object // @pts_global_config_ready
	.local	pts_global_config_ready
	.comm	pts_global_config_ready,1,1
	.type	pts_type_closure_parallel,@object // @pts_type_closure_parallel
	.p2align	3, 0x0
pts_type_closure_parallel:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.2
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel
	.xword	pts_check_2
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel, 136

	.type	.L.str.2,@object                // @.str.2
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.2:
	.zero	1
	.size	.L.str.2, 1

	.type	pts_check_2,@object             // @pts_check_2
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_2:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.3
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_2
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_2, 88

	.type	.L.str.3,@object                // @.str.3
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.3:
	.asciz	"() => value"
	.size	.L.str.3, 12

	.type	pts_type_adapter_2,@object      // @pts_type_adapter_2
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_2
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_2, 136

	.type	pts_fn_limitWhenReady.pts_site1,@object // @pts_fn_limitWhenReady.pts_site1
	.local	pts_fn_limitWhenReady.pts_site1
	.comm	pts_fn_limitWhenReady.pts_site1,8,8
	.type	.L.str.4,@object                // @.str.4
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.4:
	.asciz	"config"
	.size	.L.str.4, 7

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"limit"
	.size	.L.str.5, 6

	.type	pts_check_1,@object             // @pts_check_1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_1:
	.word	2                               // 0x2
	.word	1                               // 0x1
	.xword	.L.str.6
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_1, 88

	.type	.L.str.6,@object                // @.str.6
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.6:
	.asciz	"number"
	.size	.L.str.6, 7

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"Object"
	.size	.L.str.7, 7

	.type	pts_fields_object1,@object      // @pts_fields_object1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_fields_object1:
	.xword	.L.str.5
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_1
	.size	pts_fields_object1, 24

	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym pts_step_main
	.addrsig_sym pts_fn_parallel
	.addrsig_sym pts_dynamic_fn_parallel
	.addrsig_sym pts_adapt_2
	.addrsig_sym pts_adapter_2
	.addrsig_sym pts_adapter_call
	.addrsig_sym pts_function_names
	.addrsig_sym pts_static_parallel
	.addrsig_sym pts_type_object1
	.addrsig_sym pts_type_closure_parallel
	.addrsig_sym pts_check_2
	.addrsig_sym pts_type_adapter_2
	.addrsig_sym pts_fn_limitWhenReady.pts_site1
	.addrsig_sym pts_check_1
	.addrsig_sym pts_type_builtin_ReferenceError
	.addrsig_sym pts_fields_object1
