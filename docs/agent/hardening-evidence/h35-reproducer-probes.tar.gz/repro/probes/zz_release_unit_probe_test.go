package toolchain_test

import (
	"path/filepath"
	"testing"

	"github.com/microsoft/typescript-go/pts/toolchain"
	"gotest.tools/v3/assert"
)

// H35 reproducer probe, not a regression test: the runtime's C unit tests built with the
// Release profile and $PTS_CC (an aarch64 cross compiler) and run under qemu-aarch64, since
// the sanitizer builds that TestRuntimeUnitTestsPassUnderSanitizers makes can't link for
// aarch64 without compiler-rt's aarch64 runtimes.
func TestProbeRuntimeUnitTestsReleaseUnderCross(t *testing.T) {
	t.Parallel()
	sources, err := filepath.Glob(runtimeTestSource(t, "*_test.c"))
	assert.NilError(t, err)
	for _, source := range sources {
		t.Run(filepath.Base(source), func(t *testing.T) {
			t.Parallel()
			exe := buildC(t, toolchain.Release, source)
			result := run(t, exe, "")
			assert.Equal(t, result.exitCode, 0, "stdout:\n%s\nstderr:\n%s", result.stdout, result.stderr)
		})
	}
}
