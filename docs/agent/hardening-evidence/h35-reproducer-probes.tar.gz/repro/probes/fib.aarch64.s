	.text
	.file	"fib.c"
	.globl	main                            // -- Begin function main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_runtime_init
	adrp	x0, pts_function_names
	add	x0, x0, :lo12:pts_function_names
	mov	w1, #1                          // =0x1
	bl	pts_register_function_names
	fmov	d0, #30.00000000
	bl	pts_fn_fib
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x1, sp, #8
	mov	w0, #1                          // =0x1
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	str	x8, [sp, #8]
	bl	pts_console_log
	mov	w0, wzr
	bl	pts_runtime_exit
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_fib
	.type	pts_fn_fib,@function
pts_fn_fib:                             // @pts_fn_fib
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset b8, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB1_4
// %bb.1:
	fmov	d1, #2.00000000
	fcmp	d0, d1
	b.mi	.LBB1_3
// %bb.2:
	fmov	d1, #-1.00000000
	fmov	d8, d0
	fadd	d1, d0, d1
	fmov	d0, d1
	bl	pts_fn_fib
	fmov	d1, #-2.00000000
	fadd	d1, d8, d1
	fmov	d8, d0
	fmov	d0, d1
	bl	pts_fn_fib
	fadd	d0, d8, d0
.LBB1_3:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB1_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end1:
	.size	pts_fn_fib, .Lfunc_end1-pts_fn_fib
	.cfi_endproc
                                        // -- End function
	.type	pts_function_names,@object      // @pts_function_names
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_function_names:
	.xword	.L.str
	.xword	.L.str.1
	.byte	0                               // 0x0
	.zero	7
	.size	pts_function_names, 24

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"pts_fn_fib"
	.size	.L.str, 11

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"fib"
	.size	.L.str.1, 4

	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym pts_function_names
