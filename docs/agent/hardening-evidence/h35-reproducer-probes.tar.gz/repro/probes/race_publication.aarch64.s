	.text
	.file	"race_publication.c"
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function main
.LCPI0_0:
	.xword	0x0000000000000000              // double 0
	.xword	0x41186a0000000000              // double 4.0E+5
	.text
	.globl	main
	.p2align	2
	.type	main,@function
main:                                   // @main
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	stp	d9, d8, [sp, #64]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #80]             // 16-byte Folded Spill
	str	x23, [sp, #96]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #80
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_remember_state
	bl	pts_runtime_init
	adrp	x0, pts_function_names
	add	x0, x0, :lo12:pts_function_names
	mov	w1, #60                         // =0x3c
	bl	pts_register_function_names
	adrp	x8, pts_global_parallel_Range_class_ready
	mov	w22, #1                         // =0x1
	adrp	x9, pts_global_parallel_ParallelRange_class_ready
	strb	w22, [x8, :lo12:pts_global_parallel_Range_class_ready]
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT
	add	x1, sp, #32
	strb	w22, [x9, :lo12:pts_global_parallel_ParallelRange_class_ready]
	mov	x9, #4656722014701092864        // =0x40a0000000000000
	mov	w2, #4                          // =0x4
	str	x9, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT]
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT_ready
	mov	x9, #4607182418800017408        // =0x3ff0000000000000
	strb	w22, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT_ready]
	adrp	x8, pts_global_parallel_PIECES_PER_THREAD
	str	x9, [x8, :lo12:pts_global_parallel_PIECES_PER_THREAD]
	adrp	x9, .Lconstinit
	add	x9, x9, :lo12:.Lconstinit
	ldp	q0, q1, [x9]
	adrp	x8, pts_global_parallel_PIECES_PER_THREAD_ready
	strb	w22, [x8, :lo12:pts_global_parallel_PIECES_PER_THREAD_ready]
	adrp	x8, :got:pts_array_types
	stp	q0, q1, [sp, #32]
	ldr	x8, [x8, :got_lo12:pts_array_types]
	add	x0, x8, #408
	bl	pts_array_of
	adrp	x8, pts_global_LABELS
	adrp	x9, pts_global_LABELS_ready
	str	x0, [x8, :lo12:pts_global_LABELS]
	adrp	x8, pts_global_Inner_class_ready
	adrp	x0, pts_type_object1
	add	x0, x0, :lo12:pts_type_object1
	strb	w22, [x8, :lo12:pts_global_Inner_class_ready]
	adrp	x8, pts_global_Payload_class_ready
	strb	w22, [x9, :lo12:pts_global_LABELS_ready]
	strb	w22, [x8, :lo12:pts_global_Payload_class_ready]
	bl	pts_object_new
	adrp	x20, pts_type_Payload
	add	x20, x20, :lo12:pts_type_Payload
	mov	x19, x0
	mov	x0, x20
	bl	pts_object_new
	movi	d0, #0000000000000000
	mov	x21, x0
	bl	pts_fn_Payload_constructor
	adrp	x8, pts_global_slot
	adrp	x9, pts_global_slot_ready
	mov	x0, x20
	str	x21, [x19, #8]
	str	x19, [x8, :lo12:pts_global_slot]
	strb	w22, [x9, :lo12:pts_global_slot_ready]
	bl	pts_object_new
	movi	d0, #0000000000000000
	mov	x19, x0
	bl	pts_fn_Payload_constructor
	adrp	x0, pts_type_array_1
	add	x0, x0, :lo12:pts_type_array_1
	add	x1, sp, #24
	mov	w2, #1                          // =0x1
	str	x19, [sp, #24]
	bl	pts_array_of
	adrp	x8, pts_global_elements
	adrp	x9, pts_global_elements_ready
	str	x0, [x8, :lo12:pts_global_elements]
	adrp	x0, pts_type_tuple1
	add	x0, x0, :lo12:pts_type_tuple1
	strb	w22, [x9, :lo12:pts_global_elements_ready]
	bl	pts_object_new
	mov	x19, x0
	str	xzr, [x0, #8]
	mov	x0, x20
	bl	pts_object_new
	movi	d0, #0000000000000000
	mov	x20, x0
	bl	pts_fn_Payload_constructor
	adrp	x0, pts_type_array_2
	add	x0, x0, :lo12:pts_type_array_2
	add	x1, sp, #16
	mov	w2, #1                          // =0x1
	str	x20, [x19, #16]
	str	x19, [sp, #16]
	bl	pts_array_of
	adrp	x21, :gottprel:pts_stack_limit
	ldr	x21, [x21, :gottprel_lo12:pts_stack_limit]
	mrs	x22, TPIDR_EL0
	ldr	x8, [x22, x21]
	cmp	x8, x29
	b.hi	.LBB0_16
// %bb.1:
	mov	x19, x0
	adrp	x0, pts_type_map_1
	add	x0, x0, :lo12:pts_type_map_1
	bl	pts_map_new
	add	x8, x19, #16
	mov	x20, x0
	ldar	x8, [x8]
	cbz	x8, .LBB0_7
// %bb.2:
	movi	d8, #0000000000000000
	fmov	d9, #1.00000000
.LBB0_3:                                // =>This Inner Loop Header: Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d8, #0.0
	b.lt	.LBB0_18
// %bb.4:                               //   in Loop: Header=BB0_3 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB0_18
// %bb.5:                               //   in Loop: Header=BB0_3 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB0_18
// %bb.6:                               //   in Loop: Header=BB0_3 Depth=1
	ldr	d0, [x8, #8]
	ldr	x8, [x8, #16]
	mov	x1, sp
	add	x2, x29, #24
	mov	x0, x20
	str	d0, [sp]
	str	x8, [x29, #24]
	bl	pts_map_set
	add	x8, x19, #16
	fadd	d8, d8, d9
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d8, d0
	b.mi	.LBB0_3
.LBB0_7:
	adrp	x8, pts_global_entries
	adrp	x9, pts_global_entries_ready
	mov	w23, #1                         // =0x1
	adrp	x0, pts_type_Payload
	add	x0, x0, :lo12:pts_type_Payload
	str	x20, [x8, :lo12:pts_global_entries]
	strb	w23, [x9, :lo12:pts_global_entries_ready]
	bl	pts_object_new
	movi	d0, #0000000000000000
	mov	x19, x0
	bl	pts_fn_Payload_constructor
	adrp	x8, pts_global_variable
	adrp	x9, pts_global_variable_ready
	adrp	x0, pts_type_sync_AtomicInt
	add	x0, x0, :lo12:pts_type_sync_AtomicInt
	str	x19, [x8, :lo12:pts_global_variable]
	strb	w23, [x9, :lo12:pts_global_variable_ready]
	bl	pts_object_new
	ldr	x8, [x22, x21]
	cmp	x8, x29
	b.hi	.LBB0_16
// %bb.8:
	fmov	d0, #8.00000000
	mov	x19, x0
	bl	pts_arraybuffer_new
	str	x0, [x19, #8]
	cbz	x0, .LBB0_17
// %bb.9:
	mov	x1, xzr
	bl	pts_atomic_store
	adrp	x20, pts_global_bad
	adrp	x9, pts_global_bad_ready
	mov	w10, #1                         // =0x1
	str	x19, [x20, :lo12:pts_global_bad]
	ldr	x8, [x22, x21]
	strb	w10, [x9, :lo12:pts_global_bad_ready]
	cmp	x8, x29
	b.hi	.LBB0_16
// %bb.10:
	adrp	x0, pts_type_parallel_Range
	add	x0, x0, :lo12:pts_type_parallel_Range
	bl	pts_object_new
	adrp	x8, .LCPI0_0
	mov	x19, x0
	ldr	q0, [x8, :lo12:.LCPI0_0]
	stur	q0, [x0, #8]
	adrp	x0, pts_type_closure_parallel_for
	add	x0, x0, :lo12:pts_type_closure_parallel_for
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_for
	add	x8, x8, :lo12:pts_fn_parallel_for
	stp	x8, x19, [x0, #8]
	ldp	d1, d0, [x19, #8]
	fsub	d1, d0, d1
	fcmp	d1, d1
	b.vs	.LBB0_19
// %bb.11:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.eq	.LBB0_13
// %bb.12:
	fcsel	d0, d0, d1, mi
.LBB0_13:
	bl	pts_parallel_for_each
	adrp	x8, pts_str_5_storage
	add	x8, x8, :lo12:pts_str_5_storage
	str	x8, [sp]
	ldr	x8, [x22, x21]
	cmp	x8, x29
	b.hi	.LBB0_16
// %bb.14:
	ldr	x8, [x20, :lo12:pts_global_bad]
	ldr	x0, [x8, #8]
	cbz	x0, .LBB0_17
// %bb.15:
	bl	pts_atomic_load
	mov	w8, #6                          // =0x6
	cmp	x0, #0
	mov	x1, sp
	cinc	x8, x8, eq
	mov	w0, #2                          // =0x2
	str	x8, [sp, #8]
	bl	pts_console_log
	mov	w0, wzr
	bl	pts_runtime_exit
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldr	x23, [sp, #96]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x29, x30, [sp, #80]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #64]               // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB0_16:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB0_17:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB0_18:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.LBB0_19:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB0_13
.Lfunc_end0:
	.size	main, .Lfunc_end0-main
	.cfi_endproc
                                        // -- End function
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0                          // -- Begin function pts_fn_Payload_constructor
.LCPI1_0:
	.xword	0x3ff0000000000000              // double 1
	.xword	0x4000000000000000              // double 2
.LCPI1_1:
	.xword	0x4008000000000000              // double 3
	.xword	0x4010000000000000              // double 4
.LCPI1_2:
	.xword	0x4014000000000000              // double 5
	.xword	0x4018000000000000              // double 6
	.text
	.p2align	2
	.type	pts_fn_Payload_constructor,@function
pts_fn_Payload_constructor:             // @pts_fn_Payload_constructor
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
                                        // kill: def $d0 killed $d0 def $q0
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB1_8
// %bb.1:
	adrp	x8, .LCPI1_0
	dup	v5.2d, v0.d[0]
	fmov	d3, #7.00000000
	ldr	q1, [x8, :lo12:.LCPI1_0]
	adrp	x8, .LCPI1_1
	mov	x19, x0
	ldr	q2, [x8, :lo12:.LCPI1_1]
	adrp	x8, .LCPI1_2
	str	d0, [x0, #8]
	fadd	v1.2d, v5.2d, v1.2d
	ldr	q4, [x8, :lo12:.LCPI1_2]
	adrp	x8, pts_str_6_storage
	add	x8, x8, :lo12:pts_str_6_storage
	fadd	v2.2d, v5.2d, v2.2d
	fadd	v4.2d, v5.2d, v4.2d
	str	x8, [x0, #72]
	adrp	x8, pts_global_LABELS_ready
	ldrb	w8, [x8, :lo12:pts_global_LABELS_ready]
	stp	q1, q2, [x0, #16]
	fadd	d1, d0, d3
	str	q4, [x0, #48]
	str	d1, [x0, #64]
	tbz	w8, #0, .LBB1_10
// %bb.2:
	fmov	d1, #4.00000000
	adrp	x8, pts_global_LABELS
	str	q0, [sp]                        // 16-byte Folded Spill
	ldr	x20, [x8, :lo12:pts_global_LABELS]
                                        // kill: def $d0 killed $d0 killed $q0
	bl	fmod
	add	x8, x20, #16
	add	x9, x20, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	b.lt	.LBB1_9
// %bb.3:
	ucvtf	d1, x9
	fcmp	d0, d1
	b.pl	.LBB1_9
// %bb.4:
	fcvtzu	d1, d0
	ucvtf	d1, d1
	fcmp	d0, d1
	b.ne	.LBB1_9
// %bb.5:
	fcvtzu	x9, d0
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB1_9
// %bb.6:
	adrp	x9, pts_global_Inner_class_ready
	str	x8, [x19, #72]
	ldrb	w9, [x9, :lo12:pts_global_Inner_class_ready]
	tbz	w9, #0, .LBB1_11
// %bb.7:
	adrp	x0, pts_type_Inner
	add	x0, x0, :lo12:pts_type_Inner
	bl	pts_object_new
	ldr	q0, [sp]                        // 16-byte Folded Reload
	str	x0, [x19, #80]
	str	d0, [x0, #8]
	adrp	x0, pts_type_closure_Payload_constructor_arrow
	add	x0, x0, :lo12:pts_type_closure_Payload_constructor_arrow
	bl	pts_object_new
	ldr	q0, [sp]                        // 16-byte Folded Reload
	adrp	x8, pts_fn_Payload_constructor_arrow
	add	x8, x8, :lo12:pts_fn_Payload_constructor_arrow
	str	x8, [x0, #8]
	str	d0, [x0, #16]
	str	x0, [x19, #88]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB1_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB1_9:
	mov	x0, x20
	bl	pts_array_index_error
.LBB1_10:
	adrp	x0, .L.str.140
	add	x0, x0, :lo12:.L.str.140
	bl	pts_throw_uninitialized
.LBB1_11:
	adrp	x0, .L.str.136
	add	x0, x0, :lo12:.L.str.136
	bl	pts_throw_uninitialized
.Lfunc_end1:
	.size	pts_fn_Payload_constructor, .Lfunc_end1-pts_fn_Payload_constructor
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_12
	.type	pts_adapt_12,@function
pts_adapt_12:                           // @pts_adapt_12
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_12
	add	x0, x0, :lo12:pts_type_adapter_12
	bl	pts_object_new
	adrp	x8, pts_adapter_12
	add	x8, x8, :lo12:pts_adapter_12
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	pts_adapt_12, .Lfunc_end2-pts_adapt_12
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_12
	.type	pts_adapter_12,@function
pts_adapter_12:                         // @pts_adapter_12
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB3_2
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB3_2:
	.cfi_restore_state
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_to_number_slow
.Lfunc_end3:
	.size	pts_adapter_12, .Lfunc_end3-pts_adapter_12
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_Payload_whole
	.type	pts_entry_Payload_whole,@function
pts_entry_Payload_whole:                // @pts_entry_Payload_whole
	.cfi_startproc
// %bb.0:
	b	pts_fn_Payload_whole
.Lfunc_end4:
	.size	pts_entry_Payload_whole, .Lfunc_end4-pts_entry_Payload_whole
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_Payload_whole
	.type	pts_dynamic_entry_Payload_whole,@function
pts_dynamic_entry_Payload_whole:        // @pts_dynamic_entry_Payload_whole
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_fn_Payload_whole
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end5:
	.size	pts_dynamic_entry_Payload_whole, .Lfunc_end5-pts_dynamic_entry_Payload_whole
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_Payload_whole
	.type	pts_fn_Payload_whole,@function
pts_fn_Payload_whole:                   // @pts_fn_Payload_whole
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB6_16
// %bb.1:
	fmov	d0, #1.00000000
	ldp	d8, d1, [x0, #8]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.2:
	fmov	d0, #2.00000000
	ldr	d1, [x0, #24]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.3:
	fmov	d0, #3.00000000
	ldr	d1, [x0, #32]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.4:
	fmov	d0, #4.00000000
	ldr	d1, [x0, #40]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.5:
	fmov	d0, #5.00000000
	ldr	d1, [x0, #48]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.6:
	fmov	d0, #6.00000000
	ldr	d1, [x0, #56]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.7:
	fmov	d0, #7.00000000
	ldr	d1, [x0, #64]
	fadd	d0, d8, d0
	fcmp	d1, d0
	b.ne	.LBB6_14
// %bb.8:
	adrp	x8, pts_global_LABELS_ready
	ldrb	w8, [x8, :lo12:pts_global_LABELS_ready]
	tbz	w8, #0, .LBB6_19
// %bb.9:
	fmov	d0, d8
	fmov	d1, #4.00000000
	adrp	x8, pts_global_LABELS
	ldr	x19, [x8, :lo12:pts_global_LABELS]
	mov	x20, x0
	bl	fmod
	mov	x0, x19
	bl	pts_array_element
	ldr	x1, [x20, #72]
	bl	pts_value_strict_equals
	tbz	w0, #0, .LBB6_14
// %bb.10:
	ldr	x8, [x20, #80]
	cbz	x8, .LBB6_17
// %bb.11:
	ldr	d0, [x8, #8]
	fcmp	d0, d8
	b.ne	.LBB6_14
// %bb.12:
	ldr	x0, [x20, #88]
	cbz	x0, .LBB6_18
// %bb.13:
	ldr	x8, [x0, #8]
	blr	x8
	fadd	d1, d8, d8
	fcmp	d0, d1
	cset	w0, eq
	b	.LBB6_15
.LBB6_14:
	mov	w0, wzr
.LBB6_15:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB6_16:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB6_17:
	adrp	x0, .L.str.132
	add	x0, x0, :lo12:.L.str.132
	adrp	x1, .L.str.137
	add	x1, x1, :lo12:.L.str.137
	bl	pts_throw_unset_field
.LBB6_18:
	adrp	x0, .L.str.133
	add	x0, x0, :lo12:.L.str.133
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB6_19:
	adrp	x0, .L.str.140
	add	x0, x0, :lo12:.L.str.140
	bl	pts_throw_uninitialized
.Lfunc_end6:
	.size	pts_fn_Payload_whole, .Lfunc_end6-pts_fn_Payload_whole
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_47
	.type	pts_adapt_47,@function
pts_adapt_47:                           // @pts_adapt_47
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_47
	add	x0, x0, :lo12:pts_type_adapter_47
	bl	pts_object_new
	adrp	x8, pts_adapter_47
	add	x8, x8, :lo12:pts_adapter_47
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	pts_adapt_47, .Lfunc_end7-pts_adapt_47
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_47
	.type	pts_adapter_47,@function
pts_adapter_47:                         // @pts_adapter_47
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	bl	pts_dynamic_call_closure
	sub	x8, x0, #8
	cmn	x8, #3
	b.ls	.LBB8_2
// %bb.1:
	cmp	x0, #7
	cset	w0, eq
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB8_2:
	.cfi_restore_state
	adrp	x1, .L.str.142
	add	x1, x1, :lo12:.L.str.142
	bl	pts_throw_not_primitive
.Lfunc_end8:
	.size	pts_adapter_47, .Lfunc_end8-pts_adapter_47
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_Payload_constructor_arrow
	.type	pts_fn_Payload_constructor_arrow,@function
pts_fn_Payload_constructor_arrow:       // @pts_fn_Payload_constructor_arrow
	.cfi_startproc
// %bb.0:
	ldr	d0, [x0, #16]
	fadd	d0, d0, d0
	ret
.Lfunc_end9:
	.size	pts_fn_Payload_constructor_arrow, .Lfunc_end9-pts_fn_Payload_constructor_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_Payload_constructor_arrow
	.type	pts_dynamic_fn_Payload_constructor_arrow,@function
pts_dynamic_fn_Payload_constructor_arrow: // @pts_dynamic_fn_Payload_constructor_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end10:
	.size	pts_dynamic_fn_Payload_constructor_arrow, .Lfunc_end10-pts_dynamic_fn_Payload_constructor_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_sync_AtomicInt_load
	.type	pts_entry_sync_AtomicInt_load,@function
pts_entry_sync_AtomicInt_load:          // @pts_entry_sync_AtomicInt_load
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB11_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB11_4
// %bb.2:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_atomic_load
.LBB11_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB11_4:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end11:
	.size	pts_entry_sync_AtomicInt_load, .Lfunc_end11-pts_entry_sync_AtomicInt_load
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_sync_AtomicInt_load
	.type	pts_dynamic_entry_sync_AtomicInt_load,@function
pts_dynamic_entry_sync_AtomicInt_load:  // @pts_dynamic_entry_sync_AtomicInt_load
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB12_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB12_4
// %bb.2:
	bl	pts_atomic_load
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_from_i64
.LBB12_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB12_4:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end12:
	.size	pts_dynamic_entry_sync_AtomicInt_load, .Lfunc_end12-pts_dynamic_entry_sync_AtomicInt_load
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_sync_AtomicInt_store
	.type	pts_entry_sync_AtomicInt_store,@function
pts_entry_sync_AtomicInt_store:         // @pts_entry_sync_AtomicInt_store
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB13_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB13_4
// %bb.2:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_atomic_store
.LBB13_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB13_4:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end13:
	.size	pts_entry_sync_AtomicInt_store, .Lfunc_end13-pts_entry_sync_AtomicInt_store
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_sync_AtomicInt_store
	.type	pts_dynamic_entry_sync_AtomicInt_store,@function
pts_dynamic_entry_sync_AtomicInt_store: // @pts_dynamic_entry_sync_AtomicInt_store
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB14_2
// %bb.1:
	ldr	x20, [x2]
	b	.LBB14_3
.LBB14_2:
	mov	w20, #10                        // =0xa
.LBB14_3:
	mov	x0, x20
	mov	w1, #9                          // =0x9
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB14_9
// %bb.4:
	mov	x0, x20
	bl	pts_value_as_i64
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB14_7
// %bb.5:
	mov	x1, x0
	ldr	x0, [x19, #8]
	cbz	x0, .LBB14_8
// %bb.6:
	bl	pts_atomic_store
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB14_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB14_8:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB14_9:
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x20
	bl	pts_throw_type_mismatch
.Lfunc_end14:
	.size	pts_dynamic_entry_sync_AtomicInt_store, .Lfunc_end14-pts_dynamic_entry_sync_AtomicInt_store
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_sync_AtomicInt_add
	.type	pts_entry_sync_AtomicInt_add,@function
pts_entry_sync_AtomicInt_add:           // @pts_entry_sync_AtomicInt_add
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB15_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB15_4
// %bb.2:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_atomic_add
.LBB15_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB15_4:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end15:
	.size	pts_entry_sync_AtomicInt_add, .Lfunc_end15-pts_entry_sync_AtomicInt_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_sync_AtomicInt_add
	.type	pts_dynamic_entry_sync_AtomicInt_add,@function
pts_dynamic_entry_sync_AtomicInt_add:   // @pts_dynamic_entry_sync_AtomicInt_add
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB16_2
// %bb.1:
	ldr	x20, [x2]
	b	.LBB16_3
.LBB16_2:
	mov	w20, #10                        // =0xa
.LBB16_3:
	mov	x0, x20
	mov	w1, #9                          // =0x9
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB16_9
// %bb.4:
	mov	x0, x20
	bl	pts_value_as_i64
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB16_7
// %bb.5:
	mov	x1, x0
	ldr	x0, [x19, #8]
	cbz	x0, .LBB16_8
// %bb.6:
	bl	pts_atomic_add
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_from_i64
.LBB16_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB16_8:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB16_9:
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x20
	bl	pts_throw_type_mismatch
.Lfunc_end16:
	.size	pts_dynamic_entry_sync_AtomicInt_add, .Lfunc_end16-pts_dynamic_entry_sync_AtomicInt_add
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_sync_AtomicInt_compareExchange
	.type	pts_entry_sync_AtomicInt_compareExchange,@function
pts_entry_sync_AtomicInt_compareExchange: // @pts_entry_sync_AtomicInt_compareExchange
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB17_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB17_4
// %bb.2:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_atomic_compare_exchange
.LBB17_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB17_4:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end17:
	.size	pts_entry_sync_AtomicInt_compareExchange, .Lfunc_end17-pts_entry_sync_AtomicInt_compareExchange
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_sync_AtomicInt_compareExchange
	.type	pts_dynamic_entry_sync_AtomicInt_compareExchange,@function
pts_dynamic_entry_sync_AtomicInt_compareExchange: // @pts_dynamic_entry_sync_AtomicInt_compareExchange
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	mov	x21, x2
	mov	w20, w1
	mov	x19, x0
	cbz	w1, .LBB18_2
// %bb.1:
	ldr	x22, [x21]
	b	.LBB18_3
.LBB18_2:
	mov	w22, #10                        // =0xa
.LBB18_3:
	mov	x0, x22
	mov	w1, #9                          // =0x9
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB18_13
// %bb.4:
	mov	x0, x22
	bl	pts_value_as_i64
	cmp	w20, #2
	mov	x20, x0
	b.lo	.LBB18_6
// %bb.5:
	ldr	x21, [x21, #8]
	b	.LBB18_7
.LBB18_6:
	mov	w21, #10                        // =0xa
.LBB18_7:
	mov	x0, x21
	mov	w1, #9                          // =0x9
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB18_14
// %bb.8:
	mov	x0, x21
	bl	pts_value_as_i64
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB18_11
// %bb.9:
	mov	x2, x0
	ldr	x0, [x19, #8]
	cbz	x0, .LBB18_12
// %bb.10:
	mov	x1, x20
	bl	pts_atomic_compare_exchange
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_from_i64
.LBB18_11:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB18_12:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB18_13:
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x22
	bl	pts_throw_type_mismatch
.LBB18_14:
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x21
	bl	pts_throw_type_mismatch
.Lfunc_end18:
	.size	pts_dynamic_entry_sync_AtomicInt_compareExchange, .Lfunc_end18-pts_dynamic_entry_sync_AtomicInt_compareExchange
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_31
	.type	pts_adapt_31,@function
pts_adapt_31:                           // @pts_adapt_31
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_31
	add	x0, x0, :lo12:pts_type_adapter_31
	bl	pts_object_new
	adrp	x8, pts_adapter_31
	add	x8, x8, :lo12:pts_adapter_31
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end19:
	.size	pts_adapt_31, .Lfunc_end19-pts_adapt_31
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_31
	.type	pts_adapter_31,@function
pts_adapter_31:                         // @pts_adapter_31
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	bl	pts_dynamic_call_closure
	mov	w1, #9                          // =0x9
	mov	x19, x0
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB20_2
// %bb.1:
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_as_i64
.LBB20_2:
	.cfi_restore_state
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x19
	bl	pts_throw_type_mismatch
.Lfunc_end20:
	.size	pts_adapter_31, .Lfunc_end20-pts_adapter_31
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_32
	.type	pts_adapt_32,@function
pts_adapt_32:                           // @pts_adapt_32
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_32
	add	x0, x0, :lo12:pts_type_adapter_32
	bl	pts_object_new
	adrp	x8, pts_adapter_32
	add	x8, x8, :lo12:pts_adapter_32
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end21:
	.size	pts_adapt_32, .Lfunc_end21-pts_adapt_32
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_32
	.type	pts_adapter_32,@function
pts_adapter_32:                         // @pts_adapter_32
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	mov	x0, x1
	bl	pts_value_from_i64
	ldr	x8, [x19, #16]
	str	x0, [x29, #24]
	add	x2, x29, #24
	mov	w1, #1                          // =0x1
	mov	x0, x8
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end22:
	.size	pts_adapter_32, .Lfunc_end22-pts_adapter_32
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_33
	.type	pts_adapt_33,@function
pts_adapt_33:                           // @pts_adapt_33
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_33
	add	x0, x0, :lo12:pts_type_adapter_33
	bl	pts_object_new
	adrp	x8, pts_adapter_33
	add	x8, x8, :lo12:pts_adapter_33
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end23:
	.size	pts_adapt_33, .Lfunc_end23-pts_adapt_33
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_33
	.type	pts_adapter_33,@function
pts_adapter_33:                         // @pts_adapter_33
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	mov	x0, x1
	bl	pts_value_from_i64
	ldr	x8, [x19, #16]
	str	x0, [x29, #24]
	add	x2, x29, #24
	mov	w1, #1                          // =0x1
	mov	x0, x8
	bl	pts_dynamic_call_closure
	mov	w1, #9                          // =0x9
	mov	x19, x0
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB24_2
// %bb.1:
	mov	x0, x19
	bl	pts_value_as_i64
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB24_2:
	.cfi_restore_state
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x19
	bl	pts_throw_type_mismatch
.Lfunc_end24:
	.size	pts_adapter_33, .Lfunc_end24-pts_adapter_33
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_34
	.type	pts_adapt_34,@function
pts_adapt_34:                           // @pts_adapt_34
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_34
	add	x0, x0, :lo12:pts_type_adapter_34
	bl	pts_object_new
	adrp	x8, pts_adapter_34
	add	x8, x8, :lo12:pts_adapter_34
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end25:
	.size	pts_adapt_34, .Lfunc_end25-pts_adapt_34
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_34
	.type	pts_adapter_34,@function
pts_adapter_34:                         // @pts_adapter_34
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x20, x0
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_from_i64
	str	x0, [sp]
	mov	x0, x19
	bl	pts_value_from_i64
	ldr	x8, [x20, #16]
	str	x0, [sp, #8]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	mov	x0, x8
	bl	pts_dynamic_call_closure
	mov	w1, #9                          // =0x9
	mov	x19, x0
	bl	pts_value_is_integer_of
	tbz	w0, #0, .LBB26_2
// %bb.1:
	mov	x0, x19
	bl	pts_value_as_i64
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB26_2:
	.cfi_restore_state
	adrp	x1, .L.str.155
	add	x1, x1, :lo12:.L.str.155
	mov	x0, x19
	bl	pts_throw_type_mismatch
.Lfunc_end26:
	.size	pts_adapter_34, .Lfunc_end26-pts_adapter_34
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_Range_get_length
	.type	pts_entry_parallel_Range_get_length,@function
pts_entry_parallel_Range_get_length:    // @pts_entry_parallel_Range_get_length
	.cfi_startproc
// %bb.0:
	ldp	d1, d0, [x0, #8]
	fsub	d1, d0, d1
	fcmp	d1, d1
	b.vs	.LBB27_4
// %bb.1:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.ne	.LBB27_3
// %bb.2:
	ret
.LBB27_3:
	fcsel	d0, d0, d1, mi
	ret
.LBB27_4:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	ret
.Lfunc_end27:
	.size	pts_entry_parallel_Range_get_length, .Lfunc_end27-pts_entry_parallel_Range_get_length
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_Range_get_par
	.type	pts_entry_parallel_Range_get_par,@function
pts_entry_parallel_Range_get_par:       // @pts_entry_parallel_Range_get_par
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-32]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset b8, -24
	.cfi_offset b9, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB28_6
// %bb.1:
	adrp	x8, pts_global_parallel_ParallelRange_class_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_ParallelRange_class_ready]
	tbz	w8, #0, .LBB28_7
// %bb.2:
	ldp	d8, d0, [x0, #8]
	fsub	d0, d0, d8
	fcmp	d0, d0
	b.vs	.LBB28_8
// %bb.3:
	movi	d9, #0000000000000000
	fcmp	d0, #0.0
	b.eq	.LBB28_5
// %bb.4:
	movi	d1, #0000000000000000
	fcsel	d9, d1, d0, mi
.LBB28_5:
	adrp	x0, pts_type_parallel_ParallelRange
	add	x0, x0, :lo12:pts_type_parallel_ParallelRange
	bl	pts_object_new
	stp	d8, d9, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #32               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB28_6:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB28_7:
	adrp	x0, .L.str.167
	add	x0, x0, :lo12:.L.str.167
	bl	pts_throw_uninitialized
.LBB28_8:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d9, x8
	b	.LBB28_5
.Lfunc_end28:
	.size	pts_entry_parallel_Range_get_par, .Lfunc_end28-pts_entry_parallel_Range_get_par
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_Range_toArray
	.type	pts_entry_parallel_Range_toArray,@function
pts_entry_parallel_Range_toArray:       // @pts_entry_parallel_Range_toArray
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB29_8
// %bb.1:
	ldp	d1, d0, [x0, #8]
	mov	x19, x0
	fsub	d1, d0, d1
	fcmp	d1, d1
	b.vs	.LBB29_9
// %bb.2:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.eq	.LBB29_4
// %bb.3:
	fcsel	d0, d0, d1, mi
.LBB29_4:
	adrp	x8, :got:pts_array_types
	ldr	x8, [x8, :got_lo12:pts_array_types]
	add	x0, x8, #136
	bl	pts_array_of_length
	add	x8, x0, #16
	mov	x20, x0
	ldar	x8, [x8]
	cbz	x8, .LBB29_7
// %bb.5:
	movi	d8, #0000000000000000
	fmov	d9, #1.00000000
.LBB29_6:                               // =>This Inner Loop Header: Depth=1
	ldr	d0, [x19, #8]
	add	x1, sp, #8
	mov	x0, x20
	fadd	d0, d8, d0
	str	d0, [sp, #8]
	fmov	d0, d8
	bl	pts_array_set
	add	x8, x20, #16
	fadd	d8, d8, d9
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d8, d0
	b.mi	.LBB29_6
.LBB29_7:
	mov	x0, x20
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB29_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB29_9:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB29_4
.Lfunc_end29:
	.size	pts_entry_parallel_Range_toArray, .Lfunc_end29-pts_entry_parallel_Range_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_Range_toArray
	.type	pts_dynamic_entry_parallel_Range_toArray,@function
pts_dynamic_entry_parallel_Range_toArray: // @pts_dynamic_entry_parallel_Range_toArray
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB30_8
// %bb.1:
	ldp	d1, d0, [x0, #8]
	mov	x19, x0
	fsub	d1, d0, d1
	fcmp	d1, d1
	b.vs	.LBB30_9
// %bb.2:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.eq	.LBB30_4
// %bb.3:
	fcsel	d0, d0, d1, mi
.LBB30_4:
	adrp	x8, :got:pts_array_types
	ldr	x8, [x8, :got_lo12:pts_array_types]
	add	x0, x8, #136
	bl	pts_array_of_length
	add	x8, x0, #16
	mov	x20, x0
	ldar	x8, [x8]
	cbz	x8, .LBB30_7
// %bb.5:
	movi	d8, #0000000000000000
	fmov	d9, #1.00000000
.LBB30_6:                               // =>This Inner Loop Header: Depth=1
	ldr	d0, [x19, #8]
	add	x1, sp, #8
	mov	x0, x20
	fadd	d0, d8, d0
	str	d0, [sp, #8]
	fmov	d0, d8
	bl	pts_array_set
	add	x8, x20, #16
	fadd	d8, d8, d9
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d8, d0
	b.mi	.LBB30_6
.LBB30_7:
	mov	x0, x20
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB30_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB30_9:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB30_4
.Lfunc_end30:
	.size	pts_dynamic_entry_parallel_Range_toArray, .Lfunc_end30-pts_dynamic_entry_parallel_Range_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_Range__u0040_u0040iterator_
	.type	pts_entry_parallel_Range__u0040_u0040iterator_,@function
pts_entry_parallel_Range__u0040_u0040iterator_: // @pts_entry_parallel_Range__u0040_u0040iterator_
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x1, pts_step_fn_parallel_Range__u0040_u0040iterator_
	add	x1, x1, :lo12:pts_step_fn_parallel_Range__u0040_u0040iterator_
	mov	w0, #96                         // =0x60
	bl	pts_generator_new
	str	x19, [x0, #80]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end31:
	.size	pts_entry_parallel_Range__u0040_u0040iterator_, .Lfunc_end31-pts_entry_parallel_Range__u0040_u0040iterator_
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_Range__u0040_u0040iterator_
	.type	pts_dynamic_entry_parallel_Range__u0040_u0040iterator_,@function
pts_dynamic_entry_parallel_Range__u0040_u0040iterator_: // @pts_dynamic_entry_parallel_Range__u0040_u0040iterator_
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x1, pts_step_fn_parallel_Range__u0040_u0040iterator_
	add	x1, x1, :lo12:pts_step_fn_parallel_Range__u0040_u0040iterator_
	mov	w0, #96                         // =0x60
	bl	pts_generator_new
	str	x19, [x0, #80]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end32:
	.size	pts_dynamic_entry_parallel_Range__u0040_u0040iterator_, .Lfunc_end32-pts_dynamic_entry_parallel_Range__u0040_u0040iterator_
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_forEach
	.type	pts_entry_parallel_ParallelRange_forEach,@function
pts_entry_parallel_ParallelRange_forEach: // @pts_entry_parallel_ParallelRange_forEach
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB33_2
// %bb.1:
	mov	x20, x0
	ldr	d8, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_forEach_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_forEach_arrow
	mov	x19, x1
	bl	pts_object_new
	ldr	d0, [x20, #16]
	adrp	x8, pts_fn_parallel_ParallelRange_forEach_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_forEach_arrow
	stp	x8, x19, [x0, #8]
	str	d8, [x0, #24]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	b	pts_parallel_for
.LBB33_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end33:
	.size	pts_entry_parallel_ParallelRange_forEach, .Lfunc_end33-pts_entry_parallel_ParallelRange_forEach
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_forEach
	.type	pts_dynamic_entry_parallel_ParallelRange_forEach,@function
pts_dynamic_entry_parallel_ParallelRange_forEach: // @pts_dynamic_entry_parallel_ParallelRange_forEach
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB34_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB34_3
.LBB34_2:
	mov	w0, #10                         // =0xa
.LBB34_3:
	adrp	x1, pts_check_38
	add	x1, x1, :lo12:pts_check_38
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB34_5
// %bb.4:
	mov	x20, x0
	ldr	d8, [x19, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_forEach_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_forEach_arrow
	bl	pts_object_new
	ldr	d0, [x19, #16]
	adrp	x8, pts_fn_parallel_ParallelRange_forEach_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_forEach_arrow
	str	x8, [x0, #8]
	str	x20, [x0, #16]
	str	d8, [x0, #24]
	bl	pts_parallel_for
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB34_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end34:
	.size	pts_dynamic_entry_parallel_ParallelRange_forEach, .Lfunc_end34-pts_dynamic_entry_parallel_ParallelRange_forEach
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_filter
	.type	pts_entry_parallel_ParallelRange_filter,@function
pts_entry_parallel_ParallelRange_filter: // @pts_entry_parallel_ParallelRange_filter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB35_2
// %bb.1:
	mov	x19, x0
	ldr	d8, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_filter_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_filter_arrow
	mov	x20, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_filter_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_filter_arrow
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	str	d8, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelRange_filter_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_filter_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_filter_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_filter_adapter
	mov	x20, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_filter_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_filter_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_filter_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_filter_adapter_2
	adrp	x9, pts_static_parallel_ParallelRange_filter_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelRange_filter_arrow_2
	ldr	d0, [x19, #16]
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	mov	x0, x20
	bl	pts_parallel_reduce
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	b	pts_value_convert
.LBB35_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end35:
	.size	pts_entry_parallel_ParallelRange_filter, .Lfunc_end35-pts_entry_parallel_ParallelRange_filter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_filter
	.type	pts_dynamic_entry_parallel_ParallelRange_filter,@function
pts_dynamic_entry_parallel_ParallelRange_filter: // @pts_dynamic_entry_parallel_ParallelRange_filter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB36_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB36_3
.LBB36_2:
	mov	w0, #10                         // =0xa
.LBB36_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_entry_parallel_ParallelRange_filter
.Lfunc_end36:
	.size	pts_dynamic_entry_parallel_ParallelRange_filter, .Lfunc_end36-pts_dynamic_entry_parallel_ParallelRange_filter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_reduce
	.type	pts_entry_parallel_ParallelRange_reduce,@function
pts_entry_parallel_ParallelRange_reduce: // @pts_entry_parallel_ParallelRange_reduce
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB37_6
// %bb.1:
	ldr	d1, [x0, #16]
	fcmp	d1, #0.0
	b.ne	.LBB37_3
// %bb.2:
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB37_3:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x8, pts_type_closure_parallel_ParallelRange_reduce_arrow
	add	x8, x8, :lo12:pts_type_closure_parallel_ParallelRange_reduce_arrow
	ldr	d9, [x0, #8]
	mov	x22, x0
	mov	x0, x8
	mov	x19, x1
	fmov	d8, d0
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_reduce_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_reduce_arrow
	mov	x20, x0
	str	x8, [x0, #8]
	str	d9, [x0, #16]
	str	x19, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelRange_reduce_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_reduce_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_reduce_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_reduce_adapter
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_reduce_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_reduce_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_reduce_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_reduce_arrow_2
	mov	x20, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_reduce_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_reduce_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_reduce_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_reduce_adapter_2
	ldr	d0, [x22, #16]
	mov	x1, x0
	stp	x8, x20, [x0, #8]
	mov	x0, x21
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	ldr	x1, [x19, #8]
	cbz	x8, .LBB37_7
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
.LBB37_5:
	mov	x0, x19
	fmov	d0, d8
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	br	x1
.LBB37_6:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB37_7:
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	fmov	d1, d0
	ldr	x1, [sp, #8]                    // 8-byte Folded Reload
	b	.LBB37_5
.Lfunc_end37:
	.size	pts_entry_parallel_ParallelRange_reduce, .Lfunc_end37-pts_entry_parallel_ParallelRange_reduce
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_reduce
	.type	pts_dynamic_entry_parallel_ParallelRange_reduce,@function
pts_dynamic_entry_parallel_ParallelRange_reduce: // @pts_dynamic_entry_parallel_ParallelRange_reduce
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	x19, x0
	cbz	w1, .LBB38_3
// %bb.1:
	ldr	x0, [x2]
	mov	w20, w1
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	x21, x2
	bl	pts_value_convert
	cmp	w20, #1
	mov	x20, x0
	b.ne	.LBB38_5
// %bb.2:
	mov	w21, #10                        // =0xa
	b	.LBB38_4
.LBB38_3:
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	w0, #10                         // =0xa
	mov	w21, #10                        // =0xa
	bl	pts_value_convert
	mov	x20, x0
.LBB38_4:
	mov	x0, x21
	bl	pts_value_to_number_slow
	b	.LBB38_7
.LBB38_5:
	ldr	x21, [x21, #8]
	lsr	x8, x21, #49
	cbz	x8, .LBB38_4
// %bb.6:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x21, x8
	fmov	d0, x8
.LBB38_7:
	mov	x0, x19
	mov	x1, x20
	bl	pts_entry_parallel_ParallelRange_reduce
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end38:
	.size	pts_dynamic_entry_parallel_ParallelRange_reduce, .Lfunc_end38-pts_dynamic_entry_parallel_ParallelRange_reduce
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_some
	.type	pts_entry_parallel_ParallelRange_some,@function
pts_entry_parallel_ParallelRange_some:  // @pts_entry_parallel_ParallelRange_some
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB39_5
// %bb.1:
	bl	pts_fn_parallel_ParallelRange_findFound
	adrp	x8, pts_fn_parallel_ParallelRange_some.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_some.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB39_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB39_4
.LBB39_3:
	adrp	x1, pts_fn_parallel_ParallelRange_some.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_some.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB39_4:
	ldrb	w0, [x0]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB39_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end39:
	.size	pts_entry_parallel_ParallelRange_some, .Lfunc_end39-pts_entry_parallel_ParallelRange_some
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_some
	.type	pts_dynamic_entry_parallel_ParallelRange_some,@function
pts_dynamic_entry_parallel_ParallelRange_some: // @pts_dynamic_entry_parallel_ParallelRange_some
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB40_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB40_3
.LBB40_2:
	mov	w0, #10                         // =0xa
.LBB40_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB40_8
// %bb.4:
	mov	x1, x0
	mov	x0, x19
	bl	pts_fn_parallel_ParallelRange_findFound
	adrp	x8, pts_fn_parallel_ParallelRange_some.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_some.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB40_6
// %bb.5:
	add	x0, x0, x8, lsr #48
	b	.LBB40_7
.LBB40_6:
	adrp	x1, pts_fn_parallel_ParallelRange_some.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_some.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB40_7:
	ldrb	w8, [x0]
	cmp	w8, #0
	mov	w8, #6                          // =0x6
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB40_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end40:
	.size	pts_dynamic_entry_parallel_ParallelRange_some, .Lfunc_end40-pts_dynamic_entry_parallel_ParallelRange_some
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_every
	.type	pts_entry_parallel_ParallelRange_every,@function
pts_entry_parallel_ParallelRange_every: // @pts_entry_parallel_ParallelRange_every
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB41_5
// %bb.1:
	mov	x19, x0
	adrp	x0, pts_type_closure_parallel_ParallelRange_every_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_every_arrow
	mov	x20, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_every_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_every_arrow
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_every_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_every_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_every_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_every_adapter
	mov	x1, x0
	stp	x8, x21, [x0, #8]
	mov	x0, x19
	bl	pts_fn_parallel_ParallelRange_findFound
	adrp	x8, pts_fn_parallel_ParallelRange_every.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_every.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB41_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB41_4
.LBB41_3:
	adrp	x1, pts_fn_parallel_ParallelRange_every.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_every.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB41_4:
	ldrb	w8, [x0]
	cmp	w8, #0
	cset	w0, eq
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB41_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end41:
	.size	pts_entry_parallel_ParallelRange_every, .Lfunc_end41-pts_entry_parallel_ParallelRange_every
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_every
	.type	pts_dynamic_entry_parallel_ParallelRange_every,@function
pts_dynamic_entry_parallel_ParallelRange_every: // @pts_dynamic_entry_parallel_ParallelRange_every
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB42_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB42_3
.LBB42_2:
	mov	w0, #10                         // =0xa
.LBB42_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	bl	pts_entry_parallel_ParallelRange_every
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end42:
	.size	pts_dynamic_entry_parallel_ParallelRange_every, .Lfunc_end42-pts_dynamic_entry_parallel_ParallelRange_every
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_find
	.type	pts_entry_parallel_ParallelRange_find,@function
pts_entry_parallel_ParallelRange_find:  // @pts_entry_parallel_ParallelRange_find
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB43_5
// %bb.1:
	bl	pts_fn_parallel_ParallelRange_findFound
	adrp	x8, pts_fn_parallel_ParallelRange_find.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_find.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB43_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB43_4
.LBB43_3:
	adrp	x1, pts_fn_parallel_ParallelRange_find.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_find.pts_site1
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_address_slow
.LBB43_4:
	ldr	x0, [x0]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB43_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end43:
	.size	pts_entry_parallel_ParallelRange_find, .Lfunc_end43-pts_entry_parallel_ParallelRange_find
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_find
	.type	pts_dynamic_entry_parallel_ParallelRange_find,@function
pts_dynamic_entry_parallel_ParallelRange_find: // @pts_dynamic_entry_parallel_ParallelRange_find
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB44_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB44_3
.LBB44_2:
	mov	w0, #10                         // =0xa
.LBB44_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB44_8
// %bb.4:
	mov	x1, x0
	mov	x0, x19
	bl	pts_fn_parallel_ParallelRange_findFound
	adrp	x8, pts_fn_parallel_ParallelRange_find.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_find.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB44_6
// %bb.5:
	add	x0, x0, x8, lsr #48
	b	.LBB44_7
.LBB44_6:
	adrp	x1, pts_fn_parallel_ParallelRange_find.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_find.pts_site1
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_address_slow
.LBB44_7:
	ldr	x0, [x0]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB44_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end44:
	.size	pts_dynamic_entry_parallel_ParallelRange_find, .Lfunc_end44-pts_dynamic_entry_parallel_ParallelRange_find
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_count
	.type	pts_entry_parallel_ParallelRange_count,@function
pts_entry_parallel_ParallelRange_count: // @pts_entry_parallel_ParallelRange_count
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB45_3
// %bb.1:
	mov	x19, x0
	ldr	d8, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_count_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_count_arrow
	mov	x20, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_count_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_count_arrow
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	str	d8, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelRange_count_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_count_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_count_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_count_adapter
	mov	x20, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_count_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_count_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_count_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_count_adapter_2
	adrp	x9, pts_static_parallel_ParallelRange_count_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelRange_count_arrow_2
	ldr	d0, [x19, #16]
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	mov	x0, x20
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	cbz	x8, .LBB45_4
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB45_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB45_4:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	b	pts_value_to_number_slow
.Lfunc_end45:
	.size	pts_entry_parallel_ParallelRange_count, .Lfunc_end45-pts_entry_parallel_ParallelRange_count
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_count
	.type	pts_dynamic_entry_parallel_ParallelRange_count,@function
pts_dynamic_entry_parallel_ParallelRange_count: // @pts_dynamic_entry_parallel_ParallelRange_count
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB46_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB46_3
.LBB46_2:
	mov	w0, #10                         // =0xa
.LBB46_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	bl	pts_entry_parallel_ParallelRange_count
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end46:
	.size	pts_dynamic_entry_parallel_ParallelRange_count, .Lfunc_end46-pts_dynamic_entry_parallel_ParallelRange_count
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_sum
	.type	pts_entry_parallel_ParallelRange_sum,@function
pts_entry_parallel_ParallelRange_sum:   // @pts_entry_parallel_ParallelRange_sum
	.cfi_startproc
// %bb.0:
	fmov	d0, #-1.00000000
	ldp	d2, d1, [x0, #8]
	fmov	d3, #0.50000000
	fadd	d0, d1, d0
	fmul	d0, d1, d0
	fmul	d1, d1, d2
	fmul	d0, d0, d3
	fadd	d0, d1, d0
	ret
.Lfunc_end47:
	.size	pts_entry_parallel_ParallelRange_sum, .Lfunc_end47-pts_entry_parallel_ParallelRange_sum
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_sum
	.type	pts_dynamic_entry_parallel_ParallelRange_sum,@function
pts_dynamic_entry_parallel_ParallelRange_sum: // @pts_dynamic_entry_parallel_ParallelRange_sum
	.cfi_startproc
// %bb.0:
	fmov	d0, #-1.00000000
	ldp	d2, d1, [x0, #8]
	fmov	d3, #0.50000000
	mov	x9, #562949953421312            // =0x2000000000000
	fadd	d0, d1, d0
	fmul	d0, d1, d0
	fmul	d1, d1, d2
	fmul	d0, d0, d3
	fadd	d0, d1, d0
	fmov	x8, d0
	fcmp	d0, d0
	add	x8, x8, x9
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	ret
.Lfunc_end48:
	.size	pts_dynamic_entry_parallel_ParallelRange_sum, .Lfunc_end48-pts_dynamic_entry_parallel_ParallelRange_sum
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_min
	.type	pts_entry_parallel_ParallelRange_min,@function
pts_entry_parallel_ParallelRange_min:   // @pts_entry_parallel_ParallelRange_min
	.cfi_startproc
// %bb.0:
	ldr	d0, [x0, #16]
	fcmp	d0, #0.0
	b.le	.LBB49_2
// %bb.1:
	ldr	d0, [x0, #8]
	ret
.LBB49_2:
	mov	x8, #9218868437227405312        // =0x7ff0000000000000
	fmov	d0, x8
	ret
.Lfunc_end49:
	.size	pts_entry_parallel_ParallelRange_min, .Lfunc_end49-pts_entry_parallel_ParallelRange_min
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_min
	.type	pts_dynamic_entry_parallel_ParallelRange_min,@function
pts_dynamic_entry_parallel_ParallelRange_min: // @pts_dynamic_entry_parallel_ParallelRange_min
	.cfi_startproc
// %bb.0:
	ldr	d0, [x0, #16]
	fcmp	d0, #0.0
	b.le	.LBB50_2
// %bb.1:
	ldr	d0, [x0, #8]
	b	.LBB50_3
.LBB50_2:
	mov	x8, #9218868437227405312        // =0x7ff0000000000000
	fmov	d0, x8
.LBB50_3:
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	add	x8, x8, x9
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	ret
.Lfunc_end50:
	.size	pts_dynamic_entry_parallel_ParallelRange_min, .Lfunc_end50-pts_dynamic_entry_parallel_ParallelRange_min
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_max
	.type	pts_entry_parallel_ParallelRange_max,@function
pts_entry_parallel_ParallelRange_max:   // @pts_entry_parallel_ParallelRange_max
	.cfi_startproc
// %bb.0:
	ldr	d0, [x0, #16]
	fcmp	d0, #0.0
	b.le	.LBB51_2
// %bb.1:
	ldr	d1, [x0, #8]
	fadd	d0, d0, d1
	fmov	d1, #-1.00000000
	fadd	d0, d0, d1
	ret
.LBB51_2:
	mov	x8, #-4503599627370496          // =0xfff0000000000000
	fmov	d0, x8
	ret
.Lfunc_end51:
	.size	pts_entry_parallel_ParallelRange_max, .Lfunc_end51-pts_entry_parallel_ParallelRange_max
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_max
	.type	pts_dynamic_entry_parallel_ParallelRange_max,@function
pts_dynamic_entry_parallel_ParallelRange_max: // @pts_dynamic_entry_parallel_ParallelRange_max
	.cfi_startproc
// %bb.0:
	ldr	d0, [x0, #16]
	fcmp	d0, #0.0
	b.le	.LBB52_2
// %bb.1:
	ldr	d1, [x0, #8]
	fadd	d0, d0, d1
	fmov	d1, #-1.00000000
	fadd	d0, d0, d1
	b	.LBB52_3
.LBB52_2:
	mov	x8, #-4503599627370496          // =0xfff0000000000000
	fmov	d0, x8
.LBB52_3:
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	add	x8, x8, x9
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	ret
.Lfunc_end52:
	.size	pts_dynamic_entry_parallel_ParallelRange_max, .Lfunc_end52-pts_dynamic_entry_parallel_ParallelRange_max
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_sort
	.type	pts_entry_parallel_ParallelRange_sort,@function
pts_entry_parallel_ParallelRange_sort:  // @pts_entry_parallel_ParallelRange_sort
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB53_2
// %bb.1:
	mov	x20, x0
	adrp	x0, pts_type_parallel_ParallelArray
	add	x0, x0, :lo12:pts_type_parallel_ParallelArray
	mov	x19, x1
	bl	pts_object_new
	mov	x21, x0
	mov	x0, x20
	bl	pts_fn_parallel_ParallelRange_toArray
	mov	x8, x0
	mov	x0, x21
	mov	x1, x19
	mov	w2, #1                          // =0x1
	str	x8, [x21, #8]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_ParallelArray_sort
.LBB53_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end53:
	.size	pts_entry_parallel_ParallelRange_sort, .Lfunc_end53-pts_entry_parallel_ParallelRange_sort
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_sort
	.type	pts_dynamic_entry_parallel_ParallelRange_sort,@function
pts_dynamic_entry_parallel_ParallelRange_sort: // @pts_dynamic_entry_parallel_ParallelRange_sort
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB54_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB54_3
.LBB54_2:
	mov	w0, #10                         // =0xa
.LBB54_3:
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB54_5
// %bb.4:
	mov	x20, x0
	adrp	x0, pts_type_parallel_ParallelArray
	add	x0, x0, :lo12:pts_type_parallel_ParallelArray
	bl	pts_object_new
	mov	x21, x0
	mov	x0, x19
	bl	pts_fn_parallel_ParallelRange_toArray
	mov	x8, x0
	mov	x0, x21
	mov	x1, x20
	mov	w2, #1                          // =0x1
	str	x8, [x21, #8]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_ParallelArray_sort
.LBB54_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end54:
	.size	pts_dynamic_entry_parallel_ParallelRange_sort, .Lfunc_end54-pts_dynamic_entry_parallel_ParallelRange_sort
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_toArray
	.type	pts_entry_parallel_ParallelRange_toArray,@function
pts_entry_parallel_ParallelRange_toArray: // @pts_entry_parallel_ParallelRange_toArray
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelRange_toArray
.Lfunc_end55:
	.size	pts_entry_parallel_ParallelRange_toArray, .Lfunc_end55-pts_entry_parallel_ParallelRange_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_toArray
	.type	pts_dynamic_entry_parallel_ParallelRange_toArray,@function
pts_dynamic_entry_parallel_ParallelRange_toArray: // @pts_dynamic_entry_parallel_ParallelRange_toArray
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelRange_toArray
.Lfunc_end56:
	.size	pts_dynamic_entry_parallel_ParallelRange_toArray, .Lfunc_end56-pts_dynamic_entry_parallel_ParallelRange_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelRange_findFound
	.type	pts_entry_parallel_ParallelRange_findFound,@function
pts_entry_parallel_ParallelRange_findFound: // @pts_entry_parallel_ParallelRange_findFound
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelRange_findFound
.Lfunc_end57:
	.size	pts_entry_parallel_ParallelRange_findFound, .Lfunc_end57-pts_entry_parallel_ParallelRange_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelRange_findFound
	.type	pts_dynamic_entry_parallel_ParallelRange_findFound,@function
pts_dynamic_entry_parallel_ParallelRange_findFound: // @pts_dynamic_entry_parallel_ParallelRange_findFound
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB58_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB58_3
.LBB58_2:
	mov	w0, #10                         // =0xa
.LBB58_3:
	adrp	x1, pts_check_23
	add	x1, x1, :lo12:pts_check_23
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_ParallelRange_findFound
.Lfunc_end58:
	.size	pts_dynamic_entry_parallel_ParallelRange_findFound, .Lfunc_end58-pts_dynamic_entry_parallel_ParallelRange_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_forEach_arrow
	.type	pts_fn_parallel_ParallelRange_forEach_arrow,@function
pts_fn_parallel_ParallelRange_forEach_arrow: // @pts_fn_parallel_ParallelRange_forEach_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-64]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	str	x19, [sp, #48]                  // 8-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB59_5
// %bb.1:
	fmov	d8, d1
	fmov	d9, d0
	fcmp	d0, d1
	b.pl	.LBB59_4
// %bb.2:
	fmov	d10, #1.00000000
	ldr	x19, [x0, #16]
	ldr	d11, [x0, #24]
.LBB59_3:                               // =>This Inner Loop Header: Depth=1
	fadd	d0, d11, d9
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fadd	d9, d9, d10
	fcmp	d9, d8
	b.mi	.LBB59_3
.LBB59_4:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldr	x19, [sp, #48]                  // 8-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #64             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB59_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end59:
	.size	pts_fn_parallel_ParallelRange_forEach_arrow, .Lfunc_end59-pts_fn_parallel_ParallelRange_forEach_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_forEach_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_forEach_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_forEach_arrow: // @pts_dynamic_fn_parallel_ParallelRange_forEach_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB60_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB60_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB60_7
.LBB60_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB60_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB60_9
.LBB60_5:
	mov	w0, #10                         // =0xa
.LBB60_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB60_3
.LBB60_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB60_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB60_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB60_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB60_8
.Lfunc_end60:
	.size	pts_dynamic_fn_parallel_ParallelRange_forEach_arrow, .Lfunc_end60-pts_dynamic_fn_parallel_ParallelRange_forEach_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_15
	.type	pts_adapt_15,@function
pts_adapt_15:                           // @pts_adapt_15
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_15
	add	x0, x0, :lo12:pts_type_adapter_15
	bl	pts_object_new
	adrp	x8, pts_adapter_15
	add	x8, x8, :lo12:pts_adapter_15
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end61:
	.size	pts_adapt_15, .Lfunc_end61-pts_adapt_15
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_15
	.type	pts_adapter_15,@function
pts_adapter_15:                         // @pts_adapter_15
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	add	x8, x8, x9
	csel	x8, x10, x8, vs
	fcmp	d1, d1
	add	x9, x11, x9
	csel	x9, x10, x9, vs
	stp	x8, x9, [sp]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end62:
	.size	pts_adapter_15, .Lfunc_end62-pts_adapter_15
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_38
	.type	pts_adapt_38,@function
pts_adapt_38:                           // @pts_adapt_38
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_38
	add	x0, x0, :lo12:pts_type_adapter_38
	bl	pts_object_new
	adrp	x8, pts_adapter_38
	add	x8, x8, :lo12:pts_adapter_38
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end63:
	.size	pts_adapt_38, .Lfunc_end63-pts_adapt_38
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_38
	.type	pts_adapter_38,@function
pts_adapter_38:                         // @pts_adapter_38
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	ldr	x0, [x0, #16]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	str	x8, [sp, #8]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end64:
	.size	pts_adapter_38, .Lfunc_end64-pts_adapter_38
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_39
	.type	pts_adapt_39,@function
pts_adapt_39:                           // @pts_adapt_39
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_39
	add	x0, x0, :lo12:pts_type_adapter_39
	bl	pts_object_new
	adrp	x8, pts_adapter_39
	add	x8, x8, :lo12:pts_adapter_39
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end65:
	.size	pts_adapt_39, .Lfunc_end65-pts_adapt_39
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_39
	.type	pts_adapter_39,@function
pts_adapter_39:                         // @pts_adapter_39
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end66:
	.size	pts_adapter_39, .Lfunc_end66-pts_adapter_39
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_filter_arrow
	.type	pts_fn_parallel_ParallelRange_filter_arrow,@function
pts_fn_parallel_ParallelRange_filter_arrow: // @pts_fn_parallel_ParallelRange_filter_arrow
	.cfi_startproc
// %bb.0:
	str	d12, [sp, #-80]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 80
	stp	d11, d10, [sp, #16]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_offset b12, -80
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB67_7
// %bb.1:
	adrp	x8, :got:pts_array_types
	ldr	x19, [x0, #16]
	ldr	d11, [x0, #24]
	ldr	x8, [x8, :got_lo12:pts_array_types]
	mov	x1, xzr
	mov	x2, xzr
	fmov	d8, d1
	fmov	d9, d0
	add	x0, x8, #136
	bl	pts_array_of
	fcmp	d9, d8
	mov	x20, x0
	b.pl	.LBB67_6
// %bb.2:
	fmov	d12, #1.00000000
	b	.LBB67_4
.LBB67_3:                               //   in Loop: Header=BB67_4 Depth=1
	fadd	d9, d9, d12
	fcmp	d9, d8
	b.pl	.LBB67_6
.LBB67_4:                               // =>This Inner Loop Header: Depth=1
	fadd	d10, d11, d9
	ldr	x8, [x19, #8]
	mov	x0, x19
	fmov	d0, d10
	blr	x8
	bl	pts_value_truthy
	tbz	w0, #0, .LBB67_3
// %bb.5:                               //   in Loop: Header=BB67_4 Depth=1
	add	x1, sp, #8
	mov	x0, x20
	mov	w2, #1                          // =0x1
	str	d10, [sp, #8]
	bl	pts_array_push
	b	.LBB67_3
.LBB67_6:
	mov	x0, x20
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             // 16-byte Folded Reload
	ldr	d12, [sp], #80                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	ret
.LBB67_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end67:
	.size	pts_fn_parallel_ParallelRange_filter_arrow, .Lfunc_end67-pts_fn_parallel_ParallelRange_filter_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_filter_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_filter_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_filter_arrow: // @pts_dynamic_fn_parallel_ParallelRange_filter_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB68_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB68_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB68_7
.LBB68_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB68_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB68_9
.LBB68_5:
	mov	w0, #10                         // =0xa
.LBB68_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB68_3
.LBB68_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB68_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB68_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB68_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB68_8
.Lfunc_end68:
	.size	pts_dynamic_fn_parallel_ParallelRange_filter_arrow, .Lfunc_end68-pts_dynamic_fn_parallel_ParallelRange_filter_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_16
	.type	pts_adapt_16,@function
pts_adapt_16:                           // @pts_adapt_16
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_16
	add	x0, x0, :lo12:pts_type_adapter_16
	bl	pts_object_new
	adrp	x8, pts_adapter_16
	add	x8, x8, :lo12:pts_adapter_16
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end69:
	.size	pts_adapt_16, .Lfunc_end69-pts_adapt_16
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_16
	.type	pts_adapter_16,@function
pts_adapter_16:                         // @pts_adapter_16
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	add	x8, x8, x9
	csel	x8, x10, x8, vs
	fcmp	d1, d1
	add	x9, x11, x9
	csel	x9, x10, x9, vs
	stp	x8, x9, [sp]
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end70:
	.size	pts_adapter_16, .Lfunc_end70-pts_adapter_16
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_filter_adapter
	.type	pts_fn_parallel_ParallelRange_filter_adapter,@function
pts_fn_parallel_ParallelRange_filter_adapter: // @pts_fn_parallel_ParallelRange_filter_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB71_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB71_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end71:
	.size	pts_fn_parallel_ParallelRange_filter_adapter, .Lfunc_end71-pts_fn_parallel_ParallelRange_filter_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_filter_adapter
	.type	pts_dynamic_fn_parallel_ParallelRange_filter_adapter,@function
pts_dynamic_fn_parallel_ParallelRange_filter_adapter: // @pts_dynamic_fn_parallel_ParallelRange_filter_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB72_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB72_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB72_7
.LBB72_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB72_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB72_9
.LBB72_5:
	mov	w0, #10                         // =0xa
.LBB72_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB72_3
.LBB72_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB72_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB72_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB72_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB72_8
.Lfunc_end72:
	.size	pts_dynamic_fn_parallel_ParallelRange_filter_adapter, .Lfunc_end72-pts_dynamic_fn_parallel_ParallelRange_filter_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_17
	.type	pts_adapt_17,@function
pts_adapt_17:                           // @pts_adapt_17
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_17
	add	x0, x0, :lo12:pts_type_adapter_17
	bl	pts_object_new
	adrp	x8, pts_adapter_17
	add	x8, x8, :lo12:pts_adapter_17
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end73:
	.size	pts_adapt_17, .Lfunc_end73-pts_adapt_17
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_17
	.type	pts_adapter_17,@function
pts_adapter_17:                         // @pts_adapter_17
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	add	x8, x8, x9
	csel	x8, x10, x8, vs
	fcmp	d1, d1
	add	x9, x11, x9
	csel	x9, x10, x9, vs
	stp	x8, x9, [sp]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end74:
	.size	pts_adapter_17, .Lfunc_end74-pts_adapter_17
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_filter_arrow_2
	.type	pts_fn_parallel_ParallelRange_filter_arrow_2,@function
pts_fn_parallel_ParallelRange_filter_arrow_2: // @pts_fn_parallel_ParallelRange_filter_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB75_2
// %bb.1:
	adrp	x20, pts_check_1
	add	x20, x20, :lo12:pts_check_1
	mov	x0, x1
	mov	x1, x20
	mov	x19, x2
	bl	pts_value_convert
	adrp	x8, :got:pts_array_types
	mov	x21, x0
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:pts_array_types]
	mov	x2, xzr
	add	x0, x8, #136
	bl	pts_array_of
	bl	pts_array_copy
	mov	x22, x0
	mov	x0, x19
	mov	x1, x20
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x22
	bl	pts_array_append
	mov	x0, x21
	mov	x1, x22
	bl	pts_array_push_all
	mov	x0, x21
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB75_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end75:
	.size	pts_fn_parallel_ParallelRange_filter_arrow_2, .Lfunc_end75-pts_fn_parallel_ParallelRange_filter_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2,@function
pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2: // @pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB76_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB76_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB76_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB76_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end76:
	.size	pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2, .Lfunc_end76-pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_18
	.type	pts_adapt_18,@function
pts_adapt_18:                           // @pts_adapt_18
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_18
	add	x0, x0, :lo12:pts_type_adapter_18
	bl	pts_object_new
	adrp	x8, pts_adapter_18
	add	x8, x8, :lo12:pts_adapter_18
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end77:
	.size	pts_adapt_18, .Lfunc_end77-pts_adapt_18
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_18
	.type	pts_adapter_18,@function
pts_adapter_18:                         // @pts_adapter_18
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	stp	x1, x2, [sp]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end78:
	.size	pts_adapter_18, .Lfunc_end78-pts_adapter_18
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_filter_adapter_2
	.type	pts_fn_parallel_ParallelRange_filter_adapter_2,@function
pts_fn_parallel_ParallelRange_filter_adapter_2: // @pts_fn_parallel_ParallelRange_filter_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB79_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x3, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x3
.LBB79_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end79:
	.size	pts_fn_parallel_ParallelRange_filter_adapter_2, .Lfunc_end79-pts_fn_parallel_ParallelRange_filter_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2,@function
pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2: // @pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB80_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB80_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB80_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB80_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end80:
	.size	pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2, .Lfunc_end80-pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_19
	.type	pts_adapt_19,@function
pts_adapt_19:                           // @pts_adapt_19
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_19
	add	x0, x0, :lo12:pts_type_adapter_19
	bl	pts_object_new
	adrp	x8, pts_adapter_19
	add	x8, x8, :lo12:pts_adapter_19
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end81:
	.size	pts_adapt_19, .Lfunc_end81-pts_adapt_19
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_19
	.type	pts_adapter_19,@function
pts_adapter_19:                         // @pts_adapter_19
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	stp	x1, x2, [sp]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end82:
	.size	pts_adapter_19, .Lfunc_end82-pts_adapter_19
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_23
	.type	pts_adapt_23,@function
pts_adapt_23:                           // @pts_adapt_23
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_23
	add	x0, x0, :lo12:pts_type_adapter_23
	bl	pts_object_new
	adrp	x8, pts_adapter_23
	add	x8, x8, :lo12:pts_adapter_23
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end83:
	.size	pts_adapt_23, .Lfunc_end83-pts_adapt_23
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_23
	.type	pts_adapter_23,@function
pts_adapter_23:                         // @pts_adapter_23
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	ldr	x0, [x0, #16]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	str	x8, [sp, #8]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end84:
	.size	pts_adapter_23, .Lfunc_end84-pts_adapter_23
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_40
	.type	pts_adapt_40,@function
pts_adapt_40:                           // @pts_adapt_40
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_40
	add	x0, x0, :lo12:pts_type_adapter_40
	bl	pts_object_new
	adrp	x8, pts_adapter_40
	add	x8, x8, :lo12:pts_adapter_40
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end85:
	.size	pts_adapt_40, .Lfunc_end85-pts_adapt_40
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_40
	.type	pts_adapter_40,@function
pts_adapter_40:                         // @pts_adapter_40
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end86:
	.size	pts_adapter_40, .Lfunc_end86-pts_adapter_40
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_reduce_arrow
	.type	pts_fn_parallel_ParallelRange_reduce_arrow,@function
pts_fn_parallel_ParallelRange_reduce_arrow: // @pts_fn_parallel_ParallelRange_reduce_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-64]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	str	x19, [sp, #48]                  // 8-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -56
	.cfi_offset b11, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB87_5
// %bb.1:
	fmov	d9, #1.00000000
	ldr	d11, [x0, #16]
	fmov	d8, d1
	fadd	d10, d0, d9
	fadd	d0, d11, d0
	fcmp	d10, d1
	b.pl	.LBB87_4
// %bb.2:
	ldr	x19, [x0, #24]
.LBB87_3:                               // =>This Inner Loop Header: Depth=1
	fadd	d1, d11, d10
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fadd	d10, d10, d9
	fcmp	d10, d8
	b.mi	.LBB87_3
.LBB87_4:
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldr	x19, [sp, #48]                  // 8-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #64             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB87_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end87:
	.size	pts_fn_parallel_ParallelRange_reduce_arrow, .Lfunc_end87-pts_fn_parallel_ParallelRange_reduce_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_reduce_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_reduce_arrow: // @pts_dynamic_fn_parallel_ParallelRange_reduce_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB88_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB88_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB88_7
.LBB88_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB88_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB88_9
.LBB88_5:
	mov	w0, #10                         // =0xa
.LBB88_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB88_3
.LBB88_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB88_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB88_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB88_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB88_8
.Lfunc_end88:
	.size	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow, .Lfunc_end88-pts_dynamic_fn_parallel_ParallelRange_reduce_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_20
	.type	pts_adapt_20,@function
pts_adapt_20:                           // @pts_adapt_20
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_20
	add	x0, x0, :lo12:pts_type_adapter_20
	bl	pts_object_new
	adrp	x8, pts_adapter_20
	add	x8, x8, :lo12:pts_adapter_20
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end89:
	.size	pts_adapt_20, .Lfunc_end89-pts_adapt_20
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_20
	.type	pts_adapter_20,@function
pts_adapter_20:                         // @pts_adapter_20
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	add	x8, x8, x9
	csel	x8, x10, x8, vs
	fcmp	d1, d1
	add	x9, x11, x9
	csel	x9, x10, x9, vs
	stp	x8, x9, [sp]
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB90_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB90_2:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB90_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB90_2
.Lfunc_end90:
	.size	pts_adapter_20, .Lfunc_end90-pts_adapter_20
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_reduce_adapter
	.type	pts_fn_parallel_ParallelRange_reduce_adapter,@function
pts_fn_parallel_ParallelRange_reduce_adapter: // @pts_fn_parallel_ParallelRange_reduce_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB91_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB91_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end91:
	.size	pts_fn_parallel_ParallelRange_reduce_adapter, .Lfunc_end91-pts_fn_parallel_ParallelRange_reduce_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_reduce_adapter
	.type	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter,@function
pts_dynamic_fn_parallel_ParallelRange_reduce_adapter: // @pts_dynamic_fn_parallel_ParallelRange_reduce_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB92_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB92_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB92_7
.LBB92_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB92_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB92_9
.LBB92_5:
	mov	w0, #10                         // =0xa
.LBB92_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB92_3
.LBB92_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB92_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB92_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB92_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB92_8
.Lfunc_end92:
	.size	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter, .Lfunc_end92-pts_dynamic_fn_parallel_ParallelRange_reduce_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_reduce_arrow_2
	.type	pts_fn_parallel_ParallelRange_reduce_arrow_2,@function
pts_fn_parallel_ParallelRange_reduce_arrow_2: // @pts_fn_parallel_ParallelRange_reduce_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB93_5
// %bb.1:
	ldr	x0, [x0, #16]
	lsr	x8, x1, #49
	ldr	x3, [x0, #8]
	cbz	x8, .LBB93_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d0, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB93_7
.LBB93_3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d1, x8
.LBB93_4:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x3
.LBB93_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB93_6:
	mov	x19, x0
	mov	x0, x1
	mov	x20, x2
	str	x3, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	ldr	x3, [sp, #8]                    // 8-byte Folded Reload
	mov	x2, x20
	mov	x0, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB93_3
.LBB93_7:
	mov	x19, x0
	mov	x0, x2
	fmov	d8, d0
	str	x3, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
	ldr	x3, [sp, #8]                    // 8-byte Folded Reload
	mov	x0, x19
	b	.LBB93_4
.Lfunc_end93:
	.size	pts_fn_parallel_ParallelRange_reduce_arrow_2, .Lfunc_end93-pts_fn_parallel_ParallelRange_reduce_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2,@function
pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2: // @pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB94_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB94_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB94_5
.LBB94_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB94_5
.LBB94_4:
	ldr	x2, [x2, #8]
.LBB94_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end94:
	.size	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2, .Lfunc_end94-pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_21
	.type	pts_adapt_21,@function
pts_adapt_21:                           // @pts_adapt_21
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_21
	add	x0, x0, :lo12:pts_type_adapter_21
	bl	pts_object_new
	adrp	x8, pts_adapter_21
	add	x8, x8, :lo12:pts_adapter_21
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end95:
	.size	pts_adapt_21, .Lfunc_end95-pts_adapt_21
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_21
	.type	pts_adapter_21,@function
pts_adapter_21:                         // @pts_adapter_21
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	stp	x1, x2, [sp]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB96_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB96_2:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB96_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB96_2
.Lfunc_end96:
	.size	pts_adapter_21, .Lfunc_end96-pts_adapter_21
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_reduce_adapter_2
	.type	pts_fn_parallel_ParallelRange_reduce_adapter_2,@function
pts_fn_parallel_ParallelRange_reduce_adapter_2: // @pts_fn_parallel_ParallelRange_reduce_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB97_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB97_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end97:
	.size	pts_fn_parallel_ParallelRange_reduce_adapter_2, .Lfunc_end97-pts_fn_parallel_ParallelRange_reduce_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2,@function
pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2: // @pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB98_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB98_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB98_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB98_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end98:
	.size	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2, .Lfunc_end98-pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_41
	.type	pts_adapt_41,@function
pts_adapt_41:                           // @pts_adapt_41
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_41
	add	x0, x0, :lo12:pts_type_adapter_41
	bl	pts_object_new
	adrp	x8, pts_adapter_41
	add	x8, x8, :lo12:pts_adapter_41
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end99:
	.size	pts_adapt_41, .Lfunc_end99-pts_adapt_41
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_41
	.type	pts_adapter_41,@function
pts_adapter_41:                         // @pts_adapter_41
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	ldr	x0, [x0, #16]
	mov	x2, sp
	add	x8, x8, x9
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	stp	x1, x8, [sp]
	mov	w1, #2                          // =0x2
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB100_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB100_2:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB100_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB100_2
.Lfunc_end100:
	.size	pts_adapter_41, .Lfunc_end100-pts_adapter_41
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_findFound
	.type	pts_fn_parallel_ParallelRange_findFound,@function
pts_fn_parallel_ParallelRange_findFound: // @pts_fn_parallel_ParallelRange_findFound
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-64]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB101_2
// %bb.1:
	mov	x19, x0
	ldr	d8, [x0, #8]
	adrp	x0, pts_type_object3
	add	x0, x0, :lo12:pts_type_object3
	mov	x20, x1
	bl	pts_object_new
	mov	x21, x0
	strb	wzr, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelRange_findFound_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_findFound_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelRange_findFound_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow
	mov	x22, x0
	stp	x8, x21, [x0, #8]
	str	x20, [x0, #24]
	str	d8, [x0, #32]
	adrp	x0, pts_type_closure_parallel_ParallelRange_findFound_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelRange_findFound_adapter
	bl	pts_object_new
	ldr	d0, [x19, #16]
	adrp	x8, pts_fn_parallel_ParallelRange_findFound_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelRange_findFound_adapter
	adrp	x1, pts_static_parallel_ParallelRange_findFound_arrow_2
	add	x1, x1, :lo12:pts_static_parallel_ParallelRange_findFound_arrow_2
	stp	x8, x22, [x0, #8]
	bl	pts_parallel_reduce
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	b	pts_value_convert
.LBB101_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end101:
	.size	pts_fn_parallel_ParallelRange_findFound, .Lfunc_end101-pts_fn_parallel_ParallelRange_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_findFound_arrow
	.type	pts_fn_parallel_ParallelRange_findFound_arrow,@function
pts_fn_parallel_ParallelRange_findFound_arrow: // @pts_fn_parallel_ParallelRange_findFound_arrow
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	str	d12, [sp, #16]                  // 8-byte Folded Spill
	stp	d11, d10, [sp, #32]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #80]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -144
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB102_18
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d8, d1
	ldr	d11, [x0, #32]
	adrp	x0, pts_type_object4
	add	x0, x0, :lo12:pts_type_object4
	fmov	d9, d0
	bl	pts_object_new
	fcmp	d9, d8
	mov	x21, x0
	mov	w8, #10                         // =0xa
	strb	wzr, [x0, #8]
	str	x8, [x0, #16]
	b.pl	.LBB102_17
// %bb.2:
	fmov	d12, #1.00000000
	adrp	x25, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	mov	w26, #1                         // =0x1
	adrp	x23, .L.str.193
	add	x23, x23, :lo12:.L.str.193
	adrp	x24, pts_check_4
	add	x24, x24, :lo12:pts_check_4
	adrp	x28, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	adrp	x27, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	adrp	x22, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	add	x22, x22, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	b	.LBB102_5
.LBB102_3:                              //   in Loop: Header=BB102_5 Depth=1
	add	x4, sp, #24
	mov	x0, x19
	adrp	x1, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	mov	x2, x23
	mov	x3, x24
	bl	pts_field_set_slow
.LBB102_4:                              //   in Loop: Header=BB102_5 Depth=1
	fadd	d9, d9, d12
	fcmp	d9, d8
	b.pl	.LBB102_17
.LBB102_5:                              // =>This Inner Loop Header: Depth=1
	ldr	x8, [x25, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1]
	ldr	x9, [x19]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB102_7
// %bb.6:                               //   in Loop: Header=BB102_5 Depth=1
	add	x0, x19, x8, lsr #48
	ldrb	w8, [x0]
	cbz	w8, .LBB102_8
	b	.LBB102_17
.LBB102_7:                              //   in Loop: Header=BB102_5 Depth=1
	mov	x0, x19
	mov	x1, x22
	mov	x2, x23
	mov	x3, x24
	bl	pts_field_address_slow
	ldrb	w8, [x0]
	cbnz	w8, .LBB102_17
.LBB102_8:                              //   in Loop: Header=BB102_5 Depth=1
	fadd	d10, d11, d9
	ldr	x8, [x20, #8]
	mov	x0, x20
	fmov	d0, d10
	blr	x8
	bl	pts_value_truthy
	tbz	w0, #0, .LBB102_4
// %bb.9:                               //   in Loop: Header=BB102_5 Depth=1
	strb	w26, [sp, #28]
	adrp	x8, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	ldr	x9, [x8, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2]
	ldr	x8, [x21]
	and	x10, x9, #0xffffffffffff
	cmp	x10, x8
	b.ne	.LBB102_11
// %bb.10:                              //   in Loop: Header=BB102_5 Depth=1
	lsr	x9, x9, #48
	strb	w26, [x21, x9]
	b	.LBB102_12
.LBB102_11:                             //   in Loop: Header=BB102_5 Depth=1
	add	x4, sp, #28
	mov	x0, x21
	adrp	x1, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	mov	x2, x23
	mov	x3, x24
	bl	pts_field_set_slow
	ldr	x8, [x21]
.LBB102_12:                             //   in Loop: Header=BB102_5 Depth=1
	fmov	x9, d10
	fcmp	d10, d10
	mov	x10, #562949953421312           // =0x2000000000000
	add	x9, x9, x10
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	csel	x9, x10, x9, vs
	str	x9, [sp, #8]
	ldr	x10, [x28, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3]
	and	x11, x10, #0xffffffffffff
	cmp	x11, x8
	b.ne	.LBB102_14
// %bb.13:                              //   in Loop: Header=BB102_5 Depth=1
	lsr	x8, x10, #48
	str	x9, [x21, x8]
	b	.LBB102_15
.LBB102_14:                             //   in Loop: Header=BB102_5 Depth=1
	add	x4, sp, #8
	mov	x0, x21
	adrp	x1, pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_set_slow
.LBB102_15:                             //   in Loop: Header=BB102_5 Depth=1
	strb	w26, [sp, #24]
	ldr	x8, [x27, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4]
	ldr	x9, [x19]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB102_3
// %bb.16:                              //   in Loop: Header=BB102_5 Depth=1
	lsr	x8, x8, #48
	strb	w26, [x19, x8]
	b	.LBB102_4
.LBB102_17:
	mov	x0, x21
	.cfi_def_cfa wsp, 160
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	ldr	d12, [sp, #16]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            // 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	ret
.LBB102_18:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end102:
	.size	pts_fn_parallel_ParallelRange_findFound_arrow, .Lfunc_end102-pts_fn_parallel_ParallelRange_findFound_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_findFound_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_findFound_arrow: // @pts_dynamic_fn_parallel_ParallelRange_findFound_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB103_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB103_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB103_7
.LBB103_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB103_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB103_9
.LBB103_5:
	mov	w0, #10                         // =0xa
.LBB103_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB103_3
.LBB103_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB103_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB103_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB103_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB103_8
.Lfunc_end103:
	.size	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow, .Lfunc_end103-pts_dynamic_fn_parallel_ParallelRange_findFound_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_24
	.type	pts_adapt_24,@function
pts_adapt_24:                           // @pts_adapt_24
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_24
	add	x0, x0, :lo12:pts_type_adapter_24
	bl	pts_object_new
	adrp	x8, pts_adapter_24
	add	x8, x8, :lo12:pts_adapter_24
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end104:
	.size	pts_adapt_24, .Lfunc_end104-pts_adapt_24
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_24
	.type	pts_adapter_24,@function
pts_adapter_24:                         // @pts_adapter_24
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x8, d0
	fcmp	d0, d0
	mov	x9, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	add	x8, x8, x9
	csel	x8, x10, x8, vs
	fcmp	d1, d1
	add	x9, x11, x9
	csel	x9, x10, x9, vs
	stp	x8, x9, [sp]
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end105:
	.size	pts_adapter_24, .Lfunc_end105-pts_adapter_24
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_findFound_adapter
	.type	pts_fn_parallel_ParallelRange_findFound_adapter,@function
pts_fn_parallel_ParallelRange_findFound_adapter: // @pts_fn_parallel_ParallelRange_findFound_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB106_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB106_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end106:
	.size	pts_fn_parallel_ParallelRange_findFound_adapter, .Lfunc_end106-pts_fn_parallel_ParallelRange_findFound_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_findFound_adapter
	.type	pts_dynamic_fn_parallel_ParallelRange_findFound_adapter,@function
pts_dynamic_fn_parallel_ParallelRange_findFound_adapter: // @pts_dynamic_fn_parallel_ParallelRange_findFound_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB107_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB107_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB107_7
.LBB107_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB107_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB107_9
.LBB107_5:
	mov	w0, #10                         // =0xa
.LBB107_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB107_3
.LBB107_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB107_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB107_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB107_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB107_8
.Lfunc_end107:
	.size	pts_dynamic_fn_parallel_ParallelRange_findFound_adapter, .Lfunc_end107-pts_dynamic_fn_parallel_ParallelRange_findFound_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_findFound_arrow_2
	.type	pts_fn_parallel_ParallelRange_findFound_arrow_2,@function
pts_fn_parallel_ParallelRange_findFound_arrow_2: // @pts_fn_parallel_ParallelRange_findFound_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB108_5
// %bb.1:
	mov	x20, x1
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	mov	x0, x20
	mov	x19, x2
	bl	pts_value_convert
	adrp	x8, pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB108_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB108_4
.LBB108_3:
	adrp	x1, pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB108_4:
	ldrb	w8, [x0]
	cmp	w8, #0
	csel	x0, x19, x20, eq
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB108_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end108:
	.size	pts_fn_parallel_ParallelRange_findFound_arrow_2, .Lfunc_end108-pts_fn_parallel_ParallelRange_findFound_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2,@function
pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2: // @pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB109_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB109_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB109_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB109_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end109:
	.size	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2, .Lfunc_end109-pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_42
	.type	pts_adapt_42,@function
pts_adapt_42:                           // @pts_adapt_42
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_42
	add	x0, x0, :lo12:pts_type_adapter_42
	bl	pts_object_new
	adrp	x8, pts_adapter_42
	add	x8, x8, :lo12:pts_adapter_42
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end110:
	.size	pts_adapt_42, .Lfunc_end110-pts_adapt_42
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_42
	.type	pts_adapter_42,@function
pts_adapter_42:                         // @pts_adapter_42
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	sub	x8, x0, #8
	cmn	x8, #3
	b.ls	.LBB111_2
// %bb.1:
	cmp	x0, #7
	cset	w0, eq
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB111_2:
	.cfi_restore_state
	adrp	x1, .L.str.142
	add	x1, x1, :lo12:.L.str.142
	bl	pts_throw_not_primitive
.Lfunc_end111:
	.size	pts_adapter_42, .Lfunc_end111-pts_adapter_42
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_every_arrow
	.type	pts_fn_parallel_ParallelRange_every_arrow,@function
pts_fn_parallel_ParallelRange_every_arrow: // @pts_fn_parallel_ParallelRange_every_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB112_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	bl	pts_value_truthy
	mov	w8, #1                          // =0x1
	bic	w0, w8, w0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB112_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end112:
	.size	pts_fn_parallel_ParallelRange_every_arrow, .Lfunc_end112-pts_fn_parallel_ParallelRange_every_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_every_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_every_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_every_arrow: // @pts_dynamic_fn_parallel_ParallelRange_every_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	cbz	w1, .LBB113_3
// %bb.1:
	ldr	x8, [x2]
	lsr	x9, x8, #49
	cbz	x9, .LBB113_6
// %bb.2:
	mov	x9, #-562949953421312           // =0xfffe000000000000
	add	x8, x8, x9
	fmov	d0, x8
	b	.LBB113_5
.LBB113_3:
	mov	x19, x0
	mov	w8, #10                         // =0xa
.LBB113_4:
	mov	x0, x8
	bl	pts_value_to_number_slow
	mov	x0, x19
.LBB113_5:
	ldr	x8, [x0, #8]
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB113_6:
	.cfi_restore_state
	mov	x19, x0
	b	.LBB113_4
.Lfunc_end113:
	.size	pts_dynamic_fn_parallel_ParallelRange_every_arrow, .Lfunc_end113-pts_dynamic_fn_parallel_ParallelRange_every_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_22
	.type	pts_adapt_22,@function
pts_adapt_22:                           // @pts_adapt_22
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_22
	add	x0, x0, :lo12:pts_type_adapter_22
	bl	pts_object_new
	adrp	x8, pts_adapter_22
	add	x8, x8, :lo12:pts_adapter_22
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end114:
	.size	pts_adapt_22, .Lfunc_end114-pts_adapt_22
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_22
	.type	pts_adapter_22,@function
pts_adapter_22:                         // @pts_adapter_22
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	ldr	x0, [x0, #16]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	str	x8, [sp, #8]
	bl	pts_dynamic_call_closure
	sub	x8, x0, #8
	cmn	x8, #3
	b.ls	.LBB115_2
// %bb.1:
	cmp	x0, #7
	cset	w0, eq
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB115_2:
	.cfi_restore_state
	adrp	x1, .L.str.142
	add	x1, x1, :lo12:.L.str.142
	bl	pts_throw_not_primitive
.Lfunc_end115:
	.size	pts_adapter_22, .Lfunc_end115-pts_adapter_22
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_every_adapter
	.type	pts_fn_parallel_ParallelRange_every_adapter,@function
pts_fn_parallel_ParallelRange_every_adapter: // @pts_fn_parallel_ParallelRange_every_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB116_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB116_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end116:
	.size	pts_fn_parallel_ParallelRange_every_adapter, .Lfunc_end116-pts_fn_parallel_ParallelRange_every_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_every_adapter
	.type	pts_dynamic_fn_parallel_ParallelRange_every_adapter,@function
pts_dynamic_fn_parallel_ParallelRange_every_adapter: // @pts_dynamic_fn_parallel_ParallelRange_every_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	cbz	w1, .LBB117_3
// %bb.1:
	ldr	x8, [x2]
	lsr	x9, x8, #49
	cbz	x9, .LBB117_6
// %bb.2:
	mov	x9, #-562949953421312           // =0xfffe000000000000
	add	x8, x8, x9
	fmov	d0, x8
	b	.LBB117_5
.LBB117_3:
	mov	x19, x0
	mov	w8, #10                         // =0xa
.LBB117_4:
	mov	x0, x8
	bl	pts_value_to_number_slow
	mov	x0, x19
.LBB117_5:
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB117_6:
	.cfi_restore_state
	mov	x19, x0
	b	.LBB117_4
.Lfunc_end117:
	.size	pts_dynamic_fn_parallel_ParallelRange_every_adapter, .Lfunc_end117-pts_dynamic_fn_parallel_ParallelRange_every_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_43
	.type	pts_adapt_43,@function
pts_adapt_43:                           // @pts_adapt_43
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_43
	add	x0, x0, :lo12:pts_type_adapter_43
	bl	pts_object_new
	adrp	x8, pts_adapter_43
	add	x8, x8, :lo12:pts_adapter_43
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end118:
	.size	pts_adapt_43, .Lfunc_end118-pts_adapt_43
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_43
	.type	pts_adapter_43,@function
pts_adapter_43:                         // @pts_adapter_43
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cmp	x8, #0
	ccmp	x0, #10, #4, eq
	b.ne	.LBB119_2
// %bb.1:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB119_2:
	.cfi_restore_state
	adrp	x1, .L.str.196
	add	x1, x1, :lo12:.L.str.196
	bl	pts_throw_type_mismatch
.Lfunc_end119:
	.size	pts_adapter_43, .Lfunc_end119-pts_adapter_43
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_count_arrow
	.type	pts_fn_parallel_ParallelRange_count_arrow,@function
pts_fn_parallel_ParallelRange_count_arrow: // @pts_fn_parallel_ParallelRange_count_arrow
	.cfi_startproc
// %bb.0:
	str	d12, [sp, #-64]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d11, d10, [sp, #8]              // 16-byte Folded Spill
	stp	d9, d8, [sp, #24]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #40]             // 16-byte Folded Spill
	str	x19, [sp, #56]                  // 8-byte Folded Spill
	add	x29, sp, #40
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_offset b9, -40
	.cfi_offset b10, -48
	.cfi_offset b11, -56
	.cfi_offset b12, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB120_5
// %bb.1:
	fmov	d8, d1
	fmov	d9, d0
	movi	d10, #0000000000000000
	fcmp	d0, d1
	b.pl	.LBB120_4
// %bb.2:
	fmov	d11, #1.00000000
	ldr	x19, [x0, #16]
	ldr	d12, [x0, #24]
.LBB120_3:                              // =>This Inner Loop Header: Depth=1
	fadd	d0, d12, d9
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	bl	pts_value_truthy
	fadd	d0, d10, d11
	fadd	d9, d9, d11
	tst	w0, #0x1
	fcsel	d10, d0, d10, ne
	fcmp	d9, d8
	b.mi	.LBB120_3
.LBB120_4:
	fmov	d0, d10
	.cfi_def_cfa wsp, 64
	ldp	x29, x30, [sp, #40]             // 16-byte Folded Reload
	ldr	x19, [sp, #56]                  // 8-byte Folded Reload
	ldp	d9, d8, [sp, #24]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #8]              // 16-byte Folded Reload
	ldr	d12, [sp], #64                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	ret
.LBB120_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end120:
	.size	pts_fn_parallel_ParallelRange_count_arrow, .Lfunc_end120-pts_fn_parallel_ParallelRange_count_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_count_arrow
	.type	pts_dynamic_fn_parallel_ParallelRange_count_arrow,@function
pts_dynamic_fn_parallel_ParallelRange_count_arrow: // @pts_dynamic_fn_parallel_ParallelRange_count_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB121_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB121_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB121_7
.LBB121_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB121_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB121_9
.LBB121_5:
	mov	w0, #10                         // =0xa
.LBB121_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB121_3
.LBB121_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB121_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB121_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB121_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB121_8
.Lfunc_end121:
	.size	pts_dynamic_fn_parallel_ParallelRange_count_arrow, .Lfunc_end121-pts_dynamic_fn_parallel_ParallelRange_count_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_count_adapter
	.type	pts_fn_parallel_ParallelRange_count_adapter,@function
pts_fn_parallel_ParallelRange_count_adapter: // @pts_fn_parallel_ParallelRange_count_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB122_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB122_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end122:
	.size	pts_fn_parallel_ParallelRange_count_adapter, .Lfunc_end122-pts_fn_parallel_ParallelRange_count_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_count_adapter
	.type	pts_dynamic_fn_parallel_ParallelRange_count_adapter,@function
pts_dynamic_fn_parallel_ParallelRange_count_adapter: // @pts_dynamic_fn_parallel_ParallelRange_count_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB123_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB123_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB123_7
.LBB123_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB123_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB123_9
.LBB123_5:
	mov	w0, #10                         // =0xa
.LBB123_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB123_3
.LBB123_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB123_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB123_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB123_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB123_8
.Lfunc_end123:
	.size	pts_dynamic_fn_parallel_ParallelRange_count_adapter, .Lfunc_end123-pts_dynamic_fn_parallel_ParallelRange_count_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_count_arrow_2
	.type	pts_fn_parallel_ParallelRange_count_arrow_2,@function
pts_fn_parallel_ParallelRange_count_arrow_2: // @pts_fn_parallel_ParallelRange_count_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x19, [sp, #24]                  // 8-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_remember_state
	lsr	x8, x1, #49
	cbz	x8, .LBB124_4
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d8, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB124_5
.LBB124_2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d0, x8
.LBB124_3:
	fadd	d0, d8, d0
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	x19, [sp, #24]                  // 8-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB124_4:
	.cfi_restore_state
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_to_number_slow
	fmov	d8, d0
	mov	x2, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB124_2
.LBB124_5:
	mov	x0, x2
	bl	pts_value_to_number_slow
	b	.LBB124_3
.Lfunc_end124:
	.size	pts_fn_parallel_ParallelRange_count_arrow_2, .Lfunc_end124-pts_fn_parallel_ParallelRange_count_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_count_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelRange_count_arrow_2,@function
pts_dynamic_fn_parallel_ParallelRange_count_arrow_2: // @pts_dynamic_fn_parallel_ParallelRange_count_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB125_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB125_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB125_5
.LBB125_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB125_5
.LBB125_4:
	ldr	x2, [x2, #8]
.LBB125_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end125:
	.size	pts_dynamic_fn_parallel_ParallelRange_count_arrow_2, .Lfunc_end125-pts_dynamic_fn_parallel_ParallelRange_count_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_count_adapter_2
	.type	pts_fn_parallel_ParallelRange_count_adapter_2,@function
pts_fn_parallel_ParallelRange_count_adapter_2: // @pts_fn_parallel_ParallelRange_count_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB126_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB126_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end126:
	.size	pts_fn_parallel_ParallelRange_count_adapter_2, .Lfunc_end126-pts_fn_parallel_ParallelRange_count_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelRange_count_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelRange_count_adapter_2,@function
pts_dynamic_fn_parallel_ParallelRange_count_adapter_2: // @pts_dynamic_fn_parallel_ParallelRange_count_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB127_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB127_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB127_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB127_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end127:
	.size	pts_dynamic_fn_parallel_ParallelRange_count_adapter_2, .Lfunc_end127-pts_dynamic_fn_parallel_ParallelRange_count_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_44
	.type	pts_adapt_44,@function
pts_adapt_44:                           // @pts_adapt_44
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_44
	add	x0, x0, :lo12:pts_type_adapter_44
	bl	pts_object_new
	adrp	x8, pts_adapter_44
	add	x8, x8, :lo12:pts_adapter_44
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end128:
	.size	pts_adapt_44, .Lfunc_end128-pts_adapt_44
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_44
	.type	pts_adapter_44,@function
pts_adapter_44:                         // @pts_adapter_44
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB129_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB129_2:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB129_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB129_2
.Lfunc_end129:
	.size	pts_adapter_44, .Lfunc_end129-pts_adapter_44
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelRange_toArray
	.type	pts_fn_parallel_ParallelRange_toArray,@function
pts_fn_parallel_ParallelRange_toArray:  // @pts_fn_parallel_ParallelRange_toArray
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	.cfi_remember_state
	adrp	x21, :gottprel:pts_stack_limit
	ldr	x21, [x21, :gottprel_lo12:pts_stack_limit]
	mrs	x22, TPIDR_EL0
	ldr	x8, [x22, x21]
	cmp	x8, x29
	b.hi	.LBB130_10
// %bb.1:
	adrp	x8, pts_global_parallel_Range_class_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_Range_class_ready]
	tbz	w8, #0, .LBB130_11
// %bb.2:
	mov	x20, x0
	adrp	x0, pts_type_parallel_Range
	add	x0, x0, :lo12:pts_type_parallel_Range
	bl	pts_object_new
	ldp	d0, d1, [x20, #8]
	ldr	x8, [x22, x21]
	cmp	x8, x29
	fadd	d1, d0, d1
	stp	d0, d1, [x0, #8]
	b.hi	.LBB130_10
// %bb.3:
	fsub	d1, d1, d0
	mov	x19, x0
	fcmp	d1, d1
	b.vs	.LBB130_12
// %bb.4:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.eq	.LBB130_6
// %bb.5:
	fcsel	d0, d0, d1, mi
.LBB130_6:
	adrp	x8, :got:pts_array_types
	ldr	x8, [x8, :got_lo12:pts_array_types]
	add	x0, x8, #136
	bl	pts_array_of_length
	add	x8, x0, #16
	mov	x20, x0
	ldar	x8, [x8]
	cbz	x8, .LBB130_9
// %bb.7:
	movi	d8, #0000000000000000
	fmov	d9, #1.00000000
.LBB130_8:                              // =>This Inner Loop Header: Depth=1
	ldr	d0, [x19, #8]
	add	x1, sp, #8
	mov	x0, x20
	fadd	d0, d8, d0
	str	d0, [sp, #8]
	fmov	d0, d8
	bl	pts_array_set
	add	x8, x20, #16
	fadd	d8, d8, d9
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d8, d0
	b.mi	.LBB130_8
.LBB130_9:
	mov	x0, x20
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.LBB130_10:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB130_11:
	adrp	x0, .L.str.160
	add	x0, x0, :lo12:.L.str.160
	bl	pts_throw_uninitialized
.LBB130_12:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB130_6
.Lfunc_end130:
	.size	pts_fn_parallel_ParallelRange_toArray, .Lfunc_end130-pts_fn_parallel_ParallelRange_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sort
	.type	pts_fn_parallel_ParallelArray_sort,@function
pts_fn_parallel_ParallelArray_sort:     // @pts_fn_parallel_ParallelArray_sort
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	d11, d10, [sp, #16]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #32]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #64]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #80]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #96]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #112]            // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w30, -72
	.cfi_offset w29, -80
	.cfi_offset b8, -88
	.cfi_offset b9, -96
	.cfi_offset b10, -104
	.cfi_offset b11, -112
	.cfi_remember_state
	adrp	x24, :gottprel:pts_stack_limit
	ldr	x24, [x24, :gottprel_lo12:pts_stack_limit]
	mrs	x25, TPIDR_EL0
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.1:
	ldr	x19, [x0, #8]
	tst	w2, #0x1
	mov	w8, #10                         // =0xa
	csel	x21, x1, x8, ne
	cbz	x19, .LBB131_31
// %bb.2:
	bl	pts_parallel_threads
	fmov	d1, #1.00000000
	fcmp	d0, d1
	b.ne	.LBB131_5
// %bb.3:
	cmp	x21, #10
	b.ne	.LBB131_14
// %bb.4:
	mov	x0, x19
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	b	pts_array_sort
.LBB131_5:
	.cfi_restore_state
	.cfi_remember_state
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	mov	x9, #9218868437227405312        // =0x7ff0000000000000
	mov	x0, x19
	fmov	d0, x8
	fmov	d1, x9
	bl	pts_array_slice
	mov	x20, x0
	bl	pts_parallel_gather_sortable
	fmov	d8, d0
	cmp	x21, #10
	b.ne	.LBB131_15
// %bb.6:
	movi	d0, #0000000000000000
	fmov	d1, d8
	mov	x0, x20
	bl	pts_array_slice
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.7:
	add	x8, x0, #16
	adrp	x26, :got:pts_array_types
	mov	x22, x0
	ldar	x23, [x8]
	ldar	x8, [x8]
	ldr	x26, [x26, :got_lo12:pts_array_types]
	ucvtf	d0, x8
	add	x0, x26, #408
	bl	pts_array_of_length
	mov	x21, x0
	cbz	x23, .LBB131_16
// %bb.8:
	ucvtf	d10, x23
	movi	d9, #0000000000000000
	adrp	x23, pts_static_parallel_ParallelArray_sort_arrow
	add	x23, x23, :lo12:pts_static_parallel_ParallelArray_sort_arrow
	fmov	d11, #1.00000000
	b	.LBB131_10
.LBB131_9:                              //   in Loop: Header=BB131_10 Depth=1
	fadd	d9, d9, d11
	fcmp	d9, d10
	b.pl	.LBB131_16
.LBB131_10:                             // =>This Inner Loop Header: Depth=1
	add	x8, x22, #16
	ldar	x9, [x8]
	ucvtf	d0, x9
	fcmp	d9, d0
	b.pl	.LBB131_9
// %bb.11:                              //   in Loop: Header=BB131_10 Depth=1
	add	x9, x22, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d9, #0.0
	b.lt	.LBB131_32
// %bb.12:                              //   in Loop: Header=BB131_10 Depth=1
	fcvtzu	d0, d9
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d9, d1
	fccmp	d9, d0, #0, mi
	b.ne	.LBB131_32
// %bb.13:                              //   in Loop: Header=BB131_10 Depth=1
	fcvtzu	x9, d9
	fmov	d1, d9
	mov	x0, x23
	mov	x1, x22
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	ldr	x8, [x23, #8]
	blr	x8
	fmov	d0, d9
	str	x0, [sp, #8]
	add	x1, sp, #8
	mov	x0, x21
	bl	pts_array_set
	b	.LBB131_9
.LBB131_14:
	adrp	x2, pts_compare_1
	add	x2, x2, :lo12:pts_compare_1
	mov	x0, x19
	mov	x1, x21
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	b	pts_array_sort_with
.LBB131_15:
	.cfi_restore_state
	.cfi_remember_state
	fmov	d0, d8
	mov	x0, x20
	mov	x1, x21
	bl	pts_fn_parallel_sortInPlace_number
	b	.LBB131_29
.LBB131_16:
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.17:
	adrp	x8, pts_global_parallel_Range_class_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_Range_class_ready]
	tbz	w8, #0, .LBB131_33
// %bb.18:
	adrp	x0, pts_type_parallel_Range
	add	x0, x0, :lo12:pts_type_parallel_Range
	bl	pts_object_new
	frintz	d1, d8
	str	xzr, [x0, #8]
	str	d1, [x0, #16]
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.19:
	fcmp	d1, d1
	mov	x23, x0
	b.vs	.LBB131_34
// %bb.20:
	movi	d0, #0000000000000000
	fcmp	d1, #0.0
	b.eq	.LBB131_22
// %bb.21:
	fcsel	d0, d0, d1, mi
.LBB131_22:
	add	x0, x26, #136
	bl	pts_array_of_length
	add	x8, x0, #16
	mov	x22, x0
	ldar	x8, [x8]
	cbz	x8, .LBB131_25
// %bb.23:
	movi	d9, #0000000000000000
	fmov	d10, #1.00000000
.LBB131_24:                             // =>This Inner Loop Header: Depth=1
	ldr	d0, [x23, #8]
	add	x1, sp, #8
	mov	x0, x22
	fadd	d0, d9, d0
	str	d0, [sp, #8]
	fmov	d0, d9
	bl	pts_array_set
	add	x8, x22, #16
	fadd	d9, d9, d10
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d9, d0
	b.mi	.LBB131_24
.LBB131_25:
	adrp	x0, pts_type_closure_parallel_ParallelArray_sort_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_sort_arrow_2
	bl	pts_object_new
	fmov	d0, d8
	adrp	x8, pts_fn_parallel_ParallelArray_sort_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_sort_arrow_2
	mov	x1, x0
	stp	x8, x21, [x0, #8]
	mov	x0, x22
	bl	pts_fn_parallel_sortInPlace_number
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.26:
	adrp	x0, pts_type_parallel_ParallelArray
	add	x0, x0, :lo12:pts_type_parallel_ParallelArray
	bl	pts_object_new
	mov	x23, x0
	str	x22, [x0, #8]
	adrp	x0, pts_type_closure_parallel_permute_number_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_permute_number_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_permute_number_arrow
	add	x8, x8, :lo12:pts_fn_parallel_permute_number_arrow
	stp	x8, x20, [x0, #8]
	ldr	x8, [x25, x24]
	cmp	x8, x29
	b.hi	.LBB131_30
// %bb.27:
	ldr	x24, [x23, #8]
	cbz	x24, .LBB131_31
// %bb.28:
	add	x25, x24, #16
	mov	x21, x0
	add	x0, x26, #136
	ldar	x8, [x25]
	ucvtf	d0, x8
	bl	pts_array_of_length
	mov	x23, x0
	adrp	x0, pts_type_closure_parallel_ParallelArray_map_number_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_map_number_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_map_number_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_map_number_arrow
	stp	x23, x21, [x0, #24]
	stp	x8, x24, [x0, #8]
	ldar	x8, [x25]
	ucvtf	d0, x8
	bl	pts_parallel_for
	adrp	x0, pts_type_closure_parallel_permute_number_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_permute_number_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_permute_number_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_permute_number_arrow_2
	str	x23, [x0, #24]
	stp	x8, x20, [x0, #8]
	add	x8, x22, #16
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_for
.LBB131_29:
	mov	x0, x19
	mov	x1, x20
	bl	pts_parallel_write_sorted
	mov	x0, x19
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #96]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #80]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB131_30:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB131_31:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB131_32:
	fmov	d0, d9
	mov	x0, x22
	bl	pts_array_index_error
.LBB131_33:
	adrp	x0, .L.str.160
	add	x0, x0, :lo12:.L.str.160
	bl	pts_throw_uninitialized
.LBB131_34:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB131_22
.Lfunc_end131:
	.size	pts_fn_parallel_ParallelArray_sort, .Lfunc_end131-pts_fn_parallel_ParallelArray_sort
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_forEach
	.type	pts_entry_parallel_ParallelArray_forEach,@function
pts_entry_parallel_ParallelArray_forEach: // @pts_entry_parallel_ParallelArray_forEach
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB132_3
// %bb.1:
	ldr	x20, [x0, #8]
	cbz	x20, .LBB132_4
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_forEach_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_forEach_arrow
	mov	x19, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_forEach_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_forEach_arrow
	str	x19, [x0, #24]
	stp	x8, x20, [x0, #8]
	add	x8, x20, #16
	ldar	x8, [x8]
	ucvtf	d0, x8
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	b	pts_parallel_for
.LBB132_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB132_4:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end132:
	.size	pts_entry_parallel_ParallelArray_forEach, .Lfunc_end132-pts_entry_parallel_ParallelArray_forEach
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_forEach
	.type	pts_dynamic_entry_parallel_ParallelArray_forEach,@function
pts_dynamic_entry_parallel_ParallelArray_forEach: // @pts_dynamic_entry_parallel_ParallelArray_forEach
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB133_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB133_3
.LBB133_2:
	mov	w0, #10                         // =0xa
.LBB133_3:
	adrp	x1, pts_check_48
	add	x1, x1, :lo12:pts_check_48
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB133_6
// %bb.4:
	ldr	x19, [x19, #8]
	cbz	x19, .LBB133_7
// %bb.5:
	mov	x20, x0
	adrp	x0, pts_type_closure_parallel_ParallelArray_forEach_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_forEach_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_forEach_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_forEach_arrow
	str	x20, [x0, #24]
	stp	x8, x19, [x0, #8]
	add	x8, x19, #16
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_for
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB133_6:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB133_7:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end133:
	.size	pts_dynamic_entry_parallel_ParallelArray_forEach, .Lfunc_end133-pts_dynamic_entry_parallel_ParallelArray_forEach
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_filter
	.type	pts_entry_parallel_ParallelArray_filter,@function
pts_entry_parallel_ParallelArray_filter: // @pts_entry_parallel_ParallelArray_filter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB134_3
// %bb.1:
	ldr	x21, [x0, #8]
	cbz	x21, .LBB134_4
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_filter_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_filter_arrow
	mov	x19, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_filter_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_filter_arrow
	mov	x20, x0
	stp	x8, x21, [x0, #8]
	str	x19, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelArray_filter_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_filter_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_filter_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_filter_adapter
	mov	x19, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_filter_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_filter_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_filter_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_filter_adapter_2
	adrp	x9, pts_static_parallel_ParallelArray_filter_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelArray_filter_arrow_2
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	add	x8, x21, #16
	mov	x0, x19
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_convert
.LBB134_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB134_4:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end134:
	.size	pts_entry_parallel_ParallelArray_filter, .Lfunc_end134-pts_entry_parallel_ParallelArray_filter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_filter
	.type	pts_dynamic_entry_parallel_ParallelArray_filter,@function
pts_dynamic_entry_parallel_ParallelArray_filter: // @pts_dynamic_entry_parallel_ParallelArray_filter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB135_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB135_3
.LBB135_2:
	mov	w0, #10                         // =0xa
.LBB135_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_entry_parallel_ParallelArray_filter
.Lfunc_end135:
	.size	pts_dynamic_entry_parallel_ParallelArray_filter, .Lfunc_end135-pts_dynamic_entry_parallel_ParallelArray_filter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_reduce
	.type	pts_entry_parallel_ParallelArray_reduce,@function
pts_entry_parallel_ParallelArray_reduce: // @pts_entry_parallel_ParallelArray_reduce
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-64]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB136_9
// %bb.1:
	ldr	x20, [x0, #8]
	cbz	x20, .LBB136_10
// %bb.2:
	add	x8, x20, #16
	ldar	x8, [x8]
	cbz	x8, .LBB136_5
// %bb.3:
	mov	x21, x0
	mov	x0, x20
	mov	x19, x1
	fmov	d8, d0
	bl	pts_parallel_holds_pointers
	tbz	w0, #0, .LBB136_6
// %bb.4:
	mov	x0, x21
	mov	x1, x19
	fmov	d0, d8
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	b	pts_fn_parallel_ParallelArray_reduceElements
.LBB136_5:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB136_6:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduce_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduce_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduce_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduce_arrow
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	str	x19, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduce_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduce_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduce_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduce_adapter
	mov	x22, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduce_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduce_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduce_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduce_arrow_2
	mov	x21, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduce_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduce_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduce_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduce_adapter_2
	mov	x1, x0
	stp	x8, x21, [x0, #8]
	add	x8, x20, #16
	mov	x0, x22
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	ldr	x1, [x19, #8]
	cbz	x8, .LBB136_11
// %bb.7:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
.LBB136_8:
	mov	x0, x19
	fmov	d0, d8
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB136_9:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB136_10:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB136_11:
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	fmov	d1, d0
	ldr	x1, [sp, #8]                    // 8-byte Folded Reload
	b	.LBB136_8
.Lfunc_end136:
	.size	pts_entry_parallel_ParallelArray_reduce, .Lfunc_end136-pts_entry_parallel_ParallelArray_reduce
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_reduce
	.type	pts_dynamic_entry_parallel_ParallelArray_reduce,@function
pts_dynamic_entry_parallel_ParallelArray_reduce: // @pts_dynamic_entry_parallel_ParallelArray_reduce
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	x19, x0
	cbz	w1, .LBB137_3
// %bb.1:
	ldr	x0, [x2]
	mov	w20, w1
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	x21, x2
	bl	pts_value_convert
	cmp	w20, #1
	mov	x20, x0
	b.ne	.LBB137_5
// %bb.2:
	mov	w21, #10                        // =0xa
	b	.LBB137_4
.LBB137_3:
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	w0, #10                         // =0xa
	mov	w21, #10                        // =0xa
	bl	pts_value_convert
	mov	x20, x0
.LBB137_4:
	mov	x0, x21
	bl	pts_value_to_number_slow
	b	.LBB137_7
.LBB137_5:
	ldr	x21, [x21, #8]
	lsr	x8, x21, #49
	cbz	x8, .LBB137_4
// %bb.6:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x21, x8
	fmov	d0, x8
.LBB137_7:
	mov	x0, x19
	mov	x1, x20
	bl	pts_entry_parallel_ParallelArray_reduce
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end137:
	.size	pts_dynamic_entry_parallel_ParallelArray_reduce, .Lfunc_end137-pts_dynamic_entry_parallel_ParallelArray_reduce
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_some
	.type	pts_entry_parallel_ParallelArray_some,@function
pts_entry_parallel_ParallelArray_some:  // @pts_entry_parallel_ParallelArray_some
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB138_5
// %bb.1:
	bl	pts_fn_parallel_ParallelArray_findFound
	adrp	x8, pts_fn_parallel_ParallelArray_some.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_some.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB138_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB138_4
.LBB138_3:
	adrp	x1, pts_fn_parallel_ParallelArray_some.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_some.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB138_4:
	ldrb	w0, [x0]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB138_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end138:
	.size	pts_entry_parallel_ParallelArray_some, .Lfunc_end138-pts_entry_parallel_ParallelArray_some
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_some
	.type	pts_dynamic_entry_parallel_ParallelArray_some,@function
pts_dynamic_entry_parallel_ParallelArray_some: // @pts_dynamic_entry_parallel_ParallelArray_some
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB139_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB139_3
.LBB139_2:
	mov	w0, #10                         // =0xa
.LBB139_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB139_8
// %bb.4:
	mov	x1, x0
	mov	x0, x19
	bl	pts_fn_parallel_ParallelArray_findFound
	adrp	x8, pts_fn_parallel_ParallelArray_some.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_some.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB139_6
// %bb.5:
	add	x0, x0, x8, lsr #48
	b	.LBB139_7
.LBB139_6:
	adrp	x1, pts_fn_parallel_ParallelArray_some.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_some.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB139_7:
	ldrb	w8, [x0]
	cmp	w8, #0
	mov	w8, #6                          // =0x6
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB139_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end139:
	.size	pts_dynamic_entry_parallel_ParallelArray_some, .Lfunc_end139-pts_dynamic_entry_parallel_ParallelArray_some
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_every
	.type	pts_entry_parallel_ParallelArray_every,@function
pts_entry_parallel_ParallelArray_every: // @pts_entry_parallel_ParallelArray_every
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB140_5
// %bb.1:
	mov	x19, x0
	adrp	x0, pts_type_closure_parallel_ParallelArray_every_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_every_arrow
	mov	x20, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_every_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_every_arrow
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_every_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_every_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_every_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_every_adapter
	mov	x1, x0
	stp	x8, x21, [x0, #8]
	mov	x0, x19
	bl	pts_fn_parallel_ParallelArray_findFound
	adrp	x8, pts_fn_parallel_ParallelArray_every.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_every.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB140_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB140_4
.LBB140_3:
	adrp	x1, pts_fn_parallel_ParallelArray_every.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_every.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB140_4:
	ldrb	w8, [x0]
	cmp	w8, #0
	cset	w0, eq
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB140_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end140:
	.size	pts_entry_parallel_ParallelArray_every, .Lfunc_end140-pts_entry_parallel_ParallelArray_every
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_every
	.type	pts_dynamic_entry_parallel_ParallelArray_every,@function
pts_dynamic_entry_parallel_ParallelArray_every: // @pts_dynamic_entry_parallel_ParallelArray_every
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB141_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB141_3
.LBB141_2:
	mov	w0, #10                         // =0xa
.LBB141_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	bl	pts_entry_parallel_ParallelArray_every
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end141:
	.size	pts_dynamic_entry_parallel_ParallelArray_every, .Lfunc_end141-pts_dynamic_entry_parallel_ParallelArray_every
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_find
	.type	pts_entry_parallel_ParallelArray_find,@function
pts_entry_parallel_ParallelArray_find:  // @pts_entry_parallel_ParallelArray_find
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB142_5
// %bb.1:
	bl	pts_fn_parallel_ParallelArray_findFound
	adrp	x8, pts_fn_parallel_ParallelArray_find.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_find.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB142_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB142_4
.LBB142_3:
	adrp	x1, pts_fn_parallel_ParallelArray_find.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_find.pts_site1
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_address_slow
.LBB142_4:
	ldr	x0, [x0]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB142_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end142:
	.size	pts_entry_parallel_ParallelArray_find, .Lfunc_end142-pts_entry_parallel_ParallelArray_find
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_find
	.type	pts_dynamic_entry_parallel_ParallelArray_find,@function
pts_dynamic_entry_parallel_ParallelArray_find: // @pts_dynamic_entry_parallel_ParallelArray_find
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	mov	x19, x0
	cbz	w1, .LBB143_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB143_3
.LBB143_2:
	mov	w0, #10                         // =0xa
.LBB143_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB143_8
// %bb.4:
	mov	x1, x0
	mov	x0, x19
	bl	pts_fn_parallel_ParallelArray_findFound
	adrp	x8, pts_fn_parallel_ParallelArray_find.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_find.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB143_6
// %bb.5:
	add	x0, x0, x8, lsr #48
	b	.LBB143_7
.LBB143_6:
	adrp	x1, pts_fn_parallel_ParallelArray_find.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_find.pts_site1
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_address_slow
.LBB143_7:
	ldr	x0, [x0]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB143_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end143:
	.size	pts_dynamic_entry_parallel_ParallelArray_find, .Lfunc_end143-pts_dynamic_entry_parallel_ParallelArray_find
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_count
	.type	pts_entry_parallel_ParallelArray_count,@function
pts_entry_parallel_ParallelArray_count: // @pts_entry_parallel_ParallelArray_count
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB144_4
// %bb.1:
	ldr	x21, [x0, #8]
	cbz	x21, .LBB144_5
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_count_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_count_arrow
	mov	x19, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_count_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_count_arrow
	mov	x20, x0
	stp	x8, x21, [x0, #8]
	str	x19, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelArray_count_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_count_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_count_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_count_adapter
	mov	x19, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_count_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_count_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_count_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_count_adapter_2
	adrp	x9, pts_static_parallel_ParallelArray_count_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelArray_count_arrow_2
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	add	x8, x21, #16
	mov	x0, x19
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	cbz	x8, .LBB144_6
// %bb.3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB144_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB144_5:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB144_6:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_to_number_slow
.Lfunc_end144:
	.size	pts_entry_parallel_ParallelArray_count, .Lfunc_end144-pts_entry_parallel_ParallelArray_count
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_count
	.type	pts_dynamic_entry_parallel_ParallelArray_count,@function
pts_dynamic_entry_parallel_ParallelArray_count: // @pts_dynamic_entry_parallel_ParallelArray_count
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB145_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB145_3
.LBB145_2:
	mov	w0, #10                         // =0xa
.LBB145_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	bl	pts_entry_parallel_ParallelArray_count
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end145:
	.size	pts_dynamic_entry_parallel_ParallelArray_count, .Lfunc_end145-pts_dynamic_entry_parallel_ParallelArray_count
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_sum
	.type	pts_entry_parallel_ParallelArray_sum,@function
pts_entry_parallel_ParallelArray_sum:   // @pts_entry_parallel_ParallelArray_sum
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB146_4
// %bb.1:
	ldr	x21, [x0, #8]
	cbz	x21, .LBB146_5
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_sum_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_sum_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_sum_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_sum_arrow
	mov	x19, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_sum_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_sum_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_sum_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_sum_adapter
	mov	x20, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_sum_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_sum_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_sum_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_sum_adapter_2
	adrp	x9, pts_static_parallel_ParallelArray_sum_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelArray_sum_arrow_2
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	add	x8, x21, #16
	mov	x0, x20
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	cbz	x8, .LBB146_6
// %bb.3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB146_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB146_5:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB146_6:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_to_number_slow
.Lfunc_end146:
	.size	pts_entry_parallel_ParallelArray_sum, .Lfunc_end146-pts_entry_parallel_ParallelArray_sum
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_sum
	.type	pts_dynamic_entry_parallel_ParallelArray_sum,@function
pts_dynamic_entry_parallel_ParallelArray_sum: // @pts_dynamic_entry_parallel_ParallelArray_sum
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_entry_parallel_ParallelArray_sum
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end147:
	.size	pts_dynamic_entry_parallel_ParallelArray_sum, .Lfunc_end147-pts_dynamic_entry_parallel_ParallelArray_sum
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_min
	.type	pts_entry_parallel_ParallelArray_min,@function
pts_entry_parallel_ParallelArray_min:   // @pts_entry_parallel_ParallelArray_min
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB148_4
// %bb.1:
	ldr	x21, [x0, #8]
	cbz	x21, .LBB148_5
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_min_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_min_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_min_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_min_arrow
	mov	x19, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_min_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_min_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_min_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_min_adapter
	mov	x20, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_min_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_min_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_min_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_min_adapter_2
	adrp	x9, pts_static_parallel_ParallelArray_min_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelArray_min_arrow_2
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	add	x8, x21, #16
	mov	x0, x20
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	cbz	x8, .LBB148_6
// %bb.3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB148_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB148_5:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB148_6:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_to_number_slow
.Lfunc_end148:
	.size	pts_entry_parallel_ParallelArray_min, .Lfunc_end148-pts_entry_parallel_ParallelArray_min
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_min
	.type	pts_dynamic_entry_parallel_ParallelArray_min,@function
pts_dynamic_entry_parallel_ParallelArray_min: // @pts_dynamic_entry_parallel_ParallelArray_min
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_entry_parallel_ParallelArray_min
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end149:
	.size	pts_dynamic_entry_parallel_ParallelArray_min, .Lfunc_end149-pts_dynamic_entry_parallel_ParallelArray_min
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_max
	.type	pts_entry_parallel_ParallelArray_max,@function
pts_entry_parallel_ParallelArray_max:   // @pts_entry_parallel_ParallelArray_max
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB150_4
// %bb.1:
	ldr	x21, [x0, #8]
	cbz	x21, .LBB150_5
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_max_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_max_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_max_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_max_arrow
	mov	x19, x0
	stp	x8, x21, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_max_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_max_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_max_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_max_adapter
	mov	x20, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_max_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_max_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_max_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_max_adapter_2
	adrp	x9, pts_static_parallel_ParallelArray_max_arrow_2
	add	x9, x9, :lo12:pts_static_parallel_ParallelArray_max_arrow_2
	mov	x1, x0
	stp	x8, x9, [x0, #8]
	add	x8, x21, #16
	mov	x0, x20
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	lsr	x8, x0, #49
	cbz	x8, .LBB150_6
// %bb.3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB150_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB150_5:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB150_6:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_to_number_slow
.Lfunc_end150:
	.size	pts_entry_parallel_ParallelArray_max, .Lfunc_end150-pts_entry_parallel_ParallelArray_max
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_max
	.type	pts_dynamic_entry_parallel_ParallelArray_max,@function
pts_dynamic_entry_parallel_ParallelArray_max: // @pts_dynamic_entry_parallel_ParallelArray_max
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	pts_entry_parallel_ParallelArray_max
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end151:
	.size	pts_dynamic_entry_parallel_ParallelArray_max, .Lfunc_end151-pts_dynamic_entry_parallel_ParallelArray_max
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_sort
	.type	pts_entry_parallel_ParallelArray_sort,@function
pts_entry_parallel_ParallelArray_sort:  // @pts_entry_parallel_ParallelArray_sort
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelArray_sort
.Lfunc_end152:
	.size	pts_entry_parallel_ParallelArray_sort, .Lfunc_end152-pts_entry_parallel_ParallelArray_sort
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_sort
	.type	pts_dynamic_entry_parallel_ParallelArray_sort,@function
pts_dynamic_entry_parallel_ParallelArray_sort: // @pts_dynamic_entry_parallel_ParallelArray_sort
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB153_2
// %bb.1:
	ldr	x8, [x2]
	cmp	x8, #10
	b.ne	.LBB153_3
.LBB153_2:
	mov	w2, wzr
	mov	x1, xzr
	b	pts_fn_parallel_ParallelArray_sort
.LBB153_3:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	x19, x0
	mov	x0, x8
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	mov	w2, #1                          // =0x1
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_ParallelArray_sort
.Lfunc_end153:
	.size	pts_dynamic_entry_parallel_ParallelArray_sort, .Lfunc_end153-pts_dynamic_entry_parallel_ParallelArray_sort
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_toArray
	.type	pts_entry_parallel_ParallelArray_toArray,@function
pts_entry_parallel_ParallelArray_toArray: // @pts_entry_parallel_ParallelArray_toArray
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB154_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB154_4
// %bb.2:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	mov	x9, #9218868437227405312        // =0x7ff0000000000000
	fmov	d0, x8
	fmov	d1, x9
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_array_slice
.LBB154_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB154_4:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end154:
	.size	pts_entry_parallel_ParallelArray_toArray, .Lfunc_end154-pts_entry_parallel_ParallelArray_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_toArray
	.type	pts_dynamic_entry_parallel_ParallelArray_toArray,@function
pts_dynamic_entry_parallel_ParallelArray_toArray: // @pts_dynamic_entry_parallel_ParallelArray_toArray
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB155_3
// %bb.1:
	ldr	x0, [x0, #8]
	cbz	x0, .LBB155_4
// %bb.2:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	mov	x9, #9218868437227405312        // =0x7ff0000000000000
	fmov	d0, x8
	fmov	d1, x9
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_array_slice
.LBB155_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB155_4:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end155:
	.size	pts_dynamic_entry_parallel_ParallelArray_toArray, .Lfunc_end155-pts_dynamic_entry_parallel_ParallelArray_toArray
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_reduceElements
	.type	pts_entry_parallel_ParallelArray_reduceElements,@function
pts_entry_parallel_ParallelArray_reduceElements: // @pts_entry_parallel_ParallelArray_reduceElements
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelArray_reduceElements
.Lfunc_end156:
	.size	pts_entry_parallel_ParallelArray_reduceElements, .Lfunc_end156-pts_entry_parallel_ParallelArray_reduceElements
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_reduceElements
	.type	pts_dynamic_entry_parallel_ParallelArray_reduceElements,@function
pts_dynamic_entry_parallel_ParallelArray_reduceElements: // @pts_dynamic_entry_parallel_ParallelArray_reduceElements
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	str	x21, [sp, #16]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	mov	x19, x0
	cbz	w1, .LBB157_3
// %bb.1:
	ldr	x0, [x2]
	mov	w20, w1
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	x21, x2
	bl	pts_value_convert
	cmp	w20, #1
	mov	x20, x0
	b.ne	.LBB157_5
// %bb.2:
	mov	w21, #10                        // =0xa
	b	.LBB157_4
.LBB157_3:
	adrp	x1, pts_check_20
	add	x1, x1, :lo12:pts_check_20
	mov	w0, #10                         // =0xa
	mov	w21, #10                        // =0xa
	bl	pts_value_convert
	mov	x20, x0
.LBB157_4:
	mov	x0, x21
	bl	pts_value_to_number_slow
	b	.LBB157_7
.LBB157_5:
	ldr	x21, [x21, #8]
	lsr	x8, x21, #49
	cbz	x8, .LBB157_4
// %bb.6:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x21, x8
	fmov	d0, x8
.LBB157_7:
	mov	x0, x19
	mov	x1, x20
	bl	pts_fn_parallel_ParallelArray_reduceElements
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end157:
	.size	pts_dynamic_entry_parallel_ParallelArray_reduceElements, .Lfunc_end157-pts_dynamic_entry_parallel_ParallelArray_reduceElements
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_entry_parallel_ParallelArray_findFound
	.type	pts_entry_parallel_ParallelArray_findFound,@function
pts_entry_parallel_ParallelArray_findFound: // @pts_entry_parallel_ParallelArray_findFound
	.cfi_startproc
// %bb.0:
	b	pts_fn_parallel_ParallelArray_findFound
.Lfunc_end158:
	.size	pts_entry_parallel_ParallelArray_findFound, .Lfunc_end158-pts_entry_parallel_ParallelArray_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_entry_parallel_ParallelArray_findFound
	.type	pts_dynamic_entry_parallel_ParallelArray_findFound,@function
pts_dynamic_entry_parallel_ParallelArray_findFound: // @pts_dynamic_entry_parallel_ParallelArray_findFound
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	cbz	w1, .LBB159_2
// %bb.1:
	ldr	x0, [x2]
	b	.LBB159_3
.LBB159_2:
	mov	w0, #10                         // =0xa
.LBB159_3:
	adrp	x1, pts_check_26
	add	x1, x1, :lo12:pts_check_26
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x19
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_ParallelArray_findFound
.Lfunc_end159:
	.size	pts_dynamic_entry_parallel_ParallelArray_findFound, .Lfunc_end159-pts_dynamic_entry_parallel_ParallelArray_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_forEach_arrow
	.type	pts_fn_parallel_ParallelArray_forEach_arrow,@function
pts_fn_parallel_ParallelArray_forEach_arrow: // @pts_fn_parallel_ParallelArray_forEach_arrow
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-80]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 80
	stp	d9, d8, [sp, #8]                // 16-byte Folded Spill
	stp	x29, x30, [sp, #24]             // 16-byte Folded Spill
	str	x23, [sp, #40]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #24
	.cfi_def_cfa w29, 56
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	.cfi_offset w29, -56
	.cfi_offset b8, -64
	.cfi_offset b9, -72
	.cfi_offset b10, -80
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB160_17
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d9, d1
	fmov	d8, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	fcmp	d8, d9
	b.pl	.LBB160_16
// %bb.2:
	adrp	x22, :got:pts_type_match_array
	fmov	d10, #1.00000000
	adrp	x23, :got:pts_type_match_copy
	ldr	x22, [x22, :got_lo12:pts_type_match_array]
	ldr	x23, [x23, :got_lo12:pts_type_match_copy]
	mov	w21, w0
	b	.LBB160_5
.LBB160_3:                              //   in Loop: Header=BB160_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.eq	.LBB160_9
.LBB160_4:                              //   in Loop: Header=BB160_5 Depth=1
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.pl	.LBB160_16
.LBB160_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w21, #0, .LBB160_9
// %bb.6:                               //   in Loop: Header=BB160_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d8, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d8, d0
	fcvtzu	d0, d8
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB160_3
// %bb.7:                               //   in Loop: Header=BB160_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.ne	.LBB160_4
// %bb.8:                               //   in Loop: Header=BB160_5 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB160_12
.LBB160_9:                              //   in Loop: Header=BB160_5 Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x20, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d8, #0.0
	b.lt	.LBB160_18
// %bb.10:                              //   in Loop: Header=BB160_5 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x10
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB160_18
// %bb.11:                              //   in Loop: Header=BB160_5 Depth=1
	fcvtzu	x10, d8
	fmov	d1, d8
	mov	x0, x20
	mov	x1, x19
	add	x9, x9, x10, lsl #3
	ldr	d0, [x9, #8]
	blr	x8
	b	.LBB160_4
.LBB160_12:                             //   in Loop: Header=BB160_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB160_15
// %bb.13:                              //   in Loop: Header=BB160_5 Depth=1
	cmp	x8, x22
	b.eq	.LBB160_9
.LBB160_14:                             //   in Loop: Header=BB160_5 Depth=1
	cmp	x8, x23
	b.ne	.LBB160_4
	b	.LBB160_9
.LBB160_15:                             //   in Loop: Header=BB160_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x22
	b.ne	.LBB160_14
	b	.LBB160_9
.LBB160_16:
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldr	x23, [sp, #40]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #24]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #8]                // 16-byte Folded Reload
	ldr	d10, [sp], #80                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB160_17:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB160_18:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end160:
	.size	pts_fn_parallel_ParallelArray_forEach_arrow, .Lfunc_end160-pts_fn_parallel_ParallelArray_forEach_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_forEach_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_forEach_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_forEach_arrow: // @pts_dynamic_fn_parallel_ParallelArray_forEach_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB161_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB161_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB161_7
.LBB161_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB161_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB161_9
.LBB161_5:
	mov	w0, #10                         // =0xa
.LBB161_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB161_3
.LBB161_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB161_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB161_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB161_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB161_8
.Lfunc_end161:
	.size	pts_dynamic_fn_parallel_ParallelArray_forEach_arrow, .Lfunc_end161-pts_dynamic_fn_parallel_ParallelArray_forEach_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_48
	.type	pts_adapt_48,@function
pts_adapt_48:                           // @pts_adapt_48
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_48
	add	x0, x0, :lo12:pts_type_adapter_48
	bl	pts_object_new
	adrp	x8, pts_adapter_48
	add	x8, x8, :lo12:pts_adapter_48
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end162:
	.size	pts_adapt_48, .Lfunc_end162-pts_adapt_48
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_48
	.type	pts_adapter_48,@function
pts_adapter_48:                         // @pts_adapter_48
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	str	x1, [sp, #24]
	add	x2, sp, #8
	mov	w1, #3                          // =0x3
	add	x9, x9, x8
	csel	x9, x10, x9, vs
	fcmp	d1, d1
	add	x8, x11, x8
	csel	x8, x10, x8, vs
	stp	x9, x8, [sp, #8]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end163:
	.size	pts_adapter_48, .Lfunc_end163-pts_adapter_48
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_49
	.type	pts_adapt_49,@function
pts_adapt_49:                           // @pts_adapt_49
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_49
	add	x0, x0, :lo12:pts_type_adapter_49
	bl	pts_object_new
	adrp	x8, pts_adapter_49
	add	x8, x8, :lo12:pts_adapter_49
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end164:
	.size	pts_adapt_49, .Lfunc_end164-pts_adapt_49
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_49
	.type	pts_adapter_49,@function
pts_adapter_49:                         // @pts_adapter_49
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end165:
	.size	pts_adapter_49, .Lfunc_end165-pts_adapter_49
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_filter_arrow
	.type	pts_fn_parallel_ParallelArray_filter_arrow,@function
pts_fn_parallel_ParallelArray_filter_arrow: // @pts_fn_parallel_ParallelArray_filter_arrow
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	str	d10, [sp, #16]                  // 8-byte Folded Spill
	stp	d9, d8, [sp, #24]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #40]             // 16-byte Folded Spill
	str	x25, [sp, #56]                  // 8-byte Folded Spill
	stp	x24, x23, [sp, #64]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #40
	.cfi_def_cfa w29, 72
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w30, -64
	.cfi_offset w29, -72
	.cfi_offset b8, -80
	.cfi_offset b9, -88
	.cfi_offset b10, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB166_19
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d9, d1
	fmov	d8, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	adrp	x8, :got:pts_array_types
	mov	w21, w0
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:pts_array_types]
	mov	x2, xzr
	add	x0, x8, #136
	bl	pts_array_of
	fcmp	d8, d9
	mov	x22, x0
	b.pl	.LBB166_18
// %bb.2:
	adrp	x23, :got:pts_type_match_array
	fmov	d10, #1.00000000
	adrp	x24, :got:pts_type_match_copy
	ldr	x23, [x23, :got_lo12:pts_type_match_array]
	ldr	x24, [x24, :got_lo12:pts_type_match_copy]
	b	.LBB166_5
.LBB166_3:                              //   in Loop: Header=BB166_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.eq	.LBB166_9
.LBB166_4:                              //   in Loop: Header=BB166_5 Depth=1
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.pl	.LBB166_18
.LBB166_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w21, #0, .LBB166_9
// %bb.6:                               //   in Loop: Header=BB166_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d8, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d8, d0
	fcvtzu	d0, d8
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB166_3
// %bb.7:                               //   in Loop: Header=BB166_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.ne	.LBB166_4
// %bb.8:                               //   in Loop: Header=BB166_5 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB166_14
.LBB166_9:                              //   in Loop: Header=BB166_5 Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x20, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d8, #0.0
	b.lt	.LBB166_20
// %bb.10:                              //   in Loop: Header=BB166_5 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x10
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB166_20
// %bb.11:                              //   in Loop: Header=BB166_5 Depth=1
	fcvtzu	x25, d8
	fmov	d1, d8
	mov	x0, x20
	mov	x1, x19
	add	x9, x9, x25, lsl #3
	ldr	d0, [x9, #8]
	blr	x8
	bl	pts_value_truthy
	tbz	w0, #0, .LBB166_4
// %bb.12:                              //   in Loop: Header=BB166_5 Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	ucvtf	d0, x9
	fcmp	d8, d0
	b.pl	.LBB166_20
// %bb.13:                              //   in Loop: Header=BB166_5 Depth=1
	add	x8, x8, x25, lsl #3
	add	x1, sp, #8
	mov	x0, x22
	mov	w2, #1                          // =0x1
	ldr	d0, [x8, #8]
	str	d0, [sp, #8]
	bl	pts_array_push
	b	.LBB166_4
.LBB166_14:                             //   in Loop: Header=BB166_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB166_17
// %bb.15:                              //   in Loop: Header=BB166_5 Depth=1
	cmp	x8, x23
	b.eq	.LBB166_9
.LBB166_16:                             //   in Loop: Header=BB166_5 Depth=1
	cmp	x8, x24
	b.ne	.LBB166_4
	b	.LBB166_9
.LBB166_17:                             //   in Loop: Header=BB166_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x23
	b.ne	.LBB166_16
	b	.LBB166_9
.LBB166_18:
	mov	x0, x22
	.cfi_def_cfa wsp, 112
	ldp	x20, x19, [sp, #96]             // 16-byte Folded Reload
	ldr	x25, [sp, #56]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #80]             // 16-byte Folded Reload
	ldr	d10, [sp, #16]                  // 8-byte Folded Reload
	ldp	x24, x23, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #40]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #24]               // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB166_19:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB166_20:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end166:
	.size	pts_fn_parallel_ParallelArray_filter_arrow, .Lfunc_end166-pts_fn_parallel_ParallelArray_filter_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_filter_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_filter_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_filter_arrow: // @pts_dynamic_fn_parallel_ParallelArray_filter_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB167_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB167_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB167_7
.LBB167_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB167_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB167_9
.LBB167_5:
	mov	w0, #10                         // =0xa
.LBB167_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB167_3
.LBB167_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB167_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB167_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB167_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB167_8
.Lfunc_end167:
	.size	pts_dynamic_fn_parallel_ParallelArray_filter_arrow, .Lfunc_end167-pts_dynamic_fn_parallel_ParallelArray_filter_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_filter_adapter
	.type	pts_fn_parallel_ParallelArray_filter_adapter,@function
pts_fn_parallel_ParallelArray_filter_adapter: // @pts_fn_parallel_ParallelArray_filter_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB168_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB168_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end168:
	.size	pts_fn_parallel_ParallelArray_filter_adapter, .Lfunc_end168-pts_fn_parallel_ParallelArray_filter_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_filter_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_filter_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_filter_adapter: // @pts_dynamic_fn_parallel_ParallelArray_filter_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB169_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB169_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB169_7
.LBB169_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB169_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB169_9
.LBB169_5:
	mov	w0, #10                         // =0xa
.LBB169_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB169_3
.LBB169_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB169_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB169_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB169_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB169_8
.Lfunc_end169:
	.size	pts_dynamic_fn_parallel_ParallelArray_filter_adapter, .Lfunc_end169-pts_dynamic_fn_parallel_ParallelArray_filter_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_filter_arrow_2
	.type	pts_fn_parallel_ParallelArray_filter_arrow_2,@function
pts_fn_parallel_ParallelArray_filter_arrow_2: // @pts_fn_parallel_ParallelArray_filter_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-48]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB170_2
// %bb.1:
	adrp	x20, pts_check_1
	add	x20, x20, :lo12:pts_check_1
	mov	x0, x1
	mov	x1, x20
	mov	x19, x2
	bl	pts_value_convert
	adrp	x8, :got:pts_array_types
	mov	x21, x0
	mov	x1, xzr
	ldr	x8, [x8, :got_lo12:pts_array_types]
	mov	x2, xzr
	add	x0, x8, #136
	bl	pts_array_of
	bl	pts_array_copy
	mov	x22, x0
	mov	x0, x19
	mov	x1, x20
	bl	pts_value_convert
	mov	x1, x0
	mov	x0, x22
	bl	pts_array_append
	mov	x0, x21
	mov	x1, x22
	bl	pts_array_push_all
	mov	x0, x21
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #48             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB170_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end170:
	.size	pts_fn_parallel_ParallelArray_filter_arrow_2, .Lfunc_end170-pts_fn_parallel_ParallelArray_filter_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB171_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB171_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB171_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB171_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end171:
	.size	pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2, .Lfunc_end171-pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_filter_adapter_2
	.type	pts_fn_parallel_ParallelArray_filter_adapter_2,@function
pts_fn_parallel_ParallelArray_filter_adapter_2: // @pts_fn_parallel_ParallelArray_filter_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB172_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x3, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x3
.LBB172_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end172:
	.size	pts_fn_parallel_ParallelArray_filter_adapter_2, .Lfunc_end172-pts_fn_parallel_ParallelArray_filter_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB173_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB173_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB173_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB173_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end173:
	.size	pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2, .Lfunc_end173-pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_26
	.type	pts_adapt_26,@function
pts_adapt_26:                           // @pts_adapt_26
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_26
	add	x0, x0, :lo12:pts_type_adapter_26
	bl	pts_object_new
	adrp	x8, pts_adapter_26
	add	x8, x8, :lo12:pts_adapter_26
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end174:
	.size	pts_adapt_26, .Lfunc_end174-pts_adapt_26
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_26
	.type	pts_adapter_26,@function
pts_adapter_26:                         // @pts_adapter_26
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	str	x1, [sp, #24]
	add	x2, sp, #8
	mov	w1, #3                          // =0x3
	add	x9, x9, x8
	csel	x9, x10, x9, vs
	fcmp	d1, d1
	add	x8, x11, x8
	csel	x8, x10, x8, vs
	stp	x9, x8, [sp, #8]
	bl	pts_dynamic_call_closure
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end175:
	.size	pts_adapter_26, .Lfunc_end175-pts_adapter_26
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_50
	.type	pts_adapt_50,@function
pts_adapt_50:                           // @pts_adapt_50
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_50
	add	x0, x0, :lo12:pts_type_adapter_50
	bl	pts_object_new
	adrp	x8, pts_adapter_50
	add	x8, x8, :lo12:pts_adapter_50
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end176:
	.size	pts_adapt_50, .Lfunc_end176-pts_adapt_50
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_50
	.type	pts_adapter_50,@function
pts_adapter_50:                         // @pts_adapter_50
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end177:
	.size	pts_adapter_50, .Lfunc_end177-pts_adapter_50
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduceElements
	.type	pts_fn_parallel_ParallelArray_reduceElements,@function
pts_fn_parallel_ParallelArray_reduceElements: // @pts_fn_parallel_ParallelArray_reduceElements
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-64]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB178_12
// %bb.1:
	ldr	x22, [x0, #8]
	cbz	x22, .LBB178_13
// %bb.2:
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduceElements_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduceElements_arrow
	fmov	d8, d0
	mov	x19, x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow
	mov	x20, x0
	stp	x8, x22, [x0, #8]
	str	x19, [x0, #24]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduceElements_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduceElements_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_adapter
	mov	x21, x0
	stp	x8, x20, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	mov	x20, x0
	stp	x8, x19, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	mov	x1, x0
	stp	x8, x20, [x0, #8]
	add	x8, x22, #16
	mov	x0, x21
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	bl	pts_value_convert
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	mov	x20, x0
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB178_6
// %bb.3:
	add	x0, x20, x8, lsr #48
	ldrb	w8, [x0]
	cbz	w8, .LBB178_7
.LBB178_4:
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	ldr	x1, [x19, #8]
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements.pts_site2]
	ldr	x9, [x20]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB178_8
// %bb.5:
	add	x0, x20, x8, lsr #48
	b	.LBB178_9
.LBB178_6:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	mov	x0, x20
	bl	pts_field_address_slow
	ldrb	w8, [x0]
	cbnz	w8, .LBB178_4
.LBB178_7:
	fmov	d0, d8
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB178_8:
	.cfi_restore_state
	.cfi_remember_state
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	mov	x0, x20
	bl	pts_field_address_slow
	ldr	x1, [sp, #8]                    // 8-byte Folded Reload
.LBB178_9:
	ldr	x0, [x0]
	lsr	x8, x0, #49
	cbz	x8, .LBB178_14
// %bb.10:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
.LBB178_11:
	mov	x0, x19
	fmov	d0, d8
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB178_12:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB178_13:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB178_14:
	str	x1, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	fmov	d1, d0
	ldr	x1, [sp, #8]                    // 8-byte Folded Reload
	b	.LBB178_11
.Lfunc_end178:
	.size	pts_fn_parallel_ParallelArray_reduceElements, .Lfunc_end178-pts_fn_parallel_ParallelArray_reduceElements
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduceElements_arrow
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow,@function
pts_fn_parallel_ParallelArray_reduceElements_arrow: // @pts_fn_parallel_ParallelArray_reduceElements_arrow
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	str	d10, [sp, #16]                  // 8-byte Folded Spill
	stp	d9, d8, [sp, #32]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #64]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #80]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #96]             // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB179_38
// %bb.1:
	ldp	x20, x21, [x0, #16]
	fmov	d8, d1
	fmov	d9, d0
	mov	x0, x20
	bl	pts_parallel_has_holes_in
	mov	w22, w0
	adrp	x0, pts_type_object4
	add	x0, x0, :lo12:pts_type_object4
	bl	pts_object_new
	mov	x19, x0
	mov	w8, #10                         // =0xa
	strb	wzr, [x0, #8]
	str	x8, [x0, #16]
	tbz	w22, #0, .LBB179_13
// %bb.2:
	fcmp	d9, d8
	b.pl	.LBB179_13
// %bb.3:
	adrp	x8, :got:pts_type_match_array
	fmov	d0, #1.00000000
	adrp	x9, :got:pts_type_match_copy
	ldr	x8, [x8, :got_lo12:pts_type_match_array]
	ldr	x9, [x9, :got_lo12:pts_type_match_copy]
	b	.LBB179_6
.LBB179_4:                              //   in Loop: Header=BB179_6 Depth=1
	cmp	w11, #0
	fccmp	d9, d1, #0, ne
	b.eq	.LBB179_13
.LBB179_5:                              //   in Loop: Header=BB179_6 Depth=1
	fadd	d9, d9, d0
	fcmp	d9, d8
	b.pl	.LBB179_13
.LBB179_6:                              // =>This Inner Loop Header: Depth=1
	mov	x10, x20
	add	x12, x20, #16
	ldr	x11, [x10], #8
	ldr	w11, [x11, #64]
	ldar	x12, [x12]
	ldar	x10, [x10]
	ldr	x13, [x10]
	cmp	x12, x13
	csel	x12, x12, x13, lo
	fcmp	d9, #0.0
	sub	w13, w11, #3
	ucvtf	d1, x12
	cset	w12, ge
	fcmp	d9, d1
	fcvtzu	d1, d9
	csel	w11, wzr, w12, pl
	cmp	w13, #2
	ucvtf	d1, d1
	b.hi	.LBB179_4
// %bb.7:                               //   in Loop: Header=BB179_6 Depth=1
	cmp	w11, #0
	fccmp	d9, d1, #0, ne
	b.ne	.LBB179_5
// %bb.8:                               //   in Loop: Header=BB179_6 Depth=1
	fcvtzu	x11, d9
	add	x10, x10, x11, lsl #3
	ldr	x10, [x10, #8]
	cbnz	x10, .LBB179_13
// %bb.9:                               //   in Loop: Header=BB179_6 Depth=1
	ldr	x10, [x20]
	ldrb	w11, [x10, #4]
	cbnz	w11, .LBB179_12
// %bb.10:                              //   in Loop: Header=BB179_6 Depth=1
	cmp	x10, x8
	b.eq	.LBB179_13
.LBB179_11:                             //   in Loop: Header=BB179_6 Depth=1
	cmp	x10, x9
	b.ne	.LBB179_5
	b	.LBB179_13
.LBB179_12:                             //   in Loop: Header=BB179_6 Depth=1
	ldr	x10, [x10, #24]
	cmp	x10, x8
	b.ne	.LBB179_11
.LBB179_13:
	fcmp	d9, d8
	b.eq	.LBB179_37
// %bb.14:
	add	x8, x20, #16
	add	x9, x20, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d9, #0.0
	b.lt	.LBB179_39
// %bb.15:
	fcvtzu	d0, d9
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d9, d1
	fccmp	d9, d0, #0, mi
	b.ne	.LBB179_39
// %bb.16:
	fmov	d10, #1.00000000
	fcvtzu	x9, d9
	fadd	d9, d9, d10
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	fcmp	d9, d8
	b.pl	.LBB179_31
// %bb.17:
	adrp	x23, :got:pts_type_match_array
	adrp	x24, :got:pts_type_match_copy
	ldr	x23, [x23, :got_lo12:pts_type_match_array]
	ldr	x24, [x24, :got_lo12:pts_type_match_copy]
	b	.LBB179_20
.LBB179_18:                             //   in Loop: Header=BB179_20 Depth=1
	cmp	w9, #0
	fccmp	d9, d1, #0, ne
	b.eq	.LBB179_23
.LBB179_19:                             //   in Loop: Header=BB179_20 Depth=1
	fadd	d9, d9, d10
	fcmp	d9, d8
	b.pl	.LBB179_31
.LBB179_20:                             // =>This Inner Loop Header: Depth=1
	tbz	w22, #0, .LBB179_24
// %bb.21:                              //   in Loop: Header=BB179_20 Depth=1
	mov	x8, x20
	add	x10, x20, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d9, #0.0
	sub	w11, w9, #3
	ucvtf	d1, x10
	cset	w10, ge
	fcmp	d9, d1
	fcvtzu	d1, d9
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d1, d1
	b.ls	.LBB179_18
// %bb.22:                              //   in Loop: Header=BB179_20 Depth=1
	cmp	w9, #0
	fccmp	d9, d1, #0, ne
	b.ne	.LBB179_19
	b	.LBB179_24
.LBB179_23:                             //   in Loop: Header=BB179_20 Depth=1
	fcvtzu	x9, d9
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB179_27
.LBB179_24:                             //   in Loop: Header=BB179_20 Depth=1
	add	x9, x20, #16
	add	x10, x20, #8
	ldr	x8, [x21, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d9, #0.0
	b.lt	.LBB179_39
// %bb.25:                              //   in Loop: Header=BB179_20 Depth=1
	fcvtzu	d1, d9
	ucvtf	d2, x10
	ucvtf	d1, d1
	fcmp	d9, d2
	fccmp	d9, d1, #0, mi
	b.ne	.LBB179_39
// %bb.26:                              //   in Loop: Header=BB179_20 Depth=1
	fcvtzu	x10, d9
	mov	x0, x21
	add	x9, x9, x10, lsl #3
	ldr	d1, [x9, #8]
	blr	x8
	b	.LBB179_19
.LBB179_27:                             //   in Loop: Header=BB179_20 Depth=1
	ldr	x8, [x20]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB179_30
// %bb.28:                              //   in Loop: Header=BB179_20 Depth=1
	cmp	x8, x23
	b.eq	.LBB179_24
.LBB179_29:                             //   in Loop: Header=BB179_20 Depth=1
	cmp	x8, x24
	b.ne	.LBB179_19
	b	.LBB179_24
.LBB179_30:                             //   in Loop: Header=BB179_20 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x23
	b.ne	.LBB179_29
	b	.LBB179_24
.LBB179_31:
	mov	w9, #1                          // =0x1
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	sturb	w9, [x29, #-20]
	ldr	x10, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1]
	ldr	x8, [x19]
	and	x11, x10, #0xffffffffffff
	cmp	x11, x8
	b.ne	.LBB179_33
// %bb.32:
	lsr	x10, x10, #48
	strb	w9, [x19, x10]
	b	.LBB179_34
.LBB179_33:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	sub	x4, x29, #20
	mov	x0, x19
	fmov	d8, d0
	bl	pts_field_set_slow
	fmov	d0, d8
	ldr	x8, [x19]
.LBB179_34:
	fmov	x9, d0
	fcmp	d0, d0
	mov	x10, #562949953421312           // =0x2000000000000
	add	x9, x9, x10
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	csel	x9, x10, x9, vs
	adrp	x10, pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	str	x9, [sp, #8]
	ldr	x10, [x10, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2]
	and	x11, x10, #0xffffffffffff
	cmp	x11, x8
	b.ne	.LBB179_36
// %bb.35:
	lsr	x8, x10, #48
	str	x9, [x19, x8]
	b	.LBB179_37
.LBB179_36:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	add	x4, sp, #8
	mov	x0, x19
	bl	pts_field_set_slow
.LBB179_37:
	mov	x0, x19
	.cfi_def_cfa wsp, 112
	ldp	x20, x19, [sp, #96]             // 16-byte Folded Reload
	ldr	d10, [sp, #16]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #80]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB179_38:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB179_39:
	fmov	d0, d9
	mov	x0, x20
	bl	pts_array_index_error
.Lfunc_end179:
	.size	pts_fn_parallel_ParallelArray_reduceElements_arrow, .Lfunc_end179-pts_fn_parallel_ParallelArray_reduceElements_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow: // @pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB180_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB180_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB180_7
.LBB180_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB180_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB180_9
.LBB180_5:
	mov	w0, #10                         // =0xa
.LBB180_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB180_3
.LBB180_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB180_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB180_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB180_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB180_8
.Lfunc_end180:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow, .Lfunc_end180-pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduceElements_adapter
	.type	pts_fn_parallel_ParallelArray_reduceElements_adapter,@function
pts_fn_parallel_ParallelArray_reduceElements_adapter: // @pts_fn_parallel_ParallelArray_reduceElements_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB181_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB181_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end181:
	.size	pts_fn_parallel_ParallelArray_reduceElements_adapter, .Lfunc_end181-pts_fn_parallel_ParallelArray_reduceElements_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter: // @pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB182_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB182_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB182_7
.LBB182_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB182_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB182_9
.LBB182_5:
	mov	w0, #10                         // =0xa
.LBB182_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB182_3
.LBB182_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB182_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB182_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB182_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB182_8
.Lfunc_end182:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter, .Lfunc_end182-pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2,@function
pts_fn_parallel_ParallelArray_reduceElements_arrow_2: // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-64]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB183_22
// %bb.1:
	adrp	x22, pts_check_3
	add	x22, x22, :lo12:pts_check_3
	ldr	x20, [x0, #16]
	mov	x0, x1
	mov	x1, x22
	mov	x21, x2
	bl	pts_value_convert
	mov	x19, x0
	mov	x0, x21
	mov	x1, x22
	bl	pts_value_convert
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	mov	x21, x0
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1]
	ldr	x9, [x19]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB183_5
// %bb.2:
	add	x0, x19, x8, lsr #48
	ldrb	w8, [x0]
	cbz	w8, .LBB183_6
.LBB183_3:
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2]
	ldr	x9, [x21]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB183_7
// %bb.4:
	add	x0, x21, x8, lsr #48
	ldrb	w8, [x0]
	cbnz	w8, .LBB183_8
	b	.LBB183_21
.LBB183_5:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	mov	x0, x19
	bl	pts_field_address_slow
	ldrb	w8, [x0]
	cbnz	w8, .LBB183_3
.LBB183_6:
	mov	x19, x21
	b	.LBB183_21
.LBB183_7:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	mov	x0, x21
	bl	pts_field_address_slow
	ldrb	w8, [x0]
	cbz	w8, .LBB183_21
.LBB183_8:
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	ldr	x22, [x20, #8]
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3]
	ldr	x9, [x19]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB183_10
// %bb.9:
	add	x0, x19, x8, lsr #48
	b	.LBB183_11
.LBB183_10:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	mov	x0, x19
	bl	pts_field_address_slow
.LBB183_11:
	ldr	x0, [x0]
	lsr	x8, x0, #49
	cbz	x8, .LBB183_23
// %bb.12:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d8, x8
.LBB183_13:
	adrp	x8, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4]
	ldr	x9, [x21]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB183_15
// %bb.14:
	add	x0, x21, x8, lsr #48
	b	.LBB183_16
.LBB183_15:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	mov	x0, x21
	bl	pts_field_address_slow
.LBB183_16:
	ldr	x0, [x0]
	lsr	x8, x0, #49
	cbz	x8, .LBB183_24
// %bb.17:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
.LBB183_18:
	fmov	d0, d8
	mov	x0, x20
	blr	x22
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x8, x9, x8, vs
	adrp	x9, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	str	x8, [sp, #8]
	ldr	x9, [x9, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5]
	ldr	x10, [x19]
	and	x11, x9, #0xffffffffffff
	cmp	x11, x10
	b.ne	.LBB183_20
// %bb.19:
	lsr	x9, x9, #48
	str	x8, [x19, x9]
	b	.LBB183_21
.LBB183_20:
	adrp	x1, pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	add	x4, sp, #8
	mov	x0, x19
	bl	pts_field_set_slow
.LBB183_21:
	mov	x0, x19
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #64                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB183_22:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB183_23:
	bl	pts_value_to_number_slow
	fmov	d8, d0
	b	.LBB183_13
.LBB183_24:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	b	.LBB183_18
.Lfunc_end183:
	.size	pts_fn_parallel_ParallelArray_reduceElements_arrow_2, .Lfunc_end183-pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB184_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB184_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB184_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB184_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end184:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2, .Lfunc_end184-pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_28
	.type	pts_adapt_28,@function
pts_adapt_28:                           // @pts_adapt_28
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_28
	add	x0, x0, :lo12:pts_type_adapter_28
	bl	pts_object_new
	adrp	x8, pts_adapter_28
	add	x8, x8, :lo12:pts_adapter_28
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end185:
	.size	pts_adapt_28, .Lfunc_end185-pts_adapt_28
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_28
	.type	pts_adapter_28,@function
pts_adapter_28:                         // @pts_adapter_28
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	stp	x1, x2, [sp]
	mov	x2, sp
	mov	w1, #2                          // =0x2
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end186:
	.size	pts_adapter_28, .Lfunc_end186-pts_adapter_28
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	.type	pts_fn_parallel_ParallelArray_reduceElements_adapter_2,@function
pts_fn_parallel_ParallelArray_reduceElements_adapter_2: // @pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB187_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x3, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x3
.LBB187_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end187:
	.size	pts_fn_parallel_ParallelArray_reduceElements_adapter_2, .Lfunc_end187-pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB188_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB188_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB188_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB188_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end188:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2, .Lfunc_end188-pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduce_arrow
	.type	pts_fn_parallel_ParallelArray_reduce_arrow,@function
pts_fn_parallel_ParallelArray_reduce_arrow: // @pts_fn_parallel_ParallelArray_reduce_arrow
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-64]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB189_8
// %bb.1:
	ldp	x19, x20, [x0, #16]
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	b.lt	.LBB189_10
// %bb.2:
	fmov	d8, d1
	fcvtzu	d1, d0
	ucvtf	d2, x9
	ucvtf	d1, d1
	fcmp	d2, d0
	fccmp	d1, d0, #0, gt
	b.ne	.LBB189_10
// %bb.3:
	fmov	d10, #1.00000000
	fcvtzu	x9, d0
	fadd	d9, d0, d10
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	fcmp	d9, d8
	b.pl	.LBB189_7
.LBB189_4:                              // =>This Inner Loop Header: Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x20, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d9, #0.0
	b.lt	.LBB189_9
// %bb.5:                               //   in Loop: Header=BB189_4 Depth=1
	fcvtzu	d1, d9
	ucvtf	d2, x10
	ucvtf	d1, d1
	fcmp	d9, d2
	fccmp	d9, d1, #0, mi
	b.ne	.LBB189_9
// %bb.6:                               //   in Loop: Header=BB189_4 Depth=1
	fcvtzu	x10, d9
	mov	x0, x20
	add	x9, x9, x10, lsl #3
	ldr	d1, [x9, #8]
	blr	x8
	fadd	d9, d9, d10
	fcmp	d9, d8
	b.mi	.LBB189_4
.LBB189_7:
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldr	d10, [sp], #64                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB189_8:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB189_9:
	fmov	d0, d9
.LBB189_10:
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end189:
	.size	pts_fn_parallel_ParallelArray_reduce_arrow, .Lfunc_end189-pts_fn_parallel_ParallelArray_reduce_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduce_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_reduce_arrow: // @pts_dynamic_fn_parallel_ParallelArray_reduce_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB190_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB190_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB190_7
.LBB190_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB190_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB190_9
.LBB190_5:
	mov	w0, #10                         // =0xa
.LBB190_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB190_3
.LBB190_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB190_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB190_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB190_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB190_8
.Lfunc_end190:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow, .Lfunc_end190-pts_dynamic_fn_parallel_ParallelArray_reduce_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduce_adapter
	.type	pts_fn_parallel_ParallelArray_reduce_adapter,@function
pts_fn_parallel_ParallelArray_reduce_adapter: // @pts_fn_parallel_ParallelArray_reduce_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB191_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB191_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end191:
	.size	pts_fn_parallel_ParallelArray_reduce_adapter, .Lfunc_end191-pts_fn_parallel_ParallelArray_reduce_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduce_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_reduce_adapter: // @pts_dynamic_fn_parallel_ParallelArray_reduce_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB192_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB192_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB192_7
.LBB192_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB192_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB192_9
.LBB192_5:
	mov	w0, #10                         // =0xa
.LBB192_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB192_3
.LBB192_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB192_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB192_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB192_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB192_8
.Lfunc_end192:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter, .Lfunc_end192-pts_dynamic_fn_parallel_ParallelArray_reduce_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduce_arrow_2
	.type	pts_fn_parallel_ParallelArray_reduce_arrow_2,@function
pts_fn_parallel_ParallelArray_reduce_arrow_2: // @pts_fn_parallel_ParallelArray_reduce_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB193_5
// %bb.1:
	ldr	x0, [x0, #16]
	lsr	x8, x1, #49
	ldr	x3, [x0, #8]
	cbz	x8, .LBB193_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d0, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB193_7
.LBB193_3:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d1, x8
.LBB193_4:
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x3
.LBB193_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB193_6:
	mov	x19, x0
	mov	x0, x1
	mov	x20, x2
	str	x3, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	ldr	x3, [sp, #8]                    // 8-byte Folded Reload
	mov	x2, x20
	mov	x0, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB193_3
.LBB193_7:
	mov	x19, x0
	mov	x0, x2
	fmov	d8, d0
	str	x3, [sp, #8]                    // 8-byte Folded Spill
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
	ldr	x3, [sp, #8]                    // 8-byte Folded Reload
	mov	x0, x19
	b	.LBB193_4
.Lfunc_end193:
	.size	pts_fn_parallel_ParallelArray_reduce_arrow_2, .Lfunc_end193-pts_fn_parallel_ParallelArray_reduce_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB194_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB194_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB194_5
.LBB194_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB194_5
.LBB194_4:
	ldr	x2, [x2, #8]
.LBB194_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end194:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2, .Lfunc_end194-pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_reduce_adapter_2
	.type	pts_fn_parallel_ParallelArray_reduce_adapter_2,@function
pts_fn_parallel_ParallelArray_reduce_adapter_2: // @pts_fn_parallel_ParallelArray_reduce_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB195_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB195_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end195:
	.size	pts_fn_parallel_ParallelArray_reduce_adapter_2, .Lfunc_end195-pts_fn_parallel_ParallelArray_reduce_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB196_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB196_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB196_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB196_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end196:
	.size	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2, .Lfunc_end196-pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_findFound
	.type	pts_fn_parallel_ParallelArray_findFound,@function
pts_fn_parallel_ParallelArray_findFound: // @pts_fn_parallel_ParallelArray_findFound
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-64]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	str	x23, [sp, #16]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB197_3
// %bb.1:
	ldr	x20, [x0, #8]
	cbz	x20, .LBB197_4
// %bb.2:
	mov	x0, x20
	mov	x19, x1
	bl	pts_parallel_holds_pointers
	mov	w21, w0
	adrp	x0, pts_type_object3
	add	x0, x0, :lo12:pts_type_object3
	bl	pts_object_new
	mov	x22, x0
	strb	wzr, [x0, #8]
	adrp	x0, pts_type_closure_parallel_ParallelArray_findFound_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_findFound_arrow
	and	w23, w21, #0x1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_arrow
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow
	mov	x21, x0
	stp	x8, x22, [x0, #8]
	strb	w23, [x0, #24]
	stp	x20, x19, [x0, #32]
	adrp	x0, pts_type_closure_parallel_ParallelArray_findFound_adapter
	add	x0, x0, :lo12:pts_type_closure_parallel_ParallelArray_findFound_adapter
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_adapter
	add	x8, x8, :lo12:pts_fn_parallel_ParallelArray_findFound_adapter
	adrp	x1, pts_static_parallel_ParallelArray_findFound_arrow_2
	add	x1, x1, :lo12:pts_static_parallel_ParallelArray_findFound_arrow_2
	stp	x8, x21, [x0, #8]
	add	x8, x20, #16
	ldar	x8, [x8]
	ucvtf	d0, x8
	bl	pts_parallel_reduce
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x23, [sp, #16]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #64             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_convert
.LBB197_3:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB197_4:
	adrp	x0, .L.str.205
	add	x0, x0, :lo12:.L.str.205
	mov	x1, xzr
	bl	pts_throw_unset_field
.Lfunc_end197:
	.size	pts_fn_parallel_ParallelArray_findFound, .Lfunc_end197-pts_fn_parallel_ParallelArray_findFound
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_findFound_arrow
	.type	pts_fn_parallel_ParallelArray_findFound_arrow,@function
pts_fn_parallel_ParallelArray_findFound_arrow: // @pts_fn_parallel_ParallelArray_findFound_arrow
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #144
	.cfi_def_cfa_offset 144
	str	d10, [sp, #16]                  // 8-byte Folded Spill
	stp	d9, d8, [sp, #32]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #48]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #64]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #80]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #96]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #112]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #128]            // 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -128
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB198_31
// %bb.1:
	ldp	x19, x21, [x0, #32]
	fmov	d9, d1
	ldr	x20, [x0, #16]
	ldrb	w27, [x0, #24]
	adrp	x0, pts_type_object4
	add	x0, x0, :lo12:pts_type_object4
	fmov	d8, d0
	bl	pts_object_new
	fcmp	d8, d9
	mov	x22, x0
	mov	w8, #10                         // =0xa
	strb	wzr, [x0, #8]
	str	x8, [x0, #16]
	b.pl	.LBB198_30
// %bb.2:
	fmov	d10, #1.00000000
	adrp	x24, .L.str.193
	add	x24, x24, :lo12:.L.str.193
	adrp	x25, pts_check_4
	add	x25, x25, :lo12:pts_check_4
	adrp	x28, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	mov	w23, #1                         // =0x1
	adrp	x26, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	add	x26, x26, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	b	.LBB198_5
.LBB198_3:                              //   in Loop: Header=BB198_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.eq	.LBB198_12
.LBB198_4:                              //   in Loop: Header=BB198_5 Depth=1
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.pl	.LBB198_30
.LBB198_5:                              // =>This Inner Loop Header: Depth=1
	ldr	x8, [x28, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1]
	ldr	x9, [x20]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB198_7
// %bb.6:                               //   in Loop: Header=BB198_5 Depth=1
	add	x0, x20, x8, lsr #48
	ldrb	w8, [x0]
	cbz	w8, .LBB198_8
	b	.LBB198_30
.LBB198_7:                              //   in Loop: Header=BB198_5 Depth=1
	mov	x0, x20
	mov	x1, x26
	mov	x2, x24
	mov	x3, x25
	bl	pts_field_address_slow
	ldrb	w8, [x0]
	cbnz	w8, .LBB198_30
.LBB198_8:                              //   in Loop: Header=BB198_5 Depth=1
	cbz	w27, .LBB198_12
// %bb.9:                               //   in Loop: Header=BB198_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d8, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d8, d0
	fcvtzu	d0, d8
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB198_3
// %bb.10:                              //   in Loop: Header=BB198_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.ne	.LBB198_4
// %bb.11:                              //   in Loop: Header=BB198_5 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB198_26
.LBB198_12:                             //   in Loop: Header=BB198_5 Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x21, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d8, #0.0
	b.lt	.LBB198_32
// %bb.13:                              //   in Loop: Header=BB198_5 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x10
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB198_32
// %bb.14:                              //   in Loop: Header=BB198_5 Depth=1
	fcvtzu	x10, d8
	fmov	d1, d8
	mov	x0, x21
	mov	x1, x19
	add	x9, x9, x10, lsl #3
	ldr	d0, [x9, #8]
	blr	x8
	bl	pts_value_truthy
	tbz	w0, #0, .LBB198_4
// %bb.15:                              //   in Loop: Header=BB198_5 Depth=1
	sturb	w23, [x29, #-20]
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2]
	ldr	x9, [x22]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB198_17
// %bb.16:                              //   in Loop: Header=BB198_5 Depth=1
	lsr	x8, x8, #48
	strb	w23, [x22, x8]
	b	.LBB198_18
.LBB198_17:                             //   in Loop: Header=BB198_5 Depth=1
	sub	x4, x29, #20
	mov	x0, x22
	adrp	x1, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	mov	x2, x24
	mov	x3, x25
	bl	pts_field_set_slow
.LBB198_18:                             //   in Loop: Header=BB198_5 Depth=1
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_element
	lsr	x8, x0, #49
	cbnz	x8, .LBB198_20
// %bb.19:                              //   in Loop: Header=BB198_5 Depth=1
	cmp	x0, #10
	b.ne	.LBB198_33
.LBB198_20:                             //   in Loop: Header=BB198_5 Depth=1
	str	x0, [sp, #8]
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3]
	ldr	x9, [x22]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB198_22
// %bb.21:                              //   in Loop: Header=BB198_5 Depth=1
	lsr	x8, x8, #48
	str	x0, [x22, x8]
	b	.LBB198_23
.LBB198_22:                             //   in Loop: Header=BB198_5 Depth=1
	add	x4, sp, #8
	mov	x0, x22
	adrp	x1, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	adrp	x2, .L.str.195
	add	x2, x2, :lo12:.L.str.195
	adrp	x3, pts_check_5
	add	x3, x3, :lo12:pts_check_5
	bl	pts_field_set_slow
.LBB198_23:                             //   in Loop: Header=BB198_5 Depth=1
	strb	w23, [sp, #24]
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4]
	ldr	x9, [x20]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB198_25
// %bb.24:                              //   in Loop: Header=BB198_5 Depth=1
	lsr	x8, x8, #48
	strb	w23, [x20, x8]
	b	.LBB198_4
.LBB198_25:                             //   in Loop: Header=BB198_5 Depth=1
	add	x4, sp, #24
	mov	x0, x20
	adrp	x1, pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	mov	x2, x24
	mov	x3, x25
	bl	pts_field_set_slow
	b	.LBB198_4
.LBB198_26:                             //   in Loop: Header=BB198_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB198_29
.LBB198_27:                             //   in Loop: Header=BB198_5 Depth=1
	adrp	x9, :got:pts_type_match_array
	ldr	x9, [x9, :got_lo12:pts_type_match_array]
	cmp	x8, x9
	b.eq	.LBB198_12
// %bb.28:                              //   in Loop: Header=BB198_5 Depth=1
	adrp	x9, :got:pts_type_match_copy
	ldr	x9, [x9, :got_lo12:pts_type_match_copy]
	cmp	x8, x9
	b.ne	.LBB198_4
	b	.LBB198_12
.LBB198_29:                             //   in Loop: Header=BB198_5 Depth=1
	ldr	x8, [x8, #24]
	b	.LBB198_27
.LBB198_30:
	mov	x0, x22
	.cfi_def_cfa wsp, 144
	ldp	x20, x19, [sp, #128]            // 16-byte Folded Reload
	ldr	d10, [sp, #16]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #112]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #96]             // 16-byte Folded Reload
	ldp	x26, x25, [sp, #80]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #48]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #32]               // 16-byte Folded Reload
	add	sp, sp, #144
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB198_31:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB198_32:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.LBB198_33:
	adrp	x1, .L.str.196
	add	x1, x1, :lo12:.L.str.196
	bl	pts_throw_type_mismatch
.Lfunc_end198:
	.size	pts_fn_parallel_ParallelArray_findFound_arrow, .Lfunc_end198-pts_fn_parallel_ParallelArray_findFound_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_findFound_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_findFound_arrow: // @pts_dynamic_fn_parallel_ParallelArray_findFound_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB199_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB199_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB199_7
.LBB199_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB199_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB199_9
.LBB199_5:
	mov	w0, #10                         // =0xa
.LBB199_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB199_3
.LBB199_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB199_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB199_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB199_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB199_8
.Lfunc_end199:
	.size	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow, .Lfunc_end199-pts_dynamic_fn_parallel_ParallelArray_findFound_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_findFound_adapter
	.type	pts_fn_parallel_ParallelArray_findFound_adapter,@function
pts_fn_parallel_ParallelArray_findFound_adapter: // @pts_fn_parallel_ParallelArray_findFound_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB200_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x1, [x0, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	br	x1
.LBB200_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end200:
	.size	pts_fn_parallel_ParallelArray_findFound_adapter, .Lfunc_end200-pts_fn_parallel_ParallelArray_findFound_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_findFound_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_findFound_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_findFound_adapter: // @pts_dynamic_fn_parallel_ParallelArray_findFound_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB201_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB201_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB201_7
.LBB201_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB201_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB201_9
.LBB201_5:
	mov	w0, #10                         // =0xa
.LBB201_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB201_3
.LBB201_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB201_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB201_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB201_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB201_8
.Lfunc_end201:
	.size	pts_dynamic_fn_parallel_ParallelArray_findFound_adapter, .Lfunc_end201-pts_dynamic_fn_parallel_ParallelArray_findFound_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_findFound_arrow_2
	.type	pts_fn_parallel_ParallelArray_findFound_arrow_2,@function
pts_fn_parallel_ParallelArray_findFound_arrow_2: // @pts_fn_parallel_ParallelArray_findFound_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB202_5
// %bb.1:
	mov	x20, x1
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	mov	x0, x20
	mov	x19, x2
	bl	pts_value_convert
	adrp	x8, pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB202_3
// %bb.2:
	add	x0, x0, x8, lsr #48
	b	.LBB202_4
.LBB202_3:
	adrp	x1, pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	adrp	x2, .L.str.193
	add	x2, x2, :lo12:.L.str.193
	adrp	x3, pts_check_4
	add	x3, x3, :lo12:pts_check_4
	bl	pts_field_address_slow
.LBB202_4:
	ldrb	w8, [x0]
	cmp	w8, #0
	csel	x0, x19, x20, eq
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB202_5:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end202:
	.size	pts_fn_parallel_ParallelArray_findFound_arrow_2, .Lfunc_end202-pts_fn_parallel_ParallelArray_findFound_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB203_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB203_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB203_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB203_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end203:
	.size	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2, .Lfunc_end203-pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_51
	.type	pts_adapt_51,@function
pts_adapt_51:                           // @pts_adapt_51
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_51
	add	x0, x0, :lo12:pts_type_adapter_51
	bl	pts_object_new
	adrp	x8, pts_adapter_51
	add	x8, x8, :lo12:pts_adapter_51
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end204:
	.size	pts_adapt_51, .Lfunc_end204-pts_adapt_51
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_51
	.type	pts_adapter_51,@function
pts_adapter_51:                         // @pts_adapter_51
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	sub	x8, x0, #8
	cmn	x8, #3
	b.ls	.LBB205_2
// %bb.1:
	cmp	x0, #7
	cset	w0, eq
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB205_2:
	.cfi_restore_state
	adrp	x1, .L.str.142
	add	x1, x1, :lo12:.L.str.142
	bl	pts_throw_not_primitive
.Lfunc_end205:
	.size	pts_adapter_51, .Lfunc_end205-pts_adapter_51
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_every_arrow
	.type	pts_fn_parallel_ParallelArray_every_arrow,@function
pts_fn_parallel_ParallelArray_every_arrow: // @pts_fn_parallel_ParallelArray_every_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB206_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	bl	pts_value_truthy
	mov	w8, #1                          // =0x1
	bic	w0, w8, w0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB206_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end206:
	.size	pts_fn_parallel_ParallelArray_every_arrow, .Lfunc_end206-pts_fn_parallel_ParallelArray_every_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_every_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_every_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_every_arrow: // @pts_dynamic_fn_parallel_ParallelArray_every_arrow
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-64]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	str	x21, [sp, #32]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB207_6
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB207_7
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d8, x8
	cmp	w21, #2
	b.lo	.LBB207_8
.LBB207_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB207_9
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d9, x8
	cmp	w21, #3
	b.hs	.LBB207_10
.LBB207_5:
	mov	w0, #10                         // =0xa
	b	.LBB207_11
.LBB207_6:
	mov	w0, #10                         // =0xa
.LBB207_7:
	bl	pts_value_to_number_slow
	fmov	d8, d0
	cmp	w21, #2
	b.hs	.LBB207_3
.LBB207_8:
	mov	w0, #10                         // =0xa
.LBB207_9:
	bl	pts_value_to_number_slow
	fmov	d9, d0
	cmp	w21, #3
	b.lo	.LBB207_5
.LBB207_10:
	ldr	x0, [x20, #16]
.LBB207_11:
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	fmov	d0, d8
	fmov	d1, d9
	ldr	x8, [x19, #8]
	mov	x1, x0
	mov	x0, x19
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.Lfunc_end207:
	.size	pts_dynamic_fn_parallel_ParallelArray_every_arrow, .Lfunc_end207-pts_dynamic_fn_parallel_ParallelArray_every_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_25
	.type	pts_adapt_25,@function
pts_adapt_25:                           // @pts_adapt_25
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_25
	add	x0, x0, :lo12:pts_type_adapter_25
	bl	pts_object_new
	adrp	x8, pts_adapter_25
	add	x8, x8, :lo12:pts_adapter_25
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end208:
	.size	pts_adapt_25, .Lfunc_end208-pts_adapt_25
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_25
	.type	pts_adapter_25,@function
pts_adapter_25:                         // @pts_adapter_25
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	str	x1, [sp, #24]
	add	x2, sp, #8
	mov	w1, #3                          // =0x3
	add	x9, x9, x8
	csel	x9, x10, x9, vs
	fcmp	d1, d1
	add	x8, x11, x8
	csel	x8, x10, x8, vs
	stp	x9, x8, [sp, #8]
	bl	pts_dynamic_call_closure
	sub	x8, x0, #8
	cmn	x8, #3
	b.ls	.LBB209_2
// %bb.1:
	cmp	x0, #7
	cset	w0, eq
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB209_2:
	.cfi_restore_state
	adrp	x1, .L.str.142
	add	x1, x1, :lo12:.L.str.142
	bl	pts_throw_not_primitive
.Lfunc_end209:
	.size	pts_adapter_25, .Lfunc_end209-pts_adapter_25
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_every_adapter
	.type	pts_fn_parallel_ParallelArray_every_adapter,@function
pts_fn_parallel_ParallelArray_every_adapter: // @pts_fn_parallel_ParallelArray_every_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB210_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB210_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end210:
	.size	pts_fn_parallel_ParallelArray_every_adapter, .Lfunc_end210-pts_fn_parallel_ParallelArray_every_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_every_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_every_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_every_adapter: // @pts_dynamic_fn_parallel_ParallelArray_every_adapter
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-64]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	str	x21, [sp, #32]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB211_6
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB211_7
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d8, x8
	cmp	w21, #2
	b.lo	.LBB211_8
.LBB211_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB211_9
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d9, x8
	cmp	w21, #3
	b.hs	.LBB211_10
.LBB211_5:
	mov	w0, #10                         // =0xa
	b	.LBB211_11
.LBB211_6:
	mov	w0, #10                         // =0xa
.LBB211_7:
	bl	pts_value_to_number_slow
	fmov	d8, d0
	cmp	w21, #2
	b.hs	.LBB211_3
.LBB211_8:
	mov	w0, #10                         // =0xa
.LBB211_9:
	bl	pts_value_to_number_slow
	fmov	d9, d0
	cmp	w21, #3
	b.lo	.LBB211_5
.LBB211_10:
	ldr	x0, [x20, #16]
.LBB211_11:
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	ldr	x2, [x19, #8]
	mov	x1, x0
	mov	x0, x19
	fmov	d0, d8
	fmov	d1, d9
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	br	x2
.Lfunc_end211:
	.size	pts_dynamic_fn_parallel_ParallelArray_every_adapter, .Lfunc_end211-pts_dynamic_fn_parallel_ParallelArray_every_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_52
	.type	pts_adapt_52,@function
pts_adapt_52:                           // @pts_adapt_52
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_52
	add	x0, x0, :lo12:pts_type_adapter_52
	bl	pts_object_new
	adrp	x8, pts_adapter_52
	add	x8, x8, :lo12:pts_adapter_52
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end212:
	.size	pts_adapt_52, .Lfunc_end212-pts_adapt_52
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_52
	.type	pts_adapter_52,@function
pts_adapter_52:                         // @pts_adapter_52
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cmp	x8, #0
	ccmp	x0, #10, #4, eq
	b.ne	.LBB213_2
// %bb.1:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB213_2:
	.cfi_restore_state
	adrp	x1, .L.str.196
	add	x1, x1, :lo12:.L.str.196
	bl	pts_throw_type_mismatch
.Lfunc_end213:
	.size	pts_adapter_52, .Lfunc_end213-pts_adapter_52
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_count_arrow
	.type	pts_fn_parallel_ParallelArray_count_arrow,@function
pts_fn_parallel_ParallelArray_count_arrow: // @pts_fn_parallel_ParallelArray_count_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-96]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	str	x23, [sp, #48]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -88
	.cfi_offset b11, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB214_17
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d9, d1
	fmov	d8, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	movi	d10, #0000000000000000
	fcmp	d8, d9
	b.pl	.LBB214_16
// %bb.2:
	adrp	x22, :got:pts_type_match_array
	fmov	d11, #1.00000000
	adrp	x23, :got:pts_type_match_copy
	ldr	x22, [x22, :got_lo12:pts_type_match_array]
	ldr	x23, [x23, :got_lo12:pts_type_match_copy]
	mov	w21, w0
	b	.LBB214_5
.LBB214_3:                              //   in Loop: Header=BB214_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.eq	.LBB214_8
.LBB214_4:                              //   in Loop: Header=BB214_5 Depth=1
	fadd	d8, d8, d11
	fcmp	d8, d9
	b.pl	.LBB214_16
.LBB214_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w21, #0, .LBB214_9
// %bb.6:                               //   in Loop: Header=BB214_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d8, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d8, d0
	fcvtzu	d0, d8
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.ls	.LBB214_3
// %bb.7:                               //   in Loop: Header=BB214_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.ne	.LBB214_4
	b	.LBB214_9
.LBB214_8:                              //   in Loop: Header=BB214_5 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB214_12
.LBB214_9:                              //   in Loop: Header=BB214_5 Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x20, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d8, #0.0
	b.lt	.LBB214_18
// %bb.10:                              //   in Loop: Header=BB214_5 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x10
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB214_18
// %bb.11:                              //   in Loop: Header=BB214_5 Depth=1
	fcvtzu	x10, d8
	fmov	d1, d8
	mov	x0, x20
	mov	x1, x19
	add	x9, x9, x10, lsl #3
	ldr	d0, [x9, #8]
	blr	x8
	bl	pts_value_truthy
	fadd	d0, d10, d11
	tst	w0, #0x1
	fcsel	d10, d0, d10, ne
	b	.LBB214_4
.LBB214_12:                             //   in Loop: Header=BB214_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB214_15
// %bb.13:                              //   in Loop: Header=BB214_5 Depth=1
	cmp	x8, x22
	b.eq	.LBB214_9
.LBB214_14:                             //   in Loop: Header=BB214_5 Depth=1
	cmp	x8, x23
	b.ne	.LBB214_4
	b	.LBB214_9
.LBB214_15:                             //   in Loop: Header=BB214_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x22
	b.ne	.LBB214_14
	b	.LBB214_9
.LBB214_16:
	fmov	d0, d10
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldr	x23, [sp, #48]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #96             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB214_17:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB214_18:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end214:
	.size	pts_fn_parallel_ParallelArray_count_arrow, .Lfunc_end214-pts_fn_parallel_ParallelArray_count_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_count_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_count_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_count_arrow: // @pts_dynamic_fn_parallel_ParallelArray_count_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB215_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB215_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB215_7
.LBB215_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB215_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB215_9
.LBB215_5:
	mov	w0, #10                         // =0xa
.LBB215_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB215_3
.LBB215_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB215_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB215_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB215_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB215_8
.Lfunc_end215:
	.size	pts_dynamic_fn_parallel_ParallelArray_count_arrow, .Lfunc_end215-pts_dynamic_fn_parallel_ParallelArray_count_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_count_adapter
	.type	pts_fn_parallel_ParallelArray_count_adapter,@function
pts_fn_parallel_ParallelArray_count_adapter: // @pts_fn_parallel_ParallelArray_count_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB216_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB216_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end216:
	.size	pts_fn_parallel_ParallelArray_count_adapter, .Lfunc_end216-pts_fn_parallel_ParallelArray_count_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_count_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_count_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_count_adapter: // @pts_dynamic_fn_parallel_ParallelArray_count_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB217_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB217_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB217_7
.LBB217_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB217_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB217_9
.LBB217_5:
	mov	w0, #10                         // =0xa
.LBB217_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB217_3
.LBB217_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB217_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB217_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB217_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB217_8
.Lfunc_end217:
	.size	pts_dynamic_fn_parallel_ParallelArray_count_adapter, .Lfunc_end217-pts_dynamic_fn_parallel_ParallelArray_count_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_count_arrow_2
	.type	pts_fn_parallel_ParallelArray_count_arrow_2,@function
pts_fn_parallel_ParallelArray_count_arrow_2: // @pts_fn_parallel_ParallelArray_count_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x19, [sp, #24]                  // 8-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_remember_state
	lsr	x8, x1, #49
	cbz	x8, .LBB218_4
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d8, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB218_5
.LBB218_2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d0, x8
.LBB218_3:
	fadd	d0, d8, d0
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	x19, [sp, #24]                  // 8-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB218_4:
	.cfi_restore_state
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_to_number_slow
	fmov	d8, d0
	mov	x2, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB218_2
.LBB218_5:
	mov	x0, x2
	bl	pts_value_to_number_slow
	b	.LBB218_3
.Lfunc_end218:
	.size	pts_fn_parallel_ParallelArray_count_arrow_2, .Lfunc_end218-pts_fn_parallel_ParallelArray_count_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_count_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_count_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_count_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_count_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB219_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB219_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB219_5
.LBB219_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB219_5
.LBB219_4:
	ldr	x2, [x2, #8]
.LBB219_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end219:
	.size	pts_dynamic_fn_parallel_ParallelArray_count_arrow_2, .Lfunc_end219-pts_dynamic_fn_parallel_ParallelArray_count_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_count_adapter_2
	.type	pts_fn_parallel_ParallelArray_count_adapter_2,@function
pts_fn_parallel_ParallelArray_count_adapter_2: // @pts_fn_parallel_ParallelArray_count_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB220_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB220_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end220:
	.size	pts_fn_parallel_ParallelArray_count_adapter_2, .Lfunc_end220-pts_fn_parallel_ParallelArray_count_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_count_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_count_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_count_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_count_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB221_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB221_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB221_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB221_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end221:
	.size	pts_dynamic_fn_parallel_ParallelArray_count_adapter_2, .Lfunc_end221-pts_dynamic_fn_parallel_ParallelArray_count_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_53
	.type	pts_adapt_53,@function
pts_adapt_53:                           // @pts_adapt_53
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_53
	add	x0, x0, :lo12:pts_type_adapter_53
	bl	pts_object_new
	adrp	x8, pts_adapter_53
	add	x8, x8, :lo12:pts_adapter_53
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end222:
	.size	pts_adapt_53, .Lfunc_end222-pts_adapt_53
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_53
	.type	pts_adapter_53,@function
pts_adapter_53:                         // @pts_adapter_53
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB223_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB223_2:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB223_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB223_2
.Lfunc_end223:
	.size	pts_adapter_53, .Lfunc_end223-pts_adapter_53
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sum_arrow
	.type	pts_fn_parallel_ParallelArray_sum_arrow,@function
pts_fn_parallel_ParallelArray_sum_arrow: // @pts_fn_parallel_ParallelArray_sum_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-80]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 80
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #48]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #64]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	.cfi_offset b10, -72
	.cfi_offset b11, -80
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB224_15
// %bb.1:
	ldr	x19, [x0, #16]
	fmov	d8, d1
	fmov	d9, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	movi	d10, #0000000000000000
	fcmp	d9, d8
	b.pl	.LBB224_14
// %bb.2:
	adrp	x21, :got:pts_type_match_array
	fmov	d11, #1.00000000
	adrp	x22, :got:pts_type_match_copy
	ldr	x21, [x21, :got_lo12:pts_type_match_array]
	ldr	x22, [x22, :got_lo12:pts_type_match_copy]
	mov	w20, w0
	b	.LBB224_5
.LBB224_3:                              //   in Loop: Header=BB224_5 Depth=1
	fmov	d0, d9
	mov	x0, x19
	bl	pts_array_element
	bl	pts_value_to_number
	fadd	d10, d10, d0
.LBB224_4:                              //   in Loop: Header=BB224_5 Depth=1
	fadd	d9, d9, d11
	fcmp	d9, d8
	b.pl	.LBB224_14
.LBB224_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w20, #0, .LBB224_3
// %bb.6:                               //   in Loop: Header=BB224_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d9, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d9, d0
	fcvtzu	d0, d9
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB224_12
// %bb.7:                               //   in Loop: Header=BB224_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB224_4
// %bb.8:                               //   in Loop: Header=BB224_5 Depth=1
	fcvtzu	x9, d9
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbnz	x8, .LBB224_3
// %bb.9:                               //   in Loop: Header=BB224_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB224_13
// %bb.10:                              //   in Loop: Header=BB224_5 Depth=1
	cmp	x8, x21
	b.eq	.LBB224_3
.LBB224_11:                             //   in Loop: Header=BB224_5 Depth=1
	cmp	x8, x22
	b.ne	.LBB224_4
	b	.LBB224_3
.LBB224_12:                             //   in Loop: Header=BB224_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB224_4
	b	.LBB224_3
.LBB224_13:                             //   in Loop: Header=BB224_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x21
	b.ne	.LBB224_11
	b	.LBB224_3
.LBB224_14:
	fmov	d0, d10
	.cfi_def_cfa wsp, 80
	ldp	x20, x19, [sp, #64]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #80             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB224_15:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end224:
	.size	pts_fn_parallel_ParallelArray_sum_arrow, .Lfunc_end224-pts_fn_parallel_ParallelArray_sum_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sum_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_sum_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_sum_arrow: // @pts_dynamic_fn_parallel_ParallelArray_sum_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB225_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB225_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB225_7
.LBB225_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB225_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB225_9
.LBB225_5:
	mov	w0, #10                         // =0xa
.LBB225_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB225_3
.LBB225_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB225_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB225_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB225_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB225_8
.Lfunc_end225:
	.size	pts_dynamic_fn_parallel_ParallelArray_sum_arrow, .Lfunc_end225-pts_dynamic_fn_parallel_ParallelArray_sum_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sum_adapter
	.type	pts_fn_parallel_ParallelArray_sum_adapter,@function
pts_fn_parallel_ParallelArray_sum_adapter: // @pts_fn_parallel_ParallelArray_sum_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB226_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB226_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end226:
	.size	pts_fn_parallel_ParallelArray_sum_adapter, .Lfunc_end226-pts_fn_parallel_ParallelArray_sum_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sum_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_sum_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_sum_adapter: // @pts_dynamic_fn_parallel_ParallelArray_sum_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB227_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB227_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB227_7
.LBB227_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB227_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB227_9
.LBB227_5:
	mov	w0, #10                         // =0xa
.LBB227_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB227_3
.LBB227_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB227_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB227_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB227_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB227_8
.Lfunc_end227:
	.size	pts_dynamic_fn_parallel_ParallelArray_sum_adapter, .Lfunc_end227-pts_dynamic_fn_parallel_ParallelArray_sum_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sum_arrow_2
	.type	pts_fn_parallel_ParallelArray_sum_arrow_2,@function
pts_fn_parallel_ParallelArray_sum_arrow_2: // @pts_fn_parallel_ParallelArray_sum_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x19, [sp, #24]                  // 8-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_remember_state
	lsr	x8, x1, #49
	cbz	x8, .LBB228_4
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d8, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB228_5
.LBB228_2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d0, x8
.LBB228_3:
	fadd	d0, d8, d0
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	x19, [sp, #24]                  // 8-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB228_4:
	.cfi_restore_state
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_to_number_slow
	fmov	d8, d0
	mov	x2, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB228_2
.LBB228_5:
	mov	x0, x2
	bl	pts_value_to_number_slow
	b	.LBB228_3
.Lfunc_end228:
	.size	pts_fn_parallel_ParallelArray_sum_arrow_2, .Lfunc_end228-pts_fn_parallel_ParallelArray_sum_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB229_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB229_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB229_5
.LBB229_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB229_5
.LBB229_4:
	ldr	x2, [x2, #8]
.LBB229_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end229:
	.size	pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2, .Lfunc_end229-pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sum_adapter_2
	.type	pts_fn_parallel_ParallelArray_sum_adapter_2,@function
pts_fn_parallel_ParallelArray_sum_adapter_2: // @pts_fn_parallel_ParallelArray_sum_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB230_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB230_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end230:
	.size	pts_fn_parallel_ParallelArray_sum_adapter_2, .Lfunc_end230-pts_fn_parallel_ParallelArray_sum_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB231_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB231_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB231_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB231_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end231:
	.size	pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2, .Lfunc_end231-pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_min_arrow
	.type	pts_fn_parallel_ParallelArray_min_arrow,@function
pts_fn_parallel_ParallelArray_min_arrow: // @pts_fn_parallel_ParallelArray_min_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-96]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	str	x23, [sp, #48]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -88
	.cfi_offset b11, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB232_16
// %bb.1:
	ldr	x19, [x0, #16]
	fmov	d8, d1
	fmov	d9, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	fcmp	d9, d8
	b.pl	.LBB232_14
// %bb.2:
	mov	x8, #9218868437227405312        // =0x7ff0000000000000
	adrp	x21, :got:pts_type_match_array
	fmov	d11, #1.00000000
	adrp	x22, :got:pts_type_match_copy
	fmov	d10, x8
	ldr	x21, [x21, :got_lo12:pts_type_match_array]
	ldr	x22, [x22, :got_lo12:pts_type_match_copy]
	mov	w20, w0
	mov	x23, #9221120237041090560       // =0x7ff8000000000000
	b	.LBB232_5
.LBB232_3:                              //   in Loop: Header=BB232_5 Depth=1
	fmov	d0, d9
	mov	x0, x19
	bl	pts_array_element
	bl	pts_value_to_number
	fcmp	d10, d0
	fmov	x8, d10
	fcsel	d1, d10, d0, mi
	cmp	x8, #0
	fcsel	d2, d10, d0, lt
	fcmp	d10, d0
	fcsel	d0, d1, d2, ne
	fmov	d1, x23
	fcsel	d10, d1, d0, vs
.LBB232_4:                              //   in Loop: Header=BB232_5 Depth=1
	fadd	d9, d9, d11
	fcmp	d9, d8
	b.pl	.LBB232_15
.LBB232_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w20, #0, .LBB232_3
// %bb.6:                               //   in Loop: Header=BB232_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d9, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d9, d0
	fcvtzu	d0, d9
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB232_12
// %bb.7:                               //   in Loop: Header=BB232_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB232_4
// %bb.8:                               //   in Loop: Header=BB232_5 Depth=1
	fcvtzu	x9, d9
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbnz	x8, .LBB232_3
// %bb.9:                               //   in Loop: Header=BB232_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB232_13
// %bb.10:                              //   in Loop: Header=BB232_5 Depth=1
	cmp	x8, x21
	b.eq	.LBB232_3
.LBB232_11:                             //   in Loop: Header=BB232_5 Depth=1
	cmp	x8, x22
	b.ne	.LBB232_4
	b	.LBB232_3
.LBB232_12:                             //   in Loop: Header=BB232_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB232_4
	b	.LBB232_3
.LBB232_13:                             //   in Loop: Header=BB232_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x21
	b.ne	.LBB232_11
	b	.LBB232_3
.LBB232_14:
	mov	x8, #9218868437227405312        // =0x7ff0000000000000
	fmov	d10, x8
.LBB232_15:
	fmov	d0, d10
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldr	x23, [sp, #48]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #96             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB232_16:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end232:
	.size	pts_fn_parallel_ParallelArray_min_arrow, .Lfunc_end232-pts_fn_parallel_ParallelArray_min_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_min_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_min_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_min_arrow: // @pts_dynamic_fn_parallel_ParallelArray_min_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB233_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB233_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB233_7
.LBB233_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB233_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB233_9
.LBB233_5:
	mov	w0, #10                         // =0xa
.LBB233_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB233_3
.LBB233_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB233_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB233_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB233_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB233_8
.Lfunc_end233:
	.size	pts_dynamic_fn_parallel_ParallelArray_min_arrow, .Lfunc_end233-pts_dynamic_fn_parallel_ParallelArray_min_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_min_adapter
	.type	pts_fn_parallel_ParallelArray_min_adapter,@function
pts_fn_parallel_ParallelArray_min_adapter: // @pts_fn_parallel_ParallelArray_min_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB234_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB234_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end234:
	.size	pts_fn_parallel_ParallelArray_min_adapter, .Lfunc_end234-pts_fn_parallel_ParallelArray_min_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_min_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_min_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_min_adapter: // @pts_dynamic_fn_parallel_ParallelArray_min_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB235_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB235_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB235_7
.LBB235_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB235_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB235_9
.LBB235_5:
	mov	w0, #10                         // =0xa
.LBB235_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB235_3
.LBB235_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB235_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB235_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB235_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB235_8
.Lfunc_end235:
	.size	pts_dynamic_fn_parallel_ParallelArray_min_adapter, .Lfunc_end235-pts_dynamic_fn_parallel_ParallelArray_min_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_min_arrow_2
	.type	pts_fn_parallel_ParallelArray_min_arrow_2,@function
pts_fn_parallel_ParallelArray_min_arrow_2: // @pts_fn_parallel_ParallelArray_min_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x19, [sp, #24]                  // 8-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_remember_state
	lsr	x8, x1, #49
	cbz	x8, .LBB236_7
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d8, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB236_8
.LBB236_2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d0, x8
	fcmp	d8, d0
	b.vs	.LBB236_9
.LBB236_3:
	b.ne	.LBB236_5
// %bb.4:
	fmov	x8, d8
	cmp	x8, #0
	fcsel	d0, d8, d0, lt
	b	.LBB236_6
.LBB236_5:
	fcmp	d8, d0
	fcsel	d0, d8, d0, mi
.LBB236_6:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	x19, [sp, #24]                  // 8-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB236_7:
	.cfi_restore_state
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_to_number_slow
	fmov	d8, d0
	mov	x2, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB236_2
.LBB236_8:
	mov	x0, x2
	bl	pts_value_to_number_slow
	fcmp	d8, d0
	b.vc	.LBB236_3
.LBB236_9:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB236_6
.Lfunc_end236:
	.size	pts_fn_parallel_ParallelArray_min_arrow_2, .Lfunc_end236-pts_fn_parallel_ParallelArray_min_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_min_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_min_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_min_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_min_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB237_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB237_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB237_5
.LBB237_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB237_5
.LBB237_4:
	ldr	x2, [x2, #8]
.LBB237_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end237:
	.size	pts_dynamic_fn_parallel_ParallelArray_min_arrow_2, .Lfunc_end237-pts_dynamic_fn_parallel_ParallelArray_min_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_min_adapter_2
	.type	pts_fn_parallel_ParallelArray_min_adapter_2,@function
pts_fn_parallel_ParallelArray_min_adapter_2: // @pts_fn_parallel_ParallelArray_min_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB238_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB238_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end238:
	.size	pts_fn_parallel_ParallelArray_min_adapter_2, .Lfunc_end238-pts_fn_parallel_ParallelArray_min_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_min_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_min_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_min_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_min_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB239_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB239_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB239_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB239_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end239:
	.size	pts_dynamic_fn_parallel_ParallelArray_min_adapter_2, .Lfunc_end239-pts_dynamic_fn_parallel_ParallelArray_min_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_max_arrow
	.type	pts_fn_parallel_ParallelArray_max_arrow,@function
pts_fn_parallel_ParallelArray_max_arrow: // @pts_fn_parallel_ParallelArray_max_arrow
	.cfi_startproc
// %bb.0:
	stp	d11, d10, [sp, #-96]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	str	x23, [sp, #48]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -88
	.cfi_offset b11, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB240_16
// %bb.1:
	ldr	x19, [x0, #16]
	fmov	d8, d1
	fmov	d9, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	fcmp	d9, d8
	b.pl	.LBB240_14
// %bb.2:
	mov	x8, #-4503599627370496          // =0xfff0000000000000
	adrp	x21, :got:pts_type_match_array
	fmov	d11, #1.00000000
	adrp	x22, :got:pts_type_match_copy
	fmov	d10, x8
	ldr	x21, [x21, :got_lo12:pts_type_match_array]
	ldr	x22, [x22, :got_lo12:pts_type_match_copy]
	mov	w20, w0
	mov	x23, #9221120237041090560       // =0x7ff8000000000000
	b	.LBB240_5
.LBB240_3:                              //   in Loop: Header=BB240_5 Depth=1
	fmov	d0, d9
	mov	x0, x19
	bl	pts_array_element
	bl	pts_value_to_number
	fcmp	d10, d0
	fmov	x8, d10
	fcsel	d1, d10, d0, gt
	cmp	x8, #0
	fcsel	d2, d0, d10, lt
	fcmp	d10, d0
	fcsel	d0, d1, d2, ne
	fmov	d1, x23
	fcsel	d10, d1, d0, vs
.LBB240_4:                              //   in Loop: Header=BB240_5 Depth=1
	fadd	d9, d9, d11
	fcmp	d9, d8
	b.pl	.LBB240_15
.LBB240_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w20, #0, .LBB240_3
// %bb.6:                               //   in Loop: Header=BB240_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d9, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d9, d0
	fcvtzu	d0, d9
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB240_12
// %bb.7:                               //   in Loop: Header=BB240_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB240_4
// %bb.8:                               //   in Loop: Header=BB240_5 Depth=1
	fcvtzu	x9, d9
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbnz	x8, .LBB240_3
// %bb.9:                               //   in Loop: Header=BB240_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB240_13
// %bb.10:                              //   in Loop: Header=BB240_5 Depth=1
	cmp	x8, x21
	b.eq	.LBB240_3
.LBB240_11:                             //   in Loop: Header=BB240_5 Depth=1
	cmp	x8, x22
	b.ne	.LBB240_4
	b	.LBB240_3
.LBB240_12:                             //   in Loop: Header=BB240_5 Depth=1
	cmp	w9, #0
	fccmp	d9, d0, #0, ne
	b.ne	.LBB240_4
	b	.LBB240_3
.LBB240_13:                             //   in Loop: Header=BB240_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x21
	b.ne	.LBB240_11
	b	.LBB240_3
.LBB240_14:
	mov	x8, #-4503599627370496          // =0xfff0000000000000
	fmov	d10, x8
.LBB240_15:
	fmov	d0, d10
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldr	x23, [sp, #48]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldp	d11, d10, [sp], #96             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB240_16:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end240:
	.size	pts_fn_parallel_ParallelArray_max_arrow, .Lfunc_end240-pts_fn_parallel_ParallelArray_max_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_max_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_max_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_max_arrow: // @pts_dynamic_fn_parallel_ParallelArray_max_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB241_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB241_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB241_7
.LBB241_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB241_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB241_9
.LBB241_5:
	mov	w0, #10                         // =0xa
.LBB241_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB241_3
.LBB241_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB241_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB241_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB241_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB241_8
.Lfunc_end241:
	.size	pts_dynamic_fn_parallel_ParallelArray_max_arrow, .Lfunc_end241-pts_dynamic_fn_parallel_ParallelArray_max_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_max_adapter
	.type	pts_fn_parallel_ParallelArray_max_adapter,@function
pts_fn_parallel_ParallelArray_max_adapter: // @pts_fn_parallel_ParallelArray_max_adapter
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB242_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB242_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end242:
	.size	pts_fn_parallel_ParallelArray_max_adapter, .Lfunc_end242-pts_fn_parallel_ParallelArray_max_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_max_adapter
	.type	pts_dynamic_fn_parallel_ParallelArray_max_adapter,@function
pts_dynamic_fn_parallel_ParallelArray_max_adapter: // @pts_dynamic_fn_parallel_ParallelArray_max_adapter
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB243_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB243_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB243_7
.LBB243_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB243_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB243_9
.LBB243_5:
	mov	w0, #10                         // =0xa
.LBB243_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB243_3
.LBB243_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB243_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB243_9:
	ldr	x1, [x19, #8]
	mov	x0, x19
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	br	x1
.LBB243_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB243_8
.Lfunc_end243:
	.size	pts_dynamic_fn_parallel_ParallelArray_max_adapter, .Lfunc_end243-pts_dynamic_fn_parallel_ParallelArray_max_adapter
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_max_arrow_2
	.type	pts_fn_parallel_ParallelArray_max_arrow_2,@function
pts_fn_parallel_ParallelArray_max_arrow_2: // @pts_fn_parallel_ParallelArray_max_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-32]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x19, [sp, #24]                  // 8-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 24
	.cfi_offset w19, -8
	.cfi_offset w30, -16
	.cfi_offset w29, -24
	.cfi_offset b8, -32
	.cfi_remember_state
	lsr	x8, x1, #49
	cbz	x8, .LBB244_7
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x1, x8
	fmov	d8, x8
	lsr	x8, x2, #49
	cbz	x8, .LBB244_8
.LBB244_2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x2, x8
	fmov	d0, x8
	fcmp	d8, d0
	b.vs	.LBB244_9
.LBB244_3:
	b.ne	.LBB244_5
// %bb.4:
	fmov	x8, d8
	cmp	x8, #0
	fcsel	d0, d0, d8, lt
	b	.LBB244_6
.LBB244_5:
	fcmp	d8, d0
	fcsel	d0, d8, d0, gt
.LBB244_6:
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	x19, [sp, #24]                  // 8-byte Folded Reload
	ldr	d8, [sp], #32                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB244_7:
	.cfi_restore_state
	mov	x0, x1
	mov	x19, x2
	bl	pts_value_to_number_slow
	fmov	d8, d0
	mov	x2, x19
	lsr	x8, x2, #49
	cbnz	x8, .LBB244_2
.LBB244_8:
	mov	x0, x2
	bl	pts_value_to_number_slow
	fcmp	d8, d0
	b.vc	.LBB244_3
.LBB244_9:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d0, x8
	b	.LBB244_6
.Lfunc_end244:
	.size	pts_fn_parallel_ParallelArray_max_arrow_2, .Lfunc_end244-pts_fn_parallel_ParallelArray_max_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_max_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_max_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_max_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_max_arrow_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB245_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB245_4
// %bb.2:
	mov	w2, #10                         // =0xa
	b	.LBB245_5
.LBB245_3:
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	b	.LBB245_5
.LBB245_4:
	ldr	x2, [x2, #8]
.LBB245_5:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end245:
	.size	pts_dynamic_fn_parallel_ParallelArray_max_arrow_2, .Lfunc_end245-pts_dynamic_fn_parallel_ParallelArray_max_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_max_adapter_2
	.type	pts_fn_parallel_ParallelArray_max_adapter_2,@function
pts_fn_parallel_ParallelArray_max_adapter_2: // @pts_fn_parallel_ParallelArray_max_adapter_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB246_2
// %bb.1:
	ldr	x0, [x0, #16]
	ldr	x8, [x0, #8]
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB246_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end246:
	.size	pts_fn_parallel_ParallelArray_max_adapter_2, .Lfunc_end246-pts_fn_parallel_ParallelArray_max_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_max_adapter_2
	.type	pts_dynamic_fn_parallel_ParallelArray_max_adapter_2,@function
pts_dynamic_fn_parallel_ParallelArray_max_adapter_2: // @pts_dynamic_fn_parallel_ParallelArray_max_adapter_2
	.cfi_startproc
// %bb.0:
	cbz	w1, .LBB247_3
// %bb.1:
	mov	w8, w1
	ldr	x1, [x2]
	cmp	w8, #1
	b.ne	.LBB247_4
// %bb.2:
	ldr	x3, [x0, #8]
	mov	w2, #10                         // =0xa
	br	x3
.LBB247_3:
	ldr	x3, [x0, #8]
	mov	w1, #10                         // =0xa
	mov	w2, #10                         // =0xa
	br	x3
.LBB247_4:
	ldr	x2, [x2, #8]
	ldr	x3, [x0, #8]
	br	x3
.Lfunc_end247:
	.size	pts_dynamic_fn_parallel_ParallelArray_max_adapter_2, .Lfunc_end247-pts_dynamic_fn_parallel_ParallelArray_max_adapter_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_54
	.type	pts_adapt_54,@function
pts_adapt_54:                           // @pts_adapt_54
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_54
	add	x0, x0, :lo12:pts_type_adapter_54
	bl	pts_object_new
	adrp	x8, pts_adapter_54
	add	x8, x8, :lo12:pts_adapter_54
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end248:
	.size	pts_adapt_54, .Lfunc_end248-pts_adapt_54
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_54
	.type	pts_adapter_54,@function
pts_adapter_54:                         // @pts_adapter_54
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	tst	w2, #0x1
	mov	w8, #10                         // =0xa
	ldr	x0, [x0, #16]
	csel	x8, x1, x8, ne
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	str	x8, [sp, #8]
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end249:
	.size	pts_adapter_54, .Lfunc_end249-pts_adapter_54
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_55
	.type	pts_adapt_55,@function
pts_adapt_55:                           // @pts_adapt_55
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_55
	add	x0, x0, :lo12:pts_type_adapter_55
	bl	pts_object_new
	adrp	x8, pts_adapter_55
	add	x8, x8, :lo12:pts_adapter_55
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end250:
	.size	pts_adapt_55, .Lfunc_end250-pts_adapt_55
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_55
	.type	pts_adapter_55,@function
pts_adapter_55:                         // @pts_adapter_55
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end251:
	.size	pts_adapter_55, .Lfunc_end251-pts_adapter_55
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_compare_1
	.type	pts_compare_1,@function
pts_compare_1:                          // @pts_compare_1
	.cfi_startproc
// %bb.0:
	ldr	d0, [x1]
	ldr	d1, [x2]
	ldr	x1, [x0, #8]
	br	x1
.Lfunc_end252:
	.size	pts_compare_1, .Lfunc_end252-pts_compare_1
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortInPlace_number
	.type	pts_fn_parallel_sortInPlace_number,@function
pts_fn_parallel_sortInPlace_number:     // @pts_fn_parallel_sortInPlace_number
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-64]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	str	x21, [sp, #32]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB253_10
// %bb.1:
	fmov	d8, d0
	mov	x19, x1
	mov	x20, x0
	bl	pts_parallel_threads
	fmov	d1, #1.00000000
	fcmp	d0, d1
	b.ne	.LBB253_3
// %bb.2:
	adrp	x2, pts_compare_1
	add	x2, x2, :lo12:pts_compare_1
	mov	x0, x20
	mov	x1, x19
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	b	pts_array_sort_with
.LBB253_3:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT_ready]
	tbz	w8, #0, .LBB253_11
// %bb.4:
	adrp	x8, pts_global_parallel_PIECES_PER_THREAD_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_PIECES_PER_THREAD_ready]
	tbz	w8, #0, .LBB253_12
// %bb.5:
	adrp	x8, pts_global_parallel_PIECES_PER_THREAD
	ldr	d1, [x8, :lo12:pts_global_parallel_PIECES_PER_THREAD]
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT
	fmul	d0, d0, d1
	ldr	d1, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT]
	fdiv	d0, d8, d0
	frintp	d0, d0
	fcmp	d1, d0
	b.vs	.LBB253_13
// %bb.6:
	b.ne	.LBB253_8
// %bb.7:
	fmov	x8, d1
	cmp	x8, #0
	fcsel	d9, d0, d1, lt
	b	.LBB253_9
.LBB253_8:
	fcmp	d1, d0
	fcsel	d9, d1, d0, gt
.LBB253_9:
	movi	d0, #0000000000000000
	fmov	d1, d8
	mov	x0, x20
	bl	pts_array_slice
	mov	x21, x0
	adrp	x0, pts_type_closure_parallel_sortInPlace_number_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_sortInPlace_number_arrow
	bl	pts_object_new
	mov	x3, x0
	adrp	x8, pts_fn_parallel_sortInPlace_number_arrow
	add	x8, x8, :lo12:pts_fn_parallel_sortInPlace_number_arrow
	movi	d0, #0000000000000000
	stp	x8, x20, [x0, #8]
	mov	x0, x20
	mov	x1, x21
	fmov	d1, d8
	fmov	d2, d9
	mov	x2, x19
	str	x19, [x3, #24]
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	b	pts_fn_parallel_sortRun_number_number_array
.LBB253_10:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB253_11:
	adrp	x0, .L.str.218
	add	x0, x0, :lo12:.L.str.218
	bl	pts_throw_uninitialized
.LBB253_12:
	adrp	x0, .L.str.219
	add	x0, x0, :lo12:.L.str.219
	bl	pts_throw_uninitialized
.LBB253_13:
	mov	x8, #9221120237041090560        // =0x7ff8000000000000
	fmov	d9, x8
	b	.LBB253_9
.Lfunc_end253:
	.size	pts_fn_parallel_sortInPlace_number, .Lfunc_end253-pts_fn_parallel_sortInPlace_number
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortRun_number_number_array
	.type	pts_fn_parallel_sortRun_number_number_array,@function
pts_fn_parallel_sortRun_number_number_array: // @pts_fn_parallel_sortRun_number_number_array
	.cfi_startproc
// %bb.0:
	str	d12, [sp, #-96]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	d11, d10, [sp, #8]              // 16-byte Folded Spill
	stp	d9, d8, [sp, #24]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #40]             // 16-byte Folded Spill
	str	x23, [sp, #56]                  // 8-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #40
	.cfi_def_cfa w29, 56
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w30, -48
	.cfi_offset w29, -56
	.cfi_offset b8, -64
	.cfi_offset b9, -72
	.cfi_offset b10, -80
	.cfi_offset b11, -88
	.cfi_offset b12, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB254_4
// %bb.1:
	fsub	d8, d1, d0
	fmov	d9, d2
	mov	x21, x3
	fcmp	d8, d2
	b.ls	.LBB254_3
// %bb.2:
	fmov	d2, #0.50000000
	mov	x20, x0
	adrp	x0, pts_type_closure_parallel_sortRun_number_number_array_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_sortRun_number_number_array_arrow
	mov	x19, x1
	fmov	d11, d0
	mov	x22, x2
	fmov	d12, d1
	fmul	d2, d8, d2
	frintm	d2, d2
	fadd	d10, d2, d0
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_sortRun_number_number_array_arrow
	add	x8, x8, :lo12:pts_fn_parallel_sortRun_number_number_array_arrow
	mov	x23, x0
	stp	x8, x20, [x0, #8]
	str	x19, [x0, #24]
	stp	d11, d10, [x0, #32]
	str	d9, [x0, #48]
	stp	x22, x21, [x0, #56]
	adrp	x0, pts_type_closure_parallel_sortRun_number_number_array_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_sortRun_number_number_array_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_sortRun_number_number_array_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_sortRun_number_number_array_arrow_2
	mov	x1, x0
	stp	x8, x20, [x0, #8]
	str	x19, [x0, #24]
	stp	d10, d12, [x0, #32]
	str	d9, [x0, #48]
	stp	x22, x21, [x0, #56]
	mov	x0, x23
	bl	pts_fn_parallel_join_undefined_undefined
	fmov	d0, d11
	fmov	d1, d10
	mov	x0, x20
	fmov	d2, d10
	fmov	d3, d12
	mov	x1, x19
	fmov	d4, d11
	mov	x2, x22
	bl	pts_fn_parallel_mergeRuns_number_number_array
	adrp	x0, pts_type_closure_parallel_sortRun_number_number_array_arrow_3
	add	x0, x0, :lo12:pts_type_closure_parallel_sortRun_number_number_array_arrow_3
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_sortRun_number_number_array_arrow_3
	add	x8, x8, :lo12:pts_fn_parallel_sortRun_number_number_array_arrow_3
	str	d11, [x0, #16]
	str	x8, [x0, #8]
	stp	x20, x19, [x0, #24]
	fmov	d0, d8
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldr	x23, [sp, #56]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #40]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #24]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #8]              // 16-byte Folded Reload
	ldr	d12, [sp], #96                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	b	pts_parallel_for
.LBB254_3:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x1, [x21, #8]
	mov	x0, x21
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldr	x23, [sp, #56]                  // 8-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #40]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #24]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #8]              // 16-byte Folded Reload
	ldr	d12, [sp], #96                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	br	x1
.LBB254_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end254:
	.size	pts_fn_parallel_sortRun_number_number_array, .Lfunc_end254-pts_fn_parallel_sortRun_number_number_array
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_join_undefined_undefined
	.type	pts_fn_parallel_join_undefined_undefined,@function
pts_fn_parallel_join_undefined_undefined: // @pts_fn_parallel_join_undefined_undefined
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB255_4
// %bb.1:
	mov	w8, #10                         // =0xa
	mov	x20, x1
	mov	x21, x0
	dup	v0.2d, x8
	adrp	x8, :got:pts_array_types
	mov	x1, sp
	mov	w2, #2                          // =0x2
	str	q0, [sp]
	ldr	x8, [x8, :got_lo12:pts_array_types]
	add	x0, x8, #544
	bl	pts_array_of
	mov	x19, x0
	adrp	x0, pts_type_closure_parallel_join_undefined_undefined_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_join_undefined_undefined_arrow
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_join_undefined_undefined_arrow
	add	x8, x8, :lo12:pts_fn_parallel_join_undefined_undefined_arrow
	mov	x22, x0
	stp	x8, x19, [x0, #8]
	str	x21, [x0, #24]
	adrp	x0, pts_type_closure_parallel_join_undefined_undefined_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_join_undefined_undefined_arrow_2
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_join_undefined_undefined_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_join_undefined_undefined_arrow_2
	mov	x1, x0
	stp	x8, x19, [x0, #8]
	str	x20, [x0, #24]
	mov	x0, x22
	bl	pts_parallel_join
	adrp	x0, pts_type_tuple2
	add	x0, x0, :lo12:pts_type_tuple2
	bl	pts_object_new
	movi	d0, #0000000000000000
	mov	x20, x0
	mov	x0, x19
	bl	pts_array_element
	cmp	x0, #10
	b.ne	.LBB255_5
// %bb.2:
	fmov	d0, #1.00000000
	mov	w8, #10                         // =0xa
	mov	x0, x19
	str	x8, [x20, #8]
	bl	pts_array_element
	cmp	x0, #10
	b.ne	.LBB255_5
// %bb.3:
	mov	w8, #10                         // =0xa
	str	x8, [x20, #16]
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #32]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB255_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB255_5:
	adrp	x1, .L.str.197
	add	x1, x1, :lo12:.L.str.197
	bl	pts_throw_type_mismatch
.Lfunc_end255:
	.size	pts_fn_parallel_join_undefined_undefined, .Lfunc_end255-pts_fn_parallel_join_undefined_undefined
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_mergeRuns_number_number_array
	.type	pts_fn_parallel_mergeRuns_number_number_array,@function
pts_fn_parallel_mergeRuns_number_number_array: // @pts_fn_parallel_mergeRuns_number_number_array
	.cfi_startproc
// %bb.0:
	str	d14, [sp, #-160]!               // 8-byte Folded Spill
	.cfi_def_cfa_offset 160
	stp	d13, d12, [sp, #16]             // 16-byte Folded Spill
	stp	d11, d10, [sp, #32]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #80]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_offset b12, -136
	.cfi_offset b13, -144
	.cfi_offset b14, -160
	.cfi_remember_state
	mov	x20, x1
	mov	x19, x0
	mov	w0, #8                          // =0x8
	mov	w1, wzr
	mov	x24, x2
	fmov	d10, d4
	fmov	d8, d3
	fmov	d11, d2
	fmov	d9, d1
	fmov	d12, d0
	bl	pts_cell_new
	mov	x23, x0
	str	d12, [x0]
	mov	w0, #8                          // =0x8
	mov	w1, wzr
	bl	pts_cell_new
	mov	x21, x0
	str	d11, [x0]
	mov	w0, #8                          // =0x8
	mov	w1, wzr
	bl	pts_cell_new
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	str	d10, [x0]
	mrs	x28, TPIDR_EL0
	ldr	x8, [x28, x8]
	cmp	x8, x29
	b.hi	.LBB256_43
// %bb.1:
	mov	x22, x0
	mov	w0, #8                          // =0x8
	mov	w1, wzr
	bl	pts_cell_new
	mov	x25, x0
	mov	w0, #8                          // =0x8
	mov	w1, wzr
	bl	pts_cell_new
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT_ready
	ldrb	w8, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT_ready]
	tbz	w8, #0, .LBB256_46
// %bb.2:
	ldr	d1, [x23]
	ldr	d0, [x21]
	adrp	x8, pts_global_parallel_SEQUENTIAL_SORT
	fsub	d2, d9, d1
	fsub	d0, d8, d0
	fadd	d0, d2, d0
	ldr	d2, [x8, :lo12:pts_global_parallel_SEQUENTIAL_SORT]
	fcmp	d0, d2
	b.ls	.LBB256_10
// %bb.3:
	str	xzr, [x25]
	mov	x26, x0
	str	xzr, [x0]
	ldr	d0, [x23]
	ldr	d1, [x21]
	fsub	d2, d9, d0
	fsub	d3, d8, d1
	fcmp	d2, d3
	b.ge	.LBB256_36
// %bb.4:
	fmov	d0, #0.50000000
	add	x8, x19, #16
	add	x9, x19, #8
	fmul	d0, d3, d0
	frintm	d0, d0
	fadd	d0, d1, d0
	str	d0, [x26]
	fcvtzu	d1, d0
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	ucvtf	d1, d1
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	ucvtf	d2, x9
	fccmp	d0, d2, #0, ge
	fccmp	d0, d1, #0, mi
	b.ne	.LBB256_45
// %bb.5:
	fcvtzu	x9, d0
	ldr	d12, [x23]
	adrp	x0, pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2
	add	x0, x0, :lo12:pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2
	add	x8, x8, x9, lsl #3
	ldr	d10, [x8, #8]
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	add	x8, x8, :lo12:pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	str	d10, [x0, #24]
	stp	x8, x24, [x0, #8]
	adrp	x8, :gottprel:pts_stack_limit
	str	x19, [x0, #32]
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	ldr	x8, [x28, x8]
	cmp	x8, x29
	b.hi	.LBB256_43
// %bb.6:
	fcmp	d12, d9
	b.pl	.LBB256_9
// %bb.7:
	fmov	d14, d9
	fmov	d11, #0.50000000
	mov	x27, x0
	fmov	d13, #1.00000000
.LBB256_8:                              // =>This Inner Loop Header: Depth=1
	fsub	d0, d14, d12
	ldr	x8, [x27, #8]
	mov	x0, x27
	fmul	d0, d0, d11
	frintm	d0, d0
	fadd	d10, d12, d0
	fmov	d0, d10
	blr	x8
	fadd	d0, d10, d13
	tst	w0, #0x1
	fcsel	d14, d14, d10, ne
	fcsel	d12, d0, d12, ne
	fcmp	d12, d14
	b.mi	.LBB256_8
.LBB256_9:
	str	d12, [x25]
	ldr	d11, [x26]
	b	.LBB256_42
.LBB256_10:
	fcmp	d1, d9
	b.pl	.LBB256_25
// %bb.11:
	ldr	d0, [x21]
	fcmp	d0, d8
	b.pl	.LBB256_25
// %bb.12:
	fmov	d10, #1.00000000
.LBB256_13:                             // =>This Inner Loop Header: Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	b.lt	.LBB256_45
// %bb.14:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	d1, d0
	ucvtf	d2, x9
	ucvtf	d1, d1
	fcmp	d0, d2
	fccmp	d0, d1, #0, mi
	b.ne	.LBB256_45
// %bb.15:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	x9, d0
	add	x10, x19, #8
	ldr	d1, [x23]
	add	x8, x8, x9, lsl #3
	add	x9, x19, #16
	ldr	d0, [x8, #8]
	ldar	x9, [x9]
	ldar	x8, [x10]
	ldr	x10, [x8]
	cmp	x9, x10
	csel	x9, x9, x10, lo
	fcmp	d1, #0.0
	b.lt	.LBB256_44
// %bb.16:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	d2, d1
	ucvtf	d3, x9
	ucvtf	d2, d2
	fcmp	d1, d3
	fccmp	d1, d2, #0, mi
	b.ne	.LBB256_44
// %bb.17:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	x9, d1
	mov	x0, x24
	add	x8, x8, x9, lsl #3
	ldr	d1, [x8, #8]
	ldr	x8, [x24, #8]
	blr	x8
	fmov	d1, d0
	ldr	d0, [x22]
	fadd	d2, d0, d10
	fcmp	d1, #0.0
	str	d2, [x22]
	b.pl	.LBB256_19
// %bb.18:                              //   in Loop: Header=BB256_13 Depth=1
	ldr	d1, [x21]
	fadd	d2, d1, d10
	str	d2, [x21]
	b	.LBB256_20
.LBB256_19:                             //   in Loop: Header=BB256_13 Depth=1
	ldr	d1, [x23]
	fadd	d2, d1, d10
	str	d2, [x23]
.LBB256_20:                             //   in Loop: Header=BB256_13 Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d1, #0.0
	b.lt	.LBB256_44
// %bb.21:                              //   in Loop: Header=BB256_13 Depth=1
	ucvtf	d2, x9
	fcmp	d1, d2
	b.pl	.LBB256_44
// %bb.22:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	d2, d1
	ucvtf	d2, d2
	fcmp	d1, d2
	b.ne	.LBB256_44
// %bb.23:                              //   in Loop: Header=BB256_13 Depth=1
	fcvtzu	x9, d1
	add	x1, sp, #8
	mov	x0, x20
	add	x8, x8, x9, lsl #3
	ldr	d1, [x8, #8]
	str	d1, [sp, #8]
	bl	pts_array_set
	ldr	d1, [x23]
	fcmp	d1, d9
	b.pl	.LBB256_25
// %bb.24:                              //   in Loop: Header=BB256_13 Depth=1
	ldr	d0, [x21]
	fcmp	d0, d8
	b.mi	.LBB256_13
.LBB256_25:
	fcmp	d1, d9
	b.pl	.LBB256_30
// %bb.26:
	fmov	d10, #1.00000000
.LBB256_27:                             // =>This Inner Loop Header: Depth=1
	ldr	d0, [x22]
	add	x8, x19, #16
	add	x9, x19, #8
	fadd	d1, d0, d10
	str	d1, [x22]
	ldr	d1, [x23]
	fadd	d2, d1, d10
	str	d2, [x23]
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d1, #0.0
	b.lt	.LBB256_44
// %bb.28:                              //   in Loop: Header=BB256_27 Depth=1
	fcvtzu	d2, d1
	ucvtf	d3, x9
	ucvtf	d2, d2
	fcmp	d1, d3
	fccmp	d1, d2, #0, mi
	b.ne	.LBB256_44
// %bb.29:                              //   in Loop: Header=BB256_27 Depth=1
	fcvtzu	x9, d1
	add	x1, sp, #8
	mov	x0, x20
	add	x8, x8, x9, lsl #3
	ldr	d1, [x8, #8]
	str	d1, [sp, #8]
	bl	pts_array_set
	ldr	d0, [x23]
	fcmp	d0, d9
	b.mi	.LBB256_27
.LBB256_30:
	ldr	d0, [x21]
	fcmp	d0, d8
	b.pl	.LBB256_35
// %bb.31:
	fmov	d9, #1.00000000
.LBB256_32:                             // =>This Inner Loop Header: Depth=1
	ldr	d0, [x22]
	add	x8, x19, #16
	add	x9, x19, #8
	fadd	d1, d0, d9
	str	d1, [x22]
	ldr	d1, [x21]
	fadd	d2, d1, d9
	str	d2, [x21]
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d1, #0.0
	b.lt	.LBB256_44
// %bb.33:                              //   in Loop: Header=BB256_32 Depth=1
	fcvtzu	d2, d1
	ucvtf	d3, x9
	ucvtf	d2, d2
	fcmp	d1, d3
	fccmp	d1, d2, #0, mi
	b.ne	.LBB256_44
// %bb.34:                              //   in Loop: Header=BB256_32 Depth=1
	fcvtzu	x9, d1
	add	x1, sp, #8
	mov	x0, x20
	add	x8, x8, x9, lsl #3
	ldr	d1, [x8, #8]
	str	d1, [sp, #8]
	bl	pts_array_set
	ldr	d0, [x21]
	fcmp	d0, d8
	b.mi	.LBB256_32
.LBB256_35:
	.cfi_def_cfa wsp, 160
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            // 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             // 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             // 16-byte Folded Reload
	ldr	d14, [sp], #160                 // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	ret
.LBB256_36:
	.cfi_restore_state
	.cfi_remember_state
	fmov	d1, #0.50000000
	add	x8, x19, #16
	add	x9, x19, #8
	fmul	d1, d2, d1
	frintm	d1, d1
	fadd	d0, d0, d1
	str	d0, [x25]
	fcvtzu	d1, d0
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	ucvtf	d1, d1
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	ucvtf	d2, x9
	fccmp	d0, d2, #0, ge
	fccmp	d0, d1, #0, mi
	b.ne	.LBB256_45
// %bb.37:
	fcvtzu	x9, d0
	ldr	d11, [x21]
	adrp	x0, pts_type_closure_parallel_mergeRuns_number_number_array_arrow
	add	x0, x0, :lo12:pts_type_closure_parallel_mergeRuns_number_number_array_arrow
	add	x8, x8, x9, lsl #3
	ldr	d10, [x8, #8]
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_mergeRuns_number_number_array_arrow
	add	x8, x8, :lo12:pts_fn_parallel_mergeRuns_number_number_array_arrow
	str	x19, [x0, #24]
	stp	x8, x24, [x0, #8]
	adrp	x8, :gottprel:pts_stack_limit
	str	d10, [x0, #32]
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	ldr	x8, [x28, x8]
	cmp	x8, x29
	b.hi	.LBB256_43
// %bb.38:
	fcmp	d11, d8
	b.pl	.LBB256_41
// %bb.39:
	fmov	d14, d8
	fmov	d12, #0.50000000
	mov	x27, x0
	fmov	d13, #1.00000000
.LBB256_40:                             // =>This Inner Loop Header: Depth=1
	fsub	d0, d14, d11
	ldr	x8, [x27, #8]
	mov	x0, x27
	fmul	d0, d0, d12
	frintm	d0, d0
	fadd	d10, d11, d0
	fmov	d0, d10
	blr	x8
	fadd	d0, d10, d13
	tst	w0, #0x1
	fcsel	d14, d14, d10, ne
	fcsel	d11, d0, d11, ne
	fcmp	d11, d14
	b.mi	.LBB256_40
.LBB256_41:
	str	d11, [x26]
	ldr	d12, [x25]
.LBB256_42:
	ldr	d0, [x23]
	ldr	d1, [x22]
	adrp	x0, pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3
	add	x0, x0, :lo12:pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3
	ldr	d2, [x21]
	fsub	d0, d12, d0
	fadd	d0, d1, d0
	fsub	d1, d11, d2
	fadd	d10, d0, d1
	bl	pts_object_new
	adrp	x8, pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	add	x8, x8, :lo12:pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	mov	x27, x0
	stp	x8, x19, [x0, #8]
	stp	x23, x25, [x0, #24]
	stp	x21, x26, [x0, #40]
	stp	x20, x22, [x0, #56]
	str	x24, [x0, #72]
	adrp	x0, pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4
	add	x0, x0, :lo12:pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4
	bl	pts_object_new
	mov	x1, x0
	adrp	x8, pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	add	x8, x8, :lo12:pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	stp	x8, x19, [x0, #8]
	str	x25, [x0, #24]
	str	d9, [x0, #32]
	str	x26, [x0, #40]
	str	d8, [x0, #48]
	str	x20, [x0, #56]
	str	d10, [x0, #64]
	mov	x0, x27
	str	x24, [x1, #72]
	.cfi_def_cfa wsp, 160
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            // 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             // 16-byte Folded Reload
	ldp	d13, d12, [sp, #16]             // 16-byte Folded Reload
	ldr	d14, [sp], #160                 // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	.cfi_restore b12
	.cfi_restore b13
	.cfi_restore b14
	b	pts_fn_parallel_join_undefined_undefined
.LBB256_43:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB256_44:
	fmov	d0, d1
.LBB256_45:
	mov	x0, x19
	bl	pts_array_index_error
.LBB256_46:
	adrp	x0, .L.str.218
	add	x0, x0, :lo12:.L.str.218
	bl	pts_throw_uninitialized
.Lfunc_end256:
	.size	pts_fn_parallel_mergeRuns_number_number_array, .Lfunc_end256-pts_fn_parallel_mergeRuns_number_number_array
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_join_undefined_undefined_arrow
	.type	pts_fn_parallel_join_undefined_undefined_arrow,@function
pts_fn_parallel_join_undefined_undefined_arrow: // @pts_fn_parallel_join_undefined_undefined_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB257_2
// %bb.1:
	ldp	x19, x8, [x0, #16]
	ldr	x9, [x8, #8]
	mov	x0, x8
	blr	x9
	movi	d0, #0000000000000000
	mov	w8, #10                         // =0xa
	add	x1, x29, #24
	mov	x0, x19
	str	x8, [x29, #24]
	bl	pts_array_set
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB257_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end257:
	.size	pts_fn_parallel_join_undefined_undefined_arrow, .Lfunc_end257-pts_fn_parallel_join_undefined_undefined_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_join_undefined_undefined_arrow
	.type	pts_dynamic_fn_parallel_join_undefined_undefined_arrow,@function
pts_dynamic_fn_parallel_join_undefined_undefined_arrow: // @pts_dynamic_fn_parallel_join_undefined_undefined_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end258:
	.size	pts_dynamic_fn_parallel_join_undefined_undefined_arrow, .Lfunc_end258-pts_dynamic_fn_parallel_join_undefined_undefined_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_30
	.type	pts_adapt_30,@function
pts_adapt_30:                           // @pts_adapt_30
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_30
	add	x0, x0, :lo12:pts_type_adapter_30
	bl	pts_object_new
	adrp	x8, pts_adapter_30
	add	x8, x8, :lo12:pts_adapter_30
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end259:
	.size	pts_adapt_30, .Lfunc_end259-pts_adapt_30
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_30
	.type	pts_adapter_30,@function
pts_adapter_30:                         // @pts_adapter_30
	.cfi_startproc
// %bb.0:
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	b	pts_dynamic_call_closure
.Lfunc_end260:
	.size	pts_adapter_30, .Lfunc_end260-pts_adapter_30
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_join_undefined_undefined_arrow_2
	.type	pts_fn_parallel_join_undefined_undefined_arrow_2,@function
pts_fn_parallel_join_undefined_undefined_arrow_2: // @pts_fn_parallel_join_undefined_undefined_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB261_2
// %bb.1:
	ldp	x19, x8, [x0, #16]
	ldr	x9, [x8, #8]
	mov	x0, x8
	blr	x9
	fmov	d0, #1.00000000
	mov	w8, #10                         // =0xa
	add	x1, x29, #24
	mov	x0, x19
	str	x8, [x29, #24]
	bl	pts_array_set
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB261_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end261:
	.size	pts_fn_parallel_join_undefined_undefined_arrow_2, .Lfunc_end261-pts_fn_parallel_join_undefined_undefined_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2
	.type	pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2,@function
pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2: // @pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end262:
	.size	pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2, .Lfunc_end262-pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortRun_number_number_array_arrow
	.type	pts_fn_parallel_sortRun_number_number_array_arrow,@function
pts_fn_parallel_sortRun_number_number_array_arrow: // @pts_fn_parallel_sortRun_number_number_array_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB263_2
// %bb.1:
	ldp	x8, x1, [x0, #16]
	ldr	d2, [x0, #48]
	ldp	d0, d1, [x0, #32]
	ldp	x2, x3, [x0, #56]
	mov	x0, x8
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_sortRun_number_number_array
.LBB263_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end263:
	.size	pts_fn_parallel_sortRun_number_number_array_arrow, .Lfunc_end263-pts_fn_parallel_sortRun_number_number_array_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_sortRun_number_number_array_arrow
	.type	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow,@function
pts_dynamic_fn_parallel_sortRun_number_number_array_arrow: // @pts_dynamic_fn_parallel_sortRun_number_number_array_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end264:
	.size	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow, .Lfunc_end264-pts_dynamic_fn_parallel_sortRun_number_number_array_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortRun_number_number_array_arrow_2
	.type	pts_fn_parallel_sortRun_number_number_array_arrow_2,@function
pts_fn_parallel_sortRun_number_number_array_arrow_2: // @pts_fn_parallel_sortRun_number_number_array_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB265_2
// %bb.1:
	ldp	x8, x1, [x0, #16]
	ldr	d2, [x0, #48]
	ldp	d0, d1, [x0, #32]
	ldp	x2, x3, [x0, #56]
	mov	x0, x8
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_sortRun_number_number_array
.LBB265_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end265:
	.size	pts_fn_parallel_sortRun_number_number_array_arrow_2, .Lfunc_end265-pts_fn_parallel_sortRun_number_number_array_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2
	.type	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2,@function
pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2: // @pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end266:
	.size	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2, .Lfunc_end266-pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_mergeRuns_number_number_array_arrow
	.type	pts_fn_parallel_mergeRuns_number_number_array_arrow,@function
pts_fn_parallel_mergeRuns_number_number_array_arrow: // @pts_fn_parallel_mergeRuns_number_number_array_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB267_4
// %bb.1:
	mov	x9, x0
	ldp	x0, x8, [x0, #16]
	ldr	d1, [x9, #32]
	add	x10, x8, #16
	add	x11, x8, #8
	ldr	x9, [x0, #8]
	ldar	x12, [x10]
	ldar	x10, [x11]
	ldr	x11, [x10]
	cmp	x12, x11
	csel	x11, x12, x11, lo
	fcmp	d0, #0.0
	b.lt	.LBB267_5
// %bb.2:
	fcvtzu	d2, d0
	ucvtf	d3, x11
	ucvtf	d2, d2
	fcmp	d3, d0
	fccmp	d2, d0, #0, gt
	b.ne	.LBB267_5
// %bb.3:
	fcvtzu	x8, d0
	add	x8, x10, x8, lsl #3
	ldr	d0, [x8, #8]
	blr	x9
	fcmp	d0, #0.0
	cset	w0, mi
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB267_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB267_5:
	mov	x0, x8
	bl	pts_array_index_error
.Lfunc_end267:
	.size	pts_fn_parallel_mergeRuns_number_number_array_arrow, .Lfunc_end267-pts_fn_parallel_mergeRuns_number_number_array_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow
	.type	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow,@function
pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow: // @pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	cbz	w1, .LBB268_3
// %bb.1:
	ldr	x8, [x2]
	lsr	x9, x8, #49
	cbz	x9, .LBB268_6
// %bb.2:
	mov	x9, #-562949953421312           // =0xfffe000000000000
	add	x8, x8, x9
	fmov	d0, x8
	b	.LBB268_5
.LBB268_3:
	mov	x19, x0
	mov	w8, #10                         // =0xa
.LBB268_4:
	mov	x0, x8
	bl	pts_value_to_number_slow
	mov	x0, x19
.LBB268_5:
	ldr	x8, [x0, #8]
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB268_6:
	.cfi_restore_state
	mov	x19, x0
	b	.LBB268_4
.Lfunc_end268:
	.size	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow, .Lfunc_end268-pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	.type	pts_fn_parallel_mergeRuns_number_number_array_arrow_2,@function
pts_fn_parallel_mergeRuns_number_number_array_arrow_2: // @pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB269_4
// %bb.1:
	ldr	x8, [x0, #32]
	mov	x9, x0
	ldr	x0, [x0, #16]
	ldr	d2, [x9, #24]
	add	x10, x8, #16
	add	x11, x8, #8
	ldr	x9, [x0, #8]
	ldar	x12, [x10]
	ldar	x10, [x11]
	ldr	x11, [x10]
	cmp	x12, x11
	csel	x11, x12, x11, lo
	fcmp	d0, #0.0
	b.lt	.LBB269_5
// %bb.2:
	fcvtzu	d1, d0
	ucvtf	d3, x11
	ucvtf	d1, d1
	fcmp	d3, d0
	fccmp	d1, d0, #0, gt
	b.ne	.LBB269_5
// %bb.3:
	fcvtzu	x8, d0
	fmov	d0, d2
	add	x8, x10, x8, lsl #3
	ldr	d1, [x8, #8]
	blr	x9
	fcmp	d0, #0.0
	cset	w0, ge
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB269_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB269_5:
	mov	x0, x8
	bl	pts_array_index_error
.Lfunc_end269:
	.size	pts_fn_parallel_mergeRuns_number_number_array_arrow_2, .Lfunc_end269-pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2
	.type	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2,@function
pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2: // @pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	cbz	w1, .LBB270_3
// %bb.1:
	ldr	x8, [x2]
	lsr	x9, x8, #49
	cbz	x9, .LBB270_6
// %bb.2:
	mov	x9, #-562949953421312           // =0xfffe000000000000
	add	x8, x8, x9
	fmov	d0, x8
	b	.LBB270_5
.LBB270_3:
	mov	x19, x0
	mov	w8, #10                         // =0xa
.LBB270_4:
	mov	x0, x8
	bl	pts_value_to_number_slow
	mov	x0, x19
.LBB270_5:
	ldr	x8, [x0, #8]
	blr	x8
	mov	w8, #6                          // =0x6
	tst	w0, #0x1
	cinc	x0, x8, ne
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB270_6:
	.cfi_restore_state
	mov	x19, x0
	b	.LBB270_4
.Lfunc_end270:
	.size	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2, .Lfunc_end270-pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	.type	pts_fn_parallel_mergeRuns_number_number_array_arrow_3,@function
pts_fn_parallel_mergeRuns_number_number_array_arrow_3: // @pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB271_2
// %bb.1:
	ldp	x8, x1, [x0, #48]
	ldr	x10, [x0, #40]
	ldp	x9, x11, [x0, #24]
	ldp	x12, x2, [x0, #64]
	ldr	x0, [x0, #16]
	ldr	d2, [x10]
	ldr	d3, [x8]
	ldr	d0, [x9]
	ldr	d1, [x11]
	ldr	d4, [x12]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_mergeRuns_number_number_array
.LBB271_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end271:
	.size	pts_fn_parallel_mergeRuns_number_number_array_arrow_3, .Lfunc_end271-pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3
	.type	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3,@function
pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3: // @pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end272:
	.size	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3, .Lfunc_end272-pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	.type	pts_fn_parallel_mergeRuns_number_number_array_arrow_4,@function
pts_fn_parallel_mergeRuns_number_number_array_arrow_4: // @pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB273_2
// %bb.1:
	ldp	x8, x10, [x0, #16]
	ldr	x9, [x0, #40]
	ldr	x2, [x0, #72]
	ldr	d4, [x0, #64]
	ldr	d1, [x0, #32]
	ldr	d3, [x0, #48]
	ldr	d2, [x9]
	ldr	x1, [x0, #56]
	ldr	d0, [x10]
	mov	x0, x8
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_fn_parallel_mergeRuns_number_number_array
.LBB273_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end273:
	.size	pts_fn_parallel_mergeRuns_number_number_array_arrow_4, .Lfunc_end273-pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4
	.type	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4,@function
pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4: // @pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x8, [x0, #8]
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end274:
	.size	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4, .Lfunc_end274-pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortRun_number_number_array_arrow_3
	.type	pts_fn_parallel_sortRun_number_number_array_arrow_3,@function
pts_fn_parallel_sortRun_number_number_array_arrow_3: // @pts_fn_parallel_sortRun_number_number_array_arrow_3
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-64]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB275_7
// %bb.1:
	ldr	d2, [x0, #16]
	fadd	d8, d2, d0
	fadd	d9, d2, d1
	fcmp	d8, d9
	b.pl	.LBB275_6
// %bb.2:
	fmov	d10, #1.00000000
	ldp	x20, x19, [x0, #24]
.LBB275_3:                              // =>This Inner Loop Header: Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d8, #0.0
	b.lt	.LBB275_8
// %bb.4:                               //   in Loop: Header=BB275_3 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB275_8
// %bb.5:                               //   in Loop: Header=BB275_3 Depth=1
	fcvtzu	x9, d8
	add	x1, sp, #8
	mov	x0, x20
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	str	d0, [sp, #8]
	fmov	d0, d8
	bl	pts_array_set
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.mi	.LBB275_3
.LBB275_6:
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldr	d10, [sp], #64                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB275_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB275_8:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end275:
	.size	pts_fn_parallel_sortRun_number_number_array_arrow_3, .Lfunc_end275-pts_fn_parallel_sortRun_number_number_array_arrow_3
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3
	.type	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3,@function
pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3: // @pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB276_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB276_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB276_7
.LBB276_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB276_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB276_9
.LBB276_5:
	mov	w0, #10                         // =0xa
.LBB276_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB276_3
.LBB276_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB276_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB276_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB276_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB276_8
.Lfunc_end276:
	.size	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3, .Lfunc_end276-pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_sortInPlace_number_arrow
	.type	pts_fn_parallel_sortInPlace_number_arrow,@function
pts_fn_parallel_sortInPlace_number_arrow: // @pts_fn_parallel_sortInPlace_number_arrow
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-64]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB277_7
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d8, d0
	mov	x0, x19
	bl	pts_array_slice
	adrp	x2, pts_compare_1
	add	x2, x2, :lo12:pts_compare_1
	mov	x1, x20
	bl	pts_array_sort_with
	add	x8, x0, #16
	ldar	x8, [x8]
	cbz	x8, .LBB277_6
// %bb.2:
	movi	d9, #0000000000000000
	fmov	d10, #1.00000000
	mov	x20, x0
.LBB277_3:                              // =>This Inner Loop Header: Depth=1
	add	x8, x20, #16
	add	x9, x20, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d9, #0.0
	b.lt	.LBB277_8
// %bb.4:                               //   in Loop: Header=BB277_3 Depth=1
	fcvtzu	d0, d9
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d9, d1
	fccmp	d9, d0, #0, mi
	b.ne	.LBB277_8
// %bb.5:                               //   in Loop: Header=BB277_3 Depth=1
	fcvtzu	x9, d9
	fadd	d0, d9, d8
	add	x1, sp, #8
	mov	x0, x19
	add	x8, x8, x9, lsl #3
	ldr	d1, [x8, #8]
	str	d1, [sp, #8]
	bl	pts_array_set
	add	x8, x20, #16
	fadd	d9, d9, d10
	ldar	x8, [x8]
	ucvtf	d0, x8
	fcmp	d9, d0
	b.mi	.LBB277_3
.LBB277_6:
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldr	d10, [sp], #64                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB277_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB277_8:
	fmov	d0, d9
	mov	x0, x20
	bl	pts_array_index_error
.Lfunc_end277:
	.size	pts_fn_parallel_sortInPlace_number_arrow, .Lfunc_end277-pts_fn_parallel_sortInPlace_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_sortInPlace_number_arrow
	.type	pts_dynamic_fn_parallel_sortInPlace_number_arrow,@function
pts_dynamic_fn_parallel_sortInPlace_number_arrow: // @pts_dynamic_fn_parallel_sortInPlace_number_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB278_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB278_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB278_7
.LBB278_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB278_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB278_9
.LBB278_5:
	mov	w0, #10                         // =0xa
.LBB278_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB278_3
.LBB278_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB278_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB278_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB278_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB278_8
.Lfunc_end278:
	.size	pts_dynamic_fn_parallel_sortInPlace_number_arrow, .Lfunc_end278-pts_dynamic_fn_parallel_sortInPlace_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sort_arrow
	.type	pts_fn_parallel_ParallelArray_sort_arrow,@function
pts_fn_parallel_ParallelArray_sort_arrow: // @pts_fn_parallel_ParallelArray_sort_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB279_2
// %bb.1:
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_number_to_string
.LBB279_2:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.Lfunc_end279:
	.size	pts_fn_parallel_ParallelArray_sort_arrow, .Lfunc_end279-pts_fn_parallel_ParallelArray_sort_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sort_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_sort_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_sort_arrow: // @pts_dynamic_fn_parallel_ParallelArray_sort_arrow
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-64]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	str	x21, [sp, #32]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB280_6
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB280_7
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d8, x8
	cmp	w21, #2
	b.lo	.LBB280_8
.LBB280_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB280_9
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d9, x8
	cmp	w21, #3
	b.hs	.LBB280_10
.LBB280_5:
	mov	w0, #10                         // =0xa
	b	.LBB280_11
.LBB280_6:
	mov	w0, #10                         // =0xa
.LBB280_7:
	bl	pts_value_to_number_slow
	fmov	d8, d0
	cmp	w21, #2
	b.hs	.LBB280_3
.LBB280_8:
	mov	w0, #10                         // =0xa
.LBB280_9:
	bl	pts_value_to_number_slow
	fmov	d9, d0
	cmp	w21, #3
	b.lo	.LBB280_5
.LBB280_10:
	ldr	x0, [x20, #16]
.LBB280_11:
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	ldr	x2, [x19, #8]
	mov	x1, x0
	mov	x0, x19
	fmov	d0, d8
	fmov	d1, d9
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	br	x2
.Lfunc_end280:
	.size	pts_dynamic_fn_parallel_ParallelArray_sort_arrow, .Lfunc_end280-pts_dynamic_fn_parallel_ParallelArray_sort_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_27
	.type	pts_adapt_27,@function
pts_adapt_27:                           // @pts_adapt_27
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_27
	add	x0, x0, :lo12:pts_type_adapter_27
	bl	pts_object_new
	adrp	x8, pts_adapter_27
	add	x8, x8, :lo12:pts_adapter_27
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end281:
	.size	pts_adapt_27, .Lfunc_end281-pts_adapt_27
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_27
	.type	pts_adapter_27,@function
pts_adapter_27:                         // @pts_adapter_27
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	str	x1, [sp, #24]
	add	x2, sp, #8
	mov	w1, #3                          // =0x3
	add	x9, x9, x8
	csel	x9, x10, x9, vs
	fcmp	d1, d1
	add	x8, x11, x8
	csel	x8, x10, x8, vs
	stp	x9, x8, [sp, #8]
	bl	pts_dynamic_call_closure
	mov	x8, #-65537                     // =0xfffffffffffeffff
	sub	x9, x0, #16, lsl #12            // =65536
	movk	x8, #1, lsl #48
	cmp	x9, x8
	b.hi	.LBB282_3
// %bb.1:
	ldr	x8, [x0]
	ldr	w8, [x8]
	cmp	w8, #1
	b.ne	.LBB282_3
// %bb.2:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB282_3:
	.cfi_restore_state
	adrp	x1, .L.str.135
	add	x1, x1, :lo12:.L.str.135
	bl	pts_throw_not_primitive
.Lfunc_end282:
	.size	pts_adapter_27, .Lfunc_end282-pts_adapter_27
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_sort_arrow_2
	.type	pts_fn_parallel_ParallelArray_sort_arrow_2,@function
pts_fn_parallel_ParallelArray_sort_arrow_2: // @pts_fn_parallel_ParallelArray_sort_arrow_2
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB283_11
// %bb.1:
	ldr	x0, [x0, #16]
	add	x8, x0, #16
	add	x9, x0, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	b.lt	.LBB283_12
// %bb.2:
	fcvtzu	d2, d0
	ucvtf	d3, x9
	ucvtf	d2, d2
	fcmp	d3, d0
	fccmp	d2, d0, #0, gt
	b.ne	.LBB283_12
// %bb.3:
	fcvtzu	x9, d0
	add	x8, x8, x9, lsl #3
	ldr	x19, [x8, #8]
	cbz	x19, .LBB283_12
// %bb.4:
	add	x8, x0, #16
	add	x9, x0, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d1, #0.0
	b.lt	.LBB283_13
// %bb.5:
	fcvtzu	d0, d1
	ucvtf	d2, x9
	ucvtf	d0, d0
	fcmp	d2, d1
	fccmp	d0, d1, #0, gt
	b.ne	.LBB283_13
// %bb.6:
	fcvtzu	x9, d1
	add	x8, x8, x9, lsl #3
	ldr	x20, [x8, #8]
	cbz	x20, .LBB283_13
// %bb.7:
	mov	x0, x19
	mov	x1, x20
	bl	pts_string_compare
	tbnz	w0, #31, .LBB283_9
// %bb.8:
	mov	x0, x20
	mov	x1, x19
	bl	pts_string_compare
	movi	d0, #0000000000000000
	fmov	d1, #1.00000000
	cmp	w0, #0
	fcsel	d0, d1, d0, lt
	b	.LBB283_10
.LBB283_9:
	fmov	d0, #-1.00000000
.LBB283_10:
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB283_11:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB283_12:
	bl	pts_array_index_error
.LBB283_13:
	fmov	d0, d1
	bl	pts_array_index_error
.Lfunc_end283:
	.size	pts_fn_parallel_ParallelArray_sort_arrow_2, .Lfunc_end283-pts_fn_parallel_ParallelArray_sort_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2
	.type	pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2,@function
pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2: // @pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB284_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB284_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB284_7
.LBB284_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB284_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB284_9
.LBB284_5:
	mov	w0, #10                         // =0xa
.LBB284_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB284_3
.LBB284_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB284_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB284_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB284_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB284_8
.Lfunc_end284:
	.size	pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2, .Lfunc_end284-pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_permute_number_arrow
	.type	pts_fn_parallel_permute_number_arrow,@function
pts_fn_parallel_permute_number_arrow:   // @pts_fn_parallel_permute_number_arrow
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB285_4
// %bb.1:
	ldr	x0, [x0, #16]
	add	x8, x0, #16
	add	x9, x0, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d0, #0.0
	b.lt	.LBB285_5
// %bb.2:
	fcvtzu	d1, d0
	ucvtf	d2, x9
	ucvtf	d1, d1
	fcmp	d2, d0
	fccmp	d1, d0, #0, gt
	b.ne	.LBB285_5
// %bb.3:
	fcvtzu	x9, d0
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB285_4:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB285_5:
	bl	pts_array_index_error
.Lfunc_end285:
	.size	pts_fn_parallel_permute_number_arrow, .Lfunc_end285-pts_fn_parallel_permute_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_permute_number_arrow
	.type	pts_dynamic_fn_parallel_permute_number_arrow,@function
pts_dynamic_fn_parallel_permute_number_arrow: // @pts_dynamic_fn_parallel_permute_number_arrow
	.cfi_startproc
// %bb.0:
	stp	d9, d8, [sp, #-64]!             // 16-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	str	x21, [sp, #32]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	.cfi_offset b8, -56
	.cfi_offset b9, -64
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB286_6
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB286_7
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d8, x8
	cmp	w21, #2
	b.lo	.LBB286_8
.LBB286_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB286_9
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d9, x8
	cmp	w21, #3
	b.hs	.LBB286_10
.LBB286_5:
	mov	w0, #10                         // =0xa
	b	.LBB286_11
.LBB286_6:
	mov	w0, #10                         // =0xa
.LBB286_7:
	bl	pts_value_to_number_slow
	fmov	d8, d0
	cmp	w21, #2
	b.hs	.LBB286_3
.LBB286_8:
	mov	w0, #10                         // =0xa
.LBB286_9:
	bl	pts_value_to_number_slow
	fmov	d9, d0
	cmp	w21, #3
	b.lo	.LBB286_5
.LBB286_10:
	ldr	x0, [x20, #16]
.LBB286_11:
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	fmov	d0, d8
	fmov	d1, d9
	ldr	x8, [x19, #8]
	mov	x1, x0
	mov	x0, x19
	blr	x8
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	add	x8, x9, x8
	mov	x9, #9221683186994511872        // =0x7ffa000000000000
	csel	x0, x9, x8, vs
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldr	x21, [sp, #32]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	ldp	d9, d8, [sp], #64               // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	ret
.Lfunc_end286:
	.size	pts_dynamic_fn_parallel_permute_number_arrow, .Lfunc_end286-pts_dynamic_fn_parallel_permute_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_29
	.type	pts_adapt_29,@function
pts_adapt_29:                           // @pts_adapt_29
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_29
	add	x0, x0, :lo12:pts_type_adapter_29
	bl	pts_object_new
	adrp	x8, pts_adapter_29
	add	x8, x8, :lo12:pts_adapter_29
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end287:
	.size	pts_adapt_29, .Lfunc_end287-pts_adapt_29
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_29
	.type	pts_adapter_29,@function
pts_adapter_29:                         // @pts_adapter_29
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	fmov	x9, d0
	fcmp	d0, d0
	mov	x8, #562949953421312            // =0x2000000000000
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	fmov	x11, d1
	ldr	x0, [x0, #16]
	str	x1, [sp, #24]
	add	x2, sp, #8
	mov	w1, #3                          // =0x3
	add	x9, x9, x8
	csel	x9, x10, x9, vs
	fcmp	d1, d1
	add	x8, x11, x8
	csel	x8, x10, x8, vs
	stp	x9, x8, [sp, #8]
	bl	pts_dynamic_call_closure
	lsr	x8, x0, #49
	cbz	x8, .LBB288_3
// %bb.1:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
.LBB288_2:
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB288_3:
	.cfi_restore_state
	bl	pts_value_to_number_slow
	b	.LBB288_2
.Lfunc_end288:
	.size	pts_adapter_29, .Lfunc_end288-pts_adapter_29
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_ParallelArray_map_number_arrow
	.type	pts_fn_parallel_ParallelArray_map_number_arrow,@function
pts_fn_parallel_ParallelArray_map_number_arrow: // @pts_fn_parallel_ParallelArray_map_number_arrow
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-96]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 96
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #48]             // 16-byte Folded Spill
	stp	x22, x21, [sp, #64]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #80]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 64
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w30, -56
	.cfi_offset w29, -64
	.cfi_offset b8, -72
	.cfi_offset b9, -80
	.cfi_offset b10, -96
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB289_17
// %bb.1:
	ldp	x19, x20, [x0, #16]
	fmov	d9, d1
	ldr	x21, [x0, #32]
	fmov	d8, d0
	mov	x0, x19
	bl	pts_parallel_has_holes_in
	fcmp	d8, d9
	b.pl	.LBB289_16
// %bb.2:
	adrp	x23, :got:pts_type_match_array
	fmov	d10, #1.00000000
	adrp	x24, :got:pts_type_match_copy
	ldr	x23, [x23, :got_lo12:pts_type_match_array]
	ldr	x24, [x24, :got_lo12:pts_type_match_copy]
	mov	w22, w0
	b	.LBB289_5
.LBB289_3:                              //   in Loop: Header=BB289_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.eq	.LBB289_9
.LBB289_4:                              //   in Loop: Header=BB289_5 Depth=1
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.pl	.LBB289_16
.LBB289_5:                              // =>This Inner Loop Header: Depth=1
	tbz	w22, #0, .LBB289_9
// %bb.6:                               //   in Loop: Header=BB289_5 Depth=1
	mov	x8, x19
	add	x10, x19, #16
	ldr	x9, [x8], #8
	ldr	w9, [x9, #64]
	ldar	x10, [x10]
	ldar	x8, [x8]
	ldr	x11, [x8]
	cmp	x10, x11
	csel	x10, x10, x11, lo
	fcmp	d8, #0.0
	sub	w11, w9, #3
	ucvtf	d0, x10
	cset	w10, ge
	fcmp	d8, d0
	fcvtzu	d0, d8
	csel	w9, wzr, w10, pl
	cmp	w11, #2
	ucvtf	d0, d0
	b.hi	.LBB289_3
// %bb.7:                               //   in Loop: Header=BB289_5 Depth=1
	cmp	w9, #0
	fccmp	d8, d0, #0, ne
	b.ne	.LBB289_4
// %bb.8:                               //   in Loop: Header=BB289_5 Depth=1
	fcvtzu	x9, d8
	add	x8, x8, x9, lsl #3
	ldr	x8, [x8, #8]
	cbz	x8, .LBB289_12
.LBB289_9:                              //   in Loop: Header=BB289_5 Depth=1
	add	x9, x19, #16
	add	x10, x19, #8
	ldr	x8, [x21, #8]
	ldar	x11, [x9]
	ldar	x9, [x10]
	ldr	x10, [x9]
	cmp	x11, x10
	csel	x10, x11, x10, lo
	fcmp	d8, #0.0
	b.lt	.LBB289_18
// %bb.10:                              //   in Loop: Header=BB289_5 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x10
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB289_18
// %bb.11:                              //   in Loop: Header=BB289_5 Depth=1
	fcvtzu	x10, d8
	fmov	d1, d8
	mov	x0, x21
	mov	x1, x19
	add	x9, x9, x10, lsl #3
	ldr	d0, [x9, #8]
	blr	x8
	str	d0, [sp, #8]
	fmov	d0, d8
	add	x1, sp, #8
	mov	x0, x20
	bl	pts_array_set
	b	.LBB289_4
.LBB289_12:                             //   in Loop: Header=BB289_5 Depth=1
	ldr	x8, [x19]
	ldrb	w9, [x8, #4]
	cbnz	w9, .LBB289_15
// %bb.13:                              //   in Loop: Header=BB289_5 Depth=1
	cmp	x8, x23
	b.eq	.LBB289_9
.LBB289_14:                             //   in Loop: Header=BB289_5 Depth=1
	cmp	x8, x24
	b.ne	.LBB289_4
	b	.LBB289_9
.LBB289_15:                             //   in Loop: Header=BB289_5 Depth=1
	ldr	x8, [x8, #24]
	cmp	x8, x23
	b.ne	.LBB289_14
	b	.LBB289_9
.LBB289_16:
	.cfi_def_cfa wsp, 96
	ldp	x20, x19, [sp, #80]             // 16-byte Folded Reload
	ldp	x22, x21, [sp, #64]             // 16-byte Folded Reload
	ldp	x24, x23, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldr	d10, [sp], #96                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB289_17:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB289_18:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end289:
	.size	pts_fn_parallel_ParallelArray_map_number_arrow, .Lfunc_end289-pts_fn_parallel_ParallelArray_map_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_ParallelArray_map_number_arrow
	.type	pts_dynamic_fn_parallel_ParallelArray_map_number_arrow,@function
pts_dynamic_fn_parallel_ParallelArray_map_number_arrow: // @pts_dynamic_fn_parallel_ParallelArray_map_number_arrow
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB290_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB290_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB290_7
.LBB290_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB290_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB290_9
.LBB290_5:
	mov	w0, #10                         // =0xa
.LBB290_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB290_3
.LBB290_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB290_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB290_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB290_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB290_8
.Lfunc_end290:
	.size	pts_dynamic_fn_parallel_ParallelArray_map_number_arrow, .Lfunc_end290-pts_dynamic_fn_parallel_ParallelArray_map_number_arrow
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_permute_number_arrow_2
	.type	pts_fn_parallel_permute_number_arrow_2,@function
pts_fn_parallel_permute_number_arrow_2: // @pts_fn_parallel_permute_number_arrow_2
	.cfi_startproc
// %bb.0:
	str	d10, [sp, #-64]!                // 8-byte Folded Spill
	.cfi_def_cfa_offset 64
	stp	d9, d8, [sp, #16]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #32]             // 16-byte Folded Spill
	stp	x20, x19, [sp, #48]             // 16-byte Folded Spill
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_offset b8, -40
	.cfi_offset b9, -48
	.cfi_offset b10, -64
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB291_7
// %bb.1:
	fmov	d9, d1
	fmov	d8, d0
	fcmp	d0, d1
	b.pl	.LBB291_6
// %bb.2:
	fmov	d10, #1.00000000
	ldp	x20, x19, [x0, #16]
.LBB291_3:                              // =>This Inner Loop Header: Depth=1
	add	x8, x19, #16
	add	x9, x19, #8
	ldar	x10, [x8]
	ldar	x8, [x9]
	ldr	x9, [x8]
	cmp	x10, x9
	csel	x9, x10, x9, lo
	fcmp	d8, #0.0
	b.lt	.LBB291_8
// %bb.4:                               //   in Loop: Header=BB291_3 Depth=1
	fcvtzu	d0, d8
	ucvtf	d1, x9
	ucvtf	d0, d0
	fcmp	d8, d1
	fccmp	d8, d0, #0, mi
	b.ne	.LBB291_8
// %bb.5:                               //   in Loop: Header=BB291_3 Depth=1
	fcvtzu	x9, d8
	add	x1, sp, #8
	mov	x0, x20
	add	x8, x8, x9, lsl #3
	ldr	d0, [x8, #8]
	str	d0, [sp, #8]
	fmov	d0, d8
	bl	pts_array_set
	fadd	d8, d8, d10
	fcmp	d8, d9
	b.mi	.LBB291_3
.LBB291_6:
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #32]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #16]               // 16-byte Folded Reload
	ldr	d10, [sp], #64                  // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	ret
.LBB291_7:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB291_8:
	fmov	d0, d8
	mov	x0, x19
	bl	pts_array_index_error
.Lfunc_end291:
	.size	pts_fn_parallel_permute_number_arrow_2, .Lfunc_end291-pts_fn_parallel_permute_number_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_permute_number_arrow_2
	.type	pts_dynamic_fn_parallel_permute_number_arrow_2,@function
pts_dynamic_fn_parallel_permute_number_arrow_2: // @pts_dynamic_fn_parallel_permute_number_arrow_2
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB292_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB292_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB292_7
.LBB292_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB292_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB292_9
.LBB292_5:
	mov	w0, #10                         // =0xa
.LBB292_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB292_3
.LBB292_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB292_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB292_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB292_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB292_8
.Lfunc_end292:
	.size	pts_dynamic_fn_parallel_permute_number_arrow_2, .Lfunc_end292-pts_dynamic_fn_parallel_permute_number_arrow_2
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_45
	.type	pts_adapt_45,@function
pts_adapt_45:                           // @pts_adapt_45
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_45
	add	x0, x0, :lo12:pts_type_adapter_45
	bl	pts_object_new
	adrp	x8, pts_adapter_45
	add	x8, x8, :lo12:pts_adapter_45
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end293:
	.size	pts_adapt_45, .Lfunc_end293-pts_adapt_45
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_45
	.type	pts_adapter_45,@function
pts_adapter_45:                         // @pts_adapter_45
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end294:
	.size	pts_adapter_45, .Lfunc_end294-pts_adapter_45
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_46
	.type	pts_adapt_46,@function
pts_adapt_46:                           // @pts_adapt_46
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_46
	add	x0, x0, :lo12:pts_type_adapter_46
	bl	pts_object_new
	adrp	x8, pts_adapter_46
	add	x8, x8, :lo12:pts_adapter_46
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end295:
	.size	pts_adapt_46, .Lfunc_end295-pts_adapt_46
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_46
	.type	pts_adapter_46,@function
pts_adapter_46:                         // @pts_adapter_46
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]             // 16-byte Folded Spill
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	str	x1, [sp, #8]
	add	x2, sp, #8
	mov	w1, #1                          // =0x1
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_3
	add	x1, x1, :lo12:pts_check_3
	bl	pts_value_convert
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]             // 16-byte Folded Reload
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end296:
	.size	pts_adapter_46, .Lfunc_end296-pts_adapter_46
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_36
	.type	pts_adapt_36,@function
pts_adapt_36:                           // @pts_adapt_36
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_36
	add	x0, x0, :lo12:pts_type_adapter_36
	bl	pts_object_new
	adrp	x8, pts_adapter_36
	add	x8, x8, :lo12:pts_adapter_36
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end297:
	.size	pts_adapt_36, .Lfunc_end297-pts_adapt_36
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_36
	.type	pts_adapter_36,@function
pts_adapter_36:                         // @pts_adapter_36
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	bl	pts_dynamic_call_closure
	adrp	x1, pts_check_1
	add	x1, x1, :lo12:pts_check_1
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	pts_value_convert
.Lfunc_end298:
	.size	pts_adapter_36, .Lfunc_end298-pts_adapter_36
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_step_fn_parallel_Range__u0040_u0040iterator_
	.type	pts_step_fn_parallel_Range__u0040_u0040iterator_,@function
pts_step_fn_parallel_Range__u0040_u0040iterator_: // @pts_step_fn_parallel_Range__u0040_u0040iterator_
	.cfi_startproc
// %bb.0:
	ldr	w9, [x0, #16]
	mov	x8, x0
	cmp	w9, #1
	b.ne	.LBB299_4
// %bb.1:
	ldr	w9, [x8, #20]
	mov	w10, #-1                        // =0xffffffff
	str	w10, [x8, #16]
	cmp	w9, #2
	b.eq	.LBB299_8
// %bb.2:
	cmp	w9, #1
	b.eq	.LBB299_10
// %bb.3:
	fmov	d0, #1.00000000
	ldr	d1, [x8, #88]
	ldr	x9, [x8, #80]
	fadd	d0, d1, d0
	b	.LBB299_5
.LBB299_4:
	ldr	x9, [x8, #80]
	ldr	d0, [x9, #8]
.LBB299_5:
	ldr	d1, [x9, #16]
	str	d0, [x8, #88]
	fcmp	d0, d1
	b.pl	.LBB299_7
// %bb.6:
	fmov	x9, d0
	fcmp	d0, d0
	mov	x10, #562949953421312           // =0x2000000000000
	mov	w0, wzr
	add	x9, x9, x10
	mov	x10, #9221683186994511872       // =0x7ffa000000000000
	csel	x9, x10, x9, vs
	mov	w10, #1                         // =0x1
	b	.LBB299_9
.LBB299_7:
	mov	w0, #1                          // =0x1
	mov	w10, #-2                        // =0xfffffffe
	mov	w9, #10                         // =0xa
	b	.LBB299_9
.LBB299_8:
	ldr	x9, [x8, #24]
	mov	w0, #1                          // =0x1
	mov	w10, #-2                        // =0xfffffffe
.LBB299_9:
	str	x9, [x8, #32]
	str	w10, [x8, #16]
	ret
.LBB299_10:
	stp	x29, x30, [sp, #-16]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x8, #24]
	bl	pts_throw
.Lfunc_end299:
	.size	pts_step_fn_parallel_Range__u0040_u0040iterator_, .Lfunc_end299-pts_step_fn_parallel_Range__u0040_u0040iterator_
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapt_37
	.type	pts_adapt_37,@function
pts_adapt_37:                           // @pts_adapt_37
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]                  // 8-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x0
	adrp	x0, pts_type_adapter_37
	add	x0, x0, :lo12:pts_type_adapter_37
	bl	pts_object_new
	adrp	x8, pts_adapter_37
	add	x8, x8, :lo12:pts_adapter_37
	stp	x8, x19, [x0, #8]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end300:
	.size	pts_adapt_37, .Lfunc_end300-pts_adapt_37
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_adapter_37
	.type	pts_adapter_37,@function
pts_adapter_37:                         // @pts_adapter_37
	.cfi_startproc
// %bb.0:
	ldr	x0, [x0, #16]
	mov	w1, wzr
	mov	x2, xzr
	b	pts_dynamic_call_closure
.Lfunc_end301:
	.size	pts_adapter_37, .Lfunc_end301-pts_adapter_37
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_parallel_for
	.type	pts_fn_parallel_for,@function
pts_fn_parallel_for:                    // @pts_fn_parallel_for
	.cfi_startproc
// %bb.0:
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	d11, d10, [sp, #32]             // 16-byte Folded Spill
	stp	d9, d8, [sp, #48]               // 16-byte Folded Spill
	stp	x29, x30, [sp, #64]             // 16-byte Folded Spill
	stp	x28, x27, [sp, #80]             // 16-byte Folded Spill
	stp	x26, x25, [sp, #96]             // 16-byte Folded Spill
	stp	x24, x23, [sp, #112]            // 16-byte Folded Spill
	stp	x22, x21, [sp, #128]            // 16-byte Folded Spill
	stp	x20, x19, [sp, #144]            // 16-byte Folded Spill
	add	x29, sp, #64
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_offset b10, -120
	.cfi_offset b11, -128
	.cfi_remember_state
	adrp	x8, :gottprel:pts_stack_limit
	ldr	x8, [x8, :gottprel_lo12:pts_stack_limit]
	mrs	x9, TPIDR_EL0
	ldr	x8, [x9, x8]
	cmp	x8, x29
	b.hi	.LBB302_43
// %bb.1:
	fmov	d8, d1
	fmov	d9, d0
	fcmp	d0, d1
	b.pl	.LBB302_41
// %bb.2:
	fmov	d11, #1.00000000
	ldr	x26, [x0, #16]
	adrp	x23, pts_global_Payload_class_ready
	adrp	x19, pts_type_Payload
	add	x19, x19, :lo12:pts_type_Payload
	adrp	x22, pts_global_elements
	adrp	x20, pts_global_entries_ready
	adrp	x27, pts_global_entries
	adrp	x28, pts_global_variable_ready
	adrp	x21, pts_global_variable
	b	.LBB302_6
.LBB302_3:                              //   in Loop: Header=BB302_6 Depth=1
	bl	pts_fn_check
	ldrb	w8, [x28, :lo12:pts_global_variable_ready]
	tbz	w8, #0, .LBB302_46
// %bb.4:                               //   in Loop: Header=BB302_6 Depth=1
	ldr	x0, [x21, :lo12:pts_global_variable]
	bl	pts_fn_check
.LBB302_5:                              //   in Loop: Header=BB302_6 Depth=1
	fadd	d9, d9, d11
	fcmp	d9, d8
	b.pl	.LBB302_41
.LBB302_6:                              // =>This Loop Header: Depth=1
                                        //     Child Loop BB302_27 Depth 2
                                        //     Child Loop BB302_35 Depth 2
	ldr	d0, [x26, #8]
	fmov	d1, #2.00000000
	fadd	d10, d9, d0
	fmov	d0, d10
	bl	fmod
	fcmp	d0, #0.0
	adrp	x8, pts_global_slot_ready
	ldrb	w8, [x8, :lo12:pts_global_slot_ready]
	b.ne	.LBB302_11
// %bb.7:                               //   in Loop: Header=BB302_6 Depth=1
	tbz	w8, #0, .LBB302_45
// %bb.8:                               //   in Loop: Header=BB302_6 Depth=1
	ldrb	w8, [x23, :lo12:pts_global_Payload_class_ready]
	tbz	w8, #0, .LBB302_44
// %bb.9:                               //   in Loop: Header=BB302_6 Depth=1
	adrp	x8, pts_global_slot
	mov	x0, x19
	ldr	x24, [x8, :lo12:pts_global_slot]
	bl	pts_object_new
	fmov	d0, d10
	mov	x25, x0
	bl	pts_fn_Payload_constructor
	str	x25, [sp, #24]
	adrp	x8, pts_fn_parallel_for.pts_site1
	ldr	x8, [x8, :lo12:pts_fn_parallel_for.pts_site1]
	ldr	x9, [x24]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB302_14
// %bb.10:                              //   in Loop: Header=BB302_6 Depth=1
	lsr	x8, x8, #48
	str	x25, [x24, x8]
	b	.LBB302_15
.LBB302_11:                             //   in Loop: Header=BB302_6 Depth=1
	tbz	w8, #0, .LBB302_45
// %bb.12:                              //   in Loop: Header=BB302_6 Depth=1
	adrp	x8, pts_global_slot
	ldr	x0, [x8, :lo12:pts_global_slot]
	adrp	x8, pts_fn_parallel_for.pts_site2
	ldr	x8, [x8, :lo12:pts_fn_parallel_for.pts_site2]
	ldr	x9, [x0]
	and	x10, x8, #0xffffffffffff
	cmp	x10, x9
	b.ne	.LBB302_22
// %bb.13:                              //   in Loop: Header=BB302_6 Depth=1
	add	x0, x0, x8, lsr #48
	b	.LBB302_23
.LBB302_14:                             //   in Loop: Header=BB302_6 Depth=1
	add	x4, sp, #24
	mov	x0, x24
	adrp	x1, pts_fn_parallel_for.pts_site1
	add	x1, x1, :lo12:pts_fn_parallel_for.pts_site1
	adrp	x2, .L.str.121
	add	x2, x2, :lo12:.L.str.121
	adrp	x3, pts_check_13
	add	x3, x3, :lo12:pts_check_13
	bl	pts_field_set_slow
.LBB302_15:                             //   in Loop: Header=BB302_6 Depth=1
	adrp	x8, pts_global_elements_ready
	ldrb	w8, [x8, :lo12:pts_global_elements_ready]
	tbz	w8, #0, .LBB302_48
// %bb.16:                              //   in Loop: Header=BB302_6 Depth=1
	ldrb	w8, [x23, :lo12:pts_global_Payload_class_ready]
	tbz	w8, #0, .LBB302_44
// %bb.17:                              //   in Loop: Header=BB302_6 Depth=1
	ldr	x24, [x22, :lo12:pts_global_elements]
	mov	x0, x19
	bl	pts_object_new
	fmov	d0, d10
	mov	x25, x0
	bl	pts_fn_Payload_constructor
	movi	d0, #0000000000000000
	add	x1, sp, #24
	mov	x0, x24
	str	x25, [sp, #24]
	bl	pts_array_set
	ldrb	w8, [x20, :lo12:pts_global_entries_ready]
	tbz	w8, #0, .LBB302_47
// %bb.18:                              //   in Loop: Header=BB302_6 Depth=1
	ldrb	w8, [x23, :lo12:pts_global_Payload_class_ready]
	tbz	w8, #0, .LBB302_44
// %bb.19:                              //   in Loop: Header=BB302_6 Depth=1
	ldr	x24, [x27, :lo12:pts_global_entries]
	mov	x0, x19
	bl	pts_object_new
	fmov	d0, d10
	mov	x25, x0
	bl	pts_fn_Payload_constructor
	add	x1, sp, #16
	add	x2, sp, #8
	mov	x0, x24
	stp	x25, xzr, [sp, #8]
	bl	pts_map_set
	ldrb	w8, [x23, :lo12:pts_global_Payload_class_ready]
	tbz	w8, #0, .LBB302_44
// %bb.20:                              //   in Loop: Header=BB302_6 Depth=1
	mov	x0, x19
	bl	pts_object_new
	fmov	d0, d10
	mov	x24, x0
	bl	pts_fn_Payload_constructor
	ldrb	w8, [x28, :lo12:pts_global_variable_ready]
	tbz	w8, #0, .LBB302_46
// %bb.21:                              //   in Loop: Header=BB302_6 Depth=1
	str	x24, [x21, :lo12:pts_global_variable]
	b	.LBB302_5
.LBB302_22:                             //   in Loop: Header=BB302_6 Depth=1
	adrp	x1, pts_fn_parallel_for.pts_site2
	add	x1, x1, :lo12:pts_fn_parallel_for.pts_site2
	adrp	x2, .L.str.121
	add	x2, x2, :lo12:.L.str.121
	adrp	x3, pts_check_13
	add	x3, x3, :lo12:pts_check_13
	bl	pts_field_address_slow
.LBB302_23:                             //   in Loop: Header=BB302_6 Depth=1
	ldr	x0, [x0]
	cbz	x0, .LBB302_42
// %bb.24:                              //   in Loop: Header=BB302_6 Depth=1
	bl	pts_fn_check
	adrp	x8, pts_global_elements_ready
	ldrb	w8, [x8, :lo12:pts_global_elements_ready]
	tbz	w8, #0, .LBB302_48
// %bb.25:                              //   in Loop: Header=BB302_6 Depth=1
	movi	d0, #0000000000000000
	ldr	x0, [x22, :lo12:pts_global_elements]
	bl	pts_array_element
	mov	x9, #-65537                     // =0xfffffffffffeffff
	sub	x8, x0, #16, lsl #12            // =65536
	movk	x9, #1, lsl #48
	cmp	x8, x9
	b.hi	.LBB302_30
// %bb.26:                              //   in Loop: Header=BB302_6 Depth=1
	mov	x10, x0
.LBB302_27:                             //   Parent Loop BB302_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	x9, [x10]
	cmp	x9, #0
	cset	w8, ne
	cmp	x9, x19
	b.eq	.LBB302_29
// %bb.28:                              //   in Loop: Header=BB302_27 Depth=2
	add	x10, x9, #24
	cbnz	x9, .LBB302_27
.LBB302_29:                             //   in Loop: Header=BB302_6 Depth=1
	cmp	x0, #10
	b.ne	.LBB302_31
	b	.LBB302_32
.LBB302_30:                             //   in Loop: Header=BB302_6 Depth=1
	mov	w8, wzr
	cmp	x0, #10
	b.eq	.LBB302_32
.LBB302_31:                             //   in Loop: Header=BB302_6 Depth=1
	tbz	w8, #0, .LBB302_40
.LBB302_32:                             //   in Loop: Header=BB302_6 Depth=1
	bl	pts_fn_check
	ldrb	w8, [x20, :lo12:pts_global_entries_ready]
	tbz	w8, #0, .LBB302_47
// %bb.33:                              //   in Loop: Header=BB302_6 Depth=1
	ldr	x0, [x27, :lo12:pts_global_entries]
	mov	x1, sp
	str	xzr, [sp]
	bl	pts_map_get_value
	mov	x9, #-65537                     // =0xfffffffffffeffff
	sub	x8, x0, #16, lsl #12            // =65536
	movk	x9, #1, lsl #48
	cmp	x8, x9
	b.hi	.LBB302_37
// %bb.34:                              //   in Loop: Header=BB302_6 Depth=1
	mov	x10, x0
.LBB302_35:                             //   Parent Loop BB302_6 Depth=1
                                        // =>  This Inner Loop Header: Depth=2
	ldr	x9, [x10]
	cmp	x9, #0
	cset	w8, ne
	cmp	x9, x19
	b.eq	.LBB302_38
// %bb.36:                              //   in Loop: Header=BB302_35 Depth=2
	add	x10, x9, #24
	cbnz	x9, .LBB302_35
	b	.LBB302_38
.LBB302_37:                             //   in Loop: Header=BB302_6 Depth=1
	mov	w8, wzr
.LBB302_38:                             //   in Loop: Header=BB302_6 Depth=1
	cmp	x0, #10
	b.eq	.LBB302_3
// %bb.39:                              //   in Loop: Header=BB302_6 Depth=1
	tbnz	w8, #0, .LBB302_3
.LBB302_40:
	adrp	x1, .L.str.230
	add	x1, x1, :lo12:.L.str.230
	bl	pts_throw_type_mismatch
.LBB302_41:
	.cfi_def_cfa wsp, 160
	ldp	x20, x19, [sp, #144]            // 16-byte Folded Reload
	ldp	x22, x21, [sp, #128]            // 16-byte Folded Reload
	ldp	x24, x23, [sp, #112]            // 16-byte Folded Reload
	ldp	x26, x25, [sp, #96]             // 16-byte Folded Reload
	ldp	x28, x27, [sp, #80]             // 16-byte Folded Reload
	ldp	x29, x30, [sp, #64]             // 16-byte Folded Reload
	ldp	d9, d8, [sp, #48]               // 16-byte Folded Reload
	ldp	d11, d10, [sp, #32]             // 16-byte Folded Reload
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	.cfi_restore b9
	.cfi_restore b10
	.cfi_restore b11
	ret
.LBB302_42:
	.cfi_restore_state
	adrp	x0, .L.str.121
	add	x0, x0, :lo12:.L.str.121
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB302_43:
	bl	pts_throw_stack_overflow
.LBB302_44:
	adrp	x0, .L.str.122
	add	x0, x0, :lo12:.L.str.122
	bl	pts_throw_uninitialized
.LBB302_45:
	adrp	x0, .L.str.227
	add	x0, x0, :lo12:.L.str.227
	bl	pts_throw_uninitialized
.LBB302_46:
	adrp	x0, .L.str.231
	add	x0, x0, :lo12:.L.str.231
	bl	pts_throw_uninitialized
.LBB302_47:
	adrp	x0, .L.str.229
	add	x0, x0, :lo12:.L.str.229
	bl	pts_throw_uninitialized
.LBB302_48:
	adrp	x0, .L.str.228
	add	x0, x0, :lo12:.L.str.228
	bl	pts_throw_uninitialized
.Lfunc_end302:
	.size	pts_fn_parallel_for, .Lfunc_end302-pts_fn_parallel_for
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_dynamic_fn_parallel_for
	.type	pts_dynamic_fn_parallel_for,@function
pts_dynamic_fn_parallel_for:            // @pts_dynamic_fn_parallel_for
	.cfi_startproc
// %bb.0:
	str	d8, [sp, #-48]!                 // 8-byte Folded Spill
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #8]              // 16-byte Folded Spill
	str	x21, [sp, #24]                  // 8-byte Folded Spill
	stp	x20, x19, [sp, #32]             // 16-byte Folded Spill
	add	x29, sp, #8
	.cfi_def_cfa w29, 40
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w30, -32
	.cfi_offset w29, -40
	.cfi_offset b8, -48
	.cfi_remember_state
	mov	x20, x2
	mov	w21, w1
	mov	x19, x0
	cbz	w1, .LBB303_5
// %bb.1:
	ldr	x0, [x20]
	lsr	x8, x0, #49
	cbz	x8, .LBB303_6
// %bb.2:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d0, x8
	cmp	w21, #2
	b.lo	.LBB303_7
.LBB303_3:
	ldr	x0, [x20, #8]
	lsr	x8, x0, #49
	cbz	x8, .LBB303_10
// %bb.4:
	mov	x8, #-562949953421312           // =0xfffe000000000000
	add	x8, x0, x8
	fmov	d1, x8
	b	.LBB303_9
.LBB303_5:
	mov	w0, #10                         // =0xa
.LBB303_6:
	bl	pts_value_to_number_slow
	cmp	w21, #2
	b.hs	.LBB303_3
.LBB303_7:
	fmov	d8, d0
	mov	w0, #10                         // =0xa
.LBB303_8:
	bl	pts_value_to_number_slow
	fmov	d1, d0
	fmov	d0, d8
.LBB303_9:
	ldr	x8, [x19, #8]
	mov	x0, x19
	blr	x8
	mov	w0, #10                         // =0xa
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]             // 16-byte Folded Reload
	ldr	x21, [sp, #24]                  // 8-byte Folded Reload
	ldp	x29, x30, [sp, #8]              // 16-byte Folded Reload
	ldr	d8, [sp], #48                   // 8-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore b8
	ret
.LBB303_10:
	.cfi_restore_state
	fmov	d8, d0
	b	.LBB303_8
.Lfunc_end303:
	.size	pts_dynamic_fn_parallel_for, .Lfunc_end303-pts_dynamic_fn_parallel_for
	.cfi_endproc
                                        // -- End function
	.p2align	2                               // -- Begin function pts_fn_check
	.type	pts_fn_check,@function
pts_fn_check:                           // @pts_fn_check
	.cfi_startproc
// %bb.0:
	stp	x29, x30, [sp, #-32]!           // 16-byte Folded Spill
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]             // 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adrp	x19, :gottprel:pts_stack_limit
	ldr	x19, [x19, :gottprel_lo12:pts_stack_limit]
	mrs	x20, TPIDR_EL0
	ldr	x8, [x20, x19]
	cmp	x8, x29
	b.hi	.LBB304_17
// %bb.1:
	mov	x9, #-65537                     // =0xfffffffffffeffff
	sub	x8, x0, #16, lsl #12            // =65536
	movk	x9, #1, lsl #48
	cmp	x8, x9
	b.hi	.LBB304_13
// %bb.2:
	adrp	x8, pts_type_Payload
	add	x8, x8, :lo12:pts_type_Payload
	mov	x10, x0
.LBB304_3:                              // =>This Inner Loop Header: Depth=1
	ldr	x9, [x10]
	cmp	x9, x8
	b.eq	.LBB304_5
// %bb.4:                               //   in Loop: Header=BB304_3 Depth=1
	add	x10, x9, #24
	cbnz	x9, .LBB304_3
.LBB304_5:
	cbz	x9, .LBB304_13
// %bb.6:
	ldr	x9, [x0]
	cmp	x9, x8
	b.eq	.LBB304_11
// %bb.7:
	cbz	x9, .LBB304_19
.LBB304_8:                              // =>This Inner Loop Header: Depth=1
	ldr	x9, [x9, #24]
	cmp	x9, x8
	b.eq	.LBB304_10
// %bb.9:                               //   in Loop: Header=BB304_8 Depth=1
	cbnz	x9, .LBB304_8
.LBB304_10:
	cbz	x9, .LBB304_19
.LBB304_11:
	bl	pts_fn_Payload_whole
	tbz	w0, #0, .LBB304_13
// %bb.12:
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB304_13:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x8, pts_global_bad_ready
	ldrb	w8, [x8, :lo12:pts_global_bad_ready]
	tbz	w8, #0, .LBB304_20
// %bb.14:
	ldr	x8, [x20, x19]
	cmp	x8, x29
	b.hi	.LBB304_17
// %bb.15:
	adrp	x8, pts_global_bad
	ldr	x8, [x8, :lo12:pts_global_bad]
	ldr	x0, [x8, #8]
	cbz	x0, .LBB304_18
// %bb.16:
	mov	w1, #1                          // =0x1
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]             // 16-byte Folded Reload
	ldp	x29, x30, [sp], #32             // 16-byte Folded Reload
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	b	pts_atomic_add
.LBB304_17:
	.cfi_restore_state
	bl	pts_throw_stack_overflow
.LBB304_18:
	adrp	x0, .L.str.156
	add	x0, x0, :lo12:.L.str.156
	mov	x1, xzr
	bl	pts_throw_unset_field
.LBB304_19:
	adrp	x0, pts_type_Payload
	add	x0, x0, :lo12:pts_type_Payload
	bl	pts_throw_not_instance
.LBB304_20:
	adrp	x0, .L.str.232
	add	x0, x0, :lo12:.L.str.232
	bl	pts_throw_uninitialized
.Lfunc_end304:
	.size	pts_fn_check, .Lfunc_end304-pts_fn_check
	.cfi_endproc
                                        // -- End function
	.type	pts_function_names,@object      // @pts_function_names
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_function_names:
	.xword	.L.str
	.xword	.L.str.1
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.2
	.xword	.L.str.3
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.4
	.xword	.L.str.5
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.6
	.xword	.L.str.7
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.8
	.xword	.L.str.9
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.10
	.xword	.L.str.11
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.12
	.xword	.L.str.13
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.14
	.xword	.L.str.15
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.16
	.xword	.L.str.17
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.18
	.xword	.L.str.19
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.20
	.xword	.L.str.21
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.22
	.xword	.L.str.23
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.24
	.xword	.L.str.25
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.26
	.xword	.L.str.27
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.28
	.xword	.L.str.29
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.30
	.xword	.L.str.31
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.32
	.xword	.L.str.33
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.34
	.xword	.L.str.35
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.36
	.xword	.L.str.37
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.38
	.xword	.L.str.39
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.40
	.xword	.L.str.41
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.42
	.xword	.L.str.43
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.44
	.xword	.L.str.45
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.46
	.xword	.L.str.47
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.48
	.xword	.L.str.49
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.50
	.xword	.L.str.51
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.52
	.xword	.L.str.53
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.54
	.xword	.L.str.55
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.56
	.xword	.L.str.57
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.58
	.xword	.L.str.59
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.60
	.xword	.L.str.61
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.62
	.xword	.L.str.63
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.64
	.xword	.L.str.65
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.66
	.xword	.L.str.67
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.68
	.xword	.L.str.69
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.70
	.xword	.L.str.71
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.72
	.xword	.L.str.73
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.74
	.xword	.L.str.75
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.76
	.xword	.L.str.77
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.78
	.xword	.L.str.79
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.80
	.xword	.L.str.81
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.82
	.xword	.L.str.83
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.84
	.xword	.L.str.85
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.86
	.xword	.L.str.87
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.88
	.xword	.L.str.89
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.90
	.xword	.L.str.91
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.92
	.xword	.L.str.93
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.94
	.xword	.L.str.95
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.96
	.xword	.L.str.97
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.98
	.xword	.L.str.99
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.100
	.xword	.L.str.101
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.102
	.xword	.L.str.103
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.104
	.xword	.L.str.105
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.106
	.xword	.L.str.107
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.108
	.xword	.L.str.109
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.110
	.xword	.L.str.111
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.112
	.xword	.L.str.113
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.114
	.xword	.L.str.115
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.116
	.xword	.L.str.117
	.byte	0                               // 0x0
	.zero	7
	.xword	.L.str.118
	.xword	.L.str.119
	.byte	0                               // 0x0
	.zero	7
	.size	pts_function_names, 1440

	.type	.L.str,@object                  // @.str
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str:
	.asciz	"pts_fn_Inner_constructor"
	.size	.L.str, 25

	.type	.L.str.1,@object                // @.str.1
.L.str.1:
	.asciz	"new Inner"
	.size	.L.str.1, 10

	.type	.L.str.2,@object                // @.str.2
.L.str.2:
	.asciz	"pts_fn_Map_of"
	.size	.L.str.2, 14

	.type	.L.str.3,@object                // @.str.3
.L.str.3:
	.asciz	"Map.of"
	.size	.L.str.3, 7

	.type	.L.str.4,@object                // @.str.4
.L.str.4:
	.asciz	"pts_fn_Payload_constructor"
	.size	.L.str.4, 27

	.type	.L.str.5,@object                // @.str.5
.L.str.5:
	.asciz	"new Payload"
	.size	.L.str.5, 12

	.type	.L.str.6,@object                // @.str.6
.L.str.6:
	.asciz	"pts_fn_Payload_whole"
	.size	.L.str.6, 21

	.type	.L.str.7,@object                // @.str.7
.L.str.7:
	.asciz	"Payload.whole"
	.size	.L.str.7, 14

	.type	.L.str.8,@object                // @.str.8
.L.str.8:
	.asciz	"pts_fn_check"
	.size	.L.str.8, 13

	.type	.L.str.9,@object                // @.str.9
.L.str.9:
	.asciz	"check"
	.size	.L.str.9, 6

	.type	.L.str.10,@object               // @.str.10
.L.str.10:
	.asciz	"pts_fn_getVariable"
	.size	.L.str.10, 19

	.type	.L.str.11,@object               // @.str.11
.L.str.11:
	.asciz	"getVariable"
	.size	.L.str.11, 12

	.type	.L.str.12,@object               // @.str.12
.L.str.12:
	.asciz	"pts_fn_parallel_Array_map"
	.size	.L.str.12, 26

	.type	.L.str.13,@object               // @.str.13
.L.str.13:
	.asciz	"Array.map"
	.size	.L.str.13, 10

	.type	.L.str.14,@object               // @.str.14
.L.str.14:
	.asciz	"pts_fn_parallel_ParallelArray_constructor"
	.size	.L.str.14, 42

	.type	.L.str.15,@object               // @.str.15
.L.str.15:
	.asciz	"new ParallelArray"
	.size	.L.str.15, 18

	.type	.L.str.16,@object               // @.str.16
.L.str.16:
	.asciz	"pts_fn_parallel_ParallelArray_count"
	.size	.L.str.16, 36

	.type	.L.str.17,@object               // @.str.17
.L.str.17:
	.asciz	"ParallelArray.count"
	.size	.L.str.17, 20

	.type	.L.str.18,@object               // @.str.18
.L.str.18:
	.asciz	"pts_fn_parallel_ParallelArray_every"
	.size	.L.str.18, 36

	.type	.L.str.19,@object               // @.str.19
.L.str.19:
	.asciz	"ParallelArray.every"
	.size	.L.str.19, 20

	.type	.L.str.20,@object               // @.str.20
.L.str.20:
	.asciz	"pts_fn_parallel_ParallelArray_filter"
	.size	.L.str.20, 37

	.type	.L.str.21,@object               // @.str.21
.L.str.21:
	.asciz	"ParallelArray.filter"
	.size	.L.str.21, 21

	.type	.L.str.22,@object               // @.str.22
.L.str.22:
	.asciz	"pts_fn_parallel_ParallelArray_find"
	.size	.L.str.22, 35

	.type	.L.str.23,@object               // @.str.23
.L.str.23:
	.asciz	"ParallelArray.find"
	.size	.L.str.23, 19

	.type	.L.str.24,@object               // @.str.24
.L.str.24:
	.asciz	"pts_fn_parallel_ParallelArray_findFound"
	.size	.L.str.24, 40

	.type	.L.str.25,@object               // @.str.25
.L.str.25:
	.asciz	"ParallelArray.findFound"
	.size	.L.str.25, 24

	.type	.L.str.26,@object               // @.str.26
.L.str.26:
	.asciz	"pts_fn_parallel_ParallelArray_forEach"
	.size	.L.str.26, 38

	.type	.L.str.27,@object               // @.str.27
.L.str.27:
	.asciz	"ParallelArray.forEach"
	.size	.L.str.27, 22

	.type	.L.str.28,@object               // @.str.28
.L.str.28:
	.asciz	"pts_fn_parallel_ParallelArray_map_number"
	.size	.L.str.28, 41

	.type	.L.str.29,@object               // @.str.29
.L.str.29:
	.asciz	"ParallelArray.map"
	.size	.L.str.29, 18

	.type	.L.str.30,@object               // @.str.30
.L.str.30:
	.asciz	"pts_fn_parallel_ParallelArray_max"
	.size	.L.str.30, 34

	.type	.L.str.31,@object               // @.str.31
.L.str.31:
	.asciz	"ParallelArray.max"
	.size	.L.str.31, 18

	.type	.L.str.32,@object               // @.str.32
.L.str.32:
	.asciz	"pts_fn_parallel_ParallelArray_min"
	.size	.L.str.32, 34

	.type	.L.str.33,@object               // @.str.33
.L.str.33:
	.asciz	"ParallelArray.min"
	.size	.L.str.33, 18

	.type	.L.str.34,@object               // @.str.34
.L.str.34:
	.asciz	"pts_fn_parallel_ParallelArray_reduce"
	.size	.L.str.34, 37

	.type	.L.str.35,@object               // @.str.35
.L.str.35:
	.asciz	"ParallelArray.reduce"
	.size	.L.str.35, 21

	.type	.L.str.36,@object               // @.str.36
.L.str.36:
	.asciz	"pts_fn_parallel_ParallelArray_reduceElements"
	.size	.L.str.36, 45

	.type	.L.str.37,@object               // @.str.37
.L.str.37:
	.asciz	"ParallelArray.reduceElements"
	.size	.L.str.37, 29

	.type	.L.str.38,@object               // @.str.38
.L.str.38:
	.asciz	"pts_fn_parallel_ParallelArray_some"
	.size	.L.str.38, 35

	.type	.L.str.39,@object               // @.str.39
.L.str.39:
	.asciz	"ParallelArray.some"
	.size	.L.str.39, 19

	.type	.L.str.40,@object               // @.str.40
.L.str.40:
	.asciz	"pts_fn_parallel_ParallelArray_sort"
	.size	.L.str.40, 35

	.type	.L.str.41,@object               // @.str.41
.L.str.41:
	.asciz	"ParallelArray.sort"
	.size	.L.str.41, 19

	.type	.L.str.42,@object               // @.str.42
.L.str.42:
	.asciz	"pts_fn_parallel_ParallelArray_sum"
	.size	.L.str.42, 34

	.type	.L.str.43,@object               // @.str.43
.L.str.43:
	.asciz	"ParallelArray.sum"
	.size	.L.str.43, 18

	.type	.L.str.44,@object               // @.str.44
.L.str.44:
	.asciz	"pts_fn_parallel_ParallelArray_toArray"
	.size	.L.str.44, 38

	.type	.L.str.45,@object               // @.str.45
.L.str.45:
	.asciz	"ParallelArray.toArray"
	.size	.L.str.45, 22

	.type	.L.str.46,@object               // @.str.46
.L.str.46:
	.asciz	"pts_fn_parallel_ParallelRange_constructor"
	.size	.L.str.46, 42

	.type	.L.str.47,@object               // @.str.47
.L.str.47:
	.asciz	"new ParallelRange"
	.size	.L.str.47, 18

	.type	.L.str.48,@object               // @.str.48
.L.str.48:
	.asciz	"pts_fn_parallel_ParallelRange_count"
	.size	.L.str.48, 36

	.type	.L.str.49,@object               // @.str.49
.L.str.49:
	.asciz	"ParallelRange.count"
	.size	.L.str.49, 20

	.type	.L.str.50,@object               // @.str.50
.L.str.50:
	.asciz	"pts_fn_parallel_ParallelRange_every"
	.size	.L.str.50, 36

	.type	.L.str.51,@object               // @.str.51
.L.str.51:
	.asciz	"ParallelRange.every"
	.size	.L.str.51, 20

	.type	.L.str.52,@object               // @.str.52
.L.str.52:
	.asciz	"pts_fn_parallel_ParallelRange_filter"
	.size	.L.str.52, 37

	.type	.L.str.53,@object               // @.str.53
.L.str.53:
	.asciz	"ParallelRange.filter"
	.size	.L.str.53, 21

	.type	.L.str.54,@object               // @.str.54
.L.str.54:
	.asciz	"pts_fn_parallel_ParallelRange_find"
	.size	.L.str.54, 35

	.type	.L.str.55,@object               // @.str.55
.L.str.55:
	.asciz	"ParallelRange.find"
	.size	.L.str.55, 19

	.type	.L.str.56,@object               // @.str.56
.L.str.56:
	.asciz	"pts_fn_parallel_ParallelRange_findFound"
	.size	.L.str.56, 40

	.type	.L.str.57,@object               // @.str.57
.L.str.57:
	.asciz	"ParallelRange.findFound"
	.size	.L.str.57, 24

	.type	.L.str.58,@object               // @.str.58
.L.str.58:
	.asciz	"pts_fn_parallel_ParallelRange_forEach"
	.size	.L.str.58, 38

	.type	.L.str.59,@object               // @.str.59
.L.str.59:
	.asciz	"ParallelRange.forEach"
	.size	.L.str.59, 22

	.type	.L.str.60,@object               // @.str.60
.L.str.60:
	.asciz	"pts_fn_parallel_ParallelRange_max"
	.size	.L.str.60, 34

	.type	.L.str.61,@object               // @.str.61
.L.str.61:
	.asciz	"ParallelRange.max"
	.size	.L.str.61, 18

	.type	.L.str.62,@object               // @.str.62
.L.str.62:
	.asciz	"pts_fn_parallel_ParallelRange_min"
	.size	.L.str.62, 34

	.type	.L.str.63,@object               // @.str.63
.L.str.63:
	.asciz	"ParallelRange.min"
	.size	.L.str.63, 18

	.type	.L.str.64,@object               // @.str.64
.L.str.64:
	.asciz	"pts_fn_parallel_ParallelRange_reduce"
	.size	.L.str.64, 37

	.type	.L.str.65,@object               // @.str.65
.L.str.65:
	.asciz	"ParallelRange.reduce"
	.size	.L.str.65, 21

	.type	.L.str.66,@object               // @.str.66
.L.str.66:
	.asciz	"pts_fn_parallel_ParallelRange_some"
	.size	.L.str.66, 35

	.type	.L.str.67,@object               // @.str.67
.L.str.67:
	.asciz	"ParallelRange.some"
	.size	.L.str.67, 19

	.type	.L.str.68,@object               // @.str.68
.L.str.68:
	.asciz	"pts_fn_parallel_ParallelRange_sort"
	.size	.L.str.68, 35

	.type	.L.str.69,@object               // @.str.69
.L.str.69:
	.asciz	"ParallelRange.sort"
	.size	.L.str.69, 19

	.type	.L.str.70,@object               // @.str.70
.L.str.70:
	.asciz	"pts_fn_parallel_ParallelRange_sum"
	.size	.L.str.70, 34

	.type	.L.str.71,@object               // @.str.71
.L.str.71:
	.asciz	"ParallelRange.sum"
	.size	.L.str.71, 18

	.type	.L.str.72,@object               // @.str.72
.L.str.72:
	.asciz	"pts_fn_parallel_ParallelRange_toArray"
	.size	.L.str.72, 38

	.type	.L.str.73,@object               // @.str.73
.L.str.73:
	.asciz	"ParallelRange.toArray"
	.size	.L.str.73, 22

	.type	.L.str.74,@object               // @.str.74
.L.str.74:
	.asciz	"pts_fn_parallel_Range__u0040_u0040iterator_"
	.size	.L.str.74, 44

	.type	.L.str.75,@object               // @.str.75
.L.str.75:
	.asciz	"Range.[Symbol.iterator]"
	.size	.L.str.75, 24

	.type	.L.str.76,@object               // @.str.76
.L.str.76:
	.asciz	"pts_fn_parallel_Range_constructor"
	.size	.L.str.76, 34

	.type	.L.str.77,@object               // @.str.77
.L.str.77:
	.asciz	"new Range"
	.size	.L.str.77, 10

	.type	.L.str.78,@object               // @.str.78
.L.str.78:
	.asciz	"pts_fn_parallel_Range_get_length"
	.size	.L.str.78, 33

	.type	.L.str.79,@object               // @.str.79
.L.str.79:
	.asciz	"Range.length"
	.size	.L.str.79, 13

	.type	.L.str.80,@object               // @.str.80
.L.str.80:
	.asciz	"pts_fn_parallel_Range_get_par"
	.size	.L.str.80, 30

	.type	.L.str.81,@object               // @.str.81
.L.str.81:
	.asciz	"Range.par"
	.size	.L.str.81, 10

	.type	.L.str.82,@object               // @.str.82
.L.str.82:
	.asciz	"pts_fn_parallel_Range_toArray"
	.size	.L.str.82, 30

	.type	.L.str.83,@object               // @.str.83
.L.str.83:
	.asciz	"Range.toArray"
	.size	.L.str.83, 14

	.type	.L.str.84,@object               // @.str.84
.L.str.84:
	.asciz	"pts_fn_parallel_compareNumbers"
	.size	.L.str.84, 31

	.type	.L.str.85,@object               // @.str.85
.L.str.85:
	.asciz	"compareNumbers"
	.size	.L.str.85, 15

	.type	.L.str.86,@object               // @.str.86
.L.str.86:
	.asciz	"pts_fn_parallel_compareStrings"
	.size	.L.str.86, 31

	.type	.L.str.87,@object               // @.str.87
.L.str.87:
	.asciz	"compareStrings"
	.size	.L.str.87, 15

	.type	.L.str.88,@object               // @.str.88
.L.str.88:
	.asciz	"pts_fn_parallel_join_undefined_undefined"
	.size	.L.str.88, 41

	.type	.L.str.89,@object               // @.str.89
.L.str.89:
	.asciz	"join"
	.size	.L.str.89, 5

	.type	.L.str.90,@object               // @.str.90
.L.str.90:
	.asciz	"pts_fn_parallel_mergeRuns_number_number_array"
	.size	.L.str.90, 46

	.type	.L.str.91,@object               // @.str.91
.L.str.91:
	.asciz	"mergeRuns"
	.size	.L.str.91, 10

	.type	.L.str.92,@object               // @.str.92
.L.str.92:
	.asciz	"pts_fn_parallel_permute_number"
	.size	.L.str.92, 31

	.type	.L.str.93,@object               // @.str.93
.L.str.93:
	.asciz	"permute"
	.size	.L.str.93, 8

	.type	.L.str.94,@object               // @.str.94
.L.str.94:
	.asciz	"pts_fn_parallel_range"
	.size	.L.str.94, 22

	.type	.L.str.95,@object               // @.str.95
.L.str.95:
	.asciz	"range"
	.size	.L.str.95, 6

	.type	.L.str.96,@object               // @.str.96
.L.str.96:
	.asciz	"pts_fn_parallel_search"
	.size	.L.str.96, 23

	.type	.L.str.97,@object               // @.str.97
.L.str.97:
	.asciz	"search"
	.size	.L.str.97, 7

	.type	.L.str.98,@object               // @.str.98
.L.str.98:
	.asciz	"pts_fn_parallel_sortInPlace_number"
	.size	.L.str.98, 35

	.type	.L.str.99,@object               // @.str.99
.L.str.99:
	.asciz	"sortInPlace"
	.size	.L.str.99, 12

	.type	.L.str.100,@object              // @.str.100
.L.str.100:
	.asciz	"pts_fn_parallel_sortRun_number_number_array"
	.size	.L.str.100, 44

	.type	.L.str.101,@object              // @.str.101
.L.str.101:
	.asciz	"sortRun"
	.size	.L.str.101, 8

	.type	.L.str.102,@object              // @.str.102
.L.str.102:
	.asciz	"pts_fn_setVariable"
	.size	.L.str.102, 19

	.type	.L.str.103,@object              // @.str.103
.L.str.103:
	.asciz	"setVariable"
	.size	.L.str.103, 12

	.type	.L.str.104,@object              // @.str.104
.L.str.104:
	.asciz	"pts_fn_sync_AtomicInt_add"
	.size	.L.str.104, 26

	.type	.L.str.105,@object              // @.str.105
.L.str.105:
	.asciz	"AtomicInt.add"
	.size	.L.str.105, 14

	.type	.L.str.106,@object              // @.str.106
.L.str.106:
	.asciz	"pts_fn_sync_AtomicInt_compareExchange"
	.size	.L.str.106, 38

	.type	.L.str.107,@object              // @.str.107
.L.str.107:
	.asciz	"AtomicInt.compareExchange"
	.size	.L.str.107, 26

	.type	.L.str.108,@object              // @.str.108
.L.str.108:
	.asciz	"pts_fn_sync_AtomicInt_constructor"
	.size	.L.str.108, 34

	.type	.L.str.109,@object              // @.str.109
.L.str.109:
	.asciz	"new AtomicInt"
	.size	.L.str.109, 14

	.type	.L.str.110,@object              // @.str.110
.L.str.110:
	.asciz	"pts_fn_sync_AtomicInt_load"
	.size	.L.str.110, 27

	.type	.L.str.111,@object              // @.str.111
.L.str.111:
	.asciz	"AtomicInt.load"
	.size	.L.str.111, 15

	.type	.L.str.112,@object              // @.str.112
.L.str.112:
	.asciz	"pts_fn_sync_AtomicInt_store"
	.size	.L.str.112, 28

	.type	.L.str.113,@object              // @.str.113
.L.str.113:
	.asciz	"AtomicInt.store"
	.size	.L.str.113, 16

	.type	.L.str.114,@object              // @.str.114
.L.str.114:
	.asciz	"pts_fn_sync_Once_constructor"
	.size	.L.str.114, 29

	.type	.L.str.115,@object              // @.str.115
.L.str.115:
	.asciz	"new Once"
	.size	.L.str.115, 9

	.type	.L.str.116,@object              // @.str.116
.L.str.116:
	.asciz	"pts_fn_sync_Once_get_done"
	.size	.L.str.116, 26

	.type	.L.str.117,@object              // @.str.117
.L.str.117:
	.asciz	"Once.done"
	.size	.L.str.117, 10

	.type	.L.str.118,@object              // @.str.118
.L.str.118:
	.asciz	"pts_fn_sync_Once_run"
	.size	.L.str.118, 21

	.type	.L.str.119,@object              // @.str.119
.L.str.119:
	.asciz	"Once.run"
	.size	.L.str.119, 9

	.type	pts_global_parallel_Range_class_ready,@object // @pts_global_parallel_Range_class_ready
	.local	pts_global_parallel_Range_class_ready
	.comm	pts_global_parallel_Range_class_ready,1,1
	.type	pts_global_parallel_ParallelRange_class_ready,@object // @pts_global_parallel_ParallelRange_class_ready
	.local	pts_global_parallel_ParallelRange_class_ready
	.comm	pts_global_parallel_ParallelRange_class_ready,1,1
	.type	pts_global_parallel_SEQUENTIAL_SORT,@object // @pts_global_parallel_SEQUENTIAL_SORT
	.local	pts_global_parallel_SEQUENTIAL_SORT
	.comm	pts_global_parallel_SEQUENTIAL_SORT,8,8
	.type	pts_global_parallel_SEQUENTIAL_SORT_ready,@object // @pts_global_parallel_SEQUENTIAL_SORT_ready
	.local	pts_global_parallel_SEQUENTIAL_SORT_ready
	.comm	pts_global_parallel_SEQUENTIAL_SORT_ready,1,1
	.type	pts_global_parallel_PIECES_PER_THREAD,@object // @pts_global_parallel_PIECES_PER_THREAD
	.local	pts_global_parallel_PIECES_PER_THREAD
	.comm	pts_global_parallel_PIECES_PER_THREAD,8,8
	.type	pts_global_parallel_PIECES_PER_THREAD_ready,@object // @pts_global_parallel_PIECES_PER_THREAD_ready
	.local	pts_global_parallel_PIECES_PER_THREAD_ready
	.comm	pts_global_parallel_PIECES_PER_THREAD_ready,1,1
	.type	pts_str_1_storage,@object       // @pts_str_1_storage
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_str_1_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	4                               // 0x4
	.word	4                               // 0x4
	.zero	4
	.xword	pts_str_1_bytes
	.size	pts_str_1_storage, 32

	.type	pts_str_2_storage,@object       // @pts_str_2_storage
	.p2align	3, 0x0
pts_str_2_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	3                               // 0x3
	.word	3                               // 0x3
	.zero	4
	.xword	pts_str_2_bytes
	.size	pts_str_2_storage, 32

	.type	pts_str_3_storage,@object       // @pts_str_3_storage
	.p2align	3, 0x0
pts_str_3_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	3                               // 0x3
	.word	3                               // 0x3
	.zero	4
	.xword	pts_str_3_bytes
	.size	pts_str_3_storage, 32

	.type	pts_str_4_storage,@object       // @pts_str_4_storage
	.p2align	3, 0x0
pts_str_4_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	5                               // 0x5
	.word	5                               // 0x5
	.zero	4
	.xword	pts_str_4_bytes
	.size	pts_str_4_storage, 32

	.type	.Lconstinit,@object             // @constinit
	.p2align	3, 0x0
.Lconstinit:
	.xword	pts_str_1_storage
	.xword	pts_str_2_storage
	.xword	pts_str_3_storage
	.xword	pts_str_4_storage
	.size	.Lconstinit, 32

	.type	pts_global_LABELS,@object       // @pts_global_LABELS
	.local	pts_global_LABELS
	.comm	pts_global_LABELS,8,8
	.type	pts_global_LABELS_ready,@object // @pts_global_LABELS_ready
	.local	pts_global_LABELS_ready
	.comm	pts_global_LABELS_ready,1,1
	.type	pts_global_Inner_class_ready,@object // @pts_global_Inner_class_ready
	.local	pts_global_Inner_class_ready
	.comm	pts_global_Inner_class_ready,1,1
	.type	pts_global_Payload_class_ready,@object // @pts_global_Payload_class_ready
	.local	pts_global_Payload_class_ready
	.comm	pts_global_Payload_class_ready,1,1
	.type	pts_type_object1,@object        // @pts_type_object1
	.p2align	3, 0x0
pts_type_object1:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.120
	.xword	0
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_fields_object1
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_object1, 136

	.type	pts_type_Payload,@object        // @pts_type_Payload
	.p2align	3, 0x0
pts_type_Payload:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	31525197391593473               // 0x70000000000001
	.xword	.L.str.122
	.xword	0
	.word	96                              // 0x60
	.word	11                              // 0xb
	.xword	pts_fields_Payload
	.word	1                               // 0x1
	.zero	4
	.xword	pts_methods_Payload
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_Payload, 136

	.type	pts_global_slot,@object         // @pts_global_slot
	.local	pts_global_slot
	.comm	pts_global_slot,8,8
	.type	pts_global_slot_ready,@object   // @pts_global_slot_ready
	.local	pts_global_slot_ready
	.comm	pts_global_slot_ready,1,1
	.type	pts_type_array_1,@object        // @pts_type_array_1
	.p2align	3, 0x0
pts_type_array_1:
	.word	5                               // 0x5
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.144
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	5                               // 0x5
	.word	0                               // 0x0
	.xword	pts_check_13
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_array_1, 136

	.type	pts_global_elements,@object     // @pts_global_elements
	.local	pts_global_elements
	.comm	pts_global_elements,8,8
	.type	pts_global_elements_ready,@object // @pts_global_elements_ready
	.local	pts_global_elements_ready
	.comm	pts_global_elements_ready,1,1
	.type	pts_type_array_2,@object        // @pts_type_array_2
	.p2align	3, 0x0
pts_type_array_2:
	.word	5                               // 0x5
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.144
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	5                               // 0x5
	.word	0                               // 0x0
	.xword	pts_check_14
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_array_2, 136

	.type	pts_type_tuple1,@object         // @pts_type_tuple1
	.p2align	3, 0x0
pts_type_tuple1:
	.word	9                               // 0x9
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.144
	.xword	0
	.word	24                              // 0x18
	.word	2                               // 0x2
	.xword	pts_fields_tuple1
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_tuple1, 136

	.type	pts_global_entries,@object      // @pts_global_entries
	.local	pts_global_entries
	.comm	pts_global_entries,8,8
	.type	pts_global_entries_ready,@object // @pts_global_entries_ready
	.local	pts_global_entries_ready
	.comm	pts_global_entries_ready,1,1
	.type	pts_global_variable,@object     // @pts_global_variable
	.local	pts_global_variable
	.comm	pts_global_variable,8,8
	.type	pts_global_variable_ready,@object // @pts_global_variable_ready
	.local	pts_global_variable_ready
	.comm	pts_global_variable_ready,1,1
	.type	pts_type_sync_AtomicInt,@object // @pts_type_sync_AtomicInt
	.p2align	3, 0x0
pts_type_sync_AtomicInt:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.149
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	4                               // 0x4
	.zero	4
	.xword	pts_methods_sync_AtomicInt
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_sync_AtomicInt, 136

	.type	pts_global_bad,@object          // @pts_global_bad
	.local	pts_global_bad
	.comm	pts_global_bad,8,8
	.type	pts_global_bad_ready,@object    // @pts_global_bad_ready
	.local	pts_global_bad_ready
	.comm	pts_global_bad_ready,1,1
	.type	pts_str_5_storage,@object       // @pts_str_5_storage
	.p2align	3, 0x0
pts_str_5_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	24                              // 0x18
	.word	24                              // 0x18
	.zero	4
	.xword	pts_str_5_bytes
	.size	pts_str_5_storage, 32

	.type	pts_str_1_bytes,@object         // @pts_str_1_bytes
	.section	.rodata,"a",@progbits
pts_str_1_bytes:
	.asciz	"zero"
	.size	pts_str_1_bytes, 5

	.type	pts_str_2_bytes,@object         // @pts_str_2_bytes
pts_str_2_bytes:
	.asciz	"one"
	.size	pts_str_2_bytes, 4

	.type	pts_str_3_bytes,@object         // @pts_str_3_bytes
pts_str_3_bytes:
	.asciz	"two"
	.size	pts_str_3_bytes, 4

	.type	pts_str_4_bytes,@object         // @pts_str_4_bytes
pts_str_4_bytes:
	.asciz	"three"
	.size	pts_str_4_bytes, 6

	.type	.L.str.120,@object              // @.str.120
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.120:
	.asciz	"Object"
	.size	.L.str.120, 7

	.type	pts_fields_object1,@object      // @pts_fields_object1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_fields_object1:
	.xword	.L.str.121
	.word	8                               // 0x8
	.word	5                               // 0x5
	.xword	pts_check_13
	.size	pts_fields_object1, 24

	.type	.L.str.121,@object              // @.str.121
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.121:
	.asciz	"current"
	.size	.L.str.121, 8

	.type	pts_check_13,@object            // @pts_check_13
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_13:
	.word	8                               // 0x8
	.word	5                               // 0x5
	.xword	.L.str.122
	.xword	pts_type_Payload
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_13, 88

	.type	.L.str.122,@object              // @.str.122
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.122:
	.asciz	"Payload"
	.size	.L.str.122, 8

	.type	pts_fields_Payload,@object      // @pts_fields_Payload
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_fields_Payload:
	.xword	.L.str.123
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.124
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.125
	.word	24                              // 0x18
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.126
	.word	32                              // 0x20
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.127
	.word	40                              // 0x28
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.128
	.word	48                              // 0x30
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.129
	.word	56                              // 0x38
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.130
	.word	64                              // 0x40
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.131
	.word	72                              // 0x48
	.word	3                               // 0x3
	.xword	pts_check_10
	.xword	.L.str.132
	.word	80                              // 0x50
	.word	5                               // 0x5
	.xword	pts_check_11
	.xword	.L.str.133
	.word	88                              // 0x58
	.word	5                               // 0x5
	.xword	pts_check_12
	.size	pts_fields_Payload, 264

	.type	pts_methods_Payload,@object     // @pts_methods_Payload
	.p2align	3, 0x0
pts_methods_Payload:
	.xword	.L.str.139
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_Payload_whole
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_Payload_whole
	.xword	pts_check_47
	.size	pts_methods_Payload, 56

	.type	.L.str.123,@object              // @.str.123
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.123:
	.asciz	"a"
	.size	.L.str.123, 2

	.type	pts_check_2,@object             // @pts_check_2
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_2:
	.word	2                               // 0x2
	.word	1                               // 0x1
	.xword	.L.str.134
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_2, 88

	.type	.L.str.124,@object              // @.str.124
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.124:
	.asciz	"b"
	.size	.L.str.124, 2

	.type	.L.str.125,@object              // @.str.125
.L.str.125:
	.asciz	"c"
	.size	.L.str.125, 2

	.type	.L.str.126,@object              // @.str.126
.L.str.126:
	.asciz	"d"
	.size	.L.str.126, 2

	.type	.L.str.127,@object              // @.str.127
.L.str.127:
	.asciz	"e"
	.size	.L.str.127, 2

	.type	.L.str.128,@object              // @.str.128
.L.str.128:
	.asciz	"f"
	.size	.L.str.128, 2

	.type	.L.str.129,@object              // @.str.129
.L.str.129:
	.asciz	"g"
	.size	.L.str.129, 2

	.type	.L.str.130,@object              // @.str.130
.L.str.130:
	.asciz	"h"
	.size	.L.str.130, 2

	.type	.L.str.131,@object              // @.str.131
.L.str.131:
	.asciz	"label"
	.size	.L.str.131, 6

	.type	pts_check_10,@object            // @pts_check_10
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_10:
	.word	4                               // 0x4
	.word	3                               // 0x3
	.xword	.L.str.135
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_10, 88

	.type	.L.str.132,@object              // @.str.132
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.132:
	.asciz	"inner"
	.size	.L.str.132, 6

	.type	pts_check_11,@object            // @pts_check_11
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_11:
	.word	8                               // 0x8
	.word	5                               // 0x5
	.xword	.L.str.136
	.xword	pts_type_Inner
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_11, 88

	.type	.L.str.133,@object              // @.str.133
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.133:
	.asciz	"twice"
	.size	.L.str.133, 6

	.type	pts_check_12,@object            // @pts_check_12
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_12:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.138
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_12
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_12, 88

	.type	.L.str.134,@object              // @.str.134
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.134:
	.asciz	"number"
	.size	.L.str.134, 7

	.type	.L.str.135,@object              // @.str.135
.L.str.135:
	.asciz	"string"
	.size	.L.str.135, 7

	.type	.L.str.136,@object              // @.str.136
.L.str.136:
	.asciz	"Inner"
	.size	.L.str.136, 6

	.type	pts_type_Inner,@object          // @pts_type_Inner
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_Inner:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.136
	.xword	0
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_fields_Inner
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_Inner, 136

	.type	pts_fields_Inner,@object        // @pts_fields_Inner
	.p2align	3, 0x0
pts_fields_Inner:
	.xword	.L.str.137
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_2
	.size	pts_fields_Inner, 24

	.type	.L.str.137,@object              // @.str.137
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.137:
	.asciz	"n"
	.size	.L.str.137, 2

	.type	.L.str.138,@object              // @.str.138
.L.str.138:
	.asciz	"() => number"
	.size	.L.str.138, 13

	.type	pts_type_adapter_12,@object     // @pts_type_adapter_12
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_12:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_12
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_12, 136

	.type	.L.str.139,@object              // @.str.139
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.139:
	.asciz	"whole"
	.size	.L.str.139, 6

	.type	pts_check_47,@object            // @pts_check_47
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_47:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.141
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_47
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_47, 88

	.type	.L.str.140,@object              // @.str.140
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.140:
	.asciz	"LABELS"
	.size	.L.str.140, 7

	.type	.L.str.141,@object              // @.str.141
.L.str.141:
	.asciz	"() => boolean"
	.size	.L.str.141, 14

	.type	pts_type_adapter_47,@object     // @pts_type_adapter_47
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_47:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_47
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_47, 136

	.type	.L.str.142,@object              // @.str.142
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.142:
	.asciz	"boolean"
	.size	.L.str.142, 8

	.type	pts_str_6_storage,@object       // @pts_str_6_storage
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_str_6_storage:
	.xword	pts_string_type
	.word	1                               // 0x1
	.word	0                               // 0x0
	.word	0                               // 0x0
	.zero	4
	.xword	.L.str.143
	.size	pts_str_6_storage, 32

	.type	pts_type_closure_Payload_constructor_arrow,@object // @pts_type_closure_Payload_constructor_arrow
	.p2align	3, 0x0
pts_type_closure_Payload_constructor_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_Payload_constructor_arrow
	.xword	pts_check_12
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_Payload_constructor_arrow, 136

	.type	.L.str.143,@object              // @.str.143
	.section	.rodata,"a",@progbits
.L.str.143:
	.zero	1
	.size	.L.str.143, 1

	.type	.L.str.144,@object              // @.str.144
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.144:
	.asciz	"Array"
	.size	.L.str.144, 6

	.type	pts_type_map_1,@object          // @pts_type_map_1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_map_1:
	.word	7                               // 0x7
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.145
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	5                               // 0x5
	.word	1                               // 0x1
	.xword	pts_check_13
	.xword	pts_check_2
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_map_1, 136

	.type	.L.str.145,@object              // @.str.145
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.145:
	.asciz	"Map"
	.size	.L.str.145, 4

	.type	pts_check_14,@object            // @pts_check_14
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_14:
	.word	10                              // 0xa
	.word	5                               // 0x5
	.xword	.L.str.146
	.xword	pts_type_tuple1
	.xword	0
	.word	2                               // 0x2
	.zero	4
	.xword	pts_check_14_properties
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_14, 88

	.type	.L.str.146,@object              // @.str.146
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.146:
	.asciz	"[number, Payload]"
	.size	.L.str.146, 18

	.type	pts_check_14_properties,@object // @pts_check_14_properties
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_14_properties:
	.xword	.L.str.147
	.xword	pts_check_2
	.byte	0                               // 0x0
	.zero	3
	.word	8                               // 0x8
	.xword	.L.str.148
	.xword	pts_check_13
	.byte	0                               // 0x0
	.zero	3
	.word	16                              // 0x10
	.size	pts_check_14_properties, 48

	.type	.L.str.147,@object              // @.str.147
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.147:
	.asciz	"0"
	.size	.L.str.147, 2

	.type	.L.str.148,@object              // @.str.148
.L.str.148:
	.asciz	"1"
	.size	.L.str.148, 2

	.type	pts_fields_tuple1,@object       // @pts_fields_tuple1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_fields_tuple1:
	.xword	.L.str.147
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.148
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	pts_check_13
	.size	pts_fields_tuple1, 48

	.type	.L.str.149,@object              // @.str.149
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.149:
	.asciz	"AtomicInt"
	.size	.L.str.149, 10

	.type	pts_methods_sync_AtomicInt,@object // @pts_methods_sync_AtomicInt
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_methods_sync_AtomicInt:
	.xword	.L.str.150
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_sync_AtomicInt_load
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_sync_AtomicInt_load
	.xword	pts_check_31
	.xword	.L.str.151
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_sync_AtomicInt_store
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_sync_AtomicInt_store
	.xword	pts_check_32
	.xword	.L.str.152
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_sync_AtomicInt_add
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_sync_AtomicInt_add
	.xword	pts_check_33
	.xword	.L.str.153
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_sync_AtomicInt_compareExchange
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_sync_AtomicInt_compareExchange
	.xword	pts_check_34
	.size	pts_methods_sync_AtomicInt, 224

	.type	.L.str.150,@object              // @.str.150
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.150:
	.asciz	"load"
	.size	.L.str.150, 5

	.type	pts_check_31,@object            // @pts_check_31
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_31:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.154
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_31
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_31, 88

	.type	.L.str.151,@object              // @.str.151
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.151:
	.asciz	"store"
	.size	.L.str.151, 6

	.type	pts_check_32,@object            // @pts_check_32
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_32:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.157
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_32
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_32, 88

	.type	.L.str.152,@object              // @.str.152
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.152:
	.asciz	"add"
	.size	.L.str.152, 4

	.type	pts_check_33,@object            // @pts_check_33
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_33:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.158
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_33
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_33, 88

	.type	.L.str.153,@object              // @.str.153
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.153:
	.asciz	"compareExchange"
	.size	.L.str.153, 16

	.type	pts_check_34,@object            // @pts_check_34
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_34:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.159
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_34
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_34, 88

	.type	.L.str.154,@object              // @.str.154
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.154:
	.asciz	"() => i64"
	.size	.L.str.154, 10

	.type	pts_type_adapter_31,@object     // @pts_type_adapter_31
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_31:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_31
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_31, 136

	.type	.L.str.155,@object              // @.str.155
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.155:
	.asciz	"i64"
	.size	.L.str.155, 4

	.type	.L.str.156,@object              // @.str.156
.L.str.156:
	.asciz	"#cell"
	.size	.L.str.156, 6

	.type	.L.str.157,@object              // @.str.157
.L.str.157:
	.asciz	"(i64) => void"
	.size	.L.str.157, 14

	.type	pts_type_adapter_32,@object     // @pts_type_adapter_32
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_32:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_32
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_32, 136

	.type	.L.str.158,@object              // @.str.158
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.158:
	.asciz	"(i64) => i64"
	.size	.L.str.158, 13

	.type	pts_type_adapter_33,@object     // @pts_type_adapter_33
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_33:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_33
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_33, 136

	.type	.L.str.159,@object              // @.str.159
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.159:
	.asciz	"(i64, i64) => i64"
	.size	.L.str.159, 18

	.type	pts_type_adapter_34,@object     // @pts_type_adapter_34
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_34:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_34
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_34, 136

	.type	.L.str.160,@object              // @.str.160
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.160:
	.asciz	"Range"
	.size	.L.str.160, 6

	.type	pts_type_parallel_Range,@object // @pts_type_parallel_Range
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_parallel_Range:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.160
	.xword	0
	.word	24                              // 0x18
	.word	2                               // 0x2
	.xword	pts_fields_parallel_Range
	.word	4                               // 0x4
	.zero	4
	.xword	pts_methods_parallel_Range
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_parallel_Range, 136

	.type	pts_fields_parallel_Range,@object // @pts_fields_parallel_Range
	.p2align	3, 0x0
pts_fields_parallel_Range:
	.xword	.L.str.161
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.162
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_check_2
	.size	pts_fields_parallel_Range, 48

	.type	pts_methods_parallel_Range,@object // @pts_methods_parallel_Range
	.p2align	3, 0x0
pts_methods_parallel_Range:
	.xword	.L.str.163
	.word	1                               // 0x1
	.zero	4
	.xword	pts_entry_parallel_Range_get_length
	.word	1                               // 0x1
	.zero	4
	.xword	pts_check_2
	.xword	0
	.xword	0
	.xword	.L.str.164
	.word	1                               // 0x1
	.zero	4
	.xword	pts_entry_parallel_Range_get_par
	.word	5                               // 0x5
	.zero	4
	.xword	pts_check_9
	.xword	0
	.xword	0
	.xword	.L.str.165
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_Range_toArray
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_Range_toArray
	.xword	pts_check_36
	.xword	.L.str.166
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_Range__u0040_u0040iterator_
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_Range__u0040_u0040iterator_
	.xword	pts_check_37
	.size	pts_methods_parallel_Range, 224

	.type	.L.str.161,@object              // @.str.161
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.161:
	.asciz	"start"
	.size	.L.str.161, 6

	.type	.L.str.162,@object              // @.str.162
.L.str.162:
	.asciz	"end"
	.size	.L.str.162, 4

	.type	.L.str.163,@object              // @.str.163
.L.str.163:
	.asciz	"length"
	.size	.L.str.163, 7

	.type	.L.str.164,@object              // @.str.164
.L.str.164:
	.asciz	"par"
	.size	.L.str.164, 4

	.type	pts_check_9,@object             // @pts_check_9
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_9:
	.word	8                               // 0x8
	.word	5                               // 0x5
	.xword	.L.str.167
	.xword	pts_type_parallel_ParallelRange
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_9, 88

	.type	.L.str.165,@object              // @.str.165
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.165:
	.asciz	"toArray"
	.size	.L.str.165, 8

	.type	pts_check_36,@object            // @pts_check_36
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_36:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.225
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_36
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_36, 88

	.type	.L.str.166,@object              // @.str.166
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.166:
	.asciz	"@@iterator"
	.size	.L.str.166, 11

	.type	pts_check_37,@object            // @pts_check_37
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_37:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.226
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_37
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_37, 88

	.type	.L.str.167,@object              // @.str.167
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.167:
	.asciz	"ParallelRange"
	.size	.L.str.167, 14

	.type	pts_type_parallel_ParallelRange,@object // @pts_type_parallel_ParallelRange
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_parallel_ParallelRange:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.167
	.xword	0
	.word	24                              // 0x18
	.word	2                               // 0x2
	.xword	pts_fields_parallel_ParallelRange
	.word	13                              // 0xd
	.zero	4
	.xword	pts_methods_parallel_ParallelRange
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_parallel_ParallelRange, 136

	.type	pts_fields_parallel_ParallelRange,@object // @pts_fields_parallel_ParallelRange
	.p2align	3, 0x0
pts_fields_parallel_ParallelRange:
	.xword	.L.str.161
	.word	8                               // 0x8
	.word	1                               // 0x1
	.xword	pts_check_2
	.xword	.L.str.163
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_check_2
	.size	pts_fields_parallel_ParallelRange, 48

	.type	pts_methods_parallel_ParallelRange,@object // @pts_methods_parallel_ParallelRange
	.p2align	3, 0x0
pts_methods_parallel_ParallelRange:
	.xword	.L.str.168
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_forEach
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_forEach
	.xword	pts_check_39
	.xword	.L.str.169
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_filter
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_filter
	.xword	pts_check_40
	.xword	.L.str.170
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_reduce
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_reduce
	.xword	pts_check_41
	.xword	.L.str.171
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_some
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_some
	.xword	pts_check_42
	.xword	.L.str.172
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_every
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_every
	.xword	pts_check_42
	.xword	.L.str.173
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_find
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_find
	.xword	pts_check_43
	.xword	.L.str.174
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_count
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_count
	.xword	pts_check_44
	.xword	.L.str.175
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_sum
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_sum
	.xword	pts_check_12
	.xword	.L.str.176
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_min
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_min
	.xword	pts_check_12
	.xword	.L.str.177
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_max
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_max
	.xword	pts_check_12
	.xword	.L.str.178
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_sort
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_sort
	.xword	pts_check_45
	.xword	.L.str.165
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_toArray
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_toArray
	.xword	pts_check_36
	.xword	.L.str.179
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelRange_findFound
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelRange_findFound
	.xword	pts_check_46
	.size	pts_methods_parallel_ParallelRange, 728

	.type	.L.str.168,@object              // @.str.168
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.168:
	.asciz	"forEach"
	.size	.L.str.168, 8

	.type	pts_check_39,@object            // @pts_check_39
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_39:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.182
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_39
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_39, 88

	.type	.L.str.169,@object              // @.str.169
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.169:
	.asciz	"filter"
	.size	.L.str.169, 7

	.type	pts_check_40,@object            // @pts_check_40
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_40:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.189
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_40
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_40, 88

	.type	.L.str.170,@object              // @.str.170
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.170:
	.asciz	"reduce"
	.size	.L.str.170, 7

	.type	pts_check_41,@object            // @pts_check_41
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_41:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.192
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_41
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_41, 88

	.type	.L.str.171,@object              // @.str.171
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.171:
	.asciz	"some"
	.size	.L.str.171, 5

	.type	pts_check_42,@object            // @pts_check_42
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_42:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.199
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_42
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_42, 88

	.type	.L.str.172,@object              // @.str.172
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.172:
	.asciz	"every"
	.size	.L.str.172, 6

	.type	.L.str.173,@object              // @.str.173
.L.str.173:
	.asciz	"find"
	.size	.L.str.173, 5

	.type	pts_check_43,@object            // @pts_check_43
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_43:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.201
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_43
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_43, 88

	.type	.L.str.174,@object              // @.str.174
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.174:
	.asciz	"count"
	.size	.L.str.174, 6

	.type	pts_check_44,@object            // @pts_check_44
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_44:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.202
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_44
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_44, 88

	.type	.L.str.175,@object              // @.str.175
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.175:
	.asciz	"sum"
	.size	.L.str.175, 4

	.type	.L.str.176,@object              // @.str.176
.L.str.176:
	.asciz	"min"
	.size	.L.str.176, 4

	.type	.L.str.177,@object              // @.str.177
.L.str.177:
	.asciz	"max"
	.size	.L.str.177, 4

	.type	.L.str.178,@object              // @.str.178
.L.str.178:
	.asciz	"sort"
	.size	.L.str.178, 5

	.type	pts_check_45,@object            // @pts_check_45
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_45:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.223
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_45
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_45, 88

	.type	.L.str.179,@object              // @.str.179
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.179:
	.asciz	"findFound"
	.size	.L.str.179, 10

	.type	pts_check_46,@object            // @pts_check_46
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_46:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.224
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_46
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_46, 88

	.type	pts_type_closure_parallel_ParallelRange_forEach_arrow,@object // @pts_type_closure_parallel_ParallelRange_forEach_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_forEach_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_forEach_arrow
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_forEach_arrow, 136

	.type	pts_check_15,@object            // @pts_check_15
	.p2align	3, 0x0
pts_check_15:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.180
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_15
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_15, 88

	.type	.L.str.180,@object              // @.str.180
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.180:
	.asciz	"(number, number) => void"
	.size	.L.str.180, 25

	.type	pts_type_adapter_15,@object     // @pts_type_adapter_15
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_15:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_15
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_15, 136

	.type	pts_check_38,@object            // @pts_check_38
	.p2align	3, 0x0
pts_check_38:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.181
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_38
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_38, 88

	.type	.L.str.181,@object              // @.str.181
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.181:
	.asciz	"(number) => void"
	.size	.L.str.181, 17

	.type	pts_type_adapter_38,@object     // @pts_type_adapter_38
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_38:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_38
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_38, 136

	.type	.L.str.182,@object              // @.str.182
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.182:
	.asciz	"((number) => void) => void"
	.size	.L.str.182, 27

	.type	pts_type_adapter_39,@object     // @pts_type_adapter_39
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_39:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_39
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_39, 136

	.type	pts_static_parallel_ParallelRange_filter_arrow_2,@object // @pts_static_parallel_ParallelRange_filter_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelRange_filter_arrow_2:
	.xword	pts_type_closure_parallel_ParallelRange_filter_arrow_2
	.xword	pts_fn_parallel_ParallelRange_filter_arrow_2
	.size	pts_static_parallel_ParallelRange_filter_arrow_2, 16

	.type	pts_check_1,@object             // @pts_check_1
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_1:
	.word	11                              // 0xb
	.word	5                               // 0x5
	.xword	.L.str.187
	.xword	pts_array_types+136
	.xword	pts_check_2
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_1, 88

	.type	pts_type_closure_parallel_ParallelRange_filter_arrow,@object // @pts_type_closure_parallel_ParallelRange_filter_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_filter_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_filter_arrow
	.xword	pts_check_16
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_filter_arrow, 136

	.type	pts_check_16,@object            // @pts_check_16
	.p2align	3, 0x0
pts_check_16:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.183
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_16
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_16, 88

	.type	.L.str.183,@object              // @.str.183
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.183:
	.asciz	"(number, number) => number[]"
	.size	.L.str.183, 29

	.type	pts_type_adapter_16,@object     // @pts_type_adapter_16
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_16:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_16
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_16, 136

	.type	pts_type_closure_parallel_ParallelRange_filter_adapter,@object // @pts_type_closure_parallel_ParallelRange_filter_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_filter_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_filter_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_filter_adapter, 136

	.type	pts_check_17,@object            // @pts_check_17
	.p2align	3, 0x0
pts_check_17:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.184
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_17
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_17, 88

	.type	.L.str.184,@object              // @.str.184
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.184:
	.asciz	"(number, number) => value"
	.size	.L.str.184, 26

	.type	pts_type_adapter_17,@object     // @pts_type_adapter_17
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_17:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_17, 136

	.type	pts_type_closure_parallel_ParallelRange_filter_arrow_2,@object // @pts_type_closure_parallel_ParallelRange_filter_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_filter_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2
	.xword	pts_check_18
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_filter_arrow_2, 136

	.type	pts_check_18,@object            // @pts_check_18
	.p2align	3, 0x0
pts_check_18:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.185
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_18
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_18, 88

	.type	.L.str.185,@object              // @.str.185
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.185:
	.asciz	"(value, value) => number[]"
	.size	.L.str.185, 27

	.type	pts_type_adapter_18,@object     // @pts_type_adapter_18
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_18:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_18
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_18, 136

	.type	pts_type_closure_parallel_ParallelRange_filter_adapter_2,@object // @pts_type_closure_parallel_ParallelRange_filter_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_filter_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_filter_adapter_2, 136

	.type	pts_check_19,@object            // @pts_check_19
	.p2align	3, 0x0
pts_check_19:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.186
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_19
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_19, 88

	.type	.L.str.186,@object              // @.str.186
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.186:
	.asciz	"(value, value) => value"
	.size	.L.str.186, 24

	.type	pts_type_adapter_19,@object     // @pts_type_adapter_19
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_19:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_19, 136

	.type	.L.str.187,@object              // @.str.187
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.187:
	.asciz	"number[]"
	.size	.L.str.187, 9

	.type	pts_check_23,@object            // @pts_check_23
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_23:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.188
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_23
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_23, 88

	.type	.L.str.188,@object              // @.str.188
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.188:
	.asciz	"(number) => value"
	.size	.L.str.188, 18

	.type	pts_type_adapter_23,@object     // @pts_type_adapter_23
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_23:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_23
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_23, 136

	.type	.L.str.189,@object              // @.str.189
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.189:
	.asciz	"((number) => value) => number[]"
	.size	.L.str.189, 32

	.type	pts_type_adapter_40,@object     // @pts_type_adapter_40
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_40:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_40
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_40, 136

	.type	pts_type_closure_parallel_ParallelRange_reduce_arrow,@object // @pts_type_closure_parallel_ParallelRange_reduce_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_reduce_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	1152921504606846977             // 0x1000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_reduce_arrow, 136

	.type	pts_check_20,@object            // @pts_check_20
	.p2align	3, 0x0
pts_check_20:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.190
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_20
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_20, 88

	.type	.L.str.190,@object              // @.str.190
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.190:
	.asciz	"(number, number) => number"
	.size	.L.str.190, 27

	.type	pts_type_adapter_20,@object     // @pts_type_adapter_20
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_20:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_20
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_20, 136

	.type	pts_type_closure_parallel_ParallelRange_reduce_adapter,@object // @pts_type_closure_parallel_ParallelRange_reduce_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_reduce_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_reduce_adapter, 136

	.type	pts_type_closure_parallel_ParallelRange_reduce_arrow_2,@object // @pts_type_closure_parallel_ParallelRange_reduce_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_reduce_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_reduce_arrow_2, 136

	.type	pts_check_21,@object            // @pts_check_21
	.p2align	3, 0x0
pts_check_21:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.191
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_21
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_21, 88

	.type	.L.str.191,@object              // @.str.191
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.191:
	.asciz	"(value, value) => number"
	.size	.L.str.191, 25

	.type	pts_type_adapter_21,@object     // @pts_type_adapter_21
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_21:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_21
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_21, 136

	.type	pts_type_closure_parallel_ParallelRange_reduce_adapter_2,@object // @pts_type_closure_parallel_ParallelRange_reduce_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_reduce_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_reduce_adapter_2, 136

	.type	.L.str.192,@object              // @.str.192
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.192:
	.asciz	"((number, number) => number, number) => number"
	.size	.L.str.192, 47

	.type	pts_type_adapter_41,@object     // @pts_type_adapter_41
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_41:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_41
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_41, 136

	.type	pts_fn_parallel_ParallelRange_some.pts_site1,@object // @pts_fn_parallel_ParallelRange_some.pts_site1
	.local	pts_fn_parallel_ParallelRange_some.pts_site1
	.comm	pts_fn_parallel_ParallelRange_some.pts_site1,8,8
	.type	.L.str.193,@object              // @.str.193
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.193:
	.asciz	"found"
	.size	.L.str.193, 6

	.type	pts_check_4,@object             // @pts_check_4
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_4:
	.word	5                               // 0x5
	.word	2                               // 0x2
	.xword	.L.str.142
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_4, 88

	.type	pts_type_object3,@object        // @pts_type_object3
	.p2align	3, 0x0
pts_type_object3:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.120
	.xword	0
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_fields_object3
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_object3, 136

	.type	pts_static_parallel_ParallelRange_findFound_arrow_2,@object // @pts_static_parallel_ParallelRange_findFound_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelRange_findFound_arrow_2:
	.xword	pts_type_closure_parallel_ParallelRange_findFound_arrow_2
	.xword	pts_fn_parallel_ParallelRange_findFound_arrow_2
	.size	pts_static_parallel_ParallelRange_findFound_arrow_2, 16

	.type	pts_check_3,@object             // @pts_check_3
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_3:
	.word	9                               // 0x9
	.word	5                               // 0x5
	.xword	.L.str.198
	.xword	pts_type_object4
	.xword	0
	.word	2                               // 0x2
	.zero	4
	.xword	pts_check_3_properties
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_3, 88

	.type	pts_fields_object3,@object      // @pts_fields_object3
	.p2align	3, 0x0
pts_fields_object3:
	.xword	.L.str.193
	.word	8                               // 0x8
	.word	2                               // 0x2
	.xword	pts_check_4
	.size	pts_fields_object3, 24

	.type	pts_type_closure_parallel_ParallelRange_findFound_arrow,@object // @pts_type_closure_parallel_ParallelRange_findFound_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_findFound_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	40                              // 0x28
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow
	.xword	pts_check_24
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_findFound_arrow, 136

	.type	pts_check_24,@object            // @pts_check_24
	.p2align	3, 0x0
pts_check_24:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.194
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_24
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_24, 88

	.type	.L.str.194,@object              // @.str.194
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.194:
	.asciz	"(number, number) => {found: boolean; value: number | undefined}"
	.size	.L.str.194, 64

	.type	pts_type_adapter_24,@object     // @pts_type_adapter_24
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_24:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_24
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_24, 136

	.type	pts_type_object4,@object        // @pts_type_object4
	.p2align	3, 0x0
pts_type_object4:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.120
	.xword	0
	.word	24                              // 0x18
	.word	2                               // 0x2
	.xword	pts_fields_object4
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_object4, 136

	.type	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1,@object // @pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	.local	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	.comm	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1,8,8
	.type	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2,@object // @pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	.local	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	.comm	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2,8,8
	.type	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3,@object // @pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	.local	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	.comm	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3,8,8
	.type	.L.str.195,@object              // @.str.195
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.195:
	.asciz	"value"
	.size	.L.str.195, 6

	.type	pts_check_5,@object             // @pts_check_5
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_5:
	.word	15                              // 0xf
	.word	4                               // 0x4
	.xword	.L.str.196
	.xword	0
	.xword	0
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.xword	pts_check_5_members
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_5, 88

	.type	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4,@object // @pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	.local	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	.comm	pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4,8,8
	.type	pts_fields_object4,@object      // @pts_fields_object4
	.p2align	3, 0x0
pts_fields_object4:
	.xword	.L.str.193
	.word	8                               // 0x8
	.word	2                               // 0x2
	.xword	pts_check_4
	.xword	.L.str.195
	.word	16                              // 0x10
	.word	4                               // 0x4
	.xword	pts_check_5
	.size	pts_fields_object4, 48

	.type	.L.str.196,@object              // @.str.196
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.196:
	.asciz	"number | undefined"
	.size	.L.str.196, 19

	.type	pts_check_5_members,@object     // @pts_check_5_members
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_5_members:
	.xword	pts_check_2
	.xword	pts_check_6
	.size	pts_check_5_members, 16

	.type	pts_check_6,@object             // @pts_check_6
	.p2align	3, 0x0
pts_check_6:
	.word	7                               // 0x7
	.word	4                               // 0x4
	.xword	.L.str.197
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_6, 88

	.type	.L.str.197,@object              // @.str.197
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.197:
	.asciz	"undefined"
	.size	.L.str.197, 10

	.type	pts_type_closure_parallel_ParallelRange_findFound_adapter,@object // @pts_type_closure_parallel_ParallelRange_findFound_adapter
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_findFound_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_findFound_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_findFound_adapter, 136

	.type	pts_type_closure_parallel_ParallelRange_findFound_arrow_2,@object // @pts_type_closure_parallel_ParallelRange_findFound_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_findFound_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2
	.xword	pts_check_19
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_findFound_arrow_2, 136

	.type	pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1,@object // @pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	.local	pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	.comm	pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1,8,8
	.type	.L.str.198,@object              // @.str.198
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.198:
	.asciz	"{found: boolean; value: number | undefined}"
	.size	.L.str.198, 44

	.type	pts_check_3_properties,@object  // @pts_check_3_properties
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_3_properties:
	.xword	.L.str.193
	.xword	pts_check_4
	.byte	0                               // 0x0
	.zero	3
	.word	8                               // 0x8
	.xword	.L.str.195
	.xword	pts_check_5
	.byte	0                               // 0x0
	.zero	3
	.word	16                              // 0x10
	.size	pts_check_3_properties, 48

	.type	.L.str.199,@object              // @.str.199
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.199:
	.asciz	"((number) => value) => boolean"
	.size	.L.str.199, 31

	.type	pts_type_adapter_42,@object     // @pts_type_adapter_42
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_42:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_42
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_42, 136

	.type	pts_fn_parallel_ParallelRange_every.pts_site1,@object // @pts_fn_parallel_ParallelRange_every.pts_site1
	.local	pts_fn_parallel_ParallelRange_every.pts_site1
	.comm	pts_fn_parallel_ParallelRange_every.pts_site1,8,8
	.type	pts_type_closure_parallel_ParallelRange_every_arrow,@object // @pts_type_closure_parallel_ParallelRange_every_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_every_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_every_arrow
	.xword	pts_check_22
	.word	1                               // 0x1
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_every_arrow, 136

	.type	pts_check_22,@object            // @pts_check_22
	.p2align	3, 0x0
pts_check_22:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.200
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_22
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_22, 88

	.type	.L.str.200,@object              // @.str.200
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.200:
	.asciz	"(number) => boolean"
	.size	.L.str.200, 20

	.type	pts_type_adapter_22,@object     // @pts_type_adapter_22
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_22:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_22
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_22, 136

	.type	pts_type_closure_parallel_ParallelRange_every_adapter,@object // @pts_type_closure_parallel_ParallelRange_every_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_every_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_every_adapter
	.xword	pts_check_23
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_every_adapter, 136

	.type	pts_fn_parallel_ParallelRange_find.pts_site1,@object // @pts_fn_parallel_ParallelRange_find.pts_site1
	.local	pts_fn_parallel_ParallelRange_find.pts_site1
	.comm	pts_fn_parallel_ParallelRange_find.pts_site1,8,8
	.type	.L.str.201,@object              // @.str.201
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.201:
	.asciz	"((number) => value) => number | undefined"
	.size	.L.str.201, 42

	.type	pts_type_adapter_43,@object     // @pts_type_adapter_43
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_43:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_43
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_43, 136

	.type	pts_static_parallel_ParallelRange_count_arrow_2,@object // @pts_static_parallel_ParallelRange_count_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelRange_count_arrow_2:
	.xword	pts_type_closure_parallel_ParallelRange_count_arrow_2
	.xword	pts_fn_parallel_ParallelRange_count_arrow_2
	.size	pts_static_parallel_ParallelRange_count_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelRange_count_arrow,@object // @pts_type_closure_parallel_ParallelRange_count_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_count_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_count_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_count_arrow, 136

	.type	pts_type_closure_parallel_ParallelRange_count_adapter,@object // @pts_type_closure_parallel_ParallelRange_count_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_count_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_count_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_count_adapter, 136

	.type	pts_type_closure_parallel_ParallelRange_count_arrow_2,@object // @pts_type_closure_parallel_ParallelRange_count_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_count_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_count_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_count_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelRange_count_adapter_2,@object // @pts_type_closure_parallel_ParallelRange_count_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelRange_count_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelRange_count_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelRange_count_adapter_2, 136

	.type	.L.str.202,@object              // @.str.202
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.202:
	.asciz	"((number) => value) => number"
	.size	.L.str.202, 30

	.type	pts_type_adapter_44,@object     // @pts_type_adapter_44
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_44:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_44
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_44, 136

	.type	pts_type_parallel_ParallelArray,@object // @pts_type_parallel_ParallelArray
	.p2align	3, 0x0
pts_type_parallel_ParallelArray:
	.word	4                               // 0x4
	.byte	0                               // 0x0
	.zero	3
	.xword	4611686018427387905             // 0x4000000000000001
	.xword	.L.str.203
	.xword	0
	.word	16                              // 0x10
	.word	1                               // 0x1
	.xword	pts_fields_parallel_ParallelArray
	.word	14                              // 0xe
	.zero	4
	.xword	pts_methods_parallel_ParallelArray
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	.L.str.204
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_parallel_ParallelArray, 136

	.type	.L.str.203,@object              // @.str.203
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.203:
	.asciz	"ParallelArray"
	.size	.L.str.203, 14

	.type	pts_fields_parallel_ParallelArray,@object // @pts_fields_parallel_ParallelArray
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_fields_parallel_ParallelArray:
	.xword	.L.str.205
	.word	8                               // 0x8
	.word	5                               // 0x5
	.xword	pts_check_1
	.size	pts_fields_parallel_ParallelArray, 24

	.type	pts_methods_parallel_ParallelArray,@object // @pts_methods_parallel_ParallelArray
	.p2align	3, 0x0
pts_methods_parallel_ParallelArray:
	.xword	.L.str.168
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_forEach
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_forEach
	.xword	pts_check_49
	.xword	.L.str.169
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_filter
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_filter
	.xword	pts_check_50
	.xword	.L.str.170
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_reduce
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_reduce
	.xword	pts_check_41
	.xword	.L.str.171
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_some
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_some
	.xword	pts_check_51
	.xword	.L.str.172
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_every
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_every
	.xword	pts_check_51
	.xword	.L.str.173
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_find
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_find
	.xword	pts_check_52
	.xword	.L.str.174
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_count
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_count
	.xword	pts_check_53
	.xword	.L.str.175
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_sum
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_sum
	.xword	pts_check_12
	.xword	.L.str.176
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_min
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_min
	.xword	pts_check_12
	.xword	.L.str.177
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_max
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_max
	.xword	pts_check_12
	.xword	.L.str.178
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_sort
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_sort
	.xword	pts_check_54
	.xword	.L.str.165
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_toArray
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_toArray
	.xword	pts_check_36
	.xword	.L.str.206
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_reduceElements
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_reduceElements
	.xword	pts_check_41
	.xword	.L.str.179
	.word	0                               // 0x0
	.zero	4
	.xword	pts_entry_parallel_ParallelArray_findFound
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_dynamic_entry_parallel_ParallelArray_findFound
	.xword	pts_check_55
	.size	pts_methods_parallel_ParallelArray, 784

	.type	.L.str.204,@object              // @.str.204
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.204:
	.asciz	"ParallelArray<number>"
	.size	.L.str.204, 22

	.type	.L.str.205,@object              // @.str.205
.L.str.205:
	.asciz	"items"
	.size	.L.str.205, 6

	.type	pts_check_49,@object            // @pts_check_49
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_49:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.208
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_49
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_49, 88

	.type	pts_check_50,@object            // @pts_check_50
	.p2align	3, 0x0
pts_check_50:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.210
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_50
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_50, 88

	.type	pts_check_51,@object            // @pts_check_51
	.p2align	3, 0x0
pts_check_51:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.212
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_51
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_51, 88

	.type	pts_check_52,@object            // @pts_check_52
	.p2align	3, 0x0
pts_check_52:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.214
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_52
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_52, 88

	.type	pts_check_53,@object            // @pts_check_53
	.p2align	3, 0x0
pts_check_53:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.215
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_53
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_53, 88

	.type	pts_check_54,@object            // @pts_check_54
	.p2align	3, 0x0
pts_check_54:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.216
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_54
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_54, 88

	.type	.L.str.206,@object              // @.str.206
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.206:
	.asciz	"reduceElements"
	.size	.L.str.206, 15

	.type	pts_check_55,@object            // @pts_check_55
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_check_55:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.217
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_55
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_55, 88

	.type	pts_type_closure_parallel_ParallelArray_forEach_arrow,@object // @pts_type_closure_parallel_ParallelArray_forEach_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_forEach_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_forEach_arrow
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_forEach_arrow, 136

	.type	pts_check_48,@object            // @pts_check_48
	.p2align	3, 0x0
pts_check_48:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.207
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_48
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_48, 88

	.type	.L.str.207,@object              // @.str.207
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.207:
	.asciz	"(number, number, number[]) => void"
	.size	.L.str.207, 35

	.type	pts_type_adapter_48,@object     // @pts_type_adapter_48
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_48:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_48
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_48, 136

	.type	.L.str.208,@object              // @.str.208
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.208:
	.asciz	"((number, number, number[]) => void) => void"
	.size	.L.str.208, 45

	.type	pts_type_adapter_49,@object     // @pts_type_adapter_49
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_49:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_49
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_49, 136

	.type	pts_static_parallel_ParallelArray_filter_arrow_2,@object // @pts_static_parallel_ParallelArray_filter_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_filter_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_filter_arrow_2
	.xword	pts_fn_parallel_ParallelArray_filter_arrow_2
	.size	pts_static_parallel_ParallelArray_filter_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_filter_arrow,@object // @pts_type_closure_parallel_ParallelArray_filter_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_filter_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_filter_arrow
	.xword	pts_check_16
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_filter_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_filter_adapter,@object // @pts_type_closure_parallel_ParallelArray_filter_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_filter_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_filter_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_filter_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_filter_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_filter_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_filter_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2
	.xword	pts_check_18
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_filter_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_filter_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_filter_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_filter_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_filter_adapter_2, 136

	.type	pts_check_26,@object            // @pts_check_26
	.p2align	3, 0x0
pts_check_26:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.209
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_26
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_26, 88

	.type	.L.str.209,@object              // @.str.209
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.209:
	.asciz	"(number, number, number[]) => value"
	.size	.L.str.209, 36

	.type	pts_type_adapter_26,@object     // @pts_type_adapter_26
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_26:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_26
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_26, 136

	.type	.L.str.210,@object              // @.str.210
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.210:
	.asciz	"((number, number, number[]) => value) => number[]"
	.size	.L.str.210, 50

	.type	pts_type_adapter_50,@object     // @pts_type_adapter_50
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_50:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_50
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_50, 136

	.type	pts_fn_parallel_ParallelArray_reduceElements.pts_site1,@object // @pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	.local	pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	.comm	pts_fn_parallel_ParallelArray_reduceElements.pts_site1,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements.pts_site2,@object // @pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	.local	pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	.comm	pts_fn_parallel_ParallelArray_reduceElements.pts_site2,8,8
	.type	pts_type_closure_parallel_ParallelArray_reduceElements_arrow,@object // @pts_type_closure_parallel_ParallelArray_reduceElements_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduceElements_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow
	.xword	pts_check_24
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduceElements_arrow, 136

	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2,8,8
	.type	pts_type_closure_parallel_ParallelArray_reduceElements_adapter,@object // @pts_type_closure_parallel_ParallelArray_reduceElements_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduceElements_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduceElements_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2
	.xword	pts_check_28
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2, 136

	.type	pts_check_28,@object            // @pts_check_28
	.p2align	3, 0x0
pts_check_28:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.211
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_28
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_28, 88

	.type	.L.str.211,@object              // @.str.211
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.211:
	.asciz	"(value, value) => {found: boolean; value: number | undefined}"
	.size	.L.str.211, 62

	.type	pts_type_adapter_28,@object     // @pts_type_adapter_28
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_28:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_28
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_28, 136

	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4,8,8
	.type	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5,@object // @pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	.local	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	.comm	pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5,8,8
	.type	pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2, 136

	.type	pts_type_closure_parallel_ParallelArray_reduce_arrow,@object // @pts_type_closure_parallel_ParallelArray_reduce_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduce_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduce_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_reduce_adapter,@object // @pts_type_closure_parallel_ParallelArray_reduce_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduce_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduce_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_reduce_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_reduce_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduce_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduce_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_reduce_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_reduce_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_reduce_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_reduce_adapter_2, 136

	.type	pts_fn_parallel_ParallelArray_some.pts_site1,@object // @pts_fn_parallel_ParallelArray_some.pts_site1
	.local	pts_fn_parallel_ParallelArray_some.pts_site1
	.comm	pts_fn_parallel_ParallelArray_some.pts_site1,8,8
	.type	pts_static_parallel_ParallelArray_findFound_arrow_2,@object // @pts_static_parallel_ParallelArray_findFound_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_findFound_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_findFound_arrow_2
	.xword	pts_fn_parallel_ParallelArray_findFound_arrow_2
	.size	pts_static_parallel_ParallelArray_findFound_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_findFound_arrow,@object // @pts_type_closure_parallel_ParallelArray_findFound_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_findFound_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3170534137668829185             // 0x2c00000000000001
	.xword	.L.str.143
	.xword	0
	.word	48                              // 0x30
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow
	.xword	pts_check_24
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_findFound_arrow, 136

	.type	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1,@object // @pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	.local	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	.comm	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1,8,8
	.type	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2,@object // @pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	.local	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	.comm	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2,8,8
	.type	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3,@object // @pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	.local	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	.comm	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3,8,8
	.type	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4,@object // @pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	.local	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	.comm	pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4,8,8
	.type	pts_type_closure_parallel_ParallelArray_findFound_adapter,@object // @pts_type_closure_parallel_ParallelArray_findFound_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_findFound_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_findFound_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_findFound_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_findFound_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_findFound_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_findFound_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2
	.xword	pts_check_19
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_findFound_arrow_2, 136

	.type	pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1,@object // @pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	.local	pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	.comm	pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1,8,8
	.type	.L.str.212,@object              // @.str.212
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.212:
	.asciz	"((number, number, number[]) => value) => boolean"
	.size	.L.str.212, 49

	.type	pts_type_adapter_51,@object     // @pts_type_adapter_51
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_51:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_51
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_51, 136

	.type	pts_fn_parallel_ParallelArray_every.pts_site1,@object // @pts_fn_parallel_ParallelArray_every.pts_site1
	.local	pts_fn_parallel_ParallelArray_every.pts_site1
	.comm	pts_fn_parallel_ParallelArray_every.pts_site1,8,8
	.type	pts_type_closure_parallel_ParallelArray_every_arrow,@object // @pts_type_closure_parallel_ParallelArray_every_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_every_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_every_arrow
	.xword	pts_check_25
	.word	3                               // 0x3
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_every_arrow, 136

	.type	pts_check_25,@object            // @pts_check_25
	.p2align	3, 0x0
pts_check_25:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.213
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_25
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_25, 88

	.type	.L.str.213,@object              // @.str.213
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.213:
	.asciz	"(number, number, number[]) => boolean"
	.size	.L.str.213, 38

	.type	pts_type_adapter_25,@object     // @pts_type_adapter_25
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_25:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_25
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_25, 136

	.type	pts_type_closure_parallel_ParallelArray_every_adapter,@object // @pts_type_closure_parallel_ParallelArray_every_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_every_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_every_adapter
	.xword	pts_check_26
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_every_adapter, 136

	.type	pts_fn_parallel_ParallelArray_find.pts_site1,@object // @pts_fn_parallel_ParallelArray_find.pts_site1
	.local	pts_fn_parallel_ParallelArray_find.pts_site1
	.comm	pts_fn_parallel_ParallelArray_find.pts_site1,8,8
	.type	.L.str.214,@object              // @.str.214
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.214:
	.asciz	"((number, number, number[]) => value) => number | undefined"
	.size	.L.str.214, 60

	.type	pts_type_adapter_52,@object     // @pts_type_adapter_52
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_52:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_52
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_52, 136

	.type	pts_static_parallel_ParallelArray_count_arrow_2,@object // @pts_static_parallel_ParallelArray_count_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_count_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_count_arrow_2
	.xword	pts_fn_parallel_ParallelArray_count_arrow_2
	.size	pts_static_parallel_ParallelArray_count_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_count_arrow,@object // @pts_type_closure_parallel_ParallelArray_count_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_count_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_count_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_count_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_count_adapter,@object // @pts_type_closure_parallel_ParallelArray_count_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_count_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_count_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_count_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_count_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_count_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_count_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_count_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_count_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_count_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_count_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_count_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_count_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_count_adapter_2, 136

	.type	.L.str.215,@object              // @.str.215
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.215:
	.asciz	"((number, number, number[]) => value) => number"
	.size	.L.str.215, 48

	.type	pts_type_adapter_53,@object     // @pts_type_adapter_53
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_53:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_53
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_53, 136

	.type	pts_static_parallel_ParallelArray_sum_arrow_2,@object // @pts_static_parallel_ParallelArray_sum_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_sum_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_sum_arrow_2
	.xword	pts_fn_parallel_ParallelArray_sum_arrow_2
	.size	pts_static_parallel_ParallelArray_sum_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_sum_arrow,@object // @pts_type_closure_parallel_ParallelArray_sum_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sum_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sum_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sum_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_sum_adapter,@object // @pts_type_closure_parallel_ParallelArray_sum_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sum_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sum_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sum_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_sum_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_sum_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sum_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sum_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_sum_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_sum_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sum_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sum_adapter_2, 136

	.type	pts_static_parallel_ParallelArray_min_arrow_2,@object // @pts_static_parallel_ParallelArray_min_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_min_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_min_arrow_2
	.xword	pts_fn_parallel_ParallelArray_min_arrow_2
	.size	pts_static_parallel_ParallelArray_min_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_min_arrow,@object // @pts_type_closure_parallel_ParallelArray_min_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_min_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_min_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_min_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_min_adapter,@object // @pts_type_closure_parallel_ParallelArray_min_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_min_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_min_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_min_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_min_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_min_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_min_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_min_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_min_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_min_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_min_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_min_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_min_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_min_adapter_2, 136

	.type	pts_static_parallel_ParallelArray_max_arrow_2,@object // @pts_static_parallel_ParallelArray_max_arrow_2
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_max_arrow_2:
	.xword	pts_type_closure_parallel_ParallelArray_max_arrow_2
	.xword	pts_fn_parallel_ParallelArray_max_arrow_2
	.size	pts_static_parallel_ParallelArray_max_arrow_2, 16

	.type	pts_type_closure_parallel_ParallelArray_max_arrow,@object // @pts_type_closure_parallel_ParallelArray_max_arrow
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_max_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_max_arrow
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_max_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_max_adapter,@object // @pts_type_closure_parallel_ParallelArray_max_adapter
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_max_adapter:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_max_adapter
	.xword	pts_check_17
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_max_adapter, 136

	.type	pts_type_closure_parallel_ParallelArray_max_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_max_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_max_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_max_arrow_2
	.xword	pts_check_21
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_max_arrow_2, 136

	.type	pts_type_closure_parallel_ParallelArray_max_adapter_2,@object // @pts_type_closure_parallel_ParallelArray_max_adapter_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_max_adapter_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_max_adapter_2
	.xword	pts_check_19
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_max_adapter_2, 136

	.type	.L.str.216,@object              // @.str.216
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.216:
	.asciz	"((number, number) => number, given) => number[]"
	.size	.L.str.216, 48

	.type	pts_type_adapter_54,@object     // @pts_type_adapter_54
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_54:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_54
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_54, 136

	.type	.L.str.217,@object              // @.str.217
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.217:
	.asciz	"((number, number, number[]) => value) => {found: boolean; value: number | undefined}"
	.size	.L.str.217, 85

	.type	pts_type_adapter_55,@object     // @pts_type_adapter_55
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_55:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_55
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_55, 136

	.type	pts_static_parallel_ParallelArray_sort_arrow,@object // @pts_static_parallel_ParallelArray_sort_arrow
	.data
	.p2align	3, 0x0
pts_static_parallel_ParallelArray_sort_arrow:
	.xword	pts_type_closure_parallel_ParallelArray_sort_arrow
	.xword	pts_fn_parallel_ParallelArray_sort_arrow
	.size	pts_static_parallel_ParallelArray_sort_arrow, 16

	.type	.L.str.218,@object              // @.str.218
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.218:
	.asciz	"SEQUENTIAL_SORT"
	.size	.L.str.218, 16

	.type	.L.str.219,@object              // @.str.219
.L.str.219:
	.asciz	"PIECES_PER_THREAD"
	.size	.L.str.219, 18

	.type	pts_type_tuple2,@object         // @pts_type_tuple2
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_tuple2:
	.word	9                               // 0x9
	.byte	0                               // 0x0
	.zero	3
	.xword	6917529027641081857             // 0x6000000000000001
	.xword	.L.str.144
	.xword	0
	.word	24                              // 0x18
	.word	2                               // 0x2
	.xword	pts_fields_tuple2
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_tuple2, 136

	.type	pts_type_closure_parallel_join_undefined_undefined_arrow,@object // @pts_type_closure_parallel_join_undefined_undefined_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_join_undefined_undefined_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_join_undefined_undefined_arrow
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_join_undefined_undefined_arrow, 136

	.type	pts_check_30,@object            // @pts_check_30
	.p2align	3, 0x0
pts_check_30:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.220
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_30
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_30, 88

	.type	.L.str.220,@object              // @.str.220
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.220:
	.asciz	"() => void"
	.size	.L.str.220, 11

	.type	pts_type_adapter_30,@object     // @pts_type_adapter_30
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_30:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_30, 136

	.type	pts_type_closure_parallel_join_undefined_undefined_arrow_2,@object // @pts_type_closure_parallel_join_undefined_undefined_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_join_undefined_undefined_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_join_undefined_undefined_arrow_2, 136

	.type	pts_fields_tuple2,@object       // @pts_fields_tuple2
	.p2align	3, 0x0
pts_fields_tuple2:
	.xword	.L.str.147
	.word	8                               // 0x8
	.word	4                               // 0x4
	.xword	pts_check_6
	.xword	.L.str.148
	.word	16                              // 0x10
	.word	4                               // 0x4
	.xword	pts_check_6
	.size	pts_fields_tuple2, 48

	.type	pts_type_closure_parallel_sortRun_number_number_array_arrow,@object // @pts_type_closure_parallel_sortRun_number_number_array_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_sortRun_number_number_array_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3566850904877432833             // 0x3180000000000001
	.xword	.L.str.143
	.xword	0
	.word	72                              // 0x48
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_sortRun_number_number_array_arrow, 136

	.type	pts_type_closure_parallel_sortRun_number_number_array_arrow_2,@object // @pts_type_closure_parallel_sortRun_number_number_array_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_sortRun_number_number_array_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3566850904877432833             // 0x3180000000000001
	.xword	.L.str.143
	.xword	0
	.word	72                              // 0x48
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_sortRun_number_number_array_arrow_2, 136

	.type	pts_type_closure_parallel_mergeRuns_number_number_array_arrow,@object // @pts_type_closure_parallel_mergeRuns_number_number_array_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_mergeRuns_number_number_array_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	40                              // 0x28
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow
	.xword	pts_check_22
	.word	1                               // 0x1
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_mergeRuns_number_number_array_arrow, 136

	.type	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2,@object // @pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2882303761517117441             // 0x2800000000000001
	.xword	.L.str.143
	.xword	0
	.word	40                              // 0x28
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2
	.xword	pts_check_22
	.word	1                               // 0x1
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2, 136

	.type	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3,@object // @pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3
	.p2align	3, 0x0
pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	4593671619917905921             // 0x3fc0000000000001
	.xword	.L.str.143
	.xword	0
	.word	80                              // 0x50
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3, 136

	.type	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4,@object // @pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4
	.p2align	3, 0x0
pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3837066882519662593             // 0x3540000000000001
	.xword	.L.str.143
	.xword	0
	.word	80                              // 0x50
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4
	.xword	pts_check_30
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4, 136

	.type	pts_type_closure_parallel_sortRun_number_number_array_arrow_3,@object // @pts_type_closure_parallel_sortRun_number_number_array_arrow_3
	.p2align	3, 0x0
pts_type_closure_parallel_sortRun_number_number_array_arrow_3:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	1729382256910270465             // 0x1800000000000001
	.xword	.L.str.143
	.xword	0
	.word	40                              // 0x28
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_sortRun_number_number_array_arrow_3, 136

	.type	pts_type_closure_parallel_sortInPlace_number_arrow,@object // @pts_type_closure_parallel_sortInPlace_number_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_sortInPlace_number_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_sortInPlace_number_arrow
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_sortInPlace_number_arrow, 136

	.type	pts_type_closure_parallel_ParallelArray_sort_arrow,@object // @pts_type_closure_parallel_ParallelArray_sort_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sort_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	0                               // 0x0
	.xword	.L.str.143
	.xword	0
	.word	16                              // 0x10
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sort_arrow
	.xword	pts_check_27
	.word	1                               // 0x1
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sort_arrow, 136

	.type	pts_check_27,@object            // @pts_check_27
	.p2align	3, 0x0
pts_check_27:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.221
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_27
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_27, 88

	.type	.L.str.221,@object              // @.str.221
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.221:
	.asciz	"(number, number, number[]) => string"
	.size	.L.str.221, 37

	.type	pts_type_adapter_27,@object     // @pts_type_adapter_27
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_27:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_27
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_27, 136

	.type	pts_type_closure_parallel_ParallelArray_sort_arrow_2,@object // @pts_type_closure_parallel_ParallelArray_sort_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_sort_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2
	.xword	pts_check_20
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_sort_arrow_2, 136

	.type	pts_type_closure_parallel_permute_number_arrow,@object // @pts_type_closure_parallel_permute_number_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_permute_number_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_permute_number_arrow
	.xword	pts_check_29
	.word	1                               // 0x1
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_permute_number_arrow, 136

	.type	pts_check_29,@object            // @pts_check_29
	.p2align	3, 0x0
pts_check_29:
	.word	16                              // 0x10
	.word	5                               // 0x5
	.xword	.L.str.222
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.xword	pts_adapt_29
	.byte	0                               // 0x0
	.zero	7
	.size	pts_check_29, 88

	.type	.L.str.222,@object              // @.str.222
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.222:
	.asciz	"(number, number, number[]) => number"
	.size	.L.str.222, 37

	.type	pts_type_adapter_29,@object     // @pts_type_adapter_29
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_29:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_29
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_29, 136

	.type	pts_type_closure_parallel_ParallelArray_map_number_arrow,@object // @pts_type_closure_parallel_ParallelArray_map_number_arrow
	.p2align	3, 0x0
pts_type_closure_parallel_ParallelArray_map_number_arrow:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	4035225266123964417             // 0x3800000000000001
	.xword	.L.str.143
	.xword	0
	.word	40                              // 0x28
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_ParallelArray_map_number_arrow
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_ParallelArray_map_number_arrow, 136

	.type	pts_type_closure_parallel_permute_number_arrow_2,@object // @pts_type_closure_parallel_permute_number_arrow_2
	.p2align	3, 0x0
pts_type_closure_parallel_permute_number_arrow_2:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	3458764513820540929             // 0x3000000000000001
	.xword	.L.str.143
	.xword	0
	.word	32                              // 0x20
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_permute_number_arrow_2
	.xword	pts_check_15
	.word	2                               // 0x2
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_permute_number_arrow_2, 136

	.type	.L.str.223,@object              // @.str.223
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.223:
	.asciz	"((number, number) => number) => number[]"
	.size	.L.str.223, 41

	.type	pts_type_adapter_45,@object     // @pts_type_adapter_45
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_45:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_45
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_45, 136

	.type	.L.str.224,@object              // @.str.224
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.224:
	.asciz	"((number) => value) => {found: boolean; value: number | undefined}"
	.size	.L.str.224, 67

	.type	pts_type_adapter_46,@object     // @pts_type_adapter_46
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_46:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_46
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_46, 136

	.type	.L.str.225,@object              // @.str.225
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.225:
	.asciz	"() => number[]"
	.size	.L.str.225, 15

	.type	pts_type_adapter_36,@object     // @pts_type_adapter_36
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_36:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_36
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_36, 136

	.type	.L.str.226,@object              // @.str.226
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.226:
	.asciz	"() => value"
	.size	.L.str.226, 12

	.type	pts_type_adapter_37,@object     // @pts_type_adapter_37
	.section	.data.rel.ro,"aw",@progbits
	.p2align	3, 0x0
pts_type_adapter_37:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	0
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_adapter_call
	.xword	pts_check_37
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_adapter_37, 136

	.type	pts_type_closure_parallel_for,@object // @pts_type_closure_parallel_for
	.p2align	3, 0x0
pts_type_closure_parallel_for:
	.word	6                               // 0x6
	.byte	0                               // 0x0
	.zero	3
	.xword	2305843009213693953             // 0x2000000000000001
	.xword	.L.str.143
	.xword	0
	.word	24                              // 0x18
	.word	0                               // 0x0
	.xword	0
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.xword	0
	.xword	pts_dynamic_fn_parallel_for
	.xword	pts_check_15
	.word	0                               // 0x0
	.zero	4
	.xword	0
	.word	0                               // 0x0
	.word	0                               // 0x0
	.xword	0
	.size	pts_type_closure_parallel_for, 136

	.type	.L.str.227,@object              // @.str.227
	.section	.rodata.str1.1,"aMS",@progbits,1
.L.str.227:
	.asciz	"slot"
	.size	.L.str.227, 5

	.type	pts_fn_parallel_for.pts_site1,@object // @pts_fn_parallel_for.pts_site1
	.local	pts_fn_parallel_for.pts_site1
	.comm	pts_fn_parallel_for.pts_site1,8,8
	.type	.L.str.228,@object              // @.str.228
.L.str.228:
	.asciz	"elements"
	.size	.L.str.228, 9

	.type	.L.str.229,@object              // @.str.229
.L.str.229:
	.asciz	"entries"
	.size	.L.str.229, 8

	.type	pts_fn_parallel_for.pts_site2,@object // @pts_fn_parallel_for.pts_site2
	.local	pts_fn_parallel_for.pts_site2
	.comm	pts_fn_parallel_for.pts_site2,8,8
	.type	.L.str.230,@object              // @.str.230
.L.str.230:
	.asciz	"Payload | undefined"
	.size	.L.str.230, 20

	.type	.L.str.231,@object              // @.str.231
.L.str.231:
	.asciz	"variable"
	.size	.L.str.231, 9

	.type	.L.str.232,@object              // @.str.232
.L.str.232:
	.asciz	"bad"
	.size	.L.str.232, 4

	.type	pts_str_5_bytes,@object         // @pts_str_5_bytes
	.section	.rodata,"a",@progbits
pts_str_5_bytes:
	.asciz	"published objects whole:"
	.size	pts_str_5_bytes, 25

	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym pts_adapt_12
	.addrsig_sym pts_adapter_12
	.addrsig_sym pts_adapter_call
	.addrsig_sym pts_entry_Payload_whole
	.addrsig_sym pts_dynamic_entry_Payload_whole
	.addrsig_sym pts_adapt_47
	.addrsig_sym pts_adapter_47
	.addrsig_sym pts_fn_Payload_constructor_arrow
	.addrsig_sym pts_dynamic_fn_Payload_constructor_arrow
	.addrsig_sym pts_entry_sync_AtomicInt_load
	.addrsig_sym pts_dynamic_entry_sync_AtomicInt_load
	.addrsig_sym pts_entry_sync_AtomicInt_store
	.addrsig_sym pts_dynamic_entry_sync_AtomicInt_store
	.addrsig_sym pts_entry_sync_AtomicInt_add
	.addrsig_sym pts_dynamic_entry_sync_AtomicInt_add
	.addrsig_sym pts_entry_sync_AtomicInt_compareExchange
	.addrsig_sym pts_dynamic_entry_sync_AtomicInt_compareExchange
	.addrsig_sym pts_adapt_31
	.addrsig_sym pts_adapter_31
	.addrsig_sym pts_adapt_32
	.addrsig_sym pts_adapter_32
	.addrsig_sym pts_adapt_33
	.addrsig_sym pts_adapter_33
	.addrsig_sym pts_adapt_34
	.addrsig_sym pts_adapter_34
	.addrsig_sym pts_entry_parallel_Range_get_length
	.addrsig_sym pts_entry_parallel_Range_get_par
	.addrsig_sym pts_entry_parallel_Range_toArray
	.addrsig_sym pts_dynamic_entry_parallel_Range_toArray
	.addrsig_sym pts_entry_parallel_Range__u0040_u0040iterator_
	.addrsig_sym pts_dynamic_entry_parallel_Range__u0040_u0040iterator_
	.addrsig_sym pts_entry_parallel_ParallelRange_forEach
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_forEach
	.addrsig_sym pts_entry_parallel_ParallelRange_filter
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_filter
	.addrsig_sym pts_entry_parallel_ParallelRange_reduce
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_reduce
	.addrsig_sym pts_entry_parallel_ParallelRange_some
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_some
	.addrsig_sym pts_entry_parallel_ParallelRange_every
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_every
	.addrsig_sym pts_entry_parallel_ParallelRange_find
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_find
	.addrsig_sym pts_entry_parallel_ParallelRange_count
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_count
	.addrsig_sym pts_entry_parallel_ParallelRange_sum
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_sum
	.addrsig_sym pts_entry_parallel_ParallelRange_min
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_min
	.addrsig_sym pts_entry_parallel_ParallelRange_max
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_max
	.addrsig_sym pts_entry_parallel_ParallelRange_sort
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_sort
	.addrsig_sym pts_entry_parallel_ParallelRange_toArray
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_toArray
	.addrsig_sym pts_entry_parallel_ParallelRange_findFound
	.addrsig_sym pts_dynamic_entry_parallel_ParallelRange_findFound
	.addrsig_sym pts_fn_parallel_ParallelRange_forEach_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_forEach_arrow
	.addrsig_sym pts_adapt_15
	.addrsig_sym pts_adapter_15
	.addrsig_sym pts_adapt_38
	.addrsig_sym pts_adapter_38
	.addrsig_sym pts_adapt_39
	.addrsig_sym pts_adapter_39
	.addrsig_sym pts_fn_parallel_ParallelRange_filter_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_filter_arrow
	.addrsig_sym pts_adapt_16
	.addrsig_sym pts_adapter_16
	.addrsig_sym pts_fn_parallel_ParallelRange_filter_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_filter_adapter
	.addrsig_sym pts_adapt_17
	.addrsig_sym pts_adapter_17
	.addrsig_sym pts_fn_parallel_ParallelRange_filter_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_filter_arrow_2
	.addrsig_sym pts_adapt_18
	.addrsig_sym pts_adapter_18
	.addrsig_sym pts_fn_parallel_ParallelRange_filter_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_filter_adapter_2
	.addrsig_sym pts_adapt_19
	.addrsig_sym pts_adapter_19
	.addrsig_sym pts_adapt_23
	.addrsig_sym pts_adapter_23
	.addrsig_sym pts_adapt_40
	.addrsig_sym pts_adapter_40
	.addrsig_sym pts_fn_parallel_ParallelRange_reduce_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_reduce_arrow
	.addrsig_sym pts_adapt_20
	.addrsig_sym pts_adapter_20
	.addrsig_sym pts_fn_parallel_ParallelRange_reduce_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_reduce_adapter
	.addrsig_sym pts_fn_parallel_ParallelRange_reduce_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_reduce_arrow_2
	.addrsig_sym pts_adapt_21
	.addrsig_sym pts_adapter_21
	.addrsig_sym pts_fn_parallel_ParallelRange_reduce_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_reduce_adapter_2
	.addrsig_sym pts_adapt_41
	.addrsig_sym pts_adapter_41
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_findFound_arrow
	.addrsig_sym pts_adapt_24
	.addrsig_sym pts_adapter_24
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_findFound_adapter
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_findFound_arrow_2
	.addrsig_sym pts_adapt_42
	.addrsig_sym pts_adapter_42
	.addrsig_sym pts_fn_parallel_ParallelRange_every_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_every_arrow
	.addrsig_sym pts_adapt_22
	.addrsig_sym pts_adapter_22
	.addrsig_sym pts_fn_parallel_ParallelRange_every_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_every_adapter
	.addrsig_sym pts_adapt_43
	.addrsig_sym pts_adapter_43
	.addrsig_sym pts_fn_parallel_ParallelRange_count_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_count_arrow
	.addrsig_sym pts_fn_parallel_ParallelRange_count_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_count_adapter
	.addrsig_sym pts_fn_parallel_ParallelRange_count_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_count_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelRange_count_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelRange_count_adapter_2
	.addrsig_sym pts_adapt_44
	.addrsig_sym pts_adapter_44
	.addrsig_sym pts_entry_parallel_ParallelArray_forEach
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_forEach
	.addrsig_sym pts_entry_parallel_ParallelArray_filter
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_filter
	.addrsig_sym pts_entry_parallel_ParallelArray_reduce
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_reduce
	.addrsig_sym pts_entry_parallel_ParallelArray_some
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_some
	.addrsig_sym pts_entry_parallel_ParallelArray_every
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_every
	.addrsig_sym pts_entry_parallel_ParallelArray_find
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_find
	.addrsig_sym pts_entry_parallel_ParallelArray_count
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_count
	.addrsig_sym pts_entry_parallel_ParallelArray_sum
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_sum
	.addrsig_sym pts_entry_parallel_ParallelArray_min
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_min
	.addrsig_sym pts_entry_parallel_ParallelArray_max
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_max
	.addrsig_sym pts_entry_parallel_ParallelArray_sort
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_sort
	.addrsig_sym pts_entry_parallel_ParallelArray_toArray
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_toArray
	.addrsig_sym pts_entry_parallel_ParallelArray_reduceElements
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_reduceElements
	.addrsig_sym pts_entry_parallel_ParallelArray_findFound
	.addrsig_sym pts_dynamic_entry_parallel_ParallelArray_findFound
	.addrsig_sym pts_fn_parallel_ParallelArray_forEach_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_forEach_arrow
	.addrsig_sym pts_adapt_48
	.addrsig_sym pts_adapter_48
	.addrsig_sym pts_adapt_49
	.addrsig_sym pts_adapter_49
	.addrsig_sym pts_fn_parallel_ParallelArray_filter_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_filter_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_filter_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_filter_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_filter_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_filter_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_filter_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_filter_adapter_2
	.addrsig_sym pts_adapt_26
	.addrsig_sym pts_adapter_26
	.addrsig_sym pts_adapt_50
	.addrsig_sym pts_adapter_50
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduceElements_arrow_2
	.addrsig_sym pts_adapt_28
	.addrsig_sym pts_adapter_28
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduceElements_adapter_2
	.addrsig_sym pts_fn_parallel_ParallelArray_reduce_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduce_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_reduce_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduce_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_reduce_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduce_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_reduce_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_reduce_adapter_2
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_findFound_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_findFound_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_findFound_arrow_2
	.addrsig_sym pts_adapt_51
	.addrsig_sym pts_adapter_51
	.addrsig_sym pts_fn_parallel_ParallelArray_every_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_every_arrow
	.addrsig_sym pts_adapt_25
	.addrsig_sym pts_adapter_25
	.addrsig_sym pts_fn_parallel_ParallelArray_every_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_every_adapter
	.addrsig_sym pts_adapt_52
	.addrsig_sym pts_adapter_52
	.addrsig_sym pts_fn_parallel_ParallelArray_count_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_count_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_count_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_count_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_count_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_count_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_count_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_count_adapter_2
	.addrsig_sym pts_adapt_53
	.addrsig_sym pts_adapter_53
	.addrsig_sym pts_fn_parallel_ParallelArray_sum_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sum_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_sum_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sum_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_sum_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sum_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_sum_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sum_adapter_2
	.addrsig_sym pts_fn_parallel_ParallelArray_min_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_min_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_min_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_min_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_min_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_min_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_min_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_min_adapter_2
	.addrsig_sym pts_fn_parallel_ParallelArray_max_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_max_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_max_adapter
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_max_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_max_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_max_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_max_adapter_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_max_adapter_2
	.addrsig_sym pts_adapt_54
	.addrsig_sym pts_adapter_54
	.addrsig_sym pts_adapt_55
	.addrsig_sym pts_adapter_55
	.addrsig_sym pts_compare_1
	.addrsig_sym pts_fn_parallel_join_undefined_undefined_arrow
	.addrsig_sym pts_dynamic_fn_parallel_join_undefined_undefined_arrow
	.addrsig_sym pts_adapt_30
	.addrsig_sym pts_adapter_30
	.addrsig_sym pts_fn_parallel_join_undefined_undefined_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_join_undefined_undefined_arrow_2
	.addrsig_sym pts_fn_parallel_sortRun_number_number_array_arrow
	.addrsig_sym pts_dynamic_fn_parallel_sortRun_number_number_array_arrow
	.addrsig_sym pts_fn_parallel_sortRun_number_number_array_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_2
	.addrsig_sym pts_fn_parallel_mergeRuns_number_number_array_arrow
	.addrsig_sym pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow
	.addrsig_sym pts_fn_parallel_mergeRuns_number_number_array_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_2
	.addrsig_sym pts_fn_parallel_mergeRuns_number_number_array_arrow_3
	.addrsig_sym pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_3
	.addrsig_sym pts_fn_parallel_mergeRuns_number_number_array_arrow_4
	.addrsig_sym pts_dynamic_fn_parallel_mergeRuns_number_number_array_arrow_4
	.addrsig_sym pts_fn_parallel_sortRun_number_number_array_arrow_3
	.addrsig_sym pts_dynamic_fn_parallel_sortRun_number_number_array_arrow_3
	.addrsig_sym pts_fn_parallel_sortInPlace_number_arrow
	.addrsig_sym pts_dynamic_fn_parallel_sortInPlace_number_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_sort_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sort_arrow
	.addrsig_sym pts_adapt_27
	.addrsig_sym pts_adapter_27
	.addrsig_sym pts_fn_parallel_ParallelArray_sort_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_sort_arrow_2
	.addrsig_sym pts_fn_parallel_permute_number_arrow
	.addrsig_sym pts_dynamic_fn_parallel_permute_number_arrow
	.addrsig_sym pts_adapt_29
	.addrsig_sym pts_adapter_29
	.addrsig_sym pts_fn_parallel_ParallelArray_map_number_arrow
	.addrsig_sym pts_dynamic_fn_parallel_ParallelArray_map_number_arrow
	.addrsig_sym pts_fn_parallel_permute_number_arrow_2
	.addrsig_sym pts_dynamic_fn_parallel_permute_number_arrow_2
	.addrsig_sym pts_adapt_45
	.addrsig_sym pts_adapter_45
	.addrsig_sym pts_adapt_46
	.addrsig_sym pts_adapter_46
	.addrsig_sym pts_adapt_36
	.addrsig_sym pts_adapter_36
	.addrsig_sym pts_step_fn_parallel_Range__u0040_u0040iterator_
	.addrsig_sym pts_adapt_37
	.addrsig_sym pts_adapter_37
	.addrsig_sym pts_fn_parallel_for
	.addrsig_sym pts_dynamic_fn_parallel_for
	.addrsig_sym pts_function_names
	.addrsig_sym pts_array_types
	.addrsig_sym pts_str_1_storage
	.addrsig_sym pts_str_2_storage
	.addrsig_sym pts_str_3_storage
	.addrsig_sym pts_str_4_storage
	.addrsig_sym pts_type_object1
	.addrsig_sym pts_type_Payload
	.addrsig_sym pts_type_array_1
	.addrsig_sym pts_type_array_2
	.addrsig_sym pts_type_tuple1
	.addrsig_sym pts_type_sync_AtomicInt
	.addrsig_sym pts_str_5_storage
	.addrsig_sym pts_string_type
	.addrsig_sym pts_str_1_bytes
	.addrsig_sym pts_str_2_bytes
	.addrsig_sym pts_str_3_bytes
	.addrsig_sym pts_str_4_bytes
	.addrsig_sym pts_fields_object1
	.addrsig_sym pts_check_13
	.addrsig_sym pts_fields_Payload
	.addrsig_sym pts_methods_Payload
	.addrsig_sym pts_check_2
	.addrsig_sym pts_check_10
	.addrsig_sym pts_check_11
	.addrsig_sym pts_check_12
	.addrsig_sym pts_type_Inner
	.addrsig_sym pts_fields_Inner
	.addrsig_sym pts_type_adapter_12
	.addrsig_sym pts_check_47
	.addrsig_sym pts_type_adapter_47
	.addrsig_sym pts_str_6_storage
	.addrsig_sym pts_type_closure_Payload_constructor_arrow
	.addrsig_sym .L.str.143
	.addrsig_sym pts_type_map_1
	.addrsig_sym pts_check_14
	.addrsig_sym pts_check_14_properties
	.addrsig_sym pts_fields_tuple1
	.addrsig_sym pts_methods_sync_AtomicInt
	.addrsig_sym pts_check_31
	.addrsig_sym pts_check_32
	.addrsig_sym pts_check_33
	.addrsig_sym pts_check_34
	.addrsig_sym pts_type_adapter_31
	.addrsig_sym pts_type_adapter_32
	.addrsig_sym pts_type_adapter_33
	.addrsig_sym pts_type_adapter_34
	.addrsig_sym pts_type_parallel_Range
	.addrsig_sym pts_fields_parallel_Range
	.addrsig_sym pts_methods_parallel_Range
	.addrsig_sym pts_check_9
	.addrsig_sym pts_check_36
	.addrsig_sym pts_check_37
	.addrsig_sym pts_type_parallel_ParallelRange
	.addrsig_sym pts_fields_parallel_ParallelRange
	.addrsig_sym pts_methods_parallel_ParallelRange
	.addrsig_sym pts_check_39
	.addrsig_sym pts_check_40
	.addrsig_sym pts_check_41
	.addrsig_sym pts_check_42
	.addrsig_sym pts_check_43
	.addrsig_sym pts_check_44
	.addrsig_sym pts_check_45
	.addrsig_sym pts_check_46
	.addrsig_sym pts_type_closure_parallel_ParallelRange_forEach_arrow
	.addrsig_sym pts_check_15
	.addrsig_sym pts_type_adapter_15
	.addrsig_sym pts_check_38
	.addrsig_sym pts_type_adapter_38
	.addrsig_sym pts_type_adapter_39
	.addrsig_sym pts_static_parallel_ParallelRange_filter_arrow_2
	.addrsig_sym pts_check_1
	.addrsig_sym pts_type_closure_parallel_ParallelRange_filter_arrow
	.addrsig_sym pts_check_16
	.addrsig_sym pts_type_adapter_16
	.addrsig_sym pts_type_closure_parallel_ParallelRange_filter_adapter
	.addrsig_sym pts_check_17
	.addrsig_sym pts_type_adapter_17
	.addrsig_sym pts_type_closure_parallel_ParallelRange_filter_arrow_2
	.addrsig_sym pts_check_18
	.addrsig_sym pts_type_adapter_18
	.addrsig_sym pts_type_closure_parallel_ParallelRange_filter_adapter_2
	.addrsig_sym pts_check_19
	.addrsig_sym pts_type_adapter_19
	.addrsig_sym pts_check_23
	.addrsig_sym pts_type_adapter_23
	.addrsig_sym pts_type_adapter_40
	.addrsig_sym pts_type_closure_parallel_ParallelRange_reduce_arrow
	.addrsig_sym pts_check_20
	.addrsig_sym pts_type_adapter_20
	.addrsig_sym pts_type_closure_parallel_ParallelRange_reduce_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelRange_reduce_arrow_2
	.addrsig_sym pts_check_21
	.addrsig_sym pts_type_adapter_21
	.addrsig_sym pts_type_closure_parallel_ParallelRange_reduce_adapter_2
	.addrsig_sym pts_type_adapter_41
	.addrsig_sym pts_fn_parallel_ParallelRange_some.pts_site1
	.addrsig_sym pts_check_4
	.addrsig_sym pts_type_object3
	.addrsig_sym pts_static_parallel_ParallelRange_findFound_arrow_2
	.addrsig_sym pts_check_3
	.addrsig_sym pts_fields_object3
	.addrsig_sym pts_type_closure_parallel_ParallelRange_findFound_arrow
	.addrsig_sym pts_check_24
	.addrsig_sym pts_type_adapter_24
	.addrsig_sym pts_type_object4
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow.pts_site1
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow.pts_site2
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow.pts_site3
	.addrsig_sym pts_check_5
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow.pts_site4
	.addrsig_sym pts_fields_object4
	.addrsig_sym pts_check_5_members
	.addrsig_sym pts_check_6
	.addrsig_sym pts_type_closure_parallel_ParallelRange_findFound_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelRange_findFound_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelRange_findFound_arrow_2.pts_site1
	.addrsig_sym pts_check_3_properties
	.addrsig_sym pts_type_adapter_42
	.addrsig_sym pts_fn_parallel_ParallelRange_every.pts_site1
	.addrsig_sym pts_type_closure_parallel_ParallelRange_every_arrow
	.addrsig_sym pts_check_22
	.addrsig_sym pts_type_adapter_22
	.addrsig_sym pts_type_closure_parallel_ParallelRange_every_adapter
	.addrsig_sym pts_fn_parallel_ParallelRange_find.pts_site1
	.addrsig_sym pts_type_adapter_43
	.addrsig_sym pts_static_parallel_ParallelRange_count_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelRange_count_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelRange_count_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelRange_count_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelRange_count_adapter_2
	.addrsig_sym pts_type_adapter_44
	.addrsig_sym pts_type_parallel_ParallelArray
	.addrsig_sym pts_fields_parallel_ParallelArray
	.addrsig_sym pts_methods_parallel_ParallelArray
	.addrsig_sym pts_check_49
	.addrsig_sym pts_check_50
	.addrsig_sym pts_check_51
	.addrsig_sym pts_check_52
	.addrsig_sym pts_check_53
	.addrsig_sym pts_check_54
	.addrsig_sym pts_check_55
	.addrsig_sym pts_type_closure_parallel_ParallelArray_forEach_arrow
	.addrsig_sym pts_type_match_array
	.addrsig_sym pts_type_match_copy
	.addrsig_sym pts_check_48
	.addrsig_sym pts_type_adapter_48
	.addrsig_sym pts_type_adapter_49
	.addrsig_sym pts_static_parallel_ParallelArray_filter_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_filter_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_filter_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_filter_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_filter_adapter_2
	.addrsig_sym pts_check_26
	.addrsig_sym pts_type_adapter_26
	.addrsig_sym pts_type_adapter_50
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements.pts_site1
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements.pts_site2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduceElements_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site1
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow.pts_site2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduceElements_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduceElements_arrow_2
	.addrsig_sym pts_check_28
	.addrsig_sym pts_type_adapter_28
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site1
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site2
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site3
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site4
	.addrsig_sym pts_fn_parallel_ParallelArray_reduceElements_arrow_2.pts_site5
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduceElements_adapter_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduce_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduce_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduce_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_reduce_adapter_2
	.addrsig_sym pts_fn_parallel_ParallelArray_some.pts_site1
	.addrsig_sym pts_static_parallel_ParallelArray_findFound_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_findFound_arrow
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow.pts_site1
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow.pts_site2
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow.pts_site3
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow.pts_site4
	.addrsig_sym pts_type_closure_parallel_ParallelArray_findFound_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_findFound_arrow_2
	.addrsig_sym pts_fn_parallel_ParallelArray_findFound_arrow_2.pts_site1
	.addrsig_sym pts_type_adapter_51
	.addrsig_sym pts_fn_parallel_ParallelArray_every.pts_site1
	.addrsig_sym pts_type_closure_parallel_ParallelArray_every_arrow
	.addrsig_sym pts_check_25
	.addrsig_sym pts_type_adapter_25
	.addrsig_sym pts_type_closure_parallel_ParallelArray_every_adapter
	.addrsig_sym pts_fn_parallel_ParallelArray_find.pts_site1
	.addrsig_sym pts_type_adapter_52
	.addrsig_sym pts_static_parallel_ParallelArray_count_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_count_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_count_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_count_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_count_adapter_2
	.addrsig_sym pts_type_adapter_53
	.addrsig_sym pts_static_parallel_ParallelArray_sum_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sum_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sum_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sum_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sum_adapter_2
	.addrsig_sym pts_static_parallel_ParallelArray_min_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_min_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_min_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_min_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_min_adapter_2
	.addrsig_sym pts_static_parallel_ParallelArray_max_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_max_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_max_adapter
	.addrsig_sym pts_type_closure_parallel_ParallelArray_max_arrow_2
	.addrsig_sym pts_type_closure_parallel_ParallelArray_max_adapter_2
	.addrsig_sym pts_type_adapter_54
	.addrsig_sym pts_type_adapter_55
	.addrsig_sym pts_static_parallel_ParallelArray_sort_arrow
	.addrsig_sym pts_type_tuple2
	.addrsig_sym pts_type_closure_parallel_join_undefined_undefined_arrow
	.addrsig_sym pts_check_30
	.addrsig_sym pts_type_adapter_30
	.addrsig_sym pts_type_closure_parallel_join_undefined_undefined_arrow_2
	.addrsig_sym pts_fields_tuple2
	.addrsig_sym pts_type_closure_parallel_sortRun_number_number_array_arrow
	.addrsig_sym pts_type_closure_parallel_sortRun_number_number_array_arrow_2
	.addrsig_sym pts_type_closure_parallel_mergeRuns_number_number_array_arrow
	.addrsig_sym pts_type_closure_parallel_mergeRuns_number_number_array_arrow_2
	.addrsig_sym pts_type_closure_parallel_mergeRuns_number_number_array_arrow_3
	.addrsig_sym pts_type_closure_parallel_mergeRuns_number_number_array_arrow_4
	.addrsig_sym pts_type_closure_parallel_sortRun_number_number_array_arrow_3
	.addrsig_sym pts_type_closure_parallel_sortInPlace_number_arrow
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sort_arrow
	.addrsig_sym pts_check_27
	.addrsig_sym pts_type_adapter_27
	.addrsig_sym pts_type_closure_parallel_ParallelArray_sort_arrow_2
	.addrsig_sym pts_type_closure_parallel_permute_number_arrow
	.addrsig_sym pts_check_29
	.addrsig_sym pts_type_adapter_29
	.addrsig_sym pts_type_closure_parallel_ParallelArray_map_number_arrow
	.addrsig_sym pts_type_closure_parallel_permute_number_arrow_2
	.addrsig_sym pts_type_adapter_45
	.addrsig_sym pts_type_adapter_46
	.addrsig_sym pts_type_adapter_36
	.addrsig_sym pts_type_adapter_37
	.addrsig_sym pts_type_closure_parallel_for
	.addrsig_sym pts_fn_parallel_for.pts_site1
	.addrsig_sym pts_fn_parallel_for.pts_site2
	.addrsig_sym pts_str_5_bytes
