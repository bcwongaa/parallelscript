#!/bin/bash
# Compiles a generated C file for aarch64 (-O2, as Release does) to assembly, to show the
# instructions its stores and loads of shared slots become. Usage: asm.sh <file.c> <out.s>
set -euo pipefail
home=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32
taskset -c 6,7 clang --target=aarch64-linux-gnu -O2 -g0 -ffp-contract=off -fno-math-errno -std=c11 -w \
  -I "$home/pts/runtime/include" -I "$home/pts/third_party/bdwgc/include" -I "$home/pts/third_party/libuv/include" \
  -I "$home/pts/third_party/ryu" -I "$home/pts/third_party/libbacktrace" -I "$home/pts/third_party/pcre2-config" \
  -I "$home/pts/third_party/mbedtls-config" -I "$home/pts/third_party/mbedtls/include" \
  -S "$1" -o "$2"
