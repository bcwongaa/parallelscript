#!/bin/bash
# Rebuilds one test program for aarch64 and runs it under qemu with no deadline, recording
# how long it took, its exit code and whether its output matches Node's (a .mts copy).
# Usage: triage.sh <path to .pts> [NAME=value env...]
set -uo pipefail
source=$1
shift
name=$(basename "$(dirname "$source")")_$(basename "$source" .pts)
out=/tmp/h35s/repro/triage/$name
mkdir -p "$out"
pts=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32/pts-bin/pts
export PTS_CC=/tmp/h35s/repro/x/cc-aarch64 PTS_CACHE_DIR=/tmp/h35s/repro/xcache QEMU_LD_PREFIX=/usr/aarch64-linux-gnu TZ=America/New_York
export PATH="$HOME/.local/node/bin:$PATH"
"$pts" build "$source" -o "$out/prog" >"$out/build.log" 2>&1 || { echo "$name: build failed"; exit 1; }
cd "$(dirname "$source")" || exit 2
start=$(date +%s.%N)
env "$@" "$out/prog" >"$out/stdout" 2>"$out/stderr"
code=$?
end=$(date +%s.%N)
echo "$name: exit $code in $(echo "$end - $start" | bc) s under qemu" | tee "$out/summary"
sed 's/\.pts\(["'"'"']\)/.mts\1/g' "$source" >"$out/node.mts"
if node --no-warnings --experimental-transform-types "$out/node.mts" >"$out/node.stdout" 2>"$out/node.stderr"; then
  if cmp -s "$out/stdout" "$out/node.stdout"; then echo "$name: output matches Node" | tee -a "$out/summary"; else echo "$name: output differs from Node" | tee -a "$out/summary"; fi
else
  echo "$name: Node failed (see node.stderr)" | tee -a "$out/summary"
fi
rm -f "$out/prog"
