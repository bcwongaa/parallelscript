"""Compares a program's stdout with the `// expect:` block of its source. Usage: expect_check.py <file.pts> <stdout file>"""
import sys

source, stdout = sys.argv[1], sys.argv[2]
lines = open(source).read().split('\n')
start = next(i for i, line in enumerate(lines) if line.strip() == '// expect:')
expected = []
for line in lines[start + 1:]:
    if not line.startswith('//'):
        break
    expected.append(line[3:] if line.startswith('// ') else line[2:])
want = '\n'.join(expected).rstrip('\n') + '\n'
got = open(stdout).read()
print('matches // expect:' if got == want else 'DIFFERS from // expect:\n--- got\n' + got + '--- want\n' + want)
