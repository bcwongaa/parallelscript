"""Summarises a `go test -json` log: per package pass/fail/skip counts, failing leaf tests, and
the tail of each failing test's output. Usage: summarize.py <log.jsonl> [max output chars]"""
import collections
import json
import sys

path = sys.argv[1]
limit = int(sys.argv[2]) if len(sys.argv) > 2 else 600
counts = collections.Counter()
outputs = collections.defaultdict(list)
failed, packages = [], {}
tests = set()
for line in open(path):
    try:
        event = json.loads(line)
    except ValueError:
        continue
    test, action, pkg = event.get('Test'), event.get('Action'), event.get('Package', '').rsplit('/', 1)[-1]
    if test is None:
        if action in ('pass', 'fail', 'skip'):
            packages[pkg] = (action, event.get('Elapsed'))
        continue
    tests.add((pkg, test))
    if action == 'output':
        outputs[(pkg, test)].append(event['Output'])
    elif action in ('pass', 'fail', 'skip'):
        counts[(pkg, action)] += 1
        if action == 'fail':
            failed.append((pkg, test))
parents = {(p, t.rsplit('/', 1)[0]) for p, t in failed if '/' in t}
leaves = [f for f in failed if f not in parents]
for pkg, (action, elapsed) in sorted(packages.items()):
    print(f'{pkg}: {action} in {elapsed}s; pass {counts[(pkg, "pass")]} fail {counts[(pkg, "fail")]} skip {counts[(pkg, "skip")]}')
print(f'failing leaf tests: {len(leaves)}')
for pkg, test in leaves:
    text = ''.join(outputs[(pkg, test)])
    print(f'--- {pkg} {test}')
    if limit > 0:
        print(text[-limit:])
