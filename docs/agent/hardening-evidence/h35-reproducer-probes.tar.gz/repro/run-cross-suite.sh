#!/bin/bash
# Runs Go test packages with every program cross-compiled for aarch64 Linux and run under
# qemu-aarch64 (binfmt_misc), or with another C compiler wrapper.
# Usage: run-cross-suite.sh <label> <cc wrapper> <cache dir> <package>... [-- go test flags]
set -uo pipefail
label=$1 cc=$2 cache=$3
shift 3
packages=()
while [ $# -gt 0 ] && [ "$1" != "--" ]; do
  packages+=("$1")
  shift
done
[ "${1:-}" = "--" ] && shift
out=/tmp/h35s/repro/logs
mkdir -p "$out" "$cache"
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ad59f62f01f587a32 || exit 2
export PTS_CC="$cc" PTS_CACHE_DIR="$cache" QEMU_LD_PREFIX=/usr/aarch64-linux-gnu GOMAXPROCS=4 PTS_REQUIRE_NODE=1
export PATH="$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH"
{
  echo "label=$label PTS_CC=$PTS_CC PTS_CACHE_DIR=$PTS_CACHE_DIR QEMU_LD_PREFIX=$QEMU_LD_PREFIX"
  echo "head=$(git rev-parse --short HEAD) packages=${packages[*]} flags=$*"
  date
} >"$out/$label.env"
go test -json -count=1 -p 4 -parallel 4 -timeout 90m "$@" "${packages[@]}" >"$out/$label.jsonl" 2>"$out/$label.stderr"
status=$?
echo "exit $status" >"$out/$label.exit"
date >>"$out/$label.env"
exit $status
