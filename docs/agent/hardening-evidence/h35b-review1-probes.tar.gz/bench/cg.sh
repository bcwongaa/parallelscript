#!/bin/sh
cd /tmp/h35b/review1/bench
for b in string_building json; do
  for v in base snap; do
    PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=/dev/null ./$v-$b > /dev/null 2> cg-$v-$b.log &
  done
  wait
  printf '%-16s base %s snap %s\n' $b "$(grep -o 'Collected : [0-9]*' cg-base-$b.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' cg-snap-$b.log | grep -o '[0-9]*$')" >> cg.txt
done
touch cg.done
