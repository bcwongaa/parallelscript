#!/bin/sh
# run_home.sh HOME CHECK file.pts: builds file.pts under the publication profile with the
# snapshot CLI and the given PTS_HOME, runs it with PTS_PUBLICATION_CHECK=CHECK.
H=$1; C=$2; F=$3
exe=/tmp/h35b/review1/bin/$(basename $F .pts).$$
PTS_HOME=$H PTS_BUILD_PROFILE=publication /tmp/h35b/snap3/pts-bin/pts build $F -o $exe || exit 99
PTS_HOME=$H PTS_PUBLICATION_CHECK=$C PTS_THREADS=2 timeout -s KILL 120 setsid $exe
echo "exit=$?"
rm -f $exe
