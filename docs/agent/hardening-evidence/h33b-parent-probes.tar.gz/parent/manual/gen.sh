#!/bin/bash
# Makes the throwaway CA, certificates and keys the manual probes use (keys aren't archived).
set -euo pipefail
cd "$(dirname "$0")"
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout ca.key -out ca.pem -days 2 -subj "/CN=pts test CA" -addext basicConstraints=critical,CA:TRUE -addext keyUsage=critical,keyCertSign
openssl req -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout server.key -out server.csr -subj /CN=localhost
printf 'subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\nkeyUsage=digitalSignature\n' > ext.cnf
openssl x509 -req -in server.csr -CA ca.pem -CAkey ca.key -CAcreateserial -out server.pem -days 1 -extfile ext.cnf
openssl genrsa -out rsa.key 2048
openssl req -new -key rsa.key -out rsa.csr -subj /CN=localhost
printf 'subjectAltName=DNS:localhost,IP:127.0.0.1\nextendedKeyUsage=serverAuth\nkeyUsage=digitalSignature,keyEncipherment\n' > ext2.cnf
openssl x509 -req -in rsa.csr -CA ca.pem -CAkey ca.key -CAcreateserial -out rsa.pem -days 1 -extfile ext2.cnf
openssl pkcs8 -topk8 -in server.key -out enc.key -passout pass:secret -v2 aes256
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout other.key -out other.pem -days 1 -subj /CN=other
openssl genpkey -algorithm ed25519 -out ed.key
openssl req -x509 -key ed.key -out ed.pem -days 1 -subj /CN=localhost
openssl ec -in server.key -out legacy_enc.key -aes256 -passout pass:secret
