#!/bin/bash
# Manual probe of the HTTPS server: curl, openssl s_client, plain HTTP to the TLS port.
cd "$(dirname "$0")"
NODE_EXTRA_CA_CERTS=$PWD/ca.pem ./serve.bin $PWD > out.txt 2> err.txt &
pid=$!
sleep 1.5
read -r _ P R E _ < <(head -1 out.txt)
echo "ports $P $R $E"
curl -sS -m 5 --cacert ca.pem https://localhost:$P/hi; echo
curl -sS -m 5 --cacert ca.pem --tlsv1.2 --tls-max 1.2 https://127.0.0.1:$P/v12 -w ' %{http_version} %{ssl_verify_result}\n'
curl -sS -m 5 --cacert ca.pem --tlsv1.3 https://127.0.0.1:$P/v13 -w ' %{http_version}\n'
curl -sS -m 5 --cacert ca.pem https://localhost:$R/; echo
curl -sS -m 5 --cacert ca.pem https://localhost:$E/; echo
curl -sS -m 5 --cacert ca.pem https://localhost:$P/a https://localhost:$P/b -v 2>&1 | grep -i 'Re-using\|left intact\|ALPN\|SSL connection'
echo | timeout 5 openssl s_client -connect 127.0.0.1:$P -alpn h2,http/1.1 -CAfile ca.pem 2>&1 | grep -i 'ALPN\|Verify return\|Protocol  ' | head
echo | timeout 5 openssl s_client -connect 127.0.0.1:$P -alpn h2 -CAfile ca.pem 2>&1 | grep -i 'ALPN\|alert\|error' | head -3
curl -sS -m 3 http://127.0.0.1:$P/plain; echo " plain exit $?"
curl -sS -m 5 --cacert ca.pem https://localhost:$P/stop; echo
sleep 3.5
echo "--- out"; cat out.txt; echo "--- err"; cat err.txt
kill $pid 2>/dev/null; wait $pid; echo "exit $?"
