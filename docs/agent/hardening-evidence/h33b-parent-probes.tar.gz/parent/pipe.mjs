for (let i = 0; i < 2000000; i++) console.log("line " + i);
console.error("done writing");
