function f(): never { throw new TypeError("x"); }
try { f(); } catch (e) {
  const error = e as NodeJS.ErrnoException;
  console.log(error instanceof TypeError, e instanceof TypeError, (e as Error) instanceof TypeError, error.name);
}
try { JSON.parse("{"); } catch (e) {
  const error = e as NodeJS.ErrnoException;
  console.log(error instanceof SyntaxError, e instanceof SyntaxError);
}
interface Coded extends Error { code?: string }
try { f(); } catch (e) {
  const error = e as Coded;
  console.log(error instanceof TypeError, error instanceof Error);
}
