interface Named { name: string; message: string }
class Thing { name = "t"; message = "m" }
const t: Named = new Thing();
console.log(t instanceof Thing);
const e: Named = new RangeError("r");
console.log(e instanceof RangeError, e instanceof Error);
