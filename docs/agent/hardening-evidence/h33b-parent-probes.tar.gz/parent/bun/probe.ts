const mode = process.argv[2];
let tls: any;
if (mode === "files") tls = { certFile: "cert.pem", keyFile: "key.pem" };
else if (mode === "text") tls = { cert: await Bun.file("cert.pem").text(), key: await Bun.file("key.pem").text() };
else if (mode === "nokey") tls = { cert: await Bun.file("cert.pem").text() };
else if (mode === "badcert") tls = { cert: "garbage", key: await Bun.file("key.pem").text() };
else if (mode === "badkey") tls = { cert: await Bun.file("cert.pem").text(), key: "garbage" };
else if (mode === "missingfile") tls = { certFile: "nope.pem", keyFile: "key.pem" };
else if (mode === "empty") tls = {};
try {
  const server = Bun.serve({ port: 0, hostname: "127.0.0.1", tls, fetch(req) { return new Response(`url=${req.url}`); } });
  console.log("url", server.url.href, "protocol", server.protocol);
  try {
    const r = await fetch(`https://localhost:${server.port}/x?y`, { tls: { rejectUnauthorized: false } } as any);
    console.log(await r.text());
  } catch (e) { console.log("fetch err", e); }
  server.stop(true);
} catch (e: any) {
  console.log("serve threw", e?.constructor?.name, e?.code, e?.message);
}
