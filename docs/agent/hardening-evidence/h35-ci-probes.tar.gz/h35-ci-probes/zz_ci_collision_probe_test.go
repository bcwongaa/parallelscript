package tests

import (
	"net/http"
	"strings"
	"testing"
)

// Probe for CI run 40220044180: a request to localhost:P whose resolver gives ::1 first
// reaches another lab's [::1] server when that one has the same port number.
func TestProbeLocalhostCollision(t *testing.T) {
	exe := buildShared(t, "fetch_tls_one")
	a := startTLSLab(t)
	port := strings.TrimPrefix(a.base("localhost"), "https://localhost:")
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil) // another lab's root: the same name, another key
	good := serverCert(t, root, "p256", nil)
	a.serveTLS(t, http.NotFoundHandler(), "[::1]:"+port, good, nil, "")
	got := runTLSProgram(t, []string{"NODE_EXTRA_CA_CERTS=" + a.trusted}, exe, a.base("localhost")+"/hello")
	t.Logf("port %s: %q (exit %d)", port, got.stdout, got.exitCode)
}
