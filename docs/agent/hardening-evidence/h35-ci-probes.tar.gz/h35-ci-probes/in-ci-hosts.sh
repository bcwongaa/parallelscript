#!/bin/sh
# Runs "$@" with an /etc/hosts where localhost is ::1 first, as on GitHub's runners,
# in a private user and mount namespace (no root needed).
exec unshare --user --map-root-user --mount sh -c 'mount --bind "$0" /etc/hosts && exec "$@"' "$(dirname "$0")/hosts-ci-like" "$@"
