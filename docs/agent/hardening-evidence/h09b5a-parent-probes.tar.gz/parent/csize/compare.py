#!/usr/bin/env python3
"""emit-c every program with two CLIs and report the programs whose C or errors differ."""
import concurrent.futures, glob, hashlib, json, os, subprocess, sys
repo, base, new, out = sys.argv[1:5]
paths = sorted(glob.glob(f"{repo}/pts/tests/run/*.pts") + glob.glob(f"{repo}/pts/tests/errors/*.pts") +
               glob.glob(f"{repo}/pts/tests/corpus/*/*.pts") + glob.glob(f"{repo}/docs/examples/*.pts") +
               glob.glob(f"{repo}/pts/tests/stress/*.pts"))
def emit(cli, home, path):
    r = subprocess.run([cli, "emit-c", path], capture_output=True, text=True, env={**os.environ, "PTS_HOME": home}, timeout=300)
    return r.returncode, r.stdout, r.stderr
def one(path):
    b = emit(base, os.path.dirname(os.path.dirname(base)), path)
    n = emit(new, os.path.dirname(os.path.dirname(new)), path)
    same = b == n
    return {"path": os.path.relpath(path, repo), "same": same, "base_exit": b[0], "new_exit": n[0],
            "base_lines": b[1].count("\n"), "new_lines": n[1].count("\n"),
            "base_err": b[2][:300], "new_err": n[2][:300]}
with concurrent.futures.ThreadPoolExecutor(int(os.environ.get("JOBS", "2"))) as pool:
    results = list(pool.map(one, paths))
json.dump(results, open(out, "w"), indent=1)
diff = [r for r in results if not r["same"]]
print(f"{len(results)} programs, {len(diff)} differ")
for r in diff:
    print(f'{r["path"]}: exit {r["base_exit"]}->{r["new_exit"]}, lines {r["base_lines"]}->{r["new_lines"]}')
