// Polymorphic recursion through calls that look up instances (H09b5, C184): each call
// of rec<T> calls rec<T[]>, so its instances would make instances without end. Past the
// limit of instances that make each other, a call that looks one up keeps the erased
// copy, which a call that never runs that deep doesn't notice. Through a dispatched
// (abstract) method the limit's PTS1001 was followed by an internal error, in every
// fallback build (D-101's demands are made in each); through an interface the build fell
// back to DeclaredInstances, whose erased copy's Box<any> didn't convert.
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => Box<number>): void {
  try {
    console.log(label, f().value + 1);
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}

abstract class Base {
  abstract rec<T>(x: T, n: number): Box<T>;
}
class Recurser extends Base {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      const self: Base = this;
      const inner: Box<T[]> = self.rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  }
}
const base: Base = new Recurser();
attempt("dispatched", () => base.rec(5, 3));

interface Rec {
  rec<T>(x: T, n: number): Box<T>;
}
class ByName implements Rec {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      const self: Rec = this;
      const inner: Box<T[]> = self.rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  }
}
const byName: Rec = new ByName();
attempt("interface", () => byName.rec(5, 3));

const literal = {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      const inner: Box<T[]> = this.rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  },
};
attempt("literal", () => literal.rec(5, 3));

function viaValue(f: <T>(x: T, n: number) => Box<T>): Box<number> {
  return f(5, 3);
}
function recurse<T>(x: T, n: number): Box<T> {
  if (n > 0) {
    const g: <U>(y: U, m: number) => Box<U> = recurse;
    const inner: Box<T[]> = g([x], n - 1);
    return new Box(inner.value[0]);
  }
  return new Box(x);
}
attempt("value", () => viaValue(recurse));
// expect:
// dispatched 6
// interface 6
// literal 6
// value 6
