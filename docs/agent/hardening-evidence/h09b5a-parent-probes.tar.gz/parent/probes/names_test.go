package lower_test

import (
	"os"
	"sort"
	"testing"
)

func TestPrintInstanceNames(t *testing.T) {
	src, _ := os.ReadFile("/tmp/h09b5/review-a/p/product_blowup.pts")
	program, errors := lowerSource(t, string(src))
	counts := map[string]int{}
	for _, fn := range program.Funcs {
		n := fn.Name
		if len(n) > 12 {
			n = n[:12]
		}
		counts[n]++
	}
	keys := []string{}
	for k := range counts {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		t.Logf("%s %d", k, counts[k])
	}
	t.Logf("errors %d", len(errors))
}
