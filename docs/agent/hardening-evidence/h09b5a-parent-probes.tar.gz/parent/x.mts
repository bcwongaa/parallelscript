// Polymorphic recursion through a dispatched generic method (D-101; a trial per level) called for
// five base types side by side, recursing 3 levels: each chain's trials make 63 instances by
// recursion, so the fifth chain is past maxRecursiveInstances (256) from its first level.
class Box<T> {
  constructor(public value: T) {}
}
abstract class Base {
  abstract rec<T>(x: T, n: number): Box<T>;
}
class Recurser extends Base {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      const self: Base = this;
      const inner: Box<T[]> = self.rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  }
}
const r: Base = new Recurser();
function attempt(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
attempt("number", () => r.rec(1, 3).value);
attempt("string", () => r.rec("s", 3).value);
attempt("boolean", () => r.rec(true, 3).value);
attempt("object", () => r.rec({ a: 1 }, 3).value.a);
attempt("null", () => r.rec(null, 3).value);
