package lower_test

// REVIEW5 overlay only: prints the IR of the file named by PTS_REVIEW_DUMP.
import (
	"os"
	"testing"
)

func TestReviewDumpIR(t *testing.T) {
	path := os.Getenv("PTS_REVIEW_DUMP")
	if path == "" {
		t.Skip()
	}
	source, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	program, errors := lowerSource(t, string(source))
	for _, e := range errors {
		t.Log(e)
	}
	os.WriteFile(os.Getenv("PTS_REVIEW_OUT"), []byte(program.String()), 0o644)
}
