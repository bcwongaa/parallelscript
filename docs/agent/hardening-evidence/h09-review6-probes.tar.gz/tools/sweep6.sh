#!/bin/bash
# sweep6.sh OUT FILE...: base, snap7, snap8 and Node outputs in OUT/<dir>__<name>.{b,7,8,n} (b, 7, n reused from round 5)
out=$1; shift; mkdir -p $out; node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); tag=$(basename $(dirname $f))__$b; d=$(mktemp -d /tmp/h09/review6/run/s.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  [ -f $out/$tag.b ] || (cd "$d" && PTS_HOME=/tmp/h09/base timeout 300 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.b
  [ -f $out/$tag.7 ] || (cd "$d" && PTS_HOME=/tmp/h09/snap7 timeout 300 /tmp/h09/snap7/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.7
  (cd "$d" && PTS_HOME=/tmp/h09/snap8 timeout 300 /tmp/h09/snap8/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.8
  [ -f $out/$tag.n ] || (cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]") > $out/$tag.n
  rm -rf "$d"
  c() { cmp -s $out/$tag.$1 $out/$tag.$2 && echo "$1=$2" || echo "$1!$2"; }
  echo "$(c b n) $(c 7 n) $(c 8 n) $(c 7 8) $(c b 8) $tag"
done
