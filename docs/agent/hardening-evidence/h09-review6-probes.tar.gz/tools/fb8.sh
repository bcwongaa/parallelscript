#!/bin/bash
# fb8.sh FILE7...: emit-c with the snap7 and snap8 fallback-trace CLIs (path /tmp/h09/snap7/ -> /tmp/h09/snap8/ for the
# second): fallback used, exit codes, C lines, C same (paths normalized)
for f in "$@"; do f7=${f/\/tmp\/h09\/snap7\//\/tmp\/h09\/snap8\/}; d=$(mktemp -d /tmp/h09/review6/run/fb.XXXX)
  ta=$(date +%s%N); a=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap7 timeout 300 /tmp/h09/review5/ov/pts-trace7 emit-c "$f" -o $d/a.c 2>&1); ea=$?; ta=$(( ($(date +%s%N)-ta)/1000000 ))
  tb=$(date +%s%N); b=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap8 timeout 300 /tmp/h09/review6/ov/pts-trace8 emit-c "$f7" -o $d/b.c 2>&1); eb=$?; tb=$(( ($(date +%s%N)-tb)/1000000 ))
  fa=$(echo "$a" | grep -c '^PTS_FALLBACK'); fb=$(echo "$b" | grep -c '^PTS_FALLBACK')
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  same=$( [ -f $d/a.c ] && [ -f $d/b.c ] && cmp -s <(sed "s#/tmp/h09/snap7/#X/#g" $d/a.c) <(sed "s#/tmp/h09/snap8/#X/#g" $d/b.c) && echo Csame || echo Cdiff)
  echo "s7FB=$fa s8FB=$fb exit=$ea/$eb lines=$la/$lb $same ms=$ta/$tb $f7"
  rm -rf $d
done
