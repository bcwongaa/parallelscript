// A0606 C11 source=number:tested form=- dest=cond_branch expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}


function main(): void {
  const src = [1];
  const k = src[0];
  const v = src[1];
  if (v === undefined) console.log("tested");
  const t: number | undefined = Math.random() < 2 ? v : 7;
  console.log(t);
}
try {
  main();
} catch (e) {
  report(e);
}
