// F1532 C224 source=points form=- dest=unknown_record expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}

class P {
  constructor(public x: number) {}
}
function strs(): string[] {
  const a = new Array<string>(3);
  a[1] = "b";
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(3);
  a[1] = "b";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function nums(): number[] {
  const a = new Array<number>(3);
  a[1] = 1;
  return a;
}
function takesUnknown(x: unknown): void {
  console.log("unknown", x);
}
function takesAny(x: any): void {
  console.log("any", x);
}
function takesOptionalUnknown(x?: unknown): void {
  console.log("optional unknown", x);
}
function takesOptional(x?: P): void {
  console.log("optional", x);
}
function takesUnion(x: P | undefined): void {
  console.log("union", x);
}
function id<T>(x: T): T {
  return x;
}

function main(): void {
  const ps = [new P(1)];
  const o: Record<string, unknown> = { v: ps[5] };
  console.log(o);
}
try {
  main();
} catch (e) {
  report(e);
}
