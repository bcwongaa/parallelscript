// A0333 C11 source=string:tested form=- dest=log_array_literal expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}


function main(): void {
  const src = ["count"];
  const k = src[0];
  const v = src[1];
  if (v === undefined) console.log("tested");
  console.log([k, v]);
}
try {
  main();
} catch (e) {
  report(e);
}
