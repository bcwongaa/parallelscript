// A0048 C11 source=string:split form=- dest=log_array_literal expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}


function main(): void {
  const [k, v] = "count".split(":");
  console.log([k, v]);
}
try {
  main();
} catch (e) {
  report(e);
}
