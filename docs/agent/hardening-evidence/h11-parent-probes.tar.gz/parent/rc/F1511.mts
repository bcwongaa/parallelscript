// F1511 C224 source=numbers form=- dest=unknown_cond expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}

class P {
  constructor(public x: number) {}
}
function strs(): string[] {
  const a = new Array<string>(3);
  a[1] = "b";
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(3);
  a[1] = "b";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function nums(): number[] {
  const a = new Array<number>(3);
  a[1] = 1;
  return a;
}
function takesUnknown(x: unknown): void {
  console.log("unknown", x);
}
function takesAny(x: any): void {
  console.log("any", x);
}
function takesOptionalUnknown(x?: unknown): void {
  console.log("optional unknown", x);
}
function takesOptional(x?: number): void {
  console.log("optional", x);
}
function takesUnion(x: number | undefined): void {
  console.log("union", x);
}
function id<T>(x: T): T {
  return x;
}

function main(): void {
  const ns = [1];
  const u: unknown = Math.random() < 2 ? ns[5] : 1;
  console.log(u);
}
try {
  main();
} catch (e) {
  report(e);
}
