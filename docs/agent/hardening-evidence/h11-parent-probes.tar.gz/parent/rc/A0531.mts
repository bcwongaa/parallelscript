// A0531 C11 source=number:array form=- dest=cond_branch expected=node
function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}


function main(): void {
  const src: number[] = [1];
  const [k, v] = src;
  const t: number | undefined = Math.random() < 2 ? v : 7;
  console.log(t);
}
try {
  main();
} catch (e) {
  report(e);
}
