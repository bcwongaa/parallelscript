function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
const src: any = ["x"];
show("any rest pattern", () => { const [a, ...[b]] = src; return [a, b]; });
show("assignment default at hole", () => { let p: string | undefined, q: string | undefined; const xs = new Array<string>(2); xs[0] = "a"; [p, q = "D"] = xs; return [p, q]; });
show("assignment default past end", () => { let p = "", q = ""; [p, q = "D"] = ["a"]; return [p, q]; });
show("nested default", () => { const rows: string[][] = [["x"]]; const [[a, b = "B"], [c] = ["C"]] = rows; return [a, b, c]; });
show("number default hole", () => { const ns = new Array<number>(2); const [a = 5, b = 6, c = 7] = ns; return [a, b, c]; });
show("bool default", () => { const bs: boolean[] = [true]; const [a = false, b = true] = bs; return [a, b]; });
show("union rest", () => { const xs: (string | undefined)[] = new Array(3); xs[1] = "m"; const [, ...r] = xs; return r; });
show("default fn", () => { let calls = 0; const d = () => { calls++; return "d"; }; const [a = d(), b = d()] = ["x"]; return [a, b, calls]; });
show("async param", () => { const f = async ([a, b]: string[]) => [a, b]; return f(["q"]).then(v => console.log("async", v)); });
show("generator for-of", () => { function* g(): Generator<number[]> { yield [1]; } const out: unknown[] = []; for (const [a, b] of g()) out.push(a, b); return out; });
