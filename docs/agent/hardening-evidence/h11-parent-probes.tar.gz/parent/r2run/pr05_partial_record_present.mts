const [, column] = "sum:units".split(":");
const r: Partial<Record<"column" | "x", string>> = { column };
console.log(r);
