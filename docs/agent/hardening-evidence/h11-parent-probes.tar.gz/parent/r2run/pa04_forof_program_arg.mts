const rows: (string | number)[][] = [["k", "a"], ["k", 1], ["k"]];
function opt(s: string | undefined): string {
  return "opt:" + s;
}
for (const [x, y] of rows) {
  if (typeof y === "number") console.log("num", y);
  else console.log(opt(y));
}
