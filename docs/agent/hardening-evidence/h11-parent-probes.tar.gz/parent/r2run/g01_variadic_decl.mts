// A declaration's pattern over a variadic tuple type `[...T]` whose instance is an array.
function second<T extends unknown[]>(xs: [...T]): string {
  const [a, b] = xs;
  return String(a) + "|" + String(b);
}
console.log(second(["x"] as string[]));
console.log(second([1, 2] as [number, number]));
