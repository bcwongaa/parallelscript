interface Opt {
  label?: string;
}
const vals: (string | number)[] = ["a"];
let v = vals[0];
const bump = (): void => {
  v = 42;
};
if (v !== undefined && typeof v === "string") {
  bump();
  const o: Opt = { label: v };
  const lab = o.label;
  if (lab !== undefined) console.log(lab.length);
}
