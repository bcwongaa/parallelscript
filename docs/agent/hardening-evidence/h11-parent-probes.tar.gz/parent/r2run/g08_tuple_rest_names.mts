function f(t: [string, ...string[]]): string {
  const [a, b] = t;
  return a + "|" + b;
}
console.log(f(["only"]));
