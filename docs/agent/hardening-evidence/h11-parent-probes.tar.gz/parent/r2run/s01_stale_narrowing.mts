// A loose local narrowed by typeof, changed by a call tsc doesn't follow, then given to a
// `string | undefined` place (D-140: narrowed reads a call may have invalidated are checked).
const items: (string | number)[] = ["a", 1];
let v = items[0];
function setNumber(): void {
  v = 5;
}
if (v !== undefined && typeof v === "string") {
  setNumber();
  const s: string | undefined = v;
  console.log(typeof s, s === undefined ? "u" : s.length);
}
