abstract class Shape {
  abstract area(): number;
}
class Circle extends Shape {
  constructor(public r: number) {
    super();
  }
  area(): number {
    return 3 * this.r * this.r;
  }
}
class Square extends Shape {
  constructor(public side: number) {
    super();
  }
  area(): number {
    return this.side * this.side;
  }
}
const shapes: Shape[] = [];
for (let i = 0; i < 1000; i++) shapes.push(i % 2 === 0 ? new Circle(i) : new Square(i));
let total = 0;
for (let r = 0; r < 3000; r++) {
  for (let i = 0; i < shapes.length; i++) {
    const s = shapes[i];
    if (s instanceof Circle) total += s.r;
    else if (s instanceof Square) total += s.side;
  }
}
console.log(total);
