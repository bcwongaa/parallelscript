// A newly loose for…of pattern name, captured and changed by a closure.
const rows: (string | number)[][] = [["a", "b"]];
for (let [k, v] of rows) {
  const change = (): void => {
    v = 9;
  };
  if (typeof v === "string") {
    change();
    const s: string | undefined = v;
    console.log(s === undefined ? "u" : s.length);
  }
}
