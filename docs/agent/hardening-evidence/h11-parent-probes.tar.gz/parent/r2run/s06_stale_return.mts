const items: (string | number)[] = ["abc"];
let v = items[0];
function setNumber(): void {
  v = 7;
}
function get(): string | undefined {
  if (v === undefined || typeof v !== "string") return undefined;
  setNumber();
  return v;
}
const r = get();
console.log(r === undefined ? "u" : r.toUpperCase());
