function label(s?: string): string {
  return s === undefined ? "none" : s;
}
function show([k, v]: (string | null)[]): string {
  return v === null ? "null" : label(v);
}
console.log(show(["k", "v"]), show(["k", null]), show(["k"]));
