function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
function takesUnknown(u: unknown): string { return typeof u; }
function takesAny(u: any): string { return typeof u; }
function takesOpt(u?: string): string { return typeof u; }
function takesUnion(u: string | undefined): string { return typeof u; }
const [kind, column] = "count".split(":");
show("log", () => { console.log(column); return 1; });
show("template", () => `${column}!`);
show("concat", () => "c=" + column);
show("unknown param", () => takesUnknown(column));
show("any param", () => takesAny(column));
show("optional param", () => takesOpt(column));
show("union param", () => takesUnion(column));
show("unknown const", () => { const u: unknown = column; return u; });
show("union let", () => { let u: string | undefined = "x"; u = column; return u; });
show("array elem", () => { const a: (string | undefined)[] = [column]; return a; });
show("strict eq", () => column === undefined);
show("String()", () => String(column));
show("return unknown", (): unknown => column);
const s = "ab";
show("unknown param elem", () => takesUnknown(s[5]));
show("String elem", () => String(s[5]));
show("unknown arrow elem", (): unknown => s[5]);
show("unknown[] literal", () => { const xs: unknown[] = [s[5]]; return xs; });
