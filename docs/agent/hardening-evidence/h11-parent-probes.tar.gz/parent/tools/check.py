"""Build each run test with the given pts CLI, run it, compare stdout with `// expect:`."""
import difflib, os, subprocess, sys
def expected(text):
    lines, inside = [], False
    for line in text.split("\n"):
        if line.strip() == "// expect:":
            inside = True; continue
        if inside:
            if not line.startswith("//"): break
            body = line[2:]
            lines.append(body[1:] if body.startswith(" ") else body)
    return "\n".join(lines) + "\n" if lines else ""
home, cli, files = sys.argv[1], sys.argv[2], sys.argv[3:]
env = dict(os.environ, TZ="America/New_York", PTS_HOME=home)
os.makedirs("/tmp/h11/chk/bin", exist_ok=True)
for path in files:
    text = open(path).read()
    src = os.path.join("/tmp/h11/chk/bin", os.path.basename(path))
    open(src, "w").write("\n".join(l for l in text.split("\n") if not l.startswith("// skip:")))
    exe = src[:-4]
    b = subprocess.run([cli, "build", "-o", exe, src], env=env, capture_output=True, text=True)
    if b.returncode != 0:
        print("FAIL(build)", os.path.basename(path), b.stderr.strip().split("\n")[0][:300]); continue
    r = subprocess.run([exe], env=env, capture_output=True, text=True, timeout=60)
    os.remove(exe)
    want = expected(text)
    if r.stdout == want:
        print("PASS", os.path.basename(path))
    else:
        print("FAIL", os.path.basename(path))
        for d in list(difflib.unified_diff(want.split("\n"), r.stdout.split("\n"), "expected", "pts", lineterm="", n=0))[2:14]:
            print("   ", d)
        if r.stderr: print("    stderr:", r.stderr.strip().split("\n")[0][:200])
