"""emit-c every program with two CLIs; classify: same C, changed C, newly failing, newly compiling, both failing."""
import glob, hashlib, os, subprocess, sys
root = "/tmp/h11/snap2"
files = sorted(glob.glob(root + "/pts/tests/run/*.pts") + glob.glob(root + "/pts/tests/corpus/*/*.pts") + glob.glob(root + "/docs/examples/*.pts") + glob.glob(root + "/pts/tests/stress/*.pts"))
clis = {"base": ("/tmp/h11/base/pts-bin/pts", "/tmp/h11/base"), "new": ("/tmp/h11/snap2/pts-bin/pts", "/tmp/h11/snap2")}
out = open("/tmp/h11/sweep/sweep.tsv", "w")
counts = {}
for f in files:
    res = {}
    for k, (cli, home) in clis.items():
        r = subprocess.run([cli, "emit-c", f], env=dict(os.environ, PTS_HOME=home), capture_output=True, text=True, timeout=600)
        c = r.stdout.replace(home, "@")
        res[k] = (r.returncode, hashlib.sha256(c.encode()).hexdigest()[:12], (r.stderr or "").strip().split("\n")[0][:200])
        if r.returncode == 0:
            open("/tmp/h11/sweep/%s.%s.c" % (os.path.basename(f), k), "w").write(c)
    b, n = res["base"], res["new"]
    if b[0] == 0 and n[0] == 0:
        cls = "SAME" if b[1] == n[1] else "CHANGED"
        if cls == "SAME":
            for k in clis: os.remove("/tmp/h11/sweep/%s.%s.c" % (os.path.basename(f), k))
    elif b[0] == 0:
        cls = "NEWFAIL"
    elif n[0] == 0:
        cls = "NEWOK"
    else:
        cls = "BOTHFAIL"
    counts[cls] = counts.get(cls, 0) + 1
    out.write("%s\t%s\t%s\t%s\n" % (cls, f.replace(root + "/", ""), b[2], n[2])); out.flush()
print(counts)
