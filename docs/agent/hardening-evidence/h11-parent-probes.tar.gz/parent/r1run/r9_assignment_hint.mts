let p: number | undefined, q: number | undefined;
[p, q] = [1] as (number | undefined)[];
console.log(p, q);
