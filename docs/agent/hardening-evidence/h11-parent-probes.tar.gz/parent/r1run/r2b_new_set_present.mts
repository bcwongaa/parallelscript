const rows: string[][] = [["a", "b", "a"], ["c"]];
for (const [first, ...rest] of rows) console.log(first, rest.length);
const [left, right] = rows;
console.log(new Set(left).size, new Set(right).size);
