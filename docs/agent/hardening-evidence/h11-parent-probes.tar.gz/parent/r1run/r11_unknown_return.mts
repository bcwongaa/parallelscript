function get(o: Record<string, any>, k: string) {
  return o[k];
}
console.log(get({ a: 1 }, "b"));
