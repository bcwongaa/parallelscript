const [, column] = "count".split(":");
const c = Math.random() < 2;
const v: string | undefined = c ? (c ? column : "a") : "b";
console.log(v);
