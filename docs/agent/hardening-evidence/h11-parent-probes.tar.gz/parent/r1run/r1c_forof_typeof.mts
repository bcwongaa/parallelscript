const rows: (string | number)[][] = [["a", 1], ["b"]];
function firstNumber(): number | undefined {
  for (const [k, v] of rows) {
    if (typeof v === "number") return v;
  }
  return undefined;
}
console.log(firstNumber());
