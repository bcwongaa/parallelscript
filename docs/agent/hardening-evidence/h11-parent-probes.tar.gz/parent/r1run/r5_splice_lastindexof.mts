const nums: number[] = [1];
const [start, count] = nums;
const xs = [1, 2, 3];
xs.splice(start, count);
console.log(xs, [1, 2, 1].lastIndexOf(1, count));
