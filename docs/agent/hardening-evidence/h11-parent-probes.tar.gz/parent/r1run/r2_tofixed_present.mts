const [value, digits, radix] = "3.14159 2 16".split(" ").map(Number);
console.log(value.toFixed(digits), (255).toString(radix), parseInt("ff", radix));
