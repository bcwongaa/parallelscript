interface Rec {
  n: number;
}
const cache: Record<string, Rec | null> = { a: { n: 1 }, b: null };
function find(key: string): Rec | undefined {
  const hit = cache[key];
  if (hit === undefined) return undefined;
  if (hit !== null) return hit;
  return undefined;
}
console.log(find("a"), find("b"), find("c"));
