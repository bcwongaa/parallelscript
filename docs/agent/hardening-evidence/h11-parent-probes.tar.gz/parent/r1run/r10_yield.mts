function* pairs([a, b]: string[]): Generator<string | undefined> {
  yield a;
  yield b;
}
console.log([...pairs(["x"])]);
