let a: number | undefined = 0;
[a = 1] = [undefined];
const t: [number | undefined, string] = [undefined, "x"];
let e: number | undefined = 0;
[e = 4] = t;
console.log(a, e);
