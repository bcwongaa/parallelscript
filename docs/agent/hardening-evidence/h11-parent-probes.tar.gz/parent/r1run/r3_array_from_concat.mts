const rows: string[][] = [["a", "b"], ["c"]];
console.log(Array.from(rows[0]), rows[0].concat(rows[1]));
