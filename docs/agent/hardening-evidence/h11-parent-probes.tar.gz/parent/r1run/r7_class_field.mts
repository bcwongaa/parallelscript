const [, column] = "count".split(":");
class Holder {
  col?: string = column;
}
console.log(new Holder().col);
