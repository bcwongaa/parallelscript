function second<T extends readonly unknown[]>([a, b]: T): unknown {
  return b;
}
console.log(second([1, 2] as [number, number]));
console.log(second(["x"] as string[]));
