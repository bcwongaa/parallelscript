interface Opt {
  label?: string;
}
const labels: (string | null)[] = ["x", null];
function opt(i: number): Opt {
  const label = labels[i];
  if (label === undefined || label === null) return {};
  return { label };
}
console.log(opt(0), opt(1), opt(5));
