function* g(s: string): Generator<string | undefined, void, unknown> {
  const [a, b] = s.split(":");
  yield a;
  yield b;
  yield b ? b : "none";
}
async function* ag(s: string): AsyncGenerator<string | undefined> { const [, b] = s.split(":"); yield b; }
function* strict(s: string): Generator<string> { const [, b] = s.split(":"); yield b; }
console.log([...g("x")]);
(async () => { for await (const v of ag("x")) console.log("async", v); try { console.log([...strict("x")]); } catch (e) { console.log("strict threw", (e as Error).name); } })();
