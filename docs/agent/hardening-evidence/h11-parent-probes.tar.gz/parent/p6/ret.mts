async function a1(s: string): Promise<string | undefined> {
  const [, v] = s.split(":");
  return v;
}
async function a2(s: string): Promise<string> {
  const [, v] = s.split(":");
  return v;
}
function* g1(s: string): Generator<number, string | undefined> {
  const [, v] = s.split(":");
  yield 1;
  return v;
}
const a3 = async (s: string): Promise<unknown> => { const [, v] = s.split(":"); return v; };
const a4 = async (s: string) => { const [, v] = s.split(":"); return v; };
class K { c?: string; constructor(s: string) { const [, v] = s.split(":"); this.c = v; } }
class K2 { constructor(public c: string | undefined = "x") {} }
function def(s: string, p: string | undefined = "d"): unknown { const [, q] = s.split(":"); return q ?? p; }
async function main() {
  console.log(await a1("x"), await a3("x"));
  try { console.log(await a2("x")); } catch (e) { console.log("a2 threw", (e as Error).name); }
  try { console.log(await a4("x")); } catch (e) { console.log("a4 threw", (e as Error).name); }
  const it = g1("x"); it.next(); console.log(it.next());
  console.log(new K("x"), new K2(), def("x"));
}
main();
