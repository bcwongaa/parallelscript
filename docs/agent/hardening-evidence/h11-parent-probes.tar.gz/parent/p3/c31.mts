function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
function param([a, b]: string[]): string { return `${a}/${b}`; }
const arrow = ([a, b]: number[]) => [a, b === undefined];
function optElems([a, b]: (number | undefined)[]): unknown { return [a, b]; }
function* gen(): Generator<string> { yield "g"; }
function fromIter([a, b]: Iterable<string>): unknown { return [a, b]; }
show("param", () => param(["x"]));
show("arrow", () => arrow([1]));
show("opt elems", () => optElems([1]));
show("iterable param", () => fromIter(gen()));
show("for-of", () => { const out: unknown[] = []; for (const [k, v] of [["a", "1"], ["b"]]) out.push(k, v); return out; });
show("for-of split", () => { const out: unknown[] = []; for (const [k, v] of ["a=1", "b"].map(s => s.split("="))) out.push(v === undefined ? "none" : v); return out; });
show("nested", () => { const src: string[][] = [["x"]]; const [[a, b]] = src; return [a, b]; });
show("nested obj", () => { const o: { p: number[] } = { p: [1] }; const { p: [a, b] } = o; return [a, b]; });
show("rest pattern", () => { const xs: string[] = ["x", "y"]; const [x, ...[y, z]] = xs; return [x, y, z]; });
show("let pattern", () => { let [a, b] = "a".split(","); return [a, b]; });
show("string param", () => ((([a, b]: string) => [a, b]))("q"));
show("set for-of", () => { const out: unknown[] = []; for (const [a, b] of new Set([[1]])) out.push(a, b); return out; });
show("used as T", () => param(["x"]).length);
show("use b as string", () => { const f = ([a, b]: string[]) => b.length; return f(["x"]); });
