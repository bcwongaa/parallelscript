function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
const [k, column] = "count".split(":");
const c = k.length > 2;
show("cond union", () => { const u: string | undefined = c ? column : "x"; return u; });
show("cond unknown", () => { const u: unknown = c ? column : "x"; return u; });
show("and union", () => { const u: string | false | undefined = c && column; return u; });
show("or union", () => { const u: string | undefined = column || "d"; return u; });
show("nullish", () => { const z: string | undefined = [""][3]; const u: string | undefined = z ?? column; return u; });
show("cond required", () => { const u: string = c ? column : "x"; return u; });
show("return opt", (): string | undefined => column);
show("map set", () => { const m = new Map<string, string | undefined>(); m.set("a", column); return m; });
show("push", () => { const a: (string | undefined)[] = []; a.push(column); return a; });
show("obj prop", () => { const o: { c?: string } = { c: column }; return o; });
show("obj prop null", () => { const o: { c: string | null | undefined } = { c: column }; return o; });
show("assign field", () => { const o: { c?: string } = {}; o.c = column; return o; });
show("required arg", () => { const f = (s: string) => s; return f(column); });
show("required field", () => { const o: { c: string } = { c: column }; return o; });
