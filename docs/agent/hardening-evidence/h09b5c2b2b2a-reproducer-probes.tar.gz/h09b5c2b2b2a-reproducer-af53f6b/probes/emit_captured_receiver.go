package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) < 3 || len(os.Args) > 4 {
		fmt.Fprintln(os.Stderr, "usage: emit_captured_receiver entry.pts output.c [output.bin]")
		os.Exit(2)
	}
	ctx := context.Background()
	code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	if err != nil {
		fail(err)
	}
	if err := os.WriteFile(os.Args[2], []byte(code), 0o644); err != nil {
		fail(err)
	}
	pairs := regexp.MustCompile(`\bpts_fn_M([0-9]+)_make_C([0-9]+)\(`).FindAllStringSubmatch(code, -1)
	unique := map[string]bool{}
	for _, pair := range pairs {
		key := pair[1] + "/" + pair[2]
		if !unique[key] {
			fmt.Printf("class_method_pair=%s\n", key)
			unique[key] = true
		}
	}
	fmt.Printf("AllInstances emitted: lines=%d bytes=%d unique_M_C_pairs=%d\n", strings.Count(code, "\n"), len(code), len(unique))
	if len(os.Args) != 4 {
		return
	}
	tc, err := toolchain.New()
	if err != nil {
		fail(err)
	}
	runtime, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		fail(err)
	}
	output, err := filepath.Abs(os.Args[3])
	if err != nil {
		fail(err)
	}
	if err := tc.CompileProgram(ctx, runtime, []string{os.Args[2]}, output); err != nil {
		fail(err)
	}
	fmt.Println("AllInstances native compiled")
}

func fail(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
