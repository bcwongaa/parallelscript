from __future__ import annotations

import difflib
import hashlib
import pathlib
import tarfile

SCRATCH = pathlib.Path("/tmp/h09b5c2b2b2a-reproducer-af53f6b")
WORKTREE = pathlib.Path("/home/bryan/projects/parallelscript/.claude/worktrees/agent-af53f6b86f9c96be1")
ARCHIVE = pathlib.Path("/tmp/h09b5c2b2b2a-reproducer-af53f6b.tar.gz")
DRIVER = "pts/driver/h09_captured_receiver_flow_test.go"


def digest(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assemble_patches() -> None:
    final = WORKTREE / DRIVER
    original = SCRATCH / "probes/h09_captured_receiver_flow_test.original.go"
    (SCRATCH / "probes/h09_captured_receiver_flow_test.go").write_bytes(final.read_bytes())
    correction = difflib.unified_diff(
        original.read_text().splitlines(keepends=True),
        final.read_text().splitlines(keepends=True),
        fromfile="a/" + DRIVER,
        tofile="b/" + DRIVER,
    )
    (SCRATCH / "contextual_setup_correction.patch").write_text("".join(correction))
    patches = [
        SCRATCH / "captured_receiver_driver.patch",
        SCRATCH / "captured_receiver_sources.patch",
        SCRATCH / "captured_receiver_unknowns.patch",
    ]
    (SCRATCH / "captured_receiver_tests.patch").write_bytes(
        b"".join(path.read_bytes() for path in patches)
    )


def regular_evidence_files() -> list[pathlib.Path]:
    paths = list((SCRATCH / "probes").rglob("*"))
    paths += list((SCRATCH / "logs").rglob("*"))
    paths += list(SCRATCH.glob("*.patch"))
    files = []
    for path in sorted(paths):
        if path.is_symlink():
            raise ValueError(f"Symlink is not evidence: {path}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise ValueError(f"Nonregular evidence: {path}")
        with path.open("rb") as source:
            if source.read(4) == b"\x7fELF":
                raise ValueError(f"ELF is not archived: {path}")
        files.append(path)
    return files


def main() -> None:
    assemble_patches()
    files = regular_evidence_files()
    manifest = SCRATCH / "SHA256SUMS"
    manifest.write_text(
        "".join(f"{digest(path)}  {path.relative_to(SCRATCH)}\n" for path in files)
    )
    files.append(manifest)
    with tarfile.open(ARCHIVE, "w:gz") as archive:
        for path in files:
            archive.add(
                path,
                arcname=str(pathlib.Path(SCRATCH.name) / path.relative_to(SCRATCH)),
                recursive=False,
            )
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        for member in archive.getmembers():
            if not member.isfile() or pathlib.PurePosixPath(member.name).is_absolute():
                raise ValueError(f"Unsafe archive member: {member.name}")
            if ".." in pathlib.PurePosixPath(member.name).parts:
                raise ValueError(f"Unsafe archive path: {member.name}")
    for path in [WORKTREE / DRIVER, SCRATCH / "captured_receiver_tests.patch", SCRATCH / "contextual_setup_correction.patch", manifest, ARCHIVE]:
        print(f"{digest(path)}  {path}")
    print(f"archive_regular_files={len(files)}")


if __name__ == "__main__":
    main()
