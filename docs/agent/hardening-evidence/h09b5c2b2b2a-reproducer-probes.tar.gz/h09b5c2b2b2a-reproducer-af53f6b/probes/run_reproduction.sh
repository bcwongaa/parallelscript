#!/usr/bin/env bash
set -u
set -o pipefail

worktree=/home/bryan/projects/parallelscript/.claude/worktrees/agent-af53f6b86f9c96be1
scratch=/tmp/h09b5c2b2b2a-reproducer-af53f6b
helper="$scratch/emit-captured-receiver.bin"

if [[ "$PWD" != "$worktree" ]]; then
  printf 'Run from assigned isolated worktree: %s\n' "$worktree" >&2
  exit 2
fi

run_capture() {
  local name="$1"
  shift
  printf '%q ' "$@" > "$scratch/logs/$name.command"
  printf '\n' >> "$scratch/logs/$name.command"
  "$@" > "$scratch/logs/$name.stdout" 2> "$scratch/logs/$name.stderr"
  local status=$?
  printf '%s\n' "$status" > "$scratch/logs/$name.exit"
  printf '%s exit=%s\n' "$name" "$status"
}

run_capture base git -C "$worktree" rev-parse HEAD
run_capture driver-red env GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 10m ./pts/driver -run '^TestCaptured'
run_capture helper-build env GOMAXPROCS=1 go build -p 1 -o "$helper" "$scratch/probes/emit_captured_receiver.go"
run_capture diagonal-emit env GOMAXPROCS=1 "$helper" "$scratch/probes/captured_receiver_diagonal.pts" "$scratch/probes/captured_receiver_diagonal.c"

for name in sources unknowns; do
  fixture="$worktree/pts/tests/run/generic_captured_receiver_$name.pts"
  source="$scratch/probes/generic_captured_receiver_$name.pts"
  cp -- "$fixture" "$source"
  cp -- "$source" "$scratch/probes/generic_captured_receiver_$name.mts"
  run_capture "$name-compile" env GOMAXPROCS=1 PTS_HOME=/home/bryan/projects/parallelscript "$helper" "$source" "$scratch/probes/generic_captured_receiver_$name.c" "$scratch/generic_captured_receiver_$name.bin"
  run_capture "$name-native" "$scratch/generic_captured_receiver_$name.bin"
  run_capture "$name-node" /home/bryan/.local/node/bin/node --no-warnings --experimental-transform-types "$scratch/probes/generic_captured_receiver_$name.mts"
  run_capture "$name-compare" cmp -- "$scratch/logs/$name-native.stdout" "$scratch/logs/$name-node.stdout"
done
