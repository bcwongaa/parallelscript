env GOMAXPROCS=1 go build -p 1 -o /tmp/h09b5c2b2b2a-reproducer-af53f6b/emit-captured-receiver.bin /tmp/h09b5c2b2b2a-reproducer-af53f6b/probes/emit_captured_receiver.go 
