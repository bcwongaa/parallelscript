env GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 10m ./pts/driver -run '^TestCaptured'
