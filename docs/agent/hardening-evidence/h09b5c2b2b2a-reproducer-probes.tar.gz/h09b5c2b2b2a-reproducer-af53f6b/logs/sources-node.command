/home/bryan/.local/node/bin/node --no-warnings --experimental-transform-types /tmp/h09b5c2b2b2a-reproducer-af53f6b/probes/generic_captured_receiver_sources.mts 
