git -C /home/bryan/projects/parallelscript/.claude/worktrees/agent-af53f6b86f9c96be1 rev-parse HEAD 
