cmp -- /tmp/h09b5c2b2b2a-reproducer-af53f6b/logs/unknowns-native.stdout /tmp/h09b5c2b2b2a-reproducer-af53f6b/logs/unknowns-node.stdout 
