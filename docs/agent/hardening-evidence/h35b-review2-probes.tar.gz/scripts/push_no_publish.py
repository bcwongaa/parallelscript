#!/usr/bin/env python3
"""Runtime functions that push into (or map_set into) a local array/map made in the same
function and reach a return with no pts_publish after the last push."""
import re, glob, sys
for path in sorted(glob.glob(sys.argv[1] + "/*.c")):
    src = open(path).read()
    # split into functions at lines starting a definition
    for m in re.finditer(r"^[a-z_][^\n;{}]*\([^;{}]*\)\s*\{\n(.*?)^\}", src, re.S | re.M):
        body = m.group(1)
        head = src[m.start():m.start() + 120].split("\n")[0]
        made = re.findall(r"(\w+)\s*=\s*(?:pts_array_of\([^;]*NULL, 0\)|pts_map_new\(|pts_array_of_length\(|pts_typed_array_new\(|new_typed_array\()", body)
        for var in set(made):
            lines = body.split("\n")
            last_fill = None
            for i, l in enumerate(lines):
                if re.search(r"pts_array_push\w*\(\s*\*?" + var + r"\b|pts_map_set\(\s*" + var + r"\b|pts_array_set\(\s*" + var + r"\b|memcpy\(\s*" + var + r"->|pts_typed_array_store\(\s*" + var + r"\b|flatten_\w+\(\s*" + var + r"\b", l):
                    last_fill = i
                if last_fill is not None and "pts_publish()" in l and i > last_fill:
                    last_fill = None
                if last_fill is not None and re.search(r"\breturn\b", l) and i > last_fill:
                    print(f"{path.split('/')[-1]}: {head.strip()[:90]} :: {var} filled at body line {last_fill+1}, returns at {i+1}: {l.strip()[:80]}")
                    break
