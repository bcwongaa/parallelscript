#!/bin/sh
# Rebuilds the review's mutants: three cgen overlays (go build/test -overlay) and two
# runtime homes (PTS_HOME). Run from anywhere; writes under /tmp/h35b/review1.
set -e
R=/tmp/h35b/review1
mkdir -p $R/mut
S=/tmp/h35b/snap3/pts/cgen/classes.go
python3 - "$S" "$R/mut" <<'PY'
import sys
src, out = sys.argv[1], sys.argv[2]
s = open(src).read()
muts = {
  "noobj": ('fmt.Fprintf(&c, "pts_publish(); %s; })", object)', 'fmt.Fprintf(&c, "%s; })", object)'),
  "noescape": ("\treturn reads\n}", "\treturn map[*ir.LocalRef]bool{}\n}"),
  "noinst": ('%s(%s); pts_publish(); %s; })",', '%s(%s); %s; })",'),
}
for name, (old, new) in muts.items():
    assert s.count(old) == 1, name
    open(f"{out}/classes_{name}.go", "w").write(s.replace(old, new))
    open(f"{out}/overlay_{name}.json", "w").write('{"Replace":{"%s":"%s/classes_%s.go"}}' % (src, out, name))
PY
H=$($R/scripts/mkhome.sh tsan-plain-ready)
python3 - "$H" <<'PY'
import sys
p = sys.argv[1] + "/pts/runtime/include/pts.h"
s = open(p).read()
old = "#if defined(__aarch64__) || defined(PTS_READY_ACQUIRES)\n#define PTS_READY(flag) __atomic_load_n(&(flag), __ATOMIC_ACQUIRE)"
assert old in s
open(p, "w").write(s.replace(old, "#if defined(__aarch64__)\n#define PTS_READY(flag) __atomic_load_n(&(flag), __ATOMIC_ACQUIRE)"))
PY
H=$($R/scripts/mkhome.sh runtime-drops)
python3 - "$H" <<'PY'
import sys
H = sys.argv[1] + "/pts/runtime/src/"
def drop(file, anchor):
    p = H + file
    s = open(p).read()
    i = s.index(anchor)
    j = s.index("  pts_publish();\n", i)
    open(p, "w").write(s[:j] + s[j + len("  pts_publish();\n"):])
for f, a in [("array.c", "pts_array *pts_array_keys("), ("dynamic_methods.c", "static pts_value array_map("),
             ("map.c", "pts_map *pts_map_copy("), ("string_methods.c", "pts_array *pts_string_split(pts_string *string"),
             ("typed_array.c", "pts_typed_array *pts_typed_array_from_array("), ("date.c", "static pts_date *new_date("),
             ("integer.c", "pts_value pts_value_from_i64("), ("regexp_object.c", "static pts_regexp *regexp_new("),
             ("generator.c", "static pts_value items_iterator_new("), ("dynamic.c", "static pts_value bind_method("),
             ("array.c", "pts_array *pts_array_of(const pts_type *type")]:
    drop(f, a)
PY
echo done
