#!/bin/sh
# asm.sh file.c triple [extra flags]: the release flags' assembly on stdout
f=$1; triple=$2; shift 2
H=/tmp/h35b/snap4
exec clang --target=$triple -O2 -g0 -ffp-contract=off -fno-math-errno -falign-functions=32 -std=gnu11 -w -I $H/pts/runtime/include -I $H/pts/third_party/bdwgc/include -I $H/pts/third_party/libuv/include "$@" -S -o - "$f"
