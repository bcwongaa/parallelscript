#!/usr/bin/env python3
"""flag_order.py OUTDIR file.pts...: emit-c each program with the snapshot CLI, compile it
for x86-64 with the release flags (-O2) and report each basic block that loads a
module-scope binding (pts_global_X) and, later in the same block, its ready flag: clang
moved the binding's load above its flag's test."""
import concurrent.futures, os, re, subprocess, sys, signal

CLI, HOME = "/tmp/h35b/snap4/pts-bin/pts", "/tmp/h35b/snap4"


def run(cmd, **kw):
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True, text=True, **kw)
    try:
        out, _ = p.communicate(timeout=600)
        return p.returncode, out
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        p.communicate()
        return -1, ""


def analyse(asm):
    hits = []
    func, block = None, []

    def flush():
        seen = {}
        for s in block:
            for g in re.findall(r"(pts_global_\w+)\(%rip\)", s):
                parts = s.split(None, 1)
                op = parts[0]
                if op.startswith("lea"):
                    continue
                if op.startswith("mov") and len(parts) > 1 and parts[1].rstrip().endswith(g + "(%rip)") and not parts[1].startswith(g):
                    continue  # a store
                if g.endswith("_ready"):
                    base = g[: -len("_ready")]
                    if base in seen:
                        hits.append(f"{func}: {seen[base]}  ...then {s}")
                else:
                    seen.setdefault(g, s)

    for line in asm.split("\n"):
        s = line.strip()
        m = re.match(r"^([A-Za-z_.][\w.]*):", s)
        if m:
            flush()
            block = []
            if not s.startswith(".L"):
                func = m.group(1)
            continue
        if not s or s.startswith("#") or s.startswith("."):
            continue
        block.append(s)
        if re.match(r"^(j[a-z]+|ret|call)", s):
            flush()
            block = []
    flush()
    return hits


def one(path, outdir):
    name = os.path.basename(os.path.dirname(path)) + "_" + os.path.splitext(os.path.basename(path))[0]
    c = os.path.join(outdir, name + ".c")
    code, _ = run([CLI, "emit-c", path, "-o", c], env=dict(os.environ, PTS_HOME=HOME), cwd=os.path.dirname(path))
    if code != 0:
        return name, None
    code, out = run(["/tmp/h35b/review2/scripts/asm.sh", c, "x86_64-linux-gnu"])
    os.remove(c)
    if code != 0:
        return name, None
    return name, analyse(out)


def main(a):
    outdir = a[0]
    os.makedirs(outdir, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(4) as pool:
        for name, hits in pool.map(lambda p: one(p, outdir), a[1:]):
            if hits is None:
                print(f"{name}: BUILD", flush=True)
                continue
            for h in hits:
                print(f"{name}: {h}", flush=True)
    print("DONE", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
