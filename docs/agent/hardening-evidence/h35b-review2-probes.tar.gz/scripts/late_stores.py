#!/usr/bin/env python3
"""Rough scan: a variable assigned from a function that publishes its result, then written
through (var->x = ..., memcpy(var->...), pts_*_store(var, ...)) before the next pts_publish."""
import re, sys, glob
makers = r"(pts_string_from_\w+|pts_string_concat|pts_array_of\w*|pts_map_new|pts_map_copy|pts_set_of_array|pts_typed_array_new|pts_typed_array_slice|pts_typed_array_from_\w+|pts_arraybuffer_new|new_view|new_typed_array|pts_error_new|pts_system_error_new|pts_coded_error_new|pts_aggregate_error_new|pts_uv_error_new|pts_cell_new|pts_cell_copy|new_promise|new_date|regexp_new|pts_match_array_at|record_of|pts_value_from_i64|pts_value_from_u64|pts_array_copy\w*|new_array|pts_array_slice|pts_promise_pending)"
for path in sorted(glob.glob(sys.argv[1] + "/*.c")):
    lines = open(path).read().split("\n")
    for i, line in enumerate(lines):
        m = re.search(r"(\w+)\s*=\s*(?:\([^)]*\)\s*)?(?:pts_value_as_object\()?" + makers + r"\(", line)
        if not m: continue
        var = m.group(1)
        for j in range(i + 1, min(i + 25, len(lines))):
            l = lines[j]
            if "pts_publish()" in l or re.match(r"^\}", l): break
            if re.search(r"\b" + var + r"->\w+(\[[^\]]*\])?\s*=[^=]", l) or re.search(r"(memcpy|memset|memmove|pts_copy_shared)\(\s*" + var + r"->", l) or re.search(r"pts_typed_array_store\(\s*" + var + r"\b", l) or re.search(r"element_store\(\s*" + var + r"->", l):
                print(f"{path.split('/')[-1]}:{i+1}: {var} from {m.group(2)}; later write at {j+1}: {l.strip()}")
