#!/bin/sh
# mkhome.sh NAME: a PTS_HOME at /tmp/h35b/review2/homes/NAME with a copy of the snapshot's
# runtime (to mutate) and its third_party linked; prints the path.
set -e
d=/tmp/h35b/review2/homes/$1
rm -rf "$d"; mkdir -p "$d/pts"
cp -r /tmp/h35b/snap4/pts/runtime "$d/pts/runtime"
ln -s /tmp/h35b/snap4/pts/third_party "$d/pts/third_party"
echo "$d"
