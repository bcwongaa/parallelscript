#!/bin/sh
cd /tmp/h35b/review2/bench
for b in word_count word_freq sum_reduce; do
  for v in snap3 snap4; do
    PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=/dev/null ./$v-$b > out-$v-$b.txt 2> cg-$v-$b.log &
  done
  wait
  printf '%-16s snap3 %s snap4 %s\n' $b "$(grep -o 'Collected : [0-9]*' cg-snap3-$b.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' cg-snap4-$b.log | grep -o '[0-9]*$')" >> cg.txt
done
touch cg.done
