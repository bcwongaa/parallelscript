def m4_methods(k):
    out = [f"// C172(c): {k} method values, each passed to its own one-type consumer (review round 1's s_N).",
           "class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
    for i in range(k):
        out.append(f"class V{i} {{ constructor(public n: number) {{}} }}")
        out.append(f"function use{i}(f: Factory): number {{ const b: Box<V{i}> = f(new V{i}({i})); return b.value.n; }}")
        out += [f"class M{i} {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
    for i in range(k):
        out.append(f"console.log(use{i}(new M{i}().make));")
    write("m4_growth", f"methods_{k}", "\n".join(out) + "\n")
