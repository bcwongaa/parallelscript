package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

type outcome struct {
	Entry  string `json:"entry"`
	Mode   string `json:"mode"`
	Stage  string `json:"stage"`
	Exit   int    `json:"exit"`
	Stdout string `json:"stdout"`
	Stderr string `json:"stderr"`
	Error  string `json:"error,omitempty"`
}

func record(entry, mode, stage string, exit int, stdout, stderr string, err error) {
	r := outcome{Entry: entry, Mode: mode, Stage: stage, Exit: exit, Stdout: stdout, Stderr: stderr}
	if err != nil {
		r.Error = err.Error()
	}
	if err := json.NewEncoder(os.Stdout).Encode(r); err != nil {
		panic(err)
	}
}

func run(ctx context.Context, entry, mode, name string, args ...string) {
	cmd := exec.CommandContext(ctx, name, args...)
	var stdout, stderr bytes.Buffer
	cmd.Stdout, cmd.Stderr = &stdout, &stderr
	err := cmd.Run()
	exit := 0
	if cmd.ProcessState != nil {
		exit = cmd.ProcessState.ExitCode()
	} else if err != nil {
		exit = -1
	}
	record(entry, mode, "run", exit, stdout.String(), stderr.String(), err)
}

func probe(ctx context.Context, tc *toolchain.Toolchain, rt *toolchain.Runtime, entry, outputDir string) {
	prefix := filepath.Join(outputDir, filepath.Base(entry))
	c, err := driver.EmitCWith(ctx, entry, lower.AllInstances)
	if err != nil {
		record(entry, "AllInstances", "emit", 1, "", "", err)
	} else {
		cPath := prefix + ".all.c"
		if err := os.WriteFile(cPath, []byte(c), 0o644); err != nil {
			panic(err)
		}
		binary := prefix + ".all.bin"
		if err := tc.CompileProgram(ctx, rt, []string{cPath}, binary); err != nil {
			record(entry, "AllInstances", "compile", 1, "", "", err)
		} else {
			run(ctx, entry, "AllInstances", binary)
		}
		os.Remove(binary)
	}
	binary := prefix + ".default.bin"
	if err := driver.Build(ctx, entry, binary); err != nil {
		record(entry, "default", "build", 1, "", "", err)
	} else {
		run(ctx, entry, "default", binary)
	}
	os.Remove(binary)
	mts := prefix + ".mts"
	source, err := os.ReadFile(entry)
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(mts, source, 0o644); err != nil {
		panic(err)
	}
	run(ctx, entry, "Node", "/home/bryan/.local/node/bin/node", "--no-warnings", "--experimental-transform-types", mts)
}

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "usage: native_probe OUTPUT_DIR ENTRY...")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Minute)
	defer cancel()
	if err := os.MkdirAll(os.Args[1], 0o755); err != nil {
		panic(err)
	}
	tc, err := toolchain.New()
	if err != nil {
		panic(err)
	}
	rt, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		panic(err)
	}
	for _, entry := range os.Args[2:] {
		probe(ctx, tc, rt, entry, os.Args[1])
	}
}
