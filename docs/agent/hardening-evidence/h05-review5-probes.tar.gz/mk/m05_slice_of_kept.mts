const a = [1];
const nested = [a];
const r = [1].flatMap<(number | string)[]>(() => nested.slice());
a.push(5);
console.log(r[0], nested.length);
