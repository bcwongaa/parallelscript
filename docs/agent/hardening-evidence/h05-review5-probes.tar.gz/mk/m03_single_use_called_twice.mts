const out = [[1], [2]];
const r = [1, 2].flatMap<(number | string)[]>(() => out);
console.log(r.length, r[0] === r[2]);
r[0].push("x");
console.log(r[2]);
