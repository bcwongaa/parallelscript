const ns = [1, 2];
const items: (number[] | string)[] = [ns, "a"];
const r: ((number | string)[] | string)[] = items;
ns.push(3);
console.log(r[0]);
