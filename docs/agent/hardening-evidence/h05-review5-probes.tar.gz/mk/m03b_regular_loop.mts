const out = [[1], [2]];
const rs: (number | string)[][][] = [];
for (let i = 0; i < 2; i++) {
  const r: (number | string)[][] = out;
  rs.push(r);
}
console.log(rs[0] === rs[1], rs[0][0] === rs[1][0]);
