const a = [1];
const out = [a, [2]];
const r: (number | string)[][] = out;
a.push(9);
console.log(r[0]);
