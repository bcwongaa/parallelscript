const ns = [1, 2];
const items: (number[] | string)[] = [ns, "a"];
const r = [1].flatMap<(number | string)[] | string>(() => items);
ns.push(3);
console.log(r[0], items.length);
