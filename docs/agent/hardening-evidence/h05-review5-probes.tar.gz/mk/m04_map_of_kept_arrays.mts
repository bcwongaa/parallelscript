class H { arr = [1, 2]; }
const hs = [new H(), new H()];
const r = [1].flatMap<(number | string)[]>(() => hs.map((h) => h.arr));
hs[0].arr.push(3);
console.log(r[0]);
