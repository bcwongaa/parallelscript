interface J { x: number | string }
class C { constructor(public x: number) {} }
class D { constructor(public x: string) {} }
const c = new C(1);
const d = new D("a");
const r = [1, 2].flatMap<J>((n) => [n > 1 ? c : d]);
c.x = 5;
console.log(r.length, r[1].x);
