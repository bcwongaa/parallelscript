class C { x = 1 }
class D { x = 2 }
const c = new C();
const r = [1].flatMap<D | number>(() => [c, 3]);
c.x = 5;
const v = r[0];
console.log(r.length, typeof v === "number" ? v : v.x);
