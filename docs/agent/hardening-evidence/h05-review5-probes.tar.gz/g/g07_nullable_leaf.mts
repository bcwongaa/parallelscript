interface J { x: number | string }
class C { constructor(public x: number) {} }
class Holder { constructor(public c: C | null) {} }
const c = new C(1);
const hs = [new Holder(c), new Holder(null)];
const r = hs.flatMap<J | null>((h) => [h.c]);
c.x = 5;
console.log(r.length, r[0]?.x, r[1]);
