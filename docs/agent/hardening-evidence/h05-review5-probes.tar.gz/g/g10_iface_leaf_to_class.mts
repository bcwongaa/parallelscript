interface J { x: number }
class D { x = 2 }
const js: J[] = [new D(), { x: 3 }];
const r = [1].flatMap<D>(() => js);
console.log(r.length, r[0].x, r[1].x);
