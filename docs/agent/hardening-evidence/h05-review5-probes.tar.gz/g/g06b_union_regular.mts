interface Row { id: number; value: number | null }
class Filled { constructor(public id: number, public value: number) {} }
class Missing { value = null; constructor(public id: number) {} }
const f = new Filled(1, 10);
const g: (Filled | Missing)[] = [f, new Missing(2)];
const rows: Row[] = g.map((x) => x);
const rows2 = g.map<Row>((x) => x);
f.value = 99;
console.log(rows[0].value, rows2[0].value);
