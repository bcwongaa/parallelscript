interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const cs = [c];
const r: J[] = [...cs];
c.x = 5;
console.log(r.length, r[0].x);
