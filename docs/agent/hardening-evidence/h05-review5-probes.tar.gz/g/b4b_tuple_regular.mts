const p: [number, string] = [1, "a"];
const r: [number, string | number][] = [p];
const r2 = [1].map<[number, string | number]>(() => p);
p[1] = "b";
console.log(r.length, r[0][1], r2[0][1]);
