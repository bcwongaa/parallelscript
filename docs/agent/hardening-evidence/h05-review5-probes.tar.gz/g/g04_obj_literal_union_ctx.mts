interface J { x: number | string }
class C { constructor(public x: number) {} }
interface W { c: J }
const cobj = new C(1);
const r = [1].flatMap<W | number>(() => [{ c: cobj }, 2]);
cobj.x = 5;
const w = r[0];
console.log(r.length, typeof w === "number" ? w : w.c.x);
