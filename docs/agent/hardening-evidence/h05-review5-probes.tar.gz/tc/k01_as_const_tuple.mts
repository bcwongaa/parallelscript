const p = [1, "a"] as const;
const r = [1].flatMap<readonly [number, string]>(() => [p]);
console.log(r[0] === p, r[0][1]);
const q = [2, "b"] as const;
const r2 = [1].flatMap((): (readonly [number, string])[] => [q]);
console.log(r2[0] === q);
enum E { A, B }
const t: [E, string] = [E.B, "e"];
const r3 = [1].flatMap<[number, string]>(() => [t]);
console.log(r3[0][0]);
