const p = [1, "a"] as const;
const r: (readonly [number, string])[] = [p];
console.log(r[0] === p);
enum E { A, B }
const t: [E, string] = [E.B, "e"];
const r3: [number, string][] = [t];
console.log(r3[0][0]);
