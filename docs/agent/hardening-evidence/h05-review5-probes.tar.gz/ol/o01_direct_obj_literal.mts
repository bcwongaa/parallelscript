interface J { x: number }
const r = [1, 2].flatMap<J>((i) => ({ x: i }));
console.log(JSON.stringify(r));
const r2 = [1].flatMap<{ n: number; s: string }>(() => ({ n: 1, s: "a" }));
console.log(JSON.stringify(r2));
const j: J = { x: 3 };
const r3 = [1].flatMap<{ c: J }>(() => ({ c: j }));
console.log(r3[0].c === j);
