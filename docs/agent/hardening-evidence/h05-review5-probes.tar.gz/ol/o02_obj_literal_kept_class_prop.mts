class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<{ c: C }>(() => ({ c }));
c.x = 5;
console.log(r[0].c.x, r[0].c === c);
