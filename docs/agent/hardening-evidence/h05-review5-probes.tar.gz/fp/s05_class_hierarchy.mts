class Base { constructor(public n: number) {} }
class Sub extends Base { extra = 1; }
class Sub2 extends Sub {}
const s = new Sub(1), s2 = new Sub2(2);
const r = [1].flatMap<Base>(() => [s, s2]);
console.log(r.length, r[0] === s, r[1] === s2, r[1] instanceof Sub2);
const r2 = [1].flatMap((): Base[] => [s]);
console.log(r2[0] === s);
const subs: Sub[] = [s, s2];
const r3 = [1].flatMap<Base>(() => subs);
console.log(r3[1] === s2);
const r4 = [1].flatMap<Base | null>(() => [s, null]);
console.log(r4[0] === s, r4[1]);
const r5 = [1].flatMap<Base>((): Sub | Sub2 => s2);
console.log(r5[0] === s2);
