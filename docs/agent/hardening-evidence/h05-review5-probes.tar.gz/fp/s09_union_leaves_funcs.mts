const f = (x: number) => x + 1;
const fs: (((x: number) => number) | null)[] = [f, null];
const r = [1].flatMap<((x: number) => number) | null>(() => fs);
console.log(r.length, r[0] === f, r[1]);
const r2 = [1].flatMap<((x: number) => number) | string>(() => [f, "s"]);
console.log(r2[0] === f, typeof r2[1]);
