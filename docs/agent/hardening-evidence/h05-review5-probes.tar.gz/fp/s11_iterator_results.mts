function* g() { yield 1; yield 2; }
const it = g();
const r = [1, 2].flatMap(() => [it.next()]);
console.log(r.map((x) => x.value));
const it2 = g();
const r2 = [1].flatMap<IteratorResult<number>>(() => [it2.next()]);
console.log(r2[0].done, r2[0].value);
const it3 = [5, 6][Symbol.iterator]();
const res = it3.next();
const r3 = [1].flatMap<{ done?: boolean; value: number | undefined }>(() => [res]);
console.log(r3[0].value, r3[0] === res);
const r4 = [1].flatMap<IteratorResult<number, undefined> | null>(() => [res, null]);
console.log(r4[0] === res, r4[1]);
