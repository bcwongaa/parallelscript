enum E { A, B }
enum S { X = "x", Y = "y" }
const es: E[] = [E.A, E.B];
const r = [1].flatMap<E | S>(() => es);
console.log(r);
const r2 = [1].flatMap<number>(() => es);
console.log(r2);
const t: readonly [number, string] = [1, "a"];
const r3 = [1].flatMap<readonly [number, string]>(() => [t]);
console.log(r3[0] === t);
const ro: readonly number[] = [1, 2];
const r4 = [1].flatMap<readonly number[]>(() => [ro]);
console.log(r4[0] === ro);
const r5 = [1].flatMap(() => ro);
console.log(r5);
