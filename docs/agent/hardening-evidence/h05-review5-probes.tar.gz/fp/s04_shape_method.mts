const o = { x: 1, get(): number { return this.x; } };
const r = [1].flatMap<{ x: number; get(): number }>(() => [o]);
o.x = 4;
console.log(r[0].get(), r[0] === o);
