class C { constructor(public x: number) {} }
const c = new C(1);
const maybe: (C | null)[] = [c, null];
const r = [1].flatMap<C | null>(() => maybe);
console.log(r.length, r[0] === c, r[1]);
const und: (C | undefined)[] = [c, undefined];
const r2 = [1].flatMap<C | undefined>(() => und);
console.log(r2[0] === c, r2[1]);
const r3 = [1].flatMap<C | null | undefined>(() => [c, null, undefined]);
console.log(r3[0] === c, r3[1], r3[2]);
const nums: (number | null)[] = [1, null];
const r4 = [1].flatMap<number | null | string>(() => nums);
console.log(r4);
