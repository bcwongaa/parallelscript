interface Named { name: string }
class A implements Named { constructor(public name: string) {} }
class B extends A { other = 2 }
const a = new A("a"), b = new B("b");
const r = [1].flatMap<Named>(() => [a, b]);
a.name = "z";
console.log(r[0].name, r[0] === a, r[1] === b);
const as: A[] = [a, b];
const r2 = [1].flatMap<Named>(() => as);
console.log(r2[0] === a);
const r3 = [1].flatMap<Named | undefined>(() => [a, undefined]);
console.log(r3[0] === a, r3[1]);
