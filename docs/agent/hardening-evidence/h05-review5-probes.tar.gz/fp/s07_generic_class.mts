class Box<T> { constructor(public v: T) {} }
const b = new Box(1);
const r = [1, 2].flatMap(() => [b]);
console.log(r.length, r[0] === b, r[1] === b);
const r2 = [1].flatMap<Box<number>>(() => [b, new Box(3)]);
console.log(r2[0] === b, r2[1].v);
const bs = [new Box("s")];
const r3 = [1].flatMap<Box<string>>(() => bs);
console.log(r3[0] === bs[0]);
function f<T>(x: T): Box<T>[] { const bx = new Box(x); return [1].flatMap(() => [bx]); }
console.log(f(5)[0].v, f("q")[0].v);
