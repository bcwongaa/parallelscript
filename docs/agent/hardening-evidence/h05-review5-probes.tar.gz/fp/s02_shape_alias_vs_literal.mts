type P = { x: number };
function mk(): { x: number } { return { x: 1 }; }
const a = mk();
const r = [1].flatMap<P>(() => [a, a]);
a.x = 7;
console.log(r[0].x, r[0] === a);
interface Q { x: number }
const q: Q = { x: 2 };
const r2 = [1].flatMap<P>(() => [q]);
q.x = 9;
console.log(r2[0].x, r2[0] === q);
const r3 = [1].flatMap<Q>(() => [a]);
console.log(r3[0] === a);
