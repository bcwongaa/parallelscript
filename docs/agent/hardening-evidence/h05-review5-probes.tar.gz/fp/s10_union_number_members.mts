const xs: (number | string)[] = [1, "a"];
const r = [1].flatMap<number | string | boolean>(() => xs);
console.log(r);
const ys: (number | string | null)[][] = [[1, "a", null]];
const r2 = [1].flatMap<(number | string | null)[]>(() => ys);
console.log(r2, r2[0] === ys[0]);
