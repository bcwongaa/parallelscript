// flatMap stores the leaves of its callback's arrays as they are: a class instance that
// provides an interface is the same object (a later write shows through it), a generic
// function is a callback like another (review round 4, R4-2: PTS1001 for its `T[]` result),
// and the arrays of a new array or of a const used once are new too (R4-8: PTS1001).
function dup<T>(x: T): T[] {
  return [x, x];
}
console.log([1, 2].flatMap(dup));
const ys: string[] = ["a"].flatMap(dup);
console.log(ys);
const wrap = <T,>(x: T): T[] => [x];
console.log([1, 2].flatMap(wrap));
function orNone<T>(x: T | null): T[] {
  return x === null ? [] : [x];
}
const maybe: (number | null)[] = [1, null, 3];
console.log(maybe.flatMap(orNone));
const ns = [1, 2];
console.log([1].flatMap<(number | string)[]>(() => ns.map((m) => [m])));
const out = [[1], [2]];
console.log([1].flatMap<(number | string)[]>(() => out));
interface Named {
  name: string;
}
class Person {
  constructor(public name: string) {}
}
const ann = new Person("ann");
const people: Person[] = [ann];
const named = [1].flatMap<Named>(() => people);
ann.name = "anne";
console.log(named[0] === ann, named[0].name);
const listed = [1].flatMap((): Named[] => [ann]);
console.log(listed[0] === ann);

// expect:
// [ 1, 1, 2, 2 ]
// [ 'a', 'a' ]
// [ 1, 2 ]
// [ 1, 3 ]
// [ [ 1 ], [ 2 ] ]
// [ [ 1 ], [ 2 ] ]
// true anne
// true
