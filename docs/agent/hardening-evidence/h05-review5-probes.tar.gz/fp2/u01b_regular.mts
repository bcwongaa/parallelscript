const i = 1;
const r: ((number | string)[] | string)[] = [i === 1 ? [i] : "s"];
console.log(JSON.stringify(r));
