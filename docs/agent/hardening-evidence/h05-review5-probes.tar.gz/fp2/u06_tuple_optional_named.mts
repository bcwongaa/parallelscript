const p: [a: number, b: string] = [1, "a"];
const r = [1].flatMap<[number, string]>(() => [p]);
p[1] = "b";
console.log(r[0][1], r[0] === p);
const q: [number, string] = [2, "c"];
const r2 = [1].flatMap<[x: number, y: string]>(() => [q]);
console.log(r2[0] === q);
