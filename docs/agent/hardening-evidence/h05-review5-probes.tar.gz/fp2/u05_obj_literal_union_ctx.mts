interface P { kind: "p"; n: number }
interface Q { kind: "q"; s: string }
const r = [1, 2].flatMap<P | Q>((i) => (i === 1 ? { kind: "p", n: i } : [{ kind: "q", s: "x" }]));
console.log(JSON.stringify(r));
const r2 = [1].flatMap<P | Q>(() => ({ kind: "p" as const, n: 1 }));
console.log(JSON.stringify(r2));
