interface J { x: number }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r = [1].flatMap<{ c: J }>(() => [{ c: cobj }]);
cobj.x = 5;
console.log(r.length, r[0].c.x, r[0].c === cobj);
