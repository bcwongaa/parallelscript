const p: [number, string] = [1, "a"];
const r: [number, string?][] = [p];
p[1] = "b";
console.log(r[0][1]);
