class H { arr = [1, 2]; }
const hs = [new H()];
const r = [1].flatMap<(number | string)[]>(() => hs.map((h) => h.arr));
hs[0].arr.push(3);
console.log(JSON.stringify(r));
const out = [[1], [2]];
const r2 = [1, 2].flatMap<(number | string)[]>(() => out);
console.log(r2.length, r2[0] === r2[2]);
