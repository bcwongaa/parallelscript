const i = 1;
const r: ((number | string)[] | null)[] = [i === 1 ? [i] : null];
console.log(JSON.stringify(r));
