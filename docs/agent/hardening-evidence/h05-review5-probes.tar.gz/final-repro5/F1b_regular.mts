function* g() { yield 1; yield 2; }
const it = g();
const r: IteratorResult<number>[] = [it.next()];
console.log(r.length, r[0].done, r[0].value);
const o = { done: false as const, value: 7 };
const r2: IteratorResult<number>[] = [o];
console.log(r2[0] === o);
