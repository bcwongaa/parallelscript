const pairs: [number, string][] = [[1, "a"], [2, "b"]];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => pairs)));
