const r = [1, 2].flatMap<(number | string)[] | null>((i) => [i === 1 ? [i] : null]);
console.log(JSON.stringify(r));
