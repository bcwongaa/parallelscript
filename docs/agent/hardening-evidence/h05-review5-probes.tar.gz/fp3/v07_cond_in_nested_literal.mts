const r = [1, 2].flatMap<((number | string)[] | string)[]>((i) => [[i === 1 ? [i] : "s"]]);
console.log(JSON.stringify(r));
