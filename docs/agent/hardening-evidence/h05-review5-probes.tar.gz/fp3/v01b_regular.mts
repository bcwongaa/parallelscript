const i = 1;
const r: (number | string)[][] = [i === 1 ? [i] : [i, i]];
console.log(JSON.stringify(r));
