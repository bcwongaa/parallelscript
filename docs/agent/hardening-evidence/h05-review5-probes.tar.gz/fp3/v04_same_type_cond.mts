const r = [1, 2].flatMap((i) => [i === 1 ? [i] : null]);
console.log(JSON.stringify(r));
const r2 = [1, 2].flatMap<number[] | null>((i) => [i === 1 ? [i] : null]);
console.log(JSON.stringify(r2));
