const r = [1, 2].flatMap<number | number[]>((i) => [i === 1 ? i : [i]]);
console.log(JSON.stringify(r));
const r2 = [1, 2].flatMap<number | (number | string)[]>((i) => [i === 1 ? i : [i]]);
console.log(JSON.stringify(r2));
