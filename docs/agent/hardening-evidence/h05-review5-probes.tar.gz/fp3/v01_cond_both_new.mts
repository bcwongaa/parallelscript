const r = [1, 2].flatMap<(number | string)[]>((i) => [i === 1 ? [i] : [i, i]]);
console.log(JSON.stringify(r));
