const m = new Map<number, number[]>();
const r = [1, 2].flatMap<(number | string)[]>((i) => [m.get(i) ?? [0]]);
console.log(JSON.stringify(r));
