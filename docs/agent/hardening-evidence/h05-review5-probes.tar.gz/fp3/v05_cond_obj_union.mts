interface J { x: number }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1, 2].flatMap<J | null>((i) => [i === 1 ? c : null]);
c.x = 4;
console.log(r.length, r[0] !== null ? r[0].x : -1, r[1]);
