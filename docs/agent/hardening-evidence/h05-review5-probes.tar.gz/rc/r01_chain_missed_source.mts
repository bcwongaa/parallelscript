interface Opt { name: string; note?: string }
interface Opt2 { name: string; note?: string; extra?: number }
class A { constructor(public name: string) {} }
class B extends A { extra = "s" }
const as: A[] = [new B("b")];
const r = [1].flatMap<Opt>(() => as);
const o2: Opt2 = r[0];
console.log(o2.name, o2.extra);
