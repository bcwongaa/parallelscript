interface Opt { name: string; note?: string }
interface Opt2 { name: string; note?: string; extra?: number }
class A { constructor(public name: string) {} }
class B extends A { extra = "s" }
const as: A[] = [new B("b")];
const one: Opt = as[0];
const o2: Opt2 = one;
console.log(o2.name, o2.extra);
