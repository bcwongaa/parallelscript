interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B extends A { note = 5 }
function f<T>(t: T, a: A): Opt { const o: Opt = a; return o; }
console.log(f(1, new A("a")).name, f("s", new B("b")).name);
