interface Opt { name: string; note?: string }
interface Base { name: string }
const x = { name: "x", note: 3 };
const asBase: Base = x;
const one: Opt = asBase;
console.log(one.name);
