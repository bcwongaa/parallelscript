interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B extends A { note = 5 }
class C { constructor(public name: number) {} }
const as: A[] = [new A("a")];
const one: Opt = as[0];
console.log(one.name);
