interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B extends A { note = 5 }
function f<T>(t: T, as: A[]): Opt[] { return [t].flatMap<Opt>(() => as); }
console.log(f(1, [new A("a")]).length, f("s", [new B("b")]).length);
