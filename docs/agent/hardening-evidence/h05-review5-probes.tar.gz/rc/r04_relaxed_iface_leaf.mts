interface Opt { name: string; note?: string }
interface Base { name: string }
const x = { name: "x", note: 3 };
const asBase: Base = x;
const bases: Base[] = [asBase];
const r = [1].flatMap<Opt>(() => bases);
console.log(r.length);
