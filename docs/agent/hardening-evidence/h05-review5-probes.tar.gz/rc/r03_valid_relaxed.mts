interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B extends A { note = "n" }
const a = new A("a"), b = new B("b");
const as: A[] = [a, b];
const r = [1].flatMap<Opt>(() => as);
a.name = "changed";
console.log(r.length, r[0].name, r[0].note, r[1].note);
const r2 = [1].flatMap<Opt | null>(() => [a, null]);
console.log(r2[0] !== null ? r2[0].name : "", r2[1]);
