function* g() { yield 1; }
const it = g();
const kept = it.next();
const r = [1, 2].flatMap<IteratorResult<number>>(() => [kept]);
console.log(r.length, r[0] === kept, r[1] === kept);
const r2 = [1].flatMap<IteratorResult<number> | number>(() => [kept, 4]);
console.log(r2[0] === kept, r2[1]);
