const it3 = [5, 6][Symbol.iterator]();
const res = it3.next();
const r3 = [1].flatMap<{ done?: boolean; value: number | undefined }>(() => [res]);
console.log(r3[0].value, r3[0] === res);
