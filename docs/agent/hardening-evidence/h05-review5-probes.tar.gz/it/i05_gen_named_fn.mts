function* g() { yield 1; yield 2; }
const it = g();
function step(): IteratorResult<number>[] { return [it.next()]; }
const r = [1].flatMap(step);
console.log(r[0].value);
const r2 = [1].flatMap((): IteratorResult<number>[] => [it.next()]);
console.log(r2[0].value);
