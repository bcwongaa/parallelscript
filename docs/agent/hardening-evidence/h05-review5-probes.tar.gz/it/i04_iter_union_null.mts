const it3 = [5, 6][Symbol.iterator]();
const res = it3.next();
const r4 = [1].flatMap<IteratorResult<number, undefined> | null>(() => [res, null]);
console.log(r4[0] === res, r4[1]);
