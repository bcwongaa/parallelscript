class Counter implements Iterator<number> {
  n = 0;
  next(): IteratorResult<number> { return this.n < 2 ? { done: false, value: this.n++ } : { done: true, value: undefined }; }
}
const c = new Counter();
const r = [1, 2, 3].flatMap(() => [c.next()]);
console.log(r.map((x) => x.done));
const c2 = new Counter();
const r2 = [1, 2].flatMap<IteratorResult<number>>(() => [c2.next()]);
console.log(r2.map((x) => x.value));
