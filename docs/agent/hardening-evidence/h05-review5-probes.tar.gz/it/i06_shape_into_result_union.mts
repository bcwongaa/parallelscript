const o = { done: false as const, value: 1 };
const r = [1].flatMap<IteratorResult<number>>(() => [o]);
console.log(r.length, r[0] === o, r[0].value);
const regular: IteratorResult<number>[] = [o];
console.log(regular[0] === o);
