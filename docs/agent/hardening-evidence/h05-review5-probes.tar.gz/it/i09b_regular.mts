function* g() { yield 1; }
const it = g();
const kept = it.next();
const r: IteratorResult<number>[] = [kept, kept];
console.log(r.length, r[0] === kept);
const r2: (IteratorResult<number> | number)[] = [kept, 4];
console.log(r2[0] === kept, r2[1]);
