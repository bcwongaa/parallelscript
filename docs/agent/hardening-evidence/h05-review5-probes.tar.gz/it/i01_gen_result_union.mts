function* g() { yield 1; yield 2; }
const it2 = g();
const r2 = [1].flatMap<IteratorResult<number>>(() => [it2.next()]);
console.log(r2.length, r2[0].done, r2[0].value);
