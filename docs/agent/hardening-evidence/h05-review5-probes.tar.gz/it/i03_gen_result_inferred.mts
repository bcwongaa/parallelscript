function* g() { yield 1; yield 2; }
const it = g();
const r = [1, 2].flatMap(() => [it.next()]);
console.log(r.map((x) => x.value));
const it4 = g();
const r4 = [1, 2].flatMap(() => it4.next());
console.log(r4.map((x) => x.done));
