class Step { done = false as const; constructor(public value: number) {} }
const s = new Step(3);
const r = [1].flatMap<IteratorResult<number>>(() => [s]);
console.log(r.length, r[0] === s, r[0].value);
const regular: IteratorResult<number>[] = [s];
console.log(regular[0] === s);
