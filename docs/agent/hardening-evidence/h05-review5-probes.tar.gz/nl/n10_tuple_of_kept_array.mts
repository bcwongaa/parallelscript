const kept = [1, 2];
const r = [1].flatMap<[(number | string)[], number]>(() => [[kept, 1]]);
kept.push(3);
console.log(JSON.stringify(r));
