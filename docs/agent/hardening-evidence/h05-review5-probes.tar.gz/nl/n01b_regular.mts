interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r: (J[] | string[])[] = [[cobj]];
cobj.x = 5;
const first = r[0];
console.log(r.length, typeof first[0] === "string" ? first[0] : first[0].x);
