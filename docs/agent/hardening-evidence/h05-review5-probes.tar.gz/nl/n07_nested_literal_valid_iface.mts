interface J { x: number }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r = [1].flatMap<J[]>(() => [[cobj], [cobj, cobj]]);
cobj.x = 5;
console.log(r.length, r[0][0].x, r[0][0] === cobj, r[1][1] === cobj);
const r2 = [1].flatMap<(J | null)[][]>(() => [[[cobj, null]]]);
console.log(r2[0][0][0] === cobj, r2[0][0][1]);
