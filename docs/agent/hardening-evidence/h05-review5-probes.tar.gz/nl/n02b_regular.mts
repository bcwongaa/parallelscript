interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r: [J, number][] = [[cobj, 1]];
cobj.x = 5;
console.log(r.length, r[0][0].x);
