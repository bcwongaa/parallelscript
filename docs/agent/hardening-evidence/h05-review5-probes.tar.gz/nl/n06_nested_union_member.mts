interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r = [1].flatMap<J[] | number>(() => [[cobj], 3]);
cobj.x = 5;
const f = r[0];
console.log(r.length, typeof f === "number" ? f : f[0].x);
