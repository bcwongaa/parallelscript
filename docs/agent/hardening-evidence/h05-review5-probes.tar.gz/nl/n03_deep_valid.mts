const kept = [1, 2];
const r = [1].flatMap<(number[] | string)[][]>(() => [[[kept, "s"]]]);
kept.push(3);
console.log(JSON.stringify(r));
const r2 = [1].flatMap<(number[] | string)[]>(() => [[kept], ["a"]]);
kept.push(4);
console.log(JSON.stringify(r2));
