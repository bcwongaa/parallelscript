interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r = [1, 2].flatMap<J[]>((i) => (i === 1 ? [[cobj]] : []));
cobj.x = 5;
console.log(r.length, r[0][0].x);
