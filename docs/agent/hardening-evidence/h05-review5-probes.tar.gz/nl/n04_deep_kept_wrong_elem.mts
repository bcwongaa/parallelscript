const kept = [1, 2];
const r = [1].flatMap<(number | string)[][]>(() => [[kept]]);
kept.push(3);
console.log(JSON.stringify(r));
