const kept = [1, 2];
const r: (number | string)[][][] = [[[kept]]].flat();
kept.push(3);
console.log(JSON.stringify(r));
const r2: (number | string)[][] = [kept];
