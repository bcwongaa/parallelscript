interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const r = [1].flatMap<J[] | string[]>(() => [[cobj]]);
cobj.x = 5;
console.log(r.length, JSON.stringify(r));
