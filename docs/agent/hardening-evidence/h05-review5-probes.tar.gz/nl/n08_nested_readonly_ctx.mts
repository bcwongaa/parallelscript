const kept = [1, 2];
const r = [1].flatMap<readonly (readonly number[])[]>(() => [[kept]]);
kept.push(3);
console.log(JSON.stringify(r));
