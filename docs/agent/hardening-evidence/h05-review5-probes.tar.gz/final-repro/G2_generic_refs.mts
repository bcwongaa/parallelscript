const wrap = <T,>(x: T): T[] => [x];
console.log([1, 2].flatMap(wrap));
class Util { static pair<T>(x: T): [T, T] { return [x, x]; } }
console.log(["a", "b"].flatMap(Util.pair));
function orNone<T>(x: T | null): T[] { return x === null ? [] : [x]; }
const maybe: (number | null)[] = [1, null, 3];
console.log(maybe.flatMap(orNone));
