const p: [number, string] = [1, "a"];
const r = [1].flatMap<[number, string | number]>(() => [p]);
p[1] = "b";
console.log(r.length, r[0][1]);
