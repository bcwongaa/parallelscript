interface J { x: number | string }
class C { constructor(public x: number) {} }
class H { c?: C = new C(1); }
const hs: H[] | undefined = [new H()];
const r = hs?.flatMap<J | undefined>((h) => [h.c]);
console.log(r?.length);
const h0 = hs![0];
h0.c!.x = 5;
console.log(r![0]?.x);
