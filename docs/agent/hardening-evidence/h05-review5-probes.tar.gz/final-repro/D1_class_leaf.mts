class C { x = 1 }
class D { x = 2 }
const c = new C();
const r = [1].flatMap<D>(() => [c]);
c.x = 5;
console.log(r.length, r[0].x, r[0] instanceof D);
