function dup<T>(x: T): T[] { return [x, x]; }
console.log([1, 2].flatMap(dup));
const ys: string[] = ["a"].flatMap(dup);
console.log(ys);
