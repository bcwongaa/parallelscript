interface J { x: number | string }
class C { constructor(public x: number) {} }
class D { constructor(public x: string) {} }
const c = new C(1);
const cds: (C | D)[] = [c, new D("a")];
const r = [1].flatMap<J>(() => cds);
c.x = 5;
console.log(r.length, r[0].x, r[1].x);
