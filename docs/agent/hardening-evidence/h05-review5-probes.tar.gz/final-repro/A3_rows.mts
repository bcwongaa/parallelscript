interface Row { id: number; value: number | null }
class Filled { constructor(public id: number, public value: number) {} }
class Missing { value = null; constructor(public id: number) {} }
const f = new Filled(1, 10);
const groups: (Filled | Missing)[][] = [[f, new Missing(2)], [new Filled(3, 30)]];
const rows = groups.flatMap<Row>((g) => g);
f.value = 99;
console.log(rows.map((r) => `${r.id}=${r.value}`).join(" "));
