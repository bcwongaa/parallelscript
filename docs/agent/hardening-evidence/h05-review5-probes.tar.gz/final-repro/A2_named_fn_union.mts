interface Row { id: number; value: number | null }
class Filled { constructor(public id: number, public value: number) {} }
class Missing { value = null; constructor(public id: number) {} }
const f = new Filled(1, 10);
function rowsOf(n: number): (Filled | Missing)[] { return n > 0 ? [f, new Missing(2)] : []; }
const rows = [1, 0].flatMap<Row>(rowsOf);
f.value = 99;
console.log(rows.map((r) => `${r.id}=${r.value}`).join(" "));
