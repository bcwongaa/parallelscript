const ns = [1, 2];
const r = [1].flatMap<(number | string)[]>(() => ns.map((m) => [m]));
console.log(r);
const out = [[1], [2]];
const r2 = [1].flatMap<(number | string)[]>(() => out);
console.log(r2);
