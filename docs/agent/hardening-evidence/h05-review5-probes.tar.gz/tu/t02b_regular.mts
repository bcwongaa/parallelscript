const ns = [1, 2];
const r: (number | string)[][] = ns.map((m): [number, string] => [m, "a"]);
console.log(JSON.stringify(r));
