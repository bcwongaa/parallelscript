const ns = [1, 2];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => ns.map((m): [number, string] => [m, "a"]))));
