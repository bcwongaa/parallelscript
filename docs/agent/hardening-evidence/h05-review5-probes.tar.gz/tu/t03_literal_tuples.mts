const r = [1].flatMap<(number | string)[]>(() => [[1, "a"]]);
console.log(JSON.stringify(r));
const p: [number, string] = [1, "a"];
const r2 = [1].flatMap<(number | string)[]>(() => [[...p]]);
console.log(JSON.stringify(r2));
