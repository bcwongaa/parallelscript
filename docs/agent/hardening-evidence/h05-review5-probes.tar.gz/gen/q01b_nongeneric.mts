function oneN(x: number): number[] { return [x]; }
const r = [1, 2].flatMap<number[]>(oneN);
console.log(r.length);
