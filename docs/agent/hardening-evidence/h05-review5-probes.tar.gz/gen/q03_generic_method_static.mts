class U2 { static twice<T>(x: T): T[] { return [x, x]; } }
console.log([1, 2].flatMap(U2.twice));
const id = <T,>(x: T): T => x;
console.log([1, 2].flatMap(id));
