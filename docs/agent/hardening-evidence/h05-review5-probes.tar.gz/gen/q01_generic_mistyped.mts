function one<T>(x: T): T[] { return [x]; }
const r = [1, 2].flatMap<number[]>(one);
console.log(r.length);
console.log(r[0].length);
