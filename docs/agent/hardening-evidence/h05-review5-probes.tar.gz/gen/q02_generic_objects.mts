interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
function wrap<T>(x: T): T[] { return [x]; }
const r = [c].flatMap<J>(wrap);
c.x = 5;
console.log(r.length, r[0].x);
