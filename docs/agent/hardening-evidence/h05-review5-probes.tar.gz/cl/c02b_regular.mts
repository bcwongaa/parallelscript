const o = { x: 1 };
class C { constructor(public x: number) {} }
const c = new C(2);
const r = [1, 2].map((i) => (i === 1 ? o : c));
console.log(r.length, r[0] === o, r[1] === c);
const arr = [o, c];
console.log(arr[1] === c);
