class A { a = 1 }
class Sub extends A { s = 3 }
const s = new Sub();
const subs: (Sub | null)[] = [s, null];
const r = [1].flatMap<A | null>(() => subs);
console.log(r.length, r[0] === s, r[1]);
const r2 = [1].flatMap<A | undefined | number>(() => [s, 1]);
console.log(r2[0] === s, r2[1]);
