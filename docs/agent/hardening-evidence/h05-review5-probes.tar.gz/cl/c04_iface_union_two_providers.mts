interface J1 { kind: "a"; x: number }
interface J2 { kind: "b"; y: string }
class C1 implements J1 { kind = "a" as const; constructor(public x: number) {} }
class C2 implements J2 { kind = "b" as const; constructor(public y: string) {} }
const c1 = new C1(1), c2 = new C2("q");
const cs: (C1 | C2)[] = [c1, c2];
const r = [1].flatMap<J1 | J2>(() => cs);
c1.x = 9;
const first = r[0];
console.log(r.length, first.kind === "a" ? first.x : -1, r[0] === c1, r[1] === c2);
const r2 = [1].flatMap<J1 | J2>(() => [c1, c2]);
console.log(r2[0] === c1, r2[1] === c2);
