const o = { x: 1 };
class C { constructor(public x: number) {} }
const c = new C(2);
const r = [1, 2].flatMap((i) => (i === 1 ? [o] : [c]));
console.log(r.length, r[0] === o, r[1] === c);
