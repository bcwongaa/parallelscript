class Box<T> { constructor(public v: T) {} }
class Sub<T> extends Box<T> { more = 1 }
const s = new Sub(1);
const r = [1].flatMap<Box<number>>(() => [s]);
console.log(r[0] === s);
interface HasV<T> { v: T }
const r2 = [1].flatMap<HasV<number>>(() => [s, new Box(2)]);
console.log(r2[0] === s, r2[1].v);
const r3 = [1].flatMap<Box<number> | Box<string>>(() => [new Box(1), new Box("a")]);
console.log(r3.length);
