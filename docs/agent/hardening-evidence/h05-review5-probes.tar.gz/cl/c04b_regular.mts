interface J1 { kind: "a"; x: number }
interface J2 { kind: "b"; y: string }
class C1 implements J1 { kind = "a" as const; constructor(public x: number) {} }
class C2 implements J2 { kind = "b" as const; constructor(public y: string) {} }
const c1 = new C1(1), c2 = new C2("q");
const r2: (J1 | J2)[] = [c1, c2];
console.log(r2[0] === c1, r2[1] === c2);
