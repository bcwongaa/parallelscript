abstract class Shape { abstract area(): number }
class Sq extends Shape { constructor(public s: number) { super(); } area() { return this.s * this.s; } }
class Node2 { children: Node2[] = []; all(): Node2[] { return [this as Node2].concat(this.children.flatMap((c) => c.all())); } }
const sq = new Sq(2);
const shapes = [1].flatMap<Shape>(() => [sq]);
console.log(shapes[0] === sq, shapes[0].area());
const n = new Node2(); n.children.push(new Node2());
console.log(n.all().length);
const flat = [n].flatMap((x) => [x, ...x.children]);
console.log(flat[0] === n, flat[1] === n.children[0]);
