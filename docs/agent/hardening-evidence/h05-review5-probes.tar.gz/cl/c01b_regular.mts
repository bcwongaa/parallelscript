class A { a = 1 }
class B { b = 2 }
class Sub extends A { s = 3 }
const s = new Sub();
const r: (A | B)[] = [s];
console.log(r.length, r[0] === s, r[0] instanceof Sub);
