type A = { kind: "a"; n: number };
type B = { kind: "b"; s: string };
const lit = { kind: "a" as const, n: 2 };
const r2: (A | B)[] = [lit];
lit.n = 7;
const g = r2[0];
console.log(g.kind === "a" ? g.n : -1);
