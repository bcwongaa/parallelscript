const o = { p: { x: 1 }, tag: "t" };
const r = [1].flatMap<{ p: { x: number }; tag: string }>(() => [o]);
o.p.x = 5;
console.log(r[0].p.x, r[0] === o);
