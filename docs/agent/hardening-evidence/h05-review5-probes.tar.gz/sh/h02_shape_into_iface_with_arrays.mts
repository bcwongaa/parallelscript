interface Row { id: number; tags: string[] }
const row = { id: 1, tags: ["a"] };
const r = [1].flatMap<Row>(() => [row]);
row.tags.push("b");
console.log(r[0].tags, r[0] === row);
