interface Pt { x: number }
interface Holder { pt: Pt }
class P implements Pt { constructor(public x: number) {} }
class H implements Holder { constructor(public pt: Pt) {} }
const h = new H(new P(1));
const r = [1].flatMap<Holder>(() => [h]);
console.log(r[0] === h);
