// `&&=` on an unset object field (D-141) whose right side awaits, its value used.
class Leaf { tag = "leaf"; }
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Tree {
  a!: Leaf;
  async run(): Promise<void> {
    const r = this.a &&= await later(new Leaf());
    try { console.log(r.tag); } catch (e) { console.log("threw", (e as Error).name); }
  }
}
await new Tree().run();
