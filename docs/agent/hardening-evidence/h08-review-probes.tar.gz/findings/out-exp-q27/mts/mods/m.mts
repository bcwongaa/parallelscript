export function f(n: number): string { return `m.f ${n}`; }
export const g = (n: number): string => `m.g ${n}`;
export let h = (n: number): string => `m.h ${n}`;
export function setH(): void { h = (n: number): string => `m.h2 ${n}`; }
export class C { static s(n: number): string { return `C.s ${n}`; } }
export const obj = { k: 1, f(n: number): string { return `obj.f ${n + this.k}`; } };
