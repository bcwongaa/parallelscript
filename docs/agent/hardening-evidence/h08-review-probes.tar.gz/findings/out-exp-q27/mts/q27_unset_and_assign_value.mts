// `&&=` on an unset object field (D-141) whose right side awaits, its value used.
class Leaf { tag = "leaf"; }
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Tree {
  a!: Leaf;
  async run(): Promise<void> {
    const r = this.a &&= await later(new Leaf());
    console.log(r === undefined ? "undefined" : r.tag);
  }
}
await new Tree().run();
