// A compound or logical assignment to a property of a union of classes, one with a getter, whose right side awaits.
const trace: string[] = [];
const later = (change: () => void): Promise<number> => { trace.push("await"); queueMicrotask(change); return Promise.resolve(10); };
class A { p = 1; }
class B {
  v = 1;
  get p(): number { trace.push("get"); return this.v; }
  set p(x: number) { trace.push(`set ${x}`); this.v = x; }
}
const b0 = new B();
const a0 = new A();
const pickB = (): A | B => b0;
const pickA = (): A | B => a0;
async function main(): Promise<void> {
  const b = pickB();
  b.p += await later(() => { b0.v = 2; });
  console.log(b0.v, trace.join(","));
  trace.length = 0;
  const a = pickA();
  a.p *= await later(() => { a0.p = 3; });
  console.log(a0.p, trace.join(","));
  trace.length = 0;
  b.p &&= await later(() => { b0.v = 0; });
  console.log(b0.v, trace.join(","));
}
await main();
