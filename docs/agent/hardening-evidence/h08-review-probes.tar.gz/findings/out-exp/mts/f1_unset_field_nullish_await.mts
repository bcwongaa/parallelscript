// D-141: '??=' on a class's object field nothing has set yet (await).
class Leaf { tag = "leaf"; }
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Tree {
  a!: Leaf;
  async run(): Promise<void> { this.a ??= await later(new Leaf()); }
}
const t = new Tree();
await t.run();
console.log(typeof t.a, t.a === undefined ? "unset" : t.a.tag);
