// Logical assignments with yield in generators, and in async generators.
function* g(): Generator<string, string, number> {
  let x: number | undefined;
  const o: { n: number | null } = { n: 1 };
  console.log("v1", x ??= yield "x1");
  console.log("v2", x ??= yield "x2");
  console.log("v3", o.n &&= yield "n1");
  o.n = null;
  console.log("v4", o.n ||= yield "n2");
  let s: string = "";
  s ||= String(yield "s1");
  return `${x} ${o.n} ${s}`;
}
const it = g();
let r = it.next();
let i = 10;
while (!r.done) { console.log("yielded", r.value); r = it.next(i++); }
console.log("done", r.value);
async function* ag(): AsyncGenerator<string, void, number> {
  let x: number | null = null;
  x ??= yield "ax1";
  x ??= yield "ax2";
  const q = await Promise.resolve(3);
  let y: number = 0;
  y ||= await Promise.resolve(q);
  y &&= (yield "ay") + y;
  console.log("ag", x, y);
}
(async (): Promise<void> => {
  const it2 = ag();
  let r2 = await it2.next();
  let j = 100;
  while (!r2.done) { console.log("ayielded", r2.value); r2 = await it2.next(j++); }
})();
