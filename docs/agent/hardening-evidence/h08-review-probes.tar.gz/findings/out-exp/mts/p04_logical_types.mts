// The value of a logical assignment whose right side suspends, of differing types.
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
async function main(): Promise<void> {
  let a: string | null = null;
  let b: number | string | undefined = 5;
  let c: number[] | undefined;
  let d: boolean = false;
  let e: string | number = "";
  let f: (() => number) | undefined;
  let g: { k: number } | undefined = { k: 1 };
  const r1 = a ??= await later("x");
  const r2 = b ??= await later("y");
  const r3 = (c ??= await later([1, 2])).length;
  const r4 = d ||= await later(true);
  const r5 = e ||= await later(7);
  const r6 = (f ??= await later((): number => 42))();
  const r7 = g &&= await later({ k: 2 });
  console.log(r1, r2, r3, r4, r5, r6, r7, typeof r2, typeof r5);
  let h: number | null = 0;
  const r8 = h ||= await later(9);
  const r9 = h &&= await later(10);
  console.log(r8, r9, h);
  const s: string = (a ||= await later("q")) + "!";
  console.log(s, a);
  let x: number | undefined, y: number | undefined;
  const r10 = x ??= y ??= await later(11);
  console.log(r10, x, y);
  const r11 = x ??= y ??= await later(12);
  console.log(r11, x, y);
  let z: string | undefined;
  console.log(`${z ??= await later("zz")}/${z}`);
  const arr = [z ??= await later("no"), await later("w")];
  console.log(arr);
}
main();
