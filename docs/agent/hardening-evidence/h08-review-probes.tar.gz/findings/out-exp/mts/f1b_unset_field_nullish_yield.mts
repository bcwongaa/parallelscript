// D-141: '??=' on a class's object field nothing has set yet (yield).
class Leaf { tag = "leaf"; }
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Tree {
  a!: Leaf;
  *run(): Generator<number, void, Leaf> { this.a ??= yield 0; }
}
const t = new Tree();
const it = t.run(); it.next(); it.next(new Leaf());
console.log(typeof t.a, t.a === undefined ? "unset" : t.a.tag);
