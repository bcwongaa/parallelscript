// Logical assignments whose right side awaits, with values used as arrays and maps (D-176).
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Cache {
  items: number[] | undefined;
  byKey: Map<string, number> | undefined;
  names: string[] = [];
}
let memo: string[] | undefined;
const load = async (): Promise<string[]> => { await null; return ["a", "b"]; };
const cached = async (): Promise<string[]> => memo ??= await load();
async function main(): Promise<void> {
  const c = new Cache();
  (c.items ??= await later([])).push(1);
  (c.byKey ??= await later(new Map<string, number>())).set("k", 2);
  (c.names ||= await later([])).push("n");
  c.names.length &&= await later(0);
  console.log(c.items, c.byKey, c.names, c.names.length);
  const a = await cached();
  const b = await cached();
  console.log(a === b, a);
  const arr = [1, 2, 3];
  arr.length ||= await later(1);
  arr.length &&= await later(2);
  console.log(arr);
}
await main();
