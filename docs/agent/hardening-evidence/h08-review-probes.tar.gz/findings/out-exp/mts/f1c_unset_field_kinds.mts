// D-141 unset fields of function, array and map types with ??= whose right side awaits.
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Lazy {
  cb!: () => string;
  list!: number[];
  map!: Map<string, number>;
  async init(): Promise<void> {
    this.cb ??= await later((): string => "cb");
    this.list ??= await later([1, 2]);
    this.map ??= await later(new Map<string, number>([["a", 1]]));
  }
}
const l = new Lazy();
await l.init();
console.log(l.cb(), l.list.length, l.map.size);
