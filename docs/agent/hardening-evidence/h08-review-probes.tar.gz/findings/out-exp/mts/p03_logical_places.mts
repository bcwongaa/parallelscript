// ??=, ||= and &&= whose right side awaits, on many place kinds, value used and discarded.
const trace: string[] = [];
const later = async <T,>(v: T): Promise<T> => { trace.push(`later ${String(v)}`); await null; return v; };
class Box { n: number | undefined = undefined; s = ""; o: { v: number } | null = null; static st: number | null = null; }
class Acc {
  private v: number | null = null;
  get p(): number | null { trace.push("get"); return this.v; }
  set p(x: number | null) { trace.push(`set ${String(x)}`); this.v = x; }
}
let mod: string | undefined;
async function main(): Promise<void> {
  let loc: number | undefined;
  const b = new Box();
  const acc = new Acc();
  const arr: (number | undefined)[] = [1, undefined];
  const nums: number[] = [1, 2];
  const rec: Record<string, number> = { a: 1 };
  const tup: [number | null, string] = [null, "t"];
  const ta = new Float64Array(2);
  const anyO: any = { q: 0 };
  console.log(loc ??= await later(1), loc);
  console.log(loc ??= await later(2), loc);
  console.log(b.n ??= await later(3), b.n);
  console.log(b.s ||= await later("s"), b.s);
  console.log(b.s &&= await later("t"), b.s);
  console.log((b.o ??= await later({ v: 4 })).v);
  console.log(Box.st ??= await later(5), Box.st);
  console.log(acc.p ??= await later(6), acc.p);
  console.log(acc.p &&= await later(7), acc.p);
  console.log(acc.p ||= await later(8), acc.p);
  console.log(arr[1] ??= await later(9), arr);
  console.log(arr[0] ||= await later(10), arr);
  console.log(nums[0] &&= await later(11), nums);
  console.log("12 6");
  console.log(rec["a"] ||= await later(13), rec["b"] ??= await later(14), rec);
  console.log(tup[0] ??= await later(15), tup);
  console.log(ta[0] ||= await later(16), ta[0]);
  console.log(anyO.q ||= await later(17), anyO.q ??= await later(18), anyO);
  console.log(mod ??= await later("m"), mod);
  mod ??= await later("m2");
  b.n &&= await later(20);
  acc.p ??= await later(21);
  void (loc &&= await later(22));
  console.log(b.n, acc.p, loc);
  console.log(trace.join(","));
}
main();
