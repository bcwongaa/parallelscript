// The value of a logical assignment is the right side's, whatever the setter keeps; D-141 fields.
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class Clamp {
  private v: number | null = null;
  get p(): number | null { return this.v; }
  set p(x: number | null) { this.v = x === null ? null : Math.min(x, 5); }
}
class Node2 { next: Node2 | undefined; }
class Lazy {
  child: Node2;
  label: string;
  constructor() {
    this.child ??= new Node2();
    this.label ||= "lbl";
  }
}
class LazyAsync {
  child!: Node2;
  async init(): Promise<void> { this.child ??= await later(new Node2()); }
}
async function main(): Promise<void> {
  const c = new Clamp();
  console.log(c.p ??= await later(9), c.p);
  console.log(c.p ||= await later(9), c.p);
  const l = new Lazy();
  console.log(typeof l.child, l.label);
  const la = new LazyAsync();
  await la.init();
  console.log(typeof la.child);
}
await main();
