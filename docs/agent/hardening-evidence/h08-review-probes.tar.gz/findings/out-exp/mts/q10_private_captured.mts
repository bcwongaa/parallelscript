// Private fields, captured and module variables as places of logical assignments that suspend.
const later = async <T,>(v: T): Promise<T> => { await null; return v; };
class P {
  #v: number | undefined;
  async fill(): Promise<number> { return this.#v ??= await later(7); }
  get v(): number | undefined { return this.#v; }
}
let top: string | null = null;
function outer(): () => Generator<number, string, number> {
  let cap: number | undefined;
  let other = 0;
  return function* (): Generator<number, string, number> {
    cap ??= yield 1;
    other ||= yield 2;
    cap ??= yield 3;
    return `${cap} ${other}`;
  };
}
async function main(): Promise<void> {
  const p = new P();
  console.log(await p.fill(), await p.fill(), p.v);
  console.log(top ??= await later("t"), top ??= await later("u"));
  const it = outer()();
  let r = it.next();
  const seen: number[] = [];
  while (!r.done) { seen.push(r.value); r = it.next(r.value * 10); }
  console.log(seen, r.value);
}
await main();
