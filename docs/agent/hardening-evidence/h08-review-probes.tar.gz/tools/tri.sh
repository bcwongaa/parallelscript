#!/bin/bash
# tri.sh FILE.pts...: build+run each with base CLI and fixed CLI, and under Node (.mts copy).
# Outputs to $OUT (default /tmp/h08/rev1/out): NAME.{node,base,fix}.txt; prints verdicts.
set -u
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
BASE_CLI=/tmp/h08/base/pts-bin/pts
FIX_CLI=${FIX_CLI:-/tmp/h08/review1/pts-bin/pts}
FIX_HOME=${FIX_HOME:-/tmp/h08/review1}
out=${OUT:-/tmp/h08/rev1/out}; mkdir -p "$out/bin" "$out/mts"
for f in "$@"; do
  name=$(basename "$f" .pts); dir=$(cd "$(dirname "$f")" && pwd)
  mts="$out/mts/$name.mts"; sed 's/\.pts"/.mts"/g' "$dir/$name.pts" > "$mts"
  if [ -d "$dir/mods" ]; then mkdir -p "$out/mts/mods"; for m in "$dir"/mods/*.pts; do sed 's/\.pts"/.mts"/g' "$m" > "$out/mts/mods/$(basename "$m" .pts).mts"; done; fi
  timeout 30 node --no-warnings --experimental-transform-types "$mts" > "$out/$name.node.txt" 2>&1; echo "[exit $?]" >> "$out/$name.node.txt"
  for side in base fix; do
    if [ $side = base ]; then cli=$BASE_CLI; home=/tmp/h08/base; else cli=$FIX_CLI; home=$FIX_HOME; fi
    bin="$out/bin/$name.$side.bin"; rm -f "$bin"
    PTS_HOME=$home timeout 300 "$cli" build "$dir/$name.pts" -o "$bin" > "$out/$name.$side.build.txt" 2>&1; be=$?
    if [ $be -ne 0 ]; then
      { cat "$out/$name.$side.build.txt"; echo "[build exit $be]"; } > "$out/$name.$side.txt"
    else
      (cd "$out" && timeout 30 "$bin" > "$out/$name.$side.txt" 2>&1; echo "[exit $?]" >> "$out/$name.$side.txt")
    fi
    rm -f "$bin"
  done
  vb=$(cmp -s "$out/$name.base.txt" "$out/$name.node.txt" && echo OK || echo DIFF)
  vf=$(cmp -s "$out/$name.fix.txt" "$out/$name.node.txt" && echo OK || echo DIFF)
  echo "##### $name: base=$vb fix=$vf"
  if [ "${QUIET:-0}" != 1 ] || [ $vf != OK ]; then
    echo "=== node"; cat "$out/$name.node.txt"
    echo "=== base"; cat "$out/$name.base.txt"
    echo "=== fix"; cat "$out/$name.fix.txt"
  fi
done
