Callgrind instruction counts (PTS_THREADS=1, valgrind --tool=callgrind), base 8b02155be vs fixed snapshot:
w1_async_callee  base 80,562,399  fix 80,962,378  (+0.50%; 200k calls of a function-valued field with an awaited argument: one frame local each)
w2_gen_postfix   base 114,992,390 fix 114,392,281 (-0.52%; 300k `arr[i++] = yield k`)
w3_async_method  base 230,993,207 fix 231,061,067 (+0.03%; method calls with awaited arguments, `(await x).items.map(f)[0]`)
Binaries and callgrind.out files are left out of the archive; rebuild with the CLIs and rerun the command above.
