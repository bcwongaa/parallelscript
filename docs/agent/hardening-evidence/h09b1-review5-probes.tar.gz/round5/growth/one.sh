#!/bin/bash
# one.sh file.pts: AllInstances-alone emit-c with snap7; prints file, exit, C lines, array guards, instance calls.
f=$1
n=$(echo "$f" | sed 's|/tmp/h09b/snap7/pts/tests/||; s|/|__|g')
c=$(mktemp /tmp/h09b1-review/round5/growth/c.XXXX)
timeout 300 /tmp/h09b1-review/allinst/ptsall_snap7 "$f" > $c 2>/dev/null; e=$?
printf "%s\t%s\t%s\t%s\t%s\n" "$n" "$e" "$(wc -l < $c)" "$(grep -o -- '->type->element == PTS_FIELD_[A-Z0-9]*' $c | wc -l)" "$(grep -o 'pts_instance_find(\|pts_method_instance_find(' $c | wc -l)"
rm -f $c
