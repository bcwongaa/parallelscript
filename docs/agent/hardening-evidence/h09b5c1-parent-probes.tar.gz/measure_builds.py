import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys
import time

repo, scratch, sources = map(pathlib.Path, sys.argv[1:])
output = scratch / 'native-growth'
output.mkdir()
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
node = pathlib.Path.home() / '.local/node/bin/node'
results = []

def run(command, stem, timeout):
    stdout_path = output / (stem + '.stdout')
    stderr_path = output / (stem + '.stderr')
    started = time.monotonic()
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout,
                                   stderr=stderr, start_new_session=True)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            code = 'timeout'
    return {'command': list(map(str, command)), 'exit': code,
            'wall_seconds': time.monotonic() - started,
            'stdout': stdout_path.read_text(), 'stderr': stderr_path.read_text()}

for index, name in enumerate(('esc_0x20', 'decls_60', 'esc_150x50', 'methods_60')):
    source = sources / (name + '.pts')
    twin = output / (name + '.mts')
    twin.write_bytes(source.read_bytes())
    oracle = run([node, '--no-warnings', '--experimental-transform-types', twin], name + '.node', 30)
    if oracle['exit'] != 0:
        raise SystemExit('Node control failed: ' + name)
    for label in (('base', 'current') if index % 2 == 0 else ('current', 'base')):
        binary = output / (name + '.' + label + '.bin')
        timing = output / (name + '.' + label + '.time')
        command = ['/usr/bin/time', '-f', '%e %M', '-o', str(timing),
                   str(scratch / (label + '-pts')), 'build', str(source), '-o', str(binary)]
        build = run(command, name + '.' + label + '.build', 300)
        native = run([binary], name + '.' + label + '.run', 30) if build['exit'] == 0 else None
        row = {'case': name, 'compiler': label, 'build': build, 'native': native,
               'time_peak_rss': timing.read_text().strip(), 'node': oracle,
               'binary_bytes': binary.stat().st_size if binary.exists() else None,
               'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'matches_node': native is not None and native['exit'] == 0 and native['stdout'] == oracle['stdout']}
        if binary.exists():
            binary.unlink()
        results.append(row)
        (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        if not row['matches_node']:
            raise SystemExit('native control failed')
