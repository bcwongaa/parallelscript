import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

scratch = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
out = root / "docs/agent/hardening-evidence"
assert (scratch / "acceptance-suite.exit").read_text().strip() == "0"
source_check = json.loads((scratch / "acceptance-suite-source-check-corrected.json").read_text())
assert not source_check["changed_sources"] and not source_check["added_sources"] and source_check["cli_unchanged"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


summaries = {}
for stream in sorted(scratch.glob("*.jsonl")):
    events = []
    for line in stream.read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    actions = collections.Counter(e["Action"] for e in events
                                  if e.get("Test") and e["Action"] in ("pass", "fail", "skip"))
    corpus = collections.Counter(e["Action"] for e in events
                                 if e.get("Test", "").startswith("TestCorpusMatchesNode/")
                                 and e["Test"].count("/") == 2
                                 and e["Action"] in ("pass", "fail", "skip"))
    exit_file = stream.with_suffix(".exit")
    stderr = stream.with_suffix(".stderr")
    summaries[stream.stem] = {
        "exit": exit_file.read_text().strip() if exit_file.exists() else "pending",
        "test_events": dict(actions),
        "corpus_leaves": dict(corpus),
        "packages": [{"package": e["Package"], "action": e["Action"], "elapsed": e.get("Elapsed")}
                     for e in events if not e.get("Test") and e["Action"] in ("pass", "fail")],
        "stderr_bytes": stderr.stat().st_size if stderr.exists() else None,
        "sha256": sha(stream),
    }
(scratch / "parent-test-summary.json").write_text(json.dumps(summaries, indent=2) + "\n")

files = subprocess.run(["git", "ls-files", "pts", "cmd/pts"], cwd=root,
                       check=True, text=True, capture_output=True).stdout.splitlines()
files += [str(p.relative_to(root)) for p in (root / "pts/lower").glob("value_flow*.go")]
files += [str(p.relative_to(root)) for p in (root / "pts/tests/run").glob("generic_value_flow*.pts")]
source_hashes = {name: sha(root / name) for name in sorted(set(files)) if (root / name).is_file()}
provenance = {
    "base": (scratch / "base-sha").read_text().strip(),
    "head_at_packaging": subprocess.run(["git", "rev-parse", "HEAD"], cwd=root,
                                        check=True, text=True, capture_output=True).stdout.strip(),
    "sources": source_hashes,
    "compiler_hashes": {name: sha(scratch / name) for name in ("base-pts", "current-pts", "final-measure/current-pts")},
    "final_cli_hash": sha(root / "pts-bin/pts"),
}
accepted = json.loads((scratch / "acceptance-suite-sources-before.json").read_text())
assert source_hashes == accepted["sources"], "Source files changed after the acceptance snapshot"
assert provenance["final_cli_hash"] == accepted["cli_sha256"] == provenance["compiler_hashes"]["final-measure/current-pts"]
(scratch / "parent-source-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")

members = {}
for path in sorted(scratch.iterdir()):
    if path.is_file() and path.suffix in (".py", ".json", ".patch", ".exit", ".stderr", ".stdout", ".mts", ".log"):
        members[path.name] = path.read_bytes()
    elif path.is_file() and path.suffix == ".jsonl":
        members[path.name + ".gz"] = gzip.compress(path.read_bytes(), mtime=0)
for directory in ("growth", "native-growth", "overlay-sources", "fixture-correction", "reviewer-fixture-supplement", "final-measure/growth", "final-measure/native-growth"):
    for path in sorted((scratch / directory).rglob("*")):
        if path.is_file() and not path.is_symlink() and path.suffix != ".bin":
            members[str(path.relative_to(scratch))] = path.read_bytes()
for path in sorted(scratch.glob("m4-sources.*/**/*.pts")):
    members["m4-sources/" + path.name] = path.read_bytes()
for name in ("pts/lower/lower.go", "pts/lower/instances.go", "pts/lower/unions.go", "pts/lower/value_flow.go",
             "pts/lower/value_flow_test.go", "pts/driver/driver_test.go",
             "pts/driver/speculative_instances_test.go", "pts/tests/compiler_smoke_test.go",
             "pts/tests/errors/generic_fallback_keeps_speculative_declaration_failures.pts"):
    members["source-snapshot/" + name] = (root / name).read_bytes()
for path in sorted((root / "pts/tests/run").glob("generic_value_flow*.pts")):
    members["source-snapshot/" + str(path.relative_to(root))] = path.read_bytes()

for name, data in members.items():
    if data.startswith(b"\x7fELF"):
        raise SystemExit("Refusing binary member: " + name)
members["MANIFEST.json"] = (json.dumps({name: hashlib.sha256(data).hexdigest()
                                        for name, data in sorted(members.items())}, indent=2) + "\n").encode()
archive = out / "h09b5c1-parent-probes.tar.gz"
if archive.exists():
    raise SystemExit("Inspect/remove the old evidence archive before replacing it")
with archive.open("xb") as dest:
    with gzip.GzipFile(fileobj=dest, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
print(json.dumps({"archive": str(archive), "bytes": archive.stat().st_size,
                  "members": len(members), "sha256": sha(archive)}, indent=2))
