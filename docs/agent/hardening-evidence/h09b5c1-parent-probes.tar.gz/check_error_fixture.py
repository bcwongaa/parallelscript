import json
import os
from pathlib import Path
import subprocess
import sys

scratch = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
folder = scratch / "fixture-correction"
folder.mkdir()
source = (root / "pts/tests/errors/generic_fallback_keeps_speculative_declaration_failures.pts").read_text()
known = folder / "known.pts"
unknown = folder / "unknown.pts"
known.write_text(source)
unknown.write_text(source.replace('console.log("dogs", useDogs(make));', 'const actual: any[] = [make];\nconsole.log("dogs", useDogs(actual[0]));'))
(folder / "known.mts").write_text(source)
env = dict(os.environ, PTS_HOME=str(root), GOMAXPROCS="1")
results = []
for label, compiler in (("base", scratch / "base-pts"), ("current", scratch / "final-measure/current-pts")):
    for case in ("known", "unknown"):
        args = [str(compiler), "emit-c", str(folder / (case + ".pts"))]
        p = subprocess.run(args, env=env, capture_output=True, timeout=120)
        prefix = label + "-" + case
        (folder / (prefix + ".stdout")).write_bytes(p.stdout)
        (folder / (prefix + ".stderr")).write_bytes(p.stderr)
        results.append({"case": prefix, "command": args, "exit": p.returncode,
                        "stderr": p.stderr.decode(), "stdout_bytes": len(p.stdout)})
for label, args in (("current-known-native", [str(scratch / "final-measure/current-pts"), "run", str(known)]),
                    ("node-known", [str(Path.home() / ".local/node/bin/node"), str(folder / "known.mts")])):
    p = subprocess.run(args, env=env, capture_output=True, timeout=180)
    (folder / (label + ".stdout")).write_bytes(p.stdout)
    (folder / (label + ".stderr")).write_bytes(p.stderr)
    results.append({"case": label, "command": args, "exit": p.returncode,
                    "stdout": p.stdout.decode(), "stderr": p.stderr.decode()})
(folder / "receipt.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
assert [r["exit"] for r in results] == [1, 1, 0, 1, 0, 0]
assert results[4]["stdout"] == results[5]["stdout"] == "weird 0\nthrough any 1\ndogs 1\n"
for r in (results[0], results[1], results[3]):
    assert "using a Dog[] as a Animal[] where it may be changed or kept" in r["stderr"]
