package lower

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/microsoft/typescript-go/internal/ast"
)

func TestParameterSourceJoinMeasurements(t *testing.T) {
	for _, size := range []int{500, 1000, 2000, 4000} {
		t.Run(fmt.Sprint(size), func(t *testing.T) {
			var source strings.Builder
			source.WriteString("const origin = (): void => {}; function consume(probe: () => void): void {\n")
			for range size {
				source.WriteString("probe;\n")
			}
			source.WriteString("}\n")
			for range size {
				source.WriteString("consume(origin);\n")
			}
			l, _ := valueFlowProbe(t, source.String())
			var probes []*ast.Node
			var visit ast.Visitor
			visit = func(node *ast.Node) bool {
				if node.Kind == ast.KindExpressionStatement && node.Expression().Kind == ast.KindIdentifier && node.Expression().Text() == "probe" {
					probes = append(probes, node.Expression())
				}
				node.ForEachChild(visit)
				return false
			}
			for _, file := range l.valueFlow.files {
				file.AsNode().ForEachChild(visit)
			}
			steps := maxValueFlowSteps
			warmStart := time.Now()
			warmKnown := l.valueSources(probes[0], &steps, 0) != nil
			warm := time.Since(warmStart)
			known := 0
			start := time.Now()
			for _, probe := range probes[1:] {
				steps = maxValueFlowSteps
				if l.valueSources(probe, &steps, 0) != nil {
					known++
				}
			}
			t.Logf("callers=%d reads=%d warm_known=%t warm=%s repeated_known=%d repeated=%s", size, len(probes), warmKnown, warm, known, time.Since(start))
		})
	}
}
