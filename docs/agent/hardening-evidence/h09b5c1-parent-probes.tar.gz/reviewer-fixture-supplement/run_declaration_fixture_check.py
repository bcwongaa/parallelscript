from pathlib import Path
import json
import os
import subprocess

root = Path('/home/bryan/projects/parallelscript/.claude/worktrees/agent-abf1391354a0f7c8d')
probe = root / 'review-c1-probes'
original = root / 'pts/tests/errors/generic_fallback_keeps_speculative_declaration_failures.pts'
source = original.read_text()
body = source[source.index('class Box<T>'):]
old_call = 'console.log("dogs", useDogs(make));'
assert body.count(old_call) == 1
known = probe / 'declaration_fixture_known.pts'
unknown = probe / 'declaration_fixture_unknown.pts'
twin = known.with_suffix('.mts')
known.write_text(body)
twin.write_text(body)
unknown.write_text(body.replace(old_call, 'const actual: any[] = [make];\nconsole.log("dogs", useDogs(actual[0]));'))
env = os.environ.copy()
env.update(PTS_HOME='/home/bryan/projects/parallelscript', GOMAXPROCS='1')
cli = str(root / 'pts-bin/pts')
node = '/home/bryan/.local/node/bin/node'
commands = [
    ('known.native', [cli, 'run', str(known)]),
    ('known.node', [node, '--experimental-transform-types', '--disable-warning=ExperimentalWarning', str(twin)]),
    ('unknown.emit', [cli, 'emit-c', str(unknown)]),
]
results = {}
for label, command in commands:
    result = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=180)
    (probe / ('declaration_fixture_' + label + '.out')).write_bytes(result.stdout)
    (probe / ('declaration_fixture_' + label + '.err')).write_bytes(result.stderr)
    results[label] = {'command': command, 'exit': result.returncode, 'stdout': result.stdout.decode(errors='replace'), 'stderr': result.stderr.decode(errors='replace')}
    print(label + ': exit=' + str(result.returncode), flush=True)
    print(result.stdout.decode(errors='replace'), end='', flush=True)
    print(result.stderr.decode(errors='replace'), end='', flush=True)
(probe / 'declaration_fixture_results.json').write_text(json.dumps(results, indent=2) + '\n')
expected = 'weird 0\nthrough any 1\ndogs 1\n'
assert results['known.native']['exit'] == 0 and results['known.native']['stdout'] == expected
assert results['known.node']['exit'] == 0 and results['known.node']['stdout'] == expected
assert results['known.native']['stderr'] == results['known.node']['stderr'] == ''
assert results['unknown.emit']['exit'] != 0
assert 'using a Dog[] as a Animal[] where it may be changed or kept' in results['unknown.emit']['stderr']
print('PASS: known native/Node agree; unknown input retains the existing diagnostic', flush=True)
