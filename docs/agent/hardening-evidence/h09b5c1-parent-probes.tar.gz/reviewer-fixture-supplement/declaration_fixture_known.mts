class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
function mkWeird<T>(x: T): Box<T> {
  const weird = new Weird(x);
  console.log("weird", weird.animals().length);
  return new Box(x);
}
function useDogs(f: <T>(x: T) => Box<T>): number {
  const b: Box<Dog[]> = f([new Dog()]);
  return b.value.length;
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
const d: any = mkWeird;
console.log("through any", d(1).value);
console.log("dogs", useDogs(make));
