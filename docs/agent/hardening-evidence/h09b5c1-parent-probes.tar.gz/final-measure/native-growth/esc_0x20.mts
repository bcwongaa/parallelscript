class Box<T> {
  constructor(public value: T) {}
}
class C0 {
  tag = 0;
}
class C1 {
  tag = 1;
}
class C2 {
  tag = 2;
}
class C3 {
  tag = 3;
}
class C4 {
  tag = 4;
}
class C5 {
  tag = 5;
}
class C6 {
  tag = 6;
}
class C7 {
  tag = 7;
}
class C8 {
  tag = 8;
}
class C9 {
  tag = 9;
}
class C10 {
  tag = 10;
}
class C11 {
  tag = 11;
}
class C12 {
  tag = 12;
}
class C13 {
  tag = 13;
}
class C14 {
  tag = 14;
}
class C15 {
  tag = 15;
}
class C16 {
  tag = 16;
}
class C17 {
  tag = 17;
}
class C18 {
  tag = 18;
}
class C19 {
  tag = 19;
}
let total = 0;
const keep: any[] = [];
function use(f: <T>(x: T) => Box<T>): void {
  const b0: Box<C0> = f(new C0());
  total += b0.value.tag;
  const b1: Box<C1> = f(new C1());
  total += b1.value.tag;
  const b2: Box<C2> = f(new C2());
  total += b2.value.tag;
  const b3: Box<C3> = f(new C3());
  total += b3.value.tag;
  const b4: Box<C4> = f(new C4());
  total += b4.value.tag;
  const b5: Box<C5> = f(new C5());
  total += b5.value.tag;
  const b6: Box<C6> = f(new C6());
  total += b6.value.tag;
  const b7: Box<C7> = f(new C7());
  total += b7.value.tag;
  const b8: Box<C8> = f(new C8());
  total += b8.value.tag;
  const b9: Box<C9> = f(new C9());
  total += b9.value.tag;
  const b10: Box<C10> = f(new C10());
  total += b10.value.tag;
  const b11: Box<C11> = f(new C11());
  total += b11.value.tag;
  const b12: Box<C12> = f(new C12());
  total += b12.value.tag;
  const b13: Box<C13> = f(new C13());
  total += b13.value.tag;
  const b14: Box<C14> = f(new C14());
  total += b14.value.tag;
  const b15: Box<C15> = f(new C15());
  total += b15.value.tag;
  const b16: Box<C16> = f(new C16());
  total += b16.value.tag;
  const b17: Box<C17> = f(new C17());
  total += b17.value.tag;
  const b18: Box<C18> = f(new C18());
  total += b18.value.tag;
  const b19: Box<C19> = f(new C19());
  total += b19.value.tag;
}
function main(): void {
  use(<T>(x: T): Box<T> => new Box(x));
}
main();
console.log(total, keep.length);
