// C172(c): 60 generic declarations, each passed to its own one-type consumer (sd_N's control).
class Box<T> {
  constructor(public value: T) {}
}
type Factory = <T>(x: T) => Box<T>;
class V0 { constructor(public n: number) {} }
function use0(f: Factory): number { const b: Box<V0> = f(new V0(0)); return b.value.n; }
function make0<T>(x: T): Box<T> {
  return new Box(x);
}
class V1 { constructor(public n: number) {} }
function use1(f: Factory): number { const b: Box<V1> = f(new V1(1)); return b.value.n; }
function make1<T>(x: T): Box<T> {
  return new Box(x);
}
class V2 { constructor(public n: number) {} }
function use2(f: Factory): number { const b: Box<V2> = f(new V2(2)); return b.value.n; }
function make2<T>(x: T): Box<T> {
  return new Box(x);
}
class V3 { constructor(public n: number) {} }
function use3(f: Factory): number { const b: Box<V3> = f(new V3(3)); return b.value.n; }
function make3<T>(x: T): Box<T> {
  return new Box(x);
}
class V4 { constructor(public n: number) {} }
function use4(f: Factory): number { const b: Box<V4> = f(new V4(4)); return b.value.n; }
function make4<T>(x: T): Box<T> {
  return new Box(x);
}
class V5 { constructor(public n: number) {} }
function use5(f: Factory): number { const b: Box<V5> = f(new V5(5)); return b.value.n; }
function make5<T>(x: T): Box<T> {
  return new Box(x);
}
class V6 { constructor(public n: number) {} }
function use6(f: Factory): number { const b: Box<V6> = f(new V6(6)); return b.value.n; }
function make6<T>(x: T): Box<T> {
  return new Box(x);
}
class V7 { constructor(public n: number) {} }
function use7(f: Factory): number { const b: Box<V7> = f(new V7(7)); return b.value.n; }
function make7<T>(x: T): Box<T> {
  return new Box(x);
}
class V8 { constructor(public n: number) {} }
function use8(f: Factory): number { const b: Box<V8> = f(new V8(8)); return b.value.n; }
function make8<T>(x: T): Box<T> {
  return new Box(x);
}
class V9 { constructor(public n: number) {} }
function use9(f: Factory): number { const b: Box<V9> = f(new V9(9)); return b.value.n; }
function make9<T>(x: T): Box<T> {
  return new Box(x);
}
class V10 { constructor(public n: number) {} }
function use10(f: Factory): number { const b: Box<V10> = f(new V10(10)); return b.value.n; }
function make10<T>(x: T): Box<T> {
  return new Box(x);
}
class V11 { constructor(public n: number) {} }
function use11(f: Factory): number { const b: Box<V11> = f(new V11(11)); return b.value.n; }
function make11<T>(x: T): Box<T> {
  return new Box(x);
}
class V12 { constructor(public n: number) {} }
function use12(f: Factory): number { const b: Box<V12> = f(new V12(12)); return b.value.n; }
function make12<T>(x: T): Box<T> {
  return new Box(x);
}
class V13 { constructor(public n: number) {} }
function use13(f: Factory): number { const b: Box<V13> = f(new V13(13)); return b.value.n; }
function make13<T>(x: T): Box<T> {
  return new Box(x);
}
class V14 { constructor(public n: number) {} }
function use14(f: Factory): number { const b: Box<V14> = f(new V14(14)); return b.value.n; }
function make14<T>(x: T): Box<T> {
  return new Box(x);
}
class V15 { constructor(public n: number) {} }
function use15(f: Factory): number { const b: Box<V15> = f(new V15(15)); return b.value.n; }
function make15<T>(x: T): Box<T> {
  return new Box(x);
}
class V16 { constructor(public n: number) {} }
function use16(f: Factory): number { const b: Box<V16> = f(new V16(16)); return b.value.n; }
function make16<T>(x: T): Box<T> {
  return new Box(x);
}
class V17 { constructor(public n: number) {} }
function use17(f: Factory): number { const b: Box<V17> = f(new V17(17)); return b.value.n; }
function make17<T>(x: T): Box<T> {
  return new Box(x);
}
class V18 { constructor(public n: number) {} }
function use18(f: Factory): number { const b: Box<V18> = f(new V18(18)); return b.value.n; }
function make18<T>(x: T): Box<T> {
  return new Box(x);
}
class V19 { constructor(public n: number) {} }
function use19(f: Factory): number { const b: Box<V19> = f(new V19(19)); return b.value.n; }
function make19<T>(x: T): Box<T> {
  return new Box(x);
}
class V20 { constructor(public n: number) {} }
function use20(f: Factory): number { const b: Box<V20> = f(new V20(20)); return b.value.n; }
function make20<T>(x: T): Box<T> {
  return new Box(x);
}
class V21 { constructor(public n: number) {} }
function use21(f: Factory): number { const b: Box<V21> = f(new V21(21)); return b.value.n; }
function make21<T>(x: T): Box<T> {
  return new Box(x);
}
class V22 { constructor(public n: number) {} }
function use22(f: Factory): number { const b: Box<V22> = f(new V22(22)); return b.value.n; }
function make22<T>(x: T): Box<T> {
  return new Box(x);
}
class V23 { constructor(public n: number) {} }
function use23(f: Factory): number { const b: Box<V23> = f(new V23(23)); return b.value.n; }
function make23<T>(x: T): Box<T> {
  return new Box(x);
}
class V24 { constructor(public n: number) {} }
function use24(f: Factory): number { const b: Box<V24> = f(new V24(24)); return b.value.n; }
function make24<T>(x: T): Box<T> {
  return new Box(x);
}
class V25 { constructor(public n: number) {} }
function use25(f: Factory): number { const b: Box<V25> = f(new V25(25)); return b.value.n; }
function make25<T>(x: T): Box<T> {
  return new Box(x);
}
class V26 { constructor(public n: number) {} }
function use26(f: Factory): number { const b: Box<V26> = f(new V26(26)); return b.value.n; }
function make26<T>(x: T): Box<T> {
  return new Box(x);
}
class V27 { constructor(public n: number) {} }
function use27(f: Factory): number { const b: Box<V27> = f(new V27(27)); return b.value.n; }
function make27<T>(x: T): Box<T> {
  return new Box(x);
}
class V28 { constructor(public n: number) {} }
function use28(f: Factory): number { const b: Box<V28> = f(new V28(28)); return b.value.n; }
function make28<T>(x: T): Box<T> {
  return new Box(x);
}
class V29 { constructor(public n: number) {} }
function use29(f: Factory): number { const b: Box<V29> = f(new V29(29)); return b.value.n; }
function make29<T>(x: T): Box<T> {
  return new Box(x);
}
class V30 { constructor(public n: number) {} }
function use30(f: Factory): number { const b: Box<V30> = f(new V30(30)); return b.value.n; }
function make30<T>(x: T): Box<T> {
  return new Box(x);
}
class V31 { constructor(public n: number) {} }
function use31(f: Factory): number { const b: Box<V31> = f(new V31(31)); return b.value.n; }
function make31<T>(x: T): Box<T> {
  return new Box(x);
}
class V32 { constructor(public n: number) {} }
function use32(f: Factory): number { const b: Box<V32> = f(new V32(32)); return b.value.n; }
function make32<T>(x: T): Box<T> {
  return new Box(x);
}
class V33 { constructor(public n: number) {} }
function use33(f: Factory): number { const b: Box<V33> = f(new V33(33)); return b.value.n; }
function make33<T>(x: T): Box<T> {
  return new Box(x);
}
class V34 { constructor(public n: number) {} }
function use34(f: Factory): number { const b: Box<V34> = f(new V34(34)); return b.value.n; }
function make34<T>(x: T): Box<T> {
  return new Box(x);
}
class V35 { constructor(public n: number) {} }
function use35(f: Factory): number { const b: Box<V35> = f(new V35(35)); return b.value.n; }
function make35<T>(x: T): Box<T> {
  return new Box(x);
}
class V36 { constructor(public n: number) {} }
function use36(f: Factory): number { const b: Box<V36> = f(new V36(36)); return b.value.n; }
function make36<T>(x: T): Box<T> {
  return new Box(x);
}
class V37 { constructor(public n: number) {} }
function use37(f: Factory): number { const b: Box<V37> = f(new V37(37)); return b.value.n; }
function make37<T>(x: T): Box<T> {
  return new Box(x);
}
class V38 { constructor(public n: number) {} }
function use38(f: Factory): number { const b: Box<V38> = f(new V38(38)); return b.value.n; }
function make38<T>(x: T): Box<T> {
  return new Box(x);
}
class V39 { constructor(public n: number) {} }
function use39(f: Factory): number { const b: Box<V39> = f(new V39(39)); return b.value.n; }
function make39<T>(x: T): Box<T> {
  return new Box(x);
}
class V40 { constructor(public n: number) {} }
function use40(f: Factory): number { const b: Box<V40> = f(new V40(40)); return b.value.n; }
function make40<T>(x: T): Box<T> {
  return new Box(x);
}
class V41 { constructor(public n: number) {} }
function use41(f: Factory): number { const b: Box<V41> = f(new V41(41)); return b.value.n; }
function make41<T>(x: T): Box<T> {
  return new Box(x);
}
class V42 { constructor(public n: number) {} }
function use42(f: Factory): number { const b: Box<V42> = f(new V42(42)); return b.value.n; }
function make42<T>(x: T): Box<T> {
  return new Box(x);
}
class V43 { constructor(public n: number) {} }
function use43(f: Factory): number { const b: Box<V43> = f(new V43(43)); return b.value.n; }
function make43<T>(x: T): Box<T> {
  return new Box(x);
}
class V44 { constructor(public n: number) {} }
function use44(f: Factory): number { const b: Box<V44> = f(new V44(44)); return b.value.n; }
function make44<T>(x: T): Box<T> {
  return new Box(x);
}
class V45 { constructor(public n: number) {} }
function use45(f: Factory): number { const b: Box<V45> = f(new V45(45)); return b.value.n; }
function make45<T>(x: T): Box<T> {
  return new Box(x);
}
class V46 { constructor(public n: number) {} }
function use46(f: Factory): number { const b: Box<V46> = f(new V46(46)); return b.value.n; }
function make46<T>(x: T): Box<T> {
  return new Box(x);
}
class V47 { constructor(public n: number) {} }
function use47(f: Factory): number { const b: Box<V47> = f(new V47(47)); return b.value.n; }
function make47<T>(x: T): Box<T> {
  return new Box(x);
}
class V48 { constructor(public n: number) {} }
function use48(f: Factory): number { const b: Box<V48> = f(new V48(48)); return b.value.n; }
function make48<T>(x: T): Box<T> {
  return new Box(x);
}
class V49 { constructor(public n: number) {} }
function use49(f: Factory): number { const b: Box<V49> = f(new V49(49)); return b.value.n; }
function make49<T>(x: T): Box<T> {
  return new Box(x);
}
class V50 { constructor(public n: number) {} }
function use50(f: Factory): number { const b: Box<V50> = f(new V50(50)); return b.value.n; }
function make50<T>(x: T): Box<T> {
  return new Box(x);
}
class V51 { constructor(public n: number) {} }
function use51(f: Factory): number { const b: Box<V51> = f(new V51(51)); return b.value.n; }
function make51<T>(x: T): Box<T> {
  return new Box(x);
}
class V52 { constructor(public n: number) {} }
function use52(f: Factory): number { const b: Box<V52> = f(new V52(52)); return b.value.n; }
function make52<T>(x: T): Box<T> {
  return new Box(x);
}
class V53 { constructor(public n: number) {} }
function use53(f: Factory): number { const b: Box<V53> = f(new V53(53)); return b.value.n; }
function make53<T>(x: T): Box<T> {
  return new Box(x);
}
class V54 { constructor(public n: number) {} }
function use54(f: Factory): number { const b: Box<V54> = f(new V54(54)); return b.value.n; }
function make54<T>(x: T): Box<T> {
  return new Box(x);
}
class V55 { constructor(public n: number) {} }
function use55(f: Factory): number { const b: Box<V55> = f(new V55(55)); return b.value.n; }
function make55<T>(x: T): Box<T> {
  return new Box(x);
}
class V56 { constructor(public n: number) {} }
function use56(f: Factory): number { const b: Box<V56> = f(new V56(56)); return b.value.n; }
function make56<T>(x: T): Box<T> {
  return new Box(x);
}
class V57 { constructor(public n: number) {} }
function use57(f: Factory): number { const b: Box<V57> = f(new V57(57)); return b.value.n; }
function make57<T>(x: T): Box<T> {
  return new Box(x);
}
class V58 { constructor(public n: number) {} }
function use58(f: Factory): number { const b: Box<V58> = f(new V58(58)); return b.value.n; }
function make58<T>(x: T): Box<T> {
  return new Box(x);
}
class V59 { constructor(public n: number) {} }
function use59(f: Factory): number { const b: Box<V59> = f(new V59(59)); return b.value.n; }
function make59<T>(x: T): Box<T> {
  return new Box(x);
}
console.log(use0(make0));
console.log(use1(make1));
console.log(use2(make2));
console.log(use3(make3));
console.log(use4(make4));
console.log(use5(make5));
console.log(use6(make6));
console.log(use7(make7));
console.log(use8(make8));
console.log(use9(make9));
console.log(use10(make10));
console.log(use11(make11));
console.log(use12(make12));
console.log(use13(make13));
console.log(use14(make14));
console.log(use15(make15));
console.log(use16(make16));
console.log(use17(make17));
console.log(use18(make18));
console.log(use19(make19));
console.log(use20(make20));
console.log(use21(make21));
console.log(use22(make22));
console.log(use23(make23));
console.log(use24(make24));
console.log(use25(make25));
console.log(use26(make26));
console.log(use27(make27));
console.log(use28(make28));
console.log(use29(make29));
console.log(use30(make30));
console.log(use31(make31));
console.log(use32(make32));
console.log(use33(make33));
console.log(use34(make34));
console.log(use35(make35));
console.log(use36(make36));
console.log(use37(make37));
console.log(use38(make38));
console.log(use39(make39));
console.log(use40(make40));
console.log(use41(make41));
console.log(use42(make42));
console.log(use43(make43));
console.log(use44(make44));
console.log(use45(make45));
console.log(use46(make46));
console.log(use47(make47));
console.log(use48(make48));
console.log(use49(make49));
console.log(use50(make50));
console.log(use51(make51));
console.log(use52(make52));
console.log(use53(make53));
console.log(use54(make54));
console.log(use55(make55));
console.log(use56(make56));
console.log(use57(make57));
console.log(use58(make58));
console.log(use59(make59));
