class Box<T> {
  constructor(public value: T) {}
}
class C0 {
  tag = 0;
}
class C1 {
  tag = 1;
}
class C2 {
  tag = 2;
}
class C3 {
  tag = 3;
}
class C4 {
  tag = 4;
}
class C5 {
  tag = 5;
}
class C6 {
  tag = 6;
}
class C7 {
  tag = 7;
}
class C8 {
  tag = 8;
}
class C9 {
  tag = 9;
}
class C10 {
  tag = 10;
}
class C11 {
  tag = 11;
}
class C12 {
  tag = 12;
}
class C13 {
  tag = 13;
}
class C14 {
  tag = 14;
}
class C15 {
  tag = 15;
}
class C16 {
  tag = 16;
}
class C17 {
  tag = 17;
}
class C18 {
  tag = 18;
}
class C19 {
  tag = 19;
}
class C20 {
  tag = 20;
}
class C21 {
  tag = 21;
}
class C22 {
  tag = 22;
}
class C23 {
  tag = 23;
}
class C24 {
  tag = 24;
}
class C25 {
  tag = 25;
}
class C26 {
  tag = 26;
}
class C27 {
  tag = 27;
}
class C28 {
  tag = 28;
}
class C29 {
  tag = 29;
}
class C30 {
  tag = 30;
}
class C31 {
  tag = 31;
}
class C32 {
  tag = 32;
}
class C33 {
  tag = 33;
}
class C34 {
  tag = 34;
}
class C35 {
  tag = 35;
}
class C36 {
  tag = 36;
}
class C37 {
  tag = 37;
}
class C38 {
  tag = 38;
}
class C39 {
  tag = 39;
}
class C40 {
  tag = 40;
}
class C41 {
  tag = 41;
}
class C42 {
  tag = 42;
}
class C43 {
  tag = 43;
}
class C44 {
  tag = 44;
}
class C45 {
  tag = 45;
}
class C46 {
  tag = 46;
}
class C47 {
  tag = 47;
}
class C48 {
  tag = 48;
}
class C49 {
  tag = 49;
}
let total = 0;
const keep: any[] = [];
function use(f: <T>(x: T) => Box<T>): void {
  const b0: Box<C0> = f(new C0());
  total += b0.value.tag;
  const b1: Box<C1> = f(new C1());
  total += b1.value.tag;
  const b2: Box<C2> = f(new C2());
  total += b2.value.tag;
  const b3: Box<C3> = f(new C3());
  total += b3.value.tag;
  const b4: Box<C4> = f(new C4());
  total += b4.value.tag;
  const b5: Box<C5> = f(new C5());
  total += b5.value.tag;
  const b6: Box<C6> = f(new C6());
  total += b6.value.tag;
  const b7: Box<C7> = f(new C7());
  total += b7.value.tag;
  const b8: Box<C8> = f(new C8());
  total += b8.value.tag;
  const b9: Box<C9> = f(new C9());
  total += b9.value.tag;
  const b10: Box<C10> = f(new C10());
  total += b10.value.tag;
  const b11: Box<C11> = f(new C11());
  total += b11.value.tag;
  const b12: Box<C12> = f(new C12());
  total += b12.value.tag;
  const b13: Box<C13> = f(new C13());
  total += b13.value.tag;
  const b14: Box<C14> = f(new C14());
  total += b14.value.tag;
  const b15: Box<C15> = f(new C15());
  total += b15.value.tag;
  const b16: Box<C16> = f(new C16());
  total += b16.value.tag;
  const b17: Box<C17> = f(new C17());
  total += b17.value.tag;
  const b18: Box<C18> = f(new C18());
  total += b18.value.tag;
  const b19: Box<C19> = f(new C19());
  total += b19.value.tag;
  const b20: Box<C20> = f(new C20());
  total += b20.value.tag;
  const b21: Box<C21> = f(new C21());
  total += b21.value.tag;
  const b22: Box<C22> = f(new C22());
  total += b22.value.tag;
  const b23: Box<C23> = f(new C23());
  total += b23.value.tag;
  const b24: Box<C24> = f(new C24());
  total += b24.value.tag;
  const b25: Box<C25> = f(new C25());
  total += b25.value.tag;
  const b26: Box<C26> = f(new C26());
  total += b26.value.tag;
  const b27: Box<C27> = f(new C27());
  total += b27.value.tag;
  const b28: Box<C28> = f(new C28());
  total += b28.value.tag;
  const b29: Box<C29> = f(new C29());
  total += b29.value.tag;
  const b30: Box<C30> = f(new C30());
  total += b30.value.tag;
  const b31: Box<C31> = f(new C31());
  total += b31.value.tag;
  const b32: Box<C32> = f(new C32());
  total += b32.value.tag;
  const b33: Box<C33> = f(new C33());
  total += b33.value.tag;
  const b34: Box<C34> = f(new C34());
  total += b34.value.tag;
  const b35: Box<C35> = f(new C35());
  total += b35.value.tag;
  const b36: Box<C36> = f(new C36());
  total += b36.value.tag;
  const b37: Box<C37> = f(new C37());
  total += b37.value.tag;
  const b38: Box<C38> = f(new C38());
  total += b38.value.tag;
  const b39: Box<C39> = f(new C39());
  total += b39.value.tag;
  const b40: Box<C40> = f(new C40());
  total += b40.value.tag;
  const b41: Box<C41> = f(new C41());
  total += b41.value.tag;
  const b42: Box<C42> = f(new C42());
  total += b42.value.tag;
  const b43: Box<C43> = f(new C43());
  total += b43.value.tag;
  const b44: Box<C44> = f(new C44());
  total += b44.value.tag;
  const b45: Box<C45> = f(new C45());
  total += b45.value.tag;
  const b46: Box<C46> = f(new C46());
  total += b46.value.tag;
  const b47: Box<C47> = f(new C47());
  total += b47.value.tag;
  const b48: Box<C48> = f(new C48());
  total += b48.value.tag;
  const b49: Box<C49> = f(new C49());
  total += b49.value.tag;
}
function main(): void {
  const a0 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a0);
  const a1 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a1);
  const a2 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a2);
  const a3 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a3);
  const a4 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a4);
  const a5 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a5);
  const a6 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a6);
  const a7 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a7);
  const a8 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a8);
  const a9 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a9);
  const a10 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a10);
  const a11 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a11);
  const a12 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a12);
  const a13 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a13);
  const a14 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a14);
  const a15 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a15);
  const a16 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a16);
  const a17 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a17);
  const a18 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a18);
  const a19 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a19);
  const a20 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a20);
  const a21 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a21);
  const a22 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a22);
  const a23 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a23);
  const a24 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a24);
  const a25 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a25);
  const a26 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a26);
  const a27 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a27);
  const a28 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a28);
  const a29 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a29);
  const a30 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a30);
  const a31 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a31);
  const a32 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a32);
  const a33 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a33);
  const a34 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a34);
  const a35 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a35);
  const a36 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a36);
  const a37 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a37);
  const a38 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a38);
  const a39 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a39);
  const a40 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a40);
  const a41 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a41);
  const a42 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a42);
  const a43 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a43);
  const a44 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a44);
  const a45 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a45);
  const a46 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a46);
  const a47 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a47);
  const a48 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a48);
  const a49 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a49);
  const a50 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a50);
  const a51 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a51);
  const a52 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a52);
  const a53 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a53);
  const a54 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a54);
  const a55 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a55);
  const a56 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a56);
  const a57 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a57);
  const a58 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a58);
  const a59 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a59);
  const a60 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a60);
  const a61 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a61);
  const a62 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a62);
  const a63 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a63);
  const a64 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a64);
  const a65 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a65);
  const a66 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a66);
  const a67 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a67);
  const a68 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a68);
  const a69 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a69);
  const a70 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a70);
  const a71 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a71);
  const a72 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a72);
  const a73 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a73);
  const a74 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a74);
  const a75 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a75);
  const a76 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a76);
  const a77 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a77);
  const a78 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a78);
  const a79 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a79);
  const a80 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a80);
  const a81 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a81);
  const a82 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a82);
  const a83 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a83);
  const a84 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a84);
  const a85 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a85);
  const a86 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a86);
  const a87 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a87);
  const a88 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a88);
  const a89 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a89);
  const a90 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a90);
  const a91 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a91);
  const a92 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a92);
  const a93 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a93);
  const a94 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a94);
  const a95 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a95);
  const a96 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a96);
  const a97 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a97);
  const a98 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a98);
  const a99 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a99);
  const a100 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a100);
  const a101 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a101);
  const a102 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a102);
  const a103 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a103);
  const a104 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a104);
  const a105 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a105);
  const a106 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a106);
  const a107 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a107);
  const a108 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a108);
  const a109 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a109);
  const a110 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a110);
  const a111 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a111);
  const a112 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a112);
  const a113 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a113);
  const a114 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a114);
  const a115 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a115);
  const a116 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a116);
  const a117 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a117);
  const a118 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a118);
  const a119 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a119);
  const a120 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a120);
  const a121 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a121);
  const a122 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a122);
  const a123 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a123);
  const a124 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a124);
  const a125 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a125);
  const a126 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a126);
  const a127 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a127);
  const a128 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a128);
  const a129 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a129);
  const a130 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a130);
  const a131 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a131);
  const a132 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a132);
  const a133 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a133);
  const a134 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a134);
  const a135 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a135);
  const a136 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a136);
  const a137 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a137);
  const a138 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a138);
  const a139 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a139);
  const a140 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a140);
  const a141 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a141);
  const a142 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a142);
  const a143 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a143);
  const a144 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a144);
  const a145 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a145);
  const a146 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a146);
  const a147 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a147);
  const a148 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a148);
  const a149 = <T>(x: T): Box<T> => new Box(x);
  keep.push(a149);
  use(<T>(x: T): Box<T> => new Box(x));
}
main();
console.log(total, keep.length);
