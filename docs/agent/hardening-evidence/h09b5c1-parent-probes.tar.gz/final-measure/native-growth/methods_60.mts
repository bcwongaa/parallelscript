// C172(c): 60 method values, each passed to its own one-type consumer (review round 1's s_N).
class Box<T> {
  constructor(public value: T) {}
}
type Factory = <T>(x: T) => Box<T>;
class V0 { constructor(public n: number) {} }
function use0(f: Factory): number { const b: Box<V0> = f(new V0(0)); return b.value.n; }
class M0 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V1 { constructor(public n: number) {} }
function use1(f: Factory): number { const b: Box<V1> = f(new V1(1)); return b.value.n; }
class M1 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V2 { constructor(public n: number) {} }
function use2(f: Factory): number { const b: Box<V2> = f(new V2(2)); return b.value.n; }
class M2 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V3 { constructor(public n: number) {} }
function use3(f: Factory): number { const b: Box<V3> = f(new V3(3)); return b.value.n; }
class M3 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V4 { constructor(public n: number) {} }
function use4(f: Factory): number { const b: Box<V4> = f(new V4(4)); return b.value.n; }
class M4 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V5 { constructor(public n: number) {} }
function use5(f: Factory): number { const b: Box<V5> = f(new V5(5)); return b.value.n; }
class M5 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V6 { constructor(public n: number) {} }
function use6(f: Factory): number { const b: Box<V6> = f(new V6(6)); return b.value.n; }
class M6 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V7 { constructor(public n: number) {} }
function use7(f: Factory): number { const b: Box<V7> = f(new V7(7)); return b.value.n; }
class M7 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V8 { constructor(public n: number) {} }
function use8(f: Factory): number { const b: Box<V8> = f(new V8(8)); return b.value.n; }
class M8 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V9 { constructor(public n: number) {} }
function use9(f: Factory): number { const b: Box<V9> = f(new V9(9)); return b.value.n; }
class M9 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V10 { constructor(public n: number) {} }
function use10(f: Factory): number { const b: Box<V10> = f(new V10(10)); return b.value.n; }
class M10 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V11 { constructor(public n: number) {} }
function use11(f: Factory): number { const b: Box<V11> = f(new V11(11)); return b.value.n; }
class M11 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V12 { constructor(public n: number) {} }
function use12(f: Factory): number { const b: Box<V12> = f(new V12(12)); return b.value.n; }
class M12 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V13 { constructor(public n: number) {} }
function use13(f: Factory): number { const b: Box<V13> = f(new V13(13)); return b.value.n; }
class M13 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V14 { constructor(public n: number) {} }
function use14(f: Factory): number { const b: Box<V14> = f(new V14(14)); return b.value.n; }
class M14 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V15 { constructor(public n: number) {} }
function use15(f: Factory): number { const b: Box<V15> = f(new V15(15)); return b.value.n; }
class M15 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V16 { constructor(public n: number) {} }
function use16(f: Factory): number { const b: Box<V16> = f(new V16(16)); return b.value.n; }
class M16 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V17 { constructor(public n: number) {} }
function use17(f: Factory): number { const b: Box<V17> = f(new V17(17)); return b.value.n; }
class M17 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V18 { constructor(public n: number) {} }
function use18(f: Factory): number { const b: Box<V18> = f(new V18(18)); return b.value.n; }
class M18 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V19 { constructor(public n: number) {} }
function use19(f: Factory): number { const b: Box<V19> = f(new V19(19)); return b.value.n; }
class M19 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V20 { constructor(public n: number) {} }
function use20(f: Factory): number { const b: Box<V20> = f(new V20(20)); return b.value.n; }
class M20 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V21 { constructor(public n: number) {} }
function use21(f: Factory): number { const b: Box<V21> = f(new V21(21)); return b.value.n; }
class M21 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V22 { constructor(public n: number) {} }
function use22(f: Factory): number { const b: Box<V22> = f(new V22(22)); return b.value.n; }
class M22 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V23 { constructor(public n: number) {} }
function use23(f: Factory): number { const b: Box<V23> = f(new V23(23)); return b.value.n; }
class M23 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V24 { constructor(public n: number) {} }
function use24(f: Factory): number { const b: Box<V24> = f(new V24(24)); return b.value.n; }
class M24 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V25 { constructor(public n: number) {} }
function use25(f: Factory): number { const b: Box<V25> = f(new V25(25)); return b.value.n; }
class M25 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V26 { constructor(public n: number) {} }
function use26(f: Factory): number { const b: Box<V26> = f(new V26(26)); return b.value.n; }
class M26 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V27 { constructor(public n: number) {} }
function use27(f: Factory): number { const b: Box<V27> = f(new V27(27)); return b.value.n; }
class M27 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V28 { constructor(public n: number) {} }
function use28(f: Factory): number { const b: Box<V28> = f(new V28(28)); return b.value.n; }
class M28 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V29 { constructor(public n: number) {} }
function use29(f: Factory): number { const b: Box<V29> = f(new V29(29)); return b.value.n; }
class M29 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V30 { constructor(public n: number) {} }
function use30(f: Factory): number { const b: Box<V30> = f(new V30(30)); return b.value.n; }
class M30 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V31 { constructor(public n: number) {} }
function use31(f: Factory): number { const b: Box<V31> = f(new V31(31)); return b.value.n; }
class M31 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V32 { constructor(public n: number) {} }
function use32(f: Factory): number { const b: Box<V32> = f(new V32(32)); return b.value.n; }
class M32 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V33 { constructor(public n: number) {} }
function use33(f: Factory): number { const b: Box<V33> = f(new V33(33)); return b.value.n; }
class M33 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V34 { constructor(public n: number) {} }
function use34(f: Factory): number { const b: Box<V34> = f(new V34(34)); return b.value.n; }
class M34 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V35 { constructor(public n: number) {} }
function use35(f: Factory): number { const b: Box<V35> = f(new V35(35)); return b.value.n; }
class M35 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V36 { constructor(public n: number) {} }
function use36(f: Factory): number { const b: Box<V36> = f(new V36(36)); return b.value.n; }
class M36 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V37 { constructor(public n: number) {} }
function use37(f: Factory): number { const b: Box<V37> = f(new V37(37)); return b.value.n; }
class M37 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V38 { constructor(public n: number) {} }
function use38(f: Factory): number { const b: Box<V38> = f(new V38(38)); return b.value.n; }
class M38 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V39 { constructor(public n: number) {} }
function use39(f: Factory): number { const b: Box<V39> = f(new V39(39)); return b.value.n; }
class M39 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V40 { constructor(public n: number) {} }
function use40(f: Factory): number { const b: Box<V40> = f(new V40(40)); return b.value.n; }
class M40 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V41 { constructor(public n: number) {} }
function use41(f: Factory): number { const b: Box<V41> = f(new V41(41)); return b.value.n; }
class M41 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V42 { constructor(public n: number) {} }
function use42(f: Factory): number { const b: Box<V42> = f(new V42(42)); return b.value.n; }
class M42 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V43 { constructor(public n: number) {} }
function use43(f: Factory): number { const b: Box<V43> = f(new V43(43)); return b.value.n; }
class M43 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V44 { constructor(public n: number) {} }
function use44(f: Factory): number { const b: Box<V44> = f(new V44(44)); return b.value.n; }
class M44 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V45 { constructor(public n: number) {} }
function use45(f: Factory): number { const b: Box<V45> = f(new V45(45)); return b.value.n; }
class M45 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V46 { constructor(public n: number) {} }
function use46(f: Factory): number { const b: Box<V46> = f(new V46(46)); return b.value.n; }
class M46 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V47 { constructor(public n: number) {} }
function use47(f: Factory): number { const b: Box<V47> = f(new V47(47)); return b.value.n; }
class M47 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V48 { constructor(public n: number) {} }
function use48(f: Factory): number { const b: Box<V48> = f(new V48(48)); return b.value.n; }
class M48 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V49 { constructor(public n: number) {} }
function use49(f: Factory): number { const b: Box<V49> = f(new V49(49)); return b.value.n; }
class M49 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V50 { constructor(public n: number) {} }
function use50(f: Factory): number { const b: Box<V50> = f(new V50(50)); return b.value.n; }
class M50 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V51 { constructor(public n: number) {} }
function use51(f: Factory): number { const b: Box<V51> = f(new V51(51)); return b.value.n; }
class M51 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V52 { constructor(public n: number) {} }
function use52(f: Factory): number { const b: Box<V52> = f(new V52(52)); return b.value.n; }
class M52 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V53 { constructor(public n: number) {} }
function use53(f: Factory): number { const b: Box<V53> = f(new V53(53)); return b.value.n; }
class M53 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V54 { constructor(public n: number) {} }
function use54(f: Factory): number { const b: Box<V54> = f(new V54(54)); return b.value.n; }
class M54 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V55 { constructor(public n: number) {} }
function use55(f: Factory): number { const b: Box<V55> = f(new V55(55)); return b.value.n; }
class M55 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V56 { constructor(public n: number) {} }
function use56(f: Factory): number { const b: Box<V56> = f(new V56(56)); return b.value.n; }
class M56 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V57 { constructor(public n: number) {} }
function use57(f: Factory): number { const b: Box<V57> = f(new V57(57)); return b.value.n; }
class M57 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V58 { constructor(public n: number) {} }
function use58(f: Factory): number { const b: Box<V58> = f(new V58(58)); return b.value.n; }
class M58 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V59 { constructor(public n: number) {} }
function use59(f: Factory): number { const b: Box<V59> = f(new V59(59)); return b.value.n; }
class M59 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
console.log(use0(new M0().make));
console.log(use1(new M1().make));
console.log(use2(new M2().make));
console.log(use3(new M3().make));
console.log(use4(new M4().make));
console.log(use5(new M5().make));
console.log(use6(new M6().make));
console.log(use7(new M7().make));
console.log(use8(new M8().make));
console.log(use9(new M9().make));
console.log(use10(new M10().make));
console.log(use11(new M11().make));
console.log(use12(new M12().make));
console.log(use13(new M13().make));
console.log(use14(new M14().make));
console.log(use15(new M15().make));
console.log(use16(new M16().make));
console.log(use17(new M17().make));
console.log(use18(new M18().make));
console.log(use19(new M19().make));
console.log(use20(new M20().make));
console.log(use21(new M21().make));
console.log(use22(new M22().make));
console.log(use23(new M23().make));
console.log(use24(new M24().make));
console.log(use25(new M25().make));
console.log(use26(new M26().make));
console.log(use27(new M27().make));
console.log(use28(new M28().make));
console.log(use29(new M29().make));
console.log(use30(new M30().make));
console.log(use31(new M31().make));
console.log(use32(new M32().make));
console.log(use33(new M33().make));
console.log(use34(new M34().make));
console.log(use35(new M35().make));
console.log(use36(new M36().make));
console.log(use37(new M37().make));
console.log(use38(new M38().make));
console.log(use39(new M39().make));
console.log(use40(new M40().make));
console.log(use41(new M41().make));
console.log(use42(new M42().make));
console.log(use43(new M43().make));
console.log(use44(new M44().make));
console.log(use45(new M45().make));
console.log(use46(new M46().make));
console.log(use47(new M47().make));
console.log(use48(new M48().make));
console.log(use49(new M49().make));
console.log(use50(new M50().make));
console.log(use51(new M51().make));
console.log(use52(new M52().make));
console.log(use53(new M53().make));
console.log(use54(new M54().make));
console.log(use55(new M55().make));
console.log(use56(new M56().make));
console.log(use57(new M57().make));
console.log(use58(new M58().make));
console.log(use59(new M59().make));
