import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

scratch = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
env = dict(os.environ, GOMAXPROCS="4")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(args, prefix, env):
    with (scratch / (prefix + ".stdout")).open("xb") as stdout, (scratch / (prefix + ".stderr")).open("xb") as stderr:
        p = subprocess.run(args, cwd=root, env=env, stdout=stdout, stderr=stderr)
    (scratch / (prefix + ".exit")).write_text(str(p.returncode) + "\n")
    return p.returncode

rc = run(["make", "build"], "acceptance-build", env)
if rc:
    sys.exit(rc)
files = subprocess.run(["git", "ls-files", "-c", "-o", "--exclude-standard", "pts", "cmd/pts"], cwd=root,
                       capture_output=True, text=True, check=True).stdout.splitlines()
files = sorted({name for name in files if (root / name).is_file()})
before = {name: sha(root / name) for name in files}
cli_before = sha(root / "pts-bin/pts")
(scratch / "acceptance-suite-sources-before.json").write_text(json.dumps({"sources": before, "cli_sha256": cli_before}, indent=2) + "\n")
args = ["go", "test", "-count=1", "-json", "-p", "4", "-parallel", "4", "-timeout", "40m", "./pts/...", "./cmd/pts/"]
(scratch / "acceptance-suite-command.json").write_text(json.dumps({"command": args, "env": {"GOMAXPROCS": "4", "PTS_REQUIRE_NODE": "1"}}, indent=2) + "\n")
with (scratch / "acceptance-suite.jsonl").open("xb") as stdout, (scratch / "acceptance-suite.stderr").open("xb") as stderr:
    suite = subprocess.run(args, cwd=root, env=dict(env, PTS_REQUIRE_NODE="1"), stdout=stdout, stderr=stderr)
(scratch / "acceptance-suite.exit").write_text(str(suite.returncode) + "\n")
after = {name: sha(root / name) if (root / name).is_file() else None for name in files}
new_files = subprocess.run(["git", "ls-files", "-c", "-o", "--exclude-standard", "pts", "cmd/pts"], cwd=root,
                          capture_output=True, text=True, check=True).stdout.splitlines()
receipt = {"changed_sources": [name for name in files if before[name] != after[name]],
           "added_sources": sorted(set(new_files) - set(files)),
           "cli_unchanged": cli_before == sha(root / "pts-bin/pts"),
           "cli_sha256": cli_before}
(scratch / "acceptance-suite-source-check.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"suite_exit": suite.returncode, "source_check": receipt}))
if suite.returncode:
    sys.exit(suite.returncode)
assert not receipt["changed_sources"] and not receipt["added_sources"] and receipt["cli_unchanged"]
