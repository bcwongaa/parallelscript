import gzip
import hashlib
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time

repo, scratch, source_dir = map(pathlib.Path, sys.argv[1:])
output = scratch / 'growth'
output.mkdir()
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
compilers = {'base': scratch / 'base-pts', 'current': scratch / 'current-pts'}
results = []
for index, source in enumerate(sorted(source_dir.glob('*.pts'))):
    for label in (('base', 'current') if index % 2 == 0 else ('current', 'base')):
        stem = source.stem + '.' + label
        cpath = output / (stem + '.c')
        errpath = output / (stem + '.stderr')
        timepath = output / (stem + '.time')
        command = ['/usr/bin/time', '-f', '%e %M', '-o', str(timepath),
                   str(compilers[label]), 'emit-c', str(source)]
        started = time.monotonic()
        with cpath.open('wb') as stdout, errpath.open('wb') as stderr:
            process = subprocess.Popen(command, cwd=repo, env=env, stdout=stdout,
                                       stderr=stderr, start_new_session=True)
            try:
                code = process.wait(timeout=240)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
                code = 'timeout'
        data = cpath.read_bytes()
        text = data.decode(errors='replace')
        named_pairs = set(re.findall(r'\bpts_fn_(?:main_a\d+_C\d+|make\d+_V\d+)\(', text))
        row = {'case': source.stem, 'compiler': label, 'command': command,
               'exit': code, 'wall_seconds': time.monotonic() - started,
               'time_peak_rss': timepath.read_text().strip(),
               'c_lines': len(data.splitlines()), 'c_bytes': len(data),
               'c_sha256': hashlib.sha256(data).hexdigest(),
               'unused_arrow_or_declaration_pairs': len(named_pairs),
               'stderr_bytes': errpath.stat().st_size,
               'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'compiler_sha256': hashlib.sha256(compilers[label].read_bytes()).hexdigest()}
        with gzip.GzipFile(str(output / (stem + '.c.gz')), 'wb', mtime=0) as archive:
            archive.write(data)
        cpath.unlink()
        results.append(row)
        (output / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        if code != 0:
            raise SystemExit('growth emit-c failed')
