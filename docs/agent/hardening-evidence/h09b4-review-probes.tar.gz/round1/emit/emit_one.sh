#!/bin/bash
# emit_one.sh file.pts -> prints "name base_lines snap_lines base_exit snap_exit"
f=$1; n=$(basename $f .pts)
o=/tmp/h09b4/review/round1/emit/out; mkdir -p $o
PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/base/pts-bin/pts emit-c "$f" > $o/$n.base.c 2>$o/$n.base.err; be=$?
PTS_HOME=/tmp/h09b4/snap3 timeout 120 /tmp/h09b4/snap3/pts-bin/pts emit-c "$f" > $o/$n.snap.c 2>$o/$n.snap.err; se=$?
echo "$n $(wc -l < $o/$n.base.c) $(wc -l < $o/$n.snap.c) $be $se"
