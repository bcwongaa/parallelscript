#!/bin/bash
f=$1; n=$(basename $f .pts)
b=$(PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/review/nofb/nofb-base all "$f" 2>&1 | head -c 300 | tr '\n' ' ')
s=$(PTS_HOME=/tmp/h09b4/snap3 timeout 120 /tmp/h09b4/review/nofb/nofb-snap all "$f" 2>&1 | head -c 300 | tr '\n' ' ')
echo "$n|$b|$s"
