#!/bin/bash
# usage: run.sh probe.pts [more...]  -> writes out/<name>.{node,base,snap}.txt and prints a summary
R=/tmp/h09b4/review/round1
NODE=~/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0")
  n=$(basename "$f" .pts)
  d=$R/out/$n; mkdir -p $d
  cp "$f" $d/$n.mts
  (cd $d && TZ=America/New_York timeout 30 $NODE --no-warnings --experimental-transform-types $n.mts > node.txt 2>&1; echo "exit=$?" >> node.txt)
  (cd $d && PTS_HOME=/tmp/h09b4/base PTS_CACHE_DIR=/tmp/h09b4/review/cache-base TZ=America/New_York timeout 120 /tmp/h09b4/base/pts-bin/pts run "$f" > base.txt 2>&1; echo "exit=$?" >> base.txt)
  (cd $d && PTS_HOME=/tmp/h09b4/snap3 PTS_CACHE_DIR=/tmp/h09b4/review/cache-snap TZ=America/New_York timeout 120 /tmp/h09b4/snap3/pts-bin/pts run "$f" > snap.txt 2>&1; echo "exit=$?" >> snap.txt)
  echo "=== $n"
  if cmp -s $d/node.txt $d/snap.txt; then echo "snap==node"; else echo "--- node"; cat $d/node.txt; echo "--- snap"; cat $d/snap.txt; fi
  if cmp -s $d/base.txt $d/snap.txt; then echo "base==snap"; else echo "--- base"; cat $d/base.txt; fi
done
