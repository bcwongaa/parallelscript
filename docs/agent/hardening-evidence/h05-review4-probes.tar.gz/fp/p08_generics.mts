interface HasId { id: number }
class Item implements HasId { constructor(public id: number, public tag: string) {} }
function expand<T extends HasId>(xs: T[], f: (x: T) => T[]): T[] {
  return xs.flatMap((x) => f(x));
}
function ids<T extends HasId>(xs: T[]): HasId[] {
  return xs.flatMap<HasId>((x) => [x, x]);
}
const items = [new Item(1, "a"), new Item(2, "b")];
console.log(expand(items, (x) => [x, x]).map((i) => i.tag).join(""));
const hs = ids(items);
console.log(hs.length, hs[0] === items[0]);
function pairUp<T>(xs: T[]): T[] { return xs.flatMap((x) => [x, x]); }
console.log(pairUp([1, 2]), pairUp(["a"]), pairUp(items).length);
