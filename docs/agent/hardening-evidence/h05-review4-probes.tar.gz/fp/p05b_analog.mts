const ns = [1, 2];
const r: (number | string)[][] = ns.map((m) => [m]);
console.log(r);
const r1: (number | string)[][] = [1].flatMap(() => ns.map((m) => [m]));
console.log(r1);
const r3 = [1].flatMap<(number | string)[]>(() => [ns.map((m) => m)]);
console.log(r3);
