const xs: unknown[] = [1, () => 2, "a"];
const r = xs.flatMap<unknown>((x) => (typeof x === "function" ? [x] : []));
console.log(r.length);
const r2 = xs.flatMap<unknown>((x) => (typeof x === "function" ? x : []));
console.log(r2.length);
