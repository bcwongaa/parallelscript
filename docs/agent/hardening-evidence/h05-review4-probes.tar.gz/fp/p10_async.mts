class C { constructor(public x: number) {} }
const c = new C(1);
async function main() {
  const ps = [1, 2].flatMap(async (n) => [c, n]);
  const vs = await Promise.all(ps);
  console.log(vs.length, vs[0][0] === c);
}
main();
