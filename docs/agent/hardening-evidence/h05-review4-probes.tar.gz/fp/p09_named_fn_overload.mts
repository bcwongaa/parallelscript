interface J { x: number }
class C { constructor(public x: number) {} }
function twice(c: C): C[] { return [c, c]; }
const cs = [new C(1), new C(2)];
const r = cs.flatMap(twice);
console.log(r.length, r[0] === cs[0]);
const r2 = cs.flatMap<J>(twice);
console.log(r2.length, r2[0] === cs[0]);
class Box { items = [1, 2]; get(n: number): number[] { return this.items.map((i) => i * n); } }
const b = new Box();
console.log([1, 2].flatMap(b.get.bind(b)));
console.log([1, 2].flatMap((n) => b.get(n)));
function withDefault(n: number, i: number = 10): number[] { return [n, i]; }
console.log([1, 2].flatMap((n) => withDefault(n)));
