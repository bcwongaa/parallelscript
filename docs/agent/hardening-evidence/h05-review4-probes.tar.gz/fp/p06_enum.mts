enum Color { Red, Green }
enum S { A = "a", B = "b" }
const r = [1, 2].flatMap((n) => (n > 1 ? [Color.Red, Color.Green] : [Color.Green]));
console.log(r);
const r2 = [1].flatMap<S | number>(() => [S.A, 3]);
console.log(r2);
const r3 = [1].flatMap(() => [Color]);
console.log(r3.length);
