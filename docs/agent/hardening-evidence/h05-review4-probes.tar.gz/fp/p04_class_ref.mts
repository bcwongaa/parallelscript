class C { constructor(public x: number) {} }
const r = [1].flatMap(() => [C]);
console.log(r.length, new r[0](4).x);
