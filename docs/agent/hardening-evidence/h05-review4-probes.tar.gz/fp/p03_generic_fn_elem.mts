function identity<T>(x: T): T { return x; }
const r = [1].flatMap<(n: number) => number>(() => [identity]);
console.log(r.length, r[0](3));
