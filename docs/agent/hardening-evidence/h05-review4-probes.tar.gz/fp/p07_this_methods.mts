interface Named { name: string }
class Node1 implements Named {
  children: Node1[] = [];
  constructor(public name: string) {}
  all(): Named[] {
    return [this as Named].concat(this.children.flatMap((c) => c.all()));
  }
  selfAndKids(): Node1[] {
    return this.children.flatMap((c) => [c, this]);
  }
  named(): Named[] {
    return this.children.flatMap<Named>((c) => [c, this]);
  }
}
const root = new Node1("r");
root.children.push(new Node1("a"), new Node1("b"));
console.log(root.all().map((n) => n.name).join(","));
console.log(root.selfAndKids().map((n) => n.name).join(","));
const nm = root.named();
console.log(nm.map((n) => n.name).join(","), nm[1] === root);
