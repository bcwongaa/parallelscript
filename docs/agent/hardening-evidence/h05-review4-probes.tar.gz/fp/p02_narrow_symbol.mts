const xs: unknown[] = [1, "a", 2];
const r = xs.flatMap<unknown>((x) => {
  if (typeof x === "number") return [x, x];
  return [];
});
console.log(r);
