interface J1 { x: number | string; tag: string }
interface J2 { y: number | string }
class C { constructor(public x: number, public tag: string) {} }
const c = new C(1, "t");
const r = [1].flatMap<J1 | J2>(() => [c]);
console.log(r.length, r[0] === c);
