const p: [number, string] = [1, "a"];
const r = [1].flatMap<[number, string | number]>(() => [p]);
console.log(r.length, r[0] === p, r[0][1]);
p[1] = "b";
console.log(r[0][1]);
