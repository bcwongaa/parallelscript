interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J | number>(() => [c, 2]);
console.log(r.length, r[0] === c, r[1]);
