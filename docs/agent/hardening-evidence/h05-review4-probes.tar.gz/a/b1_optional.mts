interface J { x: number; y?: string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J>(() => [c]);
c.x = 5;
console.log(r.length, r[0].x, r[0].y);
const cs = [c, new C(2)];
const r2 = [1].flatMap<J>(() => cs);
cs[1].x = 7;
console.log(r2.length, r2[1].x, r2[1].y);
