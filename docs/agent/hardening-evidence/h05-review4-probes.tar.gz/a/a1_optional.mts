interface J { x: number; y?: string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J>(() => [c]);
console.log(r.length, r[0] === c, r[0].x, r[0].y);
const cs = [c, new C(2)];
const r2 = [1].flatMap<J>(() => cs);
console.log(r2.length, r2[0] === c, r2[1].x, r2[1].y);
