interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const a: any = c;
const j: J = a;
c.x = 5;
console.log(j.x);
