const r3 = [1, 2].flatMap(<T,>(n: T) => [n]);
console.log(r3);
function dup<T>(x: T): T[] { return [x, x]; }
console.log([1, 2].flatMap(dup));
console.log(["a"].flatMap((s) => dup(s)));
