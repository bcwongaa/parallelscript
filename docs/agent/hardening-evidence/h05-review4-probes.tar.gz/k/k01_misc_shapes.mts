interface J { x: number }
class K { constructor(public x: number) {} }
const k = new K(1);
const xs: number[] | undefined = [1, 2];
const r1 = xs?.flatMap<J>((n) => [k, ...[k]]);
console.log(r1?.length);
const r2 = [1, 2].flatMap(function (this: void, n: number) { return [n, n * 2]; });
console.log(r2);
const r3 = [1, 2].flatMap(<T,>(n: T) => [n]);
console.log(r3);
const named = function twice(n: number): number[] { return n > 5 ? [n] : twice(n + 5); };
console.log([1, 2].flatMap(named));
const maybe = { inner: { ks: [k] as K[] | undefined } };
const r4 = [1].flatMap<J>(() => maybe?.inner?.ks ?? []);
console.log(r4.length, r4[0] === k);
const r5 = [1].flatMap<J | undefined>(() => [maybe.inner.ks?.[0]]);
console.log(r5.length, r5[0] === k);
