interface J { x: number | string }
class C { constructor(public x: number) {} }
const cobj = new C(1);
const js: J[] = [{ x: "a" }];
const r = [1, 2].flatMap<J>((n) => (n > 1 ? js : [{ x: n }]));
console.log(r);
