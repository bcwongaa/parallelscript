interface J { x: number | string }
class C { constructor(public x: number) {} }
interface W { c: J }
const cobj = new C(1);
const r = [1].flatMap<W>(() => [{ c: cobj }]);
cobj.x = 5;
console.log(r.length, r[0].c.x);
