interface Named { name: string; size: number | string }
const r = [1, 2].flatMap<Named>((n) => [{ name: "n" + n, size: n }]);
console.log(r);
const r2 = [1, 2].flatMap<number[] | string>((n) => [[n, n], "s"]);
console.log(r2);
const r3 = [1, 2].flatMap<(number | string)[]>((n) => [[n, n]]);
console.log(r3);
