const xs: i32[] = [1 as i32, 2 as i32];
const r = [1].flatMap<number>(() => xs);
console.log(r);
const r2 = [1].flatMap<i32 | string>(() => [xs[0], "a"]);
console.log(r2);
const r3 = [1].flatMap<number[]>(() => [xs]);
console.log(r3);
const r4 = [1].flatMap<(number | string)[]>((n) => [xs.slice(), [n]]);
console.log(r4);
