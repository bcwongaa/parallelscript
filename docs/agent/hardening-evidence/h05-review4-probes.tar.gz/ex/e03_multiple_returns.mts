interface Shape { name: string; area(): number }
class Circle implements Shape { name = "circle"; constructor(public r: number) {} area() { return 3 * this.r * this.r; } }
class Rect implements Shape { name = "rect"; constructor(public w: number, public h: number) {} area() { return this.w * this.h; } }
const c = new Circle(1);
const rects = [new Rect(1, 2), new Rect(3, 4)];
const r = [0, 1, 2, 3].flatMap<Shape>((i) => {
  if (i === 0) return [c];
  if (i === 1) return rects;
  switch (i) {
    case 2: return c;
    default:
      for (const q of rects) { if (q.w > 2) return [q, c]; }
      return [];
  }
});
console.log(r.map((s) => s.name).join(","), r[0] === c, r[1] === rects[0]);
