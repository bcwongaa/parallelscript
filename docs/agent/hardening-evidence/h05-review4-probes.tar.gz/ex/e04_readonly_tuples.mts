interface P { x: number }
class Pt implements P { constructor(public x: number) {} }
const p = new Pt(1);
const ro: readonly Pt[] = [p, new Pt(2)];
const r = [1].flatMap<P>(() => ro);
console.log(r.length, r[0] === p);
const tup: [Pt, Pt] = [p, p];
const r2 = [1].flatMap<P>(() => tup);
console.log(r2.length, r2[1] === p);
const r3 = [1, 2].flatMap((n): [number, string] => [n, "s" + n]);
console.log(r3);
const pairs: [number, string][] = [[1, "a"]];
const r4 = [1].flatMap(() => pairs);
console.log(r4, r4[0] === pairs[0]);
