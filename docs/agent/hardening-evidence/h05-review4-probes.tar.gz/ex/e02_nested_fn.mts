interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1, 2].flatMap((n) => {
  function inner(): C[] { return [c]; }
  const g = () => [c];
  const k = function () { return [c, c]; };
  return [n, inner().length, g().length, k().length];
});
console.log(r);
const js: J[] = [{ x: "a" }];
const r2 = [1].flatMap<J>((n) => {
  const pick = (): C[] => [c];
  console.log(pick().length);
  return js;
});
console.log(r2);
