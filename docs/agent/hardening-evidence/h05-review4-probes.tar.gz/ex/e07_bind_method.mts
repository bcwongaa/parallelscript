interface J { x: number }
class C { constructor(public x: number) {} }
class Maker { base = 10; make(n: number): C[] { return [new C(n + this.base)]; } }
const m = new Maker();
const r = [1, 2].flatMap<J>(m.make.bind(m));
console.log(r.map((j) => j.x));
const r2 = [1, 2].flatMap<J>((n) => m.make(n));
console.log(r2.map((j) => j.x));
