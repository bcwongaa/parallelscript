interface Shape { area(): number }
class Sq implements Shape { constructor(public s: number) {} area() { return this.s * this.s; } }
class Bag<T extends Shape> {
  constructor(public groups: T[][]) {}
  all(): T[] { return this.groups.flatMap((g) => g); }
  shapes(): Shape[] { return this.groups.flatMap<Shape>((g) => g); }
  pairs(): T[] { return this.groups.flatMap((g) => { const out: T[] = []; for (const x of g) { out.push(x); } return out; }); }
  firsts(): Shape[] { return this.groups.flatMap<Shape>((g) => (g.length > 0 ? [g[0]] : [])); }
}
const a = new Sq(2);
const bag = new Bag([[a, new Sq(3)], []]);
console.log(bag.all().map((s) => s.area()), bag.shapes()[0] === a, bag.pairs().length, bag.firsts()[0] === a);
