interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B { note = "n"; constructor(public name: string) {} }
const a = new A("a");
const b = new B("b");
const r = [1].flatMap<Opt>(() => [a, b]);
a.name = "A2";
console.log(r.map((o) => o.name + ":" + (o.note ?? "-")).join(" "));
