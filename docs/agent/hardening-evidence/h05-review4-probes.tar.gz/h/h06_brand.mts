type USD = number & { readonly __brand: "usd" };
const usd = (n: number) => n as USD;
const prices: USD[][] = [[usd(1), usd(2)], [usd(3)]];
const r = prices.flatMap((p) => [p[0], ...p]);
console.log(r);
const r2 = [1].flatMap<number>(() => [usd(5)]);
console.log(r2);
