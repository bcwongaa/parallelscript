interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [0, 1].flatMap<J>((i) => {
  for (let n = 0; n < 2; n++) {
    while (n > 5) { return []; }
    do { if (i > 0) return [c]; } while (false);
  }
  return [];
});
console.log(r.length);
