interface J { x: number | string }
class C { constructor(public x: number) {} }
class K { constructor(public x: number | string) {} }
const c = new C(1);
const k = new K(2);
const ks = [k, new K("z")];
const r = [0, 1, 2, 3, 4].flatMap<J>((i) => {
  if (i === 0) return [k];
  try {
    if (i === 1) return ks;
  } finally {
    void 0;
  }
  outer: for (const q of ks) {
    switch (i) {
      case 2:
        return q;
      case 3:
        if (q.x === 2) continue outer;
        return [q, k];
    }
  }
  const helper = () => [c];
  function inner(): C[] { return [c]; }
  return helper().length + inner().length > 1 ? [] : [k];
});
k.x = 9;
console.log(r.map((j) => j.x).join(","), r[0] === k);
