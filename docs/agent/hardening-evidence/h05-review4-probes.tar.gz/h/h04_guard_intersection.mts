interface Tagged { tag: string }
class C { tag = "c"; constructor(public x: number) {} }
function isTagged(v: unknown): v is Tagged { return typeof v === "object" && v !== null && "tag" in v; }
const items: (C | number)[] = [new C(1), 2];
const r = items.flatMap<C | number>((v) => (isTagged(v) ? [v] : []));
console.log(r.length);
const r2 = items.flatMap<unknown>((v) => (isTagged(v) ? [v, 1] : [0]));
console.log(r2.length);
