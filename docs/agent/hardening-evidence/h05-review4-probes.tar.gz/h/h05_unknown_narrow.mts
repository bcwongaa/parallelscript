const xs: unknown[] = [1, "a", [2, 3], { k: 1 }, null];
const r = xs.flatMap<unknown>((x) => {
  if (Array.isArray(x)) return [x];
  if (typeof x === "object" && x !== null) return [x];
  if (x instanceof Date) return [x];
  if (typeof x === "string") return x;
  return [];
});
console.log(r.length);
