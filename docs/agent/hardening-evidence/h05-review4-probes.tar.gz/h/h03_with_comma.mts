interface J { x: number | string }
class K { constructor(public x: number | string) {} }
const k = new K(1);
const log: string[] = [];
const r = [1, 2].flatMap<J>((n) => (log.push("n" + n), [k]));
const r2 = [1, 2].flatMap<J>((n) => [k] as J[]);
const r3 = [1, 2].flatMap<J>((n) => [k]!);
console.log(r.length, r2.length, r3.length, log.join(""));
