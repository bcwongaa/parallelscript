N2_annotated_map.pts:2:33 - error PTS1001: using a `{name: string; size: number}` as a `{name: string; size: number | string}`, whose `size` it doesn't provide with the same types, is not supported yet
exit=1
