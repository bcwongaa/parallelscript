N1b_listeners_ice.pts:8 - error PTS9001: internal compiler error while emitting C: cgen: adapter doesn't capture adapted
  This is a bug in pts, not in the program. Please report it with the program; PTS_DEBUG=1 adds the details a report needs.
exit=3
