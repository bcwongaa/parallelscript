N3_extra_diagnostic.pts:2:49 - error PTS1001: converting number[] to {length: number} is not supported yet
N3_extra_diagnostic.pts:2:50 - error PTS1001: converting number to {length: number} is not supported yet
exit=1
