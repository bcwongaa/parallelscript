N2c_slice.pts:3:26 - error PTS1001: using a `{name: string; size: number}` as a `{name: string; size: number | string}`, whose `size` it doesn't provide with the same types, is not supported yet
exit=1
