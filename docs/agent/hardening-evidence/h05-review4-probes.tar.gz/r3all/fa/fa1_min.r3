fa1_min.pts:1:53 - error PTS1001: using a (number) => number as a () => number, which passes fewer arguments, is not supported yet
exit=1
