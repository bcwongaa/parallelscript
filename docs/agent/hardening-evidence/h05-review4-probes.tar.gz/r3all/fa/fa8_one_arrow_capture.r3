fa8_one_arrow_capture.pts:1:54 - error PTS1001: using a (number) => number as a () => number, which passes fewer arguments, is not supported yet
exit=1
