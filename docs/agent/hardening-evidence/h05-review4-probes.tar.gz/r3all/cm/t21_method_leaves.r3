sq42 ci35 true
4 true
g true
exit=0
