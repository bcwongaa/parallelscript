4 d,b,d,b
exit=0
