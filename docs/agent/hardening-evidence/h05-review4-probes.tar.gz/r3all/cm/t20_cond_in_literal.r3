t20_cond_in_literal.pts:5:39 - error PTS1001: converting {name: string} to Bird | Dog is not supported yet
exit=1
