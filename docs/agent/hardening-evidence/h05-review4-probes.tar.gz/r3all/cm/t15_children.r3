[ 1, 2 ] [ 3 ] true
exit=0
