9000 9000 2000 true
[
  'ab',      'a',
  'b',       'b',
  undefined, 'b',
  'a',       'a',
  undefined
]
9000 3000
exit=0
