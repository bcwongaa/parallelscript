Uncaught RangeError: Array index 1 is out of range (length 3); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
    at /tmp/h05r4.Dwwf/r3all/mg/g5_forof_flat_exec.pts:4
exit=1
