l1_satisfies.pts:2:41 - error PTS1001: using a `object1` as a `{name: string; size: number}`, whose `size` it doesn't provide with the same types, is not supported yet
l1_satisfies.pts:2:41 - error PTS1001: using a `{name: string; size: number}` as a `{name: string; size: number | string}`, whose `size` it doesn't provide with the same types, is not supported yet
exit=1
