[ { name: 'small', size: 1 }, { name: 'big', size: 'L' } ]
exit=0
