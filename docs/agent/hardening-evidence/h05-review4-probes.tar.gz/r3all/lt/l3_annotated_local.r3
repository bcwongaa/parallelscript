[
  { name: 'n1', size: 1 },
  { name: 'n2', size: 2 },
  { name: 'n2', size: 2 }
] true
exit=0
