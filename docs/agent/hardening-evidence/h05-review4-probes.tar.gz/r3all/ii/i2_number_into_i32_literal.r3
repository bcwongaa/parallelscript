i2_number_into_i32_literal.pts:2:35 - error PTS2001: a number doesn't convert to i32 implicitly because the value could change; write `as i32` to convert it
exit=1
