Uncaught TypeError: Expected i64, got number
    at Array.flatMap (/tmp/h05r4.Dwwf/r3all/ii/i1_number_into_i64.pts:2)
    at /tmp/h05r4.Dwwf/r3all/ii/i1_number_into_i64.pts:2
exit=1
