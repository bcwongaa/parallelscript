3 true
true [ 1, 2 ] [ 'a' ]
exit=0
