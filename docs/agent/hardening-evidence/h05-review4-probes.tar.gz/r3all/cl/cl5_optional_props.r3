cl5_optional_props.pts:6:23 - error PTS1001: the `===` operator on {x: number; y?: string | undefined} and C is not supported yet
exit=1
