cl20_interface_method.pts:8:35 - error PTS1001: conditional expression with operands of types {name: string; area(): number}[] and Ci[] is not supported yet
exit=1
