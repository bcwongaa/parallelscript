cl3_cond_element.pts:5:42 - error PTS1001: converting Animal to Bird | Dog is not supported yet
exit=1
