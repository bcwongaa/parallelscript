[ 1, 'a', 2 ]
exit=0
