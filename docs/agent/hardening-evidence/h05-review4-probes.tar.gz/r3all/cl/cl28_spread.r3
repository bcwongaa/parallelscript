3 true true
exit=0
