[ 'pen', 1.5, 'office', 'cheap', 'desk', null ]
[ 'pen:office', 'pen:cheap' ]
[ 'pen', 1.5, 'desk', null ] [ 'pen', 1.5, 'desk', null ]
exit=0
