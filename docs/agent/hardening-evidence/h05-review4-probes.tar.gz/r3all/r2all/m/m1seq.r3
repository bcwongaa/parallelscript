Uncaught RangeError: Array index 2 is out of range (length 12000); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
    at /tmp/h05r4.Dwwf/r3all/r2all/m/m1seq.pts:6
exit=1
