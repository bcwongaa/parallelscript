6 1 [ 'b', undefined, 'b' ]
exit=0
