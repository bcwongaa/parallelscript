Uncaught TypeError: Expected Point[], got Point
    at pts:parallel:166
    at ParallelArray.flatMap (pts:parallel:162)
    at /tmp/h05r4.Dwwf/r3all/r2all/par/p1.pts:5
exit=1
