[ 'ab', 'a', 'b', 'b', undefined, 'b' ]
exit=0
