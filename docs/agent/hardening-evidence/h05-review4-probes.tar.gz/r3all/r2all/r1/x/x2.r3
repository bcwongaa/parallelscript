Uncaught TypeError: Expected string, got undefined (group 1 of the match took no part in it)
    at Array.flatMap (/tmp/h05r4.Dwwf/r3all/r2all/r1/x/x2.pts:2)
    at /tmp/h05r4.Dwwf/r3all/r2all/r1/x/x2.pts:2
exit=1
