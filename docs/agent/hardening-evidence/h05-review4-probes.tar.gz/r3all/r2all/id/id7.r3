id7.pts:5:33 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
id7.pts:10:34 - error PTS1001: using a `{x: number}` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
exit=1
