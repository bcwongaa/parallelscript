id8.pts:4:34 - error PTS1001: using a `{x: number}` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
exit=1
