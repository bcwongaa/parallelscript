== fair market: 5 currencies, 9 quotes
converged after 2 rounds
  1 USD -> 0.8800 CHF
  1 USD -> 0.9200 EUR
  1 USD -> 0.7912 GBP
  1 USD -> 149.5000 JPY
  1 USD -> 1.0000 USD
== skewed market: 5 currencies, 10 quotes
NegativeCycleError: negative cycle detected
  cycle: EUR -> GBP -> JPY -> CHF -> EUR
  profit per unit: 13.241%
Map(5) { 's' => 0, 'a' => 3, 'b' => 5, 'c' => 0, 'd' => 2 }
predecessors: { a: 'b', b: 's', c: 'a', d: 'c' }
exit=0
