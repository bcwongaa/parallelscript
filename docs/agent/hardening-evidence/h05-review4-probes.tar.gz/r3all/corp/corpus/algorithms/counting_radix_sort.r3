counting sort: 11223333445556788999
3: #### (4)
5: ### (3)
9: ### (3)
1: ## (2)
2: ## (2)
4: ## (2)
8: ## (2)
6: # (1)
7: # (1)
pass 1: 170 90 802 2 24 1234 45 75 5 66 999
pass 2: 802 2 5 24 1234 45 66 170 75 90 999
pass 3: 2 5 24 45 66 75 90 170 1234 802 999
pass 4: 2 5 24 45 66 75 90 170 802 999 1234
radix base 10: [
    2,   5,   24,  45,
   66,  75,   90, 170,
  802, 999, 1234
]
radix base 2 needed 11 passes; result ok: true
radix base 16: 3 passes
string radix: [
  'a',      'app',
  'apple',  'ban',
  'banana', 'band',
  'can',    'candy',
  'cherry'
]
matches builtin: true
buckets: [
  [ 0.01 ],
  [ 0.23, 0.25, 0.32 ],
  [ 0.42, 0.47, 0.51, 0.52 ],
  [ 0.7 ],
  [ 0.99 ]
]
flattened: 0.01 0.23 0.25 0.32 0.42 0.47 0.51 0.52 0.70 0.99
bucket sizes: [ 1, 3, 4, 1, 1 ]
exit=0
