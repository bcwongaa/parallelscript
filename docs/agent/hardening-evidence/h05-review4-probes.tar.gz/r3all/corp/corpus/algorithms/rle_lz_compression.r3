rle 67 -> 16: "12WB12W3B24WB14W" ok=true
rle 3 -> 3: "abc" ok=true
rle 11 -> 7: "2ab5c3a" ok=true
rle 0 -> 0: "" ok=true
rle 30 -> 3: "30z" ok=true
lz77 "abracadabra abracadabra"
  7 tokens, ok=true: a b r <3,1>c <5,1>d <7,4>  <12,10>a
lz77 "to be or not to be, that is the question"
  21 tokens, ok=true: t o   b e <3,1>o r <6,1>n <9,1>t <10,1>t <13,4>, <7,2>h a <12,2>i s <8,3>e <29,1>q u <30,1>s <25,1>i <32,1>n
lz77 "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab"
  4 tokens, ok=true: a <1,15>a <17,15>a <32,7>b
lz77 "she sells sea shells by the sea shore"
  16 tokens, ok=true: s h e   <4,1>e l <1,1>s <6,3>a <10,2>h <11,5>b y <20,1>t <24,5>a <18,3>o r e
[
  { offset: 0, length: 0, next: 'a' },
  { offset: 0, length: 0, next: 'b' },
  { offset: 0, length: 0, next: 'c' },
  { offset: 3, length: 9, next: 'x' }
]
┌─────────┬─────┬────┬─────┐
│ (index) │ len │ lz │ rle │
├─────────┼─────┼────┼─────┤
│ 0       │ 23  │ 15 │ 23  │
│ 1       │ 40  │ 45 │ 40  │
│ 2       │ 41  │ 10 │ 4   │
│ 3       │ 37  │ 32 │ 37  │
└─────────┴─────┴────┴─────┘
window 4 -> 30 tokens
window 8 -> 26 tokens
window 16 -> 22 tokens
window 64 -> 21 tokens
deltas: [
  100, 0, 0,   1, 1, 1,
    0, 0, 0, -13, 0, 1,
    1, 1, 1
]
delta runs: [
  [ 100, 1 ],
  [ 0, 2 ],
  [ 1, 3 ],
  [ 0, 3 ],
  [ -13, 1 ],
  [ 0, 1 ],
  [ 1, 4 ]
]
rebuilt matches: true
exit=0
