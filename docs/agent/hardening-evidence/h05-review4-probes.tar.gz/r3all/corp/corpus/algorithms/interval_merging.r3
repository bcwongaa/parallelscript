merged: [ [ 1, 6 ], [ 8, 10 ], [ 15, 20 ] ]
insert [4,8]: [ [ 1, 10 ], [ 15, 20 ] ]
insert [21,22]: [ [ 1, 6 ], [ 8, 10 ], [ 15, 20 ], [ 21, 22 ] ]
intersect: [ [ 1, 2 ], [ 8, 10 ], [ 15, 23 ] ]
everyone busy (merged): 08:00-11:00, 11:30-15:30, 16:00-18:00
free slots >= 15 min: [ '11:00-11:30', '15:30-16:00' ]
free slots >= 30 min: [ '11:00-11:30', '15:30-16:00' ]
free slots >= 60 min: []
rooms needed if all meet separately: 2 (first peak at 09:00)
busy minutes: { alice: 210, bob: 210, carol: 270 }
alice & bob both busy: [ '09:30-10:30', '12:30-13:00' ] [ [ 570, 630 ], [ 750, 780 ] ]
exit=0
