failure(ABABCABAB): [
  0, 0, 1, 2, 0,
  1, 2, 3, 4
]
failure(aaaa): [ 0, 1, 2, 3 ] z(aabxaab): [
  7, 1, 0, 0,
  3, 1, 0
]
search "ABABCABAB" in "ABABDABACDABABCABABABABCABAB"
  naive      at [10,19] comparisons=56
  kmp        at [10,19] comparisons=56
  rabin-karp at [10,19] comparisons=27
  z-algorithm [ 10, 19 ] (all agree)
search "aaab" in "aaaaaaaaaaaaaaaaaaab"
  naive      at [16] comparisons=68
  kmp        at [16] comparisons=55
  rabin-karp at [16] comparisons=4
  z-algorithm [ 16 ] (all agree)
search "ain" in "the rain in spain stays mainly in the plain"
  naive      at [5,14,25,40] comparisons=50
  kmp        at [5,14,25,40] comparisons=52
  rabin-karp at [5,14,25,40] comparisons=12
  z-algorithm [ 5, 14, 25, 40 ] (all agree)
search "issi" in "mississippi"
  naive      at [1,4] comparisons=15
  kmp        at [1,4] comparisons=18
  rabin-karp at [1,4] comparisons=8
  z-algorithm [ 1, 4 ] (all agree)
search "abcd" in "abc"
  naive      at [] comparisons=0
  kmp        at [] comparisons=5
  rabin-karp at [] comparisons=0
  z-algorithm [] (all agree)
{
  algorithm: 'rabin-karp',
  positions: [ 0, 7, 12, 19 ],
  comparisons: 16,
  collisions: 0
}
smallest periods: [ [ 'abcabcabc', 3 ], [ 'abab', 2 ], [ 'abcd', 4 ], [ 'aaaa', 1 ] ]
exit=0
