into array: [
   1,   4,  16,  25,  49,
  64, 100, 121, 169, 196
]
summed: 745
elements touched across both runs: 40
Map(7) {
  'was' => 3,
  'the' => 3,
  'best' => 1,
  'times' => 2,
  'worst' => 1,
  'age' => 1,
  'wisdom' => 1
}
as string: was the best times was the worst times was the age wisdom
[ 'A', 'B', 'C', 'A' ] [ 10, 20, 30 ]
{ t1: [ 22, 22 ], h1: [ 40, 43 ], t2: [ 20 ] }
t1=22.0, h1=41.5, t2=20.0
exit=0
