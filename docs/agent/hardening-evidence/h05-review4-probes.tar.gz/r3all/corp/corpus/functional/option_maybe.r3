#1: name=Some("Ana") zip=1100 manager=None managerZip=n/a
#2: name=Some("Ben") zip=- manager=Some("Ana") managerZip=1100
#3: name=Some("Cleo") zip=- manager=None managerZip=n/a
#4: name=Some("Dev") zip=8000 manager=Some("Ben") managerZip=n/a
#5: name=None zip=- manager=None managerZip=n/a
[
  { tag: 'some', value: 42 },
  { tag: 'some', value: -7 },
  { tag: 'none' },
  { tag: 'some', value: 13 },
  { tag: 'some', value: 0 },
  { tag: 'some', value: 8 }
]
Some(42), None, None, Some(13), None, Some(8)
all: None
all valid: Some([1,2,3])
[ 'even 42', 'odd -7', 'nothing', 'odd 13', 'even 0', 'even 8' ]
first available: { tag: 'some', value: 'Cleo' }
None Some("x")
{ port: 3000, debugPort: 9229, shell: '/bin/zsh' }
sum of parseable: 56
exit=0
