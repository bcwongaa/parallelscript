rolls: 2 4 3 3 5 1 2 1 2 4 2 5 next seed: 3149294349
deterministic: true
[ [ 5, 6, 11 ], [ 3, 4, 7 ], [ 2, 3, 5 ], [ 6, 5, 11 ], [ 6, 5, 11 ] ]
flips: HHTTTHHHHHTHHTHTTTHH heads: 12
hand: Qs 2s Jh 8s 4s deck size: 26 unique: 26
P(3d6 >= 15) ~ 0.091 (exact 0.093)
 3 # 96
 6 ######### 888
 9 ####################### 2326
12 ####################### 2342
15 ######### 904
18 # 98
walk: 0,-1,0,1,2,3,4,3,2,1,2,1,2,3,2,1,0,-1,0,-1,-2,-1,-2,-3,-4,-5
max distance: 5 final: -5
exit=0
