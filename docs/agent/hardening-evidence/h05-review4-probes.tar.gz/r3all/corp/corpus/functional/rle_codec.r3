"12WB12W3B24WB14W"       len 67 -> 16 ratio 0.24 roundtrip=true
"abc"                    len  3 ->  3 ratio 1.00 roundtrip=true
"2ab5c3a"                len 11 ->  7 ratio 0.64 roundtrip=true
""                       len  0 ->  0 ratio n/a roundtrip=true
"30z"                    len 30 ->  3 ratio 0.10 roundtrip=true
SyntaxError: dangling count "2" at end of input
SyntaxError: dangling count "12" at end of input
[ [ 20, 4 ], [ 25.3, 3 ], [ 18, 2 ], [ 30.1, 1 ] ]
plateaus: [ '20x4', '25.3x3' ]
click(2) from t=1, scroll(3) from t=3, key(1) from t=6, click(1) from t=7
[[0,3],[1,2],[0,1],[1,4],[0,2]] true
packed: [ 6, 5, 2, 9, 4 ] unpacked: 000110111100
[
  [ 'e', 2 ],
  [ 'k', 2 ],
  [ 'l', 2 ],
  [ 'm', 2 ],
  [ 'o', 2 ],
  [ 'p', 2 ],
  [ 's', 2 ],
  [ 't', 2 ]
]
exit=0
