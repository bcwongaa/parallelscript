nums: (5 3 8 1 9 2 7)
length: 7 sum: 35
reverse: (7 2 9 1 8 3 5)
doubled: (10 6 16 2 18 4 14)
odds: (5 3 1 9 7)
sorted: (1 2 3 5 7 8 9)
nth 3: 1 nth 30: undefined
take 3: (5 3 8)
append: (1 2 3 4)
flatMap: (1 10 2 20 3 30)
zip: [ [ 'a', 5 ], [ 'b', 3 ], [ 'c', 8 ] ]
shared tail: true
base unchanged: (x y z) extended: (w x y z)
{
  kind: 'cons',
  head: 1,
  tail: { kind: 'cons', head: 2, tail: { kind: 'nil' } }
}
{"kind":"cons","head":"a","tail":{"kind":"nil"}}
NIL: { kind: 'nil' } empty sum: 0
big length: 50000 big sum: 1250025000
the=3, cat=1, and=2, hat=1, bat=1
exit=0
