OK   PEN-1 x 10; NB-A5 x 2      total=23.5
FAIL PEN-1 x 10; NB-A5 x two    line 2: bad quantity two
FAIL INK-B x 5                  not enough INK-B: wanted 5, have 3
OK   INK-B x 3; NB-A5 x 7       total=59.72
FAIL GLUE x 1                   not enough GLUE: wanted 1, have 0
OK   PEN-1 x 4                  total=6
FAIL PEN-1                      line 1: expected "SKU x QTY", got "PEN-1"
{ ok: true, value: { lines: [ [Object], [Object] ], total: 14.49 } }
{ ok: true, value: [ 'PEN-1', 'INK-B' ] }
parsed object: {"a":1}
error -> SyntaxError
parsed object: [1,2,3]
parsed string: "str"
{ ok: true, value: [ 1, 2, 3 ] } { ok: false, error: [ 'x', 'y' ] }
exit=0
