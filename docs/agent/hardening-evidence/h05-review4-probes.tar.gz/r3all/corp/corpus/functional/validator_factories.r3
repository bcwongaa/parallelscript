validator_factories.pts:81:10 - error PTS1001: converting (number) => number to {label: string} is not supported yet
validator_factories.pts:86:44 - error PTS1001: calling a {label: string} is not supported yet
exit=1
