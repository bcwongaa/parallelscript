valid sale ids: [ 1, 2, 3, 5, 6, 7 ]
totals: [ [ 1, 65 ], [ 2, 10 ], [ 3, 90 ], [ 5, 57 ], [ 6, 42 ], [ 7, 86 ] ]
revenue: 350.00
{ north: 65, south: 96, east: 132, west: 57 }
line count: 10
┌─────────┬──────┬────────┬──────────┬─────┬──────┬───────┐
│ (index) │ sale │ rep    │ product  │ qty │ unit │ total │
├─────────┼──────┼────────┼──────────┼─────┼──────┼───────┤
│ 0       │ 1    │ 'Ito'  │ 'widget' │ 10  │ 2.5  │ 25    │
│ 1       │ 1    │ 'Ito'  │ 'gadget' │ 1   │ 40   │ 40    │
│ 2       │ 2    │ 'Ruiz' │ 'widget' │ 4   │ 2.5  │ 10    │
│ 3       │ 3    │ 'Chen' │ 'gizmo'  │ 3   │ 15   │ 45    │
└─────────┴──────┴────────┴──────────┴─────┴──────┴───────┘
by quantity: [
  [ 'widget', 42 ],
  [ 'doohickey', 19 ],
  [ 'gizmo', 4 ],
  [ 'gadget', 2 ]
]
[
  { rep: 'Chen', sales: 2, revenue: 132, avg: 66 },
  { rep: 'Ruiz', sales: 2, revenue: 96, avg: 48 },
  { rep: 'Ito', sales: 1, revenue: 65, avg: 65 },
  { rep: 'Okafor', sales: 1, revenue: 57, avg: 57 }
]
every sale has a rep: true
some sale refunded: true
every valid sale > $10: false
first big sale: 3
index of first east sale: 2
last widget sale: 7
M1: 2 sales, 75.00
M2: 1 sales, 90.00
M3: 3 sales, 185.00
cumulative: [ 75, 165, 350 ]
[
  [ 'doohickey', 0, 0, 19 ],
  [ 'gadget', 1, 0, 1 ],
  [ 'gizmo', 0, 3, 1 ],
  [ 'widget', 14, 20, 8 ]
]
{ north: [ 1 ], south: [ 7, 2 ], east: [ 3, 6 ], west: [ 5 ] }
includes gizmo: true reversed: widget|gizmo|gadget|doohickey
exit=0
