[ 'abc', 'acb', 'bac', 'bca', 'cab', 'cba' ]
perms of 5: 120
123 124 125 134 135 145 234 235 245 345
C(10,4) = 210
[
  [],
  [ 'x' ],
  [ 'y' ],
  [ 'x', 'y' ],
  [ 'z' ],
  [ 'x', 'z' ],
  [ 'y', 'z' ],
  [ 'x', 'y', 'z' ]
]
partitions of 6: [
  '6',           '5+1',
  '4+2',         '4+1+1',
  '3+3',         '3+2+1',
  '3+1+1+1',     '2+2+2',
  '2+2+1+1',     '2+1+1+1+1',
  '1+1+1+1+1+1'
]
p(15) = 176
[ 'S-red', 'S-blue', 'M-red', 'M-blue', 'L-red', 'L-blue' ]
subsets totalling 25: [ 'mug+pin+tee', 'pen+cap+bag', 'pen+mug+cap+pin', 'tee+bag' ]
4-queens: 2 solutions
5-queens: 10 solutions
6-queens: 4 solutions
8-queens: 92 solutions
.Q....
...Q..
.....Q
Q.....
..Q...
....Q.
[ '((()))', '(()())', '(())()', '()(())', '()()()' ] catalan(1..8): [
   1,   2,   5,   14,
  42, 132, 429, 1430
]
000 001 011 010 110 111 101 100
exit=0
