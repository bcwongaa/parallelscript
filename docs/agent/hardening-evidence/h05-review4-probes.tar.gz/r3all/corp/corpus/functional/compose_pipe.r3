"the quick brown fox jumps over the lazy dog the end"
Map(9) {
  'the' => 3,
  'quick' => 1,
  'brown' => 1,
  'fox' => 1,
  'jumps' => 1,
  'over' => 1,
  'lazy' => 1,
  'dog' => 1,
  'end' => 1
}
top: [ [ 'the', 3 ], [ 'brown', 1 ], [ 'dog', 1 ] ]
incThenSq(4) = 25 sqThenInc(4) = 17
composeAll(half, sq, inc)(5) = 18
sumOfEvenSquares(1) = 0
sumOfEvenSquares(5) = 20
sumOfEvenSquares(10) = 220
sumOfEvenSquares(20) = 1540
 - Mara (34)
 - Lena (27)
 - Otto (52)
{ admin: [ 'mara' ], ops: [ 'mara', 'lena' ], dev: [ 'ivan', 'lena' ] }
identity(7) = 7 function
exit=0
