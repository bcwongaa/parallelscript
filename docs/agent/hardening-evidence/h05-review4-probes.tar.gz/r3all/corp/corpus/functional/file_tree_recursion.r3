total: 702.6 KB files: 14 depth: 4
project/ [146.9 KB]
├── README.md (2.3 KB)
├── package.json (820 B)
├── src/ [17.7 KB]
│   ├── index.ts (5.2 KB)
│   ├── util.ts (1.9 KB)
│   └── components/ [10.6 KB]
│       ├── Button.tsx (3.0 KB)
│       └── Modal.tsx (7.6 KB)
└── test/ [126.1 KB]
    ├── index.test.ts (4.0 KB)
    └── fixtures.json (122.1 KB)
original still has 6 children; cleaned has 4
[
  'project/src/index.ts',
  'project/src/util.ts',
  'project/src/components/Button.tsx',
  'project/src/components/Modal.tsx',
  'project/test/index.test.ts'
]
[
  'project/test/fixtures.json',
  'project/node_modules/lodash/lodash.js'
]
[ 'project/test/index.test.ts', 'project/test/fixtures.json' ]
paths: 14 biggest: [ 'project/node_modules/lodash/lodash.js', 544000 ]
.js=531.8 KB, .json=123.3 KB, (none)=23.5 KB, .ts=11.0 KB, .tsx=10.6 KB, .md=2.3 KB
empty dirs: [ 'project/src/components/icons' ]
exit=0
