add10(5) = 15
double(21) = 42
minusFrom100(42) = 58
subtract5(42) = 37
APL-01   member=   7.35 regular=   8.17
BRD-22   member=   6.84 regular=   7.60
CHS-07   member=   7.83 regular=   8.70
MLK-12   member=   8.50 regular=   9.44
member total: 30.52
regular total: 33.91
[WARN] db: slow query (code 17)
[WARN] net: retrying (code 3)
[
  'Hello, Ada!',
  'Hello, Linus!',
  'Hola, Ada!',
  'Hola, Linus!',
  'Bonjour, Ada!',
  'Bonjour, Linus!'
]
CHS-07 > BRD-22 > MLK-12 > APL-01
[
  { sku: 'APL-01', price: 1.25, qty: 6 },
  { sku: 'BRD-22', price: 3.49, qty: 2 },
  { sku: 'CHS-07', price: 7.99, qty: 1 },
  { sku: 'MLK-12', price: 2.89, qty: 3 }
]
arities: [ 1, 1, 1, 1, 0 ]
exit=0
