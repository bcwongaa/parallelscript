Map(2) {
  'A' => {
    id: 'A',
    owner: 'Ines',
    balance: 462.5,
    status: 'open',
    version: 4,
    lastActivity: '2024-02-01'
  },
  'B' => {
    id: 'B',
    owner: 'Tomas',
    balance: 0,
    status: 'closed',
    version: 6,
    lastActivity: '2024-01-17'
  }
}
[
  '2024-01-12 Withdrew(B): cannot withdraw from frozen account',
  '2024-01-18 Deposited(C): account C does not exist',
  '2024-01-20 Withdrew(A): insufficient funds: 420 < 1000'
]
after 3 events (2024-01-05): A:500/open B:0/open
after 6 events (2024-01-11): A:420/open B:120/frozen
after 10 events (2024-01-17): A:420/open B:0/closed
volume by month: { '2024-01': 1845, '2024-02': 42.5 }
Map(6) {
  'Opened' => 2,
  'Deposited' => 4,
  'Withdrew' => 4,
  'Frozen' => 1,
  'Unfrozen' => 1,
  'Closed' => 1
}
freeze reasons: [ 'B: suspicious login' ]
snapshot + tail == full replay: true versions: [ 4, 6 ]
{"A":{"id":"A","owner":"Ines","balance":462.5,"status":"open","version":4,"lastActivity":"2024-02-01"},"B":{"id":"B","owner":"Tomas","balance":0,"status":"closed","version":6,"lastActivity":"2024-01-17"}}
exit=0
