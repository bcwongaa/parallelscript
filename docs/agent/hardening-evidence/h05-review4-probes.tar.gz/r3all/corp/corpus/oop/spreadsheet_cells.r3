   |        A        B        C        D
  1|     Item      Qty    Price    Total
  2|     pens       12     1.25       15
  3|    paper        3     4.50    13.50
  4|      ink        2    19.99    39.98
  5|      sum       17     8.58    68.48
  6| penspape       12    19.99     #ERR
dependents of B2: [ 'B5', 'B6', 'D2' ] of D3: [ 'B6', 'D5' ]
after B2=20: 25 78.48 25
cycle: #CYCLE
cycle through B7 -> C7 -> A7 -> B7 true
[ 'A1', 'A2', 'A3', 'B1', 'B2', 'B3' ] [ 'C9' ]
evaluations: 115
exit=0
