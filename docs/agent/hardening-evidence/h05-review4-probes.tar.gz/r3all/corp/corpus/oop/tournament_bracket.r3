Uncaught TypeError: Expected Team, got null
    at /tmp/h05r4.Dwwf/r3all/corp/corpus/oop/tournament_bracket.pts:75
    at Array.map (/tmp/h05r4.Dwwf/r3all/corp/corpus/oop/tournament_bracket.pts:75)
    at Bracket.run (/tmp/h05r4.Dwwf/r3all/corp/corpus/oop/tournament_bracket.pts:75)
    at /tmp/h05r4.Dwwf/r3all/corp/corpus/oop/tournament_bracket.pts:102
exit=1
