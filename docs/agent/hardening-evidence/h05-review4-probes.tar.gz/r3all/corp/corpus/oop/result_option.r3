ok   Ada <ada@example.com> 36
err  line 2: age "2x" is not an integer
err  line 3: name empty
err  line 4: age 200 out of range
err  line 5: email bad email dee.example.com
ok   Eve <eve@q.net> 29
[ 'Ada', 'Eve' ]
age|name|age|email
Ada Some("London") Some(6) London
Bob None None unknown
Eve Some("Paris") Some(5) Paris
Some(84) None true
Result {
  ok: true,
  value: { name: 'Ada', age: 36, email: 'ada@example.com' },
  error: undefined
}
Some { value: { a: [ 1, 2 ] } }
exit=0
