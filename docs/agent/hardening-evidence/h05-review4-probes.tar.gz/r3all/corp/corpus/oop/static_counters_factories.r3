instances after static block: 2
25°C | 100°C | 0°C | 26.85°C | -40°C | 100°C | NaN°C
instances: 6 cache hit: true
RangeError: below absolute zero: -278.15
CIR-001 circle r=1.00    area=3.142
REC-001 rect 2x3         area=6.000
REC-002 rect 4x4         area=16.000
CIR-002 circle r=3.00    area=28.274
REC-003 rect 5x5         area=25.000
circle=2, rect=3
ORD-001 ORD-002 INV-001
{ CIR: 2, REC: 3, ORD: 2, INV: 1 }
Rect { serial: 'REC-001', w: 2, h: 3 } [ Temperature { celsius: 0 }, Temperature { celsius: 100 } ]
exit=0
