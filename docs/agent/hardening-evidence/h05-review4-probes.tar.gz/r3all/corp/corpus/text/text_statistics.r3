Paragraph 1: 3 sentences, ease 39.3, grade 10.5
  [.]  9w 20syl  Garbage collection is a form of automatic memor...
  [.] 17w 30syl  The collector attempts to reclaim memory which ...
  [!]  7w 11syl  It was invented by John McCarthy around 1959!
Paragraph 2: 4 sentences, ease -1.8, grade 15.3
  [.]  6w 15syl  Concurrent collectors run alongside the applica...
  [.] 12w 30syl  They must coordinate carefully with mutator thr...
  [Q]  6w 10syl  Is the extra complexity worth it?
  [.]  5w 14syl  For latency-sensitive services, usually yes.
Paragraph 3: 3 sentences, ease 68.9, grade 5.3
  [.]  3w  5syl  Short pauses matter.
  [.]  3w  5syl  Throughput matters too.
  [.] 14w 21syl  Engineers must balance both, and the right answ...
sentence length: mean=8.20 sd=4.49 min=3 max=17
[
  { w: 'latency-sensitive', syl: 6 },
  { w: 'considerably', syl: 5 },
  { w: 'implementation', syl: 5 },
  { w: 'allocated', syl: 4 },
  { w: 'application', syl: 4 },
  { w: 'automatic', syl: 4 },
  { w: 'carefully', syl: 4 },
  { w: 'complexity', syl: 4 }
]
possible passive voice: [
  'The collector attempts to reclaim memory which was allocated by the program but is no longer referenced.',
  'It was invented by John McCarthy around 1959!',
  'Engineers must balance both, and the right answer depends on the workload being measured.'
]
the=1 table=2 created=2 beautiful=3 rhythm=1 queue=1 readability=5 a=1
{
  index: 3,
  sentences: [
    {
      text: 'Short pauses matter.',
      words: 3,
      syllables: 5,
      longWords: []
    },
    {
      text: 'Throughput matters too.',
      words: 3,
      syllables: 5,
      longWords: []
    },
    {
      text: 'Engineers must balance both, and the right answer depends on the workload being measured.',
      words: 14,
      syllables: 21,
      longWords: [Array]
    }
  ],
  readingEase: 68.9,
  gradeLevel: 5.3
}
exit=0
