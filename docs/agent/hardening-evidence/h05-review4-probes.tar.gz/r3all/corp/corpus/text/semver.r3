0.9.12+build.7 < 1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-alpha.beta < 1.0.0-beta.2 < 1.0.0-beta.11 < 1.0.0-rc.1 < 1.0.0 < 1.2.9 < 1.2.10 < 1.10.0 < 2.1.3
SemVer {
  major: 1,
  minor: 2,
  patch: 3,
  prerelease: [ 'rc', 1 ],
  build: [ 'sha', 'abc' ]
}
^1.2.3                    5 best=1.10.0
~1.2.3                    3 best=1.2.10
>=1.0.0 <2.0.0            6 best=1.10.0
1.x                       6 best=1.10.0
1.2.x                     3 best=1.2.10
*                        11 best=2.1.3
1.0.0 - 1.2.9             3 best=1.2.9
^0.9.0 || ^2.0.0          3 best=2.1.3
>=1.0.0-beta.2 <1.0.0     1 best=1.0.0-beta.11
^0.0.3                    1 best=0.0.3
[
  'major: 2.0.0',
  'minor: 1.5.0',
  'patch: 1.4.2',
  'prerelease: 1.4.2-beta.4'
]
true Invalid version: 1.2
true Invalid version: 01.2.3
true Invalid version: a.b.c
true Invalid version: 1.2.3.4
true Invalid version: 
{"major":3,"minor":0,"patch":0,"prerelease":["rc",2],"build":[]}
exit=0
