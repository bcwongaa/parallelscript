*.md                 1 ["README.md"]
**/*.md              3 ["README.md","docs/SPEC.md","docs/agent/NOTES.md"]
src/**/*.ts          3 ["src/main.ts","src/util/strings.ts","src/util/strings.test.ts"]
src/*/*.{c,h}        2 ["src/gc/heap.c","src/gc/heap.h"]
test/[ab]?.pts       2 ["test/a1.pts","test/b2.pts"]
test/[!a]*.pts       2 ["test/b2.pts","test/c10.pts"]
**/*.test.ts         1 ["src/util/strings.test.ts"]
{src,test}/**        8 ["src/main.ts","src/util/strings.ts","src/util/strings.test.ts","src/gc/heap.c","src/gc/heap.h","test/a1.pts","test/b2.pts","test/c10.pts"]
docs/**/[A-Z]*.md    2 ["docs/SPEC.md","docs/agent/NOTES.md"]
.*                   1 [".gitignore"]
src/util/str?ngs.ts  1 ["src/util/strings.ts"]
**                   14 ["src/main.ts","src/util/strings.ts","src/util/strings.test.ts","src/gc/heap.c","src/gc/heap.h","README.md","docs/SPEC.md","docs/agent/NOTES.md","build/out.o","test/a1.pts","test/b2.pts","test/c10.pts",".gitignore","package.json"]
[ 'abf1', 'abf2', 'acdf1', 'acdf2', 'acef1', 'acef2' ]
6 [ 'no-braces' ]
[
  { p: 'a*b*c', s: 'aXXbYYc', ok: true },
  { p: '*.*', s: 'file', ok: false },
  { p: '[a-c]x', s: 'bx', ok: true },
  { p: '[]]', s: ']', ok: true },
  { p: 'h?llo', s: 'hallo', ok: true },
  { p: '[0-9][0-9]', s: '4a', ok: false }
]
Set(3) { 'build/out.o', '.gitignore', 'package.json' } 11
exit=0
