heading paragraph heading list heading list rule code paragraph
[
  {
    kind: 'list',
    ordered: false,
    items: [
      'strict **type** checking',
      '`Map` and `Set` support',
      'fast startup'
    ]
  },
  {
    kind: 'list',
    ordered: true,
    items: [ 'write code', 'run `pts build`', 'ship it' ]
  }
]
<h1>ParallelScript <em>notes</em></h1>
<p>TypeScript compiled to <strong>native</strong> code, with a <code>GC</code> and real threads. See <a href="https://example.com/pts">the repo</a> for <em>details</em>.</p>
<h2>Features</h2>
<ul>
  <li>strict <strong>type</strong> checking</li>
  <li><code>Map</code> and <code>Set</code> support</li>
  <li>fast startup</li>
</ul>
<h3>Steps</h3>
<ol>
  <li>write code</li>
  <li>run <code>pts build</code></li>
  <li>ship it</li>
</ol>
<hr />
<pre><code class="language-ts">const x: Array&lt;number&gt; = [1, 2];
if (x.length &lt; 3 &amp;&amp; x[0] &gt; 0) console.log("ok");</code></pre>
<p>Unclosed <em>emphasis and 5 &lt; 6 &amp; 7 &gt; 2</em></p>
table of contents:
- ParallelScript notes
  - Features
    - Steps
<strong>bold <em>and italic</em></strong> then <code>a&lt;b</code>
exit=0
