catalog { updated: '2024-03-10' } [ 'book', 'book', 'magazine', 'empty' ]
b1: "Structure & Interpretation" by Abelson & Sussman — USD 54.95
b2: "Le Petit Prince" by Saint-Exupéry — EUR 8.50
[ 'USD:54.95', 'EUR:8.50', 'USD:2.95' ]
Contains <html> & stuff
USD total: 57.90
<magazine id="m1">
  <title>Byte</title>
  <price currency="USD">2.95</price>
</magazine>
<book id="b2" lang="fr">
  <title>Le Petit Prince</title>
  <author>Saint-Exupéry</author>
  <price currency="EUR">8.50</price>
  <note>Contains &lt;html> &amp; stuff</note>
</book>
XmlError: mismatched </a>, open element is <b> (offset 6)
XmlError: unclosed <a> (offset 3)
XmlError: malformed attribute in <a> (offset 0)
XmlError: unknown entity &bogus; (offset 3)
XmlError: unterminated comment (offset 0)
XmlElement { name: 'empty', attrs: Map(0) {}, children: [] }
exit=0
