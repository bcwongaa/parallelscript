map aborted at 2 - sensor attic has no value
[ 71, 39, 54 ]
stop at attic after visiting [ 'kitchen', 'garage', 'attic' ]
[ '0.9.12', '1.2', '1.2.3', '1.2.10', '1.10.0', '2.0.0' ]
true true
array still has 7 items, contains bad: true
record 2: negative amount -1 after accumulating 11
found: error: null at attic
skipping: row 1 is a singleton
[ 10, 20, 40, 50, 60 ]
threw after 3 checks
exit=0
