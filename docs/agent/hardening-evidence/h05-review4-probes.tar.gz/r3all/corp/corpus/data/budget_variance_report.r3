Account                 Jan var       Feb var       Mar var     Q1 var    Q1 %  
Product sales         (1,600) U       6,250 F     (2,100) U      2,550    0.7% 
Services              (1,250) U       3,100 F       1,200 F      3,050    3.2% 
Materials               2,100 U       1,270 U     (1,120) F      2,250    1.7% <-- review
Freight                 (180) F       1,410 U         100 U      1,330    7.2% <-- review
Salaries                    0 F           0 F       1,900 U      1,900    1.1% <-- review
Marketing             (2,200) F       2,650 U       (800) F      (350)   -0.9% 
Rent                        0 F           0 F           0 F          0    0.0% 
Map(3) {
  'Revenue' => { budget: 470000, actual: 475600 },
  'COGS' => { budget: 149750, actual: 153330 },
  'OpEx' => { budget: 230000, actual: 231550 }
}
{
  grossBudget: 320250,
  grossActual: 322270,
  netBudget: 90250,
  netActual: 90720
}
Gross margin: budget 68.14%, actual 67.76%
[ 'Freight/Feb: 23.5%', 'Marketing/Feb: 17.7%', 'Materials/Jan: 5.0%' ]
(1,234) 999 0 (0)
exit=0
