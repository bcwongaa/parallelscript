{
  "server": {
    "host": "0.0.0.0",
    "port": 443,
    "tls": {
      "enabled": true,
      "cert": null
    }
  },
  "log": {
    "level": "debug",
    "outputs": [
      "file",
      "stdout"
    ]
  },
  "features": {
    "search": true,
    "beta": true,
    "newCheckout": true
  },
  "workers": 16
}
{ level: 'warn', outputs: [ 'stdout', 'file', 'stdout' ] }
{ level: 'warn', outputs: [ 'stdout', 'file' ] }
server.port            => 443
server.tls.enabled     => true
log.outputs            => [ 'file', 'stdout' ]
features.newCheckout   => true
nope.x                 => undefined
workers.count          => undefined
server.host="0.0.0.0"
server.port=443
server.tls.enabled=true
server.tls.cert=null
log.level="debug"
log.outputs=["file","stdout"]
features.search=true
features.beta=true
features.newCheckout=true
workers=16
4 8080 base untouched
changed vs defaults: [
  'server.port',
  'server.tls.enabled',
  'log.level',
  'log.outputs',
  'features.beta',
  'features.newCheckout',
  'workers'
]
exit=0
