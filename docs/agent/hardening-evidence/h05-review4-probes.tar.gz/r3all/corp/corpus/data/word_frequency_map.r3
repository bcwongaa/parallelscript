tokens: 56 distinct: 31
Top words:
  battery     7 ▇▇▇▇▇▇▇
  great       5 ▇▇▇▇▇
  screen      4 ▇▇▇▇
  speakers    2 ▇▇
  better      1 ▇
  clear       1 ▇
  cracked     1 ▇
  customer    1 ▇
review 1 keywords: [ [ 'dim', 1.792 ], [ 'life', 1.792 ], [ 'screen', 0.405 ] ]
review 2 keywords: [ [ 'better', 1.792 ], [ 'screen', 0.405 ], [ 'battery', 0.182 ] ]
review 3 keywords: [ [ 'fine', 1.792 ], [ 'terrible', 1.792 ], [ 'speakers', 1.099 ] ]
review 4 keywords: [ [ 'clear', 1.792 ], [ 'day', 1.792 ], [ 'loud', 1.792 ] ]
review 5 keywords: [ [ 'cracked', 1.792 ], [ 'customer', 1.792 ], [ 'support', 1.792 ] ]
review 6 keywords: [ [ 'matters', 1.792 ], [ 'battery', 0.547 ] ]
[
  [ 'the screen', 3 ],
  [ 'is great', 2 ],
  [ 'screen is', 2 ],
  [ 'speakers are', 2 ],
  [ 'battery battery', 2 ]
]
a=28 e=45 i=9 o=6 u=6
21 distinct letters
Map(8) {
  '1' => 2,
  '2' => 6,
  '3' => 14,
  '4' => 6,
  '5' => 8,
  '6' => 6,
  '7' => 10,
  '8' => 4
}
7 undefined true
exit=0
