roots: 1 orphans: [ { id: 10, parentId: 99, name: 'orphan.txt', size: 5 } ]
root/ (297)
├── assets/ (129)
│   ├── icon.svg (9)
│   └── logo.png (120)
└── src/ (168)
    ├── lib/ (108)
    │   ├── format.ts (31)
    │   └── parse.ts (77)
    ├── main.ts (42)
    └── util.ts (18)
depth: 3 total size: 297
 1 <- null root
 3 <- 1    root/assets
11 <- 3    root/assets/icon.svg
 7 <- 3    root/assets/logo.png
 2 <- 1    root/src
 6 <- 2    root/src/lib
 9 <- 6    root/src/lib/format.ts
 8 <- 6    root/src/lib/parse.ts
 4 <- 2    root/src/main.ts
 5 <- 2    root/src/util.ts
round trip ok: true
[ 'lib', 'main.ts', 'util.ts' ]
{"name":"src","children":[{"name":"lib","children":[{"name":"format.ts","children":[],"size":31},{"name":"parse.ts","children":[],"size":77}],"size":0},{"name":"main.ts","children":[],"size":42},{"name":"util.ts","children":[],"size":18}],"size":0}
leaves: [
  'icon.svg',
  'logo.png',
  'format.ts',
  'parse.ts',
  'main.ts',
  'util.ts'
]
TreeNode {
  id: 2,
  name: 'src',
  size: 0,
  children: [
    TreeNode { id: 6, name: 'lib', size: 0, children: [Array] },
    TreeNode { id: 4, name: 'main.ts', size: 42, children: [] },
    TreeNode { id: 5, name: 'util.ts', size: 18, children: [] }
  ]
}
exit=0
