10 changes
- $.env.FEATURE_X (was true)
~ $.env.LOG_LEVEL: "info" -> "debug"
+ $.env.TIMEOUT_MS = 2500
~ $.owners[0].oncall: true -> false
~ $.owners[1].oncall: false -> true
+ $.owners[2] = {"name":"mo","oncall":false}
+ $.paused = null
- $.ports[1] (was 9090)
~ $.replicas: 3 -> 5
~ $.version: "1.4.2" -> "1.5.0"
{ added: 3, removed: 2, changed: 5 }
[
  {
    kind: 'changed',
    path: '$.env.LOG_LEVEL',
    from: 'info',
    to: 'debug'
  },
  {
    kind: 'changed',
    path: '$.owners[0].oncall',
    from: true,
    to: false
  }
]
0 [ { kind: 'changed', path: '$[1][1]', from: 3, to: 4 } ]
[ { kind: 'added', path: '$.a.b.d', value: [ true ] } ]
{"service":"billing","version":"1.5.0","replicas":5,"env":{"LOG_LEVEL":"debug","REGION":"us-east-1","FEATURE_X":true},"ports":[8080,9090],"owners":[{"name":"kai","oncall":true},{"name":"lu","oncall":false}]}
[
  '- $.env.FEATURE_X (was true)',
  '+ $.env.TIMEOUT_MS = 2500',
  '~ $.owners[0].oncall: true -> false',
  '~ $.owners[1].oncall: false -> true',
  '+ $.owners[2] = {"name":"mo","oncall":false}',
  '+ $.paused = null',
  '- $.ports[1] (was 9090)'
]
exit=0
