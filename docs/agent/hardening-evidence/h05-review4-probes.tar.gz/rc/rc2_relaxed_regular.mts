interface Opt { name: string; note?: string }
class A { constructor(public name: string) {} }
class B extends A { note = 5; }
const b = new B("b");
const as: A[] = [new A("a"), b];
const r: Opt[] = as.map((x) => x);
b.name = "b2";
console.log(r.length, r.map((o) => `${o.name}:${typeof o.note}:${o.note}`).join(" "));
