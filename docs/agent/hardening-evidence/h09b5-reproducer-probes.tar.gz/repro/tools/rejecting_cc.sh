#!/bin/sh
# rejecting_cc.sh: a C compiler for PTS_CC that rejects a program's main.c holding an
# AllInstances-only by-name instance lookup (pts_method_instance_find), as clang rejects C it
# can't compile, saves the main.c it compiles to $SAVE_C, and runs clang for everything else.
for arg in "$@"; do
  case "$arg" in
  */main.c)
    if grep -q pts_method_instance_find "$arg"; then
      echo "$arg:1:1: error: rejected by rejecting_cc.sh" >&2
      exit 1
    fi
    [ -n "$SAVE_C" ] && cp "$arg" "$SAVE_C"
    ;;
  esac
done
exec clang "$@"
