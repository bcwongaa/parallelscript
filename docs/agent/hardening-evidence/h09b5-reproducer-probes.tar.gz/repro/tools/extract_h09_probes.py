#!/usr/bin/env python3
"""Extracts the .pts probes of the H09 evidence archives (docs/agent/hardening-evidence/
h09*probes.tar.gz) into OUT/<archive>/..., skipping generated matrix cases (paths with
'matrix' or 'cases' in them, which number in the hundreds), and prints the counts.
  extract_h09_probes.py EVIDENCE_DIR OUT
"""
import os, sys, tarfile

src, out = sys.argv[1], sys.argv[2]
total = 0
for name in sorted(os.listdir(src)):
    if not (name.startswith("h09") and name.endswith("probes.tar.gz")):
        continue
    dest = os.path.join(out, name[: -len(".tar.gz")])
    n = 0
    with tarfile.open(os.path.join(src, name)) as tar:
        for member in tar.getmembers():
            p = member.name
            if not member.isfile() or not p.endswith(".pts") or "matrix" in p or "/cases/" in p or ".." in p or p.startswith("/"):
                continue
            target = os.path.join(dest, p.replace("/", "__"))
            os.makedirs(dest, exist_ok=True)
            with tar.extractfile(member) as f, open(target, "wb") as g:
                g.write(f.read())
            n += 1
    print(name, n)
    total += n
print("total", total)
