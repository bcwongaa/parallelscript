#!/usr/bin/env python3
"""Generates the H09b5 matrix into OUT/<family>/<case>.pts (run_matrix.py runs it):

  m1_fnlimit   C172(a): K generic functions of one function type, each passed to its own
               consumer calling it with D class types of its own (declarations; local arrows)
  m2_classleak C172(a): a value called with N class types beside one that pairs with them and
               makes class instances no call uses (and the control without it)
  m3_limit     C172(b): Box instances made through value calls (i09's) and by plain code
  m4_growth    C172(c): W escaping generic arrows x D demand types (review round 2's
               gen_escape.py); N method values each to its own consumer (s_N)
  m5_variants  C172(d): N calls of a dynamic-result generic value whose type arguments are
               promises of N literal types (q08's), or of N string-literal unions (many_value_keys)
  m6_fallback  C176: an unrelated part that fails in a way no trial takes back (trigger) x a
               generic call that needs one of the three specialization levels (victim)
  m7_ir        C177: typed calls whose type arguments of one IR type give results of other
               checker types (gen_c177.py)
  m8_polyrec   C184: polymorphic recursion through eleven kinds of generic, recursing 3 or 70
               levels at run time
  OUT defaults to /tmp/h09b5/repro/matrix/cases.
"""
import os, subprocess, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/h09b5/repro/matrix/cases"
TOOLS = os.path.dirname(os.path.abspath(__file__))
BOX = "class Box<T> {\n  constructor(public value: T) {}\n}\n"
ATTEMPT = """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""


def write(family, name, text):
    d = os.path.join(OUT, family)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, name + ".pts"), "w") as f:
        f.write(text)


def classes(prefix, n):
    return "".join(f"class {prefix}{i} {{\n  tag = {i};\n}}\n" for i in range(n))


# ---------------------------------------------------------------- m1


def m1(kind, k, d):
    s = (f"// C172(a) {kind}: {k} generic functions of one type, each passed to its own consumer calling\n"
         f"// it with {d} class types of its own: {d} instances each used, {k * d} paired.\n")
    if kind == "decl":
        for j in range(k):
            s += f"function mapOf{j}<T>(x: T): Map<string, T> {{\n  return new Map([[\"k{j}\", x]]);\n}}\n"
    for j in range(k):
        s += classes(f"C{j}_", d)
    for j in range(k):
        s += f"function use{j}(f: <T>(x: T) => Map<string, T>): number {{\n  let s = 0;\n"
        for i in range(d):
            s += (f"  try {{\n    const m{i}: Map<string, C{j}_{i}> = f(new C{j}_{i}());\n    s += m{i}.get(\"k{j}\")!.tag;\n"
                  f"  }} catch (e: any) {{\n    console.log({j}, {i}, e.message);\n  }}\n")
        s += "  return s;\n}\n"
    if kind == "decl":
        s += "console.log(" + ", ".join(f"use{j}(mapOf{j})" for j in range(k)) + ");\n"
    else:
        s += "function main(): void {\n"
        for j in range(k):
            s += f"  const mapOf{j} = <T,>(x: T): Map<string, T> => new Map([[\"k{j}\", x]]);\n"
        s += "  console.log(" + ", ".join(f"use{j}(mapOf{j})" for j in range(k)) + ");\n}\nmain();\n"
    write("m1_fnlimit", f"{kind}_{k}x{d}", s)


# ---------------------------------------------------------------- m2


def m2(n, control):
    s = (f"// C172(a): mkA is called with {n} class types (Box<Ai>, Box<Ai[]>); mkB only with number.\n"
         "// Pairing mkB with mkA's demands makes Box<Ai[][]> instances no call uses"
         + (" (control: no mkB).\n" if control else ".\n"))
    s += BOX + classes("A", n)
    s += "function mkA<T>(x: T): Box<T> {\n  const w = new Box([x]);\n  return new Box(w.value[0]);\n}\n"
    if not control:
        s += "function mkB<T>(x: T): Box<T> {\n  const w = new Box([[x]]);\n  return new Box(w.value[0][0]);\n}\n"
    s += "function useA(f: <T>(x: T) => Box<T>): void {\n"
    for i in range(n):
        s += (f"  try {{\n    const b{i}: Box<A{i}> = f(new A{i}());\n    console.log({i}, b{i}.value.tag);\n"
              f"  }} catch (e: any) {{\n    console.log({i}, e.message);\n  }}\n")
    s += "}\nfunction useB(f: <T>(x: T) => Box<T>): number {\n  const b: Box<number> = f(1);\n  return b.value;\n}\n"
    s += "useA(mkA);\n" + ("console.log(useB(mkA));\n" if control else "console.log(useB(mkB));\n")
    write("m2_classleak", f"leak_{n}" + ("_control" if control else ""), s)


# ---------------------------------------------------------------- m3


def m3_value(n):
    s = f"// C172(b): {n} instances of Box through one value's typed calls (i09's).\n" + BOX
    s += "function make<T>(x: T): Box<T> {\n  return new Box(x);\n}\n" + classes("C", n)
    s += "function demand(f: <T>(x: T) => Box<T>): number {\n  let s = 0;\n"
    for i in range(n):
        s += f"  const b{i}: Box<C{i}> = f(new C{i}());\n  s += b{i}.value.tag;\n"
    s += "  return s;\n}\nconsole.log(demand(make));\n"
    write("m3_limit", f"viavalue_{n}", s)


def m3_plain(n):
    s = f"// C172(b): {n} instances of Box made by plain typed code.\n" + BOX + classes("C", n) + "let s = 0;\n"
    for i in range(n):
        s += f"const b{i}: Box<C{i}> = new Box(new C{i}());\ns += b{i}.value.tag;\n"
    s += "console.log(s);\n"
    write("m3_limit", f"plainboxes_{n}", s)


# ---------------------------------------------------------------- m4


def m4_escape(w, d):
    path = os.path.join(OUT, "m4_growth", f"esc_{w}x{d}.pts")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "gen_escape.py"), str(w), str(d), path], check=True)


def m4_methods(k):
    out = [f"// C172(c): {k} method values, each passed to its own one-type consumer (review round 1's s_N).",
           "class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
    for i in range(k):
        out.append(f"class V{i} {{ constructor(public n: number) {{}} }}")
        out.append(f"function use{i}(f: Factory): number {{ const b: Box<V{i}> = f(new V{i}({i})); return b.value.n; }}")
        out += [f"class M{i} {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
    for i in range(k):
        out.append(f"console.log(use{i}(new M{i}().make));")
    write("m4_growth", f"methods_{k}", "\n".join(out) + "\n")


def m4_decls(k):
    out = [f"// C172(c): {k} generic declarations, each passed to its own one-type consumer (sd_N's control).",
           "class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
    for i in range(k):
        out.append(f"class V{i} {{ constructor(public n: number) {{}} }}")
        out.append(f"function use{i}(f: Factory): number {{ const b: Box<V{i}> = f(new V{i}({i})); return b.value.n; }}")
        out += [f"function make{i}<T>(x: T): Box<T> {{", "  return new Box(x);", "}"]
    for i in range(k):
        out.append(f"console.log(use{i}(make{i}));")
    write("m4_growth", f"decls_{k}", "\n".join(out) + "\n")


# ---------------------------------------------------------------- m5


def m5_literals(n, kind):
    lit = (lambda i: f"{i + 1} as const") if kind == "num" else (lambda i: f'"k{i}" as const')
    show = (lambda: "n + 1") if kind == "num" else (lambda: 'n + "!"')
    typ = "number" if kind == "num" else "string"
    s = (f"// C172(d): {n} calls of a dynamic-result generic value for promises of {n} {typ} literal types\n"
         "// (maxDynamicVariants is 4; q08's).\n") + BOX
    s += "async function unwrap<T>(x: T): Promise<Box<Awaited<T>>> {\n  return new Box(await x);\n}\n"
    s += f"async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {{\n  const show = (label: string, n: {typ}): void => console.log(label, {show()});\n"
    for i in range(n):
        s += f'  try {{ show("{i}", (await f(Promise.resolve({lit(i)}))).value); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n'
    s += "}\nuse(unwrap);\n"
    write("m5_variants", f"literal_{kind}_{n}", s)


def m5_unions(n):
    s = (f"// C172(d): {n} calls for f<Promise<\"kN\"> | number> (the parent's many_value_keys): one instance\n"
         "// shape, IR value, told apart by checker types.\n") + BOX
    s += "async function unwrap<T>(x: T): Promise<Box<Awaited<T>>> {\n  return new Box(await x);\n}\n"
    s += "async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {\n  let s = 0;\n"
    for i in range(n):
        s += (f'  try {{ const v{i}: Promise<"k{i}"> | number = {i}; const b{i} = await f(v{i}); s += Number(b{i}.value); }}'
              f' catch (e: any) {{ console.log("{i} threw", e.message); }}\n')
    s += "  console.log(s);\n}\nuse(unwrap);\n"
    write("m5_variants", f"unions_{n}", s)


# ---------------------------------------------------------------- m6

TRIGGERS = {
    "none": ("", ""),
    "classbody": ("""class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
function useDogs(f: <T>(x: T) => Box<T>): number {
  const b: Box<Dog[]> = f([new Dog()]);
  return b.value.length;
}
function trigger(): void {
  const w = <T,>(x: T): Weird<T> => new Weird(x);
  const d: any = w;
  console.log("trigger", d(1).animals().length, useDogs(<T,>(x: T): Box<T> => new Box(x)));
}
""", "trigger();\n"),
    "relaxed": ("""interface Tagged {
  id: number;
  tag?: string;
}
class Base {
  id = 1;
}
class Derived extends Base {
  tag = 5;
}
function useBase(f: <T extends Base>(x: T) => Box<T>): number {
  return f(new Base()).value.id;
}
function trigger(): void {
  const boxed = <T extends Base>(x: T): Box<T> => {
    const tagged: Tagged = x;
    return new Box(x);
  };
  const d: any = boxed;
  console.log("trigger", d(new Base()).value.id, new Derived().tag);
  if (d.length > 5) {
    console.log(useBase(boxed));
  }
}
""", "trigger();\n"),
    "limitlit": ("""const recLit = {
  rec<T>(x: T, n: number): Box<T> {
    if (n > 0) {
      const inner: Box<T[]> = this.rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  },
};
function trigger(): void {
  console.log("trigger", recLit.rec(5, 3).value + 1);
}
""", "attempt(\"trigger\", () => { trigger(); return \"\"; });\n"),
    "limitarrow": ("""function trigger(): void {
  const rec = <T,>(x: T, n: number): Box<T> => {
    if (n > 0) {
      const inner: Box<T[]> = rec([x], n - 1);
      return new Box(inner.value[0]);
    }
    return new Box(x);
  };
  console.log("trigger", rec(5, 3).value + 1);
}
""", "attempt(\"trigger\", () => { trigger(); return \"\"; });\n"),
}

VICTIMS = {
    "localarrow": ("""function victim(): string {
  const named = <T,>(x: T): Box<T> => new Box(x);
  const b: Box<number> = named(5);
  return String(b.value + 1);
}
""", "needs ValueInstances"),
    "iface": ("""interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function victim(): string {
  const m: Maker = new ClassMaker();
  return String(m.make(5).value + 1);
}
""", "needs AllInstances"),
    "literal": ("""const maker = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
function victim(): string {
  return String(maker.make(5).value + 1);
}
""", "needs AllInstances"),
    "methodvalue": ("""class Maker2 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function useF(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
function victim(): string {
  return useF(new Maker2().make);
}
""", "needs AllInstances"),
    "decl": ("""function make<T>(x: T): Box<T> {
  return new Box(x);
}
function useG(f: <T>(x: T) => Box<T>): string {
  const b: Box<number> = f(5);
  return String(b.value + 1);
}
function victim(): string {
  return useG(make);
}
""", "DeclaredInstances keeps it"),
}


def m6(trigger, victim):
    tdecl, tcall = TRIGGERS[trigger]
    vdecl, need = VICTIMS[victim]
    s = (f"// C176: trigger {trigger} (an unrelated part whose instances fail in a way no trial takes back)\n"
         f"// beside victim {victim} ({need}).\n") + BOX + ATTEMPT + tdecl + vdecl
    s += f'attempt("victim", victim);\n' + tcall
    write("m6_fallback", f"{trigger}__{victim}", s)


# ---------------------------------------------------------------- m8

POLY = {
    "decl": ("function rec<T>(x: T, n: number): Box<T> {\n{body}}\n", "rec", "rec(5, N)"),
    "declplain": None,
    "method": ("class Recurser {\n  rec<T>(x: T, n: number): Box<T> {\n{body}  }\n}\n", "this.rec", "new Recurser().rec(5, N)"),
    "static": ("class Recurser {\n  static rec<T>(x: T, n: number): Box<T> {\n{body}  }\n}\n", "Recurser.rec", "Recurser.rec(5, N)"),
    "dispatched": ("abstract class Base {\n  abstract rec<T>(x: T, n: number): Box<T>;\n}\nclass Recurser extends Base {\n  rec<T>(x: T, n: number): Box<T> {\n    const self: Base = this;\n{body}  }\n}\nconst r: Base = new Recurser();\n", "self.rec", "r.rec(5, N)"),
    "override": ("class Base {\n  rec<T>(x: T, n: number): Box<T> {\n    return new Box(x);\n  }\n}\nclass Recurser extends Base {\n  override rec<T>(x: T, n: number): Box<T> {\n{body}  }\n}\nconst r: Base = new Recurser();\n", "this.rec", "r.rec(5, N)"),
    "interface": ("interface Recursive {\n  rec<T>(x: T, n: number): Box<T>;\n}\nclass Recurser implements Recursive {\n  rec<T>(x: T, n: number): Box<T> {\n    const self: Recursive = this;\n{body}  }\n}\nconst r: Recursive = new Recurser();\n", "self.rec", "r.rec(5, N)"),
    "literal": ("const lit = {\n  rec<T>(x: T, n: number): Box<T> {\n{body}  },\n};\n", "this.rec", "lit.rec(5, N)"),
    "arrowconst": ("const rec = <T,>(x: T, n: number): Box<T> => {\n{body}};\n", "rec", "rec(5, N)"),
    "arrowlocal": None,
    "valuemap": None,
    "value": ("let self: <U>(x: U, n: number) => Box<U>;\nfunction rec<T>(x: T, n: number): Box<T> {\n{body}}\nself = rec;\n", "self", "self(5, N)"),
}


def m8(form, depth):
    body = ("    if (n > 0) {\n      const inner: Box<T[]> = CALLEE([x], n - 1);\n      return new Box(inner.value[0]);\n"
            "    }\n    return new Box(x);\n")
    s = f"// C184: polymorphic recursion through {form}; at run time it recurses {depth} levels.\n" + BOX
    if form == "declplain":
        s = f"// C184: polymorphic recursion through a declaration whose result is T; {depth} levels at run time.\n"
        s += ("function rec<T>(x: T, n: number): T {\n  if (n > 0) {\n    const inner: T[] = rec([x], n - 1);\n"
              "    return inner[0];\n  }\n  return x;\n}\n")
        s += f"try {{\n  console.log(rec(5, {depth}) + 1);\n}} catch (error: any) {{\n  console.log(error.name, error.message);\n}}\n"
    elif form == "valuemap":
        s = (f"// C184: polymorphic recursion through a value whose result is a Map (no generic class: the\n"
             f"// function's own limit, which a trial treats as foreign); {depth} levels at run time.\n")
        s += ("let self: <U>(x: U, n: number) => Map<string, U>;\nfunction rec<T>(x: T, n: number): Map<string, T> {\n"
              "  if (n > 0) {\n    const inner: Map<string, T[]> = self([x], n - 1);\n    return new Map([[\"k\", inner.get(\"k\")![0]]]);\n"
              "  }\n  return new Map([[\"k\", x]]);\n}\nself = rec;\n")
        s += (f"try {{\n  const m: Map<string, number> = self(5, {depth});\n  console.log(m.get(\"k\")! + 1);\n"
              "} catch (error: any) {\n  console.log(error.name, error.message);\n}\n")
    elif form == "arrowlocal":
        s += ("function main(): void {\n  const rec = <T,>(x: T, n: number): Box<T> => {\n"
              + body.replace("CALLEE", "rec") + "  };\n  try {\n"
              f"    const b: Box<number> = rec(5, {depth});\n    console.log(b.value + 1);\n"
              "  } catch (error: any) {\n    console.log(error.name, error.message);\n  }\n}\nmain();\n")
    else:
        template, callee, call = POLY[form]
        s += template.replace("{body}", body.replace("CALLEE", callee))
        s += (f"try {{\n  const b: Box<number> = {call.replace('N', str(depth))};\n  console.log(b.value + 1);\n"
              "} catch (error: any) {\n  console.log(error.name, error.message);\n}\n")
    write("m8_polyrec", f"{form}_{depth}", s)


def main():
    for kind in ("decl", "arrow"):
        for k, d in ((1, 64), (1, 65), (2, 32), (2, 33), (3, 21), (3, 22), (4, 16), (4, 17)):
            m1(kind, k, d)
    for n in (10, 18, 25, 30):
        m2(n, False)
        m2(n, True)
    for n in (64, 65, 70):
        m3_value(n)
    for n in (64, 65):
        m3_plain(n)
    for w, d in ((0, 20), (10, 20), (40, 20), (10, 50), (40, 50), (150, 50)):
        m4_escape(w, d)
    for k in (10, 30, 60):
        m4_methods(k)
        m4_decls(k)
    for n in (3, 4, 5, 6, 8):
        m5_literals(n, "num")
    for n in (5, 8):
        m5_literals(n, "str")
    for n in (10, 70):
        m5_unions(n)
    for t in TRIGGERS:
        for v in VICTIMS:
            m6(t, v)
    d7 = os.path.join(OUT, "m7_ir")
    os.makedirs(d7, exist_ok=True)
    subprocess.run([sys.executable, "-I", os.path.join(TOOLS, "gen_c177.py"), d7], check=True)
    for form in POLY:
        for depth in (3, 70):
            m8(form, depth)


main()
