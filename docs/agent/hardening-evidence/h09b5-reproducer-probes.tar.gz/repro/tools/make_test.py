#!/usr/bin/env python3
"""make_test.py PROBE.pts DEST.pts "header comment line" ...: writes DEST as a run test: the header
comment lines, the probe without its own leading comment lines, and an `// expect:` block of
the probe's Node output (PROBE.node, written by duo.sh or run_matrix.py; its "exit=N" line is
dropped, and the exit must be 0)."""
import sys

probe, dest, header = sys.argv[1], sys.argv[2], sys.argv[3:]
lines = open(probe).read().splitlines()
while lines and lines[0].startswith("//"):
    lines.pop(0)
node = open(probe[:-4] + ".node").read().splitlines()
assert node and node[-1] == "exit=0", "Node must exit 0: " + node[-1]
node = node[:-1]
out = ["// " + h for h in header] + lines + ["// expect:"] + [("// " + l) if l else "//" for l in node]
open(dest, "w").write("\n".join(out) + "\n")
