#!/bin/bash
# emitc_vs_build.sh FILE.pts: with PTS_CC=rejecting_cc.sh (clang that rejects AllInstances' by-name
# lookups), compares the C `pts emit-c` prints with the C `pts build` compiled, and runs the build.
PTS=${PTS:-/tmp/h09b5/repro/bin/pts-head}
export PTS_HOME=${PTS_HOME:-/home/bryan/projects/parallelscript/.claude/worktrees/agent-a2054115b267da7c4}
d=$(mktemp -d /tmp/h09b5/repro/tmp/ecb.XXXXXX)
cp "$1" "$d/prog.pts"
cd "$d" || exit 2
PTS_CC=/tmp/h09b5/repro/tools/rejecting_cc.sh "$PTS" emit-c prog.pts -o emitted.c
echo "emit-c exit=$?"
PTS_CC=/tmp/h09b5/repro/tools/rejecting_cc.sh SAVE_C="$d/built.c" "$PTS" build prog.pts -o prog.bin
echo "build exit=$?"
./prog.bin
echo "run exit=$?"
rm -f prog.bin
wc -l emitted.c built.c
echo "pts_method_instance_find in emitted.c: $(grep -c pts_method_instance_find emitted.c), in built.c: $(grep -c pts_method_instance_find built.c)"
if cmp -s emitted.c built.c; then echo "SAME C"; else echo "emit-c's C differs from the C the build compiled"; fi
cd / && rm -rf "$d"
