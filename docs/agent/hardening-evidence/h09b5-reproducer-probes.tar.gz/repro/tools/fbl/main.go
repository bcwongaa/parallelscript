// Command fbl ("fallback level") lowers each file given with each of lower.Fallbacks alone
// (driver.EmitCWith, no fallback) and prints, per specialization, OK with the lines of C or
// the first line of the error; with CLANG=1 it also compiles each level's C against the
// runtime, as driver.Build does, and says whether clang accepts it. It then prints which
// level `pts emit-c` uses (the first that lowers) and which `pts build` uses (the first
// that lowers and compiles, CLANG=1 only). Run with PTS_HOME=<tree>.
package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

var names = map[lower.Specialization]string{
	lower.AllInstances:      "AllInstances",
	lower.ValueInstances:    "ValueInstances",
	lower.DeclaredInstances: "DeclaredInstances",
}

func main() {
	ctx := context.Background()
	clang := os.Getenv("CLANG") == "1"
	var tc *toolchain.Toolchain
	var rt *toolchain.Runtime
	if clang {
		var err error
		if tc, err = toolchain.New(); err == nil {
			rt, err = tc.Runtime(ctx, toolchain.Release)
		}
		if err != nil {
			fmt.Println("toolchain:", err)
			os.Exit(2)
		}
	}
	dir, _ := os.MkdirTemp("", "fbl-")
	defer os.RemoveAll(dir)
	for _, file := range os.Args[1:] {
		fmt.Println("==", file)
		emitPick, buildPick := "none", "none"
		for _, s := range lower.Fallbacks {
			code, err := driver.EmitCWith(ctx, file, s)
			if err != nil {
				fmt.Printf("  %-17s ERR %s\n", names[s], strings.SplitN(err.Error(), "\n", 2)[0])
				continue
			}
			lines := strings.Count(code, "\n")
			status := ""
			if clang {
				cFile := filepath.Join(dir, "main.c")
				os.WriteFile(cFile, []byte(code), 0o644)
				exe := filepath.Join(dir, "a.out")
				if cerr := tc.CompileProgram(ctx, rt, []string{cFile}, exe); cerr != nil {
					first := ""
					for _, line := range strings.Split(cerr.Error(), "\n") {
						if strings.Contains(line, "error:") {
							first = line
							break
						}
					}
					status = " CLANG-REJECTS " + first
				} else {
					status = " clang-ok"
					if buildPick == "none" {
						buildPick = names[s]
					}
				}
				os.Remove(exe)
			}
			if emitPick == "none" {
				emitPick = names[s]
			}
			fmt.Printf("  %-17s OK %d lines of C%s\n", names[s], lines, status)
		}
		fmt.Printf("  emit-c uses %s", emitPick)
		if clang {
			fmt.Printf("; build uses %s", buildPick)
		}
		fmt.Println()
	}
}
