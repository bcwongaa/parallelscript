#!/usr/bin/env python3
"""Builds matrix/table.tsv: one row per case and family with its class under each binary
(HEAD, P1, P1+P2, P1+P2+P3), from the run_matrix.py result files. Rows of a result file
follow its sorted case paths, so a file's rows are split into families by the families' case
counts at the time it ran (m3's cases were renamed later: plain_N -> plainboxes_N,
value_N -> viavalue_N, and m7 was regenerated; those families come from their own reruns)."""
import os

M = "/tmp/h09b5/repro/matrix"
COUNTS = {"m1_fnlimit": 16, "m2_classleak": 8, "m3_limit": 5, "m4_growth": 12, "m5_variants": 9,
          "m6_fallback": 25, "m7_ir": 82, "m8_polyrec": 24}


def rows(path):
    return [l.split("\t") for l in open(path).read().splitlines()[1:]]


def split(path, families):
    out, rs, i = {}, rows(path), 0
    for fam in families:
        for r in rs[i:i + COUNTS[fam]]:
            out[(fam, r[0])] = r
        i += COUNTS[fam]
    assert i == len(rs), (path, i, len(rs))
    return out


def own(path, fam):
    return {(fam, r[0]): r for r in rows(path)}


head = split(f"{M}/results_head.tsv", list(COUNTS))
head = {k: v for k, v in head.items() if k[0] not in ("m3_limit", "m7_ir")}
head.update(own(f"{M}/results_head_m3.tsv", "m3_limit"))
head.update(own(f"{M}/results_head_m7.tsv", "m7_ir"))
p1 = split(f"{M}/results_p1.tsv", ["m1_fnlimit", "m2_classleak", "m3_limit", "m6_fallback", "m8_polyrec"])
p12 = split(f"{M}/results_p12.tsv", ["m1_fnlimit", "m2_classleak", "m3_limit", "m6_fallback", "m8_polyrec"])
p123 = split(f"{M}/results_p123.tsv", ["m1_fnlimit", "m2_classleak", "m3_limit", "m8_polyrec"])
for d in (p1, p12, p123):
    for k in [k for k in d if k[0] == "m3_limit"]:
        del d[k]
p1.update(own(f"{M}/results_p1_m3.tsv", "m3_limit"))
p12.update(own(f"{M}/results_p12_m3.tsv", "m3_limit"))
p123.update(own(f"{M}/results_p123_m3.tsv", "m3_limit"))

with open(f"{M}/table.tsv", "w") as f:
    f.write("family\tcase\tHEAD\tloc_HEAD\tbuild_wall_s_HEAD\tbuild_user_s_HEAD\tmaxrss_kb_HEAD\tP1\tP1+P2\tP1+P2+P3\tloc_P1+P2+P3\tbuild_wall_s_P1+P2+P3\tHEAD_first_difference\n")
    for key in sorted(head):
        h = head[key]
        c = lambda d: d[key][1] if key in d else "-"
        p3 = p123.get(key)
        f.write("\t".join([key[0], key[1], h[1], h[2], h[3], h[4], h[5], c(p1), c(p12), c(p123),
                           p3[2] if p3 else "-", p3[3] if p3 else "-", h[6]]) + "\n")
print(len(head), "rows")
