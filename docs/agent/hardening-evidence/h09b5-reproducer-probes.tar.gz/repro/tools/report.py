#!/usr/bin/env python3
"""Writes matrix/report.txt from matrix/table.tsv: per family the counts of each class under
HEAD and the prototypes, then each case's row."""
from collections import Counter, defaultdict

M = "/tmp/h09b5/repro/matrix"
rows = [l.split("\t") for l in open(f"{M}/table.tsv").read().splitlines()[1:]]
cols = ((2, "HEAD"), (7, "P1"), (8, "P1+P2"), (9, "P1+P2+P3"))
out = ["H09b5 reproducer matrix (Node v24 the oracle; HEAD = 7428a7b0f, code of 27d1f0b07).",
       "P1, P1+P2, P1+P2+P3 are THROWAWAY prototypes (go build -overlay, proto/), not fixes:",
       "  P1  lower.go irType: classInstanceOf's nil *ir.Class returned as a nil ir.Type (no typed nil)",
       "  P2  generics.go genericInstanceFor: the function limit in a trial is the trial's failure (no t.foreign)",
       "  P3  generics.go maxInstances 64 -> 1024 (to measure what a raised count costs; not proposed)",
       "Classes: OK, WRONG, TYPEERR (a TypeError `Expected ...` Node doesn't print), PTS1001, PTS9001,",
       "CRASH, BUILD-TIMEOUT, TSERR (generator bug). m5's `N threw Expected ...` lines count as WRONG.",
       "loc = lines of `pts emit-c` C on HEAD; wall/user = `pts build` seconds; rss = KB.", ""]
by = defaultdict(lambda: defaultdict(Counter))
for r in rows:
    for i, name in cols:
        if r[i] != "-":
            by[r[0]][name][r[i]] += 1
for fam in sorted(by):
    out.append(f"## {fam}: " + " | ".join(f"{k}: " + " ".join(f"{c}={n}" for c, n in sorted(v.items())) for k, v in by[fam].items()))
    for r in rows:
        if r[0] != fam:
            continue
        protos = "/".join(r[i] for i, _ in cols[1:])
        out.append(f"  {r[1]:44s} HEAD={r[2]:8s} loc={r[3]:>6s} wall={r[4]:>6s} user={r[5]:>6s} rss={r[6]:>7s}  protos={protos:26s} {r[12][:140]}")
    out.append("")
out.append("C177 (m7) by pair and form:")
out += open(f"{M}/m7_summary.txt").read().splitlines()
open(f"{M}/report.txt", "w").write("\n".join(out) + "\n")
print(len(out), "lines")
