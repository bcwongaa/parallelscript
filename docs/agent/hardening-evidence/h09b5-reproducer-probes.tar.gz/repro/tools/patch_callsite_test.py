#!/usr/bin/env python3
"""One-off: makes the call-site C176 RED test print only that the failing call ran (its own
result may come from its erased copy; its PTS1001 is a separate defect)."""
import sys

for p in sys.argv[1:]:
    s = open(p).read()
    old = '''attempt("trigger", () => {
  const b: Box<number[]> = m.f(maybe(), 1, 2);
  return b.value.join("/");
});
// expect:
// victim 6
// trigger 1/2'''
    assert old in s, p
    s = s.replace(old, '''try {
  // The failing call's own result may come from its erased copy (its PTS1001 is a separate
  // defect), so only that it ran is printed.
  const b: Box<number[]> = m.f(maybe(), 1, 2);
  console.log("trigger ran", b.value.length);
} catch (error: any) {
  console.log("trigger ran", 2);
}
// expect:
// victim 6
// trigger ran 2''')
    s = s.replace("its own (`Expected Box<number[]>, got Box<any[]>`). Only the failing call keeps its erased copy.",
                  "its own. Only the failing call may keep its erased copy.")
    open(p, "w").write(s)
