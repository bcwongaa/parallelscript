#!/bin/bash
# run_red.sh TAG: runs the H09b5 RED tests in the reproducer's worktree (TestRun, TestRunMatchesNode,
# TestErrors, the driver's narrow_fallback tests) and writes logs/red_<suite>_TAG.log.
TAG=${1:-head}
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a2054115b267da7c4
LOGS=/tmp/h09b5/repro/logs
RUNRE='generic_class_instances_literal_type_arguments|generic_dynamic_variants_past_cap|generic_fallback_spares_unrelated_call_site|generic_fallback_spares_unrelated_class_body|generic_fallback_spares_unrelated_interface_call|generic_fallback_spares_unrelated_relaxed_cast|generic_instances_branded_type_arguments|generic_instances_same_ir_type_promises|generic_instances_same_ir_type_twins|generic_polymorphic_recursion_dispatched|generic_polymorphic_recursion_interface|generic_polymorphic_recursion_literal_method|generic_polymorphic_recursion_local_arrow|generic_polymorphic_recursion_value|generic_speculative_class_instances|generic_speculative_function_instances|generic_values_same_ir_type_promises|generic_values_read_back_from_any'
ERRRE='generic_class_limit_value_calls|generic_polymorphic_recursion_direct|generic_class_instance_failure_value_calls'
cd "$WT" || exit 2
export PTS_HOME=$WT GOMAXPROCS=2 PATH=$HOME/.local/node/bin:$PATH
for suite in ${SUITES:-TestRun TestRunMatchesNode TestErrors driver}; do
  log=$LOGS/red_${suite}_${TAG}.log
  case $suite in
    TestRun) go test -p 2 -count=1 -run "^TestRun\$/^($RUNRE)\$" ./pts/tests/ > "$log" 2>&1 ;;
    TestRunMatchesNode) PTS_REQUIRE_NODE=1 go test -p 2 -count=1 -run "^TestRunMatchesNode\$/^($RUNRE)\$" ./pts/tests/ > "$log" 2>&1 ;;
    TestErrors) go test -p 2 -count=1 -v -run "^TestErrors\$/^($ERRRE)\$" ./pts/tests/ > "$log" 2>&1 ;;
    driver) go test -p 2 -count=1 -v -run '^(TestEmitCPrintsTheCThatBuildCompiles|TestAValueWhoseClassInstanceDoesntLowerCostsNoOtherValueItsInstances|TestValuesThatNoTypedCallReachesGetNoInstances)$' ./pts/driver/ > "$log" 2>&1 ;;
  esac
  echo "exit=$?" >> "$log"
  echo "== $suite ($log)"
  grep -E "^\s*--- (FAIL|PASS|SKIP)|^(ok|FAIL)\s|^exit=" "$log"
done
