#!/usr/bin/env python3
"""summarize.py CASES_DIR RESULTS.tsv [OTHER.tsv]: per family (CASES_DIR/<family>), the count of
each class and each case's row; with OTHER.tsv (a second run), each case's class there too."""
import os, sys
from collections import Counter

cases, results = sys.argv[1], sys.argv[2]
other = sys.argv[3] if len(sys.argv) > 3 else None


def load(path):
    rows = {}
    for line in open(path).read().splitlines()[1:]:
        parts = line.split("\t")
        rows[parts[0]] = parts
    return rows


rows = load(results)
rows2 = load(other) if other else {}
for family in sorted(os.listdir(cases)):
    names = sorted(f[:-4] for f in os.listdir(os.path.join(cases, family)) if f.endswith(".pts"))
    counts = Counter(rows[n][1] for n in names if n in rows)
    line = f"## {family}: " + " ".join(f"{k}={v}" for k, v in sorted(counts.items()))
    if other:
        counts2 = Counter(rows2[n][1] for n in names if n in rows2)
        line += "   | other: " + " ".join(f"{k}={v}" for k, v in sorted(counts2.items()))
    print(line)
    for n in names:
        r = rows.get(n)
        if not r:
            continue
        extra = f"  -> {rows2[n][1]}" if n in rows2 else ""
        print(f"  {n:44s} {r[1]:13s} loc={r[2]:>6s} wall={r[3]:>6s} user={r[4]:>6s} rss={r[5]:>8s}{extra}  {r[6][:150]}")
