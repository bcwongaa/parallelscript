#!/usr/bin/env python3
"""Generates the hand probes for C172 (a) and (b) into the directory given (default .).

c172_plain_boxes_N: N class instances of Box made by plain typed code, no generic function.
c172_fn_limit_KxD: K generic declarations of one function type, each passed to its own
  consumer that calls it with D class types of its own: each function needs D instances,
  pairing every demand with every value makes K*D.
c172_class_leak_N[_control]: mkA (genuinely called with N class types, needs Box<Ai[]>) and
  mkB (genuinely called with number only, makes Box<T[][]>): mkB's speculative pairings with
  mkA's demands make Box<Ai[][]> class instances that no call uses; past the class limit
  mkA's own instances fail their trials. The control has no mkB.
"""
import sys, os

out = sys.argv[1] if len(sys.argv) > 1 else "."

BOX = "class Box<T> {\n  constructor(public value: T) {}\n}\n"


def classes(prefix, n):
    return "".join(f"class {prefix}{i} {{\n  tag = {i};\n}}\n" for i in range(n))


def write(name, text):
    with open(os.path.join(out, name + ".pts"), "w") as f:
        f.write(text)


def plain_boxes(n):
    s = f"// C172(b): {n} instances of Box made by plain typed code, no generic function.\n" + BOX + classes("C", n)
    s += "let s = 0;\n"
    for i in range(n):
        s += f"const b{i}: Box<C{i}> = new Box(new C{i}());\ns += b{i}.value.tag;\n"
    s += "console.log(s);\n"
    write(f"c172_plain_boxes_{n}", s)


def fn_limit(k, d):
    s = (f"// C172(a): {k} generic declarations of one function type, each passed to its own consumer\n"
         f"// calling it with {d} class types of its own: {d} instances each needed, {k * d} paired.\n")
    for j in range(k):
        s += f"function mapOf{j}<T>(x: T): Map<string, T> {{\n  return new Map([[\"k{j}\", x]]);\n}}\n"
    for j in range(k):
        s += classes(f"C{j}_", d)
    for j in range(k):
        s += f"function use{j}(f: <T>(x: T) => Map<string, T>): number {{\n  let s = 0;\n"
        for i in range(d):
            s += f"  const m{i}: Map<string, C{j}_{i}> = f(new C{j}_{i}());\n  s += m{i}.get(\"k{j}\")!.tag;\n"
        s += "  return s;\n}\n"
    s += "console.log(" + ", ".join(f"use{j}(mapOf{j})" for j in range(k)) + ");\n"
    write(f"c172_fn_limit_{k}x{d}", s)


def class_leak(n, control):
    s = (f"// C172(a): mkA is called with {n} class types (Box<Ai>, Box<Ai[]>); mkB only with number.\n"
         "// Pairing mkB with mkA's demands makes Box<Ai[][]> instances no call uses"
         + (" (control: no mkB).\n" if control else ".\n"))
    s += BOX + classes("A", n)
    s += ("function mkA<T>(x: T): Box<T> {\n  const w = new Box([x]);\n  return new Box(w.value[0]);\n}\n")
    if not control:
        s += ("function mkB<T>(x: T): Box<T> {\n  const w = new Box([[x]]);\n  return new Box(w.value[0][0]);\n}\n")
    s += "function useA(f: <T>(x: T) => Box<T>): void {\n"
    for i in range(n):
        s += (f"  try {{\n    const b{i}: Box<A{i}> = f(new A{i}());\n    console.log({i}, b{i}.value.tag);\n"
              f"  }} catch (e: any) {{\n    console.log({i}, e.message);\n  }}\n")
    s += "}\n"
    s += "function useB(f: <T>(x: T) => Box<T>): number {\n  const b: Box<number> = f(1);\n  return b.value;\n}\n"
    s += "useA(mkA);\n"
    s += "console.log(useB(mkB));\n" if not control else "console.log(useB(mkA));\n"
    write(f"c172_class_leak_{n}" + ("_control" if control else ""), s)


for n in (64, 70):
    plain_boxes(n)
for k, d in ((1, 64), (1, 65), (2, 32), (2, 33), (3, 22)):
    fn_limit(k, d)
for n in (25,):
    class_leak(n, False)
    class_leak(n, True)
