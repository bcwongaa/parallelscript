#!/usr/bin/env python3
"""Copies the RED tests listed (git status --short lines) from the reproducer's worktree into
/tmp/h09b5/repro/red/<run|errors|driver>/."""
import os, shutil, sys

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a2054115b267da7c4"
OUT = "/tmp/h09b5/repro/red"
shutil.rmtree(OUT, ignore_errors=True)
for line in open(sys.argv[1]).read().splitlines():
    path = line.split()[1]
    kind = "driver" if path.startswith("pts/driver/") else path.split("/")[2]
    os.makedirs(os.path.join(OUT, kind), exist_ok=True)
    shutil.copy(os.path.join(WT, path), os.path.join(OUT, kind))
    print(kind, os.path.basename(path))
