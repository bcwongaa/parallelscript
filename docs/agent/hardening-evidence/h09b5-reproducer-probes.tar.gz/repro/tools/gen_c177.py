#!/usr/bin/env python3
"""Generates C177 probes into the directory given (default .): typed calls whose type
arguments have the same IR types (D-049: instances are keyed by IR types) but whose results
differ by checker type.

Each probe is <shape>__<pair>__<form>[__rev].pts:
  shape: how the result depends on T beyond its IR type
    infer    Box<T extends Promise<infer U> ? U : T>        (g03's)
    awaited  Box<Awaited<T>>
    brand    Box<T extends Id ? string : number>              (Id a branded number)
    literal  Box<T extends 1 ? string : number>               (a literal vs its base: told apart, guard)
    twin     Box<T extends { kind: "a" } ? number : string>   (structural twins of one shape)
  pair: the two type arguments, of one IR type
  form: decl (a function declaration called by name), method (a class's generic method),
        arrowconst (a module-scope generic const, D-102), value (a value of a generic function
        type, D-148's demand), klass (a generic class's instances: Holder<A>, Holder<B>)
  rev: the second type argument's call first
The result type is a type alias R<T>; each call passes `new Box(v)` as the parameter v: R<T>, and
the body returns `new Box(v.value)`, a new box of the instance's own type (no `as any`, whose
Box<any> doesn't convert to the instance's result, D-078: the first version's bodies failed
for that reason alone, as g03's does). Node prints what each call's result holds.
"""
import sys, os

out = sys.argv[1] if len(sys.argv) > 1 else "."

PRELUDE = """class Box<T> {
  constructor(public value: T) {}
}
type Id = number & { readonly __brand: "id" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""

SHAPES = {
    "infer": "Box<T extends Promise<infer U> ? U : T>",
    "awaited": "Box<Awaited<T>>",
    "brand": "Box<T extends Id ? string : number>",
    "literal": "Box<T extends 1 ? string : number>",
    "twin": 'Box<T extends { kind: "a" } ? number : string>',
}

# Each pair: (shape, label, argument expression, explicit type argument, how to show the
# result's value, the value the body puts in the box (as any)).
PAIRS = {
    "infer": [
        ("promise_any", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("any", "2 as any", "2", "String(r.value)")),
        ("promise_unknown", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("unknown", "2 as unknown", "2", "String(r.value)")),
        ("promise_promise", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("Promise<string>", 'Promise.resolve("s")', '"t"', "r.value + \"!\"")),
    ],
    "awaited": [
        ("promise_any", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("any", "2 as any", "2", "String(r.value)")),
        ("promise_promise", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("Promise<string>", 'Promise.resolve("s")', '"t"', "r.value + \"!\"")),
    ],
    "brand": [
        ("brand_number", ("Id", "5 as Id", '"s"', "r.value + \"!\""), ("number", "5", "7", "r.value + 1")),
    ],
    "literal": [
        ("one_number", ("1", "1 as const", '"s"', "r.value + \"!\""), ("number", "5", "7", "r.value + 1")),
    ],
    "twin": [
        ("a_b", ('{ kind: "a" }', '{ kind: "a" as const }', "3", "r.value + 1"), ('{ kind: "b" }', '{ kind: "b" as const }', '"s"', "r.value + \"!\"")),
    ],
}


def probe(shape, pair, form, rev, solo=0):
    label, first, second = pair
    calls = [first, second]
    if rev:
        calls.reverse()
    if solo:
        calls = [calls[solo - 1]]  # a control: one type argument alone
    result = SHAPES[shape]
    s = (f"// C177 {shape}/{label}/{form}{' (second call first)' if rev else ''}: type arguments "
         f"{first[0]} and {second[0]}, of one IR type,\n// give {result} of other checker types.\n")
    s += PRELUDE
    # The body boxes the value the caller asks for (v), so each call's result holds what its
    # type says.
    s += f"type R<T> = {result};\n"
    if form in ("decl", "value"):
        s += "function pick<T>(x: T, v: R<T>): R<T> {\n  return new Box(v.value);\n}\n"
    elif form == "arrowconst":
        s += "const pick = <T,>(x: T, v: R<T>): R<T> => new Box(v.value);\n"
    elif form == "method":
        s += "class Picker {\n  pick<T>(x: T, v: R<T>): R<T> {\n    return new Box(v.value);\n  }\n}\nconst picker = new Picker();\n"
    elif form == "klass":
        s += "class Holder<T> {\n  constructor(public x: T) {}\n  pick(v: R<T>): R<T> {\n    return new Box(v.value);\n  }\n}\n"
    if form == "value":
        s += "function use(f: <T>(x: T, v: R<T>) => R<T>): void {\n"
        indent = "  "
    else:
        indent = ""
    for t, arg, v, show in calls:
        if form in ("decl", "arrowconst"):
            call = f"pick<{t}>({arg}, new Box({v}))"
        elif form == "value":
            call = f"f<{t}>({arg}, new Box({v}))"
        elif form == "method":
            call = f"picker.pick<{t}>({arg}, new Box({v}))"
        elif form == "klass":
            call = f"new Holder<{t}>({arg}).pick(new Box({v}))"
        s += f'{indent}attempt("{t.replace(chr(34), chr(39))}:", () => {{\n{indent}  const r = {call};\n{indent}  return String({show});\n{indent}}});\n'
    if form == "value":
        s += "}\nuse(pick);\n"
    name = f"{shape}__{label}__{form}" + ("__rev" if rev else "") + (f"__solo{solo}" if solo else "")
    with open(os.path.join(out, name + ".pts"), "w") as f:
        f.write(s)
    return name


def arrays_probe(rev):
    """D-197's known gap: arrays<Promise<number>> and arrays<unknown> with an Array.isArray branch."""
    calls = [("Promise<number>", "Promise.resolve(1)"), ("unknown", "[1, 2] as unknown")]
    if rev:
        calls.reverse()
    s = ("// C177 narrowed/arrays: an instance shared by Promise<number> and unknown (IR value) lowers its\n"
         "// Array.isArray branch with the first type argument's types (D-195, D-197's known gap).\n")
    s += PRELUDE
    s += "function arrays<T>(x: T): number {\n  if (Array.isArray(x)) {\n    return x.length;\n  }\n  return 0;\n}\n"
    for t, arg in calls:
        s += f'attempt("{t.replace(chr(34), chr(39))}:", () => String(arrays<{t}>({arg})));\n'
    name = "narrowed__arrays__decl" + ("__rev" if rev else "")
    with open(os.path.join(out, name + ".pts"), "w") as f:
        f.write(s)
    return name


names = []
for shape, pairs in PAIRS.items():
    for pair in pairs:
        for form in ("decl", "method", "arrowconst", "value", "klass"):
            for rev in (False, True):
                names.append(probe(shape, pair, form, rev))
        names.append(probe(shape, pair, "decl", False, 1))
        names.append(probe(shape, pair, "decl", False, 2))
names.append(arrays_probe(False))
names.append(arrays_probe(True))
print(len(names), "probes")
