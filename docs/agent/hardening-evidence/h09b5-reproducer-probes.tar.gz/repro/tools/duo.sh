#!/bin/bash
# duo.sh FILE.pts... : run each probe with Node (.mts copy) and HEAD's CLI (the reproducer's build).
# Writes FILE.node / FILE.<SUF> (output + "exit=N") beside the probe and prints them.
# NO_NODE=1 skips Node; SUF (default head) names the pts output; PTS/PTSHOME pick the CLI and runtime.
NODE=${NODE:-$HOME/.local/node/bin/node}
PTSHOME=${PTSHOME:-/home/bryan/projects/parallelscript/.claude/worktrees/agent-a2054115b267da7c4}
PTS=${PTS:-$PTSHOME/pts-bin/pts}
SUF=${SUF:-head}
for f in "$@"; do
  abs=$(readlink -f "$f"); dir=$(dirname "$abs"); b=$(basename "$abs" .pts)
  d=$(mktemp -d /tmp/h09b5/repro/tmp/t.XXXXXX)
  cp "$abs" "$d/$b.mts"
  if [ -z "$NO_NODE" ]; then
    (cd "$d" && TZ=America/New_York timeout 60 "$NODE" --no-warnings --experimental-transform-types "$b.mts" > "$dir/$b.node" 2>&1; echo "exit=$?" >> "$dir/$b.node")
  fi
  (cd "$d" && PTS_HOME=$PTSHOME TZ=America/New_York timeout ${PTS_TIMEOUT:-300} "$PTS" run "$abs" > "$dir/$b.$SUF" 2>&1; echo "exit=$?" >> "$dir/$b.$SUF")
  echo "=== $f"
  for k in node $SUF; do [ -f "$dir/$b.$k" ] && { echo "--- $k"; head -c 3000 "$dir/$b.$k"; }; done
  if cmp -s "$dir/$b.node" "$dir/$b.$SUF"; then echo "--- $SUF SAME as node"; else echo "--- $SUF DIFF from node"; fi
  rm -rf "$d"
done
