#!/usr/bin/env python3
"""Keeps one file per distinct content in the pool directory given (the H09 probe archives
repeat earlier rounds' probes), deleting the others, and drops files over 200 KB."""
import hashlib, os, sys

root = sys.argv[1]
seen = {}
kept = removed = 0
for dirpath, _, files in sorted(os.walk(root)):
    for name in sorted(files):
        path = os.path.join(dirpath, name)
        data = open(path, "rb").read()
        digest = hashlib.sha256(data).hexdigest()
        if digest in seen or len(data) > 200_000:
            os.remove(path)
            removed += 1
        else:
            seen[digest] = path
            kept += 1
print("kept", kept, "removed", removed)
