# gen_escape.py N M OUT: N local generic arrows that escape into an any[] (so calledOnlyName
# doesn't filter them) and one arrow passed to `use`, whose M typed calls are demands:
# every escaped arrow is paired with every demand (N x M speculative instances).
import sys
n, m, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
L = ["class Box<T> {", "  constructor(public value: T) {}", "}"]
for j in range(m):
    L += [f"class C{j} {{", f"  tag = {j};", "}"]
L.append("let total = 0;")
L.append("const keep: any[] = [];")
L.append("function use(f: <T>(x: T) => Box<T>): void {")
for j in range(m):
    L.append(f"  const b{j}: Box<C{j}> = f(new C{j}());")
    L.append(f"  total += b{j}.value.tag;")
L.append("}")
L.append("function main(): void {")
for i in range(n):
    L.append(f"  const a{i} = <T>(x: T): Box<T> => new Box(x);")
    L.append(f"  keep.push(a{i});")
L.append("  use(<T>(x: T): Box<T> => new Box(x));")
L.append("}")
L.append("main();")
L.append("console.log(total, keep.length);")
open(out, "w").write("\n".join(L) + "\n")
