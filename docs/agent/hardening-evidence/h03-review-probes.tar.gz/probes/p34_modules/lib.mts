function* src(): Generator<any> { try { yield "first"; yield undefined; yield 3; } finally { console.log("lib src closed"); } }
export const [first, second = "second default"] = src() as any;
export let [counter, step = 1] = [10] as any;
export function bump() { counter += step; return counter; }
