import { first, second, counter, bump } from "./lib.mts";
console.log(first, second, counter);
console.log(bump(), bump());
