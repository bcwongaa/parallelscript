function call(f: (x: number) => number | void) { return f(1); }
console.log(call((x) => { if (x) return; return 2; }));
const g: (x: number) => void = (x) => { if (x) return; return 5; };
console.log(g(1), g(0));
function opt(n: number): number | undefined { if (n > 0) return; return 3; }
console.log(opt(1), opt(0));
const o = { get v(): void { return; }, m(): void { return; } };
console.log(`${o.v}`, o.v + "!", String(o.v), [o.v], JSON.stringify([o.v]));
class Q { #p = 1; get priv(): void { this.#p++; return; } read() { return this.#p; } }
const q = new Q(); q.priv; q.priv; console.log(q.read());
