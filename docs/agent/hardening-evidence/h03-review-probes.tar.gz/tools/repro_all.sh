#!/bin/bash
# Reruns the review's key repros: new CLI (parent tree), base CLI (7f0a4131a worktree), Node.
for p in r2a_for_init_plain r2b_for_init_default r2c_for_init_generator r2d_for_init_class r1_inferred_next_getters r1b_iterator_literal_next r1c_setter_as_iterator_result s1_c31_interface_iterable s2_typed_array_any_live n1_elision_reads_value n2_rest_nested_past_end n5a_symbol_iterator_getter_panic n5b_generator_param_pattern_timing; do
  DIFFN=6 ERRN=3 /tmp/pts-h03-review/tools/cmp.sh /tmp/pts-h03-review/probes/$p.pts
done
