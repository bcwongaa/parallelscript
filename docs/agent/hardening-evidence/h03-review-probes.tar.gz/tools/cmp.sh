#!/bin/bash
# usage: cmp.sh probe.pts  -> runs new PTS, base PTS, Node; prints outputs and exit codes
set -o pipefail
p="$1"; name=$(basename "$p" .pts); out=/tmp/pts-h03-review/out/$name; mkdir -p "$out"
ulimit -f 40960
cp "$p" "$out/$name.mts"
( ulimit -v 4194304; cd "$out" && timeout 60 env PATH=$HOME/.local/node/bin:$PATH TZ=America/New_York node --no-warnings --experimental-transform-types "$out/$name.mts" > "$out/node.out" 2> "$out/node.err"; echo $? > "$out/node.exit" )
run() { # $1 tag $2 cli $3 home $4 cache
  local tag=$1
  ( cd "$out" && timeout 120 env PTS_HOME=$3 PTS_CACHE_DIR=$4 GOMAXPROCS=2 $2 build "$p" -o "$out/$tag.bin" > "$out/$tag.build" 2>&1; echo $? > "$out/$tag.buildexit" )
  if [ "$(cat $out/$tag.buildexit)" = 0 ]; then
    ( ulimit -v 4194304; cd "$out" && timeout 60 env TZ=America/New_York "$out/$tag.bin" > "$out/$tag.out" 2> "$out/$tag.err"; echo $? > "$out/$tag.exit" )
  else
    cp "$out/$tag.build" "$out/$tag.err"; : > "$out/$tag.out"; echo build-fail > "$out/$tag.exit"
  fi
}
run new /tmp/pts-h03-review/pts /home/bryan/projects/parallelscript /tmp/pts-h03-review/cache
if [ -z "$NOBASE" ]; then run base /home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e/pts-bin/pts /home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e /tmp/pts-h03-repro/cache; fi
echo "== $name: node exit $(cat $out/node.exit); new exit $(cat $out/new.exit)$( [ -z "$NOBASE" ] && echo "; base exit $(cat $out/base.exit)")"
if diff -q "$out/node.out" "$out/new.out" >/dev/null; then echo "new == node (stdout)"; else echo "new != node:"; diff "$out/node.out" "$out/new.out" | head -${DIFFN:-30}; fi
if [ -z "$NOBASE" ]; then if diff -q "$out/node.out" "$out/base.out" >/dev/null; then echo "base == node (stdout)"; else echo "base != node:"; diff "$out/node.out" "$out/base.out" | head -${DIFFN:-15}; fi; fi
[ -s "$out/new.err" ] && { echo "-- new stderr:"; head -${ERRN:-8} "$out/new.err"; }
[ -z "$NOBASE" ] && [ -s "$out/base.err" ] && { echo "-- base stderr:"; head -${ERRN:-5} "$out/base.err"; }
[ -s "$out/node.err" ] && { echo "-- node stderr:"; head -5 "$out/node.err"; }
exit 0
