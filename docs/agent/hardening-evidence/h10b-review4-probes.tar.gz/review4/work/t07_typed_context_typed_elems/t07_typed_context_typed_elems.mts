// Typed-context literals whose element type is typed (number[][], string[]) holding a Box<any> object's any[] members
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
}
const b = new Box<any>(1);
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
t("numberRows", () => { const rows: number[][] = [b.items]; rows[0].push(2); return [rows, b.items]; });
t("direct", () => { const xs: number[] = b.items; xs.push(3); return [xs, b.items]; });
t("tupleTyped", () => { const p: [number[], string] = [b.items, "s"]; return p; });
t("unionElems", () => { const u: (number[] | string)[] = [b.items, "s"]; return u; });
