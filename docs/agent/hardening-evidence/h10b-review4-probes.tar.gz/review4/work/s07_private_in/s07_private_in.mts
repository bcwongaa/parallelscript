// privateIn after R2-F7: instance brands across instances and subclasses, static brands, primitives, through any, unknown narrowing
class Box<T> {
  static #count = 0;
  #v: T;
  constructor(v: T) { this.#v = v; Box.#count++; }
  static check(o: any): string {
    const r: string[] = [];
    for (const f of [() => #v in o, () => #count in o]) { try { r.push(String(f())); } catch (e) { r.push((e as Error).message); } }
    return r.join(",");
  }
}
class Sub extends Box<string> {}
console.log(Box.check(new Box<number>(1)), "|", Box.check(new Sub("s")), "|", Box.check({}), "|", Box.check("str"), "|", Box.check(undefined), "|", Box.check([]));
