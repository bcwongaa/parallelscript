// LinkedList<any> chains: map().map(), filter().map(), map() on a local, map() inside the class on another list
class LinkedList<T> {
  items: T[] = [];
  push(v: T): this { this.items.push(v); return this; }
  map<R>(f: (v: T) => R): LinkedList<R> { const l = new LinkedList<R>(); for (const v of this.items) l.push(f(v)); return l; }
  filter(p: (v: T) => boolean): LinkedList<T> { const l = new LinkedList<T>(); for (const v of this.items) if (p(v)) l.push(v); return l; }
  concatMapped<R>(other: LinkedList<T>, f: (v: T) => R): LinkedList<R> { return other.map(f); }
}
const list = new LinkedList<any>().push(1).push("two");
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
t("mapmap", () => list.map((v) => [v]).map((v) => v.length).items);
t("filtermap", () => list.filter((v) => true).map((v) => typeof v).items);
t("local", () => { const l2 = list.filter(() => true); const l3 = l2.map((v) => 1); return l3.items; });
t("inClass", () => list.concatMapped(list, (v) => `${v}`).items);
t("pushmap", () => list.push(3).map((v) => v).items);
