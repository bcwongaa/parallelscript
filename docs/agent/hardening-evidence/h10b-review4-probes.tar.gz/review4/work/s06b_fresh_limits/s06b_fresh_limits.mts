// Fresh conversion limits for Box<any> objects only: nested containers two deep, maps of arrays of arrays, unions,
// tuples, records, entries, and fresh containers whose items are another fresh container
class Box<T> {
  items: T[] = [];
  matrix: T[][] = [[]];
  cube: T[][][] = [[[]]];
  store = new Map<string, T[]>([["k", []]]);
  rec: Record<string, T[]> = { a: [] };
  constructor(public v: T) {}
}
const b = new Box<any>(1);
const out: string[] = [];
const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).message.slice(0, 40)}`); } };
t("cubeSpread", () => { const c: any[][][] = [...b.cube]; c[0][0].push("c"); });
t("cubeLit", () => { const c: any[][][] = [b.matrix]; c[0][0].push("l"); });
t("nestedFresh", () => { const c: any[][][] = [[b.items]]; c[0][0].push("n"); });
t("union", () => { const u: any[][] | string = [b.items]; (u as any[][])[0].push("u"); });
t("unionNull", () => { const u: any[][] | null = b.matrix.map((r) => r); u![0].push("un"); });
t("tuple", () => { const p: [any[], any[]] = [b.items, b.matrix[0]]; p[1].push("tp"); });
t("tupleArr", () => { const ps: [string, any[]][] = [["x", b.items]]; ps[0][1].push("ta"); });
t("entries", () => { const es: [string, any[]][] = [...b.store.entries()]; es[0][1].push("e"); });
t("mapOfRows", () => { const m: Map<string, any[][]> = new Map([["m", b.matrix]]); m.get("m")![0].push("mm"); });
t("setOfSets", () => { const s: Set<any[]>[] = [new Set(b.matrix)]; [...s[0]][0].push("ss"); });
t("objLitArr", () => { const o: { rows: any[][] } = { rows: [b.items] }; o.rows[0].push("ol"); });
console.log(out.join(" | "));
console.log(JSON.stringify([b.items, b.matrix, b.cube, [...b.store], b.rec]));
