// R3: a generic method called on the RESULT of another generic method call on a Box<any> object
// (directly chained, or through a local), kept in a typed or inferred place. Box<any> objects only,
// no instanceof. HEAD and Node run it; snapshot 3 throws `Expected Box<number>, got Box<any>`.
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const a = new Box<any>(1);
const x = a.map((v) => v);
const y = x.map((v) => 5);
console.log("local", y.v);
const z = a.map((v) => [v]).map((v) => v.length);
console.log("chained", z.v);
