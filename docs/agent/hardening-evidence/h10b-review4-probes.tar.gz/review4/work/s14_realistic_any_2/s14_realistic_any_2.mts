// More realistic generic code used only for `any`: LinkedList<T> with map/filter (generic results), an Observable
// with unsubscribe closures, a Graph<T> with Map<T, T[]> adjacency and BFS, an LRU cache Map<K, V>
class LinkedList<T> {
  private head: { v: T; next: any } | null = null;
  private size = 0;
  push(v: T): this { this.head = { v, next: this.head }; this.size++; return this; }
  toArray(): T[] { const out: T[] = []; for (let n = this.head; n; n = n.next) out.unshift(n.v); return out; }
  map<R>(f: (v: T) => R): LinkedList<R> { const l = new LinkedList<R>(); for (const v of this.toArray()) l.push(f(v)); return l; }
  filter(p: (v: T) => boolean): LinkedList<T> { const l = new LinkedList<T>(); for (const v of this.toArray()) if (p(v)) l.push(v); return l; }
  get length(): number { return this.size; }
}
class Observable<T> {
  private subs: ((v: T) => void)[] = [];
  subscribe(f: (v: T) => void): () => void { this.subs.push(f); return () => { this.subs = this.subs.filter((s) => s !== f); }; }
  next(v: T): number { for (const s of this.subs) s(v); return this.subs.length; }
}
class Graph<T> {
  adj = new Map<T, T[]>();
  edge(a: T, b: T): void { (this.adj.get(a) ?? this.adj.set(a, []).get(a)!).push(b); if (!this.adj.has(b)) this.adj.set(b, []); }
  bfs(start: T): T[] { const seen = new Set<T>([start]); const q = [start]; const out: T[] = []; while (q.length) { const x = q.shift()!; out.push(x); for (const y of this.adj.get(x) ?? []) if (!seen.has(y)) { seen.add(y); q.push(y); } } return out; }
}
const list = new LinkedList<any>().push(1).push("two").push(3);
console.log("list", list.map((v) => typeof v).toArray(), list.filter((v) => typeof v === "number").length);
const obs = new Observable<any>();
const got: any[] = [];
const unsub = obs.subscribe((v) => got.push(v));
console.log("obs", obs.next("a"), (unsub(), obs.next("b")), got);
const g = new Graph<any>();
g.edge("a", 1); g.edge(1, true); g.edge("a", true);
console.log("bfs", g.bfs("a"));
const adjRows: any[][] = [...g.adj.values()];
adjRows[0].push("x");
console.log("adj", g.adj.get("a"));
