// Typed-context array literals of a Box<any> place's members (Box<any> and Box<number> objects): tuples, unions
// with undefined, readonly arrays, generic contexts, spreads inside, nested, as call arguments and returns
class Box<T> {
  items: T[] = [];
  matrix: T[][] = [[]];
  constructor(public v: T) {}
}
function generic<X>(xs: X[]): X[] { return xs; }
function takeRows(rows: any[][]): void { rows[0].push("arg"); }
function ret(b: Box<any>): any[][] { return [b.items]; }
function run(label: string, b: Box<any>): void {
  const out: string[] = [];
  const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).message.slice(0, 30)}`); } };
  t("tuple", () => { const p: [any[], number] = [b.items, 1]; p[0].push("tp"); });
  t("unionUndef", () => { const u: any[][] | undefined = [b.items]; u![0].push("uu"); });
  t("readonly", () => { const r: readonly any[][] = [b.items]; r[0].push("ro"); });
  t("generic", () => { generic([b.items])[0].push("g"); });
  t("spreadIn", () => { const s: any[][] = [...b.matrix, b.items]; s[1].push("sp"); s[0].push("sp0"); });
  t("nested", () => { const c: any[][][] = [[b.items], b.matrix]; c[0][0].push("n"); c[1][0].push("n1"); });
  t("arg", () => takeRows([b.items]));
  t("return", () => ret(b)[0].push("r"));
  t("objProp", () => { const o: { rows: any[][] } = { rows: [b.items] }; o.rows[0].push("o"); });
  t("mapProp", () => { const o: { rows: any[][] } = { rows: b.matrix.map((r) => r) }; o.rows[0].push("mp"); });
  t("inferred", () => { const i = [b.items]; i[0].push("i"); });
  console.log(label, out.join(" "));
  console.log(label, JSON.stringify([b.items, b.matrix]));
}
run("any", new Box<any>(0));
run("num", new Box<number>(0));
