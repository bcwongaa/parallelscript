// b.who.call(other) where b is a Box<any> object and other a Box<string> (base vs snapshot 3)
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  who(): string { return `${this.v}`; }
}
const b = new Box<any>("b");
const other = new Box<string>("o");
try { console.log(b.who.call(other)); } catch (e) { console.log("ERR", (e as Error).message); }
