// b.who.call(self) for Box<any> objects and subclasses of Box<any> (with and without an override): base vs snapshot 3
class Box<T> {
  constructor(public v: T) {}
  who(): string { return `box:${this.v}`; }
}
class L extends Box<any> {}
class O extends Box<any> { override who(): string { return `over:${this.v}`; } }
const t = (name: string, f: () => string) => { try { console.log(name, f()); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
const a = new Box<any>("a");
t("onL", () => a.who.call(new L("l")));
t("onO", () => a.who.call(new O("o")));
const l: Box<any> = new L("l2");
t("fromL", () => l.who.call(a));
const o: Box<any> = new O("o2");
t("fromO", () => o.who.call(a));
t("bindL", () => a.who.bind(new L("l3"))());
