// R2-F5's route for generic methods on C<any> values: chained calls, ?., element access, inherited/overridden
// generic methods, generic methods of subclasses of Box<any>, results kept in typed places. Box<any> objects
// (and one Labelled, a subclass of Box<any>) only.
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
  zip<U>(o: Box<U>): Box<[T, U]> { return new Box<[T, U]>([this.v, o.v]); }
  tag(): string { return "box"; }
}
class Labelled extends Box<any> {
  label = "L";
  override map<R>(f: (v: any) => R): Box<R> { return new Box(f(`${this.label}:${this.v}`)); }
  relabel<S>(s: S): Labelled { const l = new Labelled(this.v); l.label = String(s); return l; }
  override tag(): string { return "labelled"; }
}
class Sub<T> extends Box<T> {}
const a = new Box<any>(1);
const chained = a.map((v) => v + 1).map((v) => [v]).map((v) => v.length);
console.log("chain", chained.v);
const maybe: Box<any> | undefined = Math.random() < 2 ? a : undefined;
console.log("optional", maybe?.map((v) => v * 10).v);
console.log("element", a["map"]((v: any) => v + 2).v);
const l: Box<any> = new Labelled(5);
console.log("override", l.map((v) => `<${v}>`).v, l.tag());
const ll = new Labelled(6);
console.log("subclass generic", ll.relabel(7).label, ll.relabel("x").map((v) => v).v);
const s: Sub<any> = new Sub<any>(8);
console.log("inherited", s.map((v) => v + 1).v);
console.log("zip", JSON.stringify(a.zip(new Box<any>("z")).v));
const typed: Box<string> = a.map((v) => String(v));
console.log("typed", typed.v.length);
