// Box<any>-only programs (no instanceof): functions with any[] parameters given to, or stored in, a C<any> value,
// then compared by identity (on/off, indexOf, ===), as HEAD's typed Emitter<any> kept them
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  handler: ((rows: T[]) => void) | null = null;
  on(h: (rows: T[]) => void): void { this.handlers.push(h); }
  off(h: (rows: T[]) => void): boolean { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); return i >= 0; }
  emit(rows: T[]): void { for (const h of this.handlers) h(rows); }
}
function log(rows: any[]): void { rows.push("seen"); }
const e = new Emitter<any>();
e.on(log);
const rows: any[] = [];
e.emit(rows);
console.log("off", e.off(log), e.handlers.length, rows);
e.handlers.push(log);
console.log("indexOf", e.handlers.indexOf(log), e.handlers.includes(log));
e.handler = log;
console.log("stored", e.handler === log);
const other = new Emitter<any>();
other.on(log);
console.log("same", other.handlers[0] === e.handlers[0]);
