// More flows into the generic-method route holding Box<number>: unknown/any narrowing locals, a C<any> member of a
// narrowed value (`c.next`), a catch binding, a narrowed array element
class Box<T> {
  next: Box<T> | null = null;
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
function fromUnknown(u: unknown): void { if (u instanceof Box) t("unknownLocal", () => { const m = u; return m.map((v) => 1).v; }); }
function fromAny(a: any): void { if (a instanceof Box) t("anyLocal", () => { const m = a; return m.map((v: any) => 2).v; }); }
function fromObjectNext(o: object): void { if (o instanceof Box) t("nextMember", () => { const n = o.next!; return n.map((v) => 3).v; }); }
function fromCatch(): void { try { throw new Box<number>(4); } catch (e) { if (e instanceof Box) t("catchLocal", () => { const m = e; return m.map((v) => 4).v; }); } }
function fromArray(xs: object[]): void { const x = xs[0]; if (x instanceof Box) t("elementLocal", () => { const m = x; return m.map((v) => 5).v; }); }
const n = new Box<number>(0);
n.next = new Box<number>(9);
fromUnknown(n); fromAny(n); fromObjectNext(n); fromCatch(); fromArray([n]);
