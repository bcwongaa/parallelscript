// s04 split: each generic-method form on Box<any> objects in its own try
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
  zip<U>(o: Box<U>): Box<[T, U]> { return new Box<[T, U]>([this.v, o.v]); }
  tag(): string { return "box"; }
}
class Labelled extends Box<any> {
  label = "L";
  override map<R>(f: (v: any) => R): Box<R> { return new Box(f(`${this.label}:${this.v}`)); }
  relabel<S>(s: S): Labelled { const l = new Labelled(this.v); l.label = String(s); return l; }
  override tag(): string { return "labelled"; }
}
class Sub<T> extends Box<T> {}
const t = (name: string, f: () => any) => { try { console.log(name, f()); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
const a = new Box<any>(1);
t("map1", () => a.map((v) => v + 1).v);
t("mapArr", () => a.map((v) => [v]).v);
t("mapNum", () => { const m: Box<number> = a.map((v) => 7); return m.v; });
t("chain2", () => a.map((v) => v + 1).map((v) => [v]).v);
t("chain3", () => a.map((v) => v + 1).map((v) => [v]).map((v) => v.length).v);
const maybe: Box<any> | undefined = Math.random() < 2 ? a : undefined;
t("optional", () => maybe?.map((v) => v * 10).v);
t("element", () => a["map"]((v: any) => v + 2).v);
const l: Box<any> = new Labelled(5);
t("override", () => `${l.map((v) => `<${v}>`).v} ${l.tag()}`);
const ll = new Labelled(6);
t("relabel", () => `${ll.relabel(7).label} ${ll.relabel("x").map((v) => v).v}`);
const s: Sub<any> = new Sub<any>(8);
t("inherited", () => s.map((v) => v + 1).v);
t("zip", () => JSON.stringify(a.zip(new Box<any>("z")).v));
t("typed", () => { const typed: Box<string> = a.map((v) => String(v)); return typed.v.length; });
