// Generic methods called on a value that flowed out of an instanceof narrowing (const m = o / const m = s / ident(o))
// holding a Box<number>: base vs snapshot 3 vs snapshot 4
interface Shape { kind(): string; }
class Box<T> implements Shape {
  constructor(public v: T) {}
  kind(): string { return "box"; }
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
function ident<T>(t: T): T { return t; }
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
function fromObject(o: object): void {
  if (o instanceof Box) {
    t("objectFlow", () => { const m = o; return m.map((v) => 9).v; });
    t("objectIdent", () => ident(o).map((v) => 10).v);
  }
}
function fromShape(s: Shape): void {
  if (s instanceof Box) t("shapeFlow", () => { const m = s; return m.map((v) => 6).v; });
}
fromObject(new Box<number>(1));
fromShape(new Box<number>(1));
