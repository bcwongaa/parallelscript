// Box<any>-only: functions with defaults, optional, rest parameters, results, given by reference to a user
// method and to .then/.catch of a promise member of a C<any> value
class Box<T> {
  rows: T[][] = [[1 as any], [2 as any]];
  pending: Promise<T[]> = Promise.resolve([] as T[]);
  failing: Promise<T[]> = Promise.reject([] as T[]);
  run(f: (row: T[]) => void): void { for (const r of this.rows) f(r); }
  collect<R>(f: (row: T[]) => R): R[] { return this.rows.map((r) => f(r)); }
}
function withDefault(row: any[], tag = "d"): void { row.push(tag); }
function withOptional(row: any[], i?: number): void { row.push(i ?? -1); }
function withRest(...rs: any[][]): void { rs[0].push("rest"); }
function counting(row: any[]): number { return row.length; }
function onRows(rows: any[]): void { rows.push("then"); }
function onFail(rows: any[]): void { rows.push("catch"); }
const b = new Box<any>();
const out: string[] = [];
const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).message.slice(0, 50)}`); } };
t("default", () => b.run(withDefault));
t("optional", () => b.run(withOptional));
t("rest", () => b.run(withRest));
t("result", () => out.push(String(b.collect(counting))));
await b.pending.then(onRows);
await b.failing.catch(onFail);
console.log(out.join(" | "));
console.log(JSON.stringify(b.rows), JSON.stringify(await b.pending));
