// R2-F6's pts_dynamic_method_for: o.m.call/apply/bind(self) with self of the same instance, another instance
// (Box<number> vs Box<any>), a subclass without/with an override, a plain object, and o a subclass
class Box<T> {
  constructor(public v: T) {}
  who(): string { return `box:${this.v}`; }
  add(x: number): number { return Number(this.v) + x; }
}
class Plain extends Box<number> {}
class Over extends Box<number> { override who(): string { return `over:${this.v}`; } }
const t = (name: string, f: () => string) => { try { console.log(name, f()); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
const a: Box<any> = new Box<any>("a");
const n = new Box<number>(1);
t("anyOnNumber", () => a.who.call(n));
t("numberOnAny", () => { const p: Box<any> = n; return p.who.call(a); });
t("onPlainSub", () => a.who.call(new Plain(2)));
t("onOverride", () => a.who.call(new Over(3)));
t("subOnBase", () => { const o: Box<any> = new Over(4); return o.who.call(a); });
t("onLiteral", () => a.who.call({ v: "lit" } as any));
t("apply", () => String(a.add.apply(n, [5])));
t("bind", () => a.who.bind(n)());
t("viaAny", () => { const x: any = n; return x.who.call(a); });
