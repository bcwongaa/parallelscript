// R4: a generic method called on a local bound to an uninferred instanceof narrowing (`const m = o` for an
// `object` or a non-generic interface source, which H10a holds as a dynamic local) holding a Box<number>.
// HEAD and snapshot 3 run it as Node (9, 6); snapshot 4 routes it to the instance for any and throws
// `Expected Box<any>, got Box<number>`.
interface Shape { kind(): string; }
class Box<T> implements Shape {
  constructor(public v: T) {}
  kind(): string { return "box"; }
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
function fromObject(o: object): number {
  if (!(o instanceof Box)) return -1;
  const m = o;
  return m.map((v) => 9).v;
}
function fromShape(s: Shape): number {
  if (!(s instanceof Box)) return -1;
  const m = s;
  return m.map((v) => 6).v;
}
console.log(fromObject(new Box<number>(1)), fromShape(new Box<number>(1)));
