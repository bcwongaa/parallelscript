// Narrowed values in typed-context literals (must not copy silently) and spreads of narrowed unknowns' members
class Box<T> {
  items: T[] = [];
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
function ident<T>(t: T): T { return t; }
const t = (name: string, f: () => any) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
function viaIdent(o: object, n: Box<number>): void {
  if (o instanceof Box) t("identLiteral", () => { const rows: any[][] = [ident(o).items]; rows[0].push(1); return n.items; });
}
function viaUnknown(u: unknown, n: Box<number>): void {
  if (u instanceof Box) t("unknownSpread", () => { const m = { ...u.meta }; m.tags.push(2); return [Object.keys(m), n.meta.tags]; });
}
const n = new Box<number>(0);
viaIdent(n, n);
viaUnknown(n, n);
