// R3: a function with a default, an optional or a rest parameter (and an any[] parameter) given by reference
// to a Box<any> object's method (no instanceof): HEAD and Node run it; snapshot 3 is PTS1001 naming an
// instanceof narrowing (asIsAdapter gives up on defaults and rests, any_instances.go).
class Box<T> {
  rows: T[][] = [[1 as any], [2 as any]];
  run(f: (row: T[]) => void): void { for (const r of this.rows) f(r); }
}
function withDefault(row: any[], tag = "d"): void { row.push(tag); }
function withOptional(row: any[], i?: number): void { row.push(i ?? -1); }
function withRest(...rs: any[][]): void { rs[0].push("rest"); }
const b = new Box<any>();
b.run(withDefault);
b.run(withOptional);
b.run(withRest);
console.log(JSON.stringify(b.rows));
