// Spreads of a Box<any> object's members of object types (no instanceof): a class instance with a getter and a
// method, an optional property absent at run time, an object literal with a method, a hash map
class Inner { a = 1; get size(): number { return 2; } method(): number { return 3; } }
class Box<T> {
  inner = new Inner();
  meta: { name: string; opt?: number } = { name: "m" };
  rec: Record<string, T> = { r: 1 as any };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const s1 = { ...b.inner };
console.log("inner", JSON.stringify(s1), Object.keys(s1).join(","));
const s2 = { ...b.meta };
console.log("meta", JSON.stringify(s2), Object.keys(s2).join(","), "opt" in s2);
const s5: Record<string, any> = { ...b.rec, extra: 2 };
console.log("rec", JSON.stringify(s5));
