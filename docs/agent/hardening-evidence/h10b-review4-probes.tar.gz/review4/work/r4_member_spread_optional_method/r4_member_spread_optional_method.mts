// R4: spreads of a Box<any> object's members (no instanceof). (1) a member whose type has an optional property
// absent at run time: snapshot 4 adds the key (`Object.keys` "name,opt", `"opt" in` true), where HEAD and Node
// don't. (2) a member whose type has a method: PTS1001 "an object literal whose spreads don't give every
// property", where HEAD and Node copy it.
class Box<T> {
  meta: { name: string; opt?: number } = { name: "m" };
  lit: { f(): number; x: number } = { f() { return 4; }, x: 5 };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const s2 = { ...b.meta };
console.log("meta", Object.keys(s2).join(","), "opt" in s2);
const s3 = { ...b.lit };
console.log("lit", Object.keys(s3).join(","), s3.f());
