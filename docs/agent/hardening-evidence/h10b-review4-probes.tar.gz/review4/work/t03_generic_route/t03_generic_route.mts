// The restricted generic-method route: parameters, locals, fields, array elements, flows out of narrowings,
// narrowings themselves (object / unknown / any), for Box<any> objects and Box<number> objects
interface Shape { kind(): string; }
class Box<T> implements Shape {
  constructor(public v: T) {}
  kind(): string { return "box"; }
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
class Holder { slot: Box<any>; constructor(b: Box<any>) { this.slot = b; } }
function ident<T>(t: T): T { return t; }
const out: string[] = [];
const t = (name: string, f: () => any) => { try { out.push(`${name}=${JSON.stringify(f())}`); } catch (e) { out.push(`${name}=ERR(${(e as Error).message.slice(0, 36)})`); } };
function run(label: string, b: Box<any>): void {
  out.length = 0;
  t("param", () => b.map((v) => [v]).v);
  t("local", () => { const l = b; const m = l.map((v) => 1); return m.v; });
  t("field", () => new Holder(b).slot.map((v) => 2).v);
  t("element", () => [b][0].map((v) => 3).v);
  t("chainLocal", () => { const m = b.map((v) => v); const n = m.map((v) => 4); return n.v; });
  console.log(label, out.join(" "));
}
function narrowed(label: string, s: Shape, o: object, u: unknown, a: any): void {
  out.length = 0;
  if (s instanceof Box) { t("iface", () => s.map((v) => 5).v); t("ifaceFlow", () => { const m = s; return m.map((v) => 6).v; }); t("ifaceIdent", () => ident(s).map((v) => 7).v); }
  if (o instanceof Box) { t("object", () => o.map((v) => 8).v); t("objectFlow", () => { const m = o; return m.map((v) => 9).v; }); }
  if (u instanceof Box) t("unknown", () => u.map((v) => 10).v);
  if (a instanceof Box) t("any", () => a.map((v: any) => 11).v);
  console.log(label, out.join(" "));
}
run("anyObj", new Box<any>(0));
run("numObj", new Box<number>(0));
const n = new Box<number>(0);
narrowed("narrowNum", n, n, n, n);
const ab = new Box<any>(0);
narrowed("narrowAny", ab, ab, ab, ab);
