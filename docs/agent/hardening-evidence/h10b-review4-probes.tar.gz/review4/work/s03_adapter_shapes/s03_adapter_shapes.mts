// Box<any>-only: functions given by reference with defaults, optional, rest parameters and `this`-free arrows,
// and functions returning values, to array methods and user methods of a C<any> value's members
class Box<T> {
  rows: T[][] = [[1 as any], [2 as any]];
  each(f: (row: T[], i: number) => void): void { this.rows.forEach(f); }
  mapRows<R>(f: (row: T[]) => R): R[] { return this.rows.map(f); }
}
function withDefault(row: any[], i: number, tag = "d"): void { row.push(tag); }
function withOptional(row: any[], i?: number): void { row.push(i ?? -1); }
function withRest(row: any[], ...more: number[]): void { row.push("rest"); }
function counting(row: any[]): number { return row.length; }
const b = new Box<any>();
const out: string[] = [];
const t = (name: string, f: () => void) => { try { f(); out.push(`${name}:ok`); } catch (e) { out.push(`${name}:${(e as Error).message.slice(0, 50)}`); } };
t("default", () => b.rows.forEach(withDefault));
t("optional", () => b.each(withOptional));
t("rest", () => b.rows.forEach(withRest));
t("result", () => { console.log("lens", b.mapRows(counting), b.rows.map(counting)); });
t("reduce", () => { console.log("reduce", b.rows.reduce((acc: number, r: any[]) => acc + r.length, 0)); });
console.log(out.join(" | "));
console.log(JSON.stringify(b.rows));
