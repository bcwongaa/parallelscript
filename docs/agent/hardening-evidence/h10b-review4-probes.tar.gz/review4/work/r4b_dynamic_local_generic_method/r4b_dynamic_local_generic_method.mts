// R4: generic methods on H10a's dynamic locals holding a Box<number>: `const n = o.next!` (a C<any> member of an
// uninferred narrowing) and `const m = x` after `x instanceof Box` for an array element. HEAD and snapshot 3
// print 3 5; snapshot 4 throws `Expected Box<any>, got Box<number>`.
class Box<T> {
  next: Box<T> | null = null;
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
function fromObjectNext(o: object): number { if (!(o instanceof Box)) return -1; const n = o.next!; return n.map((v) => 3).v; }
function fromArray(xs: object[]): number { const x = xs[0]; if (!(x instanceof Box)) return -1; const m = x; return m.map((v) => 5).v; }
const n = new Box<number>(0);
n.next = new Box<number>(9);
console.log(fromObjectNext(n), fromArray([n]));
