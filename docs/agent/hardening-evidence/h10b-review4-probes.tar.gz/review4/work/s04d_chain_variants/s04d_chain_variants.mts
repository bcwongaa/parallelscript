// Which link of a generic-method chain on a Box<any> object loses its instance (Box<any> objects only)
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const a = new Box<any>(1);
const t = (name: string, f: () => any) => { try { console.log(name, f()); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
t("c2", () => { const c2 = a.map((v) => v + 1).map((v) => [v]); return c2.v; });
t("c3", () => { const c3 = a.map((v) => [v]).map((v) => v.length); return c3.v; });
t("c4", () => { const c4 = a.map((v) => v).map((v) => 5); return c4.v; });
t("c5", () => { const x = a.map((v) => v); const c5 = x.map((v) => 5); return c5.v; });
t("c6", () => { const c6: Box<number> = a.map((v) => 5); return c6.v; });
t("c7", () => { const c7 = a.map((v) => [v]).map((v) => [v]); return JSON.stringify(c7.v); });
