// Typed-context literals whose element type is typed (number[][]) holding a Box<any> object's any[] members
class Box<T> {
  items: T[] = [];
  constructor(public v: T) { this.items.push(v); }
}
const b = new Box<any>(1);
const t = (name: string, f: () => string) => { try { console.log(name, f()); } catch (e) { console.log(name, "ERR", (e as Error).message); } };
t("numberRows", () => { const rows: number[][] = [b.items]; rows[0].push(2); return `${JSON.stringify(rows)} ${JSON.stringify(b.items)}`; });
t("direct", () => { const xs: number[] = b.items; xs.push(3); return `${JSON.stringify(xs)} ${JSON.stringify(b.items)}`; });
t("tupleTyped", () => { const p: [number[], string] = [b.items, "s"]; p[0].push(4); return `${JSON.stringify(p)} ${JSON.stringify(b.items)}`; });
