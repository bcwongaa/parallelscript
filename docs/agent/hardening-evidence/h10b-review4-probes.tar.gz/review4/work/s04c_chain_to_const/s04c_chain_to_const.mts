// A chain of generic methods on a Box<any> object kept in a const (Box<any> objects only)
class Box<T> {
  constructor(public v: T) {}
  map<R>(f: (v: T) => R): Box<R> { return new Box(f(this.v)); }
}
const a = new Box<any>(1);
const one = a.map((v) => v + 1);
console.log("one", one.v);
const two = a.map((v) => [v]);
console.log("two", two.v);
const chained = a.map((v) => v + 1).map((v) => [v]).map((v) => v.length);
console.log("chain", chained.v);
