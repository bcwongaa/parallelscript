// Function identity through C<any> roots of several kinds: on(f) then off(f) must remove it (Node: every line "0")
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): void { this.handlers.push(h); }
  off(h: (rows: T[]) => void): void { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); }
}
class SubEmitter extends Emitter<any> { tag = "sub"; }
class GSub<U> extends Emitter<U> {}
class Holder {
  bus: Emitter<any> = new Emitter<any>();
  get viaGetter(): Emitter<any> { return this.bus; }
  wire(f: (rows: any[]) => void): number { this.bus.on(f); this.bus.off(f); return this.bus.handlers.length; }
}
function log(rows: any[]): void { rows.push(1); }
const e = new Emitter<any>();
const holder = new Holder();
const buses: Emitter<any>[] = [new Emitter<any>()];
const maybe: Emitter<any> | undefined = Math.random() < 2 ? new Emitter<any>() : undefined;
const orNull: Emitter<any> | null = Math.random() < 2 ? new Emitter<any>() : null;
const sub: Emitter<any> = new SubEmitter();
const gsubAny: Emitter<any> = new GSub<any>();
const getBus = () => e;
const r: string[] = [];
const t = (name: string, f: () => number) => { try { r.push(`${name}=${f()}`); } catch (er) { r.push(`${name}=ERR ${(er as Error).message.slice(0, 40)}`); } };
t("local", () => { e.on(log); e.off(log); return e.handlers.length; });
t("field", () => { holder.bus.on(log); holder.bus.off(log); return holder.bus.handlers.length; });
t("getter", () => { holder.viaGetter.on(log); holder.viaGetter.off(log); return holder.bus.handlers.length; });
t("call", () => { getBus().on(log); getBus().off(log); return e.handlers.length; });
t("element", () => { buses[0].on(log); buses[0].off(log); return buses[0].handlers.length; });
t("optional", () => { maybe?.on(log); maybe?.off(log); return maybe!.handlers.length; });
t("orNull", () => { orNull!.on(log); orNull!.off(log); return orNull!.handlers.length; });
t("thisRoot", () => holder.wire(log));
t("subclass", () => { sub.on(log); sub.off(log); return sub.handlers.length; });
t("genericSubAny", () => { gsubAny.on(log); gsubAny.off(log); return gsubAny.handlers.length; });
t("param", () => { const g = (b: Emitter<any>) => { b.on(log); b.off(log); return b.handlers.length; }; return g(new Emitter<any>()); });
console.log(r.join(" "));
