// R4: identity of a function given to a C<any> value's method is still lost when the C<any> value is reached
// through a field (holder.bus, this.bus), an array element, a getter or a call: off(f) removes nothing.
// Emitter<any> objects only, no instanceof. HEAD and Node print 0 0 0 0 0.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): void { this.handlers.push(h); }
  off(h: (rows: T[]) => void): void { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); }
}
class Service {
  bus: Emitter<any> = new Emitter<any>();
  get viaGetter(): Emitter<any> { return this.bus; }
  attach(f: (rows: any[]) => void): void { this.bus.on(f); }
  detach(f: (rows: any[]) => void): void { this.bus.off(f); }
}
function log(rows: any[]): void { rows.push(1); }
const svc = new Service();
svc.bus.on(log); svc.bus.off(log);
const a = svc.bus.handlers.length;
svc.attach(log); svc.detach(log);
const b = svc.bus.handlers.length;
const buses: Emitter<any>[] = [new Emitter<any>()];
buses[0].on(log); buses[0].off(log);
const busOf = () => buses[0];
busOf().on(log); busOf().off(log);
const s2 = new Service();
s2.viaGetter.on(log); s2.viaGetter.off(log);
console.log(a, b, buses[0].handlers.length - 0, busOf().handlers.length, s2.bus.handlers.length);
