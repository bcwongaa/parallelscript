// An Emitter<number> held in an Emitter<any> place: on(f)/off(f) with f(rows: any[]) (Node: 0 0)
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  on(h: (rows: T[]) => void): void { this.handlers.push(h); }
  off(h: (rows: T[]) => void): void { const i = this.handlers.indexOf(h); if (i >= 0) this.handlers.splice(i, 1); }
  emit(rows: T[]): void { for (const h of this.handlers) h(rows); }
}
function log(rows: any[]): void { rows.push(1); }
const n = new Emitter<number>();
const place: Emitter<any> = n;
place.on(log);
place.off(log);
console.log("other instance", n.handlers.length);
place.on(log);
try { n.emit([5]); console.log("emitted"); } catch (e) { console.log("emit ERR", (e as Error).message); }
