// Spreads of dynamic values of object types (R3-F4): Box<any> members holding class instances with getters,
// optional properties absent at run time, extra properties, object-literal methods; narrowed unknowns
class Inner { a = 1; get size(): number { return 2; } method(): number { return 3; } }
class Box<T> {
  inner = new Inner();
  meta: { name: string; opt?: number } = { name: "m" };
  lit: { f(): number; x: number } = { f() { return 4; }, x: 5 };
  wide: { k: number } = { k: 6, extra: 7 } as { k: number };
  rec: Record<string, T> = { r: 1 as any };
  constructor(public v: T) {}
const b = new Box<any>(0);
const s1 = { ...b.inner };
console.log("inner", JSON.stringify(s1), Object.keys(s1).join(","));
const s2 = { ...b.meta };
console.log("meta", JSON.stringify(s2), Object.keys(s2).join(","), "opt" in s2);
const s4 = { ...b.wide };
console.log("wide", JSON.stringify(s4));
const s5: Record<string, any> = { ...b.rec, extra: 2 };
console.log("rec", JSON.stringify(s5));
