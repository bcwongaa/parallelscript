// R4: an object spread of a dynamic member of object type copies that member's arrays where the object is
// another instance: `{ ...b.meta }` for a Box<any> place holding a Box<number>, and `{ ...u.meta }` for an
// `unknown` narrowed to Box. Node shares meta.tags (prints [2,3]); snapshot 4 loses both pushes silently.
// HEAD and snapshot 3: PTS1001 (`spreading a value into an object`; `using a Box as a Box`).
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
}
function viaPlace(b: Box<any>): void { const m = { ...b.meta }; m.tags.push(2); }
function viaUnknown(u: unknown): void { if (u instanceof Box) { const m = { ...u.meta }; m.tags.push(3); } }
const n = new Box<number>(0);
viaPlace(n);
viaUnknown(n);
console.log(JSON.stringify(n.meta.tags));
