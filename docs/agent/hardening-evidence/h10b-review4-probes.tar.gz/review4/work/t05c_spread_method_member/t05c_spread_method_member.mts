// A spread of a Box<any> object's member whose type has a method (an object literal with a method), no instanceof
class Box<T> {
  lit: { f(): number; x: number } = { f() { return 4; }, x: 5 };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const s3 = { ...b.lit };
console.log("lit", Object.keys(s3).join(","), s3.f(), s3.x);
