#!/bin/bash
# census1.sh file.pts: emit snap8's C into census/c and print "name status raw parsed bad"
R=/tmp/h09b1-review6
f=$1; n=$(echo "$f" | sed 's#^/tmp/h09b/snap8/pts/tests/##; s#^/tmp/h09b1-review6/##; s#/#__#g; s#\.pts$##'); c=$R/census/c/$n.c
PTS_CACHE_DIR=$R/cache-snap8 PTS_HOME=/tmp/h09b/snap8 timeout 120 $R/pts-snap8 emit-c "$f" -o "$c" > /dev/null 2>&1; st=$?
if [ -f "$c" ]; then
  raw=$(grep -o '== NULL || ((const pts_object \*)' "$c" | wc -l)
  parsed=$(grep -o '([A-Za-z_][A-Za-z_0-9]* == NULL || ((const pts_object \*)[A-Za-z_][A-Za-z_0-9]*)->type->element\|(0 == NULL || ((const pts_object \*)0)->type->element' "$c" | wc -l)
  mism=$(grep -o '(\([A-Za-z_][A-Za-z_0-9]*\) == NULL || ((const pts_object \*)\([A-Za-z_][A-Za-z_0-9]*\))->type->element' "$c" | sed -E 's/^\(([^ ]*) == NULL \|\| \(\(const pts_object \*\)([^)]*)\).*/\1 \2/' | awk '$1 != $2' | wc -l)
  old=$(grep -c '->type->element == PTS_FIELD' "$c")
  [ $raw -gt 0 ] || rm -f "$c"
else raw=-; parsed=-; mism=-; old=-; fi
echo "$n $st $raw $parsed $mism"
