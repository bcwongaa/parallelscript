"""compare_rerun.py: compare snap8's outputs with round 5's recorded base / snap7 / Node blocks.

For each probe: whole-output equality snap8 vs snap7 vs base vs node, and each line index
where base or snap7 equals Node but snap8 doesn't (a regression candidate).
"""
import os, re, sys

R5 = "/tmp/h09b1-review6/r5/round5/outputs"
OUT = "/tmp/h09b1-review6/outputs/rerun"


def blocks(path):
    text = open(path).read().splitlines()
    cur, res = None, {}
    for line in text:
        m = re.match(r"^-- (base|snap|snap7|node)$", line)
        if m:
            cur = m.group(1)
            if cur == "snap":
                cur = "snap7"
            res[cur] = []
            continue
        if line.startswith("== "):
            cur = None
            continue
        if cur:
            res[cur].append(line)
    return res


def norm(lines):
    # paths differ between the rounds' probe locations
    return [re.sub(r"/tmp/[^ :]*/([^/ :]+\.pts)", r"\1", l) for l in lines]


summary = []
regressions = 0
for name in sorted(os.listdir(OUT)):
    if not name.endswith(".snap8.txt"):
        continue
    probe = name[: -len(".snap8.txt")]
    rec = os.path.join(R5, "re_" + probe + ".txt")
    if not os.path.exists(rec):
        rec = os.path.join(R5, probe + ".txt")
    if not os.path.exists(rec):
        summary.append(f"{probe}: NO RECORD")
        continue
    b = blocks(rec)
    s8 = norm(open(os.path.join(OUT, name)).read().splitlines())
    base, s7, node = norm(b.get("base", [])), norm(b.get("snap7", [])), norm(b.get("node", []))
    tags = []
    tags.append("s8=s7" if s8 == s7 else "s8!=s7")
    tags.append("s8=node" if s8 == node else "s8!=node")
    tags.append("s8=base" if s8 == base else "s8!=base")
    bad = []
    for i in range(max(len(base), len(s7), len(node), len(s8))):
        n = node[i] if i < len(node) else None
        x = s8[i] if i < len(s8) else None
        bb = base[i] if i < len(base) else None
        ss = s7[i] if i < len(s7) else None
        if n is not None and (bb == n or ss == n) and x != n:
            bad.append(f"    line {i+1}: node={n!r} base={bb!r} snap7={ss!r} snap8={x!r}")
    regressions += len(bad)
    summary.append(f"{probe}: {' '.join(tags)}" + (f"  REGRESSION CANDIDATES {len(bad)}" if bad else ""))
    summary.extend(bad)
    if s8 != s7:
        summary.append("    snap7 vs snap8 differ:")
        for i in range(max(len(s7), len(s8))):
            a = s7[i] if i < len(s7) else None
            c = s8[i] if i < len(s8) else None
            if a != c:
                summary.append(f"      line {i+1}: snap7={a!r} snap8={c!r} node={(node[i] if i < len(node) else None)!r}")
print("\n".join(summary))
print(f"TOTAL lines where base or snap7 = Node but snap8 differs: {regressions}")
