"""matrix_compare.py: compare the H09 matrix verdicts of snap8 with snap7's (round 5) and print the counts."""
import collections, json
s7 = json.load(open("/tmp/h09b1-review6/r5/round5/outputs/results-full-snap7.json"))
s8 = json.load(open("/tmp/h09b1-review6/outputs/results-full-snap8.json"))
print("snap7", dict(collections.Counter(v["verdict"] for v in s7.values())))
print("snap8", dict(collections.Counter(v["verdict"] for v in s8.values())))
moved = [(k, s7[k]["verdict"], s8.get(k, {}).get("verdict")) for k in sorted(s7) if s7[k]["verdict"] != s8.get(k, {}).get("verdict")]
print("verdict changes snap7 -> snap8:", len(moved))
for m in moved:
    print("  ", *m)
out = [k for k in sorted(s7) if k in s8 and s7[k].get("pts") != s8[k].get("pts")]
print("cases whose PTS stdout differs:", len(out))
for k in out[:20]:
    print("  ", k)
