"""H09 matrix runner: builds and runs each case with PTS and with Node (an .mts copy), and
classifies it.

Usage: python3 -I run.py CASEDIR RESULTS.json [jobs]
Environment: PTS_HOME (the tree whose CLI and runtime to use), PTS_CLI (default
$PTS_HOME/pts-bin/pts), NODE (default ~/.local/node/bin/node).

Verdicts per case: OK (same stdout and exit code as Node), TYPEERR (a TypeError
`Expected X, got Y` where Node printed a value), WRONG (another difference), DIAG (a
PTS1xxx compile error), TSERR (a tsc error: a generator bug), ICE (PTS9001 or exit code 3),
CRASH (a signal or a runtime abort), NODEERR (Node itself failed: a generator bug).
"""
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

HOME = os.environ["PTS_HOME"]
CLI = os.environ.get("PTS_CLI", os.path.join(HOME, "pts-bin", "pts"))
NODE = os.environ.get("NODE", os.path.expanduser("~/.local/node/bin/node"))


def run(cmd, cwd, env=None, timeout=120):
    try:
        r = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -999, "", "TIMEOUT"


def one(path):
    name = os.path.basename(path)[:-4]
    d = tempfile.mkdtemp(prefix="h09m.", dir="/tmp/h09b1-review6/matrix/tmp")
    try:
        mts = os.path.join(d, name + ".mts")
        shutil.copy(path, mts)
        env = dict(os.environ, PTS_HOME=HOME, TZ="America/New_York")
        pcode, pout, perr = run([CLI, "run", path], d, env)
        ncode, nout, nerr = run([NODE, "--no-warnings", "--experimental-transform-types", mts], d, dict(os.environ, TZ="America/New_York"))
    finally:
        shutil.rmtree(d, ignore_errors=True)
    both = pout + perr
    if ncode != 0:
        verdict = "NODEERR"
    elif re.search(r"error TS\d+", both):
        verdict = "TSERR"
    elif "PTS9001" in both or pcode == 3:
        verdict = "ICE"
    elif re.search(r"error PTS1\d\d\d", both):
        verdict = "DIAG"
    elif pcode < 0 or pcode >= 128 or pcode == -999:
        verdict = "CRASH"
    elif pcode == ncode and pout == nout:
        verdict = "OK"
    elif re.search(r"TypeError,? Expected .*, got ", pout + perr) or "TypeError: Expected" in perr:
        verdict = "TYPEERR"
    else:
        verdict = "WRONG"
    lines = {}
    if verdict in ("OK", "TYPEERR", "WRONG"):
        nl = {l.split(" ", 1)[0]: l for l in nout.splitlines()}
        for l in pout.splitlines():
            label = l.split(" ", 1)[0]
            if label in nl:
                if l == nl[label]:
                    lines[label] = "OK"
                elif re.search(r"TypeError Expected .*, got ", l):
                    lines[label] = "TYPEERR"
                else:
                    lines[label] = "WRONG"
    diag = ""
    m = re.search(r"error (PTS\d+|TS\d+): ([^\n]*)", both)
    if m:
        diag = m.group(1) + ": " + m.group(2)[:300]
    elif verdict in ("CRASH", "ICE"):
        diag = both[-600:]
    return name, dict(verdict=verdict, pts_exit=pcode, node_exit=ncode, pts=pout[-3000:], pts_err=perr[-1500:], node=nout[-3000:],
                      node_err=nerr[-800:] if ncode else "", lines=lines, diag=diag)


def main():
    casedir, results = sys.argv[1], sys.argv[2]
    jobs = int(sys.argv[3]) if len(sys.argv) > 3 else 2
    paths = sorted(os.path.join(casedir, f) for f in os.listdir(casedir) if f.endswith(".pts"))
    out = {}
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for name, r in pool.map(one, paths):
            out[name] = r
            print(r["verdict"], name, r["diag"][:160], flush=True)
    with open(results + ".tmp", "w") as f:
        json.dump(out, f, indent=1, sort_keys=True)
    os.replace(results + ".tmp", results)


if __name__ == "__main__":
    main()
