#!/bin/bash
# snaponly.sh out_dir file.pts: run the program with snap8's CLI (as cmp3.sh does) into out_dir/NAME.snap8.txt
R=/tmp/h09b1-review6
out=$1; f=$(realpath "$2"); b=$(basename "$f" .pts); d=$(mktemp -d $R/tmp/so.XXXX)
(cd "$d" && TZ=America/New_York PTS_CACHE_DIR=$R/cache-snap8 PTS_HOME=/tmp/h09b/snap8 timeout 300 $R/pts-snap8 run "$f" 2>&1; echo "[exit $?]") > "$out/$b.snap8.txt"
rm -rf "$d"
