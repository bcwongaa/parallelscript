#!/bin/bash
# guards.sh file.pts: emit snap8's C and list every array guard's operand; flag any operand
# that is not a C identifier or the constant 0.
R=/tmp/h09b1-review6
f=$1; c=$R/tmp/$(basename "$f" .pts).snap8.c
PTS_CACHE_DIR=$R/cache-snap8 PTS_HOME=/tmp/h09b/snap8 $R/pts-snap8 emit-c "$f" -o "$c" || { echo "emit-c failed"; exit 1; }
n=$(grep -o '([^()]* == NULL || ((const pts_object \*)[^)]*)->type->element == PTS_FIELD_[A-Z_0-9]*)' "$c" | wc -l)
echo "guards: $n"
grep -o '(\([^()]*\) == NULL || ((const pts_object \*)\([^)]*\))->type->element' "$c" | sed -E 's/^\(([^()]*) == NULL \|\| \(\(const pts_object \*\)([^)]*)\)->type->element$/\1 \2/' | sort | uniq -c | awk '{bad = ($2 !~ /^([A-Za-z_][A-Za-z_0-9]*|0)$/ || $2 != $3) ? " <-- NOT A LOCAL/CONSTANT OR MISMATCH" : ""; print "  " $1 "x " $2 " / " $3 bad}'
# any guard text whose operand contains a paren or an operator
grep -o '([^ ]*[(+*-][^ ]* == NULL || ((const pts_object' "$c" | head -5
