interface J { x: number }
class C {
  x = 1;
  twice(): J[] { return [1, 2].flatMap<J>(() => [this]); }
  self(): C[] { return [1].flatMap(() => [this, this]); }
}
const c = new C();
console.log(c.twice().length, c.self().length, c.self()[1] === c);
