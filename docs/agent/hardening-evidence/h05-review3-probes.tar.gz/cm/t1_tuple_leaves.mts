const pairs: [number, string][] = [[1, "a"], [2, "b"]];
const r = [1].flatMap<(number | string)[]>(() => pairs);
console.log(r.length, r[1]);
