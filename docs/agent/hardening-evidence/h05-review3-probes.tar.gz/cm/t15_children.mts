class Node1 { children: Node1[] = []; constructor(public id: number) {} }
const root = new Node1(0);
root.children.push(new Node1(1), new Node1(2));
root.children[0].children.push(new Node1(3));
const level1 = [root].flatMap((n) => n.children);
const level2 = level1.flatMap((n) => n.children);
console.log(level1.map((n) => n.id), level2.map((n) => n.id), level1[0] === root.children[0]);
