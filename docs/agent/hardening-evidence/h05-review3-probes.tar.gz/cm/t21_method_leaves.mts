interface Shape { area(): number; name: string; scale(k: number): number }
class Sq { constructor(public name: string, public s: number) {} area() { return this.s * this.s; } scale() { return 2; } }
class Ci { constructor(public name: string, public r: number) {} area() { return 3 * this.r * this.r; } scale(k: number) { return k; } }
const sq = new Sq("sq", 2), ci = new Ci("ci", 1);
const r = [1].flatMap<Shape>(() => [sq, ci]);
console.log(r.map((s) => s.name + s.area() + s.scale(5)).join(" "), (r[0] as any) === (sq as any));
const shapes: Shape[] = [sq, ci];
const r2 = [1, 2].flatMap((i) => shapes);
console.log(r2.length, r2[2] === shapes[0]);
interface Named { readonly label: string }
class G { get label() { return "g"; } }
const g = new G();
const r3 = [1].flatMap<Named>(() => [g]);
console.log(r3[0].label, (r3[0] as any) === (g as any));
