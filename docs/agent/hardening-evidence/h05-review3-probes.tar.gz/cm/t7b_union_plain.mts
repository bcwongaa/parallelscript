interface Pet { name: string }
class Dog { constructor(public name: string) {} bark() { return 1; } }
class Bird { constructor(public name: string) {} sing() { return 2; } }
const pets: (Dog | Bird)[] = [new Dog("d"), new Bird("b")];
const p: Pet = pets[0];
console.log(p.name);
const r = pets.map<Pet>((x) => x);
console.log(r.length);
