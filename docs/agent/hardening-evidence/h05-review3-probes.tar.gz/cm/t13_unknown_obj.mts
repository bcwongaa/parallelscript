class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<unknown>(() => [c, 1, "s", [2]]);
console.log(r.length, r[0] === c);
const s = [1].flatMap<object>(() => [c, [3]]);
console.log(s.length, s[0] === c);
