interface Pet { name: string }
class Dog { constructor(public name: string) {} bark() { return 1; } }
class Bird { constructor(public name: string) {} sing() { return 2; } }
const dog = new Dog("d"), bird = new Bird("b");
const r = [1, 2].flatMap<Pet>((x) => [x > 1 ? dog : bird]);
console.log(r.map((p) => p.name).join(","));
const s = [1, 2].flatMap((x): Pet[] => [x > 1 ? dog : bird, dog]);
console.log(s.map((p) => p.name).join(","));
