interface J { x: number }
class C { constructor(public x: number, public y: string) {} }
const cs = [new C(1, "a"), new C(2, "b")];
const r = [1].flatMap<J>(() => cs);
const r2 = [1].flatMap<J>(() => [cs[1]]);
console.log(r.length, (r[0] as any) === (cs[0] as any), (r2[0] as any) === (cs[1] as any), r[1].x);
