interface Pet { name: string }
class Dog { constructor(public name: string) {} bark() { return 1; } }
class Bird { constructor(public name: string) {} sing() { return 2; } }
const pets: (Dog | Bird)[] = [new Dog("d"), new Bird("b")];
const r = [1, 2].flatMap<Pet>(() => pets);
console.log(r.length, r.map((p) => p.name).join(","));
