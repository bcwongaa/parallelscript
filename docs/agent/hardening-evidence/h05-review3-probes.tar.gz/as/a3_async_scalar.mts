const ps = [1, 2].flatMap(async (x) => x * 10);
console.log(await Promise.all(ps));
