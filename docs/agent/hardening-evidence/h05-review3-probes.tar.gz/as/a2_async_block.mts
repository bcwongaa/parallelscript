class C { constructor(public x: number) {} }
const ps = [1, 2].flatMap(async (x) => {
  if (x > 1) return [new C(x)];
  return [];
});
const rs = await Promise.all(ps);
console.log(rs.length, rs[0].length, rs[1][0].x);
