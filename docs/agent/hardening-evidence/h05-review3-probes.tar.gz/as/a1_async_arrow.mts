const ps = [1, 2].flatMap(async (x) => [x, x]);
const rs = await Promise.all(ps);
console.log(rs);
