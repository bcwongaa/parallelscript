const xs: (number | number[])[] = [1, [2, 3]];
console.log(xs.flat());
