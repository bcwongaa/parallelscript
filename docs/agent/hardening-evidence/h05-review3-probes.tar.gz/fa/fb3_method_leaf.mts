interface Handler { handle(e: string): void }
type Cb = (e: string) => number;
const g = () => 1;
const cbs: (() => number)[] = [g];
const r = [1, 2].flatMap((): Cb[] => cbs);
console.log(r.length, r[0]("e"));
