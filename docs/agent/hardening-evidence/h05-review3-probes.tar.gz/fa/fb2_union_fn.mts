type Item = string | ((n: number) => string);
const f = (): string => "f";
const r = [1].flatMap<Item>(() => ["a", f]);
for (const x of r) console.log(typeof x === "string" ? x : x(1));
