const f = (): number => 7;
const r = [1].flatMap<(a: number) => number>(() => [f]);
console.log(r.length, r[0](5));
