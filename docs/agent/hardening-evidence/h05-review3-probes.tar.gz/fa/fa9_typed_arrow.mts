const r = [1].flatMap<(a: number) => number>((x) => [(a: number) => a + x]);
console.log(r.length, r[0](10));
