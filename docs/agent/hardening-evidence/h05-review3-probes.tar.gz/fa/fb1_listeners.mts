type Listener = (e: string) => void;
class Button {
  constructor(public name: string) {}
  onClick = () => console.log(this.name, "click");
  onHover = (e: string) => console.log(this.name, "hover", e);
}
const buttons = [new Button("ok"), new Button("cancel")];
const listeners = buttons.flatMap((b): Listener[] => [b.onClick, b.onHover]);
for (const l of listeners) l("evt");
