const fs: (() => number)[] = [() => 42];
const r = [1].flatMap<() => number | string>(() => fs);
const v = r[0]();
console.log(typeof v, v);
