const fs: ((() => number) | (() => number)[])[] = [() => 1, [() => 2]];
const r = fs.flat();
console.log(r.length, r[1]());
