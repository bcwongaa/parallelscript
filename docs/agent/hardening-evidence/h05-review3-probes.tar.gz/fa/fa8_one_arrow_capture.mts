const r = [1].flatMap<(a: number) => number>((x) => [() => x]);
console.log(r.length, r[0](10));
