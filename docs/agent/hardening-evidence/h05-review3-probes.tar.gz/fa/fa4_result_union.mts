const f = (): number => 42;
const r = [1].flatMap<() => number | string>(() => [f]);
const v = r[0]();
console.log(typeof v, v);
