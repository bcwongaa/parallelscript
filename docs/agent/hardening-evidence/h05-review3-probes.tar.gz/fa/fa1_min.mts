const r = [1].flatMap<(a: number) => number>(() => [() => 1]);
console.log(r.length, r[0](5));
