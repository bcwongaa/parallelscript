const r = [1].flatMap<(a: number) => number>((x) => [() => x, (a: number) => a + x]);
console.log(r.length, r[0](10), r[1](10));
