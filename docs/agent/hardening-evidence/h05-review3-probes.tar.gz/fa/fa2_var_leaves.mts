const fs: (() => number)[] = [() => 1, () => 2];
const r = [1].flatMap<(a: number) => number>(() => fs);
console.log(r.length, r[1](5));
