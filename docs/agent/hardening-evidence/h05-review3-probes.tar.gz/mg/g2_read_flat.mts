const m = /(a)?(b)/.exec("b")!;
const s = [m].flat();
console.log(s.length, s[1] === undefined, s[1]);
