const parts = "a,b;c".split(/(,)|(;)/);
const flat = [parts].flat();
let undef = 0;
for (const p of flat) if (p === undefined) undef++;
console.log(flat.length, undef, flat.join("|"));
for (let i = 0; i < flat.length; i++) if (flat[i] === undefined) undef++;
console.log(undef);
