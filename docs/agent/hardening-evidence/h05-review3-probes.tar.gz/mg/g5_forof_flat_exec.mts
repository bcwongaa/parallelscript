const m = /(a)?(b)/.exec("b")!;
const f = [m].flat();
let n = 0;
for (const p of f) if (p === undefined) n++;
console.log("flat exec", n);
const g = ["b"].flatMap((s) => /(a)?(b)/.exec(s)!);
n = 0;
for (const p of g) if (p === undefined) n++;
console.log("flatMap exec", n);
