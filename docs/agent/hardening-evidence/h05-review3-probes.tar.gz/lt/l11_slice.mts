interface Named { name: string; size: number | string }
const base = [{ name: "a", size: 1 }];
const r = [1, 2].flatMap((n): Named[] => base.slice());
console.log(r);
