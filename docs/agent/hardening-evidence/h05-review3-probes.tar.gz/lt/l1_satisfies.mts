interface Named { name: string; size: number | string }
const r = [1, 2].flatMap<Named>((n) => [{ name: "n" + n, size: n } satisfies Named]);
console.log(r);
