interface Named { name: string; size: number | string }
const r = [1, 2].flatMap((n): Named[] => {
  const row = { name: "n" + n, size: n };
  return [row];
});
console.log(r);
