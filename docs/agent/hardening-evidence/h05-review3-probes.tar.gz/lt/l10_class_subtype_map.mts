interface Item { id: number; tag?: string }
class Thing { constructor(public id: number) {} }
const r = [[1, 2], [3]].flatMap((ids): Item[] => ids.map((id) => new Thing(id)));
console.log(r.length, r[2].id, r[0].tag);
