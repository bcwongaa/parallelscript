interface Named { name: string; size: number | string }
const r = [[1, 2], [3]].flatMap<Named>((ns) => ns.map((n) => ({ name: "n" + n, size: n })));
console.log(r);
