const r = [1, 2].flatMap<readonly [string, number]>((n) => [["k" + n, n] as const]);
console.log(r);
const s = [1, 2].flatMap((n) => [n, "x"] as const);
console.log(s);
