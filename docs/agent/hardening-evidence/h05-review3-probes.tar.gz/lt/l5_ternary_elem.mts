interface Named { name: string; size: number | string }
const big: Named = { name: "big", size: "L" };
const r = [1, 2].flatMap((n): Named[] => [n > 1 ? big : { name: "small", size: n }]);
console.log(r);
