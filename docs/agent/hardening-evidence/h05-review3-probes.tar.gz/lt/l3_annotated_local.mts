interface Named { name: string; size: number | string }
const r = [1, 2].flatMap((n): Named[] => {
  const row: Named = { name: "n" + n, size: n };
  return n > 1 ? [row, row] : [row];
});
console.log(r, r[1] === r[2]);
