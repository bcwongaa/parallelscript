interface Shape { area(): number }
class Sq { constructor(public s: number) {} area() { return this.s * this.s; } }
const r = [1, 2].flatMap((n): Shape[] => [new Sq(n), new Sq(n + 1)]);
console.log(r.map((s) => s.area()));
