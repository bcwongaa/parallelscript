interface Row { key: string; value: number | null }
const groups: Record<string, number[]> = { a: [1, -2], b: [3] };
const rows: Row[] = Object.entries(groups).flatMap(([key, vs]): Row[] => {
  return vs.filter((v) => v > 0).map((v) => ({ key, value: v }));
});
console.log(rows);
