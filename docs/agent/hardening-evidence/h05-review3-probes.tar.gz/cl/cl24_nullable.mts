class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<C | null>(() => [null, c]);
console.log(r.length, r[0], r[1] === c);
