class Animal { constructor(public name: string) {} }
class Dog extends Animal { bark() { return "woof"; } }
const dogs: Dog[] = [new Dog("a"), new Dog("b")];
const r = [1, 2].flatMap<Animal>(() => dogs);
console.log(r.length, r[0] === dogs[0], r[3].name);
const s: Animal[] = [1].flatMap((): Animal[] => dogs);
console.log(s.length, s[1] === dogs[1]);
