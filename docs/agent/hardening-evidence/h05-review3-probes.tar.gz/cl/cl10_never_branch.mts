function fail(): never { throw new Error("no"); }
const r = [1, 2].flatMap((x) => (x > 0 ? [x, x] : fail()));
console.log(r);
