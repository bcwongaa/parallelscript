interface J { x: number }
class C { constructor(public x: number) {} }
const cs = [new C(1), new C(2)];
const r = [0, 1, 2].flatMap<J>((i) => {
  if (i === 0) return [];
  if (i === 1) return cs;
  return [cs[0]];
});
console.log(r.length, r[2] === cs[0]);
