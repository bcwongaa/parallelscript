const f = (a: number) => a + 1;
const g = (a: number) => a * 2;
const fs = [f, g];
const r = [1].flatMap(() => fs);
console.log(r.length, r[0] === f, r[1](5));
const r2 = [1].flatMap(() => [f, g]);
console.log(r2[0] === f, r2[1](4));
