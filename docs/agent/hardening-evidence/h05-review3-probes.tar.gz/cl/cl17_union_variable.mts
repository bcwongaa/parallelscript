interface J { x: number }
class C { constructor(public x: number) {} }
const cs: (C | C[])[] = [new C(1), [new C(2), new C(3)]];
const r = cs.flatMap<J>((v) => v);
console.log(r.length, r[2].x, r[0] === cs[0]);
