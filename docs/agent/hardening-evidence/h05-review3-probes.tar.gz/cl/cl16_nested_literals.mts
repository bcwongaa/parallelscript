const r = [1, 2].flatMap((x) => [[[x]], [x, [x]]]);
console.log(JSON.stringify(r));
const s = [1].flatMap<(number | number[])[]>((x) => [[x, [x]]]);
console.log(JSON.stringify(s));
