interface J { x: number; y?: string }
class C { x = 1; }
class D { x = 2; y = "d"; }
const c = new C(), d = new D();
const r = [1].flatMap<J>(() => [c, d]);
console.log(r.length, r[0] === c, r[1] === d, r[0].y, r[1].y);
