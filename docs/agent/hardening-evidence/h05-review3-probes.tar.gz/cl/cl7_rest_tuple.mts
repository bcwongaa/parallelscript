const ts: [string, ...number[]][] = [["a", 1, 2], ["b"]];
const r = ts.flatMap((t) => t);
console.log(r);
const s = ts.flatMap((t): (string | number)[] => t);
console.log(s);
