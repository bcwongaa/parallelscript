interface J { x: number }
const p = { x: 1 };
const q = { x: 2, y: 3 };
const r = [1].flatMap<J>(() => [p, q]);
console.log(r.length, r[0] === p, r[1] === q, r[1].x);
