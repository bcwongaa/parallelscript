interface J { x: number }
class C { constructor(public x: number) {} }
const ro: readonly C[] = [new C(1), new C(2)];
const r = [1].flatMap<J>(() => ro);
console.log(r.length, r[0] === ro[0]);
