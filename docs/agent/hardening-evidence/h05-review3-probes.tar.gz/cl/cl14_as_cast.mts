interface J { x: number }
class C { constructor(public x: number) {} }
const c = new C(3);
const r = [1].flatMap<J>(() => [c as J]);
console.log(r[0] === c, r[0].x);
