type Dir = "n" | "s" | "e";
const r = [1, 2].flatMap<Dir>((i) => (i === 1 ? ["n", "s"] : ["e"]));
console.log(r);
enum Color { Red, Green }
const c = [1].flatMap<Color>(() => [Color.Red, Color.Green]);
console.log(c);
