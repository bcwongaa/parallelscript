class C { constructor(public x: number) {} }
const xs: (C | undefined)[] = [new C(1), undefined, new C(2)];
const r = xs.flatMap((x) => (x === undefined ? [] : [x]));
console.log(r.length, r[1].x);
const s = xs.flatMap((x) => x);
console.log(s.length, s[1]);
