const x = 1, s = "a";
const r = [1].flatMap<number | string>(() => [x, s, 2, "b"]);
console.log(r);
