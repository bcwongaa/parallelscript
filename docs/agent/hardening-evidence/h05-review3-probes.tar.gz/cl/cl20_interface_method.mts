interface Shape { area(): number; name: string }
class Sq implements Shape { constructor(public name: string, public s: number) {} area() { return this.s * this.s; } }
class Ci implements Shape { constructor(public name: string, public r: number) {} area() { return 3 * this.r * this.r; } }
const sq = new Sq("sq", 2), ci = new Ci("ci", 1);
const r = [1].flatMap<Shape>(() => [sq, ci]);
console.log(r.map((s) => s.name + s.area()).join(" "), r[0] === sq);
const shapes: Shape[] = [sq, ci];
const r2 = [1, 2].flatMap((i) => (i === 1 ? shapes : [ci]));
console.log(r2.length, r2[2] === ci);
