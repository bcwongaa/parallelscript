const ts: [number, string?][] = [[1, "a"], [2]];
const r = ts.flatMap((t) => t);
console.log(r);
