class Box<T> { constructor(public v: T) {} }
interface HasV { v: number }
const bs = [new Box(1), new Box(2)];
const r = [1].flatMap<HasV>(() => bs);
console.log(r.length, r[1].v, r[0] === bs[0]);
const r2 = [1].flatMap(() => [bs[0], new Box(5)]);
console.log(r2[1].v);
