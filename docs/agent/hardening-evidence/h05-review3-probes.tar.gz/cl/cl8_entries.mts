const o: Record<string, number> = { a: 1, b: 2 };
const r = Object.entries(o).flatMap(([k, v]) => [k, v]);
console.log(r);
const s = Object.entries(o).flatMap((e) => e);
console.log(s);
