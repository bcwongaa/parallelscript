class P { constructor(public v: number) {} }
function flatAll<T>(xs: T[][]): T[] { return xs.flatMap((x) => x); }
function wrap<T>(xs: T[]): T[] { return xs.flatMap((x) => [x]); }
const ps = [new P(1), new P(2)];
const r = flatAll([ps, [ps[0]]]);
console.log(r.length, r[2] === ps[0]);
console.log(wrap(ps)[1] === ps[1], wrap([1, 2]), wrap(["a"]));
