interface J { x: number }
class C { constructor(public x: number) {} }
const cs = [new C(1), new C(2)];
const r = [1].flatMap<J[]>(() => [cs.map((c) => c)]);
console.log(r.length, r[0].length, r[0][0] === cs[0], r[0][1].x);
