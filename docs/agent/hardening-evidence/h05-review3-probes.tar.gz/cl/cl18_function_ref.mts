interface J { x: number }
class C { constructor(public x: number) {} }
function make(n: number): C[] { return [new C(n), new C(n + 1)]; }
const r = [1, 3].flatMap<J>(make);
console.log(r.length, r[3].x);
