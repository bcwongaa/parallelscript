class Animal { constructor(public name: string) {} }
class Dog extends Animal { bark() { return "woof"; } }
class Bird extends Animal { sing() { return "tweet"; } }
const dog = new Dog("d"), bird = new Bird("b");
const r = [1, 2].flatMap<Animal>((x) => [x > 1 ? dog : bird]);
console.log(r.map((a) => a.name).join(","), r[0] === bird, r[1] === dog);
