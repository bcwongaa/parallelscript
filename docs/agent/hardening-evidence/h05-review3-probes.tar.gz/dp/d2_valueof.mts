const inner: number[] = [2];
const xs: (number | number[])[] = [1, inner];
const depth: any = { valueOf() { inner.push(3); xs.length = 1; return 1; } };
console.log(JSON.stringify(xs.flat(depth)), JSON.stringify(xs));
const ys: (number | number[])[] = [1, [2]];
const thrower: any = { valueOf() { throw new Error("boom"); } };
try { ys.flat(thrower); } catch (e) { console.log("caught", (e as Error).message); }
const dyn: any = [1, [2]];
const d2: any = { valueOf() { dyn.push(9); return 1; } };
console.log(JSON.stringify(dyn.flat(d2)));
