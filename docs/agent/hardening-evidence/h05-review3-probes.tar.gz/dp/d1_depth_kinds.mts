const xs: (number | (number | number[])[])[] = [1, [2, [3]]];
const depths: any[] = ["2", "abc", null, true, false, {}, [], [3], [1, 2], "  1  ", "Infinity", -1, 0.9, 1.9, NaN, "0x2", undefined];
for (const d of depths) console.log(JSON.stringify(xs.flat(d)));
const dyn: any = xs;
for (const d of depths) console.log("dyn", JSON.stringify(dyn.flat(d)));
console.log(JSON.stringify(dyn.flat()));
