const t: [number, number[]] = [1, [2, 3]];
const d: any = 1;
console.log(t.flat(d), t.flat(), t.flat(0));
function f(xs: (number | number[])[], depth?: number) { return xs.flat(depth); }
console.log(f([1, [2]]), f([1, [2]], 0), f([1, [2]], undefined));
