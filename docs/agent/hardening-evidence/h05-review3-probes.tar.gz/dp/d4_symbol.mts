const xs: (number | number[])[] = [1, [2]];
const s: any = Symbol("d");
try { console.log(xs.flat(s)); } catch (e) { console.log("caught", (e as Error).constructor.name); }
const dyn: any = xs;
try { console.log(dyn.flat(s)); } catch (e) { console.log("caught", (e as Error).constructor.name); }
