function perms<T>(xs: T[]): T[][] {
  if (xs.length <= 1) return [xs.slice()];
  return xs.flatMap((x, i) => perms([...xs.slice(0, i), ...xs.slice(i + 1)]).map((p) => [x, ...p]));
}
console.log(perms([1, 2, 3]).map((p) => p.join("")).join(" "));
console.log(perms(["a", "b"]));
const combos = [1, 2].flatMap((a) => ["x", "y"].map((b): [number, string] => [a, b]));
console.log(combos);
