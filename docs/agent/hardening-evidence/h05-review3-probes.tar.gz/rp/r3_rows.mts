type Cell = string | number | null;
interface Product { name: string; tags: string[]; price: number | null }
const products: Product[] = [
  { name: "pen", tags: ["office", "cheap"], price: 1.5 },
  { name: "desk", tags: [], price: null },
];
const rows: Cell[][] = products.map((p) => [p.name, p.price, ...p.tags]);
console.log(rows.flat());
const tagged = products.flatMap((p) => p.tags.map((t) => `${p.name}:${t}`));
console.log(tagged);
const cells: Cell[] = products.flatMap((p): Cell[] => [p.name, p.price]);
console.log(cells, cells.flat());
