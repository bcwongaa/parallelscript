interface Edge { from: string; to: string; weight: number }
class Graph {
  private edges = new Map<string, Edge[]>();
  add(from: string, to: string, weight: number) {
    const list = this.edges.get(from) ?? [];
    list.push({ from, to, weight });
    this.edges.set(from, list);
  }
  out(n: string): Edge[] { return this.edges.get(n) ?? []; }
  frontier(nodes: string[]): Edge[] { return nodes.flatMap((n) => this.out(n)); }
  reach(start: string): string[] {
    const seen = new Set<string>([start]);
    let level = [start];
    while (level.length > 0) {
      level = this.frontier(level).map((e) => e.to).filter((t) => !seen.has(t));
      level.forEach((t) => seen.add(t));
    }
    return [...seen];
  }
}
const g = new Graph();
g.add("a", "b", 1); g.add("a", "c", 2); g.add("b", "d", 3); g.add("c", "d", 1); g.add("d", "e", 5);
console.log(g.reach("a"), g.frontier(["a", "b"]).reduce((s, e) => s + e.weight, 0));
const nested = [["a", "b"], ["c", ["d", ["e"]]]] as const;
console.log(nested.flat(Infinity));
