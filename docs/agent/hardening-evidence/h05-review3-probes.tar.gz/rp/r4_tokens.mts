const src = "let x = 1 + foo(2, 3);";
const lines = ["a=1", "b", "c=3=4"];
const kv = lines.flatMap((l) => {
  const m = /^(\w+)(?:=(.*))?$/.exec(l);
  return m ? [[m[1], m[2] ?? "(none)"]] : [];
});
console.log(kv);
const groups: any = lines.map((l) => /^(\w+)(?:=(.*))?$/.exec(l));
console.log(groups.flat().length, groups.flat().filter((g: any) => g === undefined).length);
