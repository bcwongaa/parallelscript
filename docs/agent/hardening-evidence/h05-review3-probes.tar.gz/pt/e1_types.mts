interface Tree { v: number; kids: Tree[] }
interface Opt { a?: number; b: string | null }
class Box<T> { constructor(public v: T) {} get double() { return 2; } }
class Priv { #secret = 1; reveal() { return this.#secret; } }
type Fn = (a: number) => string;
const t1: Tree = { v: 1, kids: [{ v: 2, kids: [] }] };
const trees: Tree[][] = [[t1], [t1.kids[0]]];
console.log(trees.flat().length, [1].flatMap(() => trees[0]).length);
const maps: Map<string, number>[][] = [[new Map([["a", 1]])]];
console.log(maps.flat()[0].get("a"), [1].flatMap(() => maps[0])[0].size);
const dates: (Date | Date[])[] = [new Date(0), [new Date(1000)]];
console.log(dates.flat().map((d) => d.getTime()));
const fns: (Fn | Fn[])[] = [(a) => "x" + a, [(a) => "y" + a]];
console.log(fns.flat().map((f) => f(1)));
const boxes: Box<number>[][] = [[new Box(1)], [new Box(2)]];
console.log(boxes.flat().map((b) => b.v + b.double), [1].flatMap(() => boxes[1])[0].v);
const privs: Priv[][] = [[new Priv()]];
console.log(privs.flat()[0].reveal(), [1].flatMap(() => privs[0])[0].reveal());
const o1: Opt = { b: null }; const o2: Opt = { a: 1, b: "s" }; const o2s: Opt[] = [o2];
const opts: (Opt | Opt[])[] = [o1, o2s];
console.log(JSON.stringify(opts.flat()), JSON.stringify([1].flatMap<Opt>(() => opts[1] as Opt[])));
const bytes: Uint8Array[][] = [[new Uint8Array([1, 2])]];
console.log(bytes.flat()[0].length);
const sets: (Set<string> | Set<string>[])[] = [new Set(["a"]), [new Set(["b"])]];
console.log(sets.flat().map((s) => [...s].join("")));
const res: RegExp[][] = [[/a/g]];
console.log(res.flat()[0].source);
const ps: Promise<number>[][] = [[Promise.resolve(3)]];
console.log(await ps.flat()[0]);
const recs: Record<string, number>[][] = [[{ a: 1 }]];
console.log(recs.flat()[0].a);
