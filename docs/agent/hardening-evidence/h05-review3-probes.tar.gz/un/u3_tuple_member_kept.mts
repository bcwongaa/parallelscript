type P = [number, number];
type V = P | number[] | string;
const p: P = [1, 2];
const v: V = p;
console.log(v === p);
const q: [number, number] = [3, 4];
const vs: V[] = [q, "s", [5]];
console.log(vs[0] === q, vs);
