type V = number | number[] | (number | number[])[];
const a: number[][] = [[1], [2]];
const v: V = [[1], [2]];
console.log(JSON.stringify(v));
const f = (x: V) => JSON.stringify(x);
console.log(f([[3]]), f([4]), f(5));
