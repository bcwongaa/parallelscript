type V = [number, string | number] | (number | string)[];
const t: [number, string] = [1, "a"];
const w: V = [1, "b"];
console.log(w, w.length);
function show(v: V) { return v.length; }
console.log(show([2, "c"]));
