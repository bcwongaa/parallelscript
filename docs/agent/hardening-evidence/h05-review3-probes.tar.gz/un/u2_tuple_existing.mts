type V = [number, string] | (number | string)[] | string;
const t: [number, string] = [1, "a"];
const v: V = t;
console.log(v === t, v);
