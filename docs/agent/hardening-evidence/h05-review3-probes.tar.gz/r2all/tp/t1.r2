true [ 1, 'a' ]
exit=0
