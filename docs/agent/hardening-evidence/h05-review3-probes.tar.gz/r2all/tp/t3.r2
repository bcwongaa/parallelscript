true [ 1, 'a' ]
true
exit=0
