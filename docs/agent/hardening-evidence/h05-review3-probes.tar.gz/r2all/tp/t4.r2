true [ 1, 'a' ]
true [ 2, 'b' ]
true [ 1, 2, 3 ]
true [ 1, 'a' ]
exit=0
