o3.pts:3:23 - error TS2345: Argument of type '(x: number[] | string[]) => string[] | number[]' is not assignable to parameter of type '((this: undefined, value: string[], index: number, array: string[][]) => string | readonly string[]) & ((this: undefined, value: number[], index: number, array: number[][]) => string | readonly string[])'.
  Type '(x: number[] | string[]) => string[] | number[]' is not assignable to type '(this: undefined, value: string[], index: number, array: string[][]) => string | readonly string[]'.
    Type 'string[] | number[]' is not assignable to type 'string | readonly string[]'.
      Type 'number[]' is not assignable to type 'string | readonly string[]'.
        Type 'number[]' is not assignable to type 'readonly string[]'.
          Type 'number' is not assignable to type 'string'.
exit=1
