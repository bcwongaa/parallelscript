[ 3, 4 ] undefined 2 undefined
2 undefined
[ 1, 1 ] undefined
[ 1, 2, 3 ] undefined 3
[ 1 ] 1
a,b none
exit=0
