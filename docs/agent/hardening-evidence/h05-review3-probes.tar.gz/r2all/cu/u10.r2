[ 1, 1, 'a' ]
[ 1, 'a', 1, 'a' ] true
exit=0
