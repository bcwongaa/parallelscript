[ 1, 's', 't' ]
exit=0
