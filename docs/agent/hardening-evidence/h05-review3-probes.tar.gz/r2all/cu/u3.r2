u3.pts:2:33 - error TS2322: Type 'number | string[]' is not assignable to type 'string | readonly string[]'.
  Type 'number' is not assignable to type 'string | readonly string[]'.
exit=1
