u2.pts:2:33 - error TS2322: Type 'string[] | number[]' is not assignable to type 'string | readonly string[]'.
  Type 'number[]' is not assignable to type 'string | readonly string[]'.
    Type 'number[]' is not assignable to type 'readonly string[]'.
      Type 'number' is not assignable to type 'string'.
exit=1
