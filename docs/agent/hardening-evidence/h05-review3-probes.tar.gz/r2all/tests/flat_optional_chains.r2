[ 3 ] undefined
[ 3 ] undefined
[ 1, 2, 3 ] undefined
[ 1, 2, 3 ]
3 -1
exit=0
