[ 1, <1 empty item>, [ 2, 3 ], <1 empty item> ] [ 1, 2, 3 ]
[ 'x', 'a', 'c' ]
[ 'y', [ 'a', <1 empty item>, 'c' ] ] [ 'y', 'a', 'c' ]
[ 'a', 'a', 'c' ]
exit=0
