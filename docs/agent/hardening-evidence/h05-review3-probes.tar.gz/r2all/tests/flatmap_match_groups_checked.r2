map -> TypeError: Expected string, got undefined (group 1 of the match took no part in it)
flatMap -> TypeError: Expected string, got undefined (group 1 of the match took no part in it)
split map -> RangeError: Array index 2 is out of range (length 4); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
split flatMap -> RangeError: Array index 2 is out of range (length 4); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
exit=0
