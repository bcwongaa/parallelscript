[ 'a', 'a', 'c', 'c' ]
[ 'a', 'b' ]
exit=0
