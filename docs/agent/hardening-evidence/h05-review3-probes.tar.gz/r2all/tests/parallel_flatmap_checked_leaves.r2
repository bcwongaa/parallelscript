Point[] -> TypeError: Expected Point[], got Point
number[] -> TypeError: Expected number[], got number
string | number[] -> TypeError: Expected number[] | string, got number
Point[][] 2
exit=0
