[ 'b', undefined, 'b' ] 3
[ 'b', undefined, 'b' ]
[ 'b', undefined, 'b' ] [ 'b', 'none', 'b' ]
[ 'a', ',', undefined, 'b' ] 5
[ 'a', ',', 'none', 'b' ]
[ undefined, 'b', 'z' ]
exit=0
