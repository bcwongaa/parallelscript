mb7.pts:2:7 - error PTS1001: values of type Object are not supported yet
exit=1
