mb5.pts:2:48 - error TS2322: Type 'ArrayLike<number>' is not assignable to type 'number | readonly number[]'.
  Type 'ArrayLike<number>' is missing the following properties from type 'readonly number[]': concat, join, slice, indexOf, and 25 more.
exit=1
