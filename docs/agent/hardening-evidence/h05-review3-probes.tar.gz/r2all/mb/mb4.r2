mb4.pts:2:47 - error TS2322: Type 'Iterable<number>' is not assignable to type 'number | readonly number[]'.
  Type 'Iterable<number>' is missing the following properties from type 'readonly number[]': length, concat, join, slice, and 25 more.
exit=1
