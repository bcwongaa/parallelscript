caught TypeError
caught TypeError
[ 1, 2, 3, 4, { length: 1, z: 'x' } ]
[ 1.5, true, null, undefined ]
exit=0
