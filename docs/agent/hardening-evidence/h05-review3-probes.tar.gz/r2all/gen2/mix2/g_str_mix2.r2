1 4 ["a",["b"],["a"],[]] string,array,array,array
0 3 ["a",[["b"]],[["a"],[]]] string,array,array
1 4 ["a",["b"],["a"],[]] string,array,array,array
2 3 ["a","b","a"] string,string,string
Infinity 3 ["a","b","a"] string,string,string
fm-wrap 3 ["a",[["b"]],[["a"],[]]]
fm-mix 4 ["a",[["b"]],[["b"]],[["a"],[]]]
exit=0
