1 4 [null,[3],[null],[]] undefined,array,array,array
0 3 [null,[[3]],[[null],[]]] undefined,array,array
1 4 [null,[3],[null],[]] undefined,array,array,array
2 3 [null,3,null] undefined,number,undefined
Infinity 3 [null,3,null] undefined,number,undefined
fm-wrap 3 [null,[[3]],[[null],[]]]
fm-mix 4 [null,[[3]],[[3]],[[null],[]]]
exit=0
