g_tup_mix2.pts:4:87 - error PTS1001: using a `[[number, string][], value[]]` as a `[number, string]` is not supported yet
exit=1
