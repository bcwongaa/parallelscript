1 4 [1,["s"],[1],[]] number,array,array,array
0 3 [1,[["s"]],[[1],[]]] number,array,array
1 4 [1,["s"],[1],[]] number,array,array,array
2 3 [1,"s",1] number,string,number
Infinity 3 [1,"s",1] number,string,number
fm-wrap 3 [1,[["s"]],[[1],[]]]
fm-mix 4 [1,[["s"]],[["s"]],[[1],[]]]
exit=0
