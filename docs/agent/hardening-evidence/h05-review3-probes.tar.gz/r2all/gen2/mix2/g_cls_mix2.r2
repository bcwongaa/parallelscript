1 4 [{"x":1},[{"x":2}],[{"x":1}],[]] object,array,array,array
0 3 [{"x":1},[[{"x":2}]],[[{"x":1}],[]]] object,array,array
1 4 [{"x":1},[{"x":2}],[{"x":1}],[]] object,array,array,array
2 3 [{"x":1},{"x":2},{"x":1}] object,object,object
Infinity 3 [{"x":1},{"x":2},{"x":1}] object,object,object
fm-wrap 3 [{"x":1},[[{"x":2}]],[[{"x":1}],[]]]
fm-mix 4 [{"x":1},[[{"x":2}]],[[{"x":2}]],[[{"x":1}],[]]]
exit=0
