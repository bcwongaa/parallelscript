1 4 [true,[false],[true],[]] boolean,array,array,array
0 3 [true,[[false]],[[true],[]]] boolean,array,array
1 4 [true,[false],[true],[]] boolean,array,array,array
2 3 [true,false,true] boolean,boolean,boolean
Infinity 3 [true,false,true] boolean,boolean,boolean
fm-wrap 3 [true,[[false]],[[true],[]]]
fm-mix 4 [true,[[false]],[[false]],[[true],[]]]
exit=0
