1 4 [1,[2.5],[1],[]] number,array,array,array
0 3 [1,[[2.5]],[[1],[]]] number,array,array
1 4 [1,[2.5],[1],[]] number,array,array,array
2 3 [1,2.5,1] number,number,number
Infinity 3 [1,2.5,1] number,number,number
fm-wrap 3 [1,[[2.5]],[[1],[]]]
fm-mix 4 [1,[[2.5]],[[2.5]],[[1],[]]]
exit=0
