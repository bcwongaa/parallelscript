1 4 [{"name":"q","n":1},[{"name":"r","n":2}],[{"name":"q","n":1}],[]] object,array,array,array
0 3 [{"name":"q","n":1},[[{"name":"r","n":2}]],[[{"name":"q","n":1}],[]]] object,array,array
1 4 [{"name":"q","n":1},[{"name":"r","n":2}],[{"name":"q","n":1}],[]] object,array,array,array
2 3 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1}] object,object,object
Infinity 3 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1}] object,object,object
fm-wrap 3 [{"name":"q","n":1},[[{"name":"r","n":2}]],[[{"name":"q","n":1}],[]]]
fm-mix 4 [{"name":"q","n":1},[[{"name":"r","n":2}]],[[{"name":"r","n":2}]],[[{"name":"q","n":1}],[]]]
exit=0
