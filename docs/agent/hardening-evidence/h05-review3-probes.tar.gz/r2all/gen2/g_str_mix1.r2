1 4 ["a","b","a","b"] string,string,string,string
0 3 ["a",["b"],["a","b"]] string,array,array
1 4 ["a","b","a","b"] string,string,string,string
2 4 ["a","b","a","b"] string,string,string,string
Infinity 4 ["a","b","a","b"] string,string,string,string
fm-id 4 ["a","b","a","b"]
fm-wrap 3 ["a",["b"],["a","b"]]
fm-mix 4 ["a",["b"],["b"],["a","b"]]
exit=0
