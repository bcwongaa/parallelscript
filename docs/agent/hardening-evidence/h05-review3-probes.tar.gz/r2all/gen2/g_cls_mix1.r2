1 4 [{"x":1},{"x":2},{"x":1},{"x":2}] object,object,object,object
0 3 [{"x":1},[{"x":2}],[{"x":1},{"x":2}]] object,array,array
1 4 [{"x":1},{"x":2},{"x":1},{"x":2}] object,object,object,object
2 4 [{"x":1},{"x":2},{"x":1},{"x":2}] object,object,object,object
Infinity 4 [{"x":1},{"x":2},{"x":1},{"x":2}] object,object,object,object
fm-id 4 [{"x":1},{"x":2},{"x":1},{"x":2}]
fm-wrap 3 [{"x":1},[{"x":2}],[{"x":1},{"x":2}]]
fm-mix 4 [{"x":1},[{"x":2}],[{"x":2}],[{"x":1},{"x":2}]]
exit=0
