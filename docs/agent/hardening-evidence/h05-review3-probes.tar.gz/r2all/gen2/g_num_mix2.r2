g_num_mix2.pts:10:32 - error TS2322: Type 'number | number[][]' is not assignable to type 'number[] | readonly number[][]'.
  Type 'number' is not assignable to type 'number[] | readonly number[][]'.
exit=1
