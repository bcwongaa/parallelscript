1 3 [1,2.5,1] number,number,number
0 2 [[1],[2.5,1]] array,array
1 3 [1,2.5,1] number,number,number
2 3 [1,2.5,1] number,number,number
Infinity 3 [1,2.5,1] number,number,number
fm-id 3 [1,2.5,1]
fm-wrap 2 [[1],[2.5,1]]
fm-mix 3 [[1],[2.5,1],[2.5,1]]
exit=0
