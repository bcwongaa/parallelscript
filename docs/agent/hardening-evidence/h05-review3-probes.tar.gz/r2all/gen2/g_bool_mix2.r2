g_bool_mix2.pts:10:32 - error TS2322: Type 'boolean | boolean[][]' is not assignable to type 'boolean[] | readonly boolean[][]'.
  Type 'boolean' is not assignable to type 'boolean[] | readonly boolean[][]'.
exit=1
