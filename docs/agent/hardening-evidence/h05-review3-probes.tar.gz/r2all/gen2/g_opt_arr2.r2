1 3 [null,3,null] undefined,number,undefined
0 2 [[null],[3,null]] array,array
1 3 [null,3,null] undefined,number,undefined
2 3 [null,3,null] undefined,number,undefined
Infinity 3 [null,3,null] undefined,number,undefined
fm-id 3 [null,3,null]
fm-wrap 2 [[null],[3,null]]
fm-mix 3 [[null],[3,null],[3,null]]
exit=0
