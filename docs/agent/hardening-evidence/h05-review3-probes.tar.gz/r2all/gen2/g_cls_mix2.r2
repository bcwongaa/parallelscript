g_cls_mix2.pts:10:32 - error TS2322: Type 'P[][] | P' is not assignable to type 'P[] | readonly P[][]'.
  Type 'P' is not assignable to type 'P[] | readonly P[][]'.
exit=1
