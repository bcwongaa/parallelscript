g_uni_mix2.pts:10:32 - error TS2322: Type 'string | number | (string | number)[][]' is not assignable to type '(string | number)[] | readonly (string | number)[][]'.
  Type 'string' is not assignable to type '(string | number)[] | readonly (string | number)[][]'.
exit=1
