1 3 [true,false,true] boolean,boolean,boolean
0 2 [[true],[false,true]] array,array
1 3 [true,false,true] boolean,boolean,boolean
2 3 [true,false,true] boolean,boolean,boolean
Infinity 3 [true,false,true] boolean,boolean,boolean
fm-id 3 [true,false,true]
fm-wrap 2 [[true],[false,true]]
fm-mix 3 [[true],[false,true],[false,true]]
exit=0
