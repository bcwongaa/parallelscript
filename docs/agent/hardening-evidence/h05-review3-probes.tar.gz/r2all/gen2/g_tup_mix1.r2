g_tup_mix1.pts:10:25 - error PTS1001: `flatMap` with a callback that returns a [number, string] is not supported yet: JS's flatMap spreads it into the result, which TypeScript types as a [number, string][] as if it didn't; return it in an array to keep it whole
g_tup_mix1.pts:12:35 - error PTS1001: converting ([number, string] | [number, string][])[] | [number, string] | [number, string][] to ([number, string] | [number, string][])[] is not supported yet
exit=1
