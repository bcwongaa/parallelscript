g_opt_mix2.pts:10:32 - error TS2322: Type 'number | (number | undefined)[][] | undefined' is not assignable to type '(number | undefined)[] | readonly ((number | undefined)[] | undefined)[] | undefined'.
  Type 'number' is not assignable to type '(number | undefined)[] | readonly ((number | undefined)[] | undefined)[] | undefined'.
exit=1
