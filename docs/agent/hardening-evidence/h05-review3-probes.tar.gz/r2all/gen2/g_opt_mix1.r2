1 4 [null,3,null,3] undefined,number,undefined,number
0 3 [null,[3],[null,3]] undefined,array,array
1 4 [null,3,null,3] undefined,number,undefined,number
2 4 [null,3,null,3] undefined,number,undefined,number
Infinity 4 [null,3,null,3] undefined,number,undefined,number
fm-id 4 [null,3,null,3]
fm-wrap 3 [null,[3],[null,3]]
fm-mix 4 [null,[3],[3],[null,3]]
exit=0
