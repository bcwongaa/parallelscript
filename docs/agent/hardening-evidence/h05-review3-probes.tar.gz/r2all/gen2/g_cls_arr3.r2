1 3 [[{"x":1}],[{"x":2}],[{"x":1}]] array,array,array
0 2 [[[{"x":1}]],[[{"x":2}],[{"x":1}]]] array,array
1 3 [[{"x":1}],[{"x":2}],[{"x":1}]] array,array,array
2 3 [{"x":1},{"x":2},{"x":1}] object,object,object
Infinity 3 [{"x":1},{"x":2},{"x":1}] object,object,object
fm-id 3 [[{"x":1}],[{"x":2}],[{"x":1}]]
fm-wrap 2 [[[{"x":1}]],[[{"x":2}],[{"x":1}]]]
fm-mix 3 [[[{"x":1}]],[[{"x":2}],[{"x":1}]],[[{"x":2}],[{"x":1}]]]
exit=0
