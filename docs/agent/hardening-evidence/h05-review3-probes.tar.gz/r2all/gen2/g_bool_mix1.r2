1 4 [true,false,true,false] boolean,boolean,boolean,boolean
0 3 [true,[false],[true,false]] boolean,array,array
1 4 [true,false,true,false] boolean,boolean,boolean,boolean
2 4 [true,false,true,false] boolean,boolean,boolean,boolean
Infinity 4 [true,false,true,false] boolean,boolean,boolean,boolean
fm-id 4 [true,false,true,false]
fm-wrap 3 [true,[false],[true,false]]
fm-mix 4 [true,[false],[false],[true,false]]
exit=0
