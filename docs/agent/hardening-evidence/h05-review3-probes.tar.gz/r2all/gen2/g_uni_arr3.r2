1 3 [[1],["s"],[1]] array,array,array
0 2 [[[1]],[["s"],[1]]] array,array
1 3 [[1],["s"],[1]] array,array,array
2 3 [1,"s",1] number,string,number
Infinity 3 [1,"s",1] number,string,number
fm-id 3 [[1],["s"],[1]]
fm-wrap 2 [[[1]],[["s"],[1]]]
fm-mix 3 [[[1]],[["s"],[1]],[["s"],[1]]]
exit=0
