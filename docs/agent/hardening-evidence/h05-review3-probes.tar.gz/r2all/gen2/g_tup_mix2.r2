g_tup_mix2.pts:10:32 - error TS2322: Type '[number, string][][] | [number, string]' is not assignable to type '[number, string][] | readonly [number, string][][]'.
  Type '[number, string]' is not assignable to type '[number, string][] | readonly [number, string][][]'.
    Type '[number, string]' is not assignable to type '[number, string][]'.
      Type 'string | number' is not assignable to type '[number, string]'.
        Type 'string' is not assignable to type '[number, string]'.
exit=1
