1 3 [[{"name":"q","n":1}],[{"name":"r","n":2}],[{"name":"q","n":1}]] array,array,array
0 2 [[[{"name":"q","n":1}]],[[{"name":"r","n":2}],[{"name":"q","n":1}]]] array,array
1 3 [[{"name":"q","n":1}],[{"name":"r","n":2}],[{"name":"q","n":1}]] array,array,array
2 3 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1}] object,object,object
Infinity 3 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1}] object,object,object
fm-id 3 [[{"name":"q","n":1}],[{"name":"r","n":2}],[{"name":"q","n":1}]]
fm-wrap 2 [[[{"name":"q","n":1}]],[[{"name":"r","n":2}],[{"name":"q","n":1}]]]
fm-mix 3 [[[{"name":"q","n":1}]],[[{"name":"r","n":2}],[{"name":"q","n":1}]],[[{"name":"r","n":2}],[{"name":"q","n":1}]]]
exit=0
