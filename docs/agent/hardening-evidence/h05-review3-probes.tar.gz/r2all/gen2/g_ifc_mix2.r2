g_ifc_mix2.pts:10:32 - error TS2322: Type 'I[][] | I' is not assignable to type 'I[] | readonly I[][]'.
  Type 'I' is not assignable to type 'I[] | readonly I[][]'.
exit=1
