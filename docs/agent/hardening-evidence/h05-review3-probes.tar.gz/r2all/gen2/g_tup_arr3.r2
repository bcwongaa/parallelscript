1 3 [[[1,"t"]],[[2,"u"]],[[1,"t"]]] array,array,array
0 2 [[[[1,"t"]]],[[[2,"u"]],[[1,"t"]]]] array,array
1 3 [[[1,"t"]],[[2,"u"]],[[1,"t"]]] array,array,array
2 3 [[1,"t"],[2,"u"],[1,"t"]] object,object,object
Infinity 6 [1,"t",2,"u",1,"t"] number,string,number,string,number,string
fm-id 3 [[[1,"t"]],[[2,"u"]],[[1,"t"]]]
fm-wrap 2 [[[[1,"t"]]],[[[2,"u"]],[[1,"t"]]]]
fm-mix 3 [[[[1,"t"]]],[[[2,"u"]],[[1,"t"]]],[[[2,"u"]],[[1,"t"]]]]
exit=0
