1 4 [1,"s",1,"s"] number,string,number,string
0 3 [1,["s"],[1,"s"]] number,array,array
1 4 [1,"s",1,"s"] number,string,number,string
2 4 [1,"s",1,"s"] number,string,number,string
Infinity 4 [1,"s",1,"s"] number,string,number,string
fm-id 4 [1,"s",1,"s"]
fm-wrap 3 [1,["s"],[1,"s"]]
fm-mix 4 [1,["s"],["s"],[1,"s"]]
exit=0
