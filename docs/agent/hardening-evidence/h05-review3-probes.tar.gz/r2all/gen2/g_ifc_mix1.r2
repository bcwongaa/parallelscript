1 4 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1},{"name":"r","n":2}] object,object,object,object
0 3 [{"name":"q","n":1},[{"name":"r","n":2}],[{"name":"q","n":1},{"name":"r","n":2}]] object,array,array
1 4 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1},{"name":"r","n":2}] object,object,object,object
2 4 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1},{"name":"r","n":2}] object,object,object,object
Infinity 4 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1},{"name":"r","n":2}] object,object,object,object
fm-id 4 [{"name":"q","n":1},{"name":"r","n":2},{"name":"q","n":1},{"name":"r","n":2}]
fm-wrap 3 [{"name":"q","n":1},[{"name":"r","n":2}],[{"name":"q","n":1},{"name":"r","n":2}]]
fm-mix 4 [{"name":"q","n":1},[{"name":"r","n":2}],[{"name":"r","n":2}],[{"name":"q","n":1},{"name":"r","n":2}]]
exit=0
