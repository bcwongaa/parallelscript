1 3 ["a","b","a"] string,string,string
0 2 [["a"],["b","a"]] array,array
1 3 ["a","b","a"] string,string,string
2 3 ["a","b","a"] string,string,string
Infinity 3 ["a","b","a"] string,string,string
fm-id 3 ["a","b","a"]
fm-wrap 2 [["a"],["b","a"]]
fm-mix 3 [["a"],["b","a"],["b","a"]]
exit=0
