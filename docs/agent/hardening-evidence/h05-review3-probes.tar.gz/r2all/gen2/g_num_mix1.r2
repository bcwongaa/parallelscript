1 4 [1,2.5,1,2.5] number,number,number,number
0 3 [1,[2.5],[1,2.5]] number,array,array
1 4 [1,2.5,1,2.5] number,number,number,number
2 4 [1,2.5,1,2.5] number,number,number,number
Infinity 4 [1,2.5,1,2.5] number,number,number,number
fm-id 4 [1,2.5,1,2.5]
fm-wrap 3 [1,[2.5],[1,2.5]]
fm-mix 4 [1,[2.5],[2.5],[1,2.5]]
exit=0
