g_str_mix2.pts:10:32 - error TS2322: Type 'string | string[][]' is not assignable to type 'string[] | readonly string[][]'.
  Type 'string' is not assignable to type 'string[] | readonly string[][]'.
exit=1
