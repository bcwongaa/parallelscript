[ undefined, undefined, 1, null, 2 ] 5
[ undefined, 'x', undefined ] 3
[ undefined, undefined, 2 ] 3
[ undefined, null ]
[ true, false, true ]
[ undefined, null, undefined ] [ undefined, null, undefined ]
exit=0
