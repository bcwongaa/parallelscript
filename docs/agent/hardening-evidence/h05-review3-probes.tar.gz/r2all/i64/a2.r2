a2.pts:4:7 - error PTS1001: unions of several numeric types (string | number | int) are not supported yet
exit=1
