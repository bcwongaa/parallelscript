a3.pts:3:30 - error TS2322: Type '"s" | int[]' is not assignable to type 'int | readonly int[]'.
  Type 'string' is not assignable to type 'int | readonly int[]'.
exit=1
