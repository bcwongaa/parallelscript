a4.pts:3:51 - error PTS1001: using a i64[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
a4.pts:12:48 - error PTS1001: converting number | string to number is not supported yet
exit=1
