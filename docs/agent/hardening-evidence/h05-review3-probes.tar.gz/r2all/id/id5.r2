id5.pts:5:13 - error PTS1001: the `===` operator on {x: number | string} and C is not supported yet
id5.pts:8:12 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
exit=1
