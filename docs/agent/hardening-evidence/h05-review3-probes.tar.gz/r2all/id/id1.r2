id1.pts:21:26 - error PTS1001: using a `{x: value}` as a `{x: number}`, whose `x` it doesn't provide with the same types, is not supported yet
exit=1
