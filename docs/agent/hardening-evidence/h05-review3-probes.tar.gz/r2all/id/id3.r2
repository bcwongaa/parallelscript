5 true
[ { x: 6 } ] true true
2 false false
exit=0
