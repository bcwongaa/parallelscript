Uncaught TypeError: Expected {x: number | string}, got C
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/id/id7.pts:5)
    at /tmp/h05r3.OCtU/r2all/id/id7.pts:5
exit=1
