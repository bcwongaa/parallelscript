2 true true
10
true true
true true
exit=0
