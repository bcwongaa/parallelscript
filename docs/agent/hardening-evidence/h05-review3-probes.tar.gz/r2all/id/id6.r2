Uncaught TypeError: Expected {x: number | string}, got C
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/id/id6.pts:4)
    at /tmp/h05r3.OCtU/r2all/id/id6.pts:4
exit=1
