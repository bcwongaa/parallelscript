Uncaught TypeError: Expected {x: number | string}, got Object
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/id/id8.pts:4)
    at /tmp/h05r3.OCtU/r2all/id/id8.pts:4
exit=1
