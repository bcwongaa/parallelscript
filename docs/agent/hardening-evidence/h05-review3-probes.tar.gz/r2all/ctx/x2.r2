x2.pts:3:22 - error PTS1001: `flatMap` with a callback that returns a P is not supported yet: JS's flatMap spreads it into the result, which TypeScript types as a P[] as if it didn't; return it in an array to keep it whole
exit=1
