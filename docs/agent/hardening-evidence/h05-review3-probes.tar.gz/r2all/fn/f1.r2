3 true true true [ 11, 20, 11 ]
3 true true
3 true true
2 true
exit=0
