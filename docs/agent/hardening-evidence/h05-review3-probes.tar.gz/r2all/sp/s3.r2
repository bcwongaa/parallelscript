[ 1, 2, undefined ] 3
exit=0
