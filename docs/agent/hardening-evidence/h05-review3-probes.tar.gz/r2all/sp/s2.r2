s2.pts:2:65 - error TS2322: Type '[number, (string | undefined)?]' is not assignable to type 'string | number | readonly (string | number)[]'.
  Type '[number, (string | undefined)?]' is not assignable to type 'readonly (string | number)[]'.
    Type 'string | number | undefined' is not assignable to type 'string | number'.
      Type 'undefined' is not assignable to type 'string | number'.
exit=1
