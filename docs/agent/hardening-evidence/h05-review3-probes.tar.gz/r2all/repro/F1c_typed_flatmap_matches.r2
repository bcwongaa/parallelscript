Uncaught TypeError: Expected string, got undefined
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/repro/F1c_typed_flatmap_matches.pts:1)
    at /tmp/h05r3.OCtU/r2all/repro/F1c_typed_flatmap_matches.pts:1
exit=1
