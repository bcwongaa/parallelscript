[ 'ab', 'a', 'b', 'b', <1 empty item>, 'b' ]
exit=0
