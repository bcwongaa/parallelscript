Uncaught TypeError: Expected {x: number | string}, got C
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/repro/F6_interface_class_leaf.pts:4)
    at /tmp/h05r3.OCtU/r2all/repro/F6_interface_class_leaf.pts:4
exit=1
