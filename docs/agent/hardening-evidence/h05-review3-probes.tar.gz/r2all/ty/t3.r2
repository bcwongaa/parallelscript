3 true true true
A 1
B x
A 2
[ 1, 2, 2 ] true
3 true
3 true [ 'sq2', 'ci3', 'sq2' ]
exit=0
