number object
[]
caught TypeError
y 5
caught TypeError
exit=0
