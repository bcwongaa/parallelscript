c4.pts:2:24 - error PTS1001: `Array.from` of a Set<number> | number[] is not supported yet
exit=1
