[ 3 ]
[ Square { s: 1 } ]
[ { x: 1, y: 2 } ]
[ 1, [ 2 ] ]
[ 'a', null ]
[ [ 1, 'a' ] ]
exit=0
