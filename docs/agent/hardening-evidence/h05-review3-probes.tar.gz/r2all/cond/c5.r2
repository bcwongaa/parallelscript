c5.pts:2:28 - error TS2769: No overload matches this call.
  The last overload gave the following error.
    Argument of type '3 | number[]' is not assignable to parameter of type 'ArrayBuffer | ArrayLike<number>'.
      Type 'number' is not assignable to type 'ArrayBuffer | ArrayLike<number>'.
exit=1
