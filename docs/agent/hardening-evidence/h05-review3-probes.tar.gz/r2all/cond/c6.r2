c6.pts:2:37 - error PTS1001: a Map<string, number> of a [string, number][] | null is not supported yet
exit=1
