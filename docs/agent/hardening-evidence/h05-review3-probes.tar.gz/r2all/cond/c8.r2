c8.pts:2:29 - error PTS1001: a Set<number> of a number[] | undefined is not supported yet
c8.pts:4:28 - error PTS1001: the items of a Set<number> | number[] are not supported yet
exit=1
