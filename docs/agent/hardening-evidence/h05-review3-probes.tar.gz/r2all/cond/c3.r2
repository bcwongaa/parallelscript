c3.pts:2:27 - error PTS1001: object types with an index signature and methods, optional properties or properties of other types (ConcatArray<number>) are not supported yet
c3.pts:2:27 - error PTS1001: converting number | number[] to number is not supported yet
c3.pts:3:27 - error PTS1001: object types with an index signature and methods, optional properties or properties of other types (ConcatArray<number>) are not supported yet
c3.pts:3:27 - error PTS1001: converting number | number[] to number is not supported yet
exit=1
