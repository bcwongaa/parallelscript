[ 1 ]
[ 2 ]
[ 'a', 3 ]
[ true ]
exit=0
