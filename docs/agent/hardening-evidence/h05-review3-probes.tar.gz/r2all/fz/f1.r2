[ 1, 2, 3 ]
2 true
3 false
true false
[ 1, 2, 9 ]
[ 1, 2, 1, 2 ] [ 1, 2 ]
exit=0
