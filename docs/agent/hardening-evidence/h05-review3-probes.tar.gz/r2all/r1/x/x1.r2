3 [ 'b', undefined, 'b' ] 3
[ 'b', undefined, 'b' ]
[ 'b', undefined, 'b' ]
[ 'a', ',', undefined, 'b' ] [ 'a', ',', undefined, 'b' ]
[ 'b', undefined, 'b' ] [ 'b', undefined, 'b' ]
exit=0
