[ 'b', 'none', 'b' ]
[ 'b', undefined, 'b' ]
exit=0
