[ true, '2', 2 ]
exit=0
