s2.pts:3:56 - error PTS1001: converting number | number[] to (number | string)[] | number | string is not supported yet
exit=1
