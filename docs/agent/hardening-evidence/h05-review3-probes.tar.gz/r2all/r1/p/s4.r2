[ 1, [ 7, 8 ] ]
true
exit=0
