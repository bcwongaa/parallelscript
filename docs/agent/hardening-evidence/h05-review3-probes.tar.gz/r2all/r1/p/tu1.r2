tu1.pts:2:40 - error PTS1001: `flatMap` with a callback that returns a [number, string] is not supported yet: JS's flatMap spreads it into the result, which TypeScript types as a [number, string][] as if it didn't; return it in an array to keep it whole
exit=1
