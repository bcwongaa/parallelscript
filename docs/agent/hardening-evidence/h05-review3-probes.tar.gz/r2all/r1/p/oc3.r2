[ 1, 2, 3 ] undefined
[ 1, 2, 3 ]
exit=0
