r2.pts:2:31 - error TS2322: Type '(string | number)[] | boolean[]' is not assignable to type 'string | number | readonly (string | number)[]'.
  Type 'boolean[]' is not assignable to type 'string | number | readonly (string | number)[]'.
    Type 'boolean[]' is not assignable to type 'readonly (string | number)[]'.
      Type 'boolean' is not assignable to type 'string | number'.
exit=1
