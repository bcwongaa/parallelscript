[ 'a', 'b', 1 ]
exit=0
