[ 1, 'a' ]
Uncaught TypeError: v.push is not a function
    at /tmp/h05r3.OCtU/r2all/r1/u/u4.pts:4
exit=1
