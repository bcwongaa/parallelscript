u2.pts:2:41 - error PTS1001: using a [number, string] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
exit=1
