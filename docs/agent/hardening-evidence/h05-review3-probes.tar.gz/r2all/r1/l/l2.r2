2
3
10
20
exit=0
