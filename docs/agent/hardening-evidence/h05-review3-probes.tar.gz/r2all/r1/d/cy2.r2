Uncaught TypeError: Cannot set property element of Array: expected number, got Array
    at /tmp/h05r3.OCtU/r2all/r1/d/cy2.pts:2
exit=1
