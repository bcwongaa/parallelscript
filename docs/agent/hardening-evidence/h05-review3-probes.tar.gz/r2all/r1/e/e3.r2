[] 0
[]
[]
[]
[ 'a', 'A', 'b', 'B' ]
[ Map(1) { 1 => 2 } ]
[ 'ab', 'c' ]
[ 1, 2 ]
[ null, null ]
exit=0
