e2.pts:2:18 - error PTS1001: `flat` with a depth of -1 is not supported yet: TypeScript's type for its result isn't what JS's flat returns; JS flattens as `flat(0)` does, so write that
exit=1
