k2.pts:2:37 - error PTS2002: 300 doesn't fit in u8 (0 to 255)
exit=1
