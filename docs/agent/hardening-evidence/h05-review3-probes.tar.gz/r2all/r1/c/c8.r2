c8.pts:6:25 - error PTS1001: using a Derived[] as a Base[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
exit=1
