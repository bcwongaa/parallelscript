[ Derived { n: 1, m: 2 } ]
[ Derived { n: 3, m: 2 } ]
exit=0
