keep2.pts:10:10 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
keep2.pts:13:24 - error PTS1001: converting number[] | string to (number | string)[] | string is not supported yet
exit=1
