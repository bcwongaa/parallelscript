[ 0 ]
[ 1, 2 ] big
exit=0
