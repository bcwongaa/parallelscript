15
3
[ Circle { r: 1 } ] none
[ 1 ]
exit=0
