k4.pts:2:18 - error PTS2001: a number doesn't convert to u8 implicitly because the value could change; write `as u8` to convert it
exit=1
