3
caught TypeError
[ 'number', 'number', 'object' ] []
[ 1, 2, 's' ] [ 'number', 'number', 'string' ]
exit=0
