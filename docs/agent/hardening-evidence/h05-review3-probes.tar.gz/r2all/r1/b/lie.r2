caught TypeError: Expected number[], got number
caught TypeError: Expected number, got Array
exit=0
