h1.pts:1:43 - error PTS1001: omitted expression is not supported yet
h1.pts:3:12 - error PTS1001: arrays with holes are not supported yet
h1.pts:5:12 - error PTS1001: arrays with holes are not supported yet
h1.pts:7:11 - error PTS1001: arrays with holes are not supported yet
h1.pts:9:12 - error PTS1001: arrays with holes are not supported yet
h1.pts:11:13 - error PTS1001: arrays with holes are not supported yet
h1.pts:12:13 - error PTS1001: arrays with holes are not supported yet
exit=1
