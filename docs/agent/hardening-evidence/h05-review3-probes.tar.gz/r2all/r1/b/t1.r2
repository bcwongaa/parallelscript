[ 1, 2, undefined, 3, 4 ] 5
[ 1, undefined, true, 2 ]
[ 1, 'a', 'b', 2 ] [ 1, 'a', 'b', 2 ]
[ 1, 2, 'x', 'y' ]
[ [ 1, 'a' ], [ 2, 3 ] ] [ 1, 'a', 2, 3 ] [ 1, 'a', 2, 3 ]
[ 1, 2, [ 3 ] ] [ 1, 2, 3 ]
[ 1, 2 ]
Uncaught RangeError: Invalid array length 4: setting length can only shrink an array (length 2)
    at /tmp/h05r3.OCtU/r2all/r1/b/t1.pts:16
exit=1
