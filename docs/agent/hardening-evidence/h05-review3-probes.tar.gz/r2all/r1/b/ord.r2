arr
depth
[ 1, 2 ]
[ [ 1 ], [ 2 ] ] 1
exit=0
