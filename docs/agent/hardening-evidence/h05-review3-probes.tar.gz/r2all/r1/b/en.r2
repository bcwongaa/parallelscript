en.pts:3:21 - error PTS1001: `flat` with a depth of -1 is not supported yet: TypeScript's type for its result isn't what JS's flat returns; JS flattens as `flat(0)` does, so write that
en.pts:4:21 - error PTS1001: `flat` with a depth of 0.5 is not supported yet: TypeScript's type for its result isn't what JS's flat returns; JS flattens as `flat(0)` does, so write that
en.pts:6:21 - error PTS1001: `flat` with a depth of -1 is not supported yet: TypeScript's type for its result isn't what JS's flat returns; JS flattens as `flat(0)` does, so write that
exit=1
