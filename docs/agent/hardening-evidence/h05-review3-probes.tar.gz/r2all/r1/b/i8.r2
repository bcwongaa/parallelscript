i8.pts:8:7 - error PTS1001: unions of several numeric types (i8 | u8) are not supported yet
i8.pts:4:19 - error PTS1001: unions of several numeric types (u64 | int) are not supported yet
i8.pts:7:29 - error PTS1001: converting number[] to i8[] | u8[] is not supported yet
exit=1
