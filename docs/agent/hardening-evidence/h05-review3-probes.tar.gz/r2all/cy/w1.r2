[
  'RangeError',
  'RangeError',
  'RangeError',
  'RangeError',
  'RangeError',
  'RangeError',
  'RangeError',
  'RangeError'
]
[ 'RangeError', 'RangeError', 'RangeError', 'RangeError' ]
exit=0
