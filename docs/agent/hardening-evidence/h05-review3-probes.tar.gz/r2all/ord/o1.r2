[ 1, 2 ] arr,depth
[ 1, 2 ] arr,depth,arr,d
[ 1, 2 ] arr,depth,arr,d,anyArr,depth
[ 1, 2 ] arr,depth,arr,d,anyArr,depth,arr,getter
exit=0
