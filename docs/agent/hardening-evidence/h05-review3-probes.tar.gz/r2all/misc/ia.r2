false
true
true
exit=0
