Uncaught TypeError: Expected {x: number}, got Object
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/dyn/d1.pts:3)
    at /tmp/h05r3.OCtU/r2all/dyn/d1.pts:3
exit=1
