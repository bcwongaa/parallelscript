Uncaught TypeError: Expected {x: number}, got Object
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/dyn/d14.pts:4)
    at /tmp/h05r3.OCtU/r2all/dyn/d14.pts:4
exit=1
