[ [ 1 ], [ 2 ], [ 3 ] ] 1
Uncaught TypeError: Expected number[][], got Array
    at flatTo (/tmp/h05r3.OCtU/r2all/gen/g3.pts:2)
    at /tmp/h05r3.OCtU/r2all/gen/g3.pts:5
exit=1
