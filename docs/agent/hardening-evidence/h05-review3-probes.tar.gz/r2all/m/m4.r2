[
  'c',
  undefined,
  undefined,
  'c',
  index: 0,
  input: 'c',
  groups: undefined
]
Uncaught TypeError: Expected string, got undefined
    at /tmp/h05r3.OCtU/r2all/m/m4.pts:3
exit=1
