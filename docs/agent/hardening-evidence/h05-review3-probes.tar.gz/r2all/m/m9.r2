[ 'x', 'b', <1 empty item>, 'b' ] true
[ 'y', 'b', <1 empty item>, 'b' ]
exit=0
