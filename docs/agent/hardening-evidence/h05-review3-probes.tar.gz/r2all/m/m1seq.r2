Uncaught TypeError: Expected string, got undefined
    at Array.flatMap (/tmp/h05r3.OCtU/r2all/m/m1seq.pts:4)
    at /tmp/h05r3.OCtU/r2all/m/m1seq.pts:4
exit=1
