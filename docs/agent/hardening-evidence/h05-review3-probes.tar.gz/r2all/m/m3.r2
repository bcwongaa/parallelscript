[ 'a', 'a', undefined, 'b', undefined, 'b' ]
exit=0
