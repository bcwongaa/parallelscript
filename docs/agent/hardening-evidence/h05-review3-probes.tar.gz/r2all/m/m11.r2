caught RangeError Array index 0 is out of range (length 2); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
caught TypeError Expected string, got undefined
exit=0
