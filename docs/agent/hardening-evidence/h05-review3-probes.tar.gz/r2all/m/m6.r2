[ 'c', undefined, undefined, 'c' ]
[
  'c',       undefined,
  undefined, 'c',
  'c',       undefined,
  undefined, 'c'
]
[ 'c', undefined, undefined, 'c' ]
exit=0
