[ undefined, 'b' ]
caught RangeError
caught RangeError
caught RangeError
-b 2 1
[ undefined, 'b', 'q' ] [ undefined, 'b', 'q', 'w' ]
exit=0
