6 1 [ 'b', <1 empty item>, 'b' ]
exit=0
