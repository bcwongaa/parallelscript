Uncaught TypeError: Expected string, got undefined
    at pts:parallel:166
    at ParallelArray.flatMap (pts:parallel:162)
    at /tmp/h05r3.OCtU/r2all/m/m1.pts:4
exit=1
