interface K { x: number; get(): number }
const o: any = { x: 2, get() { return this.x * 10; } };
const r = [1].flatMap<K>(() => [o]);
console.log(r.length, r[0].get());
