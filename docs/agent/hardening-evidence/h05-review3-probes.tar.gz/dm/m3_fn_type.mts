type F = (a: number) => number;
const f: any = (a: number) => a + 1;
const r = [1].flatMap<F>(() => [f]);
console.log(r.length, r[0](1));
