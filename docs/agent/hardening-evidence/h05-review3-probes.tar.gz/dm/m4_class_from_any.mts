class C { constructor(public x: number) {} }
const c: any = new C(5);
const r = [1].flatMap<C>(() => [c]);
console.log(r.length, r[0].x, r[0] === c);
const bad: any = { x: 1 };
try { const s = [1].flatMap<C>(() => [bad]); console.log(s.length); } catch (e) { console.log("caught", (e as Error).message); }
