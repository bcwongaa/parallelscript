interface J { x: number; get(): number }
const o: any = { x: 1, get() { return this.x * 10; } };
const plain: J = o;
console.log(plain.get());
const r = [1].flatMap<J>(() => [o]);
console.log(r.length, r[0].get());
