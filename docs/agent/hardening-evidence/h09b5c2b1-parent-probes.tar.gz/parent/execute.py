import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/bryan/projects/parallelscript')
OUT = Path(__file__).resolve().parent


def source_hashes():
    paths = subprocess.check_output(
        ['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard',
         'pts', 'cmd', 'internal', 'go.mod', 'go.sum', 'Makefile'], cwd=ROOT
    ).decode().split('\0')
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
            for p in sorted(set(paths)) if p and (ROOT / p).is_file()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('label')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command and command[0] == '--':
        command = command[1:]
    before = source_hashes()
    cli = ROOT / 'pts-bin/pts'
    cli_before = hashlib.sha256(cli.read_bytes()).hexdigest() if cli.exists() else None
    started = time.monotonic()
    with (OUT / (args.label + '.out')).open('wb') as stdout, (OUT / (args.label + '.err')).open('wb') as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    after = source_hashes()
    counts = collections.Counter()
    corpus = collections.Counter()
    packages = {}
    for line in (OUT / (args.label + '.out')).read_text().splitlines():
        try:
            event = json.loads(line)
        except (json.JSONDecodeError, ValueError):
            continue
        action, test = event.get('Action'), event.get('Test')
        if action not in ('pass', 'skip', 'fail'):
            continue
        if test:
            counts[action] += 1
            if test.startswith('TestCorpusMatchesNode/'):
                corpus[action] += 1
        else:
            packages[event.get('Package', '')] = action
    receipt = {
        'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - started,
        'tests': dict(counts), 'corpus': dict(corpus), 'packages': packages,
        'source_count': len(before), 'sources_unchanged': before == after,
        'changed_sources': [p for p in sorted(set(before) | set(after)) if before.get(p) != after.get(p)],
        'cli_before': cli_before,
        'cli_after': hashlib.sha256(cli.read_bytes()).hexdigest() if cli.exists() else None,
        'stderr_bytes': (OUT / (args.label + '.err')).stat().st_size,
    }
    (OUT / (args.label + '.before.json')).write_text(json.dumps(before, indent=2) + '\n')
    (OUT / (args.label + '.after.json')).write_text(json.dumps(after, indent=2) + '\n')
    (OUT / (args.label + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
