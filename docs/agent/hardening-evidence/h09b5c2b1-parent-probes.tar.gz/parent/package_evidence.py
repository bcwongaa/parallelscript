import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path('/home/bryan/projects/parallelscript')
scratch = Path(__file__).resolve().parent
evidence = repo / 'docs/agent/hardening-evidence'
suite = json.loads((scratch / 'final-suite-complete.receipt.json').read_text())
assert suite['exit'] == 0 and suite['sources_unchanged'] and suite['cli_before'] == suite['cli_after']
assert not suite['tests'].get('fail') and suite['stderr_bytes'] == 0
assert sum(status == 'pass' for status in suite['packages'].values()) == 10
assert set(suite['packages'].values()) <= {'pass', 'skip'}
assert suite['corpus'] == {'pass': 263, 'skip': 37}

files = {}
allowed = {'.json', '.jsonl', '.py', '.md', '.pts', '.mts', '.go', '.out', '.err'}
for p in sorted(scratch.iterdir()):
    if p.is_file() and not p.is_symlink() and p.suffix in allowed:
        files['parent/' + p.name] = p
for name in ['/tmp/h09b5c2b1-mutant.1m8afb_0', '/tmp/h09b5c2b1-mutant.y9a1q2yy', '/tmp/h09b5c2b1-parent-observation.cj202j9x', '/tmp/h09b5c2b1-parent-native.5fd03ekb']:
    root = Path(name)
    assert root.is_dir(), root
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in allowed:
            files[root.name + '/' + str(p.relative_to(root))] = p
# Additional replay outputs are registered by their actual path, never a fixed prior-run marker.
controls = scratch / 'parent-controls-output.json'
if controls.exists():
    root = Path(json.loads(controls.read_text())['directory'])
    for p in sorted(root.rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in allowed:
            files['parent-controls/' + str(p.relative_to(root))] = p
for name in ['pts/lower/containing_code.go', 'pts/lower/narrowing.go', 'pts/lower/lower.go', 'pts/lower/containing_code_test.go', 'pts/lower/containing_code_caps_test.go', 'pts/driver/containing_code_caps_test.go', 'pts/tests/compiler_smoke_test.go', 'pts/tests/run/generic_containing_value_pairing.pts']:
    files['snapshot/' + name] = repo / name
archive = evidence / 'h09b5c2b1-parent-probes.tar.gz'
stream = evidence / 'h09b5c2b1-final-suite.jsonl.gz'
manifest_path = evidence / 'h09b5c2b1-artifacts.json'
assert not archive.exists() and not stream.exists() and not manifest_path.exists()
index = {name: {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size} for name, path in files.items()}
with tarfile.open(archive, 'w:gz') as target:
    for name, path in files.items():
        data = path.read_bytes()
        entry = tarfile.TarInfo(name)
        entry.mode = 0o644
        entry.size = len(data)
        target.addfile(entry, io.BytesIO(data))
    data = (json.dumps(index, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('index.json')
    entry.mode = 0o644
    entry.size = len(data)
    target.addfile(entry, io.BytesIO(data))
with stream.open('wb') as destination:
    destination.write(gzip.compress((scratch / 'final-suite-complete.out').read_bytes(), mtime=0))
artifacts = {}
for name in ['h09b5c2b1-parent-probes.tar.gz', 'h09b5c2b1-reproducer-probes.tar.gz', 'h09b5c2b1-review-probes.tar.gz', 'h09b5c2b1-final-suite.jsonl.gz']:
    path = evidence / name
    artifacts[name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
    if name.endswith('.tar.gz'):
        with tarfile.open(path, 'r:gz') as source:
            members = source.getmembers()
            names = set()
            for member in members:
                parts = Path(member.name)
                assert not parts.is_absolute() and '..' not in parts.parts and member.name not in names
                names.add(member.name)
                assert member.isfile() or member.isdir()
                assert not member.issym() and not member.islnk()
                assert not member.name.endswith(('.bin', '.exe', '.tar.gz', '.zip'))
            artifacts[name]['regular_files'] = sum(m.isfile() for m in members)
manifest = {'date': '2026-10-22', 'source_base': '9e60deebfd6a6b26d24224fdbe9753750ab8e6f0', 'ci': 'pending; not polled', 'final_suite': suite, 'artifacts': artifacts}
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
