import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/home/bryan/projects/parallelscript')
out = Path(__file__).resolve().parent
mapping = {}
hashes = {}
for relative in ['pts/lower/lower.go', 'pts/lower/narrowing.go']:
    data = subprocess.check_output(['git', 'show', '9e60deebf:' + relative], cwd=root)
    destination = out / ('base-' + Path(relative).name)
    destination.write_bytes(data)
    mapping[str(root / relative)] = str(destination)
    hashes[relative] = hashlib.sha256(data).hexdigest()
# New internal implementation/model tests do not exist on the source baseline. The
# externally designed public-API source/driver regressions remain included unchanged.
for relative in ['pts/lower/containing_code.go', 'pts/lower/containing_code_test.go']:
    mapping[str(root / relative)] = ''
(out / 'base-overlay.json').write_text(json.dumps({'Replace': mapping}, indent=2) + '\n')
(out / 'base-overlay-sources.json').write_text(json.dumps({'base': '9e60deebf', 'sha256': hashes}, indent=2) + '\n')
print(out / 'base-overlay.json')
