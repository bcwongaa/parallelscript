import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('sources', nargs='+')
args = parser.parse_args()
repo = Path('/home/bryan/projects/parallelscript')
out = Path(tempfile.mkdtemp(prefix='h09b5c2b1-parent-native.'))
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo))
clis = {'base': Path('/tmp/h09b5c2b.8x5wR1nC/base-pts'), 'current': repo / 'pts-bin/pts'}
results = []

def run(command, timeout=120):
    try:
        result = subprocess.run([str(x) for x in command], cwd=repo, env=env, capture_output=True, text=True, timeout=timeout)
        return {'command': [str(x) for x in command], 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    except subprocess.TimeoutExpired:
        return {'command': [str(x) for x in command], 'exit': 'TIMEOUT'}

sources = []
for name in args.sources:
    source = Path(name).resolve()
    sources.extend(sorted(source.glob('*.pts')) if source.is_dir() else [source])
for index, source in enumerate(sources):
    case = out / (str(index) + '-' + source.stem)
    case.mkdir()
    pts = case / 'main.pts'
    mts = case / 'main.mts'
    pts.write_bytes(source.read_bytes())
    mts.write_bytes(source.read_bytes())
    row = {'source': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'node': run(['/home/bryan/.local/node/bin/node', '--no-warnings', '--experimental-transform-types', mts])}
    for label, cli in clis.items():
        binary = case / (label + '.bin')
        entry = {'build': run([cli, 'build', pts, '-o', binary])}
        if entry['build']['exit'] == 0:
            entry['run'] = run([binary], timeout=20)
            entry['node_match'] = all(entry['run'].get(key) == row['node'].get(key) for key in ('exit', 'stdout'))
        binary.unlink(missing_ok=True)
        row[label] = entry
    results.append(row)
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(source.name, 'node', row['node']['exit'], 'base', row['base'].get('node_match'), 'current', row['current'].get('node_match'), flush=True)
print('results', out / 'results.json')
print('summary', json.dumps({label: sum(row[label].get('node_match', False) for row in results) for label in clis}))
raise SystemExit(1 if any(row[label]['build']['exit'] != 0 for row in results for label in clis) or any(row['base'].get('node_match') and not row['current'].get('node_match') for row in results) else 0)
