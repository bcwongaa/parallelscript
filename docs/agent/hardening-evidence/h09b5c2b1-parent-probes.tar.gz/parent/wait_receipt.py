import ctypes
import json
import os
from pathlib import Path
import select
import sys
import time

path = Path(sys.argv[1]).resolve()
libc = ctypes.CDLL(None, use_errno=True)
fd = libc.inotify_init1(os.O_CLOEXEC)
if fd < 0:
    raise OSError(ctypes.get_errno(), 'inotify_init1')
try:
    if libc.inotify_add_watch(fd, os.fsencode(path.parent), 0x8 | 0x80 | 0x100) < 0:
        raise OSError(ctypes.get_errno(), 'inotify_add_watch')
    deadline = time.monotonic() + 570
    while not path.is_file():
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not select.select([fd], [], [], remaining)[0]:
            print('Receipt not complete yet; tracked task remains authoritative.')
            break
        os.read(fd, 65536)
    else:
        print(json.dumps(json.loads(path.read_text()), indent=2))
finally:
    os.close(fd)
