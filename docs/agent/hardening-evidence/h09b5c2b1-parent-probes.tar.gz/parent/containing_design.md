# H09b5c2b1 implementation design (before production edits)

Keep pairing/site raw identity and intrinsic levels unchanged. Register every occurrence with its demand-code and value-code substitutions (actual instanceUse, never here/statementSites). Record site occurrences before checking exclusions. Duplicate contexts form an OR; each occurrence requires both demand and value code.

After complete lowering, compute availability with a bounded positive graph: a substitution needs any completed user AND its enclosing class; a pairing needs its intrinsic level AND any registered containing occurrence. Program-owned/unknown sources seed DeclaredInstances, unregistered pairs seed their raw level. Report-only statementSites uses must be marked and treated as unknown/live for availability (existing report-blame behavior unchanged). Fixed-point propagation from absent handles cycles without stale partial cuts. A level rises at most three times. Cap storage and graph node+rule count at 100,000; exhaustion disables cap proof and leaves raw levels.

Store effective levels separately in Narrowing; leavesOut/identity continue using raw keys. Within uses effective levels. Compute caps after all users/descriptor hits are known. Retain trial rollback, source-flow pruning, any checks, checker identity, and fallback order.

Required tests: genuine source-language RED; shared own/Value users before/after; unit late descriptor reuse, value containment, AST-shared sites, class AND, seeded/unseeded cycles, statement heuristics, unknown and both storage/graph bounds; independent brute-force small-graph availability oracle. Named reviewer of new caps only.
