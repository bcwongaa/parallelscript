import json
from pathlib import Path
import subprocess
import tempfile

root = Path('/home/bryan/projects/parallelscript')
out = Path(__file__).resolve().parent
source = root / 'pts/lower/containing_code.go'
text = source.read_text()
mutants = [
    ('and-as-or', 'level = min(level, rule.other.level)', 'level = max(level, rule.other.level)'),
    ('first-context', 'if c.pairings[p][context] {', 'if len(c.pairings[p]) > 0 {'),
]
results = []
for label, old, new in mutants:
    assert text.count(old) == 1
    directory = Path(tempfile.mkdtemp(prefix='h09b5c2b1-mutant.'))
    changed = directory / 'containing_code.go'
    changed.write_text(text.replace(old, new, 1))
    overlay = directory / 'overlay.json'
    overlay.write_text(json.dumps({'Replace': {str(source): str(changed)}}))
    result = subprocess.run([
        'python3', '-I', str(out / 'execute.py'), 'mutant-' + label, '--',
        'env', 'GOMAXPROCS=1', 'go', 'test', '-count=1', '-json',
        '-overlay', str(overlay), '-p', '1', '-parallel', '1',
        '-run', 'TestContaining', './pts/lower'
    ], cwd=root)
    rows = [json.loads(line) for line in (out / ('mutant-' + label + '.out')).read_text().splitlines()]
    failed = [e['Test'] for e in rows if e.get('Test') and e.get('Action') == 'fail']
    build_failed = any('build failed' in e.get('Output', '') for e in rows)
    results.append({'mutant': label, 'exit': result.returncode, 'failed_tests': failed,
                    'build_failed': build_failed, 'directory': str(directory)})
    assert result.returncode == 1 and failed and not build_failed, results[-1]
(out / 'mutation-results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
