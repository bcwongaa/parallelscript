import hashlib
import json
from pathlib import Path
import tempfile

repo = Path('/home/bryan/projects/parallelscript')
archive = Path('/tmp/h09b5c2b1-unpacked.4mq_b0h0')
out = Path(tempfile.mkdtemp(prefix='h09b5c2b1-parent-observation.'))
current = (repo / 'pts/lower/lower.go').read_text()
needle = '\tl.unexplainedFailure()\n\treturn result, l.errors, l.narrower()'
assert current.count(needle) == 1
instrumented = current.replace(needle, '\tl.unexplainedFailure()\n\treviewLastLowering = l\n\treturn result, l.errors, l.narrower()') + '\nvar reviewLastLowering *lowerer\n'
assert instrumented == (archive / 'instrumented-lower.go').read_text()
(out / 'lower.go').write_text(instrumented)
test = (archive / 'c251_review_test.go').read_text()
needle = 'filepath.Glob("/tmp/c251-caps-review.2Pez0ecw/cases/*.pts")'
assert test.count(needle) == 1
test = test.replace(needle, 'filepath.Glob(filepath.Join(os.Getenv("C251_REVIEW_CASES"), "*.pts"))')
needle = ' sort.Strings(paths)'
assert test.count(needle) == 1
test = test.replace(needle, ' if len(paths) != 14 { t.Fatalf("expected 14 retained cases, got %d", len(paths)) }\n sort.Strings(paths)')
(out / 'review_test.go').write_text(test)
replace = {str(repo / 'pts/lower/lower.go'): str(out / 'lower.go'), str(repo / 'pts/lower/c251_parent_observation_test.go'): str(out / 'review_test.go')}
(out / 'overlay.json').write_text(json.dumps({'Replace': replace}, indent=2) + '\n')
(out / 'sha256.json').write_text(json.dumps({name: hashlib.sha256((out / name).read_bytes()).hexdigest() for name in ('lower.go', 'review_test.go', 'overlay.json')}, indent=2) + '\n')
print(out / 'overlay.json')
