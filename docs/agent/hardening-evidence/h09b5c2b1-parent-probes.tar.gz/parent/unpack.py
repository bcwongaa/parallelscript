import hashlib
from pathlib import Path, PurePosixPath
import sys
import tarfile
import tempfile

archive = Path(sys.argv[1]).resolve()
destination = Path(tempfile.mkdtemp(prefix='h09b5c2b1-unpacked.'))
files = 0
with tarfile.open(archive, 'r:*') as source:
    for member in source.getmembers():
        path = PurePosixPath(member.name)
        if path.is_absolute() or '..' in path.parts or member.issym() or member.islnk():
            raise ValueError('unsafe member: ' + member.name)
        if member.isdir():
            continue
        if not member.isfile():
            raise ValueError('non-file member: ' + member.name)
        target = destination.joinpath(*path.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            raise ValueError('duplicate member: ' + member.name)
        with source.extractfile(member) as data:
            target.write_bytes(data.read())
        files += 1
print('archive_sha256', hashlib.sha256(archive.read_bytes()).hexdigest())
print('files', files)
print('destination', destination)
