package lower

import (
 "os"
 "path/filepath"
 "sort"
 "testing"

 "github.com/microsoft/typescript-go/internal/vfs/vfstest"
 "github.com/microsoft/typescript-go/pts/check"
 "github.com/microsoft/typescript-go/pts/frontend"
)

// Review-only observation hook: compare completed caps to registrations in independent
// later fallbacks of the same checked program. A proven cap must not hide a live later
// occurrence with the same raw pairing key.
func TestC251ReviewCrossFallbackContexts(t *testing.T) {
 paths, err := filepath.Glob(filepath.Join(os.Getenv("C251_REVIEW_CASES"), "*.pts"))
 if err != nil { t.Fatal(err) }
 if len(paths) != 14 { t.Fatalf("expected 14 retained cases, got %d", len(paths)) }
 sort.Strings(paths)
 for _, path := range paths {
  t.Run(filepath.Base(path), func(t *testing.T) {
   source, err := os.ReadFile(path)
   if err != nil { t.Fatal(err) }
   program, diagnostics := frontend.Load(t.Context(), vfstest.FromMap(map[string]string{"/p/main.pts":string(source)}, true), "/p/main.pts")
   if len(diagnostics) != 0 { t.Fatalf("frontend: %v", diagnostics) }
   info, diagnostics := check.Program(t.Context(), program)
   if len(diagnostics) != 0 { t.Fatalf("check: %v", diagnostics) }
   _, diagnostics, narrowing := ProgramWith(t.Context(), program, info, AllInstances, nil)
   all := reviewLastLowering
   keys := map[pairing]bool{}
   for p := range all.containing.pairings { keys[p] = true }
   caps := all.containing.levels(keys)
   t.Logf("all diagnostics=%d keys=%d cut=%d withinValue=%v", len(diagnostics), len(keys), narrowing.Len(), narrowing.Within(nil, ValueInstances))
   for _, at := range []Specialization{ValueInstances, DeclaredInstances} {
    _, laterDiagnostics, _ := ProgramWith(t.Context(), program, info, at, nil)
    later := reviewLastLowering
    laterKeys := map[pairing]bool{}
    for p := range later.containing.pairings { laterKeys[p] = true }
    laterCaps := later.containing.levels(laterKeys)
    if len(laterDiagnostics) != 0 { t.Logf("fallback=%d diagnostics=%v", at, laterDiagnostics) }
    for p := range laterKeys {
     if keys[p] && caps != nil && laterCaps != nil && caps[p] < at && laterCaps[p] >= at {
      t.Errorf("fallback=%d raw key capped at %d in All but live later (later diagnostics=%d): site=%d name=%q intrinsic=%d signature=%q owner=%q, call=%v value=%v", at, caps[p], len(laterDiagnostics), p.site, p.name, p.level, p.signature, p.owner, p.call, p.value)
     }
    }
   }
  })
 }
}
