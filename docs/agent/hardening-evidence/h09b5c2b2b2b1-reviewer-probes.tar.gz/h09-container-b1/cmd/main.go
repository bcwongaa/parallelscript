package main

import (
    "context"
    "fmt"
    "os"
    "path/filepath"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
    if len(os.Args) != 4 { fmt.Fprintln(os.Stderr, "usage: probe emit|native|default source output"); os.Exit(2) }
    ctx := context.Background()
    if os.Args[1] == "default" {
        if err := driver.Build(ctx, os.Args[2], os.Args[3]); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
        return
    }
    code, err := driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    output, err := filepath.Abs(os.Args[3])
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    cfile := output
    if os.Args[1] == "native" { cfile += ".c" }
    if err := os.WriteFile(cfile, []byte(code), 0600); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    if os.Args[1] == "emit" { return }
    if os.Args[1] != "native" { fmt.Fprintln(os.Stderr, "unknown mode"); os.Exit(2) }
    tc, err := toolchain.New()
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    rt, err := tc.Runtime(ctx, toolchain.Release)
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    if err := tc.CompileProgram(ctx, rt, []string{cfile}, output); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
}
