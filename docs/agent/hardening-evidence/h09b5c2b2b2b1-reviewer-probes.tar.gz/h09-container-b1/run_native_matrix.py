import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

scratch = pathlib.Path(__file__).resolve().parent
root = scratch.parents[1]
env = dict(os.environ, GOMAXPROCS="1", PTS_HOME="/home/bryan/projects/parallelscript")
prelude = '''class Box<T> { constructor(public value: T, public origin: string) {} }
class C0 { tag = 7; }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function source0<T>(value: T): Box<T> { return new Box(value, "source0"); }
function source1<T>(value: T): Box<T> { return new Box(value, "source1"); }
function source2<T>(value: T): Box<T> { return new Box(value, "source2"); }
const keep: any[] = [source0, source1, source2];
class M0 implements Maker { calls = 0; constructor(public label = "M0") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M1 implements Maker { calls = 0; constructor(public label = "M1") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M2 implements Maker { calls = 0; constructor(public label = "M2") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class Child extends M0 {}
function choose(): boolean { return true; }
function use(f: Factory): void { const b: Box<C0> = f(new C0()); console.log(b.origin, b.value.tag); }
function useReceiver(r: Maker): void { const b: Box<C0> = r.make(new C0()); console.log(b.origin, b.value.tag); }
function read(r: Maker): Factory { return r.make.bind(r); }
function pass(f: Factory): Factory { return f; }
'''
# expected rows are semantic sources; None means compatible-pair retention or native-only control.
cases = [
 ("function_object", "const held = { f: source0, other: source1 }; use(held.f);", "function", [0]),
 ("function_fresh_object", "use(({ f: source0, other: source1 }).f);", "function", [0]),
 ("function_array", "const held: Factory[] = [source0, source1]; use(held[0]);", "function", [0]),
 ("function_fresh_array", "use([source0, source1][0]);", "function", [0]),
 ("function_key_hex_mixed_unsupported", "const held = { 0x1: source0, '0x1': source1 }; use(held[1]);", "function", [0]),
 ("function_key_hex", "const held = { 0x1: source0, 2: source1 }; use(held[1]);", "function", [0]),
 ("function_key_escaped", "const held = { 'f\\u006fo': source0 }; use(held.foo);", "function", [0]),
 ("function_parameter", "function projected(f: Factory): Factory { const held = { f }; return held.f; } use(projected(source0));", "function", [0]),
 ("function_return", "function projected(): Factory { const held = { f: source0 }; return held.f; } use(projected());", "function", [0]),
 ("function_bound", "const held = { f: source0.bind(undefined) }; use(held.f);", "function", [0]),
 ("function_alias_mutation", "const held = { f: source0 }; const alias = held; alias.f = source1; use(held.f);", "function", [0,1,2]),
 ("function_direct_mutation", "const held = { f: source0 }; held.f = source1; use(held.f);", "function", [0,1,2]),
 ("function_closure_mutation", "const held = { f: source0 }; function replace(): void { held.f = source1; } replace(); use(held.f);", "function", [0,1,2]),
 ("function_array_mutation", "const held: Factory[] = [source0, source1]; held.reverse(); use(held[0]);", "function", [0,1,2]),
 ("function_nested_container", "const held = { inner: { f: source0 } }; use(held.inner.f);", "function", [0,1,2]),
 ("function_dynamic_origin", "const held: any = { f: source1 }; const f: Factory = held.f; use(f);", "function", [0,1,2]),
 ("function_typed_adapter", "const held: { f: (v: C0) => Box<C0> } = { f: source0 }; const b = held.f(new C0()); console.log(b.origin, b.value.tag);", "function", None),
 ("receiver_object", "const held: { r: Maker } = { r: new M0() }; useReceiver(held.r);", "receiver", [0]),
 ("receiver_array", "const held: Maker[] = [new M0(), new M1()]; useReceiver(held[0]);", "receiver", [0]),
 ("receiver_fresh_object", "useReceiver(({ r: new M0() }).r);", "receiver", [0]),
 ("receiver_projected_return", "function projected(): Maker { const held = { r: new M0() }; return held.r; } useReceiver(projected());", "receiver", [0]),
 ("receiver_inherited", "const held = { r: new Child() }; useReceiver(held.r);", "receiver", [0]),
 ("receiver_alias_mutation", "const held: { r: Maker } = { r: new M0() }; const alias = held; alias.r = new M1(); useReceiver(held.r);", "receiver", [0,1,2]),
 ("captured_receiver_object", "const held: { r: Maker } = { r: new M0() }; use(read(held.r));", "receiver", [0]),
 ("captured_receiver_array", "const held: Maker[] = [new M0(), new M1()]; use(read(held[0]));", "receiver", [0]),
 ("captured_receiver_field_wrapper", "const held: { r: Maker } = { r: new M0() }; const functions = { f: held.r.make.bind(held.r) }; use(functions.f);", "receiver", [0]),
 ("captured_receiver_actual_bind", "const held: { lookup: Maker; actual: Maker } = { lookup: new M0(), actual: new M1() }; const functions = { f: held.lookup.make.bind(held.actual) }; use(functions.f);", "receiver", [1]),
 ("captured_receiver_shared_site", "function capture(r: Maker): Factory { const held = { r }; return held.r.make.bind(held.r); } const a = capture(new M0('a')); const b = capture(new M1('b')); use(a); use(b); use(a);", "receiver", [0,1]),
]

def command(cmd, timeout=120):
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env, cwd=root)
    return {"cmd": [str(x) for x in cmd], "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}

records = []
problems = []
inputs = scratch / "native-inputs"
inputs.mkdir(exist_ok=True)
for name, body, kind, expected in cases:
    source = inputs / (name + ".pts")
    # Unused source consumers still lower demands. Do not let a deliberately uncalled
    # consumer add an unrelated unknown receiver/function demand to a precision case.
    case_prelude = prelude
    if kind == "function" or "useReceiver(" not in body:
        case_prelude = re.sub(r"^function useReceiver[^\n]*\n", "", case_prelude, flags=re.M)
    if "use(" not in body:
        case_prelude = re.sub(r"^function use\([^\n]*\n", "", case_prelude, flags=re.M)
        case_prelude = re.sub(r"^function read\([^\n]*\n", "", case_prelude, flags=re.M)
    source.write_text(case_prelude + body + "\n")
    mts = source.with_suffix(".mts")
    mts.write_bytes(source.read_bytes())
    node = command(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--disable-warning=ExperimentalWarning", mts], 20)
    record = {"name": name, "source": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest(), "kind": kind, "expected_rows": expected, "node": node}
    for version in ("base", "current"):
        output = inputs / (name + "." + version + ".bin")
        built = command([scratch / (version + "-probe"), "native", source, output])
        result = {"build": built}
        if built["returncode"] == 0:
            result["run"] = command([output], 20)
            code = pathlib.Path(str(output) + ".c").read_text()
            pattern = r"\bpts_fn_source([0-2])_C0\(" if kind == "function" else r"\bpts_fn_M([0-2])_make_C0\("
            result["rows"] = sorted(set(int(x) for x in re.findall(pattern, code)))
            result["c_sha256"] = hashlib.sha256(code.encode()).hexdigest()
            result["c_bytes"] = len(code.encode())
            output.unlink()
        record[version] = result
    base = record["base"]
    cur = record["current"]
    matches = cur.get("run", {}).get("returncode") == node["returncode"] == 0 and cur["run"]["stdout"] == node["stdout"] and cur["run"]["stderr"] == ""
    record["current_matches_node"] = matches
    record["base_matches_node"] = base.get("run", {}).get("returncode") == node["returncode"] == 0 and base["run"]["stdout"] == node["stdout"] and base["run"]["stderr"] == ""
    if not matches and record["base_matches_node"]:
        problems.append(name + ": native regression")
    if cur["build"]["returncode"] == 0 and expected is not None and cur["rows"] != expected:
        problems.append(name + ": wrong pair rows " + str(cur["rows"]) + " expected " + str(expected))
    records.append(record)
    (scratch / "native-matrix-results.json").write_text(json.dumps({"records": records, "problems": problems}, indent=2) + "\n")
    print(json.dumps({"name":name, "base_build":base["build"]["returncode"], "current_build":cur["build"]["returncode"], "base_rows":base.get("rows"), "current_rows":cur.get("rows"), "base_node_match":record["base_matches_node"], "current_node_match":matches}), flush=True)
# Existing frozen fixtures exercise evaluation order and real bound capture state too.
for relative in ("pts/tests/run/generic_literal_projection_sources.pts", "pts/tests/run/generic_literal_projection_unknowns.pts", "pts/tests/run/generic_containing_value_pairing.pts", "pts/tests/run/generic_fallback_spares_unrelated_total.pts"):
    source = root / relative
    name = source.stem
    local = inputs / (name + ".pts")
    local.write_bytes(source.read_bytes())
    mts = local.with_suffix(".mts")
    mts.write_bytes(local.read_bytes())
    node = command(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--disable-warning=ExperimentalWarning", mts], 20)
    record = {"name":name,"source":str(local),"node":node}
    for version in ("base", "current"):
        output = inputs / (name + "." + version + ".bin")
        built = command([scratch / (version + "-probe"), "native", local, output])
        result = {"build":built}
        if built["returncode"] == 0:
            result["run"] = command([output],20)
            output.unlink()
        record[version] = result
    record["base_matches_node"] = record["base"].get("run",{}).get("returncode") == node["returncode"] == 0 and record["base"]["run"]["stdout"] == node["stdout"]
    record["current_matches_node"] = record["current"].get("run",{}).get("returncode") == node["returncode"] == 0 and record["current"]["run"]["stdout"] == node["stdout"]
    if record["base_matches_node"] and not record["current_matches_node"]: problems.append(name + ": fixture regression")
    records.append(record)
    (scratch / "native-matrix-results.json").write_text(json.dumps({"records":records,"problems":problems},indent=2)+"\n")
    print(json.dumps({"name":name,"base_build":record["base"]["build"]["returncode"],"current_build":record["current"]["build"]["returncode"],"base_node_match":record["base_matches_node"],"current_node_match":record["current_matches_node"]}),flush=True)
print(json.dumps({"total":len(records),"base_node_matches":sum(x["base_matches_node"] for x in records),"current_node_matches":sum(x["current_matches_node"] for x in records),"problems":problems}),flush=True)
sys.exit(bool(problems))
