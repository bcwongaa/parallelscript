package lower

import (
    "testing"
    "gotest.tools/v3/assert"
)

func TestReviewContainerInstantiationWrapperControls(t *testing.T) {
    prelude := `type Value = () => void;
function first(): void {} function second(): void {}
`
    cases := []struct { name, body string; known bool }{
        {"tag_preserves_container_this", "function replace<T>(this: {value: Value}, _strings: TemplateStringsArray): void { this.value = second; } const held = {value: first, replace}; (held.replace<number>)``; const probe = held.value; probe;", false},
        {"array_call_preserves_container_this", "function replace<T>(this: {0: Value}, _x: T): void { this[0] = second; } const held: [Value, typeof replace] = [first, replace]; (held[1]<number>)(1); const probe = held[0]; probe;", false},
        {"asserted_call_preserves_container_this", "function replace<T>(this: {value: Value}, _x: T): void { this.value = second; } const held = {value: first, replace}; ((held.replace<number>) as (x: number) => void)(1); const probe = held.value; probe;", false},
        {"extracted_instantiation_is_not_implicit_this", "function replace<T>(this: {value: Value}, _x: T): void { this.value = second; } const held = {value: first, replace}; const extracted = held.replace<number>; extracted; const probe = held.value; probe;", true},
    }
    for _, tt := range cases {
        t.Run(tt.name, func(t *testing.T) {
            l, probe := valueFlowProbe(t, prelude+tt.body)
            steps := maxValueFlowSteps
            got := l.valueSources(probe, &steps, 0)
            if tt.known {
                assert.Assert(t, got != nil)
                assert.DeepEqual(t, returnedSourceNames(got), []string{"first"})
            } else {
                assert.Assert(t, got == nil, "instantiation wrapper hid escape: got %v", returnedSourceNames(got))
            }
        })
    }
}
