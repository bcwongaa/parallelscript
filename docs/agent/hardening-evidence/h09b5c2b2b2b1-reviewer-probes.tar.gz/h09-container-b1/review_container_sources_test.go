package lower

import (
    "fmt"
    "testing"

    "gotest.tools/v3/assert"
)

func TestReviewContainerSourceCompleteUses(t *testing.T) {
    prelude := `function first(this: any): void {} function second(this: any): void {}
function consume(_x: unknown): void {} function choose(): boolean { return true; }
`
    cases := []struct{name, body string; want []string}{
        {"fresh_object", "const probe = ({ f: first }).f; probe;", []string{"first"}},
        {"fresh_array", "const probe = [first][0]; probe;", []string{"first"}},
        {"const_object", "const held = { f: first }; const probe = held.f; probe;", []string{"first"}},
        {"const_array", "const held = [first]; const probe = held[0]; probe;", []string{"first"}},
        {"shorthand", "const held = { first }; const probe = held.first; probe;", []string{"first"}},
        {"projected_alias", "const held = { f: first }; const f = held.f; const probe = f; probe;", []string{"first"}},
        {"selected_return", "function make(): () => void { return first; } const held = { f: make() }; const probe = held.f; probe;", []string{"first"}},
        {"projected_return", "const held = { f: first }; function make(): () => void { return held.f; } const probe = make(); probe;", []string{"first"}},
        {"closed_selected_parameter", "function use(probe: () => void): void { probe; } const held = { f: first }; use(held.f);", []string{"first"}},
        {"merged_selected_value", "const held = { f: choose() ? first : second }; const probe = held.f; probe;", []string{"first", "second"}},
        {"exported_const", "export const held = { f: first }; const probe = held.f; probe;", nil},
        {"exported_alias", "const held = { f: first }; export { held as exposed }; const probe = held.f; probe;", nil},
        {"container_alias", "const held = { f: first }; const alias = held; const probe = held.f; probe;", nil},
        {"container_parameter", "function use(held: { f: () => void }): void { const probe = held.f; probe; } use({ f: first });", nil},
        {"returned_container", "function make(): { f: () => void } { return { f: first }; } const held = make(); const probe = held.f; probe;", nil},
        {"nested_container", "const held = { inner: { f: first } }; const probe = held.inner.f; probe;", nil},
        {"explicit_escape", "const held = { f: first }; consume(held); const probe = held.f; probe;", nil},
        {"shorthand_escape", "const held = { f: first }; consume({ held }); const probe = held.f; probe;", nil},
        {"spread_escape", "const held = { f: first }; consume({ ...held }); const probe = held.f; probe;", nil},
        {"return_escape", "const held = { f: first }; function escape(): unknown { return held; } const probe = held.f; probe;", nil},
        {"dynamic_key", "const held = [first]; const index: number = 0; const probe = held[index]; probe;", nil},
        {"other_dynamic_key", "const held = [first]; const index: number = 0; consume(held[index]); const probe = held[0]; probe;", nil},
        {"object_assertion", "const held = ({ f: first } as { f: () => void }); const probe = held.f; probe;", nil},
        {"dynamic_container", "const held: any = { f: first }; const probe = held.f; probe;", nil},
        {"mutable_binding", "let held = { f: first }; const probe = held.f; probe;", nil},
        {"direct_write", "const held = { f: first }; held.f = second; const probe = held.f; probe;", nil},
        {"asserted_write", "const held = { f: first }; (held.f as any) = second; const probe = held.f; probe;", nil},
        {"nonnull_write", "const held = { f: first }; held.f! = second; const probe = held.f; probe;", nil},
        {"satisfies_write", "const held = { f: first }; (held.f satisfies () => void) = second; const probe = held.f; probe;", nil},
        {"destructured_write", "const held = { f: first }; [held.f] = [second]; const probe = held.f; probe;", nil},
        {"destructured_default_write", "const held = { f: first }; [held.f = second] = []; const probe = held.f; probe;", nil},
        {"object_pattern_write", "const held = { f: first }; ({ f: held.f } = { f: second }); const probe = held.f; probe;", nil},
        {"for_of_write", "const held = { f: first }; for (held.f of [second]) {} const probe = held.f; probe;", nil},
        {"captured_write", "const held = { f: first }; function replace(): void { held.f = second; } replace(); const probe = held.f; probe;", nil},
        {"implicit_this_call", "const held = { f: first }; held.f(); const probe = held.f; probe;", nil},
        {"implicit_this_parens", "const held = { f: first }; ((held.f))(); const probe = held.f; probe;", nil},
        {"implicit_this_asserted_call", "const held = { f: first }; (held.f as () => void)(); const probe = held.f; probe;", nil},
        {"implicit_this_nonnull_call", "const held = { f: first }; held.f!(); const probe = held.f; probe;", nil},
        {"implicit_this_optional_call", "const held = { f: first }; held.f?.(); const probe = held.f; probe;", nil},
        {"implicit_this_array_call", "const held = [first]; held[0](); const probe = held[0]; probe;", nil},
        {"getter_sibling", "const held = { f: first, get other(): number { return 1; } }; const probe = held.f; probe;", nil},
        {"setter_sibling", "const held = { f: first, set other(_n: number) {} }; const probe = held.f; probe;", nil},
        {"method_sibling", "const held = { f: first, other(): void {} }; const probe = held.f; probe;", nil},
        {"computed_sibling", "const held = { f: first, ['other']: 1 }; const probe = held.f; probe;", nil},
        {"spread_sibling", "const held = { f: first, ...{ other: 1 } }; const probe = held.f; probe;", nil},
        {"hole_sibling", "const held = [first, , second]; const probe = held[0]; probe;", nil},
        {"array_spread_sibling", "const held = [first, ...[second]]; const probe = held[0]; probe;", nil},
        {"unknown_key", "const held = { f: first }; const probe = (held as any).absent; probe;", nil},
        {"freeze_not_proof", "const held = Object.freeze({ f: first }); const probe = held.f; probe;", nil},
    }
    for _, tt := range cases {
        t.Run(tt.name, func(t *testing.T) {
            l, probe := valueFlowProbe(t, prelude+tt.body)
            steps := maxValueFlowSteps
            got := l.valueSources(probe, &steps, 0)
            if tt.want == nil {
                assert.Assert(t, got == nil, "expected conservative unknown, got %v", returnedSourceNames(got))
            } else {
                assert.Assert(t, got != nil, "expected known sources %v", tt.want)
                assert.DeepEqual(t, returnedSourceNames(got), tt.want)
            }
            assert.Equal(t, len(l.valueFlow.active), 0)
        })
    }
}

func TestReviewContainerReceiverSelections(t *testing.T) {
    prelude := `class A {} class B {} function choose(): boolean { return true; }
`
    cases := []struct{name, body string; want []string}{
        {"fresh_object", "const probe = ({ r: new A() }).r; probe;", []string{"A"}},
        {"fresh_array", "const probe = [new A()][0]; probe;", []string{"A"}},
        {"const_object", "const held = { r: new A() }; const probe = held.r; probe;", []string{"A"}},
        {"const_array", "const held = [new A()]; const probe = held[0]; probe;", []string{"A"}},
        {"union_selected", "const held = { r: choose() ? new A() : new B() }; const probe = held.r; probe;", []string{"A", "B"}},
        {"closed_parameter", "function use(probe: A): void { probe; } const held = { r: new A() }; use(held.r);", []string{"A"}},
        {"ordinary_return", "const held = { r: new A() }; function make(): A { return held.r; } const probe = make(); probe;", []string{"A"}},
        {"dynamic_container", "const held: any = { r: new A() }; const probe = held.r; probe;", nil},
        {"dynamic_selected", "const held: { r: any } = { r: new A() }; const probe = held.r; probe;", nil},
        {"mutable_property", "const held = { r: new A() }; held.r = new B(); const probe = held.r; probe;", nil},
        {"asserted_container", "const held = { r: new A() } as { r: A }; const probe = held.r; probe;", nil},
        {"container_alias", "const held = { r: new A() }; const alias = held; const probe = held.r; probe;", nil},
        {"container_return", "function make(): { r: A } { return { r: new A() }; } const probe = make().r; probe;", nil},
        {"nested_container", "const held = { inner: { r: new A() } }; const probe = held.inner.r; probe;", nil},
    }
    for _, tt := range cases {
        for _, receiverFirst := range []bool{false, true} {
            t.Run(fmt.Sprintf("%s/receiver_first_%t", tt.name, receiverFirst), func(t *testing.T) {
                l, probe := valueFlowProbe(t, prelude+tt.body)
                fn := func() { steps := maxValueFlowSteps; assert.Assert(t, l.valueSources(probe, &steps, 0) == nil) }
                receiver := func() {
                    steps := maxValueFlowSteps
                    got := l.receiverSources(probe, &steps, 0)
                    if tt.want == nil { assert.Assert(t, got == nil) } else {
                        assert.Assert(t, got != nil)
                        assert.DeepEqual(t, returnedSourceNames(got), tt.want)
                    }
                }
                if receiverFirst { receiver(); fn() } else { fn(); receiver() }
                fn(); receiver()
            })
        }
    }
}
