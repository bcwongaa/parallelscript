package lower

import (
 "testing"
 "gotest.tools/v3/assert"
)

func TestReviewContainerInstantiationThisEscape(t *testing.T) {
 for _, call := range []string{"(held.replace<number>)(1)", "((held.replace<number>))(1)", "(held.replace<number>)?.(1)"} {
  t.Run(call, func(t *testing.T) {
   l, probe := valueFlowProbe(t, `type Value = () => void;
function first(): void {} function second(): void {}
function replace<T>(this: {value: Value}, _x: T): void { this.value = second; }
const held = { value: first, replace };
`+call+`; const probe = held.value; probe;`)
   steps := maxValueFlowSteps
   got := l.valueSources(probe, &steps, 0)
   assert.Assert(t, got == nil, "instantiation preserves this binding and must escape; got %v", returnedSourceNames(got))
  })
 }
}
