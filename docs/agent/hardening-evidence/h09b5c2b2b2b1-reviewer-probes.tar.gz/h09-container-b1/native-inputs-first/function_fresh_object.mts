class Box<T> { constructor(public value: T, public origin: string) {} }
class C0 { tag = 7; }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function source0<T>(value: T): Box<T> { return new Box(value, "source0"); }
function source1<T>(value: T): Box<T> { return new Box(value, "source1"); }
function source2<T>(value: T): Box<T> { return new Box(value, "source2"); }
const keep: any[] = [source0, source1, source2];
class M0 implements Maker { calls = 0; constructor(public label = "M0") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M1 implements Maker { calls = 0; constructor(public label = "M1") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M2 implements Maker { calls = 0; constructor(public label = "M2") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class Child extends M0 {}
function choose(): boolean { return true; }
function use(f: Factory): void { const b: Box<C0> = f(new C0()); console.log(b.origin, b.value.tag); }
function useReceiver(r: Maker): void { const b: Box<C0> = r.make(new C0()); console.log(b.origin, b.value.tag); }
function read(r: Maker): Factory { return r.make.bind(r); }
function pass(f: Factory): Factory { return f; }
use(({ f: source0, other: source1 }).f);
