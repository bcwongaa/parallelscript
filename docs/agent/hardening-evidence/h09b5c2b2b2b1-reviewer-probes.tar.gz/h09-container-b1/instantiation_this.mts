class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
function first<T>(value: T): Box<T> { console.log("first"); return new Box(value); }
function second<T>(value: T): Box<T> { console.log("second"); return new Box(value); }
function replace<T>(this: { value: Factory }, _x: T): void { this.value = second; }
const held = { value: first, replace };
(held.replace<number>)(1);
const selected: Factory = held.value;
const result: Box<number> = selected(7);
console.log(result.value);
