package lower

import (
 "fmt"
 "strings"
 "testing"
 "gotest.tools/v3/assert"
)

func TestReviewContainerNormalizedKeysAndCollisions(t *testing.T) {
 prelude := "function first(): void {} function second(): void {}\n"
 for _, numeric := range []string{"1", "0x1", "0o1", "0b1", "1e0", "1.0", "1_0"} {
  canonical := "1"
  if numeric == "1_0" { canonical = "10" }
  for _, tt := range []struct { name, body string; want []string }{
   {"numeric_member_string_read", fmt.Sprintf("const held = { %s: first }; const probe = held[%q]; probe;", numeric, canonical), []string{"first"}},
   {"string_member_numeric_read", fmt.Sprintf("const held = { %q: first }; const probe = held[%s]; probe;", canonical, numeric), []string{"first"}},
   {"normalized_duplicate", fmt.Sprintf("// @ts-ignore: defensive duplicate keys are not executable support\nconst held = { %s: first, %q: second }; const probe = held[%q]; probe;", numeric, canonical, canonical), nil},
  } {
   t.Run(numeric+"/"+tt.name, func(t *testing.T) {
    l, probe := valueFlowProbe(t, prelude+tt.body)
    steps := maxValueFlowSteps
    got := l.valueSources(probe, &steps, 0)
    if tt.want == nil { assert.Assert(t, got == nil) } else { assert.DeepEqual(t, returnedSourceNames(got), tt.want) }
   })
  }
 }
 for _, source := range []string{
  `const held = { "0x1": first, 1: second }; const probe = held["0x1"]; probe;`,
  `const held = { "01": first, 1: second }; const probe = held["01"]; probe;`,
  `const held = { "1e0": first, 1: second }; const probe = held["1e0"]; probe;`,
  `const held = { "ab": first }; const probe = held.ab; probe;`,
  `const held = { "__proto__": first, f: second }; const probe = held.f; probe;`,
 } {
  t.Run(source, func(t *testing.T) {
   l, probe := valueFlowProbe(t, prelude+source); steps := maxValueFlowSteps; got := l.valueSources(probe, &steps, 0)
   if strings.Contains(source, "__proto__") { assert.Assert(t, got == nil) } else { assert.DeepEqual(t, returnedSourceNames(got), []string{"first"}) }
  })
 }
}
