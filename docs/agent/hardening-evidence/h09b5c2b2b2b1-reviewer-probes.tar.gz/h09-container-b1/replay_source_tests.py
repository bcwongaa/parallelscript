#!/usr/bin/env python3
"""Replay independent source-proof tests without modifying repository files.

Run with Python isolated mode. Example:
  python3 -I replay_source_tests.py /absolute/path/to/parallelscript \
      --run '^TestReviewContainerInstantiationThisEscape$'

The repository must already contain the reviewed implementation. This script
creates only an overlay JSON file beside itself and invokes one serial Go test.
Add --snapshot3 to overlay the original production file and reproduce RED.
"""
import argparse
import json
import os
import pathlib
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repository", type=pathlib.Path)
parser.add_argument("--run", default="^TestReview")
parser.add_argument("--receipt", type=pathlib.Path)
parser.add_argument("--snapshot3", action="store_true")
args = parser.parse_args()
root = args.repository.resolve(strict=True)
scratch = pathlib.Path(__file__).resolve().parent
sources = (
    "review_container_sources_test.go",
    "review_container_keys_test.go",
    "review_instantiation_sources_test.go",
    "review_instantiation_extra_test.go",
)
for name in sources:
    if not (scratch / name).is_file():
        raise SystemExit("Missing independent input: " + name)
overlay = scratch / "replay-source-overlay.json"
replacements = {
    str(root / "pts/lower" / name): str(scratch / name)
    for name in sources
}
if args.snapshot3:
    original = scratch / "snapshot3-original/pts/lower/container_sources.go"
    if not original.is_file():
        raise SystemExit("Missing original snapshot3 production input")
    replacements[str(root / "pts/lower/container_sources.go")] = str(original)
overlay.write_text(json.dumps({"Replace": replacements}, indent=2) + "\n")
command = [
    "go", "test", "-count=1", "-json", "-p", "1", "-parallel", "1",
    "-timeout", "15m", "-overlay", str(overlay), "-run", args.run,
    "./pts/lower",
]
print(json.dumps({"cwd": str(root), "command": command}), file=sys.stderr)
env = dict(os.environ, GOMAXPROCS="1")
if args.receipt:
    with args.receipt.open("w") as output:
        result = subprocess.run(command, cwd=root, env=env, stdout=output)
else:
    result = subprocess.run(command, cwd=root, env=env)
sys.exit(result.returncode)
