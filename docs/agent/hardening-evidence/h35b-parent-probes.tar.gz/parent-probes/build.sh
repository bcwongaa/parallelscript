#!/usr/bin/env bash
# Builds every benchmark with a CLI and its PTS_HOME into OUT: build.sh <pts> <home> <out>
set -euo pipefail
pts=$1 home=$2 out=$3
mkdir -p "$out"
for dir in /home/bryan/projects/parallelscript/pts/bench/*/; do
  name=$(basename "$dir")
  [ -f "$dir/main.pts" ] && [ ! -f "$dir/request" ] || continue
  PTS_HOME=$home "$pts" build "$dir/main.pts" -o "$out/$name" >/dev/null
  PTS_HOME=$home "$pts" emit-c "$dir/main.pts" > "$out/$name.c"
done
ls "$out" | wc -l
