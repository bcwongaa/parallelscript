#!/usr/bin/env bash
# Round 2: base, new2 (x86 as shipped) and armproxy (acquires forced, an estimate of aarch64's lost hoisting).
cd /tmp/h35b/bench
for b in spectral_norm mandelbrot sum_reduce; do
  for v in base new2 armproxy; do
    PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=cg2-$v-$b.out ./$v/$b > /dev/null 2> cg2-$v-$b.log &
  done
  wait
  printf '%-16s base %s new2 %s armproxy %s\n' $b "$(grep -o 'Collected : [0-9]*' cg2-base-$b.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' cg2-new2-$b.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' cg2-armproxy-$b.log | grep -o '[0-9]*$')" >> callgrind2.txt
done
for b in binary_trees json string_building word_freq word_count nbody fib fib_int fan_out async_fib file_io startup; do
  PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=cg2-new2-$b.out ./new2/$b > /dev/null 2> cg2-new2-$b.log
  printf '%-16s new2 %s\n' $b "$(grep -o 'Collected : [0-9]*' cg2-new2-$b.log | grep -o '[0-9]*$')" >> callgrind2.txt
done
touch callgrind2.done
