#!/usr/bin/env bash
# Total instructions (callgrind Ir) of each benchmark, base and new, one thread, one GC marker.
cd /tmp/h35b/bench
for b in binary_trees json string_building word_freq word_count async_fib file_io nbody fib spectral_norm mandelbrot sum_reduce fib_int startup fan_out; do
  for v in base new; do
    PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=cg-$v-$b.out ./$v/$b > /dev/null 2> cg-$v-$b.log &
  done
  wait
  printf '%-16s %s %s\n' $b "$(grep -o 'Collected : [0-9]*' cg-base-$b.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' cg-new-$b.log | grep -o '[0-9]*$')" >> callgrind.txt
done
touch callgrind.done
