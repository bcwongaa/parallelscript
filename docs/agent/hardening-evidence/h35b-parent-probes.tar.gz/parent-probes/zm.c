typedef struct o { const void *type; double a, b; } o;
extern void *mk(void);
extern void hook(void);
o *f(void) { o *t = mk(); t->a = 0.0; t->b = 0.0; hook(); __asm__ volatile("" ::: "memory"); return t; }
