import re, subprocess, sys, collections
# Compares the x86-64 code of a program's own functions (generated from .pts) and of the runtime between two builds.
def functions(path):
    out = subprocess.run(['objdump', '-d', '--no-show-raw-insn', '-M', 'att', path], capture_output=True, text=True).stdout
    funcs, name, body = {}, None, []
    for line in out.split('\n'):
        m = re.match(r'^[0-9a-f]+ <([^>]+)>:$', line)
        if m:
            if name: funcs[name] = body
            name, body = m.group(1), []
            continue
        m = re.match(r'^\s+[0-9a-f]+:\s+(.*)$', line)
        if m and name:
            ins = m.group(1).split('#')[0].strip()
            ins = re.sub(r'\b[0-9a-f]{4,} <', '<', ins)
            ins = re.sub(r'<([^+>]+)\+0x[0-9a-f]+>', r'<\1>', ins)
            ins = re.sub(r'0x[0-9a-f]+\(%rip\)', 'X(%rip)', ins)
            if ins: body.append(ins)
    if name: funcs[name] = body
    return funcs
a, b = functions(sys.argv[1]), functions(sys.argv[2])
groups = collections.defaultdict(lambda: [0, 0, 0, 0])  # [functions, changed, base insns, new insns]
for name in sorted(set(a) | set(b)):
    group = 'program' if re.match(r'pts_(fn|main|step|entry|new_closure|dynamic|module|adapter)', name) else 'runtime' if name.startswith('pts_') else 'other'
    x, y = a.get(name, []), b.get(name, [])
    g = groups[group]; g[0] += 1; g[1] += x != y; g[2] += len(x); g[3] += len(y)
for group, (n, changed, x, y) in sorted(groups.items()):
    print(f'  {group:8} {n:5} functions, {changed:4} changed, instructions {x} -> {y} ({(y - x) / max(x, 1) * 100:+.2f}%)')
if len(sys.argv) > 3:
    import difflib
    for name in sorted(set(a) | set(b)):
        x, y = a.get(name, []), b.get(name, [])
        if x != y:
            print(f'--- {name}: {len(x)} -> {len(y)}')
            if sys.argv[3] == 'v':
                for line in difflib.unified_diff(x, y, lineterm='', n=1):
                    print('    ' + line)
