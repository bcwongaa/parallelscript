#!/usr/bin/env python3
"""Build programs under the publication profile and run each once with
PTS_PUBLICATION_CHECK=all (2 threads), saving stderr; prints one line per program:
exit code, number of distinct violation places, total violations.

usage: sweep.py OUTDIR [--jobs J] file.pts...
"""
import concurrent.futures
import os
import re
import signal
import subprocess
import sys

PTS = "/home/bryan/projects/parallelscript/pts-bin/pts"


def run(cmd, env, cwd=None, timeout=300):
    proc = subprocess.Popen(cmd, env=env, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
        return proc.returncode, out, err.decode(errors="replace")
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, err = proc.communicate()
        return "TIMEOUT", out, err.decode(errors="replace")


def one(path, outdir):
    name = os.path.basename(os.path.dirname(path)) + "_" + os.path.splitext(os.path.basename(path))[0]
    exe = os.path.join(outdir, name + ".bin")
    code, _, err = run([PTS, "build", path, "-o", exe], dict(os.environ, PTS_BUILD_PROFILE="publication"), timeout=600)
    if code != 0:
        return name, "BUILD", 0, 0
    env = dict(os.environ, PTS_THREADS="2", PTS_PUBLICATION_CHECK="all", TZ="America/New_York")
    code, out, err = run([exe], env, cwd=os.path.dirname(path))
    os.remove(exe)
    open(os.path.join(outdir, name + ".stderr"), "w").write(err)
    m = re.search(r"pts publication check: (\d+) publication violation\(s\) in (\d+) place", err)
    total, places = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
    return name, code, places, total


def main(argv):
    outdir, jobs, files = argv[0], 3, []
    i = 1
    while i < len(argv):
        if argv[i] == "--jobs":
            jobs = int(argv[i + 1]); i += 2
        else:
            files.append(argv[i]); i += 1
    os.makedirs(outdir, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for name, code, places, total in pool.map(lambda p: one(p, outdir), files):
            print(f"{name:60s} exit={code} places={places} violations={total}", flush=True)


if __name__ == "__main__":
    main(sys.argv[1:])
