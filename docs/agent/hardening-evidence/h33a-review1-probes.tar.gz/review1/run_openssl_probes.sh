#!/bin/bash
# Replays review round 1's OpenSSL s_server probes (needs labdir/ossl.crt and ossl.key from a lab run, and p2/one built):
# TLS 1.3 with two NewSessionTickets (-www), a KeyUpdate (k, K) after the request, a TLS 1.2 renegotiation (r).
R=/tmp/h33/review1
cd $R/p2
[ -x one ] || ${PTS:-/tmp/h33/snap1/pts-bin/pts} build one.pts -o one
./www.sh 48431 -tls1_3; ./www.sh 48432 -tls1_2
for args in "48451 -tls1_3 pts none" "48452 -tls1_3 node none" "48453 -tls1_3 pts k" "48454 -tls1_3 node k" "48455 -tls1_3 pts K" "48456 -tls1_3 node K" "48457 -tls1_2 pts r" "48458 -tls1_2 node r"; do ./interactive.sh $args 2>&1 | tail -1; done
