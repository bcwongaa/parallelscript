# Accepts TCP connections, reads the ClientHello, holds the connection for 40 s, then closes.
import socket, sys, threading, time
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", int(sys.argv[1]))); s.listen(8)
def hold(c):
    c.recv(16384); time.sleep(40); c.close()
while True:
    c, _ = s.accept(); threading.Thread(target=hold, args=(c,), daemon=True).start()
