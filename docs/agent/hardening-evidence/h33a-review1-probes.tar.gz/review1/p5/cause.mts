// How a certificate failure's cause prints and what it has.
for (const href of process.argv.slice(2)) {
  try {
    await fetch(href);
  } catch (e) {
    const cause = (e as Error).cause as Error & { code: string; errno?: number; syscall?: string };
    console.log(cause.name, cause instanceof Error, typeof cause.errno, typeof cause.syscall, Object.keys(cause).join(","));
    console.log(String(cause));
  }
}
