/* Parses each PEM certificate of a bundle with the runtime's mbedTLS build; prints the ones it refuses. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mbedtls/x509_crt.h>
#include <mbedtls/error.h>
#include <mbedtls/pem.h>
int main(int argc, char **argv) {
  FILE *f = fopen(argv[1], "rb");
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  char *buf = malloc(n + 1); fread(buf, 1, n, f); buf[n] = 0;
  int ok = 0, bad = 0;
  for (char *p = buf; (p = strstr(p, "-----BEGIN CERTIFICATE-----")) != NULL;) {
    char *end = strstr(p, "-----END CERTIFICATE-----") + 25;
    char save = *end; *end = 0;
    mbedtls_x509_crt crt; mbedtls_x509_crt_init(&crt);
    int r = mbedtls_x509_crt_parse(&crt, (unsigned char *)p, (size_t)(end - p) + 1);
    if (r != 0) {
      char e[200]; mbedtls_strerror(r, e, sizeof e);
      /* find the subject by asking openssl later: print an index */
      printf("refused #%d: %s\n", ok + bad, e);
      bad++;
    } else ok++;
    mbedtls_x509_crt_free(&crt);
    *end = save; p = end;
  }
  printf("parsed %d refused %d\n", ok, bad);
}
