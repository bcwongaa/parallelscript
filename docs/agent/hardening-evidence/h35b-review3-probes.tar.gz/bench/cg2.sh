#!/bin/sh
cd /tmp/h35b/review3/bench
for v in snap4 snap5; do
  PTS_THREADS=1 GC_MARKERS=1 valgrind --tool=callgrind --callgrind-out-file=/dev/null ./$v-word_count > wc-out-$v.txt 2> wc-cg-$v.log &
done
wait
printf 'word_count snap4 %s snap5 %s\n' "$(grep -o 'Collected : [0-9]*' wc-cg-snap4.log | grep -o '[0-9]*$')" "$(grep -o 'Collected : [0-9]*' wc-cg-snap5.log | grep -o '[0-9]*$')" >> cg.txt
cmp -s wc-out-snap4.txt wc-out-snap5.txt && echo "word_count same output" >> cg.txt
touch cg2.done
