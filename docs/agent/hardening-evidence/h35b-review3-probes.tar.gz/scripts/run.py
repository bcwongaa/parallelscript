#!/usr/bin/env python3
"""run.py [--cli snap|base] [--profile P] [--threads N] [--check OPTS] [--timeout S] [--keep] file.pts [args]
Builds file.pts with the chosen CLI and PTS_HOME, runs it (process group killed on
timeout), prints exit code, stdout and stderr. Binaries go to /tmp/h35b/review3/bin and
are deleted unless --keep."""
import os, signal, subprocess, sys
CLIS = {"snap5": ("/tmp/h35b/snap5/pts-bin/pts", "/tmp/h35b/snap5"), "snap4": ("/tmp/h35b/snap4/pts-bin/pts", "/tmp/h35b/snap4"), "snap": ("/tmp/h35b/snap3/pts-bin/pts", "/tmp/h35b/snap3"),
        "base": ("/tmp/h35b/wt-base/pts-bin/pts", "/tmp/h35b/wt-base")}
def run(cmd, env, cwd=None, timeout=120):
    p = subprocess.Popen(cmd, env=env, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        out, err = p.communicate(timeout=timeout)
        return p.returncode, out.decode(errors="replace"), err.decode(errors="replace")
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)
        out, err = p.communicate()
        return "TIMEOUT", out.decode(errors="replace"), err.decode(errors="replace")
def main(a):
    cli, profile, threads, check, timeout, keep, cliexe = "snap5", "", "2", "", 120, False, None
    while a and a[0].startswith("--"):
        k = a.pop(0)
        if k == "--cli": cli = a.pop(0)
        elif k == "--exe": cliexe = a.pop(0)
        elif k == "--profile": profile = a.pop(0)
        elif k == "--threads": threads = a.pop(0)
        elif k == "--check": check = a.pop(0)
        elif k == "--timeout": timeout = int(a.pop(0))
        elif k == "--keep": keep = True
    src, args = a[0], a[1:]
    exe, home = CLIS[cli]
    if cliexe: exe = cliexe
    env = dict(os.environ, PTS_HOME=home)
    if profile: env["PTS_BUILD_PROFILE"] = profile
    else: env.pop("PTS_BUILD_PROFILE", None)
    name = os.path.splitext(os.path.basename(src))[0]
    binp = f"/tmp/h35b/review3/bin/{name}.{cli}.{profile or 'release'}.{os.getpid()}"
    code, out, err = run([exe, "build", src, "-o", binp], env, timeout=900)
    if code != 0:
        print(f"BUILD FAILED {code}\n{out}\n{err}"); return
    renv = dict(env, PTS_THREADS=threads, TZ="America/New_York")
    if check: renv["PTS_PUBLICATION_CHECK"] = check
    code, out, err = run([binp] + args, renv, cwd=os.path.dirname(os.path.abspath(src)), timeout=timeout)
    if not keep: os.remove(binp)
    else: print("binary:", binp)
    print(f"exit={code}\n--- stdout\n{out}--- stderr\n{err}", end="")
if __name__ == "__main__": main(sys.argv[1:])
