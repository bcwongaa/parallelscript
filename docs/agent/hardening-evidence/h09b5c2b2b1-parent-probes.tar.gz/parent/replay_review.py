import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/home/bryan/projects/parallelscript')
SCRATCH = Path('/tmp/pts-h09-flow-CcTyrB')
REVIEW = ROOT / '.claude/worktrees/agent-a287d8e55867393f9/review-probes'
OUT = SCRATCH / 'parent-review-replay'
OUT.mkdir()
ENV = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(ROOT), PTS_REQUIRE_NODE='1')
HELPERS = {
    'base': ROOT / '.claude/worktrees/agent-a73ca310a5c969d18/repro-h09b5c2b2b1/probe',
    'current': SCRATCH / 'parent-all-instances',
}
prior = json.loads((SCRATCH / 'parent-replay-final/results.json').read_text())
for label, path in HELPERS.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest() == prior['helpers'][label]['sha256'], label
commands = []

def run(label, command):
    started = time.monotonic()
    command = [str(x) for x in command]
    result = subprocess.run(command, cwd=ROOT, env=ENV, capture_output=True, timeout=600)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    row = {'label': label, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - started}
    commands.append(row)
    return dict(row, out=result.stdout.decode(), err=result.stderr.decode())

mapping = {}
for name in ['review_receiver_probes_test.go', 'review_receiver_extra_test.go']:
    source = REVIEW / 'snapshot/pts/lower' / name
    dest = OUT / name
    shutil.copyfile(source, dest)
    mapping[str(ROOT / 'pts/lower' / name)] = str(dest)
overlay = OUT / 'source-tests-overlay.json'
overlay.write_text(json.dumps({'Replace': mapping}, indent=2))
unit = run('source-controls', ['go', 'test', '-overlay=' + str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', '-run', '^TestReview', './pts/lower'])
assert unit['exit'] == 0, unit
counts = {'pass': 0, 'skip': 0, 'fail': 0}
for line in unit['out'].splitlines():
    event = json.loads(line)
    if event.get('Test') and event.get('Action') in counts:
        counts[event['Action']] += 1
assert counts == {'pass': 36, 'skip': 0, 'fail': 0}, counts

cases = json.loads((REVIEW / 'manifest.json').read_text())
(OUT / 'manifest.json').write_text(json.dumps(cases, indent=2))
inputs = OUT / 'inputs'
inputs.mkdir()
unsupported = {'unknown_alias_ctor', 'nested_class_ctor', 'class_arrow_field', 'asserted_class_write', 'asserted_class_destructure'}
known_nonmatches = {'unknown_constructor_return', 'unknown_inherited_return', 'override_barrier'}
rows = []
for case in cases:
    name = case['name']
    source = inputs / (name + '.pts')
    shutil.copyfile(REVIEW / 'cases' / source.name, source)
    mts = source.with_suffix('.mts')
    shutil.copyfile(source, mts)
    node = run(name + '.node', [Path.home() / '.local/node/bin/node', '--no-warnings', '--experimental-transform-types', mts])
    assert node['exit'] == 0, node
    row = {'name': name, 'node': node, 'versions': {}}
    for version, helper in HELPERS.items():
        label = name + '.' + version
        cpath = OUT / (label + '.c')
        binary = OUT / (label + '.bin')
        compile_result = run(label + '.compile', [helper, source, cpath, binary])
        value = {'compile': compile_result}
        row['versions'][version] = value
        if name in unsupported:
            assert compile_result['exit'] == 2 and not binary.exists(), (name, version, compile_result)
            continue
        assert compile_result['exit'] == 0, (name, version, compile_result)
        code = cpath.read_text()
        targets = {target: 'pts_fn_' + target + '(' in code for target in case['required'] + case['excluded']}
        value['targets'] = targets
        assert all(targets[target] for target in case['required']), (name, version, targets)
        if version == 'current':
            assert not any(targets[target] for target in case['excluded']), (name, version, targets)
        value['native'] = run(label + '.native', [binary])
        binary.unlink()
        value['matches_node'] = value['native']['exit'] == node['exit'] and value['native']['out'] == node['out']
        assert value['matches_node'] == (name not in known_nonmatches), (name, version, value)
        value['c_sha256'] = hashlib.sha256(cpath.read_bytes()).hexdigest()
    rows.append(row)
    print(name, 'retained unsupported' if name in unsupported else 'retained known nonmatch' if name in known_nonmatches else 'base/current match Node', flush=True)
summary = {'source_controls': counts, 'cases': len(rows), 'compiling': len(rows) - len(unsupported), 'node_matches_each_version': len(rows) - len(unsupported) - len(known_nonmatches), 'known_nonmatches': sorted(known_nonmatches), 'unsupported': sorted(unsupported)}
result = {'summary': summary, 'commands': commands, 'rows': rows}
(OUT / 'results.json').write_text(json.dumps(result, indent=2))
print(json.dumps(summary), flush=True)
