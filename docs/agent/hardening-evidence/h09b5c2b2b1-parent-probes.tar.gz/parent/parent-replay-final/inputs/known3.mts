class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(receiver: Maker): void { const box: Box<C2> = receiver.make(new C2()); console.log(box.value.tag); }
use0(new M0());
use1(new M1());
use2(new M2());
