class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(receiver: Maker): void { const box: Box<C2> = receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(receiver: Maker): void { const box: Box<C3> = receiver.make(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(receiver: Maker): void { const box: Box<C4> = receiver.make(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(receiver: Maker): void { const box: Box<C5> = receiver.make(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(receiver: Maker): void { const box: Box<C6> = receiver.make(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(receiver: Maker): void { const box: Box<C7> = receiver.make(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(receiver: Maker): void { const box: Box<C8> = receiver.make(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(receiver: Maker): void { const box: Box<C9> = receiver.make(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(receiver: Maker): void { const box: Box<C10> = receiver.make(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(receiver: Maker): void { const box: Box<C11> = receiver.make(new C11()); console.log(box.value.tag); }
const held: any[] = [new M0(), new M1(), new M2(), new M3(), new M4(), new M5(), new M6(), new M7(), new M8(), new M9(), new M10(), new M11()];
use0(held[0]);
use1(held[1]);
use2(held[2]);
use3(held[3]);
use4(held[4]);
use5(held[5]);
use6(held[6]);
use7(held[7]);
use8(held[8]);
use9(held[9]);
use10(held[10]);
use11(held[11]);
