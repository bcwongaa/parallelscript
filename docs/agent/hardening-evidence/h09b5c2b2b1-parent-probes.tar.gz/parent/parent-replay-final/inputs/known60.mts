class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(receiver: Maker): void { const box: Box<C2> = receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(receiver: Maker): void { const box: Box<C3> = receiver.make(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(receiver: Maker): void { const box: Box<C4> = receiver.make(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(receiver: Maker): void { const box: Box<C5> = receiver.make(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(receiver: Maker): void { const box: Box<C6> = receiver.make(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(receiver: Maker): void { const box: Box<C7> = receiver.make(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(receiver: Maker): void { const box: Box<C8> = receiver.make(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(receiver: Maker): void { const box: Box<C9> = receiver.make(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(receiver: Maker): void { const box: Box<C10> = receiver.make(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(receiver: Maker): void { const box: Box<C11> = receiver.make(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(receiver: Maker): void { const box: Box<C12> = receiver.make(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(receiver: Maker): void { const box: Box<C13> = receiver.make(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(receiver: Maker): void { const box: Box<C14> = receiver.make(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(receiver: Maker): void { const box: Box<C15> = receiver.make(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(receiver: Maker): void { const box: Box<C16> = receiver.make(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(receiver: Maker): void { const box: Box<C17> = receiver.make(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(receiver: Maker): void { const box: Box<C18> = receiver.make(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(receiver: Maker): void { const box: Box<C19> = receiver.make(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(receiver: Maker): void { const box: Box<C20> = receiver.make(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(receiver: Maker): void { const box: Box<C21> = receiver.make(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(receiver: Maker): void { const box: Box<C22> = receiver.make(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(receiver: Maker): void { const box: Box<C23> = receiver.make(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(receiver: Maker): void { const box: Box<C24> = receiver.make(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(receiver: Maker): void { const box: Box<C25> = receiver.make(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(receiver: Maker): void { const box: Box<C26> = receiver.make(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(receiver: Maker): void { const box: Box<C27> = receiver.make(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(receiver: Maker): void { const box: Box<C28> = receiver.make(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(receiver: Maker): void { const box: Box<C29> = receiver.make(new C29()); console.log(box.value.tag); }
class C30 { tag = 30; }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(receiver: Maker): void { const box: Box<C30> = receiver.make(new C30()); console.log(box.value.tag); }
class C31 { tag = 31; }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(receiver: Maker): void { const box: Box<C31> = receiver.make(new C31()); console.log(box.value.tag); }
class C32 { tag = 32; }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(receiver: Maker): void { const box: Box<C32> = receiver.make(new C32()); console.log(box.value.tag); }
class C33 { tag = 33; }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(receiver: Maker): void { const box: Box<C33> = receiver.make(new C33()); console.log(box.value.tag); }
class C34 { tag = 34; }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(receiver: Maker): void { const box: Box<C34> = receiver.make(new C34()); console.log(box.value.tag); }
class C35 { tag = 35; }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(receiver: Maker): void { const box: Box<C35> = receiver.make(new C35()); console.log(box.value.tag); }
class C36 { tag = 36; }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(receiver: Maker): void { const box: Box<C36> = receiver.make(new C36()); console.log(box.value.tag); }
class C37 { tag = 37; }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(receiver: Maker): void { const box: Box<C37> = receiver.make(new C37()); console.log(box.value.tag); }
class C38 { tag = 38; }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(receiver: Maker): void { const box: Box<C38> = receiver.make(new C38()); console.log(box.value.tag); }
class C39 { tag = 39; }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(receiver: Maker): void { const box: Box<C39> = receiver.make(new C39()); console.log(box.value.tag); }
class C40 { tag = 40; }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(receiver: Maker): void { const box: Box<C40> = receiver.make(new C40()); console.log(box.value.tag); }
class C41 { tag = 41; }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(receiver: Maker): void { const box: Box<C41> = receiver.make(new C41()); console.log(box.value.tag); }
class C42 { tag = 42; }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(receiver: Maker): void { const box: Box<C42> = receiver.make(new C42()); console.log(box.value.tag); }
class C43 { tag = 43; }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(receiver: Maker): void { const box: Box<C43> = receiver.make(new C43()); console.log(box.value.tag); }
class C44 { tag = 44; }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(receiver: Maker): void { const box: Box<C44> = receiver.make(new C44()); console.log(box.value.tag); }
class C45 { tag = 45; }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(receiver: Maker): void { const box: Box<C45> = receiver.make(new C45()); console.log(box.value.tag); }
class C46 { tag = 46; }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(receiver: Maker): void { const box: Box<C46> = receiver.make(new C46()); console.log(box.value.tag); }
class C47 { tag = 47; }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(receiver: Maker): void { const box: Box<C47> = receiver.make(new C47()); console.log(box.value.tag); }
class C48 { tag = 48; }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(receiver: Maker): void { const box: Box<C48> = receiver.make(new C48()); console.log(box.value.tag); }
class C49 { tag = 49; }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(receiver: Maker): void { const box: Box<C49> = receiver.make(new C49()); console.log(box.value.tag); }
class C50 { tag = 50; }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(receiver: Maker): void { const box: Box<C50> = receiver.make(new C50()); console.log(box.value.tag); }
class C51 { tag = 51; }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(receiver: Maker): void { const box: Box<C51> = receiver.make(new C51()); console.log(box.value.tag); }
class C52 { tag = 52; }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(receiver: Maker): void { const box: Box<C52> = receiver.make(new C52()); console.log(box.value.tag); }
class C53 { tag = 53; }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(receiver: Maker): void { const box: Box<C53> = receiver.make(new C53()); console.log(box.value.tag); }
class C54 { tag = 54; }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(receiver: Maker): void { const box: Box<C54> = receiver.make(new C54()); console.log(box.value.tag); }
class C55 { tag = 55; }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(receiver: Maker): void { const box: Box<C55> = receiver.make(new C55()); console.log(box.value.tag); }
class C56 { tag = 56; }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(receiver: Maker): void { const box: Box<C56> = receiver.make(new C56()); console.log(box.value.tag); }
class C57 { tag = 57; }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(receiver: Maker): void { const box: Box<C57> = receiver.make(new C57()); console.log(box.value.tag); }
class C58 { tag = 58; }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(receiver: Maker): void { const box: Box<C58> = receiver.make(new C58()); console.log(box.value.tag); }
class C59 { tag = 59; }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(receiver: Maker): void { const box: Box<C59> = receiver.make(new C59()); console.log(box.value.tag); }
use0(new M0());
use1(new M1());
use2(new M2());
use3(new M3());
use4(new M4());
use5(new M5());
use6(new M6());
use7(new M7());
use8(new M8());
use9(new M9());
use10(new M10());
use11(new M11());
use12(new M12());
use13(new M13());
use14(new M14());
use15(new M15());
use16(new M16());
use17(new M17());
use18(new M18());
use19(new M19());
use20(new M20());
use21(new M21());
use22(new M22());
use23(new M23());
use24(new M24());
use25(new M25());
use26(new M26());
use27(new M27());
use28(new M28());
use29(new M29());
use30(new M30());
use31(new M31());
use32(new M32());
use33(new M33());
use34(new M34());
use35(new M35());
use36(new M36());
use37(new M37());
use38(new M38());
use39(new M39());
use40(new M40());
use41(new M41());
use42(new M42());
use43(new M43());
use44(new M44());
use45(new M45());
use46(new M46());
use47(new M47());
use48(new M48());
use49(new M49());
use50(new M50());
use51(new M51());
use52(new M52());
use53(new M53());
use54(new M54());
use55(new M55());
use56(new M56());
use57(new M57());
use58(new M58());
use59(new M59());
