import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/bryan/projects/parallelscript')
SCRATCH = Path('/tmp/pts-h09-flow-CcTyrB')
CHILD = ROOT / '.claude/worktrees/agent-a73ca310a5c969d18/repro-h09b5c2b2b1'
OUT = SCRATCH / (sys.argv[1] if len(sys.argv) > 1 else 'parent-replay')
OUT.mkdir()
INPUTS = OUT / 'inputs'
INPUTS.mkdir()
ENV = dict(os.environ, GOMAXPROCS='2', PTS_HOME=str(ROOT))
HELPERS = {'base': CHILD / 'probe', 'current': SCRATCH / 'parent-all-instances'}
commands = []

def run(label, command):
    started = time.monotonic()
    result = subprocess.run([str(x) for x in command], cwd=ROOT, env=ENV, capture_output=True, timeout=240)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    record = {'label': label, 'command': [str(x) for x in command], 'exit': result.returncode, 'seconds': time.monotonic() - started}
    commands.append(record)
    assert result.returncode == 0, record
    return result.stdout

rows = []
for name in ['known3', 'known12', 'known60', 'unknown12', 'constructor_return_replacement', 'inherited_constructor_replacement']:
    path = INPUTS / (name + '.pts')
    shutil.copyfile(CHILD / 'results/baseline-probes' / path.name, path)
    mts = path.with_suffix('.mts')
    shutil.copyfile(path, mts)
    node = run(name + '.node', [str(Path.home() / '.local/node/bin/node'), '--no-warnings', '--experimental-transform-types', mts])
    row = {'name': name, 'node': node.decode(), 'versions': {}}
    codes = {}
    for version, helper in HELPERS.items():
        label = name + '.' + version
        cpath, binary = OUT / (label + '.c'), OUT / (label + '.bin')
        run(label + '.compile', [helper, path, cpath, binary])
        native = run(label + '.native', [binary])
        binary.unlink()
        code = cpath.read_text()
        codes[version] = code
        pairs = sorted(set((int(a), int(b)) for a, b in re.findall(r'pts_fn_M(\d+)_make_C(\d+)\(', code)))
        row['versions'][version] = {'pairs': len(pairs), 'pair_set': pairs, 'c_lines': len(code.splitlines()), 'c_bytes': len(code.encode()), 'c_sha256': hashlib.sha256(code.encode()).hexdigest(), 'native': native.decode(), 'matches_node': native == node}
        if name.startswith('known') or name.startswith('unknown'):
            count = int(re.search(r'\d+', name)[0])
            expected = {(i, j) for i in range(count) for j in range(count) if version == 'base' or name.startswith('unknown') or i == j}
            assert set(pairs) == expected, (name, version, len(pairs), len(expected))
            assert native == node, (name, version)
        else:
            assert native == b'constructed 4\n' and node == b'replacement 4\n', (name, version, native, node)
    row['c_byte_identical'] = codes['base'] == codes['current']
    if name.startswith('unknown'):
        assert row['c_byte_identical'], name
    rows.append(row)
    print(json.dumps({k: v for k, v in row.items() if k != 'versions'}), flush=True)
result = {'helpers': {k: {'path': str(v), 'sha256': hashlib.sha256(v.read_bytes()).hexdigest()} for k, v in HELPERS.items()}, 'commands': commands, 'rows': rows}
(OUT / 'results.json').write_text(json.dumps(result, indent=2))
print('All parent replay assertions passed.', flush=True)
