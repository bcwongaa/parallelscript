package lower

import (
 "fmt"
 "testing"

 "gotest.tools/v3/assert"
)

func TestReviewReceiverClassWriteForms(t *testing.T) {
 for _, write := range []string{
  "A = B;", "(A) = B;", "[A] = [B];", "({A} = {A:B});", "({value:A} = {value:B});", "[A = B] = [];", "({A = B} = {});", "for (A of [B]) {}", "for ([A] of [[B]]) {}", "A ||= B;", "A &&= B;", "A ??= B;", "(A as any) = B;", "(A!) = B;", "(<any>A) = B;", "[(A as any)] = [B];",
 } {
  t.Run(write, func(t *testing.T) {
   l, probe := valueFlowProbe(t, "class A {} class B {}\n// @ts-ignore defensive binding-write guard\n"+write+"\nconst probe = new A(); probe;")
   steps := maxValueFlowSteps
   sources := l.receiverSources(probe, &steps, 0)
   assert.Assert(t, sources == nil, "assigned constructor must be unknown; got %v", returnedSourceNames(sources))
  })
 }
}

func TestReviewReceiverFunctionCaches(t *testing.T) {
 for _, source := range []string{
  "class A {} function make(): A { return new A(); } const probe = make(); probe;",
  "function id<T>(x:T):T { return x; } function make(): typeof id { return id; } const probe = make(); probe;",
  "class A {} function id<T>(x:T):T { return x; } function make(flag:boolean): A|typeof id { if(flag) return id; return new A(); } const probe = make(true); probe;",
 } {
  for _, receiverFirst := range []bool{true,false} {
   t.Run(fmt.Sprintf("%v/%s",receiverFirst, source),func(t *testing.T){
    l, probe := valueFlowProbe(t,source)
    baseline, baselineProbe := valueFlowProbe(t,source)
    steps:=maxValueFlowSteps
    wantFunctions:=baseline.valueSources(baselineProbe,&steps,0)
    steps=maxValueFlowSteps
    wantReceivers:=baseline.receiverSources(baselineProbe,&steps,0)
    checkFunctions:=func(){steps=maxValueFlowSteps; got:=l.valueSources(probe,&steps,0); assert.Equal(t, got==nil,wantFunctions==nil); assert.DeepEqual(t,returnedSourceNames(got),returnedSourceNames(wantFunctions))}
    checkReceivers:=func(){steps=maxValueFlowSteps; got:=l.receiverSources(probe,&steps,0); assert.Equal(t, got==nil,wantReceivers==nil); assert.DeepEqual(t,returnedSourceNames(got),returnedSourceNames(wantReceivers))}
    if receiverFirst {checkReceivers(); checkFunctions()} else {checkFunctions();checkReceivers()}
    checkFunctions();checkReceivers()
    assert.Equal(t,len(l.valueFlow.active),0)
    assert.Equal(t,len(l.valueFlow.receivers.active),0)
   })
  }
 }
}
