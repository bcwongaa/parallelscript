class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
abstract class Parent { abstract make<T>(value:T):Box<T>; }
class A extends Parent { make<T>(value:T):Box<T> { console.log("A"); return new Box(value); } }
class B extends Parent { make<T>(value:T):Box<T> { console.log("B"); return new Box(value); } }
function use(receiver:Parent):void { console.log(receiver.make(7).value); }
use(new B());
