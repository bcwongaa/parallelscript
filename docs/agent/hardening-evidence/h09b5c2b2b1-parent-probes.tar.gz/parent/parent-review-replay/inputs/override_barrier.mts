class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
class Parent implements Maker { make<T>(value:T):Box<T> { console.log("parent"); return new Box(value); } }
class Override extends Parent { make<T>(value:T):Box<T> { console.log("override"); const held:any=[new Box("wrong")]; return held[0]; } }
function use(receiver:Maker):void { try { console.log(receiver.make(7).value); } catch(e:any) { console.log("caught",e.name); } }
use(new Override());
