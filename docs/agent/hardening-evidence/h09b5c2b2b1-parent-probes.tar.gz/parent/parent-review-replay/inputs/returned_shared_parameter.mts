class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
class M0 implements Maker { tag="M0"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class M1 implements Maker { tag="M1"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class M2 implements Maker { tag="M2"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
function use(receiver:Maker):void { const b:Box<number> = receiver.make(7); console.log(b.value); }
function identity(x:Maker):Maker { return x; }
use(identity(new M0())); use(identity(new M1()));
