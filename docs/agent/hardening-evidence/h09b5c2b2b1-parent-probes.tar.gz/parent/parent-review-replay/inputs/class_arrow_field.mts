class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
class A implements Maker { tag="A"; make=<T>(value:T):Box<T>=> { console.log(this.tag); return new Box(value); }; }
class B implements Maker { tag="B"; make=<T>(value:T):Box<T>=> { console.log(this.tag); return new Box(value); }; }
function use(receiver:Maker):void { const b:Box<number> = receiver.make(7); console.log(b.value); }
use(new A());
