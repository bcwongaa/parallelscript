class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
class Parent implements Maker { tag="parent"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class Inherited extends Parent { tag="inherited"; }
class Override extends Parent { tag="override"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class Unreached extends Parent { make<T>(value:T):Box<T> { console.log("unreached"); return new Box(value); } }
function use0(receiver:Maker):void { console.log(receiver.make(7).value); }
function use1(receiver:Maker):void { console.log(receiver.make("str").value); }
use0(new Inherited()); use1(new Override());
