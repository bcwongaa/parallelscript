class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value:T): Box<T>; }
function choose(): boolean { return false; }
class M0 implements Maker { tag="M0"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class M1 implements Maker { tag="M1"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
class M2 implements Maker { tag="M2"; make<T>(value:T):Box<T> { console.log(this.tag); return new Box(value); } }
function f<T>(x:T):Box<T>{return new Box(x);}
function g<T>(x:T):Box<T>{return new Box(x);}
function factory(flag:boolean):typeof f { if(flag) return f; return g; }
function useFn(fn:typeof f):void { console.log(fn(9).value); }
useFn(factory(false));
function use(receiver:Maker):void { const b:Box<number> = receiver.make(7); console.log(b.value); }
use(new M1());
