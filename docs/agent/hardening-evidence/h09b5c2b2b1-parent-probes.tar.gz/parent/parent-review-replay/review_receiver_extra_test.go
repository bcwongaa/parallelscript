package lower

import (
 "testing"

 "gotest.tools/v3/assert"
)

func TestReviewAssertedFunctionBindingWritesStayUnknown(t *testing.T) {
 for _, write := range []string{"(first as any) = second;", "(<any>first) = second;", "[(first as any)] = [second];"} {
  t.Run(write,func(t *testing.T){
   l,probe:=valueFlowProbe(t,"function first(): void {} function second(): void {} "+write+" const probe=first; probe;")
   steps:=maxValueFlowSteps
   assert.Assert(t,l.valueSources(probe,&steps,0)==nil)
  })
 }
}

func TestReviewReceiverConstructorControlFlow(t *testing.T) {
 for _, tt:=range []struct{name,source string;known bool}{
  {"replacement_finally", "class A { constructor(){try {return;} finally {return new B();}}}",false},
  {"replacement_catch", "class A { constructor(){try {throw 1;} catch(e){return new B();}}}",false},
  {"replacement_unreachable", "class A { constructor(){if(false)return new B();}}",false},
  {"replacement_grandparent", "class Base {constructor(){return new B();}} class Parent extends Base {} class A extends Parent {}",false},
  {"written_ancestor", "class Parent {} class A extends Parent {} (Parent as any)=B;",false},
  {"bare_return_finally", "class A { constructor(){try {return;} finally {let i=0;i++;}}}",true},
  {"nested_method_return", "class A { constructor(){const value={method(){return new B();}}; value.method();}}",true},
 } {
  t.Run(tt.name,func(t *testing.T){
   l,probe:=valueFlowProbe(t,"class B {} "+tt.source+" const probe=new A(); probe;")
   steps:=maxValueFlowSteps
   got:=l.receiverSources(probe,&steps,0)
   assert.Equal(t,got!=nil,tt.known)
   if tt.known { assert.DeepEqual(t,returnedSourceNames(got),[]string{"A"}) }
  })
 }
}
