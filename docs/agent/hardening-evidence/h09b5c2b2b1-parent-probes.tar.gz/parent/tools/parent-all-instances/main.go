package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: probe entry.pts output.c output.bin|- (AllInstances only)")
		os.Exit(64)
	}
	ctx := context.Background()
	code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	if err != nil {
		fmt.Fprintln(os.Stderr, "EMIT ERROR:", err)
		os.Exit(2)
	}
	if err := os.MkdirAll(filepath.Dir(os.Args[2]), 0o755); err != nil {
		fmt.Fprintln(os.Stderr, "OUTPUT SETUP ERROR:", err)
		os.Exit(3)
	}
	if err := os.WriteFile(os.Args[2], []byte(code), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, "WRITE ERROR:", err)
		os.Exit(3)
	}
	if os.Args[3] == "-" {
		return
	}
	compiler, err := toolchain.New()
	if err != nil {
		fmt.Fprintln(os.Stderr, "TOOLCHAIN SETUP ERROR:", err)
		os.Exit(3)
	}
	runtime, err := compiler.Runtime(ctx, toolchain.Release)
	if err != nil {
		fmt.Fprintln(os.Stderr, "RUNTIME SETUP ERROR:", err)
		os.Exit(3)
	}
	if err := compiler.CompileProgram(ctx, runtime, []string{os.Args[2]}, os.Args[3]); err != nil {
		fmt.Fprintln(os.Stderr, "CLANG ERROR:", err)
		os.Exit(4)
	}
}
