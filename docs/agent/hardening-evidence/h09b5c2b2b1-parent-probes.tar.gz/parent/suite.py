import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/bryan/projects/parallelscript')
OUT = Path('/tmp/pts-h09-flow-CcTyrB') / sys.argv[1]
OUT.mkdir()

def manifest():
    files = {}
    for tree in ('pts', 'cmd', 'internal'):
        for path in (ROOT / tree).rglob('*'):
            if path.is_file() and not path.is_symlink() and (path.suffix in ('.go', '.pts', '.c', '.h', '.json') or path.name.endswith('.d.ts')):
                files[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return files

before = manifest()
(OUT / 'before.json').write_text(json.dumps(before, sort_keys=True))
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
commands = [['make', 'build'], ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']]
results = []
cli_before = None
for label, command in zip(('build', 'suite'), commands):
    started = time.monotonic()
    with (OUT / (label + '.stdout')).open('w') as stdout, (OUT / (label + '.stderr')).open('w') as stderr:
        proc = subprocess.run(command, cwd=ROOT, env=env, stdout=stdout, stderr=stderr)
    result = {'label': label, 'command': command, 'exit': proc.returncode, 'seconds': time.monotonic() - started}
    results.append(result)
    print(json.dumps(result), flush=True)
    if proc.returncode:
        break
    if label == 'build':
        cli_before = hashlib.sha256((ROOT / 'pts-bin/pts').read_bytes()).hexdigest()
counts = {key: 0 for key in ('pass', 'fail', 'skip')}
packages = []
corpus = {key: 0 for key in counts}
if (OUT / 'suite.stdout').exists():
    for line in (OUT / 'suite.stdout').read_text().splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        action = event.get('Action')
        if action in counts:
            if event.get('Test'):
                counts[action] += 1
                if event['Test'].startswith('TestCorpusMatchesNode/'):
                    corpus[action] += 1
            else:
                packages.append({'package': event['Package'], 'action': action})
after = manifest()
(OUT / 'after.json').write_text(json.dumps(after, sort_keys=True))
cli_after = hashlib.sha256((ROOT / 'pts-bin/pts').read_bytes()).hexdigest()
summary = {'results': results, 'counts': counts, 'corpus': corpus, 'packages': packages, 'source_files': len(before), 'sources_unchanged': before == after, 'manifest_scope': 'regular .go/.pts/.c/.h/.json/.d.ts files under pts/, cmd/, internal/', 'cli_before': cli_before, 'cli_sha256': cli_after, 'cli_unchanged': cli_before == cli_after}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
sys.exit(0 if len(results) == 2 and all(r['exit'] == 0 for r in results) and before == after and cli_before == cli_after else 1)
