import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path('/home/bryan/projects/parallelscript')
SCRATCH = Path('/tmp/pts-h09-flow-CcTyrB')
EVIDENCE = ROOT / 'docs/agent/hardening-evidence'
summary = json.loads((SCRATCH / 'final-complete/summary.json').read_text())
assert all(result['exit'] == 0 for result in summary['results'])
assert summary['sources_unchanged'] and summary['cli_unchanged']
review = json.loads((SCRATCH / 'parent-review-replay/results.json').read_text())
assert review['summary']['source_controls'] == {'pass': 36, 'skip': 0, 'fail': 0}
assert review['summary']['cases'] == 31 and review['summary']['node_matches_each_version'] == 23
files = {}
for name in ['baseline', 'baseline-complete', 'final-complete', 'parent-replay', 'parent-replay-final', 'parent-review-replay']:
    for path in (SCRATCH / name).rglob('*'):
        if path.is_file() and not path.is_symlink() and path.suffix != '.bin':
            # Keep the final raw JSONL separately, and compress other large raw streams in this archive.
            if path == SCRATCH / 'final-complete/suite.stdout':
                continue
            files[str(path.relative_to(SCRATCH))] = path
for path in SCRATCH.iterdir():
    if path.is_file() and not path.is_symlink() and (path.name.startswith('parent-') and path.suffix in {'.stdout', '.stderr', '.json'} or path.suffix == '.py' or path.name.startswith('review-round1') or path.name == 'startup-c2b1-ci.json'):
        files[path.name] = path
helper = ROOT / '.claude/h09-receiver-parent/main.go'
assert helper.is_file()
files['tools/parent-all-instances/main.go'] = helper
members = []
archive = EVIDENCE / 'h09b5c2b2b1-parent-probes.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz', compresslevel=9) as tf:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        assert data[:4] != b'\x7fELF', name
        original_sha = hashlib.sha256(data).hexdigest()
        original_size = len(data)
        if len(data) > 1_000_000 and path.name.endswith('.stdout'):
            name += '.gz'
            data = gzip.compress(data, compresslevel=9, mtime=0)
        member_name = 'parent/' + name
        info = tarfile.TarInfo(member_name)
        info.size = len(data)
        info.mode = 0o644
        tf.addfile(info, io.BytesIO(data))
        members.append({'path': member_name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'uncompressed_sha256': original_sha, 'uncompressed_bytes': original_size})
    data = json.dumps({'files': members}, indent=2).encode()
    info = tarfile.TarInfo('parent/archive-manifest.json')
    info.size = len(data)
    info.mode = 0o644
    tf.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tf:
    for member in tf.getmembers():
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert tf.extractfile(member).read(4) != b'\x7fELF'
raw = EVIDENCE / 'h09b5c2b2b1-final-suite.jsonl.gz'
assert not raw.exists()
raw.write_bytes(gzip.compress((SCRATCH / 'final-complete/suite.stdout').read_bytes(), compresslevel=9, mtime=0))
for path in [archive, raw]:
    print(path.name, path.stat().st_size, hashlib.sha256(path.read_bytes()).hexdigest(), flush=True)
print('Parent archive regular members:', len(members) + 1, flush=True)
