import hashlib, json, os, pathlib, subprocess, sys, time

out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
base, current = map(pathlib.Path, sys.argv[2:4])
entries = list(map(pathlib.Path, sys.argv[4:]))
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript')

def run(command, name):
    start = time.monotonic()
    result = subprocess.run(list(map(str, command)), env=env, capture_output=True, timeout=300)
    (out/(name+'.out')).write_bytes(result.stdout)
    (out/(name+'.err')).write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError(f'{name}: exit {result.returncode}; see output')
    return result.stdout, time.monotonic()-start

results = []
for entry in entries:
    stem = entry.stem
    data = entry.read_bytes()
    lines = data.decode().splitlines()
    index = lines.index('// expect:')
    expected = ('\n'.join(line[3:] for line in lines[index+1:] if line.startswith('// '))+'\n').encode()
    node_entry = out/(stem+'.mts'); node_entry.write_bytes(data)
    node, seconds = run(['node', '--no-warnings', '--experimental-transform-types', node_entry], stem+'-node')
    assert node == expected, (stem, 'Node output', node, expected)
    record = {'source': str(entry), 'sha256': hashlib.sha256(data).hexdigest(), 'node_exit': 0, 'node_seconds': seconds, 'versions': {}}
    for version, helper in [('base', base), ('current', current)]:
        name = stem+'-'+version
        cfile, binary = out/(name+'.c'), out/(name+'.bin')
        _, compile_seconds = run([helper, entry, cfile, binary], name+'-compile')
        native, native_seconds = run([binary], name+'-native')
        assert native == expected, (stem, version, 'native output', native, expected)
        record['versions'][version] = {'compile_exit': 0, 'compile_seconds': compile_seconds, 'native_exit': 0, 'native_seconds': native_seconds, 'matches_expected_and_node': True, 'c_sha256': hashlib.sha256(cfile.read_bytes()).hexdigest()}
        binary.unlink()
    results.append(record)
    (out/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(record), flush=True)
