import hashlib, json, os, pathlib, re, subprocess, sys

root = pathlib.Path(sys.argv[1]); helper = pathlib.Path(sys.argv[2])
out = root/'final-replay'; out.mkdir(exist_ok=False)
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript')

def run(command, name):
    result = subprocess.run(list(map(str, command)), env=env, capture_output=True, timeout=300)
    (out/(name+'.out')).write_bytes(result.stdout); (out/(name+'.err')).write_bytes(result.stderr)
    assert result.returncode == 0, (name, result.returncode, result.stderr)
    return result.stdout

results = []
for record in json.loads((root/'growth/summary.json').read_text()):
    case, n = record['case'], record['n']
    entry = root/'growth'/(case+'.pts'); cfile = out/(case+'.c'); binary = out/(case+'.bin')
    run([helper, entry, cfile, binary], case+'-compile')
    data = cfile.read_bytes(); digest = hashlib.sha256(data).hexdigest()
    assert digest == record['versions']['current'][0]['sha256'], (case, 'final C changed')
    pairs = {(int(a),int(b)) for a,b in re.findall(rb'\bpts_fn_M([0-9]+)_make_C([0-9]+)\(',data)}
    required = {(i,j) for i in range(n) for j in range(n) if record['unknown'] or i == j}
    assert pairs == required
    expected = ''.join(f'{i}\n{i}\n' for i in range(n)).encode()
    node = run(['node','--no-warnings','--experimental-transform-types',root/'growth'/(case+'.mts')],case+'-node')
    native = run([binary],case+'-native'); binary.unlink()
    assert native == node == expected
    results.append({'case':case,'sha256':digest,'matches_round1_C':True,'method_pairs':len(pairs),'compile_exit':0,'native_exit':0,'node_exit':0,'matches_expected_and_node':True})
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
