import json, os, pathlib, subprocess, sys

out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
base, current = map(pathlib.Path, sys.argv[2:4])
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript')

def run(command, stem):
    result = subprocess.run(list(map(str, command)), env=env, capture_output=True, timeout=300)
    (out/(stem+'.out')).write_bytes(result.stdout); (out/(stem+'.err')).write_bytes(result.stderr)
    return result

results = []
for name, target in [('as', '(receiver as any)'), ('type_assertion', '(<any>receiver)'), ('nonnull', 'receiver!'), ('satisfies', '(receiver satisfies A)')]:
    code = '''class Box<T> { constructor(public value: T, public tag: string) {} }
type Factory = <T>(value: T) => Box<T>;
class A { tag = "a"; make<T>(value: T): Box<T> { return new Box(value, this.tag); } }
class B extends A { make<T>(value: T): Box<T> { return new Box(value, this.tag); } constructor() { super(); this.tag = "b"; } }
function read(receiver: A): Factory { TARGET = new B(); return receiver.make.bind(receiver); }
const factory = read(new A()); const box: Box<number> = factory(4); console.log(box.tag, box.value);
'''.replace('TARGET', target)
    entry=out/(name+'.pts'); entry.write_text(code)
    node=out/(name+'.mts'); node.write_text(code)
    nr=run(['node', '--no-warnings', '--experimental-transform-types', node], name+'-node')
    assert nr.returncode==0 and nr.stdout==b'b 4\n', (name, nr.stdout, nr.stderr)
    record={'case':name,'node_exit':nr.returncode,'versions':{}}
    for version, helper in [('base',base),('round1',current)]:
        stem=name+'-'+version; cfile=out/(stem+'.c'); binary=out/(stem+'.bin')
        compiled=run([helper,entry,cfile,binary],stem+'-compile')
        detail={'compile_exit':compiled.returncode}
        if compiled.returncode==0:
            native=run([binary],stem+'-native'); binary.unlink()
            detail.update(native_exit=native.returncode,matches_node=native.stdout==nr.stdout and native.returncode==0)
        else:
            detail['native_executed']=False
        record['versions'][version]=detail
    results.append(record); print(json.dumps(record),flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n')
