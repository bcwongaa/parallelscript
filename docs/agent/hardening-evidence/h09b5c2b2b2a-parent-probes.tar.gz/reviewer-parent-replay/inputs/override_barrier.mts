class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 10; } class C1 { tag = 20; } class C2 { tag = 30; }
function choose(): boolean { return false; }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value, "parent"); } }
class M1 extends M0 { make<T>(value: T): Box<T> { return new Box<any>("wrong", "override") as any; } }
class M2 extends M0 { make<T>(value: T): Box<T> { return new Box(value, "other"); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.origin, box.value.tag); }
function read(receiver: Maker): Factory { return receiver.make.bind(receiver); }
use0(read(new M1()));
