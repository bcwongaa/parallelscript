class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 10; } class C1 { tag = 20; } class C2 { tag = 30; }
function choose(): boolean { return false; }
class M0 implements Maker { calls = 0; constructor(public label: string = "M0") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M1 implements Maker { calls = 0; constructor(public label: string = "M1") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M2 implements Maker { calls = 0; constructor(public label: string = "M2") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.origin, box.value.tag); }
function read(receiver: M0): Factory { const { make } = receiver; return make.bind(receiver); }
use0(read(new M0()));
