class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 10; } class C1 { tag = 20; } class C2 { tag = 30; }
function choose(): boolean { return false; }
class M0 implements Maker { calls = 0; constructor(public label: string = "M0") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M1 implements Maker { calls = 0; constructor(public label: string = "M1") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M2 implements Maker { calls = 0; constructor(public label: string = "M2") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.origin, box.value.tag); }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.origin, box.value.tag); }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.origin, box.value.tag); }
function read0(): Factory { const r: Maker = new M0(); return r.make.bind(r); } use0(read0());
function read1(): Factory { const r: Maker = new M1(); return r.make.bind(r); } use1(read1());
function read2(): Factory { const r: Maker = new M2(); return r.make.bind(r); } use2(read2());

