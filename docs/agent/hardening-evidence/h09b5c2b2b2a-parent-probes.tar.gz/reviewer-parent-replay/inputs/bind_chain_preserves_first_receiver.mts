class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 10; } class C1 { tag = 20; } class C2 { tag = 30; }
function choose(): boolean { return false; }
class Base { calls = 0; constructor(public label: string = "base") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M0 extends Base { make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M1 extends Base { make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
class M2 extends Base { make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.origin, box.value.tag); }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.origin, box.value.tag); }
function rebind(lookup: Base, receiver: Base): Factory { return lookup.make.bind(receiver); }
const a = rebind(new M0("lookup"), new M1("first")).bind(new M2("ignored")); use0(a); use1(a);
