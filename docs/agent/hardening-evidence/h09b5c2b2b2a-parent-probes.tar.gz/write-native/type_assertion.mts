class Box<T> { constructor(public value: T, public tag: string) {} }
type Factory = <T>(value: T) => Box<T>;
class A { tag = "a"; make<T>(value: T): Box<T> { return new Box(value, this.tag); } }
class B extends A { make<T>(value: T): Box<T> { return new Box(value, this.tag); } constructor() { super(); this.tag = "b"; } }
function read(receiver: A): Factory { (<any>receiver) = new B(); return receiver.make.bind(receiver); }
const factory = read(new A()); const box: Box<number> = factory(4); console.log(box.tag, box.value);
