import hashlib, json, os, pathlib, subprocess, sys

root = pathlib.Path('/home/bryan/projects/parallelscript')
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
snapshot = pathlib.Path('/tmp/pts-h09b5c2b2b2-rHJnXz/review-snapshot')
cases = [
    ('drop_inner_source', 'pts/lower/forwarding.go', 'receiverSource: source, ', '', 'TestCapturedReceiverWrappersOnlyInstantiateTheirConstructedMethods/direct$'),
    ('lookup_instead_of_thisarg', 'pts/lower/methods.go', 'source = args[0]', 'source = target.Expression()', 'TestCapturedReceiverBindUsesItsThisArgumentRatherThanTheMethodLookupObject$'),
]
results = []
for name, rel, old, new, test in cases:
    original = (snapshot/rel).read_text()
    assert original.count(old) == 1
    mutant = out/(name+'.go'); mutant.write_text(original.replace(old, new))
    overlay = out/(name+'-overlay.json')
    overlay.write_text(json.dumps({'Replace': {str(root/rel): str(mutant)}})+'\n')
    command = ['go', 'test', '-overlay='+str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '5m', './pts/driver', '-run', test]
    result = subprocess.run(command, cwd=root, env=dict(os.environ, GOMAXPROCS='1'), capture_output=True, timeout=300)
    (out/(name+'.jsonl')).write_bytes(result.stdout); (out/(name+'.err')).write_bytes(result.stderr)
    events = [json.loads(line) for line in result.stdout.splitlines()]
    failed = [e['Test'] for e in events if e['Action']=='fail' and e.get('Test')]
    executed = [e['Test'] for e in events if e['Action']=='run' and e.get('Test')]
    assert result.returncode != 0 and failed and executed, (name, 'mutant was not behaviorally rejected')
    assert b'build failed' not in result.stdout+result.stderr and not any(e['Action']=='build-fail' for e in events)
    record = {'mutation': name, 'command': command, 'exit': result.returncode, 'executed_tests': executed, 'failed_tests': failed, 'stderr_bytes': len(result.stderr), 'mutant_sha256': hashlib.sha256(mutant.read_bytes()).hexdigest()}
    results.append(record); print(json.dumps(record), flush=True)
(out/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
