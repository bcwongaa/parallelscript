class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
class M0 implements Maker { tag = 0; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read0(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { tag = 1; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read1(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { tag = 2; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read2(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
class M3 implements Maker { tag = 3; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read3(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
class M4 implements Maker { tag = 4; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read4(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
class M5 implements Maker { tag = 5; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read5(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
class M6 implements Maker { tag = 6; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read6(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
class M7 implements Maker { tag = 7; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read7(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
class M8 implements Maker { tag = 8; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read8(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
class M9 implements Maker { tag = 9; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read9(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
class M10 implements Maker { tag = 10; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read10(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
class M11 implements Maker { tag = 11; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read11(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
use0(read0(new M0()));
use1(read1(new M1()));
use2(read2(new M2()));
use3(read3(new M3()));
use4(read4(new M4()));
use5(read5(new M5()));
use6(read6(new M6()));
use7(read7(new M7()));
use8(read8(new M8()));
use9(read9(new M9()));
use10(read10(new M10()));
use11(read11(new M11()));
