class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
class M0 implements Maker { tag = 0; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read0(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { tag = 1; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read1(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { tag = 2; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read2(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
class M3 implements Maker { tag = 3; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read3(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
class M4 implements Maker { tag = 4; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read4(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
class M5 implements Maker { tag = 5; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read5(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
class M6 implements Maker { tag = 6; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read6(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
class M7 implements Maker { tag = 7; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read7(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
class M8 implements Maker { tag = 8; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read8(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
class M9 implements Maker { tag = 9; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read9(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
class M10 implements Maker { tag = 10; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read10(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
class M11 implements Maker { tag = 11; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read11(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
class M12 implements Maker { tag = 12; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read12(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use12(f: Factory): void { const box: Box<C12> = f(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
class M13 implements Maker { tag = 13; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read13(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use13(f: Factory): void { const box: Box<C13> = f(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
class M14 implements Maker { tag = 14; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read14(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use14(f: Factory): void { const box: Box<C14> = f(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
class M15 implements Maker { tag = 15; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read15(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use15(f: Factory): void { const box: Box<C15> = f(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
class M16 implements Maker { tag = 16; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read16(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use16(f: Factory): void { const box: Box<C16> = f(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
class M17 implements Maker { tag = 17; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read17(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use17(f: Factory): void { const box: Box<C17> = f(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
class M18 implements Maker { tag = 18; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read18(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use18(f: Factory): void { const box: Box<C18> = f(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
class M19 implements Maker { tag = 19; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read19(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use19(f: Factory): void { const box: Box<C19> = f(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
class M20 implements Maker { tag = 20; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read20(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use20(f: Factory): void { const box: Box<C20> = f(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
class M21 implements Maker { tag = 21; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read21(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use21(f: Factory): void { const box: Box<C21> = f(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
class M22 implements Maker { tag = 22; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read22(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use22(f: Factory): void { const box: Box<C22> = f(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
class M23 implements Maker { tag = 23; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read23(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use23(f: Factory): void { const box: Box<C23> = f(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
class M24 implements Maker { tag = 24; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read24(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use24(f: Factory): void { const box: Box<C24> = f(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
class M25 implements Maker { tag = 25; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read25(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use25(f: Factory): void { const box: Box<C25> = f(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
class M26 implements Maker { tag = 26; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read26(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use26(f: Factory): void { const box: Box<C26> = f(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
class M27 implements Maker { tag = 27; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read27(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use27(f: Factory): void { const box: Box<C27> = f(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
class M28 implements Maker { tag = 28; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read28(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use28(f: Factory): void { const box: Box<C28> = f(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
class M29 implements Maker { tag = 29; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read29(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use29(f: Factory): void { const box: Box<C29> = f(new C29()); console.log(box.value.tag); }
class C30 { tag = 30; }
class M30 implements Maker { tag = 30; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read30(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use30(f: Factory): void { const box: Box<C30> = f(new C30()); console.log(box.value.tag); }
class C31 { tag = 31; }
class M31 implements Maker { tag = 31; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read31(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use31(f: Factory): void { const box: Box<C31> = f(new C31()); console.log(box.value.tag); }
class C32 { tag = 32; }
class M32 implements Maker { tag = 32; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read32(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use32(f: Factory): void { const box: Box<C32> = f(new C32()); console.log(box.value.tag); }
class C33 { tag = 33; }
class M33 implements Maker { tag = 33; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read33(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use33(f: Factory): void { const box: Box<C33> = f(new C33()); console.log(box.value.tag); }
class C34 { tag = 34; }
class M34 implements Maker { tag = 34; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read34(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use34(f: Factory): void { const box: Box<C34> = f(new C34()); console.log(box.value.tag); }
class C35 { tag = 35; }
class M35 implements Maker { tag = 35; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read35(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use35(f: Factory): void { const box: Box<C35> = f(new C35()); console.log(box.value.tag); }
class C36 { tag = 36; }
class M36 implements Maker { tag = 36; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read36(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use36(f: Factory): void { const box: Box<C36> = f(new C36()); console.log(box.value.tag); }
class C37 { tag = 37; }
class M37 implements Maker { tag = 37; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read37(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use37(f: Factory): void { const box: Box<C37> = f(new C37()); console.log(box.value.tag); }
class C38 { tag = 38; }
class M38 implements Maker { tag = 38; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read38(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use38(f: Factory): void { const box: Box<C38> = f(new C38()); console.log(box.value.tag); }
class C39 { tag = 39; }
class M39 implements Maker { tag = 39; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read39(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use39(f: Factory): void { const box: Box<C39> = f(new C39()); console.log(box.value.tag); }
class C40 { tag = 40; }
class M40 implements Maker { tag = 40; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read40(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use40(f: Factory): void { const box: Box<C40> = f(new C40()); console.log(box.value.tag); }
class C41 { tag = 41; }
class M41 implements Maker { tag = 41; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read41(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use41(f: Factory): void { const box: Box<C41> = f(new C41()); console.log(box.value.tag); }
class C42 { tag = 42; }
class M42 implements Maker { tag = 42; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read42(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use42(f: Factory): void { const box: Box<C42> = f(new C42()); console.log(box.value.tag); }
class C43 { tag = 43; }
class M43 implements Maker { tag = 43; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read43(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use43(f: Factory): void { const box: Box<C43> = f(new C43()); console.log(box.value.tag); }
class C44 { tag = 44; }
class M44 implements Maker { tag = 44; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read44(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use44(f: Factory): void { const box: Box<C44> = f(new C44()); console.log(box.value.tag); }
class C45 { tag = 45; }
class M45 implements Maker { tag = 45; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read45(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use45(f: Factory): void { const box: Box<C45> = f(new C45()); console.log(box.value.tag); }
class C46 { tag = 46; }
class M46 implements Maker { tag = 46; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read46(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use46(f: Factory): void { const box: Box<C46> = f(new C46()); console.log(box.value.tag); }
class C47 { tag = 47; }
class M47 implements Maker { tag = 47; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read47(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use47(f: Factory): void { const box: Box<C47> = f(new C47()); console.log(box.value.tag); }
class C48 { tag = 48; }
class M48 implements Maker { tag = 48; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read48(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use48(f: Factory): void { const box: Box<C48> = f(new C48()); console.log(box.value.tag); }
class C49 { tag = 49; }
class M49 implements Maker { tag = 49; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read49(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use49(f: Factory): void { const box: Box<C49> = f(new C49()); console.log(box.value.tag); }
class C50 { tag = 50; }
class M50 implements Maker { tag = 50; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read50(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use50(f: Factory): void { const box: Box<C50> = f(new C50()); console.log(box.value.tag); }
class C51 { tag = 51; }
class M51 implements Maker { tag = 51; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read51(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use51(f: Factory): void { const box: Box<C51> = f(new C51()); console.log(box.value.tag); }
class C52 { tag = 52; }
class M52 implements Maker { tag = 52; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read52(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use52(f: Factory): void { const box: Box<C52> = f(new C52()); console.log(box.value.tag); }
class C53 { tag = 53; }
class M53 implements Maker { tag = 53; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read53(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use53(f: Factory): void { const box: Box<C53> = f(new C53()); console.log(box.value.tag); }
class C54 { tag = 54; }
class M54 implements Maker { tag = 54; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read54(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use54(f: Factory): void { const box: Box<C54> = f(new C54()); console.log(box.value.tag); }
class C55 { tag = 55; }
class M55 implements Maker { tag = 55; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read55(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use55(f: Factory): void { const box: Box<C55> = f(new C55()); console.log(box.value.tag); }
class C56 { tag = 56; }
class M56 implements Maker { tag = 56; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read56(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use56(f: Factory): void { const box: Box<C56> = f(new C56()); console.log(box.value.tag); }
class C57 { tag = 57; }
class M57 implements Maker { tag = 57; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read57(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use57(f: Factory): void { const box: Box<C57> = f(new C57()); console.log(box.value.tag); }
class C58 { tag = 58; }
class M58 implements Maker { tag = 58; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read58(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use58(f: Factory): void { const box: Box<C58> = f(new C58()); console.log(box.value.tag); }
class C59 { tag = 59; }
class M59 implements Maker { tag = 59; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read59(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use59(f: Factory): void { const box: Box<C59> = f(new C59()); console.log(box.value.tag); }
use0(read0(new M0()));
use1(read1(new M1()));
use2(read2(new M2()));
use3(read3(new M3()));
use4(read4(new M4()));
use5(read5(new M5()));
use6(read6(new M6()));
use7(read7(new M7()));
use8(read8(new M8()));
use9(read9(new M9()));
use10(read10(new M10()));
use11(read11(new M11()));
use12(read12(new M12()));
use13(read13(new M13()));
use14(read14(new M14()));
use15(read15(new M15()));
use16(read16(new M16()));
use17(read17(new M17()));
use18(read18(new M18()));
use19(read19(new M19()));
use20(read20(new M20()));
use21(read21(new M21()));
use22(read22(new M22()));
use23(read23(new M23()));
use24(read24(new M24()));
use25(read25(new M25()));
use26(read26(new M26()));
use27(read27(new M27()));
use28(read28(new M28()));
use29(read29(new M29()));
use30(read30(new M30()));
use31(read31(new M31()));
use32(read32(new M32()));
use33(read33(new M33()));
use34(read34(new M34()));
use35(read35(new M35()));
use36(read36(new M36()));
use37(read37(new M37()));
use38(read38(new M38()));
use39(read39(new M39()));
use40(read40(new M40()));
use41(read41(new M41()));
use42(read42(new M42()));
use43(read43(new M43()));
use44(read44(new M44()));
use45(read45(new M45()));
use46(read46(new M46()));
use47(read47(new M47()));
use48(read48(new M48()));
use49(read49(new M49()));
use50(read50(new M50()));
use51(read51(new M51()));
use52(read52(new M52()));
use53(read53(new M53()));
use54(read54(new M54()));
use55(read55(new M55()));
use56(read56(new M56()));
use57(read57(new M57()));
use58(read58(new M58()));
use59(read59(new M59()));
