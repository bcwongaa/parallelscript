class Box<T> { constructor(public value: T) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
class M0 implements Maker { tag = 0; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read0(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
class M1 implements Maker { tag = 1; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read1(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
class M2 implements Maker { tag = 2; make<T>(value: T): Box<T> { console.log(this.tag); return new Box(value); } }
function read2(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
use0(read0(new M0()));
use1(read1(new M1()));
use2(read2(new M2()));
