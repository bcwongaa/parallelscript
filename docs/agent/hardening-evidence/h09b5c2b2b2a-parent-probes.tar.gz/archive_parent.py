import hashlib, json, pathlib, sys, tarfile

root = pathlib.Path(sys.argv[1]).resolve()
output = pathlib.Path(sys.argv[2]).resolve()
assert not output.exists(), output
entries = []
excluded = []
for path in sorted(root.rglob('*')):
    if path.is_symlink():
        raise RuntimeError(f'unexpected symlink: {path}')
    if not path.is_file():
        continue
    name = str(path.relative_to(root))
    with path.open('rb') as source:
        binary = source.read(4) == b'\x7fELF'
    if binary or path.suffix == '.bin' or path.name == 'ARCHIVE_CONTENTS.json':
        excluded.append(name)
        continue
    entries.append({'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
manifest = root/'ARCHIVE_CONTENTS.json'
manifest.write_text(json.dumps({'files':entries,'excluded_binaries':excluded},indent=2)+'\n')
with tarfile.open(output, 'w:gz', compresslevel=9) as archive:
    for entry in entries:
        archive.add(root/entry['path'],arcname=entry['path'],recursive=False)
    archive.add(manifest,arcname=manifest.name,recursive=False)
with tarfile.open(output,'r:gz') as archive:
    members=archive.getmembers()
    for member in members:
        name=pathlib.PurePosixPath(member.name)
        assert member.isfile() and not name.is_absolute() and '..' not in name.parts,member.name
        with archive.extractfile(member) as source:
            assert source.read(4) != b'\x7fELF',member.name
print(json.dumps({'archive':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'regular_files':len(entries)+1,'excluded_binaries':excluded},indent=2))
