import collections, gzip, hashlib, json, os, pathlib, subprocess, sys, time
ROOT = pathlib.Path('/home/bryan/projects/parallelscript')
OUT = pathlib.Path(sys.argv[1]); OUT.mkdir(parents=True, exist_ok=True)
def manifest():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for base in ('pts', 'cmd', 'internal') for p in (ROOT/base).rglob('*')
            if p.is_file() and not p.is_symlink() and p.suffix in ('.go', '.pts', '.c', '.h', '.json', '.ts')}
def save(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
before = manifest(); save('sources-before.json', before)
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
start = time.monotonic()
with (OUT/'build.out').open('w') as out, (OUT/'build.err').open('w') as err:
    build = subprocess.run(['make', 'build'], cwd=ROOT, env=env, stdout=out, stderr=err)
result = {'build_exit': build.returncode, 'build_seconds': time.monotonic()-start}
cli = hashlib.sha256((ROOT/'pts-bin/pts').read_bytes()).hexdigest(); result['cli_before'] = cli
if build.returncode == 0:
    command = ['go','test','-count=1','-json','-p','4','-parallel','4','-timeout','40m','./pts/...','./cmd/pts/']
    result['command'] = command; start = time.monotonic()
    with (OUT/'suite.jsonl').open('w') as out, (OUT/'suite.err').open('w') as err:
        suite = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=err)
    result['suite_exit'] = suite.returncode; result['suite_seconds'] = time.monotonic()-start
    counts = collections.Counter(); corpus = collections.Counter(); packages = {}
    for line in (OUT/'suite.jsonl').read_text().splitlines():
        try: event=json.loads(line)
        except ValueError: continue
        action=event.get('Action'); test=event.get('Test')
        if action in ('pass','fail','skip'):
            if test:
                counts[action]+=1
                if test.startswith('TestCorpusMatchesNode/') and test.count('/') == 2: corpus[action]+=1
            else: packages[event['Package']]=action
    result.update(counts=dict(counts), corpus=dict(corpus), packages=packages)
    with (OUT/'suite.jsonl').open('rb') as source, gzip.open(OUT/'suite.jsonl.gz','wb') as target:
        target.write(source.read())
after = manifest(); save('sources-after.json', after)
result['source_count']=len(before); result['sources_unchanged']=before==after
result['cli_after']=hashlib.sha256((ROOT/'pts-bin/pts').read_bytes()).hexdigest()
result['stderr_bytes']={name:(OUT/name).stat().st_size for name in ('build.err','suite.err') if (OUT/name).exists()}
save('summary.json',result); print(json.dumps(result,indent=2))
sys.exit(0 if result.get('suite_exit')==0 and before==after and cli==result['cli_after'] else 1)
