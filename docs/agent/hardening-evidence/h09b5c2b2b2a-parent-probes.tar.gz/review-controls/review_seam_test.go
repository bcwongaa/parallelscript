package lower

import (
 "fmt"
 "strings"
 "testing"

 "github.com/microsoft/typescript-go/internal/ast"
 "github.com/microsoft/typescript-go/pts/ir"
)

func capturedSeam(t *testing.T, l *lowerer, probe *ast.Node) *ast.Node {
 t.Helper()
 receiver := &ir.Local{}
 forward := l.methodForward(receiver, method{name: "make", result: ir.Value, call: func(ir.Expr, []ir.Expr) ir.Expr { return &ir.UndefinedConst{} }}, nil, nil, nil, probe)
 call := forward(&demand{want: &ir.FuncType{Result: ir.Value}}, &ir.Func{}, nil)
 if len(l.demands) != 1 { t.Fatal("missing captured synthetic demand") }
 if call.(*ir.InstanceCall).X.(*ir.LocalRef).Local != receiver { t.Fatal("proof substituted for runtime capture") }
 return l.demands[0].receiverSource
}

func TestD207ReviewCapturedReceiverSeamConservatism(t *testing.T) {
 for _, tc := range []struct{name, source string; known bool}{
  {"known", "class A {} function make(): A { return new A(); } const probe = make(); probe;", true},
  {"parameter_join", "class A {} class B {} function read(probe: A): void { probe; } read(new A()); read(new B());", true},
  {"mutable", "class A {} let source = new A(); const probe = source; probe;", false},
  {"dynamic", "class A {} const source: any = new A(); const probe: A = source; probe;", false},
  {"generic_lexical_alias", "class A {} const fixed = new A(); function outer<T>(marker: T): void { const probe = fixed; probe; } outer(1);", false},
  {"contextual_generic_alias", "class A {} const fixed = new A(); const outer: <T>(marker: T) => void = marker => { const probe = fixed; probe; }; outer(1);", false},
  {"generic_class_alias", "class A {} const fixed = new A(); class Outer<T> { read(): void { const probe = fixed; probe; } } new Outer<number>().read();", false},
  {"replacement", "class B {} class A { constructor() { return new B(); } } const probe = new A(); probe;", false},
  {"cycle", "class A {} function left(): A { return right(); } function right(): A { return left(); } const probe = left(); probe;", false},
 } {
  t.Run(tc.name, func(t *testing.T) {
   for _, receiverFirst := range []bool{false,true} {
    t.Run(fmt.Sprint(receiverFirst),func(t *testing.T) {
     l, probe := valueFlowProbe(t, tc.source)
     source := capturedSeam(t,l,probe)
     functions := func() { steps := maxValueFlowSteps; if l.valueSources(probe,&steps,0) != nil { t.Fatal("function cache should remain UNKNOWN") } }
     receivers := func() { steps := maxValueFlowSteps; got := source != nil && l.receiverSources(source,&steps,0) != nil; if got != tc.known { t.Fatalf("receiver known=%t want=%t",got,tc.known) } }
     if receiverFirst { receivers(); functions() } else { functions(); receivers() }
     functions(); receivers()
     if len(l.valueFlow.active) != 0 || len(l.valueFlow.receivers.active) != 0 { t.Fatal("unfinished proof") }
    })
   }
  })
 }
}

func TestD207ReviewCapturedReceiverSeamLimits(t *testing.T) {
 t.Run("depth",func(t *testing.T) {
  var b strings.Builder
  b.WriteString("class A {} const a0 = new A();\n")
  for i:=1;i<=maxValueFlowDepth+1;i++ { fmt.Fprintf(&b,"const a%d = a%d;\n",i,i-1) }
  fmt.Fprintf(&b,"const probe = a%d; probe;",maxValueFlowDepth+1)
  l,probe := valueFlowProbe(t,b.String()); source := capturedSeam(t,l,probe)
  steps:=maxValueFlowSteps
  if l.receiverSources(source,&steps,0)!=nil { t.Fatal("depth-exhausted receiver must remain UNKNOWN") }
  if steps==0 { t.Fatal("expected depth rather than work exhaustion") }
  steps=maxValueFlowSteps
  if l.receiverSources(source,&steps,0)!=nil || steps!=maxValueFlowSteps { t.Fatal("cached depth exhaustion restarted") }
 })
 t.Run("work",func(t *testing.T) {
  l,probe:=valueFlowProbe(t,"class A { constructor() { let n=0; "+strings.Repeat("n++;",200)+" } } const probe=new A(); probe;")
  source:=capturedSeam(t,l,probe); steps:=50
  if l.receiverSources(source,&steps,0)!=nil || steps!=0 { t.Fatal("work-exhausted receiver must remain UNKNOWN") }
  steps=maxValueFlowSteps
  if l.receiverSources(source,&steps,0)!=nil || steps!=maxValueFlowSteps { t.Fatal("cached work exhaustion restarted") }
 })
 for _,count:=range []int{256,257} {
  t.Run(fmt.Sprint(count),func(t *testing.T) {
   var b strings.Builder
   for i:=0;i<count;i++ { fmt.Fprintf(&b,"class M%d {}\n",i) }
   b.WriteString("function read(probe: object): void { probe; }\n")
   for i:=0;i<count;i++ { fmt.Fprintf(&b,"read(new M%d());\n",i) }
   l,probe:=valueFlowProbe(t,b.String()); source:=capturedSeam(t,l,probe)
   steps:=maxValueFlowSteps*4
   sources:=l.receiverSources(source,&steps,0)
   if steps==0 { t.Fatal("source-count bound must be isolated from work budget") }
   if count==256 { if sources==nil || len(sources)!=256 { t.Fatalf("want 256 captures, got %d",len(sources)) } } else if sources!=nil { t.Fatalf("257 captures must be UNKNOWN, got %d",len(sources)) }
  })
 }
}
