package lower

import (
 "testing"
 "github.com/microsoft/typescript-go/pts/ir"
)

// This probes the new wrapper-to-receiver seam, not native assignment lowering.
func TestD207ReviewCapturedParameterAssertionWritesStayUnknown(t *testing.T) {
 for _, target := range []string{"(receiver as any)", "(<any>receiver)", "receiver!", "(receiver satisfies A)"} {
  t.Run(target, func(t *testing.T) {
   l, probe := valueFlowProbe(t, "class A {} class B {} function read(receiver: A): void { "+target+" = new B(); const probe = receiver; probe; } read(new A());")
   forward := l.methodForward(&ir.Local{}, method{name: "make", result: ir.Value, call: func(ir.Expr, []ir.Expr) ir.Expr { return &ir.UndefinedConst{} }}, nil, nil, nil, probe)
   forward(&demand{want: &ir.FuncType{Result: ir.Value}}, &ir.Func{}, nil)
   if len(l.demands) != 1 { t.Fatalf("missing synthetic demand") }
   steps := maxValueFlowSteps
   sources := l.receiverSources(l.demands[0].receiverSource, &steps, 0)
   if sources != nil { t.Fatalf("mutated captured receiver must be UNKNOWN, got %v", returnedSourceNames(sources)) }
  })
 }
}
