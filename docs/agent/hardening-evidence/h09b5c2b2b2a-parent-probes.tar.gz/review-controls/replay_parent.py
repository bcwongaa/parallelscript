import argparse,json,os,pathlib,shutil,subprocess,sys
HERE=pathlib.Path(__file__).resolve().parent
REVIEW=HERE.parent
p=argparse.ArgumentParser(description='Replay exact review syntax with independent AllInstances helpers; helpers take SOURCE OUTPUT_C BINARY_OR_DASH.')
p.add_argument('--base-helper');p.add_argument('--current-helper');p.add_argument('--output',required=True)
p.add_argument('--worktree',default='/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25')
p.add_argument('--validate-only',action='store_true')
a=p.parse_args();out=pathlib.Path(a.output).resolve()
if not a.validate_only:
 if not a.base_helper or not a.current_helper:p.error('both helper paths are required')
 out.mkdir(exist_ok=False)
 for d in ['inputs','raw','bin']:(out/d).mkdir()
 for name in ['generic_captured_receiver_sources.pts','generic_captured_receiver_unknowns.pts']:
  shutil.copyfile(REVIEW/'round2/snapshot/pts/tests/run'/name,out/'inputs'/name)
 env=dict(os.environ,D207_REVIEW_ROOT=str(out),D207_REVIEW_WORKTREE=a.worktree,D207_BASE_HELPER=str(pathlib.Path(a.base_helper).resolve()),D207_CURRENT_HELPER=str(pathlib.Path(a.current_helper).resolve()),GOMAXPROCS='1',PTS_HOME='/home/bryan/projects/parallelscript')
 for script,args in [('matrix.py',['prepare']),('matrix.py',[]),('followup.py',[]),('growth.py',[])]:
  log='prepare' if args else script.removesuffix('.py')
  with (out/'raw'/(log+'.stdout')).open('w') as stdout,(out/'raw'/(log+'.stderr')).open('w') as stderr:
   r=subprocess.run([sys.executable,'-I',str(HERE/script),*args],cwd=a.worktree,env=env,stdout=stdout,stderr=stderr)
  if r.returncode:raise SystemExit(r.returncode)
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'pass':bool(ok),'detail':detail})
def emit_ok(r):return all(r['versions'][v]['emit']['exit']==0 for v in ['base','current'])
def native_matches(r):return all(r['versions'][v].get('matches_node') is True for v in ['base','current'])
rows=json.loads((out/'raw/matrix-results.json').read_text())
unsupported={'destructured_class','parameter_write_asserted','parameter_write_typeasserted','parameter_write_nonnull'}
preexisting={'contextual_generic_alias'}
barrier={'override_barrier'}
supported=0
for r in rows:
 name=r['name']
 if name in unsupported:
  check(name,all(r['versions'][v]['emit']['exit']==3 and 'PTS1001' in r['versions'][v]['emit']['stderr'] for v in ['base','current']),'unsupported identically at exact base/final; not native acceptance')
 elif name in preexisting:
  check(name,emit_ok(r) and all(r['versions'][v]['pairs']==[] and r['versions'][v]['native']['exit']==1 and 'got Box<any>' in r['versions'][v]['native']['stderr'] for v in ['base','current']),'pre-existing contextual bind failure (C255); not D207 regression or acceptance')
 elif name in barrier:
  c=r['versions']['current']
  check(name,emit_ok(r) and all(r['versions'][v]['native']['exit']==1 and 'at M1.make' in r['versions'][v]['native']['stderr'] for v in ['base','current']) and c['pairs']==[['M0','C0'],['M1','C0']] and c['registered']==c['pairs'],'checked-any override must reject in override, not fall through to ancestor')
 else:
  supported+=1;check(name,emit_ok(r) and native_matches(r) and r['versions']['current'].get('pair_check') is True,'supported native/Node match and exact required/excluded definitions plus class entries')
follow=json.loads((out/'raw/followup-results.json').read_text())
for r in follow:
 name=r['name']
 if name in ['class_arrow_property_as_method','class_function_property_as_method']:
  check(name,all(r['versions'][v]['emit']['exit']==3 and 'PTS1001' in r['versions'][v]['emit']['stderr'] for v in ['base','current']),'unsupported identically at base/final')
 elif name.startswith('contextual_generic_inbody'):
  check(name,emit_ok(r) and all(r['versions'][v]['native']['exit']==1 and 'got Box<any>' in r['versions'][v]['native']['stderr'] for v in ['base','current']),'pre-existing contextual explicit-bind failure even with in-body demand')
 else:
  supported+=1;check(name,emit_ok(r) and native_matches(r) and r['versions']['current'].get('pair_check',True),'supported native/Node match; exact targets checked where specified')
for r in json.loads((out/'raw/growth-results.json').read_text()):
 check(r['name'],all(x['exit']==0 and x.get('pair_check') is True for x in r['versions'].values()) and (r['known'] or r['byte_identical']),'known24 576->24, unknown12 all144 byte-identical')
result={'checks':checks,'supported_native_node_matches':supported,'pass':all(x['pass'] for x in checks)}
(out/'raw/replay-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'checks':len(checks),'supported_native_node_matches':supported,'failures':[x for x in checks if not x['pass']]}))
raise SystemExit(0 if result['pass'] else 1)
