#!/usr/bin/python3 -I
import hashlib, json, os, pathlib, subprocess, sys

root = pathlib.Path('/tmp/pts-h09b5c2b2b2-rHJnXz')
version = pathlib.Path(sys.argv[0]).name
helper = root/('strict-base' if version == 'strict-base-adapter' else 'strict-final')
args = sys.argv[1:]
assert len(args) == 3
if args[-1] == '-':
    args = args[:-1]
result = subprocess.run([str(helper), *args], capture_output=True)
sys.stdout.buffer.write(result.stdout); sys.stderr.buffer.write(result.stderr)
normalized = 3 if result.returncode == 1 and b'PTS1001' in result.stderr else result.returncode
record = {'helper':str(helper), 'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(), 'command':[str(helper),*args], 'original_exit':result.returncode, 'review_interface_exit':normalized, 'stdout':result.stdout.decode(errors='replace'), 'stderr':result.stderr.decode(errors='replace')}
with (pathlib.Path(os.environ['D207_REVIEW_ROOT'])/'raw/parent-helper-adapter.jsonl').open('a') as out:
    out.write(json.dumps(record)+'\n')
sys.exit(normalized)
