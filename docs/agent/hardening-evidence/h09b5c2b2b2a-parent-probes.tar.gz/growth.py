import hashlib, json, os, pathlib, re, subprocess, sys, time

out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=False)
base, current = map(pathlib.Path, sys.argv[2:4])
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript')

def run(command, stem):
    start = time.monotonic()
    result = subprocess.run(list(map(str, command)), env=env, capture_output=True, timeout=300)
    (out/(stem+'.out')).write_bytes(result.stdout)
    (out/(stem+'.err')).write_bytes(result.stderr)
    if result.returncode:
        raise RuntimeError(f'{command}: exit {result.returncode}; see {stem}.err')
    return result.stdout, time.monotonic()-start

def source(n, unknown):
    lines = ['class Box<T> { constructor(public value: T) {} }',
             'interface Maker { make<T>(value: T): Box<T>; }',
             'type Factory = <T>(value: T) => Box<T>;']
    for i in range(n):
        lines += [f'class C{i} {{ tag = {i}; }}',
                  f'class M{i} implements Maker {{ tag = {i}; make<T>(value: T): Box<T> {{ console.log(this.tag); return new Box(value); }} }}',
                  f'function read{i}(receiver: Maker): Factory {{ return receiver.make.bind(receiver); }}',
                  f'function use{i}(f: Factory): void {{ const box: Box<C{i}> = f(new C{i}()); console.log(box.value.tag); }}']
    if unknown:
        lines.append('const held: any[] = ['+', '.join(f'new M{i}()' for i in range(n))+'];')
    for i in range(n):
        receiver = f'held[{i}]' if unknown else f'new M{i}()'
        lines.append(f'use{i}(read{i}({receiver}));')
    return '\n'.join(lines)+'\n'

results = []
for n, unknown in [(3, False), (12, False), (60, False), (12, True)]:
    case = ('unknown' if unknown else 'known')+str(n)
    entry = out/(case+'.pts'); entry.write_text(source(n, unknown))
    node_entry = out/(case+'.mts'); node_entry.write_bytes(entry.read_bytes())
    expected = ''.join(f'{i}\n{i}\n' for i in range(n)).encode()
    node_output, node_seconds = run(['node', '--no-warnings', '--experimental-transform-types', node_entry], case+'-node')
    assert node_output == expected, (case, 'Node output', node_output)
    record = {'case': case, 'n': n, 'unknown': unknown, 'source_sha256': hashlib.sha256(entry.read_bytes()).hexdigest(),
              'node_seconds': node_seconds, 'node_exit': 0, 'versions': {}}
    for round in range(2):
        order = [('base', base), ('current', current)] if round == 0 else [('current', current), ('base', base)]
        for version, helper in order:
            stem = f'{case}-{version}-r{round}'
            cfile = out/(stem+'.c')
            _, seconds = run([helper, entry, cfile], stem+'-emit')
            data = cfile.read_bytes()
            pairs = {(int(a), int(b)) for a, b in re.findall(rb'\bpts_fn_M([0-9]+)_make_C([0-9]+)\(', data)}
            required = {(i, j) for i in range(n) for j in range(n) if version == 'base' or unknown or i == j}
            assert pairs == required, (case, version, 'missing', required-pairs, 'extra', pairs-required)
            metric = {'round': round, 'emit_seconds': seconds, 'bytes': len(data), 'lines': data.count(b'\n'),
                      'sha256': hashlib.sha256(data).hexdigest(), 'method_pairs': len(pairs)}
            record['versions'].setdefault(version, []).append(metric)
    for version, helper in [('base', base), ('current', current)]:
        measures = record['versions'][version]
        assert measures[0]['sha256'] == measures[1]['sha256'], (case, version, 'nondeterministic C')
        cfile = out/(f'{case}-{version}-r0.c'); binary = out/(f'{case}-{version}.bin')
        _, seconds = run([helper, entry, cfile, binary], case+'-'+version+'-compile')
        assert hashlib.sha256(cfile.read_bytes()).hexdigest() == measures[0]['sha256']
        output, native_seconds = run([binary], case+'-'+version+'-native')
        assert output == expected, (case, version, 'native output', output)
        record['versions'][version+'-native'] = {'compile_seconds': seconds, 'native_seconds': native_seconds, 'exit': 0, 'matches_node': True}
        binary.unlink()
    if unknown:
        assert record['versions']['base'][0]['sha256'] == record['versions']['current'][0]['sha256'], 'unknown C changed'
    results.append(record)
    (out/'summary.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(record), flush=True)
