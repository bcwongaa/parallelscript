package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run() error {
	ctx := context.Background()
	code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	if err != nil {
		return err
	}
	if err = os.WriteFile(os.Args[2], []byte(code), 0600); err != nil || len(os.Args) < 4 {
		return err
	}
	cc, err := toolchain.New()
	if err != nil {
		return err
	}
	runtime, err := cc.Runtime(ctx, toolchain.Release)
	if err != nil {
		return err
	}
	return cc.CompileProgram(ctx, runtime, []string{os.Args[2]}, os.Args[3])
}
