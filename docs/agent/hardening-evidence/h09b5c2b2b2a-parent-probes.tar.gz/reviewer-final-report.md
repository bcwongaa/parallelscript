# Independent reviewer final report (returned in-session, 2026-10-22)

Agent: ab251d7a56b5f3e01. Scope: D-207 only. Verdict: READY.

No remaining verified correctness, capture/GC-safety, race-safety, or supported JS-semantics regression was found in the final frozen slice.

## Resolved finding

The original snapshot could incorrectly prove an asserted-written receiver parameter as its original constructor source. The synthetic demand at pts/lower/forwarding.go:157 consumed that stale proof because the write index did not unwrap assertions, non-null expressions, or satisfies. The minimal fix at pts/lower/outside_assignments.go:63–65 resolves this.

- Original index: 22 failing test events, independently reproduced.
- Fixed index: all corresponding controls pass.
- Proof-conservatism defect only: these assignment-target forms reject before native compilation on both base and final versions. No supported native wrong-output regression was demonstrated.

## Independently verified results

- Final affected packages: 492 pass events, 0 failures/skips, empty stderr: lower301, driver191.
- Independent capture/cache/budget controls: 33 pass events.
- Exact-base precision tests: expected RED26 pass /20 fail events.
- Exact-base literal/function-forwarder exclusion: expected RED2 pass /3 fail events.
- Strict AllInstances/native/Node replay: 40/40 validated checks, including28 supported programs matching strict .mts Node on both base and final.
- Known receiver growth,24 classes/signatures: 576→24 method targets and registrations;11584→5512 C lines.
- Unknown receiver control,12 classes/signatures: all144 targets retained; byte-identical C,4262 lines.

Coverage includes differing bind thisArg, unknown lookup versus known capture, shared wrapper ASTs, distinct runtime capture identities, evaluation order/count, generic boundaries, inheritance/override barriers, destructuring conservatism, source-count limits, exhaustion, cycles, and separate receiver/function cache orders. Earlier failures and unsupported/pre-existing contextual-bind controls are preserved, not counted as supported acceptance passes. Final test corrections retain required-target assertions and genuinely exercise the intended source bounds.

Reviewed production SHA256:
forwarding.go19097407b321de920a527b97d994b4afc532fbd1545f25be597b224f35a3de0a
generics.go e23ab3c146f2359a0cdb5fb65ab866ef8f121f01c3ef4e7a238db46e1977157d
methods.go fd89b32893f95938682e8a823a67f77bc86ce9e11df2cae0ae90f06986c760e8
destructuring.go196561860548fac765cf21d0e3271d523602655a5e690242d5f15a8bac069fb8
outside_assignments.go93a2367fcf101ea6b9e49e72ef774ffbe92ee21732d0353577ef1cfdfea109ab

All11 frozen production/test/fixture hashes rechecked against parent and match. Complete manifest: /tmp/pts-d207-review-ab25/round2/snapshot/sha256.json.

Independent33-control source: /tmp/pts-d207-review-ab25/tests/review_seam_test.go.
Parent test-only overlay: /tmp/pts-d207-review-ab25/round2/seam-only-parent.json.
Command: GOMAXPROCS=1 PTS_HOME=/home/bryan/projects/parallelscript go -C /home/bryan/projects/parallelscript test -count=1 -json -p 1 -parallel 1 -overlay /tmp/pts-d207-review-ab25/round2/seam-only-parent.json -run '^TestD207ReviewCapturedReceiverSeam' github.com/microsoft/typescript-go/pts/lower.

Exact command/raw paths under /tmp/pts-d207-review-ab25/round2/raw/:
go-commands.json, go-validation.json, matrix-commands.json, followup-commands.json, growth-results.json, replay-validation.json.

Safe archive: /tmp/pts-d207-review-ab25-final.tar.gz.
SHA256:4ac0210504bd168694d03c04aaf8ca111329899404a522d5aaa9283e29a2dd17.
Per-member manifest: /tmp/pts-d207-review-ab25-manifest.json.
379 regular UTF8 source/text members; no ELF, symlink or hardlink.

Isolated checkout clean at be71aac86. Heavy slot released; no reviewer jobs remain. Parent full-suite result not claimed. H09b5b independent acceptance remains BLOCKED and untouched.
