"""Generate the finite H13 header-framing cases consumed by Go and the wire probe."""
import argparse
import json
from pathlib import Path


def case(name, headers, body="", status=400, decoded="", header_only=False):
    return {"name": name, "headers": headers, "body": body, "status": status,
            "decoded": decoded, "headerOnly": header_only}


def cases():
    chunked = "2\r\nab\r\n0\r\n\r\n"
    rows = [
        case("unframed-empty", "", status=200),
        case("cl-zero", "Content-Length: 0\r\n", status=200),
        case("cl-two", "Content-Length: 2\r\n", "ab", 200, "ab"),
        case("cl-case-and-ows", "cOnTeNt-LeNgTh:\t 002 \t\r\n", "ab", 200, "ab"),
        case("cl-many-leading-zeroes", "Content-Length: " + "0" * 48 + "2\r\n", "ab", 200, "ab"),
        case("cl-many-zeroes", "Content-Length: " + "0" * 48 + "\r\n", status=200),
        case("chunked", "Transfer-Encoding: chunked\r\n", chunked, 200, "ab"),
        case("chunked-mixed-case", "Transfer-Encoding: ChUnKeD\r\n", chunked, 200, "ab"),
        case("chunked-leading-ows", "Transfer-Encoding:\t chunked\r\n", chunked, 200, "ab"),
        case("chunked-trailing-spaces", "Transfer-Encoding: chunked  \r\n", chunked, 200, "ab"),
        case("chunked-trailing-tab", "Transfer-Encoding: chunked\t\r\n", chunked, 200, "ab"),
        case("chunked-case-and-ows", "tRaNsFeR-EnCoDiNg:\t ChUnKeD \t\r\n", chunked, 200, "ab"),
    ]
    for name, value in [
        ("empty", ""), ("ows-only", " \t"), ("plus", "+2"),
        ("minus", "-2"), ("negative-zero", "-0"), ("positive-zero", "+0"),
        ("decimal-point", "2.0"), ("exponent", "2e0"), ("hex", "0x2"),
        ("embedded-space", "0 2"), ("embedded-tab", "0\t2"),
        ("suffix", "2x"), ("unicode-digit", "２"),
        ("vertical-tab", "\v2"), ("form-feed", "\f2"),
        ("comma-equal", "2, 2"), ("comma-conflict", "2, 3"),
        ("huge-with-suffix", "9" * 48 + "x"), ("above-cap-with-suffix", "67108865x"),
    ]:
        rows.append(case("cl-" + name, "Content-Length: " + value + "\r\n", "ab" if value in ["+2", "-2"] else ""))
    for name, first, second in [
        ("same", "2", "2"), ("same-numeric", "2", "02"),
        ("zero", "0", "0"), ("conflict", "2", "3"),
        ("conflict-reverse", "3", "2"), ("case-conflict", "0", "2"),
        ("above-cap-same", "67108865", "67108865"),
        ("above-cap-conflict", "67108865", "0"),
    ]:
        rows.append(case("cl-duplicate-" + name,
                         "Content-Length: " + first + "\r\ncOnTeNt-LeNgTh: " + second + "\r\n",
                         "ab" if second in ["2", "02"] else ""))
    for name, value in [
        ("empty", ""), ("ows-only", " \t"), ("unsupported", "gzip"),
        ("identity", "identity"), ("nonfinal-chunked", "chunked, gzip"),
        ("unsupported-prefix", "gzip, chunked"), ("unknown-prefix", "unknown, chunked"),
        ("duplicate-list", "chunked, chunked"), ("leading-comma", ",chunked"),
        ("trailing-comma", "chunked,"), ("double-comma", "gzip,,chunked"),
        ("parameter", "chunked; q=1"), ("quoted", '"chunked"'),
        ("token-suffix", "chunkedX"),
    ]:
        rows.append(case("te-" + name, "Transfer-Encoding: " + value + "\r\n", chunked if "chunked" in value else ""))
    for name, first, second in [
        ("same", "chunked", "chunked"), ("unsupported-first", "gzip", "chunked"),
        ("unsupported-last", "chunked", "gzip"), ("empty-first", "", "chunked"),
        ("empty-last", "chunked", ""),
    ]:
        rows.append(case("te-duplicate-" + name,
                         "Transfer-Encoding: " + first + "\r\ntRaNsFeR-EnCoDiNg: " + second + "\r\n",
                         chunked if second == "chunked" else ""))
    for name, length, transfer, reverse in [
        ("cl-te", "2", "chunked", False), ("te-cl", "2", "chunked", True),
        ("cl-zero-te", "0", "chunked", False), ("te-cl-zero", "0", "chunked", True),
        ("cl-unsupported-te", "2", "gzip", False), ("unsupported-te-cl", "2", "gzip", True),
        ("cl-empty-te", "0", "", False), ("empty-te-cl", "0", "", True),
        ("cl-huge-te", "9" * 48, "chunked", False),
        ("te-cl-huge", "9" * 48, "chunked", True),
        ("cl-above-cap-unsupported-te", "67108865", "gzip", False),
        ("unsupported-te-cl-above-cap", "67108865", "gzip", True),
    ]:
        cl = "Content-Length: " + length + "\r\n"
        te = "Transfer-Encoding: " + transfer + "\r\n"
        rows.append(case(name, te + cl if reverse else cl + te, chunked if transfer == "chunked" else "ab"))
    for name, value in [("above-cap", "67108865"), ("int64-max", "9223372036854775807"),
                        ("int64-overflow", "9223372036854775808"), ("huge", "9" * 48),
                        ("leading-zeroes-above-cap", "0" * 48 + "67108865")]:
        rows.append(case("cl-" + name, "Content-Length: " + value + "\r\n", status=413))
    rows.append(case("expect-cl-above-cap", "Content-Length: 67108865\r\nExpect: 100-continue\r\n", status=413, header_only=True))
    for name, headers in [
        ("expect-cl-te", "Content-Length: 2\r\nTransfer-Encoding: chunked\r\n"),
        ("expect-te-cl", "Transfer-Encoding: chunked\r\nContent-Length: 2\r\n"),
        ("expect-cl-plus", "Content-Length: +2\r\n"),
        ("expect-cl-duplicate", "Content-Length: 2\r\nContent-Length: 2\r\n"),
        ("expect-te-order", "Transfer-Encoding: chunked, gzip\r\n"),
        ("expect-unsupported-te", "Transfer-Encoding: gzip\r\n"),
    ]:
        rows.append(case(name, headers + "Expect: 100-continue\r\n", header_only=True))
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.write_text(json.dumps(cases(), ensure_ascii=True, indent=2) + "\n")
    print(f"generated {len(cases())} cases in {args.output}")


if __name__ == "__main__":
    main()
