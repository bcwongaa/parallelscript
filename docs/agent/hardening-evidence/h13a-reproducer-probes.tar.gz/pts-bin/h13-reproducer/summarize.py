"""Print test-event counts and selected exact wire evidence from this local probe."""
import argparse
from collections import Counter
import json
from pathlib import Path


def summarize_tests(path):
    events = [json.loads(line) for line in path.read_text().splitlines()]
    outcomes = {event["Test"]: event["Action"] for event in events
                if event.get("Test") and event["Action"] in ["pass", "fail", "skip"]}
    parents = {name.rsplit("/", 1)[0] for name in outcomes if "/" in name}
    leaf = {name: action for name, action in outcomes.items() if name not in parents}
    print("all_test_outcomes", dict(Counter(outcomes.values())))
    print("leaf_test_outcomes", dict(Counter(leaf.values())))
    for protocol in ["http", "https"]:
        print(protocol, dict(Counter(action for name, action in leaf.items() if "/" + protocol + "/" in name)))
    for event in events:
        if not event.get("Test") and event["Action"] in ["pass", "fail"]:
            print("package", event)
    for name in leaf:
        if any(name.endswith("/" + suffix) for suffix in ["fragmented-content-length", "fragmented-chunked", "valid-100-continue", "exact-body-limit-emits-continue-without-a-body"]):
            print("control", name, leaf[name])


def summarize_wire(path):
    report = json.loads(path.read_text())
    print("node_version", report["nodeVersion"])
    print("wire_summary", report["summary"])
    for name in ["cl-plus", "cl-duplicate-same", "te-nonfinal-chunked", "cl-te", "te-cl", "expect-cl-te", "chunked-trailing-tab"]:
        for kind in ["pts", "node"]:
            result = report[kind]["results"][name]
            print(kind, name, json.dumps(result, ensure_ascii=True, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--tests", type=Path)
    parser.add_argument("--wire", type=Path)
    args = parser.parse_args()
    if args.tests:
        summarize_tests(args.tests)
    if args.wire:
        summarize_wire(args.wire)


if __name__ == "__main__":
    main()
