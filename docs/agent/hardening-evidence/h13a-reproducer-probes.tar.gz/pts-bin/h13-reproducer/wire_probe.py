"""Bounded loopback-only H13 raw-wire comparison; preserve exact requests and replies."""
import argparse
import hashlib
import http.client
import json
import os
from pathlib import Path
import re
import selectors
import signal
import socket
import subprocess
import sys
import time

MARKER = b"GET /marker HTTP/1.1\r\nHost: loopback\r\nConnection: close\r\n\r\n"
MAX_REPLY = 65536


def start_server(command):
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               env=dict(os.environ, PTS_THREADS="1"), start_new_session=True)
    selector = selectors.DefaultSelector()
    try:
        selector.register(process.stdout, selectors.EVENT_READ)
        if not selector.select(10):
            raise RuntimeError("loopback fixture did not report its port")
        line = process.stdout.readline().decode("utf8").strip()
        fields = line.split()
        if len(fields) != 2 or fields[0] != "listening":
            raise RuntimeError("unexpected fixture output: " + repr(line))
        return process, int(fields[1])
    except BaseException:
        stop_server(process)
        raise
    finally:
        selector.close()


def stop_server(process):
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
    try:
        stdout, stderr = process.communicate(timeout=5)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate(timeout=5)
    return {"returncode": process.returncode, "stdout": stdout.decode("utf8", "replace"),
            "stderr": stderr.decode("utf8", "replace")}


def count_requests(port):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    try:
        connection.request("GET", "/count", headers={"Connection": "close"})
        response = connection.getresponse()
        if response.status != 200:
            raise RuntimeError("count endpoint returned " + str(response.status))
        return int(response.read(64))
    finally:
        connection.close()


def request_bytes(case):
    wire = ("POST /probe HTTP/1.1\r\nHost: loopback\r\n" + case["headers"] + "\r\n" + case["body"]).encode("utf8")
    return wire if case["headerOnly"] else wire + MARKER


def exchange(port, wire, timeout):
    reply = bytearray()
    terminal = "unknown"
    start = time.monotonic()
    with socket.create_connection(("127.0.0.1", port), timeout=3) as connection:
        connection.settimeout(timeout)
        connection.sendall(wire)
        try:
            while len(reply) <= MAX_REPLY:
                block = connection.recv(min(4096, MAX_REPLY + 1 - len(reply)))
                if not block:
                    terminal = "eof"
                    break
                reply.extend(block)
            else:
                terminal = "reply-limit"
        except socket.timeout:
            terminal = "timeout"
        except OSError as error:
            terminal = "socket-error:" + str(error.errno)
    return {"request": wire.decode("latin1"), "response": bytes(reply).decode("latin1"),
            "statuses": [int(status) for status in re.findall(rb"HTTP/1\.[01] (\d{3}) ", reply)],
            "terminal": terminal, "elapsedSeconds": round(time.monotonic() - start, 6)}


def run_cases(kind, command, cases, timeout):
    process, port = start_server(command)
    results = {}
    try:
        for case in cases:
            before = count_requests(port)
            observation = exchange(port, request_bytes(case), timeout)
            observation["dispatchDelta"] = count_requests(port) - before
            want_statuses = [200, 200] if case["status"] == 200 else [case["status"]]
            want_dispatch = 2 if case["status"] == 200 else 0
            observation["strictPolicyMatches"] = (observation["statuses"] == want_statuses
                                                    and observation["terminal"] == "eof"
                                                    and observation["dispatchDelta"] == want_dispatch)
            results[case["name"]] = observation
            print(kind, case["name"], "statuses=" + str(observation["statuses"]),
                  "terminal=" + observation["terminal"], "dispatch=" + str(observation["dispatchDelta"]),
                  "strict=" + str(observation["strictPolicyMatches"]), flush=True)
    finally:
        ended = stop_server(process)
    return {"command": command, "results": results, "process": ended}


def file_hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pts", type=Path)
    parser.add_argument("--node", type=Path, required=True)
    parser.add_argument("--oracle", type=Path, required=True)
    parser.add_argument("--cases", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=0.5)
    parser.add_argument("--only", default="")
    args = parser.parse_args()
    cases = json.loads(args.cases.read_text())
    if args.only:
        cases = [case for case in cases if re.search(args.only, case["name"])]
    if not cases:
        raise RuntimeError("no selected bounded cases")
    report = {"argv": sys.argv, "casesSHA256": file_hash(args.cases),
              "ptsSHA256": file_hash(args.pts) if args.pts else None, "oracleSHA256": file_hash(args.oracle),
              "nodeVersion": subprocess.check_output([str(args.node), "--version"], text=True).strip()}
    report["node"] = run_cases("node", [str(args.node), str(args.oracle)], cases, args.timeout)
    failed = []
    if args.pts:
        report["pts"] = run_cases("pts", [str(args.pts)], cases, args.timeout)
        failed = [name for name, observation in report["pts"]["results"].items() if not observation["strictPolicyMatches"]]
        report["summary"] = {"cases": len(cases), "ptsStrictPass": len(cases) - len(failed),
                             "ptsStrictFail": len(failed), "failures": failed}
    else:
        report["summary"] = {"cases": len(cases), "nodeOnly": True}
    args.output.write_text(json.dumps(report, ensure_ascii=True, indent=2) + "\n")
    print(json.dumps(report["summary"], sort_keys=True), flush=True)
    return bool(failed)


if __name__ == "__main__":
    sys.exit(main())
