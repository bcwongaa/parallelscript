import http from 'node:http';

let dispatched = 0;
const server = http.createServer(async (request, response) => {
  if (request.url === '/count') {
    response.end(String(dispatched));
    return;
  }
  if (request.url === '/stop') {
    response.end('bye');
    server.close();
    return;
  }
  dispatched++;
  try {
    let body = '';
    for await (const chunk of request) body += chunk.toString('utf8');
    response.end(request.url + ':' + body);
  } catch {
    response.destroy();
  }
});
server.listen(0, '127.0.0.1', () => console.log('listening', server.address().port));
