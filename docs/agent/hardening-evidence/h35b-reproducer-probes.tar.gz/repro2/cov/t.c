#include <stdint.h>
#include <string.h>
struct obj { void *type; double a; void *p; char c; };
void *g_slot;
void plain(struct obj *o, void *t) { o->type = t; o->a = 1.5; o->c = 'x'; g_slot = o; }
void relaxed(void **slot, void *v) { __atomic_store_n(slot, v, __ATOMIC_RELAXED); }
void release(void **slot, void *v) { __atomic_store_n(slot, v, __ATOMIC_RELEASE); }
void seqcst(void **slot, void *v) { __atomic_store_n(slot, v, __ATOMIC_SEQ_CST); }
void *xchg(void **slot, void *v) { return __atomic_exchange_n(slot, v, __ATOMIC_ACQ_REL); }
int cas(void **slot, void *e, void *v) { return __atomic_compare_exchange_n(slot, &e, v, 0, __ATOMIC_ACQ_REL, __ATOMIC_RELAXED); }
void copy(struct obj *d, const struct obj *s) { *d = *s; }
void mcopy(void *d, const void *s, size_t n) { memcpy(d, s, n); }
void zero(struct obj *d) { memset(d, 0, sizeof *d); }
struct pair { void *a, *b; };
void pairstore(struct pair *d, void *x, void *y) { d->a = x; d->b = y; }
void vecfill(double *d, int n) { for (int i = 0; i < n; i++) d[i] = i; }
__attribute__((no_sanitize("coverage"))) void noinstr(struct obj *o, void *t) { o->type = t; }
