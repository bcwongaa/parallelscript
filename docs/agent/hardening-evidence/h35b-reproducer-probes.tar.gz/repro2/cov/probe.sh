#!/bin/bash
# Which __sanitizer_cov_* callbacks clang emits for -fsanitize-coverage=<types>,trace-stores.
set -u
dir=/tmp/h35b/repro2/cov
clang --version | head -1
for cov in "trace-stores" "func,trace-stores" "func,trace-stores,trace-pc-guard" "func,trace-stores,inline-bool-flag" "func,trace-stores,trace-pc"; do
  echo "== -fsanitize-coverage=$cov"
  clang -O1 -c -fsanitize-coverage=$cov "$dir/t.c" -o "$dir/t.o" 2>&1 | head -3
  nm "$dir/t.o" 2>/dev/null | grep " U " | sort -u
done
echo "== per-function callbacks with func,trace-stores (-O1)"
clang -O1 -S -fsanitize-coverage=func,trace-stores "$dir/t.c" -o "$dir/t.s"
awk '/^[a-z_]+:/{f=$1} /call/{print f, $2}' "$dir/t.s"
