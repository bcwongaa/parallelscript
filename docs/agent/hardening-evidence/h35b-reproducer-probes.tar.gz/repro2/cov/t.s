	.text
	.file	"t.c"
	.globl	plain                           # -- Begin function plain
	.p2align	4, 0x90
	.type	plain,@function
plain:                                  # @plain
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	callq	__sanitizer_cov_store8@PLT
	movq	%rbx, (%r14)
	leaq	8(%r14), %rdi
	callq	__sanitizer_cov_store8@PLT
	movabsq	$4609434218613702656, %rax      # imm = 0x3FF8000000000000
	movq	%rax, 8(%r14)
	leaq	24(%r14), %rdi
	callq	__sanitizer_cov_store1@PLT
	movb	$120, 24(%r14)
	leaq	g_slot(%rip), %rdi
	callq	__sanitizer_cov_store8@PLT
	movq	%r14, g_slot(%rip)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	plain, .Lfunc_end0-plain
	.cfi_endproc
                                        # -- End function
	.globl	relaxed                         # -- Begin function relaxed
	.p2align	4, 0x90
	.type	relaxed,@function
relaxed:                                # @relaxed
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	callq	__sanitizer_cov_store8@PLT
	movq	%rbx, (%r14)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	relaxed, .Lfunc_end1-relaxed
	.cfi_endproc
                                        # -- End function
	.globl	release                         # -- Begin function release
	.p2align	4, 0x90
	.type	release,@function
release:                                # @release
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	callq	__sanitizer_cov_store8@PLT
	movq	%rbx, (%r14)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	release, .Lfunc_end2-release
	.cfi_endproc
                                        # -- End function
	.globl	seqcst                          # -- Begin function seqcst
	.p2align	4, 0x90
	.type	seqcst,@function
seqcst:                                 # @seqcst
	.cfi_startproc
# %bb.0:
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	callq	__sanitizer_cov_store8@PLT
	xchgq	%rbx, (%r14)
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	seqcst, .Lfunc_end3-seqcst
	.cfi_endproc
                                        # -- End function
	.globl	xchg                            # -- Begin function xchg
	.p2align	4, 0x90
	.type	xchg,@function
xchg:                                   # @xchg
	.cfi_startproc
# %bb.0:
	movq	%rsi, %rax
	xchgq	%rax, (%rdi)
	retq
.Lfunc_end4:
	.size	xchg, .Lfunc_end4-xchg
	.cfi_endproc
                                        # -- End function
	.globl	cas                             # -- Begin function cas
	.p2align	4, 0x90
	.type	cas,@function
cas:                                    # @cas
	.cfi_startproc
# %bb.0:
	movq	%rsi, %rax
	xorl	%ecx, %ecx
	lock		cmpxchgq	%rdx, (%rdi)
	sete	%cl
	movl	%ecx, %eax
	retq
.Lfunc_end5:
	.size	cas, .Lfunc_end5-cas
	.cfi_endproc
                                        # -- End function
	.globl	copy                            # -- Begin function copy
	.p2align	4, 0x90
	.type	copy,@function
copy:                                   # @copy
	.cfi_startproc
# %bb.0:
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movups	%xmm1, 16(%rdi)
	movups	%xmm0, (%rdi)
	retq
.Lfunc_end6:
	.size	copy, .Lfunc_end6-copy
	.cfi_endproc
                                        # -- End function
	.globl	mcopy                           # -- Begin function mcopy
	.p2align	4, 0x90
	.type	mcopy,@function
mcopy:                                  # @mcopy
	.cfi_startproc
# %bb.0:
	jmp	memcpy@PLT                      # TAILCALL
.Lfunc_end7:
	.size	mcopy, .Lfunc_end7-mcopy
	.cfi_endproc
                                        # -- End function
	.globl	zero                            # -- Begin function zero
	.p2align	4, 0x90
	.type	zero,@function
zero:                                   # @zero
	.cfi_startproc
# %bb.0:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rdi)
	movups	%xmm0, (%rdi)
	retq
.Lfunc_end8:
	.size	zero, .Lfunc_end8-zero
	.cfi_endproc
                                        # -- End function
	.globl	pairstore                       # -- Begin function pairstore
	.p2align	4, 0x90
	.type	pairstore,@function
pairstore:                              # @pairstore
	.cfi_startproc
# %bb.0:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movq	%rdi, %r15
	callq	__sanitizer_cov_store8@PLT
	movq	%r14, (%r15)
	leaq	8(%r15), %rdi
	callq	__sanitizer_cov_store8@PLT
	movq	%rbx, 8(%r15)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end9:
	.size	pairstore, .Lfunc_end9-pairstore
	.cfi_endproc
                                        # -- End function
	.globl	vecfill                         # -- Begin function vecfill
	.p2align	4, 0x90
	.type	vecfill,@function
vecfill:                                # @vecfill
	.cfi_startproc
# %bb.0:
	testl	%esi, %esi
	jle	.LBB10_4
# %bb.1:
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$16, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	movl	%esi, %r14d
	xorl	%r15d, %r15d
	.p2align	4, 0x90
.LBB10_2:                               # =>This Inner Loop Header: Depth=1
	xorps	%xmm0, %xmm0
	cvtsi2sd	%r15d, %xmm0
	movsd	%xmm0, 8(%rsp)                  # 8-byte Spill
	movq	%rbx, %rdi
	callq	__sanitizer_cov_store8@PLT
	movsd	8(%rsp), %xmm0                  # 8-byte Reload
                                        # xmm0 = mem[0],zero
	movsd	%xmm0, (%rbx)
	incq	%r15
	addq	$8, %rbx
	cmpq	%r15, %r14
	jne	.LBB10_2
# %bb.3:
	addq	$16, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r14
	.cfi_restore %r15
.LBB10_4:
	retq
.Lfunc_end10:
	.size	vecfill, .Lfunc_end10-vecfill
	.cfi_endproc
                                        # -- End function
	.globl	noinstr                         # -- Begin function noinstr
	.p2align	4, 0x90
	.type	noinstr,@function
noinstr:                                # @noinstr
	.cfi_startproc
# %bb.0:
	movq	%rsi, (%rdi)
	retq
.Lfunc_end11:
	.size	noinstr, .Lfunc_end11-noinstr
	.cfi_endproc
                                        # -- End function
	.type	g_slot,@object                  # @g_slot
	.bss
	.globl	g_slot
	.p2align	3, 0x0
g_slot:
	.quad	0
	.size	g_slot, 8

	.ident	"Ubuntu clang version 18.1.3 (1ubuntu1)"
	.section	".note.GNU-stack","",@progbits
	.addrsig
	.addrsig_sym __sanitizer_cov_store1
	.addrsig_sym __sanitizer_cov_store8
