#!/bin/bash
# A PTS_CC that records each command line (one per line, NUL-free, shell-quoted) in
# $CC_LOG and runs clang with it, so a program's compile-and-link command can be replayed
# on hand-edited C.
printf '%q ' clang "$@" >> "${CC_LOG:-/tmp/h35b/repro2/logs/cc.log}"
echo >> "${CC_LOG:-/tmp/h35b/repro2/logs/cc.log}"
exec clang "$@"
