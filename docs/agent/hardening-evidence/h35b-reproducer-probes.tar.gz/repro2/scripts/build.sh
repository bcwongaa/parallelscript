#!/bin/bash
# build.sh <profile> <file.pts> [output]: builds a program with the worktree's pts under a
# toolchain profile (release, publication, ...), printing the build's exit code.
set -u
profile=$1
source=$2
output=${3:-${source%.pts}.$profile.bin}
PTS_BUILD_PROFILE=$profile /home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts-bin/pts build "$source" -o "$output"
echo "build exit=$? $output"
