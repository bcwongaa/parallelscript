#!/usr/bin/env python3
"""One-off edit: the checker case test names, per case, the function that made the object."""
P = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts/toolchain/publication_test.go"
s = open(P).read()
pairs = [
    ('''		slot     string // what a report says the object was stored into
		stdout   string''', '''		slot     string // what a report says the object was stored into
		madeBy   string // the function a report says made the object, if not new_box
		stdout   string'''),
    ('''		{name: "pushed", options: "partial", reported: true, slot: "global published_array+0"},''',
     '''		{name: "pushed", options: "partial", reported: true, slot: "global published_array+0", madeBy: "with_room"},'''),
    ('''			assert.Assert(t, strings.Contains(got.stderr, "new_box (") && strings.Contains(got.stderr, "publication_cases.c:"),''',
     '''			madeBy := c.madeBy
			if madeBy == "" {
				madeBy = "new_box"
			}
			assert.Assert(t, strings.Contains(got.stderr, madeBy+" (") && strings.Contains(got.stderr, "publication_cases.c:"),'''),
]
for a, b in pairs:
    assert s.count(a) == 1, a
    s = s.replace(a, b)
open(P, "w").write(s)
print("edited")
