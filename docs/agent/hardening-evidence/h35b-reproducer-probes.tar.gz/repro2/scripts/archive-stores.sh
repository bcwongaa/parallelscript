#!/bin/bash
# Counts the __sanitizer_cov_store calls in each object of the newest PublicationCheck
# runtime archive (the one with a publication_check member that defines the hooks), so
# that the instrumentation's reach (atomic stores included) can be seen per file.
set -u
for dir in $(ls -td ~/.cache/pts/ptsrt-*); do
  if nm "$dir/libptsrt.a" 2>/dev/null | grep -q " T __sanitizer_cov_store8"; then
    echo "archive: $dir"
    tmp=$(mktemp -d /tmp/h35b/repro2/cov/ar.XXXXXX)
    (cd "$tmp" && ar x "$dir/libptsrt.a")
    for o in "$tmp"/*.o; do
      n=$(objdump -r "$o" | grep -c "__sanitizer_cov_store")
      printf '%6d %s\n' "$n" "$(basename "$o")"
    done | sort -rn
    rm -rf "$tmp"
    exit 0
  fi
done
echo "no PublicationCheck runtime archive found"
