#!/usr/bin/env python3
"""One-off edit of the worktree: zero atomic allocations in the checker, add the partial
option, and a `pushed` case to publication_cases.c and its Go test."""
W = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/"


def edit(path, pairs):
    s = open(W + path).read()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a, s.count(a))
        s = s.replace(a, b)
    open(W + path, "w").write(s)


edit("pts/runtime/src/publication_check.c", [
    ('''void *__wrap_GC_malloc_atomic(size_t size) {
  checker_thread *t = before_allocation();
  void *memory = __real_GC_malloc_atomic(size);
  after_allocation(t, memory, size, 0, __builtin_frame_address(0));
  return memory;
}''', '''/*
 * bdwgc doesn't zero atomic memory: the checker does (no correct program reads it first),
 * so that a word's first store is told from a change by the word holding zero.
 */
void *__wrap_GC_malloc_atomic(size_t size) {
  checker_thread *t = before_allocation();
  void *memory = __real_GC_malloc_atomic(size);
  if (memory != NULL) {
    memset(memory, 0, size);
  }
  after_allocation(t, memory, size, 0, __builtin_frame_address(0));
  return memory;
}'''),
    ('''    bool in_fresh = lookup(t, at) != NULL;
    make_clean(t, at);
    make_clean(t, *(const uintptr_t *)at);
    make_clean(t, (uintptr_t)also);
    if (!in_fresh) {''', '''    bool in_fresh = lookup(t, at) != NULL;
    if (!report_partial) {
      make_clean(t, at);
      make_clean(t, *(const uintptr_t *)at);
      make_clean(t, (uintptr_t)also);
    }
    if (!in_fresh) {'''),
    (''' * store published is shared, not a violation. Other objects stay as they are: a release
 * doesn't order the stores before it with the plain stores after it.
 */''', ''' * store published is shared, not a violation. Other objects stay as they are: a release
 * doesn't order the stores before it with the plain stores after it. That holds for the
 * three objects too, which a thread reaching them through a plain store made after the
 * release may see as they were before it (an array before its last pushes: never garbage,
 * since its length is published after its elements); PTS_PUBLICATION_CHECK=partial reports
 * that too, leaving them as they are.
 */'''),
    ('static bool strict_mode, report_all, report_none, track_uncollectable, check_malloc, print_stats;',
     'static bool strict_mode, report_all, report_none, report_partial, track_uncollectable, check_malloc, print_stats;'),
    ('''    check_malloc = strstr(options, "malloc") != NULL;''', '''    check_malloc = strstr(options, "malloc") != NULL;
    report_partial = strstr(options, "partial") != NULL;'''),
    (''' * structures, which threads reach through locks, pthread_once and thread creation) and
 * malloc (count malloc's memory as shared).''', ''' * structures, which threads reach through locks, pthread_once and thread creation),
 * malloc (count malloc's memory as shared) and partial (a release store doesn't make the
 * objects it orders clean for other paths to them; see pts_publication_check_release).'''),
])

edit("pts/runtime/tests/publication_cases.c", [
    ('''static const struct {''', '''static void *volatile published_array;

/*
 * A new array filled by pushes, whose length and buffer the runtime publishes with release
 * stores, then published by a plain store: a thread may see it with fewer elements (never
 * garbage). Reported only with PTS_PUBLICATION_CHECK=partial.
 */
static void pushed(void) {
  pts_array *array = pts_array_of(&pts_array_types[PTS_FIELD_NUMBER], NULL, 0);
  pts_publication_barrier_hook(); /* the end of pts_array_of's construction, which has no barrier yet (C356) */
  for (int i = 0; i < 20; i++) {
    pts_array_push(array, (double[]){i}, 1);
  }
  published_array = array;
}

static const struct {'''),
    ('''    {"malloc_scratch", malloc_scratch}, {"other_stack", other_stack},''', '''    {"malloc_scratch", malloc_scratch}, {"other_stack", other_stack},
    {"pushed", pushed},'''),
])

edit("pts/toolchain/publication_test.go", [
    ('''		{name: "other_stack", reported: true, slot: "another thread's stack"},''', '''		{name: "other_stack", reported: true, slot: "another thread's stack"},
		{name: "pushed"},
		{name: "pushed", options: "partial", reported: true, slot: "global published_array+0"},'''),
])
print("edited")
