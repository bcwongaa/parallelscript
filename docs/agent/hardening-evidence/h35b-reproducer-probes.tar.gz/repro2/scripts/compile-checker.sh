#!/bin/bash
# Compiles publication_check.c as the runtime's archive build does, with and without the
# checker, and lists any __sanitizer_cov_* calls in it (there must be none: it isn't
# instrumented) and the size of its no-checker object (an empty translation unit).
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b
I="-I $W/pts/runtime/include -I $W/pts/third_party/bdwgc/include -I $W/pts/third_party/libuv/include -I $W/pts/third_party/ryu -I $W/pts/third_party/libbacktrace -I $W/pts/third_party/pcre2-config -I $W/pts/third_party/mbedtls-config -I $W/pts/third_party/mbedtls/include"
D='-DMBEDTLS_USER_CONFIG_FILE="pts_mbedtls_config.h"'
out=/tmp/h35b/repro2/cov
echo "== checker build (-Wall -Wextra):"
clang -O1 -g -ffp-contract=off -fno-math-errno -fno-omit-frame-pointer -fsanitize-coverage=func,trace-stores -DPTS_PUBLICATION_CHECK -std=c11 -Wall -Wextra -Werror=implicit-function-declaration $I "$D" -c $W/pts/runtime/src/publication_check.c -o $out/pc.o
echo "exit=$?"
echo "== __sanitizer_cov references in the checker's object (want none):"
nm $out/pc.o | grep -c "U __sanitizer_cov"
echo "== release build:"
clang -O2 -g -std=c11 -Wall -Wextra $I "$D" -c $W/pts/runtime/src/publication_check.c -o $out/pc-release.o
echo "exit=$? symbols=$(nm $out/pc-release.o | wc -l)"
