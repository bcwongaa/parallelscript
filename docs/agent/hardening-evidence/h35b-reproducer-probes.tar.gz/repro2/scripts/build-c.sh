#!/bin/bash
# build-c.sh <profile> <file.pts> <edited.c> <output>: builds file.pts once under the
# profile through cc-log.sh to learn the compile-and-link command, then runs that command
# on edited.c (the program's C, edited by hand) instead of the generated main.c.
set -u
profile=$1
source=$2
edited=$3
output=$4
log=$(mktemp /tmp/h35b/repro2/logs/cc.XXXXXX)
CC_LOG=$log PTS_CC=/tmp/h35b/repro2/scripts/cc-log.sh PTS_BUILD_PROFILE=$profile \
  /home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts-bin/pts build "$source" -o "$output.orig" > /dev/null 2>&1
command=$(grep -- '-o .*\.orig ' "$log" | tail -1)
rm -f "$log"
if [ -z "$command" ]; then
  echo "no link command recorded"
  exit 1
fi
command=${command//$output.orig/$output}
command=$(printf '%s' "$command" | sed -E "s# [^ ]*/pts-build-[0-9]+/main\.c # $edited #")
eval "$command -w"
echo "build-c exit=$? $output"
