#!/usr/bin/env python3
"""One-off edit: the ring never forgets a fresh uncollectable object (a thread's own
runtime structures, which live as long as the thread), so a store into one stays private."""
P = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts/runtime/src/publication_check.c"
s = open(P).read()
a = '''  size_t index = t->next;
  t->next = (t->next + 1) & (RING_SIZE - 1);
  fresh_object *object = &t->ring[index];
  forget(t, object);'''
b = '''  size_t index = t->next;
  for (size_t tries = 0; tries < RING_SIZE && (t->ring[index].flags & UNCOLLECTABLE); tries++) {
    index = (index + 1) & (RING_SIZE - 1); /* a thread's own runtime structures stay as long as it does */
  }
  t->next = (index + 1) & (RING_SIZE - 1);
  fresh_object *object = &t->ring[index];
  forget(t, object);'''
assert s.count(a) == 1
s = s.replace(a, b)
open(P, "w").write(s)
print("edited")
