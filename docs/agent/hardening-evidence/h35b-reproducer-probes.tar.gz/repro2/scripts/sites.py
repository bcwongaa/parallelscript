#!/usr/bin/env python3
"""Aggregate the distinct violation places in PTS_PUBLICATION_CHECK=all stderr files:
for each report, the first frame of where the object was made (skipping allocator
helpers) and the first frame of the store, with counts.

usage: sites.py file.stderr...
"""
import collections
import re
import sys

HELPERS = ("pts_object_new", "new_buffer", "new_table", "allocate", "pts_string_alloc", "pts_cell_new", "checked")


def frames(block, start):
    out = []
    for line in block[start:]:
        if not line.startswith("      "):
            break
        out.append(line.strip())
    return out


def short(frame):
    frame = re.sub(r"^inlined into ", "", frame)
    frame = re.sub(r"\(/home/bryan/projects/parallelscript/.claude/worktrees/[^/]+/+", "(", frame)
    frame = re.sub(r"\(/?tmp/pts-build-\d+/main.c", "(main.c", frame)
    frame = re.sub(r"\(.*?/(pts/tests/[^)]*)\)", r"(\1)", frame)
    frame = re.sub(r"\(/tmp/h35b/repro2/[^)]*/([^/)]*)\)", r"(\1)", frame)
    return frame


def main(paths):
    places = collections.Counter()
    for path in paths:
        lines = open(path, errors="replace").read().splitlines()
        for i, line in enumerate(lines):
            if not line.startswith("pts publication violation"):
                continue
            block = lines[i:i + 40]
            made = frames(block, 2)
            store_i = next((j for j, l in enumerate(block) if l.startswith("  stored into")), None)
            store = frames(block, store_i + 1) if store_i is not None else []
            via = any(l.startswith("  is held by") for l in block[:store_i or 0])
            made_at = next((f for f in made if not any(f.split(" ")[0].endswith(h) or ("inlined into " + h) in f for h in HELPERS)), made[0] if made else "?")
            dest = re.sub(r"0x[0-9a-f]+", "…", block[store_i].strip()) if store_i is not None else "?"
            dest = re.sub(r" word \d+ of", " a word of", dest)
            places[(short(made[0]) if made else "?", short(made_at), short(store[0]) if store else "?", dest, via)] += 1
    for (alloc, made_at, store, dest, via), count in sorted(places.items(), key=lambda kv: (kv[0][2], kv[0][0])):
        print(f"{count:4d}  store {store}\n      {dest}{' (held by the published object)' if via else ''}\n      object from {alloc} / {made_at}")


if __name__ == "__main__":
    main(sys.argv[1:])
