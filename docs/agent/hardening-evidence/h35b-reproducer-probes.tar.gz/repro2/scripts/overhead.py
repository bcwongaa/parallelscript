#!/usr/bin/env python3
"""Time programs built under the release and publication profiles, interleaved, with the
checker counting violations only (PTS_PUBLICATION_CHECK=count,stats).

usage: overhead.py OUTDIR [--runs N] [--threads T] file.pts...
"""
import os
import signal
import statistics
import subprocess
import sys
import time

PTS = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts-bin/pts"


def run(cmd, env, cwd, timeout=900):
    start = time.monotonic()
    proc = subprocess.Popen(cmd, env=env, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
        code = proc.returncode
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, err = proc.communicate()
        code = "TIMEOUT"
    return code, time.monotonic() - start, out, err.decode(errors="replace")


def main(argv):
    outdir = argv[0]
    runs, threads, files = 3, 1, []
    i = 1
    while i < len(argv):
        if argv[i] == "--runs":
            runs = int(argv[i + 1]); i += 2
        elif argv[i] == "--threads":
            threads = int(argv[i + 1]); i += 2
        else:
            files.append(argv[i]); i += 1
    os.makedirs(outdir, exist_ok=True)
    print(f"{'program':28s} {'release s':>10s} {'checked s':>10s} {'ratio':>7s}  checker summary")
    for path in files:
        name = os.path.basename(os.path.dirname(path)) if os.path.basename(path) == "main.pts" else os.path.splitext(os.path.basename(path))[0]
        exes = {}
        for profile in ("release", "publication"):
            exe = os.path.join(outdir, f"{name}.{profile}.bin")
            code, _, _, err = run([PTS, "build", path, "-o", exe], dict(os.environ, PTS_BUILD_PROFILE=profile), None)
            if code != 0:
                print(f"{name}: {profile} build failed: {err[-500:]}")
                break
            exes[profile] = exe
        if len(exes) < 2:
            continue
        times = {"release": [], "publication": []}
        summary = ""
        same = True
        outputs = {}
        for _ in range(runs):
            for profile in ("release", "publication"):
                env = dict(os.environ, PTS_THREADS=str(threads), PTS_PUBLICATION_CHECK="count,stats", TZ="America/New_York")
                code, elapsed, out, err = run([exes[profile]], env, os.path.dirname(path))
                times[profile].append(elapsed)
                outputs.setdefault(profile, out)
                if profile == "publication":
                    summary = " | ".join(l.replace("pts publication check: ", "") for l in err.splitlines() if l.startswith("pts publication check:"))
        same = outputs["release"] == outputs["publication"]
        r, c = statistics.median(times["release"]), statistics.median(times["publication"])
        print(f"{name:28s} {r:10.3f} {c:10.3f} {c / r:7.1f}x  {'' if same else 'OUTPUT DIFFERS; '}{summary}")
        for exe in exes.values():
            os.remove(exe)


if __name__ == "__main__":
    main(sys.argv[1:])
