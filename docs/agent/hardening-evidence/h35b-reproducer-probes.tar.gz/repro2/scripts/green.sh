#!/bin/bash
# Rebuilds the hand-fenced C of two probes under the publication checker and compares
# what the checker reports (PTS_PUBLICATION_CHECK=all) with and without the barriers.
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b
G=/tmp/h35b/repro2/probes/green
S=/tmp/h35b/repro2/scripts
bash $S/build-c.sh publication $W/pts/tests/publication/object_literal.pts $G/object_literal.c $G/object_literal.head.bin
bash $S/build-c.sh publication $W/pts/tests/publication/object_literal.pts $G/object_literal.fenced.c $G/object_literal.fenced.bin
bash $S/build-c.sh publication $G/mutation.pts $G/mutation.fenced.c $G/mutation.fenced.bin
for v in head fenced; do
  echo "== object_literal, $v: places naming object_literal.pts"
  python3 -I $S/run.py --timeout 60 --quiet --env PTS_THREADS=2 --env PTS_PUBLICATION_CHECK=all --stdout $G/object_literal.$v.stdout --stderr $G/object_literal.$v.stderr -- $G/object_literal.$v.bin
  python3 -I $S/sites.py $G/object_literal.$v.stderr | grep -A2 "store .*object_literal.pts" || echo "   (none)"
  tail -1 $G/object_literal.$v.stderr
done
for o in all all,strict; do
  echo "== mutation (literal fenced by hand, then changed, then published), PTS_PUBLICATION_CHECK=$o: places naming mutation.pts"
  python3 -I $S/run.py --timeout 60 --quiet --env PTS_THREADS=2 --env PTS_PUBLICATION_CHECK=$o --stderr $G/mutation.$o.stderr -- $G/mutation.fenced.bin
  python3 -I $S/sites.py $G/mutation.$o.stderr | grep -A2 "store .*mutation.pts" || echo "   (none)"
done
rm -f $G/*.bin $G/*.orig
