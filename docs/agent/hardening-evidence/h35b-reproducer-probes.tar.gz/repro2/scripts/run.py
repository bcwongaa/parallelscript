#!/usr/bin/env python3
"""Run a command in its own session with a timeout, killing its whole process group on
timeout (a timed-out `pts run` leaves its binary running otherwise).

usage: run.py [--timeout S] [--env K=V]... [--stdout FILE] [--stderr FILE] [--quiet] -- cmd args...
Prints the exit code (or TIMEOUT) and, unless --quiet, the first lines of stdout/stderr.
"""
import os
import signal
import subprocess
import sys
import time


def main(argv):
    timeout = 120.0
    env = dict(os.environ)
    out_path = err_path = None
    quiet = False
    i = 0
    while i < len(argv) and argv[i] != "--":
        a = argv[i]
        if a == "--timeout":
            timeout = float(argv[i + 1]); i += 2
        elif a == "--env":
            k, v = argv[i + 1].split("=", 1); env[k] = v; i += 2
        elif a == "--stdout":
            out_path = argv[i + 1]; i += 2
        elif a == "--stderr":
            err_path = argv[i + 1]; i += 2
        elif a == "--quiet":
            quiet = True; i += 1
        else:
            sys.exit(f"unknown option {a}")
    cmd = argv[i + 1:]
    start = time.monotonic()
    proc = subprocess.Popen(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
        code = str(proc.returncode)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, err = proc.communicate()
        code = "TIMEOUT"
    elapsed = time.monotonic() - start
    if out_path:
        open(out_path, "wb").write(out)
    if err_path:
        open(err_path, "wb").write(err)
    print(f"exit={code} elapsed={elapsed:.2f}s")
    if not quiet:
        o = out.decode(errors="replace").splitlines()
        e = err.decode(errors="replace").splitlines()
        if o:
            print("--- stdout (%d lines)" % len(o)); print("\n".join(o[:15]))
        if e:
            print("--- stderr (%d lines)" % len(e)); print("\n".join(e[:60]))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
