#!/usr/bin/env python3
"""Build each .pts given under the release and publication profiles, run both, and report:
whether release prints the // expect: block, and the publication build's exit code and
first violation (or none).

usage: probe_matrix.py OUTDIR [--threads N] [--jobs J] [--options OPTS] file.pts...
Writes OUTDIR/<name>.{release,publication}.{stdout,stderr} and prints a summary table;
deletes the binaries afterwards.
"""
import concurrent.futures
import os
import re
import signal
import subprocess
import sys
import time

PTS = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts-bin/pts"


def run(cmd, env=None, timeout=300, cwd=None):
    start = time.monotonic()
    proc = subprocess.Popen(cmd, env=env, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    try:
        out, err = proc.communicate(timeout=timeout)
        code = proc.returncode
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        out, err = proc.communicate()
        code = "TIMEOUT"
    return code, out.decode(errors="replace"), err.decode(errors="replace"), time.monotonic() - start


def expected(path):
    lines = open(path).read().splitlines()
    out, inside = [], False
    for line in lines:
        if re.match(r"^//\s*expect:\s*$", line):
            inside = True
            continue
        if inside:
            m = re.match(r"^// ?(.*)$", line)
            if not m:
                break
            out.append(m.group(1))
    return "\n".join(out) + "\n" if inside else None


def first_violation(stderr):
    lines = stderr.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("pts publication violation"):
            block = lines[i:i + 14]
            obj = next((l.strip() for l in block if l.strip().startswith("object ")), "")
            alloc = [l.strip() for l in block[2:6]]
            store_i = next((j for j, l in enumerate(block) if l.strip().startswith("stored into")), None)
            store = block[store_i].strip() if store_i is not None else ""
            store_at = block[store_i + 1].strip() if store_i is not None and store_i + 1 < len(block) else ""
            return obj, alloc, store, store_at
    return None


def one(path, outdir, threads, options):
    name = os.path.splitext(os.path.basename(path))[0]
    result = {"name": name}
    for profile in ("release", "publication"):
        exe = os.path.join(outdir, f"{name}.{profile}.bin")
        env = dict(os.environ, PTS_BUILD_PROFILE=profile)
        code, out, err, _ = run([PTS, "build", path, "-o", exe], env=env, timeout=600)
        if code != 0:
            result[profile] = ("BUILD FAILED", err[-2000:])
            continue
        env = dict(os.environ, PTS_THREADS=str(threads), TZ="America/New_York")
        if options:
            env["PTS_PUBLICATION_CHECK"] = options
        code, out, err, elapsed = run([exe], env=env, cwd=os.path.dirname(path))
        open(os.path.join(outdir, f"{name}.{profile}.stdout"), "w").write(out)
        open(os.path.join(outdir, f"{name}.{profile}.stderr"), "w").write(err)
        result[profile] = (code, out, err, elapsed)
        os.remove(exe)
    return path, result


def main(argv):
    outdir = argv[0]
    threads, jobs, options = 2, 3, ""
    files = []
    i = 1
    while i < len(argv):
        if argv[i] == "--threads":
            threads = int(argv[i + 1]); i += 2
        elif argv[i] == "--jobs":
            jobs = int(argv[i + 1]); i += 2
        elif argv[i] == "--options":
            options = argv[i + 1]; i += 2
        else:
            files.append(argv[i]); i += 1
    os.makedirs(outdir, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        results = list(pool.map(lambda p: one(p, outdir, threads, options), files))
    for path, r in results:
        want = expected(path)
        rel = r.get("release")
        pub = r.get("publication")
        if rel is None or rel[0] == "BUILD FAILED":
            print(f"## {r['name']}: release BUILD FAILED\n{rel[1] if rel else ''}")
            continue
        rel_ok = "matches expect" if want is not None and rel[1] == want else ("no expect" if want is None else "DIFFERS from expect")
        if pub[0] == "BUILD FAILED":
            print(f"## {r['name']}: release exit={rel[0]} {rel_ok}; publication BUILD FAILED\n{pub[1]}")
            continue
        same = "same stdout" if pub[1] == rel[1] else "DIFFERENT stdout"
        print(f"## {r['name']}: release exit={rel[0]} {rel_ok} ({rel[3]:.2f}s); publication exit={pub[0]} {same} ({pub[3]:.2f}s)")
        v = first_violation(pub[2])
        if v:
            obj, alloc, store, store_at = v
            print(f"   first violation: {obj}")
            print(f"     made at:   {alloc[0]} <- {alloc[1] if len(alloc) > 1 else ''}")
            print(f"     {store} {store_at}")
        else:
            print("   no violation")
        if want is not None and rel[1] != want:
            print("   release stdout:\n" + rel[1][:500])
        summary = [l for l in pub[2].splitlines() if l.startswith("pts publication check:")]
        for l in summary:
            print("   " + l)


if __name__ == "__main__":
    main(sys.argv[1:])
