#!/usr/bin/env python3
"""One-off edit: always track uncollectable allocations (the runtime's own structures)."""
P = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a0ae1cb2dc0f3658b/pts/runtime/src/publication_check.c"
s = open(P).read()
pairs = [
    (''' * checker saw), strict (see above), uncollectable (also track the runtime's uncollectable
 * structures, which threads reach through locks, pthread_once and thread creation),
 * malloc (count malloc's memory as shared) and partial (a release store doesn't make the''',
     ''' * checker saw), strict (see above), malloc (count malloc's memory as shared) and
 * partial (a release store doesn't make the'''),
    ('static bool strict_mode, report_all, report_none, report_partial, track_uncollectable, check_malloc, print_stats;',
     'static bool strict_mode, report_all, report_none, report_partial, check_malloc, print_stats;'),
    ('''    track_uncollectable = strstr(options, "uncollectable") != NULL;
''', ''),
    ('''/*
 * Uncollectable memory holds the runtime's own structures (loops, deques, workers, queues,
 * servers), which threads reach by pthread_once, locks and thread creation: tracked only
 * with PTS_PUBLICATION_CHECK=uncollectable.
 */
void *__wrap_GC_malloc_uncollectable(size_t size) {
  checker_thread *t = before_allocation();
  void *memory = __real_GC_malloc_uncollectable(size);
  if (t != NULL && !track_uncollectable) {
    leave();
    return memory;
  }
  after_allocation''', '''/*
 * Uncollectable memory holds the runtime's own structures (loops, deques, workers, queues,
 * servers): one that only its thread holds (through TLS) stays private, and the ring never
 * forgets it (add_fresh); threads reach the others through locks, pthread_once and thread
 * creation.
 */
void *__wrap_GC_malloc_uncollectable(size_t size) {
  checker_thread *t = before_allocation();
  void *memory = __real_GC_malloc_uncollectable(size);
  after_allocation'''),
]
for a, b in pairs:
    assert s.count(a) == 1, a
    s = s.replace(a, b)
open(P, "w").write(s)
print("edited")
