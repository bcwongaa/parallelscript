#!/bin/bash
# wait-quiet.sh SECONDS FILE...: waits until none of FILE has changed for SECONDS seconds
# (at most 25 minutes), printing how long it waited.
quiet=$1
shift
start=$(date +%s)
while :; do
  now=$(date +%s)
  newest=0
  for f in "$@"; do
    m=$(stat -L -c %Y "$f" 2>/dev/null || echo 0)
    [ "$m" -gt "$newest" ] && newest=$m
  done
  if [ $((now - newest)) -ge "$quiet" ] || [ $((now - start)) -ge 1500 ]; then
    echo "waited $((now - start))s; last change $((now - newest))s ago"
    exit 0
  fi
  sleep 10
done
