#include "pts.h"
void *a(void){return GC_MALLOC(8);}
void *b(void){return GC_MALLOC_ATOMIC(8);}
void *c(void *d){return GC_GCJ_MALLOC(8,d);}
void *e(void){return GC_MALLOC_UNCOLLECTABLE(8);}
void *f(void *p){return GC_REALLOC(p,16);}
void *g(void){return GC_MALLOC_ATOMIC_UNCOLLECTABLE(8);}
