import sys
n = int(sys.argv[1])
out = []
for i in range(n):
    out.append(f'type U{i} = {{ k: "a"; p{i}: number[] }} | {{ k: "b"; q{i}: string }};')
out.append('const vals: any[] = [];')
out.append('function fill(): void {')
for i in range(n):
    out.append(f'  vals.push({{ k: "a", p{i}: [JSON.parse("{i}.5")] }});')
out.append('}')
out.append('fill();')
out.append('function work(j: number): number {')
out.append('  let s = 0;')
for i in range(n):
    out.append(f'  const v{i}: U{i} = vals[{i}];')
    out.append(f'  s += v{i}.k === "a" ? v{i}.p{i}[0] : v{i}.q{i}.length;')
out.append('  return s + j * 0;')
out.append('}')
out.append('const idx: number[] = [];')
out.append('for (let i = 0; i < 64; i++) idx.push(i);')
out.append('const r = idx.par.map((j) => work(j));')
out.append('let ok = true;')
out.append('for (const x of r) ok = ok && x === r[0];')
out.append('console.log(ok, r[0], work(0));')
print("\n".join(out))
