#!/bin/bash
# emit.sh: emit C for every pts/tests/run test with base and snap3 (snap3's test files), one at a time.
for f in /tmp/h09b2/snap3/pts/tests/run/*.pts; do
  n=$(basename "$f" .pts)
  for v in base snap3; do
    (cd /tmp/h09b2/snap3/pts/tests/run && PTS_HOME=/tmp/h09b2/$v timeout 60 /tmp/h09b2/$v/pts-bin/pts emit-c "$f" -o /tmp/h09b2/review2/emit/$v/$n.c > /tmp/h09b2/review2/emit/$v/$n.err 2>&1)
  done
done
touch /tmp/h09b2/review2/emit/done
