import sys, subprocess, os
# expect.py HOME FILE...: run each test with HOME's CLI; print PASS/FAIL against its // expect: block.
home = sys.argv[1]
for f in sys.argv[2:]:
    lines = open(f).read().split("\n")
    try:
        i = lines.index("// expect:")
    except ValueError:
        print("NOEXPECT", f); continue
    want = [l[3:] if l.startswith("// ") else l[2:] for l in lines[i+1:] if l.startswith("//")]
    env = dict(os.environ, PTS_HOME=home)
    p = subprocess.run([home + "/pts-bin/pts", "run", f], capture_output=True, text=True, env=env, timeout=300, cwd="/tmp/h09b2/review2")
    got = p.stdout.rstrip("\n").split("\n") if p.stdout else []
    ok = got == want and p.returncode == 0
    print(("PASS" if ok else "FAIL") + f" rc={p.returncode} {os.path.basename(f)}")
    if not ok:
        for j in range(max(len(want), len(got))):
            w = want[j] if j < len(want) else "<none>"; g = got[j] if j < len(got) else "<none>"
            if w != g: print(f"   want: {w}\n   got:  {g}")
        if p.stderr: print("   stderr:", p.stderr.strip()[:300])
