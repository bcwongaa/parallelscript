#!/bin/bash
# cg.sh BINARY [ARGS...]: callgrind instructions per iteration (N=200000 minus N=100000, PTS_THREADS=1).
bin=$1; shift
for n in 100000 200000; do
  PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=/tmp/h09b2/review2/bench/cg.$(basename "$bin").$n.out "$bin" "$n" "$@" > /dev/null 2> /tmp/h09b2/review2/bench/cg.$(basename "$bin").$n.log
  ir=$(grep -o "Collected : [0-9]*" /tmp/h09b2/review2/bench/cg.$(basename "$bin").$n.log | grep -o "[0-9]*")
  eval "ir_$n=$ir"
done
echo "$(basename "$bin") $* per-iteration=$(( (ir_200000 - ir_100000) / 100000 ))"
