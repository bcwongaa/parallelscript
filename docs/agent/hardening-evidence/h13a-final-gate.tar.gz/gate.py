#!/usr/bin/env python3
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
label = sys.argv[2]
out = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=True)


def hashes():
    paths = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '-z']).decode().split('\0')
    untracked = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '--others', '--exclude-standard', '-z']).decode().split('\0')
    selected = sorted(set(paths + untracked))
    result = {}
    for name in selected:
        if name.startswith(('pts/', 'cmd/pts/', 'internal/')) and Path(name).suffix in {'.go', '.c', '.h', '.pts', '.json', '.ts', '.out', '.tsv'}:
            path = repo / name
            if path.is_file():
                result[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    for name in ['README.md', 'docs/GUIDE.md', 'docs/SPEC.md', 'docs/ARCHITECTURE.md', 'docs/DECISIONS.md']:
        result[name] = hashlib.sha256((repo / name).read_bytes()).hexdigest()
    cli = repo / 'pts-bin/pts'
    if cli.is_file():
        result['pts-bin/pts'] = hashlib.sha256(cli.read_bytes()).hexdigest()
    return result


def save(name, data):
    (out / f'{label}-{name}.json').write_text(json.dumps(data, indent=2) + '\n')


env = os.environ.copy()
env.update(GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
with (out / f'{label}-build.out').open('wb') as stdout, (out / f'{label}-build.err').open('wb') as stderr:
    build = subprocess.run(['make', 'build'], cwd=repo, env=env, stdout=stdout, stderr=stderr)
if build.returncode:
    sys.exit(build.returncode)
before = hashes()
save('before', before)
command = ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']
with (out / f'{label}-suite.jsonl').open('wb') as stdout, (out / f'{label}-suite.err').open('wb') as stderr:
    suite = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
after = hashes()
save('after', after)
counts = collections.Counter()
packages = {}
corpus = collections.Counter()
with (out / f'{label}-suite.jsonl').open() as stream:
    for line in stream:
        event = json.loads(line)
        action = event.get('Action')
        test = event.get('Test')
        if action in {'pass', 'fail', 'skip'}:
            if test:
                counts[action] += 1
                if test.startswith('TestCorpusMatchesNode/'):
                    corpus[action] += 1
            else:
                packages[event['Package']] = action
summary = {'exit': suite.returncode, 'command': command, 'testEvents': counts, 'packageResults': packages,
           'corpusEvents': corpus, 'monitoredFiles': len(before), 'hashesUnchanged': before == after,
           'stderrBytes': (out / f'{label}-suite.err').stat().st_size}
save('summary', summary)
print(json.dumps(summary, indent=2), flush=True)
sys.exit(suite.returncode or (0 if before == after else 1))
