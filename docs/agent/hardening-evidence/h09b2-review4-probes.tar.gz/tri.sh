#!/bin/bash
# tri.sh files...: run each .pts with base, snap2 and Node (.mts copy); print the three outputs with exit codes.
export PATH=$HOME/.local/node/bin:$PATH
for f in "$@"; do
  echo "################ $f"
  a=$(cd /tmp/h09b2/review4 && PTS_HOME=/tmp/h09b2/base timeout 120 /tmp/h09b2/base/pts-bin/pts run "$f" 2>&1); ea=$?
  b=$(cd /tmp/h09b2/review4 && PTS_HOME=/tmp/h09b2/snap6 timeout 120 /tmp/h09b2/snap6/pts-bin/pts run "$f" 2>&1); eb=$?
  if [ -z "$NONODE" ]; then
    m=/tmp/h09b2/review4/node/$(basename "${f%.pts}").mts; mkdir -p /tmp/h09b2/review4/node; cp "$f" "$m"
    n=$(cd /tmp/h09b2/review4/node && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types "$m" 2>&1); en=$?
  fi
  echo "--- base ($ea)"; echo "$a"
  echo "--- snap6 ($eb)"; echo "$b"
  [ -z "$NONODE" ] && { echo "--- node ($en)"; echo "$n"; }
done
