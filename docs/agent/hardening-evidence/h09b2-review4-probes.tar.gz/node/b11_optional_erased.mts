type M<T> = { readonly tag: "maybe"; readonly value?: T; readonly xs: T[] } | { readonly tag: "none" };
type N<T> = { readonly tag: "maybe"; readonly value?: T; readonly xs: T[] };
const Ops = {
  absent<T>(): M<T> {
    return { tag: "maybe", xs: [] };
  },
  absentN<T>(): N<T> {
    return { tag: "maybe", xs: [] };
  },
};
const raw: any = Ops.absent<number>();
console.log("erased object itself", "value" in raw, Object.keys(raw).join(","));
const b = Ops["absent"]<number>();
console.log("through the union", "value" in b, Object.keys(b).join(","));
const n = Ops["absentN"]<number>();
console.log("through an object type", "value" in n, Object.keys(n).join(","));
