function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
function same(x: any, y: any): boolean {
  return x === y;
}
const Ops = {
  index<T>(x: T): Map<string, T> {
    return new Map([
      ["b", x],
      ["a", x],
    ]);
  },
  keyed<T>(x: T): Map<T, string> {
    return new Map([[x, "v"]]);
  },
  unique<T>(x: T): Set<T> {
    return new Set([x]);
  },
  nested<T>(x: T): Map<string, T[]> {
    return new Map([["k", [x]]]);
  },
  opt<T>(x: T): { tag: "some"; m: Map<string, T> } | { tag: "none" } {
    return { tag: "some", m: new Map([["k", x]]) };
  },
};
attempt("erased map, then a write through the copy", () => {
  const m = Ops["index"](7);
  m.set("c", 1);
  return [...m.entries()].map(([k, v]) => k + "=" + (v * 2)).join(",");
});
attempt("erased map keyed by T", () => {
  const m = Ops["keyed"](7);
  return String(m.get(7)) + " " + String([...m.keys()][0] * 2);
});
attempt("erased map of arrays", () => {
  const m = Ops["nested"](7);
  return String(m.get("k")![0] * 2);
});
attempt("erased set of numbers", () => {
  const s = Ops["unique"](7);
  let t = 0;
  for (const x of s) t += x * 2;
  return String(t) + " " + String(s.has(7));
});
attempt("erased map inside a union", () => {
  const o = Ops["opt"](7);
  return o.tag === "some" ? String(o.m.get("k")! * 2) : "none";
});
const own = new Map<string, number>([["z", 3]]);
attempt("typed map via any to a wider value type", () => {
  const wide: Map<string, number | string> = own as any;
  wide.set("w", "str");
  return String(same(wide, own)) + " " + String(own.size);
});
const frozen = Object.freeze(new Map<string, any>([["q", 1]]));
attempt("frozen map via any to another type", () => {
  const m: Map<string, number> = frozen as any;
  return String(Object.isFrozen(m)) + " " + String(same(m, frozen));
});
const objKey = { id: 1 };
const byObj = new Map<any, any>([[objKey, 2]]);
attempt("object key kept", () => {
  const m: Map<{ id: number }, number> = byObj as any;
  return String(m.get(objKey)! * 2);
});
const numKeyAsString = new Map<any, number>([["1", 2]]);
attempt("a lie in a key", () => {
  const m: Map<number, number> = numKeyAsString as any;
  return String(m.get(1));
});
const dupes = new Map<any, number>([[1, 2], [1.0, 3]]);
attempt("number keys", () => {
  const m: Map<number, number> = dupes as any;
  return String(m.size) + " " + String(m.get(1));
});
const setOfOpt = new Set<any>([{ tag: "some", value: [7] }]);
type Opt = { tag: "none" } | { tag: "some"; value: number[] };
attempt("set of union objects", () => {
  const s: Set<Opt> = setOfOpt as any;
  let r = "";
  for (const o of s) r += o.tag === "some" ? String(o.value[0] * 2) : "none";
  return r;
});
const mapOfOpt = new Map<any, any>([[{ tag: "some", value: [7] }, 1]]);
attempt("map keyed by union objects", () => {
  const m: Map<Opt, number> = mapOfOpt as any;
  let r = "";
  for (const [o] of m) r += o.tag === "some" ? String(o.value[0] * 2) : "none";
  return r;
});
