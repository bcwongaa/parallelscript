// An erased copy's object whose literal lists its properties in another order than the
// union member declares them, copied into the member: Object.keys, JSON.stringify, console.log.
type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
const Ops = {
  wrap<T>(x: T): Opt<T> {
    return { value: [x], tag: "some" };
  },
};
const o = Ops["wrap"](7);
console.log(Object.keys(o).join(","), JSON.stringify(o));
console.log(o);
const parsed: Opt<number> = JSON.parse('{"value":[1],"tag":"some"}');
console.log(Object.keys(parsed).join(","), JSON.stringify(parsed));
