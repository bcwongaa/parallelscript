const proto = { x: 1, y: "a" };
type P = typeof proto;
type U = P | { z: string };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const other = { y: "b", x: 2 };
const a: any = other;
attempt("shape through any", () => {
  const p: P = a;
  return String(p.x * 2) + " " + p.y;
});
attempt("shape union through any", () => {
  const u: U = a;
  if ("x" in u) {
    return String(u.x * 2) + " " + u.y;
  }
  return u.z;
});
const parsed = JSON.parse('{"y": "c", "x": 3.5}');
attempt("shape union from JSON", () => {
  const u: U = parsed;
  if ("x" in u) {
    return String(u.x * 2) + " " + u.y;
  }
  return u.z;
});
const arr: P[] = [proto];
attempt("array of shapes", () => {
  const xs: P[] = a ? [a] : arr;
  return String(xs[0].x * 2);
});
