type Opt = { readonly tag: "none" } | { readonly tag: "some"; readonly value: number[] };
class Some {
  readonly tag = "some" as const;
  constructor(public value: number[]) {}
}
function same(x: any, y: any): boolean {
  return x === y;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const s = new Some([1]);
const a: any = s;
attempt("class instance through any", () => {
  const o: Opt = a;
  return String(same(o, s));
});
const plain = { tag: "some" as const, value: [1] };
attempt("literal", () => {
  const o: Opt = plain;
  return String(same(o, plain));
});
attempt("literal through any", () => {
  const o: Opt = plain as any;
  return String(same(o, plain));
});
const extra = { tag: "some" as const, value: [1], extra: 5 };
attempt("extra through any", () => {
  const o: Opt = extra as any;
  return String(same(o, extra));
});
attempt("extra statically", () => {
  const o: Opt = extra;
  return String(same(o, extra));
});
const loose: { tag: "some"; value: any } = { tag: "some", value: [1] };
attempt("loose any field statically", () => {
  const o: Opt = loose;
  loose.value = [2];
  return String(same(o, loose)) + " " + (o.tag === "some" ? String(o.value) : "none");
});
const looseArr: { tag: "some"; value: any[] } = { tag: "some", value: [1] };
attempt("loose any[] field, then a push", () => {
  const o: Opt = looseArr;
  looseArr.value.push(2);
  return String(same(o, looseArr)) + " " + (o.tag === "some" ? String(o.value) : "none");
});
attempt("loose any[] field, push through the union", () => {
  const o: Opt = looseArr;
  if (o.tag === "some") {
    (o.value as number[]).push(3);
  }
  return String(looseArr.value);
});
const none = { tag: "none" as const };
attempt("none", () => {
  const o: Opt = none as any;
  return String(same(o, none));
});
const frozen = Object.freeze({ tag: "some" as const, value: [1] });
attempt("frozen through any", () => {
  const o: Opt = frozen as any;
  return String(same(o, frozen)) + " " + String(Object.isFrozen(o));
});
const nested: { inner: Opt } = { inner: plain };
attempt("nested union field through any", () => {
  const n: { inner: Opt } = nested as any;
  return String(same(n, nested)) + " " + String(same(n.inner, plain));
});
const nestedLoose: { inner: { tag: "some"; value: any[] } } = { inner: looseArr };
attempt("nested loose through any", () => {
  const n: { inner: Opt } = nestedLoose as any;
  return String(same(n, nestedLoose)) + " " + String(same(n.inner, looseArr));
});
