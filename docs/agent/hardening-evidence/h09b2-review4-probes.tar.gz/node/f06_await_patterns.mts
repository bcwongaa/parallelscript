// Honest objects (object literals, no any) coming back through await into a union whose
// covering member declares wider property types: kept (Node) or copied?
function same(x: any, y: any): boolean {
  return x === y;
}
async function later<T>(x: T): Promise<T> {
  return x;
}
type A = { kind: "a"; v?: number | string } | { kind: "none" };
type B = { kind: "b"; f?: (x: number, y: number) => number } | { kind: "none" };
type C = { kind: "c"; inner: { n: number | string } } | { kind: "none" };
type D = { kind: "d"; xs: (number | string)[] } | { kind: "none" };
type E = { kind: "e"; v: number | undefined } | { kind: "none" };
type F = { kind: "f"; at: { x: number } } | { kind: "none" };
async function main(): Promise<void> {
  const a = { kind: "a" as const, v: 5 };
  console.log("optional wider", same(await later<A>(a), a));
  const b = { kind: "b" as const, f: (x: number) => x };
  console.log("optional callback of fewer parameters", same(await later<B>(b), b));
  const c = { kind: "c" as const, inner: { n: 5 } };
  console.log("nested wider", same(await later<C>(c), c));
  const d = { kind: "d" as const, xs: [5] };
  console.log("array of a narrower element", same(await later<D>(d), d));
  const e = { kind: "e" as const, v: 5 };
  console.log("number where number | undefined goes", same(await later<E>(e), e));
  const f = { kind: "f" as const, at: { x: 1, y: 2 } };
  console.log("nested with more properties", same(await later<F>(f), f));
}
main();
