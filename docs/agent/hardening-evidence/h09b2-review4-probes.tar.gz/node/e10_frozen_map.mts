// A frozen Map converted by a copy (another value type): JS's frozen maps still take set().
const fm = Object.freeze(new Map<string, any>([["a", 1]]));
const loose: any = fm;
const typed: Map<string, number> = loose;
try {
  typed.set("b", 2);
  console.log("set on the copy", typed.size, Object.isFrozen(typed));
} catch (e: any) {
  console.log("set on the copy", e.name, e.message);
}
try {
  fm.set("c", 3);
  console.log("set on the original", fm.size);
} catch (e: any) {
  console.log("set on the original", e.name, e.message);
}
const fs = Object.freeze(new Set<any>([1]));
const ts: Set<number> = fs as any;
try {
  ts.add(2);
  console.log("add on the set copy", ts.size);
} catch (e: any) {
  console.log("add on the set copy", e.name, e.message);
}
