// Generic methods of an object literal whose parameters hold a generic class's instance
// (not in a union of object types): an erased copy's object holds Box<any>.
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const Ops = {
  make<T>(x: T): { box: Box<T> } {
    return { box: new Box(x) };
  },
  get<T>(o: { box: Box<T> }): T {
    return o.box.value;
  },
  list<T>(x: T): Box<T>[] {
    return [new Box(x)];
  },
  first<T>(xs: Box<T>[]): T {
    return xs[0].value;
  },
  maybe<T>(x: T): Box<T> | undefined {
    return new Box(x);
  },
  orZero<T>(b: Box<T> | undefined, d: T): T {
    return b === undefined ? d : b.value;
  },
  wrapped<T>(x: T): { tag: "some"; box: Box<T> } | { tag: "none" } {
    return { tag: "some", box: new Box(x) };
  },
  unwrap<T>(o: { tag: "some"; box: Box<T> } | { tag: "none" }, d: T): T {
    return o.tag === "some" ? o.box.value : d;
  },
};
attempt("an interface holding Box<T>", () => String(Ops.get(Ops["make"](7))));
attempt("an array of Box<T>", () => String(Ops.first(Ops["list"](7))));
attempt("Box<T> or undefined", () => String(Ops.orZero(Ops["maybe"](7), 0)));
attempt("a union of object types holding Box<T>", () => String(Ops.unwrap(Ops["wrapped"](7), 0)));
