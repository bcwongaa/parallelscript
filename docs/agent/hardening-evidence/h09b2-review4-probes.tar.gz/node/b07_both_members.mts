type U = { tag: "a"; value: number[] } | { tag: "b"; note: string };
function same(x: any, y: any): boolean {
  return x === y;
}
const both = { tag: "a" as const, value: [1], note: "x" };
const holder = { inner: both };
const h: any = holder;
const typed: { inner: U } = h;
console.log("holder kept", same(typed, holder), same(typed.inner, both));
holder.inner.value.push(2);
const i = typed.inner;
console.log("inner sees push", i.tag === "a" ? i.value.length : -1);
const u: U = both as any;
console.log("direct kept", same(u, both));
