// An interface-typed value whose object is a class's instance, holding an any[] that the
// union's other member declares as number[]: leavesOut copies it into a plain object.
type Opt = { readonly tag: "some"; readonly value: number[] } | { readonly tag: "none" };
interface Loose {
  readonly tag: "some";
  value: any[];
  label(): string;
}
class Impl implements Loose {
  readonly tag = "some" as const;
  value: any[] = [7];
  label(): string {
    return "impl";
  }
}
function same(x: any, y: any): boolean {
  return x === y;
}
const impl = new Impl();
const loose: Loose = impl;
const o: Opt = loose;
impl.value.push(8);
console.log("same", same(o, impl), "instanceof", (o as any) instanceof Impl);
console.log("sees the push", o.tag === "some" ? o.value.length : -1);
console.log("method", typeof (o as any).label);
interface LooseNoMethod {
  readonly tag: "some";
  value: any[];
}
class Impl2 implements LooseNoMethod {
  readonly tag = "some" as const;
  value: any[] = [7];
}
const impl2 = new Impl2();
const loose2: LooseNoMethod = impl2;
const o2: Opt = loose2;
impl2.value.push(8);
console.log("same", same(o2, impl2), "instanceof", (o2 as any) instanceof Impl2);
console.log("sees the push", o2.tag === "some" ? o2.value.length : -1);
