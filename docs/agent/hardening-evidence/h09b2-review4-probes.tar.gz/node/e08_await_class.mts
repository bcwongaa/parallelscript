// A class implementing a union member with a narrower property type (number where the
// member says number | undefined), returned by an async function typed with the union.
type Item = { kind: "item"; price: number | undefined } | { kind: "none" };
class Product {
  readonly kind = "item" as const;
  constructor(public price: number) {}
  label(): string {
    return "product at " + this.price;
  }
}
async function load(): Promise<Item> {
  return new Product(5);
}
async function main(): Promise<void> {
  const it = await load();
  console.log(it instanceof Product, typeof (it as any).label);
  console.log(it.kind === "item" ? it.price : -1);
  const direct: Item = new Product(6);
  console.log(direct instanceof Product);
}
main();
