// Places whose IR type may be an object literal's shape (direct struct reads) taking objects
// of another layout: a let of a literal's type, a parameter and an interface's property typed
// `typeof lit`, an array of them; the other layout holds an i32 where the shape holds a number.
const lit = { x: 1.5, y: "a" };
type Lit = typeof lit;
interface H {
  p: Lit;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const other: any = { y: "b", x: 2.5, z: 1 };
attempt("a let of the literal's type", () => {
  let o = { x: 1.5, y: "a" };
  o = other;
  return String(o.x * 2) + " " + o.y;
});
function px(p: Lit): string {
  return String(p.x * 2) + " " + p.y;
}
attempt("a parameter", () => px(other));
attempt("an interface's property", () => {
  const h: H = { p: other };
  return String(h.p.x * 2) + " " + h.p.y;
});
attempt("an interface's property read from another layout", () => {
  const raw: any = { p: { y: "c", x: 3.5 } };
  const h: H = raw;
  return String(h.p.x * 2) + " " + h.p.y;
});
attempt("an array of them", () => {
  const xs: Lit[] = [other];
  return String(xs[0].x * 2);
});
const narrowLayout = { y: "d", x: 4 as i32 };
attempt("an i32 field read through the shape's type", () => {
  const h: H = { p: narrowLayout as any };
  return String(h.p.x * 2) + " " + h.p.y;
});
const holder = { p: narrowLayout };
attempt("a holder of the i32 layout read as H", () => {
  const h: H = holder as any;
  return String(h.p.x * 2) + " " + h.p.y;
});
