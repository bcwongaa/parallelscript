// Objects a union takes as a covering member whose properties sites read as they are
// (a number where number | string goes, a closure of fewer parameters, a getter, an
// optional property, a frozen object), through await (a checked conversion): then writes,
// reads, `in`, Object.keys, JSON.stringify and console.log.
type Val = { kind: "v"; v: number | string; f?: (a: number, b: number) => number } | { kind: "none" };
function same(x: any, y: any): boolean {
  return x === y;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
async function later<T>(x: T): Promise<T> {
  return x;
}
async function main(): Promise<void> {
  const o = { kind: "v" as const, v: 5, f: (a: number) => a * 2 };
  const s: Val = await later<Val>(o);
  attempt("kept", () => String(same(s, o)));
  attempt("read", () => (s.kind === "v" ? String(s.v) + " " + String(s.f?.(3, 4)) : "none"));
  attempt("write a number", () => {
    if (s.kind === "v") s.v = 6;
    return String(o.v);
  });
  attempt("write a string", () => {
    if (s.kind === "v") s.v = "six";
    return String(o.v);
  });
  attempt("in, keys, JSON", () => String("f" in s) + " " + Object.keys(s).join(",") + " " + JSON.stringify(s));
  const g = {
    kind: "v" as const,
    get v(): number {
      return 7;
    },
  };
  const t: Val = await later<Val>(g);
  attempt("getter kept", () => String(same(t, g)) + " " + (t.kind === "v" ? String(t.v) : "none"));
  console.log("getter logged", t);
  const fr = Object.freeze({ kind: "v" as const, v: 8 });
  const u: Val = await later<Val>(fr);
  attempt("frozen kept", () => String(same(u, fr)) + " " + String(Object.isFrozen(u)));
  attempt("write to frozen", () => {
    if (u.kind === "v") u.v = 9;
    return "wrote";
  });
  const absent: { kind: "v"; v: number; f?: (a: number) => number } = { kind: "v", v: 10 };
  const w: Val = await later<Val>(absent);
  attempt("absent optional", () => String(same(w, absent)) + " " + String("f" in w) + " " + (w.kind === "v" ? String(w.f) : ""));
}
main();
