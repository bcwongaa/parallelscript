function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
type A = { kind: "a"; extra?: string } | { kind: "b"; extra: number };
attempt("optional shared name, b", () => {
  const v: A = JSON.parse('{"kind":"b","extra":5}');
  return v.kind === "b" ? String(v.extra * 2) : String(v.extra);
});
attempt("optional shared name, a", () => {
  const v: A = JSON.parse('{"kind":"a","extra":"x"}');
  return v.kind === "a" ? String(v.extra) : "b";
});
attempt("optional shared name, a without", () => {
  const v: A = JSON.parse('{"kind":"a"}');
  return v.kind === "a" ? String(v.extra) : "b";
});
type B = { t: "circle"; r: number } | { t: "rect"; w: number; h: number } | { t: "poly"; pts: [number, number][] };
attempt("three members", () => {
  const vs: B[] = JSON.parse('[{"t":"circle","r":1.5},{"t":"rect","w":2,"h":3},{"t":"poly","pts":[[1,2],[3,4.5]]}]');
  return vs.map((v) => (v.t === "circle" ? v.r : v.t === "rect" ? v.w * v.h : v.pts[1][1])).join(",");
});
type C = { k: "x"; data: { n: number } } | { k: "y"; data: Record<string, number> };
attempt("same name, object vs record (C189)", () => {
  const v: C = JSON.parse('{"k":"y","data":{"n":1,"m":2}}');
  return v.k === "y" ? Object.keys(v.data).join(",") : "x";
});
type D = { k: "x"; v: number } | { k: "y"; v: string } | { k: "z"; v: boolean };
attempt("same name, primitives", () => {
  const vs: D[] = JSON.parse('[{"k":"x","v":1},{"k":"y","v":"s"},{"k":"z","v":true}]');
  return vs.map((v) => (v.k === "x" ? String(v.v + 1) : v.k === "y" ? v.v.toUpperCase() : String(!v.v))).join(",");
});
type E = { type: "leaf"; value: number } | { type: "node"; left: E; right: E };
attempt("recursive", () => {
  const t: E = JSON.parse('{"type":"node","left":{"type":"leaf","value":1.5},"right":{"type":"node","left":{"type":"leaf","value":2},"right":{"type":"leaf","value":3}}}');
  const sum = (e: E): number => (e.type === "leaf" ? e.value : sum(e.left) + sum(e.right));
  return String(sum(t));
});
type F = { a: number } | { b: string };
attempt("in narrowing", () => {
  const vs: F[] = JSON.parse('[{"a":1},{"b":"x"}]');
  return vs.map((v) => ("a" in v ? String(v.a) : v.b)).join(",");
});
attempt("in narrowing, both", () => {
  const v: F = JSON.parse('{"a":1,"b":"x"}');
  return "a" in v ? String(v.a) : v.b;
});
