const a = { y: "q", x: 1.5 };
const other: any = { x: 2.5, y: "r", z: 1 };
let u = Math.random() > 2 ? a : "s";
u = other;
if (typeof u !== "string") {
  console.log(u.x * 2, u.y);
}
const arr = [a];
const loose: any[] = [{ x: 3.5, y: "t" }];
const arr2: typeof arr = loose;
console.log(arr2[0].x * 2, arr2[0].y);
