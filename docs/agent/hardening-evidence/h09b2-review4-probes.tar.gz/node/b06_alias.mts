// An erased copy keeps the object it returns and changes it later; typed code holds it
// through a union of object types.
type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
const store: any[] = [];
const Ops = {
  wrap<T>(x: T): Opt<T> {
    const o: Opt<T> = { tag: "some", value: [x] };
    store.push(o);
    return o;
  },
  add<T>(x: T): number {
    store[0].value.push(x);
    return store[0].value.length;
  },
};
const o = Ops["wrap"](7);
console.log("erased side sees", Ops["add"](8));
if (o.tag === "some") {
  console.log("typed side sees", o.value.length, o.value.join(","));
  o.value.push(9);
}
console.log("erased side after a typed push", store[0].value.length);
console.log("same object", (o as any) === store[0]);
