type Ev = { kind: "none" } | { kind: "some"; items: number[] };
type Ev2 = { kind: "some"; items: number[] } | { kind: "none" };
const events: Ev[] = JSON.parse('[{"kind":"some","items":[1,2]},{"kind":"none"}]');
for (const e of events) {
  console.log("parsed", e.kind === "some" ? e.items.reduce((a, b) => a + b, 0) : "none");
}
const events2: Ev2[] = JSON.parse('[{"kind":"some","items":[1,2]},{"kind":"none"}]');
for (const e of events2) {
  console.log("parsed2", e.kind === "some" ? e.items.reduce((a, b) => a + b, 0) : "none");
}
const one: Ev = JSON.parse('{"kind":"some","items":[1,2.5]}');
console.log("one", one.kind === "some" ? one.items[1] * 2 : "none");
const loose: any = { kind: "some", items: JSON.parse("[1, 2.5]") };
const two: Ev = loose;
console.log("two", two.kind === "some" ? two.items[1] * 2 : "none");
