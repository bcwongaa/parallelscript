// Erased results of a call through a union of interfaces reaching union-typed places
// through a conditional, `!`, `??`, `||`, a comma and an arrow's expression body.
interface ListerA {
  list<T>(x: T): T[] | undefined;
  a(): number;
}
interface ListerB {
  list<T>(x: T): T[] | undefined;
  b(): number;
}
class LA implements ListerA {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  a(): number {
    return 1;
  }
}
class LB implements ListerB {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  b(): number {
    return 2;
  }
}
function pick(n: number): ListerA | ListerB {
  return n === 0 ? new LA() : new LB();
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const seven: any = 7;
const flag = Math.random() < 2;
attempt("conditional", () => {
  const xs: number[] | undefined = flag ? pick(0).list<number>(seven) : undefined;
  return String(xs![0] * 2);
});
attempt("non-null into union", () => {
  const xs: number[] | undefined = pick(0).list<number>(seven)!;
  return String(xs![0] * 2);
});
attempt("nullish", () => {
  const xs: number[] | undefined = pick(0).list<number>(seven) ?? undefined;
  return String(xs![0] * 2);
});
attempt("or", () => {
  const xs: number[] | undefined = pick(0).list<number>(seven) || undefined;
  return String(xs![0] * 2);
});
attempt("returned", () => {
  const g = (): number[] | undefined => pick(0).list<number>(seven);
  return String(g()![0] * 2);
});
attempt("argument", () => {
  const h = (xs: number[] | undefined): string => String(xs![0] * 2);
  return h(pick(0).list<number>(seven));
});
attempt("array literal", () => {
  const all: (number[] | undefined)[] = [pick(0).list<number>(seven)];
  return String(all[0]![0] * 2);
});
attempt("object literal", () => {
  const o: { xs: number[] | undefined } = { xs: pick(0).list<number>(seven) };
  return String(o.xs![0] * 2);
});
attempt("assignment", () => {
  let xs: number[] | undefined = undefined;
  xs = pick(0).list<number>(seven);
  return String(xs![0] * 2);
});
