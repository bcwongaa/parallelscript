// A guard that lies (too weak), through find over an unknown[]: typed code must throw, not crash.
function isTexts(x: unknown): x is string[] | number {
  return typeof x === "number" || Array.isArray(x);
}
const arr: unknown[] = JSON.parse("[[1, 2]]");
try {
  const v = arr.find(isTexts);
  if (v !== undefined && typeof v !== "number") {
    console.log("length of the first", v[0].length);
  }
} catch (e: any) {
  console.log(e.name);
}
console.log("done");
