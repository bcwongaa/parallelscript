// An unknown narrowed to an array of a union, then read by its own methods.
function isList(x: unknown): x is (number[] | string)[] {
  return Array.isArray(x);
}
function total(v: number[] | string | undefined): number {
  if (v === undefined) {
    return -1;
  }
  if (typeof v === "string") {
    return v.length;
  }
  let sum = 0;
  for (const n of v) {
    sum += n;
  }
  return sum;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const data: unknown = JSON.parse('[[1, 2, 3.5], "ab"]');
class C {
  d: unknown = JSON.parse('[[1, 2, 3.5], "ab"]');
}
const c = new C();
if (isList(data)) {
  attempt("pop", () => String(total(data.pop())));
  attempt("at", () => String(total(data.at(0))));
  attempt("index", () => String(total(data[0])));
  attempt("find", () => String(total(data.find((v) => typeof v !== "string"))));
}
if (isList(c.d)) {
  const d = c.d;
  attempt("field: at", () => String(total(d.at(0))));
  attempt("field: find", () => String(total(d.find((v) => typeof v !== "string"))));
  attempt("field: index", () => String(total(d[0])));
}
