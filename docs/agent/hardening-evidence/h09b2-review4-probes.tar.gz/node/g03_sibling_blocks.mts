// A nested object kept as a union member's: reading a property whose type matches exactly
// throws because a sibling property (an array of a narrower element) isn't read as it is.
type T = { kind: "t"; inner: { n: number; xs: (number | string)[] } } | { kind: "none" };
const inner = { n: 5, xs: [1, 2] };
const o = { kind: "t" as const, inner };
const s: T = o;
try {
  console.log(s.kind === "t" ? s.inner.n : -1);
} catch (e: any) {
  console.log(e.name, e.message);
}
