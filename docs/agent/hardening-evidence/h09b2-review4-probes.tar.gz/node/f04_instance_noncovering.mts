// Class instances that a union takes as a member that doesn't cover them (no member takes
// them as they are otherwise), then narrowed by a tag, `in` and instanceof; reads and writes.
interface Animal {
  name: string;
}
class Dog implements Animal {
  constructor(public name: string) {}
}
class Pack {
  readonly kind = "pack" as const;
  constructor(public members: Dog[], public size: number) {}
  describe(): string {
    return "pack of " + this.members.length;
  }
}
type Group = { kind: "pack"; members: Animal[]; size: number } | { kind: "empty"; size: number };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
async function later<T>(x: T): Promise<T> {
  return x;
}
async function main(): Promise<void> {
  const pack = new Pack([new Dog("rex")], 1);
  const g: Group = await later<Group>(pack);
  attempt("kept", () => String((g as any) === pack) + " " + String(g instanceof Pack));
  attempt("size", () => String(g.size));
  attempt("write size", () => {
    g.size = 2;
    return String(pack.size);
  });
  attempt("in", () => ("members" in g ? "has members" : "none"));
  attempt("narrowed by tag", () => (g.kind === "pack" ? String(g.members.length) : "empty"));
  attempt("instanceof", () => String(g instanceof Pack));
  attempt("JSON", () => JSON.stringify(g));
}
main();
