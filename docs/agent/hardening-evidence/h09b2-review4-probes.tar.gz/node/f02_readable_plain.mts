// A covering member whose properties sites read as they are (number where number | string
// goes, a closure of fewer parameters), through await: kept, then writes and reads.
type Val = { kind: "v"; v: number | string; f: (a: number, b: number) => number } | { kind: "none" };
function same(x: any, y: any): boolean {
  return x === y;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
async function later<T>(x: T): Promise<T> {
  return x;
}
async function main(): Promise<void> {
  const o = { kind: "v" as const, v: 5, f: (a: number) => a * 2 };
  const s: Val = await later<Val>(o);
  attempt("kept", () => String(same(s, o)));
  attempt("read", () => (s.kind === "v" ? String(s.v) + " " + String(s.f(3, 4)) : "none"));
  attempt("write a number", () => {
    if (s.kind === "v") s.v = 6;
    return String(o.v);
  });
  attempt("write a string", () => {
    if (s.kind === "v") s.v = "six";
    return String(o.v);
  });
  attempt("write a closure", () => {
    if (s.kind === "v") s.f = (a: number, b: number) => a + b;
    return String(o.f(3));
  });
  attempt("JSON", () => JSON.stringify(s));
  const direct: Val = o;
  attempt("statically", () => String(same(direct, o)));
}
main();
