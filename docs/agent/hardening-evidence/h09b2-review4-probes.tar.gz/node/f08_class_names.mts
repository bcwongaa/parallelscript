// Class instances whose descriptors' names are unusual (an anonymous class expression, an
// Error subclass) through await into a union whose covering member they can't be as they are.
type Opt = { kind: "some"; value: number[] } | { kind: "none" };
class MyErr extends Error {
  readonly kind = "some" as const;
  value: any[] = [8];
}
async function later<T>(x: T): Promise<T> {
  return x;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
async function main(): Promise<void> {
  const e = new MyErr("x");
  const p: Opt = await later<Opt>(e as any);
  attempt("error subclass kept", () => String((p as any) === e) + " " + String(p instanceof MyErr));
}
main();
