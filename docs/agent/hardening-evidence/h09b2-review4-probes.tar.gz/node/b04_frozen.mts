type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
const Ops = {
  frozen<T>(x: T): Opt<T> {
    return Object.freeze({ tag: "some", value: [x] });
  },
};
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name);
  }
}
attempt("frozen erased object", () => {
  const o = Ops["frozen"](7);
  return String(Object.isFrozen(o)) + " " + (o.tag === "some" ? String(o.value[0] * 2) : "none");
});
attempt("write to a frozen erased object", () => {
  const o: any = Ops["frozen"](7);
  const typed: Opt<number> = o;
  (typed as any).tag = "none";
  return String(typed.tag);
});
const plainFrozen = Object.freeze({ tag: "some" as const, value: [1] as any[] });
attempt("frozen typed object with an any[] field", () => {
  const o: Opt<number> = plainFrozen;
  return String(Object.isFrozen(o));
});
