// Narrowed unknown values into many kinds of unions (now checked): no compile failure, Node's output.
type Tree = { kind: "leaf"; v: number } | { kind: "node"; kids: Tree[] };
type Mixed = [number, string?] | Map<string, number> | (() => number) | Set<string> | i32;
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
function isTree(x: unknown): x is Tree {
  return typeof x === "object" && x !== null && "kind" in x;
}
function sum(t: Tree): number {
  return t.kind === "leaf" ? t.v : t.kids.reduce((a, k) => a + sum(k), 0);
}
const data: unknown = JSON.parse('{"kind":"node","kids":[{"kind":"leaf","v":1.5},{"kind":"node","kids":[{"kind":"leaf","v":2}]}]}');
if (isTree(data)) {
  attempt("recursive union", () => String(sum(data || { kind: "leaf", v: 0 })));
}
const m: unknown = new Map([["a", 1.5]]);
function isMixed(x: unknown): x is Mixed {
  return x instanceof Map || x instanceof Set || Array.isArray(x) || typeof x === "function" || typeof x === "number";
}
if (isMixed(m)) {
  attempt("a map in a mixed union", () => {
    const v: Mixed = m;
    return v instanceof Map ? String(v.get("a")! * 2) : "other";
  });
}
const t: unknown = [3.5];
if (isMixed(t)) {
  attempt("a tuple with an optional element", () => {
    const v: Mixed = t;
    return Array.isArray(v) ? String(v[0] * 2) + " " + String(v.length) : "other";
  });
}
const fn: unknown = () => 4.5;
if (isMixed(fn)) {
  attempt("a function", () => {
    const v: Mixed = fn;
    return typeof v === "function" ? String(v() * 2) : "other";
  });
}
