const f = Object.freeze({ value: [1] as any[] });
const a: any = f;
const o: { value: number[] } = a;
console.log(Object.isFrozen(o));
const j = Object.freeze(JSON.parse('{"value": [1]}'));
const o2: { value: number[] } = j;
console.log(Object.isFrozen(o2));
