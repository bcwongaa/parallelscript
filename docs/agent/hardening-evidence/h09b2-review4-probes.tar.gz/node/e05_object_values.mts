// Object.values/entries of an object a union took as a member that leaves properties out
// (an erased copy's object with a method, which can't be copied): its values bypass the
// read sites that verify declared types.
type M<T> = { readonly tag: "some"; get(): T; readonly xs: T[] } | { readonly tag: "none" };
const Ops = {
  mk<T>(x: T): M<T> {
    return {
      tag: "some",
      get() {
        return x;
      },
      xs: [x],
    };
  },
};
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
attempt("Object.values", () => {
  const o = Ops["mk"](7);
  let r = "";
  if (o.tag === "some") {
    for (const v of Object.values(o)) {
      if (Array.isArray(v)) {
        r += String(v[0] * 2);
      }
    }
  }
  return r;
});
attempt("Object.entries", () => {
  const o = Ops["mk"](7);
  let r = "";
  if (o.tag === "some") {
    for (const [k, v] of Object.entries(o)) {
      if (Array.isArray(v)) {
        r += k + "=" + String(v[0] * 2);
      }
    }
  }
  return r;
});
attempt("typed read", () => {
  const o = Ops["mk"](7);
  return o.tag === "some" ? String(o.xs[0] * 2) : "none";
});
