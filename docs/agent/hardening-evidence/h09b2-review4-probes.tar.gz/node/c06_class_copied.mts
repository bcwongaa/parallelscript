// An honest class instance given to a union of object types (no any): it must stay itself.
interface Animal {
  name: string;
}
class Dog implements Animal {
  constructor(public name: string) {}
}
class Pack {
  readonly kind = "pack" as const;
  constructor(public members: Dog[]) {}
  size(): number {
    return this.members.length;
  }
}
type Group = { kind: "pack"; members: Animal[] } | { kind: "empty" };
function describe(g: Group): string {
  return g.kind === "pack" ? g.members.map((m) => m.name).join("+") : "empty";
}
const pack = new Pack([new Dog("rex")]);
const g: Group = pack;
pack.members.push(new Dog("fido"));
console.log(describe(g));
console.log(g instanceof Pack);
console.log(describe(pack));
