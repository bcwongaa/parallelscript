type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const read = (o: Opt<number>): string => (o.tag === "some" ? String(o.value[0] * 2) : "none");
const Ops = {
  wrap<T>(x: T): Opt<T> {
    return { tag: "some", value: [x] };
  },
  async later<T>(x: T): Promise<Opt<T>> {
    return { tag: "some", value: [x] };
  },
  maybe<T>(x: T): Opt<T> | undefined {
    return { tag: "some", value: [x] };
  },
};
const parsed: Opt<number> = JSON.parse('{"tag":"some","value":[1.5]}');
attempt("an erased result or a default", () => read(Ops["maybe"](7) ?? { tag: "none" }));
attempt("an erased result or a default (||)", () => read(Ops["maybe"](7) || { tag: "none" }));
attempt("an erased result's optional", () => {
  const o: Opt<number> | undefined = Ops["maybe"](7);
  return o ? read(o) : "undefined";
});
async function main(): Promise<void> {
  try {
    const all = await Promise.all([Ops["later"](7), Ops["later"](8)]);
    console.log("Promise.all", read(all[0]), read(all[1]));
  } catch (e: any) {
    console.log("Promise.all", e.name, e.message);
  }
  try {
    const one = await Promise.race([Ops["later"](7)]);
    console.log("Promise.race", read(one));
  } catch (e: any) {
    console.log("Promise.race", e.name, e.message);
  }
  try {
    const p = Ops["later"](7);
    const v = await p.then((o) => o);
    console.log("then identity", read(v));
  } catch (e: any) {
    console.log("then identity", e.name, e.message);
  }
}
main();
