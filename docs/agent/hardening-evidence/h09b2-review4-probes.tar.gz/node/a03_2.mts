interface ListerA {
  list<T>(x: T): T[] | undefined;
  a(): number;
}
interface ListerB {
  list<T>(x: T): T[] | undefined;
  b(): number;
}
class LA implements ListerA {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  a(): number {
    return 1;
  }
}
class LB implements ListerB {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  b(): number {
    return 2;
  }
}
function pick(n: number): ListerA | ListerB {
  return n === 0 ? new LA() : new LB();
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const seven: any = 7;
const flag = Math.random() < 2;
attempt("and", () => {
  const xs: number[] | undefined = flag && pick(0).list<number>(seven) || undefined;
  return String(xs![0] * 2);
});
