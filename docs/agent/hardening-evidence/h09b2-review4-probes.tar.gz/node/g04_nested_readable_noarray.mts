// Objects kept statically as a union member, whose nested objects sites read as they are
// (read mode's as-is acceptance): nested arrays, getters, optional/absent, closures, class
// instances, recursion, writes afterwards (g02 without the array, which blocks the rest: g03).
class Pt {
  constructor(public x: number) {}
}
type T =
  | {
      kind: "t";
      inner: {
        n: number | string;
        g: number | string;
        o?: number | string;
        f: (a: number, b: number) => number;
        p: { x: number | string };
      };
    }
  | { kind: "none" };
type N = { v: number | string; next?: N };
type L = { kind: "l"; list: N } | { kind: "none" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const inner = {
  n: 5,
  get g(): number {
    return 7;
  },
  f: (a: number) => a * 10,
  p: new Pt(3),
};
const o = { kind: "t" as const, inner };
const s: T = o;
if (s.kind === "t") {
  attempt("nested number", () => String(s.inner.n));
  attempt("nested getter", () => String(s.inner.g));
  attempt("nested absent optional", () => String(s.inner.o) + " " + String("o" in s.inner));
  attempt("nested closure of fewer parameters", () => String(s.inner.f(2, 3)));
  attempt("nested class instance", () => String(s.inner.p.x));
  attempt("write a number through it", () => {
    s.inner.n = 6;
    return String(inner.n);
  });
  attempt("write a string through it", () => {
    s.inner.n = "six";
    return String(inner.n);
  });
  attempt("write a closure through it", () => {
    s.inner.f = (a: number, b: number) => a + b;
    return String(inner.f(1));
  });
  attempt("hold the nested object and read it later", () => {
    const held = s.inner;
    inner.n = 8;
    return String(held.n) + " " + String((held as any) === inner);
  });
}
const list = { v: 1, next: { v: 2, next: { v: 3 } } };
const l: L = { kind: "l", list: list as any };
attempt("recursive nested", () => (l.kind === "l" ? String(l.list.next?.next?.v) : "none"));
