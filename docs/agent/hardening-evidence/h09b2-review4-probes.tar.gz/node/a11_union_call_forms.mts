interface ListerA {
  list<T>(x: T): T[] | undefined;
  a(): number;
}
interface ListerB {
  list<T>(x: T): T[] | undefined;
  b(): number;
}
class LA implements ListerA {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  a(): number {
    return 1;
  }
}
class LB implements ListerB {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  b(): number {
    return 2;
  }
}
function pick(n: number): ListerA | ListerB {
  return n === 0 ? new LA() : new LB();
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const seven: any = 7;
function pickMaybe(n: number): ListerA | ListerB | undefined {
  return n === 0 ? new LA() : n === 1 ? new LB() : undefined;
}
attempt("optional call through a union", () => {
  const xs: number[] | undefined = pickMaybe(0)?.list<number>(seven);
  return String(xs![0] * 2);
});
attempt("element access call through a union", () => {
  const xs: number[] | undefined = pick(0)["list"]<number>(seven);
  return String(xs![0] * 2);
});
attempt("inferred type argument through a union", () => {
  const n = 7;
  const xs: number[] | undefined = pick(0).list(n);
  return String(xs![0] * 2);
});
attempt("a non-null assertion", () => {
  const xs: number[] | null = pick(0).list<number>(seven)!;
  return String(xs![0] * 2);
});
