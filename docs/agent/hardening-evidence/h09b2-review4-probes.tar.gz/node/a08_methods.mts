// An erased copy's object with a method (returning T) taken by a union of object types.
type M<T> = { readonly tag: "some"; get(): T; readonly xs: T[] } | { readonly tag: "none" };
type G<T> = { readonly tag: "some"; get(): T } | { readonly tag: "none" };
const Ops = {
  mk<T>(x: T): M<T> {
    return {
      tag: "some",
      get() {
        return x;
      },
      xs: [x],
    };
  },
  mg<T>(x: T): G<T> {
    return {
      tag: "some",
      get() {
        return x;
      },
    };
  },
};
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
attempt("method and array", () => {
  const o = Ops["mk"](7);
  return o.tag === "some" ? String(o.get() * 2) + " " + String(o.xs[0] * 2) : "none";
});
attempt("method only", () => {
  const o = Ops["mg"](7);
  return o.tag === "some" ? String(o.get() * 2) : "none";
});
attempt("method only, a lie", () => {
  const o = Ops.mg<string>(7 as any);
  return o.tag === "some" ? String(o.get().length) : "none";
});
attempt("method and array, a lie", () => {
  const o = Ops.mk<string>(7 as any);
  return o.tag === "some" ? String(o.get().length) : "none";
});
