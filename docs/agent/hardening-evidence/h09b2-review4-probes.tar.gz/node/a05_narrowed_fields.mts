function isNumbersOrText(x: unknown): x is number[] | string {
  return typeof x === "string" || (Array.isArray(x) && x.every((e) => typeof e === "number"));
}
function total(v: number[] | string): number {
  if (typeof v === "string") {
    return v.length;
  }
  let sum = 0;
  for (const n of v) {
    sum += n;
  }
  return sum;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
class C {
  data: any = JSON.parse("[1, 2, 3.5]");
  other: unknown = JSON.parse("[1, 2, 3.5]");
}
interface I {
  data: unknown;
}
const c = new C();
if (isNumbersOrText(c.data)) {
  const d = c.data;
  attempt("a class's any field", () => String(total(d)));
}
if (isNumbersOrText(c.other)) {
  const d = c.other;
  attempt("a class's unknown field", () => String(total(d)));
}
const i: I = { data: JSON.parse("[1, 2, 3.5]") };
if (isNumbersOrText(i.data)) {
  const d = i.data;
  attempt("an interface's unknown field", () => String(total(d)));
}
const arr: unknown[] = [JSON.parse("[1, 2, 3.5]")];
if (isNumbersOrText(arr[0])) {
  const d = arr[0];
  attempt("an unknown[] element", () => String(total(d)));
}
const tup: [unknown, number] = [JSON.parse("[1, 2, 3.5]"), 1];
if (isNumbersOrText(tup[0])) {
  const d = tup[0];
  attempt("a tuple's unknown element", () => String(total(d)));
}
const rec: Record<string, unknown> = { k: JSON.parse("[1, 2, 3.5]") };
if (isNumbersOrText(rec.k)) {
  const d = rec.k;
  attempt("a record's unknown value", () => String(total(d)));
}
function fromParam(p: { v: unknown }): string {
  if (isNumbersOrText(p.v)) {
    return String(total(p.v));
  }
  return "no";
}
attempt("a parameter's unknown field", () => fromParam({ v: JSON.parse("[1, 2, 3.5]") }));
