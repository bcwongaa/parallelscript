// Honest objects given statically to a union whose covering member declares wider nested types.
type C = { kind: "c"; inner: { n: number | string } } | { kind: "none" };
type B = { kind: "b"; f?: (x: number, y: number) => number } | { kind: "none" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const c = { kind: "c" as const, inner: { n: 5 } };
attempt("nested wider, statically", () => {
  const s: C = c;
  return s.kind === "c" ? String(s.inner.n) : "none";
});
const b = { kind: "b" as const, f: (x: number) => x * 3 };
attempt("optional callback, statically", () => {
  const s: B = b;
  return s.kind === "b" ? String(s.f?.(2, 3)) : "none";
});
