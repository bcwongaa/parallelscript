type M<T> = { readonly tag: "maybe"; readonly value?: T; readonly xs: T[] } | { readonly tag: "none" };
const Ops = {
  present<T>(x: T | undefined): M<T> {
    return { tag: "maybe", value: x, xs: [] };
  },
  absent<T>(): M<T> {
    return { tag: "maybe", xs: [] };
  },
};
const a = Ops["present"]<number>(undefined);
const b = Ops["absent"]<number>();
const c = Ops["present"]<number>(3);
for (const o of [a, b, c]) {
  if (o.tag === "maybe") {
    console.log("value" in o, o.value, Object.keys(o).join(","), JSON.stringify(o));
  }
}
