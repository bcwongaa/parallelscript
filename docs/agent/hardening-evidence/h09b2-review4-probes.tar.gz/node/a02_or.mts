interface ListerA {
  list<T>(x: T): T[] | undefined;
  a(): number;
}
interface ListerB {
  list<T>(x: T): T[] | undefined;
  b(): number;
}
class LA implements ListerA {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  a(): number {
    return 1;
  }
}
class LB implements ListerB {
  list<T>(x: T): T[] | undefined {
    return [x];
  }
  b(): number {
    return 2;
  }
}
function pick(n: number): ListerA | ListerB {
  return n === 0 ? new LA() : new LB();
}
const seven: any = 7;
const xs: number[] | undefined = pick(0).list<number>(seven) || undefined;
console.log(xs![0] * 2, xs);
const ys = pick(0).list<number>(seven) || [1];
console.log(ys[0] * 2, ys);
const zs = pick(0).list<number>(seven) ?? [1];
console.log(zs[0] * 2, zs);
const s: any = "str";
const ws = pick(0).list<number>(s) || [1];
console.log(ws[0] * 2);
