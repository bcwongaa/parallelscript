// Other ways to read and write an object kept as a covering member that sites read converted
// (a number field where number | string goes; an i32 field where number goes).
type Val = { kind: "v"; v: number | string; n: number } | { kind: "none" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
async function later<T>(x: T): Promise<T> {
  return x;
}
async function main(): Promise<void> {
  const o = { kind: "v" as const, v: 5, n: 2 as i32 };
  const s: Val = await later<Val>(o as any);
  attempt("kept", () => String((s as any) === (o as any)));
  if (s.kind !== "v") return;
  attempt("element access", () => String(s["v"]) + " " + String(s["n"] * 2));
  const key: "v" | "n" = Math.random() < 2 ? "v" : "n";
  attempt("union key", () => String(s[key]));
  attempt("destructuring", () => {
    const { v, n } = s;
    return String(v) + " " + String(n * 2);
  });
  attempt("compound number", () => {
    s.n += 1.5;
    return String(s.n) + " " + String(o.n);
  });
  attempt("increment", () => {
    s.n++;
    return String(s.n) + " " + String(o.n);
  });
  attempt("optional chain", () => String((s as Val | undefined)?.kind));
  attempt("logged", () => JSON.stringify(s));
}
main();
