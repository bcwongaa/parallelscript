// Honest class instances held as a union of object types, coming back through routes whose
// dynamic values the lowering now converts with a check (await, a generator, reduce, then):
// they must stay the same objects.
interface Animal {
  name: string;
}
class Dog implements Animal {
  constructor(public name: string) {}
}
class Pack {
  readonly kind = "pack" as const;
  constructor(public members: Dog[]) {}
}
class Loose {
  readonly kind = "pack" as const;
  constructor(public members: any[]) {}
}
type Group = { kind: "pack"; members: Animal[] } | { kind: "empty" };
function same(x: any, y: any): boolean {
  return x === y;
}
const pack = new Pack([new Dog("rex")]);
const loose = new Loose([new Dog("max")]);
async function later(g: Group): Promise<Group> {
  return g;
}
function* gen(g: Group): Generator<Group> {
  yield g;
}
async function main(): Promise<void> {
  const a: Group = await later(pack);
  console.log("await keeps", same(a, pack), a instanceof Pack);
  for (const g of gen(pack)) {
    console.log("generator keeps", same(g, pack), g instanceof Pack);
  }
  const groups: Group[] = [pack, { kind: "empty" }];
  const r: Group = groups.reduce((x, y) => (x.kind === "pack" ? x : y));
  console.log("reduce keeps", same(r, pack));
  const t: Group = await later(pack).then((g) => g);
  console.log("then keeps", same(t, pack));
  const l: Group = await later(loose);
  console.log("await, any[] members", same(l, loose), l instanceof Loose);
}
main();
