function isTexts(x: unknown): x is string[] | number {
  return typeof x === "number" || Array.isArray(x);
}
const data: unknown = JSON.parse("[1, 2]");
try {
  if (isTexts(data)) {
    const d = data;
    if (typeof d !== "number") {
      console.log("length of the first", d[0].length);
    }
  }
} catch (e: any) {
  console.log(e.name);
}
console.log("done");
