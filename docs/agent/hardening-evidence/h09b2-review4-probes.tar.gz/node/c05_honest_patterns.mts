// Honest typed objects (no any) given to unions of object types: identity and aliasing.
function same(x: any, y: any): boolean {
  return x === y;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
class Pt {
  constructor(public x: number, public y: number) {}
}
type Shape = { kind: "pt"; at: { x: number; y: number } } | { kind: "none" };
attempt("a class instance where an object type goes", () => {
  const o = { kind: "pt" as const, at: new Pt(1, 2) };
  const s: Shape = o;
  o.at = new Pt(3, 4);
  return String(same(s, o)) + " " + (s.kind === "pt" ? String(s.at.x) : "none");
});
type Val = { kind: "v"; v: number | string } | { kind: "none" };
attempt("a narrower property type", () => {
  const o = { kind: "v" as const, v: 5 };
  const s: Val = o;
  o.v = 6;
  return String(same(s, o)) + " " + (s.kind === "v" ? String(s.v) : "none");
});
type Opt = { kind: "o"; v?: number } | { kind: "none" };
attempt("a required property where an optional goes", () => {
  const o = { kind: "o" as const, v: 5 };
  const s: Opt = o;
  o.v = 6;
  return String(same(s, o)) + " " + (s.kind === "o" ? String(s.v) : "none");
});
type Cb = { kind: "cb"; f: (a: number, b: number) => number } | { kind: "none" };
attempt("a callback taking fewer parameters", () => {
  const o = { kind: "cb" as const, f: (a: number) => a * 2 };
  const s: Cb = o;
  return String(same(s, o)) + " " + (s.kind === "cb" ? String(s.f(3, 4)) : "none");
});
type Ro = { kind: "ro"; xs: readonly number[] } | { kind: "none" };
attempt("a mutable array where a readonly one goes", () => {
  const o = { kind: "ro" as const, xs: [1] };
  const s: Ro = o;
  o.xs.push(2);
  return String(same(s, o)) + " " + (s.kind === "ro" ? String(s.xs.length) : "none");
});
type Nest = { kind: "n"; inner: { a: number } } | { kind: "none" };
attempt("a wider nested object", () => {
  const o = { kind: "n" as const, inner: { a: 1, b: 2 } };
  const s: Nest = o;
  o.inner.a = 5;
  return String(same(s, o)) + " " + (s.kind === "n" ? String(s.inner.a) : "none");
});
