// A guard that lies (its check is too weak): typed code must throw or carry on, never crash.
function isTexts(x: unknown): x is string[] | number {
  return typeof x === "number" || Array.isArray(x);
}
class C {
  data: unknown = JSON.parse("[1, 2]");
}
const c = new C();
if (isTexts(c.data)) {
  const d = c.data;
  if (typeof d !== "number") {
    console.log("length of the first", d[0].length);
  }
}
console.log("done");
