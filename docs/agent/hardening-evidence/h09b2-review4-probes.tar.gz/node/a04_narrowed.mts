function isNumbersOrText(x: unknown): x is number[] | string {
  return typeof x === "string" || (Array.isArray(x) && x.every((e) => typeof e === "number"));
}
function total(v: number[] | string): number {
  if (typeof v === "string") {
    return v.length;
  }
  let sum = 0;
  for (const n of v) {
    sum += n;
  }
  return sum;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const flag = Math.random() < 2;
const data: unknown = JSON.parse("[1, 2, 3.5]");
const obj: any = JSON.parse('{"xs": [1, 2, 3.5]}');
if (isNumbersOrText(data)) {
  attempt("or", () => String(total(data || "x")));
  attempt("comma", () => String(total((console.log("c"), data))));
  attempt("conditional", () => String(total(flag ? data : "x")));
  attempt("nullish", () => String(total(data ?? "x")));
  attempt("closure", () => {
    const f = (): number => total(data);
    return String(f());
  });
  attempt("array literal", () => {
    const all: (number[] | string)[] = [data];
    return String(total(all[0]));
  });
}
if (isNumbersOrText(obj.xs)) {
  attempt("member", () => String(total(obj.xs)));
  attempt("member or", () => String(total(obj.xs || "x")));
}
const m = new Map<string, unknown>([["k", JSON.parse("[1, 2.5]")]]);
const got = m.get("k");
if (isNumbersOrText(got)) {
  attempt("a map's unknown", () => String(total(got)));
}
const arr: unknown[] = [JSON.parse("[1, 2.5]")];
const el = arr[0];
if (isNumbersOrText(el)) {
  attempt("an unknown[] element", () => String(total(el)));
}
if (isNumbersOrText(arr[0])) {
  attempt("an unknown[] element narrowed in place", () => String(total(arr[0] as number[] | string)));
}
