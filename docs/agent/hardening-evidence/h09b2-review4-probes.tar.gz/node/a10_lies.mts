// Lies through any into erased copies' objects of many kinds, read typed through a union.
class Pt {
  constructor(public x: number) {}
}
type S<T> =
  | { readonly tag: "pair"; readonly value: [T, T] }
  | { readonly tag: "nested"; readonly value: { n: T } }
  | { readonly tag: "keyed"; readonly value: Record<string, T> }
  | { readonly tag: "lazy"; readonly value: () => T }
  | { readonly tag: "maybe"; readonly value?: T }
  | { readonly tag: "getter"; readonly value: T }
  | { readonly tag: "map"; readonly value: Map<string, T> }
  | { readonly tag: "set"; readonly value: Set<T> }
  | { readonly tag: "none" };
const Ops = {
  pair<T>(x: T): S<T> {
    return { tag: "pair", value: [x, x] };
  },
  nested<T>(x: T): S<T> {
    return { tag: "nested", value: { n: x } };
  },
  keyed<T>(x: T): S<T> {
    return { tag: "keyed", value: { k: x } };
  },
  lazy<T>(x: T): S<T> {
    return { tag: "lazy", value: () => x };
  },
  maybe<T>(x: T): S<T> {
    return { tag: "maybe", value: x };
  },
  getter<T>(x: T): S<T> {
    return {
      tag: "getter",
      get value() {
        return x;
      },
    };
  },
  map<T>(x: T): S<T> {
    return { tag: "map", value: new Map([["k", x]]) };
  },
  set<T>(x: T): S<T> {
    return { tag: "set", value: new Set([x]) };
  },
};
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name);
  }
}
function str(s: S<string>): string {
  switch (s.tag) {
    case "pair":
      return String(s.value[0].length);
    case "nested":
      return String(s.value.n.length);
    case "keyed":
      return String(s.value["k"].length);
    case "lazy":
      return String(s.value().length);
    case "maybe":
      return String(s.value?.length);
    case "getter":
      return String(s.value.length);
    case "map":
      return String(s.value.get("k")!.length);
    case "set":
      return String([...s.value][0].length);
    default:
      return "none";
  }
}
function pt(s: S<Pt>): string {
  switch (s.tag) {
    case "pair":
      return String(s.value[0].x);
    case "nested":
      return String(s.value.n.x);
    case "keyed":
      return String(s.value["k"].x);
    case "lazy":
      return String(s.value().x);
    case "maybe":
      return String(s.value?.x);
    case "getter":
      return String(s.value.x);
    case "map":
      return String(s.value.get("k")!.x);
    case "set":
      return String([...s.value][0].x);
    default:
      return "none";
  }
}
const n: any = 7;
for (const k of ["pair", "nested", "keyed", "lazy", "maybe", "getter", "map", "set"]) {
  attempt("string " + k, () => str((Ops as any)[k](n)));
  attempt("Pt " + k, () => pt((Ops as any)[k](n)));
}
attempt("string pair (typed call)", () => str(Ops.pair<string>(n)));
attempt("Pt nested (typed call)", () => pt(Ops.nested<Pt>(n)));
attempt("Pt getter (typed call)", () => pt(Ops.getter<Pt>(n)));
attempt("Pt maybe (typed call)", () => pt(Ops.maybe<Pt>(n)));
attempt("Pt lazy (typed call)", () => pt(Ops.lazy<Pt>(n)));
attempt("Pt set (typed call)", () => pt(Ops.set<Pt>(n)));
attempt("string map (typed call)", () => str(Ops.map<string>(n)));
console.log("done");
