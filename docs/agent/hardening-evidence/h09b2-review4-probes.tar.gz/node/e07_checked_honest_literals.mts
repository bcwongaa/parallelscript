// c05's honest patterns, coming back through await: identity must stay.
function same(x: any, y: any): boolean {
  return x === y;
}
type Val = { kind: "v"; v: number | string } | { kind: "none" };
type Cb = { kind: "cb"; f: (a: number, b: number) => number } | { kind: "none" };
async function later<T>(x: T): Promise<T> {
  return x;
}
async function main(): Promise<void> {
  const o = { kind: "v" as const, v: 5 };
  const s: Val = await later<Val>(o);
  o.v = 6;
  console.log("a narrower property type", same(s, o), s.kind === "v" ? s.v : "none");
  const c = { kind: "cb" as const, f: (a: number) => a * 2 };
  const t: Cb = await later<Cb>(c);
  console.log("a callback taking fewer parameters", same(t, c));
  const direct: Val = o;
  console.log("statically", same(direct, o));
}
main();
