// A type-guard callback narrows an unknown[]'s (or any[]'s) elements: find/findLast/filter
// results that tsc types with the guard's type.
function isNumbersOrText(x: unknown): x is number[] | string {
  return typeof x === "string" || (Array.isArray(x) && x.every((e) => typeof e === "number"));
}
function isNumbers(x: unknown): x is number[] {
  return Array.isArray(x) && x.every((e) => typeof e === "number");
}
function total(v: number[] | string | undefined): number {
  if (v === undefined) {
    return -1;
  }
  if (typeof v === "string") {
    return v.length;
  }
  let sum = 0;
  for (const n of v) {
    sum += n;
  }
  return sum;
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const arr: unknown[] = JSON.parse('[true, [1, 2, 3.5]]');
const anyArr: any[] = JSON.parse('[true, [1, 2, 3.5]]');
attempt("find on unknown[]", () => String(total(arr.find(isNumbersOrText))));
attempt("findLast on unknown[]", () => String(total(arr.findLast(isNumbersOrText))));
attempt("find on any[]", () => String(total(anyArr.find(isNumbersOrText))));
attempt("find into a variable", () => {
  const v = arr.find(isNumbersOrText);
  return String(total(v));
});
attempt("find, arrow guard", () => String(total(arr.find((x): x is number[] | string => isNumbersOrText(x)))));
attempt("find, array-only guard", () => {
  const v: number[] | undefined = arr.find(isNumbers);
  return v === undefined ? "none" : String(v[2] * 2);
});
attempt("filter on unknown[]", () => {
  const vs = arr.filter(isNumbers);
  return String(vs[0][2] * 2);
});
