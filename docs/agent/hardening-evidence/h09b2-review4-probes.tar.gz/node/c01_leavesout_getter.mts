// leavesOut's dynamic conversion where the other member is an object literal's type with a getter.
const lazy = {
  kind: "lazy" as const,
  get value(): number {
    return 1;
  },
};
type U = typeof lazy | { kind: "none" };
const loose: { kind: "lazy"; value: any } = { kind: "lazy", value: 5 };
const u: U = loose;
console.log(u.kind, u);
const u2: U = lazy;
console.log(u2.kind === "lazy" ? u2.value : 0);
