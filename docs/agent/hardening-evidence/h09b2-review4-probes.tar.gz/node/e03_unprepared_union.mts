// Narrowed unknown values going into unions that dynamic data can't convert to yet
// (prepareDynamicTarget fails): they still take the unchecked ToUnion.
const lazy = {
  kind: "lazy" as const,
  get value(): number {
    return 1;
  },
};
type L = typeof lazy | number[];
function isL(x: unknown): x is L {
  return Array.isArray(x) || (typeof x === "object" && x !== null && "kind" in x);
}
function isG(x: unknown): x is number[] | Generator<number> {
  return Array.isArray(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const data: unknown = JSON.parse("[1, 2.5]");
if (isL(data)) {
  attempt("a getter literal's type in the union", () => {
    const v: L = data;
    return Array.isArray(v) ? String(v[1] * 2) : String(v.value);
  });
}
if (isG(data)) {
  attempt("a generator in the union", () => {
    const v: number[] | Generator<number> = data;
    return Array.isArray(v) ? String(v[1] * 2) : "gen";
  });
}
