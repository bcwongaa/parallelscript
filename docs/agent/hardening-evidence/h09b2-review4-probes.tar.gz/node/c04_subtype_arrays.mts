// Typed code's own objects whose array property holds a subtype's elements (Dog[] where a
// member says Animal[]) given to a union of object types.
interface Animal {
  name: string;
}
class Dog implements Animal {
  constructor(public name: string) {}
  bark(): string {
    return this.name + "!";
  }
}
type Pack = { kind: "pack"; members: Animal[] } | { kind: "empty" };
function same(x: any, y: any): boolean {
  return x === y;
}
const dogs: Dog[] = [new Dog("rex")];
const p = { kind: "pack" as const, members: dogs };
const u: Pack = p;
dogs.push(new Dog("fido"));
console.log("same object", same(u, p));
console.log("sees the push", u.kind === "pack" ? u.members.length : -1);
if (u.kind === "pack") {
  u.members.push({ name: "cat" });
}
console.log("typed side's push seen", p.members.length);
class Holder {
  constructor(public members: Dog[]) {}
  kind = "pack" as const;
}
const h = new Holder(dogs);
const u2: Pack = h;
console.log("class instance kept", same(u2, h));
