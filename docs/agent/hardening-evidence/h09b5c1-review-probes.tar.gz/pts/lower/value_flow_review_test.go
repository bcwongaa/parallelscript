package lower

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"github.com/microsoft/typescript-go/internal/ast"
)

func reviewExpressionNames(l *lowerer, name string) []*ast.Node {
	var result []*ast.Node
	var visit ast.Visitor
	visit = func(n *ast.Node) bool {
		if n.Kind == ast.KindExpressionStatement && n.Expression().Kind == ast.KindIdentifier && n.Expression().Text() == name {
			result = append(result, n.Expression())
		}
		n.ForEachChild(visit)
		return false
	}
	for _, file := range l.valueFlow.files {
		file.AsNode().ForEachChild(visit)
	}
	return result
}

func TestReviewShorthandDefaultEscapesConsumer(t *testing.T) {
	l, probe := valueFlowProbe(t, `const a = (): void => {};
const b = (): void => {};
function consume(probe: () => void): void { probe; }
consume(a);
let alias: (f: () => void) => void = (_f: () => void): void => {};
const options: { alias?: (f: () => void) => void } = {};
({alias = consume} = options);
alias(b);
`)
	steps := maxValueFlowSteps
	sources := l.valueSources(probe, &steps, 0)
	if sources != nil {
		t.Fatalf("consumer escapes via shorthand-assignment default; want unknown, got %d known sources", len(sources))
	}
}

func TestReviewBudgetDoesNotPoisonShortSharedProof(t *testing.T) {
	var src strings.Builder
	src.WriteString("const origin = (): void => {}; const shared = origin; const alias0 = shared;\n")
	for i := 1; i < maxValueFlowDepth-3; i++ {
		fmt.Fprintf(&src, "const alias%d = alias%d;\n", i, i-1)
	}
	fmt.Fprintf(&src, "const probe = alias%d; probe; const shortProbe = shared; shortProbe;\n", maxValueFlowDepth-4)
	l, long := valueFlowProbe(t, src.String())
	short := reviewExpressionNames(l, "shortProbe")[0]
	steps := maxValueFlowSteps
	if l.valueSources(long, &steps, 0) != nil {
		t.Fatal("expected long chain to exhaust depth")
	}
	steps = maxValueFlowSteps
	got := l.valueSources(short, &steps, 0)
	fresh, _ := valueFlowProbe(t, src.String())
	freshShort := reviewExpressionNames(fresh, "shortProbe")[0]
	steps = maxValueFlowSteps
	want := fresh.valueSources(freshShort, &steps, 0)
	if got == nil && want != nil {
		t.Fatalf("long proof cached context-dependent unknown: short proof gives nil after long proof, %d source(s) with fresh cache", len(want))
	}
}

func TestReviewParameterJoinsBypassBudget(t *testing.T) {
	for _, n := range []int{500, 1000, 2000, 4000} {
		t.Run(fmt.Sprint(n), func(t *testing.T) {
			var src strings.Builder
			src.WriteString("const origin = (): void => {}; function consume(probe: () => void): void {\n")
			for range n {
				src.WriteString("probe;\n")
			}
			src.WriteString("}\n")
			for range n {
				src.WriteString("consume(origin);\n")
			}
			l, _ := valueFlowProbe(t, src.String())
			probes := reviewExpressionNames(l, "probe")
			parameter := l.target(probes[0]).ValueDeclaration
			for _, call := range l.functionValueUses(l.target(parameter.Parent.Name())).calls {
				steps := maxValueFlowSteps
				if l.valueSources(call.Arguments.Nodes[0], &steps, 0) == nil {
					t.Fatal("argument warmup unexpectedly unknown")
				}
			}
			steps := maxValueFlowSteps
			if l.valueSources(probes[0], &steps, 0) == nil {
				t.Fatalf("first proof unexpectedly unknown at %d callers", n)
			}
			start := time.Now()
			for _, probe := range probes[1:] {
				steps = maxValueFlowSteps
				if l.valueSources(probe, &steps, 0) == nil {
					t.Fatal("cached callers unexpectedly unknown")
				}
				if steps != maxValueFlowSteps-1 {
					t.Fatalf("want only root charged despite %d joins, remaining=%d", n, steps)
				}
			}
			t.Logf("%d callers, %d further distinct parameter reads: %s; 1/%d steps charged per read", n, len(probes)-1, time.Since(start), maxValueFlowSteps)
		})
	}
}
