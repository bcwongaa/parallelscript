from pathlib import Path
import os
import shutil
import subprocess
import sys

root = Path('/home/bryan/projects/parallelscript/.claude/worktrees/agent-abf1391354a0f7c8d')
child = Path('/home/bryan/projects/parallelscript/.claude/worktrees/h09b5c1-reproducer/pts/tests/run')
scratch = root / 'review-c1-probes'
env = os.environ.copy()
env.update(PTS_HOME='/home/bryan/projects/parallelscript', GOMAXPROCS='1')
cli = root / 'pts-bin/pts'
node = Path('/home/bryan/.local/node/bin/node')
failures = 0
for name in ['generic_value_flow_expression_sources', 'generic_value_flow_unknown_origins', 'generic_value_flow_unknown_parameters']:
    source = scratch / (name + '.pts')
    twin = source.with_suffix('.mts')
    shutil.copyfile(child / source.name, source)
    shutil.copyfile(source, twin)
    native = subprocess.run([str(cli), 'run', str(source)], cwd=root, env=env, capture_output=True, timeout=120)
    oracle = subprocess.run([str(node), '--experimental-transform-types', '--disable-warning=ExperimentalWarning', str(twin)], cwd=root, env=env, capture_output=True, timeout=30)
    for label, result in [('native', native), ('node', oracle)]:
        (scratch / (name + '.' + label + '.out')).write_bytes(result.stdout)
        (scratch / (name + '.' + label + '.err')).write_bytes(result.stderr)
    good = native.returncode == oracle.returncode == 0 and native.stdout == oracle.stdout
    print(f'{name}: native={native.returncode} node={oracle.returncode} equal={native.stdout == oracle.stdout}', flush=True)
    if not good:
        failures += 1
        print(native.stderr.decode(errors='replace'), flush=True)
sys.exit(1 if failures else 0)
