class Box<T> {
  constructor(public value: T) {}
}
type Factory = <T>(x: T) => Box<T>;
const a = <T>(x: T): Box<T> => new Box(x);
const b = <T>(x: T): Box<T> => new Box(x);
function use(f: Factory): number {
  const box: Box<number> = f(42);
  return box.value;
}
console.log(use(a));
let alias: (f: Factory) => number = (_f: Factory): number => 0;
const optionsWithoutAlias: { alias?: (f: Factory) => number } = {};
({alias = use} = optionsWithoutAlias);
console.log(alias(b));
