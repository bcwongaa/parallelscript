# H03b review probes and benchmark programs

The host rebooted between H03b's third and fourth parent sessions (2026-10-16), and /tmp,
which held the probes of review rounds 1–3, the parent's probes and the benchmark programs,
was wiped before they were archived. Session 4 rebuilt these files from the session
transcripts (`~/.claude/projects/-home-bryan-projects-parallelscript/`: parent sessions
0792352a…, 711a2a1f…, 72b63c9e… and their opus-reviewer subagents) with
`tools/recover.py`: every Write and Edit tool call, and every Bash heredoc
(`cat > path <<'EOF'`), whose target was under /tmp/pts-h03b*, replayed in timestamp order,
relative heredoc paths resolved against the last `cd /tmp/pts-h03b…` before them in the same
command. `RECOVERY_LOG.tsv` lists each replayed write.

Not recovered: files made by `cp`, `sed`, compilers or test runs (binaries, outputs,
callgrind logs, the reviewers' copies of repo tests), and anything written another way.
The done-first benchmark variants (`b3d_…`, `b4d_…`) and the 1M-step versions were made by
`sed` from the recovered originals; session 4 remade them with the same `sed` commands
(in `/tmp/pts-h03b-s4/bench`, archived under `session4/bench/`).

The review texts themselves are kept verbatim in `../h03b-review.md`.

## Layout

- `tmp/pts-h03b*/`: the rebuilt files of sessions 1–3 and review rounds 1–3 (`pts-h03b-review/` is round 1,
  `-review2/` round 2, `-review3/` round 3, `-review4/` the first, unfinished round 4 of session 3;
  `pts-h03b/`, `-s2/`, `-s3/` the parent's), at their original paths.
- `tools/`: `recover.py` and `survey.py`, which rebuilt them.
- `round4/`: review round 4 (session 4, `/tmp/pts-h03b-review4b`) as it was: the reviewer's probes (`p/`), their
  outputs (`out/`), the emitted C it cites, its sanitizer runs' logs, test runs (`tests/`), benchmark programs and
  summaries (`bench/`), scripts and `REVIEW.md`; no binaries, caches or the base worktree.
- `round5/`: review round 5 (`/tmp/pts-h03b-review5`), the same way.
- `session4/`: the parent's session-4 files: the benchmark programs (remade from the rebuilt originals), `run_cg.sh`
  and its two summaries (`summary.txt`, the starting tree; `summary-final.txt`, the final tree), `r4/`, round 4's
  RED and GREEN runs, and `r5/`, round 5's probes and their runs on the final tree.

Callgrind profiles other than `out/cg_noas.out` (the one REVIEW.md annotates) were left out for size.
