## Round 5: H03b, confirmation of the round-4 fixes (readKeptAndStore, pts_result_get_slow, interfaceCast, docs)

Reviewer: opus-reviewer (claude-opus-5-5, xhigh), read-only, 2026-10-16. Tree: the parent's uncommitted working tree on `a65a75d62`. The last code mtime is `pts/lower/objects.go` at 20:58:48. Review CLI: `/tmp/pts-h03b-review5/pts`, built with `GOMAXPROCS=2 go build -p 2 -o /tmp/pts-h03b-review5/pts ./cmd/pts` and run with `PTS_HOME=/home/bryan/projects/parallelscript`. Base CLI: `/tmp/pts-h03b-s4/base/pts-bin/pts` (`a65a75d62`). Node v24.21.0. I changed nothing in the repository: `git status` shows only the parent's files. Scratch: `/tmp/pts-h03b-review5/` (`p/` probes, `out/` outputs, `run.sh` prints Node, then the tree, then the base).

## Verdict: NOT READY (one small SHOULD-FIX performance regression, new in change 2; everything else confirmed)

- Both round-4 defects are fixed, pinned, and match Node in every variant I tried.
- Change 1 (`readKeptAndStore` always uses the kept read) is safe. I tried 14 probe files covering every place kind, with `yield` and with `await`. None regressed against the base: no new PTS1001, no clang error, no panic, no new wrong output.
- The slice tests, the D-145 subset, `TestErrors` and the `pts/lower` and `pts/cgen` unit tests are all green.
- The suite receipt is now from the final code.

One problem remains. Change 2's fallback allocates a key string and does a full dynamic lookup on every slow-path read. A valid typed iterator whose results omit `done` now runs 2.7× the instructions of the base (and of the round-4 tree), with one GC allocation per read. The fix is cheap (below). If the parent prefers to keep the code, D-O15 makes benchmarks non-gating, so recording the cost as a known gap in D-178 would also close it.

## Ranked findings

1. **SHOULD-FIX (regression, performance, new in change 2):** `pts_result_get_slow`'s fallback calls `pts_string_from_cstr(name)` and then `pts_dynamic_get` on every read of a property that an object of another layout lacks.
   - Example: `r.done` on a hand-written `{ value: x }` result. This is valid TS, because `IteratorYieldResult.done` is optional. The type is `IteratorResult<number, undefined>`.
   - Cost: 2M reads take 1,212,981,392 instructions, against 445,182,914 on the base (2.72×) and 455,177,655 with the round-4 fallback emulated (2.67×).
2. **NOTE (pre-existing, D-145/C08 family, not in the ledger by name):** `arr[i++] -= yield 1` (and `+= await`) evaluates the index's `i++` twice and writes the wrong element. Node gives `i 1 95,200,300`; PTS gives `i 2 100,95,300`, and so does the base.
3. **NOTE (verified documented behaviour):** a class method read by name through a result is bound, as through `any` (D-144, D-178). `const m = t.value; m()` returns 9 where Node throws a TypeError. The base does the same through `any`.
4. **NOTE (verified documented gap):** a result without `done` reads `done` as `false` through a one-shape type (`IteratorResult<number, number>`) and as `undefined` through a union type. Both match D-178 and the SPEC text.

---

## 1. SHOULD-FIX (regression, performance): the by-name fallback allocates per read

- **Repro:** `/tmp/pts-h03b-review5/p/perf_nodone_noas.pts`
  ```ts
  class Counter {
    i = 0;
    next(): IteratorResult<number, undefined> {
      if (this.i >= 2000000) return { done: true, value: undefined };
      return { value: this.i++ };
    }
  }
  const c = new Counter();
  let sum = 0;
  for (;;) {
    const r = c.next();
    if (r.done) break;
    sum += r.value;
  }
  console.log("nodone", sum);
  ```
- **Output:** `nodone 1999999000000` on all three builds, so it is correct everywhere.
- **Instruction counts** (`PTS_THREADS=1 valgrind --tool=callgrind`):

  | Build | Instructions |
  |---|---|
  | Base (`perf_nodone_noas_base`) | 445,182,914 |
  | Tree (`perf_nodone_noas`) | **1,212,981,392** |
  | Tree runtime with the round-4 fallback emulated (`home-r4obj`: `return PTS_VALUE_UNDEFINED` for `PTS_KIND_OBJECT`) | 455,177,655 |
  | Tree runtime with static `"done"`/`"value"` keys only (`home-static`) | 789,162,917 |

  The same program with `as IteratorYieldResult<number>` (`perf_nodone.pts`) gives 1,212,980,950 on the tree and 445,183,764 on the base. With `done: false` written (`perf_withdone.pts`), the tree is faster than the base: 503,178,380 against 671,182,832.
- **Profile** (`callgrind_annotate --inclusive=yes out/cg_noas.out`):
  - `pts_result_get_slow`: 878,575,296 inclusive, about 439 instructions a read.
  - Of that, `pts_string_from_cstr` is 462,574,477 and `pts_string_from_utf8` is 418,573,708.
  - Self cost also includes `GC_malloc_kind` 104M, `object_get` 108M and `strcmp` 80M.
  - So 2M reads produce 2M garbage strings.
- **Cause:** `pts/runtime/src/object.c` (`pts_result_get_slow`, last line):
  ```c
  return pts_dynamic_get(pts_value_from_object((pts_object *)object), pts_value_from_string(pts_string_from_cstr(name)));
  ```
  `result_done` and `handed_value` in `generator.c`, which h03b.md cites as the model, use `PTS_STATIC_STRING` keys. Before change 2, a `PTS_KIND_OBJECT` without the field or getter returned undefined at once.
- **Fix suggestion:**
  - For `PTS_KIND_OBJECT`, fall back to `pts_dynamic_get` only when `method_index(type, name, PTS_METHOD) >= 0`, and otherwise return `PTS_VALUE_UNDEFINED`. Inherited methods must be in the subclass's table; my `m1_methods.pts` shows inherited getters are found that way, but check methods with the same probe.
  - Use `PTS_STATIC_STRING` keys for `"done"` and `"value"`, which are the only names the compiler passes.
  - Pin it with a callgrind-style check or a benchmark row in h03b.md, or record the cost in D-178's known gaps.

## 2. NOTE (pre-existing): a compound target's index with side effects is evaluated twice across a suspension

- **Repro:** `/tmp/pts-h03b-review5/p/n1_index_update_twice.pts` (`arr[i++] -= yield 1;` in a generator, `arr[j++] += await Promise.resolve(1);` in an async function).
- **Output:**
  - Node: `gen i 1 95,200,300` / `async j 1 101,200,300`
  - Tree: `gen i 2 100,95,300` / `async j 2 100,101,300`
  - Base: the same as the tree.
- **Cause:** `keepCurrent` (`yield_expressions.go:384-406`) reads `l.expression(target)` before the yield, and `assignmentTarget` evaluates the index again after the resume. Calls are kept: `box(0)`, `idx(1)` and `key("b")` each logged once in `p/c10_side_effects.pts`. An update expression is not kept.
- This is unchanged by the slice, and it belongs to C08's "key ordering" acceptance, but no ledger row names it. It is a silent wrong write, so it is worth adding to C08 or H08.

## Round-4 findings: status

| # | Round 4 | Now | Evidence |
|---|---|---|---|
| 1 | R2 residual: union-typed value and element access read the getter twice | **Fixed** | Node and tree both print `5x reads 1` for `r2_min_union` and `15 reads 1` for `r2_min_element`; the base gives PTS1001. The controls `r2_union_iface_ctl` and `r2_element_iface_ctl` print `reads 1` (base `reads 2`). `r2_variants` matches Node on 9 of 10 lines; the 10th, `iface`, is D-178's documented copy at the conversion to an interface, and the base also differs from Node there. In `out/r2_min_union.c:328` the resume binds `current_2 = pts_frame->current`, with no second `pts_result_get`. |
| 2 | Methods not found by name | **Fixed** | `s6b_method_any_ctl` and `s6_value_method` match Node. In `m1_methods.pts`, inherited methods, overrides, union types, superclass getters (union and one-shape) and frozen instances all match Node. Missing properties still give undefined: `missing value undefined true`, and through a union type `missing done union undefined 3` (`m2_kinds.pts`). Setter-only properties read undefined (`m3_setter_only.pts`). |
| 3 | Suite receipt predated the fixes | **Fixed** | `h03b-suite.jsonl.gz` events run 2026-10-16T20:59:47 to 21:06:40, after the last code mtime (20:58:48). Recounted: 1381 pass / 256 skip / 0 fail. It is byte-identical to `/tmp/pts-h03b-s4/suite2.jsonl`. The receipt's `cli_sha256` equals `sha256sum pts-bin/pts` (`450ed016…1774`, built 20:59:46). |
| 4 | `b3d` 1.06× | Withdrawn | h03b.md Performance and D-178 ("an earlier 1.06× didn't reproduce"). |
| 5 | h03b.md accuracy | Fixed | It now says "22 records of the 18 tests". The tarball exists (554 entries, including `session4/bench/b3d_user_forof_donefirst.pts` and `summary-final.txt`). No placeholders are left outside round 4's verbatim text. |
| 6, 7, 9 | Ledger | Done | C59, C60, C61 and C57's extension. I re-verified C62's "the same on `a65a75d62`": `p/c62_call_value.pts` gives `calling r.value is not supported yet` on both, where Node prints `call 41`. |
| 8 | Code quality | Done | `isIteratorResultType` and `isIteratorResultUnion` are gone (`grep -rn` finds nothing). `interfaceCast` reports a PTS1001 (`objects.go:918-920`), and `sameType` returns nil when `convertedResult` does (`lower.go:3353`). The `readKeptAndStore` doc now matches the code. The `pts.h` comment and D-178 mention methods. |

## Verified good (evidence)

**Change 1.** I compared Node, the tree and the base with `run.sh`; outputs are in `out/*.txt`. Every probe below matched the base, and also Node except where noted:

| Probe | What it covers | Result |
|---|---|---|
| `c1_arrays` | `a[i] += yield`, `**=`, `string[]` `+=`, `c.length -= yield`, an `int[]` generator with `+= *= <<= /=` | Matches Node, except that `int /=` truncates by design (`3,6,9` against Node's `3,6.4,9`) |
| `c2_typed` | Float64Array, Int32Array and Uint8Array (wrapping) | Matches Node |
| `c3_records` | `rec["a"]`, `rec[k]`, index-signature `m.x` and `m["y"]`, string records | Matches Node |
| `c4_union_narrowed` | Interface `number \| string` narrowed by `typeof` to number and to string, optional `z` narrowed by `!== undefined`, `number \| undefined` | Matches Node. `o.z! += yield` is PTS1001 on both the base and the tree, so I removed that line. |
| `c5_class_nested` | Class fields and strings, a nested `c.inner.b`, an interface's number and string, `o.a.b`, `o.arr[1]` | Matches Node. The array-growing `length +=` throws the same RangeError on the base and the tree (a pre-existing limitation). |
| `c6_logical` | `??=`, `\|\|=`, `&&=` with yield on interfaces and arrays (the other path) | Matches Node |
| `c7_any` | `x.n`, `x["m"]`, `o.a: any`, `x.o.k` | Matches Node |
| `c8_loose` | Loose destructured locals | Matches Node |
| `c9_await` | The same place kinds with `await` in an async function, and `yield`/`await` in an async generator | Matches Node |
| `c11_exotic` | `unknown` narrowed, an `any` field, `string \| string[]` narrowed, tuple elements, a class accessor, a static field, an interface backed by a class getter, a union receiver, `this.f` in a generator method | Matches Node. Improvement: the getter-backed interface logs `get,set9,get` like Node (base `get,get,set9,get`). |
| `c12_results_kinds` | Getter results of `int`, `string`, narrowed `number \| undefined` and `**=`, plus `+= await`/`-= await` on a result and an `IteratorResult<number, number>` | Matches Node; the base gives PTS1001 |
| `c13_left_yield` | Yields on both sides (`a[(yield 1) as number] += yield 2`, `os[…].v *=`, `rec["k" + (yield 5)] -=`) | Matches Node |
| `c14_rec_union` | A `Record<string, number \| undefined>` narrowed by `.k` and by `["j"]`, and `Record<string, int>` | Matches Node |

The emitted C for the union case: `PTS_HOME=… pts emit-c p/r2_min_union.pts -o out/r2_min_union.c`. Line 304 reads once before the yield, through `pts_result_get` and a check. Line 328 binds `current_2 = pts_frame->current` after the resume and computes from `pts_frame->current`, with no second read. `current_2` is an unused local, which is harmless.

**Change 2.** Covered by `m1_methods`, `m2_kinds`, `m2b_kinds_any` and `m3_setter_only`:

- Through `any` into a result union, the tree is the same as the base or closer to Node. Arrays, maps, functions and dates still fail the checked conversion as on the base. An `Error` now reads `undefined undefined` as in Node. A class whose `value` is a method fails the `number | undefined` check because the method is found; that is D-L09's checked cast, not a defect.
- `iterator_results_threads` passes on 1, 2 and 4 threads.
- `pts_dynamic_get` is the same path that `any` reads already use, and the object stays live in the caller's frame, so I see no GC or race concern.

**Change 3.** I found no new PTS1001 from `interfaceCast`. I tried Pick, Partial, intersection, Readonly, `Record<"value", …>` and generic-interface targets (`p/i_*.pts`) with a runtime result and an asserted getter literal:

- Partial now works where the base gave PTS1001.
- The others give the same pre-existing `doesn't provide with the same types` PTS1001 on both builds.
- The new message never appears.

**Tests** (`PTS_REQUIRE_NODE=1`, `-count=1 -p 1 -parallel 2`):

| Run | Result |
|---|---|
| Slice filter `^(iterator\|yield_star\|array_pattern_elision\|any_maps_error\|iterators_through)` | Exit 0; 48 PASS lines / 3 SKIP / 0 FAIL. All 21 slice files ran: the 18 new ones, plus `iterator_next_result_getters`, `iterator_result_as_cast`, `iterator_result_getters_*` and `any_maps_error`. The skips are `TestRunMatchesNode` for `any_maps_error`, `iterator_results_threads` and `iterator_results_copied` (by design). |
| D-145 subset `(yield\|await\|suspen\|compound\|logical_assign)` | Exit 0; 35 PASS / 3 SKIP / 0 FAIL. The skips are `logical_assign_suspensions` (C25, H08) and `TestRunMatchesNode/logical_assign_any_checks`. |
| `^(async_functions\|suspension_snapshots)$` | Pass |
| `^TestErrors$` | Pass (83 subtests) |
| `go test ./pts/lower/... ./pts/cgen/... ./pts/ir/...` and `go vet ./pts/lower/` | ok, clean |

**Docs.** I checked the claims against the code and the evidence:

- h03b.md's round-4 paragraph agrees with the code, the RED records (`round4_records`: 2 records, red on the session-4 starting tree) and my reruns.
- h03b.md's GREEN section: the receipt time window and the CLI sha agree with the files on disk.
- D-178's changed sentences: by-name reads find "a field, a getter, or as through `any` (a class's method, bound…; undefined if there is none)", and the kept read is "converted to the place's type". Both match the code.
- SPEC §9.122 matches the code; the line about the one-shape `done` gap matches `m1_methods`.
- CONSOLIDATED C57 and C59–C62 match the probes.

The one mismatch is in h03b.md's round-4 #2 text: "falls back to `pts_dynamic_get` … as `handed_value` and `result_done` read". Those two use static keys and the new fallback doesn't (finding 1).

## Commands

```sh
# build
cd /home/bryan/projects/parallelscript && GOMAXPROCS=2 go build -p 2 -o /tmp/pts-h03b-review5/pts ./cmd/pts
# differential probes (Node, tree, base)
/tmp/pts-h03b-review5/run.sh /tmp/pts-h03b-review5/p/<probe>.pts
# C of the union case
cd /tmp && PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review5/cache /tmp/pts-h03b-review5/pts emit-c /tmp/pts-h03b-review5/p/r2_min_union.pts -o /tmp/pts-h03b-review5/out/r2_min_union.c
# finding 1: counts (tree, base, emulated round-4 runtime)
cd /tmp && PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review5/cache /tmp/pts-h03b-review5/pts build /tmp/pts-h03b-review5/p/perf_nodone_noas.pts -o /tmp/pts-h03b-review5/out/perf_nodone_noas
cd /tmp && PTS_HOME=/tmp/pts-h03b-s4/base PTS_CACHE_DIR=/tmp/pts-h03b-review5/cache-base /tmp/pts-h03b-s4/base/pts-bin/pts build /tmp/pts-h03b-review5/p/perf_nodone_noas.pts -o /tmp/pts-h03b-review5/out/perf_nodone_noas_base
cd /tmp && PTS_HOME=/tmp/pts-h03b-review5/home-r4obj PTS_CACHE_DIR=/tmp/pts-h03b-review5/cache-r4obj /tmp/pts-h03b-review5/pts build /tmp/pts-h03b-review5/p/perf_nodone_noas.pts -o /tmp/pts-h03b-review5/out/perf_nodone_noas_r4obj
cd /tmp/pts-h03b-review5/out && PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=cg_X.out ./perf_nodone_noas[_base|_r4obj]
callgrind_annotate --inclusive=yes /tmp/pts-h03b-review5/out/cg_noas.out
# (home-r4obj / home-static: symlink copies of pts/runtime with only object.c edited, plus a pts/third_party symlink; the repo is untouched)
# tests
PATH=$HOME/.local/node/bin:$PATH GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -p 1 -parallel 2 -timeout 40m ./pts/tests/ -run '^(TestRun|TestRunMatchesNode)$/^(iterator|yield_star|array_pattern_elision|any_maps_error|iterators_through)' -v   # gotest-slice.log
PATH=$HOME/.local/node/bin:$PATH GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -p 1 -parallel 2 -timeout 40m ./pts/tests/ -run '^(TestRun|TestRunMatchesNode)$/(yield|await|suspen|compound|logical_assign)' -v   # gotest-d145.log
GOMAXPROCS=2 go test -count=1 -p 1 ./pts/tests/ -run '^TestErrors$'
GOMAXPROCS=2 go test -count=1 -p 1 ./pts/lower/... ./pts/cgen/... ./pts/ir/...
# receipt
python3 -I (time range and counts of docs/agent/hardening-evidence/h03b-suite.jsonl.gz); cmp with /tmp/pts-h03b-s4/suite2.jsonl; sha256sum pts-bin/pts
```
