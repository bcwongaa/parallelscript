// Control: element access compound assignment with a yield on its right, on an interface and a class receiver.
let reads = 0;
let v = 5;
interface HV { value: number }
const hv: HV = { get value() { reads++; return v; }, set value(x: number) { v = x; } };
function* g(): Generator<number, void, number> {
  hv["value"] += yield 1;
}
const it = g();
it.next();
it.next(10);
console.log("iface", v, "reads", reads);
