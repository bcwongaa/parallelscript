interface U { u: unknown; a: any; s: string | string[]; t: [number, string] }
class Acc {
  private _v = 1;
  log: string[] = [];
  get v(): number { this.log.push("get"); return this._v; }
  set v(x: number) { this.log.push("set" + x); this._v = x; }
  static st = 5;
  f = 2;
  *gen(): Generator<number, void, number> { this.f += yield 100; }
}
interface HasV { v: number }
function* g(o: U, acc: Acc, hv: HasV, uni: { k: number } | { k: number; z: string }): Generator<number, void, number> {
  if (typeof o.u === "number") o.u += yield 1;
  o.a += yield 2;
  if (typeof o.s === "string") o.s += yield 3;
  o.t[0] += yield 4;
  o.t[1] += yield 5;
  acc.v += yield 6;
  Acc.st -= yield 7;
  hv.v *= yield 8;
  uni.k += yield 9;
  console.log("exotic", JSON.stringify(o), acc.log.join(","), Acc.st, (acc as any)._v, hv.v, JSON.stringify(uni));
}
const acc = new Acc();
const hacc = new Acc();
const it = g({ u: 1, a: 2, s: "s", t: [1, "t"] }, acc, hacc, { k: 1, z: "z" });
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
console.log("hv log", hacc.log.join(","));
const it2 = acc.gen();
it2.next(); it2.next(9);
console.log("this.f", acc.f);
