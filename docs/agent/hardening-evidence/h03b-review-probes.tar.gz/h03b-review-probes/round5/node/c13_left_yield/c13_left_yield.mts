interface O { v: number }
function* g(a: number[], os: O[], rec: Record<string, number>): Generator<number, void, number> {
  a[(yield 1) as number] += yield 2;
  os[(yield 3) as number].v *= yield 4;
  rec["k" + (yield 5)] -= yield 6;
  console.log("left", a.join(","), JSON.stringify(os), JSON.stringify(rec));
}
const it = g([10, 20, 30], [{ v: 1 }, { v: 2 }], { k1: 100, k3: 7 });
let r = it.next();
const sends = [1, 5, 0, 3, 1, 9];
let i = 0;
while (!r.done) { console.log("yielded", r.value); r = it.next(sends[i++]); }
