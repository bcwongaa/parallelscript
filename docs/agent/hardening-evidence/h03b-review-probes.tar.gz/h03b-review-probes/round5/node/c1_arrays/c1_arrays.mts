function* g(): Generator<number, void, number> {
  const a: number[] = [1, 2, 3];
  let i = 1;
  a[i] += yield 10;
  a[i + 1] **= yield 11;
  console.log("num", a.join(","));
  const s: string[] = ["a", "b"];
  s[1] += yield 15;
  console.log("str", s.join(","));
  const c = [1, 2, 3, 4];
  c.length -= (yield 16) - 4;
  console.log("len", c.length, c.join(","));
}
function* gi(): Generator<number, void, int> {
  const b: int[] = [1, 2, 3];
  b[0] += yield 12;
  b[2] *= yield 13;
  b[1] <<= yield 14;
  b[1] /= yield 15;
  console.log("int", b.join(","));
}
const it = g();
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
const it2 = gi();
let r2 = it2.next();
let m: int = 2;
while (!r2.done) { console.log("yielded", r2.value); r2 = it2.next(m++); }
