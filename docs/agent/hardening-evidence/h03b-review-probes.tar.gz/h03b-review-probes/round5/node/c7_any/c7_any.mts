function* g(x: any, o: { a: any }): Generator<number, void, number> {
  x.n += yield 1;
  x["m"] *= yield 2;
  o.a += yield 3;
  x.o.k += yield 4;
  console.log("any", JSON.stringify(x), JSON.stringify(o));
}
const it = g({ n: 1, m: 2, o: { k: 1 } }, { a: 5 });
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
