// A result whose value is a method rather than a field or a getter, read by name.
const lit = { done: false as const, value() { return 41; } } as IteratorYieldResult<() => number>;
console.log("typeof", typeof lit.value);
const f0 = lit.value;
console.log("call", f0 === undefined ? "undefined" : f0());
class E {
  done = false as const;
  value() { return 42; }
}
const fromClass: IteratorResult<() => number, undefined> = new E();
if (!fromClass.done) {
  const f1 = fromClass.value;
  console.log("class", typeof f1, f1 === undefined ? "undefined" : f1());
}
class Tasks implements Iterator<() => number> {
  k = 0;
  next(): IteratorResult<() => number> {
    this.k++;
    if (this.k > 2) return { done: true, value: undefined };
    const n = this.k;
    return { done: false, value() { return n * 100; } };
  }
}
const t = new Tasks();
for (let r = t.next(); !r.done; r = t.next()) { const f = r.value; console.log("task", typeof f); }
for (const f of { [Symbol.iterator]: () => new Tasks() }) console.log("for-of", typeof f, f());
