class Base {
  done = false as const;
  value(): number { return 1; }
  get extra(): string { return "base-extra"; }
}
class Derived extends Base {
  tag = "d";
}
class Mid extends Base {
  value(): number { return 2; }
}
class GetterBase {
  get done(): false { return false; }
  get value(): number { log.push("get value"); return 77; }
}
class GetterDerived extends GetterBase { own = 1; }
const log: string[] = [];

// one-shape result type: IteratorYieldResult<() => number>
const d: IteratorYieldResult<() => number> = new Derived();
const fd = d.value;
console.log("inherited", typeof fd, d.done);
const m: IteratorYieldResult<() => number> = new Mid();
console.log("override", typeof m.value, m.done);

// union result type
const u: IteratorResult<() => number, undefined> = new Derived();
if (!u.done) { const f = u.value; console.log("union inherited", typeof f); }

// superclass getters
const gd: IteratorYieldResult<number> = new GetterDerived();
console.log("super getter", gd.value, gd.done, log.join(","));
const gu: IteratorResult<number, number> = new GetterDerived();
console.log("super getter union", gu.value, gu.done);

// frozen instance
const fz = Object.freeze(new Derived());
const fr: IteratorYieldResult<() => number> = fz;
console.log("frozen", typeof fr.value, fr.done);
const fg = Object.freeze(new GetterDerived());
const frg: IteratorResult<number, undefined> = fg;
console.log("frozen getter", frg.value, frg.done);

// missing properties still give undefined
class NoValue { done = true as const; }
const nv: IteratorResult<number | undefined, number | undefined> = new NoValue() as any as IteratorResult<number | undefined, number | undefined>;
console.log("missing value", nv.value, nv.done);
class NoDone { value = 3; }
const nd = new NoDone() as any as IteratorResult<number, number>;
console.log("missing done", nd.done, nd.value);
const nd2 = new NoDone() as any as IteratorYieldResult<number>;
console.log("missing done one-shape", nd2.done, nd2.value);
