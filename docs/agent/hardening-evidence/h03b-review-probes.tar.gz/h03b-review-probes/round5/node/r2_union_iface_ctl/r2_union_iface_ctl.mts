// Control: a union-typed property on an interface receiver, compound assignment with a yield on its right.
let reads = 0;
let v: number | string = 5;
interface HV { value: number | string }
const hv: HV = { get value(): number | string { reads++; return v; }, set value(x: number | string) { v = x; } };
function* g(): Generator<number, void, string> {
  hv.value += yield 1;
}
const it = g();
it.next();
it.next("x");
console.log("iface", v, "reads", reads);
