class C { x = 1; s = "a"; inner = { b: 5 } }
interface I { x: number; s: string }
interface Outer { a: { b: number }; arr: number[] }
function* g(c: C, i: I, o: Outer): Generator<number, void, number> {
  c.x += yield 1;
  c.s += yield 2;
  c.inner.b -= yield 3;
  i.x *= yield 4;
  i.s += yield 5;
  o.a.b += yield 6;
  o.arr[1] += yield 7;
  o.arr.length += yield 8;
  console.log("c", c.x, c.s, c.inner.b, "i", i.x, i.s, "o", o.a.b, o.arr.join(","), o.arr.length);
}
const c = new C();
const it = g(c, new C(), { a: { b: 1 }, arr: [1, 2] });
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
