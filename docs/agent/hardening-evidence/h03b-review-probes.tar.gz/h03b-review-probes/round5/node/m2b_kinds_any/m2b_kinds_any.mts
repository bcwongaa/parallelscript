class Base { done = false as const; n = 5; value(): number { return 1; } }
function show(label: string, x: any) {
  try {
    const r = x as IteratorResult<number, undefined>;
    console.log(label, r.done, r.value);
  } catch (e) { console.log(label, "threw", (e as Error).message); }
}
show("array", [1, 2]);
show("map", new Map<string, number>());
show("fn", () => 1);
show("date", new Date(0));
show("error", new Error("x"));
show("instance", new Base());
