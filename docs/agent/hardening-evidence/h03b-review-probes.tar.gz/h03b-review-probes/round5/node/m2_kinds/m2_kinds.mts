class Base {
  done = false as const;
  n = 5;
  value(): number { return 1; }
}
class Derived extends Base {}
const d: IteratorYieldResult<() => number> = new Derived();
const f = d.value;
console.log("call", f());
const u: IteratorResult<() => number, undefined> = new Derived();
if (!u.done) { const g = u.value; console.log("union call", g()); }

class NoDone { value = 3; }
const nd = new NoDone() as any as IteratorResult<number, undefined>;
console.log("missing done union", nd.done, nd.value);

function show(label: string, x: any) {
  try {
    const r = x as IteratorResult<number, undefined>;
    console.log(label, r.done, r.value);
  } catch (e) { console.log(label, "threw", (e as Error).message); }
}
show("array", [1, 2]);
show("map", new Map<string, number>());
show("fn", () => 1);
show("date", new Date(0));
show("error", new Error("x"));
show("instance", new Base());
