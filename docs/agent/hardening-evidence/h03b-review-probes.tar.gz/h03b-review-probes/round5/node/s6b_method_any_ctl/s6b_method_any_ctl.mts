// Control: a class's method read through `any`, and a result whose value is a class method, through one shape.
class E {
  done = false as const;
  value() { return 42; }
}
const a: any = new E();
console.log("any", typeof a.value, a.value());
const viaAny = a.value;
console.log("any value read", typeof viaAny);
const one: IteratorYieldResult<() => number> = new E();
const f = one.value;
console.log("one", typeof f);
