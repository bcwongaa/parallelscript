function* g(arr: number[]): Generator<number, void, number> {
  let i = 0;
  arr[i++] -= yield 1;
  console.log("gen i", i, arr.join(","));
}
const it = g([100, 200, 300]);
it.next();
it.next(5);
async function f(arr: number[]) {
  let j = 0;
  arr[j++] += await Promise.resolve(1);
  console.log("async j", j, arr.join(","));
}
f([100, 200, 300]);
