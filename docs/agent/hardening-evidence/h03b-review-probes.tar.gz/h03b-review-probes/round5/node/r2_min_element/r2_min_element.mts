// R2 residual: `r["value"] += yield v` reads the getter twice.
let reads = 0;
let v = 5;
const r = {
  done: false,
  get value() { reads++; return v; },
  set value(x: number) { v = x; },
} as IteratorYieldResult<number>;
function* g(): Generator<number, void, number> {
  r["value"] += yield 1;
}
const it = g();
it.next();
it.next(10);
console.log(v, "reads", reads);
