interface O { v: number | string; w: number | string; z?: number; q: number | undefined }
function* g(o: O): Generator<number, void, number> {
  if (typeof o.v === "number") {
    o.v += yield 1;
  }
  if (typeof o.w === "string") {
    o.w += yield 2;
  }
  if (o.z !== undefined) {
    o.z += yield 3;
  }
  if (o.q !== undefined) o.q *= yield 5;
  console.log("o", JSON.stringify(o));
}
const o: O = { v: 1, w: "w", z: 10, q: 3 };
const it = g(o);
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
