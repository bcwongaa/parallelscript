const log: string[] = [];
interface Box { v: number }
const boxes: Box[] = [{ v: 1 }, { v: 10 }];
function box(i: number): Box { log.push("box" + i); return boxes[i]; }
function idx(i: number): number { log.push("idx" + i); return i; }
const arr = [100, 200, 300];
const rec: Record<string, number> = { a: 1, b: 2 };
function key(k: string): string { log.push("key" + k); return k; }
function* g(): Generator<number, void, number> {
  box(0).v += yield 1;
  arr[idx(1)] += yield 2;
  rec[key("b")] *= yield 3;
  let i = 0;
  arr[i++] -= yield 4;
  console.log("i", i);
}
const it = g();
let r = it.next();
let n = 2;
while (!r.done) { log.push("y" + r.value); r = it.next(n++); }
console.log(log.join(","), JSON.stringify(boxes), arr.join(","), JSON.stringify(rec));
