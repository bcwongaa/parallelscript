class S {
  done = false as const;
  stored = 0;
  set value(x: number) { this.stored = x; }
}
const r = new S() as any as IteratorResult<number | undefined, undefined>;
console.log("setter-only read", r.value, r.done);
const one = new S() as any as IteratorYieldResult<number | undefined>;
console.log("setter-only one", one.value);
class T { done = false as const; value(): number { return this.k; } k = 9; }
const t: IteratorYieldResult<() => number> = new T();
const m = t.value;
try { console.log("unbound call", m()); } catch (e) { console.log("unbound threw", (e as Error).constructor.name); }
