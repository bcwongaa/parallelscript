// R2 residual: `r.value += yield v` reads the getter twice when the value's type is a union.
let reads = 0;
let v: number | string = 5;
const r = {
  done: false,
  get value(): number | string { reads++; return v; },
  set value(x: number | string) { v = x; },
} as IteratorYieldResult<number | string>;
function* g(): Generator<number, void, string> {
  r.value += yield 1;
}
const it = g();
it.next();
it.next("x");
console.log(v, "reads", reads);
