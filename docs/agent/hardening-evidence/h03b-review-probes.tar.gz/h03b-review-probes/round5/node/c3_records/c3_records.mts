function* g(): Generator<number, void, number> {
  const rec: Record<string, number> = { a: 1 };
  const k = "a";
  rec["a"] += yield 1;
  rec[k] *= yield 2;
  const m: { [k: string]: number } = { x: 2 };
  m.x += yield 3;
  m["y"] = 4;
  m["y"] -= yield 4;
  const rs: Record<string, string> = { s: "p" };
  rs.s += yield 5;
  console.log("rec", JSON.stringify(rec), JSON.stringify(m), JSON.stringify(rs));
}
const it = g();
let r = it.next();
let n = 3;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
