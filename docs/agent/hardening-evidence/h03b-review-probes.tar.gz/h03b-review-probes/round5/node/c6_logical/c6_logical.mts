interface O { n?: number; s: string; b: boolean; u: number | undefined }
function* g(o: O, a: number[]): Generator<number, void, number> {
  o.n ??= yield 1;
  o.s ||= String(yield 2);
  o.b &&= (yield 3) > 0;
  o.u ??= yield 4;
  a[0] ||= yield 5;
  a[1] &&= yield 6;
  console.log("o", JSON.stringify(o), a.join(","));
}
const it = g({ s: "", b: true, u: undefined }, [0, 9]);
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
