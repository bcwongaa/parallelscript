function* g(rec: Record<string, number | undefined>, ri: Record<string, int>): Generator<number, void, int> {
  if (rec.k !== undefined) rec.k += yield 1;
  if (rec["j"] !== undefined) rec["j"] *= yield 2;
  ri.a += yield 3;
  console.log("rec", JSON.stringify(rec), JSON.stringify(ri));
}
const it = g({ k: 1, j: 2 }, { a: 5 });
let r = it.next();
let n: int = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
