class T { done = false as const; value(): number { return this.k; } k = 9; }
const a: any = new T();
const m = a.value;
try { console.log("unbound call", m()); } catch (e) { console.log("unbound threw", (e as Error).constructor.name); }
