function* g(): Generator<number, void, number> {
  const t = new Float64Array(3);
  t[1] = 1.5;
  t[1] += yield 1;
  const u = new Int32Array(2);
  u[0] -= yield 2;
  const u8 = new Uint8Array(2);
  u8[1] = 250;
  u8[1] += yield 3;
  console.log("typed", t.join(","), u.join(","), u8.join(","));
}
const it = g();
let r = it.next();
let n = 7;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
