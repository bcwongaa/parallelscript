interface Holder<T> { value: T }
function* gen(): Generator<number, number, unknown> { yield 1; return 2; }
function show(h: Record<"value", number>) { console.log("recordlit", h.value); }
const it = gen();
const r = it.next();
show(r);
const lit = { done: false, get value() { return 7; } } as IteratorYieldResult<number>;
show(lit);
