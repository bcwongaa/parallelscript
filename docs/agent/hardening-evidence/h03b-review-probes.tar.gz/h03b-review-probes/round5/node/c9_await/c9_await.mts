interface O { v: number | string; n: number; s: string }
class K { x = 1 }
async function f(o: O, a: number[], rec: Record<string, number>, k: K, i: { x: number }) {
  if (typeof o.v === "number") o.v += await Promise.resolve(2);
  o.n *= await Promise.resolve(3);
  o.s += await Promise.resolve(4);
  a[1] += await Promise.resolve(5);
  a.length -= await Promise.resolve(1);
  rec["q"] -= await Promise.resolve(6);
  k.x += await Promise.resolve(7);
  i.x **= await Promise.resolve(2);
  console.log("await", JSON.stringify(o), a.join(","), JSON.stringify(rec), k.x, i.x);
}
async function* ag(o: O, a: number[]): AsyncGenerator<number, void, number> {
  o.n += yield 1;
  o.n += await Promise.resolve(10);
  a[0] -= yield 2;
  console.log("asyncgen", o.n, a.join(","));
}
async function main() {
  const o: O = { v: 1, n: 2, s: "s" };
  await f(o, [1, 2, 3], { q: 1 }, new K(), new K());
  const g = ag({ v: 1, n: 2, s: "s" }, [5]);
  let r = await g.next();
  let n = 3;
  while (!r.done) { console.log("yielded", r.value); r = await g.next(n++); }
}
main();
