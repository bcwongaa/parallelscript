// R2 variants: compound assignments whose right side yields, on results' value.
let log: string[] = [];
let v: any = 5;
function make<T>(): T {
  return { done: false, get value() { log.push("get"); return v; }, set value(x: any) { log.push("set"); v = x; } } as any as T;
}
function run(name: string, g: () => Generator<number, void, any>, sent: any) {
  log = [];
  const it = g();
  it.next();
  log.push("yielded");
  it.next(sent);
  console.log(name, log.join(","), v);
}

// a value of a union type (number | string): the kept read's type is a union too
v = 5;
const rs = make<IteratorYieldResult<number | string>>();
run("union value", function* () { rs.value += yield 1; }, 10);
v = "a";
run("union string", function* () { rs.value += yield 1; }, "b");

// element access
v = 5;
const re = make<IteratorYieldResult<number>>();
run("element", function* () { re["value"] += yield 1; }, 3);

// an unnarrowed union receiver
v = 5;
const ru = make<IteratorResult<number, number>>();
run("union receiver", function* () { ru.value += yield 1; }, 4);

// a call around the yield
v = 5;
const rc = make<IteratorYieldResult<number>>();
const twice = (n: number) => n * 2;
run("call", function* () { rc.value += twice(yield 1); }, 3);

// exponent and shift
v = 2;
run("exp", function* () { rc.value **= yield 1; }, 3);
v = 1;
run("shift", function* () { rc.value <<= yield 1; }, 4);

// a value read before the yield in the same expression
v = 5;
run("twice", function* () { rc.value += (yield 1) + rc.value; }, 1);

// an interface receiver (the base read it twice too)
interface HV { value: number | undefined }
v = 5;
const hv: HV = make<IteratorYieldResult<number>>();
run("iface", function* () { hv.value = (hv.value ?? 0) + (yield 1); }, 6);

// an optional-number value: IteratorResult<number | undefined>
v = 5;
const ro = make<IteratorYieldResult<number | undefined>>();
run("optional value", function* () { ro.value = (ro.value ?? 0) + (yield 1); }, 2);
