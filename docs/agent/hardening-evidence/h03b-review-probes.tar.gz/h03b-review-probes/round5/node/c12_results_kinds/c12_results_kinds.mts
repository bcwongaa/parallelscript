const log: string[] = [];
function mk<T>(init: T): { r: IteratorYieldResult<T>; get: () => T } {
  let v = init;
  const o = { done: false as const, get value(): T { log.push("get"); return v; }, set value(x: T) { log.push("set"); v = x; } };
  return { r: o, get: () => v };
}
const ni = mk<int>(5 as int);
const ns = mk<string>("a");
const nu = mk<number | undefined>(1);
const nn = mk<number>(2);
function* g(): Generator<number, void, int> {
  ni.r.value += yield 1;
  ns.r.value += yield 2;
  if (nu.r.value !== undefined) nu.r.value *= yield 3;
  nn.r.value **= yield 4;
}
const it = g();
let r = it.next();
let n: int = 2;
while (!r.done) { log.push("y" + r.value); r = it.next(n++); }
console.log(ni.get(), ns.get(), nu.get(), nn.get(), log.join(","));
async function af() {
  log.length = 0;
  nn.r.value += await Promise.resolve(10);
  const u: IteratorResult<number, number> = nn.r;
  u.value -= await Promise.resolve(1);
  console.log("async", nn.get(), log.join(","));
}
af();
