function* g(): Generator<() => number, void, unknown> { yield () => 41; }
const r = g().next();
if (!r.done) console.log("call", r.value());
