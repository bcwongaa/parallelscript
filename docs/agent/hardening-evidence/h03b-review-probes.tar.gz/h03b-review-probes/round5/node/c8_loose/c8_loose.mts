function* g(line: string, nums: number[]): Generator<number, void, number> {
  let [op, arg] = line.split(" ");
  op += yield 1;
  if (arg !== undefined) arg += yield 2;
  let [p, q] = nums;
  p += yield 3;
  if (q !== undefined) q *= yield 4;
  console.log("loose", op, arg, p, q);
}
const it = g("add", [1, 2]);
let r = it.next();
let n = 2;
while (!r.done) { console.log("yielded", r.value); r = it.next(n++); }
