#!/usr/bin/env python3
# usage: checkexpect.py file.pts  -> prints the expected stdout per pts/tests/README.md's `// expect:` rules
import sys, re
lines = open(sys.argv[1], encoding="utf-8").read().split("\n")
out = None
directive = re.compile(r"^// (expect|exit|stderr|error|no-diff|skip|threads):")
for i, l in enumerate(lines):
    if l == "// expect:":
        out = []
        for m in lines[i + 1:]:
            if not m.startswith("//") or directive.match(m):
                break
            if m == "//":
                out.append("")
            elif m.startswith("// "):
                out.append(m[3:])
            else:
                out.append(m[2:])
        break
if out is None:
    sys.exit(3)
sys.stdout.write("\n".join(out) + "\n")
