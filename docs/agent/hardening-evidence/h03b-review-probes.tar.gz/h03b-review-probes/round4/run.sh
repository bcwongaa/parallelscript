#!/bin/bash
# usage: run.sh X.pts  -> prints Node, new and base outputs; NOBASE=1 skips base
set -o pipefail
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
f=$(readlink -f "$1"); n=$(basename "$f" .pts)
R=/tmp/pts-h03b-review4b
ulimit -f 40960
mkdir -p $R/node/$n
cp "$f" $R/node/$n/$n.mts
echo "=== node"
(cd $R/node/$n && timeout 30 node --no-warnings --experimental-transform-types $n.mts 2>&1; echo "[exit $?]")
echo "=== new"
(cd /tmp && PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=$R/cache timeout 120 $R/pts run "$f" 2>&1; echo "[exit $?]")
if [ -z "$NOBASE" ]; then
echo "=== base"
(cd /tmp && PTS_HOME=$R/base PTS_CACHE_DIR=$R/cache-base timeout 120 $R/pts-base run "$f" 2>&1; echo "[exit $?]")
fi
