## Round 4: H03b, check of the round-3 fixes (R1–R3) and a hunt over the whole slice

Reviewer: opus-reviewer (claude-opus-5-5, xhigh), read-only, 2026-10-16. Tree: the parent's uncommitted working tree on base `a65a75d62`, including the R1–R3 changes (`convert.c` and `lower.go`, 03:28) and their pins (03:48). Tree CLI: `/tmp/pts-h03b-review4b/pts`, run with `PTS_HOME=/home/bryan/projects/parallelscript`. Base CLI: `/tmp/pts-h03b-review4b/pts-base`, built from a detached worktree of `a65a75d62` that I have since removed. Node v24.21.0. Nothing in the repository was edited (`git status` shows no file of mine; the sanitizer helper's C files were moved into my scratch directory).

## Verdict: NOT READY (no blocker; two small new SHOULD-FIX defects, plus stale suite evidence)

R1 and R3 are fixed, and my variants of both match Node. R2 is only partly fixed. I found no memory-safety defect: 16 probes and all 18 slice tests ran under ASan/UBSan with no ASan report. The only UBSan reports are three pre-existing ones that need no iterator results (NOTE 7). The defects I did find:

- **Finding 1 (R2 residual):** a compound assignment with a yield on its right still runs the getter twice when the result's value type is a union. Element access does the same, though for element access the base already behaves this way on interfaces.
- **Finding 2:** by-name reads don't find class methods, so a valid program throws a TypeError where Node returns the method.
- **Finding 3 (evidence):** the full-suite receipt in the evidence is from the tree before R1–R3.

## Ranked findings

1. **SHOULD-FIX (new)**: R2 residual. `r.value += yield v` still reads the getter twice when `T` is a union (`IteratorYieldResult<number | string>`). `r["value"] += yield v` also reads it twice, as interface receivers do on the base. D-178 says the property is read once.
2. **SHOULD-FIX (new, low impact)**: by-name reads skip class methods. Take a class instance whose `value` is a method, held as `IteratorYieldResult<() => number>`. Reading `.value` throws `TypeError: Expected () => number, got undefined`. Node returns the method, and PTS also finds it through `any`.
3. **SHOULD-FIX (evidence, new in this slice's docs)**: h03b.md's GREEN full-suite counts and `h03b-suite.json` come from the post-round-2 tree. Their events run 03:03:40–03:10:29, before the R1–R3 code (03:28) and the pins (03:48). No receipt of the final tree is in the evidence.
4. **NOTE (evidence)**: the benchmark row `b3d` (918,972,179, 1.06×) and D-178's "1.06× done first" don't reproduce. Round 3 measured 1.035, and I measure 1.040 for both b3 and b3d.
5. **NOTE (evidence)**: smaller accuracy and format issues in h03b.md:
   - The doc says "18 records", but `h03b-red.json` has 22 records of 18 tests.
   - The C42 RED row describes an earlier version of the file.
   - Table rows 41–42 lack the list indentation.
   - The tarball and `/tmp` paths it cites are gone.
6. **NOTE (new reachability, memory-safe, pre-existing class)**: TS's unsound `in` narrowing over a union of a result and an object type. An asserted result reaches the other member's reads and gets the kind check's TypeError, where Node prints values. The base throws the same TypeError for interfaces.
7. **NOTE (pre-existing, unledgered)**: three UBSan reports in ordinary programs, none involving results:
   - `convert_tuple` computes `&NULL->fields[i]`.
   - `pts_call_getter` and `pts_call_setter` call accessor entries through function pointers of another type.
8. **NOTE (code quality)**:
   - `isIteratorResultType` and `isIteratorResultUnion` are dead code.
   - Comments, D-178 and SPEC say a by-name read gives "a field, a getter, or undefined" (finding 2).
   - `readKeptAndStore`'s doc doesn't match its fallback (finding 1).
   - `interfaceCast` silently drops `FromResult` if `prepareDynamicTarget` fails (I couldn't reach that case).
   - `PROGRESS.md` is stale.
9. **NOTE (pre-existing or limitation, not in D-178's gaps)**: two forms are honest PTS1001s but print internal names:
   - narrowing a result with `instanceof` to its class (`converting object1 | object2 to Entry`);
   - a conditional between a class instance and a result literal where a result goes (PTS1001 on the base too).

---

## 1. SHOULD-FIX (new): R2 residual, union-typed values and element access

- **Repro (union value, new):** `/tmp/pts-h03b-review4b/p/r2_min_union.pts`
  ```ts
  let reads = 0;
  let v: number | string = 5;
  const r = {
    done: false,
    get value(): number | string { reads++; return v; },
    set value(x: number | string) { v = x; },
  } as IteratorYieldResult<number | string>;
  function* g(): Generator<number, void, string> {
    r.value += yield 1;
  }
  const it = g();
  it.next();
  it.next("x");
  console.log(v, "reads", reads);
  ```
- **Command:** `/tmp/pts-h03b-review4b/run.sh /tmp/pts-h03b-review4b/p/r2_min_union.pts` (output: `out/r2_min_union.txt`)
- **Node:** `5x reads 1`. **PTS:** `5x reads 2`. **Base:** PTS1001 `using a object2 as a object1` (honest).
- **Repro (element access):** `/tmp/pts-h03b-review4b/p/r2_min_element.pts` (`r["value"] += yield 1` on an `IteratorYieldResult<number>` getter literal): Node `15 reads 1`, PTS `15 reads 2`, base PTS1001.
  - Control `p/r2_element_iface_ctl.pts`: the same with an interface receiver gives `reads 2` on both base and tree. So the element-access half is a pre-existing D-145 gap, newly reachable for results.
  - Control `p/r2_union_iface_ctl.pts`: a union-typed interface property reads once on the tree and twice on the base. R2 fixed that case for interfaces, but not for results.
- **Variants:** `p/r2_variants.pts` matches Node for an unnarrowed union receiver, a call around the yield, `**=`, `<<=`, and a value also read on the right side. It reads twice for `union value`, `union string` and `element` (`get,yielded,get,set` against Node's `get,yielded,set`).
- **Cause:** `readKeptAndStore` (`pts/lower/lower.go:2978-2997`) uses the kept read only if `kept.Type() == t` or the place's union `t` has `kept.Type()` as a member. Otherwise it silently falls back to `target.read()`, which runs again after the resume and whose value is unused. Two cases miss:
  - A D-109 shape's field is `T | undefined`. For a union `T`, the kept read's type is `T` itself, which is neither equal to the field's type nor a member of it.
  - `r["value"]` on a result is a dynamic place (`t` is Value). The emitted C (`out/r2_min_element.c`) binds `current_2 = pts_dynamic_get(object, key)` after the resume and then uses `pts_frame->current`.

  The union case's C (`out/r2_min_union.c:328`) shows the second `pts_result_get` the same way.
- **Contradicts** D-178: "a read-modify-write … reads the property once, also when its right side yields". It is also H03b's acceptance theme (getters run when and as the caller reads them).
- **Fix suggestion:** when `kept != nil`, always bind `read` to `kept` converted to the place's type: `l.convert(kept, t, …)` handles a union into a wider union, and `box` handles a dynamic place. Pin with the two repros.

## 2. SHOULD-FIX (new, low impact): by-name reads don't find class methods

- **Repro:** `/tmp/pts-h03b-review4b/p/s6b_method_any_ctl.pts`
  ```ts
  class E {
    done = false as const;
    value() { return 42; }
  }
  const a: any = new E();
  console.log("any", typeof a.value, a.value());
  const viaAny = a.value;
  console.log("any value read", typeof viaAny);
  const one: IteratorYieldResult<() => number> = new E();
  const f = one.value;
  console.log("one", typeof f);
  ```
- **Command:** `/tmp/pts-h03b-review4b/run.sh /tmp/pts-h03b-review4b/p/s6b_method_any_ctl.pts` (output: `out/s6b_method_any_ctl.txt`)
- **Node:** `any function 42` / `any value read function` / `one function`.
- **PTS:** the two `any` lines match, then `Uncaught TypeError: Expected () => number, got undefined` (line 11).
- **Base:** PTS1001 `using a E as a object1`.
- The union form fails the same way (`p/s6_value_method.pts`: `IteratorResult<() => number, undefined>` from a class instance), with the same TypeError at line 12. An object literal's own method works (`call 41`).
- **Cause:** `pts_result_get_slow` (`pts/runtime/src/object.c:326-345`) finds a field or a getter. Otherwise it returns `PTS_VALUE_UNDEFINED` ("an object without it"), so a prototype method is never found. The runtime's other by-name reads of results do find it, because they use `pts_dynamic_get`: `handed_value` and `result_done` in `generator.c`, and reads through `any`.
- **Fix suggestion:** fall back to `pts_dynamic_get` (or a method lookup) instead of returning undefined. Fix the wording of the `pts.h` comment, D-178 and SPEC ("a field, a getter, or undefined if there is none") to match.

## 3. SHOULD-FIX (evidence): the GREEN suite receipt predates R1–R3

- `docs/agent/hardening-evidence/h03b-suite.jsonl.gz` has event times from `2026-10-16T03:03:40` to `03:10:29`, and `h03b-suite.json` says "uncommitted H03b working tree after review round 2". The R1–R3 changes and pins came later:
  ```
  2026-10-16 03:28:30 pts/runtime/src/convert.c
  2026-10-16 03:28:53 pts/lower/lower.go
  2026-10-16 03:48:44 pts/tests/run/iterator_results_from_any.pts
  2026-10-16 03:48:44 pts/tests/run/iterator_results_other_types.pts
  ```
- h03b.md's session-3 narrative says the full suite ran again, but GREEN still cites the earlier 1,381/256/0 run and its receipt. The counts may come out identical, since the pins extend existing files. Record the final tree's run and its CLI sha.
- My own runs on the final tree are below ("Verified good"). They are focused, not a full suite.

## 4. NOTE (evidence): b3d's 1.06× doesn't reproduce

h03b.md's table shows `b3d_user_forof_donefirst` at 866,965,482 → 918,972,179 (1.06), and D-178 says "(1.06× done first)". Round 3 already measured 896,972,071 (1.035) for the parent's own binary. My programs (`bench/b3_user_forof.pts` and `bench/b3d_user_forof_donefirst.pts`; the originals are lost) give identical counts for both orders, 742.94M → 772.94M (**1.040**). The doc says the table was re-measured, but this row and D-178's sentence still carry the number that doesn't reproduce. The direction holds (a small slowdown).

## 5. NOTE (evidence): smaller accuracy and format issues in h03b.md

- "[h03b-red.json] (18 records, from both sessions)": `records` holds **22** records of 18 distinct tests (`python3 … len(d['records'])` → 22; `yield_star_result_edges` ×3, `iterator_results_other_types` ×2, `iterator_results_from_any` ×2).
- The RED row for `run/iterator_results_from_any.pts` (C42) shows the earlier version's failure (`next done read` … `Error: value of a done result was read`). The final file fails on the base with PTS1001 at 138:12 (``using a `{done: boolean; extra: string; value: number}` as a `object2` ``; my base run, `tests/base/iterator_results_from_any.err`). The `yield_star_result_edges` row notes this kind of change; this row doesn't.
- The RED table sits inside list item 3, and its last two rows (lines 41–42, the `iterator_results_other_types` round-3 tail and `any_maps_error`) lack the three-space indent, so they will render outside the table.
- `h03b-review-probes.tar.gz` (cited in h03b.md lines 48, 74 and 100, and in h03b-review.md line 3) and D-178's `/tmp/pts-h03b-s2/bench` no longer exist. `REVIEW4_PLACEHOLDER` and `COMMIT_PLACEHOLDER` remain.

## 6. NOTE (new reachability; safe; pre-existing behaviour class): `in` narrowing across a result and another object member

- **Repro:** `p/m01b_in_shape_kinds.pts`. In `show(u: IteratorResult<number> | { x: number; y: number })`, the branch `if ("y" in u)` reads `u.x`, then `u.y`. The argument is `{ done: false, value: 1, x: 2.5, y: "s" } as IteratorYieldResult<number>`.
  - Node: `x 2.5`, `y s string`, …
  - PTS: `x 2.5`, then `Uncaught TypeError: Cannot read property y of Object as number: it is declared string`.
  - Base: PTS1001 at the `as`.
- `p/m01_in_shape.pts` and `p/m02_in_iface.pts` (no `x`): PTS gives `Cannot read property 'x' of #<Object>: it has none, though a type assertion says it has`, where Node prints `pt undefined s`.
- **Control without results** (`p/m01d_in_iface_base.pts`, `A | B` interfaces, an object with `y: string` passed as `A`): base and tree both throw the same TypeError, where Node prints `b 2.5 s`. So this is TS's unsound `in` narrowing hitting D-072's kind check, now reachable for results too.
- **Memory safety:** the narrowed read is a checked site. In `out/m08.c`, the narrowed `u.y` read emits `pts_field_address(…, &pts_site1, "y", &pts_check_4)`, so no offset read of a foreign layout occurs. `p/m04_guard.pts` (a user type guard) behaves the same way (`Expected number, got undefined`).

## 7. NOTE (pre-existing, unledgered): UBSan reports in ordinary programs

I built probes with the toolchain's `Sanitize` flags (`-fsanitize=address,undefined -fno-sanitize-recover=undefined`). The helper is `/tmp/pts-h03b-review4b/sanbuild/sanbuild`, which mirrors `pts/tests/http_test.go:buildSanitized`. Three UBSan reports abort programs that use no iterator results:

- `p/u1_entries_ub.pts` (`Object.entries({a: 1, b: 2})`): `convert.c:347:31: runtime error: applying zero offset to null pointer` in `convert_tuple`. `&object->type->fields[i]` is computed for an array source, whose `fields` is NULL. The same line is at base `convert.c:338`.
- `p/u2_getter_fn_type.pts` (a class getter returning a class, copied from `any`): `dynamic.c:242:55: call to function pts_entry_H_get_p through pointer to incorrect function type 'void *(*)(struct pts_object *)'`.
- `p/u3_setter_fn_type.pts` (a string setter written through `any`): `dynamic.c:568:26: call to function … through pointer to incorrect function type 'void (*)(struct pts_object *, void *)'`.

All three are benign on x86-64 SysV, and the `convert.c` and `dynamic.c` code involved is unchanged by the slice. They make 3 of the 18 slice tests stop under UBSan (`iterator_results_from_any`, `iterators_through_any_consumers`: the `convert_tuple` report; `iterator_result_getter_literals`: the setter report). I found nothing in CONSOLIDATED, PROGRESS or DECISIONS about them (`grep "zero offset\|convert_tuple"` found nothing).

## 8. NOTE (code quality)

- **Dead code:** `isIteratorResultType` and `isIteratorResultUnion` (`pts/lower/union_objects.go:128-150`). Their only caller was the removed `reportedGetterResult` (`grep -rn` finds no other use).
- **`readKeptAndStore` (`lower.go:2970-2977`):** the doc says the kept read is used so that the place "isn't read again after the yield". On a type mismatch it silently reads again (finding 1).
- **Wording about by-name reads:** the `pts.h` comment of `pts_result_get` and D-178's "a field, a getter, or undefined if there is none" skip methods (finding 2).
- **`interfaceCast` (`objects.go:916`):** if `prepareDynamicTarget` fails, it silently emits the plain cast that leads to the "compiler bug" kind error. I tried 16 interface property types (`void`, `MapIterator<string>`, `Promise<number>`, `Float64Array`, `Iterator<number>`, `never`, `{}`, `Record<…>`, …). All got the conversion, and `bigint`/`symbol`/`WeakMap` are rejected earlier, so I couldn't reach the case. A PTS1001 in that branch would make the invariant explicit.
- **Docs:**
  - D-177 isn't marked as partly superseded by D-178.
  - `PROGRESS.md` lines 9, 211 and 234 still list C28–C35 as open and getter-literal results as PTS1001. Presumably that changes with the commit.

## 9. NOTE (limitations, honest PTS1001 with internal names, not in D-178's gaps)

- `p/m05_instanceof.pts`: `if (r instanceof Entry) r.extra` on a result gives `PTS1001: converting object1 | object2 to Entry is not supported yet`. Node prints `e entry 4`. The bare `r instanceof Entry` works (`p/m05b_instanceof_bool.pts` matches Node).
- `p/t2b_cond.pts`: `i === 0 ? new Entry(i) : { done: false, value: i }` where a result goes gives `converting object1 to Entry | {done: boolean; value: number}`. The base fails the same way, so this belongs with C57/H29.

---

## Round-3 findings: status

| # | Round 3 | Now | Evidence |
|---|---|---|---|
| R1 | union of a result and another object member kept the object as the result | **fixed** | Pin RED on a scratch runtime with round-3 `convert.c` (`r3tree/`: results_last and the `implies` line removed). Same failure as the parent's record: line 39 `point 3 4` missing, `TypeError: Cannot read property x of Object as number: it is declared number \| string` at :124. Green on the final tree. My variants `p/r1_variants.pts` all match Node: arrays, an `any` array into `Array<Point \| IteratorResult<number>>`, tuples, a Map write through `any`, an optional property, `IteratorYieldResult \| IteratorReturnResult \| Point`, a nested field union, a union member holding a result, and a getter result kept lazily (`got gr 0`, `gr false 1`; base `2`, `2`). The same file fails at its first case on the round-3 runtime. A `Record<string, number>` member (`p/r1_record.pts`) prints the same as the base (D-071's copy, pre-existing). |
| R2 | `r.value += yield v` read the getter twice | **partly fixed** | Pin RED with a CLI built with only the R2 hunk reverted (`go build -overlay`, `pts-r3lower`). Line 27 reads `get,yielded,get,set 14,resumed,get,yielded,get,set 42`, exactly the parent's record. Green on the final tree. Union-typed values and element access still read twice: finding 1. |
| R3 | result checks implied interfaces by declared types | **fixed** | Twin RED on the round-3 runtime: line 39 `wrapped 3.5` missing, `Cannot read property value of Object as value: it is declared number`. Green on the final tree. My variants `p/r3_variants.pts` all match Node: an array field, a nested object, `\| undefined`, the same result type kept as is (identity `true true`), a wider result type, and an object-typed getter. On the round-3 runtime they fail at `deep`. Static routes stay honest PTS1001, as on the base (`p/r3_static_cast.pts`). |

## Verified good (evidence)

- **The 18 regression files plus the 3 modified ones** (`runtests.sh`): PTS stdout equals each `// expect:` block for all 21. The threads file matches at 1, 2 and 4 threads, plus six more runs at 4 and 8. Node's stdout equals the expect block for the 18 files without `no-diff` or `parallel`. `iterator_results_copied`'s comment ("JS prints `row 10 true …` and `literal true 99`") matches Node.
- **Focused `go test`:** `^(TestRun|TestRunMatchesNode)$/^(<21 files>)$`, `PTS_REQUIRE_NODE=1`: exit 0, 44 pass / 3 skip / 0 fail (`tests/gotest-focus.jsonl`).
- **Broader `go test`:** `^(TestRun|TestRunMatchesNode|TestErrors)$/^(any|dynamic|union|json|convert|interface|generator|iterator|yield|for_of|async_gen|array_pattern|destructur|shape|optional|relaxed|record)`: exit 0, 175 pass / 49 skip / 0 fail.
- **Other checks:**
  - `go test ./pts/lower/ ./pts/cgen/`: ok.
  - `go vet` on lower, cgen and ir: exit 0.
  - `TestRuntimeUnitTestsPassUnderSanitizers`: ok.
- **RED on the base** (`runbase.sh`, my base CLI): the table's first failures reproduce for these rows:
  - `iterator_methods_through_any`: `next escaped: h.next is not a function`.
  - `iterator_next_result_identity`: `same object false`.
  - `iterator_next_result_getters`: line 3 `manual read value 0`.
  - `iterator_result_as_layouts`: `parameter escaped: Expected number, got function`, then `console.log got a malformed value 0x0`.
  - `iterator_result_as_cast`: `TypeError: Expected number, got function`.
  - `array_pattern_elision_done_only`: `class read value 0`.
  - `iterator_close_result_unread`: `P value 1`.
  - `iterators_through_any_consumers`: `TypeError: h.next is not a function`.
  - `iterator_results_threads`: ``using a `object6` as a `object1` ``.
  - `iterator_results_copied`: `converting Entry to object1 | object2`.
  - `any_maps_error`: `keys -> TypeError…` against the new `keys ok`.
  - The PTS1001 rows: `return_throw_results`, `as_one_shape`, `getters_typed`, `getter_literals`, `yield_star_result_edges`, `other_types`.
- **Suite arithmetic** (recounted from the two jsonl.gz files): baseline 1,345 pass / 260 skip, suite 1,381 / 256. The per-test deltas are exactly as h03b.md lists them: 31 new events (14 TestRun files, plus the threads file with its parent and 3 subtests, plus 13 MatchesNode), 6 skip→pass, `TestErrors/iterator_result_getters` removed, 2 new MatchesNode skips. That gives +36 / −4.
- **H01b probes:** rerun with my CLI (`probes-h01b/run.log`): "22 probes, 14 not behaving as their kind says". All 14 red probes now `run-match` and all 8 controls `ok`, as h03b.md says.
- **Memory safety under ASan/UBSan** (`sanrun.sh`, `san/`): no ASan report anywhere. These all run with no report and match Node or the expect block:
  - 15 slice tests, including both halves of `iterator_result_as_cast`, which SIGSEGV'd on the base;
  - the threads test at 1 and 4 threads;
  - the probes `s2c_consumers_noentries`, `r1_variants_notuple`, `r3_variants_nogetter`, `j01_counts`, `s3_async`, `s4b_keys` and `g1_gc_stress` (GC pressure while handed results wait, 2×200k steps).

  The other 3 slice tests stop only at the pre-existing UBSan reports of NOTE 7.
- **Results of foreign layouts through every consumer I tried** (`p/s2b_consumers.pts`, matches Node): `Object.keys`/`values`/`entries`, `JSON.stringify`, `for…in`, `in`, `hasOwnProperty`, templates, `map`/`sort`, `Set`, `Map.get(...)?.value`, `keyof` generics (`prop(lit, "value")`), closures, class fields, `Object.freeze`, and `for…of` over arrays of results. Spreads and destructuring stay the declared C44 PTS1001. Computed keys (`o[k]` read and write with `k: "done" | "value"`) match (`p/s4b_keys.pts`). `delete` is the existing PTS1002.
- **Getter counts and order** (`p/j01_counts.pts`, identical to Node on every line) through a `yield*` of an object iterator with getter results:
  - consumers: `for…of`, array patterns with elisions and close, spread, `Array.from`, `new Set`;
  - break with `return()`;
  - typed `next`/`return`/`throw`, `next`/`return` through `any`, and nested `yield*`.
- **Runtime iterators** (`p/k01_runtime_iters.pts`): typed `ai.return!()` and `return`/`throw` through `any` give Node's TypeErrors and the iterator goes on. Array, map, string and generator iterators through `any` print Node's results. The only difference is C46's `h.throw === undefined`.
- **Async** (`p/s3_async.pts`): `await ai.next()` on a typed `AsyncIterator` whose results have getters, `for await` over it and over a sync iterable of getter results, and async generators through `any`. All identical to Node.
- **Threads:**
  - `p/t1_par_reads.pts`: 400 `parallel for` tasks read 5 result layouts at one by-name site, `bad 0` at 1, 4 and 8×3 threads.
  - `p/t2_par_view.pts`: `.par.map` and `.par.reduce` over 3,000 mixed-layout results, correct at 1, 4 and 8×2 threads.
  - `convert`'s `results_last` lives in the per-call `converting` struct (one entry point, which initialises it), so it can't leak across threads or calls.
- **No panic or clang error** in any probe. Unusual call forms (`p/d01_call_forms.pts`) give the base's PTS1001s.

## Performance

Callgrind instruction counts, `PTS_THREADS=1`, my own programs (`bench/*.pts`; the parent's originals are lost), base binaries against tree binaries, same stdout. Summary in `bench/summary.txt`:

| Program | Base | Tree | Ratio | h03b.md |
|---|---|---|---|---|
| `b4_user_next` (typed `next()` over a class implementing `Iterator<number, undefined>`, 1M) | 365,913,719 | 279,914,032 | **0.765** | 0.547 (another program) |
| `b6_forof_gen` (`for…of` over a generator, 1M) | 133,768,249 | 137,768,064 | **1.030** | 1.03 |
| `r1_union_reads` (1M reads of stored `IteratorResult<number, void>`) | 282,228,346 | 196,237,115 | **0.695** | 0.716 |
| `b2_next_shape` (typed `next()` over `Generator<number, number>`, 1M) | 246,763,166 | 275,921,336 | **1.118** | 1.113 |
| `b3_user_forof` (`for…of` over a class's iterable, value first) | 742,938,441 | 772,940,989 | **1.040** | 1.033 |
| `b3d_user_forof_donefirst` (done first) | 742,943,382 | 772,941,292 | **1.040** | 1.06 (NOTE 4) |

The directions all reproduce. `b2`'s +29M is `pts_iterator_call` (64.0M of 275.9M in `callgrind_annotate`).

## Commands

- **Builds:**
  - Tree CLI: `cd /home/bryan/projects/parallelscript && GOMAXPROCS=2 go build -p 2 -o /tmp/pts-h03b-review4b/pts ./cmd/pts`.
  - Base CLI: from the worktree of `a65a75d62` (submodules from the repo's modules), `pts-base`.
  - CLI without R2: `go build -overlay overlay/overlay.json -o pts-r3lower ./cmd/pts`, with `overlay/lower.go` being the tree's file minus the kept-read lines.
  - Round-3 runtime: `r3tree/pts/runtime` (copy, `convert.c` without results_last and the `implies` line), with `third_party` and `lib` symlinked.
- `run.sh X.pts` prints Node (`node --no-warnings --experimental-transform-types X.mts`), tree (`PTS_HOME=<repo> pts run`) and base (`PTS_HOME=<base worktree> pts-base run`; `NOBASE=1` skips it). Outputs of the cited probes are in `out/<name>.txt`.
- `runtests.sh <names>` compares the tree's stdout and Node's with each test's expect block (`checkexpect.py`, the README's rules), with `PTS_THREADS` per `// threads:`. `runbase.sh` does the same on the base.
- `sanrun.sh X.pts [threads]` builds with ASan/UBSan (`sanbuild/sanbuild`, which mirrors `buildSanitized`) and runs with `ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0`. Outputs are in `san/` and the emitted C in `san/c/`.
- **Focused tests:** `PATH=$HOME/.local/node/bin:$PATH GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 1 -parallel 2 ./pts/tests/ -run '<pattern>'`; events are in `tests/gotest-focus.jsonl` and `tests/gotest-broad.jsonl`.
- **H01b probes:** `python3 -I docs/agent/hardening-evidence/probes/h01b/run_probes.py --pts /tmp/pts-h03b-review4b/pts --node ~/.local/node/bin/node --scratch probes-h01b --out probes-h01b/after.json c02-* c03-* c18-* parent/c02-* parent/c18-*`.
- **Callgrind:** `PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=cg.<prog>.<base|new> ./<prog>.<base|new>` in `bench/`.
- The base worktree was removed with `git worktree remove --force /tmp/pts-h03b-review4b/base`.
