#!/bin/bash
# sanrun.sh file.pts [threads...]: ASan/UBSan build, run, compare stdout with Node's (or the expect block when the file has one and is a test)
R=/tmp/pts-h03b-review4b
f=$(readlink -f "$1"); shift; n=$(basename "$f" .pts)
threads="${@:-1}"
(cd /tmp && PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=$R/cache GOMAXPROCS=2 $R/sanbuild/sanbuild "$f" $R/san/$n > $R/san/$n.build 2>&1) || { echo "$n: BUILD FAILED $(head -c 300 $R/san/$n.build)"; exit 1; }
if $R/checkexpect.py "$f" > $R/san/$n.want 2>/dev/null; then src=expect; else
  mkdir -p $R/node/$n; cp "$f" $R/node/$n/$n.mts; (cd $R/node/$n && PATH=$HOME/.local/node/bin:$PATH timeout 60 node --no-warnings --experimental-transform-types $n.mts > $R/san/$n.want 2>/dev/null); src=node; fi
for t in $threads; do
  (cd /tmp && ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=print_stacktrace=1 PTS_THREADS=$t TZ=America/New_York timeout 300 $R/san/$n > $R/san/$n.t$t.out 2> $R/san/$n.t$t.err); code=$?
  san=$(grep -c "ERROR: AddressSanitizer\|runtime error:" $R/san/$n.t$t.err)
  if cmp -s $R/san/$n.want $R/san/$n.t$t.out; then m=match; else m=DIFF; fi
  echo "$n [threads $t]: exit $code, sanitizer reports $san, stdout vs $src: $m"
done
