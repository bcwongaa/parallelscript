#!/bin/bash
R=/tmp/pts-h03b-review4b; T=/home/bryan/projects/parallelscript/pts/tests/run
mkdir -p $R/tests/base
for f in "$@"; do
  envth=""; grep -q '^// threads:' $T/$f.pts && envth="PTS_THREADS=4"
  (cd /tmp && env $envth PTS_HOME=$R/base PTS_CACHE_DIR=$R/cache-base timeout 120 $R/pts-base run $T/$f.pts > $R/tests/base/$f.out 2> $R/tests/base/$f.err); code=$?
  $R/checkexpect.py $T/$f.pts > $R/tests/base/$f.expect
  firstdiff=$(diff <(cat $R/tests/base/$f.expect) $R/tests/base/$f.out | head -3 | tr '\n' '|')
  echo "$f: base exit $code; first diff: ${firstdiff:0:220}; stderr: $(head -c 300 $R/tests/base/$f.err | tr '\n' '|')"
done
