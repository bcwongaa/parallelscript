#!/bin/bash
# For each slice test: PTS stdout vs its expect block, and Node stdout vs the expect block (unless no-diff/parallel).
export PATH=$HOME/.local/node/bin:$PATH
R=/tmp/pts-h03b-review4b; T=/home/bryan/projects/parallelscript/pts/tests/run
for f in "$@"; do
  exp=$R/tests/$f.expect; $R/checkexpect.py $T/$f.pts > $exp || { echo "$f: no expect block"; continue; }
  threads=$(grep -E '^// threads:' $T/$f.pts | sed 's#// threads:##')
  [ -z "$threads" ] && threads=default
  for th in $threads; do
    if [ $th = default ]; then envth=""; else envth="PTS_THREADS=$th"; fi
    (cd /tmp && env $envth PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=$R/cache timeout 120 $R/pts run $T/$f.pts > $R/tests/$f.pts$th.out 2> $R/tests/$f.pts$th.err); code=$?
    if cmp -s $exp $R/tests/$f.pts$th.out; then pres="match"; else pres="DIFF"; fi
    echo "$f [threads $th]: pts exit $code, stdout vs expect: $pres"
  done
  if grep -qE '^// no-diff:' $T/$f.pts || grep -q 'parallel' $T/$f.pts; then echo "$f: node skipped (no-diff/parallel)"; continue; fi
  mkdir -p $R/tests/node-$f; cp $T/$f.pts $R/tests/node-$f/$f.mts
  (cd $R/tests/node-$f && timeout 60 node --no-warnings --experimental-transform-types $f.mts > $R/tests/$f.node.out 2> $R/tests/$f.node.err); ncode=$?
  if cmp -s $exp $R/tests/$f.node.out; then nres="match"; else nres="DIFF"; fi
  echo "$f: node exit $ncode, stdout vs expect: $nres"
done
