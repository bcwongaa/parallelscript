# Rebuilds files the H03b sessions wrote under /tmp/pts-h03b* from their transcripts:
# Write and Edit tool calls, and Bash heredocs (`cat > path <<'D'` / `cat <<'D' > path`),
# relative paths resolved against the last `cd` before them in the same command.
import json, os, re, sys

out_root, transcripts = sys.argv[1], sys.argv[2:]
events = []
for f in transcripts:
    for line in open(f):
        e = json.loads(line)
        c = (e.get('message') or {}).get('content')
        if not isinstance(c, list):
            continue
        for p in c:
            if p.get('type') == 'tool_use':
                events.append((e.get('timestamp') or '', f, p.get('name'), p.get('input') or {}))
events.sort(key=lambda x: x[0])

files, log = {}, []
start = re.compile(r"cat\s+(?:>\s*(?P<a>\S+)\s*<<-?\s*(?P<q>['\"]?)(?P<d>\w+)(?P=q)|<<-?\s*(?P<q2>['\"]?)(?P<d2>\w+)(?P=q2)\s*>\s*(?P<b>\S+))")
cd = re.compile(r"(?:^|[;&|(]\s*|\n\s*)cd\s+(\S+)")

def resolve(cwd, path):
    path = path.strip('"\'')
    return os.path.normpath(path if path.startswith('/') else os.path.join(cwd or '/UNKNOWN', path))

for ts, f, name, inp in events:
    if name == 'Write':
        p = inp.get('file_path', '')
        if p.startswith('/tmp/pts-h03b'):
            files[p] = inp.get('content', ''); log.append((ts, 'write', p))
    elif name == 'Edit':
        p = inp.get('file_path', '')
        if p.startswith('/tmp/pts-h03b') and p in files:
            old, new = inp.get('old_string', ''), inp.get('new_string', '')
            if old in files[p]:
                files[p] = files[p].replace(old, new) if inp.get('replace_all') else files[p].replace(old, new, 1)
                log.append((ts, 'edit', p))
            else:
                log.append((ts, 'edit-miss', p))
    elif name == 'Bash':
        cmd = inp.get('command', '')
        lines = cmd.split('\n')
        offset = 0
        i = 0
        while i < len(lines):
            line = lines[i]
            m = start.search(line)
            if not m:
                i += 1
                continue
            before = cmd[:sum(len(l) + 1 for l in lines[:i]) + m.start()]
            cds = [c for c in cd.findall(before) if c.startswith('/tmp/pts-h03b')]
            cwd = cds[-1] if cds else None
            target = m.group('a') or m.group('b')
            delim = m.group('d') or m.group('d2')
            body = []
            j = i + 1
            while j < len(lines) and lines[j].strip() != delim:
                body.append(lines[j]); j += 1
            p = resolve(cwd, target)
            if p.startswith('/tmp/pts-h03b'):
                files[p] = '\n'.join(body) + '\n'; log.append((ts, 'heredoc', p))
            elif cwd is None and not target.startswith('/'):
                log.append((ts, 'heredoc-no-cwd', target))
            i = j + 1

for p, content in files.items():
    dest = os.path.join(out_root, p.lstrip('/'))
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    with open(dest, 'w') as fh:
        fh.write(content)
with open(os.path.join(out_root, 'RECOVERY_LOG.tsv'), 'w') as fh:
    for row in log:
        fh.write('\t'.join(row) + '\n')
print(len(files), 'files;', sum(1 for r in log if r[1] == 'heredoc-no-cwd'), 'heredocs without a /tmp/pts-h03b cwd;', sum(1 for r in log if r[1] == 'edit-miss'), 'edit misses')
