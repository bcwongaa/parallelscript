# Writes a suite receipt: counts of a go test -json run, and its delta against the baseline's events.
import gzip, hashlib, json, sys
run_path, baseline_path, out_path, tree, cli_sha = sys.argv[1:6]

def outcomes(lines):
    tests, packages = {}, {'tested': 0, 'no_test': 0}
    for line in lines:
        e = json.loads(line)
        if e.get('Test') and e['Action'] in ('pass', 'fail', 'skip'):
            tests[e['Test']] = e['Action']
        elif not e.get('Test') and e['Action'] == 'pass':
            packages['tested'] += 1
        elif not e.get('Test') and e['Action'] == 'output' and 'no test files' in e.get('Output', ''):
            packages['no_test'] += 1
    return tests, packages

raw = open(run_path, 'rb').read()
run, packages = outcomes(raw.decode().splitlines())
base, _ = outcomes(gzip.open(baseline_path, 'rt').read().splitlines())
count = lambda t, a: sum(1 for v in t.values() if v == a)
corpus = {a: sum(1 for k, v in run.items() if k.startswith('TestCorpusMatchesNode/') and v == a) for a in ('pass', 'skip', 'fail')}
receipt = {
    'task': 'H03b', 'date': '2026-10-16', 'base': 'a65a75d62724c7cc78d14748aedb9ac0e51a6fca', 'tree': tree,
    'commands': ['GOMAXPROCS=2 go build -p 2 ./...', 'GOMAXPROCS=2 make build',
                 'PATH=$HOME/.local/node/bin:$PATH GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 2 -parallel 2 -timeout 40m ./pts/... ./cmd/pts/'],
    'exits': {'build': 0, 'make build': 0, 'go test': 0}, 'cli_sha256': cli_sha,
    'counts': {'pass': count(run, 'pass'), 'skip': count(run, 'skip'), 'fail': count(run, 'fail'),
               'packages_tested': packages['tested'], 'packages_no_test': packages['no_test'], 'corpus': corpus},
    'baseline': {'pass': count(base, 'pass'), 'skip': count(base, 'skip'), 'fail': count(base, 'fail'), 'record': 'h03b-baseline.jsonl.gz'},
    'delta': {'added': sorted([k, v] for k, v in run.items() if k not in base),
              'changed': sorted([k, base[k], v] for k, v in run.items() if k in base and base[k] != v),
              'removed': sorted([k, v] for k, v in base.items() if k not in run)},
    'raw_events': {'file': 'h03b-suite.jsonl.gz', 'sha256_uncompressed': hashlib.sha256(raw).hexdigest()},
}
json.dump(receipt, open(out_path, 'w'), indent=1)
print(receipt['counts'], 'baseline', receipt['baseline'], 'added', len(receipt['delta']['added']), 'changed', len(receipt['delta']['changed']), 'removed', receipt['delta']['removed'])
