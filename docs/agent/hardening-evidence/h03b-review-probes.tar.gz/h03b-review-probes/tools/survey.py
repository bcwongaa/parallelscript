# Survey file writes under /tmp/pts-h03b* in session transcripts: Write/Edit tool calls and Bash heredocs.
import json, re, sys, collections
paths = collections.Counter(); kinds = collections.Counter()
heredoc = re.compile(r"cat\s+>\s*(\S+)\s*<<\s*'?(\w+)'?")
for f in sys.argv[1:]:
    for line in open(f):
        e = json.loads(line)
        m = e.get('message') or {}
        c = m.get('content')
        if not isinstance(c, list): continue
        for p in c:
            if p.get('type') != 'tool_use': continue
            name, inp = p.get('name'), p.get('input') or {}
            if name in ('Write', 'Edit') and str(inp.get('file_path','')).startswith('/tmp/pts-h03b'):
                paths[inp['file_path']] += 1; kinds[name] += 1
            elif name == 'Bash':
                for mm in heredoc.finditer(inp.get('command','')):
                    if '/tmp/pts-h03b' in mm.group(1) or not mm.group(1).startswith('/'):
                        kinds['heredoc'] += 1; paths['HEREDOC '+mm.group(1)] += 1
print(kinds)
for p, n in sorted(paths.items())[:400]: print(n, p)
