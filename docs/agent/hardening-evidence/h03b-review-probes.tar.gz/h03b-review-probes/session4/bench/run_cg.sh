#!/bin/bash
# Builds each benchmark with the base CLI (a65a75d62) and the tree's, and counts instructions under callgrind (PTS_THREADS=1), two programs at a time.
set -o pipefail
R=/home/bryan/projects/parallelscript
B=/tmp/pts-h03b-s4/base
cd /tmp/pts-h03b-s4/bench
for f in *.pts; do
  b=${f%.pts}
  PTS_HOME=$R PTS_CACHE_DIR=/tmp/pts-h03b-s4/cache $R/pts-bin/pts build $f -o $b.new || echo "$b new build failed"
  [ -x $b.base ] || PTS_HOME=$B PTS_CACHE_DIR=/tmp/pts-h03b-s4/cache-base $B/pts-bin/pts build $f -o $b.base || echo "$b base build failed"
done
count() { PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=/dev/null ./$1 > out.$1 2> cg.$1.log; grep -o 'Collected : [0-9]*' cg.$1.log | awk '{print $3}'; }
one() {
  b=$1
  base=$(count $b.base); new=$(count $b.new)
  echo "$b base=$base new=$new ratio=$(python3 -c "print(round($new/$base,3))") out=$(tr -d '\n' < out.$b.base)/$(tr -d '\n' < out.$b.new)"
}
ls *.pts | sed 's/\.pts$//' | xargs -P 2 -I{} bash -c "$(declare -f count one); one {}"
