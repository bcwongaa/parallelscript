#!/bin/bash
# usage: run.sh file.pts -> node / new (current main tree CLI) / base outputs
set -o pipefail
ulimit -f 409600
f=$1; b=${f%.pts}
cp "$f" "$b.mts"
echo "--- node"
PATH=$HOME/.local/node/bin:$PATH timeout 20 node --no-warnings --experimental-transform-types "$b.mts" 2>&1 | head -${LINES_MAX:-60}; echo "[exit ${PIPESTATUS[0]}]"
echo "--- new"
PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-s2/cache timeout 120 /home/bryan/projects/parallelscript/pts-bin/pts run "$f" 2>&1 | head -${LINES_MAX:-60}; echo "[exit ${PIPESTATUS[0]}]"
if [ -z "$NOBASE" ]; then
echo "--- base"
PTS_HOME=/tmp/pts-h03b/base PTS_CACHE_DIR=/tmp/pts-h03b-review/cache-base timeout 120 /tmp/pts-h03b/base/pts-bin/pts run "$f" 2>&1 | head -${LINES_MAX:-60}; echo "[exit ${PIPESTATUS[0]}]"
fi
