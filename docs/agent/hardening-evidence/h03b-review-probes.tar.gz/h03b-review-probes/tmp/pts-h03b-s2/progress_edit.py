"""Apply H03b's PROGRESS.md and HARDENING_PLAN.md edits (the fix commit's state: CI pending)."""
import re
import sys

R = "/home/bryan/projects/parallelscript/"


def rep(text, old, new):
    assert old in text, old[:80]
    return text.replace(old, new, 1)


p = R + "PROGRESS.md"
s = open(p).read()
lines = s.split("\n")
cur = [i for i, l in enumerate(lines) if l.startswith("- **Current slice:**")][0]
lines[cur] = (
    "- **Current slice:** H03b complete (D-178), so H03 is complete (H03a D-177, H03b D-178): an iterator result is the object the iterator handed back. "
    "A typed `it.next()`, `it.return!(v)` and `it.throw!(e)` give the object the method returned, its getters run when the caller reads them (C30); "
    "`yield*` hands inner results through (C32); an elision reads only `done` and closing an iterator reads nothing of `return()`'s result (C33, C41); "
    "result types hold objects of any layout, read by field on the runtime's shapes and by name otherwise, so `as IteratorResult<T>` of another layout "
    "never reads a wrong offset (C35) and getter literals are typed results (C03's typed half, superseding D-177's PTS1001); conversions from `any` keep "
    "the object (C42); generators, async generators and runtime iterators have their methods through `any`, and `any` arrays their iterators (C28, C45). "
    "Evidence: `docs/agent/hardening-evidence/h03b.md`; reviews: `h03b-review.md`; ledger: `docs/reviews/2026-10-13-final/CONSOLIDATED.md`. "
    "Fix commit: see the session log (exact-SHA CI recorded there once green)."
)
nxt = [i for i, l in enumerate(lines) if l.startswith("- **Next task:**")][0]
lines[nxt] = (
    "- **Next task:** H04 (compiler failure containment): clean source-located internal compiler errors at the CLI boundary, the risky assertions on "
    "touched paths, panic-failing smoke/fuzz tests; its rows C26 (skipped `run/keyed_assign_value.pts`), C34, C39 and C50. Parent and every subagent use "
    "**claude-opus-5-5 xhigh**, no fallback (owner directive 2026-10-15). Completion marker: `docs/agent/HARDENING_DONE`."
)
s = "\n".join(lines)

old_known_start = "Iterator results (H03b): a generator object or runtime iterator held as `any` has no methods (`h.next is not a function`, C28); `it.next()` on a typed iterator reads `done` and `value` at the call, a done result's too (C30, skipped `run/iterator_next_result_getters.pts`); `yield*` doesn't hand inner results through (C32); an array pattern's elision reads `value` (C33); `as IteratorResult<T>` accepts a literal of another layout and a `.value` read narrowed on `done` reads the field offset, a wrong value or SIGSEGV (C35, pre-existing; skipped `run/iterator_result_as_cast.pts`). "
new_known = (
    "Iterator results after H03b (D-178): `it.return?.(v)` and `if (it.return)` on an `Iterator<T>` are PTS1001 (C43), as are destructuring a result "
    "(`const { value } = it.next()`, C44) and `h[Symbol.iterator]()` through `any` (C48); a result literal that is a D-109 shape prints value first (C47); "
    "arrays' `keys()`/`entries()` are snapshots (C53); spreading a handed result drops its other own properties (C54); all H29. A typed `return()` result "
    "that isn't an object fails with internal shape names (C52, H22). Object rest of an interface value makes C that clang rejects (C50, H04). "
    "Intentional: `typeof h.next` through `any` is `\"undefined\"` (C46), and a handed result's dynamic `value` that its type copies is copied at each read (C51, D-071). "
)
s = rep(s, old_known_start, new_known)
s = rep(s, "- **Confirmed defects awaiting their fix tasks (H01b, D-175; H02, D-176; H03a, D-177):**",
        "- **Confirmed defects awaiting their fix tasks (H01b, D-175; H02, D-176; H03a, D-177; H03b, D-178):**")

h02_line = [l for l in s.split("\n") if l.startswith("**H02 (2026-10-15, base `389baf63d`):**")][0]
h03b_line = (
    "**H03b (2026-10-16, base `a65a75d62`):** the baseline full suite (the first session, clean base) gave **1,345 pass / 260 skip / 0 fail**, corpus 262 / 38 "
    "(H03a's final counts). With the fix, the same command exited 0 with **1,380 pass / 255 skip / 0 fail**, 10 tested / 19 no-test packages, corpus "
    "262 pass / 38 skip: 13 new files under `TestRun` (the threads one under 1, 2 and 4 threads) and 13 under `TestRunMatchesNode`, the three skipped "
    "known issues C03, C30 and C35 now run under both tests, `errors/iterator_result_getters.pts` is gone (D-177's PTS1001 superseded), and "
    "`TestRunMatchesNode/iterator_results_threads` skips (it uses `parallel`). Records: `docs/agent/hardening-evidence/h03b-suite.json` and `.jsonl.gz`. "
    "H01b's C02/C03/C18 probes: all 14 red probes now match Node (`BAD … run-match`, runner exit 1, expected) and the 8 controls match "
    "(`h03b-probes-after.json`); for the rows still open use the glob `probes/h01b/c0[5-7]-*.pts probes/h01b/parent/c0[5-7]-*.pts probes/h01b/parent/c20-*.pts`."
)
s = rep(s, h02_line, h02_line + "\n\n" + h03b_line)

log_anchor = "## Session log\n\n"
entry = (
    "- 2026-10-16: H03b done (D-178), so H03 is done. The previous session was cut off before committing, after the reproducer (worktree "
    "`agent-a230de3063844d81e`, seven RED tests and a report, commits `46e1946b1`/`66582145c` on its branch), the first fix, a full run and review round 1 "
    "(NOT READY: a failing test, missing tests, four should-fix items); this session kept all of it, imported the reproducer's tests and report, and fixed "
    "the rest: conversions from `any` keep objects (C42), results' property types readied for dynamic conversion, results of another layout converted when "
    "they leave for an interface (`ClassCast.FromResult`), unions with a result member read by name, every property order on the fast path (3.56× → 1.28× the "
    "base's instructions for done-first reads), and the method lookup round 1 added to typed `next()` (0.94× → 0.57×) replaced by the call's own TypeError. "
    "Six new regressions; all 17 H03b files RED on the base (`h03b-red.json`). Baseline 1,345 / 260 / 0; final 1,380 / 255 / 0. New ledger rows C41–C54. "
    "REVIEW2_SUMMARY Fix commit FIX_SHA.\n"
)
s = rep(s, log_anchor, log_anchor + entry)
open(p, "w").write(s)

p = R + "docs/agent/HARDENING_PLAN.md"
s = open(p).read()
old = "  - [ ] **H03b Iterator results through `any` and typed `next()`.** C28:"
new = ("  - [ ] **H03b Iterator results through `any` and typed `next()`.** Fixed 2026-10-16 (D-178), exact-SHA CI pending; C28, C30, C32, C33 and C35 fixed with "
       "C03's typed half and the related C41, C42, C45 and C49 and C43's `!` form; C43's other forms, C44, C47, C48, C53 and C54 → H29, C50 → H04, C52 → H22; "
       "`docs/agent/hardening-evidence/h03b.md`. Original text: C28:")
s = rep(s, old, new)
open(p, "w").write(s)
print("ok")
