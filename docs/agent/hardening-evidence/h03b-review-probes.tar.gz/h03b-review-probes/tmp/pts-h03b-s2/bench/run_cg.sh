#!/bin/bash
# Build each benchmark with the current CLI and count instructions under callgrind (PTS_THREADS=1) against the base binaries.
set -o pipefail
R=/home/bryan/projects/parallelscript
cd /tmp/pts-h03b-s2/bench
for f in *.pts; do
  b=${f%.pts}
  PTS_HOME=$R PTS_CACHE_DIR=/tmp/pts-h03b-s2/cache $R/pts-bin/pts build $f -o $b.new || { echo "$b build failed"; continue; }
  cp /tmp/pts-h03b-review/bench/$b.base $b.base
done
count() { PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=/dev/null ./$1 > out.$1 2> cg.$1.log; grep -o 'refs: *[0-9,]*' cg.$1.log | tr -dc 0-9; }
for f in *.pts; do
  b=${f%.pts}
  base=$(count $b.base) ; new=$(count $b.new)
  echo "$b base=$base new=$new ratio=$(python3 -c "print(round($new/$base,3))") out=$(cat out.$b.base | tr -d '\n')/$(cat out.$b.new | tr -d '\n')"
done
