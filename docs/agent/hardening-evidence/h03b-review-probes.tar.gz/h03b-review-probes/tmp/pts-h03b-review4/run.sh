#!/bin/bash
# usage: run.sh file.pts  -> prints node / new / r3 / base outputs (NOR3=1, NOBASE=1 skip)
set -o pipefail
ulimit -f 40960
f=$1
b=${f%.pts}
cp "$f" "$b.mts"
echo "--- node"
PATH=$HOME/.local/node/bin:$PATH timeout 20 node --no-warnings --experimental-transform-types "$b.mts" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
echo "--- new"
PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review4/cache timeout 180 /tmp/pts-h03b-review4/pts run "$f" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
if [ -z "$NOR3" ]; then
echo "--- r3"
PTS_HOME=/tmp/pts-h03b-s3/pre PTS_CACHE_DIR=/tmp/pts-h03b-review4/cache-r3 timeout 180 /tmp/pts-h03b-review3/pts run "$f" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
fi
if [ -z "$NOBASE" ]; then
echo "--- base"
PTS_HOME=/tmp/pts-h03b/base PTS_CACHE_DIR=/tmp/pts-h03b-review4/cache-base timeout 180 /tmp/pts-h03b/base/pts-bin/pts run "$f" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
fi
