#!/bin/bash
# batch.sh outdir prefix files...  (2 parallel); env passes through (NOR3/NOBASE)
out=$1; pre=$2; shift 2
mkdir -p "$out"
printf '%s\n' "$@" | xargs -P 2 -I{} bash -c 'f={}; n=$(basename ${f%.pts}); /tmp/pts-h03b-review4/run.sh "$f" > '"$out"'/'"$pre"'$n.txt 2>&1'
