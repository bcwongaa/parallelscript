import json,collections,sys
c=collections.Counter(); pk=collections.Counter(); corpus=collections.Counter(); fails=[]
for line in open(sys.argv[1]):
    try: e=json.loads(line)
    except: continue
    a=e.get('Action'); t=e.get('Test')
    if a in('pass','fail','skip'):
        if t:
            c[a]+=1
            if t.startswith('TestCorpusMatchesNode/'): corpus[a]+=1
            if a=='fail': fails.append(t)
        else: pk[a]+=1
print(dict(c), 'packages', dict(pk), 'corpus', dict(corpus), 'fails', fails[:10])
