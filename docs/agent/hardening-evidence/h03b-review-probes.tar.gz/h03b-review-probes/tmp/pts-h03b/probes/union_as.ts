type A = { kind: "a"; x: number };
type B = { kind: "b"; y: string };
function make(): A | B {
  return { kind: "a", e1: true, e2: true, e3: true, e4: true, e5: true, e6: true, e7: true, e8: true, e9: true, x: 5 } as A | B;
}
const v = make();
if (v.kind === "a") {
  console.log("x", v.x);
}
function getter(): A | B {
  return { kind: "a", get x(): number { return 7; } } as A | B;
}
const w = getter();
if (w.kind === "a") {
  console.log("x", w.x);
}
