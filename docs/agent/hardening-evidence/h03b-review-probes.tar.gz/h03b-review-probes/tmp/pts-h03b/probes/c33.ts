function results(label: string): any {
  let step = 0;
  return {
    [Symbol.iterator]() { return this; },
    next(): any {
      const current = step++;
      return {
        get done(): boolean { console.log(label, "read done", current); return current >= 3; },
        get value(): number { console.log(label, "read value", current); return current; },
      };
    },
    return(): any { console.log(label, "return"); return { done: true }; },
  };
}
const it: any = results("any");
const [, b] = it;
console.log("b", b);
const typed: Iterable<number> = results("typed");
const [, , c] = typed;
console.log("c", c);
