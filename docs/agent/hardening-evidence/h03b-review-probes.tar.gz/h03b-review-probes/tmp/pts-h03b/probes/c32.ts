function results(label: string, limit: number): any {
  let step = 0;
  return {
    [Symbol.iterator]() { return this; },
    next(sent: any): any {
      const current = step++;
      console.log(label, "next", current, sent);
      return {
        get done(): boolean { console.log(label, "read done", current); return current >= limit; },
        get value(): any { console.log(label, "read value", current); return current >= limit ? "ret" : current * 10; },
      };
    },
  };
}
function* outer(): Generator<number, void, any> {
  const r = yield* results("inner", 2);
  console.log("yield* gave", r);
}
for (const n of outer()) console.log("item", n);
const o = outer();
const first = o.next("a");
console.log("first", first.done, first.value);
