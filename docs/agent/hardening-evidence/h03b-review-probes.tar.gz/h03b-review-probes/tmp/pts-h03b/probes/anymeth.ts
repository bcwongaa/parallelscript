const a: any = [1, 2];
console.log(typeof a.push, typeof a.map);
const ag: any = (async function* () { yield 1; })();
ag.next().then((r: any) => console.log("async", r));
