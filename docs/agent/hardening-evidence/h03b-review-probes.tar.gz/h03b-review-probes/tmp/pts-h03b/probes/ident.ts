interface HasV { value: number; done: boolean }
class Foo { value = 1; done = false; }
const o: any = new Foo();
const i: HasV = o;
console.log(i === o);
const lit: any = { get value(): number { console.log("get value"); return 5; }, done: false };
const j: HasV = lit;
console.log("converted");
console.log(j === lit, j.value);
const plain: any = { value: 2, done: true };
const k: HasV = plain;
console.log(k === plain, k.value);
