function* g(): Generator<number, string, number> {
  const got = yield 1;
  console.log("got", got);
  try {
    yield 2;
  } finally {
    console.log("finally");
  }
  return "end";
}
const h: any = g();
console.log(typeof h.next, typeof h.return, typeof h.throw);
console.log(h.next());
console.log(h.next(5));
console.log(h.return(7));
console.log(h.next());
const m = new Map([["a", 1], ["b", 2]]);
const keys: any = m.keys();
console.log(keys.next());
console.log(keys.next().value);
console.log(keys.next());
const k2: any = g();
k2.next();
try { k2.throw(new Error("boom")); } catch (e: any) { console.log("caught", e.message); }
console.log(k2.next());
const self: any = g();
console.log(self[Symbol.iterator]() === self);
const arr: any = [1, 2, 3].values();
console.log(arr.next(), [...arr]);
