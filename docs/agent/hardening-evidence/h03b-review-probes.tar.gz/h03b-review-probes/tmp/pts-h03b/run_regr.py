#!/usr/bin/env python3
"""Runs H03b's regression files with the base and the new CLI and compares each with its expect block.

Each file is built and run with its CLI's own runtime (PTS_HOME), under a 4 GiB address-space cap and a
timeout; the first line where stdout differs from the expectation, the exit code and stderr's first line
are recorded. Usage: run_regr.py OUT.json FILE...
"""
import json
import os
import pathlib
import subprocess
import sys

CLIS = {
    "base": ("/tmp/pts-h03b/base/pts-bin/pts", "/tmp/pts-h03b/base", "/tmp/pts-h03b/cache-base"),
    "new": ("/home/bryan/projects/parallelscript/pts-bin/pts", "/home/bryan/projects/parallelscript", "/tmp/pts-h03b/cache-new"),
}
SCRATCH = pathlib.Path("/tmp/pts-h03b/regr")


def expectation(source: str) -> str:
    lines = source.splitlines()
    start = lines.index("// expect:") + 1
    out = []
    for line in lines[start:]:
        if not line.startswith("//"):
            break
        out.append(line[3:] if line.startswith("// ") else line[2:])
    return "\n".join(out) + "\n"


def run(cli: str, home: str, cache: str, path: pathlib.Path, name: str) -> dict:
    work = SCRATCH / name
    work.mkdir(parents=True, exist_ok=True)
    source = path.read_text()
    program = work / path.name
    program.write_text("\n".join(l for l in source.splitlines() if not l.startswith("// skip:")) + "\n")
    env = dict(os.environ, PTS_HOME=home, PTS_CACHE_DIR=cache)
    built = subprocess.run([cli, "build", str(program), "-o", str(work / "a.out")], env=env, capture_output=True, text=True, timeout=600)
    if built.returncode != 0:
        return {"outcome": "build error", "exit": built.returncode, "detail": (built.stdout + built.stderr).strip().splitlines()[:1]}
    ran = subprocess.run(["bash", "-c", f"ulimit -v 4194304; ulimit -f 40960; exec timeout 60 {work / 'a.out'}"], env=env, capture_output=True, text=True)
    want = expectation(source)
    if ran.stdout == want and ran.returncode == 0:
        return {"outcome": "pass", "exit": 0}
    got, exp = ran.stdout.splitlines(), want.splitlines()
    first = next((i for i in range(max(len(got), len(exp))) if (got[i] if i < len(got) else None) != (exp[i] if i < len(exp) else None)), None)
    detail = {"line": None if first is None else first + 1,
              "got": got[first] if first is not None and first < len(got) else None,
              "want": exp[first] if first is not None and first < len(exp) else None,
              "stderr": ran.stderr.strip().splitlines()[:1]}
    return {"outcome": "fail", "exit": ran.returncode, "detail": detail}


def main() -> None:
    out, files = sys.argv[1], [pathlib.Path(f) for f in sys.argv[2:]]
    results = {}
    for path in files:
        results[path.name] = {name: run(cli, home, cache, path, f"{name}/{path.stem}") for name, (cli, home, cache) in CLIS.items()}
        row = results[path.name]
        print(f"{path.name}: base {row['base']['outcome']} (exit {row['base']['exit']}), new {row['new']['outcome']}", flush=True)
    pathlib.Path(out).write_text(json.dumps(results, indent=1) + "\n")


if __name__ == "__main__":
    main()
