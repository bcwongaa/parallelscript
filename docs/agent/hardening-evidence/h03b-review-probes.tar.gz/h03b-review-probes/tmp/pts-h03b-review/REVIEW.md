# H03b review: iterator results through `any` and typed `next()`

Reviewer: claude-opus-5-5 (xhigh), read-only, 2026-10-16. Tree: the parent's uncommitted working tree at
`/home/bryan/projects/parallelscript` on base `a65a75d62`. CLI built from that tree into
`/tmp/pts-h03b-review/pts`; base CLI `/tmp/pts-h03b/base/pts-bin/pts`.

## Verdict: NOT READY

Two blockers. (1) The working tree fails a run test (`run/any_maps_error.pts`). The parent's green full
run (`/tmp/pts-h03b/full1.jsonl`, 01:07 to 01:13) finished before the last edit of `generator.c`, `pts.h` and
`dynamic_methods.c` (01:14:52), so it says nothing about this tree. (2) Three of the five acceptance
rows (C28, C32, C33) and the IteratorClose change (C41) have no regression test in the tree. The parent's
probes for them exist only in `/tmp/pts-h03b/probes/`.

Apart from these, the core design holds up. Every probe of the acceptance rows matches Node exactly:
getter read counts through nested `yield*`, a `done` getter that changes its answer, `return`/`throw`
forwarding, elisions, closing, methods through `any`, and threads. I found no memory-safety bug: no
segfault or garbage read in about 40 probes. The callgrind claims reproduce to the digit. The
SHOULD-FIX items are semantic gaps, all on paths outside the result types' own field reads. Most are
newly reachable but fail safely with a TypeError, and none of them is listed in D-178's known gaps.

## Ranked findings (one line each)

1. **BLOCKER** `run/any_maps_error.pts` fails: it still expects `keys -> TypeError: Iterators of maps and sets through 'any' are not supported yet` (C28 removed that error). Not on base.
2. **BLOCKER** No in-tree regression tests for C28 (methods through `any`), C32 (`yield*` hands results through), C33 (an elision reads only `done`), C41 (closing reads nothing of `return()`'s result), or `keys`/`values`/`entries` through `any`. Not on base.
3. **SHOULD-FIX** A conversion from `any`/`unknown` to a result type (`return anyValue` from `next(): IteratorResult<T>`, `x as IteratorResult<T>`, an annotated local, `await it.next()`) still copies the object into a D-109 shape. That runs the getters right away, including a done result's `value` getter inside `for…of`. This is C30's and D-146's defect through `any`, and D-178 doesn't list it. Pre-existing.
4. **SHOULD-FIX** A by-name read of `value` converts with cgen's union conversion to `T | undefined`. Dynamic data whose `T` is an interface throws `TypeError: Expected undefined | {name: string}, got Object`, and other object types are copied again at each read, so identity and writes are lost (`r.value === r.value` is false). New: base gave PTS1001.
5. **SHOULD-FIX** A result object of another layout that leaves the result types (to an interface parameter, or to a union with another object type) is read by the declared field kind: `TypeError: Cannot read property value of Object as number | undefined: it is declared number`, a message the runtime says "only a compiler bug makes". `{…, extra} as IteratorYieldResult<T>` passed to an interface parameter worked on base (base copied it) and now throws, so that part is a regression. D-178's gap names only getters.
6. **SHOULD-FIX (perf)** The fast path of `resultRead`/`resultStore` tests only the shape's first descriptor (`pts_type_object1`). It misses the shape's other property-order descriptors, which share the same struct (`pts_type_object1_2`). Literals written `{ done, value }` (done first) therefore always go by name, and `done` (a bool field) is never cached. A read loop over stored one-shape results costs 3.56x the base in instructions.
7. **NOTE** Spreading `{...r}` or object rest of a handed result drops the object's other own properties. This is consistent with how base spreads interface-typed values, and is newly reachable for results.
8. **NOTE** Docs: SPEC §9 has no H03b change-log entry (H02 and H03a have §9.120 and §9.121). §9.121 still lists the deleted `errors/iterator_result_getters.pts` and calls the now-unskipped tests "skipped known issues". `PROGRESS.md` still lists C28 to C35 as open. D-178's known gaps miss items 3 to 7.
9. **NOTE** Through `any`, arrays' `keys()` and `entries()` are snapshots taken at the call, with all pairs built in O(n). That matches typed code (D-110), but JS's are live. Tuples and typed arrays have no `keys`/`values`/`entries` through `any` (pre-existing: tuples have no methods through `any` at all).
10. **NOTE** `iteratorResultShape` sets `existing.Result = true` on any program shape with the same fields, so user data such as `{done: boolean; value: number | undefined}` pays the descriptor test and the by-name slow path on every read and write.
11. **NOTE** The interface reads in item 5 are safe only because descriptors carry declared types (`e.declaredTypes`). I found none of 384 emitted test programs without them, but `pts_field_address(…, NULL)` would read a double field as a `pts_value`, and a denormal would become a pointer. Worth an assertion or a comment.
12. **NOTE** In the threaded fallback of `last_step`/`handed_value` (`last_resumed` names another iterator), `it->value` and `it->result` are two words read apart. A race could pair an ABSENT value with an ABSENT result and leak `PTS_VALUE_ABSENT`. This needs a shared generator plus a `done` getter that resumes another iterator. Exotic, not reproduced.
13. **NOTE (pre-existing, other slices)** `const { a, ...rest } = i` with `i` typed as an interface emits C that clang rejects (`pts_value_from_number()` with no argument). Belongs to H04.

## Commands

`/tmp/pts-h03b-review/run.sh X.pts` copies X.pts to X.mts and runs, in order:
- Node: `node --no-warnings --experimental-transform-types X.mts`
- new: `PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review/cache /tmp/pts-h03b-review/pts run X.pts`
- base: `PTS_HOME=/tmp/pts-h03b/base PTS_CACHE_DIR=/tmp/pts-h03b-review/cache-base /tmp/pts-h03b/base/pts-bin/pts run X.pts`

It uses `timeout`, `ulimit -f 40960` and `pipefail`. Every probe is in `/tmp/pts-h03b-review/p/`. The three outputs of each one cited here are in `/tmp/pts-h03b-review/out/<name>.txt`.

---

## 1. BLOCKER: `run/any_maps_error.pts` fails on this tree

- **Command:** `cd /home/bryan/projects/parallelscript && PATH=$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH GOMAXPROCS=2 go test -p 2 ./pts/tests/ -run 'TestRun/any_maps_error' -count=1` (output: `out/any_maps_error.test.txt`)
- **new:** FAIL. Got `keys ok`; the expect block wants `keys -> TypeError: Iterators of maps and sets through \`any\` are not supported yet`.
- **base:** passes.
- **Node:** the test is `no-diff`. JS has map iterators, so `keys ok` is the right output.
- **At fault:** the test's expectation at `pts/tests/run/any_maps_error.pts:32`, and its header comment ("their iterators come with M4.1"). The behaviour changed in `pts/runtime/src/dynamic_methods.c:959-973` (`map_values`/`map_keys`/`map_entries`). The test pinned the old limitation, so updating it is legitimate; the commit message should say so.
- **Process:** the parent's `full1` run predates the final runtime edits (file mtimes: `dynamic_methods.c`, `generator.c` and `pts.h` at 01:14:52, the run ended at 01:13:56). After the fix the full suite must be rerun on the final tree.
- **My runs on this tree:** `^TestRun$` gave 417 pass, 92 skip, 1 fail (this test); `^TestRunMatchesNode$` gave 293 pass, 124 skip, 0 fail; `TestErrors` plus an iterator-themed corpus subset gave 86 pass, 0 fail.

## 2. BLOCKER: rows fixed without in-tree tests

The tree has tests for C30 (`run/iterator_next_result_getters.pts`, unskipped), C35 (`run/iterator_result_as_cast.pts`,
unskipped) and C03's typed half (`run/iterator_result_getters_typed.pts`, unskipped, and the new
`run/iterator_result_getter_literals.pts`). Nothing in `pts/tests/` exercises:
- C28: `h.next/return/throw` through `any` on generators, async generators and runtime iterators, and `h.return` being "not a function" on array iterators;
- C32: getter read counts through `yield*`, nested `yield*`, forwarded `return`/`throw` results handed through;
- C33: an elision reading only `done`. `run/array_pattern_lazy.pts:172` has an elision, but over results without getters;
- C41: IteratorClose reading nothing of `return()`'s result;
- `keys()`/`values()`/`entries()` of maps, sets and arrays through `any`;
- D-143 with handed results (threads stepping generators whose `yield*` hands results through).

The project rule says "a feature is done only when it has tests". Ready-made, Node-checked programs:
`p/c01_yield_star.pts`, `p/c02_yield_star_return_throw.pts`, `p/c03_lying_done.pts`, `p/c04b_close_any_return.pts`,
`p/c07_missing_methods.pts`, `p/d01_any_methods.pts`, `p/d05_any_iter_consumers.pts` and `p/f01_async.pts` (first half) all match Node
exactly on the new tree. The thread programs (`p/e01_threads_private.pts`, `p/e02_threads_shared.pts`, `p/e03_threads_forof_shared.pts`,
which print `bad 0` with PTS_THREADS=4 and 8) could become `// threads: 1 2 4` tests.
The parent's `/tmp/pts-h03b/probes/c28|c32|c33.pts` are the same idea.

## 3. SHOULD-FIX (pre-existing): `any`/`unknown` → result type copies, running getters early

- **Repros:** `p/c06_any_done_value_throws.pts` (the D-146 case through `any`), `p/c05_any_to_result.pts`, `p/f02_async_await_getters.pts`
- **c06.** Node: `done read` / `loop done`. New and base: `done read` / `Uncaught Error: value of a done result was read`.
  A `next(): IteratorResult<number>` whose body returns an `any` getter result has its `value` getter run although the result is done.
- **c05.** Node reads nothing until asked (`got r`, then `next done read`). New and base read `done` and `value` at the conversion:
  at `return make()` inside `next()`, at `make() as IteratorResult<number>`, and at `const x: IteratorYieldResult<number> = make()`.
- **f02** (`await ui.next()` on a typed `AsyncIterator`): new and base read both getters at the await.
- **At fault:** a dynamic value converted to a result type still goes through `fromValue` and `pts_value_convert`
  (`pts/cgen/cgen.go:1106`), whose `copy_object` calls getters (`pts/runtime/src/convert.c:287`). `ir.ResultObject`
  (`pts/cgen/classes.go:845`) keeps the program's objects as they are, but only at the `IteratorCall` site.
  Using ResultObject's rule (keep a `PTS_KIND_OBJECT`, copy only other dynamic data) for every Value-to-result conversion would close this.
- Not in D-178's known gaps, although D-178's reason ("getters on a typed `next()`'s result run when the caller reads them") and SPEC's
  "`x as IteratorResult<T>` … read by name" read as unconditional.

## 4. SHOULD-FIX (new): by-name `value` reads convert to `T | undefined` with the union's check

- **Repro:** `p/h07_class_any_value.pts`. A class `Entry { done = false as const; constructor(public value: any) {} }` holds JSON data and is used as `IteratorResult<Row>`.
  - Node: `array 2` / `row a` / `one a`
  - new: `array 2` / `row Expected undefined | {name: string}, got Object` / `one Expected undefined | {name: string}, got Object`
  - base: PTS1001 ×3 (`converting Entry to object1 | object2 …`)
  - For comparison, `const x: Row | undefined = rows[0]` works on both trees: the lowering converts to the member `Row`, not to the union (`p/h04_any_to_union_iface.pts`).
- **Repro:** `p/h02_any_array_values.pts`. A literal `{ done: false, value: raw /* any[] */, extra: true } as IteratorResult<[number, string], undefined>`.
  - Node: `true` / `99`
  - new: `false` / `1`. Each read of `r.value` converts the array again, so identity is lost and `r.value[0] = 99` is lost.
  - base: PTS1001.
- **Realistic shape of the bug:** `p/h03_json_rows.pts`, an iterator over `JSON.parse` rows whose results are class instances. Node mutates and prints;
  new throws `TypeError: Expected undefined | {n: number; name: string}, got Object`; base PTS1001.
- **At fault:** `resultValue` (`pts/cgen/classes.go:822-829`) calls `e.fromValue(value, t)` with `t` the union `T | undefined`
  (D-109's shapes always hold `value: T | undefined`). This is the same per-read conversion that D-177 moved to binding time for
  patterns (C37), for the same identity reasons. A member-aware conversion (undefined stays undefined, otherwise convert to `T` as
  `l.convert` does), or keeping the program's objects as they are, would fix both repros.

## 5. SHOULD-FIX (new reachability; partly a regression): result objects of another layout read through other types

- **Repro (regression):** `p/a01_iface_foreign.pts`. `{ done: false as const, value: 1e-310, extra: 7 } as IteratorYieldResult<number>`
  passed to `show(r: HasValue)` with `interface HasValue { value: number | undefined }`.
  - Node: `1e-310` / `show 1e-310`
  - base: `1e-310` / `show 1e-310` (base copied the literal at the `as`: `pts_value_convert(…, &pts_check_1)`)
  - new: `1e-310` / `Uncaught TypeError: Cannot read property value of Object as number | undefined: it is declared number`
- **Repro (new route):** `p/a04_iface_handed_one.pts`. A typed `next(): IteratorResult<number, number>` returns a literal with an extra
  property, and the caller passes `it.next()` to the same interface parameter. Node: `show 1.5` / `show 3`. New: the same TypeError.
  Base: PTS1001 (honest).
- **Repro (mixed union):** `p/a06_mixed_union2.pts`, `IteratorResult<number, number> | Plain`. Node: `1 false` / `3 false`. New: the same TypeError. Base: PTS1001.
- **At fault:** `asResult` (`pts/lower/unions.go:571-581`, reached from `pts/lower/classes.go:1064`, `pts/lower/objects.go:887`,
  `pts/lower/unions.go:184/202/516`) puts objects of any layout into result-typed values. Only `FieldRef`/`SetField` on result types
  were taught about this (`pts/cgen/classes.go:810-843`). An interface conversion from a result shape is still a static `ClassCast`,
  read by `fieldPlace` (`pts/cgen/classes.go:719`) through `pts_field_address`. The runtime's kind check `wrong_kind`
  (`pts/runtime/src/object.c:79`) throws, with the "only a compiler bug makes one" message.
- **Safety:** I tried to get a garbage read (a denormal double read as a `pts_value` pointer). Every program I emitted, including the 384
  test programs, carries declared types, so the kind check is always on (finding 11). D-178's known gap says only "a TypeError for a
  getter". A plain data property of another representation fails too, and that is the common case: a literal's `value: 1` is a double
  field, while the result types' `value` slot is a `pts_value`. Either convert such reads by name, keep the copy for conversions that
  leave the result types, or give an honest PTS1001.

## 6. SHOULD-FIX (perf): the fast path misses the shape's other property-order descriptors

- **Repro:** `bench/r4_donefirst_reads.pts`. A class iterator returns `{ done: false, value: this.i++ }`, the results are stored as
  `IteratorResult<number, number>[]`, and `r.done`/`r.value` are read 2,000,000 times.
  Callgrind (`PTS_THREADS=1 valgrind --tool=callgrind ./r4_donefirst_reads.{base,new}`): base 107,127,156, new 381,252,150 (**3.56×**).
  The same loop over results the runtime made (`bench/r2_shape_reads.pts`) is 1.205×.
- **Cause, verified in the emitted C (`bench/r4.new.c`):** the literals are allocated as `pts_type_object1_2`, the done-first order of
  shape `object1` (`pts_orders_object1 = {&pts_type_object1, &pts_type_object1_2}`), which uses the same struct `pts_class_object1`.
  Every read tests `type == &pts_type_object1` (`pts/cgen/classes.go:814`; stores at `:838`), so it goes to `pts_result_get`. There
  `done`, a bool field, is never cached (`pts/runtime/src/object.c:326-345` caches only `PTS_FIELD_VALUE` fields), so each read is
  `find_field` with strcmp, then `pts_value_of_slot`.
- **Suggested fix:** test every order descriptor of the shape, all of which share its struct. Frozen twins must still take the slow path
  for stores. Or cache field kinds in the site.
- **The draft's claims reproduce exactly** with 1M steps (`bench/callgrind-summary.txt`): `for…of` over a generator 1.030, `yield*`
  1.032, typed `next()` over one shape 1.085, over a union 0.851, over a class's iterator 0.570 (0.555 done-first), `for…of` over a
  class's iterable 1.033. Reads of stored union results got faster (`r1_union_reads` 0.716).

## 7. NOTE: spread and object rest of a handed result

- **Repro:** `p/b04_spread_rest.pts`
  - Node: `{ extra: 'e', value: 7 }` and `{ extra: 'e', done: false, value: 7, x: 1 }`
  - new: `{ value: 7 }` and `{ done: false, value: 7, x: 1 }`
  - base: PTS1001
- Base does the same for interface-typed values (`p/b05_spread_iface.pts`: Node `{ a: 1, b: 2 }`, new and base `{ a: 1 }`). So this is the
  existing static-spread limitation, now reachable for results. Worth a line in D-178's known gaps.

## 8. NOTE: docs

- `docs/SPEC.md` gains no §9 entry for H03b (compare §9.120 H02 and §9.121 H03a). §9.121's test list (around line 1550) still names
  the deleted `errors/iterator_result_getters.pts` and calls the three now-unskipped tests "skipped known issues".
- `PROGRESS.md:211` still lists C28/C30/C32/C33/C35 as open. Presumably that is updated with the commit.
- D-178's known gaps miss items 3 to 7. The other gaps it lists check out: a missing `done` reads as `false` through one shape and as
  `undefined` through a union; a write of a missing `value` throws `Cannot add property value, object is not extensible`
  (`p/i01_missing_done.pts`).

## 9. NOTE: array iterators through `any`

- `p/d02_array_iter_live.pts`: Node gives `[ 0, 1, 2 ]` and `[ [ 0, 10 ], [ 1, 2 ], [ 2, 3 ] ]` after a write and a push. New gives `[ 0, 1 ]` and
  `[ [ 0, 1 ], [ 1, 2 ] ]` both typed and through `any`. Typed code was the same on base (D-110). `array_entries`
  (`pts/runtime/src/dynamic_methods.c:742`) builds every pair at the call, so `bigArray.entries()` through `any` costs O(n) before the first `next()`.
  Its comment says "the array itself, read live; its indices; its pairs", but only `values()` is live.
- `p/d04_typed_arrays_any.pts`: tuples and typed arrays through `any` have no `entries`/`values` (a tuple not even `map`). Pre-existing,
  but tuples are arrays in JS, so "arrays' keys/values/entries through `any`" is partial.

## 10. NOTE: `existing.Result = true`

`pts/lower/generators.go:79` marks any earlier program shape with the key `{done: boolean; value: T}` as a result shape. That is
semantically harmless: all reads go by name off foreign layouts. But every field read and write of such user data now pays the descriptor test,
and, per finding 6, the slow path when the literal was written in another order. The comment ("an object type of the program's with
the same fields is one") could say so.

## 11. NOTE: interface-read safety depends on declared types

See finding 5. With `e.declaredTypes` false, `siteCheck` returns `NULL` (`pts/cgen/classes.go:857-861`) and `pts_field_address_slow`
skips the kind check. A foreign result's double field would then be read as a `pts_value`, and a denormal such as `1e-310` is a pointer in
JSC encoding. I could not make a program without declared types: all 384 emitted run tests and every probe carry checks. The
safety of item 5 therefore rests on that; worth an assertion or a sentence in D-178.

## 12. NOTE: two-word fallback in the threaded step memory

`last_step` (`pts/runtime/src/generator.c:77-84`) and `handed_value` read `it->value` and `it->result` separately when `last_resumed`
names another iterator. With a generator shared by threads, whose handed result's `done` getter resumes a second iterator between the
step and the read, the pair can tear: an ABSENT value with an ABSENT result returns `PTS_VALUE_ABSENT` to typed code. D-143 already
accepts skipped or repeated items. Leaking ABSENT is a little worse, but it needs a shared generator plus a reentrant getter. Not
reproduced: `p/e01`, `e02` and `e03` print `bad 0` at 4 and 8 threads, three runs each.

## 13. NOTE (pre-existing, out of scope): clang rejects object rest of an interface value

`p/z01_rest_iface_clang.pts` (`const { a, ...rest } = i` with `i: I`): Node prints `1 { b: 2 }`. New and base fail in clang:
`error: too few arguments to function call … pts_value_from_number()`. Route to H04.

---

## Verified good (evidence)

- **C28** (`out/d01_any_methods.txt`, `out/d05_any_iter_consumers.txt`, `out/f01_async.txt`): generator `next(v)`/`return(v)`/`throw(e)` through `any`,
  array/string/map/set iterators' `next()`, `ai.return` → `TypeError ai.return is not a function`, `keys/values/entries` of maps, sets
  and arrays, consumers (`Array.from`, `new Set/Map`, patterns, `for…of`, `Promise.all`), and async generators: all identical to Node.
  Base: `TypeError: h.next is not a function`. Only `typeof h.next` differs (`undefined`, as documented).
- **C30** (`p/b02_consumers.pts`, `p/b03_class_results.pts`, `p/j01_generics.pts`, `p/l01_result_types.pts`): handed results of other layouts (extra
  properties, getters, class instances with inherited getters, private `#value`) are read by name through FieldRef, generics, a generic class field,
  `.map` callbacks, `Map` values, compound and logical assignments, `Object.freeze`, `JSON.stringify`, `Object.keys/values`, `in` and optional chains.
  All match Node; base rejects them with PTS1001.
- **C32** (`out/c01_yield_star.txt`, `out/c02_yield_star_return_throw.txt`, `out/c03_lying_done.txt`, `out/c07_missing_methods.txt`): read counts at
  every level of nested `yield*` for `for…of`, typed `next()`, spread and patterns; a `done` getter answering false to `yield*` and true to the
  consumer (the generator stays suspended and a later `next()` resumes it); `return("keep")` handing a not-done result through; throw without
  a `throw` method. All identical to Node; base differs.
- **C33/C41** (`out/c04b_close_any_return.txt`): elisions read only `done`; break, pattern end and throw close without reading `return()`'s result;
  a non-object `return()` result gives Node's TypeError on break and is dropped on a throw. Identical to Node; base read `value` and `done`.
- **C35** (`p/a01`'s direct read, `run/iterator_result_as_cast.pts`): narrowed reads of asserted literals go by name.
- **Threads (D-143)** (`p/e01_threads_private.pts`, `p/e02_threads_shared.pts`, `p/e03_threads_forof_shared.pts`): private generators with handed
  results in 400 `parallel for` iterations, and 32 to 64 workers racing on one shared generator and one shared object iterator through
  typed `next()` and `for…of`: no crash, every value valid, at PTS_THREADS=4 and 8.
- **Lowering:** unusual call forms (`p/m01_call_forms.pts`) give the base's diagnostics and no panic. `as` from `T | undefined` to a result
  shape still throws TypeError on undefined (`p/n01_as_from_undefined.pts`).
- **GC:** the new `pts_iterator.result` lives in `GC_MALLOC`'d, conservatively scanned frames and iterators. `last_resumed` is uncollectable.
  `PTS_VALUE_ABSENT == 0` makes zero-filled iterators (`from_sync`, async generators) start with no result.

## Code-quality remarks (minor)

- `pts_generator_delegate` repeats `last_step`'s `last_resumed` test inline before calling it. That is fine for the fast path, but a one-line comment
  saying so would help.
- `method_mode` casts away `const` (`pts_value_from_object((pts_iterator *)it)`). `pts_value_is_async_generator` could take the type pointer instead.
- The new code otherwise matches the surrounding style: comments in the codebase's voice, D-numbers cited, and helpers named after their outcome
  (`resultRead`, `asResult`, `isObjectOfProgram`). `isObjectOfProgram`'s doc line ("which their properties can be found by") reads awkwardly.
