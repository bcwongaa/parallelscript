# H03b review, round 3: check of the round-2 fixes

Reviewer: claude-opus-5-5 (xhigh), read-only, 2026-10-16. Tree: the parent's uncommitted working tree on base `a65a75d62`.
No compiler or runtime source changed after my build (`find … -newer` was empty at 03:24). CLI: `/tmp/pts-h03b-review3/pts`
(built 03:04:27), run with `PTS_HOME=/home/bryan/projects/parallelscript`. Base CLI: `/tmp/pts-h03b/base/pts-bin/pts`.
For before/after checks of compiler-only changes I also ran round 2's CLI (`/tmp/pts-h03b-review2/pts`) against the current
runtime. Round 2's compiler emits no `.result` flag, so that run shows the tree without N1 and S3.

## Verdict: NOT READY (no blocker; two small regressions, plus one older hole now cheap to close)

All five round-2 fixes work as described (S1, S2, S3, N1, N3), and none of the round-2 or round-1 probes changed for the worse.
Two of the fixes added a regression each, and each needs only a few lines:
- **R1 (N1, a regression from base).** Through `any`, a union of a result type and another object type now keeps an object as
  the result member when the other member needed a copy. Reads after narrowing then throw the "only a compiler bug"
  TypeError. Base printed Node's output.
- **R2 (S3, a regression from round 2).** `r.value += yield v` on a result reads the getter twice, once before and once after
  the yield. Round 2 read it once, as Node does.
- **R3 (in the slice since round 1).** A result-typed field holding an object of another layout leaks into an interface
  through `any`, because `pts_check_implies` trusts the result check's declared types. This contradicts D-178's claim that
  the conversion "holds for every route to an interface". Base gave PTS1001. With the new `result` flag the fix is one line.

I tried fixes for R1 and R3 in a scratch copy of the runtime (`/tmp/pts-h03b-review3/tree`, diff in
`experiment-convert.diff`). With them, all four R1/R3 repros print Node's output. The 20 slice tests still print their
expect blocks, and `n1_kinds` and `s2_routes` are unchanged. I didn't run the full suite with them.

## Round-2 findings: status

| # | Round 2 | Now | Evidence |
|---|---|---|---|
| S1 | typed `return!`/`throw!` on runtime iterators finished them | **fixed** | `p03` matches Node. `p/s1_kinds.pts` matches Node for every kind: array `values`/`entries`/`keys`, set `values`/`entries`/`[Symbol.iterator]`, map `entries`/`values`/`[Symbol.iterator]`, string, `Iterator<number>`- and `IterableIterator`-typed. In each case the iterator goes on afterwards. `p/s1_any.pts` (through `any`, `Float64Array.values()`, `yield*` forwarding) and `matchAll`'s iterator also match. Generators (before start, suspended, done, typed `Iterator<T>`), object iterators and a class's generator method are unchanged. |
| S2 | relaxed cast and contextual conditional skipped `FromResult` | **fixed** | `p11`, `p12`, `p14`, `routes/r_cond` match Node. `p/s2_routes.pts` also matches: relaxed casts of an asserted literal, a literal with `note`, a getter literal (1 read), own-shape yield and return results, conditionals (both orders, nested, result vs result), an arrow returning a conditional, and an assignment of a conditional. |
| S3 | postfix `r.value++` read the getter twice | **fixed** (but see R2) | `p08`, `p07` match Node. `p/s3_ops.pts` matches Node for 39 forms: `++`/`--` both ways, every arithmetic, bitwise and shift compound operator, `\|\|=`/`&&=` on truthy and falsy values, `??=`, element access `r["value"]++`, statement position, `done \|\|=`/`&&=`, own-shape receivers, a narrowed union receiver and an unnarrowed `IteratorResult<number, number>` receiver. |
| N1 | `fromValue` kept objects only for exact result types | **fixed** (but see R1) | `p02` and `p15` match Node. `p/n1_kinds.pts`: class instances, unrelated instances, `Error`s and frozen objects are now kept as JS keeps them (the base copied them or threw). A frozen object kept as a result throws on a write, as Node does. Arrays, tuples, primitives, `null` where only `undefined` is allowed, functions, Maps and Dates still fail the conversion, as on the base. JSON objects are still copied (identity `false`, as on the base). Writes through `any` into result fields, arrays and Map values keep the object. |
| N2 | identity/writes lost through an interface copy | **declared and pinned** (`run/iterator_results_copied.pts`, D-178) | `p04` unchanged; D-178 now spells out the consequences |
| N3 | a `yield*` statement skipped the done result's `value` | **fixed** | `p01b` and `p01` match Node. `p/n3_yield_star.pts` and `p/n3b_places.pts` also match Node: two `yield*` in one expression, a call argument, loops, `try/finally` with `return()`/`throw()` forwarding, discarded `yield*` in `if`, comma and conditional, nested generators, arrays/strings/sets, `catch`/`finally` blocks, `switch`, labeled blocks, templates, and `yield (yield* …)`. Async generators never reach `delegation` (PTS1001 on both trees, `p/n3_async.pts`). |
| N4 | non-boolean `done` through a union | docs (D-178 now states both behaviours) | `p20` unchanged |
| N5 | stale docs (C47, bench) | C47 fixed in the docs; the **bench numbers are still stale**: NOTE 1 | `g3`, `adj_p7_misc` match Node |
| N6 | no pins of the C51/N2 gaps | **fixed** (`iterator_results_copied.pts`, `no-diff` with Node's output in its comment) | |

All 48 round-2 probes were rerun (`out2/`). 43 match Node. The other five are the declared `g1`, `g2`, `g4` (PTS1001),
`p04` (N2) and `p20` (N4), and their new-tree outputs equal round 2's. All 55 round-1 probes were rerun too (`out1/`). Every
change from round 2 is a path in a message, so the set of differences from Node is round 2's: declared gaps and
pre-existing issues.

---

## R1. SHOULD-FIX (regression from base): the `result` flag wins over a union's other object member

- **Repro:** `p/n1_union_min.pts` (members in the order the type is written) and `p/n1_union_min2.pts` (the other order);
  `p/n1_union_anyfields.pts` is a realistic variant, where the object's fields come from parsed JSON (`{ x: data.x, y: data.y }`).
  ```ts
  interface Point { x: number; y: number }
  const loose: { x: number | string; y: number } = { x: 3, y: 4 };
  const raw: any = loose;
  const u: IteratorResult<number> | Point = raw;
  if ("x" in u) console.log("point", u.x, u.y);
  ```
- **Node:** `point 3 4`. **Base:** `point 3 4`. **Round-2 compiler on today's runtime:** `point 3 4`.
- **New:** `Uncaught TypeError: Cannot read property x of Object as number: it is declared number | string`. The anyfields
  variant says `… it is declared value`. Both member orders fail, because cgen puts the result shapes first in the
  union's check.
- **Cause:** `convert` (`pts/runtime/src/convert.c:476`) returns `true` for any `PTS_KIND_OBJECT` when `check->result` is
  set, even in the union's first, no-copy pass (`:454-466`). The result member therefore takes every program object
  before the copy pass can copy it into `Point`. Reads through `Point`'s sites then meet a field of another kind
  (`wrong_kind`). An object that fits `Point` as it is was unaffected, since it is the same pointer either way. That
  covers instances narrowed by `instanceof` and literals that fit, which is why `p/n1_unions_rest.pts` matches Node.
  JSON (hash-map objects) is unaffected too.
- **Fix (validated in the scratch tree):** keep an object as a result only after the union's other members have failed,
  both as it is and by a copy. My experiment adds a `results_last` flag to `converting`, which is set for the member
  calls of the first two passes and cleared at the top of `convert`, so nested conversions still keep results. A third
  pass then runs the result members. An alternative is to emit the flag only where cgen's `isResultType` holds, so that
  the runtime's rule matches `fromValue`'s.
- **Pin:** add `n1_union_min` (or the anyfields variant) to `run/iterator_results_from_any.pts`.

## R2. SHOULD-FIX (regression from round 2): a compound assignment with a yield on its right reads the getter twice

- **Repro:** `p/s3_yield_min.pts`
  ```ts
  let reads = 0; let v = 5;
  const r = { done: false, get value() { reads++; return v; }, set value(x: number) { v = x; } } as IteratorYieldResult<number>;
  function* g(): Generator<number, void, number> { r.value += yield 1; }
  const it = g(); it.next(); it.next(10);
  console.log(v, "reads", reads);
  ```
- **Node:** `15 reads 1`. **Round-2 compiler:** `15 reads 1`. **New:** `15 reads 2`. **Base:** PTS1001 (the `as`).
- `p/s3_yield.pts` and `p/s3_yield_logical.pts` show the same for `+=`, `*=` and `-=` in generators. The trace is
  `get,resume1,get,set`, where Node gives `get,resume1,set`.
- **Cause:** S3 makes `readAndStore` (`pts/lower/lower.go:2978-2980`) bind `current = <read>` for result receivers. Then
  `compoundAssignment` (`:2826-2828`) replaces the read with D-145's `keptCurrent` value, which was read before the yield,
  but the `Bind` around the expression still runs the read after the resume, unused. You can see it in the emitted C:
  `pts_value current_2 = …pts_result_get(…)` while the sum uses `pts_frame->current`. Interface receivers already behave
  this way: the probe's `HV` part shows `get,resume,get,set` on round 2 as well.
- **Fix:** when `keptCurrent[node]` exists, bind `current` to the kept value (or skip the read). This also fixes the
  interface case.
- **Pin:** add the repro's generator to `run/iterator_results_other_types.pts`'s update section.
- Related, already ledgered: `r.value ||= yield 1` yields before reading (`resume1,get,set` in both rounds), and in
  general `x ||= yield 1` yields even when it short-circuits (`p/d145_logical_yield.pts`, base too). That is
  CONSOLIDATED C25 (open, H08), not this slice.

## R3. SHOULD-FIX (in the slice since round 1; base PTS1001): result checks imply interfaces by their declared types

- **Repro:** `p/i11d_typed.pts`, which has no assertion except the `as any` it converts through:
  ```ts
  interface Wrapper { r?: { value: unknown } }
  const it: Iterator<number, number> = { next(): IteratorResult<number, number> { const own = { done: false, value: 3.5, extra: "x" }; return own; } };
  class Holder { r: IteratorResult<number, number> = it.next(); }
  const w: Wrapper = new Holder() as any;
  console.log("typed", w.r?.value);
  ```
  Also `p/i11b_optional.pts` (an optional property) and `p/i11c_union_prop.pts` (a required `{ value: unknown } | undefined`
  property, through a field and through a getter).
- **Node:** `typed 3.5` (`value 2.5`; `field 1.5`, `getter 2.5`). **New and round-2 compiler:**
  `Uncaught TypeError: Cannot read property value of Object as value: it is declared number`. **Base:** PTS1001 (the
  literal can't become a result there).
- **Cause:** converting `Holder` to `Wrapper` asks `object_fits`, which reaches `place_implies` and then `implies`
  (`convert.c:213`) with the field's declared check (the result union) and the property's check. `properties_imply` holds
  for the result shapes, so `Holder` is kept as a `Wrapper`. The field's actual object, however, is of another layout, a
  thing D-178 allows only for result types. `w.r` then gives that literal as `{ value: unknown }`, whose site meets a
  `number` field where it expects a `pts_value`. When the property is required and of object type (`p/i11_nested_implies.pts`),
  the slots differ and the holder is copied, so that case works.
- **Fix (validated):** in `implies`, a result check implies no non-result object check:
  `if (sub->kind == PTS_CHECK_OBJECT && sub->result && super->kind == PTS_CHECK_OBJECT && !super->result) return false;`.
  The holder is then copied (D-071), and its field is converted with the interface's check. `pts_optional_get_slow`
  (`object.c:266/273`) uses the same implication but is reached only through static casts, which the compiler already
  rejects for result-typed fields (`providesProperty` wants the same type). If the parent would rather defer this, D-178's
  "every route" sentence should then say "every static route", and the ledger should get a line.

---

## NOTEs

1. **Bench numbers in the docs are stale** (callgrind, `PTS_THREADS=1`, final tree, `bench/`):

   | Program | Base | Round 2 | Final | Ratio | vs round 2 |
   |---|---|---|---|---|---|
   | `b4_user_next` | 1,341,618,634 | 760,227,095 | 733,469,469 | 0.547 | −26.8M (S1's `always_inline`) |
   | `b4d_user_next_donefirst` | 1,341,606,538 | 731,228,166 | 704,469,007 | 0.525 | −26.8M |
   | `b1_next_union` | 489,956,963 | 417,969,392 | 415,964,994 | 0.849 | −2.0M |
   | `b2_next_shape` | 247,951,440 | 277,346,026 | 275,951,376 | 1.113 | −1.4M |
   | `b3_user_forof` | 899,970,156 | 943,973,078 | 929,976,691 | 1.033 | −14.0M (N5's inline, as predicted) |
   | `b3d_user_forof_donefirst` | 866,965,599 | 910,972,984 | 896,972,071 | 1.035 | −14.0M |
   | `b5_delegate` | 247,799,450 | 255,799,349 | 257,803,892 | 1.040 | +2.0M (NOTE 3) |
   | `b6_forof_gen` | 133,788,732 | 137,788,707 | 137,788,783 | 1.030 | 0 |
   | `r1_union_reads` | 599,493,819 | 429,417,924 | 429,415,860 | 0.716 | 0 |
   | `r2_shape_reads` | 107,257,863 | 129,273,546 | 129,276,018 | 1.205 | 0 |
   | `r3_user_shape` | 180,178,071 | 182,201,718 | 182,201,981 | 1.011 | 0 |
   | `r4_donefirst_reads` | 107,127,156 | 137,142,146 | 137,142,162 | 1.280 | 0 |
   | `i1_own_incr` (new: 40M read-modify-writes of an own-shape result) | 1,780,795,818 | 2,160,791,600 | 2,120,796,171 | 1.191 | −40.0M (S3's bound read helps) |

   - `docs/agent/hardening-evidence/h03b.md`'s table is round 2's tree: b4 0.567, b2 1.121, b5 1.032, b3d 1.060.
   - D-178 says "1.06× done first" and "`yield*` 1.03×". The final numbers are 1.035 and 1.040.
   - The parent's own 03:10 log for b3d (918,972,179) doesn't reproduce. Its binary
     (`/tmp/pts-h03b-s2/bench/b3d_user_forof_donefirst.new`) counts 896,972,503 under my run, like my two builds
     (896,972,071 and 896,974,898). That run was probably perturbed by GC helper spinning under host load.
   - D-178 could add that read-modify-writes of own-shape results cost about what reads do: `i1` at 1.19×, about 8
     instructions per operation for the descriptor tests on read and store.
2. **S1's message text is the callee's raw source text** (cosmetic; the same mechanism as object iterators' message in
   round 2). In `p/s1_text.pts`, `(av).return!()` gives `(av).return is not a function`, and a call split over two lines
   keeps its newline and indentation. Node prints `av.return` in both cases. Stripping parentheses and whitespace from
   `text` (or using the property access's expression text plus `.name`) would match.
3. **N3's frame slot.** Every `yield*` adds a `pts_value delegated` frame member, and its value stays reachable until the
   frame dies. In `b5`, clang now saves `r14` in `pts_step_fn_outer` (a push and a pop), which is +2 instructions per
   delegated step: 34.0M becomes 36.0M, and b5 goes from 1.032 to 1.040 against the base. It is harmless; NOTE 1's table
   includes it.
4. **Pre-existing, outside H03b, apparently unledgered:** `a ?? b` / `a || b` with an interface-typed `a` and a class
   instance `b`, where a third interface goes, casts `a` to `b`'s class. `p/x_nullish_iface.pts`: Node `nullish 2.5`;
   new **and base** `Uncaught TypeError: The value narrowed to Other is not an instance of it`. The emitted C is
   `pts_value_as_instance(value_2, &pts_type_Other)` for the left operand. It hits results too
   (`p/s2_nullish.pts`, `p/s2_or.pts`, `p/s2_nullish_own.pts`; the same on base), but the cause isn't result-specific
   (`p/s2_nullish_ctl.pts`). It is worth a ledger line.
5. **Pre-existing conditional limitation (not results):** `flag ? t : { value: 7 }` or `flag ? t : new Other(5)` where an
   interface with an optional property goes is PTS1001 for plain classes too (`p/s2_ctl.pts`). It is an honest
   diagnostic.

## Verified good (new evidence this round)

- **S1:** every runtime iterator kind, generators and object iterators (see the table). `pts_throw_new` is `_Noreturn`,
  so the uninitialized `done` in `pts_iterator_call`'s third branch can't be read.
- **S2:** besides the routes in the table, equality (`commonClass` in `operation`) stays a plain pointer cast, which is
  right for identity. `interfaceCast`'s relaxed path still records its `relaxedCast`, and `checkRelaxedCasts` sees the
  Result class as the source. An own-shape result passes as it is, and `note` reads `undefined`.
- **S3:** all 39 operator forms match Node (`p/s3_ops.pts`). For an own-shape receiver the bound read is a C local inside
  the statement expression, not a frame member, and it is 40M instructions cheaper than round 2 (`i1`).
- **N1:** `pts_check` gained a trailing `bool`, and every runtime initializer is designated, so the field defaults to
  `false`. `pts_check_same` is pointer identity, so the flag doesn't affect it. `pts_storable` (writes through `any`, D-072)
  keeps objects for result fields, array elements and Map values (`n1_kinds`), and fails for arrays, tuples and numbers as
  the base does. The inline path of `fromValue` for `IteratorResult<T> | undefined/null` agrees with `convert`.
- **N3:** the post-loop read never runs on the `return()` path (`leaveFunction` leaves first). D-145 sees the new local as a
  plain local of the function and keeps no second copy. `return yield* …` inside `try/finally` and two `yield*` in one
  expression keep their values across later yields (`n3_yield_star`, `n3b_places`).
- **Threads (D-143):** `run/iterator_results_threads.pts`, built from this tree, passed 10 of 10 runs (5 at
  `PTS_THREADS=4` and 5 at 8). Round-1 `e01`-`e03` give `bad 0` at 4 and 8.
- **Tests:** focused `^(TestRun|TestRunMatchesNode)$/(iterator|yield_star|array_pattern|any_maps|generator|for_of)`: **105
  pass, 7 skip, 0 fail** (`gotest-focus.jsonl`). The 7 skips are expected: `any_maps` has no expect block, and the rest
  are `no-diff`/`parallel` or older known skips. `go test ./pts/lower/ ./pts/cgen/` ok; `TestErrors` ok.

## Test quality

- The new and extended files pin the round-2 defects well. They cover runtime iterators' `return!`/`throw!` (array, map
  keys, string), a `yield*` statement's value read, the relaxed and contextual routes with the 1e-310 literal, the
  postfix, prefix, compound and narrowed updates, a union with `undefined`, arrays, an `any` array, a Map write through
  `any`, and `Promise.all`.
- `iterator_results_copied.pts` is a fair `no-diff` pin: Node's output is in its comment, and the test exercises both
  copies (C51 and the interface's).
- Gaps: R1 (a union with a non-result object member, through `any`), R2 (a compound assignment with a yield on its right
  side) and R3 (a result-typed field read through an interface after `as any`) aren't covered. Sets, entries iterators and
  typed arrays for S1 are covered only by my probes, which is acceptable since the runtime test is by type.

## Commands and files

- `run.sh X.pts` prints Node, new and base outputs (`NOBASE=1` skips the base). `batch.sh` runs probes 2 at a time.
- Probes: `p/` (this round), `r2p/` (round 2's, including `routes/`, `gaps/`, `repro/`), `r1p/` (round 1's). Outputs:
  `out/` (this round), `out2/` (round-2 probes), `out1/` (round-1 probes), `out-exp/` (the scratch-runtime experiment).
- Bench: `bench/` (programs, binaries, `cg.*`; `i1_own_incr.{base,r2,new}`; `o.r2.s`/`o.new.s`, the disassembly of b5's
  step function).
- Experiment: `tree/` (a copy of `pts/runtime`, `pts/third_party` and `pts/lib`, run with `PTS_HOME=/tmp/pts-h03b-review3/tree`).
  Its patch is `experiment-convert.diff`. Nothing in the repository was edited.
