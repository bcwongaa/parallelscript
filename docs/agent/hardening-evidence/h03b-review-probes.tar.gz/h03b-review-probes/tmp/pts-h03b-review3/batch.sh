#!/bin/bash
# batch.sh outdir prefix files...  (NOBASE run, 2 parallel)
out=$1; pre=$2; shift 2
printf '%s\n' "$@" | xargs -P 2 -I{} bash -c 'f={}; n=$(basename ${f%.pts}); NOBASE=1 /tmp/pts-h03b-review3/run.sh "$f" > '"$out"'/'"$pre"'$n.txt 2>&1'
