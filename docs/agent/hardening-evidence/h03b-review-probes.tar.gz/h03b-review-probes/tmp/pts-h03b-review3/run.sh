#!/bin/bash
# usage: run.sh file.pts  -> prints node / new / base outputs
set -o pipefail
ulimit -f 40960
f=$1
b=${f%.pts}
cp "$f" "$b.mts"
echo "--- node"
PATH=$HOME/.local/node/bin:$PATH timeout 20 node --no-warnings --experimental-transform-types "$b.mts" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
echo "--- new"
PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review3/cache timeout 120 /tmp/pts-h03b-review3/pts run "$f" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
if [ -z "$NOBASE" ]; then
echo "--- base"
PTS_HOME=/tmp/pts-h03b/base PTS_CACHE_DIR=/tmp/pts-h03b-review3/cache-base timeout 120 /tmp/pts-h03b/base/pts-bin/pts run "$f" 2>&1 | head -${LINES_MAX:-80}; echo "[exit ${PIPESTATUS[0]}]"
fi
