# H03b review, round 2: iterator results through `any` and typed `next()`

Reviewer: claude-opus-5-5 (xhigh), read-only, 2026-10-16. Tree: the parent's uncommitted working tree on base
`a65a75d62`, including the runtime change made during this review (`call_object_method`, `generator.c` mtime
02:36:16). I rebuilt the CLI after that change: `/tmp/pts-h03b-review2/pts`. Base CLI: `/tmp/pts-h03b/base/pts-bin/pts`.
Probe outputs from before the rebuild (clang `call_method` arity errors) were thrown away and rerun.

## Verdict: NOT READY (no blocker; three small SHOULD-FIX defects to fix and pin first)

The slice is in much better shape than in round 1. Both round-1 blockers are closed, and so are findings 3, 4, 6, 9, 10
and 12. Finding 5 is only partly closed. All 20 slice tests pass (`TestRun` plus `TestRunMatchesNode`), the threads test
passes 10 of 10 runs at 4 and 8 threads, and the compiler unit tests and `TestErrors` pass. I found no crash, garbage
read or GC or thread-safety defect.

Three SHOULD-FIX defects remain, each a few lines to fix:
- **S1 (new).** A typed `it.return!()` or `it.throw!()` on the runtime's iterators (arrays, maps, sets, strings) doesn't
  throw. It silently finishes the iterator. Base gave PTS1001 here, and D-178's text claims the TypeError.
- **S2 (round-1 #5, partly open).** Round-1 #5 survives on two lowering routes. One of them is a regression: base ran
  these programs correctly, and now they throw the "only a compiler bug" TypeError.
- **S3 (new).** A postfix `r.value++` on a result runs its getter twice.

## Round-1 findings: status

| # | Round 1 | Now | Evidence |
|---|---|---|---|
| 1 | BLOCKER `any_maps_error` failed | **fixed** | expects `keys ok`; passes `TestRun` (skipped in `TestRunMatchesNode` by its `no-diff`) |
| 2 | BLOCKER no tests for C28/C32/C33/C41 | **fixed** | 13 new and imported tests, all pass in both tests; see "Test quality" |
| 3 | `any` to result type copies (getters early) | **fixed for result types**; residual NOTE N1 | `c05`, `c06`, `f02` now print Node's output |
| 4 | by-name `value` reads used the union's check | **fixed** (the per-read copy is now ledger C51, declared) | `h07` matches Node; `h02`, `h03` differ only by C51 |
| 5 | result of another layout read through an interface | **partly fixed**: S2 below | `a01`, `a02`, `a04`, `a06` match Node; `p12`, `p14`, `routes/r_cond` fail |
| 6 | fast path missed done-first orders (3.56x) | **fixed** | `r4_donefirst_reads` 1.280x (callgrind, below) |
| 7 | spread drops properties | declared gap (C54) | `b04` unchanged |
| 8 | docs | **mostly fixed**; NOTE N5 (stale C47, stale bench numbers) | SPEC §9.122, D-178, ledger C41 to C54 |
| 9, 10 | comments | **fixed** | `dynamic_methods.c` `array_values`, `generators.go` `iteratorResultShape` |
| 11 | interface reads safe only through declared types | unchanged, still relevant to S2's routes | every program I emitted carries checks, including a minimal one (`p/p22_min.pts`) |
| 12 | ABSENT leak in threaded fallback | **fixed** | `handed_value` returns undefined; `pts_generator_delegate`'s fallback then reads as undefined too |
| 13 | clang rejects interface object rest | pre-existing, ledger C50 (H04) | `z01` unchanged |

All 58 round-1 probes were rerun against Node (`out/r1_*.txt`). Every difference is a declared gap (C46, C51 to C54,
C44, D-110) or pre-existing (`d03`/`d04` tuples and typed arrays through `any`, `m01` call forms, `z01`).

---

## S1. SHOULD-FIX (new): a typed `return!`/`throw!` on a runtime iterator silently finishes it

- **Repro:** `p/p03_return_bang_runtime_iters.pts` (array, map-keys and string iterators, and an array iterator typed `Iterator<number>`)
- **Node:** `ai TypeError ai.return is not a function`, then `{ value: 2, done: false }` (the iterator goes on); the same for
  `mi.return`, `si.throw` and `it.return`.
- **New:** `{ value: undefined, done: true }` for each `return!()`, and the iterator is finished (every later `next()` says done).
  `si.throw!(e)` throws `The iterator does not provide a 'throw' method.` and also finishes the iterator.
- **Base:** PTS1001 `` `ai.return` is not supported yet `` (4x), an honest diagnostic.
- **Cause:** `pts_iterator_call` (`pts/runtime/src/generator.c:536-546`) sends runtime iterators to `resume_runtime_iterator`
  (`:446`), which follows yield*'s rules. A missing `return` finishes the iterator with the value, and a missing `throw`
  closes it and throws yield*'s TypeError. A direct method call needs call semantics. The parent made this split for
  object iterators (`call_object_method` against `call_object_iterator`) but not for the runtime's own iterators.
  Through `any`, `method_mode` (`:593`) gets this right.
- **Contradicts D-178** ("An object without the method throws JS's TypeError (`it.return is not a function`), named by the
  call's source text"). No test covers it: `yield_star_result_edges.pts`'s new section uses a program object.
- **Fix:** in `pts_iterator_call`, for a runtime iterator (not a Generator, not an object iterator) and `mode != PTS_RESUME_NEXT`,
  throw `"%.*s is not a function"` with `text`. Then add the four lines of `p03` to a test.

## S2. SHOULD-FIX (round-1 #5 still open on two routes; a regression for asserted literals)

A result object of another layout still reaches an interface through a plain `ClassCast` (no `FromResult`) on two routes:

1. **The relaxed cast** (an interface with an optional property the result type lacks):
   `pts/lower/objects.go:898-900` (`holdsOptionally`) returns `&ir.ClassCast{X: value, To: target}` without going through `interfaceCast`.
   - `p/p12_relaxed_nocheck.pts`: `{ done: false as const, value: 1e-310, extra: true } as IteratorYieldResult<number>`, then passed to
     `show(r: { value: number | undefined; note?: string })`. Node `show 1e-310`; **base `show 1e-310`** (base copied at the `as`);
     new `Uncaught TypeError: Cannot read property value of Object as number | undefined: it is declared number`. **Regression.**
   - `p/p14_optional_value_iface.pts`: a typed `next(): IteratorResult<number, number>` returns `{ done, value: n * 1.5, extra: "x" }`
     through a local, and `it.next()` is passed to `showNote(r: WithNote)` with `WithNote = { value: number | undefined; note?: string }`.
     Node `note 1.5 undefined`; new: the same TypeError; base PTS1001 (honest). A realistic program. `{ value?: number }` works (`opt 1.5`).
2. **The contextual-interface conditional:** `sameType` (`pts/lower/lower.go:3335-3339`) runs `convertedResult` before
   `asContextualInterface` (`:3372-3381`), whose two `ClassCast`s are therefore never marked.
   - `p/routes/r_cond.pts`: `const a: HV = flag ? res : new Other(2)` with `res` the asserted literal above.
     Node and **base** `cond 1e-310`; new: the TypeError above. **Regression.**
- Twelve other routes (a return, a field, a Map value, a Set, a tuple, a rest parameter, an optional parameter, an array literal,
  a `readonly HV[]` parameter, `map` with an `HV` callback, a generic constraint, equality) match Node (`p/routes/r_*.pts`).
- The message is the runtime's "only a compiler bug makes one". The h03b.md table says #5 is closed.
- **Fix:** give the relaxed branch the same `FromResult` treatment (or route it through `interfaceCast`, if its copy
  shape handles optional properties), and apply `convertedResult` after `asContextualInterface` (or have it build casts
  through `interfaceCast`). Pin `p12`, `p14` and `r_cond` in `run/iterator_results_other_types.pts`.

## S3. SHOULD-FIX (new): postfix `++`/`--` on a result reads its getter twice

- **Repro:** `p/p08_incr_accessors.pts`; also `p/p07_order.pts` line 4 of the output
- **Node:** `result 6 get,set 6` and `union 8 get,set 8`. **New:** `result 6 get,get,set 6`, `union 8 get,get,set 8` (the union case is
  narrowed to the yield result's shape). Prefix `++r.value` and compound `r.value += x` read once, as do class, interface and
  object-literal receivers. **Base:** can't build the program (`Expected object1, got Object` at run time).
- **Cause:** `readAndStore` (`pts/lower/lower.go:2977-2980`) treats a Result class receiver as a plain field
  (`target.field != nil && !viaInterface`) and caches no `current`. cgen's postfix `setField` (`pts/cgen/classes.go:886-894`)
  then reads `old` with `fieldRead` while the stored value holds a second `FieldRef`. Each `fieldRead` on a result receiver
  is `resultRead`, a getter call for a handed object.
- **Fix:** in `readAndStore`, treat `isResultReceiver`-like receivers (a `Class.Result` object) like `viaInterface` so the read
  is bound once. Getter read counts are H03b's acceptance theme, so this belongs in the slice. Pin with `p08`.

---

## NOTEs

- **N1 (pre-existing; C42 residual).** The `fromValue` keep-object rule applies only when the target *is* a result type
  (`isResultType`, `pts/cgen/cgen.go:1106`, `classes.go:810`). Other targets still copy, running both getters at the conversion,
  as base does:
  - a `IteratorResult<T> | undefined` local from `any`;
  - an `any` array converted to `IteratorResult<T>[]`;
  - a write through `any` into a `Map<string, IteratorResult<T>>`;
  - `await Promise.all([ui.next(), ui.next()])` into a tuple of results.

  Probes: `p/p02_union_undefined_from_any.pts` (Node `got u` then `u done read`; new `u done read`, `u value read`, `got u`;
  arrays and the Map write likewise) and `p/p15_async_then.pts` (the `Promise.all` lines). D-178 states the rule exactly, so
  this is not a contradiction. Extending `isResultType` to unions whose other members are `undefined`/`null` is cheap. The
  array, tuple and Map cases are worth a ledger line.
- **N2 (declared, but its consequences are not spelled out).** Converting a result of another layout to an interface
  (`ClassCast.FromResult`) copies it when its declared types don't fit. Identity and writes through the interface are lost,
  and getters run at the call even if the callee never reads them. `p/p04_iface_identity.pts`: Node `result true 99`,
  `literal true 99`, `getter reads after ignore 0`; new `result false 6`, `literal false 7`, `getter reads after ignore 1`
  (the own-shape case keeps identity). A plain object of the same layout gets PTS1001 on both trees ("whose `value` it
  doesn't provide with the same types"). D-178's "copied otherwise, as D-071 converts dynamic data" is accurate. It could
  add "so identity, writes through the interface and the getters' timing differ from JS".
- **N3 (pre-existing).** A `yield*` whose value is unused never reads the final done result's `value`, which JS always does
  (IteratorValue in yield*'s step). `p/p01b_yield_star_stmt_any.pts`: Node `done read 2`, `value read 2`, `after`; new and base skip
  `value read 2`. The delegation's `value` expression (`pts/lower/generators.go:209`) is emitted only in the return path or
  where the value is used. A getter-count divergence of the kind H03b is about. Ledger-worthy.
- **N4.** A non-boolean `done`, read through a union result type, throws `Expected boolean | undefined, got number`. Through one
  shape it reads as its truth (`true`, where Node prints `1`). `p/p20_nonbool_done.pts`. D-178's "a `done` that isn't a boolean reads as
  its truth" holds for one shape only (`resultValue`'s `ir.Bool` case, `pts/cgen/classes.go:851`). The typed source is lying, so this
  is a docs nuance.
- **N5 (docs accuracy).**
  - **C47 is fixed, not open.** `p/gaps/g3_print_order.pts` and the reproducer's own `p/repro/adj_p7_misc.pts` print
    `{ done: false, value: 1 }` on the new tree, as Node does; base `{ value: 1, done: false }`. The literal keeps its
    done-first order descriptor and is handed back as it is. D-178's known gap ("a result literal that is a D-109 shape prints
    value first") and the ledger's C47 "open — H29" are stale. A generator's own results print value first in both.
  - **Benchmark numbers in D-178 and h03b.md for `b3`/`b3d` predate the final runtime.** `/tmp/pts-h03b-s2/bench/b3_user_forof.new`
    was built at 02:31:32 and `generator.c` last changed at 02:36:16. On the final tree: `b3_user_forof` **1.049x**
    (D-178: 1.03x), `b3d` **1.051x** (D-178: 1.06x). The +14 instructions a step come from `call_object_method` being a separate,
    non-inlined call (24M + 10M instructions in the profile), where round 1's `call_object_iterator` cost 40M. `static inline` would
    probably recover it. `b2_next_shape` is 1.119x (D-178 says 1.12x, which is consistent; round 1 was 1.085x).
- **N6.** No test pins the declared gaps C51 (per-read copy) and N2 (identity through an interface). `iterator_results_other_types.pts`
  reads `row.value.name` once, so it would pass whichever way they go. That is acceptable for declared gaps. A skipped
  known-issue test with Node's output, as the project does elsewhere, would keep them visible.

## Verified good (new evidence this round)

- **Getter read counts and order:** argument order, compound and logical assignments, template literals, conditionals
  (`p/p07_order.pts`, all except S3's postfix line). Array patterns with defaults, nested patterns, holes and rest, typed and
  through `any` (`p/p23_pattern_reads.pts`, base read `value` at the hole). A statement-position `yield*` reads `done` twice,
  as Node does (`p/p01_yield_star_stmt_value.pts`, apart from N3).
- **Result types holding handed objects:** unions with `undefined`/`null`/a class/a number, `instanceof`/`typeof`/`in`
  narrowing, optional chains (`p/p10_mixed_unions.pts`). Narrowing to a member and passing it on as a parameter, an
  assertion, an array element or a return (`p/p19_narrow_member.pts`). Identity of by-name values: classes, interfaces,
  arrays, tuples, Maps, functions, nested objects (`p/p06_byname_identity.pts`). Value types: function types, classes with
  methods, generic classes, tuples, Maps, Promises, `Float64Array`, nested generators, unions (`p/p05_value_types.pts`).
  `Object.keys`, `JSON.stringify`, `hasOwnProperty`, a custom `toString` (`p/p18_union_methods.pts`). All match Node.
- **Frozen results:** writes to frozen own-shape results (both orders) and to frozen handed objects throw TypeError, as in
  Node (`p/p09_frozen.pts`). Base wrote through a frozen handed object (`no throw`, `6`).
- **Async:** `then()` callbacks on a typed `AsyncIterator`'s `next()` read nothing early (`p/p15_async_then.pts`, apart
  from N1's `Promise.all`).
- **Realistic utilities:** zip, take, a `Peekable<T>` holding `IteratorResult<T, undefined> | undefined`, a class
  `IterableIterator`, manual stepping of map/set/string iterators (`p/p21_realistic_utils.pts`): identical to Node.
- **Threads (D-143):** `run/iterator_results_threads.pts` built once and run 5x at `PTS_THREADS=4` and 5x at 8: 10/10 match
  the expect block. Round-1 `e01` to `e03`: `bad 0` at 4 and 8.
- **GC:** every `pts_iterator` subtype is `GC_MALLOC`'d and scanned whole (`generator.c`, `promise.c` `allocate`).
  `generator->result` is reset before each step, so a handed result stays alive for at most one step, and `last_resumed` is
  uncollectable. `from_sync` (`step == NULL`) is rejected by `method_mode` and is never visible to programs.
- **IR plumbing:** every `*ir.Yield` consumer (`ir.Walk`, `cellPass`, the printer, cgen frames and emission) handles `Delegate`.
- **Unit tests:** `go test ./pts/lower/ ./pts/cgen/ ./pts/ir/` ok. `TestErrors` ok. Focused
  `^(TestRun|TestRunMatchesNode)$/(iterator|yield_star|array_pattern|any_maps|generator|for_of)`: 102 pass, 6 skip, 0 fail.

## Performance (callgrind, `PTS_THREADS=1`, final tree including the 02:36 runtime change; base counts from round 1)

| Program | Base | Round-1 new | Final | Ratio |
|---|---|---|---|---|
| `b4_user_next` (typed `next()`, class iterator) | 1,341,618,634 | 765,233,793 | 760,227,095 | 0.567 |
| `b4d_user_next_donefirst` | 1,341,606,538 | 744,229,679 | 731,228,166 | 0.545 |
| `b1_next_union` | 489,956,963 | 416,964,434 | 417,969,392 | 0.853 |
| `b2_next_shape` | 247,951,440 | 268,950,883 | 277,346,026 | 1.119 |
| `b3_user_forof` | 899,970,156 | 929,971,744 | 943,973,078 | 1.049 |
| `b3d_user_forof_donefirst` | 866,965,599 | 896,972,426 | 910,972,984 | 1.051 |
| `b5_delegate` | 247,799,450 | 255,799,302 | 255,799,349 | 1.032 |
| `b6_forof_gen` | 133,788,732 | 137,789,075 | 137,788,707 | 1.030 |
| `r1_union_reads` | 599,493,819 | 429,416,960 | 429,417,924 | 0.716 |
| `r2_shape_reads` | 107,257,863 | 129,270,587 | 129,273,546 | 1.205 |
| `r3_user_shape` | 180,178,071 | 180,189,487 | 182,201,718 | 1.011 |
| `r4_donefirst_reads` | 107,127,156 | 381,252,150 | 137,142,146 | **1.280** (round-1 #6 fixed) |

All outputs equal the base's. Programs, binaries, `cg.*` and logs are in `/tmp/pts-h03b-review2/bench/`.

## Test quality

- All 13 Node-checked new or imported files pass both `TestRun` and `TestRunMatchesNode`, so each expect block is Node's
  stdout. `run/iterator_results_threads.pts` checks itself (counts of bad values), is skipped by `TestRunMatchesNode`
  (`pts:parallel`), and passes at 1, 2 and 4 threads in the suite and 10 of 10 runs at 4 and 8 here.
- They pin the acceptance rows well. Read counts at each level of `yield*`, lying `done`, `return`/`throw` forwarding,
  elisions, IteratorClose, methods through `any` (generators, async generators, runtime iterators, `keys`/`values`/`entries`),
  conversions from `any`, done-first literals, interface parameters and conditionals.
- Gaps: S1 (no runtime iterator in the typed missing-method section), S2's two routes, S3 (no postfix on a result), and the
  declared C51/N2 (N6).
- Overlap: `iterator_result_getter_literals.pts` and `iterator_result_getters_typed.pts` both cover typed getter literals, but
  through different consumers. I see no duplicate without value.
- The `any_maps_error.pts` edit is legitimate: the old line pinned a limitation, and the header comment now says why.

## Commands

`/tmp/pts-h03b-review2/run.sh X.pts` copies X.pts to X.mts and runs, under `pipefail`, `ulimit -f 40960` and timeouts:
- Node: `node --no-warnings --experimental-transform-types X.mts`
- new: `PTS_HOME=/home/bryan/projects/parallelscript PTS_CACHE_DIR=/tmp/pts-h03b-review2/cache /tmp/pts-h03b-review2/pts run X.pts`
- base: `PTS_HOME=/tmp/pts-h03b/base PTS_CACHE_DIR=/tmp/pts-h03b-review2/cache-base /tmp/pts-h03b/base/pts-bin/pts run X.pts`

The probes are in `/tmp/pts-h03b-review2/p/` (`routes/`, `gaps/`, `repro/`). The three outputs of each cited probe are in
`/tmp/pts-h03b-review2/out/<name>.txt`, and the reruns of round-1 probes are in `out/r1_*.txt`. The focused suite events are in
`/tmp/pts-h03b-review2/gotest-focus.jsonl`.
