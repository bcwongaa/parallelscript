import sys,re
for fn in sys.argv[1:]:
    t=open(fn).read()
    parts=re.split(r'^--- (node|new|base)\n', t, flags=re.M)
    d={}
    for i in range(1,len(parts),2): d[parts[i]]=parts[i+1]
    s="SAME" if d.get('node')==d.get('new') else "DIFF"
    if 'base' in d: s+=" base:"+("same" if d.get('node')==d.get('base') else "diff")
    print(s, fn)
