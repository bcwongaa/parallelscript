import sys,re
for p in sys.argv[1:]:
    t=open(p).read()
    parts=re.split(r'^--- (\w+)\n', t, flags=re.M)
    d={parts[i]:parts[i+1] for i in range(1,len(parts),2)}
    print(('MATCH' if d.get('node')==d.get('new') else 'DIFF '), p)
