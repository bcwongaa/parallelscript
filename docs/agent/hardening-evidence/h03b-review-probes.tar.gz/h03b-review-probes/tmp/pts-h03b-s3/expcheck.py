"""expcheck.py <pts-cli> <pts-home> <cache> <file.pts>...: run each with pts, compare stdout with its expect block."""
import re, subprocess, sys, os, json
cli, home, cache = sys.argv[1:4]
recs=[]
for p in sys.argv[4:]:
    t=open(p).read().split('\n')
    i=t.index('// expect:')
    exp=[]
    for line in t[i+1:]:
        if not line.startswith('//'): break
        exp.append(line[3:] if line.startswith('// ') else line[2:])
    env=dict(os.environ, PTS_HOME=home, PTS_CACHE_DIR=cache, TZ='America/New_York')
    r=subprocess.run([cli,'run',p],capture_output=True,env=env,timeout=300)
    out=r.stdout.decode().split('\n')
    if out and out[-1]=='': out=out[:-1]
    first=None
    for k in range(max(len(out),len(exp))):
        a=out[k] if k<len(out) else None; b=exp[k] if k<len(exp) else None
        if a!=b: first={'line':k+1,'got':a,'want':b}; break
    ok = first is None and r.returncode==0
    rec={'file':os.path.basename(p),'exit':r.returncode,'pass':ok,'first_difference':first,'stderr':r.stderr.decode()[-600:]}
    recs.append(rec)
    print(('PASS ' if ok else 'FAIL ')+rec['file'], 'exit', r.returncode, json.dumps(first) if first else '', rec['stderr'].strip()[:300].replace('\n',' | '))
