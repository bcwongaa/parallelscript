const n = 400000;
let deep: unknown[] = [];
const top = deep;
for (let i = 0; i < n; i++) { const next: unknown[] = []; deep.push(next); deep = next; }
try { console.log("ok", String(top).length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
