const n = 2_000_000;
let deep: unknown[] = [];
const top = deep;
for (let i = 0; i < n; i++) { const next: unknown[] = []; deep.push(next); deep = next; }
console.log("built");
try { console.log("join", String(top).length); } catch (e) { console.log("join", (e as Error).name, (e as Error).message); }
