const xs = Array.from({ length: 200_000 }, (_, i) => i);
console.log(xs.par.map((x) => x * 2).reduce((a, b) => a + b, 0));
function fib(k: number): number { return k < 2 ? k : fib(k - 1) + fib(k - 2); }
console.log(fib(20));
try { (function deep(d: number): number { return deep(d + 1) + 1; })(0); } catch (e) { console.log((e as Error).name, (e as Error).message); }
console.log(0.1 + 0.2, (123.456).toFixed(2), 2 ** 53 + 1, "é".normalize("NFD").length, "ß".toUpperCase(), /(\d+)-(\d+)/.exec("10-20")?.slice(1));
console.log(process.platform, process.arch);
