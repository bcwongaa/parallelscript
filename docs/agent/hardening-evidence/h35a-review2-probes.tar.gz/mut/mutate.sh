#!/bin/bash
# Mutation checks of round 1's tests through go test -overlay (no edits to the worktree).
# usage: mutate.sh <name> <file in wt-y> <perl substitution> <package> <test regexp>
set -u
name=$1 file=$2 subst=$3 pkg=$4 tests=$5
src=/tmp/h35s/wt-y/$file
mkdir -p /tmp/h35s/review2/mut/$name
cp "$src" /tmp/h35s/review2/mut/$name/$(basename "$file")
perl -0pi -e "$subst" /tmp/h35s/review2/mut/$name/$(basename "$file")
if cmp -s "$src" /tmp/h35s/review2/mut/$name/$(basename "$file"); then echo "$name: MUTANT DID NOT APPLY"; exit 2; fi
diff -u "$src" /tmp/h35s/review2/mut/$name/$(basename "$file") > /tmp/h35s/review2/mut/$name/mutant.diff
printf '{"Replace":{"%s":"%s"}}' "$src" /tmp/h35s/review2/mut/$name/$(basename "$file") > /tmp/h35s/review2/mut/$name/overlay.json
cd /tmp/h35s/wt-y && PTS_HOME=/tmp/h35s/wt-y PTS_CACHE_DIR=/tmp/h35s/review2/cache taskset -c 6,7 go test -count=1 -p 1 -overlay /tmp/h35s/review2/mut/$name/overlay.json -run "$tests" "$pkg" > /tmp/h35s/review2/mut/$name/test.log 2>&1
code=$?
echo "$name: go test exit=$code; $(grep -cE -- '--- FAIL' /tmp/h35s/review2/mut/$name/test.log) FAIL lines; build failed: $(grep -c 'build failed\|setup failed' /tmp/h35s/review2/mut/$name/test.log)"
