#!/bin/bash
# R1-F7 recheck: the package hint only for a failing C compiler on a cross build; nothing on Ctrl-C.
. /tmp/h35s/review2/scripts/env.sh; cd /tmp/h35s/review2/wrapper
for tgt in "" "--target aarch64-linux"; do PTS_CACHE_DIR=$PWD/cache3 PTS_CC=$PWD/clang-fails taskset -c 6,7 $P build hello.pts $tgt -o hf > o.txt 2> e.txt; echo "[$tgt] exit=$? hint=$(grep -c 'cross-compiling for' e.txt)"; done; rm -rf cache3
