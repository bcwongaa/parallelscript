#!/bin/bash
# CLI parsing, precedence and error probes (R1-F4); run in /tmp/h35s/review2/p (hello.pts).
. /tmp/h35s/review2/scripts/env.sh; cd /tmp/h35s/review2/p
run $P build hello.pts --target
run $P build hello.pts --target=
run $P build hello.pts --target sparc
run env PTS_TARGET=aarch64-linux $P build hello.pts --target x86_64-linux -o h2; file h2 | cut -c1-60
run env PTS_TARGET=bogus $P build hello.pts -o h3
run env PTS_TARGET=bogus $P build hello.pts --target aarch64-linux -o h4   # R1-F4: the flag doesn't override
run env PTS_TARGET=aarch64-linux $P run hello.pts                          # foreign binary without QEMU_LD_PREFIX
run $P emit-c hello.pts --target=aarch64-linux
run $P build hello.pts --output=h5 --target aarch64-linux; file h5 | cut -c1-60
run $P build -o=h6 hello.pts
run $P build hello.pts --output=
rm -f h2 h3 h4 h5 h6 hello
