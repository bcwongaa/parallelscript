#!/bin/bash
# The aarch64 stack guard in every context (main, pool, other loop, method, closure, async, generator, big frames).
. /tmp/h35s/review2/scripts/env.sh; cd /tmp/h35s/review2/stack
taskset -c 6,7 $P build deep.pts -o deep-x64 && taskset -c 6,7 $P build deep.pts --target aarch64-linux -o deep-arm || exit 1
for t in 1 4; do PTS_THREADS=$t ./deep-x64 > x64-$t.out; echo "x64 T=$t exit=$?"; PTS_THREADS=$t $QEMU ./deep-arm > arm-$t.out; echo "arm T=$t exit=$?"; diff x64-$t.out arm-$t.out && echo same; done
aarch64-linux-gnu-objdump -d --no-show-raw-insn deep-arm | awk '/<pts_fn_down>:/,/^$/' | head -14
rm -f deep-x64 deep-arm
