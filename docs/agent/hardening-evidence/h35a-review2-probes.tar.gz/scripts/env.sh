# Common settings for the review probes (source me). The worktree's CLI: go build -o /tmp/h35s/review2/pts ./cmd/pts
export PTS_HOME=/tmp/h35s/wt-y PTS_CACHE_DIR=/tmp/h35s/review2/cache
P=/tmp/h35s/review2/pts
QEMU="qemu-aarch64-static -L /usr/aarch64-linux-gnu"
run() { echo "\$ $*"; taskset -c 6,7 "$@" >out.txt 2>err.txt; echo "exit=$?"; head -c 400 out.txt; head -c 300 err.txt; echo; }
