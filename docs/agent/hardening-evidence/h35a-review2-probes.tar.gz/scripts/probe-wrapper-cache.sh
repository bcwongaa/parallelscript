#!/bin/bash
# R2-F1: a PTS_CC wrapper (D-225's route for "another layout") shares archive keys with plain clang.
# Needs the round-1 CLI at $P (see env.sh) and a cache already holding plain clang's aarch64 archives
# (run: $P build hello.pts --target aarch64-linux first).
. /tmp/h35s/review2/scripts/env.sh; cd /tmp/h35s/review2/wrapper
ls $PTS_CACHE_DIR | grep -v lock | sort > before.txt
PTS_CC=$PWD/clang-other-layout taskset -c 6,7 $P build hello.pts --target aarch64-linux -o hw > out.txt 2> err.txt; echo "wrapper build exit=$?"; head -c 200 err.txt; echo
ls $PTS_CACHE_DIR | grep -v lock | sort > after.txt; diff before.txt after.txt && echo "no new archives: the wrapper's build took plain clang's cached aarch64 archives"
