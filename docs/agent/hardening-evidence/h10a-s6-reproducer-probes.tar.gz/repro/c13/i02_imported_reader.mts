import { type Cache, MapLRU, lenArr } from "./lib/lib.mts";
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) c.items.forEach(lenArr);
}
run(new MapLRU<string, number>("k", 0));
