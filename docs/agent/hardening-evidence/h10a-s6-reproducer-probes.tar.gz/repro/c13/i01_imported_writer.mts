import { type Cache, MapLRU, pushArr } from "./lib/lib.mts";
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) c.items.forEach(pushArr);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.items);
