export interface Cache<K, V> { get(key: K): V | undefined; }
export class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
export function pushArr(_x: any, _i: number, arr: any[]): void { arr.push(1); }
export function lenArr(_x: any, _i: number, arr: any[]): void { console.log("len", arr.length); }
export const pushRow = (row: any[]) => { row.push(2); };
export function firstPush(rows: any[][]): void { rows[0].push(3); }
