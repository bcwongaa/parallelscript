import * as L from "./lib/lib.mts";
function run(c: L.Cache<string, number>): void {
  if (c instanceof L.MapLRU) { c.items.forEach(L.pushArr); }
}
const m = new L.MapLRU<string, number>("k", 0);
run(m);
console.log(m.items);
