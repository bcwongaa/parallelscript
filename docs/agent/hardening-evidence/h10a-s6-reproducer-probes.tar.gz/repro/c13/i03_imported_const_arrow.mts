import { type Cache, MapLRU, pushRow } from "./lib/lib.mts";
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) c.matrix.forEach(pushRow);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.matrix);
