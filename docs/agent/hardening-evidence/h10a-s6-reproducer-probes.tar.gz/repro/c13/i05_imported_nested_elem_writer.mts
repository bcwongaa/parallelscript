import { type Cache, MapLRU, firstPush } from "./lib/lib.mts";
function run(c: Cache<string, number>): void {
  if (c instanceof MapLRU) firstPush(c.matrix);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.matrix);
