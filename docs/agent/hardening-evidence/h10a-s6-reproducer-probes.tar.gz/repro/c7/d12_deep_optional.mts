interface Cache<K, V> { get(key: K): V | undefined; }
type Deep<V> = { a?: { b?: { list: V[] } } };
class MapLRU<K, V> implements Cache<K, V> {
  deep: Deep<V> = { a: { b: { list: [] } } };
  none: Deep<V> = {};
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.deep.a?.b?.list.push(1);
  c.deep?.a?.b?.list?.push(2);
  const l = c.deep.a?.b?.list; l?.push(3);
  c.none.a?.b?.list.push(9);
  const b = c.deep.a!.b!; b.list.push(4);
  console.log(c.deep.a?.b === c.deep.a?.b, c.none.a?.b);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(JSON.stringify(m.deep), JSON.stringify(m.none));
