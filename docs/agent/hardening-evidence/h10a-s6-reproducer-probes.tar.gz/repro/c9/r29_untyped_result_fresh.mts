interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V[]>();
  constructor(public key: K, public val: V) { this.store.set(key, [val]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  update(key: K, f: (old: V[]) => V[]): void { this.store.set(key, f(this.store.get(key)!)); }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.update("k", (old) => [...old, 5]);
  c.update("k", (old) => old.map((x) => x * 2));
  c.update("k", (old) => (old.length > 1 ? old : []));
}
const m = new MapLRU<string, number>("k", 1);
run(m);
console.log(m.store, m.store.get("k")!.reduce((a, b) => a + b, 0));
