interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V[]>();
  constructor(public key: K, public val: V) { this.store.set(key, []); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  update(key: K, f: (old: V[]) => V[]): void { this.store.set(key, f(this.store.get(key)!)); }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const before = c.store.get("k")!;
  c.update("k", (old): any[] => { old.push(1); return old; });
  console.log(c.store.get("k") === before);
  before.push(2);
  console.log(c.store.get("k")!.length);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.store);
