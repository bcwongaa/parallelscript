interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  box = { items: [] as V[] };
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  withSelf(f: (me: MapLRU<K, V>) => void): void { f(this); }
  withBox(f: (o: { items: V[] }) => void): void { f(this.box); }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.withSelf((me) => me.items.push(1));
  c.withBox((o) => o.items.push(2));
  c.withBox((o: { items: any[] }) => o.items.push(3));
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.items, m.box);
