interface Cache<K, V> { get(key: K): V | undefined; }
class Inner<T> { items: T[] = []; each(f: (items: T[]) => void): void { f(this.items); } }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [[], []];
  meta: { tags: V[]; inner: { list: V[] } } = { tags: [], inner: { list: [] } };
  store = new Map<K, V[]>();
  sets: Set<V>[] = [new Set<V>()];
  maps: Map<string, V>[] = [new Map<string, V>()];
  rec: Record<string, V[]> = { a: [] };
  cube: V[][][] = [[[], []]];
  pairs: [K, V[]][] = [];
  groups: { list: V[] }[] = [{ list: [] }];
  inners: Inner<V>[] = [new Inner<V>()];
  mixed: (V[] | string)[] = [[], "s"];
  constructor(public key: K, public val: V) { this.items.push(val); this.store.set(key, []); this.pairs.push([key, []]); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
  each(f: (items: V[]) => void): void { f(this.items); }
  both(f: (items: V[]) => void, g: (rows: V[][]) => void): void { f(this.items); g(this.matrix); }
  get first(): V[] { return this.matrix[0]; }
}
const m = new MapLRU<string, number>("k", 0);
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  console.log(String(c.matrix[0]));
}
run(m);
