interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  maybe?: V[] = [];
  slots: (V[] | undefined)[] = [[1 as V]];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function pushOne(_x: any, _i: number, arr: any[]): void { arr.push(1); }
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.maybe?.push(0);
  c.maybe?.forEach(pushOne);
  c.slots[0]?.forEach(pushOne);
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.maybe, m.slots);
