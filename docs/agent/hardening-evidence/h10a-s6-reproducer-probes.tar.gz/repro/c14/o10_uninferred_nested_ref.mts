class Box<T> { rows: T[][] = [[]]; store = new Map<string, T[]>([["k", []]]); }
function pushRow(row: any[]): void { row.push(1); }
function pushV(v: any[]): void { v.push(2); }
function run(o: object): void {
  if (!(o instanceof Box)) return;
  o.rows.forEach(pushRow);
  o.store.forEach(pushV);
}
const b = new Box<number>();
run(b);
console.log(b.rows, b.store);
