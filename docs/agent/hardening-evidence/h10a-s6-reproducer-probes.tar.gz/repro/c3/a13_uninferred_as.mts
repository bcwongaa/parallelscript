class Box<T> { items: T[] = []; rows: T[][] = [[]]; }
function run(o: object): void {
  if (o instanceof Box) { (o.items as any[]).push(1); (o.rows[0] as any[]).push(2); const r = o.rows[0] as any[]; r.push(3); }
}
const b = new Box<number>();
run(b);
console.log(b.items, b.rows);
