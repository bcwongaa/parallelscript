// A callback with a `this` parameter: the parameter indexes shift by one.
interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  items: V[] = [];
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) { this.items.push(val); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  c.matrix.forEach(function (this: any, row: any[]) { row.push(1); });
  c.items.forEach(function (this: any, _x: any, _i: number, arr: any[]) { arr.push(2); });
}
const m = new MapLRU<string, number>("k", 0);
run(m);
console.log(m.matrix, m.items);
