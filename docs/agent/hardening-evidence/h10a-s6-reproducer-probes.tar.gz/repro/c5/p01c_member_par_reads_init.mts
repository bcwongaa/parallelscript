interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [];
  items: V[] = [];
  constructor(public key: K, public val: V) { const row: V[] = []; for (let i = 0; i < 50; i++) { row.push(val); this.items.push(val); } this.matrix.push(row); }
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function run(c: Cache<string, number>): void {
  if (!(c instanceof MapLRU)) return;
  const d = c.items.map((x) => x * 2);
  const row = c.matrix[0];
  console.log(d.length, d[49], row.length);
}
run(new MapLRU<string, number>("k", 3));
