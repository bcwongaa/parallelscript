class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run(u: unknown): void {
  if (!(u instanceof Grid)) return;
  u.matrix[0].push(1); const r = u.matrix[1]; r.push(2); u.meta.tags.push(3); u.store.get("k")!.push(4); u.pairs[0][1].push(5); for (const row of u.matrix) row.push(6);
}
const g = new Grid<number>();
run(g);
console.log(JSON.stringify(g.matrix), g.meta.tags, g.store.get("k"), g.pairs[0][1]);
