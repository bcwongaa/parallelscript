class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run(o: object): void {
  if (!(o instanceof Grid)) return;
  const r = o.matrix[1]; console.log(r === o.matrix[1], o.matrix.indexOf(r), o.meta.tags === o.meta.tags);
}
const g = new Grid<number>();
run(g);

