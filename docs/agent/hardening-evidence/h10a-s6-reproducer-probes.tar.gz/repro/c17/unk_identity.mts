class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run(u: unknown): void {
  if (!(u instanceof Grid)) return;
  const r = u.matrix[1]; console.log(r === u.matrix[1], u.matrix.indexOf(r), u.meta.tags === u.meta.tags);
}
const g = new Grid<number>();
run(g);

