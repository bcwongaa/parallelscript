class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run<S extends object>(s: S): void {
  if (!(s instanceof Grid)) return;
  s.matrix[0].push(1); const r = s.matrix[1]; r.push(2); s.meta.tags.push(3); s.store.get("k")!.push(4); s.pairs[0][1].push(5); for (const row of s.matrix) row.push(6);
}
const g = new Grid<number>();
run(g);
console.log(JSON.stringify(g.matrix), g.meta.tags, g.store.get("k"), g.pairs[0][1]);
