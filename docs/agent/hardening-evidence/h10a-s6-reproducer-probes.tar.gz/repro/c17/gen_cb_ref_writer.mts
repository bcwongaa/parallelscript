class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run<S extends object>(s: S): void {
  if (!(s instanceof Grid)) return;
  s.matrix.forEach(addRow);
}
const g = new Grid<number>();
run(g);
console.log(g.matrix);
