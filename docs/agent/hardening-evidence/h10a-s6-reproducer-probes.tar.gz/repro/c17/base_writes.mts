class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  pairs: [string, T[]][] = [["p", []]];
}
function fill(a: any[]): void { a.push(9); }
function firstPush(rows: any[][]): void { rows[0].push(10); }
function addRow(row: any[]): void { row.push(11); }
function run(b: Base): void {
  if (!(b instanceof Grid)) return;
  b.matrix[0].push(1); const r = b.matrix[1]; r.push(2); b.meta.tags.push(3); b.store.get("k")!.push(4); b.pairs[0][1].push(5); for (const row of b.matrix) row.push(6);
}
const g = new Grid<number>();
run(g);
console.log(JSON.stringify(g.matrix), g.meta.tags, g.store.get("k"), g.pairs[0][1]);
