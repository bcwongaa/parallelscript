// No instanceof: a typed array's concat given a dynamic value that is an array.
const a: number[] = [5];
const z: any = [1, 2];
const u: unknown = [3];
console.log(a.concat(z));
console.log(a.concat(u as number[]));
