class Grid<T> {
  matrix: T[][] = [[], []];
  meta: { tags: T[] } = { tags: [] };
  store = new Map<string, T[]>([["k", []]]);
  each(f: (rows: T[][]) => void): void { f(this.matrix); }
}
function viaObject(o: object): void {
  if (!(o instanceof Grid)) return;
  o.matrix.forEach((row: any[]) => row.push(1));
  o.store.forEach((v: any[]) => v.push(2));
  o.each((rows) => rows[0].push(3));
  o.each((rows: any[][]) => rows[1].push(4));
}
const a = new Grid<number>();
viaObject(a);
console.log(a.matrix, a.store.get("k"));
