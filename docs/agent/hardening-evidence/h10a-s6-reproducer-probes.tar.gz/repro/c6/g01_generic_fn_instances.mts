interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function touch<V>(c: Cache<string, V>, v: V): void {
  if (!(c instanceof MapLRU)) return;
  c.matrix[0].push(v);
  c.matrix.forEach((row: any[]) => row.push(v));
  const r = c.matrix[1]; r.push(v);
  console.log(c.matrix[0] === c.matrix[0]);
}
const a = new MapLRU<string, number>("k", 1);
const b = new MapLRU<string, string>("k", "s");
touch(a, 7);
touch(b, "x");
console.log(a.matrix, b.matrix);
