class Grid<T> {
  matrix: T[][] = [[], []];
}
function addRow(row: any[]): void { row.push(1); }
function viaCatch(): void {
  try { throw new Grid<number>(); } catch (e) {
    if (e instanceof Grid) { e.matrix.forEach(addRow); e.matrix[0].push(2); console.log(e.matrix); }
  }
}
viaCatch();
