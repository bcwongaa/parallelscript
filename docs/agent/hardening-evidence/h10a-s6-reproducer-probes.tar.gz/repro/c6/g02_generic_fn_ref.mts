interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
function len(row: any[]): void { console.log(row.length); }
function touch<V>(c: Cache<string, V>): void {
  if (!(c instanceof MapLRU)) return;
  c.matrix.forEach(len);
}
touch(new MapLRU<string, number>("k", 1));
touch(new MapLRU<string, string>("k", "s"));
