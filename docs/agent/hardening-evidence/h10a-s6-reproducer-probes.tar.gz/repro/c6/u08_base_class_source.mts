class Base {}
class Grid<T> extends Base {
  matrix: T[][] = [[], []];
  meta = { tags: [] as T[] };
}
function viaBase(b: Base): void {
  if (!(b instanceof Grid)) return;
  b.matrix[0].push(1);
  b.meta.tags.push(2);
  b.matrix.forEach((row: any[]) => row.push(3));
  const [r0] = b.matrix; r0.push(4);
}
const g = new Grid<number>();
viaBase(g);
console.log(g.matrix, g.meta);
