interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  constructor(public key: K, public val: V) {}
  get(key: K): V | undefined { return key === this.key ? this.val : undefined; }
}
class Owner<V> {
  constructor(public c: Cache<string, V>) {}
  touch(v: V): void {
    const c = this.c;
    if (!(c instanceof MapLRU)) return;
    c.matrix[0].push(v);
    c.matrix.forEach((row) => row.push(v));
  }
}
const a = new MapLRU<string, number>("k", 1);
new Owner(a).touch(5);
const b = new MapLRU<string, boolean>("k", true);
new Owner(b).touch(false);
console.log(a.matrix, b.matrix);
