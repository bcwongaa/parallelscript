class Grid<T> {
  matrix: T[][] = [[], []];
}
function addRow(row: any[]): void { row.push(1); }
function lenRow(row: any[]): void { console.log("len", row.length); }
function viaUnknown(u: unknown): void {
  if (!(u instanceof Grid)) return;
  u.matrix.forEach(lenRow);
}
const a = new Grid<number>();
viaUnknown(a);
