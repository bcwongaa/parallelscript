class Grid<T> {
  matrix: T[][] = [[], []];
}
function addRow(row: any[]): void { row.push(1); }
function viaAny(x: any): void {
  if (!(x instanceof Grid)) return;
  x.matrix.forEach(addRow);
}
const a = new Grid<number>();
viaAny(a);
console.log(a.matrix);
