class Grid<T> {
  matrix: T[][] = [[], []];
  each(f: (rows: T[][]) => void): void { f(this.matrix); }
}
function viaAny(x: any): void {
  if (!(x instanceof Grid)) return;
  x.matrix.forEach((row: any[]) => row.push(1));
  x.each((rows: any[][]) => rows[1].push(4));
  x.matrix[0].push(5);
  const r = x.matrix[1]; r.push(6);
}
const a = new Grid<number>();
viaAny(a);
console.log(a.matrix);
