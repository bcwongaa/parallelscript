class Grid<T> {
  matrix: T[][] = [[], []];
}
function addRow(row: any[]): void { row.push(1); }
function viaUnknown(u: unknown): void {
  if (!(u instanceof Grid)) return;
  u.matrix.forEach(addRow);
}
const a = new Grid<number>();
viaUnknown(a);
console.log(a.matrix);
