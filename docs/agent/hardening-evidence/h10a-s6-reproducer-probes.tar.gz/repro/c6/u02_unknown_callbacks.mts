class Grid<T> {
  matrix: T[][] = [[], []];
  store = new Map<string, T[]>([["k", []]]);
  each(f: (rows: T[][]) => void): void { f(this.matrix); }
}
function viaUnknown(u: unknown): void {
  if (!(u instanceof Grid)) return;
  u.matrix.forEach((row: any[]) => row.push(1));
  u.store.forEach((v: any[]) => v.push(2));
  u.each((rows) => rows[0].push(3));
  u.each((rows: any[][]) => rows[1].push(4));
}
const a = new Grid<number>();
viaUnknown(a);
console.log(a.matrix, a.store.get("k"));
