// Operands JS evaluates before a yield or an await in a later operand of the same expression
// run before the suspension, with what they read then (D-145). pts counted these among the
// operands nothing can change while the function is suspended and evaluated them after the
// resume (H08): a postfix `i++` (alone, in a comma or under `void`), a spread (of an array,
// a call's result or an iterable, in a call, `new`, an array literal or an object literal,
// whose getters it runs), `in`, and binary operators on an `any` operand, which call its
// valueOf.
const trace: string[] = [];
const log = (s: string): void => {
  trace.push(s);
};
const show = (label: string, result: string): void => {
  console.log(`${label}: ${trace.join(",")} => ${result}`);
  trace.length = 0;
};
const pair = (a: unknown, b: number): string => `${String(a)}/${b}`;
const sum = (...xs: number[]): number => {
  let total = 0;
  for (const x of xs) total += x;
  return total;
};

function drive(label: string, steps: Generator<number, string, number>, change: () => void): void {
  let step = steps.next();
  while (!step.done) {
    log("yielded " + step.value);
    change();
    step = steps.next(10);
  }
  show(label, step.value);
}

let peek = (): number => -1;
function* postfix(): Generator<number, string, number> {
  let i = 0;
  peek = (): number => i;
  return pair(i++, yield i);
}
drive("pair(i++, yield i)", postfix(), () => log("i " + peek()));

function* postfixInComma(): Generator<number, string, number> {
  let i = 0;
  peek = (): number => i;
  return pair((i--, 7), yield 0);
}
drive("pair((i--, 7), yield)", postfixInComma(), () => log("i " + peek()));

function* postfixUnderVoid(): Generator<number, string, number> {
  let i = 0;
  peek = (): number => i;
  return pair(void i++, yield 0);
}
drive("pair(void i++, yield)", postfixUnderVoid(), () => log("i " + peek()));

const numbers = [1, 2];
function* spreadArgument(): Generator<number, string, number> {
  return String(sum(...numbers, yield 0));
}
drive("sum(...numbers, yield)", spreadArgument(), () => { numbers.push(100); });

const kept = [1, 2];
const getKept = (): number[] => {
  log("getKept");
  return kept;
};
function* spreadOfCall(): Generator<number, string, number> {
  return String(sum(...getKept(), yield 0));
}
drive("sum(...getKept(), yield)", spreadOfCall(), () => { kept.push(100); });

class Countdown implements Iterable<number> {
  from = 2;
  *[Symbol.iterator](): Iterator<number> {
    log("iterate");
    for (let i = this.from; i > 0; i--) yield i;
  }
}
const countdown = new Countdown();
function* spreadIterable(): Generator<number, string, number> {
  return [...countdown, yield 0].join(",");
}
drive("[...iterable, yield]", spreadIterable(), () => { countdown.from = 4; });

class Pair {
  items: number[];
  constructor(...items: number[]) {
    this.items = items;
  }
}
const parts = [1];
function* spreadNew(): Generator<number, string, number> {
  return new Pair(...parts, yield 0).items.join(",");
}
drive("new Pair(...parts, yield)", spreadNew(), () => { parts.push(100); });

let shown = 1;
const source = {
  get a(): number {
    log("get a");
    return shown;
  },
};
function* spreadObject(): Generator<number, string, number> {
  return JSON.stringify({ ...source, z: yield 0 });
}
drive("{ ...object, z: yield }", spreadObject(), () => { shown = 2; });

const record: Record<string, number> = { a: 1 };
function* inOperator(): Generator<number, string, number> {
  return pair("b" in record, yield 0);
}
drive("pair(\"b\" in record, yield)", inOperator(), () => { record.b = 2; });

let state = 1;
const valued: any = {
  valueOf(): number {
    log("valueOf");
    return state;
  },
};
function* anyPlus(): Generator<number, string, number> {
  return pair(valued + 1, yield 0);
}
drive("pair(any + 1, yield)", anyPlus(), () => { state = 5; });

function* anyLess(): Generator<number, string, number> {
  return pair(valued < 3, yield 0);
}
drive("pair(any < 3, yield)", anyLess(), () => { state = 1; });

// The same with await.
const later = (change: () => void): Promise<number> => {
  log("await");
  queueMicrotask(() => {
    log("changed");
    change();
  });
  return Promise.resolve(10);
};
async function awaited(): Promise<void> {
  let i = 0;
  show("await pair(i++, …)", pair(i++, await later(() => log("i " + i))));
  const xs = [1, 2];
  show("await sum(...xs, …)", String(sum(...xs, await later(() => { xs.push(100); }))));
  const r: Record<string, number> = { a: 1 };
  show("await pair(\"b\" in r, …)", pair("b" in r, await later(() => { r.b = 2; })));
  state = 1;
  show("await pair(any * 2, …)", pair(valued * 2, await later(() => { state = 5; })));
}
await awaited();

// expect:
// pair(i++, yield i): yielded 1,i 1 => 0/10
// pair((i--, 7), yield): yielded 0,i -1 => 7/10
// pair(void i++, yield): yielded 0,i 1 => undefined/10
// sum(...numbers, yield): yielded 0 => 13
// sum(...getKept(), yield): getKept,yielded 0 => 13
// [...iterable, yield]: iterate,yielded 0 => 2,1,10
// new Pair(...parts, yield): yielded 0 => 1,10
// { ...object, z: yield }: get a,yielded 0 => {"a":1,"z":10}
// pair("b" in record, yield): yielded 0 => false/10
// pair(any + 1, yield): valueOf,yielded 0 => 2/10
// pair(any < 3, yield): valueOf,yielded 0 => false/10
// await pair(i++, …): await,changed,i 1 => 0/10
// await sum(...xs, …): await,changed => 13
// await pair("b" in r, …): await,changed => false/10
// await pair(any * 2, …): valueOf,await,changed => 2/10
