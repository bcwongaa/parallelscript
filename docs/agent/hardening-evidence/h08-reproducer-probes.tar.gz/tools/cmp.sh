#!/bin/bash
# cmp.sh FILE.pts...: build and run each program with the PTS CLI ($PTS_CLI, default the base's)
# and under Node (a strict-ESM .mts copy); print both outputs with exit codes and a verdict.
# Outputs go to $OUT (default: next to the file) as NAME.pts.txt / NAME.node.txt.
set -u
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
CLI=${PTS_CLI:-/tmp/h08/base/pts-bin/pts}
export PTS_HOME=${PTS_HOME:-/tmp/h08/base}
for f in "$@"; do
  name=$(basename "$f" .pts); dir=$(cd "$(dirname "$f")" && pwd)
  out=${OUT:-$dir}; mkdir -p "$out" "$out/bin" "$out/mts"
  bin="$out/bin/$name.bin"; mts="$out/mts/$name.mts"
  cp "$dir/$name.pts" "$mts"
  timeout 30 node --no-warnings --experimental-transform-types "$mts" > "$out/$name.node.txt" 2>&1; ne=$?
  echo "[exit $ne]" >> "$out/$name.node.txt"
  rm -f "$bin"
  timeout 180 "$CLI" build "$dir/$name.pts" -o "$bin" > "$out/$name.build.txt" 2>&1; be=$?
  if [ $be -ne 0 ]; then
    cp "$out/$name.build.txt" "$out/$name.pts.txt"; echo "[build exit $be]" >> "$out/$name.pts.txt"
    verdict=$([ $be -eq 3 ] && echo ICE || echo DIAG)
  else
    (cd "$out" && timeout 30 "$bin" > "$out/$name.pts.txt" 2>&1; echo "[exit $?]" >> "$out/$name.pts.txt")
    if cmp -s "$out/$name.pts.txt" "$out/$name.node.txt"; then verdict=OK; else verdict=WRONG; fi
  fi
  echo "##### $name: $verdict"
  echo "=== node"; cat "$out/$name.node.txt"
  echo "=== pts"; cat "$out/$name.pts.txt"
  rm -f "$bin"
done
