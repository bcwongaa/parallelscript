#!/bin/bash
# fbtrace2.sh FILE: emit-c with the snap5 trace CLI and the no-filter trace CLI; prints "<snap5 FB?> <none FB?> exit5 exitN lines5 linesN file"
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review3/run/fb.XXXX)
a=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap5 timeout 300 /tmp/h09/review3/ov/pts-trace emit-c "$f" -o $d/a.c 2>&1); ea=$?
b=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap5 timeout 300 /tmp/h09/review3/ov/pts-none-trace emit-c "$f" -o $d/b.c 2>&1); eb=$?
fa=$(echo "$a" | grep -c '^PTS_FALLBACK'); fb=$(echo "$b" | grep -c '^PTS_FALLBACK')
la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
echo "snap5FB=$fa noneFB=$fb exit=$ea/$eb lines=$la/$lb $f"
rm -rf $d
