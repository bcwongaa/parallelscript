#!/bin/bash
# tri.sh file.pts...: run each with base CLI, fix CLI ($FIX, default /tmp/h09/snap5), Node (.mts copy).
# Prints a status line, and outputs (all, or with QUIET=1 only when base != fix or fix != node).
FIX=${FIX:-/tmp/h09/snap5}; BASE=${BASE:-/tmp/h09/base}
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review3/run/r.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  bo=$(cd "$d" && PTS_HOME=$BASE timeout 300 $BASE/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  so=$(cd "$d" && PTS_HOME=$FIX timeout 300 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  bs=$([ "$bo" == "$no" ] && echo B=node || echo B!=node); ss=$([ "$so" == "$no" ] && echo S=node || echo S!=node); bss=$([ "$bo" == "$so" ] && echo B=S || echo B!=S)
  echo "== $b: $bs $ss $bss"
  if [ "${QUIET:-}" != 1 ] || [ "$bo" != "$so" ] || [ "$so" != "$no" ]; then
    if [ "$bo" == "$so" ]; then echo "-- base=snap"; echo "$bo"; else echo "-- base"; echo "$bo"; echo "-- snap"; echo "$so"; fi
    [ "$so" != "$no" ] && { echo "-- node"; echo "$no"; }
  fi
  rm -rf "$d"
done
