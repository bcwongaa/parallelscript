#!/bin/bash
# bs.sh file.pts: base vs fix ($FIX, default /tmp/h09/snap5) run outputs; SAME/DIFF line; saves FILE.base.out/FILE.snap.out on DIFF
FIX=${FIX:-/tmp/h09/snap5}; BASE=${BASE:-/tmp/h09/base}
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review3/run/r.XXXX)
bo=$(cd "$d" && PTS_HOME=$BASE timeout 300 $BASE/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
so=$(cd "$d" && PTS_HOME=$FIX timeout 300 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
rm -rf "$d"
be=$(echo "$bo" | tail -1); se=$(echo "$so" | tail -1)
if [ "$bo" == "$so" ]; then echo "SAME $be $(basename $f)"; else echo "DIFF base$be snap$se $(basename $f)"; echo "$bo" > "$f.base.out"; echo "$so" > "$f.snap.out"; fi
