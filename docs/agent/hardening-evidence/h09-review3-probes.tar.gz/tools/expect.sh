#!/bin/bash
# expect.sh HOME file.pts...: `pts run` stdout (HOME's CLI) vs the file's // expect: block; NODE=1 compares Node's stdout instead
home=$1; shift
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts)
  exp=$(awk '/^\/\/ expect:/{p=1; next} p && /^\/\/ ?/{sub(/^\/\/ ?/, ""); print; next} p{exit}' "$f")
  d=$(mktemp -d /tmp/h09/review3/run/e.XXXX)
  if [ "${NODE:-}" == 1 ]; then cp "$f" $d/$b.mts; out=$(cd "$d" && timeout 60 $HOME/.local/node/bin/node --no-warnings --experimental-transform-types $b.mts 2>/dev/null)
  else out=$(cd "$d" && PTS_HOME=$home timeout 300 $home/pts-bin/pts run "$f" 2>/dev/null); fi
  rm -rf "$d"
  if [ "$out" == "$exp" ]; then echo "PASS $(basename $f)"; else echo "FAIL $(basename $f)"; diff <(echo "$exp") <(echo "$out") | head -20; fi
done
