# gen_keys_esc.py V N OUT: V generic arrows that escape into an any[] plus one passed to `use`,
# whose N call sites each pass a fresh object literal to a Promise<Box<T>> result (N keys):
# every value gets an entry per key (V x N entries).
import sys
v, n, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
L = ["class Box<T> {", "  constructor(public value: T) {}", "}", "const keep: any[] = [];"]
L.append("async function use(f: <T>(x: T) => Promise<Box<T>>): Promise<number> {")
L.append("  let total = 0;")
for i in range(n):
    L.append(f"  total += (await f({{ a: {i} }})).value.a;")
L.append("  return total;")
L.append("}")
L.append("function main(): void {")
for i in range(v):
    L.append(f"  const a{i} = async <T>(x: T): Promise<Box<T>> => new Box(x);")
    L.append(f"  keep.push(a{i});")
L.append("  use(async <T>(x: T): Promise<Box<T>> => new Box(x)).then((t) => console.log(t, keep.length));")
L.append("}")
L.append("main();")
open(out, "w").write("\n".join(L) + "\n")
