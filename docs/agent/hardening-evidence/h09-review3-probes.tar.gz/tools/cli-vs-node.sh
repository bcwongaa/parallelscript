#!/bin/bash
# cli-vs-node.sh CLI FILE...: run each with CLI (PTS_HOME=/tmp/h09/snap5) and Node; "SAME"/"DIFF" + outputs on DIFF
cli=$1; shift; node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review3/run/v.XXXX)
  cp "$f" "$d/$b.mts"
  so=$(cd "$d" && PTS_HOME=/tmp/h09/snap5 timeout 300 $cli run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  rm -rf "$d"
  if [ "$so" == "$no" ]; then echo "SAME $b"; else echo "DIFF $b"; echo "$so" | head -8 | sed 's/^/  cli: /'; echo "$no" | head -8 | sed 's/^/  node: /'; fi
done
