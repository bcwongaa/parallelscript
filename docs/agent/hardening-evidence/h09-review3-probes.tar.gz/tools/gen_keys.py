# gen_keys.py N KIND OUT: N call sites of one generic function value whose dynamic result
# (Promise<Box<T>>) is keyed by its type; KIND "literal" passes a fresh object literal at
# each site (T inferred as a new anonymous type each time), "number" passes numbers (one key),
# "typed" uses a typed result Box<T> (no key) with object literals.
import sys
n, kind, out = int(sys.argv[1]), sys.argv[2], sys.argv[3]
L = ["class Box<T> {", "  constructor(public value: T) {}", "}"]
if kind == "typed":
    L.append("function use(f: <T>(x: T) => Box<T>): number {")
    L.append("  let total = 0;")
    for i in range(n):
        L.append(f"  total += f({{ a: {i} }}).value.a;")
    L.append("  return total;")
    L.append("}")
    L.append("console.log(use(<T>(x: T): Box<T> => new Box(x)));")
else:
    L.append("async function use(f: <T>(x: T) => Promise<Box<T>>): Promise<number> {")
    L.append("  let total = 0;")
    for i in range(n):
        if kind == "literal":
            L.append(f"  total += (await f({{ a: {i} }})).value.a;")
        else:
            L.append(f"  total += (await f({i})).value;")
    L.append("  return total;")
    L.append("}")
    L.append("use(async <T>(x: T): Promise<Box<T>> => new Box(x)).then((t) => console.log(t));")
open(out, "w").write("\n".join(L) + "\n")
