#!/bin/bash
# measure.sh FILE: emit-c lines + wall time and pts build wall time + binary size, for base and $FIX (default snap4)
FIX=${FIX:-/tmp/h09/snap5}; BASE=${BASE:-/tmp/h09/base}
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review3/run/m.XXXX); cd $d
for w in base:$BASE fix:$FIX; do n=${w%%:*}; h=${w#*:}
  s=$(date +%s.%N); PTS_HOME=$h /usr/bin/time -f "%M" -o $n.mem $h/pts-bin/pts emit-c "$f" -o $n.c >$n.err 2>&1; e=$?; t=$(echo "$(date +%s.%N) - $s" | bc)
  s=$(date +%s.%N); PTS_HOME=$h $h/pts-bin/pts build "$f" -o $n.exe >$n.berr 2>&1; be=$?; bt=$(echo "$(date +%s.%N) - $s" | bc)
  echo "$n emitc_exit=$e lines=$([ -f $n.c ] && wc -l < $n.c || echo 0) emitc_s=${t:0:6} emitc_maxrss_kb=$(cat $n.mem) build_exit=$be build_s=${bt:0:6} bin=$([ -f $n.exe ] && stat -c %s $n.exe || echo 0) $(basename $f)"
done
cd /; rm -rf $d
