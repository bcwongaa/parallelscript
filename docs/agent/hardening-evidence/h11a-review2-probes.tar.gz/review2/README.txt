H11a review round 2 (snapshot 4 = 898a0a52b in /tmp/h11/snap2, base /tmp/h11/base).
tools/run.sh [-N|-S|-B] FILE...: Node (.mts copy), snapshot and base runs; outputs in out/<name>.{node,snap,base}[.err|.build]
repro/: minimal reproducers for round-2 findings
probes/r1repro: round-1 repros rerun on snapshot 4
probes/n/: stale narrowing s*, instanceof i*, tuple defaults t01, generic sources g*, yields y*, records rc01 and pr/, nested conditionals nc01, builtin type arguments ta/, program arguments pa/, defaults dn/
probes/still/: spot checks of the parent's STILL class
probes/tests/: the new run tests on node/snap/base
perf/callgrind.txt: instruction counts (base vs snapshot 4)
matrix/results-snap4.jsonl: the reproducer's families A,B,C,F,G on snapshot 4
tmp/s01.c: emit-c of repro/s01_stale_narrowing.pts on snapshot 4
