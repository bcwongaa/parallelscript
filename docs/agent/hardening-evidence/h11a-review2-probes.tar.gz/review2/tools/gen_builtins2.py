import os, sys
out = sys.argv[1]
HEADER = '''const nums: number[] = [1, 2, 0];
const strs: string[] = ["x", "g", "a"];
'''
cases = {
 "toExponential": ("const [n, d] = nums;", "(1.2345).toExponential(d)"),
 "Number_parseInt": ("const [n, r] = [16, 16];", 'Number.parseInt("ff", r)'),
 "RegExp_flags": ("const [p, f] = strs;", "new RegExp(p, f).flags"),
 "subarray": ("const [s, e] = nums;", "new Float64Array([1, 2, 3]).subarray(s, e).length"),
 "ta_slice": ("const [s, e] = nums;", "new Float64Array([1, 2, 3]).slice(s, e).length"),
 "ta_fill": ("const [s, e] = nums;", "new Float64Array([1, 2, 3]).fill(9, s, e)[1]"),
 "ta_set": ("const [s, e] = nums; const t = new Float64Array(4);", "(t.set([5], s), t[1])"),
 "str_lastIndexOf": ("const [s, e] = nums;", '"abab".lastIndexOf("a", s)'),
 "str_includes": ("const [s, e] = nums;", '"abab".includes("a", s)'),
 "str_endsWith": ("const [s, e] = nums;", '"abab".endsWith("a", s)'),
 "substr": ("const [s, e] = nums;", '"abcdef".substr(s, e)'),
 "padEnd": ("const [w, f] = strs;", '"x".padEnd(3, f)'),
 "setInterval": ("const [n, d] = nums;", "(clearInterval(setInterval(() => {}, d)), 1)"),
 "Promise_resolve_v": ("const [a, b] = strs;", "typeof Promise.resolve(b)"),
 "Error_cause": ("const [a, m] = strs;", 'new Error("e", { cause: m }).message'),
 "toLocaleString": ("const [a, m] = strs;", '(1234).toLocaleString(m === "x" ? "en-US" : "en-US")'),
 "Date_UTC": ("const [n, d] = nums;", "Date.UTC(2020, d)"),
 "new_Uint8Array": ("const [n, d] = nums;", "new Uint8Array(d).length"),
 "array_at_ctor": ("const [n, d] = nums;", "Array.from({ length: d }).length"),
 "arr_findIndex": ("const [a, b] = strs;", "strs.indexOf(b, 1)"),
 "Map_set_value": ("const [a, b] = strs; const m = new Map<string, string | undefined>();", "m.set(a, b).size"),
 "split_sep": ("const [a, b] = strs;", '"xgx".split(a)'),
 "replace_str": ("const [a, b] = strs;", '"xgx".replace(a, b)'),
 "Math_hypot": ("const [a, b] = nums;", "Math.hypot(a, b)"),
 "str_at": ("const [a, b] = nums;", '"abc".at(b)'),
 "concat_str": ("const [a, b] = strs;", '"p".concat(a, b)'),
 "startsWith_pos": ("const [a, b] = nums;", '"abc".startsWith("b", a)'),
 "indexOf_str_from": ("const [a, b] = nums;", '"abcb".indexOf("b", b)'),
 "Number_toString_present": ("const [a, b] = [10, 2];", "(5).toString(a)"),
}
for name, (setup, expr) in cases.items():
    with open(os.path.join(out, f"b2_{name}.pts"), "w") as f:
        f.write(HEADER + setup + "\n" + f'console.log("{name}", {expr});\n')
print(len(cases))
