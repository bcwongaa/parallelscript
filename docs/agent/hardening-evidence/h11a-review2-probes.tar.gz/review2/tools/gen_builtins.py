import os, sys
out = sys.argv[1]
HEADER = '''function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
const nums: number[] = [1];
const strs: string[] = ["x"];
const rows: string[][] = [["a", "b"]];
const recs: Record<string, number>[] = [{ a: 1 }];
const pairs: [string, number][][] = [[["k", 1]]];
const cmps: ((a: number, b: number) => number)[] = [(a, b) => a - b];
'''
# name -> (binding statement, expression printed); the second name is missing, the first present
cases = {
 "slice_end": ("const [s, e] = nums;", '"abcdef".slice(s, e)'),
 "arr_slice_end": ("const [s, e] = nums;", "[1, 2, 3].slice(s, e)"),
 "substring": ("const [s, e] = nums;", '"abcdef".substring(s, e)'),
 "padStart": ("const [w, f] = strs;", '"x".padStart(3, f)'),
 "join": ("const [a, sep] = strs;", '["p", "q"].join(sep)'),
 "toFixed": ("const [n, d] = nums;", "(1.2345).toFixed(d)"),
 "str_indexOf_from": ("const [n, d] = nums;", '"abcabc".indexOf("b", d)'),
 "arr_includes_from": ("const [n, d] = nums;", "[1, 2, 3].includes(1, d)"),
 "split_limit": ("const [n, d] = nums;", '"a,b,c".split(",", d)'),
 "parseInt_radix": ("const [n, r] = nums;", 'parseInt("11", r)'),
 "toString_radix": ("const [n, r] = nums;", "(255).toString(r)"),
 "Error_message": ("const [a, m] = strs;", "new Error(m).message"),
 "splice_count": ("const [s, c] = nums; const xs = [1, 2, 3]; xs.splice(s, c);", "xs"),
 "fill_end": ("const [s, e] = nums;", "[1, 2, 3].fill(0, s, e)"),
 "lastIndexOf_from": ("const [n, d] = nums;", "[1, 2, 1].lastIndexOf(1, d)"),
 "startsWith_pos": ("const [n, d] = nums;", '"abc".startsWith("a", d)'),
 "JSON_space": ("const [n, d] = nums;", "JSON.stringify([1], null, d)"),
 "String_call": ("const [a, m] = strs;", "String(m)"),
 "Number_call": ("const [a, m] = strs;", "Number(m)"),
 "toSpliced": ("const [s, e] = nums;", "[1, 2, 3].toSpliced(s, e)"),
 "copyWithin": ("const [s, e] = nums;", "[1, 2, 3, 4].copyWithin(0, s, e)"),
 "toPrecision": ("const [n, d] = nums;", "(1.2345).toPrecision(d)"),
 "Date_day": ("const [n, d] = nums;", "new Date(2020, 0, d).getFullYear()"),
 "new_Set": ("const [a, b] = rows;", "new Set(b).size"),
 "new_Map": ("const [a, b] = pairs;", "new Map(b).size"),
 "Object_keys": ("const [a, b] = recs;", "Object.keys(b)"),
 "Object_values": ("const [a, b] = recs;", "Object.values(b)"),
 "Object_entries": ("const [a, b] = recs;", "Object.entries(b)"),
 "Object_assign": ("const [a, b] = recs;", "Object.assign({}, b)"),
 "Object_freeze": ("const [a, b] = recs;", "Object.freeze(b)"),
 "structuredClone": ("const [a, b] = recs;", "structuredClone(b)"),
 "JSON_stringify_obj": ("const [a, b] = recs;", "JSON.stringify(b)"),
 "Array_isArray": ("const [a, b] = rows;", "Array.isArray(b)"),
 "sort_cmp": ("const [c1, c2] = cmps;", "[3, 1, 2].sort(c2)"),
 "toSorted_cmp": ("const [c1, c2] = cmps;", "[3, 1, 2].toSorted(c2)"),
 "Promise_resolve": ("const [a, b] = strs;", "typeof Promise.resolve(b)"),
 "Object_keys_present": ("const [a, b] = recs;", "Object.keys(a)"),
 "new_Set_present": ("const [a, b] = rows;", "new Set(a).size"),
 "sort_present": ("const [c1, c2] = cmps;", "[3, 1, 2].sort(c1)"),
 "concat": ("const [a, b] = rows;", '["z"].concat(b)'),
 "push_spread": ("const [a, b] = rows; const out: string[] = [];", "out.push(...a), out"),
 "Array_from": ("const [a, b] = rows;", "Array.from(a)"),
 "localeCompare": ("const [a, m] = strs;", '"a".localeCompare("b", m)'),
 "normalize": ("const [a, m] = strs;", '"e".normalize(m as "NFC" | undefined)'),
 "flat_depth": ("const [n, d] = nums;", "[[1, [2]]].flat(d)"),
 "setTimeout_ms": ("const [n, d] = nums;", 'setTimeout(() => console.log("timer"), d) !== undefined'),
 "map_get": ("const [a, b] = strs; const m = new Map<string | undefined, number>([[undefined, 9]]);", "m.get(b)"),
 "set_has": ("const [a, b] = strs; const st = new Set<string | undefined>([undefined]);", "st.has(b)"),
 "arr_indexOf_value": ("const [a, b] = strs; const xs: (string | undefined)[] = [undefined];", "xs.indexOf(b)"),
 "Symbol_desc": ("const [a, m] = strs;", "Symbol(m).toString()"),
 "Boolean_call": ("const [a, m] = strs;", "Boolean(m)"),
 "isNaN_any": ("const [n, d] = nums;", "Number.isNaN(d)"),
 "Math_max": ("const [n, d] = nums;", "Math.max(n, d ?? 0)"),
}
for name, (setup, expr) in cases.items():
    with open(os.path.join(out, f"bi_{name}.pts"), "w") as f:
        f.write(HEADER)
        f.write(f'show("{name}", () => {{\n  {setup}\n  console.log("{name}", {expr});\n}});\n')
print(len(cases))
