import os, sys
out = sys.argv[1]
HEADER = '''const strs: string[] = ["x"];
const nums: number[] = [1];
const [s0, sMissing] = strs;
const [n0, nMissing] = nums;
'''
cases = {
 "push_unknown": ("const out: unknown[] = [];", "(out.push(sMissing, nMissing), out)"),
 "push_maybe_num": ("const out: (number | undefined)[] = [];", "(out.push(nMissing), out)"),
 "unshift_any": ("const out: any[] = [1];", "(out.unshift(sMissing), out)"),
 "map_set_unknown": ("const m = new Map<string, unknown>();", "m.set('k', nMissing)"),
 "map_get_key": ("const m = new Map<string | undefined, number>([[undefined, 3]]);", "m.get(sMissing)"),
 "map_has_key": ("const m = new Map<string | undefined, number>([[undefined, 3]]);", "m.has(sMissing)"),
 "set_add": ("const st = new Set<number | undefined>();", "st.add(nMissing)"),
 "set_delete": ("const st = new Set<string | undefined>([undefined]);", "(st.delete(sMissing), st.size)"),
 "includes_union": ("const xs: (string | undefined)[] = [undefined];", "xs.includes(sMissing)"),
 "indexOf_union_num": ("const xs: (number | undefined)[] = [5, undefined];", "xs.indexOf(nMissing)"),
 "lastIndexOf_union": ("const xs: (string | undefined)[] = [undefined, 'a'];", "xs.lastIndexOf(sMissing)"),
 "fill_union": ("const xs: (string | undefined)[] = ['a', 'b'];", "xs.fill(sMissing)"),
 "fill_num_union": ("const xs: (number | undefined)[] = [1, 2];", "xs.fill(nMissing, 1)"),
 "with_union": ("const xs: (number | undefined)[] = [1, 2];", "xs.with(0, nMissing)"),
 "splice_items": ("const xs: (string | undefined)[] = ['a'];", "(xs.splice(0, 0, sMissing), xs)"),
 "toSpliced_items": ("const xs: (number | undefined)[] = [1];", "xs.toSpliced(1, 0, nMissing)"),
 "Array_of": ("", "Array.of<string | undefined>(s0, sMissing)"),
 "Promise_resolve_unknown": ("", "(Promise.resolve<unknown>(nMissing).then((v) => console.log('resolved', v)), 'p')"),
 "reduce_init_union": ("", "nums.reduce<number | undefined>((acc, x) => (acc ?? 0) + x, nMissing)"),
 "Object_freeze_explicit": ("", "Object.freeze<string | undefined>(sMissing)"),
 "map_set_key_union": ("const m = new Map<number | undefined, string>();", "m.set(nMissing, 'v')"),
 "unknown_push_present": ("const out: unknown[] = [];", "(out.push(s0, n0), out)"),
 "number_union_push_present": ("const out: (number | undefined)[] = [];", "(out.push(n0), out)"),
 "concat_union": ("const xs: (string | undefined)[] = ['a'];", "xs.concat(sMissing)"),
 "structuredClone_any": ("", "typeof structuredClone"),
 "sort_cmp_any": ("const fs: ((a: number, b: number) => number)[] = [];", "(() => { const [f0] = fs; return [3, 1].sort(f0); })()"),
 "map_callback_result": ("", "strs.map((s) => sMissing)"),
 "find_default_any": ("const xs: unknown[] = [1];", "xs.indexOf(sMissing)"),
}
for name, (setup, expr) in cases.items():
    with open(os.path.join(out, f"ta_{name}.pts"), "w") as f:
        f.write(HEADER + (setup + "\n" if setup else "") + f'console.log("{name}", {expr});\n')
print(len(cases))
