# split_show.py FILE OUTDIR: one file per top-level `show(` statement, each with the file's other top-level code before it
import os, sys
src = open(sys.argv[1]).read().split("\n")
outdir = sys.argv[2]
os.makedirs(outdir, exist_ok=True)
base = os.path.basename(sys.argv[1])[:-4]
header, blocks, cur, depth = [], [], None, 0
for line in src:
    if cur is None and line.startswith("show("):
        cur = []
    if cur is not None:
        cur.append(line)
        depth += line.count("(") + line.count("{") + line.count("[") - line.count(")") - line.count("}") - line.count("]")
        if depth == 0:
            blocks.append(cur); cur = None
    else:
        header.append(line)
for i, b in enumerate(blocks):
    with open(os.path.join(outdir, f"{base}_{i:02d}.pts"), "w") as f:
        f.write("\n".join(header) + "\n" + "\n".join(b) + "\n")
print(len(blocks))
