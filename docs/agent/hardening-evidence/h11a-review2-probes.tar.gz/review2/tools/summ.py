import sys,re
name=None; st={}
rows=[]
for line in open(sys.argv[1]):
    m=re.match(r"##### (\S+)", line)
    if m:
        if name: rows.append((name, st.get("snap","?"), st.get("base","?")))
        name=m.group(1); st={}
        continue
    m=re.match(r"\s+(snap|base) (==|!=) node", line)
    if m: st[m.group(1)]= "OK" if m.group(2)=="==" else "DIFF"
if name: rows.append((name, st.get("snap","?"), st.get("base","?")))
for r in rows: print("%-40s snap=%-4s base=%s" % r)
