#!/bin/bash
# usage: run.sh [-n] [-s] [-b] file.pts ...   runs each under node, snap, base; prints a summary and diffs
# outputs go to /tmp/h11/review2/out/<name>.{node,snap,base}
NODE=$HOME/.local/node/bin/node
OUT=/tmp/h11/review2/out
BIN=/tmp/h11/review2/bin
do_node=1; do_snap=1; do_base=1
while [[ $1 == -* ]]; do
  case $1 in
    -N) do_node=0;; -S) do_snap=0;; -B) do_base=0;;
  esac; shift
done
for f in "$@"; do
  name=$(basename "$f" .pts)
  if [[ $do_node == 1 ]]; then
    tmpd=$(mktemp -d /tmp/h11/review2/nodetmp.XXXX)
    cp "$f" "$tmpd/$name.mts"
    (cd "$tmpd" && TZ=America/New_York timeout 30 $NODE --no-warnings --experimental-transform-types "$name.mts" > $OUT/$name.node 2>$OUT/$name.node.err; echo "exit=$?" >> $OUT/$name.node)
    rm -rf "$tmpd"
  fi
  for tree in snap base; do
    [[ $tree == snap && $do_snap == 0 ]] && continue
    [[ $tree == base && $do_base == 0 ]] && continue
    home=/tmp/h11/snap2; [[ $tree == base ]] && home=/tmp/h11/base
    b=$BIN/$name.$tree.bin
    if TZ=America/New_York PTS_HOME=$home timeout 300 $home/pts-bin/pts build "$f" -o "$b" > $OUT/$name.$tree.build 2>&1; then
      TZ=America/New_York timeout 30 "$b" > $OUT/$name.$tree 2>$OUT/$name.$tree.err; echo "exit=$?" >> $OUT/$name.$tree
    else
      { echo "BUILD FAILED:"; grep -E "error|PTS" $OUT/$name.$tree.build | head -5; } > $OUT/$name.$tree
    fi
    rm -f "$b"
  done
  echo "##### $name"
  for tree in snap base; do
    [[ -f $OUT/$name.$tree ]] || continue
    if [[ $do_node == 1 || -f $OUT/$name.node ]] && cmp -s $OUT/$name.node $OUT/$name.$tree; then echo "  $tree == node"; else echo "  $tree != node"; diff $OUT/$name.node $OUT/$name.$tree | head -20 | sed 's/^/    /'; fi
  done
done
