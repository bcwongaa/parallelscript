#!/bin/bash
# OpenSSL s_server driven through a FIFO: after the client's request, a command line (k: KeyUpdate, r: TLS 1.2
# renegotiation), then an HTTP response, then quit. Client is argv[3] (pts or node).
set -u
trap "" PIPE
cd /tmp/h33/review3/p2
export PATH=$HOME/.local/node/bin:$PATH
L=/tmp/h33/review3/labdir
PORT=$1; VERSION=$2; CLIENT=$3; CMD=$4
FIFO=fifo.$PORT; rm -f $FIFO; mkfifo $FIFO
openssl s_server -accept 127.0.0.1:$PORT -cert $L/ossl.crt -key $L/ossl.key $VERSION -naccept 1 < $FIFO > sserver_$CMD$VERSION$CLIENT.out 2>&1 &
SP=$!
exec 3> $FIFO
sleep 0.7
if [ "$CLIENT" = pts ]; then
  NODE_EXTRA_CA_CERTS=$L/trusted.pem timeout 20 ./one https://localhost:$PORT/ > out_$CMD$VERSION$CLIENT.txt 2>&1 &
else
  NODE_EXTRA_CA_CERTS=$L/trusted.pem timeout 20 node --no-warnings --experimental-transform-types one.mts https://localhost:$PORT/ > out_$CMD$VERSION$CLIENT.txt 2>&1 &
fi
CP=$!
sleep 1.5
if [ "$CMD" != none ]; then printf '%s\n' "$CMD" >&3; sleep 0.7; fi
printf 'HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok' >&3
sleep 0.7
printf 'Q\n' >&3
exec 3>&-
wait $CP; echo "client exit $?"
kill $SP 2>/dev/null; wait $SP 2>/dev/null; rm -f $FIFO
echo "$CLIENT $CMD $VERSION: $(cat out_$CMD$VERSION$CLIENT.txt)"
