#!/bin/bash
# Round 2: starts lab2 (precedence combinations, name decoding), runs c1/combos under Node, pts (snap2's CLI,
# or PTS) and, if built, the ASan/UBSan build c1/combos_san; diffs Node against each; stops lab2 by PID.
set -u
R=/tmp/h33/review3
PTS=${PTS:-/tmp/h33/snap3/pts-bin/pts}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
[ -x $R/lab2/lab2 ] || (cd $R/lab2 && GOMAXPROCS=2 go build -o lab2 .)
$PTS build $R/c1/combos.pts -o $R/c1/combos || exit 1
D=$R/lab2dir; mkdir -p $D; rm -f $D/lab.out
(sleep 600 | $R/lab2/lab2 $D > $D/lab.out 2>&1 & echo $! > $D/lab.pid)
for i in $(seq 1 100); do grep -q ready $D/lab.out 2>/dev/null && break; sleep 0.2; done
ARGS=$(tr '\n' ' ' < $D/args.txt)
export NODE_EXTRA_CA_CERTS=$D/trusted.pem
unset SSL_CERT_FILE SSL_CERT_DIR
node --no-warnings --experimental-transform-types $R/c1/combos.mts $ARGS > $R/c1/node.out 2>&1
$R/c1/combos $ARGS > $R/c1/pts.out 2>&1
echo "=== node vs pts"; diff $R/c1/node.out $R/c1/pts.out
if [ -x $R/c1/combos_san ]; then
  for t in 1 4; do
    PTS_THREADS=$t ASAN_OPTIONS=detect_leaks=1:detect_stack_use_after_return=0 $R/c1/combos_san $ARGS > $R/c1/san$t.out 2> $R/c1/san$t.err
    echo "=== sanitized, PTS_THREADS=$t: exit $?, vs pts:"; diff $R/c1/pts.out $R/c1/san$t.out
    grep -E "ERROR: AddressSanitizer|runtime error" $R/c1/san$t.err | head -3
    awk '/^(Direct|Indirect) leak/{blk=$0; keep=0; next} /^$/{if(keep) print blk; keep=0; next} /tls\.c|fetch\.c|mbedtls|ssl_|x509|psa_/{keep=1}' $R/c1/san$t.err | sort | uniq -c
  done
fi
kill $(cat $D/lab.pid)
