#!/bin/bash
# Replays review round 1's lab probes: starts lab/lab (Go TLS servers, throwaway CAs), runs
# p1/probe1 (chain and name parity) and p4/misc (HEAD/204/304, POST, redirects, precedence)
# under Node and pts (both trusting labdir/trusted.pem through NODE_EXTRA_CA_CERTS), diffs
# them, and stops the lab by its saved PID. PTS defaults to the snapshot's CLI.
set -u
R=/tmp/h33/review3
PTS=${PTS:-/tmp/h33/snap3/pts-bin/pts}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd $R/lab && GOMAXPROCS=2 go build -o lab . || exit 1
mkdir -p $R/labdir.replay && rm -f $R/labdir.replay/lab.out
(sleep 600 | $R/lab/lab $R/labdir.replay > $R/labdir.replay/lab.out 2>&1 & echo $! > $R/labdir.replay/lab.pid)
for i in $(seq 1 100); do grep -q ready $R/labdir.replay/lab.out 2>/dev/null && break; sleep 0.2; done
ARGS=$(tr '\n' ' ' < $R/labdir.replay/args.txt)
export NODE_EXTRA_CA_CERTS=$R/labdir.replay/trusted.pem
unset SSL_CERT_FILE SSL_CERT_DIR
for p in p1/probe1 p4/misc; do
  $PTS build $R/$p.pts -o $R/$p.replay.bin || continue
  node --no-warnings --experimental-transform-types $R/$p.mts $ARGS > $R/$p.node.replay.out 2>&1
  $R/$p.replay.bin $ARGS > $R/$p.pts.replay.out 2>&1
  rm -f $R/$p.replay.bin
  echo "=== $p: diff node pts"; diff $R/$p.node.replay.out $R/$p.pts.replay.out
done
kill $(cat $R/labdir.replay/lab.pid)
