H11b review round 2 probes (reviewer). Snapshot 3 = /tmp/h11b/snap3 (594341ee3); snapshot 2 and base as in round 1.
scripts/run.sh [-w "snap3 snap2 base"] file.pts : builds with each CLI, runs, prints Node's output (.mts copy).
  replay/        round 1's 55 probes (r1/) replayed on snap3, snap2, base, Node; summary.txt from scripts/compare.py
  r1/            round 1's probe archive, unpacked
  m/             R1-F1: stale and lying narrowings of loose locals to interfaces, arrays, functions, shapes, tuples, classes (n01-n07)
  d/             R1-F4: maybeUndefined calls, adapters, i64, spreads, evaluation order (d07-d11: R2-F1)
  w/             R1-F3: switch over union, any, enum, literal, object, integer tags (x01-x05)
  s/             R1-F2/R1-F5: concatenation other sides, `+=`, `void` (y01-y03: R2-F2)
  c/             R1-F6: parenthesized and wrapped callbacks (z01)
  race/          maybePassed's repeated reads of a shared module variable (q01; not reproduced)
  cost/          callgrind: hot calls with union/any arguments, for…of over union arrays, D-221 probes on snap3 (d221/)
  sweep-summary/ emit-c sweeps of 1,062 run tests + 329 other programs, snap2 vs snap3 (no new diagnostics)
