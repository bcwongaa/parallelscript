#!/bin/bash
# emit-c of each listed program (base's copies) with snap3, for a diff against round 1's snap2 sweep.
list=$1
out=/tmp/h11b/review2/sweep/snap3
while read f; do
  n=$(basename "$f" .pts)
  ( cd "$(dirname "$f")" && PTS_HOME=/tmp/h11b/snap3 timeout 120 /tmp/h11b/snap3/pts-bin/pts emit-c "$f" -o "$out/$n.c" > "$out/$n.log" 2>&1 ) || echo "fail $?" >> "$out/$n.log"
done < "$list"
