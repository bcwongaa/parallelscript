#!/bin/bash
# emit-c of round 1's second list (examples, stress, errors, corpus, http) with snap3, named as in round 1.
list=$1
out=/tmp/h11b/review2/sweep2/snap3
while read f; do
  n=$(echo "$f" | sed 's#/tmp/h11b/base/##; s#/#__#g; s#\.pts$##')
  ( cd "$(dirname "$f")" && PTS_HOME=/tmp/h11b/snap3 timeout 120 /tmp/h11b/snap3/pts-bin/pts emit-c "$f" -o "$out/$n.c" > "$out/$n.log" 2>&1 ) || echo "fail $?" >> "$out/$n.log"
done < "$list"
