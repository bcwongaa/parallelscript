#!/bin/bash
# As sweep.sh, into sweep2/, names prefixed by their directory to avoid clashes.
which=$1; list=$2
out=/tmp/h11b/review1/sweep2/$([ $which = base ] && echo base || echo snap)
while read f; do
  n=$(echo "$f" | sed 's#/tmp/h11b/base/##; s#/#__#g; s#\.pts$##')
  ( cd "$(dirname "$f")" && PTS_HOME=/tmp/h11b/$which timeout 120 /tmp/h11b/$which/pts-bin/pts emit-c "$f" -o "$out/$n.c" > "$out/$n.log" 2>&1 ) || echo "fail $?" >> "$out/$n.log"
done < "$list"
