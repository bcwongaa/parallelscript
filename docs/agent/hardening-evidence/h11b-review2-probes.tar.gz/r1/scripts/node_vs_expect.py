import os, re, subprocess, sys, tempfile, shutil
# For each test file: compare Node's stdout with the file's `// expect:` block.
for path in sys.argv[1:]:
    src = open(path).read()
    lines = src.split('\n')
    try:
        i = lines.index('// expect:')
    except ValueError:
        print(path, 'NO EXPECT'); continue
    expect = []
    for l in lines[i+1:]:
        if l.startswith('// '): expect.append(l[3:])
        elif l == '//': expect.append('')
        elif l.strip() == '': continue
        else: break
    markers = [l for l in lines if re.match(r'^// (skip|no-diff):', l)]
    d = tempfile.mkdtemp(dir='/tmp/h11b/review1/tq')
    name = os.path.basename(path).replace('.pts', '.mts')
    shutil.copy(path, os.path.join(d, name))
    p = subprocess.run([os.path.expanduser('~/.local/node/bin/node'), '--no-warnings', '--experimental-transform-types', name], cwd=d, capture_output=True, text=True, timeout=60)
    shutil.rmtree(d)
    got = p.stdout.rstrip('\n').split('\n') if p.stdout else []
    while expect and expect[-1] == '': expect.pop()
    same = got == expect
    print(f"{os.path.basename(path)}: node {'==' if same else '!='} expect; markers={[m[:40] for m in markers]} exit={p.returncode}")
    if not same:
        import difflib
        for l in difflib.unified_diff(expect, got, 'expect', 'node', lineterm='', n=0):
            print('   ', l)
