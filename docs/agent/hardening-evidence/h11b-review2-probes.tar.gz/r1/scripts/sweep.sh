#!/bin/bash
# emit-c of each base test program with base and snap2 CLIs (same source file: base's copy).
# Usage: sweep.sh which listfile   (which = base|snap2)
which=$1; list=$2
out=/tmp/h11b/review1/sweep/$([ $which = base ] && echo base || echo snap)
while read f; do
  n=$(basename "$f" .pts)
  ( cd "$(dirname "$f")" && PTS_HOME=/tmp/h11b/$which timeout 120 /tmp/h11b/$which/pts-bin/pts emit-c "$f" -o "$out/$n.c" > "$out/$n.log" 2>&1 ) || echo "fail $?" >> "$out/$n.log"
done < "$list"
