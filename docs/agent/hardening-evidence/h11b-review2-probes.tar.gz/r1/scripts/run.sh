#!/bin/bash
# Usage: run.sh [-s] file.pts...   Builds each with snapshot (and base unless -s), runs, prints Node's output.
# Sequential: one heavy job at a time. Binaries deleted after running.
only_snap=0
if [ "$1" = "-s" ]; then only_snap=1; shift; fi
B=/tmp/h11b/review1/bin
for f in "$@"; do
  n=$(basename "$f" .pts)
  echo "======== $f"
  for which in snap2 base; do
    [ $only_snap = 1 ] && [ $which = base ] && continue
    bin="$B/$n.$which.bin"
    if PTS_HOME=/tmp/h11b/$which /tmp/h11b/$which/pts-bin/pts build "$f" -o "$bin" > "$B/$n.$which.build.log" 2>&1; then
      out=$(cd /tmp && timeout 20 "$bin" 2>&1 | head -60; echo "exit=${PIPESTATUS[0]}")
      echo "-- $which:"; echo "$out"
      rm -f "$bin"
    else
      echo "-- $which build failed:"; grep -v '^\s*$' "$B/$n.$which.build.log" | head -8
    fi
  done
  tmp=$(mktemp -d /tmp/h11b/review1/bin/node-XXXX)
  cp "$f" "$tmp/$n.mts"
  echo "-- node:"
  (cd "$tmp" && timeout 20 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" 2>&1 | grep -v '^\s*at \|^Node.js v\|^$' | head -40; echo "exit=${PIPESTATUS[0]}")
  rm -rf "$tmp"
done
