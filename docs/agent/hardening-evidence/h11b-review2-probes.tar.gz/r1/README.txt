H11b review round 1 probes (reviewer). Each probe dir holds .pts sources and, where captured,
.out files with snapshot (snap2), base and Node outputs as printed by scripts/run.sh.
  m/  memory safety of FromUnion.Defined (lying predicates, stale narrowings, writes, generics, races)
  s/  for…of loose variable semantics, concatenation, element kinds
  c/  callback forms, defaults, receivers (closureSignature keepsDefaults regressions)
  r/  callback defaults across methods, tuples, typed arrays, Array.from sources
  f/  find and its kin over shortened arrays (incl. integer arrays)
  a/  Array.from mapper edges
  w/  switch `case undefined`, `f?.()`
  cost/ callgrind spot checks (scripts/cost.sh; results.txt, d221/results.txt)
  sweep-summary/ emit-c sweep of base's 1069 run tests + 510 other programs, base vs snap2
  scripts/ run.sh (build+run snap2/base, Node via .mts), cost.sh, sweep*.sh, node_vs_expect.py
Re-run a probe: cd <dir> && ../scripts/run.sh <file>.pts
