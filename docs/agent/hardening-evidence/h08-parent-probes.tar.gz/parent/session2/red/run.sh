#!/bin/bash
# run.sh WORKTREE OUT: the round-2 regression tests under TestRun, TestRunMatchesNode and TestErrors in that worktree.
set -uo pipefail
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2 PTS_REQUIRE_NODE=1
cd "$1" && go test -count=1 -timeout 40m -v -run '^(TestRun|TestRunMatchesNode|TestErrors)$/^(logical_assign_suspension_unset_fields|suspension_literal_operands_evaluate_first|logical_assign_suspension_values|union_callee_suspension)$' ./pts/tests/ > "$2" 2>&1
echo "exit $?" >> "$2"
