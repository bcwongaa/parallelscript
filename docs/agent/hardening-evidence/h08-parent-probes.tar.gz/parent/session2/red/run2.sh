#!/bin/bash
# run2.sh WORKTREE OUT TEST: one run test under TestRun and TestRunMatchesNode in that worktree.
set -uo pipefail
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2 PTS_REQUIRE_NODE=1
cd "$1" && go test -count=1 -timeout 40m -v -run "^(TestRun|TestRunMatchesNode)\$/^($3)\$" ./pts/tests/ > "$2" 2>&1
echo "exit $?" >> "$2"
