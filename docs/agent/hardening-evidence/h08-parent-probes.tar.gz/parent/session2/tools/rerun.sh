#!/bin/bash
# rerun.sh OUT FILE.pts...: build and run each with the main tree's CLI; compare with the reviewer's
# recorded node/fix outputs in /tmp/h08/rev1/out (or $REF). Prints NAME: node=OK|DIFF snap=SAME|CHANGED.
set -u
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
repo=/home/bryan/projects/parallelscript; cli=$repo/pts-bin/pts; ref=${REF:-/tmp/h08/rev1/out}
out=$1; shift; mkdir -p "$out/bin"
one() {
  f=$1; name=$(basename "$f" .pts); dir=$(cd "$(dirname "$f")" && pwd)
  bin="$out/bin/$name.bin"; rm -f "$bin"
  PTS_HOME=$repo timeout 300 "$cli" build "$dir/$name.pts" -o "$bin" > "$out/$name.build.txt" 2>&1; be=$?
  if [ $be -ne 0 ]; then { cat "$out/$name.build.txt"; echo "[build exit $be]"; } > "$out/$name.now.txt"
  else (cd "$ref" && timeout 30 "$bin" > "$out/$name.now.txt" 2>&1; echo "[exit $?]" >> "$out/$name.now.txt"); fi
  rm -f "$bin"
  n=$( [ -f "$ref/$name.node.txt" ] && { cmp -s "$out/$name.now.txt" "$ref/$name.node.txt" && echo OK || echo DIFF; } || echo NONE)
  s=$( [ -f "$ref/$name.fix.txt" ] && { cmp -s "$out/$name.now.txt" "$ref/$name.fix.txt" && echo SAME || echo CHANGED; } || echo NONE)
  echo "$name: node=$n snap=$s"
}
export -f one; export out ref cli repo
printf '%s\n' "$@" | xargs -P 3 -I{} bash -c 'one "$@"' _ {}
