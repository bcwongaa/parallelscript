#!/usr/bin/env python3
"""H08 matrix runner: builds and runs every generated program with the PTS CLI and under
Node, and classifies each case:
  OK     its line matches Node's
  WRONG  it runs but its line differs from Node's
  DIAG   a PTS compile error (PTS1001 or another diagnostic; exit 1)
  TSERR  a TypeScript error (the generator's fault, not the compiler's)
  ICE    internal compiler error (build exit 3)
  CRASH  the program exits non-zero or times out where Node doesn't
A program that fails to build or run is split: each of its cases is built alone. Each case
that isn't OK also gets its control (the suspension replaced by 10) built and compared, to
tell suspension defects (control OK) from unrelated ones.

Usage: python3 -I run.py MATRIXDIR [JOBS]   (env PTS_CLI, PTS_HOME)
Writes MATRIXDIR/results.json and MATRIXDIR/summary.txt.
"""
import collections
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys

CLI = os.environ.get("PTS_CLI", "/tmp/h08/base/pts-bin/pts")
HOME = os.environ.get("PTS_HOME", "/tmp/h08/base")
NODE = os.path.expanduser("~/.local/node/bin/node")
ENV = dict(os.environ, PTS_HOME=HOME, PATH=os.path.expanduser("~/.local/node/bin") + ":" + os.path.expanduser("~/.local/go/bin") + ":" + os.environ["PATH"])
LINE = re.compile(r"^\{\{(.*?)\}\} (.*)$")


def run(cmd, timeout, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=ENV, cwd=cwd)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        return "timeout", (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), ""


def lines_of(stdout):
    got = {}
    for line in stdout.splitlines():
        m = LINE.match(line)
        if m:
            got[m.group(1)] = m.group(2)
    return got


def node_run(src, work):
    mts = os.path.join(work, os.path.basename(src)[:-4] + ".mts")
    shutil.copyfile(src, mts)
    code, out, err = run([NODE, "--no-warnings", "--experimental-transform-types", mts], 60, cwd=work)
    return code, out, err


def pts_run(src, work):
    exe = os.path.join(work, os.path.basename(src)[:-4] + ".bin")
    code, out, err = run([CLI, "build", src, "-o", exe], 300, cwd=work)
    if code != 0:
        return ("build", code, out + err)
    rc, rout, rerr = run([exe], 60, cwd=work)
    try:
        os.remove(exe)
    except OSError:
        pass
    return ("run", rc, rout, rerr)


def classify_build_failure(code, text):
    if code == 3:
        return "ICE"
    if re.search(r"error TS\d+", text):
        return "TSERR"
    return "DIAG"


def first_diag(text):
    for line in text.splitlines():
        if "error" in line:
            return re.sub(r"^.*?(error )", r"\1", line)[:300]
    return text.strip().splitlines()[0][:300] if text.strip() else ""


def single(matrix, n, control=False):
    """Classify one case alone: returns (verdict, pts line or diag, node line)."""
    src = os.path.join(matrix, "single", f"c{n}{'_control' if control else ''}.pts")
    work = os.path.join(matrix, "work", f"c{n}{'_control' if control else ''}")
    os.makedirs(work, exist_ok=True)
    ncode, nout, nerr = node_run(src, work)
    nl = lines_of(nout)
    r = pts_run(src, work)
    if r[0] == "build":
        return classify_build_failure(r[1], r[2]), first_diag(r[2]), next(iter(nl.values()), f"<node exit {ncode}> {nerr[-300:]}")
    _, rc, rout, rerr = r
    pl = lines_of(rout)
    nline = next(iter(nl.values()), f"<node exit {ncode}> {nerr[-300:]}")
    if rc != 0 or not pl:
        return "CRASH", f"<exit {rc}> {next(iter(pl.values()), '')} {rerr.strip()[-300:]}", nline
    pline = next(iter(pl.values()))
    return ("OK" if pline == nline else "WRONG"), pline, nline


def program(matrix, name, info):
    src = os.path.join(matrix, "progs", name + ".pts")
    work = os.path.join(matrix, "work", name)
    os.makedirs(work, exist_ok=True)
    ncode, nout, nerr = node_run(src, work)
    nl = lines_of(nout)
    results = {}
    r = pts_run(src, work)
    split = []
    if r[0] == "build":
        split = info["cases"]
        prog_note = f"build {r[1]}: {first_diag(r[2])}"
    else:
        _, rc, rout, rerr = r
        pl = lines_of(rout)
        prog_note = f"run exit {rc}"
        for cid in info["cases"]:
            if cid not in pl:
                split.append(cid)
            elif cid not in nl:
                results[cid] = dict(verdict="NODEFAIL", pts=pl[cid], node=f"<node exit {ncode}> {nerr[-300:]}")
            else:
                results[cid] = dict(verdict="OK" if pl[cid] == nl[cid] else "WRONG", pts=pl[cid], node=nl[cid])
    return name, prog_note, results, split


def main():
    matrix = sys.argv[1]
    jobs = int(sys.argv[2]) if len(sys.argv) > 2 else 2
    manifest = json.load(open(os.path.join(matrix, "manifest.json")))
    cases = manifest["cases"]
    results, notes, to_split = {}, {}, []
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for name, note, res, split in pool.map(lambda kv: program(matrix, *kv), manifest["programs"].items()):
            notes[name] = note
            results.update(res)
            to_split += split
            print(f"{name}: {note}; {sum(1 for v in res.values() if v['verdict'] == 'OK')} OK, "
                  f"{sum(1 for v in res.values() if v['verdict'] != 'OK')} not OK, {len(split)} split", flush=True)
        # cases whose program didn't build or run: alone
        for cid, (verdict, pts, node) in zip(to_split, pool.map(lambda cid: single(matrix, cases[cid]["n"]), to_split)):
            results[cid] = dict(verdict=verdict, pts=pts, node=node, alone=True)
        # controls for every case that isn't OK
        bad = [cid for cid, r in results.items() if r["verdict"] != "OK"]
        for cid, (verdict, pts, node) in zip(bad, pool.map(lambda cid: single(matrix, cases[cid]["n"], control=True), bad)):
            results[cid]["control"] = dict(verdict=verdict, pts=pts, node=node)
    for cid, r in results.items():
        r["dims"] = cases[cid]["dims"]
        r["n"] = cases[cid]["n"]
    json.dump(dict(notes=notes, results=results), open(os.path.join(matrix, "results.json"), "w"), indent=1)
    summarize(matrix, results)


def summarize(matrix, results):
    out = []
    total = collections.Counter(r["verdict"] for r in results.values())
    out.append(f"cases: {len(results)}  " + "  ".join(f"{k}={v}" for k, v in sorted(total.items())))
    supp = collections.Counter((r["verdict"], r.get("control", {}).get("verdict", "-")) for r in results.values() if r["verdict"] != "OK")
    out.append("not OK by (verdict, control verdict): " + ", ".join(f"{k}={v}" for k, v in sorted(supp.items())))
    by = collections.defaultdict(collections.Counter)
    for r in results.values():
        d = r["dims"]
        by[(d["family"], d["mode"])][r["verdict"]] += 1
    out.append("\nby family and mode:")
    for k in sorted(by):
        out.append(f"  {k[0]:10s} {k[1]:6s} " + "  ".join(f"{v}={c}" for v, c in sorted(by[k].items())))
    tgt = collections.defaultdict(collections.Counter)
    for r in results.values():
        d = r["dims"]
        tgt[(d["family"], d["target"])][r["verdict"]] += 1
    out.append("\nby family and target (yield and await together):")
    for k in sorted(tgt):
        out.append(f"  {k[0]:10s} {k[1]:34s} " + "  ".join(f"{v}={c}" for v, c in sorted(tgt[k].items())))
    out.append("\nevery case that isn't OK:")
    for cid in sorted(results, key=lambda c: (results[c]["verdict"], c)):
        r = results[cid]
        if r["verdict"] == "OK":
            continue
        ctl = r.get("control", {})
        out.append(f"{r['verdict']:6s} c{r['n']} {cid}  [control {ctl.get('verdict', '-')}]")
        out.append(f"        pts:  {r['pts']}")
        out.append(f"        node: {r['node']}")
        if ctl.get("verdict") not in (None, "OK"):
            out.append(f"        control pts:  {ctl.get('pts')}")
            out.append(f"        control node: {ctl.get('node')}")
    open(os.path.join(matrix, "summary.txt"), "w").write("\n".join(out) + "\n")
    print("\n".join(out[:40]))


if __name__ == "__main__":
    if len(sys.argv) > 2 and sys.argv[2] == "summarize":
        m = sys.argv[1]
        summarize(m, json.load(open(os.path.join(m, "results.json")))["results"])
    else:
        main()
