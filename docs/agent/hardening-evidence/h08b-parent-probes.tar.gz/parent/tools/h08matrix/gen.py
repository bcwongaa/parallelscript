#!/usr/bin/env python3
"""H08 differential side-effect matrix: writes small ParallelScript programs (.pts, which run
unchanged under Node as .mts) that each hold several independent cases. A case is one
statement whose right side (or an argument) suspends, with `yield` (a generator driven by a
loop) or `await` (an async function; a microtask queued before the await changes state while
it is suspended). Each case prints one line: `[id] trace => final values`.

Every case also has a control twin (the suspension replaced by the constant 10): the runner
builds controls for cases that fail, to tell suspension defects from unrelated ones.

Usage: python3 -I gen.py OUTDIR   (writes OUTDIR/progs/*.pts and OUTDIR/manifest.json)
Exhaustive over a fixed grid; no randomness.
"""
import json
import os
import sys

PRELUDE = """\
const trace: string[] = [];
const log = (s: string): void => { trace.push(s); };
const id = (n: number): number => { log("id " + n); return n; };
const pre = (): number => { log("pre"); return 0; };
const ten = (m: () => void): Promise<number> => {
  log("susp");
  queueMicrotask(() => { log("mut"); m(); });
  return Promise.resolve(10);
};
const report = (name: string, values: string): void => {
  console.log("{{" + name + "}} " + trace.join(",") + " => " + values);
  trace.length = 0;
};
const pair = (a: number, b: number): string => a + "/" + b;
const bpair = (a: boolean, b: number): string => a + "/" + b;
const upair = (a: unknown, b: number): string => String(a) + "/" + b;
const sum = (...xs: number[]): number => { let t = 0; for (const x of xs) t += x; return t; };
"""

# ---------------------------------------------------------------------------------------
# Targets of compound and logical assignments. Each is a function of (n, t, init, mutated)
# giving: decl (module scope), setup (statements in the case's function before the
# statement), place, mut (statements run while suspended), values (an expression of the
# final state, a string), post (statements after the statement), method (the case's
# function is a method of class `M_n`, created as `o_n`).
# t is the place's TS type ("number", "number | undefined", "string"); init and mutated are
# TS literals of that type.


def acc_class(n, t, init, name="A"):
    return (f"class {name}_{n} {{\n  v: {t} = {init};\n"
            f"  get p(): {t} {{ log(\"get\"); return this.v; }}\n"
            f"  set p(x: {t}) {{ log(\"set \" + x); this.v = x; }}\n}}\n")


def target_defs():
    T = {}

    def add(name, fn, types=("number", "number | undefined", "string"), ops=None):
        T[name] = dict(fn=fn, types=types, ops=ops)

    add("local", lambda n, t, i, m: dict(
        decl="", setup=f"let x: {t} = {i};", place="x", mut="", post='log("x " + x);', values='""'))
    add("captured", lambda n, t, i, m: dict(
        decl=f"let set_{n}: (v: {t}) => void = (v: {t}): void => {{}};",
        setup=f"let x: {t} = {i}; set_{n} = (v: {t}): void => {{ x = v; }};",
        place="x", mut=f"set_{n}({m});", post='log("x " + x);', values='""'))
    add("module", lambda n, t, i, m: dict(
        decl=f"let m_{n}: {t} = {i};", place=f"m_{n}", mut=f"m_{n} = {m};", values=f"String(m_{n})"))
    add("field", lambda n, t, i, m: dict(
        decl=f"class F_{n} {{ f: {t} = {i}; }}\nconst o_{n} = new F_{n}();",
        place=f"o_{n}.f", mut=f"o_{n}.f = {m};", values=f"String(o_{n}.f)"))
    add("static field", lambda n, t, i, m: dict(
        decl=f"class S_{n} {{ static f: {t} = {i}; }}",
        place=f"S_{n}.f", mut=f"S_{n}.f = {m};", values=f"String(S_{n}.f)"))
    add("accessor", lambda n, t, i, m: dict(
        decl=acc_class(n, t, i) + f"const o_{n} = new A_{n}();",
        place=f"o_{n}.p", mut=f"o_{n}.v = {m};", values=f"String(o_{n}.v)"))
    add("inherited accessor", lambda n, t, i, m: dict(
        decl=acc_class(n, t, i) + f"class B_{n} extends A_{n} {{ w = 0; }}\nconst o_{n} = new B_{n}();",
        place=f"o_{n}.p", mut=f"o_{n}.v = {m};", values=f"String(o_{n}.v)"))
    add("interface accessor", lambda n, t, i, m: dict(
        decl=acc_class(n, t, i) + f"interface I_{n} {{ p: {t} }}\nconst a_{n} = new A_{n}();\nconst o_{n}: I_{n} = a_{n};",
        place=f"o_{n}.p", mut=f"a_{n}.v = {m};", values=f"String(a_{n}.v)"))
    add("literal accessor", lambda n, t, i, m: dict(
        decl=(f"const o_{n} = {{\n  v: {i} as {t},\n  get p(): {t} {{ log(\"get\"); return this.v; }},\n"
              f"  set p(x: {t}) {{ log(\"set \" + x); this.v = x; }},\n}};"),
        place=f"o_{n}.p", mut=f"o_{n}.v = {m};", values=f"String(o_{n}.v)"))
    add("shape", lambda n, t, i, m: dict(
        decl=f"const o_{n} = {{ p: {i} as {t}, q: 0 }};",
        place=f"o_{n}.p", mut=f"o_{n}.p = {m};", values=f"String(o_{n}.p)"))
    # an `any` place that starts undefined is a JSON.parse object (a hash-map object, which
    # takes any value and can gain properties); a literal's undefined property holds only
    # undefined (D-L10), which would make the test about something else.
    add("any", lambda n, t, i, m: dict(
        decl=f"const o_{n}: any = {{ p: {i} }};" if i != "undefined" else f"const o_{n}: any = JSON.parse(\"{{}}\");",
        place=f"o_{n}.p", mut=f"o_{n}.p = {m};", values=f"String(o_{n}.p)"))
    add("any accessor", lambda n, t, i, m: dict(
        decl=acc_class(n, t, i) + f"const a_{n} = new A_{n}();\nconst o_{n}: any = a_{n};",
        place=f"o_{n}.p", mut=f"a_{n}.v = {m};", values=f"String(a_{n}.v)"))
    add("any element", lambda n, t, i, m: dict(
        decl=f"const o_{n}: any = [{i}, 1];",
        place=f"o_{n}[0]", mut=f"o_{n}[0] = {m};", values=f"String(o_{n}[0])"))
    add("array", lambda n, t, i, m: dict(
        decl=f"const o_{n}: ({t})[] = [{i}, {i}];",
        place=f"o_{n}[0]", mut=f"o_{n}[0] = {m};", values=f"String(o_{n}[0])"))
    add("tuple", lambda n, t, i, m: dict(
        decl=f"const o_{n}: [{t}, boolean] = [{i}, true];",
        place=f"o_{n}[0]", mut=f"o_{n}[0] = {m};", values=f"String(o_{n}[0])"))
    add("typed array", lambda n, t, i, m: dict(
        decl=f"const o_{n} = new Float64Array([{i}, 1]);",
        place=f"o_{n}[0]", mut=f"o_{n}[0] = {m};", values=f"String(o_{n}[0])"), types=("number",))
    add("record", lambda n, t, i, m: dict(
        decl=f"const o_{n}: Record<string, {t}> = {{ p: {i} }};",
        place=f"o_{n}.p", mut=f"o_{n}.p = {m};", values=f"String(o_{n}.p)"))
    add("record element", lambda n, t, i, m: dict(
        decl=f"const o_{n}: Record<string, {t}> = {{ p: {i} }};",
        place=f"o_{n}[\"p\"]", mut=f"o_{n}[\"p\"] = {m};", values=f"String(o_{n}.p)"))
    add("index signature [k]", lambda n, t, i, m: dict(
        decl=f"const o_{n}: {{ [k: string]: {t} }} = {{ p: {i} }};\nconst k_{n} = \"p\";",
        place=f"o_{n}[k_{n}]", mut=f"o_{n}.p = {m};", values=f"String(o_{n}.p)"))
    add("union field", lambda n, t, i, m: dict(
        decl=(f"class U1_{n} {{ p: {t} = {i}; u1 = 1; }}\nclass U2_{n} {{ p: {t} = {i}; u2 = \"x\"; }}\n"
              f"const pick_{n} = (): U1_{n} | U2_{n} => new U1_{n}();\nconst o_{n} = pick_{n}();"),
        place=f"o_{n}.p", mut=f"o_{n}.p = {m};", values=f"String(o_{n}.p)"))
    add("this field", lambda n, t, i, m: dict(
        decl="", cls=f"f: {t} = {i};", method=True,
        place="this.f", mut=f"o_{n}.f = {m};", values=f"String(o_{n}.f)"))
    add("this accessor", lambda n, t, i, m: dict(
        decl="", cls=(f"v: {t} = {i};\n  get p(): {t} {{ log(\"get\"); return this.v; }}\n"
                      f"  set p(x: {t}) {{ log(\"set \" + x); this.v = x; }}"), method=True,
        place="this.p", mut=f"o_{n}.v = {m};", values=f"String(o_{n}.v)"))
    add("super accessor", lambda n, t, i, m: dict(
        decl=acc_class(n, t, i, "SA"), base=f"SA_{n}", cls="w = 0;", method=True,
        place="super.p", mut=f"o_{n}.v = {m};", values=f"String(o_{n}.v)"))
    return T


TARGETS = target_defs()

# Right-side forms: SUSP is the suspension, of type number (10 once resumed).
RHS_FORMS = {"direct": "SUSP", "call": "id(SUSP)", "binary": "pre() + SUSP"}


def susp_text(mode, n, control):
    if control:
        return "(10)"
    return "(yield 0)" if mode == "yield" else f"(await ten(mut_{n}))"


def literal(t, value):
    if t == "string":
        return json.dumps(str(value))
    return str(value)


class Program:
    def __init__(self, name):
        self.name = name
        self.cases = []  # dicts: id, decl, func (text of the generator/async function or class), call (driver), values

    def add(self, case):
        self.cases.append(case)


def case_text(mode, case, control):
    """The module-scope text of one case: declarations, its mutation, its function, and a
    runner function `run_<n>` (yield: synchronous; await: async)."""
    n = case["n"]
    susp = susp_text(mode, n, control)
    body = case["body"].replace("SUSP", susp)
    setup = case.get("setup", "")
    post = case.get("post", "")
    lines = [case["decl"]]
    stmts = "\n  ".join(s for s in (setup, body, post) if s)
    if mode == "yield":
        sig = f"*g(): Generator<number, void, number>"
        free_sig = f"function* g_{n}(): Generator<number, void, number>"
    else:
        sig = f"async g(): Promise<void>"
        free_sig = f"async function g_{n}(): Promise<void>"
    if case.get("method"):
        base = case.get("base")
        ext = f" extends {base}" if base else ""
        lines.append(f"class M_{n}{ext} {{\n  {case.get('cls', '')}\n  {sig} {{\n  {stmts}\n  }}\n}}\nconst o_{n} = new M_{n}();")
        start = f"o_{n}.g()"
    else:
        lines.append(f"{free_sig} {{\n  {stmts}\n}}")
        start = f"g_{n}()"
    lines.append(f"const mut_{n} = (): void => {{ {case['mut']} }};")
    if mode == "yield":
        lines.append(f"function run_{n}(): void {{\n  const it = {start};\n  let s = it.next();\n"
                     f"  while (!s.done) {{ log(\"susp\"); log(\"mut\"); mut_{n}(); s = it.next(10); }}\n"
                     f"  report(\"{case['id']}\", {case['values']});\n}}")
    else:
        lines.append(f"async function run_{n}(): Promise<void> {{\n  await {start};\n  report(\"{case['id']}\", {case['values']});\n}}")
    return "\n".join(l for l in lines if l)


def program_text(mode, cases, control=False):
    parts = [PRELUDE]
    for case in cases:
        parts.append(f"// case {case['id']}: {case['desc']}")
        parts.append(case_text(mode, case, control))
    if mode == "yield":
        parts.append("\n".join(f"run_{c['n']}();" for c in cases))
    else:
        parts.append("async function main(): Promise<void> {\n" + "\n".join(f"  await run_{c['n']}();" for c in cases) + "\n}\nmain();")
    return "\n".join(parts) + "\n"


# ---------------------------------------------------------------------------------------
# Families.

counter = [0]


def next_n():
    counter[0] += 1
    return counter[0]


NUMERIC_OPS = ["+=", "-=", "*=", "**=", "|=", "<<="]


def compound_cases(mode):
    """Group A: arithmetic compound assignments over every numeric target and right-side
    form; group B: string `+=`. The place holds 1 ("a"), the mutation makes it 2 ("b")."""
    progs = []
    for tname, target in TARGETS.items():
        cases = []
        for op in NUMERIC_OPS + ["s+="]:
            t = "string" if op == "s+=" else "number"
            if t not in target["types"]:
                continue
            real_op = "+=" if op == "s+=" else op
            for form, rhs in RHS_FORMS.items():
                n = next_n()
                d = target["fn"](n, t, literal(t, "a" if t == "string" else 1), literal(t, "b" if t == "string" else 2))
                cases.append(dict(
                    n=n, id=f"{mode}|compound|{tname}|{op}|{form}", desc=f"{tname} {op} {form} ({mode})",
                    decl=d["decl"], setup=d.get("setup", ""), post=d.get("post", ""), mut=d["mut"],
                    body=f"{d['place']} {real_op} {rhs};", values=d["values"], method=d.get("method", False),
                    cls=d.get("cls", ""), base=d.get("base"),
                    dims=dict(family="compound", mode=mode, target=tname, op=op, form=form)))
        progs.append((f"{mode}_compound_{slug(tname)}", mode, cases))
    return progs


def logical_cases(mode):
    """Group C: `??=`, `||=`, `&&=` that store or don't. A suspension must happen only
    when the assignment stores; the mutation makes the place's test change."""
    progs = []
    plans = [  # op, type, init when it stores, init when it doesn't, mutated value
        ("??=", "number | undefined", "undefined", "1", "2"),
        ("||=", "number", "0", "5", "2"),
        ("&&=", "number", "5", "0", "0"),
    ]
    for tname, target in TARGETS.items():
        cases = []
        for op, t, store_init, keep_init, mutated in plans:
            if t not in target["types"]:
                continue
            for stores, init in (("stores", store_init), ("keeps", keep_init)):
                for form, rhs in RHS_FORMS.items():
                    n = next_n()
                    if tname in ("any", "any element") and init == "undefined":
                        d = target["fn"](n, t, "undefined", mutated)
                    else:
                        d = target["fn"](n, t, init, mutated)
                    cases.append(dict(
                        n=n, id=f"{mode}|logical|{tname}|{op}|{stores}|{form}", desc=f"{tname} {op} {stores} {form} ({mode})",
                        decl=d["decl"], setup=d.get("setup", ""), post=d.get("post", ""), mut=d["mut"],
                        body=f"{d['place']} {op} {rhs};", values=d["values"], method=d.get("method", False),
                        cls=d.get("cls", ""), base=d.get("base"),
                        dims=dict(family="logical", mode=mode, target=tname, op=op, stores=stores, form=form)))
        progs.append((f"{mode}_logical_{slug(tname)}", mode, cases))
    return progs


# Group D: calls whose argument suspends; the function (or its receiver) is replaced
# while suspended. Each: decl, callee expression, mutation, method scaffolding.
def callee_defs(n):
    old = "(k: number): string => \"old \" + k"
    new = "(k: number): string => \"new \" + k"
    return {
        "literal fn property": dict(decl=f"const o_{n} = {{ m: {old} }};", callee=f"o_{n}.m", mut=f"o_{n}.m = {new};"),
        "literal fn property via element": dict(decl=f"const o_{n} = {{ m: {old} }};", callee=f"o_{n}[\"m\"]", mut=f"o_{n}.m = {new};"),
        "class fn field": dict(decl=f"class C_{n} {{ m: (k: number) => string = {old}; }}\nconst o_{n} = new C_{n}();", callee=f"o_{n}.m", mut=f"o_{n}.m = {new};"),
        "interface fn property": dict(decl=f"interface I_{n} {{ m: (k: number) => string }}\nconst o_{n}: I_{n} = {{ m: {old} }};", callee=f"o_{n}.m", mut=f"o_{n}.m = {new};"),
        "any method": dict(decl=f"const o_{n}: any = {{ m: {old} }};", callee=f"o_{n}.m", mut=f"o_{n}.m = {new};"),
        "any method via element": dict(decl=f"const o_{n}: any = {{ m: {old} }};", callee=f"o_{n}[\"m\"]", mut=f"o_{n}.m = {new};"),
        "nested chain": dict(decl=f"const o_{n} = {{ a: {{ b: {{ m: {old} }} }} }};", callee=f"o_{n}.a.b.m", mut=f"o_{n}.a.b.m = {new};"),
        "nested chain receiver swapped": dict(decl=f"const o_{n} = {{ a: {{ b: {{ m: {old} }} }} }};", callee=f"o_{n}.a.b.m", mut=f"o_{n}.a.b = {{ m: {new} }};"),
        "getter returns fn": dict(decl=f"const o_{n} = {{ impl: {old}, get m(): (k: number) => string {{ log(\"getter\"); return this.impl; }} }};", callee=f"o_{n}.m", mut=f"o_{n}.impl = {new};"),
        "class getter returns fn": dict(decl=f"class C_{n} {{ impl: (k: number) => string = {old}; get m(): (k: number) => string {{ log(\"getter\"); return this.impl; }} }}\nconst o_{n} = new C_{n}();", callee=f"o_{n}.m", mut=f"o_{n}.impl = {new};"),
        "record of fns": dict(decl=f"const o_{n}: Record<string, (k: number) => string> = {{ m: {old} }};", callee=f"o_{n}.m", mut=f"o_{n}.m = {new};"),
        "record of fns via key": dict(decl=f"const o_{n}: Record<string, (k: number) => string> = {{ m: {old} }};\nconst key_{n} = \"m\";", callee=f"o_{n}[key_{n}]", mut=f"o_{n}.m = {new};"),
        "array of fns": dict(decl=f"const o_{n}: ((k: number) => string)[] = [{old}];", callee=f"o_{n}[0]", mut=f"o_{n}[0] = {new};"),
        "receiver variable swapped": dict(decl=f"class C_{n} {{ constructor(public tag: string) {{}} m(k: number): string {{ return this.tag + \" \" + k; }} }}\nlet o_{n} = new C_{n}(\"old\");", callee=f"o_{n}.m", mut=f"o_{n} = new C_{n}(\"new\");"),
        "receiver field swapped": dict(decl=f"class C_{n} {{ constructor(public tag: string) {{}} m(k: number): string {{ return this.tag + \" \" + k; }} }}\nconst h_{n} = {{ c: new C_{n}(\"old\") }};", callee=f"h_{n}.c.m", mut=f"h_{n}.c = new C_{n}(\"new\");"),
        "free fn variable": dict(decl=f"let o_{n} = {old};", callee=f"o_{n}", mut=f"o_{n} = {new};"),
        "this fn field": dict(decl="", cls=f"m: (k: number) => string = {old};", method=True, callee="this.m", mut=f"o_{n}.m = {new};"),
        "this method, field read": dict(decl="", cls="tag = \"old\";\n  m(k: number): string { return this.tag + \" \" + k; }", method=True, callee="this.m", mut=f"o_{n}.tag = \"new\";"),
        "map get result": dict(decl=f"const o_{n} = new Map<string, (k: number) => string>([[\"m\", {old}]]);", callee=f"o_{n}.get(\"m\")!", mut=f"o_{n}.set(\"m\", {new});"),
    }


def call_cases(mode):
    progs = []
    names = list(callee_defs(0).keys())
    for cname in names:
        cases = []
        for form, arg in RHS_FORMS.items():
            n = next_n()
            d = callee_defs(n)[cname]
            cases.append(dict(
                n=n, id=f"{mode}|call|{cname}|{form}", desc=f"{cname} {form} ({mode})",
                decl=d["decl"], mut=d["mut"], body=f"log({d['callee']}({arg}));", values='""',
                method=d.get("method", False), cls=d.get("cls", ""),
                dims=dict(family="call", mode=mode, target=cname, form=form)))
        progs.append((f"{mode}_call_{slug(cname)}", mode, cases))
    return progs


# Group E: reference operands with side effects (index, key, receiver) of compound, plain
# and logical assignments; `peek` shows a local index while suspended. t is the element
# type and v0 the value of the first slot (the one written first), chosen per operator so
# that `??=` and `||=` store there: the other slots hold values they keep.
REFERENCE_PLANS = {"+=": ("number", "100"), "=": ("number", "100"),
                   "??=": ("number | undefined", "undefined"), "||=": ("number", "0")}


def reference_defs(n, t, v0):
    arr = f"const o_{n}: ({t})[] = [{v0}, 200, 300];"
    keyfn = (f"const ks_{n} = [\"a\", \"b\"];\nlet ki_{n} = 0;\n"
             f"const key_{n} = (): string => {{ const k = ks_{n}[ki_{n}++]; log(\"key \" + k); return k; }};")
    rec = f"const o_{n}: Record<string, {t}> = {{ a: {v0}, b: 2 }};\n" + keyfn
    dyn = (f"const o_{n}: any = {{ a: {v0}, b: 2 }};\n" if v0 != "undefined"
           else f"const o_{n}: any = JSON.parse('{{\"b\":2}}');\n") + keyfn
    peek = f"let peek_{n}: () => number = () => -1;"
    local_i = f"let i = 0; peek_{n} = (): number => i;"
    show_i = 'log("i " + i);'
    show_peek = f'log("peek " + peek_{n}());'
    return {
        "array[i++]": dict(decl=arr + "\n" + peek, setup=local_i, place=f"o_{n}[i++]", post=show_i, mut=show_peek, values=f"o_{n}.join(\"/\")"),
        "array[i--]": dict(decl=f"const o_{n}: ({t})[] = [200, {v0}, 300];\n" + peek, setup=f"let i = 1; peek_{n} = (): number => i;", place=f"o_{n}[i--]", post=show_i, mut=show_peek, values=f"o_{n}.join(\"/\")"),
        "array[++i]": dict(decl=f"const o_{n}: ({t})[] = [200, {v0}, 300];\n" + peek, setup=local_i, place=f"o_{n}[++i]", post=show_i, mut=show_peek, values=f"o_{n}.join(\"/\")"),
        "array[module i++]": dict(decl=arr + f"\nlet i_{n} = 0;", place=f"o_{n}[i_{n}++]", mut=f'log("i " + i_{n});', values=f"o_{n}.join(\"/\") + \" i \" + i_{n}"),
        "array[idx()]": dict(decl=arr + f"\nconst idx_{n} = (): number => {{ log(\"idx\"); return 0; }};", place=f"o_{n}[idx_{n}()]", mut="", values=f"o_{n}.join(\"/\")"),
        "getArray()[idx()]": dict(decl=arr + f"\nconst get_{n} = (): ({t})[] => {{ log(\"get array\"); return o_{n}; }};\nconst idx_{n} = (): number => {{ log(\"idx\"); return 0; }};", place=f"get_{n}()[idx_{n}()]", mut="", values=f"o_{n}.join(\"/\")"),
        "any array[i++]": dict(decl=f"const o_{n}: any = [{v0}, 200, 300];\n" + peek, setup=local_i, place=f"o_{n}[i++]", post=show_i, mut=show_peek, values=f"o_{n}.join(\"/\")"),
        "typed array[i++]": dict(decl=f"const o_{n} = new Float64Array([{0 if v0 == 'undefined' else v0}, 200, 300]);\n" + peek, setup=local_i, place=f"o_{n}[i++]", post=show_i, mut=show_peek, values=f"o_{n}.join(\"/\")", nonnull=True),
        "record[key()]": dict(decl=rec, place=f"o_{n}[key_{n}()]", mut="", values=f"JSON.stringify(o_{n})"),
        "record[keys[i++]]": dict(decl=rec + "\n" + peek, setup=local_i, place=f"o_{n}[ks_{n}[i++]]", post=show_i, mut=show_peek, values=f"JSON.stringify(o_{n})"),
        "any[key()]": dict(decl=dyn, place=f"o_{n}[key_{n}()]", mut="", values=f"JSON.stringify(o_{n})"),
        "getObject().f": dict(decl=f"class F_{n} {{ f: {t} = {v0}; }}\nconst objs_{n} = [new F_{n}(), new F_{n}()];\nlet ri_{n} = 0;\nconst get_{n} = (): F_{n} => {{ log(\"recv \" + ri_{n}); return objs_{n}[ri_{n}++]; }};", place=f"get_{n}().f", mut=f"objs_{n}[0].f = 2;", values=f"objs_{n}.map((o) => String(o.f)).join(\"/\")"),
        "getAccessor().p": dict(decl=acc_class(n, t, v0) + f"const objs_{n} = [new A_{n}(), new A_{n}()];\nlet ri_{n} = 0;\nconst get_{n} = (): A_{n} => {{ log(\"recv \" + ri_{n}); return objs_{n}[ri_{n}++]; }};", place=f"get_{n}().p", mut=f"objs_{n}[0].v = 2;", values=f"objs_{n}.map((o) => String(o.v)).join(\"/\")"),
        "getAny().p": dict(decl=(f"const objs_{n}: any[] = [{{ p: {v0} }}, {{ p: {v0} }}];" if v0 != "undefined" else f"const objs_{n}: any[] = [JSON.parse(\"{{}}\"), JSON.parse(\"{{}}\")];") + f"\nlet ri_{n} = 0;\nconst get_{n} = (): any => {{ log(\"recv \" + ri_{n}); return objs_{n}[ri_{n}++]; }};", place=f"get_{n}().p", mut=f"objs_{n}[0].p = 2;", values=f"objs_{n}.map((o: any) => String(o.p)).join(\"/\")"),
        "receiver variable swapped": dict(decl=f"class F_{n} {{ f: {t} = {v0}; }}\nlet o_{n} = new F_{n}();\nconst first_{n} = o_{n};", place=f"o_{n}.f", mut=f"o_{n} = new F_{n}();", values=f"String(first_{n}.f) + \"/\" + String(o_{n}.f)"),
        "key variable swapped": dict(decl=f"const o_{n}: Record<string, {t}> = {{ a: {v0}, b: 2 }};\nlet k_{n} = \"a\";", place=f"o_{n}[k_{n}]", mut=f"k_{n} = \"b\";", values=f"JSON.stringify(o_{n})"),
    }


def reference_cases(mode):
    progs = []
    names = list(reference_defs(0, "number", "1").keys())
    for rname in names:
        cases = []
        for op, (t, v0) in REFERENCE_PLANS.items():
            for form in ["direct", "binary"]:
                n = next_n()
                d = reference_defs(n, t, v0)[rname]
                if op == "??=" and d.get("nonnull"):
                    continue
                cases.append(dict(
                    n=n, id=f"{mode}|reference|{rname}|{op}|{form}", desc=f"{rname} {op} {form} ({mode})",
                    decl=d["decl"], setup=d.get("setup", ""), post=d.get("post", ""), mut=d["mut"],
                    body=f"{d['place']} {op} {RHS_FORMS[form]};", values=d["values"],
                    dims=dict(family="reference", mode=mode, target=rname, op=op, form=form)))
        progs.append((f"{mode}_reference_{slug(rname)}", mode, cases))
    return progs


# Group F: operands JS evaluates before a suspension in a later operand of the same
# expression (D-145's settled operands).
def operand_defs(n):
    peek = f"let peek_{n}: () => number = () => -1;"
    v = f"let st_{n} = 1;\nconst v_{n}: any = {{ valueOf(): number {{ log(\"valueOf\"); return st_{n}; }} }};"
    return {
        "postfix i++": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="pair(i++, SUSP)", mut=f'log("peek " + peek_{n}());'),
        "postfix i-- in comma": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="pair((i--, 7), SUSP)", mut=f'log("peek " + peek_{n}());'),
        "void i++": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="upair(void i++, SUSP)", mut=f'log("peek " + peek_{n}());'),
        "prefix ++i": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="pair(++i, SUSP)", mut=f'log("peek " + peek_{n}());'),
        "assignment i = 5": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="pair(i = 5, SUSP)", mut=f'log("peek " + peek_{n}());'),
        "compound i += 5": dict(decl=peek, setup=f"let i = 0; peek_{n} = (): number => i;", expr="pair(i += 5, SUSP)", mut=f'log("peek " + peek_{n}());'),
        "spread argument": dict(decl=f"const xs_{n} = [1, 2];", expr=f"String(sum(...xs_{n}, SUSP))", mut=f"xs_{n}.push(100);"),
        "spread array literal": dict(decl=f"const xs_{n} = [1, 2];", expr=f"[...xs_{n}, SUSP].join(\"/\")", mut=f"xs_{n}.push(100);"),
        "spread object literal": dict(decl=f"const o_{n} = {{ a: 1 }};", expr=f"JSON.stringify({{ ...o_{n}, z: SUSP }})", mut=f"o_{n}.a = 2;"),
        "in operator": dict(decl=f"const o_{n}: Record<string, number> = {{ a: 1 }};", expr=f"bpair(\"b\" in o_{n}, SUSP)", mut=f"o_{n}.b = 2;"),
        "any + 1 (valueOf)": dict(decl=v, expr=f"pair(v_{n} + 1, SUSP)", mut=f"st_{n} = 5;"),
        "any < 3 (valueOf)": dict(decl=v, expr=f"bpair(v_{n} < 3, SUSP)", mut=f"st_{n} = 5;"),
        "any * 2 (valueOf)": dict(decl=v, expr=f"pair(v_{n} * 2, SUSP)", mut=f"st_{n} = 5;"),
        "-any (valueOf)": dict(decl=v, expr=f"pair(-v_{n}, SUSP)", mut=f"st_{n} = 5;"),
        "getter operand": dict(decl=f"let st_{n} = 1;\nconst gt_{n} = {{ get p(): number {{ log(\"get\"); return st_{n}; }} }};", expr=f"pair(gt_{n}.p, SUSP)", mut=f"st_{n} = 5;"),
        "array element operand": dict(decl=f"const xs_{n} = [1, 2];", expr=f"pair(xs_{n}[0], SUSP)", mut=f"xs_{n}[0] = 5;"),
        "array length operand": dict(decl=f"const xs_{n} = [1, 2];", expr=f"pair(xs_{n}.length, SUSP)", mut=f"xs_{n}.push(5);"),
        "captured variable operand": dict(decl=f"let st_{n} = 1;", expr=f"pair(st_{n}, SUSP)", mut=f"st_{n} = 5;"),
        "call operand": dict(decl=f"let st_{n} = 1;\nconst f_{n} = (): number => {{ log(\"f\"); return st_{n}; }};", expr=f"pair(f_{n}(), SUSP)", mut=f"st_{n} = 5;"),
        "template operand": dict(decl=f"let st_{n} = 1;\nconst t_{n} = {{ toString(): string {{ log(\"toString\"); return \"t\" + st_{n}; }} }};", expr=f"`${{t_{n}}}:${{SUSP}}`", mut=f"st_{n} = 5;"),
        "binary of getter": dict(decl=f"let st_{n} = 1;\nconst gt_{n} = {{ get p(): number {{ log(\"get\"); return st_{n}; }} }};", expr=f"String(gt_{n}.p + SUSP)", mut=f"st_{n} = 5;"),
        "method result + susp": dict(decl=f"const xs_{n} = [1, 2];", expr=f"String(xs_{n}.indexOf(2) + SUSP)", mut=f"xs_{n}.unshift(0);"),
        "new with earlier argument": dict(decl=f"let st_{n} = 1;\nclass P_{n} {{ constructor(public a: number, public b: number) {{ log(\"new\"); }} }}\nconst f_{n} = (): number => {{ log(\"f\"); return st_{n}; }};", expr=f"JSON.stringify(new P_{n}(f_{n}(), SUSP))", mut=f"st_{n} = 5;"),
        "new with spread": dict(decl=f"const xs_{n} = [1];\nclass P_{n} {{ xs: number[]; constructor(...xs: number[]) {{ this.xs = xs; }} }}", expr=f"new P_{n}(...xs_{n}, SUSP).xs.join(\"/\")", mut=f"xs_{n}.push(100);"),
    }


def operand_cases(mode):
    progs = []
    names = list(operand_defs(0).keys())
    cases = []
    for oname in names:
        for form in ["direct", "call"]:
            n = next_n()
            d = operand_defs(n)[oname]
            susp = RHS_FORMS[form]
            cases.append(dict(
                n=n, id=f"{mode}|operand|{oname}|{form}", desc=f"{oname} {form} ({mode})",
                decl=d["decl"], setup=d.get("setup", ""), mut=d["mut"],
                body=f"log({d['expr'].replace('SUSP', susp)});", values='""',
                dims=dict(family="operand", mode=mode, target=oname, form=form)))
    # split in programs of 8 cases
    for i in range(0, len(cases), 8):
        progs.append((f"{mode}_operand_{i // 8}", mode, cases[i:i + 8]))
    return progs


# Group G: a compound or logical assignment nested in a larger expression, in a
# conditional's branch, or with two suspensions on its right side.
def nested_cases(mode):
    progs = []
    cases = []
    for tname in ["accessor", "any", "field", "array", "literal accessor", "any accessor"]:
        target = TARGETS[tname]
        shapes = {
            "as call argument": ("number", "log(String(PLACE += SUSP));"),
            "in conditional branch": ("number", "const r = c_N ? (PLACE += SUSP) : 0; log(\"r \" + r);"),
            "two suspensions": ("number", "PLACE += SUSP + SUSP;"),
            "suspension in key and right side": ("number", "PLACE += SUSP;"),  # placeholder replaced below for element targets
            "logical as argument": ("number | undefined", "log(String(PLACE ??= SUSP));"),
            "logical keeps as argument": ("number | undefined", "log(String(PLACE ??= SUSP));"),
            "result times two": ("number", "const r = (PLACE *= SUSP) * 2; log(\"r \" + r);"),
        }
        for sname, (t, body) in shapes.items():
            if sname == "suspension in key and right side":
                continue
            if t not in target["types"]:
                continue
            n = next_n()
            init = "undefined" if sname == "logical as argument" else "1"
            d = target["fn"](n, t, init, "2")
            decl = d["decl"] + f"\nconst c_{n} = true;"
            cases.append(dict(
                n=n, id=f"{mode}|nested|{tname}|{sname}", desc=f"{tname} {sname} ({mode})",
                decl=decl, setup=d.get("setup", ""), post=d.get("post", ""), mut=d["mut"],
                body=body.replace("PLACE", d["place"]).replace("c_N", f"c_{n}"), values=d["values"],
                method=d.get("method", False), cls=d.get("cls", ""), base=d.get("base"),
                dims=dict(family="nested", mode=mode, target=tname, shape=sname)))
    for i in range(0, len(cases), 7):
        progs.append((f"{mode}_nested_{i // 7}", mode, cases[i:i + 7]))
    return progs


def slug(s):
    return "".join(c if c.isalnum() else "_" for c in s).strip("_")


def main():
    out = sys.argv[1]
    os.makedirs(os.path.join(out, "progs"), exist_ok=True)
    manifest = {"programs": {}, "cases": {}}
    for mode in ("yield", "await"):
        for name, m, cases in (compound_cases(mode) + logical_cases(mode) + call_cases(mode) +
                               reference_cases(mode) + operand_cases(mode) + nested_cases(mode)):
            if not cases:
                continue
            base_name, k = name, 2
            while name in manifest["programs"]:  # slugs can collide: array[i++], array[i--]
                name, k = f"{base_name}_{k}", k + 1
            manifest["programs"][name] = dict(mode=m, cases=[c["id"] for c in cases])
            for c in cases:
                manifest["cases"][c["id"]] = dict(program=name, n=c["n"], desc=c["desc"], dims=c["dims"],
                                                  source=case_text(m, c, False))
            with open(os.path.join(out, "progs", name + ".pts"), "w") as f:
                f.write(program_text(m, cases))
            # per-case sources (suspending and control), for the runner's fallbacks
            os.makedirs(os.path.join(out, "single"), exist_ok=True)
            for c in cases:
                base = os.path.join(out, "single", f"c{c['n']}")
                with open(base + ".pts", "w") as f:
                    f.write(program_text(m, [c]))
                with open(base + "_control.pts", "w") as f:
                    f.write(program_text(m, [c], control=True))
    with open(os.path.join(out, "manifest.json"), "w") as f:
        json.dump(manifest, f, indent=1)
    print(len(manifest["programs"]), "programs,", len(manifest["cases"]), "cases")


if __name__ == "__main__":
    main()
