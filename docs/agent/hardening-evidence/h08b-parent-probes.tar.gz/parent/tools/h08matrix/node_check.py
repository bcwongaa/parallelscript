#!/usr/bin/env python3
"""Runs every generated program under Node and reports programs that fail or cases without
a line (a generator bug). Usage: python3 -I node_check.py MATRIXDIR"""
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys

NODE = os.path.expanduser("~/.local/node/bin/node")
matrix = sys.argv[1]
manifest = json.load(open(os.path.join(matrix, "manifest.json")))
work = os.path.join(matrix, "nodecheck")
os.makedirs(work, exist_ok=True)


def check(item):
    name, info = item
    mts = os.path.join(work, name + ".mts")
    shutil.copyfile(os.path.join(matrix, "progs", name + ".pts"), mts)
    p = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", mts], capture_output=True, text=True, timeout=60)
    got = set(re.findall(r"^\{\{(.*?)\}\}", p.stdout, re.M))
    missing = [c for c in info["cases"] if c not in got]
    return name, p.returncode, missing, p.stderr[-500:]


bad = 0
with concurrent.futures.ThreadPoolExecutor(4) as pool:
    for name, code, missing, err in pool.map(check, manifest["programs"].items()):
        if code != 0 or missing:
            bad += 1
            print(name, code, missing[:3], err)
print("programs with problems:", bad, "of", len(manifest["programs"]))
