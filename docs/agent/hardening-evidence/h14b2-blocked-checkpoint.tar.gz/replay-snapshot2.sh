#!/usr/bin/env bash
set -eu
root=/home/bryan/projects/parallelscript/pts-bin/h14b2-parent-replay
probes="$root/review-probes"
export GOMAXPROCS=1 PTS_HOME=/home/bryan/projects/parallelscript
run_case() {
  name=$1 expected=$2; shift 2
  set +e
  "$@" > "$probes/snapshot2-$name.stdout" 2> "$probes/snapshot2-$name.stderr"
  result=$?
  set -e
  printf '%s\n' "$result" > "$probes/snapshot2-$name.exit"
  printf '%s actual_exit=%s expected_exit=%s\n' "$name" "$result" "$expected"
  test "$result" -eq "$expected"
}
for profile in release sanitize; do
  go -C /home/bryan/projects/parallelscript run "$probes/compile.go" c "$probes/request_timer_probe.c" "$probes/snapshot2-timer-$profile.bin" "$profile"
  run_case "timer-$profile-minimum" 0 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/snapshot2-timer-$profile.bin" minimum
  run_case "timer-$profile-late-continue" 0 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/snapshot2-timer-$profile.bin" late-continue
  # Historical fabricated state remains RED; legal sequence is tested in request_timer.c.
  run_case "timer-$profile-fabricated-queue" 1 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/snapshot2-timer-$profile.bin" queued-continue
done
go -C /home/bryan/projects/parallelscript run "$probes/compile.go" pts "$probes/probe_server.pts" "$probes/snapshot2-server.bin" release
run_case network-phase 0 python3 -I "$probes/network_probe.py" "$probes/snapshot2-server.bin" phase
# The frozen oracle intentionally asserts the now-proven-invalid lower bound.
run_case historical-network-oracle 1 python3 -I "$probes/network_probe.py" "$probes/snapshot2-server.bin" oracle
run_case network-late-observations 0 python3 -I "$probes/network_probe.py" "$probes/snapshot2-server.bin" late
