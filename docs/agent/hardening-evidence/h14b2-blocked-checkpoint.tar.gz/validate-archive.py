import hashlib
import json
import pathlib
import re
import sys
import tarfile

src = pathlib.Path(sys.argv[1])
private_key = re.compile(rb'(?m)^-----BEGIN [^-\r\n]*PRIVATE KEY-----')
items = []
with tarfile.open(src, 'r:gz') as archive:
    for member in archive:
        path = pathlib.PurePosixPath(member.name)
        if not member.isfile() or path.is_absolute() or '..' in path.parts:
            raise SystemExit('unsafe member: ' + member.name)
        data = archive.extractfile(member).read()
        text = data.decode('utf-8')
        if '\x00' in text or private_key.search(data):
            raise SystemExit('unsafe content: ' + member.name)
        items.append({'path': member.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
result = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'members': items}
if len(sys.argv) > 2:
    pathlib.Path(sys.argv[2]).write_text(json.dumps(result, indent=2) + '\n')
print('validated', len(items), 'regular UTF-8 files; archive sha256', result['sha256'])
