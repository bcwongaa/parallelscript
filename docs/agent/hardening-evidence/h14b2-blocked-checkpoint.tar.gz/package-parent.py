import hashlib
import json
import pathlib
import re
import sys
import tarfile

source = pathlib.Path(sys.argv[1]).resolve()
destination = pathlib.Path(sys.argv[2]).resolve()
if destination.exists():
    raise SystemExit('refusing to overwrite an existing evidence archive')
private_key = re.compile(rb'(?m)^-----BEGIN [^-\r\n]*PRIVATE KEY-----')
files = sorted(path for path in source.rglob('*') if path.is_file())
for path in files:
    if path.is_symlink():
        raise SystemExit('symlink in parent evidence: ' + str(path))
    data = path.read_bytes()
    text = data.decode('utf-8')
    if '\x00' in text or private_key.search(data):
        raise SystemExit('binary/private-key material in parent evidence: ' + str(path))
with tarfile.open(destination, 'w:gz') as archive:
    for path in files:
        archive.add(path, arcname=str(path.relative_to(source)), recursive=False)
items = []
with tarfile.open(destination, 'r:gz') as archive:
    for member in archive:
        path = pathlib.PurePosixPath(member.name)
        if not member.isfile() or path.is_absolute() or '..' in path.parts:
            raise SystemExit('unsafe archive path: ' + member.name)
        data = archive.extractfile(member).read()
        data.decode('utf-8')
        if private_key.search(data) or b'\x00' in data:
            raise SystemExit('unsafe archive contents: ' + member.name)
        items.append({'path': member.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
result = {'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(), 'members': items}
with pathlib.Path(str(destination) + '.json').open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'sha256': result['sha256'], 'regular_utf8_members': len(items), 'compressed_bytes': destination.stat().st_size}, indent=2))
