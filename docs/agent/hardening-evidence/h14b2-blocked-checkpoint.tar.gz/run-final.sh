#!/usr/bin/env bash
set -u -o pipefail
root=/home/bryan/projects/parallelscript
out=/tmp/pts-h14b2-parent-20261027
cd "$root" || exit 2
printf '%s\n' 'GOMAXPROCS=4 make build' > "$out/final-command.txt"
printf '%s\n' 'GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/' >> "$out/final-command.txt"
git rev-parse HEAD > "$out/final-head.txt"
git status --short > "$out/final-status.txt"
GOMAXPROCS=4 make build > "$out/final-build.stdout" 2> "$out/final-build.stderr"
result=$?
printf '%s\n' "$result" > "$out/final-build-exit.txt"
if test "$result" -ne 0; then
  printf '%s\n' "$result" > "$out/final-exit.txt"
  exit "$result"
fi
python3 -I "$out/manifest.py" "$root" "$out/final-before-manifest.json" > "$out/final-before-manifest.stdout" || exit 2
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/ > "$out/final-suite.jsonl" 2> "$out/final-suite.stderr"
result=$?
printf '%s\n' "$result" > "$out/final-suite-exit.txt"
python3 -I "$out/manifest.py" "$root" "$out/final-after-manifest.json" "$out/final-before-manifest.json" > "$out/final-manifest-comparison.stdout"
manifest_result=$?
python3 -I "$out/summarize.py" "$out" final-suite > "$out/final-suite-summary.stdout"
summary_result=$?
if test "$manifest_result" -ne 0 || test "$summary_result" -ne 0; then result=2; fi
printf '%s\n' "$result" > "$out/final-exit.txt"
exit "$result"
