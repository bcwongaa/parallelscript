#!/usr/bin/env bash
# Extract the archive at a snapshot worktree root, then pass that root here.
# No production files are changed. Only review-probes/replay-* artifacts are written.
set -eu
root=${1:?usage: replay.sh /absolute/path/to/snapshot-worktree}
probes="$root/review-probes"
export GOMAXPROCS=1 PTS_HOME="$root"

run_case() {
  name=$1
  expected=$2
  shift 2
  set +e
  "$@" > "$probes/replay-$name.stdout" 2> "$probes/replay-$name.stderr"
  result=$?
  set -e
  printf '%s\n' "$result" > "$probes/replay-$name.exit"
  printf '%s actual_exit=%s snapshot1_expected_exit=%s\n' "$name" "$result" "$expected"
  if test "$result" -ne "$expected"; then
    return 1
  fi
}

for profile in release sanitize; do
  go -C "$root" run "$probes/compile.go" c "$probes/request_timer_probe.c" "$probes/replay-timer-$profile.bin" "$profile"
  run_case "timer-$profile-minimum" 0 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/replay-timer-$profile.bin" minimum
  run_case "timer-$profile-late-continue" 1 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/replay-timer-$profile.bin" late-continue
  # This is a controlled queue-state reproduction, not a real-network reachability claim.
  run_case "timer-$profile-queued-continue" 1 env ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0 UBSAN_OPTIONS=halt_on_error=1 "$probes/replay-timer-$profile.bin" queued-continue
done

go -C "$root" run "$probes/compile.go" pts "$probes/probe_server.pts" "$probes/replay-server.bin" release
run_case network-phase 0 python3 -I "$probes/network_probe.py" "$probes/replay-server.bin" phase
run_case network-oracle 1 python3 -I "$probes/network_probe.py" "$probes/replay-server.bin" oracle
run_case network-late 0 python3 -I "$probes/network_probe.py" "$probes/replay-server.bin" late
