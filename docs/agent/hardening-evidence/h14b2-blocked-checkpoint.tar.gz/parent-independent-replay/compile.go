package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 5 {
		panic("usage: compile <c|pts> <source> <output> <release|sanitize>")
	}
	ctx := context.Background()
	profile := toolchain.Release
	if os.Args[4] == "sanitize" {
		profile = toolchain.Sanitize
	} else if os.Args[4] != "release" {
		panic("unknown profile")
	}
	var err error
	if os.Args[1] == "pts" {
		if err = os.Setenv("PTS_BUILD_PROFILE", profile.String()); err == nil {
			err = driver.Build(ctx, os.Args[2], os.Args[3])
		}
	} else if os.Args[1] == "c" {
		var tc *toolchain.Toolchain
		var rt *toolchain.Runtime
		if tc, err = toolchain.New(); err == nil {
			if rt, err = tc.Runtime(ctx, profile); err == nil {
				err = tc.CompileProgram(ctx, rt, []string{os.Args[2]}, os.Args[3])
			}
		}
	} else {
		panic("unknown input kind")
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Printf("compiled %s (%s)\n", os.Args[2], profile)
}
