import argparse
import contextlib
import http.client
import json
import os
import selectors
import signal
import socket
import subprocess
import sys
import time


@contextlib.contextmanager
def server(binary, threads, budget_ms):
    env = dict(os.environ, PTS_THREADS=str(threads), REVIEW_REQUEST_MS=str(budget_ms), REVIEW_HEADERS_MS="0")
    process = subprocess.Popen([binary], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, start_new_session=True)
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(process.stdout, selectors.EVENT_READ)
            if not selector.select(15):
                raise AssertionError("server startup timed out")
        line = process.stdout.readline().strip()
        if not line.startswith("listening "):
            raise AssertionError(f"unexpected startup {line!r}")
        yield int(line.split()[1])
    finally:
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
        try:
            _, stderr = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            _, stderr = process.communicate(timeout=5)
        if stderr:
            print(json.dumps({"server_stderr": stderr}), flush=True)


def count(port):
    client = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
    try:
        client.request("GET", "/count", headers={"Connection": "close"})
        response = client.getresponse()
        assert response.status == 200
        return int(response.read())
    finally:
        client.close()


def closed_read(conn):
    pieces = []
    error = None
    try:
        while True:
            piece = conn.recv(65536)
            if not piece:
                break
            pieces.append(piece)
    except ConnectionResetError:
        error = "reset"
    except socket.timeout:
        error = "timeout"
    return b"".join(pieces), error


def phase_controls(binary):
    for threads in (1, 4):
        with server(binary, threads, 450) as port:
            for name, prefix, suffix in (
                ("whole_cl", b"POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: 3\r\n", b"\r\na"),
                ("whole_chunked", b"POST /echo HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n", b"\r\n3\r\na"),
            ):
                before = count(port)
                with socket.create_connection(("127.0.0.1", port), timeout=2) as conn:
                    started = time.monotonic()
                    conn.sendall(prefix)
                    time.sleep(0.30)
                    conn.sendall(suffix)
                    wire, error = closed_read(conn)
                    elapsed = time.monotonic() - started
                after = count(port)
                result = dict(case=name, threads=threads, elapsed=elapsed, wire=wire.decode("latin1"),
                              terminal=error or "eof", calls_before=before, calls_after=after)
                print(json.dumps(result), flush=True)
                assert error != "timeout" and not wire and 0.30 <= elapsed < 0.70 and before == after

            for name, prefix, progress in (
                ("absolute_cl", b"POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: 100\r\n\r\na", b"a"),
                ("absolute_chunked", b"POST /echo HTTP/1.1\r\nHost: x\r\nTransfer-Encoding: chunked\r\n\r\n", b"1\r\na\r\n"),
            ):
                before = count(port)
                with socket.create_connection(("127.0.0.1", port), timeout=2) as conn:
                    conn.settimeout(0.025)
                    started = time.monotonic()
                    conn.sendall(prefix)
                    next_progress = started + 0.06
                    wire = b""
                    terminal = "timeout"
                    while time.monotonic() - started < 1.2:
                        now = time.monotonic()
                        if now >= next_progress:
                            try:
                                conn.sendall(progress)
                            except (BrokenPipeError, ConnectionResetError):
                                pass
                            next_progress = now + 0.06
                        try:
                            piece = conn.recv(65536)
                            if not piece:
                                terminal = "eof"
                                break
                            wire += piece
                        except ConnectionResetError:
                            terminal = "reset"
                            break
                        except socket.timeout:
                            pass
                    elapsed = time.monotonic() - started
                after = count(port)
                print(json.dumps(dict(case=name, threads=threads, elapsed=elapsed,
                                      wire=wire.decode("latin1"), terminal=terminal,
                                      calls_before=before, calls_after=after)), flush=True)
                assert terminal != "timeout" and not wire and 0.30 <= elapsed < 0.70 and before == after

            client = http.client.HTTPConnection("127.0.0.1", port, timeout=3)
            try:
                client.request("POST", "/slow", body="complete")
                response = client.getresponse()
                body = response.read().decode()
                print(json.dumps(dict(case="handler_excluded", threads=threads, status=response.status, body=body)), flush=True)
                assert response.status == 200 and body == "slow:false"
            finally:
                client.close()


def read_head(reader):
    status = reader.readline()
    assert status.startswith(b"HTTP/1.1 200"), status
    headers = {}
    while True:
        line = reader.readline()
        if line == b"\r\n":
            return headers
        assert line, "EOF within response headers"
        key, value = line.split(b":", 1)
        headers[key.lower()] = value.strip()


def client_read_oracle(binary):
    with server(binary, 1, 600) as port:
        before = count(port)
        with socket.create_connection(("127.0.0.1", port), timeout=3) as conn:
            conn.sendall(b"GET /large HTTP/1.1\r\nHost: x\r\n\r\n"
                         b"POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: 2\r\n\r\na")
            time.sleep(1.20)
            reader = conn.makefile("rb")
            headers = read_head(reader)
            length = int(headers[b"content-length"])
            body = reader.read(length - 1)
            assert len(body) == length - 1 and body == b"r" * (length - 1)
            # Delay inside completion of the client's body read, after the server can drain its output.
            # This models descheduling/decryption time within readResourceLargeResponse, not extra server work.
            time.sleep(0.90)
            body += reader.read(1)
            assert len(body) == 4 * 1024 * 1024 and body[-1:] == b"r"
            started = time.monotonic()
            tail = reader.read()
            elapsed = time.monotonic() - started
            reader.close()
        after = count(port)
        print(json.dumps(dict(case="queued_output_client_read_oracle", full_body_bytes=len(body), tail=tail.decode("latin1"),
                              post_body_read_elapsed=elapsed, existing_test_minimum=0.300,
                              calls_before=before, calls_after=after,
                              correct_closure_rejected_by_existing_lower_bound=elapsed < 0.300)), flush=True)
        assert not tail and after == before + 1
        assert elapsed >= 0.300, "snapshot1 checkRequestClosure rejects valid expiry because it times from client read completion"


def late_continue(binary):
    observations = []
    with server(binary, 1, 1) as port:
        before = count(port)
        for fields in (500, 1000, 2000, 4000, 6000, 8000):
            wire = (b"POST /echo HTTP/1.1\r\nHost: x\r\nContent-Length: 2\r\nExpect: 100-continue\r\n"
                    + b"X: a\r\n" * fields + b"\r\na")
            assert len(wire) < 64 * 1024
            for repeat in range(8):
                with socket.create_connection(("127.0.0.1", port), timeout=2) as conn:
                    started = time.monotonic()
                    conn.sendall(wire)
                    output, error = closed_read(conn)
                    elapsed = time.monotonic() - started
                item = dict(case="large_valid_head_expect_continue", fields=fields, repeat=repeat,
                            elapsed=elapsed, bytes=len(output), wire=output.decode("latin1"), terminal=error or "eof")
                observations.append(item)
                print(json.dumps(item), flush=True)
        after = count(port)
    print(json.dumps(dict(case="late_continue_summary", observations=len(observations),
                          continue_responses=sum(b"100 Continue" in o["wire"].encode() for o in observations),
                          continue_over_1ms=sum("100 Continue" in o["wire"] and o["elapsed"] > .001 for o in observations),
                          calls_before=before, calls_after=after,
                          note="network elapsed alone does not prove server send timestamp")), flush=True)
    assert after == before


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("binary")
    parser.add_argument("mode", choices=("phase", "oracle", "late"))
    args = parser.parse_args()
    if args.mode == "phase":
        phase_controls(args.binary)
    elif args.mode == "oracle":
        client_read_oracle(args.binary)
    else:
        late_continue(args.binary)


if __name__ == "__main__":
    main()
