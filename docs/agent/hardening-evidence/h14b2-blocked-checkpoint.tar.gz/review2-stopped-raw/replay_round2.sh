#!/usr/bin/env bash
# Extract the evidence archive at a snapshot2 worktree root and pass that root.
# Only review-probes/round2 outputs and binaries are written.
set -eu
root=${1:?usage: replay_round2.sh /absolute/path/to/snapshot2-worktree}
probes="$root/review-probes"
out="$probes/round2"
mkdir -p "$out"
export GOMAXPROCS=1 PTS_HOME="$root"
export ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0
export UBSAN_OPTIONS=halt_on_error=1

run_case() {
  name=$1
  expected=$2
  shift 2
  set +e
  "$@" > "$out/$name.stdout" 2> "$out/$name.stderr"
  result=$?
  set -e
  printf '%s\n' "$result" > "$out/$name.exit"
  printf '%s actual_exit=%s expected_exit=%s\n' "$name" "$result" "$expected"
  if test "$result" -ne "$expected"; then
    return 1
  fi
}

for profile in release sanitize; do
  go -C "$root" run "$probes/compile.go" c "$probes/request_timer_probe.c" "$out/timer-$profile.bin" "$profile" > "$out/build-timer-$profile.stdout" 2> "$out/build-timer-$profile.stderr"
  run_case "timer-$profile-minimum" 0 "$out/timer-$profile.bin" minimum
  run_case "timer-$profile-late-continue" 0 "$out/timer-$profile.bin" late-continue
  # This fabricated state is now prevented by the legal production sequence.
  run_case "historical-timer-$profile-queued-continue" 1 "$out/timer-$profile.bin" queued-continue

  for kind in cl chunked size_error; do
    go -C "$root" run "$probes/compile.go" c "$probes/after_parse_${kind}_probe.c" "$out/after-parse-$kind-$profile.bin" "$profile" > "$out/build-after-parse-$kind-$profile.stdout" 2> "$out/build-after-parse-$kind-$profile.stderr"
    run_case "after-parse-$kind-$profile" 0 "$out/after-parse-$kind-$profile.bin" late-continue
  done

  go -C "$root" run "$probes/compile.go" c "$probes/legal_queue_chunked_probe.c" "$out/legal-queue-chunked-$profile.bin" "$profile" > "$out/build-legal-queue-chunked-$profile.stdout" 2> "$out/build-legal-queue-chunked-$profile.stderr"
  run_case "legal-queue-chunked-$profile" 0 "$out/legal-queue-chunked-$profile.bin" queued
  run_case "retained-chunked-$profile" 0 "$out/legal-queue-chunked-$profile.bin" retained

  go -C "$root" run "$probes/compile.go" pts "$probes/probe_server.pts" "$out/probe-server-$profile.bin" "$profile" > "$out/build-server-$profile.stdout" 2> "$out/build-server-$profile.stderr"
  run_case "network-phase-$profile" 0 python3 -I "$probes/network_probe.py" "$out/probe-server-$profile.bin" phase
  # Deliberately reruns snapshot1's now-removed invalid lower-bound assertion.
  run_case "historical-client-read-oracle-$profile" 1 python3 -I "$probes/network_probe.py" "$out/probe-server-$profile.bin" oracle
  # Network elapsed alone remains observational, not a server-send timestamp proof.
  run_case "observational-network-late-$profile" 0 python3 -I "$probes/network_probe.py" "$out/probe-server-$profile.bin" late
done
