/* Keep request clock and write-queue boundaries deterministic; include the real server. */
#include "pts.h"
#include <uv.h>

static uint64_t clock_now(void);
static size_t queued_now(const uv_stream_t *stream);
static int record_write(uv_write_t *req, uv_stream_t *stream, const uv_buf_t bufs[], unsigned count, uv_write_cb callback);
#define uv_hrtime clock_now
#define uv_stream_get_write_queue_size queued_now
#define uv_write record_write
#include "../pts/runtime/src/http.c"
#undef uv_hrtime
#undef uv_stream_get_write_queue_size
#undef uv_write

static uint64_t now = UINT64_C(1000000000);
static uint64_t jump_to;
static unsigned clock_reads, writes;
static size_t queued_bytes;
static uv_write_t *pending_write;

static uint64_t clock_now(void) {
  if (++clock_reads >= 2 && jump_to != 0) now = jump_to;
  return now;
}

static size_t queued_now(const uv_stream_t *stream) {
  (void)stream;
  return queued_bytes;
}

static int record_write(uv_write_t *req, uv_stream_t *stream, const uv_buf_t bufs[], unsigned count, uv_write_cb callback) {
  (void)stream;
  (void)bufs;
  (void)count;
  (void)callback;
  writes++;
  pending_write = req;
  return 0;
}

static void require(bool condition, const char *message) {
  if (!condition) {
    fprintf(stderr, "request timer assertion: %s\n", message);
    exit(1);
  }
}

static connection *make_connection(listener *l, bool chunked) {
  const char *input = chunked
      ? "POST / HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\nExpect: 100-continue\r\n\r\n2\r\na"
      : "POST / HTTP/1.1\r\nHost: loopback\r\nContent-Length: 2\r\nExpect: 100-continue\r\n\r\na";
  connection *c = checked(calloc(1, sizeof *c));
  require(uv_tcp_init(pts_uv_loop(), &c->tcp) == 0, "TCP init");
  c->listener = l;
  c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
  c->roots->request = PTS_VALUE_ABSENT;
  c->headers_pending = true;
  c->in_len = strlen(input);
  c->in_cap = c->in_len + 1;
  c->in = checked(malloc(c->in_cap));
  memcpy(c->in, input, c->in_cap);
  add_to_table(c);
  l->connections = c;
  return c;
}

int main(int argc, char **argv) {
  require(argc == 2, "select retained, late-cl, late-chunked, or queued");
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  server s = {.headers_timeout = 600, .request_timeout = 1000};
  listener l = {.server = &s};
  connection *c = make_connection(&l, true);
  if (strcmp(argv[1], "retained") == 0) {
    start_request_deadlines(c);
    require(c->deadline_at == UINT64_C(1600000000), "earlier headers did not win");
    require(c->request_deadline_at == UINT64_C(2000000000), "whole-request origin moved");
    now += UINT64_C(200000000);
    process(c);
    require(!c->headers_pending && c->continued, "complete headers did not reach body phase");
    require(c->deadline_at == UINT64_C(2000000000), "header completion refreshed the request budget");
    uv_timer_stop(c->deadline);
    on_deadline(c->deadline);
    require(!c->closing && c->deadline_at == UINT64_C(2000000000), "early callback closed or moved budget");
    require(uv_timer_get_due_in(c->deadline) > 0 && uv_timer_get_due_in(c->deadline) <= 800, "invalid rounded remainder");
  } else if (strcmp(argv[1], "late-cl") == 0 || strcmp(argv[1], "late-chunked") == 0) {
    s.headers_timeout = 0;
    s.request_timeout = 1;
    start_request_deadlines(c);
    clock_reads = 0;
    jump_to = c->request_deadline_at + 1;
    process(c);
    printf("late request: closed=%d continued=%d writes=%u\n", c->closing, c->continued, writes);
    require(c->closing && !c->continued && writes == 0, "expired request emitted interim output");
  } else if (strcmp(argv[1], "queued") == 0) {
    queued_bytes = 100; /* preceding final response has not drained */
    process(c);
    require(!c->headers_pending && !c->continued && writes == 0, "interim output overtook preceding final drain");
    require(c->deadline_at == 0 && c->request_deadline_at == 0, "preceding output consumed follower's budget");
    now += UINT64_C(2000000000);
    queued_bytes = 0;
    write_request *w = checked(calloc(1, sizeof *w));
    w->connection = c;
    w->bytes = checked(malloc(1));
    on_written(&w->req, 0);
    require(c->continued && writes == 1, "drained output did not resume pending 100 Continue");
    require(c->deadline_at == UINT64_C(4000000000) && c->request_deadline_at == c->deadline_at,
            "drained output did not start a fresh whole body budget");
    queued_bytes = 25; /* this request's interim output must not stop its clock */
    now += UINT64_C(1000000000);
    uv_timer_stop(c->deadline);
    on_deadline(c->deadline);
    require(c->closing && writes == 1, "own interim output postponed request expiry");
  } else {
    require(false, "unknown mode");
  }
  if (pending_write != NULL) {
    write_request *w = (write_request *)pending_write;
    free(w->bytes);
    free(w);
  }
  if (!c->closing) close_connection(c);
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  puts("request deadline clock/queue controls passed");
  return 0;
}
