/* Round2: cross expiry on the fourth clock read, specifically after header parsing.
 * Deterministic request-clock probes. Production source is included unchanged.
 * The clock and write/queue boundaries are controlled to expose exact phase states. */
#include "pts.h"
#include <uv.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint64_t probe_clock(void);
static size_t probe_queued(const uv_stream_t *stream);
static int probe_write(uv_write_t *req, uv_stream_t *stream,
                       const uv_buf_t bufs[], unsigned count, uv_write_cb callback);
#define uv_hrtime probe_clock
#define uv_stream_get_write_queue_size probe_queued
#define uv_write probe_write
#include "../pts/runtime/src/http.c"
#undef uv_hrtime
#undef uv_stream_get_write_queue_size
#undef uv_write

static uint64_t clock_ns = UINT64_C(1000000000);
static uint64_t jump_to;
static unsigned clock_reads;
static size_t queued_bytes;
static unsigned write_count;
static uv_write_t *pending_write;
static char written[128];

static uint64_t probe_clock(void) {
  clock_reads++;
  if (jump_to != 0 && clock_reads >= 4) clock_ns = jump_to;
  return clock_ns;
}

static size_t probe_queued(const uv_stream_t *stream) {
  (void)stream;
  return queued_bytes;
}

static int probe_write(uv_write_t *req, uv_stream_t *stream,
                       const uv_buf_t bufs[], unsigned count, uv_write_cb callback) {
  (void)stream;
  (void)callback;
  write_count++;
  pending_write = req;
  size_t used = 0;
  for (unsigned i = 0; i < count && used < sizeof written - 1; i++) {
    size_t n = bufs[i].len;
    if (n > sizeof written - 1 - used) n = sizeof written - 1 - used;
    memcpy(written + used, bufs[i].base, n);
    used += n;
  }
  written[used] = 0;
  return 0;
}

static void require(bool condition, const char *message) {
  if (!condition) {
    fprintf(stderr, "probe assertion: %s\n", message);
    exit(2);
  }
}

static connection *make_connection(listener *l, const char *input) {
  connection *c = checked(calloc(1, sizeof *c));
  require(uv_tcp_init(pts_uv_loop(), &c->tcp) == 0, "tcp init");
  c->listener = l;
  c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
  c->roots->request = PTS_VALUE_ABSENT;
  c->headers_pending = true;
  c->in_len = strlen(input);
  c->in_cap = c->in_len + 1;
  c->in = checked(malloc(c->in_cap));
  memcpy(c->in, input, c->in_cap);
  add_to_table(c);
  l->connections = c;
  return c;
}

int main(int argc, char **argv) {
  require(argc == 2, "select minimum, late-continue, or queued-continue");
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  server s = {.headers_timeout = 600, .request_timeout = 1000};
  listener l = {.server = &s};
  const char *partial = "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\nExpect: 100-continue\r\n\r\n2\r\na";
  connection *c = make_connection(&l, partial);
  int status = 0;
  if (strcmp(argv[1], "minimum") == 0) {
    start_request_deadlines(c);
    require(c->deadline_at == UINT64_C(1600000000), "headers not earliest");
    require(c->request_deadline_at == UINT64_C(2000000000), "request timestamp wrong");
    clock_ns += UINT64_C(200000000);
    c->headers_pending = false;
    set_deadline(c, c->request_deadline_at);
    require(c->deadline_at == UINT64_C(2000000000), "header completion reset request budget");
    uv_timer_stop(c->deadline);
    on_deadline(c->deadline);
    require(!c->closing && c->deadline_at == UINT64_C(2000000000), "early callback moved/closed");
    require(uv_timer_get_due_in(c->deadline) <= 800, "early remainder exceeds original budget");
    stop_deadline(c);
    c->request_deadline_at = 0;
    clock_ns += UINT64_C(1500000000);
    next_request_deadline(c);
    require(c->request_deadline_at == UINT64_C(3700000000), "next request did not get fresh budget");
    require(c->deadline_at == c->request_deadline_at, "body-only next request has header clock");
    puts("minimum, retained timestamp, early callback, and body-only follower controls passed");
  } else if (strcmp(argv[1], "late-continue") == 0) {
    s.headers_timeout = 0;
    s.request_timeout = 1;
    start_request_deadlines(c);
    clock_reads = 0;
    jump_to = c->request_deadline_at + 1;
    process(c);
    printf("late-continue clock=%llu deadline=%llu closed=%d continued=%d writes=%u output=%s\n",
           (unsigned long long)clock_ns, (unsigned long long)c->request_deadline_at,
           c->closing, c->continued, write_count, written);
    require(clock_ns > c->request_deadline_at, "clock did not cross request deadline");
    status = !c->closing || write_count != 0;
    if (status) fprintf(stderr, "VIOLATION: an expired incomplete request emitted 100 Continue instead of closing\n");
  } else if (strcmp(argv[1], "queued-continue") == 0) {
    c->headers_pending = false;
    c->continued = true;
    queued_bytes = 25; /* only this request's 100 Continue remains; preceding final output has drained */
    write_request *w = checked(calloc(1, sizeof *w));
    w->connection = c;
    w->bytes = checked(malloc(1));
    on_written(&w->req, 0); /* completion of preceding final response */
    printf("queued-continue preceding-final-completed own-queued=%zu request-deadline=%llu timer=%llu\n",
           queued_bytes, (unsigned long long)c->request_deadline_at,
           (unsigned long long)c->deadline_at);
    status = c->request_deadline_at == 0;
    if (status) fprintf(stderr, "VIOLATION: current-request interim output postponed its whole-request clock\n");
    queued_bytes = 0;
    next_request_deadline(c);
    require(c->request_deadline_at != 0, "queue-zero positive control failed");
  } else {
    require(false, "unknown mode");
  }
  if (pending_write != NULL) {
    write_request *w = (write_request *)pending_write;
    free(w->bytes);
    free(w);
  }
  if (!c->closing) close_connection(c);
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  return status;
}
