import collections
import json
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
name = sys.argv[2]
events = [json.loads(line) for line in (root / (name + '.jsonl')).read_text().splitlines() if line.strip()]
completed = [event for event in events if event.get('Test') and event['Action'] in ('pass', 'fail', 'skip')]
names = {event['Test'] for event in completed}
leaves = [event for event in completed if not any(other.startswith(event['Test'] + '/') for other in names)]
corpus = [event for event in completed if event['Test'].startswith('TestCorpusMatchesNode/')]
result = {
    'events': dict(collections.Counter(event['Action'] for event in completed)),
    'leaves': dict(collections.Counter(event['Action'] for event in leaves)),
    'packages': {event['Package']: event['Action'] for event in events if not event.get('Test') and event['Action'] in ('pass', 'fail', 'skip')},
    'corpus_events': dict(collections.Counter(event['Action'] for event in corpus)),
    'failures': [event for event in events if event['Action'] == 'fail'],
    'stderr_bytes': (root / (name + '.stderr')).stat().st_size,
}
(root / (name + '-summary.json')).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
