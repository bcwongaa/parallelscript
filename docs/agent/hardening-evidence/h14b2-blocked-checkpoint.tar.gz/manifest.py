import hashlib
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(sys.argv[1]).resolve()
out = pathlib.Path(sys.argv[2])
paths = subprocess.check_output(['git', '-C', str(root), 'ls-files', '-z', '--', 'pts', 'cmd', 'internal']).decode().split('\0')
paths += ['pts/tests/http_request_deadlines_test.go', 'pts/tests/http/request_deadlines.pts', 'pts/tests/http_request_timer_test.go', 'pts/tests/testdata/http_deadlines/request_timer.c', 'README.md', 'docs/SPEC.md', 'docs/GUIDE.md', 'docs/ARCHITECTURE.md', 'Makefile', 'go.mod', 'go.sum', '.gitignore', 'pts-bin/pts']
manifest = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in sorted(set(paths)) if name and (root / name).is_file()}
out.write_text(json.dumps(manifest, sort_keys=True, indent=2) + '\n')
print('hashed', len(manifest), 'source/test/CLI/public-policy files')
if len(sys.argv) > 3:
    before = json.loads(pathlib.Path(sys.argv[3]).read_text())
    changed = {name: {'before': before.get(name), 'after': manifest.get(name)} for name in before.keys() | manifest.keys() if before.get(name) != manifest.get(name)}
    print(json.dumps({'unchanged': not changed, 'changed': changed}, indent=2))
    if changed:
        raise SystemExit(1)
