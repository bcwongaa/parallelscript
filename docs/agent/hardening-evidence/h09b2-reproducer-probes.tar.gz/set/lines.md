| program | head | protoA | protoB | protoAB | protoAB2 | liftHead | liftA | liftAB | liftAB2 |
|---|---|---|---|---|---|---|---|---|---|
| erased_objects_typed_reads | MISREAD (16/17 lines) | OK | TYPEERR (1/17 lines) | OK | OK | MISREAD (16/17 lines) | OK | OK | OK |
| erased_objects_union_routes | MISREAD (8/8 lines) | MISREAD (1/8 lines) | MISREAD (1/8 lines) | OK | OK | MISREAD (8/8 lines) | MISREAD (1/8 lines) | OK | OK |
| generic_method_object_arguments | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) |
| om2 | OK | OK | OK | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| om3 | MISREAD (2/2 lines) | OK | OK | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| q01_assertion_any_field | MISREAD (1/2 lines) | OK | MISREAD (1/2 lines) | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| q02_nested_union_implies | MISREAD (2/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | MISREAD (2/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) |
| q03_class_field_and_callbacks | MISREAD (4/4 lines) | OK | OK | OK | OK | MISREAD (4/4 lines) | OK | OK | OK |
| q04_union_call_tounion | MISREAD (2/4 lines) | MISREAD (1/4 lines) | OK | OK | OK | MISREAD (2/4 lines) | MISREAD (1/4 lines) | OK | OK |
| q05_lies_crash | CRASH (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | CRASH (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) |
| q07b_static_any_fields_unions | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) |
| q08_member_choice | TYPEERR (1/3 lines) | OK | TYPEERR (1/3 lines) | OK | OK | TYPEERR (1/3 lines) | OK | OK | OK |
| q09b_static_routes | MISREAD (3/3 lines) | OK | MISREAD (3/3 lines) | OK | OK | MISREAD (3/3 lines) | OK | OK | OK |
| q10_no_declared_types | MISREAD (1/1 lines) | OK | MISREAD (1/1 lines) | OK | OK | MISREAD (1/1 lines) | OK | OK | OK |
| r02b_to_union_base_path | CRASH (3/3 lines) | CRASH (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) | CRASH (3/3 lines) | CRASH (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) |
| r04_to_union_honest_numbers | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) |
| r07_shape_union_array_field | MISREAD (2/4 lines) | OK | OK | OK | OK | MISREAD (1/4 lines) | OK | OK | OK |
| r08_shape_union_regression | OK | OK | OK | OK | OK | MISREAD (2/2 lines) | OK | OK | OK |
| r12_shape_union_map_field | OK | OK | TYPEERR (2/2 lines) | TYPEERR (2/2 lines) | OK | MISREAD (2/2 lines) | TYPEERR (1/2 lines) | TYPEERR (2/2 lines) | TYPEERR (1/2 lines) |
| r14_shape_union_crash | OK | OK | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) | OK | CRASH (1/1 lines) | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) |
| r15_honest_partial_coverage | OK | OK | OK | OK | OK | MISREAD (3/4 lines) | OK | OK | OK |
| r16_h09a_same_class | MISREAD (1/3 lines) | OK | OK | OK | OK | MISREAD (1/3 lines) | OK | OK | OK |
| residual | TYPEERR (2/2 lines) | OK | OK | OK | OK | TYPEERR (2/2 lines) | OK | OK | OK |

#### head

- erased_objects_typed_reads:1: pts 'an element access, a typed read 15' / node 'an element access, a typed read 14'
- erased_objects_typed_reads:2: pts 'an optional call, a typed read 18' / node 'an optional call, a typed read 16'
- erased_objects_typed_reads:3: pts 'a method value, a typed read 20' / node 'a method value, a typed read 18'
- erased_objects_typed_reads:4: pts 'an any argument, a typed read 15' / node 'an any argument, a typed read 14'
- erased_objects_typed_reads:5: pts 'a JSON value, a typed read 22' / node 'a JSON value, a typed read 20'
- erased_objects_typed_reads:6: pts 'an integer array 1' / node 'an integer array 201'
- erased_objects_typed_reads:8: pts 'held, then iterated 6.5' / node 'held, then iterated 6'
- erased_objects_typed_reads:9: pts 'destructured 9' / node 'destructured 8'
- erased_objects_typed_reads:10: pts 'a dynamic field read as a number (C186) TypeError Cannot read property value of Object as number: it is declared value' / node 'a dynamic field read as a number (C186) 10'
- erased_objects_typed_reads:11: pts 'a dynamic field read as an interface (C186) TypeError Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node 'a dynamic field read as an interface (C186) 1 1100'
- erased_objects_typed_reads:12: pts 'a getter of a dynamic value TypeError Cannot read property value of Object as number: it is declared value' / node 'a getter of a dynamic value 12'
- erased_objects_typed_reads:13: pts 'a tuple 15' / node 'a tuple 14'
- erased_objects_typed_reads:14: pts 'a nested object TypeError Cannot read property n of Object as number: it is declared value' / node 'a nested object 14'
- erased_objects_typed_reads:15: pts 'a hash-map object 15' / node 'a hash-map object 14'
- erased_objects_typed_reads:16: pts 'a closure 3.992094846249083e-110' / node 'a closure 14'
- erased_objects_typed_reads:17: pts 'an optional property TypeError Cannot read property value of Object as number | undefined: it is declared value' / node 'an optional property 14'
- erased_objects_union_routes:1: pts 'a union in an object type 15' / node 'a union in an object type 14'
- erased_objects_union_routes:2: pts 'an array of unions 15' / node 'an array of unions 14'
- erased_objects_union_routes:3: pts "a class's field 15" / node "a class's field 14"
- erased_objects_union_routes:4: pts 'a callback of the erased copy 15' / node 'a callback of the erased copy 14'
- erased_objects_union_routes:5: pts "a generator's value 15" / node "a generator's value 14"
- erased_objects_union_routes:6: pts "a union call's array 15" / node "a union call's array 14"
- erased_objects_union_routes:7: pts "typed code's object with an any[] field 15" / node "typed code's object with an any[] field 14"
- erased_objects_union_routes:8: pts 'an awaited result 15' / node 'an awaited result 14'
- generic_method_object_arguments:1: pts 'interface type argument TypeError Expected Box<User>, got Box<any>' / node 'interface type argument ana'
- generic_method_object_arguments:2: pts 'object literal type argument TypeError Expected Box<{ id: number; }>, got Box<any>' / node 'object literal type argument 2'
- generic_method_object_arguments:3: pts 'array of interfaces TypeError Expected Box<User[]>, got Box<any[]>' / node 'array of interfaces 1'
- generic_method_object_arguments:4: pts 'Map of interfaces TypeError Expected Box<User | undefined>, got Box<any>' / node 'Map of interfaces ana'
- generic_method_object_arguments:5: pts 'interface or undefined TypeError Expected Box<User | undefined>, got Box<any>' / node 'interface or undefined ana'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- om3:1: pts 'typed read Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node 'typed read 1100'
- om3:2: pts 'typed read 2 Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node 'typed read 2 1100'
- q01_assertion_any_field:2: pts 'assigned 15' / node 'assigned 14'
- q02_nested_union_implies:2: pts 'array of unions 15' / node 'array of unions 14'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q03_class_field_and_callbacks:1: pts 'class field 15' / node 'class field 14'
- q03_class_field_and_callbacks:2: pts 'callback 15' / node 'callback 14'
- q03_class_field_and_callbacks:3: pts 'generator 15' / node 'generator 14'
- q03_class_field_and_callbacks:4: pts 'awaited 15' / node 'awaited 14'
- q04_union_call_tounion:1: pts 'array or undefined, any argument 15' / node 'array or undefined, any argument 14'
- q04_union_call_tounion:2: pts 'tagged union, any argument 15' / node 'tagged union, any argument 14'
- q05_lies_crash:1: pts '<none>' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts '<none>' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts '<none>' / node 'string from a dynamic field holding a number undefined'
- q05_lies_crash: pts exit 139 ''
- q07b_static_any_fields_unions:2: pts 'union 15' / node 'union 14'
- q07b_static_any_fields_unions:3: pts 'union parameter 15' / node 'union parameter 14'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property n of Object as number: it is declared value' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union 15' / node 'map of any, union 14'
- q08_member_choice:1: pts "nested, after a hash-map member TypeError Cannot read property 'n' of #<Object>: it has none, though a type assertion says it has" / node 'nested, after a hash-map member 14'
- q09b_static_routes:1: pts 'argument 15' / node 'argument 14'
- q09b_static_routes:2: pts 'returned 15' / node 'returned 14'
- q09b_static_routes:3: pts 'array element 15' / node 'array element 14'
- q10_no_declared_types:1: pts '15' / node '14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 139 ''
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r04_to_union_honest_numbers:3: pts 'base route: a declaration, then a typed read 8.5' / node 'base route: a declaration, then a typed read 8'
- r07_shape_union_array_field:2: pts 'head 8.5' / node 'head 8'
- r07_shape_union_array_field:4: pts 'honest 8.5' / node 'honest 8'
- r16_h09a_same_class:2: pts "optional call, then instance { tag: 'some', value: [ 9 ] }" / node "optional call, then instance { tag: 'some', value: [ 8 ] }"
- residual:1: pts 'first TypeError Expected Box<number>, got Box<any>' / node 'first 7'
- residual:2: pts 'typed read 8.5' / node 'typed read 8'

#### protoA

- erased_objects_union_routes:6: pts "a union call's array 15" / node "a union call's array 14"
- generic_method_object_arguments:1: pts 'interface type argument TypeError Expected Box<User>, got Box<any>' / node 'interface type argument ana'
- generic_method_object_arguments:2: pts 'object literal type argument TypeError Expected Box<{ id: number; }>, got Box<any>' / node 'object literal type argument 2'
- generic_method_object_arguments:3: pts 'array of interfaces TypeError Expected Box<User[]>, got Box<any[]>' / node 'array of interfaces 1'
- generic_method_object_arguments:4: pts 'Map of interfaces TypeError Expected Box<User | undefined>, got Box<any>' / node 'Map of interfaces ana'
- generic_method_object_arguments:5: pts 'interface or undefined TypeError Expected Box<User | undefined>, got Box<any>' / node 'interface or undefined ana'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q04_union_call_tounion:1: pts 'array or undefined, any argument 15' / node 'array or undefined, any argument 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 139 ''
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r04_to_union_honest_numbers:3: pts 'base route: a declaration, then a typed read 8.5' / node 'base route: a declaration, then a typed read 8'

#### protoB

- erased_objects_typed_reads:14: pts "a nested object TypeError Cannot read property 'n' of #<Object>: it has none, though a type assertion says it has" / node 'a nested object 14'
- erased_objects_union_routes:7: pts "typed code's object with an any[] field 15" / node "typed code's object with an any[] field 14"
- generic_method_object_arguments:1: pts 'interface type argument TypeError Expected Box<User>, got Box<any>' / node 'interface type argument ana'
- generic_method_object_arguments:2: pts 'object literal type argument TypeError Expected Box<{ id: number; }>, got Box<any>' / node 'object literal type argument 2'
- generic_method_object_arguments:3: pts 'array of interfaces TypeError Expected Box<User[]>, got Box<any[]>' / node 'array of interfaces 1'
- generic_method_object_arguments:4: pts 'Map of interfaces TypeError Expected Box<User | undefined>, got Box<any>' / node 'Map of interfaces ana'
- generic_method_object_arguments:5: pts 'interface or undefined TypeError Expected Box<User | undefined>, got Box<any>' / node 'interface or undefined ana'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q01_assertion_any_field:2: pts 'assigned 15' / node 'assigned 14'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:2: pts 'union 15' / node 'union 14'
- q07b_static_any_fields_unions:3: pts 'union parameter 15' / node 'union parameter 14'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property n of Object as number: it is declared value' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union 15' / node 'map of any, union 14'
- q08_member_choice:1: pts "nested, after a hash-map member TypeError Cannot read property 'n' of #<Object>: it has none, though a type assertion says it has" / node 'nested, after a hash-map member 14'
- q09b_static_routes:1: pts 'argument 15' / node 'argument 14'
- q09b_static_routes:2: pts 'returned 15' / node 'returned 14'
- q09b_static_routes:3: pts 'array element 15' / node 'array element 14'
- q10_no_declared_types:1: pts '15' / node '14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 1 'Uncaught TypeError: Expected string[] | undefined, got Array\n    at /tmp/h09b2/repro/scratch/r02b_to_union_base_path.3_tha_7z/r02b_to_union_base_path.pts:37'
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r12_shape_union_map_field:1: pts "map field TypeError Cannot read properties of undefined (reading 'get')" / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r12_shape_union_map_field:2: pts "object field TypeError Cannot read properties of undefined (reading 'n')" / node "object field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts "head TypeError Cannot read properties of undefined (reading '0')" / node "head { tag: 'some', value: [ 7 ] }"

#### protoAB

- generic_method_object_arguments:1: pts 'interface type argument TypeError Expected Box<User>, got Box<any>' / node 'interface type argument ana'
- generic_method_object_arguments:2: pts 'object literal type argument TypeError Expected Box<{ id: number; }>, got Box<any>' / node 'object literal type argument 2'
- generic_method_object_arguments:3: pts 'array of interfaces TypeError Expected Box<User[]>, got Box<any[]>' / node 'array of interfaces 1'
- generic_method_object_arguments:4: pts 'Map of interfaces TypeError Expected Box<User | undefined>, got Box<any>' / node 'Map of interfaces ana'
- generic_method_object_arguments:5: pts 'interface or undefined TypeError Expected Box<User | undefined>, got Box<any>' / node 'interface or undefined ana'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 1 'Uncaught TypeError: Expected string[] | undefined, got Array\n    at /tmp/h09b2/repro/scratch/r02b_to_union_base_path.9g5e1ogo/r02b_to_union_base_path.pts:37'
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r12_shape_union_map_field:1: pts "map field TypeError Cannot read properties of undefined (reading 'get')" / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r12_shape_union_map_field:2: pts "object field TypeError Cannot read properties of undefined (reading 'n')" / node "object field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts "head TypeError Cannot read properties of undefined (reading '0')" / node "head { tag: 'some', value: [ 7 ] }"

#### protoAB2

- generic_method_object_arguments:1: pts 'interface type argument TypeError Expected Box<User>, got Box<any>' / node 'interface type argument ana'
- generic_method_object_arguments:2: pts 'object literal type argument TypeError Expected Box<{ id: number; }>, got Box<any>' / node 'object literal type argument 2'
- generic_method_object_arguments:3: pts 'array of interfaces TypeError Expected Box<User[]>, got Box<any[]>' / node 'array of interfaces 1'
- generic_method_object_arguments:4: pts 'Map of interfaces TypeError Expected Box<User | undefined>, got Box<any>' / node 'Map of interfaces ana'
- generic_method_object_arguments:5: pts 'interface or undefined TypeError Expected Box<User | undefined>, got Box<any>' / node 'interface or undefined ana'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 1 'Uncaught TypeError: Expected string[] | undefined, got Array\n    at /tmp/h09b2/repro/scratch/r02b_to_union_base_path.7lxi6zpj/r02b_to_union_base_path.pts:37'
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'

#### liftHead

- erased_objects_typed_reads:1: pts 'an element access, a typed read 15' / node 'an element access, a typed read 14'
- erased_objects_typed_reads:2: pts 'an optional call, a typed read 18' / node 'an optional call, a typed read 16'
- erased_objects_typed_reads:3: pts 'a method value, a typed read 20' / node 'a method value, a typed read 18'
- erased_objects_typed_reads:4: pts 'an any argument, a typed read 15' / node 'an any argument, a typed read 14'
- erased_objects_typed_reads:5: pts 'a JSON value, a typed read 22' / node 'a JSON value, a typed read 20'
- erased_objects_typed_reads:6: pts 'an integer array 1' / node 'an integer array 201'
- erased_objects_typed_reads:8: pts 'held, then iterated 6.5' / node 'held, then iterated 6'
- erased_objects_typed_reads:9: pts 'destructured 9' / node 'destructured 8'
- erased_objects_typed_reads:10: pts 'a dynamic field read as a number (C186) TypeError Cannot read property value of Object as number: it is declared value' / node 'a dynamic field read as a number (C186) 10'
- erased_objects_typed_reads:11: pts 'a dynamic field read as an interface (C186) TypeError Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node 'a dynamic field read as an interface (C186) 1 1100'
- erased_objects_typed_reads:12: pts 'a getter of a dynamic value TypeError Cannot read property value of Object as number: it is declared value' / node 'a getter of a dynamic value 12'
- erased_objects_typed_reads:13: pts 'a tuple 15' / node 'a tuple 14'
- erased_objects_typed_reads:14: pts 'a nested object TypeError Cannot read property n of Object as number: it is declared value' / node 'a nested object 14'
- erased_objects_typed_reads:15: pts 'a hash-map object 15' / node 'a hash-map object 14'
- erased_objects_typed_reads:16: pts 'a closure 3.992094846249083e-110' / node 'a closure 14'
- erased_objects_typed_reads:17: pts 'an optional property TypeError Cannot read property value of Object as number | undefined: it is declared value' / node 'an optional property 14'
- erased_objects_union_routes:1: pts 'a union in an object type 15' / node 'a union in an object type 14'
- erased_objects_union_routes:2: pts 'an array of unions 15' / node 'an array of unions 14'
- erased_objects_union_routes:3: pts "a class's field 15" / node "a class's field 14"
- erased_objects_union_routes:4: pts 'a callback of the erased copy 15' / node 'a callback of the erased copy 14'
- erased_objects_union_routes:5: pts "a generator's value 15" / node "a generator's value 14"
- erased_objects_union_routes:6: pts "a union call's array 15" / node "a union call's array 14"
- erased_objects_union_routes:7: pts "typed code's object with an any[] field 15" / node "typed code's object with an any[] field 14"
- erased_objects_union_routes:8: pts 'an awaited result 15' / node 'an awaited result 14'
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- om2:2: pts 'literal Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node "literal { tag: 'some', value: '1100' }"
- om3:1: pts 'typed read Cannot read property value of Object as {id: number; zip?: string | undefined}: it is declared value' / node 'typed read 1100'
- q01_assertion_any_field:2: pts 'assigned 15' / node 'assigned 14'
- q02_nested_union_implies:2: pts 'array of unions 15' / node 'array of unions 14'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q03_class_field_and_callbacks:1: pts 'class field 15' / node 'class field 14'
- q03_class_field_and_callbacks:2: pts 'callback 15' / node 'callback 14'
- q03_class_field_and_callbacks:3: pts 'generator 15' / node 'generator 14'
- q03_class_field_and_callbacks:4: pts 'awaited 15' / node 'awaited 14'
- q04_union_call_tounion:1: pts 'array or undefined, any argument 15' / node 'array or undefined, any argument 14'
- q04_union_call_tounion:2: pts 'tagged union, any argument 15' / node 'tagged union, any argument 14'
- q05_lies_crash:1: pts '<none>' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts '<none>' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts '<none>' / node 'string from a dynamic field holding a number undefined'
- q05_lies_crash: pts exit 139 ''
- q07b_static_any_fields_unions:2: pts 'union 15' / node 'union 14'
- q07b_static_any_fields_unions:3: pts 'union parameter 15' / node 'union parameter 14'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property n of Object as number: it is declared value' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union 15' / node 'map of any, union 14'
- q08_member_choice:1: pts "nested, after a hash-map member TypeError Cannot read property 'n' of #<Object>: it has none, though a type assertion says it has" / node 'nested, after a hash-map member 14'
- q09b_static_routes:1: pts 'argument 15' / node 'argument 14'
- q09b_static_routes:2: pts 'returned 15' / node 'returned 14'
- q09b_static_routes:3: pts 'array element 15' / node 'array element 14'
- q10_no_declared_types:1: pts '15' / node '14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 139 ''
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r04_to_union_honest_numbers:3: pts 'base route: a declaration, then a typed read 8.5' / node 'base route: a declaration, then a typed read 8'
- r07_shape_union_array_field:2: pts 'head 8.5' / node 'head 8'
- r08_shape_union_regression:1: pts "head { tag: 'some', value: [ 7.5 ] }" / node "head { tag: 'some', value: [ 7 ] }"
- r08_shape_union_regression:2: pts "from JSON { tag: 'some', value: [ 2.25 ] }" / node "from JSON { tag: 'some', value: [ 2 ] }"
- r12_shape_union_map_field:1: pts "map field { tag: 'some', m: Map(1) { 'k' => 7.5 }, o: { n: 7.5 } }" / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r12_shape_union_map_field:2: pts 'object field TypeError Cannot read property n of Object as number: it is declared value' / node "object field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts '<none>' / node "head { tag: 'some', value: [ 7 ] }"
- r14_shape_union_crash: pts exit 139 ''
- r15_honest_partial_coverage:1: pts "element access, then dotted { tag: 'some', value: [ 7.5 ] }" / node "element access, then dotted { tag: 'some', value: [ 7 ] }"
- r15_honest_partial_coverage:2: pts "optional call, then dotted { tag: 'some', value: [ 9 ] }" / node "optional call, then dotted { tag: 'some', value: [ 8 ] }"
- r15_honest_partial_coverage:3: pts "method value, then dotted { tag: 'some', value: [ 10 ] }" / node "method value, then dotted { tag: 'some', value: [ 9 ] }"
- r16_h09a_same_class:2: pts "optional call, then instance { tag: 'some', value: [ 9 ] }" / node "optional call, then instance { tag: 'some', value: [ 8 ] }"
- residual:1: pts 'first TypeError Expected Box<number>, got Box<any>' / node 'first 7'
- residual:2: pts 'typed read 8.5' / node 'typed read 8'

#### liftA

- erased_objects_union_routes:6: pts "a union call's array 15" / node "a union call's array 14"
- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q04_union_call_tounion:1: pts 'array or undefined, any argument 15' / node 'array or undefined, any argument 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 139 ''
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r04_to_union_honest_numbers:3: pts 'base route: a declaration, then a typed read 8.5' / node 'base route: a declaration, then a typed read 8'
- r12_shape_union_map_field:1: pts 'map field TypeError Cannot read property m of Object as Map<string, number>: it is declared Map<string, value>' / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts 'head TypeError Cannot read property value of Object as string[]: it is declared value[]' / node "head { tag: 'some', value: [ 7 ] }"

#### liftAB

- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 1 'Uncaught TypeError: Expected string[] | undefined, got Array\n    at /tmp/h09b2/repro/scratch/r02b_to_union_base_path.1_a8s1hi/r02b_to_union_base_path.pts:37'
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r12_shape_union_map_field:1: pts "map field TypeError Cannot read property 'm' of #<Object>: it has none, though a type assertion says it has" / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r12_shape_union_map_field:2: pts "object field TypeError Cannot read property 'o' of #<Object>: it has none, though a type assertion says it has" / node "object field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts "head TypeError Cannot read property 'value' of #<Object>: it has none, though a type assertion says it has" / node "head { tag: 'some', value: [ 7 ] }"

#### liftAB2

- generic_method_object_arguments:6: pts 'union of object types TypeError Expected Box<number>, got Box<any>' / node 'union of object types 4'
- q02_nested_union_implies:3: pts 'map of unions TypeError Expected Map<string, {tag: string; value: number[]} | {tag: string}>, got Map' / node 'map of unions 14'
- q05_lies_crash:1: pts 'string from an any[] holding a number TypeError' / node 'string from an any[] holding a number undefined'
- q05_lies_crash:2: pts 'class from an any[] holding a number TypeError' / node 'class from an any[] holding a number undefined'
- q05_lies_crash:3: pts 'string from a dynamic field holding a number TypeError' / node 'string from a dynamic field holding a number undefined'
- q07b_static_any_fields_unions:4: pts 'nested any field, union TypeError Cannot read property value of Object as {n: number}: it is declared {n: value}' / node 'nested any field, union 14'
- q07b_static_any_fields_unions:5: pts 'map of any, union TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>' / node 'map of any, union 14'
- r02b_to_union_base_path:1: pts '<none>' / node 'typeof number'
- r02b_to_union_base_path:2: pts '<none>' / node 'typed function number'
- r02b_to_union_base_path:3: pts '<none>' / node 'length undefined'
- r02b_to_union_base_path: pts exit 1 'Uncaught TypeError: Expected string[] | undefined, got Array\n    at /tmp/h09b2/repro/scratch/r02b_to_union_base_path.we4klpme/r02b_to_union_base_path.pts:37'
- r04_to_union_honest_numbers:1: pts 'honest numbers, into an instance by name TypeError Expected Box<number>, got Box<any>' / node 'honest numbers, into an instance by name number 5 6'
- r04_to_union_honest_numbers:2: pts 'honest booleans TypeError Expected Box<boolean>, got Box<any>' / node 'honest booleans true true'
- r12_shape_union_map_field:1: pts 'map field TypeError Cannot read property m of Object as Map<string, number>: it is declared Map<string, value>' / node "map field { tag: 'some', m: Map(1) { 'k' => 7 }, o: { n: 7 } }"
- r14_shape_union_crash:1: pts 'head TypeError Cannot read property value of Object as string[]: it is declared value[]' / node "head { tag: 'some', value: [ 7 ] }"
