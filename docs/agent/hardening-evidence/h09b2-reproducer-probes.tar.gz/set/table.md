| program | head | protoA | protoB | protoAB | protoAB2 | liftHead | liftA | liftAB | liftAB2 |
|---|---|---|---|---|---|---|---|---|---|
| erased_objects_typed_reads | MISREAD (16/17 lines) | OK | TYPEERR (1/17 lines) | OK | OK | MISREAD (16/17 lines) | OK | OK | OK |
| erased_objects_union_routes | MISREAD (8/8 lines) | MISREAD (1/8 lines) | MISREAD (1/8 lines) | OK | OK | MISREAD (8/8 lines) | MISREAD (1/8 lines) | OK | OK |
| generic_method_object_arguments | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (6/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) | TYPEERR (1/8 lines) |
| om2 | OK | OK | OK | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| om3 | MISREAD (2/2 lines) | OK | OK | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| q01_assertion_any_field | MISREAD (1/2 lines) | OK | MISREAD (1/2 lines) | OK | OK | MISREAD (1/2 lines) | OK | OK | OK |
| q02_nested_union_implies | MISREAD (2/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | MISREAD (2/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) | TYPEERR (1/3 lines) |
| q03_class_field_and_callbacks | MISREAD (4/4 lines) | OK | OK | OK | OK | MISREAD (4/4 lines) | OK | OK | OK |
| q04_union_call_tounion | MISREAD (2/4 lines) | MISREAD (1/4 lines) | OK | OK | OK | MISREAD (2/4 lines) | MISREAD (1/4 lines) | OK | OK |
| q05_lies_crash | CRASH (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | CRASH (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) |
| q07b_static_any_fields_unions | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) | MISREAD (4/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) | TYPEERR (2/5 lines) |
| q08_member_choice | TYPEERR (1/3 lines) | OK | TYPEERR (1/3 lines) | OK | OK | TYPEERR (1/3 lines) | OK | OK | OK |
| q09b_static_routes | MISREAD (3/3 lines) | OK | MISREAD (3/3 lines) | OK | OK | MISREAD (3/3 lines) | OK | OK | OK |
| q10_no_declared_types | MISREAD (1/1 lines) | OK | MISREAD (1/1 lines) | OK | OK | MISREAD (1/1 lines) | OK | OK | OK |
| r02b_to_union_base_path | CRASH (3/3 lines) | CRASH (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) | CRASH (3/3 lines) | CRASH (3/3 lines) | OTHER (3/3 lines) | OTHER (3/3 lines) |
| r04_to_union_honest_numbers | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) | TYPEERR (3/3 lines) | TYPEERR (3/3 lines) | TYPEERR (2/3 lines) | TYPEERR (2/3 lines) |
| r07_shape_union_array_field | MISREAD (2/4 lines) | OK | OK | OK | OK | MISREAD (1/4 lines) | OK | OK | OK |
| r08_shape_union_regression | OK | OK | OK | OK | OK | MISREAD (2/2 lines) | OK | OK | OK |
| r12_shape_union_map_field | OK | OK | TYPEERR (2/2 lines) | TYPEERR (2/2 lines) | OK | MISREAD (2/2 lines) | TYPEERR (1/2 lines) | TYPEERR (2/2 lines) | TYPEERR (1/2 lines) |
| r14_shape_union_crash | OK | OK | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) | OK | CRASH (1/1 lines) | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) | TYPEERR (1/1 lines) |
| r15_honest_partial_coverage | OK | OK | OK | OK | OK | MISREAD (3/4 lines) | OK | OK | OK |
| r16_h09a_same_class | MISREAD (1/3 lines) | OK | OK | OK | OK | MISREAD (1/3 lines) | OK | OK | OK |
| residual | TYPEERR (2/2 lines) | OK | OK | OK | OK | TYPEERR (2/2 lines) | OK | OK | OK |
