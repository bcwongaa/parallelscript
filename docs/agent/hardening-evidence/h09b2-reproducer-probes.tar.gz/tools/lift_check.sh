#!/bin/bash
# lift_check.sh : runs the H09b1-restriction programs with the restriction lifted, under each runtime.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
R=/tmp/h09b2/repro
files="$R/red/src/generic_method_object_arguments.pts $WT/pts/tests/run/generic_method_erased_objects.pts $R/red/src/r08_shape_union_regression.pts $R/red/src/r12_shape_union_map_field.pts $R/red/src/r14_shape_union_crash.pts $R/red/src/r15_honest_partial_coverage.pts $R/red/src/om2.pts $R/red/src/r07_shape_union_array_field.pts"
run() {
  label=$1 pts=$2 home=$3
  echo "##### $label"
  for f in $files; do
    b=$(basename "$f" .pts)
    d=$(mktemp -d $R/scratch/lift.XXXX)
    cp "$f" "$d/$b.pts"
    out=$(cd "$d" && PTS_HOME=$home timeout 180 "$pts" run "$b.pts" 2>&1)
    code=$?
    echo "=== $b (exit $code)"
    echo "$out"
    rm -rf "$d"
  done
}
run "lifted, HEAD runtime" $R/bin/pts-lift $WT
run "lifted, runtime (a)" $R/bin/pts-lift $R/proto-home
run "lifted + lowering (b), runtime (b)" $R/bin/pts-blift $R/proto-home-b
run "lifted + lowering (b), runtime (a)+(b)" $R/bin/pts-blift $R/proto-home-ab
