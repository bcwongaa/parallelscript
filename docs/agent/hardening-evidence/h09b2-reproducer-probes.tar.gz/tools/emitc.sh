#!/bin/bash
# emitc.sh OUTDIR FILE.pts... : writes OUTDIR/<name>.c for each program with the worktree's pts.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
PTS=${PTS:-$WT/pts-bin/pts}
out=$1
shift
for f in "$@"; do
  b=$(basename "$f" .pts)
  PTS_HOME=${PTS_HOME_OVERRIDE:-$WT} "$PTS" emit-c "$f" -o "$out/$b.c"
  echo "$b exit=$?"
done
