#!/bin/bash
# tri.sh FILE.pts... : runs each with the worktree's pts (PTS_HOME=worktree) and with Node (.mts copy),
# printing both outputs with their exit codes.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
PTS=${PTS:-$WT/pts-bin/pts}
HOME_=${PTS_HOME_OVERRIDE:-$WT}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
for f in "$@"; do
  b=$(basename "$f" .pts)
  d=$(mktemp -d /tmp/h09b2/repro/run.XXXX)
  cp "$f" "$d/$b.pts"
  cp "$f" "$d/$b.mts"
  echo "=== $f"
  echo "--- pts"
  (cd "$d" && PTS_HOME=$HOME_ timeout 120 "$PTS" run "$b.pts" 2>&1)
  echo "[pts exit=$?]"
  echo "--- node"
  (cd "$d" && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types "$b.mts" 2>&1)
  echo "[node exit=$?]"
  rm -rf "$d"
done
