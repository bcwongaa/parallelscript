#!/usr/bin/env python3
"""Applies the H09b2 direction-(b) prototype to a copy of pts/runtime/src/convert.c (argv[1])."""
import sys

p = sys.argv[1]
s = open(p).read()

old = '''static bool implies(implying *s, const pts_check *sub, const pts_check *super);
'''
new = '''static bool implies(implying *s, const pts_check *sub, const pts_check *super);
static bool foreign_implied(implying *s, const pts_check *sub, const pts_type *type, const pts_check *u, const pts_check *m);
'''
assert old in s
s = s.replace(old, new, 1)

old = '''  switch (super->kind) {
  case PTS_CHECK_UNION:
    for (uint32_t i = 0; i < super->count; i++) {
      if (implies(s, sub, super->members[i])) {
        return true;
      }
    }
    return false;'''
new = '''  switch (super->kind) {
  case PTS_CHECK_UNION:
    for (uint32_t i = 0; i < super->count; i++) {
      if (implies(s, sub, super->members[i]) &&
          (sub->kind != PTS_CHECK_OBJECT && sub->kind != PTS_CHECK_INSTANCE ? true
                                                                              : foreign_implied(s, sub->kind == PTS_CHECK_OBJECT ? sub : NULL,
                                                                                                sub->kind == PTS_CHECK_INSTANCE ? sub->type : NULL, super,
                                                                                                super->members[i]))) {
        return true;
      }
    }
    return false;'''
assert old in s
s = s.replace(old, new, 1)

old = '''bool pts_check_implies(const pts_check *sub, const pts_check *super) {'''
new = '''/* Whether the object type m declares a property named name. */
static bool declares(const pts_check *m, const char *name) {
  if (m->kind != PTS_CHECK_OBJECT) {
    return false;
  }
  for (uint32_t i = 0; i < m->count; i++) {
    if (strcmp(m->properties[i].name, name) == 0) {
      return true;
    }
  }
  return false;
}

/*
 * H09b2 prototype (direction b): whether a value of object type sub (or an object of
 * descriptor type), which is one of member m of the union u as it is, is safe to read as any
 * other member: narrowing by a tag (a string in the IR) may take it as another member n, whose
 * properties it holds beside m's must then be of n's types too. An erased copy's
 * { tag: "some"; value: any[] } is one of { tag: "none" } as it is, but not of
 * { tag: "some"; value: number[] } | { tag: "none" }.
 */
static bool foreign_implied(implying *s, const pts_check *sub, const pts_type *type, const pts_check *u, const pts_check *m) {
  for (uint32_t i = 0; i < u->count; i++) {
    const pts_check *n = u->members[i];
    if (n == m || n->kind != PTS_CHECK_OBJECT) {
      continue;
    }
    for (uint32_t j = 0; j < n->count; j++) {
      const pts_check_property *property = &n->properties[j];
      if (declares(m, property->name)) {
        continue;
      }
      if (sub != NULL) {
        for (uint32_t k = 0; k < sub->count; k++) {
          const pts_check_property *own = &sub->properties[k];
          if (strcmp(own->name, property->name) == 0 && !place_implies(s, own->check->slot, own->check, property)) {
            return false;
          }
        }
        continue;
      }
      const pts_field *field = field_named(type, property->name);
      if (field != NULL) {
        if (!place_implies(s, field->kind, pts_check_declared(field->kind, field->check), property)) {
          return false;
        }
        continue;
      }
      const pts_method *getter = getter_named(type, property->name);
      if (getter != NULL && (getter->result != property->check->slot || !implies(s, pts_check_declared(getter->result, getter->check), property->check))) {
        return false;
      }
    }
  }
  return true;
}

bool pts_check_implies(const pts_check *sub, const pts_check *super) {'''
assert old in s
s = s.replace(old, new, 1)

old = '''  case PTS_CHECK_UNION:
    for (uint32_t i = 0; i < check->count; i++) {
      c->results_last = true;
      if (convert(c, value, check->members[i], false, out)) {
        return true;
      }
    }'''
new = '''  case PTS_CHECK_UNION:
    for (uint32_t i = 0; i < check->count; i++) {
      c->results_last = true;
      if (convert(c, value, check->members[i], false, out)) {
        if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
          implying s;
          s.depth = 0;
          if (!foreign_implied(&s, NULL, pts_value_as_object(value)->type, check, check->members[i])) {
            continue; /* H09b2 prototype (b): copied into the member it converts to, below, or as it is if none */
          }
        }
        return true;
      }
    }'''
assert old in s
s = s.replace(old, new, 1)

old = '''    for (uint32_t i = 0; copy && i < check->count; i++) {
      if (check->members[i]->result) {
        continue;
      }
      c->results_last = true;
      if (convert(c, value, check->members[i], true, out)) {
        return true;
      }
    }'''
new = '''    for (uint32_t i = 0; copy && i < check->count; i++) {
      if (check->members[i]->result) {
        continue;
      }
      c->results_last = true;
      if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
        implying s;
        s.depth = 0;
        if (!foreign_implied(&s, NULL, pts_value_as_object(value)->type, check, check->members[i])) {
          c->results_last = false;
          if (copy_object(c, pts_value_as_object(value), check->members[i], out)) {
            return true; /* H09b2 prototype (b): a copy, never the object as it is */
          }
          continue;
        }
      }
      if (convert(c, value, check->members[i], true, out)) {
        return true;
      }
    }'''
assert old in s
s = s.replace(old, new, 1)

open(p, "w").write(s)
print("patched", p)
