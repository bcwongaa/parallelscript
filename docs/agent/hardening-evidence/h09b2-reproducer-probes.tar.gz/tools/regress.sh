#!/bin/bash
# regress.sh : runs a subset of pts/tests/run (generics, any, unions, dynamic, JSON, interfaces, optional, literals, records, flat, iterator results) under HEAD and the prototypes.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
R=/tmp/h09b2/repro
mkdir -p $R/regress
files=$(ls $WT/pts/tests/run/*.pts | grep -E "/(generic|any_|union|dynamic|json|interface|optional|object_literal|record|flat|iterator_result|convert|narrow|discriminat|tagged|option|shape)[^/]*\.pts$")
python3 -I $R/tools/runexpect.py --pts $WT/pts-bin/pts --home $WT --out $R/regress/head.json $files
python3 -I $R/tools/runexpect.py --pts $WT/pts-bin/pts --home $R/proto-home --out $R/regress/protoA.json $files
python3 -I $R/tools/runexpect.py --pts $R/bin/pts-b --home $R/proto-home-ab --out $R/regress/protoAB.json $files
python3 -I $R/tools/runexpect.py --pts $R/bin/pts-blift --home $R/proto-home-ab --out $R/regress/liftAB.json $files
python3 -I $R/tools/runexpect.py --pts $R/bin/pts-lift --home $R/proto-home --out $R/regress/liftA.json $files
