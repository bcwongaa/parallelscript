#!/bin/bash
# cmain.sh FILE.c : prints pts_main's body without #line directives.
sed -n '/^static void pts_main(void) {/,/^}/p' "$1" | grep -v '^#line'
