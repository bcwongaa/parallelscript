#!/usr/bin/env python3
"""Turns prototype (b)'s convert.c (argv[1], patched by patch_b.py) into (b2): an object that fits a
union member as it is but holds another member's property of another type is copied into a member
that keeps every such property; if no such copy converts, it is kept as it is (as HEAD does), and
typed reads (prototype a) convert what they read or throw. Copies never drop another member's fields."""
import sys

p = sys.argv[1]
s = open(p).read()

old = '''  case PTS_CHECK_UNION:
    for (uint32_t i = 0; i < check->count; i++) {
      c->results_last = true;
      if (convert(c, value, check->members[i], false, out)) {
        if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
          implying s;
          s.depth = 0;
          if (!foreign_implied(&s, NULL, pts_value_as_object(value)->type, check, check->members[i])) {
            continue; /* H09b2 prototype (b): copied into the member it converts to, below, or as it is if none */
          }
        }
        return true;
      }
    }'''
new = '''  case PTS_CHECK_UNION: {
    int64_t kept = -1; /* H09b2 prototype (b2): the member the object fits as it is but for another member's properties */
    for (uint32_t i = 0; i < check->count; i++) {
      c->results_last = true;
      if (convert(c, value, check->members[i], false, out)) {
        if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
          implying s;
          s.depth = 0;
          if (!foreign_implied(&s, NULL, pts_value_as_object(value)->type, check, check->members[i])) {
            if (kept < 0) {
              kept = i;
            }
            continue;
          }
        }
        return true;
      }
    }'''
assert old in s
s = s.replace(old, new, 1)

old = '''      if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
        implying s;
        s.depth = 0;
        if (!foreign_implied(&s, NULL, pts_value_as_object(value)->type, check, check->members[i])) {
          c->results_last = false;
          if (copy_object(c, pts_value_as_object(value), check->members[i], out)) {
            return true; /* H09b2 prototype (b): a copy, never the object as it is */
          }
          continue;
        }
      }
      if (convert(c, value, check->members[i], true, out)) {
        return true;
      }
    }'''
new = '''      if (check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT) &&
          drops_foreign(pts_value_as_object(value)->type, check, check->members[i])) {
        continue; /* H09b2 prototype (b2): a copy that would drop another member's property */
      }
      if (kept >= 0 && check->members[i]->kind == PTS_CHECK_OBJECT && is_kind(value, PTS_KIND_OBJECT)) {
        c->results_last = false;
        if (copy_object(c, pts_value_as_object(value), check->members[i], out)) {
          return true; /* H09b2 prototype (b2): a copy into the member whose properties it holds */
        }
        continue;
      }
      if (convert(c, value, check->members[i], true, out)) {
        return true;
      }
    }
    if (kept >= 0) {
      *out = value; /* H09b2 prototype (b2): as it is, as HEAD keeps it; typed reads convert what they read */
      return true;
    }'''
assert old in s
s = s.replace(old, new, 1)

old = '''      c->results_last = false;
      if (convert(c, value, check->members[i], copy, out)) {
        return true;
      }
    }
    return false;
  default:
    break;
  }
  if (!pts_value_is_object(value)) {'''
new = '''      c->results_last = false;
      if (convert(c, value, check->members[i], copy, out)) {
        return true;
      }
    }
    return false;
  }
  default:
    break;
  }
  if (!pts_value_is_object(value)) {'''
assert old in s
s = s.replace(old, new, 1)

old = '''bool pts_check_implies(const pts_check *sub, const pts_check *super) {'''
new = '''/* Whether a copy of an object of descriptor type into member m of union u would leave out a property another member declares. */
static bool drops_foreign(const pts_type *type, const pts_check *u, const pts_check *m) {
  for (uint32_t i = 0; i < u->count; i++) {
    const pts_check *n = u->members[i];
    if (n == m || n->kind != PTS_CHECK_OBJECT) {
      continue;
    }
    for (uint32_t j = 0; j < n->count; j++) {
      const char *name = n->properties[j].name;
      if (!declares(m, name) && (field_named(type, name) != NULL || getter_named(type, name) != NULL)) {
        return true;
      }
    }
  }
  return false;
}

bool pts_check_implies(const pts_check *sub, const pts_check *super) {'''
assert old in s
s = s.replace(old, new, 1)
open(p, "w").write(s)
print("patched", p)
