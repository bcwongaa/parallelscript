#!/bin/bash
# run_ab2.sh : the matrix, the repro set and the regression subset under prototype (a)+(b2), and (a)+(b2) lifted.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
R=/tmp/h09b2/repro
export PATH=$HOME/.local/node/bin:$PATH
NODE=$HOME/.local/node/bin/node
python3 -I $R/tools/run_matrix.py --pts $R/bin/pts-b --home $R/proto-home-ab2 --node $NODE --scratch $R/scratch --out $R/matrix/protoAB2.json --node-cache $R/matrix/head.json --jobs 2 $R/matrix/cases/*.pts | tail -1
cp $R/tests/erased_objects_typed_writes.pts $R/probes/q11_closure_fields.pts $R/probes/q12_union_argument_literal.pts $R/probes/q13_typed_writes.pts $R/set/ 2>/dev/null
python3 -I $R/tools/run_matrix.py --pts $R/bin/pts-b --home $R/proto-home-ab2 --node $NODE --scratch $R/scratch --out $R/set/protoAB2.json --jobs 2 $R/set/*.pts | tail -1
python3 -I $R/tools/run_matrix.py --pts $R/bin/pts-blift --home $R/proto-home-ab2 --node $NODE --scratch $R/scratch --out $R/set/liftAB2.json --node-cache $R/set/protoAB2.json --jobs 2 $R/set/*.pts | tail -1
files=$(ls $WT/pts/tests/run/*.pts | grep -E "/(generic|any_|union|dynamic|json|interface|optional|object_literal|record|flat|iterator_result|convert|narrow|discriminat|tagged|option|shape)[^/]*\.pts$")
python3 -I $R/tools/runexpect.py --pts $R/bin/pts-b --home $R/proto-home-ab2 --out $R/regress/protoAB2.json $files
python3 -I $R/tools/runexpect.py --pts $R/bin/pts-blift --home $R/proto-home-ab2 --out $R/regress/liftAB2.json $files
