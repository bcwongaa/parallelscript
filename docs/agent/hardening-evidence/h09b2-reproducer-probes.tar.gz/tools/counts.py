#!/usr/bin/env python3
"""counts.py FILE.json... : class counts per result file, side by side."""
import collections
import json
import os
import sys

files = sys.argv[1:]
counts = {}
for f in files:
    with open(f) as fh:
        counts[f] = collections.Counter(r["cls"] for r in json.load(fh))
classes = sorted(set(c for cnt in counts.values() for c in cnt))
print("| class | " + " | ".join(os.path.basename(f)[:-5] for f in files) + " |")
print("|---|" + "---|" * len(files))
for c in classes:
    print(f"| {c} | " + " | ".join(str(counts[f].get(c, 0)) for f in files) + " |")
