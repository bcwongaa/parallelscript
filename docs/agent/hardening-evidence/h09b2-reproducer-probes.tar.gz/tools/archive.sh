#!/bin/bash
# archive.sh : packs the reproducer's probes, tools, results and prototype diffs into probes.tar.gz (with INDEX.txt).
R=/tmp/h09b2/repro
cd $R || exit 1
rm -f probes.tar.gz
tar -czf /tmp/h09b2/probes.tar.gz.tmp \
  INDEX.txt red probes tests matrix set regress lift lift_check.txt bench/*.pts bench/cg.sh bench/*.c cdump proto tools \
  ab2.log regress.log protoB-lower.diff protoB-lift-lower.diff
mv /tmp/h09b2/probes.tar.gz.tmp $R/probes.tar.gz
ls -la $R/probes.tar.gz
tar -tzf $R/probes.tar.gz | wc -l
