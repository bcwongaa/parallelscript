#!/usr/bin/env python3
"""runexpect.py --pts PTS --home HOME --out OUT.json [--jobs 2] FILES...

Runs each test file with pts and compares stdout (and the exit code, `// exit: n`, default 0)
to its `// expect:` block. Files with `// skip:` are skipped. Writes per-file results.
"""
import argparse
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import tempfile


def spec(text):
    want, exit_code, skip = None, 0, False
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("// skip:"):
            skip = True
        m = re.match(r"^// exit: (\d+)$", line)
        if m:
            exit_code = int(m.group(1))
        if line.strip() == "// expect:" and want is None:
            want = []
            for l in lines[i + 1:]:
                if not l.startswith("//") or re.match(r"^// (exit|stderr):", l):
                    break
                want.append(l[3:] if l.startswith("// ") else l[2:])
    return want, exit_code, skip


def one(path, args):
    name = os.path.basename(path)[:-4]
    with open(path) as f:
        text = f.read()
    want, exit_code, skip = spec(text)
    if skip or want is None:
        return dict(name=name, verdict="SKIP")
    d = tempfile.mkdtemp(prefix="rx.", dir=args.scratch)
    try:
        src = os.path.dirname(path)
        # copy sibling files a test may import or read
        for sib in os.listdir(src):
            p = os.path.join(src, sib)
            if os.path.isfile(p) and not sib.endswith(".pts"):
                pass
        shutil.copy(path, os.path.join(d, name + ".pts"))
        env = dict(os.environ, PTS_HOME=args.home, TZ="America/New_York")
        try:
            p = subprocess.run([args.pts, "run", name + ".pts"], cwd=d, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
            code, out, err = p.returncode, p.stdout.decode(errors="replace"), p.stderr.decode(errors="replace")
        except subprocess.TimeoutExpired:
            code, out, err = "timeout", "", ""
        ok = code == exit_code and out.splitlines() == want
        return dict(name=name, verdict="PASS" if ok else "FAIL", code=code, out=out[-3000:], err=err[-1500:])
    finally:
        shutil.rmtree(d, ignore_errors=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--scratch", default="/tmp/h09b2/repro/scratch")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    results = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        for r in ex.map(lambda p: one(p, args), sorted(args.files)):
            results.append(r)
    with open(args.out, "w") as f:
        json.dump(results, f, indent=1)
    counts = {}
    for r in results:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    print(json.dumps(counts, sort_keys=True))
    for r in results:
        if r["verdict"] == "FAIL":
            print("FAIL", r["name"], r.get("code"))


if __name__ == "__main__":
    main()
