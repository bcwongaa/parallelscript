#!/usr/bin/env python3
"""Summarizes a run_matrix.py result: counts per class, and tables per axis pair.

usage: report.py RESULT.json [BASE.json]
With BASE.json, also lists cases whose class changed between BASE and RESULT.
"""
import collections
import json
import sys

AX = ["P", "C", "E", "W", "K"]


def parse(name):
    return dict(zip(AX, name.split("__")))


def load(path):
    with open(path) as f:
        return {r["name"]: r for r in json.load(f)}


def table(rs, row, col, filt):
    cells = collections.defaultdict(collections.Counter)
    rows, cols = [], []
    for r in rs.values():
        a = parse(r["name"])
        if any(a[k] != v for k, v in filt.items()):
            continue
        cells[(a[row], a[col])][r["cls"]] += 1
        if a[row] not in rows:
            rows.append(a[row])
        if a[col] not in cols:
            cols.append(a[col])
    if not rows:
        return
    rows.sort()
    cols.sort()
    print(f"\n### {row} x {col} ({', '.join(f'{k}={v}' for k, v in filt.items())})\n")
    print("| " + row + " \\ " + col + " | " + " | ".join(cols) + " |")
    print("|" + "---|" * (len(cols) + 1))
    abbrev = {"OK": "ok", "MISREAD": "MIS", "TYPEERR": "TE", "CRASH": "CRASH", "DIAG": "diag", "TSERR": "tserr", "ICE": "ICE", "ERRDIFF": "errdiff", "OTHER": "other", "TIMEOUT": "TO", "NODEERR": "nodeerr"}
    for rname in rows:
        line = []
        for cname in cols:
            c = cells.get((rname, cname))
            if not c:
                line.append("")
            else:
                line.append("/".join(abbrev.get(k, k) for k, _ in c.most_common()))
        print("| " + rname + " | " + " | ".join(line) + " |")


def main():
    rs = load(sys.argv[1])
    counts = collections.Counter(r["cls"] for r in rs.values())
    print("counts:", dict(sorted(counts.items())), "total", len(rs))
    table(rs, "P", "C", {"E": "num", "W": "u", "K": "read"})
    table(rs, "C", "E", {"P": "elem", "W": "u", "K": "read"})
    table(rs, "K", "C", {"P": "elem", "E": "num", "W": "u"})
    table(rs, "W", "C", {"P": "elem", "E": "num", "K": "read"})
    table(rs, "E", "C", {"P": "lie", "W": "u", "K": "read"})
    table(rs, "E", "C", {"P": "dyn", "W": "u", "K": "read"})
    table(rs, "P", "K", {"C": "arr", "W": "u"})
    if len(sys.argv) > 2:
        base = load(sys.argv[2])
        print("\n### changed against", sys.argv[2], "\n")
        moves = collections.Counter()
        for n, r in sorted(rs.items()):
            b = base.get(n)
            if b and b["cls"] != r["cls"]:
                moves[(b["cls"], r["cls"])] += 1
                print(f"- {n}: {b['cls']} -> {r['cls']}  pts: {r['pts_out'].strip()[:120]!r}")
        print("\nmoves:", dict(moves))


if __name__ == "__main__":
    main()
