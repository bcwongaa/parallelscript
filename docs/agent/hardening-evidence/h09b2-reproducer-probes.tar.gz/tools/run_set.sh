#!/bin/bash
# run_set.sh : runs the repro set (set/*.pts) under HEAD, (a), (b), (a)+(b), and the lifted variants; writes set/<config>.json.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-accc90938bd79391e
R=/tmp/h09b2/repro
export PATH=$HOME/.local/node/bin:$PATH
NODE=$HOME/.local/node/bin/node
go() {
  python3 -I $R/tools/run_matrix.py --pts "$2" --home "$3" --node "$NODE" --scratch $R/scratch --out "$R/set/$1.json" --jobs 2 $4 $R/set/*.pts | tail -1
}
go head $WT/pts-bin/pts $WT ""
go protoA $WT/pts-bin/pts $R/proto-home "--node-cache $R/set/head.json"
go protoB $R/bin/pts-b $R/proto-home-b "--node-cache $R/set/head.json"
go protoAB $R/bin/pts-b $R/proto-home-ab "--node-cache $R/set/head.json"
go liftHead $R/bin/pts-lift $WT "--node-cache $R/set/head.json"
go liftA $R/bin/pts-lift $R/proto-home "--node-cache $R/set/head.json"
go liftAB $R/bin/pts-blift $R/proto-home-ab "--node-cache $R/set/head.json"
