#!/usr/bin/env python3
"""merge.py BASE.json PATCH.json : replaces BASE's results by PATCH's for the cases PATCH has (in place)."""
import json
import sys

base_path, patch_path = sys.argv[1], sys.argv[2]
with open(base_path) as f:
    base = json.load(f)
with open(patch_path) as f:
    patch = {r["name"]: r for r in json.load(f)}
merged = [patch.get(r["name"], r) for r in base]
with open(base_path, "w") as f:
    json.dump(merged, f, indent=1)
for name, r in sorted(patch.items()):
    print(r["cls"], name)
