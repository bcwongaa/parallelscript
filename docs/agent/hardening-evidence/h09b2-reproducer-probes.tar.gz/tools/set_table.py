#!/usr/bin/env python3
"""set_table.py DIR CONFIG... : a table of class per program and config, then per config the lines that differ from Node."""
import json
import os
import sys

d = sys.argv[1]
configs = sys.argv[2:]
data = {}
for c in configs:
    with open(os.path.join(d, c + ".json")) as f:
        data[c] = {r["name"]: r for r in json.load(f)}
names = sorted(data[configs[0]])
print("| program | " + " | ".join(configs) + " |")
print("|---|" + "---|" * len(configs))
for n in names:
    cells = []
    for c in configs:
        r = data[c].get(n)
        if r is None:
            cells.append("")
            continue
        node = r["node_out"].splitlines()
        pts = r["pts_out"].splitlines()
        wrong = sum(1 for i in range(max(len(node), len(pts))) if (pts[i] if i < len(pts) else None) != (node[i] if i < len(node) else None))
        cells.append(r["cls"] if r["cls"] == "OK" else f"{r['cls']} ({wrong}/{len(node)} lines)")
    print("| " + n + " | " + " | ".join(cells) + " |")
if "--lines" in os.environ.get("SET_TABLE", ""):
    for c in configs:
        print(f"\n#### {c}\n")
        for n in names:
            r = data[c][n]
            node = r["node_out"].splitlines()
            pts = r["pts_out"].splitlines()
            for i in range(max(len(node), len(pts))):
                a = pts[i] if i < len(pts) else "<none>"
                b = node[i] if i < len(node) else "<none>"
                if a != b:
                    print(f"- {n}:{i + 1}: pts {a!r} / node {b!r}")
            if r["pts_code"] != 0:
                print(f"- {n}: pts exit {r['pts_code']} {r['pts_err'].strip()[:160]!r}")
