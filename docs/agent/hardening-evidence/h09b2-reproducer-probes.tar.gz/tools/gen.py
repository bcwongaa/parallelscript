#!/usr/bin/env python3
"""H09b2 matrix generator: objects that erased copies make, read by typed code.

Each case is one program: a generic maker returns W<T>, an object type whose field `value`
holds T in some container; a producer obtains W<E> in a way that may keep the erased copy;
a consumer reads it typed. Every case prints one line `R <result>` (or `R <name> <message>`
when it throws), and the `log` consumer a line `L <object>` before it.

Axes:
  P producer   (how the object is obtained)
  C container  (where T sits inside the object)
  E element    (what T is)
  W wrapper    (the result type: a tagged union, a plain object type, ... )
  K consumer   (how typed code reads it)

usage: gen.py OUTDIR
"""
import os
import sys

E = {
    "num": dict(t="number", x="7", use="String(v * 2)", lie='"s"', json="7"),
    "str": dict(t="string", x='"ab"', use="v.toUpperCase()", lie="7", json='"ab"'),
    "bool": dict(t="boolean", x="true", use="String(v === true) + String(!v)", lie="7", json="true"),
    "u8": dict(t="u8", x="seven8", use="String(v + 1)", lie='"s"', json="7"),
    "int": dict(t="int", x="sevenI", use="String(v * 2)", lie='"s"', json="7"),
    "cls": dict(t="Pt", x="pt", use="String(v.x * 2)", lie="7", json=None),
    "iface": dict(t="IP", x="ip", use="String(v.x * 2)", lie="7", json='{"x": 7}'),
    "lit": dict(t="{ x: number; y: string }", x="lit", use="v.y + String(v.x * 2)", lie="7", json='{"x": 7, "y": "q"}'),
}

# ft: the field's type in terms of T; mk: the field's value in terms of x; rd: a read of one T from the field {V}.
C = {
    "arr": dict(ft="T[]", mk="[x]", rd="{V}[0]", it="{V}"),
    "map": dict(ft="Map<string, T>", mk='new Map([["k", x]])', rd='{V}.get("k")!', it="{V}.values()"),
    "set": dict(ft="Set<T>", mk="new Set([x])", rd="Array.from({V})[0]", it="{V}"),
    "rec": dict(ft="Record<string, T>", mk="{ k: x }", rd='{V}["k"]', it="Object.values({V})"),
    "nest": dict(ft="{ n: T }", mk="{ n: x }", rd="{V}.n", it=None),
    "tup": dict(ft="[T, T]", mk="[x, x]", rd="{V}[1]", it="{V}"),
    "direct": dict(ft="T", mk="x", rd="{V}", it=None),
    "orund": dict(ft="T | undefined", mk="x", rd="{V}!", it=None),
    "opt": dict(ft="T", mk="x", rd="{V}!", it=None, optional=True),
    "fn": dict(ft="() => T", mk="() => x", rd="{V}()", it=None),
    "box": dict(ft="Box<T>", mk="new Box(x)", rd="{V}.v", it=None),
    "getter": dict(ft="T", mk=None, rd="{V}", it=None, getter=True),
}

W = ["u", "s", "un", "i"]

P = ["dot", "elem", "opt", "mval", "anyarg", "json", "arrowmap", "union", "unionany", "iface", "ifaceany", "ifaceelem", "dyn", "lie", "fnany", "clsany"]

K = ["read", "destr", "spread", "param", "ginst", "minst", "iface", "log", "forof", "json", "ret", "ident", "write"]


def subst_t(s, t):
    """Replaces the type parameter T (as a whole word) in a type text."""
    out, i = [], 0
    while i < len(s):
        if s[i] == "T" and (i == 0 or not (s[i - 1].isalnum() or s[i - 1] == "_")) and (i + 1 == len(s) or not (s[i + 1].isalnum() or s[i + 1] == "_")):
            out.append(t)
        else:
            out.append(s[i])
        i += 1
    return "".join(out)


def program(p, c, e, w, k):
    ce, ee = C[c], E[e]
    if p == "json" and ee["json"] is None:
        return None
    if k == "forof" and ce["it"] is None:
        return None
    if k == "write" and c not in ("arr", "map", "rec", "set"):
        return None
    if k == "ident" and e not in ("cls", "iface", "lit"):
        return None
    opt = "?" if ce.get("optional") else ""
    some = f'{{ readonly tag: "some"; readonly value{opt}: {ce["ft"]} }}'
    if w == "u":
        wdecl = f'type W<T> = {some} | {{ readonly tag: "none" }};'
        narrow = '{o}.tag === "some"'
    elif w == "s":
        wdecl = f"type W<T> = {some};"
        narrow = '{o}.tag === "some"'
    elif w == "un":
        wdecl = f"type W<T> = {some} | undefined;"
        narrow = "{o} !== undefined"
    else:
        wdecl = f'interface W<T> {{ readonly tag: "some"; readonly value{opt}: {ce["ft"]} }}'
        narrow = '{o}.tag === "some"'
    if ce.get("getter"):
        made = '{ tag: "some", get value() { return x; } }'
    else:
        made = f'{{ tag: "some", value: {ce["mk"]} }}'
    if w == "un" or w == "s" or w == "i":
        pass
    ET = ee["t"]
    X = ee["x"]
    CT = subst_t(ce["ft"], ET)  # the container's type for E
    lines = []
    lines.append(f"// H09b2 matrix: producer={p} container={c} element={e} wrapper={w} consumer={k}")
    lines.append("class Pt {\n  constructor(public x: number) {}\n}")
    lines.append("class Box<T> {\n  constructor(public v: T) {}\n}")
    lines.append("interface IP {\n  x: number;\n}")
    lines.append("const seven8: u8 = 7;\nconst sevenI: int = 7;")
    lines.append("const pt = new Pt(7);\nconst ip: IP = { x: 7 };\nconst lit: { x: number; y: string } = { x: 7, y: \"q\" };")
    lines.append(wdecl)
    lines.append(f"const use = (v: {ET}): string => {ee['use']};")
    # the makers
    lines.append(
        "const Ops = {\n"
        f"  mk<T>(x: T): W<T> {{\n    return {made};\n  }},\n"
        f"  take<T>(w: W<T>, f: (t: T) => string): string {{\n    if ({narrow.format(o='w')}) {{\n      return f({ce['rd'].format(V='w.value')});\n    }}\n    return \"none\";\n  }},\n"
        "};"
    )
    if p == "opt":
        lines.append("const maybeOps: typeof Ops | undefined = Math.random() > 2 ? undefined : Ops;")
    if p in ("union", "unionany"):
        lines.append(
            "interface MA {\n  mk<T>(x: T): W<T>;\n  a(): number;\n}\n"
            "interface MB {\n  mk<T>(x: T): W<T>;\n  b(): number;\n}\n"
            f"class CA implements MA {{\n  mk<T>(x: T): W<T> {{\n    return {made};\n  }}\n  a(): number {{\n    return 1;\n  }}\n}}\n"
            f"class CB implements MB {{\n  mk<T>(x: T): W<T> {{\n    return {made};\n  }}\n  b(): number {{\n    return 2;\n  }}\n}}\n"
            "function pick(n: number): MA | MB {\n  return n === 0 ? new CA() : new CB();\n}"
        )
    if p in ("iface", "ifaceany", "ifaceelem", "clsany"):
        lines.append(
            "interface Maker {\n  mk<T>(x: T): W<T>;\n}\n"
            f"class MakerC implements Maker {{\n  mk<T>(x: T): W<T> {{\n    return {made};\n  }}\n}}\n"
            "const mi: Maker = new MakerC();"
        )
    if p == "arrowmap":
        lines.append(f"const mkA = <T>(x: T): W<T> => ({made});")
    if p == "fnany":
        lines.append(f"function mkF<T>(x: T): W<T> {{\n  return {made};\n}}")
    if p in ("anyarg", "unionany", "ifaceany", "fnany", "clsany"):
        lines.append(f"const raw: any = {X};")
    if p == "lie":
        lines.append(f"const rawLie: any = {ee['lie']};")
    if p == "dyn":
        lines.append("const anyOps: any = Ops;")
    prod = {
        "dot": f"Ops.mk({X})",
        "elem": f'Ops["mk"]({X})',
        "opt": f"maybeOps?.mk({X})!",
        "mval": None,
        "anyarg": f"Ops.mk<{ET}>(raw)",
        "json": f"Ops.mk<{ET}>(JSON.parse({ee['json']!r}))" if ee["json"] else None,
        "arrowmap": f"[{X}].map(mkA)[0]",
        "union": f"pick(0).mk({X})",
        "unionany": f"pick(0).mk<{ET}>(raw)",
        "iface": f"mi.mk({X})",
        "ifaceany": f"mi.mk<{ET}>(raw)",
        "ifaceelem": f'mi["mk"]({X})',
        "dyn": f"anyOps.mk({X})",
        "lie": f"Ops.mk<{ET}>(rawLie)",
        "fnany": f"mkF<{ET}>(raw)",
        "clsany": f"new MakerC().mk<{ET}>(raw)",
    }[p]
    if p == "mval":
        lines.append("const mkv = Ops.mk;")
        prod = f"mkv({X})"
    if p == "json":
        js = ee["json"].replace("\\", "\\\\").replace("'", "\\'")
        prod = f"Ops.mk<{ET}>(JSON.parse('{js}'))"
    if p == "arrowmap" and w == "un":
        pass
    lines.append(f"const o: W<{ET}> = {prod};")
    rd = lambda v: ce["rd"].format(V=v)
    no = narrow.format(o="o")
    body = []
    if k == "read":
        body.append(f'if ({no}) {{\n    return use({rd("o.value")});\n  }}\n  return "none";')
    elif k == "destr":
        body.append(f'if ({no}) {{\n    const {{ value }} = o;\n    return use({rd("value")});\n  }}\n  return "none";')
    elif k == "spread":
        body.append(f'if ({no}) {{\n    const c = {{ ...o }};\n    return use({rd("c.value")});\n  }}\n  return "none";')
    elif k == "param":
        lines.append(f'function take(w: W<{ET}>): string {{\n  if ({narrow.format(o="w")}) {{\n    return use({rd("w.value")});\n  }}\n  return "none";\n}}')
        body.append("return take(o);")
    elif k == "ginst":
        lines.append(f'function takeG<T>(w: W<T>, f: (t: T) => string): string {{\n  if ({narrow.format(o="w")}) {{\n    return f({rd("w.value")});\n  }}\n  return "none";\n}}')
        body.append("return takeG(o, use);")
    elif k == "minst":
        body.append("return Ops.take(o, use);")
    elif k == "iface":
        lines.append(f"interface HasV {{\n  readonly value{opt}: {CT};\n}}")
        body.append(f'if ({no}) {{\n    const h: HasV = o;\n    return use({rd("h.value")});\n  }}\n  return "none";')
    elif k == "log":
        body.append('console.log("L", o);\n  return "logged";')
    elif k == "forof":
        body.append(f'let r = "empty";\n  if ({no}) {{\n    for (const e of {ce["it"].format(V="o.value")}) {{\n      r = use(e);\n    }}\n  }}\n  return r;')
    elif k == "json":
        body.append("return JSON.stringify(o);")
    elif k == "ret":
        optu = " | undefined" if ce.get("optional") else ""
        lines.append(f"function getV(w: W<{ET}>): ({CT}){optu} | undefined {{\n  return {narrow.format(o='w')} ? w.value : undefined;\n}}")
        body.append(f'const got = getV(o);\n  return got === undefined ? "none" : use({rd("got")});')
    elif k == "ident":
        body.append(f'if ({no}) {{\n    return String({rd("o.value")} === {X});\n  }}\n  return "none";')
    elif k == "write":
        w2 = {"arr": "o.value.push({X}); return String(o.value.length) + use(o.value[1]);",
              "map": 'o.value.set("j", {X}); return String(o.value.size) + use(o.value.get("j")!);',
              "rec": 'o.value["j"] = {X}; return String(Object.keys(o.value).length) + use(o.value["j"]);',
              "set": "o.value.add({X}); return String(o.value.size);"}[c].format(X=X)
        body.append(f'if ({no}) {{\n    {w2}\n  }}\n  return "none";')
    lines.append("function result(): string {\n  " + "\n".join(body) + "\n}")
    lines.append('try {\n  console.log("R", result());\n} catch (e: any) {\n  console.log("R", e.name, e.message);\n}')
    return "\n".join(lines) + "\n"


def cases():
    seen = set()

    def add(p, c, e, w, k):
        key = (p, c, e, w, k)
        if key not in seen:
            seen.add(key)
            yield key

    for p in P:  # A: every producer and container
        for c in C:
            yield from add(p, c, "num", "u", "read")
    for c in C:  # B: every container and element
        for e in E:
            yield from add("elem", c, e, "u", "read")
    for k in K:  # C: every consumer and container
        for c in C:
            e = "iface" if k == "ident" else "num"
            yield from add("elem", c, e, "u", k)
    for w in W:  # D: every wrapper and container
        for c in C:
            yield from add("elem", c, "num", w, "read")
    for e in E:  # E: lies
        for c in ("arr", "direct", "nest", "map"):
            yield from add("lie", c, e, "u", "read")
    for e in E:  # F: checked conversions of a dynamic result
        yield from add("dyn", "arr", e, "u", "read")
        yield from add("dyn", "direct", e, "u", "read")
    for p in ("elem", "opt", "mval", "anyarg", "arrowmap", "unionany", "dyn", "lie"):  # G: producers and consumers
        for k in K:
            e = "iface" if k == "ident" else "num"
            yield from add(p, "arr", e, "u", k)


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    n = 0
    for p, c, e, w, k in cases():
        text = program(p, c, e, w, k)
        if text is None:
            continue
        name = f"{p}__{c}__{e}__{w}__{k}.pts"
        with open(os.path.join(out, name), "w") as f:
            f.write(text)
        n += 1
    print(n, "cases")


if __name__ == "__main__":
    main()
