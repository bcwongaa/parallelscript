// .par over an array an erased copy made (its any[] held as number[]), and a .par callback
// reading the erased copy's objects typed. Node twin: q06_par_callbacks.node.mts (. -> .).
type Opt<T> = { readonly tag: "some"; readonly value: T[] } | { readonly tag: "none" };
const Ops = {
  mk<T>(x: T): Opt<T> {
    return { tag: "some", value: [x, x, x] };
  },
};
const o: Opt<number> = Ops["mk"](7);
if (o.tag === "some") {
  console.log("par map", o.value.map((v) => v * 2).join(","));
  console.log("par reduce", o.value.reduce((a, b) => a + b, 0));
}
