| class | head | protoA | protoB | protoAB | protoAB2 |
|---|---|---|---|---|---|
| CRASH | 8 | 0 | 0 | 0 | 0 |
| DIAG | 23 | 23 | 23 | 23 | 23 |
| ERRDIFF | 2 | 4 | 4 | 4 | 4 |
| MISREAD | 165 | 0 | 9 | 9 | 1 |
| OK | 247 | 412 | 408 | 408 | 419 |
| OTHER | 9 | 9 | 9 | 9 | 9 |
| TYPEERR | 113 | 119 | 114 | 114 | 111 |
