counts: {'DIAG': 23, 'ERRDIFF': 4, 'OK': 412, 'OTHER': 9, 'TYPEERR': 119} total 567

### P x C (E=num, W=u, K=read)

| P \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| anyarg | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| arrowmap | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| clsany | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| dot | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| dyn | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| elem | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| fnany | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| iface | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| ifaceany | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| ifaceelem | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| json | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| lie | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE |
| mval | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| opt | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| union | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| unionany | ok | TE | ok | ok | ok | TE | TE | ok | ok | ok | TE | ok |

### C x E (P=elem, W=u, K=read)

| C \ E | bool | cls | iface | int | lit | num | str | u8 |
|---|---|---|---|---|---|---|---|---|
| arr | ok | ok | ok | ok | ok | ok | ok | ok |
| box | TE | TE | TE | TE | TE | TE | TE | TE |
| direct | ok | ok | ok | ok | ok | ok | ok | ok |
| fn | ok | ok | ok | ok | ok | ok | ok | ok |
| getter | ok | ok | ok | ok | ok | ok | ok | ok |
| map | TE | TE | TE | diag | TE | TE | TE | diag |
| nest | ok | ok | ok | ok | ok | ok | ok | ok |
| opt | ok | ok | ok | ok | ok | ok | ok | ok |
| orund | ok | ok | ok | ok | ok | ok | ok | ok |
| rec | ok | ok | ok | ok | ok | ok | ok | ok |
| set | TE | TE | TE | TE | TE | TE | TE | TE |
| tup | ok | ok | ok | ok | ok | ok | ok | ok |

### K x C (P=elem, E=num, W=u)

| K \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| destr | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| forof | ok |  |  |  |  | TE |  |  |  | ok | TE | ok |
| ginst | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| iface | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| json | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| log | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| minst | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| param | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| read | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| ret | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| spread | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag |
| write | TE |  |  |  |  | TE |  |  |  | TE | TE |  |

### W x C (P=elem, E=num, K=read)

| W \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| i | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |
| s | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |
| u | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| un | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |

### E x C (P=lie, W=u, K=read)

| E \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bool | TE |  | TE |  |  | TE | TE |  |  |  |  |  |
| cls | TE |  | TE |  |  | TE | TE |  |  |  |  |  |
| iface | TE |  | TE |  |  | TE | TE |  |  |  |  |  |
| int | TE |  | TE |  |  | diag | TE |  |  |  |  |  |
| lit | TE |  | TE |  |  | TE | TE |  |  |  |  |  |
| num | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE | TE |
| str | errdiff |  | errdiff |  |  | errdiff | errdiff |  |  |  |  |  |
| u8 | TE |  | TE |  |  | diag | TE |  |  |  |  |  |

### E x C (P=dyn, W=u, K=read)

| E \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bool | ok |  | ok |  |  |  |  |  |  |  |  |  |
| cls | ok |  | ok |  |  |  |  |  |  |  |  |  |
| iface | ok |  | ok |  |  |  |  |  |  |  |  |  |
| int | ok |  | ok |  |  |  |  |  |  |  |  |  |
| lit | ok |  | ok |  |  |  |  |  |  |  |  |  |
| num | ok | TE | ok | ok | ok | TE | ok | ok | ok | ok | TE | ok |
| str | ok |  | ok |  |  |  |  |  |  |  |  |  |
| u8 | ok |  | ok |  |  |  |  |  |  |  |  |  |

### P x K (C=arr, W=u)

| P \ K | destr | forof | ginst | ident | iface | json | log | minst | param | read | ret | spread | write |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| anyarg | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |
| arrowmap | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | ok |
| clsany |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| dot |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| dyn | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |
| elem | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |
| fnany |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| iface |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| ifaceany |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| ifaceelem |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| json |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| lie | TE | TE | TE | TE | TE | ok | ok | TE | TE | TE/errdiff | TE | diag | TE |
| mval | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |
| opt | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |
| union |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| unionany | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | TE |

### changed against matrix/head.json 

- anyarg__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- anyarg__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- anyarg__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- anyarg__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- anyarg__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- anyarg__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- anyarg__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- anyarg__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- anyarg__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- anyarg__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- anyarg__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- anyarg__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- dyn__arr__int__u__read: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- dyn__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- dyn__arr__u8__u__read: MISREAD -> OK  pts: 'R 8'
- dyn__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- dyn__direct__bool__u__read: TYPEERR -> OK  pts: 'R truefalse'
- dyn__direct__cls__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__direct__iface__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__direct__int__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__direct__lit__u__read: TYPEERR -> OK  pts: 'R q14'
- dyn__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__direct__str__u__read: TYPEERR -> OK  pts: 'R AB'
- dyn__direct__u8__u__read: TYPEERR -> OK  pts: 'R 8'
- dyn__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- dyn__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- dyn__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- dyn__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- dyn__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- dyn__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- elem__arr__int__u__read: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- elem__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- elem__arr__u8__u__read: MISREAD -> OK  pts: 'R 8'
- elem__box__bool__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<boolean>: it is declared Box<any>'
- elem__box__cls__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<Pt>: it is declared Box<any>'
- elem__box__iface__u__ident: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<IP>: it is declared Box<any>'
- elem__box__iface__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<IP>: it is declared Box<any>'
- elem__box__int__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<int>: it is declared Box<any>'
- elem__box__lit__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<{ x: number; y: string; }>: it is declared Box<any>'
- elem__box__num__u__destr: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- elem__box__num__u__ginst: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- elem__box__num__u__iface: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- elem__box__num__u__param: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- elem__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- elem__box__str__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<string>: it is declared Box<any>'
- elem__box__u8__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<u8>: it is declared Box<any>'
- elem__direct__bool__u__read: TYPEERR -> OK  pts: 'R truefalse'
- elem__direct__cls__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__direct__iface__u__ident: TYPEERR -> OK  pts: 'R true'
- elem__direct__iface__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__direct__int__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__direct__lit__u__read: TYPEERR -> OK  pts: 'R q14'
- elem__direct__num__u__destr: TYPEERR -> OK  pts: 'R 14'
- elem__direct__num__u__ginst: TYPEERR -> OK  pts: 'R 14'
- elem__direct__num__u__iface: TYPEERR -> OK  pts: 'R 14'
- elem__direct__num__u__param: TYPEERR -> OK  pts: 'R 14'
- elem__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__direct__num__u__ret: TYPEERR -> OK  pts: 'R 14'
- elem__direct__str__u__read: TYPEERR -> OK  pts: 'R AB'
- elem__direct__u8__u__read: TYPEERR -> OK  pts: 'R 8'
- elem__fn__int__u__read: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__destr: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__iface: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__param: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- elem__fn__num__u__ret: MISREAD -> OK  pts: 'R 14'
- elem__fn__u8__u__read: MISREAD -> OK  pts: 'R 8'
- elem__getter__bool__u__read: TYPEERR -> OK  pts: 'R truefalse'
- elem__getter__cls__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__getter__iface__u__ident: TYPEERR -> OK  pts: 'R true'
- elem__getter__iface__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__getter__int__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__getter__lit__u__read: TYPEERR -> OK  pts: 'R q14'
- elem__getter__num__u__destr: TYPEERR -> OK  pts: 'R 14'
- elem__getter__num__u__ginst: TYPEERR -> OK  pts: 'R 14'
- elem__getter__num__u__iface: TYPEERR -> OK  pts: 'R 14'
- elem__getter__num__u__param: TYPEERR -> OK  pts: 'R 14'
- elem__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__getter__num__u__ret: TYPEERR -> OK  pts: 'R 14'
- elem__getter__str__u__read: TYPEERR -> OK  pts: 'R AB'
- elem__getter__u8__u__read: TYPEERR -> OK  pts: 'R 8'
- elem__map__bool__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, boolean>: it is declared Map<string, value>'
- elem__map__cls__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, Pt>: it is declared Map<string, value>'
- elem__map__iface__u__ident: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, {x: number}>: it is declared Map<string, value>'
- elem__map__iface__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, {x: number}>: it is declared Map<string, value>'
- elem__map__lit__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, {x: number; y: string}>: it is declared Map<string, valu'
- elem__map__num__u__destr: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__forof: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__ginst: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__iface: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__param: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__ret: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__num__u__write: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- elem__map__str__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, string>: it is declared Map<string, value>'
- elem__nest__bool__u__read: TYPEERR -> OK  pts: 'R truefalse'
- elem__nest__cls__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__nest__iface__u__ident: TYPEERR -> OK  pts: 'R true'
- elem__nest__iface__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__nest__int__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__nest__lit__u__read: TYPEERR -> OK  pts: 'R q14'
- elem__nest__num__u__destr: TYPEERR -> OK  pts: 'R 14'
- elem__nest__num__u__ginst: TYPEERR -> OK  pts: 'R 14'
- elem__nest__num__u__iface: TYPEERR -> OK  pts: 'R 14'
- elem__nest__num__u__param: TYPEERR -> OK  pts: 'R 14'
- elem__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__nest__num__u__ret: TYPEERR -> OK  pts: 'R 14'
- elem__nest__str__u__read: TYPEERR -> OK  pts: 'R AB'
- elem__nest__u8__u__read: TYPEERR -> OK  pts: 'R 8'
- elem__opt__bool__u__read: TYPEERR -> OK  pts: 'R truefalse'
- elem__opt__cls__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__opt__iface__u__ident: TYPEERR -> OK  pts: 'R true'
- elem__opt__iface__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__opt__int__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__opt__lit__u__read: TYPEERR -> OK  pts: 'R q14'
- elem__opt__num__u__destr: TYPEERR -> OK  pts: 'R 14'
- elem__opt__num__u__ginst: TYPEERR -> OK  pts: 'R 14'
- elem__opt__num__u__iface: TYPEERR -> OK  pts: 'R 14'
- elem__opt__num__u__param: TYPEERR -> OK  pts: 'R 14'
- elem__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- elem__opt__num__u__ret: TYPEERR -> OK  pts: 'R 14'
- elem__opt__str__u__read: TYPEERR -> OK  pts: 'R AB'
- elem__opt__u8__u__read: TYPEERR -> OK  pts: 'R 8'
- elem__rec__int__u__read: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__destr: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__forof: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__iface: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__param: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__ret: MISREAD -> OK  pts: 'R 14'
- elem__rec__num__u__write: OK -> TYPEERR  pts: "R RangeError Object has no property 'j'; if it may be missing, read it with `?? fallback`, give the value type `| undefi"
- elem__rec__u8__u__read: MISREAD -> OK  pts: 'R 8'
- elem__set__bool__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<boolean>: it is declared Set<value>'
- elem__set__cls__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<Pt>: it is declared Set<value>'
- elem__set__iface__u__ident: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<{x: number}>: it is declared Set<value>'
- elem__set__iface__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<{x: number}>: it is declared Set<value>'
- elem__set__int__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<i64>: it is declared Set<value>'
- elem__set__lit__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<{x: number; y: string}>: it is declared Set<value>'
- elem__set__num__u__destr: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__forof: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__ginst: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__iface: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__param: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__ret: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__num__u__write: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- elem__set__str__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<string>: it is declared Set<value>'
- elem__set__u8__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<u8>: it is declared Set<value>'
- elem__tup__bool__u__read: MISREAD -> OK  pts: 'R truefalse'
- elem__tup__int__u__read: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__destr: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__forof: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__iface: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__param: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- elem__tup__num__u__ret: MISREAD -> OK  pts: 'R 14'
- elem__tup__u8__u__read: MISREAD -> OK  pts: 'R 8'
- ifaceany__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceany__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- ifaceany__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceany__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceany__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceany__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- ifaceany__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceany__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceany__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceany__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- ifaceany__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceelem__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceelem__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- ifaceelem__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceelem__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceelem__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceelem__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- ifaceelem__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceelem__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- ifaceelem__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- ifaceelem__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- ifaceelem__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- json__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- json__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- json__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- json__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- json__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- json__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- json__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- json__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- json__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- json__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- json__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- lie__arr__bool__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as boolean[]: it is declared value[]'
- lie__arr__cls__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Pt[]: it is declared value[]'
- lie__arr__iface__u__ident: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as {x: number}[]: it is declared value[]'
- lie__arr__iface__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as {x: number}[]: it is declared value[]'
- lie__arr__int__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as i64[]: it is declared value[]'
- lie__arr__lit__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as {x: number; y: string}[]: it is declared value[]'
- lie__arr__num__u__destr: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__forof: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__ginst: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__iface: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__param: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__ret: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__num__u__write: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number[]: it is declared value[]'
- lie__arr__str__u__read: CRASH -> ERRDIFF  pts: 'R TypeError Cannot read property value of Object as string[]: it is declared value[]'
- lie__arr__u8__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as u8[]: it is declared value[]'
- lie__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- lie__fn__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Expected number, got string'
- lie__map__bool__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, boolean>: it is declared Map<string, value>'
- lie__map__cls__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, Pt>: it is declared Map<string, value>'
- lie__map__iface__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, {x: number}>: it is declared Map<string, value>'
- lie__map__lit__u__read: CRASH -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, {x: number; y: string}>: it is declared Map<string, valu'
- lie__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- lie__map__str__u__read: CRASH -> ERRDIFF  pts: 'R TypeError Cannot read property value of Object as Map<string, string>: it is declared Map<string, value>'
- lie__orund__num__u__read: OK -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as number | undefined: it is declared value'
- lie__rec__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Record<string, number>: it is declared Record<string, value>'
- lie__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- lie__tup__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as [number, number]: it is declared [value, value]'
- mval__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- mval__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- mval__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- mval__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- mval__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- mval__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- mval__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- mval__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- mval__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- mval__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- mval__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- mval__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- opt__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- opt__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- opt__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- opt__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- opt__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- opt__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- opt__nest__num__u__read: TYPEERR -> OK  pts: 'R 14'
- opt__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- opt__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- opt__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- opt__tup__num__u__read: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__destr: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__forof: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__ginst: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__iface: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__param: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__read: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__ret: MISREAD -> OK  pts: 'R 14'
- unionany__arr__num__u__write: OK -> TYPEERR  pts: 'R RangeError Array index 1 is out of range (length 1); if it may be missing, read it with `?? fallback`, give the elemen'
- unionany__box__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Box<number>: it is declared Box<any>'
- unionany__direct__num__u__read: TYPEERR -> OK  pts: 'R 14'
- unionany__fn__num__u__read: MISREAD -> OK  pts: 'R 14'
- unionany__getter__num__u__read: TYPEERR -> OK  pts: 'R 14'
- unionany__map__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Map<string, number>: it is declared Map<string, value>'
- unionany__opt__num__u__read: TYPEERR -> OK  pts: 'R 14'
- unionany__rec__num__u__read: MISREAD -> OK  pts: 'R 14'
- unionany__set__num__u__read: MISREAD -> TYPEERR  pts: 'R TypeError Cannot read property value of Object as Set<number>: it is declared Set<value>'
- unionany__tup__num__u__read: MISREAD -> OK  pts: 'R 14'

moves: {('MISREAD', 'OK'): 100, ('OK', 'TYPEERR'): 29, ('MISREAD', 'TYPEERR'): 65, ('TYPEERR', 'OK'): 94, ('CRASH', 'TYPEERR'): 6, ('CRASH', 'ERRDIFF'): 2}
