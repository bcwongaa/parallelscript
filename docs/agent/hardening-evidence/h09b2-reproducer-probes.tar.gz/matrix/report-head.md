counts: {'CRASH': 8, 'DIAG': 23, 'ERRDIFF': 2, 'MISREAD': 165, 'OK': 247, 'OTHER': 9, 'TYPEERR': 113} total 567

### P x C (E=num, W=u, K=read)

| P \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| anyarg | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| arrowmap | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| clsany | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| dot | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| dyn | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| elem | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| fnany | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| iface | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| ifaceany | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| ifaceelem | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| json | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| lie | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| mval | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| opt | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| union | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| unionany | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |

### C x E (P=elem, W=u, K=read)

| C \ E | bool | cls | iface | int | lit | num | str | u8 |
|---|---|---|---|---|---|---|---|---|
| arr | ok | ok | ok | MIS | ok | MIS | ok | MIS |
| box | ok | ok | ok | MIS | ok | MIS | ok | MIS |
| direct | TE | TE | TE | TE | TE | TE | TE | TE |
| fn | ok | ok | ok | MIS | ok | MIS | ok | MIS |
| getter | TE | TE | TE | TE | TE | TE | TE | TE |
| map | ok | ok | ok | diag | ok | MIS | ok | diag |
| nest | TE | TE | TE | TE | TE | TE | TE | TE |
| opt | TE | TE | TE | TE | TE | TE | TE | TE |
| orund | ok | ok | ok | ok | ok | ok | ok | ok |
| rec | ok | ok | ok | MIS | ok | MIS | ok | MIS |
| set | ok | ok | ok | MIS | ok | MIS | ok | MIS |
| tup | MIS | ok | ok | MIS | ok | MIS | ok | MIS |

### K x C (P=elem, E=num, W=u)

| K \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| destr | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| forof | MIS |  |  |  |  | MIS |  |  |  | MIS | MIS | MIS |
| ginst | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| iface | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| json | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| log | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| minst | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok |
| param | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| read | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| ret | MIS | TE | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| spread | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag | diag |
| write | ok |  |  |  |  | ok |  |  |  | ok | MIS |  |

### W x C (P=elem, E=num, K=read)

| W \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| i | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |
| s | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |
| u | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| un | ok | other | ok | ok | ok | other | ok | ok | ok | ok | other | ok |

### E x C (P=lie, W=u, K=read)

| E \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bool | MIS |  | TE |  |  | MIS | TE |  |  |  |  |  |
| cls | CRASH |  | TE |  |  | CRASH | TE |  |  |  |  |  |
| iface | CRASH |  | TE |  |  | CRASH | TE |  |  |  |  |  |
| int | MIS |  | TE |  |  | diag | TE |  |  |  |  |  |
| lit | CRASH |  | TE |  |  | CRASH | TE |  |  |  |  |  |
| num | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| str | CRASH |  | errdiff |  |  | CRASH | errdiff |  |  |  |  |  |
| u8 | MIS |  | TE |  |  | diag | TE |  |  |  |  |  |

### E x C (P=dyn, W=u, K=read)

| E \ C | arr | box | direct | fn | getter | map | nest | opt | orund | rec | set | tup |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| bool | ok |  | TE |  |  |  |  |  |  |  |  |  |
| cls | ok |  | TE |  |  |  |  |  |  |  |  |  |
| iface | ok |  | TE |  |  |  |  |  |  |  |  |  |
| int | MIS |  | TE |  |  |  |  |  |  |  |  |  |
| lit | ok |  | TE |  |  |  |  |  |  |  |  |  |
| num | MIS | MIS | TE | MIS | TE | MIS | TE | TE | ok | MIS | MIS | MIS |
| str | ok |  | TE |  |  |  |  |  |  |  |  |  |
| u8 | MIS |  | TE |  |  |  |  |  |  |  |  |  |

### P x K (C=arr, W=u)

| P \ K | destr | forof | ginst | ident | iface | json | log | minst | param | read | ret | spread | write |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| anyarg | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | MIS | MIS | diag | ok |
| arrowmap | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | ok | diag | ok |
| clsany |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| dot |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| dyn | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | ok/MIS | MIS | diag | ok |
| elem | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | ok/MIS | MIS | diag | ok |
| fnany |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| iface |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| ifaceany |  |  |  |  |  |  |  |  |  | MIS |  |  |  |
| ifaceelem |  |  |  |  |  |  |  |  |  | MIS |  |  |  |
| json |  |  |  |  |  |  |  |  |  | MIS |  |  |  |
| lie | MIS | MIS | MIS | ok | MIS | ok | ok | TE | MIS | MIS/CRASH | MIS | diag | ok |
| mval | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | MIS | MIS | diag | ok |
| opt | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | MIS | MIS | diag | ok |
| union |  |  |  |  |  |  |  |  |  | ok |  |  |  |
| unionany | MIS | MIS | MIS | ok | MIS | ok | ok | ok | MIS | MIS | MIS | diag | ok |

### changed against matrix/head.json 


moves: {}
