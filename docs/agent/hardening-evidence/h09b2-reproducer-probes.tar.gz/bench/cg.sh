#!/bin/bash
# cg.sh BINARY... : callgrind instruction counts at N=100000 and N=200000 (PTS_THREADS=1), and the per-iteration difference.
for bin in "$@"; do
  for n in 100000 200000; do
    PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=/tmp/h09b2/repro/bench/cg.$(basename "$bin").$n.out "$bin" "$n" > /dev/null 2> /tmp/h09b2/repro/bench/cg.$(basename "$bin").$n.log
    ir=$(grep -o "Collected : [0-9]*" /tmp/h09b2/repro/bench/cg.$(basename "$bin").$n.log | grep -o "[0-9]*")
    eval "ir_$n=$ir"
  done
  echo "$(basename "$bin") N=100000 Ir=$ir_100000 N=200000 Ir=$ir_200000 per-iteration=$(( (ir_200000 - ir_100000) / 100000 ))"
done
