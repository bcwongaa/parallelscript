// Command irdump prints the lowered IR of a .pts program, or its compile errors, for H04
// probing without clang: go run ./h04-probes/irdump [-c] file.pts...
// With -c it also emits the C (as pts emit-c does) and prints only "C ok (N bytes)", so a
// panic in the C emitter shows too. Each file's panic is printed and the next file runs.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"runtime/debug"

	"github.com/microsoft/typescript-go/internal/vfs/osvfs"
	"github.com/microsoft/typescript-go/pts/cgen"
	"github.com/microsoft/typescript-go/pts/check"
	"github.com/microsoft/typescript-go/pts/diagnostic"
	"github.com/microsoft/typescript-go/pts/frontend"
	"github.com/microsoft/typescript-go/pts/lower"
)

var compilerFrame = regexp.MustCompile(`/(pts/(?:check|lower|cgen|ir|frontend|driver)/[a-z_]+\.go:\d+)`)

func main() {
	emitC := flag.Bool("c", false, "emit C instead of printing the IR")
	flag.Parse()
	for _, file := range flag.Args() {
		fmt.Printf("== %s\n", filepath.Base(file))
		dump(file, *emitC)
	}
}

func dump(file string, emitC bool) {
	defer func() {
		if r := recover(); r != nil {
			fmt.Printf("PANIC %v\n", r)
			for _, frame := range compilerFrame.FindAllStringSubmatch(string(debug.Stack()), 5) {
				fmt.Printf("  %s\n", frame[1])
			}
		}
	}()
	entry, err := filepath.Abs(file)
	if err != nil {
		panic(err)
	}
	ctx := context.Background()
	program, errors := frontend.Load(ctx, osvfs.FS(), entry)
	if len(errors) > 0 {
		report(errors, entry)
		return
	}
	info, errors := check.Program(ctx, program)
	if len(errors) > 0 {
		report(errors, entry)
		return
	}
	lowered, errors := lower.Program(ctx, program, info)
	if len(errors) > 0 {
		report(errors, entry)
		return
	}
	if !emitC {
		fmt.Print(lowered.String())
		return
	}
	c := cgen.Emit(lowered)
	fmt.Printf("C ok (%d bytes)\n", len(c))
	if out := os.Getenv("IRDUMP_C_DIR"); out != "" {
		if err := os.WriteFile(filepath.Join(out, filepath.Base(entry)+".c"), []byte(c), 0o644); err != nil {
			panic(err)
		}
	}
}

func report(errors []diagnostic.Diagnostic, entry string) {
	for _, d := range errors {
		fmt.Println(d.Format(filepath.Dir(entry)))
	}
}
