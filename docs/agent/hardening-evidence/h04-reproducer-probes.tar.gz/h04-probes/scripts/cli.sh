#!/usr/bin/env bash
# cli.sh : how each pts command behaves on a compiler panic (the C34 probe), and the usage exit code.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52
PTS=$WT/pts-bin/pts
mkdir -p /tmp/h04/cli
cp /tmp/h04/a/c34.pts /tmp/h04/cli/c34.pts
cp /tmp/h04/a/c34.pts /tmp/h04/cli/c34.test.pts
cd /tmp/h04/cli || exit 1
for cmd in "run c34.pts" "build c34.pts -o c34.exe" "emit-c c34.pts -o c34.c" "test c34.test.pts"; do
  # shellcheck disable=SC2086
  PTS_HOME=$WT "$PTS" $cmd > out.txt 2> err.txt
  echo "pts $cmd -> exit=$? stdout_lines=$(wc -l < out.txt) stderr_lines=$(wc -l < err.txt) first_stderr: $(head -1 err.txt) | $(grep -m1 'pts/lower' err.txt | sed 's/^[[:space:]]*//')"
done
PTS_HOME=$WT "$PTS" frobnicate > out.txt 2> err.txt
echo "pts frobnicate -> exit=$? first_stderr: $(head -1 err.txt)"
