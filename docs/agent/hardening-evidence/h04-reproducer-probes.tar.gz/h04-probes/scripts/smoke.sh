#!/usr/bin/env bash
# smoke.sh label [VAR=value...] : run TestCompilerFailsCleanly in the worktree with the given
# PTS_SMOKE_* settings (2 procs), log to /tmp/h04/logs/smoke-<label>.log, print a summary.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52
label=$1
shift
log=/tmp/h04/logs/smoke-$label.log
mkdir -p /tmp/h04/logs
cd "$WT" || exit 1
echo "\$ env $* GOMAXPROCS=2 go test ./pts/tests/ -run 'TestCompilerFailsCleanly' -count=1 -v"
start=$(date +%s)
env "$@" GOMAXPROCS=2 go test -p 1 ./pts/tests/ -run 'TestCompilerFailsCleanly$' -count=1 -v -timeout 120m > "$log" 2>&1
code=$?
end=$(date +%s)
grep -E 'compiled [0-9]+ programs|programs failed|^--- |^    --- |^\s+--- ' "$log" | head -n "${SHOW_LINES:-60}"
echo "wall $((end - start))s; go test exit=$code; log $log"
