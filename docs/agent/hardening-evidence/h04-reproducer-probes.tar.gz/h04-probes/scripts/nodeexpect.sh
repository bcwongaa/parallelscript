#!/usr/bin/env bash
# nodeexpect.sh test.pts... : run each test under Node as the differential test does and diff
# Node's stdout against the test's // expect: block.
NODE=/home/bryan/.local/node/bin/node
for f in "$@"; do
  base=$(basename "$f" .pts)
  tmp=$(mktemp -d /tmp/h04/node.XXXX)
  cp "$f" "$tmp/$base.mts"
  (cd "$tmp" && timeout 60 "$NODE" --no-warnings --experimental-transform-types "$base.mts" > "$tmp/node.out" 2> "$tmp/node.err")
  code=$?
  awk '/^\/\/ expect:$/ { on = 1; next } on && /^\/\/( |$)/ { sub(/^\/\/ ?/, ""); print; next } on { exit }' "$f" > "$tmp/expect.out"
  if cmp -s "$tmp/node.out" "$tmp/expect.out"; then
    echo "$base: node exit=$code, matches // expect:"
  else
    echo "$base: node exit=$code, DIFFERS from // expect: (< node, > expect)"
    diff "$tmp/node.out" "$tmp/expect.out"
    head -5 "$tmp/node.err"
  fi
  rm -rf "$tmp"
done
