#!/usr/bin/env bash
# split.sh bundle dir : split a bundle of probes into dir; each starts with a line "//// name.pts".
bundle=$1
dir=$2
mkdir -p "$dir"
awk -v dir="$dir" '
  /^\/\/\/\/ / { file = dir "/" $2; printf "" > file; next }
  file != "" { print >> file }
' "$bundle"
