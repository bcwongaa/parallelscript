#!/usr/bin/env bash
# classify.sh file.pts... : run each probe under pts (worktree build) and Node, and print one
# compact verdict: PANIC (first pts frame), CLANG (first clang error), DIAG (pts diagnostic),
# WRONG (stdout or exit differs from Node), OK. Full outputs go next to the probe as .pts.out / .node.out.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52
PTS=${PTS:-$WT/pts-bin/pts}
NODE=/home/bryan/.local/node/bin/node
for f in "$@"; do
  dir=$(dirname "$f")
  base=$(basename "$f" .pts)
  (cd "$dir" && PTS_HOME=$WT timeout 60 "$PTS" run "$base.pts" > "$base.pts.stdout" 2> "$base.pts.stderr")
  code=$?
  tmp=$(mktemp -d /tmp/h04/node.XXXX)
  cp "$f" "$tmp/$base.mts"
  (cd "$tmp" && timeout 60 "$NODE" --no-warnings --experimental-transform-types "$base.mts" > "$dir/$base.node.stdout" 2> "$dir/$base.node.stderr")
  ncode=$?
  rm -rf "$tmp"
  err="$dir/$base.pts.stderr"
  if grep -q '^panic: \|^goroutine ' "$err"; then
    verdict="PANIC $(grep -m1 '^panic: ' "$err") @ $(grep -m1 -A1 'pts/\(lower\|cgen\|check\|driver\|frontend\)' "$err" | grep -m1 -o 'pts/[a-z]*/[a-z_]*\.go:[0-9]*')"
  elif grep -q ': error: ' "$err" && grep -q '^pts: clang' "$err"; then
    verdict="CLANG $(grep -m1 ': error: ' "$err" | sed 's/^[^ ]*: error: //')"
  elif grep -q ' - error ' "$err"; then
    verdict="DIAG $(grep -m1 ' - error ' "$err")"
  elif [ "$code" = "$ncode" ] && cmp -s "$dir/$base.pts.stdout" "$dir/$base.node.stdout"; then
    verdict="OK"
  else
    verdict="WRONG pts exit=$code node exit=$ncode"
  fi
  echo "$base: pts exit=$code node exit=$ncode :: $verdict"
  if [ -n "$SHOW" ]; then
    echo "  pts stdout: $(head -c 300 "$dir/$base.pts.stdout" | tr '\n' '|')"
    echo "  node stdout: $(head -c 300 "$dir/$base.node.stdout" | tr '\n' '|')"
    [ "$ncode" != 0 ] && echo "  node stderr: $(grep -m2 'Error' "$dir/$base.node.stderr" | tr '\n' '|')"
  fi
done
