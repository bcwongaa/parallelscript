#!/usr/bin/env bash
# frames.sh stderr-file... : print the panic message and the first pts frames (function and site) of each.
for f in "$@"; do
  echo "== $(basename "$f" .pts.stderr)"
  grep -m1 '^panic: ' "$f"
  awk '/^goroutine /{on=1; next} on && /^github.com\/microsoft\/typescript-go\/pts\//{fn=$0; sub(/^github.com\/microsoft\/typescript-go\//, "", fn); sub(/\(0x.*$/, "", fn); getline loc; sub(/^.*parallelscript[^ ]*\/pts\//, "pts/", loc); sub(/ \+0x.*$/, "", loc); print "  " fn " @ " loc; n++; if (n >= '"${N:-4}"') exit}' "$f"
done
