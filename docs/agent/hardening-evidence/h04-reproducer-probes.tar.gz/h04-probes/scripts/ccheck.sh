#!/usr/bin/env bash
# ccheck.sh file.pts... : emit each program's C in process (irdump -c, no pts CLI) and check
# it with clang -fsyntax-only against the runtime headers; print OK / CLANG <first error> per file.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52/pts
out=$(mktemp -d /tmp/h04/cdir.XXXX)
for f in "$@"; do
  base=$(basename "$f")
  (cd "$(dirname "$f")" && IRDUMP_C_DIR=$out GOMAXPROCS=1 /tmp/h04/irdump -c "$base" > "$out/$base.irdump" 2>&1)
  if [ ! -f "$out/$base.c" ]; then
    echo "$base: no C :: $(grep -v '^==' "$out/$base.irdump" | head -1 | cut -c1-160)"
    continue
  fi
  start=$(date +%s.%N)
  clang -fsyntax-only -std=c11 -w -ferror-limit=2 -I "$W/runtime/include" -I "$W/third_party/bdwgc/include" -I "$W/third_party/libuv/include" -I "$W/third_party/ryu" -I "$W/third_party/libbacktrace" -I "$W/third_party/pcre2-config" "$out/$base.c" > "$out/$base.clang" 2>&1
  code=$?
  end=$(date +%s.%N)
  if [ "$code" = 0 ]; then
    echo "$base: C OK (clang $(printf '%.2f' "$(echo "$end - $start" | bc)")s)"
  else
    echo "$base: CLANG $(grep -m1 'error:' "$out/$base.clang" | sed 's/^.*error: //' | cut -c1-160)"
  fi
done
