#!/usr/bin/env bash
# probe.sh file.pts... : run each probe under pts (worktree build) and Node; print exit codes and first lines.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52
PTS=${PTS:-$WT/pts-bin/pts}
NODE=/home/bryan/.local/node/bin/node
LINES=${LINES_SHOWN:-8}
for f in "$@"; do
  echo "=== $f"
  out=$(cd "$(dirname "$f")" && PTS_HOME=$WT timeout 60 "$PTS" run "$(basename "$f")" 2>&1)
  code=$?
  echo "--- pts exit=$code"
  printf '%s\n' "$out" | head -n "$LINES"
  tmp=$(mktemp -d /tmp/h04/node.XXXX)
  cp "$f" "$tmp/$(basename "${f%.pts}").mts"
  nout=$(cd "$tmp" && timeout 60 "$NODE" --no-warnings --experimental-transform-types "$(basename "${f%.pts}").mts" 2>&1)
  ncode=$?
  echo "--- node exit=$ncode"
  printf '%s\n' "$nout" | head -n "$LINES"
  rm -rf "$tmp"
done
