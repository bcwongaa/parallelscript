#!/usr/bin/env bash
# gotest.sh name-regex [lines] : run `go test ./pts/tests/ -run <regex> -count=1` in the worktree
# (2 procs), save the log to /tmp/h04/logs/<safe name>.log and print its head and the exit code.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ad1c2f8c7439f4e52
mkdir -p /tmp/h04/logs
log=/tmp/h04/logs/$(printf '%s' "$1" | tr -c 'A-Za-z0-9_' '_').log
cd "$WT" || exit 1
echo "\$ go test ./pts/tests/ -run '$1' -count=1"
GOMAXPROCS=2 go test -p 1 ./pts/tests/ -run "$1" -count=1 -timeout 30m > "$log" 2>&1
code=$?
head -n "${2:-25}" "$log"
echo "... ($(wc -l < "$log") lines, log $log)"
echo "go test exit=$code"
