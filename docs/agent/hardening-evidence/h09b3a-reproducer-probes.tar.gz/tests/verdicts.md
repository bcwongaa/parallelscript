| test | node | HEAD | clean | proto | -chain | -elem | -lit | -rest |
|---|---|---|---|---|---|---|---|---|
| generic_optional_chain_calls | PASS | FAIL 12/18 lines | PASS | PASS | FAIL 12/18 lines | PASS | PASS | PASS |
| generic_element_access_calls | PASS | FAIL 11/14 lines | PASS | PASS | FAIL 1/14 lines | FAIL 11/14 lines | PASS | PASS |
| generic_union_literal_arguments | PASS | FAIL 11/17 lines | PASS | PASS | PASS | PASS | FAIL 11/17 lines | PASS |
| skipped_generic_method_literal_arguments | PASS | FAIL 2/2 lines | PASS | PASS | PASS | PASS | FAIL 2/2 lines | PASS |
| generic_rest_parameter_calls | PASS | FAIL 11/13 lines | PASS | PASS | FAIL 1/13 lines | PASS | PASS | FAIL 11/13 lines |
| generic_rest_spread_arguments | PASS | FAIL exit 1 (PTS1001) | PASS | PASS | PASS | PASS | PASS | FAIL exit 1 (PTS1001) FB |
| generic_rest_result_contexts | PASS | FAIL exit 1 (PTS1001) | PASS | FAIL exit 1 (PTS1001) FB | FAIL exit 1 (PTS1001) FB | FAIL exit 1 (PTS1001) FB | FAIL exit 1 (PTS1001) FB | FAIL exit 1 (PTS1001) FB |
| generic_call_forms_any_boundaries | FAIL 9/10 lines | FAIL 3/10 lines | PASS | PASS | FAIL 3/10 lines | PASS | PASS | PASS |
