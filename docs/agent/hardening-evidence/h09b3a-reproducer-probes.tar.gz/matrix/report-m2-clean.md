by shape/type: {'arr/num': {'OK': 62}, 'box/arr': {'OK': 62}, 'box/cls': {'OK': 62}, 'box/num': {'OK': 93}, 'box/str': {'OK': 93}, 'prom/num': {'OK': 62}, 'union/num': {'OK': 62}}

moves against base:
  TYPEERR -> OK: 288
  OK -> not OK: none
  same class, other output: none
