counts: {'OK': 208, 'TYPEERR': 288}

| form \ kind | fnvar | value | disp | iface | ifacelit | lit | union | direct |
|---|---|---|---|---|---|---|---|---|
| dot | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| opt | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok7 |
| optnn | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| elem | - | ok7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 |
| elemconst | - | ok7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 |
| elemopt | - | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 |
| lit | ok7 | ok7 | ok7 | TE7 | TE7 | TE7 | TE7 | ok7 |
| litplain | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| rest | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | ok7 |
| restopt | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | ok2 |
| litcls | ok2 | ok2 | ok2 | TE2 | TE2 | TE2 | TE2 | ok2 |
| restmix | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | ok7 |

by shape/type: {'arr/num': {'OK': 25, 'TYPEERR': 37}, 'box/arr': {'OK': 25, 'TYPEERR': 37}, 'box/cls': {'OK': 25, 'TYPEERR': 37}, 'box/num': {'OK': 38, 'TYPEERR': 55}, 'box/str': {'OK': 38, 'TYPEERR': 55}, 'prom/num': {'OK': 32, 'TYPEERR': 30}, 'union/num': {'OK': 25, 'TYPEERR': 37}}
