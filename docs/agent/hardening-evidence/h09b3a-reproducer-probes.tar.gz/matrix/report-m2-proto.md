counts: {'OK': 496}

| form \ kind | fnvar | value | disp | iface | ifacelit | lit | union | direct |
|---|---|---|---|---|---|---|---|---|
| dot | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| opt | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| optnn | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| elem | - | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| elemconst | - | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| elemopt | - | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| lit | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| litplain | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| rest | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| restopt | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| litcls | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| restmix | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |

by shape/type: {'arr/num': {'OK': 62}, 'box/arr': {'OK': 62}, 'box/cls': {'OK': 62}, 'box/num': {'OK': 93}, 'box/str': {'OK': 93}, 'prom/num': {'OK': 62}, 'union/num': {'OK': 62}}

moves against base:
  TYPEERR -> OK: 288
  OK -> not OK: none
  same class, other output: none
