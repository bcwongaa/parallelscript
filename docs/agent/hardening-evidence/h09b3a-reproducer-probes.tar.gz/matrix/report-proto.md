counts: {'OK': 424}

| form \ kind | fnvar | value | disp | iface | ifacelit | lit | union | direct |
|---|---|---|---|---|---|---|---|---|
| dot | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| opt | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| optnn | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| elem | - | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| elemconst | - | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| elemopt | - | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| lit | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| litplain | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| rest | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| restopt | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |

by shape/type: {'arr/num': {'OK': 54}, 'box/arr': {'OK': 54}, 'box/cls': {'OK': 54}, 'box/num': {'OK': 77}, 'box/str': {'OK': 77}, 'prom/num': {'OK': 54}, 'union/num': {'OK': 54}}

moves against base:
  TYPEERR -> OK: 231
  OK -> not OK: none
  same class, other output: none
