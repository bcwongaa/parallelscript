counts: {'OK': 193, 'TYPEERR': 231}

| form \ kind | fnvar | value | disp | iface | ifacelit | lit | union | direct |
|---|---|---|---|---|---|---|---|---|
| dot | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| opt | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok1 TE6 | ok7 |
| optnn | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 | ok2 |
| elem | - | ok7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 |
| elemconst | - | ok7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 |
| elemopt | - | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 |
| lit | ok7 | ok7 | ok7 | TE7 | TE7 | TE7 | TE7 | ok7 |
| litplain | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 | ok7 |
| rest | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | TE7 | ok7 |
| restopt | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | TE2 | ok2 |

by shape/type: {'arr/num': {'OK': 24, 'TYPEERR': 30}, 'box/arr': {'OK': 24, 'TYPEERR': 30}, 'box/cls': {'OK': 24, 'TYPEERR': 30}, 'box/num': {'OK': 33, 'TYPEERR': 44}, 'box/str': {'OK': 33, 'TYPEERR': 44}, 'prom/num': {'OK': 31, 'TYPEERR': 23}, 'union/num': {'OK': 24, 'TYPEERR': 30}}
