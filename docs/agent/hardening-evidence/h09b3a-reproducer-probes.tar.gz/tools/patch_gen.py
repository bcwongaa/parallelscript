#!/usr/bin/env python3
"""One-off: adds the restmix and litcls forms to gen.py (kept for the record)."""
p = '/tmp/h09b3/repro/tools/gen.py'
s = open(p).read()
reps = [
    ('''  rest       recv.make(a, a)                        make<T>(...xs: T[])
  restopt    recvMaybe?.make(a, a)''', '''  rest       recv.make(a, a)                        make<T>(...xs: T[])
  restopt    recvMaybe?.make(a, a)
  restmix    recv.make(a, "s")                      make<T>(...xs: (T | string)[])  (union elements)
  litcls     recv.make(new Some(a))                 a class's instance for the union parameter (C188)'''),
    ('FORMS_FULL = ["dot", "opt", "elem", "elemconst", "lit", "litplain", "rest"]', 'FORMS_FULL = ["dot", "opt", "elem", "elemconst", "lit", "litplain", "rest", "restmix"]'),
    ('FORMS_SMALL = ["optnn", "elemopt", "restopt"]', 'FORMS_SMALL = ["optnn", "elemopt", "restopt", "litcls"]'),
    ('''    if form in ("lit",):
        return "o: Opt<T>", "const x = o.tag === \\"some\\" ? o.value : o.fallback;"''', '''    if form in ("lit", "litcls"):
        return "o: Opt<T>", "const x = o.tag === \\"some\\" ? o.value : o.fallback;"
    if form == "restmix":
        return "...xs: (T | string)[]", "const x = xs[0] as T;"'''),
    ('''    if form == "litplain":
        return f"{{ value: {a} }}"''', '''    if form == "litplain":
        return f"{{ value: {a} }}"
    if form == "litcls":
        return f"new Some({a})"
    if form == "restmix":
        return f'{a}, "s"\''''),
    ('''        'type Opt<T> = { tag: "some"; value: T } | { tag: "none"; fallback: T };',''', '''        'type Opt<T> = { tag: "some"; value: T } | { tag: "none"; fallback: T };',
        "class Some<T> {",
        '  readonly tag = "some" as const;',
        "  constructor(public value: T) {}",
        "}",'''),
    ('''"litplain": f"recv({args})", "rest": f"recv({args})", "restopt": f"recvMaybe?.({args})"}.get(form)''', '''"litplain": f"recv({args})", "rest": f"recv({args})", "restopt": f"recvMaybe?.({args})", "restmix": f"recv({args})",
                "litcls": f"recv({args})"}.get(form)'''),
    ('''"rest": f"recv.make({args})", "restopt": f"recvMaybe?.make({args})"}[form]''', '''"rest": f"recv.make({args})", "restopt": f"recvMaybe?.make({args})",
                "restmix": f"recv.make({args})", "litcls": f"recv.make({args})"}[form]'''),
]
for a, b in reps:
    assert a in s, a
    s = s.replace(a, b)
open(p, 'w').write(s)
print("patched")
