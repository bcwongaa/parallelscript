#!/bin/bash
# run_both.sh CASES_DIR TAG : runs the matrix with the HEAD CLI, then with the prototype CLI
# (PTS_PROTO_DEBUG=1, so a fallback shows in pts_err), 2 jobs each. Results in matrix/TAG-{head,proto}.json.
R=/tmp/h09b3/repro
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
export PATH=$HOME/.local/node/bin:$PATH
python3 -I $R/tools/run_matrix.py --pts $R/pts-head --home $WT --node $HOME/.local/node/bin/node --scratch $R/scratch/m \
  --out $R/matrix/$2-head.json --jobs 2 "$1"/*.pts > $R/matrix/$2-head.log 2>&1
echo "exit=$?" >> $R/matrix/$2-head.log
PTS_PROTO_DEBUG=1 python3 -I $R/tools/run_matrix.py --pts $R/pts-proto --home $WT --node $HOME/.local/node/bin/node --scratch $R/scratch/m \
  --out $R/matrix/$2-proto.json --node-cache $R/matrix/$2-head.json --jobs 2 "$1"/*.pts > $R/matrix/$2-proto.log 2>&1
echo "exit=$?" >> $R/matrix/$2-proto.log
