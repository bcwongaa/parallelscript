#!/usr/bin/env python3
"""checkexpect.py [--pts PTS --home HOME] [--node-only] [--no-node] FILE.pts...

For each test file: runs Node on an .mts copy and pts, and compares both to the file's
`// expect:` block, line by line. Prints a verdict per runner and the differing lines.
"""
import argparse
import os
import shutil
import subprocess
import tempfile

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541"


def expect_block(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "// expect:":
            out = []
            for l in lines[i + 1:]:
                if not l.startswith("//"):
                    break
                out.append(l[3:] if l.startswith("// ") else l[2:])
            return out
    return None


def run(cmd, cwd, env, timeout=180):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        return p.returncode, p.stdout.decode(errors="replace"), p.stderr.decode(errors="replace")
    except subprocess.TimeoutExpired:
        return "timeout", "", ""


def compare(label, code, out, err, want):
    got = out.splitlines()
    if code == 0 and got == want:
        print(f"  {label}: PASS")
        return True
    print(f"  {label}: FAIL (exit {code})")
    for i in range(max(len(got), len(want))):
        g = got[i] if i < len(got) else "<none>"
        w = want[i] if i < len(want) else "<none>"
        if g != w:
            print(f"    line {i + 1}: got  {g!r}\n    {' ' * len(str(i + 1))}       want {w!r}")
    if err.strip():
        print("    stderr:", err.strip()[:600].replace("\n", "\n            "))
    return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", default=os.path.join(WT, "pts-bin/pts"))
    ap.add_argument("--home", default=WT)
    ap.add_argument("--node", default=os.path.expanduser("~/.local/node/bin/node"))
    ap.add_argument("--no-node", action="store_true")
    ap.add_argument("--node-only", action="store_true")
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    for path in args.files:
        name = os.path.basename(path)[:-4]
        with open(path) as f:
            want = expect_block(f.read())
        print(f"== {path}")
        d = tempfile.mkdtemp(prefix="chk.", dir="/tmp/h09b3/repro/scratch")
        try:
            shutil.copy(path, os.path.join(d, name + ".pts"))
            shutil.copy(path, os.path.join(d, name + ".mts"))
            env = dict(os.environ, PTS_HOME=args.home, TZ="America/New_York")
            if not args.no_node:
                compare("node", *run([args.node, "--no-warnings", "--experimental-transform-types", name + ".mts"], d, env), want)
            if not args.node_only:
                compare("pts ", *run([args.pts, "run", name + ".pts"], d, env), want)
        finally:
            shutil.rmtree(d, ignore_errors=True)


if __name__ == "__main__":
    main()
