#!/bin/bash
# emitc.sh FILE.pts OUT.c : the generated C of FILE.pts with the worktree's pts (PTS=... picks another CLI).
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
PTS=${PTS:-$WT/pts-bin/pts}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
d=$(mktemp -d /tmp/h09b3/repro/scratch/emit.XXXX)
b=$(basename "$1" .pts)
cp "$1" "$d/$b.pts"
(cd "$d" && PTS_HOME=${PTS_HOME_OVERRIDE:-$WT} "$PTS" emit-c "$b.pts" -o out.c)
code=$?
cp "$d/out.c" "$2" 2>/dev/null
rm -rf "$d"
exit $code
