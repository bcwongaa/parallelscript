#!/usr/bin/env python3
"""Summarises a run_matrix.py result: counts, and a form x kind table of classes.

usage: python3 -I report.py RESULT.json [BASE.json]
With BASE, also lists every case whose class differs (moves) and every case whose output differs.
Case names are form__kind__shape__type.
"""
import json
import sys
from collections import Counter, defaultdict

ABBR = {"OK": "ok", "TYPEERR": "TE", "MISREAD": "W", "ERRDIFF": "ED", "CRASH": "CR", "DIAG": "D", "ICE": "ICE", "TSERR": "TS", "TIMEOUT": "TO", "NODEERR": "NE", "OTHER": "?"}


def load(p):
    with open(p) as f:
        return {r["name"]: r for r in json.load(f)}


def main():
    res = load(sys.argv[1])
    base = load(sys.argv[2]) if len(sys.argv) > 2 else None
    counts = Counter(r["cls"] for r in res.values())
    print("counts:", dict(sorted(counts.items())))
    table = defaultdict(Counter)
    forms, kinds = [], []
    for name, r in res.items():
        form, kind, shape, t = name.split("__")
        if form not in forms:
            forms.append(form)
        if kind not in kinds:
            kinds.append(kind)
        table[(form, kind)][r["cls"]] += 1
    order_f = ["dot", "opt", "optnn", "elem", "elemconst", "elemopt", "lit", "litplain", "rest", "restopt"]
    order_k = ["fnvar", "value", "disp", "iface", "ifacelit", "lit", "union", "direct"]
    forms = [f for f in order_f if f in forms] + [f for f in forms if f not in order_f]
    kinds = [k for k in order_k if k in kinds] + [k for k in kinds if k not in order_k]
    print()
    print("| form \\ kind | " + " | ".join(kinds) + " |")
    print("|---|" + "---|" * len(kinds))
    for f in forms:
        cells = []
        for k in kinds:
            c = table.get((f, k))
            if not c:
                cells.append("-")
                continue
            cells.append(" ".join(f"{ABBR.get(cls, cls)}{n}" for cls, n in sorted(c.items())))
        print(f"| {f} | " + " | ".join(cells) + " |")
    by_shape = defaultdict(Counter)
    for name, r in res.items():
        form, kind, shape, t = name.split("__")
        by_shape[f"{shape}/{t}"][r["cls"]] += 1
    print()
    print("by shape/type:", {k: dict(v) for k, v in sorted(by_shape.items())})
    if base:
        moves = Counter()
        print()
        print("moves against base:")
        for name in sorted(res):
            a, b = base.get(name), res[name]
            if a is None:
                continue
            if a["cls"] != b["cls"]:
                moves[(a["cls"], b["cls"])] += 1
        for (a, b), n in sorted(moves.items()):
            print(f"  {a} -> {b}: {n}")
        worse = [n for n in sorted(res) if n in base and base[n]["cls"] == "OK" and res[n]["cls"] != "OK"]
        print("  OK -> not OK:", worse if worse else "none")
        changed = [n for n in sorted(res) if n in base and base[n]["cls"] == res[n]["cls"] and base[n]["pts_out"] != res[n]["pts_out"]]
        print("  same class, other output:", changed if changed else "none")


if __name__ == "__main__":
    main()
