#!/usr/bin/env python3
"""verdicts.py OUT.txt TEST.pts... : each test's `// expect:` block against Node, HEAD's CLI, the
prototype's CLI, and the prototype with each family turned off (PTS_PROTO_OFF=chain|elem|lit|rest),
PASS or FAIL with the failing line count (PTS_PROTO_DEBUG=1 for the prototype: a fallback is FB).
A file with a `// no-diff:` line is checked against its expect block under every runner, Node too.
"""
import os
import shutil
import subprocess
import sys
import tempfile

R = "/tmp/h09b3/repro"
WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541"
NODE = os.path.expanduser("~/.local/node/bin/node")
CONFIGS = [("node", None, None), ("HEAD", R + "/pts-head", None), ("clean", R + "/pts-clean", None), ("proto", R + "/pts-proto", ""),
           ("-chain", R + "/pts-proto", "chain"), ("-elem", R + "/pts-proto", "elem"),
           ("-lit", R + "/pts-proto", "lit"), ("-rest", R + "/pts-proto", "rest")]


def expect_block(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.strip() == "// expect:":
            out = []
            for l in lines[i + 1:]:
                if not l.startswith("//"):
                    break
                out.append(l[3:] if l.startswith("// ") else l[2:])
            return out
    return None


def run(cmd, cwd, env):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
        return p.returncode, p.stdout.decode(errors="replace"), p.stderr.decode(errors="replace")
    except subprocess.TimeoutExpired:
        return "timeout", "", ""


def main():
    out = open(sys.argv[1], "w")
    header = "| test | " + " | ".join(c[0] for c in CONFIGS) + " |"
    out.write(header + "\n|---|" + "---|" * len(CONFIGS) + "\n")
    for path in sys.argv[2:]:
        name = os.path.basename(path)[:-4]
        text = open(path).read()
        want = expect_block(text)
        cells = []
        for label, pts, off in CONFIGS:
            d = tempfile.mkdtemp(prefix="v.", dir=R + "/scratch")
            try:
                shutil.copy(path, os.path.join(d, name + ".pts"))
                shutil.copy(path, os.path.join(d, name + ".mts"))
                env = dict(os.environ, PTS_HOME=WT, TZ="America/New_York")
                if off is not None:
                    env["PTS_PROTO_DEBUG"] = "1"
                    env["PTS_PROTO_OFF"] = off
                if pts is None:
                    code, so, se = run([NODE, "--no-warnings", "--experimental-transform-types", name + ".mts"], d, env)
                else:
                    code, so, se = run([pts, "run", name + ".pts"], d, env)
            finally:
                shutil.rmtree(d, ignore_errors=True)
            got = so.splitlines()
            bad = sum(1 for i in range(max(len(got), len(want))) if (got[i] if i < len(got) else None) != (want[i] if i < len(want) else None))
            fb = " FB" if "PROTO fallback" in se else ""
            if code == 0 and bad == 0:
                cells.append("PASS" + fb)
            elif code != 0 and not got:
                first = se.strip().splitlines()[0] if se.strip() else ""
                cells.append(f"FAIL exit {code} ({'PTS1001' if 'PTS1001' in first else 'error'}){fb}")
            else:
                cells.append(f"FAIL {bad}/{len(want)} lines{fb}")
        line = f"| {name} | " + " | ".join(cells) + " |"
        print(line, flush=True)
        out.write(line + "\n")
    out.close()


if __name__ == "__main__":
    main()
