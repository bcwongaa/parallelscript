#!/bin/bash
# tri.sh FILE.pts... : runs each with the worktree's pts (PTS_HOME=worktree) and with Node (.mts copy),
# printing both outputs with their exit codes. PTS=... and PTS_HOME_OVERRIDE=... pick another CLI/runtime;
# NO_NODE=1 skips Node.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
PTS=${PTS:-$WT/pts-bin/pts}
HOME_=${PTS_HOME_OVERRIDE:-$WT}
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
mkdir -p /tmp/h09b3/repro/scratch
for f in "$@"; do
  b=$(basename "$f" .pts)
  d=$(mktemp -d /tmp/h09b3/repro/scratch/run.XXXX)
  cp "$f" "$d/$b.pts"
  cp "$f" "$d/$b.mts"
  echo "=== $f"
  echo "--- pts"
  (cd "$d" && PTS_HOME=$HOME_ timeout 180 "$PTS" run "$b.pts" 2>&1)
  echo "[pts exit=$?]"
  if [ -z "$NO_NODE" ]; then
    echo "--- node"
    (cd "$d" && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types "$b.mts" 2>&1)
    echo "[node exit=$?]"
  fi
  rm -rf "$d"
done
