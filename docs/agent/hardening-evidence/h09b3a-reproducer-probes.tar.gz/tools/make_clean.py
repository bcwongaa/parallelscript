#!/usr/bin/env python3
"""One-off: turns the measured prototype (proto-switch) in the worktree into the clean one:
drops the PTS_PROTO_OFF switches and the PTS_PROTO_DEBUG fallback print, and adds the
generics.go:515 fix (D-095's inference from the result for signatures with a rest parameter)."""
import re

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541/"


def edit(path, reps):
    p = WT + path
    s = open(p).read()
    for a, b in reps:
        assert a in s, (path, a)
        s = s.replace(a, b)
    open(p, "w").write(s)


edit("pts/lower/instances.go", [
    ('''
// protoOff (H09b3a reproducer's prototype only) turns a family's change off, for measuring
// each alone: PTS_PROTO_OFF=chain,rest,elem,lit.
func protoOff(name string) bool {
	return strings.Contains(os.Getenv("PTS_PROTO_OFF"), name)
}
''', ''),
    ('\t"os"\n', ''),
    ('chained := l.checker.PtsIsOuterCallChain(resolved) && !protoOff("chain")', 'chained := l.checker.PtsIsOuterCallChain(resolved)'),
    ('if resolved.HasRestParameter() && (protoOff("rest") || l.specialization == DeclaredInstances) ||', 'if resolved.HasRestParameter() && l.specialization == DeclaredInstances ||'),
    ('return ok && isRest && e.Array.Elem == ir.Value && !protoOff("rest") && p.Array.Elem != nil', 'return ok && isRest && e.Array.Elem == ir.Value && p.Array.Elem != nil'),
    ('return !protoOff("lit") && member != nil && isObject(from)', 'return member != nil && isObject(from)'),
])
edit("pts/lower/element_calls.go", [
    ('if !ok || protoOff("elem") || l.specialization == DeclaredInstances {', 'if !ok || l.specialization == DeclaredInstances {'),
])
edit("pts/driver/driver.go", [
    ('''		if os.Getenv("PTS_PROTO_DEBUG") != "" { // H09b3a reproducer's prototype only
			var internal *diagnostic.InternalError
			if errors.As(err, &internal) {
				fmt.Fprintln(os.Stderr, "PROTO fallback from", specialization, ":", err, "\\n", internal.Detail)
			} else {
				fmt.Fprintln(os.Stderr, "PROTO fallback from", specialization, ":", err)
			}
		}
''', ''),
    ('\t"errors"\n\t"fmt"\n\t"os"\n', '\t"errors"\n\t"os"\n'),
])
edit("pts/lower/generics.go", [
    ('''	if inferred == nil || slices.Equal(inferred, arguments) || slices.ContainsFunc(inferred, l.mentionsErased) || signature.HasRestParameter() {
		return nil
	}''', '''	if inferred == nil || slices.Equal(inferred, arguments) || slices.ContainsFunc(inferred, l.mentionsErased) {
		return nil
	}'''),
    ('''	params := signature.Parameters()
	for i, argument := range call.Arguments.Nodes {
		if i >= len(params) || !l.checker.IsTypeAssignableTo(l.typeAt(argument), instantiated(l.typeOfSymbol(params[i]))) {
			return nil
		}
	}
	return inferred''', '''	params := signature.Parameters()
	for i, argument := range call.Arguments.Nodes {
		if signature.HasRestParameter() && i >= len(params)-1 {
			// An argument for the rest parameter (C170): of its element type, or a spread of its type.
			rest := instantiated(l.typeOfSymbol(params[len(params)-1]))
			if !l.checker.IsArrayType(rest) {
				return nil // a tuple's elements: as before
			}
			if argument.Kind == ast.KindSpreadElement {
				if !l.checker.IsTypeAssignableTo(l.typeAt(argument.Expression()), rest) {
					return nil
				}
			} else if !l.checker.IsTypeAssignableTo(l.typeAt(argument), l.checker.GetElementTypeOfArrayType(rest)) {
				return nil
			}
			continue
		}
		if i >= len(params) || !l.checker.IsTypeAssignableTo(l.typeAt(argument), instantiated(l.typeOfSymbol(params[i]))) {
			return nil
		}
	}
	return inferred'''),
])
print("clean")
