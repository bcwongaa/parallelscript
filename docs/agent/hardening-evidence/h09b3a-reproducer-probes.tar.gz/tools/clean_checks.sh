#!/bin/bash
# clean_checks.sh : the clean prototype (pts-clean, worktree as it is): the 496-case matrix, then
# the lowering/driver/cgen unit tests, a focused pts/tests run and a filtered smoke run with clang.
R=/tmp/h09b3/repro
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
: > $R/clean.exits
python3 -I $R/tools/run_matrix.py --pts $R/pts-clean --home $WT --node $HOME/.local/node/bin/node --scratch $R/scratch/m \
  --out $R/matrix/m2-clean.json --node-cache $R/matrix/m2-head.json --jobs 2 $R/matrix/cases2/*.pts > $R/matrix/m2-clean.log 2>&1
echo "matrix=$?" >> $R/clean.exits
cd "$WT" || exit 1
GOMAXPROCS=2 go test -count=1 -p 1 ./pts/lower/ ./pts/driver/ ./pts/cgen/ > $R/clean.unit.txt 2>&1
echo "unit=$?" >> $R/clean.exits
PATTERN='^(TestRun|TestRunMatchesNode|TestErrors)$/^(generic_.*|dispatched_generic.*|.*optional.*|.*chain.*|.*rest.*|.*spread.*|.*element.*|.*keyed.*|.*union.*|.*interface.*|.*any_.*|.*erased.*|.*object_literal.*|.*method.*|.*overload.*|.*context.*|zz_.*)$'
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -p 1 -parallel 2 -timeout 60m ./pts/tests -run "$PATTERN" -json > $R/clean.focused.jsonl 2> $R/clean.focused.err
echo "focused=$?" >> $R/clean.exits
GOMAXPROCS=2 PTS_SMOKE_CLANG=1 PTS_SMOKE_FILTER='generic_|object_union|optional|rest|element' go test -count=1 -p 1 -timeout 60m ./pts/tests -run '^TestCompilerFailsCleanly$' > $R/clean.smoke.txt 2>&1
echo "smoke=$?" >> $R/clean.exits
echo done >> $R/clean.exits
