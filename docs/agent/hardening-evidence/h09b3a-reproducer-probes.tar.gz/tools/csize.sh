#!/bin/bash
# csize.sh FILE.pts... : lines of generated C (pts emit-c) with HEAD's CLI and the prototype's, and the
# number of instance lookups (pts_instance_find / pts_method_instance_find) in each.
R=/tmp/h09b3/repro
for f in "$@"; do
  PTS=$R/pts-head $R/tools/emitc.sh "$f" $R/scratch/size.head.c > /dev/null 2>&1; h=$?
  PTS=$R/pts-proto $R/tools/emitc.sh "$f" $R/scratch/size.proto.c > /dev/null 2>&1; p=$?
  hl=$([ $h = 0 ] && wc -l < $R/scratch/size.head.c || echo "exit$h")
  pl=$([ $p = 0 ] && wc -l < $R/scratch/size.proto.c || echo "exit$p")
  hi=$([ $h = 0 ] && grep -o "pts_instance_find\|pts_method_instance_find" $R/scratch/size.head.c | wc -l || echo -)
  pi=$([ $p = 0 ] && grep -o "pts_instance_find\|pts_method_instance_find" $R/scratch/size.proto.c | wc -l || echo -)
  echo "$(basename $f .pts) head_lines=$hl proto_lines=$pl head_lookups=$hi proto_lookups=$pi"
  rm -f $R/scratch/size.head.c $R/scratch/size.proto.c
done
