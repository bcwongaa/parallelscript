#!/bin/bash
# suite.sh OUTPREFIX : the prototype tree's checks: lowering/driver/cgen unit tests, the checker's
# upstream tests, the whole pts/tests package (run, Node differential, errors, corpus, smoke with
# clang) and the CLI tests. Each step's exit code goes to OUTPREFIX.exits.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 1
: > "$1.exits"
GOMAXPROCS=2 go test -count=1 -p 1 ./pts/lower/ ./pts/driver/ ./pts/cgen/ > "$1.unit.txt" 2>&1
echo "unit=$?" >> "$1.exits"
GOMAXPROCS=2 go test -count=1 -p 1 ./internal/checker/... > "$1.checker.txt" 2>&1
echo "checker=$?" >> "$1.exits"
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 PTS_SMOKE_CLANG=1 go test -count=1 -p 1 -parallel 2 -timeout 90m ./pts/tests/ -json > "$1.tests.jsonl" 2> "$1.tests.err"
echo "tests=$?" >> "$1.exits"
GOMAXPROCS=2 go test -count=1 -p 1 ./cmd/pts/ > "$1.cli.txt" 2>&1
echo "cli=$?" >> "$1.exits"
echo "done" >> "$1.exits"
