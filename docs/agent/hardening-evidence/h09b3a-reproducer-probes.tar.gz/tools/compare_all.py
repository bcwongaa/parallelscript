#!/usr/bin/env python3
"""compare_all.py HEAD_ALL.txt CLEAN_ALL.txt : per probe, the lines where HEAD differs from Node,
and whether the clean prototype matches Node there (tri.sh outputs: HEAD's with Node, the
prototype's without)."""
import re
import sys


def parse(path):
    runs, cur, part = {}, None, None
    for line in open(path).read().splitlines():
        m = re.match(r"^=== (.*)$", line)
        if m:
            cur = m.group(1)
            runs[cur] = {"pts": [], "node": [], "pts_exit": None, "node_exit": None}
            continue
        if cur is None:
            continue
        if line == "--- pts":
            part = "pts"
            continue
        if line == "--- node":
            part = "node"
            continue
        m = re.match(r"^\[(pts|node) exit=(\d+)\]$", line)
        if m:
            runs[cur][m.group(1) + "_exit"] = int(m.group(2))
            continue
        runs[cur][part].append(line)
    return runs


def main():
    head, clean = parse(sys.argv[1]), parse(sys.argv[2])
    for name in sorted(head):
        h, c = head[name], clean.get(name)
        node = h["node"]
        same_head = h["pts"] == node and h["pts_exit"] == h["node_exit"]
        same_clean = c is not None and c["pts"] == node and c["pts_exit"] == h["node_exit"]
        print(f"== {name}: HEAD {'= Node' if same_head else '!= Node'} (exit {h['pts_exit']}), "
              f"clean {'= Node' if same_clean else '!= Node'} (exit {c['pts_exit'] if c else '?'})")
        if same_head and same_clean:
            continue
        for i in range(max(len(node), len(h["pts"]), len(c["pts"]) if c else 0)):
            n = node[i] if i < len(node) else "<none>"
            hp = h["pts"][i] if i < len(h["pts"]) else "<none>"
            cp = c["pts"][i] if c and i < len(c["pts"]) else "<none>"
            if hp != n or cp != n:
                print(f"   node : {n}\n   HEAD : {hp}\n   clean: {cp}")


if __name__ == "__main__":
    main()
