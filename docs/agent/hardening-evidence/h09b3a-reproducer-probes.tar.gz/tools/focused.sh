#!/bin/bash
# focused.sh OUTPREFIX : the focused pts/tests subset (run, Node differential, errors) on the worktree as it is.
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae1b0dd3e886fa541
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
cd "$WT" || exit 1
PATTERN='^(TestRun|TestRunMatchesNode|TestErrors)$/^(generic_.*|dispatched_generic.*|.*optional.*|.*chain.*|.*rest.*|.*spread.*|.*element.*|.*keyed.*|.*union.*|.*interface.*|.*any_.*|.*erased.*|.*object_literal.*|.*method.*|.*overload.*)$'
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -p 1 -parallel 2 -timeout 40m ./pts/tests -run "$PATTERN" -json > "$1.jsonl" 2> "$1.err"
echo "exit=$?" > "$1.exit"
