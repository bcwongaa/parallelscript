import sys, subprocess, re
pts, f = sys.argv[1], sys.argv[2]
src = open(f).read().splitlines()
i = src.index('// expect:')
want = [l[3:] if l.startswith('// ') else l[2:] for l in src[i+1:] if l.startswith('//')]
want = '\n'.join(want) + '\n'
r = subprocess.run([pts, 'run', f], capture_output=True, text=True, timeout=300)
if r.stdout == want:
    print(f"{f}: PASS (exit {r.returncode})")
else:
    got = r.stdout.splitlines(); w = want.splitlines()
    k = next((j for j in range(max(len(got), len(w))) if j >= len(got) or j >= len(w) or got[j] != w[j]), None)
    print(f"{f}: FAIL exit {r.returncode} first diff line {k}: got {got[k] if k is not None and k < len(got) else None!r} want {w[k] if k is not None and k < len(w) else None!r}; stderr {r.stderr.strip()[:200]!r}")
