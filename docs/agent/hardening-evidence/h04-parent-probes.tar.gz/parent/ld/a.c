extern void pts_runtime_init(int argc, char **argv);
int main(int argc, char **argv) { pts_runtime_init(argc, argv); return 0; }
