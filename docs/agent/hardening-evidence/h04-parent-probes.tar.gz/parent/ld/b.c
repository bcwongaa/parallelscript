#line 7 "/p/main.pts"
extern void pts_no_such_function(void);
int main(void) { pts_no_such_function(); return 0; }
