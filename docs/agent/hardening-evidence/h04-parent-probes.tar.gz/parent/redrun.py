import json, subprocess, sys, os, glob
pts, home, out = sys.argv[1], sys.argv[2], sys.argv[3]
recs = []
for f in sorted(glob.glob('*.pts')):
    env = dict(os.environ, PTS_HOME=home)
    r = subprocess.run([pts, 'run', f], capture_output=True, text=True, timeout=300, env=env)
    src = open(f).read().splitlines()
    want = None
    if '// expect:' in src:
        i = src.index('// expect:')
        want = '\n'.join(l[3:] if l.startswith('// ') else l[2:] for l in src[i+1:] if l.startswith('//')) + '\n'
    recs.append({'file': f, 'exit': r.returncode, 'stdout_matches_expect': (r.stdout == want) if want is not None else None,
                 'stdout_head': r.stdout.splitlines()[:3], 'stderr_head': r.stderr.splitlines()[:2]})
    print(f, r.returncode, recs[-1]['stdout_matches_expect'], (r.stderr.splitlines() or [''])[0][:150])
json.dump({'pts': pts, 'PTS_HOME': home, 'records': recs}, open(out, 'w'), indent=1)
