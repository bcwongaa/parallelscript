type U = [string, number] | Generator<number>;
function isT(x: U): x is [string, number] { return Array.isArray(x); }
const d: U = ["b", 2];
if (isT(d)) { console.log("plain union local", d[0], d[1]); }
