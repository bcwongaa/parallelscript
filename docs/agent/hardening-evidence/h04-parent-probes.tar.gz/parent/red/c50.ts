// Pre-existing (base too): object rest of an interface-typed value emits C that clang rejects.
interface I { a: number }
class C { a = 1; b = 2; }
const i: I = new C();
const { a, ...rest } = i;
console.log(a, rest);
