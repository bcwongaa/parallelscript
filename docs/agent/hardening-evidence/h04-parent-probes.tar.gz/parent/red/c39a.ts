async function e3(p: Promise<number> | [number]) { return Array.isArray(p) ? p[0] : await p; }
e3(Promise.resolve(3)).then(v => console.log("e3 promise|tuple", v));
