const o: any = {
  get [Symbol.iterator]() { console.log("get @@iterator"); return function* () { yield 1; yield 2; }; },
};
for (const x of o) console.log("item", x);
const [a] = o;
console.log(a);
console.log([...o]);
