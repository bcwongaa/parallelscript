function isNums(x: unknown): x is number[] { return Array.isArray(x); }
const u: unknown = JSON.parse("[3, 1, 2]");
if (isNums(u)) {
  console.log(u.length, u[0], u.at(-1), u.indexOf(1), u.includes(2), u.join("-"), u.slice(1), u.concat([9]));
  u.push(4); u.unshift(0); console.log(u.pop(), u.shift(), u);
  u.sort((a, b) => a - b); u.reverse(); console.log(u, u.map(n => n * 2), u.filter(n => n > 1), u.reduce((a, b) => a + b, 0));
  u.forEach(n => console.log("each", n)); console.log(u.find(n => n > 1), u.findIndex(n => n > 5), u.some(n => n > 2), u.every(n => n > 0));
  for (const n of u) console.log("of", n);
  console.log([...u], Array.from(u), [...u.keys()], [...u.entries()], [...u.values()]);
  const [a, b, ...rest] = u; console.log(a, b, rest);
  u[0] = 10; u.length = 2; console.log(u, JSON.stringify(u), `${u}`, typeof u, u === u);
  u.splice(0, 1, 7, 8); u.fill(5, 1); console.log(u, Object.keys(u));
  const typed: number[] = u; typed.push(6); console.log(u.length, typed.length);
  const sum = (xs: number[]) => xs.reduce((s, x) => s + x, 0); console.log(sum(u));
}
const g: unknown = [["k", 1], ["j", 2]];
function isPairs(x: unknown): x is [string, number][] { return Array.isArray(x); }
if (isPairs(g)) { for (const [k, v] of g) console.log(k, v); console.log(g[1][0], g.map(([k]) => k), new Map(g).get("j")); }
function isPair(x: unknown): x is [string, number] { return Array.isArray(x); }
const t: unknown = ["s", 5];
if (isPair(t)) { const [s, n] = t; console.log(s, n, t[0].length, t[1] + 1, t.length); t[1] = 6; console.log(t); }
