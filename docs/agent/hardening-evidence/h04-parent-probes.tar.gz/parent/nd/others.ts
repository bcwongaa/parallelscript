function isRec(x: unknown): x is Record<string, number> { return typeof x === "object" && x !== null; }
const r: unknown = JSON.parse('{"a": 1, "b": 2}');
if (isRec(r)) {
  r.c = 3; r["d"] = 4;
  console.log(r.b, r["c"], "c" in r, "a" in r, Object.keys(r), Object.values(r), Object.entries(r), JSON.stringify(r));
  for (const k in r) console.log("key", k, r[k]);
  const typed: Record<string, number> = r; typed.e = 5; console.log(Object.keys(r).length, Object.keys(typed).length);
}
function isMap(x: unknown): x is Map<string, number> { return x instanceof Map; }
const m: unknown = new Map<string, number>([["x", 1]]);
if (isMap(m)) {
  m.set("y", 2); console.log(m.get("x"), m.has("y"), m.size, [...m.keys()], [...m.values()], [...m.entries()], [...m]);
  m.forEach((v, k) => console.log("m", k, v)); for (const [k, v] of m) console.log("of", k, v); m.delete("x"); console.log(m.size, m);
}
function isSet(x: unknown): x is Set<string> { return x instanceof Set; }
const s: unknown = new Set(["p"]);
if (isSet(s)) { s.add("q"); console.log(s.has("p"), s.size, [...s], Array.from(s)); for (const v of s) console.log("s", v); s.delete("p"); console.log(s); }
