const o: any = JSON.parse("{}");
console.log((o.m = new Map()).size);
const u: unknown = new Map([["a", 1]]);
if (u instanceof Map) console.log(u.size, u.get("a"));
