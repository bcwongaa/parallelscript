let u: number[] | undefined;
console.log((u = []).length, u);
const r: Record<"a" | "b", number[]> = { a: [1], b: [] };
const k: "a" | "b" = "a";
const got = (r[k] = []);
console.log(got.length, got === r[k], r);
