class C { xs: string[] | undefined = undefined; n: number | string = 0; }
const c = new C();
let u: string[] | undefined;
const o: any = {};
const m: Record<string, number[]> = {};
const arr: (string[] | null)[] = [null];
console.log((arr[0] = ["w"]).length);
