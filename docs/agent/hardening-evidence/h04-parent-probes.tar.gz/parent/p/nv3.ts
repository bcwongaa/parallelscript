let u: number[] | undefined;
console.log((u = []).length, u);
interface Shape { area(): number }
let s: Shape | undefined;
console.log((s = { area: () => 2 }).area());
class Box { v = 1; get double() { return this.v * 2; } }
let b: Box | null = null;
console.log((b = new Box()).double, b.v);
let w: string | string[] = "x";
console.log((w = ["p"]).length, (w = "abc").length);
