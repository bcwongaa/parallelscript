type U = string[] | Generator<number>;
function* g() { yield 1; }
const values: U[] = [["a", "b"], g()];
for (const v of values) {
  if (Array.isArray(v)) { console.log(v.length, v[0], v.join("-")); v.push("c"); console.log(v); }
  else console.log([...v]);
}
