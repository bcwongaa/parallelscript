class Logger2 { log(...args: [string, number]) { console.log("class", args[0], args[1]); } }
interface L { log(...args: [string, number]): void }
const viaClass: L = new Logger2();
viaClass.log("c", 2);
class G { pair<T>(...items: [T, T]): T[] { return [items[0], items[1]]; } }
const g = new G();
console.log(g.pair("x", "y"));
const anyG: any = g;
console.log(anyG.pair(1, 2));
