interface Shape { area(): number }
let s: Shape | undefined;
console.log((s ??= { area: () => 2 }).area());
let m: Map<string, number> | undefined;
console.log((m ??= new Map()).size);
