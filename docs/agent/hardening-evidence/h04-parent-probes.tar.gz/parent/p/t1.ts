type U = [string, number] | Generator<number>;
function isT(x: U): x is [string, number] { return Array.isArray(x); }
const d: U = ["b", 2];
if (isT(d)) { console.log("plain union local", d[0], d[1]); d[0] = "z"; }
console.log(d);
function* g() { yield 1; }
let v: U = g();
if (!isT(v)) console.log([...v]);
v = ["c", 3];
if (isT(v)) { const t = v; t[1] = 9; }
console.log(v);
async function e3(p: Promise<number> | [number]) { return Array.isArray(p) ? p[0] : await p; }
e3(Promise.resolve(3)).then(v => console.log("e3 promise|tuple", v));
e3([4]).then(v => console.log("e3 tuple", v));
