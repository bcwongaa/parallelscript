async function f(p: Promise<number> | number[]) { return Array.isArray(p) ? p.length : await p; }
f([5, 6]).then(x => console.log("f", x));
async function h(p: Promise<number> | number[]) { if (Array.isArray(p)) { const a: number[] = p; return a[0]; } return await p; }
h([5, 6]).then(x => console.log("h", x));
