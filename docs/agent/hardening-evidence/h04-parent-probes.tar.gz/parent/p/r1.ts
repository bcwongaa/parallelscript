interface I { a: number }
class C { a = 1; b = 2; }
const i: I = new C();
const { a, ...rest } = i;
console.log(a, rest);
function f(x: I) { const { a: aa, ...others } = x; return [aa, others]; }
console.log(f({ a: 5 }));
interface E {}
const e: E = new C();
const spread = { ...e, z: 1 };
console.log(spread);
class Empty {}
const { ...none } = new Empty();
console.log(none);
const target = { q: 1 };
console.log(Object.assign(target, new Empty()));
