class C { xs: string[] | undefined = undefined; n: number | string = 0; }
const c = new C();
let u: string[] | undefined;
const o: any = JSON.parse("{}");
const m: Record<string, number[]> = {};
const arr: (string[] | null)[] = [null];
console.log((o.v = [1, 2, 3]).length, (o.s = "abc").toUpperCase());
