const a = { get x() { return 1; } };
let v = 2;
const b = { get x() { return v; }, set x(n: number) { v = n; } };
b.x = 5;
console.log(a.x, b.x);
