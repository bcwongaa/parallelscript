// An object literal with a getter alone and one with a getter and a setter of the same
// property have shapes of their own: the second took the first's, which has no setter, and
// the compiler panicked on its setter (found by H04, D-179).
const fixed = { get x() { return 1; } };
let stored = 2;
const settable = { get x() { return stored; }, set x(n: number) { stored = n; } };
settable.x = 5;
console.log(fixed.x, settable.x, stored);
const writeOnlyAfter = { set y(n: number) { stored = n; }, get y() { return stored * 10; } };
writeOnlyAfter.y = 3;
console.log(writeOnlyAfter.y);

// expect:
// 1 5 5
// 30
