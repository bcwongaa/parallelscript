function isSA(x: unknown): x is string[] { return Array.isArray(x); }
const j: unknown = JSON.parse('["a", "b"]');
if (isSA(j)) { console.log(j.length, j[0], j.join("+")); j.push("c"); console.log(j); }
const k: any = JSON.parse('[1, 2]');
if (Array.isArray(k)) console.log(k.length, k[1]);
