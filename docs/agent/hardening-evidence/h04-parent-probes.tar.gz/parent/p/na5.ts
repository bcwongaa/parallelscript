function isR(x: unknown): x is Record<string, number> { return typeof x === "object" && x !== null; }
function isP(x: unknown): x is { a: number } { return typeof x === "object" && x !== null && "a" in x; }
const j: unknown = JSON.parse('{"a": 1, "b": 2}');
if (isR(j)) console.log(j["a"] + j["b"], Object.keys(j));
if (isP(j)) console.log(j.a + 1);
type V = { a: number } | Generator<number>;
const w: V = { a: 7 };
if ("a" in w) console.log(w.a);
interface Pt { x: number }
function isPts(v: unknown): v is Pt[] { return Array.isArray(v); }
const ps: unknown = JSON.parse('[{"x": 1}, {"x": 2}]');
if (isPts(ps)) console.log(ps.length, ps[1].x, ps.map(p => p.x * 10));
const json: any = JSON.parse('[1, [2, 3]]');
if (Array.isArray(json)) console.log(json.length, json[1]);
