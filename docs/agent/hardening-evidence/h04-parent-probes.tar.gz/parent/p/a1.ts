class C { xs: string[] | undefined = undefined; n: number | string = 0; }
const c = new C();
console.log((c.xs = ["z"]).length);
console.log((c.n = 5).toFixed(1));
let u: string[] | undefined;
console.log((u = ["q", "r"]).length);
const o: any = {};
console.log((o.v = [1, 2, 3]).length, (o.s = "abc").toUpperCase());
const m: Record<string, number[]> = {};
console.log((m["a"] = [7]).length, m);
const arr: (string[] | null)[] = [null];
console.log((arr[0] = ["w"]).length);
