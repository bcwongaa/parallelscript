// no-diff: pins a documented difference (D-179, D-071): dynamic data narrowed to a typed array is copied at each read
// Pins a documented difference (D-179), so that a change to it is seen: dynamic data (an
// `unknown` from JSON.parse) that a type guard narrows to a typed array or record is
// converted, so copied, at each read, as converting dynamic data is anywhere (D-071):
// writes through the narrowed name don't reach the data, and two reads aren't the same
// object. Binding the narrowed value to a typed local copies it once. JS writes the data
// itself (`[ 'a', 'b', 'c' ]`, `true`). The program's own arrays narrowed out of a union
// with a type only dynamic values hold are kept as they are
// (run/narrowed_arrays_of_dynamic_unions.pts).
function isStrings(x: unknown): x is string[] {
  return Array.isArray(x) && x.every((item) => typeof item === "string");
}
const parsed: unknown = JSON.parse('["a", "b"]');
if (isStrings(parsed)) {
  parsed.push("c");
  console.log(parsed, parsed === parsed, parsed.length);
  const strings: string[] = parsed;
  strings.push("d");
  console.log(strings, strings.length);
}
function isCounts(x: unknown): x is Record<string, number> {
  return typeof x === "object" && x !== null;
}
const counts: unknown = JSON.parse('{"a": 1}');
if (isCounts(counts)) {
  counts["b"] = 2;
  console.log(counts, Object.keys(counts).length);
}

// expect:
// [ 'a', 'b' ] false 2
// [ 'a', 'b', 'd' ] 3
// { a: 1 } 1
