class Animal { name = "a"; }
class Dog extends Animal { bark() { return "woof"; } }
interface Shape { area(): number }
class Sq implements Shape { s: number; constructor(s: number) { this.s = s; } area() { return this.s * this.s; } side() { return this.s; } }
let a: Animal = new Animal();
let s: Shape = new Sq(1);
let n: number = 0;
let t: [number, string] | number[] = [1, "a"];
const j = (a = new Dog()); console.log(j.bark());
