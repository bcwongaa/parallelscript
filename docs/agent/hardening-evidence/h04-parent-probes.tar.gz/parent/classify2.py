import subprocess, sys, os, glob, collections, shutil, tempfile
pts, home = sys.argv[1], sys.argv[2]
files = sorted(f for d in sys.argv[3:] for f in glob.glob(os.path.join(d, '*.pts')))
counts = collections.Counter()
for f in files:
    d, b = os.path.dirname(f), os.path.basename(f)
    try:
        r = subprocess.run([pts, 'run', b], cwd=d, capture_output=True, text=True, timeout=120, env=dict(os.environ, PTS_HOME=home))
        code, out, err = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        code, out, err = 'timeout', '', ''
    t = tempfile.mkdtemp(prefix='h04node')
    shutil.copy(f, os.path.join(t, b[:-4] + '.mts'))
    try:
        n = subprocess.run([os.path.expanduser('~/.local/node/bin/node'), '--no-warnings', '--experimental-transform-types', b[:-4] + '.mts'], cwd=t, capture_output=True, text=True, timeout=60)
        nout, ncode = n.stdout, n.returncode
    except subprocess.TimeoutExpired:
        nout, ncode = None, 'timeout'
    shutil.rmtree(t)
    if 'error PTS9001' in err or 'panic:' in err:
        v = 'ICE ' + next(l for l in err.splitlines() if 'PTS9001' in l or 'panic:' in l)[:170]
    elif ' - error ' in err:
        v = 'DIAG ' + next(l for l in err.splitlines() if ' - error ' in l)[:170]
    elif out == nout and code == ncode:
        v = 'OK'
    else:
        v = f'WRONG pts exit={code} node exit={ncode}'
    counts[v.split()[0]] += 1
    print(f'{os.path.relpath(f)}: {v}', flush=True)
print(dict(counts))
