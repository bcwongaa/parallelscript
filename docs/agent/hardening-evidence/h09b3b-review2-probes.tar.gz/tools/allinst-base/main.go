// Command allinst lowers each file given with lower.AllInstances alone (driver.EmitCWith,
// no fallback) and prints "OK file" or "ERR file: first line of the error".
package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func main() {
	for _, file := range os.Args[1:] {
		_, err := driver.EmitCWith(context.Background(), file, lower.AllInstances)
		if err == nil {
			fmt.Println("OK", file)
			continue
		}
		fmt.Println("ERR", file+":", strings.SplitN(err.Error(), "\n", 2)[0])
	}
}
