#!/bin/bash
# tri.sh FILE.pts... : run each probe with Node (.mts copy), the base CLI and the snapshot CLI.
# Writes FILE.node / FILE.base / FILE.snap (output + "exit=N") beside the probe and prints them.
# NO_BASE=1 skips the base.
NODE=${NODE:-$HOME/.local/node/bin/node}
for f in "$@"; do
  abs=$(readlink -f "$f"); dir=$(dirname "$abs"); b=$(basename "$abs" .pts)
  d=$(mktemp -d /tmp/h09b3b/review2/tmp/t.XXXXXX)
  cp "$abs" "$d/$b.mts"
  (cd "$d" && TZ=America/New_York timeout 60 "$NODE" --no-warnings --experimental-transform-types "$b.mts" > "$dir/$b.node" 2>&1; echo "exit=$?" >> "$dir/$b.node")
  if [ -z "$NO_BASE" ]; then
    (cd "$d" && PTS_HOME=/tmp/h09b3b/base TZ=America/New_York timeout 300 /tmp/h09b3b/base/pts-bin/pts run "$abs" > "$dir/$b.base" 2>&1; echo "exit=$?" >> "$dir/$b.base")
  fi
  (cd "$d" && PTS_HOME=/tmp/h09b3b/snap3r TZ=America/New_York timeout 300 /tmp/h09b3b/snap3r/pts-bin/pts run "$abs" > "$dir/$b.snap" 2>&1; echo "exit=$?" >> "$dir/$b.snap")
  echo "=== $f"
  for k in node base snap; do [ -f "$dir/$b.$k" ] && { echo "--- $k"; cat "$dir/$b.$k"; }; done
  if cmp -s "$dir/$b.node" "$dir/$b.snap"; then echo "--- snap SAME as node"; else echo "--- snap DIFF from node"; fi
  rm -rf "$d"
done
