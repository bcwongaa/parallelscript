// keepsLeaves reports, and reports whether, every typed leaf that flatMap may store from the
// values of callback, of type t, stays the value it is where the result's element type elem
// goes (keepsLeaf). An annotated callback's values, and a named function's, are of its result
// type, converted where it returns them; otherwise the leaves are found in the values it
// returns (keepsLeavesOf).
func (l *lowerer) keepsLeaves(callback *ast.Node, t, elem ir.Type) bool {
	if !ast.IsFunctionExpressionOrArrowFunction(callback) || callback.Type() != nil {
		return l.keepsLeafTypes(t, elem, callback)
	}
	return l.keepsReturnedValues(callback, func(value *ast.Node) bool { return l.keepsLeavesOf(value, elem, true, callback) })
}

// keepsReturnedValues reports whether keeps holds for each value fn, a function expression or
// an arrow function, returns.
func (l *lowerer) keepsReturnedValues(fn *ast.Node, keeps func(value *ast.Node) bool) bool {
	body := fn.Body()
	if body.Kind != ast.KindBlock {
		return keeps(body)
	}
	kept := true
	ast.ForEachReturnStatement(body, func(stmt *ast.Node) bool {
		if value := stmt.Expression(); value != nil && !keeps(value) {
			kept = false
		}
		return !kept
	})
	return kept
}

// keepsLeavesOf is keepsLeaves for the leaves flatMap takes from value, a value fn returns or
// one whose elements are such a value's: an array's or a tuple's elements, or value itself,
// each stored where elem goes. made says whether value's literals are made as the context of
// fn's values gives them. The elements of an array literal are its elements, of a map's or
// Array.from's with a function the values the function returns, of a sorted, reversed,
// filtered or sliced array its receiver's, and of a const fn makes at each call (constMadeIn)
// its initializer's.
func (l *lowerer) keepsLeavesOf(value *ast.Node, elem ir.Type, made bool, fn *ast.Node) bool {
	value = ast.SkipParentheses(value)
	switch value.Kind {
	case ast.KindArrayLiteralExpression:
		return l.keepsElements(value, elem, made, fn)
	case ast.KindAsExpression, ast.KindSatisfiesExpression:
		if literal := castLiteral(value); literal != nil {
			return l.keepsElements(literal, elem, false, fn) // made as the cast's type
		}
	case ast.KindConditionalExpression:
		branches := value.AsConditionalExpression()
		return l.keepsLeavesOf(branches.WhenTrue, elem, made, fn) && l.keepsLeavesOf(branches.WhenFalse, elem, made, fn)
	case ast.KindObjectLiteralExpression:
		return l.keepsValue(value, elem, made, fn) // a leaf itself
	case ast.KindIdentifier:
		if initializer := l.constMadeIn(value, fn); initializer != nil {
			return l.keepsLeavesOf(initializer, elem, false, fn)
		}
	case ast.KindCallExpression:
		if mapper := l.arrayMapper(value); mapper != nil {
			return l.keepsReturnedValues(mapper, func(mapped *ast.Node) bool { return l.keepsValue(mapped, elem, false, mapper) })
		}
		if receiver := l.sameElementsReceiver(value); receiver != nil {
			return l.keepsLeavesOf(receiver, elem, false, fn)
		}
	}
	t := l.irType(l.typeAt(value), value)
	return t == nil || l.keepsLeafTypes(t, elem, value)
}

// keepsElements is keepsLeavesOf for the elements of an array literal, each stored where
// elem goes, made as elem's values if made: a spread's are an array's or a tuple's leaves.
func (l *lowerer) keepsElements(literal *ast.Node, elem ir.Type, made bool, fn *ast.Node) bool {
	for _, element := range literal.AsArrayLiteralExpression().Elements.Nodes {
		switch element.Kind {
		case ast.KindOmittedExpression:
			continue // a hole
		case ast.KindSpreadElement:
			if spread := l.irType(l.typeAt(element.Expression()), element); (isArray(spread) || isTuple(spread)) && !l.keepsLeavesOf(element.Expression(), elem, false, fn) {
				return false
			}
			continue // an iterable's values, which the runtime checks
		}
		if !l.keepsValue(element, elem, made, fn) {
			return false
		}
	}
	return true
}

// keepsTupleElements is keepsElements for an array literal made as the tuple type tuple, each
// element stored in the field at its position. A spread of a tuple stores its elements in the
// fields from its position on; after a spread of an array, or of a tuple with optional
// elements, an element may be stored in any later field.
func (l *lowerer) keepsTupleElements(literal *ast.Node, tuple *ir.Class, made bool, fn *ast.Node) bool {
	position, exact := 0, true
	keeps := func(check func(field ir.Type) bool) bool {
		last := len(tuple.Fields)
		if exact {
			last = min(position+1, last)
		}
		for _, field := range tuple.Fields[min(position, last):last] {
			if !check(field.Type) {
				return false
			}
		}
		return true
	}
	for _, element := range literal.AsArrayLiteralExpression().Elements.Nodes {
		if element.Kind != ast.KindSpreadElement {
			if !keeps(func(field ir.Type) bool { return l.keepsValue(element, field, made, fn) }) {
				return false
			}
			position++
			continue
		}
		spread := l.irType(l.typeAt(element.Expression()), element)
		if array, ok := spread.(*ir.Array); ok {
			exact = false
			if !keeps(func(field ir.Type) bool { return l.keepsLeaf(array.Elem, field, false, element) }) {
				return false
			}
			continue
		}
		spreadTuple, ok := spread.(*ir.Class)
		if !ok || !spreadTuple.Tuple {
			exact = false // an iterable's values, which the runtime checks
			continue
		}
		for _, f := range spreadTuple.Fields {
			if !keeps(func(field ir.Type) bool { return l.keepsLeaf(f.Type, field, false, element) }) {
				return false
			}
			if f.Optional {
				exact = false
			} else {
				position++
			}
		}
	}
	return true
}

// keepsValue is keepsLeaf for the value of node, stored where target goes; made says whether
// a literal there is made as target's value. A literal made so is target's value, an array
// literal's elements stored where target's go; a new array or tuple of another type is copied
// into target's, its elements stored where target's go (keepsLeavesOf), and a new object
// literal into target's interface, each property's value stored where its type goes.
func (l *lowerer) keepsValue(node *ast.Node, target ir.Type, made bool, fn *ast.Node) bool {
	node = ast.SkipParentheses(node)
	switch node.Kind {
	case ast.KindConditionalExpression:
		branches := node.AsConditionalExpression()
		return l.keepsValue(branches.WhenTrue, target, made, fn) && l.keepsValue(branches.WhenFalse, target, made, fn)
	case ast.KindObjectLiteralExpression:
		if made {
			return true // its properties converted where it is made
		}
		return l.keepsObjectLiteral(node, target, fn)
	case ast.KindArrayLiteralExpression:
		if made {
			switch to := l.nestedLiteralTarget(target, node).(type) {
			case *ir.Array:
				return l.keepsElements(node, to.Elem, true, fn)
			case *ir.Class:
				return l.keepsTupleElements(node, to, true, fn)
			}
			return true
		}
	}
	t := l.irType(l.typeAt(node), node)
	if t == nil {
		return true
	}
	isNew := l.isNewArrayIn(node, fn)
	if to := l.arrayTarget(t, target); isNew && to != nil && t != to && !isDynamicArray(t) {
		switch {
		case isTuple(t) && isArray(to):
			l.notSupportedYet(node, fmt.Sprintf("using a `%s` as a `%s` is", t, to)) // the runtime converts arrays to arrays only
			return false
		case isArray(t) && isArray(to):
			return l.keepsLeavesOf(node, to.(*ir.Array).Elem, false, fn) // the copy holds its elements
		case isTuple(t) && isTuple(to):
			if literal := castLiteral(node); literal != nil {
				return l.keepsTupleElements(literal, to.(*ir.Class), false, fn)
			}
		}
	}
	return l.keepsLeaf(t, target, isNew, node)
}

// arrayTarget is the array or tuple type that a value of the array or tuple type t stored
// where target goes is converted to: target, or the union member memberFor finds; nil if t
// isn't an array or a tuple type or there is none.
func (l *lowerer) arrayTarget(t, target ir.Type) ir.Type {
	if !isArray(t) && !isTuple(t) {
		return nil
	}
	if u, ok := target.(*ir.Union); ok {
		if u.Has(t) {
			return t
		}
		target = l.memberFor(t, u)
	}
	if isArray(target) || isTuple(target) {
		return target
	}
	return nil
}

// keepsObjectLiteral is keepsValue for an object literal not made as target's value: a new
// object, copied where target's interface goes, each property's value stored where the
// interface's property of its name goes. A literal with other members than plain properties,
// or going where another type goes, is checked by its type.
func (l *lowerer) keepsObjectLiteral(literal *ast.Node, target ir.Type, fn *ast.Node) bool {
	t := l.irType(l.typeAt(literal), literal)
	if t == nil {
		return true
	}
	to := target
	if u, ok := target.(*ir.Union); ok && !u.Has(t) {
		to = l.memberFor(t, u)
	}
	iface, ok := to.(*ir.Interface)
	if !ok || len(iface.Methods) > 0 {
		return l.keepsLeaf(t, target, false, literal)
	}
	for _, property := range literal.AsObjectLiteralExpression().Properties.Nodes {
		var value *ast.Node
		switch property.Kind {
		case ast.KindPropertyAssignment:
			value = property.Initializer()
		case ast.KindShorthandPropertyAssignment:
			value = property.Name()
		}
		if value == nil || !ast.IsIdentifier(property.Name()) && !ast.IsStringLiteral(property.Name()) {
			return l.keepsLeaf(t, target, false, literal) // a spread, a method, an accessor or a computed name
		}
		field := iface.Field(property.Name().Text())
		if field != nil && !l.keepsValue(value, field.Type, false, fn) {
			return false
		}
	}
	return true
}

// castLiteral is the array literal node is, under parentheses and `as` and `satisfies` casts
// (`[c, 1] as const`), or nil if it isn't one.
func castLiteral(node *ast.Node) *ast.Node {
	for {
		switch node = ast.SkipParentheses(node); node.Kind {
		case ast.KindArrayLiteralExpression:
			return node
		case ast.KindAsExpression, ast.KindSatisfiesExpression:
			node = node.Expression()
		default:
			return nil
		}
	}
}

// arrayMapper is the function expression or arrow function that call, `xs.map(f)` or
// `Array.from(xs, f)`, makes its array's elements with, or nil if it isn't such a call.
func (l *lowerer) arrayMapper(call *ast.Node) *ast.Node {
	args := call.Arguments()
	callee := ast.SkipParentheses(call.AsCallExpression().Expression)
	var mapper *ast.Node
	switch {
	case l.isArrayMethodCall(call) && callee.AsPropertyAccessExpression().Name().Text() == "map" && len(args) > 0:
		mapper = args[0]
	case l.isArrayStatic(callee, "from") && len(args) > 1:
		mapper = args[1]
	}
	if mapper == nil || !ast.IsFunctionExpressionOrArrowFunction(mapper) {
		return nil
	}
	return mapper
}

// sameElementsMethods are the methods of arrays whose result holds elements of the array
// they are called on only.
var sameElementsMethods = map[string]bool{
	"sort": true, "reverse": true, "filter": true, "slice": true, "toSorted": true, "toReversed": true,
}

// sameElementsReceiver is the array that call, a sameElementsMethods call whose result is of
// its type (not a type guard's narrower one), is made on, or nil if it isn't such a call.
func (l *lowerer) sameElementsReceiver(call *ast.Node) *ast.Node {
	if !l.isArrayMethodCall(call) {
		return nil
	}
	callee := ast.SkipParentheses(call.AsCallExpression().Expression).AsPropertyAccessExpression()
	if !sameElementsMethods[callee.Name().Text()] || l.typeAt(call) != l.typeAt(callee.Expression) {
		return nil
	}
	return callee.Expression
}

// nestedLiteralTarget is the array or tuple type that elem gives an array literal stored
// where it goes: elem, or the union member memberFor finds for the literal's type; nil if neither.
func (l *lowerer) nestedLiteralTarget(elem ir.Type, literal *ast.Node) ir.Type {
	if u, ok := elem.(*ir.Union); ok {
		t := l.irType(l.typeAt(literal), literal)
		if t == nil {
			return nil
		}
		elem = l.memberFor(t, u)
	}
	if isArray(elem) || isTuple(elem) {
		return elem
	}
	return nil
}

