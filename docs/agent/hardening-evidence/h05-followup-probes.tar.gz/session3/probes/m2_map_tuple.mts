interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const ns = [1];
const r = [1].flatMap<[J, number]>(() => ns.map((m): [C, number] => [c, m]));
c.x = 5;
console.log(r.length, r[0][0].x);
