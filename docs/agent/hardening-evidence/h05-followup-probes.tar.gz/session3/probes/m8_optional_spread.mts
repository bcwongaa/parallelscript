interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const o: [number, string?] = [1];
const r = [1].flatMap<[number, string?, C?]>(() => [[...o, c]]);
c.x = 5;
console.log(r.length, JSON.stringify(r));
