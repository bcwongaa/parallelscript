function f(): (number | string)[] {
  const local = [1, 2];
  return local;
}
console.log(f(), f() === f());
const once = [1, 2];
const u: (number | string)[] = once;
console.log(u);
for (let i = 0; i < 2; i++) {
  const inner = [i];
  const v: (number | string)[] = inner;
  console.log(v);
}
