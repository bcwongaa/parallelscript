class P { constructor(public x: number) {} }
const ps = [new P(1), new P(2)];
const r = [1].flatMap<P[]>(() => [ps.slice(), ps.filter((p) => p.x > 1)]);
ps[0].x = 9;
console.log(r.length, r[0][0].x, r[0][0] === ps[0]);
const ns = [1, 2];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => [ns.slice()])));
console.log(JSON.stringify([1, 2].flatMap<[number, (number | string)[]]>((i) => [[i, [i]]])));
const t2 = [1].flatMap<[number, string]>(() => ns.map((m): [number, string] => [m, String(m)]));
console.log(JSON.stringify(t2));
