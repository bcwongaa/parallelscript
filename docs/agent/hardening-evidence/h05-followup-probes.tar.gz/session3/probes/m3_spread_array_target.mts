interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const cs: C[] = [c];
const r = [1].flatMap<J[]>(() => [[...cs]]);
c.x = 5;
console.log(r.length, r[0][0].x);
