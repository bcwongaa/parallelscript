const base = [1];
class K {
  xs: (number | string)[] = base;
}
const k1 = new K();
const k2 = new K();
console.log(k1.xs === k2.xs);
