const nested = [[1], [2]];
const r = [1].flatMap<(number | string)[]>(() => [...nested]);
nested[0].push(9);
console.log(JSON.stringify(r));
