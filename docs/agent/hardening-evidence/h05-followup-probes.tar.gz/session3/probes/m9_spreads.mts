const nested = [[1], [2]];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => [...nested.map((m) => [...m])])));
const ns = [1, 2];
console.log(JSON.stringify([1].flatMap<number | string>(() => [...ns, ...new Set([3])])));
class P { constructor(public x: number) {} }
const ps = [new P(1)];
const r = [1].flatMap<P>(() => [...ps]);
console.log(r[0] === ps[0]);
