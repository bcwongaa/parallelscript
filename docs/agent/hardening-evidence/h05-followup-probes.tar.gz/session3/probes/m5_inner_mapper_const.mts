const r = [1].flatMap<(number | string)[]>((i) => {
  const a = [i];
  return [0, 1].map(() => a);
});
console.log(r.length, r[0] === r[1]);
