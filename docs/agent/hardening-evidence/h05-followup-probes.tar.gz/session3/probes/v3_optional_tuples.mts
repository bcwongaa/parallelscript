const r = [1, 2].flatMap<[number, string?]>((i) => [[i], [i, "s"]]);
console.log(JSON.stringify(r), r[0].length, r[1].length);
const short: [number][] = [[1]];
const loose: [number, string?][] = short.map((t) => t);
console.log(JSON.stringify(loose));
const anyPairs: any = [[1], [2, "b"]];
const typed: [number, string?][] = anyPairs;
console.log(JSON.stringify(typed), typed[0].length, typed[1][1]);
