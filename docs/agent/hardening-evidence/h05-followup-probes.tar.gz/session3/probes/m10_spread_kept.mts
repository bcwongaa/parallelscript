const nested = [[1], [2]];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => [...nested])));
