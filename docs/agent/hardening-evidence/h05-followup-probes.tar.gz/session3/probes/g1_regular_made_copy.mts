interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const cs: C[] = [c];
const js: J[] = cs.slice();
c.x = 5;
console.log(js[0].x);
