// keepsLeaves reports, and reports whether, every typed leaf that flatMap may store from the
// values of callback, of type t, stays the value it is where the result's element type elem
// goes (keepsLeaf). An annotated callback's values, and a named function's, are of its result
// type, converted where it returns them; otherwise the leaves of a returned array literal are
// its elements, a new array among them copied as it is made (D-094), and those of another
// value the elements of its type's arrays and tuples and its other members.
func (l *lowerer) keepsLeaves(callback *ast.Node, t, elem ir.Type) bool {
	if !ast.IsFunctionExpressionOrArrowFunction(callback) || callback.Type() != nil {
		return l.keepsLeafTypes(t, elem, callback)
	}
	return l.keepsReturnedLeaves(callback, func(value *ast.Node) bool { return l.keepsLeavesOf(value, elem, callback) })
}

// keepsReturnedLeaves reports whether keeps holds for each value fn, a function expression or
// an arrow function, returns.
func (l *lowerer) keepsReturnedLeaves(fn *ast.Node, keeps func(value *ast.Node) bool) bool {
	body := fn.Body()
	if body.Kind != ast.KindBlock {
		return keeps(body)
	}
	kept := true
	ast.ForEachReturnStatement(body, func(stmt *ast.Node) bool {
		if value := stmt.Expression(); value != nil && !keeps(value) {
			kept = false
		}
		return !kept
	})
	return kept
}

// keepsLeavesOf is keepsLeaves for one value the callback returns, value. The elements of an
// array a map or Array.from makes with a function are the values the function returns, each
// stored as an element of an array literal would be, those of a sorted, reversed, filtered or
// sliced array its receiver's, and those of a const the callback declares and returns its
// initializer's.
func (l *lowerer) keepsLeavesOf(value *ast.Node, elem ir.Type, callback *ast.Node) bool {
	if literal := castLiteral(value); literal != nil {
		return l.keepsLiteralLeaves(literal, elem)
	}
	value = ast.SkipParentheses(value)
	switch value.Kind {
	case ast.KindConditionalExpression:
		branches := value.AsConditionalExpression()
		return l.keepsLeavesOf(branches.WhenTrue, elem, callback) && l.keepsLeavesOf(branches.WhenFalse, elem, callback)
	case ast.KindObjectLiteralExpression:
		return true // made as the type its context gives it, its properties converted there
	case ast.KindIdentifier:
		if initializer := l.singleUseConstInitializer(value); initializer != nil {
			return l.keepsLeavesOf(initializer, elem, callback)
		}
	case ast.KindCallExpression:
		if mapper := l.arrayMapper(value); mapper != nil {
			return l.keepsReturnedLeaves(mapper, func(mapped *ast.Node) bool { return l.keepsElement(mapped, elem) })
		}
		if receiver := l.sameElementsReceiver(value); receiver != nil {
			return l.keepsLeavesOf(receiver, elem, callback)
		}
	}
	t := l.irType(l.typeAt(value), value)
	return t == nil || l.keepsLeafTypes(t, elem, callback)
}

// castLiteral is the array literal node is, under parentheses and `as` and `satisfies` casts
// (`[c, 1] as const`), or nil if it isn't one.
func castLiteral(node *ast.Node) *ast.Node {
	for {
		switch node = ast.SkipParentheses(node); node.Kind {
		case ast.KindArrayLiteralExpression:
			return node
		case ast.KindAsExpression, ast.KindSatisfiesExpression:
			node = node.Expression()
		default:
			return nil
		}
	}
}

// arrayMapper is the function expression or arrow function that call, `xs.map(f)` or
// `Array.from(xs, f)`, makes its array's elements with, or nil if it isn't such a call.
func (l *lowerer) arrayMapper(call *ast.Node) *ast.Node {
	args := call.Arguments()
	callee := ast.SkipParentheses(call.AsCallExpression().Expression)
	var mapper *ast.Node
	switch {
	case l.isArrayMethodCall(call) && callee.AsPropertyAccessExpression().Name().Text() == "map" && len(args) > 0:
		mapper = args[0]
	case l.isArrayStatic(callee, "from") && len(args) > 1:
		mapper = args[1]
	}
	if mapper == nil || !ast.IsFunctionExpressionOrArrowFunction(mapper) {
		return nil
	}
	return mapper
}

// sameElementsMethods are the methods of arrays whose result holds elements of the array
// they are called on only.
var sameElementsMethods = map[string]bool{
	"sort": true, "reverse": true, "filter": true, "slice": true, "toSorted": true, "toReversed": true,
}

// sameElementsReceiver is the array that call, a sameElementsMethods call, is made on, or
// nil if it isn't such a call.
func (l *lowerer) sameElementsReceiver(call *ast.Node) *ast.Node {
	if !l.isArrayMethodCall(call) {
		return nil
	}
	callee := ast.SkipParentheses(call.AsCallExpression().Expression).AsPropertyAccessExpression()
	if !sameElementsMethods[callee.Name().Text()] {
		return nil
	}
	return callee.Expression
}

// keepsLiteralLeaves is keepsLeaves for the elements of an array literal, each stored where
// elem goes.
func (l *lowerer) keepsLiteralLeaves(literal *ast.Node, elem ir.Type) bool {
	for _, element := range literal.AsArrayLiteralExpression().Elements.Nodes {
		if !l.keepsElement(element, elem) {
			return false
		}
	}
	return true
}

// keepsTupleLiteralLeaves is keepsLeaves for the elements of an array literal made as the
// tuple type tuple, each stored in the field at its position. A spread of a tuple stores its
// elements in the fields from its position on; after a spread of an array, or of a tuple
// with optional elements, an element may be stored in any later field.
func (l *lowerer) keepsTupleLiteralLeaves(literal *ast.Node, tuple *ir.Class) bool {
	position, exact := 0, true
	keeps := func(check func(field ir.Type) bool) bool {
		last := len(tuple.Fields)
		if exact {
			last = min(position+1, last)
		}
		for _, field := range tuple.Fields[min(position, last):last] {
			if !check(field.Type) {
				return false
			}
		}
		return true
	}
	for _, element := range literal.AsArrayLiteralExpression().Elements.Nodes {
		if element.Kind != ast.KindSpreadElement {
			if !keeps(func(field ir.Type) bool { return l.keepsElement(element, field) }) {
				return false
			}
			position++
			continue
		}
		spread := l.irType(l.typeAt(element.Expression()), element)
		if array, ok := spread.(*ir.Array); ok {
			exact = false
			if !keeps(func(field ir.Type) bool { return l.keepsLeaf(array.Elem, field, false, element) }) {
				return false
			}
			continue
		}
		spreadTuple, ok := spread.(*ir.Class)
		if !ok || !spreadTuple.Tuple {
			exact = false // an iterable's values, which the runtime checks
			continue
		}
		for _, f := range spreadTuple.Fields {
			if !keeps(func(field ir.Type) bool { return l.keepsLeaf(f.Type, field, false, element) }) {
				return false
			}
			if f.Optional {
				exact = false
			} else {
				position++
			}
		}
	}
	return true
}

// keepsElement is keepsLeaves for one element of an array literal, stored where elem goes:
// each branch of a conditional is such an element, and a nested array literal's elements are
// stored in the array or tuple its context gives it.
func (l *lowerer) keepsElement(element *ast.Node, elem ir.Type) bool {
	if literal := castLiteral(element); literal != nil {
		switch target := l.nestedLiteralTarget(elem, literal).(type) {
		case *ir.Array:
			return l.keepsLiteralLeaves(literal, target.Elem)
		case *ir.Class:
			return l.keepsTupleLiteralLeaves(literal, target)
		}
		return true
	}
	element = ast.SkipParentheses(element)
	switch element.Kind {
	case ast.KindSpreadElement, ast.KindOmittedExpression, ast.KindObjectLiteralExpression:
		return true // a spread's elements are an array's or iterable's values, which the runtime checks; an omitted one is a hole; an object literal is made as its context's type
	case ast.KindConditionalExpression:
		branches := element.AsConditionalExpression()
		return l.keepsElement(branches.WhenTrue, elem) && l.keepsElement(branches.WhenFalse, elem)
	}
	t := l.irType(l.typeAt(element), element)
	return t == nil || l.keepsLeaf(t, elem, l.isNewArray(element), element)
}

// nestedLiteralTarget is the array or tuple type that elem gives an array literal stored
// where it goes: elem, or the union member memberFor finds for the literal's type; nil if neither.
func (l *lowerer) nestedLiteralTarget(elem ir.Type, literal *ast.Node) ir.Type {
	if u, ok := elem.(*ir.Union); ok {
		t := l.irType(l.typeAt(literal), literal)
		if t == nil {
			return nil
		}
		elem = l.memberFor(t, u)
	}
	if isArray(elem) || isTuple(elem) {
		return elem
	}
	return nil
}

// keepsLeafTypes is keepsLeaves for values of type t that aren't array literals, none of
// whose arrays is known to be new.
func (l *lowerer) keepsLeafTypes(t, elem ir.Type, node *ast.Node) bool {
	for _, leaf := range leafTypes(t) {
		if !l.keepsLeaf(leaf, elem, false, node) {
			return false
		}
	}
	return true
}

// keepsLeaf reports, and reports at node whether, a leaf of type leaf stored where elem goes
// stays the value it is. The runtime converts numbers, adapts functions (D-075) and copies
// dynamic data (D-071), but would copy a typed object into an interface whose members it
// doesn't provide as they are or into a union of interfaces none of which it provides, an
// instance into a class it isn't one of, or an array into an array or tuple of other
// elements, which JS doesn't: reported as the same conversions elsewhere report them (`const
// js: J[] = [c]`, D-094). A new array (made) is copied as it is made, but its elements are
// stored where elem's go. Each member of a union leaf is such a leaf.
func (l *lowerer) keepsLeaf(leaf, elem ir.Type, made bool, node *ast.Node) bool {
	if u, ok := leaf.(*ir.Union); ok {
		return !slices.ContainsFunc(u.Members, func(member ir.Type) bool { return !l.keepsLeaf(member, elem, made, node) })
	}
	if u, ok := elem.(*ir.Union); ok && !u.Has(leaf) {
		if isResultUnion(u) && isObjectOfProgram(leaf) {
			return true // an iterator result, as iterators hand them back: any of the program's objects as it is (D-178)
		}
		member := l.memberFor(leaf, u)
		if member == nil && isObject(leaf) {
			l.notSupportedYet(node, fmt.Sprintf("converting %s to %s is", leaf, u))
			return false
		}
		if member == nil {
			return true // left to the runtime's check
		}
		elem = member
	}
	switch {
	case leaf == elem || leaf == ir.Value || elem == ir.Value || isUnion(elem):
		return true
	case isArray(leaf) || isTuple(leaf):
		switch {
		case isDynamicArray(leaf) || !isArray(elem) && !isTuple(elem):
			return true
		case isTuple(leaf) && isArray(elem), !made && isTuple(elem):
			l.notSupportedYet(node, fmt.Sprintf("using a `%s` as a `%s` is", leaf, elem)) // the runtime converts arrays to arrays only, and tuples to tuples by copying them
			return false
		case !made:
			l.reportKeptCopy(leaf, elem, node)
			return false
		}
		return l.keepsElementsOf(leaf, elem, node)
	case isObject(leaf):
		switch target := elem.(type) {
		case *ir.Interface:
			missing := unprovided(leaf, target)
			if missing != "" && !holdsOptionally(leaf, target) {
				l.notSupportedYet(node, fmt.Sprintf("using a `%s` as a `%s`, whose `%s` it doesn't provide with the same types, is", leaf, target, missing))
				return false
			}
			if missing != "" {
				l.relaxedCasts = append(l.relaxedCasts, relaxedCast{from: leaf, to: target, node: node}) // checked against the subclasses that hold it otherwise, as objectCast's (D-066)
			}
		case *ir.Class:
			if class, ok := leaf.(*ir.Class); ok && !target.Result && !class.IsSubclassOf(target) {
				l.notSupportedYet(node, fmt.Sprintf("using a `%s` as a `%s` is", leaf, target))
				return false
			}
		}
	}
	return true
}

// keepsElementsOf is keepsLeaf for the elements of a new array or tuple of type from, copied
// into one of type to, an array into an array or a tuple into a tuple: its elements are the
// values they are, stored where to's go.
func (l *lowerer) keepsElementsOf(from, to ir.Type, node *ast.Node) bool {
	switch from := from.(type) {
	case *ir.Array:
		if to, ok := to.(*ir.Array); ok {
			return l.keepsLeaf(from.Elem, to.Elem, false, node)
		}
	case *ir.Class:
		if to, ok := to.(*ir.Class); ok {
			for i := range min(len(from.Fields), len(to.Fields)) {
				if !l.keepsLeaf(from.Fields[i].Type, to.Fields[i].Type, false, node) {
					return false
				}
			}
		}
	}
	return true
}

// reportKeptCopy reports a conversion of an array of type from to an array type to that
// would copy it where it may be changed or kept, which D-094 allows only where no one else
// holds the array.
func (l *lowerer) reportKeptCopy(from, to ir.Type, node *ast.Node) {
	l.notSupportedYet(node, fmt.Sprintf("using a %s as a %s where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is", from, to))
}

