**NOT READY.** Round 10's four findings are fixed or no longer reachable through flatMap, and the sweep found no new silent wrong output, run-time TypeError or crash compared with the commit. But some programs that the commit, the base and round 10 compiled and ran correctly are now PTS1001. These are object literals with computed or numeric keys (so tsc types them as hash maps) that are already made as the target type, through every recorded workaround. That is not the accepted c13 class.

Scratch: `/tmp/h05r11.MccN`. Outputs are in `<dir>/out/<name>.{node,new,r10,commit,base}`. Builds: new = cli6/suite5, r10 = cli5/suite4, commit = `/tmp/h05-close`, base = `/tmp/h05-base`. Node v24 runs on a `.mts` copy.

## Findings

**1. Medium-low, VERIFIED. A hash-map object literal made as the target is checked by its own type.** Regression vs commit, base and round 10. Every workaround fails: an annotated mapper, an annotated const with an array-literal initializer, `Array.of<T>` and a cast.
- Repro `m/m30_m11_annotated.pts`:
  ```ts
  const groups = [["a", "b"], ["c"]];
  const xs = groups.flatMap<Record<string, number | string>>((g) => g.map((k): Record<string, number | string> => ({ [k]: k.length })));
  console.log(JSON.stringify(xs));
  ```
  - Node, r10, commit and base: `[{"a":1},{"b":1},{"c":1}]`
  - new: `2:114 PTS1001: converting Record<string, number> to Record<string, number | string> is not supported yet`
- The same happens in:
  - `m/m42` (`const recs: Record<string, number | string>[] = [{ [g[0]]: g.length }]; return recs;`)
  - `m/m35` (`Array.of<Record<…>>({…})`)
  - `m/m36` (`[{…}] as Record<…>[]`)
- The only working workaround is annotating the flatMap callback itself (`m/m43`).
- **Cause:**
  - `keepsObjectLiteral` (`pts/lower/arrays.go:847-856`) takes the made type from `literalType`. `literalType` never returns a hash-map context, because `fitsLiteral` requires `isObjectType`.
  - But `objectLiteral` (`pts/lower/objects.go:350-358`) makes the literal as the first hash-map type among `literalContext`, `recordMemberOfContext` and `typeAt`. Here that is the target, `Record<string, number | string>`.
- **Fix:** share one "made type" helper between the two functions. Watch out for `recordType`'s diagnostics being reported twice.
- **Checked:** no false approval in the other direction. A record literal going where an interface goes is reported by the regular conversion on every tree (`m/m40`, `m/m41`).

**2. Low, VERIFIED. Hash-map leaves that the commit copied without visible effect are now PTS1001** ("converting Record<…> to Record<…>"). Regression vs commit, base and round 10. Node, r10, commit and base give the same correct output for all of them.
- `o14_numeric_key` (in round 8's set, `src/h05r8.vXBS/o/`). Your sweep missed it:
  ```ts
  interface N { 0: number | string }
  const ns = [1, 2];
  const r = [1].flatMap<N>(() => ns.map((m) => ({ 0: m })));
  ```
- `m/m11`: a computed-key literal in a mapper.
- `m/m25`: `{ 0: m, 1: m * 2 }` into `Record<number, …>`.
- `m/m12`: a const record used more than once in the callback.
- `m/m13`: a function's result.
- `m/m24`: a `Record<string, any>`, reported as "Record<string, value>".
- **Assessment:**
  - m12, m13 and m24 match the regular rule. `m/m20` is PTS1001 on every tree, so treating them as by design is defensible.
  - o14, m11 and m25 are the hash-map analogue of c13. The commit's rule didn't cover them, so the acceptance text needs widening.
  - Alternative: for a new literal, check only the values with `keepsLeaf(t.Value, member.Value)`.
- Inconsistency: `N | null` instead of `N` compiles and matches Node (`m/m28`), because unions skip the check (finding 4).

**3. Low, VERIFIED. "Annotate the const" doesn't help when the initializer is a mapper.** Regression vs commit, base and round 10, in the c13 class.
- Repro `ac/a1_annot_const_map_iface.pts`:
  ```ts
  interface P { a: number; z: number | string }
  const ns = [1, 2];
  const xs = [1, 2].flatMap<P>((i) => { const a: P[] = ns.map((m) => ({ a: m, z: m + i })); return a; });
  ```
  - Node, r10, commit and base: `[{"a":1,"z":2},{"a":2,"z":3},{"a":1,"z":3},{"a":2,"z":4}]`
  - new: `4:33 PTS1001 … whose z …`
  - `ac/a3` adds `.filter`: same result.
  - With an annotated mapper it compiles (`ac/a2`).
- **Cause:** `constMadeIn` walks into the initializer even though the annotation already converted it at the const.
- **Trade-off:** that walk also catches real identity loss. In `ac/a6`, `{ arr: kept }`: the commit's JSON hides a copy.
- **Suggestion:** at minimum, correct the recorded workaround to "annotate the mapper or the callback".

**4. Medium, VERIFIED, pre-existing (new, commit and base). Round 10's finding 2 is still open for union targets and for objects stored where a hash map goes.**
- **Silent copy** (Node prints `{"a":1,"b":2} true`; every build prints `{"a":1} false`):
  - `m/m01`: `flatMap<Record<string, number | string> | null>(() => [shared])`
  - `m/m17`: a union of two Records.
  - `mk/k15`: `A | Record<…>`.
- **Kept object into a Record** (`m/m18`):
  ```ts
  const shared = { a: 1 };
  const xs = [1].flatMap<Record<string, number>>(() => [shared]);
  shared.a = 5;
  ```
  Node prints `{"a":5} true`; every build prints `{"a":1} false`.
- **TypeError on every build:** `m/m02`, a Map into `Map<…> | undefined`.
- The regular rules report all of these: `toUnion` at `unions.go:212`, and `convert`'s "using a X as a hash-map object" in `lower.go`.
- **Cause:** in `keepsLeaf` (`arrays.go:975-987`), when `memberFor` returns nil for a MapType the code returns true ("left to the runtime's check"). The object case has no `*ir.MapType` target arm.
- **Fix caution:** an object-into-Record check must exempt new literals, because `lt/l13` is correct on every tree. Otherwise, record this as a ledger row.

**5. Nits.**
- The errors-test header still describes the round 8–9 copy-order rules, which no longer exist.
- Pre-existing diagnostic wording:
  - `misc/u1` says "whose `note`…"; the property that differs is `z`.
  - `any` prints as `value` (`m/m24`, `mk/k13`).

## Round 10 status
1. **No longer reachable through flatMap.**
   - `q6`, `q5`, `p01`, `q1`, `q3` and `n5` give PTS1001, as on the commit.
   - Relaxed interface casts keep identity and match Node on every tree (`f1/o1`–`o6`).
   - `q4`, a regular D-094 copy, is still DIFF on every tree. That needs its ledger row. `convert.c` hasn't changed since round 9.
2. **Fixed for direct leaves and properties.**
   - `n3`, `n6`, `n7`, `n9`, `n10`, `n10b`, `n12` and `n13` give PTS1001.
   - These went from DIFF or TypeError to PTS1001: `m04`, `m06`, `m10`, `m14`, `m15`, `m19`, `m22`, `m23` and `k06`.
   - Unions and objects into Records are still open (finding 4).
3. **Fixed.** `det2` gave the same PTS1001 in 8 of 8 builds. Round 9's `nd` probes are all PTS1001.
4. **Pre-existing and unchanged.** `mk/m2` is DIFF on every tree.

Tests:
- `flatmap_kept_elements` gives exactly its 35 errors, in order.
- `flatmap_leaf_conversions` gives its 12.
- In both run tests the `expect` block equals Node's output and the new CLI's.
- `convert_test.c` wasn't run (no `go test`), but the runtime is unchanged since round 9.

## Checked and fine
- **Sweep of rounds 3–10:** 870 unique probes (deduplicated by hash). New output differs from the commit's in 234:
  - 159 are compile errors on both, with only message or position changes.
  - Improvements: 19 errors → OK, 7 TypeErrors → OK, 35 wrong outputs → PTS1001, 3 TypeErrors → PTS1001.
  - New PTS1001 where the commit was OK, 9 files:
    - accepted: `c13`, `t6`
    - exported consts, round 10's accepted side effect: `e4`, `f`, `i`, `a`, `b`, `other`
    - not accepted: `o14` (finding 2)
  - Wrong output where the commit threw: `m1` and `m4`, accepted in round 7.
  - Nowhere is the new build wrong, throwing or crashing where the commit was right or reported an error. No PTS9xxx and no panics.
- **Map identity matches Node on every tree:**
  - the same Map or Set, and ReadonlyMap or ReadonlySet targets (`m03`)
  - an index-signature interface for a Record (`m05`)
  - value types that are structurally equal or the same interface in another order (`m07`, `m08`)
  - readonly array values (`m09`)
  - enum keys and values, and literal keys (`k01`–`k05`, `k07`)
  - class values (`k08`)
  - same-typed Map or Record properties (`k09`, `k10`)
  - union members (`m16`, `k11`)
  - new arrays of maps (`k12`)
- **The `literalType` path matches the commit and Node:**
  - unions with null or undefined (`l02`, `l03`, `l18`)
  - iterator results, including conditional, reordered and extra-property forms (`l04`, `l05`, `l21`)
  - nested literals (`l06`, `l07`) and discriminated unions (`l08`, `l09`)
  - casts, `Array.of` and `concat` (`l10`–`l12`)
  - getters, spreads, methods and generics (`l14`–`l16`, `l20`)
  - `Object.keys` on a made literal (`l22`)
- No duplicate diagnostics from `irType` in the check (`dup/d1`). gofmt is clean and every helper added in the diff is still used. The repo is unchanged.

## Commands
- `bin/one.sh <probe> [variants]`: Node on a `.mts` copy, then `PTS_HOME=<tree> <cli> run` for each build.
- Sweep: `xargs -P 2` over `reps.txt`; `bin/diffs.sh` lists probes where new and commit outputs differ.
- Tests: `sed` extraction of the `// error:` and `expect` blocks, compared with `cmp`.
- Determinism: 8 copies of `det2` with random trailing comments.
- `gofmt -l`. Last step: `touch /tmp/h05-r6/review11.done`.
