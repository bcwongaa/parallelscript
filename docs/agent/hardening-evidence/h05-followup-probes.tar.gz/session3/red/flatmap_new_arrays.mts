// A flatMap callback's arrays that are new at each call are copied as they are made where
// the result's element type goes (D-094): those a map or Array.from makes with a callback
// that makes them, conditionals of literals, cast literals, copies, sorted, reversed or
// filtered new arrays, and a const the callback declares (H05 review round 6, finding 3:
// PTS1001 after round 5's fix; the base and round 5 matched Node). A spread of a tuple in
// a nested tuple literal moves the elements after it to later fields (finding 2: the C
// below was checked against a J field, a PTS1001).
const ns = [1, 2];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => ns.map((m) => (m > 1 ? [m] : [])))));
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => ns.map((m) => [m] as number[]))));
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => ns.map((m) => [m]).reverse())));
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => ns.map((m) => [m, 0]).sort((a, b) => b[0] - a[0]))));
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => Array.from({ length: 2 }, (_, i) => [i]))));
const nested = [[1], [2]];
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => nested.map((m) => m.slice()))));
console.log(JSON.stringify([1].flatMap<(number | string)[]>(() => nested.map((m) => [...m]).filter((m) => m[0] > 1))));
console.log(
  JSON.stringify(
    [1, 2].flatMap<(number | string)[]>((i) => {
      const a = [[i], [i + 1]];
      return a;
    }),
  ),
);
console.log(
  JSON.stringify(
    [1, 2].flatMap<(number | string)[]>((i) => {
      const a = [i];
      return [a];
    }),
  ),
);
console.log(
  JSON.stringify(
    [1].flatMap<(number | string)[]>(() =>
      ns.map((m) => {
        if (m > 1) return [m, m];
        return [m];
      }),
    ),
  ),
);
interface J {
  x: number | string;
}
class C {
  constructor(public x: number) {}
}
const c = new C(1);
const q: [J, J] = [{ x: 1 }, { x: "a" }];
const r = [1].flatMap<[J, J, C]>(() => [[...q, c]]);
c.x = 5;
console.log(r.length, r[0][2].x, r[0][2] === c, r[0][0] === q[0]);
