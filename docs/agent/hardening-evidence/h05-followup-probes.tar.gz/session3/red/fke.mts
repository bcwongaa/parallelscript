// An array a flatMap callback returns in an array literal is a kept array unless it is new
// at each call: a const declared outside the callback holds the same array at each call,
// even if the callback is its only use, so copying it where an array of other elements goes
// would lose its identity (H05 review round 6, finding 1: copied silently, also in a
// conditional, a sorted const and a nested literal, and as a tuple's array field). A spread
// of a tuple moves a nested tuple literal's later elements to later fields (finding 2: the C
// was checked against a number field and copied into J silently), and a nested tuple literal
// under `as const` or `satisfies` is checked as the literal is (finding 4). The elements of a
// map's new tuples and of a spread in a nested literal are checked too, as are a spread's
// kept arrays (the parent's round 6 probes: copied silently). Round 7: an object a map, a
// const or a cast makes isn't made as the result's element type, so it is copied into it
// with its properties (copied silently in an intermediate version), and a tuple a cast, an
// annotation or a map's annotated callback makes is reported where an array goes (a
// TypeError at run time in that version). Round 8: a copy of such an object has the
// interface's properties in its order, so a literal with others, or in another order, is
// checked by its type; an iterable's spread values are of the literal's element type; and a
// shorthand property is a use of its const, here and in D-094's regular conversions (each
// copied silently before). Round 9: the copy shape lists an interface's properties in its
// declaration order, its own before an extended interface's, so a literal in another order
// is checked by its type; a shorthand's default (`{ a = arr }`) is a use of its const; and
// an exported const may be used in other files. Round 10: an object a map, a const or a
// cast makes of its own type is checked by that type (a copy into the interface's shape
// lost left-out, extra or misordered properties and hash maps' identity), and a hash map,
// a map or a set where one of other types goes is reported (copied silently, or a
// TypeError at run time).
interface J {
  x: number | string;
}
class C {
  constructor(public x: number) {}
}
const c = new C(1);
const out1 = [1];
console.log([1, 2].flatMap<(number | string)[]>(() => [out1]));
const out2 = [1];
console.log([1, 2].flatMap<(number | string)[]>((i) => [i > 0 ? out2 : [i]]));
const out3 = [3, 1];
console.log([1, 2].flatMap<(number | string)[]>(() => [out3.sort()]));
const out4 = [1];
console.log([1, 2].flatMap<(number | string)[][]>(() => [[out4]]));
const ws = ["w"];
console.log([1, 2].flatMap<[number, (string | number)[]]>((i) => [[i, ws]]));
const p: [number, number] = [1, 2];
console.log([1].flatMap<[number, number, J]>(() => [[...p, c]]));
console.log([1].flatMap<readonly [J, number]>(() => [[c, 1] as const]));
console.log([1].flatMap<[J, number]>(() => [[c, 1] satisfies [C, number]]));
const hs = [{ arr: [1] }];
console.log([1].flatMap<(number | string)[]>(() => hs.map((h) => h.arr)));
const ns = [1];
console.log([1].flatMap<[J, number]>(() => ns.map((m): [C, number] => [c, m])));
const cs: C[] = [c];
console.log([1].flatMap<J[]>(() => [[...cs]]));
const nested = [[1], [2]];
console.log([1].flatMap<(number | string)[]>(() => [...nested]));
console.log(
  [1].flatMap<(number | string)[]>((i) => {
    const a = [i];
    return [0, 1].map(() => a);
  }),
);
interface H {
  arr: (number | string)[];
}
const kept = [1];
console.log([1].flatMap<H>(() => ns.map(() => ({ arr: kept }))));
console.log([1].flatMap<{ c: J }>(() => ns.map(() => ({ c }))));
const kept2 = [1];
console.log(
  [1, 2].flatMap<H>(() => {
    const a = [{ arr: kept2 }];
    return a;
  }),
);
const kept3 = [1];
console.log([1, 2].flatMap<H>(() => [{ arr: kept3 }] as { arr: number[] }[]));
console.log([1, 2].flatMap<(number | string)[]>((i) => [[i, "a"] as [number, string]]));
console.log([1].flatMap<(number | string)[]>(() => ns.map((m): [number, string] => [m, "a"])));
console.log(
  [1, 2].flatMap<(number | string)[]>((i) => {
    const a: [number, string][] = [[i, "a"]];
    return a;
  }),
);
interface K {
  x: number | string;
  y: number;
}
console.log([1].flatMap<K>(() => ns.map((m) => ({ y: m, x: m }))));
interface Item {
  name: string;
  qty: number | string;
}
const orders = [{ id: 1, lines: ["a", "b"] }];
console.log(orders.flatMap<Item>((o) => o.lines.map((line) => ({ name: line, qty: 1, order: o.id }))));
const kept4 = [1];
console.log([1, 2].flatMap<(number | string)[]>(() => [...new Set([kept4])]));
const kept5 = [1];
function* gen() {
  yield kept5;
}
console.log([1].flatMap<(number | string)[]>(() => [...gen()]));
const kept6 = [1];
console.log(
  [1, 2].flatMap<(number | string)[]>(() => {
    const a = [...new Set([kept6])];
    return a;
  }),
);
const seen: { a: number[] }[] = [];
console.log(
  [1].flatMap<(number | string)[]>(() =>
    ns.map((m) => {
      const a = [m];
      seen.push({ a });
      return a;
    }),
  ),
);
const shared = [1];
const holder = { shared };
const widened: (number | string)[] = shared;
console.log(holder, widened);
interface Q {
  z: number | string;
  a: number;
}
console.log([1].flatMap<Q>(() => ns.map((m) => ({ a: m, z: m }))));
interface Base {
  a: number | string;
}
interface Derived extends Base {
  b: number;
}
console.log([1].flatMap<Derived>(() => ns.map((m) => ({ a: m, b: m * 10 }))));
let taken: number[] = [];
console.log(
  [1].flatMap<(number | string)[]>(() => {
    const arr = [1, 2];
    ({ taken = arr } = {} as { taken?: number[] });
    return [arr];
  }),
  taken,
);
export const exported = [1];
const exportedWide: (number | string)[] = exported;
console.log(exportedWide);
interface Outer {
  r: Record<string, number | string>;
  id: number;
}
const sharedRecord: Record<string, number> = { a: 1 };
console.log([1].flatMap<Outer>(() => ns.map((k) => ({ r: sharedRecord, id: k }))));
const sharedRecord2: Record<string, number> = { a: 1 };
console.log([1].flatMap<Record<string, number | string>>(() => [sharedRecord2]));
interface Dependent {
  id: string;
  deps: Set<string | number>;
}
console.log([["a", "b"]].flatMap<Dependent>((g) => g.map((name) => ({ id: name, deps: new Set([name.length]) }))));
console.log([1].flatMap<Map<string, number | string>>(() => ns.map((k) => new Map([["k", k]]))));
