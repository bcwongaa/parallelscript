// An array a flatMap callback returns in an array literal is a kept array unless it is new
// at each call: a const declared outside the callback holds the same array at each call,
// even if the callback is its only use, so copying it where an array of other elements goes
// would lose its identity (H05 review round 6, finding 1: copied silently, also in a
// conditional, a sorted const and a nested literal, and as a tuple's array field). A spread
// of a tuple moves a nested tuple literal's later elements to later fields (finding 2: the C
// was checked against a number field and copied into J silently), and a nested tuple literal
// under `as const` or `satisfies` is checked as the literal is (finding 4). The elements of a
// map's new tuples and of a spread in a nested literal are checked too, as are a spread's
// kept arrays (the parent's round 6 probes: copied silently). The same holds for D-094's
// regular conversions: a const used once in a loop, a function or a class's field is the
// same array at each pass (copied silently before).
interface J {
  x: number | string;
}
class C {
  constructor(public x: number) {}
}
const c = new C(1);
const out1 = [1];
console.log([1, 2].flatMap<(number | string)[]>(() => [out1]));
const out2 = [1];
console.log([1, 2].flatMap<(number | string)[]>((i) => [i > 0 ? out2 : [i]]));
const out3 = [3, 1];
console.log([1, 2].flatMap<(number | string)[]>(() => [out3.sort()]));
const out4 = [1];
console.log([1, 2].flatMap<(number | string)[][]>(() => [[out4]]));
const ws = ["w"];
console.log([1, 2].flatMap<[number, (string | number)[]]>((i) => [[i, ws]]));
const p: [number, number] = [1, 2];
console.log([1].flatMap<[number, number, J]>(() => [[...p, c]]));
console.log([1].flatMap<readonly [J, number]>(() => [[c, 1] as const]));
console.log([1].flatMap<[J, number]>(() => [[c, 1] satisfies [C, number]]));
const hs = [{ arr: [1] }];
console.log([1].flatMap<(number | string)[]>(() => hs.map((h) => h.arr)));
const once = [1];
const keep: (number | string)[][] = [];
for (let i = 0; i < 2; i++) {
  const r: (number | string)[][] = [once];
  keep.push(r[0]);
}
const base = [1, 2];
function make(): (number | string)[] {
  return base;
}
console.log(keep, make());
const ns = [1];
console.log([1].flatMap<[J, number]>(() => ns.map((m): [C, number] => [c, m])));
const cs: C[] = [c];
console.log([1].flatMap<J[]>(() => [[...cs]]));
const nested = [[1], [2]];
console.log([1].flatMap<(number | string)[]>(() => [...nested]));
console.log(
  [1].flatMap<(number | string)[]>((i) => {
    const a = [i];
    return [0, 1].map(() => a);
  }),
);
const fieldBase = [1];
class K {
  xs: (number | string)[] = fieldBase;
}
console.log(new K().xs);

// error: flatmap_kept_elements.pts:21:56 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:23:65 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:25:56 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:27:59 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:29:71 - error PTS1001: using a string[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:31:60 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
// error: flatmap_kept_elements.pts:32:55 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
// error: flatmap_kept_elements.pts:33:46 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
// error: flatmap_kept_elements.pts:35:66 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:39:37 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:48:72 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
// error: flatmap_kept_elements.pts:50:38 - error PTS1001: using a `C` as a `{x: number | string}`, whose `x` it doesn't provide with the same types, is not supported yet
// error: flatmap_kept_elements.pts:52:53 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:56:29 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:44:10 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
// error: flatmap_kept_elements.pts:61:29 - error PTS1001: using a number[] as a (number | string)[] where it may be changed or kept (a copy wouldn't show the changes; a new array, or one passed to a parameter that is only read, is copied) is not supported yet
