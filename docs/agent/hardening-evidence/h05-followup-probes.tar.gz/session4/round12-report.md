READY. I found no BLOCKING finding.

Against the commit `c158778d4`, the new build (cli7/suite6) never gives wrong output, a TypeError, a crash, a PTS9xxx or a panic where the commit gave Node's output or a compile error. That holds over 962 earlier probes and about 60 new probes; valgrind found no memory errors. Round 11's findings 1–5 are fixed. Two outcome changes vs r11 matter; both are NON-BLOCKING because the commit and the base behave the same:
- **Annotated consts.** The annotated-const skip (F3) brings back silent identity loss that r11 reported.
- **Hash maps, maps and arrays where an interface or a numeric Record goes.** These leaves are still not reported by flatMap's check (a pre-existing hole).

The harness wouldn't let me save `report.md` (subagents can't write report files), so this message is the report.

Scratch is `/tmp/h05r12.eD0Y`. Outputs are in `<dir>/out/<name>.{node,n12,r11,commit,base}`; in round 11's copied probes, `.new` is the r11 output. Builds:
- **n12 (new):** `/tmp/h05-r6/cli7/pts` with home `/tmp/h05-r6/suite6`
- **r11:** cli6/suite5
- **commit:** `/tmp/h05-close`
- **base:** `/tmp/h05-base`
- **Node:** v24 on a `.mts` copy

## Findings

### N1. NON-BLOCKING, medium-low, VERIFIED: an annotated const's initializer isn't walked, so kept values lose identity silently
The commit and the base do the same; r11 reported these. The cause is `pts/lower/arrays.go:635` (`initializer.Parent.Type() == nil`).

**`p/a/a01_annot_const_kept_identity.pts`** (round 11's ac/a6 plus a mutation):
```ts
interface H { arr: (number | string)[] }
const kept = [1];
const xs = [1, 2].flatMap<H>(() => { const a: H[] = [0].map(() => ({ arr: kept })); return a; });
kept.push(2);
console.log(JSON.stringify(xs));
```
- Node: `[{"arr":[1,2]},{"arr":[1,2]}]`
- new, commit, base: `[{"arr":[1]},{"arr":[1]}]`
- r11: `6:33 PTS1001 using a {arr: number[]} as a {arr: (number | string)[]}…`
- This is the regular C80 copy: the same const outside flatMap (`a02`) is wrong on every build.

**`p/a/a06_any_annot_const.pts`**: `const a: any[] = [kept]; return a;` into `flatMap<(number | string)[]>`.
- Node: `[[1,2],[1,2]]`
- new, commit, base: `[[1],[1]]`
- r11: `3:21 PTS1001`
- Here the copy isn't made at the declaration. `any[]` boxes `kept` as it is, and flatMap's own dynamic conversion copies it (D-071).
- So the comment, and D-181's "an annotated one's elements are converted to its type where it is declared", are false for `any[]` and `unknown[]` annotations.
- A cheap fix: keep walking when the annotation's elements are dynamic (`isDynamicArray`).

**`p/a/a08_annot_const_union_elem.pts`**: `const a: P[] = ns.map((m) => (m > 1 ? { a: m, z: m } : shared))`.
- Node: `[{"a":1,"z":7},…]`
- new, commit, base: `[{"a":1,"z":1},…]`
- r11: `8:41 PTS1001`
- This is C80 again.

### N2. NON-BLOCKING, medium, VERIFIED, pre-existing on every build: a hash-map, Map or array leaf where an interface or numeric Record goes isn't reported
`keepsLeaf` (`arrays.go:1033-1091`) has no arm for a `*ir.MapType` leaf with an Interface or Class target, and the array arm at `arrays.go:1059` approves any target that isn't an array. The regular conversion reports these cases; F4 only covered the union form, so the two are now inconsistent.

**`p/u/u11_kept_hashmap_into_iface.pts`**:
```ts
type HV = { [k: string]: number; v: number };
const h: HV = { v: 1, a: 2 };
const xs = [1].flatMap<{ v: number }>(() => [h]);
h.v = 5;
console.log(JSON.stringify(xs));
```
- Node: `[{"v":5,"a":2}]`
- new, r11, commit, base: `[{"v":1}]`
- The regular `const o: { v: number } = h` (`u13`) is PTS1001 on every build.

**`p/u/u07b_plain_only.pts`**: a computed-key literal through a mapper into `flatMap<{ v: number }>`.
- Node: `[{"v":1,"a":1},…]`
- every build: `[{"v":1},…]`
- Its union form (`u07a`, also round 11's `dup/d2`) is now correctly PTS1001 on new.

**`p/u/u14_map_into_iface.pts`**: a Map into `flatMap<{ size: number }>`.
- Node: `2`
- every build: `TypeError: Expected {size: number}, got Map`
- The regular conversion (`u15`) gives PTS1001.

**`p/u/u16_array_into_numeric_record.pts`**: a kept `number[]` into `flatMap<Record<number, number>>`.
- Node: `[[1,2,3]]`
- every build: `TypeError: Expected Record<string, number>, got Array`

The fix is a "converting X to Y" arm for these leaves (and an array-into-hash-map arm), or a ledger row. D-181's "Hash maps, maps and sets" bullet over-claims here, in both the draft and the repo version.

### N3. NON-BLOCKING, low, VERIFIED: new false PTS1001s from F4's object-into-hash-map arm
These compiled correctly on r11, the commit and the base.

**`p/u/u04b_alias_order_into_record.pts`**, with `type I = { b: number; a: number }`, into `flatMap<Record<string, number | string>>`:
- **Line 10:** `({ a: m, b: m * 2 }) as I` in a mapper.
- **Line 12:** `const v: I = {…}; return v` in a mapper.
- **new:** `PTS1001: using a {a: number; b: number} as a hash-map object (Record<string, number | string>)` on both lines.
- **Node, r11, commit, base:** `[{"a":1,"b":2},{"a":2,"b":4}] a,b`.

**`p/d/d05_spread_literal_record.pts`**: `({ ...base, a: m })` into `Record<string, number>`.
- new: PTS1001
- everyone else: `[{"z":0,"a":1},{"z":0,"a":2}]`

Annotating the mapper works around both (`u04c`, `u12`); annotating the const doesn't. Round 11's m12, m13 and m24 stay PTS1001 by design, but m13 (a function's result) and m24 (`Record<string, any>`) have no workaround. So the Reason's "have a workaround (annotate the mapper or the callback)" isn't always true.

Message nit: the regular message's hint "; a copy of its properties, `{ ...o }`, is one" is dropped in keepsLeaf's version (`dd3`).

### N4. NON-BLOCKING, low, VERIFIED, pre-existing: optional-tuple leaves inside a conditional element
**`p/v/v07`**: `[1, 2, 3].flatMap<[number, string?]>((i) => [i % 2 ? [i] : [i, "s"]])`
- Node: `[[1],[2,"s"],[3]]`
- new, r11, commit: `PTS1001 using a [number] as a [number, string | undefined]` at 1:65 and 1:71
- base: TypeError
- The plain form (`v08`) and the regular conditional (`v06`) work. This belongs in D-181's known gaps.

### N5. NON-BLOCKING, low: test gaps
None of these new branches has a test, so deleting any of them leaves the suite green:
- **`onlyRecordMember` approval:** an interface-typed literal into `Record<…> | null` or `| string`. In u01, u06, r05, v03, u09 and u10 the commit gives PTS1001 and new gives Node's output.
- **Per-property rejection of a kept value:** `p/d/d06` line 8, `({ kept })` into `Record<string, (number | string)[]>`.
- **The accessor fallback:** `p/d/d04`. r11, commit and base silently print `[{},{}] 0`, Node prints `[{"a":1},{"a":2}] 2`, new gives PTS1001.
- **The `hasOptionalFields` guard:** `p/u/u18a`. r11, commit and base silently print `a,b a,b`, Node prints `a a,b`, new gives PTS1001.

I suggest adding u01 and u06 lines to `flatmap_record_leaves.pts`, and d04, d06 and u18a lines to `flatmap_kept_elements.pts`.

### N6. NON-BLOCKING: D-181 claims
The draft `/tmp/h05-r6/d181.md` doesn't describe round 11's changes:
- `recordContext` (F1)
- the value-by-value check of new literals going where a hash map goes, with its fallbacks (F2)
- the annotated-const exception (F3)
- the union and object-into-hash-map arms (F4)

Its "checked by that type, as on the commit" is also wrong for objects into hash maps: the commit approved those silently.

The parent edited D-181 in `docs/DECISIONS.md` during this review, and that version covers F1–F4. These are still wrong or missing there:
- the hash-map bullet's over-claim (N2)
- the `any[]` case in the annotated-const rationale (N1)
- known gaps for:
  - N1 (a01 and a08 under C80, a06 under D-071)
  - N2
  - N3 (no workaround for m13 and m24)
  - N4

### N7. Nits
- `arrays.go:1031` is a 116-character comment line that wasn't rewrapped.
- The `keepsLeavesOf` doc comment doesn't mention the annotated-const exception.
- The `keepsObjectLiteral` doc says "of its own type", but the branch also covers a literal made as an annotated mapper's type.
- `any` still prints as `value` (pre-existing).
- `{ __proto__: m }` keeps a `__proto__` key on every build (`v04`); the regular literal does too, so it's outside H05.

## Round 11 status
1. **F1 fixed.** m30, m33, m35, m36 and m42 are OK on new (CE on r11).
2. **F2 fixed.** o14 (both copies), m29, m11 and m25 are OK. m12, m13 and m24 stay PTS1001 by design.
3. **F3 fixed.** a1 and a3 are OK. a6 is now silently wrong, as on the commit (N1).
4. **F4 fixed for unions and objects into Records.**
   - m01, m17, m18 and k15 went from wrong output to PTS1001, and m02 from TypeError to PTS1001.
   - k03 (wrong output) and k08 (TypeError) are now correctly PTS1001 too.
   - Interface targets are still open (N2).
5. **F5 fixed.** The errors-test header is accurate.

## Checked and fine
- **Sweep, 962 probes** (round 11's 870 representatives plus its 92 own):
  - No regression vs the commit, and no PTS9xxx or panic.
  - 22 probes changed outcome vs r11; all are explained above:
    - Fixed or improved: 12 compile errors became correct output, 4 wrong outputs and 1 TypeError became PTS1001.
    - dup/d2 is a correct new report.
    - Others are message or position changes only.
- **Tests:**
  - Each of the three new run tests' `// expect:` blocks equals Node's output and new's.
  - The errors tests' `// error:` lines equal new's output exactly and in order: 40/40 and 12/12.
  - The five new kept_elements errors are real identity losses or run-time TypeErrors.
  - The `flatmap_record_leaves` header claim holds: the commit and base print its expect block, r11 doesn't compile.
- **`objectLiteral` refactor:** `emit-c` from r11 and new is byte-identical (C and diagnostics) for 535 of the 537 run and errors tests; only the two flatMap tests differ. `o01` (HeadersInit-style unions, computed and enum keys, numeric-key interfaces, Partial<Record>, nested records) is OK on every build.
- **Record branch and unions:**
  - Correct output, identity checked by mutation, in r01–r06, u01, u02, u05b, u06, u09, u10, v01–v03, v05, v09, k01, k02 and k04–k07.
  - No double diagnostics (dd1–dd5, d01).
- **`.par.flatMap`:** at PTS_THREADS=1, 2 and 4 it equals Node's sequential run: `par2` three times each, and the GC-heavy `par3` with 400,000 `Record | null` leaves.
- **Memory:**
  - `pts build` plus `valgrind -q --undef-value-errors=no --error-exitcode=99` exits 0 with no reports on 11 binaries.
  - The full runs' undefined-value reports are all inside bdwgc's conservative scan.
  - The runtime's `convert_test.c` passes and is valgrind-clean.
- **Determinism and format:** the 8 determinism copies give identical output, and `gofmt -l pts/lower` is clean.
- **Repo:** I didn't edit the repo or `/tmp/h05-r6/suite6`; the code files still equal suite6's copies. The parent changed PROGRESS.md, DECISIONS.md, SPEC.md, h05.md and CONSOLIDATED.md, and added h05-review11-probes.tar.gz, during the review; none of that is mine.

## Commands
- `bin/one.sh <probe> node,n12,r11,commit,base` runs Node on a `.mts` copy, then `PTS_HOME=<home> <cli> run` for each build.
- The sweep ran `xargs -P 1` over `all.txt`; `bin/cmp.sh` classifies each probe and flags regressions and changes vs r11.
- Test checks: `awk` extraction of the expect blocks and `// error:` lines, compared with `cmp`.
- `pts emit-c` with r11 and new over copies of `pts/tests/{run,errors}`.
- `pts build`, then `PTS_THREADS=1|2|4` runs and valgrind.
- A `clang` build of `convert_test.c` against the cached runtime archives.
- `gofmt -l` and `git status`. Last step: `touch /tmp/h05-r6/review12.done` (done).

Files are in `/tmp/h05r12.eD0Y`:
- `cmp.txt`: sweep classification
- `sweep1.txt`, `sweep2.txt`: raw sweep logs
- `p/{u,r,k,a,d,dd,v,o,par}/`: my probes
- `tests/`: test-file checks
- `emit/all/`: the emit-c comparison
- `vg/`, `ct/`: valgrind runs and the convert test