// `case undefined` in a switch over a loose local of numbers (an array pattern's name, an element read).
const one: number[] = [1];
const [a, b] = one;
switch (b) {
  case undefined: console.log("pattern", "missing", a); break;
  case 1: console.log("pattern", "one");
}
const c = one[3];
switch (c) {
  case undefined: console.log("element", "missing"); break;
  default: console.log("element", c + 1);
}
