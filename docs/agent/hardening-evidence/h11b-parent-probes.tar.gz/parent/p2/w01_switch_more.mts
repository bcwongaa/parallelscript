// `case undefined` / `case null` / `case void 0` in more switches.
function show(label: string, f: () => void): void {
  try { f(); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
function nothing(): void {}
show("void tag", () => { switch (nothing()) { case undefined: console.log("void tag", "undefined"); break; default: console.log("void tag", "other"); } });
show("number param", () => { const k = (n: number) => { switch (n) { case undefined: return "u"; case 1: return "one"; default: return "d"; } }; console.log("number param", k(1), k(2)); });
show("void 0", () => { const xs = ["a"]; const c = xs[2]; switch (c) { case void 0: console.log("void 0", "missing"); break; default: console.log("void 0", c.length); } });
show("fallthrough", () => {
  const holey = new Array<string>(3); holey[1] = "m";
  for (const w of holey) { switch (w) { case null: case undefined: console.log("fallthrough", "none"); break; default: console.log("fallthrough", w.toUpperCase()); } }
});
show("number pattern", () => { const one: number[] = [1]; const [a, b] = one; switch (b) { case undefined: console.log("number pattern", "missing", a); break; case 1: console.log("number pattern", "one"); } });
class P { x = 1; }
show("object tag", () => {

  const ps = new Array<P>(2); ps[0] = new P();
  for (const p of ps) { switch (p) { case undefined: console.log("object tag", "hole"); break; default: console.log("object tag", p.x); } }
});
enum E { A = "a", B = "b" }
show("enum tag", () => {

  const es = new Array<E>(2); es[1] = E.B;
  for (const e of es) { switch (e) { case E.A: console.log("enum tag", "A"); break; case undefined: console.log("enum tag", "hole"); break; case E.B: console.log("enum tag", "B"); } }
});
show("case variable undefined", () => {
  const u = undefined;
  const holey = new Array<string>(2); holey[1] = "z";
  for (const w of holey) { switch (w) { case u: console.log("case variable undefined", "hole"); break; default: console.log("case variable undefined", w.length); } }
});
