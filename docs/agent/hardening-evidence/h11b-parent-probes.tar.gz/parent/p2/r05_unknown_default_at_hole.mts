// An element parameter of type unknown or any with a default, at a hole: JS applies the default.
function holes<T>(n: number, at: number, value: T): T[] { const a = new Array<T>(n); a[at] = value; return a; }
const strs = holes(3, 1, "b");
const seen: unknown[] = [];
strs.find((s: unknown = "D") => { seen.push(s); return false; });
console.log(seen);
const seen2: any[] = [];
strs.findLast((s: any = "D") => { seen2.push(s); return false; });
console.log(seen2);
console.log(Array.from(strs, (s: unknown = "D") => s));
console.log(Array.from({ length: 2 }, (v = 5) => v));
function g(v: unknown = 5): unknown { return v; }
const u: unknown = undefined;
console.log(g(u), g(undefined), g());
