// `case undefined` in a switch over a number parameter (a type without undefined).
function k(n: number): string {
  switch (n) {
    case undefined: return "u";
    case 1: return "one";
    default: return "d";
  }
}
console.log(k(1), k(2));
