// A D-090 loose local (an element read tested for undefined) narrowed by a lying type
// predicate to a member of its union it doesn't hold.
function isStr(v: string | number): v is string { return true; }
const xs: (string | number)[] = [42, "abc"];
for (let i = 0; i < 3; i++) {
  const v = xs[i];
  if (v === undefined) { console.log("missing"); continue; }
  try {
    if (isStr(v)) console.log("len", v.length, v.toUpperCase());
  } catch (e) { console.log("caught", (e as Error).message); }
}
