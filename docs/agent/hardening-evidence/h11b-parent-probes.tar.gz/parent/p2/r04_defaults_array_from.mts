console.log(Array.from({ length: 3 }, (_v, i = 7) => i));
console.log(Array.from({ length: 2 }, (v = 5) => v));
console.log(Array.from({ length: 2 }, (v: unknown = 5, i = 0) => String(v) + i));
console.log(Array.from("abc", (c = "z", i = 0) => c + i));
console.log(Array.from(new Set(["x", "y"]), (s = "d", i = 0) => s + i));
console.log(Array.from(new Map([["k", 1]]).keys(), (k = "d") => k));
function* gen(): Generator<number> { yield 1; yield 2; }
console.log(Array.from(gen(), (n = 0, i = 0) => n + i));
const f = new Float64Array([1, 2]);
console.log(Array.from(f, (x = 0) => x + 1));
console.log(Array.from(["a", "b"], (s = "d", i = 0) => s + i));
console.log(Array.from([1, 2], (n = 0) => n * 2));
