// A D-090 loose local of a union of a tuple and a string, narrowed to the tuple, then
// changed by a closure to a string: its read must stay checked (D-140).
type Pair = [number, string];
const xs: (Pair | string)[] = [[1, "a"]];
function run(): void {
  let v = xs[0];
  if (v === undefined) return;
  const change = () => { v = "str"; };
  if (typeof v !== "string") {
    change();
    try { console.log("d090", v[1].length, v[0] + 1); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
  }
}
run();
console.log("end");
