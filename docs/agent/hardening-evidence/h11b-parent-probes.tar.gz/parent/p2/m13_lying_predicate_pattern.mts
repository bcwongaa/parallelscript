// A D-220 array pattern's name narrowed by a lying type predicate.
function isStr(v: string | number): v is string { return true; }
const xs: (string | number)[] = [42, "abc"];
const [a, b] = xs;
try {
  if (isStr(a)) console.log("len", a.length, a.toUpperCase());
} catch (e) { console.log("caught", (e as Error).message); }
console.log(b);
