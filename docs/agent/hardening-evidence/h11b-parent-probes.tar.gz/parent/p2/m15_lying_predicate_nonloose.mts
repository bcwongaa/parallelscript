// The same lying predicate over a local that isn't loose (no element read): pre-existing?
function isStr(v: string | number): v is string { return true; }
function get(): string | number { return 42; }
const v = get();
try {
  if (isStr(v)) console.log("len", v.length, v.toUpperCase());
} catch (e) { console.log("caught", (e as Error).message); }
console.log("end");
