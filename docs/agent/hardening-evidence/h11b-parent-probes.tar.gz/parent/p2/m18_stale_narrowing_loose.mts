// A loose local's narrowing that a call made stale stays checked (D-140): for…of, D-090, pattern.
function show(label: string, f: () => void): void {
  try { f(); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
class A { a = "aa"; }
class B { b = 7; }
show("for...of union", () => {
  const xs: (string | number)[] = ["abc"];
  for (let v of xs) {
    const change = () => { v = 5; };
    if (typeof v === "string") { change(); console.log("for...of union", v.length); }
  }
});
show("d090 union", () => {
  const xs: (string | number)[] = ["abc"];
  let v = xs[0];
  if (v === undefined) return;
  const change = () => { v = 5; };
  if (typeof v === "string") { change(); console.log("d090 union", v.toUpperCase()); }
});
show("pattern union", () => {
  const xs: (string | number)[] = ["abc"];
  let [v] = xs;
  const change = () => { v = 5; };
  if (typeof v === "string") { change(); console.log("pattern union", v.toUpperCase()); }
});
show("for...of classes", () => {
  const xs: (A | B)[] = [new A()];
  for (let v of xs) {
    const change = () => { v = new B(); };
    if (v instanceof A) { change(); console.log("for...of classes", v.a.length); }
  }
});
show("for...of own undefined", () => {
  const xs: string[] = ["abc"];
  for (let v of xs) {
    const change = () => { v = undefined!; };
    if (v !== undefined) { change(); console.log("for...of own undefined", v.length); }
  }
});
show("for...of interface", () => {
  interface I { n: number }
  const xs: (I | string)[] = [{ n: 1 }];
  for (let v of xs) {
    const change = () => { v = "str"; };
    if (typeof v === "object") { change(); console.log("for...of interface", v.n); }
  }
});
