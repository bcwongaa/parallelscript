// A for…of variable over (Pair | string)[] narrowed to the tuple, changed by a closure.
type Pair = [number, string];
const xs: (Pair | string)[] = [[1, "a"]];
for (let v of xs) {
  const change = () => { v = "str"; };
  if (typeof v !== "string") {
    change();
    try { console.log("forof", v[1].length, v[0] + 1); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
  }
}
console.log("end");
