// A D-090 loose local of a union of a tuple and a number, narrowed by a lying predicate to the tuple.
type Pair = [number, string];
function isPair(v: Pair | number): v is Pair { return true; }
const xs: (Pair | number)[] = [7];
const v = xs[0];
if (v === undefined) console.log("tested");
try { if (isPair(v)) console.log("pair", v[1].length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
console.log("end");
