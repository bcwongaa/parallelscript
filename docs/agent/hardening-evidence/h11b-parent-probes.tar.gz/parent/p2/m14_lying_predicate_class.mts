// A D-090 loose local of a union of classes narrowed by a lying predicate.
class A { a: string; constructor() { this.a = "aa"; } }
class B { b: number; constructor() { this.b = 7; } }
function isA(v: A | B): v is A { return true; }
const xs: (A | B)[] = [new B(), new A()];
for (let i = 0; i < 3; i++) {
  const v = xs[i];
  if (v === undefined) { console.log("missing"); continue; }
  try {
    if (isA(v)) console.log("a", v.a.length);
  } catch (e) { console.log("caught", (e as Error).message); }
}
