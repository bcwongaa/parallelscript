// An array pattern's name (D-220) of a union of an object literal type and a number,
// narrowed to the object type, then changed by a closure to a number.
type Pt = { x: number; y: number };
const xs: (Pt | number)[] = [{ x: 1, y: 2 }];
function run(): void {
  let [v] = xs;
  const change = () => { v = 42; };
  if (typeof v === "object") {
    change();
    try { console.log("pattern", v.x, v.y); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
  }
}
run();
console.log("end");
