class Val {
  valueOf(): number {
    return 3;
  }
  toString(): string {
    return "V";
  }
}
const vals = [new Val()];
const strs = ["a"];
console.log(vals[0] + strs[0], strs[0] + vals[0]);
const [v] = vals;
console.log(v + strs[0], strs[0] + v);
type Kind = "x" | "y";
const kinds: Kind[] = ["x"];
console.log(kinds[0] + strs[0], kinds[0] + kinds[3]);
