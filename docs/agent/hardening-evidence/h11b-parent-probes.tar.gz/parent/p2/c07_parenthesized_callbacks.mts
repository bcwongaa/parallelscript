// A parenthesized callback with a default or optional element parameter, at a hole.
function show(label: string, f: () => void): void {
  try { f(); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message); }
}
function holes<T>(n: number, at: number, value: T): T[] { const a = new Array<T>(n); a[at] = value; return a; }
show("paren from default", () => { console.log("paren from default", Array.from(holes(2, 1, "q"), ((s = "d") => s))); });
show("paren find default", () => { console.log("paren find default", holes(2, 1, "q").findIndex(((s = "d") => s === "d"))); });
show("paren find optional", () => { console.log("paren find optional", holes(2, 1, "q").findIndex(((s?: string) => s === undefined))); });
show("as cast default", () => { console.log("as cast default", holes(2, 1, "q").findIndex(((s = "d") => s === "d") as (s?: string) => boolean)); });
