// The same through a local that isn't loose: pre-existing?
type Pair = [number, string];
function get(): Pair | string { return [1, "a"]; }
function run(): void {
  let v = get();
  const change = () => { v = "str"; };
  if (typeof v !== "string") {
    change();
    try { console.log("plain", v[1].length, v[0] + 1); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
  }
}
run();
console.log("end");
