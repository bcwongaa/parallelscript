// The same uses for a D-090 loose local (an element read tested for undefined): pre-existing?
const strs: string[] = ["a"];
function show(label: string, f: () => void): void {
  try { f(); } catch (e) { console.log(label, "threw", (e as Error).name); }
}
show("void", () => { const v = strs[3]; if (v === undefined) console.log("tested"); console.log("void", void v); });
show("plus-eq string", () => { let v = strs[3]; if (v === undefined) console.log("tested"); v += "x"; console.log("plus-eq string", v); });
show("plus string", () => { let v = strs[3]; if (v === undefined) console.log("tested"); console.log("plus string", v + "x"); });
