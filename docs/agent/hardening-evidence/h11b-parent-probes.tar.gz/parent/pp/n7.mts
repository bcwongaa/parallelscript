function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
show("any call", () => {
  const f: any = (w?: string) => w ?? "-";
  console.log("any call", f(undefined), f("x"), f());
});
show("any from", () => {
  const a: any = ["a", undefined, "b"];
  console.log("any from", Array.from(a, (w?: string) => w ?? "-"));
});
show("any map", () => {
  const a: any = ["a", undefined];
  console.log("any map", a.map((w?: string) => w ?? "-"));
});
