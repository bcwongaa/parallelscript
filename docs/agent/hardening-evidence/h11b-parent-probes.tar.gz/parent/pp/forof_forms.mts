class Point {
  x: number;
  constructor(x: number) {
    this.x = x;
  }
}
function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
function holey<T>(n: number, at: number, v: T): T[] {
  const a = new Array<T>(n);
  a[at] = v;
  return a;
}
show("values", () => { for (const w of holey(3, 1, "b").values()) console.log("values", w ?? "hole"); });
show("let", () => { for (let w of holey(2, 1, "b")) { w = w ?? "z"; console.log("let", w); } });
show("plain log", () => { for (const w of holey(2, 1, "b")) console.log("plain log", w); });
show("untested use", () => { for (const w of holey(2, 1, "b")) console.log("untested use", w.length); });
show("pass to string param", () => { const f = (s: string) => s + "!"; for (const w of holey(2, 0, "b")) console.log("pass", f(w)); });
show("store", () => { const out: string[] = []; for (const w of holey(2, 0, "b")) out.push(w); console.log("store", out); });
show("closure", () => { const fs: (() => string)[] = []; for (const w of holey(2, 1, "b")) fs.push(() => w ?? "cap-hole"); console.log("closure", fs.map((f) => f())); });
function gen<T>(xs: T[]): string[] { const out: string[] = []; for (const x of xs) out.push(x === undefined ? "u" : String(x)); return out; }
show("generic string", () => console.log("generic string", gen(holey(2, 1, "q"))));
show("generic number", () => console.log("generic number", gen([1, 2, 3])));
show("null union", () => { const a = new Array<string | null>(2); a[0] = null; for (const w of a) console.log("null union", w); });
show("union objects", () => { const a = new Array<Point | string>(2); a[1] = "s"; for (const w of a) console.log("union objects", w === undefined ? "hole" : typeof w); });
show("functions", () => { const a = new Array<() => number>(2); a[0] = () => 7; for (const f of a) console.log("functions", f?.()); });
show("readonly", () => { const a: readonly string[] = holey(2, 1, "r"); for (const w of a) console.log("readonly", w ?? "hole"); });
show("rows", () => { const rows: string[][] = new Array<string[]>(2); rows[1] = ["a"]; for (const row of rows) console.log("rows", row?.length ?? "hole"); });
show("break continue", () => { outer: for (const w of holey(4, 2, "c")) { if (w === undefined) continue outer; console.log("bc", w); break; } });
show("object pattern", () => { for (const { x } of holey(2, 1, new Point(1))) console.log("object pattern", x); });
show("instanceof", () => { for (const p of holey(2, 1, new Point(4))) console.log("instanceof", p instanceof Point ? p.x : "not"); });
show("bools", () => { for (const b of [true, false]) console.log("bools", b); });
function* g(): Generator<string> { for (const w of holey(2, 1, "y")) yield w ?? "gh"; }
show("generator", () => console.log("generator", [...g()]));
show("entries", () => { for (const [i, w] of holey(2, 1, "e").entries()) console.log("entries", i, w ?? "hole"); });
