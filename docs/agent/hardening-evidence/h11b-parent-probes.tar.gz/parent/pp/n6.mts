const words = ["a", "b"];
let n = 0;
console.log(Array.from(words, (w, i) => {
  if (n < 2) words.push("n" + n++);
  return w + i;
}));
const shrink = ["a", "b", "c"];
console.log(Array.from(shrink, (w) => {
  shrink.length = 1;
  return w;
}));
const nums = [1, 2];
console.log(Array.from(nums, (x) => {
  if (nums.length < 4) nums.push(x * 10);
  return x;
}));
