function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
const words = ["a"];
show("element number", () => console.log("element number", words[5] + 1));
show("element string", () => console.log("element string", words[5] + "!"));
show("element bool", () => console.log("element bool", true + words[5]));
show("present", () => console.log("present", words[0] + 1, 2 + words[0]));
show("loose number", () => {
  const [a, b] = words;
  console.log("loose number", b + 1);
});
show("loose string", () => {
  const [a, b] = words;
  console.log("loose string", b + "?", a + 1);
});
show("for...of", () => {
  const holey = new Array<string>(2);
  holey[1] = "z";
  for (const w of holey) console.log("for...of", w + "!", w + 1);
});
show("template", () => {
  const [a, b] = words;
  console.log("template", `${b}-${a}`);
});
show("number union", () => {
  const n: number | null = null;
  console.log("number union", words[3] + n);
});
