class Point {
  x: number;
  constructor(x: number) {
    this.x = x;
  }
}
function points(): Point[] {
  const a = new Array<Point>(3);
  a[1] = new Point(1);
  return a;
}
function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
show("map optional", () => {
  const m = new Map<string, string | undefined>([["a", "x"], ["b", undefined]]);
  m.forEach((v?: string, k?: string) => console.log("map optional", k, v ?? "none"));
});
