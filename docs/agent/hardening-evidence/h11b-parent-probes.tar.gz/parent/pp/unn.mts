function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
show("typeof", () => {
  const vals: (string | number)[] = ["a"];
  const v = vals[3];
  if (typeof v !== "number") console.log("typeof", v, `${v}`);
});
show("pattern", () => {
  const rows: (string | number)[] = [1];
  const [a, b] = rows;
  if (typeof b !== "number") console.log("pattern", a, b);
});
show("for...of", () => {
  const holey = new Array<string | number>(2);
  holey[1] = 2;
  for (const w of holey) if (typeof w !== "number") console.log("for...of", w);
});
