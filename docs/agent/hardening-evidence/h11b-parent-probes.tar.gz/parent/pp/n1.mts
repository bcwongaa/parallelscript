function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name, (e as Error).message);
  }
}
function kind(s: string): string {
  switch (s) {
    case undefined:
      return "missing";
    case "a":
      return "a";
    default:
      return "other";
  }
}
show("parameter", () => console.log("parameter", kind("a"), kind("b")));
show("element local", () => {
  const xs = ["a"];
  const c = xs[3];
  switch (c) {
    case undefined:
      console.log("element local", "missing");
      break;
    default:
      console.log("element local", c);
  }
});
show("for...of", () => {
  const holey = new Array<string>(2);
  holey[1] = "z";
  for (const w of holey) {
    switch (w) {
      case undefined:
        console.log("for...of", "hole");
        break;
      case "z":
        console.log("for...of", "z");
    }
  }
});
show("null case", () => {
  const xs = ["q"];
  const [p, q] = xs;
  switch (q) {
    case null:
      console.log("null case", "null");
      break;
    case undefined:
      console.log("null case", "undefined");
      break;
    default:
      console.log("null case", q);
  }
});
