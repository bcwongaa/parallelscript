const fns: (() => number)[] = [() => 7];
const f = fns[3];
console.log("decl", f?.());
const g = fns[0];
console.log("decl present", g?.());
function holey(): (() => number)[] {
  const a = new Array<() => number>(2);
  a[0] = () => 7;
  return a;
}
for (const h of holey()) console.log("forof", h?.());
const [p, q] = holey();
console.log("pattern", p?.(), q?.());
