function nullable(): (string | null)[] {
  const a = new Array<string | null>(4);
  a[0] = "a";
  a[2] = null;
  a[3] = "dd";
  return a;
}
function lengths(xs: (string | null)[]): string {
  const out: string[] = [];
  for (const x of xs) {
    out.push(x !== null ? String(x.length) : "null");
  }
  return out.join(",");
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
show("toSorted", () => nullable().toSorted());
show("toReversed", () => nullable().toReversed());
show("toSpliced", () => nullable().toSpliced(0, 1));
show("with", () => nullable().with(0, "z"));
show("spread", () => [...nullable()]);
show("from", () => Array.from(nullable()));
show("read toSorted", () => lengths(nullable().toSorted()));
show("read with", () => lengths(nullable().with(1, "b")));
show("read spread", () => lengths([...nullable()]));
const viaAny: any = nullable();
show("any toSorted", () => viaAny.toSorted());
show("any with", () => viaAny.with(0, "z"));
show("any read", () => lengths(viaAny.toReversed()));

