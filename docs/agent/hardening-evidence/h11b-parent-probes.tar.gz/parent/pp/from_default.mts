class Point {
  x: number;
  constructor(x: number) {
    this.x = x;
  }
}
function points(): Point[] {
  const a = new Array<Point>(3);
  a[1] = new Point(1);
  return a;
}
const origin = new Point(-5);
console.log(Array.from(points(), (p: Point = origin) => p.x));
