function holey(): (() => number)[] {
  const a = new Array<() => number>(2);
  a[0] = () => 7;
  return a;
}
function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
show("forof", () => { for (const h of holey()) console.log("forof", h?.()); });
show("pattern", () => { const [p, q] = holey(); console.log("pattern", p?.(), q?.()); });
show("decl", () => { const fns = holey(); const f = fns[1]; console.log("decl", f?.()); });
