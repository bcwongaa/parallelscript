class Point {
  x: number;
  constructor(x: number) {
    this.x = x;
  }
}
function points(): Point[] {
  const a = new Array<Point>(3);
  a[1] = new Point(1);
  return a;
}
function show(label: string, f: () => void): void {
  try {
    f();
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
const origin = new Point(-5);
show("default", () => console.log("default", points().map((p) => p.x), points().findIndex((p: Point = origin) => p.x === -5)));
show("from default", () => console.log("from default", Array.from(points(), (p: Point = origin) => p.x)));
show("from default index", () => console.log("from default index", Array.from(points(), (p: Point = origin, i?: number) => p.x + (i ?? 0))));
show("findLast default", () => console.log("findLast default", points().findLast((p: Point = origin) => p.x < 0)));
show("null param", () => console.log("null param", points().findIndex((p: Point | null) => p === null)));
show("nums optional shrink", () => {
  const xs = [1, 2, 3];
  const seen: unknown[] = [];
  const r = xs.find((n?: number, i?: number) => { if (i === 0) xs.length = 1; seen.push(n); return false; });
  console.log("nums optional shrink", seen, r);
});
show("nums required shrink", () => {
  const xs = [1, 2, 3];
  const seen: unknown[] = [];
  const r = xs.findIndex((n: number, i: number) => { if (i === 0) xs.length = 1; seen.push(n); return false; });
  console.log("nums required shrink", seen, r);
});
show("bools union shrink", () => {
  const xs = [true, false, true];
  const seen: unknown[] = [];
  const r = xs.findLastIndex((b: boolean | undefined, i: number) => { if (i === 2) xs.length = 1; seen.push(b); return false; });
  console.log("bools union shrink", seen, r);
});
show("map optional", () => {
  const m = new Map<string, string | undefined>([["a", "x"], ["b", undefined]]);
  m.forEach((v?: string, k?: string) => console.log("map optional", k, v ?? "none"));
});
show("filter optional words", () => console.log("filter optional", ["a", "b"].filter((w?: string) => w !== "a")));
show("reduce optional", () => console.log("reduce optional", ["a", "b"].reduce((acc: string, w?: string) => acc + (w ?? "?"), "")));
show("any arr optional", () => {
  const a: any[] = new Array(2);
  a[1] = new Point(3);
  console.log("any arr optional", a.findIndex((p?: Point) => p === undefined));
});
show("maybe arr optional", () => {
  const a: (Point | undefined)[] = [undefined, new Point(3)];
  console.log("maybe arr optional", a.findIndex((p?: Point) => p !== undefined));
});
