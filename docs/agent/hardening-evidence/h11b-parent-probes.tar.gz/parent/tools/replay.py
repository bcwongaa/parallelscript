"""Replay a review round's probes with a CLI and classify them against the round's
recorded Node and base outputs (out/<name>.node, out/<name>.base).

Usage: python3 -I replay.py ROUND_DIR CLI HOME OUTDIR [--jobs N]
REGRESSION: base matched Node, the CLI doesn't; FIXED: the CLI matches Node, base didn't;
STILL: neither matches Node; SAME: both match.
"""
import os, subprocess, sys, glob
from concurrent.futures import ThreadPoolExecutor

def norm(text):
    return "\n".join(l for l in text.split("\n") if not l.startswith("exit=")).strip()

def run(args):
    path, cli, home, outdir = args
    name = os.path.basename(path)[:-4]
    env = dict(os.environ, TZ="America/New_York", PTS_HOME=home)
    exe = os.path.join(outdir, name + ".bin")
    b = subprocess.run([cli, "build", path, "-o", exe], env=env, capture_output=True, text=True, timeout=600)
    if b.returncode != 0:
        out = "BUILD FAILED:\n" + "\n".join(l for l in (b.stdout + b.stderr).split("\n") if "error" in l or "PTS" in l)[:600]
    else:
        try:
            r = subprocess.run([exe], env=env, capture_output=True, text=True, timeout=30)
            out = r.stdout
        except subprocess.TimeoutExpired:
            out = "TIMEOUT"
        os.remove(exe)
    open(os.path.join(outdir, name + ".new"), "w").write(out)
    return name, out

def main():
    round_dir, cli, home, outdir = sys.argv[1:5]
    jobs = int(sys.argv[sys.argv.index("--jobs") + 1]) if "--jobs" in sys.argv else 2
    os.makedirs(outdir, exist_ok=True)
    files = sorted(set(glob.glob(os.path.join(round_dir, "repro", "*.pts")) + glob.glob(os.path.join(round_dir, "probes", "**", "*.pts"), recursive=True)))
    counts = {}
    with ThreadPoolExecutor(jobs) as ex:
        for name, out in ex.map(run, [(f, cli, home, outdir) for f in files]):
            nodef, basef = os.path.join(round_dir, "out", name + ".node"), os.path.join(round_dir, "out", name + ".base")
            if not os.path.exists(nodef):
                cls = "NONODE"
            else:
                node = norm(open(nodef).read())
                base = norm(open(basef).read()) if os.path.exists(basef) else None
                new = norm(out)
                if new == node:
                    cls = "SAME" if base == node else "FIXED"
                else:
                    cls = "REGRESSION" if base == node else "STILL"
            counts[cls] = counts.get(cls, 0) + 1
            print(cls, name, flush=True)
    print(counts)

main()
