#!/bin/bash
# cmp.sh file.mts [cli...]: run Node on file.mts, then each CLI's build of a .pts copy; print diffs.
set -u
f=$1; shift
d=$(dirname $f); b=$(basename $f .mts)
cp $f $d/$b.pts
~/.local/node/bin/node $f > $d/$b.node.txt 2>&1
for cli in "$@"; do
  home=$(dirname $(dirname $cli))
  tag=$(echo $home | tr '/' '_')
  if PTS_HOME=$home $cli build -o $d/$b.bin $d/$b.pts > $d/$b.build.txt 2>&1; then
    $d/$b.bin > $d/$b.$tag.txt 2>&1; rm -f $d/$b.bin
  else
    cp $d/$b.build.txt $d/$b.$tag.txt
  fi
  echo "== $cli"
  diff $d/$b.node.txt $d/$b.$tag.txt > /dev/null && echo SAME || diff $d/$b.node.txt $d/$b.$tag.txt | head -${DIFFN:-20}
done
