"""Replay probes: Node (transform-types) vs several CLIs; classify each CLI against Node and flag regressions of the last CLI."""
import glob, os, subprocess, sys, json, hashlib
from concurrent.futures import ThreadPoolExecutor
NODE = os.path.expanduser("~/.local/node/bin/node")
clis = [("base", "/tmp/h11b/base/pts-bin/pts", "/tmp/h11b/base"), ("snap3", "/tmp/h11b/snap3/pts-bin/pts", "/tmp/h11b/snap3"), ("new", sys.argv[1], sys.argv[2])]
files = sys.argv[4:]
out = sys.argv[3]
work = "/tmp/h11b/replay"; os.makedirs(work, exist_ok=True)
def run(cmd, env=None, timeout=60):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return -999, "", "TIMEOUT"
def one(f):
    base = os.path.basename(f)[:-4]
    mts = os.path.join(work, base + ".mts")
    open(mts, "w").write("\n".join(l for l in open(f).read().split("\n") if not l.startswith("// skip:")))
    nc, no, ne = run([NODE, "--no-warnings", "--experimental-transform-types", mts])
    res = {"file": f, "node": [nc, no]}
    for tag, cli, home in clis:
        b = os.path.join(work, base + "." + tag + ".bin")
        bc, bo, be = run([cli, "build", "-o", b, f], env=dict(os.environ, PTS_HOME=home), timeout=300)
        if bc != 0:
            res[tag] = ["BUILD", (bo + be).strip().split("\n")[0][:200]]
            continue
        rc, ro, re_ = run([b])
        os.remove(b)
        res[tag] = [rc, ro, re_.strip().split("\n")[0][:200]]
    return res
with ThreadPoolExecutor(2) as ex:
    results = list(ex.map(one, files))
with open(out, "w") as fh:
    for r in results: fh.write(json.dumps(r) + "\n")
def cls(r, tag):
    v = r[tag]
    if v[0] == "BUILD": return "BUILD"
    if v[1] == r["node"][1] and (v[0] == 0) == (r["node"][0] == 0): return "MATCH"
    if v[0] == 139 or v[0] < 0: return "CRASH%d" % v[0]
    return "DIFF"
counts = {}
for r in results:
    c = tuple(cls(r, t) for t, _, _ in clis)
    counts[c] = counts.get(c, 0) + 1
    if c[2] != "MATCH" and (c[0] == "MATCH" or c[1] == "MATCH"):
        print("REGRESSION?", r["file"], c)
    if c[2].startswith("CRASH"):
        print("CRASH", r["file"], c)
for c, n in sorted(counts.items(), key=lambda x: -x[1]): print(n, c)
