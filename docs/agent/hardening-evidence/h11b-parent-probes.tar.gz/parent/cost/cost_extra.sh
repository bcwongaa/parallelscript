#!/bin/bash
# Callgrind instruction counts (Ir) of the cost probes, built by one CLI: each probe run
# with its loop repeated REPS times and 0 times (setup only), so the loop's own count is
# the difference. Checks each probe's output against Node first. Binaries deleted after.
# Usage: cost.sh LABEL PTS_BINARY [REPS]
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
label="$1"
pts="$2"
reps="${3:-20}"
D=/tmp/h11b/repro/cost
out="$D/results_extra_$label.txt"
: > "$out"
for src in "$D"/extra/cost_*.pts; do
  n=$(basename "$src" .pts)
  bin="$D/$n.$label.bin"
  PTS_HOME="$W" "$pts" build "$src" -o "$bin" > "$D/$n.$label.build.log" 2>&1 || { echo "$n build failed" >> "$out"; continue; }
  tmp=$(mktemp -d "$D/node-XXXX")
  cp "$src" "$tmp/$n.mts"
  node_out=$(~/.local/node/bin/node --no-warnings --experimental-transform-types "$tmp/$n.mts" 2)
  rm -rf "$tmp"
  pts_out=$("$bin" 2)
  for r in "$reps" 0; do
    valgrind --tool=callgrind --callgrind-out-file=/dev/null "$bin" "$r" > /dev/null 2> "$D/$n.$label.r$r.vg"
  done
  ir=$(grep -o 'Collected : [0-9]*' "$D/$n.$label.r$reps.vg" | grep -o '[0-9]*')
  ir0=$(grep -o 'Collected : [0-9]*' "$D/$n.$label.r0.vg" | grep -o '[0-9]*')
  same=$([ "$node_out" = "$pts_out" ] && echo same || echo "DIFF(node=$node_out pts=$pts_out)")
  echo "$n reps=$reps Ir=$ir setup=$ir0 loop=$((ir - ir0)) output_vs_node(reps=2)=$same" >> "$out"
  rm -f "$bin"
done
cat "$out"
