#!/usr/bin/env python3
"""Differential runner for H12 cases.

usage: runner.py --cli PTS --home PTS_HOME --cases DIR --out results.jsonl [--jobs N] [--filter REGEX]
                 [--node-cache node.jsonl]

DIR holds <id>.pts files and cases.jsonl (one object per case: id, family, expect, no_node, note).
Each case is copied to a fresh work dir as p.pts and p.mts; Node runs the .mts copy (strict ESM),
pts builds p.pts to a binary that runs with a 20 s timeout; the work dir (and binary) is deleted
right after. Node results are cached per case text (sha1) in --node-cache so reruns against
another CLI only build and run pts.

Classes: OK (stdout and exit code equal Node's), WRONG, TypeError, RangeError (pts threw where
Node's stdout/rc differ), PTS1001, PTS9001 (or exit 3 internal error), COMPILE (another compile
error), crash (signal), timeout. For no_node cases the class is OK when pts's stdout equals the
case's `expect_stdout` (if given) and it exits 0.
"""
import argparse, concurrent.futures as cf, hashlib, json, os, re, shutil, subprocess, sys, tempfile, threading, time

NODE = os.path.expanduser("~/.local/node/bin/node")
WORK = "/tmp/h12/review5/matrix/work"


def run(cmd, cwd, timeout, env=None):
    t0 = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, timeout=timeout, env=env)
        return p.returncode, p.stdout.decode("utf-8", "replace"), p.stderr.decode("utf-8", "replace"), time.time() - t0
    except subprocess.TimeoutExpired as e:
        return "timeout", (e.stdout or b"").decode("utf-8", "replace"), (e.stderr or b"").decode("utf-8", "replace"), time.time() - t0


def first_error(stderr):
    for line in stderr.splitlines():
        m = re.search(r"\b(TypeError|RangeError|ReferenceError|SyntaxError|Error)\b:?.*", line)
        if m and not line.startswith("    at "):
            return line.strip()[:300]
    return ""


def classify(case, node, build, prun):
    if build["rc"] == "timeout":
        return "timeout"
    if build["rc"] != 0:
        err = build["stderr"]
        if build["rc"] == 3 or "PTS9001" in err:
            return "PTS9001"
        if "PTS1001" in err:
            return "PTS1001"
        return "COMPILE"
    if prun["rc"] == "timeout":
        return "timeout"
    if isinstance(prun["rc"], int) and prun["rc"] < 0:
        return "crash"
    if case.get("no_node"):
        want = case.get("expect_stdout")
        if (want is None or prun["stdout"] == want) and prun["rc"] == case.get("expect_rc", 0):
            return "OK"
    elif node is not None and prun["stdout"] == node["stdout"] and prun["rc"] == node["rc"]:
        return "OK"
    err = prun["stderr"]
    if "TypeError" in err:
        return "TypeError"
    if "RangeError" in err:
        return "RangeError"
    if prun["rc"] in (134, 139, 132, 136):
        return "crash"
    return "WRONG"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cli", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--cases", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--filter", default="")
    ap.add_argument("--node-cache", default="")
    ap.add_argument("--every", type=int, default=1, help="run every Nth case only (a quick stratified look)")
    ap.add_argument("--ids", default="", help="a file of case ids to run (one per line)")
    args = ap.parse_args()

    listing = os.path.join(args.cases, "cases.jsonl")
    if os.path.exists(listing):
        cases = [json.loads(l) for l in open(listing)]
    else:  # every .pts file in DIR, expected to match Node
        cases = [{"id": n[:-4], "family": os.path.basename(os.path.abspath(args.cases)), "expect": "node"}
                 for n in sorted(os.listdir(args.cases)) if n.endswith(".pts")]
    if args.filter:
        rx = re.compile(args.filter)
        cases = [c for c in cases if rx.search(c["id"])]
    if args.ids:
        wanted = set(l.strip() for l in open(args.ids) if l.strip())
        cases = [c for c in cases if c["id"] in wanted]
    if args.every > 1:
        cases = cases[::args.every]
    cache, lock = {}, threading.Lock()
    if args.node_cache and os.path.exists(args.node_cache):
        for l in open(args.node_cache):
            r = json.loads(l)
            cache[r["sha"]] = r
    os.makedirs(WORK, exist_ok=True)
    env = dict(os.environ, PTS_HOME=args.home, TZ="America/New_York")

    def one(case):
        src = open(os.path.join(args.cases, case["id"] + ".pts")).read()
        sha = hashlib.sha1(src.encode()).hexdigest()
        d = tempfile.mkdtemp(prefix=case["id"][:40] + ".", dir=WORK)
        try:
            open(os.path.join(d, "p.pts"), "w").write(src)
            node = None
            if not case.get("no_node"):
                with lock:
                    node = cache.get(sha)
                if node is None:
                    open(os.path.join(d, "p.mts"), "w").write(src)
                    rc, out, err, _ = run([NODE, "--experimental-transform-types", "--no-warnings", "p.mts"], d, 20, env)
                    node = {"sha": sha, "rc": rc, "stdout": out, "error": first_error(err)}
                    with lock:
                        cache[sha] = node
            rc, out, err, bt = run([args.cli, "build", "p.pts", "-o", "p.bin"], d, 300, env)
            build = {"rc": rc, "stderr": err, "secs": round(bt, 2)}
            prun = {"rc": None, "stdout": "", "stderr": ""}
            if rc == 0:
                rc2, out2, err2, _ = run([os.path.join(d, "p.bin")], d, 20, env)
                prun = {"rc": rc2, "stdout": out2, "stderr": err2}
            cls = classify(case, node, build, prun)
            diag = ""
            if build["rc"] != 0:
                diag = " | ".join(l.strip() for l in build["stderr"].splitlines() if "error" in l)[:600]
            elif cls != "OK":
                diag = first_error(prun["stderr"]) or prun["stderr"][:300]
            return dict(id=case["id"], family=case.get("family"), expect=case.get("expect", "node"),
                        cls=cls, node_rc=None if node is None else node["rc"], node_stdout=None if node is None else node["stdout"],
                        node_error=None if node is None else node["error"], pts_build_rc=build["rc"], pts_rc=prun["rc"],
                        pts_stdout=prun["stdout"], pts_diag=diag, build_secs=build["secs"])
        finally:
            shutil.rmtree(d, ignore_errors=True)

    results = []
    t0 = time.time()
    with cf.ThreadPoolExecutor(args.jobs) as ex, open(args.out, "w") as f:
        for i, r in enumerate(ex.map(one, cases)):
            results.append(r)
            f.write(json.dumps(r) + "\n")
            f.flush()
            if (i + 1) % 50 == 0:
                print(f"{i + 1}/{len(cases)} {time.time() - t0:.0f}s", file=sys.stderr, flush=True)
    if args.node_cache:
        with open(args.node_cache, "w") as f:
            for r in cache.values():
                f.write(json.dumps(r) + "\n")
    counts = {}
    for r in results:
        counts[r["cls"]] = counts.get(r["cls"], 0) + 1
    print(json.dumps(counts, sort_keys=True))


if __name__ == "__main__":
    main()
