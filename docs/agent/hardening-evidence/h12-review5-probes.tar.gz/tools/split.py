#!/usr/bin/env python3
# split.py FILE...: writes FILE's attempt(...) lines each into DIR/split/<name>_NN.pts with the lines before
# the first attempt as header; trailing non-attempt lines go into one more file.
import sys, os
for path in sys.argv[1:]:
    lines = open(path).read().rstrip("\n").split("\n")
    first = next(i for i, l in enumerate(lines) if l.startswith("attempt("))
    head, rest = lines[:first], lines[first:]
    att = [l for l in rest if l.startswith("attempt(")]
    tail = [l for l in rest if not l.startswith("attempt(")]
    d = os.path.join(os.path.dirname(path), "split"); os.makedirs(d, exist_ok=True)
    base = os.path.basename(path)[:-4]
    for i, l in enumerate(att + (["\n".join(tail)] if tail else [])):
        open(os.path.join(d, f"{base}_{i:02d}.pts"), "w").write("\n".join(head + [l]) + "\n")
