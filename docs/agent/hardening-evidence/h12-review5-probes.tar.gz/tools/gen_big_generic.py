#!/usr/bin/env python3
# gen_big_generic.py N DEG FUNCS OUT: N module `string | undefined` variables written from FUNCS generic
# functions over T extends string[] (each with a local written xs[i] and other locals), DEG random writes each,
# every function instantiated with three tuple/array types.
import random, sys
n, deg, funcs, out = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
rng = random.Random(n + deg + funcs)
L = ["const empty: string[] = [];"] + [f"let v{i}: string | undefined = \"v{i}\";" for i in range(n)]
per = max(1, n // funcs)
for f in range(funcs):
    L.append(f"function w{f}<T extends string[]>(xs: T): number {{")
    L.append(f"  let x: string | undefined = 'x'; let y: string | undefined = 'y'; let z: string | undefined = 'z';")
    L.append(f"  if (empty.length > 9) x = xs[3]; y = c(x) || xs[{rng.randint(4, 9)}]; z = (c(y), x);")
    for i in range(f * per, min(n, (f + 1) * per)):
        for j in rng.sample(range(n), deg):
            L.append(f"  if (empty.length > {rng.randint(1, 9)}) v{i} = v{j};")
        L.append(f"  if (empty.length > 10) v{i} = {rng.choice(['x', 'y', 'z'])};")
    L.append("  return xs.length;")
    L.append("}")
L.insert(1, "function c(s: string | undefined): string { return s === undefined ? '' : s; }")
for f in range(funcs):
    L.append(f"w{f}(['a']); w{f}([] as string[]);")
L.append("if (empty.length === 0) v0 = empty[3];")
for i in range(0, n, max(1, n // 5)):
    L.append(f"try {{ console.log(v{i}.length); }} catch (e) {{ console.log('v{i}', (e as Error).name); }}")
open(out, "w").write("\n".join(L) + "\n")
