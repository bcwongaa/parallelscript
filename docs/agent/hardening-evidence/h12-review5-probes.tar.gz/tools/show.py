#!/usr/bin/env python3
# usage: show.py OUT.json [substring] — prints outputs per probe
import sys, json
d = json.load(open(sys.argv[1]))
for k, v in d.items():
    if len(sys.argv) > 2 and sys.argv[2] not in k: continue
    print("===", k)
    for name in v:
        rc, out = v[name]
        print(f"--- {name} rc={rc}"); print(out.rstrip()[:1200])
