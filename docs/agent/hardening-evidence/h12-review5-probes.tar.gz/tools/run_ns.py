#!/usr/bin/env python3
# usage: run_ns.py CLI HOME probe.pts...  — node vs one CLI, W in parallel (default 2); prints mismatches
import sys, subprocess, tempfile, shutil, os, concurrent.futures, difflib, signal
cli, home = sys.argv[1], sys.argv[2]
def sh(cmd, cwd, timeout, env=None):
    q = subprocess.Popen(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, start_new_session=True)
    try:
        o, e = q.communicate(timeout=timeout)
        return q.returncode, o + e
    except subprocess.TimeoutExpired:
        os.killpg(q.pid, signal.SIGKILL); q.communicate()
        return 124, "TIMEOUT"
def run(path):
    d = tempfile.mkdtemp(dir="/tmp/h12/review5/work")
    try:
        shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
        n = sh(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], d, 30)
        rc, out = sh([cli, "run", "p.pts"], d, 300, dict(os.environ, PTS_HOME=home))
        p = (rc, out.replace(d, "<d>"))
        return path, n, p
    finally:
        shutil.rmtree(d, ignore_errors=True)
ok = bad = 0
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "2"))) as ex:
    for path, n, p in ex.map(run, sys.argv[3:]):
        if n == p: ok += 1
        else:
            bad += 1
            print("DIFF", path, "node rc", n[0], "pts rc", p[0])
            print("\n".join(list(difflib.unified_diff(n[1].split("\n"), p[1].split("\n"), "node", "pts", lineterm=""))[:16]))
print("ok", ok, "diff", bad)
