#!/usr/bin/env python3
# gen5.py OUTDIR N SEED [all]: one function per program in a random context (plain, generic over
# T extends string[] / T[] / T extends string, a class method, a module variable written the local),
# 1-4 writes to declared `string | undefined` locals from logical/comma/conditional/element/loose
# forms, reads narrowed to string in a try. Without "all", leaves out round 4's known shapes
# (satisfies; typeof-narrowed type parameters).
import random, sys, os
out, n, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
everything = len(sys.argv) > 4
os.makedirs(out, exist_ok=True)
rng = random.Random(seed)
for case in range(n):
    ctx = rng.choice(["plain", "gen_arr", "gen_t", "gen_str", "method", "modvar"] + (["typeof"] if everything else []))
    src = {"plain": "xs", "gen_arr": "xs", "gen_t": "xs", "gen_str": "s", "method": "this.xs", "modvar": "xs", "typeof": "v"}[ctx]
    elem = lambda: f"{src}[{rng.randint(3, 9)}]"
    forms = [lambda: elem(), lambda: f"e || {elem()}", lambda: f"c && {elem()}", lambda: f"(log('s'), {elem()})",
             lambda: f"(pick() ? {elem()} : 'z')", lambda: "lb", lambda: "lb && 'k'", lambda: f"e || (c && {elem()})",
             lambda: f"(e || {elem()}) || 'f'", lambda: f"c && (e || lb)", lambda: f"(log('t'), e || {elem()})", lambda: "e || lb",
             lambda: f"((({elem()})))", lambda: f"c && c && {elem()}"]
    if everything: forms.append(lambda: f"{elem()} satisfies string | undefined")
    k = rng.randint(1, 3)
    names = [f"x{i}" for i in range(k)]
    body = [f"let {nm}: string | undefined = 'i{nm}';" for nm in names]
    for _ in range(rng.randint(1, 4)):
        a = rng.choice(names)
        op = rng.choice(["=", "=", "=", "||=", "&&="])
        if op == "||=": body.append(f"{a} = ''; {a} ||= {rng.choice(forms)()};")
        elif op == "&&=": body.append(f"{a} = 'q'; {a} &&= {rng.choice(forms)()};")
        else: body.append(f"{a} = {rng.choice(forms)()};")
        if rng.random() < 0.3 and k > 1:
            b = rng.choice(names); body.append(f"{b} = {a};")
    if ctx == "modvar": body.append(f"M = {rng.choice(names)};")
    for nm in names:
        body.append(f"try {{ log('{nm} ' + {nm}.length); }} catch (err) {{ log('{nm} ' + (err as Error).name); }}")
    head = ["const empty: string[] = [];", "const [lb] = empty;", "const e: string = '';", "const c: string = 'c';",
            "function log(s: string): void { console.log(s); }", "function pick(): boolean { return empty.length === 0; }", "let M: string | undefined = 'm';"]
    if ctx == "plain": prog = head + ["function run(xs: string[]): void {"] + body + ["}", "run(['a']);"]
    elif ctx in ("gen_arr", "modvar"): prog = head + ["function run<T extends string[]>(xs: T): void {"] + body + ["}", "run(['a']);"]
    elif ctx == "gen_t": prog = head + ["function run<T>(xs: T[], d: T): void {"] + [b.replace("'i", "'i") for b in body] + ["}", "run(['a'], 'b');"]
    elif ctx == "gen_str": prog = head + ["function run<T extends string>(s: T): void {"] + body + ["}", "run('ab');"]
    elif ctx == "method": prog = head + ["class Box<T extends string[]> {", "  constructor(public xs: T) {}", "  run(): void {"] + body + ["  }", "}", "new Box(['a']).run();"]
    else: prog = head + ["function run<T>(v: T): void {", "  if (typeof v !== 'string') return;"] + body + ["}", "run('ab');"]
    if ctx == "modvar": prog.append("try { log('M ' + M.length); } catch (err) { log('M ' + (err as Error).name); }")
    open(os.path.join(out, f"f5_{seed}_{case:03d}.pts"), "w").write("\n".join(prog) + "\n")
