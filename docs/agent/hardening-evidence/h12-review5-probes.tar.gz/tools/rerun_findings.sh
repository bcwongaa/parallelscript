#!/bin/bash
# Reruns round 5's finding probes against Node, base, snap4, snap5 and snapshot 6 (/tmp/h12/fix3), process groups killed on timeout.
cd /tmp/h12/review5
B=base,snap4,snap5,fix3 W=4 python3 tools/run.py rerun-findings.json \
  p/e/e01_mapped_over_tuple_param.pts p/e2/e17_mapped_tested.pts p/e2/e18_mapped_readonly_elems.pts p/e2/e19_mapped_module_var.pts \
  p/e3/e20_arraylike_constraint.pts p/e3/e22_arraylike_tested.pts p/e3/e21_index_signature_constraint.pts p/e2/e16_mapped_over_record.pts
