// Interface-typed objects read as they are (any object as an object type, cached), then
// handed to places that may read fields without sites: a local of a literal's shape, a class
// field initialized from a literal, a spread, destructuring with defaults, Object.assign,
// JSON, inspect, `in`, method calls, getters and setters, frozen twins. The objects have
// another layout than the type's (an i32 where the type says number, properties in another
// order, a getter where a field goes).
interface P {
  x: number;
  y: string;
}
interface H {
  p: P;
}
class WithPos {
  pos = { x: 1.5, y: "a" };
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const odd = { y: "b", x: 3 as i32 };
const getterP = {
  get x(): number {
    return 4.5;
  },
  y: "g",
};
const holders: H[] = [{ p: { x: 1.5, y: "a" } }, { p: odd as any }, { p: getterP as any }];
for (const h of holders) {
  attempt("site read", () => String(h.p.x * 2) + " " + h.p.y);
  attempt("a literal-shaped local", () => {
    let o = { x: 0.5, y: "z" };
    o = h.p;
    return String(o.x * 2) + " " + o.y;
  });
  attempt("a class field from a literal", () => {
    const w = new WithPos();
    w.pos = h.p;
    return String(w.pos.x * 2) + " " + w.pos.y;
  });
  attempt("a spread", () => {
    const c = { ...h.p };
    return String(c.x * 2) + " " + c.y;
  });
  attempt("destructuring with defaults", () => {
    const { x = 0, y = "d" } = h.p;
    return String(x * 2) + " " + y;
  });
  attempt("Object.assign", () => {
    const t: any = Object.assign({ x: 0, y: "" }, h.p);
    return String(t.x * 2) + " " + t.y;
  });
  attempt("JSON and keys", () => JSON.stringify(h.p) + " " + Object.keys(h.p).join(","));
  attempt("in", () => String("x" in h.p));
  attempt("write through it", () => {
    h.p.x = 9;
    return String(h.p.x);
  });
  attempt("frozen twin", () => {
    const f = Object.freeze(h.p);
    return String(f.x) + " " + String(Object.isFrozen(h.p));
  });
}
