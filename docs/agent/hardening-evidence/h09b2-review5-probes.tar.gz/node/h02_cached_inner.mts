// A nested object a union member keeps as it is, whose declared type differs from the
// member's (an i32 where number goes, properties in another order, a getter, an array of a
// narrower element): the cached read of `inner` hands it out as the member's object type;
// then every place that might read its fields without a site.
type T = { kind: "t"; inner: { x: number; y: string; zs: (number | string)[] } } | { kind: "none" };
class WithPos {
  pos = { x: 1.5, y: "a", zs: [] as (number | string)[] };
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
function show(p: { x: number; y: string }): string {
  return String(p.x * 2) + " " + p.y;
}
const plainInner = { zs: [1, 2], y: "b", x: 3 };
const getterInner = {
  zs: [3],
  get x(): number {
    return 4.5;
  },
  y: "g",
};
const o1 = { kind: "t" as const, inner: plainInner };
const o2 = { kind: "t" as const, inner: getterInner };
const s1: T = o1;
const s2: T = o2;
for (const s of [s1, s2]) {
  if (s.kind !== "t") continue;
  attempt("site reads", () => String(s.inner.x * 2) + " " + s.inner.y);
  attempt("the array of a narrower element", () => String(s.inner.zs.length));
  attempt("a parameter", () => show(s.inner));
  attempt("a literal-shaped local", () => {
    let o = { x: 0.5, y: "z", zs: [] as (number | string)[] };
    o = s.inner;
    return String(o.x * 2) + " " + o.y;
  });
  attempt("a class field from a literal", () => {
    const w = new WithPos();
    w.pos = s.inner;
    return String(w.pos.x * 2) + " " + w.pos.y;
  });
  attempt("a spread", () => {
    const c = { ...s.inner };
    return String(c.x * 2) + " " + c.y;
  });
  attempt("destructuring with defaults", () => {
    const { x = 0, y = "d" } = s.inner;
    return String(x * 2) + " " + y;
  });
  attempt("JSON, keys, in", () => JSON.stringify(s.inner) + " " + Object.keys(s.inner).join(",") + " " + String("x" in s.inner));
  attempt("write a number", () => {
    s.inner.x = 9;
    return String(s.inner.x);
  });
  attempt("push a string", () => {
    s.inner.zs.push("s");
    return String(s.inner.zs.length);
  });
}
