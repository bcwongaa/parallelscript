// Kept nested objects read as the member's object type through a cached site, then used
// through interface method calls (another signature: adapted), getters and setters, and a
// union whose members hold a property as different types (Mixed).
class Counter {
  constructor(public n: number) {}
  add(k: number): number {
    this.n += k;
    return this.n;
  }
  get twice(): number {
    return this.n * 2;
  }
  set twice(v: number) {
    this.n = v / 2;
  }
}
type T = { kind: "t"; c: { n: number | string; add(k: number): number; twice: number } } | { kind: "none" };
type M = { kind: "a"; v: number } | { kind: "b"; v: string };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (e: any) {
    console.log(label, e.name, e.message);
  }
}
const counter = new Counter(1);
const o = { kind: "t" as const, c: counter };
const s: T = o;
for (let i = 0; i < 3; i++) {
  if (s.kind !== "t") continue;
  attempt("method", () => String(s.c.add(2)));
  attempt("getter", () => String(s.c.twice));
  attempt("setter", () => {
    s.c.twice = 20;
    return String(counter.n);
  });
  attempt("field", () => String(s.c.n));
}
const ms: M[] = [{ kind: "a", v: 1.5 }, { kind: "b", v: "x" }];
for (const m of ms) {
  attempt("mixed", () => String(m.v));
}
