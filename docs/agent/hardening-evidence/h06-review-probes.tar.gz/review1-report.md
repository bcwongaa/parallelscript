# H06a review 1 (opus-reviewer, claude-opus-5-5)

Slice: the uncommitted tree in `/home/bryan/projects/parallelscript` against `HEAD` `3999ab359` (code diff `git diff -- pts | sha256sum` = `37a5617f…f075`). Every code file predates my CLI build (12:06; the latest code edit was `pts/lower/arrays.go` at 12:04). CLI: `/tmp/h06/review1/pts`, built from the main tree. Base: `/tmp/h06-base/pts-bin/pts`. Probes are under `/tmp/h06/review1/` and archived in `/tmp/h06/review1/h06-review-probes.tar.gz`. The helper `run3.sh <file> [threads]` runs the new CLI, the base CLI and Node (the `.oracle.mts` twin if there is one).

## Verdict

**Not ready: one blocker, three should-fix.** The core of the slice is right. The runtime's SortCompare order, comparators never seeing undefined or a hole, the copies, the dynamic path and the parallel library all match Node across a generated matrix at 1, 2 and 4 threads. But the new handling of an undefined comparator silently breaks typed arrays (F1): base rejected that code with PTS1001, and now it sorts in string order. Fix F1 and add typed cases to `sort_optional_comparator.pts` before committing. F2 and F4 are also worth fixing in H06a; the rest can be recorded.

## Verified evidence (commands run, results)

- **New tests vs Node.** I copied each of the 8 sequential new tests to `.mts` and ran it in Node; Node's output equals the expect block for all 8 (`/tmp/h06/review1/expect/*.diff`, empty). For the 2 parallel tests I wrote my own sequential twins (`.par.sort` changed to `.sort`, AtomicInt replaced by a counter class); both expect blocks equal Node.
- **New tests, both CLIs.** All 10 non-skipped new tests are red on the base CLI at `PTS_THREADS=1` and `2` (5–12 differing lines each; `sort_optional_comparator` fails to compile on base). On the new CLI, `parallel_sort_undefined` and `parallel_sort_holes` match their expect blocks at 1, 2 and 4 threads (`diff -q` clean, exit 0). The other 8 pass through the harness (below).
- **Skipped tests.** All 10 skipped tests: the expect block equals Node, they are still red on the new CLI, and their output is byte-identical between base and new (H06a changes nothing there).
- **Generated differential matrix** (`/tmp/h06/review1/diff/gen.pts`, with a Node twin).
  - Arrays: any[], `(string|number|null|undefined)[]`, string[] with holes, `(O|undefined)[]` and number[].
  - Sizes: 0, 1, 2, 7, 100, 2047, 2048, 2049, 4500 and 9000.
  - Operations: sort(), sort(cmp), toSorted(), toSorted(cmp), .par.sort(), .par.sort(cmp), and through `any`. The comparator is consistent but has many equal keys, so stability is exercised.
  - Each result is digested position by position. A hole is detected as `a.slice(i,i+1).flat().length === 0`, since `flat` skips holes but keeps undefined.
  - Results: 230 digests per run. Seed 12345 has 0 differences from Node at 1, 2 and 4 threads; seeds 777 and 99991 have 0 differences at 1 and 4 threads. The base binary of the same program exits 1 early, so the digest does discriminate.
- **Unit and Go tests.**
  - `go test -count=1 -v -run 'TestRuntimeUnitTestsPassUnderSanitizers/array_test.c' ./pts/toolchain/`: PASS (2.26 s). My first run used the filter `/array_test` without `.c` and matched no subtest.
  - `go test ./pts/lower/... ./pts/cgen/...`: ok. `go vet ./pts/lower/ ./pts/cgen/`: clean.
- **Regression sweep.** The 38 run tests that use sort, toSorted, toReversed, toSpliced, with, sortBy or `.par.sort`, through the real harness (`-parallel 2`): `TestRun` gave 44 PASS (12 skipped as "compared by TestRunMatchesNode"), and `TestRunMatchesNode` on those 12 gave 12 PASS (`PTS_REQUIRE_NODE=1`).
- **Performance** (`bench/`, 1M elements, `PTS_THREADS=4`, new and base interleaved ×3): default `.par.sort()` on strings took 435/451/445 ms new vs 536/491/510 ms base; `.par.sort(cmp)` on numbers took 109/149/91 vs 104/92/115 ms (noise). No regression.
- **Correct paths I probed.** All of these match Node:
  - match arrays (`.par.sort`, toReversed, with, toSpliced), at 1 and 2 threads;
  - tuples with optional (ABSENT) elements;
  - generic code and an erased generic arrow with `compare?`;
  - optional comparators read from an optional property, an optional class field, an optional tuple element, a `Record`, `?.` and an array element;
  - `.par.sort(undefined)` and `.par.sort(maybe)`;
  - unions without undefined (`(string|null)[]`, `(P|null)[]`, `(number|string)[]`): their copies now give undefined, as in Node;
  - checked conversions from `any` of such copies (no new TypeErrors).
- **Race and GC.**
  - `pts_array_sort` now reads each slot once (before H06a it read each slot twice: `element_load`, then `element_string` on the buffer).
  - Scratch memory is `GC_MALLOC`, so it is scanned.
  - `pts_array_copy_as_read` writes only into an unpublished copy.
  - In `store_if_moved`, the second load only decides whether to store; the value stored comes from the first read.
  - Disguised non-arrays (`typed as any as number[]`, a tuple as an array) are stopped by the checked conversion before `pts_parallel_gather_sortable` casts its argument (`par_disguised.pts`).
  - Union reads of the new explicit undefined are tag-checked: `TypeError: Expected string, got undefined`, never a wild pointer (`union_without_undefined.pts`).
- **Generated C** (`probes/emit_optional.c`): the optional path is one readable statement-expression with `#line`.

## Findings

### F1: blocker, new in H06a. Typed arrays' `sort(undefined)`, `toSorted(undefined)` and optional comparators sort in string order

- `pts/lower/typed_arrays.go:576-591` (`typedSortWith`) calls `l.sortWith(&ir.LocalRef{Local: numbers}, compare)`.
- H06a's `sortWith` (`pts/lower/arrays.go:412-414`) and `sortWithOptional` (`:432-446`) emit `ir.ArraySort` for the undefined case, which is Array's string order, on the typed array's `number[]` copy. A typed array's default order is numeric.
- Repro: `/tmp/h06/review1/probes/typed_sort_undefined.pts`.

```
NODE: Float64Array(6) [ -0, 0, 1, 9, 10, 100 ]      Int32Array(4) [ 1, 9, 10, 100 ] …  Uint8Array(4) [ 1, 9, 10, 100 ]
PTS : Float64Array(6) [ -0, 0, 1, 10, 100, 9 ]      Int32Array(4) [ 1, 10, 100, 9 ] …  Uint8Array(4) [ 1, 10, 100, 9 ]
BASE: error PTS1001: converting undefined to (number, number) => number is not supported yet (×4)
```

- Base gave an honest compile error; H06a gives a silent wrong result. That is a regression, on a path the SPEC change now claims ("an undefined comparator (`sort(undefined)`, `compare?: …`) is the default order").
- Fix: in `typedSortWith`, handle undefined before calling `sortWith`.
  - A literal `undefined` should call `pts_typed_array_sort` (or `toSorted`'s copy, then `pts_typed_array_sort`).
  - A comparator whose union holds undefined should get a run-time `Conditional` between `pts_typed_array_sort(sorted)` and the existing numbers path.
- Add `Float64Array`/`Int32Array` cases to `run/sort_optional_comparator.pts`: `sort(undefined)`, `toSorted(undefined)`, and a `compare?` parameter, both left out and given.

### F2: should-fix, new in H06a. `.par.sort` changes the array before the comparator or toString runs

- `pts/lib/parallel.pts:184` calls `pts_parallel_gather_sortable(items)` in place, before any user code runs.
- JS (and the base, at 1 thread and for arrays shorter than one piece at 2 and 4 threads) reads the elements, sorts them, and writes back only if nothing throws. The comparator also sees the original array.
- With the in-place gather, the array is left compacted when the comparator or a `toString` throws, and the comparator sees the compacted array. This happens at every thread count.
- Repros: `/tmp/h06/review1/probes/par_sort_edges.pts` (first two lines) and `/tmp/h06/review1/probes/par_observe.pts`.

```
thrown = [undefined, 3, undefined, 1, 2]; thrown.par.sort(() => { throw … })
NODE / BASE (t=1,2,4): after throw [ undefined, 3, undefined, 1, 2 ]
PTS (t=1,2,4):         after throw [ 3, 1, 2, undefined, undefined ]
throwing toString, default order:  NODE [ undefined, Bad { n: 1 }, undefined, Bad { n: 2 } ]   PTS [ Bad { n: 1 }, Bad { n: 2 }, undefined, undefined ]
comparator reading b[0] of [undefined, 2, 1]:  NODE seen [ 'undefined' ]   PTS seen [ '2' ]
```

- For arrays longer than one piece at 2 or more threads, the base already wrote sorted pieces back before the merges, so a throw there was never all-or-nothing.
- Fix: gather into a scratch array rather than in place.
  - A runtime helper would return a compact array of the compared elements and the undefined count.
  - Sort that array with `sortInPlace` and the existing merge, or `permute` for the default order.
  - A second helper would then write back the compared elements, then the undefineds, then the holes, frozen check included.
- The cheaper fallback is to skip the gather at 1 thread, since `items.sort` already handles undefined and holes. That still leaves small arrays at 2+ threads changed.

### F3: minor, new in H06a. A frozen array's `.par.sort` names the wrong index and throws before the comparator runs

- In `pts/runtime/src/array.c:921-931` (`store_if_moved`), the gather throws at the first slot it moves. Node, and PTS's sequential sort, throw at `'0'`, after the comparator calls.
- Repro: `/tmp/h06/review1/probes/frozen_messages.pts`.

```
NODE (and PTS a.sort()):  TypeError: Cannot assign to read only property '0' of object '[object Array]'
PTS a.par.sort() / a.par.sort(cmp), t=1,2:   … read only property '1' …     (BASE par sort: '0')
```

- The F2 fix makes this go away.
- Related, pre-existing (`frozen_holes.pts`, `par_sort_edges.pts`):
  - The sequential `sort()`/`sort(cmp)` of a frozen all-holes array throws; Node doesn't, since it only deletes absent properties. The frozen check at `array.c:853` and `:907` could be `length >= 2 && count + undefineds > 0`.
  - `Object.freeze([1]).par.sort()` throws; Node returns `[ 1 ]`, because V8 returns early for length < 2.
  - With H06a, `.par.sort()` of a frozen all-holes array matches Node while `.par.sort(cmp)` throws.

### F4: should-fix, pre-existing, in C95's scope. Comparators of dynamic type that hold undefined throw

- `sortWith` (`pts/lower/arrays.go:421`) branches at run time only when the comparator's IR type is a `*ir.Union` holding undefined.
- A comparator that is `any`, or a `Map.get(k)` result (tsc: `C | undefined`, IR: a dynamic value), goes through `l.convert` instead and throws where JS sorts in the default order.
- Repros: `/tmp/h06/review1/probes/sort_any_comparator.pts` and `/tmp/h06/review1/probes/optional_map_get.pts`.

```
[3,20,100].sort(anyUndefined) / .toSorted(anyUndefined):  NODE [ 100, 20, 3 ]   PTS/BASE TypeError: Expected (number, number) => number, got undefined
[10,9,1,100].sort(m.get("x")) (empty Map<string, C>):     NODE [ 1, 10, 100, 9 ] PTS/BASE same TypeError
sort(anyNull):  NODE TypeError: The comparison function must be either a function or undefined: null   PTS TypeError: Expected (number, number) => number, got null
```

- Fix: give `compare.Type() == ir.Value` the same treatment as the optional union. Bind the value, test `== PTS_VALUE_UNDEFINED` and take `ArraySort`; otherwise do the checked conversion. Ideally, a non-function would throw Node's message, as `dynamic_methods.c`'s `array_sort` does.
- The SPEC sentence "an undefined comparator … is the default order" currently overclaims.

### F5: minor. `isUndefined` goes by the identifier's text (new for `sort`, pre-existing for `toSorted`)

- `pts/lower/arrays.go:497-499` and `:412`: a parameter named `undefined` (legal in strict code) is taken for the global, so the comparator is ignored.
- Repro: `/tmp/h06/review1/probes/shadowed_undefined.pts`.

```
function f(undefined: C) { return [[3,20,100].sort(undefined), [3,20,100].toSorted(undefined)]; }  f((a,b)=>a-b)
NODE [ [ 3, 20, 100 ], [ 3, 20, 100 ] ]   PTS [ [ 100, 20, 3 ], [ 100, 20, 3 ] ]   BASE [ [ 3, 20, 100 ], [ 100, 20, 3 ] ]
```

- The reverse case: `sort((undefined))`, `sort(void 0)` and `const u = undefined; sort(u)` are still PTS1001 (`sort_undefined_spellings.pts`), which is honest but inconsistent.
- Fix: decide by the lowered argument's IR type (`ir.Undefined`: evaluate it, then `ArraySort`), or check that the identifier resolves to the default library's `undefined` (`l.isDeclaredInDefaultLib(l.target(arg))`), after `ast.SkipParentheses`.

### F6: minor, pre-existing, and the new optional path inherits it. `toSorted` and `toSpliced` copy before evaluating their arguments

- In `pts/lower/array_library.go:24-38`, `ArrayCopy` of the receiver is bound before the comparator or items are evaluated.
- JS evaluates the arguments first and copies inside the method, so an argument whose evaluation changes the receiver is in JS's copy but not in PTS's.
- Repros: `/tmp/h06/review1/probes/copy_order.pts`, and `copy_order_base.pts` for the base.

```
a=[3,1,2]; a.toSorted(optional())  // optional() pushes 0, returns undefined
NODE [ 0, 1, 2, 3 ]  PTS [ 1, 2, 3 ]      (required comparator: same; toSpliced(0,1,item()): NODE [ 9, 1, 2, 0 ] PTS/BASE [ 9, 1, 2 ]; with() is right)
```

- `sort_optional_comparator.pts` checks that the receiver is evaluated before the comparator. That's true, but its `comparator()` doesn't touch the receiver, so the test can't see this.
- Fix: bind the receiver to a local, evaluate the arguments, then copy that local.

### F7: minor, pre-existing, in the function H06a rewrote. `pts_array_sort` writes back into a stale buffer

- At `array.c:833` and `:856-859`, the buffer is loaded before the keys are computed, and keys can call a user `toString`. If that `toString` pushes and the array is reallocated, the write-back goes to the old buffer, so the sort is lost silently.
- `pts_array_sort_with` reloads the buffer after its user calls (`:911-913`); `pts_array_sort` doesn't.
- Repro: `/tmp/h06/review1/probes/tostring_mutates.pts`. NODE `[ T{1}, T{2}, T{3}, undefined, undefined ] 104`; PTS and BASE `[ T{3}, undefined, T{1}, T{2}, undefined ] 104`.
- Fix: reload `buffer` and `readable_length` after the keys and clamp, as `sort_with` does.

### F8: note, pre-existing design. A comparator that shrinks the array gets a shorter result than JS

- At `array.c:913`, the write-back stops at `now`. JS's `Set` re-extends the array to the number of sorted items.
- Repro: `/tmp/h06/review1/probes/comparator_mutates.pts`.
  - `pop` in the comparator: NODE `[1,2,3,undefined,undefined]` (length 5); PTS `[1,2,3,undefined]` (length 4).
  - `length = 0` in the comparator: NODE `['a','b','c',undefined]`; PTS `[]`.
- This was deliberate ("as far as it reaches"), but it's not listed in SPEC §7. Record it there or in H06b.

### F9: minor, docs and test quality

1. The ledger row C96, D-182 as SPEC and REVIEW_LATER use it, and the comment in `run/array_copies_read_holes.pts` imply that holes stay in copies whenever the element type has no undefined. C96 explicitly lists `(string | null)[]`.
   - The code converts holes in every dynamic-value array, including `(string|null)[]`, `(P|null)[]` and `(number|string)[]`, and matches Node there (`probes/union_copies.pts`, `probes/union_without_undefined.pts`).
   - Only `string[]` and arrays of one object type (non-union element kinds) keep holes.
   - Fix the wording, and pin a `(string | null)[]` case in `array_copies_read_holes.pts`.
2. D-182 is cited by SPEC, the plan, REVIEW_LATER and a test, but it isn't in `docs/DECISIONS.md` yet.
3. `parallel_sort_undefined.pts` and `parallel_sort_holes.pts` cite `h06-probes/parallel/*.oracle.mts`. Those files exist only under `/tmp/h06/repro/…` and a `.claude/worktrees/` copy. Archive them in the repository or reword the comments.
4. Stale comments:
   - `pts/ir/ir.go:869`: `ArrayCopy` "a new array of a's elements" (it now reads holes as undefined).
   - `array.c:700`: `element_string` "the string join and sort use … "" for undefined, null and holes" (sort no longer gives those to it, and null is `"null"` for sort).
   - D-039's sort clause is superseded; D-182 should say so.
5. `pts_array_gather_sortable` has no C unit test. Missing cases: a frozen array with nothing to move doesn't throw; one with something to move throws; only changed slots are stored; the order is compared, then undefined, then holes.
6. The `big` case of `parallel_sort_undefined.pts` only checks ascending order and a few slices, so a merge that duplicated or dropped elements while staying ascending would pass. A checksum, or a position digest like `diff/gen.pts`'s, would catch it.
7. `sort_optional_comparator.pts` has no typed-array case (that is F1).

## Split and by-design choice

- **The split is defensible.** H06a covers C06's sort paths, the copying methods (which share `toSorted`'s copy) and C95. H06b's items (callbacks, `find*`, `includes`/`indexOf`, keys, `in`, iteration, `concat` through `any`, match spreads) touch different runtime functions, and none of them depends on the sort changes. The skipped RED tests pin each one, and their output is unchanged by H06a.
  - The plan text says "audit … with generated differential cases". The reproducer's matrix is the stated evidence. A small generated regression test in the suite, like `/tmp/h06/review1/diff/gen.pts` (hole-exact digests, sizes around 2048, run at 1, 2 and 4 threads), would keep the audit from rotting; it could go in with H06b.
- **D-182 (string and object copies keep holes) is defensible.** A `string[]` or `P[]` slot has no representation for undefined beyond zero, which D-038 makes a hole. The divergence only shows for arrays that have holes, which come from `new Array<T>(n)` left partly unfilled, or from racing pushes. Reads where any value goes still give undefined.
  - The alternative REVIEW_LATER mentions is real: a "zero slot is undefined" twin descriptor, as `pts_type_match_copy` is for strings. It would make printing match Node, and a required read would throw a TypeError, as Node's property access on undefined does, rather than a RangeError.
  - The wording needs to be narrowed to the kinds that actually keep holes (F9.1).
