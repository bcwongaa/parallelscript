#!/bin/bash
# existing2.sh <fix|base|exp> <src.pts> <reps>: builds a repo run test; checks stdout (expect block, .out, or Node's) and the exit code at each `// threads:` value
which=$1; src=$2; reps=$3; name=$(basename $src .pts); dir=$(dirname $src)
case $which in
  fix) home=/home/bryan/projects/parallelscript; cli=$home/pts-bin/pts;;
  exp) home=/tmp/h07b2/review2/copies/exp;; exp2) home=/tmp/h07b2/review2/copies/exp2; cli=/home/bryan/projects/parallelscript/pts-bin/pts; cli=/home/bryan/projects/parallelscript/pts-bin/pts;;
  *) home=/tmp/h07b2/base; cli=$home/pts-bin/pts;;
esac
out=/tmp/h07b2/review2/existing; mkdir -p $out; bin=$out/$which.$name
( cd $dir && PTS_HOME=$home $cli build $src -o $bin > $bin.build 2>&1 ) || { echo "$name: BUILD FAILED"; exit; }
exp=$out/$name.expect
if grep -q "^// expect:" $src; then
  awk '/^\/\/ expect:/{on=1;next} on && /^\/\/ (exit|stderr|threads|skip|no-diff):/{exit} on && /^\/\/( |$)/{sub(/^\/\/ ?/,""); print; next} on{exit}' $src > $exp
elif [ -f $dir/$name.out ]; then cp $dir/$name.out $exp
else cp $src $out/$name.mts; (cd $out && timeout 60 ~/.local/node/bin/node --no-warnings $name.mts > $exp 2>/dev/null); fi
code=$(sed -n 's|^// exit: *\([0-9]*\).*|\1|p' $src | head -1); code=${code:-0}
threads=$(sed -n 's|^// threads: *||p' $src | head -1); threads=${threads:-default}
res=""
for t in $threads; do bad=0; for r in $(seq 1 $reps); do
  if [ $t = default ]; then (cd $dir && timeout 60 $bin > $bin.out 2> $bin.err); c=$?; else (cd $dir && PTS_THREADS=$t timeout 60 $bin > $bin.out 2> $bin.err); c=$?; fi
  if ! diff -q $exp $bin.out > /dev/null || [ $c != $code ]; then bad=$((bad+1)); cp $bin.out $bin.t$t.r$r.bad; fi
done; res="$res t$t:$bad/$reps"; done
echo "$which $name:$res"
