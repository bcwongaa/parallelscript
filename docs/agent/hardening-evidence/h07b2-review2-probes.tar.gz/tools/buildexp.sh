#!/bin/bash
# buildexp.sh <src.pts>: builds with the main CLI against the experimental runtime copy, into bin/exp/
src=$1; name=$(basename "$src" .pts); mkdir -p /tmp/h07b2/review2/bin/exp
cd /tmp/h07b2/review2/bin/exp && PTS_HOME=/tmp/h07b2/review2/copies/exp /home/bryan/projects/parallelscript/pts-bin/pts build "$src" -o /tmp/h07b2/review2/bin/exp/$name 2>&1 | tail -5
