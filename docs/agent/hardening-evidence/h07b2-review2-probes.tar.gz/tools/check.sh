#!/bin/bash
# check.sh <fix|base> <name> <threads> <reps>: runs the binary and compares stdout with the source's expect block
which=$1; name=$2; threads=$3; reps=$4
src=/tmp/h07b2/review2/probes/$name.pts
exp=$(mktemp); awk '/^\/\/ expect:/{on=1;next} on && /^\/\/ ?/{sub(/^\/\/ ?/,""); print}' "$src" > "$exp"
pass=0; fail=0
for r in $(seq 1 $reps); do
  out=/tmp/h07b2/review2/out/$which.$name.t$threads.r$r
  start=$(date +%s%N)
  PTS_THREADS=$threads timeout 60 /tmp/h07b2/review2/bin/$which/$name > $out.stdout 2> $out.stderr; code=$?
  ms=$(( ($(date +%s%N) - start) / 1000000 ))
  if diff -q "$exp" $out.stdout >/dev/null && [ $code = 0 ]; then pass=$((pass+1)); else fail=$((fail+1)); echo "  FAIL r$r exit=$code ${ms}ms:"; diff "$exp" $out.stdout | head -8 | sed 's/^/    /'; head -3 $out.stderr | sed 's/^/    stderr: /'; fi
done
echo "$which $name t$threads: pass=$pass fail=$fail (last ${ms}ms)"
rm -f "$exp"
