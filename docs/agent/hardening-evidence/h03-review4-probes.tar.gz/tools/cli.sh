# sourced: sets cli home cache for $which
R=/home/bryan/projects/parallelscript
B=$R/.claude/worktrees/agent-afb5379bc12f20b9e
case $which in
 new) cli=$R/pts-bin/pts; home=$R; cache=/tmp/pts-h03-review4/cache;;
 base) cli=$B/pts-bin/pts; home=$B; cache=/tmp/pts-h03-review4/basecache;;
 r2) cli=/tmp/pts-h03-review/pts2; home=$R; cache=/tmp/pts-h03-review4/r2cache;;
 r3) cli=/tmp/pts-h03-review4/r3build/pts-r3; home=$R; cache=/tmp/pts-h03-review4/r3cache;;
 fix) cli=/tmp/pts-h03-review4/fixbuild/pts-fix; home=$R; cache=/tmp/pts-h03-review4/fixcache;;
 *) echo "unknown $which"; exit 2;;
esac
