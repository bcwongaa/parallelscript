#!/bin/bash
# usage: cmp4.sh probe.pts  -> runs new PTS, base PTS (unless NOBASE), r3 (if R3=1), Node; prints outputs and exit codes
set -o pipefail
p="$(realpath "$1")"; name=$(basename "$p" .pts); out=/tmp/pts-h03-review4/out/$name; mkdir -p "$out"
ulimit -f 40960
cp "$p" "$out/$name.mts"
( ulimit -v 4194304; cd "$out" && timeout 60 env PATH=$HOME/.local/node/bin:$PATH TZ=America/New_York node --no-warnings --experimental-transform-types "$out/$name.mts" > "$out/node.out" 2> "$out/node.err"; echo $? > "$out/node.exit" )
run() { # $1 which
  local which=$1 tag=$1; source /tmp/pts-h03-review4/tools/cli.sh
  ( cd "$out" && timeout 120 env PTS_HOME=$home PTS_CACHE_DIR=$cache GOMAXPROCS=2 $cli build "$p" -o "$out/$tag.bin" > "$out/$tag.build" 2>&1; echo $? > "$out/$tag.buildexit" )
  if [ "$(cat $out/$tag.buildexit)" = 0 ]; then
    ( ulimit -v 4194304; cd "$out" && timeout 60 env TZ=America/New_York "$out/$tag.bin" > "$out/$tag.out" 2> "$out/$tag.err"; echo $? > "$out/$tag.exit" )
  else
    cp "$out/$tag.build" "$out/$tag.err"; : > "$out/$tag.out"; echo build-fail > "$out/$tag.exit"
  fi
}
tags="new"; [ -z "$NOBASE" ] && tags="$tags base"; [ -n "$R3" ] && tags="$tags r3"; [ -n "$R2" ] && tags="$tags r2"
for t in $tags; do run $t; done
line="== $name: node exit $(cat $out/node.exit)"; for t in $tags; do line="$line; $t exit $(cat $out/$t.exit)"; done; echo "$line"
for t in $tags; do
  if diff -q "$out/node.out" "$out/$t.out" >/dev/null; then echo "$t == node (stdout)"; else echo "$t != node:"; diff "$out/node.out" "$out/$t.out" | head -${DIFFN:-30}; fi
done
for t in $tags; do [ -s "$out/$t.err" ] && { echo "-- $t stderr:"; head -${ERRN:-6} "$out/$t.err"; }; done
[ -s "$out/node.err" ] && { echo "-- node stderr:"; head -5 "$out/node.err"; }
exit 0
