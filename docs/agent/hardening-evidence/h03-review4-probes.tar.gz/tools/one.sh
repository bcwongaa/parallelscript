#!/bin/bash
# usage: one.sh <new|base|r2|r3> probe.pts -> build+run with that CLI
which=$1; p=$(realpath "$2"); name=$(basename "$p" .pts); out=/tmp/pts-h03-review4/out1/$which/$name; mkdir -p "$out"
source /tmp/pts-h03-review4/tools/cli.sh
ulimit -f 40960
( cd "$out" && timeout 120 env PTS_HOME=$home PTS_CACHE_DIR=$cache GOMAXPROCS=2 $cli build "$p" -o "$out/bin" > "$out/build" 2>&1 ); be=$?
if [ $be = 0 ]; then ( ulimit -v 4194304; cd "$out" && timeout 60 env TZ=America/New_York "$out/bin" > "$out/out" 2> "$out/err" ); e=$?; else cp "$out/build" "$out/err"; : > "$out/out"; e=build-fail; fi
echo "== [$which] $name exit $e"; cat "$out/out" | head -${OUTN:-40}; [ -s "$out/err" ] && { echo "-- stderr:"; head -${ERRN:-6} "$out/err"; }
exit 0
