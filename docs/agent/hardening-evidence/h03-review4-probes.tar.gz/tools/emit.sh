#!/bin/bash
# usage: emit.sh <new|base|r2|r3> probe.pts -> writes C to out1/<which>/<name>.c
which=$1; p=$(realpath "$2"); name=$(basename "$p" .pts); out=/tmp/pts-h03-review4/out1/$which; mkdir -p "$out"
source /tmp/pts-h03-review4/tools/cli.sh
timeout 120 env PTS_HOME=$home PTS_CACHE_DIR=$cache GOMAXPROCS=2 $cli emit-c "$p" -o "$out/$name.c"; echo "emit $which exit $? -> $out/$name.c"
