// `x += y` reads x before evaluating y.
function setV(): string { v = 5; return "x"; }
let v: string | number = "abc";
v += setV();
console.log("union", v);
let [w] = new Set(["w"]);
function setW(): string { w = "changed"; return "!"; }
w += setW();
console.log("loose", w);
let s = "s";
function setS(): string { s = "changed"; return "?"; }
s += setS();
console.log("string", s);
const o: any = { p: "abc" };
function setP(): string { o.p = 7; return "y"; }
if (typeof o.p === "string") {
  o.p += setP();
}
console.log("any property", o.p);
