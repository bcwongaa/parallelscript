const o: any = { s: "x" };
if (typeof o.s === "string") {
  o.s += 3;
}
console.log("any property narrowed", o.s);
const rec: Record<string, string | number> = { k: 1 };
rec.k = "r";
rec.k += 5;
console.log("record element", rec.k);
const rec2: Record<string, string | number> = { k: 1 };
rec2["k"] = "s";
rec2["k"] += 6;
console.log("record element access", rec2.k);
class Box { val: string | number = 0; }
const bx = new Box();
bx.val = "b";
bx.val += 7;
console.log("field", bx.val);
let n: string | number = "n";
n += 1.5;
n += -0;
n += NaN;
n += 1e21;
console.log("numbers", n);
let w: string | number = "w";
w += [1, 2] as any;
console.log("any array right", w);
let x: string | number | null = "x";
x += null as any;
console.log("null right", x);
