class V {
  valueOf(): number { return 7; }
  toString(): string { return "T"; }
}
const s = "s";
console.log("binary", s + new V());
console.log("template", `${new V()}`);
let t = "t";
t = t + new V();
console.log("assign", t);
const n = 1;
console.log("number + V", n + (new V() as any));
