// `+` uses ToPrimitive with the default hint: valueOf before toString.
class V {
  valueOf(): number { return 7; }
  toString(): string { return "T"; }
}
const o: any = { s: "x" };
if (typeof o.s === "string") {
  o.s += new V();
}
console.log("any property", o.s);
let a: any = "q";
if (typeof a === "string") {
  a += new V();
}
console.log("any local", a);
let u: string | number = "u";
u += new V();
console.log("union local", u);
let s = "s";
s += new V();
console.log("string local", s);
let [w] = "w";
w += new V();
console.log("loose local", w);
const d = new Date(0);
let ds: string | number = "d:";
ds += d.getTime();
console.log("date number", ds);
console.log("end");
