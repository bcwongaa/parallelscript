// `+` uses ToPrimitive with the default hint: valueOf before toString.
class V {
  valueOf(): number { return 7; }
  toString(): string { return "T"; }
}
const o: any = { s: "x" };
if (typeof o.s === "string") {
  o.s += new V();
}
console.log("any property", o.s);
let s = "s";
s += new V();
console.log("string local", s);
let [w] = "w";
w += new V();
console.log("loose local", w);
