let [p, q] = "a";
try {
  q += "!";
  console.log("q", q);
} catch (e) {
  console.log("threw", (e as Error).message);
}
let [r, s] = new Set(["x"]);
try {
  s += 1;
  console.log("s", s);
} catch (e) {
  console.log("threw", (e as Error).message);
}
console.log(p, r);
