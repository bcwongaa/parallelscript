// `+=` where the narrowed read is a string but the place's type is not.
let v: string | number = "a";
v += 1;
console.log("union narrowed by assignment", v, typeof v);
let v3: string | number = "a";
v3 += `t${1}`;
console.log("template", v3);
let v4: string | boolean = "s";
v4 += true;
console.log("string|boolean", v4);
let v5: string | undefined = "u";
v5 += "w";
console.log("string|undefined", v5);
let a: any = "q";
if (typeof a === "string") {
  a += 2;
}
console.log("any narrowed", a);
let un: unknown = "k";
if (typeof un === "string") {
  un += "!";
}
console.log("unknown narrowed", un);
const o: any = { s: "x" };
if (typeof o.s === "string") {
  o.s += 3;
}
console.log("any property narrowed", o.s);
const rec: Record<string, string | number> = { k: 1 };
rec.k = "r";
rec.k += 5;
console.log("record element", rec.k);
const rec2: Record<string, string | number> = { k: 1 };
rec2["k"] = "s";
rec2["k"] += 6;
console.log("record element access", rec2.k);
class Box { val: string | number = 0; }
const bx = new Box();
bx.val = "b";
bx.val += 7;
console.log("field", bx.val);
let n: string | number = "n";
n += 1.5;
n += -0;
n += NaN;
n += 1e21;
console.log("numbers", n);
let w: string | number = "w";
w += [1, 2] as any;
console.log("any array right", w);
let x: string | number | null = "x";
x += null as any;
console.log("null right", x);
