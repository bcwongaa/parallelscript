function* g(): Generator<number, string, string> {
  let v: string | number = "a";
  v += yield 1;
  let [w] = new Set(["w"]);
  w += yield 2;
  let s = "s";
  s += yield 3;
  return v + "|" + w + "|" + s;
}
const it = g();
it.next();
it.next("B");
it.next("C");
console.log(it.next("D").value);
async function f(): Promise<string> {
  let v: string | number = "x";
  v += await Promise.resolve("y");
  let [w] = "w";
  w += await Promise.resolve(1);
  return v + w;
}
f().then((r) => console.log(r));
