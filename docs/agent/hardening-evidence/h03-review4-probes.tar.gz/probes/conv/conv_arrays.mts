// Array sources (loose on the base, raw): element types that the binding now converts to.
interface P { x: number }
interface Q { y: number }
const pq: (P & Q)[] = [{ x: 1, y: 2 }];
const [a] = pq;
console.log("intersection", a.x + a.y, a === pq[0]);
const ro: Readonly<P>[] = [{ x: 3 }];
const [c] = ro;
console.log("Readonly", c.x, c === ro[0]);
const pa: Partial<P>[] = [{}];
const [d] = pa;
console.log("Partial", d.x, d === pa[0]);
const ob: object[] = [{}];
const [e] = ob;
console.log("object", e === ob[0]);
const em: {}[] = [1];
const [f] = em;
console.log("{}", f === em[0]);
const it: Iterable<number>[] = [[1, 2]];
const [g] = it;
console.log("Iterable", [...g], g === it[0]);
const rec: Record<string, number>[] = [{ k: 1 }];
const [r] = rec;
console.log("record", r.k, r === rec[0]);
const nested: { inner: { v: number[] } }[] = [{ inner: { v: [1] } }];
const [n] = nested;
n.inner.v.push(2);
console.log("nested shape", nested[0].inner.v, n === nested[0]);
