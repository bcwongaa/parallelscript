// A loose name past the end, returned where the return type allows undefined.
function fromArray(a: string[]): string | undefined {
  const [x] = a;
  return x;
}
console.log("array", fromArray([]));
function fromSet(s: Set<string>): string | undefined {
  const [x] = s;
  return x;
}
console.log("set", fromSet(new Set()));
function fromStr(s: string): string | undefined {
  const [, second] = s;
  return second;
}
console.log("string", fromStr("a"));
function gen<T>(s: T[]): T | undefined {
  const [x] = s;
  return x;
}
console.log("generic array", gen<number>([]));
const [y] = [] as string[];
const z: string | undefined = y;
console.log("assign", z);
