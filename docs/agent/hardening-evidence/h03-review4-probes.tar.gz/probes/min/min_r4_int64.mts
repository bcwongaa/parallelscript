// A loose name of a 64-bit integer type is read through a double (checkedConversion).
const big: int = 9007199254740993;
const [a] = new Set<int>([big]);
console.log("Set<int>", a, a === big);
function* g(): Generator<int> { yield big; }
const [b] = g();
console.log("Generator<int>", b, b === big);
const [k] = new Map<int, string>([[big, "v"]]).keys();
console.log("map keys", k, k === big);
const ub: u64 = 9007199254740993;
const [u] = new Set<u64>([ub]);
console.log("Set<u64>", u, u === ub);
const arr: int[] = [big];
const [c] = arr;
console.log("int[] (loose on the base too)", c, c === big);
