// Loose names bound from any values cast to typed iterables.
const m = new Map([["a", 1]]);
const a: any = m;
const [e] = a as Map<string, number>;
e[1] = 5;
console.log("any as Map", e === e, e);
const it: Iterable<[string, number]> = a;
const [h] = it;
h[1] = 7;
console.log("any into Iterable", h === h, h);
const arrAny: any = [["x", 1]];
const [k] = arrAny as [string, number][];
k[1] = 8;
console.log("any array as", k === k, k === arrAny[0], arrAny[0]);
const [k2] = arrAny as Array<Array<string | number>>;
k2.push("z");
console.log("any array of arrays", k2 === arrAny[0], arrAny[0]);
const wrong: any = [5];
try {
  const [x] = wrong as Iterable<[string, number]>;
  console.log("bound wrong item");
  console.log(typeof x);
} catch (err) {
  console.log("threw", (err as Error).message);
}
