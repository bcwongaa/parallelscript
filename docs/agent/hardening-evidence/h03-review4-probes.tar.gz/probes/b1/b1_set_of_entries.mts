const m = new Map([["a", 1]]);
const s = new Set(m);
const [e] = s;
e[1] = 5;
console.log("set of entries", e, [...s][0], [...s][0] === e);
const arr = Array.from(m);
const [f] = arr;
f[1] = 6;
console.log("Array.from entries", f, arr[0] === f);
