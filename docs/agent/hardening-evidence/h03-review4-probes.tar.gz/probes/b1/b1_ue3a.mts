// Map entries (arrays at run time) as a union-with-tuple: parameter pattern and assignment pattern.
const m = new Map([["a", 1]]);
function f([e]: Iterable<[string, number] | null>): void {
  if (e) {
    console.log("param pattern", e.length, e[0], e[1]);
  }
}
f(m);
