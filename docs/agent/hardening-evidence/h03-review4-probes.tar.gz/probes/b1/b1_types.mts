// Loose names over more element types: each bound once, identity kept.
const vt: [string, ...number[]] = ["a", 1, 2];
const [v1] = new Set<[string, ...number[]]>([vt]);
v1.push(3);
console.log("variadic tuple", v1 === vt, vt);
const ot: [string, number?] = ["o"];
const [o1] = new Set<[string, number?]>([ot]);
o1[1] = 4;
console.log("optional tuple", o1 === ot, ot);
const rt: readonly [number, number] = [1, 2] as const;
const [r1] = new Set([rt]);
console.log("readonly tuple", r1 === rt, r1);
const ob: object = { a: 1 };
const [b1] = new Set<object>([ob]);
console.log("object", b1 === ob);
const rec: Record<string, number> = { a: 1 };
const [rc] = new Set([rec]);
rc.b = 2;
console.log("record", rc === rec, rec);
const dt: Date | [number, number] = [1, 2];
const [u1] = new Set<Date | [number, number]>([dt]);
console.log("date|tuple", u1 === dt, u1);
const p = Promise.resolve(1);
const [pp] = new Set([p]);
console.log("promise", pp === p);
type Brand = [string, number] & { readonly brand?: true };
const br: Brand = ["b", 1] as Brand;
const [bb] = new Set<Brand>([br]);
console.log("branded", bb === br);
function firstOf<T>(s: Set<T>): T | undefined {
  const [x] = s;
  return x;
}
const tt: [string, number] = ["g", 1];
console.log("generic", firstOf(new Set([1])), firstOf(new Set([tt])) === tt, firstOf(new Set([{ k: 1 }])));
const nested: [string, number][][] = [[["n", 1]]];
const [ninner] = nested;
ninner[0][1] = 5;
console.log("array of arrays of tuples", ninner === nested[0], nested);
const [[deep]] = nested;
deep[1] = 6;
console.log("nested pattern deep", deep === nested[0][0], nested[0][0]);
class K { constructor(public v: number) {} }
const [kk] = new Set([new K(1)]);
kk.v = 2;
console.log("class", kk === kk, kk.v);
const [fa] = new Set([new Float64Array(2)]);
fa[0] = 1.5;
console.log("typed array elem", fa === fa, fa[0]);
