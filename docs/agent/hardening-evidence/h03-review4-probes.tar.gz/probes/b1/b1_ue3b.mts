// Map entries (arrays at run time) as a union-with-tuple: parameter pattern and assignment pattern.
const m = new Map([["a", 1]]);
const [[k, v]] = new Map([["q", 2]]) as Iterable<[string, number] | [string, string]>;
console.log("nested", k, v);
