// Generators that yield tuples, objects and arrays; loose names in generator and async bodies.
const shared: [string, number] = ["s", 1];
const sobj = { n: 1 };
function* tuples(): Generator<[string, number]> { yield shared; yield ["b", 2]; }
function* objs(): Generator<{ n: number }> { yield sobj; }
const [t] = tuples();
t[1] = 2;
console.log("gen tuple", t === shared, shared);
const [o] = objs();
o.n = 3;
console.log("gen obj", o === sobj, sobj.n);
const m = new Map([["a", 1]]);
function* body(): Generator<boolean | [string, number]> {
  const [e] = m;
  e[1] = 50;
  yield e === e;
  yield e;
  const [f] = m.entries();
  f[1] = 51;
  yield f === f;
  yield f;
}
for (const v of body()) console.log("gen body", v);
async function asy(): Promise<void> {
  const [e] = m;
  await null;
  e[1] = 60;
  console.log("async", e === e, e);
  const [f] = m.entries();
  await null;
  f[1] = 61;
  console.log("async it", f === f, f);
}
async function* agen(): AsyncGenerator<[string, number]> {
  const [e] = m;
  e[1] = 70;
  yield e;
  await null;
  yield e;
}
async function main(): Promise<void> {
  await asy();
  const seen: [string, number][] = [];
  for await (const v of agen()) seen.push(v);
  console.log("async gen", seen[0] === seen[1], seen[0]);
}
main();
