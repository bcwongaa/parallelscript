// A map's entry (an array at run time) bound through a union element type.
const m = new Map([["a", 1]]);
const it: Iterable<[string, number] | null> = m;
const [e] = it;
if (e) {
  e[1] = 5;
  console.log("tuple|null", e, e === e);
}
const it2: Iterable<[string, number] | string> = m;
const [f] = it2;
if (typeof f !== "string") {
  f[1] = 6;
  console.log("tuple|string", f, f === f);
}
const arrs: ([string, number] | null)[] = [...m];
const [g] = arrs;
if (g) {
  g[1] = 7;
  console.log("array of tuple|null", g, g === g, arrs[0] === g);
}
