// Map entries (arrays at run time) typed through a union with a tuple: non-loose paths.
const m = new Map([["a", 1]]);
const it: Iterable<[string, number] | null> = m;
for (const e of it) {
  if (e) {
    e[1] = 5;
    console.log("for-of", e.length, e, e === e);
  }
}
const [d = null] = it;
if (d) {
  console.log("default", d.length, d);
}
function f(x: [string, number] | null): void {
  if (x) console.log("param", x.length, x);
}
for (const e of it) f(e);
