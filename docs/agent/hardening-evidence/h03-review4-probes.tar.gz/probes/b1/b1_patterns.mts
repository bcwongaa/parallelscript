// Defaults, rest, nested patterns, for-let heads with closures.
const m = new Map([["a", 1]]);
const d: [string, number] = ["z", 0];
const [x, y = d] = m;
console.log("default", y === d, y === y, x);
const [x2 = d] = m;
x2[1] = 4;
console.log("default not taken", x2 === x2, x2);
const [first, ...rest] = new Map([["a", 1], ["b", 2]]);
rest[0][1] = 22;
first[1] = 11;
console.log("rest", first === first, first, rest, rest[0] === rest[0]);
const [[k, v]] = m;
console.log("nested", k, v);
const fns: (() => [string, number])[] = [];
let n = 0;
for (let [e] = m; n < 2; n++) {
  e[1]++;
  fns.push(() => e);
}
console.log("for head", fns[0]() === fns[1](), fns[0](), fns[1]());
const fns2: (() => [string, number])[] = [];
let n2 = 0;
for (let [e] = m.entries(); n2 < 2; n2++) {
  e[1] += 10;
  fns2.push(() => e);
}
console.log("for head iter", fns2[0]() === fns2[1](), fns2[0]());
let [le] = m;
const before = le;
le[1] = 99;
le = ["n", 0];
console.log("let reassign", before, le, before === le);
