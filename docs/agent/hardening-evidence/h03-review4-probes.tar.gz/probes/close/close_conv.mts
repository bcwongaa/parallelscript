// A loose name's conversion that throws closes the iterator first (protected region).
function* g(): Generator<[string, number]> {
  try {
    yield 5 as any;
    yield ["b", 2];
  } finally {
    console.log("gen finally");
  }
}
try {
  const [e, f] = g();
  console.log("bound", typeof e, f);
} catch (err) {
  console.log("threw", (err as Error).message);
}
class It implements Iterator<[string, number]> {
  i = 0;
  next(): IteratorResult<[string, number]> {
    this.i++;
    if (this.i === 2) return { value: "bad" as any, done: false };
    return { value: ["a", this.i], done: false };
  }
  return(): IteratorResult<[string, number]> {
    console.log("return called");
    return { value: undefined, done: true };
  }
  [Symbol.iterator](): It { return this; }
}
try {
  const [a, b] = new It();
  console.log("bound2", a, typeof b);
} catch (err) {
  console.log("threw2", (err as Error).message);
}
function* objs(): Generator<{ n: number }> {
  try {
    yield { n: 1 };
    yield 7 as any;
  } finally {
    console.log("objs finally");
  }
}
try {
  const [o1, o2] = objs();
  console.log("bound3", o1, typeof o2);
} catch (err) {
  console.log("threw3", (err as Error).message);
}
