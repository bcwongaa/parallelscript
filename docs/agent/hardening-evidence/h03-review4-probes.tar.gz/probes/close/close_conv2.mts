// The item reaches the pattern unchecked (a Generator<any> held as an Iterable of tuples):
// the loose name's conversion throws inside the pattern; the generator must be closed.
function* ga(): Generator<any> {
  try {
    yield 5;
    yield ["b", 2];
  } finally {
    console.log("ga finally");
  }
}
const it: Iterable<[string, number]> = ga();
try {
  const [e] = it;
  console.log("bound", typeof e);
} catch (err) {
  console.log("threw", (err as Error).message);
}
const it2: Iterable<[string, number]> = ga();
try {
  const [x, y] = it2;
  console.log("bound2", typeof x, y);
} catch (err) {
  console.log("threw2", (err as Error).message);
}
function* gb(): Generator<any> {
  try {
    yield { n: "str" };
    yield 1;
  } finally {
    console.log("gb finally");
  }
}
interface N { n: number }
const it3: Iterable<N> = gb();
try {
  const [o] = it3;
  console.log("bound3", typeof o);
} catch (err) {
  console.log("threw3", (err as Error).message);
}
const it4: Iterable<number[]> = ga();
try {
  const [arr] = it4;
  console.log("bound4", typeof arr);
} catch (err) {
  console.log("threw4", (err as Error).message);
}
console.log("end");
