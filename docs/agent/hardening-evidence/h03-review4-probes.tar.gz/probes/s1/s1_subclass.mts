function* inner(): Generator<number> {
  try {
    yield 100;
    yield 200;
  } finally {
    console.log("F iterator closed");
  }
}
class F extends Float64Array {
  [Symbol.iterator](): ArrayIterator<number> {
    return inner() as any;
  }
}
const f: Float64Array = new F(3);
function thrower(): number { throw new Error("t"); }
try {
  const [a, b = thrower()] = f;
  console.log("bound", a, b);
} catch (e) {
  console.log("caught", (e as Error).message);
}
const [c] = f;
console.log("c", c);
