// Typed-array patterns without the close-on-throw handler.
function thrower(): number { throw new Error("default threw"); }
try {
  const [a, b = thrower()] = new Float64Array([1]);
  console.log("no throw", a, b);
} catch (e) {
  console.log("caught", (e as Error).message);
}
let calls = 0;
const f = new Int32Array([5, 6, 7]);
const [p, q = ++calls, r = ++calls, s = ++calls] = f;
console.log("defaults", p, q, r, s, calls);
const [h, ...rest] = new Uint8Array([1, 2, 3]);
console.log("rest", h, rest, Array.isArray(rest));
const anyTA: any = new Float32Array([1.5, 2.5]);
const [x1, x2, x3] = anyTA;
console.log("any typed array", x1, x2, x3);
const [y1, y2] = anyTA as Float32Array;
console.log("any as Float32Array", y1, y2);
function firstTwo<T extends Float64Array>(t: T): number {
  const [m, n] = t;
  return m + n;
}
console.log("generic", firstTwo(new Float64Array([3, 4])));
function* gen(): Generator<number, void, number> {
  const [a, b = 5] = new Float64Array([1]);
  const c = yield a;
  const d = yield b;
  console.log("gen got", a, b, c, d);
}
const it = gen();
console.log(it.next().value, it.next(10).value, it.next(20).done);
async function asy(): Promise<void> {
  const [a = 7, b] = new Float64Array(0);
  await null;
  console.log("async got", a, b);
}
asy();
for (let i = 0; i < 3; i++) {
  try {
    const [z = i === 1 ? thrower() : i] = new Float64Array(0);
    if (z === 2) break;
    console.log("loop", z);
  } catch (e) {
    console.log("loop caught", i);
    continue;
  } finally {
    console.log("finally", i);
  }
}
const fns: (() => number)[] = [];
for (let [v = 0] = new Float64Array([9]); v < 11; v++) fns.push(() => v);
console.log("for head closures", fns.map((g) => g()));
const big = new Float64Array(5);
const [, , third, , fifth, sixth] = big;
console.log("elisions", third, fifth, sixth);
