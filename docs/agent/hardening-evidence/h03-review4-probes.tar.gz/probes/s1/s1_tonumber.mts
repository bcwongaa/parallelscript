// pts_value_to_number_checked: boxed 64-bit integers, -0, NaN, infinities, non-numbers.
const big: int = 9007199254740993;
const ubig: u64 = 18446744073709551615;
const nbig: i64 = -9007199254740995;
const vals: any[] = [big, ubig, nbig, -0, NaN, Infinity, -Infinity, 1.5, 0];
for (const v of vals) {
  const n: number = v;
  console.log(n, Object.is(n, -0), Number.isNaN(n), n + 1);
}
const bad: any[] = ["s", true, null, undefined, {}, [1]];
for (const v of bad) {
  try {
    const n: number = v;
    console.log("no throw", n);
  } catch (e) {
    console.log((e as Error).name, (e as Error).message);
  }
}
const [z, nn, inf] = new Set([-0, NaN, Infinity]);
console.log("set loose", Object.is(z, -0), Number.isNaN(nn), inf, z + 1);
const [f0, f1, f2] = new Float64Array([-0, NaN, -Infinity]);
console.log("f64 loose", Object.is(f0, -0), Number.isNaN(f1), f2);
const [c] = new Set<int>([big]);
const asNum: number = c;
console.log("int set", c, asNum);
