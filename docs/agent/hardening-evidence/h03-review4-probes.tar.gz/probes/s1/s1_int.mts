const big: int = 9007199254740993;
const [c] = new Set<int>([big]);
console.log("int set", c, c + 1, c === big);
const [d] = [big];
console.log("int array", d, d === big);
const [e] = new Map<int, int>([[big, big]]);
console.log("int map entry", e);
function* g(): Generator<int> { yield big; }
const [h] = g();
console.log("int generator", h, h === big);
const [u] = new Set<u64>([18446744073709551615]);
console.log("u64 set", u);
