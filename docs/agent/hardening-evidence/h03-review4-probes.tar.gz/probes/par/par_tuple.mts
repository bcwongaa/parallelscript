// Loose tuple names from map entries, captured by and declared in parallel code.
import { range } from "pts:parallel";
const m = new Map([["a", 1], ["b", 2]]);
const [e1, e2] = m;
const out = new Float64Array(4);
parallel for (const i of range(0, 4)) {
  out[i] = i + e1[1] + e2[1] + e1[0].length;
}
console.log(Array.from(out));
const res = new Float64Array(4);
parallel for (const i of range(0, 4)) {
  const local = new Map([["k", i]]);
  const [en] = local;
  en[1] += 10;
  res[i] = en[1];
}
console.log(Array.from(res));
const xs = [1, 2, 3, 4];
console.log(xs.par.map((x) => {
  const [p] = new Map([["z", x]]);
  p[1] *= 3;
  return p[1] + (p === p ? 1000 : 0);
}));
