#!/bin/bash
# csize.sh FILE: emit C with base and $FIX (default snap4); prints "lines_base lines_fix exit_base exit_fix file"
FIX=${FIX:-/tmp/h09/snap4}; BASE=${BASE:-/tmp/h09/base}
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review2/run/cs.XXXX); cd "$d"
PTS_HOME=$BASE timeout 120 $BASE/pts-bin/pts emit-c "$f" -o b.c >b.err 2>&1; eb=$?
PTS_HOME=$FIX timeout 120 $FIX/pts-bin/pts emit-c "$f" -o s.c >s.err 2>&1; es=$?
lb=$( [ -f b.c ] && wc -l < b.c || echo 0); ls=$( [ -f s.c ] && wc -l < s.c || echo 0)
echo "$lb $ls $eb $es $f"
cd /; rm -rf "$d"
