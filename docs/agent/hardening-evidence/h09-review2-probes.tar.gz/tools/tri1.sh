#!/bin/bash
# tri1.sh FILE: base, fix and node outputs into FILE.{base,snap,node}.out; prints one status line
FIX=${FIX:-/tmp/h09/snap4}; BASE=${BASE:-/tmp/h09/base}; node=$HOME/.local/node/bin/node
f=$(realpath "$1"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review2/run/r.XXXX)
cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
(cd "$d" && PTS_HOME=$BASE timeout 300 $BASE/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > "$f.base.out"
(cd "$d" && PTS_HOME=$FIX timeout 300 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > "$f.snap.out"
[ "${NONODE:-}" == 1 ] || (cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]") > "$f.node.out"
rm -rf "$d"
bs=$(cmp -s "$f.base.out" "$f.snap.out" && echo B=S || echo B!=S)
sn=$(cmp -s "$f.snap.out" "$f.node.out" && echo S=N || echo S!=N)
bn=$(cmp -s "$f.base.out" "$f.node.out" && echo B=N || echo B!=N)
echo "$bs $sn $bn base$(tail -1 $f.base.out) snap$(tail -1 $f.snap.out) $1"
