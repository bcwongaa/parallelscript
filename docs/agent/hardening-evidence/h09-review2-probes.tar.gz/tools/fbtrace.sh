#!/bin/bash
# fbtrace.sh FILE: emit-c with the fallback-tracing CLI (snap4 + overlay); prints "FB <file> <reason>" when AllInstances failed, else "OK"/"ERR"
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review2/run/fb.XXXX)
out=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap4 timeout 300 /tmp/h09/review2/ov/pts emit-c "$f" -o $d/o.c 2>&1); e=$?
rm -rf $d
fb=$(echo "$out" | grep '^PTS_FALLBACK' | head -1)
if [ -n "$fb" ]; then echo "FB exit$e $f :: ${fb:0:250}"; else echo "NOFB exit$e $f"; fi
