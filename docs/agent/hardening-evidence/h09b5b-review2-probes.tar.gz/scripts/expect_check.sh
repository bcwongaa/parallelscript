#!/bin/bash
# expect_check.sh cli home file: build with cli, run, and compare with the file's // expect: block.
cli=$1; home=$2; f=$3; n=$(basename $f .pts); tmp=/tmp/h09b5b/review2/out/expect; mkdir -p $tmp
cd $(dirname $f)
PTS_HOME=$home $cli build $f -o $tmp/$n.bin > $tmp/$n.build.txt 2>&1 || { echo "BUILDFAIL $n"; exit; }
timeout 20 $tmp/$n.bin > $tmp/$n.out.txt 2>&1; rm -f $tmp/$n.bin
sed -n '/^\/\/ expect:/,$p' $f | sed '1d;s|^// \{0,1\}||' > $tmp/$n.exp
cmp -s $tmp/$n.out.txt $tmp/$n.exp && echo "OK $n" || echo "DIFF $n"
