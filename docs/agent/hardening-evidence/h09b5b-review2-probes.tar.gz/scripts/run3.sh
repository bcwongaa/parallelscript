#!/bin/bash
# run3.sh file.pts [timeout_s]: base and fix (snap-d) CLIs build + run, then Node on a .mts copy.
# Outputs go to /tmp/h09b5b/review2/out/<name>.{base,fix}.{build,out}.txt and <name>.node.txt; binaries are deleted.
f=$1; to=${2:-300}; name=$(basename "$f" .pts); dir=/tmp/h09b5b/review2/out; mkdir -p $dir
for side in base fix; do
  if [ $side = base ]; then home=/tmp/h09b5b/base; else home=/tmp/h09b5b/snap-d; fi
  cli=$home/pts-bin/pts
  out=$dir/$name.$side.bin
  ( ulimit -v 6000000; PTS_HOME=$home /usr/bin/time -f "wall=%es maxrss=%MkB" timeout $to $cli build "$f" -o "$out" ) > $dir/$name.$side.build.txt 2>&1
  code=$?
  echo "== $side build exit=$code $(grep '^wall=' $dir/$name.$side.build.txt | tail -1)"
  grep -v '^wall=\|^Command exited' $dir/$name.$side.build.txt | head -c 1500
  if [ -f "$out" ]; then timeout 20 "$out" > $dir/$name.$side.out.txt 2>&1; echo "-- run exit=$?"; head -c 1500 $dir/$name.$side.out.txt; rm -f "$out"; fi
done
cp "$f" $dir/$name.mts; echo "== node"; timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $dir/$name.mts > $dir/$name.node.txt 2>&1; head -c 1500 $dir/$name.node.txt; rm -f $dir/$name.mts
