#!/bin/bash
# emitc_loop.sh list log: emitc_cmp.sh on each file of list, one at a time, appending to log.
while read -r f; do /tmp/h09b5b/review2/scripts/emitc_cmp.sh "$f" >> "$2" 2>&1; done < "$1"
echo finished > "$2.done"
