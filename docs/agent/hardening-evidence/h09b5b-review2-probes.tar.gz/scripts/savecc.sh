#!/bin/sh
# savecc.sh: a PTS_CC that saves each main.c it is given (as out/cc-saved-N.c) and runs clang.
for arg in "$@"; do case "$arg" in */main.c) n=$(ls /tmp/h09b5b/review2/out/cc-saved-*.c 2>/dev/null | wc -l); cp "$arg" /tmp/h09b5b/review2/out/cc-saved-$n.c ;; esac; done
exec clang "$@"
