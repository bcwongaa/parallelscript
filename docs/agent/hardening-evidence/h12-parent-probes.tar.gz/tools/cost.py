#!/usr/bin/env python3
"""cost.py DIR: for each DIR/*.pts, build with the base and the prototype CLIs and count
instructions (callgrind) for N=200000 and N=0 loop iterations; prints the loop's instructions
(N run minus 0 run) per CLI and the ratio. Binaries are deleted after each probe."""
import glob, os, re, shutil, subprocess, sys, tempfile

CLIS = {"base": "/tmp/h12/base/pts-bin/pts", "new": "/tmp/h12/snap2/pts-bin/pts"}
N = "200000"


def instructions(binary, n, d):
    out = os.path.join(d, "cg.out")
    subprocess.run(["valgrind", "--tool=callgrind", f"--callgrind-out-file={out}", binary, n], cwd=d, capture_output=True,
                   env=dict(os.environ, PTS_THREADS="1", GC_DONT_GC="1"), timeout=600)
    text = open(out).read()
    os.unlink(out)
    m = re.search(r"^summary:\s+(\d+)", text, re.M) or re.search(r"^totals:\s+(\d+)", text, re.M)
    return int(m.group(1))


for path in sorted(glob.glob(os.path.join(sys.argv[1], "*.pts"))):
    row = {}
    for name, cli in CLIS.items():
        d = tempfile.mkdtemp(prefix="cost.", dir="/tmp/h12/repro/work")
        try:
            shutil.copy(path, os.path.join(d, "p.pts"))
            b = subprocess.run([cli, "build", "p.pts", "-o", "p.bin"], cwd=d, capture_output=True, env=dict(os.environ, PTS_HOME="/tmp/h12/base"))
            if b.returncode != 0:
                row[name] = "build failed: " + b.stderr.decode()[:120]
                continue
            row[name] = instructions(os.path.join(d, "p.bin"), N, d) - instructions(os.path.join(d, "p.bin"), "0", d)
        finally:
            shutil.rmtree(d, ignore_errors=True)
    ratio = f"{row['new'] / row['base']:.2f}x" if all(isinstance(v, int) for v in row.values()) and row["base"] else "-"
    print(f"{os.path.basename(path):<34} base {row['base']}  new {row['new']}  {ratio}", flush=True)
