import json,collections,sys
c=collections.Counter(); pk=set(); fails=[]; corpus=''
for line in open(sys.argv[1]):
    try: e=json.loads(line)
    except: continue
    a=e.get('Action')
    if e.get('Test') and a in('pass','fail','skip'):
        c[a]+=1
        if a=='fail': fails.append(e['Test'])
    elif not e.get('Test') and a in ('pass','fail'): pk.add((e['Package'].split('/')[-1],a))
    o=e.get('Output','')
    if 'corpus: 300 programs' in o: corpus=o.strip()
print(dict(c)); print(sorted(pk)); print(corpus); print(fails[:30])
