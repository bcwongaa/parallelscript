#!/bin/bash
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap5/pts/tests/||; s|/|__|g; s|.pts$||')
b=$(PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/review/nofb/nofb-base all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
s=$(PTS_HOME=/tmp/h09b4/snap5 timeout 120 /tmp/h09b4/review/round2/nofb/nofb-snap5 all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
echo "$n|$b|$s"
