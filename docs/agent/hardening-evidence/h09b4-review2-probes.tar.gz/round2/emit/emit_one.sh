#!/bin/bash
# emit_one.sh file.pts -> "relname base_lines snap5_lines base_exit snap5_exit same_c"
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap5/pts/tests/||; s|/|__|g; s|.pts$||')
o=/tmp/h09b4/review/round2/emit/out
PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/base/pts-bin/pts emit-c "$f" > $o/$n.base.c 2>$o/$n.base.err; be=$?
PTS_HOME=/tmp/h09b4/snap5 timeout 120 /tmp/h09b4/snap5/pts-bin/pts emit-c "$f" > $o/$n.snap.c 2>$o/$n.snap.err; se=$?
same=$(cmp -s $o/$n.base.c $o/$n.snap.c && echo same || echo diff)
[ $same = same ] && rm -f $o/$n.base.c $o/$n.snap.c
echo "$n $(wc -l < $o/$n.base.c 2>/dev/null || echo 0) $(wc -l < $o/$n.snap.c 2>/dev/null || echo 0) $be $se $same"
