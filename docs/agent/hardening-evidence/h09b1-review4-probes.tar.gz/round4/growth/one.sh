#!/bin/bash
# one.sh file.pts: AllInstances-alone emit-c with snap6; prints file, tree, mode, exit, C lines.
f=$1
n=$(echo "$f" | sed 's|/tmp/h09b/snap6/pts/tests/||; s|/|__|g')
l=$(timeout 300 /tmp/h09b1-review/allinst/ptsall_snap6 "$f" 2>/dev/null | wc -l)
e=${PIPESTATUS[0]}
timeout 300 /tmp/h09b1-review/allinst/ptsall_snap6 "$f" > /dev/null 2>&1; e=$?
printf "%s\t%s\t%s\t%s\t%s\n" "$n" "snap6" "all" "$e" "$l"
