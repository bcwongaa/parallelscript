#!/bin/bash
rel="$1"; S=/tmp/h09b4b2/review4/tree; O=/tmp/h09b4b2/review4/emitc
key=$(echo "$rel" | tr '/' '_')
for which in fix base; do
  if [ $which = fix ]; then home=/tmp/h09b4b2/s/snap4; else home=/tmp/h09b4b2/base; fi
  ( cd $(dirname $S/$rel) && PTS_HOME=$home timeout 300 $home/pts-bin/pts emit-c $(basename $rel) -o $O/$which/$key.c > $O/$which/$key.err 2>&1; echo $? > $O/$which/$key.rc )
done
