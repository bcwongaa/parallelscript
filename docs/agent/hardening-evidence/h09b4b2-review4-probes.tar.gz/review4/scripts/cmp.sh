#!/bin/bash
# usage: cmp.sh file.pts -> node / snap4 / snap3 / base outputs
f="$1"; name=$(basename "$f" .pts); d=/tmp/h09b4b2/review4
out=$d/out/$name; mkdir -p $out
cp "$f" $out/$name.mts
( cd $out && TZ=America/New_York timeout 20 ~/.local/node/bin/node --no-warnings --experimental-transform-types $name.mts > node.txt 2>&1; echo "exit=$?" >> node.txt )
LIST="snap4 base"; [ -n "$WITH3" ] && LIST="snap4 snap3 base"
for which in $LIST; do
  case $which in snap4) home=/tmp/h09b4b2/s/snap4;; snap3) home=/tmp/h09b4b2/s/snap3;; base) home=/tmp/h09b4b2/base;; esac
  if [ -n "$ONLY4" ] && [ $which != snap4 ]; then continue; fi
  bin=$d/bin/$name.$which.bin
  PTS_HOME=$home timeout 300 $home/pts-bin/pts build "$f" -o $bin > $out/$which.txt 2>&1
  rc=$?
  if [ $rc -eq 0 ]; then
    ( cd $out && TZ=America/New_York timeout 20 $bin >> $out/$which.txt 2>&1; echo "exit=$?" >> $out/$which.txt )
  else
    echo "BUILD exit=$rc" >> $out/$which.txt
  fi
  rm -f $bin
done
if [ -z "$QUIET" ]; then for which in node snap4 snap3 base; do [ -f $out/$which.txt ] && { echo "=== $which"; cat $out/$which.txt; }; done; fi
s4=$(cat $out/snap4.txt); n=$(cat $out/node.txt); b=$(cat $out/base.txt 2>/dev/null); s3=$(cat $out/snap3.txt 2>/dev/null)
st="snap4"; [ "$s4" = "$n" ] && st="$st=node"; [ "$s4" = "$b" ] && st="$st=base"; [ "$s4" = "$s3" ] && st="$st=snap3"
echo "SUMMARY $name $st"
