#!/bin/bash
# callgrind instruction counts of emit-c, one job at a time
cd /tmp/h09b4b2/review4/cg
for spec in "alias_dispatcher.pts:." "alias_cost.pts:." "alias_chain.pts:." "generic_optional_chain_calls.pts:/tmp/h09b4b2/review4/tree/pts/tests/run" "generic_interface_methods.pts:/tmp/h09b4b2/review4/tree/pts/tests/run" "sql_query_parser.pts:/tmp/h09b4b2/review4/tree/pts/tests/corpus/text" "big_function_150.pts:."; do
  f=${spec%%:*}; dir=${spec#*:}
  for w in snap4 base; do case $w in snap4) h=/tmp/h09b4b2/s/snap4;; base) h=/tmp/h09b4b2/base;; esac
    c=$(cd $dir && GOMAXPROCS=1 PTS_HOME=$h valgrind --tool=callgrind --callgrind-out-file=/dev/null $h/pts-bin/pts emit-c $f -o /dev/null 2>&1 | grep Collected | sed 's/.*Collected : //')
    echo "$f $w $c" >> counts-seq.txt
  done
done
touch CGSEQ.DONE
