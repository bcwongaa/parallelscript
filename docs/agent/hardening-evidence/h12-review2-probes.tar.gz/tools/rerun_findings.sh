#!/bin/bash
# Reruns the probes behind the round-2 findings against node, base, snapshot 2 and snapshot 3.
cd /tmp/h12/review2/p
W=${W:-2} python3 /tmp/h12/review2/tools/run3.py /tmp/h12/review2/rerun-findings.json \
  w01_obj_in_assign_array.pts w06_nested_default_rest.pts w07_obj_nested_deeper.pts w08_shorthand_obj_rest.pts w11_param_object_array.pts \
  l11_or_assign_loose_rhs.pts
python3 /tmp/h12/review2/tools/show.py /tmp/h12/review2/rerun-findings.json
# compile-time growth of isLoose (emit-c only): snapshot 2 vs snapshot 3
for f in dense10.pts dense12.pts sparse40_3.pts c10_register_machine.pts; do
  for s in snap2 snap3; do
    d=$(mktemp -d /tmp/h12/review2/run.XXXX); cp $f $d/p.pts
    st=$(date +%s.%N); (cd $d && PTS_HOME=/tmp/h12/$s timeout 120 /tmp/h12/$s/pts-bin/pts emit-c p.pts > /dev/null); rc=$?
    echo "$f $s rc=$rc secs=$(echo "$(date +%s.%N) - $st" | bc)"; rm -rf $d
  done
done
