#!/usr/bin/env python3
# usage: run3.py OUT.json probe.pts...  — runs node (.mts copy), base, snap2, snap3 per probe (4 probes in parallel)
import sys, json, subprocess, tempfile, shutil, os, concurrent.futures
CLIS = {"base": ("/tmp/h12/base/pts-bin/pts", "/tmp/h12/base"),
        "snap2": ("/tmp/h12/snap2/pts-bin/pts", "/tmp/h12/snap2"),
        "snap3": ("/tmp/h12/snap3/pts-bin/pts", "/tmp/h12/snap3")}
def run(path):
    d = tempfile.mkdtemp(dir="/tmp/h12/review2")
    try:
        shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
        res = {}
        try:
            r = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=30)
            res["node"] = (r.returncode, r.stdout + r.stderr)
        except subprocess.TimeoutExpired:
            res["node"] = (124, "")
        for name, (cli, home) in CLIS.items():
            env = dict(os.environ, PTS_HOME=home)
            try:
                r = subprocess.run([cli, "run", "p.pts"], cwd=d, capture_output=True, text=True, timeout=180, env=env)
                out = r.stdout + r.stderr
                res[name] = (r.returncode, out.replace(d, "<d>"))
            except subprocess.TimeoutExpired:
                res[name] = (124, "TIMEOUT")
        return path, res
    finally:
        shutil.rmtree(d, ignore_errors=True)
out = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "4"))) as ex:
    for path, res in ex.map(run, sys.argv[2:]):
        out[path] = res
        n = res["node"]
        def tag(k):
            return "=" if res[k] == n else ("x%d" % res[k][0])
        print(f"{os.path.basename(path):45s} base{tag('base'):5s} snap2{tag('snap2'):5s} snap3{tag('snap3'):5s}" + ("   <-- snap3 differs from snap2" if res['snap3'] != res['snap2'] else ""), flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1)
