#!/usr/bin/env python3
# usage: run_ns.py CLI HOME probe.pts...  — node vs one CLI, 4 in parallel; prints mismatches
import sys, subprocess, tempfile, shutil, os, concurrent.futures
cli, home = sys.argv[1], sys.argv[2]
def run(path):
    d = tempfile.mkdtemp(dir="/tmp/h12/review2")
    try:
        shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
        r = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=30)
        n = (r.returncode, r.stdout + r.stderr)
        try:
            r = subprocess.run([cli, "run", "p.pts"], cwd=d, capture_output=True, text=True, timeout=300, env=dict(os.environ, PTS_HOME=home))
            p = (r.returncode, (r.stdout + r.stderr).replace(d, "<d>"))
        except subprocess.TimeoutExpired:
            p = (124, "TIMEOUT")
        return path, n, p
    finally:
        shutil.rmtree(d, ignore_errors=True)
ok = bad = 0
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "4"))) as ex:
    for path, n, p in ex.map(run, sys.argv[3:]):
        if n == p: ok += 1
        else:
            bad += 1
            print("DIFF", path, "node rc", n[0], "pts rc", p[0])
            import difflib
            print("\n".join(list(difflib.unified_diff(n[1].split("\n"), p[1].split("\n"), "node", "pts", lineterm=""))[:16]))
print("ok", ok, "diff", bad)
