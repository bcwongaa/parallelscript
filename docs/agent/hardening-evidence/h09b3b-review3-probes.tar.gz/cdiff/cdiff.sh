#!/bin/bash
# cdiff.sh: emit-c each program with base and snap3r; print SAME/DIFF/ERR per file, with the
# path prefix of each tree normalised (the run tests are read from snap3r for both).
while read f; do
  b=/tmp/h09b3b/review3/cdiff/out/$(echo "$f" | sed 's#/tmp/h09b3b/snap4r/##; s#/#__#g')
  PTS_HOME=/tmp/h09b3b/base /tmp/h09b3b/base/pts-bin/pts emit-c "$f" -o "$b.base.c" > /dev/null 2>&1; be=$?
  PTS_HOME=/tmp/h09b3b/snap4r /tmp/h09b3b/snap4r/pts-bin/pts emit-c "$f" -o "$b.snap.c" > /dev/null 2>&1; se=$?
  if [ $be != 0 ] || [ $se != 0 ]; then echo "ERR base=$be snap=$se $f"; elif cmp -s "$b.base.c" "$b.snap.c"; then echo "SAME $f"; rm -f "$b.base.c" "$b.snap.c"; else echo "DIFF $(wc -l < $b.base.c) $(wc -l < $b.snap.c) $f"; fi
done
