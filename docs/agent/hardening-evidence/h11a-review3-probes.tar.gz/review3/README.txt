H11a review round 3 (snapshot 5 = 441cc503e in /tmp/h11/snap2, base /tmp/h11/base).
tools/run.sh [-N|-S|-B] FILE...: Node (.mts copy), snapshot and base runs; outputs in out/<name>.{node,snap,base}[.err|.build]
probes/prev/: round-1 and round-2 repros rerun on snapshot 5 (node and snapshot only)
probes/a/: R2-F2 reordering (type guards, assertion functions, overloads, generic T | undefined, call/apply/bind, callbacks)
probes/b/: madeLiterals (nested, spread, union members, getters/methods, iterator results, as const, yields in literals across generic instances)
probes/c/: mayHaveChanged coverage for stale loose locals (destructuring and object assignment in closures, loop-captured lets, async, class methods, parameters, generators, shorthands, program arguments, yields, conditionals, identity)
probes/d/: rest tuples with optional, leading and middle rest elements
probes/e/: checked stale conversions by type (functions, generators, maps, class unions, i64, tuples, arrays, promises)
probes/f/: literals in generic arrows, generic object-literal methods, generic classes, spreads
probes/tests/: the four round-2 tests on node/snap/base
perf/callgrind.txt: instruction counts on snapshot 5
matrix/results-snap5.jsonl: the reproducer's families A,B,C,F,G on snapshot 5
