package lower_test

import (
	"fmt"
	"testing"
)

func TestDbgTrial(t *testing.T) {
	_, errors := lowerSource(t, `class Box<T> {
  constructor(public value: T) {}
}
function use(f: <T>(x: T) => Box<T>): number {
  return f(1).value;
}
function run(): number {
  return use(<T>(x: T) => {
    if (Array.isArray(x)) {
      const n = x.length;
      console.log(n);
    }
    return new Box(x);
  });
}
console.log(run());
`)
	for _, e := range errors {
		fmt.Printf("%+v %s\n", e, e.Format("/"))
	}
}
