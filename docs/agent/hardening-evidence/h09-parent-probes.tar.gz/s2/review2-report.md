# H09a review, round 2 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: not ready.** Every round-1 finding is now fixed, mitigated by the fallback, or a documented trade-off. Closure sharing held up under every probe I wrote. But I found two new runtime regressions. Both are fully typed programs that compile on both trees: they match Node on the base and throw an uncaught TypeError on snap4. The driver fallback doesn't help, because nothing fails to compile. Both are small to fix, and both contradict D-190's "none worse".

What I reviewed: `/tmp/h09/snap4`. Its `git diff HEAD -- pts` has sha256 `d23a400d…`, the same as the main tree's code right now. Its CLI is `9063c807…`. I compared it with the base (`7fad8ae1…`) and Node v24 (.mts copies). "Verified" means I ran it. Probes are in `/tmp/h09/review2/h09-review2-probes.tar.gz` (`INDEX.txt` inside); paths below are relative to `/tmp/h09/review2/`.

## New regressions

### R1 (high, verified): `isUninferred` drops legitimate instances when one of several type arguments is `unknown` or `any`

- **Where:** `pts/lower/instances.go:225` skips the pairing if *any* inferred argument is any or unknown.
  - With one type parameter this is harmless: `Box<unknown>` is the same IR class as the erased copy's `Box<any>` (probes u01–u03 pass).
  - With two or more, the erased copy erases the concrete ones too. A demand like `<string, unknown>` then gets `Pair<any, any>`, and the call's conversion rejects it.
- **What it breaks:** declarations and module-scope consts used as values. Base made instances for these.
- **Fallback:** none. `DeclaredInstances` applies the same filter, and the program compiles anyway.
- **Repro:** `p/u05_result_error_unknown.pts`. It has no `any` anywhere: a `Result<T, E>` factory called as `f(41)` through `<T, E>(value: T) => Result<T, E>`, so tsc infers E as unknown. This is a common shape.
  - Base and Node: `42`.
  - snap4: `Uncaught TypeError: Expected Result<number, unknown>, got Result<any, any>`, exit 1.
- **Also:** `p/u04_partly_unknown.pts` covers `unknown` inferred, `unknown` explicit and `any` inferred, for a declaration and a module-scope const. All six lines match Node on the base and throw on snap4.
- **Suggested fix:** skip only when the any or unknown comes from failed inference, not from the call. For example, skip only if the demand's own resolved type arguments (`PtsTypeArgumentsOfSignature(d.signature)`) contain no any or unknown. That keeps F7's purpose (the `gens_value` instance for `g<string>`).

### R2 (high, verified): dynamic-result instances break calls the base served correctly

- **Where:** `pts/lower/instances.go:94`. Under `AllInstances`, a call whose result is a promise or generator of generic class instances is now a demand, and its table entry is keyed by the IR signature alone.
- **Why it breaks:** a call with T as any or unknown shares the signature `(number) => value` with a typed call. Because `isUninferred` makes no instance for it, the runtime lookup finds the typed call's instance. That instance makes `Box<number>`, which the `await` rejects as a `Box<any>`.
- **Minimal repro:** `p/d06_dynamic_collision_base_runs.pts`. It calls `f(5)` (T inferred unknown, T only in the result), and has `f<number>(6)` behind a branch that never runs.
  - Base and Node: `inferred 5`.
  - snap4: `Uncaught TypeError: Expected Box<any>, got Box<number>`, exit 1.
- **Other probes:**
  - `p/d02_dynamic_collision_any.pts`: `f<any>` and `f<unknown>`, for a declaration and a local arrow. Base runs them; snap4 crashes at the first `await`.
  - `p/d03_dynamic_collision_generator.pts`: generators. `g<any>(1)` runs `g<string>`'s instance, whose `n as any` is checked as a string: `TypeError: Expected string, got number`. Base and Node print `any 1`.
- **Effect on D-190:** its known gap C173 says only that "the second call's `await` rejects" a value. It doesn't say that calls which worked on the base now throw, so "with none worse" is false.
- **Suggested fix for H09a:** list a dynamic-result instance only if no other demand of the same erased value has its IR signature with different type arguments; otherwise leave all of them on the erased copy. The proper fix (C173) is to key entries by type arguments.

## Round-1 findings, re-checked on snap4

| | Status | Evidence |
|---|---|---|
| **F1** (class instance from a dropped trial) | Fixed by the fallback | `f01` matches base and Node; the trace CLI shows the fallback ran (`converting string to number`) |
| **F2a** (cascade in the trial's own code) | Fixed in lowering, no fallback | `f02c` matches Node |
| **F2b** (`staticContext`) | Fixed | `f02b` matches; `f02` now matches Node (base threw) |
| **F3** (relaxed cast in a dropped instance) | Fixed in lowering | `f03` |
| **F3b** (relaxed cast in a kept instance) | Fixed by the fallback | `f03b` matches |
| **F4** (intersection miscompile) | Mitigated, not fixed | `f06b` is avoided by `calledOnlyName`. Other shapes compile to C that clang rejects; the build falls back and runs clang twice. `spec2/ternary_len__array__local.pts` matches the base. Direct calls are still PTS9001 on both (`f06`, `f06c`). |
| **F5** (instance limit) | Fixed: the limit stands and falls back | `inv/i10`: base and snap4 both give the PTS1001 |
| **F5 / f04** (instance that doesn't lower) | Trade-off, in the D-190 draft | Base PTS1001 → snap4 TypeError at run time. **Also applies to dispatched generic methods** (`specializeMethod` now uses `tryInstance`, `instances.go:386`): `p/t01_dispatched_method_trial.pts`, base PTS1001, snap4 `3` then `TypeError Expected Box<number>, got Box<any>`, Node `3 3`. No test pins either case. |
| **F6** (code size, scope cost) | Partly fixed | See F6 residual below. |
| **F7** (signature collision) | Open: C173 known gap | R2 shows it reaches further than documented, and `isUninferred` caused R1. |
| **F8** (state a dropped trial leaves) | Covered by the fallback where it leads to an error | Silent leftovers only add dead code: class instances, cached helpers, dynamic-type descriptors (`prepareDynamicTarget` never reports). |
| **F9** (docs) | In progress | D-190 is being written in the main tree. It should cover R1, R2, the dispatched-method trade-off and the F6 residual. |
| **F10** (tests) | Largely addressed | `generic_arrow_contexts` (a1/a4/a7/a8), `generic_arrow_suspensions` (a2), `generic_instances_fall_back`, `generic_instances_keep_compiling`, and the driver and lowering tests. The latter two lowering tests and the two driver tests pass (`go test -run`). |

**F6 details:**
- The scope snapshot cost is gone. Round 1's `scope_b` now takes 190 MB and 2.2 s, against the base's 149 MB and 1.5 s (round 1: 656 MB, 3.9 s).
- Arrows called only by name are fixed: `blow_150x50` is 11,457 lines against the base's 8,806 (round 1: 85,957).
- **Arrows that escape still pair with every demand.** `gen/esc_150x50.pts` (`tools/gen_escape.py`: 150 arrows pushed into an `any[]` plus one passed to `use`, 50 types):
  - 92,388 lines of C against the base's 8,784;
  - build 25.7 s against 2.2 s;
  - binary 9.8 MB against 4.3 MB.
- `esc_60x40` is 32,418 lines against 5,374. D-190's "Code grows with the pairs that are real" isn't accurate.

## Other findings

**N1 (medium, verified, documented): the fallback is all or nothing.**
- `p/c10_cliff.pts`: an unrelated F1-pattern line (`Weird` reached through `any`) makes `main`'s fixed arrow throw its old TypeError again.
- `p/c10b_cliff_alone.pts`, the same arrow alone: `fixed by H09a 6`.
- The D-190 draft does mention this. A narrower fallback (exclude only the failing erased values) would keep the feature robust in larger programs.

**N2 (low-medium, verified): the suite can't see failures that only `AllInstances` hits.**
- `TestRun` and `TestRunMatchesNode` build through `driver.Build` with the fallback (`pts/tests/run_test.go:283`).
- `TestCompilerFailsCleanly` uses `AllInstances` alone but flags only internal errors, not PTS1001.
- My sweep with a tracing overlay (`fb/emitc.txt`, 973 programs): today only `run/generic_instances_fall_back.pts` needs the lowering-level fallback among programs that compile. Nothing pins that.
- Suggestion: assert that `EmitCWith(AllInstances)` lowers every run and corpus program that `EmitC` lowers, apart from an allowlist.

**N3 (low, verified): `pts emit-c` doesn't fall back for clang failures, so it can print C that `pts build` doesn't use.**
- On `fuzz/spec2/ternary_len__array__local.pts`, emit-c prints 372 lines of `AllInstances` C, which clang rejects. The build falls back and compiles the base's 354.
- The cost of the fallback otherwise is small: 0.48 s → 0.80 s for that build. On a 42k-line program with an ordinary error, the second lowering adds about 0.1–0.4 s.

**S1 (low, suspicion, not reproduced): a foreign unexplained failure without a report can be lost.**
- In `tryInstance` (`instances.go:267`), the "stands" case requires `l.reports > reports`.
- If foreign code only noted an unexplained failure, the rollback at line 272 restores `l.unexplained`, so that failure goes unreported.
- I found no path that lowers foreign expressions during a trial. Worth a one-line fix: stand on `t.foreign` alone.

## What checked out (verified)

**Sweeps:**
- Round 1's 212 generated programs (`fuzz/sweep.txt`): 199 unchanged, 13 differ from the base and all 13 now match Node; none worse.
- C size over 973 programs (`csize/sizes.txt`): +0.23% in total. `transducers` is 10.1% smaller (4,620 lines). The only exit-code change is the intended `generic_instances_keep_compiling`.
- Emitted C is deterministic across runs.

**Closure sharing.** These match Node (or a hand-computed result where Node can't run them):
- `c02` nested function declarations across three instances of an outer generic function;
- `c03` `this` and `super` in constructors, fields, methods and getters;
- `c04` a named function expression recursing, with a closure capturing its name;
- `c05` loop variables, cells, generators and async;
- `c06` `calledOnlyName` edges: `?.()`, `!`, `typeof`, closure, element, parentheses, `.call`, shadowing, shorthand;
- `c07` names in scope: a `let` after the arrow, catch, for-of, blocks, a hoisted function, a nested generic arrow;
- `c08` generic class contexts;
- `c09` 200k calls with GC pressure and `.par.map`; stable under `PTS_THREADS` 1/2/4/8 with `GC_FREE_SPACE_DIVISOR=400`;
- `c11`–`c15`, the modules probe in `m/`, and `d01` (dynamic results with `this`, generators).
- Round 1's a1–a11 and the reproducer's probes behave as before or better. The `anyp/a04` lies still throw, and `generic_values_any_boundaries` passes.

**C70.**
- `p/r01_c70_more_edges.pts` matches Node: optional elements in the middle and left out at the end, variadic, self-containing, nested, a union target, the empty tuple, and a generic rest parameter through a value.
- Frozen tuples thaw when copied, and writes through the copy aren't seen by the original (the existing D-157/D-071 behaviour).
- D-190 or the SPEC should list that a tuple held in `any` now silently copies where it used to throw.

**Tests.**
- Every new test with an `// expect:` block passes on snap4.
- The tests that aren't `no-diff` match Node; the two tests with no expectations of their own match Node through `tri.sh`.
- The `no-diff` reasons are justified.

## Before it is ready
1. Fix R1 and add `u05` as a run test.
2. Fix or contain R2 and add `d06`.
3. Pin the f04 and t01 trade-off with a test, and say in D-190 that it covers dispatched methods.
4. Correct D-190's "none worse" and "pairs that are real" claims, and add the escaping-arrow blowup to the known gaps.
5. Optional: N2's assertion, and S1's one-line guard.

Archive: `/tmp/h09/review2/h09-review2-probes.tar.gz` (`INDEX.txt` inside); `/tmp/h09/review2/DONE` is touched.