#!/bin/bash
# tri.sh file.pts...: run each with the base CLI, the main tree's CLI ($FIX, default the repo) and Node; print a status line and the outputs that differ.
node=$HOME/.local/node/bin/node
FIX=${FIX:-/home/bryan/projects/parallelscript}
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/s2/run.XXXX)
  cp "$f" "$d/$b.mts"
  bo=$(cd "$d" && PTS_HOME=/tmp/h09/base timeout 180 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  so=$(cd "$d" && PTS_HOME=$FIX timeout 180 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  bs=$([ "$bo" == "$no" ] && echo B=node || echo B!=node); ss=$([ "$so" == "$no" ] && echo F=node || echo F!=node); bss=$([ "$bo" == "$so" ] && echo B=F || echo B!=F)
  echo "== $b: $bs $ss $bss"
  if [ "${QUIET:-}" != 1 ] || [ "$bo" != "$so" ]; then
    if [ "$bo" == "$so" ]; then echo "-- base=fix"; echo "$bo"; else echo "-- base"; echo "$bo"; echo "-- fix"; echo "$so"; fi
    [ "$so" != "$no" ] && { echo "-- node"; echo "$no"; }
  fi
  rm -rf "$d"
done
