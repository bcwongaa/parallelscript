#!/bin/bash
# bs.sh file.pts: base CLI vs the fix CLI ($FIX, default the repo): SAME or DIFF with exit codes.
FIX=${FIX:-/home/bryan/projects/parallelscript}
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/s2/run.XXXX)
bo=$(cd "$d" && PTS_HOME=/tmp/h09/base timeout 180 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
so=$(cd "$d" && PTS_HOME=$FIX timeout 180 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
rm -rf "$d"
be=$(echo "$bo" | tail -1); se=$(echo "$so" | tail -1)
if [ "$bo" == "$so" ]; then echo "SAME $be $(basename $f)"; else echo "DIFF base$be fix$se $(basename $f)"; fi
