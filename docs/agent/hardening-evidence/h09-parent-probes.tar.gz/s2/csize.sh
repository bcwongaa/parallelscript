#!/bin/bash
# csize.sh file: emit C with the base and the fix ($FIX), print "lines_base lines_fix exit_base exit_fix file"; exit-code differences go to csize/exitdiff.txt.
FIX=${FIX:-/tmp/h09/snap4}
f=$1; d=$(mktemp -d /tmp/h09/s2/csize/x.XXXX)
cd "$d"
PTS_HOME=/tmp/h09/base timeout 120 /tmp/h09/base/pts-bin/pts emit-c "$f" -o b.c >b.err 2>&1; eb=$?
PTS_HOME=$FIX timeout 120 $FIX/pts-bin/pts emit-c "$f" -o s.c >s.err 2>&1; es=$?
lb=$( [ -f b.c ] && wc -l < b.c || echo 0); ls=$( [ -f s.c ] && wc -l < s.c || echo 0)
echo "$lb $ls $eb $es $f"
if [ "$eb" != "$es" ]; then { echo "--- $f"; cat b.err; echo "+++"; cat s.err; } >> /tmp/h09/s2/csize/exitdiff.txt; fi
cd /; rm -rf "$d"
