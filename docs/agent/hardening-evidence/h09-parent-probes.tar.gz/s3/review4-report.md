# H09a review, round 4 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: not ready.** Removing `uninferred` is correct: it fixes R1′ and costs nothing measurable. But the new `instanceKey` gives the same key to calls that need different instances. That breaks code that snap5 ran correctly, and on some lines code that the base ran. The fix is small; an overlay that fixes it changes no C in 1,091 programs. Everything else checks out.

I reviewed `/tmp/h09/snap6`, after checking it byte for byte: `git diff HEAD -- pts` has sha256 `18ed99d2…`, the same as the main tree, the untracked tests are identical, and the CLI is `01a68785…`. I compared it with snap5, the base and Node v24 on `.mts` copies. "Verified" means I ran it. Paths are under `/tmp/h09/review4/`. I edited no tree; the experiments are `go build -overlay` only.

## F1 (high, verified): the key ignores type arguments that come from outside the call's own signature

`instanceKey` builds its identity from `resolved.Declaration()` plus the call's own type arguments. Two kinds of type argument never reach it:
- a type alias's arguments (`Loader<number>` and `Loader<string>` share one function-type node);
- an enclosing generic function's or class's instance arguments.

So calls through `<T>(k: T) => Promise<Pair<T, U>>` with the same T get one key, whatever U is. The first call to be lowered creates the table entry (`specializeValue` returns early when the entry exists), and the second call reuses that instance. The trigger is a value that is generic in a type parameter appearing only in its result, for example `async <K, V>(k: K) => new Pair<K, V>(k, [])`.

| Probe | Base | snap5 | snap6 | Node |
|---|---|---|---|---|
| `p/k04` (enclosing function) | both lines TypeError | `2 0` / `2 0` | line 2: `rejected Expected Pair<number, string>, got Pair<number, number>` | `2 0` / `2 0` |
| `p/k05` (type alias) | TypeError | `1` / `1` | `Uncaught TypeError … got Pair<number, number>` | `1` / `1` |
| `p/k06` (enclosing class) | TypeError | = Node | line 2 rejected | |
| `p/k07` (alias, `f<any>`) | **`any: 1 0`** | = Node | **`any: rejected Expected Pair<any, any>, got Pair<any, number>`** | `any: 1 0` |
| `p/k08` (enclosing, `f<any>`) | **`any: 1 0`** | = Node | **`any: rejected …`** | `any: 1 0` |

- k04–k06 are regressions against snap5. The base also failed them, with C09's TypeError.
- k07 and k08 are regressions against the base on their `any` lines. That is the same symptom as round 2's R2.
- Every failure is a checked TypeError, not a memory error.
- The claim "the same IR types … name the same instance (as `genericInstance`'s do)" is therefore false. `genericInstance` dedupes by the *value's* inferred type arguments, and those depend on the call's whole instantiated signature.

**Fix, verified by overlay** (`ov/instances_keyfix2.go`): build the identity from the call's type arguments *and* the instantiated result type, through a canonical walk. The walk:
- recurses into library references and generic-class references by their target and type arguments, so it makes no class instance;
- recurses into unions by their members;
- uses the literal's own type for literals;
- uses `irType`, with the take-back, for everything else.

Results with that overlay:
- k01–k08 and both changed run tests match Node.
- `keys_literal_200` stays at 3,323 lines and `keys_esc_50x200` at 7,839.
- The C is byte-identical to snap6 on all 1,091 programs (`out/keyfix2-ccmp.txt`).
- `go test ./pts/lower` passes.
- With the result in the key, the declaration could perhaps be dropped. That would merge entries such as `later(2)` and `pass`'s `f(1)`, which are now separate (see Other).

Please add a k05/k07-style block to `run/generic_dynamic_results_by_type.pts`; the suite misses F1 today.

## F2 (medium, verified; in the slice since snap4, not introduced by this delta): `genericInstance` merges type arguments that share an IR type

T = `Promise<number>` and T = `any` both lower to `value`, so they get one instance, lowered for whichever came first. For a typed result, `fits` catches the mismatch; for a dynamic result nothing does.

- **`p/g01`** (`Promise<Box<Awaited<T>>>`):
  - Base prints `any: 2`.
  - snap4, snap5 and snap6 print `any: rejected Expected Box<any>, got Box<number>`.
  - This is a regression against the base on that line, and it contradicts D-190's "an instance for `any` makes what the erased copy makes".
- **`p/g02`**: `string: rejected Expected number, got string`. The base fails here too.
- **`p/g03`**: the same merge on direct calls gives PTS1001 on the base, so the limit itself predates H09.

An overlay that treats `value`-typed arguments by their checker type, both in the key and in `genericInstance` (`ov/*_keyfix3.go`), fixes g01 and g02. It changes C in 4 of 1,091 programs (`lazy_thunk_streams`, `fetch_abort`, `generic_dynamic_results_by_type`, `recursive_unions_generic_consts`), and their outputs stay the same. Because it also affects typed calls and the 64-instance limit, either adopt it limited to keyed demands, or record it as a gap with g01 as a skipped test.

## F3 (low, verified): `instanceKey`'s `irType` makes class instances that stay

Calling `irType` on a type argument that is a generic class creates that class instance, and it isn't taken back. In `p2/s03`, a call `f<Holder<string>>()` that is never awaited creates `Holder<string>`, which doesn't lower. The build falls back and an unrelated C09 line throws. snap5 printed what Node prints. The probe is contrived, and experiment 2's walk avoids it.

## F4 (low, verified): a taken-back failure leaves a cached nil

When `irType` fails inside `instanceKey`, `interfaceOf` caches `nil` and the report is taken back. A later use of the same type then fails without a report. In `p2/s08` the first lowering says "identifier (which the compiler failed to lower without saying why)", and the fallback then prints the base's error. Only `EmitCWith` would show the vague message.

## Verified as claimed

- **R1′ is fixed.** Each new block of `generic_instances_unknown_type_arguments.pts`, run alone, fails on snap5 and passes on snap6; the base matches Node. u06, u07 and u09 match Node; the other u, d and k probes behave as on snap5.
- **Removing `uninferred` changes nothing else:**
  - 1,091 programs: fallback use and exit codes are identical to snap5. C differs only in the two edited tests and in `generic_arrow_suspensions` (+26 lines) and `generic_factory_promises_generators` (+64 lines); those extra entries come from per-declaration keys, and both tests match Node.
  - The 212-program sweep: snap5 and snap6 give the same output for every program (162 match Node on all trees, 37 unchanged, 13 improved, 0 worse).
  - Both reproducer matrices (754 + 432): C byte-identical to snap5.
  - The generator programs from rounds 1–3: C identical apart from the keys ones.
  - Every earlier probe (rounds 1–3 and the reproducer's): snap5 = snap6, except u06, u07, u09 and k01, which now match Node.
- **Key growth figures are confirmed:** 3,323, 7,839 and 7,816 lines.
- **The C is deterministic:** three runs of 7 programs gave identical output.
- **The `%p` identities are sound:** every `ir.Type` is a pointer, and `genericInstance` compares the same pointers.
- **The lowering tests pass,** including the new key test.

## Docs

- Inaccurate given F1 and F2:
  - D-190's "Dynamic results" ("whatever object literals or aliases spell them", "as `genericInstance` tells instances apart");
  - D-190's "Which pairs" ("an instance for `any` makes what the erased copy makes");
  - the `instanceKey` doc comment;
  - h09.md's Keys line;
  - C173's "Each call finds the instance of its own type arguments".
- Wrong cause: D-190, h09.md and C173 say the phantom `f<number, string>`/`f<number, boolean>` calls failed on snap5 because they shared an entry. Round 3's no-filter overlay passed k01 with snap5's keys, so the cause was `uninferred`.
- Stale test comment: the header of `generic_dynamic_results_by_type.pts` still says "told apart by the result's type". It also says all calls have the signature `(number) => value`, which the literals block's calls don't.
- Correct: the rest of the delta (SPEC §9.129, the ir and demand comments, C176's clang note, h09.md's round-3 section, and the round-3 report saved into `h09-review.md`, which matches the recovered copy).

## Other (cost only, verified)

The same instance reached through two function-type declarations gets two entries: `later(2)` called directly, and `pass`'s `f(1)`.

## Before it is ready

1. Fix F1 (experiment 2 is one validated way) and add a k05/k07-style test block.
2. Fix F2 for keyed demands, or record it with g01 as a skipped test.
3. Correct the docs listed above.

Archive: `/tmp/h09/review4/h09-review4-probes.tar.gz` (sha256 `a10b7847…`, `INDEX.txt` inside; overlay binaries not included). `/tmp/h09/review4/DONE` is touched.