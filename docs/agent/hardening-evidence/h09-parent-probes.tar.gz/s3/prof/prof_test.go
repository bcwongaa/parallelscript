package driver_test

import (
	"context"
	"os"
	"runtime/pprof"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func TestProfileWideTypes(t *testing.T) {
	f, _ := os.Create("/tmp/h09/s3/prof/cpu.out")
	pprof.StartCPUProfile(f)
	_, err := driver.EmitCWith(context.Background(), "/tmp/h09/s3/gen/wide_types_keys.pts", lower.AllInstances)
	pprof.StopCPUProfile()
	f.Close()
	m, _ := os.Create("/tmp/h09/s3/prof/mem.out")
	pprof.WriteHeapProfile(m)
	m.Close()
	if err != nil {
		t.Fatal(err)
	}
}
