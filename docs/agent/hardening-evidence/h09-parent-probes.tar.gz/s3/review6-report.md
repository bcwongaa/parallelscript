# H09a review, round 6 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: not ready to commit as it stands.** Every round-5 response checks out, and nothing regressed in the sweeps or the matrices. But snap8's structural walk is coarser than the IR in two ways, and its cut-offs split calls that should share an instance:
- **R6-1:** two lines that snap6 and snap7 ran correctly now throw, and one of them the base ran too.
- **R6-2:** two programs that snap6 and snap7 ran correctly now throw from the fifth call on.

A three-edit overlay (`fix6b`) fixes all five probes and changes nothing else. With it, plus test blocks for these probes, the slice is ready.

What I reviewed: `/tmp/h09/snap8`. Its `git diff HEAD -- pts` has sha256 `674dcaf7…`, the same as the main tree, and the CLI is `3c039ef6…`. I compared it with snap7, snap6, the base and Node v24 on `.mts` copies. "Verified" means I ran it. Paths are under `/tmp/h09/review6/`. I edited no tree; experiments are overlays only.

## R6-1 (medium-high, verified): `objectKeyParts` writes types of different IR types the same way

The identities below come from a debug overlay that prints each key (`out/key-identities.txt`).

- **`p/r01`: a method against a function-valued property.** `{ m(): number }` and `{ m: () => number }` both come out as `{m,{,0(),<number>}}`. Their IR types differ: the IR dump shows an interface method in one and a field of function type in the other. When both calls go through one function-type declaration, they share an entry.
  - snap8 prints `function rejected Expected {m(): number}, got Object`.
  - snap6, snap7 and Node print `function 2`.
- **`p/r03` and `p/r03b`: the prelude's `Timeout` against a structural twin.** `isLibInterface` is false for the prelude (`ptslib:///prelude.d.ts`), so `Timeout`, whose IR type is a dynamic value, is walked by its members exactly like a user `interface MyTimer` with the same members, whose IR type is a shape. The two calls get one key.
  - In r03, the MyTimer line throws.
  - In r03b, MyTimer's call is lowered first, and the Timeout line throws: `timeout rejected Expected {hasRef(): boolean; …}, got Timeout`. **The base runs that line** (it prints `timeout boolean`).

## R6-2 (medium, verified): the walk splits call sites that should share an instance, and past four variants the cap leaves later calls on the erased copy

- **`p/r05`: generic signature type parameters.** Six sites call `wrap(<X>(x: X) => x)`. Each site's `X` is a fresh type parameter written by its checker id, so `madeFor` treats every site as a new variant. Calls 5 and 6 keep the erased copy and throw `Expected Box<<X>(x: X) => X>, got Box<any>`.
- **`p/r08`: the depth and budget cut-offs.** Six sites pass an 8-level nested object literal. Past `maxKeyDepth`, each site's fresh literal types are written by checker id (`t<id>`). That is not "only a cost": through `madeFor` and the cap, calls 5 and 6 throw.

snap6, snap7 and Node print all six values in both programs; the base throws on all six.

## The fix, verified by overlay (`ov/fix6b/instances.go`)

The overlay makes three edits to `instances.go`:
1. For an object type that `objectKeyParts` walks, write `irTypeKeyPart` first. This makes the key never coarser than the IR.
2. Write a signature's own type parameters by position (`$depth.index`).
3. At `maxKeyDepth` or `maxKeyParts`, write `irTypeKeyPart` instead of the checker id.

Results:
- r01, r03, r03b, r05 and r08 match Node.
- The C is byte-identical to snap8 on all 1,093 programs, 1,186 matrix cases, 19 generator programs and every earlier probe; my five probes are the only ones whose C changes.
- emit-c time rises about 1%: 209.2 s to 210.9 s over the 1,093 programs.
- `go test ./pts/lower` passes.

Writing the constraints of signature type parameters would close the remaining gap there, though I know of no case that needs it.

## Your focus questions

Verified by running:
- **Getters and setters:** a getter's IR type is the same as a field's (the IR dump shows both as `{p: number}`), so merging them is fine.
- **Methods:** this is R6-1.
- **Generic signatures:** this is R6-2 (`r05`).
- **Namespaces:** PTS1002 everywhere. Module namespace values are PTS1001 everywhere. Neither is a hole.

By reading the code, not run:
- **Readonly properties:** IR types are the same, so merging is fine. Readonly arrays and tuples have their own targets, so they get finer keys: a cost only.
- **Tuples:** they are references, and their target carries the readonly flag; fine.
- **Enums:** their members are literal types written by id, so two enums never merge.
- **`typeof C`:** its `prototype` property is a reference to the class, so two classes never merge.
- **`this` inside interfaces:** an interface that mentions `this` is a reference, keyed by its target.

`isNominal`:
- The pts:* modules are compiled as program sources. Their classes are in `l.classes`, and their interfaces are walked structurally, which is right because PTS lowers them structurally.
- The prelude is the problem case (R6-1).
- Lib interfaces with structural IR types are keyed by their IR pointer. A user twin gets another key (a cost only). I know of no two lib interfaces that share an IR shape but differ in their dynamic members.

## Regression sweep and cost (verified)

- **Fallback compare:** over 1,093 programs, fallback use and exit codes are identical to snap7. C differs only in `generic_dynamic_results_by_type` (+156 lines) and the new test. Total emit-c time is 167.8 s against 168.7 s.
- **The 212-program sweep:** identical to snap7 on every program (162 match Node on all trees, 37 unchanged, 13 improved, 0 worse).
- **Matrices and generator programs:** C identical to snap7.
- **123 earlier probes:** snap8 = snap7 apart from five improvements (q03, q04, q10, p02, p03). q08 is still the stated cap trade-off.
- **New test:** each of the six blocks in `s3/red5/` fails alone on snap7 and passes on snap8.
- **Determinism:** the C is deterministic over three runs of five programs.
- **`wide_types_keys`:** snap8 is no slower than snap7, about 8.4 s against 8.3 s on a loaded host. But the base takes 2.1–3.1 s, so H09a makes this program roughly 3–4 times slower to compile. That was already so on snap5, before `keyPart` existed, so it comes from the pairing, not the walk. h09.md's "3.2 s, same as snap7" doesn't mention the base.

## Docs

- D-190 and `keyPart`'s comment say it writes the same thing "for types of the same IR types … but for dynamic values". The converse fails too: different IR types are written the same (R6-1).
- "Checker ids from there" at the cut-offs leads to R6-2.
- The rest of the delta is accurate: SPEC §9.129, C172's q08 example, C173, C177's caveat, the outer-type-arguments test's header and h09.md's round-5 section.

## Before it is ready

1. Apply fix6b's three edits (or something equivalent).
2. Add r01, r03b, r05 and r08 as test blocks.
3. Correct the `keyPart` sentence in D-190 and the code comment.

Archive: `/tmp/h09/review6/h09-review6-probes.tar.gz` (sha256 `9998c4e8…`, `INDEX.txt` inside; overlay binaries not included). `/tmp/h09/review6/DONE` is touched.