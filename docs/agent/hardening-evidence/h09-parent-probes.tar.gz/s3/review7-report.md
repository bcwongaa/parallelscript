# H09a review, round 7 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: ready.** Everything the parent asked me to verify checks out, and I found nothing new of any severity.

What I reviewed: `/tmp/h09/snap9`. Its `git diff HEAD -- pts` has sha256 `f333e191…`, the same as the main tree, and the CLI is `f192de25…`. I compared it with snap8, round 6's overlay `fix6b`, snap6, snap5, the base and Node v24. "Verified" means I ran it. Paths are under `/tmp/h09/review7/`. I edited no tree.

## The code is my fix6b in effect (verified)

- Diffing `pts/lower/instances.go` against my overlay shows two real differences besides comments, and neither changes what is written:
  - **Moved `irTypeKeyPart` call:** it is now the first line of `objectKeyParts` rather than just before its call in `keyPart`. `objectKeyParts` has only that one caller, and the identity string comes out the same.
  - **Order of the two early checks:** the binders check now runs after the path check instead of before it. A binder returns before anything is pushed onto the path, so the path check can never match one.
- **C:** snap9's C is byte-identical to fix6b's on all 1,094 programs, the new test included (1,056 identical C files; 38 programs fail with the same errors on both).

## No regression or new fallback use (verified)

- **Fallback compare:** over 1,094 programs, fallback use and exit codes are identical to snap8. C is identical except for the new test. Total emit-c time is 208.5 s against 212.3 s on a busy host, which is within noise.
- **Matrices (1,186) and 20 generator programs:** C identical to snap8.
- **The 212-program sweep:** the 198 programs that compile have identical C to snap8, and the other 14 fail with the same exit codes. Round 6's classification therefore still holds: 162 match Node on all trees, 37 unchanged, 13 improved, 0 worse.
- **139 earlier probes:** C is identical to snap8 except for round 6's five probes and the four `s3/red6` blocks. All nine match Node on snap9 and fail on snap8; snap6 matches Node on all of them. r03b's Timeout line, which the base runs, matches Node.
- **New test:** `generic_dynamic_results_ir_identity.pts` matches Node, and each of its blocks fails alone on snap8 and passes on snap9.
- **Other checks:** `go test ./pts/lower` passes, and the C is deterministic over three runs.

## C178 (verified)

My numbers were measured with the host's load around 6–7, so my times run higher than the parent's. Memory and the ratios agree with the C178 row.

| Program | Base | snap9 | Notes |
|---|---|---|---|
| `wide_types_direct` | 11.9 s, 2.5 GB | 9.9 s, 2.5 GB | The base pays the same cost |
| `wide_types_keys` | 2.7–2.8 s, 0.18–0.19 GB | 5.6–6.2 s, 0.81–1.0 GB | snap5, which has no `keyPart`, is already 5.5 s and 0.8 GB |

- **It grows exponentially with interface depth.** On the base, the direct form takes 0.48 s and 67 MB at 4 levels, 1.7 s and 310 MB at 5, and about 10 s and 2.5 GB at 6.
- **The profile supports the parent's attribution.** In `/tmp/h09/s3/prof/cpu.out`:
  - `ir.(*Interface).String` takes 33.5% cumulative, almost all of it inside `fieldList` and `Union.String`.
  - Its callers are cgen's `checkDefinitions` (35.6% cumulative) and lower's `typeArgumentsName` (16.4%).
  - `keyPart` takes only 2.3%.
- So the cost is the IR printer's, and H09a now reaches it through values. Recording it under H23 is the right home.

## Docs (verified)

The following match the code and my runs:
- D-190's `keyPart` sentence: "never the same for other IR types", and past six levels or 256 types a type is written by its IR type alone;
- the C178 gap and the H23 note;
- SPEC §9.129's test list;
- C173's round-6 entry and the new C178 row;
- PROGRESS's known issues;
- h09.md's round-6 section.

## Low-severity notes (no change needed)

- **Stated trade-off:** a dynamic value deeper than six levels or 256 types isn't told apart. D-190 and the code comment both say so.
- **Timing:** h09.md's absolute times for C178 depend on host load. The ratios and the memory figures are the robust part.

Archive: `/tmp/h09/review7/h09-review7-probes.tar.gz` (sha256 `34e7ad9b…`, `INDEX.txt` inside). `/tmp/h09/review7/DONE` is touched.