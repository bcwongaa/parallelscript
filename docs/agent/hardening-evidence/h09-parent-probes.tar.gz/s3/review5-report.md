# H09a review, round 5 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: not ready to commit as it stands, but close.** Every round-4 response checks out: k04–k08, g01, g02, s03 and p01 match Node, and so do each of the parent's red4 blocks. Nothing regressed in the sweeps or the matrices. Three narrower cases of the same two failure modes remain:
- **R5-1 and R5-2** each make one line throw that the base ran.
- **R5-3** is a trade-off of the cap: worse than snap6, no worse than the base.

One small overlay fixes R5-1 and R5-2 at almost no cost (details below). Either apply that approach, or record both as known gaps with RED tests; after either, the slice is ready.

What I reviewed: `/tmp/h09/snap7`. Its `git diff HEAD -- pts` has sha256 `c61e9a2e…`, the same as the main tree, and the CLI is `aefd0ec9…`. I compared it with snap6, the base and Node v24 on `.mts` copies. "Verified" means I ran it. Paths are under `/tmp/h09/review5/`. I edited no tree; experiments are overlays only.

## R5-1 (medium, verified): the key still merges calls through an intersection-typed parameter

`p/q04` is the parent's p01 with `Tagged<U> = Promise<U> & { label?: string }` as the parameter type. `keyPart` doesn't walk intersections, so it falls through to `irType`, which gives `value` whatever U is.
- The IR dump (`out/q04*.ir`) shows both calls with key `Promise<Box<any>>#1`, and only one instance, `feed_number_value`.
- Base and Node print both lines; snap6 and snap7 print `string rejected Expected number, got string`.
- So "anything else by its IR type, the same object for the same types" (D-190, the `keyPart` comment) doesn't hold when the IR type is `value`.

The same merge happens for an object-type parameter `{ p: Promise<U> }` (`p/q02`, one key in `out/q02*.ir`). It can't show at run time today, because the value goes through an adapter (C169). Function-type parameters (`q01`) are hidden the same way.

## R5-2 (medium, verified): `madeFor` only compares the top level of each type argument

`madeFor` compares checker types only where the IR type argument is `ir.Value` itself. A dynamic value inside an array or an object type isn't compared.
- **`p/q10`**: `first<T extends unknown[]>(xs: T): Promise<Box<Awaited<T[number]>>>`, called with T = `Promise<number>[]` and with `any[]`. Both are an array of `value`, so `f<any[]>` gets the `Promise<number>[]` instance. The base prints `any: 2`; snap7 prints `any: rejected Expected Box<any>, got Box<number>`.
- **`p/q03`** shows the same with T = `{ p: Promise<number> }` against `{ p: any }`.
- These are g01's failure, one level deeper. C177's wording ("dynamic results tell them apart since H09a") needs the same caveat.

## Experiment for R5-1 and R5-2 (verified, `ov/fix5`)

The overlay makes four changes:
- `keyPart` walks intersections by their members.
- `keyPart` walks type-literal and object-literal types by their members and call signatures.
- `keyPart` writes a leaf whose IR type is `value` by its checker type.
- `madeFor` compares the `keyPart` identities of every one of the instance's own type arguments.

Results:
- q03, q04 and q10 match Node, as do k01–k08, g01, g02, s03, p01, `many_value_keys_70` and both dynamic-results tests.
- The C is identical to snap7 on 1,091 of the 1,092 programs and on all 1,186 matrix cases. The one exception is `generic_dynamic_results_by_type` (+156 lines), which still matches its expected output.
- `keys_literal_200` stays at 3,323 lines and `many_value_keys_70` at 3,415.
- `go test ./pts/lower` passes.

## R5-3 (low, verified): past the cap, a call that sharing served correctly now throws

In `p/q08`, six calls pass `Promise<1>` through `Promise<6>` to `<T>(x: T) => Promise<Box<Awaited<T>>>`.
- snap6 printed what Node prints, because one shared instance making `Box<number>` fit every call.
- snap7 is right for calls 1–4. Calls 5 and 6 keep the erased copy and throw `Expected Box<1>, got Box<any>`.
- The base throws on all six.

D-190 states "past them the call keeps the erased copy, as the base's did", so this is a stated trade-off. Please add q08 as its example in C172. The cap's `nil` leaves the trial clean: nothing has been made yet, `tryInstance` rolls back nothing, and dynamic instances are only ever requested from `tryInstance` itself.

## Your focus questions (verified)

- **`this` types:** `this` parameters are PTS1001 everywhere (`q09`), so there is no hole there. A `this` type inside the key goes through `irType` to its class.
- **Optional parameters (`q06`):** fixed; the union with undefined is walked.
- **Dispatched generic methods (`q07`, Awaited with `any`):** fixed on snap7; snap6 failed it.
- **Instances of enclosing classes (k06 and the test's block):** fixed.
- **Overloads:** a function type with more than one call signature is never a demand, so overloads don't reach the key.

## Regression sweep (verified)

- **Fallback compare:** over 1,092 programs, fallback use and exit codes are identical to snap6. C differs only in the two dynamic-results tests.
- **The 212-program sweep:** identical to snap6 on every program (162 match Node on all trees, 37 unchanged, 13 improved, 0 worse).
- **Both matrices (1,186 cases):** C identical to snap6.
- **Generator programs:** C identical apart from `many_value_keys_70` (1,699 lines on snap6, 3,415 on snap7).
- **Every earlier probe** (rounds 1–3 and the reproducer's): snap6 = snap7. Round-4 probes are all fixed.
- **Determinism:** the C is deterministic over three runs of six programs.

## Docs

The delta is accurate apart from these three points:
- D-190, the `keyPart` comment and C173 claim that parameters "whose IR type is a dynamic value" are covered; R5-1 shows they aren't when the type is an intersection.
- D-190, C173 and C177, and the new test's header ("never gets an instance made for another such type argument"), hold only at the top level of each type argument (R5-2).
- C172 should give q08 as the example of what happens past four variants.

Archive: `/tmp/h09/review5/h09-review5-probes.tar.gz` (sha256 `5fbc2197…`, `INDEX.txt` inside; overlay binaries not included). `/tmp/h09/review5/DONE` is touched.