The coordinator sent a message while you were working:
H09a review ROUND 3: please re-review the delta on snapshot /tmp/h09/snap5 (same rules as before: read-only, scratch under /tmp/h09/review3/, at most 2 heavy jobs since the parent's full suite runs on snap5 now, final message = your report, archive /tmp/h09/review3/h09-review3-probes.tar.gz with INDEX.txt, then touch /tmp/h09/review3/DONE). snap5 = HEAD 14ad0e6b7 + the change; `git diff HEAD -- pts` sha256 1d4c9adf2616e84a… (same as the main tree), CLI sha256 d33d4b4c…; PTS_HOME=/tmp/h09/snap5. Your tools take FIX=/tmp/h09/snap5.

Parent's responses to your round 2 (verify each):
- R1: `isUninferred` replaced by `uninferred(arguments, d)` (pts/lower/instances.go): skip only when an inferred type argument (instantiated) is any/unknown AND none of the call's own resolved type arguments (`PtsTypeArgumentsOfSignature(d.signature)`, instantiated) is. Your u04/u05 now print what the base and Node print. New run test `run/generic_instances_unknown_type_arguments.pts` (u04+u05 shapes, plus a local arrow).
- R2 and C173: dynamic-result entries are now keyed by the call's result type. `demand.key` = `TypeToString(instantiate(return type)) + "#" + checker id` when the IR result is `value`; `ir.Instance.Key` and `ir.InstanceCall.Key` carry it; specializeValue/specializeMethod dedupe by (signature, key); cgen `keyedFuncType`/`instanceSignatureCheck` give each key its own pts_check (a `keyedFuncTypes` set that `check` doesn't canonicalize), so the runtime's address comparison separates them. d02, d04, d05, d06, round 1's f05 and the parent's p4/collide now match Node; d03 (a lie: `n as any` read as string) throws a TypeError as the base does, with a more precise message. New run test `run/generic_dynamic_results_by_type.pts`. C173 is now recorded as fixed in H09a.
- t01/f04 trade-off: pinned by new lines in the no-diff `run/generic_instances_that_dont_lower.pts` (declaration through a value; dispatched method); D-190 states it for dispatched methods too.
- N2: `TestCompilerFailsCleanly` now also fails for a seed (not a mutant) that compiles only with the fallback (`fallbackFailure`: AllInstances fails with compile errors, DeclaredInstances compiles), except `needsFallback` (= run/generic_instances_fall_back.pts), and for an allowlisted seed that no longer needs it. The parent checked both directions with an overlay that changed the allowlist (both failures reported); the real run passes.
- S1: tryInstance's "stands" case is now `t.foreign` alone.
- F6 residual (escaping arrows), N1 (whole-program fallback, c10_cliff) and N3 (emit-c doesn't fall back for clang) are recorded as known gaps: C172 extended with esc_150x50's numbers, new C176 for N1/N3 (H09b). D-190's "pairs that are real" claim is replaced by the esc numbers; its Reason now says "none worse case by case" with the f04/t01 exception stated.
- Docs to check: D-190 (docs/DECISIONS.md, last entry), SPEC §3.7 bullet and §9.129, ARCHITECTURE driver line, HARDENING_PLAN H09/H09a/H09b, CONSOLIDATED C09/C70/C164/C169–C176, PROGRESS known issues, docs/agent/hardening-evidence/h09.md (draft, still has TBD placeholders for the final runs).

Please focus on: correctness of the key (could two calls that need different instances get the same key, e.g. results that print alike, types in instances of an enclosing generic function, `this` types, unions, aliases; or could keys multiply table entries badly — table growth per call site), whether `uninferred` can still drop an instance a call needs or make one it shouldn't, any new regression versus the base (re-run your sweep, u/d/t/c probes and the round-1 probes), the fallback check in the smoke test, and the docs' accuracy. Say plainly whether the slice is ready.

Address this before completing your current task.
=====REPORT3=====
# H09a review, round 3 (opus-reviewer, claude-opus-5-5, xhigh)

**Verdict: not ready, but close.** Keying the dynamic results is correct and fixes R2 and C173. The S1 change, the smoke test's fallback check and nearly all of the docs check out. **R1 is only partly fixed:** `uninferred` still drops instances that the base made and the call needs. I found three fully typed shapes that match Node on the base and throw on snap5. An overlay experiment shows that dropping the filter entirely fixes all three and costs nothing measurable, so the remaining fix is a deletion plus three test lines.

What I reviewed: `/tmp/h09/snap5`. Its `git diff HEAD -- pts` has sha256 `1d4c9adf…`, the same as the main tree; the CLI is `d33d4b4c…`. I compared it with the base and with Node v24 on .mts copies. Paths below are relative to `/tmp/h09/review3/`. "Verified" means I ran it.

## Open: R1′ (high, verified) — `uninferred` still skips needed instances

`uninferred` (`pts/lower/instances.go`) skips a pairing when the value's inferred type arguments include any or unknown and the call's own type arguments don't. But an `unknown` can be correct without appearing among the call's type arguments. All three cases below are typed results (no key), and the `DeclaredInstances` fallback applies the same filter, so it can't rescue them:

| Probe | What makes the unknown correct | Base and Node | snap5 |
|---|---|---|---|
| `p/u06_unknown_in_demand_type.pts` | The parameter's function type fixes it: `wrap(f: <T>(value: T) => Result<T, unknown>)` with `wrap(ok)`, where `ok<T, E>` | `42 42 2` | `Uncaught TypeError: Expected Result<number, unknown>, got Result<any, any>`, exit 1 |
| `p/u07_unknown_from_enclosing_instance.pts` | It comes from an enclosing instance: `outer<unknown>(pair)`, with `f: <T>(k: T) => Pair<T, U>` | `6 6` | `TypeError: Expected Pair<number, unknown>, got Pair<any, any>` |
| `p/u09_phantom_explicit_only.pts` | A type parameter the signature doesn't mention, called only with explicit arguments: `f<number, string>(1)`, `f<number, boolean>(2)` | `3 3` | `TypeError: Expected Box<number>, got Box<any>` |

**Experiment (verified; overlays only, the tree was not touched; `ov/instances_none.go`, `ov/instances_keyed.go`):**
- **With `uninferred` always false:**
  - These probes match Node: u04–u09, d02, d04–d06, k01–k03, round 1's f05, and the run tests `generic_dynamic_results_by_type`, `generic_instances_unknown_type_arguments`, `generic_factory_promises_generators` and `generic_arrow_suspensions`.
  - The one exception is d03, a deliberate lie (`n as any` read as a string). It throws a TypeError as the base does.
  - Every other `run/generic*.pts` test also matches Node, or snap5 where Node isn't compared (`out-none-generic-tests.txt`).
  - Over 1,091 programs (round 1's fuzz plus run, corpus and stress; `fb-compare.txt`), fallback use and exit codes are identical to snap5. The C is identical in size everywhere except `generic_dynamic_results_by_type` (+46 lines).
- **Why the filter is no longer needed:** it existed for F7's collision. With keys, an instance inferred as any is listed only under the key of the demand that made it, and it makes the same values the erased copy would.
- **Restricting the filter to keyed (dynamic) demands** also fixes u06, u07 and u09. It still misses k01's phantom-parameter line (`f<number, string>` on a `Promise<Box<T>>` result), which the base also failed on.

**Recommendation:** remove `uninferred`, and add the u06, u07 and u09 shapes to `run/generic_instances_unknown_type_arguments.pts`.

## Re-checking the round-2 responses

**R1 (u04, u05): fixed for those shapes (verified).** Base, snap5 and Node all print the same. The new test passes and matches Node; it fails on the base because of its local-arrow line.

**R2 and C173: fixed (verified).**
- d02, d04, d05, d06 and f05 match Node. d03 throws as the base does.
- Key probes `p/k01`–`k03` match Node, apart from k01's phantom line (see R1′, above):
  - an alias signature against a direct one;
  - `Promise<Box<T> | undefined>`;
  - instances of an enclosing generic function and class;
  - `Generator<Box<T>, void, unknown>`, `Promise<Map<string, Box<T>>>` and `Promise<[Box<T>, number]>`.
- `run/generic_dynamic_results_by_type.pts` passes and matches Node; the base exits 1.

**Is the key correct?** Yes. Each call's own demand creates its own entry, so a call always finds the instance made for it, or none and the erased copy.
- A shared key means the same checker type object (same id), so the same result type.
- Types that print alike but differ (aliases, unions, other modules) get other ids. That only adds entries; it never mixes instances up.
- Check names come from a counter, and `keyedFuncTypes` keeps each key's check a separate object.
- The emitted C is deterministic over three runs of k01, `keys_literal_200`, the dynamic-results test and the modules probe.
- One residual, which typed results already have on the base: type parameters that the result type doesn't show share an entry.

**Do keys multiply table entries? Yes: medium, verified, performance only (`gen/measure-keys.txt`).**
- The key uses checker identity, so each call site that passes a fresh object literal gets its own key.
- `keys_literal_200` (200 sites):
  - 200 table entries, each with a trampoline, and 205 checks;
  - 8,099 lines of C against 3,264 on the base; build 5.5 s against 2.8 s;
  - the same program with numbers has 1 entry.
- Combined with C172's escaping values, `keys_esc_50x200` (50 escaping async arrows, 200 sites) gives 10,200 entries: 32,515 lines, a 24.8 s build and a 10.4 MB binary. The same program with numbers is 7,816 lines and 2.8 s.
- Each call also scans its value's table linearly.
- The output matches Node, where the base threw. Suggestion: key by the IR type of the result's type arguments, which is canonical for structurally equal object types. Otherwise record this in C172.

**t01/f04 trade-off: pinned and stated (verified).**
- `generic_instances_that_dont_lower.pts` passes its expectations. Its `no-diff` reason is justified, and the base gives PTS1001 at lines 58 and 69.
- D-190 states the trade-off for dispatched methods.

**N2, the smoke test's fallback check: works both ways (verified).**
- With `PTS_SMOKE_MUTANTS=0` and `PTS_SMOKE_FILTER=generic` it passes.
- With an overlay that moves `needsFallback` to `generic_instances_keep_compiling`, both failure kinds fire with the right messages: "compiles only with the driver's fallback (D-190)" and "compiles without the fallback: remove it from needsFallback".
- Limit (low): it covers only lowering-level fallbacks. A seed whose `AllInstances` C clang rejects is caught only with `PTS_SMOKE_CLANG=1`, which CI doesn't set.

**S1:** `case t.foreign` alone. The sweep classification is unchanged.

**F6 residual, N1 and N3: recorded as C172 and C176.**
- C172's claim that escaping generic declarations already blew up before H09 is true. My `gen/esc_decl_60x40.pts` gives 32,015 lines on the base and 32,419 on snap5.
- `c10_cliff` behaves as before; it is documented.

## Regression sweep (verified)
- **Round 1's 212 fuzz programs:** 162 match on all three, 37 unchanged (base and snap5 differ from Node alike), 13 improved, 0 worse. This is the same classification as round 2.
- **Round-1 probes, my round-2 probes and the reproducer's probes:** the same classification as round 2.
  - f05 now matches Node.
  - The `.par` and modules probes give the same values as before.
  - The `anyp/a04` lies still throw.
- **C size:** run, corpus and stress grow +0.257% over the base. Only three new tests changed between snap4 and snap5.

## Docs
- **D-190 (Which pairs) and h09.md ("R1 (high): fixed"):** inaccurate. u06, u07 and u09 aren't covered, and with keys the stated reason for `uninferred` (an unrelated value, or a T only in a dynamic result) no longer needs the filter.
- **The rest checked out:** D-190 on keys, the fallback, C70 and the known gaps; SPEC §3.7 and §9.129; the ARCHITECTURE driver line; HARDENING_PLAN H09a/H09b; CONSOLIDATED C09, C70, C164, C169–C176. They match the code and my runs.
- **Missing:** key growth for fresh anonymous result types, unless the key changes.
- **h09.md:** still has its TBD placeholders, as expected.

## Before it is ready
1. Remove `uninferred` (or fix it) and add u06, u07 and u09 to the unknown-type-arguments test.
2. Correct D-190 and h09.md on R1.
3. Either canonicalize keys or record per-call-site key growth in C172.

Archive: `/tmp/h09/review3/h09-review3-probes.tar.gz` (`INDEX.txt` inside); `/tmp/h09/review3/DONE` is touched. I made no edits to the main tree, the snapshots or the base; the experiments were overlays only. The cleanup of `/tmp/h09/review3/run/` was refused, so it still holds stray temporary files; they aren't in the archive.
