// Generic arrow functions and function expressions anywhere make the generic class
// instances their typed calls ask for (H09, C09): an inline arrow passed to a parameter
// of a generic function type, a function-local const called by name, an arrow a
// factory returns that captures its parameter, one capturing a local that changes, and
// one capturing `this`. Each typed call finds the instance of its signature, which runs
// with the arrow's own closure, so the boxes are `Box<number>` and `Box<string>`, not
// erased code's `Box<any>`.
class Box<T> {
  constructor(public value: T) {}
}
class Pair<A, B> {
  constructor(public first: A, public second: B) {}
}

function use(label: string, factory: <T>(value: T) => Box<T>): void {
  const box: Box<number> = factory(9);
  const named: Box<string> = factory("nine");
  console.log(label, box.value + 1, named.value.length, box instanceof Box);
}

// The review's probe (GPT #3): an inline generic arrow.
use("inline arrow", <T>(value: T) => new Box(value));
use("inline function", function <T>(value: T): Box<T> {
  return new Box(value);
});

function local(): void {
  const make = <T>(x: T): Box<T> => new Box(x);
  const b: Box<number> = make(5);
  console.log("local const", b.value + 1, make("ab").value.length);
  use("local const as value", make);
}
local();

function tagged(tag: string): <T>(value: T) => Pair<string, T> {
  return <T>(value: T) => new Pair(tag, value);
}
const label = tagged("n");
const p: Pair<string, number> = label(41);
console.log("returned arrow", p.first, p.second + 1, tagged("s")("x").second.toUpperCase());

function counted(): void {
  let made = 0;
  const make = <T>(value: T): Box<T> => {
    made++;
    return new Box(value);
  };
  use("captured counter", make);
  console.log("made", made);
}
counted();

class Shelf {
  prefix = "shelf";
  boxes(): number {
    const make = <T>(value: T): Pair<string, T> => new Pair(this.prefix, value);
    const pair: Pair<string, number> = make(2);
    return pair.second + pair.first.length;
  }
}
console.log("this", new Shelf().boxes());

// expect:
// inline arrow 10 4 true
// inline function 10 4 true
// local const 6 2
// local const as value 10 4 true
// returned arrow n 42 X
// captured counter 10 4 true
// made 2
// this 7
