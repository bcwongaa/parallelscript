#!/usr/bin/env python3
# Independent bounded loopback-only H13a checks. No external services or production data.
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import socket
import ssl
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LIMIT = 64 * 1024 * 1024
FOLLOW = b'GET /follower HTTP/1.1\r\nHost: local\r\nConnection: close\r\n\r\n'
FIRST = b'GET /first HTTP/1.1\r\nHost: local\r\n\r\n'

def raw(headers, body=b'', path=b'/probe', close=False, expect=True):
    return (b'POST ' + path + b' HTTP/1.1\r\nHost: local\r\n' + headers +
            (b'Expect: 100-continue\r\n' if expect else b'') +
            (b'Connection: close\r\n' if close else b'Connection: keep-alive\r\n') + b'\r\n' + body)

def cases():
    out = []
    def bad(name, headers, status=400, body=b'0\r\n\r\n', **kw):
        out.append(dict(name=name, wire=raw(headers, body, **kw)+FOLLOW, statuses=[status], bodies=[b''], dispatched=0))
    for i, v in enumerate([b'', b' ', b'\t', b'+0', b'-0', b'00x', b'0,0', b'0 , 0', b'0 0', b'0\t0', b'\v0', b'0\f', b'\xA00', b'\x800', b'0\x7f', b'0\0', '٠'.encode(), '０'.encode()]):
        bad(f'bad-cl-{i}-{v.hex()}', b'Content-Length: '+v+b'\r\n')
    for i, v in enumerate([b'9'*24, b'9'*512, b'67108865']):
        bad(f'oversized-{i}', b'Content-Length: '+v+b'\r\n', 413)
        for suffix in [b'x', b'+', b' 0', b'\t0', b',0', b'\x80']:
            bad(f'saturated-junk-{i}-{suffix.hex()}', b'Content-Length: '+v+suffix+b'\r\n')
    for i, (a,b) in enumerate([(b'0',b'0'), (b'00',b'0'), (b'1',b'1'), (b'1',b'2'), (b'67108865',b'67108865'), (b'9'*100,b'0')]):
        bad(f'duplicate-cl-{i}', b'Content-Length: '+a+b'\r\ncOnTeNt-LeNgTh:\t'+b+b' \r\n')
    for i,v in enumerate([b'', b'identity', b'gzip', b'chunked,', b',chunked', b'chunked,gzip', b'gzip,chunked', b'chunked,chunked', b'"chunked"', b'chunked; q=1', b'\vchunked', b'chunked\f', b'chunked\x80']):
        bad(f'bad-te-{i}-{v.hex()}', b'Transfer-Encoding: '+v+b'\r\n')
    for i,(a,b) in enumerate([(b'chunked',b'chunked'), (b'gzip',b'chunked'), (b'chunked',b'gzip'), (b'ChUnKeD',b'\tCHUNKED ')]):
        bad(f'duplicate-te-{i}', b'Transfer-Encoding: '+a+b'\r\ntRaNsFeR-EnCoDiNg: '+b+b'\r\n')
    for i,v in enumerate([b'0',b'3',b'67108865',b'9'*512]):
        for reverse in [False,True]:
            fields=[b'Content-Length: '+v+b'\r\n',b'Transfer-Encoding: chunked\r\n']
            if reverse: fields.reverse()
            bad(f'cl-te-{i}-{reverse}', b''.join(fields))
    # Errors after a valid response must close without dispatching a follower.
    for i, fields in enumerate([b'Content-Length: 0\r\nContent-Length: 0\r\n', b'Transfer-Encoding: chunked\r\nContent-Length: 0\r\n', b'Content-Length: '+b'9'*128+b'x\r\n']):
        out.append(dict(name=f'pipeline-error-{i}',wire=FIRST+raw(fields,b'0\r\n\r\n')+FOLLOW,statuses=[200,400],bodies=[b'GET:/first:',b''],dispatched=1))
    for i,(fields,body) in enumerate([(b'Content-Length: 0\r\n',b''), (b'Content-Length: 00\r\n',b''), (b'Content-Length: '+b'0'*512+b'\r\n',b''), (b'Content-Length: \t'+b'0'*512+b'3 \t\r\n',b'abc'), (b'cOnTeNt-LeNgTh: 3\r\n',b'abc'),(b'Transfer-Encoding: \tChUnKeD \t\r\n',b'3\r\nabc\r\n0\r\n\r\n'),(b'',b'')]):
        out.append(dict(name=f'valid-{i}',wire=raw(fields,body,expect=False)+FOLLOW,statuses=[200,200],bodies=[b'POST:/probe:'+ (b'abc' if body else b''),b'GET:/follower:'],dispatched=2))
    pipeline=(FIRST+raw(b'Content-Length: 3\r\n',b'abc',path=b'/cl',expect=False)+
              raw(b'Transfer-Encoding: chunked\r\n',b'1\r\nz\r\n0\r\n\r\n',path=b'/te',expect=False)+
              raw(b'Content-Length: 0\r\n',path=b'/zero',close=True,expect=False))
    out.append(dict(name='pipeline-state-reset',wire=pipeline,statuses=[200]*4,bodies=[b'GET:/first:',b'POST:/cl:abc',b'POST:/te:z',b'POST:/zero:'],dispatched=4))
    # Fragment headers before their complete CRLFCRLF; no interim response may leak.
    for fields in [b'Content-Length: 0\r\nTransfer-Encoding: chunked\r\n', b'Transfer-Encoding: chunked\r\nContent-Length: 0\r\n', b'Content-Length: '+b'9'*128+b'x\r\n', b'Transfer-Encoding: gzip, chunked\r\n']:
        for delta in [1,3]:
            wire=raw(fields,b'0\r\n\r\n')+FOLLOW
            split=wire.index(b'\r\n\r\n')+4-delta
            out.append(dict(name=f'fragmented-{len(out)}',wire=wire,split=split,statuses=[400],bodies=[b''],dispatched=0))
    return out

def parsed(wire):
    results=[]
    pos=0
    while pos<len(wire):
        end=wire.find(b'\r\n\r\n',pos)
        if end<0: raise ValueError('incomplete response head')
        head=wire[pos:end]
        status=int(head.split(b' ',2)[1])
        headers={}
        for line in head.split(b'\r\n')[1:]:
            k,v=line.split(b':',1)
            headers[k.strip().lower()]=v.strip().lower()
        start=end+4
        size=int(headers.get(b'content-length',b'0'))
        if headers.get(b'transfer-encoding') == b'chunked':
            chunks=[]
            p=start
            while True:
                e=wire.index(b'\r\n',p)
                n=int(wire[p:e].split(b';',1)[0],16)
                p=e+2
                if n==0: p+=2; break
                chunks.append(wire[p:p+n]); p+=n+2
            body=b''.join(chunks); pos=p
        else:
            body=wire[start:start+size]; pos=start+size
        if len(body)!=size and b'transfer-encoding' not in headers: raise ValueError('truncated body')
        results.append((status,body,headers))
    return results

def connect(port, ctx):
    sock=socket.create_connection(('127.0.0.1',port),timeout=3)
    if ctx is not None:
        sock=ctx.wrap_socket(sock,server_hostname='127.0.0.1',suppress_ragged_eofs=False)
    return sock

def exchange(port,ctx,wire,timeout=2,split=None):
    data=b''; early=b''; error=None; eof=False
    with connect(port,ctx) as sock:
        sock.settimeout(timeout)
        if split is not None:
            sock.sendall(wire[:split]); sock.settimeout(0.03)
            try: early=sock.recv(4096)
            except socket.timeout: pass
            sock.settimeout(timeout)
            sock.sendall(wire[split:])
        else: sock.sendall(wire)
        data=early
        while len(data)<256*1024:
            try:
                part=sock.recv(4096)
                if not part: eof=True; break
                data+=part
            except Exception as exc:
                error=f'{type(exc).__name__}: {exc}'; break
        else: error='response bound exceeded'
    return data,eof,error,early

def count(port,timeout=2):
    data,eof,error,_=exchange(port,None,b'GET /count HTTP/1.1\r\nHost: local\r\nConnection: close\r\n\r\n',timeout)
    assert eof and not error,(data,error)
    return int(parsed(data)[0][1])

def start(command,env):
    err=HERE/('node.stderr' if command[0].endswith('node') else 'pts.stderr')
    stream=err.open('w')
    process=subprocess.Popen(command,env=env,cwd=HERE,stdout=subprocess.PIPE,stderr=stream,text=True,start_new_session=True)
    ready=selectors.DefaultSelector(); ready.register(process.stdout,selectors.EVENT_READ)
    if not ready.select(15):
        process.kill(); process.wait(); stream.close()
        raise RuntimeError(f'no startup output: {command}; {err}')
    line=process.stdout.readline().strip()
    assert line.startswith('ports '),(line,err.read_text())
    return process,stream,tuple(map(int,line.split()[1:]))

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--node',action='store_true'); parser.add_argument('--out',required=True)
    args=parser.parse_args()
    cert=HERE/'cert.pem'; key=HERE/'key.pem'
    if not cert.exists():
        subprocess.run(['openssl','req','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:prime256v1','-nodes','-keyout',str(key),'-out',str(cert),'-subj','/CN=localhost','-addext','subjectAltName=IP:127.0.0.1','-days','1'],check=True,capture_output=True,timeout=10)
        key.chmod(0o600)
    ctx=ssl.create_default_context(cafile=str(cert))
    env=dict(os.environ,REVIEW_CERT=str(cert),REVIEW_KEY=str(key),PTS_THREADS='1')
    command=['/home/bryan/.local/node/bin/node',str(HERE/'server.mjs')] if args.node else [str(HERE/'server')]
    process,stream,ports=start(command,env)
    report={'command':command,'runtime_sha256':hashlib.sha256((ROOT/'pts/runtime/src/http.c').read_bytes()).hexdigest(),'node':args.node,'cases':[]}
    failures=[]
    try:
        for proto,port,context in [('http',ports[0],None),('https',ports[1],ctx)]:
            for c in cases():
                before=count(ports[0]); wire,eof,error,early=exchange(port,context,c['wire'],0.15 if args.node else 2,c.get('split'))
                after=count(ports[0])
                entry=dict(protocol=proto,name=c['name'],request_b64=base64.b64encode(c['wire']).decode(),response_b64=base64.b64encode(wire).decode(),eof=eof,error=error,dispatch_delta=after-before,early_b64=base64.b64encode(early).decode(),expected_statuses=c['statuses'],expected_dispatch=c['dispatched'])
                try:
                    parts=parsed(wire)
                    entry['statuses']=[p[0] for p in parts]
                    entry['bodies']=[p[1].decode('utf-8','backslashreplace') for p in parts]
                    problems=[]
                    if not eof: problems.append('no EOF')
                    if error: problems.append(error)
                    if entry['statuses']!=c['statuses']: problems.append('statuses')
                    if [p[1] for p in parts]!=c['bodies']: problems.append('bodies')
                    if after-before!=c['dispatched']: problems.append('dispatch')
                    if any(p[0]>=400 and p[2].get(b'connection')!=b'close' for p in parts): problems.append('missing close header')
                    if b'100 Continue' in early: problems.append('early100')
                    entry['policy_mismatches']=problems
                except Exception as exc: entry['policy_mismatches']=[f'{type(exc).__name__}: {exc}']
                if entry['policy_mismatches']: failures.append((proto,c['name'],entry['policy_mismatches']))
                report['cases'].append(entry)
            # Exact boundary: 100 is permitted, but no dispatch without the body.
            before=count(ports[0])
            with connect(port,context) as sock:
                sock.settimeout(2)
                sock.sendall(raw(b'Content-Length: 67108864\r\n',body=b''))
                head=b''
                while b'\r\n\r\n' not in head and len(head)<4096:
                    part=sock.recv(4096)
                    if not part: break
                    head+=part
            after=count(ports[0])
            ok=head==b'HTTP/1.1 100 Continue\r\n\r\n' and (args.node or after==before)
            report['cases'].append(dict(protocol=proto,name='max-body-boundary',response_b64=base64.b64encode(head).decode(),dispatch_delta=after-before,policy_mismatches=[] if ok else ['boundary']))
            if not ok: failures.append((proto,'max-body-boundary',['boundary']))
    finally:
        process.terminate()
        try: process.wait(timeout=5)
        except subprocess.TimeoutExpired: process.kill(); process.wait(timeout=5)
        stream.close()
    report['policy_matches']=len(report['cases'])-len(failures)
    report['policy_mismatches']=failures
    report['runtime_sha256_after']=hashlib.sha256((ROOT/'pts/runtime/src/http.c').read_bytes()).hexdigest()
    Path(args.out).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'node':args.node,'cases':len(report['cases']),'matches':report['policy_matches'],'mismatches':failures,'runtime_sha256':report['runtime_sha256_after']}))
    if failures and not args.node: raise SystemExit(1)

if __name__=='__main__': main()
