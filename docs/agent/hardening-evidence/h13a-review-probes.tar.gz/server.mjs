// Independent Node oracle. Only fresh local test credentials and loopback ports.
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
let count = 0;
const servers = [];
function handle(req, res) {
  if (req.url === '/count') { res.end(String(count)); return; }
  if (req.url === '/stop') { res.end('bye'); for (const s of servers) s.close(); return; }
  count++;
  const data = [];
  req.on('data', part => data.push(part));
  req.on('end', () => res.end(`${req.method}:${req.url}:${Buffer.concat(data).toString()}`));
}
const plain = http.createServer(handle);
const secure = https.createServer({cert: fs.readFileSync(process.env.REVIEW_CERT), key: fs.readFileSync(process.env.REVIEW_KEY)}, handle);
servers.push(plain, secure);
await Promise.all(servers.map(s => new Promise(resolve => s.listen(0, '127.0.0.1', resolve))));
console.log('ports', plain.address().port, secure.address().port);
