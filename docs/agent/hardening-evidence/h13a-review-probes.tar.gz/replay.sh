#!/usr/bin/env bash
# Rebuild and replay independent loopback-only review inputs with at most one CPU.
set -euo pipefail
HERE="$(dirname "$(realpath "$0")")"
ROOT="${1:-$(realpath "$HERE/../..")}"
CORE="$(python3 -I -c 'import os; print(min(os.sched_getaffinity(0)))')"
taskset -c "$CORE" env GOMAXPROCS=1 PTS_THREADS=1 PTS_HOME="$ROOT" "$ROOT/pts-bin/pts" build "$HERE/server.pts" -o "$HERE/server"
python3 -I "$HERE/probe.py" --out "$HERE/pts-results-rerun.json"
python3 -I "$HERE/probe.py" --node --out "$HERE/node-results-rerun.json"
