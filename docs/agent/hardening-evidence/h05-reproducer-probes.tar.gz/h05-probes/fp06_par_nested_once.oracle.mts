console.log([1, 2].flatMap((x) => [[x]]));
