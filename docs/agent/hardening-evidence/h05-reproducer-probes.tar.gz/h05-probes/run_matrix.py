#!/usr/bin/env python3
"""H05 Node differential matrix for flat/flatMap.

Each probe NAME.pts may carry header comments:
    // h05: <description>
    // oracle: NAME.oracle.mts     (a sequential Node equivalent; default: the probe itself as .mts)
    // threads: 1 2 4              (PTS_THREADS values; default 1)

Every probe is built with `pts build`, run at each thread count, and compared with
Node (`node --no-warnings --experimental-transform-types NAME.mts`, as the test
harness runs it). Classification, first match wins:
    TSERR  build failed with a TypeScript error (TSnnnn): not valid TS, drop it
    ICE    build exit 3, PTS9001, a Go panic, or a C compiler failure
    DIAG   build failed with a ParallelScript diagnostic (PTSnnnn)
    CRASH  a run died by a signal, timed out, or its exit code differs from Node's
    WRONG  a run's stdout differs from Node's
    OK     every run matches Node's stdout and exit code
Usage: run_matrix.py --pts CLI --home PTS_HOME --node NODE --scratch DIR --out JSON probe.pts...
"""

import argparse
import concurrent.futures
import difflib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

RUN_TIMEOUT_S = 60
BUILD_TIMEOUT_S = 600


def header(path):
    fields = {"oracle": None, "threads": [1], "description": ""}
    for line in path.read_text().splitlines():
        m = re.match(r"^// (h05|oracle|threads): (.*)$", line)
        if not m:
            continue
        key, value = m.group(1), m.group(2).strip()
        if key == "h05":
            fields["description"] = value
        elif key == "oracle":
            fields["oracle"] = value
        else:
            fields["threads"] = [int(t) for t in value.split()]
    return fields


def run(cmd, env=None, cwd=None, timeout=RUN_TIMEOUT_S):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=cwd, timeout=timeout)
        return {"exit": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    except subprocess.TimeoutExpired as e:
        return {"exit": "timeout", "stdout": (e.stdout or b"").decode() if isinstance(e.stdout, bytes) else (e.stdout or ""), "stderr": ""}


def first_diff(expected, actual):
    diff =list(difflib.unified_diff(expected.splitlines(), actual.splitlines(), "node", "pts", lineterm="", n=0))
    return "\n".join(diff[2:12])


def probe(path, args):
    h = header(path)
    scratch = Path(args.scratch) / path.stem
    shutil.rmtree(scratch, ignore_errors=True)
    scratch.mkdir(parents=True)
    env = dict(os.environ, PTS_HOME=args.home)
    binary = scratch / path.stem
    build = run([args.pts, "build", str(path), "-o", str(binary)], env=env, timeout=BUILD_TIMEOUT_S)
    if h["oracle"]:
        mts = scratch / Path(h["oracle"]).name
        shutil.copy(path.parent / h["oracle"], mts)
    else:
        mts = scratch / (path.stem + ".mts")
        shutil.copy(path, mts)
    node = run([args.node, "--no-warnings", "--experimental-transform-types", str(mts)], cwd=scratch)
    result = {"probe": path.name, "description": h["description"], "build_exit": build["exit"],
              "node_exit": node["exit"], "node_stdout": node["stdout"], "runs": []}
    err = build["stderr"]
    if build["exit"] != 0:
        result["build_stderr"] = err[-3000:]
        if re.search(r"error TS\d+", err):
            result["class"] = "TSERR"
        elif build["exit"] == 3 or "PTS9001" in err or re.search(r"^panic: ", err, re.M) or "clang" in err.lower():
            result["class"] = "ICE"
        elif re.search(r"PTS\d{4}", err):
            result["class"] = "DIAG"
        else:
            result["class"] = "ICE"
        diag = re.search(r"error (PTS\d+|TS\d+): .*", err)
        result["detail"] = diag.group(0) if diag else err.strip().splitlines()[-1] if err.strip() else ""
        return result
    cls = "OK"
    details = []
    for threads in h["threads"]:
        r = run([str(binary)], env=dict(env, PTS_THREADS=str(threads)))
        r["threads"] = threads
        result["runs"].append(r)
        if r["exit"] == "timeout" or (isinstance(r["exit"], int) and r["exit"] < 0) or r["exit"] != node["exit"]:
            cls = "CRASH"
            details.append(f"t{threads}: exit {r['exit']} (node {node['exit']}); stderr: {r['stderr'].strip()[:300]}")
        elif r["stdout"] != node["stdout"] and cls != "CRASH":
            cls = "WRONG"
            details.append(f"t{threads}:\n{first_diff(node['stdout'], r['stdout'])}")
        elif r["stdout"] != node["stdout"]:
            details.append(f"t{threads}:\n{first_diff(node['stdout'], r['stdout'])}")
    result["class"] = cls
    result["detail"] = "\n".join(details)
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--node", required=True)
    ap.add_argument("--scratch", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("probes", nargs="+")
    args = ap.parse_args()
    paths = [Path(p).resolve() for p in args.probes if not p.endswith(".oracle.mts")]
    with concurrent.futures.ThreadPoolExecutor(args.jobs) as pool:
        results = list(pool.map(lambda p: probe(p, args), paths))
    Path(args.out).write_text(json.dumps(results, indent=1))
    counts = {}
    for r in results:
        counts[r["class"]] = counts.get(r["class"], 0) + 1
        print(f"{r['class']:6} {r['probe']}  -- {r['description']}")
        if r["class"] != "OK" and r.get("detail"):
            for line in r["detail"].splitlines():
                print(f"         {line}")
    print("counts:", json.dumps(counts, sort_keys=True))
    sys.exit(0)


if __name__ == "__main__":
    main()
