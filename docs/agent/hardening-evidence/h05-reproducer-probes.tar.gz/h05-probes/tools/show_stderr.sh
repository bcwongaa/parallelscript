#!/bin/bash
# Run each named run test with the worktree CLI and show exit code, stdout and stderr heads.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-aa9b2c9ea41b3d6b2
cd "$W" || exit 9
export PTS_HOME=$W PTS_THREADS=${PTS_THREADS:-2}
for t in "$@"; do
  echo "== $t"
  "$W/pts-bin/pts" run "pts/tests/run/$t.pts" > /tmp/h05repro.ykncB8/o.txt 2> /tmp/h05repro.ykncB8/e.txt
  echo "exit=$?"
  head -3 /tmp/h05repro.ykncB8/o.txt | sed 's/^/  out: /'
  head -3 /tmp/h05repro.ykncB8/e.txt | sed 's/^/  err: /'
done
