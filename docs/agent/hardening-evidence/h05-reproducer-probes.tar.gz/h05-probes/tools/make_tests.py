"""Split the test bundle, run each body under Node (a sequential oracle for `.par`), and
write the run test with Node's stdout as its `// expect:` block."""
import re
import subprocess
import sys
from pathlib import Path

bundle, outdir, scratch, node = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
scratch.mkdir(parents=True, exist_ok=True)
tests, name, lines = {}, None, []
for line in bundle.read_text().splitlines():
    if line.startswith("=== "):
        if name:
            tests[name] = "\n".join(lines).rstrip("\n") + "\n"
        name, lines = line[4:].strip(), []
    else:
        lines.append(line)
if name:
    tests[name] = "\n".join(lines).rstrip("\n") + "\n"

ok = True
for name, body in tests.items():
    oracle = body
    if ".par." in body:
        oracle = re.sub(r"\.par\.", ".", body)
    mts = scratch / (Path(name).stem + ".mts")
    mts.write_text(oracle)
    p = subprocess.run([node, "--no-warnings", "--experimental-transform-types", str(mts)], capture_output=True, text=True, cwd=scratch)
    if p.returncode != 0 or p.stderr.strip() or not p.stdout:
        print(f"NODE FAILED {name}: exit {p.returncode}\n{p.stderr}")
        ok = False
        continue
    expect = ["// expect:"] + [("// " + l) if l else "//" for l in p.stdout.rstrip("\n").split("\n")]
    (outdir / name).write_text(body + "\n" + "\n".join(expect) + "\n")
    print(f"wrote {name} ({len(expect) - 1} expected lines)")
sys.exit(0 if ok else 1)
