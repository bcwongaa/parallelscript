#!/bin/bash
# Run the compiler smoke test over the new H05 run tests only (mutants included).
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-aa9b2c9ea41b3d6b2 || exit 9
export PATH=$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH
export GOMAXPROCS=2 PTS_SMOKE_JOBS=2 PTS_SMOKE_MUTANTS=${PTS_SMOKE_MUTANTS:-3}
export PTS_SMOKE_FILTER='run/(flat_[a-z_]+|flatmap_[a-z_]+|any_flat_holes|parallel_flatmap_[a-z]+)\.pts'
go test ./pts/tests/ -count=1 -timeout 40m -v -run '^TestCompilerFailsCleanly$' > /tmp/h05repro.ykncB8/smoke.txt 2>&1
echo "exit=$?" >> /tmp/h05repro.ykncB8/smoke.txt
