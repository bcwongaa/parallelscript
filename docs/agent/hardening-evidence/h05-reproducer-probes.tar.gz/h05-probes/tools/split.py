import sys
from pathlib import Path

bundle, outdir = Path(sys.argv[1]), Path(sys.argv[2])
name, lines, count = None, [], 0
def flush():
    global count
    if name:
        (outdir / name).write_text("\n".join(lines).rstrip("\n") + "\n")
        count += 1
for line in bundle.read_text().splitlines():
    if line.startswith("=== "):
        flush()
        name, lines = line[4:].strip(), []
    else:
        lines.append(line)
flush()
print(count, "files")
