#!/bin/bash
# Run the H05 RED run tests on the base worktree.
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-aa9b2c9ea41b3d6b2 || exit 9
export PATH=$HOME/.local/go/bin:$HOME/.local/node/bin:$PATH
export GOMAXPROCS=2 PTS_REQUIRE_NODE=1
names="${1:-flat_unions|flat_depths|flat_tuples|flat_tuple_receiver|flat_any_elements|flat_holes|flatmap_union_results|flat_typed_results|flat_generic|flatmap_holes|any_flat_holes|parallel_flatmap_unions|parallel_flatmap_holes|flat_literal_depths|flat_negative_depths|flat_integer_unions}"
out="${2:-/tmp/h05repro.ykncB8/red_tests.txt}"
go test ./pts/tests/ -count=1 -parallel 2 -timeout 40m -v -run "^(TestRun|TestRunMatchesNode)\$/^($names)\$" > "$out" 2>&1
echo "exit=$?" >> "$out"
