console.log([1, 2, 3].flatMap((x) => (x % 2 ? x : [x, x])));
