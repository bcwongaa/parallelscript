console.log(["a", "b"].flatMap((x) => {
  const out = new Array<string>(2);
  out[1] = x;
  return out;
}));
