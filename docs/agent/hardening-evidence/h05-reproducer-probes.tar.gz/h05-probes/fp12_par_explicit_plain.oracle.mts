console.log([1, 2].flatMap<number>((x) => [x, x]));
console.log([1, 2].flatMap<string>((x) => String(x)));
