const r = [0, 1, 2, 3];
console.log(r.flatMap((i) => [i, i]));
console.log(r.flatMap((i) => (i % 2 ? [i, i] : i)));
