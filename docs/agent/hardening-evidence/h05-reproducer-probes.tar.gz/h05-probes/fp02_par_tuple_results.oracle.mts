console.log([1, 2].flatMap((x): [number, string] => [x, String(x)]));
