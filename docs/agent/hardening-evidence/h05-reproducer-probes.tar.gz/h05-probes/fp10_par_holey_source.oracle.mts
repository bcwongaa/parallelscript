const src = new Array<string>(3);
src[0] = "a";
src[2] = "c";
console.log(src.flatMap((x) => [x, x]));
