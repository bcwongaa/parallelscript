console.log([1, 2].flatMap((x): readonly number[] => [x, x * 10]));
