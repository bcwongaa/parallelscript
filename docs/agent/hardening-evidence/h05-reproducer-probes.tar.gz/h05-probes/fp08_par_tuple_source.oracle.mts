const pairs: [string, number][] = [["a", 1], ["b", 2]];
console.log(pairs.flatMap((p) => p));
