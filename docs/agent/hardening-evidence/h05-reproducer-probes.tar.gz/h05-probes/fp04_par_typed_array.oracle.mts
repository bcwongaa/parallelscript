const xs = Array.from(new Float64Array([1, 2, 3]));
console.log(xs.flatMap((x) => [x, x * 10]));
console.log(xs.flatMap((x) => (x > 1 ? x : [x, x])));
