const nested: (number | number[])[] = [1, [2, 3], 4];
console.log(nested.flatMap((x) => x));
