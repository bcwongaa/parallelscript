console.log([1, 2].flatMap((x): any => (x === 1 ? [x, x] : x)));
