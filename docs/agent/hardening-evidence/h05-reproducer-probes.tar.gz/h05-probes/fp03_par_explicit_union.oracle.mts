const values: number[] = [1, 2];
console.log(values.flatMap<number | number[]>((x) => (x === 1 ? x : [[x]])));
