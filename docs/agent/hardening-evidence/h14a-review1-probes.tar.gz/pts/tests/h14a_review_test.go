package tests

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"testing"
	"time"

	"github.com/microsoft/typescript-go/pts/toolchain"
	"gotest.tools/v3/assert"
)

func reviewH14Response(t *testing.T, reader *bufio.Reader, want string) {
	t.Helper()
	response, err := http.ReadResponse(reader, nil)
	assert.NilError(t, err)
	assert.Equal(t, response.StatusCode, 200)
	body, err := io.ReadAll(response.Body)
	assert.NilError(t, err)
	assert.NilError(t, response.Body.Close())
	assert.Equal(t, string(body), want)
}

func reviewH14Marker(t *testing.T, path string) {
	t.Helper()
	until := time.Now().Add(2 * time.Second)
	for time.Now().Before(until) {
		if _, err := os.Stat(path); err == nil {
			return
		}
		time.Sleep(5 * time.Millisecond)
	}
	t.Fatal("blocking handler did not publish its marker")
}

func TestH14aReviewDelayedCallbacksRejectExpiredHeaders(t *testing.T) {
	exe := buildServer(t, "h14a_review")
	for _, secure := range []bool{false, true} {
		for _, reused := range []bool{false, true} {
			t.Run(fmt.Sprintf("TLS=%v/reused=%v", secure, reused), func(t *testing.T) {
				marker := filepath.Join(t.TempDir(), "entered")
				t.Setenv("H14_REVIEW_MARKER", marker)
				endpoint := startResourceEndpoint(t, exe, secure, 1, 400*time.Millisecond, 2*time.Second)
				defer endpoint.stop(t)
				conn := endpoint.dial(t)
				defer conn.Close()
				reader := bufio.NewReader(conn)
				if reused {
					assert.Equal(t, resourceRoundTrip(t, conn, reader, "/ok", ""), "ok")
				}
				_, err := io.WriteString(conn, "GET /must-not-dispatch HTTP/1.1\r\nHost: loopback\r\n")
				assert.NilError(t, err)
				before := endpoint.count(t)
				blocker := endpoint.dial(t)
				defer blocker.Close()
				_, err = io.WriteString(blocker, "GET /block HTTP/1.1\r\nHost: loopback\r\n\r\n")
				assert.NilError(t, err)
				reviewH14Marker(t, marker)
				time.Sleep(500 * time.Millisecond)
				_, _ = io.WriteString(conn, "\r\nGET /follower-must-not-dispatch HTTP/1.1\r\nHost: loopback\r\n\r\n")
				reviewH14Response(t, bufio.NewReader(blocker), "blocked")
				wire, err := io.ReadAll(io.LimitReader(reader, 4096))
				assert.Assert(t, err == nil || errors.Is(err, syscall.ECONNRESET), "expired input must close, not just wait: %v", err)
				assert.Equal(t, len(wire), 0, "expired completed headers/follower produced a response: %q", wire)
				assert.Equal(t, endpoint.count(t), before+1, "only the blocker may dispatch")
				t.Log("late completion and follower rejected after a 1200ms blocked loop")
			})
		}
	}
}

func TestH14aReviewPipelineAndContinueExcludeNonHeaderPhases(t *testing.T) {
	exe := buildServer(t, "h14a_review")
	for _, secure := range []bool{false, true} {
		for _, threads := range []int{1, 4} {
			t.Run(fmt.Sprintf("TLS=%v/threads=%d", secure, threads), func(t *testing.T) {
				endpoint := startResourceEndpoint(t, exe, secure, threads, 400*time.Millisecond, 2*time.Second)
				defer endpoint.stop(t)
				conn := endpoint.dial(t)
				defer conn.Close()
				reader := bufio.NewReader(conn)
				_, err := io.WriteString(conn, "GET /hold HTTP/1.1\r\nHost: loopback\r\n\r\nGET /ok HTTP/1.1\r\nHost: loopback\r\n")
				assert.NilError(t, err)
				reviewH14Response(t, reader, "held:false")
				_, err = io.WriteString(conn, "\r\n")
				assert.NilError(t, err)
				reviewH14Response(t, reader, "ok")
				assert.NilError(t, conn.SetDeadline(time.Now().Add(3*time.Second)))
				_, err = io.WriteString(conn, "POST /echo HTTP/1.1\r\nHost: loopback\r\nTransfer-Encoding: chunked\r\nExpect: 100-continue\r\n\r\n")
				assert.NilError(t, err)
				interim, err := http.ReadResponse(reader, nil)
				assert.NilError(t, err)
				assert.Equal(t, interim.StatusCode, 100)
				assert.NilError(t, interim.Body.Close())
				_, err = io.WriteString(conn, "1\r\na\r\n")
				assert.NilError(t, err)
				time.Sleep(650 * time.Millisecond)
				_, err = io.WriteString(conn, "0\r\n\r\n")
				assert.NilError(t, err)
				reviewH14Response(t, reader, "a")
				assert.NilError(t, conn.SetDeadline(time.Now().Add(3*time.Second)))
				_, err = io.WriteString(conn, "GET /ok HTTP/1.1\r\nHost: loopback\r\n")
				assert.NilError(t, err)
				expired, err := io.ReadAll(io.LimitReader(reader, 4096))
				assert.NilError(t, err)
				assert.Equal(t, len(expired), 0)
				t.Log("held-handler pipeline and valid chunked/100 body survive; later partial header expires")
			})
		}
	}
}

func TestH14aReviewDeadlineStateControls(t *testing.T) {
	chain, err := toolchain.New()
	assert.NilError(t, err)
	rt, err := chain.Runtime(context.Background(), toolchain.Release)
	assert.NilError(t, err)
	source, err := filepath.Abs(filepath.Join("testdata", "h14a_review", "deadline_state.c"))
	assert.NilError(t, err)
	exe := filepath.Join(t.TempDir(), "deadline-state")
	assert.NilError(t, chain.CompileProgram(context.Background(), rt, []string{source}, exe))
	result, err := exec.CommandContext(t.Context(), exe).CombinedOutput()
	assert.NilError(t, err, "%s", result)
	assert.Equal(t, string(result), "H14a state controls passed\n")
}
