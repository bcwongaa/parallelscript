package tests

import (
	"context"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/toolchain"
	"gotest.tools/v3/assert"
)

func TestH14aReviewTimerRoundingObservation(t *testing.T) {
	chain, err := toolchain.New()
	assert.NilError(t, err)
	rt, err := chain.Runtime(context.Background(), toolchain.Release)
	assert.NilError(t, err)
	source, err := filepath.Abs(filepath.Join("testdata", "h14a_review", "timer_rounding.c"))
	assert.NilError(t, err)
	exe := filepath.Join(t.TempDir(), "timer-rounding")
	assert.NilError(t, chain.CompileProgram(context.Background(), rt, []string{source}, exe))
	result, err := exec.CommandContext(t.Context(), exe).CombinedOutput()
	assert.NilError(t, err, "%s", result)
	t.Logf("monotonic rounding observation: %s", result)
	assert.Assert(t, strings.HasPrefix(string(result), "early_count=0/32 "), "connection closed before its monotonic deadline: %s", result)
}
