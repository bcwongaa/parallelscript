/* Observe whether the production UV callback precedes its own monotonic deadline. */
#include "../../../runtime/src/http.c"

static unsigned early_count;
static uint64_t maximum_early_ns;
static void spin(uv_idle_t *idle) { (void)idle; }
static void observe(uv_timer_t *timer) {
  connection *c = timer->data;
  uint64_t deadline_at = c->deadline_at;
  on_deadline(timer);
  uint64_t now = uv_hrtime();
  if (c->closing && now < deadline_at) {
    early_count++;
    uint64_t early = deadline_at - now;
    if (early > maximum_early_ns) maximum_early_ns = early;
  }
}
int main(int argc, char **argv) {
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  server s = {0};
  listener l = {.server = &s};
  uv_idle_t idle;
  uv_idle_init(pts_uv_loop(), &idle);
  uv_idle_start(&idle, spin); /* represents a busy loop with other ready I/O */
  for (unsigned i = 0; i < 32; i++) {
    connection *c = checked(calloc(1, sizeof *c));
    uv_tcp_init(pts_uv_loop(), &c->tcp);
    c->listener = &l;
    c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
    add_to_table(c);
    l.connections = c;
    start_deadline(c, 2);
    c->deadline->timer_cb = observe; /* wraps the callback without changing its scheduled time */
    while (l.connections != NULL) uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
    uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  }
  uv_idle_stop(&idle);
  uv_close((uv_handle_t *)&idle, NULL);
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  printf("early_count=%u/32 maximum_early_ns=%llu\n", early_count, (unsigned long long)maximum_early_ns);
  return 0;
}
