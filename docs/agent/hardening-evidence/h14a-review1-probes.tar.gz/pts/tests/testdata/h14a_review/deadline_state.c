/* Independent state-machine review input. No network timing assumptions. */
#include "../../../runtime/src/http.c"

static void require(bool condition, const char *message) {
  if (!condition) {
    fprintf(stderr, "review assertion: %s\n", message);
    exit(1);
  }
}

static connection *review_connection(listener *l, const char *input) {
  connection *c = checked(calloc(1, sizeof *c));
  uv_tcp_init(pts_uv_loop(), &c->tcp);
  c->listener = l;
  c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
  c->headers_pending = true;
  c->in = strdup(input);
  c->in_len = strlen(input);
  c->in_cap = c->in_len + 1;
  add_to_table(c);
  c->next = l->connections;
  if (c->next != NULL) c->next->prev = c;
  l->connections = c;
  return c;
}

static void review_written(connection *c) {
  write_request *w = checked(calloc(1, sizeof *w));
  w->connection = c;
  on_written(&w->req, 0);
}

int main(int argc, char **argv) {
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  server s = {0};
  s.headers_timeout = 400;
  listener l = {.server = &s};
  connection *c = review_connection(&l, "GET /ok HTTP/1.1\r\n");

  /* A non-draining output queue below MAX_QUEUED must still exclude headers. */
  ((uv_stream_t *)&c->tcp)->write_queue_size = 17;
  next_header_deadline(c);
  require(c->deadline == NULL && c->deadline_at == 0, "queued output armed headers");
  review_written(c);
  require(c->deadline == NULL, "nonfinal write callback armed headers");
  ((uv_stream_t *)&c->tcp)->write_queue_size = 0;
  review_written(c);
  require(c->deadline != NULL && c->deadline_at != 0, "final non-draining write did not arm buffered headers");
  require(uv_is_active((uv_handle_t *)c->deadline), "new header timer inactive");
  uint64_t original = c->deadline_at;
  next_header_deadline(c);
  require(c->deadline_at == original, "progress reset the deadline");

  free(c->in);
  c->in = strdup("POST /echo HTTP/1.1\r\nHost: loopback\r\nContent-Length: 1\r\n\r\n");
  c->in_len = strlen(c->in);
  c->in_cap = c->in_len + 1;
  process(c);
  require(!c->headers_pending && c->deadline_at == 0, "complete headers left deadline armed during body");
  require(!uv_is_active((uv_handle_t *)c->deadline), "body timer still active");
  next_header_deadline(c);
  require(c->deadline_at == 0, "body read restarted headers");
  c->headers_pending = true;
  c->busy = true;
  next_header_deadline(c);
  require(c->deadline_at == 0, "handler armed headers");
  c->busy = false;
  uv_timer_t *timer = c->deadline;
  close_connection(c);
  require(timer->data == NULL && uv_is_closing((uv_handle_t *)timer), "closing timer retains connection");
  require(c->deadline == NULL && c->closing, "connection failed to detach timer");
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);

  c = review_connection(&l, "GET /ok HTTP/1.1\r\nHost: loopback\r\n\r\n");
  start_deadline(c, 400);
  timer = c->deadline;
  uint32_t slot = c->slot;
  c->deadline_at = uv_hrtime() - 1;
  process(c); /* a completed head delivered after expiry must not reach NULL on_request */
  require(c->closing && c->deadline == NULL, "late completed header was accepted");
  require(table.connections[slot] == NULL, "expired connection retained its id");
  require(timer->data == NULL && uv_is_closing((uv_handle_t *)timer), "expiry retained timer data");
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);

  c = review_connection(&l, "GET /ok HTTP/1.1\r\n");
  s.headers_timeout = 0;
  next_header_deadline(c);
  require(c->deadline == NULL && c->deadline_at == 0, "disabled deadline allocated timer");
  close_connection(c);
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  puts("H14a state controls passed");
  return 0;
}
