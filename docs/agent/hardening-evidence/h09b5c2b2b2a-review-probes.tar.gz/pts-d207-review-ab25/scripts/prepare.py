import hashlib, json, pathlib, subprocess
ROOT = pathlib.Path('/tmp/pts-d207-review-ab25')
WT = pathlib.Path('/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25')
SNAP = pathlib.Path('/tmp/pts-h09b5c2b2b2-rHJnXz/review-snapshot')
PARENT = pathlib.Path('/home/bryan/projects/parallelscript')
for name in ('inputs', 'raw', 'bin', 'snapshot', 'tests'):
    (ROOT/name).mkdir(parents=True, exist_ok=True)
expected = json.loads((SNAP/'sha256.json').read_text())
basehash, currenthash = {}, {}
current = {}
for relative, digest in expected.items():
    content = (SNAP/relative).read_bytes()
    actual = hashlib.sha256(content).hexdigest()
    assert actual == digest, (relative, actual, digest)
    target = ROOT/'snapshot'/relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
    current[str(WT/relative)] = str(target)
    currenthash[relative] = actual
    base = subprocess.check_output(['git', '-C', str(WT), 'show', 'be71aac86:'+relative])
    assert base == (WT/relative).read_bytes()
    basehash[relative] = hashlib.sha256(base).hexdigest()
for relative in ('pts/driver/h09_captured_receiver_flow_test.go', 'pts/lower/captured_receiver_tables_test.go'):
    data = (PARENT/relative).read_bytes()
    target = ROOT/'tests'/pathlib.Path(relative).name
    target.write_bytes(data)
    current[str(WT/relative)] = str(target)
base_tests = {k:v for k,v in current.items() if '/tests/' in v}
current_unit = dict(current)
current_unit[str(WT/'pts/lower/review_d207_mutation_test.go')] = str(ROOT/'tests/review_mutation_test.go')
for name, replacements in (('current.json',current), ('base-tests.json',base_tests), ('current-unit.json',current_unit)):
    (ROOT/name).write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
(ROOT/'raw/reviewed-hashes.json').write_text(json.dumps({'base':'be71aac86','base_sha256':basehash,'snapshot_sha256':currenthash},indent=2)+'\n')
(ROOT/'snapshot/production.patch').write_bytes((SNAP/'production.patch').read_bytes())
for name in ('generic_captured_receiver_sources.pts', 'generic_captured_receiver_unknowns.pts'):
    (ROOT/'inputs'/name).write_bytes((PARENT/'pts/tests/run'/name).read_bytes())
print(json.dumps({'verified_files':currenthash,'overlay_files':len(current)}))
