import collections,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/tmp/pts-d207-review-ab25');R2=ROOT/'round2';WT=pathlib.Path('/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25')
ENV={'GOMAXPROCS':'1','PTS_HOME':'/home/bryan/projects/parallelscript'}
commands=[];gates={}
for name,overlay,pattern,packages,expected_fail in [
 ('original-index-red','original-index.json','^Test(CapturedReceiverAssertionWrites|FunctionParameterAssertionWrites|D207ReviewCapturedParameterAssertionWrites)',['./pts/lower'],22),
 ('base-final-tests-red','base-final-tests.json','^Test(CapturedReceiver|WrapperCreationTables)',['./pts/driver','./pts/lower'],20),
 ('final-packages','current.json',None,['./pts/lower','./pts/driver'],0),
 ('base-literal-targets-red','base-final-tests.json','^TestCapturedClassReceiversExcludeLiteralCandidatesOnlyWhenProven$',['./pts/driver'],3),
]:
 stdout=R2/'raw'/(name+'.jsonl');stderr=R2/'raw'/(name+'.stderr')
 rows=[json.loads(x) for x in stdout.read_text().splitlines()]
 counts=collections.Counter(x['Action'] for x in rows if x.get('Test'))
 terminal=[{'package':x['Package'],'action':x['Action'],'elapsed':x.get('Elapsed')} for x in rows if not x.get('Test') and x['Action'] in ['pass','fail']]
 assert counts['fail']==expected_fail,(name,counts)
 assert len(stderr.read_bytes())==0
 if name=='final-packages':assert counts['pass']==492 and len(terminal)==2 and all(x['action']=='pass' for x in terminal)
 gates[name]={'test_event_counts':dict(counts),'package_terminal_events':terminal,'stderr_bytes':0}
 args=['go','-C',str(WT),'test','-count=1','-json','-p','1','-parallel','1','-timeout','20m' if name=='base-literal-targets-red' else '40m','-overlay',str(R2/overlay)]
 if pattern:args+=['-run',pattern]
 args+=packages
 commands.append({'environment':ENV,'argv':args,'stdout':str(stdout),'stderr':str(stderr),'observed_exit':1 if expected_fail else 0})
(R2/'raw/go-validation.json').write_text(json.dumps(gates,indent=2)+'\n')
(R2/'raw/go-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
manifest=json.loads((R2/'snapshot/sha256.json').read_text());verified={}
for relative,digest in manifest.items():
 a=hashlib.sha256((R2/'snapshot'/relative).read_bytes()).hexdigest()
 b=hashlib.sha256((pathlib.Path('/home/bryan/projects/parallelscript')/relative).read_bytes()).hexdigest()
 assert a==b==digest,(relative,a,b,digest)
 verified[relative]=a
assert subprocess.check_output(['git','-C',str(WT),'status','--porcelain']).decode()==''
(R2/'raw/final-hash-verification.json').write_text(json.dumps({'base':'be71aac86','worktree_clean':True,'snapshot_and_parent_sha256':verified,'review_seam_sha256':hashlib.sha256((ROOT/'tests/review_seam_test.go').read_bytes()).hexdigest()},indent=2)+'\n')
annotations={
 'original_round1_failures_retained':{'mutation':'raw/mutation-current.jsonl','initial_supplied_tests':'raw/original-tests-current.jsonl','original_exact_base_tests':'raw/original-tests-base-tests.jsonl'},
 'unsupported_both_base_and_final':['parameter_write_asserted','parameter_write_typeasserted','parameter_write_nonnull','destructured_class','class_arrow_property_as_method','class_function_property_as_method'],
 'preexisting_contextual_explicit_bind_failures_both_base_and_final':['contextual_generic_alias','contextual_generic_inbody','contextual_generic_inbody_direct_demand'],
 'intentional_checked_any_override_barrier':'override_barrier rejects at M1.make on both versions; do not count as native-vs-Node acceptance',
 'source_only_asserted_parameter_write':{'round1_expected':'UNKNOWN but got [A] through methodForward receiverSource','round2_expected':'UNKNOWN; fixed by shared markAssignedOutside assertion/non-null/satisfies unwrap','native_status':'assignment target syntax unsupported identically before native compilation; no supported native wrong-output claim'},
 'corrected_union_test':'Original repeated M0/M1 constructors represented only two class-source identities. Final distinct ordinary subclass declarations genuinely hit 256/257 bound.',
 'corrected_contextual_test':'Original contextual-returned wrapper lacked typed targets even on exact base (C255). Final generic-return-origin guard has typed targets and remains conservative; own direct seam controls separately test contextual generic lexical guard.',
 'corrected_wrapper_creation_table_test':'Exact closed callers prove diagonal receiver/demand sets. Final test preserves required signatures, Shares/capture assertions and excludes cross-pairs for class and interface cases.',
 'H09b5b':'Provider-refused independent acceptance remains BLOCKED; untouched and not reviewed.'
}
(R2/'raw/control-classifications.json').write_text(json.dumps(annotations,indent=2)+'\n')
print(json.dumps({'go_gates':{k:v['test_event_counts'] for k,v in gates.items()},'hashes_verified':len(verified),'worktree_clean':True}))
