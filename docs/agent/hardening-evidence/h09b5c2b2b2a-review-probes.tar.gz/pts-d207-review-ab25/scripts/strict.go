package main

import (
 "context"
 "fmt"
 "os"
 "time"

 "github.com/microsoft/typescript-go/pts/driver"
 "github.com/microsoft/typescript-go/pts/lower"
 "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
 if len(os.Args) != 4 { fmt.Fprintln(os.Stderr, "usage: strict source.pts output.c binary-or-dash"); os.Exit(2) }
 ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
 defer cancel()
 code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
 if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(3) }
 if err := os.WriteFile(os.Args[2], []byte(code), 0600); err != nil { panic(err) }
 if os.Args[3] == "-" { return }
 tc, err := toolchain.New()
 if err != nil { panic(err) }
 rt, err := tc.Runtime(ctx, toolchain.Release)
 if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(4) }
 if err := tc.CompileProgram(ctx, rt, []string{os.Args[2]}, os.Args[3]); err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(5) }
}
