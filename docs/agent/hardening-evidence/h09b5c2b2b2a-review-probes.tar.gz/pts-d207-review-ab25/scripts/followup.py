import json,os,pathlib,re,subprocess,time
ROOT=pathlib.Path(os.environ.get('D207_REVIEW_ROOT','/tmp/pts-d207-review-ab25'))
WT=pathlib.Path(os.environ.get('D207_REVIEW_WORKTREE','/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25'))
ENV=dict(os.environ,GOMAXPROCS='1',PTS_HOME='/home/bryan/projects/parallelscript',PTS_THREADS='1')
rows=[]
manifest=json.loads((ROOT/'raw/matrix-manifest.json').read_text())
byname={x['name']:x for x in manifest}
cases=[]
def add(name,source,pairs=None): cases.append({'name':name,'source':source,'expected_pairs':pairs})
add('class_destructure_same_class',byname['destructured_class']['source'].replace('read(new M1())','read(new M0())'), [('M0','C0')])
a=byname['returned_receiver_alias']['source']
for i in range(3):
 a=a.replace('make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); }','make = <T>(value: T): Box<T> => { this.calls++; return new Box(value, this.label + "/" + this.calls); };',1)
add('class_arrow_property_as_method',a)
a=byname['returned_receiver_alias']['source']
a=a.replace('make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); }','make: Factory = function<T>(value: T): Box<T> { return new Box(value, "function-property"); };')
add('class_function_property_as_method',a)
a=byname['contextual_generic_alias']['source']
a=a[:a.index('const receiver: Maker')]+'''const receiver: Maker = new M0();
const outer: <U>(marker: U) => void = marker => { console.log(marker); const f: Factory = receiver.make.bind(receiver); use0(f); };
outer(1);
'''
add('contextual_generic_inbody',a,[('M%d'%i,'C0') for i in range(3)])
a=byname['contextual_generic_alias']['source']
a=a[:a.index('const receiver: Maker')]+'''const receiver: Maker = new M0();
const outer: <U>(marker: U) => void = marker => { console.log(marker); const f: Factory = receiver.make.bind(receiver); const box: Box<C0> = f(new C0()); console.log(box.origin, box.value.tag); };
outer(1);
'''
add('contextual_generic_inbody_direct_demand',a,[('M%d'%i,'C0') for i in range(3)])
a=byname['bind_different_thisarg']['source']
a=a[:a.index('const f = rebind')]+'''let order = "";
function lookup(): Base { order += "lookup "; return new M0("lookup"); }
function capture(): Base { order += "capture "; return new M1("capture"); }
const f = lookup().make.bind(capture());
console.log(order); use0(f); use1(f); console.log(order);
'''
add('bind_evaluation_once_in_order',a,[('M1','C0'),('M1','C1')])
for fixture in ['generic_captured_receiver_sources','generic_captured_receiver_unknowns']:
 add(fixture,(ROOT/'inputs'/(fixture+'.pts')).read_text())
commands=[]
def run(args):
 t=time.monotonic()
 try:
  p=subprocess.run([str(x) for x in args],cwd=WT,env=ENV,capture_output=True,text=True,timeout=150)
  r={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 except subprocess.TimeoutExpired as e: r={'exit':'timeout','stdout':str(e.stdout or ''),'stderr':str(e.stderr or '')}
 r['seconds']=round(time.monotonic()-t,3);commands.append({'args':[str(x) for x in args],**r});return r
for case in cases:
 name=case['name'];s=ROOT/'inputs'/(name+'.pts');s.write_text(case['source']);s.with_suffix('.mts').write_text(case['source'])
 row={'name':name,'node':run(['/home/bryan/.local/node/bin/node','--no-warnings','--experimental-transform-types',s.with_suffix('.mts')]),'versions':{}}
 for v in ['base','current']:
  c=ROOT/'raw'/(name+'.'+v+'.c');b=ROOT/'bin'/(name+'.'+v)
  helper=pathlib.Path(os.environ.get('D207_'+v.upper()+'_HELPER',str(ROOT/'bin'/v)))
  r={'emit':run([helper,s,c,b])}
  if c.exists():
   text=c.read_text();r['pairs']=sorted(set(re.findall(r'\bpts_fn_(M[012])_make_(C[012])\(',text)))
   r['registered']=sorted(set(re.findall(r'return pts_fn_(M[012])_make_(C[012])\(',text)))
   if case['expected_pairs'] is not None:r['pair_check']=r['pairs']==sorted(case['expected_pairs']) and r['registered']==sorted(case['expected_pairs'])
  if r['emit']['exit']==0:
   r['native']=run([b]);r['matches_node']=r['native']['exit']==row['node']['exit']==0 and r['native']['stdout']==row['node']['stdout']
  b.unlink(missing_ok=True);row['versions'][v]=r
 rows.append(row)
 (ROOT/'raw/followup-results.json').write_text(json.dumps(rows,indent=2)+'\n');(ROOT/'raw/followup-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print(name,[(v,r['emit']['exit'],r.get('matches_node'),r.get('pair_check')) for v,r in row['versions'].items()],flush=True)
(ROOT/'raw/followup-manifest.json').write_text(json.dumps(cases,indent=2)+'\n')
