import json, os, pathlib, re, subprocess, sys, time
ROOT = pathlib.Path(os.environ.get('D207_REVIEW_ROOT', '/tmp/pts-d207-review-ab25'))
WT = pathlib.Path(os.environ.get('D207_REVIEW_WORKTREE', '/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25'))
ENV = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript', PTS_THREADS='1')
COMMANDS = []

def run(args, timeout=150):
    start = time.monotonic()
    try:
        p = subprocess.run([str(x) for x in args], cwd=WT, env=ENV, text=True, capture_output=True, timeout=timeout)
        result = {'exit':p.returncode, 'stdout':p.stdout, 'stderr':p.stderr}
    except subprocess.TimeoutExpired as e:
        result = {'exit':'timeout', 'stdout':str(e.stdout or ''), 'stderr':str(e.stderr or '')}
    result['seconds'] = round(time.monotonic()-start,3)
    COMMANDS.append({'cwd':str(WT),'args':[str(x) for x in args],**result})
    return result

PRE = '''class Box<T> { constructor(public value: T, public origin: string) {} }
interface Maker { make<T>(value: T): Box<T>; }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 10; } class C1 { tag = 20; } class C2 { tag = 30; }
function choose(): boolean { return false; }
'''
MODELS = ''.join('class M%d implements Maker { calls = 0; constructor(public label: string = "M%d") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }\n'%(i,i) for i in range(3))
def uses_for(body):
    return ''.join('function use%d(f: Factory): void { const box: Box<C%d> = f(new C%d()); console.log(box.origin, box.value.tag); }\n'%(i,i,i) for i in sorted({int(x) for x in re.findall(r'\buse([012])\(', body)}))
READ = 'function read(receiver: Maker): Factory { return receiver.make.bind(receiver); }\n'
CASES = []
def add(name, body, pairs, extra='', models=MODELS, classification='match', compile_native=True):
    CASES.append({'name':name,'source':PRE+models+uses_for(extra+body)+extra+body+'\n','pairs':pairs,'classification':classification,'native':compile_native})

add('diagonal_bound', ''.join('function read%d(): Factory { const r: Maker = new M%d(); return r.make.bind(r); } use%d(read%d());\n'%(i,i,i,i) for i in range(3)), [('M%d'%i,'C%d'%i) for i in range(3)])
add('shared_bound_ast', 'const a = read(new M0("a")); const b = read(new M1("b")); use0(a); use1(b); use1(a); use0(b);', [('M%d'%i,'C%d'%j) for i in range(2) for j in range(2)], READ)
add('capture_same_class_distinct_objects', 'const a = read(new M0("a")); const b = read(new M0("b")); use0(a); use1(b); use1(a); use0(b);', [('M0','C0'),('M0','C1')], READ)
add('capture_survives_field_mutation', 'const r = new M0("before"); const a = read(r); r.label = "after"; use0(a); use1(a);', [('M0','C0'),('M0','C1')], READ)
add('returned_receiver_alias', 'use0(read(alias()));', [('M1','C0')], READ+'function construct(): Maker { return new M1(); } const alias = construct;\n')
add('all_return_arms', 'use0(read(construct()));', [('M0','C0'),('M1','C0')], READ+'function construct(): Maker { try { return new M0(); } finally { if (choose()) return new M1(); } }\n')
add('unknown_return_arm', 'use0(read(construct()));', [('M%d'%i,'C0') for i in range(3)], READ+'const held: any[] = [new M1()]; function construct(): Maker { if (choose()) return new M0(); return held[0]; }\n')
add('mutable_capture', 'let r: Maker = new M0(); function change(): void { r = new M1(); } change(); use0(read(r));', [('M%d'%i,'C0') for i in range(3)], READ)
add('unknown_capture', 'const held: any[] = [new M1()]; const checked: Maker = held[0]; use0(read(checked));', [('M%d'%i,'C0') for i in range(3)], READ)
add('destructured_interface', 'use0(read(new M1()));', [('M%d'%i,'C0') for i in range(3)], 'function read(receiver: Maker): Factory { const { make } = receiver; return make.bind(receiver); }\n')
add('destructured_class', 'use0(read(new M1()));', [('M%d'%i,'C0') for i in range(3)], 'function read(receiver: M0): Factory { const { make } = receiver; return make.bind(receiver); }\n')
add('generic_lexical_alias', 'const factory = outer(1); use0(factory);', [('M%d'%i,'C0') for i in range(3)], 'const receiver: Maker = new M0(); function outer<U>(marker: U): Factory { console.log(marker); return receiver.make.bind(receiver); }\n')
add('contextual_generic_alias', 'const factory = outer(1); use0(factory);', [('M%d'%i,'C0') for i in range(3)], 'const receiver: Maker = new M0(); const outer: <U>(marker: U) => Factory = marker => { console.log(marker); return receiver.make.bind(receiver); };\n', classification='preexisting-c255-or-match')
add('generic_class_alias', 'const factory = new Holder(1).read(); use0(factory);', [('M%d'%i,'C0') for i in range(3)], 'const receiver: Maker = new M0(); class Holder<U> { constructor(public marker: U) {} read(): Factory { console.log(this.marker); return receiver.make.bind(receiver); } }\n')
add('lexically_shared_nested_factory', 'const a = outer(new M0("a")); const b = outer(new M1("b")); use0(a()); use1(b()); use1(a());', [('M%d'%i,'C%d'%j) for i in range(2) for j in range(2)], 'function outer(receiver: Maker): () => Factory { function inner(): Factory { return receiver.make.bind(receiver); } return inner; }\n')
BASEMODELS = '''class Base { calls = 0; constructor(public label: string = "base") {} make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
'''+''.join('class M%d extends Base { make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }\n'%i for i in range(3))
REBIND = 'function rebind(lookup: Base, receiver: Base): Factory { return lookup.make.bind(receiver); }\n'
add('bind_different_thisarg', 'const f = rebind(new M0("lookup"), new M1("captured")); use0(f); use1(f);', [('M1','C0'),('M1','C1')], REBIND, BASEMODELS)
add('bind_unknown_lookup_known_thisarg', 'const held: any[] = [new M0("lookup")]; use0(rebind(held[0], new M1("captured")));', [('M1','C0')], REBIND, BASEMODELS)
add('bind_known_lookup_unknown_thisarg', 'const held: any[] = [new M1("captured")]; use0(rebind(new M0("lookup"), held[0]));', [('M%d'%i,'C0') for i in range(3)], REBIND, BASEMODELS)
add('bind_shared_args', 'const a = rebind(new M0("lookup"), new M1("a")); const b = rebind(new M0("lookup"), new M2("b")); use0(a); use1(b);', [('M%d'%i,'C%d'%j) for i in (1,2) for j in range(2)], REBIND, BASEMODELS)
add('bind_chain_preserves_first_receiver', 'const a = rebind(new M0("lookup"), new M1("first")).bind(new M2("ignored")); use0(a); use1(a);', [('M1','C0'),('M1','C1')], REBIND, BASEMODELS)
add('bind_returned_thisarg', 'use0(rebind(new M0("lookup"), makeReceiver()));', [('M2','C0')], REBIND+'function makeReceiver(): Base { return new M2("returned"); }\n', BASEMODELS)
add('bind_conditional_thisarg', 'use0(rebind(new M2("lookup"), choose() ? new M0("a") : new M1("b")));', [('M0','C0'),('M1','C0')], REBIND, BASEMODELS)
INHERITED = '''class M0 implements Maker { calls = 0; make<T>(value: T): Box<T> { this.calls++; return new Box(value, "parent/" + this.calls); } }
class M1 extends M0 {} class M2 extends M0 { make<T>(value: T): Box<T> { return new Box(value, "override"); } }
'''
add('inherited_implementation', 'use0(read(new M1()));', [('M0','C0')], READ, INHERITED)
add('overridden_implementation', 'use0(read(new M2()));', [('M0','C0'),('M2','C0')], READ, INHERITED)
BAD = '''class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value, "parent"); } }
class M1 extends M0 { make<T>(value: T): Box<T> { return new Box<any>("wrong", "override") as any; } }
class M2 extends M0 { make<T>(value: T): Box<T> { return new Box(value, "other"); } }
'''
add('override_barrier', 'use0(read(new M1()));', None, READ, BAD, classification='checked-any-override')
for target in ('(receiver as any)', '(<any>receiver)', 'receiver!'):
    name = {'(receiver as any)':'asserted', '(<any>receiver)':'typeasserted', 'receiver!':'nonnull'}[target]
    add('parameter_write_'+name, 'use0(read(new M0()));', None, 'function read(receiver: Maker): Factory { '+target+' = new M1(); return receiver.make.bind(receiver); }\n', classification='unsupported-assignment-or-match')
add('proof_depth_exhaustion', 'use0(read());', [('M%d'%i,'C0') for i in range(3)], 'function read(): Factory { const r0: Maker = new M1(); '+''.join('const r%d = r%d; '%(i,i-1) for i in range(1,141))+'return r140.make.bind(r140); }\n')
add('proof_work_exhaustion', 'use0(read(construct()));', [('M%d'%i,'C0') for i in range(3)], READ+'function construct(): Maker { let n = 0; '+('n++; '*1500)+'return new M1(); }\n')

if len(sys.argv) > 1 and sys.argv[1] == 'prepare':
    for case in CASES:
        (ROOT/'inputs'/(case['name']+'.pts')).write_text(case['source'])
    (ROOT/'raw/matrix-manifest.json').write_text(json.dumps(CASES,indent=2)+'\n')
    print('prepared',len(CASES),'cases')
    raise SystemExit(0)
results = []
for case in CASES:
    name = case['name']
    source = ROOT/'inputs'/(name+'.pts')
    source.write_text(case['source'])
    mts = source.with_suffix('.mts')
    mts.write_text(case['source'])
    node = run(['/home/bryan/.local/node/bin/node','--no-warnings','--experimental-transform-types',mts])
    row = {'name':name,'classification':case['classification'],'node':node,'versions':{}}
    for version in ('base','current'):
        cfile = ROOT/'raw'/(name+'.'+version+'.c')
        binary = ROOT/'bin'/(name+'.'+version)
        helper = pathlib.Path(os.environ.get('D207_'+version.upper()+'_HELPER', str(ROOT/'bin'/version)))
        emitted = run([helper,source,cfile,binary if case['native'] else '-'])
        item = {'emit':emitted}
        if cfile.exists():
            c = cfile.read_text()
            present = sorted(set(re.findall(r'\bpts_fn_(M[012])_make_(C[012])\(',c)))
            registered = sorted(set(re.findall(r'return pts_fn_(M[012])_make_(C[012])\(',c)))
            item.update(pairs=present, registered=registered, c_lines=len(c.splitlines()), c_bytes=len(c.encode()))
            if version == 'current' and case['pairs'] is not None:
                expected = sorted(case['pairs'])
                item['pair_check'] = present == expected and registered == expected
                item['expected_pairs'] = expected
        if emitted['exit'] == 0 and case['native']:
            native = run([binary],30)
            item['native'] = native
            item['matches_node'] = native['exit'] == node['exit'] == 0 and native['stdout'] == node['stdout']
        binary.unlink(missing_ok=True)
        row['versions'][version] = item
    results.append(row)
    (ROOT/'raw/matrix-results.json').write_text(json.dumps(results,indent=2)+'\n')
    (ROOT/'raw/matrix-commands.json').write_text(json.dumps(COMMANDS,indent=2)+'\n')
    a,b = row['versions']['base'],row['versions']['current']
    print(name, 'base=',a['emit']['exit'],a.get('matches_node'), 'current=',b['emit']['exit'],b.get('matches_node'), 'pairs=',b.get('pair_check'),flush=True)
print('cases',len(results),'current_pair_failures',sum(r['versions']['current'].get('pair_check') is False for r in results))
