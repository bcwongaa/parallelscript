import hashlib,json,os,pathlib,re,subprocess,time
ROOT=pathlib.Path(os.environ.get('D207_REVIEW_ROOT','/tmp/pts-d207-review-ab25'))
WT=pathlib.Path(os.environ.get('D207_REVIEW_WORKTREE','/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25'))
ENV=dict(os.environ,GOMAXPROCS='1',PTS_HOME='/home/bryan/projects/parallelscript')
results=[]
for known,count in [(True,24),(False,12)]:
 name='growth_'+('known' if known else 'unknown')+str(count)
 lines=['class Box<T> { constructor(public value: T) {} }','interface Maker { make<T>(value: T): Box<T>; }','type Factory = <T>(value: T) => Box<T>;']
 for i in range(count):
  lines+=['class C%d { tag = %d; }'%(i,i),'class M%d implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }'%i]
 if not known:lines+=['const held: any[] = ['+', '.join('new M%d()'%i for i in range(count))+'];']
 for i in range(count):
  receiver='new M%d()'%i if known else 'held[%d]'%i
  lines+=['function read%d(): Factory { const receiver: Maker = %s; return receiver.make.bind(receiver); }'%(i,receiver),'function use%d(f: Factory): void { const box: Box<C%d> = f(new C%d()); console.log(box.value.tag); }'%(i,i,i),'use%d(read%d());'%(i,i)]
 source=ROOT/'inputs'/(name+'.pts');source.write_text('\n'.join(lines)+'\n')
 row={'name':name,'count':count,'known':known,'versions':{}}
 for v in ['base','current']:
  helper=pathlib.Path(os.environ.get('D207_'+v.upper()+'_HELPER',str(ROOT/'bin'/v)))
  c=ROOT/'raw'/(name+'.'+v+'.c');args=[str(helper),str(source),str(c),'-'];start=time.monotonic()
  p=subprocess.run(args,cwd=WT,env=ENV,capture_output=True,text=True,timeout=180)
  r={'command':args,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':round(time.monotonic()-start,3)}
  if c.exists():
   data=c.read_bytes();text=data.decode();r.update(bytes=len(data),lines=len(text.splitlines()),sha256=hashlib.sha256(data).hexdigest())
   r['pairs']=sorted(set(re.findall(r'\bpts_fn_(M\d+)_make_(C\d+)\(',text)));r['registered']=sorted(set(re.findall(r'return pts_fn_(M\d+)_make_(C\d+)\(',text)))
   expected=sorted(('M%d'%i,'C%d'%j) for i in range(count) for j in range(count) if v=='base' or not known or i==j)
   r['pair_check']=r['pairs']==expected and r['registered']==expected
  row['versions'][v]=r
 row['byte_identical']=all(x['exit']==0 for x in row['versions'].values()) and row['versions']['base']['sha256']==row['versions']['current']['sha256']
 results.append(row);(ROOT/'raw/growth-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,[(v,r['exit'],len(r.get('pairs',[])),r.get('pair_check'),r.get('lines')) for v,r in row['versions'].items()],'identical=',row['byte_identical'],flush=True)
