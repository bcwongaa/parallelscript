import hashlib,json,pathlib,shutil,subprocess
ROOT=pathlib.Path('/tmp/pts-d207-review-ab25')
R2=ROOT/'round2'
SNAP=pathlib.Path('/tmp/pts-h09b5c2b2b2-rHJnXz/review-snapshot-r2')
WT=pathlib.Path('/home/bryan/projects/parallelscript/.claude/worktrees/review-d207-ab25')
for d in ['snapshot','inputs','raw','bin']: (R2/d).mkdir(parents=True,exist_ok=True)
expected=json.loads((SNAP/'sha256.json').read_text());replace={};base_tests={};base_hashes={}
for relative,digest in expected.items():
 data=(SNAP/relative).read_bytes();actual=hashlib.sha256(data).hexdigest();assert actual==digest,(relative,actual,digest)
 target=R2/'snapshot'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 if relative.endswith('.go'):replace[str(WT/relative)]=str(target)
 if relative.endswith('_test.go') and 'captured_receiver_write_sources_test.go' not in relative:base_tests[str(WT/relative)]=str(target)
 if relative.endswith('.pts'):(R2/'inputs'/pathlib.Path(relative).name).write_bytes(data)
 if relative.endswith('.go') and not relative.endswith('_test.go'):
  base=subprocess.check_output(['git','-C',str(WT),'show','be71aac86:'+relative]);assert base==(WT/relative).read_bytes();base_hashes[relative]=hashlib.sha256(base).hexdigest()
for name in ['review_mutation_test.go','review_seam_test.go']:
 replace[str(WT/'pts/lower'/('review_d207_'+name))]=str(ROOT/'tests'/name)
original=dict(replace);original.pop(str(WT/'pts/lower/outside_assignments.go'))
for name,r in [('current.json',replace),('original-index.json',original),('base-final-tests.json',base_tests)]:
 (R2/name).write_text(json.dumps({'Replace':r},indent=2)+'\n')
(R2/'snapshot/production.patch').write_bytes((SNAP/'production.patch').read_bytes())
(R2/'snapshot/sha256.json').write_bytes((SNAP/'sha256.json').read_bytes())
(R2/'raw/reviewed-hashes.json').write_text(json.dumps({'base':'be71aac86','base_sha256':base_hashes,'snapshot_sha256':expected},indent=2)+'\n')
shutil.copyfile(ROOT/'bin/base',R2/'bin/base');(R2/'bin/base').chmod(0o700)
print(json.dumps({'round2':str(R2),'verified_files':len(expected),'production_files':len(base_hashes),'hashes':expected}))
