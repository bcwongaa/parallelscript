import hashlib,io,json,pathlib,stat,tarfile
ROOT=pathlib.Path('/tmp/pts-d207-review-ab25')
OUT=pathlib.Path('/tmp/pts-d207-review-ab25-final.tar.gz')
files=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_dir():continue
 rel=p.relative_to(ROOT)
 if 'bin' in rel.parts:continue
 st=p.lstat()
 if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:raise RuntimeError('non-regular or linked source '+str(p))
 data=p.read_bytes()
 if data.startswith(b'\x7fELF'):raise RuntimeError('ELF '+str(p))
 data.decode('utf-8')
 name='pts-d207-review-ab25/'+rel.as_posix()
 if pathlib.PurePosixPath(name).is_absolute() or '..' in pathlib.PurePosixPath(name).parts:raise RuntimeError(name)
 files.append((name,data))
manifest=json.dumps([{'name':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in files],indent=2).encode()+b'\n'
pathlib.Path('/tmp/pts-d207-review-ab25-manifest.json').write_bytes(manifest)
files.append(('pts-d207-review-ab25/archive-members.json',manifest))
with tarfile.open(OUT,'w:gz') as t:
 for name,data in files:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.type=tarfile.REGTYPE;info.uid=info.gid=0;info.mtime=0
  t.addfile(info,io.BytesIO(data))
with tarfile.open(OUT,'r:gz') as t:
 for m in t.getmembers():
  if not m.isfile() or m.issym() or m.islnk():raise RuntimeError('unsafe member '+m.name)
  data=t.extractfile(m).read();data.decode('utf-8')
  if data.startswith(b'\x7fELF'):raise RuntimeError('ELF member '+m.name)
print(json.dumps({'archive':str(OUT),'members':len(files),'bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),'regular_utf8_only':True}))
