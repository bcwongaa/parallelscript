import hashlib
import json
from pathlib import PurePosixPath
import sys
import tarfile


def main():
    archive = sys.argv[1]
    with tarfile.open(archive, "r:gz") as bundle:
        members = bundle.getmembers()
        by_name = {}
        for member in members:
            path = PurePosixPath(member.name)
            if path.is_absolute() or ".." in path.parts:
                raise SystemExit("unsafe archive path: " + member.name)
            if not (member.isfile() or member.isdir()):
                raise SystemExit("non-regular archive entry: " + member.name)
            name = str(path)
            if name in by_name:
                raise SystemExit("duplicate archive entry: " + member.name)
            by_name[name] = member
            if member.isfile() and (name == "pts" or name.endswith(".bin") or name.endswith(".tar.gz")):
                raise SystemExit("excluded binary/archive entry: " + member.name)
        manifest = json.loads(bundle.extractfile(by_name["manifest.json"]).read())
        for source in manifest["files"]:
            content = bundle.extractfile(by_name[source["path"]]).read()
            digest = hashlib.sha256(content).hexdigest()
            if digest != source["sha256"]:
                raise SystemExit("source hash mismatch: " + source["path"])
            patch = bundle.extractfile(by_name[source["patch"]]).read().decode()
            added = "\n".join(line[1:] for line in patch.splitlines() if line.startswith("+") and not line.startswith("+++")) + "\n"
            if added.encode() != content:
                raise SystemExit("patch content mismatch: " + source["patch"])
        regular = sum(member.isfile() for member in members)
        print(json.dumps({"status": "safe", "entries": len(members), "regular_files": regular, "source_and_patch_hashes_verified": len(manifest["files"])}))


if __name__ == "__main__":
    main()
