// Review H09b5b r2: a value pairing (ValueInstances' level) whose demand is in code only a demand
// by name makes. Bad.make<T> (paired speculatively with m.make's demand; m is never a Bad) calls
// use(w), and use's demand for Dog[] pairs with the escaping arrow w, whose instance makes
// Weird<Dog[]>, whose method doesn't lower (D-094) after the trial. The failure is blamed on that
// value pairing, level ValueInstances, which ValueInstances never makes (Bad.make<number> isn't
// made there), so Within fails and the build falls back to ValueInstances as on the base, and
// the unrelated interface call loses its instance; leaving out Bad.make's pairing would do.
class Box<T> {
  constructor(public value: T) {}
}
class Animal {
  name = "a";
}
class Dog extends Animal {
  bark = 1;
}
class Weird<T> {
  constructor(public value: T) {}
  animals(): Animal[] {
    const v = this.value;
    if (Array.isArray(v)) {
      return v;
    }
    return [];
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Good implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function useDogs(f: <T>(x: T) => Box<T>): number {
  const b: Box<Dog[]> = f([new Dog()]);
  return b.value.length;
}
class Bad implements Maker {
  make<T>(x: T): Box<T> {
    const w = <U,>(u: U): Weird<U> => new Weird(u);
    const d: any = w;
    console.log("bad", d(x).animals().length, useDogs(<V,>(v: V): Box<V> => new Box(v)));
    return new Box(x);
  }
}
const makers: Maker[] = [new Good(), new Bad()];
const m: Maker = makers[0];
console.log("by name", m.make(4).value + 1);
