class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(value: T): Box<T>;
}
type RestFactory = <T>(optional?: number, ...values: T[]) => Box<T[]>;
function maybe(): number | undefined {
  return undefined;
}
class Late<T> {
  constructor(public value: T) {}
  factory: RestFactory = <U,>(optional?: number, ...values: U[]): Box<U[]> => new Box(values);
  unused(): void {
    const f = this.factory;
    const box: Box<T[]> = f(maybe(), this.value);
    console.log("late", box.value.length);
  }
}
class Good implements Maker {
  make<T>(value: T): Box<T> {
    return new Box(value);
  }
}
class Bad implements Maker {
  make<T>(value: T): Box<T> {
    const late = new Late(value);
    return new Box(late.value);
  }
}
const makers: Maker[] = [new Good(), new Bad()];
const maker: Maker = makers[0];
console.log("by name", maker.make(4).value + 1);
