import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def run_command(command, cwd, env, prefix, timeout):
    started = time.monotonic()
    try:
        result = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=timeout)
        code = result.returncode
        stdout, stderr = result.stdout, result.stderr
    except subprocess.TimeoutExpired as error:
        code = "timeout"
        stdout, stderr = error.stdout or b"", error.stderr or b""
    Path(str(prefix) + ".stdout").write_bytes(stdout)
    Path(str(prefix) + ".stderr").write_bytes(stderr)
    return {"command": [str(arg) for arg in command], "cwd": str(cwd), "env": {name: env[name] for name in ("GOMAXPROCS", "GOFLAGS", "PTS_HOME", "PTS_THREADS")}, "exit_code": code, "seconds": time.monotonic() - started, "stdout": stdout.decode(errors="replace"), "stderr": stderr.decode(errors="replace")}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--pts", type=Path, required=True)
    parser.add_argument("--node", type=Path, required=True)
    parser.add_argument("--worktree", type=Path, required=True)
    parser.add_argument("--runtime-home", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("sources", type=Path, nargs="+")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    env = os.environ.copy()
    env.update(GOMAXPROCS="1", GOFLAGS="-p=1", PTS_HOME=str(args.runtime_home or args.worktree), PTS_THREADS="1")
    receipts = []
    for source in args.sources:
        source = source.resolve()
        name = source.stem
        node_source = args.output / (name + ".mts")
        node_source.write_bytes(source.read_bytes())
        binary = args.output / (name + ".bin")
        receipt = {"source": str(source), "sha256": hashlib.sha256(source.read_bytes()).hexdigest()}
        receipt["node"] = run_command([args.node, "--no-warnings", "--experimental-transform-types", node_source], args.worktree, env, args.output / (name + ".node"), 20)
        receipt["build"] = run_command([args.pts, "build", source, "-o", binary], args.worktree, env, args.output / (name + ".build"), 120)
        if receipt["build"]["exit_code"] == 0:
            receipt["native"] = run_command([binary], args.worktree, env, args.output / (name + ".native"), 20)
            binary.unlink()
        receipt["matches_node"] = receipt.get("native", {}).get("stdout") == receipt["node"]["stdout"] and receipt.get("native", {}).get("exit_code") == receipt["node"]["exit_code"]
        receipts.append(receipt)
        print(json.dumps(receipt), flush=True)
    (args.output / "receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")


if __name__ == "__main__":
    main()
