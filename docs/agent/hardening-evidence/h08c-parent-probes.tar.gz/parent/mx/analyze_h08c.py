#!/usr/bin/env python3
"""analyze_h08c.py MATRIXDIR: labels every case of a plain-mode sync/const run with its cause
and writes analysis.txt (counts by site and by kind, then every case not OK with its label).

Labels, for a case whose sync line differs from Node's:
  C153        a PTS line has "Cannot spread … into the arguments of a call through `any`"
  C152        the const control is OK and the sync value is Node's "pre" value (causes.json
              LATE: the spread read what the later operand left), or the site is "array
              literal, two spreads", whose second spread `...ys` is the array the later operand
              pushes to (its first spread may be of any kind)
  D-085       holes of a number[] read 0 (the const control too)
  C154        a tuple's optional element left out is passed as undefined (the const control too)
  C148        a literal-typed computed key is never evaluated (the const control too)
  OTHER       none of these (listed in full)
DIAG/ICE/TSERR cases are labelled with their verdict and grouped by message."""
import collections
import json
import os
import re
import sys

matrix = sys.argv[1]
results = json.load(open(os.path.join(matrix, "results.json")))["results"]
causes = json.load(open(os.path.join(matrix, "causes.json")))


def label(cid, r):
    sync, const = r["sync"], r["const"]
    v = sync["verdict"]
    if v == "OK":
        return "OK" if const["verdict"] == "OK" else f"OK(const {const['verdict']})"
    if v != "WRONG":
        return v
    lines = " ".join(sync.get("pts") or [])
    d = r["dims"]
    if "Cannot spread" in lines:
        return "C153"
    if const["verdict"] == "OK":
        if causes.get(cid, {}).get("label") == "LATE" or d["site"] == "array literal, two spreads":
            return "C152"
        return "OTHER"
    if d["kind"] == "holes number[]":
        return "D-085"
    if d["kind"] == "tuple [number, number?]":
        return "C154"
    if d["site"] == "{ ...o, [key()]: S }":
        return "C148"
    return "OTHER"


labels = {cid: label(cid, r) for cid, r in results.items()}
out = []
total = collections.Counter(labels.values())
out.append(f"cases: {len(results)}  " + "  ".join(f"{k}={v}" for k, v in sorted(total.items())))
for key in ("site", "kind", "mut"):
    by = collections.defaultdict(collections.Counter)
    for cid, r in results.items():
        by[(r["dims"]["family"], r["dims"][key])][labels[cid]] += 1
    out.append(f"\nby family and {key}:")
    for k in sorted(by):
        out.append(f"  {k[0]:7s} {k[1]:48s} " + "  ".join(f"{v}={c}" for v, c in sorted(by[k].items())))

# C153 by kind, and what the const twin says
out.append("\nC153 cases by site and kind (the message the base throws):")
c153 = collections.defaultdict(list)
for cid, r in results.items():
    if labels[cid] == "C153":
        m = re.search(r"Cannot spread (.*?) into", " ".join(r["sync"]["pts"]))
        c153[(r["dims"]["site"], r["dims"]["kind"])].append(m.group(1) if m else "?")
for k in sorted(c153):
    out.append(f"  {k[0]:36s} {k[1]:36s} {len(c153[k])}  ({', '.join(sorted(set(c153[k])))})")

# DIAG/ICE/TSERR grouped by message (case numbers and line numbers stripped)
out.append("\nDIAG / ICE / TSERR by message:")
msgs = collections.Counter()
for cid, r in results.items():
    if labels[cid] in ("DIAG", "ICE", "TSERR"):
        text = re.sub(r"_\d+", "_N", r["sync"].get("pts") or "")
        text = re.sub(r"\(line \d+\)", "", text)
        msgs[(labels[cid], text[:200])] += 1
for (v, text), n in sorted(msgs.items(), key=lambda x: -x[1]):
    out.append(f"  {v:5s} {n:4d}  {text}")

out.append("\nevery OTHER case:")
for cid in sorted(results, key=lambda c: results[c]["n"]):
    if labels[cid] == "OTHER":
        r = results[cid]
        out.append(f"  c{r['n']} {cid}")
        out.append(f"      pts:   {r['sync'].get('pts')}")
        out.append(f"      node:  {r['sync'].get('node')}")
        out.append(f"      const: {r['const']['verdict']} {r['const'].get('pts')}")
        out.append(f"      pre:   {causes.get(cid, {}).get('pre')}")
json.dump(labels, open(os.path.join(matrix, "labels.json"), "w"), indent=1)
open(os.path.join(matrix, "analysis.txt"), "w").write("\n".join(out) + "\n")
print("\n".join(out[:1]))
