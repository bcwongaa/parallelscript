#!/usr/bin/env python3
"""H08c's copy of H08b's matrix (C152, C153). H08c adds, without changing any H08b cell:
  - a `plain` mode: the case's statement in a plain function (no generator, no async), so
    the `sync` variant is C152's RED without any suspension machinery around it;
  - MODES (gen) and VARIANTS (run) environment filters: H08c runs MODES=plain and
    VARIANTS=sync,const (the `real` variant has no meaning in plain mode);
  - element kinds for C153 (values held in `any`: a string, a generator object, a map, a
    map iterator, an object-literal iterable, a tuple, a typed array) and a `clear`
    mutation (the later operand empties the array);
  - plain-mode-only sites: Math.hypot, String.fromCodePoint, super(...), a generic method,
    a union's method, new Float64Array([...]), Array.from([...]), `new` through any, and
    the same spread again after the mutation, which must see it (rest fn, any fn, console.log).
  - summarize_sync / classify_sync for runs without the real variant.
Original docstring follows.

H08b differential matrix: spreads before a suspension (C139).

Each case is one statement in a generator (`yield`, driven by a loop that mutates the
spread's source while the generator is suspended) or an async function (`await`, where a
microtask queued just before the await mutates the source before the await resumes). The
statement holds a spread (`...S`) that JS evaluates before the suspension SUSP in a later
operand (or, for guards, after it). The case function returns a string; the driver prints
`{{id}} trace => result`, where the trace shows the logs of getters, iterators, generator
bodies and calls, and "susp"/"mut" for the suspension and the mutation.

Every case has three variants, all generated from the same parts:
  real   SUSP is `(yield 0)` / `(await ten(mut_n))`
  sync   SUSP is `now(mut_n)`: logs "susp","mut", runs the mutation, gives 10, without a
         suspension. JS evaluates the spread before it too, so Node prints exactly the
         real variant's line (checked: NODE-ASYM otherwise). PTS's sync line tells
         whether its order without a suspension is right.
  const  SUSP is `(10)`: no suspension and no mutation (the plain control twin).
A WRONG real case whose const and sync controls are OK is suspension-specific.

Usage:
  python3 -I matrix.py gen OUTDIR           writes OUTDIR/manifest.json
  python3 -I matrix.py run OUTDIR [JOBS]     builds/runs everything; results.json, summary.txt
  python3 -I matrix.py summarize OUTDIR
Deterministic: the grid is exhaustive over the tables below (no randomness; the "seed" is
the table order, which fixes every case number).
Env: PTS_CLI, PTS_HOME (default: this worktree's base CLI).
"""
import collections
import concurrent.futures
import json
import os
import re
import shutil
import subprocess
import sys

WORKTREE = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ada8309aafb8cc260"
CLI = os.environ.get("PTS_CLI", WORKTREE + "/pts-bin/pts")
HOME = os.environ.get("PTS_HOME", WORKTREE)
NODE = os.path.expanduser("~/.local/node/bin/node")
MODES = tuple(os.environ.get("MODES", "yield,await").split(","))  # H08c: gen's modes (plain, yield, await)
VARIANTS = tuple(os.environ.get("VARIANTS", "real,sync,const").split(","))  # H08c: run's variants

PRELUDE = """\
const trace: string[] = [];
const log = (s: string): void => { trace.push(s); };
const ten = (m: () => void): Promise<number> => {
  log("susp");
  queueMicrotask(() => { log("mut"); m(); });
  return Promise.resolve(10);
};
const now = (m: () => void): number => { log("susp"); log("mut"); m(); return 10; };
const report = (name: string, value: string): void => {
  console.log("{{" + name + "}} " + trace.join(",") + " => " + value);
  trace.length = 0;
};
interface V { v: number }
const ob = (n: number): V => ({ v: n });
const pr = (n: number): [number, number] => [n, n];
const codes = (s: string): string => {
  const r: number[] = [];
  for (let i = 0; i < s.length; i++) r.push(s.charCodeAt(i));
  return r.join("/");
};
"""

# Element types: TS type, how one element prints (x), the suspension's value as one, a
# value for an element written before the spread, and one for a second spread's array.
ETYPES = {
    "num": dict(ts="number", fmt="String(x)", val="SUSP", zero="0", z2="7"),
    "unum": dict(ts="number | undefined", fmt="String(x)", val="SUSP", zero="0", z2="7"),
    "ns": dict(ts="number | string", fmt="String(x)", val="SUSP", zero="0", z2="7"),
    "str": dict(ts="string", fmt="x", val="String(SUSP)", zero='"s"', z2='"q"'),
    "pair": dict(ts="[number, number]", fmt='x[0] + ":" + x[1]', val="pr(SUSP)", zero="pr(0)", z2="pr(7)"),
    "obj": dict(ts="V", fmt='"v" + x.v', val="ob(SUSP)", zero="ob(0)", z2="ob(7)"),
}

ITER_CLASS = ("class It_N implements Iterable<number> {\n  items = [1, 2];\n"
              "  *[Symbol.iterator](): Iterator<number> {\n    log(\"iter\");\n"
              "    for (const x of this.items) yield x;\n  }\n}\n")
GEN_FN = ("const src_N = [1, 2];\nfunction* gen_N(): Generator<number> {\n  log(\"gen\");\n"
          "  for (const x of src_N) yield x;\n}\n")


def K(name, etype, decl, sp, muts, **kw):
    return dict(name=name, etype=etype, decl=decl, sp=sp, muts=muts, **kw)


# Element kinds: decl (module scope, N is the case number), the spread text, mutations
# (name -> statements run while suspended). tuple= gives fixed-parameter and tuple-literal
# shapes for tuples.
ELEMENT_KINDS = [
    K("number[]", "num", "const xs_N: number[] = [1, 2];", "...xs_N",
      {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;", "pop": "xs_N.pop();"}),
    K("readonly number[]", "num", "const xw_N: number[] = [1, 2];\nconst xs_N: readonly number[] = xw_N;", "...xs_N",
      {"push": "xw_N.push(100);", "write": "xw_N[0] = -5;"}),
    K("let number[] reassigned", "num", "let xs_N: number[] = [1, 2];", "...xs_N",
      {"reassign": "xs_N = [7, 8, 9];"}),
    K("number[] property", "num", "const h_N = { xs: [1, 2] };", "...h_N.xs",
      {"push": "h_N.xs.push(100);", "write": "h_N.xs[0] = -5;", "reassign": "h_N.xs = [7, 8, 9];"}),
    K("number[] from call", "num", "const xs_N = [1, 2];\nconst get_N = (): number[] => { log(\"get\"); return xs_N; };", "...get_N()",
      {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;"}),
    K("holes (number|undefined)[]", "unum",
      "const xs_N = new Array<number | undefined>(3);\nxs_N[0] = 1;\nxs_N[2] = 3;", "...xs_N",
      {"fill hole": "xs_N[1] = 7;", "push": "xs_N.push(100);"}),
    K("holes number[]", "num", "const xs_N = new Array<number>(3);\nxs_N[0] = 1;\nxs_N[2] = 3;", "...xs_N",
      {"fill hole": "xs_N[1] = 7;"}),
    K("V[] (objects)", "obj", "const xs_N: V[] = [{ v: 1 }, { v: 2 }];", "...xs_N",
      {"push": "xs_N.push({ v: 100 });", "replace": "xs_N[0] = { v: -5 };"}),
    K("Set<V> (objects)", "obj", "const xs_N = new Set<V>([{ v: 1 }, { v: 2 }]);", "...xs_N",
      {"add": "xs_N.add({ v: 100 });"}),
    K("tuple [number, number]", "num", "const xs_N: [number, number] = [1, 2];", "...xs_N",
      {"write": "xs_N[0] = -5;"},
      tuple=dict(g="(a: number, b: number, z: number): string => [a, b, z]", tt="number, number")),
    K("tuple [number, ...number[]]", "num", "const xs_N: [number, ...number[]] = [1, 2];", "...xs_N",
      {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;"},
      tuple=dict(g="(a: number, ...rest: number[]): string => [a, ...rest]", tt="number, ...number[]")),
    K("tuple [number, number?]", "unum", "const xs_N: [number, number?] = [1];", "...xs_N",
      {"write": "xs_N[1] = 7;", "write first": "xs_N[0] = -5;"},
      tuple=dict(g="(a: number, b?: number, z?: number): string => [a, b, z]", tt="number, number?", optional=True)),
    K("tuple [number, string]", "ns", "const xs_N: [number, string] = [1, \"b\"];", "...xs_N",
      {"write": "xs_N[0] = -5;", "write string": "xs_N[1] = \"w\";"},
      tuple=dict(g="(a: number, b: string, z: number): string => [a, b, z]", tt="number, string")),
    K("tuple literal [1, 2] as const", "num", "", "...([1, 2] as const)", {"none": ""}, guard=True),
    K("Set<number>", "num", "const xs_N = new Set([1, 2]);", "...xs_N",
      {"add": "xs_N.add(100);", "delete": "xs_N.delete(1);"}),
    K("set.values()", "num", "const xs_N = new Set([1, 2]);", "...xs_N.values()",
      {"add": "xs_N.add(100);", "delete": "xs_N.delete(1);"}),
    K("set.keys()", "num", "const xs_N = new Set([1, 2]);", "...xs_N.keys()", {"add": "xs_N.add(100);"}),
    K("map.keys()", "num", "const m_N = new Map([[1, 10], [2, 20]]);", "...m_N.keys()",
      {"set": "m_N.set(100, 1000);", "delete": "m_N.delete(1);"}),
    K("map.values()", "num", "const m_N = new Map([[1, 10], [2, 20]]);", "...m_N.values()",
      {"set": "m_N.set(100, 1000);", "overwrite": "m_N.set(1, -5);"}),
    K("arr.keys()", "num", "const xs_N = [1, 2];", "...xs_N.keys()", {"push": "xs_N.push(100);"}),
    K("arr.values()", "num", "const xs_N = [1, 2];", "...xs_N.values()",
      {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;"}),
    K("user iterable class", "num", ITER_CLASS + "const xs_N = new It_N();", "...xs_N",
      {"push": "xs_N.items.push(100);", "write": "xs_N.items[0] = -5;"}),
    K("object literal iterable", "num",
      "const xs_N = {\n  items: [1, 2],\n  *[Symbol.iterator](): Iterator<number> {\n    log(\"iter\");\n"
      "    for (const x of this.items) yield x;\n  },\n};", "...xs_N",
      {"push": "xs_N.items.push(100);"}),
    K("generator call", "num", GEN_FN, "...gen_N()", {"push": "src_N.push(100);", "write": "src_N[0] = -5;"}),
    K("generator object variable", "num", GEN_FN + "const go_N = gen_N();", "...go_N", {"push": "src_N.push(100);"}),
    K("Float64Array", "num", "const xs_N = new Float64Array([1, 2]);", "...xs_N", {"write": "xs_N[0] = -5;"}),
    K("Int32Array", "num", "const xs_N = new Int32Array([1, 2]);", "...xs_N", {"write": "xs_N[0] = -5;"}),
    K("Uint8Array", "num", "const xs_N = new Uint8Array([1, 2]);", "...xs_N", {"write": "xs_N[0] = 250;"}),
    K("Float64Array.values()", "num", "const xs_N = new Float64Array([1, 2]);", "...xs_N.values()", {"write": "xs_N[0] = -5;"}),
    K("Iterable<number> of array", "num", "const w_N = [1, 2];\nconst xs_N: Iterable<number> = w_N;", "...xs_N",
      {"push": "w_N.push(100);", "write": "w_N[0] = -5;"}),
    K("Iterable<number> of Set", "num", "const w_N = new Set([1, 2]);\nconst xs_N: Iterable<number> = w_N;", "...xs_N",
      {"add": "w_N.add(100);"}),
    K("any array", "num", "const xs_N: any = [1, 2];", "...xs_N", {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;"}),
    K("any Set", "num", "const xs_N: any = new Set([1, 2]);", "...xs_N", {"add": "xs_N.add(100);"}),
    K("any user iterable", "num", ITER_CLASS + "const xs_N: any = new It_N();", "...xs_N", {"push": "xs_N.items.push(100);"}),
    K("union number[] | Set<number>", "num",
      "const w_N = [1, 2];\nconst pick_N = (): number[] | Set<number> => w_N;\nconst xs_N = pick_N();", "...xs_N",
      {"push": "w_N.push(100);"}),
    K("number[] | undefined ?? []", "num",
      "const w_N = [1, 2];\nconst mk_N = (): number[] | undefined => w_N;\nconst xs_N = mk_N();", "...(xs_N ?? [])",
      {"push": "w_N.push(100);"}),
    K("string reassigned", "str", "let s_N = \"ab\";", "...s_N", {"reassign": "s_N = \"xyz\";"}),
    K("string property", "str", "const h_N = { s: \"ab\" };", "...h_N.s", {"reassign": "h_N.s = \"xyz\";"}),
    K("string[]", "str", "const xs_N = [\"a\", \"b\"];", "...xs_N", {"push": "xs_N.push(\"z\");", "write": "xs_N[0] = \"w\";"}),
    K("Set<string>", "str", "const xs_N = new Set([\"a\", \"b\"]);", "...xs_N", {"add": "xs_N.add(\"z\");"}),
    K("map (entries)", "pair", "const m_N = new Map<number, number>([[1, 10], [2, 20]]);", "...m_N",
      {"set": "m_N.set(100, 1000);", "overwrite": "m_N.set(1, -5);"}),
    K("map.entries()", "pair", "const m_N = new Map<number, number>([[1, 10], [2, 20]]);", "...m_N.entries()",
      {"set": "m_N.set(100, 1000);", "overwrite": "m_N.set(1, -5);"}),
    K("set.entries()", "pair", "const xs_N = new Set([1, 2]);", "...xs_N.entries()", {"add": "xs_N.add(100);"}),
    K("arr.entries()", "pair", "const xs_N = [1, 2];", "...xs_N.entries()", {"push": "xs_N.push(100);", "write": "xs_N[0] = -5;"}),
    K("[number, number][]", "pair", "const xs_N: [number, number][] = [[1, 10], [2, 20]];", "...xs_N",
      {"push": "xs_N.push([100, 1000]);", "replace": "xs_N[0] = [-5, -5];"}),
]

# H08c: kinds and mutations added after H08b's (C153's values held in `any`; a later
# operand that empties the array). Appended, so H08b's kinds keep their order.
H08C_ELEMENT_KINDS = [
    K("number[] cleared", "num", "const xs_N: number[] = [1, 2];", "...xs_N", {"clear": "xs_N.length = 0;"}),
    K("any array cleared", "num", "const xs_N: any = [1, 2];", "...xs_N", {"clear": "xs_N.length = 0;"}),
    K("any string", "str", "let xs_N: any = \"ab\";", "...xs_N", {"reassign": "xs_N = \"xyz\";"}),
    K("any generator object", "num", GEN_FN + "const xs_N: any = gen_N();", "...xs_N", {"push": "src_N.push(100);"}),
    K("any Map", "pair", "const xs_N: any = new Map<number, number>([[1, 10], [2, 20]]);", "...xs_N",
      {"set": "xs_N.set(100, 1000);", "overwrite": "xs_N.set(1, -5);"}),
    K("any map.keys() iterator", "num", "const m_N = new Map([[1, 10], [2, 20]]);\nconst xs_N: any = m_N.keys();", "...xs_N",
      {"set": "m_N.set(100, 1000);"}),
    K("any object-literal iterable", "num",
      "const xs_N: any = {\n  items: [1, 2],\n  *[Symbol.iterator](): Iterator<number> {\n    log(\"iter\");\n"
      "    for (const x of this.items) yield x;\n  },\n};", "...xs_N",
      {"push": "xs_N.items.push(100);"}),
    K("any tuple", "num", "const t_N: [number, number] = [1, 2];\nconst xs_N: any = t_N;", "...xs_N", {"write": "t_N[0] = -5;"}),
    K("any Float64Array", "num", "const t_N = new Float64Array([1, 2]);\nconst xs_N: any = t_N;", "...xs_N", {"write": "t_N[0] = -5;"}),
]
ELEMENT_KINDS = ELEMENT_KINDS + H08C_ELEMENT_KINDS


def S(name, etypes, body, decl="", mut="", needs=None, modes=None):
    return dict(name=name, etypes=etypes, body=body, decl=decl, mut=mut, needs=needs, modes=modes)


PLAIN = ("plain",)


ALL = ("num", "unum", "ns", "str", "pair", "obj")
NUMS = ("num",)

# Spread sites. Body text: SP the spread, VAL the suspension as an element, Z an element
# value, E the element type, FMT an element's text (x), N the case number. The body ends
# with a return of a string. `needs` restricts a site to kinds with that property.
SPREAD_SITES = [
    S("arrow rest fn", ALL, "const r = f_N(SP, VAL);\n  return r;"),
    S("arrow rest fn, element before", ALL, "const r = f_N(Z, SP, VAL);\n  return r;"),
    S("arrow rest fn, return", ALL, "return f_N(SP, VAL);"),
    S("arrow rest fn, as argument", ALL, "log(f_N(SP, VAL));\n  return \"\";"),
    S("arrow rest fn, suspension nested in call", ALL, "return f_N(SP, idE_N(VAL));"),
    S("call argument [...xs] then S", ALL, "return two_N([SP], VAL);"),
    S("declared rest fn", ALL, "return fd_N(SP, VAL);"),
    S("generic rest fn", ALL, "return gf_N(SP, VAL);"),
    S("function value", ALL, "return fv_N(SP, VAL);"),
    S("fn.call", ALL, "return fd_N.call(undefined, SP, VAL);"),
    S("method", ALL, "return c_N.f(SP, VAL);"),
    S("static method", ALL, "return C_N.sf(SP, VAL);"),
    S("interface method", ALL, "return ic_N.f(SP, VAL);"),
    S("any function", ALL, "return String(af_N(SP, VAL));"),
    S("any method", ALL, "return String(ao_N.f(SP, VAL));"),
    S("new class", ALL, "return new P_N(SP, VAL).s;"),
    S("fixed params", ALL, "return fx_N(SP, VAL);", needs="tuple"),
    S("head + rest params", ALL, "return hr_N(SP, VAL);", needs="tuple head"),
    S("Math.max", NUMS, "return String(Math.max(SP, VAL));"),
    S("Math.min", NUMS, "return String(Math.min(SP, VAL));"),
    S("String.fromCharCode", NUMS, "return codes(String.fromCharCode(SP, VAL));"),
    S("Array.of", ALL, "return fmt_N(Array.of(SP, VAL));"),
    S("new Array", ALL, "return fmt_N(new Array<E>(SP, VAL));"),
    S("str.concat", ("str",), "return \"s\".concat(SP, VAL);"),
    S("arr.push", ALL, "const o: (E)[] = [Z];\n  o.push(SP, VAL);\n  return fmt_N(o);"),
    S("arr.unshift", ALL, "const o: (E)[] = [Z];\n  o.unshift(SP, VAL);\n  return fmt_N(o);"),
    S("arr.splice", ALL, "const o: (E)[] = [Z];\n  o.splice(1, 0, SP, VAL);\n  return fmt_N(o);"),
    S("console.log", ALL, "console.log(\"{{ID/log}}\", SP, VAL);\n  return \"\";"),
    S("array literal", ALL, "const r = fmt_N([SP, VAL]);\n  return r;"),
    S("array literal, element before", ALL, "return fmt_N([Z, SP, VAL]);"),
    S("array literal, two spreads", ALL, "return fmt_N([SP, ...ys_N, VAL]);",
      decl="const ys_N: (E)[] = [Z2];", mut="ys_N.push(Z2);"),
    S("array literal, spread twice", ALL, "return fmt_N([SP, SP, VAL]);"),
    S("array literal, nested spread", ALL, "return fmt_N([...[SP], VAL]);"),
    S("array literal, in template", ALL, "return `<${fmt_N([SP, VAL])}>`;"),
    S("array literal, suspension in later spread", ALL, "return fmt_N([SP, ...one_N(VAL)]);"),
    S("array literal, suspension in first spread (guard)", ALL, "return fmt_N([...one_N(VAL), SP]);"),
    S("array literal, suspension first (guard)", ALL, "return fmt_N([VAL, SP]);"),
    S("tuple-typed literal", ALL, "const t: [TT, E] = [SP, VAL];\n  return t.map((x) => String(x)).join(\"/\");", needs="tuple no optional"),
    S("destructuring a literal", ALL, "const [d0, ...drest] = [SP, VAL];\n  return fmt_N([d0]) + \"|\" + fmt_N(drest);"),
    S("for...of a literal", ALL, "const acc: string[] = [];\n  for (const x of [SP, VAL]) acc.push(FMT);\n  return acc.join(\"/\");"),
    S("new Set(literal)", ALL, "return fmtSet_N(new Set([SP, VAL]));"),
    S("new Map(literal)", ("pair",), "return fmtMap_N(new Map([SP, VAL]));"),
    # H08c: plain-mode sites (no suspension), appended.
    S("Math.hypot", NUMS, "return String(Math.hypot(SP, VAL));", modes=PLAIN),
    S("String.fromCodePoint", NUMS, "return codes(String.fromCodePoint(SP, VAL));", modes=PLAIN),
    S("super call", ALL, "return new Q_N().s;",
      decl="class Q_N extends P_N {\n  constructor() {\n    super(SP, VAL);\n  }\n}", modes=PLAIN),
    S("generic method", ALL, "return c_N.gm(SP, VAL);", modes=PLAIN),
    S("union method", ALL, "return u_N.f(SP, VAL);",
      decl="class D_N {\n  f(...xs: (E)[]): string { return \"D\" + fmt_N(xs); }\n}\n"
           "const pickU_N = (): C_N | D_N => c_N;\nconst u_N = pickU_N();", modes=PLAIN),
    S("new Float64Array(literal)", NUMS, "return new Float64Array([SP, VAL]).join(\"/\");", modes=PLAIN),
    S("Array.from(literal)", ALL, "return fmt_N(Array.from([SP, VAL]));", modes=PLAIN),
    S("new through any", ALL, "return String(new AP_N(SP, VAL).s);", decl="const AP_N: any = P_N;", modes=PLAIN),
    S("arrow rest fn, spread again after", ALL, "return f_N(SP, VAL, SP);", modes=PLAIN),
    S("any function, spread again after", ALL, "return String(af_N(SP, VAL, SP));", modes=PLAIN),
    S("console.log, spread again after", ALL, "console.log(\"{{ID/log}}\", SP, VAL, SP);\n  return \"\";", modes=PLAIN),
]

# Per-case declarations every spread case gets (E the element type, FMT an element's text).
SITE_DECLS = """\
const fmt_N = (a: (E)[]): string => a.map((x) => FMT).join("/");
const f_N = (...xs: (E)[]): string => fmt_N(xs);
function fd_N(...xs: (E)[]): string { return fmt_N(xs); }
function gf_N<T>(...xs: T[]): string { return xs.map((x) => String(x)).join("/"); }
const pickf_N = (): ((...xs: (E)[]) => string) => f_N;
const fv_N: (...xs: (E)[]) => string = pickf_N();
class C_N {
  f(...xs: (E)[]): string { return fmt_N(xs); }
  static sf(...xs: (E)[]): string { return fmt_N(xs); }
  gm<T>(...xs: T[]): string { return xs.map((x) => String(x)).join("/"); }
}
const c_N = new C_N();
interface IF_N { f(...xs: (E)[]): string }
const ic_N: IF_N = c_N;
const af_N: any = f_N;
const ao_N: any = c_N;
class P_N {
  s: string;
  constructor(...xs: (E)[]) { this.s = fmt_N(xs); }
}
const one_N = (x: E): (E)[] => [x];
const idE_N = (x: E): E => x;
const two_N = (a: (E)[], z: E): string => fmt_N(a) + "|" + fmt_N([z]);
const fmtSet_N = (s: Set<E>): string => {
  const r: string[] = [];
  for (const x of s) r.push(FMT);
  return r.join("/");
};"""
PAIR_DECLS = """
const fmtMap_N = (m: Map<number, number>): string => {
  const r: string[] = [];
  for (const [k, v] of m) r.push(k + ":" + v);
  return r.join("/");
};"""

# Object-spread sources: decl, the spread text, mutations; every source has numeric a, b.
OBJECT_KINDS = [
    K("object literal", "objsrc", "const o_N = { a: 1, b: 2 };", "...o_N", {"write": "o_N.a = 5;"}),
    K("object literal with getter", "objsrc",
      "let st_N = 1;\nconst o_N = {\n  get a(): number { log(\"get a\"); return st_N; },\n  b: 2,\n};", "...o_N",
      {"write": "st_N = 5;"}),
    K("class instance", "objsrc", "class Kc_N { a = 1; b = 2; }\nconst o_N = new Kc_N();", "...o_N", {"write": "o_N.a = 5;"}),
    K("class instance with prototype getter", "objsrc",
      "class Kg_N {\n  a = 1;\n  get b(): number { log(\"get b\"); return 2; }\n}\nconst o_N = new Kg_N();", "...o_N",
      {"write": "o_N.a = 5;"}),
    K("interface of literal", "objsrc", "interface I_N { a: number; b: number }\nconst o_N: I_N = { a: 1, b: 2 };", "...o_N",
      {"write": "o_N.a = 5;"}),
    K("interface of class instance", "objsrc",
      "interface I_N { a: number; b: number }\nclass Kc_N { a = 1; b = 2; }\nconst o_N: I_N = new Kc_N();", "...o_N",
      {"write": "o_N.a = 5;"}),
    K("interface of getter literal", "objsrc",
      "interface I_N { a: number; b: number }\nlet st_N = 1;\nconst o_N: I_N = {\n  get a(): number { log(\"get a\"); return st_N; },\n  b: 2,\n};",
      "...o_N", {"write": "st_N = 5;"}),
    K("Record<string, number>", "objsrc", "const o_N: Record<string, number> = { a: 1, b: 2 };", "...o_N",
      {"write": "o_N.a = 5;", "add key": "o_N.c = 3;", "delete key": "delete o_N.a;"}, record=True),
    K("index signature", "objsrc", "const o_N: { [k: string]: number } = { a: 1, b: 2 };", "...o_N",
      {"write": "o_N.a = 5;", "add key": "o_N.c = 3;", "delete key": "delete o_N.a;"}, record=True),
    K("any object", "objsrc", "const o_N: any = { a: 1, b: 2 };", "...o_N",
      {"write": "o_N.a = 5;", "add key": "o_N.c = 3;"}),
    K("any of class instance", "objsrc", "class Kc_N { a = 1; b = 2; }\nconst o_N: any = new Kc_N();", "...o_N",
      {"write": "o_N.a = 5;"}),
    K("object from call", "objsrc",
      "const src_N = { a: 1, b: 2 };\nconst get_N = (): { a: number; b: number } => { log(\"get\"); return src_N; };",
      "...get_N()", {"write": "src_N.a = 5;"}),
    K("object property", "objsrc", "const h_N = { o: { a: 1, b: 2 } };", "...h_N.o",
      {"write": "h_N.o.a = 5;", "reassign": "h_N.o = { a: 7, b: 8 };"}),
    K("union of classes", "objsrc",
      "class Ua_N { a = 1; b = 2; }\nclass Ub_N { a = 3; b = 4; c = 0; }\nconst pick_N = (): Ua_N | Ub_N => new Ua_N();\nconst o_N = pick_N();",
      "...o_N", {"write": "o_N.a = 5;"}),
    K("optional property", "objsrc", "const o_N: { a?: number; b: number } = { a: 1, b: 2 };", "...o_N",
      {"write": "o_N.a = 5;"}),
    K("array into object", "objsrc", "const o_N = [1, 2];", "...o_N", {"push": "o_N.push(100);"}, record=True),
    K("string into object", "objsrc", "let o_N = \"ab\";", "...o_N", {"reassign": "o_N = \"xyz\";"}, record=True),
]

OBJECT_SITES = [
    S("{ ...o, z: S }", ("objsrc",), "return JSON.stringify({ SP, z: SUSP });"),
    S("{ ...o, z: S } kept in const", ("objsrc",), "const r = { SP, z: SUSP };\n  return JSON.stringify(r);"),
    S("{ ...o, ...o2, z: S }", ("objsrc",), "return JSON.stringify({ SP, ...o2_N, z: SUSP });",
      decl="const o2_N = { q: 1 };", mut="o2_N.q = 9;"),
    S("{ w, ...o, z: S }", ("objsrc",), "return JSON.stringify({ w: 0, SP, z: SUSP });"),
    S("{ ...o, [key()]: S }", ("objsrc",), "return JSON.stringify({ SP, [key_N()]: SUSP });",
      decl="const key_N = (): \"z\" => { log(\"key\"); return \"z\"; };"),
    S("{ ...(c ? o : {}), z: S }", ("objsrc",), "return JSON.stringify({ ...(flag_N() ? SPX : {}), z: SUSP });",
      decl="const flag_N = (): boolean => true;"),
    S("{ ...{ ...o }, z: S }", ("objsrc",), "return JSON.stringify({ ...{ SP }, z: SUSP });"),
    S("typed argument { ...o, z: S }", ("objsrc",), "return showZ_N({ SP, z: SUSP });",
      decl="interface Z_N { a?: number; b: number; z: number }\nconst showZ_N = (o: Z_N): string => o.a + \"/\" + o.b + \"/\" + o.z;",
      needs="not record"),
    S("Record context { ...o, z: S }", ("objsrc",),
      "const r: Record<string, number> = { SP, z: SUSP };\n  return JSON.stringify(r);"),
    S("{ z: S, ...o } (guard)", ("objsrc",), "return JSON.stringify({ z: SUSP, SP });"),
    S("call argument { ...o } then S", ("objsrc",), "return two_N({ SP }, SUSP);",
      decl="const two_N = (o: object, n: number): string => JSON.stringify(o) + \"/\" + n;"),
]


def susp_text(mode, n, variant):
    if mode == "plain" and variant == "real":
        raise ValueError("plain mode has no real variant")
    if variant in ("const", "pre"):
        return "(10)"
    if variant == "sync":
        return f"now(mut_{n})"
    return "(yield 0)" if mode == "yield" else f"(await ten(mut_{n}))"


counter = [0]


def next_n():
    counter[0] += 1
    return counter[0]


def site_applies(site, kind):
    need = site["needs"]
    tup = kind.get("tuple")
    if need == "tuple":
        return tup is not None
    if need == "tuple head":
        return tup is not None
    if need == "tuple no optional":
        return tup is not None and not tup.get("optional")
    if need == "not record":
        return not kind.get("record")
    return True


def spread_case(mode, site, kind, mut_name, mut):
    n = next_n()
    et = ETYPES[kind["etype"]]
    tup = kind.get("tuple")
    decl = [kind["decl"], SITE_DECLS]
    if kind["etype"] == "pair":
        decl.append(PAIR_DECLS)
    if tup:
        decl.append(f"const fx_N = {tup['g']}.map((x) => String(x)).join(\"/\");")
        decl.append("const hr_N = (a: number, ...rest: (E)[]): string => String(a) + \"|\" + rest.map((x) => String(x)).join(\"/\");")
    if site["decl"]:
        decl.append(site["decl"])
    body = site["body"]
    tt = tup["tt"] if tup else ""
    return dict(n=n, id=f"{mode}|{site['name']}|{kind['name']}|{mut_name}", family="spread", mode=mode,
                site=site["name"], kind=kind["name"], mut_name=mut_name, etype=kind["etype"],
                decl="\n".join(d for d in decl if d), body=body, mut=" ".join(x for x in (mut, site["mut"]) if x),
                subst=dict(SP=kind["sp"], VAL=et["val"], Z2=et["z2"], Z=et["zero"], TT=tt, E=et["ts"], FMT=et["fmt"]))


def object_case(mode, site, kind, mut_name, mut):
    n = next_n()
    decl = [kind["decl"]]
    if site["decl"]:
        decl.append(site["decl"])
    return dict(n=n, id=f"{mode}|{site['name']}|{kind['name']}|{mut_name}", family="object", mode=mode,
                site=site["name"], kind=kind["name"], mut_name=mut_name, etype="objsrc",
                decl="\n".join(d for d in decl if d), body=site["body"], mut=" ".join(x for x in (mut, site["mut"]) if x),
                subst=dict(SP=kind["sp"], SPX=kind["sp"][3:]))


def substitute(text, case, variant):
    n = case["n"]
    # the suspension value VAL first (it holds SUSP), then the rest; N last
    for key in ("VAL", "SP", "SPX", "Z2", "Z", "TT", "E", "FMT"):
        if key in case["subst"]:
            text = re.sub(r"\b" + key + r"\b", lambda m, v=case["subst"][key]: v, text)
    text = text.replace("SUSP", susp_text(case["mode"], n, variant))
    text = text.replace("{{ID/log}}", "{{" + case["id"] + "/log}}")
    return re.sub(r"_N\b", f"_{n}", text)


def case_text(case, variant):
    """The module-scope text of one case: its declarations, its mutation, its function and
    the runner function `run_<n>`."""
    n = case["n"]
    mode = case["mode"]
    # TS: E and FMT inside the declarations; SP etc. only in the body
    decl = case["decl"]
    for key in ("E", "FMT", "Z2", "Z"):
        if key in case["subst"]:
            decl = re.sub(r"\b" + key + r"\b", lambda m, v=case["subst"][key]: v, decl)
    if "SP" in re.findall(r"\bSP\b", decl):  # H08c: a site whose declaration holds the spread (super call)
        decl = substitute(decl, case, variant)
    decl = re.sub(r"_N\b", f"_{n}", decl)
    body = substitute(case["body"], case, variant)
    if variant == "pre":  # the mutation before the whole statement: every read sees it
        body = f'log("susp");\n  log("mut");\n  mut_{n}();\n  ' + body
    mut = case["mut"]
    for key in ("Z2", "Z"):
        if key in case["subst"]:
            mut = re.sub(r"\b" + key + r"\b", lambda m, v=case["subst"][key]: v, mut)
    mut = re.sub(r"_N\b", f"_{n}", mut)
    lines = [decl, f"const mut_{n} = (): void => {{ {mut} }};"]
    if mode == "plain":
        lines.append(f"function g_{n}(): string {{\n  {body}\n}}")
        lines.append(f"function run_{n}(): void {{\n  report(\"{case['id']}\", g_{n}());\n}}")
    elif mode == "yield":
        lines.append(f"function* g_{n}(): Generator<number, string, number> {{\n  {body}\n}}")
        lines.append(f"function run_{n}(): void {{\n  const it = g_{n}();\n  let s = it.next();\n"
                     f"  while (!s.done) {{ log(\"susp\"); log(\"mut\"); mut_{n}(); s = it.next(10); }}\n"
                     f"  report(\"{case['id']}\", s.value);\n}}")
    else:
        lines.append(f"async function g_{n}(): Promise<string> {{\n  {body}\n}}")
        lines.append(f"async function run_{n}(): Promise<void> {{\n  const r = await g_{n}();\n  report(\"{case['id']}\", r);\n}}")
    return "\n".join(l for l in lines if l)


def program_text(mode, cases, variant):
    """The program's text and each case's line range [first, last] (1-based)."""
    parts = [PRELUDE.rstrip("\n")]
    line = PRELUDE.count("\n") + 1
    ranges = {}
    for case in cases:
        text = f"// case {case['n']}: {case['id']}\n" + case_text(case, variant)
        count = text.count("\n") + 1
        ranges[case["id"]] = (line, line + count - 1)
        parts.append(text)
        line += count
    if mode in ("yield", "plain"):
        parts.append("\n".join(f"try {{ run_{c['n']}(); }} catch (e) {{ report(\"{c['id']}\", \"threw \" + String(e)); }}" for c in cases))
    else:
        parts.append("async function main(): Promise<void> {\n" + "\n".join(
            f"  try {{ await run_{c['n']}(); }} catch (e) {{ report(\"{c['id']}\", \"threw \" + String(e)); }}" for c in cases) + "\n}\nmain();")
    return "\n".join(parts) + "\n", ranges


def generate():
    programs = collections.OrderedDict()
    for mode in MODES:
        for kind in ELEMENT_KINDS:
            for mut_name, mut in kind["muts"].items():
                group = []
                for site in SPREAD_SITES:
                    if site["modes"] and mode not in site["modes"]:
                        continue
                    if kind["etype"] in site["etypes"] and site_applies(site, kind):
                        group.append(spread_case(mode, site, kind, mut_name, mut))
                name = f"{mode}_spread_{slug(kind['name'])}_{slug(mut_name)}"
                while name in programs:  # slugs collide: tuple [number, number] and [number, number?]
                    name += "_"
                programs[name] = group
        for kind in OBJECT_KINDS:
            for mut_name, mut in kind["muts"].items():
                group = []
                for site in OBJECT_SITES:
                    if site_applies(site, kind):
                        group.append(object_case(mode, site, kind, mut_name, mut))
                name = f"{mode}_object_{slug(kind['name'])}_{slug(mut_name)}"
                while name in programs:
                    name += "_"
                programs[name] = group
    return programs


def slug(s):
    return re.sub(r"_+", "_", "".join(c if c.isalnum() else "_" for c in s)).strip("_")


# ---------------------------------------------------------------------------------------
# Running.

ENV = dict(os.environ, PTS_HOME=HOME,
           PATH=os.path.expanduser("~/.local/node/bin") + ":" + os.path.expanduser("~/.local/go/bin") + ":" + os.environ["PATH"])
LINE = re.compile(r"^\{\{(.*?)\}\} ?(.*)$")
ERR = re.compile(r"^(.*?\.pts):(\d+):(\d+) - error (\w+): (.*)$")


def run(cmd, timeout, cwd=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=ENV, cwd=cwd)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        return "timeout", out, ""


def lines_of(stdout):
    got = collections.defaultdict(list)
    for line in stdout.splitlines():
        m = LINE.match(line)
        if m:
            got[m.group(1)].append(m.group(2))
    return got


def case_lines(got, cid):
    """The lines of case cid: its report and its console.log lines, in order."""
    return [f"{k}: {v}" for k in (cid + "/log", cid) for v in got.get(k, [])]


def node_variant(work, name, mode, cases, variant):
    text, _ = program_text(mode, cases, variant)
    mts = os.path.join(work, f"{name}.{variant}.mts")
    with open(mts, "w") as f:
        f.write(text)
    code, out, err = run([NODE, "--no-warnings", "--experimental-transform-types", mts], 120, cwd=work)
    return code, lines_of(out), err


def pts_variant(work, name, mode, cases, variant):
    """Builds and runs the variant; returns {cid: dict(verdict-ish)}: for each case its lines,
    or DIAG/TSERR/ICE with the message, or CRASH."""
    result = {}
    remaining = list(cases)
    for attempt in range(8):
        if not remaining:
            return result
        text, ranges = program_text(mode, remaining, variant)
        src = os.path.join(work, f"{name}.{variant}.pts")
        with open(src, "w") as f:
            f.write(text)
        exe = os.path.join(work, f"{name}.{variant}.bin")
        code, out, err = run([CLI, "build", src, "-o", exe], 600, cwd=work)
        if code == 0:
            break
        text_out = out + err
        attributed = collections.defaultdict(list)
        unattributed = []
        for line in text_out.splitlines():
            m = ERR.match(line.strip())
            if not m:
                continue
            ln = int(m.group(2))
            owner = next((cid for cid, (a, b) in ranges.items() if a <= ln <= b), None)
            if owner is None:
                unattributed.append(line)
            else:
                attributed[owner].append(f"{m.group(4)}: {m.group(5)} (line {ln - ranges[owner][0] + 1})")
        if code == 3 or not attributed:
            # an internal error, or errors we can't place: build each case alone
            for c in remaining:
                result[c["id"]] = single(work, mode, c, variant)
            return result
        for cid, msgs in attributed.items():
            kind = "TSERR" if all(m.startswith("TS") for m in msgs) else "DIAG"
            result[cid] = dict(verdict=kind, pts=" | ".join(msgs)[:400])
        remaining = [c for c in remaining if c["id"] not in attributed]
    else:
        for c in remaining:
            result[c["id"]] = single(work, mode, c, variant)
        return result
    rc, rout, rerr = run([exe], 120, cwd=work)
    try:
        os.remove(exe)
    except OSError:
        pass
    got = lines_of(rout)
    missing = []
    for c in remaining:
        if c["id"] in got:
            result[c["id"]] = dict(verdict="RAN", lines=case_lines(got, c["id"]))
        else:
            missing.append(c)
    if rc != 0 or missing:
        for c in missing:
            result[c["id"]] = single(work, mode, c, variant)
        if rc != 0 and not missing:
            pass  # every case printed; the exit status comes after them
    return result


def single(work, mode, case, variant):
    name = f"c{case['n']}"
    text, _ = program_text(mode, [case], variant)
    src = os.path.join(work, f"{name}.{variant}.pts")
    with open(src, "w") as f:
        f.write(text)
    exe = os.path.join(work, f"{name}.{variant}.bin")
    code, out, err = run([CLI, "build", src, "-o", exe], 600, cwd=work)
    if code != 0:
        msgs = [l.strip() for l in (out + err).splitlines() if " - error " in l]
        verdict = "ICE" if code == 3 else ("TSERR" if msgs and all(" error TS" in m for m in msgs) else "DIAG")
        return dict(verdict=verdict, pts=" | ".join(msgs)[:400] or (out + err)[-400:], alone=True)
    rc, rout, rerr = run([exe], 120, cwd=work)
    try:
        os.remove(exe)
    except OSError:
        pass
    got = lines_of(rout)
    if rc != 0 or case["id"] not in got:
        return dict(verdict="CRASH", pts=f"<exit {rc}> {rout[-200:]} {rerr.strip()[-300:]}", alone=True)
    return dict(verdict="RAN", lines=case_lines(got, case["id"]), alone=True)


def program(matrix, name, cases):
    work = os.path.join(matrix, "work", name)
    os.makedirs(work, exist_ok=True)
    mode = cases[0]["mode"]
    out = {}
    for variant in VARIANTS:
        ncode, nlines, nerr = node_variant(work, name, mode, cases, variant)
        pres = pts_variant(work, name, mode, cases, variant)
        for c in cases:
            nl = case_lines(nlines, c["id"])
            p = pres.get(c["id"], dict(verdict="CRASH", pts="<no result>"))
            if p["verdict"] == "RAN":
                verdict = "OK" if p["lines"] == nl else "WRONG"
                rec = dict(verdict=verdict, pts=p["lines"], node=nl)
            else:
                rec = dict(verdict=p["verdict"], pts=p.get("pts"), node=nl)
            if not nl:
                rec["node_note"] = f"<node exit {ncode}> {nerr[-200:]}"
            out.setdefault(c["id"], {})[variant] = rec
    return name, out


def main_run(matrix, jobs):
    manifest = json.load(open(os.path.join(matrix, "manifest.json")))
    programs = manifest["programs"]
    cases = {c["id"]: c for group in programs.values() for c in group}
    results = {}
    done = 0
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for name, res in pool.map(lambda kv: program(matrix, *kv), programs.items()):
            results.update(res)
            done += 1
            vc = collections.Counter(r[VARIANTS[0]]["verdict"] for r in res.values())  # H08c: real, or sync without it
            print(f"[{done}/{len(programs)}] {name}: " + " ".join(f"{k}={v}" for k, v in sorted(vc.items())), flush=True)
    for cid, r in results.items():
        c = cases[cid]
        r["dims"] = dict(family=c["family"], mode=c["mode"], site=c["site"], kind=c["kind"], mut=c["mut_name"], etype=c["etype"])
        r["n"] = c["n"]
    json.dump(dict(cli=CLI, home=HOME, results=results), open(os.path.join(matrix, "results.json"), "w"), indent=1)
    if "real" in VARIANTS:
        summarize(matrix, results)
    else:
        summarize_sync(matrix, results)


def classify(r):
    """The case's verdict and, for a WRONG one, whether it is suspension-specific."""
    real, sync, const = r["real"], r["sync"], r["const"]
    v = real["verdict"]
    if v == "WRONG":
        if const["verdict"] == "OK" and sync["verdict"] == "OK":
            return "WRONG"
        return f"WRONG(ctl:{const['verdict']}/{sync['verdict']})"
    if v in ("DIAG", "TSERR", "ICE", "CRASH"):
        return f"{v}(ctl:{const['verdict']})"
    return v


def summarize(matrix, results):
    out = []
    verdicts = collections.Counter(r["real"]["verdict"] for r in results.values())
    out.append(f"cases: {len(results)}  " + "  ".join(f"{k}={v}" for k, v in sorted(verdicts.items())))
    cls = collections.Counter(classify(r) for r in results.values())
    out.append("by verdict with controls (const/sync): " + ", ".join(f"{k}={v}" for k, v in sorted(cls.items())))
    asym = [cid for cid, r in results.items() if r["real"].get("node") != r["sync"].get("node")]
    out.append(f"node real/sync asymmetries (generator checks): {len(asym)}")
    for cid in asym[:20]:
        out.append(f"  ASYM {cid}: real {results[cid]['real'].get('node')} sync {results[cid]['sync'].get('node')}")
    sync_wrong = [cid for cid, r in results.items() if r["sync"]["verdict"] == "WRONG"]
    out.append(f"sync control WRONG (order bug without a suspension): {len(sync_wrong)}")
    for key in ("mode", "site", "kind", "etype"):
        by = collections.defaultdict(collections.Counter)
        for r in results.values():
            by[(r["dims"]["family"], r["dims"][key])][classify(r)] += 1
        out.append(f"\nby family and {key}:")
        for k in sorted(by):
            out.append(f"  {k[0]:7s} {k[1]:48s} " + "  ".join(f"{v}={c}" for v, c in sorted(by[k].items())))
    out.append("\nevery case that isn't OK:")
    for cid in sorted(results, key=lambda c: (classify(results[c]), results[c]["n"])):
        r = results[cid]
        if r["real"]["verdict"] == "OK":
            continue
        out.append(f"{classify(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['real'].get('pts')}")
        out.append(f"        node: {r['real'].get('node')}")
        for variant in ("const", "sync"):
            if r[variant]["verdict"] != "OK":
                out.append(f"        {variant} {r[variant]['verdict']}: pts {r[variant].get('pts')} node {r[variant].get('node')}")
    with open(os.path.join(matrix, "summary.txt"), "w") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(out[:12]))


def classify_sync(r):
    """H08c: a case run without the real variant: its sync verdict, with its const control's."""
    sync, const = r["sync"], r["const"]
    v = sync["verdict"]
    if v == "OK":
        return "OK" if const["verdict"] == "OK" else f"OK(ctl:{const['verdict']})"
    if v == "WRONG":
        return "WRONG" if const["verdict"] == "OK" else f"WRONG(ctl:{const['verdict']})"
    return f"{v}(ctl:{const['verdict']})"


def summarize_sync(matrix, results):
    """H08c: summary.txt for a sync/const run. WRONG = the sync line differs from Node's while
    the const control matches (the order without a suspension, C152/C153); WRONG(ctl:X) = the
    const control is X too (pre-existing beside the order)."""
    out = []
    verdicts = collections.Counter(r["sync"]["verdict"] for r in results.values())
    out.append(f"cases: {len(results)}  (sync verdicts) " + "  ".join(f"{k}={v}" for k, v in sorted(verdicts.items())))
    cls = collections.Counter(classify_sync(r) for r in results.values())
    out.append("by sync verdict with const control: " + ", ".join(f"{k}={v}" for k, v in sorted(cls.items())))
    for key in ("mode", "site", "kind", "etype", "mut"):
        by = collections.defaultdict(collections.Counter)
        for r in results.values():
            by[(r["dims"]["family"], r["dims"][key])][classify_sync(r)] += 1
        out.append(f"\nby family and {key}:")
        for k in sorted(by):
            out.append(f"  {k[0]:7s} {k[1]:48s} " + "  ".join(f"{v}={c}" for v, c in sorted(by[k].items())))
    out.append("\nevery case that isn't OK:")
    for cid in sorted(results, key=lambda c: (classify_sync(results[c]), results[c]["n"])):
        r = results[cid]
        if r["sync"]["verdict"] == "OK":
            continue
        out.append(f"{classify_sync(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['sync'].get('pts')}")
        out.append(f"        node: {r['sync'].get('node')}")
        if r["const"]["verdict"] != "OK":
            out.append(f"        const {r['const']['verdict']}: pts {r['const'].get('pts')} node {r['const'].get('node')}")
    with open(os.path.join(matrix, "summary.txt"), "w") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(out[:3]))


def classify_sync_causes(matrix, jobs):
    """H08c: for each sync-WRONG case, the Node-only "pre" variant (the mutation before the
    whole statement): LATE when PTS's sync value is the pre value (the spread read what the
    later operand left), OTHER otherwise. Writes causes.json and causes.txt."""
    results = json.load(open(os.path.join(matrix, "results.json")))["results"]
    manifest = json.load(open(os.path.join(matrix, "manifest.json")))
    wanted = {cid for cid, r in results.items() if r["sync"]["verdict"] == "WRONG"}
    jobs_list = [(name, [c for c in cases if c["id"] in wanted]) for name, cases in manifest["programs"].items()]
    jobs_list = [(name, group) for name, group in jobs_list if group]

    def node_pre(item):
        name, group = item
        work = os.path.join(matrix, "work", name)
        os.makedirs(work, exist_ok=True)
        code, nl, err = node_variant(work, name, group[0]["mode"], group, "pre")
        return {c["id"]: case_lines(nl, c["id"]) for c in group}

    pre = {}
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for res in pool.map(node_pre, jobs_list):
            pre.update(res)
    causes = {}
    for cid in sorted(wanted, key=lambda c: results[c]["n"]):
        got, late = results[cid]["sync"]["pts"], pre.get(cid, [])
        label = "LATE" if [value_of(x) for x in got] == [value_of(x) for x in late] else "OTHER"
        causes[cid] = dict(label=label, pre=late)
    json.dump(causes, open(os.path.join(matrix, "causes.json"), "w"), indent=1)
    out = ["causes of the sync-WRONG cases (Node 'pre' variant: the mutation before the statement):"]
    by = collections.defaultdict(collections.Counter)
    for cid, c in causes.items():
        by[(results[cid]["dims"]["family"], classify_sync(results[cid]))][c["label"]] += 1
    for k in sorted(by):
        out.append(f"  {k[0]:7s} {k[1]:26s} " + "  ".join(f"{v}={n}" for v, n in sorted(by[k].items())))
    others = [cid for cid, c in causes.items() if c["label"] == "OTHER"]
    out.append(f"OTHER cases ({len(others)}):")
    for cid in others:
        r = results[cid]
        out.append(f"  {classify_sync(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['sync']['pts']}")
        out.append(f"        node: {r['sync']['node']}")
        out.append(f"        pre:  {causes[cid]['pre']}")
    with open(os.path.join(matrix, "causes.txt"), "w") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(out[:20]))


def rerun(matrix, names):
    """Regenerates the manifest (same tables, so the same case numbers), reruns the named
    programs, replaces their cases in results.json, and summarizes again."""
    programs = generate()
    with open(os.path.join(matrix, "manifest.json"), "w") as f:
        json.dump(dict(programs=programs), f, indent=1)
    data = json.load(open(os.path.join(matrix, "results.json")))
    results = data["results"]
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        for name, res in pool.map(lambda nm: program(matrix, nm, programs[nm]), names):
            for cid, r in res.items():
                c = next(c for c in programs[name] if c["id"] == cid)
                r["dims"] = dict(family=c["family"], mode=c["mode"], site=c["site"], kind=c["kind"], mut=c["mut_name"], etype=c["etype"])
                r["n"] = c["n"]
                results[cid] = r
            vc = collections.Counter(r[VARIANTS[0]]["verdict"] for r in res.values())
            print(f"rerun {name}: " + " ".join(f"{k}={v}" for k, v in sorted(vc.items())), flush=True)
    json.dump(data, open(os.path.join(matrix, "results.json"), "w"), indent=1)
    (summarize if "real" in VARIANTS else summarize_sync)(matrix, results)  # H08c


def value_of(line):
    return line.split(" => ", 1)[1] if " => " in line else line


def classify_causes(matrix, jobs):
    """For each suspension-specific WRONG case: runs the Node-only "pre" variant (the
    mutation before the statement) and labels the case LATE-ALL (PTS's real line is the pre
    line: the spread, and everything it runs, was evaluated after the resume), LATE-ELEMENTS
    (only its result is the pre result: what the spread's operand runs came first, its
    elements were read after) or OTHER. Writes causes.json and appends to summary.txt."""
    data = json.load(open(os.path.join(matrix, "results.json")))
    results = data["results"]
    manifest = json.load(open(os.path.join(matrix, "manifest.json")))
    wanted = {cid for cid, r in results.items() if r["real"]["verdict"] == "WRONG"}
    jobs_list = []
    for name, cases in manifest["programs"].items():
        group = [c for c in cases if c["id"] in wanted]
        if group:
            jobs_list.append((name, group))

    def node_pre(item):
        name, group = item
        work = os.path.join(matrix, "work", name)
        os.makedirs(work, exist_ok=True)
        code, nl, err = node_variant(work, name, group[0]["mode"], group, "pre")
        return {c["id"]: case_lines(nl, c["id"]) for c in group}

    pre = {}
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for res in pool.map(node_pre, jobs_list):
            pre.update(res)
    causes = {}
    for cid in wanted:
        r = results[cid]
        got, want, late = r["real"]["pts"], r["real"]["node"], pre.get(cid, [])
        if got == late:
            label = "LATE-ALL"
        elif [value_of(x) for x in got] == [value_of(x) for x in late]:
            label = "LATE-ELEMENTS"
        else:
            label = "OTHER"
        causes[cid] = dict(label=label, pre=late)
    json.dump(causes, open(os.path.join(matrix, "causes.json"), "w"), indent=1)
    out = ["", "causes of the WRONG cases (Node 'pre' variant: the mutation before the statement):"]
    by = collections.defaultdict(collections.Counter)
    for cid, c in causes.items():
        d = results[cid]["dims"]
        by[(d["family"], classify(results[cid]))][c["label"]] += 1
    for k in sorted(by):
        out.append(f"  {k[0]:7s} {k[1]:26s} " + "  ".join(f"{v}={n}" for v, n in sorted(by[k].items())))
    others = [cid for cid, c in causes.items() if c["label"] == "OTHER"]
    out.append(f"OTHER cases ({len(others)}):")
    for cid in sorted(others, key=lambda c: results[c]["n"]):
        r = results[cid]
        out.append(f"  {classify(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['real']['pts']}")
        out.append(f"        node: {r['real']['node']}")
        out.append(f"        pre:  {causes[cid]['pre']}")
    with open(os.path.join(matrix, "causes.txt"), "w") as f:
        f.write("\n".join(out) + "\n")
    print("\n".join(out[:40]))


def main():
    cmd, matrix = sys.argv[1], os.path.abspath(sys.argv[2])
    if cmd == "gen":
        os.makedirs(matrix, exist_ok=True)
        programs = generate()
        with open(os.path.join(matrix, "manifest.json"), "w") as f:
            json.dump(dict(programs=programs), f, indent=1)
        os.makedirs(os.path.join(matrix, "progs"), exist_ok=True)
        for name, cases in programs.items():
            with open(os.path.join(matrix, "progs", name + ".pts"), "w") as f:
                f.write(program_text(cases[0]["mode"], cases, "sync" if cases[0]["mode"] == "plain" else "real")[0])
        total = sum(len(c) for c in programs.values())
        print(len(programs), "programs,", total, "cases")
    elif cmd == "run":
        main_run(matrix, int(sys.argv[3]) if len(sys.argv) > 3 else 2)
    elif cmd == "summarize":
        summarize(matrix, json.load(open(os.path.join(matrix, "results.json")))["results"])
    elif cmd == "summarize_sync":  # H08c
        summarize_sync(matrix, json.load(open(os.path.join(matrix, "results.json")))["results"])
    elif cmd == "classify_sync":  # H08c
        classify_sync_causes(matrix, int(sys.argv[3]) if len(sys.argv) > 3 else 2)
    elif cmd == "rerun":  # rerun NAMES (regenerated from the tables) and merge into results.json
        rerun(matrix, sys.argv[3:])
    elif cmd == "classify":
        classify_causes(matrix, int(sys.argv[3]) if len(sys.argv) > 3 else 4)
    elif cmd == "only":  # run one program: only OUTDIR NAME
        manifest = json.load(open(os.path.join(matrix, "manifest.json")))
        name, res = program(matrix, sys.argv[3], manifest["programs"][sys.argv[3]])
        for cid, r in res.items():
            if "real" in r:
                print(classify(dict(r)), cid, json.dumps(r["real"]))
            else:  # H08c: a sync/const run
                print(classify_sync(dict(r)), cid, json.dumps(r["sync"]))


if __name__ == "__main__":
    main()
