#!/bin/bash
# snapshot.sh DIR: a worktree of HEAD at DIR with the main tree's uncommitted changes, byte-checked.
set -euo pipefail
repo=/home/bryan/projects/parallelscript
dir=$1
if [ -d "$dir" ]; then git -C "$repo" worktree remove --force "$dir"; fi
git -C "$repo" worktree add --detach "$dir" HEAD >/dev/null 2>&1
for lib in ryu bdwgc libuv libbacktrace pcre2; do
  git -C "$dir" submodule update --init --reference "$repo/.git/modules/pts/third_party/$lib" "pts/third_party/$lib" >/dev/null 2>&1
done
git -C "$repo" diff --binary HEAD > "$dir.patch"
if [ -s "$dir.patch" ]; then git -C "$dir" apply --binary "$dir.patch"; fi
git -C "$repo" ls-files --others --exclude-standard -z | (cd "$repo" && xargs -0 -r cp --parents -t "$dir")
bad=0
for f in $(git -C "$repo" diff --name-only HEAD; git -C "$repo" ls-files --others --exclude-standard); do
  if [ -e "$repo/$f" ]; then cmp -s "$repo/$f" "$dir/$f" || { echo "DIFFERS $f"; bad=1; }; else [ ! -e "$dir/$f" ] || { echo "SHOULD BE GONE $f"; bad=1; }; fi
done
echo "snapshot $dir: $(git -C "$repo" diff --name-only HEAD | wc -l) changed, $(git -C "$repo" ls-files --others --exclude-standard | wc -l) new, bad=$bad"
exit $bad
