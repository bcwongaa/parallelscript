#!/bin/bash
# suite.sh DIR OUT: build and run the full PTS suite in worktree DIR; raw events in OUT.jsonl, summary in OUT.txt.
set -uo pipefail
dir=$1; out=$2
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2 PTS_REQUIRE_NODE=1
cd "$dir" || exit 2
{ go build -p 2 ./... && make build; } > "$out.build.txt" 2>&1; b=$?
echo "build exit $b" > "$out.txt"
[ $b -eq 0 ] || exit $b
go test -count=1 -json -p 2 -parallel 2 -timeout 40m ./pts/... ./cmd/pts/ > "$out.jsonl" 2> "$out.stderr"; t=$?
echo "test exit $t" >> "$out.txt"
python3 -I - "$out.jsonl" >> "$out.txt" <<'PY'
import json, sys, collections
c = collections.Counter(); fails = []
for line in open(sys.argv[1]):
    try: e = json.loads(line)
    except Exception: continue
    if e.get("Test") and e.get("Action") in ("pass", "fail", "skip"):
        c[e["Action"]] += 1
        if e["Action"] == "fail": fails.append(e["Package"] + " " + e["Test"])
print(dict(c)); print("\n".join(fails[:50]))
PY
exit $t
