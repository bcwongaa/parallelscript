# compare_matrix.py BASE.json FIX.json: per-case verdict transitions (sync and const) between two runs of the same manifest.
import json, sys, collections
base = json.load(open(sys.argv[1]))["results"]
fix = json.load(open(sys.argv[2]))["results"]
assert base.keys() == fix.keys(), "different manifests"
for variant in ("sync", "const"):
    t = collections.Counter()
    worse = []
    for case in base:
        if variant not in base[case]:
            continue
        b, f = base[case][variant]["verdict"], fix[case][variant]["verdict"]
        t[(b, f)] += 1
        if b == "OK" and f != "OK":
            worse.append(case)
    print(variant, sorted(t.items(), key=lambda kv: -kv[1]))
    print("  OK -> not OK:", len(worse))
    for case in worse[:40]:
        print("   ", case, fix[case][variant]["pts"][:2], fix[case][variant]["node"][:2])
still = collections.Counter()
for case in fix:
    if fix[case]["sync"]["verdict"] == "WRONG":
        d = fix[case]["dims"]
        still[(d["site"] if fix[case]["const"]["verdict"] != "WRONG" else "const-too", d["kind"])] += 1
print("sync WRONG on fix by (site or const-too, kind):")
for k, n in sorted(still.items(), key=lambda kv: -kv[1]):
    print("  ", n, k)
