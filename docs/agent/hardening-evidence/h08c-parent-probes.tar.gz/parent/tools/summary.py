# summary.py OUT.jsonl: test events, packages and corpus counts of a full-suite run.
import json, sys, collections
events, packages, corpus = collections.Counter(), collections.Counter(), collections.Counter()
fails = []
for line in open(sys.argv[1]):
    try:
        e = json.loads(line)
    except ValueError:
        continue
    action, test = e.get("Action"), e.get("Test", "")
    if action not in ("pass", "fail", "skip"):
        continue
    if not test:
        packages[action] += 1
        continue
    events[action] += 1
    if action == "fail":
        fails.append(test)
    if test.startswith("TestCorpusMatchesNode/") and test.count("/") == 2:
        corpus[action] += 1
print("events", dict(events), "packages", dict(packages), "corpus", dict(corpus))
print("\n".join(fails[:50]))
