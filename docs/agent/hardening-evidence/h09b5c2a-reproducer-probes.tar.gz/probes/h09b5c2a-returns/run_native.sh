#!/usr/bin/env bash
set -uo pipefail

tree="${1:?worktree path required}"
evidence="${2:?evidence directory required}"
home="${3:?runtime home required}"
mkdir -p "$evidence"
command=(env GOMAXPROCS=1 PTS_REQUIRE_NODE=1 "PTS_HOME=$home" go -C "$tree" test -count=1 -json -p 1 -parallel 1 -timeout 15m ./pts/tests -run '^TestRun(MatchesNode)?/generic_value_flow_returned_(sources|unknowns)$')
printf '%q ' "${command[@]}" > "$evidence/native_node_home.command"
printf '\n' >> "$evidence/native_node_home.command"
"${command[@]}" > "$evidence/native_node_home.jsonl" 2> "$evidence/native_node_home.stderr"
code=$?
printf '%s\n' "$code" > "$evidence/native_node_home.exit"
printf 'native_node_home exit=%s\n' "$code"
exit "$code"
