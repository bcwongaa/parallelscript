import collections
import json
import sys
from pathlib import Path

for argument in sys.argv[1:]:
    path = Path(argument)
    events = [json.loads(line) for line in path.read_text().splitlines()]
    counts = collections.Counter(event["Action"] for event in events if event.get("Test") and event.get("Action") in ("pass", "fail", "skip"))
    print(path.name, dict(counts))
    by_group = collections.defaultdict(collections.Counter)
    for event in events:
        name = event.get("Test", "")
        if event.get("Action") in ("pass", "fail", "skip") and "/" in name:
            by_group[name.split("/")[0]][event["Action"]] += 1
    for group, result in by_group.items():
        print(group, dict(result))
    for event in events:
        text = event.get("Output", "")
        if "named pairs" in text:
            print(event["Test"].split("/")[-1], text.strip())
        if "error is not nil" in text:
            print("unexpected fixture/setup error:", text.strip())
    for selected in ("TestReturnSourceWalkerChargesItsBodyWork", "TestReturnSourceSummariesAreSharedAcrossDistinctCalls"):
        for event in events:
            text = event.get("Output", "")
            if event.get("Test") == selected and "assertion failed" in text:
                print(selected, text.strip())
    print()
