import hashlib
import sys
import tarfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
probes = root / "probes/h09b5c2a-returns"
patches = ("driver-tests.patch", "lower-tests.patch", "sources-fixture.patch", "unknowns-fixture.patch")
(probes / "tests.patch").write_text("".join((probes / name).read_text() for name in patches))
files = [
    root / "pts/driver/returned_value_sources_test.go",
    root / "pts/lower/returned_value_sources_test.go",
    root / "pts/tests/run/generic_value_flow_returned_sources.pts",
    root / "pts/tests/run/generic_value_flow_returned_unknowns.pts",
]
files += sorted(path for path in probes.rglob("*") if path.is_file())
allowed = {".go", ".pts", ".sh", ".py", ".jsonl", ".stderr", ".exit", ".command", ".txt", ".diff", ".patch"}
for path in files:
    if path.is_symlink() or path.suffix not in allowed:
        raise SystemExit("refusing non-text evidence member: " + str(path))
    path.read_text()
archive = root / "probes/h09b5c2a-return-evidence.tar.gz"
with tarfile.open(archive, "w:gz") as target:
    for path in files:
        target.add(path, arcname=str(path.relative_to(root)), recursive=False)
with tarfile.open(archive, "r:gz") as target:
    if not all(member.isfile() for member in target.getmembers()):
        raise SystemExit("archive contains a non-file member")
print("archive", archive)
print("sha256", hashlib.sha256(archive.read_bytes()).hexdigest())
print("text_members", len(files))
print("patch", probes / "tests.patch")
for path in files[:4]:
    print(hashlib.sha256(path.read_bytes()).hexdigest(), path)
