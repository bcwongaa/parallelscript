#!/usr/bin/env bash
set -uo pipefail

tree="${1:?worktree path required}"
evidence="${2:?evidence directory required}"
mkdir -p "$evidence"

run_case() {
  local name="$1"
  shift
  printf '%q ' "$@" > "$evidence/$name.command"
  printf '\n' >> "$evidence/$name.command"
  "$@" > "$evidence/$name.jsonl" 2> "$evidence/$name.stderr"
  local code=$?
  printf '%s\n' "$code" > "$evidence/$name.exit"
  printf '%s exit=%s\n' "$name" "$code"
}

run_case driver env GOMAXPROCS=1 go -C "$tree" test -count=1 -json -p 1 -parallel 1 -timeout 15m ./pts/driver -run '^Test(ReturnedValuesOnlyInstantiateTheirProvenSources|UnknownReturnedValuesKeepEveryCompatibleInstance|SharedFactoryParameterSummaryIncludesEveryCaller)$'
run_case lower env GOMAXPROCS=1 go -C "$tree" test -count=1 -json -p 1 -parallel 1 -timeout 15m ./pts/lower -run '^Test(ReturnedFunctionSourcesJoinAllSynchronousReturns|UncertainReturnedFunctionSourcesStayUnknown|ReturnSourceWalkerChargesItsBodyWork|ReturnSourceSummariesAreSharedAcrossDistinctCalls|ReturnSourceDepthLimitStaysUnknown)$'
run_case native_node env GOMAXPROCS=1 PTS_REQUIRE_NODE=1 go -C "$tree" test -count=1 -json -p 1 -parallel 1 -timeout 15m ./pts/tests -run '^TestRun(MatchesNode)?/generic_value_flow_returned_(sources|unknowns)$'
