import collections
import json
import sys
from pathlib import Path

for argument in sys.argv[1:]:
    path = Path(argument)
    events = [json.loads(line) for line in path.read_text().splitlines()]
    terminal = [event for event in events if event.get("Test") and event.get("Action") in ("pass", "fail", "skip")]
    counts = collections.Counter(event["Action"] for event in terminal)
    print(path.name, dict(counts))
    failed = {event["Test"] for event in terminal if event["Action"] == "fail"}
    for event in events:
        text = event.get("Output", "")
        if event.get("Test") in failed and any(marker in text for marker in ("assertion failed", "named pairs", "error ", "Error:", "expected", "--- FAIL")):
            print(event.get("Test"), text.rstrip())
    print()
