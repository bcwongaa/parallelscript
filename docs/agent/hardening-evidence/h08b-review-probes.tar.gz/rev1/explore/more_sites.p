/tmp/h08b/rev1/explore/more_sites.pts:34:43 - error PTS1001: spread arguments of `Object.assign({}, …)` are not supported yet
/tmp/h08b/rev1/explore/more_sites.pts:40:25 - error PTS1001: `Object.assign({}, …)` of type Record<string, number> & { z: number; } is not supported yet
[exit 1]
