sum(...getXs().values(), yield): getXs,yielded => 1/2/10
[...getXs().keys(), yield]: getXs,yielded => 0/1/10
sum(...getM().keys(), yield): getM,yielded => 1/2/10
Uncaught TypeError: Expected number[][], got Array
    at /tmp/h08b/rev1/explore/double_eval.pts:56
    at drive (/tmp/h08b/rev1/explore/double_eval.pts:38)
    at /tmp/h08b/rev1/explore/double_eval.pts:57
    at /tmp/h08b/rev1/explore/double_eval.pts:3
[exit 1]
