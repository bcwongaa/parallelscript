/tmp/h08b/rev1/explore/other_forms.pts:74:41 - error PTS9001: internal compiler error while lowering: interface conversion: ir.Type is *ir.Primitive, not *ir.Array
  This is a bug in pts, not in the program. Please report it with the program; PTS_DEBUG=1 adds the details a report needs.
[exit 3]
