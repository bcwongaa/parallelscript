#!/bin/bash
# emitc_diff.sh OUT FILE...: emit C for each file with the base and the snapshot CLI, record same/differ/failed
out=$1; shift
mkdir -p "$out"
for f in "$@"; do
  b=$(basename "$f" .pts)
  d=$(dirname "$f")
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/base timeout 120 /tmp/h08b/base/pts-bin/pts emit-c "$f" -o "$out/$b.base.c" > "$out/$b.base.err" 2>&1); eb=$?
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/review1 timeout 120 /tmp/h08b/review1/pts-bin/pts emit-c "$f" -o "$out/$b.snap.c" > "$out/$b.snap.err" 2>&1); es=$?
  if [ $eb -ne $es ] || ! cmp -s "$out/$b.base.err" "$out/$b.snap.err"; then echo "DIAG-DIFF $b ($eb/$es)";
  elif [ $eb -ne 0 ]; then echo "BOTH-FAIL $b";
  elif cmp -s "$out/$b.base.c" "$out/$b.snap.c"; then echo "SAME $b"; rm -f "$out/$b.base.c" "$out/$b.snap.c" "$out/$b.base.err" "$out/$b.snap.err";
  else echo "C-DIFF $b"; fi
done
