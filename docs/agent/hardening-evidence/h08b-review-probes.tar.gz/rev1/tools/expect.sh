#!/bin/bash
# expect.sh file.pts: print the file's "// expect:" block without the comment prefix
awk 'f { sub(/^\/\/ ?/, ""); print; next } /^\/\/ expect:/ { f=1 }' "$1"
