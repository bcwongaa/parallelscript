H08b review round 1 probes (opus-reviewer). Snapshot /tmp/h08b/review1 (base 88c9cc293 + uncommitted H08b change), base CLI /tmp/h08b/base.
Compare: /tmp/h08b/tools/cmp.sh HOME file.pts (PTS vs Node .mts); outputs saved as *.out next to each probe (### base then ### review1).
p/        semantic probes (holes, tuples, classes, D-108 order, Mixed interfaces, any asymmetry, GC frame/stress, once, receivers, ...)
diag/     diagnostics base vs snapshot (*.base.txt, *.review1.txt); d01/d02 show the objectN name regression
tests/    the six new tests run on base and snapshot vs Node (*.snap.txt, *.base.txt), expect blocks (*.expect) vs Node (*.node)
emitc/    run.txt / other.txt: emit-c base vs snapshot for 525 run tests + 244 corpus/examples (SAME = byte-identical C)
sfirst/   suspension-first spreads: identical C
mx/       reproducer matrix.py `only` on 13 programs against the snapshot (only_*.txt)
explore/  the reproducer's explore probes rerun on the snapshot (*.snap.txt) and base (*.base.txt)
harness_subset.txt  go test TestRun/TestRunMatchesNode on 33 suspension/generator/spread tests (all pass)
tools/    expect.sh, emitc_diff.sh
