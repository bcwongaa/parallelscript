# H06b parent probes and records

- `red/`: RED records. `red-c-unit.txt` (C unit tests against stubs); `red-base-tests.txt` (the 9 committed RED tests on the base CLI); `red-base-new-tests.txt` (the 10 new tests on the base; `nullable_copies_keep_holes` exits 139); `red-par-base.txt`; `red-pop-shift.txt`; `red-r1-1.txt`, `red-r1-2.txt`, `red-r1-3.txt` (round 1's findings on the round-1 build); `red-r2-1-run.txt`, `red-r2-1-errors.txt` (round 2's on the round-2 build).
- `probes/`: the parent's probe programs (the C99 SIGSEGV, `(string | null)[]` paths, entries as a value, pop/shift, the first `.par` probe and its twin).
- `oracles/`: the sequential Node twin of `run/parallel_callbacks_skip_holes.pts` and its output (the test's expect block).
- `matrix-fixed.json.gz`, `families-fixed.txt`, `breakdown-fixed.txt`: the H06 matrix on snapshot 2's CLI, bucketed against the reproducer's base run.
- `bench/`: benchmark programs (the parent's `callbacks`, `par`, `dyn`; the reviewer's `widened`, `loops`, `parscan`, `parreduce`, `parreduce_t`, `quad2`), `measure.sh` (base vs current callgrind counts), `final.txt` (the final pass), `parscan4.txt` (4-thread runs); the callgrind outputs themselves are left out (rerun `measure.sh`).
- `review-replays/`, `review2-replays/`: the reviewer's round-1 and round-2 probes replayed by the parent against Node (`.node`), the build at the time (`.now`) and the base (`.base`).
- `tools/`: `snapshot.sh` (a byte-checked worktree of the uncommitted change), `suite.sh`, `runtests.sh`, `baseline.sh`, `runexpect.py` (a CLI against expect blocks), `count.py` (go test -json counts), `cgdiff.py` (callgrind self-cost diff), `ledger.py` (the ledger update).
