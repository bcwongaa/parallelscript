"""Updates the hardening ledger for H06b: resolutions of C74, C78, C88-C92, C96's text, rows C99-C107."""
import sys

PATH = "docs/reviews/2026-10-13-final/CONSOLIDATED.md"
EVIDENCE = "[h06b.md](../../agent/hardening-evidence/h06b.md)"

RESOLUTIONS = {
    "C74": "**fixed** — H06b (D-183): typed, through `any` and pts:parallel's views skip holes; map keeps them (zeros for a number or boolean result, D-085); reduce without an initial value starts at the first element there is; RED→GREEN tests `run/array_callbacks_skip_holes.pts` (its `points map` line maps to strings, since a `number[]` can't hold holes; `run/array_map_numbers_at_holes.pts` pins the zeros), `any_array_callbacks_skip_holes`, `array_callbacks_length_once`, `parallel_callbacks_skip_holes`, `parallel_views_skip_holes`; " + EVIDENCE,
    "C78": "**fixed** — H06b (D-183): a plain `string[]` given a match's undefined group takes match copies' descriptor (spreads, `concat`, `push`/`unshift` of spreads); filter through `any` keeps the groups; RED→GREEN `run/match_spreads_keep_undefined.pts`, `any_concat_match_groups`. Known gap: a `string[]` that already has holes reads them as undefined too",
    "C88": "**fixed** — H06b (D-183): find and its kin read every index below the starting length, a hole (or a cut-off index) undefined where the element type or the callback's element parameter holds undefined; RED→GREEN `run/array_find_holes.pts`, `array_callbacks_length_once`",
    "C89": "**fixed** — H06b (D-183): `includes` reads holes as undefined, `indexOf`/`lastIndexOf` skip them, on both paths; RED→GREEN `run/array_search_undefined_holes.pts`",
    "C90": "**fixed** — H06b (D-183): own keys (`Object.keys`/`values`/`entries`, `for…in`, `Object.hasOwn`) and `in` leave holes out, a match's undefined group staying in; RED→GREEN `run/array_keys_skip_holes.pts`, `array_in_skips_holes`, `array_has_own_skips_holes`",
    "C91": "**fixed** — H06b (D-183): spreads, `Array.from` (with and without a mapper), `values()`, `entries()` and `for…of` read holes as undefined where the element type holds undefined; `new Set(array)` adds it there (C103); RED→GREEN `run/array_iteration_reads_holes.pts`, `array_from_mapper_reads_holes`, `set_of_array_holes`. By design: element types without undefined keep holes or throw (C96, C106)",
    "C92": "**fixed** — H06b (D-183): `concat` through `any` keeps holes; RED→GREEN `run/any_concat_keeps_holes.pts`, `any_concat_match_groups`",
}

C96_OLD = "| C96 | H06 reproducer, design question 1 (UNREPR, 237 matrix cases); narrowed by H06a review round 1 (F9) | toSorted, toReversed, toSpliced and with (and spreads, `Array.from`, `values()`, C91) of a `string[]` or an array of one object type (`P[]`), whose element type can't hold undefined, give undefined for each hole in JS, which the result's type can't hold; ParallelScript keeps the hole (arrays of any union, `(string \\| null)[]` included, are arrays of dynamic values and get undefined)"
C96_NEW = "| C96 | H06 reproducer, design question 1 (UNREPR, 237 matrix cases); narrowed by H06a review round 1 (F9); widened by H06b (C99) | toSorted, toReversed, toSpliced and with (and spreads, `Array.from`, `values()`, C91) of a `string[]` or an array of one object type (`P[]`), whose element type can't hold undefined, give undefined for each hole in JS, which the result's type can't hold; ParallelScript keeps the hole (since H06b also for unions without undefined such as `(string \\| null)[]`, C99, C106, D-183)"

ROWS = """| C99 | H06b parent (regression from H06a, D-182) | H06a's copies of a `(string \\| null)[]` (any union without undefined) read holes as undefined, a value the type can't hold, which typed code narrowed by `x !== null` to a string and dereferenced: `const c = nullable().toSorted(); for (const x of c) if (x !== null) x.length` exits by SIGSEGV (139) on the base. RED test `run/nullable_copies_keep_holes.pts` | **confirmed** (H06b parent: exit 139 on the base) | **fixed** — H06b (D-183, superseding D-182's union rule): such copies keep the hole; typed reads of it throw RangeError (D-085) | No typed slot holds a value outside its static type. |
| C100 | H06b reproducer F13 (pre-existing) | pts:parallel's `map`, `forEach`, `filter`, `some`, `every`, `find`, `reduce`, `count`, `sum`, `min` and `max` read every index: arrays of strings and objects threw RangeError at the first hole, arrays of unions and `any` passed holes to the callback, and sum/min/max of strings with holes were NaN, at 1/2/4 threads | **confirmed** (H06b reproducer and parent) | **fixed** — H06b (D-183): map keeps holes, the others skip them (find too); RED→GREEN `run/parallel_callbacks_skip_holes.pts`, `parallel_views_skip_holes` (`threads: 1 2 4`, sequential Node twins) | The views equal the sequential methods at holes at every thread count. |
| C101 | H06b reproducer F14 (pre-existing) | Callbacks that change the array's length: typed `map` gave a shorter result, typed find* skipped cut-off indices; through `any`, map gave a shorter result, reduce/reduceRight/some visited cut-off indices as undefined, and forEach/filter/every read the length at every step, so a forEach that pushed never ended | **confirmed** (H06b reproducer) | **fixed** — H06b (D-183): the length is read once; RED→GREEN `run/array_callbacks_length_once.pts` | JS's visiting rules: length read once, HasProperty at each index, map's result of the starting length. |
| C102 | H06b reproducer F15 (pre-existing) | Array patterns at holes: `const [p = "P"] = strings()` throws RangeError where Node gives `'P'`; `[p, q = "D"] = maybe()` throws; a match default throws D-133's TypeError (a copy's RangeError); a rest element over a `(T \\| undefined)[]` keeps holes where Node has undefined. Skipped RED test `run/array_patterns_read_holes.pts` | **confirmed** (H06b reproducer) | open — H11 | Patterns read their source as its iterator does: a default applies at a hole or an undefined group; a rest element holds undefined for holes where its element type holds it. |
| C103 | H06b reproducer F16 (pre-existing) | `new Set(maybe())` of a `(T \\| undefined)[]` or `any[]` with holes left them out (`Set(1) { 'b' }`, Node `Set(2) { undefined, 'b' }`) | **confirmed** (H06b reproducer) | **fixed** — H06b (D-183): undefined added where the set holds undefined; a set of a `string[]` or object array still leaves holes out (D-130, by design); RED→GREEN `run/set_of_array_holes.pts` | A set of an array takes what the array's iterator gives where it can hold it. |
| C104 | H06b reproducer F17 (pre-existing) | A typed callback whose element parameter takes undefined (`m.map((x: string \\| undefined) => x ?? "u")`) over a match array or copy threw D-133's TypeError (a copy's RangeError) for a group that took no part, where D-133 gives a parameter that takes undefined undefined; likewise forEach, some, every, filter, findIndex, reduce | **confirmed** (H06b reproducer) | **fixed** — H06b (D-183): such callbacks read the element as a value; filter keeps the group undefined; RED→GREEN `run/match_callbacks_wide_parameters.pts` | D-133's rule for parameters that take undefined holds in the callback methods. |
| C105 | H06b reproducer DQ8 (pre-existing) | Typed `Object.values(m.slice())` and `Object.entries(m.slice())` of a match copy throw `TypeError: Expected string[], got Array` in the checked copy into tsc's type, where Node gives `[ 'b', undefined, 'b' ]`. Skipped RED test `run/match_copy_values_keep_undefined.pts` | **confirmed** (H06b reproducer and parent) | open — H22 | The values of a match copy keep its undefined groups (a match copy's representation), or an honest diagnostic. |
| C106 | H06b reproducer DQ4 (108 matrix cases) | Spreads, `Array.from`, `values()`, `entries()`, `for…of` and find* of a union without undefined (`(string \\| null)[]`, `(number \\| string)[]`) keep holes or throw RangeError where JS reads undefined | **confirmed** (H06b reproducer) | intentional — D-183 (reading undefined there is C99's unsoundness); [REVIEW_LATER](../../agent/REVIEW_LATER.md) | Documented: a hole is undefined only where the element type holds undefined. |
| C107 | H06b reproducer, minor (pre-existing) | `delete a[i]` on an array is PTS1002 with the message "… other objects have fixed layouts and arrays have no holes", stale since D-085 (`pts/lower/records.go:379`) | **confirmed** (H06b reproducer) | open — H22 | The message says what is true: writes and deletes can't make holes. |"""


def main():
    text = open(PATH, encoding="utf-8").read()
    lines = text.split("\n")
    done = set()
    for i, line in enumerate(lines):
        for cid, resolution in RESOLUTIONS.items():
            if line.startswith("| " + cid + " |"):
                parts = line.split("|")
                parts[-3] = " " + resolution + " "  # | ID | Source | Finding | Verification | Resolution | Acceptance |
                lines[i] = "|".join(parts)
                done.add(cid)
    if done != set(RESOLUTIONS):
        sys.exit("missing rows: %s" % (set(RESOLUTIONS) - done))
    text = "\n".join(lines)
    if C96_OLD not in text:
        sys.exit("C96 text not found")
    text = text.replace(C96_OLD, C96_NEW)
    anchor = text.index("| C98 |")
    end = text.index("\n", anchor)
    text = text[: end + 1] + ROWS + "\n" + text[end + 1 :]
    open(PATH, "w", encoding="utf-8").write(text)


main()
