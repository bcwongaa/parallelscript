"""Runs pts programs and compares stdout with their // expect: blocks.

usage: runexpect.py --pts CLI --home PTS_HOME [--threads N] file.pts...
Prints PASS/FAIL per file (with a unified diff for failures); exits 1 if any fails.
"""
import argparse, difflib, os, subprocess, sys

def expected(path):
    lines, inside = [], False
    for line in open(path, encoding="utf-8").read().split("\n"):
        if line.strip() == "// expect:":
            inside = True
            continue
        if inside:
            if not line.startswith("//"):
                break
            text = line[2:]
            lines.append(text[1:] if text.startswith(" ") else text)
    return lines

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", required=True)
    ap.add_argument("--home", required=True)
    ap.add_argument("--threads")
    ap.add_argument("files", nargs="+")
    args = ap.parse_args()
    env = dict(os.environ, PTS_HOME=args.home, TZ="America/New_York")
    if args.threads:
        env["PTS_THREADS"] = args.threads
    failed = 0
    for path in args.files:
        run = subprocess.run([args.pts, "run", path], capture_output=True, text=True, env=env, timeout=600)
        got = run.stdout.rstrip("\n").split("\n") if run.stdout else []
        want = expected(path)
        if got == want and run.returncode == 0:
            print(f"PASS {path}")
            continue
        failed += 1
        print(f"FAIL {path} (exit {run.returncode})")
        for d in difflib.unified_diff(want, got, "expected", "got", lineterm="", n=0):
            print("   ", d)
        if run.stderr:
            print("    stderr:", run.stderr.strip().split("\n")[0][:300])
    sys.exit(1 if failed else 0)

main()
