"""Counts go test -json events: pass/skip/fail test events, packages, corpus pass/skip."""
import json, sys, collections
c = collections.Counter(); pk = collections.Counter(); corpus = collections.Counter(); fails = []
for line in open(sys.argv[1]):
    try:
        e = json.loads(line)
    except ValueError:
        continue
    a, t = e.get("Action"), e.get("Test")
    if t and a in ("pass", "skip", "fail"):
        c[a] += 1
        if t.startswith("TestCorpusMatchesNode/"):
            corpus[a] += 1
        if a == "fail":
            fails.append(t)
    if not t and a in ("pass", "fail", "skip"):
        pk[a] += 1
print(dict(c), "packages", dict(pk), "corpus", dict(corpus))
for f in fails[:40]:
    print("FAIL", f)
