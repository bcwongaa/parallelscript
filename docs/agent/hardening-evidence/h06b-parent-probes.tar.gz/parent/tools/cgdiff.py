"""cgdiff.py base.cg new.cg [n]: per-function self instruction counts that changed most."""
import re, subprocess, sys
def counts(path):
    out = subprocess.run(["callgrind_annotate", "--threshold=100", "--inclusive=no", "--auto=no", path], capture_output=True, text=True).stdout
    c, table = {}, False
    for line in out.split("\n"):
        if re.match(r"^Ir\s+file:function", line):
            table = True
            continue
        if not table:
            continue
        m = re.match(r"\s*([\d,]+) \([^)]*\)\s+(.*)", line)
        if not m:
            continue
        name = re.sub(r"\s*\[.*\]$", "", m.group(2))
        name = name.rsplit(":", 1)[-1]
        c[name] = c.get(name, 0) + int(m.group(1).replace(",", ""))
    return c
a, b = counts(sys.argv[1]), counts(sys.argv[2])
rows = sorted(set(a) | set(b), key=lambda k: -abs(b.get(k, 0) - a.get(k, 0)))
print(f"total base {sum(a.values()):,} new {sum(b.values()):,}")
for k in rows[:int(sys.argv[3]) if len(sys.argv) > 3 else 15]:
    print(f"{b.get(k,0)-a.get(k,0):>+14,} {a.get(k,0):>14,} {b.get(k,0):>14,}  {k[:90]}")
