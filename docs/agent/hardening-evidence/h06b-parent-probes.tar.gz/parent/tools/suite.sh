#!/bin/bash
# suite.sh DIR OUT: the full PTS suite in DIR.
set -o pipefail
cd "$1"
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2
go build -p 2 ./... && make build >/dev/null && echo BUILD_OK > "$2.build"
PTS_REQUIRE_NODE=1 go test -count=1 -json -p 2 -parallel 2 -timeout 40m ./pts/... ./cmd/pts/ > "$2.jsonl" 2> "$2.stderr"
echo "EXIT $?" > "$2.done"
