#!/bin/bash
# runtests.sh DIR OUT: TestRun and TestRunMatchesNode in DIR, events to OUT.jsonl.
set -o pipefail
cd "$1"
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" GOMAXPROCS=2
make build >/dev/null || { echo "EXIT build" > "$2.done"; exit 1; }
PTS_REQUIRE_NODE=1 go test -count=1 -json -p 1 -parallel 2 -timeout 40m -run '^(TestRun|TestRunMatchesNode|TestErrors)$' ./pts/tests/ > "$2.jsonl" 2> "$2.stderr"
echo "EXIT $?" > "$2.done"
