#!/bin/bash
set -o pipefail
cd /tmp/h06b-base
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
export GOMAXPROCS=2
go build -p 2 ./... && make build >/dev/null && echo BUILD_OK
PTS_REQUIRE_NODE=1 go test -count=1 -json -p 2 -parallel 2 -timeout 40m ./pts/... ./cmd/pts/ > /tmp/h06b/baseline.jsonl 2>/tmp/h06b/baseline.stderr
echo "EXIT $?" > /tmp/h06b/baseline.done
