#!/bin/bash
# measure.sh NAME...: builds each bench/NAME.pts with the base and current CLIs and prints callgrind counts (PTS_THREADS=1).
cd /tmp/h06b/bench
for p in "$@"; do
  PTS_HOME=/tmp/h06b-base /tmp/h06b/pts-base build $p.pts -o b_$p >/dev/null || exit 1
  PTS_HOME=/home/bryan/projects/parallelscript /home/bryan/projects/parallelscript/pts-bin/pts build $p.pts -o n_$p >/dev/null || exit 1
  [ "$(./b_$p)" = "$(./n_$p)" ] || echo "$p: OUTPUTS DIFFER"
  for v in b n; do
    PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file=${v}_$p.cg ./${v}_$p >/dev/null 2>${v}_$p.vg
  done
  b=$(grep -o 'refs: *[0-9,]*' b_$p.vg | tr -dc 0-9); n=$(grep -o 'refs: *[0-9,]*' n_$p.vg | tr -dc 0-9)
  python3 -c "print('%-10s base %15s new %15s  %+.1f%%' % ('$p', format($b, ','), format($n, ','), 100.0*($n-$b)/$b))"
done
