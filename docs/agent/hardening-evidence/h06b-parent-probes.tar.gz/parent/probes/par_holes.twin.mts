function range(a: number, b: number) { const r: number[] = []; for (let i = a; i < b; i++) r.push(i); return r; }
class AtomicInt { n = 0; add(k: number) { this.n += k; } load() { return this.n; } }
declare global { interface Array<T> { count(p: (x: T) => unknown): number; sum(): number; min(): number; max(): number; } }
Array.prototype.count = function (p) { return this.filter(p).length; };
Array.prototype.sum = function () { return this.reduce((a: number, b: unknown) => a + Number(b), 0); };
Array.prototype.min = function () { return this.reduce((a: number, b: unknown) => Math.min(a, Number(b)), Infinity); };
Array.prototype.max = function () { return this.reduce((a: number, b: unknown) => Math.max(a, Number(b)), -Infinity); };
class P {
  x: number;
  constructor(x: number) {
    this.x = x;
  }
}
function show(label: string, f: () => unknown): void {
  try {
    console.log(label, f());
  } catch (e) {
    console.log(label, "threw", (e as Error).name);
  }
}
function strings(n: number): string[] {
  const a = new Array<string>(n);
  for (let i = 0; i < n; i += 3) {
    a[i] = "s" + i;
  }
  return a;
}
function points(n: number): P[] {
  const a = new Array<P>(n);
  for (let i = 1; i < n; i += 4) {
    a[i] = new P(i);
  }
  return a;
}
function maybe(n: number): (number | undefined)[] {
  const a = new Array<number | undefined>(n);
  for (let i = 0; i < n; i += 2) {
    a[i] = i % 4 === 0 ? i : undefined;
  }
  return a;
}
for (const n of [5, 3000]) {
  const s = strings(n), p = points(n), m = maybe(n);
  show(n + " map", () => s.map((x) => x + "!").filter(() => true).length);
  show(n + " map keeps holes", () => { const r = s.map((x) => x + "!"); return [r.length, Object.keys(r).length]; });
  show(n + " forEach", () => { const c = new AtomicInt(); p.forEach(() => { c.add(1); }); return c.load(); });
  show(n + " filter", () => [s.filter(() => true).length, p.filter((q) => q.x > 0).length, m.filter(() => true).length]);
  show(n + " some", () => [s.some((x) => x === undefined), p.some((q) => q === undefined), m.some((x) => x === undefined)]);
  show(n + " every", () => [s.every((x) => typeof x === "string"), p.every((q) => q instanceof P)]);
  show(n + " find", () => [m.find((x) => x === undefined), typeof s.find((x) => x.length > 100)]);
  show(n + " reduce", () => [p.reduce((a, b) => (a.x > b.x ? a : b), new P(-1)).x, s.reduce((a, b) => (a.length > b.length ? a : b), "").length]);
  show(n + " count", () => [s.count(() => true), p.count(() => true), m.count(() => true)]);
  show(n + " sum", () => [m.sum(), m.min(), m.max()]);
}
show("only holes reduce", () => new Array<string>(4).reduce((a, b) => a + b, "init"));
show("range", () => range(0, 4).map((i) => i * 2));

export {};
