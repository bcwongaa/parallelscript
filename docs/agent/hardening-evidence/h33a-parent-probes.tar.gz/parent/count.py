import json, sys, collections
p=f=s=0; fails=[]; pk=collections.Counter()
for l in open(sys.argv[1]):
    try: e=json.loads(l)
    except: continue
    a=e.get('Action')
    if e.get('Test') and a in('pass','fail','skip'):
        if a=='pass':p+=1
        elif a=='fail':f+=1; fails.append(e['Package'].split('/')[-1]+' '+e['Test'])
        else:s+=1
    elif not e.get('Test') and a in ('pass','fail'):
        pk[a]+=1
print(f"{p} pass / {s} skip / {f} fail; packages {dict(pk)}")
for x in fails[:40]: print('FAIL', x)
