package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"math/big"
	"net"
	"net/http"
	"os"
	"time"
)

func main() {
	caKey, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	caTmpl := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "test CA"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign}
	caDER, _ := x509.CreateCertificate(rand.Reader, caTmpl, caTmpl, &caKey.PublicKey, caKey)
	ca, _ := x509.ParseCertificate(caDER)
	os.WriteFile(os.Args[1], pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: caDER}), 0o644)
	leaf := func(names []string, ips []net.IP) tls.Certificate {
		key, _ := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
		tmpl := &x509.Certificate{SerialNumber: big.NewInt(2), Subject: pkix.Name{CommonName: "leaf"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour), DNSNames: names, IPAddresses: ips, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}, KeyUsage: x509.KeyUsageDigitalSignature}
		der, _ := x509.CreateCertificate(rand.Reader, tmpl, ca, &key.PublicKey, caKey)
		return tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}
	}
	serve := func(cert tls.Certificate, max uint16) string {
		l, _ := net.Listen("tcp", "127.0.0.1:0")
		srv := &http.Server{Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "sni=%q alpn=%q version=%x path=%s", r.TLS.ServerName, r.TLS.NegotiatedProtocol, r.TLS.Version, r.URL.Path)
		}), TLSConfig: &tls.Config{Certificates: []tls.Certificate{cert}, MaxVersion: max}}
		go srv.ServeTLS(l, "", "")
		return l.Addr().String()
	}
	good := serve(leaf([]string{"localhost"}, []net.IP{net.ParseIP("127.0.0.1"), net.ParseIP("::1")}), 0)
	tls12 := serve(leaf([]string{"localhost"}, []net.IP{net.ParseIP("127.0.0.1")}), tls.VersionTLS12)
	other := serve(leaf([]string{"other.example"}, []net.IP{net.ParseIP("10.0.0.1")}), 0)
	fmt.Println(good, tls12, other)
	select {}
}
