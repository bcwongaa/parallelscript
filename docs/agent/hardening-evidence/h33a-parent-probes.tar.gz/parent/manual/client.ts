const [good, tls12, other] = process.argv.slice(2);
async function attempt(label: string, url: string): Promise<void> {
  try {
    const response = await fetch(url);
    console.log(label, response.status, await response.text());
  } catch (e) {
    const error = e as Error;
    const cause = error.cause as { code?: string; message?: string } | undefined;
    console.log(label, `${error.name}: ${error.message} | ${cause?.code} | ${cause?.message}`);
  }
}
const port = (a: string) => a.split(":")[1];
await attempt("localhost", `https://localhost:${port(good)}/a`);
await attempt("127.0.0.1", `https://127.0.0.1:${port(good)}/b`);
await attempt("[::1]", `https://[::1]:${port(good)}/b`);
await attempt("tls12", `https://localhost:${port(tls12)}/c`);
await attempt("wrong host", `https://localhost:${port(other)}/d`);
await attempt("wrong ip", `https://127.0.0.1:${port(other)}/d`);
await attempt("http to https server", `http://127.0.0.1:${port(good)}/e`);
