package emitwith

// go test -run TestEmit ./... with PROBE=<file.pts>: prints EmitCWith(AllInstances)'s error,
// which the driver's fallback hides.
import (
	"context"
	"os"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func TestEmit(t *testing.T) {
	_, err := driver.EmitCWith(context.Background(), os.Getenv("PROBE"), lower.AllInstances)
	t.Logf("AllInstances error: %v", err)
}
