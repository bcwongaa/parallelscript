import sys
# gen_sep.py K: K classes whose generic make<T> is read as a value and passed to its own
# function use{k}, which makes one typed call for its own type V{k}. Each wrapper meets one
# demand at run time; pairing is K x K.
K = int(sys.argv[1])
out = ["class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
for k in range(K):
    out.append(f"class V{k} {{ constructor(public n: number) {{}} }}")
    out.append(f"function use{k}(f: Factory): number {{ const b: Box<V{k}> = f(new V{k}({k})); return b.value.n; }}")
    out += [f"class M{k} {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
for k in range(K):
    out.append(f"console.log(use{k}(new M{k}().make));")
print("\n".join(out))
