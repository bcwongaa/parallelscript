import sys
# gen_decl.py K D: the control for gen.py: K generic function declarations passed to `use`,
# which makes D typed calls of a generic function type (instances made on the base too).
K, D = int(sys.argv[1]), int(sys.argv[2])
out = ["class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
for j in range(D):
    out.append(f"class V{j} {{ constructor(public n: number) {{}} }}")
lines = ["function use(f: Factory): number {", "  let total = 0;"]
for j in range(D):
    lines.append(f"  const b{j}: Box<V{j}> = f(new V{j}({j}));")
    lines.append(f"  total += b{j}.value.n;")
lines += ["  return total;", "}"]
out += lines
for k in range(K):
    out += [f"function make{k}<T>(x: T): Box<T> {{", "    return new Box(x);", "}"]
for k in range(K):
    out.append(f"console.log(use(make{k}), use(make{k}));")
print("\n".join(out))
