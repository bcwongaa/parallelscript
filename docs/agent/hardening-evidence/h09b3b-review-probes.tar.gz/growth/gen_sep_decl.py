import sys
# gen_sep_decl.py K: the control: K generic declarations, each passed to its own use{k}.
K = int(sys.argv[1])
out = ["class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
for k in range(K):
    out.append(f"class V{k} {{ constructor(public n: number) {{}} }}")
    out.append(f"function use{k}(f: Factory): number {{ const b: Box<V{k}> = f(new V{k}({k})); return b.value.n; }}")
    out.append(f"function make{k}<T>(x: T): Box<T> {{ return new Box(x); }}")
for k in range(K):
    out.append(f"console.log(use{k}(make{k}));")
print("\n".join(out))
