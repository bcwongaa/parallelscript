import sys
# gen.py K D: K classes whose generic make<T> is read as a value (method value + bind) and
# passed to `use`, which makes D typed calls of a generic function type.
K, D = int(sys.argv[1]), int(sys.argv[2])
out = ["class Box<T> {", "  constructor(public value: T) {}", "}", "type Factory = <T>(x: T) => Box<T>;"]
types = []
for j in range(D):
    out.append(f"class V{j} {{ constructor(public n: number) {{}} }}")
lines = ["function use(f: Factory): number {", "  let total = 0;"]
for j in range(D):
    lines.append(f"  const b{j}: Box<V{j}> = f(new V{j}({j}));")
    lines.append(f"  total += b{j}.value.n;")
lines += ["  return total;", "}"]
out += lines
for k in range(K):
    out += [f"class M{k} {{", "  make<T>(x: T): Box<T> {", "    return new Box(x);", "  }", "}"]
for k in range(K):
    out.append(f"const m{k} = new M{k}();")
    out.append(f"console.log(use(m{k}.make), use(m{k}.make.bind(m{k})));")
print("\n".join(out))
