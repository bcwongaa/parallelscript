import difflib, sys
head = open(sys.argv[1]).read().split('\n'); proto = open(sys.argv[2]).read().split('\n')
ops = difflib.SequenceMatcher(None, head, proto, autojunk=False).get_opcodes()
# merge change groups separated by short equal runs (<= GAP lines), never across a blank line or a function boundary
GAP = 2
blocks = []  # list of ['eq', lines] or ['chg', old, new]
for tag, i1, i2, j1, j2 in ops:
    if tag == 'equal':
        blocks.append(['eq', head[i1:i2]])
    else:
        blocks.append(['chg', head[i1:i2], proto[j1:j2]])
merged = []
for b in blocks:
    if b[0] == 'chg' and len(merged) >= 2 and merged[-1][0] == 'eq' and merged[-2][0] == 'chg' and len(merged[-1][1]) <= GAP \
       and all(l.strip() not in ('', '}') and not l.startswith(('static', 'double', '#')) for l in merged[-1][1]):
        eq = merged.pop()[1]; prev = merged.pop()
        merged.append(['chg', prev[1] + eq + b[1], prev[2] + eq + b[2]])
    else:
        merged.append(b)
out = []; n = 0
for b in merged:
    if b[0] == 'eq': out += b[1]; continue
    n += 1; old, new = b[1], b[2]
    if new and old: out += ['#if PTS_V8_GCC_FMA'] + new + ['#else'] + old + ['#endif']
    elif new: out += ['#if PTS_V8_GCC_FMA'] + new + ['#endif']
    else: out += ['#if !PTS_V8_GCC_FMA'] + old + ['#endif']
s = '\n'.join(out).replace('#if PTS_V8_GCC_FMA\n#include "v8_fma_internal.h"\n#endif\n', '#include "v8_fma_internal.h"\n', 1)
open(sys.argv[3], 'w').write(s)
print('blocks', n, file=sys.stderr)
