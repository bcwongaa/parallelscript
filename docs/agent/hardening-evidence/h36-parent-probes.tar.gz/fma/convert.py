import difflib, sys
head = open(sys.argv[1]).read().split('\n')
proto = open(sys.argv[2]).read().split('\n')
out = []
groups = 0
for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, head, proto, autojunk=False).get_opcodes():
    if tag == 'equal':
        out += head[i1:i2]; continue
    groups += 1
    old, new = head[i1:i2], proto[j1:j2]
    if new and old:
        out += ['#if PTS_V8_GCC_FMA'] + new + ['#else'] + old + ['#endif']
    elif new:
        out += ['#if PTS_V8_GCC_FMA'] + new + ['#endif']
    else:
        out += ['#if !PTS_V8_GCC_FMA'] + old + ['#endif']
open(sys.argv[3], 'w').write('\n'.join(out))
print('groups', groups, file=sys.stderr)
