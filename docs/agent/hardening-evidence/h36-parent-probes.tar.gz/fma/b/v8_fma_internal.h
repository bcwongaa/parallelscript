/*
 * PTS_V8_FMA(a, b, c) is a * b + c, rounded once where Node's own build of V8's C++ rounds it once.
 *
 * Node's official linux-arm64 binary is built by GCC 12, whose default -ffp-contract=fast fuses a
 * product into the addition or subtraction that is its only use in the same basic block (GCC's
 * widening_mul pass); x86-64's baseline has no FMA instruction, so nothing fuses there, and V8's
 * JIT never fuses JavaScript's own arithmetic. The runtime's ports of that C++ (Math in ieee754.c,
 * parseInt's other radixes in number_methods.c, MakeDate in date.c) write PTS_V8_FMA exactly where
 * GCC 12 fuses and nowhere else, and still compile with -ffp-contract=off, so the C compiler fuses
 * nothing of its own: an aarch64 Linux program prints what Node prints on arm64 Linux, and an x86-64
 * one what Node prints on x86-64. c - a * b is PTS_V8_FMA(-a, b, c) and a * b - c is
 * PTS_V8_FMA(a, b, -c); negation is exact, so the unfused forms round as the original expressions do.
 */
#ifndef PTS_V8_FMA_INTERNAL_H
#define PTS_V8_FMA_INTERNAL_H

#if defined(__aarch64__) && defined(__linux__)
#define PTS_V8_FMA(a, b, c) __builtin_fma((a), (b), (c))
#else
#define PTS_V8_FMA(a, b, c) ((a) * (b) + (c))
#endif

#endif
