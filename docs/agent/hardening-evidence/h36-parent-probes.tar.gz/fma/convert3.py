import sys, importlib.util
sys.argv_saved = sys.argv
head = open('head.c').read().split('\n'); proto = open('proto.c').read().split('\n')
def find(lines, text, start=0):
    for i in range(start, len(lines)):
        if text in lines[i]: return i
    raise SystemExit('not found: ' + text)
def region(lines):
    a = find(lines, 'We always inline k_log1p') - 1   # the comment's "/*"
    b = find(lines, "Return the base 10 logarithm of x", a) - 3  # the "}" ending log2
    assert lines[a] == '/*' and lines[b] == '}', (lines[a], lines[b])
    return a, b + 1
ha, hb = region(head); pa, pb = region(proto)
import difflib
def convert(h, p):
    ops = difflib.SequenceMatcher(None, h, p, autojunk=False).get_opcodes()
    blocks = []
    for tag, i1, i2, j1, j2 in ops:
        blocks.append(['eq', h[i1:i2]] if tag == 'equal' else ['chg', h[i1:i2], p[j1:j2]])
    merged = []
    for b in blocks:
        if b[0] == 'chg' and len(merged) >= 2 and merged[-1][0] == 'eq' and merged[-2][0] == 'chg' and len(merged[-1][1]) <= 2 \
           and all(l.strip() not in ('', '}') and not l.lstrip().startswith(('static', '#', '/*', '*')) for l in merged[-1][1]):
            eq = merged.pop()[1]; prev = merged.pop()
            merged.append(['chg', prev[1] + eq + b[1], prev[2] + eq + b[2]])
        else:
            merged.append(b)
    out = []; n = 0
    for b in merged:
        if b[0] == 'eq': out += b[1]; continue
        n += 1; old, new = b[1], b[2]
        if new and old: out += ['#if PTS_V8_GCC_FMA'] + new + ['#else'] + old + ['#endif']
        elif new: out += ['#if PTS_V8_GCC_FMA'] + new + ['#endif']
        else: out += ['#if !PTS_V8_GCC_FMA'] + old + ['#endif']
    return out, n
pre, n1 = convert(head[:ha], proto[:pa])
post, n2 = convert(head[hb:], proto[pb:])
mid = ['#if PTS_V8_GCC_FMA'] + proto[pa:pb] + ['#else'] + head[ha:hb] + ['#endif']
s = '\n'.join(pre + mid + post).replace('#if PTS_V8_GCC_FMA\n#include "v8_fma_internal.h"\n#endif\n', '#include "v8_fma_internal.h"\n', 1)
open('merged3.c', 'w').write(s)
print('blocks', n1 + n2 + 1, file=sys.stderr)
