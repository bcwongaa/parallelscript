#!/bin/sh
# Node's linux-arm64 build under qemu-aarch64 (binfmt_misc), as the arm64 CI job's oracle.
QEMU_LD_PREFIX=/usr/aarch64-linux-gnu exec /tmp/pts-h36/node-arm64-dl/node-v24.21.0-linux-arm64/bin/node "$@"
