package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: allinstances emit|build|default input.pts output")
		os.Exit(2)
	}
	ctx := context.Background()
	if os.Args[1] == "default" {
		check(driver.Build(ctx, os.Args[2], os.Args[3]))
		return
	}
	c, err := driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
	check(err)
	if os.Args[1] == "emit" {
		check(os.WriteFile(os.Args[3], []byte(c), 0600))
		fmt.Printf("AllInstances lines=%d bytes=%d\n", strings.Count(c, "\n"), len(c))
		return
	}
	if os.Args[1] != "build" {
		fmt.Fprintln(os.Stderr, "unknown action", os.Args[1])
		os.Exit(2)
	}
	cfile := os.Args[3] + ".c"
	check(os.WriteFile(cfile, []byte(c), 0600))
	tc, err := toolchain.New()
	check(err)
	rt, err := tc.Runtime(ctx, toolchain.Release)
	check(err)
	check(tc.CompileProgram(ctx, rt, []string{cfile}, os.Args[3]))
}

func check(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
