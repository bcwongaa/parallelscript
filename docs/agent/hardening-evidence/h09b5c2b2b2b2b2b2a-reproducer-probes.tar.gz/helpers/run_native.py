#!/usr/bin/env python3
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(sys.argv[1])
helper = Path(sys.argv[2])
runtime_home = Path(sys.argv[3])
out = Path(__file__).resolve().parent
fixture = root / "pts/tests/run/generic_destructured_container_sources.pts"
source = fixture.read_text()
(out / "fixture.pts").write_text(source)
(out / "fixture.mts").write_text(source)
expected = "\n".join(line[3:] for line in source.split("// expect:\n", 1)[1].splitlines() if line.startswith("// ")) + "\n"
(out / "fixture.expected").write_text(expected)
env = dict(os.environ, PTS_HOME=str(runtime_home), PTS_THREADS="1", GOMAXPROCS="1")
results = []


def run(name, command):
    try:
        completed = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=600)
        code, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or b"", error.stderr or b""
    (out / (name + ".stdout")).write_bytes(stdout)
    (out / (name + ".stderr")).write_bytes(stderr)
    results.append({"name": name, "command": list(map(str, command)), "cwd": str(root), "PTS_HOME": str(runtime_home), "exit": code})
    print(name + ": exit=" + str(code), flush=True)
    return code, stdout


node = Path.home() / ".local/node/bin/node"
node_code, node_stdout = run("node", [str(node), "--no-warnings", "--experimental-transform-types", str(out / "fixture.mts")])
all_ok = node_code == 0 and node_stdout.decode() == expected
for mode in ["build", "default"]:
    native = out / ("fixture-" + mode + ".bin")
    code, _ = run("fixture-" + mode, [str(helper), mode, str(out / "fixture.pts"), str(native)])
    if code == 0:
        code, stdout = run("fixture-" + mode + "-run", [str(native)])
        match = code == 0 and stdout == node_stdout and stdout.decode() == expected
        print("fixture-" + mode + " strict-Node-and-expect-match=" + str(match), flush=True)
        all_ok = all_ok and match
    else:
        all_ok = False

checked = out / "checked_any_write.pts"
checked_native = out / "checked-any.bin"
code, _ = run("checked-any-build", [str(helper), "build", str(checked), str(checked_native)])
if code == 0:
    code, stdout = run("checked-any-run", [str(checked_native)])
    match = code == 0 and stdout == b"checked write true\nafter checked write 4\n"
    print("checked-any PTS-boundary-match=" + str(match), flush=True)
    all_ok = all_ok and match
else:
    all_ok = False
(out / "native-results.json").write_text(json.dumps({"results": results, "all_ok": all_ok}, indent=2) + "\n")
sys.exit(0 if all_ok else 1)
