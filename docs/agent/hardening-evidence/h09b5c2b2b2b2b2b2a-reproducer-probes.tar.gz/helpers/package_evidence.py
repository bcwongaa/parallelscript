import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile

root = Path(sys.argv[1])
scratch = Path(sys.argv[2])
archive = scratch / 'h09-destructured-red-evidence.tar.gz'
payload = {}


def include(name, path):
    path = Path(path)
    assert stat.S_ISREG(path.lstat().st_mode), str(path)
    assert not path.is_symlink(), str(path)
    assert name not in payload, name
    payload[name] = path.read_bytes()


for name in [
    'pts/lower/destructured_container_sources_test.go',
    'pts/driver/destructured_container_instances_test.go',
    'pts/tests/run/generic_destructured_container_sources.pts',
]:
    include('sources/' + name, root / name)
for name in ['allinstances.go', 'run_native.py', 'package_evidence.py']:
    include('helpers/' + name, scratch / name)
include('sources/checked_any_write.pts', scratch / 'checked_any_write.pts')
for name in ['lower-red-input.go', 'initial-lower-draft.go', 'initial-driver-draft.go', 'initial-fixture-draft.pts']:
    include('originals/' + name, scratch / name)
for name in [
    'lower-red.jsonl', 'lower-red.stderr',
    'lower-red-corrected.jsonl', 'lower-red-corrected.stderr',
    'driver-red.jsonl', 'driver-red.stderr',
    'helper-build.stdout', 'helper-build.stderr',
    'native-run.stdout', 'native-run.stderr', 'native-results.json',
    'node.stdout', 'node.stderr',
    'fixture-build.stdout', 'fixture-build.stderr',
    'fixture-build-run.stdout', 'fixture-build-run.stderr',
    'fixture-default.stdout', 'fixture-default.stderr',
    'fixture-default-run.stdout', 'fixture-default-run.stderr',
    'checked-any-build.stdout', 'checked-any-build.stderr',
    'checked-any-run.stdout', 'checked-any-run.stderr',
    'fixture.expected',
]:
    include('raw/' + name, scratch / name)
for name in ['fixture-build.bin.c', 'checked-any.bin.c']:
    include('generated/' + name, scratch / name)

base = 'fccb65ad6e2e598ea862aaae8dbde26b73ddf32e'
model = {
    'actual_runtime_identity': 'gpt-6.1-sol',
    'identity_evidence': 'Environment system-reminder: You are powered by the model gpt-6.1-sol.',
    'model_override_used': False,
    'nested_agents_used': False,
    'selection_rule': 'Inherited omit-only exception per parent task D-206 through D-212.',
    'heavy_slot': 'released; no further tests or builds',
    'base_commit': base,
    'worktree': str(root),
}
payload['metadata/model-confirmation.json'] = (json.dumps(model, indent=2) + '\n').encode()


def go_test(package, stem):
    return ('GOMAXPROCS=1 go -C ' + str(root) +
            ' test -count=1 -json -p 1 -parallel 1 -timeout 15m ./' + package +
            " -run '^TestDestructuredContainer' > " + str(scratch / (stem + '.jsonl')) +
            ' 2> ' + str(scratch / (stem + '.stderr')))


commands = [
    {
        'name': 'initial-lower-red', 'command': go_test('pts/lower', 'lower-red'), 'exit': 1,
        'pass_events': 55, 'fail_events': 52,
        'executed_lower_source': 'originals/lower-red-input.go',
        'setup_diagnostics': ['TS2353 invalid_unselected_getter', 'TS2353 invalid_unselected_spread', 'TS2353 unselected_root_work'],
    },
    {
        'name': 'corrected-lower-red', 'command': go_test('pts/lower', 'lower-red-corrected'), 'exit': 1,
        'pass_events': 60, 'fail_events': 47,
        'executed_lower_source': 'sources/pts/lower/destructured_container_sources_test.go',
        'setup_diagnostics': [],
    },
    {
        'name': 'driver-red', 'command': go_test('pts/driver', 'driver-red'), 'exit': 1,
        'pass_events': 36, 'fail_events': 54, 'setup_diagnostics': [],
    },
    {
        'name': 'helper-build',
        'command': ('GOMAXPROCS=1 go -C ' + str(root) + ' build -p 1 -o ' + str(scratch / 'allinstances') +
                    ' ' + str(scratch / 'allinstances.go') + ' > ' + str(scratch / 'helper-build.stdout') +
                    ' 2> ' + str(scratch / 'helper-build.stderr')),
        'exit': 0,
    },
    {
        'name': 'native-runner',
        'command': ('python3 -I ' + str(scratch / 'run_native.py') + ' ' + str(root) +
                    ' ' + str(scratch / 'allinstances') + ' /home/bryan/projects/parallelscript > ' +
                    str(scratch / 'native-run.stdout') + ' 2> ' + str(scratch / 'native-run.stderr')),
        'exit': 0,
        'subcommands_record': 'raw/native-results.json',
        'environment': {'GOMAXPROCS': '1', 'PTS_THREADS': '1', 'PTS_HOME': '/home/bryan/projects/parallelscript'},
        'runtime_home_reason': 'Existing unchanged runtime used because assigned worktree third-party submodules are uninitialized; compiler/helper built from exact base in assigned worktree.',
    },
]
metadata = {
    'base_commit': base,
    'cwd': str(root),
    'commands': commands,
    'counts_are': 'go test pass/fail test and subtest events, not unique programs',
    'original_setup_corrections': {
        'cases': ['invalid_unselected_getter', 'invalid_unselected_spread', 'unselected_root_work'],
        'change': 'Name complete literal root before destructuring instead of destructuring fresh literal with discarded excess members; assertions unchanged.',
        'original_executed_source': 'originals/lower-red-input.go',
        'unexecuted_draft_files': [
            'originals/initial-lower-draft.go',
            'originals/initial-driver-draft.go',
            'originals/initial-fixture-draft.pts',
        ],
    },
    'omissions': [
        'helper executable and native binaries',
        'dependency trees',
        'duplicate fixture.pts and fixture.mts copies generated by run_native.py from the included source fixture',
    ],
    'archive_policy': 'Relative regular-file members only, no links/directories/absolute or parent-traversal members. SHA256SUMS covers every payload member except SHA256SUMS itself.',
}
payload['metadata/commands.json'] = (json.dumps(metadata, indent=2) + '\n').encode()
payload['SHA256SUMS'] = ''.join(hashlib.sha256(data).hexdigest() + '  ' + name + '\n' for name, data in sorted(payload.items())).encode()

for name in payload:
    parts = PurePosixPath(name)
    assert not parts.is_absolute() and '..' not in parts.parts and str(parts) == name, name

with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|', format=tarfile.USTAR_FORMAT) as tf:
            for name, data in sorted(payload.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                entry.uid = entry.gid = entry.mtime = 0
                entry.uname = entry.gname = ''
                entry.type = tarfile.REGTYPE
                tf.addfile(entry, io.BytesIO(data))

with tarfile.open(archive, 'r:gz') as tf:
    members = tf.getmembers()
    assert len(members) == len(payload)
    assert len({m.name for m in members}) == len(members)
    for member in members:
        assert member.isreg() and not member.issym() and not member.islnk()
        assert not PurePosixPath(member.name).is_absolute() and '..' not in PurePosixPath(member.name).parts
        assert tf.extractfile(member).read() == payload[member.name]
    manifest = tf.extractfile('SHA256SUMS').read().decode()
    for line in manifest.splitlines():
        wanted, name = line.split('  ', 1)
        assert hashlib.sha256(tf.extractfile(name).read()).hexdigest() == wanted

print('archive=' + str(archive))
print('sha256=' + hashlib.sha256(archive.read_bytes()).hexdigest())
print('members=' + str(len(payload)))
print('payload_bytes=' + str(sum(map(len, payload.values()))))
print('archive_bytes=' + str(archive.stat().st_size))
print('verified=relative regular members and full hash manifest')
