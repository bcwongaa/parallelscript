#!/bin/bash
# usage: emit.sh <new|base> probe.pts -> writes C to out1/<which>/<name>.c
which=$1; p=$(realpath "$2"); name=$(basename "$p" .pts); out=/tmp/pts-h03-review3/out1/$which; mkdir -p "$out"
case $which in
 new) cli=/home/bryan/projects/parallelscript/pts-bin/pts; home=/home/bryan/projects/parallelscript; cache=/tmp/pts-h03-review3/cache;;
 base) cli=/home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e/pts-bin/pts; home=/home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e; cache=/tmp/pts-h03-review3/basecache;;
 r2) cli=/tmp/pts-h03-review/pts2; home=/home/bryan/projects/parallelscript; cache=/tmp/pts-h03-review3/cache;;
esac
timeout 120 env PTS_HOME=$home PTS_CACHE_DIR=$cache GOMAXPROCS=2 $cli emit-c "$p" -o "$out/$name.c"; echo "emit $which exit $? -> $out/$name.c"
