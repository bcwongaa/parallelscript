#!/bin/bash
# usage: one.sh <new|base|r2> probe.pts -> build+run with that CLI; prints exit, stdout, stderr head
which=$1; p=$(realpath "$2"); name=$(basename "$p" .pts); out=/tmp/pts-h03-review3/out1/$which/$name; mkdir -p "$out"
case $which in
 new) cli=/home/bryan/projects/parallelscript/pts-bin/pts; home=/home/bryan/projects/parallelscript; cache=/tmp/pts-h03-review3/cache;;
 base) cli=/home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e/pts-bin/pts; home=/home/bryan/projects/parallelscript/.claude/worktrees/agent-afb5379bc12f20b9e; cache=/tmp/pts-h03-review3/basecache;;
 r2) cli=/tmp/pts-h03-review/pts2; home=/home/bryan/projects/parallelscript; cache=/tmp/pts-h03-review3/cache;;
esac
ulimit -f 40960
( cd "$out" && timeout 120 env PTS_HOME=$home PTS_CACHE_DIR=$cache GOMAXPROCS=2 $cli build "$p" -o "$out/bin" > "$out/build" 2>&1 ); be=$?
if [ $be = 0 ]; then ( ulimit -v 4194304; cd "$out" && timeout 60 env TZ=America/New_York "$out/bin" > "$out/out" 2> "$out/err" ); e=$?; else cp "$out/build" "$out/err"; : > "$out/out"; e=build-fail; fi
echo "== [$which] $name exit $e"; cat "$out/out" | head -${OUTN:-20}; [ -s "$out/err" ] && { echo "-- stderr:"; head -${ERRN:-6} "$out/err"; }
exit 0
