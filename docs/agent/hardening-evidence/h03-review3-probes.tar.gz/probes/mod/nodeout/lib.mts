export const [ea, eb] = new Set([1]);
export let [la, lb] = "x";
export function bump(): void { lb = "y"; la = la + "!"; }
