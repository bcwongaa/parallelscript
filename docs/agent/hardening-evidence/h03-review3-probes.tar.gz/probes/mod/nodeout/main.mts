import { ea, eb, la, lb, bump } from "./lib.mts";
console.log("imported", ea, eb, la, lb, ea + 1, la.length);
bump();
console.log("after bump", la, lb, lb?.length);
const f = () => eb ?? "none";
console.log(f());
