// Review probe 1: chain and name parity with Node beyond the reproducer's matrix.
type Coded = Error & { code: string };
const NODE_CA_HINT = "; if the root CA is installed locally, try running Node.js with --use-system-ca";
const bases = new Map<string, string>();
for (const arg of process.argv.slice(2)) {
  const equals = arg.indexOf("=");
  bases.set(arg.slice(0, equals), arg.slice(equals + 1));
}
async function attempt(label: string): Promise<void> {
  const base = bases.get(label);
  if (base === undefined) {
    console.log(label, "absent");
    return;
  }
  try {
    const response = await fetch(base + "/hello");
    console.log(label, response.status, await response.text());
  } catch (e) {
    const error = e as Error;
    const cause = error.cause as Coded | undefined;
    console.log(label, `${error.name}: ${error.message} | ${cause?.code} | ${cause?.message.replace(NODE_CA_HINT, "")}`);
  }
}
const labels = ["good", "nc-noncrit-permitted-other", "nc-noncrit-excluded", "nc-crit-permitted-ok", "nc-noncrit-ip", "eku-inter-client", "eku-inter-email",
  "badsig-leaf-by-sent-inter", "badsig-leaf-by-root", "pathlen-exceeded", "rsa1024-leaf", "rsa1024-inter", "inter-without-keycertsign", "sha1-leaf",
  "self-signed-trusted", "expired-root", "leaf-ku-keyencipherment-only", "leaf-is-ca", "leaf-no-eku", "leaf-eku-any", "cn-wildcard", "cn-wildcard-two-deep",
  "multi-cn", "multi-cn-wrong", "bmp-cn", "upper-san", "dot-san", "comma-san", "dns-plus-ipv6", "uri-email", "ipv6-mismatch", "ipv6-good", "ipv4-only-ipv6-san"];
for (const label of labels) {
  await attempt(label);
}
