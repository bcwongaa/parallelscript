// Review round 2: precedence combinations and name decoding, every server of lab2 in order.
type Coded = Error & { code: string };
const NODE_CA_HINT = "; if the root CA is installed locally, try running Node.js with --use-system-ca";
for (const arg of process.argv.slice(2)) {
  const equals = arg.indexOf("=");
  const label = arg.slice(0, equals);
  try {
    const response = await fetch(arg.slice(equals + 1) + "/hello");
    console.log(label, response.status, await response.text());
  } catch (e) {
    const error = e as Error;
    const cause = error.cause as Coded | undefined;
    console.log(label, `${error.name}: ${error.message} | ${cause?.code} | ${cause?.message.replace(NODE_CA_HINT, "")}`);
  }
}
