// Fetches argv[2] (method argv[3], default GET) and prints the status and body, or the error and its cause.
type Coded = Error & { code: string };
const href = process.argv[2];
const method = process.argv[3] ?? "GET";
try {
  const response = await fetch(href, { method });
  const text = await response.text();
  console.log(response.status, JSON.stringify(text.length > 200 ? text.slice(0, 80) + "…(" + text.length + ")" : text));
} catch (e) {
  const error = e as Error;
  const cause = error.cause as Coded | undefined;
  console.log(`${error.name}: ${error.message} | ${cause?.code} | ${cause?.message}`);
}
