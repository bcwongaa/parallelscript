#!/bin/bash
# OpenSSL s_server -www (TLS 1.3 or 1.2: two NewSessionTickets after the handshake for 1.3), fetched by pts and Node.
set -u
cd /tmp/h33/review2/p2
export PATH=$HOME/.local/node/bin:$PATH
L=/tmp/h33/review2/labdir
PORT=$1; VERSION=$2
openssl s_server -accept 127.0.0.1:$PORT -cert $L/ossl.crt -key $L/ossl.key $VERSION -www -naccept 2 > sserver_www$VERSION.out 2>&1 &
SP=$!
sleep 0.7
NODE_EXTRA_CA_CERTS=$L/trusted.pem timeout 20 ./one https://localhost:$PORT/ > pts_www$VERSION.out 2>&1; echo "pts exit $?"
NODE_EXTRA_CA_CERTS=$L/trusted.pem timeout 20 node --no-warnings --experimental-transform-types one.mts https://localhost:$PORT/ > node_www$VERSION.out 2>&1; echo "node exit $?"
kill $SP 2>/dev/null; wait $SP 2>/dev/null
echo "pts:  $(cat pts_www$VERSION.out)"; echo "node: $(cat node_www$VERSION.out)"
