// Review lab for H33a round 1: TLS servers whose certificates probe chain and name rules
// beyond the reproducer's matrix. Usage: lab <dir>; writes <dir>/args.txt (name=url per
// line) and <dir>/trusted.pem, prints "ready", serves until stdin closes.
package main

import (
	"bufio"
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/asn1"
	"encoding/pem"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
)

type authority struct {
	cert *x509.Certificate
	key  crypto.Signer
}

func must[T any](v T, err error) T {
	if err != nil {
		log.Fatal(err)
	}
	return v
}

func newKey(kind string) crypto.Signer {
	switch kind {
	case "p256":
		return must(ecdsa.GenerateKey(elliptic.P256(), rand.Reader))
	case "rsa":
		return must(rsa.GenerateKey(rand.Reader, 2048))
	case "rsa1024":
		os.Setenv("GODEBUG", "rsa1024min=0")
		return must(rsa.GenerateKey(rand.Reader, 1024))
	}
	log.Fatal("kind")
	return nil
}

func certifyDER(template *x509.Certificate, key crypto.Signer, issuer *authority) []byte {
	template.SerialNumber = must(rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 127)))
	parent, signer := template, key
	if issuer != nil {
		parent, signer = issuer.cert, issuer.key
	}
	return must(x509.CreateCertificate(rand.Reader, template, parent, key.Public(), signer))
}

func certify(template *x509.Certificate, key crypto.Signer, issuer *authority) *x509.Certificate {
	return must(x509.ParseCertificate(certifyDER(template, key, issuer)))
}

var now = time.Now()

func newAuthority(name, kind string, issuer *authority, edit func(*x509.Certificate)) *authority {
	key := newKey(kind)
	t := &x509.Certificate{
		Subject:   pkix.Name{CommonName: name, Organization: []string{"PTS review"}},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		IsCA: true, BasicConstraintsValid: true,
		KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
	}
	if edit != nil {
		edit(t)
	}
	return &authority{certify(t, key, issuer), key}
}

// leaf makes a server certificate (localhost, 127.0.0.1, ::1 by default) and the chain sent.
func leaf(issuer *authority, kind string, edit func(*x509.Certificate), corrupt bool, sent ...*x509.Certificate) (tls.Certificate, *x509.Certificate) {
	key := newKey(kind)
	t := &x509.Certificate{
		Subject:   pkix.Name{CommonName: "localhost"},
		DNSNames:  []string{"localhost"},
		IPAddresses: []net.IP{net.IPv4(127, 0, 0, 1), net.IPv6loopback},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		KeyUsage:    x509.KeyUsageDigitalSignature,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	if kind != "p256" {
		t.KeyUsage |= x509.KeyUsageKeyEncipherment
	}
	if edit != nil {
		edit(t)
	}
	der := certifyDER(t, key, issuer)
	if corrupt {
		der = append([]byte(nil), der...)
		der[len(der)-1] ^= 0x01
	}
	chain := tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}
	for _, c := range sent {
		chain.Certificate = append(chain.Certificate, c.Raw)
	}
	parsed, _ := x509.ParseCertificate(der)
	return chain, parsed
}

func writePEM(path string, certs ...*x509.Certificate) {
	var out []byte
	for _, c := range certs {
		out = append(out, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: c.Raw})...)
	}
	check(os.WriteFile(path, out, 0o644))
}

func mux() *http.ServeMux {
	m := http.NewServeMux()
	m.HandleFunc("/hello", func(w http.ResponseWriter, r *http.Request) {
		if r.TLS == nil {
			fmt.Fprintf(w, "%s plain", r.Method)
			return
		}
		fmt.Fprintf(w, "%s sni=%q %s", r.Method, r.TLS.ServerName, tls.VersionName(r.TLS.Version))
	})
	m.HandleFunc("/echo", func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		fmt.Fprintf(w, "%s length=%d read=%d auth=%q cookie=%q", r.Method, r.ContentLength, len(body), r.Header.Get("Authorization"), r.Header.Get("Cookie"))
	})
	m.HandleFunc("/redirect", func(w http.ResponseWriter, r *http.Request) {
		status, _ := strconv.Atoi(r.URL.Query().Get("status"))
		w.Header().Set("Location", r.URL.Query().Get("to"))
		w.WriteHeader(status)
	})
	m.HandleFunc("/status/", func(w http.ResponseWriter, r *http.Request) {
		status, _ := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/status/"))
		w.Header().Set("X-Status", strconv.Itoa(status))
		w.WriteHeader(status)
	})
	m.HandleFunc("/stall", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Length", "100")
		_, _ = io.WriteString(w, "partial")
		w.(http.Flusher).Flush()
		select {
		case <-r.Context().Done():
		case <-time.After(5 * time.Second):
		}
	})
	m.HandleFunc("/big", func(w http.ResponseWriter, r *http.Request) {
		piece := strings.Repeat("y", 64*1024)
		for range 160 {
			_, _ = io.WriteString(w, piece)
		}
	})
	m.HandleFunc("/n/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "n %s", strings.TrimPrefix(r.URL.Path, "/n/"))
	})
	return m
}

// serveRaw accepts connections, reads the first bytes, then holds (hold) or writes junk and closes.
func serveRaw(hold bool) string {
	l := must(net.Listen("tcp", "127.0.0.1:0"))
	go func() {
		for {
			conn, err := l.Accept()
			if err != nil {
				return
			}
			go func() {
				defer conn.Close()
				buf := make([]byte, 16384)
				_ = conn.SetReadDeadline(time.Now().Add(10 * time.Second))
				_, _ = conn.Read(buf)
				if hold {
					_, _ = io.Copy(io.Discard, conn)
					return
				}
				_, _ = conn.Write([]byte("\x16\x03\x03\x00\x05junk!"))
			}()
		}
	}()
	return strconv.Itoa(l.Addr().(*net.TCPAddr).Port)
}

var args []string

func name(n, base string) { args = append(args, n+"="+base) }

func serveTLS(address string, cert tls.Certificate, edit func(*tls.Config)) string {
	if address == "" {
		address = "127.0.0.1:0"
	}
	cfg := &tls.Config{Certificates: []tls.Certificate{cert}, NextProtos: []string{"http/1.1"}}
	if edit != nil {
		edit(cfg)
	}
	l := must(net.Listen("tcp", address))
	srv := &http.Server{Handler: mux(), ErrorLog: log.New(io.Discard, "", 0)}
	go srv.Serve(tls.NewListener(l, cfg))
	return strconv.Itoa(l.Addr().(*net.TCPAddr).Port)
}

func bmpString(s string) asn1.RawValue {
	var b []byte
	for _, u := range utf16.Encode([]rune(s)) {
		b = append(b, byte(u>>8), byte(u))
	}
	return asn1.RawValue{Class: asn1.ClassUniversal, Tag: 30, Bytes: b}
}

var oidCN = asn1.ObjectIdentifier{2, 5, 4, 3}

func check(err error) {
	if err != nil {
		log.Fatal(err)
	}
}

// rawSAN is a subjectAltName extension of one dNSName of raw bytes, which Go's own encoder refuses.
func rawSAN(name []byte) pkix.Extension {
	inner := must(asn1.Marshal(asn1.RawValue{Class: asn1.ClassContextSpecific, Tag: 2, Bytes: name}))
	value := must(asn1.Marshal(asn1.RawValue{Class: asn1.ClassUniversal, Tag: asn1.TagSequence, IsCompound: true, Bytes: inner}))
	return pkix.Extension{Id: asn1.ObjectIdentifier{2, 5, 29, 17}, Value: value}
}

func main() {
	dir := os.Args[1]
	expired := func(c *x509.Certificate) { c.NotBefore, c.NotAfter = now.Add(-48*time.Hour), now.Add(-24*time.Hour) }
	root := newAuthority("Review2 Root", "p256", nil, nil)
	rsaRoot := newAuthority("Review2 RSA Root", "rsa", nil, nil)
	weakRoot := newAuthority("Review2 RSA 1024 Root", "rsa1024", nil, nil)
	ncRoot := newAuthority("Review2 NC Root", "p256", nil, func(c *x509.Certificate) { c.PermittedDNSDomains = []string{"localhost"} })
	untrustedRoot := newAuthority("Review2 Untrusted Root", "p256", nil, nil)
	fakeRoot := newAuthority("Review2 Root", "p256", nil, nil) // the trusted root's name, another key
	partialRoot := newAuthority("Review2 Partial Root", "p256", nil, nil)
	partialInter := newAuthority("Review2 Partial Intermediate", "p256", partialRoot, nil)
	writePEM(filepath.Join(dir, "trusted.pem"), root.cert, rsaRoot.cert, weakRoot.cert, ncRoot.cert, partialInter.cert)

	inter := newAuthority("Review2 Intermediate", "p256", root, nil)
	fakeInter := newAuthority("Review2 Intermediate", "p256", root, nil) // the same name, another key
	expiredInter := newAuthority("Review2 Expired Intermediate", "p256", root, expired)
	ekuInter := newAuthority("Review2 clientAuth Intermediate", "p256", root, func(c *x509.Certificate) { c.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth} })
	ekuUntrusted := newAuthority("Review2 clientAuth Intermediate (untrusted)", "p256", untrustedRoot, func(c *x509.Certificate) { c.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth} })
	ncInter := newAuthority("Review2 NC Intermediate", "p256", root, func(c *x509.Certificate) { c.PermittedDNSDomains = []string{"localhost"} })
	pathZeroExpired := newAuthority("Review2 Pathlen 0 (expired)", "p256", root, func(c *x509.Certificate) { c.MaxPathLen, c.MaxPathLenZero = 0, true; expired(c) })
	underPathZeroExpired := newAuthority("Review2 Under pathlen 0", "p256", pathZeroExpired, nil)
	notCAKey := newKey("p256")
	notCAExpired := &authority{certify(&x509.Certificate{Subject: pkix.Name{CommonName: "Review2 Not a CA (expired)"}, NotBefore: now.Add(-48 * time.Hour), NotAfter: now.Add(-24 * time.Hour),
		KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature, BasicConstraintsValid: true}, notCAKey, root), notCAKey}
	notCAKey2 := newKey("p256")
	notCA := &authority{certify(&x509.Certificate{Subject: pkix.Name{CommonName: "Review2 Not a CA"}, NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageDigitalSignature, BasicConstraintsValid: true}, notCAKey2, root), notCAKey2}
	noCertSign := newAuthority("Review2 no keyCertSign", "p256", root, func(c *x509.Certificate) { c.KeyUsage = x509.KeyUsageDigitalSignature })
	sha1Inter := newAuthority("Review2 SHA-1 Intermediate", "p256", rsaRoot, func(c *x509.Certificate) { c.SignatureAlgorithm = x509.SHA1WithRSA })
	_ = sha1Inter

	add := func(n string, cert tls.Certificate) { name(n, "https://localhost:"+serveTLS("", cert, nil)) }
	c := func(issuer *authority, kind string, edit func(*x509.Certificate), corrupt bool, sent ...*x509.Certificate) tls.Certificate {
		ch, _ := leaf(issuer, kind, edit, corrupt, sent...)
		return ch
	}
	add("good", c(root, "p256", nil, false))
	add("expired-leaf+badsig-by-inter", c(inter, "p256", expired, true, inter.cert))
	add("expired-inter+badsig-leaf", c(expiredInter, "p256", nil, true, expiredInter.cert))
	badInter := *inter.cert
	badInterDER := append([]byte(nil), inter.cert.Raw...)
	badInterDER[len(badInterDER)-1] ^= 1
	badInter.Raw = badInterDER
	add("badsig-inter-by-root", c(inter, "p256", nil, false, &badInter))
	add("eku-inter+untrusted", c(ekuUntrusted, "p256", nil, false, ekuUntrusted.cert))
	add("eku-inter+untrusted-root-sent", c(ekuUntrusted, "p256", nil, false, ekuUntrusted.cert, untrustedRoot.cert))
	add("eku-inter+badsig-leaf", c(ekuInter, "p256", nil, true, ekuInter.cert))
	add("eku-inter+expired-leaf", c(ekuInter, "p256", expired, false, ekuInter.cert))
	add("nc-inter+expired-leaf", c(ncInter, "p256", func(x *x509.Certificate) { x.IPAddresses = nil; expired(x) }, false, ncInter.cert))
	add("nc-root-direct", c(ncRoot, "p256", func(x *x509.Certificate) { x.IPAddresses = nil }, false))
	add("pathlen+expired-inter1", c(underPathZeroExpired, "p256", nil, false, underPathZeroExpired.cert, pathZeroExpired.cert))
	add("notca-issuer-expired", c(notCAExpired, "p256", nil, false, notCAExpired.cert))
	add("notca-issuer+expired-leaf", c(notCA, "p256", expired, false, notCA.cert))
	add("nocertsign-inter+expired-leaf", c(noCertSign, "p256", expired, false, noCertSign.cert))
	add("same-name-fake-root", c(fakeRoot, "p256", nil, false))
	add("same-name-fake-root-sent", c(fakeRoot, "p256", nil, false, fakeRoot.cert))
	add("same-name-fake-inter-real-sent", c(fakeInter, "p256", nil, false, inter.cert))
	add("weak-root-trusted", c(weakRoot, "p256", nil, false))
	add("weak-leaf+expired", c(root, "rsa1024", expired, false))
	add("lone-untrusted+weak-leaf", c(untrustedRoot, "rsa1024", nil, false))
	add("untrusted-inter-sent+weak-leaf", c(ekuUntrusted, "rsa1024", func(x *x509.Certificate) {}, false, newAuthority("Review2 Untrusted plain inter", "p256", untrustedRoot, nil).cert))
	plainUntrustedInter := newAuthority("Review2 Untrusted inter 2", "p256", untrustedRoot, nil)
	add("untrusted-inter2-sent+weak-leaf", c(plainUntrustedInter, "rsa1024", nil, false, plainUntrustedInter.cert))
	add("sha1-inter", c(sha1Inter, "p256", nil, false, sha1Inter.cert))
	add("partial-chain-trusted-inter", c(partialInter, "p256", nil, false))
	bmpOdd := bmpString("localhost")
	bmpOdd.Bytes = append(bmpOdd.Bytes, 0x41)
	oddSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: bmpOdd}}}))
	add("bmp-cn-odd-length", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = oddSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	uni := asn1.RawValue{Class: asn1.ClassUniversal, Tag: 28}
	for _, r := range "localhost" {
		uni.Bytes = append(uni.Bytes, 0, 0, 0, byte(r))
	}
	uniSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: uni}}}))
	add("universal-cn", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = uniSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	uniBad := asn1.RawValue{Class: asn1.ClassUniversal, Tag: 28, Bytes: append(append([]byte(nil), uni.Bytes...), 0)}
	uniBadSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: uniBad}}}))
	add("universal-cn-bad-length", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = uniBadSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	uniHuge := asn1.RawValue{Class: asn1.ClassUniversal, Tag: 28, Bytes: append([]byte{0x7f, 0xff, 0xff, 0xff, 0x00, 0x00, 0xd8, 0x00}, uni.Bytes...)}
	uniHugeSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: uniHuge}}}))
	add("universal-cn-invalid-code-points", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = uniHugeSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	bmpSur := bmpString("localhost")
	bmpSur.Bytes = append([]byte{0xd8, 0x3d, 0xde, 0x00}, bmpSur.Bytes...)
	bmpSurSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: bmpSur}}}))
	add("bmp-cn-surrogates", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = bmpSurSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	interA := newAuthority("Review2 Upper Intermediate", "p256", root, nil)
	interB := newAuthority("Review2 Lower Intermediate", "p256", interA, nil)
	add("chain-in-order", c(interB, "p256", nil, false, interB.cert, interA.cert))
	add("chain-misordered", c(interB, "p256", nil, false, interA.cert, interB.cert))
	add("chain-root-before-intermediate", c(inter, "p256", nil, false, root.cert, inter.cert))
	for i, raw := range [][]byte{[]byte("caf\xe9.example"), []byte("a\x01b.example"), []byte("q\"uote.example"), []byte("back\\slash.example"), []byte("it's.example"), []byte("ok.example")} {
		ext := rawSAN(raw)
		add("san-bytes-"+strconv.Itoa(i), c(root, "p256", func(x *x509.Certificate) { x.DNSNames, x.IPAddresses = nil, nil; x.ExtraExtensions = []pkix.Extension{ext} }, false))
	}
	check(os.WriteFile(filepath.Join(dir, "args.txt"), []byte(strings.Join(args, "\n")+"\n"), 0o644))
	fmt.Println("ready")
	io.Copy(io.Discard, bufio.NewReader(os.Stdin))
}
