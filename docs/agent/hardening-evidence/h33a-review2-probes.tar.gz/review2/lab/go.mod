module reviewlab

go 1.26
