// Review lab for H33a round 1: TLS servers whose certificates probe chain and name rules
// beyond the reproducer's matrix. Usage: lab <dir>; writes <dir>/args.txt (name=url per
// line) and <dir>/trusted.pem, prints "ready", serves until stdin closes.
package main

import (
	"bufio"
	"crypto"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/asn1"
	"encoding/pem"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
	"unicode/utf16"
)

type authority struct {
	cert *x509.Certificate
	key  crypto.Signer
}

func must[T any](v T, err error) T {
	if err != nil {
		log.Fatal(err)
	}
	return v
}

func newKey(kind string) crypto.Signer {
	switch kind {
	case "p256":
		return must(ecdsa.GenerateKey(elliptic.P256(), rand.Reader))
	case "rsa":
		return must(rsa.GenerateKey(rand.Reader, 2048))
	case "rsa1024":
		os.Setenv("GODEBUG", "rsa1024min=0")
		return must(rsa.GenerateKey(rand.Reader, 1024))
	}
	log.Fatal("kind")
	return nil
}

func certifyDER(template *x509.Certificate, key crypto.Signer, issuer *authority) []byte {
	template.SerialNumber = must(rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 127)))
	parent, signer := template, key
	if issuer != nil {
		parent, signer = issuer.cert, issuer.key
	}
	return must(x509.CreateCertificate(rand.Reader, template, parent, key.Public(), signer))
}

func certify(template *x509.Certificate, key crypto.Signer, issuer *authority) *x509.Certificate {
	return must(x509.ParseCertificate(certifyDER(template, key, issuer)))
}

var now = time.Now()

func newAuthority(name, kind string, issuer *authority, edit func(*x509.Certificate)) *authority {
	key := newKey(kind)
	t := &x509.Certificate{
		Subject:   pkix.Name{CommonName: name, Organization: []string{"PTS review"}},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		IsCA: true, BasicConstraintsValid: true,
		KeyUsage: x509.KeyUsageCertSign | x509.KeyUsageCRLSign | x509.KeyUsageDigitalSignature,
	}
	if edit != nil {
		edit(t)
	}
	return &authority{certify(t, key, issuer), key}
}

// leaf makes a server certificate (localhost, 127.0.0.1, ::1 by default) and the chain sent.
func leaf(issuer *authority, kind string, edit func(*x509.Certificate), corrupt bool, sent ...*x509.Certificate) (tls.Certificate, *x509.Certificate) {
	key := newKey(kind)
	t := &x509.Certificate{
		Subject:   pkix.Name{CommonName: "localhost"},
		DNSNames:  []string{"localhost"},
		IPAddresses: []net.IP{net.IPv4(127, 0, 0, 1), net.IPv6loopback},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour),
		KeyUsage:    x509.KeyUsageDigitalSignature,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	if kind != "p256" {
		t.KeyUsage |= x509.KeyUsageKeyEncipherment
	}
	if edit != nil {
		edit(t)
	}
	der := certifyDER(t, key, issuer)
	if corrupt {
		der = append([]byte(nil), der...)
		der[len(der)-1] ^= 0x01
	}
	chain := tls.Certificate{Certificate: [][]byte{der}, PrivateKey: key}
	for _, c := range sent {
		chain.Certificate = append(chain.Certificate, c.Raw)
	}
	parsed, _ := x509.ParseCertificate(der)
	return chain, parsed
}

func writePEM(path string, certs ...*x509.Certificate) {
	var out []byte
	for _, c := range certs {
		out = append(out, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: c.Raw})...)
	}
	check(os.WriteFile(path, out, 0o644))
}

func mux() *http.ServeMux {
	m := http.NewServeMux()
	m.HandleFunc("/hello", func(w http.ResponseWriter, r *http.Request) {
		if r.TLS == nil {
			fmt.Fprintf(w, "%s plain", r.Method)
			return
		}
		fmt.Fprintf(w, "%s sni=%q %s", r.Method, r.TLS.ServerName, tls.VersionName(r.TLS.Version))
	})
	m.HandleFunc("/echo", func(w http.ResponseWriter, r *http.Request) {
		body, _ := io.ReadAll(r.Body)
		fmt.Fprintf(w, "%s length=%d read=%d auth=%q cookie=%q", r.Method, r.ContentLength, len(body), r.Header.Get("Authorization"), r.Header.Get("Cookie"))
	})
	m.HandleFunc("/redirect", func(w http.ResponseWriter, r *http.Request) {
		status, _ := strconv.Atoi(r.URL.Query().Get("status"))
		w.Header().Set("Location", r.URL.Query().Get("to"))
		w.WriteHeader(status)
	})
	m.HandleFunc("/status/", func(w http.ResponseWriter, r *http.Request) {
		status, _ := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/status/"))
		w.Header().Set("X-Status", strconv.Itoa(status))
		w.WriteHeader(status)
	})
	m.HandleFunc("/stall", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Length", "100")
		_, _ = io.WriteString(w, "partial")
		w.(http.Flusher).Flush()
		select {
		case <-r.Context().Done():
		case <-time.After(5 * time.Second):
		}
	})
	m.HandleFunc("/big", func(w http.ResponseWriter, r *http.Request) {
		piece := strings.Repeat("y", 64*1024)
		for range 160 {
			_, _ = io.WriteString(w, piece)
		}
	})
	m.HandleFunc("/n/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "n %s", strings.TrimPrefix(r.URL.Path, "/n/"))
	})
	return m
}

// serveRaw accepts connections, reads the first bytes, then holds (hold) or writes junk and closes.
func serveRaw(hold bool) string {
	l := must(net.Listen("tcp", "127.0.0.1:0"))
	go func() {
		for {
			conn, err := l.Accept()
			if err != nil {
				return
			}
			go func() {
				defer conn.Close()
				buf := make([]byte, 16384)
				_ = conn.SetReadDeadline(time.Now().Add(10 * time.Second))
				_, _ = conn.Read(buf)
				if hold {
					_, _ = io.Copy(io.Discard, conn)
					return
				}
				_, _ = conn.Write([]byte("\x16\x03\x03\x00\x05junk!"))
			}()
		}
	}()
	return strconv.Itoa(l.Addr().(*net.TCPAddr).Port)
}

var args []string

func name(n, base string) { args = append(args, n+"="+base) }

func serveTLS(address string, cert tls.Certificate, edit func(*tls.Config)) string {
	if address == "" {
		address = "127.0.0.1:0"
	}
	cfg := &tls.Config{Certificates: []tls.Certificate{cert}, NextProtos: []string{"http/1.1"}}
	if edit != nil {
		edit(cfg)
	}
	l := must(net.Listen("tcp", address))
	srv := &http.Server{Handler: mux(), ErrorLog: log.New(io.Discard, "", 0)}
	go srv.Serve(tls.NewListener(l, cfg))
	return strconv.Itoa(l.Addr().(*net.TCPAddr).Port)
}

func bmpString(s string) asn1.RawValue {
	var b []byte
	for _, u := range utf16.Encode([]rune(s)) {
		b = append(b, byte(u>>8), byte(u))
	}
	return asn1.RawValue{Class: asn1.ClassUniversal, Tag: 30, Bytes: b}
}

var oidCN = asn1.ObjectIdentifier{2, 5, 4, 3}

func main() {
	dir := os.Args[1]
	root := newAuthority("Review Root", "p256", nil, nil)
	rsaRoot := newAuthority("Review RSA Root", "rsa", nil, nil)
	expiredRoot := newAuthority("Review Expired Root", "p256", nil, func(c *x509.Certificate) {
		c.NotBefore, c.NotAfter = now.Add(-48*time.Hour), now.Add(-24*time.Hour)
	})
	selfSigned, selfSignedCert := leaf(nil, "p256", nil, false)
	writePEM(filepath.Join(dir, "trusted.pem"), root.cert, rsaRoot.cert, expiredRoot.cert, selfSignedCert)

	dnsOnly := func(names ...string) func(*x509.Certificate) {
		return func(c *x509.Certificate) { c.Subject.CommonName = names[0]; c.DNSNames, c.IPAddresses = names, nil }
	}
	cnOnly := func(cn string) func(*x509.Certificate) {
		return func(c *x509.Certificate) { c.Subject.CommonName = cn; c.DNSNames, c.IPAddresses = nil, nil }
	}
	interWith := func(n string, edit func(*x509.Certificate)) *authority { return newAuthority(n, "p256", root, edit) }

	ncOther := interWith("NC permitted example.org (non-critical)", func(c *x509.Certificate) { c.PermittedDNSDomains = []string{"example.org"} })
	ncExcl := interWith("NC excluded localhost (non-critical)", func(c *x509.Certificate) { c.ExcludedDNSDomains = []string{"localhost"} })
	ncCritOK := interWith("NC permitted localhost (critical)", func(c *x509.Certificate) {
		c.PermittedDNSDomains = []string{"localhost"}
		c.PermittedDNSDomainsCritical = true
	})
	ncIP := interWith("NC permitted IP 10.0.0.0/8 (non-critical)", func(c *x509.Certificate) {
		c.PermittedIPRanges = []*net.IPNet{{IP: net.IPv4(10, 0, 0, 0).To4(), Mask: net.CIDRMask(8, 32)}}
	})
	ekuClient := interWith("EKU clientAuth intermediate", func(c *x509.Certificate) { c.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth} })
	ekuEmail := interWith("EKU emailProtection intermediate", func(c *x509.Certificate) { c.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageEmailProtection} })
	inter := interWith("Review Intermediate", nil)
	pathZero := interWith("Pathlen 0 intermediate", func(c *x509.Certificate) { c.MaxPathLen, c.MaxPathLenZero = 0, true })
	underPathZero := newAuthority("Under pathlen 0", "p256", pathZero, nil)
	rsa1024Inter := newAuthority("RSA 1024 intermediate", "rsa1024", root, nil)
	noKUCertSign := interWith("Intermediate without keyCertSign", func(c *x509.Certificate) { c.KeyUsage = x509.KeyUsageDigitalSignature })

	add := func(n string, cert tls.Certificate) { name(n, "https://localhost:"+serveTLS("", cert, nil)) }
	c := func(issuer *authority, kind string, edit func(*x509.Certificate), corrupt bool, sent ...*x509.Certificate) tls.Certificate {
		ch, _ := leaf(issuer, kind, edit, corrupt, sent...)
		return ch
	}
	add("good", c(root, "p256", nil, false))
	add("nc-noncrit-permitted-other", c(ncOther, "p256", dnsOnly("localhost"), false, ncOther.cert))
	add("nc-noncrit-excluded", c(ncExcl, "p256", dnsOnly("localhost"), false, ncExcl.cert))
	add("nc-crit-permitted-ok", c(ncCritOK, "p256", dnsOnly("localhost"), false, ncCritOK.cert))
	name("nc-noncrit-ip", "https://127.0.0.1:"+serveTLS("", c(ncIP, "p256", func(x *x509.Certificate) { x.DNSNames = nil; x.IPAddresses = []net.IP{net.IPv4(127, 0, 0, 1)} }, false, ncIP.cert), nil))
	add("eku-inter-client", c(ekuClient, "p256", nil, false, ekuClient.cert))
	add("eku-inter-email", c(ekuEmail, "p256", nil, false, ekuEmail.cert))
	add("badsig-leaf-by-sent-inter", c(inter, "p256", nil, true, inter.cert))
	add("badsig-leaf-by-root", c(root, "p256", nil, true))
	add("pathlen-exceeded", c(underPathZero, "p256", nil, false, underPathZero.cert, pathZero.cert))
	add("rsa1024-leaf", c(root, "rsa1024", nil, false))
	add("rsa1024-inter", c(rsa1024Inter, "p256", nil, false, rsa1024Inter.cert))
	add("inter-without-keycertsign", c(noKUCertSign, "p256", nil, false, noKUCertSign.cert))
	add("sha1-leaf", c(rsaRoot, "rsa", func(x *x509.Certificate) { x.SignatureAlgorithm = x509.SHA1WithRSA }, false))
	add("self-signed-trusted", selfSigned)
	add("expired-root", c(expiredRoot, "p256", nil, false))
	add("leaf-ku-keyencipherment-only", c(root, "p256", func(x *x509.Certificate) { x.KeyUsage = x509.KeyUsageKeyEncipherment }, false))
	add("leaf-is-ca", c(root, "p256", func(x *x509.Certificate) { x.IsCA = true; x.KeyUsage |= x509.KeyUsageCertSign }, false))
	add("leaf-no-eku", c(root, "p256", func(x *x509.Certificate) { x.ExtKeyUsage = nil }, false))
	add("leaf-eku-any", c(root, "p256", func(x *x509.Certificate) { x.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageAny} }, false))
	name("cn-wildcard", "https://a.pts.localhost:"+serveTLS("", c(root, "p256", cnOnly("*.pts.localhost"), false), nil))
	name("cn-wildcard-two-deep", "https://a.b.pts.localhost:"+serveTLS("", c(root, "p256", cnOnly("*.pts.localhost"), false), nil))
	add("multi-cn", c(root, "p256", func(x *x509.Certificate) {
		x.Subject = pkix.Name{ExtraNames: []pkix.AttributeTypeAndValue{{Type: oidCN, Value: "other.example"}, {Type: oidCN, Value: "localhost"}}}
		x.DNSNames, x.IPAddresses = nil, nil
	}, false))
	add("multi-cn-wrong", c(root, "p256", func(x *x509.Certificate) {
		x.Subject = pkix.Name{ExtraNames: []pkix.AttributeTypeAndValue{{Type: oidCN, Value: "other.example"}, {Type: oidCN, Value: "another.example"}}}
		x.DNSNames, x.IPAddresses = nil, nil
	}, false))
	bmpSubject := must(asn1.Marshal(pkix.RDNSequence{{{Type: oidCN, Value: bmpString("localhost")}}}))
	add("bmp-cn", c(root, "p256", func(x *x509.Certificate) { x.RawSubject = bmpSubject; x.DNSNames, x.IPAddresses = nil, nil }, false))
	add("upper-san", c(root, "p256", dnsOnly("LOCALHOST"), false))
	add("dot-san", c(root, "p256", dnsOnly("localhost."), false))
	add("comma-san", c(root, "p256", dnsOnly("localhost, DNS:x"), false))
	add("dns-plus-ipv6", c(root, "p256", func(x *x509.Certificate) { x.DNSNames = []string{"other.example"}; x.IPAddresses = []net.IP{net.ParseIP("::1"), net.IPv4(10, 1, 2, 3)} }, false))
	add("uri-email", c(root, "p256", func(x *x509.Certificate) {
		x.DNSNames, x.IPAddresses = []string{"other.example"}, nil
		x.EmailAddresses = []string{"a@b.example"}
	}, false))
	if l, err := net.Listen("tcp", "[::1]:0"); err == nil {
		l.Close()
		name("ipv6-mismatch", "https://[::1]:"+serveTLS("[::1]:0", c(root, "p256", func(x *x509.Certificate) { x.DNSNames = []string{"localhost"}; x.IPAddresses = []net.IP{net.IPv4(127, 0, 0, 1), net.ParseIP("::2")} }, false), nil))
		name("ipv6-good", "https://[::1]:"+serveTLS("[::1]:0", c(root, "p256", nil, false), nil))
	}
	name("ipv4-only-ipv6-san", "https://127.0.0.1:"+serveTLS("", c(root, "p256", func(x *x509.Certificate) { x.IPAddresses = []net.IP{net.ParseIP("::ffff:127.0.0.1")} }, false), nil))
	name("holds", "https://localhost:"+serveRaw(true))
	name("junk", "https://localhost:"+serveRaw(false))
	name("untrusted", "https://localhost:"+serveTLS("", c(newAuthority("Untrusted", "p256", nil, nil), "p256", nil, false), nil))
	name("wrong-host", "https://localhost:"+serveTLS("", c(root, "p256", dnsOnly("other.example"), false), nil))
	name("lone-untrusted-client-eku", "https://localhost:"+serveTLS("", c(newAuthority("Untrusted 2", "p256", nil, nil), "p256", func(x *x509.Certificate) { x.ExtKeyUsage = []x509.ExtKeyUsage{x509.ExtKeyUsageClientAuth} }, false), nil))
	plain := must(net.Listen("tcp", "127.0.0.1:0"))
	go (&http.Server{Handler: mux()}).Serve(plain)
	name("plain", "http://127.0.0.1:"+strconv.Itoa(plain.Addr().(*net.TCPAddr).Port))

	check(os.WriteFile(filepath.Join(dir, "args.txt"), []byte(strings.Join(args, "\n")+"\n"), 0o644))
	// keys for openssl s_server probes
	k := newKey("p256")
	der := certifyDER(&x509.Certificate{Subject: pkix.Name{CommonName: "localhost"}, DNSNames: []string{"localhost"},
		NotBefore: now.Add(-time.Hour), NotAfter: now.Add(24 * time.Hour), KeyUsage: x509.KeyUsageDigitalSignature,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}, k, root)
	check(os.WriteFile(filepath.Join(dir, "ossl.crt"), pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der}), 0o644))
	kder := must(x509.MarshalPKCS8PrivateKey(k))
	check(os.WriteFile(filepath.Join(dir, "ossl.key"), pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: kder}), 0o600))
	fmt.Println("ready")
	io.Copy(io.Discard, bufio.NewReader(os.Stdin))
}

func check(err error) {
	if err != nil {
		log.Fatal(err)
	}
}
