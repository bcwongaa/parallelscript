#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned char lower(unsigned char c) { return c >= 'A' && c <= 'Z' ? (unsigned char)(c + 32) : c; }

static bool equal_ignoring_case(const void *a, const void *b, size_t len) {
  const unsigned char *x = a, *y = b;
  for (size_t i = 0; i < len; i++) {
    if (lower(x[i]) != lower(y[i])) {
      return false;
    }
  }
  return true;
}

/* How many labels a name of len bytes has: one more than its dots. */
static size_t labels(const void *name, size_t len) {
  size_t count = 1;
  for (const char *p = name, *end = p + len; (p = memchr(p, '.', (size_t)(end - p))) != NULL; p++) {
    count++;
  }
  return count;
}

/* Whether a label of len bytes holds an IDNA A-label's prefix, xn--, which takes no wildcard. */
static bool holds_idna_prefix(const unsigned char *label, size_t len) {
  for (size_t i = 0; i + 4 <= len; i++) {
    if (equal_ignoring_case(label + i, "xn--", 4)) {
      return true;
    }
  }
  return false;
}

/*
 * Whether a certificate's DNS name (a subject alternative name or a common name, len
 * bytes) names host, as Node's check() decides: as many labels as the host, none empty,
 * printable ASCII only, all but the first equal to the host's ignoring case; and the
 * first equal too, or matched by one wildcard (a*b) in a name of three labels or more,
 * but not in an IDNA label.
 */
static bool pattern_names(const unsigned char *pattern, size_t len, const char *host, size_t host_len) {
  if (len > 0 && pattern[len - 1] == '.') {
    len--;
  }
  if (len == 0 || labels(pattern, len) != labels(host, host_len)) {
    return false;
  }
  for (size_t i = 0; i < len; i++) {
    if (pattern[i] < 0x21 || pattern[i] > 0x7F || (pattern[i] == '.' && (i == 0 || i + 1 == len || pattern[i + 1] == '.'))) {
      return false;
    }
  }
  const unsigned char *dot = memchr(pattern, '.', len);
  const char *host_dot = memchr(host, '.', host_len);
  size_t first = dot != NULL ? (size_t)(dot - pattern) : len, host_first = host_dot != NULL ? (size_t)(host_dot - host) : host_len;
  if (len - first != host_len - host_first || !equal_ignoring_case(pattern + first, host + host_first, len - first)) {
    return false;
  }
  const unsigned char *star = memchr(pattern, '*', first);
  if (star == NULL || holds_idna_prefix(pattern, first)) {
    return first == host_first && equal_ignoring_case(pattern, host, first);
  }
  size_t prefix = (size_t)(star - pattern), suffix = first - prefix - 1;
  if (memchr(star + 1, '*', suffix) != NULL || labels(pattern, len) <= 2 || prefix + suffix > host_first) {
    return false;
  }
  return equal_ignoring_case(pattern, host, prefix) && equal_ignoring_case(star + 1, host + host_first - suffix, suffix);
}

static size_t unhex(const char *s, unsigned char *out) {
  size_t n = 0;
  for (; s[0] && s[1] && s[0] != '\t' && s[0] != '\n'; s += 2) {
    unsigned v;
    sscanf(s, "%2x", &v);
    out[n++] = (unsigned char)v;
  }
  return n;
}
int main(void) {
  char line[4096];
  while (fgets(line, sizeof line, stdin)) {
    char *tab = strchr(line, '\t');
    unsigned char host[1024], pattern[1024];
    size_t host_len = unhex(line, host);
    size_t len = unhex(tab + 1, pattern);
    /* as pts_tls_client: the host without a final dot, NUL-terminated (strndup of the URL's host stops at a NUL) */
    host[host_len] = 0;
    host_len = strlen((char *)host);
    host_len -= host_len > 0 && host[host_len - 1] == '.';
    host[host_len] = 0;
    printf("%d\n", pattern_names(pattern, len, (const char *)host, host_len) ? 1 : 0);
  }
  return 0;
}
