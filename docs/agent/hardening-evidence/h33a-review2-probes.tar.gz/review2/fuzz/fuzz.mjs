// Differential fuzz: Node's tls.checkServerIdentity (DNS SAN path) vs tls.c's pattern_names.
import tls from "node:tls";
import { execFileSync } from "node:child_process";
const hostAlpha = ["a", "b", "x", "n", "-", ".", ".", "*", "A", "B", "xn--", "1"];
const patAlpha = ["a", "b", "x", "n", "-", ".", ".", "*", "*", "A", "B", "xn--", "XN--", "\x00", "\x7f", "\x80", "\xe9", " ", "\t", "1", "~"];
let seed = Number(process.argv[2] ?? 1);
function rand(n) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; }
function gen(alpha, max) { let s = ""; const n = 1 + rand(max); for (let i = 0; i < n; i++) s += alpha[rand(alpha.length)]; return s; }
const hex = (s) => Buffer.from(s, "latin1").toString("hex");
const cases = [];
for (let i = 0; i < 200000; i++) {
  let host = gen(hostAlpha, 8);
  let pattern = rand(3) === 0 ? host.replace(/^[^.]*/, (m) => m.slice(0, rand(m.length + 1)) + "*" + m.slice(rand(m.length + 1))) : gen(patAlpha, 8);
  if (rand(4) === 0) pattern = pattern.toUpperCase();
  if (rand(5) === 0) pattern += ".";
  // Node never sees a host Node's URL parser would refuse: skip hosts with empty labels in the middle or that are IPs
  if (host === "" || host === ".") continue;
  cases.push([host, pattern]);
}
const lines = cases.map(([h, p]) => `${hex(h.toLowerCase())}\t${hex(p)}`).join("\n") + "\n";
const out = execFileSync("./harness", { input: lines, maxBuffer: 1 << 26 }).toString().trim().split("\n");
let diffs = 0;
for (let i = 0; i < cases.length; i++) {
  const [host, pattern] = cases[i];
  const nodeOk = tls.checkServerIdentity(host.toLowerCase(), { subjectaltname: "DNS:" + pattern, subject: {} }) === undefined;
  const ptsOk = out[i] === "1";
  if (nodeOk !== ptsOk) {
    if (diffs < 25) console.log(JSON.stringify({ host: host.toLowerCase(), pattern, node: nodeOk, pts: ptsOk }));
    diffs++;
  }
}
console.log("cases", cases.length, "diffs", diffs, "node-accepts", cases.filter(([h, p]) => tls.checkServerIdentity(h.toLowerCase(), { subjectaltname: "DNS:" + p, subject: {} }) === undefined).length);
