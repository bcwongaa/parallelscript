// Builds a .pts program against the ASan/UBSan runtime of the snapshot (as the tests' buildSanitized does).
package main

import (
	"context"
	"log"
	"os"
	"path/filepath"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	source, exe := os.Args[1], os.Args[2]
	ctx := context.Background()
	c, err := driver.EmitC(ctx, source)
	if err != nil {
		log.Fatal(err)
	}
	tc, err := toolchain.New()
	if err != nil {
		log.Fatal(err)
	}
	profile := toolchain.Sanitize
	if os.Getenv("REVIEW_TSAN") != "" {
		profile = toolchain.ThreadSanitize
	}
	rt, err := tc.Runtime(ctx, profile)
	if err != nil {
		log.Fatal(err)
	}
	cFile := filepath.Join(filepath.Dir(exe), filepath.Base(exe)+".c")
	if err := os.WriteFile(cFile, []byte(c), 0o644); err != nil {
		log.Fatal(err)
	}
	if err := tc.CompileProgram(ctx, rt, []string{cFile}, exe); err != nil {
		log.Fatal(err)
	}
}
