// Fetches each argument and prints its status or the cause's code and message.
type Coded = Error & { code: string };
for (const href of process.argv.slice(2)) {
  try {
    const response = await fetch(href, { method: "HEAD" });
    console.log(href, response.status);
  } catch (e) {
    const cause = (e as Error).cause as Coded | undefined;
    console.log(href, `${cause?.code} | ${cause?.message}`);
  }
}
