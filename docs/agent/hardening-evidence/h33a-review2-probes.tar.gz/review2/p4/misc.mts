// Review probe 4: HEAD/204/304 over TLS, a large POST, redirects and credentials across https origins, precedence of a lone untrusted leaf with a client-only EKU.
type Coded = Error & { code: string };
const bases = new Map<string, string>();
for (const arg of process.argv.slice(2)) {
  const equals = arg.indexOf("=");
  bases.set(arg.slice(0, equals), arg.slice(equals + 1));
}
const NODE_CA_HINT = "; if the root CA is installed locally, try running Node.js with --use-system-ca";
async function attempt(label: string, f: () => Promise<string>): Promise<void> {
  try {
    console.log(label, await f());
  } catch (e) {
    const error = e as Error;
    const cause = error.cause as Coded | undefined;
    console.log(label, `${error.name}: ${error.message} | ${cause?.code} | ${cause?.message.replace(NODE_CA_HINT, "")}`);
  }
}
const good = bases.get("good")!;
const other = bases.get("upper-san")!; // another https origin (same host, other port) whose certificate verifies
await attempt("HEAD", async () => { const r = await fetch(good + "/hello", { method: "HEAD" }); return `${r.status} ${JSON.stringify(await r.text())} ${r.headers.get("content-length")}`; });
await attempt("204", async () => { const r = await fetch(good + "/status/204"); return `${r.status} ${JSON.stringify(await r.text())}`; });
await attempt("304", async () => { const r = await fetch(good + "/status/304"); return `${r.status} ${JSON.stringify(await r.text())}`; });
await attempt("10 MB post", async () => { const r = await fetch(good + "/echo", { method: "POST", body: "z".repeat(10 * 1024 * 1024) }); return `${r.status} ${await r.text()}`; });
const creds: Record<string, string> = { authorization: "Bearer s", cookie: "c=1" };
await attempt("https to https, other port", async () => {
  const r = await fetch(good + "/redirect?status=302&to=" + encodeURIComponent(other + "/echo"), { headers: creds });
  return `${r.status} ${await r.text()}`;
});
await attempt("https to https, same origin, host in capitals", async () => {
  const r = await fetch(good + "/redirect?status=302&to=" + encodeURIComponent(good.replace("localhost", "LOCALHOST") + "/echo"), { headers: creds });
  return `${r.status} ${await r.text()}`;
});
await attempt("https to http, same host and port number", async () => {
  const r = await fetch(good + "/redirect?status=307&to=" + encodeURIComponent(good.replace("https:", "http:") + "/echo"), { headers: creds });
  return `${r.status} ${await r.text()}`;
});
await attempt("lone untrusted leaf, client-only EKU", async () => { const r = await fetch(bases.get("lone-untrusted-client-eku")! + "/hello"); return `${r.status}`; });
await attempt("trailing dot host", async () => { const r = await fetch(good.replace("localhost", "localhost.") + "/hello"); return `${r.status} ${await r.text()}`; });
