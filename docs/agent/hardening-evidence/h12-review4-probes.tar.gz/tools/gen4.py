#!/usr/bin/env python3
# gen4.py OUTDIR N SEED: straight-line write graphs over declared `string | undefined` variables
# (module scope, a function, a generator, an async function with awaits), missing values
# entering through element reads, loose bindings, rest-tuple and nested patterns, ||=/??=/&&=,
# conditionals, loops, if/else and try/finally; every read is `.length` (tsc narrows to string)
# inside a try, or an undefined test. Excludes shapes known to diverge for other reasons
# (closures: D-140; `a || b` / `a && b` values: R3-F1; chained assignments).
import random, sys, os
out, n, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
os.makedirs(out, exist_ok=True)
rng = random.Random(seed)
for case in range(n):
    k = rng.randint(int(os.environ.get("KMIN", "3")), int(os.environ.get("KMAX", "9")))
    names = [f"v{i}" for i in range(k)]
    ctx = rng.choice(["module", "function", "generator", "async", "generic"])
    pre = ["function pick(n: number): boolean { return n === 0; }", "const arr: string[] = [];", "const full: string[] = ['xy'];", "const [lb] = arr;",
           "const r: [number, ...string[]] = [1];", "const ro: { k: [number, ...string[]] } = { k: [1] };",
           "const rows: [number, ...string[]][] = [[1]];", "const rec: Record<string, string> = { a: 'r' };", "let hh = 0;"]
    def src():
        return rng.choice(['"q"', 'full[0]', 'arr[2]', 'lb', 'rec["zz"]', 'rec["a"]', 'xs[1]' if ctx == "generic" else 'arr[1]'])
    def stmt(depth=0):
        a, b, c = rng.choice(names), rng.choice(names), rng.choice(names)
        x = rng.random()
        if x < 0.25: return f"{a} = {b};"
        if x < 0.33: return f"{a} = pick({rng.randint(0,1)}) ? {b} : {c};"
        if x < 0.38: return f"{a} ||= {b};"
        if x < 0.42: return f"{a} ??= {b};"
        if x < 0.45: return f"{a} &&= {b};"
        if x < 0.58: return f"{a} = {src()};"
        if x < 0.62: return f"[hh, {a}] = r;"
        if x < 0.65: return f"({{ k: [hh, {a}] }} = ro);"
        if x < 0.67: return f"[[hh, {a}] = [0, 'dd']] = rows;"
        if x < 0.72 and depth < 2: return f"for (let i = 0; i < 2; i++) {{ {stmt(depth+1)} }}"
        if x < 0.78 and depth < 2: return f"if (pick({rng.randint(0,1)})) {{ {stmt(depth+1)} }} else {{ {stmt(depth+1)} }}"
        if x < 0.82 and depth < 2: return f"try {{ {stmt(depth+1)} }} finally {{ {read(rng.choice(names))} }}"
        if x < 0.86 and ctx in ("async",): return "await 0;"
        if x < 0.86 and ctx in ("generator",): return "yield 1;"
        return read(a)
    def read(a):
        if rng.random() < 0.15: return f"console.log('{a}u', {a} === undefined);"
        return f"try {{ console.log('{a}', {a}.length); }} catch (e) {{ console.log('{a}', (e as Error).name); }}"
    stmts = []
    for _ in range(rng.randint(k, 3 * k)):
        stmts.append(stmt()); stmts.append(read(rng.choice(names)))
    decl = [f"let {nm}: string | undefined = {src()};" for nm in names]
    if ctx == "module":
        prog = pre + decl + stmts
    else:
        head = {"function": "function run(): void {", "generator": "function* run(): Generator<number> {",
                "async": "async function run(): Promise<void> {", "generic": "function run<T extends string>(xs: T[]): void {"}[ctx]
        call = {"function": "run();", "generator": "for (const _ of run()) {}", "async": "run();", "generic": "run(['g']);"}[ctx]
        prog = pre + [head] + ["  " + s for s in decl + stmts] + ["}", call]
    open(os.path.join(out, f"f4_{seed}_{case:03d}.pts"), "w").write("\n".join(prog) + "\n")
