#!/bin/bash
# Reruns round 4's finding probes against Node, base, snap4 and fix3 (tools/run.py, process groups killed on timeout).
cd /tmp/h12/review4
W=4 python3 tools/run.py rerun-findings.json \
  p/b3/b30_typeof_string_alone.pts p/b3/b31_typeof_tested_init.pts p/b3/b32_predicate_array.pts p/b3/b34_typeof_module_var.pts \
  p/b3/b37_union_with_param.pts p/b3/b39_declared_intersection.pts p/b3/b40_typeof_number_elem.pts p/b3/b41_predicate_record.pts \
  p/a/split/a01_satisfies_union_00.pts p/a/split/a01_satisfies_union_01.pts p/a/split/a01_satisfies_union_03.pts \
  p/d/split/d04_shorthand_element_loose_01.pts p/a/split/a05_numbers_objects_05.pts p/r/split/r01_or_loose_right_00.pts
