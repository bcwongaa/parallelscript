#!/usr/bin/env python3
# gen_big.py N DEG OUT [fn]: N `string | undefined` variables, each written from DEG random others
# (under always-false ifs), one element read entering at v0; reads of a few at the end.
import random, sys
n, deg, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
fn = len(sys.argv) > 4
rng = random.Random(n * 7 + deg)
L = ["const empty: string[] = [];"]
body = [f"let v{i}: string | undefined = \"v{i}\";" for i in range(n)]
for i in range(n):
    for j in rng.sample(range(n), deg):
        body.append(f"if (empty.length > {rng.randint(1, 9)}) v{i} = v{j};")
body.append("if (empty.length === 0) v0 = empty[3];")
for i in range(0, n, max(1, n // 5)):
    body.append(f"try {{ console.log(v{i}.length); }} catch (e) {{ console.log('v{i}', (e as Error).name); }}")
if fn:  # module variables; the writes spread over functions of 40 statements each
    decls, writes, reads = body[:n], [b for b in body[n:] if b.startswith("if")], [b for b in body[n:] if b.startswith("try")]
    L += decls
    for k in range(0, len(writes), 40):
        L += [f"function w{k}(): void {{"] + ["  " + b for b in writes[k:k + 40]] + ["}", f"w{k}();"]
    L += reads
else:
    L += body
open(out, "w").write("\n".join(L) + "\n")
