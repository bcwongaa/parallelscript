// shorthand defaults reading past the end and loose locals, into declared unions and plain names
const arr: string[] = ["a"];
const empty: string[] = [];
const [lb] = empty;
const e: string = "";
function attempt(label: string, f: () => void): void { try { f(); } catch (err) { console.log(label, (err as Error).name); } }
attempt("loose", () => { const o: { p?: string } = {}; let p: string | undefined = "p"; ({ p = lb } = o); console.log(p === undefined); console.log(p.length); });
