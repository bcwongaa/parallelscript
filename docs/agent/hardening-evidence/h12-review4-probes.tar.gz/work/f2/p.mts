// an element read under `satisfies string | undefined`, whose context takes undefined
const arr: string[] = ["a"];
const empty: string[] = [];
const [lb] = empty;
const [lb2] = empty;
const e: string = "";
const c: string = "c";
function attempt(label: string, f: () => void): void { try { f(); } catch (err) { console.log(label, (err as Error).name); } }
attempt("init", () => { const x: string | undefined = arr[3] satisfies string | undefined; console.log(x.length); });
