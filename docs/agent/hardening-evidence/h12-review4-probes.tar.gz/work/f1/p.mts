// a predicate narrowing v: T to T & Record<string, string>, a missing key
function isRec(v: unknown): v is Record<string, string> { return typeof v === "object" && v !== null; }
function g<T>(v: T): number {
  let x: string | undefined = "x";
  if (isRec(v)) x = v["zz"];
  return x.length;
}
try { console.log(g({ a: "1" } as Record<string, string>)); } catch (e) { console.log("g", (e as Error).name); }
