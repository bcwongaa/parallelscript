#!/usr/bin/env bash
# Archives the reproducer's probes, generator, runner, matrix results, prototypes' overlay
# sources and tests as /tmp/h10/repro-probes.tar.gz, without binaries (CLIs, case binaries).
set -u
cd /tmp/h10 || exit 2
tar -czf /tmp/h10/repro-probes.tar.gz \
  --exclude='protoA/pts' --exclude='protoB/pts' --exclude='protoB/pts_ab' \
  --exclude='protoC/pts_abc' --exclude='protoConly/pts_c' --exclude='*.bin' \
  quick matrix tests protoA protoB protoC protoConly build.log
echo "tar exit=$?"
ls -la /tmp/h10/repro-probes.tar.gz
tar -tzf /tmp/h10/repro-probes.tar.gz | awk -F/ '{print $1}' | sort | uniq -c
echo "largest:"
tar -tzvf /tmp/h10/repro-probes.tar.gz | sort -k3 -n -r | head -3
