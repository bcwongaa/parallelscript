#!/usr/bin/env python3
"""Builds each test with a pts CLI ($PTS, default HEAD's) and compares its stdout and exit
code with the test's `// expect:` block (and `// exit:`), under each `// threads:` value,
as TestRun does (a quick stand-in for prototypes; the real check is the go test harness).
Usage: check.py test.pts...   prints PASS/FAIL per test with the first differing line."""
import os
import re
import subprocess
import sys
import tempfile

PTS = os.environ.get("PTS", "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4/pts-bin/pts")
ENV = dict(os.environ, TZ="America/New_York")


def parse(src):
    lines = src.split("\n")
    expect, exit_code, threads = None, 0, [None]
    i = 0
    while i < len(lines):
        line = lines[i]
        if line == "// expect:":
            out = []
            i += 1
            while i < len(lines) and lines[i].startswith("//") and not re.match(r"// (expect|exit|stderr|error|no-diff|skip|threads):", lines[i]):
                text = lines[i][2:]
                out.append(text[1:] if text.startswith(" ") else text)
                i += 1
            expect = "\n".join(out) + "\n"
            continue
        m = re.match(r"// exit: (\d+)$", line)
        if m:
            exit_code = int(m.group(1))
        m = re.match(r"// threads: (.*)$", line)
        if m:
            threads = [int(t) for t in m.group(1).split()]
        i += 1
    return expect, exit_code, threads


def main():
    for path in sys.argv[1:]:
        name = os.path.basename(path)[:-4]
        expect, exit_code, threads = parse(open(path).read())
        with tempfile.TemporaryDirectory(dir="/tmp/h10") as d:
            b = subprocess.run([PTS, "build", os.path.abspath(path), "-o", os.path.join(d, "bin")], cwd=d, env=ENV, capture_output=True, text=True, timeout=180)
            if b.returncode != 0:
                first = (b.stdout + b.stderr).strip().splitlines()
                print(f"FAIL {name}: build exit {b.returncode}: {first[0] if first else ''}")
                continue
            verdict = "PASS"
            for t in threads:
                env = dict(ENV)
                if t is not None:
                    env["PTS_THREADS"] = str(t)
                try:
                    p = subprocess.run([os.path.join(d, "bin")], cwd=d, env=env, capture_output=True, text=True, timeout=60)
                except subprocess.TimeoutExpired:
                    verdict = f"FAIL {name}: timeout (threads {t})"
                    break
                if p.stdout != expect or p.returncode != exit_code:
                    got, want = p.stdout.splitlines(), expect.splitlines()
                    k = next((k for k in range(max(len(got), len(want))) if (got[k] if k < len(got) else None) != (want[k] if k < len(want) else None)), None)
                    err = next((l for l in p.stderr.splitlines() if "Error" in l), "")
                    verdict = f"FAIL {name} (threads {t}, exit {p.returncode}): line {k + 1 if k is not None else '?'}: got {got[k] if k is not None and k < len(got) else '<none>'!r} want {want[k] if k is not None and k < len(want) else '<none>'!r} {err}"
                    break
            print(verdict if verdict != "PASS" else f"PASS {name}")


if __name__ == "__main__":
    main()
