#!/usr/bin/env bash
# Final HEAD checks of the H10 tests in the worktree, on 2 CPUs: the run and differential
# harness on generic_instanceof_*, then the compiler smoke test on them (with mutants).
set -u
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4 || exit 2
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 taskset -c 0,1 go test -count=1 -timeout 30m -v \
  -run '^(TestRun|TestRunMatchesNode)$/^(generic_instanceof_.*)$' ./pts/tests/ > /tmp/h10/tests/harness_final.log 2>&1
echo "exit=$?" >> /tmp/h10/tests/harness_final.log
GOMAXPROCS=2 PTS_SMOKE_FILTER='generic_instanceof_' PTS_SMOKE_MUTANTS=4 taskset -c 0,1 go test -count=1 -timeout 30m -v \
  -run '^TestCompilerFailsCleanly$' ./pts/tests/ > /tmp/h10/tests/smoke_final.log 2>&1
echo "exit=$?" >> /tmp/h10/tests/smoke_final.log
