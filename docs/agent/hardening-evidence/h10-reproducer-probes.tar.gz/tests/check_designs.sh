#!/usr/bin/env bash
# check.py over the worktree's generic_instanceof tests for each CLI, one after another.
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4
export PTS_HOME=$W
cd "$W" || exit 2
for spec in HEAD=$W/pts-bin/pts A=/tmp/h10/protoA/pts B=/tmp/h10/protoB/pts AB=/tmp/h10/protoB/pts_ab C=/tmp/h10/protoConly/pts_c ABC=/tmp/h10/protoC/pts_abc; do
  name=${spec%%=*}
  PTS=${spec#*=} python3 /tmp/h10/tests/check.py pts/tests/run/generic_instanceof_*.pts > "/tmp/h10/tests/check_$name.txt" 2>&1
done
echo done
