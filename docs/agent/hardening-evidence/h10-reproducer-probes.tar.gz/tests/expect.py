#!/usr/bin/env python3
"""For each draft test: runs Node on its .mts copy (`.par.` made `.`), and pts (HEAD's CLI
or $PTS) on the program; prints both and the `// expect:` block Node's stdout makes.
With --write DIR, writes each test with Node's expect block appended (an existing
`// expect:` block is kept as is) into DIR.
Usage: expect.py [--write DIR] test.pts..."""
import os
import subprocess
import sys
import tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
PTS = os.environ.get("PTS", "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4/pts-bin/pts")
ENV = dict(os.environ, TZ="America/New_York")


def block(out):
    lines = ["// expect:"]
    for line in out.split("\n")[:-1] if out.endswith("\n") else out.split("\n"):
        lines.append("//" if line == "" else "// " + line)
    return "\n".join(lines) + "\n"


def main():
    args = sys.argv[1:]
    write = None
    if args and args[0] == "--write":
        write, args = args[1], args[2:]
    for path in args:
        name = os.path.basename(path)[:-4]
        src = open(path).read()
        with tempfile.TemporaryDirectory(dir="/tmp/h10") as d:
            open(os.path.join(d, name + ".mts"), "w").write(src.replace(".par.", "."))
            n = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", name + ".mts"], cwd=d, env=ENV, capture_output=True, text=True, timeout=60)
            b = subprocess.run([PTS, "build", os.path.abspath(path), "-o", os.path.join(d, "bin")], cwd=d, env=ENV, capture_output=True, text=True, timeout=180)
            if b.returncode == 0:
                p = subprocess.run([os.path.join(d, "bin")], cwd=d, env=ENV, capture_output=True, text=True, timeout=60)
                pts = f"exit={p.returncode}\n{p.stdout}{p.stderr}"
            else:
                pts = f"build exit={b.returncode}\n{b.stdout}{b.stderr}"
        print(f"===== {name}\n--- node exit={n.returncode}\n{n.stdout}{n.stderr}--- pts {pts}")
        if write and n.returncode == 0:
            out = src if "// expect:" in src else src.rstrip("\n") + "\n" + block(n.stdout)
            open(os.path.join(write, name + ".pts"), "w").write(out)


if __name__ == "__main__":
    main()
