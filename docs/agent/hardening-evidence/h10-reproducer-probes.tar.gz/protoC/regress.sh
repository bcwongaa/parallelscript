#!/usr/bin/env bash
# Runs the run, corpus and error tests of the worktree with a prototype overlay, on 2 CPUs
# (the harness sizes its job pool from the CPUs it may use).
# Usage: regress.sh OVERLAY.json LOG
set -u
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4 || exit 2
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 taskset -c 0,1 go test -overlay "$1" -count=1 -timeout 90m \
  -run '^(TestRun|TestRunMatchesNode|TestCorpusMatchesNode|TestErrors)$' ./pts/tests/ > "$2" 2>&1
echo "exit=$?" >> "$2"
