package lower

// H10 prototype C (evidence only): tsc's instance for any of a generic class of the program
// (`C<any, …>`, what `instanceof` narrows to from a type that doesn't name the class) is a
// dynamic value wherever it types a place, so the place holds any instance of the class;
// its members are read, written and called as a dynamic value's. Where the class itself is
// needed (`new C<any>()`, a superclass, the tables of the members a reference names, a
// fluent `this`), irType is asked for it with l.h10WantClass. Library classes (pts:) keep
// their instance for any.

import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/pts/ir"
	"github.com/microsoft/typescript-go/pts/lib"
)

// isLibraryClassH10 reports whether symbol is declared by a pts: declaration file or module.
func (l *lowerer) isLibraryClassH10(symbol *ast.Symbol) bool {
	if symbol == nil || symbol.ValueDeclaration == nil {
		return false
	}
	name := ast.GetSourceFileOfNode(symbol.ValueDeclaration).FileName()
	return lib.IsLibPath(name) || lib.IsModulePath(name)
}

// classIRType is irType's answer for code that needs the class itself.
func (l *lowerer) classIRType(f func() ir.Type) ir.Type {
	outer := l.h10WantClass
	l.h10WantClass = true
	defer func() { l.h10WantClass = outer }()
	return f()
}
