#!/usr/bin/env python3
"""Builds the overlay sources of prototype C alone (no inference A, no B-local), from the
worktree's HEAD files: tsc's instance for any of a program's generic class is a dynamic
value as a place type (irType), and references of that type are read as `any` (isAny);
the class itself where code needs it (new, superclasses, member tables, fluent this)."""
import json
import os

W = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4"
D = "/tmp/h10/protoConly/"
os.makedirs(D, exist_ok=True)


def edit(rel, pairs):
    s = open(os.path.join(W, rel)).read()
    for old, new in pairs:
        if old not in s:
            raise SystemExit(f"{rel}: not found: {old!r}")
        s = s.replace(old, new, 1)
    out = D + os.path.basename(rel)
    open(out, "w").write(s)
    return out


files = {}
files["pts/lower/lower.go"] = edit("pts/lower/lower.go", [
    ("type lowerer struct {\n", "type lowerer struct {\n\th10WantClass bool // H10 prototype C: irType is asked for a class itself\n"),
    ("func (l *lowerer) irType(t *checker.Type, node *ast.Node) ir.Type {\n\tt = l.instantiate(t)\n\tif t.Flags()&checker.TypeFlagsTypeParameter != 0 && t.AsTypeParameter().IsThisType() {\n",
     "func (l *lowerer) irType(t *checker.Type, node *ast.Node) ir.Type {\n\twantClass := l.h10WantClass // H10 prototype C\n\tl.h10WantClass = false\n\tdefer func() { l.h10WantClass = wantClass }()\n\tt = l.instantiate(t)\n\tif t.Flags()&checker.TypeFlagsTypeParameter != 0 && t.AsTypeParameter().IsThisType() {\n\t\twantClass = true\n"),
    ("\t\tif class := l.classInstanceOf(generic, t, node); class != nil {\n\t\t\treturn class\n\t\t}\n\t\treturn nil // not a typed nil",
     "\t\tif !wantClass && l.isAnyInstanceB(t) && !l.isLibraryClassH10(t.Symbol()) {\n\t\t\treturn ir.Value // H10 prototype C\n\t\t}\n\t\tif class := l.classInstanceOf(generic, t, node); class != nil {\n\t\t\treturn class\n\t\t}\n\t\treturn nil // not a typed nil"),
])
files["pts/lower/generic_classes.go"] = edit("pts/lower/generic_classes.go", [
    ("\tclass, _ := l.irType(t, receiver).(*ir.Class)\n\treturn class\n}", "\tclass, _ := l.classIRType(func() ir.Type { return l.irType(t, receiver) }).(*ir.Class) // H10 prototype C\n\treturn class\n}"),
    ("\t\tparent, _ = l.irType(bases[0], heritage).(*ir.Class)", "\t\tparent, _ = l.classIRType(func() ir.Type { return l.irType(bases[0], heritage) }).(*ir.Class) // H10 prototype C"),
    ("\tclass, _ := l.irType(l.typeAt(node), node).(*ir.Class)\n\treturn class", "\tclass, _ := l.classIRType(func() ir.Type { return l.irType(l.typeAt(node), node) }).(*ir.Class) // H10 prototype C\n\treturn class"),
])
files["pts/lower/classes.go"] = edit("pts/lower/classes.go", [
    ("\t\t\tclass.Parent, _ = l.irType(bases[0], heritage).(*ir.Class)", "\t\t\tclass.Parent, _ = l.classIRType(func() ir.Type { return l.irType(bases[0], heritage) }).(*ir.Class) // H10 prototype C"),
])
files["pts/lower/dynamic.go"] = edit("pts/lower/dynamic.go", [
    ("\treturn t.Flags()&checker.TypeFlagsAny != 0 || l.isRuntimeObject(t)\n", "\treturn t.Flags()&checker.TypeFlagsAny != 0 || l.isRuntimeObject(t) || l.isAnyInstanceB(t) && !l.isLibraryClassH10(t.Symbol()) // H10 prototype C\n"),
])
# The helpers: want_class.go (classIRType, isLibraryClassH10) and isAnyInstanceB.
open(D + "want_class.go", "w").write(open("/tmp/h10/protoC/want_class.go").read())
open(D + "any_instance.go", "w").write('''package lower

import "github.com/microsoft/typescript-go/internal/checker"

// isAnyInstanceB reports whether t is a generic class of the program's instance whose type
// arguments are all any (H10 prototype C).
func (l *lowerer) isAnyInstanceB(t *checker.Type) bool {
	if t.Flags()&checker.TypeFlagsObject == 0 || t.ObjectFlags()&checker.ObjectFlagsReference == 0 {
		return false
	}
	if _, ok := l.genericClasses[t.Symbol()]; !ok {
		return false
	}
	arguments := l.checker.GetTypeArguments(t)
	if len(arguments) == 0 {
		return false
	}
	for _, argument := range arguments {
		if argument.Flags()&checker.TypeFlagsAny == 0 && !(argument.Flags()&checker.TypeFlagsTypeParameter != 0 && argument.AsTypeParameter().IsThisType()) {
			return false
		}
	}
	return true
}
''')
files["pts/lower/want_class.go"] = D + "want_class.go"
files["pts/lower/any_instance.go"] = D + "any_instance.go"
json.dump({"Replace": {os.path.join(W, k): v for k, v in files.items()}}, open(D + "overlay.json", "w"), indent=1)
print("overlay", D + "overlay.json")
