#!/usr/bin/env python3
"""Prototype C fixes: the want-class flag becomes a lowerer field (the harness lowers
programs concurrently in one process), and library (pts:) generic classes keep their
instance for any (`.par` of an any[] is a ParallelArray<any>)."""
d = "/tmp/h10/protoC/"


def edit(name, pairs):
    p = d + name
    s = open(p).read()
    for old, new in pairs:
        if old not in s:
            raise SystemExit(f"{name}: not found: {old!r}")
        s = s.replace(old, new)
    open(p, "w").write(s)


edit("lower.go", [
    ("type lowerer struct {\n", "type lowerer struct {\n\th10WantClass bool // H10 prototype C: irType is asked for a class itself\n", ),
    ("\twantClass := h10WantClass // H10", "\twantClass := l.h10WantClass // H10"),
    ("\th10WantClass = false\n\tdefer func() { h10WantClass = wantClass }()", "\tl.h10WantClass = false\n\tdefer func() { l.h10WantClass = wantClass }()"),
    ("if !wantClass && l.isAnyInstanceB(t) {", "if !wantClass && l.isAnyInstanceB(t) && !l.isDeclaredInPtsLib(t.Symbol()) {"),
])
edit("generic_classes.go", [("classIRType(func", "l.classIRType(func")] )
edit("classes.go", [("classIRType(func", "l.classIRType(func")])
edit("dynamic.go", [("|| l.isAnyInstanceB(t) // H10 prototype C", "|| l.isAnyInstanceB(t) && !l.isDeclaredInPtsLib(t.Symbol()) // H10 prototype C")])
open(d + "want_class.go", "w").write('''package lower

// H10 prototype C (evidence only): tsc's instance for any of a generic class of the program
// (`C<any, …>`, what `instanceof` narrows to from a type that doesn't name the class) is a
// dynamic value wherever it types a place, so the place holds any instance of the class;
// its members are read, written and called as a dynamic value's. Where the class itself is
// needed (`new C<any>()`, a superclass, the tables of the members a reference names, a
// fluent `this`), irType is asked for it with l.h10WantClass. Library classes (pts:) keep
// their instance for any.

import "github.com/microsoft/typescript-go/pts/ir"

// classIRType is irType's answer for code that needs the class itself.
func (l *lowerer) classIRType(f func() ir.Type) ir.Type {
	outer := l.h10WantClass
	l.h10WantClass = true
	defer func() { l.h10WantClass = outer }()
	return f()
}
''')
print("ok")
