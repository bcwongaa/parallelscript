#!/usr/bin/env python3
"""Prototype C fix 2: library classes are those of pts: declarations and pts: modules
(pts:parallel's ParallelArray), not only the .d.ts ones."""
d = "/tmp/h10/protoC/"
for name in ("lower.go", "dynamic.go"):
    p = d + name
    s = open(p).read()
    old = "!l.isDeclaredInPtsLib(t.Symbol())"
    if old not in s:
        raise SystemExit(name + ": not found")
    s = s.replace(old, "!l.isLibraryClassH10(t.Symbol())")
    open(p, "w").write(s)
p = d + "want_class.go"
s = open(p).read()
s = s.replace('import "github.com/microsoft/typescript-go/pts/ir"', '''import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/pts/ir"
	"github.com/microsoft/typescript-go/pts/lib"
)

// isLibraryClassH10 reports whether symbol is declared by a pts: declaration file or module.
func (l *lowerer) isLibraryClassH10(symbol *ast.Symbol) bool {
	if symbol == nil || symbol.ValueDeclaration == nil {
		return false
	}
	name := ast.GetSourceFileOfNode(symbol.ValueDeclaration).FileName()
	return lib.IsLibPath(name) || lib.IsModulePath(name)
}''')
open(p, "w").write(s)
print("ok")
