package lower

import "github.com/microsoft/typescript-go/internal/checker"

// isAnyInstanceB reports whether t is a generic class of the program's instance whose type
// arguments are all any (H10 prototype C).
func (l *lowerer) isAnyInstanceB(t *checker.Type) bool {
	if t.Flags()&checker.TypeFlagsObject == 0 || t.ObjectFlags()&checker.ObjectFlagsReference == 0 {
		return false
	}
	if _, ok := l.genericClasses[t.Symbol()]; !ok {
		return false
	}
	arguments := l.checker.GetTypeArguments(t)
	if len(arguments) == 0 {
		return false
	}
	for _, argument := range arguments {
		if argument.Flags()&checker.TypeFlagsAny == 0 && !(argument.Flags()&checker.TypeFlagsTypeParameter != 0 && argument.AsTypeParameter().IsThisType()) {
			return false
		}
	}
	return true
}
