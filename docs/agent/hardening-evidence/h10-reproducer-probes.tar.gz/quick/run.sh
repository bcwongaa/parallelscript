#!/usr/bin/env bash
# Runs each given .pts under pts (pts run) and Node, printing both outputs and exit codes.
# Usage: run.sh file.pts...   (PTS overrides the compiler)
set -u
pts="${PTS:-/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4/pts-bin/pts}"
export TZ=America/New_York
for f in "$@"; do
  dir=$(dirname "$f"); name=$(basename "$f" .pts)
  echo "=== $name"
  cp "$f" "$dir/$name.mts"
  echo "--- node"
  (cd "$dir" && timeout 30 node --no-warnings --experimental-transform-types "$name.mts" 2>&1); echo "node exit=$?"
  echo "--- pts"
  timeout 120 "$pts" build "$f" -o "$dir/$name.bin" 2>&1; bc=$?
  if [ $bc -eq 0 ]; then
    (cd "$dir" && timeout 30 "./$name.bin" 2>&1); echo "pts exit=$?"
    rm -f "$dir/$name.bin"
  else
    echo "build exit=$bc"
  fi
  rm -f "$dir/$name.mts"
done
