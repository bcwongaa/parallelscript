package lower

// H10 prototype A (evidence only): a reference that `instanceof` narrowed to a generic
// class's instance for any (tsc's `C<any, …>`, the class's prototype type) reads as the
// class's instance for the type arguments its declared type implies, when inference
// decides every one of them and the instance is assignable to the declared type; else as
// tsc says (unchanged).

import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
)

// instanceofInstance is t, tsc's (instantiated) type of node, with a generic class's
// instance for any replaced by the instance node's declared type implies.
func (l *lowerer) instanceofInstance(node *ast.Node, t *checker.Type) *checker.Type {
	if t == nil {
		return t
	}
	switch node.Kind {
	case ast.KindIdentifier, ast.KindPropertyAccessExpression, ast.KindElementAccessExpression:
	default:
		return t
	}
	members := []*checker.Type{t}
	if t.Flags()&checker.TypeFlagsIntersection != 0 {
		members = t.Types()
	}
	var proto *checker.Type
	for _, member := range members {
		if l.isAnyInstance(member) {
			proto = member
		}
	}
	if proto == nil {
		return t
	}
	declared := l.declaredReferenceType(node)
	if declared == nil || declared == proto || declared.Flags()&(checker.TypeFlagsAny|checker.TypeFlagsUnknown) != 0 {
		return t
	}
	inferred := l.checker.PtsInferClassInstance(proto.Symbol(), declared)
	if inferred == nil || l.isAnyInstance(inferred) || !l.checker.IsTypeAssignableTo(inferred, declared) {
		return t
	}
	return inferred
}

// isAnyInstance reports whether t is a generic class of the program's instance whose type
// arguments are all any.
func (l *lowerer) isAnyInstance(t *checker.Type) bool {
	if t.Flags()&checker.TypeFlagsObject == 0 || t.ObjectFlags()&checker.ObjectFlagsReference == 0 {
		return false
	}
	if _, ok := l.genericClasses[t.Symbol()]; !ok {
		return false
	}
	arguments := l.checker.GetTypeArguments(t)
	if len(arguments) == 0 {
		return false
	}
	for _, argument := range arguments {
		if argument.Flags()&checker.TypeFlagsAny == 0 && !(argument.Flags()&checker.TypeFlagsTypeParameter != 0 && argument.AsTypeParameter().IsThisType()) {
			return false
		}
	}
	return true
}

// declaredReferenceType is the declared type of the variable, property or element node
// reads, before narrowing, instantiated; nil if it has none.
func (l *lowerer) declaredReferenceType(node *ast.Node) *checker.Type {
	if declared, _ := l.readTypes(node); declared != nil {
		return l.instantiate(declared)
	}
	if node.Kind == ast.KindElementAccessExpression {
		if object := l.typeAt(node.Expression()); l.checker.IsArrayType(object) {
			return l.checker.GetElementTypeOfArrayType(object)
		}
	}
	return nil
}
