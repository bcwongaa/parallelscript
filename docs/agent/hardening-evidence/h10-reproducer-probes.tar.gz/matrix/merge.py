#!/usr/bin/env python3
"""Merges results JSONL files (later ones override earlier ones by case id) into OUT.
Usage: merge.py OUT in1.jsonl in2.jsonl ..."""
import json
import sys

rows = {}
for p in sys.argv[2:]:
    for line in open(p):
        r = json.loads(line)
        rows[r["id"]] = r
with open(sys.argv[1], "w") as fh:
    for k in sorted(rows):
        fh.write(json.dumps(rows[k]) + "\n")
print(len(rows), "cases ->", sys.argv[1])
