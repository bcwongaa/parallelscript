#!/usr/bin/env python3
"""Compares matrix results of several CLIs case by case.
Usage: designs.py NAME=results.jsonl ...  (first is the baseline, HEAD)
Prints totals per design, OK counts by family and by use, and the cases a design breaks
(OK on the baseline, not OK with the design)."""
import collections
import json
import sys

designs = []
for arg in sys.argv[1:]:
    name, path = arg.split("=", 1)
    rows = {}
    for line in open(path):
        r = json.loads(line)
        rows[r["id"]] = r
    designs.append((name, rows))
base_name, base = designs[0]
ids = sorted(base)
print("totals")
for name, rows in designs:
    c = collections.Counter(rows[i]["class"] for i in ids if i in rows)
    print(f"  {name:6} {len(rows):4} cases  " + "  ".join(f"{k}={v}" for k, v in sorted(c.items())))
for key in ("family", "use", "form"):
    print(f"\nOK by {key} (" + " / ".join(n for n, _ in designs) + ")")
    groups = collections.defaultdict(list)
    for i in ids:
        groups[base[i][key]].append(i)
    for g in sorted(groups):
        cells = []
        for name, rows in designs:
            ok = sum(1 for i in groups[g] if i in rows and rows[i]["class"] == "OK")
            cells.append(f"{ok:3}")
        print(f"  {g:22} n={len(groups[g]):3}  " + " / ".join(cells))
for name, rows in designs[1:]:
    broken = [i for i in ids if base[i]["class"] == "OK" and i in rows and rows[i]["class"] != "OK"]
    fixed = [i for i in ids if base[i]["class"] != "OK" and i in rows and rows[i]["class"] == "OK"]
    print(f"\n{name}: fixes {len(fixed)}, breaks {len(broken)}")
    for i in broken:
        print(f"  broken {i}: {rows[i]['class']} {str(rows[i].get('detail', ''))[:140]}")
