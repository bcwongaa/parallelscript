#!/usr/bin/env python3
"""Generates the H10 differential matrix: programs that narrow a reference to a generic
class with `instanceof` from many declared types (families), with many element types,
narrowing forms and uses of the narrowed value in the branch.

Usage: gen.py OUTDIR    (writes OUTDIR/cases/*.pts and OUTDIR/manifest.json)

Part A: every family x every use, element type number (the D-149 unsafe case).
Part B: element types x a few families x a few uses.
Part C: narrowing forms x a few families, one combined use.
"""
import json
import os
import sys

# ---------------------------------------------------------------------------------------
# Element types: (name, TS type, v1, v2, extra declarations)
ELEMS = {
    "number": ("number", "7", "8.5", ""),
    "string": ("string", '"s7"', '"s8"', ""),
    "boolean": ("boolean", "true", "false", ""),
    "object": ("{ id: number }", "{ id: 7 }", "{ id: 8 }", ""),
    "array": ("number[]", "[7, 8]", "[9]", ""),
    "nested": ("Box<number>", "new Box(7)", "new Box(8)", "class Box<T> {\n  constructor(public inner: T) {}\n}\n"),
    "literal": ('"a" | "b"', '"a"', '"b"', ""),
    "dog": ("Dog", "new Dog()", "new Dog()", 'class Animal {\n  name = "a";\n}\nclass Dog extends Animal {\n  bark(): string { return "woof"; }\n}\n'),
}


def target_class(name, tparams, tp, heritage, ctor, super_call, extra, peek):
    """The class narrowed to, with the uniform members every use reads."""
    lines = [f"class {name}{tparams}{heritage} {{"]
    lines.append("  hits = 0;")
    lines.append(f"  items: {tp}[] = [];")
    lines.append(f"  #secret: {tp};")
    body = (super_call + " " if super_call else "") + "this.#secret = val; this.items.push(val);"
    lines.append(f"  constructor({ctor}) {{ {body} }}")
    lines.append(f"  get current(): {tp} {{ return this.val; }}")
    lines.append(f"  read(): {tp} {{ return this.val; }}")
    lines.append(f"  with(v: {tp}): {tp} {{ this.val = v; return v; }}")
    lines.append(f"  map<R>(f: (v: {tp}) => R): R {{ return f(this.val); }}")
    if peek is not None:
        lines.append(f"  peek(o: {peek}): {tp} | undefined {{ return o instanceof {name} ? o.#secret : undefined; }}")
    for e in extra:
        lines.append("  " + e)
    lines.append("}")
    return "\n".join(lines) + "\n"


CACHE = "interface Cache<K, V> {\n  get(k: K): V | undefined;\n}\n"
OTHER_CACHE = "class Other<K, V> implements Cache<K, V> {\n  get(k: K): V | undefined { return undefined; }\n}\n"


def maplru(peek, peek_type="Cache<K, V>"):
    return target_class("MapLRU", "<K, V>", "V", " implements Cache<K, V>", "public key: K, public val: V", None,
                        ["get(k: K): V | undefined { return k === this.key ? this.val : undefined; }"],
                        peek_type if peek else None)


# A family: the declared type of the narrowed reference and the class narrowed to.
#   decls(peek) -> declarations; src: the source type (ELT the element type); srch: the source
#   type helpers take; cls; actual: the object's type; make(v); other: a source value that
#   isn't cls (or None); src_read(c): an expression reading c through the source type;
#   sig: the probe's signature; call(arg): how the probe is called; infer: whether the
#   class's type arguments follow from the source type.
def fam(name, decls, src, cls, actual, make, other, src_read, infer, sig=None, call=None, extra_main="", srch=None, note=""):
    return dict(name=name, decls=decls, src=src, srch=srch or src, cls=cls, actual=actual, make=make, other=other,
                src_read=src_read, infer=infer, sig=sig or "function probe(x: SRC): void", call=call or "probe(ARG);",
                extra_main=extra_main, note=note)


FAMILIES = [
    fam("iface", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, ELT>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "yes",
        note="class MapLRU<K, V> implements Cache<K, V>"),
    fam("iface_partial", lambda peek: CACHE + target_class("StrCache", "<V>", "V", " implements Cache<string, V>", "public val: V", None,
                                                            ["get(k: string): V | undefined { return this.val; }"], "Cache<string, V>" if peek else None) + OTHER_CACHE,
        "Cache<string, ELT>", "StrCache", "StrCache<ELT>", "new StrCache<ELT>(v1)", "new Other<string, ELT>()", 'c.get("k")', "yes",
        note="class StrCache<V> implements Cache<string, V>"),
    fam("iface_reorder", lambda peek: CACHE + target_class("Flip", "<V, K>", "V", " implements Cache<K, V>", "public key: K, public val: V", None,
                                                            ["get(k: K): V | undefined { return this.val; }"], "Cache<K, V>" if peek else None) + OTHER_CACHE,
        "Cache<string, ELT>", "Flip", "Flip<ELT, string>", 'new Flip<ELT, string>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "yes",
        note="class Flip<V, K> implements Cache<K, V> (parameters in the other order)"),
    fam("iface_wrapped", lambda peek: "interface Holder<T> {\n  first(): T | undefined;\n}\n" +
        target_class("Sub", "<A>", "A", " implements Holder<A[]>", "public val: A", None,
                     ["first(): A[] | undefined { return this.items; }"], "Holder<A[]>" if peek else None) +
        "class OtherH<T> implements Holder<T> {\n  first(): T | undefined { return undefined; }\n}\n",
        "Holder<ELT[]>", "Sub", "Sub<ELT>", "new Sub<ELT>(v1)", "new OtherH<ELT[]>()", "c.first()", "yes (structural: A from A[])",
        note="class Sub<A> implements Holder<A[]>"),
    fam("iface_noninfer", lambda peek: CACHE + target_class("Tagged", "<T, Extra>", "T", " implements Cache<string, T>", "public val: T", None,
                                                             ["extra: Extra | undefined = undefined;", "get(k: string): T | undefined { return this.val; }"],
                                                             "Cache<string, T>" if peek else None) + OTHER_CACHE,
        "Cache<string, ELT>", "Tagged", "Tagged<ELT, boolean>", "new Tagged<ELT, boolean>(v1)", "new Other<string, ELT>()", 'c.get("k")', "no (Extra)",
        note="class Tagged<T, Extra> implements Cache<string, T>"),
    fam("iface_via_base", lambda peek: CACHE + "class MidCache<V> implements Cache<string, V> {\n  get(k: string): V | undefined { return undefined; }\n}\n" +
        target_class("LeafCache", "<V>", "V", " extends MidCache<V>", "public val: V", "super();", [], "Cache<string, V>" if peek else None) + OTHER_CACHE,
        "Cache<string, ELT>", "LeafCache", "LeafCache<ELT>", "new LeafCache<ELT>(v1)", "new Other<string, ELT>()", 'c.get("k")', "yes (through the superclass)",
        note="class LeafCache<V> extends MidCache<V>; class MidCache<V> implements Cache<string, V>"),
    fam("base_abstract", lambda peek: "abstract class Option<T> {\n  abstract isSome(): boolean;\n  abstract read(): T;\n}\n" +
        target_class("Some", "<T>", "T", " extends Option<T>", "public val: T", "super();", ["isSome(): boolean { return true; }"], "Option<T>" if peek else None) +
        "class None<T> extends Option<T> {\n  isSome(): boolean { return false; }\n  read(): T { throw new Error(\"none\"); }\n}\n",
        "Option<ELT>", "Some", "Some<ELT>", "new Some<ELT>(v1)", "new None<ELT>()", "c.isSome()", "yes",
        note="abstract class Option<T>; class Some<T> extends Option<T>"),
    fam("base_concrete", lambda peek: "class Base<T> {\n  constructor(public val: T) {}\n  kind(): string { return \"base\"; }\n}\n" +
        target_class("Derived", "<T>", "T", " extends Base<T>", "val: T", "super(val);", [], "Base<T>" if peek else None),
        "Base<ELT>", "Derived", "Derived<ELT>", "new Derived<ELT>(v1)", "new Base<ELT>(v2)", "c.val", "yes",
        note="class Base<T> (val declared here); class Derived<T> extends Base<T>"),
    fam("base_chain", lambda peek: "class A<T> {\n  constructor(public val: T) {}\n}\nclass B<T> extends A<T> {\n  b = 1;\n}\n" +
        target_class("C", "<T>", "T", " extends B<T>", "val: T", "super(val);", [], "A<T>" if peek else None),
        "A<ELT>", "C", "C<ELT>", "new C<ELT>(v1)", "new B<ELT>(v2)", "c.val", "yes (two levels)",
        note="class A<T>; class B<T> extends A<T>; class C<T> extends B<T>"),
    fam("base_wrapped", lambda peek: "class Bag<T> {\n  constructor(public contents: T) {}\n}\n" +
        target_class("ListBag", "<A>", "A", " extends Bag<A[]>", "public val: A", "super([val]);", [], "Bag<A[]>" if peek else None),
        "Bag<ELT[]>", "ListBag", "ListBag<ELT>", "new ListBag<ELT>(v1)", "new Bag<ELT[]>([v2])", "c.contents.length", "yes (structural: A from A[])",
        note="class ListBag<A> extends Bag<A[]>"),
    fam("base_nongeneric", lambda peek: "class Shape {\n  area(): number { return 0; }\n}\n" +
        target_class("Tagged", "<T>", "T", " extends Shape", "public val: T", "super();", [], "Shape" if peek else None),
        "Shape", "Tagged", "Tagged<ELT>", "new Tagged<ELT>(v1)", "new Shape()", "c.area()", "no (non-generic base)",
        note="class Shape; class Tagged<T> extends Shape"),
    fam("error", lambda peek: target_class("HttpError", "<T>", "T", " extends Error", "public val: T", "super(\"http\");", [], "Error" if peek else None),
        "Error", "HttpError", "HttpError<ELT>", "new HttpError<ELT>(v1)", 'new Error("plain")', "c.message", "no (non-generic base Error)",
        note="class HttpError<T> extends Error"),
    fam("object", lambda peek: CACHE + maplru(peek, "object") + OTHER_CACHE, "object", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "{ z: 1 }", "typeof c", "no (object)"),
    fam("empty", lambda peek: CACHE + maplru(peek, "{}") + OTHER_CACHE, "{}", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "42", "typeof c", "no ({})"),
    fam("union_undef", lambda peek: CACHE + maplru(peek, "Cache<K, V> | undefined") + OTHER_CACHE, "Cache<string, ELT> | undefined", "MapLRU",
        "MapLRU<string, ELT>", 'new MapLRU<string, ELT>("k", v1)', "undefined", 'c?.get("k")', "yes"),
    fam("union_prim", lambda peek: CACHE + maplru(peek, "Cache<K, V> | string") + OTHER_CACHE, "Cache<string, ELT> | string", "MapLRU",
        "MapLRU<string, ELT>", 'new MapLRU<string, ELT>("k", v1)', '"str"', 'typeof c === "string" ? c : c.get("k")', "yes"),
    fam("union_ifaces", lambda peek: CACHE + "interface Store<T> {\n  all(): T[];\n}\n" + maplru(peek, "Cache<K, V> | Store<V>") +
        "class ArrStore<T> implements Store<T> {\n  all(): T[] { return []; }\n}\n",
        "Cache<string, ELT> | Store<ELT>", "MapLRU", "MapLRU<string, ELT>", 'new MapLRU<string, ELT>("k", v1)', "new ArrStore<ELT>()",
        '"get" in c ? c.get("k") : c.all().length', "yes (from the Cache member)"),
    fam("typeparam_inferred", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "S", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "yes (S is the class)",
        sig="function probe<S extends Cache<string, ELT>>(x: S): void", srch="Cache<string, ELT>",
        note="probe<S extends Cache<string, ELT>>(x: S), S inferred from the argument"),
    fam("typeparam_iface", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "S", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "yes",
        sig="function probe<S extends Cache<string, ELT>>(x: S): void", call="probe<Cache<string, ELT>>(ARG);", srch="Cache<string, ELT>",
        note="probe<S extends Cache<string, ELT>>(x: S) called with S = Cache<string, ELT>"),
    fam("unknown", lambda peek: CACHE + maplru(peek, "unknown") + OTHER_CACHE, "unknown", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "42", "typeof c", "guard (dynamic source)"),
    fam("any", lambda peek: CACHE + maplru(peek, "any") + OTHER_CACHE, "any", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "42", "typeof c", "guard (dynamic source)"),
    fam("ctl_same_union", lambda peek: CACHE + maplru(peek, "MapLRU<K, V> | Other<K, V>") + OTHER_CACHE, "MapLRU<string, ELT> | Other<string, ELT>", "MapLRU",
        "MapLRU<string, ELT>", 'new MapLRU<string, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "control (tsc keeps MapLRU<string, ELT>)"),
    fam("ctl_nongeneric", lambda peek: "interface NCache {\n  get(k: string): ELT | undefined;\n}\n" +
        target_class("NMap", "", "ELT", " implements NCache", "public key: string, public val: ELT", None,
                     ["get(k: string): ELT | undefined { return k === this.key ? this.val : undefined; }"], "NCache" if peek else None) +
        "class NOther implements NCache {\n  get(k: string): ELT | undefined { return undefined; }\n}\n",
        "NCache", "NMap", "NMap", 'new NMap("k", v1)', "new NOther()", 'c.get("k")', "control (non-generic class)"),
    fam("multi_inst", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, ELT>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "yes",
        extra_main='function probe2(y: Cache<number, string>): void {\n  if (y instanceof MapLRU) console.log("probe2", y.key, y.val, y.read(), y.hits, y.items);\n}\n'
                   'const obj2 = new MapLRU<number, string>(1, "one");\nprobe2(obj2);\nconsole.log("after2", obj2.val, obj2.hits);\n',
        note="iface plus a MapLRU<number, string> narrowed at a Cache<number, string> place of its own"),
]
# Part D: the object's type arguments differ from the declared type's (variance), or two
# instances reach one place: what the declared type implies isn't the object's instance.
D_FAMILIES = [
    fam("var_wider_v", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, number | string>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, number | string>()", 'c.get("k")', "wrong (infers MapLRU<string, number | string>)",
        note="Cache<string, number | string> holding a MapLRU<string, number>"),
    fam("var_unknown_k", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, ELT>", "MapLRU", "MapLRU<unknown, ELT>",
        'new MapLRU<unknown, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "wrong (infers MapLRU<string, number>)",
        note="Cache<string, number> holding a MapLRU<unknown, number> (method parameters are bivariant)"),
    fam("var_base_wider", lambda peek: FAMILY0["base_abstract"]["decls"](peek), "Option<number | string>", "Some", "Some<ELT>",
        "new Some<ELT>(v1)", "new None<number | string>()", "c.isSome()", "wrong (infers Some<number | string>)",
        note="Option<number | string> holding a Some<number>"),
    fam("var_class_arg", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, Animal>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, Animal>()", 'c.get("k")', "wrong (infers MapLRU<string, Animal>)",
        note="Cache<string, Animal> holding a MapLRU<string, Dog>"),
    fam("union_two_insts", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, number> | Cache<number, string>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, number>()", 'c.get("k" as never)', "no (two instances)",
        extra_main='probe(new MapLRU<number, string>(1, "one"));\n',
        note="Cache<string, number> | Cache<number, string> reached by MapLRU<string, number> and MapLRU<number, string>"),
]
FAMILY0 = {f["name"]: f for f in FAMILIES}
FAMILY = {f["name"]: f for f in FAMILIES + D_FAMILIES}

# ---------------------------------------------------------------------------------------
# Uses in the branch: (name, body with X the narrowed reference, helpers, needs peek, flags)
USES = [
    ("field", 'console.log("val", X.val, typeof X.val, X.val === v1);', ""),
    ("getter", 'console.log("current", X.current);', ""),
    ("method", 'console.log("read", X.read());', ""),
    ("method_arg", 'console.log("with", X.with(v2), X.val);', ""),
    ("generic_method", 'console.log("map", X.map((v) => [v, v]));', ""),
    ("field_write", 'X.val = v2;\n    console.log("wrote", X.val);', ""),
    ("compound", 'X.hits++;\n    X.hits += 2;\n    console.log("hits", X.hits);', ""),
    ("push_field", 'X.items.push(v2);\n    console.log("items", X.items.length, X.items);', ""),
    ("iterate_field", 'for (const it of X.items) console.log("it", it);', ""),
    ("pass_actual", 'console.log("actual", takeActual(X));', "function takeActual(c: ACTUAL): ELT {\n  return c.read();\n}\n"),
    ("pass_src", 'console.log("src", takeSrc(X));', "function takeSrc(c: SRCH) {\n  return SRCREAD;\n}\n"),
    ("pass_any", 'console.log("any", takeAny(X));', "function takeAny(a: any): any {\n  return a.val;\n}\n"),
    ("return_declared", 'const r = asActual(X);\n    console.log("ret", r?.read(), r?.val);',
     "function asActual(c: SRCH): ACTUAL | undefined {\n  if (c instanceof CLS) return c;\n  return undefined;\n}\n"),
    ("return_inferred", 'const r = asInferred(X);\n    console.log("reti", r?.read(), r?.val);',
     "function asInferred(c: SRCH) {\n  if (c instanceof CLS) return c;\n  return undefined;\n}\n"),
    ("const_copy", 'const m2 = X;\n    m2.hits++;\n    console.log("m2", m2.val, m2.read(), m2.hits);', ""),
    ("array_literal", 'const arr = [X];\n    console.log("arr", arr.length, arr[0].val, arr[0].read());', ""),
    ("log_object", "console.log(X);", ""),
    ("template", 'console.log(`tpl ${X.val} ${X.hits} ${X.read()}`);', ""),
    ("instanceof_again", 'console.log("again", X instanceof CLS, X instanceof Unrelated);', "class Unrelated {\n  u = 1;\n}\n"),
    ("private_peek", 'console.log("peek", obj.peek(obj));', "PEEK"),
    ("generic_call", 'const g = ident(X);\n    console.log("ident", g.val, g.read());', "function ident<T>(t: T): T {\n  return t;\n}\n"),
    ("destructure", 'const { val, hits } = X;\n    console.log("destr", val, hits);', ""),
    ("par_map", 'const arr = [X, X, X];\n    console.log("par", arr.par.map((m) => m.read()).join(","), arr.par.map((m) => m.hits + 1).join(","));', "PAR"),
]
USE = {u[0]: u for u in USES}

# Narrowing forms (Part C): R is the narrowed reference; BODY the use on it.
FORM_USE = 'console.log("read", @R.val, @R.read(), @R.current);\n    @R.hits++;\n    console.log("hits", @R.hits, @R.items.length);'
FORM_EXPR = '`${@R.val}|${@R.read()}|${@R.current}|${++@R.hits}`'
FORMS = [
    ("if", "function probe(x: SRC): void {\n  if (x instanceof CLS) {\n    BODY(x)\n  } else {\n    console.log(\"no\");\n  }\n}\n", ""),
    ("early_return", "function probe(x: SRC): void {\n  if (!(x instanceof CLS)) {\n    console.log(\"no\");\n    return;\n  }\n  BODY(x)\n}\n", ""),
    ("else_branch", "function probe(x: SRC): void {\n  if (!(x instanceof CLS)) console.log(\"no\");\n  else {\n    BODY(x)\n  }\n}\n", ""),
    ("conditional", "function probe(x: SRC): void {\n  console.log(\"cond\", x instanceof CLS ? EXPR(x) : \"no\");\n}\n", ""),
    ("and_chain", "function probe(x: SRC): void {\n  if (x instanceof CLS && x.hits >= 0) {\n    BODY(x)\n  }\n}\n", ""),
    ("and_expr", "function probe(x: SRC): void {\n  const r = x instanceof CLS && EXPR(x);\n  console.log(\"and\", r);\n}\n", ""),
    ("switch_true", "function probe(x: SRC): void {\n  switch (true) {\n    case x instanceof CLS: {\n      BODY(x)\n      break;\n    }\n    default:\n      console.log(\"no\");\n  }\n}\n", ""),
    ("property", "function probe(x: SRC): void {\n  const holder: { c: SRC } = { c: x };\n  if (holder.c instanceof CLS) {\n    BODY(holder.c)\n  }\n}\n", ""),
    ("this_property", "class Owner {\n  constructor(public cache: SRC) {}\n  run(): void {\n    if (this.cache instanceof CLS) {\n      BODY(this.cache)\n    }\n  }\n}\nfunction probe(x: SRC): void {\n  new Owner(x).run();\n}\n", ""),
    ("element", "function probe(x: SRC): void {\n  const arr: Array<SRC> = [x];\n  if (arr[0] instanceof CLS) {\n    BODY(arr[0])\n  }\n}\n", ""),
    ("closure_const", "function probe(x: SRC): void {\n  if (x instanceof CLS) {\n    const c = x;\n    const f = () => {\n    BODY(c)\n    };\n    f();\n  }\n}\n", ""),
    ("closure_param", "function probe(x: SRC): void {\n  if (x instanceof CLS) {\n    const f = () => {\n    BODY(x)\n    };\n    f();\n  }\n}\n", ""),
    ("let_reassigned", "function probe(x: SRC): void {\n  let cur: SRC = x;\n  if (cur instanceof CLS) {\n    BODY(cur)\n  }\n  cur = x;\n}\n", ""),
    ("catch", "function probe(x: SRC): void {\n  try {\n    throw x;\n  } catch (e) {\n    if (e instanceof CLS) {\n      BODY(e)\n    }\n  }\n}\n", ""),
    ("catch_any", "function probe(x: SRC): void {\n  try {\n    throw x;\n  } catch (e: any) {\n    if (e instanceof CLS) {\n      BODY(e)\n    }\n  }\n}\n", ""),
    ("filter_inferred", "function probe(x: SRC): void {\n  const xs: Array<SRC> = [x, OTHER];\n  for (const m of xs.filter((v) => v instanceof CLS)) {\n    BODY(m)\n  }\n}\n", ""),
    ("filter_explicit", "function probe(x: SRC): void {\n  const xs: Array<SRC> = [x, OTHER];\n  for (const m of xs.filter((v): v is ACTUAL => v instanceof CLS)) {\n    BODY(m)\n  }\n}\n", ""),
    ("find", "function probe(x: SRC): void {\n  const xs: Array<SRC> = [OTHER, x];\n  const m = xs.find((v) => v instanceof CLS);\n  if (m) {\n    BODY(m)\n  }\n}\n", ""),
    ("guard_fn_inferred", "function isIt(v: SRC) {\n  return v instanceof CLS;\n}\nfunction probe(x: SRC): void {\n  if (isIt(x)) {\n    BODY(x)\n  }\n}\n", ""),
]


def subst(text, f, e):
    t = ELEMS[e][0]
    return (text.replace("SRCREAD", f["src_read"]).replace("SRCH", f["srch"]).replace("SRC", f["src"])
            .replace("ACTUAL", f["actual"]).replace("CLS", f["cls"]).replace("OTHER", f["other"] or "undefined")
            .replace("ELT", t))


def main_part(f, e):
    t, v1, v2, _ = ELEMS[e]
    lines = [f"const v1: {t} = {v1};", f"const v2: {t} = {v2};", f"const obj: {f['actual']} = {f['make']};"]
    lines.append(f["call"].replace("ARG", "obj"))
    if f["other"] is not None:
        lines.append(f["call"].replace("ARG", f["other"]))
    lines.append('console.log("after", obj.val, obj.hits, obj.items.length);')
    return subst("\n".join(lines) + "\n" + f["extra_main"], f, e)


def program_a(f, use, e):
    name, body, helper = use
    peek = helper == "PEEK"
    decls = f["decls"](peek)
    helpers = "" if helper in ("PEEK", "PAR") else helper
    sig = f["sig"]
    probe = f"{sig} {{\n  if (x instanceof CLS) {{\n    {body.replace('X', 'x')}\n  }} else {{\n    console.log(\"no\", typeof x);\n  }}\n}}\n"
    src = ELEMS[e][3] + subst(decls + helpers + probe, f, e) + main_part(f, e)
    return src


def program_c(f, form, e):
    fname, template, _ = form
    decls = f["decls"](False)
    code = template
    # BODY(R) and EXPR(R)
    import re
    code = re.sub(r"BODY\(([^)]*)\)", lambda m: FORM_USE.replace("@R", m.group(1)), code)
    code = re.sub(r"EXPR\(([^)]*)\)", lambda m: FORM_EXPR.replace("@R", m.group(1)), code)
    if f["sig"] != "function probe(x: SRC): void":
        code = code.replace("function probe(x: SRC): void", f["sig"])
    src = ELEMS[e][3] + subst(decls + code, f, e) + main_part(f, e)
    return src


def header(meta):
    return "// H10 matrix case: " + json.dumps(meta, sort_keys=True) + "\n"


def generate(out):
    cases = []
    os.makedirs(os.path.join(out, "cases"), exist_ok=True)

    def add(cid, meta, src):
        meta = dict(meta, id=cid)
        par = ".par." in src
        meta["par"] = par
        meta["threads"] = [1, 2, 4] if par else [None]
        path = os.path.join(out, "cases", cid + ".pts")
        with open(path, "w") as fh:
            fh.write(header(meta) + src)
        cases.append(meta)

    # Part A: every family x every use, number elements.
    for f in FAMILIES:
        for use in USES:
            if f["name"] == "error" and use[0] == "log_object":
                continue  # an Error's console.log prints its stack, which differs by path
            add(f"A_{f['name']}__{use[0]}", dict(part="A", family=f["name"], use=use[0], elem="number", form="if", infer=f["infer"]),
                program_a(f, use, "number"))
    # Part B: element types x families x uses.
    for e in ["string", "boolean", "object", "array", "nested", "literal"]:
        for fn in ["iface", "base_abstract", "object", "typeparam_iface"]:
            for un in ["field", "method_arg", "field_write", "const_copy"]:
                f = FAMILY[fn]
                add(f"B_{e}__{fn}__{un}", dict(part="B", family=fn, use=un, elem=e, form="if", infer=f["infer"]),
                    program_a(f, USE[un], e))
    # Part C: forms x families, combined use.
    for fn in ["iface", "base_abstract", "object", "unknown", "ctl_same_union"]:
        for form in FORMS:
            f = FAMILY[fn]
            add(f"C_{fn}__{form[0]}", dict(part="C", family=fn, use="combined", elem="number", form=form[0], infer=f["infer"]),
                program_c(f, form, "number"))
    for form in FORMS:
        if form[0] in ("if", "catch", "catch_any"):
            f = FAMILY["error"]
            add(f"C_error__{form[0]}", dict(part="C", family="error", use="combined", elem="number", form=form[0], infer=f["infer"]),
                program_c(f, form, "number"))
    # Part D: variance and two instances at one place.
    for f in D_FAMILIES:
        elem = "dog" if f["name"] == "var_class_arg" else "number"
        for un in ["field", "method", "field_write", "const_copy", "pass_actual", "log_object"]:
            add(f"D_{f['name']}__{un}", dict(part="D", family=f["name"], use=un, elem=elem, form="if", infer=f["infer"]),
                program_a(f, USE[un], elem))
    # Part D: a narrowed value from a dynamic source passed to the interface type.
    for fn in ["unknown", "any"]:
        f = FAMILY[fn]
        use = ("pass_iface", 'console.log("iface", takeIface(X));', 'function takeIface(c: Cache<string, ELT>) {\n  return c.get("k");\n}\n')
        add(f"D_{fn}__pass_iface", dict(part="D", family=fn, use="pass_iface", elem="number", form="if", infer=f["infer"]), program_a(f, use, "number"))
    with open(os.path.join(out, "manifest.json"), "w") as fh:
        json.dump(cases, fh, indent=1)
    return cases


if __name__ == "__main__":
    cases = generate(sys.argv[1])
    print(len(cases), "cases")
