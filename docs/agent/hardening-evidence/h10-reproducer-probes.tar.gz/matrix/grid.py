#!/usr/bin/env python3
"""Prints Part A's family x use grid of classes (one letter each) from results JSONL files.
Later files override earlier ones for the same case id.
O=OK W=WRONG T=TYPEERR P=PTS1001 9=PTS9001 C=CRASH X=TIMEOUT S=TSERR B=BUILDFAIL N=NODEFAIL"""
import json
import sys

LETTER = {"OK": "O", "WRONG": "W", "TYPEERR": "T", "PTS1001": "P", "PTS9001": "9", "CRASH": "C", "TIMEOUT": "X",
          "TSERR": "S", "BUILDFAIL": "B", "NODEFAIL": "N"}
rows = {}
for p in sys.argv[1:]:
    for line in open(p):
        r = json.loads(line)
        rows[r["id"]] = r
part = "A"
a = [r for r in rows.values() if r["part"] == part]
fams = sorted({r["family"] for r in a})
uses = []
for r in sorted(a, key=lambda r: r["id"]):
    if r["use"] not in uses:
        uses.append(r["use"])
uses.sort()
print(" " * 20 + " ".join(f"{i:>2}" for i in range(len(uses))))
for f in fams:
    line = f"{f:20}"
    for u in uses:
        r = rows.get(f"A_{f}__{u}")
        line += " " + (" " + LETTER[r["class"]] if r else "  ")
    print(line)
for i, u in enumerate(uses):
    print(f"{i:>2} {u}")
