#!/usr/bin/env python3
"""Writes one CSV row per matrix case with its class under each design.
Usage: combined_csv.py OUT.csv NAME=results.jsonl ..."""
import csv
import json
import sys

out = sys.argv[1]
designs = []
for arg in sys.argv[2:]:
    name, path = arg.split("=", 1)
    designs.append((name, {json.loads(l)["id"]: json.loads(l) for l in open(path)}))
base = designs[0][1]
with open(out, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["id", "part", "family", "use", "form", "elem", "infer"] + [n for n, _ in designs] + ["head_detail"])
    for i in sorted(base):
        r = base[i]
        w.writerow([i, r["part"], r["family"], r["use"], r["form"], r["elem"], r["infer"]] +
                   [rows[i]["class"] if i in rows else "" for _, rows in designs] + [str(r.get("detail", ""))[:200]])
print("wrote", out)
