#!/usr/bin/env python3
"""Summarises H10 matrix results: counts by class, family x class, use x class, form x
family, element x family, distinct failure details. Writes a CSV next to the JSONL.

Usage: analyze.py RESULTS.jsonl [more.jsonl...]
"""
import collections
import csv
import json
import re
import sys

CLASSES = ["OK", "WRONG", "TYPEERR", "PTS1001", "PTS9001", "CRASH", "TIMEOUT", "TSERR", "BUILDFAIL", "NODEFAIL"]


def load(paths):
    rows = []
    for p in paths:
        for line in open(p):
            rows.append(json.loads(line))
    return rows


def norm(detail):
    d = detail if isinstance(detail, str) else json.dumps(detail)
    d = re.sub(r"^.*?error (PTS\d+|TS\d+)", r"\1", d)
    d = re.sub(r"/tmp/\S+", "<file>", d)
    return d[:160]


def table(rows, key, title):
    counts = collections.defaultdict(collections.Counter)
    for r in rows:
        counts[r[key]][r["class"]] += 1
    used = [c for c in CLASSES if any(counts[k][c] for k in counts)]
    print(f"\n## {title}")
    print(f"{key:24} " + " ".join(f"{c:>8}" for c in used) + "    total")
    for k in sorted(counts):
        print(f"{k:24} " + " ".join(f"{counts[k][c]:>8}" for c in used) + f"    {sum(counts[k].values())}")


def main():
    rows = load(sys.argv[1:])
    total = collections.Counter(r["class"] for r in rows)
    print("cases", len(rows), dict(total))
    for part in sorted({r["part"] for r in rows}):
        pr = [r for r in rows if r["part"] == part]
        print(f"part {part}: {len(pr)}", dict(collections.Counter(r["class"] for r in pr)))
    a = [r for r in rows if r["part"] == "A"]
    if a:
        table(a, "family", "Part A: family x class (number elements, if)")
        table(a, "use", "Part A: use x class")
    b = [r for r in rows if r["part"] == "B"]
    if b:
        for r in b:
            r["elem_family"] = r["elem"] + "/" + r["family"]
        table(b, "elem_family", "Part B: element/family x class")
    c = [r for r in rows if r["part"] == "C"]
    if c:
        for r in c:
            r["form_family"] = r["form"] + "/" + r["family"]
        table(c, "form", "Part C: form x class (all families)")
        table(c, "form_family", "Part C: form/family x class")
    d = [r for r in rows if r["part"] == "D"]
    if d:
        table(d, "family", "Part D: family x class")
    print("\n## distinct details (class: count  detail)")
    det = collections.Counter((r["class"], norm(r.get("detail", ""))) for r in rows if r["class"] != "OK")
    for (cls, dd), n in det.most_common():
        print(f"{cls:8} {n:4}  {dd}")
    out = re.sub(r"\.jsonl$", ".csv", sys.argv[1])
    with open(out, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "part", "family", "use", "form", "elem", "infer", "class", "detail"])
        for r in sorted(rows, key=lambda r: r["id"]):
            w.writerow([r["id"], r["part"], r["family"], r["use"], r["form"], r["elem"], r["infer"], r["class"], norm(r.get("detail", ""))])
    print("\ncsv:", out)


if __name__ == "__main__":
    main()
