#!/usr/bin/env bash
# Runs the matrix with the corrected A+B+C and with C alone, one after the other (2 jobs each).
set -u
cd /tmp/h10/matrix || exit 2
export PTS_HOME=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4
python3 run.py out_full/cases /tmp/h10/matrix/protoABC2.jsonl --pts /tmp/h10/protoC/pts_abc > /tmp/h10/matrix/protoABC2.log 2>&1
python3 run.py out_full/cases /tmp/h10/matrix/protoC.jsonl --pts /tmp/h10/protoConly/pts_c > /tmp/h10/matrix/protoC.log 2>&1
echo exit=$? >> /tmp/h10/matrix/protoC.log
