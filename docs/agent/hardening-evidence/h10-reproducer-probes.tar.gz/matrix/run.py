#!/usr/bin/env python3
"""Runs the H10 matrix: each case under Node (as the harness does: a .mts copy, with
`.par.` made sequential for ParallelScript-only cases) and under pts (built, run with a
timeout under each PTS_THREADS value, binary deleted right after), and classifies it.

Usage: run.py CASEDIR RESULTS.jsonl [--pts PATH] [--jobs N] [--filter REGEX]

Classes: OK, WRONG (other stdout or exit code), TYPEERR (a pts TypeError Node doesn't
throw), PTS1001, PTS9001, TSERR (a tsc error: a generator bug), BUILDFAIL, CRASH (a
signal), TIMEOUT, NODEFAIL (Node itself failed: a generator bug).
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading

NODE = os.path.expanduser("~/.local/node/bin/node")
DEFAULT_PTS = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a3112385051b6fcf4/pts-bin/pts"
ENV = dict(os.environ, TZ="America/New_York")


def run(cmd, cwd, timeout, env=ENV):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout, errors="replace")
        return p.returncode, p.stdout, p.stderr, False
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        err = e.stderr.decode(errors="replace") if isinstance(e.stderr, bytes) else (e.stderr or "")
        return None, out, err, True


def first_diff(a, b):
    al, bl = a.splitlines(), b.splitlines()
    for i in range(max(len(al), len(bl))):
        x = al[i] if i < len(al) else "<none>"
        y = bl[i] if i < len(bl) else "<none>"
        if x != y:
            return {"line": i + 1, "node": x, "pts": y}
    return None


def one(case_path, meta, pts, work_root):
    cid = meta["id"]
    work = tempfile.mkdtemp(prefix=cid[:40] + ".", dir=work_root)
    try:
        src = open(case_path).read()
        twin = src.replace(".par.", ".")
        with open(os.path.join(work, cid + ".mts"), "w") as fh:
            fh.write(twin)
        ncode, nout, nerr, nto = run([NODE, "--no-warnings", "--experimental-transform-types", cid + ".mts"], work, 30)
        res = dict(meta, node_exit=ncode, node_out=nout[-3000:], node_err=nerr[-1500:])
        if nto or ncode != 0:
            res["class"] = "NODEFAIL"
            return res
        binp = os.path.join(work, "case.bin")
        bcode, bout, berr, bto = run([pts, "build", case_path, "-o", binp], work, 180)
        res["build_exit"] = bcode
        if bto:
            res["class"] = "TIMEOUT"
            res["detail"] = "build timeout"
            return res
        if bcode != 0:
            text = bout + berr
            res["build_err"] = text[-2000:]
            if "PTS9001" in text or bcode == 3:
                res["class"] = "PTS9001"
            elif "PTS1001" in text:
                res["class"] = "PTS1001"
            elif re.search(r"error TS\d+", text):
                res["class"] = "TSERR"
            else:
                res["class"] = "BUILDFAIL"
            m = re.search(r"error (PTS\d+|TS\d+): (.*)", text)
            res["detail"] = m.group(0) if m else text.strip().splitlines()[-1:]
            return res
        runs = []
        worst = "OK"
        order = ["OK", "WRONG", "TYPEERR", "CRASH", "TIMEOUT"]
        for threads in meta["threads"]:
            env = dict(ENV)
            if threads is not None:
                env["PTS_THREADS"] = str(threads)
            pcode, pout, perr, pto = run([binp], work, 30, env)
            if pto:
                cls = "TIMEOUT"
            elif pcode is not None and (pcode < 0 or pcode >= 128):
                cls = "CRASH"
            elif pout == nout and pcode == ncode:
                cls = "OK"
            elif "TypeError" in perr and "TypeError" not in nout + nerr:
                cls = "TYPEERR"
            else:
                cls = "WRONG"
            runs.append(dict(threads=threads, exit=pcode, cls=cls, out=pout[-3000:], err=perr[-1500:], diff=first_diff(nout, pout)))
            if order.index(cls) > order.index(worst):
                worst = cls
        res["runs"] = runs
        res["class"] = worst
        bad = next((r for r in runs if r["cls"] != "OK"), None)
        if bad:
            errline = next((l for l in bad["err"].splitlines() if "Error" in l or "error" in l), "")
            res["detail"] = errline or (json.dumps(bad["diff"]) if bad["diff"] else "")
        return res
    finally:
        shutil.rmtree(work, ignore_errors=True)  # the binary goes with it


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("casedir")
    ap.add_argument("results")
    ap.add_argument("--pts", default=os.environ.get("PTS", DEFAULT_PTS))
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--filter", default="")
    a = ap.parse_args()
    a.casedir = os.path.abspath(a.casedir)
    manifest = json.load(open(os.path.join(os.path.dirname(a.casedir.rstrip("/")), "manifest.json")))
    rx = re.compile(a.filter) if a.filter else None
    todo = [m for m in manifest if not rx or rx.search(m["id"])]
    work_root = tempfile.mkdtemp(prefix="h10-matrix-", dir="/tmp/h10")
    lock = threading.Lock()
    counts = {}
    with open(a.results, "w") as out, cf.ThreadPoolExecutor(a.jobs) as pool:
        futs = {pool.submit(one, os.path.join(a.casedir, m["id"] + ".pts"), m, a.pts, work_root): m for m in todo}
        for i, fut in enumerate(cf.as_completed(futs), 1):
            r = fut.result()
            with lock:
                out.write(json.dumps(r) + "\n")
                out.flush()
                counts[r["class"]] = counts.get(r["class"], 0) + 1
            if i % 50 == 0:
                print(i, "/", len(todo), counts, flush=True)
    shutil.rmtree(work_root, ignore_errors=True)
    print("done", len(todo), counts, flush=True)


if __name__ == "__main__":
    main()
