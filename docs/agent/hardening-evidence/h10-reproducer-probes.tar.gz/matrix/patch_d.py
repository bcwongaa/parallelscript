#!/usr/bin/env python3
"""Adds Part D (variance, two instances at one place, dynamic sources to the interface) to gen.py."""
p = "/tmp/h10/matrix/gen.py"
s = open(p).read()
if "D_FAMILIES" in s:
    raise SystemExit("already patched")
s = s.replace('''    "literal": ('"a" | "b"', '"a"', '"b"', ""),
}''', '''    "literal": ('"a" | "b"', '"a"', '"b"', ""),
    "dog": ("Dog", "new Dog()", "new Dog()", 'class Animal {\\n  name = "a";\\n}\\nclass Dog extends Animal {\\n  bark(): string { return "woof"; }\\n}\\n'),
}''')
s = s.replace('''FAMILY = {f["name"]: f for f in FAMILIES}''', '''# Part D: the object's type arguments differ from the declared type's (variance), or two
# instances reach one place: what the declared type implies isn't the object's instance.
D_FAMILIES = [
    fam("var_wider_v", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, number | string>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, number | string>()", 'c.get("k")', "wrong (infers MapLRU<string, number | string>)",
        note="Cache<string, number | string> holding a MapLRU<string, number>"),
    fam("var_unknown_k", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, ELT>", "MapLRU", "MapLRU<unknown, ELT>",
        'new MapLRU<unknown, ELT>("k", v1)', "new Other<string, ELT>()", 'c.get("k")', "wrong (infers MapLRU<string, number>)",
        note="Cache<string, number> holding a MapLRU<unknown, number> (method parameters are bivariant)"),
    fam("var_base_wider", lambda peek: FAMILY0["base_abstract"]["decls"](peek), "Option<number | string>", "Some", "Some<ELT>",
        "new Some<ELT>(v1)", "new None<number | string>()", "c.isSome()", "wrong (infers Some<number | string>)",
        note="Option<number | string> holding a Some<number>"),
    fam("var_class_arg", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, Animal>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, Animal>()", 'c.get("k")', "wrong (infers MapLRU<string, Animal>)",
        note="Cache<string, Animal> holding a MapLRU<string, Dog>"),
    fam("union_two_insts", lambda peek: CACHE + maplru(peek) + OTHER_CACHE, "Cache<string, number> | Cache<number, string>", "MapLRU", "MapLRU<string, ELT>",
        'new MapLRU<string, ELT>("k", v1)', "new Other<string, number>()", 'c.get("k" as never)', "no (two instances)",
        extra_main='probe(new MapLRU<number, string>(1, "one"));\\n',
        note="Cache<string, number> | Cache<number, string> reached by MapLRU<string, number> and MapLRU<number, string>"),
]
FAMILY0 = {f["name"]: f for f in FAMILIES}
FAMILY = {f["name"]: f for f in FAMILIES + D_FAMILIES}''')
s = s.replace('''    with open(os.path.join(out, "manifest.json"), "w") as fh:''', '''    # Part D: variance and two instances at one place.
    for f in D_FAMILIES:
        elem = "dog" if f["name"] == "var_class_arg" else "number"
        for un in ["field", "method", "field_write", "const_copy", "pass_actual", "log_object"]:
            add(f"D_{f['name']}__{un}", dict(part="D", family=f["name"], use=un, elem=elem, form="if", infer=f["infer"]),
                program_a(f, USE[un], elem))
    # Part D: a narrowed value from a dynamic source passed to the interface type.
    for fn in ["unknown", "any"]:
        f = FAMILY[fn]
        use = ("pass_iface", 'console.log("iface", takeIface(X));', 'function takeIface(c: Cache<string, ELT>) {\\n  return c.get("k");\\n}\\n')
        add(f"D_{fn}__pass_iface", dict(part="D", family=fn, use="pass_iface", elem="number", form="if", infer=f["infer"]), program_a(f, use, "number"))
    with open(os.path.join(out, "manifest.json"), "w") as fh:''')
open(p, "w").write(s)
print("patched")
