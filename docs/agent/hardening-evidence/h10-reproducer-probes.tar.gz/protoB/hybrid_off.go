package lower

import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
)

// hybridDecides: pure prototype B, every such reference stays dynamic.
func (l *lowerer) hybridDecides(node *ast.Node, t *checker.Type) bool {
	return false
}
