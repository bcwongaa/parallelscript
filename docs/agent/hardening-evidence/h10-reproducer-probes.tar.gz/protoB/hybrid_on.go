package lower

import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
)

// hybridDecides: prototype A's inference decides the instance (instanceofInstance changed
// tsc's type), so the reference is typed as that instance; otherwise it stays dynamic (B).
func (l *lowerer) hybridDecides(node *ast.Node, t *checker.Type) bool {
	return l.instanceofInstance(node, t) != t
}
