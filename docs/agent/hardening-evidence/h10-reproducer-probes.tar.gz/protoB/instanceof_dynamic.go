package lower

// H10 prototype B (evidence only): a reference that `instanceof` narrowed to a generic
// class's instance for any (tsc's `C<any, …>`) from a declared type that isn't that
// instance (nor any or unknown, which stay dynamic already) is kept a dynamic value, whose
// members are read, written and called as a dynamic value's (D-179's narrowed dynamic
// values). In the hybrid build, only where prototype A's inference doesn't decide.

import (
	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
)

// isAnyInstanceNarrowing reports whether node is such a reference.
func (l *lowerer) isAnyInstanceNarrowing(node *ast.Node) bool {
	switch node.Kind {
	case ast.KindIdentifier, ast.KindPropertyAccessExpression, ast.KindElementAccessExpression:
	default:
		return false
	}
	if ast.IsDeclarationName(node) || ast.IsWriteOnlyAccess(node) {
		return false
	}
	t := l.instantiate(l.checker.GetTypeAtLocation(node))
	members := []*checker.Type{t}
	if t.Flags()&checker.TypeFlagsIntersection != 0 {
		members = t.Types()
	}
	var proto *checker.Type
	for _, member := range members {
		if l.isAnyInstanceB(member) {
			proto = member
		}
	}
	if proto == nil {
		return false
	}
	declared := l.declaredReferenceTypeB(node)
	if declared == nil || declared == proto || l.isAnyInstanceB(declared) || declared.Flags()&(checker.TypeFlagsAny|checker.TypeFlagsUnknown) != 0 {
		return false
	}
	if l.hybridDecides(node, t) {
		return false
	}
	return true
}

// isAnyInstanceB reports whether t is a generic class of the program's instance whose type
// arguments are all any.
func (l *lowerer) isAnyInstanceB(t *checker.Type) bool {
	if t.Flags()&checker.TypeFlagsObject == 0 || t.ObjectFlags()&checker.ObjectFlagsReference == 0 {
		return false
	}
	if _, ok := l.genericClasses[t.Symbol()]; !ok {
		return false
	}
	arguments := l.checker.GetTypeArguments(t)
	if len(arguments) == 0 {
		return false
	}
	for _, argument := range arguments {
		if argument.Flags()&checker.TypeFlagsAny == 0 && !(argument.Flags()&checker.TypeFlagsTypeParameter != 0 && argument.AsTypeParameter().IsThisType()) {
			return false
		}
	}
	return true
}

// declaredReferenceTypeB is the declared type of the variable, property or element node
// reads, before narrowing, instantiated; nil if it has none.
func (l *lowerer) declaredReferenceTypeB(node *ast.Node) *checker.Type {
	if declared, _ := l.readTypes(node); declared != nil {
		return l.instantiate(declared)
	}
	if node.Kind == ast.KindElementAccessExpression {
		if object := l.instantiate(l.checker.GetTypeAtLocation(node.Expression())); l.checker.IsArrayType(object) {
			return l.checker.GetElementTypeOfArrayType(object)
		}
	}
	return nil
}
