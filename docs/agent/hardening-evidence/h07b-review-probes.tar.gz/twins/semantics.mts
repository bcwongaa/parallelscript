// Review probe: JS/DOM edge cases of abort.pts at 1 thread, compared with Node.
function log(...parts: unknown[]): void {
  console.log(parts.map(String).join(" "));
}

{
  log("-- A once on source, abort twice");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => log("once; d", d.aborted), { once: true });
  d.addEventListener("abort", () => log("d once"), { once: true });
  a.abort("x");
  a.abort("y");
  log("reason", d.reason);
}
{
  log("-- B add to dependent during source dispatch");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => {
    d.addEventListener("abort", () => log("added during source dispatch"));
  });
  a.abort();
}
{
  log("-- C remove from dependent during source dispatch");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  const l = (): void => log("SHOULD NOT RUN");
  d.addEventListener("abort", l);
  a.signal.addEventListener("abort", () => {
    d.removeEventListener("abort", l);
  });
  a.abort();
  log("done C");
}
{
  log("-- D stopImmediatePropagation on source");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", (e) => {
    log("first");
    e.stopImmediatePropagation();
  });
  a.signal.addEventListener("abort", () => log("SHOULD NOT RUN"));
  d.addEventListener("abort", () => log("d still fires"));
  a.abort();
}
{
  log("-- F any inside dispatch");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => {
    const x = AbortSignal.any([d]);
    log("x", x.aborted, x.reason);
    const y = AbortSignal.any([new AbortController().signal, d]);
    log("y", y.aborted, y.reason);
  });
  a.abort("F");
}
{
  log("-- G signal option on itself");
  const a = new AbortController();
  a.signal.addEventListener("abort", () => log("self listener"), { signal: a.signal });
  a.abort();
}
{
  log("-- H signal option with dependent");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  const t = new EventTarget();
  t.addEventListener("ping", () => log("ping listener"), { signal: d });
  a.signal.addEventListener("abort", () => {
    t.dispatchEvent(new Event("ping"));
    log("source listener dispatched ping");
  });
  a.abort();
  t.dispatchEvent(new Event("ping"));
  log("done H");
}
{
  log("-- I duplicate add with signal");
  const a = new AbortController();
  const t = new EventTarget();
  const l = (): void => log("listener called");
  t.addEventListener("ping", l);
  t.addEventListener("ping", l, { signal: a.signal });
  a.abort();
  t.dispatchEvent(new Event("ping"));
  log("done I");
}
{
  log("-- J onabort null and back");
  const a = new AbortController();
  a.signal.onabort = () => log("onabort 1");
  a.signal.addEventListener("abort", () => log("listener"));
  a.signal.onabort = null;
  a.signal.onabort = () => log("onabort 2");
  a.abort();
}
{
  log("-- K any([])");
  const e = AbortSignal.any([]);
  const f = AbortSignal.any([e]);
  log("e", e.aborted, "f", f.aborted);
}
{
  log("-- N untrusted abort event");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  d.addEventListener("abort", () => log("d listener"));
  a.signal.addEventListener("abort", (e) => log("a listener trusted", e.isTrusted));
  a.signal.dispatchEvent(new Event("abort"));
  log("a", a.signal.aborted, "d", d.aborted);
}
{
  log("-- O once re-adding itself");
  const t = new EventTarget();
  let n = 0;
  const l = (): void => {
    n++;
    log("call", n);
    if (n < 3) {
      t.addEventListener("ping", l, { once: true });
    }
  };
  t.addEventListener("ping", l, { once: true });
  for (let i = 0; i < 4; i++) {
    t.dispatchEvent(new Event("ping"));
  }
}
{
  log("-- P remove and re-add during dispatch");
  const t = new EventTarget();
  const l2 = (): void => log("l2");
  t.addEventListener("ping", () => {
    t.removeEventListener("ping", l2);
    t.addEventListener("ping", l2);
    log("l1");
  });
  t.addEventListener("ping", l2);
  t.dispatchEvent(new Event("ping"));
  log("second");
  t.dispatchEvent(new Event("ping"));
}
{
  log("-- S throwIfAborted on a dependent in the source's listener");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => {
    try {
      d.throwIfAborted();
      log("no throw");
    } catch (e) {
      log("threw", e);
    }
  });
  a.abort("S");
}
{
  log("-- U onabort set during source dispatch");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.onabort = () => {
    d.onabort = () => log("d onabort set during a's dispatch");
  };
  a.abort();
}
{
  log("-- W a dependent's listener adds to a later dependent");
  const a = new AbortController();
  const d1 = AbortSignal.any([a.signal]);
  const d2 = AbortSignal.any([a.signal]);
  d1.addEventListener("abort", () => d2.addEventListener("abort", () => log("added to d2 by d1")));
  d2.addEventListener("abort", () => log("d2 original"));
  a.abort();
}
{
  log("-- X once listener removed by an earlier listener");
  const t = new EventTarget();
  const l = (): void => log("SHOULD NOT RUN");
  t.addEventListener("ping", () => t.removeEventListener("ping", l));
  t.addEventListener("ping", l, { once: true });
  t.dispatchEvent(new Event("ping"));
  t.addEventListener("ping", l, { once: true });
  log("re-added once after removal");
}
{
  log("-- Y source aborts in a dependent's own listener chain");
  const a = new AbortController();
  const b = new AbortController();
  const d = AbortSignal.any([a.signal, b.signal]);
  const e = AbortSignal.any([b.signal]);
  d.addEventListener("abort", () => {
    b.abort("b in d");
    log("after b.abort in d's listener; e", e.aborted, e.reason);
  });
  e.addEventListener("abort", () => log("e listener", e.reason));
  a.abort("a");
}
{
  log("-- Z console.log");
  console.log(new AbortController().signal);
  console.log(new EventTarget());
  console.log(AbortSignal.any([new AbortController().signal]));
  console.log(AbortSignal.abort("z"));
}
