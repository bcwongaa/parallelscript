// Review probe: an own accessor named "aborted" on a signal; #settle's write of aborted runs its
// setter while the signal's lock is held, and the setter adds a listener (the same lock).
const controller = new AbortController();
let stored = false;
Object.defineProperty(controller.signal, "aborted", {
  get() {
    return stored;
  },
  set(value: boolean) {
    console.error("setter called with", value);
    controller.signal.addEventListener("abort", () => console.error("listener from setter"));
    stored = value;
  },
  configurable: true,
});
console.error("aborting");
try {
  controller.abort("x");
  console.error("abort returned; aborted", controller.signal.aborted);
} catch (error) {
  console.error("abort threw", String(error));
}
console.error("end");
