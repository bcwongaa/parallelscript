// Review probe: a throw inside #settle's critical section (a frozen signal) must not leave the lock held.
const controller = new AbortController();
Object.freeze(controller.signal);
try {
  controller.abort("frozen");
  console.log("abort returned; aborted", controller.signal.aborted, "reason", controller.signal.reason);
} catch (error) {
  console.log("abort threw", String(error));
}
console.log("adding a listener after that...");
controller.signal.addEventListener("abort", () => console.log("listener"));
console.log("added; aborting again...");
try {
  controller.abort("again");
  console.log("second abort returned");
} catch (error) {
  console.log("second abort threw", String(error));
}
const follower = AbortSignal.any([controller.signal]);
console.log("follower made; aborted", follower.aborted);
console.log("end");
