// Review probe 2: listeners typed as EventListener (no C118 adapters), and Node's lazy composites.
function log(...parts: unknown[]): void {
  console.log(parts.map(String).join(" "));
}
{
  log("-- C remove from dependent during source dispatch");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  const l: EventListener = () => log("SHOULD NOT RUN");
  d.addEventListener("abort", l);
  a.signal.addEventListener("abort", () => {
    d.removeEventListener("abort", l);
  });
  a.abort();
  log("done C");
}
{
  log("-- P remove and re-add during dispatch");
  const t = new EventTarget();
  const l2: EventListener = () => log("l2");
  t.addEventListener("ping", () => {
    t.removeEventListener("ping", l2);
    t.addEventListener("ping", l2);
    log("l1");
  });
  t.addEventListener("ping", l2);
  t.dispatchEvent(new Event("ping"));
  log("second");
  t.dispatchEvent(new Event("ping"));
}
{
  log("-- X once listener removed by an earlier listener");
  const t = new EventTarget();
  const l: EventListener = () => log("SHOULD NOT RUN");
  t.addEventListener("ping", () => t.removeEventListener("ping", l));
  t.addEventListener("ping", l, { once: true });
  t.dispatchEvent(new Event("ping"));
  log("done X");
}
{
  log("-- I duplicate add with signal");
  const a = new AbortController();
  const t = new EventTarget();
  const l: EventListener = () => log("listener called");
  t.addEventListener("ping", l);
  t.addEventListener("ping", l, { signal: a.signal });
  a.abort();
  t.dispatchEvent(new Event("ping"));
  log("done I");
}
{
  log("-- R1 two sources, no listener on the follower: reason");
  const a = new AbortController();
  const b = new AbortController();
  const d = AbortSignal.any([a.signal, b.signal]);
  b.abort("b first");
  a.abort("a second");
  log("d", d.reason);
}
{
  log("-- R2 two sources, follower with a listener: reason");
  const a = new AbortController();
  const b = new AbortController();
  const d = AbortSignal.any([a.signal, b.signal]);
  d.addEventListener("abort", () => {});
  b.abort("b first");
  a.abort("a second");
  log("d", d.reason);
}
{
  log("-- R3 follower without listeners read in the source's listener");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => log("in a's listener d", d.aborted));
  a.abort();
  d.addEventListener("abort", () => log("SHOULD NOT RUN: added after"));
  log("done R3");
}
{
  log("-- R4 onabort of a non-listened follower set in the source's listener");
  const a = new AbortController();
  const d = AbortSignal.any([a.signal]);
  a.signal.addEventListener("abort", () => {
    d.onabort = () => log("d onabort (spec: runs; Node 24.21: lazy follower, doesn't)");
  });
  a.abort();
  log("done R4");
}
