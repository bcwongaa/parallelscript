// Review probe: the new private fields stay invisible to reflection.
const c = new AbortController();
const d = AbortSignal.any([c.signal]);
const t = new EventTarget();
console.log(JSON.stringify(c.signal), JSON.stringify(d), JSON.stringify(t));
console.log(Object.keys(c.signal).join(","), Object.keys(d).join(","), Object.keys(t).join(","));
const e: any = d;
for (const k in e) {
  console.log("for-in key", k);
}
