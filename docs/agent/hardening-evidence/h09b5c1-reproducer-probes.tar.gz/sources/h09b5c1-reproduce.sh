#!/usr/bin/env bash
# Reproduce H09b5c1 test-only evidence against the unchanged 7b3b240da compiler.
# Arguments: assigned worktree, new empty output directory.
set -u
wt=${1:?worktree required}
out=${2:?output directory required}
mkdir -p "$out"
cd "$wt" || exit 99
export GOMAXPROCS=2
export PTS_HOME="$wt"
export PTS_REQUIRE_NODE=1

{
  git rev-parse HEAD
  go version
  /home/bryan/.local/node/bin/node --version
  clang --version
} > "$out/environment.log" 2>&1

red=(go test -count=1 -p 2 -parallel 2 -timeout 10m -run '^(TestValuesThatNoTypedCallReachesGetNoInstances|TestClosedValueDemandsOnlyInstantiateTheirKnownSources|TestUnknownConsumersKeepCompatibleValues)$' -v ./pts/driver)
printf '%q ' "${red[@]}" > "$out/driver.command"
printf '\n' >> "$out/driver.command"
"${red[@]}" > "$out/driver.log" 2>&1
red_status=$?
printf '%s\n' "$red_status" > "$out/driver.exit"

# Affinity limits runtime.NumCPU(), including the native archive compiler pool.
runtime=(taskset -c 0,1 go test -count=1 -p 2 -parallel 2 -timeout 20m -run '^(TestRun|TestRunMatchesNode)$/^(generic_value_flow_(expression_sources|unknown_origins|unknown_parameters)|generic_values_(read_back_from_any|any_boundaries)|generic_value_forms_any_boundaries)$' -v ./pts/tests)
printf '%q ' "${runtime[@]}" > "$out/runtime.command"
printf '\n' >> "$out/runtime.command"
"${runtime[@]}" > "$out/runtime.log" 2>&1
runtime_status=$?
printf '%s\n' "$runtime_status" > "$out/runtime.exit"

printf 'driver=%s (expected RED 1 on base), runtime=%s (expected 0)\n' "$red_status" "$runtime_status"
# A successful reproducer is not a claim that the baseline driver tests pass.
[[ "$red_status" == 1 && "$runtime_status" == 0 ]] &&
  grep -q '^--- FAIL: TestValuesThatNoTypedCallReachesGetNoInstances ' "$out/driver.log" &&
  grep -q '^--- FAIL: TestClosedValueDemandsOnlyInstantiateTheirKnownSources ' "$out/driver.log" &&
  grep -q '^--- PASS: TestUnknownConsumersKeepCompatibleValues ' "$out/driver.log" &&
  ! grep -q '\[build failed\]' "$out/driver.log"
