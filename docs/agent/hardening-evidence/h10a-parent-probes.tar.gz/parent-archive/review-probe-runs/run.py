import subprocess, os, sys, json, concurrent.futures as cf, shutil
P = sys.argv[1]; OUT = sys.argv[2]
clis = dict(base='/tmp/h10/pts-base', fix1='/tmp/h10/pts-fix1', fix2='/tmp/h10/pts-fix2', fix3='/tmp/h10/pts-fix3', fix4='/tmp/h10/pts-fix4')
env = dict(os.environ, PTS_HOME='/home/bryan/projects/parallelscript', TZ='America/New_York')
NODE = os.path.expanduser('~/.local/node/bin/node')
def run(cmd, cwd):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env, capture_output=True, text=True, timeout=90)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return None, '', 'TIMEOUT'
def one(f):
    name = f[:-4]
    res = {'probe': name}
    work = os.path.join(OUT, name); os.makedirs(work, exist_ok=True)
    shutil.copy(os.path.join(P, f), os.path.join(work, name + '.mts'))
    if os.path.isdir(os.path.join(P, name.split('_')[0] + '_mod')):
        pass
    c, o, e = run([NODE, '--no-warnings', '--experimental-transform-types', name + '.mts'], work)
    res['node'] = (c, o)
    for k, cli in clis.items():
        c, o, e = run([cli, 'run', os.path.join(P, f)], P)
        res[k] = (c, o, e[-600:])
    return res
files = sorted(x for x in os.listdir(P) if x.endswith('.pts'))
with cf.ThreadPoolExecutor(3) as ex:
    results = list(ex.map(one, files))
json.dump(results, open(os.path.join(OUT, 'results.json'), 'w'), indent=1)
for r in results:
    nc, no = r['node']
    row = []
    for k in ('base', 'fix3', 'fix4'):
        c, o, e = r[k]
        if c == nc and o == no: row.append('OK')
        elif 'PTS1001' in e: row.append('PTS1001')
        elif 'PTS9001' in e: row.append('PTS9001')
        elif 'TypeError' in e or 'TypeError' in o: row.append('TYPEERR')
        else: row.append('WRONG')
    print(f"{r['probe']:40s} {' '.join(f'{x:8s}' for x in row)}")
