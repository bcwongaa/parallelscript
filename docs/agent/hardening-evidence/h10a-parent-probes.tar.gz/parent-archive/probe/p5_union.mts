class Box<T> { constructor(public value: T) {} }
class Pair<A, B> { constructor(public a: A, public b: B) {} }
function f(x: Box<number> | Pair<string, number>): number {
  if (x instanceof Pair) return x.b + x.a.length;
  return x.value;
}
console.log(f(new Box(3)), f(new Pair("ab", 5)));
