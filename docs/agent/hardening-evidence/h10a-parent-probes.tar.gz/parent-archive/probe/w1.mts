class C<T> { items: T[] = []; }
function f(x: unknown) {
  if (x instanceof C) {
    x.items.push(8.5);
    console.log(x.items.length);
  }
}
const c = new C<number>(); c.items.push(7);
f(c);
console.log(c.items);
