class Shape { name = "shape"; }
class Tagged<T> extends Shape { constructor(public tag: T) { super(); } describe(): string { return `${this.name}:${this.tag}`; } }
function show(s: Shape): string {
  if (s instanceof Tagged) return `${s.describe()} ${s.tag} ${typeof s.tag}`;
  return s.name;
}
console.log(show(new Tagged(5)), show(new Tagged("x")), show(new Shape()));
function keep(s: Shape): Tagged<number> | null { return s instanceof Tagged ? s : null; }
console.log(keep(new Tagged(7))?.tag);
