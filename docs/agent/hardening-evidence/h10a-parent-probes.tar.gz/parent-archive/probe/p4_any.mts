class Box<T> { constructor(public value: T) {} get(): T { return this.value; } }
function show(x: any): string {
  if (x instanceof Box) return `box(${x.value}, ${x.get()})`;
  return "other";
}
console.log(show(new Box(1)), show(new Box("s")), show(3));
