interface Cache<K, V> { get(key: K): V | undefined; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V>();
  evictions: K[] = [];
  get(key: K): V | undefined { return this.store.get(key); }
  put(key: K, v: V): void { this.store.set(key, v); }
}
const c: Cache<string, number> = new MapLRU<string, number>();
if (c instanceof MapLRU) {
  c.put("b", 2);
  const ev = c.evictions;
  ev.push("z");
  console.log(c.evictions, ev === c.evictions);
  const v = c.get("b");
  console.log(v + 1);
  const n: number = c.get("b");
  console.log(n + 1);
}
