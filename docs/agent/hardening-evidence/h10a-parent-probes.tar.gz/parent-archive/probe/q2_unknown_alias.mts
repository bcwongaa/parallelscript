class MapLRU<K, V> { evictions: K[] = []; constructor(public cap: number) {} get(k: K): V | undefined { return undefined; } }
function f(x: unknown) {
  if (x instanceof MapLRU) {
    const ev = x.evictions;
    ev.push("z");
    console.log(x.evictions, ev === x.evictions);
    const n: number = x.cap;
    const g: number | undefined = x.get("q");
    console.log(n, g);
  }
}
f(new MapLRU<string, number>(3));
