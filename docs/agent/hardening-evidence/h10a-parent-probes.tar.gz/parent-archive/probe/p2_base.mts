abstract class Option<T> { abstract isSome(): boolean; }
class Some<T> extends Option<T> { constructor(public value: T) { super(); } isSome() { return true; } }
class None<T> extends Option<T> { isSome() { return false; } }
function unwrap(o: Option<number>): number {
  if (o instanceof Some) return o.value * 2;
  return -1;
}
console.log(unwrap(new Some(21)), unwrap(new None<number>()));
