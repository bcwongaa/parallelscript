const xs: string[] = ["a"];
const ys: any[] = xs;
ys.push("b");
console.log(xs, ys === xs);
