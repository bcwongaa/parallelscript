interface Cache<K, V> { get(key: K): V | undefined; readonly size: number; }
class MapLRU<K, V> implements Cache<K, V> {
  store = new Map<K, V>();
  evictions: K[] = [];
  get(key: K): V | undefined { return this.store.get(key); }
  put(key: K, v: V): void { this.store.set(key, v); }
  get size(): number { return this.store.size; }
}
const c: Cache<string, number> = new MapLRU<string, number>();
(c as MapLRU<string, number>).put("a", 1);
if (c instanceof MapLRU) {
  console.log(c.get("a"), c.size, c.evictions);
  c.put("b", 2);
  const n: number = c.get("b");
  console.log(n + 1);
}
