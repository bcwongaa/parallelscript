package ut

import (
	"fmt"
	"testing"

	"github.com/microsoft/typescript-go/internal/vfs/vfstest"
	"github.com/microsoft/typescript-go/pts/check"
	"github.com/microsoft/typescript-go/pts/frontend"
	"github.com/microsoft/typescript-go/pts/lower"
)

func TestDump(t *testing.T) {
	source := `interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  evictions: K[] = [];
  constructor(private key: K, private value: V) {}
  get(key: K): V | undefined {
    return key === this.key ? this.value : undefined;
  }
}
abstract class Option<T> {}
class Some<T> extends Option<T> {
  constructor(public value: T) {
    super();
  }
}
function read(cache: Cache<string, number>, o: Option<number>): number {
  if (cache instanceof MapLRU && o instanceof Some) return cache.evictions.length + o.value;
  return 0;
}
console.log(read(new MapLRU("a", 1), new Some(2)));
`
	fs := vfstest.FromMap(map[string]string{"/p/main.pts": source}, true)
	program, errors := frontend.Load(t.Context(), fs, "/p/main.pts")
	fmt.Println(errors)
	info, errors := check.Program(t.Context(), program)
	fmt.Println(errors)
	p, errors, _ := lower.ProgramWith(t.Context(), program, info, lower.AllInstances, nil)
	fmt.Println(errors)
	fmt.Println(p.String())
}
