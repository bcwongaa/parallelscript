#!/bin/bash
# emit-c of every program with the base and the fix; prints SAME/DIFF/ERR per file.
cd /home/bryan/projects/parallelscript
export PTS_HOME=$PWD
for f in pts/tests/run/*.pts pts/tests/errors/*.pts pts/tests/corpus/*/*.pts pts/tests/stress/*.pts docs/examples/*.pts; do
  b=$(timeout 120 /tmp/h10/pts-base emit-c "$f" -o /tmp/h10/sweep/b.c 2>/tmp/h10/sweep/b.err; echo $?)
  x=$(timeout 120 /tmp/h10/pts-fix1 emit-c "$f" -o /tmp/h10/sweep/x.c 2>/tmp/h10/sweep/x.err; echo $?)
  if [ "$b" != "$x" ]; then echo "EXIT $b $x $f"; continue; fi
  if [ "$b" != 0 ]; then
    if cmp -s /tmp/h10/sweep/b.err /tmp/h10/sweep/x.err; then echo "SAMEERR $f"; else echo "DIFFERR $f"; fi
    continue
  fi
  if cmp -s /tmp/h10/sweep/b.c /tmp/h10/sweep/x.c; then echo "SAME $f"; else echo "DIFF $f $(wc -l < /tmp/h10/sweep/b.c) $(wc -l < /tmp/h10/sweep/x.c)"; fi
  rm -f /tmp/h10/sweep/b.c /tmp/h10/sweep/x.c
done
