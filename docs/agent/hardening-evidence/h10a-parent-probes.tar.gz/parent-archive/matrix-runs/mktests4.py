import os, subprocess
RUN='/home/bryan/projects/parallelscript/pts/tests/run'
ERR='/home/bryan/projects/parallelscript/pts/tests/errors'
NODE=os.path.expanduser('~/.local/node/bin/node')
P4='/tmp/h10/review4-unpacked/review4/p'
def node_out(src, name):
    tmp=f'/tmp/h10/mine/{name}.mts'; open(tmp,'w').write(src.replace('.par.','.'))
    p=subprocess.run([NODE,'--no-warnings','--experimental-transform-types',tmp],capture_output=True,text=True,timeout=60)
    assert p.returncode==0, (name, p.stderr[:300])
    return ''.join('// '+l+'\n' if l else '//\n' for l in p.stdout.rstrip('\n').split('\n'))
def run_test(src, name, head):
    open(f'{RUN}/{name}.pts','w').write(head+'\n'+src.rstrip('\n')+'\n// expect:\n'+node_out(src,name)); print(name)
def err_test(src, name, head):
    msg="using the object an `instanceof` narrowing holds as a dynamic value as a value[] where it may be changed or kept"
    open(f'{ERR}/{name}.pts','w').write(head+'\n// error: '+msg+'\n'+src); print('errors/'+name)
for probe,name,fid in [('s01_unknown_read_only','generic_instanceof_unknown_member_reads','R4-F1'),('s02_catch_generic_error','generic_instanceof_catch_member_reads','R4-F1'),('s05_any_source_read_only','generic_instanceof_any_member_reads','R4-F1'),('s06b_more_paths','generic_instanceof_callback_and_await_paths','R4-F2')]:
    run_test(open(f'{P4}/{probe}.pts').read(), name, f"// H10a review round 4 ({fid}), the reviewer's probe {probe}.pts:")
src=open(f'{P4}/s03b_bypass_paths.pts').read().split('\n')
keep=[l for l in src if 'forEach annotated row' not in l]
run_test('\n'.join(keep), 'generic_instanceof_bypass_paths', "// H10a review round 4 (R4-F2), the reviewer's probe s03b_bypass_paths.pts without its annotated `(row: any[])` callback (errors/generic_instanceof_annotated_callback_copy.pts):")
annotated=[l for l in src if not l.startswith('check(') or 'forEach annotated row' in l]
err_test('\n'.join(annotated), 'generic_instanceof_annotated_callback_copy', "// H10a review round 4 (R4-F2: a callback parameter annotated `any[]` that a method of an instanceof narrowing's member array hands the instance's typed rows would copy them, so PTS1001, not a silent copy); from the reviewer's probe s03b_bypass_paths.pts.")
src=open(f'{P4}/s07_r15_unreported_sinks.pts').read().split('\n')
keep=[l for l in src if 'local shorthand' not in l]
run_test('\n'.join(keep), 'generic_instanceof_sinks_that_keep_the_object', "// H10a review round 4, the reviewer's probe s07_r15_unreported_sinks.pts (without its shorthand line, errors/generic_instanceof_shorthand_copy.pts): a conditional, `||`, `satisfies`, for…of destructuring and a local conditional keep the instance's array, as a dynamic value:")
err_test(open(f'{P4}/s08_object_literal_forms.pts').read(), 'generic_instanceof_shorthand_copy', "// H10a review round 4 (R4-F2: an object literal's shorthand or explicit property of a variable holding an instanceof narrowing's dynamic value would copy it into the literal's any[] field, so PTS1001, not a silent copy); the reviewer's probe s08_object_literal_forms.pts.")
