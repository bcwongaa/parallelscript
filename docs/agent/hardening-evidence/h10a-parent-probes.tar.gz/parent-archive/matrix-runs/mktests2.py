import os, subprocess
RUN='/home/bryan/projects/parallelscript/pts/tests/run'
ERR='/home/bryan/projects/parallelscript/pts/tests/errors'
NODE=os.path.expanduser('~/.local/node/bin/node')
P2='/tmp/h10/review2-unpacked/review2/p'
P1='/tmp/h10/review1-unpacked/review1/p'
spec = [
 (P2,'q01_mapped_members','generic_instanceof_mapped_members','round 2 (R2-F2)'),
 (P2,'q06_member_forms2','generic_instanceof_member_uses_d','round 2'),
 (P2,'q07_dynamic_call_results','generic_instanceof_dynamic_call_results','round 2 (R2-F1)'),
 (P2,'q08_member_local_alias','generic_instanceof_member_local_alias','round 2 (R2-F1)'),
 (P2,'q10_private_name_other_instance','generic_instanceof_private_name_other_instance','round 2'),
 (P2,'q11_optional_dynamic_calls','generic_instanceof_optional_dynamic_calls','round 2'),
 (P2,'q12b_member_object_alias','generic_instanceof_member_object_alias','round 2 (R2-F1)'),
 (P2,'q12c_unknown_object_alias','generic_instanceof_unknown_object_alias','round 2 (R2-F1)'),
 (P2,'q14_private_method_dynamic_call','generic_instanceof_private_method_literal_argument','round 2 (R2-F3)'),
 (P2,'q18_private_function_field','generic_instanceof_private_function_field','round 2'),
 (P2,'q19_uninferred_member_alias','generic_instanceof_uninferred_member_alias','round 2 (R2-F1)'),
 (P2,'q21_unreached_record_member','generic_instanceof_unreached_record_member','round 2 (R2-F2)'),
 (P1,'p15_nested_generic_members','generic_instanceof_nested_generic_members','round 1 (R1-F11)'),
 (P1,'p16_nested_parts','generic_instanceof_nested_parts','round 1 (R1-F11)'),
 (P1,'p21_optional_chains','generic_instanceof_optional_chains','round 1 (R1-F11)'),
 (P1,'p22_self_ref_members','generic_instanceof_self_referential_members','round 1 (R1-F11)'),
 (P1,'p45_private_chain','generic_instanceof_private_chain','round 1 (R1-F11)'),
]
for d,probe,name,rnd in spec:
    src=open(f'{d}/{probe}.pts').read()
    tmp=f'/tmp/h10/mine/{name}.mts'; open(tmp,'w').write(src)
    p=subprocess.run([NODE,'--no-warnings','--experimental-transform-types',tmp],capture_output=True,text=True,timeout=60)
    assert p.returncode==0, (probe, p.stderr[:300])
    head=f"// H10a review {rnd}, the reviewer's probe {probe}.pts:"
    out=''.join('// '+l+'\n' if l else '//\n' for l in p.stdout.rstrip('\n').split('\n'))
    open(f'{RUN}/{name}.pts','w').write(head+'\n'+src.rstrip('\n')+'\n// expect:\n'+out)
    print(name, len(p.stdout.splitlines()))
errs=[
 ('q04_classcast_targets','generic_instanceof_unrelated_class_target','using a `MapLRU` as a `Twin` is not supported yet','R2-F4: a narrowed reference where tsc takes an unrelated class structurally stays the base PTS1001, a conversion that can never succeed'),
 ('q09_member_passed_to_mutator','generic_instanceof_member_passed_to_mutator','using a number[] as a value[] where it may be changed or kept','R2-F1: a member array passed to an any[] parameter that changes it: a copy would lose the change (D-094), so PTS1001 as for typed arrays, not a silent copy'),
 ('q22_member_returned','generic_instanceof_member_returned','using a number[] as a value[] where it may be changed or kept','R2-F1: a member array returned from a function whose inferred return type is any[]: a copy would lose later writes (D-094), so PTS1001, not a silent copy'),
]
for probe,name,msg,why in errs:
    src=open(f'{P2}/{probe}.pts').read()
    open(f'{ERR}/{name}.pts','w').write(f"// H10a review round 2 ({why}); the reviewer's probe {probe}.pts.\n// error: {msg}\n"+src)
    print('errors/'+name)
