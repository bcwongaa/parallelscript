import os, subprocess
RUN='/home/bryan/projects/parallelscript/pts/tests/run'
ERR='/home/bryan/projects/parallelscript/pts/tests/errors'
NODE=os.path.expanduser('~/.local/node/bin/node')
P5='/tmp/h10/review5-unpacked/review5/p'
def node_out(src, name):
    tmp=f'/tmp/h10/mine/{name}.mts'; open(tmp,'w').write(src.replace('.par.','.'))
    p=subprocess.run([NODE,'--no-warnings','--experimental-transform-types',tmp],capture_output=True,text=True,timeout=60)
    assert p.returncode==0, (name, p.stderr[:300])
    return ''.join('// '+l+'\n' if l else '//\n' for l in p.stdout.rstrip('\n').split('\n'))
for probe,name,head in [
 ('t01_annotated_callback_false_positives','generic_instanceof_annotated_callback_reads',"// H10a review round 5 (R5-F1), the reviewer's probe t01_annotated_callback_false_positives.pts: annotated callback parameters that aren't the receiver's objects (reduce's accumulator) or are only read take them as before:"),
 ('t02_callback_param_forms','generic_instanceof_callback_parameter_forms',"// H10a review round 5 (R5-F2), the reviewer's probe t02_callback_param_forms.pts:"),
 ('t04_callback_references','generic_instanceof_callback_references',"// skip: H10a open (R5-F2): a callback given by reference (a function declaration, a const arrow, an object's method) whose `arr: any[]` parameter a dynamic method call of an instanceof narrowing's member hands the instance's array gets a copy, so the write is lost silently (the base threw a checked TypeError)\n// H10a review round 5 (R5-F2), the reviewer's probe t04_callback_references.pts:")]:
    src=open(f'{P5}/{probe}.pts').read()
    open(f'{RUN}/{name}.pts','w').write(head+'\n'+src.rstrip('\n')+'\n// expect:\n'+node_out(src,name)); print(name)
msg="using the object an `instanceof` narrowing holds as a dynamic value as a value[][] where it may be changed or kept"
for probe,name in [('t03_par_callback_params','generic_instanceof_par_element_writes'),('t07_par_local_element_writes','generic_instanceof_par_local_element_writes')]:
    src=open(f'{P5}/{probe}.pts').read()
    open(f'{ERR}/{name}.pts','w').write(f"// H10a review round 5 (R5-F3: a `.par` view of an instanceof narrowing's member array of arrays would be a deep copy, so writes to its elements would be lost; PTS1001, not a silent copy); the reviewer's probe {probe}.pts.\n// error: {msg}\n"+src); print('errors/'+name)
