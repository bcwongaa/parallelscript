import os, subprocess
RUN='/home/bryan/projects/parallelscript/pts/tests/run'
ERR='/home/bryan/projects/parallelscript/pts/tests/errors'
NODE=os.path.expanduser('~/.local/node/bin/node')
P3='/tmp/h10/review3-unpacked/review3/p'
spec=[
 ('r01_local_cache_across_instances','generic_instanceof_local_across_instances','R3-F1'),
 ('r01b_local_cache_reversed','generic_instanceof_local_across_instances_reversed','R3-F1'),
 ('r03_local_cache_silent','generic_instanceof_local_cache_order','R3-F1'),
 ('r03b_local_cache_control','generic_instanceof_local_cache_order_control','R3-F1'),
 ('r07_dynamic_local_lifetimes','generic_instanceof_dynamic_local_lifetimes','R3-F2'),
 ('r08_generator_dynamic_local','generic_instanceof_dynamic_local_suspensions','round 3'),
 ('r09_par_dynamic_local','generic_instanceof_dynamic_local_par','round 3'),
 ('r10_dynamic_local_builtins','generic_instanceof_dynamic_local_builtins','round 3'),
 ('r12_var_and_module_scope','generic_instanceof_dynamic_local_scopes','round 3'),
]
for probe,name,fid in spec:
    src=open(f'{P3}/{probe}.pts').read()
    tmp=f'/tmp/h10/mine/{name}.mts'; open(tmp,'w').write(src.replace('.par.','.'))
    p=subprocess.run([NODE,'--no-warnings','--experimental-transform-types',tmp],capture_output=True,text=True,timeout=60)
    assert p.returncode==0, (probe, p.stderr[:300])
    lines=src.rstrip('\n').split('\n')
    # keep a `// threads:` directive first, if any
    head=f"// H10a review round 3 ({fid}), the reviewer's probe {probe}.pts:"
    out=''.join('// '+l+'\n' if l else '//\n' for l in p.stdout.rstrip('\n').split('\n'))
    open(f'{RUN}/{name}.pts','w').write(head+'\n'+'\n'.join(lines)+'\n// expect:\n'+out)
    print(name, len(p.stdout.splitlines()))
msg="using the object an `instanceof` narrowing holds as a dynamic value as a value[] where it may be changed or kept"
for probe,name,why in [
 ('r15_sinks_each','generic_instanceof_dynamic_value_sinks','a member or a variable holding one, going into a conditional, `??`, `||`, `as`, a default parameter, `||=`, an any[] parameter, a field, an array literal, an annotated variable: each a copy that writes would miss, so PTS1001, not a silent copy'),
 ('r11_uninferred_sinks','generic_instanceof_uninferred_value_sinks','the same through an uninferred narrowing (a Shape source) and an unknown one'),
 ('r16b_more_sinks','generic_instanceof_dynamic_value_yield_sinks','`yield` of a member and a returned conditional'),
]:
    src=open(f'{P3}/{probe}.pts').read()
    open(f'{ERR}/{name}.pts','w').write(f"// H10a review round 3 (R3-F2: {why}); the reviewer's probe {probe}.pts.\n// error: {msg}\n"+src)
    print('errors/'+name)
