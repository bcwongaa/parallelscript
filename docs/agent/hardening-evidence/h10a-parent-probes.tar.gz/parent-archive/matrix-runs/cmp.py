import json,collections,csv,sys
head={r['id']:r for r in csv.DictReader(open('/tmp/h10/matrix/head.csv'))}
mine={}
for line in open(sys.argv[1]):
    r=json.loads(line); mine[r['id']]=r
print(collections.Counter(r['class'] for r in mine.values()))
trans=collections.Counter((head[i]['class'],mine[i]['class']) for i in mine)
print(sorted(trans.items(), key=lambda x:-x[1]))
print('worse:',[i for i in mine if head[i]['class']=='OK' and mine[i]['class']!='OK'])
print('to WRONG:',[i for i in mine if mine[i]['class']=='WRONG'])
use=collections.defaultdict(collections.Counter)
for i,r in mine.items():
    if r['class']!='OK': use[r['use']][r['class']]+=1
for k,v in sorted(use.items()): print('notOK U',k,dict(v))
fam=collections.defaultdict(collections.Counter)
for i,r in mine.items():
    if r['class']!='OK' and r['use'] not in ('const_copy','return_inferred','array_literal','generic_call','par_map','instanceof_again'): fam[r['family']][(r['use'],r['class'])]+=1
for k,v in sorted(fam.items()): print('in-branch notOK F',k,dict(v))
