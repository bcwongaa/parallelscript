import json, os, re, subprocess
P='/tmp/h10/review1-unpacked/review1/p'
RUN='/home/bryan/projects/parallelscript/pts/tests/run'
NODE=os.path.expanduser('~/.local/node/bin/node')
spec = [
 ('p35_class_method_two_instances','generic_instanceof_class_method_instances','R1-F1'),
 ('p47b_cache_key_any_instance','generic_instanceof_generic_function_any_instance','R1-F1'),
 ('p31_union_object_type_confusion','generic_instanceof_union_object_member','R1-F7'),
 ('p36_union_empty_object','generic_instanceof_union_empty_object','R1-F7'),
 ('p11_tuple_member_crash','generic_instanceof_tuple_member','R1-F4'),
 ('p12b_tuple_member_variants','generic_instanceof_tuple_member_forms','R1-F4'),
 ('p18_private_getter','generic_instanceof_private_getter','R1-F5'),
 ('p19_private_static','generic_instanceof_private_static','R1-F5'),
 ('p03_any_instance_in_base','generic_instanceof_any_instance_base','R1-F2'),
 ('p04_any_instance_private_method','generic_instanceof_any_instance_private_method','R1-F2'),
 ('p05_any_instance_object_source','generic_instanceof_any_instance_object_source','R1-F2'),
 ('p08_unreached_branch','generic_instanceof_unreached_branch','R1-F3'),
 ('p39_unreached_const_copy','generic_instanceof_unreached_const_copy','R1-F3'),
 ('p09_member_use_forms','generic_instanceof_member_uses_a','R1-F3'),
 ('p09b_member_use_forms','generic_instanceof_member_uses_b','R1-F3'),
 ('p09c_member_use_forms','generic_instanceof_member_uses_c','R1-F3'),
 ('p28_argument_forms','generic_instanceof_argument_forms_a','R1-F3'),
 ('p28b_argument_forms','generic_instanceof_argument_forms_b','R1-F3'),
 ('p28c_argument_forms','generic_instanceof_argument_forms_c','R1-F3'),
 ('p27_private_read_uses','generic_instanceof_private_read_uses','R1-F6'),
 ('p26_private_in_callback','generic_instanceof_private_in_callback','R1-F6'),
 ('p33_unsound_inference','generic_instanceof_unique_instances','R1-F8'),
 ('p14_typeparam_object_alone','generic_instanceof_type_parameter_object','R1-F9'),
 ('p43_reference_gaps','generic_instanceof_reference_kinds','R1-F10'),
 ('p25_par_private','generic_instanceof_private_par','R1-F6'),
 ('p24_unknown_member_par','generic_instanceof_dynamic_member_par','R1-F4'),
]
twins={'p25_par_private':'p25b_seq_private','p24_unknown_member_par':'p24_twin'}
for probe,name,fid in spec:
    src=open(f'{P}/{probe}.pts').read()
    nodesrc=open(f'{P}/{twins.get(probe,probe)}.pts').read()
    tmp=f'/tmp/h10/mine/{name}.mts'; open(tmp,'w').write(nodesrc.replace('.par.','.'))
    p=subprocess.run([NODE,'--no-warnings','--experimental-transform-types',tmp],capture_output=True,text=True,timeout=60)
    assert p.returncode==0, (probe, p.stderr[:300])
    lines=src.rstrip('\n').split('\n')
    head=f'// H10a review round 1 ({fid}), the reviewer\'s probe {probe}.pts:'
    body='\n'.join(lines)
    out=''.join('// '+l+'\n' if l else '//\n' for l in p.stdout.rstrip('\n').split('\n'))
    open(f'{RUN}/{name}.pts','w').write(head+'\n'+body+'\n// expect:\n'+out)
    print(name, len(p.stdout.splitlines()))
