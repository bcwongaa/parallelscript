#!/bin/bash
# csize.sh OUT CLI HOME: lines and exit code of `pts emit-c` for every single-file test program, "path lines exit" per line.
out=$(realpath -m "$1"); cli=$2; home=$3
cd /home/bryan/projects/parallelscript
find pts/tests -name '*.pts' -not -path '*/node_modules/*' | sort | xargs -P 2 -I{} bash -c 'n=$(PTS_HOME='"$home"' timeout 120 '"$cli"' emit-c "{}" 2>/dev/null | wc -l); echo "{} $n ${PIPESTATUS[0]}"' > "$out"
