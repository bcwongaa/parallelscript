"""Check tests against their `// expect:` blocks with a compiler and with Node.

Run: python3 -I check.py [--pts PATH] TEST.pts...
Prints, per test: Node PASS/FAIL, pts PASS/RED (build error or first differing lines).
"""

import argparse
import difflib
import os
import shutil
import subprocess
import tempfile

WT = os.environ["PTS_WT"]
NODE = os.path.expanduser("~/.local/node/bin/node")
ENV = dict(os.environ, PTS_HOME=WT, PTS_CACHE_DIR="/tmp/h09b4/cache", TZ="America/New_York", GOMAXPROCS="2")


def expected(path):
    lines = open(path).read().rstrip("\n").split("\n")
    i = lines.index("// expect:")
    out = []
    for l in lines[i + 1:]:
        if not l.startswith("//"):
            break
        out.append(l[3:] if l.startswith("// ") else l[2:])
    return "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pts", default=os.path.join(WT, "pts-bin/pts"))
    ap.add_argument("tests", nargs="+")
    a = ap.parse_args()
    for path in a.tests:
        want = expected(path)
        base = os.path.splitext(os.path.basename(path))[0]
        with tempfile.TemporaryDirectory(dir="/tmp/h09b4/repro") as d:
            shutil.copy(path, os.path.join(d, base + ".mts"))
            shutil.copy(path, os.path.join(d, base + ".pts"))
            n = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", base + ".mts"], cwd=d, capture_output=True, env=ENV, timeout=60)
            node_ok = n.returncode == 0 and n.stdout.decode() == want
            b = subprocess.run([a.pts, "build", base + ".pts", "-o", base + ".bin"], cwd=d, capture_output=True, env=ENV, timeout=300)
            if b.returncode != 0:
                msg = (b.stdout + b.stderr).decode().replace(d + "/", "").strip().splitlines()
                print("%-48s node %s | pts RED: build exit %d" % (base, "PASS" if node_ok else "FAIL", b.returncode))
                for m in msg[:8]:
                    print("      " + m[:220])
                continue
            r = subprocess.run(["./" + base + ".bin"], cwd=d, capture_output=True, env=ENV, timeout=60)
            got = r.stdout.decode()
            if got == want and r.returncode == 0:
                print("%-48s node %s | pts PASS" % (base, "PASS" if node_ok else "FAIL"))
                continue
            print("%-48s node %s | pts RED: exit %d" % (base, "PASS" if node_ok else "FAIL", r.returncode))
            diff = [l for l in difflib.unified_diff(want.splitlines(), got.splitlines(), "node", "pts", lineterm="", n=0) if not l.startswith("@@")]
            for l in diff[2:14]:
                print("      " + l[:220])
            if r.stderr:
                print("      stderr: " + r.stderr.decode().strip().splitlines()[0][:220])


if __name__ == "__main__":
    main()
