#!/bin/bash
# rerun3.sh OUTDIR PROBE...: each probe with Node (an .mts copy), the base CLI and CUR (env CUR, CUR_HOME); prints NODE-vs-CUR OK/DIFF and BASE-vs-CUR SAME/CHANGED.
out=$1; shift; mkdir -p "$out"
for p in "$@"; do
  n=$(basename "$p" .pts); d="$out/$n"; mkdir -p "$d"; cp "$p" "$d/$n.mts"
  (cd "$d" && timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" > node.txt 2>&1; echo "exit $?" >> node.txt)
  PTS_HOME=/tmp/h09b4/base timeout 120 /tmp/h09b4/base/pts-bin/pts run "$p" > "$d/base.txt" 2>&1; echo "exit $?" >> "$d/base.txt"
  PTS_HOME=$CUR_HOME timeout 120 $CUR run "$p" > "$d/cur.txt" 2>&1; echo "exit $?" >> "$d/cur.txt"
  sed -i "s#$(dirname "$p")/##g" "$d/base.txt" "$d/cur.txt"
  a=OK; cmp -s "$d/node.txt" "$d/cur.txt" || a=DIFF
  b=SAME; cmp -s "$d/base.txt" "$d/cur.txt" || b=CHANGED
  echo "$a $b $p"
done
