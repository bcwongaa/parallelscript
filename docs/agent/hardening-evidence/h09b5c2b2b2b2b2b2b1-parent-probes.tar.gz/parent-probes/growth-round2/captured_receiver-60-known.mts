class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.value.tag); }
function read0(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.value.tag); }
function read1(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(factory: Factory): void { const box: Box<C2> = factory(new C2()); console.log(box.value.tag); }
function read2(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(factory: Factory): void { const box: Box<C3> = factory(new C3()); console.log(box.value.tag); }
function read3(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(factory: Factory): void { const box: Box<C4> = factory(new C4()); console.log(box.value.tag); }
function read4(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(factory: Factory): void { const box: Box<C5> = factory(new C5()); console.log(box.value.tag); }
function read5(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(factory: Factory): void { const box: Box<C6> = factory(new C6()); console.log(box.value.tag); }
function read6(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(factory: Factory): void { const box: Box<C7> = factory(new C7()); console.log(box.value.tag); }
function read7(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(factory: Factory): void { const box: Box<C8> = factory(new C8()); console.log(box.value.tag); }
function read8(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(factory: Factory): void { const box: Box<C9> = factory(new C9()); console.log(box.value.tag); }
function read9(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(factory: Factory): void { const box: Box<C10> = factory(new C10()); console.log(box.value.tag); }
function read10(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(factory: Factory): void { const box: Box<C11> = factory(new C11()); console.log(box.value.tag); }
function read11(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(factory: Factory): void { const box: Box<C12> = factory(new C12()); console.log(box.value.tag); }
function read12(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(factory: Factory): void { const box: Box<C13> = factory(new C13()); console.log(box.value.tag); }
function read13(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(factory: Factory): void { const box: Box<C14> = factory(new C14()); console.log(box.value.tag); }
function read14(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(factory: Factory): void { const box: Box<C15> = factory(new C15()); console.log(box.value.tag); }
function read15(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(factory: Factory): void { const box: Box<C16> = factory(new C16()); console.log(box.value.tag); }
function read16(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(factory: Factory): void { const box: Box<C17> = factory(new C17()); console.log(box.value.tag); }
function read17(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(factory: Factory): void { const box: Box<C18> = factory(new C18()); console.log(box.value.tag); }
function read18(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(factory: Factory): void { const box: Box<C19> = factory(new C19()); console.log(box.value.tag); }
function read19(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(factory: Factory): void { const box: Box<C20> = factory(new C20()); console.log(box.value.tag); }
function read20(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(factory: Factory): void { const box: Box<C21> = factory(new C21()); console.log(box.value.tag); }
function read21(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(factory: Factory): void { const box: Box<C22> = factory(new C22()); console.log(box.value.tag); }
function read22(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(factory: Factory): void { const box: Box<C23> = factory(new C23()); console.log(box.value.tag); }
function read23(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(factory: Factory): void { const box: Box<C24> = factory(new C24()); console.log(box.value.tag); }
function read24(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(factory: Factory): void { const box: Box<C25> = factory(new C25()); console.log(box.value.tag); }
function read25(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(factory: Factory): void { const box: Box<C26> = factory(new C26()); console.log(box.value.tag); }
function read26(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(factory: Factory): void { const box: Box<C27> = factory(new C27()); console.log(box.value.tag); }
function read27(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(factory: Factory): void { const box: Box<C28> = factory(new C28()); console.log(box.value.tag); }
function read28(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(factory: Factory): void { const box: Box<C29> = factory(new C29()); console.log(box.value.tag); }
function read29(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(factory: Factory): void { const box: Box<C30> = factory(new C30()); console.log(box.value.tag); }
function read30(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(factory: Factory): void { const box: Box<C31> = factory(new C31()); console.log(box.value.tag); }
function read31(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(factory: Factory): void { const box: Box<C32> = factory(new C32()); console.log(box.value.tag); }
function read32(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(factory: Factory): void { const box: Box<C33> = factory(new C33()); console.log(box.value.tag); }
function read33(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(factory: Factory): void { const box: Box<C34> = factory(new C34()); console.log(box.value.tag); }
function read34(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(factory: Factory): void { const box: Box<C35> = factory(new C35()); console.log(box.value.tag); }
function read35(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(factory: Factory): void { const box: Box<C36> = factory(new C36()); console.log(box.value.tag); }
function read36(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(factory: Factory): void { const box: Box<C37> = factory(new C37()); console.log(box.value.tag); }
function read37(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(factory: Factory): void { const box: Box<C38> = factory(new C38()); console.log(box.value.tag); }
function read38(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(factory: Factory): void { const box: Box<C39> = factory(new C39()); console.log(box.value.tag); }
function read39(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(factory: Factory): void { const box: Box<C40> = factory(new C40()); console.log(box.value.tag); }
function read40(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(factory: Factory): void { const box: Box<C41> = factory(new C41()); console.log(box.value.tag); }
function read41(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(factory: Factory): void { const box: Box<C42> = factory(new C42()); console.log(box.value.tag); }
function read42(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(factory: Factory): void { const box: Box<C43> = factory(new C43()); console.log(box.value.tag); }
function read43(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(factory: Factory): void { const box: Box<C44> = factory(new C44()); console.log(box.value.tag); }
function read44(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(factory: Factory): void { const box: Box<C45> = factory(new C45()); console.log(box.value.tag); }
function read45(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(factory: Factory): void { const box: Box<C46> = factory(new C46()); console.log(box.value.tag); }
function read46(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(factory: Factory): void { const box: Box<C47> = factory(new C47()); console.log(box.value.tag); }
function read47(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(factory: Factory): void { const box: Box<C48> = factory(new C48()); console.log(box.value.tag); }
function read48(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(factory: Factory): void { const box: Box<C49> = factory(new C49()); console.log(box.value.tag); }
function read49(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(factory: Factory): void { const box: Box<C50> = factory(new C50()); console.log(box.value.tag); }
function read50(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(factory: Factory): void { const box: Box<C51> = factory(new C51()); console.log(box.value.tag); }
function read51(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(factory: Factory): void { const box: Box<C52> = factory(new C52()); console.log(box.value.tag); }
function read52(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(factory: Factory): void { const box: Box<C53> = factory(new C53()); console.log(box.value.tag); }
function read53(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(factory: Factory): void { const box: Box<C54> = factory(new C54()); console.log(box.value.tag); }
function read54(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(factory: Factory): void { const box: Box<C55> = factory(new C55()); console.log(box.value.tag); }
function read55(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(factory: Factory): void { const box: Box<C56> = factory(new C56()); console.log(box.value.tag); }
function read56(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(factory: Factory): void { const box: Box<C57> = factory(new C57()); console.log(box.value.tag); }
function read57(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(factory: Factory): void { const box: Box<C58> = factory(new C58()); console.log(box.value.tag); }
function read58(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(factory: Factory): void { const box: Box<C59> = factory(new C59()); console.log(box.value.tag); }
function read59(receiver: Maker): Factory { return receiver.make.bind(receiver); }
const selected0: Maker = new M0();
const root0 = [{ value: selected0 }];
const [child0] = root0;
use0(read0(child0.value));
const selected1: Maker = new M1();
const root1 = [{ value: selected1 }];
const [child1] = root1;
use1(read1(child1.value));
const selected2: Maker = new M2();
const root2 = [{ value: selected2 }];
const [child2] = root2;
use2(read2(child2.value));
const selected3: Maker = new M3();
const root3 = [{ value: selected3 }];
const [child3] = root3;
use3(read3(child3.value));
const selected4: Maker = new M4();
const root4 = [{ value: selected4 }];
const [child4] = root4;
use4(read4(child4.value));
const selected5: Maker = new M5();
const root5 = [{ value: selected5 }];
const [child5] = root5;
use5(read5(child5.value));
const selected6: Maker = new M6();
const root6 = [{ value: selected6 }];
const [child6] = root6;
use6(read6(child6.value));
const selected7: Maker = new M7();
const root7 = [{ value: selected7 }];
const [child7] = root7;
use7(read7(child7.value));
const selected8: Maker = new M8();
const root8 = [{ value: selected8 }];
const [child8] = root8;
use8(read8(child8.value));
const selected9: Maker = new M9();
const root9 = [{ value: selected9 }];
const [child9] = root9;
use9(read9(child9.value));
const selected10: Maker = new M10();
const root10 = [{ value: selected10 }];
const [child10] = root10;
use10(read10(child10.value));
const selected11: Maker = new M11();
const root11 = [{ value: selected11 }];
const [child11] = root11;
use11(read11(child11.value));
const selected12: Maker = new M12();
const root12 = [{ value: selected12 }];
const [child12] = root12;
use12(read12(child12.value));
const selected13: Maker = new M13();
const root13 = [{ value: selected13 }];
const [child13] = root13;
use13(read13(child13.value));
const selected14: Maker = new M14();
const root14 = [{ value: selected14 }];
const [child14] = root14;
use14(read14(child14.value));
const selected15: Maker = new M15();
const root15 = [{ value: selected15 }];
const [child15] = root15;
use15(read15(child15.value));
const selected16: Maker = new M16();
const root16 = [{ value: selected16 }];
const [child16] = root16;
use16(read16(child16.value));
const selected17: Maker = new M17();
const root17 = [{ value: selected17 }];
const [child17] = root17;
use17(read17(child17.value));
const selected18: Maker = new M18();
const root18 = [{ value: selected18 }];
const [child18] = root18;
use18(read18(child18.value));
const selected19: Maker = new M19();
const root19 = [{ value: selected19 }];
const [child19] = root19;
use19(read19(child19.value));
const selected20: Maker = new M20();
const root20 = [{ value: selected20 }];
const [child20] = root20;
use20(read20(child20.value));
const selected21: Maker = new M21();
const root21 = [{ value: selected21 }];
const [child21] = root21;
use21(read21(child21.value));
const selected22: Maker = new M22();
const root22 = [{ value: selected22 }];
const [child22] = root22;
use22(read22(child22.value));
const selected23: Maker = new M23();
const root23 = [{ value: selected23 }];
const [child23] = root23;
use23(read23(child23.value));
const selected24: Maker = new M24();
const root24 = [{ value: selected24 }];
const [child24] = root24;
use24(read24(child24.value));
const selected25: Maker = new M25();
const root25 = [{ value: selected25 }];
const [child25] = root25;
use25(read25(child25.value));
const selected26: Maker = new M26();
const root26 = [{ value: selected26 }];
const [child26] = root26;
use26(read26(child26.value));
const selected27: Maker = new M27();
const root27 = [{ value: selected27 }];
const [child27] = root27;
use27(read27(child27.value));
const selected28: Maker = new M28();
const root28 = [{ value: selected28 }];
const [child28] = root28;
use28(read28(child28.value));
const selected29: Maker = new M29();
const root29 = [{ value: selected29 }];
const [child29] = root29;
use29(read29(child29.value));
const selected30: Maker = new M30();
const root30 = [{ value: selected30 }];
const [child30] = root30;
use30(read30(child30.value));
const selected31: Maker = new M31();
const root31 = [{ value: selected31 }];
const [child31] = root31;
use31(read31(child31.value));
const selected32: Maker = new M32();
const root32 = [{ value: selected32 }];
const [child32] = root32;
use32(read32(child32.value));
const selected33: Maker = new M33();
const root33 = [{ value: selected33 }];
const [child33] = root33;
use33(read33(child33.value));
const selected34: Maker = new M34();
const root34 = [{ value: selected34 }];
const [child34] = root34;
use34(read34(child34.value));
const selected35: Maker = new M35();
const root35 = [{ value: selected35 }];
const [child35] = root35;
use35(read35(child35.value));
const selected36: Maker = new M36();
const root36 = [{ value: selected36 }];
const [child36] = root36;
use36(read36(child36.value));
const selected37: Maker = new M37();
const root37 = [{ value: selected37 }];
const [child37] = root37;
use37(read37(child37.value));
const selected38: Maker = new M38();
const root38 = [{ value: selected38 }];
const [child38] = root38;
use38(read38(child38.value));
const selected39: Maker = new M39();
const root39 = [{ value: selected39 }];
const [child39] = root39;
use39(read39(child39.value));
const selected40: Maker = new M40();
const root40 = [{ value: selected40 }];
const [child40] = root40;
use40(read40(child40.value));
const selected41: Maker = new M41();
const root41 = [{ value: selected41 }];
const [child41] = root41;
use41(read41(child41.value));
const selected42: Maker = new M42();
const root42 = [{ value: selected42 }];
const [child42] = root42;
use42(read42(child42.value));
const selected43: Maker = new M43();
const root43 = [{ value: selected43 }];
const [child43] = root43;
use43(read43(child43.value));
const selected44: Maker = new M44();
const root44 = [{ value: selected44 }];
const [child44] = root44;
use44(read44(child44.value));
const selected45: Maker = new M45();
const root45 = [{ value: selected45 }];
const [child45] = root45;
use45(read45(child45.value));
const selected46: Maker = new M46();
const root46 = [{ value: selected46 }];
const [child46] = root46;
use46(read46(child46.value));
const selected47: Maker = new M47();
const root47 = [{ value: selected47 }];
const [child47] = root47;
use47(read47(child47.value));
const selected48: Maker = new M48();
const root48 = [{ value: selected48 }];
const [child48] = root48;
use48(read48(child48.value));
const selected49: Maker = new M49();
const root49 = [{ value: selected49 }];
const [child49] = root49;
use49(read49(child49.value));
const selected50: Maker = new M50();
const root50 = [{ value: selected50 }];
const [child50] = root50;
use50(read50(child50.value));
const selected51: Maker = new M51();
const root51 = [{ value: selected51 }];
const [child51] = root51;
use51(read51(child51.value));
const selected52: Maker = new M52();
const root52 = [{ value: selected52 }];
const [child52] = root52;
use52(read52(child52.value));
const selected53: Maker = new M53();
const root53 = [{ value: selected53 }];
const [child53] = root53;
use53(read53(child53.value));
const selected54: Maker = new M54();
const root54 = [{ value: selected54 }];
const [child54] = root54;
use54(read54(child54.value));
const selected55: Maker = new M55();
const root55 = [{ value: selected55 }];
const [child55] = root55;
use55(read55(child55.value));
const selected56: Maker = new M56();
const root56 = [{ value: selected56 }];
const [child56] = root56;
use56(read56(child56.value));
const selected57: Maker = new M57();
const root57 = [{ value: selected57 }];
const [child57] = root57;
use57(read57(child57.value));
const selected58: Maker = new M58();
const root58 = [{ value: selected58 }];
const [child58] = root58;
use58(read58(child58.value));
const selected59: Maker = new M59();
const root59 = [{ value: selected59 }];
const [child59] = root59;
use59(read59(child59.value));
