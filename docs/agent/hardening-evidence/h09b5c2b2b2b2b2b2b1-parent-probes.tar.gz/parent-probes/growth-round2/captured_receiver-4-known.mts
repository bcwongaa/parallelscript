class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.value.tag); }
function read0(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.value.tag); }
function read1(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(factory: Factory): void { const box: Box<C2> = factory(new C2()); console.log(box.value.tag); }
function read2(receiver: Maker): Factory { return receiver.make.bind(receiver); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(factory: Factory): void { const box: Box<C3> = factory(new C3()); console.log(box.value.tag); }
function read3(receiver: Maker): Factory { return receiver.make.bind(receiver); }
const selected0: Maker = new M0();
const root0 = [{ value: selected0 }];
const [child0] = root0;
use0(read0(child0.value));
const selected1: Maker = new M1();
const root1 = [{ value: selected1 }];
const [child1] = root1;
use1(read1(child1.value));
const selected2: Maker = new M2();
const root2 = [{ value: selected2 }];
const [child2] = root2;
use2(read2(child2.value));
const selected3: Maker = new M3();
const root3 = [{ value: selected3 }];
const [child3] = root3;
use3(read3(child3.value));
