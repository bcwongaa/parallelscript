class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(factory: Factory): void { const box: Box<C2> = factory(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(factory: Factory): void { const box: Box<C3> = factory(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(factory: Factory): void { const box: Box<C4> = factory(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(factory: Factory): void { const box: Box<C5> = factory(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(factory: Factory): void { const box: Box<C6> = factory(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(factory: Factory): void { const box: Box<C7> = factory(new C7()); console.log(box.value.tag); }
const selected0: Factory = source0;
const root0 = [{ value: selected0 }];
const [child0] = root0;
consumeContainer(child0);
use0(child0.value);
const selected1: Factory = source1;
const root1 = [{ value: selected1 }];
const [child1] = root1;
consumeContainer(child1);
use1(child1.value);
const selected2: Factory = source2;
const root2 = [{ value: selected2 }];
const [child2] = root2;
consumeContainer(child2);
use2(child2.value);
const selected3: Factory = source3;
const root3 = [{ value: selected3 }];
const [child3] = root3;
consumeContainer(child3);
use3(child3.value);
const selected4: Factory = source4;
const root4 = [{ value: selected4 }];
const [child4] = root4;
consumeContainer(child4);
use4(child4.value);
const selected5: Factory = source5;
const root5 = [{ value: selected5 }];
const [child5] = root5;
consumeContainer(child5);
use5(child5.value);
const selected6: Factory = source6;
const root6 = [{ value: selected6 }];
const [child6] = root6;
consumeContainer(child6);
use6(child6.value);
const selected7: Factory = source7;
const root7 = [{ value: selected7 }];
const [child7] = root7;
consumeContainer(child7);
use7(child7.value);
