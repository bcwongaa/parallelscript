class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(receiver: Maker): void { const box: Box<C2> = receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(receiver: Maker): void { const box: Box<C3> = receiver.make(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(receiver: Maker): void { const box: Box<C4> = receiver.make(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(receiver: Maker): void { const box: Box<C5> = receiver.make(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(receiver: Maker): void { const box: Box<C6> = receiver.make(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(receiver: Maker): void { const box: Box<C7> = receiver.make(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(receiver: Maker): void { const box: Box<C8> = receiver.make(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(receiver: Maker): void { const box: Box<C9> = receiver.make(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(receiver: Maker): void { const box: Box<C10> = receiver.make(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(receiver: Maker): void { const box: Box<C11> = receiver.make(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(receiver: Maker): void { const box: Box<C12> = receiver.make(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(receiver: Maker): void { const box: Box<C13> = receiver.make(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(receiver: Maker): void { const box: Box<C14> = receiver.make(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(receiver: Maker): void { const box: Box<C15> = receiver.make(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(receiver: Maker): void { const box: Box<C16> = receiver.make(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(receiver: Maker): void { const box: Box<C17> = receiver.make(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(receiver: Maker): void { const box: Box<C18> = receiver.make(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(receiver: Maker): void { const box: Box<C19> = receiver.make(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(receiver: Maker): void { const box: Box<C20> = receiver.make(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(receiver: Maker): void { const box: Box<C21> = receiver.make(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(receiver: Maker): void { const box: Box<C22> = receiver.make(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(receiver: Maker): void { const box: Box<C23> = receiver.make(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(receiver: Maker): void { const box: Box<C24> = receiver.make(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(receiver: Maker): void { const box: Box<C25> = receiver.make(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(receiver: Maker): void { const box: Box<C26> = receiver.make(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(receiver: Maker): void { const box: Box<C27> = receiver.make(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(receiver: Maker): void { const box: Box<C28> = receiver.make(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(receiver: Maker): void { const box: Box<C29> = receiver.make(new C29()); console.log(box.value.tag); }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(receiver: Maker): void { const box: Box<C30> = receiver.make(new C30()); console.log(box.value.tag); }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(receiver: Maker): void { const box: Box<C31> = receiver.make(new C31()); console.log(box.value.tag); }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(receiver: Maker): void { const box: Box<C32> = receiver.make(new C32()); console.log(box.value.tag); }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(receiver: Maker): void { const box: Box<C33> = receiver.make(new C33()); console.log(box.value.tag); }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(receiver: Maker): void { const box: Box<C34> = receiver.make(new C34()); console.log(box.value.tag); }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(receiver: Maker): void { const box: Box<C35> = receiver.make(new C35()); console.log(box.value.tag); }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(receiver: Maker): void { const box: Box<C36> = receiver.make(new C36()); console.log(box.value.tag); }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(receiver: Maker): void { const box: Box<C37> = receiver.make(new C37()); console.log(box.value.tag); }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(receiver: Maker): void { const box: Box<C38> = receiver.make(new C38()); console.log(box.value.tag); }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(receiver: Maker): void { const box: Box<C39> = receiver.make(new C39()); console.log(box.value.tag); }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(receiver: Maker): void { const box: Box<C40> = receiver.make(new C40()); console.log(box.value.tag); }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(receiver: Maker): void { const box: Box<C41> = receiver.make(new C41()); console.log(box.value.tag); }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(receiver: Maker): void { const box: Box<C42> = receiver.make(new C42()); console.log(box.value.tag); }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(receiver: Maker): void { const box: Box<C43> = receiver.make(new C43()); console.log(box.value.tag); }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(receiver: Maker): void { const box: Box<C44> = receiver.make(new C44()); console.log(box.value.tag); }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(receiver: Maker): void { const box: Box<C45> = receiver.make(new C45()); console.log(box.value.tag); }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(receiver: Maker): void { const box: Box<C46> = receiver.make(new C46()); console.log(box.value.tag); }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(receiver: Maker): void { const box: Box<C47> = receiver.make(new C47()); console.log(box.value.tag); }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(receiver: Maker): void { const box: Box<C48> = receiver.make(new C48()); console.log(box.value.tag); }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(receiver: Maker): void { const box: Box<C49> = receiver.make(new C49()); console.log(box.value.tag); }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(receiver: Maker): void { const box: Box<C50> = receiver.make(new C50()); console.log(box.value.tag); }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(receiver: Maker): void { const box: Box<C51> = receiver.make(new C51()); console.log(box.value.tag); }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(receiver: Maker): void { const box: Box<C52> = receiver.make(new C52()); console.log(box.value.tag); }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(receiver: Maker): void { const box: Box<C53> = receiver.make(new C53()); console.log(box.value.tag); }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(receiver: Maker): void { const box: Box<C54> = receiver.make(new C54()); console.log(box.value.tag); }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(receiver: Maker): void { const box: Box<C55> = receiver.make(new C55()); console.log(box.value.tag); }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(receiver: Maker): void { const box: Box<C56> = receiver.make(new C56()); console.log(box.value.tag); }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(receiver: Maker): void { const box: Box<C57> = receiver.make(new C57()); console.log(box.value.tag); }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(receiver: Maker): void { const box: Box<C58> = receiver.make(new C58()); console.log(box.value.tag); }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(receiver: Maker): void { const box: Box<C59> = receiver.make(new C59()); console.log(box.value.tag); }
const selected0: Maker = new M0();
const root0 = [{ value: selected0 }];
const [child0] = root0;
use0(child0.value);
const selected1: Maker = new M1();
const root1 = [{ value: selected1 }];
const [child1] = root1;
use1(child1.value);
const selected2: Maker = new M2();
const root2 = [{ value: selected2 }];
const [child2] = root2;
use2(child2.value);
const selected3: Maker = new M3();
const root3 = [{ value: selected3 }];
const [child3] = root3;
use3(child3.value);
const selected4: Maker = new M4();
const root4 = [{ value: selected4 }];
const [child4] = root4;
use4(child4.value);
const selected5: Maker = new M5();
const root5 = [{ value: selected5 }];
const [child5] = root5;
use5(child5.value);
const selected6: Maker = new M6();
const root6 = [{ value: selected6 }];
const [child6] = root6;
use6(child6.value);
const selected7: Maker = new M7();
const root7 = [{ value: selected7 }];
const [child7] = root7;
use7(child7.value);
const selected8: Maker = new M8();
const root8 = [{ value: selected8 }];
const [child8] = root8;
use8(child8.value);
const selected9: Maker = new M9();
const root9 = [{ value: selected9 }];
const [child9] = root9;
use9(child9.value);
const selected10: Maker = new M10();
const root10 = [{ value: selected10 }];
const [child10] = root10;
use10(child10.value);
const selected11: Maker = new M11();
const root11 = [{ value: selected11 }];
const [child11] = root11;
use11(child11.value);
const selected12: Maker = new M12();
const root12 = [{ value: selected12 }];
const [child12] = root12;
use12(child12.value);
const selected13: Maker = new M13();
const root13 = [{ value: selected13 }];
const [child13] = root13;
use13(child13.value);
const selected14: Maker = new M14();
const root14 = [{ value: selected14 }];
const [child14] = root14;
use14(child14.value);
const selected15: Maker = new M15();
const root15 = [{ value: selected15 }];
const [child15] = root15;
use15(child15.value);
const selected16: Maker = new M16();
const root16 = [{ value: selected16 }];
const [child16] = root16;
use16(child16.value);
const selected17: Maker = new M17();
const root17 = [{ value: selected17 }];
const [child17] = root17;
use17(child17.value);
const selected18: Maker = new M18();
const root18 = [{ value: selected18 }];
const [child18] = root18;
use18(child18.value);
const selected19: Maker = new M19();
const root19 = [{ value: selected19 }];
const [child19] = root19;
use19(child19.value);
const selected20: Maker = new M20();
const root20 = [{ value: selected20 }];
const [child20] = root20;
use20(child20.value);
const selected21: Maker = new M21();
const root21 = [{ value: selected21 }];
const [child21] = root21;
use21(child21.value);
const selected22: Maker = new M22();
const root22 = [{ value: selected22 }];
const [child22] = root22;
use22(child22.value);
const selected23: Maker = new M23();
const root23 = [{ value: selected23 }];
const [child23] = root23;
use23(child23.value);
const selected24: Maker = new M24();
const root24 = [{ value: selected24 }];
const [child24] = root24;
use24(child24.value);
const selected25: Maker = new M25();
const root25 = [{ value: selected25 }];
const [child25] = root25;
use25(child25.value);
const selected26: Maker = new M26();
const root26 = [{ value: selected26 }];
const [child26] = root26;
use26(child26.value);
const selected27: Maker = new M27();
const root27 = [{ value: selected27 }];
const [child27] = root27;
use27(child27.value);
const selected28: Maker = new M28();
const root28 = [{ value: selected28 }];
const [child28] = root28;
use28(child28.value);
const selected29: Maker = new M29();
const root29 = [{ value: selected29 }];
const [child29] = root29;
use29(child29.value);
const selected30: Maker = new M30();
const root30 = [{ value: selected30 }];
const [child30] = root30;
use30(child30.value);
const selected31: Maker = new M31();
const root31 = [{ value: selected31 }];
const [child31] = root31;
use31(child31.value);
const selected32: Maker = new M32();
const root32 = [{ value: selected32 }];
const [child32] = root32;
use32(child32.value);
const selected33: Maker = new M33();
const root33 = [{ value: selected33 }];
const [child33] = root33;
use33(child33.value);
const selected34: Maker = new M34();
const root34 = [{ value: selected34 }];
const [child34] = root34;
use34(child34.value);
const selected35: Maker = new M35();
const root35 = [{ value: selected35 }];
const [child35] = root35;
use35(child35.value);
const selected36: Maker = new M36();
const root36 = [{ value: selected36 }];
const [child36] = root36;
use36(child36.value);
const selected37: Maker = new M37();
const root37 = [{ value: selected37 }];
const [child37] = root37;
use37(child37.value);
const selected38: Maker = new M38();
const root38 = [{ value: selected38 }];
const [child38] = root38;
use38(child38.value);
const selected39: Maker = new M39();
const root39 = [{ value: selected39 }];
const [child39] = root39;
use39(child39.value);
const selected40: Maker = new M40();
const root40 = [{ value: selected40 }];
const [child40] = root40;
use40(child40.value);
const selected41: Maker = new M41();
const root41 = [{ value: selected41 }];
const [child41] = root41;
use41(child41.value);
const selected42: Maker = new M42();
const root42 = [{ value: selected42 }];
const [child42] = root42;
use42(child42.value);
const selected43: Maker = new M43();
const root43 = [{ value: selected43 }];
const [child43] = root43;
use43(child43.value);
const selected44: Maker = new M44();
const root44 = [{ value: selected44 }];
const [child44] = root44;
use44(child44.value);
const selected45: Maker = new M45();
const root45 = [{ value: selected45 }];
const [child45] = root45;
use45(child45.value);
const selected46: Maker = new M46();
const root46 = [{ value: selected46 }];
const [child46] = root46;
use46(child46.value);
const selected47: Maker = new M47();
const root47 = [{ value: selected47 }];
const [child47] = root47;
use47(child47.value);
const selected48: Maker = new M48();
const root48 = [{ value: selected48 }];
const [child48] = root48;
use48(child48.value);
const selected49: Maker = new M49();
const root49 = [{ value: selected49 }];
const [child49] = root49;
use49(child49.value);
const selected50: Maker = new M50();
const root50 = [{ value: selected50 }];
const [child50] = root50;
use50(child50.value);
const selected51: Maker = new M51();
const root51 = [{ value: selected51 }];
const [child51] = root51;
use51(child51.value);
const selected52: Maker = new M52();
const root52 = [{ value: selected52 }];
const [child52] = root52;
use52(child52.value);
const selected53: Maker = new M53();
const root53 = [{ value: selected53 }];
const [child53] = root53;
use53(child53.value);
const selected54: Maker = new M54();
const root54 = [{ value: selected54 }];
const [child54] = root54;
use54(child54.value);
const selected55: Maker = new M55();
const root55 = [{ value: selected55 }];
const [child55] = root55;
use55(child55.value);
const selected56: Maker = new M56();
const root56 = [{ value: selected56 }];
const [child56] = root56;
use56(child56.value);
const selected57: Maker = new M57();
const root57 = [{ value: selected57 }];
const [child57] = root57;
use57(child57.value);
const selected58: Maker = new M58();
const root58 = [{ value: selected58 }];
const [child58] = root58;
use58(child58.value);
const selected59: Maker = new M59();
const root59 = [{ value: selected59 }];
const [child59] = root59;
use59(child59.value);
