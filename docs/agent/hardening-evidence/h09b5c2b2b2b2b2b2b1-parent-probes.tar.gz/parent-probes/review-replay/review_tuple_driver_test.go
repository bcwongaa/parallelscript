package driver_test

import (
 "fmt"
 "strings"
 "testing"

 "github.com/microsoft/typescript-go/pts/driver"
 "github.com/microsoft/typescript-go/pts/lower"
 "gotest.tools/v3/assert"
)

func TestReviewD214FreshTupleRetainsEveryPair(t *testing.T) {
 for _, kind:=range []string{"function","receiver","captured_receiver","wrapper"} {
  t.Run(kind,func(t *testing.T){
   var s strings.Builder
   s.WriteString(inlineContainerFlowInventory(kind,3))
   s.WriteString("const keep: any[] = [source0, source1, source2];\n")
   for i:=range 3 {
    value,typ:=fmt.Sprintf("source%d",i),"Factory"
    switch kind {
     case "receiver","captured_receiver":value=fmt.Sprintf("new M%d()",i);typ="Maker"
     case "wrapper":value=fmt.Sprintf("read%d()",i)
    }
    fmt.Fprintf(&s,"const first%d: %s = %s; const [child%d] = [{ value: first%d }];\n",i,typ,value,i,i)
    terminal:=fmt.Sprintf("child%d.value",i)
    if kind=="captured_receiver" {terminal=fmt.Sprintf("read%d(%s)",i,terminal)}
    fmt.Fprintf(&s,"use%d(%s);\n",i,terminal)
   }
   entry:=writeSource(t,s.String())
   c,err:=driver.EmitCWith(t.Context(),entry,lower.AllInstances)
   assert.NilError(t,err)
   pairs:=inlineContainerAssertPairs(t,c,kind,3,func(v,d int)bool{return true})
   assert.Equal(t,pairs,9)
   t.Logf("direct fresh raw tuple: kind=%s all %d compatible pairs retained",kind,pairs)
  })
 }
}
