package lower

import (
 "fmt"
 "slices"
 "testing"

 "github.com/microsoft/typescript-go/internal/ast"
 "github.com/microsoft/typescript-go/internal/checker"
 "gotest.tools/v3/assert"
)

func TestReviewD214WholePatternAndAllUses(t *testing.T) {
 const base = `const root = { rows: [{ box: { value: first }, more: [{ value: first }] }, { box: { value: first }, more: [{ value: first }] }], spare: { value: first } };
const [{ box: child, more: [other] }, { box: sibling, more: [another] }] = root.rows;
const alias = child;
const check_root = root.rows[0].box.value; const check_child = child.value; const check_other = other.value;
const check_sibling = sibling.value; const check_another = another.value; const check_alias = alias.value;
const check_spare = root.spare.value; const probe = check_child; probe;
`
 for _, tt := range []struct{name, use string}{
  {"safe", ""},
  {"late_sibling_write", "sibling.value = second;"},
  {"unselected_literal_write", "root.rows[1].more[0].value = second;"},
  {"captured_other_write", "function change(): void { other.value = second; }"},
  {"unselected_spare_escape", "consume(root.spare);"},
  {"selected_return_escape", "function leak() { return child; }"},
  {"destructured_sibling_escape", "const exported = { sibling };"},
  {"reexport_sibling", "export { sibling };"},
  {"reexport_root", "export { root };"},
  {"export_alias", "export const publicAlias = alias;"},
  {"empty_then_unsafe", "const [] = root.rows; consume(another);"},
  {"first_omitted", "const [, { box: selected }] = root.rows;"},
  {"last_omitted", "const [selected, ,] = root.rows;"},
  {"nested_omission", "const [{ more: [,] }] = root.rows;"},
  {"nested_rest", "const [{ more: [...selected] }] = root.rows;"},
  {"nested_default", "const [{ more: [selected = { value: first }] }] = root.rows;"},
  {"terminal_sibling", "const [{ box: { value } }] = root.rows;"},
  {"computed_key", "const [{ [\"box\"]: selected }] = root.rows;"},
  {"changed_any_contract", "const changed: { value: any } = other;"},
  {"changed_unknown_contract", "const changed: { value: unknown } = other;"},
  {"optional_contract", "const changed: { value?: Value } = other;"},
  {"dynamic_readback", "const dyn: any = another;"},
  {"asserted_alias", "const asserted = child as { value: Value };"},
  {"array_method", "const ignored = root.rows.values();"},
  {"dynamic_index", "let i = 0; const ignored = root.rows[i].box.value;"},
  {"annotated_rebinding", "const [selected]: { box: { value: Value }; more: { value: Value }[] }[] = root.rows;"},
 } {
  for _, receivers := range []bool{false, true} {
   for _, reverse := range []bool{false, true} {
    t.Run(fmt.Sprintf("%s_receiver_%t_reverse_%t", tt.name,receivers,reverse),func(t *testing.T){
     l, _ := valueFlowProbe(t, nestedContainerPrelude(receivers)+base+tt.use)
     projections := containerAliasProbeExpressions(l)
     assert.Equal(t,len(projections),7)
     if reverse { slices.Reverse(projections) }
     for round:=0;round<2;round++ {
      for _, projection := range projections {
       steps:=maxValueFlowSteps
       sources:=(sourceProof{l:l,receivers:receivers}).valueSources(projection,&steps,0)
       assert.Check(t,(sources!=nil)==(tt.use==""),"case=%s receiver=%t reverse=%t round=%d known=%t",tt.name,receivers,reverse,round,sources!=nil)
       if sources!=nil {assert.DeepEqual(t,returnedSourceNames(sources),inlineContainerSourceNames([]string{"first"},receivers))}
      }
     }
     assert.Equal(t,len(l.valueFlow.active),0)
     assert.Equal(t,len(l.valueFlow.receivers.active),0)
    })
   }
  }
 }
}

func TestReviewD214CheckerTupleBarrierEvidence(t *testing.T) {
 for _, tt:=range []struct{name, body string;known bool}{
  {"named", "const rows = [{ value: first }]; const [child] = rows; const probe = child.value; probe;",true},
  {"original_fresh", "const [child] = [{ value: first }]; const probe = child.value; probe;",false},
  {"fresh_projection", "const [child] = ({ rows: [{ value: first }] }).rows; const probe = child.value; probe;",true},
  {"nested_named", "const rows = [[{ value: first }]]; const [[child]] = rows; const probe = child.value; probe;",true},
  {"original_fresh_nested", "const [[child]] = [[{ value: first }]]; const probe = child.value; probe;",false},
  {"heterogeneous", "const rows = [{ value: first }, { value: first, tag: 1 }]; const [child] = rows; const probe = child.value; probe;",false},
  {"tuple_asserted", "const rows = [{ value: first }] as const; const [child] = rows; const probe = child.value; probe;",false},
 } {
  t.Run(tt.name,func(t *testing.T){
   l,probe:=valueFlowProbe(t,nestedContainerPrelude(false)+tt.body)
   var visit ast.Visitor
   visit=func(n *ast.Node)bool {
    if n.Kind==ast.KindArrayLiteralExpression {
     raw:=l.checker.GetWidenedType(l.checker.GetTypeAtLocation(n))
     t.Logf("raw array literal flags=%v IsArrayType=%t IsTupleType=%t ContextWithSkipBindingPatterns=%t",raw.Flags(),l.checker.IsArrayType(raw),checker.IsTupleType(raw),l.checker.GetContextualType(n,checker.ContextFlagsSkipBindingPatterns)!=nil)
    }
    n.ForEachChild(visit);return false
   }
   l.valueFlow.files[0].AsNode().ForEachChild(visit)
   steps:=maxValueFlowSteps
   got:=l.valueSources(probe,&steps,0)
   assert.Equal(t,got!=nil,tt.known)
  })
 }
}

func TestReviewD214SafeMixedFollowOnPatterns(t *testing.T) {
 for _, receivers:=range []bool{false,true} {
  for _, body:=range []string{
   `const root = [{ rows: [[{ value: first }]] }]; const [branch] = root; const { rows: [[child]] } = branch; const probe = child.value; probe;`,
   `const root = { rows: [[{ value: first }]] }; const { rows: [inner] } = root; const [child] = inner; const probe = child.value; probe;`,
   `const root = [{ value: first }, { value: second }]; const [] = root; const [child] = root; const probe = child.value; probe;`,
  } {
   l,probe:=valueFlowProbe(t,nestedContainerPrelude(receivers)+body)
   steps:=maxValueFlowSteps
   sources:=(sourceProof{l:l,receivers:receivers}).valueSources(probe,&steps,0)
   assert.Assert(t,sources!=nil)
   assert.DeepEqual(t,returnedSourceNames(sources),inlineContainerSourceNames([]string{"first"},receivers))
  }
 }
}
