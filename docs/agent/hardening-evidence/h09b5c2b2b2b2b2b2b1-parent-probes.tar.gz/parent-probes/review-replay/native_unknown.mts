class Box<T> {
  value: T;
  mark: string;
  constructor(value: T, mark: string) { this.value = value; this.mark = mark; }
}
class C0 { tag = 10; }
class C1 { tag = 20; }
type Factory = <T>(value: T) => Box<T>;
function source0<T>(value: T): Box<T> { return new Box(value, "source0"); }
function source1<T>(value: T): Box<T> { return new Box(value, "source1"); }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.mark, box.value.tag); }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.mark, box.value.tag); }
const first: Factory = source0;
const second: Factory = source1;
const keep: any[] = [first, second];
const rows = [{ factory: first }, { factory: first }];
const [left, right] = rows;
const dynamic: any = left;
dynamic.factory = second;
use0(left.factory);
use1(right.factory);
