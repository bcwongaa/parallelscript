import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(sys.argv[1]).resolve()
helpers = Path(sys.argv[2]).resolve()
env = dict(os.environ, GOMAXPROCS="1", PTS_HOME="/home/bryan/projects/parallelscript", PTS_THREADS="1")
rows = []
failed = False
for name in ("native_safe", "native_unknown"):
    source = out / (name + ".pts")
    mts = out / (name + ".mts")
    mts.write_bytes(source.read_bytes())
    nodecmd = ["/home/bryan/.local/node/bin/node", str(mts)]
    node = subprocess.run(nodecmd, env=env, capture_output=True, text=True, timeout=45)
    (out / (name + ".node.stdout")).write_text(node.stdout)
    (out / (name + ".node.stderr")).write_text(node.stderr)
    rows.append(dict(name=name, command=nodecmd, exit=node.returncode, stdout=node.stdout, stderr=node.stderr))
    if node.returncode:
        failed = True
    for compiler in ("base", "current"):
        helper = helpers / (compiler + "-emit")
        for mode in ("all", "default"):
            prefix = out / (name + "." + compiler + "." + mode)
            c = prefix.with_suffix(prefix.suffix + ".c")
            binary = prefix.with_suffix(prefix.suffix + ".bin")
            cmd = [str(helper), str(source), str(c), str(binary), mode]
            emit = subprocess.run(cmd, env=env, capture_output=True, text=True, timeout=120)
            Path(str(prefix) + ".emit.stdout").write_text(emit.stdout)
            Path(str(prefix) + ".emit.stderr").write_text(emit.stderr)
            row = dict(name=name, compiler=compiler, mode=mode, command=cmd,
                       helper_sha256=hashlib.sha256(helper.read_bytes()).hexdigest(), exit=emit.returncode,
                       emit_stdout=emit.stdout, emit_stderr=emit.stderr)
            if emit.returncode:
                failed = True
            else:
                code = c.read_text()
                pairs = [[v,d] for v in range(2) for d in range(2)
                         if "pts_fn_source%d_C%d(" % (v,d) in code]
                expected = [[0,0],[1,1]] if compiler == "current" and name == "native_safe" else [[0,0],[0,1],[1,0],[1,1]]
                row["pairs"] = pairs
                row["expected_pairs"] = expected
                row["pairs_match"] = pairs == expected
                run = subprocess.run([str(binary)], env=env, capture_output=True, text=True, timeout=45)
                Path(str(prefix) + ".run.stdout").write_text(run.stdout)
                Path(str(prefix) + ".run.stderr").write_text(run.stderr)
                row.update(run_exit=run.returncode, run_stdout=run.stdout, run_stderr=run.stderr,
                           node_match=run.returncode == node.returncode == 0 and run.stdout == node.stdout)
                if not row["pairs_match"] or not row["node_match"]:
                    failed = True
                binary.unlink()
            rows.append(row)
            print(json.dumps(row), flush=True)
(out / "native-results.json").write_text(json.dumps(rows, indent=2) + "\n")
sys.exit(int(failed))
