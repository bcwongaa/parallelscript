class Box<T> {
  value: T;
  mark: string;
  constructor(value: T, mark: string) { this.value = value; this.mark = mark; }
}
class C0 { tag = 10; }
class C1 { tag = 20; }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
let calls0 = 0;
let calls1 = 0;
function source0<T>(value: T): Box<T> { calls0++; return new Box(value, "source0/" + calls0); }
function source1<T>(value: T): Box<T> { calls1++; return new Box(value, "source1/" + calls1); }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.mark, box.value.tag); }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.mark, box.value.tag); }
const first: Factory = source0;
const second: Factory = source1;
const root0 = { grid: [[{ selected: { factory: first }, sibling: { factory: first } }]] };
const { grid: [[{ selected: child0, sibling: sibling0 }]] } = root0;
const root1 = [{ factory: second }];
const [child1] = root1;
const alias0 = child0;
const ignored = sibling0.factory;
use0(alias0.factory);
use1(child1.factory);
use0(child0.factory);
function build(label: string): Factory {
  let count = 0;
  return <T>(value: T): Box<T> => { count++; return new Box(value, label + "/" + count); };
}
const a: Factory = build("captured-a");
const b: Factory = build("captured-b");
const captureRows = [[{ factory: a }, { factory: b }]];
const [[left, right]] = captureRows;
use0(left.factory);
use1(right.factory);
use1(left.factory);
class Parent implements Maker {
  label: string;
  calls = 0;
  constructor(label: string) { this.label = label; }
  make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); }
}
class Child extends Parent {}
const lookup = new Parent("lookup");
const actual = new Child("actual");
const bound: Factory = lookup.make.bind(actual);
const methodRows = [{ branch: [{ factory: bound }] }];
const [{ branch: [methodChild] }] = methodRows;
use0(methodChild.factory);
use1(methodChild.factory);
console.log("receiver-counts", lookup.calls, actual.calls);
