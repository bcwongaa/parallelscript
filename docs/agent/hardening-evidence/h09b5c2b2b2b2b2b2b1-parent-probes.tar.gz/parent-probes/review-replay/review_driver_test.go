package driver_test

import (
 "fmt"
 "strings"
 "testing"

 "github.com/microsoft/typescript-go/pts/driver"
 "github.com/microsoft/typescript-go/pts/lower"
 "gotest.tools/v3/assert"
)

func TestReviewD214TargetMatrixMixedPatterns(t *testing.T) {
 for _, kind:=range []string{"function","receiver","captured_receiver","wrapper"} {
  for _, shape:=range []string{"safe","omission","nested_default","nested_rest","terminal_sibling","mutated_sibling","escaped_sibling","reexport_sibling","changed_raw_contract","typed_owner"} {
   t.Run(kind+"/"+shape,func(t *testing.T){
    var s strings.Builder
    s.WriteString(inlineContainerFlowInventory(kind,3))
    s.WriteString("const keepFunctions: any[] = [source0, source1, source2];\n")
    for i:=range 3 {
     value,other:=fmt.Sprintf("source%d",i),fmt.Sprintf("source%d",(i+1)%3)
     typ:="Factory"
     switch kind {
      case "receiver","captured_receiver":value,other=fmt.Sprintf("new M%d()",i),fmt.Sprintf("new M%d()",(i+1)%3);typ="Maker"
      case "wrapper":value,other=fmt.Sprintf("read%d()",i),fmt.Sprintf("read%d()",(i+1)%3)
     }
     fmt.Fprintf(&s,"const first%d: %s = %s; const other%d: %s = %s;\n",i,typ,value,i,typ,other)
     fmt.Fprintf(&s,"const root%d = { grid: [[{ a: { value: first%d }, b: { value: other%d } }]] };\n",i,i,i)
     fmt.Fprintf(&s,"const { grid: [[{ a: child%d, b: sibling%d }]] } = root%d;\n",i,i,i)
     switch shape {
      case "omission":fmt.Fprintf(&s,"const { grid: [[,]] } = root%d;\n",i)
      case "nested_default":fmt.Fprintf(&s,"const { grid: [[{ a: extra%d = { value: first%d } }]] } = root%d;\n",i,i,i)
      case "nested_rest":fmt.Fprintf(&s,"const { grid: [[...extra%d]] } = root%d;\n",i,i)
      case "terminal_sibling":fmt.Fprintf(&s,"const { value: extra%d } = sibling%d;\n",i,i)
      case "mutated_sibling":fmt.Fprintf(&s,"sibling%d.value = first%d;\n",i,i)
      case "escaped_sibling":fmt.Fprintf(&s,"consumeContainer(sibling%d);\n",i)
      case "reexport_sibling":fmt.Fprintf(&s,"export { sibling%d };\n",i)
      case "changed_raw_contract":fmt.Fprintf(&s,"const changed%d: { value: any } = sibling%d;\n",i,i)
      case "typed_owner":fmt.Fprintf(&s,"const [typed%d]: { a: { value: %s }; b: { value: %s } }[] = root%d.grid[0];\n",i,typ,typ,i)
     }
     terminal:=fmt.Sprintf("child%d.value",i)
     if kind=="captured_receiver" {terminal=fmt.Sprintf("read%d(%s)",i,terminal)}
     fmt.Fprintf(&s,"use%d(%s);\n",i,terminal)
    }
    entry:=writeSource(t,s.String())
    c,err:=driver.EmitCWith(t.Context(),entry,lower.AllInstances)
    if shape=="changed_raw_contract" {
     assert.Assert(t,err!=nil && strings.Contains(err.Error(),"PTS1001"),"this raw-contract source conversion remains unsupported at the exact AllInstances API, not a target-pruning result: %v",err)
     t.Logf("unsupported AllInstances raw-contract conversion retained: %v",err)
     return
    }
    assert.NilError(t,err)
    pairs:=inlineContainerAssertPairs(t,c,kind,3,func(v,d int)bool{return shape!="safe"||v==d})
    t.Logf("kind=%s shape=%s direct AllInstances targets=%d",kind,shape,pairs)
   })
  }
 }
}
