import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def manifest(repo):
    names = set(subprocess.check_output(["git", "ls-files", "-co", "--exclude-standard", "-z", "pts", "cmd/pts", "internal"], cwd=repo).decode().strip("\0").split("\0"))
    for record in subprocess.check_output(["git", "ls-files", "-s", "pts/third_party"], cwd=repo).decode().splitlines():
        mode, _, rest = record.split(" ", 2)
        if mode == "160000":
            submodule = rest.split("\t", 1)[1]
            for child in subprocess.check_output(["git", "ls-files", "-z"], cwd=repo / submodule).decode().strip("\0").split("\0"):
                names.add(submodule + "/" + child)
    names.update(["README.md", "docs/GUIDE.md", "docs/SPEC.md", "docs/ARCHITECTURE.md"])
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in sorted(names) if name and (repo / name).is_file()}


def main():
    repo, out = map(Path, sys.argv[1:3])
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, GOMAXPROCS="4", PTS_REQUIRE_NODE="1")
    before = manifest(repo)
    (out / "sources.before.json").write_text(json.dumps(before, indent=2) + "\n")
    with (out / "build.stdout").open("w") as stdout, (out / "build.stderr").open("w") as stderr:
        build = subprocess.run(["make", "build"], cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=600)
    cli_before = hashlib.sha256((repo / "pts-bin/pts").read_bytes()).hexdigest()
    command = ["go", "test", "-count=1", "-json", "-p", "4", "-parallel", "4", "-timeout", "40m", "./pts/...", "./cmd/pts/"]
    (out / "command.json").write_text(json.dumps(command) + "\n")
    result = None
    if build.returncode == 0:
        with (out / "suite.jsonl").open("w") as stdout, (out / "suite.stderr").open("w") as stderr:
            result = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=2700)
    after = manifest(repo)
    (out / "sources.after.json").write_text(json.dumps(after, indent=2) + "\n")
    cli_after = hashlib.sha256((repo / "pts-bin/pts").read_bytes()).hexdigest()
    counts, corpus, packages = collections.Counter(), collections.Counter(), {}
    for line in (out / "suite.jsonl").open() if (out / "suite.jsonl").exists() else []:
        event = json.loads(line)
        action, test = event.get("Action"), event.get("Test", "")
        if action in ("pass", "skip", "fail"):
            if test:
                counts[action] += 1
                if test.startswith("TestCorpusMatchesNode/"):
                    corpus[action] += 1
            else:
                packages[event["Package"]] = action
    summary = {"build_exit": build.returncode, "suite_exit": result.returncode if result else None, "counts": dict(counts), "corpus": dict(corpus), "packages": packages, "source_files": len(before), "sources_unchanged": before == after, "cli_before": cli_before, "cli_after": cli_after, "cli_unchanged": cli_before == cli_after, "build_stderr_bytes": (out / "build.stderr").stat().st_size, "suite_stderr_bytes": (out / "suite.stderr").stat().st_size if (out / "suite.stderr").exists() else None}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2), flush=True)
    assert build.returncode == 0 and result is not None and result.returncode == 0, "build/test failed"
    assert before == after and cli_before == cli_after, "frozen inputs changed"
    assert not counts["fail"] and all(value != "fail" for value in packages.values()), "test failure"


if __name__ == "__main__":
    main()
