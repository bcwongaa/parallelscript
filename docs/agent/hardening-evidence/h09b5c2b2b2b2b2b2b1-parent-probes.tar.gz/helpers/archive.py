import gzip
import hashlib
import json
from pathlib import Path
import tarfile
import sys


def main():
    repo, scratch = map(Path, sys.argv[1:3])
    work = repo / "pts-bin/d214"
    evidence = repo / "docs/agent/hardening-evidence"
    prefix = "h09b5c2b2b2b2b2b2b1"
    final = work / "final-round1"
    summary = json.loads((final / "summary.json").read_text())
    assert summary["build_exit"] == summary["suite_exit"] == 0 and summary["sources_unchanged"] and summary["cli_unchanged"]
    snapshot = json.loads((work / "reviewed-snapshot.json").read_text())
    assert all(hashlib.sha256((repo / path).read_bytes()).hexdigest() == digest for path, digest in snapshot.items())
    target = evidence / (prefix + "-parent-probes.tar.gz")
    assert not target.exists()
    with tarfile.open(target, "w:gz") as archive:
        def add(path, name):
            assert path.is_file() and not path.is_symlink(), path
            assert path.suffix not in (".bin", ".pyc"), path
            archive.add(path, arcname=name, recursive=False)

        for path in sorted(scratch.iterdir()):
            if path.is_file():
                add(path, "parent-raw/" + path.name)
        for name in ("emit.go", "native.py", "measure.py", "mutants.py", "final_suite.py", "archive.py", "raw_layout_probe_test.go", "base-overlay.json", "raw-layout-overlay.json", "reviewed-snapshot.json"):
            add(work / name, "helpers/" + name)
        for directory in ("base", "original-tests", "native-round1", "native-round2", "growth-round2", "growth-repeat", "mutants-round1", "review-replay"):
            for path in sorted((work / directory).rglob("*")):
                if path.is_file() and path.suffix not in (".bin", ".pyc"):
                    add(path, "parent-probes/" + str(path.relative_to(work)))
        for name in ("sources.before.json", "sources.after.json", "summary.json", "command.json", "build.stdout", "build.stderr", "suite.stderr"):
            add(final / name, "final/" + name)
        for name in snapshot:
            add(repo / name, "reviewed-snapshot/" + name)
    raw = evidence / (prefix + "-final-suite.jsonl.gz")
    assert not raw.exists()
    raw.write_bytes(gzip.compress((final / "suite.jsonl").read_bytes(), mtime=0))
    assert gzip.decompress(raw.read_bytes()) == (final / "suite.jsonl").read_bytes()
    receipt = evidence / (prefix + "-final-summary.json")
    assert not receipt.exists()
    receipt.write_text(json.dumps(summary, indent=2) + "\n")
    rows = []
    for path in (target, raw, receipt, evidence / (prefix + "-reproducer-probes.tar.gz"), evidence / (prefix + "-review-probes.tar.gz")):
        row = {"path": path.name, "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        if path.name.endswith(".tar.gz"):
            with tarfile.open(path) as archive:
                members = archive.getmembers()
                for member in members:
                    assert not member.name.startswith("/") and ".." not in Path(member.name).parts
                    assert not member.issym() and not member.islnk() and (member.isfile() or member.isdir())
                    assert not member.name.endswith((".bin", ".pyc"))
                row["members"] = len(members)
        rows.append(row)
    manifest = evidence / (prefix + "-artifacts.json")
    assert not manifest.exists()
    manifest.write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2), flush=True)


if __name__ == "__main__":
    main()
