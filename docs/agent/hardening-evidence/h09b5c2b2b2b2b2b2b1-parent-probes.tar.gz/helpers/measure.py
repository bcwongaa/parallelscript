import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def inventory(kind, count):
    lines = [
        "class Box<T> { constructor(public value: T) {} }",
        "type Factory = <T>(value: T) => Box<T>;",
        "interface Maker { make<T>(value: T): Box<T>; }",
        "function consumeContainer(value: unknown): void {}",
    ]
    for i in range(count):
        lines += [
            f"class C{i} {{ tag = {i}; }}",
            f"function source{i}<T>(value: T): Box<T> {{ return new Box(value); }}",
            f"class M{i} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value); }} }}",
        ]
        if kind == "receiver":
            lines.append(f"function use{i}(receiver: Maker): void {{ const box: Box<C{i}> = receiver.make(new C{i}()); console.log(box.value.tag); }}")
        else:
            lines.append(f"function use{i}(factory: Factory): void {{ const box: Box<C{i}> = factory(new C{i}()); console.log(box.value.tag); }}")
        if kind == "captured_receiver":
            lines.append(f"function read{i}(receiver: Maker): Factory {{ return receiver.make.bind(receiver); }}")
        elif kind == "wrapper":
            lines.append(f"function read{i}(): Factory {{ const receiver: Maker = new M{i}(); return receiver.make.bind(receiver); }}")
    return lines


def source(kind, count, unknown):
    lines = inventory(kind, count)
    value_type = "Maker" if kind in ("receiver", "captured_receiver") else "Factory"
    for i in range(count):
        value = f"new M{i}()" if value_type == "Maker" else f"read{i}()" if kind == "wrapper" else f"source{i}"
        lines += [
            f"const selected{i}: {value_type} = {value};",
            f"const root{i} = [{{ value: selected{i} }}];",
            f"const [child{i}] = root{i};",
        ]
        if unknown:
            lines.append(f"consumeContainer(child{i});")
        terminal = f"child{i}.value"
        if kind == "captured_receiver":
            terminal = f"read{i}({terminal})"
        lines.append(f"use{i}({terminal});")
    return "\n".join(lines) + "\n"


def run(command, path, env):
    start = time.monotonic()
    result = subprocess.run(command, text=True, capture_output=True, env=env, timeout=600)
    path.with_suffix(path.suffix + ".stdout").write_text(result.stdout)
    path.with_suffix(path.suffix + ".stderr").write_text(result.stderr)
    if result.returncode:
        raise RuntimeError(f"exit {result.returncode}: {command}: {result.stderr[-2000:]}")
    return result.stdout, time.monotonic() - start


def main():
    repo, out, base, current = map(Path, sys.argv[1:5])
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS="1", PTS_THREADS="1")
    rows = []
    for kind in ("function", "receiver", "captured_receiver", "wrapper"):
        for count, unknown in ((4, False), (60, False), (8, True)):
            name = f"{kind}-{count}-{'unknown' if unknown else 'known'}"
            entry = out / (name + ".pts")
            entry.write_text(source(kind, count, unknown))
            twin = entry.with_suffix(".mts")
            twin.write_text(entry.read_text())
            oracle, _ = run([str(Path.home() / ".local/node/bin/node"), "--experimental-transform-types", str(twin)], out / (name + ".node"), env)
            assert oracle == "".join(f"{i}\n" for i in range(count)), (name, oracle)
            order = [("base", base), ("current", current)]
            if len(rows) % 2:
                order.reverse()
            row = {"name": name, "kind": kind, "count": count, "unknown": unknown, "order": [x[0] for x in order]}
            for label, helper in order:
                prefix = out / (name + "." + label)
                cfile = prefix.with_suffix(prefix.suffix + ".c")
                binary = prefix.with_suffix(prefix.suffix + ".bin")
                _, elapsed = run([str(helper), str(entry), str(cfile), str(binary), "all"], prefix.with_suffix(prefix.suffix + ".emit"), env)
                code = cfile.read_text()
                pairs = []
                for value in range(count):
                    for demand in range(count):
                        target = f"pts_fn_source{value}_C{demand}(" if kind == "function" else f"pts_fn_M{value}_make_C{demand}("
                        present = target in code
                        required = label == "base" or unknown or value == demand
                        assert present == required, (name, label, target, present, required)
                        if kind != "function":
                            assert ("return " + target in code) == required, (name, label, "registration", target)
                        if present:
                            pairs.append([value, demand])
                stdout, _ = run([str(binary)], prefix.with_suffix(prefix.suffix + ".native"), env)
                binary.unlink()
                assert stdout == oracle, (name, label, stdout, oracle)
                row[label] = {"pairs": len(pairs), "required_pairs": pairs, "lines": code.count("\n"), "bytes": cfile.stat().st_size, "sha256": hashlib.sha256(cfile.read_bytes()).hexdigest(), "emit_compile_seconds": elapsed, "node_match": True}
            if unknown:
                assert row["base"]["sha256"] == row["current"]["sha256"], name
            rows.append(row)
            (out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
            print(name, row["base"]["pairs"], "->", row["current"]["pairs"], "pairs;", row["base"]["lines"], "->", row["current"]["lines"], "lines", flush=True)


if __name__ == "__main__":
    main()
