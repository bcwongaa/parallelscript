import json
import os
from pathlib import Path
import subprocess
import sys


def execute(command, prefix, env):
    result = subprocess.run(command, text=True, capture_output=True, env=env, timeout=300)
    Path(str(prefix) + ".stdout").write_text(result.stdout)
    Path(str(prefix) + ".stderr").write_text(result.stderr)
    Path(str(prefix) + ".command.json").write_text(json.dumps(command) + "\n")
    if result.returncode:
        raise RuntimeError(f"exit {result.returncode}: {command}: {result.stderr[-3000:]}")
    return result


def main():
    repo, out, entry, base, current = map(Path, sys.argv[1:6])
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS="1", PTS_THREADS="1")
    twin = out / "oracle.mts"
    twin.write_text(entry.read_text())
    oracle = execute([str(Path.home() / ".local/node/bin/node"), "--experimental-transform-types", str(twin)], out / "node", env)
    if "// expect:\n" in entry.read_text():
        expected = "\n".join(line[3:] for line in entry.read_text().split("// expect:\n")[1].splitlines() if line.startswith("// ")) + "\n"
        assert oracle.stdout == expected, (oracle.stdout, expected)
    rows = []
    for label, helper in (("base", base), ("current", current)):
        for mode in ("all", "default"):
            name = label + "." + mode
            cfile = out / (name + ".c")
            binary = out / (name + ".bin")
            execute([str(helper), str(entry), str(cfile), str(binary), mode], out / (name + ".emit"), env)
            result = execute([str(binary)], out / (name + ".native"), env)
            binary.unlink()
            assert result.stdout == oracle.stdout, (name, result.stdout, oracle.stdout)
            rows.append({"compiler": label, "mode": mode, "node_match": True, "output_lines": result.stdout.count("\n")})
            print(name, "strict Node match", flush=True)
    (out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
