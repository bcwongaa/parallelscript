package lower

import (
	"testing"

	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
	"gotest.tools/v3/assert"
)

func TestD214RawArrayPatternLayouts(t *testing.T) {
	for _, tt := range []struct {
		name string
		body string
		array bool
		tuple bool
	}{
		{"named_ordinary_control", "const root = [{ value: first }]; const [child] = root; const probe = child.value; probe;", true, false},
		{"original_fresh_input", "const [child] = [{ value: first }]; const probe = child.value; probe;", false, true},
		{"fresh_object_projection", "const [child] = ({ rows: [{ value: first }] }).rows; const probe = child.value; probe;", true, false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+tt.body)
			count := 0
			var visit ast.Visitor
			visit = func(node *ast.Node) bool {
				if node.Kind == ast.KindArrayLiteralExpression {
					own := l.checker.GetWidenedType(l.checker.GetTypeAtLocation(node))
					array, tuple := l.checker.IsArrayType(own), checker.IsTupleType(own)
					t.Logf("initializer raw widened layout: IsArrayType=%t IsTupleType=%t", array, tuple)
					assert.Equal(t, array, tt.array)
					assert.Equal(t, tuple, tt.tuple)
					count++
				}
				node.ForEachChild(visit)
				return false
			}
			for _, file := range l.valueFlow.files {
				file.AsNode().ForEachChild(visit)
			}
			assert.Equal(t, count, 1)
		})
	}
}

func TestD214CorrectedHoleyDensePrefixGuard(t *testing.T) {
	for _, receivers := range []bool{false, true} {
		body := `const root = [{ value: first }, { value: second }, ,]; const [child, sibling] = root;
// @ts-expect-error: the literal's selected prefix is dense, but a later hole widens the raw element contract
const ignored = sibling.value;
// @ts-expect-error: the literal's selected prefix is dense, but a later hole widens the raw element contract
const probe = child.value; probe;`
		l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+body)
		steps := maxValueFlowSteps
		sources := (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0)
		assert.Assert(t, sources == nil, "a hole outside the selected dense prefix invalidates the complete literal root")
	}
}
