package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 5 {
		fmt.Fprintln(os.Stderr, "usage: emit entry.pts exact.c binary-or-dash all-or-default")
		os.Exit(2)
	}
	if err := emit(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func emit() error {
	ctx := context.Background()
	var code string
	var err error
	switch os.Args[4] {
	case "all":
		code, err = driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	case "default":
		code, err = driver.EmitC(ctx, os.Args[1])
	default:
		return fmt.Errorf("unknown emission mode %q", os.Args[4])
	}
	if err != nil {
		return err
	}
	if err := os.WriteFile(os.Args[2], []byte(code), 0600); err != nil {
		return err
	}
	if os.Args[3] == "-" {
		return nil
	}
	compiler, err := toolchain.New()
	if err != nil {
		return err
	}
	runtime, err := compiler.Runtime(ctx, toolchain.Release)
	if err != nil {
		return err
	}
	return compiler.CompileProgram(ctx, runtime, []string{os.Args[2]}, os.Args[3])
}
