package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "usage: native_all fixture.pts output-prefix")
		os.Exit(2)
	}
	if err := compile(os.Args[1], os.Args[2]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func compile(entry, prefix string) error {
	ctx := context.Background()
	code, err := driver.EmitCWith(ctx, entry, lower.AllInstances)
	if err != nil {
		return err
	}
	if err := os.WriteFile(prefix+".c", []byte(code), 0o644); err != nil {
		return err
	}
	compiler, err := toolchain.New()
	if err != nil {
		return err
	}
	runtime, err := compiler.Runtime(ctx, toolchain.Release)
	if err != nil {
		return err
	}
	return compiler.CompileProgram(ctx, runtime, []string{prefix + ".c"}, prefix+".bin")
}
