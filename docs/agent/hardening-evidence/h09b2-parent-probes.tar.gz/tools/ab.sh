#!/bin/bash
# ab.sh files...: run each file with HEAD's build (/tmp/h09b2/base) and the main tree's; print files whose outputs differ.
for f in "$@"; do
  a=$(PTS_HOME=/tmp/h09b2/base timeout 120 /tmp/h09b2/base/pts-bin/pts run "$f" 2>&1); ea=$?
  b=$(PTS_HOME=/home/bryan/projects/parallelscript timeout 120 /home/bryan/projects/parallelscript/pts-bin/pts run "$f" 2>&1); eb=$?
  if [ "$a" != "$b" ] || [ $ea != $eb ]; then echo "=== $f (head $ea, now $eb)"; diff <(echo "$a") <(echo "$b") | head -20; fi
done
