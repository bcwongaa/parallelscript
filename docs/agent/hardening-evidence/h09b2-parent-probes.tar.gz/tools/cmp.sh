#!/bin/bash
# cmp.sh PTS HOME files...: run each file with PTS (PTS_HOME=HOME) and Node; print both outputs with exit codes.
pts=$1; home=$2; shift 2
export PATH=$HOME/.local/node/bin:$PATH
for f in "$@"; do
  echo "=== $f"
  out=$(PTS_HOME=$home timeout 120 $pts run "$f" 2>&1); e=$?
  d=$(mktemp -d); cp "$f" $d/x.mts
  nout=$(cd $d && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types x.mts 2>&1); ne=$?
  rm -rf $d
  if [ "$out" == "$nout" ] && [ $e == $ne ]; then echo "SAME (exit $e)"; echo "$out" | head -${LINES_SHOWN:-6}; else echo "--- pts (exit $e)"; echo "$out" | head -20; echo "--- node (exit $ne)"; echo "$nout" | head -20; fi
done
