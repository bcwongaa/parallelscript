#!/bin/bash
# vsnode.sh files...: run each .pts with the main tree's pts and with Node; print SAME or both outputs (exit codes).
export PATH=$HOME/.local/node/bin:$PATH
for f in "$@"; do
  b=$(cd "$(dirname "$f")" && PTS_HOME=/home/bryan/projects/parallelscript timeout 120 /home/bryan/projects/parallelscript/pts-bin/pts run "$(basename "$f")" 2>&1); eb=$?
  d=$(mktemp -d); cp "$f" $d/x.mts
  n=$(cd $d && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types x.mts 2>&1); en=$?; rm -rf $d
  if [ "$b" == "$n" ] && [ $eb == $en ]; then echo "SAME $f"; else echo "######## $f"; echo "--- now ($eb)"; echo "$b" | head -${MAXL:-12}; echo "--- node ($en)"; echo "$n" | head -${MAXL:-12}; fi
done
