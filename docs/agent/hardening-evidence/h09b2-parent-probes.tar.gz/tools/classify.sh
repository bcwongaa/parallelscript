#!/bin/bash
# classify.sh FILE: HEAD, now and Node; prints FIXED / REGRESSED / BOTH-DIFFER / SAME-AS-NODE / OTHER with the file.
export PATH=$HOME/.local/node/bin:$PATH
f=$1
a=$(cd "$(dirname "$f")" && PTS_HOME=/tmp/h09b2/base timeout 120 /tmp/h09b2/base/pts-bin/pts run "$(basename "$f")" 2>/dev/null); ea=$?
b=$(cd "$(dirname "$f")" && PTS_HOME=/home/bryan/projects/parallelscript timeout 120 /home/bryan/projects/parallelscript/pts-bin/pts run "$(basename "$f")" 2>/dev/null); eb=$?
d=$(mktemp -d); cp "$f" $d/x.mts; for m in $(dirname "$f")/*.pts; do :; done
n=$(cd $d && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types x.mts 2>/dev/null); en=$?; rm -rf $d
hn=0; [ "$a" == "$n" ] && [ $ea == $en ] && hn=1
bn=0; [ "$b" == "$n" ] && [ $eb == $en ] && bn=1
if [ $hn == 0 ] && [ $bn == 1 ]; then echo "FIXED $f"; elif [ $hn == 1 ] && [ $bn == 0 ]; then echo "REGRESSED $f"; elif [ $hn == 1 ] && [ $bn == 1 ]; then echo "SAME-AS-NODE $f"; else echo "BOTH-DIFFER $f (head $ea, now $eb, node $en)"; fi
