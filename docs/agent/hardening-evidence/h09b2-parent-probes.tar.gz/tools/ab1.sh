#!/bin/bash
# ab1.sh FILE: HEAD vs now for one file; prints a block if they differ.
f=$1
a=$(cd "$(dirname "$f")" && PTS_HOME=/tmp/h09b2/base timeout 120 /tmp/h09b2/base/pts-bin/pts run "$(basename "$f")" 2>&1); ea=$?
b=$(cd "$(dirname "$f")" && PTS_HOME=/home/bryan/projects/parallelscript timeout 120 /home/bryan/projects/parallelscript/pts-bin/pts run "$(basename "$f")" 2>&1); eb=$?
if [ "$a" != "$b" ] || [ $ea != $eb ]; then printf '=== %s (head %s, now %s)\n%s\n' "$f" $ea $eb "$(diff <(echo "$a") <(echo "$b") | head -12)"; fi
