// v13's defaults in declarations (`const { opt = [] } = b`) and nested patterns, for a
// Box<number> in a Box<any> place, and from an `unknown` narrowing.
class Box<T> {
  opt?: T[];
  meta: { tags?: T[] } = {};
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("decl default", () => { const { opt = [] } = b; opt.push("d"); return opt.length; });
  t("nested assign default", () => { let tags: any[] = []; ({ meta: { tags = [] } } = b); tags.push("na"); return tags.length; });
  t("nested decl default", () => { const { meta: { tags = [] } } = b; tags.push("nd"); return tags.length; });
}
function fromUnknown(u: unknown): void {
  if (!(u instanceof Box)) return;
  t("unknown assign default", () => { let opt: any[] = []; ({ opt = [] } = u); opt.push("u"); return opt.length; });
}
const n = new Box<number>(0); n.opt = []; n.meta.tags = [];
forms(n);
fromUnknown(n);
console.log(JSON.stringify(n.opt), JSON.stringify(n.meta.tags));
