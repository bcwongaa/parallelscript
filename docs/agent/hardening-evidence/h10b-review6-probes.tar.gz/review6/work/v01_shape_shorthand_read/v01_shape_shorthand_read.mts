// v01: a destructuring assignment from an instanceof narrowing (shorthand_read), for Box<any> and
// Box<number> objects: snapshot 8 makes copying ones D-218's PTS1001; did base or snap6 run it?
interface Shape { kind(): string; }
class Box<T> implements Shape {
  items: T[] = [];
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  constructor(public v: T) {}
  kind(): string { return "box"; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function run(o: Shape): void {
  if (!(o instanceof Box)) return;
  t("shorthand_read", () => { let items: any[] = []; ({ items } = o); return items.length; });
}
const a = new Box<any>(0); a.items.push(1); a.meta.tags.push(1);
const n = new Box<number>(0); n.items.push(1); n.meta.tags.push(1);
run(a); run(n);
console.log(JSON.stringify(a.items), JSON.stringify(a.meta.tags), JSON.stringify(n.items), JSON.stringify(n.meta.tags));
