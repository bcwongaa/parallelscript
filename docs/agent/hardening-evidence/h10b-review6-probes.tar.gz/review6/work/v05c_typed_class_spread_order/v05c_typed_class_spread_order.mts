// A typed spread of a class instance whose field order differs from the object type's (no Box<any>).
type Meta = { name: string; count: number };
class MetaImpl implements Meta { count = 3; name = "impl"; }
const m: Meta = new MetaImpl();
console.log(JSON.stringify({ ...m }));
