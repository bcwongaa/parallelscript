// anyInstanceSource sees through calls: a fresh object a method of a Box<any> place's value
// returns (its own new arrays, which nothing else holds) now takes the as-is rule. For a
// Box<number>, Node (and a copy) work: is it now a TypeError?
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
  snapshot(): { n: number; items: T[] } { return { n: this.items.length, items: [...this.items] }; }
  pair(): [T[], T[]] { return [[], []]; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).message); }
};
function forms(b: Box<any>): void {
  t("spread", () => { const s = { ...b.snapshot() }; s.items.push(9); return s.items; });
  t("rest", () => { const { n, ...r } = b.snapshot(); r.items.push(8); return r.items; });
  t("assign", () => { let items: any[] = []; ({ items } = b.snapshot()); items.push(7); return items; });
  t("decl", () => { const { items } = b.snapshot(); items.push(6); return items; });
  t("annotated", () => { const s: { n: number; items: any[] } = b.snapshot(); s.items.push(5); return s.items; });
  t("plain", () => { const s = b.snapshot(); s.items.push(4); return s.items; });
}
const nb = new Box<number>(0); nb.items.push(1);
forms(nb);
const ab = new Box<any>(0); ab.items.push(1);
forms(ab);
console.log(JSON.stringify(nb.items), JSON.stringify(ab.items));
