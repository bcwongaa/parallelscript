// A rest pattern in a for…of declaration over a narrowing's container, only read.
class Box<T> {
  metas: { name: string; tags: T[] }[] = [{ name: "m", tags: [] }];
  constructor(public v: T) {}
}
function run(o: object): void {
  if (!(o instanceof Box)) return;
  for (const { name, ...r } of o.metas) console.log(name, r.tags.length);
}
run(new Box<number>(0));
