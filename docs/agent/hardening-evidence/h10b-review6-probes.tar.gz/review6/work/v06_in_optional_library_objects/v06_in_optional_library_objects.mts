// `"k" in v` where tsc declares k optional and v is dynamic (looked up at run time since
// snap5): plain objects with and without k, and library objects that have k on their
// prototype (a Map's size, an array's length, a function's name, a promise's then).
type Sized = { size?: number };
type Lengthy = { length?: number };
type Named = { name?: string };
type Thenable = { then?: unknown };
function isSized(u: unknown): u is Sized { return typeof u === "object" && u !== null; }
function isLengthy(u: unknown): u is Lengthy { return typeof u === "object" && u !== null; }
function isNamed(u: unknown): u is Named { return u !== null && u !== undefined; }
function isThenable(u: unknown): u is Thenable { return typeof u === "object" && u !== null; }
const vals: unknown[] = [new Map(), {}, { size: 1 }];
for (const v of vals) if (isSized(v)) console.log("size", "size" in v);
const arrs: unknown[] = [[1], {}];
for (const v of arrs) if (isLengthy(v)) console.log("length", "length" in v);
const fns: unknown[] = [function named() {}, {}];
for (const v of fns) if (isNamed(v)) console.log("name", "name" in v);
const ps: unknown[] = [Promise.resolve(1), {}];
for (const v of ps) if (isThenable(v)) console.log("then", "then" in v);
class Box<T> {
  m: Sized = new Map<string, T>() as unknown as Sized;
  constructor(public v: T) {}
}
const b: Box<any> = new Box<any>(0);
console.log("box member", "size" in b.m);
