// v05 without the Box<number> line, for the base.
// an object a narrowing added a key to, a Record, and undefined for an optional member.
type Meta = { name: string; count: number };
class MetaImpl implements Meta { count = 3; name = "impl"; }
class Box<T> {
  meta: Meta = { count: 1, name: "m" };
  opt?: Meta;
  rec: Record<string, number> = { z: 1, a: 2 };
  tags: { list: T[]; label: string } = { label: "l", list: [] };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
const show = (name: string, f: () => unknown) => {
  try { const v = f(); console.log(name, JSON.stringify(v), Object.keys(v as object).join(",")); } catch (e) { console.log(name, (e as Error).message); }
};
show("literal", () => ({ ...b.meta }));
b.meta = new MetaImpl();
show("class", () => ({ ...b.meta }));
b.meta = Object.freeze({ count: 4, name: "frozen" });
show("frozen", () => ({ ...b.meta }));
const copy = { ...b.meta }; copy.count = 9;
show("frozen copy writable", () => copy);
show("record", () => ({ ...b.rec }));
show("over", () => ({ ...b.meta, count: 7 }));
