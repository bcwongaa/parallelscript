// Destructuring assignments whose right side is a literal holding a Box<any> place's arrays,
// and plain swaps (no Box): memberCopyOf of a literal.
class Box<T> {
  items: T[] = [];
  rows: T[][] = [[]];
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>, tag: string): void {
  t("object literal", () => { let a: any[] = []; let n = 0; ({ a, n } = { a: b.items, n: 1 }); a.push(tag + 1); return a.length; });
  t("renamed literal", () => { let x: any[] = []; ({ a: x } = { a: b.items }); x.push(tag + 2); return x.length; });
}
let p = 1, q = 2;
[p, q] = [q, p];
let s1 = "a", s2 = "b";
({ s1, s2 } = { s1: s2, s2: s1 });
console.log("swaps", p, q, s1, s2);
const nb = new Box<number>(0);
forms(nb, "n");
const ab = new Box<any>(0);
forms(ab, "a");
console.log(JSON.stringify(nb.items), JSON.stringify(ab.items));
