// anyInstanceSource walks member reads, calls, `!`, `as` and parentheses. The same member
// reached through `??`, `||`, `?:`, a comma or `await` (for a Box<number> in a Box<any>
// place): the as-is TypeError, or a silent copy?
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  opt?: { name: string; tags: T[] };
  constructor(public v: T) {}
  async load(): Promise<{ name: string; tags: T[] }> { return this.meta; }
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
const empty = { name: "", tags: [] as any[] };
function forms(b: Box<any>, yes: boolean): void {
  t("?? spread", () => { const m = { ...(b.opt ?? empty) }; m.tags.push("a"); return m.tags.length; });
  t("|| rest", () => { const { name, ...r } = b.opt || empty; r.tags.push("b"); return r.tags.length; });
  t("?: spread", () => { const m = { ...(yes ? b.meta : empty) }; m.tags.push("c"); return m.tags.length; });
  t("?: assign", () => { let tags: any[] = []; ({ tags } = yes ? b.meta : empty); tags.push("d"); return tags.length; });
  t("comma rest", () => { let k = 0; const { name, ...r } = (k++, b.meta); r.tags.push("e"); return r.tags.length; });
  t("?? decl", () => { const { tags } = b.opt ?? empty; tags.push("f"); return tags.length; });
}
async function viaAwait(b: Box<any>): Promise<void> {
  t("await spread", () => 0);
  const m = { ...(await b.load()) };
  try { m.tags.push("g"); } catch (e) { console.log("await push", (e as Error).name); }
  const { name, ...r } = await b.load();
  r.tags.push("h");
}
const nb = new Box<number>(0);
nb.opt = nb.meta;
forms(nb, true);
viaAwait(nb).then(() => console.log("number", JSON.stringify(nb.meta.tags)), (e) => console.log("rejected", (e as Error).name, JSON.stringify(nb.meta.tags)));
