// Realistic: a Redux-like Store<S> kept in a registry as Store<any>; reducers return fresh
// state by spreads; getState()'s results taken apart by rests and destructuring
// assignments; `in` on optional action fields; listeners subscribed through getters and
// awaited dispatches; a Store<number[]> in a Store<any> place.
type Action = { type: string; payload?: unknown; meta?: { ts: number } };
class Store<S> {
  listeners: ((s: S) => void)[] = [];
  log: string[] = [];
  constructor(private state: S, private reducer: (s: S, a: Action) => S) {}
  getState(): S { return this.state; }
  dispatch(a: Action): void {
    this.log.push(a.type + ("meta" in a ? "@" : ""));
    this.state = this.reducer(this.state, a);
    for (const l of this.listeners) l(this.state);
  }
  subscribe(l: (s: S) => void): () => void {
    this.listeners.push(l);
    return () => { this.listeners = this.listeners.filter((x) => x !== l); };
  }
}
type Todos = { items: string[]; done: number; filter?: string };
const todos = (s: Todos, a: Action): Todos => {
  switch (a.type) {
    case "add": return { ...s, items: [...s.items, String(a.payload)] };
    case "done": return { ...s, done: s.done + 1 };
    case "filter": return { ...s, filter: String(a.payload) };
  }
  return s;
};
class Registry {
  stores = new Map<string, Store<any>>();
  reads = 0;
  get todos(): Store<any> { this.reads++; return this.stores.get("todos")!; }
}
const reg = new Registry();
reg.stores.set("todos", new Store<Todos>({ items: [], done: 0 }, todos));
const seen: number[] = [];
const onChange = (s: any) => { seen.push(s.items.length); };
const off = reg.todos.subscribe(onChange);
async function main(): Promise<void> {
  reg.todos.dispatch(await Promise.resolve({ type: "add", payload: "a" }));
  reg.todos.dispatch({ type: "add", payload: "b", meta: { ts: 1 } });
  const { items, ...rest } = reg.todos.getState() as Todos;
  console.log("rest", items.join(","), JSON.stringify(rest), "filter" in rest);
  let done = 0; let all: string[] = [];
  ({ done, items: all } = reg.todos.getState() as Todos);
  console.log("assign", done, all.length);
  const snapshot = { ...(reg.todos.getState() as Todos), extra: true };
  console.log("spread", JSON.stringify(snapshot), Object.keys(snapshot).join(","));
  off();
  reg.todos.dispatch({ type: "done" });
  console.log("listeners", reg.todos.listeners.length, seen.join(","), reg.todos.log.join(","));
  reg.todos.listeners.push(await Promise.resolve(onChange));
  reg.todos.dispatch({ type: "filter", payload: "x" });
  console.log("filter", JSON.stringify(reg.todos.getState()), seen.join(","), reg.reads);
  const nums: Store<any> = new Store<number[]>([1], (s, a) => [...s, Number(a.payload)]);
  nums.dispatch({ type: "push", payload: 2 });
  try { const [first, ...others] = nums.getState(); console.log("nums", first, others); } catch (e) { console.log("nums", (e as Error).name); }
}
main();
