// Destructuring assignments with rest elements from Box<any> members: top level, nested, with defaults, array patterns
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  rows: { name: string; tags: T[] }[] = [this.meta];
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => { try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); } };
function forms(b: Box<any>): void {
  t("rest assign", () => { let r: { tags: any[] } = { tags: [] }; let name = ""; ({ name, ...r } = b.meta); r.tags.push("a"); return r.tags.length; });
  t("nested rest", () => { let r: { tags: any[] } = { tags: [] }; let name = ""; ({ meta: { name, ...r } } = b); r.tags.push("n"); return r.tags.length; });
  t("default", () => { let r: { tags: any[] } = { tags: [] }; let name = ""; ({ meta: { name, ...r } = { name: "d", tags: [] } } = b); r.tags.push("d"); return r.tags.length; });
}
const anyBox = new Box<any>(0);
forms(anyBox);
console.log("any", JSON.stringify(anyBox.meta.tags));
const numBox = new Box<number>(0);
forms(numBox);
console.log("number", JSON.stringify(numBox.meta.tags));
