// A rest of the narrowing itself (`const { v, ...r } = o` for an `object` source), Box with an array field, read only.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function run(o: object): number {
  if (!(o instanceof Box)) return -1;
  const { v, ...r } = o;
  return r.items.length;
}
const a = new Box<any>(0); a.items.push(1);
console.log(run(a), run(new Box<number>(1)));
