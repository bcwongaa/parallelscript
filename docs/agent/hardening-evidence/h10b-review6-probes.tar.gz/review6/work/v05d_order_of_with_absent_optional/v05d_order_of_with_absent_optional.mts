// OrderOf from a dynamic first spread whose object lacks an optional key, with later parts
// adding it: JS lists the first object's own keys, then the new ones.
type Meta = { name: string; opt?: string; count: number };
class Box<T> {
  meta: Meta = { count: 1, name: "m" };
  full: Meta = { opt: "o", count: 2, name: "f" };
  constructor(public v: T) {}
}
const b = new Box<any>(0);
console.log(JSON.stringify({ ...b.meta }), Object.keys({ ...b.meta }).join(","));
console.log(JSON.stringify({ ...b.meta, ...b.full }), Object.keys({ ...b.meta, ...b.full }).join(","));
console.log(JSON.stringify({ ...b.full, ...b.meta }), Object.keys({ ...b.full, ...b.meta }).join(","));
console.log(JSON.stringify({ ...b.meta, opt: "late" }), Object.keys({ ...b.meta, opt: "late" }).join(","));
const typed: Meta = { count: 1, name: "t" };
const typedFull: Meta = { opt: "o", count: 2, name: "tf" };
console.log("typed", JSON.stringify({ ...typed, ...typedFull }), JSON.stringify({ ...typed, opt: "late" }));
