// A rest of the narrowing itself, Box with scalar fields only.
class Box<T> {
  label = "l";
  constructor(public v: T) {}
}
function run(o: object): string {
  if (!(o instanceof Box)) return "";
  const { v, ...r } = o;
  return JSON.stringify(r);
}
console.log(run(new Box<any>(0)), run(new Box<number>(1)));
