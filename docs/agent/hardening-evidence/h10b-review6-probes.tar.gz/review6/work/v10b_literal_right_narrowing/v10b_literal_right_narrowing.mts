// A destructuring assignment whose right side is an object literal holding a narrowing's array.
class Box<T> {
  items: T[] = [];
  constructor(public v: T) {}
}
function run(o: object): number {
  if (!(o instanceof Box)) return -1;
  let a: any[] = []; let n = 0;
  ({ a, n } = { a: o.items, n: 1 });
  a.push(2);
  return a.length;
}
const ab = new Box<any>(0);
console.log(run(ab), JSON.stringify(ab.items));
