// patternSource edge cases with a Box<number> in a Box<any> place (as-is TypeError expected
// wherever a copy would hide writes) and a Box<any> (shared): a for…of assignment pattern,
// a nested array pattern, a callback parameter, a parameter default, a chained assignment,
// a for-let initializer, a nested declaration default, a for…of declaration.
class Box<T> {
  meta: { name: string; tags: T[] } = { name: "m", tags: [] };
  metas: { name: string; tags: T[] }[] = [this.meta];
  constructor(public v: T) {}
}
type Meta = { name: string; tags: any[] };
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>, tag: string): void {
  t("callback", () => { b.metas.forEach(({ name, ...r }) => { r.tags.push(tag + 4); }); return b.meta.tags.length; });
  t("param default", () => { const f = ({ name, ...r }: Meta = b.meta) => { r.tags.push(tag + 5); return r.tags.length; }; return f(); });
  t("chained", () => { let x: Meta = { name: "", tags: [] }; let r: { tags: any[] } = { tags: [] }; let name = ""; ({ name, ...r } = x = b.meta); r.tags.push(tag + 6); return r.tags.length; });
  t("for-let", () => { let n = 0; for (let { name, ...r } = b.meta; n < 1; n++) r.tags.push(tag + 7); return n; });
  t("decl nested default", () => { const { meta: { name, ...r } = { name: "d", tags: [] } } = b; r.tags.push(tag + 8); return r.tags.length; });
  t("for-of decl", () => { for (const { name, ...r } of b.metas) r.tags.push(tag + 9); return 0; });
}
const nb = new Box<number>(0);
forms(nb, "n");
console.log("number", JSON.stringify(nb.meta.tags));
const ab = new Box<any>(0);
forms(ab, "a");
console.log("any", JSON.stringify(ab.meta.tags));
