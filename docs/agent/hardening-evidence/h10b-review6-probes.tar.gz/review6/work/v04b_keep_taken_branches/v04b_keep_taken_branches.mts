// v04's short-circuit and conditional forms with the branch taken, and `yield` forms: the
// root runs once, in order, and the function stored keeps its identity.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  handler: ((rows: T[]) => void) | null = null;
}
const order: string[] = [];
const e = new Emitter<any>();
function busOf(tag: string): Emitter<any> { order.push(tag); return e; }
function log(rows: any[]): void { rows.push(1); }
const p = <X>(x: X): Promise<X> => { order.push("await"); return Promise.resolve(x); };
function show(name: string, v: unknown): void { console.log(name, JSON.stringify(v), e.handlers.indexOf(log), order.join(",")); order.length = 0; e.handlers.length = 0; }
async function main(flag: boolean): Promise<void> {
  show("&& true", flag && busOf("a").handlers.push(await p(log)));
  show("?: true", flag ? busOf("b").handlers.push(await p(log)) : 0);
  show("|| false", !flag || busOf("c").handlers.push(await p(log)));
  show("nested", flag && (flag ? busOf("d").handlers.push(await p(log)) : 0));
}
function* gen(flag: boolean): Generator<number, void, (rows: any[]) => void> {
  show("yield &&", flag && busOf("y1").handlers.push(yield 1));
  show("yield ?:", flag ? busOf("y2").handlers.push(yield 2) : 0);
  busOf("y3").handler = flag ? (yield 3) : null;
  show("yield store", e.handler === log);
}
const it = gen(true); it.next(); it.next(log); it.next(log); it.next(log);
main(true);
