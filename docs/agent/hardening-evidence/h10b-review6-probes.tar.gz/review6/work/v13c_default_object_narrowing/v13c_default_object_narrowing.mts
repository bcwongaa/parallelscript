// A destructuring assignment with a default from an `object` narrowing (D-218's PTS1001 expected, as without the default).
class Box<T> {
  opt?: T[];
  constructor(public v: T) {}
}
function run(o: object): number {
  if (!(o instanceof Box)) return -1;
  let opt: any[] = [];
  ({ opt = [] } = o);
  opt.push(1);
  return opt.length;
}
const n = new Box<number>(0); n.opt = [];
console.log(run(n), JSON.stringify(n.opt));
