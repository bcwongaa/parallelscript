// keep's new keepAnyInstanceRoot for other suspension forms: a C<any> root inside an operand
// before an `await` in short-circuits and conditionals (must not run when the branch isn't
// taken), templates, spreads, comparisons, arguments, compound and logical assignments.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  count = 0;
  handler: ((rows: T[]) => void) | null = null;
  cfg = { a: 1, b: 2 };
}
const order: string[] = [];
const e = new Emitter<any>();
function busOf(tag: string): Emitter<any> { order.push(tag); return e; }
function log(rows: any[]): void { rows.push(1); }
const p = <X>(x: X): Promise<X> => { order.push("await"); return Promise.resolve(x); };
function other(tag: string): number { order.push(tag); return 0; }
function show(name: string, v: unknown): void { console.log(name, JSON.stringify(v), order.join(",")); order.length = 0; }
async function main(flag: boolean, nothing: number | null): Promise<void> {
  show("&& false", flag && busOf("a").handlers.push(await p(log)));
  show("|| true", !flag || busOf("b").handlers.push(await p(log)));
  show("?: false", flag ? busOf("c").handlers.push(await p(log)) : 0);
  show("?? set", (nothing ?? 5) || busOf("d").handlers.push(await p(log)));
  show("template", `${busOf("e").handlers.length} ${other("f")} ${await p(1)}`);
  show("spread", [...busOf("g").handlers, await p(log)].length);
  show("object spread", { ...busOf("h").cfg, x: await p(3) });
  show("compare", busOf("i").handlers.length === (await p(0)));
  show("args", Math.max(busOf("j").count, other("k"), await p(2)));
  busOf("l").count += await p(4);
  show("+=", e.count);
  busOf("m").handler ??= await p(log);
  show("??=", e.handler === log);
  busOf("n").handler &&= await p(log);
  show("&&=", e.handler === log);
  show("chain", busOf("o").handlers.concat([]).push(await p(log)));
}
main(false, null);
