// Kept roots with a suspension in more shapes: two levels below the root, an element-access
// callee, an optional chain, a root that is the receiver, a getter root with `yield`.
class Emitter<T> {
  handlers: ((rows: T[]) => void)[] = [];
  cfg: { list: ((rows: T[]) => void)[] } = { list: [] };
  on(h: (rows: T[]) => void, tag?: unknown): number { this.handlers.push(h); return this.handlers.length; }
}
const order: string[] = [];
const e = new Emitter<any>();
class Svc {
  get bus(): Emitter<any> { order.push("get"); return e; }
  get maybe(): Emitter<any> | undefined { order.push("maybe"); return e; }
}
const svc = new Svc();
function log(rows: any[]): void { rows.push(1); }
const p = <X>(x: X): Promise<X> => { order.push("await"); return Promise.resolve(x); };
function show(name: string): void { console.log(name, e.handlers.indexOf(log), e.cfg.list.indexOf(log), order.join(",")); order.length = 0; e.handlers.length = 0; e.cfg.list.length = 0; }
async function main(): Promise<void> {
  svc.bus.cfg.list.push(await p(log)); show("two deep");
  svc.bus.on(log, await p("t")); show("receiver");
  svc.bus.on(await p(log)); show("receiver fn");
  (svc.bus).handlers.push(await p(log)); show("parenthesized");
  svc.bus!.handlers.push(await p(log)); show("non-null");
}
function* gen(): Generator<number, void, (rows: any[]) => void> {
  svc.bus.cfg.list.push(yield 1); show("yield two deep");
  svc.bus.handlers[0] = yield 2; show("yield store");
}
const it = gen(); it.next(); it.next(log); it.next(log);
main();
