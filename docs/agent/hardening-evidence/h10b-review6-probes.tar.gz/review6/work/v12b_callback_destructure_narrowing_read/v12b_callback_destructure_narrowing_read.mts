// The same with a plain destructuring parameter, only read.
class Box<T> {
  metas: { name: string; tags: T[] }[] = [{ name: "m", tags: [] }];
  constructor(public v: T) {}
}
function run(o: object): void {
  if (!(o instanceof Box)) return;
  o.metas.forEach(({ name, tags }) => console.log(name, tags.length));
}
run(new Box<number>(0));
