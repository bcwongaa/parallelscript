// A spread of the narrowing itself, Box with scalar fields only, and of a scalar member object.
class Box<T> {
  label = "l";
  info = { a: 1, b: "x" };
  constructor(public v: T) {}
}
function run(o: object): string {
  if (!(o instanceof Box)) return "";
  return JSON.stringify({ ...o }) + JSON.stringify({ ...o.info, c: true });
}
console.log(run(new Box<any>(0)), run(new Box<number>(1)));
