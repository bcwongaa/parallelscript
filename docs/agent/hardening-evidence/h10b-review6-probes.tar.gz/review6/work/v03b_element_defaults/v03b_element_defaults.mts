// Defaults in patterns over a Box<any> place's value whose member is absent, so the default
// (a fresh literal) is what the rest or the name takes: as-is must not reject a fresh object.
class Box<T> {
  meta?: { name: string; tags: T[] };
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).message); }
};
const fallback = () => ({ name: "d", tags: [] as any[] });
function forms(b: Box<any>): void {
  t("assign default rest", () => { let r: { tags: any[] } = { tags: [] }; let name = ""; ({ meta: { name, ...r } = fallback() } = b); r.tags.push(1); return [name, r.tags]; });
  t("assign default member", () => { let tags: any[] = []; ({ meta: { tags } = fallback() } = b); tags.push(2); return tags; });
  t("decl default rest", () => { const { meta: { name, ...r } = fallback() } = b; r.tags.push(3); return [name, r.tags]; });
  t("decl default member", () => { const { meta: { tags } = fallback() } = b; tags.push(4); return tags; });
  t("decl default typed", () => { const { meta: { tags } = { name: "x", tags: [5] } } = b; tags.push(6); return tags; });
}
forms(new Box<number>(0));
forms(new Box<any>(0));
