// A rest pattern in a callback's parameter over a narrowing's container, only read (D-218
// lets a callback written in place take a copy at a parameter it only reads).
class Box<T> {
  metas: { name: string; tags: T[] }[] = [{ name: "m", tags: [] }];
  constructor(public v: T) {}
}
function run(o: object): void {
  if (!(o instanceof Box)) return;
  o.metas.forEach(({ name, ...r }) => console.log(name, r.tags.length));
}
run(new Box<number>(0));
