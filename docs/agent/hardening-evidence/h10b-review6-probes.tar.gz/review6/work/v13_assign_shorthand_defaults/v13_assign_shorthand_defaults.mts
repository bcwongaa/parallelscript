// Shorthand and renamed destructuring assignments with defaults (assignShorthand's new rule
// after withDefault): the member present or absent, for Box<any> and Box<number> objects.
class Box<T> {
  opt?: T[];
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>, tag: string): void {
  t("shorthand default", () => { let opt: any[] = []; ({ opt = [] } = b); opt.push(tag + 1); return opt.length; });
  t("renamed default", () => { let o: any[] = []; ({ opt: o = [] } = b); o.push(tag + 2); return o.length; });
}
const a = new Box<any>(0); forms(a, "a-absent"); a.opt = []; forms(a, "a");
const n = new Box<number>(0); forms(n, "n-absent"); n.opt = []; forms(n, "n");
console.log(JSON.stringify(a.opt), JSON.stringify(n.opt));
