#!/bin/bash
# emit-c a program with snapshot 6's and snapshot 8's CLI; record exit codes, C sizes and whether the C or errors differ.
f="$1"; out=/tmp/h10b/review6/sweep/out; mkdir -p "$out"
id=$(echo "$f" | sed 's#^/tmp/h10b/snap8/##; s#/#__#g')
PTS_HOME=/tmp/h10b/snap6 timeout 180 /tmp/h10b/snap6/pts-bin/pts emit-c "$f" > "$out/$id.old.c" 2> "$out/$id.old.err"; eo=$?
PTS_HOME=/tmp/h10b/snap8 timeout 180 /tmp/h10b/snap8/pts-bin/pts emit-c "$f" > "$out/$id.new.c" 2> "$out/$id.new.err"; en=$?
sed -i 's#/tmp/h10b/[a-z0-9]*/##g' "$out/$id.old.err" "$out/$id.new.err"
sed -i 's#/tmp/h10b/snap[0-9]/##g' "$out/$id.old.c" "$out/$id.new.c"
lo=$(wc -l < "$out/$id.old.c"); ln=$(wc -l < "$out/$id.new.c")
if cmp -s "$out/$id.old.c" "$out/$id.new.c" && cmp -s "$out/$id.old.err" "$out/$id.new.err" && [ $eo = $en ]; then same=1; rm -f "$out/$id".*; else same=0; fi
echo "$id $eo $en $lo $ln $same"
