#!/bin/bash
# bisect.sh file.pts : emit-c with fix, print first line of errors
PTS_HOME=/home/bryan/projects/parallelscript /tmp/h10/pts-fix1 emit-c "$1" -o /tmp/h10/review1/w/out.c 2>&1 | head -3
