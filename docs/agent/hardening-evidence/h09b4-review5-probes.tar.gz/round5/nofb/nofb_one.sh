#!/bin/bash
# nofb_one.sh file.pts -> "name|snap8 AllInstances result|snap9 AllInstances result" (no fallback)
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap9/pts/tests/||; s|/|__|g; s|.pts$||')
a=$(PTS_HOME=/tmp/h09b4/snap8 timeout 120 /tmp/h09b4/review/round4/nofb/nofb-snap8 all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
b=$(PTS_HOME=/tmp/h09b4/snap9 timeout 120 /tmp/h09b4/review/round5/nofb/nofb-snap9 all "$f" 2>&1 | head -c 300 | tr '\n|' '  ')
echo "$n|$a|$b"
