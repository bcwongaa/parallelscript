// ptsnofb emits C with one specialization and no fallback: ptsnofb all|value|declared file.pts
package main

import (
	"context"
	"fmt"
	"os"
	"strings"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

func main() {
	specs := map[string]lower.Specialization{"all": lower.AllInstances, "value": lower.ValueInstances, "declared": lower.DeclaredInstances}
	code, err := driver.EmitCWith(context.Background(), os.Args[2], specs[os.Args[1]])
	if err != nil {
		fmt.Println("ERROR:", err)
		os.Exit(1)
	}
	fmt.Println("OK lines:", strings.Count(code, "\n"))
}
