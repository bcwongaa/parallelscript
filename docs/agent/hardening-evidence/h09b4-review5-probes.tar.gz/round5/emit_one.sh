#!/bin/bash
# emit_one.sh file.pts -> "relname snap8_exit snap9_exit same|diff"; keeps the C only when it differs
f=$1; n=$(echo $f | sed 's|/tmp/h09b4/snap9/pts/tests/||; s|/|__|g; s|.pts$||')
o=/tmp/h09b4/review/round5/emit
mkdir -p $o
PTS_HOME=/tmp/h09b4/snap8 timeout 120 /tmp/h09b4/snap8/pts-bin/pts emit-c "$f" > $o/$n.snap8.c 2>$o/$n.snap8.err; ae=$?
PTS_HOME=/tmp/h09b4/snap9 timeout 120 /tmp/h09b4/snap9/pts-bin/pts emit-c "$f" > $o/$n.snap9.c 2>$o/$n.snap9.err; be=$?
if cmp -s <(sed 's|/tmp/h09b4/snap8/|/SNAP/|g' $o/$n.snap8.c) <(sed 's|/tmp/h09b4/snap9/|/SNAP/|g' $o/$n.snap9.c); then
  same=same
  rm -f $o/$n.snap8.c $o/$n.snap9.c $o/$n.snap8.err $o/$n.snap9.err
else
  same=diff
fi
echo "$n $ae $be $same"
