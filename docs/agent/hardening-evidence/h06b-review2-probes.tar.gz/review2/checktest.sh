#!/bin/bash
# usage: checktest.sh test.pts -> compares the expect block to node and new pts output
f="$1"; n=$(basename "$f" .pts); d=/tmp/h06b/review2/tests; mkdir -p $d
awk '/^\/\/ expect:/{p=1;next} p && /^\/\/ ?/{sub(/^\/\/ ?/,""); print; next} p{p=0}' "$f" > $d/$n.expect
cp "$f" $d/$n.mts
args=""; grep -q "experimental-transform-types\|constructor(public\|constructor(private\|constructor(readonly" "$f" && args="--experimental-transform-types"
(cd $d && $HOME/.local/node/bin/node $args $n.mts > $n.node 2>&1)
PTS_HOME=/tmp/h06b-review2 timeout 120 /tmp/h06b-review2/pts-bin/pts run "$f" > $d/$n.pts.out 2>&1; echo "pts exit $?" > $d/$n.pts.exit
printf "%-40s node-vs-expect: " $n; diff -q $d/$n.expect $d/$n.node >/dev/null && printf "SAME " || printf "DIFF "
printf " pts-vs-expect: "; diff -q $d/$n.expect $d/$n.pts.out >/dev/null && echo SAME || echo DIFF
