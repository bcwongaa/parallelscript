const fs: ((x: number) => number)[] = [(x) => x * 2, (x) => x + 1];
const k = fs.findIndex((f: ((x: number) => unknown) | undefined) => f !== undefined && f(1) === 2);
console.log(k);
