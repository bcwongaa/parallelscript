const os: { x: number }[] = [{ x: 1.5 }];
os.findIndex((o: { x: number | string } | undefined) => {
  if (o !== undefined) {
    console.log(typeof o.x, o.x);
    o.x = "str";
  }
  return false;
});
console.log(os[0].x + 1, typeof os[0].x);
class K { v: number; constructor(v: number) { this.v = v; } }
const ks: K[] = [new K(2.5)];
ks.findIndex((o: { v: number | string } | undefined) => {
  if (o !== undefined) o.v = "s";
  return false;
});
console.log(ks[0].v * 2);
