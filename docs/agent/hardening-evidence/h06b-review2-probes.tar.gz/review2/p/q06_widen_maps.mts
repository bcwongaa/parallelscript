const ms: Map<string, number>[] = [new Map([["a", 1.5]])];
console.log(ms.findIndex((m: Map<string, unknown> | undefined) => m !== undefined && m.get("a") === 1.5));
const out = Array.from(ms, (m: Map<string, unknown> | undefined) => (m === undefined ? "none" : String(m.get("a"))));
console.log(out);
