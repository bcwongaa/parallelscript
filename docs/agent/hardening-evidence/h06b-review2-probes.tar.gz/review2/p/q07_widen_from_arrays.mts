const xs: number[][] = [[1.5], [2.5, 3.5]];
console.log(Array.from(xs, (a: (number | string)[] | undefined) => (a === undefined ? -1 : a.length + ":" + a[0])));
