// A number[][] searched with a callback whose parameter is a wider array type (TS allows it).
const xs: number[][] = [[1.5, 2.5], [3]];
const i = xs.findIndex((a: (number | string)[] | undefined) => {
  if (a === undefined) return false;
  console.log("elem", a[0], typeof a[0]);
  return a.length === 1;
});
console.log(i);
