const nested: string[][] = [["a"], ["bb"]];
nested.findIndex((s: (string | undefined)[] | undefined) => {
  if (s !== undefined) s.push(undefined);
  return false;
});
for (const row of nested) {
  for (const w of row) console.log(w.length);
}
