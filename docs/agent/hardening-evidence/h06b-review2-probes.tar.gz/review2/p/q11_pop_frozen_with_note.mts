const a = new Array<string>(2);
Object.freeze(a);
try { console.log(a.pop()); } catch (e) { console.log("threw", (e as Error).name, (e as Error).message); }
try { console.log(a.shift()); } catch (e) { console.log("threw", (e as Error).name, (e as Error).message); }
console.log(a.length);
