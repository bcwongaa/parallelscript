interface I { x: number; name: string }
class C {
  name: string;
  x: number;
  constructor() { this.name = "c"; this.x = 0; }
}
const is: I[] = [{ x: 1, name: "one" }, { x: 2, name: "two" }];
console.log(is.findIndex((c: C | undefined) => c !== undefined && c.x === 2 && c.name === "two"));
