class Base {
  name: string;
  constructor(name: string) { this.name = name; }
  hello(): string { return "base " + this.name; }
}
class Sub extends Base {
  extra: number;
  constructor(name: string, extra: number) { super(name); this.extra = extra; }
  hello(): string { return "sub " + this.name + this.extra; }
}
const subs: Sub[] = [new Sub("a", 1), new Sub("b", 2)];
console.log(subs.findIndex((b: Base | undefined) => b !== undefined && b.hello() === "sub b2"));
console.log(subs.find((b: Base | undefined) => b?.name === "a"));
interface Named { name: string }
console.log(subs.findIndex((n: Named | undefined) => n?.name === "b"));
console.log(subs.findIndex((n: { name: string } | undefined) => n !== undefined && n.name === "b"));
interface Full { name: string; age: number; tags: string[] }
const people: Full[] = [{ name: "x", age: 3, tags: ["t"] }, { name: "y", age: 4, tags: [] }];
console.log(people.findIndex((p: { age: number } | undefined) => p !== undefined && p.age === 4));
console.log(people.findLastIndex((p: Named | undefined) => p?.name === "x"));
const ro: number[][] = [[1], [2, 3]];
console.log(ro.findIndex((r: readonly number[] | undefined) => r !== undefined && r.length === 2));
const sets: Set<number>[] = [new Set([1])];
console.log(sets.findIndex((s: ReadonlySet<number> | undefined) => s !== undefined && s.has(1)));
const nested: string[][] = [["a"]];
console.log(nested.findIndex((s: (string | undefined)[] | undefined) => s !== undefined && s[0] === "a"));
console.log(Array.from(subs, (b: Base | undefined) => b?.hello()));
