function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 70)); }
}
const ws: string[] = ["abc", "de"];
show("length shape", () => ws.findIndex((x: { length: number } | undefined) => x?.length === 2));
show("forEach length shape", () => { const out: number[] = []; ws.forEach((x: { length: number } | undefined) => out.push(x?.length ?? -1)); return out; });
show("empty obj", () => ws.some((x: {} | undefined) => x === undefined));
show("iterable", () => ws.findIndex((x: Iterable<string> | undefined) => x !== undefined));
