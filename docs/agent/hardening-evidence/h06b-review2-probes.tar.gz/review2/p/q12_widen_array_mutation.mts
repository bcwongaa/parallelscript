const xs: number[][] = [[1.5], [2.5]];
xs.findIndex((a: (number | string)[] | undefined) => {
  if (a !== undefined) a.push("str");
  return false;
});
console.log(xs);
const total = xs[0].reduce((s, v) => s + v, 0);
console.log(total);
