const ts: [number, string][] = [[1, "a"], [2, "b"]];
const j = ts.findIndex((t: (number | string)[] | undefined) => t !== undefined && t.length === 2 && t[1] === "b");
console.log(j);
