const fs: ((x: number) => number)[] = [(x) => x * 2];
fs.find((f: ((x: number) => unknown) | undefined) => {
  if (f !== undefined) {
    const r = f(21);
    console.log(typeof r, r);
    console.log(String(r));
  }
  return false;
});
const hs: ((x: string) => number)[] = [(s) => s.length];
hs.findIndex((h: ((x: string) => unknown) | undefined) => {
  if (h !== undefined) {
    const r = h("abc");
    console.log(typeof r, r);
  }
  return false;
});
