const rows: number[][] = [[1.5, 2], [3]];
const i = rows.findIndex((r: unknown[] | undefined) => r !== undefined && String(r[0]) === "3");
console.log(i);
const j = rows.findIndex((r: readonly unknown[] | undefined) => r !== undefined && typeof r[0] === "number" && r.length === 1);
console.log(j);
