const ms: Map<string, number>[] = [new Map([["a", 1.5]])];
ms.findIndex((m: Map<string, unknown> | undefined) => {
  m?.set("b", "a string");
  return false;
});
console.log(ms);
let sum = 0;
for (const v of ms[0].values()) sum += v;
console.log(sum);
