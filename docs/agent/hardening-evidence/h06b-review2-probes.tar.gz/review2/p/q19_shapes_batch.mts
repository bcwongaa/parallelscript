function show(label: string, f: () => unknown): void {
  try { console.log(label, f()); } catch (e) { console.log(label, "threw", (e as Error).name, (e as Error).message.slice(0, 60)); }
}
class Base { name: string; constructor(n: string) { this.name = n; } }
class Sub extends Base { k: number; constructor(n: string, k: number) { super(n); this.k = k; } }
const subs: Sub[] = [new Sub("a", 1), new Sub("b", 2)];
const tuples: [number, string][] = [[1, "a"], [2, "b"]];
const ro: readonly string[] = ["x", "yy"];
const nul: (string | null)[] = [null, "s"];
type Lit = "a" | "b";
const lits: Lit[] = ["a", "b"];
show("sub find! base param", () => subs.find((b: Base | undefined) => b?.name === "b")!.k);
show("tuple find same", () => tuples.find((t: [number, string] | undefined) => t?.[0] === 2)!);
show("tuple filter", () => tuples.filter((t: [number, string] | undefined) => t !== undefined && t[1] === "a"));
show("tuple unknown find!", () => tuples.find((t: unknown) => Array.isArray(t))!);
show("ro filter", () => ro.filter((x: string | undefined) => x !== "x"));
show("ro find!", () => ro.find((x: string | undefined) => (x ?? "").length > 1)!);
show("nul find null-undef", () => nul.findIndex((x: string | null | undefined) => x === null));
show("lits find!", () => lits.find((x: Lit | undefined) => x === "b")!);
show("lits reduce", () => lits.reduce((a: Lit, x: Lit | undefined) => (x === "b" ? x : a)));
show("any param objects find!", () => subs.find((x: any) => x.k === 2)!.name);
show("unknown reduce", () => subs.reduce((a: Sub, x: unknown) => (x instanceof Sub && x.k > a.k ? x : a)).k);
show("string union number", () => ["1", "22"].find((x: string | number | undefined) => String(x).length === 2)!);
show("map from unknown", () => Array.from(tuples, (t: unknown) => Array.isArray(t)));
show("map from union", () => Array.from(subs, (b: Base | undefined) => b?.name));
show("forEach union strings", () => { const out: string[] = []; ["a"].forEach((x: string | undefined) => out.push(x ?? "u")); return out; });
show("flatMap union strings", () => ["a", "b"].flatMap((x: string | undefined) => [x ?? "u", "!"]));
const fnArr: (() => number)[] = [() => 1];
show("fn same type find", () => fnArr.find((f: (() => number) | undefined) => f !== undefined && f() === 1)!());
show("fn unknown find", () => fnArr.findIndex((f: unknown) => typeof f === "function"));
