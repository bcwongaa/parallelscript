class A {
  tag: string;
  x: number;
  constructor() { this.tag = "A"; this.x = 1; }
}
class B {
  x: number;
  tag: string;
  extra: number[];
  constructor(x: number) { this.x = x; this.tag = "B"; this.extra = [x]; }
}
const bs: B[] = [new B(5), new B(7)];
const k = bs.findIndex((a: A | undefined) => a !== undefined && a.x === 7 && a.tag.length === 1);
console.log(k);
const found = bs.find((a: A | undefined) => a !== undefined && a.tag === "B");
console.log(found);
