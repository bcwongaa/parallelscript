const ts: [number, string][] = [[1, "a"], [2, "b"]];
ts.find((t: (number | string)[] | undefined) => {
  if (t !== undefined) {
    console.log(t.length, t[0], t[1]);
    t.push("x");
  }
  return false;
});
console.log(ts);
