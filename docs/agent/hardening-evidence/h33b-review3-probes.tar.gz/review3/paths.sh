#!/bin/bash
# Runs every closing scenario under TLS 1.2 and 1.3 against snapshot 2's and snapshot 3's servers.
D=/tmp/h33b/review3
start() { # $1 = snapshot; sets pid and port
  CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 taskset -c ${CPUS:-0,1} $D/srv/s.$1 > $D/srv/s.out 2> $D/srv/s.err &
  pid=$!
  for i in $(seq 1 100); do grep -q '^port' $D/srv/s.out 2>/dev/null && break; sleep 0.05; done
  port=$(awk '/^port/{print $2}' $D/srv/s.out)
}
for v in snap2 snap3; do
  GOMAXPROCS=2 taskset -c 0,1 /tmp/h33b/$v/pts-bin/pts build $D/srv/probe_server.pts -o $D/srv/s.$v >/dev/null || exit 1
  echo "===== $v"
  start $v
  for s in close-response http10 400 413 431 notify-idle notify-busy notify-busy-close close-and-notify-at-once 400-and-notify-at-once fail-after-close 400-then-garbage-at-once; do
    for t in 1.2 1.3; do $D/cnpaths/cnpaths 127.0.0.1:$port $s $t; done
  done
  kill $pid; wait $pid 2>/dev/null
  echo "server stderr: $(wc -c < $D/srv/s.err) bytes"
  for t in 1.2 1.3; do start $v; $D/cnpaths/cnpaths 127.0.0.1:$port stop-idle $t; wait $pid; echo "  (server exit $?)"; done
done
rm -f $D/srv/s.snap2 $D/srv/s.snap3
