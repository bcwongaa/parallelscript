#!/bin/bash
# Repeats the scenarios whose two writes may or may not be read together, 10 times each, on both snapshots.
D=/tmp/h33b/review3
for v in snap2 snap3; do
  GOMAXPROCS=2 taskset -c 0,1 /tmp/h33b/$v/pts-bin/pts build $D/srv/probe_server.pts -o $D/srv/s.$v >/dev/null || exit 1
  CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 taskset -c 0,1 $D/srv/s.$v > $D/srv/s.out 2> $D/srv/s.err &
  pid=$!
  for i in $(seq 1 100); do grep -q '^port' $D/srv/s.out 2>/dev/null && break; sleep 0.05; done
  port=$(awk '/^port/{print $2}' $D/srv/s.out)
  for s in 400-then-garbage-at-once close-and-notify-at-once 400-and-notify-at-once; do
    for t in 1.2 1.3; do
      echo "$v $s TLS $t: $(for i in $(seq 1 10); do $D/cnpaths/cnpaths 127.0.0.1:$port $s $t | sed 's/.*: \([0-9]*\) records, \([0-9]*\) plaintext.*/\1r\/\2a/'; done | sort | uniq -c | tr '\n' ' ')"
    done
  done
  kill $pid; wait $pid 2>/dev/null; rm -f $D/srv/s.$v
done
