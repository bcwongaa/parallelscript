module cnpaths

go 1.26
