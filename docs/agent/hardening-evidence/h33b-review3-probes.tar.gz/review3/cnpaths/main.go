// For each path that ends an HTTPS connection, lists the TLS records the server sends after the
// scenario starts (type(length)), and how TCP ends. Usage: cnpaths <addr> <scenario> <1.2|1.3>
package main

import (
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"os"
	"strings"
	"sync"
	"syscall"
	"time"
)

type tap struct {
	net.Conn
	mu  sync.Mutex
	raw []byte
}

func (t *tap) Read(p []byte) (int, error) {
	n, err := t.Conn.Read(p)
	t.mu.Lock()
	t.raw = append(t.raw, p[:n]...)
	t.mu.Unlock()
	return n, err
}

func dial(addr string, v uint16) (net.Conn, *tap, *tls.Conn) {
	tcp, err := net.Dial("tcp", addr)
	if err != nil {
		fmt.Println("dial:", err)
		os.Exit(1)
	}
	tp := &tap{Conn: tcp}
	c := tls.Client(tp, &tls.Config{InsecureSkipVerify: true, MinVersion: v, MaxVersion: v})
	if err := c.Handshake(); err != nil {
		fmt.Println("handshake:", err)
		os.Exit(1)
	}
	return tcp, tp, c
}

func main() {
	addr, scenario := os.Args[1], os.Args[2]
	v := uint16(tls.VersionTLS12)
	if os.Args[3] == "1.3" {
		v = tls.VersionTLS13
	}
	tcp, tp, c := dial(addr, v)
	tp.mu.Lock()
	start := len(tp.raw)
	tp.mu.Unlock()
	switch scenario {
	case "close-response": // an answer that closes its connection
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n"))
	case "http10":
		c.Write([]byte("GET /hello HTTP/1.0\r\n\r\n"))
	case "400":
		c.Write([]byte("NOT HTTP\r\n\r\n"))
	case "413":
		c.Write([]byte("POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: 100000000\r\n\r\n"))
	case "431":
		const s = "GET /hello HTTP/1.1\r\nHost: a\r\nX-Long: "
		c.Write([]byte(s + strings.Repeat("a", 64*1024+1-len(s))))
	case "notify-idle": // the client's close_notify on an idle keep-alive connection
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(200 * time.Millisecond)
		c.CloseWrite()
	case "notify-busy": // the client's close_notify while its request is held by the program
		c.Write([]byte("GET /hold HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(200 * time.Millisecond)
		c.CloseWrite()
	case "notify-busy-close": // close_notify while a Connection: close answer is still being written
		c.Write([]byte("GET /bigclose?3000000 HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(100 * time.Millisecond)
		c.CloseWrite()
	case "close-and-notify-at-once": // R2-F1: a closing request and close_notify read together
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n"))
		c.CloseWrite()
	case "400-and-notify-at-once":
		c.Write([]byte("NOT HTTP\r\n\r\n"))
		c.CloseWrite()
	case "fail-after-close": // the server answered with close_notify; the client then sends a corrupt record
		c.Write([]byte("GET /sleep?150 HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n"))
		time.Sleep(20 * time.Millisecond)
		tcp.Write([]byte("\x17\x03\x03\x00\x20" + strings.Repeat("g", 32)))
	case "400-then-garbage-at-once": // a 400 (close_notify) and a corrupt record read together
		c.Write([]byte("NOT HTTP\r\n\r\n"))
		tcp.Write([]byte("\x17\x03\x03\x00\x20" + strings.Repeat("g", 32)))
	case "stop-idle": // an idle keep-alive connection when another client asks the server to stop
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(200 * time.Millisecond)
		_, _, s := dial(addr, v)
		s.Write([]byte("GET /stop HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(200 * time.Millisecond)
	}
	tcp.SetReadDeadline(time.Now().Add(4 * time.Second))
	buf := make([]byte, 65536)
	var end error
	for {
		n, err := tcp.Read(buf)
		tp.mu.Lock()
		tp.raw = append(tp.raw, buf[:n]...)
		tp.mu.Unlock()
		if err != nil {
			end = err
			break
		}
	}
	ending := "FIN"
	if errors.Is(end, syscall.ECONNRESET) {
		ending = "RST"
	} else if end != io.EOF {
		ending = "no end (" + end.Error() + ")"
	}
	tp.mu.Lock()
	raw := tp.raw[start:]
	tp.mu.Unlock()
	types := []string{}
	alerts, total := 0, 0
	for p := raw; len(p) >= 5; {
		l := int(p[3])<<8 | int(p[4])
		total++
		if p[0] == 21 {
			alerts++
		}
		if len(types) < 6 || len(p) <= 5+l+64 {
			types = append(types, fmt.Sprintf("%d(%d)", p[0], l))
		} else if len(types) == 6 {
			types = append(types, "…")
		}
		if len(p) < 5+l {
			break
		}
		p = p[5+l:]
	}
	fmt.Printf("%-26s TLS %s: %d records, %d plaintext alerts, last: %v, then %s\n", scenario, os.Args[3], total, alerts, tail(types), ending)
}

func tail(s []string) []string {
	if len(s) > 4 {
		return s[len(s)-4:]
	}
	return s
}
