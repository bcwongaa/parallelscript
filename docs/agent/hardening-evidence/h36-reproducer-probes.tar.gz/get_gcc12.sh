#!/bin/bash
# GCC 12.3 for aarch64 without root (Ubuntu noble's signed packages), extracted under gcc12/root.
# Its cc1 needs GCC 13's internal headers (stddef.h) and the cross sysroot's: see build_gcc12_variant.sh.
set -euo pipefail
mkdir -p /tmp/pts-h36/repro/gcc12/debs /tmp/pts-h36/repro/gcc12/root
cd /tmp/pts-h36/repro/gcc12/debs
apt-get download gcc-12-aarch64-linux-gnu=12.3.0-17ubuntu1cross1 cpp-12-aarch64-linux-gnu=12.3.0-17ubuntu1cross1 \
  gcc-12-aarch64-linux-gnu-base=12.3.0-17ubuntu1cross1
for deb in *.deb; do dpkg -x "$deb" ../root; done
../root/usr/bin/aarch64-linux-gnu-gcc-12 --version | head -1
