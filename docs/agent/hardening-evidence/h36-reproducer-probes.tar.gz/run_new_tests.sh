#!/bin/bash
# The new regression tests, on the prototype runtime (worktree) and on HEAD's (home_head), for x86-64 and aarch64.
#   usage: run_new_tests.sh OUTFILE
OUT=$1
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a115bda57afdd6198
export GOMAXPROCS=4 PTS_CACHE_DIR=/tmp/pts-h36/repro/cache QEMU_LD_PREFIX=/usr/aarch64-linux-gnu PTS_REQUIRE_CROSS=1
: > "$OUT"
run() { # label, env..., then go test args after --
  local label=$1; shift
  local envs=()
  while [ "$1" != -- ]; do envs+=("$1"); shift; done
  shift
  echo "=== $label: ${envs[*]} go test $*" >> "$OUT"
  env "${envs[@]}" go test -count=1 "$@" >> "$OUT" 2>&1
  echo "exit=$? ($label)" >> "$OUT"
}
T1='TestNumbersPrintAsNodeOfTheProgramsArchitecture'
T2='TestBuildForAarch64LinuxPrintsNumbersAsNodeOnArm64'
run "pts/tests x86 prototype" PTS_X=1 -- -run "$T1" ./pts/tests/
run "pts/tests x86 HEAD" PTS_HOME=/tmp/pts-h36/repro/home_head -- -run "$T1" ./pts/tests/
run "pts/tests aarch64 prototype" PTS_TARGET=aarch64-linux -- -run "$T1" ./pts/tests/
run "pts/tests aarch64 HEAD" PTS_TARGET=aarch64-linux PTS_HOME=/tmp/pts-h36/repro/home_head -- -run "$T1" ./pts/tests/
run "cmd/pts cross prototype" PTS_X=1 -- -run "$T2" ./cmd/pts/
run "cmd/pts cross HEAD" PTS_HOME=/tmp/pts-h36/repro/home_head -- -run "$T2" ./cmd/pts/
