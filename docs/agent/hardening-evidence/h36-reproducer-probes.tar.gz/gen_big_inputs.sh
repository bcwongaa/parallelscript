#!/bin/bash
# 40 more input sets (other seeds) concatenated per function into inputs_big/: 4.8M inputs per function.
set -euo pipefail
cd /tmp/pts-h36/repro
mkdir -p inputs_big inputs_tmp
rm -f inputs_big/*.bin
for seed in $(seq 1 40); do
  python3 -I gen_inputs.py inputs_tmp $seed > /dev/null
  for f in inputs_tmp/*.bin; do
    cat "$f" >> inputs_big/$(basename "$f")
  done
done
rm -rf inputs_tmp
ls -la inputs_big | head -5
echo done
