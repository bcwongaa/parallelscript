#!/bin/bash
# Run every probe under x86-64 Node and arm64 Node (qemu), TZ as the tests set it; report differing lines.
set -uo pipefail
cd /tmp/pts-h36/repro
export TZ=America/New_York
mkdir -p probes/out probes/mjs
for f in probes/*.pts; do
  n=$(basename "$f" .pts)
  cp "$f" probes/mjs/$n.mjs
  /home/bryan/.local/node/bin/node probes/mjs/$n.mjs > probes/out/$n.node_x86.txt 2>&1
  /tmp/pts-h36/arm64-node-bin/node probes/mjs/$n.mjs > probes/out/$n.node_arm64.txt 2>&1
  echo "$n: $(wc -l < probes/out/$n.node_x86.txt) lines, x86 vs arm64 Node differ on $(diff probes/out/$n.node_x86.txt probes/out/$n.node_arm64.txt | grep -c '^<') lines"
done
