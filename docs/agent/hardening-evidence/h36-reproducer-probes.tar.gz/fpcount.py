#!/usr/bin/env python3
"""Count floating-point instructions per function in an aarch64 objdump -d listing.

Usage: fpcount.py LISTING [--names]
Prints, per function, counts of fmadd/fmsub/fnmadd/fnmsub (fused) and fmul/fadd/fsub/fdiv/fnmul.
Function names are normalised: C++ v8::base::ieee754::X(double) and pts_ieee754_X both become X;
helpers keep their own names.
"""
import re
import sys
from collections import Counter, OrderedDict

OPS = ["fmadd", "fmsub", "fnmadd", "fnmsub", "fmul", "fnmul", "fadd", "fsub", "fdiv", "fsqrt"]


def norm(name):
    m = re.search(r"ieee754::(?:\(anonymous namespace\)::)?(?:legacy::)?([A-Za-z0-9_]+)\(", name)
    if m:
        return m.group(1)
    m = re.match(r"pts_ieee754_([A-Za-z0-9_]+)", name)
    if m:
        return m.group(1)
    return name


def main():
    path = sys.argv[1]
    funcs = OrderedDict()
    cur = None
    for line in open(path):
        m = re.match(r"^[0-9a-f]+ <(.+)>:$", line)
        if m:
            cur = norm(m.group(1))
            funcs.setdefault(cur, Counter())
            continue
        if cur is None:
            continue
        m = re.match(r"^\s+[0-9a-f]+:\s+(?:[0-9a-f]{8}\s+)?([a-z0-9.]+)\s+(\S+)", line)
        if not m:
            continue
        op, args = m.group(1), m.group(2)
        if op in OPS and args.startswith("d"):
            funcs[cur][op] += 1
    print("%-22s %6s %6s %6s %6s | %5s %5s %5s %5s %5s" % ("function", "fmadd", "fmsub", "fnmadd", "fnmsub", "fmul", "fnmul", "fadd", "fsub", "fdiv"))
    for f, c in funcs.items():
        if sum(c.values()) == 0:
            continue
        print("%-22s %6d %6d %6d %6d | %5d %5d %5d %5d %5d" % (f, c["fmadd"], c["fmsub"], c["fnmadd"], c["fnmsub"], c["fmul"], c["fnmul"], c["fadd"], c["fsub"], c["fdiv"]))


main()
