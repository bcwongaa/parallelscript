#!/bin/bash
# Run every harness variant (and both Nodes, unless SKIP_NODE=1) over inputs/, results in out/<variant>/.
set -euo pipefail
cd /tmp/pts-h36/repro
export QEMU_LD_PREFIX=/usr/aarch64-linux-gnu
VARIANTS=${VARIANTS:-"a_clang_off b_clang_pragma_fast b2_clang_fast c_clang_on c2_clang_stdc_on d_gcc_O2_fast d_gcc_O3_fast d_gcc_O2_off x_clang_off"}
for v in $VARIANTS; do
  mkdir -p out/$v
  ./bin/$v inputs out/$v
  echo "ran $v"
done
if [ "${SKIP_NODE:-0}" != 1 ]; then
  mkdir -p out/node_arm64 out/node_x86
  /usr/bin/time -f "node_arm64 %es" /tmp/pts-h36/arm64-node-bin/node node_harness.mjs inputs out/node_arm64
  /usr/bin/time -f "node_x86 %es" /home/bryan/.local/node/bin/node node_harness.mjs inputs out/node_x86
  /tmp/pts-h36/arm64-node-bin/node --version
  /home/bryan/.local/node/bin/node --version
  /tmp/pts-h36/arm64-node-bin/node -p process.arch
fi
