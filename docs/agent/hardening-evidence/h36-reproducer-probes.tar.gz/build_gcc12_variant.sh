#!/bin/bash
# Harness linked with the port at HEAD built by GCC 12.3 -O3 -ffp-contract=fast (Node's compiler family and default).
set -euo pipefail
cd /tmp/pts-h36/repro
gcc12/root/usr/bin/aarch64-linux-gnu-gcc-12 -O3 -g -fno-strict-aliasing -ffp-contract=fast -Istub \
  -isystem /usr/lib/gcc-cross/aarch64-linux-gnu/13/include -isystem /usr/aarch64-linux-gnu/include -S src/ieee754_head.c -o gcc12/head_O3_fast.s
aarch64-linux-gnu-as gcc12/head_O3_fast.s -o bin/d12_gcc12_O3_fast.o
clang --target=aarch64-linux-gnu bin/harness_a64.o bin/d12_gcc12_O3_fast.o -lm -o bin/d12_gcc12_O3_fast
echo built
