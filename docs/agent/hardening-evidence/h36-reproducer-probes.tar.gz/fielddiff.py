#!/usr/bin/env python3
"""fielddiff.py A B [PROBE]: for lines that differ between two outputs, count which space-separated
fields differ; with PROBE, print the first few probe statements whose output differs."""
import sys
from collections import Counter

a = open(sys.argv[1]).read().split("\n")
b = open(sys.argv[2]).read().split("\n")
probe = open(sys.argv[3]).read().split("\n") if len(sys.argv) > 3 else None
assert len(a) == len(b), (len(a), len(b))
fields = Counter()
lines = 0
shown = 0
for i, (x, y) in enumerate(zip(a, b)):
    if x == y:
        continue
    lines += 1
    fx, fy = x.split(" "), y.split(" ")
    if len(fx) != len(fy):
        fields["(field count)"] += 1
    else:
        for k, (p, q) in enumerate(zip(fx, fy)):
            if p != q:
                fields[k] += 1
    if probe and shown < 6:
        shown += 1
        print("  " + probe[i][:200])
        print("    A: " + x[:200])
        print("    B: " + y[:200])
print("lines differ:", lines, "by field:", dict(sorted(fields.items(), key=lambda kv: str(kv[0]))))
