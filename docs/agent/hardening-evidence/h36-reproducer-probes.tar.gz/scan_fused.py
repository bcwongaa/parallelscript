#!/usr/bin/env python3
"""scan_fused.py LISTING: every function of an aarch64 objdump -d -C listing that contains fused
multiply-adds on doubles (fmadd/fmsub/fnmadd/fnmsub d...), with the count, sorted by name."""
import re
import sys
from collections import Counter

FUSED = {"fmadd", "fmsub", "fnmadd", "fnmsub"}
counts = Counter()
cur = None
for line in open(sys.argv[1], errors="replace"):
    m = re.match(r"^[0-9a-f]+ <(.+)>:$", line)
    if m:
        cur = m.group(1)
        continue
    m = re.match(r"^\s+[0-9a-f]+:\s+(?:[0-9a-f]{8}\s+)?([a-z0-9.]+)\s+(\S+)", line)
    if m and cur and m.group(1) in FUSED and m.group(2).startswith("d"):
        counts[cur] += 1
for name in sorted(counts):
    print("%4d  %s" % (counts[name], name))
print("functions:", len(counts), "fused instructions:", sum(counts.values()))
