#!/bin/bash
# Build every probe with pts for TARGET (aarch64-linux | x86_64-linux) against the runtime in HOME_DIR,
# run it (aarch64 under qemu), and compare with the Node of that architecture.
#   usage: run_probes_pts.sh TARGET HOME_DIR LABEL
set -uo pipefail
TARGET=$1 HOME_DIR=$2 LABEL=$3
cd /tmp/pts-h36/repro
export TZ=America/New_York QEMU_LD_PREFIX=/usr/aarch64-linux-gnu PTS_CACHE_DIR=/tmp/pts-h36/repro/cache PTS_HOME=$HOME_DIR PTS_TARGET=$TARGET
PTS=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a115bda57afdd6198/pts-bin/pts
NODE=node_x86
[ "$TARGET" = aarch64-linux ] && NODE=node_arm64
mkdir -p probes/bin probes/out
for f in probes/${4:-*}.pts; do
  n=$(basename "$f" .pts)
  if ! $PTS build "$f" -o probes/bin/$n.$LABEL > probes/out/$n.$LABEL.build.txt 2>&1; then
    echo "$n: build failed (probes/out/$n.$LABEL.build.txt)"
    continue
  fi
  ./probes/bin/$n.$LABEL > probes/out/$n.$LABEL.txt 2>&1
  echo "$n [$LABEL]: exit $?, differs from $NODE on $(python3 -I fielddiff.py probes/out/$n.$NODE.txt probes/out/$n.$LABEL.txt | tail -1)"
  rm -f probes/bin/$n.$LABEL
done
