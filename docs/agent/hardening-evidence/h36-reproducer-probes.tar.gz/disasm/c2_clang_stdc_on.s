
bin/c2_clang_stdc_on.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <pts_ieee754_acos>:
       0:	fmov	x8, d0
       4:	lsr	x10, x8, #32
       8:	ubfx	x9, x8, #32, #31
       c:	ubfx	w11, w10, #20, #11
      10:	cmp	w11, #0x3ff
      14:	b.cc	4c <pts_ieee754_acos+0x4c>  // b.lo, b.ul, b.last
      18:	movi	d0, #0x0
      1c:	adrp	x11, 0 <pts_ieee754_acos>
      20:	cmp	w10, #0x0
      24:	ldr	d1, [x11]
      28:	mov	w10, #0xc0100000            	// #-1072693248
      2c:	add	w9, w9, w10
      30:	orr	w8, w9, w8
      34:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
      38:	fcsel	d0, d0, d1, gt
      3c:	fmov	d1, x9
      40:	cmp	w8, #0x0
      44:	fcsel	d0, d0, d1, eq	// eq = none
      48:	ret
      4c:	lsr	w10, w9, #21
      50:	cmp	w10, #0x1fe
      54:	b.hi	74 <pts_ieee754_acos+0x74>  // b.pmore
      58:	mov	w8, #0x1                   	// #1
      5c:	movk	w8, #0x3c60, lsl #16
      60:	cmp	w9, w8
      64:	adrp	x8, 0 <pts_ieee754_acos>
      68:	b.cs	134 <pts_ieee754_acos+0x134>  // b.hs, b.nlast
      6c:	ldr	d0, [x8]
      70:	ret
      74:	fmov	d1, #1.000000000000000000e+00
      78:	tbnz	x8, #63, 1d8 <pts_ieee754_acos+0x1d8>
      7c:	fsub	d0, d1, d0
      80:	fmov	d2, #5.000000000000000000e-01
      84:	adrp	x8, 0 <pts_ieee754_acos>
      88:	adrp	x9, 0 <pts_ieee754_acos>
      8c:	ldr	d3, [x8]
      90:	ldr	d4, [x9]
      94:	adrp	x9, 0 <pts_ieee754_acos>
      98:	fmul	d0, d0, d2
      9c:	fsqrt	d2, d0
      a0:	fmadd	d3, d0, d4, d3
      a4:	fmov	x10, d2
      a8:	and	x8, x10, #0xffffffff00000000
      ac:	adrp	x10, 0 <pts_ieee754_acos>
      b0:	fmov	d5, x8
      b4:	adrp	x8, 0 <pts_ieee754_acos>
      b8:	ldr	d16, [x10]
      bc:	ldr	d7, [x8]
      c0:	adrp	x8, 0 <pts_ieee754_acos>
      c4:	fmsub	d4, d5, d5, d0
      c8:	fadd	d6, d2, d5
      cc:	fmadd	d3, d0, d3, d7
      d0:	ldr	d7, [x9]
      d4:	adrp	x9, 0 <pts_ieee754_acos>
      d8:	fdiv	d4, d4, d6
      dc:	ldr	d6, [x8]
      e0:	adrp	x8, 0 <pts_ieee754_acos>
      e4:	fmadd	d3, d0, d3, d6
      e8:	fmadd	d6, d0, d16, d7
      ec:	ldr	d7, [x8]
      f0:	ldr	d16, [x9]
      f4:	adrp	x8, 0 <pts_ieee754_acos>
      f8:	fmadd	d3, d0, d3, d7
      fc:	ldr	d7, [x8]
     100:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     104:	fmadd	d6, d0, d6, d16
     108:	movk	x8, #0x3fc5, lsl #48
     10c:	fmov	d16, x8
     110:	fmadd	d3, d0, d3, d16
     114:	fmadd	d6, d0, d6, d7
     118:	fmul	d3, d0, d3
     11c:	fmadd	d0, d0, d6, d1
     120:	fdiv	d0, d3, d0
     124:	fmadd	d0, d0, d2, d4
     128:	fadd	d0, d0, d5
     12c:	fadd	d0, d0, d0
     130:	ret
     134:	fmul	d1, d0, d0
     138:	adrp	x9, 0 <pts_ieee754_acos>
     13c:	adrp	x10, 0 <pts_ieee754_acos>
     140:	ldr	d2, [x9]
     144:	ldr	d3, [x10]
     148:	adrp	x9, 0 <pts_ieee754_acos>
     14c:	adrp	x10, 0 <pts_ieee754_acos>
     150:	adrp	x11, 0 <pts_ieee754_acos>
     154:	ldr	d4, [x10]
     158:	ldr	d5, [x11]
     15c:	adrp	x10, 0 <pts_ieee754_acos>
     160:	fmadd	d2, d1, d3, d2
     164:	ldr	d3, [x9]
     168:	adrp	x9, 0 <pts_ieee754_acos>
     16c:	fmadd	d2, d1, d2, d3
     170:	ldr	d3, [x9]
     174:	adrp	x9, 0 <pts_ieee754_acos>
     178:	fmadd	d2, d1, d2, d3
     17c:	fmadd	d3, d1, d5, d4
     180:	ldr	d4, [x9]
     184:	ldr	d5, [x10]
     188:	adrp	x9, 0 <pts_ieee754_acos>
     18c:	fmadd	d2, d1, d2, d4
     190:	ldr	d4, [x9]
     194:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     198:	fmadd	d3, d1, d3, d5
     19c:	movk	x9, #0x3fc5, lsl #48
     1a0:	fmov	d5, x9
     1a4:	adrp	x9, 0 <pts_ieee754_acos>
     1a8:	fmadd	d2, d1, d2, d5
     1ac:	fmadd	d3, d1, d3, d4
     1b0:	fmov	d4, #1.000000000000000000e+00
     1b4:	fmul	d2, d1, d2
     1b8:	fmadd	d1, d1, d3, d4
     1bc:	fdiv	d1, d2, d1
     1c0:	ldr	d2, [x9]
     1c4:	fmsub	d1, d0, d1, d2
     1c8:	fsub	d0, d1, d0
     1cc:	ldr	d1, [x8]
     1d0:	fadd	d0, d0, d1
     1d4:	ret
     1d8:	fadd	d0, d0, d1
     1dc:	fmov	d2, #5.000000000000000000e-01
     1e0:	adrp	x8, 0 <pts_ieee754_acos>
     1e4:	adrp	x9, 0 <pts_ieee754_acos>
     1e8:	adrp	x10, 0 <pts_ieee754_acos>
     1ec:	ldr	d3, [x9]
     1f0:	adrp	x9, 0 <pts_ieee754_acos>
     1f4:	ldr	d5, [x10]
     1f8:	ldr	d4, [x9]
     1fc:	adrp	x9, 0 <pts_ieee754_acos>
     200:	fmul	d0, d0, d2
     204:	ldr	d2, [x8]
     208:	adrp	x8, 0 <pts_ieee754_acos>
     20c:	fmadd	d2, d0, d3, d2
     210:	ldr	d3, [x8]
     214:	adrp	x8, 0 <pts_ieee754_acos>
     218:	fmadd	d4, d0, d5, d4
     21c:	ldr	d5, [x9]
     220:	fmadd	d2, d0, d2, d3
     224:	ldr	d3, [x8]
     228:	adrp	x8, 0 <pts_ieee754_acos>
     22c:	fmadd	d4, d0, d4, d5
     230:	fmadd	d2, d0, d2, d3
     234:	ldr	d3, [x8]
     238:	adrp	x8, 0 <pts_ieee754_acos>
     23c:	fmadd	d2, d0, d2, d3
     240:	ldr	d3, [x8]
     244:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     248:	movk	x8, #0x3fc5, lsl #48
     24c:	fmov	d5, x8
     250:	fmadd	d3, d0, d4, d3
     254:	adrp	x8, 0 <pts_ieee754_acos>
     258:	fmadd	d2, d0, d2, d5
     25c:	fmadd	d1, d0, d3, d1
     260:	fmul	d2, d0, d2
     264:	fsqrt	d0, d0
     268:	fdiv	d1, d2, d1
     26c:	ldr	d2, [x8]
     270:	adrp	x8, 0 <pts_ieee754_acos>
     274:	fmadd	d1, d1, d0, d2
     278:	ldr	d2, [x8]
     27c:	fadd	d0, d0, d1
     280:	fmov	d1, #-2.000000000000000000e+00
     284:	fmadd	d0, d0, d1, d2
     288:	ret
     28c:	nop
     290:	nop
     294:	nop
     298:	nop
     29c:	nop

00000000000002a0 <pts_ieee754_acosh>:
     2a0:	fmov	x9, d0
     2a4:	mov	w10, #0x3ff00000            	// #1072693248
     2a8:	lsr	x8, x9, #32
     2ac:	cmp	w8, w10
     2b0:	b.ge	2c0 <pts_ieee754_acosh+0x20>  // b.tcont
     2b4:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     2b8:	fmov	d0, x8
     2bc:	ret
     2c0:	lsr	w10, w8, #20
     2c4:	cmp	w10, #0x41b
     2c8:	b.cc	2dc <pts_ieee754_acosh+0x3c>  // b.lo, b.ul, b.last
     2cc:	cmp	w10, #0x7ff
     2d0:	b.cc	320 <pts_ieee754_acosh+0x80>  // b.lo, b.ul, b.last
     2d4:	fadd	d0, d0, d0
     2d8:	ret
     2dc:	mov	w10, #0xc0100000            	// #-1072693248
     2e0:	add	w10, w8, w10
     2e4:	orr	w9, w10, w9
     2e8:	cbz	w9, 340 <pts_ieee754_acosh+0xa0>
     2ec:	mov	w9, #0x1                   	// #1
     2f0:	movk	w9, #0x4000, lsl #16
     2f4:	cmp	w8, w9
     2f8:	b.cc	348 <pts_ieee754_acosh+0xa8>  // b.lo, b.ul, b.last
     2fc:	fmul	d1, d0, d0
     300:	fmov	d2, #-1.000000000000000000e+00
     304:	fadd	d1, d1, d2
     308:	fsqrt	d1, d1
     30c:	fadd	d1, d1, d0
     310:	fdiv	d1, d2, d1
     314:	fmov	d2, #2.000000000000000000e+00
     318:	fmadd	d0, d0, d2, d1
     31c:	b	380 <pts_ieee754_log>
     320:	stp	x29, x30, [sp, #-16]!
     324:	mov	x29, sp
     328:	bl	380 <pts_ieee754_log>
     32c:	adrp	x8, 0 <pts_ieee754_acos>
     330:	ldr	d1, [x8]
     334:	fadd	d0, d0, d1
     338:	ldp	x29, x30, [sp], #16
     33c:	ret
     340:	movi	d0, #0x0
     344:	ret
     348:	fmov	d1, #-1.000000000000000000e+00
     34c:	fmov	d2, #2.000000000000000000e+00
     350:	fadd	d0, d0, d1
     354:	fmul	d1, d0, d0
     358:	fmadd	d1, d0, d2, d1
     35c:	fsqrt	d1, d1
     360:	fadd	d0, d0, d1
     364:	b	5a0 <pts_ieee754_log1p>
     368:	nop
     36c:	nop
     370:	nop
     374:	nop
     378:	nop
     37c:	nop

0000000000000380 <pts_ieee754_log>:
     380:	fmov	x9, d0
     384:	lsr	x8, x9, #32
     388:	cmp	w8, #0x100, lsl #12
     38c:	b.ge	3bc <pts_ieee754_log+0x3c>  // b.tcont
     390:	and	w8, w8, #0x7fffffff
     394:	orr	w8, w8, w9
     398:	cbz	w8, 44c <pts_ieee754_log+0xcc>
     39c:	tbnz	x9, #63, 514 <pts_ieee754_log+0x194>
     3a0:	mov	x8, #0x4350000000000000    	// #4850376798678024192
     3a4:	mov	w10, #0xffffffca            	// #-54
     3a8:	fmov	d1, x8
     3ac:	fmul	d0, d0, d1
     3b0:	fmov	x8, d0
     3b4:	lsr	x8, x8, #32
     3b8:	b	3c0 <pts_ieee754_log+0x40>
     3bc:	mov	w10, wzr
     3c0:	mov	w9, #0x7ff00000            	// #2146435072
     3c4:	cmp	w8, w9
     3c8:	b.lt	3d4 <pts_ieee754_log+0x54>  // b.tstop
     3cc:	fadd	d0, d0, d0
     3d0:	ret
     3d4:	and	w9, w8, #0xfffff
     3d8:	fmov	x13, d0
     3dc:	fmov	d0, #-1.000000000000000000e+00
     3e0:	add	w11, w9, #0x95, lsl #12
     3e4:	add	w10, w10, w8, asr #20
     3e8:	add	w11, w11, #0xf64
     3ec:	and	w12, w11, #0x100000
     3f0:	and	x13, x13, #0xffffffff
     3f4:	add	w10, w10, w11, lsr #20
     3f8:	bfxil	w12, w8, #0, #20
     3fc:	add	w8, w8, #0x2
     400:	and	w8, w8, #0xfffff
     404:	eor	w12, w12, #0x3ff00000
     408:	cmp	w8, #0x2
     40c:	sub	w8, w10, #0x3ff
     410:	orr	x12, x13, x12, lsl #32
     414:	fmov	d1, x12
     418:	fadd	d0, d1, d0
     41c:	b.hi	458 <pts_ieee754_log+0xd8>  // b.pmore
     420:	fcmp	d0, #0.0
     424:	b.ne	520 <pts_ieee754_log+0x1a0>  // b.any
     428:	cbz	w8, 580 <pts_ieee754_log+0x200>
     42c:	scvtf	d0, w8
     430:	adrp	x8, 0 <pts_ieee754_acos>
     434:	ldr	d1, [x8]
     438:	adrp	x8, 0 <pts_ieee754_acos>
     43c:	ldr	d2, [x8]
     440:	fmul	d1, d0, d1
     444:	fmadd	d0, d0, d2, d1
     448:	ret
     44c:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
     450:	fmov	d0, x8
     454:	ret
     458:	fmov	d1, #2.000000000000000000e+00
     45c:	adrp	x10, 0 <pts_ieee754_acos>
     460:	adrp	x11, 0 <pts_ieee754_acos>
     464:	ldr	d4, [x10]
     468:	ldr	d5, [x11]
     46c:	adrp	x10, 0 <pts_ieee754_acos>
     470:	adrp	x11, 0 <pts_ieee754_acos>
     474:	adrp	x12, 0 <pts_ieee754_acos>
     478:	fadd	d1, d0, d1
     47c:	ldr	d6, [x11]
     480:	ldr	d7, [x12]
     484:	adrp	x11, 0 <pts_ieee754_acos>
     488:	fdiv	d1, d0, d1
     48c:	fmul	d2, d1, d1
     490:	fmul	d3, d2, d2
     494:	fmadd	d4, d3, d5, d4
     498:	ldr	d5, [x10]
     49c:	adrp	x10, 0 <pts_ieee754_acos>
     4a0:	fmadd	d5, d3, d6, d5
     4a4:	ldr	d6, [x10]
     4a8:	sub	w10, w9, #0x61, lsl #12
     4ac:	sub	w10, w10, #0x47a
     4b0:	fmadd	d4, d3, d4, d7
     4b4:	ldr	d7, [x11]
     4b8:	mov	w11, #0xb851                	// #47185
     4bc:	movk	w11, #0x6, lsl #16
     4c0:	fmadd	d5, d3, d5, d6
     4c4:	sub	w9, w11, w9
     4c8:	orr	w9, w10, w9
     4cc:	fmadd	d4, d3, d4, d7
     4d0:	cmp	w9, #0x1
     4d4:	fmul	d3, d3, d5
     4d8:	fmul	d4, d2, d4
     4dc:	scvtf	d2, w8
     4e0:	fadd	d3, d3, d4
     4e4:	b.lt	554 <pts_ieee754_log+0x1d4>  // b.tstop
     4e8:	fmov	d4, #5.000000000000000000e-01
     4ec:	fmul	d4, d0, d4
     4f0:	fmul	d4, d0, d4
     4f4:	fadd	d3, d4, d3
     4f8:	cbz	w8, 588 <pts_ieee754_log+0x208>
     4fc:	adrp	x8, 0 <pts_ieee754_acos>
     500:	ldr	d5, [x8]
     504:	fmul	d5, d2, d5
     508:	fmadd	d1, d1, d3, d5
     50c:	fsub	d1, d4, d1
     510:	b	56c <pts_ieee754_log+0x1ec>
     514:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     518:	fmov	d0, x8
     51c:	ret
     520:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     524:	fmov	d1, #5.000000000000000000e-01
     528:	fmul	d3, d0, d0
     52c:	movk	x9, #0xbfd5, lsl #48
     530:	fmov	d2, x9
     534:	fmadd	d1, d0, d2, d1
     538:	fmul	d1, d3, d1
     53c:	cbz	w8, 58c <pts_ieee754_log+0x20c>
     540:	scvtf	d2, w8
     544:	adrp	x8, 0 <pts_ieee754_acos>
     548:	ldr	d3, [x8]
     54c:	fmadd	d1, d2, d3, d1
     550:	b	56c <pts_ieee754_log+0x1ec>
     554:	fsub	d3, d0, d3
     558:	cbz	w8, 594 <pts_ieee754_log+0x214>
     55c:	adrp	x8, 0 <pts_ieee754_acos>
     560:	ldr	d4, [x8]
     564:	fmul	d4, d2, d4
     568:	fmadd	d1, d1, d3, d4
     56c:	fsub	d0, d1, d0
     570:	adrp	x8, 0 <pts_ieee754_acos>
     574:	ldr	d1, [x8]
     578:	fnmsub	d0, d2, d1, d0
     57c:	ret
     580:	movi	d0, #0x0
     584:	ret
     588:	fmsub	d1, d1, d3, d4
     58c:	fsub	d0, d0, d1
     590:	ret
     594:	fmsub	d0, d1, d3, d0
     598:	ret
     59c:	nop

00000000000005a0 <pts_ieee754_log1p>:
     5a0:	fmov	x8, d0
     5a4:	mov	w10, #0x8279                	// #33401
     5a8:	movk	w10, #0x3fda, lsl #16
     5ac:	lsr	x9, x8, #32
     5b0:	cmp	w9, w10
     5b4:	b.gt	5e8 <pts_ieee754_log1p+0x48>
     5b8:	ubfx	x10, x8, #32, #31
     5bc:	lsr	w8, w10, #20
     5c0:	cmp	w8, #0x3ff
     5c4:	b.cc	5fc <pts_ieee754_log1p+0x5c>  // b.lo, b.ul, b.last
     5c8:	fmov	d1, #-1.000000000000000000e+00
     5cc:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     5d0:	mov	x9, #0xfff0000000000000    	// #-4503599627370496
     5d4:	fcmp	d0, d1
     5d8:	fmov	d0, x8
     5dc:	fmov	d1, x9
     5e0:	fcsel	d0, d1, d0, eq	// eq = none
     5e4:	ret
     5e8:	lsr	w8, w9, #20
     5ec:	cmp	w8, #0x7ff
     5f0:	b.cc	628 <pts_ieee754_log1p+0x88>  // b.lo, b.ul, b.last
     5f4:	fadd	d0, d0, d0
     5f8:	ret
     5fc:	lsr	w10, w10, #21
     600:	cmp	w10, #0x1f0
     604:	b.hi	63c <pts_ieee754_log1p+0x9c>  // b.pmore
     608:	mov	x9, #0x4350000000000000    	// #4850376798678024192
     60c:	fmov	d1, x9
     610:	fadd	d1, d0, d1
     614:	fcmp	d1, #0.0
     618:	b.le	7d0 <pts_ieee754_log1p+0x230>
     61c:	cmp	w8, #0x3c9
     620:	b.cs	7d0 <pts_ieee754_log1p+0x230>  // b.hs, b.nlast
     624:	ret
     628:	lsr	w10, w9, #22
     62c:	cmp	w10, #0x10c
     630:	b.ls	664 <pts_ieee754_log1p+0xc4>  // b.plast
     634:	movi	d1, #0x0
     638:	b	69c <pts_ieee754_log1p+0xfc>
     63c:	sub	w8, w9, #0x1
     640:	mov	w9, #0xbec3                	// #48835
     644:	movk	w9, #0xbfd2, lsl #16
     648:	cmp	w8, w9
     64c:	b.hi	664 <pts_ieee754_log1p+0xc4>  // b.pmore
     650:	fmov	d1, #5.000000000000000000e-01
     654:	mov	w8, wzr
     658:	fmul	d1, d0, d1
     65c:	fmul	d2, d1, d0
     660:	b	6fc <pts_ieee754_log1p+0x15c>
     664:	fmov	d1, #1.000000000000000000e+00
     668:	fmov	d3, #-1.000000000000000000e+00
     66c:	fadd	d2, d0, d1
     670:	fsub	d4, d0, d2
     674:	fadd	d3, d2, d3
     678:	fmov	x9, d2
     67c:	asr	x8, x9, #52
     680:	lsr	x9, x9, #32
     684:	fadd	d1, d4, d1
     688:	fsub	d0, d0, d3
     68c:	cmp	w8, #0x3ff
     690:	fcsel	d0, d1, d0, gt
     694:	fdiv	d1, d0, d2
     698:	fmov	d0, d2
     69c:	fmov	x10, d0
     6a0:	mov	w11, #0xa09d                	// #41117
     6a4:	and	w9, w9, #0xfffff
     6a8:	movk	w11, #0x6, lsl #16
     6ac:	orr	w12, w9, #0x3fe00000
     6b0:	orr	w13, w9, #0x3ff00000
     6b4:	cmp	w9, w11
     6b8:	fmov	d0, #-1.000000000000000000e+00
     6bc:	and	x10, x10, #0xffffffff
     6c0:	csel	w11, w12, w13, hi	// hi = pmore
     6c4:	orr	x10, x10, x11, lsl #32
     6c8:	sub	w11, w8, #0x3fe
     6cc:	sub	w8, w8, #0x3ff
     6d0:	csel	w8, w11, w8, hi	// hi = pmore
     6d4:	fmov	d2, x10
     6d8:	mov	w10, #0x100000              	// #1048576
     6dc:	sub	w10, w10, w9
     6e0:	lsr	w10, w10, #2
     6e4:	fadd	d0, d2, d0
     6e8:	fmov	d2, #5.000000000000000000e-01
     6ec:	csel	w9, w10, w9, hi	// hi = pmore
     6f0:	fmul	d2, d0, d2
     6f4:	fmul	d2, d0, d2
     6f8:	cbz	w9, 794 <pts_ieee754_log1p+0x1f4>
     6fc:	fmov	d3, #2.000000000000000000e+00
     700:	adrp	x9, 0 <pts_ieee754_acos>
     704:	adrp	x10, 0 <pts_ieee754_acos>
     708:	ldr	d5, [x9]
     70c:	ldr	d6, [x10]
     710:	adrp	x9, 0 <pts_ieee754_acos>
     714:	fadd	d3, d0, d3
     718:	fdiv	d3, d0, d3
     71c:	fmul	d4, d3, d3
     720:	fmadd	d5, d4, d6, d5
     724:	ldr	d6, [x9]
     728:	adrp	x9, 0 <pts_ieee754_acos>
     72c:	fmadd	d5, d4, d5, d6
     730:	ldr	d6, [x9]
     734:	adrp	x9, 0 <pts_ieee754_acos>
     738:	fmadd	d5, d4, d5, d6
     73c:	ldr	d6, [x9]
     740:	adrp	x9, 0 <pts_ieee754_acos>
     744:	fmadd	d5, d4, d5, d6
     748:	ldr	d6, [x9]
     74c:	adrp	x9, 0 <pts_ieee754_acos>
     750:	fmadd	d5, d4, d5, d6
     754:	ldr	d6, [x9]
     758:	fmadd	d5, d4, d5, d6
     75c:	fmul	d4, d4, d5
     760:	cbz	w8, 7c0 <pts_ieee754_log1p+0x220>
     764:	scvtf	d5, w8
     768:	adrp	x8, 0 <pts_ieee754_acos>
     76c:	fadd	d4, d2, d4
     770:	ldr	d6, [x8]
     774:	adrp	x8, 0 <pts_ieee754_acos>
     778:	fmadd	d1, d5, d6, d1
     77c:	fmadd	d1, d3, d4, d1
     780:	fsub	d1, d2, d1
     784:	fsub	d0, d1, d0
     788:	ldr	d1, [x8]
     78c:	fnmsub	d0, d5, d1, d0
     790:	ret
     794:	fcmp	d0, #0.0
     798:	b.ne	7e0 <pts_ieee754_log1p+0x240>  // b.any
     79c:	cbz	w8, 824 <pts_ieee754_log1p+0x284>
     7a0:	scvtf	d0, w8
     7a4:	adrp	x8, 0 <pts_ieee754_acos>
     7a8:	ldr	d2, [x8]
     7ac:	adrp	x8, 0 <pts_ieee754_acos>
     7b0:	fmadd	d1, d0, d2, d1
     7b4:	ldr	d2, [x8]
     7b8:	fmadd	d0, d0, d2, d1
     7bc:	ret
     7c0:	fadd	d1, d2, d4
     7c4:	fmsub	d1, d3, d1, d2
     7c8:	fsub	d0, d0, d1
     7cc:	ret
     7d0:	fmul	d1, d0, d0
     7d4:	fmov	d2, #-5.000000000000000000e-01
     7d8:	fmadd	d0, d1, d2, d0
     7dc:	ret
     7e0:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     7e4:	fmov	d3, #1.000000000000000000e+00
     7e8:	movk	x9, #0xbfe5, lsl #48
     7ec:	fmov	d4, x9
     7f0:	fmadd	d3, d0, d4, d3
     7f4:	fmul	d2, d3, d2
     7f8:	cbz	w8, 82c <pts_ieee754_log1p+0x28c>
     7fc:	scvtf	d3, w8
     800:	adrp	x8, 0 <pts_ieee754_acos>
     804:	ldr	d4, [x8]
     808:	adrp	x8, 0 <pts_ieee754_acos>
     80c:	fmadd	d1, d3, d4, d1
     810:	fsub	d1, d2, d1
     814:	fsub	d0, d1, d0
     818:	ldr	d1, [x8]
     81c:	fnmsub	d0, d3, d1, d0
     820:	ret
     824:	movi	d0, #0x0
     828:	ret
     82c:	fsub	d0, d0, d2
     830:	ret
     834:	nop
     838:	nop
     83c:	nop

0000000000000840 <pts_ieee754_asin>:
     840:	fmov	x10, d0
     844:	lsr	x8, x10, #32
     848:	ubfx	x9, x10, #32, #31
     84c:	ubfx	w11, w8, #20, #11
     850:	cmp	w11, #0x3ff
     854:	b.cc	890 <pts_ieee754_asin+0x50>  // b.lo, b.ul, b.last
     858:	adrp	x8, 0 <pts_ieee754_acos>
     85c:	ldr	d1, [x8]
     860:	adrp	x8, 0 <pts_ieee754_acos>
     864:	ldr	d2, [x8]
     868:	mov	w8, #0xc0100000            	// #-1072693248
     86c:	fmul	d1, d0, d1
     870:	add	w8, w9, w8
     874:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
     878:	orr	w8, w8, w10
     87c:	cmp	w8, #0x0
     880:	fmadd	d0, d0, d2, d1
     884:	fmov	d1, x9
     888:	fcsel	d0, d0, d1, eq	// eq = none
     88c:	ret
     890:	lsr	w10, w9, #21
     894:	cmp	w10, #0x1fe
     898:	b.hi	8c8 <pts_ieee754_asin+0x88>  // b.pmore
     89c:	lsr	w8, w9, #22
     8a0:	cmp	w8, #0xf8
     8a4:	b.hi	994 <pts_ieee754_asin+0x154>  // b.pmore
     8a8:	adrp	x8, 0 <pts_ieee754_acos>
     8ac:	fmov	d3, #1.000000000000000000e+00
     8b0:	ldr	d1, [x8]
     8b4:	fadd	d2, d0, d1
     8b8:	movi	d1, #0x0
     8bc:	fcmp	d2, d3
     8c0:	b.le	998 <pts_ieee754_asin+0x158>
     8c4:	ret
     8c8:	fabs	d0, d0
     8cc:	fmov	d3, #1.000000000000000000e+00
     8d0:	adrp	x10, 0 <pts_ieee754_acos>
     8d4:	fmov	d1, #5.000000000000000000e-01
     8d8:	adrp	x11, 0 <pts_ieee754_acos>
     8dc:	adrp	x12, 0 <pts_ieee754_acos>
     8e0:	ldr	d2, [x11]
     8e4:	adrp	x11, 0 <pts_ieee754_acos>
     8e8:	ldr	d6, [x12]
     8ec:	ldr	d5, [x11]
     8f0:	adrp	x11, 0 <pts_ieee754_acos>
     8f4:	fsub	d0, d3, d0
     8f8:	fmul	d0, d0, d1
     8fc:	ldr	d1, [x10]
     900:	adrp	x10, 0 <pts_ieee754_acos>
     904:	ldr	d4, [x10]
     908:	adrp	x10, 0 <pts_ieee754_acos>
     90c:	fmadd	d2, d0, d2, d1
     910:	fsqrt	d1, d0
     914:	fmadd	d2, d0, d2, d4
     918:	ldr	d4, [x10]
     91c:	adrp	x10, 0 <pts_ieee754_acos>
     920:	fmadd	d2, d0, d2, d4
     924:	fmadd	d4, d0, d6, d5
     928:	ldr	d5, [x10]
     92c:	ldr	d6, [x11]
     930:	adrp	x10, 0 <pts_ieee754_acos>
     934:	fmadd	d2, d0, d2, d5
     938:	ldr	d5, [x10]
     93c:	mov	x10, #0x5555555555555555    	// #6148914691236517205
     940:	fmadd	d4, d0, d4, d6
     944:	movk	x10, #0x3fc5, lsl #48
     948:	fmov	d6, x10
     94c:	mov	w10, #0x3333                	// #13107
     950:	movk	w10, #0x3fef, lsl #16
     954:	cmp	w9, w10
     958:	fmadd	d2, d0, d2, d6
     95c:	fmadd	d4, d0, d4, d5
     960:	fmul	d2, d0, d2
     964:	fmadd	d3, d0, d4, d3
     968:	b.cc	a24 <pts_ieee754_asin+0x1e4>  // b.lo, b.ul, b.last
     96c:	fdiv	d0, d2, d3
     970:	adrp	x9, 0 <pts_ieee754_acos>
     974:	ldr	d2, [x9]
     978:	adrp	x9, 0 <pts_ieee754_acos>
     97c:	fmadd	d0, d1, d0, d1
     980:	fmov	d1, #2.000000000000000000e+00
     984:	fmadd	d0, d0, d1, d2
     988:	ldr	d1, [x9]
     98c:	fsub	d0, d1, d0
     990:	b	a6c <pts_ieee754_asin+0x22c>
     994:	fmul	d1, d0, d0
     998:	adrp	x8, 0 <pts_ieee754_acos>
     99c:	adrp	x9, 0 <pts_ieee754_acos>
     9a0:	adrp	x10, 0 <pts_ieee754_acos>
     9a4:	ldr	d2, [x8]
     9a8:	ldr	d3, [x9]
     9ac:	adrp	x8, 0 <pts_ieee754_acos>
     9b0:	adrp	x9, 0 <pts_ieee754_acos>
     9b4:	ldr	d5, [x10]
     9b8:	fmadd	d2, d1, d3, d2
     9bc:	ldr	d3, [x8]
     9c0:	adrp	x8, 0 <pts_ieee754_acos>
     9c4:	ldr	d4, [x9]
     9c8:	adrp	x9, 0 <pts_ieee754_acos>
     9cc:	fmadd	d2, d1, d2, d3
     9d0:	ldr	d3, [x8]
     9d4:	adrp	x8, 0 <pts_ieee754_acos>
     9d8:	fmadd	d2, d1, d2, d3
     9dc:	fmadd	d3, d1, d5, d4
     9e0:	ldr	d4, [x8]
     9e4:	ldr	d5, [x9]
     9e8:	adrp	x8, 0 <pts_ieee754_acos>
     9ec:	fmadd	d2, d1, d2, d4
     9f0:	ldr	d4, [x8]
     9f4:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     9f8:	fmadd	d3, d1, d3, d5
     9fc:	movk	x8, #0x3fc5, lsl #48
     a00:	fmov	d5, x8
     a04:	fmadd	d2, d1, d2, d5
     a08:	fmadd	d3, d1, d3, d4
     a0c:	fmov	d4, #1.000000000000000000e+00
     a10:	fmul	d2, d1, d2
     a14:	fmadd	d1, d1, d3, d4
     a18:	fdiv	d1, d2, d1
     a1c:	fmadd	d0, d0, d1, d0
     a20:	ret
     a24:	fmov	x9, d1
     a28:	fdiv	d2, d2, d3
     a2c:	fmov	d3, #-2.000000000000000000e+00
     a30:	and	x9, x9, #0xffffffff00000000
     a34:	fmov	d4, x9
     a38:	adrp	x9, 0 <pts_ieee754_acos>
     a3c:	fmsub	d0, d4, d4, d0
     a40:	fadd	d5, d1, d4
     a44:	fadd	d1, d1, d1
     a48:	fdiv	d0, d0, d5
     a4c:	ldr	d5, [x9]
     a50:	adrp	x9, 0 <pts_ieee754_acos>
     a54:	fmadd	d0, d0, d3, d5
     a58:	ldr	d5, [x9]
     a5c:	fnmsub	d0, d1, d2, d0
     a60:	fmadd	d1, d4, d3, d5
     a64:	fsub	d0, d1, d0
     a68:	fadd	d0, d0, d5
     a6c:	fneg	d1, d0
     a70:	cmp	w8, #0x0
     a74:	fcsel	d0, d0, d1, gt
     a78:	ret
     a7c:	nop

0000000000000a80 <pts_ieee754_asinh>:
     a80:	stp	x29, x30, [sp, #-32]!
     a84:	str	x19, [sp, #16]
     a88:	mov	x29, sp
     a8c:	fmov	x8, d0
     a90:	lsr	x19, x8, #32
     a94:	ubfx	w9, w19, #20, #11
     a98:	cmp	w9, #0x7ff
     a9c:	b.cc	aa8 <pts_ieee754_asinh+0x28>  // b.lo, b.ul, b.last
     aa0:	fadd	d0, d0, d0
     aa4:	b	b5c <pts_ieee754_asinh+0xdc>
     aa8:	adrp	x9, 0 <pts_ieee754_acos>
     aac:	fmov	d2, #1.000000000000000000e+00
     ab0:	ubfx	x8, x8, #32, #31
     ab4:	ldr	d1, [x9]
     ab8:	fadd	d1, d0, d1
     abc:	fcmp	d1, d2
     ac0:	b.le	ad0 <pts_ieee754_asinh+0x50>
     ac4:	lsr	w9, w8, #20
     ac8:	cmp	w9, #0x3e3
     acc:	b.cc	b5c <pts_ieee754_asinh+0xdc>  // b.lo, b.ul, b.last
     ad0:	mov	w9, #0x1                   	// #1
     ad4:	movk	w9, #0x41b0, lsl #16
     ad8:	cmp	w8, w9
     adc:	b.cc	af8 <pts_ieee754_asinh+0x78>  // b.lo, b.ul, b.last
     ae0:	fabs	d0, d0
     ae4:	bl	380 <pts_ieee754_log>
     ae8:	adrp	x8, 0 <pts_ieee754_acos>
     aec:	ldr	d1, [x8]
     af0:	fadd	d0, d0, d1
     af4:	b	b50 <pts_ieee754_asinh+0xd0>
     af8:	mov	w9, #0x1                   	// #1
     afc:	movk	w9, #0x4000, lsl #16
     b00:	cmp	w8, w9
     b04:	b.cc	b30 <pts_ieee754_asinh+0xb0>  // b.lo, b.ul, b.last
     b08:	fmov	d1, #1.000000000000000000e+00
     b0c:	fmadd	d2, d0, d0, d1
     b10:	fabs	d0, d0
     b14:	fsqrt	d2, d2
     b18:	fadd	d2, d0, d2
     b1c:	fdiv	d1, d1, d2
     b20:	fmov	d2, #2.000000000000000000e+00
     b24:	fmadd	d0, d0, d2, d1
     b28:	bl	380 <pts_ieee754_log>
     b2c:	b	b50 <pts_ieee754_asinh+0xd0>
     b30:	fmul	d1, d0, d0
     b34:	fabs	d0, d0
     b38:	fadd	d3, d1, d2
     b3c:	fsqrt	d3, d3
     b40:	fadd	d2, d3, d2
     b44:	fdiv	d1, d1, d2
     b48:	fadd	d0, d0, d1
     b4c:	bl	5a0 <pts_ieee754_log1p>
     b50:	fneg	d1, d0
     b54:	cmp	w19, #0x0
     b58:	fcsel	d0, d0, d1, gt
     b5c:	ldr	x19, [sp, #16]
     b60:	ldp	x29, x30, [sp], #32
     b64:	ret
     b68:	nop
     b6c:	nop
     b70:	nop
     b74:	nop
     b78:	nop
     b7c:	nop

0000000000000b80 <pts_ieee754_atan>:
     b80:	fmov	x8, d0
     b84:	lsr	x9, x8, #32
     b88:	ubfx	x11, x8, #32, #31
     b8c:	ubfx	w10, w9, #20, #11
     b90:	cmp	w10, #0x441
     b94:	b.cc	bbc <pts_ieee754_atan+0x3c>  // b.lo, b.ul, b.last
     b98:	mov	w10, #0x7ff00000            	// #2146435072
     b9c:	cmp	w11, w10
     ba0:	b.hi	bb4 <pts_ieee754_atan+0x34>  // b.pmore
     ba4:	cbz	w8, c24 <pts_ieee754_atan+0xa4>
     ba8:	mov	w8, #0x7ff00000            	// #2146435072
     bac:	cmp	w11, w8
     bb0:	b.ne	c24 <pts_ieee754_atan+0xa4>  // b.any
     bb4:	fadd	d0, d0, d0
     bb8:	ret
     bbc:	lsr	w9, w11, #18
     bc0:	cmp	w9, #0xff6
     bc4:	b.hi	bf4 <pts_ieee754_atan+0x74>  // b.pmore
     bc8:	adrp	x10, 0 <pts_ieee754_acos>
     bcc:	fmov	d2, #1.000000000000000000e+00
     bd0:	ldr	d1, [x10]
     bd4:	mov	w10, #0xffffffff            	// #-1
     bd8:	fadd	d1, d0, d1
     bdc:	fcmp	d1, d2
     be0:	b.le	c90 <pts_ieee754_atan+0x110>
     be4:	lsr	w11, w11, #22
     be8:	cmp	w11, #0xf9
     bec:	b.cs	c90 <pts_ieee754_atan+0x110>  // b.hs, b.nlast
     bf0:	ret
     bf4:	fabs	d0, d0
     bf8:	mov	w10, #0x3ff2ffff            	// #1072889855
     bfc:	cmp	w11, w10
     c00:	b.hi	c44 <pts_ieee754_atan+0xc4>  // b.pmore
     c04:	fmov	d1, #-1.000000000000000000e+00
     c08:	mov	w10, #0x3fe5ffff            	// #1072037887
     c0c:	cmp	w11, w10
     c10:	b.hi	c70 <pts_ieee754_atan+0xf0>  // b.pmore
     c14:	fmov	d2, #2.000000000000000000e+00
     c18:	mov	x10, xzr
     c1c:	fmadd	d1, d0, d2, d1
     c20:	b	c7c <pts_ieee754_atan+0xfc>
     c24:	adrp	x8, 0 <pts_ieee754_acos>
     c28:	cmp	w9, #0x1
     c2c:	ldr	d0, [x8]
     c30:	b.lt	d6c <pts_ieee754_atan+0x1ec>  // b.tstop
     c34:	adrp	x8, 0 <pts_ieee754_acos>
     c38:	ldr	d1, [x8]
     c3c:	fadd	d0, d0, d1
     c40:	ret
     c44:	mov	w10, #0x7fff                	// #32767
     c48:	movk	w10, #0x4003, lsl #16
     c4c:	cmp	w11, w10
     c50:	b.hi	c84 <pts_ieee754_atan+0x104>  // b.pmore
     c54:	fmov	d1, #-1.500000000000000000e+00
     c58:	fmov	d2, #1.000000000000000000e+00
     c5c:	mov	w10, #0x2                   	// #2
     c60:	fmov	d3, #1.500000000000000000e+00
     c64:	fadd	d1, d0, d1
     c68:	fmadd	d0, d0, d3, d2
     c6c:	b	c8c <pts_ieee754_atan+0x10c>
     c70:	fmov	d2, #1.000000000000000000e+00
     c74:	fadd	d1, d0, d1
     c78:	mov	w10, #0x1                   	// #1
     c7c:	fadd	d0, d0, d2
     c80:	b	c8c <pts_ieee754_atan+0x10c>
     c84:	fmov	d1, #-1.000000000000000000e+00
     c88:	mov	w10, #0x3                   	// #3
     c8c:	fdiv	d0, d1, d0
     c90:	fmul	d1, d0, d0
     c94:	adrp	x11, 0 <pts_ieee754_acos>
     c98:	adrp	x12, 0 <pts_ieee754_acos>
     c9c:	ldr	d3, [x11]
     ca0:	ldr	d4, [x12]
     ca4:	adrp	x11, 0 <pts_ieee754_acos>
     ca8:	adrp	x12, 0 <pts_ieee754_acos>
     cac:	adrp	x13, 0 <pts_ieee754_acos>
     cb0:	cmp	w9, #0xff6
     cb4:	ldr	d5, [x12]
     cb8:	ldr	d6, [x13]
     cbc:	adrp	x12, 0 <pts_ieee754_acos>
     cc0:	fmul	d2, d1, d1
     cc4:	fmadd	d3, d2, d4, d3
     cc8:	ldr	d4, [x11]
     ccc:	adrp	x11, 0 <pts_ieee754_acos>
     cd0:	fmadd	d3, d2, d3, d4
     cd4:	fmadd	d4, d2, d6, d5
     cd8:	ldr	d5, [x11]
     cdc:	ldr	d6, [x12]
     ce0:	adrp	x11, 0 <pts_ieee754_acos>
     ce4:	adrp	x12, 0 <pts_ieee754_acos>
     ce8:	fmadd	d3, d2, d3, d5
     cec:	fmadd	d4, d2, d4, d6
     cf0:	ldr	d5, [x11]
     cf4:	ldr	d6, [x12]
     cf8:	adrp	x11, 0 <pts_ieee754_acos>
     cfc:	adrp	x12, 0 <pts_ieee754_acos>
     d00:	fmadd	d3, d2, d3, d5
     d04:	fmadd	d4, d2, d4, d6
     d08:	ldr	d5, [x11]
     d0c:	ldr	d6, [x12]
     d10:	fmadd	d3, d2, d3, d5
     d14:	fmadd	d4, d2, d4, d6
     d18:	fmul	d1, d1, d3
     d1c:	fmul	d2, d2, d4
     d20:	b.hi	d30 <pts_ieee754_atan+0x1b0>  // b.pmore
     d24:	fadd	d1, d2, d1
     d28:	fmsub	d0, d0, d1, d0
     d2c:	ret
     d30:	lsl	x9, x10, #3
     d34:	fadd	d1, d2, d1
     d38:	adrp	x10, 0 <pts_ieee754_acos>
     d3c:	add	x10, x10, #0x0
     d40:	cmp	x8, #0x0
     d44:	ldr	d2, [x10, x9]
     d48:	adrp	x10, 0 <pts_ieee754_acos>
     d4c:	add	x10, x10, #0x0
     d50:	fnmsub	d1, d0, d1, d2
     d54:	fsub	d0, d1, d0
     d58:	ldr	d1, [x10, x9]
     d5c:	fsub	d0, d1, d0
     d60:	fneg	d1, d0
     d64:	fcsel	d0, d1, d0, lt	// lt = tstop
     d68:	ret
     d6c:	adrp	x8, 0 <pts_ieee754_acos>
     d70:	ldr	d1, [x8]
     d74:	fsub	d0, d1, d0
     d78:	ret
     d7c:	nop

0000000000000d80 <pts_ieee754_atan2>:
     d80:	stp	x29, x30, [sp, #-32]!
     d84:	str	x19, [sp, #16]
     d88:	mov	x29, sp
     d8c:	fmov	x8, d1
     d90:	mov	w10, #0x7ff00000            	// #2146435072
     d94:	ubfx	x9, x8, #32, #31
     d98:	cmp	w8, #0x0
     d9c:	cset	w11, ne	// ne = any
     da0:	orr	w11, w9, w11
     da4:	cmp	w11, w10
     da8:	b.hi	dd0 <pts_ieee754_atan2+0x50>  // b.pmore
     dac:	fmov	x10, d0
     db0:	mov	w13, #0x1                   	// #1
     db4:	movk	w13, #0x7ff0, lsl #16
     db8:	ubfx	x11, x10, #32, #31
     dbc:	cmp	w10, #0x0
     dc0:	cset	w12, ne	// ne = any
     dc4:	orr	w12, w11, w12
     dc8:	cmp	w12, w13
     dcc:	b.cc	de0 <pts_ieee754_atan2+0x60>  // b.lo, b.ul, b.last
     dd0:	fadd	d0, d0, d1
     dd4:	ldr	x19, [sp, #16]
     dd8:	ldp	x29, x30, [sp], #32
     ddc:	ret
     de0:	lsr	x12, x8, #32
     de4:	mov	w13, #0xc0100000            	// #-1072693248
     de8:	add	w13, w12, w13
     dec:	orr	w13, w13, w8
     df0:	cbz	w13, e48 <pts_ieee754_atan2+0xc8>
     df4:	lsr	w13, w12, #30
     df8:	lsr	x12, x10, #32
     dfc:	and	w19, w13, #0x2
     e00:	orr	w13, w11, w10
     e04:	bfxil	w19, w12, #31, #1
     e08:	cbz	w13, e54 <pts_ieee754_atan2+0xd4>
     e0c:	orr	w13, w9, w8
     e10:	cbz	w13, e84 <pts_ieee754_atan2+0x104>
     e14:	mov	w13, #0x7ff00000            	// #2146435072
     e18:	cmp	w9, w13
     e1c:	b.ne	e7c <pts_ieee754_atan2+0xfc>  // b.any
     e20:	cmp	w11, w13
     e24:	b.ne	eac <pts_ieee754_atan2+0x12c>  // b.any
     e28:	adrp	x8, 0 <pts_ieee754_acos>
     e2c:	cmp	w19, #0x1
     e30:	b.gt	ef8 <pts_ieee754_atan2+0x178>
     e34:	cbnz	w19, f80 <pts_ieee754_atan2+0x200>
     e38:	adrp	x9, 0 <pts_ieee754_acos>
     e3c:	ldr	d0, [x8]
     e40:	ldr	d1, [x9]
     e44:	b	dd0 <pts_ieee754_atan2+0x50>
     e48:	ldr	x19, [sp, #16]
     e4c:	ldp	x29, x30, [sp], #32
     e50:	b	b80 <pts_ieee754_atan>
     e54:	cmp	w19, #0x2
     e58:	b.cc	dd4 <pts_ieee754_atan2+0x54>  // b.lo, b.ul, b.last
     e5c:	cmp	w19, #0x3
     e60:	b.ne	f18 <pts_ieee754_atan2+0x198>  // b.any
     e64:	adrp	x8, 0 <pts_ieee754_acos>
     e68:	adrp	x9, 0 <pts_ieee754_acos>
     e6c:	ldr	d0, [x8]
     e70:	ldr	d1, [x9]
     e74:	fsub	d0, d1, d0
     e78:	b	dd4 <pts_ieee754_atan2+0x54>
     e7c:	cmp	w11, w13
     e80:	b.ne	ec8 <pts_ieee754_atan2+0x148>  // b.any
     e84:	adrp	x8, 0 <pts_ieee754_acos>
     e88:	ldr	d0, [x8]
     e8c:	tbnz	x10, #63, e9c <pts_ieee754_atan2+0x11c>
     e90:	adrp	x8, 0 <pts_ieee754_acos>
     e94:	ldr	d1, [x8]
     e98:	b	dd0 <pts_ieee754_atan2+0x50>
     e9c:	adrp	x8, 0 <pts_ieee754_acos>
     ea0:	ldr	d1, [x8]
     ea4:	fsub	d0, d1, d0
     ea8:	b	dd4 <pts_ieee754_atan2+0x54>
     eac:	cmp	w19, #0x1
     eb0:	b.gt	f10 <pts_ieee754_atan2+0x190>
     eb4:	movi	d0, #0x0
     eb8:	cbz	w19, dd4 <pts_ieee754_atan2+0x54>
     ebc:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
     ec0:	fmov	d0, x8
     ec4:	b	dd4 <pts_ieee754_atan2+0x54>
     ec8:	sub	w9, w11, w9
     ecc:	asr	w9, w9, #20
     ed0:	cmp	w9, #0x3d
     ed4:	b.lt	f2c <pts_ieee754_atan2+0x1ac>  // b.tstop
     ed8:	adrp	x8, 0 <pts_ieee754_acos>
     edc:	adrp	x9, 0 <pts_ieee754_acos>
     ee0:	fmov	d0, #5.000000000000000000e-01
     ee4:	ldr	d1, [x8]
     ee8:	ldr	d2, [x9]
     eec:	lsr	w19, w12, #31
     ef0:	fmadd	d2, d1, d0, d2
     ef4:	b	f4c <pts_ieee754_atan2+0x1cc>
     ef8:	cmp	w19, #0x2
     efc:	b.ne	f94 <pts_ieee754_atan2+0x214>  // b.any
     f00:	adrp	x9, 0 <pts_ieee754_acos>
     f04:	ldr	d0, [x8]
     f08:	ldr	d1, [x9]
     f0c:	b	dd0 <pts_ieee754_atan2+0x50>
     f10:	cmp	w19, #0x2
     f14:	b.ne	e64 <pts_ieee754_atan2+0xe4>  // b.any
     f18:	adrp	x8, 0 <pts_ieee754_acos>
     f1c:	adrp	x9, 0 <pts_ieee754_acos>
     f20:	ldr	d0, [x8]
     f24:	ldr	d1, [x9]
     f28:	b	dd0 <pts_ieee754_atan2+0x50>
     f2c:	tbz	x8, #63, f3c <pts_ieee754_atan2+0x1bc>
     f30:	movi	d2, #0x0
     f34:	cmn	w9, #0x3c
     f38:	b.lt	f4c <pts_ieee754_atan2+0x1cc>  // b.tstop
     f3c:	fdiv	d0, d0, d1
     f40:	fabs	d0, d0
     f44:	bl	b80 <pts_ieee754_atan>
     f48:	fmov	d2, d0
     f4c:	cbz	w19, fa8 <pts_ieee754_atan2+0x228>
     f50:	cmp	w19, #0x2
     f54:	b.eq	f68 <pts_ieee754_atan2+0x1e8>  // b.none
     f58:	cmp	w19, #0x1
     f5c:	b.ne	fb0 <pts_ieee754_atan2+0x230>  // b.any
     f60:	fneg	d0, d2
     f64:	b	dd4 <pts_ieee754_atan2+0x54>
     f68:	adrp	x8, 0 <pts_ieee754_acos>
     f6c:	ldr	d0, [x8]
     f70:	adrp	x8, 0 <pts_ieee754_acos>
     f74:	ldr	d1, [x8]
     f78:	fsub	d0, d0, d2
     f7c:	b	dd0 <pts_ieee754_atan2+0x50>
     f80:	adrp	x9, 0 <pts_ieee754_acos>
     f84:	ldr	d0, [x8]
     f88:	ldr	d1, [x9]
     f8c:	fsub	d0, d1, d0
     f90:	b	dd4 <pts_ieee754_atan2+0x54>
     f94:	adrp	x9, 0 <pts_ieee754_acos>
     f98:	ldr	d0, [x8]
     f9c:	ldr	d1, [x9]
     fa0:	fsub	d0, d1, d0
     fa4:	b	dd4 <pts_ieee754_atan2+0x54>
     fa8:	fmov	d0, d2
     fac:	b	dd4 <pts_ieee754_atan2+0x54>
     fb0:	adrp	x8, 0 <pts_ieee754_acos>
     fb4:	ldr	d0, [x8]
     fb8:	adrp	x8, 0 <pts_ieee754_acos>
     fbc:	ldr	d1, [x8]
     fc0:	fsub	d0, d2, d0
     fc4:	b	dd0 <pts_ieee754_atan2+0x50>
     fc8:	nop
     fcc:	nop
     fd0:	nop
     fd4:	nop
     fd8:	nop
     fdc:	nop

0000000000000fe0 <pts_ieee754_cos>:
     fe0:	sub	sp, sp, #0x20
     fe4:	stp	x29, x30, [sp, #16]
     fe8:	add	x29, sp, #0x10
     fec:	fmov	x8, d0
     ff0:	mov	w9, #0x21fb                	// #8699
     ff4:	movk	w9, #0x3fe9, lsl #16
     ff8:	ubfx	x8, x8, #32, #31
     ffc:	cmp	w8, w9
    1000:	b.hi	109c <pts_ieee754_cos+0xbc>  // b.pmore
    1004:	lsr	w9, w8, #22
    1008:	cmp	w9, #0xf8
    100c:	b.hi	101c <pts_ieee754_cos+0x3c>  // b.pmore
    1010:	fcvtzs	w9, d0
    1014:	fmov	d1, #1.000000000000000000e+00
    1018:	cbz	w9, 139c <pts_ieee754_cos+0x3bc>
    101c:	fmul	d1, d0, d0
    1020:	adrp	x9, 0 <pts_ieee754_acos>
    1024:	adrp	x10, 0 <pts_ieee754_acos>
    1028:	ldr	d2, [x9]
    102c:	ldr	d3, [x10]
    1030:	adrp	x9, 0 <pts_ieee754_acos>
    1034:	fmadd	d2, d1, d3, d2
    1038:	ldr	d3, [x9]
    103c:	adrp	x9, 0 <pts_ieee754_acos>
    1040:	fmadd	d2, d1, d2, d3
    1044:	ldr	d3, [x9]
    1048:	adrp	x9, 0 <pts_ieee754_acos>
    104c:	fmadd	d2, d1, d2, d3
    1050:	ldr	d3, [x9]
    1054:	adrp	x9, 0 <pts_ieee754_acos>
    1058:	fmadd	d2, d1, d2, d3
    105c:	ldr	d3, [x9]
    1060:	mov	w9, #0x3333                	// #13107
    1064:	movk	w9, #0x3fd3, lsl #16
    1068:	cmp	w8, w9
    106c:	fmadd	d2, d1, d2, d3
    1070:	fmul	d2, d1, d2
    1074:	b.cs	1164 <pts_ieee754_cos+0x184>  // b.hs, b.nlast
    1078:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    107c:	fmov	d3, x8
    1080:	fmul	d0, d0, d3
    1084:	fmadd	d0, d1, d2, d0
    1088:	fmov	d2, #5.000000000000000000e-01
    108c:	fnmsub	d0, d1, d2, d0
    1090:	fmov	d1, #1.000000000000000000e+00
    1094:	fsub	d1, d1, d0
    1098:	b	139c <pts_ieee754_cos+0x3bc>
    109c:	lsr	w8, w8, #20
    10a0:	cmp	w8, #0x7ff
    10a4:	b.cc	10b0 <pts_ieee754_cos+0xd0>  // b.lo, b.ul, b.last
    10a8:	fsub	d1, d0, d0
    10ac:	b	139c <pts_ieee754_cos+0x3bc>
    10b0:	mov	x0, sp
    10b4:	bl	1400 <__ieee754_rem_pio2>
    10b8:	ldr	d0, [sp]
    10bc:	and	w8, w0, #0x3
    10c0:	cmp	w8, #0x2
    10c4:	b.eq	1230 <pts_ieee754_cos+0x250>  // b.none
    10c8:	cmp	w8, #0x1
    10cc:	b.eq	11ac <pts_ieee754_cos+0x1cc>  // b.none
    10d0:	cbnz	w8, 12d4 <pts_ieee754_cos+0x2f4>
    10d4:	fmov	x8, d0
    10d8:	ldr	d2, [sp, #8]
    10dc:	lsr	x9, x8, #32
    10e0:	ubfx	w9, w9, #22, #9
    10e4:	cmp	w9, #0xf8
    10e8:	b.hi	10f8 <pts_ieee754_cos+0x118>  // b.pmore
    10ec:	fcvtzs	w9, d0
    10f0:	fmov	d1, #1.000000000000000000e+00
    10f4:	cbz	w9, 139c <pts_ieee754_cos+0x3bc>
    10f8:	fmul	d1, d0, d0
    10fc:	adrp	x9, 0 <pts_ieee754_acos>
    1100:	adrp	x10, 0 <pts_ieee754_acos>
    1104:	ldr	d3, [x9]
    1108:	ldr	d4, [x10]
    110c:	adrp	x9, 0 <pts_ieee754_acos>
    1110:	ubfx	x8, x8, #32, #31
    1114:	fmadd	d3, d1, d4, d3
    1118:	ldr	d4, [x9]
    111c:	adrp	x9, 0 <pts_ieee754_acos>
    1120:	fmadd	d3, d1, d3, d4
    1124:	ldr	d4, [x9]
    1128:	adrp	x9, 0 <pts_ieee754_acos>
    112c:	fmadd	d3, d1, d3, d4
    1130:	ldr	d4, [x9]
    1134:	adrp	x9, 0 <pts_ieee754_acos>
    1138:	fmadd	d3, d1, d3, d4
    113c:	ldr	d4, [x9]
    1140:	mov	w9, #0x3333                	// #13107
    1144:	movk	w9, #0x3fd3, lsl #16
    1148:	cmp	w8, w9
    114c:	fmadd	d3, d1, d3, d4
    1150:	fmul	d3, d1, d3
    1154:	b.cs	13ac <pts_ieee754_cos+0x3cc>  // b.hs, b.nlast
    1158:	fnmul	d0, d0, d2
    115c:	fmadd	d0, d1, d3, d0
    1160:	b	1088 <pts_ieee754_cos+0xa8>
    1164:	sub	w9, w8, #0x200, lsl #12
    1168:	mov	x11, #0x8000000000000000    	// #-9223372036854775808
    116c:	fmov	d3, #2.812500000000000000e-01
    1170:	lsl	x9, x9, #32
    1174:	fmov	d5, x11
    1178:	mov	w10, #0x3fe90000            	// #1072234496
    117c:	cmp	w8, w10
    1180:	fmov	d4, x9
    1184:	fmul	d0, d0, d5
    1188:	fcsel	d3, d3, d4, hi	// hi = pmore
    118c:	fmov	d4, #5.000000000000000000e-01
    1190:	fmadd	d0, d1, d2, d0
    1194:	fnmsub	d4, d1, d4, d3
    1198:	fmov	d1, #1.000000000000000000e+00
    119c:	fsub	d1, d1, d3
    11a0:	fsub	d0, d0, d4
    11a4:	fadd	d1, d1, d0
    11a8:	b	139c <pts_ieee754_cos+0x3bc>
    11ac:	fmov	x8, d0
    11b0:	ubfx	x8, x8, #54, #9
    11b4:	cmp	x8, #0xf8
    11b8:	b.hi	11c4 <pts_ieee754_cos+0x1e4>  // b.pmore
    11bc:	fcvtzs	w8, d0
    11c0:	cbz	w8, 1228 <pts_ieee754_cos+0x248>
    11c4:	fmul	d1, d0, d0
    11c8:	adrp	x8, 0 <pts_ieee754_acos>
    11cc:	adrp	x9, 0 <pts_ieee754_acos>
    11d0:	ldr	d2, [x8]
    11d4:	ldr	d3, [x9]
    11d8:	adrp	x8, 0 <pts_ieee754_acos>
    11dc:	fmov	d4, #5.000000000000000000e-01
    11e0:	ldr	d5, [sp, #8]
    11e4:	fmadd	d2, d1, d3, d2
    11e8:	ldr	d3, [x8]
    11ec:	adrp	x8, 0 <pts_ieee754_acos>
    11f0:	fmadd	d2, d1, d2, d3
    11f4:	ldr	d3, [x8]
    11f8:	adrp	x8, 0 <pts_ieee754_acos>
    11fc:	fmadd	d2, d1, d2, d3
    1200:	ldr	d3, [x8]
    1204:	adrp	x8, 0 <pts_ieee754_acos>
    1208:	fmadd	d2, d1, d2, d3
    120c:	fnmul	d3, d1, d0
    1210:	fmul	d2, d3, d2
    1214:	fmadd	d2, d5, d4, d2
    1218:	fnmsub	d1, d1, d2, d5
    121c:	ldr	d2, [x8]
    1220:	fmadd	d1, d3, d2, d1
    1224:	fsub	d0, d0, d1
    1228:	fneg	d1, d0
    122c:	b	139c <pts_ieee754_cos+0x3bc>
    1230:	fmov	x8, d0
    1234:	ldr	d1, [sp, #8]
    1238:	lsr	x9, x8, #32
    123c:	ubfx	w9, w9, #22, #9
    1240:	cmp	w9, #0xf8
    1244:	b.hi	1254 <pts_ieee754_cos+0x274>  // b.pmore
    1248:	fcvtzs	w9, d0
    124c:	fmov	d2, #1.000000000000000000e+00
    1250:	cbz	w9, 1398 <pts_ieee754_cos+0x3b8>
    1254:	fmul	d2, d0, d0
    1258:	adrp	x9, 0 <pts_ieee754_acos>
    125c:	adrp	x10, 0 <pts_ieee754_acos>
    1260:	ldr	d3, [x9]
    1264:	ldr	d4, [x10]
    1268:	adrp	x9, 0 <pts_ieee754_acos>
    126c:	ubfx	x8, x8, #32, #31
    1270:	fmadd	d3, d2, d4, d3
    1274:	ldr	d4, [x9]
    1278:	adrp	x9, 0 <pts_ieee754_acos>
    127c:	fmadd	d3, d2, d3, d4
    1280:	ldr	d4, [x9]
    1284:	adrp	x9, 0 <pts_ieee754_acos>
    1288:	fmadd	d3, d2, d3, d4
    128c:	ldr	d4, [x9]
    1290:	adrp	x9, 0 <pts_ieee754_acos>
    1294:	fmadd	d3, d2, d3, d4
    1298:	ldr	d4, [x9]
    129c:	mov	w9, #0x3333                	// #13107
    12a0:	movk	w9, #0x3fd3, lsl #16
    12a4:	cmp	w8, w9
    12a8:	fmadd	d3, d2, d3, d4
    12ac:	fmul	d3, d2, d3
    12b0:	b.cs	135c <pts_ieee754_cos+0x37c>  // b.hs, b.nlast
    12b4:	fnmul	d0, d0, d1
    12b8:	fmov	d1, #5.000000000000000000e-01
    12bc:	fmadd	d0, d2, d3, d0
    12c0:	fnmsub	d0, d2, d1, d0
    12c4:	fmov	d1, #1.000000000000000000e+00
    12c8:	fsub	d2, d1, d0
    12cc:	fneg	d1, d2
    12d0:	b	139c <pts_ieee754_cos+0x3bc>
    12d4:	fmov	x8, d0
    12d8:	ubfx	x8, x8, #54, #9
    12dc:	cmp	x8, #0xf8
    12e0:	b.hi	12f4 <pts_ieee754_cos+0x314>  // b.pmore
    12e4:	fcvtzs	w8, d0
    12e8:	cbnz	w8, 12f4 <pts_ieee754_cos+0x314>
    12ec:	fmov	d1, d0
    12f0:	b	139c <pts_ieee754_cos+0x3bc>
    12f4:	fmul	d1, d0, d0
    12f8:	adrp	x8, 0 <pts_ieee754_acos>
    12fc:	adrp	x9, 0 <pts_ieee754_acos>
    1300:	ldr	d2, [x8]
    1304:	ldr	d3, [x9]
    1308:	adrp	x8, 0 <pts_ieee754_acos>
    130c:	fmov	d4, #5.000000000000000000e-01
    1310:	ldr	d5, [sp, #8]
    1314:	fmadd	d2, d1, d3, d2
    1318:	ldr	d3, [x8]
    131c:	adrp	x8, 0 <pts_ieee754_acos>
    1320:	fmadd	d2, d1, d2, d3
    1324:	ldr	d3, [x8]
    1328:	adrp	x8, 0 <pts_ieee754_acos>
    132c:	fmadd	d2, d1, d2, d3
    1330:	ldr	d3, [x8]
    1334:	adrp	x8, 0 <pts_ieee754_acos>
    1338:	fmadd	d2, d1, d2, d3
    133c:	fnmul	d3, d1, d0
    1340:	fmul	d2, d3, d2
    1344:	fmadd	d2, d5, d4, d2
    1348:	fnmsub	d1, d1, d2, d5
    134c:	ldr	d2, [x8]
    1350:	fmadd	d1, d3, d2, d1
    1354:	fsub	d1, d0, d1
    1358:	b	139c <pts_ieee754_cos+0x3bc>
    135c:	sub	w9, w8, #0x200, lsl #12
    1360:	fmov	d4, #2.812500000000000000e-01
    1364:	mov	w10, #0x3fe90000            	// #1072234496
    1368:	lsl	x9, x9, #32
    136c:	cmp	w8, w10
    1370:	fnmul	d0, d0, d1
    1374:	fmov	d1, #5.000000000000000000e-01
    1378:	fmov	d5, x9
    137c:	fmadd	d0, d2, d3, d0
    1380:	fcsel	d4, d4, d5, hi	// hi = pmore
    1384:	fnmsub	d1, d2, d1, d4
    1388:	fmov	d2, #1.000000000000000000e+00
    138c:	fsub	d2, d2, d4
    1390:	fsub	d0, d0, d1
    1394:	fadd	d2, d2, d0
    1398:	fneg	d1, d2
    139c:	fmov	d0, d1
    13a0:	ldp	x29, x30, [sp, #16]
    13a4:	add	sp, sp, #0x20
    13a8:	ret
    13ac:	sub	w9, w8, #0x200, lsl #12
    13b0:	fmov	d4, #2.812500000000000000e-01
    13b4:	mov	w10, #0x3fe90000            	// #1072234496
    13b8:	lsl	x9, x9, #32
    13bc:	cmp	w8, w10
    13c0:	fnmul	d0, d0, d2
    13c4:	fmov	d2, #5.000000000000000000e-01
    13c8:	fmov	d5, x9
    13cc:	fmadd	d0, d1, d3, d0
    13d0:	fcsel	d4, d4, d5, hi	// hi = pmore
    13d4:	fnmsub	d2, d1, d2, d4
    13d8:	fmov	d1, #1.000000000000000000e+00
    13dc:	fsub	d1, d1, d4
    13e0:	fsub	d0, d0, d2
    13e4:	b	11a4 <pts_ieee754_cos+0x1c4>
    13e8:	nop
    13ec:	nop
    13f0:	nop
    13f4:	nop
    13f8:	nop
    13fc:	nop

0000000000001400 <__ieee754_rem_pio2>:
    1400:	str	d14, [sp, #-160]!
    1404:	stp	d13, d12, [sp, #16]
    1408:	stp	d11, d10, [sp, #32]
    140c:	stp	d9, d8, [sp, #48]
    1410:	stp	x29, x30, [sp, #64]
    1414:	stp	x28, x27, [sp, #80]
    1418:	stp	x26, x25, [sp, #96]
    141c:	stp	x24, x23, [sp, #112]
    1420:	stp	x22, x21, [sp, #128]
    1424:	stp	x20, x19, [sp, #144]
    1428:	add	x29, sp, #0x40
    142c:	sub	sp, sp, #0x290
    1430:	fmov	x6, d0
    1434:	mov	w9, #0x21fb                	// #8699
    1438:	mov	x5, x0
    143c:	movk	w9, #0x3fe9, lsl #16
    1440:	ubfx	x8, x6, #32, #31
    1444:	cmp	w8, w9
    1448:	b.hi	145c <__ieee754_rem_pio2+0x5c>  // b.pmore
    144c:	mov	w0, wzr
    1450:	str	d0, [x5]
    1454:	str	xzr, [x5, #8]
    1458:	b	22bc <__ieee754_rem_pio2+0xebc>
    145c:	mov	w9, #0xd97b                	// #55675
    1460:	movk	w9, #0x4002, lsl #16
    1464:	cmp	w8, w9
    1468:	b.hi	14ac <__ieee754_rem_pio2+0xac>  // b.pmore
    146c:	lsr	x9, x6, #32
    1470:	cmp	w9, #0x1
    1474:	b.lt	15bc <__ieee754_rem_pio2+0x1bc>  // b.tstop
    1478:	adrp	x9, 0 <pts_ieee754_acos>
    147c:	ldr	d1, [x9]
    1480:	mov	w9, #0x21fb                	// #8699
    1484:	movk	w9, #0x3ff9, lsl #16
    1488:	fadd	d0, d0, d1
    148c:	cmp	w8, w9
    1490:	b.ne	15f0 <__ieee754_rem_pio2+0x1f0>  // b.any
    1494:	adrp	x8, 0 <pts_ieee754_acos>
    1498:	ldr	d1, [x8]
    149c:	adrp	x8, 0 <pts_ieee754_acos>
    14a0:	fadd	d0, d0, d1
    14a4:	ldr	d1, [x8]
    14a8:	b	15f8 <__ieee754_rem_pio2+0x1f8>
    14ac:	mov	w9, #0x21fb                	// #8699
    14b0:	movk	w9, #0x4139, lsl #16
    14b4:	cmp	w8, w9
    14b8:	b.hi	15a0 <__ieee754_rem_pio2+0x1a0>  // b.pmore
    14bc:	fabs	d0, d0
    14c0:	adrp	x9, 0 <pts_ieee754_acos>
    14c4:	fmov	d1, #5.000000000000000000e-01
    14c8:	ldr	d2, [x9]
    14cc:	adrp	x9, 0 <pts_ieee754_acos>
    14d0:	adrp	x10, 0 <pts_ieee754_acos>
    14d4:	ldr	d3, [x10]
    14d8:	fmadd	d1, d0, d2, d1
    14dc:	fcvtzs	w0, d1
    14e0:	ldr	d1, [x9]
    14e4:	scvtf	d2, w0
    14e8:	cmp	w0, #0x1f
    14ec:	fmadd	d1, d2, d1, d0
    14f0:	fmul	d0, d2, d3
    14f4:	b.gt	1510 <__ieee754_rem_pio2+0x110>
    14f8:	adrp	x9, 0 <pts_ieee754_acos>
    14fc:	add	x9, x9, #0x0
    1500:	add	x9, x9, w0, sxtw #2
    1504:	ldur	w9, [x9, #-4]
    1508:	cmp	w8, w9
    150c:	b.ne	1594 <__ieee754_rem_pio2+0x194>  // b.any
    1510:	fsub	d3, d1, d0
    1514:	lsr	w8, w8, #20
    1518:	fmov	x9, d3
    151c:	str	d3, [x5]
    1520:	ubfx	x9, x9, #52, #11
    1524:	sub	w9, w8, w9
    1528:	cmp	w9, #0x11
    152c:	b.lt	1770 <__ieee754_rem_pio2+0x370>  // b.tstop
    1530:	adrp	x9, 0 <pts_ieee754_acos>
    1534:	ldr	d0, [x9]
    1538:	adrp	x9, 0 <pts_ieee754_acos>
    153c:	fmul	d0, d2, d0
    1540:	fsub	d4, d1, d0
    1544:	fsub	d1, d1, d4
    1548:	fsub	d0, d1, d0
    154c:	ldr	d1, [x9]
    1550:	fnmsub	d0, d2, d1, d0
    1554:	fsub	d3, d4, d0
    1558:	fmov	x9, d3
    155c:	str	d3, [x5]
    1560:	ubfx	x9, x9, #52, #11
    1564:	sub	w8, w8, w9
    1568:	cmp	w8, #0x32
    156c:	b.lt	176c <__ieee754_rem_pio2+0x36c>  // b.tstop
    1570:	adrp	x8, 0 <pts_ieee754_acos>
    1574:	ldr	d0, [x8]
    1578:	adrp	x8, 0 <pts_ieee754_acos>
    157c:	fmul	d0, d2, d0
    1580:	fsub	d1, d4, d0
    1584:	fsub	d3, d4, d1
    1588:	fsub	d0, d3, d0
    158c:	ldr	d3, [x8]
    1590:	fnmsub	d0, d2, d3, d0
    1594:	fsub	d3, d1, d0
    1598:	str	d3, [x5]
    159c:	b	1770 <__ieee754_rem_pio2+0x370>
    15a0:	lsr	w10, w8, #20
    15a4:	cmp	w10, #0x7ff
    15a8:	b.cc	1604 <__ieee754_rem_pio2+0x204>  // b.lo, b.ul, b.last
    15ac:	fsub	d0, d0, d0
    15b0:	mov	w0, wzr
    15b4:	stp	d0, d0, [x5]
    15b8:	b	22bc <__ieee754_rem_pio2+0xebc>
    15bc:	adrp	x9, 0 <pts_ieee754_acos>
    15c0:	ldr	d1, [x9]
    15c4:	mov	w9, #0x21fb                	// #8699
    15c8:	movk	w9, #0x3ff9, lsl #16
    15cc:	fadd	d0, d0, d1
    15d0:	cmp	w8, w9
    15d4:	b.ne	1714 <__ieee754_rem_pio2+0x314>  // b.any
    15d8:	adrp	x8, 0 <pts_ieee754_acos>
    15dc:	ldr	d1, [x8]
    15e0:	adrp	x8, 0 <pts_ieee754_acos>
    15e4:	fadd	d0, d0, d1
    15e8:	ldr	d1, [x8]
    15ec:	b	171c <__ieee754_rem_pio2+0x31c>
    15f0:	adrp	x8, 0 <pts_ieee754_acos>
    15f4:	ldr	d1, [x8]
    15f8:	fadd	d2, d0, d1
    15fc:	mov	w0, #0x1                   	// #1
    1600:	b	1724 <__ieee754_rem_pio2+0x324>
    1604:	sub	w9, w10, #0x416
    1608:	mov	x12, x6
    160c:	mov	x23, xzr
    1610:	sub	w8, w8, w9, lsl #20
    1614:	mov	x11, xzr
    1618:	bfi	x12, x8, #32, #32
    161c:	fmov	d0, x12
    1620:	mov	x12, #0x4170000000000000    	// #4715268809856909312
    1624:	fmov	d2, x12
    1628:	mov	x12, #0xffffffff00000000    	// #-4294967296
    162c:	fcvtzs	w8, d0
    1630:	scvtf	d1, w8
    1634:	fsub	d0, d0, d1
    1638:	fcvtzs	w8, d0, #24
    163c:	fmul	d0, d0, d2
    1640:	scvtf	d3, w8
    1644:	add	x8, sp, #0x38
    1648:	add	x8, x8, #0x10
    164c:	fsub	d0, d0, d3
    1650:	stp	d1, d3, [sp, #56]
    1654:	fmul	d0, d0, d2
    1658:	str	d0, [sp, #72]
    165c:	ldr	d0, [x8, x23, lsl #3]
    1660:	add	x11, x11, x12
    1664:	sub	x23, x23, #0x1
    1668:	fcmp	d0, #0.0
    166c:	b.eq	165c <__ieee754_rem_pio2+0x25c>  // b.none
    1670:	sub	w8, w10, #0x419
    1674:	mov	w10, #0xaaab                	// #43691
    1678:	mov	w12, #0xffffffe8            	// #-24
    167c:	movk	w10, #0x2aaa, lsl #16
    1680:	stp	x6, x5, [sp, #8]
    1684:	smull	x8, w8, w10
    1688:	lsr	x10, x8, #63
    168c:	asr	x8, x8, #34
    1690:	add	w8, w8, w10
    1694:	add	x10, x23, #0x4
    1698:	madd	w9, w8, w12, w9
    169c:	cmn	w10, #0x3
    16a0:	stur	w9, [x29, #-52]
    16a4:	adrp	x9, 0 <pts_ieee754_acos>
    16a8:	add	x9, x9, #0x0
    16ac:	b.lt	1754 <__ieee754_rem_pio2+0x354>  // b.tstop
    16b0:	add	x12, x23, #0x7
    16b4:	mov	x13, #0x300000000           	// #12884901888
    16b8:	mov	x14, #0x400000000           	// #17179869184
    16bc:	bic	w0, w12, w12, asr #31
    16c0:	mov	x17, #0x500000000           	// #21474836480
    16c4:	add	x16, x11, x13
    16c8:	mov	x13, #0x600000000           	// #25769803776
    16cc:	sub	w18, w8, w23
    16d0:	add	x15, x11, x14
    16d4:	add	x14, x11, x17
    16d8:	add	x13, x11, x13
    16dc:	add	x17, x23, #0x3
    16e0:	sub	w18, w18, #0x3
    16e4:	add	x0, x0, #0x1
    16e8:	add	x1, sp, #0x198
    16ec:	b	1708 <__ieee754_rem_pio2+0x308>
    16f0:	ldr	w2, [x9, w18, uxtw #2]
    16f4:	scvtf	d0, w2
    16f8:	subs	x0, x0, #0x1
    16fc:	add	w18, w18, #0x1
    1700:	str	d0, [x1], #8
    1704:	b.eq	1734 <__ieee754_rem_pio2+0x334>  // b.none
    1708:	tbz	w18, #31, 16f0 <__ieee754_rem_pio2+0x2f0>
    170c:	movi	d0, #0x0
    1710:	b	16f8 <__ieee754_rem_pio2+0x2f8>
    1714:	adrp	x8, 0 <pts_ieee754_acos>
    1718:	ldr	d1, [x8]
    171c:	fadd	d2, d0, d1
    1720:	mov	w0, #0xffffffff            	// #-1
    1724:	fsub	d0, d0, d2
    1728:	fadd	d0, d0, d1
    172c:	stp	d2, d0, [x5]
    1730:	b	22bc <__ieee754_rem_pio2+0xebc>
    1734:	cmp	w10, #0x0
    1738:	b.le	1754 <__ieee754_rem_pio2+0x354>
    173c:	movi	d0, #0x0
    1740:	and	x24, x10, #0xffffffff
    1744:	cmp	x24, #0x8
    1748:	b.cs	1790 <__ieee754_rem_pio2+0x390>  // b.hs, b.nlast
    174c:	mov	x17, xzr
    1750:	b	1818 <__ieee754_rem_pio2+0x418>
    1754:	movi	v1.2d, #0x0
    1758:	mov	w26, wzr
    175c:	movi	d0, #0x0
    1760:	and	x24, x10, #0xffffffff
    1764:	stp	q1, q1, [sp, #80]
    1768:	b	1bd8 <__ieee754_rem_pio2+0x7d8>
    176c:	fmov	d1, d4
    1770:	fsub	d1, d1, d3
    1774:	fsub	d0, d1, d0
    1778:	str	d0, [x5, #8]
    177c:	tbz	x6, #63, 22bc <__ieee754_rem_pio2+0xebc>
    1780:	fneg	d1, d3
    1784:	fneg	d0, d0
    1788:	stp	d1, d0, [x5]
    178c:	b	22b8 <__ieee754_rem_pio2+0xeb8>
    1790:	sub	x18, x24, #0x1
    1794:	sub	w0, w17, w18
    1798:	cmp	w0, w17
    179c:	mov	x17, xzr
    17a0:	b.gt	1818 <__ieee754_rem_pio2+0x418>
    17a4:	lsr	x18, x18, #32
    17a8:	cbnz	x18, 1818 <__ieee754_rem_pio2+0x418>
    17ac:	and	x18, x10, #0x3
    17b0:	add	x0, sp, #0x38
    17b4:	add	w1, w23, #0x4
    17b8:	sub	x17, x24, x18
    17bc:	add	x0, x0, #0x10
    17c0:	sub	x1, x1, x18
    17c4:	add	x2, sp, #0x198
    17c8:	mov	x3, #0xfffffffc00000000    	// #-17179869184
    17cc:	add	x4, x2, x16, asr #29
    17d0:	ldp	q2, q3, [x0, #-16]
    17d4:	subs	x1, x1, #0x4
    17d8:	add	x0, x0, #0x20
    17dc:	add	x16, x16, x3
    17e0:	ldur	q1, [x4, #-8]
    17e4:	ext	v1.16b, v1.16b, v1.16b, #8
    17e8:	fmul	v1.2d, v2.2d, v1.2d
    17ec:	ldur	q2, [x4, #-24]
    17f0:	ext	v2.16b, v2.16b, v2.16b, #8
    17f4:	mov	d4, v1.d[1]
    17f8:	fadd	d0, d0, d1
    17fc:	fmul	v1.2d, v3.2d, v2.2d
    1800:	fadd	d0, d0, d4
    1804:	mov	d2, v1.d[1]
    1808:	fadd	d0, d0, d1
    180c:	fadd	d0, d0, d2
    1810:	b.ne	17cc <__ieee754_rem_pio2+0x3cc>  // b.any
    1814:	cbz	x18, 1858 <__ieee754_rem_pio2+0x458>
    1818:	sub	x18, x11, x17, lsl #32
    181c:	add	x16, sp, #0x38
    1820:	mov	x0, #0x300000000           	// #12884901888
    1824:	add	w1, w23, #0x4
    1828:	add	x16, x16, x17, lsl #3
    182c:	add	x18, x18, x0
    1830:	sub	x17, x1, x17
    1834:	add	x0, sp, #0x198
    1838:	mov	x1, #0xffffffff00000000    	// #-4294967296
    183c:	asr	x2, x18, #29
    1840:	ldr	d1, [x16], #8
    1844:	subs	x17, x17, #0x1
    1848:	add	x18, x18, x1
    184c:	ldr	d2, [x0, x2]
    1850:	fmadd	d0, d1, d2, d0
    1854:	b.ne	183c <__ieee754_rem_pio2+0x43c>  // b.any
    1858:	movi	d1, #0x0
    185c:	cmp	x24, #0x8
    1860:	str	d0, [sp, #80]
    1864:	b.cs	1870 <__ieee754_rem_pio2+0x470>  // b.hs, b.nlast
    1868:	mov	x16, xzr
    186c:	b	18f8 <__ieee754_rem_pio2+0x4f8>
    1870:	sub	x17, x24, #0x1
    1874:	sub	w16, w10, w17
    1878:	cmp	w16, w10
    187c:	mov	x16, xzr
    1880:	b.gt	18f8 <__ieee754_rem_pio2+0x4f8>
    1884:	lsr	x17, x17, #32
    1888:	cbnz	x17, 18f8 <__ieee754_rem_pio2+0x4f8>
    188c:	and	x17, x10, #0x3
    1890:	add	x18, sp, #0x38
    1894:	add	w0, w23, #0x4
    1898:	sub	x16, x24, x17
    189c:	add	x18, x18, #0x10
    18a0:	sub	x0, x0, x17
    18a4:	add	x1, sp, #0x198
    18a8:	mov	x2, #0xfffffffc00000000    	// #-17179869184
    18ac:	add	x3, x1, x15, asr #29
    18b0:	ldp	q2, q3, [x18, #-16]
    18b4:	subs	x0, x0, #0x4
    18b8:	add	x18, x18, #0x20
    18bc:	add	x15, x15, x2
    18c0:	ldur	q0, [x3, #-8]
    18c4:	ext	v0.16b, v0.16b, v0.16b, #8
    18c8:	fmul	v0.2d, v2.2d, v0.2d
    18cc:	ldur	q2, [x3, #-24]
    18d0:	ext	v2.16b, v2.16b, v2.16b, #8
    18d4:	mov	d4, v0.d[1]
    18d8:	fadd	d0, d1, d0
    18dc:	fmul	v1.2d, v3.2d, v2.2d
    18e0:	fadd	d0, d0, d4
    18e4:	mov	d2, v1.d[1]
    18e8:	fadd	d0, d0, d1
    18ec:	fadd	d1, d0, d2
    18f0:	b.ne	18ac <__ieee754_rem_pio2+0x4ac>  // b.any
    18f4:	cbz	x17, 1938 <__ieee754_rem_pio2+0x538>
    18f8:	sub	x17, x11, x16, lsl #32
    18fc:	add	x15, sp, #0x38
    1900:	mov	x18, #0x400000000           	// #17179869184
    1904:	add	w0, w23, #0x4
    1908:	add	x15, x15, x16, lsl #3
    190c:	add	x17, x17, x18
    1910:	sub	x16, x0, x16
    1914:	add	x18, sp, #0x198
    1918:	mov	x0, #0xffffffff00000000    	// #-4294967296
    191c:	asr	x1, x17, #29
    1920:	ldr	d0, [x15], #8
    1924:	subs	x16, x16, #0x1
    1928:	add	x17, x17, x0
    192c:	ldr	d2, [x18, x1]
    1930:	fmadd	d1, d0, d2, d1
    1934:	b.ne	191c <__ieee754_rem_pio2+0x51c>  // b.any
    1938:	movi	d0, #0x0
    193c:	cmp	x24, #0xa
    1940:	str	d1, [sp, #88]
    1944:	b.cs	1950 <__ieee754_rem_pio2+0x550>  // b.hs, b.nlast
    1948:	mov	x15, xzr
    194c:	b	19dc <__ieee754_rem_pio2+0x5dc>
    1950:	sub	x16, x24, #0x1
    1954:	add	w15, w23, #0x5
    1958:	sub	w17, w15, w16
    195c:	cmp	w17, w15
    1960:	mov	x15, xzr
    1964:	b.gt	19dc <__ieee754_rem_pio2+0x5dc>
    1968:	lsr	x16, x16, #32
    196c:	cbnz	x16, 19dc <__ieee754_rem_pio2+0x5dc>
    1970:	and	x16, x10, #0x3
    1974:	add	x17, sp, #0x38
    1978:	add	w18, w23, #0x4
    197c:	sub	x15, x24, x16
    1980:	add	x17, x17, #0x10
    1984:	sub	x18, x18, x16
    1988:	add	x0, sp, #0x198
    198c:	mov	x1, #0xfffffffc00000000    	// #-17179869184
    1990:	add	x2, x0, x14, asr #29
    1994:	ldp	q2, q3, [x17, #-16]
    1998:	subs	x18, x18, #0x4
    199c:	add	x17, x17, #0x20
    19a0:	add	x14, x14, x1
    19a4:	ldur	q1, [x2, #-8]
    19a8:	ext	v1.16b, v1.16b, v1.16b, #8
    19ac:	fmul	v1.2d, v2.2d, v1.2d
    19b0:	ldur	q2, [x2, #-24]
    19b4:	ext	v2.16b, v2.16b, v2.16b, #8
    19b8:	mov	d4, v1.d[1]
    19bc:	fadd	d0, d0, d1
    19c0:	fmul	v1.2d, v3.2d, v2.2d
    19c4:	fadd	d0, d0, d4
    19c8:	mov	d2, v1.d[1]
    19cc:	fadd	d0, d0, d1
    19d0:	fadd	d0, d0, d2
    19d4:	b.ne	1990 <__ieee754_rem_pio2+0x590>  // b.any
    19d8:	cbz	x16, 1a1c <__ieee754_rem_pio2+0x61c>
    19dc:	sub	x16, x11, x15, lsl #32
    19e0:	add	x14, sp, #0x38
    19e4:	mov	x17, #0x500000000           	// #21474836480
    19e8:	add	w18, w23, #0x4
    19ec:	add	x14, x14, x15, lsl #3
    19f0:	add	x16, x16, x17
    19f4:	sub	x15, x18, x15
    19f8:	add	x17, sp, #0x198
    19fc:	mov	x18, #0xffffffff00000000    	// #-4294967296
    1a00:	asr	x0, x16, #29
    1a04:	ldr	d1, [x14], #8
    1a08:	subs	x15, x15, #0x1
    1a0c:	add	x16, x16, x18
    1a10:	ldr	d2, [x17, x0]
    1a14:	fmadd	d0, d1, d2, d0
    1a18:	b.ne	1a00 <__ieee754_rem_pio2+0x600>  // b.any
    1a1c:	movi	d1, #0x0
    1a20:	cmp	x24, #0xa
    1a24:	str	d0, [sp, #96]
    1a28:	b.cs	1a34 <__ieee754_rem_pio2+0x634>  // b.hs, b.nlast
    1a2c:	mov	x14, xzr
    1a30:	b	1ac0 <__ieee754_rem_pio2+0x6c0>
    1a34:	sub	x15, x24, #0x1
    1a38:	add	w14, w23, #0x6
    1a3c:	sub	w16, w14, w15
    1a40:	cmp	w16, w14
    1a44:	mov	x14, xzr
    1a48:	b.gt	1ac0 <__ieee754_rem_pio2+0x6c0>
    1a4c:	lsr	x15, x15, #32
    1a50:	cbnz	x15, 1ac0 <__ieee754_rem_pio2+0x6c0>
    1a54:	and	x15, x10, #0x3
    1a58:	add	x16, sp, #0x38
    1a5c:	add	w17, w23, #0x4
    1a60:	sub	x14, x24, x15
    1a64:	add	x16, x16, #0x10
    1a68:	sub	x17, x17, x15
    1a6c:	add	x18, sp, #0x198
    1a70:	mov	x0, #0xfffffffc00000000    	// #-17179869184
    1a74:	add	x1, x18, x13, asr #29
    1a78:	ldp	q2, q3, [x16, #-16]
    1a7c:	subs	x17, x17, #0x4
    1a80:	add	x16, x16, #0x20
    1a84:	add	x13, x13, x0
    1a88:	ldur	q0, [x1, #-8]
    1a8c:	ext	v0.16b, v0.16b, v0.16b, #8
    1a90:	fmul	v0.2d, v2.2d, v0.2d
    1a94:	ldur	q2, [x1, #-24]
    1a98:	ext	v2.16b, v2.16b, v2.16b, #8
    1a9c:	mov	d4, v0.d[1]
    1aa0:	fadd	d0, d1, d0
    1aa4:	fmul	v1.2d, v3.2d, v2.2d
    1aa8:	fadd	d0, d0, d4
    1aac:	mov	d2, v1.d[1]
    1ab0:	fadd	d0, d0, d1
    1ab4:	fadd	d1, d0, d2
    1ab8:	b.ne	1a74 <__ieee754_rem_pio2+0x674>  // b.any
    1abc:	cbz	x15, 1b00 <__ieee754_rem_pio2+0x700>
    1ac0:	sub	x13, x11, x14, lsl #32
    1ac4:	add	x11, sp, #0x38
    1ac8:	mov	x15, #0x600000000           	// #25769803776
    1acc:	add	w16, w23, #0x4
    1ad0:	add	x11, x11, x14, lsl #3
    1ad4:	add	x13, x13, x15
    1ad8:	sub	x14, x16, x14
    1adc:	add	x15, sp, #0x198
    1ae0:	mov	x16, #0xffffffff00000000    	// #-4294967296
    1ae4:	asr	x17, x13, #29
    1ae8:	ldr	d0, [x11], #8
    1aec:	subs	x14, x14, #0x1
    1af0:	add	x13, x13, x16
    1af4:	ldr	d2, [x15, x17]
    1af8:	fmadd	d1, d0, d2, d1
    1afc:	b.ne	1ae4 <__ieee754_rem_pio2+0x6e4>  // b.any
    1b00:	movi	d0, #0x0
    1b04:	cmp	x24, #0xa
    1b08:	str	d1, [sp, #104]
    1b0c:	b.cs	1b18 <__ieee754_rem_pio2+0x718>  // b.hs, b.nlast
    1b10:	mov	x11, xzr
    1b14:	b	1ba0 <__ieee754_rem_pio2+0x7a0>
    1b18:	sub	x13, x24, #0x1
    1b1c:	sub	w11, w12, w13
    1b20:	cmp	w11, w12
    1b24:	mov	x11, xzr
    1b28:	b.gt	1ba0 <__ieee754_rem_pio2+0x7a0>
    1b2c:	lsr	x12, x13, #32
    1b30:	cbnz	x12, 1ba0 <__ieee754_rem_pio2+0x7a0>
    1b34:	and	x10, x10, #0x3
    1b38:	add	x12, sp, #0x38
    1b3c:	add	w13, w23, #0x4
    1b40:	sub	x11, x24, x10
    1b44:	add	x12, x12, #0x10
    1b48:	sub	x13, x13, x10
    1b4c:	add	w14, w23, #0x7
    1b50:	add	x15, sp, #0x198
    1b54:	add	x16, x15, w14, sxtw #3
    1b58:	ldp	q2, q3, [x12, #-16]
    1b5c:	sub	x13, x13, #0x4
    1b60:	add	x12, x12, #0x20
    1b64:	sub	w14, w14, #0x4
    1b68:	ldur	q1, [x16, #-8]
    1b6c:	ext	v1.16b, v1.16b, v1.16b, #8
    1b70:	fmul	v1.2d, v2.2d, v1.2d
    1b74:	ldur	q2, [x16, #-24]
    1b78:	ext	v2.16b, v2.16b, v2.16b, #8
    1b7c:	mov	d4, v1.d[1]
    1b80:	fadd	d0, d0, d1
    1b84:	fmul	v1.2d, v3.2d, v2.2d
    1b88:	fadd	d0, d0, d4
    1b8c:	mov	d2, v1.d[1]
    1b90:	fadd	d0, d0, d1
    1b94:	fadd	d0, d0, d2
    1b98:	cbnz	x13, 1b54 <__ieee754_rem_pio2+0x754>
    1b9c:	cbz	x10, 1bd4 <__ieee754_rem_pio2+0x7d4>
    1ba0:	add	x10, sp, #0x38
    1ba4:	add	w12, w23, #0x4
    1ba8:	sub	w13, w23, w11
    1bac:	add	x10, x10, x11, lsl #3
    1bb0:	sub	x11, x12, x11
    1bb4:	add	w12, w13, #0x7
    1bb8:	add	x13, sp, #0x198
    1bbc:	ldr	d1, [x10], #8
    1bc0:	ldr	d2, [x13, w12, sxtw #3]
    1bc4:	sub	x11, x11, #0x1
    1bc8:	sub	w12, w12, #0x1
    1bcc:	fmadd	d0, d1, d2, d0
    1bd0:	cbnz	x11, 1bbc <__ieee754_rem_pio2+0x7bc>
    1bd4:	mov	w26, #0x1                   	// #1
    1bd8:	ldur	w12, [x29, #-52]
    1bdc:	add	x22, x9, w8, sxtw #2
    1be0:	sub	x8, x29, #0x98
    1be4:	mov	w10, #0x30                  	// #48
    1be8:	sub	x9, x8, #0x10
    1bec:	mov	w11, #0x2f                  	// #47
    1bf0:	sub	w10, w10, w12
    1bf4:	str	x9, [sp, #24]
    1bf8:	add	x9, sp, #0x38
    1bfc:	sub	x28, x8, #0x4
    1c00:	add	x21, sp, #0x198
    1c04:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1c08:	stur	w10, [x29, #-56]
    1c0c:	sub	w10, w11, w12
    1c10:	add	x15, x9, #0x10
    1c14:	sub	x16, x21, #0x8
    1c18:	fmov	d13, x8
    1c1c:	mov	x8, #0xc170000000000000    	// #-4508103226997866496
    1c20:	sub	w25, w12, #0x18
    1c24:	str	d0, [sp, #112]
    1c28:	and	x19, x24, #0xfffffffc
    1c2c:	str	w10, [sp, #36]
    1c30:	fmov	d9, #1.250000000000000000e-01
    1c34:	fmov	d10, #-8.000000000000000000e+00
    1c38:	fmov	d11, #1.000000000000000000e+00
    1c3c:	fmov	d12, #5.000000000000000000e-01
    1c40:	fmov	d14, x8
    1c44:	add	x20, sp, #0x50
    1c48:	mov	w8, #0x4                   	// #4
    1c4c:	stp	x16, x15, [sp, #40]
    1c50:	b	1c58 <__ieee754_rem_pio2+0x858>
    1c54:	ldr	d0, [x20, x8, lsl #3]
    1c58:	mov	w27, w8
    1c5c:	sub	x9, x29, #0x98
    1c60:	sub	x8, x27, #0x1
    1c64:	fmul	d1, d0, d13
    1c68:	ldr	d2, [x20, x8, lsl #3]
    1c6c:	sub	x8, x8, #0x1
    1c70:	cmn	x8, #0x1
    1c74:	fcvtzs	w10, d1
    1c78:	scvtf	d1, w10
    1c7c:	fmadd	d0, d1, d14, d0
    1c80:	fcvtzs	w10, d0
    1c84:	fadd	d0, d2, d1
    1c88:	str	w10, [x9], #4
    1c8c:	b.ne	1c64 <__ieee754_rem_pio2+0x864>  // b.any
    1c90:	mov	w0, w25
    1c94:	bl	0 <scalbn>
    1c98:	fmul	d1, d0, d9
    1c9c:	ldur	w8, [x29, #-52]
    1ca0:	cmp	w8, #0x19
    1ca4:	frintm	d1, d1
    1ca8:	fmadd	d0, d1, d10, d0
    1cac:	fcvtzs	w13, d0
    1cb0:	scvtf	d1, w13
    1cb4:	fsub	d8, d0, d1
    1cb8:	b.lt	1cec <__ieee754_rem_pio2+0x8ec>  // b.tstop
    1cbc:	sub	x8, x29, #0x98
    1cc0:	ldur	w11, [x29, #-56]
    1cc4:	add	x8, x8, w27, sxtw #2
    1cc8:	ldur	w9, [x8, #-4]
    1ccc:	asr	w10, w9, w11
    1cd0:	lsl	w11, w10, w11
    1cd4:	add	w13, w10, w13
    1cd8:	sub	w9, w9, w11
    1cdc:	ldr	w11, [sp, #36]
    1ce0:	stur	w9, [x8, #-4]
    1ce4:	asr	w17, w9, w11
    1ce8:	b	1d18 <__ieee754_rem_pio2+0x918>
    1cec:	cbz	w25, 1d08 <__ieee754_rem_pio2+0x908>
    1cf0:	fcmp	d8, d12
    1cf4:	ldp	x16, x15, [sp, #40]
    1cf8:	add	x14, sp, #0x38
    1cfc:	b.ge	1d2c <__ieee754_rem_pio2+0x92c>  // b.tcont
    1d00:	mov	w17, wzr
    1d04:	b	1df4 <__ieee754_rem_pio2+0x9f4>
    1d08:	sub	x8, x29, #0x98
    1d0c:	add	x8, x8, w27, sxtw #2
    1d10:	ldur	w8, [x8, #-4]
    1d14:	asr	w17, w8, #23
    1d18:	ldp	x16, x15, [sp, #40]
    1d1c:	add	x14, sp, #0x38
    1d20:	cmp	w17, #0x1
    1d24:	b.ge	1d30 <__ieee754_rem_pio2+0x930>  // b.tcont
    1d28:	b	1df4 <__ieee754_rem_pio2+0x9f4>
    1d2c:	mov	w17, #0x2                   	// #2
    1d30:	mov	w11, wzr
    1d34:	sub	x9, x29, #0x98
    1d38:	mov	x10, x27
    1d3c:	b	1d60 <__ieee754_rem_pio2+0x960>
    1d40:	mov	w11, #0xffffff              	// #16777215
    1d44:	sub	w11, w11, w12
    1d48:	mov	w8, wzr
    1d4c:	str	w11, [x9]
    1d50:	mov	w11, #0x1                   	// #1
    1d54:	subs	x10, x10, #0x1
    1d58:	add	x9, x9, #0x4
    1d5c:	b.eq	1d80 <__ieee754_rem_pio2+0x980>  // b.none
    1d60:	ldr	w12, [x9]
    1d64:	cbnz	w11, 1d40 <__ieee754_rem_pio2+0x940>
    1d68:	cbz	w12, 1d74 <__ieee754_rem_pio2+0x974>
    1d6c:	mov	w11, #0x1000000             	// #16777216
    1d70:	b	1d44 <__ieee754_rem_pio2+0x944>
    1d74:	mov	w11, wzr
    1d78:	mov	w8, #0x1                   	// #1
    1d7c:	b	1d54 <__ieee754_rem_pio2+0x954>
    1d80:	ldur	w9, [x29, #-52]
    1d84:	cmp	w9, #0x19
    1d88:	b.lt	1dbc <__ieee754_rem_pio2+0x9bc>  // b.tstop
    1d8c:	b.eq	1da4 <__ieee754_rem_pio2+0x9a4>  // b.none
    1d90:	ldur	w9, [x29, #-52]
    1d94:	cmp	w9, #0x1a
    1d98:	b.ne	1dbc <__ieee754_rem_pio2+0x9bc>  // b.any
    1d9c:	mov	w9, #0x3fffff              	// #4194303
    1da0:	b	1da8 <__ieee754_rem_pio2+0x9a8>
    1da4:	mov	w9, #0x7fffff              	// #8388607
    1da8:	sub	x10, x29, #0x98
    1dac:	add	x10, x10, w27, sxtw #2
    1db0:	ldur	w11, [x10, #-4]
    1db4:	and	w9, w11, w9
    1db8:	stur	w9, [x10, #-4]
    1dbc:	cmp	w17, #0x2
    1dc0:	add	w13, w13, #0x1
    1dc4:	b.ne	1df0 <__ieee754_rem_pio2+0x9f0>  // b.any
    1dc8:	fsub	d8, d11, d8
    1dcc:	tbnz	w8, #0, 1df0 <__ieee754_rem_pio2+0x9f0>
    1dd0:	fmov	d0, #1.000000000000000000e+00
    1dd4:	mov	w0, w25
    1dd8:	str	w13, [sp, #32]
    1ddc:	bl	0 <scalbn>
    1de0:	fsub	d8, d8, d0
    1de4:	ldp	x16, x15, [sp, #40]
    1de8:	ldr	w13, [sp, #32]
    1dec:	add	x14, sp, #0x38
    1df0:	mov	w17, #0x2                   	// #2
    1df4:	fcmp	d8, #0.0
    1df8:	b.ne	1fb4 <__ieee754_rem_pio2+0xbb4>  // b.any
    1dfc:	cmp	w27, #0x5
    1e00:	b.cc	1e98 <__ieee754_rem_pio2+0xa98>  // b.lo, b.ul, b.last
    1e04:	sub	x9, x27, #0x4
    1e08:	cmp	x9, #0x8
    1e0c:	b.cs	1e1c <__ieee754_rem_pio2+0xa1c>  // b.hs, b.nlast
    1e10:	mov	w9, wzr
    1e14:	mov	x8, x27
    1e18:	b	1e80 <__ieee754_rem_pio2+0xa80>
    1e1c:	movi	v0.2d, #0x0
    1e20:	movi	v1.2d, #0x0
    1e24:	ldr	x8, [sp, #24]
    1e28:	and	x10, x9, #0xfffffffffffffff8
    1e2c:	add	x11, x8, x27, lsl #2
    1e30:	sub	x8, x27, x10
    1e34:	mov	x12, x10
    1e38:	ldp	q3, q2, [x11, #-16]
    1e3c:	subs	x12, x12, #0x8
    1e40:	sub	x11, x11, #0x20
    1e44:	rev64	v2.4s, v2.4s
    1e48:	rev64	v3.4s, v3.4s
    1e4c:	ext	v2.16b, v2.16b, v2.16b, #8
    1e50:	ext	v3.16b, v3.16b, v3.16b, #8
    1e54:	orr	v0.16b, v2.16b, v0.16b
    1e58:	orr	v1.16b, v3.16b, v1.16b
    1e5c:	b.ne	1e38 <__ieee754_rem_pio2+0xa38>  // b.any
    1e60:	orr	v0.16b, v1.16b, v0.16b
    1e64:	cmp	x9, x10
    1e68:	ext	v1.16b, v0.16b, v0.16b, #8
    1e6c:	orr	v0.8b, v0.8b, v1.8b
    1e70:	fmov	x11, d0
    1e74:	lsr	x12, x11, #32
    1e78:	orr	w9, w11, w12
    1e7c:	b.eq	1e94 <__ieee754_rem_pio2+0xa94>  // b.none
    1e80:	ldr	w10, [x28, x8, lsl #2]
    1e84:	cmp	x8, #0x5
    1e88:	sub	x8, x8, #0x1
    1e8c:	orr	w9, w10, w9
    1e90:	b.gt	1e80 <__ieee754_rem_pio2+0xa80>
    1e94:	cbnz	w9, 2184 <__ieee754_rem_pio2+0xd84>
    1e98:	ldur	w8, [x29, #-140]
    1e9c:	cbz	w8, 1ea8 <__ieee754_rem_pio2+0xaa8>
    1ea0:	mov	w8, #0x1                   	// #1
    1ea4:	b	1ed8 <__ieee754_rem_pio2+0xad8>
    1ea8:	ldur	w8, [x29, #-144]
    1eac:	cbz	w8, 1eb8 <__ieee754_rem_pio2+0xab8>
    1eb0:	mov	w8, #0x2                   	// #2
    1eb4:	b	1ed8 <__ieee754_rem_pio2+0xad8>
    1eb8:	ldur	w8, [x29, #-148]
    1ebc:	cbz	w8, 1ec8 <__ieee754_rem_pio2+0xac8>
    1ec0:	mov	w8, #0x3                   	// #3
    1ec4:	b	1ed8 <__ieee754_rem_pio2+0xad8>
    1ec8:	ldur	w8, [x29, #-152]
    1ecc:	cmp	w8, #0x0
    1ed0:	mov	w8, #0x4                   	// #4
    1ed4:	cinc	w8, w8, eq	// eq = none
    1ed8:	add	w9, w23, w27
    1edc:	add	w8, w8, w27
    1ee0:	add	w9, w9, #0x4
    1ee4:	b	1ef8 <__ieee754_rem_pio2+0xaf8>
    1ee8:	cmp	x27, x8
    1eec:	add	w9, w9, #0x1
    1ef0:	str	d0, [x20, x27, lsl #3]
    1ef4:	b.cs	1c54 <__ieee754_rem_pio2+0x854>  // b.hs, b.nlast
    1ef8:	mov	x10, x27
    1efc:	add	x27, x27, #0x1
    1f00:	movi	d0, #0x0
    1f04:	ldr	w11, [x22, x27, lsl #2]
    1f08:	add	w10, w23, w10
    1f0c:	add	w10, w10, #0x4
    1f10:	scvtf	d1, w11
    1f14:	str	d1, [x21, w10, sxtw #3]
    1f18:	cbz	w26, 1ee8 <__ieee754_rem_pio2+0xae8>
    1f1c:	sbfiz	x10, x9, #3, #32
    1f20:	cmp	x24, #0x4
    1f24:	b.cs	1f30 <__ieee754_rem_pio2+0xb30>  // b.hs, b.nlast
    1f28:	mov	x11, xzr
    1f2c:	b	1f88 <__ieee754_rem_pio2+0xb88>
    1f30:	add	x11, x16, x10
    1f34:	mov	x12, x19
    1f38:	mov	x13, x15
    1f3c:	ldp	q2, q1, [x11, #-16]
    1f40:	subs	x12, x12, #0x4
    1f44:	ldp	q3, q4, [x13, #-16]
    1f48:	add	x13, x13, #0x20
    1f4c:	sub	x11, x11, #0x20
    1f50:	ext	v1.16b, v1.16b, v1.16b, #8
    1f54:	ext	v2.16b, v2.16b, v2.16b, #8
    1f58:	fmul	v1.2d, v3.2d, v1.2d
    1f5c:	mov	d3, v1.d[1]
    1f60:	fadd	d0, d0, d1
    1f64:	fmul	v1.2d, v4.2d, v2.2d
    1f68:	fadd	d0, d0, d3
    1f6c:	mov	d2, v1.d[1]
    1f70:	fadd	d0, d0, d1
    1f74:	fadd	d0, d0, d2
    1f78:	b.ne	1f3c <__ieee754_rem_pio2+0xb3c>  // b.any
    1f7c:	cmp	x24, x19
    1f80:	mov	x11, x19
    1f84:	b.eq	1ee8 <__ieee754_rem_pio2+0xae8>  // b.none
    1f88:	lsl	x12, x11, #3
    1f8c:	sub	x13, x10, x12
    1f90:	sub	x10, x24, x11
    1f94:	add	x12, x14, x12
    1f98:	add	x11, x21, x13
    1f9c:	ldr	d1, [x12], #8
    1fa0:	subs	x10, x10, #0x1
    1fa4:	ldr	d2, [x11], #-8
    1fa8:	fmadd	d0, d1, d2, d0
    1fac:	b.ne	1f9c <__ieee754_rem_pio2+0xb9c>  // b.any
    1fb0:	b	1ee8 <__ieee754_rem_pio2+0xae8>
    1fb4:	fmov	d0, d8
    1fb8:	ldur	w9, [x29, #-52]
    1fbc:	mov	w8, #0x18                  	// #24
    1fc0:	mov	w19, w17
    1fc4:	mov	w20, w13
    1fc8:	sub	w0, w8, w9
    1fcc:	bl	0 <scalbn>
    1fd0:	mov	x8, #0x4170000000000000    	// #4715268809856909312
    1fd4:	fmov	d1, x8
    1fd8:	fcmp	d0, d1
    1fdc:	b.ge	1ff4 <__ieee754_rem_pio2+0xbf4>  // b.tcont
    1fe0:	fcvtzs	w8, d0
    1fe4:	sub	x9, x29, #0x98
    1fe8:	stur	w25, [x29, #-52]
    1fec:	str	w8, [x9, x27, lsl #2]
    1ff0:	b	2028 <__ieee754_rem_pio2+0xc28>
    1ff4:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1ff8:	mov	x9, #0xc170000000000000    	// #-4508103226997866496
    1ffc:	sub	x10, x29, #0x98
    2000:	fmov	d1, x8
    2004:	fmov	d2, x9
    2008:	fmul	d1, d0, d1
    200c:	fcvtzs	w8, d1
    2010:	scvtf	d1, w8
    2014:	fmadd	d0, d1, d2, d0
    2018:	fcvtzs	w9, d0
    201c:	str	w9, [x10, x27, lsl #2]
    2020:	add	w27, w27, #0x1
    2024:	str	w8, [x10, w27, uxtw #2]
    2028:	mov	w17, w19
    202c:	tbnz	w27, #31, 21a8 <__ieee754_rem_pio2+0xda8>
    2030:	fmov	d0, #1.000000000000000000e+00
    2034:	ldur	w0, [x29, #-52]
    2038:	mov	w21, w17
    203c:	mov	w19, w27
    2040:	bl	0 <scalbn>
    2044:	mov	x10, #0x3e70000000000000    	// #4499096027743125504
    2048:	sub	x8, x29, #0x98
    204c:	add	x9, sp, #0x50
    2050:	fmov	d1, x10
    2054:	mov	x10, x19
    2058:	ldr	w11, [x8, x10, lsl #2]
    205c:	scvtf	d2, w11
    2060:	fmul	d2, d0, d2
    2064:	fmul	d0, d0, d1
    2068:	str	d2, [x9, x10, lsl #3]
    206c:	sub	x10, x10, #0x1
    2070:	cmn	x10, #0x1
    2074:	b.ne	2058 <__ieee754_rem_pio2+0xc58>  // b.any
    2078:	adrp	x11, 0 <pts_ieee754_acos>
    207c:	add	x10, sp, #0x50
    2080:	movi	d1, #0x0
    2084:	ldr	d0, [x11]
    2088:	adrp	x11, 0 <pts_ieee754_acos>
    208c:	add	x10, x10, x19, lsl #3
    2090:	ldr	d2, [x11]
    2094:	adrp	x11, 0 <pts_ieee754_acos>
    2098:	adrp	x12, 0 <pts_ieee754_acos>
    209c:	ldr	d3, [x11]
    20a0:	ldr	d4, [x12]
    20a4:	mov	x13, #0x442d00000000        	// #74960064217088
    20a8:	ldr	x15, [sp, #16]
    20ac:	mov	x8, xzr
    20b0:	add	x9, x19, #0x1
    20b4:	add	x10, x10, #0x10
    20b8:	mov	w11, #0x4                   	// #4
    20bc:	add	x12, sp, #0xf8
    20c0:	movk	x13, #0x3e74, lsl #48
    20c4:	mov	w16, w20
    20c8:	mov	w17, w21
    20cc:	b	20e4 <__ieee754_rem_pio2+0xce4>
    20d0:	str	d5, [x12, x8, lsl #3]
    20d4:	add	x8, x8, #0x1
    20d8:	sub	x10, x10, #0x8
    20dc:	cmp	w9, w8
    20e0:	b.eq	213c <__ieee754_rem_pio2+0xd3c>  // b.none
    20e4:	ldur	d5, [x10, #-16]
    20e8:	cmp	w8, #0x4
    20ec:	csel	w14, w8, w11, cc	// cc = lo, ul, last
    20f0:	fmadd	d5, d5, d0, d1
    20f4:	cbz	w8, 20d0 <__ieee754_rem_pio2+0xcd0>
    20f8:	fmov	d7, x13
    20fc:	ldur	d6, [x10, #-8]
    2100:	add	w14, w14, #0x1
    2104:	cmp	w14, #0x2
    2108:	fmadd	d5, d6, d7, d5
    210c:	b.eq	20d0 <__ieee754_rem_pio2+0xcd0>  // b.none
    2110:	ldr	d6, [x10]
    2114:	cmp	w14, #0x3
    2118:	fmadd	d5, d6, d2, d5
    211c:	b.eq	20d0 <__ieee754_rem_pio2+0xcd0>  // b.none
    2120:	ldr	d6, [x10, #8]
    2124:	cmp	w14, #0x4
    2128:	fmadd	d5, d6, d3, d5
    212c:	b.eq	20d0 <__ieee754_rem_pio2+0xcd0>  // b.none
    2130:	ldr	d6, [x10, #16]
    2134:	fmadd	d5, d6, d4, d5
    2138:	b	20d0 <__ieee754_rem_pio2+0xcd0>
    213c:	movi	d1, #0x0
    2140:	cbz	w19, 21d0 <__ieee754_rem_pio2+0xdd0>
    2144:	add	x9, x19, #0x1
    2148:	add	x8, sp, #0xf8
    214c:	and	x10, x9, #0xfffffffe
    2150:	add	x11, x8, x19, lsl #3
    2154:	sub	x8, x19, x10
    2158:	mov	x12, x10
    215c:	ldr	d0, [x11]
    2160:	sub	x12, x12, #0x2
    2164:	fadd	d0, d1, d0
    2168:	ldur	d1, [x11, #-8]
    216c:	sub	x11, x11, #0x10
    2170:	fadd	d1, d0, d1
    2174:	cbnz	x12, 215c <__ieee754_rem_pio2+0xd5c>
    2178:	cmp	x9, x10
    217c:	b.ne	21d4 <__ieee754_rem_pio2+0xdd4>  // b.any
    2180:	b	21ec <__ieee754_rem_pio2+0xdec>
    2184:	sub	x8, x29, #0x98
    2188:	mov	w20, w13
    218c:	sub	x8, x8, #0x4
    2190:	ldr	w9, [x8, x27, lsl #2]
    2194:	sub	w25, w25, #0x18
    2198:	sub	x27, x27, #0x1
    219c:	cbz	w9, 2190 <__ieee754_rem_pio2+0xd90>
    21a0:	stur	w25, [x29, #-52]
    21a4:	tbz	w27, #31, 2030 <__ieee754_rem_pio2+0xc30>
    21a8:	movi	d0, #0x0
    21ac:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    21b0:	cmp	w17, #0x0
    21b4:	fmov	d1, x8
    21b8:	ldp	x12, x15, [sp, #8]
    21bc:	cset	w8, eq	// eq = none
    21c0:	mov	w16, w20
    21c4:	fcsel	d0, d0, d1, eq	// eq = none
    21c8:	str	d0, [x15]
    21cc:	b	2294 <__ieee754_rem_pio2+0xe94>
    21d0:	mov	x8, x19
    21d4:	add	x9, sp, #0xf8
    21d8:	ldr	d0, [x9, x8, lsl #3]
    21dc:	sub	x8, x8, #0x1
    21e0:	cmn	x8, #0x1
    21e4:	fadd	d1, d1, d0
    21e8:	b.ne	21d8 <__ieee754_rem_pio2+0xdd8>  // b.any
    21ec:	fneg	d0, d1
    21f0:	ldr	d2, [sp, #248]
    21f4:	cmp	w17, #0x0
    21f8:	cset	w8, eq	// eq = none
    21fc:	fcsel	d0, d1, d0, eq	// eq = none
    2200:	fsub	d1, d2, d1
    2204:	str	d0, [x15]
    2208:	cbz	w19, 2224 <__ieee754_rem_pio2+0xe24>
    220c:	cmp	w19, #0x4
    2210:	add	w9, w19, #0x1
    2214:	b.cs	222c <__ieee754_rem_pio2+0xe2c>  // b.hs, b.nlast
    2218:	ldr	x12, [sp, #8]
    221c:	mov	w10, #0x1                   	// #1
    2220:	b	2278 <__ieee754_rem_pio2+0xe78>
    2224:	ldr	x12, [sp, #8]
    2228:	b	2294 <__ieee754_rem_pio2+0xe94>
    222c:	sub	x11, x9, #0x1
    2230:	add	x13, sp, #0xf8
    2234:	and	x12, x11, #0xfffffffffffffffc
    2238:	add	x13, x13, #0x18
    223c:	orr	x10, x12, #0x1
    2240:	mov	x14, x12
    2244:	ldp	q2, q3, [x13, #-16]
    2248:	subs	x14, x14, #0x4
    224c:	add	x13, x13, #0x20
    2250:	mov	d4, v2.d[1]
    2254:	fadd	d1, d1, d2
    2258:	mov	d2, v3.d[1]
    225c:	fadd	d1, d1, d4
    2260:	fadd	d1, d1, d3
    2264:	fadd	d1, d1, d2
    2268:	b.ne	2244 <__ieee754_rem_pio2+0xe44>  // b.any
    226c:	cmp	x11, x12
    2270:	ldr	x12, [sp, #8]
    2274:	b.eq	2294 <__ieee754_rem_pio2+0xe94>  // b.none
    2278:	add	x11, sp, #0xf8
    227c:	sub	x9, x9, x10
    2280:	add	x11, x11, x10, lsl #3
    2284:	ldr	d2, [x11], #8
    2288:	subs	x9, x9, #0x1
    228c:	fadd	d1, d1, d2
    2290:	b.ne	2284 <__ieee754_rem_pio2+0xe84>  // b.any
    2294:	fneg	d2, d1
    2298:	cmp	w8, #0x0
    229c:	and	w0, w16, #0x7
    22a0:	fcsel	d1, d1, d2, ne	// ne = any
    22a4:	str	d1, [x15, #8]
    22a8:	tbz	x12, #63, 22bc <__ieee754_rem_pio2+0xebc>
    22ac:	fneg	d0, d0
    22b0:	fneg	d1, d1
    22b4:	stp	d0, d1, [x15]
    22b8:	neg	w0, w0
    22bc:	add	sp, sp, #0x290
    22c0:	ldp	x20, x19, [sp, #144]
    22c4:	ldp	x22, x21, [sp, #128]
    22c8:	ldp	x24, x23, [sp, #112]
    22cc:	ldp	x26, x25, [sp, #96]
    22d0:	ldp	x28, x27, [sp, #80]
    22d4:	ldp	x29, x30, [sp, #64]
    22d8:	ldp	d9, d8, [sp, #48]
    22dc:	ldp	d11, d10, [sp, #32]
    22e0:	ldp	d13, d12, [sp, #16]
    22e4:	ldr	d14, [sp], #160
    22e8:	ret
    22ec:	nop
    22f0:	nop
    22f4:	nop
    22f8:	nop
    22fc:	nop

0000000000002300 <pts_ieee754_exp>:
    2300:	fmov	x9, d0
    2304:	mov	w11, #0x2e42                	// #11842
    2308:	movk	w11, #0x4086, lsl #16
    230c:	ubfx	x10, x9, #32, #31
    2310:	lsr	x8, x9, #63
    2314:	cmp	w10, w11
    2318:	b.cc	2350 <pts_ieee754_exp+0x50>  // b.lo, b.ul, b.last
    231c:	lsr	w10, w10, #20
    2320:	cmp	w10, #0x7ff
    2324:	b.cc	2388 <pts_ieee754_exp+0x88>  // b.lo, b.ul, b.last
    2328:	movi	d1, #0x0
    232c:	lsr	x8, x9, #32
    2330:	cmp	x9, #0x0
    2334:	fadd	d2, d0, d0
    2338:	and	w8, w8, #0xfffff
    233c:	orr	w8, w8, w9
    2340:	fcsel	d0, d0, d1, ge	// ge = tcont
    2344:	cmp	w8, #0x0
    2348:	fcsel	d0, d0, d2, eq	// eq = none
    234c:	ret
    2350:	mov	w9, #0x2e43                	// #11843
    2354:	movk	w9, #0x3fd6, lsl #16
    2358:	cmp	w10, w9
    235c:	b.cc	23ac <pts_ieee754_exp+0xac>  // b.lo, b.ul, b.last
    2360:	mov	w9, #0xa2b1                	// #41649
    2364:	movk	w9, #0x3ff0, lsl #16
    2368:	cmp	w10, w9
    236c:	b.hi	2410 <pts_ieee754_exp+0x110>  // b.pmore
    2370:	fmov	d1, #1.000000000000000000e+00
    2374:	fcmp	d0, d1
    2378:	b.ne	2520 <pts_ieee754_exp+0x220>  // b.any
    237c:	adrp	x8, 0 <pts_ieee754_acos>
    2380:	ldr	d0, [x8]
    2384:	ret
    2388:	adrp	x9, 0 <pts_ieee754_acos>
    238c:	ldr	d1, [x9]
    2390:	fcmp	d0, d1
    2394:	b.le	23f4 <pts_ieee754_exp+0xf4>
    2398:	adrp	x8, 0 <pts_ieee754_acos>
    239c:	ldr	d0, [x8]
    23a0:	ldr	d1, [x8]
    23a4:	fmul	d0, d0, d1
    23a8:	ret
    23ac:	lsr	w8, w10, #20
    23b0:	cmp	w8, #0x3e2
    23b4:	b.hi	23d8 <pts_ieee754_exp+0xd8>  // b.pmore
    23b8:	adrp	x8, 0 <pts_ieee754_acos>
    23bc:	ldr	d1, [x8]
    23c0:	fadd	d2, d1, d0
    23c4:	fmov	d1, #1.000000000000000000e+00
    23c8:	fcmp	d2, d1
    23cc:	b.le	23d8 <pts_ieee754_exp+0xd8>
    23d0:	fadd	d0, d0, d1
    23d4:	ret
    23d8:	fmul	d3, d0, d0
    23dc:	movi	d1, #0x0
    23e0:	movi	d2, #0x0
    23e4:	mov	w8, wzr
    23e8:	mov	w9, #0x1                   	// #1
    23ec:	mov	w10, #0x3ff00000            	// #1072693248
    23f0:	b	2464 <pts_ieee754_exp+0x164>
    23f4:	adrp	x9, 0 <pts_ieee754_acos>
    23f8:	ldr	d1, [x9]
    23fc:	fcmp	d0, d1
    2400:	b.pl	2410 <pts_ieee754_exp+0x110>  // b.nfrst
    2404:	adrp	x8, 0 <pts_ieee754_acos>
    2408:	ldr	d0, [x8]
    240c:	b	2514 <pts_ieee754_exp+0x214>
    2410:	adrp	x9, 0 <pts_ieee754_acos>
    2414:	add	x9, x9, #0x0
    2418:	adrp	x10, 0 <pts_ieee754_acos>
    241c:	ldr	d1, [x9, w8, uxtw #3]
    2420:	ldr	d2, [x10]
    2424:	adrp	x9, 0 <pts_ieee754_acos>
    2428:	adrp	x10, 0 <pts_ieee754_acos>
    242c:	mov	w11, #0x3ff00000            	// #1072693248
    2430:	fmadd	d1, d0, d2, d1
    2434:	ldr	d3, [x10]
    2438:	mov	w10, #0x7e700000            	// #2121269248
    243c:	fcvtzs	w8, d1
    2440:	ldr	d1, [x9]
    2444:	scvtf	d2, w8
    2448:	cmn	w8, #0x3fe
    244c:	cset	w9, gt
    2450:	csel	w10, w11, w10, gt
    2454:	fmadd	d1, d2, d1, d0
    2458:	fmul	d2, d2, d3
    245c:	fsub	d0, d1, d2
    2460:	fmul	d3, d0, d0
    2464:	adrp	x11, 0 <pts_ieee754_acos>
    2468:	adrp	x12, 0 <pts_ieee754_acos>
    246c:	ldr	d4, [x11]
    2470:	ldr	d5, [x12]
    2474:	adrp	x11, 0 <pts_ieee754_acos>
    2478:	fmadd	d4, d3, d5, d4
    247c:	ldr	d5, [x11]
    2480:	adrp	x11, 0 <pts_ieee754_acos>
    2484:	fmadd	d4, d3, d4, d5
    2488:	ldr	d5, [x11]
    248c:	adrp	x11, 0 <pts_ieee754_acos>
    2490:	fmadd	d4, d3, d4, d5
    2494:	ldr	d5, [x11]
    2498:	fmadd	d4, d3, d4, d5
    249c:	fmsub	d4, d3, d4, d0
    24a0:	fmul	d3, d0, d4
    24a4:	cbz	w8, 24f0 <pts_ieee754_exp+0x1f0>
    24a8:	fmov	d0, #2.000000000000000000e+00
    24ac:	add	w10, w10, w8, lsl #20
    24b0:	lsl	x10, x10, #32
    24b4:	fsub	d0, d0, d4
    24b8:	fdiv	d0, d3, d0
    24bc:	fsub	d0, d2, d0
    24c0:	fsub	d0, d1, d0
    24c4:	fmov	d1, #1.000000000000000000e+00
    24c8:	fadd	d0, d0, d1
    24cc:	fmov	d1, x10
    24d0:	cbz	w9, 250c <pts_ieee754_exp+0x20c>
    24d4:	cmp	w8, #0x400
    24d8:	b.ne	2518 <pts_ieee754_exp+0x218>  // b.any
    24dc:	fadd	d0, d0, d0
    24e0:	adrp	x8, 0 <pts_ieee754_acos>
    24e4:	ldr	d1, [x8]
    24e8:	fmul	d0, d0, d1
    24ec:	ret
    24f0:	fmov	d1, #-2.000000000000000000e+00
    24f4:	fadd	d1, d4, d1
    24f8:	fdiv	d1, d3, d1
    24fc:	fsub	d0, d0, d1
    2500:	fmov	d1, #1.000000000000000000e+00
    2504:	fadd	d0, d0, d1
    2508:	ret
    250c:	fmul	d0, d0, d1
    2510:	adrp	x8, 0 <pts_ieee754_acos>
    2514:	ldr	d1, [x8]
    2518:	fmul	d0, d0, d1
    251c:	ret
    2520:	mov	w9, w8
    2524:	adrp	x10, 0 <pts_ieee754_acos>
    2528:	add	x10, x10, #0x0
    252c:	ubfiz	x9, x9, #3, #32
    2530:	ldr	d1, [x10, x9]
    2534:	adrp	x10, 0 <pts_ieee754_acos>
    2538:	add	x10, x10, #0x0
    253c:	ldr	d2, [x10, x9]
    2540:	eor	w9, w8, #0x1
    2544:	fsub	d1, d0, d1
    2548:	sub	w8, w9, w8
    254c:	fsub	d0, d1, d2
    2550:	fmul	d3, d0, d0
    2554:	b	23e8 <pts_ieee754_exp+0xe8>
    2558:	nop
    255c:	nop

0000000000002560 <pts_ieee754_atanh>:
    2560:	stp	x29, x30, [sp, #-32]!
    2564:	str	x19, [sp, #16]
    2568:	mov	x29, sp
    256c:	fmov	x19, d0
    2570:	mov	w9, #0x3ff00000            	// #1072693248
    2574:	ubfx	x8, x19, #32, #31
    2578:	cmp	w19, #0x0
    257c:	cset	w10, ne	// ne = any
    2580:	orr	w10, w8, w10
    2584:	cmp	w10, w9
    2588:	b.ls	2598 <pts_ieee754_atanh+0x38>  // b.plast
    258c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2590:	fmov	d0, x8
    2594:	b	2628 <pts_ieee754_atanh+0xc8>
    2598:	cmp	w8, w9
    259c:	b.ne	25bc <pts_ieee754_atanh+0x5c>  // b.any
    25a0:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    25a4:	mov	x9, #0x7ff0000000000000    	// #9218868437227405312
    25a8:	fcmp	d0, #0.0
    25ac:	fmov	d0, x8
    25b0:	fmov	d1, x9
    25b4:	fcsel	d0, d1, d0, gt
    25b8:	b	2628 <pts_ieee754_atanh+0xc8>
    25bc:	adrp	x9, 0 <pts_ieee754_acos>
    25c0:	ldr	d1, [x9]
    25c4:	fadd	d1, d0, d1
    25c8:	fcmp	d1, #0.0
    25cc:	b.le	25dc <pts_ieee754_atanh+0x7c>
    25d0:	lsr	w9, w8, #20
    25d4:	cmp	w9, #0x3e3
    25d8:	b.cc	2628 <pts_ieee754_atanh+0xc8>  // b.lo, b.ul, b.last
    25dc:	fabs	d1, d0
    25e0:	lsr	w8, w8, #21
    25e4:	fmov	d2, #1.000000000000000000e+00
    25e8:	cmp	w8, #0x1fe
    25ec:	fadd	d0, d1, d1
    25f0:	b.hi	2608 <pts_ieee754_atanh+0xa8>  // b.pmore
    25f4:	fmul	d3, d1, d0
    25f8:	fsub	d1, d2, d1
    25fc:	fdiv	d1, d3, d1
    2600:	fadd	d0, d0, d1
    2604:	b	2610 <pts_ieee754_atanh+0xb0>
    2608:	fsub	d1, d2, d1
    260c:	fdiv	d0, d0, d1
    2610:	bl	5a0 <pts_ieee754_log1p>
    2614:	fmov	d1, #5.000000000000000000e-01
    2618:	cmp	x19, #0x0
    261c:	fmul	d2, d0, d1
    2620:	fnmul	d0, d0, d1
    2624:	fcsel	d0, d0, d2, lt	// lt = tstop
    2628:	ldr	x19, [sp, #16]
    262c:	ldp	x29, x30, [sp], #32
    2630:	ret
    2634:	nop
    2638:	nop
    263c:	nop

0000000000002640 <pts_ieee754_log2>:
    2640:	fmov	x10, d0
    2644:	lsr	x8, x10, #32
    2648:	cmp	w8, #0x100, lsl #12
    264c:	b.ge	267c <pts_ieee754_log2+0x3c>  // b.tcont
    2650:	and	w8, w8, #0x7fffffff
    2654:	orr	w8, w8, w10
    2658:	cbz	w8, 26b4 <pts_ieee754_log2+0x74>
    265c:	tbnz	x10, #63, 27d0 <pts_ieee754_log2+0x190>
    2660:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    2664:	mov	w9, #0xffffffca            	// #-54
    2668:	fmov	d1, x8
    266c:	fmul	d0, d0, d1
    2670:	fmov	x8, d0
    2674:	lsr	x8, x8, #32
    2678:	b	2680 <pts_ieee754_log2+0x40>
    267c:	mov	w9, wzr
    2680:	mov	w11, #0x7ff00000            	// #2146435072
    2684:	cmp	w8, w11
    2688:	b.lt	2698 <pts_ieee754_log2+0x58>  // b.tstop
    268c:	fadd	d1, d0, d0
    2690:	fmov	d0, d1
    2694:	ret
    2698:	cbnz	w10, 26bc <pts_ieee754_log2+0x7c>
    269c:	movi	d1, #0x0
    26a0:	mov	w10, #0x3ff00000            	// #1072693248
    26a4:	cmp	w8, w10
    26a8:	b.ne	26bc <pts_ieee754_log2+0x7c>  // b.any
    26ac:	fmov	d0, d1
    26b0:	ret
    26b4:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    26b8:	b	27d4 <pts_ieee754_log2+0x194>
    26bc:	and	w10, w8, #0xfffff
    26c0:	fmov	x12, d0
    26c4:	fmov	d0, #-1.000000000000000000e+00
    26c8:	add	w10, w10, #0x95, lsl #12
    26cc:	fmov	d6, #5.000000000000000000e-01
    26d0:	add	w10, w10, #0xf64
    26d4:	and	w11, w10, #0x100000
    26d8:	and	x12, x12, #0xffffffff
    26dc:	bfxil	w11, w8, #0, #20
    26e0:	add	w8, w9, w8, asr #20
    26e4:	eor	w11, w11, #0x3ff00000
    26e8:	add	w8, w8, w10, lsr #20
    26ec:	orr	x11, x12, x11, lsl #32
    26f0:	adrp	x12, 0 <pts_ieee754_acos>
    26f4:	ldr	d5, [x12]
    26f8:	adrp	x12, 0 <pts_ieee754_acos>
    26fc:	sub	w8, w8, #0x3ff
    2700:	fmov	d1, x11
    2704:	adrp	x11, 0 <pts_ieee754_acos>
    2708:	ldr	d16, [x12]
    270c:	ldr	d4, [x11]
    2710:	adrp	x11, 0 <pts_ieee754_acos>
    2714:	adrp	x12, 0 <pts_ieee754_acos>
    2718:	fadd	d0, d1, d0
    271c:	fmov	d1, #2.000000000000000000e+00
    2720:	fadd	d1, d0, d1
    2724:	fmul	d6, d0, d6
    2728:	fdiv	d1, d0, d1
    272c:	fmul	d6, d0, d6
    2730:	fmul	d2, d1, d1
    2734:	fmul	d3, d2, d2
    2738:	fmadd	d4, d3, d5, d4
    273c:	ldr	d5, [x11]
    2740:	adrp	x11, 0 <pts_ieee754_acos>
    2744:	ldr	d7, [x11]
    2748:	adrp	x11, 0 <pts_ieee754_acos>
    274c:	fmadd	d5, d3, d7, d5
    2750:	ldr	d7, [x11]
    2754:	fmadd	d4, d3, d4, d16
    2758:	ldr	d16, [x12]
    275c:	fmadd	d5, d3, d5, d7
    2760:	fmadd	d4, d3, d4, d16
    2764:	fmul	d3, d3, d5
    2768:	scvtf	d5, w8
    276c:	adrp	x8, 0 <pts_ieee754_acos>
    2770:	fmul	d2, d2, d4
    2774:	fsub	d4, d0, d6
    2778:	fmov	x11, d4
    277c:	fadd	d2, d3, d2
    2780:	and	x9, x11, #0xffffffff00000000
    2784:	fmov	d3, x9
    2788:	fadd	d2, d6, d2
    278c:	adrp	x9, 0 <pts_ieee754_acos>
    2790:	ldr	d4, [x9]
    2794:	fsub	d0, d0, d3
    2798:	fmul	d1, d1, d2
    279c:	fmul	d2, d3, d4
    27a0:	fsub	d0, d0, d6
    27a4:	fadd	d0, d0, d1
    27a8:	fadd	d1, d2, d5
    27ac:	fadd	d3, d0, d3
    27b0:	fmul	d0, d0, d4
    27b4:	fsub	d4, d5, d1
    27b8:	ldr	d5, [x8]
    27bc:	fmadd	d0, d3, d5, d0
    27c0:	fadd	d2, d2, d4
    27c4:	fadd	d0, d2, d0
    27c8:	fadd	d0, d1, d0
    27cc:	ret
    27d0:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    27d4:	fmov	d1, x8
    27d8:	fmov	d0, d1
    27dc:	ret

00000000000027e0 <pts_ieee754_log10>:
    27e0:	fmov	x8, d0
    27e4:	lsr	x9, x8, #32
    27e8:	cmp	w9, #0x100, lsl #12
    27ec:	b.ge	281c <pts_ieee754_log10+0x3c>  // b.tcont
    27f0:	and	w9, w9, #0x7fffffff
    27f4:	orr	w9, w9, w8
    27f8:	cbz	w9, 284c <pts_ieee754_log10+0x6c>
    27fc:	tbnz	x8, #63, 28c4 <pts_ieee754_log10+0xe4>
    2800:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    2804:	mov	w10, #0xffffffca            	// #-54
    2808:	fmov	d1, x8
    280c:	fmul	d0, d0, d1
    2810:	fmov	x8, d0
    2814:	lsr	x9, x8, #32
    2818:	b	2820 <pts_ieee754_log10+0x40>
    281c:	mov	w10, wzr
    2820:	mov	w11, #0x7ff00000            	// #2146435072
    2824:	cmp	w9, w11
    2828:	b.lt	2834 <pts_ieee754_log10+0x54>  // b.tstop
    282c:	fadd	d0, d0, d0
    2830:	ret
    2834:	cbnz	w8, 2858 <pts_ieee754_log10+0x78>
    2838:	movi	d0, #0x0
    283c:	mov	w11, #0x3ff00000            	// #1072693248
    2840:	cmp	w9, w11
    2844:	b.ne	2858 <pts_ieee754_log10+0x78>  // b.any
    2848:	ret
    284c:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2850:	fmov	d0, x8
    2854:	ret
    2858:	str	d8, [sp, #-32]!
    285c:	stp	x29, x30, [sp, #16]
    2860:	add	x29, sp, #0x10
    2864:	add	w10, w10, w9, asr #20
    2868:	and	w9, w9, #0xfffff
    286c:	mov	w8, w8
    2870:	sub	w10, w10, #0x3ff
    2874:	lsr	w11, w10, #31
    2878:	orr	w9, w9, w11, lsl #20
    287c:	add	w10, w11, w10
    2880:	scvtf	d8, w10
    2884:	eor	w9, w9, #0x3ff00000
    2888:	orr	x8, x8, x9, lsl #32
    288c:	fmov	d0, x8
    2890:	bl	380 <pts_ieee754_log>
    2894:	adrp	x8, 0 <pts_ieee754_acos>
    2898:	ldr	d1, [x8]
    289c:	adrp	x8, 0 <pts_ieee754_acos>
    28a0:	fmul	d0, d0, d1
    28a4:	ldr	d1, [x8]
    28a8:	adrp	x8, 0 <pts_ieee754_acos>
    28ac:	fmadd	d0, d8, d1, d0
    28b0:	ldr	d1, [x8]
    28b4:	fmadd	d0, d8, d1, d0
    28b8:	ldp	x29, x30, [sp, #16]
    28bc:	ldr	d8, [sp], #32
    28c0:	ret
    28c4:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    28c8:	fmov	d0, x8
    28cc:	ret
    28d0:	nop
    28d4:	nop
    28d8:	nop
    28dc:	nop

00000000000028e0 <pts_ieee754_expm1>:
    28e0:	fmov	x9, d0
    28e4:	mov	w11, #0x687a                	// #26746
    28e8:	movk	w11, #0x4043, lsl #16
    28ec:	ubfx	x10, x9, #32, #31
    28f0:	lsr	x8, x9, #32
    28f4:	cmp	w10, w11
    28f8:	b.cc	293c <pts_ieee754_expm1+0x5c>  // b.lo, b.ul, b.last
    28fc:	mov	w11, #0x2e42                	// #11842
    2900:	movk	w11, #0x4086, lsl #16
    2904:	cmp	w10, w11
    2908:	b.cc	29cc <pts_ieee754_expm1+0xec>  // b.lo, b.ul, b.last
    290c:	lsr	w10, w10, #20
    2910:	cmp	w10, #0x7ff
    2914:	b.cc	29a8 <pts_ieee754_expm1+0xc8>  // b.lo, b.ul, b.last
    2918:	fmov	d1, #-1.000000000000000000e+00
    291c:	tst	w8, #0x80000000
    2920:	fadd	d2, d0, d0
    2924:	and	w8, w8, #0xfffff
    2928:	orr	w8, w8, w9
    292c:	fcsel	d0, d0, d1, eq	// eq = none
    2930:	cmp	w8, #0x0
    2934:	fcsel	d0, d0, d2, eq	// eq = none
    2938:	ret
    293c:	mov	w9, #0x2e43                	// #11843
    2940:	movk	w9, #0x3fd6, lsl #16
    2944:	cmp	w10, w9
    2948:	b.cc	297c <pts_ieee754_expm1+0x9c>  // b.lo, b.ul, b.last
    294c:	mov	w9, #0xa2b1                	// #41649
    2950:	movk	w9, #0x3ff0, lsl #16
    2954:	cmp	w10, w9
    2958:	b.hi	29ec <pts_ieee754_expm1+0x10c>  // b.pmore
    295c:	tbnz	w8, #31, 2b54 <pts_ieee754_expm1+0x274>
    2960:	adrp	x8, 0 <pts_ieee754_acos>
    2964:	ldr	d1, [x8]
    2968:	adrp	x8, 0 <pts_ieee754_acos>
    296c:	ldr	d2, [x8]
    2970:	mov	w8, #0x1                   	// #1
    2974:	fadd	d1, d0, d1
    2978:	b	2a28 <pts_ieee754_expm1+0x148>
    297c:	lsr	w8, w10, #20
    2980:	cmp	w8, #0x3c8
    2984:	b.hi	2a38 <pts_ieee754_expm1+0x158>  // b.pmore
    2988:	adrp	x8, 0 <pts_ieee754_acos>
    298c:	ldr	d1, [x8]
    2990:	ldr	d2, [x8]
    2994:	fadd	d1, d1, d0
    2998:	fadd	d2, d2, d0
    299c:	fsub	d1, d1, d2
    29a0:	fsub	d0, d0, d1
    29a4:	ret
    29a8:	adrp	x9, 0 <pts_ieee754_acos>
    29ac:	ldr	d1, [x9]
    29b0:	fcmp	d0, d1
    29b4:	b.le	29cc <pts_ieee754_expm1+0xec>
    29b8:	adrp	x8, 0 <pts_ieee754_acos>
    29bc:	ldr	d0, [x8]
    29c0:	ldr	d1, [x8]
    29c4:	fmul	d0, d0, d1
    29c8:	ret
    29cc:	adrp	x9, 0 <pts_ieee754_acos>
    29d0:	ldr	d1, [x9]
    29d4:	and	w9, w8, #0x80000000
    29d8:	fadd	d1, d0, d1
    29dc:	fcmp	d1, #0.0
    29e0:	fmov	d1, #-1.000000000000000000e+00
    29e4:	ccmp	w9, #0x0, #0x4, mi	// mi = first
    29e8:	b.ne	2bd0 <pts_ieee754_expm1+0x2f0>  // b.any
    29ec:	fmov	d1, #-5.000000000000000000e-01
    29f0:	fmov	d2, #5.000000000000000000e-01
    29f4:	tst	w8, #0x80000000
    29f8:	adrp	x8, 0 <pts_ieee754_acos>
    29fc:	adrp	x9, 0 <pts_ieee754_acos>
    2a00:	adrp	x10, 0 <pts_ieee754_acos>
    2a04:	ldr	d3, [x10]
    2a08:	fcsel	d1, d2, d1, eq	// eq = none
    2a0c:	ldr	d2, [x8]
    2a10:	fmadd	d1, d0, d2, d1
    2a14:	fcvtzs	w8, d1
    2a18:	ldr	d1, [x9]
    2a1c:	scvtf	d2, w8
    2a20:	fmadd	d1, d2, d1, d0
    2a24:	fmul	d2, d2, d3
    2a28:	fsub	d0, d1, d2
    2a2c:	fsub	d1, d1, d0
    2a30:	fsub	d1, d1, d2
    2a34:	b	2a3c <pts_ieee754_expm1+0x15c>
    2a38:	mov	w8, wzr
    2a3c:	fmov	d2, #5.000000000000000000e-01
    2a40:	adrp	x9, 0 <pts_ieee754_acos>
    2a44:	adrp	x10, 0 <pts_ieee754_acos>
    2a48:	ldr	d4, [x9]
    2a4c:	ldr	d5, [x10]
    2a50:	adrp	x9, 0 <pts_ieee754_acos>
    2a54:	fmul	d3, d0, d2
    2a58:	fmul	d2, d0, d3
    2a5c:	fmadd	d4, d2, d5, d4
    2a60:	ldr	d5, [x9]
    2a64:	adrp	x9, 0 <pts_ieee754_acos>
    2a68:	fmadd	d4, d2, d4, d5
    2a6c:	ldr	d5, [x9]
    2a70:	adrp	x9, 0 <pts_ieee754_acos>
    2a74:	fmadd	d4, d2, d4, d5
    2a78:	ldr	d5, [x9]
    2a7c:	fmadd	d4, d2, d4, d5
    2a80:	fmov	d5, #1.000000000000000000e+00
    2a84:	fmadd	d4, d2, d4, d5
    2a88:	fmov	d5, #3.000000000000000000e+00
    2a8c:	fmsub	d3, d4, d3, d5
    2a90:	fmov	d5, #6.000000000000000000e+00
    2a94:	fsub	d4, d4, d3
    2a98:	fmsub	d3, d0, d3, d5
    2a9c:	fdiv	d3, d4, d3
    2aa0:	fmul	d3, d2, d3
    2aa4:	cbz	w8, 2ad8 <pts_ieee754_expm1+0x1f8>
    2aa8:	fsub	d3, d3, d1
    2aac:	cmp	w8, #0x1
    2ab0:	fnmsub	d1, d0, d3, d1
    2ab4:	fsub	d1, d1, d2
    2ab8:	b.eq	2ae4 <pts_ieee754_expm1+0x204>  // b.none
    2abc:	cmn	w8, #0x1
    2ac0:	b.ne	2b08 <pts_ieee754_expm1+0x228>  // b.any
    2ac4:	fsub	d0, d0, d1
    2ac8:	fmov	d1, #-5.000000000000000000e-01
    2acc:	fmov	d2, #5.000000000000000000e-01
    2ad0:	fmadd	d0, d0, d2, d1
    2ad4:	ret
    2ad8:	fnmsub	d1, d0, d3, d2
    2adc:	fsub	d0, d0, d1
    2ae0:	ret
    2ae4:	fmov	d2, #-2.500000000000000000e-01
    2ae8:	fcmp	d0, d2
    2aec:	b.pl	2b70 <pts_ieee754_expm1+0x290>  // b.nfrst
    2af0:	fmov	d2, #5.000000000000000000e-01
    2af4:	fadd	d0, d0, d2
    2af8:	fsub	d0, d1, d0
    2afc:	fmov	d1, #-2.000000000000000000e+00
    2b00:	fmul	d0, d0, d1
    2b04:	ret
    2b08:	mov	x9, #0x3ff0000000000000    	// #4607182418800017408
    2b0c:	sub	w10, w8, #0x39
    2b10:	add	x9, x9, x8, lsl #52
    2b14:	cmn	w10, #0x3b
    2b18:	fmov	d2, x9
    2b1c:	b.hi	2b84 <pts_ieee754_expm1+0x2a4>  // b.pmore
    2b20:	fsub	d0, d0, d1
    2b24:	fmov	d1, #1.000000000000000000e+00
    2b28:	mov	x9, #0x7fe0000000000000    	// #9214364837600034816
    2b2c:	fmov	d3, x9
    2b30:	cmp	w8, #0x400
    2b34:	fadd	d0, d0, d1
    2b38:	fadd	d1, d0, d0
    2b3c:	fmul	d0, d0, d2
    2b40:	fmul	d1, d1, d3
    2b44:	fcsel	d0, d1, d0, eq	// eq = none
    2b48:	fmov	d1, #-1.000000000000000000e+00
    2b4c:	fadd	d0, d0, d1
    2b50:	ret
    2b54:	adrp	x8, 0 <pts_ieee754_acos>
    2b58:	ldr	d1, [x8]
    2b5c:	adrp	x8, 0 <pts_ieee754_acos>
    2b60:	ldr	d2, [x8]
    2b64:	mov	w8, #0xffffffff            	// #-1
    2b68:	fadd	d1, d0, d1
    2b6c:	b	2a28 <pts_ieee754_expm1+0x148>
    2b70:	fsub	d0, d0, d1
    2b74:	fmov	d1, #1.000000000000000000e+00
    2b78:	fmov	d2, #2.000000000000000000e+00
    2b7c:	fmadd	d0, d0, d2, d1
    2b80:	ret
    2b84:	lsl	w9, w8, #20
    2b88:	mov	w10, #0x3ff00000            	// #1072693248
    2b8c:	cmp	w8, #0x13
    2b90:	sub	w9, w10, w9
    2b94:	lsl	x9, x9, #32
    2b98:	fmov	d3, x9
    2b9c:	mov	w9, #0x200000              	// #2097152
    2ba0:	lsr	w9, w9, w8
    2ba4:	fadd	d3, d1, d3
    2ba8:	sub	w9, w10, w9
    2bac:	lsl	x9, x9, #32
    2bb0:	fmov	d4, x9
    2bb4:	fsub	d3, d0, d3
    2bb8:	fsub	d0, d1, d0
    2bbc:	fmov	d1, #1.000000000000000000e+00
    2bc0:	fadd	d1, d3, d1
    2bc4:	fsub	d0, d4, d0
    2bc8:	fcsel	d0, d1, d0, hi	// hi = pmore
    2bcc:	fmul	d1, d0, d2
    2bd0:	fmov	d0, d1
    2bd4:	ret
    2bd8:	nop
    2bdc:	nop

0000000000002be0 <pts_ieee754_cbrt>:
    2be0:	fmov	x10, d0
    2be4:	lsr	x8, x10, #32
    2be8:	ubfx	w9, w8, #20, #11
    2bec:	cmp	w9, #0x7ff
    2bf0:	b.cc	2bfc <pts_ieee754_cbrt+0x1c>  // b.lo, b.ul, b.last
    2bf4:	fadd	d0, d0, d0
    2bf8:	ret
    2bfc:	ubfx	x9, x10, #32, #31
    2c00:	lsr	w11, w9, #20
    2c04:	cbnz	w11, 2c30 <pts_ieee754_cbrt+0x50>
    2c08:	orr	w9, w9, w10
    2c0c:	cbz	w9, 2cdc <pts_ieee754_cbrt+0xfc>
    2c10:	mov	x9, #0x4350000000000000    	// #4850376798678024192
    2c14:	mov	w10, #0x7893                	// #30867
    2c18:	fmov	d1, x9
    2c1c:	movk	w10, #0x297f, lsl #16
    2c20:	fmul	d1, d0, d1
    2c24:	fmov	x9, d1
    2c28:	ubfx	x9, x9, #32, #31
    2c2c:	b	2c38 <pts_ieee754_cbrt+0x58>
    2c30:	mov	w10, #0x7893                	// #30867
    2c34:	movk	w10, #0x2a9f, lsl #16
    2c38:	mov	w11, #0x5556                	// #21846
    2c3c:	and	w8, w8, #0x80000000
    2c40:	movk	w11, #0x5555, lsl #16
    2c44:	umull	x9, w9, w11
    2c48:	lsr	x9, x9, #32
    2c4c:	add	w9, w9, w10
    2c50:	adrp	x10, 0 <pts_ieee754_acos>
    2c54:	orr	w8, w9, w8
    2c58:	adrp	x9, 0 <pts_ieee754_acos>
    2c5c:	ldr	d7, [x10]
    2c60:	lsl	x8, x8, #32
    2c64:	ldr	d4, [x9]
    2c68:	adrp	x9, 0 <pts_ieee754_acos>
    2c6c:	ldr	d6, [x9]
    2c70:	mov	w9, #0x80000000            	// #-2147483648
    2c74:	fmov	d1, x8
    2c78:	adrp	x8, 0 <pts_ieee754_acos>
    2c7c:	fdiv	d2, d1, d0
    2c80:	fmul	d3, d1, d1
    2c84:	fmul	d2, d3, d2
    2c88:	ldr	d3, [x8]
    2c8c:	adrp	x8, 0 <pts_ieee754_acos>
    2c90:	ldr	d5, [x8]
    2c94:	fmadd	d3, d2, d4, d3
    2c98:	fmul	d4, d2, d2
    2c9c:	fmadd	d3, d2, d3, d5
    2ca0:	fmul	d4, d2, d4
    2ca4:	fmadd	d2, d2, d7, d6
    2ca8:	fmadd	d2, d4, d2, d3
    2cac:	fmul	d1, d2, d1
    2cb0:	fmov	x8, d1
    2cb4:	and	x8, x8, #0xffffffffc0000000
    2cb8:	add	x8, x8, x9
    2cbc:	fmov	d1, x8
    2cc0:	fmul	d2, d1, d1
    2cc4:	fdiv	d0, d0, d2
    2cc8:	fadd	d2, d1, d1
    2ccc:	fsub	d3, d0, d1
    2cd0:	fadd	d0, d2, d0
    2cd4:	fdiv	d0, d3, d0
    2cd8:	fmadd	d0, d1, d0, d1
    2cdc:	ret

0000000000002ce0 <pts_ieee754_sin>:
    2ce0:	sub	sp, sp, #0x20
    2ce4:	stp	x29, x30, [sp, #16]
    2ce8:	add	x29, sp, #0x10
    2cec:	fmov	x8, d0
    2cf0:	mov	w10, #0x21fb                	// #8699
    2cf4:	movk	w10, #0x3fe9, lsl #16
    2cf8:	ubfx	x9, x8, #32, #31
    2cfc:	cmp	w9, w10
    2d00:	b.hi	2d6c <pts_ieee754_sin+0x8c>  // b.pmore
    2d04:	ubfx	x8, x8, #54, #9
    2d08:	cmp	x8, #0xf8
    2d0c:	b.hi	2d18 <pts_ieee754_sin+0x38>  // b.pmore
    2d10:	fcvtzs	w8, d0
    2d14:	cbz	w8, 2d7c <pts_ieee754_sin+0x9c>
    2d18:	fmul	d1, d0, d0
    2d1c:	adrp	x8, 0 <pts_ieee754_acos>
    2d20:	adrp	x9, 0 <pts_ieee754_acos>
    2d24:	ldr	d2, [x8]
    2d28:	ldr	d3, [x9]
    2d2c:	adrp	x8, 0 <pts_ieee754_acos>
    2d30:	fmadd	d2, d1, d3, d2
    2d34:	ldr	d3, [x8]
    2d38:	adrp	x8, 0 <pts_ieee754_acos>
    2d3c:	fmul	d4, d1, d0
    2d40:	fmadd	d2, d1, d2, d3
    2d44:	ldr	d3, [x8]
    2d48:	adrp	x8, 0 <pts_ieee754_acos>
    2d4c:	fmadd	d2, d1, d2, d3
    2d50:	ldr	d3, [x8]
    2d54:	adrp	x8, 0 <pts_ieee754_acos>
    2d58:	fmadd	d2, d1, d2, d3
    2d5c:	ldr	d3, [x8]
    2d60:	fmadd	d1, d1, d2, d3
    2d64:	fmadd	d0, d4, d1, d0
    2d68:	b	2d7c <pts_ieee754_sin+0x9c>
    2d6c:	lsr	w8, w9, #20
    2d70:	cmp	w8, #0x7ff
    2d74:	b.cc	2d88 <pts_ieee754_sin+0xa8>  // b.lo, b.ul, b.last
    2d78:	fsub	d0, d0, d0
    2d7c:	ldp	x29, x30, [sp, #16]
    2d80:	add	sp, sp, #0x20
    2d84:	ret
    2d88:	mov	x0, sp
    2d8c:	bl	1400 <__ieee754_rem_pio2>
    2d90:	ldr	d1, [sp]
    2d94:	and	w8, w0, #0x3
    2d98:	cmp	w8, #0x2
    2d9c:	b.eq	2e6c <pts_ieee754_sin+0x18c>  // b.none
    2da0:	cmp	w8, #0x1
    2da4:	b.eq	2dcc <pts_ieee754_sin+0xec>  // b.none
    2da8:	cbnz	w8, 2ef0 <pts_ieee754_sin+0x210>
    2dac:	fmov	x8, d1
    2db0:	ubfx	x8, x8, #54, #9
    2db4:	cmp	x8, #0xf8
    2db8:	b.hi	2f90 <pts_ieee754_sin+0x2b0>  // b.pmore
    2dbc:	fcvtzs	w8, d1
    2dc0:	cbnz	w8, 2f90 <pts_ieee754_sin+0x2b0>
    2dc4:	fmov	d0, d1
    2dc8:	b	2d7c <pts_ieee754_sin+0x9c>
    2dcc:	fmov	x8, d1
    2dd0:	ldr	d2, [sp, #8]
    2dd4:	lsr	x9, x8, #32
    2dd8:	ubfx	w9, w9, #22, #9
    2ddc:	cmp	w9, #0xf8
    2de0:	b.hi	2df0 <pts_ieee754_sin+0x110>  // b.pmore
    2de4:	fcvtzs	w9, d1
    2de8:	fmov	d0, #1.000000000000000000e+00
    2dec:	cbz	w9, 2d7c <pts_ieee754_sin+0x9c>
    2df0:	fmul	d0, d1, d1
    2df4:	adrp	x9, 0 <pts_ieee754_acos>
    2df8:	adrp	x10, 0 <pts_ieee754_acos>
    2dfc:	ldr	d3, [x9]
    2e00:	ldr	d4, [x10]
    2e04:	adrp	x9, 0 <pts_ieee754_acos>
    2e08:	ubfx	x8, x8, #32, #31
    2e0c:	fmadd	d3, d0, d4, d3
    2e10:	ldr	d4, [x9]
    2e14:	adrp	x9, 0 <pts_ieee754_acos>
    2e18:	fmadd	d3, d0, d3, d4
    2e1c:	ldr	d4, [x9]
    2e20:	adrp	x9, 0 <pts_ieee754_acos>
    2e24:	fmadd	d3, d0, d3, d4
    2e28:	ldr	d4, [x9]
    2e2c:	adrp	x9, 0 <pts_ieee754_acos>
    2e30:	fmadd	d3, d0, d3, d4
    2e34:	ldr	d4, [x9]
    2e38:	mov	w9, #0x3333                	// #13107
    2e3c:	movk	w9, #0x3fd3, lsl #16
    2e40:	cmp	w8, w9
    2e44:	fmadd	d3, d0, d3, d4
    2e48:	fmul	d3, d0, d3
    2e4c:	b.cs	2ff8 <pts_ieee754_sin+0x318>  // b.hs, b.nlast
    2e50:	fnmul	d1, d1, d2
    2e54:	fmov	d2, #5.000000000000000000e-01
    2e58:	fmadd	d1, d0, d3, d1
    2e5c:	fnmsub	d0, d0, d2, d1
    2e60:	fmov	d1, #1.000000000000000000e+00
    2e64:	fsub	d0, d1, d0
    2e68:	b	2d7c <pts_ieee754_sin+0x9c>
    2e6c:	fmov	x8, d1
    2e70:	ubfx	x8, x8, #54, #9
    2e74:	cmp	x8, #0xf8
    2e78:	b.hi	2e84 <pts_ieee754_sin+0x1a4>  // b.pmore
    2e7c:	fcvtzs	w8, d1
    2e80:	cbz	w8, 2ee8 <pts_ieee754_sin+0x208>
    2e84:	fmul	d0, d1, d1
    2e88:	adrp	x8, 0 <pts_ieee754_acos>
    2e8c:	adrp	x9, 0 <pts_ieee754_acos>
    2e90:	ldr	d2, [x8]
    2e94:	ldr	d3, [x9]
    2e98:	adrp	x8, 0 <pts_ieee754_acos>
    2e9c:	fmov	d4, #5.000000000000000000e-01
    2ea0:	ldr	d5, [sp, #8]
    2ea4:	fmadd	d2, d0, d3, d2
    2ea8:	ldr	d3, [x8]
    2eac:	adrp	x8, 0 <pts_ieee754_acos>
    2eb0:	fmadd	d2, d0, d2, d3
    2eb4:	ldr	d3, [x8]
    2eb8:	adrp	x8, 0 <pts_ieee754_acos>
    2ebc:	fmadd	d2, d0, d2, d3
    2ec0:	ldr	d3, [x8]
    2ec4:	adrp	x8, 0 <pts_ieee754_acos>
    2ec8:	fmadd	d2, d0, d2, d3
    2ecc:	fnmul	d3, d0, d1
    2ed0:	fmul	d2, d3, d2
    2ed4:	fmadd	d2, d5, d4, d2
    2ed8:	fnmsub	d0, d0, d2, d5
    2edc:	ldr	d2, [x8]
    2ee0:	fmadd	d0, d3, d2, d0
    2ee4:	fsub	d1, d1, d0
    2ee8:	fneg	d0, d1
    2eec:	b	2d7c <pts_ieee754_sin+0x9c>
    2ef0:	fmov	x8, d1
    2ef4:	ldr	d0, [sp, #8]
    2ef8:	lsr	x9, x8, #32
    2efc:	ubfx	w9, w9, #22, #9
    2f00:	cmp	w9, #0xf8
    2f04:	b.hi	2f14 <pts_ieee754_sin+0x234>  // b.pmore
    2f08:	fcvtzs	w9, d1
    2f0c:	fmov	d2, #1.000000000000000000e+00
    2f10:	cbz	w9, 3074 <pts_ieee754_sin+0x394>
    2f14:	fmul	d2, d1, d1
    2f18:	adrp	x9, 0 <pts_ieee754_acos>
    2f1c:	adrp	x10, 0 <pts_ieee754_acos>
    2f20:	ldr	d3, [x9]
    2f24:	ldr	d4, [x10]
    2f28:	adrp	x9, 0 <pts_ieee754_acos>
    2f2c:	ubfx	x8, x8, #32, #31
    2f30:	fmadd	d3, d2, d4, d3
    2f34:	ldr	d4, [x9]
    2f38:	adrp	x9, 0 <pts_ieee754_acos>
    2f3c:	fmadd	d3, d2, d3, d4
    2f40:	ldr	d4, [x9]
    2f44:	adrp	x9, 0 <pts_ieee754_acos>
    2f48:	fmadd	d3, d2, d3, d4
    2f4c:	ldr	d4, [x9]
    2f50:	adrp	x9, 0 <pts_ieee754_acos>
    2f54:	fmadd	d3, d2, d3, d4
    2f58:	ldr	d4, [x9]
    2f5c:	mov	w9, #0x3333                	// #13107
    2f60:	movk	w9, #0x3fd3, lsl #16
    2f64:	cmp	w8, w9
    2f68:	fmadd	d3, d2, d3, d4
    2f6c:	fmul	d3, d2, d3
    2f70:	b.cs	3038 <pts_ieee754_sin+0x358>  // b.hs, b.nlast
    2f74:	fnmul	d0, d1, d0
    2f78:	fmov	d1, #5.000000000000000000e-01
    2f7c:	fmadd	d0, d2, d3, d0
    2f80:	fnmsub	d0, d2, d1, d0
    2f84:	fmov	d1, #1.000000000000000000e+00
    2f88:	fsub	d2, d1, d0
    2f8c:	b	3074 <pts_ieee754_sin+0x394>
    2f90:	fmul	d0, d1, d1
    2f94:	adrp	x8, 0 <pts_ieee754_acos>
    2f98:	adrp	x9, 0 <pts_ieee754_acos>
    2f9c:	ldr	d2, [x8]
    2fa0:	ldr	d3, [x9]
    2fa4:	adrp	x8, 0 <pts_ieee754_acos>
    2fa8:	fmov	d4, #5.000000000000000000e-01
    2fac:	ldr	d5, [sp, #8]
    2fb0:	fmadd	d2, d0, d3, d2
    2fb4:	ldr	d3, [x8]
    2fb8:	adrp	x8, 0 <pts_ieee754_acos>
    2fbc:	fmadd	d2, d0, d2, d3
    2fc0:	ldr	d3, [x8]
    2fc4:	adrp	x8, 0 <pts_ieee754_acos>
    2fc8:	fmadd	d2, d0, d2, d3
    2fcc:	ldr	d3, [x8]
    2fd0:	adrp	x8, 0 <pts_ieee754_acos>
    2fd4:	fmadd	d2, d0, d2, d3
    2fd8:	fnmul	d3, d0, d1
    2fdc:	fmul	d2, d3, d2
    2fe0:	fmadd	d2, d5, d4, d2
    2fe4:	fnmsub	d0, d0, d2, d5
    2fe8:	ldr	d2, [x8]
    2fec:	fmadd	d0, d3, d2, d0
    2ff0:	fsub	d0, d1, d0
    2ff4:	b	2d7c <pts_ieee754_sin+0x9c>
    2ff8:	sub	w9, w8, #0x200, lsl #12
    2ffc:	fmov	d4, #2.812500000000000000e-01
    3000:	mov	w10, #0x3fe90000            	// #1072234496
    3004:	lsl	x9, x9, #32
    3008:	cmp	w8, w10
    300c:	fnmul	d1, d1, d2
    3010:	fmov	d2, #5.000000000000000000e-01
    3014:	fmov	d5, x9
    3018:	fcsel	d4, d4, d5, hi	// hi = pmore
    301c:	fnmsub	d2, d0, d2, d4
    3020:	fmadd	d0, d0, d3, d1
    3024:	fmov	d1, #1.000000000000000000e+00
    3028:	fsub	d1, d1, d4
    302c:	fsub	d0, d0, d2
    3030:	fadd	d0, d1, d0
    3034:	b	2d7c <pts_ieee754_sin+0x9c>
    3038:	sub	w9, w8, #0x200, lsl #12
    303c:	fmov	d4, #2.812500000000000000e-01
    3040:	mov	w10, #0x3fe90000            	// #1072234496
    3044:	lsl	x9, x9, #32
    3048:	cmp	w8, w10
    304c:	fnmul	d0, d1, d0
    3050:	fmov	d1, #5.000000000000000000e-01
    3054:	fmov	d5, x9
    3058:	fmadd	d0, d2, d3, d0
    305c:	fcsel	d4, d4, d5, hi	// hi = pmore
    3060:	fnmsub	d1, d2, d1, d4
    3064:	fmov	d2, #1.000000000000000000e+00
    3068:	fsub	d2, d2, d4
    306c:	fsub	d0, d0, d1
    3070:	fadd	d2, d2, d0
    3074:	fneg	d0, d2
    3078:	b	2d7c <pts_ieee754_sin+0x9c>
    307c:	nop

0000000000003080 <pts_ieee754_tan>:
    3080:	sub	sp, sp, #0x20
    3084:	stp	x29, x30, [sp, #16]
    3088:	add	x29, sp, #0x10
    308c:	fmov	x8, d0
    3090:	mov	w10, #0x21fb                	// #8699
    3094:	movk	w10, #0x3fe9, lsl #16
    3098:	ubfx	x9, x8, #32, #31
    309c:	cmp	w9, w10
    30a0:	b.hi	30bc <pts_ieee754_tan+0x3c>  // b.pmore
    30a4:	lsr	w10, w9, #20
    30a8:	cmp	w10, #0x3e2
    30ac:	b.hi	30d0 <pts_ieee754_tan+0x50>  // b.pmore
    30b0:	fcvtzs	w10, d0
    30b4:	cbnz	w10, 30d0 <pts_ieee754_tan+0x50>
    30b8:	b	3408 <pts_ieee754_tan+0x388>
    30bc:	lsr	w8, w9, #20
    30c0:	cmp	w8, #0x7ff
    30c4:	b.cc	31e8 <pts_ieee754_tan+0x168>  // b.lo, b.ul, b.last
    30c8:	fsub	d0, d0, d0
    30cc:	b	3408 <pts_ieee754_tan+0x388>
    30d0:	mov	w10, #0x9427                	// #37927
    30d4:	movk	w10, #0x3fe5, lsl #16
    30d8:	cmp	w9, w10
    30dc:	b.ls	3104 <pts_ieee754_tan+0x84>  // b.plast
    30e0:	fneg	d1, d0
    30e4:	cmp	x8, #0x0
    30e8:	adrp	x11, 0 <pts_ieee754_acos>
    30ec:	fcsel	d0, d1, d0, lt	// lt = tstop
    30f0:	ldr	d1, [x11]
    30f4:	adrp	x11, 0 <pts_ieee754_acos>
    30f8:	fsub	d0, d1, d0
    30fc:	ldr	d1, [x11]
    3100:	fadd	d0, d0, d1
    3104:	fmul	d1, d0, d0
    3108:	adrp	x11, 0 <pts_ieee754_acos>
    310c:	adrp	x12, 0 <pts_ieee754_acos>
    3110:	ldr	d3, [x11]
    3114:	ldr	d4, [x12]
    3118:	adrp	x11, 0 <pts_ieee754_acos>
    311c:	adrp	x12, 0 <pts_ieee754_acos>
    3120:	adrp	x13, 0 <pts_ieee754_acos>
    3124:	cmp	w9, w10
    3128:	ldr	d5, [x12]
    312c:	ldr	d6, [x13]
    3130:	adrp	x12, 0 <pts_ieee754_acos>
    3134:	fmul	d2, d1, d1
    3138:	fmadd	d3, d2, d4, d3
    313c:	ldr	d4, [x11]
    3140:	adrp	x11, 0 <pts_ieee754_acos>
    3144:	fmadd	d4, d2, d5, d4
    3148:	ldr	d5, [x11]
    314c:	adrp	x11, 0 <pts_ieee754_acos>
    3150:	fmadd	d3, d2, d3, d6
    3154:	ldr	d6, [x12]
    3158:	adrp	x12, 0 <pts_ieee754_acos>
    315c:	fmadd	d4, d2, d4, d5
    3160:	ldr	d5, [x11]
    3164:	adrp	x11, 0 <pts_ieee754_acos>
    3168:	fmadd	d3, d2, d3, d6
    316c:	ldr	d6, [x12]
    3170:	adrp	x12, 0 <pts_ieee754_acos>
    3174:	fmadd	d4, d2, d4, d5
    3178:	ldr	d5, [x11]
    317c:	adrp	x11, 0 <pts_ieee754_acos>
    3180:	fmadd	d3, d2, d3, d6
    3184:	ldr	d6, [x12]
    3188:	fmadd	d4, d2, d4, d5
    318c:	ldr	d5, [x11]
    3190:	adrp	x11, 0 <pts_ieee754_acos>
    3194:	fmadd	d3, d2, d3, d6
    3198:	fmadd	d2, d2, d4, d5
    319c:	fmul	d4, d0, d1
    31a0:	fmul	d3, d1, d3
    31a4:	fadd	d2, d2, d3
    31a8:	movi	d3, #0x0
    31ac:	fmadd	d2, d4, d2, d3
    31b0:	fmadd	d1, d1, d2, d3
    31b4:	ldr	d2, [x11]
    31b8:	fmadd	d1, d4, d2, d1
    31bc:	fadd	d2, d0, d1
    31c0:	b.ls	3238 <pts_ieee754_tan+0x1b8>  // b.plast
    31c4:	fmov	d3, #1.000000000000000000e+00
    31c8:	fmul	d4, d2, d2
    31cc:	lsr	x8, x8, #32
    31d0:	lsr	w8, w8, #31
    31d4:	fadd	d2, d2, d3
    31d8:	fdiv	d2, d4, d2
    31dc:	fsub	d1, d2, d1
    31e0:	fsub	d0, d0, d1
    31e4:	b	3364 <pts_ieee754_tan+0x2e4>
    31e8:	mov	x0, sp
    31ec:	bl	1400 <__ieee754_rem_pio2>
    31f0:	ldp	d1, d0, [sp]
    31f4:	ubfiz	w9, w0, #1, #1
    31f8:	fmov	x12, d1
    31fc:	lsr	x8, x12, #32
    3200:	ubfx	x10, x12, #32, #31
    3204:	ubfx	w11, w8, #20, #11
    3208:	cmp	w11, #0x3e2
    320c:	b.hi	3240 <pts_ieee754_tan+0x1c0>  // b.pmore
    3210:	fcvtzs	w11, d1
    3214:	cbnz	w11, 3240 <pts_ieee754_tan+0x1c0>
    3218:	mov	w8, #0x2                   	// #2
    321c:	orr	w10, w12, w10
    3220:	sub	w8, w8, w9
    3224:	orr	w8, w8, w10
    3228:	cbz	w8, 33bc <pts_ieee754_tan+0x33c>
    322c:	cbnz	w9, 33cc <pts_ieee754_tan+0x34c>
    3230:	fmov	d0, d1
    3234:	b	3408 <pts_ieee754_tan+0x388>
    3238:	fmov	d0, d2
    323c:	b	3408 <pts_ieee754_tan+0x388>
    3240:	mov	w11, #0x9427                	// #37927
    3244:	movk	w11, #0x3fe5, lsl #16
    3248:	cmp	w10, w11
    324c:	b.ls	3284 <pts_ieee754_tan+0x204>  // b.plast
    3250:	fneg	d2, d1
    3254:	fneg	d3, d0
    3258:	cmp	x12, #0x0
    325c:	adrp	x12, 0 <pts_ieee754_acos>
    3260:	adrp	x13, 0 <pts_ieee754_acos>
    3264:	fcsel	d0, d3, d0, lt	// lt = tstop
    3268:	fcsel	d1, d2, d1, lt	// lt = tstop
    326c:	ldr	d2, [x12]
    3270:	ldr	d3, [x13]
    3274:	fsub	d1, d2, d1
    3278:	fsub	d0, d3, d0
    327c:	fadd	d1, d1, d0
    3280:	movi	d0, #0x0
    3284:	fmul	d2, d1, d1
    3288:	adrp	x12, 0 <pts_ieee754_acos>
    328c:	adrp	x13, 0 <pts_ieee754_acos>
    3290:	ldr	d4, [x12]
    3294:	ldr	d5, [x13]
    3298:	adrp	x12, 0 <pts_ieee754_acos>
    329c:	adrp	x13, 0 <pts_ieee754_acos>
    32a0:	adrp	x14, 0 <pts_ieee754_acos>
    32a4:	cmp	w10, w11
    32a8:	ldr	d6, [x13]
    32ac:	ldr	d7, [x14]
    32b0:	adrp	x13, 0 <pts_ieee754_acos>
    32b4:	fmul	d3, d2, d2
    32b8:	fmadd	d4, d3, d5, d4
    32bc:	ldr	d5, [x12]
    32c0:	adrp	x12, 0 <pts_ieee754_acos>
    32c4:	fmadd	d5, d3, d6, d5
    32c8:	ldr	d6, [x12]
    32cc:	adrp	x12, 0 <pts_ieee754_acos>
    32d0:	fmadd	d4, d3, d4, d7
    32d4:	ldr	d7, [x13]
    32d8:	adrp	x13, 0 <pts_ieee754_acos>
    32dc:	fmadd	d5, d3, d5, d6
    32e0:	ldr	d6, [x12]
    32e4:	adrp	x12, 0 <pts_ieee754_acos>
    32e8:	fmadd	d4, d3, d4, d7
    32ec:	ldr	d7, [x13]
    32f0:	adrp	x13, 0 <pts_ieee754_acos>
    32f4:	fmadd	d5, d3, d5, d6
    32f8:	ldr	d6, [x12]
    32fc:	adrp	x12, 0 <pts_ieee754_acos>
    3300:	fmadd	d4, d3, d4, d7
    3304:	ldr	d7, [x13]
    3308:	fmadd	d5, d3, d5, d6
    330c:	ldr	d6, [x12]
    3310:	adrp	x12, 0 <pts_ieee754_acos>
    3314:	fmadd	d4, d3, d4, d7
    3318:	fmadd	d3, d3, d5, d6
    331c:	fmul	d5, d1, d2
    3320:	fmul	d4, d2, d4
    3324:	fadd	d3, d3, d4
    3328:	fmadd	d3, d5, d3, d0
    332c:	fmadd	d0, d2, d3, d0
    3330:	ldr	d2, [x12]
    3334:	fmadd	d2, d5, d2, d0
    3338:	fadd	d0, d1, d2
    333c:	b.ls	3380 <pts_ieee754_tan+0x300>  // b.plast
    3340:	mov	w10, #0x1                   	// #1
    3344:	fmul	d4, d0, d0
    3348:	lsr	w8, w8, #31
    334c:	sub	w9, w10, w9
    3350:	scvtf	d3, w9
    3354:	fadd	d0, d0, d3
    3358:	fdiv	d0, d4, d0
    335c:	fsub	d0, d0, d2
    3360:	fsub	d0, d1, d0
    3364:	mov	w9, #0x1                   	// #1
    3368:	fmov	d1, #-2.000000000000000000e+00
    336c:	sub	w8, w9, w8, lsl #1
    3370:	scvtf	d2, w8
    3374:	fmadd	d0, d0, d1, d3
    3378:	fmul	d0, d0, d2
    337c:	b	3408 <pts_ieee754_tan+0x388>
    3380:	cbz	w9, 30b8 <pts_ieee754_tan+0x38>
    3384:	fmov	d3, #-1.000000000000000000e+00
    3388:	fmov	x8, d0
    338c:	fmov	d4, #1.000000000000000000e+00
    3390:	fdiv	d3, d3, d0
    3394:	and	x8, x8, #0xffffffff00000000
    3398:	fmov	d0, x8
    339c:	fsub	d1, d0, d1
    33a0:	fsub	d1, d2, d1
    33a4:	fmov	x8, d3
    33a8:	and	x8, x8, #0xffffffff00000000
    33ac:	fmov	d5, x8
    33b0:	fmadd	d0, d5, d0, d4
    33b4:	fmadd	d0, d5, d1, d0
    33b8:	b	3404 <pts_ieee754_tan+0x384>
    33bc:	fabs	d0, d1
    33c0:	fmov	d1, #1.000000000000000000e+00
    33c4:	fdiv	d0, d1, d0
    33c8:	b	30b8 <pts_ieee754_tan+0x38>
    33cc:	fadd	d2, d1, d0
    33d0:	fmov	d3, #-1.000000000000000000e+00
    33d4:	fmov	d4, #1.000000000000000000e+00
    33d8:	fdiv	d3, d3, d2
    33dc:	fmov	x8, d2
    33e0:	and	x8, x8, #0xffffffff00000000
    33e4:	fmov	d2, x8
    33e8:	fsub	d1, d2, d1
    33ec:	fsub	d0, d0, d1
    33f0:	fmov	x8, d3
    33f4:	and	x8, x8, #0xffffffff00000000
    33f8:	fmov	d5, x8
    33fc:	fmadd	d1, d5, d2, d4
    3400:	fmadd	d0, d5, d0, d1
    3404:	fmadd	d0, d3, d0, d5
    3408:	ldp	x29, x30, [sp, #16]
    340c:	add	sp, sp, #0x20
    3410:	ret
    3414:	nop
    3418:	nop
    341c:	nop

0000000000003420 <pts_ieee754_cosh>:
    3420:	str	d8, [sp, #-32]!
    3424:	stp	x29, x30, [sp, #8]
    3428:	str	x19, [sp, #24]
    342c:	add	x29, sp, #0x8
    3430:	fmov	x8, d0
    3434:	ubfx	x19, x8, #32, #31
    3438:	mov	w8, #0x2e42                	// #11842
    343c:	movk	w8, #0x3fd6, lsl #16
    3440:	cmp	w19, w8
    3444:	b.hi	347c <pts_ieee754_cosh+0x5c>  // b.pmore
    3448:	fabs	d0, d0
    344c:	bl	28e0 <pts_ieee754_expm1>
    3450:	fmov	d2, #1.000000000000000000e+00
    3454:	fmov	d1, d0
    3458:	lsr	w8, w19, #23
    345c:	cmp	w8, #0x79
    3460:	fadd	d0, d0, d2
    3464:	b.cc	350c <pts_ieee754_cosh+0xec>  // b.lo, b.ul, b.last
    3468:	fmul	d1, d1, d1
    346c:	fadd	d0, d0, d0
    3470:	fdiv	d0, d1, d0
    3474:	fadd	d0, d0, d2
    3478:	b	350c <pts_ieee754_cosh+0xec>
    347c:	mov	w8, #0x4035ffff            	// #1077280767
    3480:	cmp	w19, w8
    3484:	b.hi	34a0 <pts_ieee754_cosh+0x80>  // b.pmore
    3488:	fabs	d0, d0
    348c:	bl	2300 <pts_ieee754_exp>
    3490:	fmov	d1, #5.000000000000000000e-01
    3494:	fdiv	d2, d1, d0
    3498:	fmadd	d0, d0, d1, d2
    349c:	b	350c <pts_ieee754_cosh+0xec>
    34a0:	fabs	d1, d0
    34a4:	mov	w8, #0x2e41                	// #11841
    34a8:	movk	w8, #0x4086, lsl #16
    34ac:	cmp	w19, w8
    34b0:	b.hi	34c4 <pts_ieee754_cosh+0xa4>  // b.pmore
    34b4:	fmov	d0, d1
    34b8:	bl	2300 <pts_ieee754_exp>
    34bc:	fmov	d1, #5.000000000000000000e-01
    34c0:	b	3508 <pts_ieee754_cosh+0xe8>
    34c4:	adrp	x8, 0 <pts_ieee754_acos>
    34c8:	ldr	d2, [x8]
    34cc:	fcmp	d1, d2
    34d0:	b.ls	34e8 <pts_ieee754_cosh+0xc8>  // b.plast
    34d4:	lsr	w8, w19, #20
    34d8:	cmp	w8, #0x7ff
    34dc:	b.cc	34fc <pts_ieee754_cosh+0xdc>  // b.lo, b.ul, b.last
    34e0:	fmul	d0, d0, d0
    34e4:	b	350c <pts_ieee754_cosh+0xec>
    34e8:	fmov	d8, #5.000000000000000000e-01
    34ec:	fmul	d0, d1, d8
    34f0:	bl	2300 <pts_ieee754_exp>
    34f4:	fmul	d1, d0, d8
    34f8:	b	3508 <pts_ieee754_cosh+0xe8>
    34fc:	adrp	x8, 0 <pts_ieee754_acos>
    3500:	ldr	d0, [x8]
    3504:	ldr	d1, [x8]
    3508:	fmul	d0, d0, d1
    350c:	ldp	x29, x30, [sp, #8]
    3510:	ldr	x19, [sp, #24]
    3514:	ldr	d8, [sp], #32
    3518:	ret
    351c:	nop

0000000000003520 <pts_ieee754_sinh>:
    3520:	stp	d9, d8, [sp, #-32]!
    3524:	stp	x29, x30, [sp, #16]
    3528:	add	x29, sp, #0x10
    352c:	fmov	d1, #5.000000000000000000e-01
    3530:	fabs	d8, d0
    3534:	fcmp	d0, #0.0
    3538:	fmov	d2, #-5.000000000000000000e-01
    353c:	fmov	d3, #2.200000000000000000e+01
    3540:	fcsel	d9, d2, d1, mi	// mi = first
    3544:	fcmp	d8, d3
    3548:	b.pl	358c <pts_ieee754_sinh+0x6c>  // b.nfrst
    354c:	mov	x8, #0x3e30000000000000    	// #4481081629233643520
    3550:	fmov	d1, x8
    3554:	fcmp	d8, d1
    3558:	b.mi	35f0 <pts_ieee754_sinh+0xd0>  // b.first
    355c:	fmov	d0, d8
    3560:	bl	28e0 <pts_ieee754_expm1>
    3564:	fmov	d2, #1.000000000000000000e+00
    3568:	fadd	d1, d0, d2
    356c:	fcmp	d8, d2
    3570:	b.pl	35cc <pts_ieee754_sinh+0xac>  // b.nfrst
    3574:	fnmul	d2, d0, d0
    3578:	fdiv	d1, d2, d1
    357c:	fmov	d2, #2.000000000000000000e+00
    3580:	fmadd	d0, d0, d2, d1
    3584:	fmul	d0, d9, d0
    3588:	b	35f0 <pts_ieee754_sinh+0xd0>
    358c:	mov	x8, #0x2e4200000000        	// #50861002719232
    3590:	movk	x8, #0x4086, lsl #48
    3594:	fmov	d1, x8
    3598:	fcmp	d8, d1
    359c:	b.pl	35b0 <pts_ieee754_sinh+0x90>  // b.nfrst
    35a0:	fmov	d0, d8
    35a4:	bl	2300 <pts_ieee754_exp>
    35a8:	fmul	d0, d9, d0
    35ac:	b	35f0 <pts_ieee754_sinh+0xd0>
    35b0:	adrp	x8, 0 <pts_ieee754_acos>
    35b4:	ldr	d1, [x8]
    35b8:	fcmp	d8, d1
    35bc:	b.ls	35dc <pts_ieee754_sinh+0xbc>  // b.plast
    35c0:	adrp	x8, 0 <pts_ieee754_acos>
    35c4:	ldr	d1, [x8]
    35c8:	b	35ec <pts_ieee754_sinh+0xcc>
    35cc:	fdiv	d1, d0, d1
    35d0:	fadd	d0, d0, d1
    35d4:	fmul	d0, d9, d0
    35d8:	b	35f0 <pts_ieee754_sinh+0xd0>
    35dc:	fmov	d0, #5.000000000000000000e-01
    35e0:	fmul	d0, d8, d0
    35e4:	bl	2300 <pts_ieee754_exp>
    35e8:	fmul	d1, d9, d0
    35ec:	fmul	d0, d0, d1
    35f0:	ldp	x29, x30, [sp, #16]
    35f4:	ldp	d9, d8, [sp], #32
    35f8:	ret
    35fc:	nop

0000000000003600 <pts_ieee754_tanh>:
    3600:	stp	x29, x30, [sp, #-32]!
    3604:	str	x19, [sp, #16]
    3608:	mov	x29, sp
    360c:	fmov	x19, d0
    3610:	lsr	x8, x19, #32
    3614:	ubfx	w8, w8, #20, #11
    3618:	cmp	w8, #0x7ff
    361c:	b.cc	3640 <pts_ieee754_tanh+0x40>  // b.lo, b.ul, b.last
    3620:	fmov	d1, #1.000000000000000000e+00
    3624:	fmov	d2, #-1.000000000000000000e+00
    3628:	tst	x19, #0x8000000000000000
    362c:	fdiv	d0, d1, d0
    3630:	fadd	d2, d0, d2
    3634:	fadd	d0, d0, d1
    3638:	fcsel	d0, d2, d0, ne	// ne = any
    363c:	b	36bc <pts_ieee754_tanh+0xbc>
    3640:	ubfx	x8, x19, #32, #31
    3644:	mov	w9, #0x4035ffff            	// #1077280767
    3648:	cmp	w8, w9
    364c:	b.hi	36a0 <pts_ieee754_tanh+0xa0>  // b.pmore
    3650:	adrp	x9, 0 <pts_ieee754_acos>
    3654:	fmov	d2, #1.000000000000000000e+00
    3658:	lsr	w8, w8, #20
    365c:	ldr	d1, [x9]
    3660:	fadd	d1, d0, d1
    3664:	fcmp	d1, d2
    3668:	b.le	3674 <pts_ieee754_tanh+0x74>
    366c:	cmp	w8, #0x3e3
    3670:	b.cc	36bc <pts_ieee754_tanh+0xbc>  // b.lo, b.ul, b.last
    3674:	fabs	d0, d0
    3678:	cmp	w8, #0x3ff
    367c:	b.cc	36c8 <pts_ieee754_tanh+0xc8>  // b.lo, b.ul, b.last
    3680:	fadd	d0, d0, d0
    3684:	bl	28e0 <pts_ieee754_expm1>
    3688:	fmov	d1, #2.000000000000000000e+00
    368c:	fadd	d0, d0, d1
    3690:	fdiv	d0, d1, d0
    3694:	fmov	d1, #1.000000000000000000e+00
    3698:	fsub	d0, d1, d0
    369c:	b	36b0 <pts_ieee754_tanh+0xb0>
    36a0:	adrp	x8, 0 <pts_ieee754_acos>
    36a4:	fmov	d0, #1.000000000000000000e+00
    36a8:	ldr	d1, [x8]
    36ac:	fsub	d0, d0, d1
    36b0:	fneg	d1, d0
    36b4:	cmp	x19, #0x0
    36b8:	fcsel	d0, d1, d0, lt	// lt = tstop
    36bc:	ldr	x19, [sp, #16]
    36c0:	ldp	x29, x30, [sp], #32
    36c4:	ret
    36c8:	fmov	d1, #-2.000000000000000000e+00
    36cc:	fmul	d0, d0, d1
    36d0:	bl	28e0 <pts_ieee754_expm1>
    36d4:	fmov	d1, #2.000000000000000000e+00
    36d8:	fneg	d2, d0
    36dc:	fadd	d0, d0, d1
    36e0:	fdiv	d0, d2, d0
    36e4:	b	36b0 <pts_ieee754_tanh+0xb0>
