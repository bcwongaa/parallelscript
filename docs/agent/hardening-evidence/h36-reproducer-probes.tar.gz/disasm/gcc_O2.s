
bin/gcc_O2.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <__kernel_tan>:
       0:	fmov	x2, d0
       4:	fmov	d2, d0
       8:	mov	w4, #0x3e2fffff            	// #1043333119
       c:	ubfx	x1, x2, #32, #31
      10:	lsr	x3, x2, #32
      14:	cmp	w1, w4
      18:	b.gt	70 <__kernel_tan+0x70>
      1c:	fcvtzs	w4, d0
      20:	cbnz	w4, a4 <__kernel_tan+0xa4>
      24:	add	w3, w0, #0x1
      28:	orr	w2, w3, w2
      2c:	orr	w1, w2, w1
      30:	cbz	w1, 204 <__kernel_tan+0x204>
      34:	cmp	w0, #0x1
      38:	b.eq	6c <__kernel_tan+0x6c>  // b.none
      3c:	fadd	d3, d0, d1
      40:	fmov	d4, #-1.000000000000000000e+00
      44:	movi	v5.2d, #0xffffffff00000000
      48:	fmov	d2, #1.000000000000000000e+00
      4c:	fdiv	d4, d4, d3
      50:	and	v3.8b, v3.8b, v5.8b
      54:	fsub	d0, d3, d0
      58:	fsub	d0, d1, d0
      5c:	and	v1.8b, v4.8b, v5.8b
      60:	fmadd	d2, d3, d1, d2
      64:	fmadd	d2, d0, d1, d2
      68:	fmadd	d0, d2, d4, d1
      6c:	ret
      70:	mov	w2, #0x9427                	// #37927
      74:	movk	w2, #0x3fe5, lsl #16
      78:	cmp	w1, w2
      7c:	b.le	a4 <__kernel_tan+0xa4>
      80:	tbnz	w3, #31, 1d8 <__kernel_tan+0x1d8>
      84:	adrp	x2, 0 <__kernel_tan>
      88:	ldr	d0, [x2]
      8c:	adrp	x2, 0 <__kernel_tan>
      90:	ldr	d3, [x2]
      94:	fsub	d0, d0, d2
      98:	fsub	d2, d3, d1
      9c:	movi	d1, #0x0
      a0:	fadd	d2, d2, d0
      a4:	fmul	d3, d2, d2
      a8:	adrp	x2, 0 <__kernel_tan>
      ac:	ldr	d25, [x2]
      b0:	adrp	x2, 0 <__kernel_tan>
      b4:	fmul	d0, d3, d3
      b8:	ldr	d21, [x2]
      bc:	adrp	x2, 0 <__kernel_tan>
      c0:	fmul	d22, d2, d3
      c4:	ldr	d24, [x2]
      c8:	adrp	x2, 0 <__kernel_tan>
      cc:	fmadd	d21, d0, d25, d21
      d0:	ldr	d20, [x2]
      d4:	adrp	x2, 0 <__kernel_tan>
      d8:	fmadd	d20, d0, d24, d20
      dc:	ldr	d19, [x2]
      e0:	adrp	x2, 0 <__kernel_tan>
      e4:	ldr	d18, [x2]
      e8:	adrp	x2, 0 <__kernel_tan>
      ec:	ldr	d17, [x2]
      f0:	adrp	x2, 0 <__kernel_tan>
      f4:	fmadd	d19, d21, d0, d19
      f8:	ldr	d16, [x2]
      fc:	adrp	x2, 0 <__kernel_tan>
     100:	fmadd	d18, d20, d0, d18
     104:	ldr	d7, [x2]
     108:	adrp	x2, 0 <__kernel_tan>
     10c:	ldr	d6, [x2]
     110:	adrp	x2, 0 <__kernel_tan>
     114:	ldr	d5, [x2]
     118:	adrp	x2, 0 <__kernel_tan>
     11c:	fmadd	d17, d19, d0, d17
     120:	ldr	d4, [x2]
     124:	adrp	x2, 0 <__kernel_tan>
     128:	fmadd	d16, d18, d0, d16
     12c:	ldr	d23, [x2]
     130:	mov	w2, #0x9427                	// #37927
     134:	movk	w2, #0x3fe5, lsl #16
     138:	fmadd	d7, d17, d0, d7
     13c:	fmadd	d6, d16, d0, d6
     140:	fmadd	d5, d7, d0, d5
     144:	fmadd	d0, d6, d0, d4
     148:	fmadd	d0, d5, d3, d0
     14c:	fmadd	d0, d0, d22, d1
     150:	fmadd	d1, d0, d3, d1
     154:	fmadd	d1, d22, d23, d1
     158:	fadd	d0, d2, d1
     15c:	cmp	w1, w2
     160:	b.gt	19c <__kernel_tan+0x19c>
     164:	cmp	w0, #0x1
     168:	b.eq	6c <__kernel_tan+0x6c>  // b.none
     16c:	movi	v6.2d, #0xffffffff00000000
     170:	fmov	d5, #-1.000000000000000000e+00
     174:	fmov	d3, #1.000000000000000000e+00
     178:	and	v4.8b, v0.8b, v6.8b
     17c:	fdiv	d0, d5, d0
     180:	fsub	d2, d4, d2
     184:	fsub	d1, d1, d2
     188:	and	v2.8b, v0.8b, v6.8b
     18c:	fmadd	d3, d4, d2, d3
     190:	fmadd	d3, d2, d1, d3
     194:	fmadd	d0, d3, d0, d2
     198:	ret
     19c:	scvtf	d4, w0
     1a0:	fmul	d3, d0, d0
     1a4:	fmov	d6, #2.000000000000000000e+00
     1a8:	asr	w3, w3, #30
     1ac:	and	w3, w3, #0x2
     1b0:	mov	w0, #0x1                   	// #1
     1b4:	sub	w0, w0, w3
     1b8:	fadd	d0, d0, d4
     1bc:	scvtf	d5, w0
     1c0:	fdiv	d3, d3, d0
     1c4:	fsub	d3, d3, d1
     1c8:	fsub	d3, d2, d3
     1cc:	fmsub	d4, d3, d6, d4
     1d0:	fmul	d0, d5, d4
     1d4:	ret
     1d8:	adrp	x2, 0 <__kernel_tan>
     1dc:	fneg	d2, d0
     1e0:	fneg	d1, d1
     1e4:	ldr	d0, [x2]
     1e8:	adrp	x2, 0 <__kernel_tan>
     1ec:	ldr	d3, [x2]
     1f0:	fsub	d0, d0, d2
     1f4:	fsub	d2, d3, d1
     1f8:	movi	d1, #0x0
     1fc:	fadd	d2, d2, d0
     200:	b	a4 <__kernel_tan+0xa4>
     204:	fabs	d2, d0
     208:	fmov	d0, #1.000000000000000000e+00
     20c:	fdiv	d0, d0, d2
     210:	ret

0000000000000214 <__kernel_rem_pio2.constprop.0>:
     214:	stp	x29, x30, [sp, #-128]!
     218:	sub	w6, w2, #0x3
     21c:	mov	w4, #0xaaab                	// #43691
     220:	mov	x29, sp
     224:	movk	w4, #0x2aaa, lsl #16
     228:	adrp	x5, 0 <__stack_chk_guard>
     22c:	ldr	x5, [x5]
     230:	stp	x19, x20, [sp, #16]
     234:	smull	x4, w6, w4
     238:	stp	x21, x22, [sp, #32]
     23c:	sub	w19, w3, #0x1
     240:	mov	x20, x0
     244:	stp	x23, x24, [sp, #48]
     248:	asr	x4, x4, #34
     24c:	sub	w6, w4, w6, asr #31
     250:	stp	x25, x26, [sp, #64]
     254:	adrp	x4, 0 <__kernel_tan>
     258:	add	x4, x4, #0x0
     25c:	stp	x27, x28, [sp, #80]
     260:	stp	d8, d9, [sp, #96]
     264:	stp	d10, d11, [sp, #112]
     268:	sub	sp, sp, #0x260
     26c:	add	x7, sp, #0x78
     270:	str	x7, [sp]
     274:	str	x1, [sp, #16]
     278:	add	w1, w6, #0x1
     27c:	str	w3, [sp, #24]
     280:	add	w3, w3, #0x4
     284:	sub	w1, w1, w1, lsl #2
     288:	ldr	x0, [x5]
     28c:	str	x0, [sp, #600]
     290:	mov	x0, #0x0                   	// #0
     294:	sub	w0, w6, w19
     298:	add	w21, w2, w1, lsl #3
     29c:	sxtw	x0, w0
     2a0:	add	x3, x0, w3, sxtw
     2a4:	sub	x2, x7, x0, lsl #3
     2a8:	tbnz	w0, #31, 6d0 <__kernel_rem_pio2.constprop.0+0x4bc>
     2ac:	ldr	w1, [x4, x0, lsl #2]
     2b0:	scvtf	d0, w1
     2b4:	str	d0, [x2, x0, lsl #3]
     2b8:	add	x0, x0, #0x1
     2bc:	cmp	x0, x3
     2c0:	b.ne	2a8 <__kernel_rem_pio2.constprop.0+0x94>  // b.any
     2c4:	sxtw	x0, w19
     2c8:	str	x0, [sp, #8]
     2cc:	ldr	x0, [sp]
     2d0:	add	x26, sp, #0x1b8
     2d4:	mov	x2, #0x1                   	// #1
     2d8:	add	x3, x0, w19, sxtw #3
     2dc:	nop
     2e0:	movi	d0, #0x0
     2e4:	mov	x1, x3
     2e8:	mov	x0, #0x0                   	// #0
     2ec:	nop
     2f0:	ldr	d2, [x20, x0, lsl #3]
     2f4:	add	x0, x0, #0x1
     2f8:	ldr	d1, [x1], #-8
     2fc:	fmadd	d0, d2, d1, d0
     300:	cmp	w19, w0
     304:	b.ge	2f0 <__kernel_rem_pio2.constprop.0+0xdc>  // b.tcont
     308:	add	x0, x26, x2, lsl #3
     30c:	add	x2, x2, #0x1
     310:	add	x3, x3, #0x8
     314:	stur	d0, [x0, #-8]
     318:	cmp	x2, #0x6
     31c:	b.ne	2e0 <__kernel_rem_pio2.constprop.0+0xcc>  // b.any
     320:	adrp	x0, 0 <__kernel_tan>
     324:	add	x1, x0, #0x0
     328:	add	x6, x1, w6, sxtw #2
     32c:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     330:	sub	x24, x6, #0x4
     334:	add	x28, sp, #0x28
     338:	fmov	d11, x0
     33c:	mov	w27, #0x4                   	// #4
     340:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     344:	fmov	d8, #1.250000000000000000e-01
     348:	fmov	d10, x0
     34c:	mov	w22, #0xffffff              	// #16777215
     350:	sxtw	x23, w27
     354:	sbfiz	x1, x27, #3, #32
     358:	ldr	d0, [x26, x23, lsl #3]
     35c:	cmp	w27, #0x0
     360:	b.le	3a0 <__kernel_rem_pio2.constprop.0+0x18c>
     364:	add	x1, x26, x1
     368:	add	w8, w27, #0x1
     36c:	mov	x0, #0x1                   	// #1
     370:	fmul	d1, d0, d11
     374:	add	x2, x28, x0, lsl #2
     378:	ldr	d3, [x1, #-8]!
     37c:	add	x0, x0, #0x1
     380:	fcvtzs	w3, d1
     384:	scvtf	d1, w3
     388:	fmsub	d2, d1, d10, d0
     38c:	fadd	d0, d1, d3
     390:	fcvtzs	w3, d2
     394:	stur	w3, [x2, #-4]
     398:	cmp	x0, x8
     39c:	b.ne	370 <__kernel_rem_pio2.constprop.0+0x15c>  // b.any
     3a0:	mov	w0, w21
     3a4:	bl	0 <scalbn>
     3a8:	fmul	d1, d0, d8
     3ac:	fmov	d2, #8.000000000000000000e+00
     3b0:	frintm	d1, d1
     3b4:	fmsub	d0, d1, d2, d0
     3b8:	fcvtzs	w25, d0
     3bc:	scvtf	d1, w25
     3c0:	fsub	d9, d0, d1
     3c4:	cmp	w21, #0x0
     3c8:	b.le	500 <__kernel_rem_pio2.constprop.0+0x2ec>
     3cc:	sub	w0, w27, #0x1
     3d0:	mov	w2, #0x18                  	// #24
     3d4:	sub	w2, w2, w21
     3d8:	mov	w3, #0x17                  	// #23
     3dc:	sxtw	x0, w0
     3e0:	sub	w3, w3, w21
     3e4:	ldr	w8, [x28, x0, lsl #2]
     3e8:	asr	w1, w8, w2
     3ec:	add	w25, w25, w1
     3f0:	lsl	w1, w1, w2
     3f4:	sub	w8, w8, w1
     3f8:	str	w8, [x28, x0, lsl #2]
     3fc:	asr	w8, w8, w3
     400:	cmp	w8, #0x0
     404:	b.gt	6f0 <__kernel_rem_pio2.constprop.0+0x4dc>
     408:	fcmp	d9, #0.0
     40c:	b.ne	5d8 <__kernel_rem_pio2.constprop.0+0x3c4>  // b.any
     410:	cmp	w27, #0x4
     414:	b.le	44c <__kernel_rem_pio2.constprop.0+0x238>
     418:	sub	w0, w27, #0x2
     41c:	sub	x3, x23, #0x3
     420:	sub	w2, w27, #0x5
     424:	mov	w1, #0x0                   	// #0
     428:	sxtw	x0, w0
     42c:	sub	x3, x3, x2
     430:	add	x2, x28, x0, lsl #2
     434:	sub	x0, x0, #0x1
     438:	ldr	w2, [x2, #4]
     43c:	orr	w1, w1, w2
     440:	cmp	x0, x3
     444:	b.ne	430 <__kernel_rem_pio2.constprop.0+0x21c>  // b.any
     448:	cbnz	w1, 720 <__kernel_rem_pio2.constprop.0+0x50c>
     44c:	ldr	w0, [sp, #52]
     450:	cbnz	w0, 4f4 <__kernel_rem_pio2.constprop.0+0x2e0>
     454:	ldr	w0, [sp, #48]
     458:	cbnz	w0, 848 <__kernel_rem_pio2.constprop.0+0x634>
     45c:	ldr	w0, [sp, #44]
     460:	mov	w8, #0x3                   	// #3
     464:	cbnz	w0, 4f8 <__kernel_rem_pio2.constprop.0+0x2e4>
     468:	ldr	w0, [sp, #40]
     46c:	add	w8, w27, #0x5
     470:	cbnz	w0, 854 <__kernel_rem_pio2.constprop.0+0x640>
     474:	ldr	w0, [sp, #24]
     478:	add	w3, w27, #0x1
     47c:	add	w2, w27, #0x2
     480:	add	x7, x23, w0, sxtw
     484:	sxtw	x2, w2
     488:	ldr	x0, [sp, #8]
     48c:	add	x3, x0, w3, sxtw
     490:	ldr	x0, [sp]
     494:	sub	x9, x3, x7
     498:	add	x3, x0, x3, lsl #3
     49c:	nop
     4a0:	ldr	w7, [x24, x2, lsl #2]
     4a4:	movi	d0, #0x0
     4a8:	mov	x1, x3
     4ac:	mov	x0, #0x0                   	// #0
     4b0:	scvtf	d1, w7
     4b4:	str	d1, [x3, x9, lsl #3]
     4b8:	ldr	d2, [x20, x0, lsl #3]
     4bc:	add	x0, x0, #0x1
     4c0:	ldr	d1, [x1], #-8
     4c4:	fmadd	d0, d2, d1, d0
     4c8:	cmp	w19, w0
     4cc:	b.ge	4b8 <__kernel_rem_pio2.constprop.0+0x2a4>  // b.tcont
     4d0:	add	x1, x26, x2, lsl #3
     4d4:	add	x2, x2, #0x1
     4d8:	sub	w0, w2, #0x1
     4dc:	add	x3, x3, #0x8
     4e0:	stur	d0, [x1, #-8]
     4e4:	cmp	w8, w0
     4e8:	b.ge	4a0 <__kernel_rem_pio2.constprop.0+0x28c>  // b.tcont
     4ec:	mov	w27, w8
     4f0:	b	350 <__kernel_rem_pio2.constprop.0+0x13c>
     4f4:	mov	w8, #0x1                   	// #1
     4f8:	add	w8, w27, w8
     4fc:	b	474 <__kernel_rem_pio2.constprop.0+0x260>
     500:	b.ne	6dc <__kernel_rem_pio2.constprop.0+0x4c8>  // b.any
     504:	sub	w0, w27, #0x1
     508:	ldr	w8, [x28, w0, sxtw #2]
     50c:	asr	w8, w8, #23
     510:	cmp	w8, #0x0
     514:	b.le	408 <__kernel_rem_pio2.constprop.0+0x1f4>
     518:	add	w25, w25, #0x1
     51c:	cmp	w27, #0x0
     520:	b.le	890 <__kernel_rem_pio2.constprop.0+0x67c>
     524:	ldr	w2, [x28]
     528:	mov	x0, x28
     52c:	mov	w1, #0x0                   	// #0
     530:	cbnz	w2, 54c <__kernel_rem_pio2.constprop.0+0x338>
     534:	add	w1, w1, #0x1
     538:	add	x0, x0, #0x4
     53c:	cmp	w27, w1
     540:	b.le	57c <__kernel_rem_pio2.constprop.0+0x368>
     544:	ldr	w2, [x0]
     548:	cbz	w2, 534 <__kernel_rem_pio2.constprop.0+0x320>
     54c:	mov	w3, #0x1000000             	// #16777216
     550:	sub	w2, w3, w2
     554:	str	w2, [x0]
     558:	b	568 <__kernel_rem_pio2.constprop.0+0x354>
     55c:	ldr	w2, [x0]
     560:	sub	w2, w22, w2
     564:	str	w2, [x0]
     568:	add	w1, w1, #0x1
     56c:	add	x0, x0, #0x4
     570:	cmp	w27, w1
     574:	b.gt	55c <__kernel_rem_pio2.constprop.0+0x348>
     578:	mov	w2, #0x1                   	// #1
     57c:	cmp	w21, #0x0
     580:	b.le	5a8 <__kernel_rem_pio2.constprop.0+0x394>
     584:	cmp	w21, #0x1
     588:	b.eq	708 <__kernel_rem_pio2.constprop.0+0x4f4>  // b.none
     58c:	cmp	w21, #0x2
     590:	b.ne	5a8 <__kernel_rem_pio2.constprop.0+0x394>  // b.any
     594:	sub	w0, w27, #0x1
     598:	sxtw	x0, w0
     59c:	ldr	w1, [x28, x0, lsl #2]
     5a0:	and	w1, w1, #0x3fffff
     5a4:	str	w1, [x28, x0, lsl #2]
     5a8:	cmp	w8, #0x2
     5ac:	b.ne	408 <__kernel_rem_pio2.constprop.0+0x1f4>  // b.any
     5b0:	fmov	d0, #1.000000000000000000e+00
     5b4:	fsub	d9, d0, d9
     5b8:	cbz	w2, 408 <__kernel_rem_pio2.constprop.0+0x1f4>
     5bc:	mov	w0, w21
     5c0:	str	w8, [sp, #28]
     5c4:	bl	0 <scalbn>
     5c8:	fsub	d9, d9, d0
     5cc:	ldr	w8, [sp, #28]
     5d0:	fcmp	d9, #0.0
     5d4:	b.eq	410 <__kernel_rem_pio2.constprop.0+0x1fc>  // b.none
     5d8:	fmov	d0, d9
     5dc:	neg	w0, w21
     5e0:	str	w8, [sp]
     5e4:	bl	0 <scalbn>
     5e8:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     5ec:	fmov	d2, x0
     5f0:	ldr	w8, [sp]
     5f4:	fcmpe	d0, d2
     5f8:	b.ge	860 <__kernel_rem_pio2.constprop.0+0x64c>  // b.tcont
     5fc:	fcvtzs	w0, d0
     600:	str	w0, [x28, x23, lsl #2]
     604:	fmov	d0, #1.000000000000000000e+00
     608:	mov	w0, w21
     60c:	str	w8, [sp]
     610:	bl	0 <scalbn>
     614:	fmov	d1, d0
     618:	ldr	w8, [sp]
     61c:	tbnz	w27, #31, 768 <__kernel_rem_pio2.constprop.0+0x554>
     620:	sxtw	x19, w27
     624:	sub	w5, w27, #0x1
     628:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     62c:	fmov	d2, x0
     630:	mov	x6, #0xfffffffffffffffe    	// #-2
     634:	sxtw	x5, w5
     638:	mov	x0, x5
     63c:	nop
     640:	add	x2, x28, x0, lsl #2
     644:	add	x1, x26, x0, lsl #3
     648:	sub	x0, x0, #0x1
     64c:	ldr	w2, [x2, #4]
     650:	scvtf	d0, w2
     654:	fmul	d0, d0, d1
     658:	fmul	d1, d1, d2
     65c:	str	d0, [x1, #8]
     660:	cmp	x0, x6
     664:	b.ne	640 <__kernel_rem_pio2.constprop.0+0x42c>  // b.any
     668:	add	x7, sp, #0x118
     66c:	adrp	x0, 0 <__kernel_tan>
     670:	add	x3, x0, #0x0
     674:	add	x2, x26, x19, lsl #3
     678:	add	x3, x3, #0x110
     67c:	mov	x4, x7
     680:	mov	w1, #0x0                   	// #0
     684:	nop
     688:	movi	d0, #0x0
     68c:	mov	x0, #0x0                   	// #0
     690:	b	6a0 <__kernel_rem_pio2.constprop.0+0x48c>
     694:	add	x0, x0, #0x1
     698:	cmp	w1, w0
     69c:	b.lt	6b4 <__kernel_rem_pio2.constprop.0+0x4a0>  // b.tstop
     6a0:	ldr	d2, [x3, x0, lsl #3]
     6a4:	ldr	d1, [x2, x0, lsl #3]
     6a8:	fmadd	d0, d2, d1, d0
     6ac:	cmp	x0, #0x4
     6b0:	b.ne	694 <__kernel_rem_pio2.constprop.0+0x480>  // b.any
     6b4:	str	d0, [x4], #8
     6b8:	sub	x2, x2, #0x8
     6bc:	add	w0, w1, #0x1
     6c0:	cmp	w1, w27
     6c4:	b.eq	7c8 <__kernel_rem_pio2.constprop.0+0x5b4>  // b.none
     6c8:	mov	w1, w0
     6cc:	b	688 <__kernel_rem_pio2.constprop.0+0x474>
     6d0:	str	xzr, [x2, x0, lsl #3]
     6d4:	add	x0, x0, #0x1
     6d8:	b	2a8 <__kernel_rem_pio2.constprop.0+0x94>
     6dc:	fmov	d0, #5.000000000000000000e-01
     6e0:	fcmpe	d9, d0
     6e4:	b.ge	824 <__kernel_rem_pio2.constprop.0+0x610>  // b.tcont
     6e8:	mov	w8, #0x0                   	// #0
     6ec:	b	408 <__kernel_rem_pio2.constprop.0+0x1f4>
     6f0:	add	w25, w25, #0x1
     6f4:	mov	w2, #0x0                   	// #0
     6f8:	cmp	w27, #0x0
     6fc:	b.gt	524 <__kernel_rem_pio2.constprop.0+0x310>
     700:	cmp	w21, #0x1
     704:	b.ne	58c <__kernel_rem_pio2.constprop.0+0x378>  // b.any
     708:	sub	w0, w27, #0x1
     70c:	sxtw	x0, w0
     710:	ldr	w1, [x28, x0, lsl #2]
     714:	and	w1, w1, #0x7fffff
     718:	str	w1, [x28, x0, lsl #2]
     71c:	b	5a8 <__kernel_rem_pio2.constprop.0+0x394>
     720:	sub	w27, w27, #0x1
     724:	sub	w21, w21, #0x18
     728:	add	x7, x28, x23, lsl #2
     72c:	sxtw	x19, w27
     730:	ldr	w0, [x28, x19, lsl #2]
     734:	cbnz	w0, 8c4 <__kernel_rem_pio2.constprop.0+0x6b0>
     738:	ldur	w0, [x7, #-8]
     73c:	sub	x7, x7, #0x4
     740:	sub	w27, w27, #0x1
     744:	sub	w21, w21, #0x18
     748:	cbz	w0, 738 <__kernel_rem_pio2.constprop.0+0x524>
     74c:	fmov	d0, #1.000000000000000000e+00
     750:	mov	w0, w21
     754:	str	w8, [sp]
     758:	bl	0 <scalbn>
     75c:	fmov	d1, d0
     760:	ldr	w8, [sp]
     764:	tbz	w27, #31, 620 <__kernel_rem_pio2.constprop.0+0x40c>
     768:	ldr	d0, [sp, #280]
     76c:	cbnz	w8, 8e0 <__kernel_rem_pio2.constprop.0+0x6cc>
     770:	ldr	x0, [sp, #16]
     774:	str	xzr, [x0]
     778:	ldr	x0, [sp, #16]
     77c:	adrp	x1, 0 <__stack_chk_guard>
     780:	ldr	x1, [x1]
     784:	str	d0, [x0, #8]
     788:	and	w0, w25, #0x7
     78c:	ldr	x3, [sp, #600]
     790:	ldr	x2, [x1]
     794:	subs	x3, x3, x2
     798:	mov	x2, #0x0                   	// #0
     79c:	b.ne	8f8 <__kernel_rem_pio2.constprop.0+0x6e4>  // b.any
     7a0:	add	sp, sp, #0x260
     7a4:	ldp	x19, x20, [sp, #16]
     7a8:	ldp	x21, x22, [sp, #32]
     7ac:	ldp	x23, x24, [sp, #48]
     7b0:	ldp	x25, x26, [sp, #64]
     7b4:	ldp	x27, x28, [sp, #80]
     7b8:	ldp	d8, d9, [sp, #96]
     7bc:	ldp	d10, d11, [sp, #112]
     7c0:	ldp	x29, x30, [sp], #128
     7c4:	ret
     7c8:	movi	d1, #0x0
     7cc:	add	x0, x7, x5, lsl #3
     7d0:	sub	x5, x5, #0x1
     7d4:	ldr	d0, [x0, #8]
     7d8:	fadd	d1, d1, d0
     7dc:	cmp	x5, x6
     7e0:	b.ne	7cc <__kernel_rem_pio2.constprop.0+0x5b8>  // b.any
     7e4:	ldr	d0, [sp, #280]
     7e8:	fsub	d0, d0, d1
     7ec:	cbnz	w8, 8ac <__kernel_rem_pio2.constprop.0+0x698>
     7f0:	ldr	x0, [sp, #16]
     7f4:	str	d1, [x0]
     7f8:	cbz	w27, 778 <__kernel_rem_pio2.constprop.0+0x564>
     7fc:	add	x1, sp, #0x120
     800:	mov	w0, #0x1                   	// #1
     804:	ldr	d1, [x1], #8
     808:	add	w0, w0, #0x1
     80c:	fadd	d0, d0, d1
     810:	cmp	w0, w27
     814:	b.le	804 <__kernel_rem_pio2.constprop.0+0x5f0>
     818:	cbz	w8, 778 <__kernel_rem_pio2.constprop.0+0x564>
     81c:	fneg	d0, d0
     820:	b	778 <__kernel_rem_pio2.constprop.0+0x564>
     824:	add	w25, w25, #0x1
     828:	mov	w8, #0x2                   	// #2
     82c:	cmp	w27, #0x0
     830:	b.gt	524 <__kernel_rem_pio2.constprop.0+0x310>
     834:	fmov	d0, #1.000000000000000000e+00
     838:	fsub	d9, d0, d9
     83c:	fcmp	d9, #0.0
     840:	b.eq	44c <__kernel_rem_pio2.constprop.0+0x238>  // b.none
     844:	b	5d8 <__kernel_rem_pio2.constprop.0+0x3c4>
     848:	mov	w8, #0x2                   	// #2
     84c:	add	w8, w27, w8
     850:	b	474 <__kernel_rem_pio2.constprop.0+0x260>
     854:	mov	w8, #0x4                   	// #4
     858:	add	w8, w27, w8
     85c:	b	474 <__kernel_rem_pio2.constprop.0+0x260>
     860:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     864:	fmov	d1, x0
     868:	add	w27, w27, #0x1
     86c:	add	w21, w21, #0x18
     870:	fmul	d1, d0, d1
     874:	fcvtzs	w0, d1
     878:	scvtf	d1, w0
     87c:	fmsub	d0, d1, d2, d0
     880:	fcvtzs	w1, d0
     884:	str	w1, [x28, x23, lsl #2]
     888:	str	w0, [x28, w27, sxtw #2]
     88c:	b	604 <__kernel_rem_pio2.constprop.0+0x3f0>
     890:	cmp	w8, #0x2
     894:	b.ne	8a0 <__kernel_rem_pio2.constprop.0+0x68c>  // b.any
     898:	fmov	d0, #1.000000000000000000e+00
     89c:	fsub	d9, d0, d9
     8a0:	fcmp	d9, #0.0
     8a4:	b.eq	44c <__kernel_rem_pio2.constprop.0+0x238>  // b.none
     8a8:	b	5d8 <__kernel_rem_pio2.constprop.0+0x3c4>
     8ac:	ldr	x0, [sp, #16]
     8b0:	fneg	d1, d1
     8b4:	str	d1, [x0]
     8b8:	cbnz	w27, 7fc <__kernel_rem_pio2.constprop.0+0x5e8>
     8bc:	fneg	d0, d0
     8c0:	b	778 <__kernel_rem_pio2.constprop.0+0x564>
     8c4:	fmov	d0, #1.000000000000000000e+00
     8c8:	mov	w0, w21
     8cc:	str	w8, [sp]
     8d0:	bl	0 <scalbn>
     8d4:	fmov	d1, d0
     8d8:	ldr	w8, [sp]
     8dc:	b	624 <__kernel_rem_pio2.constprop.0+0x410>
     8e0:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
     8e4:	fmov	d1, x0
     8e8:	ldr	x0, [sp, #16]
     8ec:	fneg	d0, d0
     8f0:	str	d1, [x0]
     8f4:	b	778 <__kernel_rem_pio2.constprop.0+0x564>
     8f8:	bl	0 <__stack_chk_fail>
     8fc:	nop

0000000000000900 <__ieee754_rem_pio2>:
     900:	sub	sp, sp, #0x40
     904:	fmov	x4, d0
     908:	adrp	x1, 0 <__stack_chk_guard>
     90c:	ldr	x1, [x1]
     910:	stp	x29, x30, [sp, #32]
     914:	add	x29, sp, #0x20
     918:	ubfx	x5, x4, #32, #31
     91c:	stp	x19, x20, [sp, #48]
     920:	mov	x19, x0
     924:	mov	w0, #0x21fb                	// #8699
     928:	ldr	x2, [x1]
     92c:	str	x2, [sp, #24]
     930:	mov	x2, #0x0                   	// #0
     934:	movk	w0, #0x3fe9, lsl #16
     938:	cmp	w5, w0
     93c:	b.le	a60 <__ieee754_rem_pio2+0x160>
     940:	mov	w0, #0xd97b                	// #55675
     944:	lsr	x20, x4, #32
     948:	movk	w0, #0x4002, lsl #16
     94c:	cmp	w5, w0
     950:	b.gt	9c4 <__ieee754_rem_pio2+0xc4>
     954:	adrp	x0, 0 <__kernel_tan>
     958:	ldr	d1, [x0]
     95c:	mov	w0, #0x21fb                	// #8699
     960:	movk	w0, #0x3ff9, lsl #16
     964:	cmp	w20, #0x0
     968:	b.le	bb0 <__ieee754_rem_pio2+0x2b0>
     96c:	fsub	d0, d0, d1
     970:	cmp	w5, w0
     974:	b.eq	b5c <__ieee754_rem_pio2+0x25c>  // b.none
     978:	adrp	x0, 0 <__kernel_tan>
     97c:	ldr	d2, [x0]
     980:	fsub	d1, d0, d2
     984:	fsub	d0, d0, d1
     988:	fsub	d0, d0, d2
     98c:	mov	w0, #0x1                   	// #1
     990:	stp	d1, d0, [x19]
     994:	nop
     998:	adrp	x1, 0 <__stack_chk_guard>
     99c:	ldr	x1, [x1]
     9a0:	ldr	x3, [sp, #24]
     9a4:	ldr	x2, [x1]
     9a8:	subs	x3, x3, x2
     9ac:	mov	x2, #0x0                   	// #0
     9b0:	b.ne	c00 <__ieee754_rem_pio2+0x300>  // b.any
     9b4:	ldp	x29, x30, [sp, #32]
     9b8:	ldp	x19, x20, [sp, #48]
     9bc:	add	sp, sp, #0x40
     9c0:	ret
     9c4:	mov	w0, #0x21fb                	// #8699
     9c8:	movk	w0, #0x4139, lsl #16
     9cc:	cmp	w5, w0
     9d0:	b.le	a70 <__ieee754_rem_pio2+0x170>
     9d4:	mov	w0, #0x7fefffff            	// #2146435071
     9d8:	cmp	w5, w0
     9dc:	b.gt	b94 <__ieee754_rem_pio2+0x294>
     9e0:	asr	w2, w5, #20
     9e4:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     9e8:	sub	w2, w2, #0x416
     9ec:	fmov	d1, x0
     9f0:	mov	w3, #0x3                   	// #3
     9f4:	sub	w5, w5, w2, lsl #20
     9f8:	bfi	x4, x5, #32, #32
     9fc:	fmov	d0, x4
     a00:	fcvtzs	w0, d0
     a04:	scvtf	d2, w0
     a08:	fsub	d0, d0, d2
     a0c:	str	d2, [sp]
     a10:	fmul	d0, d0, d1
     a14:	fcvtzs	w0, d0
     a18:	scvtf	d2, w0
     a1c:	fsub	d0, d0, d2
     a20:	fmul	d0, d0, d1
     a24:	fcmp	d0, #0.0
     a28:	stp	d2, d0, [sp, #8]
     a2c:	b.ne	a3c <__ieee754_rem_pio2+0x13c>  // b.any
     a30:	cmp	w0, #0x0
     a34:	cset	w3, ne	// ne = any
     a38:	add	w3, w3, #0x1
     a3c:	mov	x1, x19
     a40:	mov	x0, sp
     a44:	bl	214 <__kernel_rem_pio2.constprop.0>
     a48:	tbz	w20, #31, 998 <__ieee754_rem_pio2+0x98>
     a4c:	ldr	q0, [x19]
     a50:	neg	w0, w0
     a54:	fneg	v0.2d, v0.2d
     a58:	str	q0, [x19]
     a5c:	b	998 <__ieee754_rem_pio2+0x98>
     a60:	mov	w0, #0x0                   	// #0
     a64:	str	d0, [x19]
     a68:	str	xzr, [x19, #8]
     a6c:	b	998 <__ieee754_rem_pio2+0x98>
     a70:	adrp	x0, 0 <__kernel_tan>
     a74:	fabs	d0, d0
     a78:	fmov	d2, #5.000000000000000000e-01
     a7c:	ldr	d3, [x0]
     a80:	adrp	x0, 0 <__kernel_tan>
     a84:	ldr	d4, [x0]
     a88:	adrp	x0, 0 <__kernel_tan>
     a8c:	fmadd	d2, d0, d3, d2
     a90:	ldr	d1, [x0]
     a94:	fcvtzs	w0, d2
     a98:	scvtf	d3, w0
     a9c:	fmsub	d0, d3, d4, d0
     aa0:	fmul	d1, d3, d1
     aa4:	fsub	d2, d0, d1
     aa8:	cmp	w0, #0x1f
     aac:	b.gt	ae4 <__ieee754_rem_pio2+0x1e4>
     ab0:	adrp	x1, 0 <__kernel_tan>
     ab4:	add	x1, x1, #0x0
     ab8:	add	x1, x1, #0x150
     abc:	sub	w2, w0, #0x1
     ac0:	ldr	w1, [x1, w2, sxtw #2]
     ac4:	cmp	w1, w5
     ac8:	b.eq	ae4 <__ieee754_rem_pio2+0x1e4>  // b.none
     acc:	str	d2, [x19]
     ad0:	fsub	d0, d0, d2
     ad4:	fsub	d0, d0, d1
     ad8:	tbnz	w20, #31, b80 <__ieee754_rem_pio2+0x280>
     adc:	str	d0, [x19, #8]
     ae0:	b	998 <__ieee754_rem_pio2+0x98>
     ae4:	fmov	x1, d2
     ae8:	asr	w5, w5, #20
     aec:	ubfx	x1, x1, #52, #11
     af0:	sub	w1, w5, w1
     af4:	cmp	w1, #0x10
     af8:	b.le	acc <__ieee754_rem_pio2+0x1cc>
     afc:	adrp	x1, 0 <__kernel_tan>
     b00:	ldr	d2, [x1]
     b04:	adrp	x1, 0 <__kernel_tan>
     b08:	ldr	d1, [x1]
     b0c:	fmsub	d4, d3, d2, d0
     b10:	fsub	d0, d0, d4
     b14:	fmsub	d0, d3, d2, d0
     b18:	fnmsub	d1, d3, d1, d0
     b1c:	fsub	d2, d4, d1
     b20:	fmov	x1, d2
     b24:	ubfx	x1, x1, #52, #11
     b28:	sub	w5, w5, w1
     b2c:	cmp	w5, #0x31
     b30:	b.le	ba4 <__ieee754_rem_pio2+0x2a4>
     b34:	adrp	x1, 0 <__kernel_tan>
     b38:	ldr	d2, [x1]
     b3c:	adrp	x1, 0 <__kernel_tan>
     b40:	ldr	d1, [x1]
     b44:	fmsub	d0, d3, d2, d4
     b48:	fsub	d4, d4, d0
     b4c:	fmsub	d4, d3, d2, d4
     b50:	fnmsub	d1, d3, d1, d4
     b54:	fsub	d2, d0, d1
     b58:	b	acc <__ieee754_rem_pio2+0x1cc>
     b5c:	adrp	x0, 0 <__kernel_tan>
     b60:	ldr	d1, [x0]
     b64:	adrp	x0, 0 <__kernel_tan>
     b68:	ldr	d2, [x0]
     b6c:	fsub	d0, d0, d1
     b70:	fsub	d1, d0, d2
     b74:	fsub	d0, d0, d1
     b78:	fsub	d0, d0, d2
     b7c:	b	98c <__ieee754_rem_pio2+0x8c>
     b80:	mov	v2.d[1], v0.d[0]
     b84:	neg	w0, w0
     b88:	fneg	v2.2d, v2.2d
     b8c:	str	q2, [x19]
     b90:	b	998 <__ieee754_rem_pio2+0x98>
     b94:	fsub	d0, d0, d0
     b98:	mov	w0, #0x0                   	// #0
     b9c:	stp	d0, d0, [x19]
     ba0:	b	998 <__ieee754_rem_pio2+0x98>
     ba4:	fmov	d0, d4
     ba8:	str	d2, [x19]
     bac:	b	ad0 <__ieee754_rem_pio2+0x1d0>
     bb0:	fadd	d0, d0, d1
     bb4:	cmp	w5, w0
     bb8:	b.eq	bdc <__ieee754_rem_pio2+0x2dc>  // b.none
     bbc:	adrp	x0, 0 <__kernel_tan>
     bc0:	ldr	d2, [x0]
     bc4:	fadd	d1, d0, d2
     bc8:	fsub	d0, d0, d1
     bcc:	fadd	d0, d0, d2
     bd0:	mov	w0, #0xffffffff            	// #-1
     bd4:	stp	d1, d0, [x19]
     bd8:	b	998 <__ieee754_rem_pio2+0x98>
     bdc:	adrp	x0, 0 <__kernel_tan>
     be0:	ldr	d1, [x0]
     be4:	adrp	x0, 0 <__kernel_tan>
     be8:	ldr	d2, [x0]
     bec:	fadd	d0, d0, d1
     bf0:	fadd	d1, d0, d2
     bf4:	fsub	d0, d0, d1
     bf8:	fadd	d0, d0, d2
     bfc:	b	bd0 <__ieee754_rem_pio2+0x2d0>
     c00:	bl	0 <__stack_chk_fail>

0000000000000c04 <pts_ieee754_acos>:
     c04:	fmov	x1, d0
     c08:	mov	w2, #0x3fefffff            	// #1072693247
     c0c:	ubfx	x0, x1, #32, #31
     c10:	lsr	x3, x1, #32
     c14:	cmp	w0, w2
     c18:	b.le	c44 <pts_ieee754_acos+0x40>
     c1c:	mov	w2, #0xc0100000            	// #-1072693248
     c20:	add	w0, w0, w2
     c24:	orr	w0, w0, w1
     c28:	cbnz	w0, ca4 <pts_ieee754_acos+0xa0>
     c2c:	adrp	x0, 0 <__kernel_tan>
     c30:	movi	d1, #0x0
     c34:	cmp	w3, #0x0
     c38:	ldr	d0, [x0]
     c3c:	fcsel	d0, d0, d1, le
     c40:	ret
     c44:	stp	x29, x30, [sp, #-48]!
     c48:	mov	w1, #0x3fdfffff            	// #1071644671
     c4c:	mov	x29, sp
     c50:	cmp	w0, w1
     c54:	b.gt	c74 <pts_ieee754_acos+0x70>
     c58:	mov	w1, #0x3c600000            	// #1012924416
     c5c:	cmp	w0, w1
     c60:	b.gt	d64 <pts_ieee754_acos+0x160>
     c64:	adrp	x0, 0 <__kernel_tan>
     c68:	ldr	d0, [x0]
     c6c:	ldp	x29, x30, [sp], #48
     c70:	ret
     c74:	stp	d8, d9, [sp, #16]
     c78:	tbnz	w3, #31, e18 <pts_ieee754_acos+0x214>
     c7c:	fmov	d8, #1.000000000000000000e+00
     c80:	fmov	d1, #5.000000000000000000e-01
     c84:	fsub	d8, d8, d0
     c88:	fmul	d8, d8, d1
     c8c:	fcmp	d8, #0.0
     c90:	b.pl	cb0 <pts_ieee754_acos+0xac>  // b.nfrst
     c94:	fmov	d0, d8
     c98:	bl	0 <sqrt>
     c9c:	fmov	d3, d0
     ca0:	b	cb4 <pts_ieee754_acos+0xb0>
     ca4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     ca8:	fmov	d0, x0
     cac:	ret
     cb0:	fsqrt	d3, d8
     cb4:	adrp	x0, 0 <__kernel_tan>
     cb8:	fmov	d4, #1.000000000000000000e+00
     cbc:	ldr	d1, [x0]
     cc0:	adrp	x0, 0 <__kernel_tan>
     cc4:	ldr	d19, [x0]
     cc8:	adrp	x0, 0 <__kernel_tan>
     ccc:	fmadd	d19, d8, d1, d19
     cd0:	ldr	d17, [x0]
     cd4:	adrp	x0, 0 <__kernel_tan>
     cd8:	ldr	d0, [x0]
     cdc:	adrp	x0, 0 <__kernel_tan>
     ce0:	ldr	d18, [x0]
     ce4:	adrp	x0, 0 <__kernel_tan>
     ce8:	fmadd	d18, d8, d0, d18
     cec:	movi	v0.2d, #0xffffffff00000000
     cf0:	ldr	d7, [x0]
     cf4:	adrp	x0, 0 <__kernel_tan>
     cf8:	fmadd	d17, d19, d8, d17
     cfc:	ldr	d16, [x0]
     d00:	adrp	x0, 0 <__kernel_tan>
     d04:	and	v2.8b, v3.8b, v0.8b
     d08:	ldr	d5, [x0]
     d0c:	adrp	x0, 0 <__kernel_tan>
     d10:	ldr	d6, [x0]
     d14:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     d18:	fmadd	d16, d18, d8, d16
     d1c:	movk	x0, #0x3fc5, lsl #48
     d20:	fmov	d1, x0
     d24:	fmsub	d0, d2, d2, d8
     d28:	fmadd	d7, d17, d8, d7
     d2c:	fadd	d9, d2, d3
     d30:	fmadd	d6, d16, d8, d6
     d34:	fdiv	d0, d0, d9
     d38:	fmadd	d5, d7, d8, d5
     d3c:	fmadd	d4, d6, d8, d4
     d40:	fmadd	d1, d5, d8, d1
     d44:	fmul	d1, d1, d8
     d48:	ldp	d8, d9, [sp, #16]
     d4c:	ldp	x29, x30, [sp], #48
     d50:	fdiv	d1, d1, d4
     d54:	fmadd	d0, d1, d3, d0
     d58:	fadd	d0, d0, d2
     d5c:	fadd	d0, d0, d0
     d60:	ret
     d64:	adrp	x0, 0 <__kernel_tan>
     d68:	fmul	d2, d0, d0
     d6c:	stp	d8, d9, [sp, #16]
     d70:	fmov	d5, #1.000000000000000000e+00
     d74:	ldr	d3, [x0]
     d78:	adrp	x0, 0 <__kernel_tan>
     d7c:	ldr	d18, [x0]
     d80:	adrp	x0, 0 <__kernel_tan>
     d84:	fmadd	d18, d2, d3, d18
     d88:	ldr	d16, [x0]
     d8c:	adrp	x0, 0 <__kernel_tan>
     d90:	ldr	d1, [x0]
     d94:	adrp	x0, 0 <__kernel_tan>
     d98:	ldr	d17, [x0]
     d9c:	adrp	x0, 0 <__kernel_tan>
     da0:	fmadd	d17, d2, d1, d17
     da4:	ldr	d8, [x0]
     da8:	adrp	x0, 0 <__kernel_tan>
     dac:	fmadd	d16, d18, d2, d16
     db0:	ldr	d9, [x0]
     db4:	adrp	x0, 0 <__kernel_tan>
     db8:	ldr	d6, [x0]
     dbc:	adrp	x0, 0 <__kernel_tan>
     dc0:	ldr	d7, [x0]
     dc4:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     dc8:	fmadd	d9, d17, d2, d9
     dcc:	movk	x0, #0x3fc5, lsl #48
     dd0:	fmov	d3, x0
     dd4:	adrp	x0, 0 <__kernel_tan>
     dd8:	fmadd	d8, d16, d2, d8
     ddc:	ldr	d4, [x0]
     de0:	adrp	x0, 0 <__kernel_tan>
     de4:	ldr	d1, [x0]
     de8:	fmadd	d7, d9, d2, d7
     dec:	fmadd	d6, d8, d2, d6
     df0:	ldp	d8, d9, [sp, #16]
     df4:	ldp	x29, x30, [sp], #48
     df8:	fmadd	d5, d7, d2, d5
     dfc:	fmadd	d3, d6, d2, d3
     e00:	fmul	d2, d3, d2
     e04:	fdiv	d2, d2, d5
     e08:	fmsub	d2, d0, d2, d4
     e0c:	fsub	d0, d0, d2
     e10:	fsub	d0, d1, d0
     e14:	ret
     e18:	fmov	d1, #1.000000000000000000e+00
     e1c:	fmov	d3, #5.000000000000000000e-01
     e20:	adrp	x0, 0 <__kernel_tan>
     e24:	fadd	d0, d0, d1
     e28:	ldr	d17, [x0]
     e2c:	adrp	x0, 0 <__kernel_tan>
     e30:	ldr	d9, [x0]
     e34:	adrp	x0, 0 <__kernel_tan>
     e38:	fmul	d0, d0, d3
     e3c:	ldr	d6, [x0]
     e40:	adrp	x0, 0 <__kernel_tan>
     e44:	ldr	d16, [x0]
     e48:	adrp	x0, 0 <__kernel_tan>
     e4c:	fmadd	d9, d0, d17, d9
     e50:	fcmp	d0, #0.0
     e54:	ldr	d4, [x0]
     e58:	adrp	x0, 0 <__kernel_tan>
     e5c:	ldr	d7, [x0]
     e60:	adrp	x0, 0 <__kernel_tan>
     e64:	fmadd	d7, d0, d16, d7
     e68:	ldr	d2, [x0]
     e6c:	adrp	x0, 0 <__kernel_tan>
     e70:	ldr	d5, [x0]
     e74:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     e78:	fmadd	d6, d9, d0, d6
     e7c:	movk	x0, #0x3fc5, lsl #48
     e80:	fmov	d8, x0
     e84:	adrp	x0, 0 <__kernel_tan>
     e88:	ldr	d3, [x0]
     e8c:	fmadd	d5, d7, d0, d5
     e90:	fmadd	d4, d6, d0, d4
     e94:	fmadd	d3, d5, d0, d3
     e98:	fmadd	d2, d4, d0, d2
     e9c:	fmadd	d3, d3, d0, d1
     ea0:	fmadd	d8, d2, d0, d8
     ea4:	fmul	d8, d8, d0
     ea8:	b.pl	ec0 <pts_ieee754_acos+0x2bc>  // b.nfrst
     eac:	str	d3, [sp, #40]
     eb0:	bl	0 <sqrt>
     eb4:	ldr	d3, [sp, #40]
     eb8:	fmov	d1, d0
     ebc:	b	ec4 <pts_ieee754_acos+0x2c0>
     ec0:	fsqrt	d1, d0
     ec4:	fdiv	d8, d8, d3
     ec8:	adrp	x0, 0 <__kernel_tan>
     ecc:	fmov	d3, #2.000000000000000000e+00
     ed0:	ldr	d2, [x0]
     ed4:	adrp	x0, 0 <__kernel_tan>
     ed8:	ldr	d0, [x0]
     edc:	fmadd	d2, d8, d1, d2
     ee0:	ldp	d8, d9, [sp, #16]
     ee4:	ldp	x29, x30, [sp], #48
     ee8:	fadd	d1, d2, d1
     eec:	fmsub	d0, d1, d3, d0
     ef0:	ret

0000000000000ef4 <pts_ieee754_asin>:
     ef4:	fmov	x0, d0
     ef8:	stp	x29, x30, [sp, #-64]!
     efc:	fmov	d1, d0
     f00:	mov	x29, sp
     f04:	stp	x19, x20, [sp, #16]
     f08:	mov	w1, #0x3fefffff            	// #1072693247
     f0c:	ubfx	x19, x0, #32, #31
     f10:	cmp	w19, w1
     f14:	b.le	f60 <pts_ieee754_asin+0x6c>
     f18:	mov	w1, #0xc0100000            	// #-1072693248
     f1c:	add	w19, w19, w1
     f20:	orr	w19, w19, w0
     f24:	cbz	w19, f3c <pts_ieee754_asin+0x48>
     f28:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     f2c:	fmov	d0, x0
     f30:	ldp	x19, x20, [sp, #16]
     f34:	ldp	x29, x30, [sp], #64
     f38:	ret
     f3c:	adrp	x0, 0 <__kernel_tan>
     f40:	ldp	x19, x20, [sp, #16]
     f44:	ldr	d0, [x0]
     f48:	adrp	x0, 0 <__kernel_tan>
     f4c:	ldr	d2, [x0]
     f50:	fmul	d0, d1, d0
     f54:	ldp	x29, x30, [sp], #64
     f58:	fmadd	d0, d1, d2, d0
     f5c:	ret
     f60:	lsr	x20, x0, #32
     f64:	mov	w0, #0x3fdfffff            	// #1071644671
     f68:	cmp	w19, w0
     f6c:	b.gt	fa8 <pts_ieee754_asin+0xb4>
     f70:	mov	w0, #0x3e3fffff            	// #1044381695
     f74:	cmp	w19, w0
     f78:	b.gt	10b0 <pts_ieee754_asin+0x1bc>
     f7c:	adrp	x0, 0 <__kernel_tan>
     f80:	fmov	d3, #1.000000000000000000e+00
     f84:	ldr	d2, [x0]
     f88:	fadd	d2, d0, d2
     f8c:	fcmpe	d2, d3
     f90:	b.gt	f30 <pts_ieee754_asin+0x3c>
     f94:	movi	d0, #0x0
     f98:	fmadd	d0, d1, d0, d1
     f9c:	ldp	x19, x20, [sp, #16]
     fa0:	ldp	x29, x30, [sp], #64
     fa4:	ret
     fa8:	fabs	d1, d0
     fac:	fmov	d0, #1.000000000000000000e+00
     fb0:	fmov	d18, #5.000000000000000000e-01
     fb4:	adrp	x0, 0 <__kernel_tan>
     fb8:	stp	d8, d9, [sp, #32]
     fbc:	adrp	x1, 0 <__kernel_tan>
     fc0:	ldr	d17, [x0]
     fc4:	fsub	d1, d0, d1
     fc8:	adrp	x0, 0 <__kernel_tan>
     fcc:	ldr	d3, [x1]
     fd0:	ldr	d9, [x0]
     fd4:	adrp	x0, 0 <__kernel_tan>
     fd8:	fmul	d1, d1, d18
     fdc:	ldr	d6, [x0]
     fe0:	adrp	x0, 0 <__kernel_tan>
     fe4:	ldr	d16, [x0]
     fe8:	adrp	x0, 0 <__kernel_tan>
     fec:	fmadd	d9, d1, d17, d9
     ff0:	fcmp	d1, #0.0
     ff4:	ldr	d4, [x0]
     ff8:	adrp	x0, 0 <__kernel_tan>
     ffc:	ldr	d7, [x0]
    1000:	adrp	x0, 0 <__kernel_tan>
    1004:	fmadd	d7, d1, d16, d7
    1008:	ldr	d2, [x0]
    100c:	adrp	x0, 0 <__kernel_tan>
    1010:	ldr	d5, [x0]
    1014:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1018:	fmadd	d6, d9, d1, d6
    101c:	movk	x0, #0x3fc5, lsl #48
    1020:	fmov	d8, x0
    1024:	fmadd	d5, d7, d1, d5
    1028:	fmadd	d4, d6, d1, d4
    102c:	fmadd	d3, d5, d1, d3
    1030:	fmadd	d2, d4, d1, d2
    1034:	fmadd	d3, d3, d1, d0
    1038:	fmadd	d8, d2, d1, d8
    103c:	fmul	d8, d8, d1
    1040:	b.pl	105c <pts_ieee754_asin+0x168>  // b.nfrst
    1044:	fmov	d0, d1
    1048:	stp	d1, d3, [sp, #48]
    104c:	bl	0 <sqrt>
    1050:	fmov	d2, d0
    1054:	ldp	d1, d3, [sp, #48]
    1058:	b	1060 <pts_ieee754_asin+0x16c>
    105c:	fsqrt	d2, d1
    1060:	fdiv	d8, d8, d3
    1064:	mov	w0, #0x3332                	// #13106
    1068:	movk	w0, #0x3fef, lsl #16
    106c:	cmp	w19, w0
    1070:	b.le	1148 <pts_ieee754_asin+0x254>
    1074:	fmadd	d2, d2, d8, d2
    1078:	adrp	x0, 0 <__kernel_tan>
    107c:	fmov	d3, #2.000000000000000000e+00
    1080:	ldr	d1, [x0]
    1084:	adrp	x0, 0 <__kernel_tan>
    1088:	ldr	d0, [x0]
    108c:	fmadd	d1, d2, d3, d1
    1090:	fsub	d0, d0, d1
    1094:	fneg	d1, d0
    1098:	cmp	w20, #0x0
    109c:	ldp	x19, x20, [sp, #16]
    10a0:	ldp	d8, d9, [sp, #32]
    10a4:	fcsel	d0, d1, d0, le
    10a8:	ldp	x29, x30, [sp], #64
    10ac:	ret
    10b0:	adrp	x0, 0 <__kernel_tan>
    10b4:	fmul	d0, d0, d0
    10b8:	stp	d8, d9, [sp, #32]
    10bc:	ldr	d3, [x0]
    10c0:	adrp	x0, 0 <__kernel_tan>
    10c4:	ldr	d16, [x0]
    10c8:	adrp	x0, 0 <__kernel_tan>
    10cc:	fmadd	d16, d0, d3, d16
    10d0:	fmov	d3, #1.000000000000000000e+00
    10d4:	ldr	d8, [x0]
    10d8:	adrp	x0, 0 <__kernel_tan>
    10dc:	ldr	d2, [x0]
    10e0:	adrp	x0, 0 <__kernel_tan>
    10e4:	ldr	d9, [x0]
    10e8:	adrp	x0, 0 <__kernel_tan>
    10ec:	fmadd	d9, d0, d2, d9
    10f0:	ldr	d6, [x0]
    10f4:	adrp	x0, 0 <__kernel_tan>
    10f8:	fmadd	d8, d0, d16, d8
    10fc:	ldr	d7, [x0]
    1100:	adrp	x0, 0 <__kernel_tan>
    1104:	ldr	d4, [x0]
    1108:	adrp	x0, 0 <__kernel_tan>
    110c:	ldr	d5, [x0]
    1110:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1114:	fmadd	d7, d0, d9, d7
    1118:	movk	x0, #0x3fc5, lsl #48
    111c:	fmov	d2, x0
    1120:	fmadd	d6, d0, d8, d6
    1124:	ldp	d8, d9, [sp, #32]
    1128:	fmadd	d5, d0, d7, d5
    112c:	fmadd	d4, d0, d6, d4
    1130:	fmadd	d3, d0, d5, d3
    1134:	fmadd	d2, d0, d4, d2
    1138:	fmul	d0, d0, d2
    113c:	fdiv	d0, d0, d3
    1140:	fmadd	d0, d1, d0, d1
    1144:	b	f9c <pts_ieee754_asin+0xa8>
    1148:	movi	v0.2d, #0xffffffff00000000
    114c:	fadd	d6, d2, d2
    1150:	adrp	x0, 0 <__kernel_tan>
    1154:	fmov	d5, #2.000000000000000000e+00
    1158:	ldr	d3, [x0]
    115c:	adrp	x0, 0 <__kernel_tan>
    1160:	and	v4.8b, v2.8b, v0.8b
    1164:	ldr	d0, [x0]
    1168:	fmsub	d1, d4, d4, d1
    116c:	fadd	d2, d4, d2
    1170:	fmsub	d4, d4, d5, d0
    1174:	fdiv	d1, d1, d2
    1178:	fmsub	d1, d1, d5, d3
    117c:	fnmsub	d1, d6, d8, d1
    1180:	fsub	d1, d1, d4
    1184:	fsub	d0, d0, d1
    1188:	b	1094 <pts_ieee754_asin+0x1a0>
    118c:	nop

0000000000001190 <pts_ieee754_atan>:
    1190:	fmov	x1, d0
    1194:	fmov	d1, d0
    1198:	mov	w2, #0x440fffff            	// #1141899263
    119c:	ubfx	x0, x1, #32, #31
    11a0:	lsr	x3, x1, #32
    11a4:	cmp	w0, w2
    11a8:	b.le	11f0 <pts_ieee754_atan+0x60>
    11ac:	mov	w2, #0x7ff00000            	// #2146435072
    11b0:	cmp	w0, w2
    11b4:	b.gt	11e8 <pts_ieee754_atan+0x58>
    11b8:	cmp	w1, #0x0
    11bc:	ccmp	w0, w2, #0x0, ne	// ne = any
    11c0:	b.eq	11e8 <pts_ieee754_atan+0x58>  // b.none
    11c4:	adrp	x0, 0 <__kernel_tan>
    11c8:	add	x0, x0, #0x0
    11cc:	cmp	w3, #0x0
    11d0:	b.le	1354 <pts_ieee754_atan+0x1c4>
    11d4:	adrp	x1, 0 <__kernel_tan>
    11d8:	ldr	d0, [x0, #488]
    11dc:	ldr	d1, [x1]
    11e0:	fadd	d0, d0, d1
    11e4:	ret
    11e8:	fadd	d0, d1, d1
    11ec:	ret
    11f0:	mov	w1, #0x3fdbffff            	// #1071382527
    11f4:	cmp	w0, w1
    11f8:	b.gt	12d8 <pts_ieee754_atan+0x148>
    11fc:	mov	w1, #0x3e3fffff            	// #1044381695
    1200:	cmp	w0, w1
    1204:	b.le	1338 <pts_ieee754_atan+0x1a8>
    1208:	mov	x0, #0xffffffffffffffff    	// #-1
    120c:	fmul	d3, d1, d1
    1210:	adrp	x1, 0 <__kernel_tan>
    1214:	ldr	d21, [x1]
    1218:	adrp	x1, 0 <__kernel_tan>
    121c:	fmul	d2, d3, d3
    1220:	ldr	d19, [x1]
    1224:	adrp	x1, 0 <__kernel_tan>
    1228:	ldr	d20, [x1]
    122c:	adrp	x1, 0 <__kernel_tan>
    1230:	fmadd	d19, d2, d21, d19
    1234:	ldr	d18, [x1]
    1238:	adrp	x1, 0 <__kernel_tan>
    123c:	fmadd	d18, d2, d20, d18
    1240:	ldr	d17, [x1]
    1244:	adrp	x1, 0 <__kernel_tan>
    1248:	ldr	d16, [x1]
    124c:	adrp	x1, 0 <__kernel_tan>
    1250:	ldr	d7, [x1]
    1254:	adrp	x1, 0 <__kernel_tan>
    1258:	fmadd	d17, d19, d2, d17
    125c:	ldr	d6, [x1]
    1260:	adrp	x1, 0 <__kernel_tan>
    1264:	fmadd	d16, d18, d2, d16
    1268:	ldr	d5, [x1]
    126c:	adrp	x1, 0 <__kernel_tan>
    1270:	ldr	d0, [x1]
    1274:	adrp	x1, 0 <__kernel_tan>
    1278:	ldr	d4, [x1]
    127c:	fmadd	d7, d17, d2, d7
    1280:	fmadd	d6, d16, d2, d6
    1284:	fmadd	d5, d7, d2, d5
    1288:	fmadd	d0, d6, d2, d0
    128c:	fmadd	d4, d5, d2, d4
    1290:	fmul	d0, d0, d2
    1294:	fmadd	d0, d4, d3, d0
    1298:	fmul	d0, d1, d0
    129c:	cmn	w0, #0x1
    12a0:	b.eq	1368 <pts_ieee754_atan+0x1d8>  // b.none
    12a4:	adrp	x1, 0 <__kernel_tan>
    12a8:	add	x1, x1, #0x0
    12ac:	add	x2, x1, #0x1d0
    12b0:	add	x1, x1, #0x1f0
    12b4:	cmp	w3, #0x0
    12b8:	ldr	d3, [x2, x0, lsl #3]
    12bc:	ldr	d2, [x1, x0, lsl #3]
    12c0:	fsub	d0, d0, d3
    12c4:	fsub	d0, d0, d1
    12c8:	fsub	d0, d2, d0
    12cc:	fneg	d1, d0
    12d0:	fcsel	d0, d1, d0, lt	// lt = tstop
    12d4:	ret
    12d8:	fabs	d1, d0
    12dc:	mov	w1, #0x3ff2ffff            	// #1072889855
    12e0:	cmp	w0, w1
    12e4:	b.gt	1310 <pts_ieee754_atan+0x180>
    12e8:	mov	w1, #0x3fe5ffff            	// #1072037887
    12ec:	cmp	w0, w1
    12f0:	b.gt	1380 <pts_ieee754_atan+0x1f0>
    12f4:	fmov	d2, #2.000000000000000000e+00
    12f8:	fmov	d0, #-1.000000000000000000e+00
    12fc:	mov	x0, #0x0                   	// #0
    1300:	fmadd	d0, d1, d2, d0
    1304:	fadd	d1, d1, d2
    1308:	fdiv	d1, d0, d1
    130c:	b	120c <pts_ieee754_atan+0x7c>
    1310:	add	w1, w1, #0x108, lsl #12
    1314:	cmp	w0, w1
    1318:	b.gt	1370 <pts_ieee754_atan+0x1e0>
    131c:	fmov	d2, #1.500000000000000000e+00
    1320:	fmov	d0, #1.000000000000000000e+00
    1324:	mov	x0, #0x2                   	// #2
    1328:	fmadd	d0, d1, d2, d0
    132c:	fsub	d1, d1, d2
    1330:	fdiv	d1, d1, d0
    1334:	b	120c <pts_ieee754_atan+0x7c>
    1338:	adrp	x0, 0 <__kernel_tan>
    133c:	fmov	d3, #1.000000000000000000e+00
    1340:	ldr	d2, [x0]
    1344:	fadd	d2, d0, d2
    1348:	fcmpe	d2, d3
    134c:	b.gt	11e4 <pts_ieee754_atan+0x54>
    1350:	b	1208 <pts_ieee754_atan+0x78>
    1354:	adrp	x1, 0 <__kernel_tan>
    1358:	ldr	d1, [x0, #488]
    135c:	ldr	d0, [x1]
    1360:	fsub	d0, d0, d1
    1364:	ret
    1368:	fsub	d0, d1, d0
    136c:	ret
    1370:	fmov	d0, #-1.000000000000000000e+00
    1374:	mov	x0, #0x3                   	// #3
    1378:	fdiv	d1, d0, d1
    137c:	b	120c <pts_ieee754_atan+0x7c>
    1380:	fmov	d0, #1.000000000000000000e+00
    1384:	mov	x0, #0x1                   	// #1
    1388:	fsub	d2, d1, d0
    138c:	fadd	d1, d1, d0
    1390:	fdiv	d1, d2, d1
    1394:	b	120c <pts_ieee754_atan+0x7c>
    1398:	nop
    139c:	nop

00000000000013a0 <pts_ieee754_atan2>:
    13a0:	fmov	x1, d1
    13a4:	fmov	d2, d0
    13a8:	mov	w3, #0x7ff00000            	// #2146435072
    13ac:	neg	w0, w1
    13b0:	ubfx	x5, x1, #32, #31
    13b4:	orr	w0, w0, w1
    13b8:	orr	w0, w5, w0, lsr #31
    13bc:	cmp	w0, w3
    13c0:	b.hi	147c <pts_ieee754_atan2+0xdc>  // b.pmore
    13c4:	fmov	x0, d0
    13c8:	neg	w2, w0
    13cc:	ubfx	x6, x0, #32, #31
    13d0:	orr	w2, w2, w0
    13d4:	lsr	x8, x0, #32
    13d8:	orr	w2, w6, w2, lsr #31
    13dc:	cmp	w2, w3
    13e0:	b.hi	147c <pts_ieee754_atan2+0xdc>  // b.pmore
    13e4:	lsr	x7, x1, #32
    13e8:	mov	w2, #0xc0100000            	// #-1072693248
    13ec:	add	w2, w7, w2
    13f0:	orr	w2, w2, w1
    13f4:	cbz	w2, 1498 <pts_ieee754_atan2+0xf8>
    13f8:	asr	w4, w7, #30
    13fc:	lsr	w2, w8, #31
    1400:	and	w4, w4, #0x2
    1404:	orr	w0, w6, w0
    1408:	orr	w4, w4, w2
    140c:	cbz	w0, 1484 <pts_ieee754_atan2+0xe4>
    1410:	orr	w1, w5, w1
    1414:	cbz	w1, 149c <pts_ieee754_atan2+0xfc>
    1418:	cmp	w5, w3
    141c:	b.eq	1520 <pts_ieee754_atan2+0x180>  // b.none
    1420:	cmp	w6, w3
    1424:	b.eq	149c <pts_ieee754_atan2+0xfc>  // b.none
    1428:	sub	w6, w6, w5
    142c:	asr	w6, w6, #20
    1430:	cmp	w6, #0x3c
    1434:	b.gt	14fc <pts_ieee754_atan2+0x15c>
    1438:	cmp	w7, #0x0
    143c:	mov	w0, #0xffffffc4            	// #-60
    1440:	movi	d0, #0x0
    1444:	ccmp	w6, w0, #0x0, lt	// lt = tstop
    1448:	b.ge	15ac <pts_ieee754_atan2+0x20c>  // b.tcont
    144c:	cmp	w4, #0x1
    1450:	b.eq	15a4 <pts_ieee754_atan2+0x204>  // b.none
    1454:	cmp	w4, #0x2
    1458:	b.ne	1580 <pts_ieee754_atan2+0x1e0>  // b.any
    145c:	adrp	x0, 0 <__kernel_tan>
    1460:	add	x0, x0, #0x0
    1464:	adrp	x1, 0 <__kernel_tan>
    1468:	ldr	d2, [x0, #8]
    146c:	ldr	d1, [x1]
    1470:	fsub	d0, d0, d2
    1474:	fsub	d0, d1, d0
    1478:	ret
    147c:	fadd	d0, d1, d2
    1480:	ret
    1484:	cmp	w4, #0x2
    1488:	b.eq	14d0 <pts_ieee754_atan2+0x130>  // b.none
    148c:	cmp	w4, #0x3
    1490:	b.eq	14b8 <pts_ieee754_atan2+0x118>  // b.none
    1494:	ret
    1498:	b	1190 <pts_ieee754_atan>
    149c:	adrp	x0, 0 <__kernel_tan>
    14a0:	tbnz	w8, #31, 14e8 <pts_ieee754_atan2+0x148>
    14a4:	adrp	x1, 0 <__kernel_tan>
    14a8:	ldr	d0, [x0]
    14ac:	ldr	d1, [x1]
    14b0:	fadd	d0, d0, d1
    14b4:	ret
    14b8:	adrp	x0, 0 <__kernel_tan>
    14bc:	adrp	x1, 0 <__kernel_tan>
    14c0:	ldr	d1, [x0]
    14c4:	ldr	d0, [x1]
    14c8:	fsub	d0, d0, d1
    14cc:	ret
    14d0:	adrp	x0, 0 <__kernel_tan>
    14d4:	adrp	x1, 0 <__kernel_tan>
    14d8:	ldr	d0, [x0]
    14dc:	ldr	d1, [x1]
    14e0:	fadd	d0, d0, d1
    14e4:	ret
    14e8:	adrp	x1, 0 <__kernel_tan>
    14ec:	ldr	d1, [x0]
    14f0:	ldr	d0, [x1]
    14f4:	fsub	d0, d0, d1
    14f8:	ret
    14fc:	adrp	x0, 0 <__kernel_tan>
    1500:	add	x0, x0, #0x0
    1504:	adrp	x1, 0 <__kernel_tan>
    1508:	fmov	d1, #5.000000000000000000e-01
    150c:	ldr	d2, [x0, #8]
    1510:	ldr	d0, [x1]
    1514:	fmadd	d0, d2, d1, d0
    1518:	tbnz	w4, #0, 15a4 <pts_ieee754_atan2+0x204>
    151c:	ret
    1520:	cmp	w6, w5
    1524:	b.eq	1550 <pts_ieee754_atan2+0x1b0>  // b.none
    1528:	cmp	w4, #0x2
    152c:	b.eq	14d0 <pts_ieee754_atan2+0x130>  // b.none
    1530:	cmp	w4, #0x3
    1534:	b.eq	14b8 <pts_ieee754_atan2+0x118>  // b.none
    1538:	movi	d1, #0x0
    153c:	cmp	w4, #0x1
    1540:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
    1544:	fmov	d0, x0
    1548:	fcsel	d0, d0, d1, eq	// eq = none
    154c:	ret
    1550:	adrp	x0, 0 <__kernel_tan>
    1554:	cmp	w4, #0x2
    1558:	b.eq	1648 <pts_ieee754_atan2+0x2a8>  // b.none
    155c:	cmp	w4, #0x3
    1560:	b.eq	1634 <pts_ieee754_atan2+0x294>  // b.none
    1564:	cmp	w4, #0x1
    1568:	b.eq	1620 <pts_ieee754_atan2+0x280>  // b.none
    156c:	adrp	x1, 0 <__kernel_tan>
    1570:	ldr	d0, [x0]
    1574:	ldr	d1, [x1]
    1578:	fadd	d0, d0, d1
    157c:	ret
    1580:	cbz	w4, 165c <pts_ieee754_atan2+0x2bc>
    1584:	adrp	x0, 0 <__kernel_tan>
    1588:	add	x0, x0, #0x0
    158c:	adrp	x1, 0 <__kernel_tan>
    1590:	ldr	d2, [x0, #8]
    1594:	ldr	d1, [x1]
    1598:	fsub	d0, d0, d2
    159c:	fsub	d0, d0, d1
    15a0:	ret
    15a4:	fneg	d0, d0
    15a8:	ret
    15ac:	fdiv	d0, d2, d1
    15b0:	stp	x29, x30, [sp, #-16]!
    15b4:	mov	x29, sp
    15b8:	fabs	d0, d0
    15bc:	bl	1190 <pts_ieee754_atan>
    15c0:	cmp	w4, #0x1
    15c4:	b.eq	15f4 <pts_ieee754_atan2+0x254>  // b.none
    15c8:	cmp	w4, #0x2
    15cc:	b.ne	15fc <pts_ieee754_atan2+0x25c>  // b.any
    15d0:	adrp	x0, 0 <__kernel_tan>
    15d4:	add	x0, x0, #0x0
    15d8:	adrp	x1, 0 <__kernel_tan>
    15dc:	ldr	d2, [x0, #8]
    15e0:	ldr	d1, [x1]
    15e4:	fsub	d0, d0, d2
    15e8:	fsub	d0, d1, d0
    15ec:	ldp	x29, x30, [sp], #16
    15f0:	ret
    15f4:	fneg	d0, d0
    15f8:	b	15ec <pts_ieee754_atan2+0x24c>
    15fc:	cbz	w4, 15ec <pts_ieee754_atan2+0x24c>
    1600:	adrp	x0, 0 <__kernel_tan>
    1604:	add	x0, x0, #0x0
    1608:	adrp	x1, 0 <__kernel_tan>
    160c:	ldr	d2, [x0, #8]
    1610:	ldr	d1, [x1]
    1614:	fsub	d0, d0, d2
    1618:	fsub	d0, d0, d1
    161c:	b	15ec <pts_ieee754_atan2+0x24c>
    1620:	adrp	x1, 0 <__kernel_tan>
    1624:	ldr	d1, [x0]
    1628:	ldr	d0, [x1]
    162c:	fsub	d0, d0, d1
    1630:	ret
    1634:	adrp	x1, 0 <__kernel_tan>
    1638:	ldr	d1, [x0]
    163c:	ldr	d0, [x1]
    1640:	fsub	d0, d0, d1
    1644:	ret
    1648:	adrp	x1, 0 <__kernel_tan>
    164c:	ldr	d0, [x0]
    1650:	ldr	d1, [x1]
    1654:	fadd	d0, d0, d1
    1658:	ret
    165c:	ret

0000000000001660 <pts_ieee754_cos>:
    1660:	sub	sp, sp, #0x30
    1664:	mov	w1, #0x21fb                	// #8699
    1668:	adrp	x0, 0 <__stack_chk_guard>
    166c:	ldr	x0, [x0]
    1670:	fmov	d1, d0
    1674:	stp	x29, x30, [sp, #32]
    1678:	add	x29, sp, #0x20
    167c:	movk	w1, #0x3fe9, lsl #16
    1680:	ldr	x2, [x0]
    1684:	str	x2, [sp, #24]
    1688:	mov	x2, #0x0                   	// #0
    168c:	fmov	x0, d0
    1690:	ubfx	x0, x0, #32, #31
    1694:	cmp	w0, w1
    1698:	b.le	17a4 <pts_ieee754_cos+0x144>
    169c:	mov	w1, #0x7fefffff            	// #2146435071
    16a0:	cmp	w0, w1
    16a4:	b.le	16d4 <pts_ieee754_cos+0x74>
    16a8:	fsub	d0, d0, d0
    16ac:	adrp	x0, 0 <__stack_chk_guard>
    16b0:	ldr	x0, [x0]
    16b4:	ldr	x2, [sp, #24]
    16b8:	ldr	x1, [x0]
    16bc:	subs	x2, x2, x1
    16c0:	mov	x1, #0x0                   	// #0
    16c4:	b.ne	1b94 <pts_ieee754_cos+0x534>  // b.any
    16c8:	ldp	x29, x30, [sp, #32]
    16cc:	add	sp, sp, #0x30
    16d0:	ret
    16d4:	add	x0, sp, #0x8
    16d8:	bl	900 <__ieee754_rem_pio2>
    16dc:	and	w0, w0, #0x3
    16e0:	cmp	w0, #0x1
    16e4:	b.eq	19f8 <pts_ieee754_cos+0x398>  // b.none
    16e8:	cmp	w0, #0x2
    16ec:	b.eq	18c0 <pts_ieee754_cos+0x260>  // b.none
    16f0:	cbnz	w0, 1974 <pts_ieee754_cos+0x314>
    16f4:	ldp	d1, d7, [sp, #8]
    16f8:	mov	w1, #0x3e3fffff            	// #1044381695
    16fc:	fmov	x0, d1
    1700:	ubfx	x0, x0, #32, #31
    1704:	cmp	w0, w1
    1708:	b.le	1b0c <pts_ieee754_cos+0x4ac>
    170c:	adrp	x1, 0 <__kernel_tan>
    1710:	fmul	d2, d1, d1
    1714:	ldr	d16, [x1]
    1718:	adrp	x1, 0 <__kernel_tan>
    171c:	ldr	d6, [x1]
    1720:	adrp	x1, 0 <__kernel_tan>
    1724:	fmadd	d6, d2, d16, d6
    1728:	ldr	d5, [x1]
    172c:	adrp	x1, 0 <__kernel_tan>
    1730:	ldr	d3, [x1]
    1734:	adrp	x1, 0 <__kernel_tan>
    1738:	ldr	d0, [x1]
    173c:	adrp	x1, 0 <__kernel_tan>
    1740:	ldr	d4, [x1]
    1744:	mov	w1, #0x3332                	// #13106
    1748:	fmadd	d5, d2, d6, d5
    174c:	movk	w1, #0x3fd3, lsl #16
    1750:	fmadd	d3, d2, d5, d3
    1754:	fmadd	d0, d2, d3, d0
    1758:	fmadd	d4, d2, d0, d4
    175c:	fmul	d4, d2, d4
    1760:	cmp	w0, w1
    1764:	b.le	1b60 <pts_ieee754_cos+0x500>
    1768:	mov	w1, #0x3fe90000            	// #1072234496
    176c:	cmp	w0, w1
    1770:	b.gt	1b88 <pts_ieee754_cos+0x528>
    1774:	sub	w0, w0, #0x200, lsl #12
    1778:	fmov	d3, x0
    177c:	fmov	d0, #1.000000000000000000e+00
    1780:	shl	d3, d3, #32
    1784:	fsub	d0, d0, d3
    1788:	fmov	d5, #5.000000000000000000e-01
    178c:	fmul	d1, d1, d7
    1790:	fnmsub	d1, d2, d4, d1
    1794:	fnmsub	d3, d2, d5, d3
    1798:	fsub	d3, d3, d1
    179c:	fsub	d0, d0, d3
    17a0:	b	16ac <pts_ieee754_cos+0x4c>
    17a4:	mov	w1, #0x3e3fffff            	// #1044381695
    17a8:	cmp	w0, w1
    17ac:	b.le	184c <pts_ieee754_cos+0x1ec>
    17b0:	adrp	x1, 0 <__kernel_tan>
    17b4:	fmul	d2, d0, d0
    17b8:	ldr	d7, [x1]
    17bc:	adrp	x1, 0 <__kernel_tan>
    17c0:	ldr	d6, [x1]
    17c4:	adrp	x1, 0 <__kernel_tan>
    17c8:	fmadd	d6, d2, d7, d6
    17cc:	ldr	d5, [x1]
    17d0:	adrp	x1, 0 <__kernel_tan>
    17d4:	ldr	d4, [x1]
    17d8:	adrp	x1, 0 <__kernel_tan>
    17dc:	ldr	d0, [x1]
    17e0:	adrp	x1, 0 <__kernel_tan>
    17e4:	ldr	d3, [x1]
    17e8:	mov	w1, #0x3332                	// #13106
    17ec:	fmadd	d5, d2, d6, d5
    17f0:	movk	w1, #0x3fd3, lsl #16
    17f4:	fmadd	d4, d2, d5, d4
    17f8:	fmadd	d0, d2, d4, d0
    17fc:	fmadd	d3, d2, d0, d3
    1800:	fmul	d3, d2, d3
    1804:	cmp	w0, w1
    1808:	b.le	18a0 <pts_ieee754_cos+0x240>
    180c:	mov	w1, #0x3fe90000            	// #1072234496
    1810:	cmp	w0, w1
    1814:	b.gt	1a88 <pts_ieee754_cos+0x428>
    1818:	sub	w0, w0, #0x200, lsl #12
    181c:	fmov	d0, x0
    1820:	fmov	d5, #1.000000000000000000e+00
    1824:	shl	d0, d0, #32
    1828:	fsub	d5, d5, d0
    182c:	movi	d4, #0x0
    1830:	fmov	d6, #5.000000000000000000e-01
    1834:	fnmsub	d0, d2, d6, d0
    1838:	fmul	d1, d1, d4
    183c:	fnmsub	d1, d2, d3, d1
    1840:	fsub	d0, d0, d1
    1844:	fsub	d0, d5, d0
    1848:	b	16ac <pts_ieee754_cos+0x4c>
    184c:	fcvtzs	w0, d0
    1850:	cbz	w0, 1a80 <pts_ieee754_cos+0x420>
    1854:	adrp	x0, 0 <__kernel_tan>
    1858:	fmul	d2, d0, d0
    185c:	ldr	d7, [x0]
    1860:	adrp	x0, 0 <__kernel_tan>
    1864:	ldr	d6, [x0]
    1868:	adrp	x0, 0 <__kernel_tan>
    186c:	fmadd	d6, d2, d7, d6
    1870:	ldr	d5, [x0]
    1874:	adrp	x0, 0 <__kernel_tan>
    1878:	ldr	d4, [x0]
    187c:	adrp	x0, 0 <__kernel_tan>
    1880:	ldr	d0, [x0]
    1884:	adrp	x0, 0 <__kernel_tan>
    1888:	ldr	d3, [x0]
    188c:	fmadd	d5, d2, d6, d5
    1890:	fmadd	d4, d5, d2, d4
    1894:	fmadd	d0, d4, d2, d0
    1898:	fmadd	d3, d0, d2, d3
    189c:	fmul	d3, d3, d2
    18a0:	movi	d0, #0x0
    18a4:	fmov	d5, #5.000000000000000000e-01
    18a8:	fmov	d4, #1.000000000000000000e+00
    18ac:	fmul	d0, d1, d0
    18b0:	fnmsub	d0, d2, d3, d0
    18b4:	fnmsub	d0, d2, d5, d0
    18b8:	fsub	d0, d4, d0
    18bc:	b	16ac <pts_ieee754_cos+0x4c>
    18c0:	ldp	d1, d7, [sp, #8]
    18c4:	mov	w1, #0x3e3fffff            	// #1044381695
    18c8:	fmov	x0, d1
    18cc:	ubfx	x0, x0, #32, #31
    18d0:	cmp	w0, w1
    18d4:	b.le	1a94 <pts_ieee754_cos+0x434>
    18d8:	adrp	x1, 0 <__kernel_tan>
    18dc:	fmul	d2, d1, d1
    18e0:	ldr	d16, [x1]
    18e4:	adrp	x1, 0 <__kernel_tan>
    18e8:	ldr	d6, [x1]
    18ec:	adrp	x1, 0 <__kernel_tan>
    18f0:	fmadd	d6, d2, d16, d6
    18f4:	ldr	d5, [x1]
    18f8:	adrp	x1, 0 <__kernel_tan>
    18fc:	ldr	d3, [x1]
    1900:	adrp	x1, 0 <__kernel_tan>
    1904:	ldr	d0, [x1]
    1908:	adrp	x1, 0 <__kernel_tan>
    190c:	ldr	d4, [x1]
    1910:	mov	w1, #0x3332                	// #13106
    1914:	fmadd	d5, d2, d6, d5
    1918:	movk	w1, #0x3fd3, lsl #16
    191c:	fmadd	d3, d2, d5, d3
    1920:	fmadd	d0, d2, d3, d0
    1924:	fmadd	d4, d2, d0, d4
    1928:	fmul	d4, d2, d4
    192c:	cmp	w0, w1
    1930:	b.le	1aec <pts_ieee754_cos+0x48c>
    1934:	mov	w1, #0x3fe90000            	// #1072234496
    1938:	cmp	w0, w1
    193c:	b.gt	1b7c <pts_ieee754_cos+0x51c>
    1940:	sub	w0, w0, #0x200, lsl #12
    1944:	fmov	d3, x0
    1948:	fmov	d0, #1.000000000000000000e+00
    194c:	shl	d3, d3, #32
    1950:	fsub	d0, d0, d3
    1954:	fmov	d5, #5.000000000000000000e-01
    1958:	fmul	d1, d1, d7
    195c:	fnmsub	d1, d2, d4, d1
    1960:	fnmsub	d3, d2, d5, d3
    1964:	fsub	d3, d3, d1
    1968:	fsub	d0, d0, d3
    196c:	fneg	d0, d0
    1970:	b	16ac <pts_ieee754_cos+0x4c>
    1974:	ldp	d0, d2, [sp, #8]
    1978:	mov	w0, #0x3e3fffff            	// #1044381695
    197c:	fmov	x1, d0
    1980:	ubfx	x1, x1, #32, #31
    1984:	cmp	w1, w0
    1988:	b.gt	1994 <pts_ieee754_cos+0x334>
    198c:	fcvtzs	w0, d0
    1990:	cbz	w0, 16ac <pts_ieee754_cos+0x4c>
    1994:	adrp	x0, 0 <__kernel_tan>
    1998:	fmul	d3, d0, d0
    199c:	fmov	d17, #5.000000000000000000e-01
    19a0:	ldr	d7, [x0]
    19a4:	adrp	x0, 0 <__kernel_tan>
    19a8:	ldr	d6, [x0]
    19ac:	adrp	x0, 0 <__kernel_tan>
    19b0:	fmadd	d6, d3, d7, d6
    19b4:	fmul	d7, d0, d3
    19b8:	ldr	d5, [x0]
    19bc:	adrp	x0, 0 <__kernel_tan>
    19c0:	ldr	d4, [x0]
    19c4:	adrp	x0, 0 <__kernel_tan>
    19c8:	ldr	d1, [x0]
    19cc:	adrp	x0, 0 <__kernel_tan>
    19d0:	ldr	d16, [x0]
    19d4:	fmadd	d5, d3, d6, d5
    19d8:	fmadd	d4, d3, d5, d4
    19dc:	fmadd	d1, d3, d4, d1
    19e0:	fmul	d1, d7, d1
    19e4:	fnmsub	d1, d2, d17, d1
    19e8:	fnmsub	d2, d3, d1, d2
    19ec:	fmadd	d2, d7, d16, d2
    19f0:	fsub	d0, d0, d2
    19f4:	b	16ac <pts_ieee754_cos+0x4c>
    19f8:	ldp	d0, d2, [sp, #8]
    19fc:	mov	w0, #0x3e3fffff            	// #1044381695
    1a00:	fmov	x1, d0
    1a04:	ubfx	x1, x1, #32, #31
    1a08:	cmp	w1, w0
    1a0c:	b.gt	1a18 <pts_ieee754_cos+0x3b8>
    1a10:	fcvtzs	w0, d0
    1a14:	cbz	w0, 196c <pts_ieee754_cos+0x30c>
    1a18:	adrp	x0, 0 <__kernel_tan>
    1a1c:	fmul	d3, d0, d0
    1a20:	fmov	d17, #5.000000000000000000e-01
    1a24:	ldr	d7, [x0]
    1a28:	adrp	x0, 0 <__kernel_tan>
    1a2c:	ldr	d6, [x0]
    1a30:	adrp	x0, 0 <__kernel_tan>
    1a34:	fmadd	d6, d3, d7, d6
    1a38:	fmul	d7, d0, d3
    1a3c:	ldr	d5, [x0]
    1a40:	adrp	x0, 0 <__kernel_tan>
    1a44:	ldr	d4, [x0]
    1a48:	adrp	x0, 0 <__kernel_tan>
    1a4c:	ldr	d1, [x0]
    1a50:	adrp	x0, 0 <__kernel_tan>
    1a54:	ldr	d16, [x0]
    1a58:	fmadd	d5, d3, d6, d5
    1a5c:	fmadd	d4, d3, d5, d4
    1a60:	fmadd	d1, d3, d4, d1
    1a64:	fmul	d1, d7, d1
    1a68:	fnmsub	d1, d2, d17, d1
    1a6c:	fnmsub	d2, d3, d1, d2
    1a70:	fmadd	d2, d7, d16, d2
    1a74:	fsub	d0, d0, d2
    1a78:	fneg	d0, d0
    1a7c:	b	16ac <pts_ieee754_cos+0x4c>
    1a80:	fmov	d0, #1.000000000000000000e+00
    1a84:	b	16ac <pts_ieee754_cos+0x4c>
    1a88:	fmov	d5, #7.187500000000000000e-01
    1a8c:	fmov	d0, #2.812500000000000000e-01
    1a90:	b	182c <pts_ieee754_cos+0x1cc>
    1a94:	fcvtzs	w0, d1
    1a98:	fmov	d0, #-1.000000000000000000e+00
    1a9c:	cbz	w0, 16ac <pts_ieee754_cos+0x4c>
    1aa0:	adrp	x0, 0 <__kernel_tan>
    1aa4:	fmul	d2, d1, d1
    1aa8:	ldr	d16, [x0]
    1aac:	adrp	x0, 0 <__kernel_tan>
    1ab0:	ldr	d6, [x0]
    1ab4:	adrp	x0, 0 <__kernel_tan>
    1ab8:	fmadd	d6, d2, d16, d6
    1abc:	ldr	d5, [x0]
    1ac0:	adrp	x0, 0 <__kernel_tan>
    1ac4:	ldr	d3, [x0]
    1ac8:	adrp	x0, 0 <__kernel_tan>
    1acc:	ldr	d0, [x0]
    1ad0:	adrp	x0, 0 <__kernel_tan>
    1ad4:	ldr	d4, [x0]
    1ad8:	fmadd	d5, d2, d6, d5
    1adc:	fmadd	d3, d2, d5, d3
    1ae0:	fmadd	d0, d2, d3, d0
    1ae4:	fmadd	d4, d2, d0, d4
    1ae8:	fmul	d4, d2, d4
    1aec:	fmul	d1, d1, d7
    1af0:	fmov	d3, #5.000000000000000000e-01
    1af4:	fnmsub	d1, d2, d4, d1
    1af8:	fmov	d0, #1.000000000000000000e+00
    1afc:	fnmsub	d1, d2, d3, d1
    1b00:	fsub	d0, d0, d1
    1b04:	fneg	d0, d0
    1b08:	b	16ac <pts_ieee754_cos+0x4c>
    1b0c:	fcvtzs	w0, d1
    1b10:	cbz	w0, 1a80 <pts_ieee754_cos+0x420>
    1b14:	adrp	x0, 0 <__kernel_tan>
    1b18:	fmul	d2, d1, d1
    1b1c:	ldr	d16, [x0]
    1b20:	adrp	x0, 0 <__kernel_tan>
    1b24:	ldr	d6, [x0]
    1b28:	adrp	x0, 0 <__kernel_tan>
    1b2c:	fmadd	d6, d2, d16, d6
    1b30:	ldr	d5, [x0]
    1b34:	adrp	x0, 0 <__kernel_tan>
    1b38:	ldr	d3, [x0]
    1b3c:	adrp	x0, 0 <__kernel_tan>
    1b40:	ldr	d0, [x0]
    1b44:	adrp	x0, 0 <__kernel_tan>
    1b48:	ldr	d4, [x0]
    1b4c:	fmadd	d5, d2, d6, d5
    1b50:	fmadd	d3, d2, d5, d3
    1b54:	fmadd	d0, d2, d3, d0
    1b58:	fmadd	d4, d2, d0, d4
    1b5c:	fmul	d4, d2, d4
    1b60:	fmul	d1, d1, d7
    1b64:	fmov	d3, #5.000000000000000000e-01
    1b68:	fnmsub	d1, d2, d4, d1
    1b6c:	fmov	d0, #1.000000000000000000e+00
    1b70:	fnmsub	d1, d2, d3, d1
    1b74:	fsub	d0, d0, d1
    1b78:	b	16ac <pts_ieee754_cos+0x4c>
    1b7c:	fmov	d0, #7.187500000000000000e-01
    1b80:	fmov	d3, #2.812500000000000000e-01
    1b84:	b	1954 <pts_ieee754_cos+0x2f4>
    1b88:	fmov	d0, #7.187500000000000000e-01
    1b8c:	fmov	d3, #2.812500000000000000e-01
    1b90:	b	1788 <pts_ieee754_cos+0x128>
    1b94:	bl	0 <__stack_chk_fail>
    1b98:	nop
    1b9c:	nop

0000000000001ba0 <pts_ieee754_exp>:
    1ba0:	fmov	x0, d0
    1ba4:	mov	w3, #0x2e41                	// #11841
    1ba8:	movk	w3, #0x4086, lsl #16
    1bac:	ubfx	x1, x0, #32, #31
    1bb0:	lsr	x2, x0, #32
    1bb4:	lsr	x4, x0, #63
    1bb8:	cmp	w1, w3
    1bbc:	b.ls	1be0 <pts_ieee754_exp+0x40>  // b.plast
    1bc0:	mov	w3, #0x7fefffff            	// #2146435071
    1bc4:	cmp	w1, w3
    1bc8:	b.ls	1c70 <pts_ieee754_exp+0xd0>  // b.plast
    1bcc:	and	w2, w2, #0xfffff
    1bd0:	orr	w2, w2, w0
    1bd4:	cbz	w2, 1e18 <pts_ieee754_exp+0x278>
    1bd8:	fadd	d0, d0, d0
    1bdc:	ret
    1be0:	mov	w0, #0x2e42                	// #11842
    1be4:	movk	w0, #0x3fd6, lsl #16
    1be8:	cmp	w1, w0
    1bec:	b.hi	1d98 <pts_ieee754_exp+0x1f8>  // b.pmore
    1bf0:	mov	w0, #0x3e2fffff            	// #1043333119
    1bf4:	cmp	w1, w0
    1bf8:	b.ls	1df8 <pts_ieee754_exp+0x258>  // b.plast
    1bfc:	movi	d3, #0x0
    1c00:	fmul	d1, d0, d0
    1c04:	fmov	d16, #1.000000000000000000e+00
    1c08:	mov	w0, #0x0                   	// #0
    1c0c:	fmov	d4, d3
    1c10:	adrp	x1, 0 <__kernel_tan>
    1c14:	ldr	d2, [x1]
    1c18:	adrp	x1, 0 <__kernel_tan>
    1c1c:	ldr	d7, [x1]
    1c20:	adrp	x1, 0 <__kernel_tan>
    1c24:	fmadd	d7, d1, d2, d7
    1c28:	ldr	d6, [x1]
    1c2c:	adrp	x1, 0 <__kernel_tan>
    1c30:	ldr	d5, [x1]
    1c34:	adrp	x1, 0 <__kernel_tan>
    1c38:	ldr	d2, [x1]
    1c3c:	fmadd	d6, d7, d1, d6
    1c40:	fmadd	d5, d6, d1, d5
    1c44:	fmadd	d2, d5, d1, d2
    1c48:	fmsub	d1, d2, d1, d0
    1c4c:	cbnz	w0, 1d68 <pts_ieee754_exp+0x1c8>
    1c50:	fmov	d4, #2.000000000000000000e+00
    1c54:	fmul	d2, d1, d0
    1c58:	fmov	d3, #1.000000000000000000e+00
    1c5c:	fsub	d1, d1, d4
    1c60:	fdiv	d1, d2, d1
    1c64:	fsub	d0, d1, d0
    1c68:	fsub	d0, d3, d0
    1c6c:	ret
    1c70:	adrp	x0, 0 <__kernel_tan>
    1c74:	ldr	d1, [x0]
    1c78:	fcmpe	d0, d1
    1c7c:	b.gt	1e28 <pts_ieee754_exp+0x288>
    1c80:	adrp	x0, 0 <__kernel_tan>
    1c84:	ldr	d1, [x0]
    1c88:	fcmpe	d0, d1
    1c8c:	b.mi	1e60 <pts_ieee754_exp+0x2c0>  // b.first
    1c90:	adrp	x1, 0 <__kernel_tan>
    1c94:	ubfiz	x4, x4, #3, #1
    1c98:	adrp	x0, 0 <__kernel_tan>
    1c9c:	add	x0, x0, #0x0
    1ca0:	add	x0, x0, x4
    1ca4:	ldr	d3, [x1]
    1ca8:	adrp	x1, 0 <__kernel_tan>
    1cac:	ldr	d1, [x0, #560]
    1cb0:	adrp	x0, 0 <__kernel_tan>
    1cb4:	fmadd	d1, d0, d3, d1
    1cb8:	ldr	d4, [x1]
    1cbc:	ldr	d2, [x0]
    1cc0:	adrp	x0, 0 <__kernel_tan>
    1cc4:	adrp	x1, 0 <__kernel_tan>
    1cc8:	ldr	d5, [x0]
    1ccc:	ldr	d17, [x1]
    1cd0:	adrp	x1, 0 <__kernel_tan>
    1cd4:	ldr	d16, [x1]
    1cd8:	adrp	x1, 0 <__kernel_tan>
    1cdc:	fcvtzs	w0, d1
    1ce0:	ldr	d7, [x1]
    1ce4:	adrp	x1, 0 <__kernel_tan>
    1ce8:	ldr	d6, [x1]
    1cec:	scvtf	d3, w0
    1cf0:	fmsub	d4, d3, d4, d0
    1cf4:	fmul	d3, d3, d17
    1cf8:	fsub	d0, d4, d3
    1cfc:	fmul	d1, d0, d0
    1d00:	fmadd	d7, d1, d16, d7
    1d04:	fmadd	d6, d1, d7, d6
    1d08:	fmadd	d2, d1, d6, d2
    1d0c:	fmadd	d5, d1, d2, d5
    1d10:	fmsub	d5, d1, d5, d0
    1d14:	cmn	w0, #0x3fd
    1d18:	b.ge	1e84 <pts_ieee754_exp+0x2e4>  // b.tcont
    1d1c:	fmov	d1, #2.000000000000000000e+00
    1d20:	fmul	d2, d0, d5
    1d24:	add	w0, w0, #0x3e8
    1d28:	mov	w1, #0x3ff00000            	// #1072693248
    1d2c:	fsub	d5, d1, d5
    1d30:	add	w0, w1, w0, lsl #20
    1d34:	fmov	d0, #1.000000000000000000e+00
    1d38:	fmov	d1, x0
    1d3c:	adrp	x1, 0 <__kernel_tan>
    1d40:	add	x1, x1, #0x0
    1d44:	fdiv	d2, d2, d5
    1d48:	shl	d1, d1, #32
    1d4c:	ldr	d5, [x1, #24]
    1d50:	fsub	d2, d3, d2
    1d54:	fsub	d2, d2, d4
    1d58:	fsub	d0, d0, d2
    1d5c:	fmul	d0, d0, d1
    1d60:	fmul	d0, d0, d5
    1d64:	ret
    1d68:	fmov	d5, #2.000000000000000000e+00
    1d6c:	fmul	d0, d1, d0
    1d70:	fmov	d2, #1.000000000000000000e+00
    1d74:	fsub	d1, d5, d1
    1d78:	fdiv	d0, d0, d1
    1d7c:	fsub	d0, d3, d0
    1d80:	fsub	d0, d0, d4
    1d84:	fsub	d0, d2, d0
    1d88:	cmp	w0, #0x400
    1d8c:	b.eq	1e40 <pts_ieee754_exp+0x2a0>  // b.none
    1d90:	fmul	d0, d0, d16
    1d94:	ret
    1d98:	mov	w0, #0xa2b1                	// #41649
    1d9c:	movk	w0, #0x3ff0, lsl #16
    1da0:	cmp	w1, w0
    1da4:	b.hi	1c90 <pts_ieee754_exp+0xf0>  // b.pmore
    1da8:	fmov	d1, #1.000000000000000000e+00
    1dac:	fcmp	d0, d1
    1db0:	b.eq	1e78 <pts_ieee754_exp+0x2d8>  // b.none
    1db4:	adrp	x1, 0 <__kernel_tan>
    1db8:	add	x1, x1, #0x0
    1dbc:	ubfiz	x0, x4, #3, #1
    1dc0:	add	x1, x1, #0x200
    1dc4:	add	x1, x1, x0
    1dc8:	eor	w0, w4, #0x1
    1dcc:	sub	w0, w0, w4
    1dd0:	mov	w2, #0x3ff00000            	// #1072693248
    1dd4:	ldr	d4, [x1, #16]
    1dd8:	add	w2, w2, w0, lsl #20
    1ddc:	ldr	d3, [x1, #32]
    1de0:	fmov	d1, x2
    1de4:	fsub	d4, d0, d4
    1de8:	shl	d16, d1, #32
    1dec:	fsub	d0, d4, d3
    1df0:	fmul	d1, d0, d0
    1df4:	b	1c10 <pts_ieee754_exp+0x70>
    1df8:	adrp	x0, 0 <__kernel_tan>
    1dfc:	add	x0, x0, #0x0
    1e00:	fmov	d2, #1.000000000000000000e+00
    1e04:	ldr	d1, [x0, #16]
    1e08:	fadd	d1, d1, d0
    1e0c:	fcmpe	d1, d2
    1e10:	b.gt	1e58 <pts_ieee754_exp+0x2b8>
    1e14:	b	1bfc <pts_ieee754_exp+0x5c>
    1e18:	movi	d1, #0x0
    1e1c:	cmp	w4, #0x0
    1e20:	fcsel	d0, d0, d1, eq	// eq = none
    1e24:	ret
    1e28:	adrp	x0, 0 <__kernel_tan>
    1e2c:	add	x0, x0, #0x0
    1e30:	ldr	d0, [x0, #16]
    1e34:	ldr	d1, [x0, #16]
    1e38:	fmul	d0, d0, d1
    1e3c:	ret
    1e40:	adrp	x0, 0 <__kernel_tan>
    1e44:	add	x0, x0, #0x0
    1e48:	fadd	d1, d0, d0
    1e4c:	ldr	d0, [x0, #32]
    1e50:	fmul	d0, d1, d0
    1e54:	ret
    1e58:	fadd	d0, d0, d2
    1e5c:	ret
    1e60:	adrp	x0, 0 <__kernel_tan>
    1e64:	add	x0, x0, #0x0
    1e68:	ldr	d0, [x0, #24]
    1e6c:	ldr	d1, [x0, #24]
    1e70:	fmul	d0, d0, d1
    1e74:	ret
    1e78:	adrp	x0, 0 <__kernel_tan>
    1e7c:	ldr	d0, [x0]
    1e80:	ret
    1e84:	mov	w1, #0x3ff00000            	// #1072693248
    1e88:	add	w1, w1, w0, lsl #20
    1e8c:	fmov	d2, x1
    1e90:	shl	d16, d2, #32
    1e94:	b	1c10 <pts_ieee754_exp+0x70>
    1e98:	nop
    1e9c:	nop

0000000000001ea0 <pts_ieee754_log>:
    1ea0:	fmov	x2, d0
    1ea4:	mov	w3, #0xfffff               	// #1048575
    1ea8:	lsr	x0, x2, #32
    1eac:	mov	w1, w0
    1eb0:	cmp	w0, w3
    1eb4:	b.gt	1f6c <pts_ieee754_log+0xcc>
    1eb8:	and	w1, w0, #0x7fffffff
    1ebc:	orr	w1, w1, w2
    1ec0:	cbz	w1, 2034 <pts_ieee754_log+0x194>
    1ec4:	tbnz	w0, #31, 20b8 <pts_ieee754_log+0x218>
    1ec8:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    1ecc:	fmov	d1, x0
    1ed0:	mov	w6, #0xffffffca            	// #-54
    1ed4:	fmul	d0, d0, d1
    1ed8:	fmov	x0, d0
    1edc:	lsr	x1, x0, #32
    1ee0:	mov	w0, #0x7fefffff            	// #2146435071
    1ee4:	cmp	w1, w0
    1ee8:	b.gt	1f7c <pts_ieee754_log+0xdc>
    1eec:	and	w4, w1, #0xfffff
    1ef0:	fmov	x0, d0
    1ef4:	add	w3, w4, #0x95, lsl #12
    1ef8:	asr	w1, w1, #20
    1efc:	add	w3, w3, #0xf64
    1f00:	sub	w1, w1, #0x3ff
    1f04:	and	w2, w3, #0x100000
    1f08:	add	w5, w4, #0x2
    1f0c:	eor	w2, w2, #0x3ff00000
    1f10:	and	x0, x0, #0xffffffff
    1f14:	orr	w2, w2, w4
    1f18:	fmov	d0, #1.000000000000000000e+00
    1f1c:	add	w1, w1, w6
    1f20:	and	w5, w5, #0xfffff
    1f24:	orr	x0, x0, x2, lsl #32
    1f28:	fmov	d1, x0
    1f2c:	add	w3, w1, w3, lsr #20
    1f30:	fsub	d0, d1, d0
    1f34:	cmp	w5, #0x2
    1f38:	b.gt	1f84 <pts_ieee754_log+0xe4>
    1f3c:	fcmp	d0, #0.0
    1f40:	b.ne	2040 <pts_ieee754_log+0x1a0>  // b.any
    1f44:	movi	d0, #0x0
    1f48:	cbz	w3, 1f68 <pts_ieee754_log+0xc8>
    1f4c:	adrp	x0, 0 <__kernel_tan>
    1f50:	scvtf	d1, w3
    1f54:	ldr	d0, [x0]
    1f58:	adrp	x0, 0 <__kernel_tan>
    1f5c:	ldr	d2, [x0]
    1f60:	fmul	d0, d1, d0
    1f64:	fmadd	d0, d1, d2, d0
    1f68:	ret
    1f6c:	mov	w6, #0x0                   	// #0
    1f70:	mov	w0, #0x7fefffff            	// #2146435071
    1f74:	cmp	w1, w0
    1f78:	b.le	1eec <pts_ieee754_log+0x4c>
    1f7c:	fadd	d0, d0, d0
    1f80:	ret
    1f84:	fmov	d2, #2.000000000000000000e+00
    1f88:	adrp	x0, 0 <__kernel_tan>
    1f8c:	sub	w1, w4, #0x61, lsl #12
    1f90:	scvtf	d19, w3
    1f94:	fadd	d2, d0, d2
    1f98:	ldr	d18, [x0]
    1f9c:	adrp	x0, 0 <__kernel_tan>
    1fa0:	sub	w1, w1, #0x47a
    1fa4:	ldr	d16, [x0]
    1fa8:	adrp	x0, 0 <__kernel_tan>
    1fac:	fdiv	d2, d0, d2
    1fb0:	ldr	d6, [x0]
    1fb4:	adrp	x0, 0 <__kernel_tan>
    1fb8:	ldr	d17, [x0]
    1fbc:	adrp	x0, 0 <__kernel_tan>
    1fc0:	ldr	d7, [x0]
    1fc4:	adrp	x0, 0 <__kernel_tan>
    1fc8:	ldr	d1, [x0]
    1fcc:	adrp	x0, 0 <__kernel_tan>
    1fd0:	ldr	d4, [x0]
    1fd4:	mov	w0, #0xb851                	// #47185
    1fd8:	movk	w0, #0x6, lsl #16
    1fdc:	sub	w0, w0, w4
    1fe0:	orr	w0, w0, w1
    1fe4:	fmul	d5, d2, d2
    1fe8:	fmul	d3, d5, d5
    1fec:	fmadd	d16, d3, d18, d16
    1ff0:	fmadd	d7, d3, d17, d7
    1ff4:	fmadd	d6, d16, d3, d6
    1ff8:	fmadd	d4, d7, d3, d4
    1ffc:	fmadd	d1, d6, d3, d1
    2000:	fmul	d1, d1, d5
    2004:	fmadd	d1, d4, d3, d1
    2008:	cmp	w0, #0x0
    200c:	b.le	2084 <pts_ieee754_log+0x1e4>
    2010:	fmov	d3, #5.000000000000000000e-01
    2014:	fmul	d3, d0, d3
    2018:	fmul	d3, d3, d0
    201c:	fadd	d1, d1, d3
    2020:	fmul	d1, d1, d2
    2024:	cbnz	w3, 20c4 <pts_ieee754_log+0x224>
    2028:	fsub	d3, d3, d1
    202c:	fsub	d0, d0, d3
    2030:	ret
    2034:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2038:	fmov	d0, x0
    203c:	ret
    2040:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    2044:	fmov	d2, #5.000000000000000000e-01
    2048:	movk	x0, #0x3fd5, lsl #48
    204c:	fmov	d3, x0
    2050:	fmul	d1, d0, d0
    2054:	fmsub	d2, d0, d3, d2
    2058:	fmul	d1, d1, d2
    205c:	cbz	w3, 20b0 <pts_ieee754_log+0x210>
    2060:	adrp	x0, 0 <__kernel_tan>
    2064:	scvtf	d2, w3
    2068:	ldr	d4, [x0]
    206c:	adrp	x0, 0 <__kernel_tan>
    2070:	ldr	d3, [x0]
    2074:	fmsub	d1, d2, d4, d1
    2078:	fsub	d1, d1, d0
    207c:	fnmsub	d0, d2, d3, d1
    2080:	ret
    2084:	fsub	d1, d0, d1
    2088:	fmul	d1, d1, d2
    208c:	cbz	w3, 20b0 <pts_ieee754_log+0x210>
    2090:	adrp	x0, 0 <__kernel_tan>
    2094:	ldr	d3, [x0]
    2098:	adrp	x0, 0 <__kernel_tan>
    209c:	ldr	d2, [x0]
    20a0:	fmsub	d1, d19, d3, d1
    20a4:	fsub	d1, d1, d0
    20a8:	fnmsub	d0, d19, d2, d1
    20ac:	ret
    20b0:	fsub	d0, d0, d1
    20b4:	ret
    20b8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    20bc:	fmov	d0, x0
    20c0:	ret
    20c4:	adrp	x0, 0 <__kernel_tan>
    20c8:	ldr	d4, [x0]
    20cc:	adrp	x0, 0 <__kernel_tan>
    20d0:	ldr	d2, [x0]
    20d4:	fmadd	d1, d19, d4, d1
    20d8:	fsub	d3, d3, d1
    20dc:	fsub	d3, d3, d0
    20e0:	fnmsub	d0, d19, d2, d3
    20e4:	ret
    20e8:	nop
    20ec:	nop

00000000000020f0 <pts_ieee754_log1p>:
    20f0:	fmov	x1, d0
    20f4:	mov	w3, #0x8279                	// #33401
    20f8:	fmov	d1, d0
    20fc:	movk	w3, #0x3fda, lsl #16
    2100:	lsr	x0, x1, #32
    2104:	mov	w2, w0
    2108:	cmp	w0, w3
    210c:	b.gt	2140 <pts_ieee754_log1p+0x50>
    2110:	and	w1, w0, #0x7fffffff
    2114:	mov	w2, #0x3fefffff            	// #1072693247
    2118:	cmp	w1, w2
    211c:	b.le	21d0 <pts_ieee754_log1p+0xe0>
    2120:	fmov	d2, #-1.000000000000000000e+00
    2124:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2128:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    212c:	fmov	d0, x0
    2130:	fcmp	d1, d2
    2134:	fmov	d1, x1
    2138:	fcsel	d0, d0, d1, ne	// ne = any
    213c:	ret
    2140:	mov	w3, #0x7fefffff            	// #2146435071
    2144:	cmp	w0, w3
    2148:	b.gt	2278 <pts_ieee754_log1p+0x188>
    214c:	mov	w3, #0x433fffff            	// #1128267775
    2150:	cmp	w0, w3
    2154:	b.le	22cc <pts_ieee754_log1p+0x1dc>
    2158:	asr	w0, w0, #20
    215c:	movi	d5, #0x0
    2160:	sub	w0, w0, #0x3ff
    2164:	mov	w3, #0xa09d                	// #41117
    2168:	and	w2, w2, #0xfffff
    216c:	and	x1, x1, #0xffffffff
    2170:	movk	w3, #0x6, lsl #16
    2174:	cmp	w2, w3
    2178:	b.gt	22ac <pts_ieee754_log1p+0x1bc>
    217c:	orr	w3, w2, #0x3ff00000
    2180:	orr	x1, x1, x3, lsl #32
    2184:	fmov	d1, x1
    2188:	fmov	d2, #1.000000000000000000e+00
    218c:	fmov	d0, #5.000000000000000000e-01
    2190:	fsub	d1, d1, d2
    2194:	fmul	d0, d1, d0
    2198:	fmul	d0, d0, d1
    219c:	cbnz	w2, 2200 <pts_ieee754_log1p+0x110>
    21a0:	fcmp	d1, #0.0
    21a4:	b.ne	2300 <pts_ieee754_log1p+0x210>  // b.any
    21a8:	movi	d0, #0x0
    21ac:	cbz	w0, 213c <pts_ieee754_log1p+0x4c>
    21b0:	scvtf	d1, w0
    21b4:	adrp	x0, 0 <__kernel_tan>
    21b8:	ldr	d0, [x0]
    21bc:	adrp	x0, 0 <__kernel_tan>
    21c0:	ldr	d2, [x0]
    21c4:	fmadd	d0, d1, d0, d5
    21c8:	fmadd	d0, d1, d2, d0
    21cc:	ret
    21d0:	mov	w2, #0x3e1fffff            	// #1042284543
    21d4:	cmp	w1, w2
    21d8:	b.le	2280 <pts_ieee754_log1p+0x190>
    21dc:	mov	w1, #0x413b                	// #16699
    21e0:	movk	w1, #0x402d, lsl #16
    21e4:	add	w0, w0, w1
    21e8:	cmp	w0, w1
    21ec:	b.ls	22cc <pts_ieee754_log1p+0x1dc>  // b.plast
    21f0:	fmov	d0, #5.000000000000000000e-01
    21f4:	mov	w0, #0x0                   	// #0
    21f8:	fmul	d0, d1, d0
    21fc:	fmul	d0, d0, d1
    2200:	fmov	d2, #2.000000000000000000e+00
    2204:	adrp	x1, 0 <__kernel_tan>
    2208:	fadd	d2, d1, d2
    220c:	ldr	d19, [x1]
    2210:	adrp	x1, 0 <__kernel_tan>
    2214:	ldr	d18, [x1]
    2218:	adrp	x1, 0 <__kernel_tan>
    221c:	fdiv	d2, d1, d2
    2220:	ldr	d17, [x1]
    2224:	adrp	x1, 0 <__kernel_tan>
    2228:	ldr	d16, [x1]
    222c:	adrp	x1, 0 <__kernel_tan>
    2230:	ldr	d7, [x1]
    2234:	adrp	x1, 0 <__kernel_tan>
    2238:	ldr	d6, [x1]
    223c:	adrp	x1, 0 <__kernel_tan>
    2240:	ldr	d4, [x1]
    2244:	fmul	d3, d2, d2
    2248:	fmadd	d18, d3, d19, d18
    224c:	fmadd	d17, d18, d3, d17
    2250:	fmadd	d16, d17, d3, d16
    2254:	fmadd	d7, d16, d3, d7
    2258:	fmadd	d6, d7, d3, d6
    225c:	fmadd	d4, d6, d3, d4
    2260:	fmadd	d3, d4, d3, d0
    2264:	fmul	d2, d2, d3
    2268:	cbnz	w0, 2320 <pts_ieee754_log1p+0x230>
    226c:	fsub	d0, d0, d2
    2270:	fsub	d0, d1, d0
    2274:	ret
    2278:	fadd	d0, d0, d0
    227c:	ret
    2280:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2284:	fmov	d2, x0
    2288:	mov	w0, #0x3c8fffff            	// #1016070143
    228c:	fadd	d1, d0, d2
    2290:	fcmpe	d1, #0.0
    2294:	ccmp	w1, w0, #0x0, gt
    2298:	b.le	213c <pts_ieee754_log1p+0x4c>
    229c:	fmul	d2, d0, d0
    22a0:	fmov	d1, #5.000000000000000000e-01
    22a4:	fmsub	d0, d2, d1, d0
    22a8:	ret
    22ac:	orr	w3, w2, #0x3fe00000
    22b0:	mov	w4, #0x100000              	// #1048576
    22b4:	sub	w2, w4, w2
    22b8:	add	w0, w0, #0x1
    22bc:	orr	x1, x1, x3, lsl #32
    22c0:	fmov	d1, x1
    22c4:	asr	w2, w2, #2
    22c8:	b	2188 <pts_ieee754_log1p+0x98>
    22cc:	fmov	d5, #1.000000000000000000e+00
    22d0:	fadd	d0, d1, d5
    22d4:	fmov	x1, d0
    22d8:	lsr	x0, x1, #32
    22dc:	mov	w2, w0
    22e0:	asr	w0, w0, #20
    22e4:	sub	w0, w0, #0x3ff
    22e8:	cmp	w0, #0x0
    22ec:	b.le	2374 <pts_ieee754_log1p+0x284>
    22f0:	fsub	d1, d0, d1
    22f4:	fsub	d5, d5, d1
    22f8:	fdiv	d5, d5, d0
    22fc:	b	2164 <pts_ieee754_log1p+0x74>
    2300:	mov	x1, #0x5555555555555555    	// #6148914691236517205
    2304:	movk	x1, #0x3fe5, lsl #48
    2308:	fmov	d3, x1
    230c:	fmsub	d2, d1, d3, d2
    2310:	fmul	d2, d2, d0
    2314:	cbnz	w0, 234c <pts_ieee754_log1p+0x25c>
    2318:	fsub	d0, d1, d2
    231c:	ret
    2320:	scvtf	d4, w0
    2324:	adrp	x0, 0 <__kernel_tan>
    2328:	ldr	d3, [x0]
    232c:	adrp	x0, 0 <__kernel_tan>
    2330:	ldr	d6, [x0]
    2334:	fmadd	d3, d4, d3, d5
    2338:	fadd	d2, d3, d2
    233c:	fsub	d0, d0, d2
    2340:	fsub	d0, d0, d1
    2344:	fnmsub	d0, d4, d6, d0
    2348:	ret
    234c:	scvtf	d0, w0
    2350:	adrp	x0, 0 <__kernel_tan>
    2354:	ldr	d3, [x0]
    2358:	adrp	x0, 0 <__kernel_tan>
    235c:	ldr	d4, [x0]
    2360:	fmadd	d3, d0, d3, d5
    2364:	fsub	d2, d2, d3
    2368:	fsub	d2, d2, d1
    236c:	fnmsub	d0, d0, d4, d2
    2370:	ret
    2374:	fsub	d5, d0, d5
    2378:	fsub	d5, d1, d5
    237c:	fdiv	d5, d5, d0
    2380:	b	2164 <pts_ieee754_log1p+0x74>

0000000000002384 <pts_ieee754_acosh>:
    2384:	fmov	x2, d0
    2388:	mov	w1, #0x3fefffff            	// #1072693247
    238c:	lsr	x0, x2, #32
    2390:	cmp	w0, w1
    2394:	b.le	2418 <pts_ieee754_acosh+0x94>
    2398:	stp	x29, x30, [sp, #-32]!
    239c:	mov	w3, #0x41afffff            	// #1102053375
    23a0:	mov	x29, sp
    23a4:	stp	d8, d9, [sp, #16]
    23a8:	fmov	d8, d0
    23ac:	cmp	w0, w3
    23b0:	b.gt	23f0 <pts_ieee754_acosh+0x6c>
    23b4:	mov	w3, #0xc0100000            	// #-1072693248
    23b8:	add	w3, w3, w0
    23bc:	orr	w2, w3, w2
    23c0:	cbz	w2, 248c <pts_ieee754_acosh+0x108>
    23c4:	add	w1, w1, #0x100, lsl #12
    23c8:	add	w1, w1, #0x1
    23cc:	cmp	w0, w1
    23d0:	b.le	2434 <pts_ieee754_acosh+0xb0>
    23d4:	fmov	d0, #-1.000000000000000000e+00
    23d8:	fadd	d9, d8, d8
    23dc:	fmadd	d0, d8, d8, d0
    23e0:	fcmp	d0, #0.0
    23e4:	b.pl	2458 <pts_ieee754_acosh+0xd4>  // b.nfrst
    23e8:	bl	0 <sqrt>
    23ec:	b	245c <pts_ieee754_acosh+0xd8>
    23f0:	mov	w1, #0x7fefffff            	// #2146435071
    23f4:	cmp	w0, w1
    23f8:	b.gt	2424 <pts_ieee754_acosh+0xa0>
    23fc:	bl	1ea0 <pts_ieee754_log>
    2400:	adrp	x0, 0 <__kernel_tan>
    2404:	ldp	d8, d9, [sp, #16]
    2408:	ldr	d1, [x0]
    240c:	ldp	x29, x30, [sp], #32
    2410:	fadd	d0, d0, d1
    2414:	ret
    2418:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    241c:	fmov	d0, x0
    2420:	ret
    2424:	ldp	d8, d9, [sp, #16]
    2428:	fadd	d0, d0, d0
    242c:	ldp	x29, x30, [sp], #32
    2430:	ret
    2434:	fmov	d0, #1.000000000000000000e+00
    2438:	fmov	d1, #2.000000000000000000e+00
    243c:	fsub	d8, d8, d0
    2440:	fmul	d0, d8, d8
    2444:	fmadd	d0, d8, d1, d0
    2448:	fcmp	d0, #0.0
    244c:	b.pl	2478 <pts_ieee754_acosh+0xf4>  // b.nfrst
    2450:	bl	0 <sqrt>
    2454:	b	247c <pts_ieee754_acosh+0xf8>
    2458:	fsqrt	d0, d0
    245c:	fadd	d8, d8, d0
    2460:	fmov	d0, #1.000000000000000000e+00
    2464:	fdiv	d0, d0, d8
    2468:	fsub	d0, d9, d0
    246c:	ldp	d8, d9, [sp, #16]
    2470:	ldp	x29, x30, [sp], #32
    2474:	b	1ea0 <pts_ieee754_log>
    2478:	fsqrt	d0, d0
    247c:	fadd	d0, d8, d0
    2480:	ldp	d8, d9, [sp, #16]
    2484:	ldp	x29, x30, [sp], #32
    2488:	b	20f0 <pts_ieee754_log1p>
    248c:	ldp	d8, d9, [sp, #16]
    2490:	movi	d0, #0x0
    2494:	ldp	x29, x30, [sp], #32
    2498:	ret
    249c:	nop

00000000000024a0 <pts_ieee754_asinh>:
    24a0:	fmov	x0, d0
    24a4:	fmov	d1, d0
    24a8:	mov	w1, #0x7fefffff            	// #2146435071
    24ac:	lsr	x7, x0, #32
    24b0:	and	w0, w7, #0x7fffffff
    24b4:	cmp	w0, w1
    24b8:	b.gt	2544 <pts_ieee754_asinh+0xa4>
    24bc:	stp	x29, x30, [sp, #-16]!
    24c0:	mov	w1, #0x3e2fffff            	// #1043333119
    24c4:	mov	x29, sp
    24c8:	cmp	w0, w1
    24cc:	b.le	2504 <pts_ieee754_asinh+0x64>
    24d0:	fabs	d0, d0
    24d4:	mov	w1, #0x41b00000            	// #1102053376
    24d8:	cmp	w0, w1
    24dc:	b.le	254c <pts_ieee754_asinh+0xac>
    24e0:	bl	1ea0 <pts_ieee754_log>
    24e4:	adrp	x0, 0 <__kernel_tan>
    24e8:	ldr	d1, [x0]
    24ec:	fadd	d0, d0, d1
    24f0:	fneg	d1, d0
    24f4:	cmp	w7, #0x0
    24f8:	fcsel	d0, d1, d0, le
    24fc:	ldp	x29, x30, [sp], #16
    2500:	ret
    2504:	adrp	x0, 0 <__kernel_tan>
    2508:	fmov	d2, #1.000000000000000000e+00
    250c:	ldr	d3, [x0]
    2510:	fadd	d3, d0, d3
    2514:	fcmpe	d3, d2
    2518:	b.gt	24fc <pts_ieee754_asinh+0x5c>
    251c:	fmul	d3, d0, d0
    2520:	fabs	d0, d0
    2524:	fadd	d2, d3, d2
    2528:	fsqrt	d2, d2
    252c:	fmov	d1, #1.000000000000000000e+00
    2530:	fadd	d2, d2, d1
    2534:	fdiv	d3, d3, d2
    2538:	fadd	d0, d3, d0
    253c:	bl	20f0 <pts_ieee754_log1p>
    2540:	b	24f0 <pts_ieee754_asinh+0x50>
    2544:	fadd	d0, d0, d0
    2548:	ret
    254c:	fmul	d3, d1, d1
    2550:	fmov	d1, #1.000000000000000000e+00
    2554:	mov	w1, #0x40000000            	// #1073741824
    2558:	fadd	d2, d3, d1
    255c:	fsqrt	d2, d2
    2560:	cmp	w0, w1
    2564:	b.le	252c <pts_ieee754_asinh+0x8c>
    2568:	fadd	d2, d0, d2
    256c:	fmov	d3, #2.000000000000000000e+00
    2570:	fdiv	d1, d1, d2
    2574:	fmadd	d0, d0, d3, d1
    2578:	bl	1ea0 <pts_ieee754_log>
    257c:	b	24f0 <pts_ieee754_asinh+0x50>

0000000000002580 <pts_ieee754_atanh>:
    2580:	fmov	x0, d0
    2584:	mov	w3, #0x3ff00000            	// #1072693248
    2588:	neg	w1, w0
    258c:	ubfx	x2, x0, #32, #31
    2590:	orr	w1, w1, w0
    2594:	orr	w1, w2, w1, lsr #31
    2598:	cmp	w1, w3
    259c:	b.hi	2648 <pts_ieee754_atanh+0xc8>  // b.pmore
    25a0:	cmp	w2, w3
    25a4:	b.eq	2654 <pts_ieee754_atanh+0xd4>  // b.none
    25a8:	stp	x29, x30, [sp, #-16]!
    25ac:	lsr	x5, x0, #32
    25b0:	mov	w1, #0x3e2fffff            	// #1043333119
    25b4:	mov	x29, sp
    25b8:	cmp	w2, w1
    25bc:	b.le	2604 <pts_ieee754_atanh+0x84>
    25c0:	bfi	x0, x2, #32, #32
    25c4:	fmov	d0, #1.000000000000000000e+00
    25c8:	fmov	d1, x0
    25cc:	mov	w0, #0x3fdfffff            	// #1071644671
    25d0:	fadd	d2, d1, d1
    25d4:	fsub	d0, d0, d1
    25d8:	cmp	w2, w0
    25dc:	b.le	2624 <pts_ieee754_atanh+0xa4>
    25e0:	fdiv	d0, d2, d0
    25e4:	bl	20f0 <pts_ieee754_log1p>
    25e8:	fmov	d1, #5.000000000000000000e-01
    25ec:	fmul	d0, d0, d1
    25f0:	fneg	d1, d0
    25f4:	cmp	w5, #0x0
    25f8:	fcsel	d0, d1, d0, lt	// lt = tstop
    25fc:	ldp	x29, x30, [sp], #16
    2600:	ret
    2604:	adrp	x1, 0 <__kernel_tan>
    2608:	ldr	d2, [x1]
    260c:	fadd	d1, d0, d2
    2610:	fcmpe	d1, #0.0
    2614:	b.gt	25fc <pts_ieee754_atanh+0x7c>
    2618:	bfi	x0, x2, #32, #32
    261c:	fmov	d1, x0
    2620:	fadd	d2, d1, d1
    2624:	fmov	d3, #1.000000000000000000e+00
    2628:	fmul	d0, d2, d1
    262c:	fsub	d1, d3, d1
    2630:	fdiv	d0, d0, d1
    2634:	fadd	d0, d0, d2
    2638:	bl	20f0 <pts_ieee754_log1p>
    263c:	fmov	d1, #5.000000000000000000e-01
    2640:	fmul	d0, d0, d1
    2644:	b	25f0 <pts_ieee754_atanh+0x70>
    2648:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    264c:	fmov	d0, x0
    2650:	ret
    2654:	fcmpe	d0, #0.0
    2658:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
    265c:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    2660:	fmov	d0, x0
    2664:	fmov	d1, x1
    2668:	fcsel	d0, d0, d1, gt
    266c:	ret

0000000000002670 <pts_ieee754_log2>:
    2670:	fmov	x1, d0
    2674:	fmov	d1, d0
    2678:	mov	w3, #0xfffff               	// #1048575
    267c:	lsr	x0, x1, #32
    2680:	mov	w2, w0
    2684:	cmp	w0, w3
    2688:	b.gt	27d8 <pts_ieee754_log2+0x168>
    268c:	and	w2, w0, #0x7fffffff
    2690:	orr	w2, w2, w1
    2694:	cbz	w2, 27f0 <pts_ieee754_log2+0x180>
    2698:	tbnz	w0, #31, 27fc <pts_ieee754_log2+0x18c>
    269c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    26a0:	fmov	d0, x0
    26a4:	mov	w4, #0xffffffca            	// #-54
    26a8:	fmul	d1, d1, d0
    26ac:	fmov	x0, d1
    26b0:	lsr	x2, x0, #32
    26b4:	mov	w0, #0x7fefffff            	// #2146435071
    26b8:	cmp	w2, w0
    26bc:	b.gt	27e8 <pts_ieee754_log2+0x178>
    26c0:	cmp	w1, #0x0
    26c4:	mov	w0, #0x3ff00000            	// #1072693248
    26c8:	movi	d0, #0x0
    26cc:	ccmp	w2, w0, #0x0, eq	// eq = none
    26d0:	b.eq	27d4 <pts_ieee754_log2+0x164>  // b.none
    26d4:	and	w5, w2, #0xfffff
    26d8:	fmov	x0, d1
    26dc:	add	w3, w5, #0x95, lsl #12
    26e0:	fmov	d0, #1.000000000000000000e+00
    26e4:	add	w3, w3, #0xf64
    26e8:	fmov	d5, #2.000000000000000000e+00
    26ec:	and	w1, w3, #0x100000
    26f0:	adrp	x6, 0 <__kernel_tan>
    26f4:	eor	w1, w1, #0x3ff00000
    26f8:	and	x0, x0, #0xffffffff
    26fc:	orr	w1, w1, w5
    2700:	ldr	d25, [x6]
    2704:	adrp	x5, 0 <__kernel_tan>
    2708:	fmov	d7, #5.000000000000000000e-01
    270c:	orr	x0, x0, x1, lsl #32
    2710:	fmov	d1, x0
    2714:	ldr	d21, [x5]
    2718:	adrp	x5, 0 <__kernel_tan>
    271c:	fsub	d1, d1, d0
    2720:	adrp	x1, 0 <__kernel_tan>
    2724:	ldr	d19, [x5]
    2728:	adrp	x5, 0 <__kernel_tan>
    272c:	ldr	d20, [x1]
    2730:	adrp	x1, 0 <__kernel_tan>
    2734:	ldr	d24, [x5]
    2738:	movi	v2.2d, #0xffffffff00000000
    273c:	fadd	d5, d1, d5
    2740:	ldr	d18, [x1]
    2744:	adrp	x1, 0 <__kernel_tan>
    2748:	fmul	d7, d1, d7
    274c:	asr	w2, w2, #20
    2750:	adrp	x0, 0 <__kernel_tan>
    2754:	ldr	d17, [x1]
    2758:	sub	w2, w2, #0x3ff
    275c:	fdiv	d5, d1, d5
    2760:	add	w2, w2, w4
    2764:	fmsub	d4, d7, d1, d1
    2768:	ldr	d16, [x0]
    276c:	add	w3, w2, w3, lsr #20
    2770:	adrp	x0, 0 <__kernel_tan>
    2774:	scvtf	d0, w3
    2778:	ldr	d22, [x0]
    277c:	and	v4.8b, v4.8b, v2.8b
    2780:	fsub	d2, d1, d4
    2784:	fmadd	d23, d4, d16, d0
    2788:	fmsub	d2, d7, d1, d2
    278c:	fsub	d0, d0, d23
    2790:	fmadd	d0, d4, d16, d0
    2794:	fmul	d3, d5, d5
    2798:	fmul	d6, d3, d3
    279c:	fmadd	d21, d6, d25, d21
    27a0:	fmadd	d20, d6, d24, d20
    27a4:	fmadd	d19, d6, d21, d19
    27a8:	fmadd	d17, d6, d20, d17
    27ac:	fmadd	d18, d6, d19, d18
    27b0:	fmul	d3, d3, d18
    27b4:	fmadd	d3, d6, d17, d3
    27b8:	fmadd	d3, d7, d1, d3
    27bc:	fmadd	d1, d5, d3, d2
    27c0:	fadd	d4, d4, d1
    27c4:	fmul	d1, d1, d16
    27c8:	fmadd	d1, d4, d22, d1
    27cc:	fadd	d0, d0, d1
    27d0:	fadd	d0, d0, d23
    27d4:	ret
    27d8:	mov	w4, #0x0                   	// #0
    27dc:	mov	w0, #0x7fefffff            	// #2146435071
    27e0:	cmp	w2, w0
    27e4:	b.le	26c0 <pts_ieee754_log2+0x50>
    27e8:	fadd	d0, d1, d1
    27ec:	ret
    27f0:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    27f4:	fmov	d0, x0
    27f8:	ret
    27fc:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2800:	fmov	d0, x0
    2804:	ret
    2808:	nop
    280c:	nop

0000000000002810 <pts_ieee754_log10>:
    2810:	fmov	x2, d0
    2814:	mov	w4, #0xfffff               	// #1048575
    2818:	lsr	x1, x2, #32
    281c:	cmp	w1, w4
    2820:	b.gt	28d4 <pts_ieee754_log10+0xc4>
    2824:	and	w0, w1, #0x7fffffff
    2828:	orr	w0, w0, w2
    282c:	cbz	w0, 28f8 <pts_ieee754_log10+0xe8>
    2830:	tbnz	w1, #31, 2904 <pts_ieee754_log10+0xf4>
    2834:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2838:	fmov	d1, x0
    283c:	mov	w4, #0xffffffca            	// #-54
    2840:	mov	w1, #0x7fefffff            	// #2146435071
    2844:	fmul	d0, d0, d1
    2848:	fmov	x0, d0
    284c:	mov	w3, w0
    2850:	lsr	x0, x0, #32
    2854:	cmp	w0, w1
    2858:	b.gt	28ec <pts_ieee754_log10+0xdc>
    285c:	cmp	w3, #0x0
    2860:	mov	w1, #0x3ff00000            	// #1072693248
    2864:	movi	d0, #0x0
    2868:	ccmp	w0, w1, #0x0, eq	// eq = none
    286c:	b.eq	28f4 <pts_ieee754_log10+0xe4>  // b.none
    2870:	asr	w1, w0, #20
    2874:	mov	w2, #0x3ff                 	// #1023
    2878:	sub	w1, w1, #0x3ff
    287c:	stp	x29, x30, [sp, #-16]!
    2880:	add	w1, w1, w4
    2884:	mov	x29, sp
    2888:	lsr	w4, w1, #31
    288c:	sub	w2, w2, w4
    2890:	add	w1, w1, w4
    2894:	bfi	w0, w2, #20, #12
    2898:	scvtf	d20, w1
    289c:	orr	x0, x3, x0, lsl #32
    28a0:	fmov	d0, x0
    28a4:	bl	1ea0 <pts_ieee754_log>
    28a8:	adrp	x0, 0 <__kernel_tan>
    28ac:	ldp	x29, x30, [sp], #16
    28b0:	ldr	d3, [x0]
    28b4:	adrp	x0, 0 <__kernel_tan>
    28b8:	ldr	d2, [x0]
    28bc:	adrp	x0, 0 <__kernel_tan>
    28c0:	fmul	d0, d0, d3
    28c4:	ldr	d1, [x0]
    28c8:	fmadd	d0, d20, d2, d0
    28cc:	fmadd	d0, d20, d1, d0
    28d0:	ret
    28d4:	mov	w0, w1
    28d8:	mov	w3, w2
    28dc:	mov	w4, #0x0                   	// #0
    28e0:	mov	w1, #0x7fefffff            	// #2146435071
    28e4:	cmp	w0, w1
    28e8:	b.le	285c <pts_ieee754_log10+0x4c>
    28ec:	fadd	d0, d0, d0
    28f0:	ret
    28f4:	ret
    28f8:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    28fc:	fmov	d0, x0
    2900:	ret
    2904:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2908:	fmov	d0, x0
    290c:	ret

0000000000002910 <pts_ieee754_expm1>:
    2910:	fmov	x1, d0
    2914:	mov	w2, #0x6879                	// #26745
    2918:	fmov	d2, d0
    291c:	movk	w2, #0x4043, lsl #16
    2920:	ubfx	x0, x1, #32, #31
    2924:	lsr	x3, x1, #32
    2928:	cmp	w0, w2
    292c:	b.ls	29b8 <pts_ieee754_expm1+0xa8>  // b.plast
    2930:	mov	w2, #0x2e41                	// #11841
    2934:	movk	w2, #0x4086, lsl #16
    2938:	cmp	w0, w2
    293c:	b.ls	2970 <pts_ieee754_expm1+0x60>  // b.plast
    2940:	mov	w2, #0x7fefffff            	// #2146435071
    2944:	cmp	w0, w2
    2948:	b.ls	2960 <pts_ieee754_expm1+0x50>  // b.plast
    294c:	and	w0, w3, #0xfffff
    2950:	orr	w0, w0, w1
    2954:	cbz	w0, 2bdc <pts_ieee754_expm1+0x2cc>
    2958:	fadd	d0, d0, d0
    295c:	ret
    2960:	adrp	x0, 0 <__kernel_tan>
    2964:	ldr	d0, [x0]
    2968:	fcmpe	d2, d0
    296c:	b.gt	2c00 <pts_ieee754_expm1+0x2f0>
    2970:	tbnz	w3, #31, 2ab4 <pts_ieee754_expm1+0x1a4>
    2974:	adrp	x0, 0 <__kernel_tan>
    2978:	fmov	d0, #5.000000000000000000e-01
    297c:	ldr	d1, [x0]
    2980:	fmul	d1, d2, d1
    2984:	fadd	d0, d0, d1
    2988:	adrp	x0, 0 <__kernel_tan>
    298c:	ldr	d3, [x0]
    2990:	adrp	x0, 0 <__kernel_tan>
    2994:	fcvtzs	w1, d0
    2998:	ldr	d1, [x0]
    299c:	scvtf	d0, w1
    29a0:	fmsub	d3, d0, d3, d2
    29a4:	fmul	d0, d0, d1
    29a8:	fsub	d2, d3, d0
    29ac:	fsub	d3, d3, d2
    29b0:	fsub	d3, d3, d0
    29b4:	b	29d8 <pts_ieee754_expm1+0xc8>
    29b8:	mov	w1, #0x2e42                	// #11842
    29bc:	movk	w1, #0x3fd6, lsl #16
    29c0:	cmp	w0, w1
    29c4:	b.hi	2b00 <pts_ieee754_expm1+0x1f0>  // b.pmore
    29c8:	mov	w2, #0x3c8fffff            	// #1016070143
    29cc:	mov	w1, #0x0                   	// #0
    29d0:	cmp	w0, w2
    29d4:	b.ls	2b30 <pts_ieee754_expm1+0x220>  // b.plast
    29d8:	fmov	d18, #5.000000000000000000e-01
    29dc:	adrp	x0, 0 <__kernel_tan>
    29e0:	fmov	d19, #1.000000000000000000e+00
    29e4:	fmov	d4, #3.000000000000000000e+00
    29e8:	fmul	d17, d2, d18
    29ec:	ldr	d20, [x0]
    29f0:	adrp	x0, 0 <__kernel_tan>
    29f4:	fmov	d5, #6.000000000000000000e+00
    29f8:	ldr	d16, [x0]
    29fc:	adrp	x0, 0 <__kernel_tan>
    2a00:	fmul	d1, d2, d17
    2a04:	ldr	d7, [x0]
    2a08:	adrp	x0, 0 <__kernel_tan>
    2a0c:	ldr	d6, [x0]
    2a10:	adrp	x0, 0 <__kernel_tan>
    2a14:	fmadd	d16, d1, d20, d16
    2a18:	ldr	d0, [x0]
    2a1c:	fmadd	d7, d16, d1, d7
    2a20:	fmadd	d6, d7, d1, d6
    2a24:	fmadd	d0, d6, d1, d0
    2a28:	fmadd	d0, d0, d1, d19
    2a2c:	fmsub	d4, d17, d0, d4
    2a30:	fmsub	d5, d2, d4, d5
    2a34:	fsub	d0, d0, d4
    2a38:	fdiv	d0, d0, d5
    2a3c:	fmul	d0, d0, d1
    2a40:	cbz	w1, 2aa8 <pts_ieee754_expm1+0x198>
    2a44:	fsub	d0, d0, d3
    2a48:	fnmsub	d3, d0, d2, d3
    2a4c:	fsub	d3, d3, d1
    2a50:	cmn	w1, #0x1
    2a54:	b.eq	2b84 <pts_ieee754_expm1+0x274>  // b.none
    2a58:	cmp	w1, #0x1
    2a5c:	b.eq	2b68 <pts_ieee754_expm1+0x258>  // b.none
    2a60:	mov	w2, #0x3ff00000            	// #1072693248
    2a64:	add	w3, w1, #0x1
    2a68:	add	w0, w2, w1, lsl #20
    2a6c:	fmov	d0, x0
    2a70:	shl	d1, d0, #32
    2a74:	cmp	w3, #0x39
    2a78:	b.hi	2ae0 <pts_ieee754_expm1+0x1d0>  // b.pmore
    2a7c:	cmp	w1, #0x13
    2a80:	b.gt	2b94 <pts_ieee754_expm1+0x284>
    2a84:	mov	w0, #0x200000              	// #2097152
    2a88:	fsub	d3, d3, d2
    2a8c:	asr	w0, w0, w1
    2a90:	sub	w2, w2, w0
    2a94:	fmov	d0, x2
    2a98:	shl	d0, d0, #32
    2a9c:	fsub	d0, d0, d3
    2aa0:	fmul	d0, d1, d0
    2aa4:	ret
    2aa8:	fnmsub	d1, d2, d0, d1
    2aac:	fsub	d0, d2, d1
    2ab0:	ret
    2ab4:	adrp	x0, 0 <__kernel_tan>
    2ab8:	fmov	d0, #-1.000000000000000000e+00
    2abc:	ldr	d1, [x0]
    2ac0:	fadd	d1, d2, d1
    2ac4:	fcmpe	d1, #0.0
    2ac8:	b.mi	295c <pts_ieee754_expm1+0x4c>  // b.first
    2acc:	adrp	x0, 0 <__kernel_tan>
    2ad0:	fmov	d0, #-5.000000000000000000e-01
    2ad4:	ldr	d1, [x0]
    2ad8:	fmul	d1, d2, d1
    2adc:	b	2984 <pts_ieee754_expm1+0x74>
    2ae0:	fsub	d3, d3, d2
    2ae4:	fsub	d3, d19, d3
    2ae8:	cmp	w1, #0x400
    2aec:	b.eq	2c18 <pts_ieee754_expm1+0x308>  // b.none
    2af0:	fmul	d0, d1, d3
    2af4:	fmov	d1, #1.000000000000000000e+00
    2af8:	fsub	d0, d0, d1
    2afc:	ret
    2b00:	mov	w1, #0xa2b1                	// #41649
    2b04:	movk	w1, #0x3ff0, lsl #16
    2b08:	cmp	w0, w1
    2b0c:	b.hi	2bbc <pts_ieee754_expm1+0x2ac>  // b.pmore
    2b10:	adrp	x0, 0 <__kernel_tan>
    2b14:	ldr	d3, [x0]
    2b18:	tbz	w3, #31, 2b54 <pts_ieee754_expm1+0x244>
    2b1c:	adrp	x0, 0 <__kernel_tan>
    2b20:	fadd	d3, d2, d3
    2b24:	mov	w1, #0xffffffff            	// #-1
    2b28:	ldr	d0, [x0]
    2b2c:	b	29a8 <pts_ieee754_expm1+0x98>
    2b30:	adrp	x0, 0 <__kernel_tan>
    2b34:	add	x0, x0, #0x0
    2b38:	ldr	d1, [x0, #40]
    2b3c:	ldr	d0, [x0, #40]
    2b40:	fadd	d1, d1, d2
    2b44:	fadd	d0, d0, d2
    2b48:	fsub	d1, d1, d0
    2b4c:	fsub	d0, d2, d1
    2b50:	ret
    2b54:	adrp	x0, 0 <__kernel_tan>
    2b58:	fsub	d3, d2, d3
    2b5c:	mov	w1, #0x1                   	// #1
    2b60:	ldr	d0, [x0]
    2b64:	b	29a8 <pts_ieee754_expm1+0x98>
    2b68:	fmov	d0, #-2.500000000000000000e-01
    2b6c:	fcmpe	d2, d0
    2b70:	b.mi	2bec <pts_ieee754_expm1+0x2dc>  // b.first
    2b74:	fsub	d3, d2, d3
    2b78:	fmov	d1, #2.000000000000000000e+00
    2b7c:	fmadd	d0, d3, d1, d19
    2b80:	ret
    2b84:	fsub	d3, d2, d3
    2b88:	fmov	d1, #-5.000000000000000000e-01
    2b8c:	fmadd	d0, d3, d18, d1
    2b90:	ret
    2b94:	mov	w0, #0x3ff                 	// #1023
    2b98:	sub	w0, w0, w1
    2b9c:	lsl	w0, w0, #20
    2ba0:	fmov	d0, x0
    2ba4:	shl	d0, d0, #32
    2ba8:	fadd	d3, d3, d0
    2bac:	fsub	d2, d2, d3
    2bb0:	fadd	d2, d2, d19
    2bb4:	fmul	d0, d2, d1
    2bb8:	ret
    2bbc:	adrp	x0, 0 <__kernel_tan>
    2bc0:	cmp	w3, #0x0
    2bc4:	fmov	d0, #-5.000000000000000000e-01
    2bc8:	fmov	d3, #5.000000000000000000e-01
    2bcc:	ldr	d1, [x0]
    2bd0:	fcsel	d0, d0, d3, lt	// lt = tstop
    2bd4:	fmul	d1, d2, d1
    2bd8:	b	2984 <pts_ieee754_expm1+0x74>
    2bdc:	cmp	w3, #0x0
    2be0:	fmov	d1, #-1.000000000000000000e+00
    2be4:	fcsel	d0, d0, d1, ge	// ge = tcont
    2be8:	ret
    2bec:	fadd	d18, d2, d18
    2bf0:	fmov	d1, #-2.000000000000000000e+00
    2bf4:	fsub	d3, d3, d18
    2bf8:	fmul	d0, d3, d1
    2bfc:	ret
    2c00:	adrp	x0, 0 <__kernel_tan>
    2c04:	add	x0, x0, #0x0
    2c08:	ldr	d0, [x0, #40]
    2c0c:	ldr	d1, [x0, #40]
    2c10:	fmul	d0, d0, d1
    2c14:	ret
    2c18:	fadd	d3, d3, d3
    2c1c:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
    2c20:	fmov	d0, x0
    2c24:	fmul	d0, d3, d0
    2c28:	b	2af4 <pts_ieee754_expm1+0x1e4>
    2c2c:	nop

0000000000002c30 <pts_ieee754_cbrt>:
    2c30:	fmov	x1, d0
    2c34:	fmov	d3, d0
    2c38:	mov	w3, #0x7fefffff            	// #2146435071
    2c3c:	ubfx	x0, x1, #32, #31
    2c40:	lsr	x2, x1, #32
    2c44:	cmp	w0, w3
    2c48:	b.hi	2d34 <pts_ieee754_cbrt+0x104>  // b.pmore
    2c4c:	and	w3, w2, #0x80000000
    2c50:	tst	x2, #0x7ff00000
    2c54:	b.ne	2c88 <pts_ieee754_cbrt+0x58>  // b.any
    2c58:	orr	w0, w0, w1
    2c5c:	cbz	w0, 2d30 <pts_ieee754_cbrt+0x100>
    2c60:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2c64:	fmov	d1, x0
    2c68:	mov	w2, #0xaaab                	// #43691
    2c6c:	mov	w1, #0x7893                	// #30867
    2c70:	fmul	d1, d0, d1
    2c74:	movk	w2, #0xaaaa, lsl #16
    2c78:	movk	w1, #0x297f, lsl #16
    2c7c:	fmov	x0, d1
    2c80:	ubfx	x0, x0, #32, #31
    2c84:	b	2c98 <pts_ieee754_cbrt+0x68>
    2c88:	mov	w2, #0xaaab                	// #43691
    2c8c:	mov	w1, #0x7893                	// #30867
    2c90:	movk	w2, #0xaaaa, lsl #16
    2c94:	movk	w1, #0x2a9f, lsl #16
    2c98:	umull	x0, w0, w2
    2c9c:	fmov	d4, #2.000000000000000000e+00
    2ca0:	lsr	x0, x0, #33
    2ca4:	add	w0, w0, w1
    2ca8:	orr	w0, w0, w3
    2cac:	fmov	d0, x0
    2cb0:	adrp	x0, 0 <__kernel_tan>
    2cb4:	shl	d1, d0, #32
    2cb8:	ldr	d16, [x0]
    2cbc:	adrp	x0, 0 <__kernel_tan>
    2cc0:	ldr	d7, [x0]
    2cc4:	adrp	x0, 0 <__kernel_tan>
    2cc8:	fdiv	d17, d1, d3
    2ccc:	fmul	d0, d1, d1
    2cd0:	ldr	d6, [x0]
    2cd4:	adrp	x0, 0 <__kernel_tan>
    2cd8:	ldr	d5, [x0]
    2cdc:	adrp	x0, 0 <__kernel_tan>
    2ce0:	ldr	d2, [x0]
    2ce4:	mov	x0, #0x80000000            	// #2147483648
    2ce8:	fmul	d0, d0, d17
    2cec:	fmadd	d7, d0, d16, d7
    2cf0:	fmadd	d5, d0, d6, d5
    2cf4:	fmul	d6, d0, d0
    2cf8:	fmul	d6, d6, d0
    2cfc:	fmadd	d2, d7, d0, d2
    2d00:	fmadd	d2, d6, d5, d2
    2d04:	fmul	d1, d2, d1
    2d08:	fmov	x1, d1
    2d0c:	add	x0, x1, x0
    2d10:	and	x0, x0, #0xffffffffc0000000
    2d14:	fmov	d1, x0
    2d18:	fmul	d0, d1, d1
    2d1c:	fdiv	d3, d3, d0
    2d20:	fmadd	d0, d1, d4, d3
    2d24:	fsub	d3, d3, d1
    2d28:	fdiv	d3, d3, d0
    2d2c:	fmadd	d0, d1, d3, d1
    2d30:	ret
    2d34:	fadd	d0, d0, d0
    2d38:	ret
    2d3c:	nop

0000000000002d40 <pts_ieee754_sin>:
    2d40:	sub	sp, sp, #0x30
    2d44:	mov	w1, #0x21fb                	// #8699
    2d48:	adrp	x0, 0 <__stack_chk_guard>
    2d4c:	ldr	x0, [x0]
    2d50:	fmov	d1, d0
    2d54:	stp	x29, x30, [sp, #32]
    2d58:	add	x29, sp, #0x20
    2d5c:	movk	w1, #0x3fe9, lsl #16
    2d60:	ldr	x2, [x0]
    2d64:	str	x2, [sp, #24]
    2d68:	mov	x2, #0x0                   	// #0
    2d6c:	fmov	x0, d0
    2d70:	ubfx	x0, x0, #32, #31
    2d74:	cmp	w0, w1
    2d78:	b.le	2e58 <pts_ieee754_sin+0x118>
    2d7c:	mov	w1, #0x7fefffff            	// #2146435071
    2d80:	cmp	w0, w1
    2d84:	b.le	2db4 <pts_ieee754_sin+0x74>
    2d88:	fsub	d0, d0, d0
    2d8c:	adrp	x0, 0 <__stack_chk_guard>
    2d90:	ldr	x0, [x0]
    2d94:	ldr	x2, [sp, #24]
    2d98:	ldr	x1, [x0]
    2d9c:	subs	x2, x2, x1
    2da0:	mov	x1, #0x0                   	// #0
    2da4:	b.ne	31b0 <pts_ieee754_sin+0x470>  // b.any
    2da8:	ldp	x29, x30, [sp, #32]
    2dac:	add	sp, sp, #0x30
    2db0:	ret
    2db4:	add	x0, sp, #0x8
    2db8:	bl	900 <__ieee754_rem_pio2>
    2dbc:	and	w0, w0, #0x3
    2dc0:	cmp	w0, #0x1
    2dc4:	b.eq	2ffc <pts_ieee754_sin+0x2bc>  // b.none
    2dc8:	cmp	w0, #0x2
    2dcc:	b.eq	2ec0 <pts_ieee754_sin+0x180>  // b.none
    2dd0:	cbnz	w0, 2f48 <pts_ieee754_sin+0x208>
    2dd4:	ldp	d0, d2, [sp, #8]
    2dd8:	mov	w0, #0x3e3fffff            	// #1044381695
    2ddc:	fmov	x1, d0
    2de0:	ubfx	x1, x1, #32, #31
    2de4:	cmp	w1, w0
    2de8:	b.gt	2df4 <pts_ieee754_sin+0xb4>
    2dec:	fcvtzs	w0, d0
    2df0:	cbz	w0, 2d8c <pts_ieee754_sin+0x4c>
    2df4:	adrp	x0, 0 <__kernel_tan>
    2df8:	fmul	d3, d0, d0
    2dfc:	fmov	d17, #5.000000000000000000e-01
    2e00:	ldr	d7, [x0]
    2e04:	adrp	x0, 0 <__kernel_tan>
    2e08:	ldr	d6, [x0]
    2e0c:	adrp	x0, 0 <__kernel_tan>
    2e10:	fmadd	d6, d3, d7, d6
    2e14:	fmul	d7, d0, d3
    2e18:	ldr	d5, [x0]
    2e1c:	adrp	x0, 0 <__kernel_tan>
    2e20:	ldr	d4, [x0]
    2e24:	adrp	x0, 0 <__kernel_tan>
    2e28:	ldr	d1, [x0]
    2e2c:	adrp	x0, 0 <__kernel_tan>
    2e30:	ldr	d16, [x0]
    2e34:	fmadd	d5, d3, d6, d5
    2e38:	fmadd	d4, d3, d5, d4
    2e3c:	fmadd	d1, d3, d4, d1
    2e40:	fmul	d1, d7, d1
    2e44:	fnmsub	d1, d2, d17, d1
    2e48:	fnmsub	d2, d3, d1, d2
    2e4c:	fmadd	d2, d7, d16, d2
    2e50:	fsub	d0, d0, d2
    2e54:	b	2d8c <pts_ieee754_sin+0x4c>
    2e58:	mov	w1, #0x3e3fffff            	// #1044381695
    2e5c:	cmp	w0, w1
    2e60:	b.gt	2e6c <pts_ieee754_sin+0x12c>
    2e64:	fcvtzs	w0, d0
    2e68:	cbz	w0, 2d8c <pts_ieee754_sin+0x4c>
    2e6c:	adrp	x0, 0 <__kernel_tan>
    2e70:	fmul	d2, d1, d1
    2e74:	ldr	d0, [x0]
    2e78:	adrp	x0, 0 <__kernel_tan>
    2e7c:	ldr	d7, [x0]
    2e80:	adrp	x0, 0 <__kernel_tan>
    2e84:	fmadd	d7, d2, d0, d7
    2e88:	fmul	d0, d1, d2
    2e8c:	ldr	d6, [x0]
    2e90:	adrp	x0, 0 <__kernel_tan>
    2e94:	ldr	d5, [x0]
    2e98:	adrp	x0, 0 <__kernel_tan>
    2e9c:	ldr	d4, [x0]
    2ea0:	adrp	x0, 0 <__kernel_tan>
    2ea4:	ldr	d3, [x0]
    2ea8:	fmadd	d6, d2, d7, d6
    2eac:	fmadd	d5, d2, d6, d5
    2eb0:	fmadd	d4, d2, d5, d4
    2eb4:	fmadd	d2, d2, d4, d3
    2eb8:	fmadd	d0, d0, d2, d1
    2ebc:	b	2d8c <pts_ieee754_sin+0x4c>
    2ec0:	ldp	d0, d2, [sp, #8]
    2ec4:	mov	w0, #0x3e3fffff            	// #1044381695
    2ec8:	fmov	x1, d0
    2ecc:	ubfx	x1, x1, #32, #31
    2ed0:	cmp	w1, w0
    2ed4:	b.gt	2ee0 <pts_ieee754_sin+0x1a0>
    2ed8:	fcvtzs	w0, d0
    2edc:	cbz	w0, 2f40 <pts_ieee754_sin+0x200>
    2ee0:	adrp	x0, 0 <__kernel_tan>
    2ee4:	fmul	d3, d0, d0
    2ee8:	fmov	d17, #5.000000000000000000e-01
    2eec:	ldr	d7, [x0]
    2ef0:	adrp	x0, 0 <__kernel_tan>
    2ef4:	ldr	d6, [x0]
    2ef8:	adrp	x0, 0 <__kernel_tan>
    2efc:	fmadd	d6, d3, d7, d6
    2f00:	fmul	d7, d0, d3
    2f04:	ldr	d5, [x0]
    2f08:	adrp	x0, 0 <__kernel_tan>
    2f0c:	ldr	d4, [x0]
    2f10:	adrp	x0, 0 <__kernel_tan>
    2f14:	ldr	d1, [x0]
    2f18:	adrp	x0, 0 <__kernel_tan>
    2f1c:	ldr	d16, [x0]
    2f20:	fmadd	d5, d3, d6, d5
    2f24:	fmadd	d4, d3, d5, d4
    2f28:	fmadd	d1, d3, d4, d1
    2f2c:	fmul	d1, d7, d1
    2f30:	fnmsub	d1, d2, d17, d1
    2f34:	fnmsub	d2, d3, d1, d2
    2f38:	fmadd	d2, d7, d16, d2
    2f3c:	fsub	d0, d0, d2
    2f40:	fneg	d0, d0
    2f44:	b	2d8c <pts_ieee754_sin+0x4c>
    2f48:	ldp	d1, d7, [sp, #8]
    2f4c:	mov	w1, #0x3e3fffff            	// #1044381695
    2f50:	fmov	x0, d1
    2f54:	ubfx	x0, x0, #32, #31
    2f58:	cmp	w0, w1
    2f5c:	b.le	3120 <pts_ieee754_sin+0x3e0>
    2f60:	adrp	x1, 0 <__kernel_tan>
    2f64:	fmul	d2, d1, d1
    2f68:	ldr	d16, [x1]
    2f6c:	adrp	x1, 0 <__kernel_tan>
    2f70:	ldr	d6, [x1]
    2f74:	adrp	x1, 0 <__kernel_tan>
    2f78:	fmadd	d6, d2, d16, d6
    2f7c:	ldr	d5, [x1]
    2f80:	adrp	x1, 0 <__kernel_tan>
    2f84:	ldr	d3, [x1]
    2f88:	adrp	x1, 0 <__kernel_tan>
    2f8c:	ldr	d0, [x1]
    2f90:	adrp	x1, 0 <__kernel_tan>
    2f94:	ldr	d4, [x1]
    2f98:	mov	w1, #0x3332                	// #13106
    2f9c:	fmadd	d5, d2, d6, d5
    2fa0:	movk	w1, #0x3fd3, lsl #16
    2fa4:	fmadd	d3, d2, d5, d3
    2fa8:	fmadd	d0, d2, d3, d0
    2fac:	fmadd	d4, d2, d0, d4
    2fb0:	fmul	d4, d2, d4
    2fb4:	cmp	w0, w1
    2fb8:	b.le	3178 <pts_ieee754_sin+0x438>
    2fbc:	mov	w1, #0x3fe90000            	// #1072234496
    2fc0:	cmp	w0, w1
    2fc4:	b.gt	31a4 <pts_ieee754_sin+0x464>
    2fc8:	sub	w0, w0, #0x200, lsl #12
    2fcc:	fmov	d3, x0
    2fd0:	fmov	d0, #1.000000000000000000e+00
    2fd4:	shl	d3, d3, #32
    2fd8:	fsub	d0, d0, d3
    2fdc:	fmov	d5, #5.000000000000000000e-01
    2fe0:	fmul	d1, d1, d7
    2fe4:	fnmsub	d1, d2, d4, d1
    2fe8:	fnmsub	d3, d2, d5, d3
    2fec:	fsub	d3, d3, d1
    2ff0:	fsub	d0, d0, d3
    2ff4:	fneg	d0, d0
    2ff8:	b	2d8c <pts_ieee754_sin+0x4c>
    2ffc:	ldp	d1, d7, [sp, #8]
    3000:	mov	w1, #0x3e3fffff            	// #1044381695
    3004:	fmov	x0, d1
    3008:	ubfx	x0, x0, #32, #31
    300c:	cmp	w0, w1
    3010:	b.le	30ac <pts_ieee754_sin+0x36c>
    3014:	adrp	x1, 0 <__kernel_tan>
    3018:	fmul	d2, d1, d1
    301c:	ldr	d16, [x1]
    3020:	adrp	x1, 0 <__kernel_tan>
    3024:	ldr	d6, [x1]
    3028:	adrp	x1, 0 <__kernel_tan>
    302c:	fmadd	d6, d2, d16, d6
    3030:	ldr	d5, [x1]
    3034:	adrp	x1, 0 <__kernel_tan>
    3038:	ldr	d3, [x1]
    303c:	adrp	x1, 0 <__kernel_tan>
    3040:	ldr	d0, [x1]
    3044:	adrp	x1, 0 <__kernel_tan>
    3048:	ldr	d4, [x1]
    304c:	mov	w1, #0x3332                	// #13106
    3050:	fmadd	d5, d2, d6, d5
    3054:	movk	w1, #0x3fd3, lsl #16
    3058:	fmadd	d3, d2, d5, d3
    305c:	fmadd	d0, d2, d3, d0
    3060:	fmadd	d4, d2, d0, d4
    3064:	fmul	d4, d2, d4
    3068:	cmp	w0, w1
    306c:	b.le	3104 <pts_ieee754_sin+0x3c4>
    3070:	mov	w1, #0x3fe90000            	// #1072234496
    3074:	cmp	w0, w1
    3078:	b.gt	3198 <pts_ieee754_sin+0x458>
    307c:	sub	w0, w0, #0x200, lsl #12
    3080:	fmov	d3, x0
    3084:	fmov	d0, #1.000000000000000000e+00
    3088:	shl	d3, d3, #32
    308c:	fsub	d0, d0, d3
    3090:	fmov	d5, #5.000000000000000000e-01
    3094:	fmul	d1, d1, d7
    3098:	fnmsub	d1, d2, d4, d1
    309c:	fnmsub	d3, d2, d5, d3
    30a0:	fsub	d3, d3, d1
    30a4:	fsub	d0, d0, d3
    30a8:	b	2d8c <pts_ieee754_sin+0x4c>
    30ac:	fcvtzs	w0, d1
    30b0:	fmov	d0, #1.000000000000000000e+00
    30b4:	cbz	w0, 2d8c <pts_ieee754_sin+0x4c>
    30b8:	adrp	x0, 0 <__kernel_tan>
    30bc:	fmul	d2, d1, d1
    30c0:	ldr	d16, [x0]
    30c4:	adrp	x0, 0 <__kernel_tan>
    30c8:	ldr	d6, [x0]
    30cc:	adrp	x0, 0 <__kernel_tan>
    30d0:	fmadd	d6, d2, d16, d6
    30d4:	ldr	d5, [x0]
    30d8:	adrp	x0, 0 <__kernel_tan>
    30dc:	ldr	d3, [x0]
    30e0:	adrp	x0, 0 <__kernel_tan>
    30e4:	ldr	d0, [x0]
    30e8:	adrp	x0, 0 <__kernel_tan>
    30ec:	ldr	d4, [x0]
    30f0:	fmadd	d5, d6, d2, d5
    30f4:	fmadd	d3, d2, d5, d3
    30f8:	fmadd	d0, d2, d3, d0
    30fc:	fmadd	d4, d2, d0, d4
    3100:	fmul	d4, d2, d4
    3104:	fmul	d1, d1, d7
    3108:	fmov	d3, #5.000000000000000000e-01
    310c:	fnmsub	d1, d4, d2, d1
    3110:	fmov	d0, #1.000000000000000000e+00
    3114:	fnmsub	d1, d2, d3, d1
    3118:	fsub	d0, d0, d1
    311c:	b	2d8c <pts_ieee754_sin+0x4c>
    3120:	fcvtzs	w0, d1
    3124:	fmov	d0, #-1.000000000000000000e+00
    3128:	cbz	w0, 2d8c <pts_ieee754_sin+0x4c>
    312c:	adrp	x0, 0 <__kernel_tan>
    3130:	fmul	d2, d1, d1
    3134:	ldr	d16, [x0]
    3138:	adrp	x0, 0 <__kernel_tan>
    313c:	ldr	d6, [x0]
    3140:	adrp	x0, 0 <__kernel_tan>
    3144:	fmadd	d6, d2, d16, d6
    3148:	ldr	d5, [x0]
    314c:	adrp	x0, 0 <__kernel_tan>
    3150:	ldr	d3, [x0]
    3154:	adrp	x0, 0 <__kernel_tan>
    3158:	ldr	d0, [x0]
    315c:	adrp	x0, 0 <__kernel_tan>
    3160:	ldr	d4, [x0]
    3164:	fmadd	d5, d2, d6, d5
    3168:	fmadd	d3, d5, d2, d3
    316c:	fmadd	d0, d3, d2, d0
    3170:	fmadd	d4, d0, d2, d4
    3174:	fmul	d4, d4, d2
    3178:	fmul	d1, d1, d7
    317c:	fmov	d3, #5.000000000000000000e-01
    3180:	fnmsub	d1, d2, d4, d1
    3184:	fmov	d0, #1.000000000000000000e+00
    3188:	fnmsub	d1, d2, d3, d1
    318c:	fsub	d0, d0, d1
    3190:	fneg	d0, d0
    3194:	b	2d8c <pts_ieee754_sin+0x4c>
    3198:	fmov	d0, #7.187500000000000000e-01
    319c:	fmov	d3, #2.812500000000000000e-01
    31a0:	b	3090 <pts_ieee754_sin+0x350>
    31a4:	fmov	d0, #7.187500000000000000e-01
    31a8:	fmov	d3, #2.812500000000000000e-01
    31ac:	b	2fdc <pts_ieee754_sin+0x29c>
    31b0:	bl	0 <__stack_chk_fail>

00000000000031b4 <pts_ieee754_tan>:
    31b4:	sub	sp, sp, #0x30
    31b8:	fmov	x0, d0
    31bc:	adrp	x1, 0 <__stack_chk_guard>
    31c0:	ldr	x1, [x1]
    31c4:	mov	w2, #0x21fb                	// #8699
    31c8:	stp	x29, x30, [sp, #32]
    31cc:	add	x29, sp, #0x20
    31d0:	movk	w2, #0x3fe9, lsl #16
    31d4:	ldr	x3, [x1]
    31d8:	str	x3, [sp, #24]
    31dc:	mov	x3, #0x0                   	// #0
    31e0:	ubfx	x1, x0, #32, #31
    31e4:	cmp	w1, w2
    31e8:	b.le	3268 <pts_ieee754_tan+0xb4>
    31ec:	mov	w2, #0x7fefffff            	// #2146435071
    31f0:	cmp	w1, w2
    31f4:	b.le	3228 <pts_ieee754_tan+0x74>
    31f8:	adrp	x1, 0 <__stack_chk_guard>
    31fc:	ldr	x1, [x1]
    3200:	fsub	d0, d0, d0
    3204:	mov	x0, x1
    3208:	ldr	x2, [sp, #24]
    320c:	ldr	x1, [x0]
    3210:	subs	x2, x2, x1
    3214:	mov	x1, #0x0                   	// #0
    3218:	b.ne	3298 <pts_ieee754_tan+0xe4>  // b.any
    321c:	ldp	x29, x30, [sp, #32]
    3220:	add	sp, sp, #0x30
    3224:	ret
    3228:	add	x0, sp, #0x8
    322c:	bl	900 <__ieee754_rem_pio2>
    3230:	adrp	x1, 0 <__stack_chk_guard>
    3234:	ldr	x1, [x1]
    3238:	ldr	x3, [sp, #24]
    323c:	ldr	x2, [x1]
    3240:	subs	x3, x3, x2
    3244:	mov	x2, #0x0                   	// #0
    3248:	b.ne	3298 <pts_ieee754_tan+0xe4>  // b.any
    324c:	ldp	x29, x30, [sp, #32]
    3250:	ubfiz	w0, w0, #1, #1
    3254:	ldp	d0, d1, [sp, #8]
    3258:	mov	w1, #0x1                   	// #1
    325c:	add	sp, sp, #0x30
    3260:	sub	w0, w1, w0
    3264:	b	0 <__kernel_tan>
    3268:	adrp	x0, 0 <__stack_chk_guard>
    326c:	ldr	x0, [x0]
    3270:	ldr	x2, [sp, #24]
    3274:	ldr	x1, [x0]
    3278:	subs	x2, x2, x1
    327c:	mov	x1, #0x0                   	// #0
    3280:	b.ne	3298 <pts_ieee754_tan+0xe4>  // b.any
    3284:	ldp	x29, x30, [sp, #32]
    3288:	movi	d1, #0x0
    328c:	add	sp, sp, #0x30
    3290:	mov	w0, #0x1                   	// #1
    3294:	b	0 <__kernel_tan>
    3298:	bl	0 <__stack_chk_fail>
    329c:	nop

00000000000032a0 <pts_ieee754_cosh>:
    32a0:	fmov	x1, d0
    32a4:	stp	x29, x30, [sp, #-16]!
    32a8:	mov	w0, #0x2e42                	// #11842
    32ac:	mov	x29, sp
    32b0:	fmov	d1, d0
    32b4:	movk	w0, #0x3fd6, lsl #16
    32b8:	ubfx	x4, x1, #32, #31
    32bc:	fabs	d0, d0
    32c0:	cmp	w4, w0
    32c4:	b.le	331c <pts_ieee754_cosh+0x7c>
    32c8:	mov	w0, #0x4035ffff            	// #1077280767
    32cc:	cmp	w4, w0
    32d0:	b.le	3364 <pts_ieee754_cosh+0xc4>
    32d4:	mov	w0, #0x2e41                	// #11841
    32d8:	movk	w0, #0x4086, lsl #16
    32dc:	cmp	w4, w0
    32e0:	b.le	3350 <pts_ieee754_cosh+0xb0>
    32e4:	adrp	x0, 0 <__kernel_tan>
    32e8:	ldr	d2, [x0]
    32ec:	fcmpe	d0, d2
    32f0:	b.ls	3388 <pts_ieee754_cosh+0xe8>  // b.plast
    32f4:	mov	w0, #0x7fefffff            	// #2146435071
    32f8:	cmp	w4, w0
    32fc:	b.gt	337c <pts_ieee754_cosh+0xdc>
    3300:	adrp	x0, 0 <__kernel_tan>
    3304:	add	x0, x0, #0x0
    3308:	ldr	d0, [x0, #48]
    330c:	ldr	d1, [x0, #48]
    3310:	fmul	d0, d0, d1
    3314:	ldp	x29, x30, [sp], #16
    3318:	ret
    331c:	bl	2910 <pts_ieee754_expm1>
    3320:	fmov	d1, d0
    3324:	fmov	d3, #1.000000000000000000e+00
    3328:	mov	w0, #0x3c7fffff            	// #1015021567
    332c:	fadd	d0, d0, d3
    3330:	cmp	w4, w0
    3334:	b.le	3314 <pts_ieee754_cosh+0x74>
    3338:	fmul	d2, d1, d1
    333c:	fadd	d1, d0, d0
    3340:	ldp	x29, x30, [sp], #16
    3344:	fdiv	d1, d2, d1
    3348:	fadd	d0, d1, d3
    334c:	ret
    3350:	bl	1ba0 <pts_ieee754_exp>
    3354:	fmov	d1, #5.000000000000000000e-01
    3358:	ldp	x29, x30, [sp], #16
    335c:	fmul	d0, d0, d1
    3360:	ret
    3364:	bl	1ba0 <pts_ieee754_exp>
    3368:	fmov	d2, #5.000000000000000000e-01
    336c:	ldp	x29, x30, [sp], #16
    3370:	fdiv	d1, d2, d0
    3374:	fmadd	d0, d0, d2, d1
    3378:	ret
    337c:	fmul	d0, d1, d1
    3380:	ldp	x29, x30, [sp], #16
    3384:	ret
    3388:	fmov	d18, #5.000000000000000000e-01
    338c:	fmul	d0, d0, d18
    3390:	bl	1ba0 <pts_ieee754_exp>
    3394:	fmul	d1, d0, d18
    3398:	fmul	d0, d1, d0
    339c:	b	3314 <pts_ieee754_cosh+0x74>

00000000000033a0 <pts_ieee754_sinh>:
    33a0:	fcmpe	d0, #0.0
    33a4:	fabs	d21, d0
    33a8:	fmov	d1, #-5.000000000000000000e-01
    33ac:	fmov	d2, #5.000000000000000000e-01
    33b0:	fmov	d3, #2.200000000000000000e+01
    33b4:	stp	x29, x30, [sp, #-16]!
    33b8:	fcsel	d22, d1, d2, mi	// mi = first
    33bc:	fcmpe	d21, d3
    33c0:	mov	x29, sp
    33c4:	b.mi	3400 <pts_ieee754_sinh+0x60>  // b.first
    33c8:	mov	x0, #0x2e4200000000        	// #50861002719232
    33cc:	movk	x0, #0x4086, lsl #48
    33d0:	fmov	d1, x0
    33d4:	fcmpe	d21, d1
    33d8:	b.mi	343c <pts_ieee754_sinh+0x9c>  // b.first
    33dc:	adrp	x0, 0 <__kernel_tan>
    33e0:	ldr	d1, [x0]
    33e4:	fcmpe	d21, d1
    33e8:	b.ls	3470 <pts_ieee754_sinh+0xd0>  // b.plast
    33ec:	adrp	x0, 0 <__kernel_tan>
    33f0:	ldr	d1, [x0]
    33f4:	fmul	d0, d0, d1
    33f8:	ldp	x29, x30, [sp], #16
    33fc:	ret
    3400:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
    3404:	fmov	d1, x0
    3408:	fcmpe	d21, d1
    340c:	b.mi	33f8 <pts_ieee754_sinh+0x58>  // b.first
    3410:	fmov	d0, d21
    3414:	bl	2910 <pts_ieee754_expm1>
    3418:	fmov	d1, #1.000000000000000000e+00
    341c:	fcmpe	d21, d1
    3420:	b.mi	3450 <pts_ieee754_sinh+0xb0>  // b.first
    3424:	fadd	d1, d0, d1
    3428:	ldp	x29, x30, [sp], #16
    342c:	fdiv	d1, d0, d1
    3430:	fadd	d0, d1, d0
    3434:	fmul	d0, d0, d22
    3438:	ret
    343c:	fmov	d0, d21
    3440:	bl	1ba0 <pts_ieee754_exp>
    3444:	fmul	d0, d0, d22
    3448:	ldp	x29, x30, [sp], #16
    344c:	ret
    3450:	fmul	d2, d0, d0
    3454:	fadd	d1, d0, d1
    3458:	fmov	d3, #2.000000000000000000e+00
    345c:	ldp	x29, x30, [sp], #16
    3460:	fdiv	d1, d2, d1
    3464:	fnmsub	d0, d0, d3, d1
    3468:	fmul	d0, d0, d22
    346c:	ret
    3470:	fmul	d0, d21, d2
    3474:	bl	1ba0 <pts_ieee754_exp>
    3478:	fmul	d1, d22, d0
    347c:	fmul	d0, d1, d0
    3480:	b	33f8 <pts_ieee754_sinh+0x58>

0000000000003484 <pts_ieee754_tanh>:
    3484:	fmov	x0, d0
    3488:	fmov	d1, d0
    348c:	mov	w1, #0x7fefffff            	// #2146435071
    3490:	lsr	x4, x0, #32
    3494:	and	w0, w4, #0x7fffffff
    3498:	cmp	w0, w1
    349c:	b.le	34bc <pts_ieee754_tanh+0x38>
    34a0:	fmov	d0, #1.000000000000000000e+00
    34a4:	fdiv	d1, d0, d1
    34a8:	tbnz	w4, #31, 34b4 <pts_ieee754_tanh+0x30>
    34ac:	fadd	d0, d1, d0
    34b0:	ret
    34b4:	fsub	d0, d1, d0
    34b8:	ret
    34bc:	mov	w1, #0x4035ffff            	// #1077280767
    34c0:	cmp	w0, w1
    34c4:	b.gt	351c <pts_ieee754_tanh+0x98>
    34c8:	stp	x29, x30, [sp, #-16]!
    34cc:	mov	w1, #0x3e2fffff            	// #1043333119
    34d0:	mov	x29, sp
    34d4:	cmp	w0, w1
    34d8:	b.le	3540 <pts_ieee754_tanh+0xbc>
    34dc:	fabs	d0, d0
    34e0:	mov	w1, #0x3fefffff            	// #1072693247
    34e4:	cmp	w0, w1
    34e8:	b.le	355c <pts_ieee754_tanh+0xd8>
    34ec:	fadd	d0, d0, d0
    34f0:	bl	2910 <pts_ieee754_expm1>
    34f4:	fmov	d2, #2.000000000000000000e+00
    34f8:	fmov	d1, #1.000000000000000000e+00
    34fc:	fadd	d0, d0, d2
    3500:	fdiv	d2, d2, d0
    3504:	fsub	d0, d1, d2
    3508:	fneg	d1, d0
    350c:	cmp	w4, #0x0
    3510:	fcsel	d0, d1, d0, lt	// lt = tstop
    3514:	ldp	x29, x30, [sp], #16
    3518:	ret
    351c:	adrp	x0, 0 <__kernel_tan>
    3520:	add	x0, x0, #0x0
    3524:	fmov	d0, #1.000000000000000000e+00
    3528:	cmp	w4, #0x0
    352c:	ldr	d1, [x0, #576]
    3530:	fsub	d0, d0, d1
    3534:	fneg	d1, d0
    3538:	fcsel	d0, d1, d0, lt	// lt = tstop
    353c:	ret
    3540:	adrp	x0, 0 <__kernel_tan>
    3544:	fmov	d3, #1.000000000000000000e+00
    3548:	ldr	d2, [x0]
    354c:	fadd	d2, d0, d2
    3550:	fcmpe	d2, d3
    3554:	b.gt	3514 <pts_ieee754_tanh+0x90>
    3558:	fabs	d0, d0
    355c:	fmov	d1, #-2.000000000000000000e+00
    3560:	fmul	d0, d0, d1
    3564:	bl	2910 <pts_ieee754_expm1>
    3568:	fneg	d1, d0
    356c:	fmov	d2, #2.000000000000000000e+00
    3570:	fadd	d0, d0, d2
    3574:	fdiv	d0, d1, d0
    3578:	b	3508 <pts_ieee754_tanh+0x84>
