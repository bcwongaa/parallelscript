
/tmp/pts-h36/node-arm64-dl/node-v24.21.0-linux-arm64/bin/node:     file format elf64-littleaarch64


Disassembly of section .text:

0000000001018e50 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)>:
 1018e50:	ldr	w7, [x0, #32]
 1018e54:	mov	w3, #0xa                   	// #10
 1018e58:	ldr	d0, [x0, #72]
 1018e5c:	mov	w8, #0x71c7                	// #29127
 1018e60:	cmp	w7, w3
 1018e64:	add	w11, w7, #0x57
 1018e68:	csel	w3, w7, w3, le
 1018e6c:	add	w9, w7, #0x37
 1018e70:	add	w10, w3, #0x30
 1018e74:	movk	w8, #0x71c, lsl #16
 1018e78:	mov	w6, #0x1                   	// #1
 1018e7c:	mov	w5, #0x0                   	// #0
 1018e80:	ldrb	w3, [x1]
 1018e84:	cmp	w3, #0x2f
 1018e88:	b.hi	1018edc <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x8c>  // b.pmore
 1018e8c:	scvtf	d2, w6
 1018e90:	ucvtf	d1, w5
 1018e94:	ldrb	w3, [x0, #62]
 1018e98:	fmadd	d0, d0, d2, d1
 1018e9c:	str	d0, [x0, #72]
 1018ea0:	cbnz	w3, 1018f70 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x120>
 1018ea4:	cmp	x2, x1
 1018ea8:	b.eq	1018f70 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x120>  // b.none
 1018eac:	adrp	x4, 36c1000 <fast_float::powers_template<void>::power_of_five_128+0x1b18>
 1018eb0:	add	x4, x4, #0xf10
 1018eb4:	b	1018ec0 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x70>
 1018eb8:	cmp	x2, x1
 1018ebc:	b.eq	1018f70 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x120>  // b.none
 1018ec0:	ldrb	w3, [x1]
 1018ec4:	add	x1, x1, #0x1
 1018ec8:	ldrb	w3, [x4, w3, uxtw]
 1018ecc:	tbnz	w3, #3, 1018eb8 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x68>
 1018ed0:	mov	w1, #0x2                   	// #2
 1018ed4:	str	w1, [x0, #64]
 1018ed8:	ret
 1018edc:	cmp	w3, w10
 1018ee0:	b.ge	1018f0c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0xbc>  // b.tcont
 1018ee4:	sub	w3, w3, #0x30
 1018ee8:	mul	w4, w7, w6
 1018eec:	cmp	w4, w8
 1018ef0:	b.hi	1018f30 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0xe0>  // b.pmore
 1018ef4:	add	x1, x1, #0x1
 1018ef8:	madd	w5, w7, w5, w3
 1018efc:	cmp	x1, x2
 1018f00:	b.eq	1018f60 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x110>  // b.none
 1018f04:	mov	w6, w4
 1018f08:	b	1018e80 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x30>
 1018f0c:	cmp	w3, #0x60
 1018f10:	b.ls	1018f44 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0xf4>  // b.plast
 1018f14:	cmp	w3, w11
 1018f18:	b.ge	1018f50 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x100>  // b.tcont
 1018f1c:	mul	w4, w7, w6
 1018f20:	sub	w3, w3, #0x57
 1018f24:	cmp	w4, w8
 1018f28:	b.ls	1018ef4 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0xa4>  // b.plast
 1018f2c:	nop
 1018f30:	scvtf	d2, w6
 1018f34:	ucvtf	d1, w5
 1018f38:	fmadd	d0, d2, d0, d1
 1018f3c:	str	d0, [x0, #72]
 1018f40:	b	1018e78 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x28>
 1018f44:	cmp	w3, #0x40
 1018f48:	b.ls	1018e8c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x3c>  // b.plast
 1018f4c:	nop
 1018f50:	cmp	w3, w9
 1018f54:	b.ge	1018e8c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x3c>  // b.tcont
 1018f58:	sub	w3, w3, #0x37
 1018f5c:	b	1018ee8 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x98>
 1018f60:	scvtf	d2, w4
 1018f64:	ucvtf	d1, w5
 1018f68:	fmadd	d0, d0, d2, d1
 1018f6c:	str	d0, [x0, #72]
 1018f70:	mov	w1, #0x5                   	// #5
 1018f74:	b	1018ed4 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned char>(unsigned char const*, unsigned char const*)+0x84>
 1018f78:	nop
 1018f7c:	nop

0000000001018f80 <void v8::internal::NumberParseIntHelper::HandleBaseTenCase<unsigned short>(unsigned short const*, unsigned short const*)>:
 1018f80:	stp	x29, x30, [sp, #-352]!
 1018f84:	mov	x3, x1
 1018f88:	mov	x1, #0x0                   	// #0
 1018f8c:	mov	x29, sp
 1018f90:	str	x19, [sp, #16]
 1018f94:	mov	x19, x0
 1018f98:	add	x0, sp, #0x28
 1018f9c:	b	1018fb8 <void v8::internal::NumberParseIntHelper::HandleBaseTenCase<unsigned short>(unsigned short const*, unsigned short const*)+0x38>
 1018fa0:	cmp	x1, #0x135
 1018fa4:	b.hi	1018fb0 <void v8::internal::NumberParseIntHelper::HandleBaseTenCase<unsigned short>(unsigned short const*, unsigned short const*)+0x30>  // b.pmore
 1018fa8:	strb	w5, [x0, x1]
 1018fac:	add	x1, x1, #0x1
 1018fb0:	cmp	x3, x2
 1018fb4:	b.eq	1018fd0 <void v8::internal::NumberParseIntHelper::HandleBaseTenCase<unsigned short>(unsigned short const*, unsigned short const*)+0x50>  // b.none
 1018fb8:	ldrh	w5, [x3]
 1018fbc:	add	x3, x3, #0x2
 1018fc0:	sub	w4, w5, #0x30
 1018fc4:	and	w4, w4, #0xffff
 1018fc8:	cmp	w4, #0x9
 1018fcc:	b.ls	1018fa0 <void v8::internal::NumberParseIntHelper::HandleBaseTenCase<unsigned short>(unsigned short const*, unsigned short const*)+0x20>  // b.plast
 1018fd0:	mov	w2, #0x0                   	// #0
 1018fd4:	strb	wzr, [x0, x1]
 1018fd8:	bl	2413650 <v8::base::Strtod(v8::base::Vector<char const>, int)>
 1018fdc:	str	d0, [x19, #72]
 1018fe0:	mov	w0, #0x5                   	// #5
 1018fe4:	str	w0, [x19, #64]
 1018fe8:	ldr	x19, [sp, #16]
 1018fec:	ldp	x29, x30, [sp], #352
 1018ff0:	ret
 1018ff4:	nop
 1018ff8:	nop
 1018ffc:	nop

0000000001019000 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)>:
 1019000:	stp	x29, x30, [sp, #-64]!
 1019004:	mov	w3, #0xa                   	// #10
 1019008:	mov	x29, sp
 101900c:	stp	x19, x20, [sp, #16]
 1019010:	mov	x20, x2
 1019014:	mov	x19, x1
 1019018:	stp	x21, x22, [sp, #32]
 101901c:	mov	w2, #0x71c7                	// #29127
 1019020:	mov	x21, x0
 1019024:	ldr	w6, [x0, #32]
 1019028:	movk	w2, #0x71c, lsl #16
 101902c:	ldr	d0, [x0, #72]
 1019030:	cmp	w6, w3
 1019034:	add	w9, w6, #0x57
 1019038:	csel	w3, w6, w3, le
 101903c:	add	w7, w6, #0x37
 1019040:	add	w8, w3, #0x30
 1019044:	nop
 1019048:	mov	w5, #0x1                   	// #1
 101904c:	mov	w4, #0x0                   	// #0
 1019050:	ldrh	w3, [x19]
 1019054:	cmp	w3, #0x2f
 1019058:	b.hi	101908c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x8c>  // b.pmore
 101905c:	scvtf	d2, w5
 1019060:	ucvtf	d1, w4
 1019064:	ldrb	w0, [x21, #62]
 1019068:	fmadd	d0, d0, d2, d1
 101906c:	str	d0, [x21, #72]
 1019070:	cbz	w0, 1019124 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x124>
 1019074:	mov	w0, #0x5                   	// #5
 1019078:	str	w0, [x21, #64]
 101907c:	ldp	x19, x20, [sp, #16]
 1019080:	ldp	x21, x22, [sp, #32]
 1019084:	ldp	x29, x30, [sp], #64
 1019088:	ret
 101908c:	cmp	w3, w8
 1019090:	b.ge	10190bc <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0xbc>  // b.tcont
 1019094:	sub	w3, w3, #0x30
 1019098:	mul	w1, w6, w5
 101909c:	cmp	w1, w2
 10190a0:	b.hi	10190e0 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0xe0>  // b.pmore
 10190a4:	add	x19, x19, #0x2
 10190a8:	madd	w4, w6, w4, w3
 10190ac:	cmp	x19, x20
 10190b0:	b.eq	1019110 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x110>  // b.none
 10190b4:	mov	w5, w1
 10190b8:	b	1019050 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x50>
 10190bc:	cmp	w3, #0x60
 10190c0:	b.ls	10190f4 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0xf4>  // b.plast
 10190c4:	cmp	w3, w9
 10190c8:	b.ge	1019100 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x100>  // b.tcont
 10190cc:	mul	w1, w6, w5
 10190d0:	sub	w3, w3, #0x57
 10190d4:	cmp	w1, w2
 10190d8:	b.ls	10190a4 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0xa4>  // b.plast
 10190dc:	nop
 10190e0:	scvtf	d2, w5
 10190e4:	ucvtf	d1, w4
 10190e8:	fmadd	d0, d2, d0, d1
 10190ec:	str	d0, [x21, #72]
 10190f0:	b	1019048 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x48>
 10190f4:	cmp	w3, #0x40
 10190f8:	b.ls	101905c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x5c>  // b.plast
 10190fc:	nop
 1019100:	cmp	w3, w7
 1019104:	b.ge	101905c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x5c>  // b.tcont
 1019108:	sub	w3, w3, #0x37
 101910c:	b	1019098 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x98>
 1019110:	scvtf	d2, w1
 1019114:	ucvtf	d1, w4
 1019118:	fmadd	d0, d0, d2, d1
 101911c:	str	d0, [x21, #72]
 1019120:	b	1019074 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x74>
 1019124:	stp	x23, x24, [sp, #48]
 1019128:	cmp	x20, x19
 101912c:	b.eq	1019198 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x198>  // b.none
 1019130:	adrp	x23, 36c1000 <fast_float::powers_template<void>::power_of_five_128+0x1b18>
 1019134:	mov	w24, #0xffffdfd8            	// #-8232
 1019138:	add	x23, x23, #0xf10
 101913c:	b	1019150 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x150>
 1019140:	ldrb	w0, [x23, w22, uxtw]
 1019144:	tbz	w0, #3, 101917c <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x17c>
 1019148:	cmp	x20, x19
 101914c:	b.eq	1019198 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x198>  // b.none
 1019150:	ldrh	w22, [x19]
 1019154:	add	x19, x19, #0x2
 1019158:	cmp	w22, #0xff
 101915c:	b.ls	1019140 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x140>  // b.plast
 1019160:	mov	w0, w22
 1019164:	add	w22, w22, w24
 1019168:	bl	1344060 <v8::internal::IsWhiteSpaceSlow(unsigned int)>
 101916c:	tst	w0, #0xff
 1019170:	b.ne	1019148 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x148>  // b.any
 1019174:	cmp	w22, #0x1
 1019178:	b.ls	1019148 <void v8::internal::NumberParseIntHelper::HandleGenericCase<unsigned short>(unsigned short const*, unsigned short const*)+0x148>  // b.plast
 101917c:	ldp	x23, x24, [sp, #48]
