
/tmp/pts-h36/node-arm64-dl/node-v24.21.0-linux-arm64/bin/node:     file format elf64-littleaarch64


Disassembly of section .text:

0000000002405de0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]>:
 2405de0:	sub	sp, sp, #0x2f0
 2405de4:	mov	w4, #0xaaab                	// #43691
 2405de8:	movk	w4, #0x2aaa, lsl #16
 2405dec:	mov	w5, w2
 2405df0:	stp	x29, x30, [sp]
 2405df4:	mov	x29, sp
 2405df8:	stp	x21, x22, [sp, #32]
 2405dfc:	sub	w21, w2, #0x3
 2405e00:	str	x1, [sp, #176]
 2405e04:	smull	x4, w21, w4
 2405e08:	stp	x19, x20, [sp, #16]
 2405e0c:	stp	x23, x24, [sp, #48]
 2405e10:	sub	w24, w3, #0x1
 2405e14:	asr	x4, x4, #34
 2405e18:	sub	w2, w4, w21, asr #31
 2405e1c:	stp	x25, x26, [sp, #64]
 2405e20:	add	w1, w2, #0x1
 2405e24:	stp	x27, x28, [sp, #80]
 2405e28:	mov	x27, x0
 2405e2c:	sub	w1, w1, w1, lsl #2
 2405e30:	str	w3, [sp, #164]
 2405e34:	add	w0, w3, #0x3
 2405e38:	str	w2, [sp, #184]
 2405e3c:	add	w23, w5, w1, lsl #3
 2405e40:	stp	d8, d9, [sp, #96]
 2405e44:	subs	w2, w2, w24
 2405e48:	stp	d10, d11, [sp, #112]
 2405e4c:	stp	d12, d13, [sp, #128]
 2405e50:	b.pl	2406640 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x860>  // b.nfrst
 2405e54:	str	xzr, [sp, #432]
 2405e58:	cmn	w2, #0x1
 2405e5c:	b.eq	2405e7c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x9c>  // b.none
 2405e60:	cmp	w0, #0x1
 2405e64:	add	w3, w3, #0x2
 2405e68:	csinc	w3, w3, wzr, gt
 2405e6c:	mov	w2, #0x0                   	// #0
 2405e70:	mov	w1, #0x2                   	// #2
 2405e74:	str	xzr, [sp, #440]
 2405e78:	b	2405e98 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0xb8>
 2405e7c:	mov	w1, #0x1                   	// #1
 2405e80:	mov	w2, #0x0                   	// #0
 2405e84:	ldr	w3, [sp, #164]
 2405e88:	cmp	w0, w1
 2405e8c:	sub	w3, w3, w1
 2405e90:	add	w3, w3, #0x4
 2405e94:	csinc	w3, w3, wzr, ge	// ge = tcont
 2405e98:	sbfiz	x5, x2, #2, #32
 2405e9c:	adrp	x22, 5ff1000 <icudt78_dat+0x1f92120>
 2405ea0:	add	x4, x22, #0x8d0
 2405ea4:	add	x25, sp, #0x1b0
 2405ea8:	sbfiz	x6, x1, #3, #32
 2405eac:	str	x4, [sp, #168]
 2405eb0:	add	x7, x25, x6
 2405eb4:	ldr	q0, [x4, x5]
 2405eb8:	sxtl	v1.2d, v0.2s
 2405ebc:	sxtl2	v0.2d, v0.4s
 2405ec0:	scvtf	v1.2d, v1.2d
 2405ec4:	scvtf	v0.2d, v0.2d
 2405ec8:	str	q1, [x25, x6]
 2405ecc:	str	q0, [x7, #16]
 2405ed0:	cmp	w3, #0x4
 2405ed4:	b.eq	2405f30 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x150>  // b.none
 2405ed8:	add	w2, w2, #0x4
 2405edc:	add	w3, w1, #0x4
 2405ee0:	add	w5, w1, #0x5
 2405ee4:	sxtw	x2, w2
 2405ee8:	ldr	w6, [x4, x2, lsl #2]
 2405eec:	scvtf	d0, w6
 2405ef0:	str	d0, [x25, w3, sxtw #3]
 2405ef4:	cmp	w0, w5
 2405ef8:	b.lt	2405f30 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x150>  // b.tstop
 2405efc:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 2405f00:	add	x3, x3, #0x8d4
 2405f04:	add	w1, w1, #0x6
 2405f08:	ldr	w3, [x3, x2, lsl #2]
 2405f0c:	scvtf	d0, w3
 2405f10:	str	d0, [x25, w5, sxtw #3]
 2405f14:	cmp	w0, w1
 2405f18:	b.lt	2405f30 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x150>  // b.tstop
 2405f1c:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 2405f20:	add	x3, x3, #0x8d8
 2405f24:	ldr	w2, [x3, x2, lsl #2]
 2405f28:	scvtf	d0, w2
 2405f2c:	str	d0, [x25, w1, sxtw #3]
 2405f30:	ldr	w1, [sp, #164]
 2405f34:	mov	x2, #0xfffffffffffffff8    	// #-8
 2405f38:	movi	v0.2d, #0x0
 2405f3c:	ldr	d11, [x27]
 2405f40:	add	x2, x2, w1, sxtw #3
 2405f44:	dup	v4.2d, v11.d[0]
 2405f48:	add	x1, x25, x2
 2405f4c:	mov	v1.16b, v0.16b
 2405f50:	ldr	q2, [x25, x2]
 2405f54:	fmla	v1.2d, v2.2d, v11.d[0]
 2405f58:	cbz	w24, 24066b8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x8d8>
 2405f5c:	ldur	q2, [x1, #-8]
 2405f60:	mov	v0.16b, v1.16b
 2405f64:	ldr	d3, [x27, #8]
 2405f68:	dup	v1.2d, v3.d[0]
 2405f6c:	fmla	v0.2d, v2.2d, v3.d[0]
 2405f70:	cmp	w24, #0x2
 2405f74:	b.ne	2405f84 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x1a4>  // b.any
 2405f78:	ldur	q2, [x1, #-16]
 2405f7c:	ldr	d5, [x27, #16]
 2405f80:	fmla	v0.2d, v2.2d, v5.d[0]
 2405f84:	ldr	q5, [x1, #16]
 2405f88:	str	q0, [sp, #272]
 2405f8c:	movi	v2.2d, #0x0
 2405f90:	ldur	q0, [x1, #8]
 2405f94:	fmla	v2.2d, v5.2d, v4.2d
 2405f98:	fmla	v2.2d, v0.2d, v1.2d
 2405f9c:	cmp	w24, #0x2
 2405fa0:	b.ne	2405fb0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x1d0>  // b.any
 2405fa4:	ldr	q0, [x25, x2]
 2405fa8:	ldr	d1, [x27, #16]
 2405fac:	fmla	v2.2d, v0.2d, v1.d[0]
 2405fb0:	ldr	d1, [x25, w0, sxtw #3]
 2405fb4:	movi	d0, #0x0
 2405fb8:	ldr	w0, [sp, #164]
 2405fbc:	str	q2, [sp, #288]
 2405fc0:	add	w0, w0, #0x2
 2405fc4:	fmadd	d0, d1, d11, d0
 2405fc8:	ldr	d1, [x25, w0, sxtw #3]
 2405fcc:	fmadd	d0, d3, d1, d0
 2405fd0:	cmp	w24, #0x2
 2405fd4:	b.ne	2405fe4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x204>  // b.any
 2405fd8:	ldr	d1, [x27, #16]
 2405fdc:	ldr	d2, [sp, #464]
 2405fe0:	fmadd	d0, d2, d1, d0
 2405fe4:	add	x26, sp, #0x110
 2405fe8:	add	x28, sp, #0xc0
 2405fec:	mov	x1, #0x3e70000000000000    	// #4499096027743125504
 2405ff0:	mov	x0, #0x4170000000000000    	// #4715268809856909312
 2405ff4:	fmov	d13, x1
 2405ff8:	fmov	d12, x0
 2405ffc:	mov	w22, #0x4                   	// #4
 2406000:	fmov	d9, #1.250000000000000000e-01
 2406004:	fmov	d8, #8.000000000000000000e+00
 2406008:	str	d0, [sp, #304]
 240600c:	sxtw	x21, w22
 2406010:	sbfiz	x20, x22, #3, #32
 2406014:	sub	x0, x20, #0x8
 2406018:	mov	x6, x28
 240601c:	add	x0, x26, x0
 2406020:	mov	x1, x28
 2406024:	ldr	d0, [x26, x21, lsl #3]
 2406028:	mov	w19, w22
 240602c:	nop
 2406030:	fmul	d1, d0, d13
 2406034:	ldr	d3, [x0], #-8
 2406038:	subs	w19, w19, #0x1
 240603c:	fcvtzs	w2, d1
 2406040:	scvtf	d1, w2
 2406044:	fmsub	d2, d1, d12, d0
 2406048:	fadd	d0, d1, d3
 240604c:	fcvtzs	w2, d2
 2406050:	str	w2, [x1], #4
 2406054:	b.ne	2406030 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x250>  // b.any
 2406058:	mov	w0, w23
 240605c:	str	x6, [sp, #152]
 2406060:	bl	744f40 <scalbn@plt>
 2406064:	fmul	d1, d0, d9
 2406068:	ldr	x6, [sp, #152]
 240606c:	cmp	w23, #0x0
 2406070:	frintm	d1, d1
 2406074:	fmsub	d0, d1, d8, d0
 2406078:	fcvtzs	w8, d0
 240607c:	scvtf	d1, w8
 2406080:	fsub	d10, d0, d1
 2406084:	b.le	24062a4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4c4>
 2406088:	sub	w0, w22, #0x1
 240608c:	mov	w9, #0x18                  	// #24
 2406090:	sub	w9, w9, w23
 2406094:	mov	w10, #0x17                  	// #23
 2406098:	sxtw	x0, w0
 240609c:	sub	w10, w10, w23
 24060a0:	ldr	w1, [x28, x0, lsl #2]
 24060a4:	asr	w2, w1, w9
 24060a8:	add	w8, w8, w2
 24060ac:	lsl	w2, w2, w9
 24060b0:	sub	w1, w1, w2
 24060b4:	str	w1, [x28, x0, lsl #2]
 24060b8:	asr	w1, w1, w10
 24060bc:	cmp	w1, #0x0
 24060c0:	b.gt	24062bc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4dc>
 24060c4:	fcmp	d10, #0.0
 24060c8:	b.ne	2406370 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x590>  // b.any
 24060cc:	sub	w6, w22, #0x1
 24060d0:	mov	w0, w6
 24060d4:	cmp	w6, #0x3
 24060d8:	b.eq	24061e0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x400>  // b.none
 24060dc:	sub	w10, w22, #0x5
 24060e0:	sub	w2, w22, #0x4
 24060e4:	cmp	w10, #0x3
 24060e8:	b.ls	2406198 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3b8>  // b.plast
 24060ec:	mov	x0, #0xfffffffffffffff0    	// #-16
 24060f0:	adrp	x3, 36c7000 <vtable for v8::internal::(anonymous namespace)::TypedElementsAccessor<(v8::internal::ElementsKind)32, unsigned short>+0x150>
 24060f4:	add	x0, x0, w22, sxtw #2
 24060f8:	lsr	w7, w2, #2
 24060fc:	ldr	q4, [x3, #3904]
 2406100:	add	x9, x28, x0
 2406104:	ldr	q0, [x28, x0]
 2406108:	mov	v1.16b, v0.16b
 240610c:	tbl	v0.16b, {v0.16b-v1.16b}, v4.16b
 2406110:	cmp	w7, #0x1
 2406114:	b.eq	2406424 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x644>  // b.none
 2406118:	ldur	q2, [x9, #-16]
 240611c:	mov	v3.16b, v2.16b
 2406120:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
 2406124:	orr	v0.16b, v0.16b, v2.16b
 2406128:	cmp	w7, #0x2
 240612c:	b.eq	2406170 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x390>  // b.none
 2406130:	ldur	q2, [x9, #-32]
 2406134:	mov	v3.16b, v2.16b
 2406138:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
 240613c:	orr	v0.16b, v0.16b, v2.16b
 2406140:	cmp	w7, #0x3
 2406144:	b.eq	2406170 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x390>  // b.none
 2406148:	ldur	q2, [x9, #-48]
 240614c:	mov	v3.16b, v2.16b
 2406150:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
 2406154:	orr	v0.16b, v0.16b, v2.16b
 2406158:	cmp	w7, #0x4
 240615c:	b.eq	2406170 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x390>  // b.none
 2406160:	ldur	q2, [x9, #-64]
 2406164:	mov	v3.16b, v2.16b
 2406168:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
 240616c:	orr	v0.16b, v0.16b, v2.16b
 2406170:	movi	v1.4s, #0x0
 2406174:	ext	v2.16b, v0.16b, v1.16b, #8
 2406178:	orr	v2.16b, v2.16b, v0.16b
 240617c:	ext	v0.16b, v2.16b, v1.16b, #4
 2406180:	orr	v0.16b, v0.16b, v2.16b
 2406184:	fmov	w19, s0
 2406188:	tst	x2, #0x3
 240618c:	b.eq	24061dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3fc>  // b.none
 2406190:	and	w2, w2, #0xfffffffc
 2406194:	sub	w0, w6, w2
 2406198:	ldr	w2, [x28, w0, sxtw #2]
 240619c:	sub	w7, w0, #0x1
 24061a0:	orr	w19, w19, w2
 24061a4:	cmp	w0, #0x4
 24061a8:	b.eq	24061dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3fc>  // b.none
 24061ac:	ldr	w2, [x28, w7, sxtw #2]
 24061b0:	sub	w7, w0, #0x2
 24061b4:	orr	w19, w19, w2
 24061b8:	cmp	w0, #0x5
 24061bc:	b.eq	24061dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3fc>  // b.none
 24061c0:	ldr	w7, [x28, w7, sxtw #2]
 24061c4:	sub	w2, w0, #0x3
 24061c8:	orr	w19, w19, w7
 24061cc:	cmp	w0, #0x6
 24061d0:	b.eq	24061dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3fc>  // b.none
 24061d4:	ldr	w0, [x28, w2, sxtw #2]
 24061d8:	orr	w19, w19, w0
 24061dc:	cbnz	w19, 2406444 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x664>
 24061e0:	ldr	w0, [sp, #204]
 24061e4:	cbnz	w0, 2406648 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x868>
 24061e8:	ldr	w0, [sp, #200]
 24061ec:	cbnz	w0, 2406630 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x850>
 24061f0:	ldr	w0, [sp, #196]
 24061f4:	cbnz	w0, 2406620 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x840>
 24061f8:	ldr	w2, [sp, #192]
 24061fc:	add	w1, w22, #0x1
 2406200:	add	w0, w22, #0x2
 2406204:	cmp	w2, #0x0
 2406208:	cset	w7, eq	// eq = none
 240620c:	add	w7, w7, w22
 2406210:	add	w7, w7, #0x4
 2406214:	ldr	x3, [sp, #168]
 2406218:	add	w1, w24, w1
 240621c:	ldr	w2, [sp, #184]
 2406220:	movi	d3, #0x0
 2406224:	sbfiz	x1, x1, #3, #32
 2406228:	sxtw	x0, w0
 240622c:	sub	x1, x1, x20
 2406230:	add	x8, x3, w2, sxtw #2
 2406234:	ldr	w2, [sp, #164]
 2406238:	sub	x1, x1, #0x10
 240623c:	sub	x8, x8, #0x4
 2406240:	add	x1, x25, x1
 2406244:	sub	w9, w2, #0x3
 2406248:	ldr	w2, [x8, x0, lsl #2]
 240624c:	sub	w6, w0, #0x1
 2406250:	add	w5, w9, w0
 2406254:	add	x3, x26, x0, lsl #3
 2406258:	scvtf	d0, w2
 240625c:	str	d0, [x1, x0, lsl #3]
 2406260:	add	x0, x0, #0x1
 2406264:	fmadd	d0, d0, d11, d3
 2406268:	sub	w2, w0, #0x1
 240626c:	cbz	w24, 2406290 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4b0>
 2406270:	ldr	d2, [x25, w5, sxtw #3]
 2406274:	ldr	d1, [x27, #8]
 2406278:	fmadd	d0, d2, d1, d0
 240627c:	cmp	w24, #0x2
 2406280:	b.ne	2406290 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4b0>  // b.any
 2406284:	ldr	d1, [x25, w6, sxtw #3]
 2406288:	ldr	d2, [x27, #16]
 240628c:	fmadd	d0, d2, d1, d0
 2406290:	stur	d0, [x3, #-8]
 2406294:	cmp	w7, w2
 2406298:	b.ge	2406248 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x468>  // b.tcont
 240629c:	mov	w22, w7
 24062a0:	b	240600c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x22c>
 24062a4:	b.ne	2406410 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x630>  // b.any
 24062a8:	sub	w0, w22, #0x1
 24062ac:	ldr	w1, [x28, w0, sxtw #2]
 24062b0:	asr	w1, w1, #23
 24062b4:	cmp	w1, #0x0
 24062b8:	b.le	24060c4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2e4>
 24062bc:	add	w8, w8, #0x1
 24062c0:	ldr	w0, [x28]
 24062c4:	add	x2, x28, x21, lsl #2
 24062c8:	mov	x9, x28
 24062cc:	nop
 24062d0:	cbz	w0, 24063d0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x5f0>
 24062d4:	mov	w10, #0x1000000             	// #16777216
 24062d8:	mov	w11, #0xffffff              	// #16777215
 24062dc:	sub	w0, w10, w0
 24062e0:	str	w0, [x9]
 24062e4:	b	24062f4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x514>
 24062e8:	ldr	w0, [x6]
 24062ec:	sub	w0, w11, w0
 24062f0:	str	w0, [x6]
 24062f4:	add	x6, x6, #0x4
 24062f8:	cmp	x6, x2
 24062fc:	b.ne	24062e8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x508>  // b.any
 2406300:	mov	w0, #0x1                   	// #1
 2406304:	cmp	w23, #0x0
 2406308:	b.le	2406658 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x878>
 240630c:	cmp	w23, #0x1
 2406310:	b.eq	24063f8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x618>  // b.none
 2406314:	cmp	w23, #0x2
 2406318:	b.ne	2406330 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x550>  // b.any
 240631c:	sub	w2, w22, #0x1
 2406320:	sxtw	x2, w2
 2406324:	ldr	w6, [x28, x2, lsl #2]
 2406328:	and	w6, w6, #0x3fffff
 240632c:	str	w6, [x28, x2, lsl #2]
 2406330:	cmp	w1, #0x2
 2406334:	b.ne	24060c4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2e4>  // b.any
 2406338:	fmov	d0, #1.000000000000000000e+00
 240633c:	fsub	d10, d0, d10
 2406340:	cbz	w0, 24060c4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2e4>
 2406344:	mov	w1, #0x2                   	// #2
 2406348:	fmov	d0, #1.000000000000000000e+00
 240634c:	mov	w0, w23
 2406350:	str	w1, [sp, #152]
 2406354:	str	w8, [sp, #188]
 2406358:	bl	744f40 <scalbn@plt>
 240635c:	fsub	d10, d10, d0
 2406360:	ldr	w1, [sp, #152]
 2406364:	ldr	w8, [sp, #188]
 2406368:	fcmp	d10, #0.0
 240636c:	b.eq	24060cc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2ec>  // b.none
 2406370:	fmov	d0, d10
 2406374:	neg	w0, w23
 2406378:	str	w1, [sp, #152]
 240637c:	str	w8, [sp, #164]
 2406380:	bl	744f40 <scalbn@plt>
 2406384:	fmov	d1, d0
 2406388:	mov	x0, #0x4170000000000000    	// #4715268809856909312
 240638c:	fmov	d3, x0
 2406390:	ldr	w1, [sp, #152]
 2406394:	fcmpe	d0, d3
 2406398:	ldr	w8, [sp, #164]
 240639c:	b.ge	240666c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x88c>  // b.tcont
 24063a0:	fcvtzs	w2, d0
 24063a4:	fmov	d0, #1.000000000000000000e+00
 24063a8:	mov	w0, w23
 24063ac:	str	w1, [sp, #152]
 24063b0:	str	w8, [sp, #164]
 24063b4:	mov	w19, w22
 24063b8:	str	w2, [x28, x21, lsl #2]
 24063bc:	bl	744f40 <scalbn@plt>
 24063c0:	ldr	w1, [sp, #152]
 24063c4:	fmov	d1, d0
 24063c8:	ldr	w8, [sp, #164]
 24063cc:	b	240648c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x6ac>
 24063d0:	add	x6, x6, #0x4
 24063d4:	cmp	x6, x2
 24063d8:	b.eq	24063e8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x608>  // b.none
 24063dc:	ldr	w0, [x6]
 24063e0:	mov	x9, x6
 24063e4:	b	24062d0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4f0>
 24063e8:	cmp	w23, #0x0
 24063ec:	b.le	2406330 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x550>
 24063f0:	cmp	w23, #0x1
 24063f4:	b.ne	2406314 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x534>  // b.any
 24063f8:	sub	w2, w22, #0x1
 24063fc:	sxtw	x2, w2
 2406400:	ldr	w6, [x28, x2, lsl #2]
 2406404:	and	w6, w6, #0x7fffff
 2406408:	str	w6, [x28, x2, lsl #2]
 240640c:	b	2406330 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x550>
 2406410:	fmov	d0, #5.000000000000000000e-01
 2406414:	fcmpe	d10, d0
 2406418:	b.ge	2406614 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x834>  // b.tcont
 240641c:	mov	w1, #0x0                   	// #0
 2406420:	b	24060c4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2e4>
 2406424:	movi	v1.4s, #0x0
 2406428:	mov	w0, w10
 240642c:	ext	v2.16b, v0.16b, v1.16b, #8
 2406430:	orr	v2.16b, v2.16b, v0.16b
 2406434:	ext	v0.16b, v2.16b, v1.16b, #4
 2406438:	orr	v0.16b, v0.16b, v2.16b
 240643c:	fmov	w19, s0
 2406440:	b	2406198 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x3b8>
 2406444:	ldr	w3, [x28, w6, sxtw #2]
 2406448:	add	x2, x28, w22, sxtw #2
 240644c:	mov	w19, w6
 2406450:	sub	x2, x2, #0x8
 2406454:	sub	w0, w23, #0x18
 2406458:	cbnz	w3, 2406708 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x928>
 240645c:	ldr	w3, [x2], #-4
 2406460:	sub	w19, w19, #0x1
 2406464:	sub	w0, w0, #0x18
 2406468:	cbz	w3, 240645c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x67c>
 240646c:	fmov	d0, #1.000000000000000000e+00
 2406470:	str	w1, [sp, #152]
 2406474:	str	w8, [sp, #164]
 2406478:	bl	744f40 <scalbn@plt>
 240647c:	fmov	d1, d0
 2406480:	ldr	w1, [sp, #152]
 2406484:	ldr	w8, [sp, #164]
 2406488:	tbnz	w19, #31, 24066d8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x8f8>
 240648c:	sub	w10, w19, #0x1
 2406490:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
 2406494:	fmov	d2, x0
 2406498:	sxtw	x10, w10
 240649c:	mov	x0, x10
 24064a0:	add	x3, x28, x0, lsl #2
 24064a4:	add	x2, x26, x0, lsl #3
 24064a8:	sub	x0, x0, #0x1
 24064ac:	ldr	w3, [x3, #4]
 24064b0:	scvtf	d0, w3
 24064b4:	fmul	d0, d0, d1
 24064b8:	fmul	d1, d1, d2
 24064bc:	str	d0, [x2, #8]
 24064c0:	cmn	w0, #0x1
 24064c4:	b.pl	24064a0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x6c0>  // b.nfrst
 24064c8:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 24064cc:	mov	x0, #0x442d00000000        	// #74960064217088
 24064d0:	movk	x0, #0x3e74, lsl #48
 24064d4:	movi	d2, #0x0
 24064d8:	ldr	d3, [x3, #2520]
 24064dc:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 24064e0:	fmov	d4, x0
 24064e4:	add	x5, sp, #0x250
 24064e8:	ldr	d5, [x3, #2528]
 24064ec:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 24064f0:	mov	x2, x10
 24064f4:	mov	w0, #0x0                   	// #0
 24064f8:	ldr	d7, [x3, #2536]
 24064fc:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 2406500:	ldr	d6, [x3, #2544]
 2406504:	b	240650c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x72c>
 2406508:	mov	w0, w3
 240650c:	add	x4, x26, x2, lsl #3
 2406510:	add	w7, w2, #0x2
 2406514:	add	w6, w2, #0x3
 2406518:	add	w9, w2, #0x4
 240651c:	add	w3, w2, #0x5
 2406520:	ldr	d0, [x4, #8]
 2406524:	fmadd	d0, d0, d3, d2
 2406528:	cbz	w0, 2406564 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x784>
 240652c:	ldr	d1, [x26, w7, sxtw #3]
 2406530:	fmadd	d0, d1, d4, d0
 2406534:	cmp	w0, #0x1
 2406538:	b.eq	2406564 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x784>  // b.none
 240653c:	ldr	d1, [x26, w6, sxtw #3]
 2406540:	fmadd	d0, d1, d5, d0
 2406544:	cmp	w0, #0x2
 2406548:	b.eq	2406564 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x784>  // b.none
 240654c:	ldr	d1, [x26, w9, sxtw #3]
 2406550:	fmadd	d0, d1, d7, d0
 2406554:	cmp	w0, #0x3
 2406558:	b.eq	2406564 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x784>  // b.none
 240655c:	ldr	d1, [x26, w3, sxtw #3]
 2406560:	fmadd	d0, d1, d6, d0
 2406564:	str	d0, [x5], #8
 2406568:	sub	x2, x2, #0x1
 240656c:	add	w3, w0, #0x1
 2406570:	cmp	w19, w0
 2406574:	b.ne	2406508 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x728>  // b.any
 2406578:	movi	d1, #0x0
 240657c:	mov	x2, #0xfffffffffffffffe    	// #-2
 2406580:	add	x0, sp, #0x250
 2406584:	add	x0, x0, x10, lsl #3
 2406588:	sub	x10, x10, #0x1
 240658c:	ldr	d0, [x0, #8]
 2406590:	fadd	d1, d1, d0
 2406594:	cmp	x10, x2
 2406598:	b.ne	2406580 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7a0>  // b.any
 240659c:	ldr	d0, [sp, #592]
 24065a0:	cbz	w1, 24066f4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x914>
 24065a4:	ldr	x0, [sp, #176]
 24065a8:	fneg	d2, d1
 24065ac:	fsub	d0, d0, d1
 24065b0:	str	d2, [x0]
 24065b4:	cbz	w19, 24065d8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7f8>
 24065b8:	add	x2, sp, #0x258
 24065bc:	mov	w0, #0x1                   	// #1
 24065c0:	ldr	d1, [x2], #8
 24065c4:	add	w0, w0, #0x1
 24065c8:	fadd	d0, d0, d1
 24065cc:	cmp	w0, w19
 24065d0:	b.le	24065c0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7e0>
 24065d4:	cbz	w1, 24065dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7fc>
 24065d8:	fneg	d0, d0
 24065dc:	ldr	x1, [sp, #176]
 24065e0:	and	w0, w8, #0x7
 24065e4:	str	d0, [x1, #8]
 24065e8:	ldp	x29, x30, [sp]
 24065ec:	ldp	x19, x20, [sp, #16]
 24065f0:	ldp	x21, x22, [sp, #32]
 24065f4:	ldp	x23, x24, [sp, #48]
 24065f8:	ldp	x25, x26, [sp, #64]
 24065fc:	ldp	x27, x28, [sp, #80]
 2406600:	ldp	d8, d9, [sp, #96]
 2406604:	ldp	d10, d11, [sp, #112]
 2406608:	ldp	d12, d13, [sp, #128]
 240660c:	add	sp, sp, #0x2f0
 2406610:	ret
 2406614:	add	w8, w8, #0x1
 2406618:	mov	w1, #0x2                   	// #2
 240661c:	b	24062c0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x4e0>
 2406620:	add	w1, w22, #0x1
 2406624:	add	w7, w22, #0x3
 2406628:	add	w0, w22, #0x2
 240662c:	b	2406214 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x434>
 2406630:	add	w0, w22, #0x2
 2406634:	add	w1, w22, #0x1
 2406638:	mov	w7, w0
 240663c:	b	2406214 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x434>
 2406640:	mov	w1, #0x0                   	// #0
 2406644:	b	2405e84 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0xa4>
 2406648:	add	w1, w22, #0x1
 240664c:	add	w0, w22, #0x2
 2406650:	mov	w7, w1
 2406654:	b	2406214 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x434>
 2406658:	cmp	w1, #0x2
 240665c:	b.ne	24060c4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x2e4>  // b.any
 2406660:	fmov	d0, #1.000000000000000000e+00
 2406664:	fsub	d10, d0, d10
 2406668:	b	2406344 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x564>
 240666c:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
 2406670:	fmov	d2, x0
 2406674:	add	w19, w22, #0x1
 2406678:	fmov	d0, #1.000000000000000000e+00
 240667c:	fmul	d2, d1, d2
 2406680:	add	w0, w23, #0x18
 2406684:	str	w1, [sp, #152]
 2406688:	str	w8, [sp, #164]
 240668c:	fcvtzs	w2, d2
 2406690:	scvtf	d2, w2
 2406694:	fmsub	d1, d2, d3, d1
 2406698:	fcvtzs	w3, d1
 240669c:	str	w3, [x28, x21, lsl #2]
 24066a0:	str	w2, [x28, w19, sxtw #2]
 24066a4:	bl	744f40 <scalbn@plt>
 24066a8:	ldr	w1, [sp, #152]
 24066ac:	fmov	d1, d0
 24066b0:	ldr	w8, [sp, #164]
 24066b4:	b	240648c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x6ac>
 24066b8:	ldr	q3, [x1, #16]
 24066bc:	str	q1, [sp, #272]
 24066c0:	ldr	d2, [sp, #464]
 24066c4:	mov	v1.16b, v0.16b
 24066c8:	fmadd	d0, d2, d11, d0
 24066cc:	fmla	v1.2d, v3.2d, v4.2d
 24066d0:	str	q1, [sp, #288]
 24066d4:	b	2405fe4 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x204>
 24066d8:	ldr	d0, [sp, #592]
 24066dc:	cbz	w1, 2406728 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x948>
 24066e0:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
 24066e4:	fmov	d1, x0
 24066e8:	ldr	x0, [sp, #176]
 24066ec:	str	d1, [x0]
 24066f0:	b	24065d8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7f8>
 24066f4:	ldr	x0, [sp, #176]
 24066f8:	fsub	d0, d0, d1
 24066fc:	str	d1, [x0]
 2406700:	cbnz	w19, 24065b8 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7d8>
 2406704:	b	24065dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7fc>
 2406708:	fmov	d0, #1.000000000000000000e+00
 240670c:	str	w1, [sp, #152]
 2406710:	str	w8, [sp, #164]
 2406714:	bl	744f40 <scalbn@plt>
 2406718:	fmov	d1, d0
 240671c:	ldr	w1, [sp, #152]
 2406720:	ldr	w8, [sp, #164]
 2406724:	b	240648c <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x6ac>
 2406728:	ldr	x0, [sp, #176]
 240672c:	str	xzr, [x0]
 2406730:	b	24065dc <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]+0x7fc>
 2406734:	nop
 2406738:	nop
 240673c:	nop

0000000002406740 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)>:
 2406740:	fmov	x4, d0
 2406744:	stp	x29, x30, [sp, #-64]!
 2406748:	mov	x29, sp
 240674c:	stp	x19, x20, [sp, #16]
 2406750:	mov	x19, x0
 2406754:	ubfx	x5, x4, #32, #31
 2406758:	mov	w0, #0x21fb                	// #8699
 240675c:	movk	w0, #0x3fe9, lsl #16
 2406760:	cmp	w5, w0
 2406764:	b.le	2406864 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x124>
 2406768:	mov	w0, #0xd97b                	// #55675
 240676c:	lsr	x20, x4, #32
 2406770:	movk	w0, #0x4002, lsl #16
 2406774:	cmp	w5, w0
 2406778:	b.gt	24067c8 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x88>
 240677c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406780:	ldr	d1, [x0, #2552]
 2406784:	mov	w0, #0x21fb                	// #8699
 2406788:	movk	w0, #0x3ff9, lsl #16
 240678c:	cmp	w20, #0x0
 2406790:	b.le	24069b0 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x270>
 2406794:	fsub	d0, d0, d1
 2406798:	cmp	w5, w0
 240679c:	b.eq	240695c <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x21c>  // b.none
 24067a0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24067a4:	ldr	d2, [x0, #2560]
 24067a8:	fsub	d1, d0, d2
 24067ac:	fsub	d0, d0, d1
 24067b0:	fsub	d0, d0, d2
 24067b4:	mov	w0, #0x1                   	// #1
 24067b8:	stp	d1, d0, [x19]
 24067bc:	ldp	x19, x20, [sp, #16]
 24067c0:	ldp	x29, x30, [sp], #64
 24067c4:	ret
 24067c8:	mov	w0, #0x21fb                	// #8699
 24067cc:	movk	w0, #0x4139, lsl #16
 24067d0:	cmp	w5, w0
 24067d4:	b.le	2406874 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x134>
 24067d8:	mov	w0, #0x7fefffff            	// #2146435071
 24067dc:	cmp	w5, w0
 24067e0:	b.gt	2406994 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x254>
 24067e4:	asr	w2, w5, #20
 24067e8:	mov	x0, #0x4170000000000000    	// #4715268809856909312
 24067ec:	sub	w2, w2, #0x416
 24067f0:	fmov	d1, x0
 24067f4:	mov	w3, #0x3                   	// #3
 24067f8:	sub	w5, w5, w2, lsl #20
 24067fc:	bfi	x4, x5, #32, #32
 2406800:	fmov	d0, x4
 2406804:	fcvtzs	w0, d0
 2406808:	scvtf	d2, w0
 240680c:	fsub	d0, d0, d2
 2406810:	str	d2, [sp, #40]
 2406814:	fmul	d0, d0, d1
 2406818:	fcvtzs	w0, d0
 240681c:	scvtf	d2, w0
 2406820:	fsub	d0, d0, d2
 2406824:	fmul	d0, d0, d1
 2406828:	fcmp	d0, #0.0
 240682c:	stp	d2, d0, [sp, #48]
 2406830:	b.ne	2406840 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x100>  // b.any
 2406834:	cmp	w0, #0x0
 2406838:	cset	w3, ne	// ne = any
 240683c:	add	w3, w3, #0x1
 2406840:	mov	x1, x19
 2406844:	add	x0, sp, #0x28
 2406848:	bl	2405de0 <v8::base::ieee754::(anonymous namespace)::__kernel_rem_pio2(double*, double*, int, int, int, int const*) [clone .constprop.0]>
 240684c:	tbz	w20, #31, 24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 2406850:	ldr	q0, [x19]
 2406854:	neg	w0, w0
 2406858:	fneg	v0.2d, v0.2d
 240685c:	str	q0, [x19]
 2406860:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 2406864:	mov	w0, #0x0                   	// #0
 2406868:	str	d0, [x19]
 240686c:	str	xzr, [x19, #8]
 2406870:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 2406874:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406878:	fabs	d0, d0
 240687c:	fmov	d2, #5.000000000000000000e-01
 2406880:	ldr	d3, [x0, #2584]
 2406884:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406888:	ldr	d4, [x0, #2552]
 240688c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406890:	fmadd	d2, d0, d3, d2
 2406894:	ldr	d1, [x0, #2560]
 2406898:	fcvtzs	w0, d2
 240689c:	scvtf	d3, w0
 24068a0:	fmsub	d0, d3, d4, d0
 24068a4:	fmul	d1, d3, d1
 24068a8:	fsub	d2, d0, d1
 24068ac:	cmp	w0, #0x1f
 24068b0:	b.gt	24068e4 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x1a4>
 24068b4:	sub	w2, w0, #0x1
 24068b8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24068bc:	add	x1, x1, #0x850
 24068c0:	ldr	w1, [x1, w2, sxtw #2]
 24068c4:	cmp	w1, w5
 24068c8:	b.eq	24068e4 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x1a4>  // b.none
 24068cc:	str	d2, [x19]
 24068d0:	fsub	d0, d0, d2
 24068d4:	fsub	d0, d0, d1
 24068d8:	tbnz	w20, #31, 2406980 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x240>
 24068dc:	str	d0, [x19, #8]
 24068e0:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 24068e4:	fmov	x1, d2
 24068e8:	asr	w5, w5, #20
 24068ec:	ubfx	x1, x1, #52, #11
 24068f0:	sub	w1, w5, w1
 24068f4:	cmp	w1, #0x10
 24068f8:	b.le	24068cc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x18c>
 24068fc:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2406900:	ldr	d2, [x1, #2568]
 2406904:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2406908:	ldr	d1, [x1, #2576]
 240690c:	fmsub	d4, d3, d2, d0
 2406910:	fsub	d0, d0, d4
 2406914:	fmsub	d0, d3, d2, d0
 2406918:	fnmsub	d1, d3, d1, d0
 240691c:	fsub	d2, d4, d1
 2406920:	fmov	x1, d2
 2406924:	ubfx	x1, x1, #52, #11
 2406928:	sub	w5, w5, w1
 240692c:	cmp	w5, #0x31
 2406930:	b.le	24069a4 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x264>
 2406934:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2406938:	ldr	d2, [x1, #2592]
 240693c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2406940:	ldr	d1, [x1, #2600]
 2406944:	fmsub	d0, d3, d2, d4
 2406948:	fsub	d4, d4, d0
 240694c:	fmsub	d4, d3, d2, d4
 2406950:	fnmsub	d1, d3, d1, d4
 2406954:	fsub	d2, d0, d1
 2406958:	b	24068cc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x18c>
 240695c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406960:	ldr	d1, [x0, #2568]
 2406964:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406968:	ldr	d2, [x0, #2576]
 240696c:	fsub	d0, d0, d1
 2406970:	fsub	d1, d0, d2
 2406974:	fsub	d0, d0, d1
 2406978:	fsub	d0, d0, d2
 240697c:	b	24067b4 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x74>
 2406980:	mov	v2.d[1], v0.d[0]
 2406984:	neg	w0, w0
 2406988:	fneg	v2.2d, v2.2d
 240698c:	str	q2, [x19]
 2406990:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 2406994:	fsub	d0, d0, d0
 2406998:	mov	w0, #0x0                   	// #0
 240699c:	stp	d0, d0, [x19]
 24069a0:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 24069a4:	fmov	d0, d4
 24069a8:	str	d2, [x19]
 24069ac:	b	24068d0 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x190>
 24069b0:	fadd	d0, d0, d1
 24069b4:	cmp	w5, w0
 24069b8:	b.eq	24069dc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x29c>  // b.none
 24069bc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24069c0:	ldr	d2, [x0, #2560]
 24069c4:	fadd	d1, d0, d2
 24069c8:	fsub	d0, d0, d1
 24069cc:	fadd	d0, d0, d2
 24069d0:	mov	w0, #0xffffffff            	// #-1
 24069d4:	stp	d1, d0, [x19]
 24069d8:	b	24067bc <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x7c>
 24069dc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24069e0:	ldr	d1, [x0, #2568]
 24069e4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24069e8:	ldr	d2, [x0, #2576]
 24069ec:	fadd	d0, d0, d1
 24069f0:	fadd	d1, d0, d2
 24069f4:	fsub	d0, d0, d1
 24069f8:	fadd	d0, d0, d2
 24069fc:	b	24069d0 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)+0x290>

0000000002406a00 <v8::base::ieee754::acos(double)>:
 2406a00:	fmov	x1, d0
 2406a04:	mov	w2, #0x3fefffff            	// #1072693247
 2406a08:	ubfx	x0, x1, #32, #31
 2406a0c:	lsr	x3, x1, #32
 2406a10:	cmp	w0, w2
 2406a14:	b.le	2406a40 <v8::base::ieee754::acos(double)+0x40>
 2406a18:	mov	w2, #0xc0100000            	// #-1072693248
 2406a1c:	add	w0, w0, w2
 2406a20:	orr	w0, w0, w1
 2406a24:	cbnz	w0, 2406aa0 <v8::base::ieee754::acos(double)+0xa0>
 2406a28:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2406a2c:	movi	d1, #0x0
 2406a30:	cmp	w3, #0x0
 2406a34:	ldr	d0, [x0, #4056]
 2406a38:	fcsel	d0, d0, d1, le
 2406a3c:	ret
 2406a40:	stp	x29, x30, [sp, #-48]!
 2406a44:	mov	w1, #0x3fdfffff            	// #1071644671
 2406a48:	mov	x29, sp
 2406a4c:	cmp	w0, w1
 2406a50:	b.gt	2406a70 <v8::base::ieee754::acos(double)+0x70>
 2406a54:	mov	w1, #0x3c600000            	// #1012924416
 2406a58:	cmp	w0, w1
 2406a5c:	b.gt	2406b60 <v8::base::ieee754::acos(double)+0x160>
 2406a60:	adrp	x0, 3fe1000 <yy_action+0x1040>
 2406a64:	ldr	d0, [x0, #688]
 2406a68:	ldp	x29, x30, [sp], #48
 2406a6c:	ret
 2406a70:	stp	d8, d9, [sp, #16]
 2406a74:	tbnz	w3, #31, 2406c14 <v8::base::ieee754::acos(double)+0x214>
 2406a78:	fmov	d8, #1.000000000000000000e+00
 2406a7c:	fmov	d1, #5.000000000000000000e-01
 2406a80:	fsub	d8, d8, d0
 2406a84:	fmul	d8, d8, d1
 2406a88:	fcmp	d8, #0.0
 2406a8c:	b.pl	2406aac <v8::base::ieee754::acos(double)+0xac>  // b.nfrst
 2406a90:	fmov	d0, d8
 2406a94:	bl	743a70 <sqrt@plt>
 2406a98:	fmov	d3, d0
 2406a9c:	b	2406ab0 <v8::base::ieee754::acos(double)+0xb0>
 2406aa0:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2406aa4:	fmov	d0, x0
 2406aa8:	ret
 2406aac:	fsqrt	d3, d8
 2406ab0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ab4:	fmov	d4, #1.000000000000000000e+00
 2406ab8:	ldr	d1, [x0, #2608]
 2406abc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ac0:	ldr	d19, [x0, #2616]
 2406ac4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ac8:	fmadd	d19, d8, d1, d19
 2406acc:	ldr	d17, [x0, #2624]
 2406ad0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ad4:	ldr	d0, [x0, #2632]
 2406ad8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406adc:	ldr	d18, [x0, #2640]
 2406ae0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ae4:	fmadd	d18, d8, d0, d18
 2406ae8:	movi	v0.2d, #0xffffffff00000000
 2406aec:	ldr	d7, [x0, #2648]
 2406af0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406af4:	fmadd	d17, d19, d8, d17
 2406af8:	ldr	d16, [x0, #2656]
 2406afc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b00:	and	v2.8b, v3.8b, v0.8b
 2406b04:	ldr	d5, [x0, #2664]
 2406b08:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b0c:	ldr	d6, [x0, #2672]
 2406b10:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2406b14:	fmadd	d16, d18, d8, d16
 2406b18:	movk	x0, #0x3fc5, lsl #48
 2406b1c:	fmov	d1, x0
 2406b20:	fmsub	d0, d2, d2, d8
 2406b24:	fmadd	d7, d17, d8, d7
 2406b28:	fadd	d9, d2, d3
 2406b2c:	fmadd	d6, d16, d8, d6
 2406b30:	fdiv	d0, d0, d9
 2406b34:	fmadd	d5, d7, d8, d5
 2406b38:	fmadd	d4, d6, d8, d4
 2406b3c:	fmadd	d1, d5, d8, d1
 2406b40:	fmul	d1, d1, d8
 2406b44:	ldp	d8, d9, [sp, #16]
 2406b48:	ldp	x29, x30, [sp], #48
 2406b4c:	fdiv	d1, d1, d4
 2406b50:	fmadd	d0, d1, d3, d0
 2406b54:	fadd	d0, d0, d2
 2406b58:	fadd	d0, d0, d0
 2406b5c:	ret
 2406b60:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b64:	fmul	d2, d0, d0
 2406b68:	stp	d8, d9, [sp, #16]
 2406b6c:	fmov	d5, #1.000000000000000000e+00
 2406b70:	ldr	d3, [x0, #2608]
 2406b74:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b78:	ldr	d18, [x0, #2616]
 2406b7c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b80:	fmadd	d18, d2, d3, d18
 2406b84:	ldr	d16, [x0, #2624]
 2406b88:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b8c:	ldr	d1, [x0, #2632]
 2406b90:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b94:	ldr	d17, [x0, #2640]
 2406b98:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406b9c:	fmadd	d17, d2, d1, d17
 2406ba0:	ldr	d8, [x0, #2648]
 2406ba4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ba8:	fmadd	d16, d18, d2, d16
 2406bac:	ldr	d9, [x0, #2656]
 2406bb0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406bb4:	ldr	d6, [x0, #2664]
 2406bb8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406bbc:	ldr	d7, [x0, #2672]
 2406bc0:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2406bc4:	fmadd	d9, d17, d2, d9
 2406bc8:	movk	x0, #0x3fc5, lsl #48
 2406bcc:	fmov	d3, x0
 2406bd0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406bd4:	fmadd	d8, d16, d2, d8
 2406bd8:	ldr	d4, [x0, #2680]
 2406bdc:	adrp	x0, 3fe1000 <yy_action+0x1040>
 2406be0:	ldr	d1, [x0, #688]
 2406be4:	fmadd	d7, d9, d2, d7
 2406be8:	fmadd	d6, d8, d2, d6
 2406bec:	ldp	d8, d9, [sp, #16]
 2406bf0:	ldp	x29, x30, [sp], #48
 2406bf4:	fmadd	d5, d7, d2, d5
 2406bf8:	fmadd	d3, d6, d2, d3
 2406bfc:	fmul	d2, d3, d2
 2406c00:	fdiv	d2, d2, d5
 2406c04:	fmsub	d2, d2, d0, d4
 2406c08:	fsub	d0, d0, d2
 2406c0c:	fsub	d0, d1, d0
 2406c10:	ret
 2406c14:	fmov	d1, #1.000000000000000000e+00
 2406c18:	fmov	d3, #5.000000000000000000e-01
 2406c1c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c20:	fadd	d0, d0, d1
 2406c24:	ldr	d17, [x0, #2608]
 2406c28:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c2c:	ldr	d9, [x0, #2616]
 2406c30:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c34:	fmul	d0, d0, d3
 2406c38:	ldr	d6, [x0, #2624]
 2406c3c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c40:	ldr	d16, [x0, #2632]
 2406c44:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c48:	fmadd	d9, d0, d17, d9
 2406c4c:	fcmp	d0, #0.0
 2406c50:	ldr	d4, [x0, #2648]
 2406c54:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c58:	ldr	d7, [x0, #2640]
 2406c5c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c60:	fmadd	d7, d0, d16, d7
 2406c64:	ldr	d2, [x0, #2664]
 2406c68:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c6c:	ldr	d5, [x0, #2656]
 2406c70:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2406c74:	fmadd	d6, d9, d0, d6
 2406c78:	movk	x0, #0x3fc5, lsl #48
 2406c7c:	fmov	d8, x0
 2406c80:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406c84:	ldr	d3, [x0, #2672]
 2406c88:	fmadd	d5, d7, d0, d5
 2406c8c:	fmadd	d4, d6, d0, d4
 2406c90:	fmadd	d3, d5, d0, d3
 2406c94:	fmadd	d2, d4, d0, d2
 2406c98:	fmadd	d3, d3, d0, d1
 2406c9c:	fmadd	d8, d2, d0, d8
 2406ca0:	fmul	d8, d8, d0
 2406ca4:	b.pl	2406cbc <v8::base::ieee754::acos(double)+0x2bc>  // b.nfrst
 2406ca8:	str	d3, [sp, #40]
 2406cac:	bl	743a70 <sqrt@plt>
 2406cb0:	ldr	d3, [sp, #40]
 2406cb4:	fmov	d1, d0
 2406cb8:	b	2406cc0 <v8::base::ieee754::acos(double)+0x2c0>
 2406cbc:	fsqrt	d1, d0
 2406cc0:	fdiv	d8, d8, d3
 2406cc4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406cc8:	fmov	d3, #2.000000000000000000e+00
 2406ccc:	ldr	d2, [x0, #2688]
 2406cd0:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2406cd4:	ldr	d0, [x0, #4056]
 2406cd8:	fmadd	d2, d8, d1, d2
 2406cdc:	ldp	d8, d9, [sp, #16]
 2406ce0:	ldp	x29, x30, [sp], #48
 2406ce4:	fadd	d1, d2, d1
 2406ce8:	fmsub	d0, d1, d3, d0
 2406cec:	ret

0000000002406cf0 <v8::base::ieee754::asin(double)>:
 2406cf0:	fmov	x0, d0
 2406cf4:	stp	x29, x30, [sp, #-64]!
 2406cf8:	fmov	d1, d0
 2406cfc:	mov	x29, sp
 2406d00:	stp	x19, x20, [sp, #16]
 2406d04:	mov	w1, #0x3fefffff            	// #1072693247
 2406d08:	ubfx	x19, x0, #32, #31
 2406d0c:	cmp	w19, w1
 2406d10:	b.le	2406d38 <v8::base::ieee754::asin(double)+0x48>
 2406d14:	mov	w1, #0xc0100000            	// #-1072693248
 2406d18:	add	w19, w19, w1
 2406d1c:	orr	w19, w19, w0
 2406d20:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2406d24:	fmov	d0, x0
 2406d28:	cbz	w19, 2406d80 <v8::base::ieee754::asin(double)+0x90>
 2406d2c:	ldp	x19, x20, [sp, #16]
 2406d30:	ldp	x29, x30, [sp], #64
 2406d34:	ret
 2406d38:	lsr	x20, x0, #32
 2406d3c:	mov	w0, #0x3fdfffff            	// #1071644671
 2406d40:	cmp	w19, w0
 2406d44:	b.gt	2406da4 <v8::base::ieee754::asin(double)+0xb4>
 2406d48:	mov	w0, #0x3e3fffff            	// #1044381695
 2406d4c:	cmp	w19, w0
 2406d50:	b.gt	2406eac <v8::base::ieee754::asin(double)+0x1bc>
 2406d54:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406d58:	fmov	d3, #1.000000000000000000e+00
 2406d5c:	ldr	d2, [x0, #2696]
 2406d60:	fadd	d2, d0, d2
 2406d64:	fcmpe	d2, d3
 2406d68:	b.gt	2406d2c <v8::base::ieee754::asin(double)+0x3c>
 2406d6c:	movi	d0, #0x0
 2406d70:	fmadd	d0, d1, d0, d1
 2406d74:	ldp	x19, x20, [sp, #16]
 2406d78:	ldp	x29, x30, [sp], #64
 2406d7c:	ret
 2406d80:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406d84:	ldp	x19, x20, [sp, #16]
 2406d88:	ldr	d0, [x0, #2680]
 2406d8c:	adrp	x0, 3fe1000 <yy_action+0x1040>
 2406d90:	ldr	d2, [x0, #688]
 2406d94:	fmul	d0, d1, d0
 2406d98:	ldp	x29, x30, [sp], #64
 2406d9c:	fmadd	d0, d1, d2, d0
 2406da0:	ret
 2406da4:	fabs	d1, d0
 2406da8:	fmov	d0, #1.000000000000000000e+00
 2406dac:	fmov	d18, #5.000000000000000000e-01
 2406db0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406db4:	stp	d8, d9, [sp, #32]
 2406db8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2406dbc:	ldr	d17, [x0, #2608]
 2406dc0:	fsub	d1, d0, d1
 2406dc4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406dc8:	ldr	d3, [x1, #2672]
 2406dcc:	ldr	d9, [x0, #2616]
 2406dd0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406dd4:	fmul	d1, d1, d18
 2406dd8:	ldr	d6, [x0, #2624]
 2406ddc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406de0:	ldr	d16, [x0, #2632]
 2406de4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406de8:	fmadd	d9, d1, d17, d9
 2406dec:	fcmp	d1, #0.0
 2406df0:	ldr	d4, [x0, #2648]
 2406df4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406df8:	ldr	d7, [x0, #2640]
 2406dfc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406e00:	fmadd	d7, d1, d16, d7
 2406e04:	ldr	d2, [x0, #2664]
 2406e08:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406e0c:	ldr	d5, [x0, #2656]
 2406e10:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2406e14:	fmadd	d6, d9, d1, d6
 2406e18:	movk	x0, #0x3fc5, lsl #48
 2406e1c:	fmov	d8, x0
 2406e20:	fmadd	d5, d7, d1, d5
 2406e24:	fmadd	d4, d6, d1, d4
 2406e28:	fmadd	d3, d5, d1, d3
 2406e2c:	fmadd	d2, d4, d1, d2
 2406e30:	fmadd	d3, d3, d1, d0
 2406e34:	fmadd	d8, d2, d1, d8
 2406e38:	fmul	d8, d8, d1
 2406e3c:	b.pl	2406e58 <v8::base::ieee754::asin(double)+0x168>  // b.nfrst
 2406e40:	fmov	d0, d1
 2406e44:	stp	d1, d3, [sp, #48]
 2406e48:	bl	743a70 <sqrt@plt>
 2406e4c:	fmov	d2, d0
 2406e50:	ldp	d1, d3, [sp, #48]
 2406e54:	b	2406e5c <v8::base::ieee754::asin(double)+0x16c>
 2406e58:	fsqrt	d2, d1
 2406e5c:	fdiv	d8, d8, d3
 2406e60:	mov	w0, #0x3332                	// #13106
 2406e64:	movk	w0, #0x3fef, lsl #16
 2406e68:	cmp	w19, w0
 2406e6c:	b.le	2406f44 <v8::base::ieee754::asin(double)+0x254>
 2406e70:	fmadd	d2, d2, d8, d2
 2406e74:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406e78:	fmov	d3, #2.000000000000000000e+00
 2406e7c:	ldr	d1, [x0, #2688]
 2406e80:	adrp	x0, 3fe1000 <yy_action+0x1040>
 2406e84:	ldr	d0, [x0, #688]
 2406e88:	fmadd	d1, d2, d3, d1
 2406e8c:	fsub	d0, d0, d1
 2406e90:	fneg	d1, d0
 2406e94:	cmp	w20, #0x0
 2406e98:	ldp	x19, x20, [sp, #16]
 2406e9c:	ldp	d8, d9, [sp, #32]
 2406ea0:	fcsel	d0, d1, d0, le
 2406ea4:	ldp	x29, x30, [sp], #64
 2406ea8:	ret
 2406eac:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406eb0:	fmul	d0, d0, d0
 2406eb4:	stp	d8, d9, [sp, #32]
 2406eb8:	ldr	d3, [x0, #2608]
 2406ebc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ec0:	ldr	d16, [x0, #2616]
 2406ec4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ec8:	fmadd	d16, d0, d3, d16
 2406ecc:	fmov	d3, #1.000000000000000000e+00
 2406ed0:	ldr	d8, [x0, #2624]
 2406ed4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ed8:	ldr	d2, [x0, #2632]
 2406edc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ee0:	ldr	d9, [x0, #2640]
 2406ee4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ee8:	fmadd	d9, d0, d2, d9
 2406eec:	ldr	d6, [x0, #2648]
 2406ef0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406ef4:	fmadd	d8, d0, d16, d8
 2406ef8:	ldr	d7, [x0, #2656]
 2406efc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406f00:	ldr	d4, [x0, #2664]
 2406f04:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406f08:	ldr	d5, [x0, #2672]
 2406f0c:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2406f10:	fmadd	d7, d0, d9, d7
 2406f14:	movk	x0, #0x3fc5, lsl #48
 2406f18:	fmov	d2, x0
 2406f1c:	fmadd	d6, d0, d8, d6
 2406f20:	ldp	d8, d9, [sp, #32]
 2406f24:	fmadd	d5, d0, d7, d5
 2406f28:	fmadd	d4, d0, d6, d4
 2406f2c:	fmadd	d3, d0, d5, d3
 2406f30:	fmadd	d2, d0, d4, d2
 2406f34:	fmul	d0, d0, d2
 2406f38:	fdiv	d0, d0, d3
 2406f3c:	fmadd	d0, d1, d0, d1
 2406f40:	b	2406d74 <v8::base::ieee754::asin(double)+0x84>
 2406f44:	movi	v0.2d, #0xffffffff00000000
 2406f48:	fadd	d6, d2, d2
 2406f4c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406f50:	fmov	d5, #2.000000000000000000e+00
 2406f54:	ldr	d3, [x0, #2680]
 2406f58:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406f5c:	and	v4.8b, v2.8b, v0.8b
 2406f60:	ldr	d0, [x0, #2704]
 2406f64:	fmsub	d1, d4, d4, d1
 2406f68:	fadd	d2, d4, d2
 2406f6c:	fmsub	d4, d4, d5, d0
 2406f70:	fdiv	d1, d1, d2
 2406f74:	fmsub	d1, d1, d5, d3
 2406f78:	fnmsub	d1, d6, d8, d1
 2406f7c:	fsub	d1, d1, d4
 2406f80:	fsub	d0, d0, d1
 2406f84:	b	2406e90 <v8::base::ieee754::asin(double)+0x1a0>
 2406f88:	nop
 2406f8c:	nop

0000000002406f90 <v8::base::ieee754::atan(double)>:
 2406f90:	fmov	x1, d0
 2406f94:	fmov	d1, d0
 2406f98:	mov	w2, #0x440fffff            	// #1141899263
 2406f9c:	ubfx	x0, x1, #32, #31
 2406fa0:	lsr	x3, x1, #32
 2406fa4:	cmp	w0, w2
 2406fa8:	b.le	2406ff0 <v8::base::ieee754::atan(double)+0x60>
 2406fac:	mov	w2, #0x7ff00000            	// #2146435072
 2406fb0:	cmp	w0, w2
 2406fb4:	b.gt	2406fe8 <v8::base::ieee754::atan(double)+0x58>
 2406fb8:	cmp	w1, #0x0
 2406fbc:	ccmp	w0, w2, #0x0, ne	// ne = any
 2406fc0:	b.eq	2406fe8 <v8::base::ieee754::atan(double)+0x58>  // b.none
 2406fc4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2406fc8:	add	x0, x0, #0x830
 2406fcc:	cmp	w3, #0x0
 2406fd0:	b.le	2407168 <v8::base::ieee754::atan(double)+0x1d8>
 2406fd4:	adrp	x1, 3fe1000 <yy_action+0x1040>
 2406fd8:	ldr	d0, [x0, #24]
 2406fdc:	ldr	d1, [x1, #688]
 2406fe0:	fadd	d0, d0, d1
 2406fe4:	ret
 2406fe8:	fadd	d0, d1, d1
 2406fec:	ret
 2406ff0:	mov	w1, #0x3fdbffff            	// #1071382527
 2406ff4:	cmp	w0, w1
 2406ff8:	b.gt	24070c8 <v8::base::ieee754::atan(double)+0x138>
 2406ffc:	mov	w1, #0x3e3fffff            	// #1044381695
 2407000:	cmp	w0, w1
 2407004:	b.le	240714c <v8::base::ieee754::atan(double)+0x1bc>
 2407008:	movi	d21, #0x0
 240700c:	mov	w0, #0xffffffff            	// #-1
 2407010:	fmov	d0, d21
 2407014:	fmul	d4, d1, d1
 2407018:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240701c:	ldr	d23, [x1, #2760]
 2407020:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407024:	fmul	d3, d4, d4
 2407028:	ldr	d20, [x1, #2768]
 240702c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407030:	ldr	d22, [x1, #2776]
 2407034:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407038:	fmadd	d20, d3, d23, d20
 240703c:	ldr	d19, [x1, #2784]
 2407040:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407044:	fmadd	d19, d3, d22, d19
 2407048:	ldr	d18, [x1, #2792]
 240704c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407050:	ldr	d17, [x1, #2800]
 2407054:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407058:	ldr	d16, [x1, #2808]
 240705c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407060:	fmadd	d18, d20, d3, d18
 2407064:	ldr	d7, [x1, #2816]
 2407068:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240706c:	fmadd	d17, d19, d3, d17
 2407070:	ldr	d6, [x1, #2824]
 2407074:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407078:	ldr	d2, [x1, #2832]
 240707c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407080:	ldr	d5, [x1, #2840]
 2407084:	fmadd	d16, d18, d3, d16
 2407088:	fmadd	d7, d17, d3, d7
 240708c:	fmadd	d6, d16, d3, d6
 2407090:	fmadd	d2, d7, d3, d2
 2407094:	fmadd	d5, d6, d3, d5
 2407098:	fmul	d2, d2, d3
 240709c:	fmadd	d2, d5, d4, d2
 24070a0:	fmul	d2, d1, d2
 24070a4:	cmn	w0, #0x1
 24070a8:	b.eq	240717c <v8::base::ieee754::atan(double)+0x1ec>  // b.none
 24070ac:	fsub	d2, d2, d21
 24070b0:	cmp	w3, #0x0
 24070b4:	fsub	d2, d2, d1
 24070b8:	fsub	d0, d0, d2
 24070bc:	fneg	d1, d0
 24070c0:	fcsel	d0, d1, d0, lt	// lt = tstop
 24070c4:	ret
 24070c8:	fabs	d1, d0
 24070cc:	mov	w1, #0x3ff2ffff            	// #1072889855
 24070d0:	cmp	w0, w1
 24070d4:	b.gt	2407110 <v8::base::ieee754::atan(double)+0x180>
 24070d8:	mov	w1, #0x3fe5ffff            	// #1072037887
 24070dc:	cmp	w0, w1
 24070e0:	b.gt	24071a4 <v8::base::ieee754::atan(double)+0x214>
 24070e4:	fmov	d3, #2.000000000000000000e+00
 24070e8:	fmov	d2, #-1.000000000000000000e+00
 24070ec:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24070f0:	fmadd	d2, d1, d3, d2
 24070f4:	fadd	d1, d1, d3
 24070f8:	ldr	d21, [x0, #2720]
 24070fc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407100:	ldr	d0, [x0, #2728]
 2407104:	mov	w0, #0x0                   	// #0
 2407108:	fdiv	d1, d2, d1
 240710c:	b	2407014 <v8::base::ieee754::atan(double)+0x84>
 2407110:	mov	w1, #0x7fff                	// #32767
 2407114:	movk	w1, #0x4003, lsl #16
 2407118:	cmp	w0, w1
 240711c:	b.gt	2407184 <v8::base::ieee754::atan(double)+0x1f4>
 2407120:	fmov	d3, #1.500000000000000000e+00
 2407124:	fmov	d2, #1.000000000000000000e+00
 2407128:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240712c:	fmadd	d2, d1, d3, d2
 2407130:	fsub	d1, d1, d3
 2407134:	ldr	d21, [x0, #2744]
 2407138:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240713c:	ldr	d0, [x0, #2752]
 2407140:	mov	w0, #0x2                   	// #2
 2407144:	fdiv	d1, d1, d2
 2407148:	b	2407014 <v8::base::ieee754::atan(double)+0x84>
 240714c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407150:	fmov	d3, #1.000000000000000000e+00
 2407154:	ldr	d2, [x0, #2696]
 2407158:	fadd	d2, d0, d2
 240715c:	fcmpe	d2, d3
 2407160:	b.gt	2406fe4 <v8::base::ieee754::atan(double)+0x54>
 2407164:	b	2407008 <v8::base::ieee754::atan(double)+0x78>
 2407168:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240716c:	ldr	d1, [x0, #24]
 2407170:	ldr	d0, [x1, #2712]
 2407174:	fsub	d0, d0, d1
 2407178:	ret
 240717c:	fsub	d0, d1, d2
 2407180:	ret
 2407184:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407188:	fmov	d2, #-1.000000000000000000e+00
 240718c:	fdiv	d1, d2, d1
 2407190:	ldr	d21, [x0, #2680]
 2407194:	adrp	x0, 3fe1000 <yy_action+0x1040>
 2407198:	ldr	d0, [x0, #688]
 240719c:	mov	w0, #0x3                   	// #3
 24071a0:	b	2407014 <v8::base::ieee754::atan(double)+0x84>
 24071a4:	fmov	d2, #1.000000000000000000e+00
 24071a8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24071ac:	fsub	d3, d1, d2
 24071b0:	fadd	d1, d1, d2
 24071b4:	ldr	d21, [x0, #2736]
 24071b8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24071bc:	ldr	d0, [x0, #2704]
 24071c0:	mov	w0, #0x1                   	// #1
 24071c4:	fdiv	d1, d3, d1
 24071c8:	b	2407014 <v8::base::ieee754::atan(double)+0x84>
 24071cc:	nop

00000000024071d0 <v8::base::ieee754::atan2(double, double)>:
 24071d0:	fmov	x0, d1
 24071d4:	mov	w2, #0x80000000            	// #-2147483648
 24071d8:	fmov	d2, d0
 24071dc:	mov	w3, #0x7ff00000            	// #2146435072
 24071e0:	cmp	w2, w0
 24071e4:	ubfx	x5, x0, #32, #31
 24071e8:	cneg	w1, w0, ne	// ne = any
 24071ec:	orr	w1, w1, w0
 24071f0:	orr	w1, w5, w1, lsr #31
 24071f4:	cmp	w1, w3
 24071f8:	b.hi	2407274 <v8::base::ieee754::atan2(double, double)+0xa4>  // b.pmore
 24071fc:	fmov	x1, d0
 2407200:	cmp	w2, w1
 2407204:	ubfx	x6, x1, #32, #31
 2407208:	cneg	w2, w1, ne	// ne = any
 240720c:	lsr	x8, x1, #32
 2407210:	orr	w2, w2, w1
 2407214:	orr	w2, w6, w2, lsr #31
 2407218:	cmp	w2, w3
 240721c:	b.hi	2407274 <v8::base::ieee754::atan2(double, double)+0xa4>  // b.pmore
 2407220:	lsr	x7, x0, #32
 2407224:	mov	w2, #0xc0100000            	// #-1072693248
 2407228:	add	w2, w7, w2
 240722c:	orr	w2, w2, w0
 2407230:	cbz	w2, 24072c4 <v8::base::ieee754::atan2(double, double)+0xf4>
 2407234:	asr	w4, w7, #30
 2407238:	lsr	w2, w8, #31
 240723c:	and	w4, w4, #0x2
 2407240:	orr	w1, w6, w1
 2407244:	orr	w4, w4, w2
 2407248:	cbnz	w1, 240727c <v8::base::ieee754::atan2(double, double)+0xac>
 240724c:	cmp	w4, #0x2
 2407250:	b.eq	24072e8 <v8::base::ieee754::atan2(double, double)+0x118>  // b.none
 2407254:	cmp	w4, #0x3
 2407258:	b.ne	24072e4 <v8::base::ieee754::atan2(double, double)+0x114>  // b.any
 240725c:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407260:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407264:	ldr	d1, [x0, #1944]
 2407268:	ldr	d0, [x1, #2848]
 240726c:	fsub	d0, d0, d1
 2407270:	ret
 2407274:	fadd	d0, d1, d2
 2407278:	ret
 240727c:	orr	w0, w5, w0
 2407280:	cbz	w0, 24072c8 <v8::base::ieee754::atan2(double, double)+0xf8>
 2407284:	cmp	w5, w3
 2407288:	b.eq	2407300 <v8::base::ieee754::atan2(double, double)+0x130>  // b.none
 240728c:	cmp	w6, w3
 2407290:	b.eq	24072c8 <v8::base::ieee754::atan2(double, double)+0xf8>  // b.none
 2407294:	sub	w0, w6, w5
 2407298:	asr	w0, w0, #20
 240729c:	cmp	w0, #0x3c
 24072a0:	b.le	2407344 <v8::base::ieee754::atan2(double, double)+0x174>
 24072a4:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24072a8:	adrp	x1, 3fe1000 <yy_action+0x1040>
 24072ac:	fmov	d1, #5.000000000000000000e-01
 24072b0:	ldr	d2, [x0, #1936]
 24072b4:	ldr	d0, [x1, #688]
 24072b8:	fmadd	d0, d2, d1, d0
 24072bc:	tbnz	w4, #0, 24073d4 <v8::base::ieee754::atan2(double, double)+0x204>
 24072c0:	ret
 24072c4:	b	2406f90 <v8::base::ieee754::atan(double)>
 24072c8:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24072cc:	tbnz	w8, #31, 2407330 <v8::base::ieee754::atan2(double, double)+0x160>
 24072d0:	adrp	x1, 3fe1000 <yy_action+0x1040>
 24072d4:	ldr	d0, [x0, #1944]
 24072d8:	ldr	d1, [x1, #688]
 24072dc:	fadd	d0, d0, d1
 24072e0:	ret
 24072e4:	ret
 24072e8:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24072ec:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 24072f0:	ldr	d0, [x0, #1944]
 24072f4:	ldr	d1, [x1, #4056]
 24072f8:	fadd	d0, d0, d1
 24072fc:	ret
 2407300:	cmp	w6, w5
 2407304:	b.eq	24073a4 <v8::base::ieee754::atan2(double, double)+0x1d4>  // b.none
 2407308:	cmp	w4, #0x2
 240730c:	b.eq	24072e8 <v8::base::ieee754::atan2(double, double)+0x118>  // b.none
 2407310:	cmp	w4, #0x3
 2407314:	b.eq	240725c <v8::base::ieee754::atan2(double, double)+0x8c>  // b.none
 2407318:	movi	d1, #0x0
 240731c:	cmp	w4, #0x1
 2407320:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
 2407324:	fmov	d0, x0
 2407328:	fcsel	d0, d0, d1, eq	// eq = none
 240732c:	ret
 2407330:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407334:	ldr	d1, [x0, #1944]
 2407338:	ldr	d0, [x1, #2712]
 240733c:	fsub	d0, d0, d1
 2407340:	ret
 2407344:	cmp	w7, #0x0
 2407348:	mov	w1, #0xffffffc4            	// #-60
 240734c:	movi	d0, #0x0
 2407350:	ccmp	w0, w1, #0x0, lt	// lt = tstop
 2407354:	b.ge	24073dc <v8::base::ieee754::atan2(double, double)+0x20c>  // b.tcont
 2407358:	cmp	w4, #0x1
 240735c:	b.eq	24073d4 <v8::base::ieee754::atan2(double, double)+0x204>  // b.none
 2407360:	cmp	w4, #0x2
 2407364:	b.ne	2407384 <v8::base::ieee754::atan2(double, double)+0x1b4>  // b.any
 2407368:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 240736c:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2407370:	ldr	d2, [x0, #1936]
 2407374:	ldr	d1, [x1, #4056]
 2407378:	fsub	d0, d0, d2
 240737c:	fsub	d0, d1, d0
 2407380:	ret
 2407384:	cbz	w4, 2407484 <v8::base::ieee754::atan2(double, double)+0x2b4>
 2407388:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 240738c:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2407390:	ldr	d2, [x0, #1936]
 2407394:	ldr	d1, [x1, #4056]
 2407398:	fsub	d0, d0, d2
 240739c:	fsub	d0, d0, d1
 24073a0:	ret
 24073a4:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24073a8:	cmp	w4, #0x2
 24073ac:	b.eq	2407470 <v8::base::ieee754::atan2(double, double)+0x2a0>  // b.none
 24073b0:	cmp	w4, #0x3
 24073b4:	b.eq	240745c <v8::base::ieee754::atan2(double, double)+0x28c>  // b.none
 24073b8:	cmp	w4, #0x1
 24073bc:	b.eq	2407448 <v8::base::ieee754::atan2(double, double)+0x278>  // b.none
 24073c0:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24073c4:	ldr	d0, [x0, #1944]
 24073c8:	ldr	d1, [x1, #2704]
 24073cc:	fadd	d0, d0, d1
 24073d0:	ret
 24073d4:	fneg	d0, d0
 24073d8:	ret
 24073dc:	fdiv	d0, d2, d1
 24073e0:	stp	x29, x30, [sp, #-16]!
 24073e4:	mov	x29, sp
 24073e8:	fabs	d0, d0
 24073ec:	bl	2406f90 <v8::base::ieee754::atan(double)>
 24073f0:	cmp	w4, #0x1
 24073f4:	b.eq	2407440 <v8::base::ieee754::atan2(double, double)+0x270>  // b.none
 24073f8:	cmp	w4, #0x2
 24073fc:	b.ne	2407420 <v8::base::ieee754::atan2(double, double)+0x250>  // b.any
 2407400:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407404:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2407408:	ldr	d2, [x0, #1936]
 240740c:	ldr	d1, [x1, #4056]
 2407410:	fsub	d0, d0, d2
 2407414:	fsub	d0, d1, d0
 2407418:	ldp	x29, x30, [sp], #16
 240741c:	ret
 2407420:	cbz	w4, 2407418 <v8::base::ieee754::atan2(double, double)+0x248>
 2407424:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407428:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 240742c:	ldr	d2, [x0, #1936]
 2407430:	ldr	d1, [x1, #4056]
 2407434:	fsub	d0, d0, d2
 2407438:	fsub	d0, d0, d1
 240743c:	b	2407418 <v8::base::ieee754::atan2(double, double)+0x248>
 2407440:	fneg	d0, d0
 2407444:	b	2407418 <v8::base::ieee754::atan2(double, double)+0x248>
 2407448:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240744c:	ldr	d1, [x0, #1944]
 2407450:	ldr	d0, [x1, #2856]
 2407454:	fsub	d0, d0, d1
 2407458:	ret
 240745c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407460:	ldr	d1, [x0, #1944]
 2407464:	ldr	d0, [x1, #2872]
 2407468:	fsub	d0, d0, d1
 240746c:	ret
 2407470:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407474:	ldr	d0, [x0, #1944]
 2407478:	ldr	d1, [x1, #2864]
 240747c:	fadd	d0, d0, d1
 2407480:	ret
 2407484:	ret
 2407488:	nop
 240748c:	nop

0000000002407490 <v8::base::ieee754::cos(double)>:
 2407490:	fmov	x0, d0
 2407494:	mov	w1, #0x21fb                	// #8699
 2407498:	fmov	d1, d0
 240749c:	movk	w1, #0x3fe9, lsl #16
 24074a0:	ubfx	x0, x0, #32, #31
 24074a4:	cmp	w0, w1
 24074a8:	b.gt	2407554 <v8::base::ieee754::cos(double)+0xc4>
 24074ac:	mov	w1, #0x3e3fffff            	// #1044381695
 24074b0:	cmp	w0, w1
 24074b4:	b.le	2407568 <v8::base::ieee754::cos(double)+0xd8>
 24074b8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074bc:	fmul	d3, d0, d0
 24074c0:	ldr	d7, [x1, #2880]
 24074c4:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074c8:	ldr	d6, [x1, #2888]
 24074cc:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074d0:	fmadd	d6, d3, d7, d6
 24074d4:	ldr	d5, [x1, #2896]
 24074d8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074dc:	ldr	d4, [x1, #2904]
 24074e0:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074e4:	ldr	d0, [x1, #2912]
 24074e8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24074ec:	ldr	d2, [x1, #2920]
 24074f0:	mov	w1, #0x3332                	// #13106
 24074f4:	fmadd	d5, d3, d6, d5
 24074f8:	movk	w1, #0x3fd3, lsl #16
 24074fc:	fmadd	d4, d3, d5, d4
 2407500:	fmadd	d0, d3, d4, d0
 2407504:	fmadd	d2, d3, d0, d2
 2407508:	fmul	d2, d3, d2
 240750c:	cmp	w0, w1
 2407510:	b.le	24075bc <v8::base::ieee754::cos(double)+0x12c>
 2407514:	mov	w1, #0x3fe90000            	// #1072234496
 2407518:	cmp	w0, w1
 240751c:	b.gt	2407688 <v8::base::ieee754::cos(double)+0x1f8>
 2407520:	sub	w0, w0, #0x200, lsl #12
 2407524:	fmov	d0, x0
 2407528:	movi	d4, #0x0
 240752c:	fmov	d6, #5.000000000000000000e-01
 2407530:	shl	d0, d0, #32
 2407534:	fmov	d5, #1.000000000000000000e+00
 2407538:	fmul	d1, d1, d4
 240753c:	fsub	d5, d5, d0
 2407540:	fnmsub	d1, d3, d2, d1
 2407544:	fnmsub	d0, d3, d6, d0
 2407548:	fsub	d0, d0, d1
 240754c:	fsub	d0, d5, d0
 2407550:	ret
 2407554:	mov	w1, #0x7fefffff            	// #2146435071
 2407558:	cmp	w0, w1
 240755c:	b.le	24075dc <v8::base::ieee754::cos(double)+0x14c>
 2407560:	fsub	d0, d0, d0
 2407564:	ret
 2407568:	fcvtzs	w0, d0
 240756c:	cbz	w0, 240789c <v8::base::ieee754::cos(double)+0x40c>
 2407570:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407574:	fmul	d3, d0, d0
 2407578:	ldr	d7, [x0, #2880]
 240757c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407580:	ldr	d6, [x0, #2888]
 2407584:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407588:	fmadd	d6, d3, d7, d6
 240758c:	ldr	d5, [x0, #2896]
 2407590:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407594:	ldr	d4, [x0, #2904]
 2407598:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240759c:	ldr	d0, [x0, #2912]
 24075a0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24075a4:	ldr	d2, [x0, #2920]
 24075a8:	fmadd	d5, d6, d3, d5
 24075ac:	fmadd	d4, d5, d3, d4
 24075b0:	fmadd	d0, d4, d3, d0
 24075b4:	fmadd	d2, d0, d3, d2
 24075b8:	fmul	d2, d2, d3
 24075bc:	movi	d0, #0x0
 24075c0:	fmov	d5, #5.000000000000000000e-01
 24075c4:	fmov	d4, #1.000000000000000000e+00
 24075c8:	fmul	d0, d1, d0
 24075cc:	fnmsub	d0, d3, d2, d0
 24075d0:	fnmsub	d0, d3, d5, d0
 24075d4:	fsub	d0, d4, d0
 24075d8:	ret
 24075dc:	stp	x29, x30, [sp, #-32]!
 24075e0:	mov	x29, sp
 24075e4:	add	x0, sp, #0x10
 24075e8:	bl	2406740 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)>
 24075ec:	and	w0, w0, #0x3
 24075f0:	cmp	w0, #0x1
 24075f4:	b.eq	2407818 <v8::base::ieee754::cos(double)+0x388>  // b.none
 24075f8:	cmp	w0, #0x2
 24075fc:	b.eq	2407760 <v8::base::ieee754::cos(double)+0x2d0>  // b.none
 2407600:	cbz	w0, 24076b0 <v8::base::ieee754::cos(double)+0x220>
 2407604:	ldp	d0, d2, [sp, #16]
 2407608:	mov	w0, #0x3e3fffff            	// #1044381695
 240760c:	fmov	x1, d0
 2407610:	ubfx	x1, x1, #32, #31
 2407614:	cmp	w1, w0
 2407618:	b.gt	2407624 <v8::base::ieee754::cos(double)+0x194>
 240761c:	fcvtzs	w0, d0
 2407620:	cbz	w0, 2407810 <v8::base::ieee754::cos(double)+0x380>
 2407624:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407628:	fmul	d3, d0, d0
 240762c:	fmov	d17, #5.000000000000000000e-01
 2407630:	ldr	d7, [x0, #2928]
 2407634:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407638:	ldr	d6, [x0, #2936]
 240763c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407640:	fmadd	d6, d3, d7, d6
 2407644:	fmul	d7, d0, d3
 2407648:	ldr	d5, [x0, #2944]
 240764c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407650:	ldr	d4, [x0, #2952]
 2407654:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407658:	ldr	d1, [x0, #2960]
 240765c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407660:	ldr	d16, [x0, #2968]
 2407664:	fmadd	d5, d3, d6, d5
 2407668:	fmadd	d4, d3, d5, d4
 240766c:	fmadd	d1, d3, d4, d1
 2407670:	fmul	d1, d7, d1
 2407674:	fnmsub	d1, d2, d17, d1
 2407678:	fnmsub	d2, d3, d1, d2
 240767c:	fmadd	d2, d7, d16, d2
 2407680:	fsub	d0, d0, d2
 2407684:	b	2407810 <v8::base::ieee754::cos(double)+0x380>
 2407688:	movi	d4, #0x0
 240768c:	fmov	d6, #5.000000000000000000e-01
 2407690:	fmov	d0, #2.812500000000000000e-01
 2407694:	fmov	d5, #7.187500000000000000e-01
 2407698:	fnmsub	d0, d3, d6, d0
 240769c:	fmul	d1, d1, d4
 24076a0:	fnmsub	d1, d3, d2, d1
 24076a4:	fsub	d0, d0, d1
 24076a8:	fsub	d0, d5, d0
 24076ac:	ret
 24076b0:	ldp	d1, d7, [sp, #16]
 24076b4:	mov	w1, #0x3e3fffff            	// #1044381695
 24076b8:	fmov	x0, d1
 24076bc:	ubfx	x0, x0, #32, #31
 24076c0:	cmp	w0, w1
 24076c4:	b.le	240791c <v8::base::ieee754::cos(double)+0x48c>
 24076c8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076cc:	fmul	d2, d1, d1
 24076d0:	ldr	d16, [x1, #2880]
 24076d4:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076d8:	ldr	d6, [x1, #2888]
 24076dc:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076e0:	fmadd	d6, d2, d16, d6
 24076e4:	ldr	d5, [x1, #2896]
 24076e8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076ec:	ldr	d3, [x1, #2904]
 24076f0:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076f4:	ldr	d0, [x1, #2912]
 24076f8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24076fc:	ldr	d4, [x1, #2920]
 2407700:	mov	w1, #0x3332                	// #13106
 2407704:	fmadd	d5, d2, d6, d5
 2407708:	movk	w1, #0x3fd3, lsl #16
 240770c:	fmadd	d3, d2, d5, d3
 2407710:	fmadd	d0, d2, d3, d0
 2407714:	fmadd	d4, d2, d0, d4
 2407718:	fmul	d4, d2, d4
 240771c:	cmp	w0, w1
 2407720:	b.le	2407970 <v8::base::ieee754::cos(double)+0x4e0>
 2407724:	mov	w1, #0x3fe90000            	// #1072234496
 2407728:	cmp	w0, w1
 240772c:	b.gt	24079a0 <v8::base::ieee754::cos(double)+0x510>
 2407730:	sub	w0, w0, #0x200, lsl #12
 2407734:	fmov	d3, x0
 2407738:	fmov	d0, #1.000000000000000000e+00
 240773c:	shl	d3, d3, #32
 2407740:	fsub	d0, d0, d3
 2407744:	fmov	d5, #5.000000000000000000e-01
 2407748:	fmul	d1, d1, d7
 240774c:	fnmsub	d1, d2, d4, d1
 2407750:	fnmsub	d3, d2, d5, d3
 2407754:	fsub	d3, d3, d1
 2407758:	fsub	d0, d0, d3
 240775c:	b	2407810 <v8::base::ieee754::cos(double)+0x380>
 2407760:	ldp	d1, d7, [sp, #16]
 2407764:	mov	w1, #0x3e3fffff            	// #1044381695
 2407768:	fmov	x0, d1
 240776c:	ubfx	x0, x0, #32, #31
 2407770:	cmp	w0, w1
 2407774:	b.le	24078a4 <v8::base::ieee754::cos(double)+0x414>
 2407778:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240777c:	fmul	d2, d1, d1
 2407780:	ldr	d16, [x1, #2880]
 2407784:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407788:	ldr	d6, [x1, #2888]
 240778c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407790:	fmadd	d6, d2, d16, d6
 2407794:	ldr	d5, [x1, #2896]
 2407798:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240779c:	ldr	d3, [x1, #2904]
 24077a0:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24077a4:	ldr	d0, [x1, #2912]
 24077a8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24077ac:	ldr	d4, [x1, #2920]
 24077b0:	mov	w1, #0x3332                	// #13106
 24077b4:	fmadd	d5, d2, d6, d5
 24077b8:	movk	w1, #0x3fd3, lsl #16
 24077bc:	fmadd	d3, d2, d5, d3
 24077c0:	fmadd	d0, d2, d3, d0
 24077c4:	fmadd	d4, d2, d0, d4
 24077c8:	fmul	d4, d2, d4
 24077cc:	cmp	w0, w1
 24077d0:	b.le	24078fc <v8::base::ieee754::cos(double)+0x46c>
 24077d4:	mov	w1, #0x3fe90000            	// #1072234496
 24077d8:	cmp	w0, w1
 24077dc:	b.gt	2407994 <v8::base::ieee754::cos(double)+0x504>
 24077e0:	sub	w0, w0, #0x200, lsl #12
 24077e4:	fmov	d3, x0
 24077e8:	fmov	d0, #1.000000000000000000e+00
 24077ec:	shl	d3, d3, #32
 24077f0:	fsub	d0, d0, d3
 24077f4:	fmov	d5, #5.000000000000000000e-01
 24077f8:	fmul	d1, d1, d7
 24077fc:	fnmsub	d1, d2, d4, d1
 2407800:	fnmsub	d3, d2, d5, d3
 2407804:	fsub	d3, d3, d1
 2407808:	fsub	d0, d0, d3
 240780c:	fneg	d0, d0
 2407810:	ldp	x29, x30, [sp], #32
 2407814:	ret
 2407818:	ldp	d0, d2, [sp, #16]
 240781c:	mov	w0, #0x3e3fffff            	// #1044381695
 2407820:	fmov	x1, d0
 2407824:	ubfx	x1, x1, #32, #31
 2407828:	cmp	w1, w0
 240782c:	b.gt	2407838 <v8::base::ieee754::cos(double)+0x3a8>
 2407830:	fcvtzs	w0, d0
 2407834:	cbz	w0, 240780c <v8::base::ieee754::cos(double)+0x37c>
 2407838:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240783c:	fmul	d3, d0, d0
 2407840:	fmov	d17, #5.000000000000000000e-01
 2407844:	ldr	d7, [x0, #2928]
 2407848:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240784c:	ldr	d6, [x0, #2936]
 2407850:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407854:	fmadd	d6, d3, d7, d6
 2407858:	fmul	d7, d0, d3
 240785c:	ldr	d5, [x0, #2944]
 2407860:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407864:	ldr	d4, [x0, #2952]
 2407868:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240786c:	ldr	d1, [x0, #2960]
 2407870:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407874:	ldr	d16, [x0, #2968]
 2407878:	fmadd	d5, d3, d6, d5
 240787c:	fmadd	d4, d3, d5, d4
 2407880:	fmadd	d1, d3, d4, d1
 2407884:	fmul	d1, d7, d1
 2407888:	fnmsub	d1, d2, d17, d1
 240788c:	fnmsub	d2, d3, d1, d2
 2407890:	fmadd	d2, d7, d16, d2
 2407894:	fsub	d0, d0, d2
 2407898:	b	240780c <v8::base::ieee754::cos(double)+0x37c>
 240789c:	fmov	d0, #1.000000000000000000e+00
 24078a0:	ret
 24078a4:	fcvtzs	w0, d1
 24078a8:	fmov	d0, #-1.000000000000000000e+00
 24078ac:	cbz	w0, 2407810 <v8::base::ieee754::cos(double)+0x380>
 24078b0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078b4:	fmul	d2, d1, d1
 24078b8:	ldr	d16, [x0, #2880]
 24078bc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078c0:	ldr	d6, [x0, #2888]
 24078c4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078c8:	fmadd	d6, d2, d16, d6
 24078cc:	ldr	d5, [x0, #2896]
 24078d0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078d4:	ldr	d3, [x0, #2904]
 24078d8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078dc:	ldr	d0, [x0, #2912]
 24078e0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24078e4:	ldr	d4, [x0, #2920]
 24078e8:	fmadd	d5, d2, d6, d5
 24078ec:	fmadd	d3, d2, d5, d3
 24078f0:	fmadd	d0, d2, d3, d0
 24078f4:	fmadd	d4, d2, d0, d4
 24078f8:	fmul	d4, d2, d4
 24078fc:	fmul	d1, d1, d7
 2407900:	fmov	d3, #5.000000000000000000e-01
 2407904:	fnmsub	d1, d2, d4, d1
 2407908:	fmov	d0, #1.000000000000000000e+00
 240790c:	fnmsub	d1, d2, d3, d1
 2407910:	fsub	d0, d0, d1
 2407914:	fneg	d0, d0
 2407918:	b	2407810 <v8::base::ieee754::cos(double)+0x380>
 240791c:	fcvtzs	w0, d1
 2407920:	cbz	w0, 240798c <v8::base::ieee754::cos(double)+0x4fc>
 2407924:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407928:	fmul	d2, d1, d1
 240792c:	ldr	d16, [x0, #2880]
 2407930:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407934:	ldr	d6, [x0, #2888]
 2407938:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240793c:	fmadd	d6, d2, d16, d6
 2407940:	ldr	d5, [x0, #2896]
 2407944:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407948:	ldr	d3, [x0, #2904]
 240794c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407950:	ldr	d0, [x0, #2912]
 2407954:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407958:	ldr	d4, [x0, #2920]
 240795c:	fmadd	d5, d2, d6, d5
 2407960:	fmadd	d3, d2, d5, d3
 2407964:	fmadd	d0, d2, d3, d0
 2407968:	fmadd	d4, d2, d0, d4
 240796c:	fmul	d4, d2, d4
 2407970:	fmul	d1, d1, d7
 2407974:	fmov	d3, #5.000000000000000000e-01
 2407978:	fnmsub	d1, d2, d4, d1
 240797c:	fmov	d0, #1.000000000000000000e+00
 2407980:	fnmsub	d1, d2, d3, d1
 2407984:	fsub	d0, d0, d1
 2407988:	b	2407810 <v8::base::ieee754::cos(double)+0x380>
 240798c:	fmov	d0, #1.000000000000000000e+00
 2407990:	b	2407810 <v8::base::ieee754::cos(double)+0x380>
 2407994:	fmov	d0, #7.187500000000000000e-01
 2407998:	fmov	d3, #2.812500000000000000e-01
 240799c:	b	24077f4 <v8::base::ieee754::cos(double)+0x364>
 24079a0:	fmov	d0, #7.187500000000000000e-01
 24079a4:	fmov	d3, #2.812500000000000000e-01
 24079a8:	b	2407744 <v8::base::ieee754::cos(double)+0x2b4>
 24079ac:	nop

00000000024079b0 <v8::base::ieee754::exp(double)>:
 24079b0:	fmov	x0, d0
 24079b4:	mov	w4, #0x2e41                	// #11841
 24079b8:	movk	w4, #0x4086, lsl #16
 24079bc:	ubfx	x2, x0, #32, #31
 24079c0:	lsr	x3, x0, #32
 24079c4:	lsr	x1, x0, #63
 24079c8:	cmp	w2, w4
 24079cc:	b.ls	24079f0 <v8::base::ieee754::exp(double)+0x40>  // b.plast
 24079d0:	mov	w4, #0x7fefffff            	// #2146435071
 24079d4:	cmp	w2, w4
 24079d8:	b.ls	2407a80 <v8::base::ieee754::exp(double)+0xd0>  // b.plast
 24079dc:	and	w3, w3, #0xfffff
 24079e0:	orr	w3, w3, w0
 24079e4:	cbz	w3, 2407be8 <v8::base::ieee754::exp(double)+0x238>
 24079e8:	fadd	d0, d0, d0
 24079ec:	ret
 24079f0:	mov	w0, #0x2e42                	// #11842
 24079f4:	movk	w0, #0x3fd6, lsl #16
 24079f8:	cmp	w2, w0
 24079fc:	b.hi	2407b6c <v8::base::ieee754::exp(double)+0x1bc>  // b.pmore
 2407a00:	mov	w0, #0x3e2fffff            	// #1043333119
 2407a04:	cmp	w2, w0
 2407a08:	b.ls	2407bcc <v8::base::ieee754::exp(double)+0x21c>  // b.plast
 2407a0c:	movi	d3, #0x0
 2407a10:	fmul	d1, d0, d0
 2407a14:	fmov	d16, #1.000000000000000000e+00
 2407a18:	mov	w1, #0x0                   	// #0
 2407a1c:	fmov	d4, d3
 2407a20:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a24:	ldr	d2, [x0, #3008]
 2407a28:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a2c:	ldr	d7, [x0, #3016]
 2407a30:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a34:	fmadd	d7, d1, d2, d7
 2407a38:	ldr	d6, [x0, #3024]
 2407a3c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a40:	ldr	d5, [x0, #3032]
 2407a44:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a48:	ldr	d2, [x0, #3040]
 2407a4c:	fmadd	d6, d7, d1, d6
 2407a50:	fmadd	d5, d6, d1, d5
 2407a54:	fmadd	d2, d5, d1, d2
 2407a58:	fmsub	d1, d2, d1, d0
 2407a5c:	cbnz	w1, 2407c0c <v8::base::ieee754::exp(double)+0x25c>
 2407a60:	fmov	d4, #2.000000000000000000e+00
 2407a64:	fmul	d2, d1, d0
 2407a68:	fmov	d3, #1.000000000000000000e+00
 2407a6c:	fsub	d1, d1, d4
 2407a70:	fdiv	d1, d2, d1
 2407a74:	fsub	d0, d1, d0
 2407a78:	fsub	d0, d3, d0
 2407a7c:	ret
 2407a80:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a84:	ldr	d1, [x0, #2976]
 2407a88:	fcmpe	d0, d1
 2407a8c:	b.gt	2407bf8 <v8::base::ieee754::exp(double)+0x248>
 2407a90:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407a94:	ldr	d1, [x0, #2984]
 2407a98:	fcmpe	d0, d1
 2407a9c:	b.mi	2407c58 <v8::base::ieee754::exp(double)+0x2a8>  // b.first
 2407aa0:	adrp	x2, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2407aa4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407aa8:	add	x0, x0, #0x820
 2407aac:	ldr	d2, [x2, #4040]
 2407ab0:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2407ab4:	ldr	d1, [x0, w1, sxtw #3]
 2407ab8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407abc:	fmadd	d1, d0, d2, d1
 2407ac0:	ldr	d4, [x2, #2992]
 2407ac4:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2407ac8:	ldr	d7, [x0, #3016]
 2407acc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407ad0:	ldr	d17, [x2, #3000]
 2407ad4:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2407ad8:	ldr	d6, [x0, #3024]
 2407adc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407ae0:	ldr	d16, [x2, #3008]
 2407ae4:	ldr	d2, [x0, #3032]
 2407ae8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407aec:	fcvtzs	w1, d1
 2407af0:	ldr	d5, [x0, #3040]
 2407af4:	scvtf	d3, w1
 2407af8:	fmsub	d4, d3, d4, d0
 2407afc:	fmul	d3, d3, d17
 2407b00:	fsub	d0, d4, d3
 2407b04:	fmul	d1, d0, d0
 2407b08:	fmadd	d7, d1, d16, d7
 2407b0c:	fmadd	d6, d1, d7, d6
 2407b10:	fmadd	d2, d1, d6, d2
 2407b14:	fmadd	d5, d1, d2, d5
 2407b18:	fmsub	d5, d1, d5, d0
 2407b1c:	cmn	w1, #0x3fd
 2407b20:	b.ge	2407c78 <v8::base::ieee754::exp(double)+0x2c8>  // b.tcont
 2407b24:	fmov	d1, #2.000000000000000000e+00
 2407b28:	fmul	d2, d0, d5
 2407b2c:	add	w1, w1, #0x3e8
 2407b30:	mov	w0, #0x3ff00000            	// #1072693248
 2407b34:	fsub	d5, d1, d5
 2407b38:	add	w1, w0, w1, lsl #20
 2407b3c:	fmov	d0, #1.000000000000000000e+00
 2407b40:	fmov	d1, x1
 2407b44:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407b48:	fdiv	d2, d2, d5
 2407b4c:	shl	d1, d1, #32
 2407b50:	ldr	d6, [x0, #1920]
 2407b54:	fsub	d2, d3, d2
 2407b58:	fsub	d2, d2, d4
 2407b5c:	fsub	d0, d0, d2
 2407b60:	fmul	d0, d0, d1
 2407b64:	fmul	d0, d0, d6
 2407b68:	ret
 2407b6c:	mov	w0, #0xa2b1                	// #41649
 2407b70:	movk	w0, #0x3ff0, lsl #16
 2407b74:	cmp	w2, w0
 2407b78:	b.hi	2407aa0 <v8::base::ieee754::exp(double)+0xf0>  // b.pmore
 2407b7c:	fmov	d1, #1.000000000000000000e+00
 2407b80:	fcmp	d0, d1
 2407b84:	b.eq	2407c6c <v8::base::ieee754::exp(double)+0x2bc>  // b.none
 2407b88:	sxtw	x4, w1
 2407b8c:	adrp	x3, 5ff1000 <icudt78_dat+0x1f92120>
 2407b90:	add	x3, x3, #0x810
 2407b94:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2407b98:	add	x2, x2, #0x800
 2407b9c:	mov	w0, #0x1                   	// #1
 2407ba0:	sub	w1, w0, w1, lsl #1
 2407ba4:	mov	w0, #0x3ff00000            	// #1072693248
 2407ba8:	ldr	d4, [x3, x4, lsl #3]
 2407bac:	ldr	d3, [x2, x4, lsl #3]
 2407bb0:	add	w0, w0, w1, lsl #20
 2407bb4:	fsub	d4, d0, d4
 2407bb8:	fmov	d0, x0
 2407bbc:	shl	d16, d0, #32
 2407bc0:	fsub	d0, d4, d3
 2407bc4:	fmul	d1, d0, d0
 2407bc8:	b	2407a20 <v8::base::ieee754::exp(double)+0x70>
 2407bcc:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407bd0:	fmov	d2, #1.000000000000000000e+00
 2407bd4:	ldr	d1, [x0, #1928]
 2407bd8:	fadd	d1, d1, d0
 2407bdc:	fcmpe	d1, d2
 2407be0:	b.gt	2407c48 <v8::base::ieee754::exp(double)+0x298>
 2407be4:	b	2407a0c <v8::base::ieee754::exp(double)+0x5c>
 2407be8:	movi	d1, #0x0
 2407bec:	cmp	w1, #0x0
 2407bf0:	fcsel	d0, d0, d1, eq	// eq = none
 2407bf4:	ret
 2407bf8:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407bfc:	ldr	d0, [x0, #1928]
 2407c00:	ldr	d1, [x0, #1928]
 2407c04:	fmul	d0, d0, d1
 2407c08:	ret
 2407c0c:	fmov	d5, #2.000000000000000000e+00
 2407c10:	fmul	d0, d1, d0
 2407c14:	fmov	d2, #1.000000000000000000e+00
 2407c18:	fsub	d1, d5, d1
 2407c1c:	fdiv	d0, d0, d1
 2407c20:	fsub	d3, d3, d0
 2407c24:	fsub	d3, d3, d4
 2407c28:	fsub	d0, d2, d3
 2407c2c:	cmp	w1, #0x400
 2407c30:	b.ne	2407c50 <v8::base::ieee754::exp(double)+0x2a0>  // b.any
 2407c34:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407c38:	fadd	d1, d0, d0
 2407c3c:	ldr	d0, [x0, #1912]
 2407c40:	fmul	d0, d1, d0
 2407c44:	ret
 2407c48:	fadd	d0, d0, d2
 2407c4c:	ret
 2407c50:	fmul	d0, d0, d16
 2407c54:	ret
 2407c58:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2407c5c:	ldr	d0, [x0, #1920]
 2407c60:	ldr	d1, [x0, #1920]
 2407c64:	fmul	d0, d0, d1
 2407c68:	ret
 2407c6c:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2407c70:	ldr	d0, [x0, #4016]
 2407c74:	ret
 2407c78:	mov	w0, #0x3ff00000            	// #1072693248
 2407c7c:	add	w0, w0, w1, lsl #20
 2407c80:	fmov	d2, x0
 2407c84:	shl	d16, d2, #32
 2407c88:	b	2407a20 <v8::base::ieee754::exp(double)+0x70>
 2407c8c:	nop

0000000002407c90 <v8::base::ieee754::log(double)>:
 2407c90:	fmov	x1, d0
 2407c94:	mov	w3, #0xfffff               	// #1048575
 2407c98:	lsr	x2, x1, #32
 2407c9c:	mov	w0, w2
 2407ca0:	cmp	w2, w3
 2407ca4:	b.gt	2407cc0 <v8::base::ieee754::log(double)+0x30>
 2407ca8:	and	w0, w2, #0x7fffffff
 2407cac:	orr	w0, w0, w1
 2407cb0:	cbnz	w0, 2407d48 <v8::base::ieee754::log(double)+0xb8>
 2407cb4:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
 2407cb8:	fmov	d0, x0
 2407cbc:	ret
 2407cc0:	mov	w6, #0x0                   	// #0
 2407cc4:	mov	w2, #0x7fefffff            	// #2146435071
 2407cc8:	cmp	w0, w2
 2407ccc:	b.gt	2407d70 <v8::base::ieee754::log(double)+0xe0>
 2407cd0:	and	w4, w0, #0xfffff
 2407cd4:	asr	w0, w0, #20
 2407cd8:	add	w3, w4, #0x95, lsl #12
 2407cdc:	sub	w0, w0, #0x3ff
 2407ce0:	add	w3, w3, #0xf64
 2407ce4:	add	w5, w4, #0x2
 2407ce8:	and	w2, w3, #0x100000
 2407cec:	fmov	d0, #1.000000000000000000e+00
 2407cf0:	eor	w2, w2, #0x3ff00000
 2407cf4:	add	w0, w0, w6
 2407cf8:	orr	x2, x2, x4
 2407cfc:	and	w5, w5, #0xfffff
 2407d00:	add	w3, w0, w3, lsr #20
 2407d04:	bfi	x1, x2, #32, #32
 2407d08:	fmov	d1, x1
 2407d0c:	fsub	d0, d1, d0
 2407d10:	cmp	w5, #0x2
 2407d14:	b.gt	2407d78 <v8::base::ieee754::log(double)+0xe8>
 2407d18:	fcmp	d0, #0.0
 2407d1c:	b.ne	2407e28 <v8::base::ieee754::log(double)+0x198>  // b.any
 2407d20:	movi	d0, #0x0
 2407d24:	cbz	w3, 2407cbc <v8::base::ieee754::log(double)+0x2c>
 2407d28:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407d2c:	scvtf	d1, w3
 2407d30:	ldr	d0, [x0, #3000]
 2407d34:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407d38:	ldr	d2, [x0, #2992]
 2407d3c:	fmul	d0, d1, d0
 2407d40:	fmadd	d0, d1, d2, d0
 2407d44:	ret
 2407d48:	tbnz	w2, #31, 2407e6c <v8::base::ieee754::log(double)+0x1dc>
 2407d4c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
 2407d50:	fmov	d1, x0
 2407d54:	mov	w6, #0xffffffca            	// #-54
 2407d58:	mov	w2, #0x7fefffff            	// #2146435071
 2407d5c:	fmul	d0, d0, d1
 2407d60:	fmov	x1, d0
 2407d64:	lsr	x0, x1, #32
 2407d68:	cmp	w0, w2
 2407d6c:	b.le	2407cd0 <v8::base::ieee754::log(double)+0x40>
 2407d70:	fadd	d0, d0, d0
 2407d74:	ret
 2407d78:	fmov	d2, #2.000000000000000000e+00
 2407d7c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407d80:	sub	w1, w4, #0x61, lsl #12
 2407d84:	scvtf	d19, w3
 2407d88:	fadd	d2, d0, d2
 2407d8c:	ldr	d18, [x0, #3048]
 2407d90:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407d94:	sub	w1, w1, #0x47a
 2407d98:	ldr	d16, [x0, #3056]
 2407d9c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407da0:	fdiv	d2, d0, d2
 2407da4:	ldr	d6, [x0, #3064]
 2407da8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407dac:	ldr	d17, [x0, #3072]
 2407db0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407db4:	ldr	d7, [x0, #3080]
 2407db8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407dbc:	ldr	d1, [x0, #3088]
 2407dc0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407dc4:	ldr	d4, [x0, #3096]
 2407dc8:	mov	w0, #0xb851                	// #47185
 2407dcc:	movk	w0, #0x6, lsl #16
 2407dd0:	sub	w0, w0, w4
 2407dd4:	orr	w0, w0, w1
 2407dd8:	fmul	d5, d2, d2
 2407ddc:	fmul	d3, d5, d5
 2407de0:	fmadd	d16, d3, d18, d16
 2407de4:	fmadd	d7, d3, d17, d7
 2407de8:	fmadd	d6, d16, d3, d6
 2407dec:	fmadd	d4, d7, d3, d4
 2407df0:	fmadd	d1, d6, d3, d1
 2407df4:	fmul	d1, d1, d5
 2407df8:	fmadd	d1, d4, d3, d1
 2407dfc:	cmp	w0, #0x0
 2407e00:	b.le	2407e78 <v8::base::ieee754::log(double)+0x1e8>
 2407e04:	fmov	d3, #5.000000000000000000e-01
 2407e08:	fmul	d3, d0, d3
 2407e0c:	fmul	d3, d3, d0
 2407e10:	fadd	d1, d1, d3
 2407e14:	fmul	d1, d1, d2
 2407e18:	cbnz	w3, 2407e8c <v8::base::ieee754::log(double)+0x1fc>
 2407e1c:	fsub	d3, d3, d1
 2407e20:	fsub	d0, d0, d3
 2407e24:	ret
 2407e28:	mov	x0, #0x5555555555555555    	// #6148914691236517205
 2407e2c:	fmov	d2, #5.000000000000000000e-01
 2407e30:	movk	x0, #0x3fd5, lsl #48
 2407e34:	fmov	d3, x0
 2407e38:	fmul	d1, d0, d0
 2407e3c:	fmsub	d2, d0, d3, d2
 2407e40:	fmul	d1, d1, d2
 2407e44:	cbz	w3, 2407e84 <v8::base::ieee754::log(double)+0x1f4>
 2407e48:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407e4c:	scvtf	d2, w3
 2407e50:	ldr	d4, [x0, #3000]
 2407e54:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407e58:	ldr	d3, [x0, #2992]
 2407e5c:	fmsub	d1, d2, d4, d1
 2407e60:	fsub	d1, d1, d0
 2407e64:	fnmsub	d0, d2, d3, d1
 2407e68:	ret
 2407e6c:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2407e70:	fmov	d0, x0
 2407e74:	ret
 2407e78:	fsub	d1, d0, d1
 2407e7c:	fmul	d1, d1, d2
 2407e80:	cbnz	w3, 2407eb0 <v8::base::ieee754::log(double)+0x220>
 2407e84:	fsub	d0, d0, d1
 2407e88:	ret
 2407e8c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407e90:	ldr	d4, [x0, #3000]
 2407e94:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407e98:	ldr	d2, [x0, #2992]
 2407e9c:	fmadd	d1, d19, d4, d1
 2407ea0:	fsub	d3, d3, d1
 2407ea4:	fsub	d3, d3, d0
 2407ea8:	fnmsub	d0, d19, d2, d3
 2407eac:	ret
 2407eb0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407eb4:	ldr	d3, [x0, #3000]
 2407eb8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407ebc:	ldr	d2, [x0, #2992]
 2407ec0:	fmsub	d1, d19, d3, d1
 2407ec4:	fsub	d1, d1, d0
 2407ec8:	fnmsub	d0, d19, d2, d1
 2407ecc:	ret

0000000002407ed0 <v8::base::ieee754::log1p(double)>:
 2407ed0:	fmov	x1, d0
 2407ed4:	mov	w3, #0x8279                	// #33401
 2407ed8:	fmov	d1, d0
 2407edc:	movk	w3, #0x3fda, lsl #16
 2407ee0:	lsr	x0, x1, #32
 2407ee4:	mov	w2, w0
 2407ee8:	cmp	w0, w3
 2407eec:	b.gt	2407f20 <v8::base::ieee754::log1p(double)+0x50>
 2407ef0:	and	w1, w0, #0x7fffffff
 2407ef4:	mov	w2, #0x3fefffff            	// #1072693247
 2407ef8:	cmp	w1, w2
 2407efc:	b.le	2407fb4 <v8::base::ieee754::log1p(double)+0xe4>
 2407f00:	fmov	d2, #-1.000000000000000000e+00
 2407f04:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2407f08:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
 2407f0c:	fmov	d0, x0
 2407f10:	fcmp	d1, d2
 2407f14:	fmov	d1, x1
 2407f18:	fcsel	d0, d0, d1, ne	// ne = any
 2407f1c:	ret
 2407f20:	mov	w3, #0x7fefffff            	// #2146435071
 2407f24:	cmp	w0, w3
 2407f28:	b.gt	240805c <v8::base::ieee754::log1p(double)+0x18c>
 2407f2c:	mov	w3, #0x433fffff            	// #1128267775
 2407f30:	cmp	w0, w3
 2407f34:	b.le	24080b0 <v8::base::ieee754::log1p(double)+0x1e0>
 2407f38:	asr	w0, w0, #20
 2407f3c:	movi	d5, #0x0
 2407f40:	sub	w0, w0, #0x3ff
 2407f44:	mov	w3, #0xa09d                	// #41117
 2407f48:	and	w2, w2, #0xfffff
 2407f4c:	and	x1, x1, #0xffffffff
 2407f50:	movk	w3, #0x6, lsl #16
 2407f54:	cmp	w2, w3
 2407f58:	b.gt	2408090 <v8::base::ieee754::log1p(double)+0x1c0>
 2407f5c:	orr	w3, w2, #0x3ff00000
 2407f60:	sbfiz	x3, x3, #32, #32
 2407f64:	orr	x1, x3, x1
 2407f68:	fmov	d1, x1
 2407f6c:	fmov	d2, #1.000000000000000000e+00
 2407f70:	fmov	d0, #5.000000000000000000e-01
 2407f74:	fsub	d1, d1, d2
 2407f78:	fmul	d0, d1, d0
 2407f7c:	fmul	d0, d0, d1
 2407f80:	cbnz	w2, 2407fe4 <v8::base::ieee754::log1p(double)+0x114>
 2407f84:	fcmp	d1, #0.0
 2407f88:	b.ne	24080e4 <v8::base::ieee754::log1p(double)+0x214>  // b.any
 2407f8c:	movi	d0, #0x0
 2407f90:	cbz	w0, 2407f1c <v8::base::ieee754::log1p(double)+0x4c>
 2407f94:	scvtf	d1, w0
 2407f98:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407f9c:	ldr	d0, [x0, #3000]
 2407fa0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2407fa4:	ldr	d2, [x0, #2992]
 2407fa8:	fmadd	d0, d1, d0, d5
 2407fac:	fmadd	d0, d1, d2, d0
 2407fb0:	ret
 2407fb4:	mov	w2, #0x3e1fffff            	// #1042284543
 2407fb8:	cmp	w1, w2
 2407fbc:	b.le	2408064 <v8::base::ieee754::log1p(double)+0x194>
 2407fc0:	mov	w1, #0x413b                	// #16699
 2407fc4:	movk	w1, #0x402d, lsl #16
 2407fc8:	add	w0, w0, w1
 2407fcc:	cmp	w0, w1
 2407fd0:	b.ls	24080b0 <v8::base::ieee754::log1p(double)+0x1e0>  // b.plast
 2407fd4:	fmov	d0, #5.000000000000000000e-01
 2407fd8:	mov	w0, #0x0                   	// #0
 2407fdc:	fmul	d0, d1, d0
 2407fe0:	fmul	d0, d0, d1
 2407fe4:	fmov	d2, #2.000000000000000000e+00
 2407fe8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407fec:	fadd	d2, d1, d2
 2407ff0:	ldr	d19, [x1, #3048]
 2407ff4:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2407ff8:	ldr	d18, [x1, #3072]
 2407ffc:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408000:	fdiv	d2, d1, d2
 2408004:	ldr	d17, [x1, #3056]
 2408008:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240800c:	ldr	d16, [x1, #3080]
 2408010:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408014:	ldr	d7, [x1, #3064]
 2408018:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240801c:	ldr	d6, [x1, #3096]
 2408020:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408024:	ldr	d4, [x1, #3088]
 2408028:	fmul	d3, d2, d2
 240802c:	fmadd	d18, d3, d19, d18
 2408030:	fmadd	d17, d18, d3, d17
 2408034:	fmadd	d16, d17, d3, d16
 2408038:	fmadd	d7, d16, d3, d7
 240803c:	fmadd	d6, d7, d3, d6
 2408040:	fmadd	d4, d6, d3, d4
 2408044:	fmadd	d3, d4, d3, d0
 2408048:	fmul	d2, d2, d3
 240804c:	cbnz	w0, 2408104 <v8::base::ieee754::log1p(double)+0x234>
 2408050:	fsub	d0, d0, d2
 2408054:	fsub	d0, d1, d0
 2408058:	ret
 240805c:	fadd	d0, d0, d0
 2408060:	ret
 2408064:	mov	x0, #0x4350000000000000    	// #4850376798678024192
 2408068:	fmov	d2, x0
 240806c:	mov	w0, #0x3c8fffff            	// #1016070143
 2408070:	fadd	d1, d0, d2
 2408074:	fcmpe	d1, #0.0
 2408078:	ccmp	w1, w0, #0x0, gt
 240807c:	b.le	2407f1c <v8::base::ieee754::log1p(double)+0x4c>
 2408080:	fmul	d2, d0, d0
 2408084:	fmov	d1, #5.000000000000000000e-01
 2408088:	fmsub	d0, d2, d1, d0
 240808c:	ret
 2408090:	orr	w3, w2, #0x3fe00000
 2408094:	mov	w4, #0x100000              	// #1048576
 2408098:	sub	w2, w4, w2
 240809c:	add	w0, w0, #0x1
 24080a0:	orr	x1, x1, x3, lsl #32
 24080a4:	fmov	d1, x1
 24080a8:	asr	w2, w2, #2
 24080ac:	b	2407f6c <v8::base::ieee754::log1p(double)+0x9c>
 24080b0:	fmov	d5, #1.000000000000000000e+00
 24080b4:	fadd	d0, d1, d5
 24080b8:	fmov	x1, d0
 24080bc:	lsr	x0, x1, #32
 24080c0:	mov	w2, w0
 24080c4:	asr	w0, w0, #20
 24080c8:	sub	w0, w0, #0x3ff
 24080cc:	cmp	w0, #0x0
 24080d0:	b.le	2408158 <v8::base::ieee754::log1p(double)+0x288>
 24080d4:	fsub	d1, d0, d1
 24080d8:	fsub	d5, d5, d1
 24080dc:	fdiv	d5, d5, d0
 24080e0:	b	2407f44 <v8::base::ieee754::log1p(double)+0x74>
 24080e4:	mov	x1, #0x5555555555555555    	// #6148914691236517205
 24080e8:	movk	x1, #0x3fe5, lsl #48
 24080ec:	fmov	d3, x1
 24080f0:	fmsub	d2, d1, d3, d2
 24080f4:	fmul	d2, d2, d0
 24080f8:	cbnz	w0, 2408130 <v8::base::ieee754::log1p(double)+0x260>
 24080fc:	fsub	d0, d1, d2
 2408100:	ret
 2408104:	scvtf	d4, w0
 2408108:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240810c:	ldr	d3, [x0, #3000]
 2408110:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408114:	ldr	d6, [x0, #2992]
 2408118:	fmadd	d3, d4, d3, d5
 240811c:	fadd	d2, d3, d2
 2408120:	fsub	d0, d0, d2
 2408124:	fsub	d0, d0, d1
 2408128:	fnmsub	d0, d4, d6, d0
 240812c:	ret
 2408130:	scvtf	d0, w0
 2408134:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408138:	ldr	d3, [x0, #3000]
 240813c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408140:	ldr	d4, [x0, #2992]
 2408144:	fmadd	d3, d0, d3, d5
 2408148:	fsub	d2, d2, d3
 240814c:	fsub	d2, d2, d1
 2408150:	fnmsub	d0, d0, d4, d2
 2408154:	ret
 2408158:	fsub	d5, d0, d5
 240815c:	fsub	d5, d1, d5
 2408160:	fdiv	d5, d5, d0
 2408164:	b	2407f44 <v8::base::ieee754::log1p(double)+0x74>
 2408168:	nop
 240816c:	nop

0000000002408170 <v8::base::ieee754::acosh(double)>:
 2408170:	fmov	x1, d0
 2408174:	mov	w2, #0x3fefffff            	// #1072693247
 2408178:	lsr	x0, x1, #32
 240817c:	cmp	w0, w2
 2408180:	b.le	24081c8 <v8::base::ieee754::acosh(double)+0x58>
 2408184:	stp	x29, x30, [sp, #-32]!
 2408188:	mov	w2, #0x41afffff            	// #1102053375
 240818c:	mov	x29, sp
 2408190:	stp	d8, d9, [sp, #16]
 2408194:	fmov	d8, d0
 2408198:	cmp	w0, w2
 240819c:	b.le	24081d4 <v8::base::ieee754::acosh(double)+0x64>
 24081a0:	mov	w1, #0x7fefffff            	// #2146435071
 24081a4:	cmp	w0, w1
 24081a8:	b.gt	240820c <v8::base::ieee754::acosh(double)+0x9c>
 24081ac:	bl	2407c90 <v8::base::ieee754::log(double)>
 24081b0:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 24081b4:	ldr	d1, [x0, #4032]
 24081b8:	fadd	d0, d0, d1
 24081bc:	ldp	d8, d9, [sp, #16]
 24081c0:	ldp	x29, x30, [sp], #32
 24081c4:	ret
 24081c8:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 24081cc:	fmov	d0, x0
 24081d0:	ret
 24081d4:	mov	w2, #0xc0100000            	// #-1072693248
 24081d8:	add	w2, w2, w0
 24081dc:	orr	w1, w2, w1
 24081e0:	cbz	w1, 2408214 <v8::base::ieee754::acosh(double)+0xa4>
 24081e4:	mov	w1, #0x40000000            	// #1073741824
 24081e8:	cmp	w0, w1
 24081ec:	b.le	240823c <v8::base::ieee754::acosh(double)+0xcc>
 24081f0:	fmov	d0, #-1.000000000000000000e+00
 24081f4:	fadd	d9, d8, d8
 24081f8:	fmadd	d0, d8, d8, d0
 24081fc:	fcmp	d0, #0.0
 2408200:	b.pl	240821c <v8::base::ieee754::acosh(double)+0xac>  // b.nfrst
 2408204:	bl	743a70 <sqrt@plt>
 2408208:	b	2408220 <v8::base::ieee754::acosh(double)+0xb0>
 240820c:	fadd	d0, d0, d0
 2408210:	b	24081bc <v8::base::ieee754::acosh(double)+0x4c>
 2408214:	movi	d0, #0x0
 2408218:	b	24081bc <v8::base::ieee754::acosh(double)+0x4c>
 240821c:	fsqrt	d0, d0
 2408220:	fadd	d8, d8, d0
 2408224:	fmov	d0, #1.000000000000000000e+00
 2408228:	fdiv	d0, d0, d8
 240822c:	fsub	d0, d9, d0
 2408230:	ldp	d8, d9, [sp, #16]
 2408234:	ldp	x29, x30, [sp], #32
 2408238:	b	2407c90 <v8::base::ieee754::log(double)>
 240823c:	fmov	d0, #1.000000000000000000e+00
 2408240:	fmov	d1, #2.000000000000000000e+00
 2408244:	fsub	d8, d8, d0
 2408248:	fmul	d0, d8, d8
 240824c:	fmadd	d0, d8, d1, d0
 2408250:	fcmp	d0, #0.0
 2408254:	b.pl	2408260 <v8::base::ieee754::acosh(double)+0xf0>  // b.nfrst
 2408258:	bl	743a70 <sqrt@plt>
 240825c:	b	2408264 <v8::base::ieee754::acosh(double)+0xf4>
 2408260:	fsqrt	d0, d0
 2408264:	fadd	d0, d8, d0
 2408268:	ldp	d8, d9, [sp, #16]
 240826c:	ldp	x29, x30, [sp], #32
 2408270:	b	2407ed0 <v8::base::ieee754::log1p(double)>
 2408274:	nop
 2408278:	nop
 240827c:	nop

0000000002408280 <v8::base::ieee754::asinh(double)>:
 2408280:	fmov	x0, d0
 2408284:	stp	x29, x30, [sp, #-64]!
 2408288:	fmov	d1, d0
 240828c:	mov	x29, sp
 2408290:	str	x19, [sp, #16]
 2408294:	mov	w1, #0x7fefffff            	// #2146435071
 2408298:	lsr	x19, x0, #32
 240829c:	and	w0, w19, #0x7fffffff
 24082a0:	cmp	w0, w1
 24082a4:	b.gt	240833c <v8::base::ieee754::asinh(double)+0xbc>
 24082a8:	mov	w1, #0x3e2fffff            	// #1043333119
 24082ac:	cmp	w0, w1
 24082b0:	b.le	24082f8 <v8::base::ieee754::asinh(double)+0x78>
 24082b4:	stp	d8, d9, [sp, #32]
 24082b8:	mov	w1, #0x41b00000            	// #1102053376
 24082bc:	fabs	d8, d0
 24082c0:	cmp	w0, w1
 24082c4:	b.le	2408368 <v8::base::ieee754::asinh(double)+0xe8>
 24082c8:	fmov	d0, d8
 24082cc:	bl	2407c90 <v8::base::ieee754::log(double)>
 24082d0:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 24082d4:	ldr	d1, [x0, #4032]
 24082d8:	fadd	d0, d0, d1
 24082dc:	fneg	d1, d0
 24082e0:	cmp	w19, #0x0
 24082e4:	ldp	d8, d9, [sp, #32]
 24082e8:	fcsel	d0, d1, d0, le
 24082ec:	ldr	x19, [sp, #16]
 24082f0:	ldp	x29, x30, [sp], #64
 24082f4:	ret
 24082f8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24082fc:	fmov	d3, #1.000000000000000000e+00
 2408300:	ldr	d2, [x0, #2696]
 2408304:	fadd	d2, d0, d2
 2408308:	fcmpe	d2, d3
 240830c:	b.gt	24082ec <v8::base::ieee754::asinh(double)+0x6c>
 2408310:	stp	d8, d9, [sp, #32]
 2408314:	fabs	d8, d0
 2408318:	fmul	d1, d1, d1
 240831c:	fmov	d0, #1.000000000000000000e+00
 2408320:	fadd	d0, d1, d0
 2408324:	fcmp	d0, #0.0
 2408328:	b.pl	240834c <v8::base::ieee754::asinh(double)+0xcc>  // b.nfrst
 240832c:	str	d1, [sp, #56]
 2408330:	bl	743a70 <sqrt@plt>
 2408334:	ldr	d1, [sp, #56]
 2408338:	b	2408350 <v8::base::ieee754::asinh(double)+0xd0>
 240833c:	ldr	x19, [sp, #16]
 2408340:	fadd	d0, d0, d0
 2408344:	ldp	x29, x30, [sp], #64
 2408348:	ret
 240834c:	fsqrt	d0, d0
 2408350:	fmov	d2, #1.000000000000000000e+00
 2408354:	fadd	d0, d0, d2
 2408358:	fdiv	d0, d1, d0
 240835c:	fadd	d0, d0, d8
 2408360:	bl	2407ed0 <v8::base::ieee754::log1p(double)>
 2408364:	b	24082dc <v8::base::ieee754::asinh(double)+0x5c>
 2408368:	fmov	d0, #1.000000000000000000e+00
 240836c:	mov	w1, #0x40000000            	// #1073741824
 2408370:	fmadd	d0, d1, d1, d0
 2408374:	cmp	w0, w1
 2408378:	b.le	2408318 <v8::base::ieee754::asinh(double)+0x98>
 240837c:	fcmp	d0, #0.0
 2408380:	fadd	d9, d8, d8
 2408384:	b.pl	2408390 <v8::base::ieee754::asinh(double)+0x110>  // b.nfrst
 2408388:	bl	743a70 <sqrt@plt>
 240838c:	b	2408394 <v8::base::ieee754::asinh(double)+0x114>
 2408390:	fsqrt	d0, d0
 2408394:	fadd	d0, d0, d8
 2408398:	fmov	d1, #1.000000000000000000e+00
 240839c:	fdiv	d0, d1, d0
 24083a0:	fadd	d0, d0, d9
 24083a4:	bl	2407c90 <v8::base::ieee754::log(double)>
 24083a8:	b	24082dc <v8::base::ieee754::asinh(double)+0x5c>
 24083ac:	nop

00000000024083b0 <v8::base::ieee754::atanh(double)>:
 24083b0:	fmov	x0, d0
 24083b4:	mov	w1, #0x80000000            	// #-2147483648
 24083b8:	mov	w3, #0x3ff00000            	// #1072693248
 24083bc:	cmp	w1, w0
 24083c0:	ubfx	x2, x0, #32, #31
 24083c4:	cneg	w1, w0, ne	// ne = any
 24083c8:	orr	w1, w1, w0
 24083cc:	orr	w1, w2, w1, lsr #31
 24083d0:	cmp	w1, w3
 24083d4:	b.hi	2408444 <v8::base::ieee754::atanh(double)+0x94>  // b.pmore
 24083d8:	cmp	w2, w3
 24083dc:	b.eq	2408450 <v8::base::ieee754::atanh(double)+0xa0>  // b.none
 24083e0:	stp	x29, x30, [sp, #-16]!
 24083e4:	lsr	x5, x0, #32
 24083e8:	mov	w1, #0x3e2fffff            	// #1043333119
 24083ec:	mov	x29, sp
 24083f0:	cmp	w2, w1
 24083f4:	b.le	240846c <v8::base::ieee754::atanh(double)+0xbc>
 24083f8:	and	x0, x0, #0xffffffff
 24083fc:	sbfiz	x1, x2, #32, #32
 2408400:	orr	x0, x0, x1
 2408404:	fmov	d0, #1.000000000000000000e+00
 2408408:	fmov	d1, x0
 240840c:	mov	w0, #0x3fdfffff            	// #1071644671
 2408410:	fadd	d2, d1, d1
 2408414:	fsub	d0, d0, d1
 2408418:	cmp	w2, w0
 240841c:	b.le	2408494 <v8::base::ieee754::atanh(double)+0xe4>
 2408420:	fdiv	d0, d2, d0
 2408424:	bl	2407ed0 <v8::base::ieee754::log1p(double)>
 2408428:	fmov	d1, #5.000000000000000000e-01
 240842c:	fmul	d0, d0, d1
 2408430:	fneg	d1, d0
 2408434:	cmp	w5, #0x0
 2408438:	fcsel	d0, d1, d0, lt	// lt = tstop
 240843c:	ldp	x29, x30, [sp], #16
 2408440:	ret
 2408444:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2408448:	fmov	d0, x0
 240844c:	ret
 2408450:	fcmpe	d0, #0.0
 2408454:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
 2408458:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
 240845c:	fmov	d0, x0
 2408460:	fmov	d1, x1
 2408464:	fcsel	d0, d0, d1, gt
 2408468:	ret
 240846c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408470:	ldr	d2, [x1, #2696]
 2408474:	fadd	d1, d0, d2
 2408478:	fcmpe	d1, #0.0
 240847c:	b.gt	240843c <v8::base::ieee754::atanh(double)+0x8c>
 2408480:	and	x0, x0, #0xffffffff
 2408484:	sbfiz	x2, x2, #32, #32
 2408488:	orr	x0, x0, x2
 240848c:	fmov	d1, x0
 2408490:	fadd	d2, d1, d1
 2408494:	fmov	d3, #1.000000000000000000e+00
 2408498:	fmul	d0, d2, d1
 240849c:	fsub	d1, d3, d1
 24084a0:	fdiv	d0, d0, d1
 24084a4:	fadd	d0, d0, d2
 24084a8:	bl	2407ed0 <v8::base::ieee754::log1p(double)>
 24084ac:	fmov	d1, #5.000000000000000000e-01
 24084b0:	fmul	d0, d0, d1
 24084b4:	b	2408430 <v8::base::ieee754::atanh(double)+0x80>
 24084b8:	nop
 24084bc:	nop

00000000024084c0 <v8::base::ieee754::log2(double)>:
 24084c0:	fmov	x0, d0
 24084c4:	mov	w3, #0xfffff               	// #1048575
 24084c8:	lsr	x2, x0, #32
 24084cc:	mov	w4, w0
 24084d0:	mov	w1, w2
 24084d4:	cmp	w2, w3
 24084d8:	b.gt	24084f4 <v8::base::ieee754::log2(double)+0x34>
 24084dc:	and	w1, w2, #0x7fffffff
 24084e0:	orr	w0, w1, w0
 24084e4:	cbnz	w0, 2408614 <v8::base::ieee754::log2(double)+0x154>
 24084e8:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
 24084ec:	fmov	d0, x0
 24084f0:	ret
 24084f4:	mov	w5, #0x0                   	// #0
 24084f8:	mov	w2, #0x7fefffff            	// #2146435071
 24084fc:	cmp	w1, w2
 2408500:	b.gt	240863c <v8::base::ieee754::log2(double)+0x17c>
 2408504:	cmp	w4, #0x0
 2408508:	mov	w2, #0x3ff00000            	// #1072693248
 240850c:	movi	d0, #0x0
 2408510:	ccmp	w1, w2, #0x0, eq	// eq = none
 2408514:	b.eq	24084f0 <v8::base::ieee754::log2(double)+0x30>  // b.none
 2408518:	and	w4, w1, #0xfffff
 240851c:	fmov	d0, #1.000000000000000000e+00
 2408520:	add	w3, w4, #0x95, lsl #12
 2408524:	fmov	d5, #2.000000000000000000e+00
 2408528:	add	w3, w3, #0xf64
 240852c:	adrp	x6, 5ff1000 <icudt78_dat+0x1f92120>
 2408530:	and	w2, w3, #0x100000
 2408534:	fmov	d7, #5.000000000000000000e-01
 2408538:	eor	w2, w2, #0x3ff00000
 240853c:	ldr	d25, [x6, #3048]
 2408540:	orr	x2, x2, x4
 2408544:	adrp	x6, 5ff1000 <icudt78_dat+0x1f92120>
 2408548:	adrp	x4, 5ff1000 <icudt78_dat+0x1f92120>
 240854c:	movi	v2.2d, #0xffffffff00000000
 2408550:	bfi	x0, x2, #32, #32
 2408554:	fmov	d1, x0
 2408558:	ldr	d21, [x6, #3056]
 240855c:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2408560:	fsub	d1, d1, d0
 2408564:	ldr	d19, [x4, #3064]
 2408568:	adrp	x4, 5ff1000 <icudt78_dat+0x1f92120>
 240856c:	ldr	d18, [x2, #3088]
 2408570:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2408574:	asr	w1, w1, #20
 2408578:	ldr	d24, [x4, #3072]
 240857c:	adrp	x4, 5ff1000 <icudt78_dat+0x1f92120>
 2408580:	fadd	d5, d1, d5
 2408584:	fmul	d7, d1, d7
 2408588:	ldr	d20, [x4, #3080]
 240858c:	sub	w1, w1, #0x3ff
 2408590:	ldr	d17, [x2, #3096]
 2408594:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2408598:	add	w1, w1, w5
 240859c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24085a0:	fdiv	d5, d1, d5
 24085a4:	fmsub	d4, d7, d1, d1
 24085a8:	ldr	d16, [x2, #3104]
 24085ac:	add	w3, w1, w3, lsr #20
 24085b0:	ldr	d22, [x0, #3112]
 24085b4:	scvtf	d0, w3
 24085b8:	and	v4.8b, v4.8b, v2.8b
 24085bc:	fsub	d2, d1, d4
 24085c0:	fmadd	d23, d4, d16, d0
 24085c4:	fmsub	d2, d7, d1, d2
 24085c8:	fsub	d0, d0, d23
 24085cc:	fmadd	d0, d4, d16, d0
 24085d0:	fmul	d3, d5, d5
 24085d4:	fmul	d6, d3, d3
 24085d8:	fmadd	d21, d6, d25, d21
 24085dc:	fmadd	d20, d6, d24, d20
 24085e0:	fmadd	d19, d6, d21, d19
 24085e4:	fmadd	d17, d6, d20, d17
 24085e8:	fmadd	d18, d6, d19, d18
 24085ec:	fmul	d3, d3, d18
 24085f0:	fmadd	d3, d6, d17, d3
 24085f4:	fmadd	d3, d7, d1, d3
 24085f8:	fmadd	d1, d5, d3, d2
 24085fc:	fadd	d4, d4, d1
 2408600:	fmul	d1, d1, d16
 2408604:	fmadd	d1, d4, d22, d1
 2408608:	fadd	d0, d0, d1
 240860c:	fadd	d0, d0, d23
 2408610:	ret
 2408614:	tbnz	w2, #31, 2408644 <v8::base::ieee754::log2(double)+0x184>
 2408618:	mov	x0, #0x4350000000000000    	// #4850376798678024192
 240861c:	fmov	d1, x0
 2408620:	mov	w5, #0xffffffca            	// #-54
 2408624:	mov	w2, #0x7fefffff            	// #2146435071
 2408628:	fmul	d0, d0, d1
 240862c:	fmov	x0, d0
 2408630:	lsr	x1, x0, #32
 2408634:	cmp	w1, w2
 2408638:	b.le	2408504 <v8::base::ieee754::log2(double)+0x44>
 240863c:	fadd	d0, d0, d0
 2408640:	ret
 2408644:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2408648:	fmov	d0, x0
 240864c:	ret

0000000002408650 <v8::base::ieee754::log10(double)>:
 2408650:	fmov	x0, d0
 2408654:	mov	w4, #0xfffff               	// #1048575
 2408658:	lsr	x1, x0, #32
 240865c:	cmp	w1, w4
 2408660:	b.gt	240867c <v8::base::ieee754::log10(double)+0x2c>
 2408664:	and	w2, w1, #0x7fffffff
 2408668:	orr	w0, w2, w0
 240866c:	cbnz	w0, 240870c <v8::base::ieee754::log10(double)+0xbc>
 2408670:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
 2408674:	fmov	d0, x0
 2408678:	ret
 240867c:	mov	w2, w1
 2408680:	mov	w3, w0
 2408684:	mov	w4, #0x0                   	// #0
 2408688:	mov	w0, #0x7fefffff            	// #2146435071
 240868c:	cmp	w2, w0
 2408690:	b.gt	2408738 <v8::base::ieee754::log10(double)+0xe8>
 2408694:	cmp	w3, #0x0
 2408698:	mov	w0, #0x3ff00000            	// #1072693248
 240869c:	movi	d0, #0x0
 24086a0:	ccmp	w2, w0, #0x0, eq	// eq = none
 24086a4:	b.eq	2408740 <v8::base::ieee754::log10(double)+0xf0>  // b.none
 24086a8:	asr	w0, w2, #20
 24086ac:	mov	w1, #0x3ff                 	// #1023
 24086b0:	sub	w0, w0, #0x3ff
 24086b4:	stp	x29, x30, [sp, #-16]!
 24086b8:	add	w0, w0, w4
 24086bc:	mov	x29, sp
 24086c0:	lsr	w4, w0, #31
 24086c4:	sub	w1, w1, w4
 24086c8:	add	w0, w0, w4
 24086cc:	bfi	w2, w1, #20, #12
 24086d0:	scvtf	d20, w0
 24086d4:	orr	x0, x3, x2, lsl #32
 24086d8:	fmov	d0, x0
 24086dc:	bl	2407c90 <v8::base::ieee754::log(double)>
 24086e0:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 24086e4:	ldp	x29, x30, [sp], #16
 24086e8:	ldr	d3, [x0, #4048]
 24086ec:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24086f0:	ldr	d2, [x0, #3120]
 24086f4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24086f8:	fmul	d0, d0, d3
 24086fc:	ldr	d1, [x0, #3128]
 2408700:	fmadd	d0, d20, d2, d0
 2408704:	fmadd	d0, d20, d1, d0
 2408708:	ret
 240870c:	tbnz	w1, #31, 2408744 <v8::base::ieee754::log10(double)+0xf4>
 2408710:	mov	x0, #0x4350000000000000    	// #4850376798678024192
 2408714:	fmov	d1, x0
 2408718:	mov	w4, #0xffffffca            	// #-54
 240871c:	fmul	d0, d0, d1
 2408720:	fmov	x0, d0
 2408724:	lsr	x2, x0, #32
 2408728:	mov	w3, w0
 240872c:	mov	w0, #0x7fefffff            	// #2146435071
 2408730:	cmp	w2, w0
 2408734:	b.le	2408694 <v8::base::ieee754::log10(double)+0x44>
 2408738:	fadd	d0, d0, d0
 240873c:	ret
 2408740:	ret
 2408744:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
 2408748:	fmov	d0, x0
 240874c:	ret

0000000002408750 <v8::base::ieee754::expm1(double)>:
 2408750:	fmov	x1, d0
 2408754:	mov	w2, #0x6879                	// #26745
 2408758:	fmov	d2, d0
 240875c:	movk	w2, #0x4043, lsl #16
 2408760:	ubfx	x0, x1, #32, #31
 2408764:	lsr	x3, x1, #32
 2408768:	cmp	w0, w2
 240876c:	b.ls	24087a0 <v8::base::ieee754::expm1(double)+0x50>  // b.plast
 2408770:	mov	w2, #0x2e41                	// #11841
 2408774:	movk	w2, #0x4086, lsl #16
 2408778:	cmp	w0, w2
 240877c:	b.ls	24088a0 <v8::base::ieee754::expm1(double)+0x150>  // b.plast
 2408780:	mov	w2, #0x7fefffff            	// #2146435071
 2408784:	cmp	w0, w2
 2408788:	b.ls	2408890 <v8::base::ieee754::expm1(double)+0x140>  // b.plast
 240878c:	and	w0, w3, #0xfffff
 2408790:	orr	w0, w0, w1
 2408794:	cbz	w0, 2408a24 <v8::base::ieee754::expm1(double)+0x2d4>
 2408798:	fadd	d0, d0, d0
 240879c:	ret
 24087a0:	mov	w1, #0x2e42                	// #11842
 24087a4:	movk	w1, #0x3fd6, lsl #16
 24087a8:	cmp	w0, w1
 24087ac:	b.hi	24088b8 <v8::base::ieee754::expm1(double)+0x168>  // b.pmore
 24087b0:	mov	w1, #0x3c8fffff            	// #1016070143
 24087b4:	cmp	w0, w1
 24087b8:	b.ls	24088f4 <v8::base::ieee754::expm1(double)+0x1a4>  // b.plast
 24087bc:	mov	w1, #0x0                   	// #0
 24087c0:	fmov	d18, #5.000000000000000000e-01
 24087c4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24087c8:	fmov	d19, #1.000000000000000000e+00
 24087cc:	fmov	d4, #3.000000000000000000e+00
 24087d0:	fmul	d17, d2, d18
 24087d4:	ldr	d20, [x0, #3152]
 24087d8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24087dc:	fmov	d5, #6.000000000000000000e+00
 24087e0:	ldr	d16, [x0, #3160]
 24087e4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24087e8:	fmul	d1, d17, d2
 24087ec:	ldr	d7, [x0, #3168]
 24087f0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24087f4:	ldr	d6, [x0, #3176]
 24087f8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24087fc:	fmadd	d16, d1, d20, d16
 2408800:	ldr	d0, [x0, #3184]
 2408804:	fmadd	d7, d16, d1, d7
 2408808:	fmadd	d6, d7, d1, d6
 240880c:	fmadd	d0, d6, d1, d0
 2408810:	fmadd	d0, d0, d1, d19
 2408814:	fmsub	d4, d17, d0, d4
 2408818:	fmsub	d5, d4, d2, d5
 240881c:	fsub	d0, d0, d4
 2408820:	fdiv	d0, d0, d5
 2408824:	fmul	d0, d0, d1
 2408828:	cbz	w1, 2408990 <v8::base::ieee754::expm1(double)+0x240>
 240882c:	fsub	d0, d0, d3
 2408830:	fnmsub	d3, d0, d2, d3
 2408834:	fsub	d3, d3, d1
 2408838:	cmn	w1, #0x1
 240883c:	b.eq	24089cc <v8::base::ieee754::expm1(double)+0x27c>  // b.none
 2408840:	cmp	w1, #0x1
 2408844:	b.eq	24089b0 <v8::base::ieee754::expm1(double)+0x260>  // b.none
 2408848:	mov	w2, #0x3ff00000            	// #1072693248
 240884c:	add	w3, w1, #0x1
 2408850:	add	w0, w2, w1, lsl #20
 2408854:	fmov	d0, x0
 2408858:	shl	d1, d0, #32
 240885c:	cmp	w3, #0x39
 2408860:	b.hi	24089dc <v8::base::ieee754::expm1(double)+0x28c>  // b.pmore
 2408864:	cmp	w1, #0x13
 2408868:	b.gt	24089fc <v8::base::ieee754::expm1(double)+0x2ac>
 240886c:	mov	w0, #0x200000              	// #2097152
 2408870:	fsub	d3, d3, d2
 2408874:	asr	w0, w0, w1
 2408878:	sub	w2, w2, w0
 240887c:	fmov	d0, x2
 2408880:	shl	d0, d0, #32
 2408884:	fsub	d0, d0, d3
 2408888:	fmul	d0, d1, d0
 240888c:	ret
 2408890:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408894:	ldr	d0, [x0, #2976]
 2408898:	fcmpe	d2, d0
 240889c:	b.gt	2408964 <v8::base::ieee754::expm1(double)+0x214>
 24088a0:	tbnz	w3, #31, 2408914 <v8::base::ieee754::expm1(double)+0x1c4>
 24088a4:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 24088a8:	fmov	d1, #5.000000000000000000e-01
 24088ac:	ldr	d0, [x0, #4040]
 24088b0:	fmul	d0, d2, d0
 24088b4:	b	240893c <v8::base::ieee754::expm1(double)+0x1ec>
 24088b8:	mov	w1, #0xa2b1                	// #41649
 24088bc:	movk	w1, #0x3ff0, lsl #16
 24088c0:	cmp	w0, w1
 24088c4:	b.hi	2408978 <v8::base::ieee754::expm1(double)+0x228>  // b.pmore
 24088c8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24088cc:	ldr	d0, [x0, #2992]
 24088d0:	tbz	w3, #31, 240899c <v8::base::ieee754::expm1(double)+0x24c>
 24088d4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24088d8:	fadd	d0, d2, d0
 24088dc:	mov	w1, #0xffffffff            	// #-1
 24088e0:	ldr	d1, [x0, #3144]
 24088e4:	fsub	d2, d0, d1
 24088e8:	fsub	d0, d0, d2
 24088ec:	fsub	d3, d0, d1
 24088f0:	b	24087c0 <v8::base::ieee754::expm1(double)+0x70>
 24088f4:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24088f8:	ldr	d1, [x0, #1904]
 24088fc:	ldr	d0, [x0, #1904]
 2408900:	fadd	d1, d1, d2
 2408904:	fadd	d0, d0, d2
 2408908:	fsub	d1, d1, d0
 240890c:	fsub	d0, d2, d1
 2408910:	ret
 2408914:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408918:	fmov	d0, #-1.000000000000000000e+00
 240891c:	ldr	d1, [x0, #3136]
 2408920:	fadd	d1, d2, d1
 2408924:	fcmpe	d1, #0.0
 2408928:	b.mi	240879c <v8::base::ieee754::expm1(double)+0x4c>  // b.first
 240892c:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2408930:	ldr	d0, [x0, #4040]
 2408934:	fmul	d0, d2, d0
 2408938:	fmov	d1, #-5.000000000000000000e-01
 240893c:	fadd	d1, d1, d0
 2408940:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408944:	ldr	d0, [x0, #2992]
 2408948:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240894c:	fcvtzs	w1, d1
 2408950:	ldr	d3, [x0, #3000]
 2408954:	scvtf	d1, w1
 2408958:	fmsub	d0, d1, d0, d2
 240895c:	fmul	d1, d1, d3
 2408960:	b	24088e4 <v8::base::ieee754::expm1(double)+0x194>
 2408964:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2408968:	ldr	d0, [x0, #1904]
 240896c:	ldr	d1, [x0, #1904]
 2408970:	fmul	d0, d0, d1
 2408974:	ret
 2408978:	adrp	x0, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 240897c:	fmov	d1, #5.000000000000000000e-01
 2408980:	ldr	d0, [x0, #4040]
 2408984:	fmul	d0, d2, d0
 2408988:	tbz	w3, #31, 240893c <v8::base::ieee754::expm1(double)+0x1ec>
 240898c:	b	2408938 <v8::base::ieee754::expm1(double)+0x1e8>
 2408990:	fnmsub	d1, d0, d2, d1
 2408994:	fsub	d0, d2, d1
 2408998:	ret
 240899c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24089a0:	fsub	d0, d2, d0
 24089a4:	mov	w1, #0x1                   	// #1
 24089a8:	ldr	d1, [x0, #3000]
 24089ac:	b	24088e4 <v8::base::ieee754::expm1(double)+0x194>
 24089b0:	fmov	d0, #-2.500000000000000000e-01
 24089b4:	fcmpe	d2, d0
 24089b8:	b.mi	2408a34 <v8::base::ieee754::expm1(double)+0x2e4>  // b.first
 24089bc:	fsub	d3, d2, d3
 24089c0:	fmov	d1, #2.000000000000000000e+00
 24089c4:	fmadd	d0, d3, d1, d19
 24089c8:	ret
 24089cc:	fsub	d3, d2, d3
 24089d0:	fmov	d1, #-5.000000000000000000e-01
 24089d4:	fmadd	d0, d3, d18, d1
 24089d8:	ret
 24089dc:	fsub	d3, d3, d2
 24089e0:	fsub	d3, d19, d3
 24089e4:	cmp	w1, #0x400
 24089e8:	b.eq	2408a48 <v8::base::ieee754::expm1(double)+0x2f8>  // b.none
 24089ec:	fmul	d0, d1, d3
 24089f0:	fmov	d1, #1.000000000000000000e+00
 24089f4:	fsub	d0, d0, d1
 24089f8:	ret
 24089fc:	mov	w0, #0x3ff                 	// #1023
 2408a00:	sub	w0, w0, w1
 2408a04:	lsl	w0, w0, #20
 2408a08:	fmov	d0, x0
 2408a0c:	shl	d0, d0, #32
 2408a10:	fadd	d3, d3, d0
 2408a14:	fsub	d2, d2, d3
 2408a18:	fadd	d2, d2, d19
 2408a1c:	fmul	d0, d1, d2
 2408a20:	ret
 2408a24:	cmp	w3, #0x0
 2408a28:	fmov	d1, #-1.000000000000000000e+00
 2408a2c:	fcsel	d0, d0, d1, ge	// ge = tcont
 2408a30:	ret
 2408a34:	fadd	d18, d2, d18
 2408a38:	fmov	d1, #-2.000000000000000000e+00
 2408a3c:	fsub	d3, d3, d18
 2408a40:	fmul	d0, d3, d1
 2408a44:	ret
 2408a48:	fadd	d3, d3, d3
 2408a4c:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
 2408a50:	fmov	d1, x0
 2408a54:	fmul	d0, d3, d1
 2408a58:	b	24089f0 <v8::base::ieee754::expm1(double)+0x2a0>
 2408a5c:	nop

0000000002408a60 <v8::base::ieee754::cbrt(double)>:
 2408a60:	fmov	x1, d0
 2408a64:	fmov	d3, d0
 2408a68:	mov	w3, #0x7fefffff            	// #2146435071
 2408a6c:	ubfx	x0, x1, #32, #31
 2408a70:	lsr	x2, x1, #32
 2408a74:	cmp	w0, w3
 2408a78:	b.hi	2408b64 <v8::base::ieee754::cbrt(double)+0x104>  // b.pmore
 2408a7c:	and	w3, w2, #0x80000000
 2408a80:	tst	x2, #0x7ff00000
 2408a84:	b.ne	2408ab8 <v8::base::ieee754::cbrt(double)+0x58>  // b.any
 2408a88:	orr	w0, w0, w1
 2408a8c:	cbz	w0, 2408b60 <v8::base::ieee754::cbrt(double)+0x100>
 2408a90:	mov	x0, #0x4350000000000000    	// #4850376798678024192
 2408a94:	fmov	d1, x0
 2408a98:	mov	w2, #0xaaab                	// #43691
 2408a9c:	mov	w1, #0x7893                	// #30867
 2408aa0:	fmul	d1, d0, d1
 2408aa4:	movk	w2, #0xaaaa, lsl #16
 2408aa8:	movk	w1, #0x297f, lsl #16
 2408aac:	fmov	x0, d1
 2408ab0:	ubfx	x0, x0, #32, #31
 2408ab4:	b	2408ac8 <v8::base::ieee754::cbrt(double)+0x68>
 2408ab8:	mov	w2, #0xaaab                	// #43691
 2408abc:	mov	w1, #0x7893                	// #30867
 2408ac0:	movk	w2, #0xaaaa, lsl #16
 2408ac4:	movk	w1, #0x2a9f, lsl #16
 2408ac8:	umull	x0, w0, w2
 2408acc:	fmov	d4, #2.000000000000000000e+00
 2408ad0:	lsr	x0, x0, #33
 2408ad4:	add	w0, w0, w1
 2408ad8:	orr	w0, w0, w3
 2408adc:	fmov	d0, x0
 2408ae0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ae4:	shl	d1, d0, #32
 2408ae8:	ldr	d16, [x0, #3192]
 2408aec:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408af0:	ldr	d7, [x0, #3200]
 2408af4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408af8:	fdiv	d17, d1, d3
 2408afc:	fmul	d0, d1, d1
 2408b00:	ldr	d6, [x0, #3208]
 2408b04:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408b08:	ldr	d5, [x0, #3216]
 2408b0c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408b10:	ldr	d2, [x0, #3224]
 2408b14:	mov	x0, #0x80000000            	// #2147483648
 2408b18:	fmul	d0, d0, d17
 2408b1c:	fmadd	d7, d0, d16, d7
 2408b20:	fmadd	d5, d0, d6, d5
 2408b24:	fmul	d6, d0, d0
 2408b28:	fmul	d6, d6, d0
 2408b2c:	fmadd	d2, d7, d0, d2
 2408b30:	fmadd	d2, d6, d5, d2
 2408b34:	fmul	d1, d2, d1
 2408b38:	fmov	x1, d1
 2408b3c:	add	x0, x1, x0
 2408b40:	and	x0, x0, #0xffffffffc0000000
 2408b44:	fmov	d1, x0
 2408b48:	fmul	d0, d1, d1
 2408b4c:	fdiv	d3, d3, d0
 2408b50:	fmadd	d0, d1, d4, d3
 2408b54:	fsub	d3, d3, d1
 2408b58:	fdiv	d3, d3, d0
 2408b5c:	fmadd	d0, d3, d1, d1
 2408b60:	ret
 2408b64:	fadd	d0, d0, d0
 2408b68:	ret
 2408b6c:	nop

0000000002408b70 <v8::base::ieee754::sin(double)>:
 2408b70:	fmov	x0, d0
 2408b74:	mov	w1, #0x21fb                	// #8699
 2408b78:	fmov	d1, d0
 2408b7c:	movk	w1, #0x3fe9, lsl #16
 2408b80:	ubfx	x0, x0, #32, #31
 2408b84:	cmp	w0, w1
 2408b88:	b.gt	2408bf4 <v8::base::ieee754::sin(double)+0x84>
 2408b8c:	mov	w1, #0x3e3fffff            	// #1044381695
 2408b90:	cmp	w0, w1
 2408b94:	b.gt	2408ba0 <v8::base::ieee754::sin(double)+0x30>
 2408b98:	fcvtzs	w0, d0
 2408b9c:	cbz	w0, 2408ce8 <v8::base::ieee754::sin(double)+0x178>
 2408ba0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ba4:	fmul	d2, d1, d1
 2408ba8:	ldr	d0, [x0, #2928]
 2408bac:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408bb0:	ldr	d7, [x0, #2936]
 2408bb4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408bb8:	fmadd	d7, d2, d0, d7
 2408bbc:	fmul	d0, d2, d1
 2408bc0:	ldr	d6, [x0, #2944]
 2408bc4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408bc8:	ldr	d5, [x0, #2952]
 2408bcc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408bd0:	ldr	d4, [x0, #2960]
 2408bd4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408bd8:	ldr	d3, [x0, #3232]
 2408bdc:	fmadd	d6, d2, d7, d6
 2408be0:	fmadd	d5, d2, d6, d5
 2408be4:	fmadd	d4, d2, d5, d4
 2408be8:	fmadd	d2, d2, d4, d3
 2408bec:	fmadd	d0, d0, d2, d1
 2408bf0:	ret
 2408bf4:	mov	w1, #0x7fefffff            	// #2146435071
 2408bf8:	cmp	w0, w1
 2408bfc:	b.le	2408c08 <v8::base::ieee754::sin(double)+0x98>
 2408c00:	fsub	d0, d0, d0
 2408c04:	ret
 2408c08:	stp	x29, x30, [sp, #-32]!
 2408c0c:	mov	x29, sp
 2408c10:	add	x0, sp, #0x10
 2408c14:	bl	2406740 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)>
 2408c18:	and	w0, w0, #0x3
 2408c1c:	cmp	w0, #0x1
 2408c20:	b.eq	2408df4 <v8::base::ieee754::sin(double)+0x284>  // b.none
 2408c24:	cmp	w0, #0x2
 2408c28:	b.eq	2408cec <v8::base::ieee754::sin(double)+0x17c>  // b.none
 2408c2c:	cbz	w0, 2408d70 <v8::base::ieee754::sin(double)+0x200>
 2408c30:	ldp	d1, d7, [sp, #16]
 2408c34:	mov	w1, #0x3e3fffff            	// #1044381695
 2408c38:	fmov	x0, d1
 2408c3c:	ubfx	x0, x0, #32, #31
 2408c40:	cmp	w0, w1
 2408c44:	b.le	2408f18 <v8::base::ieee754::sin(double)+0x3a8>
 2408c48:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c4c:	fmul	d2, d1, d1
 2408c50:	ldr	d16, [x1, #2880]
 2408c54:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c58:	ldr	d6, [x1, #2888]
 2408c5c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c60:	fmadd	d6, d2, d16, d6
 2408c64:	ldr	d5, [x1, #2896]
 2408c68:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c6c:	ldr	d3, [x1, #2904]
 2408c70:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c74:	ldr	d0, [x1, #2912]
 2408c78:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408c7c:	ldr	d4, [x1, #2920]
 2408c80:	mov	w1, #0x3332                	// #13106
 2408c84:	fmadd	d5, d2, d6, d5
 2408c88:	movk	w1, #0x3fd3, lsl #16
 2408c8c:	fmadd	d3, d2, d5, d3
 2408c90:	fmadd	d0, d2, d3, d0
 2408c94:	fmadd	d4, d2, d0, d4
 2408c98:	fmul	d4, d2, d4
 2408c9c:	cmp	w0, w1
 2408ca0:	b.le	2408f70 <v8::base::ieee754::sin(double)+0x400>
 2408ca4:	mov	w1, #0x3fe90000            	// #1072234496
 2408ca8:	cmp	w0, w1
 2408cac:	b.gt	2408f9c <v8::base::ieee754::sin(double)+0x42c>
 2408cb0:	sub	w0, w0, #0x200, lsl #12
 2408cb4:	fmov	d3, x0
 2408cb8:	fmov	d0, #1.000000000000000000e+00
 2408cbc:	shl	d3, d3, #32
 2408cc0:	fsub	d0, d0, d3
 2408cc4:	fmov	d5, #5.000000000000000000e-01
 2408cc8:	fmul	d1, d1, d7
 2408ccc:	fnmsub	d1, d2, d4, d1
 2408cd0:	fnmsub	d3, d2, d5, d3
 2408cd4:	fsub	d3, d3, d1
 2408cd8:	fsub	d0, d0, d3
 2408cdc:	fneg	d0, d0
 2408ce0:	ldp	x29, x30, [sp], #32
 2408ce4:	ret
 2408ce8:	ret
 2408cec:	ldp	d0, d2, [sp, #16]
 2408cf0:	mov	w0, #0x3e3fffff            	// #1044381695
 2408cf4:	fmov	x1, d0
 2408cf8:	ubfx	x1, x1, #32, #31
 2408cfc:	cmp	w1, w0
 2408d00:	b.gt	2408d0c <v8::base::ieee754::sin(double)+0x19c>
 2408d04:	fcvtzs	w0, d0
 2408d08:	cbz	w0, 2408cdc <v8::base::ieee754::sin(double)+0x16c>
 2408d0c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d10:	fmul	d3, d0, d0
 2408d14:	fmov	d17, #5.000000000000000000e-01
 2408d18:	ldr	d7, [x0, #2928]
 2408d1c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d20:	ldr	d6, [x0, #2936]
 2408d24:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d28:	fmadd	d6, d3, d7, d6
 2408d2c:	fmul	d7, d0, d3
 2408d30:	ldr	d5, [x0, #2944]
 2408d34:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d38:	ldr	d4, [x0, #2952]
 2408d3c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d40:	ldr	d1, [x0, #2960]
 2408d44:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d48:	ldr	d16, [x0, #2968]
 2408d4c:	fmadd	d5, d3, d6, d5
 2408d50:	fmadd	d4, d3, d5, d4
 2408d54:	fmadd	d1, d3, d4, d1
 2408d58:	fmul	d1, d7, d1
 2408d5c:	fnmsub	d1, d2, d17, d1
 2408d60:	fnmsub	d2, d3, d1, d2
 2408d64:	fmadd	d2, d7, d16, d2
 2408d68:	fsub	d0, d0, d2
 2408d6c:	b	2408cdc <v8::base::ieee754::sin(double)+0x16c>
 2408d70:	ldp	d0, d2, [sp, #16]
 2408d74:	mov	w0, #0x3e3fffff            	// #1044381695
 2408d78:	fmov	x1, d0
 2408d7c:	ubfx	x1, x1, #32, #31
 2408d80:	cmp	w1, w0
 2408d84:	b.gt	2408d90 <v8::base::ieee754::sin(double)+0x220>
 2408d88:	fcvtzs	w0, d0
 2408d8c:	cbz	w0, 2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408d90:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408d94:	fmul	d3, d0, d0
 2408d98:	fmov	d17, #5.000000000000000000e-01
 2408d9c:	ldr	d7, [x0, #2928]
 2408da0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408da4:	ldr	d6, [x0, #2936]
 2408da8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408dac:	fmadd	d6, d3, d7, d6
 2408db0:	fmul	d7, d0, d3
 2408db4:	ldr	d5, [x0, #2944]
 2408db8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408dbc:	ldr	d4, [x0, #2952]
 2408dc0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408dc4:	ldr	d1, [x0, #2960]
 2408dc8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408dcc:	ldr	d16, [x0, #2968]
 2408dd0:	fmadd	d5, d3, d6, d5
 2408dd4:	fmadd	d4, d3, d5, d4
 2408dd8:	fmadd	d1, d3, d4, d1
 2408ddc:	fmul	d1, d7, d1
 2408de0:	fnmsub	d1, d2, d17, d1
 2408de4:	fnmsub	d2, d3, d1, d2
 2408de8:	fmadd	d2, d7, d16, d2
 2408dec:	fsub	d0, d0, d2
 2408df0:	b	2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408df4:	ldp	d1, d7, [sp, #16]
 2408df8:	mov	w1, #0x3e3fffff            	// #1044381695
 2408dfc:	fmov	x0, d1
 2408e00:	ubfx	x0, x0, #32, #31
 2408e04:	cmp	w0, w1
 2408e08:	b.le	2408ea4 <v8::base::ieee754::sin(double)+0x334>
 2408e0c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e10:	fmul	d2, d1, d1
 2408e14:	ldr	d16, [x1, #2880]
 2408e18:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e1c:	ldr	d6, [x1, #2888]
 2408e20:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e24:	fmadd	d6, d2, d16, d6
 2408e28:	ldr	d5, [x1, #2896]
 2408e2c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e30:	ldr	d3, [x1, #2904]
 2408e34:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e38:	ldr	d0, [x1, #2912]
 2408e3c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2408e40:	ldr	d4, [x1, #2920]
 2408e44:	mov	w1, #0x3332                	// #13106
 2408e48:	fmadd	d5, d2, d6, d5
 2408e4c:	movk	w1, #0x3fd3, lsl #16
 2408e50:	fmadd	d3, d2, d5, d3
 2408e54:	fmadd	d0, d2, d3, d0
 2408e58:	fmadd	d4, d2, d0, d4
 2408e5c:	fmul	d4, d2, d4
 2408e60:	cmp	w0, w1
 2408e64:	b.le	2408efc <v8::base::ieee754::sin(double)+0x38c>
 2408e68:	mov	w1, #0x3fe90000            	// #1072234496
 2408e6c:	cmp	w0, w1
 2408e70:	b.gt	2408f90 <v8::base::ieee754::sin(double)+0x420>
 2408e74:	sub	w0, w0, #0x200, lsl #12
 2408e78:	fmov	d3, x0
 2408e7c:	fmov	d0, #1.000000000000000000e+00
 2408e80:	shl	d3, d3, #32
 2408e84:	fsub	d0, d0, d3
 2408e88:	fmov	d5, #5.000000000000000000e-01
 2408e8c:	fmul	d1, d1, d7
 2408e90:	fnmsub	d1, d2, d4, d1
 2408e94:	fnmsub	d3, d2, d5, d3
 2408e98:	fsub	d3, d3, d1
 2408e9c:	fsub	d0, d0, d3
 2408ea0:	b	2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408ea4:	fcvtzs	w0, d1
 2408ea8:	fmov	d0, #1.000000000000000000e+00
 2408eac:	cbz	w0, 2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408eb0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408eb4:	fmul	d2, d1, d1
 2408eb8:	ldr	d16, [x0, #2880]
 2408ebc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ec0:	ldr	d6, [x0, #2888]
 2408ec4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ec8:	fmadd	d6, d2, d16, d6
 2408ecc:	ldr	d5, [x0, #2896]
 2408ed0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ed4:	ldr	d3, [x0, #2904]
 2408ed8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408edc:	ldr	d0, [x0, #2912]
 2408ee0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408ee4:	ldr	d4, [x0, #2920]
 2408ee8:	fmadd	d5, d2, d6, d5
 2408eec:	fmadd	d3, d2, d5, d3
 2408ef0:	fmadd	d0, d2, d3, d0
 2408ef4:	fmadd	d4, d2, d0, d4
 2408ef8:	fmul	d4, d2, d4
 2408efc:	fmul	d1, d1, d7
 2408f00:	fmov	d3, #5.000000000000000000e-01
 2408f04:	fnmsub	d1, d2, d4, d1
 2408f08:	fmov	d0, #1.000000000000000000e+00
 2408f0c:	fnmsub	d1, d2, d3, d1
 2408f10:	fsub	d0, d0, d1
 2408f14:	b	2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408f18:	fcvtzs	w0, d1
 2408f1c:	fmov	d0, #-1.000000000000000000e+00
 2408f20:	cbz	w0, 2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408f24:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f28:	fmul	d2, d1, d1
 2408f2c:	ldr	d16, [x0, #2880]
 2408f30:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f34:	ldr	d6, [x0, #2888]
 2408f38:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f3c:	fmadd	d6, d2, d16, d6
 2408f40:	ldr	d5, [x0, #2896]
 2408f44:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f48:	ldr	d3, [x0, #2904]
 2408f4c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f50:	ldr	d0, [x0, #2912]
 2408f54:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2408f58:	ldr	d4, [x0, #2920]
 2408f5c:	fmadd	d5, d6, d2, d5
 2408f60:	fmadd	d3, d5, d2, d3
 2408f64:	fmadd	d0, d3, d2, d0
 2408f68:	fmadd	d4, d0, d2, d4
 2408f6c:	fmul	d4, d2, d4
 2408f70:	fmul	d1, d1, d7
 2408f74:	fmov	d3, #5.000000000000000000e-01
 2408f78:	fnmsub	d1, d2, d4, d1
 2408f7c:	fmov	d0, #1.000000000000000000e+00
 2408f80:	fnmsub	d1, d2, d3, d1
 2408f84:	fsub	d0, d0, d1
 2408f88:	fneg	d0, d0
 2408f8c:	b	2408ce0 <v8::base::ieee754::sin(double)+0x170>
 2408f90:	fmov	d0, #7.187500000000000000e-01
 2408f94:	fmov	d3, #2.812500000000000000e-01
 2408f98:	b	2408e88 <v8::base::ieee754::sin(double)+0x318>
 2408f9c:	fmov	d0, #7.187500000000000000e-01
 2408fa0:	fmov	d3, #2.812500000000000000e-01
 2408fa4:	b	2408cc4 <v8::base::ieee754::sin(double)+0x154>
 2408fa8:	nop
 2408fac:	nop

0000000002408fb0 <v8::base::ieee754::tan(double)>:
 2408fb0:	fmov	x0, d0
 2408fb4:	mov	w2, #0x21fb                	// #8699
 2408fb8:	fmov	d1, d0
 2408fbc:	movk	w2, #0x3fe9, lsl #16
 2408fc0:	lsr	x1, x0, #32
 2408fc4:	and	w0, w1, #0x7fffffff
 2408fc8:	cmp	w0, w2
 2408fcc:	b.gt	24090d8 <v8::base::ieee754::tan(double)+0x128>
 2408fd0:	mov	w2, #0x3e2fffff            	// #1043333119
 2408fd4:	cmp	w0, w2
 2408fd8:	b.le	24090ec <v8::base::ieee754::tan(double)+0x13c>
 2408fdc:	mov	w2, #0x9427                	// #37927
 2408fe0:	movk	w2, #0x3fe5, lsl #16
 2408fe4:	cmp	w0, w2
 2408fe8:	b.le	2409010 <v8::base::ieee754::tan(double)+0x60>
 2408fec:	fneg	d3, d0
 2408ff0:	cmp	w1, #0x0
 2408ff4:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2408ff8:	ldr	d0, [x2, #2704]
 2408ffc:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409000:	fcsel	d1, d3, d1, lt	// lt = tstop
 2409004:	ldr	d2, [x2, #2736]
 2409008:	fsub	d0, d0, d1
 240900c:	fadd	d1, d0, d2
 2409010:	fmul	d4, d1, d1
 2409014:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409018:	movi	d3, #0x0
 240901c:	ldr	d24, [x2, #3240]
 2409020:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409024:	fmul	d0, d4, d4
 2409028:	ldr	d21, [x2, #3248]
 240902c:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409030:	fmul	d22, d1, d4
 2409034:	ldr	d23, [x2, #3256]
 2409038:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 240903c:	fmadd	d21, d0, d24, d21
 2409040:	ldr	d20, [x2, #3264]
 2409044:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409048:	fmadd	d20, d0, d23, d20
 240904c:	ldr	d19, [x2, #3272]
 2409050:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409054:	ldr	d18, [x2, #3280]
 2409058:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 240905c:	ldr	d17, [x2, #3288]
 2409060:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409064:	fmadd	d19, d0, d21, d19
 2409068:	ldr	d16, [x2, #3296]
 240906c:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409070:	fmadd	d18, d0, d20, d18
 2409074:	ldr	d7, [x2, #3304]
 2409078:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 240907c:	ldr	d6, [x2, #3312]
 2409080:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409084:	ldr	d5, [x2, #3320]
 2409088:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 240908c:	fmadd	d17, d0, d19, d17
 2409090:	ldr	d2, [x2, #3328]
 2409094:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 2409098:	fmadd	d16, d0, d18, d16
 240909c:	ldr	d23, [x2, #3336]
 24090a0:	mov	w2, #0x9427                	// #37927
 24090a4:	movk	w2, #0x3fe5, lsl #16
 24090a8:	fmadd	d7, d0, d17, d7
 24090ac:	fmadd	d6, d0, d16, d6
 24090b0:	fmadd	d5, d0, d7, d5
 24090b4:	fmadd	d0, d0, d6, d2
 24090b8:	fmadd	d0, d4, d5, d0
 24090bc:	fmadd	d0, d22, d0, d3
 24090c0:	fmadd	d3, d4, d0, d3
 24090c4:	fmadd	d3, d22, d23, d3
 24090c8:	fadd	d0, d1, d3
 24090cc:	cmp	w0, w2
 24090d0:	b.gt	240926c <v8::base::ieee754::tan(double)+0x2bc>
 24090d4:	ret
 24090d8:	mov	w1, #0x7fefffff            	// #2146435071
 24090dc:	cmp	w0, w1
 24090e0:	b.le	24090f8 <v8::base::ieee754::tan(double)+0x148>
 24090e4:	fsub	d0, d0, d0
 24090e8:	ret
 24090ec:	fcvtzs	w2, d0
 24090f0:	cbnz	w2, 2409010 <v8::base::ieee754::tan(double)+0x60>
 24090f4:	ret
 24090f8:	stp	x29, x30, [sp, #-32]!
 24090fc:	mov	x29, sp
 2409100:	add	x0, sp, #0x10
 2409104:	bl	2406740 <v8::base::ieee754::(anonymous namespace)::__ieee754_rem_pio2(double, double*)>
 2409108:	ldp	d1, d2, [sp, #16]
 240910c:	ubfiz	w2, w0, #1, #1
 2409110:	mov	w1, #0x1                   	// #1
 2409114:	sub	w2, w1, w2
 2409118:	lsl	w0, w0, #1
 240911c:	mov	w5, #0x3e2fffff            	// #1043333119
 2409120:	fmov	x3, d1
 2409124:	ubfx	x1, x3, #32, #31
 2409128:	lsr	x4, x3, #32
 240912c:	cmp	w1, w5
 2409130:	b.le	24092a8 <v8::base::ieee754::tan(double)+0x2f8>
 2409134:	mov	w0, #0x9427                	// #37927
 2409138:	movk	w0, #0x3fe5, lsl #16
 240913c:	cmp	w1, w0
 2409140:	b.le	2409170 <v8::base::ieee754::tan(double)+0x1c0>
 2409144:	tbz	w4, #31, 2409150 <v8::base::ieee754::tan(double)+0x1a0>
 2409148:	fneg	d1, d1
 240914c:	fneg	d2, d2
 2409150:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409154:	ldr	d3, [x0, #2704]
 2409158:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240915c:	ldr	d0, [x0, #2736]
 2409160:	fsub	d1, d3, d1
 2409164:	fsub	d0, d0, d2
 2409168:	movi	d2, #0x0
 240916c:	fadd	d1, d1, d0
 2409170:	fmul	d4, d1, d1
 2409174:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409178:	ldr	d25, [x0, #3240]
 240917c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409180:	fmul	d0, d4, d4
 2409184:	ldr	d21, [x0, #3248]
 2409188:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 240918c:	fmul	d22, d1, d4
 2409190:	ldr	d24, [x0, #3256]
 2409194:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409198:	fmadd	d21, d0, d25, d21
 240919c:	ldr	d20, [x0, #3264]
 24091a0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091a4:	fmadd	d20, d0, d24, d20
 24091a8:	ldr	d19, [x0, #3272]
 24091ac:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091b0:	ldr	d18, [x0, #3280]
 24091b4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091b8:	ldr	d17, [x0, #3288]
 24091bc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091c0:	fmadd	d19, d0, d21, d19
 24091c4:	ldr	d16, [x0, #3296]
 24091c8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091cc:	fmadd	d18, d0, d20, d18
 24091d0:	ldr	d7, [x0, #3304]
 24091d4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091d8:	ldr	d6, [x0, #3312]
 24091dc:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091e0:	ldr	d5, [x0, #3320]
 24091e4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091e8:	fmadd	d17, d0, d19, d17
 24091ec:	ldr	d3, [x0, #3328]
 24091f0:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24091f4:	fmadd	d16, d0, d18, d16
 24091f8:	ldr	d23, [x0, #3336]
 24091fc:	mov	w0, #0x9427                	// #37927
 2409200:	movk	w0, #0x3fe5, lsl #16
 2409204:	fmadd	d7, d0, d17, d7
 2409208:	fmadd	d6, d0, d16, d6
 240920c:	fmadd	d5, d0, d7, d5
 2409210:	fmadd	d0, d0, d6, d3
 2409214:	fmadd	d0, d4, d5, d0
 2409218:	fmadd	d0, d22, d0, d2
 240921c:	fmadd	d2, d4, d0, d2
 2409220:	fmadd	d2, d22, d23, d2
 2409224:	fadd	d0, d1, d2
 2409228:	cmp	w1, w0
 240922c:	b.gt	2409304 <v8::base::ieee754::tan(double)+0x354>
 2409230:	cmp	w2, #0x1
 2409234:	b.eq	2409264 <v8::base::ieee754::tan(double)+0x2b4>  // b.none
 2409238:	movi	v6.2d, #0xffffffff00000000
 240923c:	fmov	d5, #-1.000000000000000000e+00
 2409240:	fmov	d3, #1.000000000000000000e+00
 2409244:	and	v4.8b, v0.8b, v6.8b
 2409248:	fdiv	d0, d5, d0
 240924c:	fsub	d1, d4, d1
 2409250:	fsub	d2, d2, d1
 2409254:	and	v1.8b, v0.8b, v6.8b
 2409258:	fmadd	d3, d4, d1, d3
 240925c:	fmadd	d3, d2, d1, d3
 2409260:	fmadd	d0, d0, d3, d1
 2409264:	ldp	x29, x30, [sp], #32
 2409268:	ret
 240926c:	fmov	d4, #1.000000000000000000e+00
 2409270:	fmul	d2, d0, d0
 2409274:	fmov	d6, #2.000000000000000000e+00
 2409278:	asr	w1, w1, #30
 240927c:	fadd	d0, d0, d4
 2409280:	and	w1, w1, #0x2
 2409284:	mov	w0, #0x1                   	// #1
 2409288:	sub	w0, w0, w1
 240928c:	scvtf	d5, w0
 2409290:	fdiv	d2, d2, d0
 2409294:	fsub	d2, d2, d3
 2409298:	fsub	d2, d1, d2
 240929c:	fmsub	d4, d2, d6, d4
 24092a0:	fmul	d0, d5, d4
 24092a4:	ret
 24092a8:	fcvtzs	w5, d1
 24092ac:	cbnz	w5, 2409170 <v8::base::ieee754::tan(double)+0x1c0>
 24092b0:	mvn	w0, w0
 24092b4:	orr	w1, w1, w3
 24092b8:	and	w0, w0, #0x2
 24092bc:	orr	w0, w0, w1
 24092c0:	cbz	w0, 2409340 <v8::base::ieee754::tan(double)+0x390>
 24092c4:	fmov	d0, d1
 24092c8:	cmp	w2, #0x1
 24092cc:	b.eq	2409264 <v8::base::ieee754::tan(double)+0x2b4>  // b.none
 24092d0:	fadd	d3, d1, d2
 24092d4:	fmov	d4, #-1.000000000000000000e+00
 24092d8:	movi	v5.2d, #0xffffffff00000000
 24092dc:	fmov	d1, #1.000000000000000000e+00
 24092e0:	fdiv	d4, d4, d3
 24092e4:	and	v3.8b, v3.8b, v5.8b
 24092e8:	fsub	d0, d3, d0
 24092ec:	fsub	d0, d2, d0
 24092f0:	and	v2.8b, v4.8b, v5.8b
 24092f4:	fmadd	d1, d3, d2, d1
 24092f8:	fmadd	d1, d0, d2, d1
 24092fc:	fmadd	d0, d4, d1, d2
 2409300:	b	2409264 <v8::base::ieee754::tan(double)+0x2b4>
 2409304:	scvtf	d4, w2
 2409308:	fmul	d3, d0, d0
 240930c:	fmov	d6, #2.000000000000000000e+00
 2409310:	asr	w4, w4, #30
 2409314:	and	w4, w4, #0x2
 2409318:	mov	w0, #0x1                   	// #1
 240931c:	sub	w0, w0, w4
 2409320:	fadd	d0, d0, d4
 2409324:	scvtf	d5, w0
 2409328:	fdiv	d0, d3, d0
 240932c:	fsub	d0, d0, d2
 2409330:	fsub	d0, d1, d0
 2409334:	fmsub	d4, d0, d6, d4
 2409338:	fmul	d0, d5, d4
 240933c:	b	2409264 <v8::base::ieee754::tan(double)+0x2b4>
 2409340:	fabs	d1, d1
 2409344:	fmov	d0, #1.000000000000000000e+00
 2409348:	fdiv	d0, d0, d1
 240934c:	b	2409264 <v8::base::ieee754::tan(double)+0x2b4>

0000000002409350 <v8::base::ieee754::cosh(double)>:
 2409350:	fmov	x1, d0
 2409354:	stp	x29, x30, [sp, #-16]!
 2409358:	mov	w0, #0x2e42                	// #11842
 240935c:	mov	x29, sp
 2409360:	fmov	d1, d0
 2409364:	movk	w0, #0x3fd6, lsl #16
 2409368:	ubfx	x4, x1, #32, #31
 240936c:	fabs	d0, d0
 2409370:	cmp	w4, w0
 2409374:	b.le	24093c8 <v8::base::ieee754::cosh(double)+0x78>
 2409378:	mov	w0, #0x4035ffff            	// #1077280767
 240937c:	cmp	w4, w0
 2409380:	b.le	2409418 <v8::base::ieee754::cosh(double)+0xc8>
 2409384:	mov	w0, #0x2e41                	// #11841
 2409388:	movk	w0, #0x4086, lsl #16
 240938c:	cmp	w4, w0
 2409390:	b.le	24093fc <v8::base::ieee754::cosh(double)+0xac>
 2409394:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409398:	ldr	d2, [x0, #3344]
 240939c:	fcmpe	d0, d2
 24093a0:	b.ls	2409430 <v8::base::ieee754::cosh(double)+0xe0>  // b.plast
 24093a4:	mov	w0, #0x7fefffff            	// #2146435071
 24093a8:	cmp	w4, w0
 24093ac:	b.gt	2409410 <v8::base::ieee754::cosh(double)+0xc0>
 24093b0:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 24093b4:	ldr	d0, [x0, #1896]
 24093b8:	ldr	d1, [x0, #1896]
 24093bc:	fmul	d0, d0, d1
 24093c0:	ldp	x29, x30, [sp], #16
 24093c4:	ret
 24093c8:	bl	2408750 <v8::base::ieee754::expm1(double)>
 24093cc:	fmov	d1, d0
 24093d0:	fmov	d3, #1.000000000000000000e+00
 24093d4:	mov	w0, #0x3c7fffff            	// #1015021567
 24093d8:	fadd	d0, d0, d3
 24093dc:	cmp	w4, w0
 24093e0:	b.le	24093c0 <v8::base::ieee754::cosh(double)+0x70>
 24093e4:	fmul	d2, d1, d1
 24093e8:	fadd	d1, d0, d0
 24093ec:	ldp	x29, x30, [sp], #16
 24093f0:	fdiv	d1, d2, d1
 24093f4:	fadd	d0, d1, d3
 24093f8:	ret
 24093fc:	bl	24079b0 <v8::base::ieee754::exp(double)>
 2409400:	fmov	d1, #5.000000000000000000e-01
 2409404:	ldp	x29, x30, [sp], #16
 2409408:	fmul	d0, d0, d1
 240940c:	ret
 2409410:	fmul	d0, d1, d1
 2409414:	b	24093c0 <v8::base::ieee754::cosh(double)+0x70>
 2409418:	bl	24079b0 <v8::base::ieee754::exp(double)>
 240941c:	fmov	d2, #5.000000000000000000e-01
 2409420:	ldp	x29, x30, [sp], #16
 2409424:	fdiv	d1, d2, d0
 2409428:	fmadd	d0, d0, d2, d1
 240942c:	ret
 2409430:	fmov	d18, #5.000000000000000000e-01
 2409434:	fmul	d0, d0, d18
 2409438:	bl	24079b0 <v8::base::ieee754::exp(double)>
 240943c:	fmul	d1, d0, d18
 2409440:	fmul	d0, d1, d0
 2409444:	b	24093c0 <v8::base::ieee754::cosh(double)+0x70>
 2409448:	nop
 240944c:	nop

0000000002409450 <v8::base::ieee754::legacy::pow(double, double)>:
 2409450:	fmov	x0, d1
 2409454:	ubfx	x1, x0, #32, #31
 2409458:	orr	w2, w1, w0
 240945c:	cbz	w2, 2409494 <v8::base::ieee754::legacy::pow(double, double)+0x44>
 2409460:	fmov	x2, d0
 2409464:	fmov	d2, d0
 2409468:	mov	w3, #0x7ff00000            	// #2146435072
 240946c:	ubfx	x5, x2, #32, #31
 2409470:	lsr	x7, x2, #32
 2409474:	cmp	w5, w3
 2409478:	b.gt	240948c <v8::base::ieee754::legacy::pow(double, double)+0x3c>
 240947c:	cmp	w2, #0x0
 2409480:	ccmp	w5, w3, #0x0, ne	// ne = any
 2409484:	ccmp	w1, w3, #0x0, ne	// ne = any
 2409488:	b.le	240949c <v8::base::ieee754::legacy::pow(double, double)+0x4c>
 240948c:	fadd	d0, d2, d1
 2409490:	ret
 2409494:	fmov	d0, #1.000000000000000000e+00
 2409498:	ret
 240949c:	cmp	w0, #0x0
 24094a0:	ccmp	w1, w3, #0x0, ne	// ne = any
 24094a4:	b.eq	240948c <v8::base::ieee754::legacy::pow(double, double)+0x3c>  // b.none
 24094a8:	lsr	x6, x0, #32
 24094ac:	tbnz	w7, #31, 2409548 <v8::base::ieee754::legacy::pow(double, double)+0xf8>
 24094b0:	mov	w4, #0x0                   	// #0
 24094b4:	cbz	w0, 24095b4 <v8::base::ieee754::legacy::pow(double, double)+0x164>
 24094b8:	fabs	d0, d2
 24094bc:	cbz	w2, 2409618 <v8::base::ieee754::legacy::pow(double, double)+0x1c8>
 24094c0:	asr	w3, w7, #31
 24094c4:	add	w3, w3, #0x1
 24094c8:	sub	w2, w4, #0x1
 24094cc:	stp	x29, x30, [sp, #-48]!
 24094d0:	orr	w2, w2, w3
 24094d4:	cmp	w2, #0x0
 24094d8:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 24094dc:	mov	x29, sp
 24094e0:	ldr	d4, [x2, #3352]
 24094e4:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 24094e8:	movi	d2, #0x0
 24094ec:	mov	x3, #0x8000000000000000    	// #-9223372036854775808
 24094f0:	ldr	d6, [x2, #2696]
 24094f4:	fmov	d5, x3
 24094f8:	fmov	d3, #1.000000000000000000e+00
 24094fc:	stp	d8, d9, [sp, #16]
 2409500:	fmov	d8, #-1.000000000000000000e+00
 2409504:	fcsel	d5, d5, d2, eq	// eq = none
 2409508:	fcsel	d4, d4, d6, eq	// eq = none
 240950c:	fcsel	d8, d8, d3, eq	// eq = none
 2409510:	mov	w2, #0x41e00000            	// #1105199104
 2409514:	cmp	w1, w2
 2409518:	b.le	24096e4 <v8::base::ieee754::legacy::pow(double, double)+0x294>
 240951c:	mov	w2, #0x43f00000            	// #1139802112
 2409520:	cmp	w1, w2
 2409524:	b.le	2409a80 <v8::base::ieee754::legacy::pow(double, double)+0x630>
 2409528:	mov	w0, #0x3fefffff            	// #1072693247
 240952c:	cmp	w5, w0
 2409530:	b.gt	2409c1c <v8::base::ieee754::legacy::pow(double, double)+0x7cc>
 2409534:	fmov	d0, d2
 2409538:	tbnz	w6, #31, 2409c28 <v8::base::ieee754::legacy::pow(double, double)+0x7d8>
 240953c:	ldp	d8, d9, [sp, #16]
 2409540:	ldp	x29, x30, [sp], #48
 2409544:	ret
 2409548:	mov	w4, #0x433fffff            	// #1128267775
 240954c:	cmp	w1, w4
 2409550:	b.gt	2409638 <v8::base::ieee754::legacy::pow(double, double)+0x1e8>
 2409554:	mov	w3, #0x3fefffff            	// #1072693247
 2409558:	cmp	w1, w3
 240955c:	b.le	24095f8 <v8::base::ieee754::legacy::pow(double, double)+0x1a8>
 2409560:	asr	w3, w1, #20
 2409564:	sub	w3, w3, #0x3ff
 2409568:	cmp	w3, #0x14
 240956c:	b.le	2409b48 <v8::base::ieee754::legacy::pow(double, double)+0x6f8>
 2409570:	mov	w4, #0x34                  	// #52
 2409574:	sub	w3, w4, w3
 2409578:	lsr	w4, w0, w3
 240957c:	lsl	w3, w4, w3
 2409580:	cmp	w3, w0
 2409584:	b.eq	2409cc4 <v8::base::ieee754::legacy::pow(double, double)+0x874>  // b.none
 2409588:	cbnz	w0, 2409674 <v8::base::ieee754::legacy::pow(double, double)+0x224>
 240958c:	mov	w4, #0x0                   	// #0
 2409590:	fabs	d0, d2
 2409594:	cbz	w2, 2409618 <v8::base::ieee754::legacy::pow(double, double)+0x1c8>
 2409598:	asr	w3, w7, #31
 240959c:	add	w3, w3, #0x1
 24095a0:	orr	w2, w3, w4
 24095a4:	cbnz	w2, 24094c8 <v8::base::ieee754::legacy::pow(double, double)+0x78>
 24095a8:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 24095ac:	fmov	d0, x0
 24095b0:	ret
 24095b4:	cmp	w1, w3
 24095b8:	b.eq	2409648 <v8::base::ieee754::legacy::pow(double, double)+0x1f8>  // b.none
 24095bc:	mov	w3, #0x3ff00000            	// #1072693248
 24095c0:	cmp	w1, w3
 24095c4:	b.ne	2409a04 <v8::base::ieee754::legacy::pow(double, double)+0x5b4>  // b.any
 24095c8:	fmov	d0, d2
 24095cc:	tbz	w6, #31, 2409634 <v8::base::ieee754::legacy::pow(double, double)+0x1e4>
 24095d0:	fcmp	d2, #0.0
 24095d4:	b.ne	2409ca8 <v8::base::ieee754::legacy::pow(double, double)+0x858>  // b.any
 24095d8:	fmov	x0, d2
 24095dc:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
 24095e0:	fmov	d1, x1
 24095e4:	cmp	x0, #0x0
 24095e8:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
 24095ec:	fmov	d0, x0
 24095f0:	fcsel	d0, d1, d0, lt	// lt = tstop
 24095f4:	ret
 24095f8:	cbnz	w0, 2409674 <v8::base::ieee754::legacy::pow(double, double)+0x224>
 24095fc:	mov	w3, #0x40000000            	// #1073741824
 2409600:	cmp	w6, w3
 2409604:	b.eq	2409b74 <v8::base::ieee754::legacy::pow(double, double)+0x724>  // b.none
 2409608:	cbnz	w2, 24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>
 240960c:	fabs	d0, d0
 2409610:	mov	w4, #0x0                   	// #0
 2409614:	nop
 2409618:	cmp	w5, #0x0
 240961c:	and	w2, w7, #0x3fffffff
 2409620:	mov	w3, #0x3ff00000            	// #1072693248
 2409624:	ccmp	w2, w3, #0x4, ne	// ne = any
 2409628:	b.ne	2409598 <v8::base::ieee754::legacy::pow(double, double)+0x148>  // b.any
 240962c:	tbnz	w6, #31, 2409698 <v8::base::ieee754::legacy::pow(double, double)+0x248>
 2409630:	tbnz	w7, #31, 24096c4 <v8::base::ieee754::legacy::pow(double, double)+0x274>
 2409634:	ret
 2409638:	mov	w4, #0x2                   	// #2
 240963c:	cbnz	w0, 24094b8 <v8::base::ieee754::legacy::pow(double, double)+0x68>
 2409640:	cmp	w1, w3
 2409644:	b.ne	2409590 <v8::base::ieee754::legacy::pow(double, double)+0x140>  // b.any
 2409648:	mov	w0, #0xc0100000            	// #-1072693248
 240964c:	add	w0, w5, w0
 2409650:	orr	w0, w0, w2
 2409654:	cbz	w0, 2409b2c <v8::base::ieee754::legacy::pow(double, double)+0x6dc>
 2409658:	mov	w0, #0x3fefffff            	// #1072693247
 240965c:	cmp	w5, w0
 2409660:	b.le	2409b34 <v8::base::ieee754::legacy::pow(double, double)+0x6e4>
 2409664:	movi	d0, #0x0
 2409668:	cmp	w6, #0x0
 240966c:	fcsel	d0, d1, d0, ge	// ge = tcont
 2409670:	ret
 2409674:	cbnz	w2, 24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>
 2409678:	cmp	w5, #0x0
 240967c:	and	w0, w7, #0x3fffffff
 2409680:	mov	w1, #0x3ff00000            	// #1072693248
 2409684:	ccmp	w0, w1, #0x4, ne	// ne = any
 2409688:	b.ne	24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>  // b.any
 240968c:	fabs	d0, d2
 2409690:	mov	w4, #0x0                   	// #0
 2409694:	tbz	w6, #31, 24096c4 <v8::base::ieee754::legacy::pow(double, double)+0x274>
 2409698:	fcmp	d2, #0.0
 240969c:	b.ne	2409cb4 <v8::base::ieee754::legacy::pow(double, double)+0x864>  // b.any
 24096a0:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
 24096a4:	fmov	d0, x0
 24096a8:	tbz	w7, #31, 2409634 <v8::base::ieee754::legacy::pow(double, double)+0x1e4>
 24096ac:	b	24096c4 <v8::base::ieee754::legacy::pow(double, double)+0x274>
 24096b0:	fcmp	d2, #0.0
 24096b4:	b.ne	2409cec <v8::base::ieee754::legacy::pow(double, double)+0x89c>  // b.any
 24096b8:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
 24096bc:	mov	w4, #0x0                   	// #0
 24096c0:	fmov	d0, x0
 24096c4:	mov	w0, #0xc0100000            	// #-1072693248
 24096c8:	add	w0, w5, w0
 24096cc:	orr	w0, w0, w4
 24096d0:	cbz	w0, 24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>
 24096d4:	fneg	d1, d0
 24096d8:	cmp	w4, #0x1
 24096dc:	fcsel	d0, d1, d0, eq	// eq = none
 24096e0:	ret
 24096e4:	stp	d10, d11, [sp, #32]
 24096e8:	tst	x7, #0x7ff00000
 24096ec:	b.eq	2409b10 <v8::base::ieee754::legacy::pow(double, double)+0x6c0>  // b.none
 24096f0:	fmov	x1, d0
 24096f4:	mov	w4, #0x0                   	// #0
 24096f8:	asr	w3, w5, #20
 24096fc:	and	w5, w5, #0xfffff
 2409700:	sub	w3, w3, #0x3ff
 2409704:	orr	w2, w5, #0x3ff00000
 2409708:	add	w3, w3, w4
 240970c:	mov	w4, #0x988e                	// #39054
 2409710:	movk	w4, #0x3, lsl #16
 2409714:	cmp	w5, w4
 2409718:	b.le	2409afc <v8::base::ieee754::legacy::pow(double, double)+0x6ac>
 240971c:	mov	w4, #0xb679                	// #46713
 2409720:	movk	w4, #0xb, lsl #16
 2409724:	cmp	w5, w4
 2409728:	b.le	2409c00 <v8::base::ieee754::legacy::pow(double, double)+0x7b0>
 240972c:	movi	d7, #0x0
 2409730:	add	w3, w3, #0x1
 2409734:	sub	w2, w2, #0x100, lsl #12
 2409738:	mov	w4, #0x0                   	// #0
 240973c:	fmov	d16, #1.000000000000000000e+00
 2409740:	fmov	d21, d7
 2409744:	bfi	x1, x2, #32, #32
 2409748:	fmov	d0, x1
 240974c:	fadd	d2, d0, d16
 2409750:	fsub	d3, d0, d16
 2409754:	fcmp	d2, #0.0
 2409758:	b.ne	2409b90 <v8::base::ieee754::legacy::pow(double, double)+0x740>  // b.any
 240975c:	fmov	x1, d2
 2409760:	mov	x5, #0xfff0000000000000    	// #-4503599627370496
 2409764:	fmov	d27, x5
 2409768:	cmp	x1, #0x0
 240976c:	mov	x1, #0x7ff0000000000000    	// #9218868437227405312
 2409770:	fmov	d2, x1
 2409774:	fcsel	d27, d27, d2, lt	// lt = tstop
 2409778:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240977c:	fmul	d26, d3, d27
 2409780:	movi	v11.2d, #0xffffffff00000000
 2409784:	fmov	d6, #3.000000000000000000e+00
 2409788:	ldr	d17, [x1, #3392]
 240978c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409790:	scvtf	d18, w3
 2409794:	ldr	d10, [x1, #3400]
 2409798:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240979c:	fmul	d25, d26, d26
 24097a0:	and	v22.8b, v26.8b, v11.8b
 24097a4:	ldr	d9, [x1, #3408]
 24097a8:	asr	w1, w2, #1
 24097ac:	orr	w1, w1, #0x20000000
 24097b0:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 24097b4:	add	w1, w1, #0x80, lsl #12
 24097b8:	add	w1, w1, w4
 24097bc:	fmov	d2, x1
 24097c0:	fmadd	d10, d25, d17, d10
 24097c4:	ldr	d31, [x2, #3416]
 24097c8:	shl	d2, d2, #32
 24097cc:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 24097d0:	fadd	d19, d26, d22
 24097d4:	fmul	d30, d25, d25
 24097d8:	ldr	d29, [x2, #3424]
 24097dc:	adrp	x2, 5ff1000 <icudt78_dat+0x1f92120>
 24097e0:	fmadd	d20, d22, d22, d6
 24097e4:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24097e8:	fsub	d17, d2, d16
 24097ec:	fmsub	d3, d2, d22, d3
 24097f0:	ldr	d28, [x2, #3432]
 24097f4:	ldr	d23, [x1, #3440]
 24097f8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 24097fc:	fsub	d17, d0, d17
 2409800:	fmadd	d0, d10, d25, d9
 2409804:	ldr	d24, [x1, #3448]
 2409808:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240980c:	ldr	d16, [x1, #3456]
 2409810:	fmsub	d3, d17, d22, d3
 2409814:	fmadd	d2, d0, d25, d31
 2409818:	fmul	d3, d3, d27
 240981c:	fmadd	d2, d2, d25, d29
 2409820:	fmul	d0, d19, d3
 2409824:	fmadd	d2, d2, d25, d28
 2409828:	fmadd	d0, d30, d2, d0
 240982c:	fadd	d2, d20, d0
 2409830:	and	v2.8b, v2.8b, v11.8b
 2409834:	fsub	d6, d2, d6
 2409838:	fmsub	d6, d22, d22, d6
 240983c:	fsub	d0, d0, d6
 2409840:	fmul	d0, d0, d26
 2409844:	fmadd	d0, d2, d3, d0
 2409848:	fmadd	d6, d2, d22, d0
 240984c:	and	v6.8b, v6.8b, v11.8b
 2409850:	fmsub	d2, d2, d22, d6
 2409854:	fsub	d0, d0, d2
 2409858:	fmul	d0, d0, d23
 240985c:	fmadd	d0, d6, d24, d0
 2409860:	fadd	d0, d0, d21
 2409864:	fmadd	d3, d6, d16, d0
 2409868:	fadd	d3, d3, d7
 240986c:	fadd	d3, d3, d18
 2409870:	and	v3.8b, v3.8b, v11.8b
 2409874:	fsub	d2, d3, d18
 2409878:	fsub	d2, d2, d7
 240987c:	fmsub	d2, d6, d16, d2
 2409880:	fsub	d0, d0, d2
 2409884:	and	x0, x0, #0xffffffff00000000
 2409888:	fmov	d2, x0
 240988c:	fmul	d0, d0, d1
 2409890:	mov	w0, #0x408fffff            	// #1083179007
 2409894:	fsub	d1, d1, d2
 2409898:	fmul	d2, d2, d3
 240989c:	fmadd	d1, d1, d3, d0
 24098a0:	fadd	d3, d2, d1
 24098a4:	fmov	x1, d3
 24098a8:	lsr	x2, x1, #32
 24098ac:	cmp	w2, w0
 24098b0:	b.le	2409a30 <v8::base::ieee754::legacy::pow(double, double)+0x5e0>
 24098b4:	mov	w0, #0xbf700000            	// #-1083179008
 24098b8:	add	w0, w0, w2
 24098bc:	orr	w0, w0, w1
 24098c0:	cbnz	w0, 2409b7c <v8::base::ieee754::legacy::pow(double, double)+0x72c>
 24098c4:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 24098c8:	fsub	d3, d3, d2
 24098cc:	ldr	d0, [x0, #3464]
 24098d0:	fadd	d0, d1, d0
 24098d4:	fcmpe	d0, d3
 24098d8:	b.gt	2409b7c <v8::base::ieee754::legacy::pow(double, double)+0x72c>
 24098dc:	mov	x1, #0x4090000000000000    	// #4652218415073722368
 24098e0:	mov	w0, #0x400                 	// #1024
 24098e4:	fmov	d0, x1
 24098e8:	fsub	d2, d2, d0
 24098ec:	lsl	w3, w0, #20
 24098f0:	fadd	d0, d2, d1
 24098f4:	fmov	x1, d0
 24098f8:	and	x1, x1, #0xffffffff00000000
 24098fc:	fmov	d0, x1
 2409900:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409904:	fmov	d4, #2.000000000000000000e+00
 2409908:	fsub	d2, d0, d2
 240990c:	ldr	d3, [x1, #3472]
 2409910:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2409914:	ldr	d17, [x1, #4032]
 2409918:	mov	x1, #0x2e4300000000        	// #50865297686528
 240991c:	fsub	d1, d1, d2
 2409920:	fmul	d3, d0, d3
 2409924:	movk	x1, #0x3fe6, lsl #48
 2409928:	fmov	d5, x1
 240992c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409930:	fmadd	d2, d1, d17, d3
 2409934:	ldr	d16, [x1, #3008]
 2409938:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 240993c:	ldr	d10, [x1, #3016]
 2409940:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409944:	fmadd	d3, d0, d5, d2
 2409948:	ldr	d9, [x1, #3024]
 240994c:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409950:	ldr	d7, [x1, #3032]
 2409954:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409958:	fmsub	d1, d0, d5, d3
 240995c:	ldr	d6, [x1, #3040]
 2409960:	fmul	d0, d3, d3
 2409964:	fmadd	d5, d0, d16, d10
 2409968:	fsub	d1, d2, d1
 240996c:	fmadd	d1, d3, d1, d1
 2409970:	fmadd	d2, d0, d5, d9
 2409974:	fmadd	d2, d0, d2, d7
 2409978:	fmadd	d2, d0, d2, d6
 240997c:	fmsub	d0, d0, d2, d3
 2409980:	fsub	d2, d0, d4
 2409984:	fmul	d0, d3, d0
 2409988:	fsub	d1, d2, d1
 240998c:	fcmp	d1, #0.0
 2409990:	b.ne	2409c38 <v8::base::ieee754::legacy::pow(double, double)+0x7e8>  // b.any
 2409994:	fcmp	d0, #0.0
 2409998:	fccmp	d0, d0, #0x0, ne	// ne = any
 240999c:	b.ne	2409c40 <v8::base::ieee754::legacy::pow(double, double)+0x7f0>  // b.any
 24099a0:	fcmpe	d0, #0.0
 24099a4:	fmov	x2, d1
 24099a8:	mov	x4, #0x7ff0000000000000    	// #9218868437227405312
 24099ac:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
 24099b0:	fmov	d1, x4
 24099b4:	fmov	d0, x1
 24099b8:	cset	w4, ge	// ge = tcont
 24099bc:	cmp	x2, #0x0
 24099c0:	cset	w1, ge	// ge = tcont
 24099c4:	cmp	w4, w1
 24099c8:	fcsel	d0, d0, d1, ne	// ne = any
 24099cc:	fsub	d0, d0, d3
 24099d0:	fmov	d1, #1.000000000000000000e+00
 24099d4:	fsub	d0, d1, d0
 24099d8:	fmov	x1, d0
 24099dc:	lsr	x2, x1, #32
 24099e0:	add	w2, w3, w2
 24099e4:	asr	w3, w2, #20
 24099e8:	cmp	w3, #0x0
 24099ec:	b.le	2409c88 <v8::base::ieee754::legacy::pow(double, double)+0x838>
 24099f0:	bfi	x1, x2, #32, #32
 24099f4:	fmov	d0, x1
 24099f8:	ldp	d10, d11, [sp, #32]
 24099fc:	fmul	d0, d8, d0
 2409a00:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409a04:	mov	w3, #0x40000000            	// #1073741824
 2409a08:	cmp	w6, w3
 2409a0c:	b.eq	2409b74 <v8::base::ieee754::legacy::pow(double, double)+0x724>  // b.none
 2409a10:	cmp	w7, #0x0
 2409a14:	mov	w3, #0x3fe00000            	// #1071644672
 2409a18:	ccmp	w6, w3, #0x0, ge	// ge = tcont
 2409a1c:	b.ne	2409590 <v8::base::ieee754::legacy::pow(double, double)+0x140>  // b.any
 2409a20:	fcmp	d2, #0.0
 2409a24:	b.pl	2409c80 <v8::base::ieee754::legacy::pow(double, double)+0x830>  // b.nfrst
 2409a28:	fmov	d0, d2
 2409a2c:	b	743a70 <sqrt@plt>
 2409a30:	mov	w0, #0xcbff                	// #52223
 2409a34:	and	w4, w2, #0x7fffffff
 2409a38:	movk	w0, #0x4090, lsl #16
 2409a3c:	cmp	w4, w0
 2409a40:	b.le	2409b9c <v8::base::ieee754::legacy::pow(double, double)+0x74c>
 2409a44:	mov	w0, #0x3400                	// #13312
 2409a48:	fmov	d0, d5
 2409a4c:	movk	w0, #0x3f6f, lsl #16
 2409a50:	add	w0, w2, w0
 2409a54:	orr	w0, w0, w1
 2409a58:	cbnz	w0, 2409c90 <v8::base::ieee754::legacy::pow(double, double)+0x840>
 2409a5c:	fsub	d3, d3, d2
 2409a60:	fcmpe	d3, d1
 2409a64:	b.ge	2409c90 <v8::base::ieee754::legacy::pow(double, double)+0x840>  // b.tcont
 2409a68:	mov	x1, #0xcc0000000000        	// #224300372066304
 2409a6c:	mov	w0, #0x433                 	// #1075
 2409a70:	movk	x1, #0xc090, lsl #48
 2409a74:	neg	w0, w0
 2409a78:	fmov	d0, x1
 2409a7c:	b	24098e8 <v8::base::ieee754::legacy::pow(double, double)+0x498>
 2409a80:	mov	w1, #0x3fefffff            	// #1072693247
 2409a84:	cmp	w5, w1
 2409a88:	b.lt	2409c98 <v8::base::ieee754::legacy::pow(double, double)+0x848>  // b.tstop
 2409a8c:	mov	w1, #0x3ff00000            	// #1072693248
 2409a90:	cmp	w5, w1
 2409a94:	b.gt	2409cd8 <v8::base::ieee754::legacy::pow(double, double)+0x888>
 2409a98:	fsub	d0, d0, d3
 2409a9c:	fmov	d2, #2.500000000000000000e-01
 2409aa0:	mov	x1, #0x5555555555555555    	// #6148914691236517205
 2409aa4:	fmov	d6, #5.000000000000000000e-01
 2409aa8:	movk	x1, #0x3fd5, lsl #48
 2409aac:	fmov	d3, x1
 2409ab0:	adrp	x1, 3709000 <v8::internal::maglev::OpcodeToString(v8::internal::maglev::Opcode)::names+0x1f0>
 2409ab4:	stp	d10, d11, [sp, #32]
 2409ab8:	fmsub	d3, d0, d2, d3
 2409abc:	fmul	d2, d0, d0
 2409ac0:	ldr	d10, [x1, #4040]
 2409ac4:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409ac8:	ldr	d9, [x1, #3360]
 2409acc:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409ad0:	ldr	d7, [x1, #3368]
 2409ad4:	fmsub	d3, d0, d3, d6
 2409ad8:	movi	v6.2d, #0xffffffff00000000
 2409adc:	fmul	d2, d2, d3
 2409ae0:	fmul	d2, d2, d10
 2409ae4:	fnmsub	d2, d0, d9, d2
 2409ae8:	fmadd	d3, d0, d7, d2
 2409aec:	and	v3.8b, v3.8b, v6.8b
 2409af0:	fmsub	d0, d0, d7, d3
 2409af4:	fsub	d0, d2, d0
 2409af8:	b	2409884 <v8::base::ieee754::legacy::pow(double, double)+0x434>
 2409afc:	movi	d7, #0x0
 2409b00:	mov	w4, #0x0                   	// #0
 2409b04:	fmov	d16, #1.000000000000000000e+00
 2409b08:	fmov	d21, d7
 2409b0c:	b	2409744 <v8::base::ieee754::legacy::pow(double, double)+0x2f4>
 2409b10:	mov	x1, #0x4340000000000000    	// #4845873199050653696
 2409b14:	fmov	d2, x1
 2409b18:	mov	w4, #0xffffffcb            	// #-53
 2409b1c:	fmul	d0, d0, d2
 2409b20:	fmov	x1, d0
 2409b24:	lsr	x5, x1, #32
 2409b28:	b	24096f8 <v8::base::ieee754::legacy::pow(double, double)+0x2a8>
 2409b2c:	fsub	d0, d1, d1
 2409b30:	ret
 2409b34:	fneg	d0, d1
 2409b38:	movi	d1, #0x0
 2409b3c:	cmp	w6, #0x0
 2409b40:	fcsel	d0, d0, d1, lt	// lt = tstop
 2409b44:	ret
 2409b48:	cbnz	w0, 2409c4c <v8::base::ieee754::legacy::pow(double, double)+0x7fc>
 2409b4c:	mov	w8, #0x14                  	// #20
 2409b50:	sub	w8, w8, w3
 2409b54:	mov	w4, #0x2                   	// #2
 2409b58:	asr	w3, w1, w8
 2409b5c:	and	w9, w3, #0x1
 2409b60:	sub	w4, w4, w9
 2409b64:	lsl	w3, w3, w8
 2409b68:	cmp	w3, w1
 2409b6c:	csel	w4, w4, wzr, eq	// eq = none
 2409b70:	b	24095bc <v8::base::ieee754::legacy::pow(double, double)+0x16c>
 2409b74:	fmul	d0, d2, d2
 2409b78:	ret
 2409b7c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409b80:	ldp	d10, d11, [sp, #32]
 2409b84:	ldr	d0, [x0, #2696]
 2409b88:	fmul	d0, d4, d0
 2409b8c:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409b90:	fmov	d27, #1.000000000000000000e+00
 2409b94:	fdiv	d27, d27, d2
 2409b98:	b	2409778 <v8::base::ieee754::legacy::pow(double, double)+0x328>
 2409b9c:	mov	w5, #0x3fe00000            	// #1071644672
 2409ba0:	mov	w3, #0x0                   	// #0
 2409ba4:	mov	w0, #0x0                   	// #0
 2409ba8:	cmp	w4, w5
 2409bac:	b.le	24098f8 <v8::base::ieee754::legacy::pow(double, double)+0x4a8>
 2409bb0:	asr	w0, w4, #20
 2409bb4:	mov	w3, #0x100000              	// #1048576
 2409bb8:	sub	w0, w0, #0x3fe
 2409bbc:	mov	w1, #0xfff00000            	// #-1048576
 2409bc0:	mov	w5, #0x14                  	// #20
 2409bc4:	asr	w3, w3, w0
 2409bc8:	add	w3, w3, w2
 2409bcc:	and	w0, w3, #0xfffff
 2409bd0:	ubfx	x4, x3, #20, #11
 2409bd4:	orr	w0, w0, #0x100000
 2409bd8:	sub	w4, w4, #0x3ff
 2409bdc:	sub	w5, w5, w4
 2409be0:	asr	w1, w1, w4
 2409be4:	and	w1, w1, w3
 2409be8:	fmov	d0, x1
 2409bec:	asr	w0, w0, w5
 2409bf0:	shl	d0, d0, #32
 2409bf4:	tbz	w2, #31, 24098e8 <v8::base::ieee754::legacy::pow(double, double)+0x498>
 2409bf8:	neg	w0, w0
 2409bfc:	b	24098e8 <v8::base::ieee754::legacy::pow(double, double)+0x498>
 2409c00:	adrp	x4, 5ff1000 <icudt78_dat+0x1f92120>
 2409c04:	fmov	d16, #1.500000000000000000e+00
 2409c08:	ldr	d7, [x4, #3376]
 2409c0c:	adrp	x4, 5ff1000 <icudt78_dat+0x1f92120>
 2409c10:	ldr	d21, [x4, #3384]
 2409c14:	mov	w4, #0x40000               	// #262144
 2409c18:	b	2409744 <v8::base::ieee754::legacy::pow(double, double)+0x2f4>
 2409c1c:	fmov	d0, d2
 2409c20:	cmp	w6, #0x0
 2409c24:	b.le	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409c28:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409c2c:	ldr	d0, [x0, #2696]
 2409c30:	fmul	d0, d0, d0
 2409c34:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409c38:	fdiv	d0, d0, d1
 2409c3c:	b	24099cc <v8::base::ieee754::legacy::pow(double, double)+0x57c>
 2409c40:	mov	x1, #0x7ff8000000000000    	// #9221120237041090560
 2409c44:	fmov	d0, x1
 2409c48:	b	24099cc <v8::base::ieee754::legacy::pow(double, double)+0x57c>
 2409c4c:	cbnz	w2, 24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>
 2409c50:	and	w7, w7, #0x3fffffff
 2409c54:	cmp	w5, #0x0
 2409c58:	mov	w0, #0x3ff00000            	// #1072693248
 2409c5c:	ccmp	w7, w0, #0x4, ne	// ne = any
 2409c60:	b.ne	24095a8 <v8::base::ieee754::legacy::pow(double, double)+0x158>  // b.any
 2409c64:	fabs	d0, d0
 2409c68:	tbnz	w6, #31, 24096b0 <v8::base::ieee754::legacy::pow(double, double)+0x260>
 2409c6c:	cmp	w5, w0
 2409c70:	mov	x0, #0x7ff4000000000000    	// #9219994337134247936
 2409c74:	fmov	d1, x0
 2409c78:	fcsel	d0, d0, d1, ne	// ne = any
 2409c7c:	ret
 2409c80:	fsqrt	d0, d2
 2409c84:	ret
 2409c88:	bl	744f40 <scalbn@plt>
 2409c8c:	b	24099f8 <v8::base::ieee754::legacy::pow(double, double)+0x5a8>
 2409c90:	ldp	d10, d11, [sp, #32]
 2409c94:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409c98:	fmov	d0, d5
 2409c9c:	tbz	w6, #31, 240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409ca0:	fmul	d0, d4, d6
 2409ca4:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409ca8:	fmov	d1, #1.000000000000000000e+00
 2409cac:	fdiv	d0, d1, d2
 2409cb0:	ret
 2409cb4:	fmov	d1, #1.000000000000000000e+00
 2409cb8:	fdiv	d0, d1, d0
 2409cbc:	tbz	w7, #31, 2409634 <v8::base::ieee754::legacy::pow(double, double)+0x1e4>
 2409cc0:	b	24096c4 <v8::base::ieee754::legacy::pow(double, double)+0x274>
 2409cc4:	and	w8, w4, #0x1
 2409cc8:	mov	w4, #0x2                   	// #2
 2409ccc:	sub	w4, w4, w8
 2409cd0:	cbnz	w3, 24094b8 <v8::base::ieee754::legacy::pow(double, double)+0x68>
 2409cd4:	b	2409590 <v8::base::ieee754::legacy::pow(double, double)+0x140>
 2409cd8:	fmov	d0, d5
 2409cdc:	cmp	w6, #0x0
 2409ce0:	b.le	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409ce4:	fmul	d0, d4, d6
 2409ce8:	b	240953c <v8::base::ieee754::legacy::pow(double, double)+0xec>
 2409cec:	fmov	d1, #1.000000000000000000e+00
 2409cf0:	mov	w4, #0x0                   	// #0
 2409cf4:	fdiv	d0, d1, d0
 2409cf8:	b	24096c4 <v8::base::ieee754::legacy::pow(double, double)+0x274>
 2409cfc:	nop

0000000002409d00 <v8::base::ieee754::sinh(double)>:
 2409d00:	fcmpe	d0, #0.0
 2409d04:	fabs	d21, d0
 2409d08:	fmov	d1, #-5.000000000000000000e-01
 2409d0c:	fmov	d2, #5.000000000000000000e-01
 2409d10:	fmov	d3, #2.200000000000000000e+01
 2409d14:	stp	x29, x30, [sp, #-16]!
 2409d18:	fcsel	d22, d1, d2, mi	// mi = first
 2409d1c:	fcmpe	d21, d3
 2409d20:	mov	x29, sp
 2409d24:	b.mi	2409d60 <v8::base::ieee754::sinh(double)+0x60>  // b.first
 2409d28:	mov	x0, #0x2e4200000000        	// #50861002719232
 2409d2c:	movk	x0, #0x4086, lsl #48
 2409d30:	fmov	d1, x0
 2409d34:	fcmpe	d21, d1
 2409d38:	b.mi	2409d9c <v8::base::ieee754::sinh(double)+0x9c>  // b.first
 2409d3c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409d40:	ldr	d1, [x0, #3344]
 2409d44:	fcmpe	d21, d1
 2409d48:	b.ls	2409dd0 <v8::base::ieee754::sinh(double)+0xd0>  // b.plast
 2409d4c:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409d50:	ldr	d1, [x0, #3480]
 2409d54:	fmul	d0, d0, d1
 2409d58:	ldp	x29, x30, [sp], #16
 2409d5c:	ret
 2409d60:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
 2409d64:	fmov	d1, x0
 2409d68:	fcmpe	d21, d1
 2409d6c:	b.mi	2409d58 <v8::base::ieee754::sinh(double)+0x58>  // b.first
 2409d70:	fmov	d0, d21
 2409d74:	bl	2408750 <v8::base::ieee754::expm1(double)>
 2409d78:	fmov	d1, #1.000000000000000000e+00
 2409d7c:	fcmpe	d21, d1
 2409d80:	b.mi	2409db0 <v8::base::ieee754::sinh(double)+0xb0>  // b.first
 2409d84:	fadd	d1, d0, d1
 2409d88:	ldp	x29, x30, [sp], #16
 2409d8c:	fdiv	d1, d0, d1
 2409d90:	fadd	d0, d1, d0
 2409d94:	fmul	d0, d0, d22
 2409d98:	ret
 2409d9c:	fmov	d0, d21
 2409da0:	bl	24079b0 <v8::base::ieee754::exp(double)>
 2409da4:	fmul	d0, d0, d22
 2409da8:	ldp	x29, x30, [sp], #16
 2409dac:	ret
 2409db0:	fmul	d2, d0, d0
 2409db4:	fadd	d1, d0, d1
 2409db8:	fmov	d3, #2.000000000000000000e+00
 2409dbc:	ldp	x29, x30, [sp], #16
 2409dc0:	fdiv	d1, d2, d1
 2409dc4:	fnmsub	d0, d0, d3, d1
 2409dc8:	fmul	d0, d0, d22
 2409dcc:	ret
 2409dd0:	fmul	d0, d21, d2
 2409dd4:	bl	24079b0 <v8::base::ieee754::exp(double)>
 2409dd8:	fmul	d1, d22, d0
 2409ddc:	fmul	d0, d1, d0
 2409de0:	b	2409d58 <v8::base::ieee754::sinh(double)+0x58>
 2409de4:	nop
 2409de8:	nop
 2409dec:	nop

0000000002409df0 <v8::base::ieee754::tanh(double)>:
 2409df0:	fmov	x0, d0
 2409df4:	fmov	d1, d0
 2409df8:	mov	w1, #0x7fefffff            	// #2146435071
 2409dfc:	lsr	x4, x0, #32
 2409e00:	and	w0, w4, #0x7fffffff
 2409e04:	cmp	w0, w1
 2409e08:	b.le	2409e28 <v8::base::ieee754::tanh(double)+0x38>
 2409e0c:	fmov	d0, #1.000000000000000000e+00
 2409e10:	fdiv	d1, d0, d1
 2409e14:	tbnz	w4, #31, 2409e20 <v8::base::ieee754::tanh(double)+0x30>
 2409e18:	fadd	d0, d1, d0
 2409e1c:	ret
 2409e20:	fsub	d0, d1, d0
 2409e24:	ret
 2409e28:	mov	w1, #0x4035ffff            	// #1077280767
 2409e2c:	cmp	w0, w1
 2409e30:	b.gt	2409e88 <v8::base::ieee754::tanh(double)+0x98>
 2409e34:	stp	x29, x30, [sp, #-16]!
 2409e38:	mov	w1, #0x3e2fffff            	// #1043333119
 2409e3c:	mov	x29, sp
 2409e40:	cmp	w0, w1
 2409e44:	b.le	2409ea8 <v8::base::ieee754::tanh(double)+0xb8>
 2409e48:	fabs	d0, d0
 2409e4c:	mov	w1, #0x3fefffff            	// #1072693247
 2409e50:	cmp	w0, w1
 2409e54:	b.le	2409ec4 <v8::base::ieee754::tanh(double)+0xd4>
 2409e58:	fadd	d0, d0, d0
 2409e5c:	bl	2408750 <v8::base::ieee754::expm1(double)>
 2409e60:	fmov	d2, #2.000000000000000000e+00
 2409e64:	fmov	d1, #1.000000000000000000e+00
 2409e68:	fadd	d0, d0, d2
 2409e6c:	fdiv	d2, d2, d0
 2409e70:	fsub	d0, d1, d2
 2409e74:	fneg	d1, d0
 2409e78:	cmp	w4, #0x0
 2409e7c:	fcsel	d0, d1, d0, lt	// lt = tstop
 2409e80:	ldp	x29, x30, [sp], #16
 2409e84:	ret
 2409e88:	adrp	x0, 663d000 <aBuiltinFunc.45+0x17c0>
 2409e8c:	fmov	d0, #1.000000000000000000e+00
 2409e90:	cmp	w4, #0x0
 2409e94:	ldr	d1, [x0, #1888]
 2409e98:	fsub	d0, d0, d1
 2409e9c:	fneg	d1, d0
 2409ea0:	fcsel	d0, d1, d0, lt	// lt = tstop
 2409ea4:	ret
 2409ea8:	adrp	x0, 5ff1000 <icudt78_dat+0x1f92120>
 2409eac:	fmov	d3, #1.000000000000000000e+00
 2409eb0:	ldr	d2, [x0, #2696]
 2409eb4:	fadd	d2, d0, d2
 2409eb8:	fcmpe	d2, d3
 2409ebc:	b.gt	2409e80 <v8::base::ieee754::tanh(double)+0x90>
 2409ec0:	fabs	d0, d0
 2409ec4:	fmov	d1, #-2.000000000000000000e+00
 2409ec8:	fmul	d0, d0, d1
 2409ecc:	bl	2408750 <v8::base::ieee754::expm1(double)>
 2409ed0:	fneg	d1, d0
 2409ed4:	fmov	d2, #2.000000000000000000e+00
 2409ed8:	fadd	d0, d0, d2
 2409edc:	fdiv	d0, d1, d0
 2409ee0:	b	2409e74 <v8::base::ieee754::tanh(double)+0x84>
 2409ee4:	nop
 2409ee8:	nop
 2409eec:	nop

0000000002409ef0 <v8::base::CheckMessageStream::~CheckMessageStream()>:
 2409ef0:	stp	x29, x30, [sp, #-32]!
 2409ef4:	add	x4, x0, #0x60
 2409ef8:	adrp	x1, 5ff1000 <icudt78_dat+0x1f92120>
 2409efc:	mov	x29, sp
