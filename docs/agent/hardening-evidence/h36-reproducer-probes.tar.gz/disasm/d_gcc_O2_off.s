
bin/d_gcc_O2_off.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <__kernel_tan>:
       0:	fmov	x2, d0
       4:	fmov	d4, d0
       8:	mov	w4, #0x3e2fffff            	// #1043333119
       c:	ubfx	x1, x2, #32, #31
      10:	lsr	x3, x2, #32
      14:	cmp	w1, w4
      18:	b.gt	7c <__kernel_tan+0x7c>
      1c:	fcvtzs	w4, d0
      20:	cbnz	w4, b0 <__kernel_tan+0xb0>
      24:	add	w3, w0, #0x1
      28:	orr	w2, w3, w2
      2c:	orr	w1, w2, w1
      30:	cbz	w1, 254 <__kernel_tan+0x254>
      34:	cmp	w0, #0x1
      38:	b.eq	78 <__kernel_tan+0x78>  // b.none
      3c:	fadd	d2, d0, d1
      40:	fmov	d3, #-1.000000000000000000e+00
      44:	movi	v4.2d, #0xffffffff00000000
      48:	fmov	d5, #1.000000000000000000e+00
      4c:	fdiv	d3, d3, d2
      50:	and	v2.8b, v2.8b, v4.8b
      54:	fsub	d0, d2, d0
      58:	fsub	d1, d1, d0
      5c:	and	v4.8b, v3.8b, v4.8b
      60:	fmul	d2, d2, d4
      64:	fmul	d0, d1, d4
      68:	fadd	d2, d2, d5
      6c:	fadd	d0, d0, d2
      70:	fmul	d0, d0, d3
      74:	fadd	d0, d0, d4
      78:	ret
      7c:	mov	w2, #0x9427                	// #37927
      80:	movk	w2, #0x3fe5, lsl #16
      84:	cmp	w1, w2
      88:	b.le	b0 <__kernel_tan+0xb0>
      8c:	tbnz	w3, #31, 228 <__kernel_tan+0x228>
      90:	adrp	x2, 0 <__kernel_tan>
      94:	ldr	d0, [x2]
      98:	adrp	x2, 0 <__kernel_tan>
      9c:	ldr	d2, [x2]
      a0:	fsub	d0, d0, d4
      a4:	fsub	d2, d2, d1
      a8:	movi	d1, #0x0
      ac:	fadd	d4, d2, d0
      b0:	fmul	d6, d4, d4
      b4:	adrp	x2, 0 <__kernel_tan>
      b8:	ldr	d2, [x2]
      bc:	adrp	x2, 0 <__kernel_tan>
      c0:	fmul	d0, d6, d6
      c4:	ldr	d25, [x2]
      c8:	adrp	x2, 0 <__kernel_tan>
      cc:	fmul	d7, d4, d6
      d0:	ldr	d3, [x2]
      d4:	adrp	x2, 0 <__kernel_tan>
      d8:	fmul	d2, d0, d2
      dc:	ldr	d24, [x2]
      e0:	adrp	x2, 0 <__kernel_tan>
      e4:	fmul	d3, d0, d3
      e8:	ldr	d23, [x2]
      ec:	adrp	x2, 0 <__kernel_tan>
      f0:	fadd	d2, d2, d25
      f4:	ldr	d22, [x2]
      f8:	adrp	x2, 0 <__kernel_tan>
      fc:	fadd	d3, d3, d24
     100:	ldr	d21, [x2]
     104:	adrp	x2, 0 <__kernel_tan>
     108:	fmul	d2, d2, d0
     10c:	ldr	d20, [x2]
     110:	adrp	x2, 0 <__kernel_tan>
     114:	fmul	d3, d3, d0
     118:	ldr	d19, [x2]
     11c:	adrp	x2, 0 <__kernel_tan>
     120:	fadd	d2, d2, d23
     124:	ldr	d18, [x2]
     128:	adrp	x2, 0 <__kernel_tan>
     12c:	fadd	d3, d3, d22
     130:	ldr	d17, [x2]
     134:	adrp	x2, 0 <__kernel_tan>
     138:	fmul	d2, d2, d0
     13c:	ldr	d16, [x2]
     140:	adrp	x2, 0 <__kernel_tan>
     144:	fmul	d3, d3, d0
     148:	ldr	d5, [x2]
     14c:	mov	w2, #0x9427                	// #37927
     150:	fadd	d2, d2, d21
     154:	movk	w2, #0x3fe5, lsl #16
     158:	fadd	d3, d3, d20
     15c:	fmul	d5, d7, d5
     160:	fmul	d2, d2, d0
     164:	fmul	d3, d3, d0
     168:	fadd	d2, d2, d19
     16c:	fadd	d3, d3, d18
     170:	fmul	d2, d2, d0
     174:	fmul	d3, d3, d0
     178:	fadd	d2, d2, d17
     17c:	fadd	d3, d3, d16
     180:	fmul	d2, d2, d6
     184:	fadd	d2, d2, d3
     188:	fmul	d2, d2, d7
     18c:	fadd	d2, d2, d1
     190:	fmul	d2, d2, d6
     194:	fadd	d1, d2, d1
     198:	fadd	d1, d5, d1
     19c:	fadd	d0, d4, d1
     1a0:	cmp	w1, w2
     1a4:	b.gt	1ec <__kernel_tan+0x1ec>
     1a8:	cmp	w0, #0x1
     1ac:	b.eq	78 <__kernel_tan+0x78>  // b.none
     1b0:	fmov	d3, #-1.000000000000000000e+00
     1b4:	movi	v6.2d, #0xffffffff00000000
     1b8:	fmov	d5, #1.000000000000000000e+00
     1bc:	fdiv	d3, d3, d0
     1c0:	and	v2.8b, v0.8b, v6.8b
     1c4:	fsub	d4, d2, d4
     1c8:	fsub	d1, d1, d4
     1cc:	and	v0.8b, v3.8b, v6.8b
     1d0:	fmul	d2, d2, d0
     1d4:	fmul	d1, d1, d0
     1d8:	fadd	d2, d2, d5
     1dc:	fadd	d1, d1, d2
     1e0:	fmul	d1, d1, d3
     1e4:	fadd	d0, d1, d0
     1e8:	ret
     1ec:	scvtf	d3, w0
     1f0:	fmul	d2, d0, d0
     1f4:	asr	w3, w3, #30
     1f8:	mov	w0, #0x1                   	// #1
     1fc:	and	w3, w3, #0x2
     200:	sub	w0, w0, w3
     204:	fadd	d0, d0, d3
     208:	scvtf	d5, w0
     20c:	fdiv	d0, d2, d0
     210:	fsub	d0, d0, d1
     214:	fsub	d0, d4, d0
     218:	fadd	d0, d0, d0
     21c:	fsub	d3, d3, d0
     220:	fmul	d0, d3, d5
     224:	ret
     228:	adrp	x2, 0 <__kernel_tan>
     22c:	fneg	d4, d0
     230:	fneg	d1, d1
     234:	ldr	d0, [x2]
     238:	adrp	x2, 0 <__kernel_tan>
     23c:	ldr	d2, [x2]
     240:	fsub	d0, d0, d4
     244:	fsub	d2, d2, d1
     248:	movi	d1, #0x0
     24c:	fadd	d4, d2, d0
     250:	b	b0 <__kernel_tan+0xb0>
     254:	fabs	d4, d0
     258:	fmov	d0, #1.000000000000000000e+00
     25c:	fdiv	d0, d0, d4
     260:	ret

0000000000000264 <__kernel_rem_pio2.constprop.0>:
     264:	stp	x29, x30, [sp, #-128]!
     268:	sub	w6, w2, #0x3
     26c:	mov	w4, #0xaaab                	// #43691
     270:	mov	x29, sp
     274:	movk	w4, #0x2aaa, lsl #16
     278:	adrp	x5, 0 <__stack_chk_guard>
     27c:	ldr	x5, [x5]
     280:	stp	x19, x20, [sp, #16]
     284:	smull	x4, w6, w4
     288:	stp	x21, x22, [sp, #32]
     28c:	sub	w19, w3, #0x1
     290:	mov	x20, x0
     294:	stp	x23, x24, [sp, #48]
     298:	asr	x4, x4, #34
     29c:	sub	w6, w4, w6, asr #31
     2a0:	stp	x25, x26, [sp, #64]
     2a4:	adrp	x4, 0 <__kernel_tan>
     2a8:	add	x4, x4, #0x0
     2ac:	stp	x27, x28, [sp, #80]
     2b0:	stp	d8, d9, [sp, #96]
     2b4:	stp	d10, d11, [sp, #112]
     2b8:	sub	sp, sp, #0x260
     2bc:	add	x7, sp, #0x78
     2c0:	str	x7, [sp]
     2c4:	str	x1, [sp, #16]
     2c8:	add	w1, w6, #0x1
     2cc:	str	w3, [sp, #24]
     2d0:	add	w3, w3, #0x4
     2d4:	sub	w1, w1, w1, lsl #2
     2d8:	ldr	x0, [x5]
     2dc:	str	x0, [sp, #600]
     2e0:	mov	x0, #0x0                   	// #0
     2e4:	sub	w0, w6, w19
     2e8:	add	w21, w2, w1, lsl #3
     2ec:	sxtw	x0, w0
     2f0:	add	x3, x0, w3, sxtw
     2f4:	sub	x2, x7, x0, lsl #3
     2f8:	tbnz	w0, #31, 734 <__kernel_rem_pio2.constprop.0+0x4d0>
     2fc:	ldr	w1, [x4, x0, lsl #2]
     300:	scvtf	d0, w1
     304:	str	d0, [x2, x0, lsl #3]
     308:	add	x0, x0, #0x1
     30c:	cmp	x0, x3
     310:	b.ne	2f8 <__kernel_rem_pio2.constprop.0+0x94>  // b.any
     314:	sxtw	x0, w19
     318:	str	x0, [sp, #8]
     31c:	ldr	x0, [sp]
     320:	add	x26, sp, #0x1b8
     324:	mov	x2, #0x1                   	// #1
     328:	add	x3, x0, w19, sxtw #3
     32c:	nop
     330:	movi	d1, #0x0
     334:	mov	x1, x3
     338:	mov	x0, #0x0                   	// #0
     33c:	nop
     340:	ldr	d0, [x20, x0, lsl #3]
     344:	add	x0, x0, #0x1
     348:	ldr	d2, [x1], #-8
     34c:	fmul	d0, d0, d2
     350:	fadd	d1, d1, d0
     354:	cmp	w19, w0
     358:	b.ge	340 <__kernel_rem_pio2.constprop.0+0xdc>  // b.tcont
     35c:	add	x0, x26, x2, lsl #3
     360:	add	x2, x2, #0x1
     364:	add	x3, x3, #0x8
     368:	stur	d1, [x0, #-8]
     36c:	cmp	x2, #0x6
     370:	b.ne	330 <__kernel_rem_pio2.constprop.0+0xcc>  // b.any
     374:	adrp	x0, 0 <__kernel_tan>
     378:	add	x1, x0, #0x0
     37c:	add	x6, x1, w6, sxtw #2
     380:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     384:	sub	x24, x6, #0x4
     388:	add	x28, sp, #0x28
     38c:	fmov	d11, x0
     390:	mov	w27, #0x4                   	// #4
     394:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     398:	fmov	d8, #1.250000000000000000e-01
     39c:	fmov	d10, x0
     3a0:	mov	w22, #0xffffff              	// #16777215
     3a4:	nop
     3a8:	sxtw	x23, w27
     3ac:	sbfiz	x1, x27, #3, #32
     3b0:	ldr	d0, [x26, x23, lsl #3]
     3b4:	cmp	w27, #0x0
     3b8:	b.le	3fc <__kernel_rem_pio2.constprop.0+0x198>
     3bc:	add	x1, x26, x1
     3c0:	add	w8, w27, #0x1
     3c4:	mov	x0, #0x1                   	// #1
     3c8:	fmul	d1, d0, d11
     3cc:	add	x2, x28, x0, lsl #2
     3d0:	ldr	d3, [x1, #-8]!
     3d4:	add	x0, x0, #0x1
     3d8:	fcvtzs	w3, d1
     3dc:	scvtf	d2, w3
     3e0:	fmul	d1, d2, d10
     3e4:	fsub	d1, d0, d1
     3e8:	fadd	d0, d2, d3
     3ec:	fcvtzs	w3, d1
     3f0:	stur	w3, [x2, #-4]
     3f4:	cmp	x0, x8
     3f8:	b.ne	3c8 <__kernel_rem_pio2.constprop.0+0x164>  // b.any
     3fc:	mov	w0, w21
     400:	bl	0 <scalbn>
     404:	fmul	d1, d0, d8
     408:	fmov	d2, #8.000000000000000000e+00
     40c:	frintm	d1, d1
     410:	fmul	d1, d1, d2
     414:	fsub	d0, d0, d1
     418:	fcvtzs	w25, d0
     41c:	scvtf	d1, w25
     420:	fsub	d9, d0, d1
     424:	cmp	w21, #0x0
     428:	b.le	564 <__kernel_rem_pio2.constprop.0+0x300>
     42c:	sub	w0, w27, #0x1
     430:	mov	w2, #0x18                  	// #24
     434:	sub	w2, w2, w21
     438:	mov	w3, #0x17                  	// #23
     43c:	sxtw	x0, w0
     440:	sub	w3, w3, w21
     444:	ldr	w8, [x28, x0, lsl #2]
     448:	asr	w1, w8, w2
     44c:	add	w25, w25, w1
     450:	lsl	w1, w1, w2
     454:	sub	w8, w8, w1
     458:	str	w8, [x28, x0, lsl #2]
     45c:	asr	w8, w8, w3
     460:	cmp	w8, #0x0
     464:	b.gt	754 <__kernel_rem_pio2.constprop.0+0x4f0>
     468:	fcmp	d9, #0.0
     46c:	b.ne	63c <__kernel_rem_pio2.constprop.0+0x3d8>  // b.any
     470:	cmp	w27, #0x4
     474:	b.le	4ac <__kernel_rem_pio2.constprop.0+0x248>
     478:	sub	w0, w27, #0x2
     47c:	sub	x3, x23, #0x3
     480:	sub	w2, w27, #0x5
     484:	mov	w1, #0x0                   	// #0
     488:	sxtw	x0, w0
     48c:	sub	x3, x3, x2
     490:	add	x2, x28, x0, lsl #2
     494:	sub	x0, x0, #0x1
     498:	ldr	w2, [x2, #4]
     49c:	orr	w1, w1, w2
     4a0:	cmp	x0, x3
     4a4:	b.ne	490 <__kernel_rem_pio2.constprop.0+0x22c>  // b.any
     4a8:	cbnz	w1, 784 <__kernel_rem_pio2.constprop.0+0x520>
     4ac:	ldr	w0, [sp, #52]
     4b0:	cbnz	w0, 558 <__kernel_rem_pio2.constprop.0+0x2f4>
     4b4:	ldr	w0, [sp, #48]
     4b8:	cbnz	w0, 8ac <__kernel_rem_pio2.constprop.0+0x648>
     4bc:	ldr	w0, [sp, #44]
     4c0:	mov	w8, #0x3                   	// #3
     4c4:	cbnz	w0, 55c <__kernel_rem_pio2.constprop.0+0x2f8>
     4c8:	ldr	w0, [sp, #40]
     4cc:	add	w8, w27, #0x5
     4d0:	cbnz	w0, 8b8 <__kernel_rem_pio2.constprop.0+0x654>
     4d4:	ldr	w0, [sp, #24]
     4d8:	add	w3, w27, #0x1
     4dc:	add	w2, w27, #0x2
     4e0:	add	x7, x23, w0, sxtw
     4e4:	sxtw	x2, w2
     4e8:	ldr	x0, [sp, #8]
     4ec:	add	x3, x0, w3, sxtw
     4f0:	ldr	x0, [sp]
     4f4:	sub	x9, x3, x7
     4f8:	add	x3, x0, x3, lsl #3
     4fc:	nop
     500:	ldr	w7, [x24, x2, lsl #2]
     504:	movi	d1, #0x0
     508:	mov	x1, x3
     50c:	mov	x0, #0x0                   	// #0
     510:	scvtf	d0, w7
     514:	str	d0, [x3, x9, lsl #3]
     518:	ldr	d0, [x20, x0, lsl #3]
     51c:	add	x0, x0, #0x1
     520:	ldr	d2, [x1], #-8
     524:	fmul	d0, d0, d2
     528:	fadd	d1, d1, d0
     52c:	cmp	w19, w0
     530:	b.ge	518 <__kernel_rem_pio2.constprop.0+0x2b4>  // b.tcont
     534:	add	x1, x26, x2, lsl #3
     538:	add	x2, x2, #0x1
     53c:	sub	w0, w2, #0x1
     540:	add	x3, x3, #0x8
     544:	stur	d1, [x1, #-8]
     548:	cmp	w8, w0
     54c:	b.ge	500 <__kernel_rem_pio2.constprop.0+0x29c>  // b.tcont
     550:	mov	w27, w8
     554:	b	3a8 <__kernel_rem_pio2.constprop.0+0x144>
     558:	mov	w8, #0x1                   	// #1
     55c:	add	w8, w27, w8
     560:	b	4d4 <__kernel_rem_pio2.constprop.0+0x270>
     564:	b.ne	740 <__kernel_rem_pio2.constprop.0+0x4dc>  // b.any
     568:	sub	w0, w27, #0x1
     56c:	ldr	w8, [x28, w0, sxtw #2]
     570:	asr	w8, w8, #23
     574:	cmp	w8, #0x0
     578:	b.le	468 <__kernel_rem_pio2.constprop.0+0x204>
     57c:	add	w25, w25, #0x1
     580:	cmp	w27, #0x0
     584:	b.le	8f8 <__kernel_rem_pio2.constprop.0+0x694>
     588:	ldr	w2, [x28]
     58c:	mov	x0, x28
     590:	mov	w1, #0x0                   	// #0
     594:	cbnz	w2, 5b0 <__kernel_rem_pio2.constprop.0+0x34c>
     598:	add	w1, w1, #0x1
     59c:	add	x0, x0, #0x4
     5a0:	cmp	w27, w1
     5a4:	b.le	5e0 <__kernel_rem_pio2.constprop.0+0x37c>
     5a8:	ldr	w2, [x0]
     5ac:	cbz	w2, 598 <__kernel_rem_pio2.constprop.0+0x334>
     5b0:	mov	w3, #0x1000000             	// #16777216
     5b4:	sub	w2, w3, w2
     5b8:	str	w2, [x0]
     5bc:	b	5cc <__kernel_rem_pio2.constprop.0+0x368>
     5c0:	ldr	w2, [x0]
     5c4:	sub	w2, w22, w2
     5c8:	str	w2, [x0]
     5cc:	add	w1, w1, #0x1
     5d0:	add	x0, x0, #0x4
     5d4:	cmp	w27, w1
     5d8:	b.gt	5c0 <__kernel_rem_pio2.constprop.0+0x35c>
     5dc:	mov	w2, #0x1                   	// #1
     5e0:	cmp	w21, #0x0
     5e4:	b.le	60c <__kernel_rem_pio2.constprop.0+0x3a8>
     5e8:	cmp	w21, #0x1
     5ec:	b.eq	76c <__kernel_rem_pio2.constprop.0+0x508>  // b.none
     5f0:	cmp	w21, #0x2
     5f4:	b.ne	60c <__kernel_rem_pio2.constprop.0+0x3a8>  // b.any
     5f8:	sub	w0, w27, #0x1
     5fc:	sxtw	x0, w0
     600:	ldr	w1, [x28, x0, lsl #2]
     604:	and	w1, w1, #0x3fffff
     608:	str	w1, [x28, x0, lsl #2]
     60c:	cmp	w8, #0x2
     610:	b.ne	468 <__kernel_rem_pio2.constprop.0+0x204>  // b.any
     614:	fmov	d0, #1.000000000000000000e+00
     618:	fsub	d9, d0, d9
     61c:	cbz	w2, 468 <__kernel_rem_pio2.constprop.0+0x204>
     620:	mov	w0, w21
     624:	str	w8, [sp, #28]
     628:	bl	0 <scalbn>
     62c:	fsub	d9, d9, d0
     630:	ldr	w8, [sp, #28]
     634:	fcmp	d9, #0.0
     638:	b.eq	470 <__kernel_rem_pio2.constprop.0+0x20c>  // b.none
     63c:	fmov	d0, d9
     640:	neg	w0, w21
     644:	str	w8, [sp]
     648:	bl	0 <scalbn>
     64c:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     650:	fmov	d2, x0
     654:	ldr	w8, [sp]
     658:	fcmpe	d0, d2
     65c:	b.ge	8c4 <__kernel_rem_pio2.constprop.0+0x660>  // b.tcont
     660:	fcvtzs	w0, d0
     664:	str	w0, [x28, x23, lsl #2]
     668:	fmov	d0, #1.000000000000000000e+00
     66c:	mov	w0, w21
     670:	str	w8, [sp]
     674:	bl	0 <scalbn>
     678:	fmov	d1, d0
     67c:	ldr	w8, [sp]
     680:	tbnz	w27, #31, 7cc <__kernel_rem_pio2.constprop.0+0x568>
     684:	sxtw	x19, w27
     688:	sub	w5, w27, #0x1
     68c:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     690:	fmov	d2, x0
     694:	mov	x6, #0xfffffffffffffffe    	// #-2
     698:	sxtw	x5, w5
     69c:	mov	x0, x5
     6a0:	add	x2, x28, x0, lsl #2
     6a4:	add	x1, x26, x0, lsl #3
     6a8:	sub	x0, x0, #0x1
     6ac:	ldr	w2, [x2, #4]
     6b0:	scvtf	d0, w2
     6b4:	fmul	d0, d0, d1
     6b8:	fmul	d1, d1, d2
     6bc:	str	d0, [x1, #8]
     6c0:	cmp	x0, x6
     6c4:	b.ne	6a0 <__kernel_rem_pio2.constprop.0+0x43c>  // b.any
     6c8:	add	x7, sp, #0x118
     6cc:	adrp	x0, 0 <__kernel_tan>
     6d0:	add	x3, x0, #0x0
     6d4:	add	x2, x26, x19, lsl #3
     6d8:	add	x3, x3, #0x110
     6dc:	mov	x4, x7
     6e0:	mov	w1, #0x0                   	// #0
     6e4:	nop
     6e8:	movi	d1, #0x0
     6ec:	mov	x0, #0x0                   	// #0
     6f0:	b	700 <__kernel_rem_pio2.constprop.0+0x49c>
     6f4:	add	x0, x0, #0x1
     6f8:	cmp	w1, w0
     6fc:	b.lt	718 <__kernel_rem_pio2.constprop.0+0x4b4>  // b.tstop
     700:	ldr	d0, [x3, x0, lsl #3]
     704:	ldr	d2, [x2, x0, lsl #3]
     708:	fmul	d0, d0, d2
     70c:	fadd	d1, d1, d0
     710:	cmp	x0, #0x4
     714:	b.ne	6f4 <__kernel_rem_pio2.constprop.0+0x490>  // b.any
     718:	str	d1, [x4], #8
     71c:	sub	x2, x2, #0x8
     720:	add	w0, w1, #0x1
     724:	cmp	w1, w27
     728:	b.eq	82c <__kernel_rem_pio2.constprop.0+0x5c8>  // b.none
     72c:	mov	w1, w0
     730:	b	6e8 <__kernel_rem_pio2.constprop.0+0x484>
     734:	str	xzr, [x2, x0, lsl #3]
     738:	add	x0, x0, #0x1
     73c:	b	2f8 <__kernel_rem_pio2.constprop.0+0x94>
     740:	fmov	d0, #5.000000000000000000e-01
     744:	fcmpe	d9, d0
     748:	b.ge	888 <__kernel_rem_pio2.constprop.0+0x624>  // b.tcont
     74c:	mov	w8, #0x0                   	// #0
     750:	b	468 <__kernel_rem_pio2.constprop.0+0x204>
     754:	add	w25, w25, #0x1
     758:	mov	w2, #0x0                   	// #0
     75c:	cmp	w27, #0x0
     760:	b.gt	588 <__kernel_rem_pio2.constprop.0+0x324>
     764:	cmp	w21, #0x1
     768:	b.ne	5f0 <__kernel_rem_pio2.constprop.0+0x38c>  // b.any
     76c:	sub	w0, w27, #0x1
     770:	sxtw	x0, w0
     774:	ldr	w1, [x28, x0, lsl #2]
     778:	and	w1, w1, #0x7fffff
     77c:	str	w1, [x28, x0, lsl #2]
     780:	b	60c <__kernel_rem_pio2.constprop.0+0x3a8>
     784:	sub	w27, w27, #0x1
     788:	sub	w21, w21, #0x18
     78c:	add	x7, x28, x23, lsl #2
     790:	sxtw	x19, w27
     794:	ldr	w0, [x28, x19, lsl #2]
     798:	cbnz	w0, 92c <__kernel_rem_pio2.constprop.0+0x6c8>
     79c:	ldur	w0, [x7, #-8]
     7a0:	sub	x7, x7, #0x4
     7a4:	sub	w27, w27, #0x1
     7a8:	sub	w21, w21, #0x18
     7ac:	cbz	w0, 79c <__kernel_rem_pio2.constprop.0+0x538>
     7b0:	fmov	d0, #1.000000000000000000e+00
     7b4:	mov	w0, w21
     7b8:	str	w8, [sp]
     7bc:	bl	0 <scalbn>
     7c0:	fmov	d1, d0
     7c4:	ldr	w8, [sp]
     7c8:	tbz	w27, #31, 684 <__kernel_rem_pio2.constprop.0+0x420>
     7cc:	ldr	d0, [sp, #280]
     7d0:	cbnz	w8, 948 <__kernel_rem_pio2.constprop.0+0x6e4>
     7d4:	ldr	x0, [sp, #16]
     7d8:	str	xzr, [x0]
     7dc:	ldr	x0, [sp, #16]
     7e0:	adrp	x1, 0 <__stack_chk_guard>
     7e4:	ldr	x1, [x1]
     7e8:	str	d0, [x0, #8]
     7ec:	and	w0, w25, #0x7
     7f0:	ldr	x3, [sp, #600]
     7f4:	ldr	x2, [x1]
     7f8:	subs	x3, x3, x2
     7fc:	mov	x2, #0x0                   	// #0
     800:	b.ne	960 <__kernel_rem_pio2.constprop.0+0x6fc>  // b.any
     804:	add	sp, sp, #0x260
     808:	ldp	x19, x20, [sp, #16]
     80c:	ldp	x21, x22, [sp, #32]
     810:	ldp	x23, x24, [sp, #48]
     814:	ldp	x25, x26, [sp, #64]
     818:	ldp	x27, x28, [sp, #80]
     81c:	ldp	d8, d9, [sp, #96]
     820:	ldp	d10, d11, [sp, #112]
     824:	ldp	x29, x30, [sp], #128
     828:	ret
     82c:	movi	d1, #0x0
     830:	add	x0, x7, x5, lsl #3
     834:	sub	x5, x5, #0x1
     838:	ldr	d0, [x0, #8]
     83c:	fadd	d1, d1, d0
     840:	cmp	x5, x6
     844:	b.ne	830 <__kernel_rem_pio2.constprop.0+0x5cc>  // b.any
     848:	ldr	d0, [sp, #280]
     84c:	fsub	d0, d0, d1
     850:	cbnz	w8, 914 <__kernel_rem_pio2.constprop.0+0x6b0>
     854:	ldr	x0, [sp, #16]
     858:	str	d1, [x0]
     85c:	cbz	w27, 7dc <__kernel_rem_pio2.constprop.0+0x578>
     860:	add	x1, sp, #0x120
     864:	mov	w0, #0x1                   	// #1
     868:	ldr	d1, [x1], #8
     86c:	add	w0, w0, #0x1
     870:	fadd	d0, d0, d1
     874:	cmp	w0, w27
     878:	b.le	868 <__kernel_rem_pio2.constprop.0+0x604>
     87c:	cbz	w8, 7dc <__kernel_rem_pio2.constprop.0+0x578>
     880:	fneg	d0, d0
     884:	b	7dc <__kernel_rem_pio2.constprop.0+0x578>
     888:	add	w25, w25, #0x1
     88c:	mov	w8, #0x2                   	// #2
     890:	cmp	w27, #0x0
     894:	b.gt	588 <__kernel_rem_pio2.constprop.0+0x324>
     898:	fmov	d0, #1.000000000000000000e+00
     89c:	fsub	d9, d0, d9
     8a0:	fcmp	d9, #0.0
     8a4:	b.eq	4ac <__kernel_rem_pio2.constprop.0+0x248>  // b.none
     8a8:	b	63c <__kernel_rem_pio2.constprop.0+0x3d8>
     8ac:	mov	w8, #0x2                   	// #2
     8b0:	add	w8, w27, w8
     8b4:	b	4d4 <__kernel_rem_pio2.constprop.0+0x270>
     8b8:	mov	w8, #0x4                   	// #4
     8bc:	add	w8, w27, w8
     8c0:	b	4d4 <__kernel_rem_pio2.constprop.0+0x270>
     8c4:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     8c8:	fmov	d1, x0
     8cc:	add	w27, w27, #0x1
     8d0:	add	w21, w21, #0x18
     8d4:	fmul	d1, d0, d1
     8d8:	fcvtzs	w0, d1
     8dc:	scvtf	d1, w0
     8e0:	fmul	d1, d1, d2
     8e4:	fsub	d0, d0, d1
     8e8:	fcvtzs	w1, d0
     8ec:	str	w1, [x28, x23, lsl #2]
     8f0:	str	w0, [x28, w27, sxtw #2]
     8f4:	b	668 <__kernel_rem_pio2.constprop.0+0x404>
     8f8:	cmp	w8, #0x2
     8fc:	b.ne	908 <__kernel_rem_pio2.constprop.0+0x6a4>  // b.any
     900:	fmov	d0, #1.000000000000000000e+00
     904:	fsub	d9, d0, d9
     908:	fcmp	d9, #0.0
     90c:	b.eq	4ac <__kernel_rem_pio2.constprop.0+0x248>  // b.none
     910:	b	63c <__kernel_rem_pio2.constprop.0+0x3d8>
     914:	ldr	x0, [sp, #16]
     918:	fneg	d1, d1
     91c:	str	d1, [x0]
     920:	cbnz	w27, 860 <__kernel_rem_pio2.constprop.0+0x5fc>
     924:	fneg	d0, d0
     928:	b	7dc <__kernel_rem_pio2.constprop.0+0x578>
     92c:	fmov	d0, #1.000000000000000000e+00
     930:	mov	w0, w21
     934:	str	w8, [sp]
     938:	bl	0 <scalbn>
     93c:	fmov	d1, d0
     940:	ldr	w8, [sp]
     944:	b	688 <__kernel_rem_pio2.constprop.0+0x424>
     948:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
     94c:	fmov	d1, x0
     950:	ldr	x0, [sp, #16]
     954:	fneg	d0, d0
     958:	str	d1, [x0]
     95c:	b	7dc <__kernel_rem_pio2.constprop.0+0x578>
     960:	bl	0 <__stack_chk_fail>

0000000000000964 <__ieee754_rem_pio2>:
     964:	sub	sp, sp, #0x40
     968:	fmov	x4, d0
     96c:	adrp	x1, 0 <__stack_chk_guard>
     970:	ldr	x1, [x1]
     974:	stp	x29, x30, [sp, #32]
     978:	add	x29, sp, #0x20
     97c:	ubfx	x5, x4, #32, #31
     980:	stp	x19, x20, [sp, #48]
     984:	mov	x19, x0
     988:	mov	w0, #0x21fb                	// #8699
     98c:	ldr	x2, [x1]
     990:	str	x2, [sp, #24]
     994:	mov	x2, #0x0                   	// #0
     998:	movk	w0, #0x3fe9, lsl #16
     99c:	cmp	w5, w0
     9a0:	b.le	ac0 <__ieee754_rem_pio2+0x15c>
     9a4:	mov	w0, #0xd97b                	// #55675
     9a8:	lsr	x20, x4, #32
     9ac:	movk	w0, #0x4002, lsl #16
     9b0:	cmp	w5, w0
     9b4:	b.gt	a24 <__ieee754_rem_pio2+0xc0>
     9b8:	adrp	x0, 0 <__kernel_tan>
     9bc:	ldr	d1, [x0]
     9c0:	mov	w0, #0x21fb                	// #8699
     9c4:	movk	w0, #0x3ff9, lsl #16
     9c8:	cmp	w20, #0x0
     9cc:	b.le	c28 <__ieee754_rem_pio2+0x2c4>
     9d0:	fsub	d0, d0, d1
     9d4:	cmp	w5, w0
     9d8:	b.eq	bd4 <__ieee754_rem_pio2+0x270>  // b.none
     9dc:	adrp	x0, 0 <__kernel_tan>
     9e0:	ldr	d2, [x0]
     9e4:	fsub	d1, d0, d2
     9e8:	fsub	d0, d0, d1
     9ec:	fsub	d0, d0, d2
     9f0:	mov	w0, #0x1                   	// #1
     9f4:	stp	d1, d0, [x19]
     9f8:	adrp	x1, 0 <__stack_chk_guard>
     9fc:	ldr	x1, [x1]
     a00:	ldr	x3, [sp, #24]
     a04:	ldr	x2, [x1]
     a08:	subs	x3, x3, x2
     a0c:	mov	x2, #0x0                   	// #0
     a10:	b.ne	c78 <__ieee754_rem_pio2+0x314>  // b.any
     a14:	ldp	x29, x30, [sp, #32]
     a18:	ldp	x19, x20, [sp, #48]
     a1c:	add	sp, sp, #0x40
     a20:	ret
     a24:	mov	w0, #0x21fb                	// #8699
     a28:	movk	w0, #0x4139, lsl #16
     a2c:	cmp	w5, w0
     a30:	b.le	ad0 <__ieee754_rem_pio2+0x16c>
     a34:	mov	w0, #0x7fefffff            	// #2146435071
     a38:	cmp	w5, w0
     a3c:	b.gt	c0c <__ieee754_rem_pio2+0x2a8>
     a40:	asr	w2, w5, #20
     a44:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     a48:	sub	w2, w2, #0x416
     a4c:	fmov	d1, x0
     a50:	mov	w3, #0x3                   	// #3
     a54:	sub	w5, w5, w2, lsl #20
     a58:	bfi	x4, x5, #32, #32
     a5c:	fmov	d0, x4
     a60:	fcvtzs	w0, d0
     a64:	scvtf	d2, w0
     a68:	fsub	d0, d0, d2
     a6c:	str	d2, [sp]
     a70:	fmul	d0, d0, d1
     a74:	fcvtzs	w0, d0
     a78:	scvtf	d2, w0
     a7c:	fsub	d0, d0, d2
     a80:	fmul	d0, d0, d1
     a84:	fcmp	d0, #0.0
     a88:	stp	d2, d0, [sp, #8]
     a8c:	b.ne	a9c <__ieee754_rem_pio2+0x138>  // b.any
     a90:	cmp	w0, #0x0
     a94:	cset	w3, ne	// ne = any
     a98:	add	w3, w3, #0x1
     a9c:	mov	x1, x19
     aa0:	mov	x0, sp
     aa4:	bl	264 <__kernel_rem_pio2.constprop.0>
     aa8:	tbz	w20, #31, 9f8 <__ieee754_rem_pio2+0x94>
     aac:	ldr	q0, [x19]
     ab0:	neg	w0, w0
     ab4:	fneg	v0.2d, v0.2d
     ab8:	str	q0, [x19]
     abc:	b	9f8 <__ieee754_rem_pio2+0x94>
     ac0:	mov	w0, #0x0                   	// #0
     ac4:	str	d0, [x19]
     ac8:	str	xzr, [x19, #8]
     acc:	b	9f8 <__ieee754_rem_pio2+0x94>
     ad0:	adrp	x0, 0 <__kernel_tan>
     ad4:	fabs	d0, d0
     ad8:	fmov	d3, #5.000000000000000000e-01
     adc:	ldr	d2, [x0]
     ae0:	adrp	x0, 0 <__kernel_tan>
     ae4:	ldr	d4, [x0]
     ae8:	adrp	x0, 0 <__kernel_tan>
     aec:	fmul	d2, d0, d2
     af0:	ldr	d1, [x0]
     af4:	fadd	d2, d2, d3
     af8:	fcvtzs	w0, d2
     afc:	scvtf	d3, w0
     b00:	fmul	d2, d3, d4
     b04:	fmul	d1, d3, d1
     b08:	fsub	d0, d0, d2
     b0c:	fsub	d2, d0, d1
     b10:	cmp	w0, #0x1f
     b14:	b.gt	b4c <__ieee754_rem_pio2+0x1e8>
     b18:	adrp	x1, 0 <__kernel_tan>
     b1c:	add	x1, x1, #0x0
     b20:	add	x1, x1, #0x150
     b24:	sub	w2, w0, #0x1
     b28:	ldr	w1, [x1, w2, sxtw #2]
     b2c:	cmp	w1, w5
     b30:	b.eq	b4c <__ieee754_rem_pio2+0x1e8>  // b.none
     b34:	str	d2, [x19]
     b38:	fsub	d0, d0, d2
     b3c:	fsub	d0, d0, d1
     b40:	tbnz	w20, #31, bf8 <__ieee754_rem_pio2+0x294>
     b44:	str	d0, [x19, #8]
     b48:	b	9f8 <__ieee754_rem_pio2+0x94>
     b4c:	fmov	x1, d2
     b50:	asr	w5, w5, #20
     b54:	ubfx	x1, x1, #52, #11
     b58:	sub	w1, w5, w1
     b5c:	cmp	w1, #0x10
     b60:	b.le	b34 <__ieee754_rem_pio2+0x1d0>
     b64:	adrp	x1, 0 <__kernel_tan>
     b68:	ldr	d2, [x1]
     b6c:	adrp	x1, 0 <__kernel_tan>
     b70:	ldr	d1, [x1]
     b74:	fmul	d2, d3, d2
     b78:	fmul	d1, d3, d1
     b7c:	fsub	d4, d0, d2
     b80:	fsub	d0, d0, d4
     b84:	fsub	d0, d0, d2
     b88:	fsub	d1, d1, d0
     b8c:	fsub	d2, d4, d1
     b90:	fmov	x1, d2
     b94:	ubfx	x1, x1, #52, #11
     b98:	sub	w5, w5, w1
     b9c:	cmp	w5, #0x31
     ba0:	b.le	c1c <__ieee754_rem_pio2+0x2b8>
     ba4:	adrp	x1, 0 <__kernel_tan>
     ba8:	ldr	d1, [x1]
     bac:	adrp	x1, 0 <__kernel_tan>
     bb0:	ldr	d0, [x1]
     bb4:	fmul	d1, d3, d1
     bb8:	fmul	d3, d3, d0
     bbc:	fsub	d0, d4, d1
     bc0:	fsub	d4, d4, d0
     bc4:	fsub	d4, d4, d1
     bc8:	fsub	d1, d3, d4
     bcc:	fsub	d2, d0, d1
     bd0:	b	b34 <__ieee754_rem_pio2+0x1d0>
     bd4:	adrp	x0, 0 <__kernel_tan>
     bd8:	ldr	d1, [x0]
     bdc:	adrp	x0, 0 <__kernel_tan>
     be0:	ldr	d2, [x0]
     be4:	fsub	d0, d0, d1
     be8:	fsub	d1, d0, d2
     bec:	fsub	d0, d0, d1
     bf0:	fsub	d0, d0, d2
     bf4:	b	9f0 <__ieee754_rem_pio2+0x8c>
     bf8:	mov	v2.d[1], v0.d[0]
     bfc:	neg	w0, w0
     c00:	fneg	v2.2d, v2.2d
     c04:	str	q2, [x19]
     c08:	b	9f8 <__ieee754_rem_pio2+0x94>
     c0c:	fsub	d0, d0, d0
     c10:	mov	w0, #0x0                   	// #0
     c14:	stp	d0, d0, [x19]
     c18:	b	9f8 <__ieee754_rem_pio2+0x94>
     c1c:	fmov	d0, d4
     c20:	str	d2, [x19]
     c24:	b	b38 <__ieee754_rem_pio2+0x1d4>
     c28:	fadd	d0, d0, d1
     c2c:	cmp	w5, w0
     c30:	b.eq	c54 <__ieee754_rem_pio2+0x2f0>  // b.none
     c34:	adrp	x0, 0 <__kernel_tan>
     c38:	ldr	d2, [x0]
     c3c:	fadd	d1, d0, d2
     c40:	fsub	d0, d0, d1
     c44:	fadd	d0, d0, d2
     c48:	mov	w0, #0xffffffff            	// #-1
     c4c:	stp	d1, d0, [x19]
     c50:	b	9f8 <__ieee754_rem_pio2+0x94>
     c54:	adrp	x0, 0 <__kernel_tan>
     c58:	ldr	d1, [x0]
     c5c:	adrp	x0, 0 <__kernel_tan>
     c60:	ldr	d2, [x0]
     c64:	fadd	d0, d0, d1
     c68:	fadd	d1, d0, d2
     c6c:	fsub	d0, d0, d1
     c70:	fadd	d0, d0, d2
     c74:	b	c48 <__ieee754_rem_pio2+0x2e4>
     c78:	bl	0 <__stack_chk_fail>
     c7c:	nop

0000000000000c80 <pts_ieee754_acos>:
     c80:	fmov	x1, d0
     c84:	mov	w2, #0x3fefffff            	// #1072693247
     c88:	ubfx	x0, x1, #32, #31
     c8c:	lsr	x3, x1, #32
     c90:	cmp	w0, w2
     c94:	b.le	cc0 <pts_ieee754_acos+0x40>
     c98:	mov	w2, #0xc0100000            	// #-1072693248
     c9c:	add	w0, w0, w2
     ca0:	orr	w0, w0, w1
     ca4:	cbnz	w0, d20 <pts_ieee754_acos+0xa0>
     ca8:	adrp	x0, 0 <__kernel_tan>
     cac:	movi	d1, #0x0
     cb0:	cmp	w3, #0x0
     cb4:	ldr	d0, [x0]
     cb8:	fcsel	d0, d0, d1, le
     cbc:	ret
     cc0:	stp	x29, x30, [sp, #-32]!
     cc4:	mov	w1, #0x3fdfffff            	// #1071644671
     cc8:	mov	x29, sp
     ccc:	cmp	w0, w1
     cd0:	b.gt	cf0 <pts_ieee754_acos+0x70>
     cd4:	mov	w1, #0x3c600000            	// #1012924416
     cd8:	cmp	w0, w1
     cdc:	b.gt	e0c <pts_ieee754_acos+0x18c>
     ce0:	adrp	x0, 0 <__kernel_tan>
     ce4:	ldp	x29, x30, [sp], #32
     ce8:	ldr	d0, [x0]
     cec:	ret
     cf0:	stp	d8, d9, [sp, #16]
     cf4:	tbnz	w3, #31, ee8 <pts_ieee754_acos+0x268>
     cf8:	fmov	d8, #1.000000000000000000e+00
     cfc:	fmov	d1, #5.000000000000000000e-01
     d00:	fsub	d8, d8, d0
     d04:	fmul	d8, d8, d1
     d08:	fcmp	d8, #0.0
     d0c:	b.pl	d2c <pts_ieee754_acos+0xac>  // b.nfrst
     d10:	fmov	d0, d8
     d14:	bl	0 <sqrt>
     d18:	fmov	d5, d0
     d1c:	b	d30 <pts_ieee754_acos+0xb0>
     d20:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     d24:	fmov	d0, x0
     d28:	ret
     d2c:	fsqrt	d5, d8
     d30:	adrp	x0, 0 <__kernel_tan>
     d34:	fmov	d6, #1.000000000000000000e+00
     d38:	ldr	d0, [x0]
     d3c:	adrp	x0, 0 <__kernel_tan>
     d40:	ldr	d3, [x0]
     d44:	adrp	x0, 0 <__kernel_tan>
     d48:	fmul	d0, d8, d0
     d4c:	ldr	d19, [x0]
     d50:	adrp	x0, 0 <__kernel_tan>
     d54:	ldr	d1, [x0]
     d58:	adrp	x0, 0 <__kernel_tan>
     d5c:	fadd	d0, d0, d3
     d60:	ldr	d2, [x0]
     d64:	adrp	x0, 0 <__kernel_tan>
     d68:	fmul	d1, d8, d1
     d6c:	ldr	d16, [x0]
     d70:	adrp	x0, 0 <__kernel_tan>
     d74:	fmul	d0, d0, d8
     d78:	ldr	d18, [x0]
     d7c:	adrp	x0, 0 <__kernel_tan>
     d80:	fsub	d1, d1, d2
     d84:	movi	v2.2d, #0xffffffff00000000
     d88:	ldr	d7, [x0]
     d8c:	adrp	x0, 0 <__kernel_tan>
     d90:	fsub	d0, d0, d19
     d94:	ldr	d9, [x0]
     d98:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     d9c:	fmul	d1, d1, d8
     da0:	movk	x0, #0x3fc5, lsl #48
     da4:	fmov	d4, x0
     da8:	and	v3.8b, v5.8b, v2.8b
     dac:	fmul	d0, d0, d8
     db0:	fadd	d1, d1, d18
     db4:	fmul	d2, d3, d3
     db8:	fadd	d17, d3, d5
     dbc:	fadd	d0, d0, d16
     dc0:	fmul	d1, d1, d8
     dc4:	fsub	d2, d8, d2
     dc8:	fmul	d0, d0, d8
     dcc:	fsub	d1, d1, d9
     dd0:	fdiv	d2, d2, d17
     dd4:	fsub	d0, d0, d7
     dd8:	fmul	d1, d1, d8
     ddc:	fmul	d0, d0, d8
     de0:	fadd	d1, d1, d6
     de4:	fadd	d0, d0, d4
     de8:	fmul	d0, d0, d8
     dec:	ldp	d8, d9, [sp, #16]
     df0:	ldp	x29, x30, [sp], #32
     df4:	fdiv	d0, d0, d1
     df8:	fmul	d0, d0, d5
     dfc:	fadd	d0, d0, d2
     e00:	fadd	d0, d0, d3
     e04:	fadd	d0, d0, d0
     e08:	ret
     e0c:	adrp	x0, 0 <__kernel_tan>
     e10:	fmul	d4, d0, d0
     e14:	stp	d8, d9, [sp, #16]
     e18:	fmov	d7, #1.000000000000000000e+00
     e1c:	ldr	d2, [x0]
     e20:	adrp	x0, 0 <__kernel_tan>
     e24:	fmul	d2, d4, d2
     e28:	ldr	d19, [x0]
     e2c:	adrp	x0, 0 <__kernel_tan>
     e30:	ldr	d18, [x0]
     e34:	adrp	x0, 0 <__kernel_tan>
     e38:	fadd	d2, d2, d19
     e3c:	ldr	d3, [x0]
     e40:	adrp	x0, 0 <__kernel_tan>
     e44:	ldr	d1, [x0]
     e48:	adrp	x0, 0 <__kernel_tan>
     e4c:	fmul	d2, d2, d4
     e50:	fmul	d3, d4, d3
     e54:	ldr	d16, [x0]
     e58:	adrp	x0, 0 <__kernel_tan>
     e5c:	ldr	d17, [x0]
     e60:	adrp	x0, 0 <__kernel_tan>
     e64:	fsub	d2, d2, d18
     e68:	fsub	d3, d3, d1
     e6c:	ldr	d8, [x0]
     e70:	adrp	x0, 0 <__kernel_tan>
     e74:	ldr	d9, [x0]
     e78:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     e7c:	fmul	d2, d2, d4
     e80:	fmul	d3, d3, d4
     e84:	movk	x0, #0x3fc5, lsl #48
     e88:	fmov	d6, x0
     e8c:	adrp	x0, 0 <__kernel_tan>
     e90:	fadd	d2, d2, d16
     e94:	fadd	d3, d3, d17
     e98:	ldr	d5, [x0]
     e9c:	adrp	x0, 0 <__kernel_tan>
     ea0:	ldr	d1, [x0]
     ea4:	fmul	d2, d2, d4
     ea8:	fmul	d3, d3, d4
     eac:	fsub	d2, d2, d8
     eb0:	fsub	d3, d3, d9
     eb4:	ldp	d8, d9, [sp, #16]
     eb8:	ldp	x29, x30, [sp], #32
     ebc:	fmul	d2, d2, d4
     ec0:	fmul	d3, d3, d4
     ec4:	fadd	d2, d2, d6
     ec8:	fadd	d3, d3, d7
     ecc:	fmul	d2, d2, d4
     ed0:	fdiv	d2, d2, d3
     ed4:	fmul	d2, d2, d0
     ed8:	fsub	d2, d5, d2
     edc:	fsub	d0, d0, d2
     ee0:	fsub	d0, d1, d0
     ee4:	ret
     ee8:	fmov	d2, #1.000000000000000000e+00
     eec:	fmov	d1, #5.000000000000000000e-01
     ef0:	adrp	x0, 0 <__kernel_tan>
     ef4:	fadd	d0, d0, d2
     ef8:	ldr	d8, [x0]
     efc:	adrp	x0, 0 <__kernel_tan>
     f00:	ldr	d17, [x0]
     f04:	adrp	x0, 0 <__kernel_tan>
     f08:	fmul	d0, d0, d1
     f0c:	ldr	d9, [x0]
     f10:	adrp	x0, 0 <__kernel_tan>
     f14:	ldr	d7, [x0]
     f18:	adrp	x0, 0 <__kernel_tan>
     f1c:	fmul	d8, d0, d8
     f20:	fmul	d9, d0, d9
     f24:	ldr	d16, [x0]
     f28:	adrp	x0, 0 <__kernel_tan>
     f2c:	fcmp	d0, #0.0
     f30:	ldr	d5, [x0]
     f34:	adrp	x0, 0 <__kernel_tan>
     f38:	fadd	d8, d8, d17
     f3c:	fsub	d9, d9, d16
     f40:	ldr	d6, [x0]
     f44:	adrp	x0, 0 <__kernel_tan>
     f48:	ldr	d3, [x0]
     f4c:	adrp	x0, 0 <__kernel_tan>
     f50:	fmul	d8, d8, d0
     f54:	fmul	d9, d9, d0
     f58:	ldr	d4, [x0]
     f5c:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     f60:	movk	x0, #0x3fc5, lsl #48
     f64:	fmov	d1, x0
     f68:	fsub	d8, d8, d7
     f6c:	fadd	d9, d9, d6
     f70:	fmul	d8, d8, d0
     f74:	fmul	d9, d9, d0
     f78:	fadd	d8, d8, d5
     f7c:	fsub	d9, d9, d4
     f80:	fmul	d8, d8, d0
     f84:	fmul	d9, d9, d0
     f88:	fsub	d8, d8, d3
     f8c:	fadd	d9, d9, d2
     f90:	fmul	d8, d8, d0
     f94:	fadd	d8, d8, d1
     f98:	fmul	d8, d8, d0
     f9c:	b.pl	fac <pts_ieee754_acos+0x32c>  // b.nfrst
     fa0:	bl	0 <sqrt>
     fa4:	fmov	d2, d0
     fa8:	b	fb0 <pts_ieee754_acos+0x330>
     fac:	fsqrt	d2, d0
     fb0:	fdiv	d1, d8, d9
     fb4:	adrp	x0, 0 <__kernel_tan>
     fb8:	ldp	d8, d9, [sp, #16]
     fbc:	ldr	d3, [x0]
     fc0:	adrp	x0, 0 <__kernel_tan>
     fc4:	ldp	x29, x30, [sp], #32
     fc8:	ldr	d0, [x0]
     fcc:	fmul	d1, d1, d2
     fd0:	fsub	d1, d1, d3
     fd4:	fadd	d1, d1, d2
     fd8:	fadd	d1, d1, d1
     fdc:	fsub	d0, d0, d1
     fe0:	ret

0000000000000fe4 <pts_ieee754_asin>:
     fe4:	fmov	x0, d0
     fe8:	stp	x29, x30, [sp, #-64]!
     fec:	fmov	d2, d0
     ff0:	mov	x29, sp
     ff4:	stp	x19, x20, [sp, #16]
     ff8:	mov	w1, #0x3fefffff            	// #1072693247
     ffc:	ubfx	x19, x0, #32, #31
    1000:	cmp	w19, w1
    1004:	b.le	1054 <pts_ieee754_asin+0x70>
    1008:	mov	w1, #0xc0100000            	// #-1072693248
    100c:	add	w19, w19, w1
    1010:	orr	w19, w19, w0
    1014:	cbz	w19, 102c <pts_ieee754_asin+0x48>
    1018:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    101c:	fmov	d0, x0
    1020:	ldp	x19, x20, [sp, #16]
    1024:	ldp	x29, x30, [sp], #64
    1028:	ret
    102c:	adrp	x0, 0 <__kernel_tan>
    1030:	ldp	x19, x20, [sp, #16]
    1034:	ldr	d1, [x0]
    1038:	adrp	x0, 0 <__kernel_tan>
    103c:	ldr	d0, [x0]
    1040:	fmul	d1, d2, d1
    1044:	ldp	x29, x30, [sp], #64
    1048:	fmul	d0, d2, d0
    104c:	fadd	d0, d1, d0
    1050:	ret
    1054:	lsr	x20, x0, #32
    1058:	mov	w0, #0x3fdfffff            	// #1071644671
    105c:	cmp	w19, w0
    1060:	b.gt	10a0 <pts_ieee754_asin+0xbc>
    1064:	mov	w0, #0x3e3fffff            	// #1044381695
    1068:	cmp	w19, w0
    106c:	b.gt	11d0 <pts_ieee754_asin+0x1ec>
    1070:	adrp	x0, 0 <__kernel_tan>
    1074:	fmov	d3, #1.000000000000000000e+00
    1078:	ldr	d1, [x0]
    107c:	fadd	d1, d0, d1
    1080:	fcmpe	d1, d3
    1084:	b.gt	1020 <pts_ieee754_asin+0x3c>
    1088:	movi	d1, #0x0
    108c:	fmul	d1, d2, d1
    1090:	ldp	x19, x20, [sp, #16]
    1094:	ldp	x29, x30, [sp], #64
    1098:	fadd	d0, d1, d2
    109c:	ret
    10a0:	fabs	d2, d0
    10a4:	fmov	d1, #1.000000000000000000e+00
    10a8:	fmov	d18, #5.000000000000000000e-01
    10ac:	adrp	x0, 0 <__kernel_tan>
    10b0:	stp	d8, d9, [sp, #32]
    10b4:	ldr	d8, [x0]
    10b8:	fsub	d2, d1, d2
    10bc:	adrp	x0, 0 <__kernel_tan>
    10c0:	ldr	d17, [x0]
    10c4:	adrp	x0, 0 <__kernel_tan>
    10c8:	fmul	d2, d2, d18
    10cc:	ldr	d9, [x0]
    10d0:	adrp	x0, 0 <__kernel_tan>
    10d4:	ldr	d7, [x0]
    10d8:	adrp	x0, 0 <__kernel_tan>
    10dc:	fmul	d8, d2, d8
    10e0:	fmul	d9, d2, d9
    10e4:	ldr	d16, [x0]
    10e8:	adrp	x0, 0 <__kernel_tan>
    10ec:	fcmp	d2, #0.0
    10f0:	ldr	d5, [x0]
    10f4:	adrp	x0, 0 <__kernel_tan>
    10f8:	fadd	d8, d8, d17
    10fc:	fsub	d9, d9, d16
    1100:	ldr	d6, [x0]
    1104:	adrp	x0, 0 <__kernel_tan>
    1108:	ldr	d3, [x0]
    110c:	adrp	x0, 0 <__kernel_tan>
    1110:	fmul	d8, d8, d2
    1114:	fmul	d9, d9, d2
    1118:	ldr	d4, [x0]
    111c:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1120:	movk	x0, #0x3fc5, lsl #48
    1124:	fmov	d0, x0
    1128:	fsub	d8, d8, d7
    112c:	fadd	d9, d9, d6
    1130:	fmul	d8, d8, d2
    1134:	fmul	d9, d9, d2
    1138:	fadd	d8, d8, d5
    113c:	fsub	d9, d9, d4
    1140:	fmul	d8, d8, d2
    1144:	fmul	d9, d9, d2
    1148:	fsub	d8, d8, d3
    114c:	fadd	d9, d9, d1
    1150:	fmul	d8, d8, d2
    1154:	fadd	d8, d8, d0
    1158:	fmul	d8, d8, d2
    115c:	b.pl	1178 <pts_ieee754_asin+0x194>  // b.nfrst
    1160:	fmov	d0, d2
    1164:	str	d2, [sp, #56]
    1168:	bl	0 <sqrt>
    116c:	fmov	d1, d0
    1170:	ldr	d2, [sp, #56]
    1174:	b	117c <pts_ieee754_asin+0x198>
    1178:	fsqrt	d1, d2
    117c:	fdiv	d8, d8, d9
    1180:	mov	w0, #0x3332                	// #13106
    1184:	movk	w0, #0x3fef, lsl #16
    1188:	cmp	w19, w0
    118c:	b.le	1288 <pts_ieee754_asin+0x2a4>
    1190:	fmul	d8, d1, d8
    1194:	adrp	x0, 0 <__kernel_tan>
    1198:	ldr	d2, [x0]
    119c:	adrp	x0, 0 <__kernel_tan>
    11a0:	fadd	d8, d8, d1
    11a4:	ldr	d0, [x0]
    11a8:	fadd	d8, d8, d8
    11ac:	fsub	d8, d8, d2
    11b0:	fsub	d0, d0, d8
    11b4:	fneg	d1, d0
    11b8:	cmp	w20, #0x0
    11bc:	ldp	x19, x20, [sp, #16]
    11c0:	ldp	d8, d9, [sp, #32]
    11c4:	fcsel	d0, d1, d0, le
    11c8:	ldp	x29, x30, [sp], #64
    11cc:	ret
    11d0:	adrp	x0, 0 <__kernel_tan>
    11d4:	fmul	d3, d0, d0
    11d8:	stp	d8, d9, [sp, #32]
    11dc:	fmov	d5, #1.000000000000000000e+00
    11e0:	ldr	d1, [x0]
    11e4:	adrp	x0, 0 <__kernel_tan>
    11e8:	fmul	d1, d3, d1
    11ec:	ldr	d18, [x0]
    11f0:	adrp	x0, 0 <__kernel_tan>
    11f4:	ldr	d16, [x0]
    11f8:	adrp	x0, 0 <__kernel_tan>
    11fc:	fadd	d1, d1, d18
    1200:	ldr	d0, [x0]
    1204:	adrp	x0, 0 <__kernel_tan>
    1208:	ldr	d17, [x0]
    120c:	adrp	x0, 0 <__kernel_tan>
    1210:	fmul	d1, d1, d3
    1214:	fmul	d0, d3, d0
    1218:	ldr	d8, [x0]
    121c:	adrp	x0, 0 <__kernel_tan>
    1220:	ldr	d9, [x0]
    1224:	adrp	x0, 0 <__kernel_tan>
    1228:	fsub	d1, d1, d16
    122c:	fsub	d0, d0, d17
    1230:	ldr	d6, [x0]
    1234:	adrp	x0, 0 <__kernel_tan>
    1238:	ldr	d7, [x0]
    123c:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1240:	fmul	d1, d1, d3
    1244:	fmul	d0, d0, d3
    1248:	movk	x0, #0x3fc5, lsl #48
    124c:	fmov	d4, x0
    1250:	fadd	d1, d1, d8
    1254:	fadd	d0, d0, d9
    1258:	ldp	d8, d9, [sp, #32]
    125c:	fmul	d1, d1, d3
    1260:	fmul	d0, d0, d3
    1264:	fsub	d1, d1, d6
    1268:	fsub	d0, d0, d7
    126c:	fmul	d1, d1, d3
    1270:	fmul	d0, d0, d3
    1274:	fadd	d1, d1, d4
    1278:	fadd	d0, d0, d5
    127c:	fmul	d1, d1, d3
    1280:	fdiv	d1, d1, d0
    1284:	b	108c <pts_ieee754_asin+0xa8>
    1288:	movi	v0.2d, #0xffffffff00000000
    128c:	fadd	d4, d1, d1
    1290:	adrp	x0, 0 <__kernel_tan>
    1294:	ldr	d5, [x0]
    1298:	adrp	x0, 0 <__kernel_tan>
    129c:	and	v3.8b, v1.8b, v0.8b
    12a0:	fmul	d4, d4, d8
    12a4:	ldr	d0, [x0]
    12a8:	fmul	d6, d3, d3
    12ac:	fadd	d1, d3, d1
    12b0:	fadd	d3, d3, d3
    12b4:	fsub	d2, d2, d6
    12b8:	fsub	d3, d0, d3
    12bc:	fdiv	d2, d2, d1
    12c0:	fadd	d2, d2, d2
    12c4:	fsub	d1, d5, d2
    12c8:	fsub	d1, d4, d1
    12cc:	fsub	d1, d1, d3
    12d0:	fsub	d0, d0, d1
    12d4:	b	11b4 <pts_ieee754_asin+0x1d0>
    12d8:	nop
    12dc:	nop

00000000000012e0 <pts_ieee754_atan>:
    12e0:	fmov	x1, d0
    12e4:	fmov	d3, d0
    12e8:	mov	w2, #0x440fffff            	// #1141899263
    12ec:	ubfx	x0, x1, #32, #31
    12f0:	lsr	x3, x1, #32
    12f4:	cmp	w0, w2
    12f8:	b.le	1340 <pts_ieee754_atan+0x60>
    12fc:	mov	w2, #0x7ff00000            	// #2146435072
    1300:	cmp	w0, w2
    1304:	b.gt	1338 <pts_ieee754_atan+0x58>
    1308:	cmp	w1, #0x0
    130c:	ccmp	w0, w2, #0x0, ne	// ne = any
    1310:	b.eq	1338 <pts_ieee754_atan+0x58>  // b.none
    1314:	adrp	x0, 0 <__kernel_tan>
    1318:	add	x0, x0, #0x0
    131c:	cmp	w3, #0x0
    1320:	b.le	14d4 <pts_ieee754_atan+0x1f4>
    1324:	adrp	x1, 0 <__kernel_tan>
    1328:	ldr	d0, [x0, #488]
    132c:	ldr	d1, [x1]
    1330:	fadd	d0, d0, d1
    1334:	ret
    1338:	fadd	d0, d3, d3
    133c:	ret
    1340:	mov	w1, #0x3fdbffff            	// #1071382527
    1344:	cmp	w0, w1
    1348:	b.gt	1450 <pts_ieee754_atan+0x170>
    134c:	mov	w1, #0x3e3fffff            	// #1044381695
    1350:	cmp	w0, w1
    1354:	b.le	14b8 <pts_ieee754_atan+0x1d8>
    1358:	mov	x0, #0xffffffffffffffff    	// #-1
    135c:	fmul	d4, d3, d3
    1360:	adrp	x1, 0 <__kernel_tan>
    1364:	ldr	d1, [x1]
    1368:	adrp	x1, 0 <__kernel_tan>
    136c:	fmul	d0, d4, d4
    1370:	ldr	d21, [x1]
    1374:	adrp	x1, 0 <__kernel_tan>
    1378:	ldr	d2, [x1]
    137c:	adrp	x1, 0 <__kernel_tan>
    1380:	fmul	d1, d0, d1
    1384:	ldr	d19, [x1]
    1388:	adrp	x1, 0 <__kernel_tan>
    138c:	fmul	d2, d0, d2
    1390:	ldr	d20, [x1]
    1394:	adrp	x1, 0 <__kernel_tan>
    1398:	fadd	d1, d1, d21
    139c:	ldr	d17, [x1]
    13a0:	adrp	x1, 0 <__kernel_tan>
    13a4:	fsub	d2, d2, d20
    13a8:	ldr	d18, [x1]
    13ac:	adrp	x1, 0 <__kernel_tan>
    13b0:	fmul	d1, d1, d0
    13b4:	ldr	d7, [x1]
    13b8:	adrp	x1, 0 <__kernel_tan>
    13bc:	fmul	d2, d2, d0
    13c0:	ldr	d16, [x1]
    13c4:	adrp	x1, 0 <__kernel_tan>
    13c8:	fadd	d1, d1, d19
    13cc:	ldr	d5, [x1]
    13d0:	adrp	x1, 0 <__kernel_tan>
    13d4:	fsub	d2, d2, d18
    13d8:	ldr	d6, [x1]
    13dc:	fmul	d1, d1, d0
    13e0:	fmul	d2, d2, d0
    13e4:	fadd	d1, d1, d17
    13e8:	fsub	d2, d2, d16
    13ec:	fmul	d1, d1, d0
    13f0:	fmul	d2, d2, d0
    13f4:	fadd	d1, d1, d7
    13f8:	fsub	d2, d2, d6
    13fc:	fmul	d1, d1, d0
    1400:	fmul	d2, d2, d0
    1404:	fadd	d1, d1, d5
    1408:	fmul	d1, d1, d4
    140c:	fadd	d1, d1, d2
    1410:	fmul	d1, d1, d3
    1414:	cmn	w0, #0x1
    1418:	b.eq	14e8 <pts_ieee754_atan+0x208>  // b.none
    141c:	adrp	x1, 0 <__kernel_tan>
    1420:	add	x1, x1, #0x0
    1424:	add	x2, x1, #0x1d0
    1428:	add	x1, x1, #0x1f0
    142c:	cmp	w3, #0x0
    1430:	ldr	d0, [x2, x0, lsl #3]
    1434:	ldr	d2, [x1, x0, lsl #3]
    1438:	fsub	d1, d1, d0
    143c:	fsub	d0, d1, d3
    1440:	fsub	d0, d2, d0
    1444:	fneg	d1, d0
    1448:	fcsel	d0, d1, d0, lt	// lt = tstop
    144c:	ret
    1450:	fabs	d3, d0
    1454:	mov	w1, #0x3ff2ffff            	// #1072889855
    1458:	cmp	w0, w1
    145c:	b.gt	148c <pts_ieee754_atan+0x1ac>
    1460:	mov	w1, #0x3fe5ffff            	// #1072037887
    1464:	cmp	w0, w1
    1468:	b.gt	1500 <pts_ieee754_atan+0x220>
    146c:	fadd	d0, d3, d3
    1470:	fmov	d1, #1.000000000000000000e+00
    1474:	fmov	d2, #2.000000000000000000e+00
    1478:	mov	x0, #0x0                   	// #0
    147c:	fadd	d3, d3, d2
    1480:	fsub	d0, d0, d1
    1484:	fdiv	d3, d0, d3
    1488:	b	135c <pts_ieee754_atan+0x7c>
    148c:	add	w1, w1, #0x108, lsl #12
    1490:	cmp	w0, w1
    1494:	b.gt	14f0 <pts_ieee754_atan+0x210>
    1498:	fmov	d1, #1.500000000000000000e+00
    149c:	fmov	d2, #1.000000000000000000e+00
    14a0:	mov	x0, #0x2                   	// #2
    14a4:	fmul	d0, d3, d1
    14a8:	fsub	d3, d3, d1
    14ac:	fadd	d0, d0, d2
    14b0:	fdiv	d3, d3, d0
    14b4:	b	135c <pts_ieee754_atan+0x7c>
    14b8:	adrp	x0, 0 <__kernel_tan>
    14bc:	fmov	d2, #1.000000000000000000e+00
    14c0:	ldr	d1, [x0]
    14c4:	fadd	d1, d0, d1
    14c8:	fcmpe	d1, d2
    14cc:	b.gt	1334 <pts_ieee754_atan+0x54>
    14d0:	b	1358 <pts_ieee754_atan+0x78>
    14d4:	adrp	x1, 0 <__kernel_tan>
    14d8:	ldr	d1, [x0, #488]
    14dc:	ldr	d0, [x1]
    14e0:	fsub	d0, d0, d1
    14e4:	ret
    14e8:	fsub	d0, d3, d1
    14ec:	ret
    14f0:	fmov	d0, #-1.000000000000000000e+00
    14f4:	mov	x0, #0x3                   	// #3
    14f8:	fdiv	d3, d0, d3
    14fc:	b	135c <pts_ieee754_atan+0x7c>
    1500:	fmov	d0, #1.000000000000000000e+00
    1504:	mov	x0, #0x1                   	// #1
    1508:	fsub	d1, d3, d0
    150c:	fadd	d3, d3, d0
    1510:	fdiv	d3, d1, d3
    1514:	b	135c <pts_ieee754_atan+0x7c>
    1518:	nop
    151c:	nop

0000000000001520 <pts_ieee754_atan2>:
    1520:	fmov	x1, d1
    1524:	fmov	d2, d0
    1528:	mov	w3, #0x7ff00000            	// #2146435072
    152c:	neg	w0, w1
    1530:	ubfx	x5, x1, #32, #31
    1534:	orr	w0, w0, w1
    1538:	orr	w0, w5, w0, lsr #31
    153c:	cmp	w0, w3
    1540:	b.hi	15fc <pts_ieee754_atan2+0xdc>  // b.pmore
    1544:	fmov	x0, d0
    1548:	neg	w2, w0
    154c:	ubfx	x6, x0, #32, #31
    1550:	orr	w2, w2, w0
    1554:	lsr	x8, x0, #32
    1558:	orr	w2, w6, w2, lsr #31
    155c:	cmp	w2, w3
    1560:	b.hi	15fc <pts_ieee754_atan2+0xdc>  // b.pmore
    1564:	lsr	x7, x1, #32
    1568:	mov	w2, #0xc0100000            	// #-1072693248
    156c:	add	w2, w7, w2
    1570:	orr	w2, w2, w1
    1574:	cbz	w2, 1618 <pts_ieee754_atan2+0xf8>
    1578:	asr	w4, w7, #30
    157c:	lsr	w2, w8, #31
    1580:	and	w4, w4, #0x2
    1584:	orr	w0, w6, w0
    1588:	orr	w4, w4, w2
    158c:	cbz	w0, 1604 <pts_ieee754_atan2+0xe4>
    1590:	orr	w1, w5, w1
    1594:	cbz	w1, 161c <pts_ieee754_atan2+0xfc>
    1598:	cmp	w5, w3
    159c:	b.eq	16a4 <pts_ieee754_atan2+0x184>  // b.none
    15a0:	cmp	w6, w3
    15a4:	b.eq	161c <pts_ieee754_atan2+0xfc>  // b.none
    15a8:	sub	w6, w6, w5
    15ac:	asr	w6, w6, #20
    15b0:	cmp	w6, #0x3c
    15b4:	b.gt	167c <pts_ieee754_atan2+0x15c>
    15b8:	cmp	w7, #0x0
    15bc:	mov	w0, #0xffffffc4            	// #-60
    15c0:	movi	d0, #0x0
    15c4:	ccmp	w6, w0, #0x0, lt	// lt = tstop
    15c8:	b.ge	1730 <pts_ieee754_atan2+0x210>  // b.tcont
    15cc:	cmp	w4, #0x1
    15d0:	b.eq	1728 <pts_ieee754_atan2+0x208>  // b.none
    15d4:	cmp	w4, #0x2
    15d8:	b.ne	1704 <pts_ieee754_atan2+0x1e4>  // b.any
    15dc:	adrp	x0, 0 <__kernel_tan>
    15e0:	add	x0, x0, #0x0
    15e4:	adrp	x1, 0 <__kernel_tan>
    15e8:	ldr	d2, [x0, #8]
    15ec:	ldr	d1, [x1]
    15f0:	fsub	d0, d0, d2
    15f4:	fsub	d0, d1, d0
    15f8:	ret
    15fc:	fadd	d0, d1, d2
    1600:	ret
    1604:	cmp	w4, #0x2
    1608:	b.eq	1650 <pts_ieee754_atan2+0x130>  // b.none
    160c:	cmp	w4, #0x3
    1610:	b.eq	1638 <pts_ieee754_atan2+0x118>  // b.none
    1614:	ret
    1618:	b	12e0 <pts_ieee754_atan>
    161c:	adrp	x0, 0 <__kernel_tan>
    1620:	tbnz	w8, #31, 1668 <pts_ieee754_atan2+0x148>
    1624:	adrp	x1, 0 <__kernel_tan>
    1628:	ldr	d0, [x0]
    162c:	ldr	d1, [x1]
    1630:	fadd	d0, d0, d1
    1634:	ret
    1638:	adrp	x0, 0 <__kernel_tan>
    163c:	adrp	x1, 0 <__kernel_tan>
    1640:	ldr	d1, [x0]
    1644:	ldr	d0, [x1]
    1648:	fsub	d0, d0, d1
    164c:	ret
    1650:	adrp	x0, 0 <__kernel_tan>
    1654:	adrp	x1, 0 <__kernel_tan>
    1658:	ldr	d0, [x0]
    165c:	ldr	d1, [x1]
    1660:	fadd	d0, d0, d1
    1664:	ret
    1668:	adrp	x1, 0 <__kernel_tan>
    166c:	ldr	d1, [x0]
    1670:	ldr	d0, [x1]
    1674:	fsub	d0, d0, d1
    1678:	ret
    167c:	adrp	x0, 0 <__kernel_tan>
    1680:	add	x0, x0, #0x0
    1684:	fmov	d2, #5.000000000000000000e-01
    1688:	adrp	x1, 0 <__kernel_tan>
    168c:	ldr	d0, [x0, #8]
    1690:	ldr	d1, [x1]
    1694:	fmul	d0, d0, d2
    1698:	fadd	d0, d0, d1
    169c:	tbnz	w4, #0, 1728 <pts_ieee754_atan2+0x208>
    16a0:	ret
    16a4:	cmp	w6, w5
    16a8:	b.eq	16d4 <pts_ieee754_atan2+0x1b4>  // b.none
    16ac:	cmp	w4, #0x2
    16b0:	b.eq	1650 <pts_ieee754_atan2+0x130>  // b.none
    16b4:	cmp	w4, #0x3
    16b8:	b.eq	1638 <pts_ieee754_atan2+0x118>  // b.none
    16bc:	movi	d1, #0x0
    16c0:	cmp	w4, #0x1
    16c4:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
    16c8:	fmov	d0, x0
    16cc:	fcsel	d0, d0, d1, eq	// eq = none
    16d0:	ret
    16d4:	adrp	x0, 0 <__kernel_tan>
    16d8:	cmp	w4, #0x2
    16dc:	b.eq	17cc <pts_ieee754_atan2+0x2ac>  // b.none
    16e0:	cmp	w4, #0x3
    16e4:	b.eq	17b8 <pts_ieee754_atan2+0x298>  // b.none
    16e8:	cmp	w4, #0x1
    16ec:	b.eq	17a4 <pts_ieee754_atan2+0x284>  // b.none
    16f0:	adrp	x1, 0 <__kernel_tan>
    16f4:	ldr	d0, [x0]
    16f8:	ldr	d1, [x1]
    16fc:	fadd	d0, d0, d1
    1700:	ret
    1704:	cbz	w4, 17e0 <pts_ieee754_atan2+0x2c0>
    1708:	adrp	x0, 0 <__kernel_tan>
    170c:	add	x0, x0, #0x0
    1710:	adrp	x1, 0 <__kernel_tan>
    1714:	ldr	d2, [x0, #8]
    1718:	ldr	d1, [x1]
    171c:	fsub	d0, d0, d2
    1720:	fsub	d0, d0, d1
    1724:	ret
    1728:	fneg	d0, d0
    172c:	ret
    1730:	fdiv	d0, d2, d1
    1734:	stp	x29, x30, [sp, #-16]!
    1738:	mov	x29, sp
    173c:	fabs	d0, d0
    1740:	bl	12e0 <pts_ieee754_atan>
    1744:	cmp	w4, #0x1
    1748:	b.eq	1778 <pts_ieee754_atan2+0x258>  // b.none
    174c:	cmp	w4, #0x2
    1750:	b.ne	1780 <pts_ieee754_atan2+0x260>  // b.any
    1754:	adrp	x0, 0 <__kernel_tan>
    1758:	add	x0, x0, #0x0
    175c:	adrp	x1, 0 <__kernel_tan>
    1760:	ldr	d2, [x0, #8]
    1764:	ldr	d1, [x1]
    1768:	fsub	d0, d0, d2
    176c:	fsub	d0, d1, d0
    1770:	ldp	x29, x30, [sp], #16
    1774:	ret
    1778:	fneg	d0, d0
    177c:	b	1770 <pts_ieee754_atan2+0x250>
    1780:	cbz	w4, 1770 <pts_ieee754_atan2+0x250>
    1784:	adrp	x0, 0 <__kernel_tan>
    1788:	add	x0, x0, #0x0
    178c:	adrp	x1, 0 <__kernel_tan>
    1790:	ldr	d2, [x0, #8]
    1794:	ldr	d1, [x1]
    1798:	fsub	d0, d0, d2
    179c:	fsub	d0, d0, d1
    17a0:	b	1770 <pts_ieee754_atan2+0x250>
    17a4:	adrp	x1, 0 <__kernel_tan>
    17a8:	ldr	d1, [x0]
    17ac:	ldr	d0, [x1]
    17b0:	fsub	d0, d0, d1
    17b4:	ret
    17b8:	adrp	x1, 0 <__kernel_tan>
    17bc:	ldr	d1, [x0]
    17c0:	ldr	d0, [x1]
    17c4:	fsub	d0, d0, d1
    17c8:	ret
    17cc:	adrp	x1, 0 <__kernel_tan>
    17d0:	ldr	d0, [x0]
    17d4:	ldr	d1, [x1]
    17d8:	fadd	d0, d0, d1
    17dc:	ret
    17e0:	ret

00000000000017e4 <pts_ieee754_cos>:
    17e4:	sub	sp, sp, #0x30
    17e8:	mov	w1, #0x21fb                	// #8699
    17ec:	adrp	x0, 0 <__stack_chk_guard>
    17f0:	ldr	x0, [x0]
    17f4:	fmov	d1, d0
    17f8:	stp	x29, x30, [sp, #32]
    17fc:	add	x29, sp, #0x20
    1800:	movk	w1, #0x3fe9, lsl #16
    1804:	ldr	x2, [x0]
    1808:	str	x2, [sp, #24]
    180c:	mov	x2, #0x0                   	// #0
    1810:	fmov	x0, d0
    1814:	ubfx	x0, x0, #32, #31
    1818:	cmp	w0, w1
    181c:	b.le	1944 <pts_ieee754_cos+0x160>
    1820:	mov	w1, #0x7fefffff            	// #2146435071
    1824:	cmp	w0, w1
    1828:	b.le	1858 <pts_ieee754_cos+0x74>
    182c:	fsub	d0, d0, d0
    1830:	adrp	x0, 0 <__stack_chk_guard>
    1834:	ldr	x0, [x0]
    1838:	ldr	x2, [sp, #24]
    183c:	ldr	x1, [x0]
    1840:	subs	x2, x2, x1
    1844:	mov	x1, #0x0                   	// #0
    1848:	b.ne	1df8 <pts_ieee754_cos+0x614>  // b.any
    184c:	ldp	x29, x30, [sp, #32]
    1850:	add	sp, sp, #0x30
    1854:	ret
    1858:	add	x0, sp, #0x8
    185c:	bl	964 <__ieee754_rem_pio2>
    1860:	and	w0, w0, #0x3
    1864:	cmp	w0, #0x1
    1868:	b.eq	1c08 <pts_ieee754_cos+0x424>  // b.none
    186c:	cmp	w0, #0x2
    1870:	b.eq	1a98 <pts_ieee754_cos+0x2b4>  // b.none
    1874:	cbnz	w0, 1b68 <pts_ieee754_cos+0x384>
    1878:	ldp	d3, d6, [sp, #8]
    187c:	mov	w1, #0x3e3fffff            	// #1044381695
    1880:	fmov	x0, d3
    1884:	ubfx	x0, x0, #32, #31
    1888:	cmp	w0, w1
    188c:	b.le	1d54 <pts_ieee754_cos+0x570>
    1890:	adrp	x1, 0 <__kernel_tan>
    1894:	fmul	d2, d3, d3
    1898:	ldr	d1, [x1]
    189c:	adrp	x1, 0 <__kernel_tan>
    18a0:	ldr	d16, [x1]
    18a4:	adrp	x1, 0 <__kernel_tan>
    18a8:	fmul	d1, d2, d1
    18ac:	ldr	d7, [x1]
    18b0:	adrp	x1, 0 <__kernel_tan>
    18b4:	ldr	d5, [x1]
    18b8:	adrp	x1, 0 <__kernel_tan>
    18bc:	fadd	d1, d1, d16
    18c0:	ldr	d4, [x1]
    18c4:	adrp	x1, 0 <__kernel_tan>
    18c8:	ldr	d0, [x1]
    18cc:	mov	w1, #0x3332                	// #13106
    18d0:	fmul	d1, d1, d2
    18d4:	movk	w1, #0x3fd3, lsl #16
    18d8:	fsub	d1, d1, d7
    18dc:	fmul	d1, d1, d2
    18e0:	fadd	d1, d1, d5
    18e4:	fmul	d1, d1, d2
    18e8:	fsub	d1, d1, d4
    18ec:	fmul	d1, d1, d2
    18f0:	fadd	d1, d1, d0
    18f4:	fmul	d1, d1, d2
    18f8:	cmp	w0, w1
    18fc:	b.le	1dbc <pts_ieee754_cos+0x5d8>
    1900:	mov	w1, #0x3fe90000            	// #1072234496
    1904:	cmp	w0, w1
    1908:	b.gt	1dec <pts_ieee754_cos+0x608>
    190c:	sub	w0, w0, #0x200, lsl #12
    1910:	fmov	d4, x0
    1914:	fmov	d0, #1.000000000000000000e+00
    1918:	shl	d4, d4, #32
    191c:	fsub	d0, d0, d4
    1920:	fmov	d5, #5.000000000000000000e-01
    1924:	fmul	d1, d2, d1
    1928:	fmul	d3, d3, d6
    192c:	fmul	d2, d2, d5
    1930:	fsub	d1, d1, d3
    1934:	fsub	d2, d2, d4
    1938:	fsub	d1, d2, d1
    193c:	fsub	d0, d0, d1
    1940:	b	1830 <pts_ieee754_cos+0x4c>
    1944:	mov	w1, #0x3e3fffff            	// #1044381695
    1948:	cmp	w0, w1
    194c:	b.le	1a08 <pts_ieee754_cos+0x224>
    1950:	adrp	x1, 0 <__kernel_tan>
    1954:	fmul	d3, d0, d0
    1958:	ldr	d2, [x1]
    195c:	adrp	x1, 0 <__kernel_tan>
    1960:	ldr	d7, [x1]
    1964:	adrp	x1, 0 <__kernel_tan>
    1968:	fmul	d2, d3, d2
    196c:	ldr	d6, [x1]
    1970:	adrp	x1, 0 <__kernel_tan>
    1974:	ldr	d5, [x1]
    1978:	adrp	x1, 0 <__kernel_tan>
    197c:	fadd	d2, d2, d7
    1980:	ldr	d4, [x1]
    1984:	adrp	x1, 0 <__kernel_tan>
    1988:	ldr	d0, [x1]
    198c:	mov	w1, #0x3332                	// #13106
    1990:	fmul	d2, d2, d3
    1994:	movk	w1, #0x3fd3, lsl #16
    1998:	fsub	d2, d2, d6
    199c:	fmul	d2, d2, d3
    19a0:	fadd	d2, d2, d5
    19a4:	fmul	d2, d2, d3
    19a8:	fsub	d2, d2, d4
    19ac:	fmul	d2, d2, d3
    19b0:	fadd	d2, d2, d0
    19b4:	fmul	d2, d2, d3
    19b8:	cmp	w0, w1
    19bc:	b.le	1a70 <pts_ieee754_cos+0x28c>
    19c0:	mov	w1, #0x3fe90000            	// #1072234496
    19c4:	cmp	w0, w1
    19c8:	b.gt	1cb4 <pts_ieee754_cos+0x4d0>
    19cc:	sub	w0, w0, #0x200, lsl #12
    19d0:	fmov	d0, x0
    19d4:	fmov	d6, #1.000000000000000000e+00
    19d8:	shl	d0, d0, #32
    19dc:	fsub	d6, d6, d0
    19e0:	movi	d5, #0x0
    19e4:	fmov	d4, #5.000000000000000000e-01
    19e8:	fmul	d2, d3, d2
    19ec:	fmul	d3, d3, d4
    19f0:	fmul	d1, d1, d5
    19f4:	fsub	d0, d3, d0
    19f8:	fsub	d2, d2, d1
    19fc:	fsub	d0, d0, d2
    1a00:	fsub	d0, d6, d0
    1a04:	b	1830 <pts_ieee754_cos+0x4c>
    1a08:	fcvtzs	w0, d0
    1a0c:	cbz	w0, 1cac <pts_ieee754_cos+0x4c8>
    1a10:	adrp	x0, 0 <__kernel_tan>
    1a14:	fmul	d3, d0, d0
    1a18:	ldr	d2, [x0]
    1a1c:	adrp	x0, 0 <__kernel_tan>
    1a20:	ldr	d7, [x0]
    1a24:	adrp	x0, 0 <__kernel_tan>
    1a28:	fmul	d2, d3, d2
    1a2c:	ldr	d6, [x0]
    1a30:	adrp	x0, 0 <__kernel_tan>
    1a34:	ldr	d5, [x0]
    1a38:	adrp	x0, 0 <__kernel_tan>
    1a3c:	fadd	d2, d2, d7
    1a40:	ldr	d4, [x0]
    1a44:	adrp	x0, 0 <__kernel_tan>
    1a48:	ldr	d0, [x0]
    1a4c:	fmul	d2, d2, d3
    1a50:	fsub	d2, d2, d6
    1a54:	fmul	d2, d2, d3
    1a58:	fadd	d2, d2, d5
    1a5c:	fmul	d2, d2, d3
    1a60:	fsub	d2, d2, d4
    1a64:	fmul	d2, d2, d3
    1a68:	fadd	d2, d2, d0
    1a6c:	fmul	d2, d2, d3
    1a70:	movi	d4, #0x0
    1a74:	fmul	d2, d3, d2
    1a78:	fmov	d0, #5.000000000000000000e-01
    1a7c:	fmov	d5, #1.000000000000000000e+00
    1a80:	fmul	d0, d3, d0
    1a84:	fmul	d1, d1, d4
    1a88:	fsub	d2, d2, d1
    1a8c:	fsub	d0, d0, d2
    1a90:	fsub	d0, d5, d0
    1a94:	b	1830 <pts_ieee754_cos+0x4c>
    1a98:	ldp	d3, d5, [sp, #8]
    1a9c:	mov	w1, #0x3e3fffff            	// #1044381695
    1aa0:	fmov	x0, d3
    1aa4:	ubfx	x0, x0, #32, #31
    1aa8:	cmp	w0, w1
    1aac:	b.le	1cc0 <pts_ieee754_cos+0x4dc>
    1ab0:	adrp	x1, 0 <__kernel_tan>
    1ab4:	fmul	d2, d3, d3
    1ab8:	ldr	d1, [x1]
    1abc:	adrp	x1, 0 <__kernel_tan>
    1ac0:	ldr	d16, [x1]
    1ac4:	adrp	x1, 0 <__kernel_tan>
    1ac8:	fmul	d1, d2, d1
    1acc:	ldr	d7, [x1]
    1ad0:	adrp	x1, 0 <__kernel_tan>
    1ad4:	ldr	d6, [x1]
    1ad8:	adrp	x1, 0 <__kernel_tan>
    1adc:	fadd	d1, d1, d16
    1ae0:	ldr	d4, [x1]
    1ae4:	adrp	x1, 0 <__kernel_tan>
    1ae8:	ldr	d0, [x1]
    1aec:	mov	w1, #0x3332                	// #13106
    1af0:	fmul	d1, d1, d2
    1af4:	movk	w1, #0x3fd3, lsl #16
    1af8:	fsub	d1, d1, d7
    1afc:	fmul	d1, d1, d2
    1b00:	fadd	d1, d1, d6
    1b04:	fmul	d1, d1, d2
    1b08:	fsub	d1, d1, d4
    1b0c:	fmul	d1, d1, d2
    1b10:	fadd	d1, d1, d0
    1b14:	fmul	d1, d1, d2
    1b18:	cmp	w0, w1
    1b1c:	b.le	1d2c <pts_ieee754_cos+0x548>
    1b20:	mov	w1, #0x3fe90000            	// #1072234496
    1b24:	cmp	w0, w1
    1b28:	b.gt	1de0 <pts_ieee754_cos+0x5fc>
    1b2c:	sub	w0, w0, #0x200, lsl #12
    1b30:	fmov	d4, x0
    1b34:	fmov	d0, #1.000000000000000000e+00
    1b38:	shl	d4, d4, #32
    1b3c:	fsub	d0, d0, d4
    1b40:	fmov	d6, #5.000000000000000000e-01
    1b44:	fmul	d1, d2, d1
    1b48:	fmul	d3, d3, d5
    1b4c:	fmul	d2, d2, d6
    1b50:	fsub	d1, d1, d3
    1b54:	fsub	d2, d2, d4
    1b58:	fsub	d1, d2, d1
    1b5c:	fsub	d0, d0, d1
    1b60:	fneg	d0, d0
    1b64:	b	1830 <pts_ieee754_cos+0x4c>
    1b68:	ldp	d0, d5, [sp, #8]
    1b6c:	mov	w0, #0x3e3fffff            	// #1044381695
    1b70:	fmov	x1, d0
    1b74:	ubfx	x1, x1, #32, #31
    1b78:	cmp	w1, w0
    1b7c:	b.gt	1b88 <pts_ieee754_cos+0x3a4>
    1b80:	fcvtzs	w0, d0
    1b84:	cbz	w0, 1830 <pts_ieee754_cos+0x4c>
    1b88:	adrp	x0, 0 <__kernel_tan>
    1b8c:	fmul	d3, d0, d0
    1b90:	fmov	d2, #5.000000000000000000e-01
    1b94:	ldr	d1, [x0]
    1b98:	adrp	x0, 0 <__kernel_tan>
    1b9c:	fmul	d2, d5, d2
    1ba0:	ldr	d18, [x0]
    1ba4:	adrp	x0, 0 <__kernel_tan>
    1ba8:	fmul	d1, d3, d1
    1bac:	fmul	d6, d0, d3
    1bb0:	ldr	d17, [x0]
    1bb4:	adrp	x0, 0 <__kernel_tan>
    1bb8:	ldr	d16, [x0]
    1bbc:	adrp	x0, 0 <__kernel_tan>
    1bc0:	fsub	d1, d1, d18
    1bc4:	ldr	d7, [x0]
    1bc8:	adrp	x0, 0 <__kernel_tan>
    1bcc:	ldr	d4, [x0]
    1bd0:	fmul	d1, d1, d3
    1bd4:	fmul	d4, d6, d4
    1bd8:	fadd	d1, d1, d17
    1bdc:	fmul	d1, d1, d3
    1be0:	fsub	d1, d1, d16
    1be4:	fmul	d1, d1, d3
    1be8:	fadd	d1, d1, d7
    1bec:	fmul	d1, d1, d6
    1bf0:	fsub	d1, d2, d1
    1bf4:	fmul	d1, d1, d3
    1bf8:	fsub	d1, d1, d5
    1bfc:	fadd	d1, d1, d4
    1c00:	fsub	d0, d0, d1
    1c04:	b	1830 <pts_ieee754_cos+0x4c>
    1c08:	ldp	d0, d5, [sp, #8]
    1c0c:	mov	w0, #0x3e3fffff            	// #1044381695
    1c10:	fmov	x1, d0
    1c14:	ubfx	x1, x1, #32, #31
    1c18:	cmp	w1, w0
    1c1c:	b.gt	1c28 <pts_ieee754_cos+0x444>
    1c20:	fcvtzs	w0, d0
    1c24:	cbz	w0, 1ca4 <pts_ieee754_cos+0x4c0>
    1c28:	adrp	x0, 0 <__kernel_tan>
    1c2c:	fmul	d3, d0, d0
    1c30:	fmov	d2, #5.000000000000000000e-01
    1c34:	ldr	d1, [x0]
    1c38:	adrp	x0, 0 <__kernel_tan>
    1c3c:	fmul	d2, d5, d2
    1c40:	ldr	d18, [x0]
    1c44:	adrp	x0, 0 <__kernel_tan>
    1c48:	fmul	d1, d3, d1
    1c4c:	fmul	d6, d0, d3
    1c50:	ldr	d17, [x0]
    1c54:	adrp	x0, 0 <__kernel_tan>
    1c58:	ldr	d16, [x0]
    1c5c:	adrp	x0, 0 <__kernel_tan>
    1c60:	fsub	d1, d1, d18
    1c64:	ldr	d7, [x0]
    1c68:	adrp	x0, 0 <__kernel_tan>
    1c6c:	ldr	d4, [x0]
    1c70:	fmul	d1, d1, d3
    1c74:	fmul	d4, d6, d4
    1c78:	fadd	d1, d1, d17
    1c7c:	fmul	d1, d1, d3
    1c80:	fsub	d1, d1, d16
    1c84:	fmul	d1, d1, d3
    1c88:	fadd	d1, d1, d7
    1c8c:	fmul	d1, d1, d6
    1c90:	fsub	d1, d2, d1
    1c94:	fmul	d1, d1, d3
    1c98:	fsub	d1, d1, d5
    1c9c:	fadd	d1, d1, d4
    1ca0:	fsub	d0, d0, d1
    1ca4:	fneg	d0, d0
    1ca8:	b	1830 <pts_ieee754_cos+0x4c>
    1cac:	fmov	d0, #1.000000000000000000e+00
    1cb0:	b	1830 <pts_ieee754_cos+0x4c>
    1cb4:	fmov	d6, #7.187500000000000000e-01
    1cb8:	fmov	d0, #2.812500000000000000e-01
    1cbc:	b	19e0 <pts_ieee754_cos+0x1fc>
    1cc0:	fcvtzs	w0, d3
    1cc4:	fmov	d0, #-1.000000000000000000e+00
    1cc8:	cbz	w0, 1830 <pts_ieee754_cos+0x4c>
    1ccc:	adrp	x0, 0 <__kernel_tan>
    1cd0:	fmul	d2, d3, d3
    1cd4:	ldr	d1, [x0]
    1cd8:	adrp	x0, 0 <__kernel_tan>
    1cdc:	ldr	d16, [x0]
    1ce0:	adrp	x0, 0 <__kernel_tan>
    1ce4:	fmul	d1, d2, d1
    1ce8:	ldr	d7, [x0]
    1cec:	adrp	x0, 0 <__kernel_tan>
    1cf0:	ldr	d6, [x0]
    1cf4:	adrp	x0, 0 <__kernel_tan>
    1cf8:	fadd	d1, d1, d16
    1cfc:	ldr	d4, [x0]
    1d00:	adrp	x0, 0 <__kernel_tan>
    1d04:	ldr	d0, [x0]
    1d08:	fmul	d1, d1, d2
    1d0c:	fsub	d1, d1, d7
    1d10:	fmul	d1, d1, d2
    1d14:	fadd	d1, d1, d6
    1d18:	fmul	d1, d1, d2
    1d1c:	fsub	d1, d1, d4
    1d20:	fmul	d1, d1, d2
    1d24:	fadd	d1, d1, d0
    1d28:	fmul	d1, d1, d2
    1d2c:	fmul	d1, d2, d1
    1d30:	fmul	d3, d3, d5
    1d34:	fmov	d4, #5.000000000000000000e-01
    1d38:	fmov	d0, #1.000000000000000000e+00
    1d3c:	fmul	d2, d2, d4
    1d40:	fsub	d1, d1, d3
    1d44:	fsub	d1, d2, d1
    1d48:	fsub	d0, d0, d1
    1d4c:	fneg	d0, d0
    1d50:	b	1830 <pts_ieee754_cos+0x4c>
    1d54:	fcvtzs	w0, d3
    1d58:	cbz	w0, 1cac <pts_ieee754_cos+0x4c8>
    1d5c:	adrp	x0, 0 <__kernel_tan>
    1d60:	fmul	d2, d3, d3
    1d64:	ldr	d1, [x0]
    1d68:	adrp	x0, 0 <__kernel_tan>
    1d6c:	ldr	d16, [x0]
    1d70:	adrp	x0, 0 <__kernel_tan>
    1d74:	fmul	d1, d2, d1
    1d78:	ldr	d7, [x0]
    1d7c:	adrp	x0, 0 <__kernel_tan>
    1d80:	ldr	d5, [x0]
    1d84:	adrp	x0, 0 <__kernel_tan>
    1d88:	fadd	d1, d1, d16
    1d8c:	ldr	d4, [x0]
    1d90:	adrp	x0, 0 <__kernel_tan>
    1d94:	ldr	d0, [x0]
    1d98:	fmul	d1, d1, d2
    1d9c:	fsub	d1, d1, d7
    1da0:	fmul	d1, d1, d2
    1da4:	fadd	d1, d1, d5
    1da8:	fmul	d1, d1, d2
    1dac:	fsub	d1, d1, d4
    1db0:	fmul	d1, d1, d2
    1db4:	fadd	d1, d1, d0
    1db8:	fmul	d1, d1, d2
    1dbc:	fmul	d1, d2, d1
    1dc0:	fmul	d3, d3, d6
    1dc4:	fmov	d4, #5.000000000000000000e-01
    1dc8:	fmov	d0, #1.000000000000000000e+00
    1dcc:	fmul	d2, d2, d4
    1dd0:	fsub	d1, d1, d3
    1dd4:	fsub	d1, d2, d1
    1dd8:	fsub	d0, d0, d1
    1ddc:	b	1830 <pts_ieee754_cos+0x4c>
    1de0:	fmov	d0, #7.187500000000000000e-01
    1de4:	fmov	d4, #2.812500000000000000e-01
    1de8:	b	1b40 <pts_ieee754_cos+0x35c>
    1dec:	fmov	d0, #7.187500000000000000e-01
    1df0:	fmov	d4, #2.812500000000000000e-01
    1df4:	b	1920 <pts_ieee754_cos+0x13c>
    1df8:	bl	0 <__stack_chk_fail>
    1dfc:	nop

0000000000001e00 <pts_ieee754_exp>:
    1e00:	fmov	x0, d0
    1e04:	mov	w3, #0x2e41                	// #11841
    1e08:	movk	w3, #0x4086, lsl #16
    1e0c:	ubfx	x1, x0, #32, #31
    1e10:	lsr	x2, x0, #32
    1e14:	lsr	x4, x0, #63
    1e18:	cmp	w1, w3
    1e1c:	b.ls	1e40 <pts_ieee754_exp+0x40>  // b.plast
    1e20:	mov	w3, #0x7fefffff            	// #2146435071
    1e24:	cmp	w1, w3
    1e28:	b.ls	1ee4 <pts_ieee754_exp+0xe4>  // b.plast
    1e2c:	and	w2, w2, #0xfffff
    1e30:	orr	w2, w2, w0
    1e34:	cbz	w2, 20a8 <pts_ieee754_exp+0x2a8>
    1e38:	fadd	d0, d0, d0
    1e3c:	ret
    1e40:	mov	w0, #0x2e42                	// #11842
    1e44:	movk	w0, #0x3fd6, lsl #16
    1e48:	cmp	w1, w0
    1e4c:	b.hi	2028 <pts_ieee754_exp+0x228>  // b.pmore
    1e50:	mov	w0, #0x3e2fffff            	// #1043333119
    1e54:	cmp	w1, w0
    1e58:	b.ls	2088 <pts_ieee754_exp+0x288>  // b.plast
    1e5c:	movi	d3, #0x0
    1e60:	fmul	d2, d0, d0
    1e64:	fmov	d5, #1.000000000000000000e+00
    1e68:	mov	w0, #0x0                   	// #0
    1e6c:	fmov	d4, d3
    1e70:	adrp	x1, 0 <__kernel_tan>
    1e74:	ldr	d1, [x1]
    1e78:	adrp	x1, 0 <__kernel_tan>
    1e7c:	ldr	d17, [x1]
    1e80:	adrp	x1, 0 <__kernel_tan>
    1e84:	fmul	d1, d2, d1
    1e88:	ldr	d16, [x1]
    1e8c:	adrp	x1, 0 <__kernel_tan>
    1e90:	ldr	d7, [x1]
    1e94:	adrp	x1, 0 <__kernel_tan>
    1e98:	fsub	d1, d1, d17
    1e9c:	ldr	d6, [x1]
    1ea0:	fmul	d1, d1, d2
    1ea4:	fadd	d1, d1, d16
    1ea8:	fmul	d1, d1, d2
    1eac:	fsub	d1, d1, d7
    1eb0:	fmul	d1, d1, d2
    1eb4:	fadd	d1, d1, d6
    1eb8:	fmul	d1, d1, d2
    1ebc:	fsub	d1, d0, d1
    1ec0:	cbnz	w0, 1ff8 <pts_ieee754_exp+0x1f8>
    1ec4:	fmov	d4, #2.000000000000000000e+00
    1ec8:	fmul	d2, d1, d0
    1ecc:	fmov	d3, #1.000000000000000000e+00
    1ed0:	fsub	d1, d1, d4
    1ed4:	fdiv	d1, d2, d1
    1ed8:	fsub	d0, d1, d0
    1edc:	fsub	d0, d3, d0
    1ee0:	ret
    1ee4:	adrp	x0, 0 <__kernel_tan>
    1ee8:	ldr	d1, [x0]
    1eec:	fcmpe	d0, d1
    1ef0:	b.gt	20b8 <pts_ieee754_exp+0x2b8>
    1ef4:	adrp	x0, 0 <__kernel_tan>
    1ef8:	ldr	d1, [x0]
    1efc:	fcmpe	d0, d1
    1f00:	b.mi	20f0 <pts_ieee754_exp+0x2f0>  // b.first
    1f04:	adrp	x1, 0 <__kernel_tan>
    1f08:	ubfiz	x4, x4, #3, #1
    1f0c:	adrp	x0, 0 <__kernel_tan>
    1f10:	add	x0, x0, #0x0
    1f14:	ldr	d2, [x1]
    1f18:	add	x0, x0, x4
    1f1c:	adrp	x1, 0 <__kernel_tan>
    1f20:	fmul	d2, d0, d2
    1f24:	ldr	d3, [x0, #560]
    1f28:	adrp	x0, 0 <__kernel_tan>
    1f2c:	ldr	d4, [x1]
    1f30:	adrp	x1, 0 <__kernel_tan>
    1f34:	ldr	d7, [x0]
    1f38:	adrp	x0, 0 <__kernel_tan>
    1f3c:	fadd	d2, d2, d3
    1f40:	ldr	d17, [x1]
    1f44:	ldr	d6, [x0]
    1f48:	adrp	x0, 0 <__kernel_tan>
    1f4c:	adrp	x1, 0 <__kernel_tan>
    1f50:	ldr	d5, [x0]
    1f54:	fcvtzs	w0, d2
    1f58:	ldr	d1, [x1]
    1f5c:	adrp	x1, 0 <__kernel_tan>
    1f60:	ldr	d16, [x1]
    1f64:	scvtf	d3, w0
    1f68:	fmul	d4, d3, d4
    1f6c:	fmul	d3, d3, d17
    1f70:	fsub	d4, d0, d4
    1f74:	fsub	d0, d4, d3
    1f78:	fmul	d2, d0, d0
    1f7c:	fmul	d1, d2, d1
    1f80:	fsub	d1, d1, d16
    1f84:	fmul	d1, d1, d2
    1f88:	fadd	d1, d1, d7
    1f8c:	fmul	d1, d1, d2
    1f90:	fsub	d1, d1, d6
    1f94:	fmul	d1, d1, d2
    1f98:	fadd	d1, d1, d5
    1f9c:	fmul	d1, d1, d2
    1fa0:	fsub	d1, d0, d1
    1fa4:	cmn	w0, #0x3fd
    1fa8:	b.ge	2114 <pts_ieee754_exp+0x314>  // b.tcont
    1fac:	fmov	d5, #2.000000000000000000e+00
    1fb0:	fmul	d2, d0, d1
    1fb4:	add	w0, w0, #0x3e8
    1fb8:	mov	w1, #0x3ff00000            	// #1072693248
    1fbc:	fsub	d5, d5, d1
    1fc0:	fmov	d0, #1.000000000000000000e+00
    1fc4:	add	w0, w1, w0, lsl #20
    1fc8:	fmov	d1, x0
    1fcc:	adrp	x1, 0 <__kernel_tan>
    1fd0:	add	x1, x1, #0x0
    1fd4:	shl	d1, d1, #32
    1fd8:	fdiv	d2, d2, d5
    1fdc:	ldr	d5, [x1, #24]
    1fe0:	fsub	d2, d3, d2
    1fe4:	fsub	d2, d2, d4
    1fe8:	fsub	d0, d0, d2
    1fec:	fmul	d0, d0, d1
    1ff0:	fmul	d0, d0, d5
    1ff4:	ret
    1ff8:	fmov	d6, #2.000000000000000000e+00
    1ffc:	fmul	d0, d1, d0
    2000:	fmov	d2, #1.000000000000000000e+00
    2004:	fsub	d1, d6, d1
    2008:	fdiv	d0, d0, d1
    200c:	fsub	d0, d3, d0
    2010:	fsub	d0, d0, d4
    2014:	fsub	d0, d2, d0
    2018:	cmp	w0, #0x400
    201c:	b.eq	20d0 <pts_ieee754_exp+0x2d0>  // b.none
    2020:	fmul	d0, d0, d5
    2024:	ret
    2028:	mov	w0, #0xa2b1                	// #41649
    202c:	movk	w0, #0x3ff0, lsl #16
    2030:	cmp	w1, w0
    2034:	b.hi	1f04 <pts_ieee754_exp+0x104>  // b.pmore
    2038:	fmov	d1, #1.000000000000000000e+00
    203c:	fcmp	d0, d1
    2040:	b.eq	2108 <pts_ieee754_exp+0x308>  // b.none
    2044:	adrp	x1, 0 <__kernel_tan>
    2048:	add	x1, x1, #0x0
    204c:	ubfiz	x0, x4, #3, #1
    2050:	add	x1, x1, #0x200
    2054:	add	x1, x1, x0
    2058:	eor	w0, w4, #0x1
    205c:	sub	w0, w0, w4
    2060:	mov	w2, #0x3ff00000            	// #1072693248
    2064:	ldr	d4, [x1, #16]
    2068:	add	w2, w2, w0, lsl #20
    206c:	ldr	d3, [x1, #32]
    2070:	fmov	d1, x2
    2074:	fsub	d4, d0, d4
    2078:	shl	d5, d1, #32
    207c:	fsub	d0, d4, d3
    2080:	fmul	d2, d0, d0
    2084:	b	1e70 <pts_ieee754_exp+0x70>
    2088:	adrp	x0, 0 <__kernel_tan>
    208c:	add	x0, x0, #0x0
    2090:	fmov	d2, #1.000000000000000000e+00
    2094:	ldr	d1, [x0, #16]
    2098:	fadd	d1, d1, d0
    209c:	fcmpe	d1, d2
    20a0:	b.gt	20e8 <pts_ieee754_exp+0x2e8>
    20a4:	b	1e5c <pts_ieee754_exp+0x5c>
    20a8:	movi	d1, #0x0
    20ac:	cmp	w4, #0x0
    20b0:	fcsel	d0, d0, d1, eq	// eq = none
    20b4:	ret
    20b8:	adrp	x0, 0 <__kernel_tan>
    20bc:	add	x0, x0, #0x0
    20c0:	ldr	d0, [x0, #16]
    20c4:	ldr	d1, [x0, #16]
    20c8:	fmul	d0, d0, d1
    20cc:	ret
    20d0:	adrp	x0, 0 <__kernel_tan>
    20d4:	add	x0, x0, #0x0
    20d8:	fadd	d1, d0, d0
    20dc:	ldr	d0, [x0, #32]
    20e0:	fmul	d0, d1, d0
    20e4:	ret
    20e8:	fadd	d0, d0, d2
    20ec:	ret
    20f0:	adrp	x0, 0 <__kernel_tan>
    20f4:	add	x0, x0, #0x0
    20f8:	ldr	d0, [x0, #24]
    20fc:	ldr	d1, [x0, #24]
    2100:	fmul	d0, d0, d1
    2104:	ret
    2108:	adrp	x0, 0 <__kernel_tan>
    210c:	ldr	d0, [x0]
    2110:	ret
    2114:	mov	w1, #0x3ff00000            	// #1072693248
    2118:	add	w1, w1, w0, lsl #20
    211c:	fmov	d1, x1
    2120:	shl	d5, d1, #32
    2124:	b	1e70 <pts_ieee754_exp+0x70>
    2128:	nop
    212c:	nop

0000000000002130 <pts_ieee754_log>:
    2130:	fmov	x2, d0
    2134:	mov	w3, #0xfffff               	// #1048575
    2138:	lsr	x0, x2, #32
    213c:	mov	w1, w0
    2140:	cmp	w0, w3
    2144:	b.gt	2200 <pts_ieee754_log+0xd0>
    2148:	and	w1, w0, #0x7fffffff
    214c:	orr	w1, w1, w2
    2150:	cbz	w1, 22e0 <pts_ieee754_log+0x1b0>
    2154:	tbnz	w0, #31, 2378 <pts_ieee754_log+0x248>
    2158:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    215c:	fmov	d1, x0
    2160:	mov	w6, #0xffffffca            	// #-54
    2164:	fmul	d0, d0, d1
    2168:	fmov	x0, d0
    216c:	lsr	x1, x0, #32
    2170:	mov	w0, #0x7fefffff            	// #2146435071
    2174:	cmp	w1, w0
    2178:	b.gt	2210 <pts_ieee754_log+0xe0>
    217c:	and	w4, w1, #0xfffff
    2180:	fmov	x0, d0
    2184:	add	w3, w4, #0x95, lsl #12
    2188:	asr	w1, w1, #20
    218c:	add	w3, w3, #0xf64
    2190:	sub	w1, w1, #0x3ff
    2194:	and	w2, w3, #0x100000
    2198:	add	w5, w4, #0x2
    219c:	eor	w2, w2, #0x3ff00000
    21a0:	and	x0, x0, #0xffffffff
    21a4:	orr	w2, w2, w4
    21a8:	fmov	d0, #1.000000000000000000e+00
    21ac:	add	w1, w1, w6
    21b0:	and	w5, w5, #0xfffff
    21b4:	orr	x0, x0, x2, lsl #32
    21b8:	fmov	d1, x0
    21bc:	add	w3, w1, w3, lsr #20
    21c0:	fsub	d0, d1, d0
    21c4:	cmp	w5, #0x2
    21c8:	b.gt	2218 <pts_ieee754_log+0xe8>
    21cc:	fcmp	d0, #0.0
    21d0:	b.ne	22ec <pts_ieee754_log+0x1bc>  // b.any
    21d4:	movi	d0, #0x0
    21d8:	cbz	w3, 21fc <pts_ieee754_log+0xcc>
    21dc:	adrp	x0, 0 <__kernel_tan>
    21e0:	scvtf	d1, w3
    21e4:	ldr	d0, [x0]
    21e8:	adrp	x0, 0 <__kernel_tan>
    21ec:	ldr	d2, [x0]
    21f0:	fmul	d0, d1, d0
    21f4:	fmul	d1, d1, d2
    21f8:	fadd	d0, d0, d1
    21fc:	ret
    2200:	mov	w6, #0x0                   	// #0
    2204:	mov	w0, #0x7fefffff            	// #2146435071
    2208:	cmp	w1, w0
    220c:	b.le	217c <pts_ieee754_log+0x4c>
    2210:	fadd	d0, d0, d0
    2214:	ret
    2218:	fmov	d3, #2.000000000000000000e+00
    221c:	adrp	x0, 0 <__kernel_tan>
    2220:	sub	w1, w4, #0x61, lsl #12
    2224:	scvtf	d6, w3
    2228:	fadd	d3, d0, d3
    222c:	ldr	d1, [x0]
    2230:	adrp	x0, 0 <__kernel_tan>
    2234:	sub	w1, w1, #0x47a
    2238:	ldr	d19, [x0]
    223c:	adrp	x0, 0 <__kernel_tan>
    2240:	fdiv	d3, d0, d3
    2244:	ldr	d2, [x0]
    2248:	adrp	x0, 0 <__kernel_tan>
    224c:	ldr	d17, [x0]
    2250:	adrp	x0, 0 <__kernel_tan>
    2254:	ldr	d18, [x0]
    2258:	adrp	x0, 0 <__kernel_tan>
    225c:	ldr	d7, [x0]
    2260:	adrp	x0, 0 <__kernel_tan>
    2264:	ldr	d16, [x0]
    2268:	mov	w0, #0xb851                	// #47185
    226c:	movk	w0, #0x6, lsl #16
    2270:	sub	w0, w0, w4
    2274:	orr	w0, w0, w1
    2278:	fmul	d5, d3, d3
    227c:	fmul	d4, d5, d5
    2280:	fmul	d1, d4, d1
    2284:	fmul	d2, d4, d2
    2288:	fadd	d1, d1, d19
    228c:	fadd	d2, d2, d18
    2290:	fmul	d1, d1, d4
    2294:	fmul	d2, d2, d4
    2298:	fadd	d1, d1, d17
    229c:	fadd	d2, d2, d16
    22a0:	fmul	d1, d1, d4
    22a4:	fmul	d2, d2, d4
    22a8:	fadd	d1, d1, d7
    22ac:	fmul	d1, d1, d5
    22b0:	fadd	d1, d1, d2
    22b4:	cmp	w0, #0x0
    22b8:	b.le	233c <pts_ieee754_log+0x20c>
    22bc:	fmov	d2, #5.000000000000000000e-01
    22c0:	fmul	d2, d0, d2
    22c4:	fmul	d2, d2, d0
    22c8:	fadd	d1, d1, d2
    22cc:	fmul	d1, d1, d3
    22d0:	cbnz	w3, 2384 <pts_ieee754_log+0x254>
    22d4:	fsub	d2, d2, d1
    22d8:	fsub	d0, d0, d2
    22dc:	ret
    22e0:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    22e4:	fmov	d0, x0
    22e8:	ret
    22ec:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    22f0:	fmov	d1, #5.000000000000000000e-01
    22f4:	movk	x0, #0x3fd5, lsl #48
    22f8:	fmov	d2, x0
    22fc:	fmul	d3, d0, d0
    2300:	fmul	d2, d0, d2
    2304:	fsub	d1, d1, d2
    2308:	fmul	d1, d1, d3
    230c:	cbz	w3, 2370 <pts_ieee754_log+0x240>
    2310:	adrp	x0, 0 <__kernel_tan>
    2314:	scvtf	d2, w3
    2318:	ldr	d3, [x0]
    231c:	adrp	x0, 0 <__kernel_tan>
    2320:	ldr	d4, [x0]
    2324:	fmul	d3, d2, d3
    2328:	fmul	d2, d2, d4
    232c:	fsub	d1, d1, d3
    2330:	fsub	d1, d1, d0
    2334:	fsub	d0, d2, d1
    2338:	ret
    233c:	fsub	d1, d0, d1
    2340:	fmul	d1, d1, d3
    2344:	cbz	w3, 2370 <pts_ieee754_log+0x240>
    2348:	adrp	x0, 0 <__kernel_tan>
    234c:	ldr	d2, [x0]
    2350:	adrp	x0, 0 <__kernel_tan>
    2354:	ldr	d3, [x0]
    2358:	fmul	d2, d6, d2
    235c:	fmul	d6, d6, d3
    2360:	fsub	d1, d1, d2
    2364:	fsub	d1, d1, d0
    2368:	fsub	d0, d6, d1
    236c:	ret
    2370:	fsub	d0, d0, d1
    2374:	ret
    2378:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    237c:	fmov	d0, x0
    2380:	ret
    2384:	adrp	x0, 0 <__kernel_tan>
    2388:	ldr	d3, [x0]
    238c:	adrp	x0, 0 <__kernel_tan>
    2390:	ldr	d4, [x0]
    2394:	fmul	d3, d6, d3
    2398:	fmul	d4, d6, d4
    239c:	fadd	d1, d3, d1
    23a0:	fsub	d2, d2, d1
    23a4:	fsub	d2, d2, d0
    23a8:	fsub	d0, d4, d2
    23ac:	ret

00000000000023b0 <pts_ieee754_log1p>:
    23b0:	fmov	x1, d0
    23b4:	mov	w3, #0x8279                	// #33401
    23b8:	fmov	d1, d0
    23bc:	movk	w3, #0x3fda, lsl #16
    23c0:	lsr	x0, x1, #32
    23c4:	mov	w2, w0
    23c8:	cmp	w0, w3
    23cc:	b.gt	2400 <pts_ieee754_log1p+0x50>
    23d0:	and	w1, w0, #0x7fffffff
    23d4:	mov	w2, #0x3fefffff            	// #1072693247
    23d8:	cmp	w1, w2
    23dc:	b.le	2498 <pts_ieee754_log1p+0xe8>
    23e0:	fmov	d2, #-1.000000000000000000e+00
    23e4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    23e8:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    23ec:	fmov	d0, x0
    23f0:	fcmp	d1, d2
    23f4:	fmov	d1, x1
    23f8:	fcsel	d0, d0, d1, ne	// ne = any
    23fc:	ret
    2400:	mov	w3, #0x7fefffff            	// #2146435071
    2404:	cmp	w0, w3
    2408:	b.gt	255c <pts_ieee754_log1p+0x1ac>
    240c:	mov	w3, #0x433fffff            	// #1128267775
    2410:	cmp	w0, w3
    2414:	b.le	2634 <pts_ieee754_log1p+0x284>
    2418:	asr	w0, w0, #20
    241c:	movi	d4, #0x0
    2420:	sub	w0, w0, #0x3ff
    2424:	mov	w3, #0xa09d                	// #41117
    2428:	and	w2, w2, #0xfffff
    242c:	and	x1, x1, #0xffffffff
    2430:	movk	w3, #0x6, lsl #16
    2434:	cmp	w2, w3
    2438:	b.gt	2614 <pts_ieee754_log1p+0x264>
    243c:	orr	w3, w2, #0x3ff00000
    2440:	orr	x1, x1, x3, lsl #32
    2444:	fmov	d0, x1
    2448:	fmov	d2, #1.000000000000000000e+00
    244c:	fmov	d3, #5.000000000000000000e-01
    2450:	fsub	d1, d0, d2
    2454:	fmul	d3, d1, d3
    2458:	fmul	d3, d3, d1
    245c:	cbnz	w2, 24c8 <pts_ieee754_log1p+0x118>
    2460:	fcmp	d1, #0.0
    2464:	b.ne	2594 <pts_ieee754_log1p+0x1e4>  // b.any
    2468:	movi	d0, #0x0
    246c:	cbz	w0, 23fc <pts_ieee754_log1p+0x4c>
    2470:	scvtf	d1, w0
    2474:	adrp	x0, 0 <__kernel_tan>
    2478:	ldr	d0, [x0]
    247c:	adrp	x0, 0 <__kernel_tan>
    2480:	ldr	d2, [x0]
    2484:	fmul	d0, d1, d0
    2488:	fmul	d1, d1, d2
    248c:	fadd	d0, d0, d4
    2490:	fadd	d0, d0, d1
    2494:	ret
    2498:	mov	w2, #0x3e1fffff            	// #1042284543
    249c:	cmp	w1, w2
    24a0:	b.le	2564 <pts_ieee754_log1p+0x1b4>
    24a4:	mov	w1, #0x413b                	// #16699
    24a8:	movk	w1, #0x402d, lsl #16
    24ac:	add	w0, w0, w1
    24b0:	cmp	w0, w1
    24b4:	b.ls	2634 <pts_ieee754_log1p+0x284>  // b.plast
    24b8:	fmov	d3, #5.000000000000000000e-01
    24bc:	mov	w0, #0x0                   	// #0
    24c0:	fmul	d3, d0, d3
    24c4:	fmul	d3, d3, d0
    24c8:	fmov	d0, #2.000000000000000000e+00
    24cc:	adrp	x1, 0 <__kernel_tan>
    24d0:	fadd	d0, d1, d0
    24d4:	ldr	d2, [x1]
    24d8:	adrp	x1, 0 <__kernel_tan>
    24dc:	ldr	d19, [x1]
    24e0:	adrp	x1, 0 <__kernel_tan>
    24e4:	fdiv	d0, d1, d0
    24e8:	ldr	d18, [x1]
    24ec:	adrp	x1, 0 <__kernel_tan>
    24f0:	ldr	d17, [x1]
    24f4:	adrp	x1, 0 <__kernel_tan>
    24f8:	ldr	d16, [x1]
    24fc:	adrp	x1, 0 <__kernel_tan>
    2500:	ldr	d7, [x1]
    2504:	adrp	x1, 0 <__kernel_tan>
    2508:	ldr	d6, [x1]
    250c:	fmul	d5, d0, d0
    2510:	fmul	d2, d5, d2
    2514:	fadd	d2, d2, d19
    2518:	fmul	d2, d2, d5
    251c:	fadd	d2, d2, d18
    2520:	fmul	d2, d2, d5
    2524:	fadd	d2, d2, d17
    2528:	fmul	d2, d2, d5
    252c:	fadd	d2, d2, d16
    2530:	fmul	d2, d2, d5
    2534:	fadd	d2, d2, d7
    2538:	fmul	d2, d2, d5
    253c:	fadd	d2, d2, d6
    2540:	fmul	d2, d2, d5
    2544:	fadd	d2, d2, d3
    2548:	fmul	d2, d2, d0
    254c:	cbnz	w0, 25e0 <pts_ieee754_log1p+0x230>
    2550:	fsub	d2, d3, d2
    2554:	fsub	d0, d1, d2
    2558:	ret
    255c:	fadd	d0, d0, d0
    2560:	ret
    2564:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2568:	fmov	d2, x0
    256c:	mov	w0, #0x3c8fffff            	// #1016070143
    2570:	fadd	d1, d0, d2
    2574:	fcmpe	d1, #0.0
    2578:	ccmp	w1, w0, #0x0, gt
    257c:	b.le	23fc <pts_ieee754_log1p+0x4c>
    2580:	fmul	d1, d0, d0
    2584:	fmov	d2, #5.000000000000000000e-01
    2588:	fmul	d1, d1, d2
    258c:	fsub	d0, d0, d1
    2590:	ret
    2594:	mov	x1, #0x5555555555555555    	// #6148914691236517205
    2598:	movk	x1, #0x3fe5, lsl #48
    259c:	fmov	d0, x1
    25a0:	fmul	d0, d1, d0
    25a4:	fsub	d2, d2, d0
    25a8:	fmul	d2, d2, d3
    25ac:	cbz	w0, 2554 <pts_ieee754_log1p+0x1a4>
    25b0:	scvtf	d0, w0
    25b4:	adrp	x0, 0 <__kernel_tan>
    25b8:	ldr	d3, [x0]
    25bc:	adrp	x0, 0 <__kernel_tan>
    25c0:	ldr	d5, [x0]
    25c4:	fmul	d3, d0, d3
    25c8:	fmul	d0, d0, d5
    25cc:	fadd	d3, d3, d4
    25d0:	fsub	d2, d2, d3
    25d4:	fsub	d2, d2, d1
    25d8:	fsub	d0, d0, d2
    25dc:	ret
    25e0:	scvtf	d0, w0
    25e4:	adrp	x0, 0 <__kernel_tan>
    25e8:	ldr	d5, [x0]
    25ec:	adrp	x0, 0 <__kernel_tan>
    25f0:	ldr	d6, [x0]
    25f4:	fmul	d5, d0, d5
    25f8:	fmul	d0, d0, d6
    25fc:	fadd	d4, d5, d4
    2600:	fadd	d2, d4, d2
    2604:	fsub	d2, d3, d2
    2608:	fsub	d1, d2, d1
    260c:	fsub	d0, d0, d1
    2610:	ret
    2614:	orr	w3, w2, #0x3fe00000
    2618:	mov	w4, #0x100000              	// #1048576
    261c:	sub	w2, w4, w2
    2620:	add	w0, w0, #0x1
    2624:	orr	x1, x1, x3, lsl #32
    2628:	fmov	d0, x1
    262c:	asr	w2, w2, #2
    2630:	b	2448 <pts_ieee754_log1p+0x98>
    2634:	fmov	d4, #1.000000000000000000e+00
    2638:	fadd	d0, d1, d4
    263c:	fmov	x1, d0
    2640:	lsr	x0, x1, #32
    2644:	mov	w2, w0
    2648:	asr	w0, w0, #20
    264c:	sub	w0, w0, #0x3ff
    2650:	cmp	w0, #0x0
    2654:	b.le	2668 <pts_ieee754_log1p+0x2b8>
    2658:	fsub	d1, d0, d1
    265c:	fsub	d4, d4, d1
    2660:	fdiv	d4, d4, d0
    2664:	b	2424 <pts_ieee754_log1p+0x74>
    2668:	fsub	d4, d0, d4
    266c:	fsub	d4, d1, d4
    2670:	fdiv	d4, d4, d0
    2674:	b	2424 <pts_ieee754_log1p+0x74>
    2678:	nop
    267c:	nop

0000000000002680 <pts_ieee754_acosh>:
    2680:	fmov	x2, d0
    2684:	mov	w1, #0x3fefffff            	// #1072693247
    2688:	lsr	x0, x2, #32
    268c:	cmp	w0, w1
    2690:	b.le	2718 <pts_ieee754_acosh+0x98>
    2694:	stp	x29, x30, [sp, #-32]!
    2698:	mov	w3, #0x41afffff            	// #1102053375
    269c:	mov	x29, sp
    26a0:	stp	d8, d9, [sp, #16]
    26a4:	fmov	d8, d0
    26a8:	cmp	w0, w3
    26ac:	b.gt	26f0 <pts_ieee754_acosh+0x70>
    26b0:	mov	w3, #0xc0100000            	// #-1072693248
    26b4:	add	w3, w3, w0
    26b8:	orr	w2, w3, w2
    26bc:	cbz	w2, 278c <pts_ieee754_acosh+0x10c>
    26c0:	add	w1, w1, #0x100, lsl #12
    26c4:	add	w1, w1, #0x1
    26c8:	cmp	w0, w1
    26cc:	b.le	2734 <pts_ieee754_acosh+0xb4>
    26d0:	fmul	d0, d0, d0
    26d4:	fmov	d1, #1.000000000000000000e+00
    26d8:	fadd	d9, d8, d8
    26dc:	fsub	d0, d0, d1
    26e0:	fcmp	d0, #0.0
    26e4:	b.pl	2758 <pts_ieee754_acosh+0xd8>  // b.nfrst
    26e8:	bl	0 <sqrt>
    26ec:	b	275c <pts_ieee754_acosh+0xdc>
    26f0:	mov	w1, #0x7fefffff            	// #2146435071
    26f4:	cmp	w0, w1
    26f8:	b.gt	2724 <pts_ieee754_acosh+0xa4>
    26fc:	bl	2130 <pts_ieee754_log>
    2700:	adrp	x0, 0 <__kernel_tan>
    2704:	ldp	d8, d9, [sp, #16]
    2708:	ldr	d1, [x0]
    270c:	ldp	x29, x30, [sp], #32
    2710:	fadd	d0, d0, d1
    2714:	ret
    2718:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    271c:	fmov	d0, x0
    2720:	ret
    2724:	ldp	d8, d9, [sp, #16]
    2728:	fadd	d0, d0, d0
    272c:	ldp	x29, x30, [sp], #32
    2730:	ret
    2734:	fmov	d0, #1.000000000000000000e+00
    2738:	fsub	d8, d8, d0
    273c:	fadd	d0, d8, d8
    2740:	fmul	d1, d8, d8
    2744:	fadd	d0, d0, d1
    2748:	fcmp	d0, #0.0
    274c:	b.pl	2778 <pts_ieee754_acosh+0xf8>  // b.nfrst
    2750:	bl	0 <sqrt>
    2754:	b	277c <pts_ieee754_acosh+0xfc>
    2758:	fsqrt	d0, d0
    275c:	fadd	d8, d8, d0
    2760:	fmov	d0, #1.000000000000000000e+00
    2764:	fdiv	d0, d0, d8
    2768:	fsub	d0, d9, d0
    276c:	ldp	d8, d9, [sp, #16]
    2770:	ldp	x29, x30, [sp], #32
    2774:	b	2130 <pts_ieee754_log>
    2778:	fsqrt	d0, d0
    277c:	fadd	d0, d8, d0
    2780:	ldp	d8, d9, [sp, #16]
    2784:	ldp	x29, x30, [sp], #32
    2788:	b	23b0 <pts_ieee754_log1p>
    278c:	ldp	d8, d9, [sp, #16]
    2790:	movi	d0, #0x0
    2794:	ldp	x29, x30, [sp], #32
    2798:	ret
    279c:	nop

00000000000027a0 <pts_ieee754_asinh>:
    27a0:	fmov	x0, d0
    27a4:	fmov	d1, d0
    27a8:	mov	w1, #0x7fefffff            	// #2146435071
    27ac:	lsr	x7, x0, #32
    27b0:	and	w0, w7, #0x7fffffff
    27b4:	cmp	w0, w1
    27b8:	b.gt	2844 <pts_ieee754_asinh+0xa4>
    27bc:	stp	x29, x30, [sp, #-16]!
    27c0:	mov	w1, #0x3e2fffff            	// #1043333119
    27c4:	mov	x29, sp
    27c8:	cmp	w0, w1
    27cc:	b.le	2804 <pts_ieee754_asinh+0x64>
    27d0:	fabs	d0, d0
    27d4:	mov	w1, #0x41b00000            	// #1102053376
    27d8:	cmp	w0, w1
    27dc:	b.le	284c <pts_ieee754_asinh+0xac>
    27e0:	bl	2130 <pts_ieee754_log>
    27e4:	adrp	x0, 0 <__kernel_tan>
    27e8:	ldr	d1, [x0]
    27ec:	fadd	d0, d0, d1
    27f0:	fneg	d1, d0
    27f4:	cmp	w7, #0x0
    27f8:	fcsel	d0, d1, d0, le
    27fc:	ldp	x29, x30, [sp], #16
    2800:	ret
    2804:	adrp	x0, 0 <__kernel_tan>
    2808:	fmov	d2, #1.000000000000000000e+00
    280c:	ldr	d3, [x0]
    2810:	fadd	d3, d0, d3
    2814:	fcmpe	d3, d2
    2818:	b.gt	27fc <pts_ieee754_asinh+0x5c>
    281c:	fmul	d3, d0, d0
    2820:	fabs	d0, d0
    2824:	fadd	d2, d3, d2
    2828:	fsqrt	d2, d2
    282c:	fmov	d1, #1.000000000000000000e+00
    2830:	fadd	d2, d2, d1
    2834:	fdiv	d3, d3, d2
    2838:	fadd	d0, d3, d0
    283c:	bl	23b0 <pts_ieee754_log1p>
    2840:	b	27f0 <pts_ieee754_asinh+0x50>
    2844:	fadd	d0, d0, d0
    2848:	ret
    284c:	fmul	d3, d1, d1
    2850:	fmov	d1, #1.000000000000000000e+00
    2854:	mov	w1, #0x40000000            	// #1073741824
    2858:	fadd	d2, d3, d1
    285c:	fsqrt	d2, d2
    2860:	cmp	w0, w1
    2864:	b.le	282c <pts_ieee754_asinh+0x8c>
    2868:	fadd	d2, d0, d2
    286c:	fadd	d0, d0, d0
    2870:	fdiv	d1, d1, d2
    2874:	fadd	d0, d1, d0
    2878:	bl	2130 <pts_ieee754_log>
    287c:	b	27f0 <pts_ieee754_asinh+0x50>

0000000000002880 <pts_ieee754_atanh>:
    2880:	fmov	x0, d0
    2884:	mov	w3, #0x3ff00000            	// #1072693248
    2888:	neg	w1, w0
    288c:	ubfx	x2, x0, #32, #31
    2890:	orr	w1, w1, w0
    2894:	orr	w1, w2, w1, lsr #31
    2898:	cmp	w1, w3
    289c:	b.hi	2948 <pts_ieee754_atanh+0xc8>  // b.pmore
    28a0:	cmp	w2, w3
    28a4:	b.eq	2954 <pts_ieee754_atanh+0xd4>  // b.none
    28a8:	stp	x29, x30, [sp, #-16]!
    28ac:	lsr	x5, x0, #32
    28b0:	mov	w1, #0x3e2fffff            	// #1043333119
    28b4:	mov	x29, sp
    28b8:	cmp	w2, w1
    28bc:	b.le	2904 <pts_ieee754_atanh+0x84>
    28c0:	bfi	x0, x2, #32, #32
    28c4:	fmov	d0, #1.000000000000000000e+00
    28c8:	fmov	d1, x0
    28cc:	mov	w0, #0x3fdfffff            	// #1071644671
    28d0:	fadd	d2, d1, d1
    28d4:	fsub	d0, d0, d1
    28d8:	cmp	w2, w0
    28dc:	b.le	2924 <pts_ieee754_atanh+0xa4>
    28e0:	fdiv	d0, d2, d0
    28e4:	bl	23b0 <pts_ieee754_log1p>
    28e8:	fmov	d1, #5.000000000000000000e-01
    28ec:	fmul	d0, d0, d1
    28f0:	fneg	d1, d0
    28f4:	cmp	w5, #0x0
    28f8:	fcsel	d0, d1, d0, lt	// lt = tstop
    28fc:	ldp	x29, x30, [sp], #16
    2900:	ret
    2904:	adrp	x1, 0 <__kernel_tan>
    2908:	ldr	d2, [x1]
    290c:	fadd	d1, d0, d2
    2910:	fcmpe	d1, #0.0
    2914:	b.gt	28fc <pts_ieee754_atanh+0x7c>
    2918:	bfi	x0, x2, #32, #32
    291c:	fmov	d1, x0
    2920:	fadd	d2, d1, d1
    2924:	fmov	d3, #1.000000000000000000e+00
    2928:	fmul	d0, d2, d1
    292c:	fsub	d1, d3, d1
    2930:	fdiv	d0, d0, d1
    2934:	fadd	d0, d0, d2
    2938:	bl	23b0 <pts_ieee754_log1p>
    293c:	fmov	d1, #5.000000000000000000e-01
    2940:	fmul	d0, d0, d1
    2944:	b	28f0 <pts_ieee754_atanh+0x70>
    2948:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    294c:	fmov	d0, x0
    2950:	ret
    2954:	fcmpe	d0, #0.0
    2958:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
    295c:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    2960:	fmov	d0, x0
    2964:	fmov	d1, x1
    2968:	fcsel	d0, d0, d1, gt
    296c:	ret

0000000000002970 <pts_ieee754_log2>:
    2970:	fmov	x1, d0
    2974:	fmov	d1, d0
    2978:	mov	w3, #0xfffff               	// #1048575
    297c:	lsr	x0, x1, #32
    2980:	mov	w2, w0
    2984:	cmp	w0, w3
    2988:	b.gt	2b00 <pts_ieee754_log2+0x190>
    298c:	and	w2, w0, #0x7fffffff
    2990:	orr	w2, w2, w1
    2994:	cbz	w2, 2b18 <pts_ieee754_log2+0x1a8>
    2998:	tbnz	w0, #31, 2b24 <pts_ieee754_log2+0x1b4>
    299c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    29a0:	fmov	d0, x0
    29a4:	mov	w4, #0xffffffca            	// #-54
    29a8:	fmul	d1, d1, d0
    29ac:	fmov	x0, d1
    29b0:	lsr	x2, x0, #32
    29b4:	mov	w0, #0x7fefffff            	// #2146435071
    29b8:	cmp	w2, w0
    29bc:	b.gt	2b10 <pts_ieee754_log2+0x1a0>
    29c0:	cmp	w1, #0x0
    29c4:	mov	w0, #0x3ff00000            	// #1072693248
    29c8:	movi	d0, #0x0
    29cc:	ccmp	w2, w0, #0x0, eq	// eq = none
    29d0:	b.eq	2afc <pts_ieee754_log2+0x18c>  // b.none
    29d4:	and	w5, w2, #0xfffff
    29d8:	fmov	x0, d1
    29dc:	add	w3, w5, #0x95, lsl #12
    29e0:	fmov	d0, #1.000000000000000000e+00
    29e4:	add	w3, w3, #0xf64
    29e8:	fmov	d7, #2.000000000000000000e+00
    29ec:	and	w1, w3, #0x100000
    29f0:	fmov	d4, #5.000000000000000000e-01
    29f4:	eor	w1, w1, #0x3ff00000
    29f8:	and	x0, x0, #0xffffffff
    29fc:	orr	w1, w1, w5
    2a00:	movi	v6.2d, #0xffffffff00000000
    2a04:	asr	w2, w2, #20
    2a08:	adrp	x6, 0 <__kernel_tan>
    2a0c:	orr	x0, x0, x1, lsl #32
    2a10:	fmov	d2, x0
    2a14:	adrp	x0, 0 <__kernel_tan>
    2a18:	sub	w2, w2, #0x3ff
    2a1c:	fsub	d0, d2, d0
    2a20:	add	w2, w2, w4
    2a24:	ldr	d18, [x0]
    2a28:	add	w3, w2, w3, lsr #20
    2a2c:	ldr	d1, [x6]
    2a30:	adrp	x5, 0 <__kernel_tan>
    2a34:	scvtf	d5, w3
    2a38:	adrp	x1, 0 <__kernel_tan>
    2a3c:	fadd	d7, d0, d7
    2a40:	fmul	d4, d0, d4
    2a44:	ldr	d24, [x5]
    2a48:	adrp	x5, 0 <__kernel_tan>
    2a4c:	ldr	d23, [x1]
    2a50:	adrp	x1, 0 <__kernel_tan>
    2a54:	ldr	d3, [x5]
    2a58:	adrp	x5, 0 <__kernel_tan>
    2a5c:	fdiv	d7, d0, d7
    2a60:	fmul	d4, d4, d0
    2a64:	ldr	d22, [x5]
    2a68:	adrp	x0, 0 <__kernel_tan>
    2a6c:	ldr	d20, [x1]
    2a70:	adrp	x1, 0 <__kernel_tan>
    2a74:	ldr	d17, [x0]
    2a78:	fsub	d2, d0, d4
    2a7c:	ldr	d21, [x1]
    2a80:	and	v6.8b, v2.8b, v6.8b
    2a84:	fmul	d19, d6, d18
    2a88:	fsub	d0, d0, d6
    2a8c:	fadd	d16, d5, d19
    2a90:	fsub	d2, d0, d4
    2a94:	fsub	d0, d5, d16
    2a98:	fadd	d0, d0, d19
    2a9c:	fmul	d19, d7, d7
    2aa0:	fmul	d5, d19, d19
    2aa4:	fmul	d1, d5, d1
    2aa8:	fmul	d3, d5, d3
    2aac:	fadd	d1, d1, d24
    2ab0:	fadd	d3, d3, d23
    2ab4:	fmul	d1, d1, d5
    2ab8:	fmul	d3, d3, d5
    2abc:	fadd	d1, d1, d22
    2ac0:	fadd	d3, d3, d21
    2ac4:	fmul	d1, d1, d5
    2ac8:	fmul	d3, d3, d5
    2acc:	fadd	d1, d1, d20
    2ad0:	fmul	d1, d1, d19
    2ad4:	fadd	d1, d1, d3
    2ad8:	fadd	d1, d1, d4
    2adc:	fmul	d1, d1, d7
    2ae0:	fadd	d1, d1, d2
    2ae4:	fadd	d2, d6, d1
    2ae8:	fmul	d1, d1, d18
    2aec:	fmul	d2, d2, d17
    2af0:	fadd	d1, d2, d1
    2af4:	fadd	d0, d0, d1
    2af8:	fadd	d0, d0, d16
    2afc:	ret
    2b00:	mov	w4, #0x0                   	// #0
    2b04:	mov	w0, #0x7fefffff            	// #2146435071
    2b08:	cmp	w2, w0
    2b0c:	b.le	29c0 <pts_ieee754_log2+0x50>
    2b10:	fadd	d0, d1, d1
    2b14:	ret
    2b18:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2b1c:	fmov	d0, x0
    2b20:	ret
    2b24:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2b28:	fmov	d0, x0
    2b2c:	ret

0000000000002b30 <pts_ieee754_log10>:
    2b30:	fmov	x2, d0
    2b34:	mov	w4, #0xfffff               	// #1048575
    2b38:	lsr	x1, x2, #32
    2b3c:	cmp	w1, w4
    2b40:	b.gt	2bfc <pts_ieee754_log10+0xcc>
    2b44:	and	w0, w1, #0x7fffffff
    2b48:	orr	w0, w0, w2
    2b4c:	cbz	w0, 2c20 <pts_ieee754_log10+0xf0>
    2b50:	tbnz	w1, #31, 2c2c <pts_ieee754_log10+0xfc>
    2b54:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2b58:	fmov	d1, x0
    2b5c:	mov	w4, #0xffffffca            	// #-54
    2b60:	mov	w1, #0x7fefffff            	// #2146435071
    2b64:	fmul	d0, d0, d1
    2b68:	fmov	x0, d0
    2b6c:	mov	w3, w0
    2b70:	lsr	x0, x0, #32
    2b74:	cmp	w0, w1
    2b78:	b.gt	2c14 <pts_ieee754_log10+0xe4>
    2b7c:	cmp	w3, #0x0
    2b80:	mov	w1, #0x3ff00000            	// #1072693248
    2b84:	movi	d0, #0x0
    2b88:	ccmp	w0, w1, #0x0, eq	// eq = none
    2b8c:	b.eq	2c1c <pts_ieee754_log10+0xec>  // b.none
    2b90:	asr	w1, w0, #20
    2b94:	mov	w2, #0x3ff                 	// #1023
    2b98:	sub	w1, w1, #0x3ff
    2b9c:	stp	x29, x30, [sp, #-16]!
    2ba0:	add	w1, w1, w4
    2ba4:	adrp	x5, 0 <__kernel_tan>
    2ba8:	mov	x29, sp
    2bac:	lsr	w4, w1, #31
    2bb0:	sub	w2, w2, w4
    2bb4:	add	w1, w1, w4
    2bb8:	ldr	d21, [x5]
    2bbc:	bfi	w0, w2, #20, #12
    2bc0:	scvtf	d20, w1
    2bc4:	orr	x0, x3, x0, lsl #32
    2bc8:	fmov	d0, x0
    2bcc:	fmul	d21, d20, d21
    2bd0:	bl	2130 <pts_ieee754_log>
    2bd4:	adrp	x0, 0 <__kernel_tan>
    2bd8:	ldp	x29, x30, [sp], #16
    2bdc:	ldr	d1, [x0]
    2be0:	adrp	x0, 0 <__kernel_tan>
    2be4:	ldr	d2, [x0]
    2be8:	fmul	d0, d0, d1
    2bec:	fmul	d20, d20, d2
    2bf0:	fadd	d0, d0, d21
    2bf4:	fadd	d0, d0, d20
    2bf8:	ret
    2bfc:	mov	w0, w1
    2c00:	mov	w3, w2
    2c04:	mov	w4, #0x0                   	// #0
    2c08:	mov	w1, #0x7fefffff            	// #2146435071
    2c0c:	cmp	w0, w1
    2c10:	b.le	2b7c <pts_ieee754_log10+0x4c>
    2c14:	fadd	d0, d0, d0
    2c18:	ret
    2c1c:	ret
    2c20:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2c24:	fmov	d0, x0
    2c28:	ret
    2c2c:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2c30:	fmov	d0, x0
    2c34:	ret
    2c38:	nop
    2c3c:	nop

0000000000002c40 <pts_ieee754_expm1>:
    2c40:	fmov	x1, d0
    2c44:	mov	w2, #0x6879                	// #26745
    2c48:	fmov	d2, d0
    2c4c:	movk	w2, #0x4043, lsl #16
    2c50:	ubfx	x0, x1, #32, #31
    2c54:	lsr	x3, x1, #32
    2c58:	cmp	w0, w2
    2c5c:	b.ls	2cec <pts_ieee754_expm1+0xac>  // b.plast
    2c60:	mov	w2, #0x2e41                	// #11841
    2c64:	movk	w2, #0x4086, lsl #16
    2c68:	cmp	w0, w2
    2c6c:	b.ls	2ca0 <pts_ieee754_expm1+0x60>  // b.plast
    2c70:	mov	w2, #0x7fefffff            	// #2146435071
    2c74:	cmp	w0, w2
    2c78:	b.ls	2c90 <pts_ieee754_expm1+0x50>  // b.plast
    2c7c:	and	w0, w3, #0xfffff
    2c80:	orr	w0, w0, w1
    2c84:	cbz	w0, 2f34 <pts_ieee754_expm1+0x2f4>
    2c88:	fadd	d0, d0, d0
    2c8c:	ret
    2c90:	adrp	x0, 0 <__kernel_tan>
    2c94:	ldr	d0, [x0]
    2c98:	fcmpe	d2, d0
    2c9c:	b.gt	2f58 <pts_ieee754_expm1+0x318>
    2ca0:	tbnz	w3, #31, 2e0c <pts_ieee754_expm1+0x1cc>
    2ca4:	adrp	x0, 0 <__kernel_tan>
    2ca8:	fmov	d0, #5.000000000000000000e-01
    2cac:	ldr	d1, [x0]
    2cb0:	fmul	d1, d2, d1
    2cb4:	fadd	d0, d0, d1
    2cb8:	adrp	x0, 0 <__kernel_tan>
    2cbc:	ldr	d3, [x0]
    2cc0:	adrp	x0, 0 <__kernel_tan>
    2cc4:	fcvtzs	w1, d0
    2cc8:	ldr	d1, [x0]
    2ccc:	scvtf	d0, w1
    2cd0:	fmul	d3, d0, d3
    2cd4:	fmul	d0, d0, d1
    2cd8:	fsub	d3, d2, d3
    2cdc:	fsub	d2, d3, d0
    2ce0:	fsub	d3, d3, d2
    2ce4:	fsub	d3, d3, d0
    2ce8:	b	2d0c <pts_ieee754_expm1+0xcc>
    2cec:	mov	w1, #0x2e42                	// #11842
    2cf0:	movk	w1, #0x3fd6, lsl #16
    2cf4:	cmp	w0, w1
    2cf8:	b.hi	2e58 <pts_ieee754_expm1+0x218>  // b.pmore
    2cfc:	mov	w2, #0x3c8fffff            	// #1016070143
    2d00:	mov	w1, #0x0                   	// #0
    2d04:	cmp	w0, w2
    2d08:	b.ls	2e88 <pts_ieee754_expm1+0x248>  // b.plast
    2d0c:	fmov	d16, #5.000000000000000000e-01
    2d10:	adrp	x0, 0 <__kernel_tan>
    2d14:	fmov	d6, #1.000000000000000000e+00
    2d18:	fmov	d4, #3.000000000000000000e+00
    2d1c:	fmul	d5, d2, d16
    2d20:	ldr	d1, [x0]
    2d24:	adrp	x0, 0 <__kernel_tan>
    2d28:	fmov	d7, #6.000000000000000000e+00
    2d2c:	ldr	d20, [x0]
    2d30:	adrp	x0, 0 <__kernel_tan>
    2d34:	fmul	d0, d2, d5
    2d38:	ldr	d19, [x0]
    2d3c:	adrp	x0, 0 <__kernel_tan>
    2d40:	ldr	d18, [x0]
    2d44:	adrp	x0, 0 <__kernel_tan>
    2d48:	fmul	d1, d0, d1
    2d4c:	ldr	d17, [x0]
    2d50:	fadd	d1, d1, d20
    2d54:	fmul	d1, d1, d0
    2d58:	fsub	d1, d1, d19
    2d5c:	fmul	d1, d1, d0
    2d60:	fadd	d1, d1, d18
    2d64:	fmul	d1, d1, d0
    2d68:	fsub	d1, d1, d17
    2d6c:	fmul	d1, d1, d0
    2d70:	fadd	d1, d1, d6
    2d74:	fmul	d5, d5, d1
    2d78:	fsub	d4, d4, d5
    2d7c:	fmul	d5, d2, d4
    2d80:	fsub	d1, d1, d4
    2d84:	fsub	d4, d7, d5
    2d88:	fdiv	d1, d1, d4
    2d8c:	fmul	d1, d1, d0
    2d90:	cbz	w1, 2dfc <pts_ieee754_expm1+0x1bc>
    2d94:	fsub	d1, d1, d3
    2d98:	fmul	d1, d1, d2
    2d9c:	fsub	d1, d1, d3
    2da0:	fsub	d1, d1, d0
    2da4:	cmn	w1, #0x1
    2da8:	b.eq	2edc <pts_ieee754_expm1+0x29c>  // b.none
    2dac:	cmp	w1, #0x1
    2db0:	b.eq	2ec0 <pts_ieee754_expm1+0x280>  // b.none
    2db4:	mov	w0, #0x3ff00000            	// #1072693248
    2db8:	add	w2, w1, #0x1
    2dbc:	add	w3, w0, w1, lsl #20
    2dc0:	fmov	d0, x3
    2dc4:	shl	d3, d0, #32
    2dc8:	cmp	w2, #0x39
    2dcc:	b.hi	2e38 <pts_ieee754_expm1+0x1f8>  // b.pmore
    2dd0:	cmp	w1, #0x13
    2dd4:	b.gt	2eec <pts_ieee754_expm1+0x2ac>
    2dd8:	mov	w2, #0x200000              	// #2097152
    2ddc:	fsub	d0, d1, d2
    2de0:	asr	w1, w2, w1
    2de4:	sub	w0, w0, w1
    2de8:	fmov	d1, x0
    2dec:	shl	d1, d1, #32
    2df0:	fsub	d0, d1, d0
    2df4:	fmul	d0, d3, d0
    2df8:	ret
    2dfc:	fmul	d1, d2, d1
    2e00:	fsub	d1, d1, d0
    2e04:	fsub	d0, d2, d1
    2e08:	ret
    2e0c:	adrp	x0, 0 <__kernel_tan>
    2e10:	fmov	d0, #-1.000000000000000000e+00
    2e14:	ldr	d1, [x0]
    2e18:	fadd	d1, d2, d1
    2e1c:	fcmpe	d1, #0.0
    2e20:	b.mi	2c8c <pts_ieee754_expm1+0x4c>  // b.first
    2e24:	adrp	x0, 0 <__kernel_tan>
    2e28:	fmov	d0, #-5.000000000000000000e-01
    2e2c:	ldr	d1, [x0]
    2e30:	fmul	d1, d2, d1
    2e34:	b	2cb4 <pts_ieee754_expm1+0x74>
    2e38:	fsub	d0, d1, d2
    2e3c:	fsub	d1, d6, d0
    2e40:	cmp	w1, #0x400
    2e44:	b.eq	2f70 <pts_ieee754_expm1+0x330>  // b.none
    2e48:	fmul	d0, d3, d1
    2e4c:	fmov	d1, #1.000000000000000000e+00
    2e50:	fsub	d0, d0, d1
    2e54:	ret
    2e58:	mov	w1, #0xa2b1                	// #41649
    2e5c:	movk	w1, #0x3ff0, lsl #16
    2e60:	cmp	w0, w1
    2e64:	b.hi	2f14 <pts_ieee754_expm1+0x2d4>  // b.pmore
    2e68:	adrp	x0, 0 <__kernel_tan>
    2e6c:	ldr	d3, [x0]
    2e70:	tbz	w3, #31, 2eac <pts_ieee754_expm1+0x26c>
    2e74:	adrp	x0, 0 <__kernel_tan>
    2e78:	fadd	d3, d2, d3
    2e7c:	mov	w1, #0xffffffff            	// #-1
    2e80:	ldr	d0, [x0]
    2e84:	b	2cdc <pts_ieee754_expm1+0x9c>
    2e88:	adrp	x0, 0 <__kernel_tan>
    2e8c:	add	x0, x0, #0x0
    2e90:	ldr	d1, [x0, #40]
    2e94:	ldr	d0, [x0, #40]
    2e98:	fadd	d1, d1, d2
    2e9c:	fadd	d0, d0, d2
    2ea0:	fsub	d1, d1, d0
    2ea4:	fsub	d0, d2, d1
    2ea8:	ret
    2eac:	adrp	x0, 0 <__kernel_tan>
    2eb0:	fsub	d3, d2, d3
    2eb4:	mov	w1, #0x1                   	// #1
    2eb8:	ldr	d0, [x0]
    2ebc:	b	2cdc <pts_ieee754_expm1+0x9c>
    2ec0:	fmov	d0, #-2.500000000000000000e-01
    2ec4:	fcmpe	d2, d0
    2ec8:	b.mi	2f44 <pts_ieee754_expm1+0x304>  // b.first
    2ecc:	fsub	d0, d2, d1
    2ed0:	fadd	d0, d0, d0
    2ed4:	fadd	d0, d0, d6
    2ed8:	ret
    2edc:	fsub	d0, d2, d1
    2ee0:	fmul	d0, d0, d16
    2ee4:	fsub	d0, d0, d16
    2ee8:	ret
    2eec:	mov	w0, #0x3ff                 	// #1023
    2ef0:	sub	w0, w0, w1
    2ef4:	lsl	w0, w0, #20
    2ef8:	fmov	d0, x0
    2efc:	shl	d0, d0, #32
    2f00:	fadd	d1, d1, d0
    2f04:	fsub	d2, d2, d1
    2f08:	fadd	d2, d2, d6
    2f0c:	fmul	d0, d2, d3
    2f10:	ret
    2f14:	adrp	x0, 0 <__kernel_tan>
    2f18:	cmp	w3, #0x0
    2f1c:	fmov	d0, #-5.000000000000000000e-01
    2f20:	fmov	d3, #5.000000000000000000e-01
    2f24:	ldr	d1, [x0]
    2f28:	fcsel	d0, d0, d3, lt	// lt = tstop
    2f2c:	fmul	d1, d2, d1
    2f30:	b	2cb4 <pts_ieee754_expm1+0x74>
    2f34:	cmp	w3, #0x0
    2f38:	fmov	d1, #-1.000000000000000000e+00
    2f3c:	fcsel	d0, d0, d1, ge	// ge = tcont
    2f40:	ret
    2f44:	fadd	d16, d2, d16
    2f48:	fmov	d2, #-2.000000000000000000e+00
    2f4c:	fsub	d0, d1, d16
    2f50:	fmul	d0, d0, d2
    2f54:	ret
    2f58:	adrp	x0, 0 <__kernel_tan>
    2f5c:	add	x0, x0, #0x0
    2f60:	ldr	d0, [x0, #40]
    2f64:	ldr	d1, [x0, #40]
    2f68:	fmul	d0, d0, d1
    2f6c:	ret
    2f70:	fadd	d1, d1, d1
    2f74:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
    2f78:	fmov	d0, x0
    2f7c:	fmul	d0, d1, d0
    2f80:	b	2e4c <pts_ieee754_expm1+0x20c>

0000000000002f84 <pts_ieee754_cbrt>:
    2f84:	fmov	x1, d0
    2f88:	fmov	d3, d0
    2f8c:	mov	w3, #0x7fefffff            	// #2146435071
    2f90:	ubfx	x0, x1, #32, #31
    2f94:	lsr	x2, x1, #32
    2f98:	cmp	w0, w3
    2f9c:	b.hi	309c <pts_ieee754_cbrt+0x118>  // b.pmore
    2fa0:	and	w3, w2, #0x80000000
    2fa4:	tst	x2, #0x7ff00000
    2fa8:	b.ne	2fdc <pts_ieee754_cbrt+0x58>  // b.any
    2fac:	orr	w0, w0, w1
    2fb0:	cbz	w0, 3098 <pts_ieee754_cbrt+0x114>
    2fb4:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2fb8:	fmov	d1, x0
    2fbc:	mov	w2, #0xaaab                	// #43691
    2fc0:	mov	w1, #0x7893                	// #30867
    2fc4:	fmul	d1, d0, d1
    2fc8:	movk	w2, #0xaaaa, lsl #16
    2fcc:	movk	w1, #0x297f, lsl #16
    2fd0:	fmov	x0, d1
    2fd4:	ubfx	x0, x0, #32, #31
    2fd8:	b	2fec <pts_ieee754_cbrt+0x68>
    2fdc:	mov	w2, #0xaaab                	// #43691
    2fe0:	mov	w1, #0x7893                	// #30867
    2fe4:	movk	w2, #0xaaaa, lsl #16
    2fe8:	movk	w1, #0x2a9f, lsl #16
    2fec:	umull	x0, w0, w2
    2ff0:	lsr	x0, x0, #33
    2ff4:	add	w0, w0, w1
    2ff8:	orr	w0, w0, w3
    2ffc:	fmov	d0, x0
    3000:	adrp	x0, 0 <__kernel_tan>
    3004:	shl	d1, d0, #32
    3008:	ldr	d0, [x0]
    300c:	adrp	x0, 0 <__kernel_tan>
    3010:	ldr	d16, [x0]
    3014:	adrp	x0, 0 <__kernel_tan>
    3018:	fdiv	d2, d1, d3
    301c:	fmul	d4, d1, d1
    3020:	ldr	d5, [x0]
    3024:	adrp	x0, 0 <__kernel_tan>
    3028:	ldr	d7, [x0]
    302c:	adrp	x0, 0 <__kernel_tan>
    3030:	ldr	d6, [x0]
    3034:	mov	x0, #0x80000000            	// #2147483648
    3038:	fmul	d4, d4, d2
    303c:	fmul	d0, d4, d0
    3040:	fmul	d5, d4, d5
    3044:	fmul	d2, d4, d4
    3048:	fsub	d0, d0, d16
    304c:	fsub	d5, d5, d7
    3050:	fmul	d2, d2, d4
    3054:	fmul	d0, d0, d4
    3058:	fmul	d2, d2, d5
    305c:	fadd	d0, d0, d6
    3060:	fadd	d2, d2, d0
    3064:	fmul	d1, d2, d1
    3068:	fmov	x1, d1
    306c:	add	x0, x1, x0
    3070:	and	x0, x0, #0xffffffffc0000000
    3074:	fmov	d1, x0
    3078:	fmul	d0, d1, d1
    307c:	fadd	d2, d1, d1
    3080:	fdiv	d3, d3, d0
    3084:	fsub	d0, d3, d1
    3088:	fadd	d2, d2, d3
    308c:	fdiv	d0, d0, d2
    3090:	fmul	d0, d0, d1
    3094:	fadd	d0, d0, d1
    3098:	ret
    309c:	fadd	d0, d0, d0
    30a0:	ret

00000000000030a4 <pts_ieee754_sin>:
    30a4:	sub	sp, sp, #0x30
    30a8:	mov	w1, #0x21fb                	// #8699
    30ac:	adrp	x0, 0 <__stack_chk_guard>
    30b0:	ldr	x0, [x0]
    30b4:	fmov	d2, d0
    30b8:	stp	x29, x30, [sp, #32]
    30bc:	add	x29, sp, #0x20
    30c0:	movk	w1, #0x3fe9, lsl #16
    30c4:	ldr	x2, [x0]
    30c8:	str	x2, [sp, #24]
    30cc:	mov	x2, #0x0                   	// #0
    30d0:	fmov	x0, d0
    30d4:	ubfx	x0, x0, #32, #31
    30d8:	cmp	w0, w1
    30dc:	b.le	31d8 <pts_ieee754_sin+0x134>
    30e0:	mov	w1, #0x7fefffff            	// #2146435071
    30e4:	cmp	w0, w1
    30e8:	b.le	3118 <pts_ieee754_sin+0x74>
    30ec:	fsub	d0, d0, d0
    30f0:	adrp	x0, 0 <__stack_chk_guard>
    30f4:	ldr	x0, [x0]
    30f8:	ldr	x2, [sp, #24]
    30fc:	ldr	x1, [x0]
    3100:	subs	x2, x2, x1
    3104:	mov	x1, #0x0                   	// #0
    3108:	b.ne	35d4 <pts_ieee754_sin+0x530>  // b.any
    310c:	ldp	x29, x30, [sp, #32]
    3110:	add	sp, sp, #0x30
    3114:	ret
    3118:	add	x0, sp, #0x8
    311c:	bl	964 <__ieee754_rem_pio2>
    3120:	and	w0, w0, #0x3
    3124:	cmp	w0, #0x1
    3128:	b.eq	33cc <pts_ieee754_sin+0x328>  // b.none
    312c:	cmp	w0, #0x2
    3130:	b.eq	3258 <pts_ieee754_sin+0x1b4>  // b.none
    3134:	cbnz	w0, 32fc <pts_ieee754_sin+0x258>
    3138:	ldp	d0, d5, [sp, #8]
    313c:	mov	w0, #0x3e3fffff            	// #1044381695
    3140:	fmov	x1, d0
    3144:	ubfx	x1, x1, #32, #31
    3148:	cmp	w1, w0
    314c:	b.gt	3158 <pts_ieee754_sin+0xb4>
    3150:	fcvtzs	w0, d0
    3154:	cbz	w0, 30f0 <pts_ieee754_sin+0x4c>
    3158:	adrp	x0, 0 <__kernel_tan>
    315c:	fmul	d3, d0, d0
    3160:	fmov	d2, #5.000000000000000000e-01
    3164:	ldr	d1, [x0]
    3168:	adrp	x0, 0 <__kernel_tan>
    316c:	fmul	d2, d5, d2
    3170:	ldr	d18, [x0]
    3174:	adrp	x0, 0 <__kernel_tan>
    3178:	fmul	d1, d3, d1
    317c:	fmul	d6, d0, d3
    3180:	ldr	d17, [x0]
    3184:	adrp	x0, 0 <__kernel_tan>
    3188:	ldr	d16, [x0]
    318c:	adrp	x0, 0 <__kernel_tan>
    3190:	fsub	d1, d1, d18
    3194:	ldr	d7, [x0]
    3198:	adrp	x0, 0 <__kernel_tan>
    319c:	ldr	d4, [x0]
    31a0:	fmul	d1, d1, d3
    31a4:	fmul	d4, d6, d4
    31a8:	fadd	d1, d1, d17
    31ac:	fmul	d1, d1, d3
    31b0:	fsub	d1, d1, d16
    31b4:	fmul	d1, d1, d3
    31b8:	fadd	d1, d1, d7
    31bc:	fmul	d1, d1, d6
    31c0:	fsub	d1, d2, d1
    31c4:	fmul	d1, d1, d3
    31c8:	fsub	d1, d1, d5
    31cc:	fadd	d1, d1, d4
    31d0:	fsub	d0, d0, d1
    31d4:	b	30f0 <pts_ieee754_sin+0x4c>
    31d8:	mov	w1, #0x3e3fffff            	// #1044381695
    31dc:	cmp	w0, w1
    31e0:	b.gt	31ec <pts_ieee754_sin+0x148>
    31e4:	fcvtzs	w0, d0
    31e8:	cbz	w0, 30f0 <pts_ieee754_sin+0x4c>
    31ec:	adrp	x0, 0 <__kernel_tan>
    31f0:	fmul	d0, d2, d2
    31f4:	ldr	d1, [x0]
    31f8:	adrp	x0, 0 <__kernel_tan>
    31fc:	ldr	d16, [x0]
    3200:	adrp	x0, 0 <__kernel_tan>
    3204:	fmul	d1, d0, d1
    3208:	fmul	d3, d2, d0
    320c:	ldr	d7, [x0]
    3210:	adrp	x0, 0 <__kernel_tan>
    3214:	ldr	d6, [x0]
    3218:	adrp	x0, 0 <__kernel_tan>
    321c:	fsub	d1, d1, d16
    3220:	ldr	d5, [x0]
    3224:	adrp	x0, 0 <__kernel_tan>
    3228:	ldr	d4, [x0]
    322c:	fmul	d1, d1, d0
    3230:	fadd	d1, d1, d7
    3234:	fmul	d1, d1, d0
    3238:	fsub	d1, d1, d6
    323c:	fmul	d1, d1, d0
    3240:	fadd	d1, d1, d5
    3244:	fmul	d1, d1, d0
    3248:	fsub	d1, d1, d4
    324c:	fmul	d1, d1, d3
    3250:	fadd	d0, d1, d2
    3254:	b	30f0 <pts_ieee754_sin+0x4c>
    3258:	ldp	d0, d5, [sp, #8]
    325c:	mov	w0, #0x3e3fffff            	// #1044381695
    3260:	fmov	x1, d0
    3264:	ubfx	x1, x1, #32, #31
    3268:	cmp	w1, w0
    326c:	b.gt	3278 <pts_ieee754_sin+0x1d4>
    3270:	fcvtzs	w0, d0
    3274:	cbz	w0, 32f4 <pts_ieee754_sin+0x250>
    3278:	adrp	x0, 0 <__kernel_tan>
    327c:	fmul	d3, d0, d0
    3280:	fmov	d2, #5.000000000000000000e-01
    3284:	ldr	d1, [x0]
    3288:	adrp	x0, 0 <__kernel_tan>
    328c:	fmul	d2, d5, d2
    3290:	ldr	d18, [x0]
    3294:	adrp	x0, 0 <__kernel_tan>
    3298:	fmul	d1, d3, d1
    329c:	fmul	d6, d0, d3
    32a0:	ldr	d17, [x0]
    32a4:	adrp	x0, 0 <__kernel_tan>
    32a8:	ldr	d16, [x0]
    32ac:	adrp	x0, 0 <__kernel_tan>
    32b0:	fsub	d1, d1, d18
    32b4:	ldr	d7, [x0]
    32b8:	adrp	x0, 0 <__kernel_tan>
    32bc:	ldr	d4, [x0]
    32c0:	fmul	d1, d1, d3
    32c4:	fmul	d4, d6, d4
    32c8:	fadd	d1, d1, d17
    32cc:	fmul	d1, d1, d3
    32d0:	fsub	d1, d1, d16
    32d4:	fmul	d1, d1, d3
    32d8:	fadd	d1, d1, d7
    32dc:	fmul	d1, d1, d6
    32e0:	fsub	d1, d2, d1
    32e4:	fmul	d1, d1, d3
    32e8:	fsub	d1, d1, d5
    32ec:	fadd	d1, d1, d4
    32f0:	fsub	d0, d0, d1
    32f4:	fneg	d0, d0
    32f8:	b	30f0 <pts_ieee754_sin+0x4c>
    32fc:	ldp	d3, d5, [sp, #8]
    3300:	mov	w1, #0x3e3fffff            	// #1044381695
    3304:	fmov	x0, d3
    3308:	ubfx	x0, x0, #32, #31
    330c:	cmp	w0, w1
    3310:	b.le	3528 <pts_ieee754_sin+0x484>
    3314:	adrp	x1, 0 <__kernel_tan>
    3318:	fmul	d2, d3, d3
    331c:	ldr	d1, [x1]
    3320:	adrp	x1, 0 <__kernel_tan>
    3324:	ldr	d16, [x1]
    3328:	adrp	x1, 0 <__kernel_tan>
    332c:	fmul	d1, d2, d1
    3330:	ldr	d7, [x1]
    3334:	adrp	x1, 0 <__kernel_tan>
    3338:	ldr	d6, [x1]
    333c:	adrp	x1, 0 <__kernel_tan>
    3340:	fadd	d1, d1, d16
    3344:	ldr	d4, [x1]
    3348:	adrp	x1, 0 <__kernel_tan>
    334c:	ldr	d0, [x1]
    3350:	mov	w1, #0x3332                	// #13106
    3354:	fmul	d1, d1, d2
    3358:	movk	w1, #0x3fd3, lsl #16
    335c:	fsub	d1, d1, d7
    3360:	fmul	d1, d1, d2
    3364:	fadd	d1, d1, d6
    3368:	fmul	d1, d1, d2
    336c:	fsub	d1, d1, d4
    3370:	fmul	d1, d1, d2
    3374:	fadd	d1, d1, d0
    3378:	fmul	d1, d1, d2
    337c:	cmp	w0, w1
    3380:	b.le	3594 <pts_ieee754_sin+0x4f0>
    3384:	mov	w1, #0x3fe90000            	// #1072234496
    3388:	cmp	w0, w1
    338c:	b.gt	35c8 <pts_ieee754_sin+0x524>
    3390:	sub	w0, w0, #0x200, lsl #12
    3394:	fmov	d4, x0
    3398:	fmov	d0, #1.000000000000000000e+00
    339c:	shl	d4, d4, #32
    33a0:	fsub	d0, d0, d4
    33a4:	fmov	d6, #5.000000000000000000e-01
    33a8:	fmul	d1, d2, d1
    33ac:	fmul	d3, d3, d5
    33b0:	fmul	d2, d2, d6
    33b4:	fsub	d1, d1, d3
    33b8:	fsub	d2, d2, d4
    33bc:	fsub	d1, d2, d1
    33c0:	fsub	d0, d0, d1
    33c4:	fneg	d0, d0
    33c8:	b	30f0 <pts_ieee754_sin+0x4c>
    33cc:	ldp	d3, d5, [sp, #8]
    33d0:	mov	w1, #0x3e3fffff            	// #1044381695
    33d4:	fmov	x0, d3
    33d8:	ubfx	x0, x0, #32, #31
    33dc:	cmp	w0, w1
    33e0:	b.le	3498 <pts_ieee754_sin+0x3f4>
    33e4:	adrp	x1, 0 <__kernel_tan>
    33e8:	fmul	d2, d3, d3
    33ec:	ldr	d1, [x1]
    33f0:	adrp	x1, 0 <__kernel_tan>
    33f4:	ldr	d16, [x1]
    33f8:	adrp	x1, 0 <__kernel_tan>
    33fc:	fmul	d1, d2, d1
    3400:	ldr	d7, [x1]
    3404:	adrp	x1, 0 <__kernel_tan>
    3408:	ldr	d6, [x1]
    340c:	adrp	x1, 0 <__kernel_tan>
    3410:	fadd	d1, d1, d16
    3414:	ldr	d4, [x1]
    3418:	adrp	x1, 0 <__kernel_tan>
    341c:	ldr	d0, [x1]
    3420:	mov	w1, #0x3332                	// #13106
    3424:	fmul	d1, d1, d2
    3428:	movk	w1, #0x3fd3, lsl #16
    342c:	fsub	d1, d1, d7
    3430:	fmul	d1, d1, d2
    3434:	fadd	d1, d1, d6
    3438:	fmul	d1, d1, d2
    343c:	fsub	d1, d1, d4
    3440:	fmul	d1, d1, d2
    3444:	fadd	d1, d1, d0
    3448:	fmul	d1, d1, d2
    344c:	cmp	w0, w1
    3450:	b.le	3504 <pts_ieee754_sin+0x460>
    3454:	mov	w1, #0x3fe90000            	// #1072234496
    3458:	cmp	w0, w1
    345c:	b.gt	35bc <pts_ieee754_sin+0x518>
    3460:	sub	w0, w0, #0x200, lsl #12
    3464:	fmov	d4, x0
    3468:	fmov	d0, #1.000000000000000000e+00
    346c:	shl	d4, d4, #32
    3470:	fsub	d0, d0, d4
    3474:	fmov	d6, #5.000000000000000000e-01
    3478:	fmul	d1, d2, d1
    347c:	fmul	d3, d3, d5
    3480:	fmul	d2, d2, d6
    3484:	fsub	d1, d1, d3
    3488:	fsub	d2, d2, d4
    348c:	fsub	d1, d2, d1
    3490:	fsub	d0, d0, d1
    3494:	b	30f0 <pts_ieee754_sin+0x4c>
    3498:	fcvtzs	w0, d3
    349c:	fmov	d0, #1.000000000000000000e+00
    34a0:	cbz	w0, 30f0 <pts_ieee754_sin+0x4c>
    34a4:	adrp	x0, 0 <__kernel_tan>
    34a8:	fmul	d2, d3, d3
    34ac:	ldr	d1, [x0]
    34b0:	adrp	x0, 0 <__kernel_tan>
    34b4:	ldr	d16, [x0]
    34b8:	adrp	x0, 0 <__kernel_tan>
    34bc:	fmul	d1, d2, d1
    34c0:	ldr	d7, [x0]
    34c4:	adrp	x0, 0 <__kernel_tan>
    34c8:	ldr	d6, [x0]
    34cc:	adrp	x0, 0 <__kernel_tan>
    34d0:	fadd	d1, d1, d16
    34d4:	ldr	d4, [x0]
    34d8:	adrp	x0, 0 <__kernel_tan>
    34dc:	ldr	d0, [x0]
    34e0:	fmul	d1, d1, d2
    34e4:	fsub	d1, d1, d7
    34e8:	fmul	d1, d1, d2
    34ec:	fadd	d1, d1, d6
    34f0:	fmul	d1, d1, d2
    34f4:	fsub	d1, d1, d4
    34f8:	fmul	d1, d1, d2
    34fc:	fadd	d1, d1, d0
    3500:	fmul	d1, d1, d2
    3504:	fmul	d1, d1, d2
    3508:	fmul	d3, d3, d5
    350c:	fmov	d4, #5.000000000000000000e-01
    3510:	fmov	d0, #1.000000000000000000e+00
    3514:	fmul	d2, d2, d4
    3518:	fsub	d1, d1, d3
    351c:	fsub	d1, d2, d1
    3520:	fsub	d0, d0, d1
    3524:	b	30f0 <pts_ieee754_sin+0x4c>
    3528:	fcvtzs	w0, d3
    352c:	fmov	d0, #-1.000000000000000000e+00
    3530:	cbz	w0, 30f0 <pts_ieee754_sin+0x4c>
    3534:	adrp	x0, 0 <__kernel_tan>
    3538:	fmul	d2, d3, d3
    353c:	ldr	d1, [x0]
    3540:	adrp	x0, 0 <__kernel_tan>
    3544:	ldr	d16, [x0]
    3548:	adrp	x0, 0 <__kernel_tan>
    354c:	fmul	d1, d2, d1
    3550:	ldr	d7, [x0]
    3554:	adrp	x0, 0 <__kernel_tan>
    3558:	ldr	d6, [x0]
    355c:	adrp	x0, 0 <__kernel_tan>
    3560:	fadd	d1, d1, d16
    3564:	ldr	d4, [x0]
    3568:	adrp	x0, 0 <__kernel_tan>
    356c:	ldr	d0, [x0]
    3570:	fmul	d1, d1, d2
    3574:	fsub	d1, d1, d7
    3578:	fmul	d1, d1, d2
    357c:	fadd	d1, d1, d6
    3580:	fmul	d1, d1, d2
    3584:	fsub	d1, d1, d4
    3588:	fmul	d1, d1, d2
    358c:	fadd	d1, d1, d0
    3590:	fmul	d1, d1, d2
    3594:	fmul	d1, d2, d1
    3598:	fmul	d3, d3, d5
    359c:	fmov	d4, #5.000000000000000000e-01
    35a0:	fmov	d0, #1.000000000000000000e+00
    35a4:	fmul	d2, d2, d4
    35a8:	fsub	d1, d1, d3
    35ac:	fsub	d1, d2, d1
    35b0:	fsub	d0, d0, d1
    35b4:	fneg	d0, d0
    35b8:	b	30f0 <pts_ieee754_sin+0x4c>
    35bc:	fmov	d0, #7.187500000000000000e-01
    35c0:	fmov	d4, #2.812500000000000000e-01
    35c4:	b	3474 <pts_ieee754_sin+0x3d0>
    35c8:	fmov	d0, #7.187500000000000000e-01
    35cc:	fmov	d4, #2.812500000000000000e-01
    35d0:	b	33a4 <pts_ieee754_sin+0x300>
    35d4:	bl	0 <__stack_chk_fail>
    35d8:	nop
    35dc:	nop

00000000000035e0 <pts_ieee754_tan>:
    35e0:	sub	sp, sp, #0x30
    35e4:	fmov	x0, d0
    35e8:	adrp	x1, 0 <__stack_chk_guard>
    35ec:	ldr	x1, [x1]
    35f0:	mov	w2, #0x21fb                	// #8699
    35f4:	stp	x29, x30, [sp, #32]
    35f8:	add	x29, sp, #0x20
    35fc:	movk	w2, #0x3fe9, lsl #16
    3600:	ldr	x3, [x1]
    3604:	str	x3, [sp, #24]
    3608:	mov	x3, #0x0                   	// #0
    360c:	ubfx	x1, x0, #32, #31
    3610:	cmp	w1, w2
    3614:	b.le	3694 <pts_ieee754_tan+0xb4>
    3618:	mov	w2, #0x7fefffff            	// #2146435071
    361c:	cmp	w1, w2
    3620:	b.le	3654 <pts_ieee754_tan+0x74>
    3624:	adrp	x1, 0 <__stack_chk_guard>
    3628:	ldr	x1, [x1]
    362c:	fsub	d0, d0, d0
    3630:	mov	x0, x1
    3634:	ldr	x2, [sp, #24]
    3638:	ldr	x1, [x0]
    363c:	subs	x2, x2, x1
    3640:	mov	x1, #0x0                   	// #0
    3644:	b.ne	36c4 <pts_ieee754_tan+0xe4>  // b.any
    3648:	ldp	x29, x30, [sp, #32]
    364c:	add	sp, sp, #0x30
    3650:	ret
    3654:	add	x0, sp, #0x8
    3658:	bl	964 <__ieee754_rem_pio2>
    365c:	adrp	x1, 0 <__stack_chk_guard>
    3660:	ldr	x1, [x1]
    3664:	ldr	x3, [sp, #24]
    3668:	ldr	x2, [x1]
    366c:	subs	x3, x3, x2
    3670:	mov	x2, #0x0                   	// #0
    3674:	b.ne	36c4 <pts_ieee754_tan+0xe4>  // b.any
    3678:	ldp	x29, x30, [sp, #32]
    367c:	ubfiz	w0, w0, #1, #1
    3680:	ldp	d0, d1, [sp, #8]
    3684:	mov	w1, #0x1                   	// #1
    3688:	add	sp, sp, #0x30
    368c:	sub	w0, w1, w0
    3690:	b	0 <__kernel_tan>
    3694:	adrp	x0, 0 <__stack_chk_guard>
    3698:	ldr	x0, [x0]
    369c:	ldr	x2, [sp, #24]
    36a0:	ldr	x1, [x0]
    36a4:	subs	x2, x2, x1
    36a8:	mov	x1, #0x0                   	// #0
    36ac:	b.ne	36c4 <pts_ieee754_tan+0xe4>  // b.any
    36b0:	ldp	x29, x30, [sp, #32]
    36b4:	movi	d1, #0x0
    36b8:	add	sp, sp, #0x30
    36bc:	mov	w0, #0x1                   	// #1
    36c0:	b	0 <__kernel_tan>
    36c4:	bl	0 <__stack_chk_fail>
    36c8:	nop
    36cc:	nop

00000000000036d0 <pts_ieee754_cosh>:
    36d0:	fmov	x1, d0
    36d4:	stp	x29, x30, [sp, #-16]!
    36d8:	mov	w0, #0x2e42                	// #11842
    36dc:	mov	x29, sp
    36e0:	fmov	d1, d0
    36e4:	movk	w0, #0x3fd6, lsl #16
    36e8:	ubfx	x4, x1, #32, #31
    36ec:	fabs	d0, d0
    36f0:	cmp	w4, w0
    36f4:	b.le	374c <pts_ieee754_cosh+0x7c>
    36f8:	mov	w0, #0x4035ffff            	// #1077280767
    36fc:	cmp	w4, w0
    3700:	b.le	3794 <pts_ieee754_cosh+0xc4>
    3704:	mov	w0, #0x2e41                	// #11841
    3708:	movk	w0, #0x4086, lsl #16
    370c:	cmp	w4, w0
    3710:	b.le	3780 <pts_ieee754_cosh+0xb0>
    3714:	adrp	x0, 0 <__kernel_tan>
    3718:	ldr	d2, [x0]
    371c:	fcmpe	d0, d2
    3720:	b.ls	37bc <pts_ieee754_cosh+0xec>  // b.plast
    3724:	mov	w0, #0x7fefffff            	// #2146435071
    3728:	cmp	w4, w0
    372c:	b.gt	37b0 <pts_ieee754_cosh+0xe0>
    3730:	adrp	x0, 0 <__kernel_tan>
    3734:	add	x0, x0, #0x0
    3738:	ldr	d0, [x0, #48]
    373c:	ldr	d1, [x0, #48]
    3740:	fmul	d0, d0, d1
    3744:	ldp	x29, x30, [sp], #16
    3748:	ret
    374c:	bl	2c40 <pts_ieee754_expm1>
    3750:	fmov	d1, d0
    3754:	fmov	d3, #1.000000000000000000e+00
    3758:	mov	w0, #0x3c7fffff            	// #1015021567
    375c:	fadd	d0, d0, d3
    3760:	cmp	w4, w0
    3764:	b.le	3744 <pts_ieee754_cosh+0x74>
    3768:	fmul	d2, d1, d1
    376c:	fadd	d1, d0, d0
    3770:	ldp	x29, x30, [sp], #16
    3774:	fdiv	d1, d2, d1
    3778:	fadd	d0, d1, d3
    377c:	ret
    3780:	bl	1e00 <pts_ieee754_exp>
    3784:	fmov	d1, #5.000000000000000000e-01
    3788:	ldp	x29, x30, [sp], #16
    378c:	fmul	d0, d0, d1
    3790:	ret
    3794:	bl	1e00 <pts_ieee754_exp>
    3798:	fmov	d1, #5.000000000000000000e-01
    379c:	ldp	x29, x30, [sp], #16
    37a0:	fdiv	d2, d1, d0
    37a4:	fmul	d0, d0, d1
    37a8:	fadd	d0, d0, d2
    37ac:	ret
    37b0:	fmul	d0, d1, d1
    37b4:	ldp	x29, x30, [sp], #16
    37b8:	ret
    37bc:	fmov	d18, #5.000000000000000000e-01
    37c0:	fmul	d0, d0, d18
    37c4:	bl	1e00 <pts_ieee754_exp>
    37c8:	fmul	d1, d0, d18
    37cc:	fmul	d0, d1, d0
    37d0:	b	3744 <pts_ieee754_cosh+0x74>

00000000000037d4 <pts_ieee754_sinh>:
    37d4:	fcmpe	d0, #0.0
    37d8:	fabs	d21, d0
    37dc:	fmov	d1, #-5.000000000000000000e-01
    37e0:	fmov	d2, #5.000000000000000000e-01
    37e4:	fmov	d3, #2.200000000000000000e+01
    37e8:	stp	x29, x30, [sp, #-16]!
    37ec:	fcsel	d22, d1, d2, mi	// mi = first
    37f0:	fcmpe	d21, d3
    37f4:	mov	x29, sp
    37f8:	b.mi	3834 <pts_ieee754_sinh+0x60>  // b.first
    37fc:	mov	x0, #0x2e4200000000        	// #50861002719232
    3800:	movk	x0, #0x4086, lsl #48
    3804:	fmov	d1, x0
    3808:	fcmpe	d21, d1
    380c:	b.mi	3870 <pts_ieee754_sinh+0x9c>  // b.first
    3810:	adrp	x0, 0 <__kernel_tan>
    3814:	ldr	d1, [x0]
    3818:	fcmpe	d21, d1
    381c:	b.ls	38a4 <pts_ieee754_sinh+0xd0>  // b.plast
    3820:	adrp	x0, 0 <__kernel_tan>
    3824:	ldr	d1, [x0]
    3828:	fmul	d0, d0, d1
    382c:	ldp	x29, x30, [sp], #16
    3830:	ret
    3834:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
    3838:	fmov	d1, x0
    383c:	fcmpe	d21, d1
    3840:	b.mi	382c <pts_ieee754_sinh+0x58>  // b.first
    3844:	fmov	d0, d21
    3848:	bl	2c40 <pts_ieee754_expm1>
    384c:	fmov	d1, #1.000000000000000000e+00
    3850:	fcmpe	d21, d1
    3854:	b.mi	3884 <pts_ieee754_sinh+0xb0>  // b.first
    3858:	fadd	d1, d0, d1
    385c:	ldp	x29, x30, [sp], #16
    3860:	fdiv	d1, d0, d1
    3864:	fadd	d0, d1, d0
    3868:	fmul	d0, d0, d22
    386c:	ret
    3870:	fmov	d0, d21
    3874:	bl	1e00 <pts_ieee754_exp>
    3878:	fmul	d0, d0, d22
    387c:	ldp	x29, x30, [sp], #16
    3880:	ret
    3884:	fmul	d2, d0, d0
    3888:	fadd	d1, d0, d1
    388c:	fadd	d0, d0, d0
    3890:	ldp	x29, x30, [sp], #16
    3894:	fdiv	d1, d2, d1
    3898:	fsub	d0, d0, d1
    389c:	fmul	d0, d0, d22
    38a0:	ret
    38a4:	fmul	d0, d21, d2
    38a8:	bl	1e00 <pts_ieee754_exp>
    38ac:	fmul	d1, d22, d0
    38b0:	fmul	d0, d1, d0
    38b4:	b	382c <pts_ieee754_sinh+0x58>
    38b8:	nop
    38bc:	nop

00000000000038c0 <pts_ieee754_tanh>:
    38c0:	fmov	x0, d0
    38c4:	fmov	d1, d0
    38c8:	mov	w1, #0x7fefffff            	// #2146435071
    38cc:	lsr	x4, x0, #32
    38d0:	and	w0, w4, #0x7fffffff
    38d4:	cmp	w0, w1
    38d8:	b.le	38f8 <pts_ieee754_tanh+0x38>
    38dc:	fmov	d0, #1.000000000000000000e+00
    38e0:	fdiv	d1, d0, d1
    38e4:	tbnz	w4, #31, 38f0 <pts_ieee754_tanh+0x30>
    38e8:	fadd	d0, d1, d0
    38ec:	ret
    38f0:	fsub	d0, d1, d0
    38f4:	ret
    38f8:	mov	w1, #0x4035ffff            	// #1077280767
    38fc:	cmp	w0, w1
    3900:	b.gt	3958 <pts_ieee754_tanh+0x98>
    3904:	stp	x29, x30, [sp, #-16]!
    3908:	mov	w1, #0x3e2fffff            	// #1043333119
    390c:	mov	x29, sp
    3910:	cmp	w0, w1
    3914:	b.le	397c <pts_ieee754_tanh+0xbc>
    3918:	fabs	d0, d0
    391c:	mov	w1, #0x3fefffff            	// #1072693247
    3920:	cmp	w0, w1
    3924:	b.le	3998 <pts_ieee754_tanh+0xd8>
    3928:	fadd	d0, d0, d0
    392c:	bl	2c40 <pts_ieee754_expm1>
    3930:	fmov	d2, #2.000000000000000000e+00
    3934:	fmov	d1, #1.000000000000000000e+00
    3938:	fadd	d0, d0, d2
    393c:	fdiv	d2, d2, d0
    3940:	fsub	d0, d1, d2
    3944:	fneg	d1, d0
    3948:	cmp	w4, #0x0
    394c:	fcsel	d0, d1, d0, lt	// lt = tstop
    3950:	ldp	x29, x30, [sp], #16
    3954:	ret
    3958:	adrp	x0, 0 <__kernel_tan>
    395c:	add	x0, x0, #0x0
    3960:	fmov	d0, #1.000000000000000000e+00
    3964:	cmp	w4, #0x0
    3968:	ldr	d1, [x0, #576]
    396c:	fsub	d0, d0, d1
    3970:	fneg	d1, d0
    3974:	fcsel	d0, d1, d0, lt	// lt = tstop
    3978:	ret
    397c:	adrp	x0, 0 <__kernel_tan>
    3980:	fmov	d3, #1.000000000000000000e+00
    3984:	ldr	d2, [x0]
    3988:	fadd	d2, d0, d2
    398c:	fcmpe	d2, d3
    3990:	b.gt	3950 <pts_ieee754_tanh+0x90>
    3994:	fabs	d0, d0
    3998:	fmov	d1, #-2.000000000000000000e+00
    399c:	fmul	d0, d0, d1
    39a0:	bl	2c40 <pts_ieee754_expm1>
    39a4:	fneg	d1, d0
    39a8:	fmov	d2, #2.000000000000000000e+00
    39ac:	fadd	d0, d0, d2
    39b0:	fdiv	d0, d1, d0
    39b4:	b	3944 <pts_ieee754_tanh+0x84>
