
bin/b2_clang_fast.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <pts_ieee754_acos>:
       0:	fmov	x8, d0
       4:	lsr	x10, x8, #32
       8:	ubfx	x9, x8, #32, #31
       c:	ubfx	w11, w10, #20, #11
      10:	cmp	w11, #0x3ff
      14:	b.cc	4c <pts_ieee754_acos+0x4c>  // b.lo, b.ul, b.last
      18:	movi	d0, #0x0
      1c:	adrp	x11, 0 <pts_ieee754_acos>
      20:	cmp	w10, #0x0
      24:	ldr	d1, [x11]
      28:	mov	w10, #0xc0100000            	// #-1072693248
      2c:	add	w9, w9, w10
      30:	orr	w8, w9, w8
      34:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
      38:	fcsel	d0, d0, d1, gt
      3c:	fmov	d1, x9
      40:	cmp	w8, #0x0
      44:	fcsel	d0, d0, d1, eq	// eq = none
      48:	ret
      4c:	lsr	w10, w9, #21
      50:	cmp	w10, #0x1fe
      54:	b.hi	74 <pts_ieee754_acos+0x74>  // b.pmore
      58:	mov	w8, #0x1                   	// #1
      5c:	movk	w8, #0x3c60, lsl #16
      60:	cmp	w9, w8
      64:	adrp	x8, 0 <pts_ieee754_acos>
      68:	b.cs	114 <pts_ieee754_acos+0x114>  // b.hs, b.nlast
      6c:	ldr	d0, [x8]
      70:	ret
      74:	fmov	d1, #1.000000000000000000e+00
      78:	tbnz	x8, #63, 194 <pts_ieee754_acos+0x194>
      7c:	fsub	d0, d1, d0
      80:	fmov	d1, #5.000000000000000000e-01
      84:	adrp	x8, 0 <pts_ieee754_acos>
      88:	adrp	x9, 0 <pts_ieee754_acos>
      8c:	ldr	d2, [x8]
      90:	adrp	x8, 0 <pts_ieee754_acos>
      94:	add	x8, x8, #0x0
      98:	ldr	d3, [x9]
      9c:	fmul	d0, d0, d1
      a0:	fsqrt	d1, d0
      a4:	fmadd	d2, d0, d3, d2
      a8:	ld1r	{v3.2d}, [x8]
      ac:	mov	v3.d[0], v2.d[0]
      b0:	fmov	x8, d1
      b4:	and	x8, x8, #0xffffffff00000000
      b8:	fmov	d2, x8
      bc:	adrp	x8, 0 <pts_ieee754_acos>
      c0:	ldr	q6, [x8]
      c4:	adrp	x8, 0 <pts_ieee754_acos>
      c8:	fmsub	d4, d2, d2, d0
      cc:	fadd	d5, d1, d2
      d0:	fmla	v6.2d, v3.2d, v0.d[0]
      d4:	fdiv	d3, d4, d5
      d8:	ldr	q4, [x8]
      dc:	adrp	x8, 0 <pts_ieee754_acos>
      e0:	ldr	q5, [x8]
      e4:	adrp	x8, 0 <pts_ieee754_acos>
      e8:	fmla	v4.2d, v6.2d, v0.d[0]
      ec:	fmla	v5.2d, v4.2d, v0.d[0]
      f0:	ldr	q4, [x8]
      f4:	fmla	v4.2d, v5.2d, v0.d[0]
      f8:	fmul	d0, d0, d4
      fc:	mov	d4, v4.d[1]
     100:	fdiv	d0, d0, d4
     104:	fmadd	d0, d1, d0, d3
     108:	fadd	d0, d0, d2
     10c:	fadd	d0, d0, d0
     110:	ret
     114:	fmul	d1, d0, d0
     118:	adrp	x9, 0 <pts_ieee754_acos>
     11c:	adrp	x10, 0 <pts_ieee754_acos>
     120:	ldr	d2, [x9]
     124:	ldr	d3, [x10]
     128:	adrp	x9, 0 <pts_ieee754_acos>
     12c:	add	x9, x9, #0x0
     130:	fmadd	d2, d1, d3, d2
     134:	ld1r	{v3.2d}, [x9]
     138:	adrp	x9, 0 <pts_ieee754_acos>
     13c:	mov	v3.d[0], v2.d[0]
     140:	ldr	q2, [x9]
     144:	adrp	x9, 0 <pts_ieee754_acos>
     148:	fmla	v2.2d, v3.2d, v1.d[0]
     14c:	ldr	q3, [x9]
     150:	adrp	x9, 0 <pts_ieee754_acos>
     154:	fmla	v3.2d, v2.2d, v1.d[0]
     158:	ldr	q2, [x9]
     15c:	adrp	x9, 0 <pts_ieee754_acos>
     160:	fmla	v2.2d, v3.2d, v1.d[0]
     164:	ldr	q3, [x9]
     168:	adrp	x9, 0 <pts_ieee754_acos>
     16c:	fmla	v3.2d, v2.2d, v1.d[0]
     170:	fmul	d1, d1, d3
     174:	mov	d2, v3.d[1]
     178:	fdiv	d1, d1, d2
     17c:	ldr	d2, [x9]
     180:	fmsub	d1, d1, d0, d2
     184:	fsub	d0, d1, d0
     188:	ldr	d1, [x8]
     18c:	fadd	d0, d0, d1
     190:	ret
     194:	fadd	d0, d0, d1
     198:	fmov	d1, #5.000000000000000000e-01
     19c:	adrp	x8, 0 <pts_ieee754_acos>
     1a0:	adrp	x9, 0 <pts_ieee754_acos>
     1a4:	ldr	d2, [x9]
     1a8:	fmul	d0, d0, d1
     1ac:	ldr	d1, [x8]
     1b0:	adrp	x8, 0 <pts_ieee754_acos>
     1b4:	add	x8, x8, #0x0
     1b8:	fmadd	d1, d0, d2, d1
     1bc:	ld1r	{v2.2d}, [x8]
     1c0:	adrp	x8, 0 <pts_ieee754_acos>
     1c4:	mov	v2.d[0], v1.d[0]
     1c8:	ldr	q1, [x8]
     1cc:	adrp	x8, 0 <pts_ieee754_acos>
     1d0:	fmla	v1.2d, v2.2d, v0.d[0]
     1d4:	ldr	q2, [x8]
     1d8:	adrp	x8, 0 <pts_ieee754_acos>
     1dc:	fmla	v2.2d, v1.2d, v0.d[0]
     1e0:	ldr	q1, [x8]
     1e4:	adrp	x8, 0 <pts_ieee754_acos>
     1e8:	fmla	v1.2d, v2.2d, v0.d[0]
     1ec:	ldr	q2, [x8]
     1f0:	adrp	x8, 0 <pts_ieee754_acos>
     1f4:	fmla	v2.2d, v1.2d, v0.d[0]
     1f8:	fmul	d1, d0, d2
     1fc:	mov	d2, v2.d[1]
     200:	fsqrt	d0, d0
     204:	fdiv	d1, d1, d2
     208:	ldr	d2, [x8]
     20c:	adrp	x8, 0 <pts_ieee754_acos>
     210:	fmadd	d1, d0, d1, d2
     214:	ldr	d2, [x8]
     218:	fadd	d0, d0, d1
     21c:	fmov	d1, #-2.000000000000000000e+00
     220:	fmadd	d0, d0, d1, d2
     224:	ret
     228:	nop
     22c:	nop
     230:	nop
     234:	nop
     238:	nop
     23c:	nop

0000000000000240 <pts_ieee754_acosh>:
     240:	fmov	x9, d0
     244:	mov	w10, #0x3ff00000            	// #1072693248
     248:	lsr	x8, x9, #32
     24c:	cmp	w8, w10
     250:	b.ge	260 <pts_ieee754_acosh+0x20>  // b.tcont
     254:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     258:	fmov	d0, x8
     25c:	ret
     260:	lsr	w10, w8, #20
     264:	cmp	w10, #0x41b
     268:	b.cc	27c <pts_ieee754_acosh+0x3c>  // b.lo, b.ul, b.last
     26c:	cmp	w10, #0x7ff
     270:	b.cc	2bc <pts_ieee754_acosh+0x7c>  // b.lo, b.ul, b.last
     274:	fadd	d0, d0, d0
     278:	ret
     27c:	mov	w10, #0xc0100000            	// #-1072693248
     280:	add	w10, w8, w10
     284:	orr	w9, w10, w9
     288:	cbz	w9, 2dc <pts_ieee754_acosh+0x9c>
     28c:	mov	w9, #0x1                   	// #1
     290:	fmov	d1, #-1.000000000000000000e+00
     294:	movk	w9, #0x4000, lsl #16
     298:	cmp	w8, w9
     29c:	b.cc	2e4 <pts_ieee754_acosh+0xa4>  // b.lo, b.ul, b.last
     2a0:	fmadd	d2, d0, d0, d1
     2a4:	fsqrt	d2, d2
     2a8:	fadd	d2, d2, d0
     2ac:	fdiv	d1, d1, d2
     2b0:	fmov	d2, #2.000000000000000000e+00
     2b4:	fmadd	d0, d0, d2, d1
     2b8:	b	300 <pts_ieee754_log>
     2bc:	stp	x29, x30, [sp, #-16]!
     2c0:	mov	x29, sp
     2c4:	bl	300 <pts_ieee754_log>
     2c8:	adrp	x8, 0 <pts_ieee754_acos>
     2cc:	ldr	d1, [x8]
     2d0:	fadd	d0, d0, d1
     2d4:	ldp	x29, x30, [sp], #16
     2d8:	ret
     2dc:	movi	d0, #0x0
     2e0:	ret
     2e4:	fadd	d0, d0, d1
     2e8:	fmov	d2, #2.000000000000000000e+00
     2ec:	fmul	d1, d0, d0
     2f0:	fmadd	d1, d0, d2, d1
     2f4:	fsqrt	d1, d1
     2f8:	fadd	d0, d0, d1
     2fc:	b	540 <pts_ieee754_log1p>

0000000000000300 <pts_ieee754_log>:
     300:	fmov	x9, d0
     304:	lsr	x8, x9, #32
     308:	cmp	w8, #0x100, lsl #12
     30c:	b.ge	33c <pts_ieee754_log+0x3c>  // b.tcont
     310:	and	w8, w8, #0x7fffffff
     314:	orr	w8, w8, w9
     318:	cbz	w8, 3cc <pts_ieee754_log+0xcc>
     31c:	tbnz	x9, #63, 490 <pts_ieee754_log+0x190>
     320:	mov	x8, #0x4350000000000000    	// #4850376798678024192
     324:	mov	w10, #0xffffffca            	// #-54
     328:	fmov	d1, x8
     32c:	fmul	d0, d0, d1
     330:	fmov	x8, d0
     334:	lsr	x8, x8, #32
     338:	b	340 <pts_ieee754_log+0x40>
     33c:	mov	w10, wzr
     340:	mov	w9, #0x7ff00000            	// #2146435072
     344:	cmp	w8, w9
     348:	b.lt	354 <pts_ieee754_log+0x54>  // b.tstop
     34c:	fadd	d0, d0, d0
     350:	ret
     354:	and	w9, w8, #0xfffff
     358:	fmov	x13, d0
     35c:	fmov	d0, #-1.000000000000000000e+00
     360:	add	w11, w9, #0x95, lsl #12
     364:	add	w10, w10, w8, asr #20
     368:	add	w11, w11, #0xf64
     36c:	and	w12, w11, #0x100000
     370:	and	x13, x13, #0xffffffff
     374:	add	w10, w10, w11, lsr #20
     378:	bfxil	w12, w8, #0, #20
     37c:	add	w8, w8, #0x2
     380:	and	w8, w8, #0xfffff
     384:	eor	w12, w12, #0x3ff00000
     388:	cmp	w8, #0x2
     38c:	sub	w8, w10, #0x3ff
     390:	orr	x12, x13, x12, lsl #32
     394:	fmov	d1, x12
     398:	fadd	d0, d1, d0
     39c:	b.hi	3d8 <pts_ieee754_log+0xd8>  // b.pmore
     3a0:	fcmp	d0, #0.0
     3a4:	b.ne	49c <pts_ieee754_log+0x19c>  // b.any
     3a8:	cbz	w8, 4fc <pts_ieee754_log+0x1fc>
     3ac:	scvtf	d0, w8
     3b0:	adrp	x8, 0 <pts_ieee754_acos>
     3b4:	ldr	d1, [x8]
     3b8:	adrp	x8, 0 <pts_ieee754_acos>
     3bc:	ldr	d2, [x8]
     3c0:	fmul	d1, d0, d1
     3c4:	fmadd	d0, d0, d2, d1
     3c8:	ret
     3cc:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
     3d0:	fmov	d0, x8
     3d4:	ret
     3d8:	fmov	d1, #2.000000000000000000e+00
     3dc:	adrp	x10, 0 <pts_ieee754_acos>
     3e0:	adrp	x11, 0 <pts_ieee754_acos>
     3e4:	ldr	d4, [x10]
     3e8:	ldr	d5, [x11]
     3ec:	adrp	x10, 0 <pts_ieee754_acos>
     3f0:	adrp	x11, 0 <pts_ieee754_acos>
     3f4:	adrp	x12, 0 <pts_ieee754_acos>
     3f8:	fadd	d1, d0, d1
     3fc:	ldr	d6, [x11]
     400:	ldr	d7, [x12]
     404:	mov	w11, #0xb851                	// #47185
     408:	movk	w11, #0x6, lsl #16
     40c:	fdiv	d1, d0, d1
     410:	fmul	d2, d1, d1
     414:	fmul	d3, d2, d2
     418:	fmadd	d4, d3, d5, d4
     41c:	ldr	d5, [x10]
     420:	adrp	x10, 0 <pts_ieee754_acos>
     424:	fmadd	d4, d3, d4, d5
     428:	ldr	d5, [x10]
     42c:	adrp	x10, 0 <pts_ieee754_acos>
     430:	fmadd	d5, d3, d6, d5
     434:	ldr	d6, [x10]
     438:	sub	w10, w9, #0x61, lsl #12
     43c:	sub	w10, w10, #0x47a
     440:	sub	w9, w11, w9
     444:	fmadd	d4, d3, d4, d7
     448:	orr	w9, w10, w9
     44c:	cmp	w9, #0x1
     450:	fmadd	d5, d3, d5, d6
     454:	fmul	d4, d2, d4
     458:	scvtf	d2, w8
     45c:	fmadd	d3, d3, d5, d4
     460:	b.lt	4d0 <pts_ieee754_log+0x1d0>  // b.tstop
     464:	fmov	d4, #5.000000000000000000e-01
     468:	fmul	d4, d0, d4
     46c:	fmul	d4, d0, d4
     470:	cbz	w8, 504 <pts_ieee754_log+0x204>
     474:	fadd	d3, d4, d3
     478:	adrp	x8, 0 <pts_ieee754_acos>
     47c:	fmul	d1, d1, d3
     480:	ldr	d3, [x8]
     484:	fmadd	d1, d2, d3, d1
     488:	fsub	d1, d4, d1
     48c:	b	4e8 <pts_ieee754_log+0x1e8>
     490:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     494:	fmov	d0, x8
     498:	ret
     49c:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     4a0:	fmov	d1, #5.000000000000000000e-01
     4a4:	fmul	d3, d0, d0
     4a8:	movk	x9, #0xbfd5, lsl #48
     4ac:	fmov	d2, x9
     4b0:	fmadd	d1, d0, d2, d1
     4b4:	fmul	d1, d3, d1
     4b8:	cbz	w8, 514 <pts_ieee754_log+0x214>
     4bc:	scvtf	d2, w8
     4c0:	adrp	x8, 0 <pts_ieee754_acos>
     4c4:	ldr	d3, [x8]
     4c8:	fmadd	d1, d2, d3, d1
     4cc:	b	4e8 <pts_ieee754_log+0x1e8>
     4d0:	cbz	w8, 51c <pts_ieee754_log+0x21c>
     4d4:	adrp	x8, 0 <pts_ieee754_acos>
     4d8:	fsub	d3, d0, d3
     4dc:	ldr	d4, [x8]
     4e0:	fmul	d4, d2, d4
     4e4:	fmadd	d1, d1, d3, d4
     4e8:	fsub	d0, d1, d0
     4ec:	adrp	x8, 0 <pts_ieee754_acos>
     4f0:	ldr	d1, [x8]
     4f4:	fnmsub	d0, d2, d1, d0
     4f8:	ret
     4fc:	movi	d0, #0x0
     500:	ret
     504:	fadd	d2, d4, d3
     508:	fnmsub	d1, d1, d2, d4
     50c:	fadd	d0, d0, d1
     510:	ret
     514:	fsub	d0, d0, d1
     518:	ret
     51c:	fsub	d2, d0, d3
     520:	fmsub	d0, d1, d2, d0
     524:	ret
     528:	nop
     52c:	nop
     530:	nop
     534:	nop
     538:	nop
     53c:	nop

0000000000000540 <pts_ieee754_log1p>:
     540:	fmov	x8, d0
     544:	mov	w10, #0x8279                	// #33401
     548:	movk	w10, #0x3fda, lsl #16
     54c:	lsr	x9, x8, #32
     550:	cmp	w9, w10
     554:	b.gt	588 <pts_ieee754_log1p+0x48>
     558:	ubfx	x10, x8, #32, #31
     55c:	lsr	w8, w10, #20
     560:	cmp	w8, #0x3ff
     564:	b.cc	59c <pts_ieee754_log1p+0x5c>  // b.lo, b.ul, b.last
     568:	fmov	d1, #-1.000000000000000000e+00
     56c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     570:	mov	x9, #0xfff0000000000000    	// #-4503599627370496
     574:	fcmp	d0, d1
     578:	fmov	d0, x8
     57c:	fmov	d1, x9
     580:	fcsel	d0, d1, d0, eq	// eq = none
     584:	ret
     588:	lsr	w8, w9, #20
     58c:	cmp	w8, #0x7ff
     590:	b.cc	5c8 <pts_ieee754_log1p+0x88>  // b.lo, b.ul, b.last
     594:	fadd	d0, d0, d0
     598:	ret
     59c:	lsr	w10, w10, #21
     5a0:	cmp	w10, #0x1f0
     5a4:	b.hi	5dc <pts_ieee754_log1p+0x9c>  // b.pmore
     5a8:	mov	x9, #0x4350000000000000    	// #4850376798678024192
     5ac:	fmov	d1, x9
     5b0:	fadd	d1, d0, d1
     5b4:	fcmp	d1, #0.0
     5b8:	b.le	770 <pts_ieee754_log1p+0x230>
     5bc:	cmp	w8, #0x3c9
     5c0:	b.cs	770 <pts_ieee754_log1p+0x230>  // b.hs, b.nlast
     5c4:	ret
     5c8:	lsr	w10, w9, #22
     5cc:	cmp	w10, #0x10c
     5d0:	b.ls	604 <pts_ieee754_log1p+0xc4>  // b.plast
     5d4:	movi	d1, #0x0
     5d8:	b	63c <pts_ieee754_log1p+0xfc>
     5dc:	sub	w8, w9, #0x1
     5e0:	mov	w9, #0xbec3                	// #48835
     5e4:	movk	w9, #0xbfd2, lsl #16
     5e8:	cmp	w8, w9
     5ec:	b.hi	604 <pts_ieee754_log1p+0xc4>  // b.pmore
     5f0:	fmov	d1, #5.000000000000000000e-01
     5f4:	mov	w8, wzr
     5f8:	fmul	d1, d0, d1
     5fc:	fmul	d2, d1, d0
     600:	b	69c <pts_ieee754_log1p+0x15c>
     604:	fmov	d1, #1.000000000000000000e+00
     608:	fmov	d3, #-1.000000000000000000e+00
     60c:	fadd	d2, d0, d1
     610:	fsub	d4, d0, d2
     614:	fadd	d3, d2, d3
     618:	fmov	x9, d2
     61c:	asr	x8, x9, #52
     620:	lsr	x9, x9, #32
     624:	fadd	d1, d4, d1
     628:	fsub	d0, d0, d3
     62c:	cmp	w8, #0x3ff
     630:	fcsel	d0, d1, d0, gt
     634:	fdiv	d1, d0, d2
     638:	fmov	d0, d2
     63c:	fmov	x10, d0
     640:	mov	w11, #0xa09d                	// #41117
     644:	and	w9, w9, #0xfffff
     648:	movk	w11, #0x6, lsl #16
     64c:	orr	w12, w9, #0x3fe00000
     650:	orr	w13, w9, #0x3ff00000
     654:	cmp	w9, w11
     658:	fmov	d0, #-1.000000000000000000e+00
     65c:	and	x10, x10, #0xffffffff
     660:	csel	w11, w12, w13, hi	// hi = pmore
     664:	orr	x10, x10, x11, lsl #32
     668:	sub	w11, w8, #0x3fe
     66c:	sub	w8, w8, #0x3ff
     670:	csel	w8, w11, w8, hi	// hi = pmore
     674:	fmov	d2, x10
     678:	mov	w10, #0x100000              	// #1048576
     67c:	sub	w10, w10, w9
     680:	lsr	w10, w10, #2
     684:	fadd	d0, d2, d0
     688:	fmov	d2, #5.000000000000000000e-01
     68c:	csel	w9, w10, w9, hi	// hi = pmore
     690:	fmul	d2, d0, d2
     694:	fmul	d2, d0, d2
     698:	cbz	w9, 734 <pts_ieee754_log1p+0x1f4>
     69c:	fmov	d3, #2.000000000000000000e+00
     6a0:	adrp	x9, 0 <pts_ieee754_acos>
     6a4:	adrp	x10, 0 <pts_ieee754_acos>
     6a8:	ldr	d5, [x9]
     6ac:	ldr	d6, [x10]
     6b0:	adrp	x9, 0 <pts_ieee754_acos>
     6b4:	fadd	d3, d0, d3
     6b8:	fdiv	d3, d0, d3
     6bc:	fmul	d4, d3, d3
     6c0:	fmadd	d5, d4, d6, d5
     6c4:	ldr	d6, [x9]
     6c8:	adrp	x9, 0 <pts_ieee754_acos>
     6cc:	fmadd	d5, d4, d5, d6
     6d0:	ldr	d6, [x9]
     6d4:	adrp	x9, 0 <pts_ieee754_acos>
     6d8:	fmadd	d5, d4, d5, d6
     6dc:	ldr	d6, [x9]
     6e0:	adrp	x9, 0 <pts_ieee754_acos>
     6e4:	fmadd	d5, d4, d5, d6
     6e8:	ldr	d6, [x9]
     6ec:	adrp	x9, 0 <pts_ieee754_acos>
     6f0:	fmadd	d5, d4, d5, d6
     6f4:	ldr	d6, [x9]
     6f8:	fmadd	d5, d4, d5, d6
     6fc:	fmul	d4, d4, d5
     700:	cbz	w8, 760 <pts_ieee754_log1p+0x220>
     704:	scvtf	d5, w8
     708:	adrp	x8, 0 <pts_ieee754_acos>
     70c:	fadd	d4, d2, d4
     710:	ldr	d6, [x8]
     714:	adrp	x8, 0 <pts_ieee754_acos>
     718:	fmadd	d1, d5, d6, d1
     71c:	fmadd	d1, d3, d4, d1
     720:	fsub	d1, d2, d1
     724:	fsub	d0, d1, d0
     728:	ldr	d1, [x8]
     72c:	fnmsub	d0, d5, d1, d0
     730:	ret
     734:	fcmp	d0, #0.0
     738:	b.ne	780 <pts_ieee754_log1p+0x240>  // b.any
     73c:	cbz	w8, 7c4 <pts_ieee754_log1p+0x284>
     740:	scvtf	d0, w8
     744:	adrp	x8, 0 <pts_ieee754_acos>
     748:	ldr	d2, [x8]
     74c:	adrp	x8, 0 <pts_ieee754_acos>
     750:	fmadd	d1, d0, d2, d1
     754:	ldr	d2, [x8]
     758:	fmadd	d0, d0, d2, d1
     75c:	ret
     760:	fadd	d1, d2, d4
     764:	fmsub	d1, d3, d1, d2
     768:	fsub	d0, d0, d1
     76c:	ret
     770:	fmul	d1, d0, d0
     774:	fmov	d2, #-5.000000000000000000e-01
     778:	fmadd	d0, d1, d2, d0
     77c:	ret
     780:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     784:	fmov	d3, #1.000000000000000000e+00
     788:	movk	x9, #0xbfe5, lsl #48
     78c:	fmov	d4, x9
     790:	fmadd	d3, d0, d4, d3
     794:	fmul	d2, d2, d3
     798:	cbz	w8, 7cc <pts_ieee754_log1p+0x28c>
     79c:	scvtf	d3, w8
     7a0:	adrp	x8, 0 <pts_ieee754_acos>
     7a4:	ldr	d4, [x8]
     7a8:	adrp	x8, 0 <pts_ieee754_acos>
     7ac:	fmadd	d1, d3, d4, d1
     7b0:	fsub	d1, d2, d1
     7b4:	fsub	d0, d1, d0
     7b8:	ldr	d1, [x8]
     7bc:	fnmsub	d0, d3, d1, d0
     7c0:	ret
     7c4:	movi	d0, #0x0
     7c8:	ret
     7cc:	fsub	d0, d0, d2
     7d0:	ret
     7d4:	nop
     7d8:	nop
     7dc:	nop

00000000000007e0 <pts_ieee754_asin>:
     7e0:	fmov	x10, d0
     7e4:	lsr	x8, x10, #32
     7e8:	ubfx	x9, x10, #32, #31
     7ec:	ubfx	w11, w8, #20, #11
     7f0:	cmp	w11, #0x3ff
     7f4:	b.cc	830 <pts_ieee754_asin+0x50>  // b.lo, b.ul, b.last
     7f8:	adrp	x8, 0 <pts_ieee754_acos>
     7fc:	ldr	d1, [x8]
     800:	adrp	x8, 0 <pts_ieee754_acos>
     804:	ldr	d2, [x8]
     808:	mov	w8, #0xc0100000            	// #-1072693248
     80c:	fmul	d1, d0, d1
     810:	add	w8, w9, w8
     814:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
     818:	orr	w8, w8, w10
     81c:	cmp	w8, #0x0
     820:	fmadd	d0, d0, d2, d1
     824:	fmov	d1, x9
     828:	fcsel	d0, d0, d1, eq	// eq = none
     82c:	ret
     830:	lsr	w10, w9, #21
     834:	cmp	w10, #0x1fe
     838:	b.hi	868 <pts_ieee754_asin+0x88>  // b.pmore
     83c:	lsr	w8, w9, #22
     840:	cmp	w8, #0xf8
     844:	b.hi	934 <pts_ieee754_asin+0x154>  // b.pmore
     848:	adrp	x8, 0 <pts_ieee754_acos>
     84c:	fmov	d3, #1.000000000000000000e+00
     850:	ldr	d1, [x8]
     854:	fadd	d2, d0, d1
     858:	movi	d1, #0x0
     85c:	fcmp	d2, d3
     860:	b.le	938 <pts_ieee754_asin+0x158>
     864:	ret
     868:	fabs	d0, d0
     86c:	fmov	d3, #1.000000000000000000e+00
     870:	adrp	x10, 0 <pts_ieee754_acos>
     874:	fmov	d1, #5.000000000000000000e-01
     878:	adrp	x11, 0 <pts_ieee754_acos>
     87c:	adrp	x12, 0 <pts_ieee754_acos>
     880:	ldr	d2, [x11]
     884:	adrp	x11, 0 <pts_ieee754_acos>
     888:	ldr	d6, [x12]
     88c:	ldr	d5, [x11]
     890:	adrp	x11, 0 <pts_ieee754_acos>
     894:	fsub	d0, d3, d0
     898:	fmul	d0, d0, d1
     89c:	ldr	d1, [x10]
     8a0:	adrp	x10, 0 <pts_ieee754_acos>
     8a4:	ldr	d4, [x10]
     8a8:	adrp	x10, 0 <pts_ieee754_acos>
     8ac:	fmadd	d2, d0, d2, d1
     8b0:	fsqrt	d1, d0
     8b4:	fmadd	d2, d0, d2, d4
     8b8:	ldr	d4, [x10]
     8bc:	adrp	x10, 0 <pts_ieee754_acos>
     8c0:	fmadd	d2, d0, d2, d4
     8c4:	fmadd	d4, d0, d6, d5
     8c8:	ldr	d5, [x10]
     8cc:	ldr	d6, [x11]
     8d0:	adrp	x10, 0 <pts_ieee754_acos>
     8d4:	fmadd	d2, d0, d2, d5
     8d8:	ldr	d5, [x10]
     8dc:	mov	x10, #0x5555555555555555    	// #6148914691236517205
     8e0:	fmadd	d4, d0, d4, d6
     8e4:	movk	x10, #0x3fc5, lsl #48
     8e8:	fmov	d6, x10
     8ec:	mov	w10, #0x3333                	// #13107
     8f0:	movk	w10, #0x3fef, lsl #16
     8f4:	cmp	w9, w10
     8f8:	fmadd	d2, d0, d2, d6
     8fc:	fmadd	d4, d0, d4, d5
     900:	fmul	d2, d0, d2
     904:	fmadd	d3, d0, d4, d3
     908:	b.cc	9a0 <pts_ieee754_asin+0x1c0>  // b.lo, b.ul, b.last
     90c:	fdiv	d0, d2, d3
     910:	adrp	x9, 0 <pts_ieee754_acos>
     914:	ldr	d2, [x9]
     918:	adrp	x9, 0 <pts_ieee754_acos>
     91c:	fmadd	d0, d1, d0, d1
     920:	fmov	d1, #2.000000000000000000e+00
     924:	fmadd	d0, d0, d1, d2
     928:	ldr	d1, [x9]
     92c:	fsub	d0, d1, d0
     930:	b	9e8 <pts_ieee754_asin+0x208>
     934:	fmul	d1, d0, d0
     938:	adrp	x8, 0 <pts_ieee754_acos>
     93c:	adrp	x9, 0 <pts_ieee754_acos>
     940:	ldr	d2, [x8]
     944:	ldr	d3, [x9]
     948:	adrp	x8, 0 <pts_ieee754_acos>
     94c:	add	x8, x8, #0x0
     950:	fmadd	d2, d1, d3, d2
     954:	ld1r	{v3.2d}, [x8]
     958:	adrp	x8, 0 <pts_ieee754_acos>
     95c:	mov	v3.d[0], v2.d[0]
     960:	ldr	q2, [x8]
     964:	adrp	x8, 0 <pts_ieee754_acos>
     968:	fmla	v2.2d, v3.2d, v1.d[0]
     96c:	ldr	q3, [x8]
     970:	adrp	x8, 0 <pts_ieee754_acos>
     974:	fmla	v3.2d, v2.2d, v1.d[0]
     978:	ldr	q2, [x8]
     97c:	adrp	x8, 0 <pts_ieee754_acos>
     980:	fmla	v2.2d, v3.2d, v1.d[0]
     984:	ldr	q3, [x8]
     988:	fmla	v3.2d, v2.2d, v1.d[0]
     98c:	fmul	d1, d1, d3
     990:	mov	d2, v3.d[1]
     994:	fdiv	d1, d1, d2
     998:	fmadd	d0, d1, d0, d0
     99c:	ret
     9a0:	fmov	x9, d1
     9a4:	fdiv	d2, d2, d3
     9a8:	fmov	d3, #2.000000000000000000e+00
     9ac:	and	x9, x9, #0xffffffff00000000
     9b0:	fmov	d4, x9
     9b4:	adrp	x9, 0 <pts_ieee754_acos>
     9b8:	fmsub	d0, d4, d4, d0
     9bc:	fadd	d5, d1, d4
     9c0:	fadd	d1, d1, d1
     9c4:	fdiv	d0, d0, d5
     9c8:	ldr	d5, [x9]
     9cc:	adrp	x9, 0 <pts_ieee754_acos>
     9d0:	fmsub	d0, d0, d3, d5
     9d4:	ldr	d5, [x9]
     9d8:	fmsub	d3, d4, d3, d5
     9dc:	fmsub	d0, d1, d2, d0
     9e0:	fadd	d0, d3, d0
     9e4:	fadd	d0, d0, d5
     9e8:	fneg	d1, d0
     9ec:	cmp	w8, #0x0
     9f0:	fcsel	d0, d0, d1, gt
     9f4:	ret
     9f8:	nop
     9fc:	nop

0000000000000a00 <pts_ieee754_asinh>:
     a00:	stp	x29, x30, [sp, #-32]!
     a04:	str	x19, [sp, #16]
     a08:	mov	x29, sp
     a0c:	fmov	x8, d0
     a10:	lsr	x19, x8, #32
     a14:	ubfx	w9, w19, #20, #11
     a18:	cmp	w9, #0x7ff
     a1c:	b.cc	a28 <pts_ieee754_asinh+0x28>  // b.lo, b.ul, b.last
     a20:	fadd	d0, d0, d0
     a24:	b	adc <pts_ieee754_asinh+0xdc>
     a28:	adrp	x9, 0 <pts_ieee754_acos>
     a2c:	fmov	d2, #1.000000000000000000e+00
     a30:	ubfx	x8, x8, #32, #31
     a34:	ldr	d1, [x9]
     a38:	fadd	d1, d0, d1
     a3c:	fcmp	d1, d2
     a40:	b.le	a50 <pts_ieee754_asinh+0x50>
     a44:	lsr	w9, w8, #20
     a48:	cmp	w9, #0x3e3
     a4c:	b.cc	adc <pts_ieee754_asinh+0xdc>  // b.lo, b.ul, b.last
     a50:	mov	w9, #0x1                   	// #1
     a54:	movk	w9, #0x41b0, lsl #16
     a58:	cmp	w8, w9
     a5c:	b.cc	a78 <pts_ieee754_asinh+0x78>  // b.lo, b.ul, b.last
     a60:	fabs	d0, d0
     a64:	bl	300 <pts_ieee754_log>
     a68:	adrp	x8, 0 <pts_ieee754_acos>
     a6c:	ldr	d1, [x8]
     a70:	fadd	d0, d0, d1
     a74:	b	ad0 <pts_ieee754_asinh+0xd0>
     a78:	mov	w9, #0x1                   	// #1
     a7c:	movk	w9, #0x4000, lsl #16
     a80:	cmp	w8, w9
     a84:	b.cc	ab0 <pts_ieee754_asinh+0xb0>  // b.lo, b.ul, b.last
     a88:	fmov	d1, #1.000000000000000000e+00
     a8c:	fmadd	d2, d0, d0, d1
     a90:	fabs	d0, d0
     a94:	fsqrt	d2, d2
     a98:	fadd	d2, d0, d2
     a9c:	fdiv	d1, d1, d2
     aa0:	fmov	d2, #2.000000000000000000e+00
     aa4:	fmadd	d0, d0, d2, d1
     aa8:	bl	300 <pts_ieee754_log>
     aac:	b	ad0 <pts_ieee754_asinh+0xd0>
     ab0:	fmul	d1, d0, d0
     ab4:	fabs	d0, d0
     ab8:	fadd	d3, d1, d2
     abc:	fsqrt	d3, d3
     ac0:	fadd	d2, d3, d2
     ac4:	fdiv	d1, d1, d2
     ac8:	fadd	d0, d0, d1
     acc:	bl	540 <pts_ieee754_log1p>
     ad0:	fneg	d1, d0
     ad4:	cmp	w19, #0x0
     ad8:	fcsel	d0, d0, d1, gt
     adc:	ldr	x19, [sp, #16]
     ae0:	ldp	x29, x30, [sp], #32
     ae4:	ret
     ae8:	nop
     aec:	nop
     af0:	nop
     af4:	nop
     af8:	nop
     afc:	nop

0000000000000b00 <pts_ieee754_atan>:
     b00:	fmov	x8, d0
     b04:	lsr	x9, x8, #32
     b08:	ubfx	x11, x8, #32, #31
     b0c:	ubfx	w10, w9, #20, #11
     b10:	cmp	w10, #0x441
     b14:	b.cc	b3c <pts_ieee754_atan+0x3c>  // b.lo, b.ul, b.last
     b18:	mov	w10, #0x7ff00000            	// #2146435072
     b1c:	cmp	w11, w10
     b20:	b.hi	b34 <pts_ieee754_atan+0x34>  // b.pmore
     b24:	cbz	w8, ba4 <pts_ieee754_atan+0xa4>
     b28:	mov	w8, #0x7ff00000            	// #2146435072
     b2c:	cmp	w11, w8
     b30:	b.ne	ba4 <pts_ieee754_atan+0xa4>  // b.any
     b34:	fadd	d0, d0, d0
     b38:	ret
     b3c:	lsr	w9, w11, #18
     b40:	cmp	w9, #0xff6
     b44:	b.hi	b74 <pts_ieee754_atan+0x74>  // b.pmore
     b48:	adrp	x10, 0 <pts_ieee754_acos>
     b4c:	fmov	d2, #1.000000000000000000e+00
     b50:	ldr	d1, [x10]
     b54:	mov	w10, #0xffffffff            	// #-1
     b58:	fadd	d1, d0, d1
     b5c:	fcmp	d1, d2
     b60:	b.le	c10 <pts_ieee754_atan+0x110>
     b64:	lsr	w11, w11, #22
     b68:	cmp	w11, #0xf9
     b6c:	b.cs	c10 <pts_ieee754_atan+0x110>  // b.hs, b.nlast
     b70:	ret
     b74:	fabs	d0, d0
     b78:	mov	w10, #0x3ff2ffff            	// #1072889855
     b7c:	cmp	w11, w10
     b80:	b.hi	bc4 <pts_ieee754_atan+0xc4>  // b.pmore
     b84:	fmov	d1, #-1.000000000000000000e+00
     b88:	mov	w10, #0x3fe5ffff            	// #1072037887
     b8c:	cmp	w11, w10
     b90:	b.hi	bf0 <pts_ieee754_atan+0xf0>  // b.pmore
     b94:	fmov	d2, #2.000000000000000000e+00
     b98:	mov	x10, xzr
     b9c:	fmadd	d1, d0, d2, d1
     ba0:	b	bfc <pts_ieee754_atan+0xfc>
     ba4:	adrp	x8, 0 <pts_ieee754_acos>
     ba8:	cmp	w9, #0x1
     bac:	ldr	d0, [x8]
     bb0:	b.lt	cec <pts_ieee754_atan+0x1ec>  // b.tstop
     bb4:	adrp	x8, 0 <pts_ieee754_acos>
     bb8:	ldr	d1, [x8]
     bbc:	fadd	d0, d0, d1
     bc0:	ret
     bc4:	mov	w10, #0x7fff                	// #32767
     bc8:	movk	w10, #0x4003, lsl #16
     bcc:	cmp	w11, w10
     bd0:	b.hi	c04 <pts_ieee754_atan+0x104>  // b.pmore
     bd4:	fmov	d1, #-1.500000000000000000e+00
     bd8:	fmov	d2, #1.000000000000000000e+00
     bdc:	mov	w10, #0x2                   	// #2
     be0:	fmov	d3, #1.500000000000000000e+00
     be4:	fadd	d1, d0, d1
     be8:	fmadd	d0, d0, d3, d2
     bec:	b	c0c <pts_ieee754_atan+0x10c>
     bf0:	fmov	d2, #1.000000000000000000e+00
     bf4:	fadd	d1, d0, d1
     bf8:	mov	w10, #0x1                   	// #1
     bfc:	fadd	d0, d0, d2
     c00:	b	c0c <pts_ieee754_atan+0x10c>
     c04:	fmov	d1, #-1.000000000000000000e+00
     c08:	mov	w10, #0x3                   	// #3
     c0c:	fdiv	d0, d1, d0
     c10:	fmul	d1, d0, d0
     c14:	adrp	x11, 0 <pts_ieee754_acos>
     c18:	adrp	x12, 0 <pts_ieee754_acos>
     c1c:	ldr	d3, [x11]
     c20:	ldr	d4, [x12]
     c24:	adrp	x11, 0 <pts_ieee754_acos>
     c28:	adrp	x12, 0 <pts_ieee754_acos>
     c2c:	adrp	x13, 0 <pts_ieee754_acos>
     c30:	cmp	w9, #0xff6
     c34:	ldr	d5, [x12]
     c38:	ldr	d6, [x13]
     c3c:	adrp	x12, 0 <pts_ieee754_acos>
     c40:	fmul	d2, d1, d1
     c44:	fmadd	d3, d2, d4, d3
     c48:	ldr	d4, [x11]
     c4c:	adrp	x11, 0 <pts_ieee754_acos>
     c50:	fmadd	d3, d2, d3, d4
     c54:	fmadd	d4, d2, d6, d5
     c58:	ldr	d5, [x11]
     c5c:	ldr	d6, [x12]
     c60:	adrp	x11, 0 <pts_ieee754_acos>
     c64:	adrp	x12, 0 <pts_ieee754_acos>
     c68:	fmadd	d3, d2, d3, d5
     c6c:	fmadd	d4, d2, d4, d6
     c70:	ldr	d5, [x11]
     c74:	ldr	d6, [x12]
     c78:	adrp	x11, 0 <pts_ieee754_acos>
     c7c:	adrp	x12, 0 <pts_ieee754_acos>
     c80:	fmadd	d3, d2, d3, d5
     c84:	fmadd	d4, d2, d4, d6
     c88:	ldr	d5, [x11]
     c8c:	ldr	d6, [x12]
     c90:	fmadd	d3, d2, d3, d5
     c94:	fmadd	d4, d2, d4, d6
     c98:	fmul	d1, d1, d3
     c9c:	fmul	d2, d2, d4
     ca0:	b.hi	cb0 <pts_ieee754_atan+0x1b0>  // b.pmore
     ca4:	fadd	d1, d2, d1
     ca8:	fmsub	d0, d0, d1, d0
     cac:	ret
     cb0:	lsl	x9, x10, #3
     cb4:	fadd	d1, d2, d1
     cb8:	adrp	x10, 0 <pts_ieee754_acos>
     cbc:	add	x10, x10, #0x0
     cc0:	cmp	x8, #0x0
     cc4:	ldr	d2, [x10, x9]
     cc8:	adrp	x10, 0 <pts_ieee754_acos>
     ccc:	add	x10, x10, #0x0
     cd0:	fnmsub	d1, d0, d1, d2
     cd4:	fsub	d0, d1, d0
     cd8:	ldr	d1, [x10, x9]
     cdc:	fsub	d0, d1, d0
     ce0:	fneg	d1, d0
     ce4:	fcsel	d0, d1, d0, lt	// lt = tstop
     ce8:	ret
     cec:	adrp	x8, 0 <pts_ieee754_acos>
     cf0:	ldr	d1, [x8]
     cf4:	fsub	d0, d1, d0
     cf8:	ret
     cfc:	nop

0000000000000d00 <pts_ieee754_atan2>:
     d00:	stp	x29, x30, [sp, #-32]!
     d04:	str	x19, [sp, #16]
     d08:	mov	x29, sp
     d0c:	fmov	x8, d1
     d10:	mov	w10, #0x7ff00000            	// #2146435072
     d14:	ubfx	x9, x8, #32, #31
     d18:	cmp	w8, #0x0
     d1c:	cset	w11, ne	// ne = any
     d20:	orr	w11, w9, w11
     d24:	cmp	w11, w10
     d28:	b.hi	d50 <pts_ieee754_atan2+0x50>  // b.pmore
     d2c:	fmov	x10, d0
     d30:	mov	w13, #0x1                   	// #1
     d34:	movk	w13, #0x7ff0, lsl #16
     d38:	ubfx	x11, x10, #32, #31
     d3c:	cmp	w10, #0x0
     d40:	cset	w12, ne	// ne = any
     d44:	orr	w12, w11, w12
     d48:	cmp	w12, w13
     d4c:	b.cc	d60 <pts_ieee754_atan2+0x60>  // b.lo, b.ul, b.last
     d50:	fadd	d0, d0, d1
     d54:	ldr	x19, [sp, #16]
     d58:	ldp	x29, x30, [sp], #32
     d5c:	ret
     d60:	lsr	x12, x8, #32
     d64:	mov	w13, #0xc0100000            	// #-1072693248
     d68:	add	w13, w12, w13
     d6c:	orr	w13, w13, w8
     d70:	cbz	w13, dc8 <pts_ieee754_atan2+0xc8>
     d74:	lsr	w13, w12, #30
     d78:	lsr	x12, x10, #32
     d7c:	and	w19, w13, #0x2
     d80:	orr	w13, w11, w10
     d84:	bfxil	w19, w12, #31, #1
     d88:	cbz	w13, dd4 <pts_ieee754_atan2+0xd4>
     d8c:	orr	w13, w9, w8
     d90:	cbz	w13, e04 <pts_ieee754_atan2+0x104>
     d94:	mov	w13, #0x7ff00000            	// #2146435072
     d98:	cmp	w9, w13
     d9c:	b.ne	dfc <pts_ieee754_atan2+0xfc>  // b.any
     da0:	cmp	w11, w13
     da4:	b.ne	e2c <pts_ieee754_atan2+0x12c>  // b.any
     da8:	adrp	x8, 0 <pts_ieee754_acos>
     dac:	cmp	w19, #0x1
     db0:	b.gt	e78 <pts_ieee754_atan2+0x178>
     db4:	cbnz	w19, f00 <pts_ieee754_atan2+0x200>
     db8:	adrp	x9, 0 <pts_ieee754_acos>
     dbc:	ldr	d0, [x8]
     dc0:	ldr	d1, [x9]
     dc4:	b	d50 <pts_ieee754_atan2+0x50>
     dc8:	ldr	x19, [sp, #16]
     dcc:	ldp	x29, x30, [sp], #32
     dd0:	b	b00 <pts_ieee754_atan>
     dd4:	cmp	w19, #0x2
     dd8:	b.cc	d54 <pts_ieee754_atan2+0x54>  // b.lo, b.ul, b.last
     ddc:	cmp	w19, #0x3
     de0:	b.ne	e98 <pts_ieee754_atan2+0x198>  // b.any
     de4:	adrp	x8, 0 <pts_ieee754_acos>
     de8:	adrp	x9, 0 <pts_ieee754_acos>
     dec:	ldr	d0, [x8]
     df0:	ldr	d1, [x9]
     df4:	fsub	d0, d1, d0
     df8:	b	d54 <pts_ieee754_atan2+0x54>
     dfc:	cmp	w11, w13
     e00:	b.ne	e48 <pts_ieee754_atan2+0x148>  // b.any
     e04:	adrp	x8, 0 <pts_ieee754_acos>
     e08:	ldr	d0, [x8]
     e0c:	tbnz	x10, #63, e1c <pts_ieee754_atan2+0x11c>
     e10:	adrp	x8, 0 <pts_ieee754_acos>
     e14:	ldr	d1, [x8]
     e18:	b	d50 <pts_ieee754_atan2+0x50>
     e1c:	adrp	x8, 0 <pts_ieee754_acos>
     e20:	ldr	d1, [x8]
     e24:	fsub	d0, d1, d0
     e28:	b	d54 <pts_ieee754_atan2+0x54>
     e2c:	cmp	w19, #0x1
     e30:	b.gt	e90 <pts_ieee754_atan2+0x190>
     e34:	movi	d0, #0x0
     e38:	cbz	w19, d54 <pts_ieee754_atan2+0x54>
     e3c:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
     e40:	fmov	d0, x8
     e44:	b	d54 <pts_ieee754_atan2+0x54>
     e48:	sub	w9, w11, w9
     e4c:	asr	w9, w9, #20
     e50:	cmp	w9, #0x3d
     e54:	b.lt	eac <pts_ieee754_atan2+0x1ac>  // b.tstop
     e58:	adrp	x8, 0 <pts_ieee754_acos>
     e5c:	adrp	x9, 0 <pts_ieee754_acos>
     e60:	fmov	d0, #5.000000000000000000e-01
     e64:	ldr	d1, [x8]
     e68:	ldr	d2, [x9]
     e6c:	lsr	w19, w12, #31
     e70:	fmadd	d2, d1, d0, d2
     e74:	b	ecc <pts_ieee754_atan2+0x1cc>
     e78:	cmp	w19, #0x2
     e7c:	b.ne	f14 <pts_ieee754_atan2+0x214>  // b.any
     e80:	adrp	x9, 0 <pts_ieee754_acos>
     e84:	ldr	d0, [x8]
     e88:	ldr	d1, [x9]
     e8c:	b	d50 <pts_ieee754_atan2+0x50>
     e90:	cmp	w19, #0x2
     e94:	b.ne	de4 <pts_ieee754_atan2+0xe4>  // b.any
     e98:	adrp	x8, 0 <pts_ieee754_acos>
     e9c:	adrp	x9, 0 <pts_ieee754_acos>
     ea0:	ldr	d0, [x8]
     ea4:	ldr	d1, [x9]
     ea8:	b	d50 <pts_ieee754_atan2+0x50>
     eac:	tbz	x8, #63, ebc <pts_ieee754_atan2+0x1bc>
     eb0:	movi	d2, #0x0
     eb4:	cmn	w9, #0x3c
     eb8:	b.lt	ecc <pts_ieee754_atan2+0x1cc>  // b.tstop
     ebc:	fdiv	d0, d0, d1
     ec0:	fabs	d0, d0
     ec4:	bl	b00 <pts_ieee754_atan>
     ec8:	fmov	d2, d0
     ecc:	cbz	w19, f28 <pts_ieee754_atan2+0x228>
     ed0:	cmp	w19, #0x2
     ed4:	b.eq	ee8 <pts_ieee754_atan2+0x1e8>  // b.none
     ed8:	cmp	w19, #0x1
     edc:	b.ne	f30 <pts_ieee754_atan2+0x230>  // b.any
     ee0:	fneg	d0, d2
     ee4:	b	d54 <pts_ieee754_atan2+0x54>
     ee8:	adrp	x8, 0 <pts_ieee754_acos>
     eec:	ldr	d0, [x8]
     ef0:	adrp	x8, 0 <pts_ieee754_acos>
     ef4:	ldr	d1, [x8]
     ef8:	fsub	d0, d0, d2
     efc:	b	d50 <pts_ieee754_atan2+0x50>
     f00:	adrp	x9, 0 <pts_ieee754_acos>
     f04:	ldr	d0, [x8]
     f08:	ldr	d1, [x9]
     f0c:	fsub	d0, d1, d0
     f10:	b	d54 <pts_ieee754_atan2+0x54>
     f14:	adrp	x9, 0 <pts_ieee754_acos>
     f18:	ldr	d0, [x8]
     f1c:	ldr	d1, [x9]
     f20:	fsub	d0, d1, d0
     f24:	b	d54 <pts_ieee754_atan2+0x54>
     f28:	fmov	d0, d2
     f2c:	b	d54 <pts_ieee754_atan2+0x54>
     f30:	adrp	x8, 0 <pts_ieee754_acos>
     f34:	ldr	d0, [x8]
     f38:	adrp	x8, 0 <pts_ieee754_acos>
     f3c:	ldr	d1, [x8]
     f40:	fsub	d0, d2, d0
     f44:	b	d50 <pts_ieee754_atan2+0x50>
     f48:	nop
     f4c:	nop
     f50:	nop
     f54:	nop
     f58:	nop
     f5c:	nop

0000000000000f60 <pts_ieee754_cos>:
     f60:	sub	sp, sp, #0x20
     f64:	stp	x29, x30, [sp, #16]
     f68:	add	x29, sp, #0x10
     f6c:	fmov	x8, d0
     f70:	mov	w9, #0x21fb                	// #8699
     f74:	movk	w9, #0x3fe9, lsl #16
     f78:	ubfx	x8, x8, #32, #31
     f7c:	cmp	w8, w9
     f80:	b.hi	101c <pts_ieee754_cos+0xbc>  // b.pmore
     f84:	lsr	w9, w8, #22
     f88:	cmp	w9, #0xf8
     f8c:	b.hi	f9c <pts_ieee754_cos+0x3c>  // b.pmore
     f90:	fcvtzs	w9, d0
     f94:	fmov	d1, #1.000000000000000000e+00
     f98:	cbz	w9, 131c <pts_ieee754_cos+0x3bc>
     f9c:	fmul	d1, d0, d0
     fa0:	adrp	x9, 0 <pts_ieee754_acos>
     fa4:	adrp	x10, 0 <pts_ieee754_acos>
     fa8:	ldr	d2, [x9]
     fac:	ldr	d3, [x10]
     fb0:	adrp	x9, 0 <pts_ieee754_acos>
     fb4:	fmadd	d2, d1, d3, d2
     fb8:	ldr	d3, [x9]
     fbc:	adrp	x9, 0 <pts_ieee754_acos>
     fc0:	fmadd	d2, d1, d2, d3
     fc4:	ldr	d3, [x9]
     fc8:	adrp	x9, 0 <pts_ieee754_acos>
     fcc:	fmadd	d2, d1, d2, d3
     fd0:	ldr	d3, [x9]
     fd4:	adrp	x9, 0 <pts_ieee754_acos>
     fd8:	fmadd	d2, d1, d2, d3
     fdc:	ldr	d3, [x9]
     fe0:	mov	w9, #0x3333                	// #13107
     fe4:	movk	w9, #0x3fd3, lsl #16
     fe8:	cmp	w8, w9
     fec:	fmadd	d2, d1, d2, d3
     ff0:	fmul	d2, d1, d2
     ff4:	b.cs	10e4 <pts_ieee754_cos+0x184>  // b.hs, b.nlast
     ff8:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
     ffc:	fmov	d3, x8
    1000:	fmul	d0, d0, d3
    1004:	fmadd	d0, d1, d2, d0
    1008:	fmov	d2, #-5.000000000000000000e-01
    100c:	fmadd	d0, d1, d2, d0
    1010:	fmov	d1, #1.000000000000000000e+00
    1014:	fadd	d1, d0, d1
    1018:	b	131c <pts_ieee754_cos+0x3bc>
    101c:	lsr	w8, w8, #20
    1020:	cmp	w8, #0x7ff
    1024:	b.cc	1030 <pts_ieee754_cos+0xd0>  // b.lo, b.ul, b.last
    1028:	fsub	d1, d0, d0
    102c:	b	131c <pts_ieee754_cos+0x3bc>
    1030:	mov	x0, sp
    1034:	bl	1380 <__ieee754_rem_pio2>
    1038:	ldr	d0, [sp]
    103c:	and	w8, w0, #0x3
    1040:	cmp	w8, #0x2
    1044:	b.eq	11b0 <pts_ieee754_cos+0x250>  // b.none
    1048:	cmp	w8, #0x1
    104c:	b.eq	112c <pts_ieee754_cos+0x1cc>  // b.none
    1050:	cbnz	w8, 1254 <pts_ieee754_cos+0x2f4>
    1054:	fmov	x8, d0
    1058:	ldr	d2, [sp, #8]
    105c:	lsr	x9, x8, #32
    1060:	ubfx	w9, w9, #22, #9
    1064:	cmp	w9, #0xf8
    1068:	b.hi	1078 <pts_ieee754_cos+0x118>  // b.pmore
    106c:	fcvtzs	w9, d0
    1070:	fmov	d1, #1.000000000000000000e+00
    1074:	cbz	w9, 131c <pts_ieee754_cos+0x3bc>
    1078:	fmul	d1, d0, d0
    107c:	adrp	x9, 0 <pts_ieee754_acos>
    1080:	adrp	x10, 0 <pts_ieee754_acos>
    1084:	ldr	d3, [x9]
    1088:	ldr	d4, [x10]
    108c:	adrp	x9, 0 <pts_ieee754_acos>
    1090:	ubfx	x8, x8, #32, #31
    1094:	fmadd	d3, d1, d4, d3
    1098:	ldr	d4, [x9]
    109c:	adrp	x9, 0 <pts_ieee754_acos>
    10a0:	fmadd	d3, d1, d3, d4
    10a4:	ldr	d4, [x9]
    10a8:	adrp	x9, 0 <pts_ieee754_acos>
    10ac:	fmadd	d3, d1, d3, d4
    10b0:	ldr	d4, [x9]
    10b4:	adrp	x9, 0 <pts_ieee754_acos>
    10b8:	fmadd	d3, d1, d3, d4
    10bc:	ldr	d4, [x9]
    10c0:	mov	w9, #0x3333                	// #13107
    10c4:	movk	w9, #0x3fd3, lsl #16
    10c8:	cmp	w8, w9
    10cc:	fmadd	d3, d1, d3, d4
    10d0:	fmul	d3, d1, d3
    10d4:	b.cs	132c <pts_ieee754_cos+0x3cc>  // b.hs, b.nlast
    10d8:	fmul	d0, d0, d2
    10dc:	fnmsub	d0, d1, d3, d0
    10e0:	b	1008 <pts_ieee754_cos+0xa8>
    10e4:	sub	w9, w8, #0x200, lsl #12
    10e8:	mov	x11, #0x8000000000000000    	// #-9223372036854775808
    10ec:	fmov	d3, #2.812500000000000000e-01
    10f0:	lsl	x9, x9, #32
    10f4:	fmov	d5, x11
    10f8:	mov	w10, #0x3fe90000            	// #1072234496
    10fc:	cmp	w8, w10
    1100:	fmov	d4, x9
    1104:	fmul	d0, d0, d5
    1108:	fcsel	d3, d3, d4, hi	// hi = pmore
    110c:	fmov	d4, #5.000000000000000000e-01
    1110:	fmadd	d0, d1, d2, d0
    1114:	fnmsub	d4, d1, d4, d3
    1118:	fmov	d1, #1.000000000000000000e+00
    111c:	fsub	d1, d1, d3
    1120:	fsub	d0, d0, d4
    1124:	fadd	d1, d1, d0
    1128:	b	131c <pts_ieee754_cos+0x3bc>
    112c:	fmov	x8, d0
    1130:	ubfx	x8, x8, #54, #9
    1134:	cmp	x8, #0xf8
    1138:	b.hi	1144 <pts_ieee754_cos+0x1e4>  // b.pmore
    113c:	fcvtzs	w8, d0
    1140:	cbz	w8, 11a8 <pts_ieee754_cos+0x248>
    1144:	fmul	d1, d0, d0
    1148:	adrp	x8, 0 <pts_ieee754_acos>
    114c:	adrp	x9, 0 <pts_ieee754_acos>
    1150:	ldr	d2, [x8]
    1154:	ldr	d3, [x9]
    1158:	adrp	x8, 0 <pts_ieee754_acos>
    115c:	ldr	d5, [sp, #8]
    1160:	fmadd	d2, d1, d3, d2
    1164:	ldr	d3, [x8]
    1168:	adrp	x8, 0 <pts_ieee754_acos>
    116c:	fmul	d4, d0, d1
    1170:	fmadd	d2, d1, d2, d3
    1174:	ldr	d3, [x8]
    1178:	adrp	x8, 0 <pts_ieee754_acos>
    117c:	fmadd	d2, d1, d2, d3
    1180:	ldr	d3, [x8]
    1184:	adrp	x8, 0 <pts_ieee754_acos>
    1188:	fmadd	d2, d1, d2, d3
    118c:	fmov	d3, #5.000000000000000000e-01
    1190:	fmul	d2, d4, d2
    1194:	fnmsub	d2, d5, d3, d2
    1198:	fnmsub	d1, d1, d2, d5
    119c:	ldr	d2, [x8]
    11a0:	fmadd	d1, d4, d2, d1
    11a4:	fsub	d0, d0, d1
    11a8:	fneg	d1, d0
    11ac:	b	131c <pts_ieee754_cos+0x3bc>
    11b0:	fmov	x8, d0
    11b4:	ldr	d1, [sp, #8]
    11b8:	lsr	x9, x8, #32
    11bc:	ubfx	w9, w9, #22, #9
    11c0:	cmp	w9, #0xf8
    11c4:	b.hi	11d4 <pts_ieee754_cos+0x274>  // b.pmore
    11c8:	fcvtzs	w9, d0
    11cc:	fmov	d2, #1.000000000000000000e+00
    11d0:	cbz	w9, 1318 <pts_ieee754_cos+0x3b8>
    11d4:	fmul	d2, d0, d0
    11d8:	adrp	x9, 0 <pts_ieee754_acos>
    11dc:	adrp	x10, 0 <pts_ieee754_acos>
    11e0:	ldr	d3, [x9]
    11e4:	ldr	d4, [x10]
    11e8:	adrp	x9, 0 <pts_ieee754_acos>
    11ec:	ubfx	x8, x8, #32, #31
    11f0:	fmadd	d3, d2, d4, d3
    11f4:	ldr	d4, [x9]
    11f8:	adrp	x9, 0 <pts_ieee754_acos>
    11fc:	fmadd	d3, d2, d3, d4
    1200:	ldr	d4, [x9]
    1204:	adrp	x9, 0 <pts_ieee754_acos>
    1208:	fmadd	d3, d2, d3, d4
    120c:	ldr	d4, [x9]
    1210:	adrp	x9, 0 <pts_ieee754_acos>
    1214:	fmadd	d3, d2, d3, d4
    1218:	ldr	d4, [x9]
    121c:	mov	w9, #0x3333                	// #13107
    1220:	movk	w9, #0x3fd3, lsl #16
    1224:	cmp	w8, w9
    1228:	fmadd	d3, d2, d3, d4
    122c:	fmul	d3, d2, d3
    1230:	b.cs	12dc <pts_ieee754_cos+0x37c>  // b.hs, b.nlast
    1234:	fmul	d0, d0, d1
    1238:	fmov	d1, #-5.000000000000000000e-01
    123c:	fnmsub	d0, d2, d3, d0
    1240:	fmadd	d0, d2, d1, d0
    1244:	fmov	d1, #1.000000000000000000e+00
    1248:	fadd	d2, d0, d1
    124c:	fneg	d1, d2
    1250:	b	131c <pts_ieee754_cos+0x3bc>
    1254:	fmov	x8, d0
    1258:	ubfx	x8, x8, #54, #9
    125c:	cmp	x8, #0xf8
    1260:	b.hi	1274 <pts_ieee754_cos+0x314>  // b.pmore
    1264:	fcvtzs	w8, d0
    1268:	cbnz	w8, 1274 <pts_ieee754_cos+0x314>
    126c:	fmov	d1, d0
    1270:	b	131c <pts_ieee754_cos+0x3bc>
    1274:	fmul	d1, d0, d0
    1278:	adrp	x8, 0 <pts_ieee754_acos>
    127c:	adrp	x9, 0 <pts_ieee754_acos>
    1280:	ldr	d2, [x8]
    1284:	ldr	d3, [x9]
    1288:	adrp	x8, 0 <pts_ieee754_acos>
    128c:	ldr	d5, [sp, #8]
    1290:	fmadd	d2, d1, d3, d2
    1294:	ldr	d3, [x8]
    1298:	adrp	x8, 0 <pts_ieee754_acos>
    129c:	fmul	d4, d0, d1
    12a0:	fmadd	d2, d1, d2, d3
    12a4:	ldr	d3, [x8]
    12a8:	adrp	x8, 0 <pts_ieee754_acos>
    12ac:	fmadd	d2, d1, d2, d3
    12b0:	ldr	d3, [x8]
    12b4:	adrp	x8, 0 <pts_ieee754_acos>
    12b8:	fmadd	d2, d1, d2, d3
    12bc:	fmov	d3, #5.000000000000000000e-01
    12c0:	fmul	d2, d4, d2
    12c4:	fnmsub	d2, d5, d3, d2
    12c8:	fnmsub	d1, d1, d2, d5
    12cc:	ldr	d2, [x8]
    12d0:	fmadd	d1, d4, d2, d1
    12d4:	fsub	d1, d0, d1
    12d8:	b	131c <pts_ieee754_cos+0x3bc>
    12dc:	sub	w9, w8, #0x200, lsl #12
    12e0:	fmov	d4, #2.812500000000000000e-01
    12e4:	mov	w10, #0x3fe90000            	// #1072234496
    12e8:	lsl	x9, x9, #32
    12ec:	cmp	w8, w10
    12f0:	fmul	d0, d0, d1
    12f4:	fmov	d1, #5.000000000000000000e-01
    12f8:	fmov	d5, x9
    12fc:	fnmsub	d0, d2, d3, d0
    1300:	fcsel	d4, d4, d5, hi	// hi = pmore
    1304:	fnmsub	d1, d2, d1, d4
    1308:	fmov	d2, #1.000000000000000000e+00
    130c:	fsub	d2, d2, d4
    1310:	fsub	d0, d0, d1
    1314:	fadd	d2, d2, d0
    1318:	fneg	d1, d2
    131c:	fmov	d0, d1
    1320:	ldp	x29, x30, [sp, #16]
    1324:	add	sp, sp, #0x20
    1328:	ret
    132c:	sub	w9, w8, #0x200, lsl #12
    1330:	fmov	d4, #2.812500000000000000e-01
    1334:	mov	w10, #0x3fe90000            	// #1072234496
    1338:	lsl	x9, x9, #32
    133c:	cmp	w8, w10
    1340:	fmul	d0, d0, d2
    1344:	fmov	d2, #5.000000000000000000e-01
    1348:	fmov	d5, x9
    134c:	fnmsub	d0, d1, d3, d0
    1350:	fcsel	d4, d4, d5, hi	// hi = pmore
    1354:	fnmsub	d2, d1, d2, d4
    1358:	fmov	d1, #1.000000000000000000e+00
    135c:	fsub	d1, d1, d4
    1360:	fsub	d0, d0, d2
    1364:	b	1124 <pts_ieee754_cos+0x1c4>
    1368:	nop
    136c:	nop
    1370:	nop
    1374:	nop
    1378:	nop
    137c:	nop

0000000000001380 <__ieee754_rem_pio2>:
    1380:	str	d14, [sp, #-160]!
    1384:	stp	d13, d12, [sp, #16]
    1388:	stp	d11, d10, [sp, #32]
    138c:	stp	d9, d8, [sp, #48]
    1390:	stp	x29, x30, [sp, #64]
    1394:	stp	x28, x27, [sp, #80]
    1398:	stp	x26, x25, [sp, #96]
    139c:	stp	x24, x23, [sp, #112]
    13a0:	stp	x22, x21, [sp, #128]
    13a4:	stp	x20, x19, [sp, #144]
    13a8:	add	x29, sp, #0x40
    13ac:	sub	sp, sp, #0x290
    13b0:	fmov	x6, d0
    13b4:	mov	w9, #0x21fb                	// #8699
    13b8:	mov	x5, x0
    13bc:	movk	w9, #0x3fe9, lsl #16
    13c0:	ubfx	x8, x6, #32, #31
    13c4:	cmp	w8, w9
    13c8:	b.hi	13dc <__ieee754_rem_pio2+0x5c>  // b.pmore
    13cc:	mov	w0, wzr
    13d0:	str	d0, [x5]
    13d4:	str	xzr, [x5, #8]
    13d8:	b	2238 <__ieee754_rem_pio2+0xeb8>
    13dc:	mov	w9, #0xd97b                	// #55675
    13e0:	movk	w9, #0x4002, lsl #16
    13e4:	cmp	w8, w9
    13e8:	b.hi	142c <__ieee754_rem_pio2+0xac>  // b.pmore
    13ec:	lsr	x9, x6, #32
    13f0:	cmp	w9, #0x1
    13f4:	b.lt	153c <__ieee754_rem_pio2+0x1bc>  // b.tstop
    13f8:	adrp	x9, 0 <pts_ieee754_acos>
    13fc:	ldr	d1, [x9]
    1400:	mov	w9, #0x21fb                	// #8699
    1404:	movk	w9, #0x3ff9, lsl #16
    1408:	fadd	d0, d0, d1
    140c:	cmp	w8, w9
    1410:	b.ne	1570 <__ieee754_rem_pio2+0x1f0>  // b.any
    1414:	adrp	x8, 0 <pts_ieee754_acos>
    1418:	ldr	d1, [x8]
    141c:	adrp	x8, 0 <pts_ieee754_acos>
    1420:	fadd	d0, d0, d1
    1424:	ldr	d1, [x8]
    1428:	b	1578 <__ieee754_rem_pio2+0x1f8>
    142c:	mov	w9, #0x21fb                	// #8699
    1430:	movk	w9, #0x4139, lsl #16
    1434:	cmp	w8, w9
    1438:	b.hi	1520 <__ieee754_rem_pio2+0x1a0>  // b.pmore
    143c:	fabs	d0, d0
    1440:	adrp	x9, 0 <pts_ieee754_acos>
    1444:	fmov	d1, #5.000000000000000000e-01
    1448:	ldr	d2, [x9]
    144c:	adrp	x9, 0 <pts_ieee754_acos>
    1450:	adrp	x10, 0 <pts_ieee754_acos>
    1454:	ldr	d3, [x10]
    1458:	fmadd	d1, d0, d2, d1
    145c:	fcvtzs	w0, d1
    1460:	ldr	d1, [x9]
    1464:	scvtf	d2, w0
    1468:	cmp	w0, #0x1f
    146c:	fmadd	d1, d2, d1, d0
    1470:	fmul	d0, d2, d3
    1474:	b.gt	1490 <__ieee754_rem_pio2+0x110>
    1478:	adrp	x9, 0 <pts_ieee754_acos>
    147c:	add	x9, x9, #0x0
    1480:	add	x9, x9, w0, sxtw #2
    1484:	ldur	w9, [x9, #-4]
    1488:	cmp	w8, w9
    148c:	b.ne	1514 <__ieee754_rem_pio2+0x194>  // b.any
    1490:	fsub	d3, d1, d0
    1494:	lsr	w8, w8, #20
    1498:	fmov	x9, d3
    149c:	str	d3, [x5]
    14a0:	ubfx	x9, x9, #52, #11
    14a4:	sub	w9, w8, w9
    14a8:	cmp	w9, #0x11
    14ac:	b.lt	16ec <__ieee754_rem_pio2+0x36c>  // b.tstop
    14b0:	adrp	x9, 0 <pts_ieee754_acos>
    14b4:	ldr	d0, [x9]
    14b8:	adrp	x9, 0 <pts_ieee754_acos>
    14bc:	fmul	d0, d2, d0
    14c0:	fsub	d4, d1, d0
    14c4:	fsub	d1, d1, d4
    14c8:	fsub	d0, d1, d0
    14cc:	ldr	d1, [x9]
    14d0:	fnmsub	d0, d2, d1, d0
    14d4:	fsub	d3, d4, d0
    14d8:	fmov	x9, d3
    14dc:	str	d3, [x5]
    14e0:	ubfx	x9, x9, #52, #11
    14e4:	sub	w8, w8, w9
    14e8:	cmp	w8, #0x32
    14ec:	b.lt	16e8 <__ieee754_rem_pio2+0x368>  // b.tstop
    14f0:	adrp	x8, 0 <pts_ieee754_acos>
    14f4:	ldr	d0, [x8]
    14f8:	adrp	x8, 0 <pts_ieee754_acos>
    14fc:	fmul	d0, d2, d0
    1500:	fsub	d1, d4, d0
    1504:	fsub	d3, d4, d1
    1508:	fsub	d0, d3, d0
    150c:	ldr	d3, [x8]
    1510:	fnmsub	d0, d2, d3, d0
    1514:	fsub	d3, d1, d0
    1518:	str	d3, [x5]
    151c:	b	16ec <__ieee754_rem_pio2+0x36c>
    1520:	lsr	w10, w8, #20
    1524:	cmp	w10, #0x7ff
    1528:	b.cc	1584 <__ieee754_rem_pio2+0x204>  // b.lo, b.ul, b.last
    152c:	fsub	d0, d0, d0
    1530:	mov	w0, wzr
    1534:	stp	d0, d0, [x5]
    1538:	b	2238 <__ieee754_rem_pio2+0xeb8>
    153c:	adrp	x9, 0 <pts_ieee754_acos>
    1540:	ldr	d1, [x9]
    1544:	mov	w9, #0x21fb                	// #8699
    1548:	movk	w9, #0x3ff9, lsl #16
    154c:	fadd	d0, d0, d1
    1550:	cmp	w8, w9
    1554:	b.ne	1690 <__ieee754_rem_pio2+0x310>  // b.any
    1558:	adrp	x8, 0 <pts_ieee754_acos>
    155c:	ldr	d1, [x8]
    1560:	adrp	x8, 0 <pts_ieee754_acos>
    1564:	fadd	d0, d0, d1
    1568:	ldr	d1, [x8]
    156c:	b	1698 <__ieee754_rem_pio2+0x318>
    1570:	adrp	x8, 0 <pts_ieee754_acos>
    1574:	ldr	d1, [x8]
    1578:	fadd	d2, d0, d1
    157c:	mov	w0, #0x1                   	// #1
    1580:	b	16a0 <__ieee754_rem_pio2+0x320>
    1584:	sub	w9, w10, #0x416
    1588:	mov	x12, x6
    158c:	mov	x23, xzr
    1590:	sub	w8, w8, w9, lsl #20
    1594:	mov	x11, xzr
    1598:	bfi	x12, x8, #32, #32
    159c:	fmov	d0, x12
    15a0:	mov	x12, #0xffffffff00000000    	// #-4294967296
    15a4:	fcvtzs	w8, d0
    15a8:	scvtf	d1, w8
    15ac:	fsub	d0, d0, d1
    15b0:	fcvtzs	w8, d0, #24
    15b4:	scvtf	d2, w8
    15b8:	mov	x8, #0x4170000000000000    	// #4715268809856909312
    15bc:	fmov	d3, x8
    15c0:	add	x8, sp, #0x38
    15c4:	add	x8, x8, #0x10
    15c8:	fnmsub	d0, d0, d3, d2
    15cc:	stp	d1, d2, [sp, #56]
    15d0:	fmul	d0, d0, d3
    15d4:	str	d0, [sp, #72]
    15d8:	ldr	d0, [x8, x23, lsl #3]
    15dc:	add	x11, x11, x12
    15e0:	sub	x23, x23, #0x1
    15e4:	fcmp	d0, #0.0
    15e8:	b.eq	15d8 <__ieee754_rem_pio2+0x258>  // b.none
    15ec:	sub	w8, w10, #0x419
    15f0:	mov	w10, #0xaaab                	// #43691
    15f4:	mov	w12, #0xffffffe8            	// #-24
    15f8:	movk	w10, #0x2aaa, lsl #16
    15fc:	stp	x6, x5, [sp, #8]
    1600:	smull	x8, w8, w10
    1604:	lsr	x10, x8, #63
    1608:	asr	x8, x8, #34
    160c:	add	w8, w8, w10
    1610:	add	x10, x23, #0x4
    1614:	madd	w9, w8, w12, w9
    1618:	cmn	w10, #0x3
    161c:	stur	w9, [x29, #-52]
    1620:	adrp	x9, 0 <pts_ieee754_acos>
    1624:	add	x9, x9, #0x0
    1628:	b.lt	16d0 <__ieee754_rem_pio2+0x350>  // b.tstop
    162c:	add	x12, x23, #0x7
    1630:	mov	x13, #0x300000000           	// #12884901888
    1634:	mov	x14, #0x400000000           	// #17179869184
    1638:	bic	w0, w12, w12, asr #31
    163c:	mov	x17, #0x500000000           	// #21474836480
    1640:	add	x16, x11, x13
    1644:	mov	x13, #0x600000000           	// #25769803776
    1648:	sub	w18, w8, w23
    164c:	add	x15, x11, x14
    1650:	add	x14, x11, x17
    1654:	add	x13, x11, x13
    1658:	add	x17, x23, #0x3
    165c:	sub	w18, w18, #0x3
    1660:	add	x0, x0, #0x1
    1664:	add	x1, sp, #0x198
    1668:	b	1684 <__ieee754_rem_pio2+0x304>
    166c:	ldr	w2, [x9, w18, uxtw #2]
    1670:	scvtf	d0, w2
    1674:	subs	x0, x0, #0x1
    1678:	add	w18, w18, #0x1
    167c:	str	d0, [x1], #8
    1680:	b.eq	16b0 <__ieee754_rem_pio2+0x330>  // b.none
    1684:	tbz	w18, #31, 166c <__ieee754_rem_pio2+0x2ec>
    1688:	movi	d0, #0x0
    168c:	b	1674 <__ieee754_rem_pio2+0x2f4>
    1690:	adrp	x8, 0 <pts_ieee754_acos>
    1694:	ldr	d1, [x8]
    1698:	fadd	d2, d0, d1
    169c:	mov	w0, #0xffffffff            	// #-1
    16a0:	fsub	d0, d0, d2
    16a4:	fadd	d0, d0, d1
    16a8:	stp	d2, d0, [x5]
    16ac:	b	2238 <__ieee754_rem_pio2+0xeb8>
    16b0:	cmp	w10, #0x0
    16b4:	b.le	16d0 <__ieee754_rem_pio2+0x350>
    16b8:	movi	d0, #0x0
    16bc:	and	x24, x10, #0xffffffff
    16c0:	cmp	x24, #0x8
    16c4:	b.cs	170c <__ieee754_rem_pio2+0x38c>  // b.hs, b.nlast
    16c8:	mov	x17, xzr
    16cc:	b	1794 <__ieee754_rem_pio2+0x414>
    16d0:	movi	v1.2d, #0x0
    16d4:	mov	w26, wzr
    16d8:	movi	d0, #0x0
    16dc:	and	x24, x10, #0xffffffff
    16e0:	stp	q1, q1, [sp, #80]
    16e4:	b	1b54 <__ieee754_rem_pio2+0x7d4>
    16e8:	fmov	d1, d4
    16ec:	fsub	d1, d1, d3
    16f0:	fsub	d0, d1, d0
    16f4:	str	d0, [x5, #8]
    16f8:	tbz	x6, #63, 2238 <__ieee754_rem_pio2+0xeb8>
    16fc:	fneg	d1, d3
    1700:	fneg	d0, d0
    1704:	stp	d1, d0, [x5]
    1708:	b	2234 <__ieee754_rem_pio2+0xeb4>
    170c:	sub	x18, x24, #0x1
    1710:	sub	w0, w17, w18
    1714:	cmp	w0, w17
    1718:	mov	x17, xzr
    171c:	b.gt	1794 <__ieee754_rem_pio2+0x414>
    1720:	lsr	x18, x18, #32
    1724:	cbnz	x18, 1794 <__ieee754_rem_pio2+0x414>
    1728:	and	x18, x10, #0x3
    172c:	add	x0, sp, #0x38
    1730:	add	w1, w23, #0x4
    1734:	sub	x17, x24, x18
    1738:	add	x0, x0, #0x10
    173c:	sub	x1, x1, x18
    1740:	add	x2, sp, #0x198
    1744:	mov	x3, #0xfffffffc00000000    	// #-17179869184
    1748:	add	x4, x2, x16, asr #29
    174c:	ldp	q2, q3, [x0, #-16]
    1750:	subs	x1, x1, #0x4
    1754:	add	x0, x0, #0x20
    1758:	add	x16, x16, x3
    175c:	ldur	q1, [x4, #-8]
    1760:	ext	v1.16b, v1.16b, v1.16b, #8
    1764:	fmul	v1.2d, v2.2d, v1.2d
    1768:	ldur	q2, [x4, #-24]
    176c:	ext	v2.16b, v2.16b, v2.16b, #8
    1770:	mov	d4, v1.d[1]
    1774:	fadd	d0, d0, d1
    1778:	fmul	v1.2d, v3.2d, v2.2d
    177c:	fadd	d0, d0, d4
    1780:	mov	d2, v1.d[1]
    1784:	fadd	d0, d0, d1
    1788:	fadd	d0, d0, d2
    178c:	b.ne	1748 <__ieee754_rem_pio2+0x3c8>  // b.any
    1790:	cbz	x18, 17d4 <__ieee754_rem_pio2+0x454>
    1794:	sub	x18, x11, x17, lsl #32
    1798:	add	x16, sp, #0x38
    179c:	mov	x0, #0x300000000           	// #12884901888
    17a0:	add	w1, w23, #0x4
    17a4:	add	x16, x16, x17, lsl #3
    17a8:	add	x18, x18, x0
    17ac:	sub	x17, x1, x17
    17b0:	add	x0, sp, #0x198
    17b4:	mov	x1, #0xffffffff00000000    	// #-4294967296
    17b8:	asr	x2, x18, #29
    17bc:	ldr	d1, [x16], #8
    17c0:	subs	x17, x17, #0x1
    17c4:	add	x18, x18, x1
    17c8:	ldr	d2, [x0, x2]
    17cc:	fmadd	d0, d1, d2, d0
    17d0:	b.ne	17b8 <__ieee754_rem_pio2+0x438>  // b.any
    17d4:	movi	d1, #0x0
    17d8:	cmp	x24, #0x8
    17dc:	str	d0, [sp, #80]
    17e0:	b.cs	17ec <__ieee754_rem_pio2+0x46c>  // b.hs, b.nlast
    17e4:	mov	x16, xzr
    17e8:	b	1874 <__ieee754_rem_pio2+0x4f4>
    17ec:	sub	x17, x24, #0x1
    17f0:	sub	w16, w10, w17
    17f4:	cmp	w16, w10
    17f8:	mov	x16, xzr
    17fc:	b.gt	1874 <__ieee754_rem_pio2+0x4f4>
    1800:	lsr	x17, x17, #32
    1804:	cbnz	x17, 1874 <__ieee754_rem_pio2+0x4f4>
    1808:	and	x17, x10, #0x3
    180c:	add	x18, sp, #0x38
    1810:	add	w0, w23, #0x4
    1814:	sub	x16, x24, x17
    1818:	add	x18, x18, #0x10
    181c:	sub	x0, x0, x17
    1820:	add	x1, sp, #0x198
    1824:	mov	x2, #0xfffffffc00000000    	// #-17179869184
    1828:	add	x3, x1, x15, asr #29
    182c:	ldp	q2, q3, [x18, #-16]
    1830:	subs	x0, x0, #0x4
    1834:	add	x18, x18, #0x20
    1838:	add	x15, x15, x2
    183c:	ldur	q0, [x3, #-8]
    1840:	ext	v0.16b, v0.16b, v0.16b, #8
    1844:	fmul	v0.2d, v2.2d, v0.2d
    1848:	ldur	q2, [x3, #-24]
    184c:	ext	v2.16b, v2.16b, v2.16b, #8
    1850:	mov	d4, v0.d[1]
    1854:	fadd	d0, d1, d0
    1858:	fmul	v1.2d, v3.2d, v2.2d
    185c:	fadd	d0, d0, d4
    1860:	mov	d2, v1.d[1]
    1864:	fadd	d0, d0, d1
    1868:	fadd	d1, d0, d2
    186c:	b.ne	1828 <__ieee754_rem_pio2+0x4a8>  // b.any
    1870:	cbz	x17, 18b4 <__ieee754_rem_pio2+0x534>
    1874:	sub	x17, x11, x16, lsl #32
    1878:	add	x15, sp, #0x38
    187c:	mov	x18, #0x400000000           	// #17179869184
    1880:	add	w0, w23, #0x4
    1884:	add	x15, x15, x16, lsl #3
    1888:	add	x17, x17, x18
    188c:	sub	x16, x0, x16
    1890:	add	x18, sp, #0x198
    1894:	mov	x0, #0xffffffff00000000    	// #-4294967296
    1898:	asr	x1, x17, #29
    189c:	ldr	d0, [x15], #8
    18a0:	subs	x16, x16, #0x1
    18a4:	add	x17, x17, x0
    18a8:	ldr	d2, [x18, x1]
    18ac:	fmadd	d1, d0, d2, d1
    18b0:	b.ne	1898 <__ieee754_rem_pio2+0x518>  // b.any
    18b4:	movi	d0, #0x0
    18b8:	cmp	x24, #0xa
    18bc:	str	d1, [sp, #88]
    18c0:	b.cs	18cc <__ieee754_rem_pio2+0x54c>  // b.hs, b.nlast
    18c4:	mov	x15, xzr
    18c8:	b	1958 <__ieee754_rem_pio2+0x5d8>
    18cc:	sub	x16, x24, #0x1
    18d0:	add	w15, w23, #0x5
    18d4:	sub	w17, w15, w16
    18d8:	cmp	w17, w15
    18dc:	mov	x15, xzr
    18e0:	b.gt	1958 <__ieee754_rem_pio2+0x5d8>
    18e4:	lsr	x16, x16, #32
    18e8:	cbnz	x16, 1958 <__ieee754_rem_pio2+0x5d8>
    18ec:	and	x16, x10, #0x3
    18f0:	add	x17, sp, #0x38
    18f4:	add	w18, w23, #0x4
    18f8:	sub	x15, x24, x16
    18fc:	add	x17, x17, #0x10
    1900:	sub	x18, x18, x16
    1904:	add	x0, sp, #0x198
    1908:	mov	x1, #0xfffffffc00000000    	// #-17179869184
    190c:	add	x2, x0, x14, asr #29
    1910:	ldp	q2, q3, [x17, #-16]
    1914:	subs	x18, x18, #0x4
    1918:	add	x17, x17, #0x20
    191c:	add	x14, x14, x1
    1920:	ldur	q1, [x2, #-8]
    1924:	ext	v1.16b, v1.16b, v1.16b, #8
    1928:	fmul	v1.2d, v2.2d, v1.2d
    192c:	ldur	q2, [x2, #-24]
    1930:	ext	v2.16b, v2.16b, v2.16b, #8
    1934:	mov	d4, v1.d[1]
    1938:	fadd	d0, d0, d1
    193c:	fmul	v1.2d, v3.2d, v2.2d
    1940:	fadd	d0, d0, d4
    1944:	mov	d2, v1.d[1]
    1948:	fadd	d0, d0, d1
    194c:	fadd	d0, d0, d2
    1950:	b.ne	190c <__ieee754_rem_pio2+0x58c>  // b.any
    1954:	cbz	x16, 1998 <__ieee754_rem_pio2+0x618>
    1958:	sub	x16, x11, x15, lsl #32
    195c:	add	x14, sp, #0x38
    1960:	mov	x17, #0x500000000           	// #21474836480
    1964:	add	w18, w23, #0x4
    1968:	add	x14, x14, x15, lsl #3
    196c:	add	x16, x16, x17
    1970:	sub	x15, x18, x15
    1974:	add	x17, sp, #0x198
    1978:	mov	x18, #0xffffffff00000000    	// #-4294967296
    197c:	asr	x0, x16, #29
    1980:	ldr	d1, [x14], #8
    1984:	subs	x15, x15, #0x1
    1988:	add	x16, x16, x18
    198c:	ldr	d2, [x17, x0]
    1990:	fmadd	d0, d1, d2, d0
    1994:	b.ne	197c <__ieee754_rem_pio2+0x5fc>  // b.any
    1998:	movi	d1, #0x0
    199c:	cmp	x24, #0xa
    19a0:	str	d0, [sp, #96]
    19a4:	b.cs	19b0 <__ieee754_rem_pio2+0x630>  // b.hs, b.nlast
    19a8:	mov	x14, xzr
    19ac:	b	1a3c <__ieee754_rem_pio2+0x6bc>
    19b0:	sub	x15, x24, #0x1
    19b4:	add	w14, w23, #0x6
    19b8:	sub	w16, w14, w15
    19bc:	cmp	w16, w14
    19c0:	mov	x14, xzr
    19c4:	b.gt	1a3c <__ieee754_rem_pio2+0x6bc>
    19c8:	lsr	x15, x15, #32
    19cc:	cbnz	x15, 1a3c <__ieee754_rem_pio2+0x6bc>
    19d0:	and	x15, x10, #0x3
    19d4:	add	x16, sp, #0x38
    19d8:	add	w17, w23, #0x4
    19dc:	sub	x14, x24, x15
    19e0:	add	x16, x16, #0x10
    19e4:	sub	x17, x17, x15
    19e8:	add	x18, sp, #0x198
    19ec:	mov	x0, #0xfffffffc00000000    	// #-17179869184
    19f0:	add	x1, x18, x13, asr #29
    19f4:	ldp	q2, q3, [x16, #-16]
    19f8:	subs	x17, x17, #0x4
    19fc:	add	x16, x16, #0x20
    1a00:	add	x13, x13, x0
    1a04:	ldur	q0, [x1, #-8]
    1a08:	ext	v0.16b, v0.16b, v0.16b, #8
    1a0c:	fmul	v0.2d, v2.2d, v0.2d
    1a10:	ldur	q2, [x1, #-24]
    1a14:	ext	v2.16b, v2.16b, v2.16b, #8
    1a18:	mov	d4, v0.d[1]
    1a1c:	fadd	d0, d1, d0
    1a20:	fmul	v1.2d, v3.2d, v2.2d
    1a24:	fadd	d0, d0, d4
    1a28:	mov	d2, v1.d[1]
    1a2c:	fadd	d0, d0, d1
    1a30:	fadd	d1, d0, d2
    1a34:	b.ne	19f0 <__ieee754_rem_pio2+0x670>  // b.any
    1a38:	cbz	x15, 1a7c <__ieee754_rem_pio2+0x6fc>
    1a3c:	sub	x13, x11, x14, lsl #32
    1a40:	add	x11, sp, #0x38
    1a44:	mov	x15, #0x600000000           	// #25769803776
    1a48:	add	w16, w23, #0x4
    1a4c:	add	x11, x11, x14, lsl #3
    1a50:	add	x13, x13, x15
    1a54:	sub	x14, x16, x14
    1a58:	add	x15, sp, #0x198
    1a5c:	mov	x16, #0xffffffff00000000    	// #-4294967296
    1a60:	asr	x17, x13, #29
    1a64:	ldr	d0, [x11], #8
    1a68:	subs	x14, x14, #0x1
    1a6c:	add	x13, x13, x16
    1a70:	ldr	d2, [x15, x17]
    1a74:	fmadd	d1, d0, d2, d1
    1a78:	b.ne	1a60 <__ieee754_rem_pio2+0x6e0>  // b.any
    1a7c:	movi	d0, #0x0
    1a80:	cmp	x24, #0x8
    1a84:	str	d1, [sp, #104]
    1a88:	b.cs	1a94 <__ieee754_rem_pio2+0x714>  // b.hs, b.nlast
    1a8c:	mov	x11, xzr
    1a90:	b	1b1c <__ieee754_rem_pio2+0x79c>
    1a94:	sub	x13, x24, #0x1
    1a98:	sub	w11, w12, w13
    1a9c:	cmp	w11, w12
    1aa0:	mov	x11, xzr
    1aa4:	b.gt	1b1c <__ieee754_rem_pio2+0x79c>
    1aa8:	lsr	x12, x13, #32
    1aac:	cbnz	x12, 1b1c <__ieee754_rem_pio2+0x79c>
    1ab0:	and	x10, x10, #0x3
    1ab4:	add	x12, sp, #0x38
    1ab8:	add	w13, w23, #0x4
    1abc:	sub	x11, x24, x10
    1ac0:	add	x12, x12, #0x10
    1ac4:	sub	x13, x13, x10
    1ac8:	add	w14, w23, #0x7
    1acc:	add	x15, sp, #0x198
    1ad0:	add	x16, x15, w14, sxtw #3
    1ad4:	ldp	q2, q3, [x12, #-16]
    1ad8:	sub	x13, x13, #0x4
    1adc:	add	x12, x12, #0x20
    1ae0:	sub	w14, w14, #0x4
    1ae4:	ldur	q1, [x16, #-8]
    1ae8:	ext	v1.16b, v1.16b, v1.16b, #8
    1aec:	fmul	v1.2d, v2.2d, v1.2d
    1af0:	ldur	q2, [x16, #-24]
    1af4:	ext	v2.16b, v2.16b, v2.16b, #8
    1af8:	mov	d4, v1.d[1]
    1afc:	fadd	d0, d0, d1
    1b00:	fmul	v1.2d, v3.2d, v2.2d
    1b04:	fadd	d0, d0, d4
    1b08:	mov	d2, v1.d[1]
    1b0c:	fadd	d0, d0, d1
    1b10:	fadd	d0, d0, d2
    1b14:	cbnz	x13, 1ad0 <__ieee754_rem_pio2+0x750>
    1b18:	cbz	x10, 1b50 <__ieee754_rem_pio2+0x7d0>
    1b1c:	add	x10, sp, #0x38
    1b20:	add	w12, w23, #0x4
    1b24:	sub	w13, w23, w11
    1b28:	add	x10, x10, x11, lsl #3
    1b2c:	sub	x11, x12, x11
    1b30:	add	w12, w13, #0x7
    1b34:	add	x13, sp, #0x198
    1b38:	ldr	d1, [x10], #8
    1b3c:	ldr	d2, [x13, w12, sxtw #3]
    1b40:	sub	x11, x11, #0x1
    1b44:	sub	w12, w12, #0x1
    1b48:	fmadd	d0, d1, d2, d0
    1b4c:	cbnz	x11, 1b38 <__ieee754_rem_pio2+0x7b8>
    1b50:	mov	w26, #0x1                   	// #1
    1b54:	ldur	w12, [x29, #-52]
    1b58:	add	x22, x9, w8, sxtw #2
    1b5c:	sub	x8, x29, #0x98
    1b60:	mov	w10, #0x30                  	// #48
    1b64:	sub	x9, x8, #0x10
    1b68:	mov	w11, #0x2f                  	// #47
    1b6c:	sub	w10, w10, w12
    1b70:	str	x9, [sp, #24]
    1b74:	add	x9, sp, #0x38
    1b78:	sub	x28, x8, #0x4
    1b7c:	add	x21, sp, #0x198
    1b80:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1b84:	stur	w10, [x29, #-56]
    1b88:	sub	w10, w11, w12
    1b8c:	add	x15, x9, #0x10
    1b90:	sub	x16, x21, #0x8
    1b94:	fmov	d13, x8
    1b98:	mov	x8, #0xc170000000000000    	// #-4508103226997866496
    1b9c:	sub	w25, w12, #0x18
    1ba0:	str	d0, [sp, #112]
    1ba4:	and	x19, x24, #0xfffffffc
    1ba8:	str	w10, [sp, #36]
    1bac:	fmov	d9, #1.250000000000000000e-01
    1bb0:	fmov	d10, #-8.000000000000000000e+00
    1bb4:	fmov	d11, #1.000000000000000000e+00
    1bb8:	fmov	d12, #5.000000000000000000e-01
    1bbc:	fmov	d14, x8
    1bc0:	add	x20, sp, #0x50
    1bc4:	mov	w8, #0x4                   	// #4
    1bc8:	stp	x16, x15, [sp, #40]
    1bcc:	b	1bd4 <__ieee754_rem_pio2+0x854>
    1bd0:	ldr	d0, [x20, x8, lsl #3]
    1bd4:	mov	w27, w8
    1bd8:	sub	x9, x29, #0x98
    1bdc:	sub	x8, x27, #0x1
    1be0:	fmul	d1, d0, d13
    1be4:	ldr	d2, [x20, x8, lsl #3]
    1be8:	sub	x8, x8, #0x1
    1bec:	cmn	x8, #0x1
    1bf0:	fcvtzs	w10, d1
    1bf4:	scvtf	d1, w10
    1bf8:	fmadd	d0, d1, d14, d0
    1bfc:	fcvtzs	w10, d0
    1c00:	fadd	d0, d2, d1
    1c04:	str	w10, [x9], #4
    1c08:	b.ne	1be0 <__ieee754_rem_pio2+0x860>  // b.any
    1c0c:	mov	w0, w25
    1c10:	bl	0 <scalbn>
    1c14:	fmul	d1, d0, d9
    1c18:	ldur	w8, [x29, #-52]
    1c1c:	cmp	w8, #0x19
    1c20:	frintm	d1, d1
    1c24:	fmadd	d0, d1, d10, d0
    1c28:	fcvtzs	w13, d0
    1c2c:	scvtf	d1, w13
    1c30:	fsub	d8, d0, d1
    1c34:	b.lt	1c68 <__ieee754_rem_pio2+0x8e8>  // b.tstop
    1c38:	sub	x8, x29, #0x98
    1c3c:	ldur	w11, [x29, #-56]
    1c40:	add	x8, x8, w27, sxtw #2
    1c44:	ldur	w9, [x8, #-4]
    1c48:	asr	w10, w9, w11
    1c4c:	lsl	w11, w10, w11
    1c50:	add	w13, w10, w13
    1c54:	sub	w9, w9, w11
    1c58:	ldr	w11, [sp, #36]
    1c5c:	stur	w9, [x8, #-4]
    1c60:	asr	w17, w9, w11
    1c64:	b	1c94 <__ieee754_rem_pio2+0x914>
    1c68:	cbz	w25, 1c84 <__ieee754_rem_pio2+0x904>
    1c6c:	fcmp	d8, d12
    1c70:	ldp	x16, x15, [sp, #40]
    1c74:	add	x14, sp, #0x38
    1c78:	b.ge	1ca8 <__ieee754_rem_pio2+0x928>  // b.tcont
    1c7c:	mov	w17, wzr
    1c80:	b	1d70 <__ieee754_rem_pio2+0x9f0>
    1c84:	sub	x8, x29, #0x98
    1c88:	add	x8, x8, w27, sxtw #2
    1c8c:	ldur	w8, [x8, #-4]
    1c90:	asr	w17, w8, #23
    1c94:	ldp	x16, x15, [sp, #40]
    1c98:	add	x14, sp, #0x38
    1c9c:	cmp	w17, #0x1
    1ca0:	b.ge	1cac <__ieee754_rem_pio2+0x92c>  // b.tcont
    1ca4:	b	1d70 <__ieee754_rem_pio2+0x9f0>
    1ca8:	mov	w17, #0x2                   	// #2
    1cac:	mov	w11, wzr
    1cb0:	sub	x9, x29, #0x98
    1cb4:	mov	x10, x27
    1cb8:	b	1cdc <__ieee754_rem_pio2+0x95c>
    1cbc:	mov	w11, #0xffffff              	// #16777215
    1cc0:	sub	w11, w11, w12
    1cc4:	mov	w8, wzr
    1cc8:	str	w11, [x9]
    1ccc:	mov	w11, #0x1                   	// #1
    1cd0:	subs	x10, x10, #0x1
    1cd4:	add	x9, x9, #0x4
    1cd8:	b.eq	1cfc <__ieee754_rem_pio2+0x97c>  // b.none
    1cdc:	ldr	w12, [x9]
    1ce0:	cbnz	w11, 1cbc <__ieee754_rem_pio2+0x93c>
    1ce4:	cbz	w12, 1cf0 <__ieee754_rem_pio2+0x970>
    1ce8:	mov	w11, #0x1000000             	// #16777216
    1cec:	b	1cc0 <__ieee754_rem_pio2+0x940>
    1cf0:	mov	w11, wzr
    1cf4:	mov	w8, #0x1                   	// #1
    1cf8:	b	1cd0 <__ieee754_rem_pio2+0x950>
    1cfc:	ldur	w9, [x29, #-52]
    1d00:	cmp	w9, #0x19
    1d04:	b.lt	1d38 <__ieee754_rem_pio2+0x9b8>  // b.tstop
    1d08:	b.eq	1d20 <__ieee754_rem_pio2+0x9a0>  // b.none
    1d0c:	ldur	w9, [x29, #-52]
    1d10:	cmp	w9, #0x1a
    1d14:	b.ne	1d38 <__ieee754_rem_pio2+0x9b8>  // b.any
    1d18:	mov	w9, #0x3fffff              	// #4194303
    1d1c:	b	1d24 <__ieee754_rem_pio2+0x9a4>
    1d20:	mov	w9, #0x7fffff              	// #8388607
    1d24:	sub	x10, x29, #0x98
    1d28:	add	x10, x10, w27, sxtw #2
    1d2c:	ldur	w11, [x10, #-4]
    1d30:	and	w9, w11, w9
    1d34:	stur	w9, [x10, #-4]
    1d38:	cmp	w17, #0x2
    1d3c:	add	w13, w13, #0x1
    1d40:	b.ne	1d6c <__ieee754_rem_pio2+0x9ec>  // b.any
    1d44:	fsub	d8, d11, d8
    1d48:	tbnz	w8, #0, 1d6c <__ieee754_rem_pio2+0x9ec>
    1d4c:	fmov	d0, #1.000000000000000000e+00
    1d50:	mov	w0, w25
    1d54:	str	w13, [sp, #32]
    1d58:	bl	0 <scalbn>
    1d5c:	fsub	d8, d8, d0
    1d60:	ldp	x16, x15, [sp, #40]
    1d64:	ldr	w13, [sp, #32]
    1d68:	add	x14, sp, #0x38
    1d6c:	mov	w17, #0x2                   	// #2
    1d70:	fcmp	d8, #0.0
    1d74:	b.ne	1f30 <__ieee754_rem_pio2+0xbb0>  // b.any
    1d78:	cmp	w27, #0x5
    1d7c:	b.cc	1e14 <__ieee754_rem_pio2+0xa94>  // b.lo, b.ul, b.last
    1d80:	sub	x9, x27, #0x4
    1d84:	cmp	x9, #0x8
    1d88:	b.cs	1d98 <__ieee754_rem_pio2+0xa18>  // b.hs, b.nlast
    1d8c:	mov	w9, wzr
    1d90:	mov	x8, x27
    1d94:	b	1dfc <__ieee754_rem_pio2+0xa7c>
    1d98:	movi	v0.2d, #0x0
    1d9c:	movi	v1.2d, #0x0
    1da0:	ldr	x8, [sp, #24]
    1da4:	and	x10, x9, #0xfffffffffffffff8
    1da8:	add	x11, x8, x27, lsl #2
    1dac:	sub	x8, x27, x10
    1db0:	mov	x12, x10
    1db4:	ldp	q3, q2, [x11, #-16]
    1db8:	subs	x12, x12, #0x8
    1dbc:	sub	x11, x11, #0x20
    1dc0:	rev64	v2.4s, v2.4s
    1dc4:	rev64	v3.4s, v3.4s
    1dc8:	ext	v2.16b, v2.16b, v2.16b, #8
    1dcc:	ext	v3.16b, v3.16b, v3.16b, #8
    1dd0:	orr	v0.16b, v2.16b, v0.16b
    1dd4:	orr	v1.16b, v3.16b, v1.16b
    1dd8:	b.ne	1db4 <__ieee754_rem_pio2+0xa34>  // b.any
    1ddc:	orr	v0.16b, v1.16b, v0.16b
    1de0:	cmp	x9, x10
    1de4:	ext	v1.16b, v0.16b, v0.16b, #8
    1de8:	orr	v0.8b, v0.8b, v1.8b
    1dec:	fmov	x11, d0
    1df0:	lsr	x12, x11, #32
    1df4:	orr	w9, w11, w12
    1df8:	b.eq	1e10 <__ieee754_rem_pio2+0xa90>  // b.none
    1dfc:	ldr	w10, [x28, x8, lsl #2]
    1e00:	cmp	x8, #0x5
    1e04:	sub	x8, x8, #0x1
    1e08:	orr	w9, w10, w9
    1e0c:	b.gt	1dfc <__ieee754_rem_pio2+0xa7c>
    1e10:	cbnz	w9, 2100 <__ieee754_rem_pio2+0xd80>
    1e14:	ldur	w8, [x29, #-140]
    1e18:	cbz	w8, 1e24 <__ieee754_rem_pio2+0xaa4>
    1e1c:	mov	w8, #0x1                   	// #1
    1e20:	b	1e54 <__ieee754_rem_pio2+0xad4>
    1e24:	ldur	w8, [x29, #-144]
    1e28:	cbz	w8, 1e34 <__ieee754_rem_pio2+0xab4>
    1e2c:	mov	w8, #0x2                   	// #2
    1e30:	b	1e54 <__ieee754_rem_pio2+0xad4>
    1e34:	ldur	w8, [x29, #-148]
    1e38:	cbz	w8, 1e44 <__ieee754_rem_pio2+0xac4>
    1e3c:	mov	w8, #0x3                   	// #3
    1e40:	b	1e54 <__ieee754_rem_pio2+0xad4>
    1e44:	ldur	w8, [x29, #-152]
    1e48:	cmp	w8, #0x0
    1e4c:	mov	w8, #0x4                   	// #4
    1e50:	cinc	w8, w8, eq	// eq = none
    1e54:	add	w9, w23, w27
    1e58:	add	w8, w8, w27
    1e5c:	add	w9, w9, #0x4
    1e60:	b	1e74 <__ieee754_rem_pio2+0xaf4>
    1e64:	cmp	x27, x8
    1e68:	add	w9, w9, #0x1
    1e6c:	str	d0, [x20, x27, lsl #3]
    1e70:	b.cs	1bd0 <__ieee754_rem_pio2+0x850>  // b.hs, b.nlast
    1e74:	mov	x10, x27
    1e78:	add	x27, x27, #0x1
    1e7c:	movi	d0, #0x0
    1e80:	ldr	w11, [x22, x27, lsl #2]
    1e84:	add	w10, w23, w10
    1e88:	add	w10, w10, #0x4
    1e8c:	scvtf	d1, w11
    1e90:	str	d1, [x21, w10, sxtw #3]
    1e94:	cbz	w26, 1e64 <__ieee754_rem_pio2+0xae4>
    1e98:	sbfiz	x10, x9, #3, #32
    1e9c:	cmp	x24, #0x4
    1ea0:	b.cs	1eac <__ieee754_rem_pio2+0xb2c>  // b.hs, b.nlast
    1ea4:	mov	x11, xzr
    1ea8:	b	1f04 <__ieee754_rem_pio2+0xb84>
    1eac:	add	x11, x16, x10
    1eb0:	mov	x12, x19
    1eb4:	mov	x13, x15
    1eb8:	ldp	q2, q1, [x11, #-16]
    1ebc:	subs	x12, x12, #0x4
    1ec0:	ldp	q3, q4, [x13, #-16]
    1ec4:	add	x13, x13, #0x20
    1ec8:	sub	x11, x11, #0x20
    1ecc:	ext	v1.16b, v1.16b, v1.16b, #8
    1ed0:	ext	v2.16b, v2.16b, v2.16b, #8
    1ed4:	fmul	v1.2d, v3.2d, v1.2d
    1ed8:	mov	d3, v1.d[1]
    1edc:	fadd	d0, d0, d1
    1ee0:	fmul	v1.2d, v4.2d, v2.2d
    1ee4:	fadd	d0, d0, d3
    1ee8:	mov	d2, v1.d[1]
    1eec:	fadd	d0, d0, d1
    1ef0:	fadd	d0, d0, d2
    1ef4:	b.ne	1eb8 <__ieee754_rem_pio2+0xb38>  // b.any
    1ef8:	cmp	x24, x19
    1efc:	mov	x11, x19
    1f00:	b.eq	1e64 <__ieee754_rem_pio2+0xae4>  // b.none
    1f04:	lsl	x12, x11, #3
    1f08:	sub	x13, x10, x12
    1f0c:	sub	x10, x24, x11
    1f10:	add	x12, x14, x12
    1f14:	add	x11, x21, x13
    1f18:	ldr	d1, [x12], #8
    1f1c:	subs	x10, x10, #0x1
    1f20:	ldr	d2, [x11], #-8
    1f24:	fmadd	d0, d1, d2, d0
    1f28:	b.ne	1f18 <__ieee754_rem_pio2+0xb98>  // b.any
    1f2c:	b	1e64 <__ieee754_rem_pio2+0xae4>
    1f30:	fmov	d0, d8
    1f34:	ldur	w9, [x29, #-52]
    1f38:	mov	w8, #0x18                  	// #24
    1f3c:	mov	w19, w17
    1f40:	mov	w20, w13
    1f44:	sub	w0, w8, w9
    1f48:	bl	0 <scalbn>
    1f4c:	mov	x8, #0x4170000000000000    	// #4715268809856909312
    1f50:	fmov	d1, x8
    1f54:	fcmp	d0, d1
    1f58:	b.ge	1f70 <__ieee754_rem_pio2+0xbf0>  // b.tcont
    1f5c:	fcvtzs	w8, d0
    1f60:	sub	x9, x29, #0x98
    1f64:	stur	w25, [x29, #-52]
    1f68:	str	w8, [x9, x27, lsl #2]
    1f6c:	b	1fa4 <__ieee754_rem_pio2+0xc24>
    1f70:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1f74:	mov	x9, #0xc170000000000000    	// #-4508103226997866496
    1f78:	sub	x10, x29, #0x98
    1f7c:	fmov	d1, x8
    1f80:	fmov	d2, x9
    1f84:	fmul	d1, d0, d1
    1f88:	fcvtzs	w8, d1
    1f8c:	scvtf	d1, w8
    1f90:	fmadd	d0, d1, d2, d0
    1f94:	fcvtzs	w9, d0
    1f98:	str	w9, [x10, x27, lsl #2]
    1f9c:	add	w27, w27, #0x1
    1fa0:	str	w8, [x10, w27, uxtw #2]
    1fa4:	mov	w17, w19
    1fa8:	tbnz	w27, #31, 2124 <__ieee754_rem_pio2+0xda4>
    1fac:	fmov	d0, #1.000000000000000000e+00
    1fb0:	ldur	w0, [x29, #-52]
    1fb4:	mov	w21, w17
    1fb8:	mov	w19, w27
    1fbc:	bl	0 <scalbn>
    1fc0:	mov	x10, #0x3e70000000000000    	// #4499096027743125504
    1fc4:	sub	x8, x29, #0x98
    1fc8:	add	x9, sp, #0x50
    1fcc:	fmov	d1, x10
    1fd0:	mov	x10, x19
    1fd4:	ldr	w11, [x8, x10, lsl #2]
    1fd8:	scvtf	d2, w11
    1fdc:	fmul	d2, d0, d2
    1fe0:	fmul	d0, d0, d1
    1fe4:	str	d2, [x9, x10, lsl #3]
    1fe8:	sub	x10, x10, #0x1
    1fec:	cmn	x10, #0x1
    1ff0:	b.ne	1fd4 <__ieee754_rem_pio2+0xc54>  // b.any
    1ff4:	adrp	x11, 0 <pts_ieee754_acos>
    1ff8:	add	x10, sp, #0x50
    1ffc:	movi	d1, #0x0
    2000:	ldr	d0, [x11]
    2004:	adrp	x11, 0 <pts_ieee754_acos>
    2008:	add	x10, x10, x19, lsl #3
    200c:	ldr	d2, [x11]
    2010:	adrp	x11, 0 <pts_ieee754_acos>
    2014:	adrp	x12, 0 <pts_ieee754_acos>
    2018:	ldr	d3, [x11]
    201c:	ldr	d4, [x12]
    2020:	mov	x13, #0x442d00000000        	// #74960064217088
    2024:	ldr	x15, [sp, #16]
    2028:	mov	x8, xzr
    202c:	add	x9, x19, #0x1
    2030:	add	x10, x10, #0x10
    2034:	mov	w11, #0x4                   	// #4
    2038:	add	x12, sp, #0xf8
    203c:	movk	x13, #0x3e74, lsl #48
    2040:	mov	w16, w20
    2044:	mov	w17, w21
    2048:	b	2060 <__ieee754_rem_pio2+0xce0>
    204c:	str	d5, [x12, x8, lsl #3]
    2050:	add	x8, x8, #0x1
    2054:	sub	x10, x10, #0x8
    2058:	cmp	w9, w8
    205c:	b.eq	20b8 <__ieee754_rem_pio2+0xd38>  // b.none
    2060:	ldur	d5, [x10, #-16]
    2064:	cmp	w8, #0x4
    2068:	csel	w14, w8, w11, cc	// cc = lo, ul, last
    206c:	fmadd	d5, d5, d0, d1
    2070:	cbz	w8, 204c <__ieee754_rem_pio2+0xccc>
    2074:	fmov	d7, x13
    2078:	ldur	d6, [x10, #-8]
    207c:	add	w14, w14, #0x1
    2080:	cmp	w14, #0x2
    2084:	fmadd	d5, d6, d7, d5
    2088:	b.eq	204c <__ieee754_rem_pio2+0xccc>  // b.none
    208c:	ldr	d6, [x10]
    2090:	cmp	w14, #0x3
    2094:	fmadd	d5, d6, d2, d5
    2098:	b.eq	204c <__ieee754_rem_pio2+0xccc>  // b.none
    209c:	ldr	d6, [x10, #8]
    20a0:	cmp	w14, #0x4
    20a4:	fmadd	d5, d6, d3, d5
    20a8:	b.eq	204c <__ieee754_rem_pio2+0xccc>  // b.none
    20ac:	ldr	d6, [x10, #16]
    20b0:	fmadd	d5, d6, d4, d5
    20b4:	b	204c <__ieee754_rem_pio2+0xccc>
    20b8:	movi	d1, #0x0
    20bc:	cbz	w19, 214c <__ieee754_rem_pio2+0xdcc>
    20c0:	add	x9, x19, #0x1
    20c4:	add	x8, sp, #0xf8
    20c8:	and	x10, x9, #0xfffffffe
    20cc:	add	x11, x8, x19, lsl #3
    20d0:	sub	x8, x19, x10
    20d4:	mov	x12, x10
    20d8:	ldr	d0, [x11]
    20dc:	sub	x12, x12, #0x2
    20e0:	fadd	d0, d1, d0
    20e4:	ldur	d1, [x11, #-8]
    20e8:	sub	x11, x11, #0x10
    20ec:	fadd	d1, d0, d1
    20f0:	cbnz	x12, 20d8 <__ieee754_rem_pio2+0xd58>
    20f4:	cmp	x9, x10
    20f8:	b.ne	2150 <__ieee754_rem_pio2+0xdd0>  // b.any
    20fc:	b	2168 <__ieee754_rem_pio2+0xde8>
    2100:	sub	x8, x29, #0x98
    2104:	mov	w20, w13
    2108:	sub	x8, x8, #0x4
    210c:	ldr	w9, [x8, x27, lsl #2]
    2110:	sub	w25, w25, #0x18
    2114:	sub	x27, x27, #0x1
    2118:	cbz	w9, 210c <__ieee754_rem_pio2+0xd8c>
    211c:	stur	w25, [x29, #-52]
    2120:	tbz	w27, #31, 1fac <__ieee754_rem_pio2+0xc2c>
    2124:	movi	d0, #0x0
    2128:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    212c:	cmp	w17, #0x0
    2130:	fmov	d1, x8
    2134:	ldp	x12, x15, [sp, #8]
    2138:	cset	w8, eq	// eq = none
    213c:	mov	w16, w20
    2140:	fcsel	d0, d0, d1, eq	// eq = none
    2144:	str	d0, [x15]
    2148:	b	2210 <__ieee754_rem_pio2+0xe90>
    214c:	mov	x8, x19
    2150:	add	x9, sp, #0xf8
    2154:	ldr	d0, [x9, x8, lsl #3]
    2158:	sub	x8, x8, #0x1
    215c:	cmn	x8, #0x1
    2160:	fadd	d1, d1, d0
    2164:	b.ne	2154 <__ieee754_rem_pio2+0xdd4>  // b.any
    2168:	fneg	d0, d1
    216c:	ldr	d2, [sp, #248]
    2170:	cmp	w17, #0x0
    2174:	cset	w8, eq	// eq = none
    2178:	fcsel	d0, d1, d0, eq	// eq = none
    217c:	fsub	d1, d2, d1
    2180:	str	d0, [x15]
    2184:	cbz	w19, 21a0 <__ieee754_rem_pio2+0xe20>
    2188:	cmp	w19, #0x4
    218c:	add	w9, w19, #0x1
    2190:	b.cs	21a8 <__ieee754_rem_pio2+0xe28>  // b.hs, b.nlast
    2194:	ldr	x12, [sp, #8]
    2198:	mov	w10, #0x1                   	// #1
    219c:	b	21f4 <__ieee754_rem_pio2+0xe74>
    21a0:	ldr	x12, [sp, #8]
    21a4:	b	2210 <__ieee754_rem_pio2+0xe90>
    21a8:	sub	x11, x9, #0x1
    21ac:	add	x13, sp, #0xf8
    21b0:	and	x12, x11, #0xfffffffffffffffc
    21b4:	add	x13, x13, #0x18
    21b8:	orr	x10, x12, #0x1
    21bc:	mov	x14, x12
    21c0:	ldp	q2, q3, [x13, #-16]
    21c4:	subs	x14, x14, #0x4
    21c8:	add	x13, x13, #0x20
    21cc:	mov	d4, v2.d[1]
    21d0:	fadd	d1, d1, d2
    21d4:	mov	d2, v3.d[1]
    21d8:	fadd	d1, d1, d4
    21dc:	fadd	d1, d1, d3
    21e0:	fadd	d1, d1, d2
    21e4:	b.ne	21c0 <__ieee754_rem_pio2+0xe40>  // b.any
    21e8:	cmp	x11, x12
    21ec:	ldr	x12, [sp, #8]
    21f0:	b.eq	2210 <__ieee754_rem_pio2+0xe90>  // b.none
    21f4:	add	x11, sp, #0xf8
    21f8:	sub	x9, x9, x10
    21fc:	add	x11, x11, x10, lsl #3
    2200:	ldr	d2, [x11], #8
    2204:	subs	x9, x9, #0x1
    2208:	fadd	d1, d1, d2
    220c:	b.ne	2200 <__ieee754_rem_pio2+0xe80>  // b.any
    2210:	fneg	d2, d1
    2214:	cmp	w8, #0x0
    2218:	and	w0, w16, #0x7
    221c:	fcsel	d1, d1, d2, ne	// ne = any
    2220:	str	d1, [x15, #8]
    2224:	tbz	x12, #63, 2238 <__ieee754_rem_pio2+0xeb8>
    2228:	fneg	d0, d0
    222c:	fneg	d1, d1
    2230:	stp	d0, d1, [x15]
    2234:	neg	w0, w0
    2238:	add	sp, sp, #0x290
    223c:	ldp	x20, x19, [sp, #144]
    2240:	ldp	x22, x21, [sp, #128]
    2244:	ldp	x24, x23, [sp, #112]
    2248:	ldp	x26, x25, [sp, #96]
    224c:	ldp	x28, x27, [sp, #80]
    2250:	ldp	x29, x30, [sp, #64]
    2254:	ldp	d9, d8, [sp, #48]
    2258:	ldp	d11, d10, [sp, #32]
    225c:	ldp	d13, d12, [sp, #16]
    2260:	ldr	d14, [sp], #160
    2264:	ret
    2268:	nop
    226c:	nop
    2270:	nop
    2274:	nop
    2278:	nop
    227c:	nop

0000000000002280 <pts_ieee754_exp>:
    2280:	fmov	x9, d0
    2284:	mov	w11, #0x2e42                	// #11842
    2288:	movk	w11, #0x4086, lsl #16
    228c:	ubfx	x10, x9, #32, #31
    2290:	lsr	x8, x9, #63
    2294:	cmp	w10, w11
    2298:	b.cc	22d0 <pts_ieee754_exp+0x50>  // b.lo, b.ul, b.last
    229c:	lsr	w10, w10, #20
    22a0:	cmp	w10, #0x7ff
    22a4:	b.cc	2308 <pts_ieee754_exp+0x88>  // b.lo, b.ul, b.last
    22a8:	movi	d1, #0x0
    22ac:	lsr	x8, x9, #32
    22b0:	cmp	x9, #0x0
    22b4:	fadd	d2, d0, d0
    22b8:	and	w8, w8, #0xfffff
    22bc:	orr	w8, w8, w9
    22c0:	fcsel	d0, d0, d1, ge	// ge = tcont
    22c4:	cmp	w8, #0x0
    22c8:	fcsel	d0, d0, d2, eq	// eq = none
    22cc:	ret
    22d0:	mov	w9, #0x2e43                	// #11843
    22d4:	movk	w9, #0x3fd6, lsl #16
    22d8:	cmp	w10, w9
    22dc:	b.cc	232c <pts_ieee754_exp+0xac>  // b.lo, b.ul, b.last
    22e0:	mov	w9, #0xa2b1                	// #41649
    22e4:	movk	w9, #0x3ff0, lsl #16
    22e8:	cmp	w10, w9
    22ec:	b.hi	2390 <pts_ieee754_exp+0x110>  // b.pmore
    22f0:	fmov	d1, #1.000000000000000000e+00
    22f4:	fcmp	d0, d1
    22f8:	b.ne	24a0 <pts_ieee754_exp+0x220>  // b.any
    22fc:	adrp	x8, 0 <pts_ieee754_acos>
    2300:	ldr	d0, [x8]
    2304:	ret
    2308:	adrp	x9, 0 <pts_ieee754_acos>
    230c:	ldr	d1, [x9]
    2310:	fcmp	d0, d1
    2314:	b.le	2374 <pts_ieee754_exp+0xf4>
    2318:	adrp	x8, 0 <pts_ieee754_acos>
    231c:	ldr	d0, [x8]
    2320:	ldr	d1, [x8]
    2324:	fmul	d0, d0, d1
    2328:	ret
    232c:	lsr	w8, w10, #20
    2330:	cmp	w8, #0x3e2
    2334:	b.hi	2358 <pts_ieee754_exp+0xd8>  // b.pmore
    2338:	adrp	x8, 0 <pts_ieee754_acos>
    233c:	ldr	d1, [x8]
    2340:	fadd	d2, d1, d0
    2344:	fmov	d1, #1.000000000000000000e+00
    2348:	fcmp	d2, d1
    234c:	b.le	2358 <pts_ieee754_exp+0xd8>
    2350:	fadd	d0, d0, d1
    2354:	ret
    2358:	fmul	d3, d0, d0
    235c:	movi	d1, #0x0
    2360:	movi	d2, #0x0
    2364:	mov	w8, wzr
    2368:	mov	w9, #0x1                   	// #1
    236c:	mov	w10, #0x3ff00000            	// #1072693248
    2370:	b	23e4 <pts_ieee754_exp+0x164>
    2374:	adrp	x9, 0 <pts_ieee754_acos>
    2378:	ldr	d1, [x9]
    237c:	fcmp	d0, d1
    2380:	b.pl	2390 <pts_ieee754_exp+0x110>  // b.nfrst
    2384:	adrp	x8, 0 <pts_ieee754_acos>
    2388:	ldr	d0, [x8]
    238c:	b	2494 <pts_ieee754_exp+0x214>
    2390:	adrp	x9, 0 <pts_ieee754_acos>
    2394:	add	x9, x9, #0x0
    2398:	adrp	x10, 0 <pts_ieee754_acos>
    239c:	ldr	d1, [x9, w8, uxtw #3]
    23a0:	ldr	d2, [x10]
    23a4:	adrp	x9, 0 <pts_ieee754_acos>
    23a8:	adrp	x10, 0 <pts_ieee754_acos>
    23ac:	mov	w11, #0x3ff00000            	// #1072693248
    23b0:	fmadd	d1, d0, d2, d1
    23b4:	ldr	d2, [x9]
    23b8:	ldr	d3, [x10]
    23bc:	mov	w10, #0x7e700000            	// #2121269248
    23c0:	fcvtzs	w8, d1
    23c4:	scvtf	d1, w8
    23c8:	cmn	w8, #0x3fe
    23cc:	cset	w9, gt
    23d0:	csel	w10, w11, w10, gt
    23d4:	fmul	d2, d1, d2
    23d8:	fmadd	d1, d1, d3, d0
    23dc:	fsub	d0, d1, d2
    23e0:	fmul	d3, d0, d0
    23e4:	adrp	x11, 0 <pts_ieee754_acos>
    23e8:	adrp	x12, 0 <pts_ieee754_acos>
    23ec:	ldr	d4, [x11]
    23f0:	ldr	d5, [x12]
    23f4:	adrp	x11, 0 <pts_ieee754_acos>
    23f8:	fmadd	d4, d3, d5, d4
    23fc:	ldr	d5, [x11]
    2400:	adrp	x11, 0 <pts_ieee754_acos>
    2404:	fmadd	d4, d3, d4, d5
    2408:	ldr	d5, [x11]
    240c:	adrp	x11, 0 <pts_ieee754_acos>
    2410:	fmadd	d4, d3, d4, d5
    2414:	ldr	d5, [x11]
    2418:	fmadd	d4, d3, d4, d5
    241c:	fmsub	d4, d3, d4, d0
    2420:	fmul	d3, d0, d4
    2424:	cbz	w8, 2470 <pts_ieee754_exp+0x1f0>
    2428:	fmov	d0, #2.000000000000000000e+00
    242c:	add	w10, w10, w8, lsl #20
    2430:	lsl	x10, x10, #32
    2434:	fsub	d0, d0, d4
    2438:	fdiv	d0, d3, d0
    243c:	fsub	d0, d2, d0
    2440:	fsub	d0, d1, d0
    2444:	fmov	d1, #1.000000000000000000e+00
    2448:	fadd	d0, d0, d1
    244c:	fmov	d1, x10
    2450:	cbz	w9, 248c <pts_ieee754_exp+0x20c>
    2454:	cmp	w8, #0x400
    2458:	b.ne	2498 <pts_ieee754_exp+0x218>  // b.any
    245c:	fadd	d0, d0, d0
    2460:	adrp	x8, 0 <pts_ieee754_acos>
    2464:	ldr	d1, [x8]
    2468:	fmul	d0, d0, d1
    246c:	ret
    2470:	fmov	d1, #-2.000000000000000000e+00
    2474:	fadd	d1, d4, d1
    2478:	fdiv	d1, d3, d1
    247c:	fsub	d0, d0, d1
    2480:	fmov	d1, #1.000000000000000000e+00
    2484:	fadd	d0, d0, d1
    2488:	ret
    248c:	fmul	d0, d0, d1
    2490:	adrp	x8, 0 <pts_ieee754_acos>
    2494:	ldr	d1, [x8]
    2498:	fmul	d0, d0, d1
    249c:	ret
    24a0:	mov	w9, w8
    24a4:	adrp	x10, 0 <pts_ieee754_acos>
    24a8:	add	x10, x10, #0x0
    24ac:	ubfiz	x9, x9, #3, #32
    24b0:	ldr	d1, [x10, x9]
    24b4:	adrp	x10, 0 <pts_ieee754_acos>
    24b8:	add	x10, x10, #0x0
    24bc:	ldr	d2, [x10, x9]
    24c0:	eor	w9, w8, #0x1
    24c4:	fsub	d1, d0, d1
    24c8:	sub	w8, w9, w8
    24cc:	fsub	d0, d1, d2
    24d0:	fmul	d3, d0, d0
    24d4:	b	2368 <pts_ieee754_exp+0xe8>
    24d8:	nop
    24dc:	nop

00000000000024e0 <pts_ieee754_atanh>:
    24e0:	stp	x29, x30, [sp, #-32]!
    24e4:	str	x19, [sp, #16]
    24e8:	mov	x29, sp
    24ec:	fmov	x19, d0
    24f0:	mov	w9, #0x3ff00000            	// #1072693248
    24f4:	ubfx	x8, x19, #32, #31
    24f8:	cmp	w19, #0x0
    24fc:	cset	w10, ne	// ne = any
    2500:	orr	w10, w8, w10
    2504:	cmp	w10, w9
    2508:	b.ls	2518 <pts_ieee754_atanh+0x38>  // b.plast
    250c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2510:	fmov	d0, x8
    2514:	b	25a8 <pts_ieee754_atanh+0xc8>
    2518:	cmp	w8, w9
    251c:	b.ne	253c <pts_ieee754_atanh+0x5c>  // b.any
    2520:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2524:	mov	x9, #0x7ff0000000000000    	// #9218868437227405312
    2528:	fcmp	d0, #0.0
    252c:	fmov	d0, x8
    2530:	fmov	d1, x9
    2534:	fcsel	d0, d1, d0, gt
    2538:	b	25a8 <pts_ieee754_atanh+0xc8>
    253c:	adrp	x9, 0 <pts_ieee754_acos>
    2540:	ldr	d1, [x9]
    2544:	fadd	d1, d0, d1
    2548:	fcmp	d1, #0.0
    254c:	b.le	255c <pts_ieee754_atanh+0x7c>
    2550:	lsr	w9, w8, #20
    2554:	cmp	w9, #0x3e3
    2558:	b.cc	25a8 <pts_ieee754_atanh+0xc8>  // b.lo, b.ul, b.last
    255c:	fabs	d1, d0
    2560:	lsr	w8, w8, #21
    2564:	fmov	d2, #1.000000000000000000e+00
    2568:	cmp	w8, #0x1fe
    256c:	fadd	d0, d1, d1
    2570:	b.hi	2588 <pts_ieee754_atanh+0xa8>  // b.pmore
    2574:	fmul	d3, d1, d0
    2578:	fsub	d1, d2, d1
    257c:	fdiv	d1, d3, d1
    2580:	fadd	d0, d0, d1
    2584:	b	2590 <pts_ieee754_atanh+0xb0>
    2588:	fsub	d1, d2, d1
    258c:	fdiv	d0, d0, d1
    2590:	bl	540 <pts_ieee754_log1p>
    2594:	fmov	d1, #5.000000000000000000e-01
    2598:	cmp	x19, #0x0
    259c:	fmul	d2, d0, d1
    25a0:	fnmul	d0, d0, d1
    25a4:	fcsel	d0, d0, d2, lt	// lt = tstop
    25a8:	ldr	x19, [sp, #16]
    25ac:	ldp	x29, x30, [sp], #32
    25b0:	ret
    25b4:	nop
    25b8:	nop
    25bc:	nop

00000000000025c0 <pts_ieee754_log2>:
    25c0:	fmov	x10, d0
    25c4:	lsr	x8, x10, #32
    25c8:	cmp	w8, #0x100, lsl #12
    25cc:	b.ge	25fc <pts_ieee754_log2+0x3c>  // b.tcont
    25d0:	and	w8, w8, #0x7fffffff
    25d4:	orr	w8, w8, w10
    25d8:	cbz	w8, 2634 <pts_ieee754_log2+0x74>
    25dc:	tbnz	x10, #63, 273c <pts_ieee754_log2+0x17c>
    25e0:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    25e4:	mov	w9, #0xffffffca            	// #-54
    25e8:	fmov	d1, x8
    25ec:	fmul	d0, d0, d1
    25f0:	fmov	x8, d0
    25f4:	lsr	x8, x8, #32
    25f8:	b	2600 <pts_ieee754_log2+0x40>
    25fc:	mov	w9, wzr
    2600:	mov	w11, #0x7ff00000            	// #2146435072
    2604:	cmp	w8, w11
    2608:	b.lt	2618 <pts_ieee754_log2+0x58>  // b.tstop
    260c:	fadd	d1, d0, d0
    2610:	fmov	d0, d1
    2614:	ret
    2618:	cbnz	w10, 263c <pts_ieee754_log2+0x7c>
    261c:	movi	d1, #0x0
    2620:	mov	w10, #0x3ff00000            	// #1072693248
    2624:	cmp	w8, w10
    2628:	b.ne	263c <pts_ieee754_log2+0x7c>  // b.any
    262c:	fmov	d0, d1
    2630:	ret
    2634:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2638:	b	2740 <pts_ieee754_log2+0x180>
    263c:	and	w10, w8, #0xfffff
    2640:	fmov	x12, d0
    2644:	fmov	d0, #-1.000000000000000000e+00
    2648:	add	w10, w10, #0x95, lsl #12
    264c:	fmov	d6, #5.000000000000000000e-01
    2650:	add	w10, w10, #0xf64
    2654:	and	w11, w10, #0x100000
    2658:	and	x12, x12, #0xffffffff
    265c:	bfxil	w11, w8, #0, #20
    2660:	add	w8, w9, w8, asr #20
    2664:	adrp	x9, 0 <pts_ieee754_acos>
    2668:	eor	w11, w11, #0x3ff00000
    266c:	add	w8, w8, w10, lsr #20
    2670:	orr	x11, x12, x11, lsl #32
    2674:	adrp	x12, 0 <pts_ieee754_acos>
    2678:	ldr	d5, [x12]
    267c:	sub	w8, w8, #0x3ff
    2680:	fmov	d1, x11
    2684:	adrp	x11, 0 <pts_ieee754_acos>
    2688:	ldr	d4, [x11]
    268c:	adrp	x11, 0 <pts_ieee754_acos>
    2690:	add	x11, x11, #0x0
    2694:	fadd	d0, d1, d0
    2698:	fmov	d1, #2.000000000000000000e+00
    269c:	fadd	d1, d0, d1
    26a0:	fdiv	d1, d0, d1
    26a4:	fmul	d2, d1, d1
    26a8:	fmul	d3, d2, d2
    26ac:	fmadd	d4, d3, d5, d4
    26b0:	ld1r	{v5.2d}, [x11]
    26b4:	adrp	x11, 0 <pts_ieee754_acos>
    26b8:	mov	v5.d[1], v4.d[0]
    26bc:	fmul	d4, d0, d6
    26c0:	ldr	q6, [x11]
    26c4:	adrp	x11, 0 <pts_ieee754_acos>
    26c8:	fmla	v6.2d, v5.2d, v3.d[0]
    26cc:	fmul	d4, d0, d4
    26d0:	ldr	q5, [x11]
    26d4:	fmla	v5.2d, v6.2d, v3.d[0]
    26d8:	mov	v3.d[1], v2.d[0]
    26dc:	fsub	d2, d0, d4
    26e0:	fmov	x11, d2
    26e4:	fmul	v3.2d, v3.2d, v5.2d
    26e8:	scvtf	d5, w8
    26ec:	adrp	x8, 0 <pts_ieee754_acos>
    26f0:	ldr	d6, [x8]
    26f4:	and	x11, x11, #0xffffffff00000000
    26f8:	fmov	d2, x11
    26fc:	faddp	d3, v3.2d
    2700:	fsub	d0, d0, d2
    2704:	fadd	d3, d4, d3
    2708:	fsub	d0, d0, d4
    270c:	ldr	d4, [x9]
    2710:	fmadd	d0, d1, d3, d0
    2714:	fmul	d1, d2, d4
    2718:	fadd	d2, d0, d2
    271c:	fadd	d3, d1, d5
    2720:	fmul	d2, d2, d6
    2724:	fsub	d5, d5, d3
    2728:	fmadd	d0, d0, d4, d2
    272c:	fadd	d1, d1, d5
    2730:	fadd	d0, d1, d0
    2734:	fadd	d0, d3, d0
    2738:	ret
    273c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2740:	fmov	d1, x8
    2744:	fmov	d0, d1
    2748:	ret
    274c:	nop
    2750:	nop
    2754:	nop
    2758:	nop
    275c:	nop

0000000000002760 <pts_ieee754_log10>:
    2760:	fmov	x8, d0
    2764:	lsr	x9, x8, #32
    2768:	cmp	w9, #0x100, lsl #12
    276c:	b.ge	279c <pts_ieee754_log10+0x3c>  // b.tcont
    2770:	and	w9, w9, #0x7fffffff
    2774:	orr	w9, w9, w8
    2778:	cbz	w9, 27cc <pts_ieee754_log10+0x6c>
    277c:	tbnz	x8, #63, 2844 <pts_ieee754_log10+0xe4>
    2780:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    2784:	mov	w10, #0xffffffca            	// #-54
    2788:	fmov	d1, x8
    278c:	fmul	d0, d0, d1
    2790:	fmov	x8, d0
    2794:	lsr	x9, x8, #32
    2798:	b	27a0 <pts_ieee754_log10+0x40>
    279c:	mov	w10, wzr
    27a0:	mov	w11, #0x7ff00000            	// #2146435072
    27a4:	cmp	w9, w11
    27a8:	b.lt	27b4 <pts_ieee754_log10+0x54>  // b.tstop
    27ac:	fadd	d0, d0, d0
    27b0:	ret
    27b4:	cbnz	w8, 27d8 <pts_ieee754_log10+0x78>
    27b8:	movi	d0, #0x0
    27bc:	mov	w11, #0x3ff00000            	// #1072693248
    27c0:	cmp	w9, w11
    27c4:	b.ne	27d8 <pts_ieee754_log10+0x78>  // b.any
    27c8:	ret
    27cc:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    27d0:	fmov	d0, x8
    27d4:	ret
    27d8:	str	d8, [sp, #-32]!
    27dc:	stp	x29, x30, [sp, #16]
    27e0:	add	x29, sp, #0x10
    27e4:	add	w10, w10, w9, asr #20
    27e8:	and	w9, w9, #0xfffff
    27ec:	mov	w8, w8
    27f0:	sub	w10, w10, #0x3ff
    27f4:	lsr	w11, w10, #31
    27f8:	orr	w9, w9, w11, lsl #20
    27fc:	add	w10, w11, w10
    2800:	scvtf	d8, w10
    2804:	eor	w9, w9, #0x3ff00000
    2808:	orr	x8, x8, x9, lsl #32
    280c:	fmov	d0, x8
    2810:	bl	300 <pts_ieee754_log>
    2814:	adrp	x8, 0 <pts_ieee754_acos>
    2818:	ldr	d1, [x8]
    281c:	adrp	x8, 0 <pts_ieee754_acos>
    2820:	fmul	d0, d0, d1
    2824:	ldr	d1, [x8]
    2828:	adrp	x8, 0 <pts_ieee754_acos>
    282c:	fmadd	d0, d8, d1, d0
    2830:	ldr	d1, [x8]
    2834:	fmadd	d0, d8, d1, d0
    2838:	ldp	x29, x30, [sp, #16]
    283c:	ldr	d8, [sp], #32
    2840:	ret
    2844:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2848:	fmov	d0, x8
    284c:	ret
    2850:	nop
    2854:	nop
    2858:	nop
    285c:	nop

0000000000002860 <pts_ieee754_expm1>:
    2860:	fmov	x9, d0
    2864:	mov	w11, #0x687a                	// #26746
    2868:	movk	w11, #0x4043, lsl #16
    286c:	ubfx	x10, x9, #32, #31
    2870:	lsr	x8, x9, #32
    2874:	cmp	w10, w11
    2878:	b.cc	28bc <pts_ieee754_expm1+0x5c>  // b.lo, b.ul, b.last
    287c:	mov	w11, #0x2e42                	// #11842
    2880:	movk	w11, #0x4086, lsl #16
    2884:	cmp	w10, w11
    2888:	b.cc	294c <pts_ieee754_expm1+0xec>  // b.lo, b.ul, b.last
    288c:	lsr	w10, w10, #20
    2890:	cmp	w10, #0x7ff
    2894:	b.cc	2928 <pts_ieee754_expm1+0xc8>  // b.lo, b.ul, b.last
    2898:	fmov	d1, #-1.000000000000000000e+00
    289c:	tst	w8, #0x80000000
    28a0:	fadd	d2, d0, d0
    28a4:	and	w8, w8, #0xfffff
    28a8:	orr	w8, w8, w9
    28ac:	fcsel	d0, d0, d1, eq	// eq = none
    28b0:	cmp	w8, #0x0
    28b4:	fcsel	d0, d0, d2, eq	// eq = none
    28b8:	ret
    28bc:	mov	w9, #0x2e43                	// #11843
    28c0:	movk	w9, #0x3fd6, lsl #16
    28c4:	cmp	w10, w9
    28c8:	b.cc	28fc <pts_ieee754_expm1+0x9c>  // b.lo, b.ul, b.last
    28cc:	mov	w9, #0xa2b1                	// #41649
    28d0:	movk	w9, #0x3ff0, lsl #16
    28d4:	cmp	w10, w9
    28d8:	b.hi	296c <pts_ieee754_expm1+0x10c>  // b.pmore
    28dc:	tbnz	w8, #31, 2ad4 <pts_ieee754_expm1+0x274>
    28e0:	adrp	x8, 0 <pts_ieee754_acos>
    28e4:	ldr	d1, [x8]
    28e8:	adrp	x8, 0 <pts_ieee754_acos>
    28ec:	ldr	d2, [x8]
    28f0:	mov	w8, #0x1                   	// #1
    28f4:	fadd	d1, d0, d1
    28f8:	b	29a8 <pts_ieee754_expm1+0x148>
    28fc:	lsr	w8, w10, #20
    2900:	cmp	w8, #0x3c8
    2904:	b.hi	29b8 <pts_ieee754_expm1+0x158>  // b.pmore
    2908:	adrp	x8, 0 <pts_ieee754_acos>
    290c:	ldr	d1, [x8]
    2910:	ldr	d2, [x8]
    2914:	fadd	d1, d1, d0
    2918:	fadd	d2, d2, d0
    291c:	fsub	d1, d1, d2
    2920:	fsub	d0, d0, d1
    2924:	ret
    2928:	adrp	x9, 0 <pts_ieee754_acos>
    292c:	ldr	d1, [x9]
    2930:	fcmp	d0, d1
    2934:	b.le	294c <pts_ieee754_expm1+0xec>
    2938:	adrp	x8, 0 <pts_ieee754_acos>
    293c:	ldr	d0, [x8]
    2940:	ldr	d1, [x8]
    2944:	fmul	d0, d0, d1
    2948:	ret
    294c:	adrp	x9, 0 <pts_ieee754_acos>
    2950:	ldr	d1, [x9]
    2954:	and	w9, w8, #0x80000000
    2958:	fadd	d1, d0, d1
    295c:	fcmp	d1, #0.0
    2960:	fmov	d1, #-1.000000000000000000e+00
    2964:	ccmp	w9, #0x0, #0x4, mi	// mi = first
    2968:	b.ne	2b50 <pts_ieee754_expm1+0x2f0>  // b.any
    296c:	fmov	d1, #-5.000000000000000000e-01
    2970:	fmov	d2, #5.000000000000000000e-01
    2974:	tst	w8, #0x80000000
    2978:	adrp	x8, 0 <pts_ieee754_acos>
    297c:	adrp	x9, 0 <pts_ieee754_acos>
    2980:	adrp	x10, 0 <pts_ieee754_acos>
    2984:	ldr	d3, [x10]
    2988:	fcsel	d1, d2, d1, eq	// eq = none
    298c:	ldr	d2, [x8]
    2990:	fmadd	d1, d0, d2, d1
    2994:	fcvtzs	w8, d1
    2998:	ldr	d1, [x9]
    299c:	scvtf	d2, w8
    29a0:	fmadd	d1, d2, d1, d0
    29a4:	fmul	d2, d2, d3
    29a8:	fsub	d0, d1, d2
    29ac:	fsub	d1, d1, d0
    29b0:	fsub	d1, d1, d2
    29b4:	b	29bc <pts_ieee754_expm1+0x15c>
    29b8:	mov	w8, wzr
    29bc:	fmov	d2, #5.000000000000000000e-01
    29c0:	adrp	x9, 0 <pts_ieee754_acos>
    29c4:	adrp	x10, 0 <pts_ieee754_acos>
    29c8:	ldr	d4, [x9]
    29cc:	ldr	d5, [x10]
    29d0:	adrp	x9, 0 <pts_ieee754_acos>
    29d4:	fmul	d3, d0, d2
    29d8:	fmul	d2, d0, d3
    29dc:	fmadd	d4, d2, d5, d4
    29e0:	ldr	d5, [x9]
    29e4:	adrp	x9, 0 <pts_ieee754_acos>
    29e8:	fmadd	d4, d2, d4, d5
    29ec:	ldr	d5, [x9]
    29f0:	adrp	x9, 0 <pts_ieee754_acos>
    29f4:	fmadd	d4, d2, d4, d5
    29f8:	ldr	d5, [x9]
    29fc:	fmadd	d4, d2, d4, d5
    2a00:	fmov	d5, #1.000000000000000000e+00
    2a04:	fmadd	d4, d2, d4, d5
    2a08:	fmov	d5, #3.000000000000000000e+00
    2a0c:	fmsub	d3, d3, d4, d5
    2a10:	fmov	d5, #6.000000000000000000e+00
    2a14:	fsub	d4, d4, d3
    2a18:	fmsub	d3, d0, d3, d5
    2a1c:	fdiv	d3, d4, d3
    2a20:	fmul	d3, d2, d3
    2a24:	cbz	w8, 2a58 <pts_ieee754_expm1+0x1f8>
    2a28:	fsub	d3, d3, d1
    2a2c:	cmp	w8, #0x1
    2a30:	fnmsub	d1, d0, d3, d1
    2a34:	fsub	d1, d1, d2
    2a38:	b.eq	2a64 <pts_ieee754_expm1+0x204>  // b.none
    2a3c:	cmn	w8, #0x1
    2a40:	b.ne	2a88 <pts_ieee754_expm1+0x228>  // b.any
    2a44:	fsub	d0, d0, d1
    2a48:	fmov	d1, #-5.000000000000000000e-01
    2a4c:	fmov	d2, #5.000000000000000000e-01
    2a50:	fmadd	d0, d0, d2, d1
    2a54:	ret
    2a58:	fnmsub	d1, d0, d3, d2
    2a5c:	fsub	d0, d0, d1
    2a60:	ret
    2a64:	fmov	d2, #-2.500000000000000000e-01
    2a68:	fcmp	d0, d2
    2a6c:	b.pl	2af0 <pts_ieee754_expm1+0x290>  // b.nfrst
    2a70:	fmov	d2, #5.000000000000000000e-01
    2a74:	fadd	d0, d0, d2
    2a78:	fsub	d0, d1, d0
    2a7c:	fmov	d1, #-2.000000000000000000e+00
    2a80:	fmul	d0, d0, d1
    2a84:	ret
    2a88:	mov	x9, #0x3ff0000000000000    	// #4607182418800017408
    2a8c:	sub	w10, w8, #0x39
    2a90:	add	x9, x9, x8, lsl #52
    2a94:	cmn	w10, #0x3b
    2a98:	fmov	d2, x9
    2a9c:	b.hi	2b04 <pts_ieee754_expm1+0x2a4>  // b.pmore
    2aa0:	fsub	d0, d0, d1
    2aa4:	fmov	d1, #1.000000000000000000e+00
    2aa8:	mov	x9, #0x7fe0000000000000    	// #9214364837600034816
    2aac:	fmov	d3, x9
    2ab0:	cmp	w8, #0x400
    2ab4:	fadd	d0, d0, d1
    2ab8:	fadd	d1, d0, d0
    2abc:	fmul	d0, d0, d2
    2ac0:	fmul	d1, d1, d3
    2ac4:	fcsel	d0, d1, d0, eq	// eq = none
    2ac8:	fmov	d1, #-1.000000000000000000e+00
    2acc:	fadd	d0, d0, d1
    2ad0:	ret
    2ad4:	adrp	x8, 0 <pts_ieee754_acos>
    2ad8:	ldr	d1, [x8]
    2adc:	adrp	x8, 0 <pts_ieee754_acos>
    2ae0:	ldr	d2, [x8]
    2ae4:	mov	w8, #0xffffffff            	// #-1
    2ae8:	fadd	d1, d0, d1
    2aec:	b	29a8 <pts_ieee754_expm1+0x148>
    2af0:	fsub	d0, d0, d1
    2af4:	fmov	d1, #1.000000000000000000e+00
    2af8:	fmov	d2, #2.000000000000000000e+00
    2afc:	fmadd	d0, d0, d2, d1
    2b00:	ret
    2b04:	lsl	w9, w8, #20
    2b08:	mov	w10, #0x3ff00000            	// #1072693248
    2b0c:	cmp	w8, #0x13
    2b10:	sub	w9, w10, w9
    2b14:	lsl	x9, x9, #32
    2b18:	fmov	d3, x9
    2b1c:	mov	w9, #0x200000              	// #2097152
    2b20:	lsr	w9, w9, w8
    2b24:	fadd	d3, d1, d3
    2b28:	sub	w9, w10, w9
    2b2c:	lsl	x9, x9, #32
    2b30:	fmov	d4, x9
    2b34:	fsub	d3, d0, d3
    2b38:	fsub	d0, d1, d0
    2b3c:	fmov	d1, #1.000000000000000000e+00
    2b40:	fadd	d1, d3, d1
    2b44:	fsub	d0, d4, d0
    2b48:	fcsel	d0, d1, d0, hi	// hi = pmore
    2b4c:	fmul	d1, d0, d2
    2b50:	fmov	d0, d1
    2b54:	ret
    2b58:	nop
    2b5c:	nop

0000000000002b60 <pts_ieee754_cbrt>:
    2b60:	fmov	x10, d0
    2b64:	lsr	x8, x10, #32
    2b68:	ubfx	w9, w8, #20, #11
    2b6c:	cmp	w9, #0x7ff
    2b70:	b.cc	2b7c <pts_ieee754_cbrt+0x1c>  // b.lo, b.ul, b.last
    2b74:	fadd	d0, d0, d0
    2b78:	ret
    2b7c:	ubfx	x9, x10, #32, #31
    2b80:	lsr	w11, w9, #20
    2b84:	cbnz	w11, 2bb0 <pts_ieee754_cbrt+0x50>
    2b88:	orr	w9, w9, w10
    2b8c:	cbz	w9, 2b78 <pts_ieee754_cbrt+0x18>
    2b90:	mov	x9, #0x4350000000000000    	// #4850376798678024192
    2b94:	mov	w10, #0x7893                	// #30867
    2b98:	fmov	d1, x9
    2b9c:	movk	w10, #0x297f, lsl #16
    2ba0:	fmul	d1, d0, d1
    2ba4:	fmov	x9, d1
    2ba8:	ubfx	x9, x9, #32, #31
    2bac:	b	2bb8 <pts_ieee754_cbrt+0x58>
    2bb0:	mov	w10, #0x7893                	// #30867
    2bb4:	movk	w10, #0x2a9f, lsl #16
    2bb8:	mov	w11, #0x5556                	// #21846
    2bbc:	and	w8, w8, #0x80000000
    2bc0:	movk	w11, #0x5555, lsl #16
    2bc4:	umull	x9, w9, w11
    2bc8:	lsr	x9, x9, #32
    2bcc:	add	w9, w9, w10
    2bd0:	orr	w8, w9, w8
    2bd4:	adrp	x9, 0 <pts_ieee754_acos>
    2bd8:	lsl	x8, x8, #32
    2bdc:	ldr	q6, [x9]
    2be0:	mov	w9, #0x80000000            	// #-2147483648
    2be4:	fmov	d1, x8
    2be8:	adrp	x8, 0 <pts_ieee754_acos>
    2bec:	ldr	q5, [x8]
    2bf0:	adrp	x8, 0 <pts_ieee754_acos>
    2bf4:	fdiv	d2, d1, d0
    2bf8:	fmul	d3, d1, d1
    2bfc:	fmul	d2, d3, d2
    2c00:	fmul	d3, d2, d2
    2c04:	dup	v4.2d, v2.d[0]
    2c08:	fmla	v6.2d, v5.2d, v2.d[0]
    2c0c:	fmul	d3, d2, d3
    2c10:	mov	v4.d[0], v3.d[0]
    2c14:	fmul	v2.2d, v4.2d, v6.2d
    2c18:	ldr	d4, [x8]
    2c1c:	mov	d3, v2.d[1]
    2c20:	fadd	d3, d3, d4
    2c24:	fadd	d2, d2, d3
    2c28:	fmul	d1, d2, d1
    2c2c:	fmov	x8, d1
    2c30:	and	x8, x8, #0xffffffffc0000000
    2c34:	add	x8, x8, x9
    2c38:	fmov	d1, x8
    2c3c:	fmul	d2, d1, d1
    2c40:	fdiv	d0, d0, d2
    2c44:	fadd	d2, d1, d1
    2c48:	fsub	d3, d0, d1
    2c4c:	fadd	d0, d2, d0
    2c50:	fdiv	d0, d3, d0
    2c54:	fmadd	d0, d0, d1, d1
    2c58:	ret
    2c5c:	nop

0000000000002c60 <pts_ieee754_sin>:
    2c60:	sub	sp, sp, #0x20
    2c64:	stp	x29, x30, [sp, #16]
    2c68:	add	x29, sp, #0x10
    2c6c:	fmov	x8, d0
    2c70:	mov	w10, #0x21fb                	// #8699
    2c74:	movk	w10, #0x3fe9, lsl #16
    2c78:	ubfx	x9, x8, #32, #31
    2c7c:	cmp	w9, w10
    2c80:	b.hi	2cec <pts_ieee754_sin+0x8c>  // b.pmore
    2c84:	ubfx	x8, x8, #54, #9
    2c88:	cmp	x8, #0xf8
    2c8c:	b.hi	2c98 <pts_ieee754_sin+0x38>  // b.pmore
    2c90:	fcvtzs	w8, d0
    2c94:	cbz	w8, 2cfc <pts_ieee754_sin+0x9c>
    2c98:	fmul	d1, d0, d0
    2c9c:	adrp	x8, 0 <pts_ieee754_acos>
    2ca0:	adrp	x9, 0 <pts_ieee754_acos>
    2ca4:	ldr	d2, [x8]
    2ca8:	ldr	d3, [x9]
    2cac:	adrp	x8, 0 <pts_ieee754_acos>
    2cb0:	fmadd	d2, d1, d3, d2
    2cb4:	ldr	d3, [x8]
    2cb8:	adrp	x8, 0 <pts_ieee754_acos>
    2cbc:	fmul	d4, d1, d0
    2cc0:	fmadd	d2, d1, d2, d3
    2cc4:	ldr	d3, [x8]
    2cc8:	adrp	x8, 0 <pts_ieee754_acos>
    2ccc:	fmadd	d2, d1, d2, d3
    2cd0:	ldr	d3, [x8]
    2cd4:	adrp	x8, 0 <pts_ieee754_acos>
    2cd8:	fmadd	d2, d1, d2, d3
    2cdc:	ldr	d3, [x8]
    2ce0:	fmadd	d1, d1, d2, d3
    2ce4:	fmadd	d0, d4, d1, d0
    2ce8:	b	2cfc <pts_ieee754_sin+0x9c>
    2cec:	lsr	w8, w9, #20
    2cf0:	cmp	w8, #0x7ff
    2cf4:	b.cc	2d08 <pts_ieee754_sin+0xa8>  // b.lo, b.ul, b.last
    2cf8:	fsub	d0, d0, d0
    2cfc:	ldp	x29, x30, [sp, #16]
    2d00:	add	sp, sp, #0x20
    2d04:	ret
    2d08:	mov	x0, sp
    2d0c:	bl	1380 <__ieee754_rem_pio2>
    2d10:	ldr	d1, [sp]
    2d14:	and	w8, w0, #0x3
    2d18:	cmp	w8, #0x2
    2d1c:	b.eq	2dec <pts_ieee754_sin+0x18c>  // b.none
    2d20:	cmp	w8, #0x1
    2d24:	b.eq	2d4c <pts_ieee754_sin+0xec>  // b.none
    2d28:	cbnz	w8, 2e70 <pts_ieee754_sin+0x210>
    2d2c:	fmov	x8, d1
    2d30:	ubfx	x8, x8, #54, #9
    2d34:	cmp	x8, #0xf8
    2d38:	b.hi	2f10 <pts_ieee754_sin+0x2b0>  // b.pmore
    2d3c:	fcvtzs	w8, d1
    2d40:	cbnz	w8, 2f10 <pts_ieee754_sin+0x2b0>
    2d44:	fmov	d0, d1
    2d48:	b	2cfc <pts_ieee754_sin+0x9c>
    2d4c:	fmov	x8, d1
    2d50:	ldr	d2, [sp, #8]
    2d54:	lsr	x9, x8, #32
    2d58:	ubfx	w9, w9, #22, #9
    2d5c:	cmp	w9, #0xf8
    2d60:	b.hi	2d70 <pts_ieee754_sin+0x110>  // b.pmore
    2d64:	fcvtzs	w9, d1
    2d68:	fmov	d0, #1.000000000000000000e+00
    2d6c:	cbz	w9, 2cfc <pts_ieee754_sin+0x9c>
    2d70:	fmul	d0, d1, d1
    2d74:	adrp	x9, 0 <pts_ieee754_acos>
    2d78:	adrp	x10, 0 <pts_ieee754_acos>
    2d7c:	ldr	d3, [x9]
    2d80:	ldr	d4, [x10]
    2d84:	adrp	x9, 0 <pts_ieee754_acos>
    2d88:	ubfx	x8, x8, #32, #31
    2d8c:	fmadd	d3, d0, d4, d3
    2d90:	ldr	d4, [x9]
    2d94:	adrp	x9, 0 <pts_ieee754_acos>
    2d98:	fmadd	d3, d0, d3, d4
    2d9c:	ldr	d4, [x9]
    2da0:	adrp	x9, 0 <pts_ieee754_acos>
    2da4:	fmadd	d3, d0, d3, d4
    2da8:	ldr	d4, [x9]
    2dac:	adrp	x9, 0 <pts_ieee754_acos>
    2db0:	fmadd	d3, d0, d3, d4
    2db4:	ldr	d4, [x9]
    2db8:	mov	w9, #0x3333                	// #13107
    2dbc:	movk	w9, #0x3fd3, lsl #16
    2dc0:	cmp	w8, w9
    2dc4:	fmadd	d3, d0, d3, d4
    2dc8:	fmul	d3, d0, d3
    2dcc:	b.cs	2f78 <pts_ieee754_sin+0x318>  // b.hs, b.nlast
    2dd0:	fmul	d1, d1, d2
    2dd4:	fmov	d2, #-5.000000000000000000e-01
    2dd8:	fnmsub	d1, d0, d3, d1
    2ddc:	fmadd	d0, d0, d2, d1
    2de0:	fmov	d1, #1.000000000000000000e+00
    2de4:	fadd	d0, d0, d1
    2de8:	b	2cfc <pts_ieee754_sin+0x9c>
    2dec:	fmov	x8, d1
    2df0:	ubfx	x8, x8, #54, #9
    2df4:	cmp	x8, #0xf8
    2df8:	b.hi	2e04 <pts_ieee754_sin+0x1a4>  // b.pmore
    2dfc:	fcvtzs	w8, d1
    2e00:	cbz	w8, 2e68 <pts_ieee754_sin+0x208>
    2e04:	fmul	d0, d1, d1
    2e08:	adrp	x8, 0 <pts_ieee754_acos>
    2e0c:	adrp	x9, 0 <pts_ieee754_acos>
    2e10:	ldr	d2, [x8]
    2e14:	ldr	d3, [x9]
    2e18:	adrp	x8, 0 <pts_ieee754_acos>
    2e1c:	ldr	d5, [sp, #8]
    2e20:	fmadd	d2, d0, d3, d2
    2e24:	ldr	d3, [x8]
    2e28:	adrp	x8, 0 <pts_ieee754_acos>
    2e2c:	fmul	d4, d1, d0
    2e30:	fmadd	d2, d0, d2, d3
    2e34:	ldr	d3, [x8]
    2e38:	adrp	x8, 0 <pts_ieee754_acos>
    2e3c:	fmadd	d2, d0, d2, d3
    2e40:	ldr	d3, [x8]
    2e44:	adrp	x8, 0 <pts_ieee754_acos>
    2e48:	fmadd	d2, d0, d2, d3
    2e4c:	fmov	d3, #5.000000000000000000e-01
    2e50:	fmul	d2, d4, d2
    2e54:	fnmsub	d2, d5, d3, d2
    2e58:	fnmsub	d0, d0, d2, d5
    2e5c:	ldr	d2, [x8]
    2e60:	fmadd	d0, d4, d2, d0
    2e64:	fsub	d1, d1, d0
    2e68:	fneg	d0, d1
    2e6c:	b	2cfc <pts_ieee754_sin+0x9c>
    2e70:	fmov	x8, d1
    2e74:	ldr	d0, [sp, #8]
    2e78:	lsr	x9, x8, #32
    2e7c:	ubfx	w9, w9, #22, #9
    2e80:	cmp	w9, #0xf8
    2e84:	b.hi	2e94 <pts_ieee754_sin+0x234>  // b.pmore
    2e88:	fcvtzs	w9, d1
    2e8c:	fmov	d2, #1.000000000000000000e+00
    2e90:	cbz	w9, 2ff4 <pts_ieee754_sin+0x394>
    2e94:	fmul	d2, d1, d1
    2e98:	adrp	x9, 0 <pts_ieee754_acos>
    2e9c:	adrp	x10, 0 <pts_ieee754_acos>
    2ea0:	ldr	d3, [x9]
    2ea4:	ldr	d4, [x10]
    2ea8:	adrp	x9, 0 <pts_ieee754_acos>
    2eac:	ubfx	x8, x8, #32, #31
    2eb0:	fmadd	d3, d2, d4, d3
    2eb4:	ldr	d4, [x9]
    2eb8:	adrp	x9, 0 <pts_ieee754_acos>
    2ebc:	fmadd	d3, d2, d3, d4
    2ec0:	ldr	d4, [x9]
    2ec4:	adrp	x9, 0 <pts_ieee754_acos>
    2ec8:	fmadd	d3, d2, d3, d4
    2ecc:	ldr	d4, [x9]
    2ed0:	adrp	x9, 0 <pts_ieee754_acos>
    2ed4:	fmadd	d3, d2, d3, d4
    2ed8:	ldr	d4, [x9]
    2edc:	mov	w9, #0x3333                	// #13107
    2ee0:	movk	w9, #0x3fd3, lsl #16
    2ee4:	cmp	w8, w9
    2ee8:	fmadd	d3, d2, d3, d4
    2eec:	fmul	d3, d2, d3
    2ef0:	b.cs	2fb8 <pts_ieee754_sin+0x358>  // b.hs, b.nlast
    2ef4:	fmul	d0, d1, d0
    2ef8:	fmov	d1, #-5.000000000000000000e-01
    2efc:	fnmsub	d0, d2, d3, d0
    2f00:	fmadd	d0, d2, d1, d0
    2f04:	fmov	d1, #1.000000000000000000e+00
    2f08:	fadd	d2, d0, d1
    2f0c:	b	2ff4 <pts_ieee754_sin+0x394>
    2f10:	fmul	d0, d1, d1
    2f14:	adrp	x8, 0 <pts_ieee754_acos>
    2f18:	adrp	x9, 0 <pts_ieee754_acos>
    2f1c:	ldr	d2, [x8]
    2f20:	ldr	d3, [x9]
    2f24:	adrp	x8, 0 <pts_ieee754_acos>
    2f28:	ldr	d5, [sp, #8]
    2f2c:	fmadd	d2, d0, d3, d2
    2f30:	ldr	d3, [x8]
    2f34:	adrp	x8, 0 <pts_ieee754_acos>
    2f38:	fmul	d4, d1, d0
    2f3c:	fmadd	d2, d0, d2, d3
    2f40:	ldr	d3, [x8]
    2f44:	adrp	x8, 0 <pts_ieee754_acos>
    2f48:	fmadd	d2, d0, d2, d3
    2f4c:	ldr	d3, [x8]
    2f50:	adrp	x8, 0 <pts_ieee754_acos>
    2f54:	fmadd	d2, d0, d2, d3
    2f58:	fmov	d3, #5.000000000000000000e-01
    2f5c:	fmul	d2, d4, d2
    2f60:	fnmsub	d2, d5, d3, d2
    2f64:	fnmsub	d0, d0, d2, d5
    2f68:	ldr	d2, [x8]
    2f6c:	fmadd	d0, d4, d2, d0
    2f70:	fsub	d0, d1, d0
    2f74:	b	2cfc <pts_ieee754_sin+0x9c>
    2f78:	sub	w9, w8, #0x200, lsl #12
    2f7c:	fmov	d4, #2.812500000000000000e-01
    2f80:	mov	w10, #0x3fe90000            	// #1072234496
    2f84:	lsl	x9, x9, #32
    2f88:	cmp	w8, w10
    2f8c:	fmul	d1, d1, d2
    2f90:	fmov	d2, #5.000000000000000000e-01
    2f94:	fmov	d5, x9
    2f98:	fcsel	d4, d4, d5, hi	// hi = pmore
    2f9c:	fnmsub	d2, d0, d2, d4
    2fa0:	fnmsub	d0, d0, d3, d1
    2fa4:	fmov	d1, #1.000000000000000000e+00
    2fa8:	fsub	d1, d1, d4
    2fac:	fsub	d0, d0, d2
    2fb0:	fadd	d0, d1, d0
    2fb4:	b	2cfc <pts_ieee754_sin+0x9c>
    2fb8:	sub	w9, w8, #0x200, lsl #12
    2fbc:	fmov	d4, #2.812500000000000000e-01
    2fc0:	mov	w10, #0x3fe90000            	// #1072234496
    2fc4:	lsl	x9, x9, #32
    2fc8:	cmp	w8, w10
    2fcc:	fmul	d0, d1, d0
    2fd0:	fmov	d1, #5.000000000000000000e-01
    2fd4:	fmov	d5, x9
    2fd8:	fnmsub	d0, d2, d3, d0
    2fdc:	fcsel	d4, d4, d5, hi	// hi = pmore
    2fe0:	fnmsub	d1, d2, d1, d4
    2fe4:	fmov	d2, #1.000000000000000000e+00
    2fe8:	fsub	d2, d2, d4
    2fec:	fsub	d0, d0, d1
    2ff0:	fadd	d2, d2, d0
    2ff4:	fneg	d0, d2
    2ff8:	b	2cfc <pts_ieee754_sin+0x9c>
    2ffc:	nop

0000000000003000 <pts_ieee754_tan>:
    3000:	fmov	x8, d0
    3004:	mov	w9, #0x21fb                	// #8699
    3008:	movk	w9, #0x3fe9, lsl #16
    300c:	ubfx	x8, x8, #32, #31
    3010:	cmp	w8, w9
    3014:	b.hi	3024 <pts_ieee754_tan+0x24>  // b.pmore
    3018:	movi	d1, #0x0
    301c:	mov	w0, #0x1                   	// #1
    3020:	b	3080 <__kernel_tan>
    3024:	lsr	w8, w8, #20
    3028:	cmp	w8, #0x7ff
    302c:	b.cc	3038 <pts_ieee754_tan+0x38>  // b.lo, b.ul, b.last
    3030:	fsub	d0, d0, d0
    3034:	ret
    3038:	sub	sp, sp, #0x20
    303c:	stp	x29, x30, [sp, #16]
    3040:	add	x29, sp, #0x10
    3044:	mov	x0, sp
    3048:	bl	1380 <__ieee754_rem_pio2>
    304c:	ubfiz	w8, w0, #1, #1
    3050:	ldp	d0, d1, [sp]
    3054:	mov	w9, #0x1                   	// #1
    3058:	sub	w0, w9, w8
    305c:	ldp	x29, x30, [sp, #16]
    3060:	add	sp, sp, #0x20
    3064:	b	3080 <__kernel_tan>
    3068:	nop
    306c:	nop
    3070:	nop
    3074:	nop
    3078:	nop
    307c:	nop

0000000000003080 <__kernel_tan>:
    3080:	fmov	x11, d0
    3084:	fcvtzs	w10, d0
    3088:	lsr	x8, x11, #32
    308c:	ubfx	w9, w8, #20, #11
    3090:	cmp	w9, #0x3e2
    3094:	ubfx	x9, x11, #32, #31
    3098:	ccmp	w10, #0x0, #0x0, ls	// ls = plast
    309c:	b.eq	31d8 <__kernel_tan+0x158>  // b.none
    30a0:	mov	w10, #0x9428                	// #37928
    30a4:	movk	w10, #0x3fe5, lsl #16
    30a8:	cmp	w9, w10
    30ac:	b.cc	30e4 <__kernel_tan+0x64>  // b.lo, b.ul, b.last
    30b0:	fneg	d2, d0
    30b4:	fneg	d3, d1
    30b8:	cmp	x11, #0x0
    30bc:	adrp	x11, 0 <pts_ieee754_acos>
    30c0:	adrp	x12, 0 <pts_ieee754_acos>
    30c4:	fcsel	d1, d3, d1, lt	// lt = tstop
    30c8:	fcsel	d0, d2, d0, lt	// lt = tstop
    30cc:	ldr	d2, [x11]
    30d0:	ldr	d3, [x12]
    30d4:	fsub	d0, d2, d0
    30d8:	fsub	d1, d3, d1
    30dc:	fadd	d0, d0, d1
    30e0:	movi	d1, #0x0
    30e4:	fmul	d2, d0, d0
    30e8:	adrp	x11, 0 <pts_ieee754_acos>
    30ec:	adrp	x12, 0 <pts_ieee754_acos>
    30f0:	ldr	d4, [x11]
    30f4:	adrp	x11, 0 <pts_ieee754_acos>
    30f8:	adrp	x13, 0 <pts_ieee754_acos>
    30fc:	ldr	d5, [x11]
    3100:	ldr	d6, [x12]
    3104:	ldr	d7, [x13]
    3108:	adrp	x11, 0 <pts_ieee754_acos>
    310c:	adrp	x12, 0 <pts_ieee754_acos>
    3110:	cmp	w9, w10
    3114:	fmul	d3, d2, d2
    3118:	fmadd	d4, d3, d5, d4
    311c:	fmadd	d5, d3, d7, d6
    3120:	ldr	d6, [x11]
    3124:	ldr	d7, [x12]
    3128:	adrp	x11, 0 <pts_ieee754_acos>
    312c:	adrp	x12, 0 <pts_ieee754_acos>
    3130:	fmadd	d4, d3, d4, d6
    3134:	fmadd	d5, d3, d5, d7
    3138:	ldr	d6, [x11]
    313c:	ldr	d7, [x12]
    3140:	adrp	x11, 0 <pts_ieee754_acos>
    3144:	adrp	x12, 0 <pts_ieee754_acos>
    3148:	fmadd	d4, d3, d4, d6
    314c:	fmadd	d5, d3, d5, d7
    3150:	ldr	d6, [x11]
    3154:	ldr	d7, [x12]
    3158:	adrp	x11, 0 <pts_ieee754_acos>
    315c:	adrp	x12, 0 <pts_ieee754_acos>
    3160:	fmadd	d4, d3, d4, d6
    3164:	fmadd	d5, d3, d5, d7
    3168:	ldr	d6, [x11]
    316c:	ldr	d7, [x12]
    3170:	adrp	x11, 0 <pts_ieee754_acos>
    3174:	fmadd	d4, d3, d4, d6
    3178:	fmadd	d3, d3, d5, d7
    317c:	fmul	d5, d0, d2
    3180:	fmadd	d3, d2, d3, d4
    3184:	fmadd	d3, d5, d3, d1
    3188:	fmadd	d1, d2, d3, d1
    318c:	ldr	d2, [x11]
    3190:	fmadd	d2, d5, d2, d1
    3194:	fadd	d1, d0, d2
    3198:	b.cc	31f4 <__kernel_tan+0x174>  // b.lo, b.ul, b.last
    319c:	scvtf	d3, w0
    31a0:	fmul	d4, d1, d1
    31a4:	lsr	w8, w8, #31
    31a8:	mov	w9, #0x1                   	// #1
    31ac:	sub	w8, w9, w8, lsl #1
    31b0:	fadd	d1, d1, d3
    31b4:	fdiv	d1, d4, d1
    31b8:	fsub	d1, d1, d2
    31bc:	scvtf	d2, w8
    31c0:	fsub	d0, d0, d1
    31c4:	fmov	d1, #-2.000000000000000000e+00
    31c8:	fmadd	d0, d0, d1, d3
    31cc:	fmul	d1, d0, d2
    31d0:	fmov	d0, d1
    31d4:	ret
    31d8:	add	w8, w0, #0x1
    31dc:	orr	w8, w8, w11
    31e0:	orr	w8, w8, w9
    31e4:	cbz	w8, 3234 <__kernel_tan+0x1b4>
    31e8:	cmp	w0, #0x1
    31ec:	b.ne	3248 <__kernel_tan+0x1c8>  // b.any
    31f0:	ret
    31f4:	cmp	w0, #0x1
    31f8:	b.eq	327c <__kernel_tan+0x1fc>  // b.none
    31fc:	fmov	d3, #-1.000000000000000000e+00
    3200:	movi	v4.2d, #0xffffffff00000000
    3204:	fmov	d5, #1.000000000000000000e+00
    3208:	fdiv	d3, d3, d1
    320c:	mov	v1.d[1], v3.d[0]
    3210:	and	v1.16b, v1.16b, v4.16b
    3214:	fsub	d0, d1, d0
    3218:	mov	d4, v1.d[1]
    321c:	fsub	d0, d2, d0
    3220:	fmadd	d2, d1, d4, d5
    3224:	fmla	d2, d0, v1.d[1]
    3228:	fmadd	d1, d3, d2, d4
    322c:	fmov	d0, d1
    3230:	ret
    3234:	fabs	d0, d0
    3238:	fmov	d1, #1.000000000000000000e+00
    323c:	fdiv	d1, d1, d0
    3240:	fmov	d0, d1
    3244:	ret
    3248:	fadd	d2, d0, d1
    324c:	fmov	d3, #-1.000000000000000000e+00
    3250:	movi	v4.2d, #0xffffffff00000000
    3254:	fmov	d5, #1.000000000000000000e+00
    3258:	fdiv	d3, d3, d2
    325c:	mov	v2.d[1], v3.d[0]
    3260:	and	v2.16b, v2.16b, v4.16b
    3264:	fsub	d0, d2, d0
    3268:	mov	d4, v2.d[1]
    326c:	fsub	d0, d1, d0
    3270:	fmadd	d1, d2, d4, d5
    3274:	fmla	d1, d0, v2.d[1]
    3278:	fmadd	d1, d3, d1, d4
    327c:	fmov	d0, d1
    3280:	ret
    3284:	nop
    3288:	nop
    328c:	nop
    3290:	nop
    3294:	nop
    3298:	nop
    329c:	nop

00000000000032a0 <pts_ieee754_cosh>:
    32a0:	str	d8, [sp, #-32]!
    32a4:	stp	x29, x30, [sp, #8]
    32a8:	str	x19, [sp, #24]
    32ac:	add	x29, sp, #0x8
    32b0:	fmov	x8, d0
    32b4:	ubfx	x19, x8, #32, #31
    32b8:	mov	w8, #0x2e42                	// #11842
    32bc:	movk	w8, #0x3fd6, lsl #16
    32c0:	cmp	w19, w8
    32c4:	b.hi	32fc <pts_ieee754_cosh+0x5c>  // b.pmore
    32c8:	fabs	d0, d0
    32cc:	bl	2860 <pts_ieee754_expm1>
    32d0:	fmov	d2, #1.000000000000000000e+00
    32d4:	fmov	d1, d0
    32d8:	lsr	w8, w19, #23
    32dc:	cmp	w8, #0x79
    32e0:	fadd	d0, d0, d2
    32e4:	b.cc	338c <pts_ieee754_cosh+0xec>  // b.lo, b.ul, b.last
    32e8:	fmul	d1, d1, d1
    32ec:	fadd	d0, d0, d0
    32f0:	fdiv	d0, d1, d0
    32f4:	fadd	d0, d0, d2
    32f8:	b	338c <pts_ieee754_cosh+0xec>
    32fc:	mov	w8, #0x4035ffff            	// #1077280767
    3300:	cmp	w19, w8
    3304:	b.hi	3320 <pts_ieee754_cosh+0x80>  // b.pmore
    3308:	fabs	d0, d0
    330c:	bl	2280 <pts_ieee754_exp>
    3310:	fmov	d1, #5.000000000000000000e-01
    3314:	fdiv	d2, d1, d0
    3318:	fmadd	d0, d0, d1, d2
    331c:	b	338c <pts_ieee754_cosh+0xec>
    3320:	fabs	d1, d0
    3324:	mov	w8, #0x2e41                	// #11841
    3328:	movk	w8, #0x4086, lsl #16
    332c:	cmp	w19, w8
    3330:	b.hi	3344 <pts_ieee754_cosh+0xa4>  // b.pmore
    3334:	fmov	d0, d1
    3338:	bl	2280 <pts_ieee754_exp>
    333c:	fmov	d1, #5.000000000000000000e-01
    3340:	b	3388 <pts_ieee754_cosh+0xe8>
    3344:	adrp	x8, 0 <pts_ieee754_acos>
    3348:	ldr	d2, [x8]
    334c:	fcmp	d1, d2
    3350:	b.ls	3368 <pts_ieee754_cosh+0xc8>  // b.plast
    3354:	lsr	w8, w19, #20
    3358:	cmp	w8, #0x7ff
    335c:	b.cc	337c <pts_ieee754_cosh+0xdc>  // b.lo, b.ul, b.last
    3360:	fmul	d0, d0, d0
    3364:	b	338c <pts_ieee754_cosh+0xec>
    3368:	fmov	d8, #5.000000000000000000e-01
    336c:	fmul	d0, d1, d8
    3370:	bl	2280 <pts_ieee754_exp>
    3374:	fmul	d1, d0, d8
    3378:	b	3388 <pts_ieee754_cosh+0xe8>
    337c:	adrp	x8, 0 <pts_ieee754_acos>
    3380:	ldr	d0, [x8]
    3384:	ldr	d1, [x8]
    3388:	fmul	d0, d0, d1
    338c:	ldp	x29, x30, [sp, #8]
    3390:	ldr	x19, [sp, #24]
    3394:	ldr	d8, [sp], #32
    3398:	ret
    339c:	nop

00000000000033a0 <pts_ieee754_sinh>:
    33a0:	stp	d9, d8, [sp, #-32]!
    33a4:	stp	x29, x30, [sp, #16]
    33a8:	add	x29, sp, #0x10
    33ac:	fmov	d1, #5.000000000000000000e-01
    33b0:	fabs	d8, d0
    33b4:	fcmp	d0, #0.0
    33b8:	fmov	d2, #-5.000000000000000000e-01
    33bc:	fmov	d3, #2.200000000000000000e+01
    33c0:	fcsel	d9, d2, d1, mi	// mi = first
    33c4:	fcmp	d8, d3
    33c8:	b.pl	340c <pts_ieee754_sinh+0x6c>  // b.nfrst
    33cc:	mov	x8, #0x3e30000000000000    	// #4481081629233643520
    33d0:	fmov	d1, x8
    33d4:	fcmp	d8, d1
    33d8:	b.mi	3474 <pts_ieee754_sinh+0xd4>  // b.first
    33dc:	fmov	d0, d8
    33e0:	bl	2860 <pts_ieee754_expm1>
    33e4:	fmov	d1, #1.000000000000000000e+00
    33e8:	fcmp	d8, d1
    33ec:	b.pl	344c <pts_ieee754_sinh+0xac>  // b.nfrst
    33f0:	fmul	d2, d0, d0
    33f4:	fadd	d1, d0, d1
    33f8:	fdiv	d1, d2, d1
    33fc:	fmov	d2, #2.000000000000000000e+00
    3400:	fnmsub	d0, d0, d2, d1
    3404:	fmul	d0, d9, d0
    3408:	b	3474 <pts_ieee754_sinh+0xd4>
    340c:	mov	x8, #0x2e4200000000        	// #50861002719232
    3410:	movk	x8, #0x4086, lsl #48
    3414:	fmov	d1, x8
    3418:	fcmp	d8, d1
    341c:	b.pl	3430 <pts_ieee754_sinh+0x90>  // b.nfrst
    3420:	fmov	d0, d8
    3424:	bl	2280 <pts_ieee754_exp>
    3428:	fmul	d0, d9, d0
    342c:	b	3474 <pts_ieee754_sinh+0xd4>
    3430:	adrp	x8, 0 <pts_ieee754_acos>
    3434:	ldr	d1, [x8]
    3438:	fcmp	d8, d1
    343c:	b.ls	3460 <pts_ieee754_sinh+0xc0>  // b.plast
    3440:	adrp	x8, 0 <pts_ieee754_acos>
    3444:	ldr	d1, [x8]
    3448:	b	3470 <pts_ieee754_sinh+0xd0>
    344c:	fadd	d1, d0, d1
    3450:	fdiv	d1, d0, d1
    3454:	fadd	d0, d0, d1
    3458:	fmul	d0, d9, d0
    345c:	b	3474 <pts_ieee754_sinh+0xd4>
    3460:	fmov	d0, #5.000000000000000000e-01
    3464:	fmul	d0, d8, d0
    3468:	bl	2280 <pts_ieee754_exp>
    346c:	fmul	d1, d9, d0
    3470:	fmul	d0, d0, d1
    3474:	ldp	x29, x30, [sp, #16]
    3478:	ldp	d9, d8, [sp], #32
    347c:	ret

0000000000003480 <pts_ieee754_tanh>:
    3480:	stp	x29, x30, [sp, #-32]!
    3484:	str	x19, [sp, #16]
    3488:	mov	x29, sp
    348c:	fmov	x19, d0
    3490:	lsr	x8, x19, #32
    3494:	ubfx	w8, w8, #20, #11
    3498:	cmp	w8, #0x7ff
    349c:	b.cc	34c0 <pts_ieee754_tanh+0x40>  // b.lo, b.ul, b.last
    34a0:	fmov	d1, #1.000000000000000000e+00
    34a4:	fmov	d2, #-1.000000000000000000e+00
    34a8:	tst	x19, #0x8000000000000000
    34ac:	fdiv	d0, d1, d0
    34b0:	fadd	d2, d0, d2
    34b4:	fadd	d0, d0, d1
    34b8:	fcsel	d0, d2, d0, ne	// ne = any
    34bc:	b	353c <pts_ieee754_tanh+0xbc>
    34c0:	ubfx	x8, x19, #32, #31
    34c4:	mov	w9, #0x4035ffff            	// #1077280767
    34c8:	cmp	w8, w9
    34cc:	b.hi	3520 <pts_ieee754_tanh+0xa0>  // b.pmore
    34d0:	adrp	x9, 0 <pts_ieee754_acos>
    34d4:	fmov	d2, #1.000000000000000000e+00
    34d8:	lsr	w8, w8, #20
    34dc:	ldr	d1, [x9]
    34e0:	fadd	d1, d0, d1
    34e4:	fcmp	d1, d2
    34e8:	b.le	34f4 <pts_ieee754_tanh+0x74>
    34ec:	cmp	w8, #0x3e3
    34f0:	b.cc	353c <pts_ieee754_tanh+0xbc>  // b.lo, b.ul, b.last
    34f4:	fabs	d0, d0
    34f8:	cmp	w8, #0x3ff
    34fc:	b.cc	3548 <pts_ieee754_tanh+0xc8>  // b.lo, b.ul, b.last
    3500:	fadd	d0, d0, d0
    3504:	bl	2860 <pts_ieee754_expm1>
    3508:	fmov	d1, #2.000000000000000000e+00
    350c:	fadd	d0, d0, d1
    3510:	fdiv	d0, d1, d0
    3514:	fmov	d1, #1.000000000000000000e+00
    3518:	fsub	d0, d1, d0
    351c:	b	3530 <pts_ieee754_tanh+0xb0>
    3520:	adrp	x8, 0 <pts_ieee754_acos>
    3524:	fmov	d0, #1.000000000000000000e+00
    3528:	ldr	d1, [x8]
    352c:	fsub	d0, d0, d1
    3530:	fneg	d1, d0
    3534:	cmp	x19, #0x0
    3538:	fcsel	d0, d1, d0, lt	// lt = tstop
    353c:	ldr	x19, [sp, #16]
    3540:	ldp	x29, x30, [sp], #32
    3544:	ret
    3548:	fmov	d1, #-2.000000000000000000e+00
    354c:	fmul	d0, d0, d1
    3550:	bl	2860 <pts_ieee754_expm1>
    3554:	fmov	d1, #2.000000000000000000e+00
    3558:	fneg	d2, d0
    355c:	fadd	d0, d0, d1
    3560:	fdiv	d0, d2, d0
    3564:	b	3530 <pts_ieee754_tanh+0xb0>
