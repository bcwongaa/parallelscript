
gcc12/ieee754_O3.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <__kernel_rem_pio2.constprop.0>:
       0:	stp	x29, x30, [sp, #-144]!
       4:	mov	w4, #0xaaab                	// #43691
       8:	movk	w4, #0x2aaa, lsl #16
       c:	mov	x29, sp
      10:	stp	x21, x22, [sp, #32]
      14:	sub	w21, w2, #0x3
      18:	mov	w5, w3
      1c:	stp	x19, x20, [sp, #16]
      20:	smull	x4, w21, w4
      24:	stp	x23, x24, [sp, #48]
      28:	sub	w24, w3, #0x1
      2c:	stp	x25, x26, [sp, #64]
      30:	asr	x4, x4, #34
      34:	sub	w4, w4, w21, asr #31
      38:	stp	x27, x28, [sp, #80]
      3c:	mov	x27, x0
      40:	add	w0, w3, #0x3
      44:	stp	d8, d9, [sp, #96]
      48:	stp	d10, d11, [sp, #112]
      4c:	stp	d12, d13, [sp, #128]
      50:	sub	sp, sp, #0x260
      54:	str	w3, [sp, #12]
      58:	adrp	x3, 0 <__stack_chk_guard>
      5c:	ldr	x3, [x3]
      60:	ldr	x6, [x3]
      64:	str	x6, [sp, #600]
      68:	mov	x6, #0x0                   	// #0
      6c:	str	x1, [sp, #16]
      70:	add	w1, w4, #0x1
      74:	str	w4, [sp, #24]
      78:	subs	w4, w4, w24
      7c:	sub	w1, w1, w1, lsl #2
      80:	add	w23, w2, w1, lsl #3
      84:	b.pl	884 <__kernel_rem_pio2.constprop.0+0x884>  // b.nfrst
      88:	str	xzr, [sp, #280]
      8c:	cmn	w4, #0x1
      90:	b.eq	b0 <__kernel_rem_pio2.constprop.0+0xb0>  // b.none
      94:	cmp	w0, #0x1
      98:	add	w2, w5, #0x2
      9c:	csinc	w2, w2, wzr, gt
      a0:	mov	w4, #0x0                   	// #0
      a4:	mov	w1, #0x2                   	// #2
      a8:	str	xzr, [sp, #288]
      ac:	b	cc <__kernel_rem_pio2.constprop.0+0xcc>
      b0:	mov	w1, #0x1                   	// #1
      b4:	mov	w4, #0x0                   	// #0
      b8:	ldr	w2, [sp, #12]
      bc:	cmp	w0, w1
      c0:	sub	w2, w2, w1
      c4:	add	w2, w2, #0x4
      c8:	csinc	w2, w2, wzr, ge	// ge = tcont
      cc:	sbfiz	x6, x4, #2, #32
      d0:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
      d4:	add	x5, x3, #0x0
      d8:	add	x25, sp, #0x118
      dc:	sbfiz	x7, x1, #3, #32
      e0:	add	x8, x25, x7
      e4:	ldr	q0, [x5, x6]
      e8:	sxtl	v1.2d, v0.2s
      ec:	sxtl2	v0.2d, v0.4s
      f0:	scvtf	v1.2d, v1.2d
      f4:	scvtf	v0.2d, v0.2d
      f8:	str	q1, [x25, x7]
      fc:	str	q0, [x8, #16]
     100:	cmp	w2, #0x4
     104:	b.eq	154 <__kernel_rem_pio2.constprop.0+0x154>  // b.none
     108:	add	w4, w4, #0x4
     10c:	add	w7, w1, #0x4
     110:	add	w2, w1, #0x5
     114:	sbfiz	x6, x4, #2, #32
     118:	ldr	w4, [x5, w4, sxtw #2]
     11c:	scvtf	d0, w4
     120:	str	d0, [x25, w7, sxtw #3]
     124:	cmp	w0, w2
     128:	b.lt	154 <__kernel_rem_pio2.constprop.0+0x154>  // b.tstop
     12c:	add	x5, x5, x6
     130:	add	w1, w1, #0x6
     134:	ldr	w4, [x5, #4]
     138:	scvtf	d0, w4
     13c:	str	d0, [x25, w2, sxtw #3]
     140:	cmp	w0, w1
     144:	b.lt	154 <__kernel_rem_pio2.constprop.0+0x154>  // b.tstop
     148:	ldr	w2, [x5, #8]
     14c:	scvtf	d0, w2
     150:	str	d0, [x25, w1, sxtw #3]
     154:	ldr	w1, [sp, #12]
     158:	mov	x2, #0xfffffffffffffff8    	// #-8
     15c:	movi	v0.2d, #0x0
     160:	ldr	d11, [x27]
     164:	add	x2, x2, w1, sxtw #3
     168:	dup	v4.2d, v11.d[0]
     16c:	add	x1, x25, x2
     170:	mov	v1.16b, v0.16b
     174:	ldr	q2, [x25, x2]
     178:	fmla	v1.2d, v2.2d, v11.d[0]
     17c:	cbz	w24, 8fc <__kernel_rem_pio2.constprop.0+0x8fc>
     180:	ldur	q2, [x1, #-8]
     184:	mov	v0.16b, v1.16b
     188:	ldr	d3, [x27, #8]
     18c:	dup	v1.2d, v3.d[0]
     190:	fmla	v0.2d, v2.2d, v3.d[0]
     194:	cmp	w24, #0x2
     198:	b.ne	1a8 <__kernel_rem_pio2.constprop.0+0x1a8>  // b.any
     19c:	ldur	q2, [x1, #-16]
     1a0:	ldr	d5, [x27, #16]
     1a4:	fmla	v0.2d, v2.2d, v5.d[0]
     1a8:	ldr	q5, [x1, #16]
     1ac:	str	q0, [sp, #112]
     1b0:	movi	v2.2d, #0x0
     1b4:	ldur	q0, [x1, #8]
     1b8:	fmla	v2.2d, v5.2d, v4.2d
     1bc:	fmla	v2.2d, v0.2d, v1.2d
     1c0:	cmp	w24, #0x2
     1c4:	b.ne	1d4 <__kernel_rem_pio2.constprop.0+0x1d4>  // b.any
     1c8:	ldr	q0, [x25, x2]
     1cc:	ldr	d1, [x27, #16]
     1d0:	fmla	v2.2d, v0.2d, v1.d[0]
     1d4:	ldr	d1, [x25, w0, sxtw #3]
     1d8:	movi	d0, #0x0
     1dc:	ldr	w0, [sp, #12]
     1e0:	str	q2, [sp, #128]
     1e4:	add	w0, w0, #0x2
     1e8:	fmadd	d0, d1, d11, d0
     1ec:	ldr	d1, [x25, w0, sxtw #3]
     1f0:	fmadd	d0, d3, d1, d0
     1f4:	cmp	w24, #0x2
     1f8:	b.ne	208 <__kernel_rem_pio2.constprop.0+0x208>  // b.any
     1fc:	ldr	d1, [x27, #16]
     200:	ldr	d2, [sp, #312]
     204:	fmadd	d0, d2, d1, d0
     208:	add	x26, sp, #0x70
     20c:	add	x28, sp, #0x20
     210:	mov	x1, #0x3e70000000000000    	// #4499096027743125504
     214:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     218:	fmov	d13, x1
     21c:	fmov	d12, x0
     220:	mov	w21, #0x4                   	// #4
     224:	fmov	d9, #1.250000000000000000e-01
     228:	fmov	d8, #8.000000000000000000e+00
     22c:	str	d0, [sp, #144]
     230:	sxtw	x22, w21
     234:	sbfiz	x20, x21, #3, #32
     238:	add	x1, x26, x20
     23c:	mov	x4, x28
     240:	mov	x0, x28
     244:	mov	w19, w21
     248:	ldr	d0, [x26, x22, lsl #3]
     24c:	nop
     250:	fmul	d1, d0, d13
     254:	ldr	d3, [x1, #-8]!
     258:	subs	w19, w19, #0x1
     25c:	fcvtzs	w2, d1
     260:	scvtf	d1, w2
     264:	fmsub	d2, d1, d12, d0
     268:	fadd	d0, d1, d3
     26c:	fcvtzs	w2, d2
     270:	str	w2, [x0], #4
     274:	b.ne	250 <__kernel_rem_pio2.constprop.0+0x250>  // b.any
     278:	mov	w0, w23
     27c:	str	x4, [sp]
     280:	bl	0 <scalbn>
     284:	fmul	d1, d0, d9
     288:	ldr	x4, [sp]
     28c:	cmp	w23, #0x0
     290:	frintm	d1, d1
     294:	fmsub	d0, d1, d8, d0
     298:	fcvtzs	w8, d0
     29c:	scvtf	d1, w8
     2a0:	fsub	d10, d0, d1
     2a4:	b.le	4cc <__kernel_rem_pio2.constprop.0+0x4cc>
     2a8:	sub	w0, w21, #0x1
     2ac:	mov	w9, #0x18                  	// #24
     2b0:	sub	w9, w9, w23
     2b4:	mov	w10, #0x17                  	// #23
     2b8:	sxtw	x0, w0
     2bc:	sub	w10, w10, w23
     2c0:	ldr	w1, [x28, x0, lsl #2]
     2c4:	asr	w2, w1, w9
     2c8:	add	w8, w8, w2
     2cc:	lsl	w2, w2, w9
     2d0:	sub	w1, w1, w2
     2d4:	str	w1, [x28, x0, lsl #2]
     2d8:	asr	w1, w1, w10
     2dc:	cmp	w1, #0x0
     2e0:	b.gt	4e4 <__kernel_rem_pio2.constprop.0+0x4e4>
     2e4:	fcmp	d10, #0.0
     2e8:	b.ne	598 <__kernel_rem_pio2.constprop.0+0x598>  // b.any
     2ec:	sub	w4, w21, #0x1
     2f0:	mov	w0, w4
     2f4:	cmp	w4, #0x3
     2f8:	b.eq	400 <__kernel_rem_pio2.constprop.0+0x400>  // b.none
     2fc:	sub	w11, w21, #0x5
     300:	sub	w2, w21, #0x4
     304:	cmp	w11, #0x3
     308:	b.ls	3b8 <__kernel_rem_pio2.constprop.0+0x3b8>  // b.plast
     30c:	mov	x0, #0xfffffffffffffff0    	// #-16
     310:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     314:	add	x0, x0, w21, sxtw #2
     318:	lsr	w9, w2, #2
     31c:	ldr	q4, [x3]
     320:	add	x10, x28, x0
     324:	ldr	q0, [x28, x0]
     328:	mov	v1.16b, v0.16b
     32c:	tbl	v0.16b, {v0.16b-v1.16b}, v4.16b
     330:	cmp	w9, #0x1
     334:	b.eq	64c <__kernel_rem_pio2.constprop.0+0x64c>  // b.none
     338:	ldur	q2, [x10, #-16]
     33c:	mov	v3.16b, v2.16b
     340:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     344:	orr	v0.16b, v0.16b, v2.16b
     348:	cmp	w9, #0x2
     34c:	b.eq	390 <__kernel_rem_pio2.constprop.0+0x390>  // b.none
     350:	ldur	q2, [x10, #-32]
     354:	mov	v3.16b, v2.16b
     358:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     35c:	orr	v0.16b, v0.16b, v2.16b
     360:	cmp	w9, #0x3
     364:	b.eq	390 <__kernel_rem_pio2.constprop.0+0x390>  // b.none
     368:	ldur	q2, [x10, #-48]
     36c:	mov	v3.16b, v2.16b
     370:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     374:	orr	v0.16b, v0.16b, v2.16b
     378:	cmp	w9, #0x4
     37c:	b.eq	390 <__kernel_rem_pio2.constprop.0+0x390>  // b.none
     380:	ldur	q2, [x10, #-64]
     384:	mov	v3.16b, v2.16b
     388:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     38c:	orr	v0.16b, v0.16b, v2.16b
     390:	movi	v1.4s, #0x0
     394:	ext	v2.16b, v0.16b, v1.16b, #8
     398:	orr	v2.16b, v2.16b, v0.16b
     39c:	ext	v0.16b, v2.16b, v1.16b, #4
     3a0:	orr	v0.16b, v0.16b, v2.16b
     3a4:	fmov	w19, s0
     3a8:	tst	x2, #0x3
     3ac:	b.eq	3fc <__kernel_rem_pio2.constprop.0+0x3fc>  // b.none
     3b0:	and	w2, w2, #0xfffffffc
     3b4:	sub	w0, w4, w2
     3b8:	ldr	w2, [x28, w0, sxtw #2]
     3bc:	sub	w9, w0, #0x1
     3c0:	orr	w19, w19, w2
     3c4:	cmp	w0, #0x4
     3c8:	b.eq	3fc <__kernel_rem_pio2.constprop.0+0x3fc>  // b.none
     3cc:	ldr	w2, [x28, w9, sxtw #2]
     3d0:	sub	w9, w0, #0x2
     3d4:	orr	w19, w19, w2
     3d8:	cmp	w0, #0x5
     3dc:	b.eq	3fc <__kernel_rem_pio2.constprop.0+0x3fc>  // b.none
     3e0:	ldr	w9, [x28, w9, sxtw #2]
     3e4:	sub	w2, w0, #0x3
     3e8:	orr	w19, w19, w9
     3ec:	cmp	w0, #0x6
     3f0:	b.eq	3fc <__kernel_rem_pio2.constprop.0+0x3fc>  // b.none
     3f4:	ldr	w0, [x28, w2, sxtw #2]
     3f8:	orr	w19, w19, w0
     3fc:	cbnz	w19, 66c <__kernel_rem_pio2.constprop.0+0x66c>
     400:	ldr	w0, [sp, #44]
     404:	cbnz	w0, 88c <__kernel_rem_pio2.constprop.0+0x88c>
     408:	ldr	w0, [sp, #40]
     40c:	cbnz	w0, 874 <__kernel_rem_pio2.constprop.0+0x874>
     410:	ldr	w0, [sp, #36]
     414:	cbnz	w0, 864 <__kernel_rem_pio2.constprop.0+0x864>
     418:	ldr	w2, [sp, #32]
     41c:	add	w1, w21, #0x1
     420:	add	w0, w21, #0x2
     424:	cmp	w2, #0x0
     428:	cset	w5, eq	// eq = none
     42c:	add	w5, w5, w21
     430:	add	w5, w5, #0x4
     434:	add	w2, w24, w1
     438:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     43c:	add	x6, x1, #0x0
     440:	ldr	w1, [sp, #24]
     444:	sbfiz	x2, x2, #3, #32
     448:	movi	d3, #0x0
     44c:	sub	x2, x2, x20
     450:	sxtw	x0, w0
     454:	add	x6, x6, w1, sxtw #2
     458:	ldr	w1, [sp, #12]
     45c:	sub	x2, x2, #0x10
     460:	sub	x6, x6, #0x4
     464:	add	x2, x25, x2
     468:	sub	w7, w1, #0x3
     46c:	nop
     470:	ldr	w1, [x6, x0, lsl #2]
     474:	scvtf	d0, w1
     478:	str	d0, [x2, x0, lsl #3]
     47c:	fmadd	d0, d0, d11, d3
     480:	cbz	w24, 4ac <__kernel_rem_pio2.constprop.0+0x4ac>
     484:	add	w1, w7, w0
     488:	ldr	d1, [x27, #8]
     48c:	ldr	d2, [x25, w1, sxtw #3]
     490:	fmadd	d0, d2, d1, d0
     494:	cmp	w24, #0x2
     498:	b.ne	4ac <__kernel_rem_pio2.constprop.0+0x4ac>  // b.any
     49c:	sub	w1, w0, #0x1
     4a0:	ldr	d2, [x27, #16]
     4a4:	ldr	d1, [x25, w1, sxtw #3]
     4a8:	fmadd	d0, d2, d1, d0
     4ac:	add	x4, x26, x0, lsl #3
     4b0:	add	x0, x0, #0x1
     4b4:	sub	w1, w0, #0x1
     4b8:	stur	d0, [x4, #-8]
     4bc:	cmp	w5, w1
     4c0:	b.ge	470 <__kernel_rem_pio2.constprop.0+0x470>  // b.tcont
     4c4:	mov	w21, w5
     4c8:	b	230 <__kernel_rem_pio2.constprop.0+0x230>
     4cc:	b.ne	638 <__kernel_rem_pio2.constprop.0+0x638>  // b.any
     4d0:	sub	w0, w21, #0x1
     4d4:	ldr	w1, [x28, w0, sxtw #2]
     4d8:	asr	w1, w1, #23
     4dc:	cmp	w1, #0x0
     4e0:	b.le	2e4 <__kernel_rem_pio2.constprop.0+0x2e4>
     4e4:	add	w8, w8, #0x1
     4e8:	ldr	w0, [x28]
     4ec:	add	x2, x28, x22, lsl #2
     4f0:	mov	x9, x28
     4f4:	nop
     4f8:	cbz	w0, 5f8 <__kernel_rem_pio2.constprop.0+0x5f8>
     4fc:	mov	w10, #0x1000000             	// #16777216
     500:	mov	w11, #0xffffff              	// #16777215
     504:	sub	w0, w10, w0
     508:	str	w0, [x9]
     50c:	b	51c <__kernel_rem_pio2.constprop.0+0x51c>
     510:	ldr	w0, [x4]
     514:	sub	w0, w11, w0
     518:	str	w0, [x4]
     51c:	add	x4, x4, #0x4
     520:	cmp	x4, x2
     524:	b.ne	510 <__kernel_rem_pio2.constprop.0+0x510>  // b.any
     528:	mov	w0, #0x1                   	// #1
     52c:	cmp	w23, #0x0
     530:	b.le	89c <__kernel_rem_pio2.constprop.0+0x89c>
     534:	cmp	w23, #0x1
     538:	b.eq	620 <__kernel_rem_pio2.constprop.0+0x620>  // b.none
     53c:	cmp	w23, #0x2
     540:	b.ne	558 <__kernel_rem_pio2.constprop.0+0x558>  // b.any
     544:	sub	w2, w21, #0x1
     548:	sxtw	x2, w2
     54c:	ldr	w4, [x28, x2, lsl #2]
     550:	and	w4, w4, #0x3fffff
     554:	str	w4, [x28, x2, lsl #2]
     558:	cmp	w1, #0x2
     55c:	b.ne	2e4 <__kernel_rem_pio2.constprop.0+0x2e4>  // b.any
     560:	fmov	d0, #1.000000000000000000e+00
     564:	fsub	d10, d0, d10
     568:	cbz	w0, 2e4 <__kernel_rem_pio2.constprop.0+0x2e4>
     56c:	mov	w1, #0x2                   	// #2
     570:	fmov	d0, #1.000000000000000000e+00
     574:	mov	w0, w23
     578:	str	w1, [sp]
     57c:	str	w8, [sp, #28]
     580:	bl	0 <scalbn>
     584:	fsub	d10, d10, d0
     588:	ldr	w1, [sp]
     58c:	ldr	w8, [sp, #28]
     590:	fcmp	d10, #0.0
     594:	b.eq	2ec <__kernel_rem_pio2.constprop.0+0x2ec>  // b.none
     598:	fmov	d0, d10
     59c:	neg	w0, w23
     5a0:	str	w1, [sp]
     5a4:	str	w8, [sp, #12]
     5a8:	bl	0 <scalbn>
     5ac:	fmov	d1, d0
     5b0:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     5b4:	fmov	d3, x0
     5b8:	ldr	w1, [sp]
     5bc:	fcmpe	d0, d3
     5c0:	ldr	w8, [sp, #12]
     5c4:	b.ge	8b0 <__kernel_rem_pio2.constprop.0+0x8b0>  // b.tcont
     5c8:	fcvtzs	w2, d0
     5cc:	fmov	d0, #1.000000000000000000e+00
     5d0:	mov	w0, w23
     5d4:	str	w1, [sp]
     5d8:	str	w8, [sp, #12]
     5dc:	mov	w19, w21
     5e0:	str	w2, [x28, x22, lsl #2]
     5e4:	bl	0 <scalbn>
     5e8:	ldr	w1, [sp]
     5ec:	fmov	d1, d0
     5f0:	ldr	w8, [sp, #12]
     5f4:	b	6b4 <__kernel_rem_pio2.constprop.0+0x6b4>
     5f8:	add	x4, x4, #0x4
     5fc:	cmp	x4, x2
     600:	b.eq	610 <__kernel_rem_pio2.constprop.0+0x610>  // b.none
     604:	ldr	w0, [x4]
     608:	mov	x9, x4
     60c:	b	4f8 <__kernel_rem_pio2.constprop.0+0x4f8>
     610:	cmp	w23, #0x0
     614:	b.le	558 <__kernel_rem_pio2.constprop.0+0x558>
     618:	cmp	w23, #0x1
     61c:	b.ne	53c <__kernel_rem_pio2.constprop.0+0x53c>  // b.any
     620:	sub	w2, w21, #0x1
     624:	sxtw	x2, w2
     628:	ldr	w4, [x28, x2, lsl #2]
     62c:	and	w4, w4, #0x7fffff
     630:	str	w4, [x28, x2, lsl #2]
     634:	b	558 <__kernel_rem_pio2.constprop.0+0x558>
     638:	fmov	d0, #5.000000000000000000e-01
     63c:	fcmpe	d10, d0
     640:	b.ge	858 <__kernel_rem_pio2.constprop.0+0x858>  // b.tcont
     644:	mov	w1, #0x0                   	// #0
     648:	b	2e4 <__kernel_rem_pio2.constprop.0+0x2e4>
     64c:	movi	v1.4s, #0x0
     650:	mov	w0, w11
     654:	ext	v2.16b, v0.16b, v1.16b, #8
     658:	orr	v2.16b, v2.16b, v0.16b
     65c:	ext	v0.16b, v2.16b, v1.16b, #4
     660:	orr	v0.16b, v0.16b, v2.16b
     664:	fmov	w19, s0
     668:	b	3b8 <__kernel_rem_pio2.constprop.0+0x3b8>
     66c:	ldr	w2, [x28, w4, sxtw #2]
     670:	mov	w19, w4
     674:	sub	w0, w23, #0x18
     678:	add	x5, x28, x22, lsl #2
     67c:	cbnz	w2, 94c <__kernel_rem_pio2.constprop.0+0x94c>
     680:	ldur	w2, [x5, #-8]
     684:	sub	x5, x5, #0x4
     688:	sub	w19, w19, #0x1
     68c:	sub	w0, w0, #0x18
     690:	cbz	w2, 680 <__kernel_rem_pio2.constprop.0+0x680>
     694:	fmov	d0, #1.000000000000000000e+00
     698:	str	w1, [sp]
     69c:	str	w8, [sp, #12]
     6a0:	bl	0 <scalbn>
     6a4:	fmov	d1, d0
     6a8:	ldr	w1, [sp]
     6ac:	ldr	w8, [sp, #12]
     6b0:	tbnz	w19, #31, 91c <__kernel_rem_pio2.constprop.0+0x91c>
     6b4:	sub	w6, w19, #0x1
     6b8:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     6bc:	fmov	d2, x0
     6c0:	sxtw	x6, w6
     6c4:	mov	x0, x6
     6c8:	add	x3, x28, x0, lsl #2
     6cc:	add	x2, x26, x0, lsl #3
     6d0:	sub	x0, x0, #0x1
     6d4:	ldr	w3, [x3, #4]
     6d8:	scvtf	d0, w3
     6dc:	fmul	d0, d0, d1
     6e0:	fmul	d1, d1, d2
     6e4:	str	d0, [x2, #8]
     6e8:	cmn	w0, #0x1
     6ec:	b.pl	6c8 <__kernel_rem_pio2.constprop.0+0x6c8>  // b.nfrst
     6f0:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     6f4:	mov	x0, #0x442d00000000        	// #74960064217088
     6f8:	movk	x0, #0x3e74, lsl #48
     6fc:	add	x7, sp, #0x1b8
     700:	ldr	d3, [x3]
     704:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     708:	fmov	d4, x0
     70c:	movi	d2, #0x0
     710:	ldr	d5, [x3]
     714:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     718:	mov	x5, x7
     71c:	mov	x2, x6
     720:	ldr	d7, [x3]
     724:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     728:	mov	w0, #0x0                   	// #0
     72c:	ldr	d6, [x3]
     730:	b	738 <__kernel_rem_pio2.constprop.0+0x738>
     734:	mov	w0, w3
     738:	add	x3, x26, x2, lsl #3
     73c:	ldr	d0, [x3, #8]
     740:	fmadd	d0, d0, d3, d2
     744:	cbz	w0, 790 <__kernel_rem_pio2.constprop.0+0x790>
     748:	add	w4, w2, #0x2
     74c:	ldr	d1, [x26, w4, sxtw #3]
     750:	fmadd	d0, d1, d4, d0
     754:	cmp	w0, #0x1
     758:	b.eq	790 <__kernel_rem_pio2.constprop.0+0x790>  // b.none
     75c:	add	w4, w2, #0x3
     760:	ldr	d1, [x26, w4, sxtw #3]
     764:	fmadd	d0, d1, d5, d0
     768:	cmp	w0, #0x2
     76c:	b.eq	790 <__kernel_rem_pio2.constprop.0+0x790>  // b.none
     770:	add	w4, w2, #0x4
     774:	ldr	d1, [x26, w4, sxtw #3]
     778:	fmadd	d0, d1, d7, d0
     77c:	cmp	w0, #0x3
     780:	b.eq	790 <__kernel_rem_pio2.constprop.0+0x790>  // b.none
     784:	add	w3, w2, #0x5
     788:	ldr	d1, [x26, w3, sxtw #3]
     78c:	fmadd	d0, d1, d6, d0
     790:	str	d0, [x5], #8
     794:	sub	x2, x2, #0x1
     798:	add	w3, w0, #0x1
     79c:	cmp	w19, w0
     7a0:	b.ne	734 <__kernel_rem_pio2.constprop.0+0x734>  // b.any
     7a4:	movi	d1, #0x0
     7a8:	mov	x2, #0xfffffffffffffffe    	// #-2
     7ac:	add	x0, x7, x6, lsl #3
     7b0:	sub	x6, x6, #0x1
     7b4:	ldr	d0, [x0, #8]
     7b8:	fadd	d1, d1, d0
     7bc:	cmp	x6, x2
     7c0:	b.ne	7ac <__kernel_rem_pio2.constprop.0+0x7ac>  // b.any
     7c4:	ldr	d0, [sp, #440]
     7c8:	cbz	w1, 938 <__kernel_rem_pio2.constprop.0+0x938>
     7cc:	ldr	x0, [sp, #16]
     7d0:	fneg	d2, d1
     7d4:	fsub	d0, d0, d1
     7d8:	str	d2, [x0]
     7dc:	cbz	w19, 800 <__kernel_rem_pio2.constprop.0+0x800>
     7e0:	add	x2, sp, #0x1c0
     7e4:	mov	w0, #0x1                   	// #1
     7e8:	ldr	d1, [x2], #8
     7ec:	add	w0, w0, #0x1
     7f0:	fadd	d0, d0, d1
     7f4:	cmp	w0, w19
     7f8:	b.le	7e8 <__kernel_rem_pio2.constprop.0+0x7e8>
     7fc:	cbz	w1, 804 <__kernel_rem_pio2.constprop.0+0x804>
     800:	fneg	d0, d0
     804:	ldr	x0, [sp, #16]
     808:	adrp	x1, 0 <__stack_chk_guard>
     80c:	ldr	x1, [x1]
     810:	str	d0, [x0, #8]
     814:	and	w0, w8, #0x7
     818:	ldr	x3, [sp, #600]
     81c:	ldr	x2, [x1]
     820:	subs	x3, x3, x2
     824:	mov	x2, #0x0                   	// #0
     828:	b.ne	978 <__kernel_rem_pio2.constprop.0+0x978>  // b.any
     82c:	add	sp, sp, #0x260
     830:	ldp	x19, x20, [sp, #16]
     834:	ldp	x21, x22, [sp, #32]
     838:	ldp	x23, x24, [sp, #48]
     83c:	ldp	x25, x26, [sp, #64]
     840:	ldp	x27, x28, [sp, #80]
     844:	ldp	d8, d9, [sp, #96]
     848:	ldp	d10, d11, [sp, #112]
     84c:	ldp	d12, d13, [sp, #128]
     850:	ldp	x29, x30, [sp], #144
     854:	ret
     858:	add	w8, w8, #0x1
     85c:	mov	w1, #0x2                   	// #2
     860:	b	4e8 <__kernel_rem_pio2.constprop.0+0x4e8>
     864:	add	w1, w21, #0x1
     868:	add	w5, w21, #0x3
     86c:	add	w0, w21, #0x2
     870:	b	434 <__kernel_rem_pio2.constprop.0+0x434>
     874:	add	w0, w21, #0x2
     878:	add	w1, w21, #0x1
     87c:	mov	w5, w0
     880:	b	434 <__kernel_rem_pio2.constprop.0+0x434>
     884:	mov	w1, #0x0                   	// #0
     888:	b	b8 <__kernel_rem_pio2.constprop.0+0xb8>
     88c:	add	w1, w21, #0x1
     890:	add	w0, w21, #0x2
     894:	mov	w5, w1
     898:	b	434 <__kernel_rem_pio2.constprop.0+0x434>
     89c:	cmp	w1, #0x2
     8a0:	b.ne	2e4 <__kernel_rem_pio2.constprop.0+0x2e4>  // b.any
     8a4:	fmov	d0, #1.000000000000000000e+00
     8a8:	fsub	d10, d0, d10
     8ac:	b	56c <__kernel_rem_pio2.constprop.0+0x56c>
     8b0:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     8b4:	fmov	d2, x0
     8b8:	add	w19, w21, #0x1
     8bc:	fmov	d0, #1.000000000000000000e+00
     8c0:	fmul	d2, d1, d2
     8c4:	add	w0, w23, #0x18
     8c8:	str	w1, [sp]
     8cc:	str	w8, [sp, #12]
     8d0:	fcvtzs	w2, d2
     8d4:	scvtf	d2, w2
     8d8:	fmsub	d1, d2, d3, d1
     8dc:	fcvtzs	w3, d1
     8e0:	str	w3, [x28, x22, lsl #2]
     8e4:	str	w2, [x28, w19, sxtw #2]
     8e8:	bl	0 <scalbn>
     8ec:	ldr	w1, [sp]
     8f0:	fmov	d1, d0
     8f4:	ldr	w8, [sp, #12]
     8f8:	b	6b4 <__kernel_rem_pio2.constprop.0+0x6b4>
     8fc:	ldr	q3, [x1, #16]
     900:	str	q1, [sp, #112]
     904:	ldr	d2, [sp, #312]
     908:	mov	v1.16b, v0.16b
     90c:	fmadd	d0, d2, d11, d0
     910:	fmla	v1.2d, v3.2d, v4.2d
     914:	str	q1, [sp, #128]
     918:	b	208 <__kernel_rem_pio2.constprop.0+0x208>
     91c:	ldr	d0, [sp, #440]
     920:	cbz	w1, 96c <__kernel_rem_pio2.constprop.0+0x96c>
     924:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
     928:	fmov	d1, x0
     92c:	ldr	x0, [sp, #16]
     930:	str	d1, [x0]
     934:	b	800 <__kernel_rem_pio2.constprop.0+0x800>
     938:	ldr	x0, [sp, #16]
     93c:	fsub	d0, d0, d1
     940:	str	d1, [x0]
     944:	cbnz	w19, 7e0 <__kernel_rem_pio2.constprop.0+0x7e0>
     948:	b	804 <__kernel_rem_pio2.constprop.0+0x804>
     94c:	fmov	d0, #1.000000000000000000e+00
     950:	str	w1, [sp]
     954:	str	w8, [sp, #12]
     958:	bl	0 <scalbn>
     95c:	fmov	d1, d0
     960:	ldr	w1, [sp]
     964:	ldr	w8, [sp, #12]
     968:	b	6b4 <__kernel_rem_pio2.constprop.0+0x6b4>
     96c:	ldr	x0, [sp, #16]
     970:	str	xzr, [x0]
     974:	b	804 <__kernel_rem_pio2.constprop.0+0x804>
     978:	bl	0 <__stack_chk_fail>
     97c:	nop

0000000000000980 <__ieee754_rem_pio2>:
     980:	sub	sp, sp, #0x40
     984:	fmov	x4, d0
     988:	adrp	x1, 0 <__stack_chk_guard>
     98c:	ldr	x1, [x1]
     990:	stp	x29, x30, [sp, #32]
     994:	add	x29, sp, #0x20
     998:	ubfx	x5, x4, #32, #31
     99c:	stp	x19, x20, [sp, #48]
     9a0:	mov	x19, x0
     9a4:	mov	w0, #0x21fb                	// #8699
     9a8:	ldr	x2, [x1]
     9ac:	str	x2, [sp, #24]
     9b0:	mov	x2, #0x0                   	// #0
     9b4:	movk	w0, #0x3fe9, lsl #16
     9b8:	cmp	w5, w0
     9bc:	b.le	ae0 <__ieee754_rem_pio2+0x160>
     9c0:	mov	w0, #0xd97b                	// #55675
     9c4:	lsr	x20, x4, #32
     9c8:	movk	w0, #0x4002, lsl #16
     9cc:	cmp	w5, w0
     9d0:	b.gt	a44 <__ieee754_rem_pio2+0xc4>
     9d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     9d8:	ldr	d1, [x0]
     9dc:	mov	w0, #0x21fb                	// #8699
     9e0:	movk	w0, #0x3ff9, lsl #16
     9e4:	cmp	w20, #0x0
     9e8:	b.le	c30 <__ieee754_rem_pio2+0x2b0>
     9ec:	fsub	d0, d0, d1
     9f0:	cmp	w5, w0
     9f4:	b.eq	bdc <__ieee754_rem_pio2+0x25c>  // b.none
     9f8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     9fc:	ldr	d2, [x0]
     a00:	fsub	d1, d0, d2
     a04:	fsub	d0, d0, d1
     a08:	fsub	d0, d0, d2
     a0c:	mov	w0, #0x1                   	// #1
     a10:	stp	d1, d0, [x19]
     a14:	nop
     a18:	adrp	x1, 0 <__stack_chk_guard>
     a1c:	ldr	x1, [x1]
     a20:	ldr	x3, [sp, #24]
     a24:	ldr	x2, [x1]
     a28:	subs	x3, x3, x2
     a2c:	mov	x2, #0x0                   	// #0
     a30:	b.ne	c80 <__ieee754_rem_pio2+0x300>  // b.any
     a34:	ldp	x29, x30, [sp, #32]
     a38:	ldp	x19, x20, [sp, #48]
     a3c:	add	sp, sp, #0x40
     a40:	ret
     a44:	mov	w0, #0x21fb                	// #8699
     a48:	movk	w0, #0x4139, lsl #16
     a4c:	cmp	w5, w0
     a50:	b.le	af0 <__ieee754_rem_pio2+0x170>
     a54:	mov	w0, #0x7fefffff            	// #2146435071
     a58:	cmp	w5, w0
     a5c:	b.gt	c14 <__ieee754_rem_pio2+0x294>
     a60:	asr	w2, w5, #20
     a64:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     a68:	sub	w2, w2, #0x416
     a6c:	fmov	d1, x0
     a70:	mov	w3, #0x3                   	// #3
     a74:	sub	w5, w5, w2, lsl #20
     a78:	bfi	x4, x5, #32, #32
     a7c:	fmov	d0, x4
     a80:	fcvtzs	w0, d0
     a84:	scvtf	d2, w0
     a88:	fsub	d0, d0, d2
     a8c:	str	d2, [sp]
     a90:	fmul	d0, d0, d1
     a94:	fcvtzs	w0, d0
     a98:	scvtf	d2, w0
     a9c:	fsub	d0, d0, d2
     aa0:	fmul	d0, d0, d1
     aa4:	fcmp	d0, #0.0
     aa8:	stp	d2, d0, [sp, #8]
     aac:	b.ne	abc <__ieee754_rem_pio2+0x13c>  // b.any
     ab0:	cmp	w0, #0x0
     ab4:	cset	w3, ne	// ne = any
     ab8:	add	w3, w3, #0x1
     abc:	mov	x1, x19
     ac0:	mov	x0, sp
     ac4:	bl	0 <__kernel_rem_pio2.constprop.0>
     ac8:	tbz	w20, #31, a18 <__ieee754_rem_pio2+0x98>
     acc:	ldr	q0, [x19]
     ad0:	neg	w0, w0
     ad4:	fneg	v0.2d, v0.2d
     ad8:	str	q0, [x19]
     adc:	b	a18 <__ieee754_rem_pio2+0x98>
     ae0:	mov	w0, #0x0                   	// #0
     ae4:	str	d0, [x19]
     ae8:	str	xzr, [x19, #8]
     aec:	b	a18 <__ieee754_rem_pio2+0x98>
     af0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     af4:	fabs	d0, d0
     af8:	fmov	d2, #5.000000000000000000e-01
     afc:	ldr	d3, [x0]
     b00:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     b04:	ldr	d4, [x0]
     b08:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     b0c:	fmadd	d2, d0, d3, d2
     b10:	ldr	d1, [x0]
     b14:	fcvtzs	w0, d2
     b18:	scvtf	d3, w0
     b1c:	fmsub	d0, d3, d4, d0
     b20:	fmul	d1, d3, d1
     b24:	fsub	d2, d0, d1
     b28:	cmp	w0, #0x1f
     b2c:	b.gt	b64 <__ieee754_rem_pio2+0x1e4>
     b30:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b34:	add	x1, x1, #0x0
     b38:	add	x1, x1, #0x110
     b3c:	sub	w2, w0, #0x1
     b40:	ldr	w1, [x1, w2, sxtw #2]
     b44:	cmp	w1, w5
     b48:	b.eq	b64 <__ieee754_rem_pio2+0x1e4>  // b.none
     b4c:	str	d2, [x19]
     b50:	fsub	d0, d0, d2
     b54:	fsub	d0, d0, d1
     b58:	tbnz	w20, #31, c00 <__ieee754_rem_pio2+0x280>
     b5c:	str	d0, [x19, #8]
     b60:	b	a18 <__ieee754_rem_pio2+0x98>
     b64:	fmov	x1, d2
     b68:	asr	w5, w5, #20
     b6c:	ubfx	x1, x1, #52, #11
     b70:	sub	w1, w5, w1
     b74:	cmp	w1, #0x10
     b78:	b.le	b4c <__ieee754_rem_pio2+0x1cc>
     b7c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b80:	ldr	d2, [x1]
     b84:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b88:	ldr	d1, [x1]
     b8c:	fmsub	d4, d3, d2, d0
     b90:	fsub	d0, d0, d4
     b94:	fmsub	d0, d3, d2, d0
     b98:	fnmsub	d1, d3, d1, d0
     b9c:	fsub	d2, d4, d1
     ba0:	fmov	x1, d2
     ba4:	ubfx	x1, x1, #52, #11
     ba8:	sub	w5, w5, w1
     bac:	cmp	w5, #0x31
     bb0:	b.le	c24 <__ieee754_rem_pio2+0x2a4>
     bb4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     bb8:	ldr	d2, [x1]
     bbc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     bc0:	ldr	d1, [x1]
     bc4:	fmsub	d0, d3, d2, d4
     bc8:	fsub	d4, d4, d0
     bcc:	fmsub	d4, d3, d2, d4
     bd0:	fnmsub	d1, d3, d1, d4
     bd4:	fsub	d2, d0, d1
     bd8:	b	b4c <__ieee754_rem_pio2+0x1cc>
     bdc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     be0:	ldr	d1, [x0]
     be4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     be8:	ldr	d2, [x0]
     bec:	fsub	d0, d0, d1
     bf0:	fsub	d1, d0, d2
     bf4:	fsub	d0, d0, d1
     bf8:	fsub	d0, d0, d2
     bfc:	b	a0c <__ieee754_rem_pio2+0x8c>
     c00:	mov	v2.d[1], v0.d[0]
     c04:	neg	w0, w0
     c08:	fneg	v2.2d, v2.2d
     c0c:	str	q2, [x19]
     c10:	b	a18 <__ieee754_rem_pio2+0x98>
     c14:	fsub	d0, d0, d0
     c18:	mov	w0, #0x0                   	// #0
     c1c:	stp	d0, d0, [x19]
     c20:	b	a18 <__ieee754_rem_pio2+0x98>
     c24:	fmov	d0, d4
     c28:	str	d2, [x19]
     c2c:	b	b50 <__ieee754_rem_pio2+0x1d0>
     c30:	fadd	d0, d0, d1
     c34:	cmp	w5, w0
     c38:	b.eq	c5c <__ieee754_rem_pio2+0x2dc>  // b.none
     c3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c40:	ldr	d2, [x0]
     c44:	fadd	d1, d0, d2
     c48:	fsub	d0, d0, d1
     c4c:	fadd	d0, d0, d2
     c50:	mov	w0, #0xffffffff            	// #-1
     c54:	stp	d1, d0, [x19]
     c58:	b	a18 <__ieee754_rem_pio2+0x98>
     c5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c60:	ldr	d1, [x0]
     c64:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c68:	ldr	d2, [x0]
     c6c:	fadd	d0, d0, d1
     c70:	fadd	d1, d0, d2
     c74:	fsub	d0, d0, d1
     c78:	fadd	d0, d0, d2
     c7c:	b	c50 <__ieee754_rem_pio2+0x2d0>
     c80:	bl	0 <__stack_chk_fail>

0000000000000c84 <pts_ieee754_acos>:
     c84:	fmov	x1, d0
     c88:	mov	w2, #0x3fefffff            	// #1072693247
     c8c:	ubfx	x0, x1, #32, #31
     c90:	lsr	x3, x1, #32
     c94:	cmp	w0, w2
     c98:	b.le	cc4 <pts_ieee754_acos+0x40>
     c9c:	mov	w2, #0xc0100000            	// #-1072693248
     ca0:	add	w0, w0, w2
     ca4:	orr	w0, w0, w1
     ca8:	cbnz	w0, d24 <pts_ieee754_acos+0xa0>
     cac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     cb0:	movi	d1, #0x0
     cb4:	cmp	w3, #0x0
     cb8:	ldr	d0, [x0]
     cbc:	fcsel	d0, d0, d1, le
     cc0:	ret
     cc4:	stp	x29, x30, [sp, #-48]!
     cc8:	mov	w1, #0x3fdfffff            	// #1071644671
     ccc:	mov	x29, sp
     cd0:	cmp	w0, w1
     cd4:	b.gt	cf4 <pts_ieee754_acos+0x70>
     cd8:	mov	w1, #0x3c600000            	// #1012924416
     cdc:	cmp	w0, w1
     ce0:	b.gt	de4 <pts_ieee754_acos+0x160>
     ce4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ce8:	ldr	d0, [x0]
     cec:	ldp	x29, x30, [sp], #48
     cf0:	ret
     cf4:	stp	d8, d9, [sp, #16]
     cf8:	tbnz	w3, #31, e98 <pts_ieee754_acos+0x214>
     cfc:	fmov	d8, #1.000000000000000000e+00
     d00:	fmov	d1, #5.000000000000000000e-01
     d04:	fsub	d8, d8, d0
     d08:	fmul	d8, d8, d1
     d0c:	fcmp	d8, #0.0
     d10:	b.pl	d30 <pts_ieee754_acos+0xac>  // b.nfrst
     d14:	fmov	d0, d8
     d18:	bl	0 <sqrt>
     d1c:	fmov	d3, d0
     d20:	b	d34 <pts_ieee754_acos+0xb0>
     d24:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     d28:	fmov	d0, x0
     d2c:	ret
     d30:	fsqrt	d3, d8
     d34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d38:	fmov	d4, #1.000000000000000000e+00
     d3c:	ldr	d1, [x0]
     d40:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d44:	ldr	d19, [x0]
     d48:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d4c:	fmadd	d19, d8, d1, d19
     d50:	ldr	d17, [x0]
     d54:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d58:	ldr	d0, [x0]
     d5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d60:	ldr	d18, [x0]
     d64:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d68:	fmadd	d18, d8, d0, d18
     d6c:	movi	v0.2d, #0xffffffff00000000
     d70:	ldr	d7, [x0]
     d74:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d78:	fmadd	d17, d19, d8, d17
     d7c:	ldr	d16, [x0]
     d80:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d84:	and	v2.8b, v3.8b, v0.8b
     d88:	ldr	d5, [x0]
     d8c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d90:	ldr	d6, [x0]
     d94:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     d98:	fmadd	d16, d18, d8, d16
     d9c:	movk	x0, #0x3fc5, lsl #48
     da0:	fmov	d1, x0
     da4:	fmsub	d0, d2, d2, d8
     da8:	fmadd	d7, d17, d8, d7
     dac:	fadd	d9, d2, d3
     db0:	fmadd	d6, d16, d8, d6
     db4:	fdiv	d0, d0, d9
     db8:	fmadd	d5, d7, d8, d5
     dbc:	fmadd	d4, d6, d8, d4
     dc0:	fmadd	d1, d5, d8, d1
     dc4:	fmul	d1, d1, d8
     dc8:	ldp	d8, d9, [sp, #16]
     dcc:	ldp	x29, x30, [sp], #48
     dd0:	fdiv	d1, d1, d4
     dd4:	fmadd	d0, d1, d3, d0
     dd8:	fadd	d0, d0, d2
     ddc:	fadd	d0, d0, d0
     de0:	ret
     de4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     de8:	fmul	d2, d0, d0
     dec:	stp	d8, d9, [sp, #16]
     df0:	fmov	d5, #1.000000000000000000e+00
     df4:	ldr	d3, [x0]
     df8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     dfc:	ldr	d18, [x0]
     e00:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e04:	fmadd	d18, d2, d3, d18
     e08:	ldr	d16, [x0]
     e0c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e10:	ldr	d1, [x0]
     e14:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e18:	ldr	d17, [x0]
     e1c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e20:	fmadd	d17, d2, d1, d17
     e24:	ldr	d8, [x0]
     e28:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e2c:	fmadd	d16, d18, d2, d16
     e30:	ldr	d9, [x0]
     e34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e38:	ldr	d6, [x0]
     e3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e40:	ldr	d7, [x0]
     e44:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     e48:	fmadd	d9, d17, d2, d9
     e4c:	movk	x0, #0x3fc5, lsl #48
     e50:	fmov	d3, x0
     e54:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e58:	fmadd	d8, d16, d2, d8
     e5c:	ldr	d4, [x0]
     e60:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e64:	ldr	d1, [x0]
     e68:	fmadd	d7, d9, d2, d7
     e6c:	fmadd	d6, d8, d2, d6
     e70:	ldp	d8, d9, [sp, #16]
     e74:	ldp	x29, x30, [sp], #48
     e78:	fmadd	d5, d7, d2, d5
     e7c:	fmadd	d3, d6, d2, d3
     e80:	fmul	d2, d3, d2
     e84:	fdiv	d2, d2, d5
     e88:	fmsub	d2, d0, d2, d4
     e8c:	fsub	d0, d0, d2
     e90:	fsub	d0, d1, d0
     e94:	ret
     e98:	fmov	d1, #1.000000000000000000e+00
     e9c:	fmov	d3, #5.000000000000000000e-01
     ea0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ea4:	fadd	d0, d0, d1
     ea8:	ldr	d17, [x0]
     eac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     eb0:	ldr	d9, [x0]
     eb4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     eb8:	fmul	d0, d0, d3
     ebc:	ldr	d6, [x0]
     ec0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ec4:	ldr	d16, [x0]
     ec8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ecc:	fmadd	d9, d0, d17, d9
     ed0:	fcmp	d0, #0.0
     ed4:	ldr	d4, [x0]
     ed8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     edc:	ldr	d7, [x0]
     ee0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ee4:	fmadd	d7, d0, d16, d7
     ee8:	ldr	d2, [x0]
     eec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ef0:	ldr	d5, [x0]
     ef4:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     ef8:	fmadd	d6, d9, d0, d6
     efc:	movk	x0, #0x3fc5, lsl #48
     f00:	fmov	d8, x0
     f04:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f08:	ldr	d3, [x0]
     f0c:	fmadd	d5, d7, d0, d5
     f10:	fmadd	d4, d6, d0, d4
     f14:	fmadd	d3, d5, d0, d3
     f18:	fmadd	d2, d4, d0, d2
     f1c:	fmadd	d3, d3, d0, d1
     f20:	fmadd	d8, d2, d0, d8
     f24:	fmul	d8, d8, d0
     f28:	b.pl	f40 <pts_ieee754_acos+0x2bc>  // b.nfrst
     f2c:	str	d3, [sp, #40]
     f30:	bl	0 <sqrt>
     f34:	ldr	d3, [sp, #40]
     f38:	fmov	d1, d0
     f3c:	b	f44 <pts_ieee754_acos+0x2c0>
     f40:	fsqrt	d1, d0
     f44:	fdiv	d8, d8, d3
     f48:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f4c:	fmov	d3, #2.000000000000000000e+00
     f50:	ldr	d2, [x0]
     f54:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f58:	ldr	d0, [x0]
     f5c:	fmadd	d2, d8, d1, d2
     f60:	ldp	d8, d9, [sp, #16]
     f64:	ldp	x29, x30, [sp], #48
     f68:	fadd	d1, d2, d1
     f6c:	fmsub	d0, d1, d3, d0
     f70:	ret

0000000000000f74 <pts_ieee754_asin>:
     f74:	fmov	x0, d0
     f78:	stp	x29, x30, [sp, #-64]!
     f7c:	fmov	d1, d0
     f80:	mov	x29, sp
     f84:	stp	x19, x20, [sp, #16]
     f88:	mov	w1, #0x3fefffff            	// #1072693247
     f8c:	ubfx	x19, x0, #32, #31
     f90:	cmp	w19, w1
     f94:	b.le	fe0 <pts_ieee754_asin+0x6c>
     f98:	mov	w1, #0xc0100000            	// #-1072693248
     f9c:	add	w19, w19, w1
     fa0:	orr	w19, w19, w0
     fa4:	cbz	w19, fbc <pts_ieee754_asin+0x48>
     fa8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     fac:	fmov	d0, x0
     fb0:	ldp	x19, x20, [sp, #16]
     fb4:	ldp	x29, x30, [sp], #64
     fb8:	ret
     fbc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     fc0:	ldp	x19, x20, [sp, #16]
     fc4:	ldr	d0, [x0]
     fc8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     fcc:	ldr	d2, [x0]
     fd0:	fmul	d0, d1, d0
     fd4:	ldp	x29, x30, [sp], #64
     fd8:	fmadd	d0, d1, d2, d0
     fdc:	ret
     fe0:	lsr	x20, x0, #32
     fe4:	mov	w0, #0x3fdfffff            	// #1071644671
     fe8:	cmp	w19, w0
     fec:	b.gt	1028 <pts_ieee754_asin+0xb4>
     ff0:	mov	w0, #0x3e3fffff            	// #1044381695
     ff4:	cmp	w19, w0
     ff8:	b.gt	1130 <pts_ieee754_asin+0x1bc>
     ffc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1000:	fmov	d3, #1.000000000000000000e+00
    1004:	ldr	d2, [x0]
    1008:	fadd	d2, d0, d2
    100c:	fcmpe	d2, d3
    1010:	b.gt	fb0 <pts_ieee754_asin+0x3c>
    1014:	movi	d0, #0x0
    1018:	fmadd	d0, d1, d0, d1
    101c:	ldp	x19, x20, [sp, #16]
    1020:	ldp	x29, x30, [sp], #64
    1024:	ret
    1028:	fabs	d1, d0
    102c:	fmov	d0, #1.000000000000000000e+00
    1030:	fmov	d18, #5.000000000000000000e-01
    1034:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1038:	stp	d8, d9, [sp, #32]
    103c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1040:	ldr	d17, [x0]
    1044:	fsub	d1, d0, d1
    1048:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    104c:	ldr	d3, [x1]
    1050:	ldr	d9, [x0]
    1054:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1058:	fmul	d1, d1, d18
    105c:	ldr	d6, [x0]
    1060:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1064:	ldr	d16, [x0]
    1068:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    106c:	fmadd	d9, d1, d17, d9
    1070:	fcmp	d1, #0.0
    1074:	ldr	d4, [x0]
    1078:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    107c:	ldr	d7, [x0]
    1080:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1084:	fmadd	d7, d1, d16, d7
    1088:	ldr	d2, [x0]
    108c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1090:	ldr	d5, [x0]
    1094:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1098:	fmadd	d6, d9, d1, d6
    109c:	movk	x0, #0x3fc5, lsl #48
    10a0:	fmov	d8, x0
    10a4:	fmadd	d5, d7, d1, d5
    10a8:	fmadd	d4, d6, d1, d4
    10ac:	fmadd	d3, d5, d1, d3
    10b0:	fmadd	d2, d4, d1, d2
    10b4:	fmadd	d3, d3, d1, d0
    10b8:	fmadd	d8, d2, d1, d8
    10bc:	fmul	d8, d8, d1
    10c0:	b.pl	10dc <pts_ieee754_asin+0x168>  // b.nfrst
    10c4:	fmov	d0, d1
    10c8:	stp	d1, d3, [sp, #48]
    10cc:	bl	0 <sqrt>
    10d0:	fmov	d2, d0
    10d4:	ldp	d1, d3, [sp, #48]
    10d8:	b	10e0 <pts_ieee754_asin+0x16c>
    10dc:	fsqrt	d2, d1
    10e0:	fdiv	d8, d8, d3
    10e4:	mov	w0, #0x3332                	// #13106
    10e8:	movk	w0, #0x3fef, lsl #16
    10ec:	cmp	w19, w0
    10f0:	b.le	11c8 <pts_ieee754_asin+0x254>
    10f4:	fmadd	d2, d2, d8, d2
    10f8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    10fc:	fmov	d3, #2.000000000000000000e+00
    1100:	ldr	d1, [x0]
    1104:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1108:	ldr	d0, [x0]
    110c:	fmadd	d1, d2, d3, d1
    1110:	fsub	d0, d0, d1
    1114:	fneg	d1, d0
    1118:	cmp	w20, #0x0
    111c:	ldp	x19, x20, [sp, #16]
    1120:	ldp	d8, d9, [sp, #32]
    1124:	fcsel	d0, d1, d0, le
    1128:	ldp	x29, x30, [sp], #64
    112c:	ret
    1130:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1134:	fmul	d0, d0, d0
    1138:	stp	d8, d9, [sp, #32]
    113c:	ldr	d3, [x0]
    1140:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1144:	ldr	d16, [x0]
    1148:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    114c:	fmadd	d16, d0, d3, d16
    1150:	fmov	d3, #1.000000000000000000e+00
    1154:	ldr	d8, [x0]
    1158:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    115c:	ldr	d2, [x0]
    1160:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1164:	ldr	d9, [x0]
    1168:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    116c:	fmadd	d9, d0, d2, d9
    1170:	ldr	d6, [x0]
    1174:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1178:	fmadd	d8, d0, d16, d8
    117c:	ldr	d7, [x0]
    1180:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1184:	ldr	d4, [x0]
    1188:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    118c:	ldr	d5, [x0]
    1190:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1194:	fmadd	d7, d0, d9, d7
    1198:	movk	x0, #0x3fc5, lsl #48
    119c:	fmov	d2, x0
    11a0:	fmadd	d6, d0, d8, d6
    11a4:	ldp	d8, d9, [sp, #32]
    11a8:	fmadd	d5, d0, d7, d5
    11ac:	fmadd	d4, d0, d6, d4
    11b0:	fmadd	d3, d0, d5, d3
    11b4:	fmadd	d2, d0, d4, d2
    11b8:	fmul	d0, d0, d2
    11bc:	fdiv	d0, d0, d3
    11c0:	fmadd	d0, d1, d0, d1
    11c4:	b	101c <pts_ieee754_asin+0xa8>
    11c8:	movi	v0.2d, #0xffffffff00000000
    11cc:	fadd	d6, d2, d2
    11d0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    11d4:	fmov	d5, #2.000000000000000000e+00
    11d8:	ldr	d3, [x0]
    11dc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    11e0:	and	v4.8b, v2.8b, v0.8b
    11e4:	ldr	d0, [x0]
    11e8:	fmsub	d1, d4, d4, d1
    11ec:	fadd	d2, d4, d2
    11f0:	fmsub	d4, d4, d5, d0
    11f4:	fdiv	d1, d1, d2
    11f8:	fmsub	d1, d1, d5, d3
    11fc:	fnmsub	d1, d6, d8, d1
    1200:	fsub	d1, d1, d4
    1204:	fsub	d0, d0, d1
    1208:	b	1114 <pts_ieee754_asin+0x1a0>
    120c:	nop

0000000000001210 <pts_ieee754_atan>:
    1210:	fmov	x1, d0
    1214:	fmov	d1, d0
    1218:	mov	w2, #0x440fffff            	// #1141899263
    121c:	ubfx	x0, x1, #32, #31
    1220:	lsr	x3, x1, #32
    1224:	cmp	w0, w2
    1228:	b.le	1270 <pts_ieee754_atan+0x60>
    122c:	mov	w2, #0x7ff00000            	// #2146435072
    1230:	cmp	w0, w2
    1234:	b.gt	1268 <pts_ieee754_atan+0x58>
    1238:	cmp	w1, #0x0
    123c:	ccmp	w0, w2, #0x0, ne	// ne = any
    1240:	b.eq	1268 <pts_ieee754_atan+0x58>  // b.none
    1244:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1248:	add	x0, x0, #0x0
    124c:	cmp	w3, #0x0
    1250:	b.le	13e8 <pts_ieee754_atan+0x1d8>
    1254:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1258:	ldr	d0, [x0, #424]
    125c:	ldr	d1, [x1]
    1260:	fadd	d0, d0, d1
    1264:	ret
    1268:	fadd	d0, d1, d1
    126c:	ret
    1270:	mov	w1, #0x3fdbffff            	// #1071382527
    1274:	cmp	w0, w1
    1278:	b.gt	1348 <pts_ieee754_atan+0x138>
    127c:	mov	w1, #0x3e3fffff            	// #1044381695
    1280:	cmp	w0, w1
    1284:	b.le	13cc <pts_ieee754_atan+0x1bc>
    1288:	movi	d21, #0x0
    128c:	mov	w0, #0xffffffff            	// #-1
    1290:	fmov	d0, d21
    1294:	fmul	d4, d1, d1
    1298:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    129c:	ldr	d23, [x1]
    12a0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12a4:	fmul	d3, d4, d4
    12a8:	ldr	d20, [x1]
    12ac:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12b0:	ldr	d22, [x1]
    12b4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12b8:	fmadd	d20, d3, d23, d20
    12bc:	ldr	d19, [x1]
    12c0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12c4:	fmadd	d19, d3, d22, d19
    12c8:	ldr	d18, [x1]
    12cc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12d0:	ldr	d17, [x1]
    12d4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12d8:	ldr	d16, [x1]
    12dc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12e0:	fmadd	d18, d20, d3, d18
    12e4:	ldr	d7, [x1]
    12e8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12ec:	fmadd	d17, d19, d3, d17
    12f0:	ldr	d6, [x1]
    12f4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12f8:	ldr	d2, [x1]
    12fc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1300:	ldr	d5, [x1]
    1304:	fmadd	d16, d18, d3, d16
    1308:	fmadd	d7, d17, d3, d7
    130c:	fmadd	d6, d16, d3, d6
    1310:	fmadd	d2, d7, d3, d2
    1314:	fmadd	d5, d6, d3, d5
    1318:	fmul	d2, d2, d3
    131c:	fmadd	d2, d5, d4, d2
    1320:	fmul	d2, d1, d2
    1324:	cmn	w0, #0x1
    1328:	b.eq	13fc <pts_ieee754_atan+0x1ec>  // b.none
    132c:	fsub	d2, d2, d21
    1330:	cmp	w3, #0x0
    1334:	fsub	d2, d2, d1
    1338:	fsub	d0, d0, d2
    133c:	fneg	d1, d0
    1340:	fcsel	d0, d1, d0, lt	// lt = tstop
    1344:	ret
    1348:	fabs	d1, d0
    134c:	mov	w1, #0x3ff2ffff            	// #1072889855
    1350:	cmp	w0, w1
    1354:	b.gt	1390 <pts_ieee754_atan+0x180>
    1358:	mov	w1, #0x3fe5ffff            	// #1072037887
    135c:	cmp	w0, w1
    1360:	b.gt	1424 <pts_ieee754_atan+0x214>
    1364:	fmov	d3, #2.000000000000000000e+00
    1368:	fmov	d2, #-1.000000000000000000e+00
    136c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1370:	fmadd	d2, d1, d3, d2
    1374:	fadd	d1, d1, d3
    1378:	ldr	d21, [x0]
    137c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1380:	ldr	d0, [x0]
    1384:	mov	w0, #0x0                   	// #0
    1388:	fdiv	d1, d2, d1
    138c:	b	1294 <pts_ieee754_atan+0x84>
    1390:	mov	w1, #0x7fff                	// #32767
    1394:	movk	w1, #0x4003, lsl #16
    1398:	cmp	w0, w1
    139c:	b.gt	1404 <pts_ieee754_atan+0x1f4>
    13a0:	fmov	d3, #1.500000000000000000e+00
    13a4:	fmov	d2, #1.000000000000000000e+00
    13a8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13ac:	fmadd	d2, d1, d3, d2
    13b0:	fsub	d1, d1, d3
    13b4:	ldr	d21, [x0]
    13b8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13bc:	ldr	d0, [x0]
    13c0:	mov	w0, #0x2                   	// #2
    13c4:	fdiv	d1, d1, d2
    13c8:	b	1294 <pts_ieee754_atan+0x84>
    13cc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13d0:	fmov	d3, #1.000000000000000000e+00
    13d4:	ldr	d2, [x0]
    13d8:	fadd	d2, d0, d2
    13dc:	fcmpe	d2, d3
    13e0:	b.gt	1264 <pts_ieee754_atan+0x54>
    13e4:	b	1288 <pts_ieee754_atan+0x78>
    13e8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    13ec:	ldr	d1, [x0, #424]
    13f0:	ldr	d0, [x1]
    13f4:	fsub	d0, d0, d1
    13f8:	ret
    13fc:	fsub	d0, d1, d2
    1400:	ret
    1404:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1408:	fmov	d2, #-1.000000000000000000e+00
    140c:	fdiv	d1, d2, d1
    1410:	ldr	d21, [x0]
    1414:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1418:	ldr	d0, [x0]
    141c:	mov	w0, #0x3                   	// #3
    1420:	b	1294 <pts_ieee754_atan+0x84>
    1424:	fmov	d2, #1.000000000000000000e+00
    1428:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    142c:	fsub	d3, d1, d2
    1430:	fadd	d1, d1, d2
    1434:	ldr	d21, [x0]
    1438:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    143c:	ldr	d0, [x0]
    1440:	mov	w0, #0x1                   	// #1
    1444:	fdiv	d1, d3, d1
    1448:	b	1294 <pts_ieee754_atan+0x84>
    144c:	nop

0000000000001450 <pts_ieee754_atan2>:
    1450:	fmov	x1, d1
    1454:	fmov	d2, d0
    1458:	mov	w3, #0x7ff00000            	// #2146435072
    145c:	neg	w0, w1
    1460:	ubfx	x5, x1, #32, #31
    1464:	orr	w0, w0, w1
    1468:	orr	w0, w5, w0, lsr #31
    146c:	cmp	w0, w3
    1470:	b.hi	152c <pts_ieee754_atan2+0xdc>  // b.pmore
    1474:	fmov	x0, d0
    1478:	neg	w2, w0
    147c:	ubfx	x6, x0, #32, #31
    1480:	orr	w2, w2, w0
    1484:	lsr	x8, x0, #32
    1488:	orr	w2, w6, w2, lsr #31
    148c:	cmp	w2, w3
    1490:	b.hi	152c <pts_ieee754_atan2+0xdc>  // b.pmore
    1494:	lsr	x7, x1, #32
    1498:	mov	w2, #0xc0100000            	// #-1072693248
    149c:	add	w2, w7, w2
    14a0:	orr	w2, w2, w1
    14a4:	cbz	w2, 155c <pts_ieee754_atan2+0x10c>
    14a8:	asr	w4, w7, #30
    14ac:	lsr	w2, w8, #31
    14b0:	and	w4, w4, #0x2
    14b4:	orr	w0, w6, w0
    14b8:	orr	w4, w4, w2
    14bc:	cbz	w0, 1534 <pts_ieee754_atan2+0xe4>
    14c0:	orr	w1, w5, w1
    14c4:	cbz	w1, 1564 <pts_ieee754_atan2+0x114>
    14c8:	cmp	w5, w3
    14cc:	b.eq	15d0 <pts_ieee754_atan2+0x180>  // b.none
    14d0:	cmp	w6, w3
    14d4:	b.eq	1564 <pts_ieee754_atan2+0x114>  // b.none
    14d8:	sub	w6, w6, w5
    14dc:	asr	w6, w6, #20
    14e0:	cmp	w6, #0x3c
    14e4:	b.gt	15ac <pts_ieee754_atan2+0x15c>
    14e8:	cmp	w7, #0x0
    14ec:	mov	w0, #0xffffffc4            	// #-60
    14f0:	movi	d0, #0x0
    14f4:	ccmp	w6, w0, #0x0, lt	// lt = tstop
    14f8:	b.ge	165c <pts_ieee754_atan2+0x20c>  // b.tcont
    14fc:	cmp	w4, #0x1
    1500:	b.eq	1654 <pts_ieee754_atan2+0x204>  // b.none
    1504:	cmp	w4, #0x2
    1508:	b.ne	1600 <pts_ieee754_atan2+0x1b0>  // b.any
    150c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1510:	add	x0, x0, #0x0
    1514:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1518:	ldr	d2, [x0, #8]
    151c:	ldr	d1, [x1]
    1520:	fsub	d0, d0, d2
    1524:	fsub	d0, d1, d0
    1528:	ret
    152c:	fadd	d0, d1, d2
    1530:	ret
    1534:	cmp	w4, #0x2
    1538:	b.eq	1580 <pts_ieee754_atan2+0x130>  // b.none
    153c:	cmp	w4, #0x3
    1540:	b.ne	1560 <pts_ieee754_atan2+0x110>  // b.any
    1544:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1548:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    154c:	ldr	d1, [x0]
    1550:	ldr	d0, [x1]
    1554:	fsub	d0, d0, d1
    1558:	ret
    155c:	b	1210 <pts_ieee754_atan>
    1560:	ret
    1564:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1568:	tbnz	w8, #31, 1598 <pts_ieee754_atan2+0x148>
    156c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1570:	ldr	d0, [x0]
    1574:	ldr	d1, [x1]
    1578:	fadd	d0, d0, d1
    157c:	ret
    1580:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1584:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1588:	ldr	d0, [x0]
    158c:	ldr	d1, [x1]
    1590:	fadd	d0, d0, d1
    1594:	ret
    1598:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    159c:	ldr	d1, [x0]
    15a0:	ldr	d0, [x1]
    15a4:	fsub	d0, d0, d1
    15a8:	ret
    15ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    15b0:	add	x0, x0, #0x0
    15b4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    15b8:	fmov	d1, #5.000000000000000000e-01
    15bc:	ldr	d2, [x0, #8]
    15c0:	ldr	d0, [x1]
    15c4:	fmadd	d0, d2, d1, d0
    15c8:	tbnz	w4, #0, 1654 <pts_ieee754_atan2+0x204>
    15cc:	ret
    15d0:	cmp	w6, w5
    15d4:	b.eq	1624 <pts_ieee754_atan2+0x1d4>  // b.none
    15d8:	cmp	w4, #0x2
    15dc:	b.eq	1580 <pts_ieee754_atan2+0x130>  // b.none
    15e0:	cmp	w4, #0x3
    15e4:	b.eq	1544 <pts_ieee754_atan2+0xf4>  // b.none
    15e8:	movi	d1, #0x0
    15ec:	cmp	w4, #0x1
    15f0:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
    15f4:	fmov	d0, x0
    15f8:	fcsel	d0, d0, d1, eq	// eq = none
    15fc:	ret
    1600:	cbz	w4, 170c <pts_ieee754_atan2+0x2bc>
    1604:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1608:	add	x0, x0, #0x0
    160c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1610:	ldr	d2, [x0, #8]
    1614:	ldr	d1, [x1]
    1618:	fsub	d0, d0, d2
    161c:	fsub	d0, d0, d1
    1620:	ret
    1624:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1628:	cmp	w4, #0x2
    162c:	b.eq	16f8 <pts_ieee754_atan2+0x2a8>  // b.none
    1630:	cmp	w4, #0x3
    1634:	b.eq	16e4 <pts_ieee754_atan2+0x294>  // b.none
    1638:	cmp	w4, #0x1
    163c:	b.eq	16d0 <pts_ieee754_atan2+0x280>  // b.none
    1640:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1644:	ldr	d0, [x0]
    1648:	ldr	d1, [x1]
    164c:	fadd	d0, d0, d1
    1650:	ret
    1654:	fneg	d0, d0
    1658:	ret
    165c:	fdiv	d0, d2, d1
    1660:	stp	x29, x30, [sp, #-16]!
    1664:	mov	x29, sp
    1668:	fabs	d0, d0
    166c:	bl	1210 <pts_ieee754_atan>
    1670:	cmp	w4, #0x1
    1674:	b.eq	16c8 <pts_ieee754_atan2+0x278>  // b.none
    1678:	cmp	w4, #0x2
    167c:	b.ne	16a4 <pts_ieee754_atan2+0x254>  // b.any
    1680:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1684:	add	x0, x0, #0x0
    1688:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    168c:	ldr	d2, [x0, #8]
    1690:	ldr	d1, [x1]
    1694:	fsub	d0, d0, d2
    1698:	fsub	d0, d1, d0
    169c:	ldp	x29, x30, [sp], #16
    16a0:	ret
    16a4:	cbz	w4, 169c <pts_ieee754_atan2+0x24c>
    16a8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    16ac:	add	x0, x0, #0x0
    16b0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16b4:	ldr	d2, [x0, #8]
    16b8:	ldr	d1, [x1]
    16bc:	fsub	d0, d0, d2
    16c0:	fsub	d0, d0, d1
    16c4:	b	169c <pts_ieee754_atan2+0x24c>
    16c8:	fneg	d0, d0
    16cc:	b	169c <pts_ieee754_atan2+0x24c>
    16d0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16d4:	ldr	d1, [x0]
    16d8:	ldr	d0, [x1]
    16dc:	fsub	d0, d0, d1
    16e0:	ret
    16e4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16e8:	ldr	d1, [x0]
    16ec:	ldr	d0, [x1]
    16f0:	fsub	d0, d0, d1
    16f4:	ret
    16f8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16fc:	ldr	d0, [x0]
    1700:	ldr	d1, [x1]
    1704:	fadd	d0, d0, d1
    1708:	ret
    170c:	ret

0000000000001710 <pts_ieee754_cos>:
    1710:	sub	sp, sp, #0x30
    1714:	mov	w1, #0x21fb                	// #8699
    1718:	adrp	x0, 0 <__stack_chk_guard>
    171c:	ldr	x0, [x0]
    1720:	fmov	d1, d0
    1724:	stp	x29, x30, [sp, #32]
    1728:	add	x29, sp, #0x20
    172c:	movk	w1, #0x3fe9, lsl #16
    1730:	ldr	x2, [x0]
    1734:	str	x2, [sp, #24]
    1738:	mov	x2, #0x0                   	// #0
    173c:	fmov	x0, d0
    1740:	ubfx	x0, x0, #32, #31
    1744:	cmp	w0, w1
    1748:	b.le	1828 <pts_ieee754_cos+0x118>
    174c:	mov	w1, #0x7fefffff            	// #2146435071
    1750:	cmp	w0, w1
    1754:	b.le	1784 <pts_ieee754_cos+0x74>
    1758:	fsub	d0, d0, d0
    175c:	adrp	x0, 0 <__stack_chk_guard>
    1760:	ldr	x0, [x0]
    1764:	ldr	x2, [sp, #24]
    1768:	ldr	x1, [x0]
    176c:	subs	x2, x2, x1
    1770:	mov	x1, #0x0                   	// #0
    1774:	b.ne	1c44 <pts_ieee754_cos+0x534>  // b.any
    1778:	ldp	x29, x30, [sp, #32]
    177c:	add	sp, sp, #0x30
    1780:	ret
    1784:	add	x0, sp, #0x8
    1788:	bl	980 <__ieee754_rem_pio2>
    178c:	and	w0, w0, #0x3
    1790:	cmp	w0, #0x1
    1794:	b.eq	1aa8 <pts_ieee754_cos+0x398>  // b.none
    1798:	cmp	w0, #0x2
    179c:	b.eq	19f4 <pts_ieee754_cos+0x2e4>  // b.none
    17a0:	cbz	w0, 1944 <pts_ieee754_cos+0x234>
    17a4:	ldp	d0, d2, [sp, #8]
    17a8:	mov	w0, #0x3e3fffff            	// #1044381695
    17ac:	fmov	x1, d0
    17b0:	ubfx	x1, x1, #32, #31
    17b4:	cmp	w1, w0
    17b8:	b.gt	17c4 <pts_ieee754_cos+0xb4>
    17bc:	fcvtzs	w0, d0
    17c0:	cbz	w0, 175c <pts_ieee754_cos+0x4c>
    17c4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    17c8:	fmul	d3, d0, d0
    17cc:	fmov	d17, #5.000000000000000000e-01
    17d0:	ldr	d7, [x0]
    17d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    17d8:	ldr	d6, [x0]
    17dc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    17e0:	fmadd	d6, d3, d7, d6
    17e4:	fmul	d7, d0, d3
    17e8:	ldr	d5, [x0]
    17ec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    17f0:	ldr	d4, [x0]
    17f4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    17f8:	ldr	d1, [x0]
    17fc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1800:	ldr	d16, [x0]
    1804:	fmadd	d5, d3, d6, d5
    1808:	fmadd	d4, d3, d5, d4
    180c:	fmadd	d1, d3, d4, d1
    1810:	fmul	d1, d7, d1
    1814:	fnmsub	d1, d2, d17, d1
    1818:	fnmsub	d2, d3, d1, d2
    181c:	fmadd	d2, d7, d16, d2
    1820:	fsub	d0, d0, d2
    1824:	b	175c <pts_ieee754_cos+0x4c>
    1828:	mov	w1, #0x3e3fffff            	// #1044381695
    182c:	cmp	w0, w1
    1830:	b.le	18d0 <pts_ieee754_cos+0x1c0>
    1834:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1838:	fmul	d2, d0, d0
    183c:	ldr	d7, [x1]
    1840:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1844:	ldr	d6, [x1]
    1848:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    184c:	fmadd	d6, d2, d7, d6
    1850:	ldr	d5, [x1]
    1854:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1858:	ldr	d4, [x1]
    185c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1860:	ldr	d0, [x1]
    1864:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1868:	ldr	d3, [x1]
    186c:	mov	w1, #0x3332                	// #13106
    1870:	fmadd	d5, d2, d6, d5
    1874:	movk	w1, #0x3fd3, lsl #16
    1878:	fmadd	d4, d2, d5, d4
    187c:	fmadd	d0, d2, d4, d0
    1880:	fmadd	d3, d2, d0, d3
    1884:	fmul	d3, d2, d3
    1888:	cmp	w0, w1
    188c:	b.le	1924 <pts_ieee754_cos+0x214>
    1890:	mov	w1, #0x3fe90000            	// #1072234496
    1894:	cmp	w0, w1
    1898:	b.gt	1b38 <pts_ieee754_cos+0x428>
    189c:	sub	w0, w0, #0x200, lsl #12
    18a0:	fmov	d0, x0
    18a4:	fmov	d5, #1.000000000000000000e+00
    18a8:	shl	d0, d0, #32
    18ac:	fsub	d5, d5, d0
    18b0:	movi	d4, #0x0
    18b4:	fmov	d6, #5.000000000000000000e-01
    18b8:	fnmsub	d0, d2, d6, d0
    18bc:	fmul	d1, d1, d4
    18c0:	fnmsub	d1, d2, d3, d1
    18c4:	fsub	d0, d0, d1
    18c8:	fsub	d0, d5, d0
    18cc:	b	175c <pts_ieee754_cos+0x4c>
    18d0:	fcvtzs	w0, d0
    18d4:	cbz	w0, 1b30 <pts_ieee754_cos+0x420>
    18d8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18dc:	fmul	d2, d0, d0
    18e0:	ldr	d7, [x0]
    18e4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18e8:	ldr	d6, [x0]
    18ec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18f0:	fmadd	d6, d2, d7, d6
    18f4:	ldr	d5, [x0]
    18f8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18fc:	ldr	d4, [x0]
    1900:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1904:	ldr	d0, [x0]
    1908:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    190c:	ldr	d3, [x0]
    1910:	fmadd	d5, d6, d2, d5
    1914:	fmadd	d4, d5, d2, d4
    1918:	fmadd	d0, d4, d2, d0
    191c:	fmadd	d3, d0, d2, d3
    1920:	fmul	d3, d3, d2
    1924:	movi	d0, #0x0
    1928:	fmov	d5, #5.000000000000000000e-01
    192c:	fmov	d4, #1.000000000000000000e+00
    1930:	fmul	d0, d1, d0
    1934:	fnmsub	d0, d2, d3, d0
    1938:	fnmsub	d0, d2, d5, d0
    193c:	fsub	d0, d4, d0
    1940:	b	175c <pts_ieee754_cos+0x4c>
    1944:	ldp	d1, d7, [sp, #8]
    1948:	mov	w1, #0x3e3fffff            	// #1044381695
    194c:	fmov	x0, d1
    1950:	ubfx	x0, x0, #32, #31
    1954:	cmp	w0, w1
    1958:	b.le	1bbc <pts_ieee754_cos+0x4ac>
    195c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1960:	fmul	d2, d1, d1
    1964:	ldr	d16, [x1]
    1968:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    196c:	ldr	d6, [x1]
    1970:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1974:	fmadd	d6, d2, d16, d6
    1978:	ldr	d5, [x1]
    197c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1980:	ldr	d3, [x1]
    1984:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1988:	ldr	d0, [x1]
    198c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1990:	ldr	d4, [x1]
    1994:	mov	w1, #0x3332                	// #13106
    1998:	fmadd	d5, d2, d6, d5
    199c:	movk	w1, #0x3fd3, lsl #16
    19a0:	fmadd	d3, d2, d5, d3
    19a4:	fmadd	d0, d2, d3, d0
    19a8:	fmadd	d4, d2, d0, d4
    19ac:	fmul	d4, d2, d4
    19b0:	cmp	w0, w1
    19b4:	b.le	1c10 <pts_ieee754_cos+0x500>
    19b8:	mov	w1, #0x3fe90000            	// #1072234496
    19bc:	cmp	w0, w1
    19c0:	b.gt	1c38 <pts_ieee754_cos+0x528>
    19c4:	sub	w0, w0, #0x200, lsl #12
    19c8:	fmov	d3, x0
    19cc:	fmov	d0, #1.000000000000000000e+00
    19d0:	shl	d3, d3, #32
    19d4:	fsub	d0, d0, d3
    19d8:	fmov	d5, #5.000000000000000000e-01
    19dc:	fmul	d1, d1, d7
    19e0:	fnmsub	d1, d2, d4, d1
    19e4:	fnmsub	d3, d2, d5, d3
    19e8:	fsub	d3, d3, d1
    19ec:	fsub	d0, d0, d3
    19f0:	b	175c <pts_ieee754_cos+0x4c>
    19f4:	ldp	d1, d7, [sp, #8]
    19f8:	mov	w1, #0x3e3fffff            	// #1044381695
    19fc:	fmov	x0, d1
    1a00:	ubfx	x0, x0, #32, #31
    1a04:	cmp	w0, w1
    1a08:	b.le	1b44 <pts_ieee754_cos+0x434>
    1a0c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a10:	fmul	d2, d1, d1
    1a14:	ldr	d16, [x1]
    1a18:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a1c:	ldr	d6, [x1]
    1a20:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a24:	fmadd	d6, d2, d16, d6
    1a28:	ldr	d5, [x1]
    1a2c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a30:	ldr	d3, [x1]
    1a34:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a38:	ldr	d0, [x1]
    1a3c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1a40:	ldr	d4, [x1]
    1a44:	mov	w1, #0x3332                	// #13106
    1a48:	fmadd	d5, d2, d6, d5
    1a4c:	movk	w1, #0x3fd3, lsl #16
    1a50:	fmadd	d3, d2, d5, d3
    1a54:	fmadd	d0, d2, d3, d0
    1a58:	fmadd	d4, d2, d0, d4
    1a5c:	fmul	d4, d2, d4
    1a60:	cmp	w0, w1
    1a64:	b.le	1b9c <pts_ieee754_cos+0x48c>
    1a68:	mov	w1, #0x3fe90000            	// #1072234496
    1a6c:	cmp	w0, w1
    1a70:	b.gt	1c2c <pts_ieee754_cos+0x51c>
    1a74:	sub	w0, w0, #0x200, lsl #12
    1a78:	fmov	d3, x0
    1a7c:	fmov	d0, #1.000000000000000000e+00
    1a80:	shl	d3, d3, #32
    1a84:	fsub	d0, d0, d3
    1a88:	fmov	d5, #5.000000000000000000e-01
    1a8c:	fmul	d1, d1, d7
    1a90:	fnmsub	d1, d2, d4, d1
    1a94:	fnmsub	d3, d2, d5, d3
    1a98:	fsub	d3, d3, d1
    1a9c:	fsub	d0, d0, d3
    1aa0:	fneg	d0, d0
    1aa4:	b	175c <pts_ieee754_cos+0x4c>
    1aa8:	ldp	d0, d2, [sp, #8]
    1aac:	mov	w0, #0x3e3fffff            	// #1044381695
    1ab0:	fmov	x1, d0
    1ab4:	ubfx	x1, x1, #32, #31
    1ab8:	cmp	w1, w0
    1abc:	b.gt	1ac8 <pts_ieee754_cos+0x3b8>
    1ac0:	fcvtzs	w0, d0
    1ac4:	cbz	w0, 1aa0 <pts_ieee754_cos+0x390>
    1ac8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1acc:	fmul	d3, d0, d0
    1ad0:	fmov	d17, #5.000000000000000000e-01
    1ad4:	ldr	d7, [x0]
    1ad8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1adc:	ldr	d6, [x0]
    1ae0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ae4:	fmadd	d6, d3, d7, d6
    1ae8:	fmul	d7, d0, d3
    1aec:	ldr	d5, [x0]
    1af0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1af4:	ldr	d4, [x0]
    1af8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1afc:	ldr	d1, [x0]
    1b00:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b04:	ldr	d16, [x0]
    1b08:	fmadd	d5, d3, d6, d5
    1b0c:	fmadd	d4, d3, d5, d4
    1b10:	fmadd	d1, d3, d4, d1
    1b14:	fmul	d1, d7, d1
    1b18:	fnmsub	d1, d2, d17, d1
    1b1c:	fnmsub	d2, d3, d1, d2
    1b20:	fmadd	d2, d7, d16, d2
    1b24:	fsub	d0, d0, d2
    1b28:	fneg	d0, d0
    1b2c:	b	175c <pts_ieee754_cos+0x4c>
    1b30:	fmov	d0, #1.000000000000000000e+00
    1b34:	b	175c <pts_ieee754_cos+0x4c>
    1b38:	fmov	d5, #7.187500000000000000e-01
    1b3c:	fmov	d0, #2.812500000000000000e-01
    1b40:	b	18b0 <pts_ieee754_cos+0x1a0>
    1b44:	fcvtzs	w0, d1
    1b48:	fmov	d0, #-1.000000000000000000e+00
    1b4c:	cbz	w0, 175c <pts_ieee754_cos+0x4c>
    1b50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b54:	fmul	d2, d1, d1
    1b58:	ldr	d16, [x0]
    1b5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b60:	ldr	d6, [x0]
    1b64:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b68:	fmadd	d6, d2, d16, d6
    1b6c:	ldr	d5, [x0]
    1b70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b74:	ldr	d3, [x0]
    1b78:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b7c:	ldr	d0, [x0]
    1b80:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b84:	ldr	d4, [x0]
    1b88:	fmadd	d5, d2, d6, d5
    1b8c:	fmadd	d3, d2, d5, d3
    1b90:	fmadd	d0, d2, d3, d0
    1b94:	fmadd	d4, d2, d0, d4
    1b98:	fmul	d4, d2, d4
    1b9c:	fmul	d1, d1, d7
    1ba0:	fmov	d3, #5.000000000000000000e-01
    1ba4:	fnmsub	d1, d2, d4, d1
    1ba8:	fmov	d0, #1.000000000000000000e+00
    1bac:	fnmsub	d1, d2, d3, d1
    1bb0:	fsub	d0, d0, d1
    1bb4:	fneg	d0, d0
    1bb8:	b	175c <pts_ieee754_cos+0x4c>
    1bbc:	fcvtzs	w0, d1
    1bc0:	cbz	w0, 1b30 <pts_ieee754_cos+0x420>
    1bc4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bc8:	fmul	d2, d1, d1
    1bcc:	ldr	d16, [x0]
    1bd0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bd4:	ldr	d6, [x0]
    1bd8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bdc:	fmadd	d6, d2, d16, d6
    1be0:	ldr	d5, [x0]
    1be4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1be8:	ldr	d3, [x0]
    1bec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bf0:	ldr	d0, [x0]
    1bf4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bf8:	ldr	d4, [x0]
    1bfc:	fmadd	d5, d6, d2, d5
    1c00:	fmadd	d3, d5, d2, d3
    1c04:	fmadd	d0, d3, d2, d0
    1c08:	fmadd	d4, d0, d2, d4
    1c0c:	fmul	d4, d4, d2
    1c10:	fmul	d1, d1, d7
    1c14:	fmov	d3, #5.000000000000000000e-01
    1c18:	fnmsub	d1, d2, d4, d1
    1c1c:	fmov	d0, #1.000000000000000000e+00
    1c20:	fnmsub	d1, d2, d3, d1
    1c24:	fsub	d0, d0, d1
    1c28:	b	175c <pts_ieee754_cos+0x4c>
    1c2c:	fmov	d0, #7.187500000000000000e-01
    1c30:	fmov	d3, #2.812500000000000000e-01
    1c34:	b	1a88 <pts_ieee754_cos+0x378>
    1c38:	fmov	d0, #7.187500000000000000e-01
    1c3c:	fmov	d3, #2.812500000000000000e-01
    1c40:	b	19d8 <pts_ieee754_cos+0x2c8>
    1c44:	bl	0 <__stack_chk_fail>
    1c48:	nop
    1c4c:	nop

0000000000001c50 <pts_ieee754_exp>:
    1c50:	fmov	x1, d0
    1c54:	mov	w4, #0x2e41                	// #11841
    1c58:	movk	w4, #0x4086, lsl #16
    1c5c:	ubfx	x2, x1, #32, #31
    1c60:	lsr	x3, x1, #32
    1c64:	lsr	x0, x1, #63
    1c68:	cmp	w2, w4
    1c6c:	b.ls	1c90 <pts_ieee754_exp+0x40>  // b.plast
    1c70:	mov	w4, #0x7fefffff            	// #2146435071
    1c74:	cmp	w2, w4
    1c78:	b.ls	1d20 <pts_ieee754_exp+0xd0>  // b.plast
    1c7c:	and	w3, w3, #0xfffff
    1c80:	orr	w3, w3, w1
    1c84:	cbz	w3, 1ebc <pts_ieee754_exp+0x26c>
    1c88:	fadd	d0, d0, d0
    1c8c:	ret
    1c90:	mov	w1, #0x2e42                	// #11842
    1c94:	movk	w1, #0x3fd6, lsl #16
    1c98:	cmp	w2, w1
    1c9c:	b.hi	1e44 <pts_ieee754_exp+0x1f4>  // b.pmore
    1ca0:	mov	w0, #0x3e2fffff            	// #1043333119
    1ca4:	cmp	w2, w0
    1ca8:	b.ls	1e9c <pts_ieee754_exp+0x24c>  // b.plast
    1cac:	movi	d3, #0x0
    1cb0:	fmul	d1, d0, d0
    1cb4:	fmov	d16, #1.000000000000000000e+00
    1cb8:	mov	w0, #0x0                   	// #0
    1cbc:	fmov	d4, d3
    1cc0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1cc4:	ldr	d2, [x1]
    1cc8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1ccc:	ldr	d7, [x1]
    1cd0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1cd4:	fmadd	d7, d1, d2, d7
    1cd8:	ldr	d6, [x1]
    1cdc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1ce0:	ldr	d5, [x1]
    1ce4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1ce8:	ldr	d2, [x1]
    1cec:	fmadd	d6, d7, d1, d6
    1cf0:	fmadd	d5, d6, d1, d5
    1cf4:	fmadd	d2, d5, d1, d2
    1cf8:	fmsub	d1, d2, d1, d0
    1cfc:	cbnz	w0, 1e14 <pts_ieee754_exp+0x1c4>
    1d00:	fmov	d4, #2.000000000000000000e+00
    1d04:	fmul	d2, d1, d0
    1d08:	fmov	d3, #1.000000000000000000e+00
    1d0c:	fsub	d1, d1, d4
    1d10:	fdiv	d1, d2, d1
    1d14:	fsub	d0, d1, d0
    1d18:	fsub	d0, d3, d0
    1d1c:	ret
    1d20:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d24:	ldr	d1, [x1]
    1d28:	fcmpe	d0, d1
    1d2c:	b.gt	1ecc <pts_ieee754_exp+0x27c>
    1d30:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d34:	ldr	d1, [x1]
    1d38:	fcmpe	d0, d1
    1d3c:	b.mi	1f04 <pts_ieee754_exp+0x2b4>  // b.first
    1d40:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d44:	add	x1, x1, #0x0
    1d48:	add	x0, x1, w0, sxtw #3
    1d4c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d50:	ldr	d2, [x1]
    1d54:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d58:	ldr	d1, [x0, #464]
    1d5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d60:	ldr	d4, [x1]
    1d64:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d68:	fmadd	d1, d0, d2, d1
    1d6c:	ldr	d6, [x0]
    1d70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d74:	ldr	d17, [x1]
    1d78:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d7c:	ldr	d2, [x0]
    1d80:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d84:	ldr	d16, [x1]
    1d88:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d8c:	ldr	d5, [x0]
    1d90:	ldr	d7, [x1]
    1d94:	fcvtzs	w0, d1
    1d98:	scvtf	d3, w0
    1d9c:	fmsub	d4, d3, d4, d0
    1da0:	fmul	d3, d3, d17
    1da4:	fsub	d0, d4, d3
    1da8:	fmul	d1, d0, d0
    1dac:	fmadd	d7, d1, d16, d7
    1db0:	fmadd	d6, d1, d7, d6
    1db4:	fmadd	d2, d1, d6, d2
    1db8:	fmadd	d5, d1, d2, d5
    1dbc:	fmsub	d5, d1, d5, d0
    1dc0:	cmn	w0, #0x3fd
    1dc4:	b.ge	1f28 <pts_ieee754_exp+0x2d8>  // b.tcont
    1dc8:	fmov	d1, #2.000000000000000000e+00
    1dcc:	fmul	d2, d0, d5
    1dd0:	add	w0, w0, #0x3e8
    1dd4:	mov	w1, #0x3ff00000            	// #1072693248
    1dd8:	fsub	d5, d1, d5
    1ddc:	add	w0, w1, w0, lsl #20
    1de0:	fmov	d0, #1.000000000000000000e+00
    1de4:	fmov	d1, x0
    1de8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1dec:	add	x1, x1, #0x0
    1df0:	fdiv	d2, d2, d5
    1df4:	shl	d1, d1, #32
    1df8:	ldr	d5, [x1, #24]
    1dfc:	fsub	d2, d3, d2
    1e00:	fsub	d2, d2, d4
    1e04:	fsub	d0, d0, d2
    1e08:	fmul	d0, d0, d1
    1e0c:	fmul	d0, d0, d5
    1e10:	ret
    1e14:	fmov	d5, #2.000000000000000000e+00
    1e18:	fmul	d0, d1, d0
    1e1c:	fmov	d2, #1.000000000000000000e+00
    1e20:	fsub	d1, d5, d1
    1e24:	fdiv	d0, d0, d1
    1e28:	fsub	d0, d3, d0
    1e2c:	fsub	d0, d0, d4
    1e30:	fsub	d0, d2, d0
    1e34:	cmp	w0, #0x400
    1e38:	b.eq	1ee4 <pts_ieee754_exp+0x294>  // b.none
    1e3c:	fmul	d0, d0, d16
    1e40:	ret
    1e44:	mov	w1, #0xa2b1                	// #41649
    1e48:	movk	w1, #0x3ff0, lsl #16
    1e4c:	cmp	w2, w1
    1e50:	b.hi	1d40 <pts_ieee754_exp+0xf0>  // b.pmore
    1e54:	fmov	d1, #1.000000000000000000e+00
    1e58:	fcmp	d0, d1
    1e5c:	b.eq	1f1c <pts_ieee754_exp+0x2cc>  // b.none
    1e60:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    1e64:	add	x2, x2, #0x0
    1e68:	add	x2, x2, w0, sxtw #3
    1e6c:	mov	w1, #0x1                   	// #1
    1e70:	sub	w0, w1, w0, lsl #1
    1e74:	mov	w1, #0x3ff00000            	// #1072693248
    1e78:	ldr	d4, [x2, #432]
    1e7c:	add	w1, w1, w0, lsl #20
    1e80:	ldr	d3, [x2, #448]
    1e84:	fmov	d1, x1
    1e88:	fsub	d4, d0, d4
    1e8c:	shl	d16, d1, #32
    1e90:	fsub	d0, d4, d3
    1e94:	fmul	d1, d0, d0
    1e98:	b	1cc0 <pts_ieee754_exp+0x70>
    1e9c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ea0:	add	x0, x0, #0x0
    1ea4:	fmov	d2, #1.000000000000000000e+00
    1ea8:	ldr	d1, [x0, #16]
    1eac:	fadd	d1, d1, d0
    1eb0:	fcmpe	d1, d2
    1eb4:	b.gt	1efc <pts_ieee754_exp+0x2ac>
    1eb8:	b	1cac <pts_ieee754_exp+0x5c>
    1ebc:	movi	d1, #0x0
    1ec0:	cmp	w0, #0x0
    1ec4:	fcsel	d0, d0, d1, eq	// eq = none
    1ec8:	ret
    1ecc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ed0:	add	x0, x0, #0x0
    1ed4:	ldr	d0, [x0, #16]
    1ed8:	ldr	d1, [x0, #16]
    1edc:	fmul	d0, d0, d1
    1ee0:	ret
    1ee4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ee8:	add	x0, x0, #0x0
    1eec:	fadd	d1, d0, d0
    1ef0:	ldr	d0, [x0, #32]
    1ef4:	fmul	d0, d1, d0
    1ef8:	ret
    1efc:	fadd	d0, d0, d2
    1f00:	ret
    1f04:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1f08:	add	x0, x0, #0x0
    1f0c:	ldr	d0, [x0, #24]
    1f10:	ldr	d1, [x0, #24]
    1f14:	fmul	d0, d0, d1
    1f18:	ret
    1f1c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1f20:	ldr	d0, [x0]
    1f24:	ret
    1f28:	mov	w1, #0x3ff00000            	// #1072693248
    1f2c:	add	w1, w1, w0, lsl #20
    1f30:	fmov	d2, x1
    1f34:	shl	d16, d2, #32
    1f38:	b	1cc0 <pts_ieee754_exp+0x70>
    1f3c:	nop

0000000000001f40 <pts_ieee754_log>:
    1f40:	fmov	x1, d0
    1f44:	mov	w3, #0xfffff               	// #1048575
    1f48:	lsr	x2, x1, #32
    1f4c:	mov	w0, w2
    1f50:	cmp	w2, w3
    1f54:	b.gt	2004 <pts_ieee754_log+0xc4>
    1f58:	and	w0, w2, #0x7fffffff
    1f5c:	orr	w0, w0, w1
    1f60:	cbz	w0, 20cc <pts_ieee754_log+0x18c>
    1f64:	tbnz	w2, #31, 2150 <pts_ieee754_log+0x210>
    1f68:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    1f6c:	fmov	d1, x0
    1f70:	mov	w6, #0xffffffca            	// #-54
    1f74:	mov	w2, #0x7fefffff            	// #2146435071
    1f78:	fmul	d0, d0, d1
    1f7c:	fmov	x1, d0
    1f80:	lsr	x0, x1, #32
    1f84:	cmp	w0, w2
    1f88:	b.gt	2014 <pts_ieee754_log+0xd4>
    1f8c:	and	w4, w0, #0xfffff
    1f90:	asr	w0, w0, #20
    1f94:	add	w3, w4, #0x95, lsl #12
    1f98:	sub	w0, w0, #0x3ff
    1f9c:	add	w3, w3, #0xf64
    1fa0:	add	w5, w4, #0x2
    1fa4:	and	w2, w3, #0x100000
    1fa8:	fmov	d0, #1.000000000000000000e+00
    1fac:	eor	w2, w2, #0x3ff00000
    1fb0:	add	w0, w0, w6
    1fb4:	orr	x2, x2, x4
    1fb8:	and	w5, w5, #0xfffff
    1fbc:	add	w3, w0, w3, lsr #20
    1fc0:	bfi	x1, x2, #32, #32
    1fc4:	fmov	d1, x1
    1fc8:	fsub	d0, d1, d0
    1fcc:	cmp	w5, #0x2
    1fd0:	b.gt	201c <pts_ieee754_log+0xdc>
    1fd4:	fcmp	d0, #0.0
    1fd8:	b.ne	20d8 <pts_ieee754_log+0x198>  // b.any
    1fdc:	movi	d0, #0x0
    1fe0:	cbz	w3, 2000 <pts_ieee754_log+0xc0>
    1fe4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1fe8:	scvtf	d1, w3
    1fec:	ldr	d0, [x0]
    1ff0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ff4:	ldr	d2, [x0]
    1ff8:	fmul	d0, d1, d0
    1ffc:	fmadd	d0, d1, d2, d0
    2000:	ret
    2004:	mov	w6, #0x0                   	// #0
    2008:	mov	w2, #0x7fefffff            	// #2146435071
    200c:	cmp	w0, w2
    2010:	b.le	1f8c <pts_ieee754_log+0x4c>
    2014:	fadd	d0, d0, d0
    2018:	ret
    201c:	fmov	d2, #2.000000000000000000e+00
    2020:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2024:	sub	w1, w4, #0x61, lsl #12
    2028:	scvtf	d19, w3
    202c:	fadd	d2, d0, d2
    2030:	ldr	d18, [x0]
    2034:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2038:	sub	w1, w1, #0x47a
    203c:	ldr	d16, [x0]
    2040:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2044:	fdiv	d2, d0, d2
    2048:	ldr	d6, [x0]
    204c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2050:	ldr	d17, [x0]
    2054:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2058:	ldr	d7, [x0]
    205c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2060:	ldr	d1, [x0]
    2064:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2068:	ldr	d4, [x0]
    206c:	mov	w0, #0xb851                	// #47185
    2070:	movk	w0, #0x6, lsl #16
    2074:	sub	w0, w0, w4
    2078:	orr	w0, w0, w1
    207c:	fmul	d5, d2, d2
    2080:	fmul	d3, d5, d5
    2084:	fmadd	d16, d3, d18, d16
    2088:	fmadd	d7, d3, d17, d7
    208c:	fmadd	d6, d16, d3, d6
    2090:	fmadd	d4, d7, d3, d4
    2094:	fmadd	d1, d6, d3, d1
    2098:	fmul	d1, d1, d5
    209c:	fmadd	d1, d4, d3, d1
    20a0:	cmp	w0, #0x0
    20a4:	b.le	211c <pts_ieee754_log+0x1dc>
    20a8:	fmov	d3, #5.000000000000000000e-01
    20ac:	fmul	d3, d0, d3
    20b0:	fmul	d3, d3, d0
    20b4:	fadd	d1, d1, d3
    20b8:	fmul	d1, d1, d2
    20bc:	cbnz	w3, 215c <pts_ieee754_log+0x21c>
    20c0:	fsub	d3, d3, d1
    20c4:	fsub	d0, d0, d3
    20c8:	ret
    20cc:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    20d0:	fmov	d0, x0
    20d4:	ret
    20d8:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    20dc:	fmov	d2, #5.000000000000000000e-01
    20e0:	movk	x0, #0x3fd5, lsl #48
    20e4:	fmov	d3, x0
    20e8:	fmul	d1, d0, d0
    20ec:	fmsub	d2, d0, d3, d2
    20f0:	fmul	d1, d1, d2
    20f4:	cbz	w3, 2148 <pts_ieee754_log+0x208>
    20f8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    20fc:	scvtf	d2, w3
    2100:	ldr	d4, [x0]
    2104:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2108:	ldr	d3, [x0]
    210c:	fmsub	d1, d2, d4, d1
    2110:	fsub	d1, d1, d0
    2114:	fnmsub	d0, d2, d3, d1
    2118:	ret
    211c:	fsub	d1, d0, d1
    2120:	fmul	d1, d1, d2
    2124:	cbz	w3, 2148 <pts_ieee754_log+0x208>
    2128:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    212c:	ldr	d3, [x0]
    2130:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2134:	ldr	d2, [x0]
    2138:	fmsub	d1, d19, d3, d1
    213c:	fsub	d1, d1, d0
    2140:	fnmsub	d0, d19, d2, d1
    2144:	ret
    2148:	fsub	d0, d0, d1
    214c:	ret
    2150:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2154:	fmov	d0, x0
    2158:	ret
    215c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2160:	ldr	d4, [x0]
    2164:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2168:	ldr	d2, [x0]
    216c:	fmadd	d1, d19, d4, d1
    2170:	fsub	d3, d3, d1
    2174:	fsub	d3, d3, d0
    2178:	fnmsub	d0, d19, d2, d3
    217c:	ret

0000000000002180 <pts_ieee754_log1p>:
    2180:	fmov	x1, d0
    2184:	mov	w3, #0x8279                	// #33401
    2188:	fmov	d1, d0
    218c:	movk	w3, #0x3fda, lsl #16
    2190:	lsr	x0, x1, #32
    2194:	mov	w2, w0
    2198:	cmp	w0, w3
    219c:	b.gt	21d0 <pts_ieee754_log1p+0x50>
    21a0:	and	w1, w0, #0x7fffffff
    21a4:	mov	w2, #0x3fefffff            	// #1072693247
    21a8:	cmp	w1, w2
    21ac:	b.le	2264 <pts_ieee754_log1p+0xe4>
    21b0:	fmov	d2, #-1.000000000000000000e+00
    21b4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    21b8:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    21bc:	fmov	d0, x0
    21c0:	fcmp	d1, d2
    21c4:	fmov	d1, x1
    21c8:	fcsel	d0, d0, d1, ne	// ne = any
    21cc:	ret
    21d0:	mov	w3, #0x7fefffff            	// #2146435071
    21d4:	cmp	w0, w3
    21d8:	b.gt	230c <pts_ieee754_log1p+0x18c>
    21dc:	mov	w3, #0x433fffff            	// #1128267775
    21e0:	cmp	w0, w3
    21e4:	b.le	2360 <pts_ieee754_log1p+0x1e0>
    21e8:	asr	w0, w0, #20
    21ec:	movi	d5, #0x0
    21f0:	sub	w0, w0, #0x3ff
    21f4:	mov	w3, #0xa09d                	// #41117
    21f8:	and	w2, w2, #0xfffff
    21fc:	and	x1, x1, #0xffffffff
    2200:	movk	w3, #0x6, lsl #16
    2204:	cmp	w2, w3
    2208:	b.gt	2340 <pts_ieee754_log1p+0x1c0>
    220c:	orr	w3, w2, #0x3ff00000
    2210:	sbfiz	x3, x3, #32, #32
    2214:	orr	x1, x3, x1
    2218:	fmov	d1, x1
    221c:	fmov	d2, #1.000000000000000000e+00
    2220:	fmov	d0, #5.000000000000000000e-01
    2224:	fsub	d1, d1, d2
    2228:	fmul	d0, d1, d0
    222c:	fmul	d0, d0, d1
    2230:	cbnz	w2, 2294 <pts_ieee754_log1p+0x114>
    2234:	fcmp	d1, #0.0
    2238:	b.ne	2394 <pts_ieee754_log1p+0x214>  // b.any
    223c:	movi	d0, #0x0
    2240:	cbz	w0, 21cc <pts_ieee754_log1p+0x4c>
    2244:	scvtf	d1, w0
    2248:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    224c:	ldr	d0, [x0]
    2250:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2254:	ldr	d2, [x0]
    2258:	fmadd	d0, d1, d0, d5
    225c:	fmadd	d0, d1, d2, d0
    2260:	ret
    2264:	mov	w2, #0x3e1fffff            	// #1042284543
    2268:	cmp	w1, w2
    226c:	b.le	2314 <pts_ieee754_log1p+0x194>
    2270:	mov	w1, #0x413b                	// #16699
    2274:	movk	w1, #0x402d, lsl #16
    2278:	add	w0, w0, w1
    227c:	cmp	w0, w1
    2280:	b.ls	2360 <pts_ieee754_log1p+0x1e0>  // b.plast
    2284:	fmov	d0, #5.000000000000000000e-01
    2288:	mov	w0, #0x0                   	// #0
    228c:	fmul	d0, d1, d0
    2290:	fmul	d0, d0, d1
    2294:	fmov	d2, #2.000000000000000000e+00
    2298:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    229c:	fadd	d2, d1, d2
    22a0:	ldr	d19, [x1]
    22a4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22a8:	ldr	d18, [x1]
    22ac:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22b0:	fdiv	d2, d1, d2
    22b4:	ldr	d17, [x1]
    22b8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22bc:	ldr	d16, [x1]
    22c0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22c4:	ldr	d7, [x1]
    22c8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22cc:	ldr	d6, [x1]
    22d0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22d4:	ldr	d4, [x1]
    22d8:	fmul	d3, d2, d2
    22dc:	fmadd	d18, d3, d19, d18
    22e0:	fmadd	d17, d18, d3, d17
    22e4:	fmadd	d16, d17, d3, d16
    22e8:	fmadd	d7, d16, d3, d7
    22ec:	fmadd	d6, d7, d3, d6
    22f0:	fmadd	d4, d6, d3, d4
    22f4:	fmadd	d3, d4, d3, d0
    22f8:	fmul	d2, d2, d3
    22fc:	cbnz	w0, 23b4 <pts_ieee754_log1p+0x234>
    2300:	fsub	d0, d0, d2
    2304:	fsub	d0, d1, d0
    2308:	ret
    230c:	fadd	d0, d0, d0
    2310:	ret
    2314:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2318:	fmov	d2, x0
    231c:	mov	w0, #0x3c8fffff            	// #1016070143
    2320:	fadd	d1, d0, d2
    2324:	fcmpe	d1, #0.0
    2328:	ccmp	w1, w0, #0x0, gt
    232c:	b.le	21cc <pts_ieee754_log1p+0x4c>
    2330:	fmul	d2, d0, d0
    2334:	fmov	d1, #5.000000000000000000e-01
    2338:	fmsub	d0, d2, d1, d0
    233c:	ret
    2340:	orr	w3, w2, #0x3fe00000
    2344:	mov	w4, #0x100000              	// #1048576
    2348:	sub	w2, w4, w2
    234c:	add	w0, w0, #0x1
    2350:	orr	x1, x1, x3, lsl #32
    2354:	fmov	d1, x1
    2358:	asr	w2, w2, #2
    235c:	b	221c <pts_ieee754_log1p+0x9c>
    2360:	fmov	d5, #1.000000000000000000e+00
    2364:	fadd	d0, d1, d5
    2368:	fmov	x1, d0
    236c:	lsr	x0, x1, #32
    2370:	mov	w2, w0
    2374:	asr	w0, w0, #20
    2378:	sub	w0, w0, #0x3ff
    237c:	cmp	w0, #0x0
    2380:	b.le	2408 <pts_ieee754_log1p+0x288>
    2384:	fsub	d1, d0, d1
    2388:	fsub	d5, d5, d1
    238c:	fdiv	d5, d5, d0
    2390:	b	21f4 <pts_ieee754_log1p+0x74>
    2394:	mov	x1, #0x5555555555555555    	// #6148914691236517205
    2398:	movk	x1, #0x3fe5, lsl #48
    239c:	fmov	d3, x1
    23a0:	fmsub	d2, d1, d3, d2
    23a4:	fmul	d2, d2, d0
    23a8:	cbnz	w0, 23e0 <pts_ieee754_log1p+0x260>
    23ac:	fsub	d0, d1, d2
    23b0:	ret
    23b4:	scvtf	d4, w0
    23b8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23bc:	ldr	d3, [x0]
    23c0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23c4:	ldr	d6, [x0]
    23c8:	fmadd	d3, d4, d3, d5
    23cc:	fadd	d2, d3, d2
    23d0:	fsub	d0, d0, d2
    23d4:	fsub	d0, d0, d1
    23d8:	fnmsub	d0, d4, d6, d0
    23dc:	ret
    23e0:	scvtf	d0, w0
    23e4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23e8:	ldr	d3, [x0]
    23ec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23f0:	ldr	d4, [x0]
    23f4:	fmadd	d3, d0, d3, d5
    23f8:	fsub	d2, d2, d3
    23fc:	fsub	d2, d2, d1
    2400:	fnmsub	d0, d0, d4, d2
    2404:	ret
    2408:	fsub	d5, d0, d5
    240c:	fsub	d5, d1, d5
    2410:	fdiv	d5, d5, d0
    2414:	b	21f4 <pts_ieee754_log1p+0x74>
    2418:	nop
    241c:	nop

0000000000002420 <pts_ieee754_acosh>:
    2420:	fmov	x1, d0
    2424:	mov	w2, #0x3fefffff            	// #1072693247
    2428:	lsr	x0, x1, #32
    242c:	cmp	w0, w2
    2430:	b.le	24b0 <pts_ieee754_acosh+0x90>
    2434:	stp	x29, x30, [sp, #-32]!
    2438:	mov	w2, #0x41afffff            	// #1102053375
    243c:	mov	x29, sp
    2440:	stp	d8, d9, [sp, #16]
    2444:	fmov	d8, d0
    2448:	cmp	w0, w2
    244c:	b.gt	2488 <pts_ieee754_acosh+0x68>
    2450:	mov	w2, #0xc0100000            	// #-1072693248
    2454:	add	w2, w2, w0
    2458:	orr	w1, w2, w1
    245c:	cbz	w1, 2524 <pts_ieee754_acosh+0x104>
    2460:	mov	w1, #0x40000000            	// #1073741824
    2464:	cmp	w0, w1
    2468:	b.le	24cc <pts_ieee754_acosh+0xac>
    246c:	fmov	d0, #-1.000000000000000000e+00
    2470:	fadd	d9, d8, d8
    2474:	fmadd	d0, d8, d8, d0
    2478:	fcmp	d0, #0.0
    247c:	b.pl	24f0 <pts_ieee754_acosh+0xd0>  // b.nfrst
    2480:	bl	0 <sqrt>
    2484:	b	24f4 <pts_ieee754_acosh+0xd4>
    2488:	mov	w1, #0x7fefffff            	// #2146435071
    248c:	cmp	w0, w1
    2490:	b.gt	24bc <pts_ieee754_acosh+0x9c>
    2494:	bl	1f40 <pts_ieee754_log>
    2498:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    249c:	ldp	d8, d9, [sp, #16]
    24a0:	ldr	d1, [x0]
    24a4:	ldp	x29, x30, [sp], #32
    24a8:	fadd	d0, d0, d1
    24ac:	ret
    24b0:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    24b4:	fmov	d0, x0
    24b8:	ret
    24bc:	ldp	d8, d9, [sp, #16]
    24c0:	fadd	d0, d0, d0
    24c4:	ldp	x29, x30, [sp], #32
    24c8:	ret
    24cc:	fmov	d0, #1.000000000000000000e+00
    24d0:	fmov	d1, #2.000000000000000000e+00
    24d4:	fsub	d8, d8, d0
    24d8:	fmul	d0, d8, d8
    24dc:	fmadd	d0, d8, d1, d0
    24e0:	fcmp	d0, #0.0
    24e4:	b.pl	2510 <pts_ieee754_acosh+0xf0>  // b.nfrst
    24e8:	bl	0 <sqrt>
    24ec:	b	2514 <pts_ieee754_acosh+0xf4>
    24f0:	fsqrt	d0, d0
    24f4:	fadd	d8, d8, d0
    24f8:	fmov	d0, #1.000000000000000000e+00
    24fc:	fdiv	d0, d0, d8
    2500:	fsub	d0, d9, d0
    2504:	ldp	d8, d9, [sp, #16]
    2508:	ldp	x29, x30, [sp], #32
    250c:	b	1f40 <pts_ieee754_log>
    2510:	fsqrt	d0, d0
    2514:	fadd	d0, d8, d0
    2518:	ldp	d8, d9, [sp, #16]
    251c:	ldp	x29, x30, [sp], #32
    2520:	b	2180 <pts_ieee754_log1p>
    2524:	ldp	d8, d9, [sp, #16]
    2528:	movi	d0, #0x0
    252c:	ldp	x29, x30, [sp], #32
    2530:	ret

0000000000002534 <pts_ieee754_asinh>:
    2534:	fmov	x0, d0
    2538:	stp	x29, x30, [sp, #-64]!
    253c:	fmov	d1, d0
    2540:	mov	x29, sp
    2544:	str	x19, [sp, #16]
    2548:	mov	w1, #0x7fefffff            	// #2146435071
    254c:	lsr	x19, x0, #32
    2550:	and	w0, w19, #0x7fffffff
    2554:	cmp	w0, w1
    2558:	b.gt	25f0 <pts_ieee754_asinh+0xbc>
    255c:	mov	w1, #0x3e2fffff            	// #1043333119
    2560:	cmp	w0, w1
    2564:	b.le	25ac <pts_ieee754_asinh+0x78>
    2568:	stp	d8, d9, [sp, #32]
    256c:	mov	w1, #0x41b00000            	// #1102053376
    2570:	fabs	d8, d0
    2574:	cmp	w0, w1
    2578:	b.le	261c <pts_ieee754_asinh+0xe8>
    257c:	fmov	d0, d8
    2580:	bl	1f40 <pts_ieee754_log>
    2584:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2588:	ldr	d1, [x0]
    258c:	fadd	d0, d0, d1
    2590:	fneg	d1, d0
    2594:	cmp	w19, #0x0
    2598:	ldp	d8, d9, [sp, #32]
    259c:	fcsel	d0, d1, d0, le
    25a0:	ldr	x19, [sp, #16]
    25a4:	ldp	x29, x30, [sp], #64
    25a8:	ret
    25ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    25b0:	fmov	d3, #1.000000000000000000e+00
    25b4:	ldr	d2, [x0]
    25b8:	fadd	d2, d0, d2
    25bc:	fcmpe	d2, d3
    25c0:	b.gt	25a0 <pts_ieee754_asinh+0x6c>
    25c4:	stp	d8, d9, [sp, #32]
    25c8:	fabs	d8, d0
    25cc:	fmul	d1, d1, d1
    25d0:	fmov	d0, #1.000000000000000000e+00
    25d4:	fadd	d0, d1, d0
    25d8:	fcmp	d0, #0.0
    25dc:	b.pl	2600 <pts_ieee754_asinh+0xcc>  // b.nfrst
    25e0:	str	d1, [sp, #56]
    25e4:	bl	0 <sqrt>
    25e8:	ldr	d1, [sp, #56]
    25ec:	b	2604 <pts_ieee754_asinh+0xd0>
    25f0:	ldr	x19, [sp, #16]
    25f4:	fadd	d0, d0, d0
    25f8:	ldp	x29, x30, [sp], #64
    25fc:	ret
    2600:	fsqrt	d0, d0
    2604:	fmov	d2, #1.000000000000000000e+00
    2608:	fadd	d0, d0, d2
    260c:	fdiv	d0, d1, d0
    2610:	fadd	d0, d0, d8
    2614:	bl	2180 <pts_ieee754_log1p>
    2618:	b	2590 <pts_ieee754_asinh+0x5c>
    261c:	fmov	d0, #1.000000000000000000e+00
    2620:	mov	w1, #0x40000000            	// #1073741824
    2624:	fmadd	d0, d1, d1, d0
    2628:	cmp	w0, w1
    262c:	b.le	25cc <pts_ieee754_asinh+0x98>
    2630:	fcmp	d0, #0.0
    2634:	fadd	d9, d8, d8
    2638:	b.pl	2644 <pts_ieee754_asinh+0x110>  // b.nfrst
    263c:	bl	0 <sqrt>
    2640:	b	2648 <pts_ieee754_asinh+0x114>
    2644:	fsqrt	d0, d0
    2648:	fadd	d0, d0, d8
    264c:	fmov	d1, #1.000000000000000000e+00
    2650:	fdiv	d0, d1, d0
    2654:	fadd	d0, d0, d9
    2658:	bl	1f40 <pts_ieee754_log>
    265c:	b	2590 <pts_ieee754_asinh+0x5c>

0000000000002660 <pts_ieee754_atanh>:
    2660:	fmov	x0, d0
    2664:	mov	w3, #0x3ff00000            	// #1072693248
    2668:	neg	w1, w0
    266c:	ubfx	x2, x0, #32, #31
    2670:	orr	w1, w1, w0
    2674:	orr	w1, w2, w1, lsr #31
    2678:	cmp	w1, w3
    267c:	b.hi	2738 <pts_ieee754_atanh+0xd8>  // b.pmore
    2680:	cmp	w2, w3
    2684:	b.eq	2744 <pts_ieee754_atanh+0xe4>  // b.none
    2688:	stp	x29, x30, [sp, #-16]!
    268c:	lsr	x5, x0, #32
    2690:	mov	w1, #0x3e2fffff            	// #1043333119
    2694:	mov	x29, sp
    2698:	cmp	w2, w1
    269c:	b.le	26ec <pts_ieee754_atanh+0x8c>
    26a0:	and	x0, x0, #0xffffffff
    26a4:	sbfiz	x1, x2, #32, #32
    26a8:	orr	x0, x1, x0
    26ac:	fmov	d0, #1.000000000000000000e+00
    26b0:	fmov	d1, x0
    26b4:	mov	w0, #0x3fdfffff            	// #1071644671
    26b8:	fadd	d2, d1, d1
    26bc:	fsub	d0, d0, d1
    26c0:	cmp	w2, w0
    26c4:	b.le	2714 <pts_ieee754_atanh+0xb4>
    26c8:	fdiv	d0, d2, d0
    26cc:	bl	2180 <pts_ieee754_log1p>
    26d0:	fmov	d1, #5.000000000000000000e-01
    26d4:	fmul	d0, d0, d1
    26d8:	fneg	d1, d0
    26dc:	cmp	w5, #0x0
    26e0:	fcsel	d0, d1, d0, lt	// lt = tstop
    26e4:	ldp	x29, x30, [sp], #16
    26e8:	ret
    26ec:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    26f0:	ldr	d2, [x1]
    26f4:	fadd	d1, d0, d2
    26f8:	fcmpe	d1, #0.0
    26fc:	b.gt	26e4 <pts_ieee754_atanh+0x84>
    2700:	and	x0, x0, #0xffffffff
    2704:	sbfiz	x2, x2, #32, #32
    2708:	orr	x0, x2, x0
    270c:	fmov	d1, x0
    2710:	fadd	d2, d1, d1
    2714:	fmov	d3, #1.000000000000000000e+00
    2718:	fmul	d0, d2, d1
    271c:	fsub	d1, d3, d1
    2720:	fdiv	d0, d0, d1
    2724:	fadd	d0, d0, d2
    2728:	bl	2180 <pts_ieee754_log1p>
    272c:	fmov	d1, #5.000000000000000000e-01
    2730:	fmul	d0, d0, d1
    2734:	b	26d8 <pts_ieee754_atanh+0x78>
    2738:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    273c:	fmov	d0, x0
    2740:	ret
    2744:	fcmpe	d0, #0.0
    2748:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
    274c:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    2750:	fmov	d0, x0
    2754:	fmov	d1, x1
    2758:	fcsel	d0, d0, d1, gt
    275c:	ret

0000000000002760 <pts_ieee754_log2>:
    2760:	fmov	x0, d0
    2764:	mov	w3, #0xfffff               	// #1048575
    2768:	lsr	x2, x0, #32
    276c:	mov	w4, w0
    2770:	mov	w1, w2
    2774:	cmp	w2, w3
    2778:	b.gt	28c0 <pts_ieee754_log2+0x160>
    277c:	and	w1, w2, #0x7fffffff
    2780:	orr	w0, w1, w0
    2784:	cbz	w0, 28d8 <pts_ieee754_log2+0x178>
    2788:	tbnz	w2, #31, 28e4 <pts_ieee754_log2+0x184>
    278c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2790:	fmov	d1, x0
    2794:	mov	w5, #0xffffffca            	// #-54
    2798:	mov	w2, #0x7fefffff            	// #2146435071
    279c:	fmul	d0, d0, d1
    27a0:	fmov	x0, d0
    27a4:	lsr	x1, x0, #32
    27a8:	cmp	w1, w2
    27ac:	b.gt	28d0 <pts_ieee754_log2+0x170>
    27b0:	cmp	w4, #0x0
    27b4:	mov	w2, #0x3ff00000            	// #1072693248
    27b8:	movi	d0, #0x0
    27bc:	ccmp	w1, w2, #0x0, eq	// eq = none
    27c0:	b.eq	28bc <pts_ieee754_log2+0x15c>  // b.none
    27c4:	and	w4, w1, #0xfffff
    27c8:	fmov	d0, #1.000000000000000000e+00
    27cc:	add	w3, w4, #0x95, lsl #12
    27d0:	fmov	d5, #2.000000000000000000e+00
    27d4:	add	w3, w3, #0xf64
    27d8:	adrp	x6, 0 <__kernel_rem_pio2.constprop.0>
    27dc:	and	w2, w3, #0x100000
    27e0:	fmov	d7, #5.000000000000000000e-01
    27e4:	eor	w2, w2, #0x3ff00000
    27e8:	ldr	d25, [x6]
    27ec:	orr	x2, x2, x4
    27f0:	adrp	x6, 0 <__kernel_rem_pio2.constprop.0>
    27f4:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    27f8:	movi	v2.2d, #0xffffffff00000000
    27fc:	bfi	x0, x2, #32, #32
    2800:	fmov	d1, x0
    2804:	ldr	d21, [x6]
    2808:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    280c:	fsub	d1, d1, d0
    2810:	ldr	d19, [x4]
    2814:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    2818:	ldr	d18, [x2]
    281c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    2820:	asr	w1, w1, #20
    2824:	ldr	d24, [x4]
    2828:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    282c:	fadd	d5, d1, d5
    2830:	fmul	d7, d1, d7
    2834:	ldr	d20, [x4]
    2838:	sub	w1, w1, #0x3ff
    283c:	ldr	d17, [x2]
    2840:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    2844:	add	w1, w1, w5
    2848:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    284c:	fdiv	d5, d1, d5
    2850:	fmsub	d4, d7, d1, d1
    2854:	ldr	d16, [x2]
    2858:	add	w3, w1, w3, lsr #20
    285c:	ldr	d22, [x0]
    2860:	scvtf	d0, w3
    2864:	and	v4.8b, v4.8b, v2.8b
    2868:	fsub	d2, d1, d4
    286c:	fmadd	d23, d4, d16, d0
    2870:	fmsub	d2, d7, d1, d2
    2874:	fsub	d0, d0, d23
    2878:	fmadd	d0, d4, d16, d0
    287c:	fmul	d3, d5, d5
    2880:	fmul	d6, d3, d3
    2884:	fmadd	d21, d6, d25, d21
    2888:	fmadd	d20, d6, d24, d20
    288c:	fmadd	d19, d6, d21, d19
    2890:	fmadd	d17, d6, d20, d17
    2894:	fmadd	d18, d6, d19, d18
    2898:	fmul	d3, d3, d18
    289c:	fmadd	d3, d6, d17, d3
    28a0:	fmadd	d3, d7, d1, d3
    28a4:	fmadd	d1, d5, d3, d2
    28a8:	fadd	d4, d4, d1
    28ac:	fmul	d1, d1, d16
    28b0:	fmadd	d1, d4, d22, d1
    28b4:	fadd	d0, d0, d1
    28b8:	fadd	d0, d0, d23
    28bc:	ret
    28c0:	mov	w5, #0x0                   	// #0
    28c4:	mov	w2, #0x7fefffff            	// #2146435071
    28c8:	cmp	w1, w2
    28cc:	b.le	27b0 <pts_ieee754_log2+0x50>
    28d0:	fadd	d0, d0, d0
    28d4:	ret
    28d8:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    28dc:	fmov	d0, x0
    28e0:	ret
    28e4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    28e8:	fmov	d0, x0
    28ec:	ret

00000000000028f0 <pts_ieee754_log10>:
    28f0:	fmov	x0, d0
    28f4:	mov	w4, #0xfffff               	// #1048575
    28f8:	lsr	x1, x0, #32
    28fc:	cmp	w1, w4
    2900:	b.gt	29b4 <pts_ieee754_log10+0xc4>
    2904:	and	w2, w1, #0x7fffffff
    2908:	orr	w0, w2, w0
    290c:	cbz	w0, 29d8 <pts_ieee754_log10+0xe8>
    2910:	tbnz	w1, #31, 29e4 <pts_ieee754_log10+0xf4>
    2914:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2918:	fmov	d1, x0
    291c:	mov	w4, #0xffffffca            	// #-54
    2920:	fmul	d0, d0, d1
    2924:	fmov	x0, d0
    2928:	lsr	x2, x0, #32
    292c:	mov	w3, w0
    2930:	mov	w0, #0x7fefffff            	// #2146435071
    2934:	cmp	w2, w0
    2938:	b.gt	29cc <pts_ieee754_log10+0xdc>
    293c:	cmp	w3, #0x0
    2940:	mov	w0, #0x3ff00000            	// #1072693248
    2944:	movi	d0, #0x0
    2948:	ccmp	w2, w0, #0x0, eq	// eq = none
    294c:	b.eq	29d4 <pts_ieee754_log10+0xe4>  // b.none
    2950:	asr	w0, w2, #20
    2954:	mov	w1, #0x3ff                 	// #1023
    2958:	sub	w0, w0, #0x3ff
    295c:	stp	x29, x30, [sp, #-16]!
    2960:	add	w0, w0, w4
    2964:	mov	x29, sp
    2968:	lsr	w4, w0, #31
    296c:	sub	w1, w1, w4
    2970:	add	w0, w0, w4
    2974:	bfi	w2, w1, #20, #12
    2978:	scvtf	d20, w0
    297c:	orr	x0, x3, x2, lsl #32
    2980:	fmov	d0, x0
    2984:	bl	1f40 <pts_ieee754_log>
    2988:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    298c:	ldp	x29, x30, [sp], #16
    2990:	ldr	d3, [x0]
    2994:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2998:	ldr	d2, [x0]
    299c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    29a0:	fmul	d0, d0, d3
    29a4:	ldr	d1, [x0]
    29a8:	fmadd	d0, d20, d2, d0
    29ac:	fmadd	d0, d20, d1, d0
    29b0:	ret
    29b4:	mov	w2, w1
    29b8:	mov	w3, w0
    29bc:	mov	w4, #0x0                   	// #0
    29c0:	mov	w0, #0x7fefffff            	// #2146435071
    29c4:	cmp	w2, w0
    29c8:	b.le	293c <pts_ieee754_log10+0x4c>
    29cc:	fadd	d0, d0, d0
    29d0:	ret
    29d4:	ret
    29d8:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    29dc:	fmov	d0, x0
    29e0:	ret
    29e4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    29e8:	fmov	d0, x0
    29ec:	ret

00000000000029f0 <pts_ieee754_expm1>:
    29f0:	fmov	x1, d0
    29f4:	mov	w2, #0x6879                	// #26745
    29f8:	fmov	d2, d0
    29fc:	movk	w2, #0x4043, lsl #16
    2a00:	ubfx	x0, x1, #32, #31
    2a04:	lsr	x3, x1, #32
    2a08:	cmp	w0, w2
    2a0c:	b.ls	2a98 <pts_ieee754_expm1+0xa8>  // b.plast
    2a10:	mov	w2, #0x2e41                	// #11841
    2a14:	movk	w2, #0x4086, lsl #16
    2a18:	cmp	w0, w2
    2a1c:	b.ls	2a50 <pts_ieee754_expm1+0x60>  // b.plast
    2a20:	mov	w2, #0x7fefffff            	// #2146435071
    2a24:	cmp	w0, w2
    2a28:	b.ls	2a40 <pts_ieee754_expm1+0x50>  // b.plast
    2a2c:	and	w0, w3, #0xfffff
    2a30:	orr	w0, w0, w1
    2a34:	cbz	w0, 2cbc <pts_ieee754_expm1+0x2cc>
    2a38:	fadd	d0, d0, d0
    2a3c:	ret
    2a40:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a44:	ldr	d0, [x0]
    2a48:	fcmpe	d2, d0
    2a4c:	b.gt	2ce0 <pts_ieee754_expm1+0x2f0>
    2a50:	tbnz	w3, #31, 2b94 <pts_ieee754_expm1+0x1a4>
    2a54:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a58:	fmov	d0, #5.000000000000000000e-01
    2a5c:	ldr	d1, [x0]
    2a60:	fmul	d1, d2, d1
    2a64:	fadd	d0, d0, d1
    2a68:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a6c:	ldr	d3, [x0]
    2a70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a74:	fcvtzs	w1, d0
    2a78:	ldr	d1, [x0]
    2a7c:	scvtf	d0, w1
    2a80:	fmsub	d3, d0, d3, d2
    2a84:	fmul	d0, d0, d1
    2a88:	fsub	d2, d3, d0
    2a8c:	fsub	d3, d3, d2
    2a90:	fsub	d3, d3, d0
    2a94:	b	2ab8 <pts_ieee754_expm1+0xc8>
    2a98:	mov	w1, #0x2e42                	// #11842
    2a9c:	movk	w1, #0x3fd6, lsl #16
    2aa0:	cmp	w0, w1
    2aa4:	b.hi	2be0 <pts_ieee754_expm1+0x1f0>  // b.pmore
    2aa8:	mov	w2, #0x3c8fffff            	// #1016070143
    2aac:	mov	w1, #0x0                   	// #0
    2ab0:	cmp	w0, w2
    2ab4:	b.ls	2c10 <pts_ieee754_expm1+0x220>  // b.plast
    2ab8:	fmov	d18, #5.000000000000000000e-01
    2abc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ac0:	fmov	d19, #1.000000000000000000e+00
    2ac4:	fmov	d4, #3.000000000000000000e+00
    2ac8:	fmul	d17, d2, d18
    2acc:	ldr	d20, [x0]
    2ad0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ad4:	fmov	d5, #6.000000000000000000e+00
    2ad8:	ldr	d16, [x0]
    2adc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ae0:	fmul	d1, d2, d17
    2ae4:	ldr	d7, [x0]
    2ae8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2aec:	ldr	d6, [x0]
    2af0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2af4:	fmadd	d16, d1, d20, d16
    2af8:	ldr	d0, [x0]
    2afc:	fmadd	d7, d16, d1, d7
    2b00:	fmadd	d6, d7, d1, d6
    2b04:	fmadd	d0, d6, d1, d0
    2b08:	fmadd	d0, d0, d1, d19
    2b0c:	fmsub	d4, d17, d0, d4
    2b10:	fmsub	d5, d2, d4, d5
    2b14:	fsub	d0, d0, d4
    2b18:	fdiv	d0, d0, d5
    2b1c:	fmul	d0, d0, d1
    2b20:	cbz	w1, 2b88 <pts_ieee754_expm1+0x198>
    2b24:	fsub	d0, d0, d3
    2b28:	fnmsub	d3, d0, d2, d3
    2b2c:	fsub	d3, d3, d1
    2b30:	cmn	w1, #0x1
    2b34:	b.eq	2c64 <pts_ieee754_expm1+0x274>  // b.none
    2b38:	cmp	w1, #0x1
    2b3c:	b.eq	2c48 <pts_ieee754_expm1+0x258>  // b.none
    2b40:	mov	w2, #0x3ff00000            	// #1072693248
    2b44:	add	w3, w1, #0x1
    2b48:	add	w0, w2, w1, lsl #20
    2b4c:	fmov	d0, x0
    2b50:	shl	d1, d0, #32
    2b54:	cmp	w3, #0x39
    2b58:	b.hi	2bc0 <pts_ieee754_expm1+0x1d0>  // b.pmore
    2b5c:	cmp	w1, #0x13
    2b60:	b.gt	2c74 <pts_ieee754_expm1+0x284>
    2b64:	mov	w0, #0x200000              	// #2097152
    2b68:	fsub	d3, d3, d2
    2b6c:	asr	w0, w0, w1
    2b70:	sub	w2, w2, w0
    2b74:	fmov	d0, x2
    2b78:	shl	d0, d0, #32
    2b7c:	fsub	d0, d0, d3
    2b80:	fmul	d0, d1, d0
    2b84:	ret
    2b88:	fnmsub	d1, d2, d0, d1
    2b8c:	fsub	d0, d2, d1
    2b90:	ret
    2b94:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b98:	fmov	d0, #-1.000000000000000000e+00
    2b9c:	ldr	d1, [x0]
    2ba0:	fadd	d1, d2, d1
    2ba4:	fcmpe	d1, #0.0
    2ba8:	b.mi	2a3c <pts_ieee754_expm1+0x4c>  // b.first
    2bac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2bb0:	fmov	d0, #-5.000000000000000000e-01
    2bb4:	ldr	d1, [x0]
    2bb8:	fmul	d1, d2, d1
    2bbc:	b	2a64 <pts_ieee754_expm1+0x74>
    2bc0:	fsub	d3, d3, d2
    2bc4:	fsub	d3, d19, d3
    2bc8:	cmp	w1, #0x400
    2bcc:	b.eq	2cf8 <pts_ieee754_expm1+0x308>  // b.none
    2bd0:	fmul	d0, d1, d3
    2bd4:	fmov	d1, #1.000000000000000000e+00
    2bd8:	fsub	d0, d0, d1
    2bdc:	ret
    2be0:	mov	w1, #0xa2b1                	// #41649
    2be4:	movk	w1, #0x3ff0, lsl #16
    2be8:	cmp	w0, w1
    2bec:	b.hi	2c9c <pts_ieee754_expm1+0x2ac>  // b.pmore
    2bf0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2bf4:	ldr	d3, [x0]
    2bf8:	tbz	w3, #31, 2c34 <pts_ieee754_expm1+0x244>
    2bfc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2c00:	fadd	d3, d2, d3
    2c04:	mov	w1, #0xffffffff            	// #-1
    2c08:	ldr	d0, [x0]
    2c0c:	b	2a88 <pts_ieee754_expm1+0x98>
    2c10:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2c14:	add	x0, x0, #0x0
    2c18:	ldr	d1, [x0, #40]
    2c1c:	ldr	d0, [x0, #40]
    2c20:	fadd	d1, d1, d2
    2c24:	fadd	d0, d0, d2
    2c28:	fsub	d1, d1, d0
    2c2c:	fsub	d0, d2, d1
    2c30:	ret
    2c34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2c38:	fsub	d3, d2, d3
    2c3c:	mov	w1, #0x1                   	// #1
    2c40:	ldr	d0, [x0]
    2c44:	b	2a88 <pts_ieee754_expm1+0x98>
    2c48:	fmov	d0, #-2.500000000000000000e-01
    2c4c:	fcmpe	d2, d0
    2c50:	b.mi	2ccc <pts_ieee754_expm1+0x2dc>  // b.first
    2c54:	fsub	d3, d2, d3
    2c58:	fmov	d1, #2.000000000000000000e+00
    2c5c:	fmadd	d0, d3, d1, d19
    2c60:	ret
    2c64:	fsub	d3, d2, d3
    2c68:	fmov	d1, #-5.000000000000000000e-01
    2c6c:	fmadd	d0, d3, d18, d1
    2c70:	ret
    2c74:	mov	w0, #0x3ff                 	// #1023
    2c78:	sub	w0, w0, w1
    2c7c:	lsl	w0, w0, #20
    2c80:	fmov	d0, x0
    2c84:	shl	d0, d0, #32
    2c88:	fadd	d3, d3, d0
    2c8c:	fsub	d2, d2, d3
    2c90:	fadd	d2, d2, d19
    2c94:	fmul	d0, d2, d1
    2c98:	ret
    2c9c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ca0:	cmp	w3, #0x0
    2ca4:	fmov	d0, #-5.000000000000000000e-01
    2ca8:	fmov	d3, #5.000000000000000000e-01
    2cac:	ldr	d1, [x0]
    2cb0:	fcsel	d0, d0, d3, lt	// lt = tstop
    2cb4:	fmul	d1, d2, d1
    2cb8:	b	2a64 <pts_ieee754_expm1+0x74>
    2cbc:	cmp	w3, #0x0
    2cc0:	fmov	d1, #-1.000000000000000000e+00
    2cc4:	fcsel	d0, d0, d1, ge	// ge = tcont
    2cc8:	ret
    2ccc:	fadd	d18, d2, d18
    2cd0:	fmov	d1, #-2.000000000000000000e+00
    2cd4:	fsub	d3, d3, d18
    2cd8:	fmul	d0, d3, d1
    2cdc:	ret
    2ce0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ce4:	add	x0, x0, #0x0
    2ce8:	ldr	d0, [x0, #40]
    2cec:	ldr	d1, [x0, #40]
    2cf0:	fmul	d0, d0, d1
    2cf4:	ret
    2cf8:	fadd	d3, d3, d3
    2cfc:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
    2d00:	fmov	d0, x0
    2d04:	fmul	d0, d3, d0
    2d08:	b	2bd4 <pts_ieee754_expm1+0x1e4>
    2d0c:	nop

0000000000002d10 <pts_ieee754_cbrt>:
    2d10:	fmov	x1, d0
    2d14:	fmov	d3, d0
    2d18:	mov	w3, #0x7fefffff            	// #2146435071
    2d1c:	ubfx	x0, x1, #32, #31
    2d20:	lsr	x2, x1, #32
    2d24:	cmp	w0, w3
    2d28:	b.hi	2e14 <pts_ieee754_cbrt+0x104>  // b.pmore
    2d2c:	and	w3, w2, #0x80000000
    2d30:	tst	x2, #0x7ff00000
    2d34:	b.ne	2d68 <pts_ieee754_cbrt+0x58>  // b.any
    2d38:	orr	w0, w0, w1
    2d3c:	cbz	w0, 2e10 <pts_ieee754_cbrt+0x100>
    2d40:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2d44:	fmov	d1, x0
    2d48:	mov	w2, #0xaaab                	// #43691
    2d4c:	mov	w1, #0x7893                	// #30867
    2d50:	fmul	d1, d0, d1
    2d54:	movk	w2, #0xaaaa, lsl #16
    2d58:	movk	w1, #0x297f, lsl #16
    2d5c:	fmov	x0, d1
    2d60:	ubfx	x0, x0, #32, #31
    2d64:	b	2d78 <pts_ieee754_cbrt+0x68>
    2d68:	mov	w2, #0xaaab                	// #43691
    2d6c:	mov	w1, #0x7893                	// #30867
    2d70:	movk	w2, #0xaaaa, lsl #16
    2d74:	movk	w1, #0x2a9f, lsl #16
    2d78:	umull	x0, w0, w2
    2d7c:	fmov	d4, #2.000000000000000000e+00
    2d80:	lsr	x0, x0, #33
    2d84:	add	w0, w0, w1
    2d88:	orr	w0, w0, w3
    2d8c:	fmov	d0, x0
    2d90:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d94:	shl	d1, d0, #32
    2d98:	ldr	d16, [x0]
    2d9c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2da0:	ldr	d7, [x0]
    2da4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2da8:	fdiv	d17, d1, d3
    2dac:	fmul	d0, d1, d1
    2db0:	ldr	d6, [x0]
    2db4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2db8:	ldr	d5, [x0]
    2dbc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2dc0:	ldr	d2, [x0]
    2dc4:	mov	x0, #0x80000000            	// #2147483648
    2dc8:	fmul	d0, d0, d17
    2dcc:	fmadd	d7, d0, d16, d7
    2dd0:	fmadd	d5, d0, d6, d5
    2dd4:	fmul	d6, d0, d0
    2dd8:	fmul	d6, d6, d0
    2ddc:	fmadd	d2, d7, d0, d2
    2de0:	fmadd	d2, d6, d5, d2
    2de4:	fmul	d1, d2, d1
    2de8:	fmov	x1, d1
    2dec:	add	x0, x1, x0
    2df0:	and	x0, x0, #0xffffffffc0000000
    2df4:	fmov	d1, x0
    2df8:	fmul	d0, d1, d1
    2dfc:	fdiv	d3, d3, d0
    2e00:	fmadd	d0, d1, d4, d3
    2e04:	fsub	d3, d3, d1
    2e08:	fdiv	d3, d3, d0
    2e0c:	fmadd	d0, d1, d3, d1
    2e10:	ret
    2e14:	fadd	d0, d0, d0
    2e18:	ret
    2e1c:	nop

0000000000002e20 <pts_ieee754_sin>:
    2e20:	sub	sp, sp, #0x50
    2e24:	mov	w2, #0x21fb                	// #8699
    2e28:	adrp	x0, 0 <__stack_chk_guard>
    2e2c:	ldr	x0, [x0]
    2e30:	fmov	d1, d0
    2e34:	stp	x29, x30, [sp, #48]
    2e38:	add	x29, sp, #0x30
    2e3c:	movk	w2, #0x3fe9, lsl #16
    2e40:	ldr	x1, [x0]
    2e44:	str	x1, [sp, #40]
    2e48:	mov	x1, #0x0                   	// #0
    2e4c:	fmov	x0, d0
    2e50:	ubfx	x1, x0, #32, #31
    2e54:	cmp	w1, w2
    2e58:	b.le	2f98 <pts_ieee754_sin+0x178>
    2e5c:	mov	w2, #0x7fefffff            	// #2146435071
    2e60:	cmp	w1, w2
    2e64:	b.le	2e94 <pts_ieee754_sin+0x74>
    2e68:	fsub	d0, d0, d0
    2e6c:	adrp	x0, 0 <__stack_chk_guard>
    2e70:	ldr	x0, [x0]
    2e74:	ldr	x2, [sp, #40]
    2e78:	ldr	x1, [x0]
    2e7c:	subs	x2, x2, x1
    2e80:	mov	x1, #0x0                   	// #0
    2e84:	b.ne	34d8 <pts_ieee754_sin+0x6b8>  // b.any
    2e88:	ldp	x29, x30, [sp, #48]
    2e8c:	add	sp, sp, #0x50
    2e90:	ret
    2e94:	mov	w2, #0xd97b                	// #55675
    2e98:	str	x19, [sp, #64]
    2e9c:	movk	w2, #0x4002, lsl #16
    2ea0:	lsr	x19, x0, #32
    2ea4:	cmp	w1, w2
    2ea8:	b.gt	3000 <pts_ieee754_sin+0x1e0>
    2eac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2eb0:	ldr	d0, [x0]
    2eb4:	mov	w0, #0x21fb                	// #8699
    2eb8:	movk	w0, #0x3ff9, lsl #16
    2ebc:	cmp	w19, #0x0
    2ec0:	b.le	3494 <pts_ieee754_sin+0x674>
    2ec4:	fsub	d1, d1, d0
    2ec8:	cmp	w1, w0
    2ecc:	b.eq	342c <pts_ieee754_sin+0x60c>  // b.none
    2ed0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ed4:	ldr	d2, [x0]
    2ed8:	fsub	d0, d1, d2
    2edc:	fsub	d1, d1, d0
    2ee0:	fmov	x0, d0
    2ee4:	fsub	d1, d1, d2
    2ee8:	lsr	x1, x0, #32
    2eec:	and	w1, w1, #0x7fffffff
    2ef0:	mov	w0, #0x3e3fffff            	// #1044381695
    2ef4:	cmp	w1, w0
    2ef8:	b.le	3204 <pts_ieee754_sin+0x3e4>
    2efc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f00:	fmul	d3, d0, d0
    2f04:	ldr	d16, [x0]
    2f08:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f0c:	ldr	d7, [x0]
    2f10:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f14:	fmadd	d7, d3, d16, d7
    2f18:	ldr	d6, [x0]
    2f1c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f20:	ldr	d5, [x0]
    2f24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f28:	ldr	d2, [x0]
    2f2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f30:	ldr	d4, [x0]
    2f34:	mov	w0, #0x3332                	// #13106
    2f38:	fmadd	d6, d3, d7, d6
    2f3c:	movk	w0, #0x3fd3, lsl #16
    2f40:	fmadd	d5, d3, d6, d5
    2f44:	fmadd	d2, d3, d5, d2
    2f48:	fmadd	d4, d3, d2, d4
    2f4c:	fmul	d4, d3, d4
    2f50:	cmp	w1, w0
    2f54:	b.le	3258 <pts_ieee754_sin+0x438>
    2f58:	mov	w0, #0x3fe90000            	// #1072234496
    2f5c:	cmp	w1, w0
    2f60:	b.gt	3444 <pts_ieee754_sin+0x624>
    2f64:	sub	w1, w1, #0x200, lsl #12
    2f68:	fmov	d2, x1
    2f6c:	fmov	d5, #1.000000000000000000e+00
    2f70:	shl	d2, d2, #32
    2f74:	fsub	d5, d5, d2
    2f78:	fmov	d6, #5.000000000000000000e-01
    2f7c:	fmul	d1, d0, d1
    2f80:	fnmsub	d1, d3, d4, d1
    2f84:	fnmsub	d2, d3, d6, d2
    2f88:	ldr	x19, [sp, #64]
    2f8c:	fsub	d2, d2, d1
    2f90:	fsub	d0, d5, d2
    2f94:	b	2e6c <pts_ieee754_sin+0x4c>
    2f98:	mov	w0, #0x3e3fffff            	// #1044381695
    2f9c:	cmp	w1, w0
    2fa0:	b.gt	2fac <pts_ieee754_sin+0x18c>
    2fa4:	fcvtzs	w0, d0
    2fa8:	cbz	w0, 2e6c <pts_ieee754_sin+0x4c>
    2fac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fb0:	fmul	d2, d1, d1
    2fb4:	ldr	d0, [x0]
    2fb8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fbc:	ldr	d7, [x0]
    2fc0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fc4:	fmadd	d7, d2, d0, d7
    2fc8:	fmul	d0, d1, d2
    2fcc:	ldr	d6, [x0]
    2fd0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fd4:	ldr	d5, [x0]
    2fd8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fdc:	ldr	d4, [x0]
    2fe0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2fe4:	ldr	d3, [x0]
    2fe8:	fmadd	d6, d2, d7, d6
    2fec:	fmadd	d5, d2, d6, d5
    2ff0:	fmadd	d4, d2, d5, d4
    2ff4:	fmadd	d2, d2, d4, d3
    2ff8:	fmadd	d0, d0, d2, d1
    2ffc:	b	2e6c <pts_ieee754_sin+0x4c>
    3000:	mov	w2, #0x21fb                	// #8699
    3004:	movk	w2, #0x4139, lsl #16
    3008:	cmp	w1, w2
    300c:	b.le	3088 <pts_ieee754_sin+0x268>
    3010:	asr	w2, w1, #20
    3014:	mov	x3, #0x4170000000000000    	// #4715268809856909312
    3018:	sub	w2, w2, #0x416
    301c:	fmov	d1, x3
    3020:	mov	w3, #0x3                   	// #3
    3024:	sub	w1, w1, w2, lsl #20
    3028:	bfi	x0, x1, #32, #32
    302c:	fmov	d0, x0
    3030:	fcvtzs	w0, d0
    3034:	scvtf	d2, w0
    3038:	fsub	d0, d0, d2
    303c:	str	d2, [sp, #16]
    3040:	fmul	d0, d0, d1
    3044:	fcvtzs	w0, d0
    3048:	scvtf	d2, w0
    304c:	fsub	d0, d0, d2
    3050:	fmul	d0, d0, d1
    3054:	fcmp	d0, #0.0
    3058:	stp	d2, d0, [sp, #24]
    305c:	b.ne	306c <pts_ieee754_sin+0x24c>  // b.any
    3060:	cmp	w0, #0x0
    3064:	cset	w3, ne	// ne = any
    3068:	add	w3, w3, #0x1
    306c:	mov	x1, sp
    3070:	add	x0, sp, #0x10
    3074:	bl	0 <__kernel_rem_pio2.constprop.0>
    3078:	ldr	d0, [sp]
    307c:	tbnz	w19, #31, 347c <pts_ieee754_sin+0x65c>
    3080:	ldr	d1, [sp, #8]
    3084:	b	3158 <pts_ieee754_sin+0x338>
    3088:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    308c:	fabs	d1, d0
    3090:	fmov	d0, #5.000000000000000000e-01
    3094:	ldr	d3, [x0]
    3098:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    309c:	ldr	d4, [x0]
    30a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    30a4:	fmadd	d0, d1, d3, d0
    30a8:	ldr	d2, [x0]
    30ac:	fcvtzs	w0, d0
    30b0:	scvtf	d3, w0
    30b4:	fmsub	d1, d3, d4, d1
    30b8:	fmul	d2, d3, d2
    30bc:	fsub	d0, d1, d2
    30c0:	cmp	w0, #0x1f
    30c4:	b.le	3278 <pts_ieee754_sin+0x458>
    30c8:	fmov	x2, d0
    30cc:	asr	w1, w1, #20
    30d0:	ubfx	x2, x2, #52, #11
    30d4:	sub	w2, w1, w2
    30d8:	cmp	w2, #0x10
    30dc:	b.le	3140 <pts_ieee754_sin+0x320>
    30e0:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    30e4:	ldr	d0, [x2]
    30e8:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    30ec:	ldr	d5, [x2]
    30f0:	fmsub	d4, d3, d0, d1
    30f4:	fsub	d2, d1, d4
    30f8:	fmov	d1, d4
    30fc:	fmsub	d2, d3, d0, d2
    3100:	fnmsub	d2, d3, d5, d2
    3104:	fsub	d0, d4, d2
    3108:	fmov	x2, d0
    310c:	ubfx	x2, x2, #52, #11
    3110:	sub	w1, w1, w2
    3114:	cmp	w1, #0x31
    3118:	b.le	3140 <pts_ieee754_sin+0x320>
    311c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    3120:	ldr	d5, [x1]
    3124:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    3128:	ldr	d2, [x1]
    312c:	fmsub	d1, d3, d5, d4
    3130:	fsub	d0, d4, d1
    3134:	fmsub	d0, d3, d5, d0
    3138:	fnmsub	d2, d3, d2, d0
    313c:	fsub	d0, d1, d2
    3140:	fsub	d1, d1, d0
    3144:	fsub	d1, d1, d2
    3148:	tbz	w19, #31, 3158 <pts_ieee754_sin+0x338>
    314c:	fneg	d0, d0
    3150:	fneg	d1, d1
    3154:	neg	w0, w0
    3158:	fmov	x1, d0
    315c:	and	w0, w0, #0x3
    3160:	lsr	x1, x1, #32
    3164:	and	w2, w1, #0x7fffffff
    3168:	cmp	w0, #0x1
    316c:	b.eq	2eec <pts_ieee754_sin+0xcc>  // b.none
    3170:	cmp	w0, #0x2
    3174:	b.eq	3314 <pts_ieee754_sin+0x4f4>  // b.none
    3178:	cbz	w0, 3298 <pts_ieee754_sin+0x478>
    317c:	and	w1, w1, #0x7fffffff
    3180:	mov	w0, #0x3e3fffff            	// #1044381695
    3184:	cmp	w1, w0
    3188:	b.gt	338c <pts_ieee754_sin+0x56c>
    318c:	fcvtzs	w0, d0
    3190:	cbz	w0, 3468 <pts_ieee754_sin+0x648>
    3194:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3198:	fmul	d3, d0, d0
    319c:	ldr	d16, [x0]
    31a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31a4:	ldr	d7, [x0]
    31a8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31ac:	fmadd	d7, d3, d16, d7
    31b0:	ldr	d6, [x0]
    31b4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31b8:	ldr	d5, [x0]
    31bc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31c0:	ldr	d2, [x0]
    31c4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31c8:	ldr	d4, [x0]
    31cc:	fmadd	d6, d3, d7, d6
    31d0:	fmadd	d5, d3, d6, d5
    31d4:	fmadd	d2, d3, d5, d2
    31d8:	fmadd	d4, d3, d2, d4
    31dc:	fmul	d4, d3, d4
    31e0:	fmul	d1, d0, d1
    31e4:	fmov	d2, #5.000000000000000000e-01
    31e8:	fnmsub	d1, d3, d4, d1
    31ec:	fmov	d0, #1.000000000000000000e+00
    31f0:	fnmsub	d1, d3, d2, d1
    31f4:	fsub	d0, d0, d1
    31f8:	ldr	x19, [sp, #64]
    31fc:	fneg	d0, d0
    3200:	b	2e6c <pts_ieee754_sin+0x4c>
    3204:	fcvtzs	w0, d0
    3208:	cbz	w0, 345c <pts_ieee754_sin+0x63c>
    320c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3210:	fmul	d3, d0, d0
    3214:	ldr	d16, [x0]
    3218:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    321c:	ldr	d7, [x0]
    3220:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3224:	fmadd	d7, d3, d16, d7
    3228:	ldr	d6, [x0]
    322c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3230:	ldr	d5, [x0]
    3234:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3238:	ldr	d2, [x0]
    323c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3240:	ldr	d4, [x0]
    3244:	fmadd	d6, d3, d7, d6
    3248:	fmadd	d5, d3, d6, d5
    324c:	fmadd	d2, d3, d5, d2
    3250:	fmadd	d4, d3, d2, d4
    3254:	fmul	d4, d3, d4
    3258:	fmul	d1, d0, d1
    325c:	fmov	d2, #5.000000000000000000e-01
    3260:	fnmsub	d1, d3, d4, d1
    3264:	fmov	d0, #1.000000000000000000e+00
    3268:	ldr	x19, [sp, #64]
    326c:	fnmsub	d1, d3, d2, d1
    3270:	fsub	d0, d0, d1
    3274:	b	2e6c <pts_ieee754_sin+0x4c>
    3278:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    327c:	add	x2, x2, #0x0
    3280:	add	x2, x2, #0x110
    3284:	sub	w3, w0, #0x1
    3288:	ldr	w2, [x2, w3, sxtw #2]
    328c:	cmp	w1, w2
    3290:	b.ne	3140 <pts_ieee754_sin+0x320>  // b.any
    3294:	b	30c8 <pts_ieee754_sin+0x2a8>
    3298:	mov	w0, #0x3e3fffff            	// #1044381695
    329c:	cmp	w2, w0
    32a0:	b.gt	32ac <pts_ieee754_sin+0x48c>
    32a4:	fcvtzs	w0, d0
    32a8:	cbz	w0, 3474 <pts_ieee754_sin+0x654>
    32ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32b0:	fmul	d2, d0, d0
    32b4:	fmov	d17, #5.000000000000000000e-01
    32b8:	ldr	d7, [x0]
    32bc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32c0:	ldr	x19, [sp, #64]
    32c4:	ldr	d6, [x0]
    32c8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32cc:	fmadd	d6, d2, d7, d6
    32d0:	fmul	d7, d2, d0
    32d4:	ldr	d5, [x0]
    32d8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32dc:	ldr	d4, [x0]
    32e0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32e4:	ldr	d3, [x0]
    32e8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32ec:	ldr	d16, [x0]
    32f0:	fmadd	d5, d2, d6, d5
    32f4:	fmadd	d4, d2, d5, d4
    32f8:	fmadd	d3, d2, d4, d3
    32fc:	fmul	d3, d7, d3
    3300:	fnmsub	d3, d1, d17, d3
    3304:	fnmsub	d2, d2, d3, d1
    3308:	fmadd	d2, d7, d16, d2
    330c:	fsub	d0, d0, d2
    3310:	b	2e6c <pts_ieee754_sin+0x4c>
    3314:	mov	w0, #0x3e3fffff            	// #1044381695
    3318:	cmp	w2, w0
    331c:	b.gt	3328 <pts_ieee754_sin+0x508>
    3320:	fcvtzs	w0, d0
    3324:	cbz	w0, 31f8 <pts_ieee754_sin+0x3d8>
    3328:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    332c:	fmul	d2, d0, d0
    3330:	fmov	d17, #5.000000000000000000e-01
    3334:	ldr	d7, [x0]
    3338:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    333c:	ldr	d6, [x0]
    3340:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3344:	fmadd	d6, d2, d7, d6
    3348:	fmul	d7, d2, d0
    334c:	ldr	d5, [x0]
    3350:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3354:	ldr	d4, [x0]
    3358:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    335c:	ldr	d3, [x0]
    3360:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3364:	ldr	d16, [x0]
    3368:	fmadd	d5, d2, d6, d5
    336c:	fmadd	d4, d2, d5, d4
    3370:	fmadd	d3, d2, d4, d3
    3374:	fmul	d3, d7, d3
    3378:	fnmsub	d3, d1, d17, d3
    337c:	fnmsub	d2, d2, d3, d1
    3380:	fmadd	d2, d7, d16, d2
    3384:	fsub	d0, d0, d2
    3388:	b	31f8 <pts_ieee754_sin+0x3d8>
    338c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3390:	fmul	d3, d0, d0
    3394:	ldr	d16, [x0]
    3398:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    339c:	ldr	d7, [x0]
    33a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33a4:	fmadd	d7, d3, d16, d7
    33a8:	ldr	d6, [x0]
    33ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33b0:	ldr	d5, [x0]
    33b4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33b8:	ldr	d2, [x0]
    33bc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33c0:	ldr	d4, [x0]
    33c4:	mov	w0, #0x3332                	// #13106
    33c8:	fmadd	d6, d3, d7, d6
    33cc:	movk	w0, #0x3fd3, lsl #16
    33d0:	fmadd	d5, d3, d6, d5
    33d4:	fmadd	d2, d3, d5, d2
    33d8:	fmadd	d4, d3, d2, d4
    33dc:	fmul	d4, d3, d4
    33e0:	cmp	w1, w0
    33e4:	b.le	31e0 <pts_ieee754_sin+0x3c0>
    33e8:	mov	w0, #0x3fe90000            	// #1072234496
    33ec:	cmp	w1, w0
    33f0:	b.gt	3450 <pts_ieee754_sin+0x630>
    33f4:	sub	w1, w1, #0x200, lsl #12
    33f8:	fmov	d2, x1
    33fc:	fmov	d5, #1.000000000000000000e+00
    3400:	shl	d2, d2, #32
    3404:	fsub	d5, d5, d2
    3408:	fmov	d6, #5.000000000000000000e-01
    340c:	fmul	d1, d0, d1
    3410:	fnmsub	d1, d3, d4, d1
    3414:	fnmsub	d2, d3, d6, d2
    3418:	ldr	x19, [sp, #64]
    341c:	fsub	d2, d2, d1
    3420:	fsub	d0, d5, d2
    3424:	fneg	d0, d0
    3428:	b	2e6c <pts_ieee754_sin+0x4c>
    342c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3430:	ldr	d0, [x0]
    3434:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3438:	ldr	d2, [x0]
    343c:	fsub	d1, d1, d0
    3440:	b	2ed8 <pts_ieee754_sin+0xb8>
    3444:	fmov	d5, #7.187500000000000000e-01
    3448:	fmov	d2, #2.812500000000000000e-01
    344c:	b	2f78 <pts_ieee754_sin+0x158>
    3450:	fmov	d5, #7.187500000000000000e-01
    3454:	fmov	d2, #2.812500000000000000e-01
    3458:	b	3408 <pts_ieee754_sin+0x5e8>
    345c:	ldr	x19, [sp, #64]
    3460:	fmov	d0, #1.000000000000000000e+00
    3464:	b	2e6c <pts_ieee754_sin+0x4c>
    3468:	ldr	x19, [sp, #64]
    346c:	fmov	d0, #-1.000000000000000000e+00
    3470:	b	2e6c <pts_ieee754_sin+0x4c>
    3474:	ldr	x19, [sp, #64]
    3478:	b	2e6c <pts_ieee754_sin+0x4c>
    347c:	fneg	d0, d0
    3480:	ldr	d1, [sp, #8]
    3484:	neg	w0, w0
    3488:	fneg	d1, d1
    348c:	str	d0, [sp]
    3490:	b	3158 <pts_ieee754_sin+0x338>
    3494:	fadd	d1, d1, d0
    3498:	cmp	w1, w0
    349c:	b.eq	34c0 <pts_ieee754_sin+0x6a0>  // b.none
    34a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    34a4:	ldr	d2, [x0]
    34a8:	fadd	d0, d1, d2
    34ac:	fsub	d1, d1, d0
    34b0:	fmov	x0, d0
    34b4:	fadd	d1, d1, d2
    34b8:	lsr	x1, x0, #32
    34bc:	b	317c <pts_ieee754_sin+0x35c>
    34c0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    34c4:	ldr	d0, [x0]
    34c8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    34cc:	ldr	d2, [x0]
    34d0:	fadd	d1, d1, d0
    34d4:	b	34a8 <pts_ieee754_sin+0x688>
    34d8:	str	x19, [sp, #64]
    34dc:	bl	0 <__stack_chk_fail>

00000000000034e0 <pts_ieee754_tan>:
    34e0:	sub	sp, sp, #0x30
    34e4:	mov	w2, #0x21fb                	// #8699
    34e8:	adrp	x0, 0 <__stack_chk_guard>
    34ec:	ldr	x0, [x0]
    34f0:	fmov	d1, d0
    34f4:	stp	x29, x30, [sp, #32]
    34f8:	add	x29, sp, #0x20
    34fc:	movk	w2, #0x3fe9, lsl #16
    3500:	ldr	x1, [x0]
    3504:	str	x1, [sp, #24]
    3508:	mov	x1, #0x0                   	// #0
    350c:	fmov	x0, d0
    3510:	lsr	x1, x0, #32
    3514:	and	w0, w1, #0x7fffffff
    3518:	cmp	w0, w2
    351c:	b.le	35e8 <pts_ieee754_tan+0x108>
    3520:	mov	w1, #0x7fefffff            	// #2146435071
    3524:	cmp	w0, w1
    3528:	b.le	3558 <pts_ieee754_tan+0x78>
    352c:	fsub	d0, d0, d0
    3530:	adrp	x0, 0 <__stack_chk_guard>
    3534:	ldr	x0, [x0]
    3538:	ldr	x2, [sp, #24]
    353c:	ldr	x1, [x0]
    3540:	subs	x2, x2, x1
    3544:	mov	x1, #0x0                   	// #0
    3548:	b.ne	38b8 <pts_ieee754_tan+0x3d8>  // b.any
    354c:	ldp	x29, x30, [sp, #32]
    3550:	add	sp, sp, #0x30
    3554:	ret
    3558:	add	x0, sp, #0x8
    355c:	bl	980 <__ieee754_rem_pio2>
    3560:	ldp	d1, d2, [sp, #8]
    3564:	ubfiz	w2, w0, #1, #1
    3568:	mov	w1, #0x1                   	// #1
    356c:	sub	w2, w1, w2
    3570:	lsl	w0, w0, #1
    3574:	mov	w5, #0x3e2fffff            	// #1043333119
    3578:	fmov	x3, d1
    357c:	ubfx	x1, x3, #32, #31
    3580:	lsr	x4, x3, #32
    3584:	cmp	w1, w5
    3588:	b.gt	3734 <pts_ieee754_tan+0x254>
    358c:	fcvtzs	w5, d1
    3590:	cbnz	w5, 3768 <pts_ieee754_tan+0x288>
    3594:	mvn	w0, w0
    3598:	orr	w1, w1, w3
    359c:	and	w0, w0, #0x2
    35a0:	orr	w0, w0, w1
    35a4:	cbz	w0, 38a8 <pts_ieee754_tan+0x3c8>
    35a8:	fmov	d0, d1
    35ac:	cmp	w2, #0x1
    35b0:	b.eq	3530 <pts_ieee754_tan+0x50>  // b.none
    35b4:	fadd	d3, d1, d2
    35b8:	fmov	d4, #-1.000000000000000000e+00
    35bc:	movi	v5.2d, #0xffffffff00000000
    35c0:	fmov	d1, #1.000000000000000000e+00
    35c4:	fdiv	d4, d4, d3
    35c8:	and	v3.8b, v3.8b, v5.8b
    35cc:	fsub	d0, d3, d0
    35d0:	fsub	d0, d2, d0
    35d4:	and	v2.8b, v4.8b, v5.8b
    35d8:	fmadd	d1, d3, d2, d1
    35dc:	fmadd	d1, d0, d2, d1
    35e0:	fmadd	d0, d4, d1, d2
    35e4:	b	3530 <pts_ieee754_tan+0x50>
    35e8:	mov	w2, #0x3e2fffff            	// #1043333119
    35ec:	cmp	w0, w2
    35f0:	b.le	3728 <pts_ieee754_tan+0x248>
    35f4:	mov	w2, #0x9427                	// #37927
    35f8:	movk	w2, #0x3fe5, lsl #16
    35fc:	cmp	w0, w2
    3600:	b.le	3628 <pts_ieee754_tan+0x148>
    3604:	fneg	d3, d0
    3608:	cmp	w1, #0x0
    360c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3610:	ldr	d0, [x2]
    3614:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3618:	fcsel	d1, d3, d1, lt	// lt = tstop
    361c:	ldr	d2, [x2]
    3620:	fsub	d0, d0, d1
    3624:	fadd	d1, d0, d2
    3628:	fmul	d4, d1, d1
    362c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3630:	movi	d3, #0x0
    3634:	ldr	d24, [x2]
    3638:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    363c:	fmul	d0, d4, d4
    3640:	ldr	d21, [x2]
    3644:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3648:	fmul	d22, d1, d4
    364c:	ldr	d23, [x2]
    3650:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3654:	fmadd	d21, d0, d24, d21
    3658:	ldr	d20, [x2]
    365c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3660:	fmadd	d20, d0, d23, d20
    3664:	ldr	d19, [x2]
    3668:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    366c:	ldr	d18, [x2]
    3670:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3674:	ldr	d17, [x2]
    3678:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    367c:	fmadd	d19, d0, d21, d19
    3680:	ldr	d16, [x2]
    3684:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3688:	fmadd	d18, d0, d20, d18
    368c:	ldr	d7, [x2]
    3690:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3694:	ldr	d6, [x2]
    3698:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    369c:	ldr	d5, [x2]
    36a0:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    36a4:	fmadd	d17, d0, d19, d17
    36a8:	ldr	d2, [x2]
    36ac:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    36b0:	fmadd	d16, d0, d18, d16
    36b4:	ldr	d23, [x2]
    36b8:	mov	w2, #0x9427                	// #37927
    36bc:	movk	w2, #0x3fe5, lsl #16
    36c0:	fmadd	d7, d0, d17, d7
    36c4:	fmadd	d6, d0, d16, d6
    36c8:	fmadd	d5, d0, d7, d5
    36cc:	fmadd	d0, d0, d6, d2
    36d0:	fmadd	d0, d4, d5, d0
    36d4:	fmadd	d0, d22, d0, d3
    36d8:	fmadd	d3, d4, d0, d3
    36dc:	fmadd	d3, d22, d23, d3
    36e0:	fadd	d0, d1, d3
    36e4:	cmp	w0, w2
    36e8:	b.le	3530 <pts_ieee754_tan+0x50>
    36ec:	fmov	d4, #1.000000000000000000e+00
    36f0:	fmul	d2, d0, d0
    36f4:	fmov	d6, #2.000000000000000000e+00
    36f8:	asr	w1, w1, #30
    36fc:	fadd	d0, d0, d4
    3700:	and	w1, w1, #0x2
    3704:	mov	w0, #0x1                   	// #1
    3708:	sub	w0, w0, w1
    370c:	scvtf	d5, w0
    3710:	fdiv	d2, d2, d0
    3714:	fsub	d2, d2, d3
    3718:	fsub	d2, d1, d2
    371c:	fmsub	d4, d2, d6, d4
    3720:	fmul	d0, d5, d4
    3724:	b	3530 <pts_ieee754_tan+0x50>
    3728:	fcvtzs	w2, d0
    372c:	cbz	w2, 3530 <pts_ieee754_tan+0x50>
    3730:	b	3628 <pts_ieee754_tan+0x148>
    3734:	mov	w0, #0x9427                	// #37927
    3738:	movk	w0, #0x3fe5, lsl #16
    373c:	cmp	w1, w0
    3740:	b.le	3768 <pts_ieee754_tan+0x288>
    3744:	tbnz	w4, #31, 389c <pts_ieee754_tan+0x3bc>
    3748:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    374c:	ldr	d0, [x0]
    3750:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3754:	ldr	d3, [x0]
    3758:	fsub	d0, d0, d1
    375c:	fsub	d1, d3, d2
    3760:	movi	d2, #0x0
    3764:	fadd	d1, d1, d0
    3768:	fmul	d4, d1, d1
    376c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3770:	ldr	d25, [x0]
    3774:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3778:	fmul	d0, d4, d4
    377c:	ldr	d21, [x0]
    3780:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3784:	fmul	d22, d1, d4
    3788:	ldr	d24, [x0]
    378c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3790:	fmadd	d21, d0, d25, d21
    3794:	ldr	d20, [x0]
    3798:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    379c:	fmadd	d20, d0, d24, d20
    37a0:	ldr	d19, [x0]
    37a4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37a8:	ldr	d18, [x0]
    37ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37b0:	ldr	d17, [x0]
    37b4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37b8:	fmadd	d19, d0, d21, d19
    37bc:	ldr	d16, [x0]
    37c0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37c4:	fmadd	d18, d0, d20, d18
    37c8:	ldr	d7, [x0]
    37cc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37d0:	ldr	d6, [x0]
    37d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37d8:	ldr	d5, [x0]
    37dc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37e0:	fmadd	d17, d0, d19, d17
    37e4:	ldr	d3, [x0]
    37e8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    37ec:	fmadd	d16, d0, d18, d16
    37f0:	ldr	d23, [x0]
    37f4:	mov	w0, #0x9427                	// #37927
    37f8:	movk	w0, #0x3fe5, lsl #16
    37fc:	fmadd	d7, d0, d17, d7
    3800:	fmadd	d6, d0, d16, d6
    3804:	fmadd	d5, d0, d7, d5
    3808:	fmadd	d0, d0, d6, d3
    380c:	fmadd	d0, d4, d5, d0
    3810:	fmadd	d0, d22, d0, d2
    3814:	fmadd	d2, d4, d0, d2
    3818:	fmadd	d2, d22, d23, d2
    381c:	fadd	d0, d1, d2
    3820:	cmp	w1, w0
    3824:	b.gt	3860 <pts_ieee754_tan+0x380>
    3828:	cmp	w2, #0x1
    382c:	b.eq	3530 <pts_ieee754_tan+0x50>  // b.none
    3830:	movi	v6.2d, #0xffffffff00000000
    3834:	fmov	d5, #-1.000000000000000000e+00
    3838:	fmov	d3, #1.000000000000000000e+00
    383c:	and	v4.8b, v0.8b, v6.8b
    3840:	fdiv	d0, d5, d0
    3844:	fsub	d1, d4, d1
    3848:	fsub	d2, d2, d1
    384c:	and	v1.8b, v0.8b, v6.8b
    3850:	fmadd	d3, d4, d1, d3
    3854:	fmadd	d3, d2, d1, d3
    3858:	fmadd	d0, d0, d3, d1
    385c:	b	3530 <pts_ieee754_tan+0x50>
    3860:	scvtf	d4, w2
    3864:	fmul	d3, d0, d0
    3868:	fmov	d6, #2.000000000000000000e+00
    386c:	asr	w4, w4, #30
    3870:	and	w4, w4, #0x2
    3874:	mov	w0, #0x1                   	// #1
    3878:	sub	w0, w0, w4
    387c:	fadd	d0, d0, d4
    3880:	scvtf	d5, w0
    3884:	fdiv	d0, d3, d0
    3888:	fsub	d0, d0, d2
    388c:	fsub	d0, d1, d0
    3890:	fmsub	d4, d0, d6, d4
    3894:	fmul	d0, d5, d4
    3898:	b	3530 <pts_ieee754_tan+0x50>
    389c:	fneg	d1, d1
    38a0:	fneg	d2, d2
    38a4:	b	3748 <pts_ieee754_tan+0x268>
    38a8:	fabs	d1, d1
    38ac:	fmov	d0, #1.000000000000000000e+00
    38b0:	fdiv	d0, d0, d1
    38b4:	b	3530 <pts_ieee754_tan+0x50>
    38b8:	bl	0 <__stack_chk_fail>
    38bc:	nop

00000000000038c0 <pts_ieee754_cosh>:
    38c0:	fmov	x1, d0
    38c4:	stp	x29, x30, [sp, #-16]!
    38c8:	mov	w0, #0x2e42                	// #11842
    38cc:	mov	x29, sp
    38d0:	fmov	d1, d0
    38d4:	movk	w0, #0x3fd6, lsl #16
    38d8:	ubfx	x4, x1, #32, #31
    38dc:	fabs	d0, d0
    38e0:	cmp	w4, w0
    38e4:	b.le	393c <pts_ieee754_cosh+0x7c>
    38e8:	mov	w0, #0x4035ffff            	// #1077280767
    38ec:	cmp	w4, w0
    38f0:	b.le	3984 <pts_ieee754_cosh+0xc4>
    38f4:	mov	w0, #0x2e41                	// #11841
    38f8:	movk	w0, #0x4086, lsl #16
    38fc:	cmp	w4, w0
    3900:	b.le	3970 <pts_ieee754_cosh+0xb0>
    3904:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3908:	ldr	d2, [x0]
    390c:	fcmpe	d0, d2
    3910:	b.ls	39a8 <pts_ieee754_cosh+0xe8>  // b.plast
    3914:	mov	w0, #0x7fefffff            	// #2146435071
    3918:	cmp	w4, w0
    391c:	b.gt	399c <pts_ieee754_cosh+0xdc>
    3920:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3924:	add	x0, x0, #0x0
    3928:	ldr	d0, [x0, #48]
    392c:	ldr	d1, [x0, #48]
    3930:	fmul	d0, d0, d1
    3934:	ldp	x29, x30, [sp], #16
    3938:	ret
    393c:	bl	29f0 <pts_ieee754_expm1>
    3940:	fmov	d1, d0
    3944:	fmov	d3, #1.000000000000000000e+00
    3948:	mov	w0, #0x3c7fffff            	// #1015021567
    394c:	fadd	d0, d0, d3
    3950:	cmp	w4, w0
    3954:	b.le	3934 <pts_ieee754_cosh+0x74>
    3958:	fmul	d2, d1, d1
    395c:	fadd	d1, d0, d0
    3960:	ldp	x29, x30, [sp], #16
    3964:	fdiv	d1, d2, d1
    3968:	fadd	d0, d1, d3
    396c:	ret
    3970:	bl	1c50 <pts_ieee754_exp>
    3974:	fmov	d1, #5.000000000000000000e-01
    3978:	ldp	x29, x30, [sp], #16
    397c:	fmul	d0, d0, d1
    3980:	ret
    3984:	bl	1c50 <pts_ieee754_exp>
    3988:	fmov	d2, #5.000000000000000000e-01
    398c:	ldp	x29, x30, [sp], #16
    3990:	fdiv	d1, d2, d0
    3994:	fmadd	d0, d0, d2, d1
    3998:	ret
    399c:	fmul	d0, d1, d1
    39a0:	ldp	x29, x30, [sp], #16
    39a4:	ret
    39a8:	fmov	d18, #5.000000000000000000e-01
    39ac:	fmul	d0, d0, d18
    39b0:	bl	1c50 <pts_ieee754_exp>
    39b4:	fmul	d1, d0, d18
    39b8:	fmul	d0, d1, d0
    39bc:	b	3934 <pts_ieee754_cosh+0x74>

00000000000039c0 <pts_ieee754_sinh>:
    39c0:	fcmpe	d0, #0.0
    39c4:	fabs	d21, d0
    39c8:	fmov	d1, #-5.000000000000000000e-01
    39cc:	fmov	d2, #5.000000000000000000e-01
    39d0:	fmov	d3, #2.200000000000000000e+01
    39d4:	stp	x29, x30, [sp, #-16]!
    39d8:	fcsel	d22, d1, d2, mi	// mi = first
    39dc:	fcmpe	d21, d3
    39e0:	mov	x29, sp
    39e4:	b.mi	3a20 <pts_ieee754_sinh+0x60>  // b.first
    39e8:	mov	x0, #0x2e4200000000        	// #50861002719232
    39ec:	movk	x0, #0x4086, lsl #48
    39f0:	fmov	d1, x0
    39f4:	fcmpe	d21, d1
    39f8:	b.mi	3a5c <pts_ieee754_sinh+0x9c>  // b.first
    39fc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3a00:	ldr	d1, [x0]
    3a04:	fcmpe	d21, d1
    3a08:	b.ls	3a90 <pts_ieee754_sinh+0xd0>  // b.plast
    3a0c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3a10:	ldr	d1, [x0]
    3a14:	fmul	d0, d0, d1
    3a18:	ldp	x29, x30, [sp], #16
    3a1c:	ret
    3a20:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
    3a24:	fmov	d1, x0
    3a28:	fcmpe	d21, d1
    3a2c:	b.mi	3a18 <pts_ieee754_sinh+0x58>  // b.first
    3a30:	fmov	d0, d21
    3a34:	bl	29f0 <pts_ieee754_expm1>
    3a38:	fmov	d1, #1.000000000000000000e+00
    3a3c:	fcmpe	d21, d1
    3a40:	b.mi	3a70 <pts_ieee754_sinh+0xb0>  // b.first
    3a44:	fadd	d1, d0, d1
    3a48:	ldp	x29, x30, [sp], #16
    3a4c:	fdiv	d1, d0, d1
    3a50:	fadd	d0, d1, d0
    3a54:	fmul	d0, d0, d22
    3a58:	ret
    3a5c:	fmov	d0, d21
    3a60:	bl	1c50 <pts_ieee754_exp>
    3a64:	fmul	d0, d0, d22
    3a68:	ldp	x29, x30, [sp], #16
    3a6c:	ret
    3a70:	fmul	d2, d0, d0
    3a74:	fadd	d1, d0, d1
    3a78:	fmov	d3, #2.000000000000000000e+00
    3a7c:	ldp	x29, x30, [sp], #16
    3a80:	fdiv	d1, d2, d1
    3a84:	fnmsub	d0, d0, d3, d1
    3a88:	fmul	d0, d0, d22
    3a8c:	ret
    3a90:	fmul	d0, d21, d2
    3a94:	bl	1c50 <pts_ieee754_exp>
    3a98:	fmul	d1, d22, d0
    3a9c:	fmul	d0, d1, d0
    3aa0:	b	3a18 <pts_ieee754_sinh+0x58>

0000000000003aa4 <pts_ieee754_tanh>:
    3aa4:	fmov	x0, d0
    3aa8:	fmov	d1, d0
    3aac:	mov	w1, #0x7fefffff            	// #2146435071
    3ab0:	lsr	x4, x0, #32
    3ab4:	and	w0, w4, #0x7fffffff
    3ab8:	cmp	w0, w1
    3abc:	b.le	3adc <pts_ieee754_tanh+0x38>
    3ac0:	fmov	d0, #1.000000000000000000e+00
    3ac4:	fdiv	d1, d0, d1
    3ac8:	tbnz	w4, #31, 3ad4 <pts_ieee754_tanh+0x30>
    3acc:	fadd	d0, d1, d0
    3ad0:	ret
    3ad4:	fsub	d0, d1, d0
    3ad8:	ret
    3adc:	mov	w1, #0x4035ffff            	// #1077280767
    3ae0:	cmp	w0, w1
    3ae4:	b.gt	3b3c <pts_ieee754_tanh+0x98>
    3ae8:	stp	x29, x30, [sp, #-16]!
    3aec:	mov	w1, #0x3e2fffff            	// #1043333119
    3af0:	mov	x29, sp
    3af4:	cmp	w0, w1
    3af8:	b.le	3b60 <pts_ieee754_tanh+0xbc>
    3afc:	fabs	d0, d0
    3b00:	mov	w1, #0x3fefffff            	// #1072693247
    3b04:	cmp	w0, w1
    3b08:	b.le	3b7c <pts_ieee754_tanh+0xd8>
    3b0c:	fadd	d0, d0, d0
    3b10:	bl	29f0 <pts_ieee754_expm1>
    3b14:	fmov	d2, #2.000000000000000000e+00
    3b18:	fmov	d1, #1.000000000000000000e+00
    3b1c:	fadd	d0, d0, d2
    3b20:	fdiv	d2, d2, d0
    3b24:	fsub	d0, d1, d2
    3b28:	fneg	d1, d0
    3b2c:	cmp	w4, #0x0
    3b30:	fcsel	d0, d1, d0, lt	// lt = tstop
    3b34:	ldp	x29, x30, [sp], #16
    3b38:	ret
    3b3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3b40:	add	x0, x0, #0x0
    3b44:	fmov	d0, #1.000000000000000000e+00
    3b48:	cmp	w4, #0x0
    3b4c:	ldr	d1, [x0, #56]
    3b50:	fsub	d0, d0, d1
    3b54:	fneg	d1, d0
    3b58:	fcsel	d0, d1, d0, lt	// lt = tstop
    3b5c:	ret
    3b60:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3b64:	fmov	d3, #1.000000000000000000e+00
    3b68:	ldr	d2, [x0]
    3b6c:	fadd	d2, d0, d2
    3b70:	fcmpe	d2, d3
    3b74:	b.gt	3b34 <pts_ieee754_tanh+0x90>
    3b78:	fabs	d0, d0
    3b7c:	fmov	d1, #-2.000000000000000000e+00
    3b80:	fmul	d0, d0, d1
    3b84:	bl	29f0 <pts_ieee754_expm1>
    3b88:	fneg	d1, d0
    3b8c:	fmov	d2, #2.000000000000000000e+00
    3b90:	fadd	d0, d0, d2
    3b94:	fdiv	d0, d1, d0
    3b98:	b	3b28 <pts_ieee754_tanh+0x84>
