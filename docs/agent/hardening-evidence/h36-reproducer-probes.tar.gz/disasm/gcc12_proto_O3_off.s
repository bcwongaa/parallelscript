
gcc12/proto_O3_off.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <__kernel_tan>:
       0:	fmov	x2, d0
       4:	fmov	d2, d0
       8:	mov	w4, #0x3e2fffff            	// #1043333119
       c:	ubfx	x1, x2, #32, #31
      10:	lsr	x3, x2, #32
      14:	cmp	w1, w4
      18:	b.gt	70 <__kernel_tan+0x70>
      1c:	fcvtzs	w4, d0
      20:	cbnz	w4, a4 <__kernel_tan+0xa4>
      24:	add	w3, w0, #0x1
      28:	orr	w2, w3, w2
      2c:	orr	w1, w2, w1
      30:	cbz	w1, 204 <__kernel_tan+0x204>
      34:	cmp	w0, #0x1
      38:	b.eq	6c <__kernel_tan+0x6c>  // b.none
      3c:	fadd	d3, d0, d1
      40:	fmov	d4, #-1.000000000000000000e+00
      44:	movi	v5.2d, #0xffffffff00000000
      48:	fmov	d2, #1.000000000000000000e+00
      4c:	fdiv	d4, d4, d3
      50:	and	v3.8b, v3.8b, v5.8b
      54:	fsub	d0, d3, d0
      58:	fsub	d0, d1, d0
      5c:	and	v1.8b, v4.8b, v5.8b
      60:	fmadd	d2, d3, d1, d2
      64:	fmadd	d2, d0, d1, d2
      68:	fmadd	d0, d2, d4, d1
      6c:	ret
      70:	mov	w2, #0x9427                	// #37927
      74:	movk	w2, #0x3fe5, lsl #16
      78:	cmp	w1, w2
      7c:	b.le	a4 <__kernel_tan+0xa4>
      80:	tbnz	w3, #31, 1d8 <__kernel_tan+0x1d8>
      84:	adrp	x2, 0 <__kernel_tan>
      88:	ldr	d0, [x2]
      8c:	adrp	x2, 0 <__kernel_tan>
      90:	ldr	d3, [x2]
      94:	fsub	d0, d0, d2
      98:	fsub	d2, d3, d1
      9c:	movi	d1, #0x0
      a0:	fadd	d2, d2, d0
      a4:	fmul	d3, d2, d2
      a8:	adrp	x2, 0 <__kernel_tan>
      ac:	ldr	d25, [x2]
      b0:	adrp	x2, 0 <__kernel_tan>
      b4:	fmul	d0, d3, d3
      b8:	ldr	d21, [x2]
      bc:	adrp	x2, 0 <__kernel_tan>
      c0:	fmul	d22, d2, d3
      c4:	ldr	d24, [x2]
      c8:	adrp	x2, 0 <__kernel_tan>
      cc:	fmadd	d21, d0, d25, d21
      d0:	ldr	d20, [x2]
      d4:	adrp	x2, 0 <__kernel_tan>
      d8:	fmadd	d20, d0, d24, d20
      dc:	ldr	d19, [x2]
      e0:	adrp	x2, 0 <__kernel_tan>
      e4:	ldr	d18, [x2]
      e8:	adrp	x2, 0 <__kernel_tan>
      ec:	ldr	d17, [x2]
      f0:	adrp	x2, 0 <__kernel_tan>
      f4:	fmadd	d19, d21, d0, d19
      f8:	ldr	d16, [x2]
      fc:	adrp	x2, 0 <__kernel_tan>
     100:	fmadd	d18, d20, d0, d18
     104:	ldr	d7, [x2]
     108:	adrp	x2, 0 <__kernel_tan>
     10c:	ldr	d6, [x2]
     110:	adrp	x2, 0 <__kernel_tan>
     114:	ldr	d5, [x2]
     118:	adrp	x2, 0 <__kernel_tan>
     11c:	fmadd	d17, d19, d0, d17
     120:	ldr	d4, [x2]
     124:	adrp	x2, 0 <__kernel_tan>
     128:	fmadd	d16, d18, d0, d16
     12c:	ldr	d23, [x2]
     130:	mov	w2, #0x9427                	// #37927
     134:	movk	w2, #0x3fe5, lsl #16
     138:	fmadd	d7, d17, d0, d7
     13c:	fmadd	d6, d16, d0, d6
     140:	fmadd	d5, d7, d0, d5
     144:	fmadd	d0, d6, d0, d4
     148:	fmadd	d0, d3, d5, d0
     14c:	fmadd	d0, d0, d22, d1
     150:	fmadd	d1, d0, d3, d1
     154:	fmadd	d1, d22, d23, d1
     158:	fadd	d0, d2, d1
     15c:	cmp	w1, w2
     160:	b.gt	19c <__kernel_tan+0x19c>
     164:	cmp	w0, #0x1
     168:	b.eq	6c <__kernel_tan+0x6c>  // b.none
     16c:	movi	v6.2d, #0xffffffff00000000
     170:	fmov	d5, #-1.000000000000000000e+00
     174:	fmov	d3, #1.000000000000000000e+00
     178:	and	v4.8b, v0.8b, v6.8b
     17c:	fdiv	d0, d5, d0
     180:	fsub	d2, d4, d2
     184:	fsub	d1, d1, d2
     188:	and	v2.8b, v0.8b, v6.8b
     18c:	fmadd	d3, d4, d2, d3
     190:	fmadd	d3, d2, d1, d3
     194:	fmadd	d0, d3, d0, d2
     198:	ret
     19c:	scvtf	d4, w0
     1a0:	fmul	d3, d0, d0
     1a4:	fmov	d6, #-2.000000000000000000e+00
     1a8:	asr	w3, w3, #30
     1ac:	and	w3, w3, #0x2
     1b0:	mov	w0, #0x1                   	// #1
     1b4:	sub	w0, w0, w3
     1b8:	fadd	d0, d0, d4
     1bc:	scvtf	d5, w0
     1c0:	fdiv	d3, d3, d0
     1c4:	fsub	d3, d3, d1
     1c8:	fsub	d3, d2, d3
     1cc:	fmadd	d4, d3, d6, d4
     1d0:	fmul	d0, d5, d4
     1d4:	ret
     1d8:	adrp	x2, 0 <__kernel_tan>
     1dc:	fneg	d2, d0
     1e0:	fneg	d1, d1
     1e4:	ldr	d0, [x2]
     1e8:	adrp	x2, 0 <__kernel_tan>
     1ec:	ldr	d3, [x2]
     1f0:	fsub	d0, d0, d2
     1f4:	fsub	d2, d3, d1
     1f8:	movi	d1, #0x0
     1fc:	fadd	d2, d2, d0
     200:	b	a4 <__kernel_tan+0xa4>
     204:	fabs	d2, d0
     208:	fmov	d0, #1.000000000000000000e+00
     20c:	fdiv	d0, d0, d2
     210:	ret

0000000000000214 <__kernel_rem_pio2.constprop.0>:
     214:	stp	x29, x30, [sp, #-144]!
     218:	mov	w4, #0xaaab                	// #43691
     21c:	movk	w4, #0x2aaa, lsl #16
     220:	mov	x29, sp
     224:	stp	x21, x22, [sp, #32]
     228:	sub	w21, w2, #0x3
     22c:	mov	w5, w3
     230:	stp	x19, x20, [sp, #16]
     234:	smull	x4, w21, w4
     238:	stp	x23, x24, [sp, #48]
     23c:	sub	w24, w3, #0x1
     240:	stp	x25, x26, [sp, #64]
     244:	asr	x4, x4, #34
     248:	sub	w4, w4, w21, asr #31
     24c:	stp	x27, x28, [sp, #80]
     250:	mov	x27, x0
     254:	add	w0, w3, #0x3
     258:	stp	d8, d9, [sp, #96]
     25c:	stp	d10, d11, [sp, #112]
     260:	stp	d12, d13, [sp, #128]
     264:	sub	sp, sp, #0x260
     268:	str	w3, [sp, #12]
     26c:	adrp	x3, 0 <__stack_chk_guard>
     270:	ldr	x3, [x3]
     274:	ldr	x6, [x3]
     278:	str	x6, [sp, #600]
     27c:	mov	x6, #0x0                   	// #0
     280:	str	x1, [sp, #16]
     284:	add	w1, w4, #0x1
     288:	str	w4, [sp, #24]
     28c:	subs	w4, w4, w24
     290:	sub	w1, w1, w1, lsl #2
     294:	add	w23, w2, w1, lsl #3
     298:	b.pl	a84 <__kernel_rem_pio2.constprop.0+0x870>  // b.nfrst
     29c:	str	xzr, [sp, #280]
     2a0:	cmn	w4, #0x1
     2a4:	b.eq	2c4 <__kernel_rem_pio2.constprop.0+0xb0>  // b.none
     2a8:	cmp	w0, #0x1
     2ac:	add	w2, w5, #0x2
     2b0:	csinc	w2, w2, wzr, gt
     2b4:	mov	w4, #0x0                   	// #0
     2b8:	mov	w1, #0x2                   	// #2
     2bc:	str	xzr, [sp, #288]
     2c0:	b	2e0 <__kernel_rem_pio2.constprop.0+0xcc>
     2c4:	mov	w1, #0x1                   	// #1
     2c8:	mov	w4, #0x0                   	// #0
     2cc:	ldr	w2, [sp, #12]
     2d0:	cmp	w0, w1
     2d4:	sub	w2, w2, w1
     2d8:	add	w2, w2, #0x4
     2dc:	csinc	w2, w2, wzr, ge	// ge = tcont
     2e0:	sbfiz	x6, x4, #2, #32
     2e4:	adrp	x3, 0 <__kernel_tan>
     2e8:	add	x5, x3, #0x0
     2ec:	add	x25, sp, #0x118
     2f0:	sbfiz	x7, x1, #3, #32
     2f4:	add	x8, x25, x7
     2f8:	ldr	q0, [x5, x6]
     2fc:	sxtl	v1.2d, v0.2s
     300:	sxtl2	v0.2d, v0.4s
     304:	scvtf	v1.2d, v1.2d
     308:	scvtf	v0.2d, v0.2d
     30c:	str	q1, [x25, x7]
     310:	str	q0, [x8, #16]
     314:	cmp	w2, #0x4
     318:	b.eq	368 <__kernel_rem_pio2.constprop.0+0x154>  // b.none
     31c:	add	w4, w4, #0x4
     320:	add	w7, w1, #0x4
     324:	add	w2, w1, #0x5
     328:	sbfiz	x6, x4, #2, #32
     32c:	ldr	w4, [x5, w4, sxtw #2]
     330:	scvtf	d0, w4
     334:	str	d0, [x25, w7, sxtw #3]
     338:	cmp	w0, w2
     33c:	b.lt	368 <__kernel_rem_pio2.constprop.0+0x154>  // b.tstop
     340:	add	x5, x5, x6
     344:	add	w1, w1, #0x6
     348:	ldr	w4, [x5, #4]
     34c:	scvtf	d0, w4
     350:	str	d0, [x25, w2, sxtw #3]
     354:	cmp	w0, w1
     358:	b.lt	368 <__kernel_rem_pio2.constprop.0+0x154>  // b.tstop
     35c:	ldr	w2, [x5, #8]
     360:	scvtf	d0, w2
     364:	str	d0, [x25, w1, sxtw #3]
     368:	ldr	w1, [sp, #12]
     36c:	mov	x2, #0xfffffffffffffff8    	// #-8
     370:	movi	v1.2d, #0x0
     374:	ldr	d11, [x27]
     378:	add	x2, x2, w1, sxtw #3
     37c:	dup	v2.2d, v11.d[0]
     380:	add	x1, x25, x2
     384:	mov	v0.16b, v1.16b
     388:	ldr	q3, [x25, x2]
     38c:	fmla	v0.2d, v3.2d, v11.d[0]
     390:	cbz	w24, b04 <__kernel_rem_pio2.constprop.0+0x8f0>
     394:	ldur	q4, [x1, #-8]
     398:	ldr	d3, [x27, #8]
     39c:	fmla	v0.2d, v4.2d, v3.d[0]
     3a0:	dup	v4.2d, v3.d[0]
     3a4:	cmp	w24, #0x2
     3a8:	b.ne	b7c <__kernel_rem_pio2.constprop.0+0x968>  // b.any
     3ac:	ldur	q7, [x1, #-16]
     3b0:	ldr	d5, [x27, #16]
     3b4:	ldr	q6, [x1, #16]
     3b8:	fmla	v0.2d, v7.2d, v5.d[0]
     3bc:	fmla	v1.2d, v6.2d, v2.2d
     3c0:	str	q0, [sp, #112]
     3c4:	ldur	q2, [x1, #8]
     3c8:	ldr	q0, [x25, x2]
     3cc:	fmla	v1.2d, v2.2d, v4.2d
     3d0:	fmla	v1.2d, v0.2d, v5.d[0]
     3d4:	ldr	d2, [x25, w0, sxtw #3]
     3d8:	movi	d0, #0x0
     3dc:	ldr	w0, [sp, #12]
     3e0:	str	q1, [sp, #128]
     3e4:	add	w0, w0, #0x2
     3e8:	fmadd	d0, d2, d11, d0
     3ec:	ldr	d1, [x25, w0, sxtw #3]
     3f0:	fmadd	d0, d3, d1, d0
     3f4:	cmp	w24, #0x2
     3f8:	b.ne	408 <__kernel_rem_pio2.constprop.0+0x1f4>  // b.any
     3fc:	ldr	d1, [x27, #16]
     400:	ldr	d2, [sp, #312]
     404:	fmadd	d0, d2, d1, d0
     408:	add	x26, sp, #0x70
     40c:	add	x28, sp, #0x20
     410:	mov	x1, #0x3e70000000000000    	// #4499096027743125504
     414:	mov	x0, #0xc170000000000000    	// #-4508103226997866496
     418:	fmov	d13, x1
     41c:	fmov	d12, x0
     420:	mov	w21, #0x4                   	// #4
     424:	fmov	d9, #1.250000000000000000e-01
     428:	fmov	d8, #-8.000000000000000000e+00
     42c:	str	d0, [sp, #144]
     430:	sxtw	x22, w21
     434:	sbfiz	x20, x21, #3, #32
     438:	add	x1, x26, x20
     43c:	mov	x4, x28
     440:	mov	x0, x28
     444:	mov	w19, w21
     448:	ldr	d0, [x26, x22, lsl #3]
     44c:	nop
     450:	fmul	d1, d0, d13
     454:	ldr	d3, [x1, #-8]!
     458:	subs	w19, w19, #0x1
     45c:	fcvtzs	w2, d1
     460:	scvtf	d1, w2
     464:	fmadd	d2, d1, d12, d0
     468:	fadd	d0, d1, d3
     46c:	fcvtzs	w2, d2
     470:	str	w2, [x0], #4
     474:	b.ne	450 <__kernel_rem_pio2.constprop.0+0x23c>  // b.any
     478:	mov	w0, w23
     47c:	str	x4, [sp]
     480:	bl	0 <scalbn>
     484:	fmul	d1, d0, d9
     488:	ldr	x4, [sp]
     48c:	cmp	w23, #0x0
     490:	frintm	d1, d1
     494:	fmadd	d0, d1, d8, d0
     498:	fcvtzs	w8, d0
     49c:	scvtf	d1, w8
     4a0:	fsub	d10, d0, d1
     4a4:	b.le	6cc <__kernel_rem_pio2.constprop.0+0x4b8>
     4a8:	sub	w0, w21, #0x1
     4ac:	mov	w9, #0x18                  	// #24
     4b0:	sub	w9, w9, w23
     4b4:	mov	w10, #0x17                  	// #23
     4b8:	sxtw	x0, w0
     4bc:	sub	w10, w10, w23
     4c0:	ldr	w1, [x28, x0, lsl #2]
     4c4:	asr	w2, w1, w9
     4c8:	add	w8, w8, w2
     4cc:	lsl	w2, w2, w9
     4d0:	sub	w1, w1, w2
     4d4:	str	w1, [x28, x0, lsl #2]
     4d8:	asr	w1, w1, w10
     4dc:	cmp	w1, #0x0
     4e0:	b.gt	6e4 <__kernel_rem_pio2.constprop.0+0x4d0>
     4e4:	fcmp	d10, #0.0
     4e8:	b.ne	798 <__kernel_rem_pio2.constprop.0+0x584>  // b.any
     4ec:	sub	w4, w21, #0x1
     4f0:	mov	w0, w4
     4f4:	cmp	w4, #0x3
     4f8:	b.eq	600 <__kernel_rem_pio2.constprop.0+0x3ec>  // b.none
     4fc:	sub	w11, w21, #0x5
     500:	sub	w2, w21, #0x4
     504:	cmp	w11, #0x3
     508:	b.ls	5b8 <__kernel_rem_pio2.constprop.0+0x3a4>  // b.plast
     50c:	mov	x0, #0xfffffffffffffff0    	// #-16
     510:	adrp	x3, 0 <__kernel_tan>
     514:	add	x0, x0, w21, sxtw #2
     518:	lsr	w9, w2, #2
     51c:	ldr	q4, [x3]
     520:	add	x10, x28, x0
     524:	ldr	q0, [x28, x0]
     528:	mov	v1.16b, v0.16b
     52c:	tbl	v0.16b, {v0.16b-v1.16b}, v4.16b
     530:	cmp	w9, #0x1
     534:	b.eq	84c <__kernel_rem_pio2.constprop.0+0x638>  // b.none
     538:	ldur	q2, [x10, #-16]
     53c:	mov	v3.16b, v2.16b
     540:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     544:	orr	v0.16b, v0.16b, v2.16b
     548:	cmp	w9, #0x2
     54c:	b.eq	590 <__kernel_rem_pio2.constprop.0+0x37c>  // b.none
     550:	ldur	q2, [x10, #-32]
     554:	mov	v3.16b, v2.16b
     558:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     55c:	orr	v0.16b, v0.16b, v2.16b
     560:	cmp	w9, #0x3
     564:	b.eq	590 <__kernel_rem_pio2.constprop.0+0x37c>  // b.none
     568:	ldur	q2, [x10, #-48]
     56c:	mov	v3.16b, v2.16b
     570:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     574:	orr	v0.16b, v0.16b, v2.16b
     578:	cmp	w9, #0x4
     57c:	b.eq	590 <__kernel_rem_pio2.constprop.0+0x37c>  // b.none
     580:	ldur	q2, [x10, #-64]
     584:	mov	v3.16b, v2.16b
     588:	tbl	v2.16b, {v2.16b-v3.16b}, v4.16b
     58c:	orr	v0.16b, v0.16b, v2.16b
     590:	movi	v1.4s, #0x0
     594:	ext	v2.16b, v0.16b, v1.16b, #8
     598:	orr	v2.16b, v2.16b, v0.16b
     59c:	ext	v0.16b, v2.16b, v1.16b, #4
     5a0:	orr	v0.16b, v0.16b, v2.16b
     5a4:	fmov	w19, s0
     5a8:	tst	x2, #0x3
     5ac:	b.eq	5fc <__kernel_rem_pio2.constprop.0+0x3e8>  // b.none
     5b0:	and	w2, w2, #0xfffffffc
     5b4:	sub	w0, w4, w2
     5b8:	ldr	w2, [x28, w0, sxtw #2]
     5bc:	sub	w9, w0, #0x1
     5c0:	orr	w19, w19, w2
     5c4:	cmp	w0, #0x4
     5c8:	b.eq	5fc <__kernel_rem_pio2.constprop.0+0x3e8>  // b.none
     5cc:	ldr	w2, [x28, w9, sxtw #2]
     5d0:	sub	w9, w0, #0x2
     5d4:	orr	w19, w19, w2
     5d8:	cmp	w0, #0x5
     5dc:	b.eq	5fc <__kernel_rem_pio2.constprop.0+0x3e8>  // b.none
     5e0:	ldr	w9, [x28, w9, sxtw #2]
     5e4:	sub	w2, w0, #0x3
     5e8:	orr	w19, w19, w9
     5ec:	cmp	w0, #0x6
     5f0:	b.eq	5fc <__kernel_rem_pio2.constprop.0+0x3e8>  // b.none
     5f4:	ldr	w0, [x28, w2, sxtw #2]
     5f8:	orr	w19, w19, w0
     5fc:	cbnz	w19, 86c <__kernel_rem_pio2.constprop.0+0x658>
     600:	ldr	w0, [sp, #44]
     604:	cbnz	w0, a8c <__kernel_rem_pio2.constprop.0+0x878>
     608:	ldr	w0, [sp, #40]
     60c:	cbnz	w0, a74 <__kernel_rem_pio2.constprop.0+0x860>
     610:	ldr	w0, [sp, #36]
     614:	cbnz	w0, a64 <__kernel_rem_pio2.constprop.0+0x850>
     618:	ldr	w2, [sp, #32]
     61c:	add	w1, w21, #0x1
     620:	add	w0, w21, #0x2
     624:	cmp	w2, #0x0
     628:	cset	w5, eq	// eq = none
     62c:	add	w5, w5, w21
     630:	add	w5, w5, #0x4
     634:	add	w2, w24, w1
     638:	adrp	x1, 0 <__kernel_tan>
     63c:	add	x6, x1, #0x0
     640:	ldr	w1, [sp, #24]
     644:	sbfiz	x2, x2, #3, #32
     648:	movi	d3, #0x0
     64c:	sub	x2, x2, x20
     650:	sxtw	x0, w0
     654:	add	x6, x6, w1, sxtw #2
     658:	ldr	w1, [sp, #12]
     65c:	sub	x2, x2, #0x10
     660:	sub	x6, x6, #0x4
     664:	add	x2, x25, x2
     668:	sub	w7, w1, #0x3
     66c:	nop
     670:	ldr	w1, [x6, x0, lsl #2]
     674:	scvtf	d0, w1
     678:	str	d0, [x2, x0, lsl #3]
     67c:	fmadd	d0, d0, d11, d3
     680:	cbz	w24, 6ac <__kernel_rem_pio2.constprop.0+0x498>
     684:	add	w1, w7, w0
     688:	ldr	d2, [x27, #8]
     68c:	ldr	d1, [x25, w1, sxtw #3]
     690:	fmadd	d0, d2, d1, d0
     694:	cmp	w24, #0x2
     698:	b.ne	6ac <__kernel_rem_pio2.constprop.0+0x498>  // b.any
     69c:	sub	w1, w0, #0x1
     6a0:	ldr	d2, [x27, #16]
     6a4:	ldr	d1, [x25, w1, sxtw #3]
     6a8:	fmadd	d0, d2, d1, d0
     6ac:	add	x4, x26, x0, lsl #3
     6b0:	add	x0, x0, #0x1
     6b4:	sub	w1, w0, #0x1
     6b8:	stur	d0, [x4, #-8]
     6bc:	cmp	w5, w1
     6c0:	b.ge	670 <__kernel_rem_pio2.constprop.0+0x45c>  // b.tcont
     6c4:	mov	w21, w5
     6c8:	b	430 <__kernel_rem_pio2.constprop.0+0x21c>
     6cc:	b.ne	838 <__kernel_rem_pio2.constprop.0+0x624>  // b.any
     6d0:	sub	w0, w21, #0x1
     6d4:	ldr	w1, [x28, w0, sxtw #2]
     6d8:	asr	w1, w1, #23
     6dc:	cmp	w1, #0x0
     6e0:	b.le	4e4 <__kernel_rem_pio2.constprop.0+0x2d0>
     6e4:	add	w8, w8, #0x1
     6e8:	ldr	w0, [x28]
     6ec:	add	x2, x28, x22, lsl #2
     6f0:	mov	x9, x28
     6f4:	nop
     6f8:	cbz	w0, 7f8 <__kernel_rem_pio2.constprop.0+0x5e4>
     6fc:	mov	w10, #0x1000000             	// #16777216
     700:	mov	w11, #0xffffff              	// #16777215
     704:	sub	w0, w10, w0
     708:	str	w0, [x9]
     70c:	b	71c <__kernel_rem_pio2.constprop.0+0x508>
     710:	ldr	w0, [x4]
     714:	sub	w0, w11, w0
     718:	str	w0, [x4]
     71c:	add	x4, x4, #0x4
     720:	cmp	x4, x2
     724:	b.ne	710 <__kernel_rem_pio2.constprop.0+0x4fc>  // b.any
     728:	mov	w0, #0x1                   	// #1
     72c:	cmp	w23, #0x0
     730:	b.le	a9c <__kernel_rem_pio2.constprop.0+0x888>
     734:	cmp	w23, #0x1
     738:	b.eq	820 <__kernel_rem_pio2.constprop.0+0x60c>  // b.none
     73c:	cmp	w23, #0x2
     740:	b.ne	758 <__kernel_rem_pio2.constprop.0+0x544>  // b.any
     744:	sub	w2, w21, #0x1
     748:	sxtw	x2, w2
     74c:	ldr	w4, [x28, x2, lsl #2]
     750:	and	w4, w4, #0x3fffff
     754:	str	w4, [x28, x2, lsl #2]
     758:	cmp	w1, #0x2
     75c:	b.ne	4e4 <__kernel_rem_pio2.constprop.0+0x2d0>  // b.any
     760:	fmov	d0, #1.000000000000000000e+00
     764:	fsub	d10, d0, d10
     768:	cbz	w0, 4e4 <__kernel_rem_pio2.constprop.0+0x2d0>
     76c:	mov	w1, #0x2                   	// #2
     770:	fmov	d0, #1.000000000000000000e+00
     774:	mov	w0, w23
     778:	str	w1, [sp]
     77c:	str	w8, [sp, #28]
     780:	bl	0 <scalbn>
     784:	fsub	d10, d10, d0
     788:	ldr	w1, [sp]
     78c:	ldr	w8, [sp, #28]
     790:	fcmp	d10, #0.0
     794:	b.eq	4ec <__kernel_rem_pio2.constprop.0+0x2d8>  // b.none
     798:	fmov	d0, d10
     79c:	neg	w0, w23
     7a0:	str	w1, [sp]
     7a4:	str	w8, [sp, #12]
     7a8:	bl	0 <scalbn>
     7ac:	fmov	d1, d0
     7b0:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     7b4:	fmov	d2, x0
     7b8:	ldr	w1, [sp]
     7bc:	fcmpe	d0, d2
     7c0:	ldr	w8, [sp, #12]
     7c4:	b.ge	ab0 <__kernel_rem_pio2.constprop.0+0x89c>  // b.tcont
     7c8:	fcvtzs	w2, d0
     7cc:	fmov	d0, #1.000000000000000000e+00
     7d0:	mov	w0, w23
     7d4:	str	w1, [sp]
     7d8:	str	w8, [sp, #12]
     7dc:	mov	w19, w21
     7e0:	str	w2, [x28, x22, lsl #2]
     7e4:	bl	0 <scalbn>
     7e8:	ldr	w1, [sp]
     7ec:	fmov	d1, d0
     7f0:	ldr	w8, [sp, #12]
     7f4:	b	8b4 <__kernel_rem_pio2.constprop.0+0x6a0>
     7f8:	add	x4, x4, #0x4
     7fc:	cmp	x4, x2
     800:	b.eq	810 <__kernel_rem_pio2.constprop.0+0x5fc>  // b.none
     804:	ldr	w0, [x4]
     808:	mov	x9, x4
     80c:	b	6f8 <__kernel_rem_pio2.constprop.0+0x4e4>
     810:	cmp	w23, #0x0
     814:	b.le	758 <__kernel_rem_pio2.constprop.0+0x544>
     818:	cmp	w23, #0x1
     81c:	b.ne	73c <__kernel_rem_pio2.constprop.0+0x528>  // b.any
     820:	sub	w2, w21, #0x1
     824:	sxtw	x2, w2
     828:	ldr	w4, [x28, x2, lsl #2]
     82c:	and	w4, w4, #0x7fffff
     830:	str	w4, [x28, x2, lsl #2]
     834:	b	758 <__kernel_rem_pio2.constprop.0+0x544>
     838:	fmov	d0, #5.000000000000000000e-01
     83c:	fcmpe	d10, d0
     840:	b.ge	a58 <__kernel_rem_pio2.constprop.0+0x844>  // b.tcont
     844:	mov	w1, #0x0                   	// #0
     848:	b	4e4 <__kernel_rem_pio2.constprop.0+0x2d0>
     84c:	movi	v1.4s, #0x0
     850:	mov	w0, w11
     854:	ext	v2.16b, v0.16b, v1.16b, #8
     858:	orr	v2.16b, v2.16b, v0.16b
     85c:	ext	v0.16b, v2.16b, v1.16b, #4
     860:	orr	v0.16b, v0.16b, v2.16b
     864:	fmov	w19, s0
     868:	b	5b8 <__kernel_rem_pio2.constprop.0+0x3a4>
     86c:	ldr	w2, [x28, w4, sxtw #2]
     870:	mov	w19, w4
     874:	sub	w0, w23, #0x18
     878:	add	x5, x28, x22, lsl #2
     87c:	cbnz	w2, b5c <__kernel_rem_pio2.constprop.0+0x948>
     880:	ldur	w2, [x5, #-8]
     884:	sub	x5, x5, #0x4
     888:	sub	w19, w19, #0x1
     88c:	sub	w0, w0, #0x18
     890:	cbz	w2, 880 <__kernel_rem_pio2.constprop.0+0x66c>
     894:	fmov	d0, #1.000000000000000000e+00
     898:	str	w1, [sp]
     89c:	str	w8, [sp, #12]
     8a0:	bl	0 <scalbn>
     8a4:	fmov	d1, d0
     8a8:	ldr	w1, [sp]
     8ac:	ldr	w8, [sp, #12]
     8b0:	tbnz	w19, #31, b20 <__kernel_rem_pio2.constprop.0+0x90c>
     8b4:	sub	w6, w19, #0x1
     8b8:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     8bc:	fmov	d2, x0
     8c0:	sxtw	x6, w6
     8c4:	mov	x0, x6
     8c8:	add	x3, x28, x0, lsl #2
     8cc:	add	x2, x26, x0, lsl #3
     8d0:	sub	x0, x0, #0x1
     8d4:	ldr	w3, [x3, #4]
     8d8:	scvtf	d0, w3
     8dc:	fmul	d0, d0, d1
     8e0:	fmul	d1, d1, d2
     8e4:	str	d0, [x2, #8]
     8e8:	cmn	w0, #0x1
     8ec:	b.pl	8c8 <__kernel_rem_pio2.constprop.0+0x6b4>  // b.nfrst
     8f0:	adrp	x3, 0 <__kernel_tan>
     8f4:	mov	x0, #0x442d00000000        	// #74960064217088
     8f8:	movk	x0, #0x3e74, lsl #48
     8fc:	add	x7, sp, #0x1b8
     900:	ldr	d3, [x3]
     904:	adrp	x3, 0 <__kernel_tan>
     908:	fmov	d4, x0
     90c:	movi	d2, #0x0
     910:	ldr	d5, [x3]
     914:	adrp	x3, 0 <__kernel_tan>
     918:	mov	x5, x7
     91c:	mov	x2, x6
     920:	ldr	d7, [x3]
     924:	adrp	x3, 0 <__kernel_tan>
     928:	mov	w0, #0x0                   	// #0
     92c:	ldr	d6, [x3]
     930:	b	938 <__kernel_rem_pio2.constprop.0+0x724>
     934:	mov	w0, w3
     938:	add	x3, x26, x2, lsl #3
     93c:	ldr	d0, [x3, #8]
     940:	fmadd	d0, d0, d3, d2
     944:	cbz	w0, 990 <__kernel_rem_pio2.constprop.0+0x77c>
     948:	add	w4, w2, #0x2
     94c:	ldr	d1, [x26, w4, sxtw #3]
     950:	fmadd	d0, d1, d4, d0
     954:	cmp	w0, #0x1
     958:	b.eq	990 <__kernel_rem_pio2.constprop.0+0x77c>  // b.none
     95c:	add	w4, w2, #0x3
     960:	ldr	d1, [x26, w4, sxtw #3]
     964:	fmadd	d0, d1, d5, d0
     968:	cmp	w0, #0x2
     96c:	b.eq	990 <__kernel_rem_pio2.constprop.0+0x77c>  // b.none
     970:	add	w4, w2, #0x4
     974:	ldr	d1, [x26, w4, sxtw #3]
     978:	fmadd	d0, d1, d7, d0
     97c:	cmp	w0, #0x3
     980:	b.eq	990 <__kernel_rem_pio2.constprop.0+0x77c>  // b.none
     984:	add	w3, w2, #0x5
     988:	ldr	d1, [x26, w3, sxtw #3]
     98c:	fmadd	d0, d1, d6, d0
     990:	str	d0, [x5], #8
     994:	sub	x2, x2, #0x1
     998:	add	w3, w0, #0x1
     99c:	cmp	w19, w0
     9a0:	b.ne	934 <__kernel_rem_pio2.constprop.0+0x720>  // b.any
     9a4:	movi	d1, #0x0
     9a8:	mov	x2, #0xfffffffffffffffe    	// #-2
     9ac:	add	x0, x7, x6, lsl #3
     9b0:	sub	x6, x6, #0x1
     9b4:	ldr	d0, [x0, #8]
     9b8:	fadd	d1, d1, d0
     9bc:	cmp	x6, x2
     9c0:	b.ne	9ac <__kernel_rem_pio2.constprop.0+0x798>  // b.any
     9c4:	ldr	d0, [sp, #440]
     9c8:	cbz	w1, b3c <__kernel_rem_pio2.constprop.0+0x928>
     9cc:	ldr	x0, [sp, #16]
     9d0:	fneg	d2, d1
     9d4:	fsub	d0, d0, d1
     9d8:	str	d2, [x0]
     9dc:	cbz	w19, a00 <__kernel_rem_pio2.constprop.0+0x7ec>
     9e0:	add	x2, sp, #0x1c0
     9e4:	mov	w0, #0x1                   	// #1
     9e8:	ldr	d1, [x2], #8
     9ec:	add	w0, w0, #0x1
     9f0:	fadd	d0, d0, d1
     9f4:	cmp	w0, w19
     9f8:	b.le	9e8 <__kernel_rem_pio2.constprop.0+0x7d4>
     9fc:	cbz	w1, a04 <__kernel_rem_pio2.constprop.0+0x7f0>
     a00:	fneg	d0, d0
     a04:	ldr	x0, [sp, #16]
     a08:	adrp	x1, 0 <__stack_chk_guard>
     a0c:	ldr	x1, [x1]
     a10:	str	d0, [x0, #8]
     a14:	and	w0, w8, #0x7
     a18:	ldr	x3, [sp, #600]
     a1c:	ldr	x2, [x1]
     a20:	subs	x3, x3, x2
     a24:	mov	x2, #0x0                   	// #0
     a28:	b.ne	b94 <__kernel_rem_pio2.constprop.0+0x980>  // b.any
     a2c:	add	sp, sp, #0x260
     a30:	ldp	x19, x20, [sp, #16]
     a34:	ldp	x21, x22, [sp, #32]
     a38:	ldp	x23, x24, [sp, #48]
     a3c:	ldp	x25, x26, [sp, #64]
     a40:	ldp	x27, x28, [sp, #80]
     a44:	ldp	d8, d9, [sp, #96]
     a48:	ldp	d10, d11, [sp, #112]
     a4c:	ldp	d12, d13, [sp, #128]
     a50:	ldp	x29, x30, [sp], #144
     a54:	ret
     a58:	add	w8, w8, #0x1
     a5c:	mov	w1, #0x2                   	// #2
     a60:	b	6e8 <__kernel_rem_pio2.constprop.0+0x4d4>
     a64:	add	w1, w21, #0x1
     a68:	add	w5, w21, #0x3
     a6c:	add	w0, w21, #0x2
     a70:	b	634 <__kernel_rem_pio2.constprop.0+0x420>
     a74:	add	w0, w21, #0x2
     a78:	add	w1, w21, #0x1
     a7c:	mov	w5, w0
     a80:	b	634 <__kernel_rem_pio2.constprop.0+0x420>
     a84:	mov	w1, #0x0                   	// #0
     a88:	b	2cc <__kernel_rem_pio2.constprop.0+0xb8>
     a8c:	add	w1, w21, #0x1
     a90:	add	w0, w21, #0x2
     a94:	mov	w5, w1
     a98:	b	634 <__kernel_rem_pio2.constprop.0+0x420>
     a9c:	cmp	w1, #0x2
     aa0:	b.ne	4e4 <__kernel_rem_pio2.constprop.0+0x2d0>  // b.any
     aa4:	fmov	d0, #1.000000000000000000e+00
     aa8:	fsub	d10, d0, d10
     aac:	b	76c <__kernel_rem_pio2.constprop.0+0x558>
     ab0:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     ab4:	fmov	d2, x0
     ab8:	mov	x0, #0xc170000000000000    	// #-4508103226997866496
     abc:	fmov	d3, x0
     ac0:	fmul	d2, d0, d2
     ac4:	add	w19, w21, #0x1
     ac8:	fmov	d0, #1.000000000000000000e+00
     acc:	add	w0, w23, #0x18
     ad0:	str	w1, [sp]
     ad4:	str	w8, [sp, #12]
     ad8:	fcvtzs	w2, d2
     adc:	scvtf	d2, w2
     ae0:	fmadd	d1, d2, d3, d1
     ae4:	fcvtzs	w3, d1
     ae8:	str	w3, [x28, x22, lsl #2]
     aec:	str	w2, [x28, w19, sxtw #2]
     af0:	bl	0 <scalbn>
     af4:	ldr	w1, [sp]
     af8:	fmov	d1, d0
     afc:	ldr	w8, [sp, #12]
     b00:	b	8b4 <__kernel_rem_pio2.constprop.0+0x6a0>
     b04:	ldr	q4, [x1, #16]
     b08:	mov	v3.16b, v1.16b
     b0c:	fmla	v3.2d, v4.2d, v2.2d
     b10:	stp	q0, q3, [sp, #112]
     b14:	ldr	d0, [sp, #312]
     b18:	fmadd	d0, d0, d11, d1
     b1c:	b	408 <__kernel_rem_pio2.constprop.0+0x1f4>
     b20:	ldr	d0, [sp, #440]
     b24:	cbz	w1, b50 <__kernel_rem_pio2.constprop.0+0x93c>
     b28:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
     b2c:	fmov	d1, x0
     b30:	ldr	x0, [sp, #16]
     b34:	str	d1, [x0]
     b38:	b	a00 <__kernel_rem_pio2.constprop.0+0x7ec>
     b3c:	ldr	x0, [sp, #16]
     b40:	fsub	d0, d0, d1
     b44:	str	d1, [x0]
     b48:	cbnz	w19, 9e0 <__kernel_rem_pio2.constprop.0+0x7cc>
     b4c:	b	a04 <__kernel_rem_pio2.constprop.0+0x7f0>
     b50:	ldr	x0, [sp, #16]
     b54:	str	xzr, [x0]
     b58:	b	a04 <__kernel_rem_pio2.constprop.0+0x7f0>
     b5c:	fmov	d0, #1.000000000000000000e+00
     b60:	str	w1, [sp]
     b64:	str	w8, [sp, #12]
     b68:	bl	0 <scalbn>
     b6c:	fmov	d1, d0
     b70:	ldr	w1, [sp]
     b74:	ldr	w8, [sp, #12]
     b78:	b	8b4 <__kernel_rem_pio2.constprop.0+0x6a0>
     b7c:	ldr	q5, [x1, #16]
     b80:	str	q0, [sp, #112]
     b84:	ldur	q0, [x1, #8]
     b88:	fmla	v1.2d, v5.2d, v2.2d
     b8c:	fmla	v1.2d, v0.2d, v4.2d
     b90:	b	3d4 <__kernel_rem_pio2.constprop.0+0x1c0>
     b94:	bl	0 <__stack_chk_fail>
     b98:	nop
     b9c:	nop

0000000000000ba0 <__ieee754_rem_pio2>:
     ba0:	sub	sp, sp, #0x40
     ba4:	fmov	x4, d0
     ba8:	adrp	x1, 0 <__stack_chk_guard>
     bac:	ldr	x1, [x1]
     bb0:	stp	x29, x30, [sp, #32]
     bb4:	add	x29, sp, #0x20
     bb8:	ubfx	x5, x4, #32, #31
     bbc:	stp	x19, x20, [sp, #48]
     bc0:	mov	x19, x0
     bc4:	mov	w0, #0x21fb                	// #8699
     bc8:	ldr	x2, [x1]
     bcc:	str	x2, [sp, #24]
     bd0:	mov	x2, #0x0                   	// #0
     bd4:	movk	w0, #0x3fe9, lsl #16
     bd8:	cmp	w5, w0
     bdc:	b.le	d00 <__ieee754_rem_pio2+0x160>
     be0:	mov	w0, #0xd97b                	// #55675
     be4:	lsr	x20, x4, #32
     be8:	movk	w0, #0x4002, lsl #16
     bec:	cmp	w5, w0
     bf0:	b.gt	c64 <__ieee754_rem_pio2+0xc4>
     bf4:	adrp	x0, 0 <__kernel_tan>
     bf8:	ldr	d1, [x0]
     bfc:	mov	w0, #0x21fb                	// #8699
     c00:	movk	w0, #0x3ff9, lsl #16
     c04:	cmp	w20, #0x0
     c08:	b.le	e50 <__ieee754_rem_pio2+0x2b0>
     c0c:	fsub	d0, d0, d1
     c10:	cmp	w5, w0
     c14:	b.eq	dfc <__ieee754_rem_pio2+0x25c>  // b.none
     c18:	adrp	x0, 0 <__kernel_tan>
     c1c:	ldr	d2, [x0]
     c20:	fsub	d1, d0, d2
     c24:	fsub	d0, d0, d1
     c28:	fsub	d0, d0, d2
     c2c:	mov	w0, #0x1                   	// #1
     c30:	stp	d1, d0, [x19]
     c34:	nop
     c38:	adrp	x1, 0 <__stack_chk_guard>
     c3c:	ldr	x1, [x1]
     c40:	ldr	x3, [sp, #24]
     c44:	ldr	x2, [x1]
     c48:	subs	x3, x3, x2
     c4c:	mov	x2, #0x0                   	// #0
     c50:	b.ne	ea0 <__ieee754_rem_pio2+0x300>  // b.any
     c54:	ldp	x29, x30, [sp, #32]
     c58:	ldp	x19, x20, [sp, #48]
     c5c:	add	sp, sp, #0x40
     c60:	ret
     c64:	mov	w0, #0x21fb                	// #8699
     c68:	movk	w0, #0x4139, lsl #16
     c6c:	cmp	w5, w0
     c70:	b.le	d10 <__ieee754_rem_pio2+0x170>
     c74:	mov	w0, #0x7fefffff            	// #2146435071
     c78:	cmp	w5, w0
     c7c:	b.gt	e34 <__ieee754_rem_pio2+0x294>
     c80:	asr	w2, w5, #20
     c84:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     c88:	sub	w2, w2, #0x416
     c8c:	fmov	d1, x0
     c90:	mov	w3, #0x3                   	// #3
     c94:	sub	w5, w5, w2, lsl #20
     c98:	bfi	x4, x5, #32, #32
     c9c:	fmov	d0, x4
     ca0:	fcvtzs	w0, d0
     ca4:	scvtf	d2, w0
     ca8:	fsub	d0, d0, d2
     cac:	str	d2, [sp]
     cb0:	fmul	d0, d0, d1
     cb4:	fcvtzs	w0, d0
     cb8:	scvtf	d2, w0
     cbc:	fsub	d0, d0, d2
     cc0:	fmul	d0, d0, d1
     cc4:	fcmp	d0, #0.0
     cc8:	stp	d2, d0, [sp, #8]
     ccc:	b.ne	cdc <__ieee754_rem_pio2+0x13c>  // b.any
     cd0:	cmp	w0, #0x0
     cd4:	cset	w3, ne	// ne = any
     cd8:	add	w3, w3, #0x1
     cdc:	mov	x1, x19
     ce0:	mov	x0, sp
     ce4:	bl	214 <__kernel_rem_pio2.constprop.0>
     ce8:	tbz	w20, #31, c38 <__ieee754_rem_pio2+0x98>
     cec:	ldr	q0, [x19]
     cf0:	neg	w0, w0
     cf4:	fneg	v0.2d, v0.2d
     cf8:	str	q0, [x19]
     cfc:	b	c38 <__ieee754_rem_pio2+0x98>
     d00:	mov	w0, #0x0                   	// #0
     d04:	str	d0, [x19]
     d08:	str	xzr, [x19, #8]
     d0c:	b	c38 <__ieee754_rem_pio2+0x98>
     d10:	adrp	x0, 0 <__kernel_tan>
     d14:	fabs	d0, d0
     d18:	fmov	d2, #5.000000000000000000e-01
     d1c:	ldr	d3, [x0]
     d20:	adrp	x0, 0 <__kernel_tan>
     d24:	ldr	d4, [x0]
     d28:	adrp	x0, 0 <__kernel_tan>
     d2c:	fmadd	d2, d0, d3, d2
     d30:	ldr	d1, [x0]
     d34:	fcvtzs	w0, d2
     d38:	scvtf	d3, w0
     d3c:	fmsub	d0, d3, d4, d0
     d40:	fmul	d1, d3, d1
     d44:	fsub	d2, d0, d1
     d48:	cmp	w0, #0x1f
     d4c:	b.gt	d84 <__ieee754_rem_pio2+0x1e4>
     d50:	adrp	x1, 0 <__kernel_tan>
     d54:	add	x1, x1, #0x0
     d58:	add	x1, x1, #0x110
     d5c:	sub	w2, w0, #0x1
     d60:	ldr	w1, [x1, w2, sxtw #2]
     d64:	cmp	w1, w5
     d68:	b.eq	d84 <__ieee754_rem_pio2+0x1e4>  // b.none
     d6c:	str	d2, [x19]
     d70:	fsub	d0, d0, d2
     d74:	fsub	d0, d0, d1
     d78:	tbnz	w20, #31, e20 <__ieee754_rem_pio2+0x280>
     d7c:	str	d0, [x19, #8]
     d80:	b	c38 <__ieee754_rem_pio2+0x98>
     d84:	fmov	x1, d2
     d88:	asr	w5, w5, #20
     d8c:	ubfx	x1, x1, #52, #11
     d90:	sub	w1, w5, w1
     d94:	cmp	w1, #0x10
     d98:	b.le	d6c <__ieee754_rem_pio2+0x1cc>
     d9c:	adrp	x1, 0 <__kernel_tan>
     da0:	ldr	d2, [x1]
     da4:	adrp	x1, 0 <__kernel_tan>
     da8:	ldr	d1, [x1]
     dac:	fmsub	d4, d3, d2, d0
     db0:	fsub	d0, d0, d4
     db4:	fnmsub	d0, d3, d2, d0
     db8:	fmadd	d1, d3, d1, d0
     dbc:	fsub	d2, d4, d1
     dc0:	fmov	x1, d2
     dc4:	ubfx	x1, x1, #52, #11
     dc8:	sub	w5, w5, w1
     dcc:	cmp	w5, #0x31
     dd0:	b.le	e44 <__ieee754_rem_pio2+0x2a4>
     dd4:	adrp	x1, 0 <__kernel_tan>
     dd8:	ldr	d2, [x1]
     ddc:	adrp	x1, 0 <__kernel_tan>
     de0:	ldr	d1, [x1]
     de4:	fmsub	d0, d3, d2, d4
     de8:	fsub	d4, d4, d0
     dec:	fnmsub	d4, d3, d2, d4
     df0:	fmadd	d1, d3, d1, d4
     df4:	fsub	d2, d0, d1
     df8:	b	d6c <__ieee754_rem_pio2+0x1cc>
     dfc:	adrp	x0, 0 <__kernel_tan>
     e00:	ldr	d1, [x0]
     e04:	adrp	x0, 0 <__kernel_tan>
     e08:	ldr	d2, [x0]
     e0c:	fsub	d0, d0, d1
     e10:	fsub	d1, d0, d2
     e14:	fsub	d0, d0, d1
     e18:	fsub	d0, d0, d2
     e1c:	b	c2c <__ieee754_rem_pio2+0x8c>
     e20:	mov	v2.d[1], v0.d[0]
     e24:	neg	w0, w0
     e28:	fneg	v2.2d, v2.2d
     e2c:	str	q2, [x19]
     e30:	b	c38 <__ieee754_rem_pio2+0x98>
     e34:	fsub	d0, d0, d0
     e38:	mov	w0, #0x0                   	// #0
     e3c:	stp	d0, d0, [x19]
     e40:	b	c38 <__ieee754_rem_pio2+0x98>
     e44:	fmov	d0, d4
     e48:	str	d2, [x19]
     e4c:	b	d70 <__ieee754_rem_pio2+0x1d0>
     e50:	fadd	d0, d0, d1
     e54:	cmp	w5, w0
     e58:	b.eq	e7c <__ieee754_rem_pio2+0x2dc>  // b.none
     e5c:	adrp	x0, 0 <__kernel_tan>
     e60:	ldr	d2, [x0]
     e64:	fadd	d1, d0, d2
     e68:	fsub	d0, d0, d1
     e6c:	fadd	d0, d0, d2
     e70:	mov	w0, #0xffffffff            	// #-1
     e74:	stp	d1, d0, [x19]
     e78:	b	c38 <__ieee754_rem_pio2+0x98>
     e7c:	adrp	x0, 0 <__kernel_tan>
     e80:	ldr	d1, [x0]
     e84:	adrp	x0, 0 <__kernel_tan>
     e88:	ldr	d2, [x0]
     e8c:	fadd	d0, d0, d1
     e90:	fadd	d1, d0, d2
     e94:	fsub	d0, d0, d1
     e98:	fadd	d0, d0, d2
     e9c:	b	e70 <__ieee754_rem_pio2+0x2d0>
     ea0:	bl	0 <__stack_chk_fail>

0000000000000ea4 <pts_ieee754_acos>:
     ea4:	fmov	x1, d0
     ea8:	mov	w2, #0x3fefffff            	// #1072693247
     eac:	ubfx	x0, x1, #32, #31
     eb0:	lsr	x3, x1, #32
     eb4:	cmp	w0, w2
     eb8:	b.le	ee4 <pts_ieee754_acos+0x40>
     ebc:	mov	w2, #0xc0100000            	// #-1072693248
     ec0:	add	w0, w0, w2
     ec4:	orr	w0, w0, w1
     ec8:	cbnz	w0, f44 <pts_ieee754_acos+0xa0>
     ecc:	adrp	x0, 0 <__kernel_tan>
     ed0:	movi	d1, #0x0
     ed4:	cmp	w3, #0x0
     ed8:	ldr	d0, [x0]
     edc:	fcsel	d0, d0, d1, le
     ee0:	ret
     ee4:	stp	x29, x30, [sp, #-48]!
     ee8:	mov	w1, #0x3fdfffff            	// #1071644671
     eec:	mov	x29, sp
     ef0:	cmp	w0, w1
     ef4:	b.gt	f14 <pts_ieee754_acos+0x70>
     ef8:	mov	w1, #0x3c600000            	// #1012924416
     efc:	cmp	w0, w1
     f00:	b.gt	1004 <pts_ieee754_acos+0x160>
     f04:	adrp	x0, 0 <__kernel_tan>
     f08:	ldr	d0, [x0]
     f0c:	ldp	x29, x30, [sp], #48
     f10:	ret
     f14:	stp	d8, d9, [sp, #16]
     f18:	tbnz	w3, #31, 10b8 <pts_ieee754_acos+0x214>
     f1c:	fmov	d8, #1.000000000000000000e+00
     f20:	fmov	d1, #5.000000000000000000e-01
     f24:	fsub	d8, d8, d0
     f28:	fmul	d8, d8, d1
     f2c:	fcmp	d8, #0.0
     f30:	b.pl	f50 <pts_ieee754_acos+0xac>  // b.nfrst
     f34:	fmov	d0, d8
     f38:	bl	0 <sqrt>
     f3c:	fmov	d3, d0
     f40:	b	f54 <pts_ieee754_acos+0xb0>
     f44:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     f48:	fmov	d0, x0
     f4c:	ret
     f50:	fsqrt	d3, d8
     f54:	adrp	x0, 0 <__kernel_tan>
     f58:	fmov	d4, #1.000000000000000000e+00
     f5c:	ldr	d1, [x0]
     f60:	adrp	x0, 0 <__kernel_tan>
     f64:	ldr	d19, [x0]
     f68:	adrp	x0, 0 <__kernel_tan>
     f6c:	fmadd	d19, d8, d1, d19
     f70:	ldr	d17, [x0]
     f74:	adrp	x0, 0 <__kernel_tan>
     f78:	ldr	d0, [x0]
     f7c:	adrp	x0, 0 <__kernel_tan>
     f80:	ldr	d18, [x0]
     f84:	adrp	x0, 0 <__kernel_tan>
     f88:	fmadd	d18, d8, d0, d18
     f8c:	movi	v0.2d, #0xffffffff00000000
     f90:	ldr	d7, [x0]
     f94:	adrp	x0, 0 <__kernel_tan>
     f98:	fmadd	d17, d19, d8, d17
     f9c:	ldr	d16, [x0]
     fa0:	adrp	x0, 0 <__kernel_tan>
     fa4:	and	v2.8b, v3.8b, v0.8b
     fa8:	ldr	d5, [x0]
     fac:	adrp	x0, 0 <__kernel_tan>
     fb0:	ldr	d6, [x0]
     fb4:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     fb8:	fmadd	d16, d18, d8, d16
     fbc:	movk	x0, #0x3fc5, lsl #48
     fc0:	fmov	d1, x0
     fc4:	fmsub	d0, d2, d2, d8
     fc8:	fmadd	d7, d17, d8, d7
     fcc:	fadd	d9, d2, d3
     fd0:	fmadd	d6, d16, d8, d6
     fd4:	fdiv	d0, d0, d9
     fd8:	fmadd	d5, d7, d8, d5
     fdc:	fmadd	d4, d6, d8, d4
     fe0:	fmadd	d1, d5, d8, d1
     fe4:	fmul	d1, d1, d8
     fe8:	ldp	d8, d9, [sp, #16]
     fec:	ldp	x29, x30, [sp], #48
     ff0:	fdiv	d1, d1, d4
     ff4:	fmadd	d0, d1, d3, d0
     ff8:	fadd	d0, d0, d2
     ffc:	fadd	d0, d0, d0
    1000:	ret
    1004:	adrp	x0, 0 <__kernel_tan>
    1008:	fmul	d2, d0, d0
    100c:	stp	d8, d9, [sp, #16]
    1010:	fmov	d5, #1.000000000000000000e+00
    1014:	ldr	d3, [x0]
    1018:	adrp	x0, 0 <__kernel_tan>
    101c:	ldr	d18, [x0]
    1020:	adrp	x0, 0 <__kernel_tan>
    1024:	fmadd	d18, d2, d3, d18
    1028:	ldr	d16, [x0]
    102c:	adrp	x0, 0 <__kernel_tan>
    1030:	ldr	d1, [x0]
    1034:	adrp	x0, 0 <__kernel_tan>
    1038:	ldr	d17, [x0]
    103c:	adrp	x0, 0 <__kernel_tan>
    1040:	fmadd	d17, d2, d1, d17
    1044:	ldr	d8, [x0]
    1048:	adrp	x0, 0 <__kernel_tan>
    104c:	fmadd	d16, d18, d2, d16
    1050:	ldr	d9, [x0]
    1054:	adrp	x0, 0 <__kernel_tan>
    1058:	ldr	d6, [x0]
    105c:	adrp	x0, 0 <__kernel_tan>
    1060:	ldr	d7, [x0]
    1064:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1068:	fmadd	d9, d17, d2, d9
    106c:	movk	x0, #0x3fc5, lsl #48
    1070:	fmov	d3, x0
    1074:	adrp	x0, 0 <__kernel_tan>
    1078:	fmadd	d8, d16, d2, d8
    107c:	ldr	d4, [x0]
    1080:	adrp	x0, 0 <__kernel_tan>
    1084:	ldr	d1, [x0]
    1088:	fmadd	d7, d9, d2, d7
    108c:	fmadd	d6, d8, d2, d6
    1090:	ldp	d8, d9, [sp, #16]
    1094:	ldp	x29, x30, [sp], #48
    1098:	fmadd	d5, d7, d2, d5
    109c:	fmadd	d3, d6, d2, d3
    10a0:	fmul	d2, d3, d2
    10a4:	fdiv	d2, d2, d5
    10a8:	fmsub	d2, d0, d2, d4
    10ac:	fsub	d0, d0, d2
    10b0:	fsub	d0, d1, d0
    10b4:	ret
    10b8:	fmov	d1, #1.000000000000000000e+00
    10bc:	fmov	d3, #5.000000000000000000e-01
    10c0:	adrp	x0, 0 <__kernel_tan>
    10c4:	fadd	d0, d0, d1
    10c8:	ldr	d17, [x0]
    10cc:	adrp	x0, 0 <__kernel_tan>
    10d0:	ldr	d9, [x0]
    10d4:	adrp	x0, 0 <__kernel_tan>
    10d8:	fmul	d0, d0, d3
    10dc:	ldr	d6, [x0]
    10e0:	adrp	x0, 0 <__kernel_tan>
    10e4:	ldr	d16, [x0]
    10e8:	adrp	x0, 0 <__kernel_tan>
    10ec:	fmadd	d9, d0, d17, d9
    10f0:	fcmp	d0, #0.0
    10f4:	ldr	d4, [x0]
    10f8:	adrp	x0, 0 <__kernel_tan>
    10fc:	ldr	d7, [x0]
    1100:	adrp	x0, 0 <__kernel_tan>
    1104:	fmadd	d7, d0, d16, d7
    1108:	ldr	d2, [x0]
    110c:	adrp	x0, 0 <__kernel_tan>
    1110:	ldr	d5, [x0]
    1114:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1118:	fmadd	d6, d9, d0, d6
    111c:	movk	x0, #0x3fc5, lsl #48
    1120:	fmov	d8, x0
    1124:	adrp	x0, 0 <__kernel_tan>
    1128:	ldr	d3, [x0]
    112c:	fmadd	d5, d7, d0, d5
    1130:	fmadd	d4, d6, d0, d4
    1134:	fmadd	d3, d5, d0, d3
    1138:	fmadd	d2, d4, d0, d2
    113c:	fmadd	d3, d3, d0, d1
    1140:	fmadd	d8, d2, d0, d8
    1144:	fmul	d8, d8, d0
    1148:	b.pl	1160 <pts_ieee754_acos+0x2bc>  // b.nfrst
    114c:	str	d3, [sp, #40]
    1150:	bl	0 <sqrt>
    1154:	ldr	d3, [sp, #40]
    1158:	fmov	d1, d0
    115c:	b	1164 <pts_ieee754_acos+0x2c0>
    1160:	fsqrt	d1, d0
    1164:	fdiv	d8, d8, d3
    1168:	adrp	x0, 0 <__kernel_tan>
    116c:	fmov	d3, #-2.000000000000000000e+00
    1170:	ldr	d2, [x0]
    1174:	adrp	x0, 0 <__kernel_tan>
    1178:	ldr	d0, [x0]
    117c:	fmadd	d2, d8, d1, d2
    1180:	ldp	d8, d9, [sp, #16]
    1184:	ldp	x29, x30, [sp], #48
    1188:	fadd	d1, d2, d1
    118c:	fmadd	d0, d1, d3, d0
    1190:	ret

0000000000001194 <pts_ieee754_asin>:
    1194:	fmov	x0, d0
    1198:	stp	x29, x30, [sp, #-64]!
    119c:	fmov	d1, d0
    11a0:	mov	x29, sp
    11a4:	stp	x19, x20, [sp, #16]
    11a8:	mov	w1, #0x3fefffff            	// #1072693247
    11ac:	ubfx	x19, x0, #32, #31
    11b0:	cmp	w19, w1
    11b4:	b.le	1200 <pts_ieee754_asin+0x6c>
    11b8:	mov	w1, #0xc0100000            	// #-1072693248
    11bc:	add	w19, w19, w1
    11c0:	orr	w19, w19, w0
    11c4:	cbz	w19, 11dc <pts_ieee754_asin+0x48>
    11c8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    11cc:	fmov	d0, x0
    11d0:	ldp	x19, x20, [sp, #16]
    11d4:	ldp	x29, x30, [sp], #64
    11d8:	ret
    11dc:	adrp	x0, 0 <__kernel_tan>
    11e0:	ldp	x19, x20, [sp, #16]
    11e4:	ldr	d0, [x0]
    11e8:	adrp	x0, 0 <__kernel_tan>
    11ec:	ldr	d2, [x0]
    11f0:	fmul	d0, d1, d0
    11f4:	ldp	x29, x30, [sp], #64
    11f8:	fmadd	d0, d1, d2, d0
    11fc:	ret
    1200:	lsr	x20, x0, #32
    1204:	mov	w0, #0x3fdfffff            	// #1071644671
    1208:	cmp	w19, w0
    120c:	b.gt	12d4 <pts_ieee754_asin+0x140>
    1210:	mov	w0, #0x3e3fffff            	// #1044381695
    1214:	cmp	w19, w0
    1218:	b.gt	13dc <pts_ieee754_asin+0x248>
    121c:	adrp	x0, 0 <__kernel_tan>
    1220:	fmov	d3, #1.000000000000000000e+00
    1224:	ldr	d2, [x0]
    1228:	fadd	d2, d0, d2
    122c:	fcmpe	d2, d3
    1230:	b.gt	11d0 <pts_ieee754_asin+0x3c>
    1234:	movi	d2, #0x0
    1238:	stp	d8, d9, [sp, #32]
    123c:	adrp	x0, 0 <__kernel_tan>
    1240:	ldp	x19, x20, [sp, #16]
    1244:	ldr	d3, [x0]
    1248:	adrp	x0, 0 <__kernel_tan>
    124c:	ldr	d16, [x0]
    1250:	adrp	x0, 0 <__kernel_tan>
    1254:	fmadd	d16, d2, d3, d16
    1258:	fmov	d3, #1.000000000000000000e+00
    125c:	ldr	d8, [x0]
    1260:	adrp	x0, 0 <__kernel_tan>
    1264:	ldr	d0, [x0]
    1268:	adrp	x0, 0 <__kernel_tan>
    126c:	ldr	d9, [x0]
    1270:	adrp	x0, 0 <__kernel_tan>
    1274:	fmadd	d9, d2, d0, d9
    1278:	ldr	d6, [x0]
    127c:	adrp	x0, 0 <__kernel_tan>
    1280:	fmadd	d8, d16, d2, d8
    1284:	ldr	d7, [x0]
    1288:	adrp	x0, 0 <__kernel_tan>
    128c:	ldr	d4, [x0]
    1290:	adrp	x0, 0 <__kernel_tan>
    1294:	ldr	d5, [x0]
    1298:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    129c:	fmadd	d7, d9, d2, d7
    12a0:	movk	x0, #0x3fc5, lsl #48
    12a4:	fmov	d0, x0
    12a8:	fmadd	d6, d8, d2, d6
    12ac:	ldp	d8, d9, [sp, #32]
    12b0:	ldp	x29, x30, [sp], #64
    12b4:	fmadd	d5, d7, d2, d5
    12b8:	fmadd	d4, d6, d2, d4
    12bc:	fmadd	d3, d5, d2, d3
    12c0:	fmadd	d0, d4, d2, d0
    12c4:	fmul	d0, d0, d2
    12c8:	fdiv	d0, d0, d3
    12cc:	fmadd	d0, d1, d0, d1
    12d0:	ret
    12d4:	fabs	d1, d0
    12d8:	fmov	d0, #1.000000000000000000e+00
    12dc:	fmov	d18, #5.000000000000000000e-01
    12e0:	adrp	x0, 0 <__kernel_tan>
    12e4:	stp	d8, d9, [sp, #32]
    12e8:	adrp	x1, 0 <__kernel_tan>
    12ec:	ldr	d17, [x0]
    12f0:	fsub	d1, d0, d1
    12f4:	adrp	x0, 0 <__kernel_tan>
    12f8:	ldr	d3, [x1]
    12fc:	ldr	d9, [x0]
    1300:	adrp	x0, 0 <__kernel_tan>
    1304:	fmul	d1, d1, d18
    1308:	ldr	d6, [x0]
    130c:	adrp	x0, 0 <__kernel_tan>
    1310:	ldr	d16, [x0]
    1314:	adrp	x0, 0 <__kernel_tan>
    1318:	fmadd	d9, d1, d17, d9
    131c:	fcmp	d1, #0.0
    1320:	ldr	d4, [x0]
    1324:	adrp	x0, 0 <__kernel_tan>
    1328:	ldr	d7, [x0]
    132c:	adrp	x0, 0 <__kernel_tan>
    1330:	fmadd	d7, d1, d16, d7
    1334:	ldr	d2, [x0]
    1338:	adrp	x0, 0 <__kernel_tan>
    133c:	ldr	d5, [x0]
    1340:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1344:	fmadd	d6, d9, d1, d6
    1348:	movk	x0, #0x3fc5, lsl #48
    134c:	fmov	d8, x0
    1350:	fmadd	d5, d7, d1, d5
    1354:	fmadd	d4, d6, d1, d4
    1358:	fmadd	d3, d5, d1, d3
    135c:	fmadd	d2, d4, d1, d2
    1360:	fmadd	d3, d3, d1, d0
    1364:	fmadd	d8, d2, d1, d8
    1368:	fmul	d8, d8, d1
    136c:	b.pl	1388 <pts_ieee754_asin+0x1f4>  // b.nfrst
    1370:	fmov	d0, d1
    1374:	stp	d1, d3, [sp, #48]
    1378:	bl	0 <sqrt>
    137c:	fmov	d2, d0
    1380:	ldp	d1, d3, [sp, #48]
    1384:	b	138c <pts_ieee754_asin+0x1f8>
    1388:	fsqrt	d2, d1
    138c:	fdiv	d8, d8, d3
    1390:	mov	w0, #0x3332                	// #13106
    1394:	movk	w0, #0x3fef, lsl #16
    1398:	cmp	w19, w0
    139c:	b.le	13e8 <pts_ieee754_asin+0x254>
    13a0:	fmadd	d2, d2, d8, d2
    13a4:	adrp	x0, 0 <__kernel_tan>
    13a8:	fmov	d3, #2.000000000000000000e+00
    13ac:	ldr	d1, [x0]
    13b0:	adrp	x0, 0 <__kernel_tan>
    13b4:	ldr	d0, [x0]
    13b8:	fmadd	d1, d2, d3, d1
    13bc:	fsub	d0, d0, d1
    13c0:	fneg	d1, d0
    13c4:	cmp	w20, #0x0
    13c8:	ldp	x19, x20, [sp, #16]
    13cc:	ldp	d8, d9, [sp, #32]
    13d0:	fcsel	d0, d1, d0, le
    13d4:	ldp	x29, x30, [sp], #64
    13d8:	ret
    13dc:	fmul	d2, d0, d0
    13e0:	stp	d8, d9, [sp, #32]
    13e4:	b	123c <pts_ieee754_asin+0xa8>
    13e8:	movi	v0.2d, #0xffffffff00000000
    13ec:	fadd	d6, d2, d2
    13f0:	adrp	x0, 0 <__kernel_tan>
    13f4:	fmov	d5, #-2.000000000000000000e+00
    13f8:	ldr	d3, [x0]
    13fc:	adrp	x0, 0 <__kernel_tan>
    1400:	and	v4.8b, v2.8b, v0.8b
    1404:	ldr	d0, [x0]
    1408:	fmsub	d1, d4, d4, d1
    140c:	fadd	d2, d4, d2
    1410:	fmadd	d4, d4, d5, d0
    1414:	fdiv	d1, d1, d2
    1418:	fnmadd	d1, d1, d5, d3
    141c:	fmadd	d1, d6, d8, d1
    1420:	fsub	d1, d1, d4
    1424:	fsub	d0, d0, d1
    1428:	b	13c0 <pts_ieee754_asin+0x22c>
    142c:	nop

0000000000001430 <pts_ieee754_atan>:
    1430:	fmov	x1, d0
    1434:	fmov	d1, d0
    1438:	mov	w2, #0x440fffff            	// #1141899263
    143c:	ubfx	x0, x1, #32, #31
    1440:	lsr	x3, x1, #32
    1444:	cmp	w0, w2
    1448:	b.le	1490 <pts_ieee754_atan+0x60>
    144c:	mov	w2, #0x7ff00000            	// #2146435072
    1450:	cmp	w0, w2
    1454:	b.gt	1488 <pts_ieee754_atan+0x58>
    1458:	cmp	w1, #0x0
    145c:	ccmp	w0, w2, #0x0, ne	// ne = any
    1460:	b.eq	1488 <pts_ieee754_atan+0x58>  // b.none
    1464:	adrp	x0, 0 <__kernel_tan>
    1468:	add	x0, x0, #0x0
    146c:	cmp	w3, #0x0
    1470:	b.le	167c <pts_ieee754_atan+0x24c>
    1474:	adrp	x1, 0 <__kernel_tan>
    1478:	ldr	d0, [x0, #424]
    147c:	ldr	d1, [x1]
    1480:	fadd	d0, d0, d1
    1484:	ret
    1488:	fadd	d0, d1, d1
    148c:	ret
    1490:	mov	w1, #0x3fdbffff            	// #1071382527
    1494:	cmp	w0, w1
    1498:	b.gt	1558 <pts_ieee754_atan+0x128>
    149c:	mov	w1, #0x3e3fffff            	// #1044381695
    14a0:	cmp	w0, w1
    14a4:	b.gt	14c0 <pts_ieee754_atan+0x90>
    14a8:	adrp	x0, 0 <__kernel_tan>
    14ac:	fmov	d3, #1.000000000000000000e+00
    14b0:	ldr	d2, [x0]
    14b4:	fadd	d2, d0, d2
    14b8:	fcmpe	d2, d3
    14bc:	b.gt	1484 <pts_ieee754_atan+0x54>
    14c0:	fmul	d3, d1, d1
    14c4:	adrp	x0, 0 <__kernel_tan>
    14c8:	ldr	d21, [x0]
    14cc:	adrp	x0, 0 <__kernel_tan>
    14d0:	fmul	d0, d3, d3
    14d4:	ldr	d19, [x0]
    14d8:	adrp	x0, 0 <__kernel_tan>
    14dc:	ldr	d20, [x0]
    14e0:	adrp	x0, 0 <__kernel_tan>
    14e4:	fmadd	d19, d0, d21, d19
    14e8:	ldr	d18, [x0]
    14ec:	adrp	x0, 0 <__kernel_tan>
    14f0:	fmadd	d18, d0, d20, d18
    14f4:	ldr	d17, [x0]
    14f8:	adrp	x0, 0 <__kernel_tan>
    14fc:	ldr	d16, [x0]
    1500:	adrp	x0, 0 <__kernel_tan>
    1504:	ldr	d7, [x0]
    1508:	adrp	x0, 0 <__kernel_tan>
    150c:	fmadd	d17, d19, d0, d17
    1510:	ldr	d6, [x0]
    1514:	adrp	x0, 0 <__kernel_tan>
    1518:	fmadd	d16, d0, d18, d16
    151c:	ldr	d5, [x0]
    1520:	adrp	x0, 0 <__kernel_tan>
    1524:	ldr	d4, [x0]
    1528:	adrp	x0, 0 <__kernel_tan>
    152c:	ldr	d2, [x0]
    1530:	fmadd	d7, d17, d0, d7
    1534:	fmadd	d6, d0, d16, d6
    1538:	fmadd	d5, d7, d0, d5
    153c:	fmadd	d4, d0, d6, d4
    1540:	fmadd	d2, d0, d5, d2
    1544:	fmul	d0, d0, d4
    1548:	fmadd	d0, d3, d2, d0
    154c:	fmul	d0, d0, d1
    1550:	fsub	d0, d1, d0
    1554:	ret
    1558:	fabs	d1, d0
    155c:	mov	w1, #0x3ff2ffff            	// #1072889855
    1560:	cmp	w0, w1
    1564:	b.le	1648 <pts_ieee754_atan+0x218>
    1568:	mov	w1, #0x7fff                	// #32767
    156c:	movk	w1, #0x4003, lsl #16
    1570:	cmp	w0, w1
    1574:	b.gt	1690 <pts_ieee754_atan+0x260>
    1578:	fmov	d2, #1.500000000000000000e+00
    157c:	fmov	d3, #1.000000000000000000e+00
    1580:	adrp	x0, 0 <__kernel_tan>
    1584:	fmadd	d3, d1, d2, d3
    1588:	fsub	d1, d1, d2
    158c:	ldr	d19, [x0]
    1590:	adrp	x0, 0 <__kernel_tan>
    1594:	ldr	d0, [x0]
    1598:	fdiv	d3, d1, d3
    159c:	fmul	d4, d3, d3
    15a0:	adrp	x0, 0 <__kernel_tan>
    15a4:	cmp	w3, #0x0
    15a8:	ldr	d23, [x0]
    15ac:	adrp	x0, 0 <__kernel_tan>
    15b0:	fmul	d2, d4, d4
    15b4:	ldr	d21, [x0]
    15b8:	adrp	x0, 0 <__kernel_tan>
    15bc:	ldr	d22, [x0]
    15c0:	adrp	x0, 0 <__kernel_tan>
    15c4:	fmadd	d21, d2, d23, d21
    15c8:	ldr	d20, [x0]
    15cc:	adrp	x0, 0 <__kernel_tan>
    15d0:	fmadd	d20, d2, d22, d20
    15d4:	ldr	d18, [x0]
    15d8:	adrp	x0, 0 <__kernel_tan>
    15dc:	ldr	d17, [x0]
    15e0:	adrp	x0, 0 <__kernel_tan>
    15e4:	ldr	d16, [x0]
    15e8:	adrp	x0, 0 <__kernel_tan>
    15ec:	fmadd	d18, d21, d2, d18
    15f0:	ldr	d7, [x0]
    15f4:	adrp	x0, 0 <__kernel_tan>
    15f8:	fmadd	d17, d20, d2, d17
    15fc:	ldr	d6, [x0]
    1600:	adrp	x0, 0 <__kernel_tan>
    1604:	ldr	d1, [x0]
    1608:	adrp	x0, 0 <__kernel_tan>
    160c:	ldr	d5, [x0]
    1610:	fmadd	d16, d18, d2, d16
    1614:	fmadd	d7, d17, d2, d7
    1618:	fmadd	d6, d16, d2, d6
    161c:	fmadd	d1, d7, d2, d1
    1620:	fmadd	d5, d6, d2, d5
    1624:	fmul	d1, d1, d2
    1628:	fmadd	d1, d5, d4, d1
    162c:	fmul	d1, d1, d3
    1630:	fsub	d1, d1, d19
    1634:	fsub	d1, d1, d3
    1638:	fsub	d0, d0, d1
    163c:	fneg	d1, d0
    1640:	fcsel	d0, d1, d0, lt	// lt = tstop
    1644:	ret
    1648:	mov	w1, #0x3fe5ffff            	// #1072037887
    164c:	cmp	w0, w1
    1650:	b.gt	16ac <pts_ieee754_atan+0x27c>
    1654:	fmov	d2, #2.000000000000000000e+00
    1658:	fmov	d3, #-1.000000000000000000e+00
    165c:	adrp	x0, 0 <__kernel_tan>
    1660:	fmadd	d3, d1, d2, d3
    1664:	fadd	d1, d1, d2
    1668:	ldr	d19, [x0]
    166c:	adrp	x0, 0 <__kernel_tan>
    1670:	ldr	d0, [x0]
    1674:	fdiv	d3, d3, d1
    1678:	b	159c <pts_ieee754_atan+0x16c>
    167c:	adrp	x1, 0 <__kernel_tan>
    1680:	ldr	d1, [x0, #424]
    1684:	ldr	d0, [x1]
    1688:	fsub	d0, d0, d1
    168c:	ret
    1690:	adrp	x0, 0 <__kernel_tan>
    1694:	fmov	d3, #-1.000000000000000000e+00
    1698:	fdiv	d3, d3, d1
    169c:	ldr	d19, [x0]
    16a0:	adrp	x0, 0 <__kernel_tan>
    16a4:	ldr	d0, [x0]
    16a8:	b	159c <pts_ieee754_atan+0x16c>
    16ac:	fmov	d2, #1.000000000000000000e+00
    16b0:	adrp	x0, 0 <__kernel_tan>
    16b4:	fsub	d3, d1, d2
    16b8:	fadd	d1, d1, d2
    16bc:	ldr	d19, [x0]
    16c0:	adrp	x0, 0 <__kernel_tan>
    16c4:	ldr	d0, [x0]
    16c8:	fdiv	d3, d3, d1
    16cc:	b	159c <pts_ieee754_atan+0x16c>

00000000000016d0 <pts_ieee754_atan2>:
    16d0:	fmov	x1, d1
    16d4:	fmov	d2, d0
    16d8:	mov	w3, #0x7ff00000            	// #2146435072
    16dc:	neg	w0, w1
    16e0:	ubfx	x5, x1, #32, #31
    16e4:	orr	w0, w0, w1
    16e8:	orr	w0, w5, w0, lsr #31
    16ec:	cmp	w0, w3
    16f0:	b.hi	17ac <pts_ieee754_atan2+0xdc>  // b.pmore
    16f4:	fmov	x0, d0
    16f8:	neg	w2, w0
    16fc:	ubfx	x6, x0, #32, #31
    1700:	orr	w2, w2, w0
    1704:	lsr	x8, x0, #32
    1708:	orr	w2, w6, w2, lsr #31
    170c:	cmp	w2, w3
    1710:	b.hi	17ac <pts_ieee754_atan2+0xdc>  // b.pmore
    1714:	lsr	x7, x1, #32
    1718:	mov	w2, #0xc0100000            	// #-1072693248
    171c:	add	w2, w7, w2
    1720:	orr	w2, w2, w1
    1724:	cbz	w2, 17dc <pts_ieee754_atan2+0x10c>
    1728:	asr	w4, w7, #30
    172c:	lsr	w2, w8, #31
    1730:	and	w4, w4, #0x2
    1734:	orr	w0, w6, w0
    1738:	orr	w4, w4, w2
    173c:	cbz	w0, 17b4 <pts_ieee754_atan2+0xe4>
    1740:	orr	w1, w5, w1
    1744:	cbz	w1, 17e4 <pts_ieee754_atan2+0x114>
    1748:	cmp	w5, w3
    174c:	b.eq	1850 <pts_ieee754_atan2+0x180>  // b.none
    1750:	cmp	w6, w3
    1754:	b.eq	17e4 <pts_ieee754_atan2+0x114>  // b.none
    1758:	sub	w6, w6, w5
    175c:	asr	w6, w6, #20
    1760:	cmp	w6, #0x3c
    1764:	b.gt	182c <pts_ieee754_atan2+0x15c>
    1768:	cmp	w7, #0x0
    176c:	mov	w0, #0xffffffc4            	// #-60
    1770:	movi	d0, #0x0
    1774:	ccmp	w6, w0, #0x0, lt	// lt = tstop
    1778:	b.ge	18dc <pts_ieee754_atan2+0x20c>  // b.tcont
    177c:	cmp	w4, #0x1
    1780:	b.eq	18d4 <pts_ieee754_atan2+0x204>  // b.none
    1784:	cmp	w4, #0x2
    1788:	b.ne	1880 <pts_ieee754_atan2+0x1b0>  // b.any
    178c:	adrp	x0, 0 <__kernel_tan>
    1790:	add	x0, x0, #0x0
    1794:	adrp	x1, 0 <__kernel_tan>
    1798:	ldr	d2, [x0, #8]
    179c:	ldr	d1, [x1]
    17a0:	fsub	d0, d0, d2
    17a4:	fsub	d0, d1, d0
    17a8:	ret
    17ac:	fadd	d0, d1, d2
    17b0:	ret
    17b4:	cmp	w4, #0x2
    17b8:	b.eq	1800 <pts_ieee754_atan2+0x130>  // b.none
    17bc:	cmp	w4, #0x3
    17c0:	b.ne	17e0 <pts_ieee754_atan2+0x110>  // b.any
    17c4:	adrp	x0, 0 <__kernel_tan>
    17c8:	adrp	x1, 0 <__kernel_tan>
    17cc:	ldr	d1, [x0]
    17d0:	ldr	d0, [x1]
    17d4:	fsub	d0, d0, d1
    17d8:	ret
    17dc:	b	1430 <pts_ieee754_atan>
    17e0:	ret
    17e4:	adrp	x0, 0 <__kernel_tan>
    17e8:	tbnz	w8, #31, 1818 <pts_ieee754_atan2+0x148>
    17ec:	adrp	x1, 0 <__kernel_tan>
    17f0:	ldr	d0, [x0]
    17f4:	ldr	d1, [x1]
    17f8:	fadd	d0, d0, d1
    17fc:	ret
    1800:	adrp	x0, 0 <__kernel_tan>
    1804:	adrp	x1, 0 <__kernel_tan>
    1808:	ldr	d0, [x0]
    180c:	ldr	d1, [x1]
    1810:	fadd	d0, d0, d1
    1814:	ret
    1818:	adrp	x1, 0 <__kernel_tan>
    181c:	ldr	d1, [x0]
    1820:	ldr	d0, [x1]
    1824:	fsub	d0, d0, d1
    1828:	ret
    182c:	adrp	x0, 0 <__kernel_tan>
    1830:	add	x0, x0, #0x0
    1834:	adrp	x1, 0 <__kernel_tan>
    1838:	fmov	d1, #5.000000000000000000e-01
    183c:	ldr	d2, [x0, #8]
    1840:	ldr	d0, [x1]
    1844:	fmadd	d0, d2, d1, d0
    1848:	tbnz	w4, #0, 18d4 <pts_ieee754_atan2+0x204>
    184c:	ret
    1850:	cmp	w6, w5
    1854:	b.eq	18a4 <pts_ieee754_atan2+0x1d4>  // b.none
    1858:	cmp	w4, #0x2
    185c:	b.eq	1800 <pts_ieee754_atan2+0x130>  // b.none
    1860:	cmp	w4, #0x3
    1864:	b.eq	17c4 <pts_ieee754_atan2+0xf4>  // b.none
    1868:	movi	d1, #0x0
    186c:	cmp	w4, #0x1
    1870:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
    1874:	fmov	d0, x0
    1878:	fcsel	d0, d0, d1, eq	// eq = none
    187c:	ret
    1880:	cbz	w4, 198c <pts_ieee754_atan2+0x2bc>
    1884:	adrp	x0, 0 <__kernel_tan>
    1888:	add	x0, x0, #0x0
    188c:	adrp	x1, 0 <__kernel_tan>
    1890:	ldr	d2, [x0, #8]
    1894:	ldr	d1, [x1]
    1898:	fsub	d0, d0, d2
    189c:	fsub	d0, d0, d1
    18a0:	ret
    18a4:	adrp	x0, 0 <__kernel_tan>
    18a8:	cmp	w4, #0x2
    18ac:	b.eq	1978 <pts_ieee754_atan2+0x2a8>  // b.none
    18b0:	cmp	w4, #0x3
    18b4:	b.eq	1964 <pts_ieee754_atan2+0x294>  // b.none
    18b8:	cmp	w4, #0x1
    18bc:	b.eq	1950 <pts_ieee754_atan2+0x280>  // b.none
    18c0:	adrp	x1, 0 <__kernel_tan>
    18c4:	ldr	d0, [x0]
    18c8:	ldr	d1, [x1]
    18cc:	fadd	d0, d0, d1
    18d0:	ret
    18d4:	fneg	d0, d0
    18d8:	ret
    18dc:	fdiv	d0, d2, d1
    18e0:	stp	x29, x30, [sp, #-16]!
    18e4:	mov	x29, sp
    18e8:	fabs	d0, d0
    18ec:	bl	1430 <pts_ieee754_atan>
    18f0:	cmp	w4, #0x1
    18f4:	b.eq	1948 <pts_ieee754_atan2+0x278>  // b.none
    18f8:	cmp	w4, #0x2
    18fc:	b.ne	1924 <pts_ieee754_atan2+0x254>  // b.any
    1900:	adrp	x0, 0 <__kernel_tan>
    1904:	add	x0, x0, #0x0
    1908:	adrp	x1, 0 <__kernel_tan>
    190c:	ldr	d2, [x0, #8]
    1910:	ldr	d1, [x1]
    1914:	fsub	d0, d0, d2
    1918:	fsub	d0, d1, d0
    191c:	ldp	x29, x30, [sp], #16
    1920:	ret
    1924:	cbz	w4, 191c <pts_ieee754_atan2+0x24c>
    1928:	adrp	x0, 0 <__kernel_tan>
    192c:	add	x0, x0, #0x0
    1930:	adrp	x1, 0 <__kernel_tan>
    1934:	ldr	d2, [x0, #8]
    1938:	ldr	d1, [x1]
    193c:	fsub	d0, d0, d2
    1940:	fsub	d0, d0, d1
    1944:	b	191c <pts_ieee754_atan2+0x24c>
    1948:	fneg	d0, d0
    194c:	b	191c <pts_ieee754_atan2+0x24c>
    1950:	adrp	x1, 0 <__kernel_tan>
    1954:	ldr	d1, [x0]
    1958:	ldr	d0, [x1]
    195c:	fsub	d0, d0, d1
    1960:	ret
    1964:	adrp	x1, 0 <__kernel_tan>
    1968:	ldr	d1, [x0]
    196c:	ldr	d0, [x1]
    1970:	fsub	d0, d0, d1
    1974:	ret
    1978:	adrp	x1, 0 <__kernel_tan>
    197c:	ldr	d0, [x0]
    1980:	ldr	d1, [x1]
    1984:	fadd	d0, d0, d1
    1988:	ret
    198c:	ret

0000000000001990 <pts_ieee754_cos>:
    1990:	sub	sp, sp, #0x30
    1994:	mov	w1, #0x21fb                	// #8699
    1998:	adrp	x0, 0 <__stack_chk_guard>
    199c:	ldr	x0, [x0]
    19a0:	fmov	d1, d0
    19a4:	stp	x29, x30, [sp, #32]
    19a8:	add	x29, sp, #0x20
    19ac:	movk	w1, #0x3fe9, lsl #16
    19b0:	ldr	x2, [x0]
    19b4:	str	x2, [sp, #24]
    19b8:	mov	x2, #0x0                   	// #0
    19bc:	fmov	x0, d0
    19c0:	ubfx	x0, x0, #32, #31
    19c4:	cmp	w0, w1
    19c8:	b.le	1aa8 <pts_ieee754_cos+0x118>
    19cc:	mov	w1, #0x7fefffff            	// #2146435071
    19d0:	cmp	w0, w1
    19d4:	b.le	1a04 <pts_ieee754_cos+0x74>
    19d8:	fsub	d0, d0, d0
    19dc:	adrp	x0, 0 <__stack_chk_guard>
    19e0:	ldr	x0, [x0]
    19e4:	ldr	x2, [sp, #24]
    19e8:	ldr	x1, [x0]
    19ec:	subs	x2, x2, x1
    19f0:	mov	x1, #0x0                   	// #0
    19f4:	b.ne	1ed0 <pts_ieee754_cos+0x540>  // b.any
    19f8:	ldp	x29, x30, [sp, #32]
    19fc:	add	sp, sp, #0x30
    1a00:	ret
    1a04:	add	x0, sp, #0x8
    1a08:	bl	ba0 <__ieee754_rem_pio2>
    1a0c:	and	w0, w0, #0x3
    1a10:	cmp	w0, #0x1
    1a14:	b.eq	1d34 <pts_ieee754_cos+0x3a4>  // b.none
    1a18:	cmp	w0, #0x2
    1a1c:	b.eq	1c7c <pts_ieee754_cos+0x2ec>  // b.none
    1a20:	cbz	w0, 1bc8 <pts_ieee754_cos+0x238>
    1a24:	ldp	d0, d2, [sp, #8]
    1a28:	mov	w0, #0x3e3fffff            	// #1044381695
    1a2c:	fmov	x1, d0
    1a30:	ubfx	x1, x1, #32, #31
    1a34:	cmp	w1, w0
    1a38:	b.gt	1a44 <pts_ieee754_cos+0xb4>
    1a3c:	fcvtzs	w0, d0
    1a40:	cbz	w0, 19dc <pts_ieee754_cos+0x4c>
    1a44:	adrp	x0, 0 <__kernel_tan>
    1a48:	fmul	d3, d0, d0
    1a4c:	fmov	d17, #5.000000000000000000e-01
    1a50:	ldr	d7, [x0]
    1a54:	adrp	x0, 0 <__kernel_tan>
    1a58:	ldr	d6, [x0]
    1a5c:	adrp	x0, 0 <__kernel_tan>
    1a60:	fmadd	d6, d3, d7, d6
    1a64:	fmul	d7, d0, d3
    1a68:	ldr	d5, [x0]
    1a6c:	adrp	x0, 0 <__kernel_tan>
    1a70:	ldr	d4, [x0]
    1a74:	adrp	x0, 0 <__kernel_tan>
    1a78:	ldr	d1, [x0]
    1a7c:	adrp	x0, 0 <__kernel_tan>
    1a80:	ldr	d16, [x0]
    1a84:	fmadd	d5, d3, d6, d5
    1a88:	fmadd	d4, d3, d5, d4
    1a8c:	fmadd	d1, d3, d4, d1
    1a90:	fmul	d1, d7, d1
    1a94:	fnmsub	d1, d2, d17, d1
    1a98:	fnmsub	d2, d3, d1, d2
    1a9c:	fmsub	d2, d7, d16, d2
    1aa0:	fsub	d0, d0, d2
    1aa4:	b	19dc <pts_ieee754_cos+0x4c>
    1aa8:	mov	w1, #0x3e3fffff            	// #1044381695
    1aac:	cmp	w0, w1
    1ab0:	b.le	1b54 <pts_ieee754_cos+0x1c4>
    1ab4:	adrp	x1, 0 <__kernel_tan>
    1ab8:	fmul	d2, d0, d0
    1abc:	ldr	d7, [x1]
    1ac0:	adrp	x1, 0 <__kernel_tan>
    1ac4:	ldr	d6, [x1]
    1ac8:	adrp	x1, 0 <__kernel_tan>
    1acc:	fmadd	d6, d2, d7, d6
    1ad0:	ldr	d5, [x1]
    1ad4:	adrp	x1, 0 <__kernel_tan>
    1ad8:	ldr	d4, [x1]
    1adc:	adrp	x1, 0 <__kernel_tan>
    1ae0:	ldr	d0, [x1]
    1ae4:	adrp	x1, 0 <__kernel_tan>
    1ae8:	ldr	d3, [x1]
    1aec:	mov	w1, #0x3332                	// #13106
    1af0:	fmadd	d5, d2, d6, d5
    1af4:	movk	w1, #0x3fd3, lsl #16
    1af8:	fmadd	d4, d2, d5, d4
    1afc:	fmadd	d0, d2, d4, d0
    1b00:	fmadd	d3, d2, d0, d3
    1b04:	fmul	d3, d2, d3
    1b08:	cmp	w0, w1
    1b0c:	b.le	1ba8 <pts_ieee754_cos+0x218>
    1b10:	mov	w1, #0x3fe90000            	// #1072234496
    1b14:	cmp	w0, w1
    1b18:	b.gt	1dc4 <pts_ieee754_cos+0x434>
    1b1c:	sub	w0, w0, #0x200, lsl #12
    1b20:	fmov	d0, x0
    1b24:	fmov	d5, #1.000000000000000000e+00
    1b28:	shl	d0, d0, #32
    1b2c:	fneg	d4, d0
    1b30:	fsub	d5, d5, d0
    1b34:	movi	d0, #0x0
    1b38:	fmov	d6, #5.000000000000000000e-01
    1b3c:	fmadd	d4, d2, d6, d4
    1b40:	fmul	d0, d1, d0
    1b44:	fnmsub	d0, d2, d3, d0
    1b48:	fsub	d0, d4, d0
    1b4c:	fsub	d0, d5, d0
    1b50:	b	19dc <pts_ieee754_cos+0x4c>
    1b54:	fcvtzs	w0, d0
    1b58:	cbz	w0, 1dbc <pts_ieee754_cos+0x42c>
    1b5c:	adrp	x0, 0 <__kernel_tan>
    1b60:	fmul	d2, d0, d0
    1b64:	ldr	d7, [x0]
    1b68:	adrp	x0, 0 <__kernel_tan>
    1b6c:	ldr	d6, [x0]
    1b70:	adrp	x0, 0 <__kernel_tan>
    1b74:	fmadd	d6, d2, d7, d6
    1b78:	ldr	d5, [x0]
    1b7c:	adrp	x0, 0 <__kernel_tan>
    1b80:	ldr	d4, [x0]
    1b84:	adrp	x0, 0 <__kernel_tan>
    1b88:	ldr	d0, [x0]
    1b8c:	adrp	x0, 0 <__kernel_tan>
    1b90:	ldr	d3, [x0]
    1b94:	fmadd	d5, d6, d2, d5
    1b98:	fmadd	d4, d5, d2, d4
    1b9c:	fmadd	d0, d4, d2, d0
    1ba0:	fmadd	d3, d0, d2, d3
    1ba4:	fmul	d3, d3, d2
    1ba8:	movi	d0, #0x0
    1bac:	fmov	d5, #5.000000000000000000e-01
    1bb0:	fmov	d4, #1.000000000000000000e+00
    1bb4:	fmul	d0, d1, d0
    1bb8:	fmsub	d0, d3, d2, d0
    1bbc:	fmadd	d0, d2, d5, d0
    1bc0:	fsub	d0, d4, d0
    1bc4:	b	19dc <pts_ieee754_cos+0x4c>
    1bc8:	ldp	d1, d7, [sp, #8]
    1bcc:	mov	w1, #0x3e3fffff            	// #1044381695
    1bd0:	fmov	x0, d1
    1bd4:	ubfx	x0, x0, #32, #31
    1bd8:	cmp	w0, w1
    1bdc:	b.le	1e48 <pts_ieee754_cos+0x4b8>
    1be0:	adrp	x1, 0 <__kernel_tan>
    1be4:	fmul	d2, d1, d1
    1be8:	ldr	d16, [x1]
    1bec:	adrp	x1, 0 <__kernel_tan>
    1bf0:	ldr	d6, [x1]
    1bf4:	adrp	x1, 0 <__kernel_tan>
    1bf8:	fmadd	d6, d2, d16, d6
    1bfc:	ldr	d5, [x1]
    1c00:	adrp	x1, 0 <__kernel_tan>
    1c04:	ldr	d4, [x1]
    1c08:	adrp	x1, 0 <__kernel_tan>
    1c0c:	ldr	d0, [x1]
    1c10:	adrp	x1, 0 <__kernel_tan>
    1c14:	ldr	d3, [x1]
    1c18:	mov	w1, #0x3332                	// #13106
    1c1c:	fmadd	d5, d2, d6, d5
    1c20:	movk	w1, #0x3fd3, lsl #16
    1c24:	fmadd	d4, d2, d5, d4
    1c28:	fmadd	d0, d2, d4, d0
    1c2c:	fmadd	d3, d2, d0, d3
    1c30:	fmul	d3, d2, d3
    1c34:	cmp	w0, w1
    1c38:	b.le	1e9c <pts_ieee754_cos+0x50c>
    1c3c:	mov	w1, #0x3fe90000            	// #1072234496
    1c40:	cmp	w0, w1
    1c44:	b.gt	1ec4 <pts_ieee754_cos+0x534>
    1c48:	sub	w0, w0, #0x200, lsl #12
    1c4c:	fmov	d4, x0
    1c50:	fmov	d0, #1.000000000000000000e+00
    1c54:	shl	d4, d4, #32
    1c58:	fneg	d5, d4
    1c5c:	fsub	d0, d0, d4
    1c60:	fmov	d4, #5.000000000000000000e-01
    1c64:	fmul	d1, d1, d7
    1c68:	fnmsub	d1, d2, d3, d1
    1c6c:	fmadd	d2, d2, d4, d5
    1c70:	fsub	d1, d2, d1
    1c74:	fsub	d0, d0, d1
    1c78:	b	19dc <pts_ieee754_cos+0x4c>
    1c7c:	ldp	d1, d7, [sp, #8]
    1c80:	mov	w1, #0x3e3fffff            	// #1044381695
    1c84:	fmov	x0, d1
    1c88:	ubfx	x0, x0, #32, #31
    1c8c:	cmp	w0, w1
    1c90:	b.le	1dd0 <pts_ieee754_cos+0x440>
    1c94:	adrp	x1, 0 <__kernel_tan>
    1c98:	fmul	d2, d1, d1
    1c9c:	ldr	d16, [x1]
    1ca0:	adrp	x1, 0 <__kernel_tan>
    1ca4:	ldr	d6, [x1]
    1ca8:	adrp	x1, 0 <__kernel_tan>
    1cac:	fmadd	d6, d2, d16, d6
    1cb0:	ldr	d5, [x1]
    1cb4:	adrp	x1, 0 <__kernel_tan>
    1cb8:	ldr	d4, [x1]
    1cbc:	adrp	x1, 0 <__kernel_tan>
    1cc0:	ldr	d0, [x1]
    1cc4:	adrp	x1, 0 <__kernel_tan>
    1cc8:	ldr	d3, [x1]
    1ccc:	mov	w1, #0x3332                	// #13106
    1cd0:	fmadd	d5, d2, d6, d5
    1cd4:	movk	w1, #0x3fd3, lsl #16
    1cd8:	fmadd	d4, d2, d5, d4
    1cdc:	fmadd	d0, d2, d4, d0
    1ce0:	fmadd	d3, d2, d0, d3
    1ce4:	fmul	d3, d2, d3
    1ce8:	cmp	w0, w1
    1cec:	b.le	1e28 <pts_ieee754_cos+0x498>
    1cf0:	mov	w1, #0x3fe90000            	// #1072234496
    1cf4:	cmp	w0, w1
    1cf8:	b.gt	1eb8 <pts_ieee754_cos+0x528>
    1cfc:	sub	w0, w0, #0x200, lsl #12
    1d00:	fmov	d4, x0
    1d04:	fmov	d0, #1.000000000000000000e+00
    1d08:	shl	d4, d4, #32
    1d0c:	fneg	d5, d4
    1d10:	fsub	d0, d0, d4
    1d14:	fmov	d4, #5.000000000000000000e-01
    1d18:	fmul	d1, d1, d7
    1d1c:	fnmsub	d1, d2, d3, d1
    1d20:	fmadd	d2, d2, d4, d5
    1d24:	fsub	d1, d2, d1
    1d28:	fsub	d0, d0, d1
    1d2c:	fneg	d0, d0
    1d30:	b	19dc <pts_ieee754_cos+0x4c>
    1d34:	ldp	d0, d2, [sp, #8]
    1d38:	mov	w0, #0x3e3fffff            	// #1044381695
    1d3c:	fmov	x1, d0
    1d40:	ubfx	x1, x1, #32, #31
    1d44:	cmp	w1, w0
    1d48:	b.gt	1d54 <pts_ieee754_cos+0x3c4>
    1d4c:	fcvtzs	w0, d0
    1d50:	cbz	w0, 1d2c <pts_ieee754_cos+0x39c>
    1d54:	adrp	x0, 0 <__kernel_tan>
    1d58:	fmul	d3, d0, d0
    1d5c:	fmov	d17, #5.000000000000000000e-01
    1d60:	ldr	d7, [x0]
    1d64:	adrp	x0, 0 <__kernel_tan>
    1d68:	ldr	d6, [x0]
    1d6c:	adrp	x0, 0 <__kernel_tan>
    1d70:	fmadd	d6, d3, d7, d6
    1d74:	fmul	d7, d0, d3
    1d78:	ldr	d5, [x0]
    1d7c:	adrp	x0, 0 <__kernel_tan>
    1d80:	ldr	d4, [x0]
    1d84:	adrp	x0, 0 <__kernel_tan>
    1d88:	ldr	d1, [x0]
    1d8c:	adrp	x0, 0 <__kernel_tan>
    1d90:	ldr	d16, [x0]
    1d94:	fmadd	d5, d3, d6, d5
    1d98:	fmadd	d4, d3, d5, d4
    1d9c:	fmadd	d1, d3, d4, d1
    1da0:	fmul	d1, d7, d1
    1da4:	fnmsub	d1, d2, d17, d1
    1da8:	fnmsub	d2, d3, d1, d2
    1dac:	fmsub	d2, d7, d16, d2
    1db0:	fsub	d0, d0, d2
    1db4:	fneg	d0, d0
    1db8:	b	19dc <pts_ieee754_cos+0x4c>
    1dbc:	fmov	d0, #1.000000000000000000e+00
    1dc0:	b	19dc <pts_ieee754_cos+0x4c>
    1dc4:	fmov	d5, #7.187500000000000000e-01
    1dc8:	fmov	d4, #-2.812500000000000000e-01
    1dcc:	b	1b34 <pts_ieee754_cos+0x1a4>
    1dd0:	fcvtzs	w0, d1
    1dd4:	fmov	d0, #-1.000000000000000000e+00
    1dd8:	cbz	w0, 19dc <pts_ieee754_cos+0x4c>
    1ddc:	adrp	x0, 0 <__kernel_tan>
    1de0:	fmul	d2, d1, d1
    1de4:	ldr	d16, [x0]
    1de8:	adrp	x0, 0 <__kernel_tan>
    1dec:	ldr	d6, [x0]
    1df0:	adrp	x0, 0 <__kernel_tan>
    1df4:	fmadd	d6, d2, d16, d6
    1df8:	ldr	d5, [x0]
    1dfc:	adrp	x0, 0 <__kernel_tan>
    1e00:	ldr	d4, [x0]
    1e04:	adrp	x0, 0 <__kernel_tan>
    1e08:	ldr	d0, [x0]
    1e0c:	adrp	x0, 0 <__kernel_tan>
    1e10:	ldr	d3, [x0]
    1e14:	fmadd	d5, d2, d6, d5
    1e18:	fmadd	d4, d2, d5, d4
    1e1c:	fmadd	d0, d2, d4, d0
    1e20:	fmadd	d3, d2, d0, d3
    1e24:	fmul	d3, d2, d3
    1e28:	fmul	d1, d1, d7
    1e2c:	fmov	d4, #5.000000000000000000e-01
    1e30:	fmsub	d1, d2, d3, d1
    1e34:	fmov	d0, #1.000000000000000000e+00
    1e38:	fmadd	d1, d2, d4, d1
    1e3c:	fsub	d0, d0, d1
    1e40:	fneg	d0, d0
    1e44:	b	19dc <pts_ieee754_cos+0x4c>
    1e48:	fcvtzs	w0, d1
    1e4c:	cbz	w0, 1dbc <pts_ieee754_cos+0x42c>
    1e50:	adrp	x0, 0 <__kernel_tan>
    1e54:	fmul	d2, d1, d1
    1e58:	ldr	d16, [x0]
    1e5c:	adrp	x0, 0 <__kernel_tan>
    1e60:	ldr	d6, [x0]
    1e64:	adrp	x0, 0 <__kernel_tan>
    1e68:	fmadd	d6, d2, d16, d6
    1e6c:	ldr	d5, [x0]
    1e70:	adrp	x0, 0 <__kernel_tan>
    1e74:	ldr	d4, [x0]
    1e78:	adrp	x0, 0 <__kernel_tan>
    1e7c:	ldr	d0, [x0]
    1e80:	adrp	x0, 0 <__kernel_tan>
    1e84:	ldr	d3, [x0]
    1e88:	fmadd	d5, d6, d2, d5
    1e8c:	fmadd	d4, d5, d2, d4
    1e90:	fmadd	d0, d4, d2, d0
    1e94:	fmadd	d3, d0, d2, d3
    1e98:	fmul	d3, d3, d2
    1e9c:	fmul	d1, d1, d7
    1ea0:	fmov	d4, #5.000000000000000000e-01
    1ea4:	fmsub	d1, d3, d2, d1
    1ea8:	fmov	d0, #1.000000000000000000e+00
    1eac:	fmadd	d1, d2, d4, d1
    1eb0:	fsub	d0, d0, d1
    1eb4:	b	19dc <pts_ieee754_cos+0x4c>
    1eb8:	fmov	d0, #7.187500000000000000e-01
    1ebc:	fmov	d5, #-2.812500000000000000e-01
    1ec0:	b	1d14 <pts_ieee754_cos+0x384>
    1ec4:	fmov	d0, #7.187500000000000000e-01
    1ec8:	fmov	d5, #-2.812500000000000000e-01
    1ecc:	b	1c60 <pts_ieee754_cos+0x2d0>
    1ed0:	bl	0 <__stack_chk_fail>

0000000000001ed4 <pts_ieee754_exp>:
    1ed4:	fmov	x1, d0
    1ed8:	mov	w4, #0x2e41                	// #11841
    1edc:	movk	w4, #0x4086, lsl #16
    1ee0:	ubfx	x2, x1, #32, #31
    1ee4:	lsr	x3, x1, #32
    1ee8:	lsr	x0, x1, #63
    1eec:	cmp	w2, w4
    1ef0:	b.ls	1f14 <pts_ieee754_exp+0x40>  // b.plast
    1ef4:	mov	w4, #0x7fefffff            	// #2146435071
    1ef8:	cmp	w2, w4
    1efc:	b.ls	1f90 <pts_ieee754_exp+0xbc>  // b.plast
    1f00:	and	w3, w3, #0xfffff
    1f04:	orr	w3, w3, w1
    1f08:	cbz	w3, 2168 <pts_ieee754_exp+0x294>
    1f0c:	fadd	d0, d0, d0
    1f10:	ret
    1f14:	mov	w1, #0x2e42                	// #11842
    1f18:	movk	w1, #0x3fd6, lsl #16
    1f1c:	cmp	w2, w1
    1f20:	b.hi	2084 <pts_ieee754_exp+0x1b0>  // b.pmore
    1f24:	mov	w0, #0x3e2fffff            	// #1043333119
    1f28:	cmp	w2, w0
    1f2c:	b.ls	2148 <pts_ieee754_exp+0x274>  // b.plast
    1f30:	adrp	x0, 0 <__kernel_tan>
    1f34:	fmul	d1, d0, d0
    1f38:	ldr	d6, [x0]
    1f3c:	adrp	x0, 0 <__kernel_tan>
    1f40:	ldr	d5, [x0]
    1f44:	adrp	x0, 0 <__kernel_tan>
    1f48:	fmadd	d5, d1, d6, d5
    1f4c:	ldr	d4, [x0]
    1f50:	adrp	x0, 0 <__kernel_tan>
    1f54:	ldr	d3, [x0]
    1f58:	adrp	x0, 0 <__kernel_tan>
    1f5c:	ldr	d2, [x0]
    1f60:	fmadd	d4, d1, d5, d4
    1f64:	fmadd	d3, d1, d4, d3
    1f68:	fmadd	d2, d1, d3, d2
    1f6c:	fmsub	d1, d1, d2, d0
    1f70:	fmov	d4, #2.000000000000000000e+00
    1f74:	fmul	d2, d0, d1
    1f78:	fmov	d3, #1.000000000000000000e+00
    1f7c:	fsub	d1, d1, d4
    1f80:	fdiv	d1, d2, d1
    1f84:	fsub	d0, d1, d0
    1f88:	fsub	d0, d3, d0
    1f8c:	ret
    1f90:	adrp	x1, 0 <__kernel_tan>
    1f94:	ldr	d1, [x1]
    1f98:	fcmpe	d0, d1
    1f9c:	b.gt	2178 <pts_ieee754_exp+0x2a4>
    1fa0:	adrp	x1, 0 <__kernel_tan>
    1fa4:	ldr	d1, [x1]
    1fa8:	fcmpe	d0, d1
    1fac:	b.mi	21b0 <pts_ieee754_exp+0x2dc>  // b.first
    1fb0:	adrp	x1, 0 <__kernel_tan>
    1fb4:	add	x1, x1, #0x0
    1fb8:	add	x0, x1, w0, sxtw #3
    1fbc:	adrp	x1, 0 <__kernel_tan>
    1fc0:	ldr	d1, [x1]
    1fc4:	adrp	x1, 0 <__kernel_tan>
    1fc8:	ldr	d2, [x0, #464]
    1fcc:	adrp	x0, 0 <__kernel_tan>
    1fd0:	ldr	d16, [x1]
    1fd4:	adrp	x1, 0 <__kernel_tan>
    1fd8:	fmadd	d2, d0, d1, d2
    1fdc:	ldr	d4, [x0]
    1fe0:	adrp	x0, 0 <__kernel_tan>
    1fe4:	ldr	d7, [x1]
    1fe8:	adrp	x1, 0 <__kernel_tan>
    1fec:	ldr	d1, [x0]
    1ff0:	ldr	d6, [x1]
    1ff4:	adrp	x1, 0 <__kernel_tan>
    1ff8:	ldr	d5, [x1]
    1ffc:	fcvtzs	w0, d2
    2000:	scvtf	d3, w0
    2004:	fmsub	d16, d3, d16, d0
    2008:	fmul	d3, d3, d7
    200c:	fsub	d0, d16, d3
    2010:	fmul	d2, d0, d0
    2014:	fmadd	d5, d2, d6, d5
    2018:	fmadd	d4, d2, d5, d4
    201c:	fmadd	d1, d2, d4, d1
    2020:	cmn	w0, #0x3fd
    2024:	b.ge	21d4 <pts_ieee754_exp+0x300>  // b.tcont
    2028:	adrp	x1, 0 <__kernel_tan>
    202c:	fmov	d5, #2.000000000000000000e+00
    2030:	add	w0, w0, #0x3e8
    2034:	fmov	d4, #1.000000000000000000e+00
    2038:	ldr	d6, [x1]
    203c:	mov	w1, #0x3ff00000            	// #1072693248
    2040:	fmadd	d6, d2, d1, d6
    2044:	add	w0, w1, w0, lsl #20
    2048:	fmov	d1, x0
    204c:	adrp	x1, 0 <__kernel_tan>
    2050:	add	x1, x1, #0x0
    2054:	shl	d1, d1, #32
    2058:	ldr	d7, [x1, #24]
    205c:	fmsub	d2, d2, d6, d0
    2060:	fmul	d0, d0, d2
    2064:	fsub	d2, d5, d2
    2068:	fdiv	d0, d0, d2
    206c:	fsub	d0, d3, d0
    2070:	fsub	d0, d0, d16
    2074:	fsub	d0, d4, d0
    2078:	fmul	d0, d0, d1
    207c:	fmul	d0, d0, d7
    2080:	ret
    2084:	mov	w1, #0xa2b1                	// #41649
    2088:	movk	w1, #0x3ff0, lsl #16
    208c:	cmp	w2, w1
    2090:	b.hi	1fb0 <pts_ieee754_exp+0xdc>  // b.pmore
    2094:	fmov	d1, #1.000000000000000000e+00
    2098:	fcmp	d0, d1
    209c:	b.eq	21c8 <pts_ieee754_exp+0x2f4>  // b.none
    20a0:	adrp	x1, 0 <__kernel_tan>
    20a4:	add	x1, x1, #0x0
    20a8:	add	x1, x1, w0, sxtw #3
    20ac:	mov	w2, #0x1                   	// #1
    20b0:	sub	w0, w2, w0, lsl #1
    20b4:	mov	w2, #0x3ff00000            	// #1072693248
    20b8:	ldr	d16, [x1, #432]
    20bc:	add	w2, w2, w0, lsl #20
    20c0:	ldr	d3, [x1, #448]
    20c4:	fmov	d1, x2
    20c8:	fsub	d16, d0, d16
    20cc:	shl	d5, d1, #32
    20d0:	fsub	d0, d16, d3
    20d4:	fmul	d2, d0, d0
    20d8:	adrp	x1, 0 <__kernel_tan>
    20dc:	ldr	d1, [x1]
    20e0:	adrp	x1, 0 <__kernel_tan>
    20e4:	ldr	d7, [x1]
    20e8:	adrp	x1, 0 <__kernel_tan>
    20ec:	fmadd	d7, d2, d1, d7
    20f0:	ldr	d6, [x1]
    20f4:	adrp	x1, 0 <__kernel_tan>
    20f8:	ldr	d4, [x1]
    20fc:	adrp	x1, 0 <__kernel_tan>
    2100:	ldr	d1, [x1]
    2104:	fmadd	d6, d7, d2, d6
    2108:	fmadd	d4, d6, d2, d4
    210c:	fmadd	d1, d4, d2, d1
    2110:	fmsub	d1, d1, d2, d0
    2114:	cbz	w0, 1f70 <pts_ieee754_exp+0x9c>
    2118:	fmov	d4, #2.000000000000000000e+00
    211c:	fmul	d0, d1, d0
    2120:	fmov	d2, #1.000000000000000000e+00
    2124:	fsub	d1, d4, d1
    2128:	fdiv	d0, d0, d1
    212c:	fsub	d3, d3, d0
    2130:	fsub	d3, d3, d16
    2134:	fsub	d0, d2, d3
    2138:	cmp	w0, #0x400
    213c:	b.eq	2198 <pts_ieee754_exp+0x2c4>  // b.none
    2140:	fmul	d0, d0, d5
    2144:	ret
    2148:	adrp	x0, 0 <__kernel_tan>
    214c:	add	x0, x0, #0x0
    2150:	fmov	d2, #1.000000000000000000e+00
    2154:	ldr	d1, [x0, #16]
    2158:	fadd	d1, d1, d0
    215c:	fcmpe	d1, d2
    2160:	b.gt	2190 <pts_ieee754_exp+0x2bc>
    2164:	b	1f30 <pts_ieee754_exp+0x5c>
    2168:	movi	d1, #0x0
    216c:	cmp	w0, #0x0
    2170:	fcsel	d0, d0, d1, eq	// eq = none
    2174:	ret
    2178:	adrp	x0, 0 <__kernel_tan>
    217c:	add	x0, x0, #0x0
    2180:	ldr	d0, [x0, #16]
    2184:	ldr	d1, [x0, #16]
    2188:	fmul	d0, d0, d1
    218c:	ret
    2190:	fadd	d0, d0, d2
    2194:	ret
    2198:	adrp	x0, 0 <__kernel_tan>
    219c:	add	x0, x0, #0x0
    21a0:	fadd	d1, d0, d0
    21a4:	ldr	d0, [x0, #32]
    21a8:	fmul	d0, d1, d0
    21ac:	ret
    21b0:	adrp	x0, 0 <__kernel_tan>
    21b4:	add	x0, x0, #0x0
    21b8:	ldr	d0, [x0, #24]
    21bc:	ldr	d1, [x0, #24]
    21c0:	fmul	d0, d0, d1
    21c4:	ret
    21c8:	adrp	x0, 0 <__kernel_tan>
    21cc:	ldr	d0, [x0]
    21d0:	ret
    21d4:	mov	w1, #0x3ff00000            	// #1072693248
    21d8:	add	w1, w1, w0, lsl #20
    21dc:	fmov	d1, x1
    21e0:	shl	d5, d1, #32
    21e4:	b	20d8 <pts_ieee754_exp+0x204>
    21e8:	nop
    21ec:	nop

00000000000021f0 <pts_ieee754_log>:
    21f0:	fmov	x1, d0
    21f4:	mov	w3, #0xfffff               	// #1048575
    21f8:	lsr	x2, x1, #32
    21fc:	mov	w0, w2
    2200:	cmp	w2, w3
    2204:	b.gt	22b4 <pts_ieee754_log+0xc4>
    2208:	and	w0, w2, #0x7fffffff
    220c:	orr	w0, w0, w1
    2210:	cbz	w0, 237c <pts_ieee754_log+0x18c>
    2214:	tbnz	w2, #31, 2400 <pts_ieee754_log+0x210>
    2218:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    221c:	fmov	d1, x0
    2220:	mov	w6, #0xffffffca            	// #-54
    2224:	mov	w2, #0x7fefffff            	// #2146435071
    2228:	fmul	d0, d0, d1
    222c:	fmov	x1, d0
    2230:	lsr	x0, x1, #32
    2234:	cmp	w0, w2
    2238:	b.gt	22c4 <pts_ieee754_log+0xd4>
    223c:	and	w4, w0, #0xfffff
    2240:	asr	w0, w0, #20
    2244:	add	w3, w4, #0x95, lsl #12
    2248:	sub	w0, w0, #0x3ff
    224c:	add	w3, w3, #0xf64
    2250:	add	w5, w4, #0x2
    2254:	and	w2, w3, #0x100000
    2258:	fmov	d0, #1.000000000000000000e+00
    225c:	eor	w2, w2, #0x3ff00000
    2260:	add	w0, w0, w6
    2264:	orr	x2, x2, x4
    2268:	and	w5, w5, #0xfffff
    226c:	add	w3, w0, w3, lsr #20
    2270:	bfi	x1, x2, #32, #32
    2274:	fmov	d1, x1
    2278:	fsub	d0, d1, d0
    227c:	cmp	w5, #0x2
    2280:	b.gt	22cc <pts_ieee754_log+0xdc>
    2284:	fcmp	d0, #0.0
    2288:	b.ne	2388 <pts_ieee754_log+0x198>  // b.any
    228c:	movi	d0, #0x0
    2290:	cbz	w3, 22b0 <pts_ieee754_log+0xc0>
    2294:	adrp	x0, 0 <__kernel_tan>
    2298:	scvtf	d1, w3
    229c:	ldr	d0, [x0]
    22a0:	adrp	x0, 0 <__kernel_tan>
    22a4:	ldr	d2, [x0]
    22a8:	fmul	d0, d1, d0
    22ac:	fmadd	d0, d1, d2, d0
    22b0:	ret
    22b4:	mov	w6, #0x0                   	// #0
    22b8:	mov	w2, #0x7fefffff            	// #2146435071
    22bc:	cmp	w0, w2
    22c0:	b.le	223c <pts_ieee754_log+0x4c>
    22c4:	fadd	d0, d0, d0
    22c8:	ret
    22cc:	fmov	d2, #2.000000000000000000e+00
    22d0:	adrp	x0, 0 <__kernel_tan>
    22d4:	sub	w1, w4, #0x61, lsl #12
    22d8:	scvtf	d19, w3
    22dc:	fadd	d2, d0, d2
    22e0:	ldr	d18, [x0]
    22e4:	adrp	x0, 0 <__kernel_tan>
    22e8:	sub	w1, w1, #0x47a
    22ec:	ldr	d16, [x0]
    22f0:	adrp	x0, 0 <__kernel_tan>
    22f4:	fdiv	d2, d0, d2
    22f8:	ldr	d6, [x0]
    22fc:	adrp	x0, 0 <__kernel_tan>
    2300:	ldr	d17, [x0]
    2304:	adrp	x0, 0 <__kernel_tan>
    2308:	ldr	d7, [x0]
    230c:	adrp	x0, 0 <__kernel_tan>
    2310:	ldr	d1, [x0]
    2314:	adrp	x0, 0 <__kernel_tan>
    2318:	ldr	d4, [x0]
    231c:	mov	w0, #0xb851                	// #47185
    2320:	movk	w0, #0x6, lsl #16
    2324:	sub	w0, w0, w4
    2328:	orr	w0, w0, w1
    232c:	fmul	d5, d2, d2
    2330:	fmul	d3, d5, d5
    2334:	fmadd	d16, d3, d18, d16
    2338:	fmadd	d7, d3, d17, d7
    233c:	fmadd	d6, d16, d3, d6
    2340:	fmadd	d4, d7, d3, d4
    2344:	fmadd	d1, d6, d3, d1
    2348:	fmul	d1, d1, d5
    234c:	fmadd	d1, d3, d4, d1
    2350:	cmp	w0, #0x0
    2354:	b.le	23cc <pts_ieee754_log+0x1dc>
    2358:	fmov	d3, #5.000000000000000000e-01
    235c:	fmul	d3, d0, d3
    2360:	fmul	d3, d3, d0
    2364:	fadd	d1, d1, d3
    2368:	fmul	d1, d1, d2
    236c:	cbnz	w3, 240c <pts_ieee754_log+0x21c>
    2370:	fsub	d3, d3, d1
    2374:	fsub	d0, d0, d3
    2378:	ret
    237c:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2380:	fmov	d0, x0
    2384:	ret
    2388:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    238c:	fmov	d2, #5.000000000000000000e-01
    2390:	movk	x0, #0xbfd5, lsl #48
    2394:	fmov	d3, x0
    2398:	fmul	d1, d0, d0
    239c:	fmadd	d2, d0, d3, d2
    23a0:	fmul	d1, d1, d2
    23a4:	cbz	w3, 23f8 <pts_ieee754_log+0x208>
    23a8:	adrp	x0, 0 <__kernel_tan>
    23ac:	scvtf	d2, w3
    23b0:	ldr	d4, [x0]
    23b4:	adrp	x0, 0 <__kernel_tan>
    23b8:	ldr	d3, [x0]
    23bc:	fmsub	d1, d2, d4, d1
    23c0:	fsub	d1, d1, d0
    23c4:	fnmsub	d0, d2, d3, d1
    23c8:	ret
    23cc:	fsub	d1, d0, d1
    23d0:	fmul	d1, d1, d2
    23d4:	cbz	w3, 23f8 <pts_ieee754_log+0x208>
    23d8:	adrp	x0, 0 <__kernel_tan>
    23dc:	ldr	d3, [x0]
    23e0:	adrp	x0, 0 <__kernel_tan>
    23e4:	ldr	d2, [x0]
    23e8:	fmsub	d1, d19, d3, d1
    23ec:	fsub	d1, d1, d0
    23f0:	fnmsub	d0, d19, d2, d1
    23f4:	ret
    23f8:	fsub	d0, d0, d1
    23fc:	ret
    2400:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2404:	fmov	d0, x0
    2408:	ret
    240c:	adrp	x0, 0 <__kernel_tan>
    2410:	ldr	d4, [x0]
    2414:	adrp	x0, 0 <__kernel_tan>
    2418:	ldr	d2, [x0]
    241c:	fmadd	d1, d19, d4, d1
    2420:	fsub	d3, d3, d1
    2424:	fsub	d3, d3, d0
    2428:	fnmsub	d0, d19, d2, d3
    242c:	ret

0000000000002430 <pts_ieee754_log1p>:
    2430:	fmov	x1, d0
    2434:	mov	w3, #0x8279                	// #33401
    2438:	fmov	d1, d0
    243c:	movk	w3, #0x3fda, lsl #16
    2440:	lsr	x0, x1, #32
    2444:	mov	w2, w0
    2448:	cmp	w0, w3
    244c:	b.gt	2480 <pts_ieee754_log1p+0x50>
    2450:	and	w1, w0, #0x7fffffff
    2454:	mov	w2, #0x3fefffff            	// #1072693247
    2458:	cmp	w1, w2
    245c:	b.le	2514 <pts_ieee754_log1p+0xe4>
    2460:	fmov	d2, #-1.000000000000000000e+00
    2464:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2468:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    246c:	fmov	d0, x0
    2470:	fcmp	d1, d2
    2474:	fmov	d1, x1
    2478:	fcsel	d0, d0, d1, ne	// ne = any
    247c:	ret
    2480:	mov	w3, #0x7fefffff            	// #2146435071
    2484:	cmp	w0, w3
    2488:	b.gt	254c <pts_ieee754_log1p+0x11c>
    248c:	mov	w3, #0x433fffff            	// #1128267775
    2490:	cmp	w0, w3
    2494:	b.le	26e0 <pts_ieee754_log1p+0x2b0>
    2498:	asr	w0, w0, #20
    249c:	movi	d4, #0x0
    24a0:	sub	w0, w0, #0x3ff
    24a4:	mov	w3, #0xa09d                	// #41117
    24a8:	and	w2, w2, #0xfffff
    24ac:	and	x1, x1, #0xffffffff
    24b0:	movk	w3, #0x6, lsl #16
    24b4:	cmp	w2, w3
    24b8:	b.gt	26c0 <pts_ieee754_log1p+0x290>
    24bc:	orr	w3, w2, #0x3ff00000
    24c0:	sbfiz	x3, x3, #32, #32
    24c4:	orr	x1, x3, x1
    24c8:	fmov	d1, x1
    24cc:	fmov	d0, #1.000000000000000000e+00
    24d0:	fmov	d2, #5.000000000000000000e-01
    24d4:	fsub	d1, d1, d0
    24d8:	fmul	d2, d1, d2
    24dc:	fmul	d2, d2, d1
    24e0:	cbnz	w2, 25e8 <pts_ieee754_log1p+0x1b8>
    24e4:	fcmp	d1, #0.0
    24e8:	b.ne	2680 <pts_ieee754_log1p+0x250>  // b.any
    24ec:	movi	d0, #0x0
    24f0:	cbz	w0, 247c <pts_ieee754_log1p+0x4c>
    24f4:	scvtf	d1, w0
    24f8:	adrp	x0, 0 <__kernel_tan>
    24fc:	ldr	d0, [x0]
    2500:	adrp	x0, 0 <__kernel_tan>
    2504:	ldr	d2, [x0]
    2508:	fmadd	d0, d1, d0, d4
    250c:	fmadd	d0, d1, d2, d0
    2510:	ret
    2514:	mov	w2, #0x3e1fffff            	// #1042284543
    2518:	cmp	w1, w2
    251c:	b.gt	2554 <pts_ieee754_log1p+0x124>
    2520:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2524:	fmov	d2, x0
    2528:	mov	w0, #0x3c8fffff            	// #1016070143
    252c:	fadd	d1, d0, d2
    2530:	fcmpe	d1, #0.0
    2534:	ccmp	w1, w0, #0x0, gt
    2538:	b.le	247c <pts_ieee754_log1p+0x4c>
    253c:	fmul	d2, d0, d0
    2540:	fmov	d1, #5.000000000000000000e-01
    2544:	fmsub	d0, d2, d1, d0
    2548:	ret
    254c:	fadd	d0, d0, d0
    2550:	ret
    2554:	mov	w1, #0x413b                	// #16699
    2558:	movk	w1, #0x402d, lsl #16
    255c:	add	w0, w0, w1
    2560:	cmp	w0, w1
    2564:	b.ls	26e0 <pts_ieee754_log1p+0x2b0>  // b.plast
    2568:	fmov	d3, #2.000000000000000000e+00
    256c:	adrp	x0, 0 <__kernel_tan>
    2570:	fmov	d2, #5.000000000000000000e-01
    2574:	fadd	d3, d0, d3
    2578:	ldr	d18, [x0]
    257c:	adrp	x0, 0 <__kernel_tan>
    2580:	fmul	d2, d1, d2
    2584:	ldr	d17, [x0]
    2588:	adrp	x0, 0 <__kernel_tan>
    258c:	fdiv	d3, d1, d3
    2590:	ldr	d16, [x0]
    2594:	adrp	x0, 0 <__kernel_tan>
    2598:	fmul	d2, d2, d1
    259c:	ldr	d7, [x0]
    25a0:	adrp	x0, 0 <__kernel_tan>
    25a4:	ldr	d6, [x0]
    25a8:	adrp	x0, 0 <__kernel_tan>
    25ac:	ldr	d5, [x0]
    25b0:	adrp	x0, 0 <__kernel_tan>
    25b4:	ldr	d0, [x0]
    25b8:	fmul	d4, d3, d3
    25bc:	fmadd	d17, d4, d18, d17
    25c0:	fmadd	d16, d17, d4, d16
    25c4:	fmadd	d7, d16, d4, d7
    25c8:	fmadd	d6, d7, d4, d6
    25cc:	fmadd	d5, d6, d4, d5
    25d0:	fmadd	d0, d5, d4, d0
    25d4:	fmadd	d0, d0, d4, d2
    25d8:	fmul	d3, d0, d3
    25dc:	fsub	d0, d2, d3
    25e0:	fsub	d0, d1, d0
    25e4:	ret
    25e8:	fmov	d0, #2.000000000000000000e+00
    25ec:	adrp	x1, 0 <__kernel_tan>
    25f0:	fadd	d0, d1, d0
    25f4:	ldr	d19, [x1]
    25f8:	adrp	x1, 0 <__kernel_tan>
    25fc:	ldr	d18, [x1]
    2600:	adrp	x1, 0 <__kernel_tan>
    2604:	fdiv	d0, d1, d0
    2608:	ldr	d17, [x1]
    260c:	adrp	x1, 0 <__kernel_tan>
    2610:	ldr	d16, [x1]
    2614:	adrp	x1, 0 <__kernel_tan>
    2618:	ldr	d7, [x1]
    261c:	adrp	x1, 0 <__kernel_tan>
    2620:	ldr	d6, [x1]
    2624:	adrp	x1, 0 <__kernel_tan>
    2628:	ldr	d5, [x1]
    262c:	fmul	d3, d0, d0
    2630:	fmadd	d18, d3, d19, d18
    2634:	fmadd	d17, d18, d3, d17
    2638:	fmadd	d16, d17, d3, d16
    263c:	fmadd	d7, d16, d3, d7
    2640:	fmadd	d6, d7, d3, d6
    2644:	fmadd	d5, d6, d3, d5
    2648:	fmadd	d3, d3, d5, d2
    264c:	fmul	d3, d0, d3
    2650:	cbz	w0, 25dc <pts_ieee754_log1p+0x1ac>
    2654:	scvtf	d0, w0
    2658:	adrp	x0, 0 <__kernel_tan>
    265c:	ldr	d6, [x0]
    2660:	adrp	x0, 0 <__kernel_tan>
    2664:	ldr	d5, [x0]
    2668:	fmadd	d4, d0, d6, d4
    266c:	fadd	d4, d4, d3
    2670:	fsub	d4, d2, d4
    2674:	fsub	d1, d4, d1
    2678:	fnmsub	d0, d0, d5, d1
    267c:	ret
    2680:	mov	x1, #0x5555555555555555    	// #6148914691236517205
    2684:	movk	x1, #0xbfe5, lsl #48
    2688:	fmov	d3, x1
    268c:	fmadd	d0, d1, d3, d0
    2690:	fmul	d0, d0, d2
    2694:	cbz	w0, 25e0 <pts_ieee754_log1p+0x1b0>
    2698:	scvtf	d3, w0
    269c:	adrp	x0, 0 <__kernel_tan>
    26a0:	ldr	d2, [x0]
    26a4:	adrp	x0, 0 <__kernel_tan>
    26a8:	ldr	d5, [x0]
    26ac:	fmadd	d2, d3, d2, d4
    26b0:	fsub	d0, d0, d2
    26b4:	fsub	d0, d0, d1
    26b8:	fnmsub	d0, d3, d5, d0
    26bc:	ret
    26c0:	orr	w3, w2, #0x3fe00000
    26c4:	mov	w4, #0x100000              	// #1048576
    26c8:	sub	w2, w4, w2
    26cc:	add	w0, w0, #0x1
    26d0:	orr	x1, x1, x3, lsl #32
    26d4:	fmov	d1, x1
    26d8:	asr	w2, w2, #2
    26dc:	b	24cc <pts_ieee754_log1p+0x9c>
    26e0:	fmov	d4, #1.000000000000000000e+00
    26e4:	fadd	d0, d1, d4
    26e8:	fmov	x1, d0
    26ec:	lsr	x0, x1, #32
    26f0:	mov	w2, w0
    26f4:	asr	w0, w0, #20
    26f8:	sub	w0, w0, #0x3ff
    26fc:	cmp	w0, #0x0
    2700:	b.le	2714 <pts_ieee754_log1p+0x2e4>
    2704:	fsub	d1, d0, d1
    2708:	fsub	d4, d4, d1
    270c:	fdiv	d4, d4, d0
    2710:	b	24a4 <pts_ieee754_log1p+0x74>
    2714:	fsub	d4, d0, d4
    2718:	fsub	d4, d1, d4
    271c:	fdiv	d4, d4, d0
    2720:	b	24a4 <pts_ieee754_log1p+0x74>

0000000000002724 <pts_ieee754_acosh>:
    2724:	fmov	x1, d0
    2728:	mov	w2, #0x3fefffff            	// #1072693247
    272c:	lsr	x0, x1, #32
    2730:	cmp	w0, w2
    2734:	b.le	27b4 <pts_ieee754_acosh+0x90>
    2738:	stp	x29, x30, [sp, #-32]!
    273c:	mov	w2, #0x41afffff            	// #1102053375
    2740:	mov	x29, sp
    2744:	stp	d8, d9, [sp, #16]
    2748:	fmov	d8, d0
    274c:	cmp	w0, w2
    2750:	b.gt	278c <pts_ieee754_acosh+0x68>
    2754:	mov	w2, #0xc0100000            	// #-1072693248
    2758:	add	w2, w2, w0
    275c:	orr	w1, w2, w1
    2760:	cbz	w1, 2828 <pts_ieee754_acosh+0x104>
    2764:	mov	w1, #0x40000000            	// #1073741824
    2768:	cmp	w0, w1
    276c:	b.le	27d0 <pts_ieee754_acosh+0xac>
    2770:	fmov	d0, #-1.000000000000000000e+00
    2774:	fadd	d9, d8, d8
    2778:	fmadd	d0, d8, d8, d0
    277c:	fcmp	d0, #0.0
    2780:	b.pl	27f4 <pts_ieee754_acosh+0xd0>  // b.nfrst
    2784:	bl	0 <sqrt>
    2788:	b	27f8 <pts_ieee754_acosh+0xd4>
    278c:	mov	w1, #0x7fefffff            	// #2146435071
    2790:	cmp	w0, w1
    2794:	b.gt	27c0 <pts_ieee754_acosh+0x9c>
    2798:	bl	21f0 <pts_ieee754_log>
    279c:	adrp	x0, 0 <__kernel_tan>
    27a0:	ldp	d8, d9, [sp, #16]
    27a4:	ldr	d1, [x0]
    27a8:	ldp	x29, x30, [sp], #32
    27ac:	fadd	d0, d0, d1
    27b0:	ret
    27b4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    27b8:	fmov	d0, x0
    27bc:	ret
    27c0:	ldp	d8, d9, [sp, #16]
    27c4:	fadd	d0, d0, d0
    27c8:	ldp	x29, x30, [sp], #32
    27cc:	ret
    27d0:	fmov	d0, #1.000000000000000000e+00
    27d4:	fmov	d1, #2.000000000000000000e+00
    27d8:	fsub	d8, d8, d0
    27dc:	fmul	d0, d8, d8
    27e0:	fmadd	d0, d8, d1, d0
    27e4:	fcmp	d0, #0.0
    27e8:	b.pl	2814 <pts_ieee754_acosh+0xf0>  // b.nfrst
    27ec:	bl	0 <sqrt>
    27f0:	b	2818 <pts_ieee754_acosh+0xf4>
    27f4:	fsqrt	d0, d0
    27f8:	fadd	d8, d8, d0
    27fc:	fmov	d0, #1.000000000000000000e+00
    2800:	fdiv	d0, d0, d8
    2804:	fsub	d0, d9, d0
    2808:	ldp	d8, d9, [sp, #16]
    280c:	ldp	x29, x30, [sp], #32
    2810:	b	21f0 <pts_ieee754_log>
    2814:	fsqrt	d0, d0
    2818:	fadd	d0, d8, d0
    281c:	ldp	d8, d9, [sp, #16]
    2820:	ldp	x29, x30, [sp], #32
    2824:	b	2430 <pts_ieee754_log1p>
    2828:	ldp	d8, d9, [sp, #16]
    282c:	movi	d0, #0x0
    2830:	ldp	x29, x30, [sp], #32
    2834:	ret
    2838:	nop
    283c:	nop

0000000000002840 <pts_ieee754_asinh>:
    2840:	fmov	x0, d0
    2844:	stp	x29, x30, [sp, #-64]!
    2848:	fmov	d1, d0
    284c:	mov	x29, sp
    2850:	str	x19, [sp, #16]
    2854:	mov	w1, #0x7fefffff            	// #2146435071
    2858:	lsr	x19, x0, #32
    285c:	and	w0, w19, #0x7fffffff
    2860:	cmp	w0, w1
    2864:	b.gt	28fc <pts_ieee754_asinh+0xbc>
    2868:	mov	w1, #0x3e2fffff            	// #1043333119
    286c:	cmp	w0, w1
    2870:	b.le	28b8 <pts_ieee754_asinh+0x78>
    2874:	stp	d8, d9, [sp, #32]
    2878:	mov	w1, #0x41b00000            	// #1102053376
    287c:	fabs	d8, d0
    2880:	cmp	w0, w1
    2884:	b.le	2928 <pts_ieee754_asinh+0xe8>
    2888:	fmov	d0, d8
    288c:	bl	21f0 <pts_ieee754_log>
    2890:	adrp	x0, 0 <__kernel_tan>
    2894:	ldr	d1, [x0]
    2898:	fadd	d0, d0, d1
    289c:	fneg	d1, d0
    28a0:	cmp	w19, #0x0
    28a4:	ldp	d8, d9, [sp, #32]
    28a8:	fcsel	d0, d1, d0, le
    28ac:	ldr	x19, [sp, #16]
    28b0:	ldp	x29, x30, [sp], #64
    28b4:	ret
    28b8:	adrp	x0, 0 <__kernel_tan>
    28bc:	fmov	d3, #1.000000000000000000e+00
    28c0:	ldr	d2, [x0]
    28c4:	fadd	d2, d0, d2
    28c8:	fcmpe	d2, d3
    28cc:	b.gt	28ac <pts_ieee754_asinh+0x6c>
    28d0:	stp	d8, d9, [sp, #32]
    28d4:	fabs	d8, d0
    28d8:	fmul	d1, d1, d1
    28dc:	fmov	d0, #1.000000000000000000e+00
    28e0:	fadd	d0, d1, d0
    28e4:	fcmp	d0, #0.0
    28e8:	b.pl	290c <pts_ieee754_asinh+0xcc>  // b.nfrst
    28ec:	str	d1, [sp, #56]
    28f0:	bl	0 <sqrt>
    28f4:	ldr	d1, [sp, #56]
    28f8:	b	2910 <pts_ieee754_asinh+0xd0>
    28fc:	ldr	x19, [sp, #16]
    2900:	fadd	d0, d0, d0
    2904:	ldp	x29, x30, [sp], #64
    2908:	ret
    290c:	fsqrt	d0, d0
    2910:	fmov	d2, #1.000000000000000000e+00
    2914:	fadd	d0, d0, d2
    2918:	fdiv	d0, d1, d0
    291c:	fadd	d0, d0, d8
    2920:	bl	2430 <pts_ieee754_log1p>
    2924:	b	289c <pts_ieee754_asinh+0x5c>
    2928:	mov	w1, #0x40000000            	// #1073741824
    292c:	cmp	w0, w1
    2930:	b.le	28d8 <pts_ieee754_asinh+0x98>
    2934:	fmov	d0, #1.000000000000000000e+00
    2938:	fadd	d9, d8, d8
    293c:	fmadd	d1, d1, d1, d0
    2940:	fcmp	d1, #0.0
    2944:	b.pl	2958 <pts_ieee754_asinh+0x118>  // b.nfrst
    2948:	fmov	d0, d1
    294c:	bl	0 <sqrt>
    2950:	fmov	d1, d0
    2954:	b	295c <pts_ieee754_asinh+0x11c>
    2958:	fsqrt	d1, d1
    295c:	fadd	d1, d1, d8
    2960:	fmov	d0, #1.000000000000000000e+00
    2964:	fdiv	d0, d0, d1
    2968:	fadd	d0, d0, d9
    296c:	bl	21f0 <pts_ieee754_log>
    2970:	b	289c <pts_ieee754_asinh+0x5c>

0000000000002974 <pts_ieee754_atanh>:
    2974:	fmov	x0, d0
    2978:	mov	w3, #0x3ff00000            	// #1072693248
    297c:	neg	w1, w0
    2980:	ubfx	x2, x0, #32, #31
    2984:	orr	w1, w1, w0
    2988:	orr	w1, w2, w1, lsr #31
    298c:	cmp	w1, w3
    2990:	b.hi	2a4c <pts_ieee754_atanh+0xd8>  // b.pmore
    2994:	cmp	w2, w3
    2998:	b.eq	2a58 <pts_ieee754_atanh+0xe4>  // b.none
    299c:	stp	x29, x30, [sp, #-16]!
    29a0:	lsr	x5, x0, #32
    29a4:	mov	w1, #0x3e2fffff            	// #1043333119
    29a8:	mov	x29, sp
    29ac:	cmp	w2, w1
    29b0:	b.le	2a00 <pts_ieee754_atanh+0x8c>
    29b4:	and	x0, x0, #0xffffffff
    29b8:	sbfiz	x1, x2, #32, #32
    29bc:	orr	x0, x1, x0
    29c0:	fmov	d0, #1.000000000000000000e+00
    29c4:	fmov	d1, x0
    29c8:	mov	w0, #0x3fdfffff            	// #1071644671
    29cc:	fadd	d2, d1, d1
    29d0:	fsub	d0, d0, d1
    29d4:	cmp	w2, w0
    29d8:	b.le	2a28 <pts_ieee754_atanh+0xb4>
    29dc:	fdiv	d0, d2, d0
    29e0:	bl	2430 <pts_ieee754_log1p>
    29e4:	fmov	d1, #5.000000000000000000e-01
    29e8:	fmul	d0, d0, d1
    29ec:	fneg	d1, d0
    29f0:	cmp	w5, #0x0
    29f4:	fcsel	d0, d1, d0, lt	// lt = tstop
    29f8:	ldp	x29, x30, [sp], #16
    29fc:	ret
    2a00:	adrp	x1, 0 <__kernel_tan>
    2a04:	ldr	d2, [x1]
    2a08:	fadd	d1, d0, d2
    2a0c:	fcmpe	d1, #0.0
    2a10:	b.gt	29f8 <pts_ieee754_atanh+0x84>
    2a14:	and	x0, x0, #0xffffffff
    2a18:	sbfiz	x2, x2, #32, #32
    2a1c:	orr	x0, x2, x0
    2a20:	fmov	d1, x0
    2a24:	fadd	d2, d1, d1
    2a28:	fmov	d3, #1.000000000000000000e+00
    2a2c:	fmul	d0, d2, d1
    2a30:	fsub	d1, d3, d1
    2a34:	fdiv	d0, d0, d1
    2a38:	fadd	d0, d0, d2
    2a3c:	bl	2430 <pts_ieee754_log1p>
    2a40:	fmov	d1, #5.000000000000000000e-01
    2a44:	fmul	d0, d0, d1
    2a48:	b	29ec <pts_ieee754_atanh+0x78>
    2a4c:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2a50:	fmov	d0, x0
    2a54:	ret
    2a58:	fcmpe	d0, #0.0
    2a5c:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
    2a60:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    2a64:	fmov	d0, x0
    2a68:	fmov	d1, x1
    2a6c:	fcsel	d0, d0, d1, gt
    2a70:	ret

0000000000002a74 <pts_ieee754_log2>:
    2a74:	fmov	x0, d0
    2a78:	mov	w3, #0xfffff               	// #1048575
    2a7c:	lsr	x2, x0, #32
    2a80:	mov	w4, w0
    2a84:	mov	w1, w2
    2a88:	cmp	w2, w3
    2a8c:	b.gt	2bd4 <pts_ieee754_log2+0x160>
    2a90:	and	w1, w2, #0x7fffffff
    2a94:	orr	w0, w1, w0
    2a98:	cbz	w0, 2bec <pts_ieee754_log2+0x178>
    2a9c:	tbnz	w2, #31, 2bf8 <pts_ieee754_log2+0x184>
    2aa0:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2aa4:	fmov	d1, x0
    2aa8:	mov	w5, #0xffffffca            	// #-54
    2aac:	mov	w2, #0x7fefffff            	// #2146435071
    2ab0:	fmul	d0, d0, d1
    2ab4:	fmov	x0, d0
    2ab8:	lsr	x1, x0, #32
    2abc:	cmp	w1, w2
    2ac0:	b.gt	2be4 <pts_ieee754_log2+0x170>
    2ac4:	cmp	w4, #0x0
    2ac8:	mov	w2, #0x3ff00000            	// #1072693248
    2acc:	movi	d0, #0x0
    2ad0:	ccmp	w1, w2, #0x0, eq	// eq = none
    2ad4:	b.eq	2bd0 <pts_ieee754_log2+0x15c>  // b.none
    2ad8:	and	w4, w1, #0xfffff
    2adc:	fmov	d0, #1.000000000000000000e+00
    2ae0:	add	w3, w4, #0x95, lsl #12
    2ae4:	fmov	d5, #2.000000000000000000e+00
    2ae8:	add	w3, w3, #0xf64
    2aec:	adrp	x6, 0 <__kernel_tan>
    2af0:	and	w2, w3, #0x100000
    2af4:	fmov	d7, #5.000000000000000000e-01
    2af8:	eor	w2, w2, #0x3ff00000
    2afc:	ldr	d25, [x6]
    2b00:	orr	x2, x2, x4
    2b04:	adrp	x6, 0 <__kernel_tan>
    2b08:	adrp	x4, 0 <__kernel_tan>
    2b0c:	movi	v2.2d, #0xffffffff00000000
    2b10:	bfi	x0, x2, #32, #32
    2b14:	fmov	d1, x0
    2b18:	ldr	d21, [x6]
    2b1c:	adrp	x2, 0 <__kernel_tan>
    2b20:	fsub	d1, d1, d0
    2b24:	ldr	d19, [x4]
    2b28:	adrp	x4, 0 <__kernel_tan>
    2b2c:	ldr	d18, [x2]
    2b30:	adrp	x2, 0 <__kernel_tan>
    2b34:	asr	w1, w1, #20
    2b38:	ldr	d24, [x4]
    2b3c:	adrp	x4, 0 <__kernel_tan>
    2b40:	fadd	d5, d1, d5
    2b44:	fmul	d7, d1, d7
    2b48:	ldr	d20, [x4]
    2b4c:	sub	w1, w1, #0x3ff
    2b50:	ldr	d17, [x2]
    2b54:	adrp	x2, 0 <__kernel_tan>
    2b58:	add	w1, w1, w5
    2b5c:	adrp	x0, 0 <__kernel_tan>
    2b60:	fdiv	d5, d1, d5
    2b64:	fmsub	d4, d1, d7, d1
    2b68:	ldr	d16, [x2]
    2b6c:	add	w3, w1, w3, lsr #20
    2b70:	ldr	d22, [x0]
    2b74:	scvtf	d0, w3
    2b78:	and	v4.8b, v4.8b, v2.8b
    2b7c:	fsub	d2, d1, d4
    2b80:	fmadd	d23, d4, d16, d0
    2b84:	fmsub	d2, d1, d7, d2
    2b88:	fsub	d0, d0, d23
    2b8c:	fmadd	d0, d4, d16, d0
    2b90:	fmul	d3, d5, d5
    2b94:	fmul	d6, d3, d3
    2b98:	fmadd	d21, d6, d25, d21
    2b9c:	fmadd	d20, d6, d24, d20
    2ba0:	fmadd	d19, d6, d21, d19
    2ba4:	fmadd	d17, d6, d20, d17
    2ba8:	fmadd	d18, d6, d19, d18
    2bac:	fmul	d3, d3, d18
    2bb0:	fmadd	d3, d6, d17, d3
    2bb4:	fmadd	d3, d1, d7, d3
    2bb8:	fmadd	d1, d5, d3, d2
    2bbc:	fadd	d4, d4, d1
    2bc0:	fmul	d1, d1, d16
    2bc4:	fmadd	d1, d4, d22, d1
    2bc8:	fadd	d0, d0, d1
    2bcc:	fadd	d0, d0, d23
    2bd0:	ret
    2bd4:	mov	w5, #0x0                   	// #0
    2bd8:	mov	w2, #0x7fefffff            	// #2146435071
    2bdc:	cmp	w1, w2
    2be0:	b.le	2ac4 <pts_ieee754_log2+0x50>
    2be4:	fadd	d0, d0, d0
    2be8:	ret
    2bec:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2bf0:	fmov	d0, x0
    2bf4:	ret
    2bf8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2bfc:	fmov	d0, x0
    2c00:	ret

0000000000002c04 <pts_ieee754_log10>:
    2c04:	fmov	x0, d0
    2c08:	mov	w4, #0xfffff               	// #1048575
    2c0c:	lsr	x1, x0, #32
    2c10:	cmp	w1, w4
    2c14:	b.gt	2cc8 <pts_ieee754_log10+0xc4>
    2c18:	and	w2, w1, #0x7fffffff
    2c1c:	orr	w0, w2, w0
    2c20:	cbz	w0, 2cec <pts_ieee754_log10+0xe8>
    2c24:	tbnz	w1, #31, 2cf8 <pts_ieee754_log10+0xf4>
    2c28:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2c2c:	fmov	d1, x0
    2c30:	mov	w4, #0xffffffca            	// #-54
    2c34:	fmul	d0, d0, d1
    2c38:	fmov	x0, d0
    2c3c:	lsr	x2, x0, #32
    2c40:	mov	w3, w0
    2c44:	mov	w0, #0x7fefffff            	// #2146435071
    2c48:	cmp	w2, w0
    2c4c:	b.gt	2ce0 <pts_ieee754_log10+0xdc>
    2c50:	cmp	w3, #0x0
    2c54:	mov	w0, #0x3ff00000            	// #1072693248
    2c58:	movi	d0, #0x0
    2c5c:	ccmp	w2, w0, #0x0, eq	// eq = none
    2c60:	b.eq	2ce8 <pts_ieee754_log10+0xe4>  // b.none
    2c64:	asr	w0, w2, #20
    2c68:	mov	w1, #0x3ff                 	// #1023
    2c6c:	sub	w0, w0, #0x3ff
    2c70:	stp	x29, x30, [sp, #-16]!
    2c74:	add	w0, w0, w4
    2c78:	mov	x29, sp
    2c7c:	lsr	w4, w0, #31
    2c80:	sub	w1, w1, w4
    2c84:	add	w0, w0, w4
    2c88:	bfi	w2, w1, #20, #12
    2c8c:	scvtf	d20, w0
    2c90:	orr	x0, x3, x2, lsl #32
    2c94:	fmov	d0, x0
    2c98:	bl	21f0 <pts_ieee754_log>
    2c9c:	adrp	x0, 0 <__kernel_tan>
    2ca0:	ldp	x29, x30, [sp], #16
    2ca4:	ldr	d3, [x0]
    2ca8:	adrp	x0, 0 <__kernel_tan>
    2cac:	ldr	d2, [x0]
    2cb0:	adrp	x0, 0 <__kernel_tan>
    2cb4:	fmul	d0, d0, d3
    2cb8:	ldr	d1, [x0]
    2cbc:	fmadd	d0, d20, d2, d0
    2cc0:	fmadd	d0, d20, d1, d0
    2cc4:	ret
    2cc8:	mov	w2, w1
    2ccc:	mov	w3, w0
    2cd0:	mov	w4, #0x0                   	// #0
    2cd4:	mov	w0, #0x7fefffff            	// #2146435071
    2cd8:	cmp	w2, w0
    2cdc:	b.le	2c50 <pts_ieee754_log10+0x4c>
    2ce0:	fadd	d0, d0, d0
    2ce4:	ret
    2ce8:	ret
    2cec:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    2cf0:	fmov	d0, x0
    2cf4:	ret
    2cf8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2cfc:	fmov	d0, x0
    2d00:	ret

0000000000002d04 <pts_ieee754_expm1>:
    2d04:	fmov	x1, d0
    2d08:	mov	w2, #0x6879                	// #26745
    2d0c:	fmov	d2, d0
    2d10:	movk	w2, #0x4043, lsl #16
    2d14:	ubfx	x0, x1, #32, #31
    2d18:	lsr	x3, x1, #32
    2d1c:	cmp	w0, w2
    2d20:	b.ls	2e78 <pts_ieee754_expm1+0x174>  // b.plast
    2d24:	mov	w2, #0x2e41                	// #11841
    2d28:	movk	w2, #0x4086, lsl #16
    2d2c:	cmp	w0, w2
    2d30:	b.ls	2d64 <pts_ieee754_expm1+0x60>  // b.plast
    2d34:	mov	w2, #0x7fefffff            	// #2146435071
    2d38:	cmp	w0, w2
    2d3c:	b.ls	2d54 <pts_ieee754_expm1+0x50>  // b.plast
    2d40:	and	w0, w3, #0xfffff
    2d44:	orr	w0, w0, w1
    2d48:	cbz	w0, 3030 <pts_ieee754_expm1+0x32c>
    2d4c:	fadd	d0, d0, d0
    2d50:	ret
    2d54:	adrp	x0, 0 <__kernel_tan>
    2d58:	ldr	d0, [x0]
    2d5c:	fcmpe	d2, d0
    2d60:	b.gt	3054 <pts_ieee754_expm1+0x350>
    2d64:	tbnz	w3, #31, 2f08 <pts_ieee754_expm1+0x204>
    2d68:	adrp	x0, 0 <__kernel_tan>
    2d6c:	fmov	d1, #5.000000000000000000e-01
    2d70:	ldr	d0, [x0]
    2d74:	fmul	d0, d2, d0
    2d78:	fadd	d1, d1, d0
    2d7c:	adrp	x0, 0 <__kernel_tan>
    2d80:	ldr	d0, [x0]
    2d84:	adrp	x0, 0 <__kernel_tan>
    2d88:	fcvtzs	w1, d1
    2d8c:	ldr	d3, [x0]
    2d90:	scvtf	d5, w1
    2d94:	fmsub	d0, d5, d0, d2
    2d98:	fmul	d5, d5, d3
    2d9c:	fsub	d2, d0, d5
    2da0:	fmov	d20, #5.000000000000000000e-01
    2da4:	adrp	x0, 0 <__kernel_tan>
    2da8:	fmov	d18, #1.000000000000000000e+00
    2dac:	fmov	d4, #3.000000000000000000e+00
    2db0:	fmov	d6, #6.000000000000000000e+00
    2db4:	ldr	d21, [x0]
    2db8:	adrp	x0, 0 <__kernel_tan>
    2dbc:	fmul	d19, d2, d20
    2dc0:	fsub	d0, d0, d2
    2dc4:	ldr	d17, [x0]
    2dc8:	adrp	x0, 0 <__kernel_tan>
    2dcc:	ldr	d16, [x0]
    2dd0:	adrp	x0, 0 <__kernel_tan>
    2dd4:	fmul	d3, d2, d19
    2dd8:	fsub	d0, d0, d5
    2ddc:	ldr	d7, [x0]
    2de0:	adrp	x0, 0 <__kernel_tan>
    2de4:	ldr	d1, [x0]
    2de8:	fmadd	d5, d3, d21, d17
    2dec:	fmadd	d5, d5, d3, d16
    2df0:	fmadd	d5, d5, d3, d7
    2df4:	fmadd	d1, d5, d3, d1
    2df8:	fmadd	d1, d1, d3, d18
    2dfc:	fmsub	d4, d19, d1, d4
    2e00:	fmsub	d5, d2, d4, d6
    2e04:	fsub	d1, d1, d4
    2e08:	fdiv	d1, d1, d5
    2e0c:	fmul	d1, d1, d3
    2e10:	cbz	w1, 2efc <pts_ieee754_expm1+0x1f8>
    2e14:	fsub	d1, d1, d0
    2e18:	fnmsub	d0, d1, d2, d0
    2e1c:	fsub	d0, d0, d3
    2e20:	cmn	w1, #0x1
    2e24:	b.eq	2fb8 <pts_ieee754_expm1+0x2b4>  // b.none
    2e28:	cmp	w1, #0x1
    2e2c:	b.eq	2f9c <pts_ieee754_expm1+0x298>  // b.none
    2e30:	mov	w2, #0x3ff00000            	// #1072693248
    2e34:	add	w3, w1, #0x1
    2e38:	add	w0, w2, w1, lsl #20
    2e3c:	fmov	d1, x0
    2e40:	shl	d1, d1, #32
    2e44:	cmp	w3, #0x39
    2e48:	b.hi	2fc8 <pts_ieee754_expm1+0x2c4>  // b.pmore
    2e4c:	cmp	w1, #0x13
    2e50:	b.gt	2fe8 <pts_ieee754_expm1+0x2e4>
    2e54:	mov	w0, #0x200000              	// #2097152
    2e58:	fsub	d0, d0, d2
    2e5c:	asr	w0, w0, w1
    2e60:	sub	w2, w2, w0
    2e64:	fmov	d2, x2
    2e68:	shl	d2, d2, #32
    2e6c:	fsub	d0, d2, d0
    2e70:	fmul	d0, d1, d0
    2e74:	ret
    2e78:	mov	w1, #0x2e42                	// #11842
    2e7c:	movk	w1, #0x3fd6, lsl #16
    2e80:	cmp	w0, w1
    2e84:	b.hi	2f34 <pts_ieee754_expm1+0x230>  // b.pmore
    2e88:	mov	w1, #0x3c8fffff            	// #1016070143
    2e8c:	cmp	w0, w1
    2e90:	b.ls	2f64 <pts_ieee754_expm1+0x260>  // b.plast
    2e94:	fmov	d4, #5.000000000000000000e-01
    2e98:	adrp	x0, 0 <__kernel_tan>
    2e9c:	fmov	d1, #1.000000000000000000e+00
    2ea0:	fmov	d5, #6.000000000000000000e+00
    2ea4:	fmul	d4, d0, d4
    2ea8:	ldr	d18, [x0]
    2eac:	adrp	x0, 0 <__kernel_tan>
    2eb0:	fmov	d0, #3.000000000000000000e+00
    2eb4:	ldr	d17, [x0]
    2eb8:	adrp	x0, 0 <__kernel_tan>
    2ebc:	fmul	d3, d2, d4
    2ec0:	ldr	d16, [x0]
    2ec4:	adrp	x0, 0 <__kernel_tan>
    2ec8:	ldr	d7, [x0]
    2ecc:	adrp	x0, 0 <__kernel_tan>
    2ed0:	fmadd	d17, d3, d18, d17
    2ed4:	ldr	d6, [x0]
    2ed8:	fmadd	d16, d17, d3, d16
    2edc:	fmadd	d7, d16, d3, d7
    2ee0:	fmadd	d6, d3, d7, d6
    2ee4:	fmadd	d1, d3, d6, d1
    2ee8:	fmsub	d0, d4, d1, d0
    2eec:	fmsub	d4, d2, d0, d5
    2ef0:	fsub	d1, d1, d0
    2ef4:	fdiv	d1, d1, d4
    2ef8:	fmul	d1, d1, d3
    2efc:	fnmsub	d1, d2, d1, d3
    2f00:	fsub	d0, d2, d1
    2f04:	ret
    2f08:	adrp	x0, 0 <__kernel_tan>
    2f0c:	fmov	d0, #-1.000000000000000000e+00
    2f10:	ldr	d1, [x0]
    2f14:	fadd	d1, d2, d1
    2f18:	fcmpe	d1, #0.0
    2f1c:	b.mi	2d50 <pts_ieee754_expm1+0x4c>  // b.first
    2f20:	adrp	x0, 0 <__kernel_tan>
    2f24:	fmov	d1, #-5.000000000000000000e-01
    2f28:	ldr	d0, [x0]
    2f2c:	fmul	d0, d2, d0
    2f30:	b	2d78 <pts_ieee754_expm1+0x74>
    2f34:	mov	w1, #0xa2b1                	// #41649
    2f38:	movk	w1, #0x3ff0, lsl #16
    2f3c:	cmp	w0, w1
    2f40:	b.hi	3010 <pts_ieee754_expm1+0x30c>  // b.pmore
    2f44:	adrp	x0, 0 <__kernel_tan>
    2f48:	ldr	d0, [x0]
    2f4c:	tbz	w3, #31, 2f88 <pts_ieee754_expm1+0x284>
    2f50:	adrp	x0, 0 <__kernel_tan>
    2f54:	fadd	d0, d2, d0
    2f58:	mov	w1, #0xffffffff            	// #-1
    2f5c:	ldr	d5, [x0]
    2f60:	b	2d9c <pts_ieee754_expm1+0x98>
    2f64:	adrp	x0, 0 <__kernel_tan>
    2f68:	add	x0, x0, #0x0
    2f6c:	ldr	d1, [x0, #40]
    2f70:	ldr	d0, [x0, #40]
    2f74:	fadd	d1, d1, d2
    2f78:	fadd	d0, d0, d2
    2f7c:	fsub	d1, d1, d0
    2f80:	fsub	d0, d2, d1
    2f84:	ret
    2f88:	adrp	x0, 0 <__kernel_tan>
    2f8c:	fsub	d0, d2, d0
    2f90:	mov	w1, #0x1                   	// #1
    2f94:	ldr	d5, [x0]
    2f98:	b	2d9c <pts_ieee754_expm1+0x98>
    2f9c:	fmov	d1, #-2.500000000000000000e-01
    2fa0:	fcmpe	d2, d1
    2fa4:	b.mi	3040 <pts_ieee754_expm1+0x33c>  // b.first
    2fa8:	fsub	d0, d2, d0
    2fac:	fmov	d1, #2.000000000000000000e+00
    2fb0:	fmadd	d0, d0, d1, d18
    2fb4:	ret
    2fb8:	fsub	d0, d2, d0
    2fbc:	fmov	d1, #-5.000000000000000000e-01
    2fc0:	fmadd	d0, d0, d20, d1
    2fc4:	ret
    2fc8:	fsub	d0, d0, d2
    2fcc:	fsub	d0, d18, d0
    2fd0:	cmp	w1, #0x400
    2fd4:	b.eq	306c <pts_ieee754_expm1+0x368>  // b.none
    2fd8:	fmul	d0, d1, d0
    2fdc:	fmov	d1, #1.000000000000000000e+00
    2fe0:	fsub	d0, d0, d1
    2fe4:	ret
    2fe8:	mov	w0, #0x3ff                 	// #1023
    2fec:	sub	w0, w0, w1
    2ff0:	lsl	w0, w0, #20
    2ff4:	fmov	d3, x0
    2ff8:	shl	d3, d3, #32
    2ffc:	fadd	d0, d0, d3
    3000:	fsub	d0, d2, d0
    3004:	fadd	d0, d0, d18
    3008:	fmul	d0, d0, d1
    300c:	ret
    3010:	adrp	x0, 0 <__kernel_tan>
    3014:	cmp	w3, #0x0
    3018:	fmov	d1, #-5.000000000000000000e-01
    301c:	fmov	d3, #5.000000000000000000e-01
    3020:	ldr	d0, [x0]
    3024:	fcsel	d1, d1, d3, lt	// lt = tstop
    3028:	fmul	d0, d2, d0
    302c:	b	2d78 <pts_ieee754_expm1+0x74>
    3030:	cmp	w3, #0x0
    3034:	fmov	d1, #-1.000000000000000000e+00
    3038:	fcsel	d0, d0, d1, ge	// ge = tcont
    303c:	ret
    3040:	fadd	d20, d2, d20
    3044:	fmov	d1, #-2.000000000000000000e+00
    3048:	fsub	d0, d0, d20
    304c:	fmul	d0, d0, d1
    3050:	ret
    3054:	adrp	x0, 0 <__kernel_tan>
    3058:	add	x0, x0, #0x0
    305c:	ldr	d0, [x0, #40]
    3060:	ldr	d1, [x0, #40]
    3064:	fmul	d0, d0, d1
    3068:	ret
    306c:	fadd	d1, d0, d0
    3070:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
    3074:	fmov	d0, x0
    3078:	fmul	d0, d1, d0
    307c:	b	2fdc <pts_ieee754_expm1+0x2d8>

0000000000003080 <pts_ieee754_cbrt>:
    3080:	fmov	x1, d0
    3084:	fmov	d3, d0
    3088:	mov	w3, #0x7fefffff            	// #2146435071
    308c:	ubfx	x0, x1, #32, #31
    3090:	lsr	x2, x1, #32
    3094:	cmp	w0, w3
    3098:	b.hi	3184 <pts_ieee754_cbrt+0x104>  // b.pmore
    309c:	and	w3, w2, #0x80000000
    30a0:	tst	x2, #0x7ff00000
    30a4:	b.ne	30d8 <pts_ieee754_cbrt+0x58>  // b.any
    30a8:	orr	w0, w0, w1
    30ac:	cbz	w0, 3180 <pts_ieee754_cbrt+0x100>
    30b0:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    30b4:	fmov	d1, x0
    30b8:	mov	w2, #0xaaab                	// #43691
    30bc:	mov	w1, #0x7893                	// #30867
    30c0:	fmul	d1, d0, d1
    30c4:	movk	w2, #0xaaaa, lsl #16
    30c8:	movk	w1, #0x297f, lsl #16
    30cc:	fmov	x0, d1
    30d0:	ubfx	x0, x0, #32, #31
    30d4:	b	30e8 <pts_ieee754_cbrt+0x68>
    30d8:	mov	w2, #0xaaab                	// #43691
    30dc:	mov	w1, #0x7893                	// #30867
    30e0:	movk	w2, #0xaaaa, lsl #16
    30e4:	movk	w1, #0x2a9f, lsl #16
    30e8:	umull	x0, w0, w2
    30ec:	fmov	d4, #2.000000000000000000e+00
    30f0:	lsr	x0, x0, #33
    30f4:	add	w0, w0, w1
    30f8:	orr	w0, w0, w3
    30fc:	fmov	d0, x0
    3100:	adrp	x0, 0 <__kernel_tan>
    3104:	shl	d1, d0, #32
    3108:	ldr	d16, [x0]
    310c:	adrp	x0, 0 <__kernel_tan>
    3110:	ldr	d7, [x0]
    3114:	adrp	x0, 0 <__kernel_tan>
    3118:	fdiv	d17, d1, d3
    311c:	fmul	d0, d1, d1
    3120:	ldr	d6, [x0]
    3124:	adrp	x0, 0 <__kernel_tan>
    3128:	ldr	d5, [x0]
    312c:	adrp	x0, 0 <__kernel_tan>
    3130:	ldr	d2, [x0]
    3134:	mov	x0, #0x80000000            	// #2147483648
    3138:	fmul	d0, d0, d17
    313c:	fmadd	d7, d0, d16, d7
    3140:	fmadd	d5, d0, d6, d5
    3144:	fmul	d6, d0, d0
    3148:	fmul	d6, d6, d0
    314c:	fmadd	d2, d7, d0, d2
    3150:	fmadd	d2, d6, d5, d2
    3154:	fmul	d1, d2, d1
    3158:	fmov	x1, d1
    315c:	add	x0, x1, x0
    3160:	and	x0, x0, #0xffffffffc0000000
    3164:	fmov	d1, x0
    3168:	fmul	d0, d1, d1
    316c:	fdiv	d3, d3, d0
    3170:	fmadd	d0, d1, d4, d3
    3174:	fsub	d3, d3, d1
    3178:	fdiv	d3, d3, d0
    317c:	fmadd	d0, d1, d3, d1
    3180:	ret
    3184:	fadd	d0, d0, d0
    3188:	ret
    318c:	nop

0000000000003190 <pts_ieee754_sin>:
    3190:	sub	sp, sp, #0x30
    3194:	mov	w1, #0x21fb                	// #8699
    3198:	adrp	x0, 0 <__stack_chk_guard>
    319c:	ldr	x0, [x0]
    31a0:	fmov	d1, d0
    31a4:	stp	x29, x30, [sp, #32]
    31a8:	add	x29, sp, #0x20
    31ac:	movk	w1, #0x3fe9, lsl #16
    31b0:	ldr	x2, [x0]
    31b4:	str	x2, [sp, #24]
    31b8:	mov	x2, #0x0                   	// #0
    31bc:	fmov	x0, d0
    31c0:	ubfx	x0, x0, #32, #31
    31c4:	cmp	w0, w1
    31c8:	b.le	32dc <pts_ieee754_sin+0x14c>
    31cc:	mov	w1, #0x7fefffff            	// #2146435071
    31d0:	cmp	w0, w1
    31d4:	b.le	3204 <pts_ieee754_sin+0x74>
    31d8:	fsub	d0, d0, d0
    31dc:	adrp	x0, 0 <__stack_chk_guard>
    31e0:	ldr	x0, [x0]
    31e4:	ldr	x2, [sp, #24]
    31e8:	ldr	x1, [x0]
    31ec:	subs	x2, x2, x1
    31f0:	mov	x1, #0x0                   	// #0
    31f4:	b.ne	3608 <pts_ieee754_sin+0x478>  // b.any
    31f8:	ldp	x29, x30, [sp, #32]
    31fc:	add	sp, sp, #0x30
    3200:	ret
    3204:	add	x0, sp, #0x8
    3208:	bl	ba0 <__ieee754_rem_pio2>
    320c:	and	w0, w0, #0x3
    3210:	cmp	w0, #0x1
    3214:	b.eq	3450 <pts_ieee754_sin+0x2c0>  // b.none
    3218:	cmp	w0, #0x2
    321c:	b.eq	33c8 <pts_ieee754_sin+0x238>  // b.none
    3220:	cbz	w0, 3344 <pts_ieee754_sin+0x1b4>
    3224:	ldp	d1, d7, [sp, #8]
    3228:	mov	w1, #0x3e3fffff            	// #1044381695
    322c:	fmov	x0, d1
    3230:	ubfx	x0, x0, #32, #31
    3234:	cmp	w0, w1
    3238:	b.le	3578 <pts_ieee754_sin+0x3e8>
    323c:	adrp	x1, 0 <__kernel_tan>
    3240:	fmul	d2, d1, d1
    3244:	ldr	d16, [x1]
    3248:	adrp	x1, 0 <__kernel_tan>
    324c:	ldr	d6, [x1]
    3250:	adrp	x1, 0 <__kernel_tan>
    3254:	fmadd	d6, d2, d16, d6
    3258:	ldr	d5, [x1]
    325c:	adrp	x1, 0 <__kernel_tan>
    3260:	ldr	d4, [x1]
    3264:	adrp	x1, 0 <__kernel_tan>
    3268:	ldr	d0, [x1]
    326c:	adrp	x1, 0 <__kernel_tan>
    3270:	ldr	d3, [x1]
    3274:	mov	w1, #0x3332                	// #13106
    3278:	fmadd	d5, d2, d6, d5
    327c:	movk	w1, #0x3fd3, lsl #16
    3280:	fmadd	d4, d2, d5, d4
    3284:	fmadd	d0, d2, d4, d0
    3288:	fmadd	d3, d2, d0, d3
    328c:	fmul	d3, d2, d3
    3290:	cmp	w0, w1
    3294:	b.le	35d0 <pts_ieee754_sin+0x440>
    3298:	mov	w1, #0x3fe90000            	// #1072234496
    329c:	cmp	w0, w1
    32a0:	b.gt	35fc <pts_ieee754_sin+0x46c>
    32a4:	sub	w0, w0, #0x200, lsl #12
    32a8:	fmov	d4, x0
    32ac:	fmov	d0, #1.000000000000000000e+00
    32b0:	shl	d4, d4, #32
    32b4:	fneg	d5, d4
    32b8:	fsub	d0, d0, d4
    32bc:	fmov	d4, #5.000000000000000000e-01
    32c0:	fmul	d1, d1, d7
    32c4:	fnmsub	d1, d2, d3, d1
    32c8:	fmadd	d2, d2, d4, d5
    32cc:	fsub	d1, d2, d1
    32d0:	fsub	d0, d0, d1
    32d4:	fneg	d0, d0
    32d8:	b	31dc <pts_ieee754_sin+0x4c>
    32dc:	mov	w1, #0x3e3fffff            	// #1044381695
    32e0:	cmp	w0, w1
    32e4:	b.gt	32f0 <pts_ieee754_sin+0x160>
    32e8:	fcvtzs	w0, d0
    32ec:	cbz	w0, 31dc <pts_ieee754_sin+0x4c>
    32f0:	adrp	x0, 0 <__kernel_tan>
    32f4:	fmul	d2, d1, d1
    32f8:	ldr	d0, [x0]
    32fc:	adrp	x0, 0 <__kernel_tan>
    3300:	ldr	d7, [x0]
    3304:	adrp	x0, 0 <__kernel_tan>
    3308:	fmadd	d7, d2, d0, d7
    330c:	fmul	d0, d1, d2
    3310:	ldr	d6, [x0]
    3314:	adrp	x0, 0 <__kernel_tan>
    3318:	ldr	d5, [x0]
    331c:	adrp	x0, 0 <__kernel_tan>
    3320:	ldr	d4, [x0]
    3324:	adrp	x0, 0 <__kernel_tan>
    3328:	ldr	d3, [x0]
    332c:	fmadd	d6, d2, d7, d6
    3330:	fmadd	d5, d2, d6, d5
    3334:	fmadd	d4, d2, d5, d4
    3338:	fmadd	d2, d2, d4, d3
    333c:	fmadd	d0, d0, d2, d1
    3340:	b	31dc <pts_ieee754_sin+0x4c>
    3344:	ldp	d0, d2, [sp, #8]
    3348:	mov	w0, #0x3e3fffff            	// #1044381695
    334c:	fmov	x1, d0
    3350:	ubfx	x1, x1, #32, #31
    3354:	cmp	w1, w0
    3358:	b.gt	3364 <pts_ieee754_sin+0x1d4>
    335c:	fcvtzs	w0, d0
    3360:	cbz	w0, 31dc <pts_ieee754_sin+0x4c>
    3364:	adrp	x0, 0 <__kernel_tan>
    3368:	fmul	d3, d0, d0
    336c:	fmov	d17, #5.000000000000000000e-01
    3370:	ldr	d7, [x0]
    3374:	adrp	x0, 0 <__kernel_tan>
    3378:	ldr	d6, [x0]
    337c:	adrp	x0, 0 <__kernel_tan>
    3380:	fmadd	d6, d3, d7, d6
    3384:	fmul	d7, d0, d3
    3388:	ldr	d5, [x0]
    338c:	adrp	x0, 0 <__kernel_tan>
    3390:	ldr	d4, [x0]
    3394:	adrp	x0, 0 <__kernel_tan>
    3398:	ldr	d1, [x0]
    339c:	adrp	x0, 0 <__kernel_tan>
    33a0:	ldr	d16, [x0]
    33a4:	fmadd	d5, d3, d6, d5
    33a8:	fmadd	d4, d3, d5, d4
    33ac:	fmadd	d1, d3, d4, d1
    33b0:	fmul	d1, d7, d1
    33b4:	fnmsub	d1, d2, d17, d1
    33b8:	fnmsub	d2, d3, d1, d2
    33bc:	fmsub	d2, d7, d16, d2
    33c0:	fsub	d0, d0, d2
    33c4:	b	31dc <pts_ieee754_sin+0x4c>
    33c8:	ldp	d0, d2, [sp, #8]
    33cc:	mov	w0, #0x3e3fffff            	// #1044381695
    33d0:	fmov	x1, d0
    33d4:	ubfx	x1, x1, #32, #31
    33d8:	cmp	w1, w0
    33dc:	b.gt	33e8 <pts_ieee754_sin+0x258>
    33e0:	fcvtzs	w0, d0
    33e4:	cbz	w0, 3448 <pts_ieee754_sin+0x2b8>
    33e8:	adrp	x0, 0 <__kernel_tan>
    33ec:	fmul	d3, d0, d0
    33f0:	fmov	d17, #5.000000000000000000e-01
    33f4:	ldr	d7, [x0]
    33f8:	adrp	x0, 0 <__kernel_tan>
    33fc:	ldr	d6, [x0]
    3400:	adrp	x0, 0 <__kernel_tan>
    3404:	fmadd	d6, d3, d7, d6
    3408:	fmul	d7, d0, d3
    340c:	ldr	d5, [x0]
    3410:	adrp	x0, 0 <__kernel_tan>
    3414:	ldr	d4, [x0]
    3418:	adrp	x0, 0 <__kernel_tan>
    341c:	ldr	d1, [x0]
    3420:	adrp	x0, 0 <__kernel_tan>
    3424:	ldr	d16, [x0]
    3428:	fmadd	d5, d3, d6, d5
    342c:	fmadd	d4, d3, d5, d4
    3430:	fmadd	d1, d3, d4, d1
    3434:	fmul	d1, d7, d1
    3438:	fnmsub	d1, d2, d17, d1
    343c:	fnmsub	d2, d3, d1, d2
    3440:	fmsub	d2, d7, d16, d2
    3444:	fsub	d0, d0, d2
    3448:	fneg	d0, d0
    344c:	b	31dc <pts_ieee754_sin+0x4c>
    3450:	ldp	d1, d7, [sp, #8]
    3454:	mov	w1, #0x3e3fffff            	// #1044381695
    3458:	fmov	x0, d1
    345c:	ubfx	x0, x0, #32, #31
    3460:	cmp	w0, w1
    3464:	b.le	3504 <pts_ieee754_sin+0x374>
    3468:	adrp	x1, 0 <__kernel_tan>
    346c:	fmul	d2, d1, d1
    3470:	ldr	d16, [x1]
    3474:	adrp	x1, 0 <__kernel_tan>
    3478:	ldr	d6, [x1]
    347c:	adrp	x1, 0 <__kernel_tan>
    3480:	fmadd	d6, d2, d16, d6
    3484:	ldr	d5, [x1]
    3488:	adrp	x1, 0 <__kernel_tan>
    348c:	ldr	d4, [x1]
    3490:	adrp	x1, 0 <__kernel_tan>
    3494:	ldr	d0, [x1]
    3498:	adrp	x1, 0 <__kernel_tan>
    349c:	ldr	d3, [x1]
    34a0:	mov	w1, #0x3332                	// #13106
    34a4:	fmadd	d5, d2, d6, d5
    34a8:	movk	w1, #0x3fd3, lsl #16
    34ac:	fmadd	d4, d2, d5, d4
    34b0:	fmadd	d0, d2, d4, d0
    34b4:	fmadd	d3, d2, d0, d3
    34b8:	fmul	d3, d2, d3
    34bc:	cmp	w0, w1
    34c0:	b.le	355c <pts_ieee754_sin+0x3cc>
    34c4:	mov	w1, #0x3fe90000            	// #1072234496
    34c8:	cmp	w0, w1
    34cc:	b.gt	35f0 <pts_ieee754_sin+0x460>
    34d0:	sub	w0, w0, #0x200, lsl #12
    34d4:	fmov	d4, x0
    34d8:	fmov	d0, #1.000000000000000000e+00
    34dc:	shl	d4, d4, #32
    34e0:	fneg	d5, d4
    34e4:	fsub	d0, d0, d4
    34e8:	fmov	d4, #5.000000000000000000e-01
    34ec:	fmul	d1, d1, d7
    34f0:	fnmsub	d1, d2, d3, d1
    34f4:	fmadd	d2, d2, d4, d5
    34f8:	fsub	d1, d2, d1
    34fc:	fsub	d0, d0, d1
    3500:	b	31dc <pts_ieee754_sin+0x4c>
    3504:	fcvtzs	w0, d1
    3508:	fmov	d0, #1.000000000000000000e+00
    350c:	cbz	w0, 31dc <pts_ieee754_sin+0x4c>
    3510:	adrp	x0, 0 <__kernel_tan>
    3514:	fmul	d2, d1, d1
    3518:	ldr	d16, [x0]
    351c:	adrp	x0, 0 <__kernel_tan>
    3520:	ldr	d6, [x0]
    3524:	adrp	x0, 0 <__kernel_tan>
    3528:	fmadd	d6, d2, d16, d6
    352c:	ldr	d5, [x0]
    3530:	adrp	x0, 0 <__kernel_tan>
    3534:	ldr	d4, [x0]
    3538:	adrp	x0, 0 <__kernel_tan>
    353c:	ldr	d0, [x0]
    3540:	adrp	x0, 0 <__kernel_tan>
    3544:	ldr	d3, [x0]
    3548:	fmadd	d5, d2, d6, d5
    354c:	fmadd	d4, d2, d5, d4
    3550:	fmadd	d0, d4, d2, d0
    3554:	fmadd	d3, d2, d0, d3
    3558:	fmul	d3, d3, d2
    355c:	fmul	d1, d1, d7
    3560:	fmov	d4, #5.000000000000000000e-01
    3564:	fmsub	d1, d2, d3, d1
    3568:	fmov	d0, #1.000000000000000000e+00
    356c:	fmadd	d1, d2, d4, d1
    3570:	fsub	d0, d0, d1
    3574:	b	31dc <pts_ieee754_sin+0x4c>
    3578:	fcvtzs	w0, d1
    357c:	fmov	d0, #-1.000000000000000000e+00
    3580:	cbz	w0, 31dc <pts_ieee754_sin+0x4c>
    3584:	adrp	x0, 0 <__kernel_tan>
    3588:	fmul	d2, d1, d1
    358c:	ldr	d16, [x0]
    3590:	adrp	x0, 0 <__kernel_tan>
    3594:	ldr	d6, [x0]
    3598:	adrp	x0, 0 <__kernel_tan>
    359c:	fmadd	d6, d2, d16, d6
    35a0:	ldr	d5, [x0]
    35a4:	adrp	x0, 0 <__kernel_tan>
    35a8:	ldr	d4, [x0]
    35ac:	adrp	x0, 0 <__kernel_tan>
    35b0:	ldr	d0, [x0]
    35b4:	adrp	x0, 0 <__kernel_tan>
    35b8:	ldr	d3, [x0]
    35bc:	fmadd	d5, d6, d2, d5
    35c0:	fmadd	d4, d5, d2, d4
    35c4:	fmadd	d0, d4, d2, d0
    35c8:	fmadd	d3, d0, d2, d3
    35cc:	fmul	d3, d3, d2
    35d0:	fmul	d1, d1, d7
    35d4:	fmov	d4, #5.000000000000000000e-01
    35d8:	fmsub	d1, d2, d3, d1
    35dc:	fmov	d0, #1.000000000000000000e+00
    35e0:	fmadd	d1, d2, d4, d1
    35e4:	fsub	d0, d0, d1
    35e8:	fneg	d0, d0
    35ec:	b	31dc <pts_ieee754_sin+0x4c>
    35f0:	fmov	d0, #7.187500000000000000e-01
    35f4:	fmov	d5, #-2.812500000000000000e-01
    35f8:	b	34e8 <pts_ieee754_sin+0x358>
    35fc:	fmov	d0, #7.187500000000000000e-01
    3600:	fmov	d5, #-2.812500000000000000e-01
    3604:	b	32bc <pts_ieee754_sin+0x12c>
    3608:	bl	0 <__stack_chk_fail>
    360c:	nop

0000000000003610 <pts_ieee754_tan>:
    3610:	sub	sp, sp, #0x30
    3614:	fmov	x0, d0
    3618:	adrp	x1, 0 <__stack_chk_guard>
    361c:	ldr	x1, [x1]
    3620:	mov	w2, #0x21fb                	// #8699
    3624:	stp	x29, x30, [sp, #32]
    3628:	add	x29, sp, #0x20
    362c:	movk	w2, #0x3fe9, lsl #16
    3630:	ldr	x3, [x1]
    3634:	str	x3, [sp, #24]
    3638:	mov	x3, #0x0                   	// #0
    363c:	ubfx	x1, x0, #32, #31
    3640:	cmp	w1, w2
    3644:	b.le	36c4 <pts_ieee754_tan+0xb4>
    3648:	mov	w2, #0x7fefffff            	// #2146435071
    364c:	cmp	w1, w2
    3650:	b.le	3684 <pts_ieee754_tan+0x74>
    3654:	adrp	x1, 0 <__stack_chk_guard>
    3658:	ldr	x1, [x1]
    365c:	fsub	d0, d0, d0
    3660:	mov	x0, x1
    3664:	ldr	x2, [sp, #24]
    3668:	ldr	x1, [x0]
    366c:	subs	x2, x2, x1
    3670:	mov	x1, #0x0                   	// #0
    3674:	b.ne	36f4 <pts_ieee754_tan+0xe4>  // b.any
    3678:	ldp	x29, x30, [sp, #32]
    367c:	add	sp, sp, #0x30
    3680:	ret
    3684:	add	x0, sp, #0x8
    3688:	bl	ba0 <__ieee754_rem_pio2>
    368c:	adrp	x1, 0 <__stack_chk_guard>
    3690:	ldr	x1, [x1]
    3694:	ldr	x3, [sp, #24]
    3698:	ldr	x2, [x1]
    369c:	subs	x3, x3, x2
    36a0:	mov	x2, #0x0                   	// #0
    36a4:	b.ne	36f4 <pts_ieee754_tan+0xe4>  // b.any
    36a8:	ldp	x29, x30, [sp, #32]
    36ac:	ubfiz	w0, w0, #1, #1
    36b0:	ldp	d0, d1, [sp, #8]
    36b4:	mov	w1, #0x1                   	// #1
    36b8:	add	sp, sp, #0x30
    36bc:	sub	w0, w1, w0
    36c0:	b	0 <__kernel_tan>
    36c4:	adrp	x0, 0 <__stack_chk_guard>
    36c8:	ldr	x0, [x0]
    36cc:	ldr	x2, [sp, #24]
    36d0:	ldr	x1, [x0]
    36d4:	subs	x2, x2, x1
    36d8:	mov	x1, #0x0                   	// #0
    36dc:	b.ne	36f4 <pts_ieee754_tan+0xe4>  // b.any
    36e0:	ldp	x29, x30, [sp, #32]
    36e4:	movi	d1, #0x0
    36e8:	add	sp, sp, #0x30
    36ec:	mov	w0, #0x1                   	// #1
    36f0:	b	0 <__kernel_tan>
    36f4:	bl	0 <__stack_chk_fail>
    36f8:	nop
    36fc:	nop

0000000000003700 <pts_ieee754_cosh>:
    3700:	fmov	x1, d0
    3704:	stp	x29, x30, [sp, #-16]!
    3708:	mov	w0, #0x2e42                	// #11842
    370c:	mov	x29, sp
    3710:	fmov	d1, d0
    3714:	movk	w0, #0x3fd6, lsl #16
    3718:	ubfx	x4, x1, #32, #31
    371c:	fabs	d0, d0
    3720:	cmp	w4, w0
    3724:	b.le	377c <pts_ieee754_cosh+0x7c>
    3728:	mov	w0, #0x4035ffff            	// #1077280767
    372c:	cmp	w4, w0
    3730:	b.le	37c4 <pts_ieee754_cosh+0xc4>
    3734:	mov	w0, #0x2e41                	// #11841
    3738:	movk	w0, #0x4086, lsl #16
    373c:	cmp	w4, w0
    3740:	b.le	37b0 <pts_ieee754_cosh+0xb0>
    3744:	adrp	x0, 0 <__kernel_tan>
    3748:	ldr	d2, [x0]
    374c:	fcmpe	d0, d2
    3750:	b.ls	37e8 <pts_ieee754_cosh+0xe8>  // b.plast
    3754:	mov	w0, #0x7fefffff            	// #2146435071
    3758:	cmp	w4, w0
    375c:	b.gt	37dc <pts_ieee754_cosh+0xdc>
    3760:	adrp	x0, 0 <__kernel_tan>
    3764:	add	x0, x0, #0x0
    3768:	ldr	d0, [x0, #48]
    376c:	ldr	d1, [x0, #48]
    3770:	fmul	d0, d0, d1
    3774:	ldp	x29, x30, [sp], #16
    3778:	ret
    377c:	bl	2d04 <pts_ieee754_expm1>
    3780:	fmov	d1, d0
    3784:	fmov	d3, #1.000000000000000000e+00
    3788:	mov	w0, #0x3c7fffff            	// #1015021567
    378c:	fadd	d0, d0, d3
    3790:	cmp	w4, w0
    3794:	b.le	3774 <pts_ieee754_cosh+0x74>
    3798:	fmul	d2, d1, d1
    379c:	fadd	d1, d0, d0
    37a0:	ldp	x29, x30, [sp], #16
    37a4:	fdiv	d1, d2, d1
    37a8:	fadd	d0, d1, d3
    37ac:	ret
    37b0:	bl	1ed4 <pts_ieee754_exp>
    37b4:	fmov	d1, #5.000000000000000000e-01
    37b8:	ldp	x29, x30, [sp], #16
    37bc:	fmul	d0, d0, d1
    37c0:	ret
    37c4:	bl	1ed4 <pts_ieee754_exp>
    37c8:	fmov	d2, #5.000000000000000000e-01
    37cc:	ldp	x29, x30, [sp], #16
    37d0:	fdiv	d1, d2, d0
    37d4:	fmadd	d0, d0, d2, d1
    37d8:	ret
    37dc:	fmul	d0, d1, d1
    37e0:	ldp	x29, x30, [sp], #16
    37e4:	ret
    37e8:	fmov	d17, #5.000000000000000000e-01
    37ec:	fmul	d0, d0, d17
    37f0:	bl	1ed4 <pts_ieee754_exp>
    37f4:	fmul	d1, d0, d17
    37f8:	fmul	d0, d1, d0
    37fc:	b	3774 <pts_ieee754_cosh+0x74>

0000000000003800 <pts_ieee754_sinh>:
    3800:	fcmpe	d0, #0.0
    3804:	fabs	d22, d0
    3808:	fmov	d1, #-5.000000000000000000e-01
    380c:	fmov	d2, #5.000000000000000000e-01
    3810:	fmov	d3, #2.200000000000000000e+01
    3814:	stp	x29, x30, [sp, #-16]!
    3818:	fcsel	d23, d1, d2, mi	// mi = first
    381c:	fcmpe	d22, d3
    3820:	mov	x29, sp
    3824:	b.mi	3860 <pts_ieee754_sinh+0x60>  // b.first
    3828:	mov	x0, #0x2e4200000000        	// #50861002719232
    382c:	movk	x0, #0x4086, lsl #48
    3830:	fmov	d1, x0
    3834:	fcmpe	d22, d1
    3838:	b.mi	389c <pts_ieee754_sinh+0x9c>  // b.first
    383c:	adrp	x0, 0 <__kernel_tan>
    3840:	ldr	d1, [x0]
    3844:	fcmpe	d22, d1
    3848:	b.ls	38d0 <pts_ieee754_sinh+0xd0>  // b.plast
    384c:	adrp	x0, 0 <__kernel_tan>
    3850:	ldr	d1, [x0]
    3854:	fmul	d0, d0, d1
    3858:	ldp	x29, x30, [sp], #16
    385c:	ret
    3860:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
    3864:	fmov	d1, x0
    3868:	fcmpe	d22, d1
    386c:	b.mi	3858 <pts_ieee754_sinh+0x58>  // b.first
    3870:	fmov	d0, d22
    3874:	bl	2d04 <pts_ieee754_expm1>
    3878:	fmov	d1, #1.000000000000000000e+00
    387c:	fcmpe	d22, d1
    3880:	b.mi	38b0 <pts_ieee754_sinh+0xb0>  // b.first
    3884:	fadd	d1, d0, d1
    3888:	ldp	x29, x30, [sp], #16
    388c:	fdiv	d1, d0, d1
    3890:	fadd	d0, d1, d0
    3894:	fmul	d0, d0, d23
    3898:	ret
    389c:	fmov	d0, d22
    38a0:	bl	1ed4 <pts_ieee754_exp>
    38a4:	fmul	d0, d0, d23
    38a8:	ldp	x29, x30, [sp], #16
    38ac:	ret
    38b0:	fmul	d2, d0, d0
    38b4:	fadd	d1, d0, d1
    38b8:	fmov	d3, #2.000000000000000000e+00
    38bc:	ldp	x29, x30, [sp], #16
    38c0:	fdiv	d1, d2, d1
    38c4:	fnmsub	d0, d0, d3, d1
    38c8:	fmul	d0, d0, d23
    38cc:	ret
    38d0:	fmul	d0, d22, d2
    38d4:	bl	1ed4 <pts_ieee754_exp>
    38d8:	fmul	d1, d23, d0
    38dc:	fmul	d0, d1, d0
    38e0:	b	3858 <pts_ieee754_sinh+0x58>

00000000000038e4 <pts_ieee754_tanh>:
    38e4:	fmov	x0, d0
    38e8:	fmov	d1, d0
    38ec:	mov	w1, #0x7fefffff            	// #2146435071
    38f0:	lsr	x4, x0, #32
    38f4:	and	w0, w4, #0x7fffffff
    38f8:	cmp	w0, w1
    38fc:	b.le	391c <pts_ieee754_tanh+0x38>
    3900:	fmov	d0, #1.000000000000000000e+00
    3904:	fdiv	d1, d0, d1
    3908:	tbnz	w4, #31, 3914 <pts_ieee754_tanh+0x30>
    390c:	fadd	d0, d1, d0
    3910:	ret
    3914:	fsub	d0, d1, d0
    3918:	ret
    391c:	mov	w1, #0x4035ffff            	// #1077280767
    3920:	cmp	w0, w1
    3924:	b.gt	397c <pts_ieee754_tanh+0x98>
    3928:	stp	x29, x30, [sp, #-16]!
    392c:	mov	w1, #0x3e2fffff            	// #1043333119
    3930:	mov	x29, sp
    3934:	cmp	w0, w1
    3938:	b.le	39a0 <pts_ieee754_tanh+0xbc>
    393c:	fabs	d0, d0
    3940:	mov	w1, #0x3fefffff            	// #1072693247
    3944:	cmp	w0, w1
    3948:	b.le	39bc <pts_ieee754_tanh+0xd8>
    394c:	fadd	d0, d0, d0
    3950:	bl	2d04 <pts_ieee754_expm1>
    3954:	fmov	d2, #2.000000000000000000e+00
    3958:	fmov	d1, #1.000000000000000000e+00
    395c:	fadd	d0, d0, d2
    3960:	fdiv	d2, d2, d0
    3964:	fsub	d0, d1, d2
    3968:	fneg	d1, d0
    396c:	cmp	w4, #0x0
    3970:	fcsel	d0, d1, d0, lt	// lt = tstop
    3974:	ldp	x29, x30, [sp], #16
    3978:	ret
    397c:	adrp	x0, 0 <__kernel_tan>
    3980:	add	x0, x0, #0x0
    3984:	fmov	d0, #1.000000000000000000e+00
    3988:	cmp	w4, #0x0
    398c:	ldr	d1, [x0, #56]
    3990:	fsub	d0, d0, d1
    3994:	fneg	d1, d0
    3998:	fcsel	d0, d1, d0, lt	// lt = tstop
    399c:	ret
    39a0:	adrp	x0, 0 <__kernel_tan>
    39a4:	fmov	d3, #1.000000000000000000e+00
    39a8:	ldr	d2, [x0]
    39ac:	fadd	d2, d0, d2
    39b0:	fcmpe	d2, d3
    39b4:	b.gt	3974 <pts_ieee754_tanh+0x90>
    39b8:	fabs	d0, d0
    39bc:	fmov	d1, #-2.000000000000000000e+00
    39c0:	fmul	d0, d0, d1
    39c4:	bl	2d04 <pts_ieee754_expm1>
    39c8:	fneg	d1, d0
    39cc:	fmov	d2, #2.000000000000000000e+00
    39d0:	fadd	d0, d0, d2
    39d4:	fdiv	d0, d1, d0
    39d8:	b	3968 <pts_ieee754_tanh+0x84>
