
bin/a_clang_off.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <pts_ieee754_acos>:
       0:	fmov	x8, d0
       4:	lsr	x10, x8, #32
       8:	ubfx	x9, x8, #32, #31
       c:	ubfx	w11, w10, #20, #11
      10:	cmp	w11, #0x3ff
      14:	b.cc	4c <pts_ieee754_acos+0x4c>  // b.lo, b.ul, b.last
      18:	movi	d0, #0x0
      1c:	adrp	x11, 0 <pts_ieee754_acos>
      20:	cmp	w10, #0x0
      24:	ldr	d1, [x11]
      28:	mov	w10, #0xc0100000            	// #-1072693248
      2c:	add	w9, w9, w10
      30:	orr	w8, w9, w8
      34:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
      38:	fcsel	d0, d0, d1, gt
      3c:	fmov	d1, x9
      40:	cmp	w8, #0x0
      44:	fcsel	d0, d0, d1, eq	// eq = none
      48:	ret
      4c:	lsr	w10, w9, #21
      50:	cmp	w10, #0x1fe
      54:	b.hi	74 <pts_ieee754_acos+0x74>  // b.pmore
      58:	mov	w8, #0x1                   	// #1
      5c:	movk	w8, #0x3c60, lsl #16
      60:	cmp	w9, w8
      64:	adrp	x8, 0 <pts_ieee754_acos>
      68:	b.cs	130 <pts_ieee754_acos+0x130>  // b.hs, b.nlast
      6c:	ldr	d0, [x8]
      70:	ret
      74:	fmov	d1, #1.000000000000000000e+00
      78:	tbnz	x8, #63, 1c8 <pts_ieee754_acos+0x1c8>
      7c:	fsub	d0, d1, d0
      80:	fmov	d1, #5.000000000000000000e-01
      84:	adrp	x8, 0 <pts_ieee754_acos>
      88:	fmul	d0, d0, d1
      8c:	ldr	d1, [x8]
      90:	adrp	x8, 0 <pts_ieee754_acos>
      94:	ldr	d2, [x8]
      98:	adrp	x8, 0 <pts_ieee754_acos>
      9c:	add	x8, x8, #0x0
      a0:	fmul	d1, d0, d1
      a4:	fadd	d1, d1, d2
      a8:	ld1r	{v2.2d}, [x8]
      ac:	adrp	x8, 0 <pts_ieee754_acos>
      b0:	mov	v2.d[0], v1.d[0]
      b4:	fmul	v1.2d, v2.2d, v0.d[0]
      b8:	ldr	q2, [x8]
      bc:	adrp	x8, 0 <pts_ieee754_acos>
      c0:	ldr	q3, [x8]
      c4:	adrp	x8, 0 <pts_ieee754_acos>
      c8:	fadd	v1.2d, v1.2d, v2.2d
      cc:	fsqrt	d2, d0
      d0:	fmul	v1.2d, v1.2d, v0.d[0]
      d4:	fadd	v1.2d, v1.2d, v3.2d
      d8:	ldr	q3, [x8]
      dc:	adrp	x8, 0 <pts_ieee754_acos>
      e0:	fmul	v1.2d, v1.2d, v0.d[0]
      e4:	fadd	v1.2d, v1.2d, v3.2d
      e8:	ldr	q3, [x8]
      ec:	fmul	v1.2d, v1.2d, v0.d[0]
      f0:	fmov	x8, d2
      f4:	fadd	v1.2d, v1.2d, v3.2d
      f8:	and	x8, x8, #0xffffffff00000000
      fc:	fmul	d3, d0, d1
     100:	mov	d1, v1.d[1]
     104:	fdiv	d1, d3, d1
     108:	fmov	d3, x8
     10c:	fmul	d4, d3, d3
     110:	fsub	d0, d0, d4
     114:	fadd	d4, d2, d3
     118:	fdiv	d0, d0, d4
     11c:	fmul	d1, d2, d1
     120:	fadd	d0, d0, d1
     124:	fadd	d0, d0, d3
     128:	fadd	d0, d0, d0
     12c:	ret
     130:	fmul	d1, d0, d0
     134:	adrp	x9, 0 <pts_ieee754_acos>
     138:	ldr	d2, [x9]
     13c:	adrp	x9, 0 <pts_ieee754_acos>
     140:	ldr	d3, [x9]
     144:	adrp	x9, 0 <pts_ieee754_acos>
     148:	add	x9, x9, #0x0
     14c:	fmul	d2, d1, d2
     150:	fadd	d2, d2, d3
     154:	ld1r	{v3.2d}, [x9]
     158:	adrp	x9, 0 <pts_ieee754_acos>
     15c:	mov	v3.d[0], v2.d[0]
     160:	fmul	v2.2d, v3.2d, v1.d[0]
     164:	ldr	q3, [x9]
     168:	adrp	x9, 0 <pts_ieee754_acos>
     16c:	fadd	v2.2d, v2.2d, v3.2d
     170:	ldr	q3, [x9]
     174:	adrp	x9, 0 <pts_ieee754_acos>
     178:	fmul	v2.2d, v2.2d, v1.d[0]
     17c:	fadd	v2.2d, v2.2d, v3.2d
     180:	ldr	q3, [x9]
     184:	adrp	x9, 0 <pts_ieee754_acos>
     188:	fmul	v2.2d, v2.2d, v1.d[0]
     18c:	fadd	v2.2d, v2.2d, v3.2d
     190:	ldr	q3, [x9]
     194:	adrp	x9, 0 <pts_ieee754_acos>
     198:	fmul	v2.2d, v2.2d, v1.d[0]
     19c:	fadd	v2.2d, v2.2d, v3.2d
     1a0:	fmul	d1, d1, d2
     1a4:	mov	d2, v2.d[1]
     1a8:	fdiv	d1, d1, d2
     1ac:	ldr	d2, [x9]
     1b0:	fmul	d1, d1, d0
     1b4:	fsub	d1, d2, d1
     1b8:	fsub	d0, d1, d0
     1bc:	ldr	d1, [x8]
     1c0:	fadd	d0, d0, d1
     1c4:	ret
     1c8:	fadd	d0, d0, d1
     1cc:	fmov	d1, #5.000000000000000000e-01
     1d0:	adrp	x8, 0 <pts_ieee754_acos>
     1d4:	fmul	d0, d0, d1
     1d8:	ldr	d1, [x8]
     1dc:	adrp	x8, 0 <pts_ieee754_acos>
     1e0:	ldr	d2, [x8]
     1e4:	adrp	x8, 0 <pts_ieee754_acos>
     1e8:	add	x8, x8, #0x0
     1ec:	fmul	d1, d0, d1
     1f0:	fadd	d1, d1, d2
     1f4:	ld1r	{v2.2d}, [x8]
     1f8:	adrp	x8, 0 <pts_ieee754_acos>
     1fc:	mov	v2.d[0], v1.d[0]
     200:	fmul	v1.2d, v2.2d, v0.d[0]
     204:	ldr	q2, [x8]
     208:	adrp	x8, 0 <pts_ieee754_acos>
     20c:	ldr	q3, [x8]
     210:	adrp	x8, 0 <pts_ieee754_acos>
     214:	fadd	v1.2d, v1.2d, v2.2d
     218:	fsqrt	d2, d0
     21c:	fmul	v1.2d, v1.2d, v0.d[0]
     220:	fadd	v1.2d, v1.2d, v3.2d
     224:	ldr	q3, [x8]
     228:	adrp	x8, 0 <pts_ieee754_acos>
     22c:	fmul	v1.2d, v1.2d, v0.d[0]
     230:	fadd	v1.2d, v1.2d, v3.2d
     234:	ldr	q3, [x8]
     238:	adrp	x8, 0 <pts_ieee754_acos>
     23c:	fmul	v1.2d, v1.2d, v0.d[0]
     240:	fadd	v1.2d, v1.2d, v3.2d
     244:	fmul	d0, d0, d1
     248:	mov	d1, v1.d[1]
     24c:	fdiv	d0, d0, d1
     250:	ldr	d1, [x8]
     254:	adrp	x8, 0 <pts_ieee754_acos>
     258:	fmul	d0, d2, d0
     25c:	fadd	d0, d0, d1
     260:	ldr	d1, [x8]
     264:	fadd	d0, d2, d0
     268:	fadd	d0, d0, d0
     26c:	fsub	d0, d1, d0
     270:	ret
     274:	nop
     278:	nop
     27c:	nop

0000000000000280 <pts_ieee754_acosh>:
     280:	fmov	x9, d0
     284:	mov	w10, #0x3ff00000            	// #1072693248
     288:	lsr	x8, x9, #32
     28c:	cmp	w8, w10
     290:	b.ge	2a0 <pts_ieee754_acosh+0x20>  // b.tcont
     294:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     298:	fmov	d0, x8
     29c:	ret
     2a0:	lsr	w10, w8, #20
     2a4:	cmp	w10, #0x41b
     2a8:	b.cc	2bc <pts_ieee754_acosh+0x3c>  // b.lo, b.ul, b.last
     2ac:	cmp	w10, #0x7ff
     2b0:	b.cc	300 <pts_ieee754_acosh+0x80>  // b.lo, b.ul, b.last
     2b4:	fadd	d0, d0, d0
     2b8:	ret
     2bc:	mov	w10, #0xc0100000            	// #-1072693248
     2c0:	add	w10, w8, w10
     2c4:	orr	w9, w10, w9
     2c8:	cbz	w9, 320 <pts_ieee754_acosh+0xa0>
     2cc:	mov	w9, #0x1                   	// #1
     2d0:	movk	w9, #0x4000, lsl #16
     2d4:	cmp	w8, w9
     2d8:	b.cc	328 <pts_ieee754_acosh+0xa8>  // b.lo, b.ul, b.last
     2dc:	fmul	d1, d0, d0
     2e0:	fmov	d2, #-1.000000000000000000e+00
     2e4:	fadd	d1, d1, d2
     2e8:	fsqrt	d1, d1
     2ec:	fadd	d1, d1, d0
     2f0:	fadd	d0, d0, d0
     2f4:	fdiv	d1, d2, d1
     2f8:	fadd	d0, d0, d1
     2fc:	b	360 <pts_ieee754_log>
     300:	stp	x29, x30, [sp, #-16]!
     304:	mov	x29, sp
     308:	bl	360 <pts_ieee754_log>
     30c:	adrp	x8, 0 <pts_ieee754_acos>
     310:	ldr	d1, [x8]
     314:	fadd	d0, d0, d1
     318:	ldp	x29, x30, [sp], #16
     31c:	ret
     320:	movi	d0, #0x0
     324:	ret
     328:	fmov	d1, #-1.000000000000000000e+00
     32c:	fadd	d0, d0, d1
     330:	fadd	d1, d0, d0
     334:	fmul	d2, d0, d0
     338:	fadd	d1, d1, d2
     33c:	fsqrt	d1, d1
     340:	fadd	d0, d0, d1
     344:	b	5c0 <pts_ieee754_log1p>
     348:	nop
     34c:	nop
     350:	nop
     354:	nop
     358:	nop
     35c:	nop

0000000000000360 <pts_ieee754_log>:
     360:	fmov	x9, d0
     364:	lsr	x8, x9, #32
     368:	cmp	w8, #0x100, lsl #12
     36c:	b.ge	39c <pts_ieee754_log+0x3c>  // b.tcont
     370:	and	w8, w8, #0x7fffffff
     374:	orr	w8, w8, w9
     378:	cbz	w8, 430 <pts_ieee754_log+0xd0>
     37c:	tbnz	x9, #63, 510 <pts_ieee754_log+0x1b0>
     380:	mov	x8, #0x4350000000000000    	// #4850376798678024192
     384:	mov	w10, #0xffffffca            	// #-54
     388:	fmov	d1, x8
     38c:	fmul	d0, d0, d1
     390:	fmov	x8, d0
     394:	lsr	x8, x8, #32
     398:	b	3a0 <pts_ieee754_log+0x40>
     39c:	mov	w10, wzr
     3a0:	mov	w9, #0x7ff00000            	// #2146435072
     3a4:	cmp	w8, w9
     3a8:	b.lt	3b4 <pts_ieee754_log+0x54>  // b.tstop
     3ac:	fadd	d0, d0, d0
     3b0:	ret
     3b4:	and	w9, w8, #0xfffff
     3b8:	fmov	x13, d0
     3bc:	fmov	d0, #-1.000000000000000000e+00
     3c0:	add	w11, w9, #0x95, lsl #12
     3c4:	add	w10, w10, w8, asr #20
     3c8:	add	w11, w11, #0xf64
     3cc:	and	w12, w11, #0x100000
     3d0:	and	x13, x13, #0xffffffff
     3d4:	add	w10, w10, w11, lsr #20
     3d8:	bfxil	w12, w8, #0, #20
     3dc:	add	w8, w8, #0x2
     3e0:	and	w8, w8, #0xfffff
     3e4:	eor	w12, w12, #0x3ff00000
     3e8:	cmp	w8, #0x2
     3ec:	sub	w8, w10, #0x3ff
     3f0:	orr	x12, x13, x12, lsl #32
     3f4:	fmov	d1, x12
     3f8:	fadd	d0, d1, d0
     3fc:	b.hi	43c <pts_ieee754_log+0xdc>  // b.pmore
     400:	fcmp	d0, #0.0
     404:	b.ne	51c <pts_ieee754_log+0x1bc>  // b.any
     408:	cbz	w8, 588 <pts_ieee754_log+0x228>
     40c:	scvtf	d0, w8
     410:	adrp	x8, 0 <pts_ieee754_acos>
     414:	adrp	x9, 0 <pts_ieee754_acos>
     418:	ldr	d1, [x8]
     41c:	ldr	d2, [x9]
     420:	fmul	d1, d0, d1
     424:	fmul	d0, d0, d2
     428:	fadd	d0, d1, d0
     42c:	ret
     430:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
     434:	fmov	d0, x8
     438:	ret
     43c:	fmov	d1, #2.000000000000000000e+00
     440:	adrp	x10, 0 <pts_ieee754_acos>
     444:	adrp	x11, 0 <pts_ieee754_acos>
     448:	ldr	d4, [x10]
     44c:	adrp	x10, 0 <pts_ieee754_acos>
     450:	ldr	d7, [x11]
     454:	ldr	d5, [x10]
     458:	adrp	x10, 0 <pts_ieee754_acos>
     45c:	adrp	x11, 0 <pts_ieee754_acos>
     460:	fadd	d1, d0, d1
     464:	fdiv	d1, d0, d1
     468:	fmul	d2, d1, d1
     46c:	fmul	d3, d2, d2
     470:	fmul	d4, d3, d4
     474:	fadd	d4, d4, d5
     478:	ldr	d5, [x10]
     47c:	adrp	x10, 0 <pts_ieee754_acos>
     480:	ldr	d6, [x10]
     484:	adrp	x10, 0 <pts_ieee754_acos>
     488:	fmul	d5, d3, d5
     48c:	fmul	d4, d3, d4
     490:	fadd	d5, d5, d6
     494:	ldr	d6, [x10]
     498:	sub	w10, w9, #0x61, lsl #12
     49c:	sub	w10, w10, #0x47a
     4a0:	fadd	d4, d4, d7
     4a4:	ldr	d7, [x11]
     4a8:	mov	w11, #0xb851                	// #47185
     4ac:	movk	w11, #0x6, lsl #16
     4b0:	fmul	d5, d3, d5
     4b4:	sub	w9, w11, w9
     4b8:	orr	w9, w10, w9
     4bc:	fmul	d4, d3, d4
     4c0:	cmp	w9, #0x1
     4c4:	fadd	d5, d5, d6
     4c8:	fadd	d4, d4, d7
     4cc:	fmul	d3, d3, d5
     4d0:	fmul	d4, d2, d4
     4d4:	scvtf	d2, w8
     4d8:	fadd	d3, d3, d4
     4dc:	b.lt	554 <pts_ieee754_log+0x1f4>  // b.tstop
     4e0:	fmov	d4, #5.000000000000000000e-01
     4e4:	fmul	d4, d0, d4
     4e8:	fmul	d4, d0, d4
     4ec:	cbz	w8, 590 <pts_ieee754_log+0x230>
     4f0:	fadd	d3, d4, d3
     4f4:	adrp	x8, 0 <pts_ieee754_acos>
     4f8:	ldr	d5, [x8]
     4fc:	fmul	d1, d1, d3
     500:	fmul	d3, d2, d5
     504:	fadd	d1, d3, d1
     508:	fsub	d1, d4, d1
     50c:	b	570 <pts_ieee754_log+0x210>
     510:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     514:	fmov	d0, x8
     518:	ret
     51c:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     520:	fmov	d2, #5.000000000000000000e-01
     524:	fmul	d3, d0, d0
     528:	movk	x9, #0xbfd5, lsl #48
     52c:	fmov	d1, x9
     530:	fmul	d1, d0, d1
     534:	fadd	d1, d1, d2
     538:	fmul	d1, d3, d1
     53c:	cbz	w8, 5a4 <pts_ieee754_log+0x244>
     540:	scvtf	d2, w8
     544:	adrp	x8, 0 <pts_ieee754_acos>
     548:	ldr	d3, [x8]
     54c:	fmul	d3, d2, d3
     550:	b	56c <pts_ieee754_log+0x20c>
     554:	cbz	w8, 5ac <pts_ieee754_log+0x24c>
     558:	fsub	d3, d0, d3
     55c:	adrp	x8, 0 <pts_ieee754_acos>
     560:	ldr	d4, [x8]
     564:	fmul	d1, d1, d3
     568:	fmul	d3, d2, d4
     56c:	fadd	d1, d1, d3
     570:	adrp	x8, 0 <pts_ieee754_acos>
     574:	fsub	d0, d1, d0
     578:	ldr	d3, [x8]
     57c:	fmul	d2, d2, d3
     580:	fsub	d0, d2, d0
     584:	ret
     588:	movi	d0, #0x0
     58c:	ret
     590:	fadd	d2, d4, d3
     594:	fmul	d1, d1, d2
     598:	fsub	d1, d1, d4
     59c:	fadd	d0, d0, d1
     5a0:	ret
     5a4:	fsub	d0, d0, d1
     5a8:	ret
     5ac:	fsub	d2, d0, d3
     5b0:	fmul	d1, d1, d2
     5b4:	fsub	d0, d0, d1
     5b8:	ret
     5bc:	nop

00000000000005c0 <pts_ieee754_log1p>:
     5c0:	fmov	x8, d0
     5c4:	mov	w10, #0x8279                	// #33401
     5c8:	movk	w10, #0x3fda, lsl #16
     5cc:	lsr	x9, x8, #32
     5d0:	cmp	w9, w10
     5d4:	b.gt	608 <pts_ieee754_log1p+0x48>
     5d8:	ubfx	x10, x8, #32, #31
     5dc:	lsr	w8, w10, #20
     5e0:	cmp	w8, #0x3ff
     5e4:	b.cc	61c <pts_ieee754_log1p+0x5c>  // b.lo, b.ul, b.last
     5e8:	fmov	d1, #-1.000000000000000000e+00
     5ec:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     5f0:	mov	x9, #0xfff0000000000000    	// #-4503599627370496
     5f4:	fcmp	d0, d1
     5f8:	fmov	d0, x8
     5fc:	fmov	d1, x9
     600:	fcsel	d0, d1, d0, eq	// eq = none
     604:	ret
     608:	lsr	w8, w9, #20
     60c:	cmp	w8, #0x7ff
     610:	b.cc	648 <pts_ieee754_log1p+0x88>  // b.lo, b.ul, b.last
     614:	fadd	d0, d0, d0
     618:	ret
     61c:	lsr	w10, w10, #21
     620:	cmp	w10, #0x1f0
     624:	b.hi	65c <pts_ieee754_log1p+0x9c>  // b.pmore
     628:	mov	x9, #0x4350000000000000    	// #4850376798678024192
     62c:	fmov	d1, x9
     630:	fadd	d1, d0, d1
     634:	fcmp	d1, #0.0
     638:	b.le	820 <pts_ieee754_log1p+0x260>
     63c:	cmp	w8, #0x3c9
     640:	b.cs	820 <pts_ieee754_log1p+0x260>  // b.hs, b.nlast
     644:	ret
     648:	lsr	w10, w9, #22
     64c:	cmp	w10, #0x10c
     650:	b.ls	684 <pts_ieee754_log1p+0xc4>  // b.plast
     654:	movi	d1, #0x0
     658:	b	6bc <pts_ieee754_log1p+0xfc>
     65c:	sub	w8, w9, #0x1
     660:	mov	w9, #0xbec3                	// #48835
     664:	movk	w9, #0xbfd2, lsl #16
     668:	cmp	w8, w9
     66c:	b.hi	684 <pts_ieee754_log1p+0xc4>  // b.pmore
     670:	fmov	d1, #5.000000000000000000e-01
     674:	mov	w8, wzr
     678:	fmul	d1, d0, d1
     67c:	fmul	d2, d1, d0
     680:	b	71c <pts_ieee754_log1p+0x15c>
     684:	fmov	d1, #1.000000000000000000e+00
     688:	fmov	d3, #-1.000000000000000000e+00
     68c:	fadd	d2, d0, d1
     690:	fsub	d4, d0, d2
     694:	fadd	d3, d2, d3
     698:	fmov	x9, d2
     69c:	asr	x8, x9, #52
     6a0:	lsr	x9, x9, #32
     6a4:	fadd	d1, d4, d1
     6a8:	fsub	d0, d0, d3
     6ac:	cmp	w8, #0x3ff
     6b0:	fcsel	d0, d1, d0, gt
     6b4:	fdiv	d1, d0, d2
     6b8:	fmov	d0, d2
     6bc:	fmov	x10, d0
     6c0:	mov	w11, #0xa09d                	// #41117
     6c4:	and	w9, w9, #0xfffff
     6c8:	movk	w11, #0x6, lsl #16
     6cc:	orr	w12, w9, #0x3fe00000
     6d0:	orr	w13, w9, #0x3ff00000
     6d4:	cmp	w9, w11
     6d8:	fmov	d0, #-1.000000000000000000e+00
     6dc:	and	x10, x10, #0xffffffff
     6e0:	csel	w11, w12, w13, hi	// hi = pmore
     6e4:	orr	x10, x10, x11, lsl #32
     6e8:	sub	w11, w8, #0x3fe
     6ec:	sub	w8, w8, #0x3ff
     6f0:	csel	w8, w11, w8, hi	// hi = pmore
     6f4:	fmov	d2, x10
     6f8:	mov	w10, #0x100000              	// #1048576
     6fc:	sub	w10, w10, w9
     700:	lsr	w10, w10, #2
     704:	fadd	d0, d2, d0
     708:	fmov	d2, #5.000000000000000000e-01
     70c:	csel	w9, w10, w9, hi	// hi = pmore
     710:	fmul	d2, d0, d2
     714:	fmul	d2, d0, d2
     718:	cbz	w9, 7d8 <pts_ieee754_log1p+0x218>
     71c:	fmov	d3, #2.000000000000000000e+00
     720:	adrp	x9, 0 <pts_ieee754_acos>
     724:	ldr	d5, [x9]
     728:	adrp	x9, 0 <pts_ieee754_acos>
     72c:	ldr	d6, [x9]
     730:	adrp	x9, 0 <pts_ieee754_acos>
     734:	fadd	d3, d0, d3
     738:	fdiv	d3, d0, d3
     73c:	fmul	d4, d3, d3
     740:	fmul	d5, d4, d5
     744:	fadd	d5, d5, d6
     748:	ldr	d6, [x9]
     74c:	adrp	x9, 0 <pts_ieee754_acos>
     750:	fmul	d5, d4, d5
     754:	fadd	d5, d5, d6
     758:	ldr	d6, [x9]
     75c:	adrp	x9, 0 <pts_ieee754_acos>
     760:	fmul	d5, d4, d5
     764:	fadd	d5, d5, d6
     768:	ldr	d6, [x9]
     76c:	adrp	x9, 0 <pts_ieee754_acos>
     770:	fmul	d5, d4, d5
     774:	fadd	d5, d5, d6
     778:	ldr	d6, [x9]
     77c:	adrp	x9, 0 <pts_ieee754_acos>
     780:	fmul	d5, d4, d5
     784:	fadd	d5, d5, d6
     788:	ldr	d6, [x9]
     78c:	fmul	d5, d4, d5
     790:	fadd	d5, d5, d6
     794:	fmul	d4, d4, d5
     798:	cbz	w8, 80c <pts_ieee754_log1p+0x24c>
     79c:	scvtf	d5, w8
     7a0:	adrp	x8, 0 <pts_ieee754_acos>
     7a4:	fadd	d4, d2, d4
     7a8:	ldr	d6, [x8]
     7ac:	adrp	x8, 0 <pts_ieee754_acos>
     7b0:	fmul	d6, d5, d6
     7b4:	fmul	d3, d3, d4
     7b8:	fadd	d1, d1, d6
     7bc:	fadd	d1, d1, d3
     7c0:	fsub	d1, d2, d1
     7c4:	ldr	d2, [x8]
     7c8:	fmul	d2, d5, d2
     7cc:	fsub	d0, d1, d0
     7d0:	fsub	d0, d2, d0
     7d4:	ret
     7d8:	fcmp	d0, #0.0
     7dc:	b.ne	834 <pts_ieee754_log1p+0x274>  // b.any
     7e0:	cbz	w8, 87c <pts_ieee754_log1p+0x2bc>
     7e4:	scvtf	d0, w8
     7e8:	adrp	x8, 0 <pts_ieee754_acos>
     7ec:	ldr	d2, [x8]
     7f0:	adrp	x8, 0 <pts_ieee754_acos>
     7f4:	ldr	d3, [x8]
     7f8:	fmul	d2, d0, d2
     7fc:	fmul	d0, d0, d3
     800:	fadd	d1, d1, d2
     804:	fadd	d0, d0, d1
     808:	ret
     80c:	fadd	d1, d2, d4
     810:	fmul	d1, d3, d1
     814:	fsub	d1, d2, d1
     818:	fsub	d0, d0, d1
     81c:	ret
     820:	fmul	d1, d0, d0
     824:	fmov	d2, #-5.000000000000000000e-01
     828:	fmul	d1, d1, d2
     82c:	fadd	d0, d0, d1
     830:	ret
     834:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     838:	fmov	d4, #1.000000000000000000e+00
     83c:	movk	x9, #0xbfe5, lsl #48
     840:	fmov	d3, x9
     844:	fmul	d3, d0, d3
     848:	fadd	d3, d3, d4
     84c:	fmul	d2, d2, d3
     850:	cbz	w8, 884 <pts_ieee754_log1p+0x2c4>
     854:	scvtf	d3, w8
     858:	adrp	x8, 0 <pts_ieee754_acos>
     85c:	ldr	d4, [x8]
     860:	adrp	x8, 0 <pts_ieee754_acos>
     864:	fmul	d4, d3, d4
     868:	fadd	d1, d1, d4
     86c:	fsub	d1, d2, d1
     870:	ldr	d2, [x8]
     874:	fmul	d2, d3, d2
     878:	b	7cc <pts_ieee754_log1p+0x20c>
     87c:	movi	d0, #0x0
     880:	ret
     884:	fsub	d0, d0, d2
     888:	ret
     88c:	nop
     890:	nop
     894:	nop
     898:	nop
     89c:	nop

00000000000008a0 <pts_ieee754_asin>:
     8a0:	fmov	x10, d0
     8a4:	lsr	x8, x10, #32
     8a8:	ubfx	x9, x10, #32, #31
     8ac:	ubfx	w11, w8, #20, #11
     8b0:	cmp	w11, #0x3ff
     8b4:	b.cc	8f4 <pts_ieee754_asin+0x54>  // b.lo, b.ul, b.last
     8b8:	adrp	x8, 0 <pts_ieee754_acos>
     8bc:	adrp	x11, 0 <pts_ieee754_acos>
     8c0:	ldr	d1, [x8]
     8c4:	ldr	d2, [x11]
     8c8:	mov	w8, #0xc0100000            	// #-1072693248
     8cc:	add	w8, w9, w8
     8d0:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
     8d4:	fmul	d1, d0, d1
     8d8:	fmul	d0, d0, d2
     8dc:	orr	w8, w8, w10
     8e0:	cmp	w8, #0x0
     8e4:	fadd	d0, d1, d0
     8e8:	fmov	d1, x9
     8ec:	fcsel	d0, d0, d1, eq	// eq = none
     8f0:	ret
     8f4:	lsr	w10, w9, #21
     8f8:	cmp	w10, #0x1fe
     8fc:	b.hi	92c <pts_ieee754_asin+0x8c>  // b.pmore
     900:	lsr	w8, w9, #22
     904:	cmp	w8, #0xf8
     908:	b.hi	a20 <pts_ieee754_asin+0x180>  // b.pmore
     90c:	adrp	x8, 0 <pts_ieee754_acos>
     910:	fmov	d3, #1.000000000000000000e+00
     914:	ldr	d1, [x8]
     918:	fadd	d2, d0, d1
     91c:	movi	d1, #0x0
     920:	fcmp	d2, d3
     924:	b.le	a24 <pts_ieee754_asin+0x184>
     928:	ret
     92c:	fabs	d0, d0
     930:	fmov	d1, #1.000000000000000000e+00
     934:	adrp	x10, 0 <pts_ieee754_acos>
     938:	fmov	d2, #5.000000000000000000e-01
     93c:	adrp	x11, 0 <pts_ieee754_acos>
     940:	ldr	d4, [x11]
     944:	fsub	d0, d1, d0
     948:	fmul	d0, d0, d2
     94c:	ldr	d2, [x10]
     950:	adrp	x10, 0 <pts_ieee754_acos>
     954:	ldr	d3, [x10]
     958:	adrp	x10, 0 <pts_ieee754_acos>
     95c:	fmul	d2, d0, d2
     960:	fadd	d2, d2, d3
     964:	ldr	d3, [x10]
     968:	adrp	x10, 0 <pts_ieee754_acos>
     96c:	fmul	d2, d0, d2
     970:	fadd	d2, d2, d3
     974:	fmul	d3, d0, d4
     978:	ldr	d4, [x10]
     97c:	adrp	x10, 0 <pts_ieee754_acos>
     980:	fmul	d2, d0, d2
     984:	fadd	d3, d3, d4
     988:	ldr	d4, [x10]
     98c:	adrp	x10, 0 <pts_ieee754_acos>
     990:	ldr	d5, [x10]
     994:	adrp	x10, 0 <pts_ieee754_acos>
     998:	fadd	d4, d2, d4
     99c:	fmul	d3, d0, d3
     9a0:	fsqrt	d2, d0
     9a4:	fmul	d4, d0, d4
     9a8:	fadd	d3, d3, d5
     9ac:	ldr	d5, [x10]
     9b0:	adrp	x10, 0 <pts_ieee754_acos>
     9b4:	fadd	d4, d4, d5
     9b8:	fmul	d3, d0, d3
     9bc:	ldr	d5, [x10]
     9c0:	mov	x10, #0x5555555555555555    	// #6148914691236517205
     9c4:	movk	x10, #0x3fc5, lsl #48
     9c8:	fmul	d4, d0, d4
     9cc:	fadd	d3, d3, d5
     9d0:	fmov	d5, x10
     9d4:	mov	w10, #0x3333                	// #13107
     9d8:	movk	w10, #0x3fef, lsl #16
     9dc:	cmp	w9, w10
     9e0:	fadd	d4, d4, d5
     9e4:	fmul	d5, d0, d3
     9e8:	fmul	d3, d0, d4
     9ec:	fadd	d1, d5, d1
     9f0:	b.cc	aa4 <pts_ieee754_asin+0x204>  // b.lo, b.ul, b.last
     9f4:	fdiv	d0, d3, d1
     9f8:	adrp	x9, 0 <pts_ieee754_acos>
     9fc:	ldr	d1, [x9]
     a00:	adrp	x9, 0 <pts_ieee754_acos>
     a04:	fmul	d0, d2, d0
     a08:	fadd	d0, d2, d0
     a0c:	fadd	d0, d0, d0
     a10:	fadd	d0, d0, d1
     a14:	ldr	d1, [x9]
     a18:	fsub	d0, d1, d0
     a1c:	b	af8 <pts_ieee754_asin+0x258>
     a20:	fmul	d1, d0, d0
     a24:	adrp	x8, 0 <pts_ieee754_acos>
     a28:	ldr	d2, [x8]
     a2c:	adrp	x8, 0 <pts_ieee754_acos>
     a30:	ldr	d3, [x8]
     a34:	adrp	x8, 0 <pts_ieee754_acos>
     a38:	add	x8, x8, #0x0
     a3c:	fmul	d2, d1, d2
     a40:	fadd	d2, d2, d3
     a44:	ld1r	{v3.2d}, [x8]
     a48:	adrp	x8, 0 <pts_ieee754_acos>
     a4c:	mov	v3.d[0], v2.d[0]
     a50:	fmul	v2.2d, v3.2d, v1.d[0]
     a54:	ldr	q3, [x8]
     a58:	adrp	x8, 0 <pts_ieee754_acos>
     a5c:	fadd	v2.2d, v2.2d, v3.2d
     a60:	ldr	q3, [x8]
     a64:	adrp	x8, 0 <pts_ieee754_acos>
     a68:	fmul	v2.2d, v2.2d, v1.d[0]
     a6c:	fadd	v2.2d, v2.2d, v3.2d
     a70:	ldr	q3, [x8]
     a74:	adrp	x8, 0 <pts_ieee754_acos>
     a78:	fmul	v2.2d, v2.2d, v1.d[0]
     a7c:	fadd	v2.2d, v2.2d, v3.2d
     a80:	ldr	q3, [x8]
     a84:	fmul	v2.2d, v2.2d, v1.d[0]
     a88:	fadd	v2.2d, v2.2d, v3.2d
     a8c:	fmul	d1, d1, d2
     a90:	mov	d2, v2.d[1]
     a94:	fdiv	d1, d1, d2
     a98:	fmul	d1, d1, d0
     a9c:	fadd	d0, d1, d0
     aa0:	ret
     aa4:	fmov	x9, d2
     aa8:	fdiv	d1, d3, d1
     aac:	and	x9, x9, #0xffffffff00000000
     ab0:	fmov	d4, x9
     ab4:	adrp	x9, 0 <pts_ieee754_acos>
     ab8:	ldr	d3, [x9]
     abc:	adrp	x9, 0 <pts_ieee754_acos>
     ac0:	fmul	d5, d4, d4
     ac4:	fsub	d0, d0, d5
     ac8:	fadd	d5, d2, d4
     acc:	fadd	d2, d2, d2
     ad0:	fdiv	d0, d0, d5
     ad4:	fmul	d1, d2, d1
     ad8:	fadd	d2, d4, d4
     adc:	fadd	d0, d0, d0
     ae0:	fsub	d0, d3, d0
     ae4:	ldr	d3, [x9]
     ae8:	fsub	d2, d3, d2
     aec:	fsub	d0, d0, d1
     af0:	fadd	d0, d2, d0
     af4:	fadd	d0, d0, d3
     af8:	fneg	d1, d0
     afc:	cmp	w8, #0x0
     b00:	fcsel	d0, d0, d1, gt
     b04:	ret
     b08:	nop
     b0c:	nop
     b10:	nop
     b14:	nop
     b18:	nop
     b1c:	nop

0000000000000b20 <pts_ieee754_asinh>:
     b20:	stp	x29, x30, [sp, #-32]!
     b24:	str	x19, [sp, #16]
     b28:	mov	x29, sp
     b2c:	fmov	x8, d0
     b30:	lsr	x19, x8, #32
     b34:	ubfx	w9, w19, #20, #11
     b38:	cmp	w9, #0x7ff
     b3c:	b.cc	b48 <pts_ieee754_asinh+0x28>  // b.lo, b.ul, b.last
     b40:	fadd	d0, d0, d0
     b44:	b	bf8 <pts_ieee754_asinh+0xd8>
     b48:	adrp	x9, 0 <pts_ieee754_acos>
     b4c:	fmov	d2, #1.000000000000000000e+00
     b50:	ubfx	x8, x8, #32, #31
     b54:	ldr	d1, [x9]
     b58:	fadd	d1, d0, d1
     b5c:	fcmp	d1, d2
     b60:	b.le	b70 <pts_ieee754_asinh+0x50>
     b64:	lsr	w9, w8, #20
     b68:	cmp	w9, #0x3e3
     b6c:	b.cc	bf8 <pts_ieee754_asinh+0xd8>  // b.lo, b.ul, b.last
     b70:	mov	w9, #0x1                   	// #1
     b74:	movk	w9, #0x41b0, lsl #16
     b78:	cmp	w8, w9
     b7c:	b.cc	b98 <pts_ieee754_asinh+0x78>  // b.lo, b.ul, b.last
     b80:	fabs	d0, d0
     b84:	bl	360 <pts_ieee754_log>
     b88:	adrp	x8, 0 <pts_ieee754_acos>
     b8c:	ldr	d1, [x8]
     b90:	fadd	d0, d0, d1
     b94:	b	bec <pts_ieee754_asinh+0xcc>
     b98:	fmul	d1, d0, d0
     b9c:	mov	w9, #0x1                   	// #1
     ba0:	movk	w9, #0x4000, lsl #16
     ba4:	cmp	w8, w9
     ba8:	b.cc	bd0 <pts_ieee754_asinh+0xb0>  // b.lo, b.ul, b.last
     bac:	fadd	d1, d1, d2
     bb0:	fabs	d0, d0
     bb4:	fsqrt	d1, d1
     bb8:	fadd	d1, d0, d1
     bbc:	fadd	d0, d0, d0
     bc0:	fdiv	d1, d2, d1
     bc4:	fadd	d0, d0, d1
     bc8:	bl	360 <pts_ieee754_log>
     bcc:	b	bec <pts_ieee754_asinh+0xcc>
     bd0:	fadd	d3, d1, d2
     bd4:	fabs	d0, d0
     bd8:	fsqrt	d3, d3
     bdc:	fadd	d2, d3, d2
     be0:	fdiv	d1, d1, d2
     be4:	fadd	d0, d0, d1
     be8:	bl	5c0 <pts_ieee754_log1p>
     bec:	fneg	d1, d0
     bf0:	cmp	w19, #0x0
     bf4:	fcsel	d0, d0, d1, gt
     bf8:	ldr	x19, [sp, #16]
     bfc:	ldp	x29, x30, [sp], #32
     c00:	ret
     c04:	nop
     c08:	nop
     c0c:	nop
     c10:	nop
     c14:	nop
     c18:	nop
     c1c:	nop

0000000000000c20 <pts_ieee754_atan>:
     c20:	fmov	x8, d0
     c24:	lsr	x9, x8, #32
     c28:	ubfx	x11, x8, #32, #31
     c2c:	ubfx	w10, w9, #20, #11
     c30:	cmp	w10, #0x441
     c34:	b.cc	c5c <pts_ieee754_atan+0x3c>  // b.lo, b.ul, b.last
     c38:	mov	w10, #0x7ff00000            	// #2146435072
     c3c:	cmp	w11, w10
     c40:	b.hi	c54 <pts_ieee754_atan+0x34>  // b.pmore
     c44:	cbz	w8, ccc <pts_ieee754_atan+0xac>
     c48:	mov	w8, #0x7ff00000            	// #2146435072
     c4c:	cmp	w11, w8
     c50:	b.ne	ccc <pts_ieee754_atan+0xac>  // b.any
     c54:	fadd	d0, d0, d0
     c58:	ret
     c5c:	lsr	w9, w11, #18
     c60:	cmp	w9, #0xff6
     c64:	b.hi	c94 <pts_ieee754_atan+0x74>  // b.pmore
     c68:	adrp	x10, 0 <pts_ieee754_acos>
     c6c:	fmov	d2, #1.000000000000000000e+00
     c70:	ldr	d1, [x10]
     c74:	mov	w10, #0xffffffff            	// #-1
     c78:	fadd	d1, d0, d1
     c7c:	fcmp	d1, d2
     c80:	b.le	d44 <pts_ieee754_atan+0x124>
     c84:	lsr	w11, w11, #22
     c88:	cmp	w11, #0xf9
     c8c:	b.cs	d44 <pts_ieee754_atan+0x124>  // b.hs, b.nlast
     c90:	ret
     c94:	fabs	d0, d0
     c98:	mov	w10, #0x3ff2ffff            	// #1072889855
     c9c:	cmp	w11, w10
     ca0:	b.hi	cec <pts_ieee754_atan+0xcc>  // b.pmore
     ca4:	mov	w10, #0x3fe5ffff            	// #1072037887
     ca8:	cmp	w11, w10
     cac:	b.hi	d20 <pts_ieee754_atan+0x100>  // b.pmore
     cb0:	fadd	d1, d0, d0
     cb4:	fmov	d2, #-1.000000000000000000e+00
     cb8:	mov	x10, xzr
     cbc:	fmov	d3, #2.000000000000000000e+00
     cc0:	fadd	d1, d1, d2
     cc4:	fadd	d0, d0, d3
     cc8:	b	d40 <pts_ieee754_atan+0x120>
     ccc:	adrp	x8, 0 <pts_ieee754_acos>
     cd0:	cmp	w9, #0x1
     cd4:	ldr	d0, [x8]
     cd8:	b.lt	e48 <pts_ieee754_atan+0x228>  // b.tstop
     cdc:	adrp	x8, 0 <pts_ieee754_acos>
     ce0:	ldr	d1, [x8]
     ce4:	fadd	d0, d0, d1
     ce8:	ret
     cec:	mov	w10, #0x7fff                	// #32767
     cf0:	movk	w10, #0x4003, lsl #16
     cf4:	cmp	w11, w10
     cf8:	b.hi	d38 <pts_ieee754_atan+0x118>  // b.pmore
     cfc:	fmov	d1, #1.500000000000000000e+00
     d00:	fmov	d2, #-1.500000000000000000e+00
     d04:	mov	w10, #0x2                   	// #2
     d08:	fmov	d3, #1.000000000000000000e+00
     d0c:	fmul	d1, d0, d1
     d10:	fadd	d0, d0, d2
     d14:	fadd	d1, d1, d3
     d18:	fdiv	d0, d0, d1
     d1c:	b	d44 <pts_ieee754_atan+0x124>
     d20:	fmov	d1, #-1.000000000000000000e+00
     d24:	fmov	d2, #1.000000000000000000e+00
     d28:	mov	w10, #0x1                   	// #1
     d2c:	fadd	d1, d0, d1
     d30:	fadd	d0, d0, d2
     d34:	b	d40 <pts_ieee754_atan+0x120>
     d38:	fmov	d1, #-1.000000000000000000e+00
     d3c:	mov	w10, #0x3                   	// #3
     d40:	fdiv	d0, d1, d0
     d44:	fmul	d1, d0, d0
     d48:	adrp	x11, 0 <pts_ieee754_acos>
     d4c:	adrp	x12, 0 <pts_ieee754_acos>
     d50:	ldr	d3, [x11]
     d54:	adrp	x11, 0 <pts_ieee754_acos>
     d58:	ldr	d6, [x12]
     d5c:	ldr	d4, [x11]
     d60:	adrp	x11, 0 <pts_ieee754_acos>
     d64:	adrp	x12, 0 <pts_ieee754_acos>
     d68:	cmp	w9, #0xff6
     d6c:	fmul	d2, d1, d1
     d70:	fmul	d3, d2, d3
     d74:	fadd	d3, d3, d4
     d78:	ldr	d4, [x11]
     d7c:	adrp	x11, 0 <pts_ieee754_acos>
     d80:	ldr	d5, [x11]
     d84:	adrp	x11, 0 <pts_ieee754_acos>
     d88:	fmul	d4, d2, d4
     d8c:	fmul	d3, d2, d3
     d90:	fadd	d4, d4, d6
     d94:	ldr	d6, [x12]
     d98:	adrp	x12, 0 <pts_ieee754_acos>
     d9c:	fadd	d3, d3, d5
     da0:	ldr	d5, [x11]
     da4:	adrp	x11, 0 <pts_ieee754_acos>
     da8:	fmul	d4, d2, d4
     dac:	fmul	d3, d2, d3
     db0:	fadd	d4, d4, d6
     db4:	ldr	d6, [x12]
     db8:	adrp	x12, 0 <pts_ieee754_acos>
     dbc:	fadd	d3, d3, d5
     dc0:	ldr	d5, [x11]
     dc4:	adrp	x11, 0 <pts_ieee754_acos>
     dc8:	fmul	d4, d2, d4
     dcc:	fmul	d3, d2, d3
     dd0:	fadd	d4, d4, d6
     dd4:	ldr	d6, [x12]
     dd8:	fadd	d3, d3, d5
     ddc:	ldr	d5, [x11]
     de0:	fmul	d4, d2, d4
     de4:	fmul	d3, d2, d3
     de8:	fadd	d4, d4, d6
     dec:	fadd	d3, d3, d5
     df0:	fmul	d2, d2, d4
     df4:	fmul	d1, d1, d3
     df8:	fadd	d1, d2, d1
     dfc:	b.hi	e0c <pts_ieee754_atan+0x1ec>  // b.pmore
     e00:	fmul	d1, d0, d1
     e04:	fsub	d0, d0, d1
     e08:	ret
     e0c:	lsl	x9, x10, #3
     e10:	fmul	d1, d0, d1
     e14:	adrp	x10, 0 <pts_ieee754_acos>
     e18:	add	x10, x10, #0x0
     e1c:	cmp	x8, #0x0
     e20:	ldr	d2, [x10, x9]
     e24:	adrp	x10, 0 <pts_ieee754_acos>
     e28:	add	x10, x10, #0x0
     e2c:	fsub	d1, d1, d2
     e30:	fsub	d0, d1, d0
     e34:	ldr	d1, [x10, x9]
     e38:	fsub	d0, d1, d0
     e3c:	fneg	d1, d0
     e40:	fcsel	d0, d1, d0, lt	// lt = tstop
     e44:	ret
     e48:	adrp	x8, 0 <pts_ieee754_acos>
     e4c:	ldr	d1, [x8]
     e50:	fsub	d0, d1, d0
     e54:	ret
     e58:	nop
     e5c:	nop

0000000000000e60 <pts_ieee754_atan2>:
     e60:	stp	x29, x30, [sp, #-32]!
     e64:	str	x19, [sp, #16]
     e68:	mov	x29, sp
     e6c:	fmov	x8, d1
     e70:	mov	w10, #0x7ff00000            	// #2146435072
     e74:	ubfx	x9, x8, #32, #31
     e78:	cmp	w8, #0x0
     e7c:	cset	w11, ne	// ne = any
     e80:	orr	w11, w9, w11
     e84:	cmp	w11, w10
     e88:	b.hi	eb0 <pts_ieee754_atan2+0x50>  // b.pmore
     e8c:	fmov	x10, d0
     e90:	mov	w13, #0x1                   	// #1
     e94:	movk	w13, #0x7ff0, lsl #16
     e98:	ubfx	x11, x10, #32, #31
     e9c:	cmp	w10, #0x0
     ea0:	cset	w12, ne	// ne = any
     ea4:	orr	w12, w11, w12
     ea8:	cmp	w12, w13
     eac:	b.cc	ec0 <pts_ieee754_atan2+0x60>  // b.lo, b.ul, b.last
     eb0:	fadd	d0, d0, d1
     eb4:	ldr	x19, [sp, #16]
     eb8:	ldp	x29, x30, [sp], #32
     ebc:	ret
     ec0:	lsr	x12, x8, #32
     ec4:	mov	w13, #0xc0100000            	// #-1072693248
     ec8:	add	w13, w12, w13
     ecc:	orr	w13, w13, w8
     ed0:	cbz	w13, f28 <pts_ieee754_atan2+0xc8>
     ed4:	lsr	w13, w12, #30
     ed8:	lsr	x12, x10, #32
     edc:	and	w19, w13, #0x2
     ee0:	orr	w13, w11, w10
     ee4:	bfxil	w19, w12, #31, #1
     ee8:	cbz	w13, f34 <pts_ieee754_atan2+0xd4>
     eec:	orr	w13, w9, w8
     ef0:	cbz	w13, f64 <pts_ieee754_atan2+0x104>
     ef4:	mov	w13, #0x7ff00000            	// #2146435072
     ef8:	cmp	w9, w13
     efc:	b.ne	f5c <pts_ieee754_atan2+0xfc>  // b.any
     f00:	cmp	w11, w13
     f04:	b.ne	f8c <pts_ieee754_atan2+0x12c>  // b.any
     f08:	adrp	x8, 0 <pts_ieee754_acos>
     f0c:	cmp	w19, #0x1
     f10:	b.gt	fdc <pts_ieee754_atan2+0x17c>
     f14:	cbnz	w19, 1064 <pts_ieee754_atan2+0x204>
     f18:	adrp	x9, 0 <pts_ieee754_acos>
     f1c:	ldr	d0, [x8]
     f20:	ldr	d1, [x9]
     f24:	b	eb0 <pts_ieee754_atan2+0x50>
     f28:	ldr	x19, [sp, #16]
     f2c:	ldp	x29, x30, [sp], #32
     f30:	b	c20 <pts_ieee754_atan>
     f34:	cmp	w19, #0x2
     f38:	b.cc	eb4 <pts_ieee754_atan2+0x54>  // b.lo, b.ul, b.last
     f3c:	cmp	w19, #0x3
     f40:	b.ne	ffc <pts_ieee754_atan2+0x19c>  // b.any
     f44:	adrp	x8, 0 <pts_ieee754_acos>
     f48:	adrp	x9, 0 <pts_ieee754_acos>
     f4c:	ldr	d0, [x8]
     f50:	ldr	d1, [x9]
     f54:	fsub	d0, d1, d0
     f58:	b	eb4 <pts_ieee754_atan2+0x54>
     f5c:	cmp	w11, w13
     f60:	b.ne	fa8 <pts_ieee754_atan2+0x148>  // b.any
     f64:	adrp	x8, 0 <pts_ieee754_acos>
     f68:	ldr	d0, [x8]
     f6c:	tbnz	x10, #63, f7c <pts_ieee754_atan2+0x11c>
     f70:	adrp	x8, 0 <pts_ieee754_acos>
     f74:	ldr	d1, [x8]
     f78:	b	eb0 <pts_ieee754_atan2+0x50>
     f7c:	adrp	x8, 0 <pts_ieee754_acos>
     f80:	ldr	d1, [x8]
     f84:	fsub	d0, d1, d0
     f88:	b	eb4 <pts_ieee754_atan2+0x54>
     f8c:	cmp	w19, #0x1
     f90:	b.gt	ff4 <pts_ieee754_atan2+0x194>
     f94:	movi	d0, #0x0
     f98:	cbz	w19, eb4 <pts_ieee754_atan2+0x54>
     f9c:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
     fa0:	fmov	d0, x8
     fa4:	b	eb4 <pts_ieee754_atan2+0x54>
     fa8:	sub	w9, w11, w9
     fac:	asr	w9, w9, #20
     fb0:	cmp	w9, #0x3d
     fb4:	b.lt	1010 <pts_ieee754_atan2+0x1b0>  // b.tstop
     fb8:	adrp	x8, 0 <pts_ieee754_acos>
     fbc:	fmov	d0, #5.000000000000000000e-01
     fc0:	lsr	w19, w12, #31
     fc4:	ldr	d1, [x8]
     fc8:	adrp	x8, 0 <pts_ieee754_acos>
     fcc:	fmul	d0, d1, d0
     fd0:	ldr	d1, [x8]
     fd4:	fadd	d2, d0, d1
     fd8:	b	1030 <pts_ieee754_atan2+0x1d0>
     fdc:	cmp	w19, #0x2
     fe0:	b.ne	1078 <pts_ieee754_atan2+0x218>  // b.any
     fe4:	adrp	x9, 0 <pts_ieee754_acos>
     fe8:	ldr	d0, [x8]
     fec:	ldr	d1, [x9]
     ff0:	b	eb0 <pts_ieee754_atan2+0x50>
     ff4:	cmp	w19, #0x2
     ff8:	b.ne	f44 <pts_ieee754_atan2+0xe4>  // b.any
     ffc:	adrp	x8, 0 <pts_ieee754_acos>
    1000:	adrp	x9, 0 <pts_ieee754_acos>
    1004:	ldr	d0, [x8]
    1008:	ldr	d1, [x9]
    100c:	b	eb0 <pts_ieee754_atan2+0x50>
    1010:	tbz	x8, #63, 1020 <pts_ieee754_atan2+0x1c0>
    1014:	movi	d2, #0x0
    1018:	cmn	w9, #0x3c
    101c:	b.lt	1030 <pts_ieee754_atan2+0x1d0>  // b.tstop
    1020:	fdiv	d0, d0, d1
    1024:	fabs	d0, d0
    1028:	bl	c20 <pts_ieee754_atan>
    102c:	fmov	d2, d0
    1030:	cbz	w19, 108c <pts_ieee754_atan2+0x22c>
    1034:	cmp	w19, #0x2
    1038:	b.eq	104c <pts_ieee754_atan2+0x1ec>  // b.none
    103c:	cmp	w19, #0x1
    1040:	b.ne	1094 <pts_ieee754_atan2+0x234>  // b.any
    1044:	fneg	d0, d2
    1048:	b	eb4 <pts_ieee754_atan2+0x54>
    104c:	adrp	x8, 0 <pts_ieee754_acos>
    1050:	ldr	d0, [x8]
    1054:	adrp	x8, 0 <pts_ieee754_acos>
    1058:	ldr	d1, [x8]
    105c:	fsub	d0, d0, d2
    1060:	b	eb0 <pts_ieee754_atan2+0x50>
    1064:	adrp	x9, 0 <pts_ieee754_acos>
    1068:	ldr	d0, [x8]
    106c:	ldr	d1, [x9]
    1070:	fsub	d0, d1, d0
    1074:	b	eb4 <pts_ieee754_atan2+0x54>
    1078:	adrp	x9, 0 <pts_ieee754_acos>
    107c:	ldr	d0, [x8]
    1080:	ldr	d1, [x9]
    1084:	fsub	d0, d1, d0
    1088:	b	eb4 <pts_ieee754_atan2+0x54>
    108c:	fmov	d0, d2
    1090:	b	eb4 <pts_ieee754_atan2+0x54>
    1094:	adrp	x8, 0 <pts_ieee754_acos>
    1098:	ldr	d0, [x8]
    109c:	adrp	x8, 0 <pts_ieee754_acos>
    10a0:	ldr	d1, [x8]
    10a4:	fsub	d0, d2, d0
    10a8:	b	eb0 <pts_ieee754_atan2+0x50>
    10ac:	nop
    10b0:	nop
    10b4:	nop
    10b8:	nop
    10bc:	nop

00000000000010c0 <pts_ieee754_cos>:
    10c0:	sub	sp, sp, #0x20
    10c4:	stp	x29, x30, [sp, #16]
    10c8:	add	x29, sp, #0x10
    10cc:	fmov	x8, d0
    10d0:	mov	w9, #0x21fb                	// #8699
    10d4:	movk	w9, #0x3fe9, lsl #16
    10d8:	ubfx	x8, x8, #32, #31
    10dc:	cmp	w8, w9
    10e0:	b.hi	1198 <pts_ieee754_cos+0xd8>  // b.pmore
    10e4:	lsr	w9, w8, #22
    10e8:	cmp	w9, #0xf8
    10ec:	b.hi	10fc <pts_ieee754_cos+0x3c>  // b.pmore
    10f0:	fcvtzs	w9, d0
    10f4:	fmov	d1, #1.000000000000000000e+00
    10f8:	cbz	w9, 1518 <pts_ieee754_cos+0x458>
    10fc:	fmul	d1, d0, d0
    1100:	adrp	x9, 0 <pts_ieee754_acos>
    1104:	ldr	d2, [x9]
    1108:	adrp	x9, 0 <pts_ieee754_acos>
    110c:	ldr	d3, [x9]
    1110:	adrp	x9, 0 <pts_ieee754_acos>
    1114:	fmul	d2, d1, d2
    1118:	fadd	d2, d2, d3
    111c:	ldr	d3, [x9]
    1120:	adrp	x9, 0 <pts_ieee754_acos>
    1124:	fmul	d2, d1, d2
    1128:	fadd	d2, d2, d3
    112c:	ldr	d3, [x9]
    1130:	adrp	x9, 0 <pts_ieee754_acos>
    1134:	fmul	d2, d1, d2
    1138:	fadd	d2, d2, d3
    113c:	ldr	d3, [x9]
    1140:	adrp	x9, 0 <pts_ieee754_acos>
    1144:	fmul	d2, d1, d2
    1148:	fadd	d2, d2, d3
    114c:	ldr	d3, [x9]
    1150:	mov	w9, #0x3333                	// #13107
    1154:	movk	w9, #0x3fd3, lsl #16
    1158:	cmp	w8, w9
    115c:	fmul	d2, d1, d2
    1160:	fadd	d2, d2, d3
    1164:	fmul	d2, d1, d2
    1168:	b.cs	1280 <pts_ieee754_cos+0x1c0>  // b.hs, b.nlast
    116c:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    1170:	fmul	d2, d1, d2
    1174:	fmov	d3, x8
    1178:	fmul	d0, d0, d3
    117c:	fmov	d3, #-5.000000000000000000e-01
    1180:	fmul	d1, d1, d3
    1184:	fadd	d0, d2, d0
    1188:	fadd	d0, d0, d1
    118c:	fmov	d1, #1.000000000000000000e+00
    1190:	fadd	d1, d0, d1
    1194:	b	1518 <pts_ieee754_cos+0x458>
    1198:	lsr	w8, w8, #20
    119c:	cmp	w8, #0x7ff
    11a0:	b.cc	11ac <pts_ieee754_cos+0xec>  // b.lo, b.ul, b.last
    11a4:	fsub	d1, d0, d0
    11a8:	b	1518 <pts_ieee754_cos+0x458>
    11ac:	mov	x0, sp
    11b0:	bl	1580 <__ieee754_rem_pio2>
    11b4:	ldr	d0, [sp]
    11b8:	and	w8, w0, #0x3
    11bc:	cmp	w8, #0x2
    11c0:	b.eq	1370 <pts_ieee754_cos+0x2b0>  // b.none
    11c4:	cmp	w8, #0x1
    11c8:	b.eq	12d0 <pts_ieee754_cos+0x210>  // b.none
    11cc:	cbnz	w8, 142c <pts_ieee754_cos+0x36c>
    11d0:	fmov	x8, d0
    11d4:	ldr	d2, [sp, #8]
    11d8:	lsr	x9, x8, #32
    11dc:	ubfx	w9, w9, #22, #9
    11e0:	cmp	w9, #0xf8
    11e4:	b.hi	11f4 <pts_ieee754_cos+0x134>  // b.pmore
    11e8:	fcvtzs	w9, d0
    11ec:	fmov	d1, #1.000000000000000000e+00
    11f0:	cbz	w9, 1518 <pts_ieee754_cos+0x458>
    11f4:	fmul	d1, d0, d0
    11f8:	adrp	x9, 0 <pts_ieee754_acos>
    11fc:	ubfx	x8, x8, #32, #31
    1200:	ldr	d3, [x9]
    1204:	adrp	x9, 0 <pts_ieee754_acos>
    1208:	ldr	d4, [x9]
    120c:	adrp	x9, 0 <pts_ieee754_acos>
    1210:	fmul	d3, d1, d3
    1214:	fadd	d3, d3, d4
    1218:	ldr	d4, [x9]
    121c:	adrp	x9, 0 <pts_ieee754_acos>
    1220:	fmul	d3, d1, d3
    1224:	fadd	d3, d3, d4
    1228:	ldr	d4, [x9]
    122c:	adrp	x9, 0 <pts_ieee754_acos>
    1230:	fmul	d3, d1, d3
    1234:	fadd	d3, d3, d4
    1238:	ldr	d4, [x9]
    123c:	adrp	x9, 0 <pts_ieee754_acos>
    1240:	fmul	d3, d1, d3
    1244:	fadd	d3, d3, d4
    1248:	ldr	d4, [x9]
    124c:	mov	w9, #0x3333                	// #13107
    1250:	movk	w9, #0x3fd3, lsl #16
    1254:	cmp	w8, w9
    1258:	fmul	d3, d1, d3
    125c:	fadd	d3, d3, d4
    1260:	fmul	d3, d1, d3
    1264:	b.cs	1528 <pts_ieee754_cos+0x468>  // b.hs, b.nlast
    1268:	fmul	d3, d1, d3
    126c:	fmul	d0, d0, d2
    1270:	fmov	d2, #-5.000000000000000000e-01
    1274:	fmul	d1, d1, d2
    1278:	fsub	d0, d3, d0
    127c:	b	1188 <pts_ieee754_cos+0xc8>
    1280:	mov	w10, #0x3fe90000            	// #1072234496
    1284:	sub	w9, w8, #0x200, lsl #12
    1288:	fmov	d3, #5.000000000000000000e-01
    128c:	cmp	w8, w10
    1290:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    1294:	lsl	x9, x9, #32
    1298:	fmov	d6, x8
    129c:	fmov	d4, #2.812500000000000000e-01
    12a0:	fmov	d5, x9
    12a4:	fmul	d3, d1, d3
    12a8:	fmul	d1, d1, d2
    12ac:	fmul	d0, d0, d6
    12b0:	fcsel	d4, d4, d5, hi	// hi = pmore
    12b4:	fadd	d0, d1, d0
    12b8:	fmov	d1, #1.000000000000000000e+00
    12bc:	fsub	d2, d3, d4
    12c0:	fsub	d1, d1, d4
    12c4:	fsub	d0, d0, d2
    12c8:	fadd	d1, d1, d0
    12cc:	b	1518 <pts_ieee754_cos+0x458>
    12d0:	fmov	x8, d0
    12d4:	ubfx	x8, x8, #54, #9
    12d8:	cmp	x8, #0xf8
    12dc:	b.hi	12e8 <pts_ieee754_cos+0x228>  // b.pmore
    12e0:	fcvtzs	w8, d0
    12e4:	cbz	w8, 1368 <pts_ieee754_cos+0x2a8>
    12e8:	fmul	d1, d0, d0
    12ec:	adrp	x8, 0 <pts_ieee754_acos>
    12f0:	ldr	d5, [sp, #8]
    12f4:	ldr	d2, [x8]
    12f8:	adrp	x8, 0 <pts_ieee754_acos>
    12fc:	ldr	d3, [x8]
    1300:	adrp	x8, 0 <pts_ieee754_acos>
    1304:	fmul	d2, d1, d2
    1308:	fmul	d4, d0, d1
    130c:	fadd	d2, d2, d3
    1310:	ldr	d3, [x8]
    1314:	adrp	x8, 0 <pts_ieee754_acos>
    1318:	fmul	d2, d1, d2
    131c:	fadd	d2, d2, d3
    1320:	ldr	d3, [x8]
    1324:	adrp	x8, 0 <pts_ieee754_acos>
    1328:	fmul	d2, d1, d2
    132c:	fadd	d2, d2, d3
    1330:	ldr	d3, [x8]
    1334:	adrp	x8, 0 <pts_ieee754_acos>
    1338:	fmul	d2, d1, d2
    133c:	fadd	d2, d2, d3
    1340:	fmov	d3, #5.000000000000000000e-01
    1344:	fmul	d3, d5, d3
    1348:	fmul	d2, d4, d2
    134c:	fsub	d2, d3, d2
    1350:	fmul	d1, d1, d2
    1354:	ldr	d2, [x8]
    1358:	fmul	d2, d4, d2
    135c:	fsub	d1, d1, d5
    1360:	fadd	d1, d2, d1
    1364:	fsub	d0, d0, d1
    1368:	fneg	d1, d0
    136c:	b	1518 <pts_ieee754_cos+0x458>
    1370:	fmov	x8, d0
    1374:	ldr	d1, [sp, #8]
    1378:	lsr	x9, x8, #32
    137c:	ubfx	w9, w9, #22, #9
    1380:	cmp	w9, #0xf8
    1384:	b.hi	1394 <pts_ieee754_cos+0x2d4>  // b.pmore
    1388:	fcvtzs	w9, d0
    138c:	fmov	d2, #1.000000000000000000e+00
    1390:	cbz	w9, 1514 <pts_ieee754_cos+0x454>
    1394:	fmul	d2, d0, d0
    1398:	adrp	x9, 0 <pts_ieee754_acos>
    139c:	ubfx	x8, x8, #32, #31
    13a0:	ldr	d3, [x9]
    13a4:	adrp	x9, 0 <pts_ieee754_acos>
    13a8:	ldr	d4, [x9]
    13ac:	adrp	x9, 0 <pts_ieee754_acos>
    13b0:	fmul	d3, d2, d3
    13b4:	fadd	d3, d3, d4
    13b8:	ldr	d4, [x9]
    13bc:	adrp	x9, 0 <pts_ieee754_acos>
    13c0:	fmul	d3, d2, d3
    13c4:	fadd	d3, d3, d4
    13c8:	ldr	d4, [x9]
    13cc:	adrp	x9, 0 <pts_ieee754_acos>
    13d0:	fmul	d3, d2, d3
    13d4:	fadd	d3, d3, d4
    13d8:	ldr	d4, [x9]
    13dc:	adrp	x9, 0 <pts_ieee754_acos>
    13e0:	fmul	d3, d2, d3
    13e4:	fadd	d3, d3, d4
    13e8:	ldr	d4, [x9]
    13ec:	mov	w9, #0x3333                	// #13107
    13f0:	movk	w9, #0x3fd3, lsl #16
    13f4:	cmp	w8, w9
    13f8:	fmul	d3, d2, d3
    13fc:	fadd	d3, d3, d4
    1400:	fmul	d3, d2, d3
    1404:	b.cs	14d0 <pts_ieee754_cos+0x410>  // b.hs, b.nlast
    1408:	fmul	d3, d2, d3
    140c:	fmul	d0, d0, d1
    1410:	fmov	d1, #-5.000000000000000000e-01
    1414:	fmul	d1, d2, d1
    1418:	fsub	d0, d3, d0
    141c:	fadd	d0, d0, d1
    1420:	fmov	d1, #1.000000000000000000e+00
    1424:	fadd	d2, d0, d1
    1428:	b	1514 <pts_ieee754_cos+0x454>
    142c:	fmov	x8, d0
    1430:	ubfx	x8, x8, #54, #9
    1434:	cmp	x8, #0xf8
    1438:	b.hi	144c <pts_ieee754_cos+0x38c>  // b.pmore
    143c:	fcvtzs	w8, d0
    1440:	cbnz	w8, 144c <pts_ieee754_cos+0x38c>
    1444:	fmov	d1, d0
    1448:	b	1518 <pts_ieee754_cos+0x458>
    144c:	fmul	d1, d0, d0
    1450:	adrp	x8, 0 <pts_ieee754_acos>
    1454:	ldr	d5, [sp, #8]
    1458:	ldr	d2, [x8]
    145c:	adrp	x8, 0 <pts_ieee754_acos>
    1460:	ldr	d3, [x8]
    1464:	adrp	x8, 0 <pts_ieee754_acos>
    1468:	fmul	d2, d1, d2
    146c:	fmul	d4, d0, d1
    1470:	fadd	d2, d2, d3
    1474:	ldr	d3, [x8]
    1478:	adrp	x8, 0 <pts_ieee754_acos>
    147c:	fmul	d2, d1, d2
    1480:	fadd	d2, d2, d3
    1484:	ldr	d3, [x8]
    1488:	adrp	x8, 0 <pts_ieee754_acos>
    148c:	fmul	d2, d1, d2
    1490:	fadd	d2, d2, d3
    1494:	ldr	d3, [x8]
    1498:	adrp	x8, 0 <pts_ieee754_acos>
    149c:	fmul	d2, d1, d2
    14a0:	fadd	d2, d2, d3
    14a4:	fmov	d3, #5.000000000000000000e-01
    14a8:	fmul	d3, d5, d3
    14ac:	fmul	d2, d4, d2
    14b0:	fsub	d2, d3, d2
    14b4:	fmul	d1, d1, d2
    14b8:	ldr	d2, [x8]
    14bc:	fmul	d2, d4, d2
    14c0:	fsub	d1, d1, d5
    14c4:	fadd	d1, d2, d1
    14c8:	fsub	d1, d0, d1
    14cc:	b	1518 <pts_ieee754_cos+0x458>
    14d0:	sub	w9, w8, #0x200, lsl #12
    14d4:	fmov	d4, #5.000000000000000000e-01
    14d8:	fmov	d5, #2.812500000000000000e-01
    14dc:	lsl	x9, x9, #32
    14e0:	mov	w10, #0x3fe90000            	// #1072234496
    14e4:	fmul	d0, d0, d1
    14e8:	cmp	w8, w10
    14ec:	fmov	d6, x9
    14f0:	fmul	d4, d2, d4
    14f4:	fmul	d2, d2, d3
    14f8:	fcsel	d5, d5, d6, hi	// hi = pmore
    14fc:	fsub	d0, d2, d0
    1500:	fmov	d2, #1.000000000000000000e+00
    1504:	fsub	d1, d4, d5
    1508:	fsub	d2, d2, d5
    150c:	fsub	d0, d0, d1
    1510:	fadd	d2, d2, d0
    1514:	fneg	d1, d2
    1518:	fmov	d0, d1
    151c:	ldp	x29, x30, [sp, #16]
    1520:	add	sp, sp, #0x20
    1524:	ret
    1528:	sub	w9, w8, #0x200, lsl #12
    152c:	fmov	d4, #5.000000000000000000e-01
    1530:	fmov	d5, #2.812500000000000000e-01
    1534:	lsl	x9, x9, #32
    1538:	fmul	d0, d0, d2
    153c:	mov	w10, #0x3fe90000            	// #1072234496
    1540:	cmp	w8, w10
    1544:	fmov	d6, x9
    1548:	fmul	d4, d1, d4
    154c:	fmul	d1, d1, d3
    1550:	fcsel	d5, d5, d6, hi	// hi = pmore
    1554:	fsub	d0, d1, d0
    1558:	fmov	d1, #1.000000000000000000e+00
    155c:	fsub	d2, d4, d5
    1560:	fsub	d1, d1, d5
    1564:	b	12c4 <pts_ieee754_cos+0x204>
    1568:	nop
    156c:	nop
    1570:	nop
    1574:	nop
    1578:	nop
    157c:	nop

0000000000001580 <__ieee754_rem_pio2>:
    1580:	str	d14, [sp, #-160]!
    1584:	stp	d13, d12, [sp, #16]
    1588:	stp	d11, d10, [sp, #32]
    158c:	stp	d9, d8, [sp, #48]
    1590:	stp	x29, x30, [sp, #64]
    1594:	stp	x28, x27, [sp, #80]
    1598:	stp	x26, x25, [sp, #96]
    159c:	stp	x24, x23, [sp, #112]
    15a0:	stp	x22, x21, [sp, #128]
    15a4:	stp	x20, x19, [sp, #144]
    15a8:	add	x29, sp, #0x40
    15ac:	sub	sp, sp, #0x290
    15b0:	fmov	x6, d0
    15b4:	mov	w9, #0x21fb                	// #8699
    15b8:	mov	x5, x0
    15bc:	movk	w9, #0x3fe9, lsl #16
    15c0:	ubfx	x8, x6, #32, #31
    15c4:	cmp	w8, w9
    15c8:	b.hi	15dc <__ieee754_rem_pio2+0x5c>  // b.pmore
    15cc:	mov	w0, wzr
    15d0:	str	d0, [x5]
    15d4:	str	xzr, [x5, #8]
    15d8:	b	2484 <__ieee754_rem_pio2+0xf04>
    15dc:	mov	w9, #0xd97b                	// #55675
    15e0:	movk	w9, #0x4002, lsl #16
    15e4:	cmp	w8, w9
    15e8:	b.hi	162c <__ieee754_rem_pio2+0xac>  // b.pmore
    15ec:	lsr	x9, x6, #32
    15f0:	cmp	w9, #0x1
    15f4:	b.lt	174c <__ieee754_rem_pio2+0x1cc>  // b.tstop
    15f8:	adrp	x9, 0 <pts_ieee754_acos>
    15fc:	ldr	d1, [x9]
    1600:	mov	w9, #0x21fb                	// #8699
    1604:	movk	w9, #0x3ff9, lsl #16
    1608:	fadd	d0, d0, d1
    160c:	cmp	w8, w9
    1610:	b.ne	1780 <__ieee754_rem_pio2+0x200>  // b.any
    1614:	adrp	x8, 0 <pts_ieee754_acos>
    1618:	ldr	d1, [x8]
    161c:	adrp	x8, 0 <pts_ieee754_acos>
    1620:	fadd	d0, d0, d1
    1624:	ldr	d1, [x8]
    1628:	b	1788 <__ieee754_rem_pio2+0x208>
    162c:	mov	w9, #0x21fb                	// #8699
    1630:	movk	w9, #0x4139, lsl #16
    1634:	cmp	w8, w9
    1638:	b.hi	1730 <__ieee754_rem_pio2+0x1b0>  // b.pmore
    163c:	fabs	d0, d0
    1640:	adrp	x9, 0 <pts_ieee754_acos>
    1644:	fmov	d2, #5.000000000000000000e-01
    1648:	ldr	d1, [x9]
    164c:	adrp	x9, 0 <pts_ieee754_acos>
    1650:	fmul	d1, d0, d1
    1654:	fadd	d1, d1, d2
    1658:	fcvtzs	w0, d1
    165c:	ldr	d1, [x9]
    1660:	adrp	x9, 0 <pts_ieee754_acos>
    1664:	ldr	d3, [x9]
    1668:	scvtf	d2, w0
    166c:	cmp	w0, #0x1f
    1670:	fmul	d1, d2, d1
    1674:	fadd	d0, d0, d1
    1678:	fmul	d1, d2, d3
    167c:	b.gt	1698 <__ieee754_rem_pio2+0x118>
    1680:	adrp	x9, 0 <pts_ieee754_acos>
    1684:	add	x9, x9, #0x0
    1688:	add	x9, x9, w0, sxtw #2
    168c:	ldur	w9, [x9, #-4]
    1690:	cmp	w8, w9
    1694:	b.ne	1724 <__ieee754_rem_pio2+0x1a4>  // b.any
    1698:	fsub	d3, d0, d1
    169c:	lsr	w8, w8, #20
    16a0:	fmov	x9, d3
    16a4:	str	d3, [x5]
    16a8:	ubfx	x9, x9, #52, #11
    16ac:	sub	w9, w8, w9
    16b0:	cmp	w9, #0x11
    16b4:	b.lt	1900 <__ieee754_rem_pio2+0x380>  // b.tstop
    16b8:	adrp	x9, 0 <pts_ieee754_acos>
    16bc:	ldr	d1, [x9]
    16c0:	adrp	x9, 0 <pts_ieee754_acos>
    16c4:	ldr	d3, [x9]
    16c8:	fmul	d1, d2, d1
    16cc:	fmul	d3, d2, d3
    16d0:	fsub	d4, d0, d1
    16d4:	fsub	d0, d0, d4
    16d8:	fsub	d0, d0, d1
    16dc:	fsub	d1, d3, d0
    16e0:	fsub	d3, d4, d1
    16e4:	fmov	x9, d3
    16e8:	str	d3, [x5]
    16ec:	ubfx	x9, x9, #52, #11
    16f0:	sub	w8, w8, w9
    16f4:	cmp	w8, #0x32
    16f8:	b.lt	18fc <__ieee754_rem_pio2+0x37c>  // b.tstop
    16fc:	adrp	x8, 0 <pts_ieee754_acos>
    1700:	ldr	d0, [x8]
    1704:	adrp	x8, 0 <pts_ieee754_acos>
    1708:	fmul	d1, d2, d0
    170c:	fsub	d0, d4, d1
    1710:	fsub	d3, d4, d0
    1714:	ldr	d4, [x8]
    1718:	fmul	d2, d2, d4
    171c:	fsub	d1, d3, d1
    1720:	fsub	d1, d2, d1
    1724:	fsub	d3, d0, d1
    1728:	str	d3, [x5]
    172c:	b	1900 <__ieee754_rem_pio2+0x380>
    1730:	lsr	w10, w8, #20
    1734:	cmp	w10, #0x7ff
    1738:	b.cc	1794 <__ieee754_rem_pio2+0x214>  // b.lo, b.ul, b.last
    173c:	fsub	d0, d0, d0
    1740:	mov	w0, wzr
    1744:	stp	d0, d0, [x5]
    1748:	b	2484 <__ieee754_rem_pio2+0xf04>
    174c:	adrp	x9, 0 <pts_ieee754_acos>
    1750:	ldr	d1, [x9]
    1754:	mov	w9, #0x21fb                	// #8699
    1758:	movk	w9, #0x3ff9, lsl #16
    175c:	fadd	d0, d0, d1
    1760:	cmp	w8, w9
    1764:	b.ne	18a4 <__ieee754_rem_pio2+0x324>  // b.any
    1768:	adrp	x8, 0 <pts_ieee754_acos>
    176c:	ldr	d1, [x8]
    1770:	adrp	x8, 0 <pts_ieee754_acos>
    1774:	fadd	d0, d0, d1
    1778:	ldr	d1, [x8]
    177c:	b	18ac <__ieee754_rem_pio2+0x32c>
    1780:	adrp	x8, 0 <pts_ieee754_acos>
    1784:	ldr	d1, [x8]
    1788:	fadd	d2, d0, d1
    178c:	mov	w0, #0x1                   	// #1
    1790:	b	18b4 <__ieee754_rem_pio2+0x334>
    1794:	sub	w9, w10, #0x416
    1798:	mov	x12, x6
    179c:	mov	x23, xzr
    17a0:	sub	w8, w8, w9, lsl #20
    17a4:	mov	x11, xzr
    17a8:	bfi	x12, x8, #32, #32
    17ac:	fmov	d0, x12
    17b0:	mov	x12, #0x4170000000000000    	// #4715268809856909312
    17b4:	fmov	d2, x12
    17b8:	mov	x12, #0xffffffff00000000    	// #-4294967296
    17bc:	fcvtzs	w8, d0
    17c0:	scvtf	d1, w8
    17c4:	fsub	d0, d0, d1
    17c8:	fcvtzs	w8, d0, #24
    17cc:	fmul	d0, d0, d2
    17d0:	scvtf	d3, w8
    17d4:	add	x8, sp, #0x38
    17d8:	add	x8, x8, #0x10
    17dc:	fsub	d0, d0, d3
    17e0:	stp	d1, d3, [sp, #56]
    17e4:	fmul	d0, d0, d2
    17e8:	str	d0, [sp, #72]
    17ec:	ldr	d0, [x8, x23, lsl #3]
    17f0:	add	x11, x11, x12
    17f4:	sub	x23, x23, #0x1
    17f8:	fcmp	d0, #0.0
    17fc:	b.eq	17ec <__ieee754_rem_pio2+0x26c>  // b.none
    1800:	sub	w8, w10, #0x419
    1804:	mov	w10, #0xaaab                	// #43691
    1808:	mov	w12, #0xffffffe8            	// #-24
    180c:	movk	w10, #0x2aaa, lsl #16
    1810:	stp	x6, x5, [sp, #8]
    1814:	smull	x8, w8, w10
    1818:	lsr	x10, x8, #63
    181c:	asr	x8, x8, #34
    1820:	add	w8, w8, w10
    1824:	add	x10, x23, #0x4
    1828:	madd	w9, w8, w12, w9
    182c:	cmn	w10, #0x3
    1830:	stur	w9, [x29, #-52]
    1834:	adrp	x9, 0 <pts_ieee754_acos>
    1838:	add	x9, x9, #0x0
    183c:	b.lt	18e4 <__ieee754_rem_pio2+0x364>  // b.tstop
    1840:	add	x12, x23, #0x7
    1844:	mov	x13, #0x300000000           	// #12884901888
    1848:	mov	x14, #0x400000000           	// #17179869184
    184c:	bic	w0, w12, w12, asr #31
    1850:	mov	x17, #0x500000000           	// #21474836480
    1854:	add	x16, x11, x13
    1858:	mov	x13, #0x600000000           	// #25769803776
    185c:	sub	w18, w8, w23
    1860:	add	x15, x11, x14
    1864:	add	x14, x11, x17
    1868:	add	x13, x11, x13
    186c:	add	x17, x23, #0x3
    1870:	sub	w18, w18, #0x3
    1874:	add	x0, x0, #0x1
    1878:	add	x1, sp, #0x198
    187c:	b	1898 <__ieee754_rem_pio2+0x318>
    1880:	ldr	w2, [x9, w18, uxtw #2]
    1884:	scvtf	d0, w2
    1888:	subs	x0, x0, #0x1
    188c:	add	w18, w18, #0x1
    1890:	str	d0, [x1], #8
    1894:	b.eq	18c4 <__ieee754_rem_pio2+0x344>  // b.none
    1898:	tbz	w18, #31, 1880 <__ieee754_rem_pio2+0x300>
    189c:	movi	d0, #0x0
    18a0:	b	1888 <__ieee754_rem_pio2+0x308>
    18a4:	adrp	x8, 0 <pts_ieee754_acos>
    18a8:	ldr	d1, [x8]
    18ac:	fadd	d2, d0, d1
    18b0:	mov	w0, #0xffffffff            	// #-1
    18b4:	fsub	d0, d0, d2
    18b8:	fadd	d0, d0, d1
    18bc:	stp	d2, d0, [x5]
    18c0:	b	2484 <__ieee754_rem_pio2+0xf04>
    18c4:	cmp	w10, #0x0
    18c8:	b.le	18e4 <__ieee754_rem_pio2+0x364>
    18cc:	movi	d0, #0x0
    18d0:	and	x24, x10, #0xffffffff
    18d4:	cmp	x24, #0x8
    18d8:	b.cs	1920 <__ieee754_rem_pio2+0x3a0>  // b.hs, b.nlast
    18dc:	mov	x17, xzr
    18e0:	b	19a8 <__ieee754_rem_pio2+0x428>
    18e4:	movi	v1.2d, #0x0
    18e8:	mov	w26, wzr
    18ec:	movi	d0, #0x0
    18f0:	and	x24, x10, #0xffffffff
    18f4:	stp	q1, q1, [sp, #80]
    18f8:	b	1d7c <__ieee754_rem_pio2+0x7fc>
    18fc:	fmov	d0, d4
    1900:	fsub	d0, d0, d3
    1904:	fsub	d0, d0, d1
    1908:	str	d0, [x5, #8]
    190c:	tbz	x6, #63, 2484 <__ieee754_rem_pio2+0xf04>
    1910:	fneg	d1, d3
    1914:	fneg	d0, d0
    1918:	stp	d1, d0, [x5]
    191c:	b	2480 <__ieee754_rem_pio2+0xf00>
    1920:	sub	x18, x24, #0x1
    1924:	sub	w0, w17, w18
    1928:	cmp	w0, w17
    192c:	mov	x17, xzr
    1930:	b.gt	19a8 <__ieee754_rem_pio2+0x428>
    1934:	lsr	x18, x18, #32
    1938:	cbnz	x18, 19a8 <__ieee754_rem_pio2+0x428>
    193c:	and	x18, x10, #0x3
    1940:	add	x0, sp, #0x38
    1944:	add	w1, w23, #0x4
    1948:	sub	x17, x24, x18
    194c:	add	x0, x0, #0x10
    1950:	sub	x1, x1, x18
    1954:	add	x2, sp, #0x198
    1958:	mov	x3, #0xfffffffc00000000    	// #-17179869184
    195c:	add	x4, x2, x16, asr #29
    1960:	ldp	q2, q3, [x0, #-16]
    1964:	subs	x1, x1, #0x4
    1968:	add	x0, x0, #0x20
    196c:	add	x16, x16, x3
    1970:	ldur	q1, [x4, #-8]
    1974:	ext	v1.16b, v1.16b, v1.16b, #8
    1978:	fmul	v1.2d, v2.2d, v1.2d
    197c:	ldur	q2, [x4, #-24]
    1980:	ext	v2.16b, v2.16b, v2.16b, #8
    1984:	mov	d4, v1.d[1]
    1988:	fadd	d0, d0, d1
    198c:	fmul	v1.2d, v3.2d, v2.2d
    1990:	fadd	d0, d0, d4
    1994:	mov	d2, v1.d[1]
    1998:	fadd	d0, d0, d1
    199c:	fadd	d0, d0, d2
    19a0:	b.ne	195c <__ieee754_rem_pio2+0x3dc>  // b.any
    19a4:	cbz	x18, 19ec <__ieee754_rem_pio2+0x46c>
    19a8:	sub	x18, x11, x17, lsl #32
    19ac:	add	x16, sp, #0x38
    19b0:	mov	x0, #0x300000000           	// #12884901888
    19b4:	add	w1, w23, #0x4
    19b8:	add	x16, x16, x17, lsl #3
    19bc:	add	x18, x18, x0
    19c0:	sub	x17, x1, x17
    19c4:	add	x0, sp, #0x198
    19c8:	mov	x1, #0xffffffff00000000    	// #-4294967296
    19cc:	asr	x2, x18, #29
    19d0:	ldr	d1, [x16], #8
    19d4:	subs	x17, x17, #0x1
    19d8:	add	x18, x18, x1
    19dc:	ldr	d2, [x0, x2]
    19e0:	fmul	d1, d1, d2
    19e4:	fadd	d0, d0, d1
    19e8:	b.ne	19cc <__ieee754_rem_pio2+0x44c>  // b.any
    19ec:	movi	d1, #0x0
    19f0:	cmp	x24, #0x8
    19f4:	str	d0, [sp, #80]
    19f8:	b.cs	1a04 <__ieee754_rem_pio2+0x484>  // b.hs, b.nlast
    19fc:	mov	x16, xzr
    1a00:	b	1a8c <__ieee754_rem_pio2+0x50c>
    1a04:	sub	x17, x24, #0x1
    1a08:	sub	w16, w10, w17
    1a0c:	cmp	w16, w10
    1a10:	mov	x16, xzr
    1a14:	b.gt	1a8c <__ieee754_rem_pio2+0x50c>
    1a18:	lsr	x17, x17, #32
    1a1c:	cbnz	x17, 1a8c <__ieee754_rem_pio2+0x50c>
    1a20:	and	x17, x10, #0x3
    1a24:	add	x18, sp, #0x38
    1a28:	add	w0, w23, #0x4
    1a2c:	sub	x16, x24, x17
    1a30:	add	x18, x18, #0x10
    1a34:	sub	x0, x0, x17
    1a38:	add	x1, sp, #0x198
    1a3c:	mov	x2, #0xfffffffc00000000    	// #-17179869184
    1a40:	add	x3, x1, x15, asr #29
    1a44:	ldp	q2, q3, [x18, #-16]
    1a48:	subs	x0, x0, #0x4
    1a4c:	add	x18, x18, #0x20
    1a50:	add	x15, x15, x2
    1a54:	ldur	q0, [x3, #-8]
    1a58:	ext	v0.16b, v0.16b, v0.16b, #8
    1a5c:	fmul	v0.2d, v2.2d, v0.2d
    1a60:	ldur	q2, [x3, #-24]
    1a64:	ext	v2.16b, v2.16b, v2.16b, #8
    1a68:	mov	d4, v0.d[1]
    1a6c:	fadd	d0, d1, d0
    1a70:	fmul	v1.2d, v3.2d, v2.2d
    1a74:	fadd	d0, d0, d4
    1a78:	mov	d2, v1.d[1]
    1a7c:	fadd	d0, d0, d1
    1a80:	fadd	d1, d0, d2
    1a84:	b.ne	1a40 <__ieee754_rem_pio2+0x4c0>  // b.any
    1a88:	cbz	x17, 1ad0 <__ieee754_rem_pio2+0x550>
    1a8c:	sub	x17, x11, x16, lsl #32
    1a90:	add	x15, sp, #0x38
    1a94:	mov	x18, #0x400000000           	// #17179869184
    1a98:	add	w0, w23, #0x4
    1a9c:	add	x15, x15, x16, lsl #3
    1aa0:	add	x17, x17, x18
    1aa4:	sub	x16, x0, x16
    1aa8:	add	x18, sp, #0x198
    1aac:	mov	x0, #0xffffffff00000000    	// #-4294967296
    1ab0:	asr	x1, x17, #29
    1ab4:	ldr	d0, [x15], #8
    1ab8:	subs	x16, x16, #0x1
    1abc:	add	x17, x17, x0
    1ac0:	ldr	d2, [x18, x1]
    1ac4:	fmul	d0, d0, d2
    1ac8:	fadd	d1, d1, d0
    1acc:	b.ne	1ab0 <__ieee754_rem_pio2+0x530>  // b.any
    1ad0:	movi	d0, #0x0
    1ad4:	cmp	x24, #0xa
    1ad8:	str	d1, [sp, #88]
    1adc:	b.cs	1ae8 <__ieee754_rem_pio2+0x568>  // b.hs, b.nlast
    1ae0:	mov	x15, xzr
    1ae4:	b	1b74 <__ieee754_rem_pio2+0x5f4>
    1ae8:	sub	x16, x24, #0x1
    1aec:	add	w15, w23, #0x5
    1af0:	sub	w17, w15, w16
    1af4:	cmp	w17, w15
    1af8:	mov	x15, xzr
    1afc:	b.gt	1b74 <__ieee754_rem_pio2+0x5f4>
    1b00:	lsr	x16, x16, #32
    1b04:	cbnz	x16, 1b74 <__ieee754_rem_pio2+0x5f4>
    1b08:	and	x16, x10, #0x3
    1b0c:	add	x17, sp, #0x38
    1b10:	add	w18, w23, #0x4
    1b14:	sub	x15, x24, x16
    1b18:	add	x17, x17, #0x10
    1b1c:	sub	x18, x18, x16
    1b20:	add	x0, sp, #0x198
    1b24:	mov	x1, #0xfffffffc00000000    	// #-17179869184
    1b28:	add	x2, x0, x14, asr #29
    1b2c:	ldp	q2, q3, [x17, #-16]
    1b30:	subs	x18, x18, #0x4
    1b34:	add	x17, x17, #0x20
    1b38:	add	x14, x14, x1
    1b3c:	ldur	q1, [x2, #-8]
    1b40:	ext	v1.16b, v1.16b, v1.16b, #8
    1b44:	fmul	v1.2d, v2.2d, v1.2d
    1b48:	ldur	q2, [x2, #-24]
    1b4c:	ext	v2.16b, v2.16b, v2.16b, #8
    1b50:	mov	d4, v1.d[1]
    1b54:	fadd	d0, d0, d1
    1b58:	fmul	v1.2d, v3.2d, v2.2d
    1b5c:	fadd	d0, d0, d4
    1b60:	mov	d2, v1.d[1]
    1b64:	fadd	d0, d0, d1
    1b68:	fadd	d0, d0, d2
    1b6c:	b.ne	1b28 <__ieee754_rem_pio2+0x5a8>  // b.any
    1b70:	cbz	x16, 1bb8 <__ieee754_rem_pio2+0x638>
    1b74:	sub	x16, x11, x15, lsl #32
    1b78:	add	x14, sp, #0x38
    1b7c:	mov	x17, #0x500000000           	// #21474836480
    1b80:	add	w18, w23, #0x4
    1b84:	add	x14, x14, x15, lsl #3
    1b88:	add	x16, x16, x17
    1b8c:	sub	x15, x18, x15
    1b90:	add	x17, sp, #0x198
    1b94:	mov	x18, #0xffffffff00000000    	// #-4294967296
    1b98:	asr	x0, x16, #29
    1b9c:	ldr	d1, [x14], #8
    1ba0:	subs	x15, x15, #0x1
    1ba4:	add	x16, x16, x18
    1ba8:	ldr	d2, [x17, x0]
    1bac:	fmul	d1, d1, d2
    1bb0:	fadd	d0, d0, d1
    1bb4:	b.ne	1b98 <__ieee754_rem_pio2+0x618>  // b.any
    1bb8:	movi	d1, #0x0
    1bbc:	cmp	x24, #0xa
    1bc0:	str	d0, [sp, #96]
    1bc4:	b.cs	1bd0 <__ieee754_rem_pio2+0x650>  // b.hs, b.nlast
    1bc8:	mov	x14, xzr
    1bcc:	b	1c5c <__ieee754_rem_pio2+0x6dc>
    1bd0:	sub	x15, x24, #0x1
    1bd4:	add	w14, w23, #0x6
    1bd8:	sub	w16, w14, w15
    1bdc:	cmp	w16, w14
    1be0:	mov	x14, xzr
    1be4:	b.gt	1c5c <__ieee754_rem_pio2+0x6dc>
    1be8:	lsr	x15, x15, #32
    1bec:	cbnz	x15, 1c5c <__ieee754_rem_pio2+0x6dc>
    1bf0:	and	x15, x10, #0x3
    1bf4:	add	x16, sp, #0x38
    1bf8:	add	w17, w23, #0x4
    1bfc:	sub	x14, x24, x15
    1c00:	add	x16, x16, #0x10
    1c04:	sub	x17, x17, x15
    1c08:	add	x18, sp, #0x198
    1c0c:	mov	x0, #0xfffffffc00000000    	// #-17179869184
    1c10:	add	x1, x18, x13, asr #29
    1c14:	ldp	q2, q3, [x16, #-16]
    1c18:	subs	x17, x17, #0x4
    1c1c:	add	x16, x16, #0x20
    1c20:	add	x13, x13, x0
    1c24:	ldur	q0, [x1, #-8]
    1c28:	ext	v0.16b, v0.16b, v0.16b, #8
    1c2c:	fmul	v0.2d, v2.2d, v0.2d
    1c30:	ldur	q2, [x1, #-24]
    1c34:	ext	v2.16b, v2.16b, v2.16b, #8
    1c38:	mov	d4, v0.d[1]
    1c3c:	fadd	d0, d1, d0
    1c40:	fmul	v1.2d, v3.2d, v2.2d
    1c44:	fadd	d0, d0, d4
    1c48:	mov	d2, v1.d[1]
    1c4c:	fadd	d0, d0, d1
    1c50:	fadd	d1, d0, d2
    1c54:	b.ne	1c10 <__ieee754_rem_pio2+0x690>  // b.any
    1c58:	cbz	x15, 1ca0 <__ieee754_rem_pio2+0x720>
    1c5c:	sub	x13, x11, x14, lsl #32
    1c60:	add	x11, sp, #0x38
    1c64:	mov	x15, #0x600000000           	// #25769803776
    1c68:	add	w16, w23, #0x4
    1c6c:	add	x11, x11, x14, lsl #3
    1c70:	add	x13, x13, x15
    1c74:	sub	x14, x16, x14
    1c78:	add	x15, sp, #0x198
    1c7c:	mov	x16, #0xffffffff00000000    	// #-4294967296
    1c80:	asr	x17, x13, #29
    1c84:	ldr	d0, [x11], #8
    1c88:	subs	x14, x14, #0x1
    1c8c:	add	x13, x13, x16
    1c90:	ldr	d2, [x15, x17]
    1c94:	fmul	d0, d0, d2
    1c98:	fadd	d1, d1, d0
    1c9c:	b.ne	1c80 <__ieee754_rem_pio2+0x700>  // b.any
    1ca0:	movi	d0, #0x0
    1ca4:	cmp	x24, #0x8
    1ca8:	str	d1, [sp, #104]
    1cac:	b.cs	1cb8 <__ieee754_rem_pio2+0x738>  // b.hs, b.nlast
    1cb0:	mov	x11, xzr
    1cb4:	b	1d40 <__ieee754_rem_pio2+0x7c0>
    1cb8:	sub	x13, x24, #0x1
    1cbc:	sub	w11, w12, w13
    1cc0:	cmp	w11, w12
    1cc4:	mov	x11, xzr
    1cc8:	b.gt	1d40 <__ieee754_rem_pio2+0x7c0>
    1ccc:	lsr	x12, x13, #32
    1cd0:	cbnz	x12, 1d40 <__ieee754_rem_pio2+0x7c0>
    1cd4:	and	x10, x10, #0x3
    1cd8:	add	x12, sp, #0x38
    1cdc:	add	w13, w23, #0x4
    1ce0:	sub	x11, x24, x10
    1ce4:	add	x12, x12, #0x10
    1ce8:	sub	x13, x13, x10
    1cec:	add	w14, w23, #0x7
    1cf0:	add	x15, sp, #0x198
    1cf4:	add	x16, x15, w14, sxtw #3
    1cf8:	ldp	q2, q3, [x12, #-16]
    1cfc:	sub	x13, x13, #0x4
    1d00:	add	x12, x12, #0x20
    1d04:	sub	w14, w14, #0x4
    1d08:	ldur	q1, [x16, #-8]
    1d0c:	ext	v1.16b, v1.16b, v1.16b, #8
    1d10:	fmul	v1.2d, v2.2d, v1.2d
    1d14:	ldur	q2, [x16, #-24]
    1d18:	ext	v2.16b, v2.16b, v2.16b, #8
    1d1c:	mov	d4, v1.d[1]
    1d20:	fadd	d0, d0, d1
    1d24:	fmul	v1.2d, v3.2d, v2.2d
    1d28:	fadd	d0, d0, d4
    1d2c:	mov	d2, v1.d[1]
    1d30:	fadd	d0, d0, d1
    1d34:	fadd	d0, d0, d2
    1d38:	cbnz	x13, 1cf4 <__ieee754_rem_pio2+0x774>
    1d3c:	cbz	x10, 1d78 <__ieee754_rem_pio2+0x7f8>
    1d40:	add	x10, sp, #0x38
    1d44:	add	w12, w23, #0x4
    1d48:	sub	w13, w23, w11
    1d4c:	add	x10, x10, x11, lsl #3
    1d50:	sub	x11, x12, x11
    1d54:	add	w12, w13, #0x7
    1d58:	add	x13, sp, #0x198
    1d5c:	ldr	d1, [x10], #8
    1d60:	ldr	d2, [x13, w12, sxtw #3]
    1d64:	sub	x11, x11, #0x1
    1d68:	sub	w12, w12, #0x1
    1d6c:	fmul	d1, d1, d2
    1d70:	fadd	d0, d0, d1
    1d74:	cbnz	x11, 1d5c <__ieee754_rem_pio2+0x7dc>
    1d78:	mov	w26, #0x1                   	// #1
    1d7c:	ldur	w12, [x29, #-52]
    1d80:	add	x22, x9, w8, sxtw #2
    1d84:	sub	x8, x29, #0x98
    1d88:	mov	w10, #0x30                  	// #48
    1d8c:	sub	x9, x8, #0x10
    1d90:	mov	w11, #0x2f                  	// #47
    1d94:	sub	w10, w10, w12
    1d98:	str	x9, [sp, #24]
    1d9c:	add	x9, sp, #0x38
    1da0:	sub	x28, x8, #0x4
    1da4:	add	x21, sp, #0x198
    1da8:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1dac:	stur	w10, [x29, #-56]
    1db0:	sub	w10, w11, w12
    1db4:	add	x15, x9, #0x10
    1db8:	sub	x16, x21, #0x8
    1dbc:	fmov	d13, x8
    1dc0:	mov	x8, #0xc170000000000000    	// #-4508103226997866496
    1dc4:	sub	w25, w12, #0x18
    1dc8:	str	d0, [sp, #112]
    1dcc:	and	x19, x24, #0xfffffffc
    1dd0:	str	w10, [sp, #36]
    1dd4:	fmov	d9, #1.250000000000000000e-01
    1dd8:	fmov	d10, #-8.000000000000000000e+00
    1ddc:	fmov	d11, #1.000000000000000000e+00
    1de0:	fmov	d12, #5.000000000000000000e-01
    1de4:	fmov	d14, x8
    1de8:	add	x20, sp, #0x50
    1dec:	mov	w8, #0x4                   	// #4
    1df0:	stp	x16, x15, [sp, #40]
    1df4:	b	1dfc <__ieee754_rem_pio2+0x87c>
    1df8:	ldr	d0, [x20, x8, lsl #3]
    1dfc:	mov	w27, w8
    1e00:	sub	x9, x29, #0x98
    1e04:	sub	x8, x27, #0x1
    1e08:	fmul	d1, d0, d13
    1e0c:	fcvtzs	w10, d1
    1e10:	scvtf	d1, w10
    1e14:	fmul	d2, d1, d14
    1e18:	fadd	d0, d0, d2
    1e1c:	ldr	d2, [x20, x8, lsl #3]
    1e20:	sub	x8, x8, #0x1
    1e24:	cmn	x8, #0x1
    1e28:	fcvtzs	w10, d0
    1e2c:	fadd	d0, d2, d1
    1e30:	str	w10, [x9], #4
    1e34:	b.ne	1e08 <__ieee754_rem_pio2+0x888>  // b.any
    1e38:	mov	w0, w25
    1e3c:	bl	0 <scalbn>
    1e40:	fmul	d1, d0, d9
    1e44:	ldur	w8, [x29, #-52]
    1e48:	cmp	w8, #0x19
    1e4c:	frintm	d1, d1
    1e50:	fmul	d1, d1, d10
    1e54:	fadd	d0, d0, d1
    1e58:	fcvtzs	w13, d0
    1e5c:	scvtf	d1, w13
    1e60:	fsub	d8, d0, d1
    1e64:	b.lt	1e98 <__ieee754_rem_pio2+0x918>  // b.tstop
    1e68:	sub	x8, x29, #0x98
    1e6c:	ldur	w11, [x29, #-56]
    1e70:	add	x8, x8, w27, sxtw #2
    1e74:	ldur	w9, [x8, #-4]
    1e78:	asr	w10, w9, w11
    1e7c:	lsl	w11, w10, w11
    1e80:	add	w13, w10, w13
    1e84:	sub	w9, w9, w11
    1e88:	ldr	w11, [sp, #36]
    1e8c:	stur	w9, [x8, #-4]
    1e90:	asr	w17, w9, w11
    1e94:	b	1ec4 <__ieee754_rem_pio2+0x944>
    1e98:	cbz	w25, 1eb4 <__ieee754_rem_pio2+0x934>
    1e9c:	fcmp	d8, d12
    1ea0:	ldp	x16, x15, [sp, #40]
    1ea4:	add	x14, sp, #0x38
    1ea8:	b.ge	1ed8 <__ieee754_rem_pio2+0x958>  // b.tcont
    1eac:	mov	w17, wzr
    1eb0:	b	1fa0 <__ieee754_rem_pio2+0xa20>
    1eb4:	sub	x8, x29, #0x98
    1eb8:	add	x8, x8, w27, sxtw #2
    1ebc:	ldur	w8, [x8, #-4]
    1ec0:	asr	w17, w8, #23
    1ec4:	ldp	x16, x15, [sp, #40]
    1ec8:	add	x14, sp, #0x38
    1ecc:	cmp	w17, #0x1
    1ed0:	b.ge	1edc <__ieee754_rem_pio2+0x95c>  // b.tcont
    1ed4:	b	1fa0 <__ieee754_rem_pio2+0xa20>
    1ed8:	mov	w17, #0x2                   	// #2
    1edc:	mov	w11, wzr
    1ee0:	sub	x9, x29, #0x98
    1ee4:	mov	x10, x27
    1ee8:	b	1f0c <__ieee754_rem_pio2+0x98c>
    1eec:	mov	w11, #0xffffff              	// #16777215
    1ef0:	sub	w11, w11, w12
    1ef4:	mov	w8, wzr
    1ef8:	str	w11, [x9]
    1efc:	mov	w11, #0x1                   	// #1
    1f00:	subs	x10, x10, #0x1
    1f04:	add	x9, x9, #0x4
    1f08:	b.eq	1f2c <__ieee754_rem_pio2+0x9ac>  // b.none
    1f0c:	ldr	w12, [x9]
    1f10:	cbnz	w11, 1eec <__ieee754_rem_pio2+0x96c>
    1f14:	cbz	w12, 1f20 <__ieee754_rem_pio2+0x9a0>
    1f18:	mov	w11, #0x1000000             	// #16777216
    1f1c:	b	1ef0 <__ieee754_rem_pio2+0x970>
    1f20:	mov	w11, wzr
    1f24:	mov	w8, #0x1                   	// #1
    1f28:	b	1f00 <__ieee754_rem_pio2+0x980>
    1f2c:	ldur	w9, [x29, #-52]
    1f30:	cmp	w9, #0x19
    1f34:	b.lt	1f68 <__ieee754_rem_pio2+0x9e8>  // b.tstop
    1f38:	b.eq	1f50 <__ieee754_rem_pio2+0x9d0>  // b.none
    1f3c:	ldur	w9, [x29, #-52]
    1f40:	cmp	w9, #0x1a
    1f44:	b.ne	1f68 <__ieee754_rem_pio2+0x9e8>  // b.any
    1f48:	mov	w9, #0x3fffff              	// #4194303
    1f4c:	b	1f54 <__ieee754_rem_pio2+0x9d4>
    1f50:	mov	w9, #0x7fffff              	// #8388607
    1f54:	sub	x10, x29, #0x98
    1f58:	add	x10, x10, w27, sxtw #2
    1f5c:	ldur	w11, [x10, #-4]
    1f60:	and	w9, w11, w9
    1f64:	stur	w9, [x10, #-4]
    1f68:	cmp	w17, #0x2
    1f6c:	add	w13, w13, #0x1
    1f70:	b.ne	1f9c <__ieee754_rem_pio2+0xa1c>  // b.any
    1f74:	fsub	d8, d11, d8
    1f78:	tbnz	w8, #0, 1f9c <__ieee754_rem_pio2+0xa1c>
    1f7c:	fmov	d0, #1.000000000000000000e+00
    1f80:	mov	w0, w25
    1f84:	str	w13, [sp, #32]
    1f88:	bl	0 <scalbn>
    1f8c:	fsub	d8, d8, d0
    1f90:	ldp	x16, x15, [sp, #40]
    1f94:	ldr	w13, [sp, #32]
    1f98:	add	x14, sp, #0x38
    1f9c:	mov	w17, #0x2                   	// #2
    1fa0:	fcmp	d8, #0.0
    1fa4:	b.ne	2164 <__ieee754_rem_pio2+0xbe4>  // b.any
    1fa8:	cmp	w27, #0x5
    1fac:	b.cc	2044 <__ieee754_rem_pio2+0xac4>  // b.lo, b.ul, b.last
    1fb0:	sub	x9, x27, #0x4
    1fb4:	cmp	x9, #0x8
    1fb8:	b.cs	1fc8 <__ieee754_rem_pio2+0xa48>  // b.hs, b.nlast
    1fbc:	mov	w9, wzr
    1fc0:	mov	x8, x27
    1fc4:	b	202c <__ieee754_rem_pio2+0xaac>
    1fc8:	movi	v0.2d, #0x0
    1fcc:	movi	v1.2d, #0x0
    1fd0:	ldr	x8, [sp, #24]
    1fd4:	and	x10, x9, #0xfffffffffffffff8
    1fd8:	add	x11, x8, x27, lsl #2
    1fdc:	sub	x8, x27, x10
    1fe0:	mov	x12, x10
    1fe4:	ldp	q3, q2, [x11, #-16]
    1fe8:	subs	x12, x12, #0x8
    1fec:	sub	x11, x11, #0x20
    1ff0:	rev64	v2.4s, v2.4s
    1ff4:	rev64	v3.4s, v3.4s
    1ff8:	ext	v2.16b, v2.16b, v2.16b, #8
    1ffc:	ext	v3.16b, v3.16b, v3.16b, #8
    2000:	orr	v0.16b, v2.16b, v0.16b
    2004:	orr	v1.16b, v3.16b, v1.16b
    2008:	b.ne	1fe4 <__ieee754_rem_pio2+0xa64>  // b.any
    200c:	orr	v0.16b, v1.16b, v0.16b
    2010:	cmp	x9, x10
    2014:	ext	v1.16b, v0.16b, v0.16b, #8
    2018:	orr	v0.8b, v0.8b, v1.8b
    201c:	fmov	x11, d0
    2020:	lsr	x12, x11, #32
    2024:	orr	w9, w11, w12
    2028:	b.eq	2040 <__ieee754_rem_pio2+0xac0>  // b.none
    202c:	ldr	w10, [x28, x8, lsl #2]
    2030:	cmp	x8, #0x5
    2034:	sub	x8, x8, #0x1
    2038:	orr	w9, w10, w9
    203c:	b.gt	202c <__ieee754_rem_pio2+0xaac>
    2040:	cbnz	w9, 234c <__ieee754_rem_pio2+0xdcc>
    2044:	ldur	w8, [x29, #-140]
    2048:	cbz	w8, 2054 <__ieee754_rem_pio2+0xad4>
    204c:	mov	w8, #0x1                   	// #1
    2050:	b	2084 <__ieee754_rem_pio2+0xb04>
    2054:	ldur	w8, [x29, #-144]
    2058:	cbz	w8, 2064 <__ieee754_rem_pio2+0xae4>
    205c:	mov	w8, #0x2                   	// #2
    2060:	b	2084 <__ieee754_rem_pio2+0xb04>
    2064:	ldur	w8, [x29, #-148]
    2068:	cbz	w8, 2074 <__ieee754_rem_pio2+0xaf4>
    206c:	mov	w8, #0x3                   	// #3
    2070:	b	2084 <__ieee754_rem_pio2+0xb04>
    2074:	ldur	w8, [x29, #-152]
    2078:	cmp	w8, #0x0
    207c:	mov	w8, #0x4                   	// #4
    2080:	cinc	w8, w8, eq	// eq = none
    2084:	add	w9, w23, w27
    2088:	add	w8, w8, w27
    208c:	add	w9, w9, #0x4
    2090:	b	20a4 <__ieee754_rem_pio2+0xb24>
    2094:	cmp	x27, x8
    2098:	add	w9, w9, #0x1
    209c:	str	d0, [x20, x27, lsl #3]
    20a0:	b.cs	1df8 <__ieee754_rem_pio2+0x878>  // b.hs, b.nlast
    20a4:	mov	x10, x27
    20a8:	add	x27, x27, #0x1
    20ac:	movi	d0, #0x0
    20b0:	ldr	w11, [x22, x27, lsl #2]
    20b4:	add	w10, w23, w10
    20b8:	add	w10, w10, #0x4
    20bc:	scvtf	d1, w11
    20c0:	str	d1, [x21, w10, sxtw #3]
    20c4:	cbz	w26, 2094 <__ieee754_rem_pio2+0xb14>
    20c8:	sbfiz	x10, x9, #3, #32
    20cc:	cmp	x24, #0x4
    20d0:	b.cs	20dc <__ieee754_rem_pio2+0xb5c>  // b.hs, b.nlast
    20d4:	mov	x11, xzr
    20d8:	b	2134 <__ieee754_rem_pio2+0xbb4>
    20dc:	add	x11, x16, x10
    20e0:	mov	x12, x19
    20e4:	mov	x13, x15
    20e8:	ldp	q2, q1, [x11, #-16]
    20ec:	subs	x12, x12, #0x4
    20f0:	ldp	q3, q4, [x13, #-16]
    20f4:	add	x13, x13, #0x20
    20f8:	sub	x11, x11, #0x20
    20fc:	ext	v1.16b, v1.16b, v1.16b, #8
    2100:	ext	v2.16b, v2.16b, v2.16b, #8
    2104:	fmul	v1.2d, v3.2d, v1.2d
    2108:	mov	d3, v1.d[1]
    210c:	fadd	d0, d0, d1
    2110:	fmul	v1.2d, v4.2d, v2.2d
    2114:	fadd	d0, d0, d3
    2118:	mov	d2, v1.d[1]
    211c:	fadd	d0, d0, d1
    2120:	fadd	d0, d0, d2
    2124:	b.ne	20e8 <__ieee754_rem_pio2+0xb68>  // b.any
    2128:	cmp	x24, x19
    212c:	mov	x11, x19
    2130:	b.eq	2094 <__ieee754_rem_pio2+0xb14>  // b.none
    2134:	lsl	x12, x11, #3
    2138:	sub	x13, x10, x12
    213c:	sub	x10, x24, x11
    2140:	add	x12, x14, x12
    2144:	add	x11, x21, x13
    2148:	ldr	d1, [x12], #8
    214c:	subs	x10, x10, #0x1
    2150:	ldr	d2, [x11], #-8
    2154:	fmul	d1, d1, d2
    2158:	fadd	d0, d0, d1
    215c:	b.ne	2148 <__ieee754_rem_pio2+0xbc8>  // b.any
    2160:	b	2094 <__ieee754_rem_pio2+0xb14>
    2164:	fmov	d0, d8
    2168:	ldur	w9, [x29, #-52]
    216c:	mov	w8, #0x18                  	// #24
    2170:	mov	w19, w17
    2174:	mov	w20, w13
    2178:	sub	w0, w8, w9
    217c:	bl	0 <scalbn>
    2180:	mov	x8, #0x4170000000000000    	// #4715268809856909312
    2184:	fmov	d1, x8
    2188:	fcmp	d0, d1
    218c:	b.ge	21a4 <__ieee754_rem_pio2+0xc24>  // b.tcont
    2190:	fcvtzs	w8, d0
    2194:	sub	x9, x29, #0x98
    2198:	stur	w25, [x29, #-52]
    219c:	str	w8, [x9, x27, lsl #2]
    21a0:	b	21dc <__ieee754_rem_pio2+0xc5c>
    21a4:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    21a8:	mov	x9, #0xc170000000000000    	// #-4508103226997866496
    21ac:	sub	x10, x29, #0x98
    21b0:	fmov	d1, x8
    21b4:	fmov	d2, x9
    21b8:	fmul	d1, d0, d1
    21bc:	fcvtzs	w8, d1
    21c0:	scvtf	d1, w8
    21c4:	fmul	d1, d1, d2
    21c8:	fadd	d0, d0, d1
    21cc:	fcvtzs	w9, d0
    21d0:	str	w9, [x10, x27, lsl #2]
    21d4:	add	w27, w27, #0x1
    21d8:	str	w8, [x10, w27, uxtw #2]
    21dc:	mov	w17, w19
    21e0:	tbnz	w27, #31, 2370 <__ieee754_rem_pio2+0xdf0>
    21e4:	fmov	d0, #1.000000000000000000e+00
    21e8:	ldur	w0, [x29, #-52]
    21ec:	mov	w21, w17
    21f0:	mov	w19, w27
    21f4:	bl	0 <scalbn>
    21f8:	mov	x10, #0x3e70000000000000    	// #4499096027743125504
    21fc:	sub	x8, x29, #0x98
    2200:	add	x9, sp, #0x50
    2204:	fmov	d1, x10
    2208:	mov	x10, x19
    220c:	ldr	w11, [x8, x10, lsl #2]
    2210:	scvtf	d2, w11
    2214:	fmul	d2, d0, d2
    2218:	fmul	d0, d0, d1
    221c:	str	d2, [x9, x10, lsl #3]
    2220:	sub	x10, x10, #0x1
    2224:	cmn	x10, #0x1
    2228:	b.ne	220c <__ieee754_rem_pio2+0xc8c>  // b.any
    222c:	adrp	x11, 0 <pts_ieee754_acos>
    2230:	add	x10, sp, #0x50
    2234:	movi	d1, #0x0
    2238:	ldr	d0, [x11]
    223c:	adrp	x11, 0 <pts_ieee754_acos>
    2240:	add	x10, x10, x19, lsl #3
    2244:	ldr	d2, [x11]
    2248:	adrp	x11, 0 <pts_ieee754_acos>
    224c:	adrp	x12, 0 <pts_ieee754_acos>
    2250:	ldr	d3, [x11]
    2254:	ldr	d4, [x12]
    2258:	mov	x13, #0x442d00000000        	// #74960064217088
    225c:	ldr	x15, [sp, #16]
    2260:	mov	x8, xzr
    2264:	add	x9, x19, #0x1
    2268:	add	x10, x10, #0x10
    226c:	mov	w11, #0x4                   	// #4
    2270:	add	x12, sp, #0xf8
    2274:	movk	x13, #0x3e74, lsl #48
    2278:	mov	w16, w20
    227c:	mov	w17, w21
    2280:	b	2298 <__ieee754_rem_pio2+0xd18>
    2284:	str	d5, [x12, x8, lsl #3]
    2288:	add	x8, x8, #0x1
    228c:	sub	x10, x10, #0x8
    2290:	cmp	w9, w8
    2294:	b.eq	2304 <__ieee754_rem_pio2+0xd84>  // b.none
    2298:	ldur	d5, [x10, #-16]
    229c:	cmp	w8, #0x4
    22a0:	csel	w14, w8, w11, cc	// cc = lo, ul, last
    22a4:	fmul	d5, d5, d0
    22a8:	fadd	d5, d5, d1
    22ac:	cbz	w8, 2284 <__ieee754_rem_pio2+0xd04>
    22b0:	fmov	d7, x13
    22b4:	ldur	d6, [x10, #-8]
    22b8:	add	w14, w14, #0x1
    22bc:	cmp	w14, #0x2
    22c0:	fmul	d6, d6, d7
    22c4:	fadd	d5, d5, d6
    22c8:	b.eq	2284 <__ieee754_rem_pio2+0xd04>  // b.none
    22cc:	ldr	d6, [x10]
    22d0:	cmp	w14, #0x3
    22d4:	fmul	d6, d6, d2
    22d8:	fadd	d5, d5, d6
    22dc:	b.eq	2284 <__ieee754_rem_pio2+0xd04>  // b.none
    22e0:	ldr	d6, [x10, #8]
    22e4:	cmp	w14, #0x4
    22e8:	fmul	d6, d6, d3
    22ec:	fadd	d5, d5, d6
    22f0:	b.eq	2284 <__ieee754_rem_pio2+0xd04>  // b.none
    22f4:	ldr	d6, [x10, #16]
    22f8:	fmul	d6, d6, d4
    22fc:	fadd	d5, d5, d6
    2300:	b	2284 <__ieee754_rem_pio2+0xd04>
    2304:	movi	d1, #0x0
    2308:	cbz	w19, 2398 <__ieee754_rem_pio2+0xe18>
    230c:	add	x9, x19, #0x1
    2310:	add	x8, sp, #0xf8
    2314:	and	x10, x9, #0xfffffffe
    2318:	add	x11, x8, x19, lsl #3
    231c:	sub	x8, x19, x10
    2320:	mov	x12, x10
    2324:	ldr	d0, [x11]
    2328:	sub	x12, x12, #0x2
    232c:	fadd	d0, d1, d0
    2330:	ldur	d1, [x11, #-8]
    2334:	sub	x11, x11, #0x10
    2338:	fadd	d1, d0, d1
    233c:	cbnz	x12, 2324 <__ieee754_rem_pio2+0xda4>
    2340:	cmp	x9, x10
    2344:	b.ne	239c <__ieee754_rem_pio2+0xe1c>  // b.any
    2348:	b	23b4 <__ieee754_rem_pio2+0xe34>
    234c:	sub	x8, x29, #0x98
    2350:	mov	w20, w13
    2354:	sub	x8, x8, #0x4
    2358:	ldr	w9, [x8, x27, lsl #2]
    235c:	sub	w25, w25, #0x18
    2360:	sub	x27, x27, #0x1
    2364:	cbz	w9, 2358 <__ieee754_rem_pio2+0xdd8>
    2368:	stur	w25, [x29, #-52]
    236c:	tbz	w27, #31, 21e4 <__ieee754_rem_pio2+0xc64>
    2370:	movi	d0, #0x0
    2374:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    2378:	cmp	w17, #0x0
    237c:	fmov	d1, x8
    2380:	ldp	x12, x15, [sp, #8]
    2384:	cset	w8, eq	// eq = none
    2388:	mov	w16, w20
    238c:	fcsel	d0, d0, d1, eq	// eq = none
    2390:	str	d0, [x15]
    2394:	b	245c <__ieee754_rem_pio2+0xedc>
    2398:	mov	x8, x19
    239c:	add	x9, sp, #0xf8
    23a0:	ldr	d0, [x9, x8, lsl #3]
    23a4:	sub	x8, x8, #0x1
    23a8:	cmn	x8, #0x1
    23ac:	fadd	d1, d1, d0
    23b0:	b.ne	23a0 <__ieee754_rem_pio2+0xe20>  // b.any
    23b4:	fneg	d0, d1
    23b8:	ldr	d2, [sp, #248]
    23bc:	cmp	w17, #0x0
    23c0:	cset	w8, eq	// eq = none
    23c4:	fcsel	d0, d1, d0, eq	// eq = none
    23c8:	fsub	d1, d2, d1
    23cc:	str	d0, [x15]
    23d0:	cbz	w19, 23ec <__ieee754_rem_pio2+0xe6c>
    23d4:	cmp	w19, #0x4
    23d8:	add	w9, w19, #0x1
    23dc:	b.cs	23f4 <__ieee754_rem_pio2+0xe74>  // b.hs, b.nlast
    23e0:	ldr	x12, [sp, #8]
    23e4:	mov	w10, #0x1                   	// #1
    23e8:	b	2440 <__ieee754_rem_pio2+0xec0>
    23ec:	ldr	x12, [sp, #8]
    23f0:	b	245c <__ieee754_rem_pio2+0xedc>
    23f4:	sub	x11, x9, #0x1
    23f8:	add	x13, sp, #0xf8
    23fc:	and	x12, x11, #0xfffffffffffffffc
    2400:	add	x13, x13, #0x18
    2404:	orr	x10, x12, #0x1
    2408:	mov	x14, x12
    240c:	ldp	q2, q3, [x13, #-16]
    2410:	subs	x14, x14, #0x4
    2414:	add	x13, x13, #0x20
    2418:	mov	d4, v2.d[1]
    241c:	fadd	d1, d1, d2
    2420:	mov	d2, v3.d[1]
    2424:	fadd	d1, d1, d4
    2428:	fadd	d1, d1, d3
    242c:	fadd	d1, d1, d2
    2430:	b.ne	240c <__ieee754_rem_pio2+0xe8c>  // b.any
    2434:	cmp	x11, x12
    2438:	ldr	x12, [sp, #8]
    243c:	b.eq	245c <__ieee754_rem_pio2+0xedc>  // b.none
    2440:	add	x11, sp, #0xf8
    2444:	sub	x9, x9, x10
    2448:	add	x11, x11, x10, lsl #3
    244c:	ldr	d2, [x11], #8
    2450:	subs	x9, x9, #0x1
    2454:	fadd	d1, d1, d2
    2458:	b.ne	244c <__ieee754_rem_pio2+0xecc>  // b.any
    245c:	fneg	d2, d1
    2460:	cmp	w8, #0x0
    2464:	and	w0, w16, #0x7
    2468:	fcsel	d1, d1, d2, ne	// ne = any
    246c:	str	d1, [x15, #8]
    2470:	tbz	x12, #63, 2484 <__ieee754_rem_pio2+0xf04>
    2474:	fneg	d0, d0
    2478:	fneg	d1, d1
    247c:	stp	d0, d1, [x15]
    2480:	neg	w0, w0
    2484:	add	sp, sp, #0x290
    2488:	ldp	x20, x19, [sp, #144]
    248c:	ldp	x22, x21, [sp, #128]
    2490:	ldp	x24, x23, [sp, #112]
    2494:	ldp	x26, x25, [sp, #96]
    2498:	ldp	x28, x27, [sp, #80]
    249c:	ldp	x29, x30, [sp, #64]
    24a0:	ldp	d9, d8, [sp, #48]
    24a4:	ldp	d11, d10, [sp, #32]
    24a8:	ldp	d13, d12, [sp, #16]
    24ac:	ldr	d14, [sp], #160
    24b0:	ret
    24b4:	nop
    24b8:	nop
    24bc:	nop

00000000000024c0 <pts_ieee754_exp>:
    24c0:	fmov	x9, d0
    24c4:	mov	w11, #0x2e42                	// #11842
    24c8:	movk	w11, #0x4086, lsl #16
    24cc:	ubfx	x10, x9, #32, #31
    24d0:	lsr	x8, x9, #63
    24d4:	cmp	w10, w11
    24d8:	b.cc	2510 <pts_ieee754_exp+0x50>  // b.lo, b.ul, b.last
    24dc:	lsr	w10, w10, #20
    24e0:	cmp	w10, #0x7ff
    24e4:	b.cc	2548 <pts_ieee754_exp+0x88>  // b.lo, b.ul, b.last
    24e8:	movi	d1, #0x0
    24ec:	lsr	x8, x9, #32
    24f0:	cmp	x9, #0x0
    24f4:	fadd	d2, d0, d0
    24f8:	and	w8, w8, #0xfffff
    24fc:	orr	w8, w8, w9
    2500:	fcsel	d0, d0, d1, ge	// ge = tcont
    2504:	cmp	w8, #0x0
    2508:	fcsel	d0, d0, d2, eq	// eq = none
    250c:	ret
    2510:	mov	w9, #0x2e43                	// #11843
    2514:	movk	w9, #0x3fd6, lsl #16
    2518:	cmp	w10, w9
    251c:	b.cc	256c <pts_ieee754_exp+0xac>  // b.lo, b.ul, b.last
    2520:	mov	w9, #0xa2b1                	// #41649
    2524:	movk	w9, #0x3ff0, lsl #16
    2528:	cmp	w10, w9
    252c:	b.hi	25d0 <pts_ieee754_exp+0x110>  // b.pmore
    2530:	fmov	d1, #1.000000000000000000e+00
    2534:	fcmp	d0, d1
    2538:	b.ne	26fc <pts_ieee754_exp+0x23c>  // b.any
    253c:	adrp	x8, 0 <pts_ieee754_acos>
    2540:	ldr	d0, [x8]
    2544:	ret
    2548:	adrp	x9, 0 <pts_ieee754_acos>
    254c:	ldr	d1, [x9]
    2550:	fcmp	d0, d1
    2554:	b.le	25b4 <pts_ieee754_exp+0xf4>
    2558:	adrp	x8, 0 <pts_ieee754_acos>
    255c:	ldr	d0, [x8]
    2560:	ldr	d1, [x8]
    2564:	fmul	d0, d0, d1
    2568:	ret
    256c:	lsr	w8, w10, #20
    2570:	cmp	w8, #0x3e2
    2574:	b.hi	2598 <pts_ieee754_exp+0xd8>  // b.pmore
    2578:	adrp	x8, 0 <pts_ieee754_acos>
    257c:	ldr	d1, [x8]
    2580:	fadd	d2, d1, d0
    2584:	fmov	d1, #1.000000000000000000e+00
    2588:	fcmp	d2, d1
    258c:	b.le	2598 <pts_ieee754_exp+0xd8>
    2590:	fadd	d0, d0, d1
    2594:	ret
    2598:	fmul	d3, d0, d0
    259c:	movi	d1, #0x0
    25a0:	movi	d2, #0x0
    25a4:	mov	w8, wzr
    25a8:	mov	w9, #0x1                   	// #1
    25ac:	mov	w10, #0x3ff00000            	// #1072693248
    25b0:	b	262c <pts_ieee754_exp+0x16c>
    25b4:	adrp	x9, 0 <pts_ieee754_acos>
    25b8:	ldr	d1, [x9]
    25bc:	fcmp	d0, d1
    25c0:	b.pl	25d0 <pts_ieee754_exp+0x110>  // b.nfrst
    25c4:	adrp	x8, 0 <pts_ieee754_acos>
    25c8:	ldr	d0, [x8]
    25cc:	b	26f0 <pts_ieee754_exp+0x230>
    25d0:	adrp	x9, 0 <pts_ieee754_acos>
    25d4:	mov	w10, #0x7e700000            	// #2121269248
    25d8:	mov	w11, #0x3ff00000            	// #1072693248
    25dc:	ldr	d1, [x9]
    25e0:	adrp	x9, 0 <pts_ieee754_acos>
    25e4:	add	x9, x9, #0x0
    25e8:	ldr	d2, [x9, w8, uxtw #3]
    25ec:	adrp	x9, 0 <pts_ieee754_acos>
    25f0:	fmul	d1, d0, d1
    25f4:	fadd	d1, d1, d2
    25f8:	ldr	d2, [x9]
    25fc:	adrp	x9, 0 <pts_ieee754_acos>
    2600:	fcvtzs	w8, d1
    2604:	scvtf	d1, w8
    2608:	cmn	w8, #0x3fe
    260c:	csel	w10, w11, w10, gt
    2610:	fmul	d3, d1, d2
    2614:	ldr	d2, [x9]
    2618:	cset	w9, gt
    261c:	fmul	d2, d1, d2
    2620:	fadd	d1, d0, d3
    2624:	fsub	d0, d1, d2
    2628:	fmul	d3, d0, d0
    262c:	adrp	x11, 0 <pts_ieee754_acos>
    2630:	ldr	d4, [x11]
    2634:	adrp	x11, 0 <pts_ieee754_acos>
    2638:	ldr	d5, [x11]
    263c:	adrp	x11, 0 <pts_ieee754_acos>
    2640:	fmul	d4, d3, d4
    2644:	fadd	d4, d4, d5
    2648:	ldr	d5, [x11]
    264c:	adrp	x11, 0 <pts_ieee754_acos>
    2650:	fmul	d4, d3, d4
    2654:	fadd	d4, d4, d5
    2658:	ldr	d5, [x11]
    265c:	adrp	x11, 0 <pts_ieee754_acos>
    2660:	fmul	d4, d3, d4
    2664:	fadd	d4, d4, d5
    2668:	ldr	d5, [x11]
    266c:	fmul	d4, d3, d4
    2670:	fadd	d4, d4, d5
    2674:	fmul	d3, d3, d4
    2678:	fsub	d4, d0, d3
    267c:	fmul	d3, d0, d4
    2680:	cbz	w8, 26cc <pts_ieee754_exp+0x20c>
    2684:	fmov	d0, #2.000000000000000000e+00
    2688:	add	w10, w10, w8, lsl #20
    268c:	lsl	x10, x10, #32
    2690:	fsub	d0, d0, d4
    2694:	fdiv	d0, d3, d0
    2698:	fsub	d0, d2, d0
    269c:	fsub	d0, d1, d0
    26a0:	fmov	d1, #1.000000000000000000e+00
    26a4:	fadd	d0, d0, d1
    26a8:	fmov	d1, x10
    26ac:	cbz	w9, 26e8 <pts_ieee754_exp+0x228>
    26b0:	cmp	w8, #0x400
    26b4:	b.ne	26f4 <pts_ieee754_exp+0x234>  // b.any
    26b8:	fadd	d0, d0, d0
    26bc:	adrp	x8, 0 <pts_ieee754_acos>
    26c0:	ldr	d1, [x8]
    26c4:	fmul	d0, d0, d1
    26c8:	ret
    26cc:	fmov	d1, #-2.000000000000000000e+00
    26d0:	fadd	d1, d4, d1
    26d4:	fdiv	d1, d3, d1
    26d8:	fsub	d0, d0, d1
    26dc:	fmov	d1, #1.000000000000000000e+00
    26e0:	fadd	d0, d0, d1
    26e4:	ret
    26e8:	fmul	d0, d0, d1
    26ec:	adrp	x8, 0 <pts_ieee754_acos>
    26f0:	ldr	d1, [x8]
    26f4:	fmul	d0, d0, d1
    26f8:	ret
    26fc:	mov	w9, w8
    2700:	adrp	x10, 0 <pts_ieee754_acos>
    2704:	add	x10, x10, #0x0
    2708:	ubfiz	x9, x9, #3, #32
    270c:	ldr	d1, [x10, x9]
    2710:	adrp	x10, 0 <pts_ieee754_acos>
    2714:	add	x10, x10, #0x0
    2718:	ldr	d2, [x10, x9]
    271c:	eor	w9, w8, #0x1
    2720:	fsub	d1, d0, d1
    2724:	sub	w8, w9, w8
    2728:	fsub	d0, d1, d2
    272c:	fmul	d3, d0, d0
    2730:	b	25a8 <pts_ieee754_exp+0xe8>
    2734:	nop
    2738:	nop
    273c:	nop

0000000000002740 <pts_ieee754_atanh>:
    2740:	stp	x29, x30, [sp, #-32]!
    2744:	str	x19, [sp, #16]
    2748:	mov	x29, sp
    274c:	fmov	x19, d0
    2750:	mov	w9, #0x3ff00000            	// #1072693248
    2754:	ubfx	x8, x19, #32, #31
    2758:	cmp	w19, #0x0
    275c:	cset	w10, ne	// ne = any
    2760:	orr	w10, w8, w10
    2764:	cmp	w10, w9
    2768:	b.ls	2778 <pts_ieee754_atanh+0x38>  // b.plast
    276c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2770:	fmov	d0, x8
    2774:	b	2808 <pts_ieee754_atanh+0xc8>
    2778:	cmp	w8, w9
    277c:	b.ne	279c <pts_ieee754_atanh+0x5c>  // b.any
    2780:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2784:	mov	x9, #0x7ff0000000000000    	// #9218868437227405312
    2788:	fcmp	d0, #0.0
    278c:	fmov	d0, x8
    2790:	fmov	d1, x9
    2794:	fcsel	d0, d1, d0, gt
    2798:	b	2808 <pts_ieee754_atanh+0xc8>
    279c:	adrp	x9, 0 <pts_ieee754_acos>
    27a0:	ldr	d1, [x9]
    27a4:	fadd	d1, d0, d1
    27a8:	fcmp	d1, #0.0
    27ac:	b.le	27bc <pts_ieee754_atanh+0x7c>
    27b0:	lsr	w9, w8, #20
    27b4:	cmp	w9, #0x3e3
    27b8:	b.cc	2808 <pts_ieee754_atanh+0xc8>  // b.lo, b.ul, b.last
    27bc:	fabs	d1, d0
    27c0:	lsr	w8, w8, #21
    27c4:	fmov	d2, #1.000000000000000000e+00
    27c8:	cmp	w8, #0x1fe
    27cc:	fadd	d0, d1, d1
    27d0:	b.hi	27e8 <pts_ieee754_atanh+0xa8>  // b.pmore
    27d4:	fmul	d3, d1, d0
    27d8:	fsub	d1, d2, d1
    27dc:	fdiv	d1, d3, d1
    27e0:	fadd	d0, d0, d1
    27e4:	b	27f0 <pts_ieee754_atanh+0xb0>
    27e8:	fsub	d1, d2, d1
    27ec:	fdiv	d0, d0, d1
    27f0:	bl	5c0 <pts_ieee754_log1p>
    27f4:	fmov	d1, #5.000000000000000000e-01
    27f8:	cmp	x19, #0x0
    27fc:	fmul	d2, d0, d1
    2800:	fnmul	d0, d0, d1
    2804:	fcsel	d0, d0, d2, lt	// lt = tstop
    2808:	ldr	x19, [sp, #16]
    280c:	ldp	x29, x30, [sp], #32
    2810:	ret
    2814:	nop
    2818:	nop
    281c:	nop

0000000000002820 <pts_ieee754_log2>:
    2820:	fmov	x10, d0
    2824:	lsr	x8, x10, #32
    2828:	cmp	w8, #0x100, lsl #12
    282c:	b.ge	285c <pts_ieee754_log2+0x3c>  // b.tcont
    2830:	and	w8, w8, #0x7fffffff
    2834:	orr	w8, w8, w10
    2838:	cbz	w8, 2894 <pts_ieee754_log2+0x74>
    283c:	tbnz	x10, #63, 29b0 <pts_ieee754_log2+0x190>
    2840:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    2844:	mov	w9, #0xffffffca            	// #-54
    2848:	fmov	d1, x8
    284c:	fmul	d0, d0, d1
    2850:	fmov	x8, d0
    2854:	lsr	x8, x8, #32
    2858:	b	2860 <pts_ieee754_log2+0x40>
    285c:	mov	w9, wzr
    2860:	mov	w11, #0x7ff00000            	// #2146435072
    2864:	cmp	w8, w11
    2868:	b.lt	2878 <pts_ieee754_log2+0x58>  // b.tstop
    286c:	fadd	d1, d0, d0
    2870:	fmov	d0, d1
    2874:	ret
    2878:	cbnz	w10, 289c <pts_ieee754_log2+0x7c>
    287c:	movi	d1, #0x0
    2880:	mov	w10, #0x3ff00000            	// #1072693248
    2884:	cmp	w8, w10
    2888:	b.ne	289c <pts_ieee754_log2+0x7c>  // b.any
    288c:	fmov	d0, d1
    2890:	ret
    2894:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2898:	b	29b4 <pts_ieee754_log2+0x194>
    289c:	and	w10, w8, #0xfffff
    28a0:	fmov	x12, d0
    28a4:	fmov	d0, #-1.000000000000000000e+00
    28a8:	add	w10, w10, #0x95, lsl #12
    28ac:	add	w10, w10, #0xf64
    28b0:	and	w11, w10, #0x100000
    28b4:	and	x12, x12, #0xffffffff
    28b8:	bfxil	w11, w8, #0, #20
    28bc:	add	w8, w9, w8, asr #20
    28c0:	adrp	x9, 0 <pts_ieee754_acos>
    28c4:	eor	w11, w11, #0x3ff00000
    28c8:	add	w8, w8, w10, lsr #20
    28cc:	orr	x11, x12, x11, lsl #32
    28d0:	sub	w8, w8, #0x3ff
    28d4:	fmov	d1, x11
    28d8:	adrp	x11, 0 <pts_ieee754_acos>
    28dc:	ldr	d4, [x11]
    28e0:	adrp	x11, 0 <pts_ieee754_acos>
    28e4:	ldr	d5, [x11]
    28e8:	adrp	x11, 0 <pts_ieee754_acos>
    28ec:	add	x11, x11, #0x0
    28f0:	fadd	d0, d1, d0
    28f4:	fmov	d1, #2.000000000000000000e+00
    28f8:	fadd	d1, d0, d1
    28fc:	fdiv	d1, d0, d1
    2900:	fmul	d2, d1, d1
    2904:	fmul	d3, d2, d2
    2908:	fmul	d4, d3, d4
    290c:	fadd	d4, d4, d5
    2910:	ld1r	{v5.2d}, [x11]
    2914:	adrp	x11, 0 <pts_ieee754_acos>
    2918:	mov	v5.d[1], v4.d[0]
    291c:	fmul	v4.2d, v5.2d, v3.d[0]
    2920:	ldr	q5, [x11]
    2924:	adrp	x11, 0 <pts_ieee754_acos>
    2928:	ldr	q6, [x11]
    292c:	fadd	v4.2d, v4.2d, v5.2d
    2930:	fmov	d5, #5.000000000000000000e-01
    2934:	fmul	d5, d0, d5
    2938:	fmul	v4.2d, v4.2d, v3.d[0]
    293c:	mov	v3.d[1], v2.d[0]
    2940:	fmul	d2, d0, d5
    2944:	fadd	v4.2d, v4.2d, v6.2d
    2948:	fmul	v3.2d, v3.2d, v4.2d
    294c:	fsub	d4, d0, d2
    2950:	fmov	x11, d4
    2954:	faddp	d3, v3.2d
    2958:	and	x11, x11, #0xffffffff00000000
    295c:	fmov	d4, x11
    2960:	fadd	d3, d2, d3
    2964:	fsub	d0, d0, d4
    2968:	fmul	d1, d1, d3
    296c:	scvtf	d3, w8
    2970:	adrp	x8, 0 <pts_ieee754_acos>
    2974:	ldr	d6, [x8]
    2978:	fsub	d0, d0, d2
    297c:	ldr	d2, [x9]
    2980:	fadd	d0, d0, d1
    2984:	fmul	d1, d4, d2
    2988:	fadd	d4, d0, d4
    298c:	fadd	d5, d1, d3
    2990:	fmul	d0, d0, d2
    2994:	fmul	d4, d4, d6
    2998:	fsub	d2, d3, d5
    299c:	fadd	d0, d0, d4
    29a0:	fadd	d1, d1, d2
    29a4:	fadd	d0, d1, d0
    29a8:	fadd	d0, d5, d0
    29ac:	ret
    29b0:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    29b4:	fmov	d1, x8
    29b8:	fmov	d0, d1
    29bc:	ret

00000000000029c0 <pts_ieee754_log10>:
    29c0:	fmov	x8, d0
    29c4:	lsr	x9, x8, #32
    29c8:	cmp	w9, #0x100, lsl #12
    29cc:	b.ge	29fc <pts_ieee754_log10+0x3c>  // b.tcont
    29d0:	and	w9, w9, #0x7fffffff
    29d4:	orr	w9, w9, w8
    29d8:	cbz	w9, 2a2c <pts_ieee754_log10+0x6c>
    29dc:	tbnz	x8, #63, 2aac <pts_ieee754_log10+0xec>
    29e0:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    29e4:	mov	w10, #0xffffffca            	// #-54
    29e8:	fmov	d1, x8
    29ec:	fmul	d0, d0, d1
    29f0:	fmov	x8, d0
    29f4:	lsr	x9, x8, #32
    29f8:	b	2a00 <pts_ieee754_log10+0x40>
    29fc:	mov	w10, wzr
    2a00:	mov	w11, #0x7ff00000            	// #2146435072
    2a04:	cmp	w9, w11
    2a08:	b.lt	2a14 <pts_ieee754_log10+0x54>  // b.tstop
    2a0c:	fadd	d0, d0, d0
    2a10:	ret
    2a14:	cbnz	w8, 2a38 <pts_ieee754_log10+0x78>
    2a18:	movi	d0, #0x0
    2a1c:	mov	w11, #0x3ff00000            	// #1072693248
    2a20:	cmp	w9, w11
    2a24:	b.ne	2a38 <pts_ieee754_log10+0x78>  // b.any
    2a28:	ret
    2a2c:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2a30:	fmov	d0, x8
    2a34:	ret
    2a38:	stp	d9, d8, [sp, #-32]!
    2a3c:	stp	x29, x30, [sp, #16]
    2a40:	add	x29, sp, #0x10
    2a44:	add	w10, w10, w9, asr #20
    2a48:	and	w9, w9, #0xfffff
    2a4c:	mov	w8, w8
    2a50:	sub	w10, w10, #0x3ff
    2a54:	lsr	w11, w10, #31
    2a58:	add	w10, w11, w10
    2a5c:	orr	w9, w9, w11, lsl #20
    2a60:	scvtf	d8, w10
    2a64:	adrp	x10, 0 <pts_ieee754_acos>
    2a68:	eor	w9, w9, #0x3ff00000
    2a6c:	ldr	d0, [x10]
    2a70:	orr	x8, x8, x9, lsl #32
    2a74:	fmul	d9, d8, d0
    2a78:	fmov	d0, x8
    2a7c:	bl	360 <pts_ieee754_log>
    2a80:	adrp	x8, 0 <pts_ieee754_acos>
    2a84:	ldr	d1, [x8]
    2a88:	adrp	x8, 0 <pts_ieee754_acos>
    2a8c:	fmul	d0, d0, d1
    2a90:	ldr	d1, [x8]
    2a94:	fmul	d1, d8, d1
    2a98:	fadd	d0, d9, d0
    2a9c:	fadd	d0, d1, d0
    2aa0:	ldp	x29, x30, [sp, #16]
    2aa4:	ldp	d9, d8, [sp], #32
    2aa8:	ret
    2aac:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2ab0:	fmov	d0, x8
    2ab4:	ret
    2ab8:	nop
    2abc:	nop

0000000000002ac0 <pts_ieee754_expm1>:
    2ac0:	fmov	x9, d0
    2ac4:	mov	w11, #0x687a                	// #26746
    2ac8:	movk	w11, #0x4043, lsl #16
    2acc:	ubfx	x10, x9, #32, #31
    2ad0:	lsr	x8, x9, #32
    2ad4:	cmp	w10, w11
    2ad8:	b.cc	2b1c <pts_ieee754_expm1+0x5c>  // b.lo, b.ul, b.last
    2adc:	mov	w11, #0x2e42                	// #11842
    2ae0:	movk	w11, #0x4086, lsl #16
    2ae4:	cmp	w10, w11
    2ae8:	b.cc	2ba0 <pts_ieee754_expm1+0xe0>  // b.lo, b.ul, b.last
    2aec:	lsr	w10, w10, #20
    2af0:	cmp	w10, #0x7ff
    2af4:	b.cc	2b7c <pts_ieee754_expm1+0xbc>  // b.lo, b.ul, b.last
    2af8:	fmov	d1, #-1.000000000000000000e+00
    2afc:	tst	w8, #0x80000000
    2b00:	fadd	d2, d0, d0
    2b04:	and	w8, w8, #0xfffff
    2b08:	orr	w8, w8, w9
    2b0c:	fcsel	d0, d0, d1, eq	// eq = none
    2b10:	cmp	w8, #0x0
    2b14:	fcsel	d0, d0, d2, eq	// eq = none
    2b18:	ret
    2b1c:	mov	w9, #0x2e43                	// #11843
    2b20:	movk	w9, #0x3fd6, lsl #16
    2b24:	cmp	w10, w9
    2b28:	b.cc	2b58 <pts_ieee754_expm1+0x98>  // b.lo, b.ul, b.last
    2b2c:	mov	w9, #0xa2b1                	// #41649
    2b30:	movk	w9, #0x3ff0, lsl #16
    2b34:	cmp	w10, w9
    2b38:	b.hi	2bc0 <pts_ieee754_expm1+0x100>  // b.pmore
    2b3c:	tbnz	w8, #31, 2d58 <pts_ieee754_expm1+0x298>
    2b40:	adrp	x8, 0 <pts_ieee754_acos>
    2b44:	ldr	d1, [x8]
    2b48:	adrp	x8, 0 <pts_ieee754_acos>
    2b4c:	ldr	d2, [x8]
    2b50:	mov	w8, #0x1                   	// #1
    2b54:	b	2c00 <pts_ieee754_expm1+0x140>
    2b58:	lsr	w8, w10, #20
    2b5c:	cmp	w8, #0x3c8
    2b60:	b.hi	2c14 <pts_ieee754_expm1+0x154>  // b.pmore
    2b64:	adrp	x8, 0 <pts_ieee754_acos>
    2b68:	ldr	d1, [x8]
    2b6c:	ldr	d2, [x8]
    2b70:	fadd	d1, d1, d0
    2b74:	fadd	d2, d2, d0
    2b78:	b	2cdc <pts_ieee754_expm1+0x21c>
    2b7c:	adrp	x9, 0 <pts_ieee754_acos>
    2b80:	ldr	d1, [x9]
    2b84:	fcmp	d0, d1
    2b88:	b.le	2ba0 <pts_ieee754_expm1+0xe0>
    2b8c:	adrp	x8, 0 <pts_ieee754_acos>
    2b90:	ldr	d0, [x8]
    2b94:	ldr	d1, [x8]
    2b98:	fmul	d0, d0, d1
    2b9c:	ret
    2ba0:	adrp	x9, 0 <pts_ieee754_acos>
    2ba4:	ldr	d1, [x9]
    2ba8:	and	w9, w8, #0x80000000
    2bac:	fadd	d1, d0, d1
    2bb0:	fcmp	d1, #0.0
    2bb4:	fmov	d1, #-1.000000000000000000e+00
    2bb8:	ccmp	w9, #0x0, #0x4, mi	// mi = first
    2bbc:	b.ne	2dd0 <pts_ieee754_expm1+0x310>  // b.any
    2bc0:	adrp	x9, 0 <pts_ieee754_acos>
    2bc4:	fmov	d1, #-5.000000000000000000e-01
    2bc8:	fmov	d2, #5.000000000000000000e-01
    2bcc:	ldr	d3, [x9]
    2bd0:	tst	w8, #0x80000000
    2bd4:	adrp	x9, 0 <pts_ieee754_acos>
    2bd8:	fmul	d3, d0, d3
    2bdc:	fcsel	d1, d2, d1, eq	// eq = none
    2be0:	fadd	d1, d3, d1
    2be4:	fcvtzs	w8, d1
    2be8:	ldr	d1, [x9]
    2bec:	adrp	x9, 0 <pts_ieee754_acos>
    2bf0:	ldr	d3, [x9]
    2bf4:	scvtf	d2, w8
    2bf8:	fmul	d1, d2, d1
    2bfc:	fmul	d2, d2, d3
    2c00:	fadd	d1, d0, d1
    2c04:	fsub	d0, d1, d2
    2c08:	fsub	d1, d1, d0
    2c0c:	fsub	d1, d1, d2
    2c10:	b	2c18 <pts_ieee754_expm1+0x158>
    2c14:	mov	w8, wzr
    2c18:	fmov	d2, #5.000000000000000000e-01
    2c1c:	adrp	x9, 0 <pts_ieee754_acos>
    2c20:	fmov	d6, #6.000000000000000000e+00
    2c24:	ldr	d4, [x9]
    2c28:	adrp	x9, 0 <pts_ieee754_acos>
    2c2c:	ldr	d5, [x9]
    2c30:	adrp	x9, 0 <pts_ieee754_acos>
    2c34:	fmul	d3, d0, d2
    2c38:	fmul	d2, d0, d3
    2c3c:	fmul	d4, d2, d4
    2c40:	fadd	d4, d4, d5
    2c44:	ldr	d5, [x9]
    2c48:	adrp	x9, 0 <pts_ieee754_acos>
    2c4c:	fmul	d4, d2, d4
    2c50:	fadd	d4, d4, d5
    2c54:	ldr	d5, [x9]
    2c58:	adrp	x9, 0 <pts_ieee754_acos>
    2c5c:	fmul	d4, d2, d4
    2c60:	fadd	d4, d4, d5
    2c64:	ldr	d5, [x9]
    2c68:	fmul	d4, d2, d4
    2c6c:	fadd	d4, d4, d5
    2c70:	fmov	d5, #1.000000000000000000e+00
    2c74:	fmul	d4, d2, d4
    2c78:	fadd	d4, d4, d5
    2c7c:	fmov	d5, #3.000000000000000000e+00
    2c80:	fmul	d3, d3, d4
    2c84:	fsub	d3, d5, d3
    2c88:	fmul	d5, d0, d3
    2c8c:	fsub	d3, d4, d3
    2c90:	fsub	d4, d6, d5
    2c94:	fdiv	d3, d3, d4
    2c98:	fmul	d3, d2, d3
    2c9c:	cbz	w8, 2cd8 <pts_ieee754_expm1+0x218>
    2ca0:	fsub	d3, d3, d1
    2ca4:	cmp	w8, #0x1
    2ca8:	fmul	d3, d0, d3
    2cac:	fsub	d1, d3, d1
    2cb0:	fsub	d1, d1, d2
    2cb4:	b.eq	2ce8 <pts_ieee754_expm1+0x228>  // b.none
    2cb8:	cmn	w8, #0x1
    2cbc:	b.ne	2d0c <pts_ieee754_expm1+0x24c>  // b.any
    2cc0:	fsub	d0, d0, d1
    2cc4:	fmov	d1, #5.000000000000000000e-01
    2cc8:	fmul	d0, d0, d1
    2ccc:	fmov	d1, #-5.000000000000000000e-01
    2cd0:	fadd	d0, d0, d1
    2cd4:	ret
    2cd8:	fmul	d1, d0, d3
    2cdc:	fsub	d1, d1, d2
    2ce0:	fsub	d0, d0, d1
    2ce4:	ret
    2ce8:	fmov	d2, #-2.500000000000000000e-01
    2cec:	fcmp	d0, d2
    2cf0:	b.pl	2d70 <pts_ieee754_expm1+0x2b0>  // b.nfrst
    2cf4:	fmov	d2, #5.000000000000000000e-01
    2cf8:	fadd	d0, d0, d2
    2cfc:	fsub	d0, d1, d0
    2d00:	fmov	d1, #-2.000000000000000000e+00
    2d04:	fmul	d0, d0, d1
    2d08:	ret
    2d0c:	mov	x9, #0x3ff0000000000000    	// #4607182418800017408
    2d10:	sub	w10, w8, #0x39
    2d14:	add	x9, x9, x8, lsl #52
    2d18:	cmn	w10, #0x3b
    2d1c:	fmov	d2, x9
    2d20:	b.hi	2d84 <pts_ieee754_expm1+0x2c4>  // b.pmore
    2d24:	fsub	d0, d0, d1
    2d28:	fmov	d1, #1.000000000000000000e+00
    2d2c:	mov	x9, #0x7fe0000000000000    	// #9214364837600034816
    2d30:	fmov	d3, x9
    2d34:	cmp	w8, #0x400
    2d38:	fadd	d0, d0, d1
    2d3c:	fadd	d1, d0, d0
    2d40:	fmul	d0, d0, d2
    2d44:	fmul	d1, d1, d3
    2d48:	fcsel	d0, d1, d0, eq	// eq = none
    2d4c:	fmov	d1, #-1.000000000000000000e+00
    2d50:	fadd	d0, d0, d1
    2d54:	ret
    2d58:	adrp	x8, 0 <pts_ieee754_acos>
    2d5c:	ldr	d1, [x8]
    2d60:	adrp	x8, 0 <pts_ieee754_acos>
    2d64:	ldr	d2, [x8]
    2d68:	mov	w8, #0xffffffff            	// #-1
    2d6c:	b	2c00 <pts_ieee754_expm1+0x140>
    2d70:	fsub	d0, d0, d1
    2d74:	fmov	d1, #1.000000000000000000e+00
    2d78:	fadd	d0, d0, d0
    2d7c:	fadd	d0, d0, d1
    2d80:	ret
    2d84:	lsl	w9, w8, #20
    2d88:	mov	w10, #0x3ff00000            	// #1072693248
    2d8c:	cmp	w8, #0x13
    2d90:	sub	w9, w10, w9
    2d94:	lsl	x9, x9, #32
    2d98:	fmov	d3, x9
    2d9c:	mov	w9, #0x200000              	// #2097152
    2da0:	lsr	w9, w9, w8
    2da4:	fadd	d3, d1, d3
    2da8:	sub	w9, w10, w9
    2dac:	lsl	x9, x9, #32
    2db0:	fmov	d4, x9
    2db4:	fsub	d3, d0, d3
    2db8:	fsub	d0, d1, d0
    2dbc:	fmov	d1, #1.000000000000000000e+00
    2dc0:	fadd	d1, d3, d1
    2dc4:	fsub	d0, d4, d0
    2dc8:	fcsel	d0, d1, d0, hi	// hi = pmore
    2dcc:	fmul	d1, d0, d2
    2dd0:	fmov	d0, d1
    2dd4:	ret
    2dd8:	nop
    2ddc:	nop

0000000000002de0 <pts_ieee754_cbrt>:
    2de0:	fmov	x10, d0
    2de4:	lsr	x8, x10, #32
    2de8:	ubfx	w9, w8, #20, #11
    2dec:	cmp	w9, #0x7ff
    2df0:	b.cc	2dfc <pts_ieee754_cbrt+0x1c>  // b.lo, b.ul, b.last
    2df4:	fadd	d0, d0, d0
    2df8:	ret
    2dfc:	ubfx	x9, x10, #32, #31
    2e00:	lsr	w11, w9, #20
    2e04:	cbnz	w11, 2e30 <pts_ieee754_cbrt+0x50>
    2e08:	orr	w9, w9, w10
    2e0c:	cbz	w9, 2df8 <pts_ieee754_cbrt+0x18>
    2e10:	mov	x9, #0x4350000000000000    	// #4850376798678024192
    2e14:	mov	w10, #0x7893                	// #30867
    2e18:	fmov	d1, x9
    2e1c:	movk	w10, #0x297f, lsl #16
    2e20:	fmul	d1, d0, d1
    2e24:	fmov	x9, d1
    2e28:	ubfx	x9, x9, #32, #31
    2e2c:	b	2e38 <pts_ieee754_cbrt+0x58>
    2e30:	mov	w10, #0x7893                	// #30867
    2e34:	movk	w10, #0x2a9f, lsl #16
    2e38:	mov	w11, #0x5556                	// #21846
    2e3c:	and	w8, w8, #0x80000000
    2e40:	movk	w11, #0x5555, lsl #16
    2e44:	umull	x9, w9, w11
    2e48:	lsr	x9, x9, #32
    2e4c:	add	w9, w9, w10
    2e50:	orr	w8, w9, w8
    2e54:	mov	w9, #0x80000000            	// #-2147483648
    2e58:	lsl	x8, x8, #32
    2e5c:	fmov	d1, x8
    2e60:	adrp	x8, 0 <pts_ieee754_acos>
    2e64:	ldr	q4, [x8]
    2e68:	adrp	x8, 0 <pts_ieee754_acos>
    2e6c:	ldr	q5, [x8]
    2e70:	adrp	x8, 0 <pts_ieee754_acos>
    2e74:	fdiv	d2, d1, d0
    2e78:	fmul	d3, d1, d1
    2e7c:	fmul	d2, d3, d2
    2e80:	fmul	d3, d2, d2
    2e84:	fmul	v4.2d, v4.2d, v2.d[0]
    2e88:	fmul	d3, d2, d3
    2e8c:	dup	v2.2d, v2.d[0]
    2e90:	fadd	v4.2d, v4.2d, v5.2d
    2e94:	mov	v2.d[0], v3.d[0]
    2e98:	fmul	v2.2d, v2.2d, v4.2d
    2e9c:	ldr	d4, [x8]
    2ea0:	mov	d3, v2.d[1]
    2ea4:	fadd	d3, d3, d4
    2ea8:	fadd	d2, d2, d3
    2eac:	fmul	d1, d2, d1
    2eb0:	fmov	x8, d1
    2eb4:	and	x8, x8, #0xffffffffc0000000
    2eb8:	add	x8, x8, x9
    2ebc:	fmov	d1, x8
    2ec0:	fmul	d2, d1, d1
    2ec4:	fdiv	d0, d0, d2
    2ec8:	fadd	d2, d1, d1
    2ecc:	fsub	d3, d0, d1
    2ed0:	fadd	d0, d2, d0
    2ed4:	fdiv	d0, d3, d0
    2ed8:	fmul	d0, d0, d1
    2edc:	fadd	d0, d0, d1
    2ee0:	ret
    2ee4:	nop
    2ee8:	nop
    2eec:	nop
    2ef0:	nop
    2ef4:	nop
    2ef8:	nop
    2efc:	nop

0000000000002f00 <pts_ieee754_sin>:
    2f00:	sub	sp, sp, #0x20
    2f04:	stp	x29, x30, [sp, #16]
    2f08:	add	x29, sp, #0x10
    2f0c:	fmov	x8, d0
    2f10:	mov	w10, #0x21fb                	// #8699
    2f14:	movk	w10, #0x3fe9, lsl #16
    2f18:	ubfx	x9, x8, #32, #31
    2f1c:	cmp	w9, w10
    2f20:	b.hi	2fa4 <pts_ieee754_sin+0xa4>  // b.pmore
    2f24:	ubfx	x8, x8, #54, #9
    2f28:	cmp	x8, #0xf8
    2f2c:	b.hi	2f38 <pts_ieee754_sin+0x38>  // b.pmore
    2f30:	fcvtzs	w8, d0
    2f34:	cbz	w8, 2fb4 <pts_ieee754_sin+0xb4>
    2f38:	fmul	d1, d0, d0
    2f3c:	adrp	x8, 0 <pts_ieee754_acos>
    2f40:	ldr	d2, [x8]
    2f44:	adrp	x8, 0 <pts_ieee754_acos>
    2f48:	ldr	d3, [x8]
    2f4c:	adrp	x8, 0 <pts_ieee754_acos>
    2f50:	fmul	d2, d1, d2
    2f54:	fadd	d2, d2, d3
    2f58:	ldr	d3, [x8]
    2f5c:	adrp	x8, 0 <pts_ieee754_acos>
    2f60:	fmul	d2, d1, d2
    2f64:	fadd	d2, d2, d3
    2f68:	ldr	d3, [x8]
    2f6c:	adrp	x8, 0 <pts_ieee754_acos>
    2f70:	fmul	d2, d1, d2
    2f74:	fadd	d2, d2, d3
    2f78:	ldr	d3, [x8]
    2f7c:	adrp	x8, 0 <pts_ieee754_acos>
    2f80:	fmul	d2, d1, d2
    2f84:	fadd	d2, d2, d3
    2f88:	ldr	d3, [x8]
    2f8c:	fmul	d2, d1, d2
    2f90:	fmul	d1, d1, d0
    2f94:	fadd	d2, d2, d3
    2f98:	fmul	d1, d1, d2
    2f9c:	fadd	d0, d1, d0
    2fa0:	b	2fb4 <pts_ieee754_sin+0xb4>
    2fa4:	lsr	w8, w9, #20
    2fa8:	cmp	w8, #0x7ff
    2fac:	b.cc	2fc0 <pts_ieee754_sin+0xc0>  // b.lo, b.ul, b.last
    2fb0:	fsub	d0, d0, d0
    2fb4:	ldp	x29, x30, [sp, #16]
    2fb8:	add	sp, sp, #0x20
    2fbc:	ret
    2fc0:	mov	x0, sp
    2fc4:	bl	1580 <__ieee754_rem_pio2>
    2fc8:	ldr	d1, [sp]
    2fcc:	and	w8, w0, #0x3
    2fd0:	cmp	w8, #0x2
    2fd4:	b.eq	30c0 <pts_ieee754_sin+0x1c0>  // b.none
    2fd8:	cmp	w8, #0x1
    2fdc:	b.eq	3004 <pts_ieee754_sin+0x104>  // b.none
    2fe0:	cbnz	w8, 3160 <pts_ieee754_sin+0x260>
    2fe4:	fmov	x8, d1
    2fe8:	ubfx	x8, x8, #54, #9
    2fec:	cmp	x8, #0xf8
    2ff0:	b.hi	321c <pts_ieee754_sin+0x31c>  // b.pmore
    2ff4:	fcvtzs	w8, d1
    2ff8:	cbnz	w8, 321c <pts_ieee754_sin+0x31c>
    2ffc:	fmov	d0, d1
    3000:	b	2fb4 <pts_ieee754_sin+0xb4>
    3004:	fmov	x8, d1
    3008:	ldr	d2, [sp, #8]
    300c:	lsr	x9, x8, #32
    3010:	ubfx	w9, w9, #22, #9
    3014:	cmp	w9, #0xf8
    3018:	b.hi	3028 <pts_ieee754_sin+0x128>  // b.pmore
    301c:	fcvtzs	w9, d1
    3020:	fmov	d0, #1.000000000000000000e+00
    3024:	cbz	w9, 2fb4 <pts_ieee754_sin+0xb4>
    3028:	fmul	d0, d1, d1
    302c:	adrp	x9, 0 <pts_ieee754_acos>
    3030:	ubfx	x8, x8, #32, #31
    3034:	ldr	d3, [x9]
    3038:	adrp	x9, 0 <pts_ieee754_acos>
    303c:	ldr	d4, [x9]
    3040:	adrp	x9, 0 <pts_ieee754_acos>
    3044:	fmul	d3, d0, d3
    3048:	fadd	d3, d3, d4
    304c:	ldr	d4, [x9]
    3050:	adrp	x9, 0 <pts_ieee754_acos>
    3054:	fmul	d3, d0, d3
    3058:	fadd	d3, d3, d4
    305c:	ldr	d4, [x9]
    3060:	adrp	x9, 0 <pts_ieee754_acos>
    3064:	fmul	d3, d0, d3
    3068:	fadd	d3, d3, d4
    306c:	ldr	d4, [x9]
    3070:	adrp	x9, 0 <pts_ieee754_acos>
    3074:	fmul	d3, d0, d3
    3078:	fadd	d3, d3, d4
    307c:	ldr	d4, [x9]
    3080:	mov	w9, #0x3333                	// #13107
    3084:	movk	w9, #0x3fd3, lsl #16
    3088:	cmp	w8, w9
    308c:	fmul	d3, d0, d3
    3090:	fadd	d3, d3, d4
    3094:	fmul	d3, d0, d3
    3098:	b.cs	32a0 <pts_ieee754_sin+0x3a0>  // b.hs, b.nlast
    309c:	fmul	d3, d0, d3
    30a0:	fmul	d1, d1, d2
    30a4:	fmov	d2, #-5.000000000000000000e-01
    30a8:	fmul	d0, d0, d2
    30ac:	fsub	d1, d3, d1
    30b0:	fadd	d0, d1, d0
    30b4:	fmov	d1, #1.000000000000000000e+00
    30b8:	fadd	d0, d0, d1
    30bc:	b	2fb4 <pts_ieee754_sin+0xb4>
    30c0:	fmov	x8, d1
    30c4:	ubfx	x8, x8, #54, #9
    30c8:	cmp	x8, #0xf8
    30cc:	b.hi	30d8 <pts_ieee754_sin+0x1d8>  // b.pmore
    30d0:	fcvtzs	w8, d1
    30d4:	cbz	w8, 3158 <pts_ieee754_sin+0x258>
    30d8:	fmul	d0, d1, d1
    30dc:	adrp	x8, 0 <pts_ieee754_acos>
    30e0:	ldr	d5, [sp, #8]
    30e4:	ldr	d2, [x8]
    30e8:	adrp	x8, 0 <pts_ieee754_acos>
    30ec:	ldr	d3, [x8]
    30f0:	adrp	x8, 0 <pts_ieee754_acos>
    30f4:	fmul	d2, d0, d2
    30f8:	fmul	d4, d1, d0
    30fc:	fadd	d2, d2, d3
    3100:	ldr	d3, [x8]
    3104:	adrp	x8, 0 <pts_ieee754_acos>
    3108:	fmul	d2, d0, d2
    310c:	fadd	d2, d2, d3
    3110:	ldr	d3, [x8]
    3114:	adrp	x8, 0 <pts_ieee754_acos>
    3118:	fmul	d2, d0, d2
    311c:	fadd	d2, d2, d3
    3120:	ldr	d3, [x8]
    3124:	adrp	x8, 0 <pts_ieee754_acos>
    3128:	fmul	d2, d0, d2
    312c:	fadd	d2, d2, d3
    3130:	fmov	d3, #5.000000000000000000e-01
    3134:	fmul	d3, d5, d3
    3138:	fmul	d2, d4, d2
    313c:	fsub	d2, d3, d2
    3140:	fmul	d0, d0, d2
    3144:	ldr	d2, [x8]
    3148:	fmul	d2, d4, d2
    314c:	fsub	d0, d0, d5
    3150:	fadd	d0, d2, d0
    3154:	fsub	d1, d1, d0
    3158:	fneg	d0, d1
    315c:	b	2fb4 <pts_ieee754_sin+0xb4>
    3160:	fmov	x8, d1
    3164:	ldr	d0, [sp, #8]
    3168:	lsr	x9, x8, #32
    316c:	ubfx	w9, w9, #22, #9
    3170:	cmp	w9, #0xf8
    3174:	b.hi	3184 <pts_ieee754_sin+0x284>  // b.pmore
    3178:	fcvtzs	w9, d1
    317c:	fmov	d2, #1.000000000000000000e+00
    3180:	cbz	w9, 332c <pts_ieee754_sin+0x42c>
    3184:	fmul	d2, d1, d1
    3188:	adrp	x9, 0 <pts_ieee754_acos>
    318c:	ubfx	x8, x8, #32, #31
    3190:	ldr	d3, [x9]
    3194:	adrp	x9, 0 <pts_ieee754_acos>
    3198:	ldr	d4, [x9]
    319c:	adrp	x9, 0 <pts_ieee754_acos>
    31a0:	fmul	d3, d2, d3
    31a4:	fadd	d3, d3, d4
    31a8:	ldr	d4, [x9]
    31ac:	adrp	x9, 0 <pts_ieee754_acos>
    31b0:	fmul	d3, d2, d3
    31b4:	fadd	d3, d3, d4
    31b8:	ldr	d4, [x9]
    31bc:	adrp	x9, 0 <pts_ieee754_acos>
    31c0:	fmul	d3, d2, d3
    31c4:	fadd	d3, d3, d4
    31c8:	ldr	d4, [x9]
    31cc:	adrp	x9, 0 <pts_ieee754_acos>
    31d0:	fmul	d3, d2, d3
    31d4:	fadd	d3, d3, d4
    31d8:	ldr	d4, [x9]
    31dc:	mov	w9, #0x3333                	// #13107
    31e0:	movk	w9, #0x3fd3, lsl #16
    31e4:	cmp	w8, w9
    31e8:	fmul	d3, d2, d3
    31ec:	fadd	d3, d3, d4
    31f0:	fmul	d3, d2, d3
    31f4:	b.cs	32e8 <pts_ieee754_sin+0x3e8>  // b.hs, b.nlast
    31f8:	fmul	d3, d2, d3
    31fc:	fmul	d0, d1, d0
    3200:	fmov	d1, #-5.000000000000000000e-01
    3204:	fmul	d1, d2, d1
    3208:	fsub	d0, d3, d0
    320c:	fadd	d0, d0, d1
    3210:	fmov	d1, #1.000000000000000000e+00
    3214:	fadd	d2, d0, d1
    3218:	b	332c <pts_ieee754_sin+0x42c>
    321c:	fmul	d0, d1, d1
    3220:	adrp	x8, 0 <pts_ieee754_acos>
    3224:	ldr	d5, [sp, #8]
    3228:	ldr	d2, [x8]
    322c:	adrp	x8, 0 <pts_ieee754_acos>
    3230:	ldr	d3, [x8]
    3234:	adrp	x8, 0 <pts_ieee754_acos>
    3238:	fmul	d2, d0, d2
    323c:	fmul	d4, d1, d0
    3240:	fadd	d2, d2, d3
    3244:	ldr	d3, [x8]
    3248:	adrp	x8, 0 <pts_ieee754_acos>
    324c:	fmul	d2, d0, d2
    3250:	fadd	d2, d2, d3
    3254:	ldr	d3, [x8]
    3258:	adrp	x8, 0 <pts_ieee754_acos>
    325c:	fmul	d2, d0, d2
    3260:	fadd	d2, d2, d3
    3264:	ldr	d3, [x8]
    3268:	adrp	x8, 0 <pts_ieee754_acos>
    326c:	fmul	d2, d0, d2
    3270:	fadd	d2, d2, d3
    3274:	fmov	d3, #5.000000000000000000e-01
    3278:	fmul	d3, d5, d3
    327c:	fmul	d2, d4, d2
    3280:	fsub	d2, d3, d2
    3284:	fmul	d0, d0, d2
    3288:	ldr	d2, [x8]
    328c:	fmul	d2, d4, d2
    3290:	fsub	d0, d0, d5
    3294:	fadd	d0, d2, d0
    3298:	fsub	d0, d1, d0
    329c:	b	2fb4 <pts_ieee754_sin+0xb4>
    32a0:	sub	w9, w8, #0x200, lsl #12
    32a4:	fmov	d4, #5.000000000000000000e-01
    32a8:	fmov	d5, #2.812500000000000000e-01
    32ac:	lsl	x9, x9, #32
    32b0:	mov	w10, #0x3fe90000            	// #1072234496
    32b4:	fmul	d1, d1, d2
    32b8:	cmp	w8, w10
    32bc:	fmov	d6, x9
    32c0:	fmul	d4, d0, d4
    32c4:	fmul	d0, d0, d3
    32c8:	fcsel	d5, d5, d6, hi	// hi = pmore
    32cc:	fsub	d0, d0, d1
    32d0:	fmov	d1, #1.000000000000000000e+00
    32d4:	fsub	d2, d4, d5
    32d8:	fsub	d1, d1, d5
    32dc:	fsub	d0, d0, d2
    32e0:	fadd	d0, d1, d0
    32e4:	b	2fb4 <pts_ieee754_sin+0xb4>
    32e8:	sub	w9, w8, #0x200, lsl #12
    32ec:	fmov	d4, #5.000000000000000000e-01
    32f0:	fmov	d5, #2.812500000000000000e-01
    32f4:	lsl	x9, x9, #32
    32f8:	mov	w10, #0x3fe90000            	// #1072234496
    32fc:	fmul	d0, d1, d0
    3300:	cmp	w8, w10
    3304:	fmov	d6, x9
    3308:	fmul	d4, d2, d4
    330c:	fmul	d2, d2, d3
    3310:	fcsel	d5, d5, d6, hi	// hi = pmore
    3314:	fsub	d0, d2, d0
    3318:	fmov	d2, #1.000000000000000000e+00
    331c:	fsub	d1, d4, d5
    3320:	fsub	d2, d2, d5
    3324:	fsub	d0, d0, d1
    3328:	fadd	d2, d2, d0
    332c:	fneg	d0, d2
    3330:	b	2fb4 <pts_ieee754_sin+0xb4>
    3334:	nop
    3338:	nop
    333c:	nop

0000000000003340 <pts_ieee754_tan>:
    3340:	fmov	x8, d0
    3344:	mov	w9, #0x21fb                	// #8699
    3348:	movk	w9, #0x3fe9, lsl #16
    334c:	ubfx	x8, x8, #32, #31
    3350:	cmp	w8, w9
    3354:	b.hi	3364 <pts_ieee754_tan+0x24>  // b.pmore
    3358:	movi	d1, #0x0
    335c:	mov	w0, #0x1                   	// #1
    3360:	b	33c0 <__kernel_tan>
    3364:	lsr	w8, w8, #20
    3368:	cmp	w8, #0x7ff
    336c:	b.cc	3378 <pts_ieee754_tan+0x38>  // b.lo, b.ul, b.last
    3370:	fsub	d0, d0, d0
    3374:	ret
    3378:	sub	sp, sp, #0x20
    337c:	stp	x29, x30, [sp, #16]
    3380:	add	x29, sp, #0x10
    3384:	mov	x0, sp
    3388:	bl	1580 <__ieee754_rem_pio2>
    338c:	ubfiz	w8, w0, #1, #1
    3390:	ldp	d0, d1, [sp]
    3394:	mov	w9, #0x1                   	// #1
    3398:	sub	w0, w9, w8
    339c:	ldp	x29, x30, [sp, #16]
    33a0:	add	sp, sp, #0x20
    33a4:	b	33c0 <__kernel_tan>
    33a8:	nop
    33ac:	nop
    33b0:	nop
    33b4:	nop
    33b8:	nop
    33bc:	nop

00000000000033c0 <__kernel_tan>:
    33c0:	fmov	x11, d0
    33c4:	fcvtzs	w10, d0
    33c8:	lsr	x8, x11, #32
    33cc:	ubfx	w9, w8, #20, #11
    33d0:	cmp	w9, #0x3e2
    33d4:	ubfx	x9, x11, #32, #31
    33d8:	ccmp	w10, #0x0, #0x0, ls	// ls = plast
    33dc:	b.eq	3550 <__kernel_tan+0x190>  // b.none
    33e0:	mov	w10, #0x9428                	// #37928
    33e4:	movk	w10, #0x3fe5, lsl #16
    33e8:	cmp	w9, w10
    33ec:	b.cc	3424 <__kernel_tan+0x64>  // b.lo, b.ul, b.last
    33f0:	fneg	d2, d0
    33f4:	fneg	d3, d1
    33f8:	cmp	x11, #0x0
    33fc:	adrp	x11, 0 <pts_ieee754_acos>
    3400:	adrp	x12, 0 <pts_ieee754_acos>
    3404:	fcsel	d1, d3, d1, lt	// lt = tstop
    3408:	fcsel	d0, d2, d0, lt	// lt = tstop
    340c:	ldr	d2, [x11]
    3410:	ldr	d3, [x12]
    3414:	fsub	d0, d2, d0
    3418:	fsub	d1, d3, d1
    341c:	fadd	d0, d0, d1
    3420:	movi	d1, #0x0
    3424:	fmul	d2, d0, d0
    3428:	adrp	x11, 0 <pts_ieee754_acos>
    342c:	adrp	x12, 0 <pts_ieee754_acos>
    3430:	ldr	d4, [x11]
    3434:	adrp	x11, 0 <pts_ieee754_acos>
    3438:	ldr	d6, [x12]
    343c:	ldr	d5, [x11]
    3440:	adrp	x11, 0 <pts_ieee754_acos>
    3444:	cmp	w9, w10
    3448:	fmul	d3, d2, d2
    344c:	fmul	d4, d3, d4
    3450:	fmul	d5, d3, d5
    3454:	fadd	d4, d4, d6
    3458:	ldr	d6, [x11]
    345c:	adrp	x11, 0 <pts_ieee754_acos>
    3460:	fadd	d5, d5, d6
    3464:	ldr	d6, [x11]
    3468:	adrp	x11, 0 <pts_ieee754_acos>
    346c:	fmul	d4, d3, d4
    3470:	fmul	d5, d3, d5
    3474:	fadd	d4, d4, d6
    3478:	ldr	d6, [x11]
    347c:	adrp	x11, 0 <pts_ieee754_acos>
    3480:	fadd	d5, d5, d6
    3484:	ldr	d6, [x11]
    3488:	adrp	x11, 0 <pts_ieee754_acos>
    348c:	fmul	d4, d3, d4
    3490:	fmul	d5, d3, d5
    3494:	fadd	d4, d4, d6
    3498:	ldr	d6, [x11]
    349c:	adrp	x11, 0 <pts_ieee754_acos>
    34a0:	fadd	d5, d5, d6
    34a4:	ldr	d6, [x11]
    34a8:	adrp	x11, 0 <pts_ieee754_acos>
    34ac:	fmul	d4, d3, d4
    34b0:	fmul	d5, d3, d5
    34b4:	fadd	d4, d4, d6
    34b8:	ldr	d6, [x11]
    34bc:	adrp	x11, 0 <pts_ieee754_acos>
    34c0:	fadd	d5, d5, d6
    34c4:	ldr	d6, [x11]
    34c8:	adrp	x11, 0 <pts_ieee754_acos>
    34cc:	fmul	d4, d3, d4
    34d0:	fmul	d3, d3, d5
    34d4:	ldr	d5, [x11]
    34d8:	adrp	x11, 0 <pts_ieee754_acos>
    34dc:	fadd	d4, d4, d6
    34e0:	fadd	d3, d3, d5
    34e4:	fmul	d5, d0, d2
    34e8:	fmul	d4, d2, d4
    34ec:	fadd	d3, d3, d4
    34f0:	fmul	d3, d5, d3
    34f4:	fadd	d3, d1, d3
    34f8:	fmul	d2, d2, d3
    34fc:	ldr	d3, [x11]
    3500:	fadd	d1, d1, d2
    3504:	fmul	d2, d5, d3
    3508:	fadd	d2, d2, d1
    350c:	fadd	d1, d0, d2
    3510:	b.cc	356c <__kernel_tan+0x1ac>  // b.lo, b.ul, b.last
    3514:	scvtf	d3, w0
    3518:	fmul	d4, d1, d1
    351c:	lsr	w8, w8, #31
    3520:	mov	w9, #0x1                   	// #1
    3524:	sub	w8, w9, w8, lsl #1
    3528:	fadd	d1, d1, d3
    352c:	fdiv	d1, d4, d1
    3530:	fsub	d1, d1, d2
    3534:	fsub	d0, d0, d1
    3538:	scvtf	d1, w8
    353c:	fadd	d0, d0, d0
    3540:	fsub	d0, d3, d0
    3544:	fmul	d1, d0, d1
    3548:	fmov	d0, d1
    354c:	ret
    3550:	add	w8, w0, #0x1
    3554:	orr	w8, w8, w11
    3558:	orr	w8, w8, w9
    355c:	cbz	w8, 35ac <__kernel_tan+0x1ec>
    3560:	cmp	w0, #0x1
    3564:	b.ne	35c0 <__kernel_tan+0x200>  // b.any
    3568:	ret
    356c:	cmp	w0, #0x1
    3570:	b.eq	3600 <__kernel_tan+0x240>  // b.none
    3574:	fmov	d3, #-1.000000000000000000e+00
    3578:	movi	v4.2d, #0xffffffff00000000
    357c:	fdiv	d3, d3, d1
    3580:	mov	v1.d[1], v3.d[0]
    3584:	and	v1.16b, v1.16b, v4.16b
    3588:	fmov	d4, #1.000000000000000000e+00
    358c:	fsub	d0, d1, d0
    3590:	fsub	d0, d2, d0
    3594:	fmul	d2, d1, v1.d[1]
    3598:	fadd	d2, d2, d4
    359c:	fmul	d0, d0, v1.d[1]
    35a0:	mov	d1, v1.d[1]
    35a4:	fadd	d0, d2, d0
    35a8:	b	35f8 <__kernel_tan+0x238>
    35ac:	fabs	d0, d0
    35b0:	fmov	d1, #1.000000000000000000e+00
    35b4:	fdiv	d1, d1, d0
    35b8:	fmov	d0, d1
    35bc:	ret
    35c0:	fadd	d2, d0, d1
    35c4:	fmov	d3, #-1.000000000000000000e+00
    35c8:	movi	v4.2d, #0xffffffff00000000
    35cc:	fdiv	d3, d3, d2
    35d0:	mov	v2.d[1], v3.d[0]
    35d4:	and	v2.16b, v2.16b, v4.16b
    35d8:	fmov	d4, #1.000000000000000000e+00
    35dc:	fsub	d0, d2, d0
    35e0:	fsub	d0, d1, d0
    35e4:	fmul	d1, d2, v2.d[1]
    35e8:	fadd	d1, d1, d4
    35ec:	fmul	d0, d0, v2.d[1]
    35f0:	fadd	d0, d1, d0
    35f4:	mov	d1, v2.d[1]
    35f8:	fmul	d0, d3, d0
    35fc:	fadd	d1, d0, d1
    3600:	fmov	d0, d1
    3604:	ret
    3608:	nop
    360c:	nop
    3610:	nop
    3614:	nop
    3618:	nop
    361c:	nop

0000000000003620 <pts_ieee754_cosh>:
    3620:	str	d8, [sp, #-32]!
    3624:	stp	x29, x30, [sp, #8]
    3628:	str	x19, [sp, #24]
    362c:	add	x29, sp, #0x8
    3630:	fmov	x8, d0
    3634:	ubfx	x19, x8, #32, #31
    3638:	mov	w8, #0x2e42                	// #11842
    363c:	movk	w8, #0x3fd6, lsl #16
    3640:	cmp	w19, w8
    3644:	b.hi	367c <pts_ieee754_cosh+0x5c>  // b.pmore
    3648:	fabs	d0, d0
    364c:	bl	2ac0 <pts_ieee754_expm1>
    3650:	fmov	d2, #1.000000000000000000e+00
    3654:	fmov	d1, d0
    3658:	lsr	w8, w19, #23
    365c:	cmp	w8, #0x79
    3660:	fadd	d0, d0, d2
    3664:	b.cc	3710 <pts_ieee754_cosh+0xf0>  // b.lo, b.ul, b.last
    3668:	fmul	d1, d1, d1
    366c:	fadd	d0, d0, d0
    3670:	fdiv	d0, d1, d0
    3674:	fadd	d0, d0, d2
    3678:	b	3710 <pts_ieee754_cosh+0xf0>
    367c:	mov	w8, #0x4035ffff            	// #1077280767
    3680:	cmp	w19, w8
    3684:	b.hi	36a4 <pts_ieee754_cosh+0x84>  // b.pmore
    3688:	fabs	d0, d0
    368c:	bl	24c0 <pts_ieee754_exp>
    3690:	fmov	d1, #5.000000000000000000e-01
    3694:	fdiv	d2, d1, d0
    3698:	fmul	d0, d0, d1
    369c:	fadd	d0, d0, d2
    36a0:	b	3710 <pts_ieee754_cosh+0xf0>
    36a4:	fabs	d1, d0
    36a8:	mov	w8, #0x2e41                	// #11841
    36ac:	movk	w8, #0x4086, lsl #16
    36b0:	cmp	w19, w8
    36b4:	b.hi	36c8 <pts_ieee754_cosh+0xa8>  // b.pmore
    36b8:	fmov	d0, d1
    36bc:	bl	24c0 <pts_ieee754_exp>
    36c0:	fmov	d1, #5.000000000000000000e-01
    36c4:	b	370c <pts_ieee754_cosh+0xec>
    36c8:	adrp	x8, 0 <pts_ieee754_acos>
    36cc:	ldr	d2, [x8]
    36d0:	fcmp	d1, d2
    36d4:	b.ls	36ec <pts_ieee754_cosh+0xcc>  // b.plast
    36d8:	lsr	w8, w19, #20
    36dc:	cmp	w8, #0x7ff
    36e0:	b.cc	3700 <pts_ieee754_cosh+0xe0>  // b.lo, b.ul, b.last
    36e4:	fmul	d0, d0, d0
    36e8:	b	3710 <pts_ieee754_cosh+0xf0>
    36ec:	fmov	d8, #5.000000000000000000e-01
    36f0:	fmul	d0, d1, d8
    36f4:	bl	24c0 <pts_ieee754_exp>
    36f8:	fmul	d1, d0, d8
    36fc:	b	370c <pts_ieee754_cosh+0xec>
    3700:	adrp	x8, 0 <pts_ieee754_acos>
    3704:	ldr	d0, [x8]
    3708:	ldr	d1, [x8]
    370c:	fmul	d0, d0, d1
    3710:	ldp	x29, x30, [sp, #8]
    3714:	ldr	x19, [sp, #24]
    3718:	ldr	d8, [sp], #32
    371c:	ret

0000000000003720 <pts_ieee754_sinh>:
    3720:	stp	d9, d8, [sp, #-32]!
    3724:	stp	x29, x30, [sp, #16]
    3728:	add	x29, sp, #0x10
    372c:	fmov	d1, #5.000000000000000000e-01
    3730:	fabs	d8, d0
    3734:	fcmp	d0, #0.0
    3738:	fmov	d2, #-5.000000000000000000e-01
    373c:	fmov	d3, #2.200000000000000000e+01
    3740:	fcsel	d9, d2, d1, mi	// mi = first
    3744:	fcmp	d8, d3
    3748:	b.pl	378c <pts_ieee754_sinh+0x6c>  // b.nfrst
    374c:	mov	x8, #0x3e30000000000000    	// #4481081629233643520
    3750:	fmov	d1, x8
    3754:	fcmp	d8, d1
    3758:	b.mi	37f4 <pts_ieee754_sinh+0xd4>  // b.first
    375c:	fmov	d0, d8
    3760:	bl	2ac0 <pts_ieee754_expm1>
    3764:	fmov	d1, #1.000000000000000000e+00
    3768:	fcmp	d8, d1
    376c:	b.pl	37cc <pts_ieee754_sinh+0xac>  // b.nfrst
    3770:	fmul	d2, d0, d0
    3774:	fadd	d1, d0, d1
    3778:	fadd	d0, d0, d0
    377c:	fdiv	d1, d2, d1
    3780:	fsub	d0, d0, d1
    3784:	fmul	d0, d9, d0
    3788:	b	37f4 <pts_ieee754_sinh+0xd4>
    378c:	mov	x8, #0x2e4200000000        	// #50861002719232
    3790:	movk	x8, #0x4086, lsl #48
    3794:	fmov	d1, x8
    3798:	fcmp	d8, d1
    379c:	b.pl	37b0 <pts_ieee754_sinh+0x90>  // b.nfrst
    37a0:	fmov	d0, d8
    37a4:	bl	24c0 <pts_ieee754_exp>
    37a8:	fmul	d0, d9, d0
    37ac:	b	37f4 <pts_ieee754_sinh+0xd4>
    37b0:	adrp	x8, 0 <pts_ieee754_acos>
    37b4:	ldr	d1, [x8]
    37b8:	fcmp	d8, d1
    37bc:	b.ls	37e0 <pts_ieee754_sinh+0xc0>  // b.plast
    37c0:	adrp	x8, 0 <pts_ieee754_acos>
    37c4:	ldr	d1, [x8]
    37c8:	b	37f0 <pts_ieee754_sinh+0xd0>
    37cc:	fadd	d1, d0, d1
    37d0:	fdiv	d1, d0, d1
    37d4:	fadd	d0, d0, d1
    37d8:	fmul	d0, d9, d0
    37dc:	b	37f4 <pts_ieee754_sinh+0xd4>
    37e0:	fmov	d0, #5.000000000000000000e-01
    37e4:	fmul	d0, d8, d0
    37e8:	bl	24c0 <pts_ieee754_exp>
    37ec:	fmul	d1, d9, d0
    37f0:	fmul	d0, d0, d1
    37f4:	ldp	x29, x30, [sp, #16]
    37f8:	ldp	d9, d8, [sp], #32
    37fc:	ret

0000000000003800 <pts_ieee754_tanh>:
    3800:	stp	x29, x30, [sp, #-32]!
    3804:	str	x19, [sp, #16]
    3808:	mov	x29, sp
    380c:	fmov	x19, d0
    3810:	lsr	x8, x19, #32
    3814:	ubfx	w8, w8, #20, #11
    3818:	cmp	w8, #0x7ff
    381c:	b.cc	3840 <pts_ieee754_tanh+0x40>  // b.lo, b.ul, b.last
    3820:	fmov	d1, #1.000000000000000000e+00
    3824:	fmov	d2, #-1.000000000000000000e+00
    3828:	tst	x19, #0x8000000000000000
    382c:	fdiv	d0, d1, d0
    3830:	fadd	d2, d0, d2
    3834:	fadd	d0, d0, d1
    3838:	fcsel	d0, d2, d0, ne	// ne = any
    383c:	b	38bc <pts_ieee754_tanh+0xbc>
    3840:	ubfx	x8, x19, #32, #31
    3844:	mov	w9, #0x4035ffff            	// #1077280767
    3848:	cmp	w8, w9
    384c:	b.hi	38a0 <pts_ieee754_tanh+0xa0>  // b.pmore
    3850:	adrp	x9, 0 <pts_ieee754_acos>
    3854:	fmov	d2, #1.000000000000000000e+00
    3858:	lsr	w8, w8, #20
    385c:	ldr	d1, [x9]
    3860:	fadd	d1, d0, d1
    3864:	fcmp	d1, d2
    3868:	b.le	3874 <pts_ieee754_tanh+0x74>
    386c:	cmp	w8, #0x3e3
    3870:	b.cc	38bc <pts_ieee754_tanh+0xbc>  // b.lo, b.ul, b.last
    3874:	fabs	d0, d0
    3878:	cmp	w8, #0x3ff
    387c:	b.cc	38c8 <pts_ieee754_tanh+0xc8>  // b.lo, b.ul, b.last
    3880:	fadd	d0, d0, d0
    3884:	bl	2ac0 <pts_ieee754_expm1>
    3888:	fmov	d1, #2.000000000000000000e+00
    388c:	fadd	d0, d0, d1
    3890:	fdiv	d0, d1, d0
    3894:	fmov	d1, #1.000000000000000000e+00
    3898:	fsub	d0, d1, d0
    389c:	b	38b0 <pts_ieee754_tanh+0xb0>
    38a0:	adrp	x8, 0 <pts_ieee754_acos>
    38a4:	fmov	d0, #1.000000000000000000e+00
    38a8:	ldr	d1, [x8]
    38ac:	fsub	d0, d0, d1
    38b0:	fneg	d1, d0
    38b4:	cmp	x19, #0x0
    38b8:	fcsel	d0, d1, d0, lt	// lt = tstop
    38bc:	ldr	x19, [sp, #16]
    38c0:	ldp	x29, x30, [sp], #32
    38c4:	ret
    38c8:	fmov	d1, #-2.000000000000000000e+00
    38cc:	fmul	d0, d0, d1
    38d0:	bl	2ac0 <pts_ieee754_expm1>
    38d4:	fmov	d1, #2.000000000000000000e+00
    38d8:	fneg	d2, d0
    38dc:	fadd	d0, d0, d1
    38e0:	fdiv	d0, d2, d0
    38e4:	b	38b0 <pts_ieee754_tanh+0xb0>
