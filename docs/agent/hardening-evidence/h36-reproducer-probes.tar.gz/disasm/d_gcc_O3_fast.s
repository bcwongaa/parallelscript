
bin/d_gcc_O3_fast.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <__kernel_rem_pio2.constprop.0>:
       0:	stp	x29, x30, [sp, #-144]!
       4:	mov	w4, #0xaaab                	// #43691
       8:	movk	w4, #0x2aaa, lsl #16
       c:	mov	x29, sp
      10:	stp	x19, x20, [sp, #16]
      14:	sub	w20, w2, #0x3
      18:	mov	w5, w2
      1c:	adrp	x2, 0 <__stack_chk_guard>
      20:	ldr	x2, [x2]
      24:	smull	x4, w20, w4
      28:	stp	x21, x22, [sp, #32]
      2c:	mov	w19, w3
      30:	asr	x4, x4, #34
      34:	stp	x23, x24, [sp, #48]
      38:	sub	w20, w4, w20, asr #31
      3c:	stp	x25, x26, [sp, #64]
      40:	sub	w24, w3, #0x1
      44:	stp	x27, x28, [sp, #80]
      48:	mov	x28, x0
      4c:	add	w0, w20, #0x1
      50:	stp	d8, d9, [sp, #96]
      54:	sub	w0, w0, w0, lsl #2
      58:	stp	d10, d11, [sp, #112]
      5c:	add	w22, w5, w0, lsl #3
      60:	str	d12, [sp, #128]
      64:	sub	sp, sp, #0x250
      68:	ldr	x3, [x2]
      6c:	str	x3, [sp, #584]
      70:	mov	x3, #0x0                   	// #0
      74:	subs	w2, w20, w24
      78:	str	x1, [sp]
      7c:	b.pl	890 <__kernel_rem_pio2.constprop.0+0x890>  // b.nfrst
      80:	str	xzr, [sp, #264]
      84:	cmn	w2, #0x1
      88:	b.eq	a0 <__kernel_rem_pio2.constprop.0+0xa0>  // b.none
      8c:	add	w5, w19, #0x2
      90:	mov	w2, #0x0                   	// #0
      94:	mov	w1, #0x2                   	// #2
      98:	str	xzr, [sp, #272]
      9c:	b	b0 <__kernel_rem_pio2.constprop.0+0xb0>
      a0:	mov	w1, #0x1                   	// #1
      a4:	mov	w2, #0x0                   	// #0
      a8:	sub	w5, w19, w1
      ac:	add	w5, w5, #0x4
      b0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
      b4:	sbfiz	x6, x2, #2, #32
      b8:	add	x3, x0, #0x0
      bc:	add	x25, sp, #0x108
      c0:	ubfiz	x7, x1, #3, #2
      c4:	add	w0, w19, #0x3
      c8:	add	x8, x25, x7
      cc:	ldr	q0, [x3, x6]
      d0:	sxtl	v1.2d, v0.2s
      d4:	sxtl2	v0.2d, v0.4s
      d8:	scvtf	v1.2d, v1.2d
      dc:	scvtf	v0.2d, v0.2d
      e0:	str	q1, [x25, x7]
      e4:	str	q0, [x8, #16]
      e8:	cmp	w5, #0x4
      ec:	b.eq	144 <__kernel_rem_pio2.constprop.0+0x144>  // b.none
      f0:	add	w2, w2, #0x4
      f4:	add	w5, w1, #0x4
      f8:	add	w6, w1, #0x5
      fc:	sbfiz	x7, x2, #2, #32
     100:	sxtw	x5, w5
     104:	ldr	w2, [x3, w2, sxtw #2]
     108:	scvtf	d0, w2
     10c:	str	d0, [x25, x5, lsl #3]
     110:	cmp	w0, w6
     114:	b.lt	144 <__kernel_rem_pio2.constprop.0+0x144>  // b.tstop
     118:	add	x3, x3, x7
     11c:	sxtw	x6, w6
     120:	add	w1, w1, #0x6
     124:	ldr	w2, [x3, #4]
     128:	scvtf	d0, w2
     12c:	str	d0, [x25, x6, lsl #3]
     130:	cmp	w0, w1
     134:	b.lt	144 <__kernel_rem_pio2.constprop.0+0x144>  // b.tstop
     138:	ldr	w1, [x3, #8]
     13c:	scvtf	d0, w1
     140:	str	d0, [sp, #312]
     144:	movi	v0.2d, #0x0
     148:	mov	x2, #0xfffffffffffffff8    	// #-8
     14c:	add	x2, x2, w19, sxtw #3
     150:	ldr	d3, [x28]
     154:	add	x1, x25, x2
     158:	ldr	q2, [x25, x2]
     15c:	mov	v1.16b, v0.16b
     160:	dup	v5.2d, v3.d[0]
     164:	fmla	v1.2d, v2.2d, v3.d[0]
     168:	cbz	w24, 8c8 <__kernel_rem_pio2.constprop.0+0x8c8>
     16c:	ldur	q2, [x1, #-8]
     170:	mov	v0.16b, v1.16b
     174:	ldr	d4, [x28, #8]
     178:	dup	v1.2d, v4.d[0]
     17c:	fmla	v0.2d, v2.2d, v4.d[0]
     180:	cmp	w24, #0x2
     184:	b.ne	194 <__kernel_rem_pio2.constprop.0+0x194>  // b.any
     188:	ldur	q2, [x1, #-16]
     18c:	ldr	d6, [x28, #16]
     190:	fmla	v0.2d, v2.2d, v6.d[0]
     194:	ldr	q6, [x1, #16]
     198:	str	q0, [sp, #96]
     19c:	movi	v2.2d, #0x0
     1a0:	ldur	q0, [x1, #8]
     1a4:	fmla	v2.2d, v6.2d, v5.2d
     1a8:	fmla	v2.2d, v0.2d, v1.2d
     1ac:	cmp	w24, #0x2
     1b0:	b.ne	1c0 <__kernel_rem_pio2.constprop.0+0x1c0>  // b.any
     1b4:	ldr	q0, [x25, x2]
     1b8:	ldr	d1, [x28, #16]
     1bc:	fmla	v2.2d, v0.2d, v1.d[0]
     1c0:	movi	d0, #0x0
     1c4:	ldr	d1, [x25, w0, sxtw #3]
     1c8:	add	w0, w19, #0x2
     1cc:	str	q2, [sp, #112]
     1d0:	fmadd	d0, d1, d3, d0
     1d4:	ldr	d1, [x25, w0, sxtw #3]
     1d8:	fmadd	d0, d4, d1, d0
     1dc:	cmp	w24, #0x2
     1e0:	b.ne	1f0 <__kernel_rem_pio2.constprop.0+0x1f0>  // b.any
     1e4:	ldr	d1, [x28, #16]
     1e8:	ldr	d2, [sp, #296]
     1ec:	fmadd	d0, d2, d1, d0
     1f0:	add	x27, sp, #0x60
     1f4:	add	x23, sp, #0x10
     1f8:	mov	x1, #0x3e70000000000000    	// #4499096027743125504
     1fc:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     200:	fmov	d12, x1
     204:	fmov	d11, x0
     208:	mov	w26, #0x4                   	// #4
     20c:	fmov	d9, #1.250000000000000000e-01
     210:	fmov	d8, #8.000000000000000000e+00
     214:	str	d0, [sp, #128]
     218:	sxtw	x21, w26
     21c:	sbfiz	x1, x26, #3, #32
     220:	ldr	d0, [x27, x21, lsl #3]
     224:	cmp	w26, #0x0
     228:	b.le	268 <__kernel_rem_pio2.constprop.0+0x268>
     22c:	add	x1, x27, x1
     230:	add	w5, w26, #0x1
     234:	mov	x0, #0x1                   	// #1
     238:	fmul	d1, d0, d12
     23c:	add	x2, x23, x0, lsl #2
     240:	ldr	d3, [x1, #-8]!
     244:	add	x0, x0, #0x1
     248:	fcvtzs	w3, d1
     24c:	scvtf	d1, w3
     250:	fmsub	d2, d1, d11, d0
     254:	fadd	d0, d1, d3
     258:	fcvtzs	w3, d2
     25c:	stur	w3, [x2, #-4]
     260:	cmp	x0, x5
     264:	b.ne	238 <__kernel_rem_pio2.constprop.0+0x238>  // b.any
     268:	mov	w0, w22
     26c:	bl	0 <scalbn>
     270:	fmul	d1, d0, d9
     274:	frintm	d1, d1
     278:	fmsub	d0, d1, d8, d0
     27c:	fcvtzs	w5, d0
     280:	scvtf	d1, w5
     284:	fsub	d10, d0, d1
     288:	cmp	w22, #0x0
     28c:	b.le	47c <__kernel_rem_pio2.constprop.0+0x47c>
     290:	sub	w0, w26, #0x1
     294:	mov	w3, #0x18                  	// #24
     298:	sub	w3, w3, w22
     29c:	mov	w6, #0x17                  	// #23
     2a0:	sxtw	x0, w0
     2a4:	sub	w6, w6, w22
     2a8:	ldr	w1, [x23, x0, lsl #2]
     2ac:	asr	w2, w1, w3
     2b0:	add	w5, w5, w2
     2b4:	lsl	w2, w2, w3
     2b8:	sub	w1, w1, w2
     2bc:	str	w1, [x23, x0, lsl #2]
     2c0:	asr	w1, w1, w6
     2c4:	cmp	w1, #0x0
     2c8:	b.gt	754 <__kernel_rem_pio2.constprop.0+0x754>
     2cc:	fcmp	d10, #0.0
     2d0:	b.ne	540 <__kernel_rem_pio2.constprop.0+0x540>  // b.any
     2d4:	sub	w6, w26, #0x1
     2d8:	mov	w2, w6
     2dc:	cmp	w6, #0x3
     2e0:	b.le	3b8 <__kernel_rem_pio2.constprop.0+0x3b8>
     2e4:	sub	w9, w26, #0x5
     2e8:	sub	w3, w26, #0x4
     2ec:	cmp	w9, #0x3
     2f0:	b.ls	7dc <__kernel_rem_pio2.constprop.0+0x7dc>  // b.plast
     2f4:	mov	x0, #0xfffffffffffffff0    	// #-16
     2f8:	lsr	w2, w3, #2
     2fc:	add	x0, x0, w26, sxtw #2
     300:	add	x8, x23, x0
     304:	ldr	q2, [x23, x0]
     308:	cmp	w2, #0x1
     30c:	b.eq	784 <__kernel_rem_pio2.constprop.0+0x784>  // b.none
     310:	ldur	q0, [x8, #-16]
     314:	orr	v0.16b, v0.16b, v2.16b
     318:	cmp	w2, #0x2
     31c:	b.eq	7b4 <__kernel_rem_pio2.constprop.0+0x7b4>  // b.none
     320:	ldur	q2, [x8, #-32]
     324:	orr	v2.16b, v2.16b, v0.16b
     328:	cmp	w2, #0x4
     32c:	b.ne	7c8 <__kernel_rem_pio2.constprop.0+0x7c8>  // b.any
     330:	ldur	q0, [x8, #-48]
     334:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     338:	ldr	q3, [x0]
     33c:	orr	v0.16b, v0.16b, v2.16b
     340:	mov	v1.16b, v0.16b
     344:	tbl	v1.16b, {v0.16b-v1.16b}, v3.16b
     348:	movi	v0.4s, #0x0
     34c:	ext	v2.16b, v1.16b, v0.16b, #8
     350:	orr	v1.16b, v2.16b, v1.16b
     354:	ext	v0.16b, v1.16b, v0.16b, #4
     358:	orr	v0.16b, v0.16b, v1.16b
     35c:	fmov	w0, s0
     360:	tst	x3, #0x3
     364:	b.eq	3b4 <__kernel_rem_pio2.constprop.0+0x3b4>  // b.none
     368:	and	w3, w3, #0xfffffffc
     36c:	sub	w2, w6, w3
     370:	ldr	w3, [x23, w2, sxtw #2]
     374:	sub	w8, w2, #0x1
     378:	orr	w0, w0, w3
     37c:	cmp	w2, #0x4
     380:	b.eq	3b4 <__kernel_rem_pio2.constprop.0+0x3b4>  // b.none
     384:	ldr	w3, [x23, w8, sxtw #2]
     388:	sub	w8, w2, #0x2
     38c:	orr	w0, w0, w3
     390:	cmp	w2, #0x5
     394:	b.eq	3b4 <__kernel_rem_pio2.constprop.0+0x3b4>  // b.none
     398:	ldr	w8, [x23, w8, sxtw #2]
     39c:	sub	w3, w2, #0x3
     3a0:	orr	w0, w0, w8
     3a4:	cmp	w2, #0x6
     3a8:	b.eq	3b4 <__kernel_rem_pio2.constprop.0+0x3b4>  // b.none
     3ac:	ldr	w2, [x23, w3, sxtw #2]
     3b0:	orr	w0, w0, w2
     3b4:	cbnz	w0, 7e4 <__kernel_rem_pio2.constprop.0+0x7e4>
     3b8:	ldr	w0, [sp, #28]
     3bc:	cbnz	w0, 870 <__kernel_rem_pio2.constprop.0+0x870>
     3c0:	ldr	w0, [sp, #24]
     3c4:	cbnz	w0, 860 <__kernel_rem_pio2.constprop.0+0x860>
     3c8:	ldr	w0, [sp, #20]
     3cc:	cbnz	w0, 880 <__kernel_rem_pio2.constprop.0+0x880>
     3d0:	ldr	w2, [sp, #16]
     3d4:	add	w1, w26, #0x1
     3d8:	add	w0, w26, #0x2
     3dc:	cmp	w2, #0x0
     3e0:	cset	w6, eq	// eq = none
     3e4:	add	w6, w6, w26
     3e8:	add	w6, w6, #0x4
     3ec:	add	w2, w1, w24
     3f0:	neg	x7, x21, lsl #3
     3f4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     3f8:	add	x5, x1, #0x0
     3fc:	add	x2, x7, w2, sxtw #3
     400:	add	x5, x5, w20, sxtw #2
     404:	sub	x2, x2, #0x10
     408:	movi	d4, #0x0
     40c:	ldr	d3, [x28]
     410:	add	x2, x25, x2
     414:	sxtw	x0, w0
     418:	sub	x5, x5, #0x4
     41c:	sub	w7, w19, #0x3
     420:	ldr	w1, [x5, x0, lsl #2]
     424:	scvtf	d0, w1
     428:	str	d0, [x2, x0, lsl #3]
     42c:	fmadd	d0, d3, d0, d4
     430:	cbz	w24, 45c <__kernel_rem_pio2.constprop.0+0x45c>
     434:	add	w1, w7, w0
     438:	ldr	d1, [x28, #8]
     43c:	ldr	d2, [x25, w1, sxtw #3]
     440:	fmadd	d0, d2, d1, d0
     444:	cmp	w24, #0x2
     448:	b.ne	45c <__kernel_rem_pio2.constprop.0+0x45c>  // b.any
     44c:	sub	w1, w0, #0x1
     450:	ldr	d2, [x28, #16]
     454:	ldr	d1, [x25, w1, sxtw #3]
     458:	fmadd	d0, d2, d1, d0
     45c:	add	x3, x27, x0, lsl #3
     460:	add	x0, x0, #0x1
     464:	sub	w1, w0, #0x1
     468:	stur	d0, [x3, #-8]
     46c:	cmp	w6, w1
     470:	b.ge	420 <__kernel_rem_pio2.constprop.0+0x420>  // b.tcont
     474:	mov	w26, w6
     478:	b	218 <__kernel_rem_pio2.constprop.0+0x218>
     47c:	b.ne	740 <__kernel_rem_pio2.constprop.0+0x740>  // b.any
     480:	sub	w0, w26, #0x1
     484:	ldr	w1, [x23, w0, sxtw #2]
     488:	asr	w1, w1, #23
     48c:	cmp	w1, #0x0
     490:	b.le	2cc <__kernel_rem_pio2.constprop.0+0x2cc>
     494:	add	w5, w5, #0x1
     498:	cmp	w26, #0x0
     49c:	b.le	8e8 <__kernel_rem_pio2.constprop.0+0x8e8>
     4a0:	ldr	w3, [x23]
     4a4:	mov	x0, x23
     4a8:	mov	w2, #0x0                   	// #0
     4ac:	cbz	w3, 728 <__kernel_rem_pio2.constprop.0+0x728>
     4b0:	mov	w6, #0x1000000             	// #16777216
     4b4:	mov	w8, #0xffffff              	// #16777215
     4b8:	sub	w3, w6, w3
     4bc:	str	w3, [x0]
     4c0:	b	4d0 <__kernel_rem_pio2.constprop.0+0x4d0>
     4c4:	ldr	w3, [x0]
     4c8:	sub	w3, w8, w3
     4cc:	str	w3, [x0]
     4d0:	add	w2, w2, #0x1
     4d4:	add	x0, x0, #0x4
     4d8:	cmp	w26, w2
     4dc:	b.gt	4c4 <__kernel_rem_pio2.constprop.0+0x4c4>
     4e0:	mov	w3, #0x1                   	// #1
     4e4:	cmp	w22, #0x0
     4e8:	b.le	510 <__kernel_rem_pio2.constprop.0+0x510>
     4ec:	cmp	w22, #0x1
     4f0:	b.eq	76c <__kernel_rem_pio2.constprop.0+0x76c>  // b.none
     4f4:	cmp	w22, #0x2
     4f8:	b.ne	510 <__kernel_rem_pio2.constprop.0+0x510>  // b.any
     4fc:	sub	w0, w26, #0x1
     500:	sxtw	x0, w0
     504:	ldr	w2, [x23, x0, lsl #2]
     508:	and	w2, w2, #0x3fffff
     50c:	str	w2, [x23, x0, lsl #2]
     510:	cmp	w1, #0x2
     514:	b.ne	2cc <__kernel_rem_pio2.constprop.0+0x2cc>  // b.any
     518:	fmov	d0, #1.000000000000000000e+00
     51c:	fsub	d10, d0, d10
     520:	cbz	w3, 2cc <__kernel_rem_pio2.constprop.0+0x2cc>
     524:	mov	w0, w22
     528:	stp	w5, w1, [sp, #8]
     52c:	bl	0 <scalbn>
     530:	fsub	d10, d10, d0
     534:	ldp	w5, w1, [sp, #8]
     538:	fcmp	d10, #0.0
     53c:	b.eq	2d4 <__kernel_rem_pio2.constprop.0+0x2d4>  // b.none
     540:	fmov	d0, d10
     544:	neg	w0, w22
     548:	stp	w5, w1, [sp, #8]
     54c:	bl	0 <scalbn>
     550:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     554:	fmov	d2, x0
     558:	ldp	w5, w1, [sp, #8]
     55c:	fcmpe	d0, d2
     560:	b.ge	898 <__kernel_rem_pio2.constprop.0+0x898>  // b.tcont
     564:	fcvtzs	w0, d0
     568:	str	w0, [x23, x21, lsl #2]
     56c:	fmov	d0, #1.000000000000000000e+00
     570:	mov	w0, w22
     574:	stp	w5, w1, [sp, #8]
     578:	bl	0 <scalbn>
     57c:	fmov	d1, d0
     580:	ldp	w5, w1, [sp, #8]
     584:	tbnz	w26, #31, 828 <__kernel_rem_pio2.constprop.0+0x828>
     588:	sub	w7, w26, #0x1
     58c:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     590:	fmov	d2, x0
     594:	mov	x8, #0xfffffffffffffffe    	// #-2
     598:	sxtw	x7, w7
     59c:	mov	x0, x7
     5a0:	add	x3, x23, x0, lsl #2
     5a4:	add	x2, x27, x0, lsl #3
     5a8:	sub	x0, x0, #0x1
     5ac:	ldr	w3, [x3, #4]
     5b0:	scvtf	d0, w3
     5b4:	fmul	d0, d0, d1
     5b8:	fmul	d1, d1, d2
     5bc:	str	d0, [x2, #8]
     5c0:	cmp	x8, x0
     5c4:	b.ne	5a0 <__kernel_rem_pio2.constprop.0+0x5a0>  // b.any
     5c8:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     5cc:	mov	x0, #0x442d00000000        	// #74960064217088
     5d0:	movk	x0, #0x3e74, lsl #48
     5d4:	add	x9, sp, #0x1a8
     5d8:	ldr	d3, [x3]
     5dc:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     5e0:	fmov	d4, x0
     5e4:	movi	d2, #0x0
     5e8:	ldr	d5, [x3]
     5ec:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     5f0:	mov	x6, x9
     5f4:	mov	x2, x7
     5f8:	ldr	d7, [x3]
     5fc:	adrp	x3, 0 <__kernel_rem_pio2.constprop.0>
     600:	mov	w0, #0x0                   	// #0
     604:	ldr	d6, [x3]
     608:	b	610 <__kernel_rem_pio2.constprop.0+0x610>
     60c:	mov	w0, w3
     610:	add	x3, x27, x2, lsl #3
     614:	ldr	d0, [x3, #8]
     618:	fmadd	d0, d0, d3, d2
     61c:	cbz	w0, 668 <__kernel_rem_pio2.constprop.0+0x668>
     620:	add	w4, w2, #0x2
     624:	ldr	d1, [x27, w4, sxtw #3]
     628:	fmadd	d0, d1, d4, d0
     62c:	cmp	w0, #0x1
     630:	b.eq	668 <__kernel_rem_pio2.constprop.0+0x668>  // b.none
     634:	add	w4, w2, #0x3
     638:	ldr	d1, [x27, w4, sxtw #3]
     63c:	fmadd	d0, d1, d5, d0
     640:	cmp	w0, #0x2
     644:	b.eq	668 <__kernel_rem_pio2.constprop.0+0x668>  // b.none
     648:	add	w4, w2, #0x4
     64c:	ldr	d1, [x27, w4, sxtw #3]
     650:	fmadd	d0, d1, d7, d0
     654:	cmp	w0, #0x3
     658:	b.eq	668 <__kernel_rem_pio2.constprop.0+0x668>  // b.none
     65c:	add	w3, w2, #0x5
     660:	ldr	d1, [x27, w3, sxtw #3]
     664:	fmadd	d0, d1, d6, d0
     668:	str	d0, [x6], #8
     66c:	sub	x2, x2, #0x1
     670:	add	w3, w0, #0x1
     674:	cmp	w26, w0
     678:	b.ne	60c <__kernel_rem_pio2.constprop.0+0x60c>  // b.any
     67c:	movi	d1, #0x0
     680:	add	x0, x9, x7, lsl #3
     684:	sub	x7, x7, #0x1
     688:	ldr	d0, [x0, #8]
     68c:	fadd	d1, d1, d0
     690:	cmp	x8, x7
     694:	b.ne	680 <__kernel_rem_pio2.constprop.0+0x680>  // b.any
     698:	ldr	d0, [sp, #424]
     69c:	fsub	d0, d0, d1
     6a0:	cbnz	w1, 904 <__kernel_rem_pio2.constprop.0+0x904>
     6a4:	ldr	x0, [sp]
     6a8:	str	d1, [x0]
     6ac:	cbz	w26, 6d4 <__kernel_rem_pio2.constprop.0+0x6d4>
     6b0:	add	x2, sp, #0x1b0
     6b4:	mov	w0, #0x1                   	// #1
     6b8:	ldr	d1, [x2], #8
     6bc:	add	w0, w0, #0x1
     6c0:	fadd	d0, d0, d1
     6c4:	cmp	w0, w26
     6c8:	b.le	6b8 <__kernel_rem_pio2.constprop.0+0x6b8>
     6cc:	cbz	w1, 6d4 <__kernel_rem_pio2.constprop.0+0x6d4>
     6d0:	fneg	d0, d0
     6d4:	ldr	x0, [sp]
     6d8:	adrp	x1, 0 <__stack_chk_guard>
     6dc:	ldr	x1, [x1]
     6e0:	str	d0, [x0, #8]
     6e4:	and	w0, w5, #0x7
     6e8:	ldr	x3, [sp, #584]
     6ec:	ldr	x2, [x1]
     6f0:	subs	x3, x3, x2
     6f4:	mov	x2, #0x0                   	// #0
     6f8:	b.ne	950 <__kernel_rem_pio2.constprop.0+0x950>  // b.any
     6fc:	add	sp, sp, #0x250
     700:	ldp	x19, x20, [sp, #16]
     704:	ldp	x21, x22, [sp, #32]
     708:	ldp	x23, x24, [sp, #48]
     70c:	ldp	x25, x26, [sp, #64]
     710:	ldp	x27, x28, [sp, #80]
     714:	ldp	d8, d9, [sp, #96]
     718:	ldp	d10, d11, [sp, #112]
     71c:	ldr	d12, [sp, #128]
     720:	ldp	x29, x30, [sp], #144
     724:	ret
     728:	add	w2, w2, #0x1
     72c:	add	x0, x0, #0x4
     730:	cmp	w26, w2
     734:	b.le	4e4 <__kernel_rem_pio2.constprop.0+0x4e4>
     738:	ldr	w3, [x0]
     73c:	b	4ac <__kernel_rem_pio2.constprop.0+0x4ac>
     740:	fmov	d0, #5.000000000000000000e-01
     744:	fcmpe	d10, d0
     748:	b.ge	83c <__kernel_rem_pio2.constprop.0+0x83c>  // b.tcont
     74c:	mov	w1, #0x0                   	// #0
     750:	b	2cc <__kernel_rem_pio2.constprop.0+0x2cc>
     754:	add	w5, w5, #0x1
     758:	cmp	w26, #0x0
     75c:	b.gt	4a0 <__kernel_rem_pio2.constprop.0+0x4a0>
     760:	mov	w3, #0x0                   	// #0
     764:	cmp	w22, #0x1
     768:	b.ne	4f4 <__kernel_rem_pio2.constprop.0+0x4f4>  // b.any
     76c:	sub	w0, w26, #0x1
     770:	sxtw	x0, w0
     774:	ldr	w2, [x23, x0, lsl #2]
     778:	and	w2, w2, #0x7fffff
     77c:	str	w2, [x23, x0, lsl #2]
     780:	b	510 <__kernel_rem_pio2.constprop.0+0x510>
     784:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     788:	mov	w2, w9
     78c:	mov	v3.16b, v2.16b
     790:	ldr	q1, [x0]
     794:	movi	v0.4s, #0x0
     798:	tbl	v2.16b, {v2.16b-v3.16b}, v1.16b
     79c:	ext	v1.16b, v2.16b, v0.16b, #8
     7a0:	orr	v1.16b, v1.16b, v2.16b
     7a4:	ext	v0.16b, v1.16b, v0.16b, #4
     7a8:	orr	v0.16b, v0.16b, v1.16b
     7ac:	fmov	w0, s0
     7b0:	b	370 <__kernel_rem_pio2.constprop.0+0x370>
     7b4:	mov	v1.16b, v0.16b
     7b8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     7bc:	ldr	q2, [x0]
     7c0:	tbl	v1.16b, {v0.16b-v1.16b}, v2.16b
     7c4:	b	348 <__kernel_rem_pio2.constprop.0+0x348>
     7c8:	mov	v3.16b, v2.16b
     7cc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     7d0:	ldr	q0, [x0]
     7d4:	tbl	v1.16b, {v2.16b-v3.16b}, v0.16b
     7d8:	b	348 <__kernel_rem_pio2.constprop.0+0x348>
     7dc:	mov	w0, #0x0                   	// #0
     7e0:	b	370 <__kernel_rem_pio2.constprop.0+0x370>
     7e4:	ldr	w0, [x23, w6, sxtw #2]
     7e8:	mov	w26, w6
     7ec:	sub	w22, w22, #0x18
     7f0:	add	x7, x23, x21, lsl #2
     7f4:	cbnz	w0, 91c <__kernel_rem_pio2.constprop.0+0x91c>
     7f8:	ldur	w0, [x7, #-8]
     7fc:	sub	x7, x7, #0x4
     800:	sub	w26, w26, #0x1
     804:	sub	w22, w22, #0x18
     808:	cbz	w0, 7f8 <__kernel_rem_pio2.constprop.0+0x7f8>
     80c:	fmov	d0, #1.000000000000000000e+00
     810:	mov	w0, w22
     814:	stp	w5, w1, [sp, #8]
     818:	bl	0 <scalbn>
     81c:	fmov	d1, d0
     820:	ldp	w5, w1, [sp, #8]
     824:	tbz	w26, #31, 588 <__kernel_rem_pio2.constprop.0+0x588>
     828:	ldr	d0, [sp, #424]
     82c:	cbnz	w1, 938 <__kernel_rem_pio2.constprop.0+0x938>
     830:	ldr	x0, [sp]
     834:	str	xzr, [x0]
     838:	b	6d4 <__kernel_rem_pio2.constprop.0+0x6d4>
     83c:	add	w5, w5, #0x1
     840:	mov	w1, #0x2                   	// #2
     844:	cmp	w26, #0x0
     848:	b.gt	4a0 <__kernel_rem_pio2.constprop.0+0x4a0>
     84c:	fmov	d0, #1.000000000000000000e+00
     850:	fsub	d10, d0, d10
     854:	fcmp	d10, #0.0
     858:	b.eq	3b8 <__kernel_rem_pio2.constprop.0+0x3b8>  // b.none
     85c:	b	540 <__kernel_rem_pio2.constprop.0+0x540>
     860:	add	w0, w26, #0x2
     864:	add	w1, w26, #0x1
     868:	mov	w6, w0
     86c:	b	3ec <__kernel_rem_pio2.constprop.0+0x3ec>
     870:	add	w1, w26, #0x1
     874:	add	w0, w26, #0x2
     878:	mov	w6, w1
     87c:	b	3ec <__kernel_rem_pio2.constprop.0+0x3ec>
     880:	add	w6, w26, #0x3
     884:	add	w1, w26, #0x1
     888:	add	w0, w26, #0x2
     88c:	b	3ec <__kernel_rem_pio2.constprop.0+0x3ec>
     890:	mov	w1, #0x0                   	// #0
     894:	b	a8 <__kernel_rem_pio2.constprop.0+0xa8>
     898:	mov	x0, #0x3e70000000000000    	// #4499096027743125504
     89c:	fmov	d1, x0
     8a0:	add	w26, w26, #0x1
     8a4:	add	w22, w22, #0x18
     8a8:	fmul	d1, d0, d1
     8ac:	fcvtzs	w0, d1
     8b0:	scvtf	d1, w0
     8b4:	fmsub	d0, d1, d2, d0
     8b8:	fcvtzs	w2, d0
     8bc:	str	w2, [x23, x21, lsl #2]
     8c0:	str	w0, [x23, w26, sxtw #2]
     8c4:	b	56c <__kernel_rem_pio2.constprop.0+0x56c>
     8c8:	ldr	q4, [x1, #16]
     8cc:	str	q1, [sp, #96]
     8d0:	ldr	d2, [sp, #296]
     8d4:	mov	v1.16b, v0.16b
     8d8:	fmadd	d0, d2, d3, d0
     8dc:	fmla	v1.2d, v4.2d, v5.2d
     8e0:	str	q1, [sp, #112]
     8e4:	b	1f0 <__kernel_rem_pio2.constprop.0+0x1f0>
     8e8:	cmp	w1, #0x2
     8ec:	b.ne	8f8 <__kernel_rem_pio2.constprop.0+0x8f8>  // b.any
     8f0:	fmov	d0, #1.000000000000000000e+00
     8f4:	fsub	d10, d0, d10
     8f8:	fcmp	d10, #0.0
     8fc:	b.eq	3b8 <__kernel_rem_pio2.constprop.0+0x3b8>  // b.none
     900:	b	540 <__kernel_rem_pio2.constprop.0+0x540>
     904:	ldr	x0, [sp]
     908:	fneg	d1, d1
     90c:	str	d1, [x0]
     910:	cbnz	w26, 6b0 <__kernel_rem_pio2.constprop.0+0x6b0>
     914:	fneg	d0, d0
     918:	b	6d4 <__kernel_rem_pio2.constprop.0+0x6d4>
     91c:	fmov	d0, #1.000000000000000000e+00
     920:	mov	w0, w22
     924:	stp	w5, w1, [sp, #8]
     928:	bl	0 <scalbn>
     92c:	fmov	d1, d0
     930:	ldp	w5, w1, [sp, #8]
     934:	b	588 <__kernel_rem_pio2.constprop.0+0x588>
     938:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
     93c:	fmov	d1, x0
     940:	ldr	x0, [sp]
     944:	fneg	d0, d0
     948:	str	d1, [x0]
     94c:	b	6d4 <__kernel_rem_pio2.constprop.0+0x6d4>
     950:	bl	0 <__stack_chk_fail>

0000000000000954 <__ieee754_rem_pio2>:
     954:	sub	sp, sp, #0x40
     958:	fmov	x4, d0
     95c:	adrp	x1, 0 <__stack_chk_guard>
     960:	ldr	x1, [x1]
     964:	stp	x29, x30, [sp, #32]
     968:	add	x29, sp, #0x20
     96c:	ubfx	x5, x4, #32, #31
     970:	stp	x19, x20, [sp, #48]
     974:	mov	x19, x0
     978:	mov	w0, #0x21fb                	// #8699
     97c:	ldr	x2, [x1]
     980:	str	x2, [sp, #24]
     984:	mov	x2, #0x0                   	// #0
     988:	movk	w0, #0x3fe9, lsl #16
     98c:	cmp	w5, w0
     990:	b.le	ab0 <__ieee754_rem_pio2+0x15c>
     994:	mov	w0, #0xd97b                	// #55675
     998:	lsr	x20, x4, #32
     99c:	movk	w0, #0x4002, lsl #16
     9a0:	cmp	w5, w0
     9a4:	b.gt	a14 <__ieee754_rem_pio2+0xc0>
     9a8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     9ac:	ldr	d1, [x0]
     9b0:	mov	w0, #0x21fb                	// #8699
     9b4:	movk	w0, #0x3ff9, lsl #16
     9b8:	cmp	w20, #0x0
     9bc:	b.le	c00 <__ieee754_rem_pio2+0x2ac>
     9c0:	fsub	d0, d0, d1
     9c4:	cmp	w5, w0
     9c8:	b.eq	bac <__ieee754_rem_pio2+0x258>  // b.none
     9cc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     9d0:	ldr	d2, [x0]
     9d4:	fsub	d1, d0, d2
     9d8:	fsub	d0, d0, d1
     9dc:	fsub	d0, d0, d2
     9e0:	mov	w0, #0x1                   	// #1
     9e4:	stp	d1, d0, [x19]
     9e8:	adrp	x1, 0 <__stack_chk_guard>
     9ec:	ldr	x1, [x1]
     9f0:	ldr	x3, [sp, #24]
     9f4:	ldr	x2, [x1]
     9f8:	subs	x3, x3, x2
     9fc:	mov	x2, #0x0                   	// #0
     a00:	b.ne	c50 <__ieee754_rem_pio2+0x2fc>  // b.any
     a04:	ldp	x29, x30, [sp, #32]
     a08:	ldp	x19, x20, [sp, #48]
     a0c:	add	sp, sp, #0x40
     a10:	ret
     a14:	mov	w0, #0x21fb                	// #8699
     a18:	movk	w0, #0x4139, lsl #16
     a1c:	cmp	w5, w0
     a20:	b.le	ac0 <__ieee754_rem_pio2+0x16c>
     a24:	mov	w0, #0x7fefffff            	// #2146435071
     a28:	cmp	w5, w0
     a2c:	b.gt	be4 <__ieee754_rem_pio2+0x290>
     a30:	asr	w2, w5, #20
     a34:	mov	x0, #0x4170000000000000    	// #4715268809856909312
     a38:	sub	w2, w2, #0x416
     a3c:	fmov	d1, x0
     a40:	mov	w3, #0x3                   	// #3
     a44:	sub	w5, w5, w2, lsl #20
     a48:	bfi	x4, x5, #32, #32
     a4c:	fmov	d0, x4
     a50:	fcvtzs	w0, d0
     a54:	scvtf	d2, w0
     a58:	fsub	d0, d0, d2
     a5c:	str	d2, [sp]
     a60:	fmul	d0, d0, d1
     a64:	fcvtzs	w0, d0
     a68:	scvtf	d2, w0
     a6c:	fsub	d0, d0, d2
     a70:	fmul	d0, d0, d1
     a74:	fcmp	d0, #0.0
     a78:	stp	d2, d0, [sp, #8]
     a7c:	b.ne	a8c <__ieee754_rem_pio2+0x138>  // b.any
     a80:	cmp	w0, #0x0
     a84:	cset	w3, ne	// ne = any
     a88:	add	w3, w3, #0x1
     a8c:	mov	x1, x19
     a90:	mov	x0, sp
     a94:	bl	0 <__kernel_rem_pio2.constprop.0>
     a98:	tbz	w20, #31, 9e8 <__ieee754_rem_pio2+0x94>
     a9c:	ldr	q0, [x19]
     aa0:	neg	w0, w0
     aa4:	fneg	v0.2d, v0.2d
     aa8:	str	q0, [x19]
     aac:	b	9e8 <__ieee754_rem_pio2+0x94>
     ab0:	mov	w0, #0x0                   	// #0
     ab4:	str	d0, [x19]
     ab8:	str	xzr, [x19, #8]
     abc:	b	9e8 <__ieee754_rem_pio2+0x94>
     ac0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ac4:	fabs	d0, d0
     ac8:	fmov	d2, #5.000000000000000000e-01
     acc:	ldr	d3, [x0]
     ad0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ad4:	ldr	d4, [x0]
     ad8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     adc:	fmadd	d2, d0, d3, d2
     ae0:	ldr	d1, [x0]
     ae4:	fcvtzs	w0, d2
     ae8:	scvtf	d3, w0
     aec:	fmsub	d0, d3, d4, d0
     af0:	fmul	d1, d3, d1
     af4:	fsub	d2, d0, d1
     af8:	cmp	w0, #0x1f
     afc:	b.gt	b34 <__ieee754_rem_pio2+0x1e0>
     b00:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b04:	add	x1, x1, #0x0
     b08:	add	x1, x1, #0x110
     b0c:	sub	w2, w0, #0x1
     b10:	ldr	w1, [x1, w2, sxtw #2]
     b14:	cmp	w1, w5
     b18:	b.eq	b34 <__ieee754_rem_pio2+0x1e0>  // b.none
     b1c:	str	d2, [x19]
     b20:	fsub	d0, d0, d2
     b24:	fsub	d0, d0, d1
     b28:	tbnz	w20, #31, bd0 <__ieee754_rem_pio2+0x27c>
     b2c:	str	d0, [x19, #8]
     b30:	b	9e8 <__ieee754_rem_pio2+0x94>
     b34:	fmov	x1, d2
     b38:	asr	w5, w5, #20
     b3c:	ubfx	x1, x1, #52, #11
     b40:	sub	w1, w5, w1
     b44:	cmp	w1, #0x10
     b48:	b.le	b1c <__ieee754_rem_pio2+0x1c8>
     b4c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b50:	ldr	d2, [x1]
     b54:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b58:	ldr	d1, [x1]
     b5c:	fmsub	d4, d3, d2, d0
     b60:	fsub	d0, d0, d4
     b64:	fmsub	d0, d3, d2, d0
     b68:	fnmsub	d1, d3, d1, d0
     b6c:	fsub	d2, d4, d1
     b70:	fmov	x1, d2
     b74:	ubfx	x1, x1, #52, #11
     b78:	sub	w5, w5, w1
     b7c:	cmp	w5, #0x31
     b80:	b.le	bf4 <__ieee754_rem_pio2+0x2a0>
     b84:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b88:	ldr	d2, [x1]
     b8c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
     b90:	ldr	d1, [x1]
     b94:	fmsub	d0, d3, d2, d4
     b98:	fsub	d4, d4, d0
     b9c:	fmsub	d4, d3, d2, d4
     ba0:	fnmsub	d1, d3, d1, d4
     ba4:	fsub	d2, d0, d1
     ba8:	b	b1c <__ieee754_rem_pio2+0x1c8>
     bac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     bb0:	ldr	d1, [x0]
     bb4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     bb8:	ldr	d2, [x0]
     bbc:	fsub	d0, d0, d1
     bc0:	fsub	d1, d0, d2
     bc4:	fsub	d0, d0, d1
     bc8:	fsub	d0, d0, d2
     bcc:	b	9e0 <__ieee754_rem_pio2+0x8c>
     bd0:	mov	v2.d[1], v0.d[0]
     bd4:	neg	w0, w0
     bd8:	fneg	v2.2d, v2.2d
     bdc:	str	q2, [x19]
     be0:	b	9e8 <__ieee754_rem_pio2+0x94>
     be4:	fsub	d0, d0, d0
     be8:	mov	w0, #0x0                   	// #0
     bec:	stp	d0, d0, [x19]
     bf0:	b	9e8 <__ieee754_rem_pio2+0x94>
     bf4:	fmov	d0, d4
     bf8:	str	d2, [x19]
     bfc:	b	b20 <__ieee754_rem_pio2+0x1cc>
     c00:	fadd	d0, d0, d1
     c04:	cmp	w5, w0
     c08:	b.eq	c2c <__ieee754_rem_pio2+0x2d8>  // b.none
     c0c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c10:	ldr	d2, [x0]
     c14:	fadd	d1, d0, d2
     c18:	fsub	d0, d0, d1
     c1c:	fadd	d0, d0, d2
     c20:	mov	w0, #0xffffffff            	// #-1
     c24:	stp	d1, d0, [x19]
     c28:	b	9e8 <__ieee754_rem_pio2+0x94>
     c2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c30:	ldr	d1, [x0]
     c34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c38:	ldr	d2, [x0]
     c3c:	fadd	d0, d0, d1
     c40:	fadd	d1, d0, d2
     c44:	fsub	d0, d0, d1
     c48:	fadd	d0, d0, d2
     c4c:	b	c20 <__ieee754_rem_pio2+0x2cc>
     c50:	bl	0 <__stack_chk_fail>

0000000000000c54 <pts_ieee754_acos>:
     c54:	fmov	x1, d0
     c58:	mov	w2, #0x3fefffff            	// #1072693247
     c5c:	ubfx	x0, x1, #32, #31
     c60:	lsr	x3, x1, #32
     c64:	cmp	w0, w2
     c68:	b.le	c94 <pts_ieee754_acos+0x40>
     c6c:	mov	w2, #0xc0100000            	// #-1072693248
     c70:	add	w0, w0, w2
     c74:	orr	w0, w0, w1
     c78:	cbnz	w0, cf4 <pts_ieee754_acos+0xa0>
     c7c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     c80:	movi	d1, #0x0
     c84:	cmp	w3, #0x0
     c88:	ldr	d0, [x0]
     c8c:	fcsel	d0, d0, d1, le
     c90:	ret
     c94:	stp	x29, x30, [sp, #-48]!
     c98:	mov	w1, #0x3fdfffff            	// #1071644671
     c9c:	mov	x29, sp
     ca0:	cmp	w0, w1
     ca4:	b.gt	cc4 <pts_ieee754_acos+0x70>
     ca8:	mov	w1, #0x3c600000            	// #1012924416
     cac:	cmp	w0, w1
     cb0:	b.gt	db4 <pts_ieee754_acos+0x160>
     cb4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     cb8:	ldr	d0, [x0]
     cbc:	ldp	x29, x30, [sp], #48
     cc0:	ret
     cc4:	stp	d8, d9, [sp, #16]
     cc8:	tbnz	w3, #31, e68 <pts_ieee754_acos+0x214>
     ccc:	fmov	d8, #1.000000000000000000e+00
     cd0:	fmov	d1, #5.000000000000000000e-01
     cd4:	fsub	d8, d8, d0
     cd8:	fmul	d8, d8, d1
     cdc:	fcmp	d8, #0.0
     ce0:	b.pl	d00 <pts_ieee754_acos+0xac>  // b.nfrst
     ce4:	fmov	d0, d8
     ce8:	bl	0 <sqrt>
     cec:	fmov	d3, d0
     cf0:	b	d04 <pts_ieee754_acos+0xb0>
     cf4:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     cf8:	fmov	d0, x0
     cfc:	ret
     d00:	fsqrt	d3, d8
     d04:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d08:	fmov	d4, #1.000000000000000000e+00
     d0c:	ldr	d1, [x0]
     d10:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d14:	ldr	d19, [x0]
     d18:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d1c:	fmadd	d19, d8, d1, d19
     d20:	ldr	d17, [x0]
     d24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d28:	ldr	d0, [x0]
     d2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d30:	ldr	d18, [x0]
     d34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d38:	fmadd	d18, d8, d0, d18
     d3c:	movi	v0.2d, #0xffffffff00000000
     d40:	ldr	d7, [x0]
     d44:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d48:	fmadd	d17, d19, d8, d17
     d4c:	ldr	d16, [x0]
     d50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d54:	and	v2.8b, v3.8b, v0.8b
     d58:	ldr	d5, [x0]
     d5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     d60:	ldr	d6, [x0]
     d64:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     d68:	fmadd	d16, d18, d8, d16
     d6c:	movk	x0, #0x3fc5, lsl #48
     d70:	fmov	d1, x0
     d74:	fmsub	d0, d2, d2, d8
     d78:	fmadd	d7, d17, d8, d7
     d7c:	fadd	d9, d2, d3
     d80:	fmadd	d6, d16, d8, d6
     d84:	fdiv	d0, d0, d9
     d88:	fmadd	d5, d7, d8, d5
     d8c:	fmadd	d4, d6, d8, d4
     d90:	fmadd	d1, d5, d8, d1
     d94:	fmul	d1, d1, d8
     d98:	ldp	d8, d9, [sp, #16]
     d9c:	ldp	x29, x30, [sp], #48
     da0:	fdiv	d1, d1, d4
     da4:	fmadd	d0, d1, d3, d0
     da8:	fadd	d0, d0, d2
     dac:	fadd	d0, d0, d0
     db0:	ret
     db4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     db8:	fmul	d2, d0, d0
     dbc:	stp	d8, d9, [sp, #16]
     dc0:	fmov	d5, #1.000000000000000000e+00
     dc4:	ldr	d3, [x0]
     dc8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     dcc:	ldr	d18, [x0]
     dd0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     dd4:	fmadd	d18, d2, d3, d18
     dd8:	ldr	d16, [x0]
     ddc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     de0:	ldr	d1, [x0]
     de4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     de8:	ldr	d17, [x0]
     dec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     df0:	fmadd	d17, d2, d1, d17
     df4:	ldr	d8, [x0]
     df8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     dfc:	fmadd	d16, d18, d2, d16
     e00:	ldr	d9, [x0]
     e04:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e08:	ldr	d6, [x0]
     e0c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e10:	ldr	d7, [x0]
     e14:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     e18:	fmadd	d9, d17, d2, d9
     e1c:	movk	x0, #0x3fc5, lsl #48
     e20:	fmov	d3, x0
     e24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e28:	fmadd	d8, d16, d2, d8
     e2c:	ldr	d4, [x0]
     e30:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e34:	ldr	d1, [x0]
     e38:	fmadd	d7, d9, d2, d7
     e3c:	fmadd	d6, d8, d2, d6
     e40:	ldp	d8, d9, [sp, #16]
     e44:	ldp	x29, x30, [sp], #48
     e48:	fmadd	d5, d7, d2, d5
     e4c:	fmadd	d3, d6, d2, d3
     e50:	fmul	d2, d3, d2
     e54:	fdiv	d2, d2, d5
     e58:	fmsub	d2, d0, d2, d4
     e5c:	fsub	d0, d0, d2
     e60:	fsub	d0, d1, d0
     e64:	ret
     e68:	fmov	d1, #1.000000000000000000e+00
     e6c:	fmov	d3, #5.000000000000000000e-01
     e70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e74:	fadd	d0, d0, d1
     e78:	ldr	d17, [x0]
     e7c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e80:	ldr	d9, [x0]
     e84:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e88:	fmul	d0, d0, d3
     e8c:	ldr	d6, [x0]
     e90:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e94:	ldr	d16, [x0]
     e98:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     e9c:	fmadd	d9, d0, d17, d9
     ea0:	fcmp	d0, #0.0
     ea4:	ldr	d4, [x0]
     ea8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     eac:	ldr	d7, [x0]
     eb0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     eb4:	fmadd	d7, d0, d16, d7
     eb8:	ldr	d2, [x0]
     ebc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ec0:	ldr	d5, [x0]
     ec4:	mov	x0, #0x5555555555555555    	// #6148914691236517205
     ec8:	fmadd	d6, d9, d0, d6
     ecc:	movk	x0, #0x3fc5, lsl #48
     ed0:	fmov	d8, x0
     ed4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     ed8:	ldr	d3, [x0]
     edc:	fmadd	d5, d7, d0, d5
     ee0:	fmadd	d4, d6, d0, d4
     ee4:	fmadd	d3, d5, d0, d3
     ee8:	fmadd	d2, d4, d0, d2
     eec:	fmadd	d3, d3, d0, d1
     ef0:	fmadd	d8, d2, d0, d8
     ef4:	fmul	d8, d8, d0
     ef8:	b.pl	f10 <pts_ieee754_acos+0x2bc>  // b.nfrst
     efc:	str	d3, [sp, #40]
     f00:	bl	0 <sqrt>
     f04:	ldr	d3, [sp, #40]
     f08:	fmov	d1, d0
     f0c:	b	f14 <pts_ieee754_acos+0x2c0>
     f10:	fsqrt	d1, d0
     f14:	fdiv	d8, d8, d3
     f18:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f1c:	fmov	d3, #2.000000000000000000e+00
     f20:	ldr	d2, [x0]
     f24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f28:	ldr	d0, [x0]
     f2c:	fmadd	d2, d8, d1, d2
     f30:	ldp	d8, d9, [sp, #16]
     f34:	ldp	x29, x30, [sp], #48
     f38:	fadd	d1, d2, d1
     f3c:	fmsub	d0, d1, d3, d0
     f40:	ret

0000000000000f44 <pts_ieee754_asin>:
     f44:	fmov	x0, d0
     f48:	stp	x29, x30, [sp, #-64]!
     f4c:	fmov	d1, d0
     f50:	mov	x29, sp
     f54:	stp	x19, x20, [sp, #16]
     f58:	mov	w1, #0x3fefffff            	// #1072693247
     f5c:	ubfx	x19, x0, #32, #31
     f60:	cmp	w19, w1
     f64:	b.le	fb0 <pts_ieee754_asin+0x6c>
     f68:	mov	w1, #0xc0100000            	// #-1072693248
     f6c:	add	w19, w19, w1
     f70:	orr	w19, w19, w0
     f74:	cbz	w19, f8c <pts_ieee754_asin+0x48>
     f78:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
     f7c:	fmov	d0, x0
     f80:	ldp	x19, x20, [sp, #16]
     f84:	ldp	x29, x30, [sp], #64
     f88:	ret
     f8c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f90:	ldp	x19, x20, [sp, #16]
     f94:	ldr	d0, [x0]
     f98:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     f9c:	ldr	d2, [x0]
     fa0:	fmul	d0, d1, d0
     fa4:	ldp	x29, x30, [sp], #64
     fa8:	fmadd	d0, d1, d2, d0
     fac:	ret
     fb0:	lsr	x20, x0, #32
     fb4:	mov	w0, #0x3fdfffff            	// #1071644671
     fb8:	cmp	w19, w0
     fbc:	b.gt	ff8 <pts_ieee754_asin+0xb4>
     fc0:	mov	w0, #0x3e3fffff            	// #1044381695
     fc4:	cmp	w19, w0
     fc8:	b.gt	1100 <pts_ieee754_asin+0x1bc>
     fcc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
     fd0:	fmov	d3, #1.000000000000000000e+00
     fd4:	ldr	d2, [x0]
     fd8:	fadd	d2, d0, d2
     fdc:	fcmpe	d2, d3
     fe0:	b.gt	f80 <pts_ieee754_asin+0x3c>
     fe4:	movi	d0, #0x0
     fe8:	fmadd	d0, d1, d0, d1
     fec:	ldp	x19, x20, [sp, #16]
     ff0:	ldp	x29, x30, [sp], #64
     ff4:	ret
     ff8:	fabs	d1, d0
     ffc:	fmov	d0, #1.000000000000000000e+00
    1000:	fmov	d18, #5.000000000000000000e-01
    1004:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1008:	stp	d8, d9, [sp, #32]
    100c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1010:	ldr	d17, [x0]
    1014:	fsub	d1, d0, d1
    1018:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    101c:	ldr	d3, [x1]
    1020:	ldr	d9, [x0]
    1024:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1028:	fmul	d1, d1, d18
    102c:	ldr	d6, [x0]
    1030:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1034:	ldr	d16, [x0]
    1038:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    103c:	fmadd	d9, d1, d17, d9
    1040:	fcmp	d1, #0.0
    1044:	ldr	d4, [x0]
    1048:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    104c:	ldr	d7, [x0]
    1050:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1054:	fmadd	d7, d1, d16, d7
    1058:	ldr	d2, [x0]
    105c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1060:	ldr	d5, [x0]
    1064:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1068:	fmadd	d6, d9, d1, d6
    106c:	movk	x0, #0x3fc5, lsl #48
    1070:	fmov	d8, x0
    1074:	fmadd	d5, d7, d1, d5
    1078:	fmadd	d4, d6, d1, d4
    107c:	fmadd	d3, d5, d1, d3
    1080:	fmadd	d2, d4, d1, d2
    1084:	fmadd	d3, d3, d1, d0
    1088:	fmadd	d8, d2, d1, d8
    108c:	fmul	d8, d8, d1
    1090:	b.pl	10ac <pts_ieee754_asin+0x168>  // b.nfrst
    1094:	fmov	d0, d1
    1098:	stp	d1, d3, [sp, #48]
    109c:	bl	0 <sqrt>
    10a0:	fmov	d2, d0
    10a4:	ldp	d1, d3, [sp, #48]
    10a8:	b	10b0 <pts_ieee754_asin+0x16c>
    10ac:	fsqrt	d2, d1
    10b0:	fdiv	d8, d8, d3
    10b4:	mov	w0, #0x3332                	// #13106
    10b8:	movk	w0, #0x3fef, lsl #16
    10bc:	cmp	w19, w0
    10c0:	b.le	1198 <pts_ieee754_asin+0x254>
    10c4:	fmadd	d2, d2, d8, d2
    10c8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    10cc:	fmov	d3, #2.000000000000000000e+00
    10d0:	ldr	d1, [x0]
    10d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    10d8:	ldr	d0, [x0]
    10dc:	fmadd	d1, d2, d3, d1
    10e0:	fsub	d0, d0, d1
    10e4:	fneg	d1, d0
    10e8:	cmp	w20, #0x0
    10ec:	ldp	x19, x20, [sp, #16]
    10f0:	ldp	d8, d9, [sp, #32]
    10f4:	fcsel	d0, d1, d0, le
    10f8:	ldp	x29, x30, [sp], #64
    10fc:	ret
    1100:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1104:	fmul	d0, d0, d0
    1108:	stp	d8, d9, [sp, #32]
    110c:	ldr	d3, [x0]
    1110:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1114:	ldr	d16, [x0]
    1118:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    111c:	fmadd	d16, d0, d3, d16
    1120:	fmov	d3, #1.000000000000000000e+00
    1124:	ldr	d8, [x0]
    1128:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    112c:	ldr	d2, [x0]
    1130:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1134:	ldr	d9, [x0]
    1138:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    113c:	fmadd	d9, d0, d2, d9
    1140:	ldr	d6, [x0]
    1144:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1148:	fmadd	d8, d0, d16, d8
    114c:	ldr	d7, [x0]
    1150:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1154:	ldr	d4, [x0]
    1158:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    115c:	ldr	d5, [x0]
    1160:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    1164:	fmadd	d7, d0, d9, d7
    1168:	movk	x0, #0x3fc5, lsl #48
    116c:	fmov	d2, x0
    1170:	fmadd	d6, d0, d8, d6
    1174:	ldp	d8, d9, [sp, #32]
    1178:	fmadd	d5, d0, d7, d5
    117c:	fmadd	d4, d0, d6, d4
    1180:	fmadd	d3, d0, d5, d3
    1184:	fmadd	d2, d0, d4, d2
    1188:	fmul	d0, d0, d2
    118c:	fdiv	d0, d0, d3
    1190:	fmadd	d0, d1, d0, d1
    1194:	b	fec <pts_ieee754_asin+0xa8>
    1198:	movi	v0.2d, #0xffffffff00000000
    119c:	fadd	d6, d2, d2
    11a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    11a4:	fmov	d5, #2.000000000000000000e+00
    11a8:	ldr	d3, [x0]
    11ac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    11b0:	and	v4.8b, v2.8b, v0.8b
    11b4:	ldr	d0, [x0]
    11b8:	fmsub	d1, d4, d4, d1
    11bc:	fadd	d2, d4, d2
    11c0:	fmsub	d4, d4, d5, d0
    11c4:	fdiv	d1, d1, d2
    11c8:	fmsub	d1, d1, d5, d3
    11cc:	fnmsub	d1, d6, d8, d1
    11d0:	fsub	d1, d1, d4
    11d4:	fsub	d0, d0, d1
    11d8:	b	10e4 <pts_ieee754_asin+0x1a0>
    11dc:	nop

00000000000011e0 <pts_ieee754_atan>:
    11e0:	fmov	x1, d0
    11e4:	fmov	d1, d0
    11e8:	mov	w2, #0x440fffff            	// #1141899263
    11ec:	ubfx	x0, x1, #32, #31
    11f0:	lsr	x3, x1, #32
    11f4:	cmp	w0, w2
    11f8:	b.le	1240 <pts_ieee754_atan+0x60>
    11fc:	mov	w2, #0x7ff00000            	// #2146435072
    1200:	cmp	w0, w2
    1204:	b.gt	1238 <pts_ieee754_atan+0x58>
    1208:	cmp	w1, #0x0
    120c:	ccmp	w0, w2, #0x0, ne	// ne = any
    1210:	b.eq	1238 <pts_ieee754_atan+0x58>  // b.none
    1214:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1218:	add	x0, x0, #0x0
    121c:	cmp	w3, #0x0
    1220:	b.le	13b4 <pts_ieee754_atan+0x1d4>
    1224:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1228:	ldr	d0, [x0, #424]
    122c:	ldr	d1, [x1]
    1230:	fadd	d0, d0, d1
    1234:	ret
    1238:	fadd	d0, d1, d1
    123c:	ret
    1240:	mov	w1, #0x3fdbffff            	// #1071382527
    1244:	cmp	w0, w1
    1248:	b.gt	1318 <pts_ieee754_atan+0x138>
    124c:	mov	w1, #0x3e3fffff            	// #1044381695
    1250:	cmp	w0, w1
    1254:	b.le	1398 <pts_ieee754_atan+0x1b8>
    1258:	movi	d21, #0x0
    125c:	mov	w0, #0xffffffff            	// #-1
    1260:	fmov	d0, d21
    1264:	fmul	d4, d1, d1
    1268:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    126c:	ldr	d23, [x1]
    1270:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1274:	fmul	d3, d4, d4
    1278:	ldr	d20, [x1]
    127c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1280:	ldr	d22, [x1]
    1284:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1288:	fmadd	d20, d3, d23, d20
    128c:	ldr	d19, [x1]
    1290:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1294:	fmadd	d19, d3, d22, d19
    1298:	ldr	d18, [x1]
    129c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12a0:	ldr	d17, [x1]
    12a4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12a8:	ldr	d16, [x1]
    12ac:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12b0:	fmadd	d18, d20, d3, d18
    12b4:	ldr	d7, [x1]
    12b8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12bc:	fmadd	d17, d19, d3, d17
    12c0:	ldr	d6, [x1]
    12c4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12c8:	ldr	d2, [x1]
    12cc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    12d0:	ldr	d5, [x1]
    12d4:	fmadd	d16, d18, d3, d16
    12d8:	fmadd	d7, d17, d3, d7
    12dc:	fmadd	d6, d16, d3, d6
    12e0:	fmadd	d2, d7, d3, d2
    12e4:	fmadd	d5, d6, d3, d5
    12e8:	fmul	d2, d2, d3
    12ec:	fmadd	d2, d5, d4, d2
    12f0:	fmul	d2, d1, d2
    12f4:	cmn	w0, #0x1
    12f8:	b.eq	13c8 <pts_ieee754_atan+0x1e8>  // b.none
    12fc:	fsub	d2, d2, d21
    1300:	cmp	w3, #0x0
    1304:	fsub	d2, d2, d1
    1308:	fsub	d0, d0, d2
    130c:	fneg	d1, d0
    1310:	fcsel	d0, d1, d0, lt	// lt = tstop
    1314:	ret
    1318:	fabs	d1, d0
    131c:	mov	w1, #0x3ff2ffff            	// #1072889855
    1320:	cmp	w0, w1
    1324:	b.gt	1360 <pts_ieee754_atan+0x180>
    1328:	mov	w1, #0x3fe5ffff            	// #1072037887
    132c:	cmp	w0, w1
    1330:	b.gt	13f0 <pts_ieee754_atan+0x210>
    1334:	fmov	d3, #2.000000000000000000e+00
    1338:	fmov	d2, #-1.000000000000000000e+00
    133c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1340:	fmadd	d2, d1, d3, d2
    1344:	fadd	d1, d1, d3
    1348:	ldr	d21, [x0]
    134c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1350:	ldr	d0, [x0]
    1354:	mov	w0, #0x0                   	// #0
    1358:	fdiv	d1, d2, d1
    135c:	b	1264 <pts_ieee754_atan+0x84>
    1360:	add	w1, w1, #0x108, lsl #12
    1364:	cmp	w0, w1
    1368:	b.gt	13d0 <pts_ieee754_atan+0x1f0>
    136c:	fmov	d3, #1.500000000000000000e+00
    1370:	fmov	d2, #1.000000000000000000e+00
    1374:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1378:	fmadd	d2, d1, d3, d2
    137c:	fsub	d1, d1, d3
    1380:	ldr	d21, [x0]
    1384:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1388:	ldr	d0, [x0]
    138c:	mov	w0, #0x2                   	// #2
    1390:	fdiv	d1, d1, d2
    1394:	b	1264 <pts_ieee754_atan+0x84>
    1398:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    139c:	fmov	d3, #1.000000000000000000e+00
    13a0:	ldr	d2, [x0]
    13a4:	fadd	d2, d0, d2
    13a8:	fcmpe	d2, d3
    13ac:	b.gt	1234 <pts_ieee754_atan+0x54>
    13b0:	b	1258 <pts_ieee754_atan+0x78>
    13b4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    13b8:	ldr	d1, [x0, #424]
    13bc:	ldr	d0, [x1]
    13c0:	fsub	d0, d0, d1
    13c4:	ret
    13c8:	fsub	d0, d1, d2
    13cc:	ret
    13d0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13d4:	fmov	d2, #-1.000000000000000000e+00
    13d8:	fdiv	d1, d2, d1
    13dc:	ldr	d21, [x0]
    13e0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13e4:	ldr	d0, [x0]
    13e8:	mov	w0, #0x3                   	// #3
    13ec:	b	1264 <pts_ieee754_atan+0x84>
    13f0:	fmov	d2, #1.000000000000000000e+00
    13f4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    13f8:	fsub	d3, d1, d2
    13fc:	fadd	d1, d1, d2
    1400:	ldr	d21, [x0]
    1404:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1408:	ldr	d0, [x0]
    140c:	mov	w0, #0x1                   	// #1
    1410:	fdiv	d1, d3, d1
    1414:	b	1264 <pts_ieee754_atan+0x84>
    1418:	nop
    141c:	nop

0000000000001420 <pts_ieee754_atan2>:
    1420:	fmov	x1, d1
    1424:	fmov	d2, d0
    1428:	mov	w3, #0x7ff00000            	// #2146435072
    142c:	neg	w0, w1
    1430:	ubfx	x5, x1, #32, #31
    1434:	orr	w0, w0, w1
    1438:	orr	w0, w5, w0, lsr #31
    143c:	cmp	w0, w3
    1440:	b.hi	14fc <pts_ieee754_atan2+0xdc>  // b.pmore
    1444:	fmov	x0, d0
    1448:	neg	w2, w0
    144c:	ubfx	x6, x0, #32, #31
    1450:	orr	w2, w2, w0
    1454:	lsr	x8, x0, #32
    1458:	orr	w2, w6, w2, lsr #31
    145c:	cmp	w2, w3
    1460:	b.hi	14fc <pts_ieee754_atan2+0xdc>  // b.pmore
    1464:	lsr	x7, x1, #32
    1468:	mov	w2, #0xc0100000            	// #-1072693248
    146c:	add	w2, w7, w2
    1470:	orr	w2, w2, w1
    1474:	cbz	w2, 1518 <pts_ieee754_atan2+0xf8>
    1478:	asr	w4, w7, #30
    147c:	lsr	w2, w8, #31
    1480:	and	w4, w4, #0x2
    1484:	orr	w0, w6, w0
    1488:	orr	w4, w4, w2
    148c:	cbz	w0, 1504 <pts_ieee754_atan2+0xe4>
    1490:	orr	w1, w5, w1
    1494:	cbz	w1, 151c <pts_ieee754_atan2+0xfc>
    1498:	cmp	w5, w3
    149c:	b.eq	15a0 <pts_ieee754_atan2+0x180>  // b.none
    14a0:	cmp	w6, w3
    14a4:	b.eq	151c <pts_ieee754_atan2+0xfc>  // b.none
    14a8:	sub	w6, w6, w5
    14ac:	asr	w6, w6, #20
    14b0:	cmp	w6, #0x3c
    14b4:	b.gt	157c <pts_ieee754_atan2+0x15c>
    14b8:	cmp	w7, #0x0
    14bc:	mov	w0, #0xffffffc4            	// #-60
    14c0:	movi	d0, #0x0
    14c4:	ccmp	w6, w0, #0x0, lt	// lt = tstop
    14c8:	b.ge	162c <pts_ieee754_atan2+0x20c>  // b.tcont
    14cc:	cmp	w4, #0x1
    14d0:	b.eq	1624 <pts_ieee754_atan2+0x204>  // b.none
    14d4:	cmp	w4, #0x2
    14d8:	b.ne	1600 <pts_ieee754_atan2+0x1e0>  // b.any
    14dc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    14e0:	add	x0, x0, #0x0
    14e4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    14e8:	ldr	d2, [x0, #8]
    14ec:	ldr	d1, [x1]
    14f0:	fsub	d0, d0, d2
    14f4:	fsub	d0, d1, d0
    14f8:	ret
    14fc:	fadd	d0, d1, d2
    1500:	ret
    1504:	cmp	w4, #0x2
    1508:	b.eq	1550 <pts_ieee754_atan2+0x130>  // b.none
    150c:	cmp	w4, #0x3
    1510:	b.eq	1538 <pts_ieee754_atan2+0x118>  // b.none
    1514:	ret
    1518:	b	11e0 <pts_ieee754_atan>
    151c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1520:	tbnz	w8, #31, 1568 <pts_ieee754_atan2+0x148>
    1524:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1528:	ldr	d0, [x0]
    152c:	ldr	d1, [x1]
    1530:	fadd	d0, d0, d1
    1534:	ret
    1538:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    153c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1540:	ldr	d1, [x0]
    1544:	ldr	d0, [x1]
    1548:	fsub	d0, d0, d1
    154c:	ret
    1550:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1554:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1558:	ldr	d0, [x0]
    155c:	ldr	d1, [x1]
    1560:	fadd	d0, d0, d1
    1564:	ret
    1568:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    156c:	ldr	d1, [x0]
    1570:	ldr	d0, [x1]
    1574:	fsub	d0, d0, d1
    1578:	ret
    157c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1580:	add	x0, x0, #0x0
    1584:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1588:	fmov	d1, #5.000000000000000000e-01
    158c:	ldr	d2, [x0, #8]
    1590:	ldr	d0, [x1]
    1594:	fmadd	d0, d2, d1, d0
    1598:	tbnz	w4, #0, 1624 <pts_ieee754_atan2+0x204>
    159c:	ret
    15a0:	cmp	w6, w5
    15a4:	b.eq	15d0 <pts_ieee754_atan2+0x1b0>  // b.none
    15a8:	cmp	w4, #0x2
    15ac:	b.eq	1550 <pts_ieee754_atan2+0x130>  // b.none
    15b0:	cmp	w4, #0x3
    15b4:	b.eq	1538 <pts_ieee754_atan2+0x118>  // b.none
    15b8:	movi	d1, #0x0
    15bc:	cmp	w4, #0x1
    15c0:	mov	x0, #0x8000000000000000    	// #-9223372036854775808
    15c4:	fmov	d0, x0
    15c8:	fcsel	d0, d0, d1, eq	// eq = none
    15cc:	ret
    15d0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    15d4:	cmp	w4, #0x2
    15d8:	b.eq	16c8 <pts_ieee754_atan2+0x2a8>  // b.none
    15dc:	cmp	w4, #0x3
    15e0:	b.eq	16b4 <pts_ieee754_atan2+0x294>  // b.none
    15e4:	cmp	w4, #0x1
    15e8:	b.eq	16a0 <pts_ieee754_atan2+0x280>  // b.none
    15ec:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    15f0:	ldr	d0, [x0]
    15f4:	ldr	d1, [x1]
    15f8:	fadd	d0, d0, d1
    15fc:	ret
    1600:	cbz	w4, 16dc <pts_ieee754_atan2+0x2bc>
    1604:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1608:	add	x0, x0, #0x0
    160c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1610:	ldr	d2, [x0, #8]
    1614:	ldr	d1, [x1]
    1618:	fsub	d0, d0, d2
    161c:	fsub	d0, d0, d1
    1620:	ret
    1624:	fneg	d0, d0
    1628:	ret
    162c:	fdiv	d0, d2, d1
    1630:	stp	x29, x30, [sp, #-16]!
    1634:	mov	x29, sp
    1638:	fabs	d0, d0
    163c:	bl	11e0 <pts_ieee754_atan>
    1640:	cmp	w4, #0x1
    1644:	b.eq	1674 <pts_ieee754_atan2+0x254>  // b.none
    1648:	cmp	w4, #0x2
    164c:	b.ne	167c <pts_ieee754_atan2+0x25c>  // b.any
    1650:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1654:	add	x0, x0, #0x0
    1658:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    165c:	ldr	d2, [x0, #8]
    1660:	ldr	d1, [x1]
    1664:	fsub	d0, d0, d2
    1668:	fsub	d0, d1, d0
    166c:	ldp	x29, x30, [sp], #16
    1670:	ret
    1674:	fneg	d0, d0
    1678:	b	166c <pts_ieee754_atan2+0x24c>
    167c:	cbz	w4, 166c <pts_ieee754_atan2+0x24c>
    1680:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1684:	add	x0, x0, #0x0
    1688:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    168c:	ldr	d2, [x0, #8]
    1690:	ldr	d1, [x1]
    1694:	fsub	d0, d0, d2
    1698:	fsub	d0, d0, d1
    169c:	b	166c <pts_ieee754_atan2+0x24c>
    16a0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16a4:	ldr	d1, [x0]
    16a8:	ldr	d0, [x1]
    16ac:	fsub	d0, d0, d1
    16b0:	ret
    16b4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16b8:	ldr	d1, [x0]
    16bc:	ldr	d0, [x1]
    16c0:	fsub	d0, d0, d1
    16c4:	ret
    16c8:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    16cc:	ldr	d0, [x0]
    16d0:	ldr	d1, [x1]
    16d4:	fadd	d0, d0, d1
    16d8:	ret
    16dc:	ret

00000000000016e0 <pts_ieee754_cos>:
    16e0:	sub	sp, sp, #0x30
    16e4:	mov	w1, #0x21fb                	// #8699
    16e8:	adrp	x0, 0 <__stack_chk_guard>
    16ec:	ldr	x0, [x0]
    16f0:	fmov	d1, d0
    16f4:	stp	x29, x30, [sp, #32]
    16f8:	add	x29, sp, #0x20
    16fc:	movk	w1, #0x3fe9, lsl #16
    1700:	ldr	x2, [x0]
    1704:	str	x2, [sp, #24]
    1708:	mov	x2, #0x0                   	// #0
    170c:	fmov	x0, d0
    1710:	ubfx	x0, x0, #32, #31
    1714:	cmp	w0, w1
    1718:	b.le	1824 <pts_ieee754_cos+0x144>
    171c:	mov	w1, #0x7fefffff            	// #2146435071
    1720:	cmp	w0, w1
    1724:	b.le	1754 <pts_ieee754_cos+0x74>
    1728:	fsub	d0, d0, d0
    172c:	adrp	x0, 0 <__stack_chk_guard>
    1730:	ldr	x0, [x0]
    1734:	ldr	x2, [sp, #24]
    1738:	ldr	x1, [x0]
    173c:	subs	x2, x2, x1
    1740:	mov	x1, #0x0                   	// #0
    1744:	b.ne	1c14 <pts_ieee754_cos+0x534>  // b.any
    1748:	ldp	x29, x30, [sp, #32]
    174c:	add	sp, sp, #0x30
    1750:	ret
    1754:	add	x0, sp, #0x8
    1758:	bl	954 <__ieee754_rem_pio2>
    175c:	and	w0, w0, #0x3
    1760:	cmp	w0, #0x1
    1764:	b.eq	1a78 <pts_ieee754_cos+0x398>  // b.none
    1768:	cmp	w0, #0x2
    176c:	b.eq	1940 <pts_ieee754_cos+0x260>  // b.none
    1770:	cbnz	w0, 19f4 <pts_ieee754_cos+0x314>
    1774:	ldp	d1, d7, [sp, #8]
    1778:	mov	w1, #0x3e3fffff            	// #1044381695
    177c:	fmov	x0, d1
    1780:	ubfx	x0, x0, #32, #31
    1784:	cmp	w0, w1
    1788:	b.le	1b8c <pts_ieee754_cos+0x4ac>
    178c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1790:	fmul	d2, d1, d1
    1794:	ldr	d16, [x1]
    1798:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    179c:	ldr	d6, [x1]
    17a0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    17a4:	fmadd	d6, d2, d16, d6
    17a8:	ldr	d5, [x1]
    17ac:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    17b0:	ldr	d3, [x1]
    17b4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    17b8:	ldr	d0, [x1]
    17bc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    17c0:	ldr	d4, [x1]
    17c4:	mov	w1, #0x3332                	// #13106
    17c8:	fmadd	d5, d2, d6, d5
    17cc:	movk	w1, #0x3fd3, lsl #16
    17d0:	fmadd	d3, d2, d5, d3
    17d4:	fmadd	d0, d2, d3, d0
    17d8:	fmadd	d4, d2, d0, d4
    17dc:	fmul	d4, d2, d4
    17e0:	cmp	w0, w1
    17e4:	b.le	1be0 <pts_ieee754_cos+0x500>
    17e8:	mov	w1, #0x3fe90000            	// #1072234496
    17ec:	cmp	w0, w1
    17f0:	b.gt	1c08 <pts_ieee754_cos+0x528>
    17f4:	sub	w0, w0, #0x200, lsl #12
    17f8:	fmov	d3, x0
    17fc:	fmov	d0, #1.000000000000000000e+00
    1800:	shl	d3, d3, #32
    1804:	fsub	d0, d0, d3
    1808:	fmov	d5, #5.000000000000000000e-01
    180c:	fmul	d1, d1, d7
    1810:	fnmsub	d1, d2, d4, d1
    1814:	fnmsub	d3, d2, d5, d3
    1818:	fsub	d3, d3, d1
    181c:	fsub	d0, d0, d3
    1820:	b	172c <pts_ieee754_cos+0x4c>
    1824:	mov	w1, #0x3e3fffff            	// #1044381695
    1828:	cmp	w0, w1
    182c:	b.le	18cc <pts_ieee754_cos+0x1ec>
    1830:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1834:	fmul	d2, d0, d0
    1838:	ldr	d7, [x1]
    183c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1840:	ldr	d6, [x1]
    1844:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1848:	fmadd	d6, d2, d7, d6
    184c:	ldr	d5, [x1]
    1850:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1854:	ldr	d4, [x1]
    1858:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    185c:	ldr	d0, [x1]
    1860:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1864:	ldr	d3, [x1]
    1868:	mov	w1, #0x3332                	// #13106
    186c:	fmadd	d5, d2, d6, d5
    1870:	movk	w1, #0x3fd3, lsl #16
    1874:	fmadd	d4, d2, d5, d4
    1878:	fmadd	d0, d2, d4, d0
    187c:	fmadd	d3, d2, d0, d3
    1880:	fmul	d3, d2, d3
    1884:	cmp	w0, w1
    1888:	b.le	1920 <pts_ieee754_cos+0x240>
    188c:	mov	w1, #0x3fe90000            	// #1072234496
    1890:	cmp	w0, w1
    1894:	b.gt	1b08 <pts_ieee754_cos+0x428>
    1898:	sub	w0, w0, #0x200, lsl #12
    189c:	fmov	d0, x0
    18a0:	fmov	d5, #1.000000000000000000e+00
    18a4:	shl	d0, d0, #32
    18a8:	fsub	d5, d5, d0
    18ac:	movi	d4, #0x0
    18b0:	fmov	d6, #5.000000000000000000e-01
    18b4:	fnmsub	d0, d2, d6, d0
    18b8:	fmul	d1, d1, d4
    18bc:	fnmsub	d1, d2, d3, d1
    18c0:	fsub	d0, d0, d1
    18c4:	fsub	d0, d5, d0
    18c8:	b	172c <pts_ieee754_cos+0x4c>
    18cc:	fcvtzs	w0, d0
    18d0:	cbz	w0, 1b00 <pts_ieee754_cos+0x420>
    18d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18d8:	fmul	d2, d0, d0
    18dc:	ldr	d7, [x0]
    18e0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18e4:	ldr	d6, [x0]
    18e8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18ec:	fmadd	d6, d2, d7, d6
    18f0:	ldr	d5, [x0]
    18f4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    18f8:	ldr	d4, [x0]
    18fc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1900:	ldr	d0, [x0]
    1904:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1908:	ldr	d3, [x0]
    190c:	fmadd	d5, d2, d6, d5
    1910:	fmadd	d4, d5, d2, d4
    1914:	fmadd	d0, d4, d2, d0
    1918:	fmadd	d3, d0, d2, d3
    191c:	fmul	d3, d3, d2
    1920:	movi	d0, #0x0
    1924:	fmov	d5, #5.000000000000000000e-01
    1928:	fmov	d4, #1.000000000000000000e+00
    192c:	fmul	d0, d1, d0
    1930:	fnmsub	d0, d2, d3, d0
    1934:	fnmsub	d0, d2, d5, d0
    1938:	fsub	d0, d4, d0
    193c:	b	172c <pts_ieee754_cos+0x4c>
    1940:	ldp	d1, d7, [sp, #8]
    1944:	mov	w1, #0x3e3fffff            	// #1044381695
    1948:	fmov	x0, d1
    194c:	ubfx	x0, x0, #32, #31
    1950:	cmp	w0, w1
    1954:	b.le	1b14 <pts_ieee754_cos+0x434>
    1958:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    195c:	fmul	d2, d1, d1
    1960:	ldr	d16, [x1]
    1964:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1968:	ldr	d6, [x1]
    196c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1970:	fmadd	d6, d2, d16, d6
    1974:	ldr	d5, [x1]
    1978:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    197c:	ldr	d3, [x1]
    1980:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1984:	ldr	d0, [x1]
    1988:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    198c:	ldr	d4, [x1]
    1990:	mov	w1, #0x3332                	// #13106
    1994:	fmadd	d5, d2, d6, d5
    1998:	movk	w1, #0x3fd3, lsl #16
    199c:	fmadd	d3, d2, d5, d3
    19a0:	fmadd	d0, d2, d3, d0
    19a4:	fmadd	d4, d2, d0, d4
    19a8:	fmul	d4, d2, d4
    19ac:	cmp	w0, w1
    19b0:	b.le	1b6c <pts_ieee754_cos+0x48c>
    19b4:	mov	w1, #0x3fe90000            	// #1072234496
    19b8:	cmp	w0, w1
    19bc:	b.gt	1bfc <pts_ieee754_cos+0x51c>
    19c0:	sub	w0, w0, #0x200, lsl #12
    19c4:	fmov	d3, x0
    19c8:	fmov	d0, #1.000000000000000000e+00
    19cc:	shl	d3, d3, #32
    19d0:	fsub	d0, d0, d3
    19d4:	fmov	d5, #5.000000000000000000e-01
    19d8:	fmul	d1, d1, d7
    19dc:	fnmsub	d1, d2, d4, d1
    19e0:	fnmsub	d3, d2, d5, d3
    19e4:	fsub	d3, d3, d1
    19e8:	fsub	d0, d0, d3
    19ec:	fneg	d0, d0
    19f0:	b	172c <pts_ieee754_cos+0x4c>
    19f4:	ldp	d0, d2, [sp, #8]
    19f8:	mov	w0, #0x3e3fffff            	// #1044381695
    19fc:	fmov	x1, d0
    1a00:	ubfx	x1, x1, #32, #31
    1a04:	cmp	w1, w0
    1a08:	b.gt	1a14 <pts_ieee754_cos+0x334>
    1a0c:	fcvtzs	w0, d0
    1a10:	cbz	w0, 172c <pts_ieee754_cos+0x4c>
    1a14:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a18:	fmul	d3, d0, d0
    1a1c:	fmov	d17, #5.000000000000000000e-01
    1a20:	ldr	d7, [x0]
    1a24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a28:	ldr	d6, [x0]
    1a2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a30:	fmadd	d6, d3, d7, d6
    1a34:	fmul	d7, d0, d3
    1a38:	ldr	d5, [x0]
    1a3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a40:	ldr	d4, [x0]
    1a44:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a48:	ldr	d1, [x0]
    1a4c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a50:	ldr	d16, [x0]
    1a54:	fmadd	d5, d3, d6, d5
    1a58:	fmadd	d4, d3, d5, d4
    1a5c:	fmadd	d1, d3, d4, d1
    1a60:	fmul	d1, d7, d1
    1a64:	fnmsub	d1, d2, d17, d1
    1a68:	fnmsub	d2, d3, d1, d2
    1a6c:	fmadd	d2, d7, d16, d2
    1a70:	fsub	d0, d0, d2
    1a74:	b	172c <pts_ieee754_cos+0x4c>
    1a78:	ldp	d0, d2, [sp, #8]
    1a7c:	mov	w0, #0x3e3fffff            	// #1044381695
    1a80:	fmov	x1, d0
    1a84:	ubfx	x1, x1, #32, #31
    1a88:	cmp	w1, w0
    1a8c:	b.gt	1a98 <pts_ieee754_cos+0x3b8>
    1a90:	fcvtzs	w0, d0
    1a94:	cbz	w0, 19ec <pts_ieee754_cos+0x30c>
    1a98:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1a9c:	fmul	d3, d0, d0
    1aa0:	fmov	d17, #5.000000000000000000e-01
    1aa4:	ldr	d7, [x0]
    1aa8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1aac:	ldr	d6, [x0]
    1ab0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ab4:	fmadd	d6, d3, d7, d6
    1ab8:	fmul	d7, d0, d3
    1abc:	ldr	d5, [x0]
    1ac0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ac4:	ldr	d4, [x0]
    1ac8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1acc:	ldr	d1, [x0]
    1ad0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ad4:	ldr	d16, [x0]
    1ad8:	fmadd	d5, d3, d6, d5
    1adc:	fmadd	d4, d3, d5, d4
    1ae0:	fmadd	d1, d3, d4, d1
    1ae4:	fmul	d1, d7, d1
    1ae8:	fnmsub	d1, d2, d17, d1
    1aec:	fnmsub	d2, d3, d1, d2
    1af0:	fmadd	d2, d7, d16, d2
    1af4:	fsub	d0, d0, d2
    1af8:	fneg	d0, d0
    1afc:	b	172c <pts_ieee754_cos+0x4c>
    1b00:	fmov	d0, #1.000000000000000000e+00
    1b04:	b	172c <pts_ieee754_cos+0x4c>
    1b08:	fmov	d5, #7.187500000000000000e-01
    1b0c:	fmov	d0, #2.812500000000000000e-01
    1b10:	b	18ac <pts_ieee754_cos+0x1cc>
    1b14:	fcvtzs	w0, d1
    1b18:	fmov	d0, #-1.000000000000000000e+00
    1b1c:	cbz	w0, 172c <pts_ieee754_cos+0x4c>
    1b20:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b24:	fmul	d2, d1, d1
    1b28:	ldr	d16, [x0]
    1b2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b30:	ldr	d6, [x0]
    1b34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b38:	fmadd	d6, d2, d16, d6
    1b3c:	ldr	d5, [x0]
    1b40:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b44:	ldr	d3, [x0]
    1b48:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b4c:	ldr	d0, [x0]
    1b50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b54:	ldr	d4, [x0]
    1b58:	fmadd	d5, d2, d6, d5
    1b5c:	fmadd	d3, d2, d5, d3
    1b60:	fmadd	d0, d2, d3, d0
    1b64:	fmadd	d4, d2, d0, d4
    1b68:	fmul	d4, d2, d4
    1b6c:	fmul	d1, d1, d7
    1b70:	fmov	d3, #5.000000000000000000e-01
    1b74:	fnmsub	d1, d2, d4, d1
    1b78:	fmov	d0, #1.000000000000000000e+00
    1b7c:	fnmsub	d1, d2, d3, d1
    1b80:	fsub	d0, d0, d1
    1b84:	fneg	d0, d0
    1b88:	b	172c <pts_ieee754_cos+0x4c>
    1b8c:	fcvtzs	w0, d1
    1b90:	cbz	w0, 1b00 <pts_ieee754_cos+0x420>
    1b94:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1b98:	fmul	d2, d1, d1
    1b9c:	ldr	d16, [x0]
    1ba0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ba4:	ldr	d6, [x0]
    1ba8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bac:	fmadd	d6, d2, d16, d6
    1bb0:	ldr	d5, [x0]
    1bb4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bb8:	ldr	d3, [x0]
    1bbc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bc0:	ldr	d0, [x0]
    1bc4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1bc8:	ldr	d4, [x0]
    1bcc:	fmadd	d5, d2, d6, d5
    1bd0:	fmadd	d3, d2, d5, d3
    1bd4:	fmadd	d0, d2, d3, d0
    1bd8:	fmadd	d4, d2, d0, d4
    1bdc:	fmul	d4, d2, d4
    1be0:	fmul	d1, d1, d7
    1be4:	fmov	d3, #5.000000000000000000e-01
    1be8:	fnmsub	d1, d2, d4, d1
    1bec:	fmov	d0, #1.000000000000000000e+00
    1bf0:	fnmsub	d1, d2, d3, d1
    1bf4:	fsub	d0, d0, d1
    1bf8:	b	172c <pts_ieee754_cos+0x4c>
    1bfc:	fmov	d0, #7.187500000000000000e-01
    1c00:	fmov	d3, #2.812500000000000000e-01
    1c04:	b	19d4 <pts_ieee754_cos+0x2f4>
    1c08:	fmov	d0, #7.187500000000000000e-01
    1c0c:	fmov	d3, #2.812500000000000000e-01
    1c10:	b	1808 <pts_ieee754_cos+0x128>
    1c14:	bl	0 <__stack_chk_fail>
    1c18:	nop
    1c1c:	nop

0000000000001c20 <pts_ieee754_exp>:
    1c20:	fmov	x0, d0
    1c24:	mov	w3, #0x2e41                	// #11841
    1c28:	movk	w3, #0x4086, lsl #16
    1c2c:	ubfx	x1, x0, #32, #31
    1c30:	lsr	x2, x0, #32
    1c34:	lsr	x4, x0, #63
    1c38:	cmp	w1, w3
    1c3c:	b.ls	1c60 <pts_ieee754_exp+0x40>  // b.plast
    1c40:	mov	w3, #0x7fefffff            	// #2146435071
    1c44:	cmp	w1, w3
    1c48:	b.ls	1cf0 <pts_ieee754_exp+0xd0>  // b.plast
    1c4c:	and	w2, w2, #0xfffff
    1c50:	orr	w2, w2, w0
    1c54:	cbz	w2, 1e94 <pts_ieee754_exp+0x274>
    1c58:	fadd	d0, d0, d0
    1c5c:	ret
    1c60:	mov	w0, #0x2e42                	// #11842
    1c64:	movk	w0, #0x3fd6, lsl #16
    1c68:	cmp	w1, w0
    1c6c:	b.hi	1e18 <pts_ieee754_exp+0x1f8>  // b.pmore
    1c70:	mov	w0, #0x3e2fffff            	// #1043333119
    1c74:	cmp	w1, w0
    1c78:	b.ls	1e74 <pts_ieee754_exp+0x254>  // b.plast
    1c7c:	movi	d3, #0x0
    1c80:	fmul	d1, d0, d0
    1c84:	fmov	d16, #1.000000000000000000e+00
    1c88:	mov	w0, #0x0                   	// #0
    1c8c:	fmov	d4, d3
    1c90:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1c94:	ldr	d2, [x1]
    1c98:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1c9c:	ldr	d7, [x1]
    1ca0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1ca4:	fmadd	d7, d1, d2, d7
    1ca8:	ldr	d6, [x1]
    1cac:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1cb0:	ldr	d5, [x1]
    1cb4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1cb8:	ldr	d2, [x1]
    1cbc:	fmadd	d6, d7, d1, d6
    1cc0:	fmadd	d5, d6, d1, d5
    1cc4:	fmadd	d2, d5, d1, d2
    1cc8:	fmsub	d1, d2, d1, d0
    1ccc:	cbnz	w0, 1de8 <pts_ieee754_exp+0x1c8>
    1cd0:	fmov	d4, #2.000000000000000000e+00
    1cd4:	fmul	d2, d1, d0
    1cd8:	fmov	d3, #1.000000000000000000e+00
    1cdc:	fsub	d1, d1, d4
    1ce0:	fdiv	d1, d2, d1
    1ce4:	fsub	d0, d1, d0
    1ce8:	fsub	d0, d3, d0
    1cec:	ret
    1cf0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1cf4:	ldr	d1, [x0]
    1cf8:	fcmpe	d0, d1
    1cfc:	b.gt	1ea4 <pts_ieee754_exp+0x284>
    1d00:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d04:	ldr	d1, [x0]
    1d08:	fcmpe	d0, d1
    1d0c:	b.mi	1edc <pts_ieee754_exp+0x2bc>  // b.first
    1d10:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d14:	ubfiz	x4, x4, #3, #1
    1d18:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d1c:	add	x0, x0, #0x0
    1d20:	add	x0, x0, x4
    1d24:	ldr	d3, [x1]
    1d28:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d2c:	ldr	d1, [x0, #464]
    1d30:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d34:	fmadd	d1, d0, d3, d1
    1d38:	ldr	d4, [x1]
    1d3c:	ldr	d2, [x0]
    1d40:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1d44:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d48:	ldr	d5, [x0]
    1d4c:	ldr	d17, [x1]
    1d50:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d54:	ldr	d16, [x1]
    1d58:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d5c:	fcvtzs	w0, d1
    1d60:	ldr	d7, [x1]
    1d64:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1d68:	ldr	d6, [x1]
    1d6c:	scvtf	d3, w0
    1d70:	fmsub	d4, d3, d4, d0
    1d74:	fmul	d3, d3, d17
    1d78:	fsub	d0, d4, d3
    1d7c:	fmul	d1, d0, d0
    1d80:	fmadd	d7, d1, d16, d7
    1d84:	fmadd	d6, d1, d7, d6
    1d88:	fmadd	d2, d1, d6, d2
    1d8c:	fmadd	d5, d1, d2, d5
    1d90:	fmsub	d5, d1, d5, d0
    1d94:	cmn	w0, #0x3fd
    1d98:	b.ge	1f00 <pts_ieee754_exp+0x2e0>  // b.tcont
    1d9c:	fmov	d1, #2.000000000000000000e+00
    1da0:	fmul	d2, d0, d5
    1da4:	add	w0, w0, #0x3e8
    1da8:	mov	w1, #0x3ff00000            	// #1072693248
    1dac:	fsub	d5, d1, d5
    1db0:	add	w0, w1, w0, lsl #20
    1db4:	fmov	d0, #1.000000000000000000e+00
    1db8:	fmov	d1, x0
    1dbc:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    1dc0:	add	x1, x1, #0x0
    1dc4:	fdiv	d2, d2, d5
    1dc8:	shl	d1, d1, #32
    1dcc:	ldr	d5, [x1, #24]
    1dd0:	fsub	d2, d3, d2
    1dd4:	fsub	d2, d2, d4
    1dd8:	fsub	d0, d0, d2
    1ddc:	fmul	d0, d0, d1
    1de0:	fmul	d0, d0, d5
    1de4:	ret
    1de8:	fmov	d5, #2.000000000000000000e+00
    1dec:	fmul	d0, d1, d0
    1df0:	fmov	d2, #1.000000000000000000e+00
    1df4:	fsub	d1, d5, d1
    1df8:	fdiv	d0, d0, d1
    1dfc:	fsub	d0, d3, d0
    1e00:	fsub	d0, d0, d4
    1e04:	fsub	d0, d2, d0
    1e08:	cmp	w0, #0x400
    1e0c:	b.eq	1ebc <pts_ieee754_exp+0x29c>  // b.none
    1e10:	fmul	d0, d0, d16
    1e14:	ret
    1e18:	mov	w0, #0xa2b1                	// #41649
    1e1c:	movk	w0, #0x3ff0, lsl #16
    1e20:	cmp	w1, w0
    1e24:	b.hi	1d10 <pts_ieee754_exp+0xf0>  // b.pmore
    1e28:	fmov	d1, #1.000000000000000000e+00
    1e2c:	fcmp	d0, d1
    1e30:	b.eq	1ef4 <pts_ieee754_exp+0x2d4>  // b.none
    1e34:	ubfiz	x1, x4, #3, #1
    1e38:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    1e3c:	add	x2, x2, #0x0
    1e40:	eor	w0, w4, #0x1
    1e44:	add	x2, x2, x1
    1e48:	sub	w0, w0, w4
    1e4c:	mov	w1, #0x3ff00000            	// #1072693248
    1e50:	add	w1, w1, w0, lsl #20
    1e54:	fmov	d1, x1
    1e58:	ldr	d4, [x2, #432]
    1e5c:	ldr	d3, [x2, #448]
    1e60:	shl	d16, d1, #32
    1e64:	fsub	d4, d0, d4
    1e68:	fsub	d0, d4, d3
    1e6c:	fmul	d1, d0, d0
    1e70:	b	1c90 <pts_ieee754_exp+0x70>
    1e74:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1e78:	add	x0, x0, #0x0
    1e7c:	fmov	d2, #1.000000000000000000e+00
    1e80:	ldr	d1, [x0, #16]
    1e84:	fadd	d1, d1, d0
    1e88:	fcmpe	d1, d2
    1e8c:	b.gt	1ed4 <pts_ieee754_exp+0x2b4>
    1e90:	b	1c7c <pts_ieee754_exp+0x5c>
    1e94:	movi	d1, #0x0
    1e98:	cmp	w4, #0x0
    1e9c:	fcsel	d0, d0, d1, eq	// eq = none
    1ea0:	ret
    1ea4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ea8:	add	x0, x0, #0x0
    1eac:	ldr	d0, [x0, #16]
    1eb0:	ldr	d1, [x0, #16]
    1eb4:	fmul	d0, d0, d1
    1eb8:	ret
    1ebc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ec0:	add	x0, x0, #0x0
    1ec4:	fadd	d1, d0, d0
    1ec8:	ldr	d0, [x0, #32]
    1ecc:	fmul	d0, d1, d0
    1ed0:	ret
    1ed4:	fadd	d0, d0, d2
    1ed8:	ret
    1edc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ee0:	add	x0, x0, #0x0
    1ee4:	ldr	d0, [x0, #24]
    1ee8:	ldr	d1, [x0, #24]
    1eec:	fmul	d0, d0, d1
    1ef0:	ret
    1ef4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ef8:	ldr	d0, [x0]
    1efc:	ret
    1f00:	mov	w1, #0x3ff00000            	// #1072693248
    1f04:	add	w1, w1, w0, lsl #20
    1f08:	fmov	d2, x1
    1f0c:	shl	d16, d2, #32
    1f10:	b	1c90 <pts_ieee754_exp+0x70>

0000000000001f14 <pts_ieee754_log>:
    1f14:	fmov	x1, d0
    1f18:	mov	w3, #0xfffff               	// #1048575
    1f1c:	lsr	x2, x1, #32
    1f20:	mov	w0, w2
    1f24:	cmp	w2, w3
    1f28:	b.gt	1fd8 <pts_ieee754_log+0xc4>
    1f2c:	and	w0, w2, #0x7fffffff
    1f30:	orr	w0, w0, w1
    1f34:	cbz	w0, 20a0 <pts_ieee754_log+0x18c>
    1f38:	tbnz	w2, #31, 2124 <pts_ieee754_log+0x210>
    1f3c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    1f40:	fmov	d1, x0
    1f44:	mov	w6, #0xffffffca            	// #-54
    1f48:	mov	w2, #0x7fefffff            	// #2146435071
    1f4c:	fmul	d0, d0, d1
    1f50:	fmov	x1, d0
    1f54:	lsr	x0, x1, #32
    1f58:	cmp	w0, w2
    1f5c:	b.gt	1fe8 <pts_ieee754_log+0xd4>
    1f60:	and	w4, w0, #0xfffff
    1f64:	asr	w0, w0, #20
    1f68:	add	w3, w4, #0x95, lsl #12
    1f6c:	sub	w0, w0, #0x3ff
    1f70:	add	w3, w3, #0xf64
    1f74:	add	w5, w4, #0x2
    1f78:	and	w2, w3, #0x100000
    1f7c:	fmov	d0, #1.000000000000000000e+00
    1f80:	eor	w2, w2, #0x3ff00000
    1f84:	add	w0, w0, w6
    1f88:	orr	w2, w2, w4
    1f8c:	and	w5, w5, #0xfffff
    1f90:	add	w3, w0, w3, lsr #20
    1f94:	bfi	x1, x2, #32, #32
    1f98:	fmov	d1, x1
    1f9c:	fsub	d0, d1, d0
    1fa0:	cmp	w5, #0x2
    1fa4:	b.gt	1ff0 <pts_ieee754_log+0xdc>
    1fa8:	fcmp	d0, #0.0
    1fac:	b.ne	20ac <pts_ieee754_log+0x198>  // b.any
    1fb0:	movi	d0, #0x0
    1fb4:	cbz	w3, 1fd4 <pts_ieee754_log+0xc0>
    1fb8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1fbc:	scvtf	d1, w3
    1fc0:	ldr	d0, [x0]
    1fc4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1fc8:	ldr	d2, [x0]
    1fcc:	fmul	d0, d1, d0
    1fd0:	fmadd	d0, d1, d2, d0
    1fd4:	ret
    1fd8:	mov	w6, #0x0                   	// #0
    1fdc:	mov	w2, #0x7fefffff            	// #2146435071
    1fe0:	cmp	w0, w2
    1fe4:	b.le	1f60 <pts_ieee754_log+0x4c>
    1fe8:	fadd	d0, d0, d0
    1fec:	ret
    1ff0:	fmov	d2, #2.000000000000000000e+00
    1ff4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    1ff8:	sub	w1, w4, #0x61, lsl #12
    1ffc:	scvtf	d19, w3
    2000:	fadd	d2, d0, d2
    2004:	ldr	d18, [x0]
    2008:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    200c:	sub	w1, w1, #0x47a
    2010:	ldr	d16, [x0]
    2014:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2018:	fdiv	d2, d0, d2
    201c:	ldr	d6, [x0]
    2020:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2024:	ldr	d17, [x0]
    2028:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    202c:	ldr	d7, [x0]
    2030:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2034:	ldr	d1, [x0]
    2038:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    203c:	ldr	d4, [x0]
    2040:	mov	w0, #0xb851                	// #47185
    2044:	movk	w0, #0x6, lsl #16
    2048:	sub	w0, w0, w4
    204c:	orr	w0, w0, w1
    2050:	fmul	d5, d2, d2
    2054:	fmul	d3, d5, d5
    2058:	fmadd	d16, d3, d18, d16
    205c:	fmadd	d7, d3, d17, d7
    2060:	fmadd	d6, d16, d3, d6
    2064:	fmadd	d4, d7, d3, d4
    2068:	fmadd	d1, d6, d3, d1
    206c:	fmul	d1, d1, d5
    2070:	fmadd	d1, d4, d3, d1
    2074:	cmp	w0, #0x0
    2078:	b.le	20f0 <pts_ieee754_log+0x1dc>
    207c:	fmov	d3, #5.000000000000000000e-01
    2080:	fmul	d3, d0, d3
    2084:	fmul	d3, d3, d0
    2088:	fadd	d1, d1, d3
    208c:	fmul	d1, d1, d2
    2090:	cbnz	w3, 2130 <pts_ieee754_log+0x21c>
    2094:	fsub	d3, d3, d1
    2098:	fsub	d0, d0, d3
    209c:	ret
    20a0:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    20a4:	fmov	d0, x0
    20a8:	ret
    20ac:	mov	x0, #0x5555555555555555    	// #6148914691236517205
    20b0:	fmov	d2, #5.000000000000000000e-01
    20b4:	movk	x0, #0x3fd5, lsl #48
    20b8:	fmov	d3, x0
    20bc:	fmul	d1, d0, d0
    20c0:	fmsub	d2, d0, d3, d2
    20c4:	fmul	d1, d1, d2
    20c8:	cbz	w3, 211c <pts_ieee754_log+0x208>
    20cc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    20d0:	scvtf	d2, w3
    20d4:	ldr	d4, [x0]
    20d8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    20dc:	ldr	d3, [x0]
    20e0:	fmsub	d1, d2, d4, d1
    20e4:	fsub	d1, d1, d0
    20e8:	fnmsub	d0, d2, d3, d1
    20ec:	ret
    20f0:	fsub	d1, d0, d1
    20f4:	fmul	d1, d1, d2
    20f8:	cbz	w3, 211c <pts_ieee754_log+0x208>
    20fc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2100:	ldr	d3, [x0]
    2104:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2108:	ldr	d2, [x0]
    210c:	fmsub	d1, d19, d3, d1
    2110:	fsub	d1, d1, d0
    2114:	fnmsub	d0, d19, d2, d1
    2118:	ret
    211c:	fsub	d0, d0, d1
    2120:	ret
    2124:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2128:	fmov	d0, x0
    212c:	ret
    2130:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2134:	ldr	d4, [x0]
    2138:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    213c:	ldr	d2, [x0]
    2140:	fmadd	d1, d19, d4, d1
    2144:	fsub	d3, d3, d1
    2148:	fsub	d3, d3, d0
    214c:	fnmsub	d0, d19, d2, d3
    2150:	ret

0000000000002154 <pts_ieee754_log1p>:
    2154:	fmov	x1, d0
    2158:	mov	w3, #0x8279                	// #33401
    215c:	fmov	d1, d0
    2160:	movk	w3, #0x3fda, lsl #16
    2164:	lsr	x0, x1, #32
    2168:	mov	w2, w0
    216c:	cmp	w0, w3
    2170:	b.gt	21a4 <pts_ieee754_log1p+0x50>
    2174:	and	w1, w0, #0x7fffffff
    2178:	mov	w2, #0x3fefffff            	// #1072693247
    217c:	cmp	w1, w2
    2180:	b.le	2234 <pts_ieee754_log1p+0xe0>
    2184:	fmov	d2, #-1.000000000000000000e+00
    2188:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    218c:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    2190:	fmov	d0, x0
    2194:	fcmp	d1, d2
    2198:	fmov	d1, x1
    219c:	fcsel	d0, d0, d1, ne	// ne = any
    21a0:	ret
    21a4:	mov	w3, #0x7fefffff            	// #2146435071
    21a8:	cmp	w0, w3
    21ac:	b.gt	22dc <pts_ieee754_log1p+0x188>
    21b0:	mov	w3, #0x433fffff            	// #1128267775
    21b4:	cmp	w0, w3
    21b8:	b.le	2330 <pts_ieee754_log1p+0x1dc>
    21bc:	asr	w0, w0, #20
    21c0:	movi	d5, #0x0
    21c4:	sub	w0, w0, #0x3ff
    21c8:	mov	w3, #0xa09d                	// #41117
    21cc:	and	w2, w2, #0xfffff
    21d0:	and	x1, x1, #0xffffffff
    21d4:	movk	w3, #0x6, lsl #16
    21d8:	cmp	w2, w3
    21dc:	b.gt	2310 <pts_ieee754_log1p+0x1bc>
    21e0:	orr	w3, w2, #0x3ff00000
    21e4:	orr	x1, x1, x3, lsl #32
    21e8:	fmov	d1, x1
    21ec:	fmov	d2, #1.000000000000000000e+00
    21f0:	fmov	d0, #5.000000000000000000e-01
    21f4:	fsub	d1, d1, d2
    21f8:	fmul	d0, d1, d0
    21fc:	fmul	d0, d0, d1
    2200:	cbnz	w2, 2264 <pts_ieee754_log1p+0x110>
    2204:	fcmp	d1, #0.0
    2208:	b.ne	2364 <pts_ieee754_log1p+0x210>  // b.any
    220c:	movi	d0, #0x0
    2210:	cbz	w0, 21a0 <pts_ieee754_log1p+0x4c>
    2214:	scvtf	d1, w0
    2218:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    221c:	ldr	d0, [x0]
    2220:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2224:	ldr	d2, [x0]
    2228:	fmadd	d0, d1, d0, d5
    222c:	fmadd	d0, d1, d2, d0
    2230:	ret
    2234:	mov	w2, #0x3e1fffff            	// #1042284543
    2238:	cmp	w1, w2
    223c:	b.le	22e4 <pts_ieee754_log1p+0x190>
    2240:	mov	w1, #0x413b                	// #16699
    2244:	movk	w1, #0x402d, lsl #16
    2248:	add	w0, w0, w1
    224c:	cmp	w0, w1
    2250:	b.ls	2330 <pts_ieee754_log1p+0x1dc>  // b.plast
    2254:	fmov	d0, #5.000000000000000000e-01
    2258:	mov	w0, #0x0                   	// #0
    225c:	fmul	d0, d1, d0
    2260:	fmul	d0, d0, d1
    2264:	fmov	d2, #2.000000000000000000e+00
    2268:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    226c:	fadd	d2, d1, d2
    2270:	ldr	d19, [x1]
    2274:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    2278:	ldr	d18, [x1]
    227c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    2280:	fdiv	d2, d1, d2
    2284:	ldr	d17, [x1]
    2288:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    228c:	ldr	d16, [x1]
    2290:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    2294:	ldr	d7, [x1]
    2298:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    229c:	ldr	d6, [x1]
    22a0:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    22a4:	ldr	d4, [x1]
    22a8:	fmul	d3, d2, d2
    22ac:	fmadd	d18, d3, d19, d18
    22b0:	fmadd	d17, d18, d3, d17
    22b4:	fmadd	d16, d17, d3, d16
    22b8:	fmadd	d7, d16, d3, d7
    22bc:	fmadd	d6, d7, d3, d6
    22c0:	fmadd	d4, d6, d3, d4
    22c4:	fmadd	d3, d4, d3, d0
    22c8:	fmul	d2, d2, d3
    22cc:	cbnz	w0, 2384 <pts_ieee754_log1p+0x230>
    22d0:	fsub	d0, d0, d2
    22d4:	fsub	d0, d1, d0
    22d8:	ret
    22dc:	fadd	d0, d0, d0
    22e0:	ret
    22e4:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    22e8:	fmov	d2, x0
    22ec:	mov	w0, #0x3c8fffff            	// #1016070143
    22f0:	fadd	d1, d0, d2
    22f4:	fcmpe	d1, #0.0
    22f8:	ccmp	w1, w0, #0x0, gt
    22fc:	b.le	21a0 <pts_ieee754_log1p+0x4c>
    2300:	fmul	d2, d0, d0
    2304:	fmov	d1, #5.000000000000000000e-01
    2308:	fmsub	d0, d2, d1, d0
    230c:	ret
    2310:	orr	w3, w2, #0x3fe00000
    2314:	mov	w4, #0x100000              	// #1048576
    2318:	sub	w2, w4, w2
    231c:	add	w0, w0, #0x1
    2320:	orr	x1, x1, x3, lsl #32
    2324:	fmov	d1, x1
    2328:	asr	w2, w2, #2
    232c:	b	21ec <pts_ieee754_log1p+0x98>
    2330:	fmov	d5, #1.000000000000000000e+00
    2334:	fadd	d0, d1, d5
    2338:	fmov	x1, d0
    233c:	lsr	x0, x1, #32
    2340:	mov	w2, w0
    2344:	asr	w0, w0, #20
    2348:	sub	w0, w0, #0x3ff
    234c:	cmp	w0, #0x0
    2350:	b.le	23d8 <pts_ieee754_log1p+0x284>
    2354:	fsub	d1, d0, d1
    2358:	fsub	d5, d5, d1
    235c:	fdiv	d5, d5, d0
    2360:	b	21c8 <pts_ieee754_log1p+0x74>
    2364:	mov	x1, #0x5555555555555555    	// #6148914691236517205
    2368:	movk	x1, #0x3fe5, lsl #48
    236c:	fmov	d3, x1
    2370:	fmsub	d2, d1, d3, d2
    2374:	fmul	d2, d2, d0
    2378:	cbnz	w0, 23b0 <pts_ieee754_log1p+0x25c>
    237c:	fsub	d0, d1, d2
    2380:	ret
    2384:	scvtf	d4, w0
    2388:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    238c:	ldr	d3, [x0]
    2390:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2394:	ldr	d6, [x0]
    2398:	fmadd	d3, d4, d3, d5
    239c:	fadd	d2, d3, d2
    23a0:	fsub	d0, d0, d2
    23a4:	fsub	d0, d0, d1
    23a8:	fnmsub	d0, d4, d6, d0
    23ac:	ret
    23b0:	scvtf	d0, w0
    23b4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23b8:	ldr	d3, [x0]
    23bc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    23c0:	ldr	d4, [x0]
    23c4:	fmadd	d3, d0, d3, d5
    23c8:	fsub	d2, d2, d3
    23cc:	fsub	d2, d2, d1
    23d0:	fnmsub	d0, d0, d4, d2
    23d4:	ret
    23d8:	fsub	d5, d0, d5
    23dc:	fsub	d5, d1, d5
    23e0:	fdiv	d5, d5, d0
    23e4:	b	21c8 <pts_ieee754_log1p+0x74>
    23e8:	nop
    23ec:	nop

00000000000023f0 <pts_ieee754_acosh>:
    23f0:	fmov	x2, d0
    23f4:	mov	w1, #0x3fefffff            	// #1072693247
    23f8:	lsr	x0, x2, #32
    23fc:	cmp	w0, w1
    2400:	b.le	2484 <pts_ieee754_acosh+0x94>
    2404:	stp	x29, x30, [sp, #-32]!
    2408:	mov	w3, #0x41afffff            	// #1102053375
    240c:	mov	x29, sp
    2410:	stp	d8, d9, [sp, #16]
    2414:	fmov	d8, d0
    2418:	cmp	w0, w3
    241c:	b.gt	245c <pts_ieee754_acosh+0x6c>
    2420:	mov	w3, #0xc0100000            	// #-1072693248
    2424:	add	w3, w3, w0
    2428:	orr	w2, w3, w2
    242c:	cbz	w2, 24f8 <pts_ieee754_acosh+0x108>
    2430:	add	w1, w1, #0x100, lsl #12
    2434:	add	w1, w1, #0x1
    2438:	cmp	w0, w1
    243c:	b.le	24a0 <pts_ieee754_acosh+0xb0>
    2440:	fmov	d0, #-1.000000000000000000e+00
    2444:	fadd	d9, d8, d8
    2448:	fmadd	d0, d8, d8, d0
    244c:	fcmp	d0, #0.0
    2450:	b.pl	24c4 <pts_ieee754_acosh+0xd4>  // b.nfrst
    2454:	bl	0 <sqrt>
    2458:	b	24c8 <pts_ieee754_acosh+0xd8>
    245c:	mov	w1, #0x7fefffff            	// #2146435071
    2460:	cmp	w0, w1
    2464:	b.gt	2490 <pts_ieee754_acosh+0xa0>
    2468:	bl	1f14 <pts_ieee754_log>
    246c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2470:	ldp	d8, d9, [sp, #16]
    2474:	ldr	d1, [x0]
    2478:	ldp	x29, x30, [sp], #32
    247c:	fadd	d0, d0, d1
    2480:	ret
    2484:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2488:	fmov	d0, x0
    248c:	ret
    2490:	ldp	d8, d9, [sp, #16]
    2494:	fadd	d0, d0, d0
    2498:	ldp	x29, x30, [sp], #32
    249c:	ret
    24a0:	fmov	d0, #1.000000000000000000e+00
    24a4:	fmov	d1, #2.000000000000000000e+00
    24a8:	fsub	d8, d8, d0
    24ac:	fmul	d0, d8, d8
    24b0:	fmadd	d0, d8, d1, d0
    24b4:	fcmp	d0, #0.0
    24b8:	b.pl	24e4 <pts_ieee754_acosh+0xf4>  // b.nfrst
    24bc:	bl	0 <sqrt>
    24c0:	b	24e8 <pts_ieee754_acosh+0xf8>
    24c4:	fsqrt	d0, d0
    24c8:	fadd	d8, d8, d0
    24cc:	fmov	d0, #1.000000000000000000e+00
    24d0:	fdiv	d0, d0, d8
    24d4:	fsub	d0, d9, d0
    24d8:	ldp	d8, d9, [sp, #16]
    24dc:	ldp	x29, x30, [sp], #32
    24e0:	b	1f14 <pts_ieee754_log>
    24e4:	fsqrt	d0, d0
    24e8:	fadd	d0, d8, d0
    24ec:	ldp	d8, d9, [sp, #16]
    24f0:	ldp	x29, x30, [sp], #32
    24f4:	b	2154 <pts_ieee754_log1p>
    24f8:	ldp	d8, d9, [sp, #16]
    24fc:	movi	d0, #0x0
    2500:	ldp	x29, x30, [sp], #32
    2504:	ret
    2508:	nop
    250c:	nop

0000000000002510 <pts_ieee754_asinh>:
    2510:	fmov	x0, d0
    2514:	fmov	d1, d0
    2518:	mov	w1, #0x7fefffff            	// #2146435071
    251c:	lsr	x7, x0, #32
    2520:	and	w0, w7, #0x7fffffff
    2524:	cmp	w0, w1
    2528:	b.gt	25b4 <pts_ieee754_asinh+0xa4>
    252c:	stp	x29, x30, [sp, #-16]!
    2530:	mov	w1, #0x3e2fffff            	// #1043333119
    2534:	mov	x29, sp
    2538:	cmp	w0, w1
    253c:	b.le	2574 <pts_ieee754_asinh+0x64>
    2540:	fabs	d0, d0
    2544:	mov	w1, #0x41b00000            	// #1102053376
    2548:	cmp	w0, w1
    254c:	b.le	25bc <pts_ieee754_asinh+0xac>
    2550:	bl	1f14 <pts_ieee754_log>
    2554:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2558:	ldr	d1, [x0]
    255c:	fadd	d0, d0, d1
    2560:	fneg	d1, d0
    2564:	cmp	w7, #0x0
    2568:	fcsel	d0, d1, d0, le
    256c:	ldp	x29, x30, [sp], #16
    2570:	ret
    2574:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2578:	fmov	d2, #1.000000000000000000e+00
    257c:	ldr	d3, [x0]
    2580:	fadd	d3, d0, d3
    2584:	fcmpe	d3, d2
    2588:	b.gt	256c <pts_ieee754_asinh+0x5c>
    258c:	fmul	d3, d0, d0
    2590:	fabs	d0, d0
    2594:	fadd	d2, d3, d2
    2598:	fsqrt	d2, d2
    259c:	fmov	d1, #1.000000000000000000e+00
    25a0:	fadd	d2, d2, d1
    25a4:	fdiv	d3, d3, d2
    25a8:	fadd	d0, d3, d0
    25ac:	bl	2154 <pts_ieee754_log1p>
    25b0:	b	2560 <pts_ieee754_asinh+0x50>
    25b4:	fadd	d0, d0, d0
    25b8:	ret
    25bc:	fmul	d3, d1, d1
    25c0:	fmov	d1, #1.000000000000000000e+00
    25c4:	mov	w1, #0x40000000            	// #1073741824
    25c8:	fadd	d2, d3, d1
    25cc:	fsqrt	d2, d2
    25d0:	cmp	w0, w1
    25d4:	b.le	259c <pts_ieee754_asinh+0x8c>
    25d8:	fadd	d2, d0, d2
    25dc:	fmov	d3, #2.000000000000000000e+00
    25e0:	fdiv	d1, d1, d2
    25e4:	fmadd	d0, d0, d3, d1
    25e8:	bl	1f14 <pts_ieee754_log>
    25ec:	b	2560 <pts_ieee754_asinh+0x50>

00000000000025f0 <pts_ieee754_atanh>:
    25f0:	fmov	x0, d0
    25f4:	mov	w3, #0x3ff00000            	// #1072693248
    25f8:	neg	w1, w0
    25fc:	ubfx	x2, x0, #32, #31
    2600:	orr	w1, w1, w0
    2604:	orr	w1, w2, w1, lsr #31
    2608:	cmp	w1, w3
    260c:	b.hi	26b8 <pts_ieee754_atanh+0xc8>  // b.pmore
    2610:	cmp	w2, w3
    2614:	b.eq	26c4 <pts_ieee754_atanh+0xd4>  // b.none
    2618:	stp	x29, x30, [sp, #-16]!
    261c:	lsr	x5, x0, #32
    2620:	mov	w1, #0x3e2fffff            	// #1043333119
    2624:	mov	x29, sp
    2628:	cmp	w2, w1
    262c:	b.le	2674 <pts_ieee754_atanh+0x84>
    2630:	bfi	x0, x2, #32, #32
    2634:	fmov	d0, #1.000000000000000000e+00
    2638:	fmov	d1, x0
    263c:	mov	w0, #0x3fdfffff            	// #1071644671
    2640:	fadd	d2, d1, d1
    2644:	fsub	d0, d0, d1
    2648:	cmp	w2, w0
    264c:	b.le	2694 <pts_ieee754_atanh+0xa4>
    2650:	fdiv	d0, d2, d0
    2654:	bl	2154 <pts_ieee754_log1p>
    2658:	fmov	d1, #5.000000000000000000e-01
    265c:	fmul	d0, d0, d1
    2660:	fneg	d1, d0
    2664:	cmp	w5, #0x0
    2668:	fcsel	d0, d1, d0, lt	// lt = tstop
    266c:	ldp	x29, x30, [sp], #16
    2670:	ret
    2674:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    2678:	ldr	d2, [x1]
    267c:	fadd	d1, d0, d2
    2680:	fcmpe	d1, #0.0
    2684:	b.gt	266c <pts_ieee754_atanh+0x7c>
    2688:	bfi	x0, x2, #32, #32
    268c:	fmov	d1, x0
    2690:	fadd	d2, d1, d1
    2694:	fmov	d3, #1.000000000000000000e+00
    2698:	fmul	d0, d2, d1
    269c:	fsub	d1, d3, d1
    26a0:	fdiv	d0, d0, d1
    26a4:	fadd	d0, d0, d2
    26a8:	bl	2154 <pts_ieee754_log1p>
    26ac:	fmov	d1, #5.000000000000000000e-01
    26b0:	fmul	d0, d0, d1
    26b4:	b	2660 <pts_ieee754_atanh+0x70>
    26b8:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    26bc:	fmov	d0, x0
    26c0:	ret
    26c4:	fcmpe	d0, #0.0
    26c8:	mov	x0, #0x7ff0000000000000    	// #9218868437227405312
    26cc:	mov	x1, #0xfff0000000000000    	// #-4503599627370496
    26d0:	fmov	d0, x0
    26d4:	fmov	d1, x1
    26d8:	fcsel	d0, d0, d1, gt
    26dc:	ret

00000000000026e0 <pts_ieee754_log2>:
    26e0:	fmov	x0, d0
    26e4:	mov	w3, #0xfffff               	// #1048575
    26e8:	lsr	x2, x0, #32
    26ec:	mov	w4, w0
    26f0:	mov	w1, w2
    26f4:	cmp	w2, w3
    26f8:	b.gt	2840 <pts_ieee754_log2+0x160>
    26fc:	and	w1, w2, #0x7fffffff
    2700:	orr	w0, w1, w0
    2704:	cbz	w0, 2858 <pts_ieee754_log2+0x178>
    2708:	tbnz	w2, #31, 2864 <pts_ieee754_log2+0x184>
    270c:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2710:	fmov	d1, x0
    2714:	mov	w5, #0xffffffca            	// #-54
    2718:	mov	w2, #0x7fefffff            	// #2146435071
    271c:	fmul	d0, d0, d1
    2720:	fmov	x0, d0
    2724:	lsr	x1, x0, #32
    2728:	cmp	w1, w2
    272c:	b.gt	2850 <pts_ieee754_log2+0x170>
    2730:	cmp	w4, #0x0
    2734:	mov	w2, #0x3ff00000            	// #1072693248
    2738:	movi	d0, #0x0
    273c:	ccmp	w1, w2, #0x0, eq	// eq = none
    2740:	b.eq	283c <pts_ieee754_log2+0x15c>  // b.none
    2744:	and	w4, w1, #0xfffff
    2748:	fmov	d0, #1.000000000000000000e+00
    274c:	add	w3, w4, #0x95, lsl #12
    2750:	fmov	d5, #2.000000000000000000e+00
    2754:	add	w3, w3, #0xf64
    2758:	adrp	x6, 0 <__kernel_rem_pio2.constprop.0>
    275c:	and	w2, w3, #0x100000
    2760:	fmov	d7, #5.000000000000000000e-01
    2764:	eor	w2, w2, #0x3ff00000
    2768:	ldr	d25, [x6]
    276c:	orr	w2, w2, w4
    2770:	adrp	x6, 0 <__kernel_rem_pio2.constprop.0>
    2774:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    2778:	movi	v2.2d, #0xffffffff00000000
    277c:	bfi	x0, x2, #32, #32
    2780:	fmov	d1, x0
    2784:	ldr	d21, [x6]
    2788:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    278c:	fsub	d1, d1, d0
    2790:	ldr	d19, [x4]
    2794:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    2798:	ldr	d18, [x2]
    279c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    27a0:	asr	w1, w1, #20
    27a4:	ldr	d24, [x4]
    27a8:	adrp	x4, 0 <__kernel_rem_pio2.constprop.0>
    27ac:	fadd	d5, d1, d5
    27b0:	fmul	d7, d1, d7
    27b4:	ldr	d20, [x4]
    27b8:	sub	w1, w1, #0x3ff
    27bc:	ldr	d17, [x2]
    27c0:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    27c4:	add	w1, w1, w5
    27c8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    27cc:	fdiv	d5, d1, d5
    27d0:	fmsub	d4, d7, d1, d1
    27d4:	ldr	d16, [x2]
    27d8:	add	w3, w1, w3, lsr #20
    27dc:	ldr	d22, [x0]
    27e0:	scvtf	d0, w3
    27e4:	and	v4.8b, v4.8b, v2.8b
    27e8:	fsub	d2, d1, d4
    27ec:	fmadd	d23, d4, d16, d0
    27f0:	fmsub	d2, d7, d1, d2
    27f4:	fsub	d0, d0, d23
    27f8:	fmadd	d0, d4, d16, d0
    27fc:	fmul	d3, d5, d5
    2800:	fmul	d6, d3, d3
    2804:	fmadd	d21, d6, d25, d21
    2808:	fmadd	d20, d6, d24, d20
    280c:	fmadd	d19, d6, d21, d19
    2810:	fmadd	d17, d6, d20, d17
    2814:	fmadd	d18, d6, d19, d18
    2818:	fmul	d3, d3, d18
    281c:	fmadd	d3, d6, d17, d3
    2820:	fmadd	d3, d7, d1, d3
    2824:	fmadd	d1, d5, d3, d2
    2828:	fadd	d4, d4, d1
    282c:	fmul	d1, d1, d16
    2830:	fmadd	d1, d4, d22, d1
    2834:	fadd	d0, d0, d1
    2838:	fadd	d0, d0, d23
    283c:	ret
    2840:	mov	w5, #0x0                   	// #0
    2844:	mov	w2, #0x7fefffff            	// #2146435071
    2848:	cmp	w1, w2
    284c:	b.le	2730 <pts_ieee754_log2+0x50>
    2850:	fadd	d0, d0, d0
    2854:	ret
    2858:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    285c:	fmov	d0, x0
    2860:	ret
    2864:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2868:	fmov	d0, x0
    286c:	ret

0000000000002870 <pts_ieee754_log10>:
    2870:	fmov	x0, d0
    2874:	mov	w4, #0xfffff               	// #1048575
    2878:	lsr	x1, x0, #32
    287c:	cmp	w1, w4
    2880:	b.gt	2934 <pts_ieee754_log10+0xc4>
    2884:	and	w2, w1, #0x7fffffff
    2888:	orr	w0, w2, w0
    288c:	cbz	w0, 2958 <pts_ieee754_log10+0xe8>
    2890:	tbnz	w1, #31, 2964 <pts_ieee754_log10+0xf4>
    2894:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2898:	fmov	d1, x0
    289c:	mov	w4, #0xffffffca            	// #-54
    28a0:	fmul	d0, d0, d1
    28a4:	fmov	x0, d0
    28a8:	lsr	x2, x0, #32
    28ac:	mov	w3, w0
    28b0:	mov	w0, #0x7fefffff            	// #2146435071
    28b4:	cmp	w2, w0
    28b8:	b.gt	294c <pts_ieee754_log10+0xdc>
    28bc:	cmp	w3, #0x0
    28c0:	mov	w0, #0x3ff00000            	// #1072693248
    28c4:	movi	d0, #0x0
    28c8:	ccmp	w2, w0, #0x0, eq	// eq = none
    28cc:	b.eq	2954 <pts_ieee754_log10+0xe4>  // b.none
    28d0:	asr	w0, w2, #20
    28d4:	mov	w1, #0x3ff                 	// #1023
    28d8:	sub	w0, w0, #0x3ff
    28dc:	stp	x29, x30, [sp, #-16]!
    28e0:	add	w0, w0, w4
    28e4:	mov	x29, sp
    28e8:	lsr	w4, w0, #31
    28ec:	sub	w1, w1, w4
    28f0:	add	w0, w0, w4
    28f4:	bfi	w2, w1, #20, #12
    28f8:	scvtf	d20, w0
    28fc:	orr	x0, x3, x2, lsl #32
    2900:	fmov	d0, x0
    2904:	bl	1f14 <pts_ieee754_log>
    2908:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    290c:	ldp	x29, x30, [sp], #16
    2910:	ldr	d3, [x0]
    2914:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2918:	ldr	d2, [x0]
    291c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2920:	fmul	d0, d0, d3
    2924:	ldr	d1, [x0]
    2928:	fmadd	d0, d20, d2, d0
    292c:	fmadd	d0, d20, d1, d0
    2930:	ret
    2934:	mov	w2, w1
    2938:	mov	w3, w0
    293c:	mov	w4, #0x0                   	// #0
    2940:	mov	w0, #0x7fefffff            	// #2146435071
    2944:	cmp	w2, w0
    2948:	b.le	28bc <pts_ieee754_log10+0x4c>
    294c:	fadd	d0, d0, d0
    2950:	ret
    2954:	ret
    2958:	mov	x0, #0xfff0000000000000    	// #-4503599627370496
    295c:	fmov	d0, x0
    2960:	ret
    2964:	mov	x0, #0x7ff8000000000000    	// #9221120237041090560
    2968:	fmov	d0, x0
    296c:	ret

0000000000002970 <pts_ieee754_expm1>:
    2970:	fmov	x1, d0
    2974:	mov	w2, #0x6879                	// #26745
    2978:	fmov	d2, d0
    297c:	movk	w2, #0x4043, lsl #16
    2980:	ubfx	x0, x1, #32, #31
    2984:	lsr	x3, x1, #32
    2988:	cmp	w0, w2
    298c:	b.ls	2a18 <pts_ieee754_expm1+0xa8>  // b.plast
    2990:	mov	w2, #0x2e41                	// #11841
    2994:	movk	w2, #0x4086, lsl #16
    2998:	cmp	w0, w2
    299c:	b.ls	29d0 <pts_ieee754_expm1+0x60>  // b.plast
    29a0:	mov	w2, #0x7fefffff            	// #2146435071
    29a4:	cmp	w0, w2
    29a8:	b.ls	29c0 <pts_ieee754_expm1+0x50>  // b.plast
    29ac:	and	w0, w3, #0xfffff
    29b0:	orr	w0, w0, w1
    29b4:	cbz	w0, 2c3c <pts_ieee754_expm1+0x2cc>
    29b8:	fadd	d0, d0, d0
    29bc:	ret
    29c0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    29c4:	ldr	d0, [x0]
    29c8:	fcmpe	d2, d0
    29cc:	b.gt	2c60 <pts_ieee754_expm1+0x2f0>
    29d0:	tbnz	w3, #31, 2b14 <pts_ieee754_expm1+0x1a4>
    29d4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    29d8:	fmov	d0, #5.000000000000000000e-01
    29dc:	ldr	d1, [x0]
    29e0:	fmul	d1, d2, d1
    29e4:	fadd	d0, d0, d1
    29e8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    29ec:	ldr	d3, [x0]
    29f0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    29f4:	fcvtzs	w1, d0
    29f8:	ldr	d1, [x0]
    29fc:	scvtf	d0, w1
    2a00:	fmsub	d3, d0, d3, d2
    2a04:	fmul	d0, d0, d1
    2a08:	fsub	d2, d3, d0
    2a0c:	fsub	d3, d3, d2
    2a10:	fsub	d3, d3, d0
    2a14:	b	2a38 <pts_ieee754_expm1+0xc8>
    2a18:	mov	w1, #0x2e42                	// #11842
    2a1c:	movk	w1, #0x3fd6, lsl #16
    2a20:	cmp	w0, w1
    2a24:	b.hi	2b60 <pts_ieee754_expm1+0x1f0>  // b.pmore
    2a28:	mov	w2, #0x3c8fffff            	// #1016070143
    2a2c:	mov	w1, #0x0                   	// #0
    2a30:	cmp	w0, w2
    2a34:	b.ls	2b90 <pts_ieee754_expm1+0x220>  // b.plast
    2a38:	fmov	d18, #5.000000000000000000e-01
    2a3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a40:	fmov	d19, #1.000000000000000000e+00
    2a44:	fmov	d4, #3.000000000000000000e+00
    2a48:	fmul	d17, d2, d18
    2a4c:	ldr	d20, [x0]
    2a50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a54:	fmov	d5, #6.000000000000000000e+00
    2a58:	ldr	d16, [x0]
    2a5c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a60:	fmul	d1, d2, d17
    2a64:	ldr	d7, [x0]
    2a68:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a6c:	ldr	d6, [x0]
    2a70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2a74:	fmadd	d16, d1, d20, d16
    2a78:	ldr	d0, [x0]
    2a7c:	fmadd	d7, d16, d1, d7
    2a80:	fmadd	d6, d7, d1, d6
    2a84:	fmadd	d0, d6, d1, d0
    2a88:	fmadd	d0, d0, d1, d19
    2a8c:	fmsub	d4, d17, d0, d4
    2a90:	fmsub	d5, d2, d4, d5
    2a94:	fsub	d0, d0, d4
    2a98:	fdiv	d0, d0, d5
    2a9c:	fmul	d0, d0, d1
    2aa0:	cbz	w1, 2b08 <pts_ieee754_expm1+0x198>
    2aa4:	fsub	d0, d0, d3
    2aa8:	fnmsub	d3, d0, d2, d3
    2aac:	fsub	d3, d3, d1
    2ab0:	cmn	w1, #0x1
    2ab4:	b.eq	2be4 <pts_ieee754_expm1+0x274>  // b.none
    2ab8:	cmp	w1, #0x1
    2abc:	b.eq	2bc8 <pts_ieee754_expm1+0x258>  // b.none
    2ac0:	mov	w2, #0x3ff00000            	// #1072693248
    2ac4:	add	w3, w1, #0x1
    2ac8:	add	w0, w2, w1, lsl #20
    2acc:	fmov	d0, x0
    2ad0:	shl	d1, d0, #32
    2ad4:	cmp	w3, #0x39
    2ad8:	b.hi	2b40 <pts_ieee754_expm1+0x1d0>  // b.pmore
    2adc:	cmp	w1, #0x13
    2ae0:	b.gt	2bf4 <pts_ieee754_expm1+0x284>
    2ae4:	mov	w0, #0x200000              	// #2097152
    2ae8:	fsub	d3, d3, d2
    2aec:	asr	w0, w0, w1
    2af0:	sub	w2, w2, w0
    2af4:	fmov	d0, x2
    2af8:	shl	d0, d0, #32
    2afc:	fsub	d0, d0, d3
    2b00:	fmul	d0, d1, d0
    2b04:	ret
    2b08:	fnmsub	d1, d2, d0, d1
    2b0c:	fsub	d0, d2, d1
    2b10:	ret
    2b14:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b18:	fmov	d0, #-1.000000000000000000e+00
    2b1c:	ldr	d1, [x0]
    2b20:	fadd	d1, d2, d1
    2b24:	fcmpe	d1, #0.0
    2b28:	b.mi	29bc <pts_ieee754_expm1+0x4c>  // b.first
    2b2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b30:	fmov	d0, #-5.000000000000000000e-01
    2b34:	ldr	d1, [x0]
    2b38:	fmul	d1, d2, d1
    2b3c:	b	29e4 <pts_ieee754_expm1+0x74>
    2b40:	fsub	d3, d3, d2
    2b44:	fsub	d3, d19, d3
    2b48:	cmp	w1, #0x400
    2b4c:	b.eq	2c78 <pts_ieee754_expm1+0x308>  // b.none
    2b50:	fmul	d0, d1, d3
    2b54:	fmov	d1, #1.000000000000000000e+00
    2b58:	fsub	d0, d0, d1
    2b5c:	ret
    2b60:	mov	w1, #0xa2b1                	// #41649
    2b64:	movk	w1, #0x3ff0, lsl #16
    2b68:	cmp	w0, w1
    2b6c:	b.hi	2c1c <pts_ieee754_expm1+0x2ac>  // b.pmore
    2b70:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b74:	ldr	d3, [x0]
    2b78:	tbz	w3, #31, 2bb4 <pts_ieee754_expm1+0x244>
    2b7c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b80:	fadd	d3, d2, d3
    2b84:	mov	w1, #0xffffffff            	// #-1
    2b88:	ldr	d0, [x0]
    2b8c:	b	2a08 <pts_ieee754_expm1+0x98>
    2b90:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2b94:	add	x0, x0, #0x0
    2b98:	ldr	d1, [x0, #40]
    2b9c:	ldr	d0, [x0, #40]
    2ba0:	fadd	d1, d1, d2
    2ba4:	fadd	d0, d0, d2
    2ba8:	fsub	d1, d1, d0
    2bac:	fsub	d0, d2, d1
    2bb0:	ret
    2bb4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2bb8:	fsub	d3, d2, d3
    2bbc:	mov	w1, #0x1                   	// #1
    2bc0:	ldr	d0, [x0]
    2bc4:	b	2a08 <pts_ieee754_expm1+0x98>
    2bc8:	fmov	d0, #-2.500000000000000000e-01
    2bcc:	fcmpe	d2, d0
    2bd0:	b.mi	2c4c <pts_ieee754_expm1+0x2dc>  // b.first
    2bd4:	fsub	d3, d2, d3
    2bd8:	fmov	d1, #2.000000000000000000e+00
    2bdc:	fmadd	d0, d3, d1, d19
    2be0:	ret
    2be4:	fsub	d3, d2, d3
    2be8:	fmov	d1, #-5.000000000000000000e-01
    2bec:	fmadd	d0, d3, d18, d1
    2bf0:	ret
    2bf4:	mov	w0, #0x3ff                 	// #1023
    2bf8:	sub	w0, w0, w1
    2bfc:	lsl	w0, w0, #20
    2c00:	fmov	d0, x0
    2c04:	shl	d0, d0, #32
    2c08:	fadd	d3, d3, d0
    2c0c:	fsub	d2, d2, d3
    2c10:	fadd	d2, d2, d19
    2c14:	fmul	d0, d2, d1
    2c18:	ret
    2c1c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2c20:	cmp	w3, #0x0
    2c24:	fmov	d0, #-5.000000000000000000e-01
    2c28:	fmov	d3, #5.000000000000000000e-01
    2c2c:	ldr	d1, [x0]
    2c30:	fcsel	d0, d0, d3, lt	// lt = tstop
    2c34:	fmul	d1, d2, d1
    2c38:	b	29e4 <pts_ieee754_expm1+0x74>
    2c3c:	cmp	w3, #0x0
    2c40:	fmov	d1, #-1.000000000000000000e+00
    2c44:	fcsel	d0, d0, d1, ge	// ge = tcont
    2c48:	ret
    2c4c:	fadd	d18, d2, d18
    2c50:	fmov	d1, #-2.000000000000000000e+00
    2c54:	fsub	d3, d3, d18
    2c58:	fmul	d0, d3, d1
    2c5c:	ret
    2c60:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2c64:	add	x0, x0, #0x0
    2c68:	ldr	d0, [x0, #40]
    2c6c:	ldr	d1, [x0, #40]
    2c70:	fmul	d0, d0, d1
    2c74:	ret
    2c78:	fadd	d3, d3, d3
    2c7c:	mov	x0, #0x7fe0000000000000    	// #9214364837600034816
    2c80:	fmov	d0, x0
    2c84:	fmul	d0, d3, d0
    2c88:	b	2b54 <pts_ieee754_expm1+0x1e4>
    2c8c:	nop

0000000000002c90 <pts_ieee754_cbrt>:
    2c90:	fmov	x1, d0
    2c94:	fmov	d3, d0
    2c98:	mov	w3, #0x7fefffff            	// #2146435071
    2c9c:	ubfx	x0, x1, #32, #31
    2ca0:	lsr	x2, x1, #32
    2ca4:	cmp	w0, w3
    2ca8:	b.hi	2d94 <pts_ieee754_cbrt+0x104>  // b.pmore
    2cac:	and	w3, w2, #0x80000000
    2cb0:	tst	x2, #0x7ff00000
    2cb4:	b.ne	2ce8 <pts_ieee754_cbrt+0x58>  // b.any
    2cb8:	orr	w0, w0, w1
    2cbc:	cbz	w0, 2d90 <pts_ieee754_cbrt+0x100>
    2cc0:	mov	x0, #0x4350000000000000    	// #4850376798678024192
    2cc4:	fmov	d1, x0
    2cc8:	mov	w2, #0xaaab                	// #43691
    2ccc:	mov	w1, #0x7893                	// #30867
    2cd0:	fmul	d1, d0, d1
    2cd4:	movk	w2, #0xaaaa, lsl #16
    2cd8:	movk	w1, #0x297f, lsl #16
    2cdc:	fmov	x0, d1
    2ce0:	ubfx	x0, x0, #32, #31
    2ce4:	b	2cf8 <pts_ieee754_cbrt+0x68>
    2ce8:	mov	w2, #0xaaab                	// #43691
    2cec:	mov	w1, #0x7893                	// #30867
    2cf0:	movk	w2, #0xaaaa, lsl #16
    2cf4:	movk	w1, #0x2a9f, lsl #16
    2cf8:	umull	x0, w0, w2
    2cfc:	fmov	d4, #2.000000000000000000e+00
    2d00:	lsr	x0, x0, #33
    2d04:	add	w0, w0, w1
    2d08:	orr	w0, w0, w3
    2d0c:	fmov	d0, x0
    2d10:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d14:	shl	d1, d0, #32
    2d18:	ldr	d16, [x0]
    2d1c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d20:	ldr	d7, [x0]
    2d24:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d28:	fdiv	d17, d1, d3
    2d2c:	fmul	d0, d1, d1
    2d30:	ldr	d6, [x0]
    2d34:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d38:	ldr	d5, [x0]
    2d3c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2d40:	ldr	d2, [x0]
    2d44:	mov	x0, #0x80000000            	// #2147483648
    2d48:	fmul	d0, d0, d17
    2d4c:	fmadd	d7, d0, d16, d7
    2d50:	fmadd	d5, d0, d6, d5
    2d54:	fmul	d6, d0, d0
    2d58:	fmul	d6, d6, d0
    2d5c:	fmadd	d2, d7, d0, d2
    2d60:	fmadd	d2, d6, d5, d2
    2d64:	fmul	d1, d2, d1
    2d68:	fmov	x1, d1
    2d6c:	add	x0, x1, x0
    2d70:	and	x0, x0, #0xffffffffc0000000
    2d74:	fmov	d1, x0
    2d78:	fmul	d0, d1, d1
    2d7c:	fdiv	d3, d3, d0
    2d80:	fmadd	d0, d1, d4, d3
    2d84:	fsub	d3, d3, d1
    2d88:	fdiv	d3, d3, d0
    2d8c:	fmadd	d0, d1, d3, d1
    2d90:	ret
    2d94:	fadd	d0, d0, d0
    2d98:	ret
    2d9c:	nop

0000000000002da0 <pts_ieee754_sin>:
    2da0:	sub	sp, sp, #0x50
    2da4:	mov	w2, #0x21fb                	// #8699
    2da8:	adrp	x0, 0 <__stack_chk_guard>
    2dac:	ldr	x0, [x0]
    2db0:	fmov	d1, d0
    2db4:	stp	x29, x30, [sp, #48]
    2db8:	add	x29, sp, #0x30
    2dbc:	movk	w2, #0x3fe9, lsl #16
    2dc0:	ldr	x1, [x0]
    2dc4:	str	x1, [sp, #40]
    2dc8:	mov	x1, #0x0                   	// #0
    2dcc:	fmov	x0, d0
    2dd0:	ubfx	x1, x0, #32, #31
    2dd4:	cmp	w1, w2
    2dd8:	b.le	2f18 <pts_ieee754_sin+0x178>
    2ddc:	mov	w2, #0x7fefffff            	// #2146435071
    2de0:	cmp	w1, w2
    2de4:	b.le	2e14 <pts_ieee754_sin+0x74>
    2de8:	fsub	d0, d0, d0
    2dec:	adrp	x0, 0 <__stack_chk_guard>
    2df0:	ldr	x0, [x0]
    2df4:	ldr	x2, [sp, #40]
    2df8:	ldr	x1, [x0]
    2dfc:	subs	x2, x2, x1
    2e00:	mov	x1, #0x0                   	// #0
    2e04:	b.ne	3458 <pts_ieee754_sin+0x6b8>  // b.any
    2e08:	ldp	x29, x30, [sp, #48]
    2e0c:	add	sp, sp, #0x50
    2e10:	ret
    2e14:	mov	w2, #0xd97b                	// #55675
    2e18:	str	x19, [sp, #64]
    2e1c:	movk	w2, #0x4002, lsl #16
    2e20:	lsr	x19, x0, #32
    2e24:	cmp	w1, w2
    2e28:	b.gt	2f80 <pts_ieee754_sin+0x1e0>
    2e2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2e30:	ldr	d0, [x0]
    2e34:	mov	w0, #0x21fb                	// #8699
    2e38:	movk	w0, #0x3ff9, lsl #16
    2e3c:	cmp	w19, #0x0
    2e40:	b.le	328c <pts_ieee754_sin+0x4ec>
    2e44:	fsub	d1, d1, d0
    2e48:	cmp	w1, w0
    2e4c:	b.eq	33d8 <pts_ieee754_sin+0x638>  // b.none
    2e50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2e54:	ldr	d2, [x0]
    2e58:	fsub	d0, d1, d2
    2e5c:	fsub	d1, d1, d0
    2e60:	fmov	x0, d0
    2e64:	fsub	d1, d1, d2
    2e68:	lsr	x1, x0, #32
    2e6c:	and	w1, w1, #0x7fffffff
    2e70:	mov	w0, #0x3e3fffff            	// #1044381695
    2e74:	cmp	w1, w0
    2e78:	b.le	3178 <pts_ieee754_sin+0x3d8>
    2e7c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2e80:	fmul	d3, d0, d0
    2e84:	ldr	d16, [x0]
    2e88:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2e8c:	ldr	d7, [x0]
    2e90:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2e94:	fmadd	d7, d3, d16, d7
    2e98:	ldr	d6, [x0]
    2e9c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ea0:	ldr	d5, [x0]
    2ea4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2ea8:	ldr	d2, [x0]
    2eac:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2eb0:	ldr	d4, [x0]
    2eb4:	mov	w0, #0x3332                	// #13106
    2eb8:	fmadd	d6, d3, d7, d6
    2ebc:	movk	w0, #0x3fd3, lsl #16
    2ec0:	fmadd	d5, d3, d6, d5
    2ec4:	fmadd	d2, d3, d5, d2
    2ec8:	fmadd	d4, d3, d2, d4
    2ecc:	fmul	d4, d3, d4
    2ed0:	cmp	w1, w0
    2ed4:	b.le	31cc <pts_ieee754_sin+0x42c>
    2ed8:	mov	w0, #0x3fe90000            	// #1072234496
    2edc:	cmp	w1, w0
    2ee0:	b.gt	33f0 <pts_ieee754_sin+0x650>
    2ee4:	sub	w1, w1, #0x200, lsl #12
    2ee8:	fmov	d2, x1
    2eec:	fmov	d5, #1.000000000000000000e+00
    2ef0:	shl	d2, d2, #32
    2ef4:	fsub	d5, d5, d2
    2ef8:	fmov	d6, #5.000000000000000000e-01
    2efc:	fmul	d1, d0, d1
    2f00:	fnmsub	d1, d3, d4, d1
    2f04:	fnmsub	d2, d3, d6, d2
    2f08:	ldr	x19, [sp, #64]
    2f0c:	fsub	d2, d2, d1
    2f10:	fsub	d0, d5, d2
    2f14:	b	2dec <pts_ieee754_sin+0x4c>
    2f18:	mov	w0, #0x3e3fffff            	// #1044381695
    2f1c:	cmp	w1, w0
    2f20:	b.gt	2f2c <pts_ieee754_sin+0x18c>
    2f24:	fcvtzs	w0, d0
    2f28:	cbz	w0, 2dec <pts_ieee754_sin+0x4c>
    2f2c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f30:	fmul	d2, d1, d1
    2f34:	ldr	d0, [x0]
    2f38:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f3c:	ldr	d7, [x0]
    2f40:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f44:	fmadd	d7, d2, d0, d7
    2f48:	fmul	d0, d1, d2
    2f4c:	ldr	d6, [x0]
    2f50:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f54:	ldr	d5, [x0]
    2f58:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f5c:	ldr	d4, [x0]
    2f60:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    2f64:	ldr	d3, [x0]
    2f68:	fmadd	d6, d2, d7, d6
    2f6c:	fmadd	d5, d2, d6, d5
    2f70:	fmadd	d4, d2, d5, d4
    2f74:	fmadd	d2, d2, d4, d3
    2f78:	fmadd	d0, d0, d2, d1
    2f7c:	b	2dec <pts_ieee754_sin+0x4c>
    2f80:	mov	w2, #0x21fb                	// #8699
    2f84:	movk	w2, #0x4139, lsl #16
    2f88:	cmp	w1, w2
    2f8c:	b.le	3008 <pts_ieee754_sin+0x268>
    2f90:	asr	w2, w1, #20
    2f94:	mov	x3, #0x4170000000000000    	// #4715268809856909312
    2f98:	sub	w2, w2, #0x416
    2f9c:	fmov	d1, x3
    2fa0:	mov	w3, #0x3                   	// #3
    2fa4:	sub	w1, w1, w2, lsl #20
    2fa8:	bfi	x0, x1, #32, #32
    2fac:	fmov	d0, x0
    2fb0:	fcvtzs	w0, d0
    2fb4:	scvtf	d2, w0
    2fb8:	fsub	d0, d0, d2
    2fbc:	str	d2, [sp, #16]
    2fc0:	fmul	d0, d0, d1
    2fc4:	fcvtzs	w0, d0
    2fc8:	scvtf	d2, w0
    2fcc:	fsub	d0, d0, d2
    2fd0:	fmul	d0, d0, d1
    2fd4:	fcmp	d0, #0.0
    2fd8:	stp	d2, d0, [sp, #24]
    2fdc:	b.ne	2fec <pts_ieee754_sin+0x24c>  // b.any
    2fe0:	cmp	w0, #0x0
    2fe4:	cset	w3, ne	// ne = any
    2fe8:	add	w3, w3, #0x1
    2fec:	mov	x1, sp
    2ff0:	add	x0, sp, #0x10
    2ff4:	bl	0 <__kernel_rem_pio2.constprop.0>
    2ff8:	ldr	d0, [sp]
    2ffc:	tbnz	w19, #31, 3428 <pts_ieee754_sin+0x688>
    3000:	ldr	d1, [sp, #8]
    3004:	b	30d8 <pts_ieee754_sin+0x338>
    3008:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    300c:	fabs	d1, d0
    3010:	fmov	d0, #5.000000000000000000e-01
    3014:	ldr	d3, [x0]
    3018:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    301c:	ldr	d4, [x0]
    3020:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3024:	fmadd	d0, d1, d3, d0
    3028:	ldr	d2, [x0]
    302c:	fcvtzs	w0, d0
    3030:	scvtf	d3, w0
    3034:	fmsub	d1, d3, d4, d1
    3038:	fmul	d2, d3, d2
    303c:	fsub	d0, d1, d2
    3040:	cmp	w0, #0x1f
    3044:	b.le	31ec <pts_ieee754_sin+0x44c>
    3048:	fmov	x2, d0
    304c:	asr	w1, w1, #20
    3050:	ubfx	x2, x2, #52, #11
    3054:	sub	w2, w1, w2
    3058:	cmp	w2, #0x10
    305c:	b.le	30c0 <pts_ieee754_sin+0x320>
    3060:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3064:	ldr	d0, [x2]
    3068:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    306c:	ldr	d5, [x2]
    3070:	fmsub	d4, d3, d0, d1
    3074:	fsub	d2, d1, d4
    3078:	fmov	d1, d4
    307c:	fmsub	d2, d3, d0, d2
    3080:	fnmsub	d2, d3, d5, d2
    3084:	fsub	d0, d4, d2
    3088:	fmov	x2, d0
    308c:	ubfx	x2, x2, #52, #11
    3090:	sub	w1, w1, w2
    3094:	cmp	w1, #0x31
    3098:	b.le	30c0 <pts_ieee754_sin+0x320>
    309c:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    30a0:	ldr	d5, [x1]
    30a4:	adrp	x1, 0 <__kernel_rem_pio2.constprop.0>
    30a8:	ldr	d2, [x1]
    30ac:	fmsub	d1, d3, d5, d4
    30b0:	fsub	d0, d4, d1
    30b4:	fmsub	d0, d3, d5, d0
    30b8:	fnmsub	d2, d3, d2, d0
    30bc:	fsub	d0, d1, d2
    30c0:	fsub	d1, d1, d0
    30c4:	fsub	d1, d1, d2
    30c8:	tbz	w19, #31, 30d8 <pts_ieee754_sin+0x338>
    30cc:	fneg	d0, d0
    30d0:	fneg	d1, d1
    30d4:	neg	w0, w0
    30d8:	fmov	x1, d0
    30dc:	and	w0, w0, #0x3
    30e0:	lsr	x1, x1, #32
    30e4:	and	w2, w1, #0x7fffffff
    30e8:	cmp	w0, #0x1
    30ec:	b.eq	2e6c <pts_ieee754_sin+0xcc>  // b.none
    30f0:	cmp	w0, #0x2
    30f4:	b.eq	320c <pts_ieee754_sin+0x46c>  // b.none
    30f8:	cbnz	w0, 32b8 <pts_ieee754_sin+0x518>
    30fc:	mov	w0, #0x3e3fffff            	// #1044381695
    3100:	cmp	w2, w0
    3104:	b.gt	3110 <pts_ieee754_sin+0x370>
    3108:	fcvtzs	w0, d0
    310c:	cbz	w0, 3420 <pts_ieee754_sin+0x680>
    3110:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3114:	fmul	d2, d0, d0
    3118:	fmov	d17, #5.000000000000000000e-01
    311c:	ldr	d7, [x0]
    3120:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3124:	ldr	x19, [sp, #64]
    3128:	ldr	d6, [x0]
    312c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3130:	fmadd	d6, d2, d7, d6
    3134:	fmul	d7, d2, d0
    3138:	ldr	d5, [x0]
    313c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3140:	ldr	d4, [x0]
    3144:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3148:	ldr	d3, [x0]
    314c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3150:	ldr	d16, [x0]
    3154:	fmadd	d5, d2, d6, d5
    3158:	fmadd	d4, d2, d5, d4
    315c:	fmadd	d3, d2, d4, d3
    3160:	fmul	d3, d7, d3
    3164:	fnmsub	d3, d1, d17, d3
    3168:	fnmsub	d2, d2, d3, d1
    316c:	fmadd	d2, d7, d16, d2
    3170:	fsub	d0, d0, d2
    3174:	b	2dec <pts_ieee754_sin+0x4c>
    3178:	fcvtzs	w0, d0
    317c:	cbz	w0, 3408 <pts_ieee754_sin+0x668>
    3180:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3184:	fmul	d3, d0, d0
    3188:	ldr	d16, [x0]
    318c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3190:	ldr	d7, [x0]
    3194:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3198:	fmadd	d7, d3, d16, d7
    319c:	ldr	d6, [x0]
    31a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31a4:	ldr	d5, [x0]
    31a8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31ac:	ldr	d2, [x0]
    31b0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    31b4:	ldr	d4, [x0]
    31b8:	fmadd	d6, d3, d7, d6
    31bc:	fmadd	d5, d6, d3, d5
    31c0:	fmadd	d2, d3, d5, d2
    31c4:	fmadd	d4, d3, d2, d4
    31c8:	fmul	d4, d3, d4
    31cc:	fmul	d1, d0, d1
    31d0:	fmov	d2, #5.000000000000000000e-01
    31d4:	fnmsub	d1, d3, d4, d1
    31d8:	fmov	d0, #1.000000000000000000e+00
    31dc:	ldr	x19, [sp, #64]
    31e0:	fnmsub	d1, d3, d2, d1
    31e4:	fsub	d0, d0, d1
    31e8:	b	2dec <pts_ieee754_sin+0x4c>
    31ec:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    31f0:	add	x2, x2, #0x0
    31f4:	add	x2, x2, #0x110
    31f8:	sub	w3, w0, #0x1
    31fc:	ldr	w2, [x2, w3, sxtw #2]
    3200:	cmp	w1, w2
    3204:	b.ne	30c0 <pts_ieee754_sin+0x320>  // b.any
    3208:	b	3048 <pts_ieee754_sin+0x2a8>
    320c:	mov	w0, #0x3e3fffff            	// #1044381695
    3210:	cmp	w2, w0
    3214:	b.gt	3220 <pts_ieee754_sin+0x480>
    3218:	fcvtzs	w0, d0
    321c:	cbz	w0, 3280 <pts_ieee754_sin+0x4e0>
    3220:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3224:	fmul	d2, d0, d0
    3228:	fmov	d17, #5.000000000000000000e-01
    322c:	ldr	d7, [x0]
    3230:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3234:	ldr	d6, [x0]
    3238:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    323c:	fmadd	d6, d2, d7, d6
    3240:	fmul	d7, d2, d0
    3244:	ldr	d5, [x0]
    3248:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    324c:	ldr	d4, [x0]
    3250:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3254:	ldr	d3, [x0]
    3258:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    325c:	ldr	d16, [x0]
    3260:	fmadd	d5, d2, d6, d5
    3264:	fmadd	d4, d2, d5, d4
    3268:	fmadd	d3, d2, d4, d3
    326c:	fmul	d3, d7, d3
    3270:	fnmsub	d3, d1, d17, d3
    3274:	fnmsub	d2, d2, d3, d1
    3278:	fmadd	d2, d7, d16, d2
    327c:	fsub	d0, d0, d2
    3280:	ldr	x19, [sp, #64]
    3284:	fneg	d0, d0
    3288:	b	2dec <pts_ieee754_sin+0x4c>
    328c:	fadd	d1, d1, d0
    3290:	cmp	w1, w0
    3294:	b.eq	3440 <pts_ieee754_sin+0x6a0>  // b.none
    3298:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    329c:	ldr	d2, [x0]
    32a0:	fadd	d0, d1, d2
    32a4:	fsub	d1, d1, d0
    32a8:	fmov	x0, d0
    32ac:	fadd	d1, d1, d2
    32b0:	lsr	x1, x0, #32
    32b4:	nop
    32b8:	and	w1, w1, #0x7fffffff
    32bc:	mov	w0, #0x3e3fffff            	// #1044381695
    32c0:	cmp	w1, w0
    32c4:	b.gt	3338 <pts_ieee754_sin+0x598>
    32c8:	fcvtzs	w0, d0
    32cc:	cbz	w0, 3414 <pts_ieee754_sin+0x674>
    32d0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32d4:	fmul	d3, d0, d0
    32d8:	ldr	d16, [x0]
    32dc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32e0:	ldr	d7, [x0]
    32e4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32e8:	fmadd	d7, d3, d16, d7
    32ec:	ldr	d6, [x0]
    32f0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32f4:	ldr	d5, [x0]
    32f8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    32fc:	ldr	d2, [x0]
    3300:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3304:	ldr	d4, [x0]
    3308:	fmadd	d6, d3, d7, d6
    330c:	fmadd	d5, d3, d6, d5
    3310:	fmadd	d2, d3, d5, d2
    3314:	fmadd	d4, d3, d2, d4
    3318:	fmul	d4, d3, d4
    331c:	fmul	d1, d0, d1
    3320:	fmov	d2, #5.000000000000000000e-01
    3324:	fnmsub	d1, d4, d3, d1
    3328:	fmov	d0, #1.000000000000000000e+00
    332c:	fnmsub	d1, d3, d2, d1
    3330:	fsub	d0, d0, d1
    3334:	b	3280 <pts_ieee754_sin+0x4e0>
    3338:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    333c:	fmul	d3, d0, d0
    3340:	ldr	d16, [x0]
    3344:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3348:	ldr	d7, [x0]
    334c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3350:	fmadd	d7, d3, d16, d7
    3354:	ldr	d6, [x0]
    3358:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    335c:	ldr	d5, [x0]
    3360:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3364:	ldr	d2, [x0]
    3368:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    336c:	ldr	d4, [x0]
    3370:	mov	w0, #0x3332                	// #13106
    3374:	fmadd	d6, d3, d7, d6
    3378:	movk	w0, #0x3fd3, lsl #16
    337c:	fmadd	d5, d3, d6, d5
    3380:	fmadd	d2, d3, d5, d2
    3384:	fmadd	d4, d3, d2, d4
    3388:	fmul	d4, d3, d4
    338c:	cmp	w1, w0
    3390:	b.le	331c <pts_ieee754_sin+0x57c>
    3394:	mov	w0, #0x3fe90000            	// #1072234496
    3398:	cmp	w1, w0
    339c:	b.gt	33fc <pts_ieee754_sin+0x65c>
    33a0:	sub	w1, w1, #0x200, lsl #12
    33a4:	fmov	d2, x1
    33a8:	fmov	d5, #1.000000000000000000e+00
    33ac:	shl	d2, d2, #32
    33b0:	fsub	d5, d5, d2
    33b4:	fmov	d6, #5.000000000000000000e-01
    33b8:	fmul	d1, d0, d1
    33bc:	fnmsub	d1, d3, d4, d1
    33c0:	fnmsub	d2, d3, d6, d2
    33c4:	ldr	x19, [sp, #64]
    33c8:	fsub	d2, d2, d1
    33cc:	fsub	d0, d5, d2
    33d0:	fneg	d0, d0
    33d4:	b	2dec <pts_ieee754_sin+0x4c>
    33d8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33dc:	ldr	d0, [x0]
    33e0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    33e4:	ldr	d2, [x0]
    33e8:	fsub	d1, d1, d0
    33ec:	b	2e58 <pts_ieee754_sin+0xb8>
    33f0:	fmov	d5, #7.187500000000000000e-01
    33f4:	fmov	d2, #2.812500000000000000e-01
    33f8:	b	2ef8 <pts_ieee754_sin+0x158>
    33fc:	fmov	d5, #7.187500000000000000e-01
    3400:	fmov	d2, #2.812500000000000000e-01
    3404:	b	33b4 <pts_ieee754_sin+0x614>
    3408:	ldr	x19, [sp, #64]
    340c:	fmov	d0, #1.000000000000000000e+00
    3410:	b	2dec <pts_ieee754_sin+0x4c>
    3414:	ldr	x19, [sp, #64]
    3418:	fmov	d0, #-1.000000000000000000e+00
    341c:	b	2dec <pts_ieee754_sin+0x4c>
    3420:	ldr	x19, [sp, #64]
    3424:	b	2dec <pts_ieee754_sin+0x4c>
    3428:	fneg	d0, d0
    342c:	ldr	d1, [sp, #8]
    3430:	neg	w0, w0
    3434:	fneg	d1, d1
    3438:	str	d0, [sp]
    343c:	b	30d8 <pts_ieee754_sin+0x338>
    3440:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3444:	ldr	d0, [x0]
    3448:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    344c:	ldr	d2, [x0]
    3450:	fadd	d1, d1, d0
    3454:	b	32a0 <pts_ieee754_sin+0x500>
    3458:	str	x19, [sp, #64]
    345c:	bl	0 <__stack_chk_fail>

0000000000003460 <pts_ieee754_tan>:
    3460:	sub	sp, sp, #0x30
    3464:	mov	w2, #0x21fb                	// #8699
    3468:	adrp	x0, 0 <__stack_chk_guard>
    346c:	ldr	x0, [x0]
    3470:	fmov	d1, d0
    3474:	stp	x29, x30, [sp, #32]
    3478:	add	x29, sp, #0x20
    347c:	movk	w2, #0x3fe9, lsl #16
    3480:	ldr	x1, [x0]
    3484:	str	x1, [sp, #24]
    3488:	mov	x1, #0x0                   	// #0
    348c:	fmov	x0, d0
    3490:	lsr	x1, x0, #32
    3494:	and	w0, w1, #0x7fffffff
    3498:	cmp	w0, w2
    349c:	b.le	3568 <pts_ieee754_tan+0x108>
    34a0:	mov	w1, #0x7fefffff            	// #2146435071
    34a4:	cmp	w0, w1
    34a8:	b.le	34d8 <pts_ieee754_tan+0x78>
    34ac:	fsub	d0, d0, d0
    34b0:	adrp	x0, 0 <__stack_chk_guard>
    34b4:	ldr	x0, [x0]
    34b8:	ldr	x2, [sp, #24]
    34bc:	ldr	x1, [x0]
    34c0:	subs	x2, x2, x1
    34c4:	mov	x1, #0x0                   	// #0
    34c8:	b.ne	3838 <pts_ieee754_tan+0x3d8>  // b.any
    34cc:	ldp	x29, x30, [sp, #32]
    34d0:	add	sp, sp, #0x30
    34d4:	ret
    34d8:	add	x0, sp, #0x8
    34dc:	bl	954 <__ieee754_rem_pio2>
    34e0:	ldp	d1, d2, [sp, #8]
    34e4:	ubfiz	w2, w0, #1, #1
    34e8:	mov	w1, #0x1                   	// #1
    34ec:	sub	w2, w1, w2
    34f0:	lsl	w0, w0, #1
    34f4:	mov	w5, #0x3e2fffff            	// #1043333119
    34f8:	fmov	x3, d1
    34fc:	ubfx	x1, x3, #32, #31
    3500:	lsr	x4, x3, #32
    3504:	cmp	w1, w5
    3508:	b.gt	36b4 <pts_ieee754_tan+0x254>
    350c:	fcvtzs	w5, d1
    3510:	cbnz	w5, 36e8 <pts_ieee754_tan+0x288>
    3514:	mvn	w0, w0
    3518:	orr	w1, w1, w3
    351c:	and	w0, w0, #0x2
    3520:	orr	w0, w0, w1
    3524:	cbz	w0, 3828 <pts_ieee754_tan+0x3c8>
    3528:	fmov	d0, d1
    352c:	cmp	w2, #0x1
    3530:	b.eq	34b0 <pts_ieee754_tan+0x50>  // b.none
    3534:	fadd	d3, d1, d2
    3538:	fmov	d4, #-1.000000000000000000e+00
    353c:	movi	v5.2d, #0xffffffff00000000
    3540:	fmov	d1, #1.000000000000000000e+00
    3544:	fdiv	d4, d4, d3
    3548:	and	v3.8b, v3.8b, v5.8b
    354c:	fsub	d0, d3, d0
    3550:	fsub	d0, d2, d0
    3554:	and	v2.8b, v4.8b, v5.8b
    3558:	fmadd	d1, d3, d2, d1
    355c:	fmadd	d1, d0, d2, d1
    3560:	fmadd	d0, d4, d1, d2
    3564:	b	34b0 <pts_ieee754_tan+0x50>
    3568:	mov	w2, #0x3e2fffff            	// #1043333119
    356c:	cmp	w0, w2
    3570:	b.le	36a8 <pts_ieee754_tan+0x248>
    3574:	mov	w2, #0x9427                	// #37927
    3578:	movk	w2, #0x3fe5, lsl #16
    357c:	cmp	w0, w2
    3580:	b.le	35a8 <pts_ieee754_tan+0x148>
    3584:	fneg	d3, d0
    3588:	cmp	w1, #0x0
    358c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3590:	ldr	d0, [x2]
    3594:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3598:	fcsel	d1, d3, d1, lt	// lt = tstop
    359c:	ldr	d2, [x2]
    35a0:	fsub	d0, d0, d1
    35a4:	fadd	d1, d0, d2
    35a8:	fmul	d4, d1, d1
    35ac:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35b0:	movi	d3, #0x0
    35b4:	ldr	d24, [x2]
    35b8:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35bc:	fmul	d0, d4, d4
    35c0:	ldr	d21, [x2]
    35c4:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35c8:	fmul	d22, d1, d4
    35cc:	ldr	d23, [x2]
    35d0:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35d4:	fmadd	d21, d0, d24, d21
    35d8:	ldr	d20, [x2]
    35dc:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35e0:	fmadd	d20, d0, d23, d20
    35e4:	ldr	d19, [x2]
    35e8:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35ec:	ldr	d18, [x2]
    35f0:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35f4:	ldr	d17, [x2]
    35f8:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    35fc:	fmadd	d19, d0, d21, d19
    3600:	ldr	d16, [x2]
    3604:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3608:	fmadd	d18, d0, d20, d18
    360c:	ldr	d7, [x2]
    3610:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3614:	ldr	d6, [x2]
    3618:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    361c:	ldr	d5, [x2]
    3620:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3624:	fmadd	d17, d0, d19, d17
    3628:	ldr	d2, [x2]
    362c:	adrp	x2, 0 <__kernel_rem_pio2.constprop.0>
    3630:	fmadd	d16, d0, d18, d16
    3634:	ldr	d23, [x2]
    3638:	mov	w2, #0x9427                	// #37927
    363c:	movk	w2, #0x3fe5, lsl #16
    3640:	fmadd	d7, d0, d17, d7
    3644:	fmadd	d6, d0, d16, d6
    3648:	fmadd	d5, d0, d7, d5
    364c:	fmadd	d0, d0, d6, d2
    3650:	fmadd	d0, d4, d5, d0
    3654:	fmadd	d0, d22, d0, d3
    3658:	fmadd	d3, d4, d0, d3
    365c:	fmadd	d3, d22, d23, d3
    3660:	fadd	d0, d1, d3
    3664:	cmp	w0, w2
    3668:	b.le	34b0 <pts_ieee754_tan+0x50>
    366c:	fmov	d4, #1.000000000000000000e+00
    3670:	fmul	d2, d0, d0
    3674:	fmov	d6, #2.000000000000000000e+00
    3678:	asr	w1, w1, #30
    367c:	fadd	d0, d0, d4
    3680:	and	w1, w1, #0x2
    3684:	mov	w0, #0x1                   	// #1
    3688:	sub	w0, w0, w1
    368c:	scvtf	d5, w0
    3690:	fdiv	d2, d2, d0
    3694:	fsub	d2, d2, d3
    3698:	fsub	d2, d1, d2
    369c:	fmsub	d4, d2, d6, d4
    36a0:	fmul	d0, d5, d4
    36a4:	b	34b0 <pts_ieee754_tan+0x50>
    36a8:	fcvtzs	w2, d0
    36ac:	cbz	w2, 34b0 <pts_ieee754_tan+0x50>
    36b0:	b	35a8 <pts_ieee754_tan+0x148>
    36b4:	mov	w0, #0x9427                	// #37927
    36b8:	movk	w0, #0x3fe5, lsl #16
    36bc:	cmp	w1, w0
    36c0:	b.le	36e8 <pts_ieee754_tan+0x288>
    36c4:	tbnz	w4, #31, 381c <pts_ieee754_tan+0x3bc>
    36c8:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    36cc:	ldr	d0, [x0]
    36d0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    36d4:	ldr	d3, [x0]
    36d8:	fsub	d0, d0, d1
    36dc:	fsub	d1, d3, d2
    36e0:	movi	d2, #0x0
    36e4:	fadd	d1, d1, d0
    36e8:	fmul	d4, d1, d1
    36ec:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    36f0:	ldr	d25, [x0]
    36f4:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    36f8:	fmul	d0, d4, d4
    36fc:	ldr	d21, [x0]
    3700:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3704:	fmul	d22, d1, d4
    3708:	ldr	d24, [x0]
    370c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3710:	fmadd	d21, d0, d25, d21
    3714:	ldr	d20, [x0]
    3718:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    371c:	fmadd	d20, d0, d24, d20
    3720:	ldr	d19, [x0]
    3724:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3728:	ldr	d18, [x0]
    372c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3730:	ldr	d17, [x0]
    3734:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3738:	fmadd	d19, d0, d21, d19
    373c:	ldr	d16, [x0]
    3740:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3744:	fmadd	d18, d0, d20, d18
    3748:	ldr	d7, [x0]
    374c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3750:	ldr	d6, [x0]
    3754:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3758:	ldr	d5, [x0]
    375c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3760:	fmadd	d17, d0, d19, d17
    3764:	ldr	d3, [x0]
    3768:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    376c:	fmadd	d16, d0, d18, d16
    3770:	ldr	d23, [x0]
    3774:	mov	w0, #0x9427                	// #37927
    3778:	movk	w0, #0x3fe5, lsl #16
    377c:	fmadd	d7, d0, d17, d7
    3780:	fmadd	d6, d0, d16, d6
    3784:	fmadd	d5, d0, d7, d5
    3788:	fmadd	d0, d0, d6, d3
    378c:	fmadd	d0, d4, d5, d0
    3790:	fmadd	d0, d22, d0, d2
    3794:	fmadd	d2, d4, d0, d2
    3798:	fmadd	d2, d22, d23, d2
    379c:	fadd	d0, d1, d2
    37a0:	cmp	w1, w0
    37a4:	b.gt	37e0 <pts_ieee754_tan+0x380>
    37a8:	cmp	w2, #0x1
    37ac:	b.eq	34b0 <pts_ieee754_tan+0x50>  // b.none
    37b0:	movi	v6.2d, #0xffffffff00000000
    37b4:	fmov	d5, #-1.000000000000000000e+00
    37b8:	fmov	d3, #1.000000000000000000e+00
    37bc:	and	v4.8b, v0.8b, v6.8b
    37c0:	fdiv	d0, d5, d0
    37c4:	fsub	d1, d4, d1
    37c8:	fsub	d2, d2, d1
    37cc:	and	v1.8b, v0.8b, v6.8b
    37d0:	fmadd	d3, d4, d1, d3
    37d4:	fmadd	d3, d2, d1, d3
    37d8:	fmadd	d0, d0, d3, d1
    37dc:	b	34b0 <pts_ieee754_tan+0x50>
    37e0:	scvtf	d4, w2
    37e4:	fmul	d3, d0, d0
    37e8:	fmov	d6, #2.000000000000000000e+00
    37ec:	asr	w4, w4, #30
    37f0:	and	w4, w4, #0x2
    37f4:	mov	w0, #0x1                   	// #1
    37f8:	sub	w0, w0, w4
    37fc:	fadd	d0, d0, d4
    3800:	scvtf	d5, w0
    3804:	fdiv	d0, d3, d0
    3808:	fsub	d0, d0, d2
    380c:	fsub	d0, d1, d0
    3810:	fmsub	d4, d0, d6, d4
    3814:	fmul	d0, d5, d4
    3818:	b	34b0 <pts_ieee754_tan+0x50>
    381c:	fneg	d1, d1
    3820:	fneg	d2, d2
    3824:	b	36c8 <pts_ieee754_tan+0x268>
    3828:	fabs	d1, d1
    382c:	fmov	d0, #1.000000000000000000e+00
    3830:	fdiv	d0, d0, d1
    3834:	b	34b0 <pts_ieee754_tan+0x50>
    3838:	bl	0 <__stack_chk_fail>
    383c:	nop

0000000000003840 <pts_ieee754_cosh>:
    3840:	fmov	x1, d0
    3844:	stp	x29, x30, [sp, #-16]!
    3848:	mov	w0, #0x2e42                	// #11842
    384c:	mov	x29, sp
    3850:	fmov	d1, d0
    3854:	movk	w0, #0x3fd6, lsl #16
    3858:	ubfx	x4, x1, #32, #31
    385c:	fabs	d0, d0
    3860:	cmp	w4, w0
    3864:	b.le	38bc <pts_ieee754_cosh+0x7c>
    3868:	mov	w0, #0x4035ffff            	// #1077280767
    386c:	cmp	w4, w0
    3870:	b.le	3904 <pts_ieee754_cosh+0xc4>
    3874:	mov	w0, #0x2e41                	// #11841
    3878:	movk	w0, #0x4086, lsl #16
    387c:	cmp	w4, w0
    3880:	b.le	38f0 <pts_ieee754_cosh+0xb0>
    3884:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3888:	ldr	d2, [x0]
    388c:	fcmpe	d0, d2
    3890:	b.ls	3928 <pts_ieee754_cosh+0xe8>  // b.plast
    3894:	mov	w0, #0x7fefffff            	// #2146435071
    3898:	cmp	w4, w0
    389c:	b.gt	391c <pts_ieee754_cosh+0xdc>
    38a0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    38a4:	add	x0, x0, #0x0
    38a8:	ldr	d0, [x0, #48]
    38ac:	ldr	d1, [x0, #48]
    38b0:	fmul	d0, d0, d1
    38b4:	ldp	x29, x30, [sp], #16
    38b8:	ret
    38bc:	bl	2970 <pts_ieee754_expm1>
    38c0:	fmov	d1, d0
    38c4:	fmov	d3, #1.000000000000000000e+00
    38c8:	mov	w0, #0x3c7fffff            	// #1015021567
    38cc:	fadd	d0, d0, d3
    38d0:	cmp	w4, w0
    38d4:	b.le	38b4 <pts_ieee754_cosh+0x74>
    38d8:	fmul	d2, d1, d1
    38dc:	fadd	d1, d0, d0
    38e0:	ldp	x29, x30, [sp], #16
    38e4:	fdiv	d1, d2, d1
    38e8:	fadd	d0, d1, d3
    38ec:	ret
    38f0:	bl	1c20 <pts_ieee754_exp>
    38f4:	fmov	d1, #5.000000000000000000e-01
    38f8:	ldp	x29, x30, [sp], #16
    38fc:	fmul	d0, d0, d1
    3900:	ret
    3904:	bl	1c20 <pts_ieee754_exp>
    3908:	fmov	d2, #5.000000000000000000e-01
    390c:	ldp	x29, x30, [sp], #16
    3910:	fdiv	d1, d2, d0
    3914:	fmadd	d0, d0, d2, d1
    3918:	ret
    391c:	fmul	d0, d1, d1
    3920:	ldp	x29, x30, [sp], #16
    3924:	ret
    3928:	fmov	d18, #5.000000000000000000e-01
    392c:	fmul	d0, d0, d18
    3930:	bl	1c20 <pts_ieee754_exp>
    3934:	fmul	d1, d0, d18
    3938:	fmul	d0, d1, d0
    393c:	b	38b4 <pts_ieee754_cosh+0x74>

0000000000003940 <pts_ieee754_sinh>:
    3940:	fcmpe	d0, #0.0
    3944:	fabs	d21, d0
    3948:	fmov	d1, #-5.000000000000000000e-01
    394c:	fmov	d2, #5.000000000000000000e-01
    3950:	fmov	d3, #2.200000000000000000e+01
    3954:	stp	x29, x30, [sp, #-16]!
    3958:	fcsel	d22, d1, d2, mi	// mi = first
    395c:	fcmpe	d21, d3
    3960:	mov	x29, sp
    3964:	b.mi	39a0 <pts_ieee754_sinh+0x60>  // b.first
    3968:	mov	x0, #0x2e4200000000        	// #50861002719232
    396c:	movk	x0, #0x4086, lsl #48
    3970:	fmov	d1, x0
    3974:	fcmpe	d21, d1
    3978:	b.mi	39dc <pts_ieee754_sinh+0x9c>  // b.first
    397c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3980:	ldr	d1, [x0]
    3984:	fcmpe	d21, d1
    3988:	b.ls	3a10 <pts_ieee754_sinh+0xd0>  // b.plast
    398c:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3990:	ldr	d1, [x0]
    3994:	fmul	d0, d0, d1
    3998:	ldp	x29, x30, [sp], #16
    399c:	ret
    39a0:	mov	x0, #0x3e30000000000000    	// #4481081629233643520
    39a4:	fmov	d1, x0
    39a8:	fcmpe	d21, d1
    39ac:	b.mi	3998 <pts_ieee754_sinh+0x58>  // b.first
    39b0:	fmov	d0, d21
    39b4:	bl	2970 <pts_ieee754_expm1>
    39b8:	fmov	d1, #1.000000000000000000e+00
    39bc:	fcmpe	d21, d1
    39c0:	b.mi	39f0 <pts_ieee754_sinh+0xb0>  // b.first
    39c4:	fadd	d1, d0, d1
    39c8:	ldp	x29, x30, [sp], #16
    39cc:	fdiv	d1, d0, d1
    39d0:	fadd	d0, d1, d0
    39d4:	fmul	d0, d0, d22
    39d8:	ret
    39dc:	fmov	d0, d21
    39e0:	bl	1c20 <pts_ieee754_exp>
    39e4:	fmul	d0, d0, d22
    39e8:	ldp	x29, x30, [sp], #16
    39ec:	ret
    39f0:	fmul	d2, d0, d0
    39f4:	fadd	d1, d0, d1
    39f8:	fmov	d3, #2.000000000000000000e+00
    39fc:	ldp	x29, x30, [sp], #16
    3a00:	fdiv	d1, d2, d1
    3a04:	fnmsub	d0, d0, d3, d1
    3a08:	fmul	d0, d0, d22
    3a0c:	ret
    3a10:	fmul	d0, d21, d2
    3a14:	bl	1c20 <pts_ieee754_exp>
    3a18:	fmul	d1, d22, d0
    3a1c:	fmul	d0, d1, d0
    3a20:	b	3998 <pts_ieee754_sinh+0x58>

0000000000003a24 <pts_ieee754_tanh>:
    3a24:	fmov	x0, d0
    3a28:	fmov	d1, d0
    3a2c:	mov	w1, #0x7fefffff            	// #2146435071
    3a30:	lsr	x4, x0, #32
    3a34:	and	w0, w4, #0x7fffffff
    3a38:	cmp	w0, w1
    3a3c:	b.le	3a5c <pts_ieee754_tanh+0x38>
    3a40:	fmov	d0, #1.000000000000000000e+00
    3a44:	fdiv	d1, d0, d1
    3a48:	tbnz	w4, #31, 3a54 <pts_ieee754_tanh+0x30>
    3a4c:	fadd	d0, d1, d0
    3a50:	ret
    3a54:	fsub	d0, d1, d0
    3a58:	ret
    3a5c:	mov	w1, #0x4035ffff            	// #1077280767
    3a60:	cmp	w0, w1
    3a64:	b.gt	3abc <pts_ieee754_tanh+0x98>
    3a68:	stp	x29, x30, [sp, #-16]!
    3a6c:	mov	w1, #0x3e2fffff            	// #1043333119
    3a70:	mov	x29, sp
    3a74:	cmp	w0, w1
    3a78:	b.le	3ae0 <pts_ieee754_tanh+0xbc>
    3a7c:	fabs	d0, d0
    3a80:	mov	w1, #0x3fefffff            	// #1072693247
    3a84:	cmp	w0, w1
    3a88:	b.le	3afc <pts_ieee754_tanh+0xd8>
    3a8c:	fadd	d0, d0, d0
    3a90:	bl	2970 <pts_ieee754_expm1>
    3a94:	fmov	d2, #2.000000000000000000e+00
    3a98:	fmov	d1, #1.000000000000000000e+00
    3a9c:	fadd	d0, d0, d2
    3aa0:	fdiv	d2, d2, d0
    3aa4:	fsub	d0, d1, d2
    3aa8:	fneg	d1, d0
    3aac:	cmp	w4, #0x0
    3ab0:	fcsel	d0, d1, d0, lt	// lt = tstop
    3ab4:	ldp	x29, x30, [sp], #16
    3ab8:	ret
    3abc:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3ac0:	add	x0, x0, #0x0
    3ac4:	fmov	d0, #1.000000000000000000e+00
    3ac8:	cmp	w4, #0x0
    3acc:	ldr	d1, [x0, #480]
    3ad0:	fsub	d0, d0, d1
    3ad4:	fneg	d1, d0
    3ad8:	fcsel	d0, d1, d0, lt	// lt = tstop
    3adc:	ret
    3ae0:	adrp	x0, 0 <__kernel_rem_pio2.constprop.0>
    3ae4:	fmov	d3, #1.000000000000000000e+00
    3ae8:	ldr	d2, [x0]
    3aec:	fadd	d2, d0, d2
    3af0:	fcmpe	d2, d3
    3af4:	b.gt	3ab4 <pts_ieee754_tanh+0x90>
    3af8:	fabs	d0, d0
    3afc:	fmov	d1, #-2.000000000000000000e+00
    3b00:	fmul	d0, d0, d1
    3b04:	bl	2970 <pts_ieee754_expm1>
    3b08:	fneg	d1, d0
    3b0c:	fmov	d2, #2.000000000000000000e+00
    3b10:	fadd	d0, d0, d2
    3b14:	fdiv	d0, d1, d0
    3b18:	b	3aa8 <pts_ieee754_tanh+0x84>
