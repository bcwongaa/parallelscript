
bin/proto_a64.o:     file format elf64-littleaarch64


Disassembly of section .text:

0000000000000000 <pts_ieee754_acos>:
       0:	fmov	x8, d0
       4:	lsr	x10, x8, #32
       8:	ubfx	x9, x8, #32, #31
       c:	ubfx	w11, w10, #20, #11
      10:	cmp	w11, #0x3ff
      14:	b.cc	4c <pts_ieee754_acos+0x4c>  // b.lo, b.ul, b.last
      18:	movi	d0, #0x0
      1c:	adrp	x11, 0 <pts_ieee754_acos>
      20:	cmp	w10, #0x0
      24:	ldr	d1, [x11]
      28:	mov	w10, #0xc0100000            	// #-1072693248
      2c:	add	w9, w9, w10
      30:	orr	w8, w9, w8
      34:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
      38:	fcsel	d0, d0, d1, gt
      3c:	fmov	d1, x9
      40:	cmp	w8, #0x0
      44:	fcsel	d0, d0, d1, eq	// eq = none
      48:	ret
      4c:	lsr	w10, w9, #21
      50:	cmp	w10, #0x1fe
      54:	b.hi	74 <pts_ieee754_acos+0x74>  // b.pmore
      58:	mov	w8, #0x1                   	// #1
      5c:	movk	w8, #0x3c60, lsl #16
      60:	cmp	w9, w8
      64:	adrp	x8, 0 <pts_ieee754_acos>
      68:	b.cs	134 <pts_ieee754_acos+0x134>  // b.hs, b.nlast
      6c:	ldr	d0, [x8]
      70:	ret
      74:	fmov	d1, #1.000000000000000000e+00
      78:	tbnz	x8, #63, 1d8 <pts_ieee754_acos+0x1d8>
      7c:	fsub	d0, d1, d0
      80:	fmov	d2, #5.000000000000000000e-01
      84:	adrp	x8, 0 <pts_ieee754_acos>
      88:	adrp	x9, 0 <pts_ieee754_acos>
      8c:	ldr	d3, [x8]
      90:	ldr	d4, [x9]
      94:	adrp	x9, 0 <pts_ieee754_acos>
      98:	fmul	d0, d0, d2
      9c:	fsqrt	d2, d0
      a0:	fmadd	d3, d0, d4, d3
      a4:	fmov	x10, d2
      a8:	and	x8, x10, #0xffffffff00000000
      ac:	adrp	x10, 0 <pts_ieee754_acos>
      b0:	fmov	d5, x8
      b4:	adrp	x8, 0 <pts_ieee754_acos>
      b8:	ldr	d16, [x10]
      bc:	ldr	d7, [x8]
      c0:	adrp	x8, 0 <pts_ieee754_acos>
      c4:	fmsub	d4, d5, d5, d0
      c8:	fadd	d6, d2, d5
      cc:	fmadd	d3, d0, d3, d7
      d0:	ldr	d7, [x9]
      d4:	adrp	x9, 0 <pts_ieee754_acos>
      d8:	fdiv	d4, d4, d6
      dc:	ldr	d6, [x8]
      e0:	adrp	x8, 0 <pts_ieee754_acos>
      e4:	fmadd	d3, d0, d3, d6
      e8:	fmadd	d6, d0, d16, d7
      ec:	ldr	d7, [x8]
      f0:	ldr	d16, [x9]
      f4:	adrp	x8, 0 <pts_ieee754_acos>
      f8:	fmadd	d3, d0, d3, d7
      fc:	ldr	d7, [x8]
     100:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     104:	fmadd	d6, d0, d6, d16
     108:	movk	x8, #0x3fc5, lsl #48
     10c:	fmov	d16, x8
     110:	fmadd	d3, d0, d3, d16
     114:	fmadd	d6, d0, d6, d7
     118:	fmul	d3, d0, d3
     11c:	fmadd	d0, d0, d6, d1
     120:	fdiv	d0, d3, d0
     124:	fmadd	d0, d0, d2, d4
     128:	fadd	d0, d0, d5
     12c:	fadd	d0, d0, d0
     130:	ret
     134:	fmul	d1, d0, d0
     138:	adrp	x9, 0 <pts_ieee754_acos>
     13c:	adrp	x10, 0 <pts_ieee754_acos>
     140:	ldr	d2, [x9]
     144:	ldr	d3, [x10]
     148:	adrp	x9, 0 <pts_ieee754_acos>
     14c:	adrp	x10, 0 <pts_ieee754_acos>
     150:	adrp	x11, 0 <pts_ieee754_acos>
     154:	ldr	d4, [x10]
     158:	ldr	d5, [x11]
     15c:	adrp	x10, 0 <pts_ieee754_acos>
     160:	fmadd	d2, d1, d3, d2
     164:	ldr	d3, [x9]
     168:	adrp	x9, 0 <pts_ieee754_acos>
     16c:	fmadd	d2, d1, d2, d3
     170:	ldr	d3, [x9]
     174:	adrp	x9, 0 <pts_ieee754_acos>
     178:	fmadd	d2, d1, d2, d3
     17c:	fmadd	d3, d1, d5, d4
     180:	ldr	d4, [x9]
     184:	ldr	d5, [x10]
     188:	adrp	x9, 0 <pts_ieee754_acos>
     18c:	fmadd	d2, d1, d2, d4
     190:	ldr	d4, [x9]
     194:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     198:	fmadd	d3, d1, d3, d5
     19c:	movk	x9, #0x3fc5, lsl #48
     1a0:	fmov	d5, x9
     1a4:	adrp	x9, 0 <pts_ieee754_acos>
     1a8:	fmadd	d2, d1, d2, d5
     1ac:	fmadd	d3, d1, d3, d4
     1b0:	fmov	d4, #1.000000000000000000e+00
     1b4:	fmul	d2, d1, d2
     1b8:	fmadd	d1, d1, d3, d4
     1bc:	fdiv	d1, d2, d1
     1c0:	ldr	d2, [x9]
     1c4:	fmsub	d1, d0, d1, d2
     1c8:	fsub	d0, d1, d0
     1cc:	ldr	d1, [x8]
     1d0:	fadd	d0, d0, d1
     1d4:	ret
     1d8:	fadd	d0, d0, d1
     1dc:	fmov	d2, #5.000000000000000000e-01
     1e0:	adrp	x8, 0 <pts_ieee754_acos>
     1e4:	adrp	x9, 0 <pts_ieee754_acos>
     1e8:	adrp	x10, 0 <pts_ieee754_acos>
     1ec:	ldr	d3, [x9]
     1f0:	adrp	x9, 0 <pts_ieee754_acos>
     1f4:	ldr	d5, [x10]
     1f8:	ldr	d4, [x9]
     1fc:	adrp	x9, 0 <pts_ieee754_acos>
     200:	fmul	d0, d0, d2
     204:	ldr	d2, [x8]
     208:	adrp	x8, 0 <pts_ieee754_acos>
     20c:	fmadd	d2, d0, d3, d2
     210:	ldr	d3, [x8]
     214:	adrp	x8, 0 <pts_ieee754_acos>
     218:	fmadd	d4, d0, d5, d4
     21c:	ldr	d5, [x9]
     220:	fmadd	d2, d0, d2, d3
     224:	ldr	d3, [x8]
     228:	adrp	x8, 0 <pts_ieee754_acos>
     22c:	fmadd	d4, d0, d4, d5
     230:	fmadd	d2, d0, d2, d3
     234:	ldr	d3, [x8]
     238:	adrp	x8, 0 <pts_ieee754_acos>
     23c:	fmadd	d2, d0, d2, d3
     240:	ldr	d3, [x8]
     244:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     248:	movk	x8, #0x3fc5, lsl #48
     24c:	fmov	d5, x8
     250:	fmadd	d3, d0, d4, d3
     254:	adrp	x8, 0 <pts_ieee754_acos>
     258:	fmadd	d2, d0, d2, d5
     25c:	fmadd	d1, d0, d3, d1
     260:	fmul	d2, d0, d2
     264:	fsqrt	d0, d0
     268:	fdiv	d1, d2, d1
     26c:	ldr	d2, [x8]
     270:	adrp	x8, 0 <pts_ieee754_acos>
     274:	fmadd	d1, d1, d0, d2
     278:	ldr	d2, [x8]
     27c:	fadd	d0, d0, d1
     280:	fmov	d1, #-2.000000000000000000e+00
     284:	fmadd	d0, d0, d1, d2
     288:	ret
     28c:	nop
     290:	nop
     294:	nop
     298:	nop
     29c:	nop

00000000000002a0 <pts_ieee754_acosh>:
     2a0:	fmov	x9, d0
     2a4:	mov	w10, #0x3ff00000            	// #1072693248
     2a8:	lsr	x8, x9, #32
     2ac:	cmp	w8, w10
     2b0:	b.ge	2c0 <pts_ieee754_acosh+0x20>  // b.tcont
     2b4:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     2b8:	fmov	d0, x8
     2bc:	ret
     2c0:	lsr	w10, w8, #20
     2c4:	cmp	w10, #0x41b
     2c8:	b.cc	2dc <pts_ieee754_acosh+0x3c>  // b.lo, b.ul, b.last
     2cc:	cmp	w10, #0x7ff
     2d0:	b.cc	31c <pts_ieee754_acosh+0x7c>  // b.lo, b.ul, b.last
     2d4:	fadd	d0, d0, d0
     2d8:	ret
     2dc:	mov	w10, #0xc0100000            	// #-1072693248
     2e0:	add	w10, w8, w10
     2e4:	orr	w9, w10, w9
     2e8:	cbz	w9, 33c <pts_ieee754_acosh+0x9c>
     2ec:	mov	w9, #0x1                   	// #1
     2f0:	fmov	d1, #-1.000000000000000000e+00
     2f4:	movk	w9, #0x4000, lsl #16
     2f8:	cmp	w8, w9
     2fc:	b.cc	344 <pts_ieee754_acosh+0xa4>  // b.lo, b.ul, b.last
     300:	fmadd	d2, d0, d0, d1
     304:	fsqrt	d2, d2
     308:	fadd	d2, d2, d0
     30c:	fadd	d0, d0, d0
     310:	fdiv	d1, d1, d2
     314:	fadd	d0, d0, d1
     318:	b	360 <pts_ieee754_log>
     31c:	stp	x29, x30, [sp, #-16]!
     320:	mov	x29, sp
     324:	bl	360 <pts_ieee754_log>
     328:	adrp	x8, 0 <pts_ieee754_acos>
     32c:	ldr	d1, [x8]
     330:	fadd	d0, d0, d1
     334:	ldp	x29, x30, [sp], #16
     338:	ret
     33c:	movi	d0, #0x0
     340:	ret
     344:	fadd	d0, d0, d1
     348:	fmov	d2, #2.000000000000000000e+00
     34c:	fmul	d1, d0, d0
     350:	fmadd	d1, d0, d2, d1
     354:	fsqrt	d1, d1
     358:	fadd	d0, d0, d1
     35c:	b	580 <pts_ieee754_log1p>

0000000000000360 <pts_ieee754_log>:
     360:	fmov	x9, d0
     364:	lsr	x8, x9, #32
     368:	cmp	w8, #0x100, lsl #12
     36c:	b.ge	39c <pts_ieee754_log+0x3c>  // b.tcont
     370:	and	w8, w8, #0x7fffffff
     374:	orr	w8, w8, w9
     378:	cbz	w8, 42c <pts_ieee754_log+0xcc>
     37c:	tbnz	x9, #63, 4f0 <pts_ieee754_log+0x190>
     380:	mov	x8, #0x4350000000000000    	// #4850376798678024192
     384:	mov	w10, #0xffffffca            	// #-54
     388:	fmov	d1, x8
     38c:	fmul	d0, d0, d1
     390:	fmov	x8, d0
     394:	lsr	x8, x8, #32
     398:	b	3a0 <pts_ieee754_log+0x40>
     39c:	mov	w10, wzr
     3a0:	mov	w9, #0x7ff00000            	// #2146435072
     3a4:	cmp	w8, w9
     3a8:	b.lt	3b4 <pts_ieee754_log+0x54>  // b.tstop
     3ac:	fadd	d0, d0, d0
     3b0:	ret
     3b4:	and	w9, w8, #0xfffff
     3b8:	fmov	x13, d0
     3bc:	fmov	d0, #-1.000000000000000000e+00
     3c0:	add	w11, w9, #0x95, lsl #12
     3c4:	add	w10, w10, w8, asr #20
     3c8:	add	w11, w11, #0xf64
     3cc:	and	w12, w11, #0x100000
     3d0:	and	x13, x13, #0xffffffff
     3d4:	add	w10, w10, w11, lsr #20
     3d8:	bfxil	w12, w8, #0, #20
     3dc:	add	w8, w8, #0x2
     3e0:	and	w8, w8, #0xfffff
     3e4:	eor	w12, w12, #0x3ff00000
     3e8:	cmp	w8, #0x2
     3ec:	sub	w8, w10, #0x3ff
     3f0:	orr	x12, x13, x12, lsl #32
     3f4:	fmov	d1, x12
     3f8:	fadd	d0, d1, d0
     3fc:	b.hi	438 <pts_ieee754_log+0xd8>  // b.pmore
     400:	fcmp	d0, #0.0
     404:	b.ne	4fc <pts_ieee754_log+0x19c>  // b.any
     408:	cbz	w8, 550 <pts_ieee754_log+0x1f0>
     40c:	scvtf	d0, w8
     410:	adrp	x8, 0 <pts_ieee754_acos>
     414:	ldr	d1, [x8]
     418:	adrp	x8, 0 <pts_ieee754_acos>
     41c:	ldr	d2, [x8]
     420:	fmul	d1, d0, d1
     424:	fmadd	d0, d0, d2, d1
     428:	ret
     42c:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
     430:	fmov	d0, x8
     434:	ret
     438:	fmov	d1, #2.000000000000000000e+00
     43c:	adrp	x10, 0 <pts_ieee754_acos>
     440:	adrp	x11, 0 <pts_ieee754_acos>
     444:	ldr	d4, [x10]
     448:	ldr	d5, [x11]
     44c:	adrp	x10, 0 <pts_ieee754_acos>
     450:	adrp	x11, 0 <pts_ieee754_acos>
     454:	adrp	x12, 0 <pts_ieee754_acos>
     458:	fadd	d1, d0, d1
     45c:	ldr	d6, [x11]
     460:	ldr	d7, [x12]
     464:	mov	w11, #0xb851                	// #47185
     468:	movk	w11, #0x6, lsl #16
     46c:	fdiv	d1, d0, d1
     470:	fmul	d2, d1, d1
     474:	fmul	d3, d2, d2
     478:	fmadd	d4, d3, d5, d4
     47c:	ldr	d5, [x10]
     480:	adrp	x10, 0 <pts_ieee754_acos>
     484:	fmadd	d4, d3, d4, d5
     488:	ldr	d5, [x10]
     48c:	adrp	x10, 0 <pts_ieee754_acos>
     490:	fmadd	d5, d3, d6, d5
     494:	ldr	d6, [x10]
     498:	sub	w10, w9, #0x61, lsl #12
     49c:	sub	w10, w10, #0x47a
     4a0:	sub	w9, w11, w9
     4a4:	fmadd	d4, d3, d4, d7
     4a8:	orr	w9, w10, w9
     4ac:	cmp	w9, #0x1
     4b0:	fmadd	d5, d3, d5, d6
     4b4:	fmul	d4, d2, d4
     4b8:	scvtf	d2, w8
     4bc:	fmadd	d3, d3, d5, d4
     4c0:	b.lt	524 <pts_ieee754_log+0x1c4>  // b.tstop
     4c4:	fmov	d4, #5.000000000000000000e-01
     4c8:	fmul	d4, d0, d4
     4cc:	fmul	d4, d0, d4
     4d0:	fadd	d3, d4, d3
     4d4:	fmul	d1, d1, d3
     4d8:	cbz	w8, 558 <pts_ieee754_log+0x1f8>
     4dc:	adrp	x8, 0 <pts_ieee754_acos>
     4e0:	ldr	d3, [x8]
     4e4:	fmadd	d1, d2, d3, d1
     4e8:	fsub	d1, d4, d1
     4ec:	b	53c <pts_ieee754_log+0x1dc>
     4f0:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     4f4:	fmov	d0, x8
     4f8:	ret
     4fc:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     500:	fmov	d1, #5.000000000000000000e-01
     504:	fmul	d3, d0, d0
     508:	movk	x9, #0xbfd5, lsl #48
     50c:	fmov	d2, x9
     510:	fmadd	d1, d0, d2, d1
     514:	fmul	d1, d3, d1
     518:	cbz	w8, 56c <pts_ieee754_log+0x20c>
     51c:	scvtf	d2, w8
     520:	b	530 <pts_ieee754_log+0x1d0>
     524:	cbz	w8, 564 <pts_ieee754_log+0x204>
     528:	fsub	d3, d0, d3
     52c:	fmul	d1, d1, d3
     530:	adrp	x8, 0 <pts_ieee754_acos>
     534:	ldr	d3, [x8]
     538:	fmadd	d1, d2, d3, d1
     53c:	fsub	d0, d1, d0
     540:	adrp	x8, 0 <pts_ieee754_acos>
     544:	ldr	d1, [x8]
     548:	fnmsub	d0, d2, d1, d0
     54c:	ret
     550:	movi	d0, #0x0
     554:	ret
     558:	fsub	d1, d1, d4
     55c:	fadd	d0, d0, d1
     560:	ret
     564:	fsub	d2, d0, d3
     568:	fmul	d1, d1, d2
     56c:	fsub	d0, d0, d1
     570:	ret
     574:	nop
     578:	nop
     57c:	nop

0000000000000580 <pts_ieee754_log1p>:
     580:	fmov	x8, d0
     584:	mov	w10, #0x8279                	// #33401
     588:	movk	w10, #0x3fda, lsl #16
     58c:	lsr	x9, x8, #32
     590:	cmp	w9, w10
     594:	b.gt	5c8 <pts_ieee754_log1p+0x48>
     598:	ubfx	x10, x8, #32, #31
     59c:	lsr	w8, w10, #20
     5a0:	cmp	w8, #0x3ff
     5a4:	b.cc	5dc <pts_ieee754_log1p+0x5c>  // b.lo, b.ul, b.last
     5a8:	fmov	d1, #-1.000000000000000000e+00
     5ac:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
     5b0:	mov	x9, #0xfff0000000000000    	// #-4503599627370496
     5b4:	fcmp	d0, d1
     5b8:	fmov	d0, x8
     5bc:	fmov	d1, x9
     5c0:	fcsel	d0, d1, d0, eq	// eq = none
     5c4:	ret
     5c8:	lsr	w8, w9, #20
     5cc:	cmp	w8, #0x7ff
     5d0:	b.cc	608 <pts_ieee754_log1p+0x88>  // b.lo, b.ul, b.last
     5d4:	fadd	d0, d0, d0
     5d8:	ret
     5dc:	lsr	w10, w10, #21
     5e0:	cmp	w10, #0x1f0
     5e4:	b.hi	61c <pts_ieee754_log1p+0x9c>  // b.pmore
     5e8:	mov	x9, #0x4350000000000000    	// #4850376798678024192
     5ec:	fmov	d1, x9
     5f0:	fadd	d1, d0, d1
     5f4:	fcmp	d1, #0.0
     5f8:	b.le	7b4 <pts_ieee754_log1p+0x234>
     5fc:	cmp	w8, #0x3c9
     600:	b.cs	7b4 <pts_ieee754_log1p+0x234>  // b.hs, b.nlast
     604:	ret
     608:	lsr	w10, w9, #22
     60c:	cmp	w10, #0x10c
     610:	b.ls	644 <pts_ieee754_log1p+0xc4>  // b.plast
     614:	movi	d1, #0x0
     618:	b	67c <pts_ieee754_log1p+0xfc>
     61c:	sub	w8, w9, #0x1
     620:	mov	w9, #0xbec3                	// #48835
     624:	movk	w9, #0xbfd2, lsl #16
     628:	cmp	w8, w9
     62c:	b.hi	644 <pts_ieee754_log1p+0xc4>  // b.pmore
     630:	fmov	d1, #5.000000000000000000e-01
     634:	mov	w8, wzr
     638:	fmul	d1, d0, d1
     63c:	fmul	d2, d1, d0
     640:	b	6dc <pts_ieee754_log1p+0x15c>
     644:	fmov	d1, #1.000000000000000000e+00
     648:	fmov	d3, #-1.000000000000000000e+00
     64c:	fadd	d2, d0, d1
     650:	fsub	d4, d0, d2
     654:	fadd	d3, d2, d3
     658:	fmov	x9, d2
     65c:	asr	x8, x9, #52
     660:	lsr	x9, x9, #32
     664:	fadd	d1, d4, d1
     668:	fsub	d0, d0, d3
     66c:	cmp	w8, #0x3ff
     670:	fcsel	d0, d1, d0, gt
     674:	fdiv	d1, d0, d2
     678:	fmov	d0, d2
     67c:	fmov	x10, d0
     680:	mov	w11, #0xa09d                	// #41117
     684:	and	w9, w9, #0xfffff
     688:	movk	w11, #0x6, lsl #16
     68c:	orr	w12, w9, #0x3fe00000
     690:	orr	w13, w9, #0x3ff00000
     694:	cmp	w9, w11
     698:	fmov	d0, #-1.000000000000000000e+00
     69c:	and	x10, x10, #0xffffffff
     6a0:	csel	w11, w12, w13, hi	// hi = pmore
     6a4:	orr	x10, x10, x11, lsl #32
     6a8:	sub	w11, w8, #0x3fe
     6ac:	sub	w8, w8, #0x3ff
     6b0:	csel	w8, w11, w8, hi	// hi = pmore
     6b4:	fmov	d2, x10
     6b8:	mov	w10, #0x100000              	// #1048576
     6bc:	sub	w10, w10, w9
     6c0:	lsr	w10, w10, #2
     6c4:	fadd	d0, d2, d0
     6c8:	fmov	d2, #5.000000000000000000e-01
     6cc:	csel	w9, w10, w9, hi	// hi = pmore
     6d0:	fmul	d2, d0, d2
     6d4:	fmul	d2, d0, d2
     6d8:	cbz	w9, 774 <pts_ieee754_log1p+0x1f4>
     6dc:	fmov	d3, #2.000000000000000000e+00
     6e0:	adrp	x9, 0 <pts_ieee754_acos>
     6e4:	adrp	x10, 0 <pts_ieee754_acos>
     6e8:	ldr	d5, [x9]
     6ec:	ldr	d6, [x10]
     6f0:	adrp	x9, 0 <pts_ieee754_acos>
     6f4:	fadd	d3, d0, d3
     6f8:	fdiv	d3, d0, d3
     6fc:	fmul	d4, d3, d3
     700:	fmadd	d5, d4, d6, d5
     704:	ldr	d6, [x9]
     708:	adrp	x9, 0 <pts_ieee754_acos>
     70c:	fmadd	d5, d4, d5, d6
     710:	ldr	d6, [x9]
     714:	adrp	x9, 0 <pts_ieee754_acos>
     718:	fmadd	d5, d4, d5, d6
     71c:	ldr	d6, [x9]
     720:	adrp	x9, 0 <pts_ieee754_acos>
     724:	fmadd	d5, d4, d5, d6
     728:	ldr	d6, [x9]
     72c:	adrp	x9, 0 <pts_ieee754_acos>
     730:	fmadd	d5, d4, d5, d6
     734:	ldr	d6, [x9]
     738:	fmadd	d5, d4, d5, d6
     73c:	cbz	w8, 7a0 <pts_ieee754_log1p+0x220>
     740:	scvtf	d6, w8
     744:	fmadd	d4, d4, d5, d2
     748:	adrp	x8, 0 <pts_ieee754_acos>
     74c:	ldr	d5, [x8]
     750:	adrp	x8, 0 <pts_ieee754_acos>
     754:	fmul	d3, d3, d4
     758:	fmadd	d1, d6, d5, d1
     75c:	fadd	d1, d1, d3
     760:	fsub	d1, d2, d1
     764:	fsub	d0, d1, d0
     768:	ldr	d1, [x8]
     76c:	fnmsub	d0, d6, d1, d0
     770:	ret
     774:	fcmp	d0, #0.0
     778:	b.ne	7c4 <pts_ieee754_log1p+0x244>  // b.any
     77c:	cbz	w8, 808 <pts_ieee754_log1p+0x288>
     780:	scvtf	d0, w8
     784:	adrp	x8, 0 <pts_ieee754_acos>
     788:	ldr	d2, [x8]
     78c:	adrp	x8, 0 <pts_ieee754_acos>
     790:	fmadd	d1, d0, d2, d1
     794:	ldr	d2, [x8]
     798:	fmadd	d0, d0, d2, d1
     79c:	ret
     7a0:	fmadd	d1, d4, d5, d2
     7a4:	fmul	d1, d3, d1
     7a8:	fsub	d1, d2, d1
     7ac:	fsub	d0, d0, d1
     7b0:	ret
     7b4:	fmul	d1, d0, d0
     7b8:	fmov	d2, #-5.000000000000000000e-01
     7bc:	fmadd	d0, d1, d2, d0
     7c0:	ret
     7c4:	mov	x9, #0x5555555555555555    	// #6148914691236517205
     7c8:	fmov	d3, #1.000000000000000000e+00
     7cc:	movk	x9, #0xbfe5, lsl #48
     7d0:	fmov	d4, x9
     7d4:	fmadd	d3, d0, d4, d3
     7d8:	fmul	d2, d3, d2
     7dc:	cbz	w8, 810 <pts_ieee754_log1p+0x290>
     7e0:	scvtf	d3, w8
     7e4:	adrp	x8, 0 <pts_ieee754_acos>
     7e8:	ldr	d4, [x8]
     7ec:	adrp	x8, 0 <pts_ieee754_acos>
     7f0:	fmadd	d1, d3, d4, d1
     7f4:	fsub	d1, d2, d1
     7f8:	fsub	d0, d1, d0
     7fc:	ldr	d1, [x8]
     800:	fnmsub	d0, d3, d1, d0
     804:	ret
     808:	movi	d0, #0x0
     80c:	ret
     810:	fsub	d0, d0, d2
     814:	ret
     818:	nop
     81c:	nop

0000000000000820 <pts_ieee754_asin>:
     820:	fmov	x10, d0
     824:	lsr	x8, x10, #32
     828:	ubfx	x9, x10, #32, #31
     82c:	ubfx	w11, w8, #20, #11
     830:	cmp	w11, #0x3ff
     834:	b.cc	870 <pts_ieee754_asin+0x50>  // b.lo, b.ul, b.last
     838:	adrp	x8, 0 <pts_ieee754_acos>
     83c:	ldr	d1, [x8]
     840:	adrp	x8, 0 <pts_ieee754_acos>
     844:	ldr	d2, [x8]
     848:	mov	w8, #0xc0100000            	// #-1072693248
     84c:	fmul	d1, d0, d1
     850:	add	w8, w9, w8
     854:	mov	x9, #0x7ff8000000000000    	// #9221120237041090560
     858:	orr	w8, w8, w10
     85c:	cmp	w8, #0x0
     860:	fmadd	d0, d0, d2, d1
     864:	fmov	d1, x9
     868:	fcsel	d0, d0, d1, eq	// eq = none
     86c:	ret
     870:	lsr	w10, w9, #21
     874:	cmp	w10, #0x1fe
     878:	b.hi	8a8 <pts_ieee754_asin+0x88>  // b.pmore
     87c:	lsr	w8, w9, #22
     880:	cmp	w8, #0xf8
     884:	b.hi	974 <pts_ieee754_asin+0x154>  // b.pmore
     888:	adrp	x8, 0 <pts_ieee754_acos>
     88c:	fmov	d3, #1.000000000000000000e+00
     890:	ldr	d1, [x8]
     894:	fadd	d2, d0, d1
     898:	movi	d1, #0x0
     89c:	fcmp	d2, d3
     8a0:	b.le	978 <pts_ieee754_asin+0x158>
     8a4:	ret
     8a8:	fabs	d0, d0
     8ac:	fmov	d3, #1.000000000000000000e+00
     8b0:	adrp	x10, 0 <pts_ieee754_acos>
     8b4:	fmov	d1, #5.000000000000000000e-01
     8b8:	adrp	x11, 0 <pts_ieee754_acos>
     8bc:	adrp	x12, 0 <pts_ieee754_acos>
     8c0:	ldr	d2, [x11]
     8c4:	adrp	x11, 0 <pts_ieee754_acos>
     8c8:	ldr	d6, [x12]
     8cc:	ldr	d5, [x11]
     8d0:	adrp	x11, 0 <pts_ieee754_acos>
     8d4:	fsub	d0, d3, d0
     8d8:	fmul	d0, d0, d1
     8dc:	ldr	d1, [x10]
     8e0:	adrp	x10, 0 <pts_ieee754_acos>
     8e4:	ldr	d4, [x10]
     8e8:	adrp	x10, 0 <pts_ieee754_acos>
     8ec:	fmadd	d2, d0, d2, d1
     8f0:	fsqrt	d1, d0
     8f4:	fmadd	d2, d0, d2, d4
     8f8:	ldr	d4, [x10]
     8fc:	adrp	x10, 0 <pts_ieee754_acos>
     900:	fmadd	d2, d0, d2, d4
     904:	fmadd	d4, d0, d6, d5
     908:	ldr	d5, [x10]
     90c:	ldr	d6, [x11]
     910:	adrp	x10, 0 <pts_ieee754_acos>
     914:	fmadd	d2, d0, d2, d5
     918:	ldr	d5, [x10]
     91c:	mov	x10, #0x5555555555555555    	// #6148914691236517205
     920:	fmadd	d4, d0, d4, d6
     924:	movk	x10, #0x3fc5, lsl #48
     928:	fmov	d6, x10
     92c:	mov	w10, #0x3333                	// #13107
     930:	movk	w10, #0x3fef, lsl #16
     934:	cmp	w9, w10
     938:	fmadd	d2, d0, d2, d6
     93c:	fmadd	d4, d0, d4, d5
     940:	fmul	d2, d0, d2
     944:	fmadd	d3, d0, d4, d3
     948:	b.cc	a04 <pts_ieee754_asin+0x1e4>  // b.lo, b.ul, b.last
     94c:	fdiv	d0, d2, d3
     950:	adrp	x9, 0 <pts_ieee754_acos>
     954:	ldr	d2, [x9]
     958:	adrp	x9, 0 <pts_ieee754_acos>
     95c:	fmadd	d0, d1, d0, d1
     960:	fmov	d1, #2.000000000000000000e+00
     964:	fmadd	d0, d0, d1, d2
     968:	ldr	d1, [x9]
     96c:	fsub	d0, d1, d0
     970:	b	a4c <pts_ieee754_asin+0x22c>
     974:	fmul	d1, d0, d0
     978:	adrp	x8, 0 <pts_ieee754_acos>
     97c:	adrp	x9, 0 <pts_ieee754_acos>
     980:	adrp	x10, 0 <pts_ieee754_acos>
     984:	ldr	d2, [x8]
     988:	ldr	d3, [x9]
     98c:	adrp	x8, 0 <pts_ieee754_acos>
     990:	adrp	x9, 0 <pts_ieee754_acos>
     994:	ldr	d5, [x10]
     998:	fmadd	d2, d1, d3, d2
     99c:	ldr	d3, [x8]
     9a0:	adrp	x8, 0 <pts_ieee754_acos>
     9a4:	ldr	d4, [x9]
     9a8:	adrp	x9, 0 <pts_ieee754_acos>
     9ac:	fmadd	d2, d1, d2, d3
     9b0:	ldr	d3, [x8]
     9b4:	adrp	x8, 0 <pts_ieee754_acos>
     9b8:	fmadd	d2, d1, d2, d3
     9bc:	fmadd	d3, d1, d5, d4
     9c0:	ldr	d4, [x8]
     9c4:	ldr	d5, [x9]
     9c8:	adrp	x8, 0 <pts_ieee754_acos>
     9cc:	fmadd	d2, d1, d2, d4
     9d0:	ldr	d4, [x8]
     9d4:	mov	x8, #0x5555555555555555    	// #6148914691236517205
     9d8:	fmadd	d3, d1, d3, d5
     9dc:	movk	x8, #0x3fc5, lsl #48
     9e0:	fmov	d5, x8
     9e4:	fmadd	d2, d1, d2, d5
     9e8:	fmadd	d3, d1, d3, d4
     9ec:	fmov	d4, #1.000000000000000000e+00
     9f0:	fmul	d2, d1, d2
     9f4:	fmadd	d1, d1, d3, d4
     9f8:	fdiv	d1, d2, d1
     9fc:	fmadd	d0, d0, d1, d0
     a00:	ret
     a04:	fmov	x9, d1
     a08:	fdiv	d2, d2, d3
     a0c:	fmov	d3, #-2.000000000000000000e+00
     a10:	and	x9, x9, #0xffffffff00000000
     a14:	fmov	d4, x9
     a18:	adrp	x9, 0 <pts_ieee754_acos>
     a1c:	fmsub	d0, d4, d4, d0
     a20:	fadd	d5, d1, d4
     a24:	fadd	d1, d1, d1
     a28:	fdiv	d0, d0, d5
     a2c:	ldr	d5, [x9]
     a30:	adrp	x9, 0 <pts_ieee754_acos>
     a34:	fmadd	d0, d0, d3, d5
     a38:	ldr	d5, [x9]
     a3c:	fnmsub	d0, d1, d2, d0
     a40:	fmadd	d1, d4, d3, d5
     a44:	fsub	d0, d1, d0
     a48:	fadd	d0, d0, d5
     a4c:	fneg	d1, d0
     a50:	cmp	w8, #0x0
     a54:	fcsel	d0, d0, d1, gt
     a58:	ret
     a5c:	nop

0000000000000a60 <pts_ieee754_asinh>:
     a60:	stp	x29, x30, [sp, #-32]!
     a64:	str	x19, [sp, #16]
     a68:	mov	x29, sp
     a6c:	fmov	x8, d0
     a70:	lsr	x19, x8, #32
     a74:	ubfx	w9, w19, #20, #11
     a78:	cmp	w9, #0x7ff
     a7c:	b.cc	a88 <pts_ieee754_asinh+0x28>  // b.lo, b.ul, b.last
     a80:	fadd	d0, d0, d0
     a84:	b	b3c <pts_ieee754_asinh+0xdc>
     a88:	adrp	x9, 0 <pts_ieee754_acos>
     a8c:	fmov	d2, #1.000000000000000000e+00
     a90:	ubfx	x8, x8, #32, #31
     a94:	ldr	d1, [x9]
     a98:	fadd	d1, d0, d1
     a9c:	fcmp	d1, d2
     aa0:	b.le	ab0 <pts_ieee754_asinh+0x50>
     aa4:	lsr	w9, w8, #20
     aa8:	cmp	w9, #0x3e3
     aac:	b.cc	b3c <pts_ieee754_asinh+0xdc>  // b.lo, b.ul, b.last
     ab0:	mov	w9, #0x1                   	// #1
     ab4:	movk	w9, #0x41b0, lsl #16
     ab8:	cmp	w8, w9
     abc:	b.cc	ad8 <pts_ieee754_asinh+0x78>  // b.lo, b.ul, b.last
     ac0:	fabs	d0, d0
     ac4:	bl	360 <pts_ieee754_log>
     ac8:	adrp	x8, 0 <pts_ieee754_acos>
     acc:	ldr	d1, [x8]
     ad0:	fadd	d0, d0, d1
     ad4:	b	b30 <pts_ieee754_asinh+0xd0>
     ad8:	mov	w9, #0x1                   	// #1
     adc:	movk	w9, #0x4000, lsl #16
     ae0:	cmp	w8, w9
     ae4:	b.cc	b10 <pts_ieee754_asinh+0xb0>  // b.lo, b.ul, b.last
     ae8:	fmov	d1, #1.000000000000000000e+00
     aec:	fmadd	d2, d0, d0, d1
     af0:	fabs	d0, d0
     af4:	fsqrt	d2, d2
     af8:	fadd	d2, d0, d2
     afc:	fadd	d0, d0, d0
     b00:	fdiv	d1, d1, d2
     b04:	fadd	d0, d0, d1
     b08:	bl	360 <pts_ieee754_log>
     b0c:	b	b30 <pts_ieee754_asinh+0xd0>
     b10:	fmul	d1, d0, d0
     b14:	fabs	d0, d0
     b18:	fadd	d3, d1, d2
     b1c:	fsqrt	d3, d3
     b20:	fadd	d2, d3, d2
     b24:	fdiv	d1, d1, d2
     b28:	fadd	d0, d0, d1
     b2c:	bl	580 <pts_ieee754_log1p>
     b30:	fneg	d1, d0
     b34:	cmp	w19, #0x0
     b38:	fcsel	d0, d0, d1, gt
     b3c:	ldr	x19, [sp, #16]
     b40:	ldp	x29, x30, [sp], #32
     b44:	ret
     b48:	nop
     b4c:	nop
     b50:	nop
     b54:	nop
     b58:	nop
     b5c:	nop

0000000000000b60 <pts_ieee754_atan>:
     b60:	fmov	x8, d0
     b64:	lsr	x9, x8, #32
     b68:	ubfx	x11, x8, #32, #31
     b6c:	ubfx	w10, w9, #20, #11
     b70:	cmp	w10, #0x441
     b74:	b.cc	b9c <pts_ieee754_atan+0x3c>  // b.lo, b.ul, b.last
     b78:	mov	w10, #0x7ff00000            	// #2146435072
     b7c:	cmp	w11, w10
     b80:	b.hi	b94 <pts_ieee754_atan+0x34>  // b.pmore
     b84:	cbz	w8, c04 <pts_ieee754_atan+0xa4>
     b88:	mov	w8, #0x7ff00000            	// #2146435072
     b8c:	cmp	w11, w8
     b90:	b.ne	c04 <pts_ieee754_atan+0xa4>  // b.any
     b94:	fadd	d0, d0, d0
     b98:	ret
     b9c:	lsr	w9, w11, #18
     ba0:	cmp	w9, #0xff6
     ba4:	b.hi	bd4 <pts_ieee754_atan+0x74>  // b.pmore
     ba8:	adrp	x10, 0 <pts_ieee754_acos>
     bac:	fmov	d2, #1.000000000000000000e+00
     bb0:	ldr	d1, [x10]
     bb4:	mov	w10, #0xffffffff            	// #-1
     bb8:	fadd	d1, d0, d1
     bbc:	fcmp	d1, d2
     bc0:	b.le	c70 <pts_ieee754_atan+0x110>
     bc4:	lsr	w11, w11, #22
     bc8:	cmp	w11, #0xf9
     bcc:	b.cs	c70 <pts_ieee754_atan+0x110>  // b.hs, b.nlast
     bd0:	ret
     bd4:	fabs	d0, d0
     bd8:	mov	w10, #0x3ff2ffff            	// #1072889855
     bdc:	cmp	w11, w10
     be0:	b.hi	c24 <pts_ieee754_atan+0xc4>  // b.pmore
     be4:	fmov	d1, #-1.000000000000000000e+00
     be8:	mov	w10, #0x3fe5ffff            	// #1072037887
     bec:	cmp	w11, w10
     bf0:	b.hi	c50 <pts_ieee754_atan+0xf0>  // b.pmore
     bf4:	fmov	d2, #2.000000000000000000e+00
     bf8:	mov	x10, xzr
     bfc:	fmadd	d1, d0, d2, d1
     c00:	b	c5c <pts_ieee754_atan+0xfc>
     c04:	adrp	x8, 0 <pts_ieee754_acos>
     c08:	cmp	w9, #0x1
     c0c:	ldr	d0, [x8]
     c10:	b.lt	d4c <pts_ieee754_atan+0x1ec>  // b.tstop
     c14:	adrp	x8, 0 <pts_ieee754_acos>
     c18:	ldr	d1, [x8]
     c1c:	fadd	d0, d0, d1
     c20:	ret
     c24:	mov	w10, #0x7fff                	// #32767
     c28:	movk	w10, #0x4003, lsl #16
     c2c:	cmp	w11, w10
     c30:	b.hi	c64 <pts_ieee754_atan+0x104>  // b.pmore
     c34:	fmov	d1, #-1.500000000000000000e+00
     c38:	fmov	d2, #1.000000000000000000e+00
     c3c:	mov	w10, #0x2                   	// #2
     c40:	fmov	d3, #1.500000000000000000e+00
     c44:	fadd	d1, d0, d1
     c48:	fmadd	d0, d0, d3, d2
     c4c:	b	c6c <pts_ieee754_atan+0x10c>
     c50:	fmov	d2, #1.000000000000000000e+00
     c54:	fadd	d1, d0, d1
     c58:	mov	w10, #0x1                   	// #1
     c5c:	fadd	d0, d0, d2
     c60:	b	c6c <pts_ieee754_atan+0x10c>
     c64:	fmov	d1, #-1.000000000000000000e+00
     c68:	mov	w10, #0x3                   	// #3
     c6c:	fdiv	d0, d1, d0
     c70:	fmul	d1, d0, d0
     c74:	adrp	x11, 0 <pts_ieee754_acos>
     c78:	adrp	x12, 0 <pts_ieee754_acos>
     c7c:	ldr	d2, [x11]
     c80:	adrp	x11, 0 <pts_ieee754_acos>
     c84:	adrp	x13, 0 <pts_ieee754_acos>
     c88:	ldr	d4, [x11]
     c8c:	ldr	d5, [x12]
     c90:	ldr	d6, [x13]
     c94:	adrp	x11, 0 <pts_ieee754_acos>
     c98:	adrp	x12, 0 <pts_ieee754_acos>
     c9c:	cmp	w9, #0xff6
     ca0:	fmul	d3, d1, d1
     ca4:	fmadd	d2, d3, d4, d2
     ca8:	fmadd	d4, d3, d6, d5
     cac:	ldr	d5, [x11]
     cb0:	ldr	d6, [x12]
     cb4:	adrp	x11, 0 <pts_ieee754_acos>
     cb8:	adrp	x12, 0 <pts_ieee754_acos>
     cbc:	fmadd	d2, d3, d2, d5
     cc0:	fmadd	d4, d3, d4, d6
     cc4:	ldr	d5, [x11]
     cc8:	ldr	d6, [x12]
     ccc:	adrp	x11, 0 <pts_ieee754_acos>
     cd0:	adrp	x12, 0 <pts_ieee754_acos>
     cd4:	fmadd	d2, d3, d2, d5
     cd8:	fmadd	d4, d3, d4, d6
     cdc:	ldr	d5, [x11]
     ce0:	ldr	d6, [x12]
     ce4:	adrp	x11, 0 <pts_ieee754_acos>
     ce8:	fmadd	d2, d3, d2, d5
     cec:	fmadd	d4, d3, d4, d6
     cf0:	ldr	d5, [x11]
     cf4:	fmadd	d2, d3, d2, d5
     cf8:	fmul	d3, d3, d4
     cfc:	fmadd	d1, d1, d2, d3
     d00:	b.hi	d10 <pts_ieee754_atan+0x1b0>  // b.pmore
     d04:	fmul	d1, d0, d1
     d08:	fsub	d0, d0, d1
     d0c:	ret
     d10:	lsl	x9, x10, #3
     d14:	fmul	d1, d0, d1
     d18:	adrp	x10, 0 <pts_ieee754_acos>
     d1c:	add	x10, x10, #0x0
     d20:	cmp	x8, #0x0
     d24:	ldr	d2, [x10, x9]
     d28:	adrp	x10, 0 <pts_ieee754_acos>
     d2c:	add	x10, x10, #0x0
     d30:	fsub	d1, d1, d2
     d34:	fsub	d0, d1, d0
     d38:	ldr	d1, [x10, x9]
     d3c:	fsub	d0, d1, d0
     d40:	fneg	d1, d0
     d44:	fcsel	d0, d1, d0, lt	// lt = tstop
     d48:	ret
     d4c:	adrp	x8, 0 <pts_ieee754_acos>
     d50:	ldr	d1, [x8]
     d54:	fsub	d0, d1, d0
     d58:	ret
     d5c:	nop

0000000000000d60 <pts_ieee754_atan2>:
     d60:	stp	x29, x30, [sp, #-32]!
     d64:	str	x19, [sp, #16]
     d68:	mov	x29, sp
     d6c:	fmov	x8, d1
     d70:	mov	w10, #0x7ff00000            	// #2146435072
     d74:	ubfx	x9, x8, #32, #31
     d78:	cmp	w8, #0x0
     d7c:	cset	w11, ne	// ne = any
     d80:	orr	w11, w9, w11
     d84:	cmp	w11, w10
     d88:	b.hi	db0 <pts_ieee754_atan2+0x50>  // b.pmore
     d8c:	fmov	x10, d0
     d90:	mov	w13, #0x1                   	// #1
     d94:	movk	w13, #0x7ff0, lsl #16
     d98:	ubfx	x11, x10, #32, #31
     d9c:	cmp	w10, #0x0
     da0:	cset	w12, ne	// ne = any
     da4:	orr	w12, w11, w12
     da8:	cmp	w12, w13
     dac:	b.cc	dc0 <pts_ieee754_atan2+0x60>  // b.lo, b.ul, b.last
     db0:	fadd	d0, d0, d1
     db4:	ldr	x19, [sp, #16]
     db8:	ldp	x29, x30, [sp], #32
     dbc:	ret
     dc0:	lsr	x12, x8, #32
     dc4:	mov	w13, #0xc0100000            	// #-1072693248
     dc8:	add	w13, w12, w13
     dcc:	orr	w13, w13, w8
     dd0:	cbz	w13, e28 <pts_ieee754_atan2+0xc8>
     dd4:	lsr	w13, w12, #30
     dd8:	lsr	x12, x10, #32
     ddc:	and	w19, w13, #0x2
     de0:	orr	w13, w11, w10
     de4:	bfxil	w19, w12, #31, #1
     de8:	cbz	w13, e34 <pts_ieee754_atan2+0xd4>
     dec:	orr	w13, w9, w8
     df0:	cbz	w13, e64 <pts_ieee754_atan2+0x104>
     df4:	mov	w13, #0x7ff00000            	// #2146435072
     df8:	cmp	w9, w13
     dfc:	b.ne	e5c <pts_ieee754_atan2+0xfc>  // b.any
     e00:	cmp	w11, w13
     e04:	b.ne	e8c <pts_ieee754_atan2+0x12c>  // b.any
     e08:	adrp	x8, 0 <pts_ieee754_acos>
     e0c:	cmp	w19, #0x1
     e10:	b.gt	ed8 <pts_ieee754_atan2+0x178>
     e14:	cbnz	w19, f60 <pts_ieee754_atan2+0x200>
     e18:	adrp	x9, 0 <pts_ieee754_acos>
     e1c:	ldr	d0, [x8]
     e20:	ldr	d1, [x9]
     e24:	b	db0 <pts_ieee754_atan2+0x50>
     e28:	ldr	x19, [sp, #16]
     e2c:	ldp	x29, x30, [sp], #32
     e30:	b	b60 <pts_ieee754_atan>
     e34:	cmp	w19, #0x2
     e38:	b.cc	db4 <pts_ieee754_atan2+0x54>  // b.lo, b.ul, b.last
     e3c:	cmp	w19, #0x3
     e40:	b.ne	ef8 <pts_ieee754_atan2+0x198>  // b.any
     e44:	adrp	x8, 0 <pts_ieee754_acos>
     e48:	adrp	x9, 0 <pts_ieee754_acos>
     e4c:	ldr	d0, [x8]
     e50:	ldr	d1, [x9]
     e54:	fsub	d0, d1, d0
     e58:	b	db4 <pts_ieee754_atan2+0x54>
     e5c:	cmp	w11, w13
     e60:	b.ne	ea8 <pts_ieee754_atan2+0x148>  // b.any
     e64:	adrp	x8, 0 <pts_ieee754_acos>
     e68:	ldr	d0, [x8]
     e6c:	tbnz	x10, #63, e7c <pts_ieee754_atan2+0x11c>
     e70:	adrp	x8, 0 <pts_ieee754_acos>
     e74:	ldr	d1, [x8]
     e78:	b	db0 <pts_ieee754_atan2+0x50>
     e7c:	adrp	x8, 0 <pts_ieee754_acos>
     e80:	ldr	d1, [x8]
     e84:	fsub	d0, d1, d0
     e88:	b	db4 <pts_ieee754_atan2+0x54>
     e8c:	cmp	w19, #0x1
     e90:	b.gt	ef0 <pts_ieee754_atan2+0x190>
     e94:	movi	d0, #0x0
     e98:	cbz	w19, db4 <pts_ieee754_atan2+0x54>
     e9c:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
     ea0:	fmov	d0, x8
     ea4:	b	db4 <pts_ieee754_atan2+0x54>
     ea8:	sub	w9, w11, w9
     eac:	asr	w9, w9, #20
     eb0:	cmp	w9, #0x3d
     eb4:	b.lt	f0c <pts_ieee754_atan2+0x1ac>  // b.tstop
     eb8:	adrp	x8, 0 <pts_ieee754_acos>
     ebc:	adrp	x9, 0 <pts_ieee754_acos>
     ec0:	fmov	d0, #5.000000000000000000e-01
     ec4:	ldr	d1, [x8]
     ec8:	ldr	d2, [x9]
     ecc:	lsr	w19, w12, #31
     ed0:	fmadd	d2, d1, d0, d2
     ed4:	b	f2c <pts_ieee754_atan2+0x1cc>
     ed8:	cmp	w19, #0x2
     edc:	b.ne	f74 <pts_ieee754_atan2+0x214>  // b.any
     ee0:	adrp	x9, 0 <pts_ieee754_acos>
     ee4:	ldr	d0, [x8]
     ee8:	ldr	d1, [x9]
     eec:	b	db0 <pts_ieee754_atan2+0x50>
     ef0:	cmp	w19, #0x2
     ef4:	b.ne	e44 <pts_ieee754_atan2+0xe4>  // b.any
     ef8:	adrp	x8, 0 <pts_ieee754_acos>
     efc:	adrp	x9, 0 <pts_ieee754_acos>
     f00:	ldr	d0, [x8]
     f04:	ldr	d1, [x9]
     f08:	b	db0 <pts_ieee754_atan2+0x50>
     f0c:	tbz	x8, #63, f1c <pts_ieee754_atan2+0x1bc>
     f10:	movi	d2, #0x0
     f14:	cmn	w9, #0x3c
     f18:	b.lt	f2c <pts_ieee754_atan2+0x1cc>  // b.tstop
     f1c:	fdiv	d0, d0, d1
     f20:	fabs	d0, d0
     f24:	bl	b60 <pts_ieee754_atan>
     f28:	fmov	d2, d0
     f2c:	cbz	w19, f88 <pts_ieee754_atan2+0x228>
     f30:	cmp	w19, #0x2
     f34:	b.eq	f48 <pts_ieee754_atan2+0x1e8>  // b.none
     f38:	cmp	w19, #0x1
     f3c:	b.ne	f90 <pts_ieee754_atan2+0x230>  // b.any
     f40:	fneg	d0, d2
     f44:	b	db4 <pts_ieee754_atan2+0x54>
     f48:	adrp	x8, 0 <pts_ieee754_acos>
     f4c:	ldr	d0, [x8]
     f50:	adrp	x8, 0 <pts_ieee754_acos>
     f54:	ldr	d1, [x8]
     f58:	fsub	d0, d0, d2
     f5c:	b	db0 <pts_ieee754_atan2+0x50>
     f60:	adrp	x9, 0 <pts_ieee754_acos>
     f64:	ldr	d0, [x8]
     f68:	ldr	d1, [x9]
     f6c:	fsub	d0, d1, d0
     f70:	b	db4 <pts_ieee754_atan2+0x54>
     f74:	adrp	x9, 0 <pts_ieee754_acos>
     f78:	ldr	d0, [x8]
     f7c:	ldr	d1, [x9]
     f80:	fsub	d0, d1, d0
     f84:	b	db4 <pts_ieee754_atan2+0x54>
     f88:	fmov	d0, d2
     f8c:	b	db4 <pts_ieee754_atan2+0x54>
     f90:	adrp	x8, 0 <pts_ieee754_acos>
     f94:	ldr	d0, [x8]
     f98:	adrp	x8, 0 <pts_ieee754_acos>
     f9c:	ldr	d1, [x8]
     fa0:	fsub	d0, d2, d0
     fa4:	b	db0 <pts_ieee754_atan2+0x50>
     fa8:	nop
     fac:	nop
     fb0:	nop
     fb4:	nop
     fb8:	nop
     fbc:	nop

0000000000000fc0 <pts_ieee754_cos>:
     fc0:	sub	sp, sp, #0x20
     fc4:	stp	x29, x30, [sp, #16]
     fc8:	add	x29, sp, #0x10
     fcc:	fmov	x8, d0
     fd0:	mov	w9, #0x21fb                	// #8699
     fd4:	movk	w9, #0x3fe9, lsl #16
     fd8:	ubfx	x8, x8, #32, #31
     fdc:	cmp	w8, w9
     fe0:	b.hi	107c <pts_ieee754_cos+0xbc>  // b.pmore
     fe4:	lsr	w9, w8, #22
     fe8:	cmp	w9, #0xf8
     fec:	b.hi	ffc <pts_ieee754_cos+0x3c>  // b.pmore
     ff0:	fcvtzs	w9, d0
     ff4:	fmov	d1, #1.000000000000000000e+00
     ff8:	cbz	w9, 137c <pts_ieee754_cos+0x3bc>
     ffc:	fmul	d1, d0, d0
    1000:	adrp	x9, 0 <pts_ieee754_acos>
    1004:	adrp	x10, 0 <pts_ieee754_acos>
    1008:	ldr	d2, [x9]
    100c:	ldr	d3, [x10]
    1010:	adrp	x9, 0 <pts_ieee754_acos>
    1014:	fmadd	d2, d1, d3, d2
    1018:	ldr	d3, [x9]
    101c:	adrp	x9, 0 <pts_ieee754_acos>
    1020:	fmadd	d2, d1, d2, d3
    1024:	ldr	d3, [x9]
    1028:	adrp	x9, 0 <pts_ieee754_acos>
    102c:	fmadd	d2, d1, d2, d3
    1030:	ldr	d3, [x9]
    1034:	adrp	x9, 0 <pts_ieee754_acos>
    1038:	fmadd	d2, d1, d2, d3
    103c:	ldr	d3, [x9]
    1040:	mov	w9, #0x3333                	// #13107
    1044:	movk	w9, #0x3fd3, lsl #16
    1048:	cmp	w8, w9
    104c:	fmadd	d2, d1, d2, d3
    1050:	fmul	d2, d1, d2
    1054:	b.cs	1144 <pts_ieee754_cos+0x184>  // b.hs, b.nlast
    1058:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    105c:	fmov	d3, x8
    1060:	fmul	d0, d0, d3
    1064:	fmadd	d0, d1, d2, d0
    1068:	fmov	d2, #5.000000000000000000e-01
    106c:	fnmsub	d0, d1, d2, d0
    1070:	fmov	d1, #1.000000000000000000e+00
    1074:	fsub	d1, d1, d0
    1078:	b	137c <pts_ieee754_cos+0x3bc>
    107c:	lsr	w8, w8, #20
    1080:	cmp	w8, #0x7ff
    1084:	b.cc	1090 <pts_ieee754_cos+0xd0>  // b.lo, b.ul, b.last
    1088:	fsub	d1, d0, d0
    108c:	b	137c <pts_ieee754_cos+0x3bc>
    1090:	mov	x0, sp
    1094:	bl	13e0 <__ieee754_rem_pio2>
    1098:	ldr	d0, [sp]
    109c:	and	w8, w0, #0x3
    10a0:	cmp	w8, #0x2
    10a4:	b.eq	1210 <pts_ieee754_cos+0x250>  // b.none
    10a8:	cmp	w8, #0x1
    10ac:	b.eq	118c <pts_ieee754_cos+0x1cc>  // b.none
    10b0:	cbnz	w8, 12b4 <pts_ieee754_cos+0x2f4>
    10b4:	fmov	x8, d0
    10b8:	ldr	d2, [sp, #8]
    10bc:	lsr	x9, x8, #32
    10c0:	ubfx	w9, w9, #22, #9
    10c4:	cmp	w9, #0xf8
    10c8:	b.hi	10d8 <pts_ieee754_cos+0x118>  // b.pmore
    10cc:	fcvtzs	w9, d0
    10d0:	fmov	d1, #1.000000000000000000e+00
    10d4:	cbz	w9, 137c <pts_ieee754_cos+0x3bc>
    10d8:	fmul	d1, d0, d0
    10dc:	adrp	x9, 0 <pts_ieee754_acos>
    10e0:	adrp	x10, 0 <pts_ieee754_acos>
    10e4:	ldr	d3, [x9]
    10e8:	ldr	d4, [x10]
    10ec:	adrp	x9, 0 <pts_ieee754_acos>
    10f0:	ubfx	x8, x8, #32, #31
    10f4:	fmadd	d3, d1, d4, d3
    10f8:	ldr	d4, [x9]
    10fc:	adrp	x9, 0 <pts_ieee754_acos>
    1100:	fmadd	d3, d1, d3, d4
    1104:	ldr	d4, [x9]
    1108:	adrp	x9, 0 <pts_ieee754_acos>
    110c:	fmadd	d3, d1, d3, d4
    1110:	ldr	d4, [x9]
    1114:	adrp	x9, 0 <pts_ieee754_acos>
    1118:	fmadd	d3, d1, d3, d4
    111c:	ldr	d4, [x9]
    1120:	mov	w9, #0x3333                	// #13107
    1124:	movk	w9, #0x3fd3, lsl #16
    1128:	cmp	w8, w9
    112c:	fmadd	d3, d1, d3, d4
    1130:	fmul	d3, d1, d3
    1134:	b.cs	138c <pts_ieee754_cos+0x3cc>  // b.hs, b.nlast
    1138:	fnmul	d0, d0, d2
    113c:	fmadd	d0, d1, d3, d0
    1140:	b	1068 <pts_ieee754_cos+0xa8>
    1144:	sub	w9, w8, #0x200, lsl #12
    1148:	mov	x11, #0x8000000000000000    	// #-9223372036854775808
    114c:	fmov	d3, #2.812500000000000000e-01
    1150:	lsl	x9, x9, #32
    1154:	fmov	d5, x11
    1158:	mov	w10, #0x3fe90000            	// #1072234496
    115c:	cmp	w8, w10
    1160:	fmov	d4, x9
    1164:	fmul	d0, d0, d5
    1168:	fcsel	d3, d3, d4, hi	// hi = pmore
    116c:	fmov	d4, #5.000000000000000000e-01
    1170:	fmadd	d0, d1, d2, d0
    1174:	fnmsub	d4, d1, d4, d3
    1178:	fmov	d1, #1.000000000000000000e+00
    117c:	fsub	d1, d1, d3
    1180:	fsub	d0, d0, d4
    1184:	fadd	d1, d1, d0
    1188:	b	137c <pts_ieee754_cos+0x3bc>
    118c:	fmov	x8, d0
    1190:	ubfx	x8, x8, #54, #9
    1194:	cmp	x8, #0xf8
    1198:	b.hi	11a4 <pts_ieee754_cos+0x1e4>  // b.pmore
    119c:	fcvtzs	w8, d0
    11a0:	cbz	w8, 1208 <pts_ieee754_cos+0x248>
    11a4:	fmul	d1, d0, d0
    11a8:	adrp	x8, 0 <pts_ieee754_acos>
    11ac:	adrp	x9, 0 <pts_ieee754_acos>
    11b0:	ldr	d2, [x8]
    11b4:	ldr	d3, [x9]
    11b8:	adrp	x8, 0 <pts_ieee754_acos>
    11bc:	fmov	d4, #5.000000000000000000e-01
    11c0:	ldr	d5, [sp, #8]
    11c4:	fmadd	d2, d1, d3, d2
    11c8:	ldr	d3, [x8]
    11cc:	adrp	x8, 0 <pts_ieee754_acos>
    11d0:	fmadd	d2, d1, d2, d3
    11d4:	ldr	d3, [x8]
    11d8:	adrp	x8, 0 <pts_ieee754_acos>
    11dc:	fmadd	d2, d1, d2, d3
    11e0:	ldr	d3, [x8]
    11e4:	adrp	x8, 0 <pts_ieee754_acos>
    11e8:	fmadd	d2, d1, d2, d3
    11ec:	fnmul	d3, d1, d0
    11f0:	fmul	d2, d3, d2
    11f4:	fmadd	d2, d5, d4, d2
    11f8:	fnmsub	d1, d1, d2, d5
    11fc:	ldr	d2, [x8]
    1200:	fmadd	d1, d3, d2, d1
    1204:	fsub	d0, d0, d1
    1208:	fneg	d1, d0
    120c:	b	137c <pts_ieee754_cos+0x3bc>
    1210:	fmov	x8, d0
    1214:	ldr	d1, [sp, #8]
    1218:	lsr	x9, x8, #32
    121c:	ubfx	w9, w9, #22, #9
    1220:	cmp	w9, #0xf8
    1224:	b.hi	1234 <pts_ieee754_cos+0x274>  // b.pmore
    1228:	fcvtzs	w9, d0
    122c:	fmov	d2, #1.000000000000000000e+00
    1230:	cbz	w9, 1378 <pts_ieee754_cos+0x3b8>
    1234:	fmul	d2, d0, d0
    1238:	adrp	x9, 0 <pts_ieee754_acos>
    123c:	adrp	x10, 0 <pts_ieee754_acos>
    1240:	ldr	d3, [x9]
    1244:	ldr	d4, [x10]
    1248:	adrp	x9, 0 <pts_ieee754_acos>
    124c:	ubfx	x8, x8, #32, #31
    1250:	fmadd	d3, d2, d4, d3
    1254:	ldr	d4, [x9]
    1258:	adrp	x9, 0 <pts_ieee754_acos>
    125c:	fmadd	d3, d2, d3, d4
    1260:	ldr	d4, [x9]
    1264:	adrp	x9, 0 <pts_ieee754_acos>
    1268:	fmadd	d3, d2, d3, d4
    126c:	ldr	d4, [x9]
    1270:	adrp	x9, 0 <pts_ieee754_acos>
    1274:	fmadd	d3, d2, d3, d4
    1278:	ldr	d4, [x9]
    127c:	mov	w9, #0x3333                	// #13107
    1280:	movk	w9, #0x3fd3, lsl #16
    1284:	cmp	w8, w9
    1288:	fmadd	d3, d2, d3, d4
    128c:	fmul	d3, d2, d3
    1290:	b.cs	133c <pts_ieee754_cos+0x37c>  // b.hs, b.nlast
    1294:	fnmul	d0, d0, d1
    1298:	fmov	d1, #5.000000000000000000e-01
    129c:	fmadd	d0, d2, d3, d0
    12a0:	fnmsub	d0, d2, d1, d0
    12a4:	fmov	d1, #1.000000000000000000e+00
    12a8:	fsub	d2, d1, d0
    12ac:	fneg	d1, d2
    12b0:	b	137c <pts_ieee754_cos+0x3bc>
    12b4:	fmov	x8, d0
    12b8:	ubfx	x8, x8, #54, #9
    12bc:	cmp	x8, #0xf8
    12c0:	b.hi	12d4 <pts_ieee754_cos+0x314>  // b.pmore
    12c4:	fcvtzs	w8, d0
    12c8:	cbnz	w8, 12d4 <pts_ieee754_cos+0x314>
    12cc:	fmov	d1, d0
    12d0:	b	137c <pts_ieee754_cos+0x3bc>
    12d4:	fmul	d1, d0, d0
    12d8:	adrp	x8, 0 <pts_ieee754_acos>
    12dc:	adrp	x9, 0 <pts_ieee754_acos>
    12e0:	ldr	d2, [x8]
    12e4:	ldr	d3, [x9]
    12e8:	adrp	x8, 0 <pts_ieee754_acos>
    12ec:	fmov	d4, #5.000000000000000000e-01
    12f0:	ldr	d5, [sp, #8]
    12f4:	fmadd	d2, d1, d3, d2
    12f8:	ldr	d3, [x8]
    12fc:	adrp	x8, 0 <pts_ieee754_acos>
    1300:	fmadd	d2, d1, d2, d3
    1304:	ldr	d3, [x8]
    1308:	adrp	x8, 0 <pts_ieee754_acos>
    130c:	fmadd	d2, d1, d2, d3
    1310:	ldr	d3, [x8]
    1314:	adrp	x8, 0 <pts_ieee754_acos>
    1318:	fmadd	d2, d1, d2, d3
    131c:	fnmul	d3, d1, d0
    1320:	fmul	d2, d3, d2
    1324:	fmadd	d2, d5, d4, d2
    1328:	fnmsub	d1, d1, d2, d5
    132c:	ldr	d2, [x8]
    1330:	fmadd	d1, d3, d2, d1
    1334:	fsub	d1, d0, d1
    1338:	b	137c <pts_ieee754_cos+0x3bc>
    133c:	sub	w9, w8, #0x200, lsl #12
    1340:	fmov	d4, #2.812500000000000000e-01
    1344:	mov	w10, #0x3fe90000            	// #1072234496
    1348:	lsl	x9, x9, #32
    134c:	cmp	w8, w10
    1350:	fnmul	d0, d0, d1
    1354:	fmov	d1, #5.000000000000000000e-01
    1358:	fmov	d5, x9
    135c:	fmadd	d0, d2, d3, d0
    1360:	fcsel	d4, d4, d5, hi	// hi = pmore
    1364:	fnmsub	d1, d2, d1, d4
    1368:	fmov	d2, #1.000000000000000000e+00
    136c:	fsub	d2, d2, d4
    1370:	fsub	d0, d0, d1
    1374:	fadd	d2, d2, d0
    1378:	fneg	d1, d2
    137c:	fmov	d0, d1
    1380:	ldp	x29, x30, [sp, #16]
    1384:	add	sp, sp, #0x20
    1388:	ret
    138c:	sub	w9, w8, #0x200, lsl #12
    1390:	fmov	d4, #2.812500000000000000e-01
    1394:	mov	w10, #0x3fe90000            	// #1072234496
    1398:	lsl	x9, x9, #32
    139c:	cmp	w8, w10
    13a0:	fnmul	d0, d0, d2
    13a4:	fmov	d2, #5.000000000000000000e-01
    13a8:	fmov	d5, x9
    13ac:	fmadd	d0, d1, d3, d0
    13b0:	fcsel	d4, d4, d5, hi	// hi = pmore
    13b4:	fnmsub	d2, d1, d2, d4
    13b8:	fmov	d1, #1.000000000000000000e+00
    13bc:	fsub	d1, d1, d4
    13c0:	fsub	d0, d0, d2
    13c4:	b	1184 <pts_ieee754_cos+0x1c4>
    13c8:	nop
    13cc:	nop
    13d0:	nop
    13d4:	nop
    13d8:	nop
    13dc:	nop

00000000000013e0 <__ieee754_rem_pio2>:
    13e0:	str	d14, [sp, #-160]!
    13e4:	stp	d13, d12, [sp, #16]
    13e8:	stp	d11, d10, [sp, #32]
    13ec:	stp	d9, d8, [sp, #48]
    13f0:	stp	x29, x30, [sp, #64]
    13f4:	stp	x28, x27, [sp, #80]
    13f8:	stp	x26, x25, [sp, #96]
    13fc:	stp	x24, x23, [sp, #112]
    1400:	stp	x22, x21, [sp, #128]
    1404:	stp	x20, x19, [sp, #144]
    1408:	add	x29, sp, #0x40
    140c:	sub	sp, sp, #0x280
    1410:	fmov	x2, d0
    1414:	mov	w8, #0x21fb                	// #8699
    1418:	mov	x1, x0
    141c:	movk	w8, #0x3fe9, lsl #16
    1420:	ubfx	x10, x2, #32, #31
    1424:	cmp	w10, w8
    1428:	b.hi	143c <__ieee754_rem_pio2+0x5c>  // b.pmore
    142c:	mov	w0, wzr
    1430:	str	d0, [x1]
    1434:	str	xzr, [x1, #8]
    1438:	b	1e7c <__ieee754_rem_pio2+0xa9c>
    143c:	mov	w8, #0xd97b                	// #55675
    1440:	movk	w8, #0x4002, lsl #16
    1444:	cmp	w10, w8
    1448:	b.hi	148c <__ieee754_rem_pio2+0xac>  // b.pmore
    144c:	lsr	x8, x2, #32
    1450:	cmp	w8, #0x1
    1454:	b.lt	1598 <__ieee754_rem_pio2+0x1b8>  // b.tstop
    1458:	adrp	x8, 0 <pts_ieee754_acos>
    145c:	ldr	d1, [x8]
    1460:	mov	w8, #0x21fb                	// #8699
    1464:	movk	w8, #0x3ff9, lsl #16
    1468:	fadd	d0, d0, d1
    146c:	cmp	w10, w8
    1470:	b.ne	15cc <__ieee754_rem_pio2+0x1ec>  // b.any
    1474:	adrp	x8, 0 <pts_ieee754_acos>
    1478:	ldr	d1, [x8]
    147c:	adrp	x8, 0 <pts_ieee754_acos>
    1480:	fadd	d0, d0, d1
    1484:	ldr	d1, [x8]
    1488:	b	15d4 <__ieee754_rem_pio2+0x1f4>
    148c:	mov	w8, #0x21fb                	// #8699
    1490:	movk	w8, #0x4139, lsl #16
    1494:	cmp	w10, w8
    1498:	b.hi	157c <__ieee754_rem_pio2+0x19c>  // b.pmore
    149c:	fabs	d0, d0
    14a0:	adrp	x8, 0 <pts_ieee754_acos>
    14a4:	fmov	d1, #5.000000000000000000e-01
    14a8:	ldr	d2, [x8]
    14ac:	adrp	x8, 0 <pts_ieee754_acos>
    14b0:	adrp	x9, 0 <pts_ieee754_acos>
    14b4:	ldr	d3, [x9]
    14b8:	fmadd	d1, d0, d2, d1
    14bc:	fcvtzs	w0, d1
    14c0:	ldr	d1, [x8]
    14c4:	scvtf	d2, w0
    14c8:	cmp	w0, #0x1f
    14cc:	fmadd	d1, d2, d1, d0
    14d0:	fmul	d0, d2, d3
    14d4:	b.gt	14f0 <__ieee754_rem_pio2+0x110>
    14d8:	adrp	x8, 0 <pts_ieee754_acos>
    14dc:	add	x8, x8, #0x0
    14e0:	add	x8, x8, w0, sxtw #2
    14e4:	ldur	w8, [x8, #-4]
    14e8:	cmp	w10, w8
    14ec:	b.ne	1570 <__ieee754_rem_pio2+0x190>  // b.any
    14f0:	fsub	d3, d1, d0
    14f4:	lsr	w8, w10, #20
    14f8:	fmov	x9, d3
    14fc:	str	d3, [x1]
    1500:	ubfx	x9, x9, #52, #11
    1504:	sub	w9, w8, w9
    1508:	cmp	w9, #0x11
    150c:	b.lt	1ba0 <__ieee754_rem_pio2+0x7c0>  // b.tstop
    1510:	fneg	d4, d2
    1514:	adrp	x9, 0 <pts_ieee754_acos>
    1518:	ldr	d0, [x9]
    151c:	adrp	x9, 0 <pts_ieee754_acos>
    1520:	fmadd	d5, d4, d0, d1
    1524:	fsub	d1, d1, d5
    1528:	fmadd	d0, d4, d0, d1
    152c:	ldr	d1, [x9]
    1530:	fnmsub	d0, d2, d1, d0
    1534:	fsub	d3, d5, d0
    1538:	fmov	x9, d3
    153c:	str	d3, [x1]
    1540:	ubfx	x9, x9, #52, #11
    1544:	sub	w8, w8, w9
    1548:	cmp	w8, #0x32
    154c:	b.lt	1b9c <__ieee754_rem_pio2+0x7bc>  // b.tstop
    1550:	adrp	x8, 0 <pts_ieee754_acos>
    1554:	ldr	d0, [x8]
    1558:	adrp	x8, 0 <pts_ieee754_acos>
    155c:	fmadd	d1, d4, d0, d5
    1560:	fsub	d3, d5, d1
    1564:	fmadd	d0, d4, d0, d3
    1568:	ldr	d3, [x8]
    156c:	fnmsub	d0, d2, d3, d0
    1570:	fsub	d3, d1, d0
    1574:	str	d3, [x1]
    1578:	b	1ba0 <__ieee754_rem_pio2+0x7c0>
    157c:	lsr	w8, w10, #20
    1580:	cmp	w8, #0x7ff
    1584:	b.cc	15e0 <__ieee754_rem_pio2+0x200>  // b.lo, b.ul, b.last
    1588:	fsub	d0, d0, d0
    158c:	mov	w0, wzr
    1590:	stp	d0, d0, [x1]
    1594:	b	1e7c <__ieee754_rem_pio2+0xa9c>
    1598:	adrp	x8, 0 <pts_ieee754_acos>
    159c:	ldr	d1, [x8]
    15a0:	mov	w8, #0x21fb                	// #8699
    15a4:	movk	w8, #0x3ff9, lsl #16
    15a8:	fadd	d0, d0, d1
    15ac:	cmp	w10, w8
    15b0:	b.ne	16e4 <__ieee754_rem_pio2+0x304>  // b.any
    15b4:	adrp	x8, 0 <pts_ieee754_acos>
    15b8:	ldr	d1, [x8]
    15bc:	adrp	x8, 0 <pts_ieee754_acos>
    15c0:	fadd	d0, d0, d1
    15c4:	ldr	d1, [x8]
    15c8:	b	16ec <__ieee754_rem_pio2+0x30c>
    15cc:	adrp	x8, 0 <pts_ieee754_acos>
    15d0:	ldr	d1, [x8]
    15d4:	fadd	d2, d0, d1
    15d8:	mov	w0, #0x1                   	// #1
    15dc:	b	16f4 <__ieee754_rem_pio2+0x314>
    15e0:	sub	w9, w8, #0x416
    15e4:	mov	x11, x2
    15e8:	mov	x23, xzr
    15ec:	sub	w10, w10, w9, lsl #20
    15f0:	mov	x12, #0x500000000           	// #21474836480
    15f4:	mov	x13, #0x400000000           	// #17179869184
    15f8:	mov	x14, #0x300000000           	// #12884901888
    15fc:	mov	x15, #0xffffffff00000000    	// #-4294967296
    1600:	bfi	x11, x10, #32, #32
    1604:	fmov	d0, x11
    1608:	mov	x11, #0x4170000000000000    	// #4715268809856909312
    160c:	fmov	d2, x11
    1610:	fcvtzs	w10, d0
    1614:	scvtf	d1, w10
    1618:	fsub	d0, d0, d1
    161c:	fcvtzs	w10, d0, #24
    1620:	fmul	d0, d0, d2
    1624:	scvtf	d3, w10
    1628:	add	x10, sp, #0x28
    162c:	add	x11, x10, #0x10
    1630:	mov	x10, #0x600000000           	// #25769803776
    1634:	fsub	d0, d0, d3
    1638:	stp	d1, d3, [sp, #40]
    163c:	fmul	d0, d0, d2
    1640:	str	d0, [sp, #56]
    1644:	ldr	d0, [x11, x23, lsl #3]
    1648:	add	x12, x12, x15
    164c:	add	x13, x13, x15
    1650:	add	x14, x14, x15
    1654:	add	x10, x10, x15
    1658:	sub	x23, x23, #0x1
    165c:	fcmp	d0, #0.0
    1660:	b.eq	1644 <__ieee754_rem_pio2+0x264>  // b.none
    1664:	mov	w11, #0xaaab                	// #43691
    1668:	sub	w8, w8, #0x419
    166c:	add	x15, x23, #0x4
    1670:	movk	w11, #0x2aaa, lsl #16
    1674:	cmn	w15, #0x3
    1678:	stp	x1, x2, [sp, #8]
    167c:	smull	x8, w8, w11
    1680:	lsr	x11, x8, #63
    1684:	asr	x8, x8, #34
    1688:	add	w8, w8, w11
    168c:	mov	w11, #0xffffffe8            	// #-24
    1690:	madd	w9, w8, w11, w9
    1694:	stur	w9, [x29, #-52]
    1698:	adrp	x9, 0 <pts_ieee754_acos>
    169c:	add	x9, x9, #0x0
    16a0:	b.lt	1810 <__ieee754_rem_pio2+0x430>  // b.tstop
    16a4:	add	x11, x23, #0x7
    16a8:	sub	w16, w8, w23
    16ac:	add	x18, sp, #0x188
    16b0:	bic	w17, w11, w11, asr #31
    16b4:	sub	w16, w16, #0x3
    16b8:	add	x17, x17, #0x1
    16bc:	b	16d8 <__ieee754_rem_pio2+0x2f8>
    16c0:	ldr	w0, [x9, w16, uxtw #2]
    16c4:	scvtf	d0, w0
    16c8:	subs	x17, x17, #0x1
    16cc:	add	w16, w16, #0x1
    16d0:	str	d0, [x18], #8
    16d4:	b.eq	1704 <__ieee754_rem_pio2+0x324>  // b.none
    16d8:	tbz	w16, #31, 16c0 <__ieee754_rem_pio2+0x2e0>
    16dc:	movi	d0, #0x0
    16e0:	b	16c8 <__ieee754_rem_pio2+0x2e8>
    16e4:	adrp	x8, 0 <pts_ieee754_acos>
    16e8:	ldr	d1, [x8]
    16ec:	fadd	d2, d0, d1
    16f0:	mov	w0, #0xffffffff            	// #-1
    16f4:	fsub	d0, d0, d2
    16f8:	fadd	d0, d0, d1
    16fc:	stp	d2, d0, [x1]
    1700:	b	1e7c <__ieee754_rem_pio2+0xa9c>
    1704:	cmp	w15, #0x0
    1708:	b.le	1810 <__ieee754_rem_pio2+0x430>
    170c:	movi	d0, #0x0
    1710:	and	x25, x15, #0xffffffff
    1714:	add	w15, w23, #0x4
    1718:	add	x16, sp, #0x28
    171c:	add	x17, sp, #0x188
    1720:	mov	x18, #0xffffffff00000000    	// #-4294967296
    1724:	asr	x0, x14, #29
    1728:	ldr	d1, [x16], #8
    172c:	subs	x15, x15, #0x1
    1730:	add	x14, x14, x18
    1734:	ldr	d2, [x17, x0]
    1738:	fmadd	d0, d1, d2, d0
    173c:	b.ne	1724 <__ieee754_rem_pio2+0x344>  // b.any
    1740:	movi	d1, #0x0
    1744:	add	w14, w23, #0x4
    1748:	add	x15, sp, #0x28
    174c:	add	x16, sp, #0x188
    1750:	mov	x17, #0xffffffff00000000    	// #-4294967296
    1754:	str	d0, [sp, #64]
    1758:	asr	x18, x13, #29
    175c:	ldr	d0, [x15], #8
    1760:	subs	x14, x14, #0x1
    1764:	add	x13, x13, x17
    1768:	ldr	d2, [x16, x18]
    176c:	fmadd	d1, d0, d2, d1
    1770:	b.ne	1758 <__ieee754_rem_pio2+0x378>  // b.any
    1774:	movi	d0, #0x0
    1778:	add	w13, w23, #0x4
    177c:	add	x14, sp, #0x28
    1780:	add	x15, sp, #0x188
    1784:	mov	x16, #0xffffffff00000000    	// #-4294967296
    1788:	str	d1, [sp, #72]
    178c:	asr	x17, x12, #29
    1790:	ldr	d1, [x14], #8
    1794:	subs	x13, x13, #0x1
    1798:	add	x12, x12, x16
    179c:	ldr	d2, [x15, x17]
    17a0:	fmadd	d0, d1, d2, d0
    17a4:	b.ne	178c <__ieee754_rem_pio2+0x3ac>  // b.any
    17a8:	movi	d1, #0x0
    17ac:	add	w12, w23, #0x4
    17b0:	add	x13, sp, #0x28
    17b4:	add	x14, sp, #0x188
    17b8:	mov	x15, #0xffffffff00000000    	// #-4294967296
    17bc:	str	d0, [sp, #80]
    17c0:	asr	x16, x10, #29
    17c4:	ldr	d0, [x13], #8
    17c8:	subs	x12, x12, #0x1
    17cc:	add	x10, x10, x15
    17d0:	ldr	d2, [x14, x16]
    17d4:	fmadd	d1, d0, d2, d1
    17d8:	b.ne	17c0 <__ieee754_rem_pio2+0x3e0>  // b.any
    17dc:	movi	d0, #0x0
    17e0:	add	w10, w23, #0x4
    17e4:	add	x12, sp, #0x28
    17e8:	add	x13, sp, #0x188
    17ec:	str	d1, [sp, #88]
    17f0:	ldr	d1, [x12], #8
    17f4:	ldr	d2, [x13, w11, sxtw #3]
    17f8:	sub	x10, x10, #0x1
    17fc:	sub	w11, w11, #0x1
    1800:	fmadd	d0, d1, d2, d0
    1804:	cbnz	x10, 17f0 <__ieee754_rem_pio2+0x410>
    1808:	mov	w27, #0x1                   	// #1
    180c:	b	1824 <__ieee754_rem_pio2+0x444>
    1810:	movi	v1.2d, #0x0
    1814:	mov	w27, wzr
    1818:	movi	d0, #0x0
    181c:	and	x25, x15, #0xffffffff
    1820:	stp	q1, q1, [sp, #64]
    1824:	ldur	w12, [x29, #-52]
    1828:	mov	w10, #0x30                  	// #48
    182c:	mov	w11, #0x2f                  	// #47
    1830:	add	x22, x9, w8, sxtw #2
    1834:	mov	x9, #0xc170000000000000    	// #-4508103226997866496
    1838:	str	d0, [sp, #96]
    183c:	sub	w10, w10, w12
    1840:	sub	w21, w12, #0x18
    1844:	fmov	d9, #1.250000000000000000e-01
    1848:	stur	w10, [x29, #-56]
    184c:	sub	w10, w11, w12
    1850:	fmov	d10, #-8.000000000000000000e+00
    1854:	str	w10, [sp, #36]
    1858:	sub	x10, x29, #0x98
    185c:	fmov	d11, #1.000000000000000000e+00
    1860:	sub	x8, x10, #0x10
    1864:	sub	x19, x10, #0x4
    1868:	fmov	d12, #5.000000000000000000e-01
    186c:	str	x8, [sp, #24]
    1870:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1874:	fmov	d14, x9
    1878:	fmov	d13, x8
    187c:	add	x20, sp, #0x40
    1880:	add	x26, sp, #0x188
    1884:	mov	w8, #0x4                   	// #4
    1888:	b	1890 <__ieee754_rem_pio2+0x4b0>
    188c:	ldr	d0, [x20, x8, lsl #3]
    1890:	mov	w28, w8
    1894:	sub	x9, x29, #0x98
    1898:	sub	x8, x28, #0x1
    189c:	fmul	d1, d0, d13
    18a0:	ldr	d2, [x20, x8, lsl #3]
    18a4:	sub	x8, x8, #0x1
    18a8:	cmn	x8, #0x1
    18ac:	fcvtzs	w10, d1
    18b0:	scvtf	d1, w10
    18b4:	fmadd	d0, d1, d14, d0
    18b8:	fcvtzs	w10, d0
    18bc:	fadd	d0, d2, d1
    18c0:	str	w10, [x9], #4
    18c4:	b.ne	189c <__ieee754_rem_pio2+0x4bc>  // b.any
    18c8:	mov	w0, w21
    18cc:	bl	0 <scalbn>
    18d0:	fmul	d1, d0, d9
    18d4:	ldur	w8, [x29, #-52]
    18d8:	cmp	w8, #0x19
    18dc:	frintm	d1, d1
    18e0:	fmadd	d0, d1, d10, d0
    18e4:	fcvtzs	w24, d0
    18e8:	scvtf	d1, w24
    18ec:	fsub	d8, d0, d1
    18f0:	b.lt	192c <__ieee754_rem_pio2+0x54c>  // b.tstop
    18f4:	sub	x8, x29, #0x98
    18f8:	ldur	w11, [x29, #-56]
    18fc:	add	x8, x8, w28, sxtw #2
    1900:	ldur	w9, [x8, #-4]
    1904:	asr	w10, w9, w11
    1908:	lsl	w11, w10, w11
    190c:	add	w24, w10, w24
    1910:	sub	w9, w9, w11
    1914:	ldr	w11, [sp, #36]
    1918:	stur	w9, [x8, #-4]
    191c:	asr	w13, w9, w11
    1920:	cmp	w13, #0x1
    1924:	b.ge	1960 <__ieee754_rem_pio2+0x580>  // b.tcont
    1928:	b	1a14 <__ieee754_rem_pio2+0x634>
    192c:	cbz	w21, 1940 <__ieee754_rem_pio2+0x560>
    1930:	fcmp	d8, d12
    1934:	b.ge	195c <__ieee754_rem_pio2+0x57c>  // b.tcont
    1938:	mov	w13, wzr
    193c:	b	1a14 <__ieee754_rem_pio2+0x634>
    1940:	sub	x8, x29, #0x98
    1944:	add	x8, x8, w28, sxtw #2
    1948:	ldur	w8, [x8, #-4]
    194c:	asr	w13, w8, #23
    1950:	cmp	w13, #0x1
    1954:	b.ge	1960 <__ieee754_rem_pio2+0x580>  // b.tcont
    1958:	b	1a14 <__ieee754_rem_pio2+0x634>
    195c:	mov	w13, #0x2                   	// #2
    1960:	mov	w11, wzr
    1964:	sub	x9, x29, #0x98
    1968:	mov	x10, x28
    196c:	b	1990 <__ieee754_rem_pio2+0x5b0>
    1970:	mov	w11, #0xffffff              	// #16777215
    1974:	sub	w11, w11, w12
    1978:	mov	w8, wzr
    197c:	str	w11, [x9]
    1980:	mov	w11, #0x1                   	// #1
    1984:	subs	x10, x10, #0x1
    1988:	add	x9, x9, #0x4
    198c:	b.eq	19b0 <__ieee754_rem_pio2+0x5d0>  // b.none
    1990:	ldr	w12, [x9]
    1994:	cbnz	w11, 1970 <__ieee754_rem_pio2+0x590>
    1998:	cbz	w12, 19a4 <__ieee754_rem_pio2+0x5c4>
    199c:	mov	w11, #0x1000000             	// #16777216
    19a0:	b	1974 <__ieee754_rem_pio2+0x594>
    19a4:	mov	w11, wzr
    19a8:	mov	w8, #0x1                   	// #1
    19ac:	b	1984 <__ieee754_rem_pio2+0x5a4>
    19b0:	ldur	w9, [x29, #-52]
    19b4:	cmp	w9, #0x19
    19b8:	b.lt	19ec <__ieee754_rem_pio2+0x60c>  // b.tstop
    19bc:	b.eq	19d4 <__ieee754_rem_pio2+0x5f4>  // b.none
    19c0:	ldur	w9, [x29, #-52]
    19c4:	cmp	w9, #0x1a
    19c8:	b.ne	19ec <__ieee754_rem_pio2+0x60c>  // b.any
    19cc:	mov	w9, #0x3fffff              	// #4194303
    19d0:	b	19d8 <__ieee754_rem_pio2+0x5f8>
    19d4:	mov	w9, #0x7fffff              	// #8388607
    19d8:	sub	x10, x29, #0x98
    19dc:	add	x10, x10, w28, sxtw #2
    19e0:	ldur	w11, [x10, #-4]
    19e4:	and	w9, w11, w9
    19e8:	stur	w9, [x10, #-4]
    19ec:	cmp	w13, #0x2
    19f0:	add	w24, w24, #0x1
    19f4:	b.ne	1a10 <__ieee754_rem_pio2+0x630>  // b.any
    19f8:	fsub	d8, d11, d8
    19fc:	tbnz	w8, #0, 1a10 <__ieee754_rem_pio2+0x630>
    1a00:	fmov	d0, #1.000000000000000000e+00
    1a04:	mov	w0, w21
    1a08:	bl	0 <scalbn>
    1a0c:	fsub	d8, d8, d0
    1a10:	mov	w13, #0x2                   	// #2
    1a14:	fcmp	d8, #0.0
    1a18:	b.ne	1b60 <__ieee754_rem_pio2+0x780>  // b.any
    1a1c:	cmp	w28, #0x5
    1a20:	b.cc	1ab8 <__ieee754_rem_pio2+0x6d8>  // b.lo, b.ul, b.last
    1a24:	sub	x9, x28, #0x4
    1a28:	cmp	x9, #0x8
    1a2c:	b.cs	1a3c <__ieee754_rem_pio2+0x65c>  // b.hs, b.nlast
    1a30:	mov	w9, wzr
    1a34:	mov	x8, x28
    1a38:	b	1aa0 <__ieee754_rem_pio2+0x6c0>
    1a3c:	movi	v0.2d, #0x0
    1a40:	movi	v1.2d, #0x0
    1a44:	ldr	x8, [sp, #24]
    1a48:	and	x10, x9, #0xfffffffffffffff8
    1a4c:	add	x11, x8, x28, lsl #2
    1a50:	sub	x8, x28, x10
    1a54:	mov	x12, x10
    1a58:	ldp	q3, q2, [x11, #-16]
    1a5c:	subs	x12, x12, #0x8
    1a60:	sub	x11, x11, #0x20
    1a64:	rev64	v2.4s, v2.4s
    1a68:	rev64	v3.4s, v3.4s
    1a6c:	ext	v2.16b, v2.16b, v2.16b, #8
    1a70:	ext	v3.16b, v3.16b, v3.16b, #8
    1a74:	orr	v0.16b, v2.16b, v0.16b
    1a78:	orr	v1.16b, v3.16b, v1.16b
    1a7c:	b.ne	1a58 <__ieee754_rem_pio2+0x678>  // b.any
    1a80:	orr	v0.16b, v1.16b, v0.16b
    1a84:	cmp	x9, x10
    1a88:	ext	v1.16b, v0.16b, v0.16b, #8
    1a8c:	orr	v0.8b, v0.8b, v1.8b
    1a90:	fmov	x11, d0
    1a94:	lsr	x12, x11, #32
    1a98:	orr	w9, w11, w12
    1a9c:	b.eq	1ab4 <__ieee754_rem_pio2+0x6d4>  // b.none
    1aa0:	ldr	w10, [x19, x8, lsl #2]
    1aa4:	cmp	x8, #0x5
    1aa8:	sub	x8, x8, #0x1
    1aac:	orr	w9, w10, w9
    1ab0:	b.gt	1aa0 <__ieee754_rem_pio2+0x6c0>
    1ab4:	cbnz	w9, 1d48 <__ieee754_rem_pio2+0x968>
    1ab8:	ldur	w8, [x29, #-140]
    1abc:	cbz	w8, 1ac8 <__ieee754_rem_pio2+0x6e8>
    1ac0:	mov	w8, #0x1                   	// #1
    1ac4:	b	1af8 <__ieee754_rem_pio2+0x718>
    1ac8:	ldur	w8, [x29, #-144]
    1acc:	cbz	w8, 1ad8 <__ieee754_rem_pio2+0x6f8>
    1ad0:	mov	w8, #0x2                   	// #2
    1ad4:	b	1af8 <__ieee754_rem_pio2+0x718>
    1ad8:	ldur	w8, [x29, #-148]
    1adc:	cbz	w8, 1ae8 <__ieee754_rem_pio2+0x708>
    1ae0:	mov	w8, #0x3                   	// #3
    1ae4:	b	1af8 <__ieee754_rem_pio2+0x718>
    1ae8:	ldur	w8, [x29, #-152]
    1aec:	cmp	w8, #0x0
    1af0:	mov	w8, #0x4                   	// #4
    1af4:	cinc	w8, w8, eq	// eq = none
    1af8:	add	w9, w23, w28
    1afc:	add	w8, w8, w28
    1b00:	add	w9, w9, #0x4
    1b04:	b	1b1c <__ieee754_rem_pio2+0x73c>
    1b08:	cmp	x10, x8
    1b0c:	add	w9, w9, #0x1
    1b10:	mov	x28, x10
    1b14:	str	d0, [x20, x10, lsl #3]
    1b18:	b.cs	188c <__ieee754_rem_pio2+0x4ac>  // b.hs, b.nlast
    1b1c:	add	x10, x28, #0x1
    1b20:	movi	d0, #0x0
    1b24:	ldr	w11, [x22, x10, lsl #2]
    1b28:	scvtf	d1, w11
    1b2c:	add	w11, w23, w28
    1b30:	add	w11, w11, #0x4
    1b34:	str	d1, [x26, w11, sxtw #3]
    1b38:	cbz	w27, 1b08 <__ieee754_rem_pio2+0x728>
    1b3c:	add	x11, x26, w9, sxtw #3
    1b40:	add	x12, sp, #0x28
    1b44:	mov	x13, x25
    1b48:	ldr	d1, [x12], #8
    1b4c:	subs	x13, x13, #0x1
    1b50:	ldr	d2, [x11], #-8
    1b54:	fmadd	d0, d1, d2, d0
    1b58:	b.ne	1b48 <__ieee754_rem_pio2+0x768>  // b.any
    1b5c:	b	1b08 <__ieee754_rem_pio2+0x728>
    1b60:	fmov	d0, d8
    1b64:	ldur	w9, [x29, #-52]
    1b68:	mov	w8, #0x18                  	// #24
    1b6c:	mov	w19, w13
    1b70:	sub	w0, w8, w9
    1b74:	bl	0 <scalbn>
    1b78:	mov	x8, #0x4170000000000000    	// #4715268809856909312
    1b7c:	fmov	d1, x8
    1b80:	fcmp	d0, d1
    1b84:	b.ge	1bc0 <__ieee754_rem_pio2+0x7e0>  // b.tcont
    1b88:	fcvtzs	w8, d0
    1b8c:	sub	x9, x29, #0x98
    1b90:	stur	w21, [x29, #-52]
    1b94:	str	w8, [x9, x28, lsl #2]
    1b98:	b	1bf4 <__ieee754_rem_pio2+0x814>
    1b9c:	fmov	d1, d5
    1ba0:	fsub	d1, d1, d3
    1ba4:	fsub	d0, d1, d0
    1ba8:	str	d0, [x1, #8]
    1bac:	tbz	x2, #63, 1e7c <__ieee754_rem_pio2+0xa9c>
    1bb0:	fneg	d1, d3
    1bb4:	fneg	d0, d0
    1bb8:	stp	d1, d0, [x1]
    1bbc:	b	1e78 <__ieee754_rem_pio2+0xa98>
    1bc0:	mov	x8, #0x3e70000000000000    	// #4499096027743125504
    1bc4:	mov	x9, #0xc170000000000000    	// #-4508103226997866496
    1bc8:	sub	x10, x29, #0x98
    1bcc:	fmov	d1, x8
    1bd0:	fmov	d2, x9
    1bd4:	fmul	d1, d0, d1
    1bd8:	fcvtzs	w8, d1
    1bdc:	scvtf	d1, w8
    1be0:	fmadd	d0, d1, d2, d0
    1be4:	fcvtzs	w9, d0
    1be8:	str	w9, [x10, x28, lsl #2]
    1bec:	add	w28, w28, #0x1
    1bf0:	str	w8, [x10, w28, uxtw #2]
    1bf4:	ldr	x20, [sp, #8]
    1bf8:	mov	w13, w19
    1bfc:	tbnz	w28, #31, 1d6c <__ieee754_rem_pio2+0x98c>
    1c00:	fmov	d0, #1.000000000000000000e+00
    1c04:	ldur	w0, [x29, #-52]
    1c08:	mov	w21, w13
    1c0c:	mov	w19, w28
    1c10:	bl	0 <scalbn>
    1c14:	mov	x10, #0x3e70000000000000    	// #4499096027743125504
    1c18:	sub	x8, x29, #0x98
    1c1c:	add	x9, sp, #0x40
    1c20:	fmov	d1, x10
    1c24:	mov	x10, x19
    1c28:	ldr	w11, [x8, x10, lsl #2]
    1c2c:	scvtf	d2, w11
    1c30:	fmul	d2, d0, d2
    1c34:	fmul	d0, d0, d1
    1c38:	str	d2, [x9, x10, lsl #3]
    1c3c:	sub	x10, x10, #0x1
    1c40:	cmn	x10, #0x1
    1c44:	b.ne	1c28 <__ieee754_rem_pio2+0x848>  // b.any
    1c48:	adrp	x11, 0 <pts_ieee754_acos>
    1c4c:	add	x10, sp, #0x40
    1c50:	movi	d1, #0x0
    1c54:	ldr	d0, [x11]
    1c58:	adrp	x11, 0 <pts_ieee754_acos>
    1c5c:	add	x10, x10, x19, lsl #3
    1c60:	ldr	d2, [x11]
    1c64:	adrp	x11, 0 <pts_ieee754_acos>
    1c68:	adrp	x12, 0 <pts_ieee754_acos>
    1c6c:	ldr	d3, [x11]
    1c70:	ldr	d4, [x12]
    1c74:	mov	x13, #0x442d00000000        	// #74960064217088
    1c78:	mov	x8, xzr
    1c7c:	add	x9, x19, #0x1
    1c80:	add	x10, x10, #0x10
    1c84:	mov	w11, #0x4                   	// #4
    1c88:	add	x12, sp, #0xe8
    1c8c:	movk	x13, #0x3e74, lsl #48
    1c90:	b	1ca8 <__ieee754_rem_pio2+0x8c8>
    1c94:	str	d5, [x12, x8, lsl #3]
    1c98:	add	x8, x8, #0x1
    1c9c:	sub	x10, x10, #0x8
    1ca0:	cmp	w9, w8
    1ca4:	b.eq	1d00 <__ieee754_rem_pio2+0x920>  // b.none
    1ca8:	ldur	d5, [x10, #-16]
    1cac:	cmp	w8, #0x4
    1cb0:	csel	w14, w8, w11, cc	// cc = lo, ul, last
    1cb4:	fmadd	d5, d5, d0, d1
    1cb8:	cbz	w8, 1c94 <__ieee754_rem_pio2+0x8b4>
    1cbc:	fmov	d7, x13
    1cc0:	ldur	d6, [x10, #-8]
    1cc4:	add	w14, w14, #0x1
    1cc8:	cmp	w14, #0x2
    1ccc:	fmadd	d5, d6, d7, d5
    1cd0:	b.eq	1c94 <__ieee754_rem_pio2+0x8b4>  // b.none
    1cd4:	ldr	d6, [x10]
    1cd8:	cmp	w14, #0x3
    1cdc:	fmadd	d5, d6, d2, d5
    1ce0:	b.eq	1c94 <__ieee754_rem_pio2+0x8b4>  // b.none
    1ce4:	ldr	d6, [x10, #8]
    1ce8:	cmp	w14, #0x4
    1cec:	fmadd	d5, d6, d3, d5
    1cf0:	b.eq	1c94 <__ieee754_rem_pio2+0x8b4>  // b.none
    1cf4:	ldr	d6, [x10, #16]
    1cf8:	fmadd	d5, d6, d4, d5
    1cfc:	b	1c94 <__ieee754_rem_pio2+0x8b4>
    1d00:	movi	d1, #0x0
    1d04:	cbz	w19, 1d90 <__ieee754_rem_pio2+0x9b0>
    1d08:	add	x9, x19, #0x1
    1d0c:	add	x8, sp, #0xe8
    1d10:	and	x10, x9, #0xfffffffe
    1d14:	add	x11, x8, x19, lsl #3
    1d18:	sub	x8, x19, x10
    1d1c:	mov	x12, x10
    1d20:	ldr	d0, [x11]
    1d24:	sub	x12, x12, #0x2
    1d28:	fadd	d0, d1, d0
    1d2c:	ldur	d1, [x11, #-8]
    1d30:	sub	x11, x11, #0x10
    1d34:	fadd	d1, d0, d1
    1d38:	cbnz	x12, 1d20 <__ieee754_rem_pio2+0x940>
    1d3c:	cmp	x9, x10
    1d40:	b.ne	1d94 <__ieee754_rem_pio2+0x9b4>  // b.any
    1d44:	b	1dac <__ieee754_rem_pio2+0x9cc>
    1d48:	sub	x8, x29, #0x98
    1d4c:	sub	x8, x8, #0x4
    1d50:	ldr	w9, [x8, x28, lsl #2]
    1d54:	sub	w21, w21, #0x18
    1d58:	sub	x28, x28, #0x1
    1d5c:	cbz	w9, 1d50 <__ieee754_rem_pio2+0x970>
    1d60:	ldr	x20, [sp, #8]
    1d64:	stur	w21, [x29, #-52]
    1d68:	tbz	w28, #31, 1c00 <__ieee754_rem_pio2+0x820>
    1d6c:	movi	d0, #0x0
    1d70:	mov	x8, #0x8000000000000000    	// #-9223372036854775808
    1d74:	cmp	w13, #0x0
    1d78:	fmov	d1, x8
    1d7c:	ldr	x12, [sp, #16]
    1d80:	cset	w8, eq	// eq = none
    1d84:	fcsel	d0, d0, d1, eq	// eq = none
    1d88:	str	d0, [x20]
    1d8c:	b	1e54 <__ieee754_rem_pio2+0xa74>
    1d90:	mov	x8, x19
    1d94:	add	x9, sp, #0xe8
    1d98:	ldr	d0, [x9, x8, lsl #3]
    1d9c:	sub	x8, x8, #0x1
    1da0:	cmn	x8, #0x1
    1da4:	fadd	d1, d1, d0
    1da8:	b.ne	1d98 <__ieee754_rem_pio2+0x9b8>  // b.any
    1dac:	fneg	d0, d1
    1db0:	ldr	d2, [sp, #232]
    1db4:	cmp	w21, #0x0
    1db8:	cset	w8, eq	// eq = none
    1dbc:	fcsel	d0, d1, d0, eq	// eq = none
    1dc0:	fsub	d1, d2, d1
    1dc4:	str	d0, [x20]
    1dc8:	cbz	w19, 1de4 <__ieee754_rem_pio2+0xa04>
    1dcc:	cmp	w19, #0x4
    1dd0:	add	w9, w19, #0x1
    1dd4:	b.cs	1dec <__ieee754_rem_pio2+0xa0c>  // b.hs, b.nlast
    1dd8:	ldr	x12, [sp, #16]
    1ddc:	mov	w10, #0x1                   	// #1
    1de0:	b	1e38 <__ieee754_rem_pio2+0xa58>
    1de4:	ldr	x12, [sp, #16]
    1de8:	b	1e54 <__ieee754_rem_pio2+0xa74>
    1dec:	sub	x11, x9, #0x1
    1df0:	add	x13, sp, #0xe8
    1df4:	and	x12, x11, #0xfffffffffffffffc
    1df8:	add	x13, x13, #0x18
    1dfc:	orr	x10, x12, #0x1
    1e00:	mov	x14, x12
    1e04:	ldp	q2, q3, [x13, #-16]
    1e08:	subs	x14, x14, #0x4
    1e0c:	add	x13, x13, #0x20
    1e10:	mov	d4, v2.d[1]
    1e14:	fadd	d1, d1, d2
    1e18:	mov	d2, v3.d[1]
    1e1c:	fadd	d1, d1, d4
    1e20:	fadd	d1, d1, d3
    1e24:	fadd	d1, d1, d2
    1e28:	b.ne	1e04 <__ieee754_rem_pio2+0xa24>  // b.any
    1e2c:	cmp	x11, x12
    1e30:	ldr	x12, [sp, #16]
    1e34:	b.eq	1e54 <__ieee754_rem_pio2+0xa74>  // b.none
    1e38:	add	x11, sp, #0xe8
    1e3c:	sub	x9, x9, x10
    1e40:	add	x11, x11, x10, lsl #3
    1e44:	ldr	d2, [x11], #8
    1e48:	subs	x9, x9, #0x1
    1e4c:	fadd	d1, d1, d2
    1e50:	b.ne	1e44 <__ieee754_rem_pio2+0xa64>  // b.any
    1e54:	fneg	d2, d1
    1e58:	cmp	w8, #0x0
    1e5c:	and	w0, w24, #0x7
    1e60:	fcsel	d1, d1, d2, ne	// ne = any
    1e64:	str	d1, [x20, #8]
    1e68:	tbz	x12, #63, 1e7c <__ieee754_rem_pio2+0xa9c>
    1e6c:	fneg	d0, d0
    1e70:	fneg	d1, d1
    1e74:	stp	d0, d1, [x20]
    1e78:	neg	w0, w0
    1e7c:	add	sp, sp, #0x280
    1e80:	ldp	x20, x19, [sp, #144]
    1e84:	ldp	x22, x21, [sp, #128]
    1e88:	ldp	x24, x23, [sp, #112]
    1e8c:	ldp	x26, x25, [sp, #96]
    1e90:	ldp	x28, x27, [sp, #80]
    1e94:	ldp	x29, x30, [sp, #64]
    1e98:	ldp	d9, d8, [sp, #48]
    1e9c:	ldp	d11, d10, [sp, #32]
    1ea0:	ldp	d13, d12, [sp, #16]
    1ea4:	ldr	d14, [sp], #160
    1ea8:	ret
    1eac:	nop
    1eb0:	nop
    1eb4:	nop
    1eb8:	nop
    1ebc:	nop

0000000000001ec0 <pts_ieee754_exp>:
    1ec0:	fmov	x9, d0
    1ec4:	mov	w11, #0x2e42                	// #11842
    1ec8:	movk	w11, #0x4086, lsl #16
    1ecc:	ubfx	x10, x9, #32, #31
    1ed0:	lsr	x8, x9, #63
    1ed4:	cmp	w10, w11
    1ed8:	b.cc	1f10 <pts_ieee754_exp+0x50>  // b.lo, b.ul, b.last
    1edc:	lsr	w10, w10, #20
    1ee0:	cmp	w10, #0x7ff
    1ee4:	b.cc	1f48 <pts_ieee754_exp+0x88>  // b.lo, b.ul, b.last
    1ee8:	movi	d1, #0x0
    1eec:	lsr	x8, x9, #32
    1ef0:	cmp	x9, #0x0
    1ef4:	fadd	d2, d0, d0
    1ef8:	and	w8, w8, #0xfffff
    1efc:	orr	w8, w8, w9
    1f00:	fcsel	d0, d0, d1, ge	// ge = tcont
    1f04:	cmp	w8, #0x0
    1f08:	fcsel	d0, d0, d2, eq	// eq = none
    1f0c:	ret
    1f10:	mov	w9, #0x2e43                	// #11843
    1f14:	movk	w9, #0x3fd6, lsl #16
    1f18:	cmp	w10, w9
    1f1c:	b.cc	1f6c <pts_ieee754_exp+0xac>  // b.lo, b.ul, b.last
    1f20:	mov	w9, #0xa2b1                	// #41649
    1f24:	movk	w9, #0x3ff0, lsl #16
    1f28:	cmp	w10, w9
    1f2c:	b.hi	1fd0 <pts_ieee754_exp+0x110>  // b.pmore
    1f30:	fmov	d1, #1.000000000000000000e+00
    1f34:	fcmp	d0, d1
    1f38:	b.ne	20e0 <pts_ieee754_exp+0x220>  // b.any
    1f3c:	adrp	x8, 0 <pts_ieee754_acos>
    1f40:	ldr	d0, [x8]
    1f44:	ret
    1f48:	adrp	x9, 0 <pts_ieee754_acos>
    1f4c:	ldr	d1, [x9]
    1f50:	fcmp	d0, d1
    1f54:	b.le	1fb4 <pts_ieee754_exp+0xf4>
    1f58:	adrp	x8, 0 <pts_ieee754_acos>
    1f5c:	ldr	d0, [x8]
    1f60:	ldr	d1, [x8]
    1f64:	fmul	d0, d0, d1
    1f68:	ret
    1f6c:	lsr	w8, w10, #20
    1f70:	cmp	w8, #0x3e2
    1f74:	b.hi	1f98 <pts_ieee754_exp+0xd8>  // b.pmore
    1f78:	adrp	x8, 0 <pts_ieee754_acos>
    1f7c:	ldr	d1, [x8]
    1f80:	fadd	d2, d1, d0
    1f84:	fmov	d1, #1.000000000000000000e+00
    1f88:	fcmp	d2, d1
    1f8c:	b.le	1f98 <pts_ieee754_exp+0xd8>
    1f90:	fadd	d0, d0, d1
    1f94:	ret
    1f98:	fmul	d3, d0, d0
    1f9c:	movi	d1, #0x0
    1fa0:	movi	d2, #0x0
    1fa4:	mov	w8, wzr
    1fa8:	mov	w9, #0x1                   	// #1
    1fac:	mov	w10, #0x3ff00000            	// #1072693248
    1fb0:	b	2024 <pts_ieee754_exp+0x164>
    1fb4:	adrp	x9, 0 <pts_ieee754_acos>
    1fb8:	ldr	d1, [x9]
    1fbc:	fcmp	d0, d1
    1fc0:	b.pl	1fd0 <pts_ieee754_exp+0x110>  // b.nfrst
    1fc4:	adrp	x8, 0 <pts_ieee754_acos>
    1fc8:	ldr	d0, [x8]
    1fcc:	b	20d4 <pts_ieee754_exp+0x214>
    1fd0:	adrp	x9, 0 <pts_ieee754_acos>
    1fd4:	add	x9, x9, #0x0
    1fd8:	adrp	x10, 0 <pts_ieee754_acos>
    1fdc:	ldr	d1, [x9, w8, uxtw #3]
    1fe0:	ldr	d2, [x10]
    1fe4:	adrp	x9, 0 <pts_ieee754_acos>
    1fe8:	adrp	x10, 0 <pts_ieee754_acos>
    1fec:	mov	w11, #0x3ff00000            	// #1072693248
    1ff0:	fmadd	d1, d0, d2, d1
    1ff4:	ldr	d3, [x10]
    1ff8:	mov	w10, #0x7e700000            	// #2121269248
    1ffc:	fcvtzs	w8, d1
    2000:	ldr	d1, [x9]
    2004:	scvtf	d2, w8
    2008:	cmn	w8, #0x3fe
    200c:	cset	w9, gt
    2010:	csel	w10, w11, w10, gt
    2014:	fmadd	d1, d2, d1, d0
    2018:	fmul	d2, d2, d3
    201c:	fsub	d0, d1, d2
    2020:	fmul	d3, d0, d0
    2024:	adrp	x11, 0 <pts_ieee754_acos>
    2028:	adrp	x12, 0 <pts_ieee754_acos>
    202c:	ldr	d4, [x11]
    2030:	ldr	d5, [x12]
    2034:	adrp	x11, 0 <pts_ieee754_acos>
    2038:	fmadd	d4, d3, d5, d4
    203c:	ldr	d5, [x11]
    2040:	adrp	x11, 0 <pts_ieee754_acos>
    2044:	fmadd	d4, d3, d4, d5
    2048:	ldr	d5, [x11]
    204c:	adrp	x11, 0 <pts_ieee754_acos>
    2050:	fmadd	d4, d3, d4, d5
    2054:	ldr	d5, [x11]
    2058:	fmadd	d4, d3, d4, d5
    205c:	fmsub	d4, d3, d4, d0
    2060:	fmul	d3, d0, d4
    2064:	cbz	w8, 20b0 <pts_ieee754_exp+0x1f0>
    2068:	fmov	d0, #2.000000000000000000e+00
    206c:	add	w10, w10, w8, lsl #20
    2070:	lsl	x10, x10, #32
    2074:	fsub	d0, d0, d4
    2078:	fdiv	d0, d3, d0
    207c:	fsub	d0, d2, d0
    2080:	fsub	d0, d1, d0
    2084:	fmov	d1, #1.000000000000000000e+00
    2088:	fadd	d0, d0, d1
    208c:	fmov	d1, x10
    2090:	cbz	w9, 20cc <pts_ieee754_exp+0x20c>
    2094:	cmp	w8, #0x400
    2098:	b.ne	20d8 <pts_ieee754_exp+0x218>  // b.any
    209c:	fadd	d0, d0, d0
    20a0:	adrp	x8, 0 <pts_ieee754_acos>
    20a4:	ldr	d1, [x8]
    20a8:	fmul	d0, d0, d1
    20ac:	ret
    20b0:	fmov	d1, #-2.000000000000000000e+00
    20b4:	fadd	d1, d4, d1
    20b8:	fdiv	d1, d3, d1
    20bc:	fsub	d0, d0, d1
    20c0:	fmov	d1, #1.000000000000000000e+00
    20c4:	fadd	d0, d0, d1
    20c8:	ret
    20cc:	fmul	d0, d0, d1
    20d0:	adrp	x8, 0 <pts_ieee754_acos>
    20d4:	ldr	d1, [x8]
    20d8:	fmul	d0, d0, d1
    20dc:	ret
    20e0:	mov	w9, w8
    20e4:	adrp	x10, 0 <pts_ieee754_acos>
    20e8:	add	x10, x10, #0x0
    20ec:	ubfiz	x9, x9, #3, #32
    20f0:	ldr	d1, [x10, x9]
    20f4:	adrp	x10, 0 <pts_ieee754_acos>
    20f8:	add	x10, x10, #0x0
    20fc:	ldr	d2, [x10, x9]
    2100:	eor	w9, w8, #0x1
    2104:	fsub	d1, d0, d1
    2108:	sub	w8, w9, w8
    210c:	fsub	d0, d1, d2
    2110:	fmul	d3, d0, d0
    2114:	b	1fa8 <pts_ieee754_exp+0xe8>
    2118:	nop
    211c:	nop

0000000000002120 <pts_ieee754_atanh>:
    2120:	stp	x29, x30, [sp, #-32]!
    2124:	str	x19, [sp, #16]
    2128:	mov	x29, sp
    212c:	fmov	x19, d0
    2130:	mov	w9, #0x3ff00000            	// #1072693248
    2134:	ubfx	x8, x19, #32, #31
    2138:	cmp	w19, #0x0
    213c:	cset	w10, ne	// ne = any
    2140:	orr	w10, w8, w10
    2144:	cmp	w10, w9
    2148:	b.ls	2158 <pts_ieee754_atanh+0x38>  // b.plast
    214c:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2150:	fmov	d0, x8
    2154:	b	21e8 <pts_ieee754_atanh+0xc8>
    2158:	cmp	w8, w9
    215c:	b.ne	217c <pts_ieee754_atanh+0x5c>  // b.any
    2160:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2164:	mov	x9, #0x7ff0000000000000    	// #9218868437227405312
    2168:	fcmp	d0, #0.0
    216c:	fmov	d0, x8
    2170:	fmov	d1, x9
    2174:	fcsel	d0, d1, d0, gt
    2178:	b	21e8 <pts_ieee754_atanh+0xc8>
    217c:	adrp	x9, 0 <pts_ieee754_acos>
    2180:	ldr	d1, [x9]
    2184:	fadd	d1, d0, d1
    2188:	fcmp	d1, #0.0
    218c:	b.le	219c <pts_ieee754_atanh+0x7c>
    2190:	lsr	w9, w8, #20
    2194:	cmp	w9, #0x3e3
    2198:	b.cc	21e8 <pts_ieee754_atanh+0xc8>  // b.lo, b.ul, b.last
    219c:	fabs	d1, d0
    21a0:	lsr	w8, w8, #21
    21a4:	fmov	d2, #1.000000000000000000e+00
    21a8:	cmp	w8, #0x1fe
    21ac:	fadd	d0, d1, d1
    21b0:	b.hi	21c8 <pts_ieee754_atanh+0xa8>  // b.pmore
    21b4:	fmul	d3, d1, d0
    21b8:	fsub	d1, d2, d1
    21bc:	fdiv	d1, d3, d1
    21c0:	fadd	d0, d0, d1
    21c4:	b	21d0 <pts_ieee754_atanh+0xb0>
    21c8:	fsub	d1, d2, d1
    21cc:	fdiv	d0, d0, d1
    21d0:	bl	580 <pts_ieee754_log1p>
    21d4:	fmov	d1, #5.000000000000000000e-01
    21d8:	cmp	x19, #0x0
    21dc:	fmul	d2, d0, d1
    21e0:	fnmul	d0, d0, d1
    21e4:	fcsel	d0, d0, d2, lt	// lt = tstop
    21e8:	ldr	x19, [sp, #16]
    21ec:	ldp	x29, x30, [sp], #32
    21f0:	ret
    21f4:	nop
    21f8:	nop
    21fc:	nop

0000000000002200 <pts_ieee754_log2>:
    2200:	fmov	x10, d0
    2204:	lsr	x8, x10, #32
    2208:	cmp	w8, #0x100, lsl #12
    220c:	b.ge	223c <pts_ieee754_log2+0x3c>  // b.tcont
    2210:	and	w8, w8, #0x7fffffff
    2214:	orr	w8, w8, w10
    2218:	cbz	w8, 2274 <pts_ieee754_log2+0x74>
    221c:	tbnz	x10, #63, 2388 <pts_ieee754_log2+0x188>
    2220:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    2224:	mov	w9, #0xffffffca            	// #-54
    2228:	fmov	d1, x8
    222c:	fmul	d0, d0, d1
    2230:	fmov	x8, d0
    2234:	lsr	x8, x8, #32
    2238:	b	2240 <pts_ieee754_log2+0x40>
    223c:	mov	w9, wzr
    2240:	mov	w11, #0x7ff00000            	// #2146435072
    2244:	cmp	w8, w11
    2248:	b.lt	2258 <pts_ieee754_log2+0x58>  // b.tstop
    224c:	fadd	d1, d0, d0
    2250:	fmov	d0, d1
    2254:	ret
    2258:	cbnz	w10, 227c <pts_ieee754_log2+0x7c>
    225c:	movi	d1, #0x0
    2260:	mov	w10, #0x3ff00000            	// #1072693248
    2264:	cmp	w8, w10
    2268:	b.ne	227c <pts_ieee754_log2+0x7c>  // b.any
    226c:	fmov	d0, d1
    2270:	ret
    2274:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2278:	b	238c <pts_ieee754_log2+0x18c>
    227c:	and	w10, w8, #0xfffff
    2280:	fmov	x12, d0
    2284:	fmov	d0, #-1.000000000000000000e+00
    2288:	add	w10, w10, #0x95, lsl #12
    228c:	fmov	d6, #-5.000000000000000000e-01
    2290:	adrp	x13, 0 <pts_ieee754_acos>
    2294:	add	w10, w10, #0xf64
    2298:	ldr	d16, [x13]
    229c:	and	w11, w10, #0x100000
    22a0:	and	x12, x12, #0xffffffff
    22a4:	bfxil	w11, w8, #0, #20
    22a8:	add	w8, w9, w8, asr #20
    22ac:	eor	w11, w11, #0x3ff00000
    22b0:	add	w8, w8, w10, lsr #20
    22b4:	orr	x11, x12, x11, lsl #32
    22b8:	adrp	x12, 0 <pts_ieee754_acos>
    22bc:	ldr	d5, [x12]
    22c0:	adrp	x12, 0 <pts_ieee754_acos>
    22c4:	sub	w8, w8, #0x3ff
    22c8:	fmov	d1, x11
    22cc:	adrp	x11, 0 <pts_ieee754_acos>
    22d0:	ldr	d7, [x12]
    22d4:	ldr	d4, [x11]
    22d8:	adrp	x11, 0 <pts_ieee754_acos>
    22dc:	fadd	d0, d1, d0
    22e0:	fmov	d1, #2.000000000000000000e+00
    22e4:	fadd	d1, d0, d1
    22e8:	fdiv	d1, d0, d1
    22ec:	fmul	d2, d1, d1
    22f0:	fmul	d3, d2, d2
    22f4:	fmadd	d4, d3, d5, d4
    22f8:	ldr	d5, [x11]
    22fc:	adrp	x11, 0 <pts_ieee754_acos>
    2300:	fmadd	d4, d3, d4, d5
    2304:	fmul	d5, d0, d6
    2308:	ldr	d6, [x11]
    230c:	adrp	x11, 0 <pts_ieee754_acos>
    2310:	fmadd	d6, d3, d7, d6
    2314:	fmadd	d7, d5, d0, d0
    2318:	fmadd	d4, d3, d4, d16
    231c:	ldr	d16, [x11]
    2320:	fmadd	d6, d3, d6, d16
    2324:	fmov	x11, d7
    2328:	fmul	d2, d2, d4
    232c:	fmov	d4, #5.000000000000000000e-01
    2330:	and	x11, x11, #0xffffffff00000000
    2334:	fmov	d7, x11
    2338:	fmadd	d2, d3, d6, d2
    233c:	fmul	d3, d0, d4
    2340:	scvtf	d6, w8
    2344:	adrp	x8, 0 <pts_ieee754_acos>
    2348:	fsub	d4, d0, d7
    234c:	fmadd	d2, d3, d0, d2
    2350:	ldr	d3, [x8]
    2354:	adrp	x8, 0 <pts_ieee754_acos>
    2358:	fmadd	d0, d5, d0, d4
    235c:	ldr	d5, [x8]
    2360:	fmadd	d0, d1, d2, d0
    2364:	fmadd	d1, d7, d3, d6
    2368:	fadd	d2, d0, d7
    236c:	fmul	d0, d0, d3
    2370:	fsub	d4, d6, d1
    2374:	fmadd	d0, d2, d5, d0
    2378:	fmadd	d2, d7, d3, d4
    237c:	fadd	d0, d2, d0
    2380:	fadd	d0, d1, d0
    2384:	ret
    2388:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    238c:	fmov	d1, x8
    2390:	fmov	d0, d1
    2394:	ret
    2398:	nop
    239c:	nop

00000000000023a0 <pts_ieee754_log10>:
    23a0:	fmov	x8, d0
    23a4:	lsr	x9, x8, #32
    23a8:	cmp	w9, #0x100, lsl #12
    23ac:	b.ge	23dc <pts_ieee754_log10+0x3c>  // b.tcont
    23b0:	and	w9, w9, #0x7fffffff
    23b4:	orr	w9, w9, w8
    23b8:	cbz	w9, 240c <pts_ieee754_log10+0x6c>
    23bc:	tbnz	x8, #63, 2484 <pts_ieee754_log10+0xe4>
    23c0:	mov	x8, #0x4350000000000000    	// #4850376798678024192
    23c4:	mov	w10, #0xffffffca            	// #-54
    23c8:	fmov	d1, x8
    23cc:	fmul	d0, d0, d1
    23d0:	fmov	x8, d0
    23d4:	lsr	x9, x8, #32
    23d8:	b	23e0 <pts_ieee754_log10+0x40>
    23dc:	mov	w10, wzr
    23e0:	mov	w11, #0x7ff00000            	// #2146435072
    23e4:	cmp	w9, w11
    23e8:	b.lt	23f4 <pts_ieee754_log10+0x54>  // b.tstop
    23ec:	fadd	d0, d0, d0
    23f0:	ret
    23f4:	cbnz	w8, 2418 <pts_ieee754_log10+0x78>
    23f8:	movi	d0, #0x0
    23fc:	mov	w11, #0x3ff00000            	// #1072693248
    2400:	cmp	w9, w11
    2404:	b.ne	2418 <pts_ieee754_log10+0x78>  // b.any
    2408:	ret
    240c:	mov	x8, #0xfff0000000000000    	// #-4503599627370496
    2410:	fmov	d0, x8
    2414:	ret
    2418:	str	d8, [sp, #-32]!
    241c:	stp	x29, x30, [sp, #16]
    2420:	add	x29, sp, #0x10
    2424:	add	w10, w10, w9, asr #20
    2428:	and	w9, w9, #0xfffff
    242c:	mov	w8, w8
    2430:	sub	w10, w10, #0x3ff
    2434:	lsr	w11, w10, #31
    2438:	orr	w9, w9, w11, lsl #20
    243c:	add	w10, w11, w10
    2440:	scvtf	d8, w10
    2444:	eor	w9, w9, #0x3ff00000
    2448:	orr	x8, x8, x9, lsl #32
    244c:	fmov	d0, x8
    2450:	bl	360 <pts_ieee754_log>
    2454:	adrp	x8, 0 <pts_ieee754_acos>
    2458:	ldr	d1, [x8]
    245c:	adrp	x8, 0 <pts_ieee754_acos>
    2460:	fmul	d0, d0, d1
    2464:	ldr	d1, [x8]
    2468:	adrp	x8, 0 <pts_ieee754_acos>
    246c:	fmadd	d0, d8, d1, d0
    2470:	ldr	d1, [x8]
    2474:	fmadd	d0, d8, d1, d0
    2478:	ldp	x29, x30, [sp, #16]
    247c:	ldr	d8, [sp], #32
    2480:	ret
    2484:	mov	x8, #0x7ff8000000000000    	// #9221120237041090560
    2488:	fmov	d0, x8
    248c:	ret
    2490:	nop
    2494:	nop
    2498:	nop
    249c:	nop

00000000000024a0 <pts_ieee754_expm1>:
    24a0:	fmov	x9, d0
    24a4:	mov	w11, #0x687a                	// #26746
    24a8:	movk	w11, #0x4043, lsl #16
    24ac:	ubfx	x10, x9, #32, #31
    24b0:	lsr	x8, x9, #32
    24b4:	cmp	w10, w11
    24b8:	b.cc	24fc <pts_ieee754_expm1+0x5c>  // b.lo, b.ul, b.last
    24bc:	mov	w11, #0x2e42                	// #11842
    24c0:	movk	w11, #0x4086, lsl #16
    24c4:	cmp	w10, w11
    24c8:	b.cc	258c <pts_ieee754_expm1+0xec>  // b.lo, b.ul, b.last
    24cc:	lsr	w10, w10, #20
    24d0:	cmp	w10, #0x7ff
    24d4:	b.cc	2568 <pts_ieee754_expm1+0xc8>  // b.lo, b.ul, b.last
    24d8:	fmov	d1, #-1.000000000000000000e+00
    24dc:	tst	w8, #0x80000000
    24e0:	fadd	d2, d0, d0
    24e4:	and	w8, w8, #0xfffff
    24e8:	orr	w8, w8, w9
    24ec:	fcsel	d0, d0, d1, eq	// eq = none
    24f0:	cmp	w8, #0x0
    24f4:	fcsel	d0, d0, d2, eq	// eq = none
    24f8:	ret
    24fc:	mov	w9, #0x2e43                	// #11843
    2500:	movk	w9, #0x3fd6, lsl #16
    2504:	cmp	w10, w9
    2508:	b.cc	253c <pts_ieee754_expm1+0x9c>  // b.lo, b.ul, b.last
    250c:	mov	w9, #0xa2b1                	// #41649
    2510:	movk	w9, #0x3ff0, lsl #16
    2514:	cmp	w10, w9
    2518:	b.hi	25ac <pts_ieee754_expm1+0x10c>  // b.pmore
    251c:	tbnz	w8, #31, 2718 <pts_ieee754_expm1+0x278>
    2520:	adrp	x8, 0 <pts_ieee754_acos>
    2524:	ldr	d1, [x8]
    2528:	adrp	x8, 0 <pts_ieee754_acos>
    252c:	ldr	d2, [x8]
    2530:	mov	w8, #0x1                   	// #1
    2534:	fadd	d1, d0, d1
    2538:	b	25ec <pts_ieee754_expm1+0x14c>
    253c:	lsr	w8, w10, #20
    2540:	cmp	w8, #0x3c8
    2544:	b.hi	25fc <pts_ieee754_expm1+0x15c>  // b.pmore
    2548:	adrp	x8, 0 <pts_ieee754_acos>
    254c:	ldr	d1, [x8]
    2550:	ldr	d2, [x8]
    2554:	fadd	d1, d1, d0
    2558:	fadd	d2, d2, d0
    255c:	fsub	d1, d1, d2
    2560:	fsub	d0, d0, d1
    2564:	ret
    2568:	adrp	x9, 0 <pts_ieee754_acos>
    256c:	ldr	d1, [x9]
    2570:	fcmp	d0, d1
    2574:	b.le	258c <pts_ieee754_expm1+0xec>
    2578:	adrp	x8, 0 <pts_ieee754_acos>
    257c:	ldr	d0, [x8]
    2580:	ldr	d1, [x8]
    2584:	fmul	d0, d0, d1
    2588:	ret
    258c:	adrp	x9, 0 <pts_ieee754_acos>
    2590:	ldr	d1, [x9]
    2594:	and	w9, w8, #0x80000000
    2598:	fadd	d1, d0, d1
    259c:	fcmp	d1, #0.0
    25a0:	fmov	d1, #-1.000000000000000000e+00
    25a4:	ccmp	w9, #0x0, #0x4, mi	// mi = first
    25a8:	b.ne	2794 <pts_ieee754_expm1+0x2f4>  // b.any
    25ac:	adrp	x9, 0 <pts_ieee754_acos>
    25b0:	fmov	d1, #-5.000000000000000000e-01
    25b4:	fmov	d2, #5.000000000000000000e-01
    25b8:	ldr	d3, [x9]
    25bc:	tst	w8, #0x80000000
    25c0:	adrp	x9, 0 <pts_ieee754_acos>
    25c4:	adrp	x10, 0 <pts_ieee754_acos>
    25c8:	fmul	d3, d0, d3
    25cc:	fcsel	d1, d2, d1, eq	// eq = none
    25d0:	fadd	d1, d3, d1
    25d4:	ldr	d3, [x10]
    25d8:	fcvtzs	w8, d1
    25dc:	ldr	d1, [x9]
    25e0:	scvtf	d2, w8
    25e4:	fmadd	d1, d2, d1, d0
    25e8:	fmul	d2, d2, d3
    25ec:	fsub	d0, d1, d2
    25f0:	fsub	d1, d1, d0
    25f4:	fsub	d1, d1, d2
    25f8:	b	2600 <pts_ieee754_expm1+0x160>
    25fc:	mov	w8, wzr
    2600:	fmov	d2, #5.000000000000000000e-01
    2604:	adrp	x9, 0 <pts_ieee754_acos>
    2608:	adrp	x10, 0 <pts_ieee754_acos>
    260c:	ldr	d4, [x9]
    2610:	ldr	d5, [x10]
    2614:	adrp	x9, 0 <pts_ieee754_acos>
    2618:	fmul	d3, d0, d2
    261c:	fmul	d2, d0, d3
    2620:	fmadd	d4, d2, d5, d4
    2624:	ldr	d5, [x9]
    2628:	adrp	x9, 0 <pts_ieee754_acos>
    262c:	fmadd	d4, d2, d4, d5
    2630:	ldr	d5, [x9]
    2634:	adrp	x9, 0 <pts_ieee754_acos>
    2638:	fmadd	d4, d2, d4, d5
    263c:	ldr	d5, [x9]
    2640:	fmadd	d4, d2, d4, d5
    2644:	fmov	d5, #1.000000000000000000e+00
    2648:	fmadd	d4, d2, d4, d5
    264c:	fmov	d5, #3.000000000000000000e+00
    2650:	fmsub	d3, d4, d3, d5
    2654:	fmov	d5, #6.000000000000000000e+00
    2658:	fsub	d4, d4, d3
    265c:	fmsub	d3, d0, d3, d5
    2660:	fdiv	d3, d4, d3
    2664:	fmul	d3, d2, d3
    2668:	cbz	w8, 269c <pts_ieee754_expm1+0x1fc>
    266c:	fsub	d3, d3, d1
    2670:	cmp	w8, #0x1
    2674:	fnmsub	d1, d0, d3, d1
    2678:	fsub	d1, d1, d2
    267c:	b.eq	26a8 <pts_ieee754_expm1+0x208>  // b.none
    2680:	cmn	w8, #0x1
    2684:	b.ne	26cc <pts_ieee754_expm1+0x22c>  // b.any
    2688:	fsub	d0, d0, d1
    268c:	fmov	d1, #-5.000000000000000000e-01
    2690:	fmov	d2, #5.000000000000000000e-01
    2694:	fmadd	d0, d0, d2, d1
    2698:	ret
    269c:	fnmsub	d1, d0, d3, d2
    26a0:	fsub	d0, d0, d1
    26a4:	ret
    26a8:	fmov	d2, #-2.500000000000000000e-01
    26ac:	fcmp	d0, d2
    26b0:	b.pl	2734 <pts_ieee754_expm1+0x294>  // b.nfrst
    26b4:	fmov	d2, #5.000000000000000000e-01
    26b8:	fadd	d0, d0, d2
    26bc:	fsub	d0, d1, d0
    26c0:	fmov	d1, #-2.000000000000000000e+00
    26c4:	fmul	d0, d0, d1
    26c8:	ret
    26cc:	mov	x9, #0x3ff0000000000000    	// #4607182418800017408
    26d0:	sub	w10, w8, #0x39
    26d4:	add	x9, x9, x8, lsl #52
    26d8:	cmn	w10, #0x3b
    26dc:	fmov	d2, x9
    26e0:	b.hi	2748 <pts_ieee754_expm1+0x2a8>  // b.pmore
    26e4:	fsub	d0, d0, d1
    26e8:	fmov	d1, #1.000000000000000000e+00
    26ec:	mov	x9, #0x7fe0000000000000    	// #9214364837600034816
    26f0:	fmov	d3, x9
    26f4:	cmp	w8, #0x400
    26f8:	fadd	d0, d0, d1
    26fc:	fadd	d1, d0, d0
    2700:	fmul	d0, d0, d2
    2704:	fmul	d1, d1, d3
    2708:	fcsel	d0, d1, d0, eq	// eq = none
    270c:	fmov	d1, #-1.000000000000000000e+00
    2710:	fadd	d0, d0, d1
    2714:	ret
    2718:	adrp	x8, 0 <pts_ieee754_acos>
    271c:	ldr	d1, [x8]
    2720:	adrp	x8, 0 <pts_ieee754_acos>
    2724:	ldr	d2, [x8]
    2728:	mov	w8, #0xffffffff            	// #-1
    272c:	fadd	d1, d0, d1
    2730:	b	25ec <pts_ieee754_expm1+0x14c>
    2734:	fsub	d0, d0, d1
    2738:	fmov	d1, #1.000000000000000000e+00
    273c:	fmov	d2, #2.000000000000000000e+00
    2740:	fmadd	d0, d0, d2, d1
    2744:	ret
    2748:	lsl	w9, w8, #20
    274c:	mov	w10, #0x3ff00000            	// #1072693248
    2750:	cmp	w8, #0x13
    2754:	sub	w9, w10, w9
    2758:	lsl	x9, x9, #32
    275c:	fmov	d3, x9
    2760:	mov	w9, #0x200000              	// #2097152
    2764:	lsr	w9, w9, w8
    2768:	fadd	d3, d1, d3
    276c:	sub	w9, w10, w9
    2770:	lsl	x9, x9, #32
    2774:	fmov	d4, x9
    2778:	fsub	d3, d0, d3
    277c:	fsub	d0, d1, d0
    2780:	fmov	d1, #1.000000000000000000e+00
    2784:	fadd	d1, d3, d1
    2788:	fsub	d0, d4, d0
    278c:	fcsel	d0, d1, d0, hi	// hi = pmore
    2790:	fmul	d1, d0, d2
    2794:	fmov	d0, d1
    2798:	ret
    279c:	nop

00000000000027a0 <pts_ieee754_cbrt>:
    27a0:	fmov	x10, d0
    27a4:	lsr	x8, x10, #32
    27a8:	ubfx	w9, w8, #20, #11
    27ac:	cmp	w9, #0x7ff
    27b0:	b.cc	27bc <pts_ieee754_cbrt+0x1c>  // b.lo, b.ul, b.last
    27b4:	fadd	d0, d0, d0
    27b8:	ret
    27bc:	ubfx	x9, x10, #32, #31
    27c0:	lsr	w11, w9, #20
    27c4:	cbnz	w11, 27f0 <pts_ieee754_cbrt+0x50>
    27c8:	orr	w9, w9, w10
    27cc:	cbz	w9, 289c <pts_ieee754_cbrt+0xfc>
    27d0:	mov	x9, #0x4350000000000000    	// #4850376798678024192
    27d4:	mov	w10, #0x7893                	// #30867
    27d8:	fmov	d1, x9
    27dc:	movk	w10, #0x297f, lsl #16
    27e0:	fmul	d1, d0, d1
    27e4:	fmov	x9, d1
    27e8:	ubfx	x9, x9, #32, #31
    27ec:	b	27f8 <pts_ieee754_cbrt+0x58>
    27f0:	mov	w10, #0x7893                	// #30867
    27f4:	movk	w10, #0x2a9f, lsl #16
    27f8:	mov	w11, #0x5556                	// #21846
    27fc:	and	w8, w8, #0x80000000
    2800:	movk	w11, #0x5555, lsl #16
    2804:	umull	x9, w9, w11
    2808:	lsr	x9, x9, #32
    280c:	add	w9, w9, w10
    2810:	orr	w8, w9, w8
    2814:	adrp	x9, 0 <pts_ieee754_acos>
    2818:	lsl	x8, x8, #32
    281c:	ldr	d4, [x9]
    2820:	adrp	x9, 0 <pts_ieee754_acos>
    2824:	ldr	d6, [x9]
    2828:	mov	w9, #0x80000000            	// #-2147483648
    282c:	fmov	d1, x8
    2830:	adrp	x8, 0 <pts_ieee754_acos>
    2834:	fdiv	d2, d1, d0
    2838:	fmul	d3, d1, d1
    283c:	fmul	d2, d3, d2
    2840:	ldr	d3, [x8]
    2844:	adrp	x8, 0 <pts_ieee754_acos>
    2848:	fmul	d5, d2, d2
    284c:	fmadd	d3, d2, d4, d3
    2850:	ldr	d4, [x8]
    2854:	adrp	x8, 0 <pts_ieee754_acos>
    2858:	ldr	d7, [x8]
    285c:	fmadd	d4, d2, d6, d4
    2860:	fmul	d5, d2, d5
    2864:	fmadd	d2, d2, d3, d7
    2868:	fmadd	d2, d5, d4, d2
    286c:	fmul	d1, d2, d1
    2870:	fmov	x8, d1
    2874:	and	x8, x8, #0xffffffffc0000000
    2878:	add	x8, x8, x9
    287c:	fmov	d1, x8
    2880:	fmul	d2, d1, d1
    2884:	fdiv	d0, d0, d2
    2888:	fmov	d2, #2.000000000000000000e+00
    288c:	fsub	d3, d0, d1
    2890:	fmadd	d0, d1, d2, d0
    2894:	fdiv	d0, d3, d0
    2898:	fmadd	d0, d1, d0, d1
    289c:	ret

00000000000028a0 <pts_ieee754_sin>:
    28a0:	sub	sp, sp, #0x20
    28a4:	stp	x29, x30, [sp, #16]
    28a8:	add	x29, sp, #0x10
    28ac:	fmov	x8, d0
    28b0:	mov	w10, #0x21fb                	// #8699
    28b4:	movk	w10, #0x3fe9, lsl #16
    28b8:	ubfx	x9, x8, #32, #31
    28bc:	cmp	w9, w10
    28c0:	b.hi	292c <pts_ieee754_sin+0x8c>  // b.pmore
    28c4:	ubfx	x8, x8, #54, #9
    28c8:	cmp	x8, #0xf8
    28cc:	b.hi	28d8 <pts_ieee754_sin+0x38>  // b.pmore
    28d0:	fcvtzs	w8, d0
    28d4:	cbz	w8, 293c <pts_ieee754_sin+0x9c>
    28d8:	fmul	d1, d0, d0
    28dc:	adrp	x8, 0 <pts_ieee754_acos>
    28e0:	adrp	x9, 0 <pts_ieee754_acos>
    28e4:	ldr	d2, [x8]
    28e8:	ldr	d3, [x9]
    28ec:	adrp	x8, 0 <pts_ieee754_acos>
    28f0:	fmadd	d2, d1, d3, d2
    28f4:	ldr	d3, [x8]
    28f8:	adrp	x8, 0 <pts_ieee754_acos>
    28fc:	fmul	d4, d1, d0
    2900:	fmadd	d2, d1, d2, d3
    2904:	ldr	d3, [x8]
    2908:	adrp	x8, 0 <pts_ieee754_acos>
    290c:	fmadd	d2, d1, d2, d3
    2910:	ldr	d3, [x8]
    2914:	adrp	x8, 0 <pts_ieee754_acos>
    2918:	fmadd	d2, d1, d2, d3
    291c:	ldr	d3, [x8]
    2920:	fmadd	d1, d1, d2, d3
    2924:	fmadd	d0, d4, d1, d0
    2928:	b	293c <pts_ieee754_sin+0x9c>
    292c:	lsr	w8, w9, #20
    2930:	cmp	w8, #0x7ff
    2934:	b.cc	2948 <pts_ieee754_sin+0xa8>  // b.lo, b.ul, b.last
    2938:	fsub	d0, d0, d0
    293c:	ldp	x29, x30, [sp, #16]
    2940:	add	sp, sp, #0x20
    2944:	ret
    2948:	mov	x0, sp
    294c:	bl	13e0 <__ieee754_rem_pio2>
    2950:	ldr	d1, [sp]
    2954:	and	w8, w0, #0x3
    2958:	cmp	w8, #0x2
    295c:	b.eq	2a2c <pts_ieee754_sin+0x18c>  // b.none
    2960:	cmp	w8, #0x1
    2964:	b.eq	298c <pts_ieee754_sin+0xec>  // b.none
    2968:	cbnz	w8, 2ab0 <pts_ieee754_sin+0x210>
    296c:	fmov	x8, d1
    2970:	ubfx	x8, x8, #54, #9
    2974:	cmp	x8, #0xf8
    2978:	b.hi	2b50 <pts_ieee754_sin+0x2b0>  // b.pmore
    297c:	fcvtzs	w8, d1
    2980:	cbnz	w8, 2b50 <pts_ieee754_sin+0x2b0>
    2984:	fmov	d0, d1
    2988:	b	293c <pts_ieee754_sin+0x9c>
    298c:	fmov	x8, d1
    2990:	ldr	d2, [sp, #8]
    2994:	lsr	x9, x8, #32
    2998:	ubfx	w9, w9, #22, #9
    299c:	cmp	w9, #0xf8
    29a0:	b.hi	29b0 <pts_ieee754_sin+0x110>  // b.pmore
    29a4:	fcvtzs	w9, d1
    29a8:	fmov	d0, #1.000000000000000000e+00
    29ac:	cbz	w9, 293c <pts_ieee754_sin+0x9c>
    29b0:	fmul	d0, d1, d1
    29b4:	adrp	x9, 0 <pts_ieee754_acos>
    29b8:	adrp	x10, 0 <pts_ieee754_acos>
    29bc:	ldr	d3, [x9]
    29c0:	ldr	d4, [x10]
    29c4:	adrp	x9, 0 <pts_ieee754_acos>
    29c8:	ubfx	x8, x8, #32, #31
    29cc:	fmadd	d3, d0, d4, d3
    29d0:	ldr	d4, [x9]
    29d4:	adrp	x9, 0 <pts_ieee754_acos>
    29d8:	fmadd	d3, d0, d3, d4
    29dc:	ldr	d4, [x9]
    29e0:	adrp	x9, 0 <pts_ieee754_acos>
    29e4:	fmadd	d3, d0, d3, d4
    29e8:	ldr	d4, [x9]
    29ec:	adrp	x9, 0 <pts_ieee754_acos>
    29f0:	fmadd	d3, d0, d3, d4
    29f4:	ldr	d4, [x9]
    29f8:	mov	w9, #0x3333                	// #13107
    29fc:	movk	w9, #0x3fd3, lsl #16
    2a00:	cmp	w8, w9
    2a04:	fmadd	d3, d0, d3, d4
    2a08:	fmul	d3, d0, d3
    2a0c:	b.cs	2bb8 <pts_ieee754_sin+0x318>  // b.hs, b.nlast
    2a10:	fnmul	d1, d1, d2
    2a14:	fmov	d2, #5.000000000000000000e-01
    2a18:	fmadd	d1, d0, d3, d1
    2a1c:	fnmsub	d0, d0, d2, d1
    2a20:	fmov	d1, #1.000000000000000000e+00
    2a24:	fsub	d0, d1, d0
    2a28:	b	293c <pts_ieee754_sin+0x9c>
    2a2c:	fmov	x8, d1
    2a30:	ubfx	x8, x8, #54, #9
    2a34:	cmp	x8, #0xf8
    2a38:	b.hi	2a44 <pts_ieee754_sin+0x1a4>  // b.pmore
    2a3c:	fcvtzs	w8, d1
    2a40:	cbz	w8, 2aa8 <pts_ieee754_sin+0x208>
    2a44:	fmul	d0, d1, d1
    2a48:	adrp	x8, 0 <pts_ieee754_acos>
    2a4c:	adrp	x9, 0 <pts_ieee754_acos>
    2a50:	ldr	d2, [x8]
    2a54:	ldr	d3, [x9]
    2a58:	adrp	x8, 0 <pts_ieee754_acos>
    2a5c:	fmov	d4, #5.000000000000000000e-01
    2a60:	ldr	d5, [sp, #8]
    2a64:	fmadd	d2, d0, d3, d2
    2a68:	ldr	d3, [x8]
    2a6c:	adrp	x8, 0 <pts_ieee754_acos>
    2a70:	fmadd	d2, d0, d2, d3
    2a74:	ldr	d3, [x8]
    2a78:	adrp	x8, 0 <pts_ieee754_acos>
    2a7c:	fmadd	d2, d0, d2, d3
    2a80:	ldr	d3, [x8]
    2a84:	adrp	x8, 0 <pts_ieee754_acos>
    2a88:	fmadd	d2, d0, d2, d3
    2a8c:	fnmul	d3, d0, d1
    2a90:	fmul	d2, d3, d2
    2a94:	fmadd	d2, d5, d4, d2
    2a98:	fnmsub	d0, d0, d2, d5
    2a9c:	ldr	d2, [x8]
    2aa0:	fmadd	d0, d3, d2, d0
    2aa4:	fsub	d1, d1, d0
    2aa8:	fneg	d0, d1
    2aac:	b	293c <pts_ieee754_sin+0x9c>
    2ab0:	fmov	x8, d1
    2ab4:	ldr	d0, [sp, #8]
    2ab8:	lsr	x9, x8, #32
    2abc:	ubfx	w9, w9, #22, #9
    2ac0:	cmp	w9, #0xf8
    2ac4:	b.hi	2ad4 <pts_ieee754_sin+0x234>  // b.pmore
    2ac8:	fcvtzs	w9, d1
    2acc:	fmov	d2, #1.000000000000000000e+00
    2ad0:	cbz	w9, 2c34 <pts_ieee754_sin+0x394>
    2ad4:	fmul	d2, d1, d1
    2ad8:	adrp	x9, 0 <pts_ieee754_acos>
    2adc:	adrp	x10, 0 <pts_ieee754_acos>
    2ae0:	ldr	d3, [x9]
    2ae4:	ldr	d4, [x10]
    2ae8:	adrp	x9, 0 <pts_ieee754_acos>
    2aec:	ubfx	x8, x8, #32, #31
    2af0:	fmadd	d3, d2, d4, d3
    2af4:	ldr	d4, [x9]
    2af8:	adrp	x9, 0 <pts_ieee754_acos>
    2afc:	fmadd	d3, d2, d3, d4
    2b00:	ldr	d4, [x9]
    2b04:	adrp	x9, 0 <pts_ieee754_acos>
    2b08:	fmadd	d3, d2, d3, d4
    2b0c:	ldr	d4, [x9]
    2b10:	adrp	x9, 0 <pts_ieee754_acos>
    2b14:	fmadd	d3, d2, d3, d4
    2b18:	ldr	d4, [x9]
    2b1c:	mov	w9, #0x3333                	// #13107
    2b20:	movk	w9, #0x3fd3, lsl #16
    2b24:	cmp	w8, w9
    2b28:	fmadd	d3, d2, d3, d4
    2b2c:	fmul	d3, d2, d3
    2b30:	b.cs	2bf8 <pts_ieee754_sin+0x358>  // b.hs, b.nlast
    2b34:	fnmul	d0, d1, d0
    2b38:	fmov	d1, #5.000000000000000000e-01
    2b3c:	fmadd	d0, d2, d3, d0
    2b40:	fnmsub	d0, d2, d1, d0
    2b44:	fmov	d1, #1.000000000000000000e+00
    2b48:	fsub	d2, d1, d0
    2b4c:	b	2c34 <pts_ieee754_sin+0x394>
    2b50:	fmul	d0, d1, d1
    2b54:	adrp	x8, 0 <pts_ieee754_acos>
    2b58:	adrp	x9, 0 <pts_ieee754_acos>
    2b5c:	ldr	d2, [x8]
    2b60:	ldr	d3, [x9]
    2b64:	adrp	x8, 0 <pts_ieee754_acos>
    2b68:	fmov	d4, #5.000000000000000000e-01
    2b6c:	ldr	d5, [sp, #8]
    2b70:	fmadd	d2, d0, d3, d2
    2b74:	ldr	d3, [x8]
    2b78:	adrp	x8, 0 <pts_ieee754_acos>
    2b7c:	fmadd	d2, d0, d2, d3
    2b80:	ldr	d3, [x8]
    2b84:	adrp	x8, 0 <pts_ieee754_acos>
    2b88:	fmadd	d2, d0, d2, d3
    2b8c:	ldr	d3, [x8]
    2b90:	adrp	x8, 0 <pts_ieee754_acos>
    2b94:	fmadd	d2, d0, d2, d3
    2b98:	fnmul	d3, d0, d1
    2b9c:	fmul	d2, d3, d2
    2ba0:	fmadd	d2, d5, d4, d2
    2ba4:	fnmsub	d0, d0, d2, d5
    2ba8:	ldr	d2, [x8]
    2bac:	fmadd	d0, d3, d2, d0
    2bb0:	fsub	d0, d1, d0
    2bb4:	b	293c <pts_ieee754_sin+0x9c>
    2bb8:	sub	w9, w8, #0x200, lsl #12
    2bbc:	fmov	d4, #2.812500000000000000e-01
    2bc0:	mov	w10, #0x3fe90000            	// #1072234496
    2bc4:	lsl	x9, x9, #32
    2bc8:	cmp	w8, w10
    2bcc:	fnmul	d1, d1, d2
    2bd0:	fmov	d2, #5.000000000000000000e-01
    2bd4:	fmov	d5, x9
    2bd8:	fcsel	d4, d4, d5, hi	// hi = pmore
    2bdc:	fnmsub	d2, d0, d2, d4
    2be0:	fmadd	d0, d0, d3, d1
    2be4:	fmov	d1, #1.000000000000000000e+00
    2be8:	fsub	d1, d1, d4
    2bec:	fsub	d0, d0, d2
    2bf0:	fadd	d0, d1, d0
    2bf4:	b	293c <pts_ieee754_sin+0x9c>
    2bf8:	sub	w9, w8, #0x200, lsl #12
    2bfc:	fmov	d4, #2.812500000000000000e-01
    2c00:	mov	w10, #0x3fe90000            	// #1072234496
    2c04:	lsl	x9, x9, #32
    2c08:	cmp	w8, w10
    2c0c:	fnmul	d0, d1, d0
    2c10:	fmov	d1, #5.000000000000000000e-01
    2c14:	fmov	d5, x9
    2c18:	fmadd	d0, d2, d3, d0
    2c1c:	fcsel	d4, d4, d5, hi	// hi = pmore
    2c20:	fnmsub	d1, d2, d1, d4
    2c24:	fmov	d2, #1.000000000000000000e+00
    2c28:	fsub	d2, d2, d4
    2c2c:	fsub	d0, d0, d1
    2c30:	fadd	d2, d2, d0
    2c34:	fneg	d0, d2
    2c38:	b	293c <pts_ieee754_sin+0x9c>
    2c3c:	nop

0000000000002c40 <pts_ieee754_tan>:
    2c40:	sub	sp, sp, #0x20
    2c44:	stp	x29, x30, [sp, #16]
    2c48:	add	x29, sp, #0x10
    2c4c:	fmov	x8, d0
    2c50:	mov	w10, #0x21fb                	// #8699
    2c54:	movk	w10, #0x3fe9, lsl #16
    2c58:	ubfx	x9, x8, #32, #31
    2c5c:	cmp	w9, w10
    2c60:	b.hi	2c7c <pts_ieee754_tan+0x3c>  // b.pmore
    2c64:	lsr	w10, w9, #20
    2c68:	cmp	w10, #0x3e2
    2c6c:	b.hi	2c90 <pts_ieee754_tan+0x50>  // b.pmore
    2c70:	fcvtzs	w10, d0
    2c74:	cbnz	w10, 2c90 <pts_ieee754_tan+0x50>
    2c78:	b	2fc0 <pts_ieee754_tan+0x380>
    2c7c:	lsr	w8, w9, #20
    2c80:	cmp	w8, #0x7ff
    2c84:	b.cc	2da4 <pts_ieee754_tan+0x164>  // b.lo, b.ul, b.last
    2c88:	fsub	d0, d0, d0
    2c8c:	b	2fc0 <pts_ieee754_tan+0x380>
    2c90:	mov	w10, #0x9427                	// #37927
    2c94:	movk	w10, #0x3fe5, lsl #16
    2c98:	cmp	w9, w10
    2c9c:	b.ls	2cc4 <pts_ieee754_tan+0x84>  // b.plast
    2ca0:	fneg	d1, d0
    2ca4:	cmp	x8, #0x0
    2ca8:	adrp	x11, 0 <pts_ieee754_acos>
    2cac:	fcsel	d0, d1, d0, lt	// lt = tstop
    2cb0:	ldr	d1, [x11]
    2cb4:	adrp	x11, 0 <pts_ieee754_acos>
    2cb8:	fsub	d0, d1, d0
    2cbc:	ldr	d1, [x11]
    2cc0:	fadd	d0, d0, d1
    2cc4:	fmul	d1, d0, d0
    2cc8:	adrp	x11, 0 <pts_ieee754_acos>
    2ccc:	adrp	x12, 0 <pts_ieee754_acos>
    2cd0:	ldr	d3, [x11]
    2cd4:	adrp	x11, 0 <pts_ieee754_acos>
    2cd8:	adrp	x13, 0 <pts_ieee754_acos>
    2cdc:	ldr	d4, [x11]
    2ce0:	ldr	d5, [x12]
    2ce4:	ldr	d6, [x13]
    2ce8:	adrp	x11, 0 <pts_ieee754_acos>
    2cec:	adrp	x12, 0 <pts_ieee754_acos>
    2cf0:	cmp	w9, w10
    2cf4:	fmul	d2, d1, d1
    2cf8:	fmadd	d3, d2, d4, d3
    2cfc:	fmadd	d4, d2, d6, d5
    2d00:	ldr	d5, [x11]
    2d04:	ldr	d6, [x12]
    2d08:	adrp	x11, 0 <pts_ieee754_acos>
    2d0c:	adrp	x12, 0 <pts_ieee754_acos>
    2d10:	fmadd	d3, d2, d3, d5
    2d14:	fmadd	d4, d2, d4, d6
    2d18:	ldr	d5, [x11]
    2d1c:	ldr	d6, [x12]
    2d20:	adrp	x11, 0 <pts_ieee754_acos>
    2d24:	adrp	x12, 0 <pts_ieee754_acos>
    2d28:	fmadd	d3, d2, d3, d5
    2d2c:	fmadd	d4, d2, d4, d6
    2d30:	ldr	d5, [x11]
    2d34:	ldr	d6, [x12]
    2d38:	adrp	x11, 0 <pts_ieee754_acos>
    2d3c:	adrp	x12, 0 <pts_ieee754_acos>
    2d40:	fmadd	d3, d2, d3, d5
    2d44:	fmadd	d4, d2, d4, d6
    2d48:	ldr	d5, [x11]
    2d4c:	ldr	d6, [x12]
    2d50:	adrp	x11, 0 <pts_ieee754_acos>
    2d54:	fmadd	d3, d2, d3, d5
    2d58:	fmadd	d2, d2, d4, d6
    2d5c:	fmul	d4, d0, d1
    2d60:	fmadd	d2, d1, d2, d3
    2d64:	movi	d3, #0x0
    2d68:	fmadd	d2, d4, d2, d3
    2d6c:	fmadd	d1, d1, d2, d3
    2d70:	ldr	d2, [x11]
    2d74:	fmadd	d1, d4, d2, d1
    2d78:	fadd	d2, d0, d1
    2d7c:	b.ls	2df4 <pts_ieee754_tan+0x1b4>  // b.plast
    2d80:	fmov	d3, #1.000000000000000000e+00
    2d84:	fmul	d4, d2, d2
    2d88:	lsr	x8, x8, #32
    2d8c:	lsr	w8, w8, #31
    2d90:	fadd	d2, d2, d3
    2d94:	fdiv	d2, d4, d2
    2d98:	fsub	d1, d2, d1
    2d9c:	fsub	d0, d0, d1
    2da0:	b	2f1c <pts_ieee754_tan+0x2dc>
    2da4:	mov	x0, sp
    2da8:	bl	13e0 <__ieee754_rem_pio2>
    2dac:	ldp	d1, d0, [sp]
    2db0:	ubfiz	w9, w0, #1, #1
    2db4:	fmov	x12, d1
    2db8:	lsr	x8, x12, #32
    2dbc:	ubfx	x10, x12, #32, #31
    2dc0:	ubfx	w11, w8, #20, #11
    2dc4:	cmp	w11, #0x3e2
    2dc8:	b.hi	2dfc <pts_ieee754_tan+0x1bc>  // b.pmore
    2dcc:	fcvtzs	w11, d1
    2dd0:	cbnz	w11, 2dfc <pts_ieee754_tan+0x1bc>
    2dd4:	mov	w8, #0x2                   	// #2
    2dd8:	orr	w10, w12, w10
    2ddc:	sub	w8, w8, w9
    2de0:	orr	w8, w8, w10
    2de4:	cbz	w8, 2f74 <pts_ieee754_tan+0x334>
    2de8:	cbnz	w9, 2f84 <pts_ieee754_tan+0x344>
    2dec:	fmov	d0, d1
    2df0:	b	2fc0 <pts_ieee754_tan+0x380>
    2df4:	fmov	d0, d2
    2df8:	b	2fc0 <pts_ieee754_tan+0x380>
    2dfc:	mov	w11, #0x9427                	// #37927
    2e00:	movk	w11, #0x3fe5, lsl #16
    2e04:	cmp	w10, w11
    2e08:	b.ls	2e40 <pts_ieee754_tan+0x200>  // b.plast
    2e0c:	fneg	d2, d1
    2e10:	fneg	d3, d0
    2e14:	cmp	x12, #0x0
    2e18:	adrp	x12, 0 <pts_ieee754_acos>
    2e1c:	adrp	x13, 0 <pts_ieee754_acos>
    2e20:	fcsel	d0, d3, d0, lt	// lt = tstop
    2e24:	fcsel	d1, d2, d1, lt	// lt = tstop
    2e28:	ldr	d2, [x12]
    2e2c:	ldr	d3, [x13]
    2e30:	fsub	d1, d2, d1
    2e34:	fsub	d0, d3, d0
    2e38:	fadd	d1, d1, d0
    2e3c:	movi	d0, #0x0
    2e40:	fmul	d2, d1, d1
    2e44:	adrp	x12, 0 <pts_ieee754_acos>
    2e48:	adrp	x13, 0 <pts_ieee754_acos>
    2e4c:	ldr	d4, [x12]
    2e50:	adrp	x12, 0 <pts_ieee754_acos>
    2e54:	adrp	x14, 0 <pts_ieee754_acos>
    2e58:	ldr	d5, [x12]
    2e5c:	ldr	d6, [x13]
    2e60:	ldr	d7, [x14]
    2e64:	adrp	x12, 0 <pts_ieee754_acos>
    2e68:	adrp	x13, 0 <pts_ieee754_acos>
    2e6c:	cmp	w10, w11
    2e70:	fmul	d3, d2, d2
    2e74:	fmadd	d4, d3, d5, d4
    2e78:	fmadd	d5, d3, d7, d6
    2e7c:	ldr	d6, [x12]
    2e80:	ldr	d7, [x13]
    2e84:	adrp	x12, 0 <pts_ieee754_acos>
    2e88:	adrp	x13, 0 <pts_ieee754_acos>
    2e8c:	fmadd	d4, d3, d4, d6
    2e90:	fmadd	d5, d3, d5, d7
    2e94:	ldr	d6, [x12]
    2e98:	ldr	d7, [x13]
    2e9c:	adrp	x12, 0 <pts_ieee754_acos>
    2ea0:	adrp	x13, 0 <pts_ieee754_acos>
    2ea4:	fmadd	d4, d3, d4, d6
    2ea8:	fmadd	d5, d3, d5, d7
    2eac:	ldr	d6, [x12]
    2eb0:	ldr	d7, [x13]
    2eb4:	adrp	x12, 0 <pts_ieee754_acos>
    2eb8:	adrp	x13, 0 <pts_ieee754_acos>
    2ebc:	fmadd	d4, d3, d4, d6
    2ec0:	fmadd	d5, d3, d5, d7
    2ec4:	ldr	d6, [x12]
    2ec8:	ldr	d7, [x13]
    2ecc:	adrp	x12, 0 <pts_ieee754_acos>
    2ed0:	fmadd	d4, d3, d4, d6
    2ed4:	fmadd	d3, d3, d5, d7
    2ed8:	fmul	d5, d1, d2
    2edc:	fmadd	d3, d2, d3, d4
    2ee0:	fmadd	d3, d5, d3, d0
    2ee4:	fmadd	d0, d2, d3, d0
    2ee8:	ldr	d2, [x12]
    2eec:	fmadd	d2, d5, d2, d0
    2ef0:	fadd	d0, d1, d2
    2ef4:	b.ls	2f38 <pts_ieee754_tan+0x2f8>  // b.plast
    2ef8:	mov	w10, #0x1                   	// #1
    2efc:	fmul	d4, d0, d0
    2f00:	lsr	w8, w8, #31
    2f04:	sub	w9, w10, w9
    2f08:	scvtf	d3, w9
    2f0c:	fadd	d0, d0, d3
    2f10:	fdiv	d0, d4, d0
    2f14:	fsub	d0, d0, d2
    2f18:	fsub	d0, d1, d0
    2f1c:	mov	w9, #0x1                   	// #1
    2f20:	fmov	d1, #-2.000000000000000000e+00
    2f24:	sub	w8, w9, w8, lsl #1
    2f28:	scvtf	d2, w8
    2f2c:	fmadd	d0, d0, d1, d3
    2f30:	fmul	d0, d0, d2
    2f34:	b	2fc0 <pts_ieee754_tan+0x380>
    2f38:	cbz	w9, 2c78 <pts_ieee754_tan+0x38>
    2f3c:	fmov	d3, #-1.000000000000000000e+00
    2f40:	fmov	x8, d0
    2f44:	fmov	d4, #1.000000000000000000e+00
    2f48:	fdiv	d3, d3, d0
    2f4c:	and	x8, x8, #0xffffffff00000000
    2f50:	fmov	d0, x8
    2f54:	fsub	d1, d0, d1
    2f58:	fsub	d1, d2, d1
    2f5c:	fmov	x8, d3
    2f60:	and	x8, x8, #0xffffffff00000000
    2f64:	fmov	d5, x8
    2f68:	fmadd	d0, d5, d0, d4
    2f6c:	fmadd	d0, d5, d1, d0
    2f70:	b	2fbc <pts_ieee754_tan+0x37c>
    2f74:	fabs	d0, d1
    2f78:	fmov	d1, #1.000000000000000000e+00
    2f7c:	fdiv	d0, d1, d0
    2f80:	b	2c78 <pts_ieee754_tan+0x38>
    2f84:	fadd	d2, d1, d0
    2f88:	fmov	d3, #-1.000000000000000000e+00
    2f8c:	fmov	d4, #1.000000000000000000e+00
    2f90:	fdiv	d3, d3, d2
    2f94:	fmov	x8, d2
    2f98:	and	x8, x8, #0xffffffff00000000
    2f9c:	fmov	d2, x8
    2fa0:	fsub	d1, d2, d1
    2fa4:	fsub	d0, d0, d1
    2fa8:	fmov	x8, d3
    2fac:	and	x8, x8, #0xffffffff00000000
    2fb0:	fmov	d5, x8
    2fb4:	fmadd	d1, d5, d2, d4
    2fb8:	fmadd	d0, d5, d0, d1
    2fbc:	fmadd	d0, d3, d0, d5
    2fc0:	ldp	x29, x30, [sp, #16]
    2fc4:	add	sp, sp, #0x20
    2fc8:	ret
    2fcc:	nop
    2fd0:	nop
    2fd4:	nop
    2fd8:	nop
    2fdc:	nop

0000000000002fe0 <pts_ieee754_cosh>:
    2fe0:	str	d8, [sp, #-32]!
    2fe4:	stp	x29, x30, [sp, #8]
    2fe8:	str	x19, [sp, #24]
    2fec:	add	x29, sp, #0x8
    2ff0:	fmov	x8, d0
    2ff4:	ubfx	x19, x8, #32, #31
    2ff8:	mov	w8, #0x2e42                	// #11842
    2ffc:	movk	w8, #0x3fd6, lsl #16
    3000:	cmp	w19, w8
    3004:	b.hi	303c <pts_ieee754_cosh+0x5c>  // b.pmore
    3008:	fabs	d0, d0
    300c:	bl	24a0 <pts_ieee754_expm1>
    3010:	fmov	d2, #1.000000000000000000e+00
    3014:	fmov	d1, d0
    3018:	lsr	w8, w19, #23
    301c:	cmp	w8, #0x79
    3020:	fadd	d0, d0, d2
    3024:	b.cc	30cc <pts_ieee754_cosh+0xec>  // b.lo, b.ul, b.last
    3028:	fmul	d1, d1, d1
    302c:	fadd	d0, d0, d0
    3030:	fdiv	d0, d1, d0
    3034:	fadd	d0, d0, d2
    3038:	b	30cc <pts_ieee754_cosh+0xec>
    303c:	mov	w8, #0x4035ffff            	// #1077280767
    3040:	cmp	w19, w8
    3044:	b.hi	3060 <pts_ieee754_cosh+0x80>  // b.pmore
    3048:	fabs	d0, d0
    304c:	bl	1ec0 <pts_ieee754_exp>
    3050:	fmov	d1, #5.000000000000000000e-01
    3054:	fdiv	d2, d1, d0
    3058:	fmadd	d0, d0, d1, d2
    305c:	b	30cc <pts_ieee754_cosh+0xec>
    3060:	fabs	d1, d0
    3064:	mov	w8, #0x2e41                	// #11841
    3068:	movk	w8, #0x4086, lsl #16
    306c:	cmp	w19, w8
    3070:	b.hi	3084 <pts_ieee754_cosh+0xa4>  // b.pmore
    3074:	fmov	d0, d1
    3078:	bl	1ec0 <pts_ieee754_exp>
    307c:	fmov	d1, #5.000000000000000000e-01
    3080:	b	30c8 <pts_ieee754_cosh+0xe8>
    3084:	adrp	x8, 0 <pts_ieee754_acos>
    3088:	ldr	d2, [x8]
    308c:	fcmp	d1, d2
    3090:	b.ls	30a8 <pts_ieee754_cosh+0xc8>  // b.plast
    3094:	lsr	w8, w19, #20
    3098:	cmp	w8, #0x7ff
    309c:	b.cc	30bc <pts_ieee754_cosh+0xdc>  // b.lo, b.ul, b.last
    30a0:	fmul	d0, d0, d0
    30a4:	b	30cc <pts_ieee754_cosh+0xec>
    30a8:	fmov	d8, #5.000000000000000000e-01
    30ac:	fmul	d0, d1, d8
    30b0:	bl	1ec0 <pts_ieee754_exp>
    30b4:	fmul	d1, d0, d8
    30b8:	b	30c8 <pts_ieee754_cosh+0xe8>
    30bc:	adrp	x8, 0 <pts_ieee754_acos>
    30c0:	ldr	d0, [x8]
    30c4:	ldr	d1, [x8]
    30c8:	fmul	d0, d0, d1
    30cc:	ldp	x29, x30, [sp, #8]
    30d0:	ldr	x19, [sp, #24]
    30d4:	ldr	d8, [sp], #32
    30d8:	ret
    30dc:	nop

00000000000030e0 <pts_ieee754_sinh>:
    30e0:	stp	d9, d8, [sp, #-32]!
    30e4:	stp	x29, x30, [sp, #16]
    30e8:	add	x29, sp, #0x10
    30ec:	fmov	d1, #5.000000000000000000e-01
    30f0:	fabs	d8, d0
    30f4:	fcmp	d0, #0.0
    30f8:	fmov	d2, #-5.000000000000000000e-01
    30fc:	fmov	d3, #2.200000000000000000e+01
    3100:	fcsel	d9, d2, d1, mi	// mi = first
    3104:	fcmp	d8, d3
    3108:	b.pl	314c <pts_ieee754_sinh+0x6c>  // b.nfrst
    310c:	mov	x8, #0x3e30000000000000    	// #4481081629233643520
    3110:	fmov	d1, x8
    3114:	fcmp	d8, d1
    3118:	b.mi	31b0 <pts_ieee754_sinh+0xd0>  // b.first
    311c:	fmov	d0, d8
    3120:	bl	24a0 <pts_ieee754_expm1>
    3124:	fmov	d2, #1.000000000000000000e+00
    3128:	fadd	d1, d0, d2
    312c:	fcmp	d8, d2
    3130:	b.pl	318c <pts_ieee754_sinh+0xac>  // b.nfrst
    3134:	fnmul	d2, d0, d0
    3138:	fdiv	d1, d2, d1
    313c:	fmov	d2, #2.000000000000000000e+00
    3140:	fmadd	d0, d0, d2, d1
    3144:	fmul	d0, d9, d0
    3148:	b	31b0 <pts_ieee754_sinh+0xd0>
    314c:	mov	x8, #0x2e4200000000        	// #50861002719232
    3150:	movk	x8, #0x4086, lsl #48
    3154:	fmov	d1, x8
    3158:	fcmp	d8, d1
    315c:	b.pl	3170 <pts_ieee754_sinh+0x90>  // b.nfrst
    3160:	fmov	d0, d8
    3164:	bl	1ec0 <pts_ieee754_exp>
    3168:	fmul	d0, d9, d0
    316c:	b	31b0 <pts_ieee754_sinh+0xd0>
    3170:	adrp	x8, 0 <pts_ieee754_acos>
    3174:	ldr	d1, [x8]
    3178:	fcmp	d8, d1
    317c:	b.ls	319c <pts_ieee754_sinh+0xbc>  // b.plast
    3180:	adrp	x8, 0 <pts_ieee754_acos>
    3184:	ldr	d1, [x8]
    3188:	b	31ac <pts_ieee754_sinh+0xcc>
    318c:	fdiv	d1, d0, d1
    3190:	fadd	d0, d0, d1
    3194:	fmul	d0, d9, d0
    3198:	b	31b0 <pts_ieee754_sinh+0xd0>
    319c:	fmov	d0, #5.000000000000000000e-01
    31a0:	fmul	d0, d8, d0
    31a4:	bl	1ec0 <pts_ieee754_exp>
    31a8:	fmul	d1, d9, d0
    31ac:	fmul	d0, d0, d1
    31b0:	ldp	x29, x30, [sp, #16]
    31b4:	ldp	d9, d8, [sp], #32
    31b8:	ret
    31bc:	nop

00000000000031c0 <pts_ieee754_tanh>:
    31c0:	stp	x29, x30, [sp, #-32]!
    31c4:	str	x19, [sp, #16]
    31c8:	mov	x29, sp
    31cc:	fmov	x19, d0
    31d0:	lsr	x8, x19, #32
    31d4:	ubfx	w8, w8, #20, #11
    31d8:	cmp	w8, #0x7ff
    31dc:	b.cc	3200 <pts_ieee754_tanh+0x40>  // b.lo, b.ul, b.last
    31e0:	fmov	d1, #1.000000000000000000e+00
    31e4:	fmov	d2, #-1.000000000000000000e+00
    31e8:	tst	x19, #0x8000000000000000
    31ec:	fdiv	d0, d1, d0
    31f0:	fadd	d2, d0, d2
    31f4:	fadd	d0, d0, d1
    31f8:	fcsel	d0, d2, d0, ne	// ne = any
    31fc:	b	327c <pts_ieee754_tanh+0xbc>
    3200:	ubfx	x8, x19, #32, #31
    3204:	mov	w9, #0x4035ffff            	// #1077280767
    3208:	cmp	w8, w9
    320c:	b.hi	3260 <pts_ieee754_tanh+0xa0>  // b.pmore
    3210:	adrp	x9, 0 <pts_ieee754_acos>
    3214:	fmov	d2, #1.000000000000000000e+00
    3218:	lsr	w8, w8, #20
    321c:	ldr	d1, [x9]
    3220:	fadd	d1, d0, d1
    3224:	fcmp	d1, d2
    3228:	b.le	3234 <pts_ieee754_tanh+0x74>
    322c:	cmp	w8, #0x3e3
    3230:	b.cc	327c <pts_ieee754_tanh+0xbc>  // b.lo, b.ul, b.last
    3234:	fabs	d0, d0
    3238:	cmp	w8, #0x3ff
    323c:	b.cc	3288 <pts_ieee754_tanh+0xc8>  // b.lo, b.ul, b.last
    3240:	fadd	d0, d0, d0
    3244:	bl	24a0 <pts_ieee754_expm1>
    3248:	fmov	d1, #2.000000000000000000e+00
    324c:	fadd	d0, d0, d1
    3250:	fdiv	d0, d1, d0
    3254:	fmov	d1, #1.000000000000000000e+00
    3258:	fsub	d0, d1, d0
    325c:	b	3270 <pts_ieee754_tanh+0xb0>
    3260:	adrp	x8, 0 <pts_ieee754_acos>
    3264:	fmov	d0, #1.000000000000000000e+00
    3268:	ldr	d1, [x8]
    326c:	fsub	d0, d0, d1
    3270:	fneg	d1, d0
    3274:	cmp	x19, #0x0
    3278:	fcsel	d0, d1, d0, lt	// lt = tstop
    327c:	ldr	x19, [sp, #16]
    3280:	ldp	x29, x30, [sp], #32
    3284:	ret
    3288:	fmov	d1, #-2.000000000000000000e+00
    328c:	fmul	d0, d0, d1
    3290:	bl	24a0 <pts_ieee754_expm1>
    3294:	fmov	d1, #2.000000000000000000e+00
    3298:	fneg	d2, d0
    329c:	fadd	d0, d0, d1
    32a0:	fdiv	d0, d2, d0
    32a4:	b	3270 <pts_ieee754_tanh+0xb0>
