/*
 * harness INDIR OUTDIR: for each Math function, reads INDIR/<fn>.bin (raw little-endian doubles;
 * atan2 reads (y, x) pairs) and writes OUTDIR/<fn>.bin with the results of the linked
 * pts_ieee754_* (whichever variant this binary was linked with).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pts.h"

typedef double (*unary)(double);

static const struct {
  const char *name;
  unary f;
} unaries[] = {
    {"acos", pts_ieee754_acos},   {"acosh", pts_ieee754_acosh}, {"asin", pts_ieee754_asin},   {"asinh", pts_ieee754_asinh},
    {"atan", pts_ieee754_atan},   {"atanh", pts_ieee754_atanh}, {"cbrt", pts_ieee754_cbrt},   {"cos", pts_ieee754_cos},
    {"cosh", pts_ieee754_cosh},   {"exp", pts_ieee754_exp},     {"expm1", pts_ieee754_expm1}, {"log", pts_ieee754_log},
    {"log10", pts_ieee754_log10}, {"log1p", pts_ieee754_log1p}, {"log2", pts_ieee754_log2},   {"sin", pts_ieee754_sin},
    {"sinh", pts_ieee754_sinh},   {"tan", pts_ieee754_tan},     {"tanh", pts_ieee754_tanh},
};

static double *read_all(const char *path, size_t *count) {
  FILE *f = fopen(path, "rb");
  if (!f) {
    perror(path);
    exit(2);
  }
  fseek(f, 0, SEEK_END);
  long size = ftell(f);
  fseek(f, 0, SEEK_SET);
  double *data = malloc((size_t)size);
  if (fread(data, 1, (size_t)size, f) != (size_t)size) {
    perror(path);
    exit(2);
  }
  fclose(f);
  *count = (size_t)size / sizeof(double);
  return data;
}

static void write_all(const char *path, const double *data, size_t count) {
  FILE *f = fopen(path, "wb");
  if (!f || fwrite(data, sizeof(double), count, f) != count) {
    perror(path);
    exit(2);
  }
  fclose(f);
}

int main(int argc, char **argv) {
  if (argc != 3) {
    fprintf(stderr, "usage: harness INDIR OUTDIR\n");
    return 2;
  }
  char in[4096], out[4096];
  for (size_t k = 0; k < sizeof unaries / sizeof unaries[0]; k++) {
    snprintf(in, sizeof in, "%s/%s.bin", argv[1], unaries[k].name);
    snprintf(out, sizeof out, "%s/%s.bin", argv[2], unaries[k].name);
    size_t n;
    double *x = read_all(in, &n);
    double *r = malloc(n * sizeof(double));
    for (size_t i = 0; i < n; i++) {
      r[i] = unaries[k].f(x[i]);
    }
    write_all(out, r, n);
    free(x);
    free(r);
  }
  snprintf(in, sizeof in, "%s/atan2.bin", argv[1]);
  snprintf(out, sizeof out, "%s/atan2.bin", argv[2]);
  size_t n;
  double *yx = read_all(in, &n);
  double *r = malloc(n / 2 * sizeof(double));
  for (size_t i = 0; i < n / 2; i++) {
    r[i] = pts_ieee754_atan2(yx[2 * i], yx[2 * i + 1]);
  }
  write_all(out, r, n / 2);
  return 0;
}
