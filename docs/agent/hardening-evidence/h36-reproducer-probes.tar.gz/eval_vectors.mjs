// node eval_vectors.mjs IN.json OUT.json: evaluates each vector's Math function on its inputs (hex bits)
// and records the result's bits under "node".
import { readFileSync, writeFileSync } from "node:fs";

const [inPath, outPath] = process.argv.slice(2);
const vectors = JSON.parse(readFileSync(inPath, "utf8"));
const f64 = new Float64Array(1), u64 = new BigUint64Array(f64.buffer);
const toDouble = (hex) => { u64[0] = BigInt("0x" + hex); return f64[0]; };
const toHex = (d) => { f64[0] = d; return u64[0].toString(16).padStart(16, "0"); };
for (const v of vectors) {
  const args = v.args.map(toDouble);
  v.node = toHex(Math[v.fn](...args));
  v.arch = process.arch;
}
writeFileSync(outPath, JSON.stringify(vectors));
