#!/bin/bash
# Compile the C port (HEAD) with aarch64 GCC 13 at -O2 and -O3 with -ffp-contract=fast and count FP ops per function.
set -e
cd /tmp/pts-h36/repro
for O in O2 O3; do
  aarch64-linux-gnu-gcc -$O -g -ffp-contract=fast -fno-strict-aliasing -Istub -c src/ieee754_head.c -o bin/gcc_$O.o
  aarch64-linux-gnu-objdump -d -C --no-show-raw-insn bin/gcc_$O.o > disasm/gcc_$O.s
  echo "== gcc13 -$O"
  python3 fpcount.py disasm/gcc_$O.s
done
