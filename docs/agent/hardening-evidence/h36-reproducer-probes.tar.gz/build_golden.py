#!/usr/bin/env python3
"""build_golden.py: choose the expressions of the golden file (vectors/golden_exprs.txt), one per line,
sections marked by lines starting with '#'. run_golden.sh then records each Node's output.

Sections:
  math sites   up to 3 inputs per fused site that changes a result on its own (site harness), whose
               results differ between x86-64 and arm64 Node
  math         5 inputs per function where x86-64 and arm64 Node differ (the 2.4M-input run)
  pinned       the CI's and the parent's residual cases
  parseInt     up to 2 strings per radix that isn't a power of two or 10, where the Nodes differ
  Date         up to 3 per probe form, where the Nodes differ
  arch-independent: parseInt with leading zeros (a PTS bug on both architectures, same on both Nodes)
"""
import json
import math
import re
import struct
from array import array

R = "/tmp/pts-h36/repro"


def d(h):
    return struct.unpack("<d", struct.pack("<Q", int(h, 16)))[0]


def lit(v):
    if v != v:
        return "NaN"
    if v == math.inf:
        return "Infinity"
    if v == -math.inf:
        return "-Infinity"
    if v == 0 and math.copysign(1, v) < 0:
        return "-0"
    return repr(v)


def call(fn, args):
    return "Math.%s(%s)" % (fn, ", ".join(lit(a) for a in args))


def nan_hex(h):
    v = int(h, 16)
    return (v >> 52) & 0x7FF == 0x7FF and v & ((1 << 52) - 1) != 0


lines = []
seen = set()


def add(expr):
    if expr not in seen:
        seen.add(expr)
        lines.append(expr)


# math sites
a = json.load(open(f"{R}/vectors/site_candidates.arm64.json"))
x = json.load(open(f"{R}/vectors/site_candidates.x64.json"))
lines.append("# math: inputs where one fused site alone changes the result (the site harness), x86-64 and arm64 Node differ")
per_site = {}
for va, vx in zip(a, x):
    assert va["args"] == vx["args"]
    if va["node"] == vx["node"] or (nan_hex(va["node"]) and nan_hex(vx["node"])):
        continue
    if va["node"] != va["fused"]:
        raise SystemExit("arm64 Node disagrees with the fused prototype: %r" % va)
    n = per_site.get(va["site"], 0)
    if n < 3:
        per_site[va["site"]] = n + 1
        add(call(va["fn"], [d(h) for h in va["args"]]))
print("math sites:", len(per_site), "sites,", sum(per_site.values()), "vectors")

# math: per function, from the 2.4M-input run
FUNCS = ["acos", "acosh", "asin", "asinh", "atan", "atan2", "atanh", "cbrt", "cos", "cosh", "exp", "expm1", "log",
         "log10", "log1p", "log2", "sin", "sinh", "tan", "tanh"]
lines.append("# math: inputs of the 2.4M-input run where x86-64 and arm64 Node differ, 5 per function")


def load(path):
    arr = array("d")
    arr.frombytes(open(path, "rb").read())
    return arr


def bits(v):
    return struct.unpack("<Q", struct.pack("<d", v))[0]


for fn in FUNCS:
    xin = load(f"{R}/inputs/{fn}.bin")
    rx = load(f"{R}/out/node_x86/{fn}.bin")
    ra = load(f"{R}/out/node_arm64/{fn}.bin")
    idx = [i for i in range(len(rx)) if bits(rx[i]) != bits(ra[i]) and not (rx[i] != rx[i] and ra[i] != ra[i])]
    step = max(1, len(idx) // 5)
    for i in idx[::step][:5]:
        add(call(fn, (xin[2 * i], xin[2 * i + 1]) if fn == "atan2" else (xin[i],)))

lines.append("# pinned: the CI's failures and the residual cases of #pragma clang fp contract(fast)")
for e in ["Math.tan(-4503.8727210219895)", "Math.sinh(-0.20922595734114824)", "Math.atanh(-0.09822103850138031)",
          "Math.atan(-0.25420467463499796)", "Math.atan(-0.2330663164060135)", "Math.asinh(-0.256649382199552)",
          'parseInt("1877849bg6cba000000000000000000000000", 23)']:
    add(e)

# parseInt
lines.append("# parseInt: other radixes, digits accumulated in parts of 32 bits (V8's HandleGenericCase), x86-64 and arm64 Node differ")
probe = open(f"{R}/probes/parseint.pts").read().split("\n")
ox = open(f"{R}/probes/out/parseint.node_x86.txt").read().split("\n")
oa = open(f"{R}/probes/out/parseint.node_arm64.txt").read().split("\n")
per_radix = {}
for p, vx, va in zip(probe, ox, oa):
    m = re.match(r'console\.log\((parseInt\("(-?)(0*)[^"]*", (\d+)\))\);', p)
    if not m or vx == va or m.group(3):
        continue
    r = int(m.group(4))
    if per_radix.get(r, 0) < 2 and len(m.group(1)) < 200:
        per_radix[r] = per_radix.get(r, 0) + 1
        add(m.group(1))
print("parseInt radixes:", sorted(per_radix))

# Date
lines.append("# Date: MakeDate's day * msPerDay + time, fused on arm64, where a huge day count cancels a time (V8's MakeDate)")
probe = open(f"{R}/probes/date.pts").read().split("\n")
ox = open(f"{R}/probes/out/date.node_x86.txt").read().split("\n")
oa = open(f"{R}/probes/out/date.node_arm64.txt").read().split("\n")
per_form = {}
for i, (p, vx, va) in enumerate(zip(probe, ox, oa)):
    m = re.match(r"console\.log\((.*)\);$", p)
    if i >= 1500 or not m or vx == va:
        continue
    form = i % 6
    if per_form.get(form, 0) < 3:
        per_form[form] = per_form.get(form, 0) + 1
        add(m.group(1))
print("Date forms:", per_form)

# arch-independent
lines.append("# arch-independent: parseInt skips leading zeros before it groups digits into parts (V8), same on both Nodes")
probe = open(f"{R}/probes/parseint.pts").read().split("\n")
ox = open(f"{R}/probes/out/parseint.node_x86.txt").read().split("\n")
oa = open(f"{R}/probes/out/parseint.node_arm64.txt").read().split("\n")
ph = open(f"{R}/probes/out/parseint.head_x86.txt").read().split("\n")
n = 0
for p, vx, va, vh in zip(probe, ox, oa, ph):
    m = re.match(r'console\.log\((parseInt\("(-?)(0+)[^"]*", (\d+)\))\);', p)
    if m and vx == va and vh != vx and len(m.group(1)) < 120 and n < 8:
        n += 1
        add(m.group(1))
print("leading zeros:", n)

open(f"{R}/vectors/golden_exprs.txt", "w").write("\n".join(lines) + "\n")
print("expressions:", sum(1 for l in lines if not l.startswith("#")))
