#!/usr/bin/env python3
"""fmuladd_sites.py IR SOURCE: the source lines and columns of clang's llvm.fmuladd calls (the products
-ffp-contract=on fuses, which is C's FP_CONTRACT within one expression), deduplicated."""
import re
import sys

ir = open(sys.argv[1]).read()
src = open(sys.argv[2]).read().split("\n")
locs = dict(re.findall(r"^(![0-9]+) = !DILocation\(line: (\d+), column: (\d+)", ir, re.M) and
            [(m[0], (int(m[1]), int(m[2]))) for m in re.findall(r"^(![0-9]+) = !DILocation\(line: (\d+), column: (\d+)", ir, re.M)])
sites = set()
for m in re.finditer(r"call double @llvm\.fmuladd\.f64\([^\n]*!dbg (![0-9]+)", ir):
    sites.add(locs[m.group(1)])
by_line = {}
for ln, col in sorted(sites):
    by_line.setdefault(ln, []).append(col)
print("%d sites on %d lines" % (len(sites), len(by_line)))
for ln, cols in by_line.items():
    print("%5d| cols %-20s %s" % (ln, ",".join(map(str, cols)), src[ln - 1].strip()))
