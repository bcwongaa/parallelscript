; ModuleID = '../src/ieee754_head.c'
source_filename = "../src/ieee754_head.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

@pts_ieee754_atan.atanhi = internal unnamed_addr constant [4 x double] [double 0x3FDDAC670561BB4F, double 0x3FE921FB54442D18, double 0x3FEF730BD281F69B, double 0x3FF921FB54442D18], align 8, !dbg !0
@pts_ieee754_atan.atanlo = internal constant [4 x double] [double 0x3C7A2B7F222F65E2, double 0x3C81A62633145C07, double 0x3C7007887AF0CBBD, double 0x3C91A62633145C07], align 8, !dbg !159
@pts_ieee754_atan2.tiny = internal global double 1.000000e-300, align 8, !dbg !173
@pts_ieee754_atan2.pi_lo = internal global double 0x3CA1A62633145C07, align 8, !dbg !202
@pts_ieee754_exp.halF = internal unnamed_addr constant [2 x double] [double 5.000000e-01, double -5.000000e-01], align 8, !dbg !234
@pts_ieee754_exp.ln2HI = internal unnamed_addr constant [2 x double] [double 0x3FE62E42FEE00000, double 0xBFE62E42FEE00000], align 8, !dbg !243
@pts_ieee754_exp.ln2LO = internal unnamed_addr constant [2 x double] [double 0x3DEA39EF35793C76, double 0xBDEA39EF35793C76], align 8, !dbg !245
@pts_ieee754_exp.huge = internal global double 1.000000e+300, align 8, !dbg !261
@pts_ieee754_exp.twom1000 = internal global double 0x170000000000000, align 8, !dbg !263
@pts_ieee754_exp.two1023 = internal global double 0x7FE0000000000000, align 8, !dbg !265
@pts_ieee754_expm1.huge = internal global double 1.000000e+300, align 8, !dbg !506
@pts_ieee754_cosh.huge = internal global double 1.000000e+300, align 8, !dbg !571
@pts_ieee754_tanh.tiny = internal constant double 1.000000e-300, align 8, !dbg !593
@__ieee754_rem_pio2.two_over_pi = internal unnamed_addr constant [66 x i32] [i32 10680707, i32 7228996, i32 1387004, i32 2578385, i32 16069853, i32 12639074, i32 9804092, i32 4427841, i32 16666979, i32 11263675, i32 12935607, i32 2387514, i32 4345298, i32 14681673, i32 3074569, i32 13734428, i32 16653803, i32 1880361, i32 10960616, i32 8533493, i32 3062596, i32 8710556, i32 7349940, i32 6258241, i32 3772886, i32 3769171, i32 3798172, i32 8675211, i32 12450088, i32 3874808, i32 9961438, i32 366607, i32 15675153, i32 9132554, i32 7151469, i32 3571407, i32 2607881, i32 12013382, i32 4155038, i32 6285869, i32 7677882, i32 13102053, i32 15825725, i32 473591, i32 9065106, i32 15363067, i32 6271263, i32 9264392, i32 5636912, i32 4652155, i32 7056368, i32 13614112, i32 10155062, i32 1944035, i32 9527646, i32 15080200, i32 6658437, i32 6231200, i32 6832269, i32 16767104, i32 5075751, i32 3212806, i32 1398474, i32 7579849, i32 6349435, i32 12618859], align 4, !dbg !642
@__ieee754_rem_pio2.npio2_hw = internal unnamed_addr constant [32 x i32] [i32 1073291771, i32 1074340347, i32 1074977148, i32 1075388923, i32 1075800698, i32 1076025724, i32 1076231611, i32 1076437499, i32 1076643386, i32 1076849274, i32 1076971356, i32 1077074300, i32 1077177244, i32 1077280187, i32 1077383131, i32 1077486075, i32 1077589019, i32 1077691962, i32 1077794906, i32 1077897850, i32 1077968460, i32 1078019932, i32 1078071404, i32 1078122876, i32 1078174348, i32 1078225820, i32 1078277292, i32 1078328763, i32 1078380235, i32 1078431707, i32 1078483179, i32 1078534651], align 4, !dbg !691

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_acos(double noundef %0) local_unnamed_addr #0 !dbg !27 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !29, metadata !DIExpression()), !dbg !878
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !885
  %2 = bitcast double %0 to i64, !dbg !887
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !885
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !40, metadata !DIExpression()), !dbg !888
  %3 = lshr i64 %2, 32, !dbg !889
  %4 = trunc i64 %3 to i32, !dbg !889
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !38, metadata !DIExpression()), !dbg !878
  %5 = and i32 %4, 2147483647, !dbg !890
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !39, metadata !DIExpression()), !dbg !878
  %6 = icmp ugt i32 %5, 1072693247, !dbg !891
  br i1 %6, label %7, label %15, !dbg !892

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !893
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !893
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !45, metadata !DIExpression()), !dbg !895
  %8 = trunc i64 %2 to i32, !dbg !896
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !42, metadata !DIExpression()), !dbg !897
  %9 = add nsw i32 %5, -1072693248, !dbg !898
  %10 = or i32 %9, %8, !dbg !900
  %11 = icmp eq i32 %10, 0, !dbg !901
  %12 = icmp sgt i32 %4, 0, !dbg !902
  %13 = select i1 %12, double 0.000000e+00, double 0x400921FB54442D18, !dbg !902
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !902
  br label %81

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !903
  br i1 %16, label %17, label %36, !dbg !904

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1012924417, !dbg !905
  br i1 %18, label %81, label %19, !dbg !908

19:                                               ; preds = %17
  %20 = fmul double %0, %0, !dbg !909
  tail call void @llvm.dbg.value(metadata double %20, metadata !30, metadata !DIExpression()), !dbg !878
  %21 = tail call double @llvm.fmuladd.f64(double %20, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !910
  %22 = tail call double @llvm.fmuladd.f64(double %20, double %21, double 0xBFA48228B5688F3B), !dbg !911
  %23 = tail call double @llvm.fmuladd.f64(double %20, double %22, double 0x3FC9C1550E884455), !dbg !912
  %24 = tail call double @llvm.fmuladd.f64(double %20, double %23, double 0xBFD4D61203EB6F7D), !dbg !913
  %25 = tail call double @llvm.fmuladd.f64(double %20, double %24, double 0x3FC5555555555555), !dbg !914
  %26 = fmul double %20, %25, !dbg !915
  tail call void @llvm.dbg.value(metadata double %26, metadata !31, metadata !DIExpression()), !dbg !878
  %27 = tail call double @llvm.fmuladd.f64(double %20, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !916
  %28 = tail call double @llvm.fmuladd.f64(double %20, double %27, double 0x40002AE59C598AC8), !dbg !917
  %29 = tail call double @llvm.fmuladd.f64(double %20, double %28, double 0xC0033A271C8A2D4B), !dbg !918
  %30 = tail call double @llvm.fmuladd.f64(double %20, double %29, double 1.000000e+00), !dbg !919
  tail call void @llvm.dbg.value(metadata double %30, metadata !32, metadata !DIExpression()), !dbg !878
  %31 = fdiv double %26, %30, !dbg !920
  tail call void @llvm.dbg.value(metadata double %31, metadata !33, metadata !DIExpression()), !dbg !878
  %32 = fneg double %0, !dbg !921
  %33 = tail call double @llvm.fmuladd.f64(double %32, double %31, double 0x3C91A62633145C07), !dbg !921
  %34 = fsub double %33, %0, !dbg !922
  %35 = fadd double %34, 0x3FF921FB54442D18, !dbg !922
  br label %81, !dbg !923

36:                                               ; preds = %15
  %37 = icmp slt i64 %2, 0, !dbg !924
  br i1 %37, label %38, label %56, !dbg !925

38:                                               ; preds = %36
  %39 = fadd double %0, 1.000000e+00, !dbg !926
  %40 = fmul double %39, 5.000000e-01, !dbg !928
  tail call void @llvm.dbg.value(metadata double %40, metadata !30, metadata !DIExpression()), !dbg !878
  %41 = tail call double @llvm.fmuladd.f64(double %40, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !929
  %42 = tail call double @llvm.fmuladd.f64(double %40, double %41, double 0xBFA48228B5688F3B), !dbg !930
  %43 = tail call double @llvm.fmuladd.f64(double %40, double %42, double 0x3FC9C1550E884455), !dbg !931
  %44 = tail call double @llvm.fmuladd.f64(double %40, double %43, double 0xBFD4D61203EB6F7D), !dbg !932
  %45 = tail call double @llvm.fmuladd.f64(double %40, double %44, double 0x3FC5555555555555), !dbg !933
  %46 = fmul double %40, %45, !dbg !934
  tail call void @llvm.dbg.value(metadata double %46, metadata !31, metadata !DIExpression()), !dbg !878
  %47 = tail call double @llvm.fmuladd.f64(double %40, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !935
  %48 = tail call double @llvm.fmuladd.f64(double %40, double %47, double 0x40002AE59C598AC8), !dbg !936
  %49 = tail call double @llvm.fmuladd.f64(double %40, double %48, double 0xC0033A271C8A2D4B), !dbg !937
  %50 = tail call double @llvm.fmuladd.f64(double %40, double %49, double 1.000000e+00), !dbg !938
  tail call void @llvm.dbg.value(metadata double %50, metadata !32, metadata !DIExpression()), !dbg !878
  %51 = tail call double @llvm.sqrt.f64(double %40), !dbg !939
  tail call void @llvm.dbg.value(metadata double %51, metadata !35, metadata !DIExpression()), !dbg !878
  %52 = fdiv double %46, %50, !dbg !940
  tail call void @llvm.dbg.value(metadata double %52, metadata !33, metadata !DIExpression()), !dbg !878
  %53 = tail call double @llvm.fmuladd.f64(double %52, double %51, double 0xBC91A62633145C07), !dbg !941
  tail call void @llvm.dbg.value(metadata double %53, metadata !34, metadata !DIExpression()), !dbg !878
  %54 = fadd double %51, %53, !dbg !942
  %55 = tail call double @llvm.fmuladd.f64(double %54, double -2.000000e+00, double 0x400921FB54442D18), !dbg !943
  br label %81, !dbg !944

56:                                               ; preds = %36
  %57 = fsub double 1.000000e+00, %0, !dbg !945
  %58 = fmul double %57, 5.000000e-01, !dbg !946
  tail call void @llvm.dbg.value(metadata double %58, metadata !30, metadata !DIExpression()), !dbg !878
  %59 = tail call double @llvm.sqrt.f64(double %58), !dbg !947
  tail call void @llvm.dbg.value(metadata double %59, metadata !35, metadata !DIExpression()), !dbg !878
  tail call void @llvm.dbg.value(metadata double %59, metadata !37, metadata !DIExpression()), !dbg !878
  tail call void @llvm.dbg.value(metadata double %59, metadata !879, metadata !DIExpression()), !dbg !948
  %60 = bitcast double %59 to i64, !dbg !950
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !884, metadata !DIExpression()), !dbg !948
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !47, metadata !DIExpression()), !dbg !951
  %61 = and i64 %60, -4294967296, !dbg !952
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !47, metadata !DIExpression()), !dbg !951
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !47, metadata !DIExpression()), !dbg !951
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !953, metadata !DIExpression()), !dbg !959
  %62 = bitcast i64 %61 to double, !dbg !961
  tail call void @llvm.dbg.value(metadata double %62, metadata !958, metadata !DIExpression()), !dbg !959
  tail call void @llvm.dbg.value(metadata double %62, metadata !37, metadata !DIExpression()), !dbg !878
  %63 = fneg double %62, !dbg !962
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %58), !dbg !962
  %65 = fadd double %59, %62, !dbg !963
  %66 = fdiv double %64, %65, !dbg !964
  tail call void @llvm.dbg.value(metadata double %66, metadata !36, metadata !DIExpression()), !dbg !878
  %67 = tail call double @llvm.fmuladd.f64(double %58, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !965
  %68 = tail call double @llvm.fmuladd.f64(double %58, double %67, double 0xBFA48228B5688F3B), !dbg !966
  %69 = tail call double @llvm.fmuladd.f64(double %58, double %68, double 0x3FC9C1550E884455), !dbg !967
  %70 = tail call double @llvm.fmuladd.f64(double %58, double %69, double 0xBFD4D61203EB6F7D), !dbg !968
  %71 = tail call double @llvm.fmuladd.f64(double %58, double %70, double 0x3FC5555555555555), !dbg !969
  %72 = fmul double %58, %71, !dbg !970
  tail call void @llvm.dbg.value(metadata double %72, metadata !31, metadata !DIExpression()), !dbg !878
  %73 = tail call double @llvm.fmuladd.f64(double %58, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !971
  %74 = tail call double @llvm.fmuladd.f64(double %58, double %73, double 0x40002AE59C598AC8), !dbg !972
  %75 = tail call double @llvm.fmuladd.f64(double %58, double %74, double 0xC0033A271C8A2D4B), !dbg !973
  %76 = tail call double @llvm.fmuladd.f64(double %58, double %75, double 1.000000e+00), !dbg !974
  tail call void @llvm.dbg.value(metadata double %76, metadata !32, metadata !DIExpression()), !dbg !878
  %77 = fdiv double %72, %76, !dbg !975
  tail call void @llvm.dbg.value(metadata double %77, metadata !33, metadata !DIExpression()), !dbg !878
  %78 = tail call double @llvm.fmuladd.f64(double %77, double %59, double %66), !dbg !976
  tail call void @llvm.dbg.value(metadata double %78, metadata !34, metadata !DIExpression()), !dbg !878
  %79 = fadd double %78, %62, !dbg !977
  %80 = fmul double %79, 2.000000e+00, !dbg !978
  br label %81, !dbg !979

81:                                               ; preds = %17, %56, %38, %19, %7
  %82 = phi double [ %14, %7 ], [ %35, %19 ], [ %55, %38 ], [ %80, %56 ], [ 0x3FF921FB54442D18, %17 ], !dbg !878
  ret double %82, !dbg !980
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_acosh(double noundef %0) local_unnamed_addr #0 !dbg !81 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !83, metadata !DIExpression()), !dbg !981
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !982
  %2 = bitcast double %0 to i64, !dbg !984
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !982
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !87, metadata !DIExpression()), !dbg !985
  %3 = lshr i64 %2, 32, !dbg !986
  %4 = trunc i64 %3 to i32, !dbg !986
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !85, metadata !DIExpression()), !dbg !981
  %5 = trunc i64 %2 to i32, !dbg !986
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !86, metadata !DIExpression()), !dbg !981
  %6 = icmp slt i32 %4, 1072693248, !dbg !987
  br i1 %6, label %37, label %7, !dbg !989

7:                                                ; preds = %1
  %8 = icmp ugt i32 %4, 1102053375, !dbg !990
  br i1 %8, label %9, label %16, !dbg !992

9:                                                ; preds = %7
  %10 = icmp ugt i32 %4, 2146435071, !dbg !993
  br i1 %10, label %11, label %13, !dbg !996

11:                                               ; preds = %9
  %12 = fadd double %0, %0, !dbg !997
  br label %37, !dbg !999

13:                                               ; preds = %9
  %14 = tail call double @pts_ieee754_log(double noundef %0), !dbg !1000
  %15 = fadd double %14, 0x3FE62E42FEFA39EF, !dbg !1002
  br label %37, !dbg !1003

16:                                               ; preds = %7
  %17 = add nsw i32 %4, -1072693248, !dbg !1004
  %18 = or i32 %17, %5, !dbg !1006
  %19 = icmp eq i32 %18, 0, !dbg !1007
  br i1 %19, label %37, label %20, !dbg !1008

20:                                               ; preds = %16
  %21 = icmp ugt i32 %4, 1073741824, !dbg !1009
  br i1 %21, label %22, label %30, !dbg !1011

22:                                               ; preds = %20
  %23 = fmul double %0, %0, !dbg !1012
  tail call void @llvm.dbg.value(metadata double %23, metadata !84, metadata !DIExpression()), !dbg !981
  %24 = fadd double %23, -1.000000e+00, !dbg !1014
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1015
  %26 = fadd double %25, %0, !dbg !1016
  %27 = fdiv double -1.000000e+00, %26, !dbg !1017
  %28 = tail call double @llvm.fmuladd.f64(double %0, double 2.000000e+00, double %27), !dbg !1017
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1018
  br label %37, !dbg !1019

30:                                               ; preds = %20
  %31 = fadd double %0, -1.000000e+00, !dbg !1020
  tail call void @llvm.dbg.value(metadata double %31, metadata !84, metadata !DIExpression()), !dbg !981
  %32 = fmul double %31, %31, !dbg !1022
  %33 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double %32), !dbg !1023
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1024
  %35 = fadd double %31, %34, !dbg !1025
  %36 = tail call double @pts_ieee754_log1p(double noundef %35), !dbg !1026
  br label %37, !dbg !1027

37:                                               ; preds = %16, %1, %30, %22, %13, %11
  %38 = phi double [ %12, %11 ], [ %15, %13 ], [ %29, %22 ], [ %36, %30 ], [ 0x7FF8000000000000, %1 ], [ 0.000000e+00, %16 ], !dbg !1028
  ret double %38, !dbg !1029
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log(double noundef %0) local_unnamed_addr #0 !dbg !286 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !288, metadata !DIExpression()), !dbg !1030
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1031
  %2 = bitcast double %0 to i64, !dbg !1033
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1031
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !303, metadata !DIExpression()), !dbg !1034
  %3 = lshr i64 %2, 32, !dbg !1035
  %4 = trunc i64 %3 to i32, !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !299, metadata !DIExpression()), !dbg !1030
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !302, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1030
  tail call void @llvm.dbg.value(metadata i32 0, metadata !298, metadata !DIExpression()), !dbg !1030
  %5 = icmp slt i32 %4, 1048576, !dbg !1036
  br i1 %5, label %6, label %18, !dbg !1037

6:                                                ; preds = %1
  %7 = trunc i64 %2 to i32, !dbg !1035
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !302, metadata !DIExpression()), !dbg !1030
  %8 = and i32 %4, 2147483647, !dbg !1038
  %9 = or i32 %8, %7, !dbg !1040
  %10 = icmp eq i32 %9, 0, !dbg !1041
  br i1 %10, label %114, label %11, !dbg !1042

11:                                               ; preds = %6
  %12 = icmp slt i64 %2, 0, !dbg !1043
  br i1 %12, label %114, label %13, !dbg !1045

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !298, metadata !DIExpression()), !dbg !1030
  %14 = fmul double %0, 0x4350000000000000, !dbg !1046
  tail call void @llvm.dbg.value(metadata double %14, metadata !288, metadata !DIExpression()), !dbg !1030
  tail call void @llvm.dbg.value(metadata double %14, metadata !879, metadata !DIExpression()), !dbg !1047
  %15 = bitcast double %14 to i64, !dbg !1049
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !884, metadata !DIExpression()), !dbg !1047
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !305, metadata !DIExpression()), !dbg !1050
  %16 = lshr i64 %15, 32, !dbg !1051
  %17 = trunc i64 %16 to i32, !dbg !1051
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !299, metadata !DIExpression()), !dbg !1030
  br label %18, !dbg !1052

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !1030
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !1030
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !288, metadata !DIExpression()), !dbg !1030
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !298, metadata !DIExpression()), !dbg !1030
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !299, metadata !DIExpression()), !dbg !1030
  %22 = icmp sgt i32 %19, 2146435071, !dbg !1053
  br i1 %22, label %23, label %25, !dbg !1055

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !1056
  br label %114, !dbg !1057

25:                                               ; preds = %18
  %26 = ashr i32 %19, 20, !dbg !1058
  %27 = add nsw i32 %26, -1023, !dbg !1059
  %28 = add nsw i32 %27, %20, !dbg !1060
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !298, metadata !DIExpression()), !dbg !1030
  %29 = and i32 %19, 1048575, !dbg !1061
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !299, metadata !DIExpression(DW_OP_constu, 1048575, DW_OP_and, DW_OP_stack_value)), !dbg !1030
  %30 = add nuw nsw i32 %29, 614244, !dbg !1062
  %31 = and i32 %30, 1048576, !dbg !1063
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !300, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !1030
  tail call void @llvm.dbg.value(metadata double %21, metadata !879, metadata !DIExpression()), !dbg !1064
  %32 = bitcast double %21 to i64, !dbg !1066
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !884, metadata !DIExpression()), !dbg !1064
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !309, metadata !DIExpression()), !dbg !1067
  %33 = and i64 %32, 4294967295, !dbg !1068
  tail call void @llvm.dbg.value(metadata i64 %33, metadata !309, metadata !DIExpression()), !dbg !1067
  %34 = or disjoint i32 %31, %29, !dbg !1068
  %35 = xor i32 %34, 1072693248, !dbg !1068
  %36 = zext nneg i32 %35 to i64
  %37 = shl nuw nsw i64 %36, 32, !dbg !1068
  %38 = or disjoint i64 %37, %33, !dbg !1068
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !309, metadata !DIExpression()), !dbg !1067
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !953, metadata !DIExpression()), !dbg !1069
  %39 = bitcast i64 %38 to double, !dbg !1071
  tail call void @llvm.dbg.value(metadata double %39, metadata !958, metadata !DIExpression()), !dbg !1069
  tail call void @llvm.dbg.value(metadata double %39, metadata !288, metadata !DIExpression()), !dbg !1030
  %40 = lshr i32 %30, 20
  %41 = add nsw i32 %28, %40, !dbg !1072
  tail call void @llvm.dbg.value(metadata i32 %41, metadata !298, metadata !DIExpression()), !dbg !1030
  %42 = fadd double %39, -1.000000e+00, !dbg !1073
  tail call void @llvm.dbg.value(metadata double %42, metadata !290, metadata !DIExpression()), !dbg !1030
  %43 = add nsw i32 %19, 2, !dbg !1074
  %44 = and i32 %43, 1048575, !dbg !1076
  %45 = icmp ult i32 %44, 3, !dbg !1077
  br i1 %45, label %46, label %68, !dbg !1078

46:                                               ; preds = %25
  %47 = fcmp oeq double %42, 0.000000e+00, !dbg !1079
  br i1 %47, label %48, label %54, !dbg !1082

48:                                               ; preds = %46
  %49 = icmp eq i32 %41, 0, !dbg !1083
  br i1 %49, label %114, label %50, !dbg !1086

50:                                               ; preds = %48
  %51 = sitofp i32 %41 to double, !dbg !1087
  tail call void @llvm.dbg.value(metadata double %51, metadata !297, metadata !DIExpression()), !dbg !1030
  %52 = fmul double %51, 0x3DEA39EF35793C76, !dbg !1089
  %53 = tail call double @llvm.fmuladd.f64(double %51, double 0x3FE62E42FEE00000, double %52), !dbg !1090
  br label %114, !dbg !1091

54:                                               ; preds = %46
  %55 = fmul double %42, %42, !dbg !1092
  %56 = tail call double @llvm.fmuladd.f64(double %42, double 0xBFD5555555555555, double 5.000000e-01), !dbg !1093
  %57 = fmul double %55, %56, !dbg !1094
  tail call void @llvm.dbg.value(metadata double %57, metadata !293, metadata !DIExpression()), !dbg !1030
  %58 = icmp eq i32 %41, 0, !dbg !1095
  br i1 %58, label %59, label %61, !dbg !1097

59:                                               ; preds = %54
  %60 = fsub double %42, %57, !dbg !1098
  br label %114, !dbg !1100

61:                                               ; preds = %54
  %62 = sitofp i32 %41 to double, !dbg !1101
  tail call void @llvm.dbg.value(metadata double %62, metadata !297, metadata !DIExpression()), !dbg !1030
  %63 = fneg double %62, !dbg !1103
  %64 = tail call double @llvm.fmuladd.f64(double %63, double 0x3DEA39EF35793C76, double %57), !dbg !1103
  %65 = fsub double %64, %42, !dbg !1104
  %66 = fneg double %65, !dbg !1105
  %67 = tail call double @llvm.fmuladd.f64(double %62, double 0x3FE62E42FEE00000, double %66), !dbg !1105
  br label %114, !dbg !1106

68:                                               ; preds = %25
  %69 = fadd double %42, 2.000000e+00, !dbg !1107
  %70 = fdiv double %42, %69, !dbg !1108
  tail call void @llvm.dbg.value(metadata double %70, metadata !291, metadata !DIExpression()), !dbg !1030
  %71 = sitofp i32 %41 to double, !dbg !1109
  tail call void @llvm.dbg.value(metadata double %71, metadata !297, metadata !DIExpression()), !dbg !1030
  %72 = fmul double %70, %70, !dbg !1110
  tail call void @llvm.dbg.value(metadata double %72, metadata !292, metadata !DIExpression()), !dbg !1030
  %73 = add nsw i32 %29, -398458, !dbg !1111
  tail call void @llvm.dbg.value(metadata i32 %73, metadata !300, metadata !DIExpression()), !dbg !1030
  %74 = fmul double %72, %72, !dbg !1112
  tail call void @llvm.dbg.value(metadata double %74, metadata !294, metadata !DIExpression()), !dbg !1030
  %75 = sub nsw i32 440401, %29, !dbg !1113
  tail call void @llvm.dbg.value(metadata i32 %75, metadata !301, metadata !DIExpression()), !dbg !1030
  %76 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !1114
  %77 = tail call double @llvm.fmuladd.f64(double %74, double %76, double 0x3FD999999997FA04), !dbg !1115
  %78 = fmul double %74, %77, !dbg !1116
  tail call void @llvm.dbg.value(metadata double %78, metadata !295, metadata !DIExpression()), !dbg !1030
  %79 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !1117
  %80 = tail call double @llvm.fmuladd.f64(double %74, double %79, double 0x3FD2492494229359), !dbg !1118
  %81 = tail call double @llvm.fmuladd.f64(double %74, double %80, double 0x3FE5555555555593), !dbg !1119
  %82 = fmul double %72, %81, !dbg !1120
  tail call void @llvm.dbg.value(metadata double %82, metadata !296, metadata !DIExpression()), !dbg !1030
  %83 = or i32 %73, %75, !dbg !1121
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !300, metadata !DIExpression()), !dbg !1030
  %84 = fadd double %78, %82, !dbg !1122
  tail call void @llvm.dbg.value(metadata double %84, metadata !293, metadata !DIExpression()), !dbg !1030
  %85 = icmp sgt i32 %83, 0, !dbg !1123
  br i1 %85, label %86, label %102, !dbg !1125

86:                                               ; preds = %68
  %87 = fmul double %42, 5.000000e-01, !dbg !1126
  %88 = fmul double %42, %87, !dbg !1128
  tail call void @llvm.dbg.value(metadata double %88, metadata !289, metadata !DIExpression()), !dbg !1030
  %89 = icmp eq i32 %41, 0, !dbg !1129
  %90 = fadd double %88, %84, !dbg !1131
  br i1 %89, label %91, label %95, !dbg !1132

91:                                               ; preds = %86
  %92 = fneg double %70, !dbg !1133
  %93 = tail call double @llvm.fmuladd.f64(double %92, double %90, double %88), !dbg !1133
  %94 = fsub double %42, %93, !dbg !1134
  br label %114, !dbg !1135

95:                                               ; preds = %86
  %96 = fmul double %71, 0x3DEA39EF35793C76, !dbg !1136
  %97 = tail call double @llvm.fmuladd.f64(double %70, double %90, double %96), !dbg !1137
  %98 = fsub double %88, %97, !dbg !1138
  %99 = fsub double %98, %42, !dbg !1139
  %100 = fneg double %99, !dbg !1140
  %101 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %100), !dbg !1140
  br label %114, !dbg !1141

102:                                              ; preds = %68
  %103 = icmp eq i32 %41, 0, !dbg !1142
  %104 = fsub double %42, %84, !dbg !1145
  br i1 %103, label %105, label %108, !dbg !1146

105:                                              ; preds = %102
  %106 = fneg double %70, !dbg !1147
  %107 = tail call double @llvm.fmuladd.f64(double %106, double %104, double %42), !dbg !1147
  br label %114, !dbg !1148

108:                                              ; preds = %102
  %109 = fmul double %71, 0xBDEA39EF35793C76, !dbg !1149
  %110 = tail call double @llvm.fmuladd.f64(double %70, double %104, double %109), !dbg !1149
  %111 = fsub double %110, %42, !dbg !1150
  %112 = fneg double %111, !dbg !1151
  %113 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %112), !dbg !1151
  br label %114, !dbg !1152

114:                                              ; preds = %48, %11, %6, %108, %105, %95, %91, %61, %59, %50, %23
  %115 = phi double [ %24, %23 ], [ %53, %50 ], [ %60, %59 ], [ %67, %61 ], [ %94, %91 ], [ %101, %95 ], [ %107, %105 ], [ %113, %108 ], [ 0xFFF0000000000000, %6 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %48 ], !dbg !1030
  ret double %115, !dbg !1153
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log1p(double noundef %0) local_unnamed_addr #0 !dbg !333 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !335, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1155
  %2 = bitcast double %0 to i64, !dbg !1157
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1155
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !347, metadata !DIExpression()), !dbg !1158
  %3 = lshr i64 %2, 32, !dbg !1159
  %4 = trunc i64 %3 to i32, !dbg !1159
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !344, metadata !DIExpression()), !dbg !1154
  %5 = and i32 %4, 2147483647, !dbg !1160
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !346, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 1, metadata !343, metadata !DIExpression()), !dbg !1154
  %6 = icmp slt i32 %4, 1071284858, !dbg !1161
  br i1 %6, label %7, label %23, !dbg !1163

7:                                                ; preds = %1
  %8 = icmp ugt i32 %5, 1072693247, !dbg !1164
  br i1 %8, label %9, label %12, !dbg !1167

9:                                                ; preds = %7
  %10 = fcmp oeq double %0, -1.000000e+00, !dbg !1168
  %11 = select i1 %10, double 0xFFF0000000000000, double 0x7FF8000000000000, !dbg !1171
  br label %130, !dbg !1171

12:                                               ; preds = %7
  %13 = icmp ult i32 %5, 1042284544, !dbg !1172
  br i1 %13, label %14, label %27, !dbg !1174

14:                                               ; preds = %12
  %15 = fadd double %0, 0x4350000000000000, !dbg !1175
  %16 = fcmp ogt double %15, 0.000000e+00, !dbg !1178
  %17 = icmp ult i32 %5, 1016070144
  %18 = and i1 %16, %17, !dbg !1179
  br i1 %18, label %130, label %19, !dbg !1179

19:                                               ; preds = %14
  %20 = fneg double %0, !dbg !1180
  %21 = fmul double %20, %0, !dbg !1180
  %22 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %0), !dbg !1180
  br label %130, !dbg !1181

23:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !337, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 1, metadata !345, metadata !DIExpression()), !dbg !1154
  %24 = icmp ugt i32 %4, 2146435071, !dbg !1182
  br i1 %24, label %25, label %33, !dbg !1184

25:                                               ; preds = %23
  %26 = fadd double %0, %0, !dbg !1185
  br label %130, !dbg !1186

27:                                               ; preds = %12
  %28 = add i32 %4, -1, !dbg !1187
  %29 = icmp ult i32 %28, -1076707644, !dbg !1187
  tail call void @llvm.dbg.value(metadata double %0, metadata !337, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 1, metadata !345, metadata !DIExpression()), !dbg !1154
  br i1 %29, label %30, label %35, !dbg !1189

30:                                               ; preds = %27
  tail call void @llvm.dbg.value(metadata double %0, metadata !337, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double undef, metadata !338, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 0, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !345, metadata !DIExpression()), !dbg !1154
  %31 = fmul double %0, 5.000000e-01, !dbg !1190
  %32 = fmul double %31, %0, !dbg !1191
  tail call void @llvm.dbg.value(metadata double %32, metadata !336, metadata !DIExpression()), !dbg !1154
  br label %100, !dbg !1192

33:                                               ; preds = %23
  %34 = icmp ult i32 %4, 1128267776, !dbg !1193
  br i1 %34, label %35, label %48, !dbg !1194

35:                                               ; preds = %27, %33
  %36 = fadd double %0, 1.000000e+00, !dbg !1195
  tail call void @llvm.dbg.value(metadata double %36, metadata !342, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %36, metadata !879, metadata !DIExpression()), !dbg !1196
  %37 = bitcast double %36 to i64, !dbg !1198
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !884, metadata !DIExpression()), !dbg !1196
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !349, metadata !DIExpression()), !dbg !1199
  %38 = lshr i64 %37, 32, !dbg !1200
  %39 = trunc i64 %38 to i32, !dbg !1200
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !345, metadata !DIExpression()), !dbg !1154
  %40 = ashr i32 %39, 20, !dbg !1201
  tail call void @llvm.dbg.value(metadata i32 %40, metadata !343, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1154
  %41 = icmp sgt i32 %40, 1023, !dbg !1202
  %42 = fsub double %0, %36, !dbg !1203
  %43 = fadd double %42, 1.000000e+00, !dbg !1203
  %44 = fadd double %36, -1.000000e+00, !dbg !1203
  %45 = fsub double %0, %44, !dbg !1203
  %46 = select i1 %41, double %43, double %45, !dbg !1203
  tail call void @llvm.dbg.value(metadata double %46, metadata !338, metadata !DIExpression()), !dbg !1154
  %47 = fdiv double %46, %36, !dbg !1204
  tail call void @llvm.dbg.value(metadata double %47, metadata !338, metadata !DIExpression()), !dbg !1154
  br label %50, !dbg !1205

48:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata double %0, metadata !342, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1206
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1206
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !345, metadata !DIExpression()), !dbg !1154
  %49 = lshr i32 %4, 20, !dbg !1208
  tail call void @llvm.dbg.value(metadata i32 %49, metadata !343, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1154
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !338, metadata !DIExpression()), !dbg !1154
  br label %50

50:                                               ; preds = %48, %35
  %51 = phi i32 [ %39, %35 ], [ %4, %48 ], !dbg !1209
  %52 = phi i32 [ %40, %35 ], [ %49, %48 ]
  %53 = phi double [ %36, %35 ], [ %0, %48 ], !dbg !1209
  %54 = phi double [ %47, %35 ], [ 0.000000e+00, %48 ], !dbg !1209
  tail call void @llvm.dbg.value(metadata double %54, metadata !338, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %53, metadata !342, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !343, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !345, metadata !DIExpression()), !dbg !1154
  %55 = and i32 %51, 1048575, !dbg !1210
  tail call void @llvm.dbg.value(metadata i32 %55, metadata !345, metadata !DIExpression()), !dbg !1154
  %56 = icmp ult i32 %55, 434334, !dbg !1211
  %57 = bitcast double %53 to i64, !dbg !1212
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !884, metadata !DIExpression()), !dbg !1214
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !884, metadata !DIExpression()), !dbg !1216
  %58 = and i64 %57, 4294967295, !dbg !1213
  br i1 %56, label %59, label %62, !dbg !1218

59:                                               ; preds = %50
  %60 = add nsw i32 %52, -1023, !dbg !1209
  tail call void @llvm.dbg.value(metadata i32 %60, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %53, metadata !879, metadata !DIExpression()), !dbg !1214
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !358, metadata !DIExpression()), !dbg !1219
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !358, metadata !DIExpression()), !dbg !1219
  %61 = or disjoint i32 %55, 1072693248, !dbg !1220
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !358, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1219
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !342, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1154
  br label %67, !dbg !1221

62:                                               ; preds = %50
  %63 = add nsw i32 %52, -1022, !dbg !1222
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata double %53, metadata !879, metadata !DIExpression()), !dbg !1216
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !362, metadata !DIExpression()), !dbg !1223
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !362, metadata !DIExpression()), !dbg !1223
  %64 = or disjoint i32 %55, 1071644672, !dbg !1224
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !362, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1223
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !342, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1154
  %65 = sub nuw nsw i32 1048576, %55, !dbg !1225
  %66 = lshr i32 %65, 2
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !345, metadata !DIExpression()), !dbg !1154
  br label %67

67:                                               ; preds = %59, %62
  %68 = phi i32 [ %55, %59 ], [ %66, %62 ], !dbg !1226
  %69 = phi i32 [ %60, %59 ], [ %63, %62 ], !dbg !1226
  %70 = phi i32 [ %61, %59 ], [ %64, %62 ]
  %71 = zext i32 %70 to i64
  %72 = shl nuw nsw i64 %71, 32, !dbg !1213
  %73 = or disjoint i64 %58, %72, !dbg !1213
  %74 = bitcast i64 %73 to double, !dbg !1213
  tail call void @llvm.dbg.value(metadata double %74, metadata !342, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %69, metadata !343, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !345, metadata !DIExpression()), !dbg !1154
  %75 = fadd double %74, -1.000000e+00, !dbg !1227
  tail call void @llvm.dbg.value(metadata double %75, metadata !337, metadata !DIExpression()), !dbg !1154
  %76 = icmp eq i32 %68, 0, !dbg !1228
  tail call void @llvm.dbg.value(metadata double %54, metadata !338, metadata !DIExpression()), !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !345, metadata !DIExpression()), !dbg !1154
  %77 = fmul double %75, 5.000000e-01, !dbg !1190
  %78 = fmul double %75, %77, !dbg !1191
  tail call void @llvm.dbg.value(metadata double %78, metadata !336, metadata !DIExpression()), !dbg !1154
  br i1 %76, label %79, label %100, !dbg !1192

79:                                               ; preds = %67
  %80 = fcmp oeq double %75, 0.000000e+00, !dbg !1230
  br i1 %80, label %81, label %87, !dbg !1233

81:                                               ; preds = %79
  %82 = icmp eq i32 %69, 0, !dbg !1234
  br i1 %82, label %130, label %83, !dbg !1237

83:                                               ; preds = %81
  %84 = sitofp i32 %69 to double, !dbg !1238
  %85 = tail call double @llvm.fmuladd.f64(double %84, double 0x3DEA39EF35793C76, double %54), !dbg !1240
  tail call void @llvm.dbg.value(metadata double %85, metadata !338, metadata !DIExpression()), !dbg !1154
  %86 = tail call double @llvm.fmuladd.f64(double %84, double 0x3FE62E42FEE00000, double %85), !dbg !1241
  br label %130, !dbg !1242

87:                                               ; preds = %79
  %88 = tail call double @llvm.fmuladd.f64(double %75, double 0xBFE5555555555555, double 1.000000e+00), !dbg !1243
  %89 = fmul double %88, %78, !dbg !1244
  tail call void @llvm.dbg.value(metadata double %89, metadata !341, metadata !DIExpression()), !dbg !1154
  %90 = icmp eq i32 %69, 0, !dbg !1245
  br i1 %90, label %91, label %93, !dbg !1247

91:                                               ; preds = %87
  %92 = fsub double %75, %89, !dbg !1248
  br label %130, !dbg !1249

93:                                               ; preds = %87
  %94 = sitofp i32 %69 to double, !dbg !1250
  %95 = tail call double @llvm.fmuladd.f64(double %94, double 0x3DEA39EF35793C76, double %54), !dbg !1251
  %96 = fsub double %89, %95, !dbg !1252
  %97 = fsub double %96, %75, !dbg !1253
  %98 = fneg double %97, !dbg !1254
  %99 = tail call double @llvm.fmuladd.f64(double %94, double 0x3FE62E42FEE00000, double %98), !dbg !1254
  br label %130, !dbg !1255

100:                                              ; preds = %30, %67
  %101 = phi double [ %32, %30 ], [ %78, %67 ]
  %102 = phi double [ %0, %30 ], [ %75, %67 ]
  %103 = phi double [ undef, %30 ], [ %54, %67 ]
  %104 = phi i32 [ 0, %30 ], [ %69, %67 ]
  %105 = fadd double %102, 2.000000e+00, !dbg !1256
  %106 = fdiv double %102, %105, !dbg !1257
  tail call void @llvm.dbg.value(metadata double %106, metadata !339, metadata !DIExpression()), !dbg !1154
  %107 = fmul double %106, %106, !dbg !1258
  tail call void @llvm.dbg.value(metadata double %107, metadata !340, metadata !DIExpression()), !dbg !1154
  %108 = tail call double @llvm.fmuladd.f64(double %107, double 0x3FC2F112DF3E5244, double 0x3FC39A09D078C69F), !dbg !1259
  %109 = tail call double @llvm.fmuladd.f64(double %107, double %108, double 0x3FC7466496CB03DE), !dbg !1260
  %110 = tail call double @llvm.fmuladd.f64(double %107, double %109, double 0x3FCC71C51D8E78AF), !dbg !1261
  %111 = tail call double @llvm.fmuladd.f64(double %107, double %110, double 0x3FD2492494229359), !dbg !1262
  %112 = tail call double @llvm.fmuladd.f64(double %107, double %111, double 0x3FD999999997FA04), !dbg !1263
  %113 = tail call double @llvm.fmuladd.f64(double %107, double %112, double 0x3FE5555555555593), !dbg !1264
  %114 = fmul double %107, %113, !dbg !1265
  tail call void @llvm.dbg.value(metadata double %114, metadata !341, metadata !DIExpression()), !dbg !1154
  %115 = icmp eq i32 %104, 0, !dbg !1266
  br i1 %115, label %116, label %121, !dbg !1268

116:                                              ; preds = %100
  %117 = fadd double %101, %114, !dbg !1269
  %118 = fneg double %106, !dbg !1270
  %119 = tail call double @llvm.fmuladd.f64(double %118, double %117, double %101), !dbg !1270
  %120 = fsub double %102, %119, !dbg !1271
  br label %130, !dbg !1272

121:                                              ; preds = %100
  %122 = sitofp i32 %104 to double, !dbg !1273
  %123 = fadd double %101, %114, !dbg !1274
  %124 = tail call double @llvm.fmuladd.f64(double %122, double 0x3DEA39EF35793C76, double %103), !dbg !1275
  %125 = tail call double @llvm.fmuladd.f64(double %106, double %123, double %124), !dbg !1276
  %126 = fsub double %101, %125, !dbg !1277
  %127 = fsub double %126, %102, !dbg !1278
  %128 = fneg double %127, !dbg !1279
  %129 = tail call double @llvm.fmuladd.f64(double %122, double 0x3FE62E42FEE00000, double %128), !dbg !1279
  br label %130, !dbg !1280

130:                                              ; preds = %81, %14, %9, %121, %116, %93, %91, %83, %25, %19
  %131 = phi double [ %22, %19 ], [ %26, %25 ], [ %86, %83 ], [ %92, %91 ], [ %99, %93 ], [ %120, %116 ], [ %129, %121 ], [ %11, %9 ], [ %0, %14 ], [ 0.000000e+00, %81 ], !dbg !1154
  ret double %131, !dbg !1281
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_asin(double noundef %0) local_unnamed_addr #0 !dbg !93 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !95, metadata !DIExpression()), !dbg !1282
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !96, metadata !DIExpression()), !dbg !1282
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1283
  %2 = bitcast double %0 to i64, !dbg !1285
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1283
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !105, metadata !DIExpression()), !dbg !1286
  %3 = lshr i64 %2, 32, !dbg !1287
  %4 = trunc i64 %3 to i32, !dbg !1287
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !103, metadata !DIExpression()), !dbg !1282
  %5 = and i32 %4, 2147483647, !dbg !1288
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !104, metadata !DIExpression()), !dbg !1282
  %6 = icmp ugt i32 %5, 1072693247, !dbg !1289
  br i1 %6, label %7, label %15, !dbg !1290

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1291
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1291
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !110, metadata !DIExpression()), !dbg !1293
  %8 = trunc i64 %2 to i32, !dbg !1294
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !107, metadata !DIExpression()), !dbg !1295
  %9 = add nsw i32 %5, -1072693248, !dbg !1296
  %10 = or i32 %9, %8, !dbg !1298
  %11 = icmp eq i32 %10, 0, !dbg !1299
  %12 = fmul double %0, 0x3C91A62633145C07, !dbg !1300
  %13 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF921FB54442D18, double %12), !dbg !1300
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !1300
  br label %80

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !1301
  br i1 %16, label %17, label %38, !dbg !1303

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1044381696, !dbg !1304
  br i1 %18, label %19, label %22, !dbg !1307

19:                                               ; preds = %17
  %20 = fadd double %0, 1.000000e+300, !dbg !1308
  %21 = fcmp ogt double %20, 1.000000e+00, !dbg !1311
  br i1 %21, label %80, label %24, !dbg !1312

22:                                               ; preds = %17
  %23 = fmul double %0, %0, !dbg !1313
  tail call void @llvm.dbg.value(metadata double %23, metadata !96, metadata !DIExpression()), !dbg !1282
  br label %24

24:                                               ; preds = %19, %22
  %25 = phi double [ 0.000000e+00, %19 ], [ %23, %22 ], !dbg !1282
  tail call void @llvm.dbg.value(metadata double %25, metadata !96, metadata !DIExpression()), !dbg !1282
  %26 = tail call double @llvm.fmuladd.f64(double %25, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1315
  %27 = tail call double @llvm.fmuladd.f64(double %25, double %26, double 0xBFA48228B5688F3B), !dbg !1316
  %28 = tail call double @llvm.fmuladd.f64(double %25, double %27, double 0x3FC9C1550E884455), !dbg !1317
  %29 = tail call double @llvm.fmuladd.f64(double %25, double %28, double 0xBFD4D61203EB6F7D), !dbg !1318
  %30 = tail call double @llvm.fmuladd.f64(double %25, double %29, double 0x3FC5555555555555), !dbg !1319
  %31 = fmul double %25, %30, !dbg !1320
  tail call void @llvm.dbg.value(metadata double %31, metadata !98, metadata !DIExpression()), !dbg !1282
  %32 = tail call double @llvm.fmuladd.f64(double %25, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1321
  %33 = tail call double @llvm.fmuladd.f64(double %25, double %32, double 0x40002AE59C598AC8), !dbg !1322
  %34 = tail call double @llvm.fmuladd.f64(double %25, double %33, double 0xC0033A271C8A2D4B), !dbg !1323
  %35 = tail call double @llvm.fmuladd.f64(double %25, double %34, double 1.000000e+00), !dbg !1324
  tail call void @llvm.dbg.value(metadata double %35, metadata !99, metadata !DIExpression()), !dbg !1282
  %36 = fdiv double %31, %35, !dbg !1325
  tail call void @llvm.dbg.value(metadata double %36, metadata !97, metadata !DIExpression()), !dbg !1282
  %37 = tail call double @llvm.fmuladd.f64(double %0, double %36, double %0), !dbg !1326
  br label %80, !dbg !1327

38:                                               ; preds = %15
  %39 = tail call double @llvm.fabs.f64(double %0), !dbg !1328
  %40 = fsub double 1.000000e+00, %39, !dbg !1329
  tail call void @llvm.dbg.value(metadata double %40, metadata !97, metadata !DIExpression()), !dbg !1282
  %41 = fmul double %40, 5.000000e-01, !dbg !1330
  tail call void @llvm.dbg.value(metadata double %41, metadata !96, metadata !DIExpression()), !dbg !1282
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1331
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0xBFA48228B5688F3B), !dbg !1332
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0x3FC9C1550E884455), !dbg !1333
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0xBFD4D61203EB6F7D), !dbg !1334
  %46 = tail call double @llvm.fmuladd.f64(double %41, double %45, double 0x3FC5555555555555), !dbg !1335
  %47 = fmul double %41, %46, !dbg !1336
  tail call void @llvm.dbg.value(metadata double %47, metadata !98, metadata !DIExpression()), !dbg !1282
  %48 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1337
  %49 = tail call double @llvm.fmuladd.f64(double %41, double %48, double 0x40002AE59C598AC8), !dbg !1338
  %50 = tail call double @llvm.fmuladd.f64(double %41, double %49, double 0xC0033A271C8A2D4B), !dbg !1339
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %50, double 1.000000e+00), !dbg !1340
  tail call void @llvm.dbg.value(metadata double %51, metadata !99, metadata !DIExpression()), !dbg !1282
  %52 = tail call double @llvm.sqrt.f64(double %41), !dbg !1341
  tail call void @llvm.dbg.value(metadata double %52, metadata !102, metadata !DIExpression()), !dbg !1282
  %53 = icmp ugt i32 %5, 1072640818, !dbg !1342
  br i1 %53, label %54, label %59, !dbg !1343

54:                                               ; preds = %38
  %55 = fdiv double %47, %51, !dbg !1344
  tail call void @llvm.dbg.value(metadata double %55, metadata !97, metadata !DIExpression()), !dbg !1282
  %56 = tail call double @llvm.fmuladd.f64(double %52, double %55, double %52), !dbg !1346
  %57 = tail call double @llvm.fmuladd.f64(double %56, double 2.000000e+00, double 0xBC91A62633145C07), !dbg !1347
  %58 = fsub double 0x3FF921FB54442D18, %57, !dbg !1348
  tail call void @llvm.dbg.value(metadata double %58, metadata !96, metadata !DIExpression()), !dbg !1282
  br label %75, !dbg !1349

59:                                               ; preds = %38
  tail call void @llvm.dbg.value(metadata double %52, metadata !97, metadata !DIExpression()), !dbg !1282
  tail call void @llvm.dbg.value(metadata double %52, metadata !879, metadata !DIExpression()), !dbg !1350
  %60 = bitcast double %52 to i64, !dbg !1352
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !884, metadata !DIExpression()), !dbg !1350
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !112, metadata !DIExpression()), !dbg !1353
  %61 = and i64 %60, -4294967296, !dbg !1354
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !112, metadata !DIExpression()), !dbg !1353
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !112, metadata !DIExpression()), !dbg !1353
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !953, metadata !DIExpression()), !dbg !1355
  %62 = bitcast i64 %61 to double, !dbg !1357
  tail call void @llvm.dbg.value(metadata double %62, metadata !958, metadata !DIExpression()), !dbg !1355
  tail call void @llvm.dbg.value(metadata double %62, metadata !97, metadata !DIExpression()), !dbg !1282
  %63 = fneg double %62, !dbg !1358
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %41), !dbg !1358
  %65 = fadd double %52, %62, !dbg !1359
  %66 = fdiv double %64, %65, !dbg !1360
  tail call void @llvm.dbg.value(metadata double %66, metadata !100, metadata !DIExpression()), !dbg !1282
  %67 = fdiv double %47, %51, !dbg !1361
  tail call void @llvm.dbg.value(metadata double %67, metadata !101, metadata !DIExpression()), !dbg !1282
  %68 = fmul double %52, 2.000000e+00, !dbg !1362
  %69 = tail call double @llvm.fmuladd.f64(double %66, double -2.000000e+00, double 0x3C91A62633145C07), !dbg !1363
  %70 = fneg double %69, !dbg !1364
  %71 = tail call double @llvm.fmuladd.f64(double %68, double %67, double %70), !dbg !1364
  tail call void @llvm.dbg.value(metadata double %71, metadata !98, metadata !DIExpression()), !dbg !1282
  %72 = tail call double @llvm.fmuladd.f64(double %62, double -2.000000e+00, double 0x3FE921FB54442D18), !dbg !1365
  tail call void @llvm.dbg.value(metadata double %72, metadata !99, metadata !DIExpression()), !dbg !1282
  %73 = fsub double %72, %71, !dbg !1366
  %74 = fadd double %73, 0x3FE921FB54442D18, !dbg !1366
  tail call void @llvm.dbg.value(metadata double %74, metadata !96, metadata !DIExpression()), !dbg !1282
  br label %75

75:                                               ; preds = %59, %54
  %76 = phi double [ %58, %54 ], [ %74, %59 ], !dbg !1367
  tail call void @llvm.dbg.value(metadata double %76, metadata !96, metadata !DIExpression()), !dbg !1282
  %77 = icmp sgt i32 %4, 0, !dbg !1368
  %78 = fneg double %76
  %79 = select i1 %77, double %76, double %78, !dbg !1370
  br label %80, !dbg !1370

80:                                               ; preds = %75, %19, %24, %7
  %81 = phi double [ %14, %7 ], [ %37, %24 ], [ %0, %19 ], [ %79, %75 ], !dbg !1282
  ret double %81, !dbg !1371
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_asinh(double noundef %0) local_unnamed_addr #0 !dbg !146 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !148, metadata !DIExpression()), !dbg !1372
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1373
  %2 = bitcast double %0 to i64, !dbg !1375
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1373
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !153, metadata !DIExpression()), !dbg !1376
  %3 = lshr i64 %2, 32, !dbg !1377
  %4 = trunc i64 %3 to i32, !dbg !1377
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !151, metadata !DIExpression()), !dbg !1372
  %5 = and i32 %4, 2147483647, !dbg !1378
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !152, metadata !DIExpression()), !dbg !1372
  %6 = icmp ugt i32 %5, 2146435071, !dbg !1379
  br i1 %6, label %7, label %9, !dbg !1381

7:                                                ; preds = %1
  %8 = fadd double %0, %0, !dbg !1382
  br label %44, !dbg !1383

9:                                                ; preds = %1
  %10 = icmp ult i32 %5, 1043333120, !dbg !1384
  %11 = fadd double %0, 1.000000e+300
  %12 = fcmp ogt double %11, 1.000000e+00
  %13 = and i1 %12, %10, !dbg !1386
  br i1 %13, label %44, label %14, !dbg !1386

14:                                               ; preds = %9
  %15 = icmp ugt i32 %5, 1102053376, !dbg !1387
  br i1 %15, label %16, label %20, !dbg !1389

16:                                               ; preds = %14
  %17 = tail call double @llvm.fabs.f64(double %0), !dbg !1390
  %18 = tail call double @pts_ieee754_log(double noundef %17), !dbg !1392
  %19 = fadd double %18, 0x3FE62E42FEFA39EF, !dbg !1393
  tail call void @llvm.dbg.value(metadata double %19, metadata !150, metadata !DIExpression()), !dbg !1372
  br label %39, !dbg !1394

20:                                               ; preds = %14
  %21 = icmp ugt i32 %5, 1073741824, !dbg !1395
  br i1 %21, label %22, label %30, !dbg !1397

22:                                               ; preds = %20
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !1398
  tail call void @llvm.dbg.value(metadata double %23, metadata !149, metadata !DIExpression()), !dbg !1372
  %24 = tail call double @llvm.fmuladd.f64(double %0, double %0, double 1.000000e+00), !dbg !1400
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1401
  %26 = fadd double %23, %25, !dbg !1402
  %27 = fdiv double 1.000000e+00, %26, !dbg !1403
  %28 = tail call double @llvm.fmuladd.f64(double %23, double 2.000000e+00, double %27), !dbg !1404
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1405
  tail call void @llvm.dbg.value(metadata double %29, metadata !150, metadata !DIExpression()), !dbg !1372
  br label %39, !dbg !1406

30:                                               ; preds = %20
  %31 = fmul double %0, %0, !dbg !1407
  tail call void @llvm.dbg.value(metadata double %31, metadata !149, metadata !DIExpression()), !dbg !1372
  %32 = tail call double @llvm.fabs.f64(double %0), !dbg !1409
  %33 = fadd double %31, 1.000000e+00, !dbg !1410
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1411
  %35 = fadd double %34, 1.000000e+00, !dbg !1412
  %36 = fdiv double %31, %35, !dbg !1413
  %37 = fadd double %32, %36, !dbg !1414
  %38 = tail call double @pts_ieee754_log1p(double noundef %37), !dbg !1415
  tail call void @llvm.dbg.value(metadata double %38, metadata !150, metadata !DIExpression()), !dbg !1372
  br label %39

39:                                               ; preds = %22, %30, %16
  %40 = phi double [ %19, %16 ], [ %29, %22 ], [ %38, %30 ], !dbg !1416
  tail call void @llvm.dbg.value(metadata double %40, metadata !150, metadata !DIExpression()), !dbg !1372
  %41 = icmp sgt i32 %4, 0, !dbg !1417
  %42 = fneg double %40
  %43 = select i1 %41, double %40, double %42, !dbg !1419
  br label %44, !dbg !1419

44:                                               ; preds = %39, %9, %7
  %45 = phi double [ %8, %7 ], [ %0, %9 ], [ %43, %39 ], !dbg !1372
  ret double %45, !dbg !1420
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(inaccessiblemem: readwrite) uwtable
define dso_local double @pts_ieee754_atan(double noundef %0) local_unnamed_addr #3 !dbg !2 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !854, metadata !DIExpression()), !dbg !1421
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1422
  %2 = bitcast double %0 to i64, !dbg !1424
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1422
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !862, metadata !DIExpression()), !dbg !1425
  %3 = lshr i64 %2, 32, !dbg !1426
  %4 = trunc i64 %3 to i32, !dbg !1426
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !860, metadata !DIExpression()), !dbg !1421
  %5 = and i32 %4, 2147483647, !dbg !1427
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !859, metadata !DIExpression()), !dbg !1421
  %6 = icmp ugt i32 %5, 1141899263, !dbg !1428
  br i1 %6, label %7, label %23, !dbg !1429

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1430
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !1430
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !864, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1432
  %8 = icmp ugt i32 %5, 2146435072, !dbg !1433
  br i1 %8, label %14, label %9, !dbg !1435

9:                                                ; preds = %7
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !864, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1432
  %10 = icmp eq i32 %5, 2146435072, !dbg !1436
  %11 = and i64 %2, 4294967295
  %12 = icmp ne i64 %11, 0
  %13 = and i1 %12, %10, !dbg !1437
  br i1 %13, label %14, label %16, !dbg !1437

14:                                               ; preds = %9, %7
  %15 = fadd double %0, %0, !dbg !1438
  br label %84, !dbg !1439

16:                                               ; preds = %9
  %17 = icmp sgt i32 %4, 0, !dbg !1440
  %18 = load volatile double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 3), align 8, !dbg !1442, !tbaa !1443
  br i1 %17, label %19, label %21, !dbg !1447

19:                                               ; preds = %16
  %20 = fadd double %18, 0x3FF921FB54442D18, !dbg !1448
  br label %84, !dbg !1449

21:                                               ; preds = %16
  %22 = fsub double 0xBFF921FB54442D18, %18, !dbg !1450
  br label %84, !dbg !1451

23:                                               ; preds = %1
  %24 = icmp ult i32 %5, 1071382528, !dbg !1452
  br i1 %24, label %25, label %30, !dbg !1454

25:                                               ; preds = %23
  %26 = icmp ult i32 %5, 1044381696, !dbg !1455
  %27 = fadd double %0, 1.000000e+300
  %28 = fcmp ogt double %27, 1.000000e+00
  %29 = and i1 %28, %26, !dbg !1458
  br i1 %29, label %84, label %51, !dbg !1458

30:                                               ; preds = %23
  %31 = tail call double @llvm.fabs.f64(double %0), !dbg !1459
  tail call void @llvm.dbg.value(metadata double %31, metadata !854, metadata !DIExpression()), !dbg !1421
  %32 = icmp ult i32 %5, 1072889856, !dbg !1461
  br i1 %32, label %33, label %43, !dbg !1463

33:                                               ; preds = %30
  %34 = icmp ult i32 %5, 1072037888, !dbg !1464
  br i1 %34, label %35, label %39, !dbg !1467

35:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 0, metadata !861, metadata !DIExpression()), !dbg !1421
  %36 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double -1.000000e+00), !dbg !1468
  %37 = fadd double %31, 2.000000e+00, !dbg !1470
  %38 = fdiv double %36, %37, !dbg !1471
  tail call void @llvm.dbg.value(metadata double %38, metadata !854, metadata !DIExpression()), !dbg !1421
  br label %51, !dbg !1472

39:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 1, metadata !861, metadata !DIExpression()), !dbg !1421
  %40 = fadd double %31, -1.000000e+00, !dbg !1473
  %41 = fadd double %31, 1.000000e+00, !dbg !1475
  %42 = fdiv double %40, %41, !dbg !1476
  tail call void @llvm.dbg.value(metadata double %42, metadata !854, metadata !DIExpression()), !dbg !1421
  br label %51

43:                                               ; preds = %30
  %44 = icmp ult i32 %5, 1073971200, !dbg !1477
  br i1 %44, label %45, label %49, !dbg !1480

45:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 2, metadata !861, metadata !DIExpression()), !dbg !1421
  %46 = fadd double %31, -1.500000e+00, !dbg !1481
  %47 = tail call double @llvm.fmuladd.f64(double %31, double 1.500000e+00, double 1.000000e+00), !dbg !1483
  %48 = fdiv double %46, %47, !dbg !1484
  tail call void @llvm.dbg.value(metadata double %48, metadata !854, metadata !DIExpression()), !dbg !1421
  br label %51, !dbg !1485

49:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 3, metadata !861, metadata !DIExpression()), !dbg !1421
  %50 = fdiv double -1.000000e+00, %31, !dbg !1486
  tail call void @llvm.dbg.value(metadata double %50, metadata !854, metadata !DIExpression()), !dbg !1421
  br label %51

51:                                               ; preds = %25, %39, %35, %49, %45
  %52 = phi i64 [ 0, %35 ], [ 1, %39 ], [ 2, %45 ], [ 3, %49 ], [ 4294967295, %25 ], !dbg !1488
  %53 = phi double [ %38, %35 ], [ %42, %39 ], [ %48, %45 ], [ %50, %49 ], [ %0, %25 ]
  tail call void @llvm.dbg.value(metadata double %53, metadata !854, metadata !DIExpression()), !dbg !1421
  tail call void @llvm.dbg.value(metadata i64 %52, metadata !861, metadata !DIExpression()), !dbg !1421
  %54 = fmul double %53, %53, !dbg !1489
  tail call void @llvm.dbg.value(metadata double %54, metadata !858, metadata !DIExpression()), !dbg !1421
  %55 = fmul double %54, %54, !dbg !1490
  tail call void @llvm.dbg.value(metadata double %55, metadata !855, metadata !DIExpression()), !dbg !1421
  %56 = tail call double @llvm.fmuladd.f64(double %55, double 0x3F90AD3AE322DA11, double 0x3FA97B4B24760DEB), !dbg !1491
  %57 = tail call double @llvm.fmuladd.f64(double %55, double %56, double 0x3FB10D66A0D03D51), !dbg !1492
  %58 = tail call double @llvm.fmuladd.f64(double %55, double %57, double 0x3FB745CDC54C206E), !dbg !1493
  %59 = tail call double @llvm.fmuladd.f64(double %55, double %58, double 0x3FC24924920083FF), !dbg !1494
  %60 = tail call double @llvm.fmuladd.f64(double %55, double %59, double 0x3FD555555555550D), !dbg !1495
  %61 = fmul double %54, %60, !dbg !1496
  tail call void @llvm.dbg.value(metadata double %61, metadata !856, metadata !DIExpression()), !dbg !1421
  %62 = tail call double @llvm.fmuladd.f64(double %55, double 0xBFA2B4442C6A6C2F, double 0xBFADDE2D52DEFD9A), !dbg !1497
  %63 = tail call double @llvm.fmuladd.f64(double %55, double %62, double 0xBFB3B0F2AF749A6D), !dbg !1498
  %64 = tail call double @llvm.fmuladd.f64(double %55, double %63, double 0xBFBC71C6FE231671), !dbg !1499
  %65 = tail call double @llvm.fmuladd.f64(double %55, double %64, double 0xBFC999999998EBC4), !dbg !1500
  %66 = fmul double %55, %65, !dbg !1501
  tail call void @llvm.dbg.value(metadata double %66, metadata !857, metadata !DIExpression()), !dbg !1421
  br i1 %24, label %67, label %71, !dbg !1502

67:                                               ; preds = %51
  %68 = fadd double %66, %61, !dbg !1503
  %69 = fneg double %53, !dbg !1506
  %70 = tail call double @llvm.fmuladd.f64(double %69, double %68, double %53), !dbg !1506
  br label %84, !dbg !1507

71:                                               ; preds = %51
  %72 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 %52, !dbg !1508
  %73 = load double, ptr %72, align 8, !dbg !1508, !tbaa !1443
  %74 = fadd double %66, %61, !dbg !1510
  %75 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 %52, !dbg !1511
  %76 = load double, ptr %75, align 8, !dbg !1511, !tbaa !1443
  %77 = fneg double %76, !dbg !1512
  %78 = tail call double @llvm.fmuladd.f64(double %53, double %74, double %77), !dbg !1512
  %79 = fsub double %78, %53, !dbg !1513
  %80 = fsub double %73, %79, !dbg !1514
  tail call void @llvm.dbg.value(metadata double %80, metadata !858, metadata !DIExpression()), !dbg !1421
  %81 = icmp slt i64 %2, 0, !dbg !1515
  %82 = fneg double %80, !dbg !1516
  %83 = select i1 %81, double %82, double %80, !dbg !1516
  br label %84, !dbg !1517

84:                                               ; preds = %25, %14, %19, %21, %71, %67
  %85 = phi double [ %70, %67 ], [ %83, %71 ], [ %15, %14 ], [ %20, %19 ], [ %22, %21 ], [ %0, %25 ], !dbg !1421
  ret double %85, !dbg !1518
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_atan2(double noundef %0, double noundef %1) local_unnamed_addr #4 !dbg !175 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !179, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata double %1, metadata !180, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata double %1, metadata !879, metadata !DIExpression()), !dbg !1520
  %3 = bitcast double %1 to i64, !dbg !1522
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !1520
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !190, metadata !DIExpression()), !dbg !1523
  %4 = lshr i64 %3, 32, !dbg !1524
  %5 = trunc i64 %4 to i32, !dbg !1524
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !184, metadata !DIExpression()), !dbg !1519
  %6 = trunc i64 %3 to i32, !dbg !1524
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !188, metadata !DIExpression()), !dbg !1519
  %7 = and i32 %5, 2147483647, !dbg !1525
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !186, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1526
  %8 = bitcast double %0 to i64, !dbg !1528
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !884, metadata !DIExpression()), !dbg !1526
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !192, metadata !DIExpression()), !dbg !1529
  %9 = lshr i64 %8, 32, !dbg !1530
  %10 = trunc i64 %9 to i32, !dbg !1530
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !185, metadata !DIExpression()), !dbg !1519
  %11 = trunc i64 %8 to i32, !dbg !1530
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !189, metadata !DIExpression()), !dbg !1519
  %12 = and i32 %10, 2147483647, !dbg !1531
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !187, metadata !DIExpression()), !dbg !1519
  %13 = icmp ne i32 %6, 0, !dbg !1532
  %14 = zext i1 %13 to i32, !dbg !1532
  %15 = or i32 %7, %14, !dbg !1534
  %16 = icmp ugt i32 %15, 2146435072, !dbg !1535
  br i1 %16, label %22, label %17, !dbg !1536

17:                                               ; preds = %2
  %18 = icmp ne i32 %11, 0, !dbg !1537
  %19 = zext i1 %18 to i32, !dbg !1537
  %20 = or i32 %12, %19, !dbg !1538
  %21 = icmp ugt i32 %20, 2146435072, !dbg !1539
  br i1 %21, label %22, label %24, !dbg !1540

22:                                               ; preds = %17, %2
  %23 = fadd double %0, %1, !dbg !1541
  br label %116, !dbg !1543

24:                                               ; preds = %17
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1544, metadata !DIExpression()), !dbg !1550
  tail call void @llvm.dbg.value(metadata i32 1072693248, metadata !1549, metadata !DIExpression()), !dbg !1550
  %25 = add i32 %5, -1072693248, !dbg !1553
  %26 = or i32 %25, %6, !dbg !1554
  %27 = icmp eq i32 %26, 0, !dbg !1555
  br i1 %27, label %28, label %30, !dbg !1556

28:                                               ; preds = %24
  %29 = tail call double @pts_ieee754_atan(double noundef %0), !dbg !1557
  br label %116, !dbg !1559

30:                                               ; preds = %24
  %31 = lshr i32 %10, 31, !dbg !1560
  %32 = lshr i32 %5, 30, !dbg !1561
  %33 = and i32 %32, 2, !dbg !1562
  %34 = or disjoint i32 %33, %31, !dbg !1563
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !183, metadata !DIExpression()), !dbg !1519
  %35 = or i32 %12, %11, !dbg !1564
  %36 = icmp eq i32 %35, 0, !dbg !1566
  br i1 %36, label %37, label %45, !dbg !1567

37:                                               ; preds = %30
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %116
    i32 2, label %38
    i32 3, label %41
  ], !dbg !1568

38:                                               ; preds = %37
  %39 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1570, !tbaa !1443
  %40 = fadd double %39, 0x400921FB54442D18, !dbg !1572
  br label %116, !dbg !1573

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1574, !tbaa !1443
  %43 = fsub double 0xC00921FB54442D18, %42, !dbg !1575
  br label %116, !dbg !1576

44:                                               ; preds = %72, %59, %37
  unreachable

45:                                               ; preds = %30
  %46 = or i32 %7, %6, !dbg !1577
  %47 = icmp eq i32 %46, 0, !dbg !1579
  br i1 %47, label %48, label %55, !dbg !1580

48:                                               ; preds = %45
  %49 = icmp slt i64 %8, 0, !dbg !1581
  %50 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1582, !tbaa !1443
  br i1 %49, label %51, label %53, !dbg !1583

51:                                               ; preds = %48
  %52 = fsub double 0xBFF921FB54442D18, %50, !dbg !1584
  br label %116, !dbg !1583

53:                                               ; preds = %48
  %54 = fadd double %50, 0x3FF921FB54442D18, !dbg !1585
  br label %116, !dbg !1583

55:                                               ; preds = %45
  %56 = icmp eq i32 %7, 2146435072, !dbg !1586
  %57 = icmp eq i32 %12, 2146435072, !dbg !1519
  br i1 %56, label %58, label %80, !dbg !1588

58:                                               ; preds = %55
  br i1 %57, label %59, label %72, !dbg !1589

59:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %60
    i32 1, label %63
    i32 2, label %66
    i32 3, label %69
  ], !dbg !1591

60:                                               ; preds = %59
  %61 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1594, !tbaa !1443
  %62 = fadd double %61, 0x3FE921FB54442D18, !dbg !1596
  br label %116, !dbg !1597

63:                                               ; preds = %59
  %64 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1598, !tbaa !1443
  %65 = fsub double 0xBFE921FB54442D18, %64, !dbg !1599
  br label %116, !dbg !1600

66:                                               ; preds = %59
  %67 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1601, !tbaa !1443
  %68 = fadd double %67, 0x4002D97C7F3321D2, !dbg !1602
  br label %116, !dbg !1603

69:                                               ; preds = %59
  %70 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1604, !tbaa !1443
  %71 = fsub double 0xC002D97C7F3321D2, %70, !dbg !1605
  br label %116, !dbg !1606

72:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %73
    i32 2, label %74
    i32 3, label %77
  ], !dbg !1607

73:                                               ; preds = %72
  br label %116, !dbg !1609

74:                                               ; preds = %72
  %75 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1611, !tbaa !1443
  %76 = fadd double %75, 0x400921FB54442D18, !dbg !1612
  br label %116, !dbg !1613

77:                                               ; preds = %72
  %78 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1614, !tbaa !1443
  %79 = fsub double 0xC00921FB54442D18, %78, !dbg !1615
  br label %116, !dbg !1616

80:                                               ; preds = %55
  br i1 %57, label %81, label %88, !dbg !1617

81:                                               ; preds = %80
  %82 = icmp slt i64 %8, 0, !dbg !1618
  %83 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1620, !tbaa !1443
  br i1 %82, label %84, label %86, !dbg !1621

84:                                               ; preds = %81
  %85 = fsub double 0xBFF921FB54442D18, %83, !dbg !1622
  br label %116, !dbg !1621

86:                                               ; preds = %81
  %87 = fadd double %83, 0x3FF921FB54442D18, !dbg !1623
  br label %116, !dbg !1621

88:                                               ; preds = %80
  %89 = sub nsw i32 %12, %7, !dbg !1624
  %90 = ashr i32 %89, 20, !dbg !1625
  tail call void @llvm.dbg.value(metadata i32 %90, metadata !182, metadata !DIExpression()), !dbg !1519
  %91 = icmp sgt i32 %90, 60, !dbg !1626
  br i1 %91, label %92, label %95, !dbg !1628

92:                                               ; preds = %88
  %93 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1629, !tbaa !1443
  %94 = tail call double @llvm.fmuladd.f64(double %93, double 5.000000e-01, double 0x3FF921FB54442D18), !dbg !1631
  tail call void @llvm.dbg.value(metadata double %94, metadata !181, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata i32 %31, metadata !183, metadata !DIExpression()), !dbg !1519
  br label %103, !dbg !1632

95:                                               ; preds = %88
  %96 = icmp slt i64 %3, 0, !dbg !1633
  %97 = icmp slt i32 %90, -60
  %98 = and i1 %96, %97, !dbg !1635
  br i1 %98, label %103, label %99, !dbg !1635

99:                                               ; preds = %95
  %100 = fdiv double %0, %1, !dbg !1636
  %101 = tail call double @llvm.fabs.f64(double %100), !dbg !1638
  %102 = tail call double @pts_ieee754_atan(double noundef %101), !dbg !1639
  tail call void @llvm.dbg.value(metadata double %102, metadata !181, metadata !DIExpression()), !dbg !1519
  br label %103

103:                                              ; preds = %95, %99, %92
  %104 = phi i32 [ %31, %92 ], [ %34, %99 ], [ %34, %95 ], !dbg !1519
  %105 = phi double [ %94, %92 ], [ %102, %99 ], [ 0.000000e+00, %95 ], !dbg !1640
  tail call void @llvm.dbg.value(metadata double %105, metadata !181, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata i32 %104, metadata !183, metadata !DIExpression()), !dbg !1519
  switch i32 %104, label %112 [
    i32 0, label %116
    i32 1, label %106
    i32 2, label %108
  ], !dbg !1641

106:                                              ; preds = %103
  %107 = fneg double %105, !dbg !1642
  br label %116, !dbg !1644

108:                                              ; preds = %103
  %109 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1645, !tbaa !1443
  %110 = fsub double %109, %105, !dbg !1646
  %111 = fadd double %110, 0x400921FB54442D18, !dbg !1646
  br label %116, !dbg !1647

112:                                              ; preds = %103
  %113 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1648, !tbaa !1443
  %114 = fsub double %105, %113, !dbg !1649
  %115 = fadd double %114, 0xC00921FB54442D18, !dbg !1650
  br label %116, !dbg !1651

116:                                              ; preds = %103, %84, %86, %72, %51, %53, %37, %37, %112, %108, %106, %77, %74, %73, %69, %66, %63, %60, %41, %38, %28, %22
  %117 = phi double [ %23, %22 ], [ %29, %28 ], [ %115, %112 ], [ %111, %108 ], [ %107, %106 ], [ %71, %69 ], [ %68, %66 ], [ %65, %63 ], [ %62, %60 ], [ %79, %77 ], [ %76, %74 ], [ -0.000000e+00, %73 ], [ %43, %41 ], [ %40, %38 ], [ %0, %37 ], [ %0, %37 ], [ %52, %51 ], [ %54, %53 ], [ 0.000000e+00, %72 ], [ %85, %84 ], [ %87, %86 ], [ %105, %103 ], !dbg !1519
  ret double %117, !dbg !1652
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_cos(double noundef %0) local_unnamed_addr #5 !dbg !1653 {
  %2 = alloca [2 x double], align 8, !DIAssignID !1663
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1656, metadata !DIExpression(), metadata !1663, metadata ptr %2, metadata !DIExpression()), !dbg !1664
  tail call void @llvm.dbg.value(metadata double %0, metadata !1655, metadata !DIExpression()), !dbg !1664
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !1665
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1658, metadata !DIExpression()), !dbg !1664
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1666
  %3 = bitcast double %0 to i64, !dbg !1668
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !1666
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !1661, metadata !DIExpression()), !dbg !1669
  %4 = lshr i64 %3, 32, !dbg !1670
  %5 = trunc i64 %4 to i32, !dbg !1670
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1660, metadata !DIExpression()), !dbg !1664
  %6 = and i32 %5, 2147483647, !dbg !1671
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1660, metadata !DIExpression()), !dbg !1664
  %7 = icmp ult i32 %6, 1072243196, !dbg !1672
  br i1 %7, label %8, label %42, !dbg !1674

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !614, metadata !DIExpression()), !dbg !1675
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !615, metadata !DIExpression()), !dbg !1675
  call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1678
  call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !1678
  call void @llvm.dbg.value(metadata i64 %3, metadata !622, metadata !DIExpression()), !dbg !1680
  call void @llvm.dbg.value(metadata i32 %5, metadata !621, metadata !DIExpression()), !dbg !1675
  call void @llvm.dbg.value(metadata i32 %6, metadata !621, metadata !DIExpression()), !dbg !1675
  %9 = icmp ult i32 %6, 1044381696, !dbg !1681
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !1683
  br i1 %12, label %186, label %13, !dbg !1683

13:                                               ; preds = %8
  %14 = fmul double %0, %0, !dbg !1684
  call void @llvm.dbg.value(metadata double %14, metadata !618, metadata !DIExpression()), !dbg !1675
  %15 = tail call double @llvm.fmuladd.f64(double %14, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1685
  %16 = tail call double @llvm.fmuladd.f64(double %14, double %15, double 0xBE927E4F809C52AD), !dbg !1686
  %17 = tail call double @llvm.fmuladd.f64(double %14, double %16, double 0x3EFA01A019CB1590), !dbg !1687
  %18 = tail call double @llvm.fmuladd.f64(double %14, double %17, double 0xBF56C16C16C15177), !dbg !1688
  %19 = tail call double @llvm.fmuladd.f64(double %14, double %18, double 0x3FA555555555554C), !dbg !1689
  %20 = fmul double %14, %19, !dbg !1690
  call void @llvm.dbg.value(metadata double %20, metadata !619, metadata !DIExpression()), !dbg !1675
  %21 = icmp ult i32 %6, 1070805811, !dbg !1691
  br i1 %21, label %22, label %28, !dbg !1692

22:                                               ; preds = %13
  %23 = fmul double %0, -0.000000e+00, !dbg !1693
  %24 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %23), !dbg !1693
  %25 = fneg double %24, !dbg !1695
  %26 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %25), !dbg !1695
  %27 = fsub double 1.000000e+00, %26, !dbg !1696
  br label %186, !dbg !1697

28:                                               ; preds = %13
  %29 = icmp ugt i32 %6, 1072234496, !dbg !1698
  %30 = add nsw i32 %6, -2097152, !dbg !1699
  %31 = zext nneg i32 %30 to i64, !dbg !1699
  %32 = shl nuw nsw i64 %31, 32, !dbg !1699
  %33 = bitcast i64 %32 to double, !dbg !1699
  %34 = select i1 %29, double 2.812500e-01, double %33, !dbg !1699
  call void @llvm.dbg.value(metadata double %34, metadata !620, metadata !DIExpression()), !dbg !1675
  %35 = fneg double %34, !dbg !1700
  %36 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %35), !dbg !1700
  call void @llvm.dbg.value(metadata double %36, metadata !617, metadata !DIExpression()), !dbg !1675
  %37 = fsub double 1.000000e+00, %34, !dbg !1701
  call void @llvm.dbg.value(metadata double %37, metadata !616, metadata !DIExpression()), !dbg !1675
  %38 = fmul double %0, -0.000000e+00, !dbg !1702
  %39 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %38), !dbg !1702
  %40 = fsub double %39, %36, !dbg !1703
  %41 = fadd double %37, %40, !dbg !1703
  br label %186, !dbg !1704

42:                                               ; preds = %1
  %43 = icmp ugt i32 %6, 2146435071, !dbg !1705
  br i1 %43, label %44, label %46, !dbg !1707

44:                                               ; preds = %42
  %45 = fsub double %0, %0, !dbg !1708
  br label %186, !dbg !1710

46:                                               ; preds = %42
  %47 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !1711
  tail call void @llvm.dbg.value(metadata i32 %47, metadata !1659, metadata !DIExpression()), !dbg !1664
  %48 = and i32 %47, 3, !dbg !1713
  %49 = load double, ptr %2, align 8, !dbg !1714, !tbaa !1443
  switch i32 %48, label %163 [
    i32 0, label %50
    i32 1, label %92
    i32 2, label %118
  ], !dbg !1716

50:                                               ; preds = %46
  %51 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1717
  %52 = load double, ptr %51, align 8, !dbg !1717, !tbaa !1443
  call void @llvm.dbg.value(metadata double %49, metadata !614, metadata !DIExpression()), !dbg !1718
  call void @llvm.dbg.value(metadata double %52, metadata !615, metadata !DIExpression()), !dbg !1718
  call void @llvm.dbg.value(metadata double %49, metadata !879, metadata !DIExpression()), !dbg !1720
  %53 = bitcast double %49 to i64, !dbg !1722
  call void @llvm.dbg.value(metadata i64 %53, metadata !884, metadata !DIExpression()), !dbg !1720
  call void @llvm.dbg.value(metadata i64 %53, metadata !622, metadata !DIExpression()), !dbg !1723
  %54 = lshr i64 %53, 32, !dbg !1724
  %55 = trunc i64 %54 to i32, !dbg !1724
  call void @llvm.dbg.value(metadata i32 %55, metadata !621, metadata !DIExpression()), !dbg !1718
  %56 = and i32 %55, 2147483647, !dbg !1725
  call void @llvm.dbg.value(metadata i32 %56, metadata !621, metadata !DIExpression()), !dbg !1718
  %57 = icmp ult i32 %56, 1044381696, !dbg !1726
  %58 = fptosi double %49 to i32
  %59 = icmp eq i32 %58, 0
  %60 = select i1 %57, i1 %59, i1 false, !dbg !1727
  br i1 %60, label %186, label %61, !dbg !1727

61:                                               ; preds = %50
  %62 = fmul double %49, %49, !dbg !1728
  call void @llvm.dbg.value(metadata double %62, metadata !618, metadata !DIExpression()), !dbg !1718
  %63 = tail call double @llvm.fmuladd.f64(double %62, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1729
  %64 = tail call double @llvm.fmuladd.f64(double %62, double %63, double 0xBE927E4F809C52AD), !dbg !1730
  %65 = tail call double @llvm.fmuladd.f64(double %62, double %64, double 0x3EFA01A019CB1590), !dbg !1731
  %66 = tail call double @llvm.fmuladd.f64(double %62, double %65, double 0xBF56C16C16C15177), !dbg !1732
  %67 = tail call double @llvm.fmuladd.f64(double %62, double %66, double 0x3FA555555555554C), !dbg !1733
  %68 = fmul double %62, %67, !dbg !1734
  call void @llvm.dbg.value(metadata double %68, metadata !619, metadata !DIExpression()), !dbg !1718
  %69 = icmp ult i32 %56, 1070805811, !dbg !1735
  br i1 %69, label %70, label %77, !dbg !1736

70:                                               ; preds = %61
  %71 = fneg double %49, !dbg !1737
  %72 = fmul double %52, %71, !dbg !1737
  %73 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %72), !dbg !1737
  %74 = fneg double %73, !dbg !1738
  %75 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %74), !dbg !1738
  %76 = fsub double 1.000000e+00, %75, !dbg !1739
  br label %186, !dbg !1740

77:                                               ; preds = %61
  %78 = icmp ugt i32 %56, 1072234496, !dbg !1741
  %79 = add nsw i32 %56, -2097152, !dbg !1742
  %80 = zext nneg i32 %79 to i64, !dbg !1742
  %81 = shl nuw nsw i64 %80, 32, !dbg !1742
  %82 = bitcast i64 %81 to double, !dbg !1742
  %83 = select i1 %78, double 2.812500e-01, double %82, !dbg !1742
  call void @llvm.dbg.value(metadata double %83, metadata !620, metadata !DIExpression()), !dbg !1718
  %84 = fneg double %83, !dbg !1743
  %85 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %84), !dbg !1743
  call void @llvm.dbg.value(metadata double %85, metadata !617, metadata !DIExpression()), !dbg !1718
  %86 = fsub double 1.000000e+00, %83, !dbg !1744
  call void @llvm.dbg.value(metadata double %86, metadata !616, metadata !DIExpression()), !dbg !1718
  %87 = fneg double %49, !dbg !1745
  %88 = fmul double %52, %87, !dbg !1745
  %89 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %88), !dbg !1745
  %90 = fsub double %89, %85, !dbg !1746
  %91 = fadd double %86, %90, !dbg !1746
  br label %186, !dbg !1747

92:                                               ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !774, metadata !DIExpression()), !dbg !1748
  call void @llvm.dbg.value(metadata double poison, metadata !775, metadata !DIExpression()), !dbg !1748
  call void @llvm.dbg.value(metadata i32 1, metadata !776, metadata !DIExpression()), !dbg !1748
  call void @llvm.dbg.value(metadata double %49, metadata !879, metadata !DIExpression()), !dbg !1750
  %93 = bitcast double %49 to i64, !dbg !1752
  call void @llvm.dbg.value(metadata i64 %93, metadata !884, metadata !DIExpression()), !dbg !1750
  call void @llvm.dbg.value(metadata i64 %93, metadata !781, metadata !DIExpression()), !dbg !1753
  call void @llvm.dbg.value(metadata i64 %93, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1748
  %94 = and i64 %93, 9205357638345293824, !dbg !1754
  %95 = icmp ult i64 %94, 4485585228861014016, !dbg !1754
  %96 = fptosi double %49 to i32
  %97 = icmp eq i32 %96, 0
  %98 = select i1 %95, i1 %97, i1 false, !dbg !1756
  br i1 %98, label %115, label %99, !dbg !1756

99:                                               ; preds = %92
  %100 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1757
  %101 = load double, ptr %100, align 8, !dbg !1757, !tbaa !1443
  call void @llvm.dbg.value(metadata double %101, metadata !775, metadata !DIExpression()), !dbg !1748
  %102 = fmul double %49, %49, !dbg !1758
  call void @llvm.dbg.value(metadata double %102, metadata !777, metadata !DIExpression()), !dbg !1748
  call void @llvm.dbg.value(metadata double poison, metadata !779, metadata !DIExpression()), !dbg !1748
  %103 = tail call double @llvm.fmuladd.f64(double %102, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1759
  %104 = tail call double @llvm.fmuladd.f64(double %102, double %103, double 0x3EC71DE357B1FE7D), !dbg !1760
  %105 = tail call double @llvm.fmuladd.f64(double %102, double %104, double 0xBF2A01A019C161D5), !dbg !1761
  %106 = tail call double @llvm.fmuladd.f64(double %102, double %105, double 0x3F8111111110F8A6), !dbg !1762
  call void @llvm.dbg.value(metadata double %106, metadata !778, metadata !DIExpression()), !dbg !1748
  %107 = fneg double %102, !dbg !1763
  %108 = fmul double %49, %107, !dbg !1763
  %109 = fmul double %108, %106, !dbg !1763
  %110 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double %109), !dbg !1763
  %111 = fneg double %101, !dbg !1766
  %112 = tail call double @llvm.fmuladd.f64(double %102, double %110, double %111), !dbg !1766
  %113 = tail call double @llvm.fmuladd.f64(double %108, double 0xBFC5555555555549, double %112), !dbg !1767
  %114 = fsub double %49, %113, !dbg !1768
  br label %115, !dbg !1769

115:                                              ; preds = %92, %99
  %116 = phi double [ %114, %99 ], [ %49, %92 ], !dbg !1748
  %117 = fneg double %116, !dbg !1770
  br label %186, !dbg !1771

118:                                              ; preds = %46
  %119 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1772
  %120 = load double, ptr %119, align 8, !dbg !1772, !tbaa !1443
  call void @llvm.dbg.value(metadata double %49, metadata !614, metadata !DIExpression()), !dbg !1773
  call void @llvm.dbg.value(metadata double %120, metadata !615, metadata !DIExpression()), !dbg !1773
  call void @llvm.dbg.value(metadata double %49, metadata !879, metadata !DIExpression()), !dbg !1775
  %121 = bitcast double %49 to i64, !dbg !1777
  call void @llvm.dbg.value(metadata i64 %121, metadata !884, metadata !DIExpression()), !dbg !1775
  call void @llvm.dbg.value(metadata i64 %121, metadata !622, metadata !DIExpression()), !dbg !1778
  %122 = lshr i64 %121, 32, !dbg !1779
  %123 = trunc i64 %122 to i32, !dbg !1779
  call void @llvm.dbg.value(metadata i32 %123, metadata !621, metadata !DIExpression()), !dbg !1773
  %124 = and i32 %123, 2147483647, !dbg !1780
  call void @llvm.dbg.value(metadata i32 %124, metadata !621, metadata !DIExpression()), !dbg !1773
  %125 = icmp ult i32 %124, 1044381696, !dbg !1781
  %126 = fptosi double %49 to i32
  %127 = icmp eq i32 %126, 0
  %128 = select i1 %125, i1 %127, i1 false, !dbg !1782
  br i1 %128, label %160, label %129, !dbg !1782

129:                                              ; preds = %118
  %130 = fmul double %49, %49, !dbg !1783
  call void @llvm.dbg.value(metadata double %130, metadata !618, metadata !DIExpression()), !dbg !1773
  %131 = tail call double @llvm.fmuladd.f64(double %130, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1784
  %132 = tail call double @llvm.fmuladd.f64(double %130, double %131, double 0xBE927E4F809C52AD), !dbg !1785
  %133 = tail call double @llvm.fmuladd.f64(double %130, double %132, double 0x3EFA01A019CB1590), !dbg !1786
  %134 = tail call double @llvm.fmuladd.f64(double %130, double %133, double 0xBF56C16C16C15177), !dbg !1787
  %135 = tail call double @llvm.fmuladd.f64(double %130, double %134, double 0x3FA555555555554C), !dbg !1788
  %136 = fmul double %130, %135, !dbg !1789
  call void @llvm.dbg.value(metadata double %136, metadata !619, metadata !DIExpression()), !dbg !1773
  %137 = icmp ult i32 %124, 1070805811, !dbg !1790
  br i1 %137, label %138, label %145, !dbg !1791

138:                                              ; preds = %129
  %139 = fneg double %49, !dbg !1792
  %140 = fmul double %120, %139, !dbg !1792
  %141 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %140), !dbg !1792
  %142 = fneg double %141, !dbg !1793
  %143 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %142), !dbg !1793
  %144 = fsub double 1.000000e+00, %143, !dbg !1794
  br label %160, !dbg !1795

145:                                              ; preds = %129
  %146 = icmp ugt i32 %124, 1072234496, !dbg !1796
  %147 = add nsw i32 %124, -2097152, !dbg !1797
  %148 = zext nneg i32 %147 to i64, !dbg !1797
  %149 = shl nuw nsw i64 %148, 32, !dbg !1797
  %150 = bitcast i64 %149 to double, !dbg !1797
  %151 = select i1 %146, double 2.812500e-01, double %150, !dbg !1797
  call void @llvm.dbg.value(metadata double %151, metadata !620, metadata !DIExpression()), !dbg !1773
  %152 = fneg double %151, !dbg !1798
  %153 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %152), !dbg !1798
  call void @llvm.dbg.value(metadata double %153, metadata !617, metadata !DIExpression()), !dbg !1773
  %154 = fsub double 1.000000e+00, %151, !dbg !1799
  call void @llvm.dbg.value(metadata double %154, metadata !616, metadata !DIExpression()), !dbg !1773
  %155 = fneg double %49, !dbg !1800
  %156 = fmul double %120, %155, !dbg !1800
  %157 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %156), !dbg !1800
  %158 = fsub double %157, %153, !dbg !1801
  %159 = fadd double %154, %158, !dbg !1801
  br label %160, !dbg !1802

160:                                              ; preds = %118, %138, %145
  %161 = phi double [ %144, %138 ], [ %159, %145 ], [ 1.000000e+00, %118 ], !dbg !1773
  %162 = fneg double %161, !dbg !1803
  br label %186, !dbg !1804

163:                                              ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !774, metadata !DIExpression()), !dbg !1805
  call void @llvm.dbg.value(metadata double poison, metadata !775, metadata !DIExpression()), !dbg !1805
  call void @llvm.dbg.value(metadata i32 1, metadata !776, metadata !DIExpression()), !dbg !1805
  call void @llvm.dbg.value(metadata double %49, metadata !879, metadata !DIExpression()), !dbg !1807
  %164 = bitcast double %49 to i64, !dbg !1809
  call void @llvm.dbg.value(metadata i64 %164, metadata !884, metadata !DIExpression()), !dbg !1807
  call void @llvm.dbg.value(metadata i64 %164, metadata !781, metadata !DIExpression()), !dbg !1810
  call void @llvm.dbg.value(metadata i64 %164, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1805
  %165 = and i64 %164, 9205357638345293824, !dbg !1811
  %166 = icmp ult i64 %165, 4485585228861014016, !dbg !1811
  %167 = fptosi double %49 to i32
  %168 = icmp eq i32 %167, 0
  %169 = select i1 %166, i1 %168, i1 false, !dbg !1812
  br i1 %169, label %186, label %170, !dbg !1812

170:                                              ; preds = %163
  %171 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1813
  %172 = load double, ptr %171, align 8, !dbg !1813, !tbaa !1443
  call void @llvm.dbg.value(metadata double %172, metadata !775, metadata !DIExpression()), !dbg !1805
  %173 = fmul double %49, %49, !dbg !1814
  call void @llvm.dbg.value(metadata double %173, metadata !777, metadata !DIExpression()), !dbg !1805
  call void @llvm.dbg.value(metadata double poison, metadata !779, metadata !DIExpression()), !dbg !1805
  %174 = tail call double @llvm.fmuladd.f64(double %173, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1815
  %175 = tail call double @llvm.fmuladd.f64(double %173, double %174, double 0x3EC71DE357B1FE7D), !dbg !1816
  %176 = tail call double @llvm.fmuladd.f64(double %173, double %175, double 0xBF2A01A019C161D5), !dbg !1817
  %177 = tail call double @llvm.fmuladd.f64(double %173, double %176, double 0x3F8111111110F8A6), !dbg !1818
  call void @llvm.dbg.value(metadata double %177, metadata !778, metadata !DIExpression()), !dbg !1805
  %178 = fneg double %173, !dbg !1819
  %179 = fmul double %49, %178, !dbg !1819
  %180 = fmul double %179, %177, !dbg !1819
  %181 = tail call double @llvm.fmuladd.f64(double %172, double 5.000000e-01, double %180), !dbg !1819
  %182 = fneg double %172, !dbg !1820
  %183 = tail call double @llvm.fmuladd.f64(double %173, double %181, double %182), !dbg !1820
  %184 = tail call double @llvm.fmuladd.f64(double %179, double 0xBFC5555555555549, double %183), !dbg !1821
  %185 = fsub double %49, %184, !dbg !1822
  br label %186, !dbg !1823

186:                                              ; preds = %170, %163, %77, %70, %50, %28, %22, %8, %160, %115, %44
  %187 = phi double [ %45, %44 ], [ %162, %160 ], [ %117, %115 ], [ %27, %22 ], [ %41, %28 ], [ 1.000000e+00, %8 ], [ %76, %70 ], [ %91, %77 ], [ 1.000000e+00, %50 ], [ %185, %170 ], [ %49, %163 ], !dbg !1824
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !1825
  ret double %187, !dbg !1825
}

; Function Attrs: nofree nosync nounwind memory(argmem: write) uwtable
define internal fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr nocapture noundef writeonly %1) unnamed_addr #6 !dbg !644 {
  %3 = alloca [20 x i32], align 4, !DIAssignID !1826
  %4 = alloca [20 x double], align 8, !DIAssignID !1827
  %5 = alloca [20 x double], align 8, !DIAssignID !1828
  %6 = alloca [20 x double], align 8, !DIAssignID !1829
  %7 = alloca [3 x double], align 8, !DIAssignID !1830
  call void @llvm.dbg.assign(metadata i1 undef, metadata !656, metadata !DIExpression(), metadata !1830, metadata ptr %7, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata double %0, metadata !649, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !650, metadata !DIExpression()), !dbg !1831
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %7) #11, !dbg !1832
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !651, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1833
  %8 = bitcast double %0 to i64, !dbg !1835
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !884, metadata !DIExpression()), !dbg !1833
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !668, metadata !DIExpression()), !dbg !1836
  %9 = lshr i64 %8, 32, !dbg !1837
  %10 = trunc i64 %9 to i32, !dbg !1837
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !666, metadata !DIExpression()), !dbg !1831
  %11 = and i32 %10, 2147483647, !dbg !1838
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !665, metadata !DIExpression()), !dbg !1831
  %12 = icmp ult i32 %11, 1072243196, !dbg !1839
  br i1 %12, label %13, label %15, !dbg !1841

13:                                               ; preds = %2
  store double %0, ptr %1, align 8, !dbg !1842, !tbaa !1443
  %14 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1844
  store double 0.000000e+00, ptr %14, align 8, !dbg !1845, !tbaa !1443
  br label %853, !dbg !1846

15:                                               ; preds = %2
  %16 = icmp ult i32 %11, 1073928572, !dbg !1847
  br i1 %16, label %17, label %46, !dbg !1849

17:                                               ; preds = %15
  %18 = icmp sgt i32 %10, 0, !dbg !1850
  %19 = icmp eq i32 %11, 1073291771, !dbg !1853
  br i1 %18, label %20, label %33, !dbg !1854

20:                                               ; preds = %17
  %21 = fadd double %0, 0xBFF921FB54400000, !dbg !1855
  tail call void @llvm.dbg.value(metadata double %21, metadata !651, metadata !DIExpression()), !dbg !1831
  br i1 %19, label %27, label %22, !dbg !1857

22:                                               ; preds = %20
  %23 = fadd double %21, 0xBDD0B4611A626331, !dbg !1858
  store double %23, ptr %1, align 8, !dbg !1861, !tbaa !1443
  %24 = fsub double %21, %23, !dbg !1862
  %25 = fadd double %24, 0xBDD0B4611A626331, !dbg !1863
  %26 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1864
  store double %25, ptr %26, align 8, !dbg !1865, !tbaa !1443
  br label %853, !dbg !1866

27:                                               ; preds = %20
  %28 = fadd double %21, 0xBDD0B4611A600000, !dbg !1867
  tail call void @llvm.dbg.value(metadata double %28, metadata !651, metadata !DIExpression()), !dbg !1831
  %29 = fadd double %28, 0xBBA3198A2E037073, !dbg !1869
  store double %29, ptr %1, align 8, !dbg !1870, !tbaa !1443
  %30 = fsub double %28, %29, !dbg !1871
  %31 = fadd double %30, 0xBBA3198A2E037073, !dbg !1872
  %32 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1873
  store double %31, ptr %32, align 8, !dbg !1874, !tbaa !1443
  br label %853

33:                                               ; preds = %17
  %34 = fadd double %0, 0x3FF921FB54400000, !dbg !1875
  tail call void @llvm.dbg.value(metadata double %34, metadata !651, metadata !DIExpression()), !dbg !1831
  br i1 %19, label %40, label %35, !dbg !1877

35:                                               ; preds = %33
  %36 = fadd double %34, 0x3DD0B4611A626331, !dbg !1878
  store double %36, ptr %1, align 8, !dbg !1881, !tbaa !1443
  %37 = fsub double %34, %36, !dbg !1882
  %38 = fadd double %37, 0x3DD0B4611A626331, !dbg !1883
  %39 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1884
  store double %38, ptr %39, align 8, !dbg !1885, !tbaa !1443
  br label %853, !dbg !1886

40:                                               ; preds = %33
  %41 = fadd double %34, 0x3DD0B4611A600000, !dbg !1887
  tail call void @llvm.dbg.value(metadata double %41, metadata !651, metadata !DIExpression()), !dbg !1831
  %42 = fadd double %41, 0x3BA3198A2E037073, !dbg !1889
  store double %42, ptr %1, align 8, !dbg !1890, !tbaa !1443
  %43 = fsub double %41, %42, !dbg !1891
  %44 = fadd double %43, 0x3BA3198A2E037073, !dbg !1892
  %45 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1893
  store double %44, ptr %45, align 8, !dbg !1894, !tbaa !1443
  br label %853

46:                                               ; preds = %15
  %47 = icmp ult i32 %11, 1094263292, !dbg !1895
  br i1 %47, label %48, label %112, !dbg !1896

48:                                               ; preds = %46
  %49 = tail call double @llvm.fabs.f64(double %0), !dbg !1897
  tail call void @llvm.dbg.value(metadata double %49, metadata !653, metadata !DIExpression()), !dbg !1831
  %50 = tail call double @llvm.fmuladd.f64(double %49, double 0x3FE45F306DC9C883, double 5.000000e-01), !dbg !1898
  %51 = fptosi double %50 to i32, !dbg !1899
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !664, metadata !DIExpression()), !dbg !1831
  %52 = sitofp i32 %51 to double, !dbg !1900
  tail call void @llvm.dbg.value(metadata double %52, metadata !655, metadata !DIExpression()), !dbg !1831
  %53 = fneg double %52, !dbg !1901
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FF921FB54400000, double %49), !dbg !1901
  tail call void @llvm.dbg.value(metadata double %54, metadata !654, metadata !DIExpression()), !dbg !1831
  %55 = fmul double %52, 0x3DD0B4611A626331, !dbg !1902
  tail call void @llvm.dbg.value(metadata double %55, metadata !652, metadata !DIExpression()), !dbg !1831
  %56 = icmp slt i32 %51, 32, !dbg !1903
  br i1 %56, label %57, label %65, !dbg !1904

57:                                               ; preds = %48
  %58 = add nsw i32 %51, -1, !dbg !1905
  %59 = sext i32 %58 to i64, !dbg !1906
  %60 = getelementptr inbounds [32 x i32], ptr @__ieee754_rem_pio2.npio2_hw, i64 0, i64 %59, !dbg !1906
  %61 = load i32, ptr %60, align 4, !dbg !1906, !tbaa !1907
  %62 = icmp eq i32 %11, %61, !dbg !1909
  br i1 %62, label %65, label %63, !dbg !1910

63:                                               ; preds = %57
  %64 = fsub double %54, %55, !dbg !1911
  br label %96, !dbg !1913

65:                                               ; preds = %57, %48
  %66 = lshr i32 %11, 20
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !662, metadata !DIExpression()), !dbg !1831
  %67 = fsub double %54, %55, !dbg !1914
  store double %67, ptr %1, align 8, !dbg !1915, !tbaa !1443
  tail call void @llvm.dbg.value(metadata double %67, metadata !879, metadata !DIExpression()), !dbg !1916
  %68 = bitcast double %67 to i64, !dbg !1918
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !884, metadata !DIExpression()), !dbg !1916
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !675, metadata !DIExpression()), !dbg !1919
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !670, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1920
  %69 = lshr i64 %68, 52, !dbg !1921
  %70 = trunc i64 %69 to i32, !dbg !1921
  %71 = and i32 %70, 2047, !dbg !1922
  %72 = sub nsw i32 %66, %71, !dbg !1923
  tail call void @llvm.dbg.value(metadata i32 %72, metadata !661, metadata !DIExpression()), !dbg !1831
  %73 = icmp sgt i32 %72, 16, !dbg !1924
  br i1 %73, label %74, label %100, !dbg !1925

74:                                               ; preds = %65
  tail call void @llvm.dbg.value(metadata double %54, metadata !653, metadata !DIExpression()), !dbg !1831
  %75 = fmul double %52, 0x3DD0B4611A600000, !dbg !1926
  tail call void @llvm.dbg.value(metadata double %75, metadata !652, metadata !DIExpression()), !dbg !1831
  %76 = fsub double %54, %75, !dbg !1927
  tail call void @llvm.dbg.value(metadata double %76, metadata !654, metadata !DIExpression()), !dbg !1831
  %77 = fsub double %54, %76, !dbg !1928
  %78 = fsub double %77, %75, !dbg !1929
  %79 = fneg double %78, !dbg !1930
  %80 = tail call double @llvm.fmuladd.f64(double %52, double 0x3BA3198A2E037073, double %79), !dbg !1930
  tail call void @llvm.dbg.value(metadata double %80, metadata !652, metadata !DIExpression()), !dbg !1831
  %81 = fsub double %76, %80, !dbg !1931
  store double %81, ptr %1, align 8, !dbg !1932, !tbaa !1443
  tail call void @llvm.dbg.value(metadata double %81, metadata !879, metadata !DIExpression()), !dbg !1933
  %82 = bitcast double %81 to i64, !dbg !1935
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !884, metadata !DIExpression()), !dbg !1933
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !677, metadata !DIExpression()), !dbg !1936
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !670, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1920
  %83 = lshr i64 %82, 52, !dbg !1937
  %84 = trunc i64 %83 to i32, !dbg !1937
  %85 = and i32 %84, 2047, !dbg !1938
  %86 = sub nsw i32 %66, %85, !dbg !1939
  tail call void @llvm.dbg.value(metadata i32 %86, metadata !661, metadata !DIExpression()), !dbg !1831
  %87 = icmp sgt i32 %86, 49, !dbg !1940
  br i1 %87, label %88, label %100, !dbg !1942

88:                                               ; preds = %74
  tail call void @llvm.dbg.value(metadata double %76, metadata !653, metadata !DIExpression()), !dbg !1831
  %89 = fmul double %52, 0x3BA3198A2E000000, !dbg !1943
  tail call void @llvm.dbg.value(metadata double %89, metadata !652, metadata !DIExpression()), !dbg !1831
  %90 = fsub double %76, %89, !dbg !1945
  tail call void @llvm.dbg.value(metadata double %90, metadata !654, metadata !DIExpression()), !dbg !1831
  %91 = fsub double %76, %90, !dbg !1946
  %92 = fsub double %91, %89, !dbg !1947
  %93 = fneg double %92, !dbg !1948
  %94 = tail call double @llvm.fmuladd.f64(double %52, double 0x397B839A252049C1, double %93), !dbg !1948
  tail call void @llvm.dbg.value(metadata double %94, metadata !652, metadata !DIExpression()), !dbg !1831
  %95 = fsub double %90, %94, !dbg !1949
  br label %96, !dbg !1950

96:                                               ; preds = %63, %88
  %97 = phi double [ %95, %88 ], [ %64, %63 ]
  %98 = phi double [ %90, %88 ], [ %54, %63 ]
  %99 = phi double [ %94, %88 ], [ %55, %63 ]
  store double %97, ptr %1, align 8, !dbg !1951, !tbaa !1443
  br label %100, !dbg !1952

100:                                              ; preds = %96, %65, %74
  %101 = phi double [ %81, %74 ], [ %67, %65 ], [ %97, %96 ], !dbg !1953
  %102 = phi double [ %76, %74 ], [ %54, %65 ], [ %98, %96 ], !dbg !1954
  %103 = phi double [ %80, %74 ], [ %55, %65 ], [ %99, %96 ], !dbg !1954
  tail call void @llvm.dbg.value(metadata double %103, metadata !652, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata double %102, metadata !654, metadata !DIExpression()), !dbg !1831
  %104 = fsub double %102, %101, !dbg !1952
  %105 = fsub double %104, %103, !dbg !1955
  %106 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1956
  store double %105, ptr %106, align 8, !dbg !1957, !tbaa !1443
  %107 = icmp slt i64 %8, 0, !dbg !1958
  br i1 %107, label %108, label %853, !dbg !1960

108:                                              ; preds = %100
  %109 = fneg double %101, !dbg !1961
  store double %109, ptr %1, align 8, !dbg !1963, !tbaa !1443
  %110 = fneg double %105, !dbg !1964
  store double %110, ptr %106, align 8, !dbg !1965, !tbaa !1443
  %111 = sub nsw i32 0, %51, !dbg !1966
  br label %853, !dbg !1967

112:                                              ; preds = %46
  %113 = icmp ugt i32 %11, 2146435071, !dbg !1968
  br i1 %113, label %114, label %117, !dbg !1970

114:                                              ; preds = %112
  %115 = fsub double %0, %0, !dbg !1971
  %116 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1973
  store double %115, ptr %116, align 8, !dbg !1974, !tbaa !1443
  store double %115, ptr %1, align 8, !dbg !1975, !tbaa !1443
  br label %853, !dbg !1976

117:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !1977
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !884, metadata !DIExpression()), !dbg !1977
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !667, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1831
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !879, metadata !DIExpression()), !dbg !1979
  tail call void @llvm.dbg.value(metadata i64 0, metadata !884, metadata !DIExpression()), !dbg !1979
  tail call void @llvm.dbg.value(metadata i64 0, metadata !683, metadata !DIExpression()), !dbg !1981
  %118 = and i64 %8, 4294967295, !dbg !1982
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !683, metadata !DIExpression()), !dbg !1981
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !953, metadata !DIExpression()), !dbg !1983
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !958, metadata !DIExpression()), !dbg !1983
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !651, metadata !DIExpression()), !dbg !1831
  %119 = lshr i32 %11, 20
  %120 = add nsw i32 %119, -1046, !dbg !1985
  tail call void @llvm.dbg.value(metadata i32 %120, metadata !660, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !879, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !884, metadata !DIExpression()), !dbg !1986
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !685, metadata !DIExpression()), !dbg !1988
  %121 = shl nsw i32 %120, 20, !dbg !1989
  %122 = sub nsw i32 %11, %121, !dbg !1989
  %123 = sext i32 %122 to i64, !dbg !1989
  %124 = shl nsw i64 %123, 32, !dbg !1989
  %125 = or disjoint i64 %124, %118, !dbg !1989
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !685, metadata !DIExpression()), !dbg !1988
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !953, metadata !DIExpression()), !dbg !1990
  %126 = bitcast i64 %125 to double, !dbg !1992
  tail call void @llvm.dbg.value(metadata double %126, metadata !958, metadata !DIExpression()), !dbg !1990
  tail call void @llvm.dbg.value(metadata double %126, metadata !651, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 0, metadata !661, metadata !DIExpression()), !dbg !1831
  %127 = fptosi double %126 to i32, !dbg !1993
  %128 = sitofp i32 %127 to double, !dbg !1997
  store double %128, ptr %7, align 8, !dbg !1998, !tbaa !1443
  %129 = fsub double %126, %128, !dbg !1999
  %130 = fmul double %129, 0x4170000000000000, !dbg !2000
  tail call void @llvm.dbg.value(metadata double %130, metadata !651, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 1, metadata !661, metadata !DIExpression()), !dbg !1831
  %131 = fptosi double %130 to i32, !dbg !1993
  %132 = sitofp i32 %131 to double, !dbg !1997
  %133 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 1, !dbg !2001
  store double %132, ptr %133, align 8, !dbg !1998, !tbaa !1443
  %134 = fsub double %130, %132, !dbg !1999
  %135 = fmul double %134, 0x4170000000000000, !dbg !2000
  tail call void @llvm.dbg.value(metadata double %135, metadata !651, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 2, metadata !661, metadata !DIExpression()), !dbg !1831
  %136 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 2, !dbg !2002
  store double %135, ptr %136, align 8, !dbg !2003, !tbaa !1443, !DIAssignID !2004
  call void @llvm.dbg.assign(metadata double %135, metadata !656, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !2004, metadata ptr %136, metadata !DIExpression()), !dbg !1831
  tail call void @llvm.dbg.value(metadata i32 3, metadata !663, metadata !DIExpression()), !dbg !1831
  br label %137, !dbg !2005

137:                                              ; preds = %137, %117
  %138 = phi i32 [ %144, %137 ], [ 0, %117 ]
  %139 = phi i64 [ %140, %137 ], [ 3, %117 ], !dbg !1831
  tail call void @llvm.dbg.value(metadata i64 %139, metadata !663, metadata !DIExpression()), !dbg !1831
  %140 = add nsw i64 %139, -1, !dbg !2006
  %141 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 %140, !dbg !2007
  %142 = load double, ptr %141, align 8, !dbg !2007, !tbaa !1443
  %143 = fcmp oeq double %142, 0.000000e+00, !dbg !2008
  %144 = add i32 %138, 1, !dbg !2005
  br i1 %143, label %137, label %145, !dbg !2005, !llvm.loop !2009

145:                                              ; preds = %137
  %146 = trunc i64 %139 to i32, !dbg !2012
  call void @llvm.dbg.assign(metadata i1 undef, metadata !736, metadata !DIExpression(), metadata !1826, metadata ptr %3, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.assign(metadata i1 undef, metadata !748, metadata !DIExpression(), metadata !1827, metadata ptr %4, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.assign(metadata i1 undef, metadata !750, metadata !DIExpression(), metadata !1828, metadata ptr %5, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.assign(metadata i1 undef, metadata !751, metadata !DIExpression(), metadata !1829, metadata ptr %6, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata ptr %7, metadata !723, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata ptr %1, metadata !724, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %120, metadata !725, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %146, metadata !726, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 2, metadata !727, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata ptr @__ieee754_rem_pio2.two_over_pi, metadata !728, metadata !DIExpression()), !dbg !2014
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %3) #11, !dbg !2012
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %4) #11, !dbg !2015
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %5) #11, !dbg !2015
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %6) #11, !dbg !2015
  call void @llvm.dbg.value(metadata i32 4, metadata !733, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 4, metadata !732, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %140, metadata !730, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2014
  %147 = add nsw i32 %119, -1049, !dbg !2016
  %148 = sdiv i32 %147, 24, !dbg !2017
  call void @llvm.dbg.value(metadata i32 %148, metadata !731, metadata !DIExpression()), !dbg !2014
  %149 = mul nsw i32 %148, -24, !dbg !2018
  %150 = add nsw i32 %149, %120, !dbg !2018
  %151 = add nsw i32 %150, -24, !dbg !2019
  call void @llvm.dbg.value(metadata i32 %151, metadata !744, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %146, metadata !743, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i64 %140), metadata !741, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_minus, DW_OP_stack_value)), !dbg !2014
  %152 = icmp slt i32 %146, -3, !dbg !2020
  br i1 %152, label %399, label %153, !dbg !2023

153:                                              ; preds = %145
  %154 = trunc i64 %140 to i32, !dbg !2012
  call void @llvm.dbg.value(metadata i32 %154, metadata !730, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i32 %154), metadata !741, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2014
  %155 = add i32 %146, 3, !dbg !2024
  call void @llvm.dbg.value(metadata i32 %155, metadata !743, metadata !DIExpression()), !dbg !2014
  %156 = sub nsw i32 %148, %154, !dbg !2025
  call void @llvm.dbg.value(metadata i32 %156, metadata !741, metadata !DIExpression()), !dbg !2014
  %157 = tail call i32 @llvm.smax.i32(i32 %155, i32 0), !dbg !2023
  %158 = add nuw i32 %157, 1, !dbg !2023
  %159 = zext i32 %158 to i64, !dbg !2020
  br label %162, !dbg !2023

160:                                              ; preds = %171
  %161 = icmp sgt i32 %146, 0
  call void @llvm.dbg.value(metadata i64 0, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  br i1 %161, label %177, label %399, !dbg !2026

162:                                              ; preds = %171, %153
  %163 = phi i64 [ 0, %153 ], [ %174, %171 ]
  %164 = phi i32 [ %156, %153 ], [ %175, %171 ]
  call void @llvm.dbg.value(metadata i32 %164, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %163, metadata !740, metadata !DIExpression()), !dbg !2014
  %165 = icmp slt i32 %164, 0, !dbg !2031
  br i1 %165, label %171, label %166, !dbg !2033

166:                                              ; preds = %162
  %167 = zext nneg i32 %164 to i64
  %168 = getelementptr inbounds i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %167, !dbg !2034
  %169 = load i32, ptr %168, align 4, !dbg !2034, !tbaa !1907
  %170 = sitofp i32 %169 to double, !dbg !2035
  br label %171, !dbg !2033

171:                                              ; preds = %166, %162
  %172 = phi double [ %170, %166 ], [ 0.000000e+00, %162 ], !dbg !2033
  %173 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %163, !dbg !2036
  store double %172, ptr %173, align 8, !dbg !2037, !tbaa !1443
  %174 = add nuw nsw i64 %163, 1, !dbg !2038
  call void @llvm.dbg.value(metadata i64 %174, metadata !740, metadata !DIExpression()), !dbg !2014
  %175 = add nsw i32 %164, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i32 %175, metadata !741, metadata !DIExpression()), !dbg !2014
  %176 = icmp eq i64 %174, %159, !dbg !2020
  br i1 %176, label %160, label %162, !dbg !2023, !llvm.loop !2040

177:                                              ; preds = %160
  %178 = and i64 %139, 4294967295, !dbg !2042
  %179 = icmp ult i64 %178, 8, !dbg !2026
  br i1 %179, label %215, label %180, !dbg !2026

180:                                              ; preds = %177
  %181 = add nsw i64 %178, -1, !dbg !2026
  %182 = trunc i64 %181 to i32, !dbg !2026
  %183 = sub i32 %154, %182, !dbg !2026
  %184 = icmp sgt i32 %183, %154, !dbg !2026
  %185 = icmp ugt i64 %181, 4294967295, !dbg !2026
  %186 = or i1 %184, %185, !dbg !2026
  br i1 %186, label %215, label %187

187:                                              ; preds = %180
  %188 = and i64 %139, 3, !dbg !2026
  %189 = sub nsw i64 %178, %188, !dbg !2026
  br label %190, !dbg !2026

190:                                              ; preds = %190, %187
  %191 = phi i64 [ 0, %187 ], [ %211, %190 ], !dbg !2044
  %192 = phi double [ 0.000000e+00, %187 ], [ %210, %190 ]
  %193 = getelementptr inbounds double, ptr %7, i64 %191, !dbg !2045
  %194 = getelementptr inbounds double, ptr %193, i64 2, !dbg !2045
  %195 = load <2 x double>, ptr %193, align 8, !dbg !2045, !tbaa !1443
  %196 = load <2 x double>, ptr %194, align 8, !dbg !2045, !tbaa !1443
  %197 = sub i64 %140, %191, !dbg !2046
  %198 = shl i64 %197, 32, !dbg !2047
  %199 = ashr exact i64 %198, 32, !dbg !2047
  %200 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %199, !dbg !2047
  %201 = getelementptr inbounds double, ptr %200, i64 -1, !dbg !2047
  %202 = getelementptr inbounds double, ptr %200, i64 -3, !dbg !2047
  %203 = load <2 x double>, ptr %201, align 8, !dbg !2047, !tbaa !1443
  %204 = shufflevector <2 x double> %203, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %205 = load <2 x double>, ptr %202, align 8, !dbg !2047, !tbaa !1443
  %206 = shufflevector <2 x double> %205, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %207 = fmul <2 x double> %195, %204
  %208 = fmul <2 x double> %196, %206
  %209 = tail call double @llvm.vector.reduce.fadd.v2f64(double %192, <2 x double> %207)
  %210 = tail call double @llvm.vector.reduce.fadd.v2f64(double %209, <2 x double> %208)
  %211 = add nuw i64 %191, 4, !dbg !2044
  %212 = icmp eq i64 %211, %189, !dbg !2044
  br i1 %212, label %213, label %190, !dbg !2044, !llvm.loop !2048

213:                                              ; preds = %190
  %214 = icmp eq i64 %188, 0, !dbg !2026
  br i1 %214, label %231, label %215, !dbg !2026

215:                                              ; preds = %180, %177, %213
  %216 = phi i64 [ 0, %180 ], [ 0, %177 ], [ %189, %213 ]
  %217 = phi double [ 0.000000e+00, %180 ], [ 0.000000e+00, %177 ], [ %210, %213 ]
  br label %218, !dbg !2026

218:                                              ; preds = %215, %218
  %219 = phi i64 [ %229, %218 ], [ %216, %215 ]
  %220 = phi double [ %228, %218 ], [ %217, %215 ]
  call void @llvm.dbg.value(metadata double %220, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %219, metadata !741, metadata !DIExpression()), !dbg !2014
  %221 = getelementptr inbounds double, ptr %7, i64 %219, !dbg !2045
  %222 = load double, ptr %221, align 8, !dbg !2045, !tbaa !1443
  %223 = sub i64 %140, %219, !dbg !2046
  %224 = shl i64 %223, 32, !dbg !2047
  %225 = ashr exact i64 %224, 32, !dbg !2047
  %226 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %225, !dbg !2047
  %227 = load double, ptr %226, align 8, !dbg !2047, !tbaa !1443
  %228 = tail call double @llvm.fmuladd.f64(double %222, double %227, double %220), !dbg !2052
  call void @llvm.dbg.value(metadata double %228, metadata !747, metadata !DIExpression()), !dbg !2014
  %229 = add nuw nsw i64 %219, 1, !dbg !2044
  call void @llvm.dbg.value(metadata i64 %229, metadata !741, metadata !DIExpression()), !dbg !2014
  %230 = icmp eq i64 %229, %178, !dbg !2042
  br i1 %230, label %231, label %218, !dbg !2026, !llvm.loop !2053

231:                                              ; preds = %218, %213
  %232 = phi double [ %210, %213 ], [ %228, %218 ], !dbg !2052
  store double %232, ptr %6, align 8, !dbg !2054, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 1, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  %233 = icmp ult i64 %178, 8, !dbg !2026
  br i1 %233, label %269, label %234, !dbg !2026

234:                                              ; preds = %231
  %235 = add nsw i64 %178, -1, !dbg !2026
  %236 = trunc i64 %235 to i32, !dbg !2026
  %237 = sub i32 %146, %236, !dbg !2026
  %238 = icmp sgt i32 %237, %146, !dbg !2026
  %239 = icmp ugt i64 %235, 4294967295, !dbg !2026
  %240 = or i1 %238, %239, !dbg !2026
  br i1 %240, label %269, label %241

241:                                              ; preds = %234
  %242 = and i64 %139, 3, !dbg !2026
  %243 = sub nsw i64 %178, %242, !dbg !2026
  br label %244, !dbg !2026

244:                                              ; preds = %244, %241
  %245 = phi i64 [ 0, %241 ], [ %265, %244 ], !dbg !2044
  %246 = phi double [ 0.000000e+00, %241 ], [ %264, %244 ]
  %247 = getelementptr inbounds double, ptr %7, i64 %245, !dbg !2045
  %248 = getelementptr inbounds double, ptr %247, i64 2, !dbg !2045
  %249 = load <2 x double>, ptr %247, align 8, !dbg !2045, !tbaa !1443
  %250 = load <2 x double>, ptr %248, align 8, !dbg !2045, !tbaa !1443
  %251 = sub i64 %139, %245, !dbg !2046
  %252 = shl i64 %251, 32, !dbg !2047
  %253 = ashr exact i64 %252, 32, !dbg !2047
  %254 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %253, !dbg !2047
  %255 = getelementptr inbounds double, ptr %254, i64 -1, !dbg !2047
  %256 = getelementptr inbounds double, ptr %254, i64 -3, !dbg !2047
  %257 = load <2 x double>, ptr %255, align 8, !dbg !2047, !tbaa !1443
  %258 = shufflevector <2 x double> %257, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %259 = load <2 x double>, ptr %256, align 8, !dbg !2047, !tbaa !1443
  %260 = shufflevector <2 x double> %259, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %261 = fmul <2 x double> %249, %258
  %262 = fmul <2 x double> %250, %260
  %263 = tail call double @llvm.vector.reduce.fadd.v2f64(double %246, <2 x double> %261)
  %264 = tail call double @llvm.vector.reduce.fadd.v2f64(double %263, <2 x double> %262)
  %265 = add nuw i64 %245, 4, !dbg !2044
  %266 = icmp eq i64 %265, %243, !dbg !2044
  br i1 %266, label %267, label %244, !dbg !2044, !llvm.loop !2055

267:                                              ; preds = %244
  %268 = icmp eq i64 %242, 0, !dbg !2026
  br i1 %268, label %285, label %269, !dbg !2026

269:                                              ; preds = %234, %231, %267
  %270 = phi i64 [ 0, %234 ], [ 0, %231 ], [ %243, %267 ]
  %271 = phi double [ 0.000000e+00, %234 ], [ 0.000000e+00, %231 ], [ %264, %267 ]
  br label %272, !dbg !2026

272:                                              ; preds = %269, %272
  %273 = phi i64 [ %283, %272 ], [ %270, %269 ]
  %274 = phi double [ %282, %272 ], [ %271, %269 ]
  call void @llvm.dbg.value(metadata double %274, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %273, metadata !741, metadata !DIExpression()), !dbg !2014
  %275 = getelementptr inbounds double, ptr %7, i64 %273, !dbg !2045
  %276 = load double, ptr %275, align 8, !dbg !2045, !tbaa !1443
  %277 = sub i64 %139, %273, !dbg !2046
  %278 = shl i64 %277, 32, !dbg !2047
  %279 = ashr exact i64 %278, 32, !dbg !2047
  %280 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %279, !dbg !2047
  %281 = load double, ptr %280, align 8, !dbg !2047, !tbaa !1443
  %282 = tail call double @llvm.fmuladd.f64(double %276, double %281, double %274), !dbg !2052
  call void @llvm.dbg.value(metadata double %282, metadata !747, metadata !DIExpression()), !dbg !2014
  %283 = add nuw nsw i64 %273, 1, !dbg !2044
  call void @llvm.dbg.value(metadata i64 %283, metadata !741, metadata !DIExpression()), !dbg !2014
  %284 = icmp eq i64 %283, %178, !dbg !2042
  br i1 %284, label %285, label %272, !dbg !2026, !llvm.loop !2056

285:                                              ; preds = %272, %267
  %286 = phi double [ %264, %267 ], [ %282, %272 ], !dbg !2052
  %287 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 1, !dbg !2057
  store double %286, ptr %287, align 8, !dbg !2054, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 2, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  %288 = add i64 %139, 1
  %289 = icmp ult i64 %178, 10, !dbg !2026
  br i1 %289, label %326, label %290, !dbg !2026

290:                                              ; preds = %285
  %291 = add nsw i64 %178, -1, !dbg !2026
  %292 = sub i32 4, %138, !dbg !2026
  %293 = trunc i64 %291 to i32, !dbg !2026
  %294 = sub i32 %292, %293, !dbg !2026
  %295 = icmp sgt i32 %294, %292, !dbg !2026
  %296 = icmp ugt i64 %291, 4294967295, !dbg !2026
  %297 = or i1 %295, %296, !dbg !2026
  br i1 %297, label %326, label %298

298:                                              ; preds = %290
  %299 = and i64 %139, 3, !dbg !2026
  %300 = sub nsw i64 %178, %299, !dbg !2026
  br label %301, !dbg !2026

301:                                              ; preds = %301, %298
  %302 = phi i64 [ 0, %298 ], [ %322, %301 ], !dbg !2044
  %303 = phi double [ 0.000000e+00, %298 ], [ %321, %301 ]
  %304 = getelementptr inbounds double, ptr %7, i64 %302, !dbg !2045
  %305 = getelementptr inbounds double, ptr %304, i64 2, !dbg !2045
  %306 = load <2 x double>, ptr %304, align 8, !dbg !2045, !tbaa !1443
  %307 = load <2 x double>, ptr %305, align 8, !dbg !2045, !tbaa !1443
  %308 = sub i64 %288, %302, !dbg !2046
  %309 = shl i64 %308, 32, !dbg !2047
  %310 = ashr exact i64 %309, 32, !dbg !2047
  %311 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %310, !dbg !2047
  %312 = getelementptr inbounds double, ptr %311, i64 -1, !dbg !2047
  %313 = getelementptr inbounds double, ptr %311, i64 -3, !dbg !2047
  %314 = load <2 x double>, ptr %312, align 8, !dbg !2047, !tbaa !1443
  %315 = shufflevector <2 x double> %314, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %316 = load <2 x double>, ptr %313, align 8, !dbg !2047, !tbaa !1443
  %317 = shufflevector <2 x double> %316, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %318 = fmul <2 x double> %306, %315
  %319 = fmul <2 x double> %307, %317
  %320 = tail call double @llvm.vector.reduce.fadd.v2f64(double %303, <2 x double> %318)
  %321 = tail call double @llvm.vector.reduce.fadd.v2f64(double %320, <2 x double> %319)
  %322 = add nuw i64 %302, 4, !dbg !2044
  %323 = icmp eq i64 %322, %300, !dbg !2044
  br i1 %323, label %324, label %301, !dbg !2044, !llvm.loop !2058

324:                                              ; preds = %301
  %325 = icmp eq i64 %299, 0, !dbg !2026
  br i1 %325, label %342, label %326, !dbg !2026

326:                                              ; preds = %290, %285, %324
  %327 = phi i64 [ 0, %290 ], [ 0, %285 ], [ %300, %324 ]
  %328 = phi double [ 0.000000e+00, %290 ], [ 0.000000e+00, %285 ], [ %321, %324 ]
  br label %329, !dbg !2026

329:                                              ; preds = %326, %329
  %330 = phi i64 [ %340, %329 ], [ %327, %326 ]
  %331 = phi double [ %339, %329 ], [ %328, %326 ]
  call void @llvm.dbg.value(metadata double %331, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %330, metadata !741, metadata !DIExpression()), !dbg !2014
  %332 = getelementptr inbounds double, ptr %7, i64 %330, !dbg !2045
  %333 = load double, ptr %332, align 8, !dbg !2045, !tbaa !1443
  %334 = sub i64 %288, %330, !dbg !2046
  %335 = shl i64 %334, 32, !dbg !2047
  %336 = ashr exact i64 %335, 32, !dbg !2047
  %337 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %336, !dbg !2047
  %338 = load double, ptr %337, align 8, !dbg !2047, !tbaa !1443
  %339 = tail call double @llvm.fmuladd.f64(double %333, double %338, double %331), !dbg !2052
  call void @llvm.dbg.value(metadata double %339, metadata !747, metadata !DIExpression()), !dbg !2014
  %340 = add nuw nsw i64 %330, 1, !dbg !2044
  call void @llvm.dbg.value(metadata i64 %340, metadata !741, metadata !DIExpression()), !dbg !2014
  %341 = icmp eq i64 %340, %178, !dbg !2042
  br i1 %341, label %342, label %329, !dbg !2026, !llvm.loop !2059

342:                                              ; preds = %329, %324
  %343 = phi double [ %321, %324 ], [ %339, %329 ], !dbg !2052
  %344 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 2, !dbg !2057
  store double %343, ptr %344, align 8, !dbg !2054, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 3, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  %345 = add i64 %139, 2
  %346 = icmp ult i64 %178, 10, !dbg !2026
  br i1 %346, label %383, label %347, !dbg !2026

347:                                              ; preds = %342
  %348 = add nsw i64 %178, -1, !dbg !2026
  %349 = sub i32 5, %138, !dbg !2026
  %350 = trunc i64 %348 to i32, !dbg !2026
  %351 = sub i32 %349, %350, !dbg !2026
  %352 = icmp sgt i32 %351, %349, !dbg !2026
  %353 = icmp ugt i64 %348, 4294967295, !dbg !2026
  %354 = or i1 %352, %353, !dbg !2026
  br i1 %354, label %383, label %355

355:                                              ; preds = %347
  %356 = and i64 %139, 3, !dbg !2026
  %357 = sub nsw i64 %178, %356, !dbg !2026
  br label %358, !dbg !2026

358:                                              ; preds = %358, %355
  %359 = phi i64 [ 0, %355 ], [ %379, %358 ], !dbg !2044
  %360 = phi double [ 0.000000e+00, %355 ], [ %378, %358 ]
  %361 = getelementptr inbounds double, ptr %7, i64 %359, !dbg !2045
  %362 = getelementptr inbounds double, ptr %361, i64 2, !dbg !2045
  %363 = load <2 x double>, ptr %361, align 8, !dbg !2045, !tbaa !1443
  %364 = load <2 x double>, ptr %362, align 8, !dbg !2045, !tbaa !1443
  %365 = sub i64 %345, %359, !dbg !2046
  %366 = shl i64 %365, 32, !dbg !2047
  %367 = ashr exact i64 %366, 32, !dbg !2047
  %368 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %367, !dbg !2047
  %369 = getelementptr inbounds double, ptr %368, i64 -1, !dbg !2047
  %370 = getelementptr inbounds double, ptr %368, i64 -3, !dbg !2047
  %371 = load <2 x double>, ptr %369, align 8, !dbg !2047, !tbaa !1443
  %372 = shufflevector <2 x double> %371, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %373 = load <2 x double>, ptr %370, align 8, !dbg !2047, !tbaa !1443
  %374 = shufflevector <2 x double> %373, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %375 = fmul <2 x double> %363, %372
  %376 = fmul <2 x double> %364, %374
  %377 = tail call double @llvm.vector.reduce.fadd.v2f64(double %360, <2 x double> %375)
  %378 = tail call double @llvm.vector.reduce.fadd.v2f64(double %377, <2 x double> %376)
  %379 = add nuw i64 %359, 4, !dbg !2044
  %380 = icmp eq i64 %379, %357, !dbg !2044
  br i1 %380, label %381, label %358, !dbg !2044, !llvm.loop !2060

381:                                              ; preds = %358
  %382 = icmp eq i64 %356, 0, !dbg !2026
  br i1 %382, label %401, label %383, !dbg !2026

383:                                              ; preds = %347, %342, %381
  %384 = phi i64 [ 0, %347 ], [ 0, %342 ], [ %357, %381 ]
  %385 = phi double [ 0.000000e+00, %347 ], [ 0.000000e+00, %342 ], [ %378, %381 ]
  br label %386, !dbg !2026

386:                                              ; preds = %383, %386
  %387 = phi i64 [ %397, %386 ], [ %384, %383 ]
  %388 = phi double [ %396, %386 ], [ %385, %383 ]
  call void @llvm.dbg.value(metadata double %388, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %387, metadata !741, metadata !DIExpression()), !dbg !2014
  %389 = getelementptr inbounds double, ptr %7, i64 %387, !dbg !2045
  %390 = load double, ptr %389, align 8, !dbg !2045, !tbaa !1443
  %391 = sub i64 %345, %387, !dbg !2046
  %392 = shl i64 %391, 32, !dbg !2047
  %393 = ashr exact i64 %392, 32, !dbg !2047
  %394 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %393, !dbg !2047
  %395 = load double, ptr %394, align 8, !dbg !2047, !tbaa !1443
  %396 = tail call double @llvm.fmuladd.f64(double %390, double %395, double %388), !dbg !2052
  call void @llvm.dbg.value(metadata double %396, metadata !747, metadata !DIExpression()), !dbg !2014
  %397 = add nuw nsw i64 %387, 1, !dbg !2044
  call void @llvm.dbg.value(metadata i64 %397, metadata !741, metadata !DIExpression()), !dbg !2014
  %398 = icmp eq i64 %397, %178, !dbg !2042
  br i1 %398, label %401, label %386, !dbg !2026, !llvm.loop !2061

399:                                              ; preds = %145, %160
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 4, metadata !740, metadata !DIExpression()), !dbg !2014
  %400 = and i64 %139, 4294967295
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %6, i8 0, i64 32, i1 false), !dbg !2054
  br label %456, !dbg !2026

401:                                              ; preds = %386, %381
  %402 = phi double [ %378, %381 ], [ %396, %386 ], !dbg !2052
  %403 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 3, !dbg !2057
  store double %402, ptr %403, align 8, !dbg !2054, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 4, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  %404 = icmp ult i64 %178, 10, !dbg !2026
  br i1 %404, label %440, label %405, !dbg !2026

405:                                              ; preds = %401
  %406 = add nsw i64 %178, -1, !dbg !2026
  %407 = trunc i64 %406 to i32, !dbg !2026
  %408 = sub i32 %155, %407, !dbg !2026
  %409 = icmp sgt i32 %408, %155, !dbg !2026
  %410 = icmp ugt i64 %406, 4294967295, !dbg !2026
  %411 = or i1 %409, %410, !dbg !2026
  br i1 %411, label %440, label %412

412:                                              ; preds = %405
  %413 = and i64 %139, 3, !dbg !2026
  %414 = sub nsw i64 %178, %413, !dbg !2026
  br label %415, !dbg !2026

415:                                              ; preds = %415, %412
  %416 = phi i64 [ 0, %412 ], [ %436, %415 ], !dbg !2044
  %417 = phi double [ 0.000000e+00, %412 ], [ %435, %415 ]
  %418 = trunc i64 %416 to i32, !dbg !2026
  %419 = getelementptr inbounds double, ptr %7, i64 %416, !dbg !2045
  %420 = getelementptr inbounds double, ptr %419, i64 2, !dbg !2045
  %421 = load <2 x double>, ptr %419, align 8, !dbg !2045, !tbaa !1443
  %422 = load <2 x double>, ptr %420, align 8, !dbg !2045, !tbaa !1443
  %423 = sub i32 %155, %418, !dbg !2046
  %424 = sext i32 %423 to i64, !dbg !2047
  %425 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %424, !dbg !2047
  %426 = getelementptr inbounds double, ptr %425, i64 -1, !dbg !2047
  %427 = getelementptr inbounds double, ptr %425, i64 -3, !dbg !2047
  %428 = load <2 x double>, ptr %426, align 8, !dbg !2047, !tbaa !1443
  %429 = shufflevector <2 x double> %428, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %430 = load <2 x double>, ptr %427, align 8, !dbg !2047, !tbaa !1443
  %431 = shufflevector <2 x double> %430, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2047
  %432 = fmul <2 x double> %421, %429
  %433 = fmul <2 x double> %422, %431
  %434 = tail call double @llvm.vector.reduce.fadd.v2f64(double %417, <2 x double> %432)
  %435 = tail call double @llvm.vector.reduce.fadd.v2f64(double %434, <2 x double> %433)
  %436 = add nuw i64 %416, 4, !dbg !2044
  %437 = icmp eq i64 %436, %414, !dbg !2044
  br i1 %437, label %438, label %415, !dbg !2044, !llvm.loop !2062

438:                                              ; preds = %415
  %439 = icmp eq i64 %413, 0, !dbg !2026
  br i1 %439, label %456, label %440, !dbg !2026

440:                                              ; preds = %405, %401, %438
  %441 = phi i64 [ 0, %405 ], [ 0, %401 ], [ %414, %438 ]
  %442 = phi double [ 0.000000e+00, %405 ], [ 0.000000e+00, %401 ], [ %435, %438 ]
  br label %443, !dbg !2026

443:                                              ; preds = %440, %443
  %444 = phi i64 [ %454, %443 ], [ %441, %440 ]
  %445 = phi double [ %453, %443 ], [ %442, %440 ]
  call void @llvm.dbg.value(metadata double %445, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %444, metadata !741, metadata !DIExpression()), !dbg !2014
  %446 = getelementptr inbounds double, ptr %7, i64 %444, !dbg !2045
  %447 = load double, ptr %446, align 8, !dbg !2045, !tbaa !1443
  %448 = trunc i64 %444 to i32, !dbg !2046
  %449 = sub i32 %155, %448, !dbg !2046
  %450 = sext i32 %449 to i64, !dbg !2047
  %451 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %450, !dbg !2047
  %452 = load double, ptr %451, align 8, !dbg !2047, !tbaa !1443
  %453 = tail call double @llvm.fmuladd.f64(double %447, double %452, double %445), !dbg !2052
  call void @llvm.dbg.value(metadata double %453, metadata !747, metadata !DIExpression()), !dbg !2014
  %454 = add nuw nsw i64 %444, 1, !dbg !2044
  call void @llvm.dbg.value(metadata i64 %454, metadata !741, metadata !DIExpression()), !dbg !2014
  %455 = icmp eq i64 %454, %178, !dbg !2042
  br i1 %455, label %456, label %443, !dbg !2026, !llvm.loop !2063

456:                                              ; preds = %443, %438, %399
  %457 = phi i64 [ %400, %399 ], [ %178, %438 ], [ %178, %443 ]
  %458 = phi i1 [ false, %399 ], [ true, %438 ], [ true, %443 ]
  %459 = phi double [ 0.000000e+00, %399 ], [ %435, %438 ], [ %453, %443 ], !dbg !2064
  %460 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 4, !dbg !2057
  store double %459, ptr %460, align 8, !dbg !2054, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 5, metadata !740, metadata !DIExpression()), !dbg !2014
  %461 = icmp sgt i32 %150, 24
  %462 = icmp eq i32 %151, 0
  %463 = sub nsw i32 48, %150
  %464 = sub nsw i32 47, %150
  %465 = sext i32 %148 to i64, !dbg !2065
  %466 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 3
  %467 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 2
  %468 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 1
  %469 = getelementptr i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %465
  %470 = icmp ult i64 %457, 4
  %471 = and i64 %457, 4294967292
  %472 = icmp eq i64 %457, %471
  br label %476, !dbg !2065

473:                                              ; preds = %676
  %474 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %628
  %475 = load double, ptr %474, align 8, !dbg !2067, !tbaa !1443
  br label %476, !dbg !2068, !llvm.loop !2074

476:                                              ; preds = %473, %456
  %477 = phi double [ %459, %456 ], [ %475, %473 ], !dbg !2067
  %478 = phi i32 [ 4, %456 ], [ %627, %473 ], !dbg !2014
  call void @llvm.dbg.value(metadata i32 %478, metadata !729, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.label(metadata !752), !dbg !2076
  call void @llvm.dbg.value(metadata i32 0, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %478, metadata !741, metadata !DIExpression()), !dbg !2014
  %479 = zext nneg i32 %478 to i64, !dbg !2067
  call void @llvm.dbg.value(metadata double %477, metadata !746, metadata !DIExpression()), !dbg !2014
  br label %480, !dbg !2077

480:                                              ; preds = %480, %476
  %481 = phi i64 [ 0, %476 ], [ %494, %480 ]
  %482 = phi i64 [ %479, %476 ], [ %490, %480 ]
  %483 = phi double [ %477, %476 ], [ %493, %480 ]
  call void @llvm.dbg.value(metadata double %483, metadata !746, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %482, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %481, metadata !740, metadata !DIExpression()), !dbg !2014
  %484 = fmul double %483, 0x3E70000000000000, !dbg !2078
  %485 = fptosi double %484 to i32, !dbg !2081
  %486 = sitofp i32 %485 to double, !dbg !2082
  call void @llvm.dbg.value(metadata double %486, metadata !747, metadata !DIExpression()), !dbg !2014
  %487 = tail call double @llvm.fmuladd.f64(double %486, double 0xC170000000000000, double %483), !dbg !2083
  %488 = fptosi double %487 to i32, !dbg !2084
  %489 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %481, !dbg !2085
  store i32 %488, ptr %489, align 4, !dbg !2086, !tbaa !1907
  %490 = add nsw i64 %482, -1, !dbg !2087
  %491 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %490, !dbg !2088
  %492 = load double, ptr %491, align 8, !dbg !2088, !tbaa !1443
  %493 = fadd double %492, %486, !dbg !2089
  call void @llvm.dbg.value(metadata double %493, metadata !746, metadata !DIExpression()), !dbg !2014
  %494 = add nuw nsw i64 %481, 1, !dbg !2090
  call void @llvm.dbg.value(metadata i64 %490, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %494, metadata !740, metadata !DIExpression()), !dbg !2014
  %495 = icmp eq i64 %494, %479, !dbg !2091
  br i1 %495, label %496, label %480, !dbg !2077, !llvm.loop !2092

496:                                              ; preds = %480
  %497 = tail call double @scalbn(double noundef %493, i32 noundef %151) #12, !dbg !2094
  call void @llvm.dbg.value(metadata double %497, metadata !746, metadata !DIExpression()), !dbg !2014
  %498 = fmul double %497, 1.250000e-01, !dbg !2095
  %499 = tail call double @llvm.floor.f64(double %498), !dbg !2096
  %500 = tail call double @llvm.fmuladd.f64(double %499, double -8.000000e+00, double %497), !dbg !2097
  call void @llvm.dbg.value(metadata double %500, metadata !746, metadata !DIExpression()), !dbg !2014
  %501 = fptosi double %500 to i32, !dbg !2098
  call void @llvm.dbg.value(metadata i32 %501, metadata !735, metadata !DIExpression()), !dbg !2014
  %502 = sitofp i32 %501 to double, !dbg !2099
  %503 = fsub double %500, %502, !dbg !2100
  call void @llvm.dbg.value(metadata double %503, metadata !746, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !745, metadata !DIExpression()), !dbg !2014
  br i1 %461, label %504, label %514, !dbg !2101

504:                                              ; preds = %496
  %505 = add nsw i32 %478, -1, !dbg !2102
  %506 = sext i32 %505 to i64, !dbg !2105
  %507 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %506, !dbg !2105
  %508 = load i32, ptr %507, align 4, !dbg !2105, !tbaa !1907
  %509 = ashr i32 %508, %463, !dbg !2106
  call void @llvm.dbg.value(metadata i32 %509, metadata !740, metadata !DIExpression()), !dbg !2014
  %510 = add nsw i32 %509, %501, !dbg !2107
  call void @llvm.dbg.value(metadata i32 %510, metadata !735, metadata !DIExpression()), !dbg !2014
  %511 = shl i32 %509, %463, !dbg !2108
  %512 = sub nsw i32 %508, %511, !dbg !2109
  store i32 %512, ptr %507, align 4, !dbg !2109, !tbaa !1907
  %513 = ashr i32 %512, %464, !dbg !2110
  call void @llvm.dbg.value(metadata i32 %513, metadata !745, metadata !DIExpression()), !dbg !2014
  br label %523, !dbg !2111

514:                                              ; preds = %496
  br i1 %462, label %515, label %521, !dbg !2112

515:                                              ; preds = %514
  %516 = add nsw i32 %478, -1, !dbg !2113
  %517 = sext i32 %516 to i64, !dbg !2116
  %518 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %517, !dbg !2116
  %519 = load i32, ptr %518, align 4, !dbg !2116, !tbaa !1907
  %520 = ashr i32 %519, 23, !dbg !2117
  call void @llvm.dbg.value(metadata i32 %520, metadata !745, metadata !DIExpression()), !dbg !2014
  br label %523, !dbg !2118

521:                                              ; preds = %514
  %522 = fcmp ult double %503, 5.000000e-01, !dbg !2119
  br i1 %522, label %564, label %527, !dbg !2121

523:                                              ; preds = %515, %504
  %524 = phi i32 [ %510, %504 ], [ %501, %515 ], !dbg !2014
  %525 = phi i32 [ %513, %504 ], [ %520, %515 ], !dbg !2014
  call void @llvm.dbg.value(metadata i32 %525, metadata !745, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %524, metadata !735, metadata !DIExpression()), !dbg !2014
  %526 = icmp sgt i32 %525, 0, !dbg !2122
  br i1 %526, label %527, label %564, !dbg !2124

527:                                              ; preds = %523, %521
  %528 = phi i32 [ %525, %523 ], [ 2, %521 ]
  %529 = phi i32 [ %524, %523 ], [ %501, %521 ]
  call void @llvm.dbg.value(metadata i32 %547, metadata !735, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !734, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !740, metadata !DIExpression()), !dbg !2014
  br label %530, !dbg !2125

530:                                              ; preds = %541, %527
  %531 = phi i64 [ 0, %527 ], [ %544, %541 ]
  %532 = phi i32 [ 0, %527 ], [ %543, %541 ]
  call void @llvm.dbg.value(metadata i64 %531, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %532, metadata !734, metadata !DIExpression()), !dbg !2014
  %533 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %531, !dbg !2128
  %534 = load i32, ptr %533, align 4, !dbg !2128, !tbaa !1907
  call void @llvm.dbg.value(metadata i32 %534, metadata !741, metadata !DIExpression()), !dbg !2014
  %535 = icmp eq i32 %532, 0, !dbg !2131
  br i1 %535, label %536, label %538, !dbg !2133

536:                                              ; preds = %530
  %537 = icmp eq i32 %534, 0, !dbg !2134
  br i1 %537, label %541, label %538, !dbg !2137

538:                                              ; preds = %536, %530
  %539 = phi i32 [ 16777216, %536 ], [ 16777215, %530 ]
  %540 = sub nsw i32 %539, %534, !dbg !2138
  store i32 %540, ptr %533, align 4, !dbg !2138, !tbaa !1907
  br label %541, !dbg !2139

541:                                              ; preds = %538, %536
  %542 = phi i1 [ true, %536 ], [ false, %538 ], !dbg !2140
  %543 = phi i32 [ 0, %536 ], [ 1, %538 ], !dbg !2140
  call void @llvm.dbg.value(metadata i32 %543, metadata !734, metadata !DIExpression()), !dbg !2014
  %544 = add nuw nsw i64 %531, 1, !dbg !2139
  call void @llvm.dbg.value(metadata i64 %544, metadata !740, metadata !DIExpression()), !dbg !2014
  %545 = icmp eq i64 %544, %479, !dbg !2141
  br i1 %545, label %546, label %530, !dbg !2125, !llvm.loop !2142

546:                                              ; preds = %541
  %547 = add nsw i32 %529, 1, !dbg !2144
  br i1 %461, label %548, label %557, !dbg !2145

548:                                              ; preds = %546
  switch i32 %150, label %557 [
    i32 25, label %550
    i32 26, label %549
  ], !dbg !2146

549:                                              ; preds = %548
  br label %550, !dbg !2149

550:                                              ; preds = %549, %548
  %551 = phi i32 [ 4194303, %549 ], [ 8388607, %548 ]
  %552 = add nsw i32 %478, -1, !dbg !2151
  %553 = sext i32 %552 to i64, !dbg !2151
  %554 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %553, !dbg !2151
  %555 = load i32, ptr %554, align 4, !dbg !2151, !tbaa !1907
  %556 = and i32 %555, %551, !dbg !2151
  store i32 %556, ptr %554, align 4, !dbg !2151, !tbaa !1907
  br label %557, !dbg !2152

557:                                              ; preds = %550, %548, %546
  %558 = icmp eq i32 %528, 2, !dbg !2152
  br i1 %558, label %559, label %564, !dbg !2154

559:                                              ; preds = %557
  %560 = fsub double 1.000000e+00, %503, !dbg !2155
  call void @llvm.dbg.value(metadata double %560, metadata !746, metadata !DIExpression()), !dbg !2014
  br i1 %542, label %564, label %561, !dbg !2157

561:                                              ; preds = %559
  %562 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %151) #12, !dbg !2158
  %563 = fsub double %560, %562, !dbg !2160
  call void @llvm.dbg.value(metadata double %563, metadata !746, metadata !DIExpression()), !dbg !2014
  br label %564, !dbg !2161

564:                                              ; preds = %561, %559, %557, %523, %521
  %565 = phi i32 [ 2, %561 ], [ 2, %559 ], [ 2, %557 ], [ %525, %523 ], [ 0, %521 ]
  %566 = phi i32 [ %547, %561 ], [ %547, %559 ], [ %547, %557 ], [ %524, %523 ], [ %501, %521 ], !dbg !2014
  %567 = phi double [ %563, %561 ], [ %560, %559 ], [ %503, %557 ], [ %503, %523 ], [ %503, %521 ], !dbg !2014
  call void @llvm.dbg.value(metadata double %567, metadata !746, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %566, metadata !735, metadata !DIExpression()), !dbg !2014
  %568 = fcmp oeq double %567, 0.000000e+00, !dbg !2162
  br i1 %568, label %569, label %688, !dbg !2163

569:                                              ; preds = %564
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %478, metadata !740, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2014
  %570 = icmp ugt i32 %478, 4, !dbg !2164
  br i1 %570, label %571, label %612, !dbg !2167

571:                                              ; preds = %569
  %572 = add nsw i64 %479, -4, !dbg !2167
  %573 = icmp ult i64 %572, 8, !dbg !2167
  br i1 %573, label %598, label %574, !dbg !2167

574:                                              ; preds = %571
  %575 = and i64 %572, -8, !dbg !2167
  %576 = sub nsw i64 %479, %575, !dbg !2167
  br label %577, !dbg !2167

577:                                              ; preds = %577, %574
  %578 = phi i64 [ 0, %574 ], [ %592, %577 ]
  %579 = phi <4 x i32> [ zeroinitializer, %574 ], [ %590, %577 ]
  %580 = phi <4 x i32> [ zeroinitializer, %574 ], [ %591, %577 ]
  %581 = xor i64 %578, -1, !dbg !2168
  %582 = add i64 %581, %479, !dbg !2168
  %583 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %582, !dbg !2169
  %584 = getelementptr inbounds i32, ptr %583, i64 -3, !dbg !2169
  %585 = getelementptr inbounds i32, ptr %583, i64 -7, !dbg !2169
  %586 = load <4 x i32>, ptr %584, align 4, !dbg !2169, !tbaa !1907
  %587 = shufflevector <4 x i32> %586, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2169
  %588 = load <4 x i32>, ptr %585, align 4, !dbg !2169, !tbaa !1907
  %589 = shufflevector <4 x i32> %588, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2169
  %590 = or <4 x i32> %587, %579, !dbg !2170
  %591 = or <4 x i32> %589, %580, !dbg !2170
  %592 = add nuw i64 %578, 8
  %593 = icmp eq i64 %592, %575
  br i1 %593, label %594, label %577, !llvm.loop !2171

594:                                              ; preds = %577
  %595 = or <4 x i32> %591, %590, !dbg !2167
  %596 = tail call i32 @llvm.vector.reduce.or.v4i32(<4 x i32> %595), !dbg !2167
  %597 = icmp eq i64 %572, %575, !dbg !2167
  br i1 %597, label %609, label %598, !dbg !2167

598:                                              ; preds = %571, %594
  %599 = phi i64 [ %479, %571 ], [ %576, %594 ]
  %600 = phi i32 [ 0, %571 ], [ %596, %594 ]
  br label %601, !dbg !2167

601:                                              ; preds = %598, %601
  %602 = phi i64 [ %604, %601 ], [ %599, %598 ]
  %603 = phi i32 [ %607, %601 ], [ %600, %598 ]
  call void @llvm.dbg.value(metadata i32 %603, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %602, metadata !740, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2014
  %604 = add nsw i64 %602, -1, !dbg !2168
  call void @llvm.dbg.value(metadata i64 %604, metadata !740, metadata !DIExpression()), !dbg !2014
  %605 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %604, !dbg !2169
  %606 = load i32, ptr %605, align 4, !dbg !2169, !tbaa !1907
  %607 = or i32 %606, %603, !dbg !2170
  call void @llvm.dbg.value(metadata i32 %607, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %604, metadata !740, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2014
  %608 = icmp sgt i64 %602, 5, !dbg !2164
  br i1 %608, label %601, label %609, !dbg !2167, !llvm.loop !2173

609:                                              ; preds = %601, %594
  %610 = phi i32 [ %596, %594 ], [ %607, %601 ], !dbg !2170
  %611 = icmp eq i32 %610, 0, !dbg !2174
  br i1 %611, label %612, label %680, !dbg !2175

612:                                              ; preds = %609, %569
  call void @llvm.dbg.value(metadata i64 1, metadata !742, metadata !DIExpression()), !dbg !2014
  %613 = load i32, ptr %466, align 4, !dbg !2176, !tbaa !1907
  %614 = icmp eq i32 %613, 0, !dbg !2179
  br i1 %614, label %615, label %625, !dbg !2180

615:                                              ; preds = %612
  call void @llvm.dbg.value(metadata i64 2, metadata !742, metadata !DIExpression()), !dbg !2014
  %616 = load i32, ptr %467, align 4, !dbg !2176, !tbaa !1907
  %617 = icmp eq i32 %616, 0, !dbg !2179
  br i1 %617, label %618, label %625, !dbg !2180

618:                                              ; preds = %615
  call void @llvm.dbg.value(metadata i64 3, metadata !742, metadata !DIExpression()), !dbg !2014
  %619 = load i32, ptr %468, align 4, !dbg !2176, !tbaa !1907
  %620 = icmp eq i32 %619, 0, !dbg !2179
  br i1 %620, label %621, label %625, !dbg !2180

621:                                              ; preds = %618
  call void @llvm.dbg.value(metadata i64 4, metadata !742, metadata !DIExpression()), !dbg !2014
  %622 = load i32, ptr %3, align 4, !dbg !2176, !tbaa !1907
  %623 = icmp eq i32 %622, 0, !dbg !2179
  %624 = select i1 %623, i32 5, i32 4, !dbg !2180
  br label %625, !dbg !2180

625:                                              ; preds = %621, %618, %615, %612
  %626 = phi i32 [ 1, %612 ], [ 2, %615 ], [ 3, %618 ], [ %624, %621 ], !dbg !2181
  call void @llvm.dbg.value(metadata i32 %478, metadata !740, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2014
  %627 = add nuw nsw i32 %626, %478
  %628 = zext nneg i32 %627 to i64, !dbg !2182
  br label %629, !dbg !2068

629:                                              ; preds = %676, %625
  %630 = phi i64 [ %479, %625 ], [ %631, %676 ]
  %631 = add nuw nsw i64 %630, 1, !dbg !2184
  %632 = getelementptr i32, ptr %469, i64 %631, !dbg !2185
  %633 = load i32, ptr %632, align 4, !dbg !2185, !tbaa !1907
  %634 = sitofp i32 %633 to double, !dbg !2185
  %635 = add i64 %139, %630, !dbg !2187
  %636 = shl i64 %635, 32, !dbg !2188
  %637 = ashr exact i64 %636, 32, !dbg !2188
  %638 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %637, !dbg !2188
  store double %634, ptr %638, align 8, !dbg !2189, !tbaa !1443
  call void @llvm.dbg.value(metadata i32 0, metadata !741, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  br i1 %458, label %639, label %676, !dbg !2190

639:                                              ; preds = %629
  br i1 %470, label %662, label %640, !dbg !2190

640:                                              ; preds = %639, %640
  %641 = phi i64 [ %659, %640 ], [ 0, %639 ], !dbg !2192
  %642 = phi double [ %658, %640 ], [ 0.000000e+00, %639 ]
  %643 = getelementptr inbounds double, ptr %7, i64 %641, !dbg !2194
  %644 = getelementptr inbounds double, ptr %643, i64 2, !dbg !2194
  %645 = load <2 x double>, ptr %643, align 8, !dbg !2194, !tbaa !1443
  %646 = load <2 x double>, ptr %644, align 8, !dbg !2194, !tbaa !1443
  %647 = sub nsw i64 %637, %641, !dbg !2195
  %648 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %647, !dbg !2196
  %649 = getelementptr inbounds double, ptr %648, i64 -1, !dbg !2196
  %650 = getelementptr inbounds double, ptr %648, i64 -3, !dbg !2196
  %651 = load <2 x double>, ptr %649, align 8, !dbg !2196, !tbaa !1443
  %652 = shufflevector <2 x double> %651, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2196
  %653 = load <2 x double>, ptr %650, align 8, !dbg !2196, !tbaa !1443
  %654 = shufflevector <2 x double> %653, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2196
  %655 = fmul <2 x double> %645, %652
  %656 = fmul <2 x double> %646, %654
  %657 = tail call double @llvm.vector.reduce.fadd.v2f64(double %642, <2 x double> %655)
  %658 = tail call double @llvm.vector.reduce.fadd.v2f64(double %657, <2 x double> %656)
  %659 = add nuw i64 %641, 4, !dbg !2192
  %660 = icmp eq i64 %659, %471, !dbg !2192
  br i1 %660, label %661, label %640, !dbg !2192, !llvm.loop !2197

661:                                              ; preds = %640
  br i1 %472, label %676, label %662, !dbg !2190

662:                                              ; preds = %639, %661
  %663 = phi i64 [ 0, %639 ], [ %471, %661 ]
  %664 = phi double [ 0.000000e+00, %639 ], [ %658, %661 ]
  br label %665, !dbg !2190

665:                                              ; preds = %662, %665
  %666 = phi i64 [ %674, %665 ], [ %663, %662 ]
  %667 = phi double [ %673, %665 ], [ %664, %662 ]
  call void @llvm.dbg.value(metadata double %667, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %666, metadata !741, metadata !DIExpression()), !dbg !2014
  %668 = getelementptr inbounds double, ptr %7, i64 %666, !dbg !2194
  %669 = load double, ptr %668, align 8, !dbg !2194, !tbaa !1443
  %670 = sub nsw i64 %637, %666, !dbg !2195
  %671 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %670, !dbg !2196
  %672 = load double, ptr %671, align 8, !dbg !2196, !tbaa !1443
  %673 = tail call double @llvm.fmuladd.f64(double %669, double %672, double %667), !dbg !2199
  call void @llvm.dbg.value(metadata double %673, metadata !747, metadata !DIExpression()), !dbg !2014
  %674 = add nuw nsw i64 %666, 1, !dbg !2192
  call void @llvm.dbg.value(metadata i64 %674, metadata !741, metadata !DIExpression()), !dbg !2014
  %675 = icmp eq i64 %674, %457, !dbg !2200
  br i1 %675, label %676, label %665, !dbg !2190, !llvm.loop !2201

676:                                              ; preds = %665, %661, %629
  %677 = phi double [ 0.000000e+00, %629 ], [ %658, %661 ], [ %673, %665 ], !dbg !2202
  %678 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %631, !dbg !2203
  store double %677, ptr %678, align 8, !dbg !2204, !tbaa !1443
  call void @llvm.dbg.value(metadata i64 %631, metadata !740, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2014
  %679 = icmp ult i64 %631, %628, !dbg !2182
  br i1 %679, label %629, label %473, !dbg !2068, !llvm.loop !2205

680:                                              ; preds = %609, %680
  %681 = phi i64 [ %684, %680 ], [ %479, %609 ]
  %682 = phi i32 [ %683, %680 ], [ %151, %609 ]
  %683 = add nsw i32 %682, -24, !dbg !2206
  %684 = add nsw i64 %681, -1, !dbg !2206
  call void @llvm.dbg.value(metadata i32 %683, metadata !744, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %684, metadata !729, metadata !DIExpression()), !dbg !2014
  %685 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %684, !dbg !2209
  %686 = load i32, ptr %685, align 4, !dbg !2209, !tbaa !1907
  %687 = icmp eq i32 %686, 0, !dbg !2210
  br i1 %687, label %680, label %705, !dbg !2211, !llvm.loop !2212

688:                                              ; preds = %564
  %689 = sub nsw i32 24, %150, !dbg !2214
  %690 = tail call double @scalbn(double noundef %567, i32 noundef %689) #12, !dbg !2216
  call void @llvm.dbg.value(metadata double %690, metadata !746, metadata !DIExpression()), !dbg !2014
  %691 = fcmp ult double %690, 0x4170000000000000, !dbg !2217
  br i1 %691, label %702, label %692, !dbg !2219

692:                                              ; preds = %688
  %693 = fmul double %690, 0x3E70000000000000, !dbg !2220
  %694 = fptosi double %693 to i32, !dbg !2222
  %695 = sitofp i32 %694 to double, !dbg !2223
  call void @llvm.dbg.value(metadata double %695, metadata !747, metadata !DIExpression()), !dbg !2014
  %696 = tail call double @llvm.fmuladd.f64(double %695, double 0xC170000000000000, double %690), !dbg !2224
  %697 = fptosi double %696 to i32, !dbg !2225
  %698 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %479, !dbg !2226
  store i32 %697, ptr %698, align 4, !dbg !2227, !tbaa !1907
  %699 = add nuw nsw i32 %478, 1, !dbg !2228
  call void @llvm.dbg.value(metadata i32 %699, metadata !729, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %150, metadata !744, metadata !DIExpression()), !dbg !2014
  %700 = zext nneg i32 %699 to i64, !dbg !2229
  %701 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %700, !dbg !2229
  store i32 %694, ptr %701, align 4, !dbg !2230, !tbaa !1907
  br label %707, !dbg !2231

702:                                              ; preds = %688
  %703 = fptosi double %690 to i32, !dbg !2232
  %704 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %479, !dbg !2234
  store i32 %703, ptr %704, align 4, !dbg !2235, !tbaa !1907
  br label %707

705:                                              ; preds = %680
  %706 = trunc i64 %684 to i32, !dbg !2236
  br label %707, !dbg !2236

707:                                              ; preds = %705, %702, %692
  %708 = phi i32 [ %699, %692 ], [ %478, %702 ], [ %706, %705 ], !dbg !2014
  %709 = phi i32 [ %150, %692 ], [ %151, %702 ], [ %683, %705 ], !dbg !2014
  call void @llvm.dbg.value(metadata i32 %709, metadata !744, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %708, metadata !729, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double poison, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 %708, metadata !740, metadata !DIExpression()), !dbg !2014
  %710 = icmp sgt i32 %708, -1, !dbg !2237
  br i1 %710, label %714, label %711, !dbg !2240

711:                                              ; preds = %707
  %712 = icmp eq i32 %565, 0, !dbg !2241
  %713 = select i1 %712, double 0.000000e+00, double -0.000000e+00, !dbg !2243
  store double %713, ptr %1, align 8, !dbg !2244, !tbaa !1443
  call void @llvm.dbg.value(metadata double undef, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 1, metadata !740, metadata !DIExpression()), !dbg !2014
  br label %840, !dbg !2245

714:                                              ; preds = %707
  %715 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %709) #12, !dbg !2236
  call void @llvm.dbg.value(metadata double %715, metadata !747, metadata !DIExpression()), !dbg !2014
  %716 = zext nneg i32 %708 to i64, !dbg !2240
  br label %717, !dbg !2240

717:                                              ; preds = %717, %714
  %718 = phi i64 [ %716, %714 ], [ %726, %717 ]
  %719 = phi double [ %715, %714 ], [ %725, %717 ]
  call void @llvm.dbg.value(metadata double %719, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %718, metadata !740, metadata !DIExpression()), !dbg !2014
  %720 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %718, !dbg !2247
  %721 = load i32, ptr %720, align 4, !dbg !2247, !tbaa !1907
  %722 = sitofp i32 %721 to double, !dbg !2247
  %723 = fmul double %719, %722, !dbg !2249
  %724 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %718, !dbg !2250
  store double %723, ptr %724, align 8, !dbg !2251, !tbaa !1443
  %725 = fmul double %719, 0x3E70000000000000, !dbg !2252
  call void @llvm.dbg.value(metadata double %725, metadata !747, metadata !DIExpression()), !dbg !2014
  %726 = add nsw i64 %718, -1, !dbg !2253
  call void @llvm.dbg.value(metadata i64 %726, metadata !740, metadata !DIExpression()), !dbg !2014
  %727 = icmp eq i64 %718, 0, !dbg !2237
  br i1 %727, label %728, label %717, !dbg !2240, !llvm.loop !2254

728:                                              ; preds = %717, %760
  %729 = phi i64 [ %764, %760 ], [ %716, %717 ]
  %730 = phi i32 [ %765, %760 ], [ 0, %717 ]
  call void @llvm.dbg.value(metadata i64 %729, metadata !740, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 0, metadata !742, metadata !DIExpression()), !dbg !2014
  %731 = tail call i32 @llvm.umin.i32(i32 %730, i32 4)
  %732 = add nuw nsw i32 %731, 1
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 0, metadata !742, metadata !DIExpression()), !dbg !2014
  %733 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %729, !dbg !2256
  %734 = load double, ptr %733, align 8, !dbg !2256, !tbaa !1443
  %735 = tail call double @llvm.fmuladd.f64(double %734, double 0x3FF921FB40000000, double 0.000000e+00), !dbg !2262
  call void @llvm.dbg.value(metadata double %735, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 1, metadata !742, metadata !DIExpression()), !dbg !2014
  %736 = icmp eq i32 %730, 0, !dbg !2263
  br i1 %736, label %760, label %737, !dbg !2263, !llvm.loop !2264

737:                                              ; preds = %728
  call void @llvm.dbg.value(metadata double %735, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 1, metadata !742, metadata !DIExpression()), !dbg !2014
  %738 = add nuw nsw i64 %729, 1, !dbg !2267
  %739 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %738, !dbg !2256
  %740 = load double, ptr %739, align 8, !dbg !2256, !tbaa !1443
  %741 = tail call double @llvm.fmuladd.f64(double %740, double 0x3E74442D00000000, double %735), !dbg !2262
  call void @llvm.dbg.value(metadata double %741, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 2, metadata !742, metadata !DIExpression()), !dbg !2014
  %742 = icmp eq i32 %732, 2, !dbg !2263
  br i1 %742, label %760, label %743, !dbg !2263, !llvm.loop !2264

743:                                              ; preds = %737
  call void @llvm.dbg.value(metadata double %741, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 2, metadata !742, metadata !DIExpression()), !dbg !2014
  %744 = add nuw nsw i64 %729, 2, !dbg !2267
  %745 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %744, !dbg !2256
  %746 = load double, ptr %745, align 8, !dbg !2256, !tbaa !1443
  %747 = tail call double @llvm.fmuladd.f64(double %746, double 0x3CF8469880000000, double %741), !dbg !2262
  call void @llvm.dbg.value(metadata double %747, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 3, metadata !742, metadata !DIExpression()), !dbg !2014
  %748 = icmp eq i32 %732, 3, !dbg !2263
  br i1 %748, label %760, label %749, !dbg !2263, !llvm.loop !2264

749:                                              ; preds = %743
  call void @llvm.dbg.value(metadata double %747, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 3, metadata !742, metadata !DIExpression()), !dbg !2014
  %750 = add nuw nsw i64 %729, 3, !dbg !2267
  %751 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %750, !dbg !2256
  %752 = load double, ptr %751, align 8, !dbg !2256, !tbaa !1443
  %753 = tail call double @llvm.fmuladd.f64(double %752, double 0x3B78CC5160000000, double %747), !dbg !2262
  call void @llvm.dbg.value(metadata double %753, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 4, metadata !742, metadata !DIExpression()), !dbg !2014
  %754 = icmp eq i32 %732, 4, !dbg !2263
  br i1 %754, label %760, label %755, !dbg !2263, !llvm.loop !2264

755:                                              ; preds = %749
  call void @llvm.dbg.value(metadata double %753, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 4, metadata !742, metadata !DIExpression()), !dbg !2014
  %756 = add nuw nsw i64 %729, 4, !dbg !2267
  %757 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %756, !dbg !2256
  %758 = load double, ptr %757, align 8, !dbg !2256, !tbaa !1443
  %759 = tail call double @llvm.fmuladd.f64(double %758, double 0x39F01B8380000000, double %753), !dbg !2262
  call void @llvm.dbg.value(metadata double %759, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 5, metadata !742, metadata !DIExpression()), !dbg !2014
  br label %760

760:                                              ; preds = %755, %749, %743, %737, %728
  %761 = phi double [ %735, %728 ], [ %741, %737 ], [ %747, %743 ], [ %753, %749 ], [ %759, %755 ], !dbg !2262
  %762 = sub nuw nsw i64 %716, %729
  %763 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %762, !dbg !2268
  store double %761, ptr %763, align 8, !dbg !2269, !tbaa !1443
  %764 = add nsw i64 %729, -1, !dbg !2270
  call void @llvm.dbg.value(metadata i64 %764, metadata !740, metadata !DIExpression()), !dbg !2014
  %765 = add nuw i32 %730, 1, !dbg !2271
  %766 = icmp eq i32 %730, %708, !dbg !2272
  br i1 %766, label %767, label %728, !dbg !2271, !llvm.loop !2273

767:                                              ; preds = %760
  %768 = add nuw nsw i64 %716, 1, !dbg !2275
  %769 = icmp eq i32 %708, 0, !dbg !2275
  br i1 %769, label %788, label %770, !dbg !2275

770:                                              ; preds = %767
  %771 = and i64 %768, 4294967294, !dbg !2275
  %772 = sub nsw i64 %716, %771, !dbg !2275
  br label %773, !dbg !2275

773:                                              ; preds = %773, %770
  %774 = phi i64 [ 0, %770 ], [ %784, %773 ]
  %775 = phi double [ 0.000000e+00, %770 ], [ %783, %773 ]
  %776 = sub i64 %716, %774, !dbg !2275
  %777 = add i64 %776, -1, !dbg !2275
  %778 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %776, !dbg !2277
  %779 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %777, !dbg !2277
  %780 = load double, ptr %778, align 8, !dbg !2277, !tbaa !1443
  %781 = load double, ptr %779, align 8, !dbg !2277, !tbaa !1443
  %782 = fadd double %775, %780, !dbg !2277
  %783 = fadd double %782, %781, !dbg !2277
  %784 = add nuw i64 %774, 2
  %785 = icmp eq i64 %784, %771
  br i1 %785, label %786, label %773, !llvm.loop !2279

786:                                              ; preds = %773
  %787 = icmp eq i64 %768, %771, !dbg !2275
  br i1 %787, label %799, label %788, !dbg !2275

788:                                              ; preds = %767, %786
  %789 = phi i64 [ %716, %767 ], [ %772, %786 ]
  %790 = phi double [ 0.000000e+00, %767 ], [ %783, %786 ]
  br label %791, !dbg !2275

791:                                              ; preds = %788, %791
  %792 = phi i64 [ %797, %791 ], [ %789, %788 ]
  %793 = phi double [ %796, %791 ], [ %790, %788 ]
  call void @llvm.dbg.value(metadata double %793, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %792, metadata !740, metadata !DIExpression()), !dbg !2014
  %794 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %792, !dbg !2277
  %795 = load double, ptr %794, align 8, !dbg !2277, !tbaa !1443
  %796 = fadd double %793, %795, !dbg !2281
  call void @llvm.dbg.value(metadata double %796, metadata !747, metadata !DIExpression()), !dbg !2014
  %797 = add nsw i64 %792, -1, !dbg !2282
  call void @llvm.dbg.value(metadata i64 %797, metadata !740, metadata !DIExpression()), !dbg !2014
  %798 = icmp eq i64 %792, 0, !dbg !2283
  br i1 %798, label %799, label %791, !dbg !2275, !llvm.loop !2284

799:                                              ; preds = %791, %786
  %800 = phi double [ %783, %786 ], [ %796, %791 ], !dbg !2281
  %801 = load double, ptr %5, align 8, !dbg !2285, !tbaa !1443
  %802 = icmp eq i32 %565, 0, !dbg !2241
  %803 = fneg double %800, !dbg !2243
  %804 = select i1 %802, double %800, double %803, !dbg !2243
  store double %804, ptr %1, align 8, !dbg !2244, !tbaa !1443
  %805 = fsub double %801, %800, !dbg !2286
  call void @llvm.dbg.value(metadata double %805, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i32 1, metadata !740, metadata !DIExpression()), !dbg !2014
  %806 = icmp eq i32 %708, 0, !dbg !2287
  br i1 %806, label %840, label %807, !dbg !2245

807:                                              ; preds = %799
  %808 = add nuw i32 %708, 1, !dbg !2245
  %809 = zext i32 %808 to i64, !dbg !2287
  %810 = add nsw i64 %809, -1, !dbg !2245
  %811 = icmp ult i32 %708, 4, !dbg !2245
  br i1 %811, label %829, label %812, !dbg !2245

812:                                              ; preds = %807
  %813 = and i64 %810, -4, !dbg !2245
  %814 = or disjoint i64 %813, 1, !dbg !2245
  br label %815, !dbg !2245

815:                                              ; preds = %815, %812
  %816 = phi i64 [ 0, %812 ], [ %825, %815 ]
  %817 = phi double [ %805, %812 ], [ %824, %815 ]
  %818 = or disjoint i64 %816, 1, !dbg !2245
  %819 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %818, !dbg !2289
  %820 = getelementptr inbounds double, ptr %819, i64 2, !dbg !2289
  %821 = load <2 x double>, ptr %819, align 8, !dbg !2289, !tbaa !1443
  %822 = load <2 x double>, ptr %820, align 8, !dbg !2289, !tbaa !1443
  %823 = tail call double @llvm.vector.reduce.fadd.v2f64(double %817, <2 x double> %821), !dbg !2289
  %824 = tail call double @llvm.vector.reduce.fadd.v2f64(double %823, <2 x double> %822), !dbg !2289
  %825 = add nuw i64 %816, 4
  %826 = icmp eq i64 %825, %813
  br i1 %826, label %827, label %815, !llvm.loop !2290

827:                                              ; preds = %815
  %828 = icmp eq i64 %810, %813, !dbg !2245
  br i1 %828, label %840, label %829, !dbg !2245

829:                                              ; preds = %807, %827
  %830 = phi i64 [ 1, %807 ], [ %814, %827 ]
  %831 = phi double [ %805, %807 ], [ %824, %827 ]
  br label %832, !dbg !2245

832:                                              ; preds = %829, %832
  %833 = phi i64 [ %838, %832 ], [ %830, %829 ]
  %834 = phi double [ %837, %832 ], [ %831, %829 ]
  call void @llvm.dbg.value(metadata double %834, metadata !747, metadata !DIExpression()), !dbg !2014
  call void @llvm.dbg.value(metadata i64 %833, metadata !740, metadata !DIExpression()), !dbg !2014
  %835 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %833, !dbg !2289
  %836 = load double, ptr %835, align 8, !dbg !2289, !tbaa !1443
  %837 = fadd double %834, %836, !dbg !2292
  call void @llvm.dbg.value(metadata double %837, metadata !747, metadata !DIExpression()), !dbg !2014
  %838 = add nuw nsw i64 %833, 1, !dbg !2293
  call void @llvm.dbg.value(metadata i64 %838, metadata !740, metadata !DIExpression()), !dbg !2014
  %839 = icmp eq i64 %838, %809, !dbg !2287
  br i1 %839, label %840, label %832, !dbg !2245, !llvm.loop !2294

840:                                              ; preds = %832, %827, %711, %799
  %841 = phi double [ %804, %799 ], [ %713, %711 ], [ %804, %827 ], [ %804, %832 ]
  %842 = phi i1 [ %802, %799 ], [ %712, %711 ], [ %802, %827 ], [ %802, %832 ]
  %843 = phi double [ %805, %799 ], [ undef, %711 ], [ %824, %827 ], [ %837, %832 ], !dbg !2295
  %844 = fneg double %843, !dbg !2296
  %845 = select i1 %842, double %843, double %844, !dbg !2296
  %846 = getelementptr inbounds double, ptr %1, i64 1, !dbg !2297
  store double %845, ptr %846, align 8, !dbg !2298, !tbaa !1443
  %847 = and i32 %566, 7, !dbg !2299
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %6) #11, !dbg !2300
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %5) #11, !dbg !2300
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %4) #11, !dbg !2300
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %3) #11, !dbg !2300
  tail call void @llvm.dbg.value(metadata i32 %847, metadata !664, metadata !DIExpression()), !dbg !1831
  %848 = icmp slt i64 %8, 0, !dbg !2301
  br i1 %848, label %849, label %853, !dbg !2303

849:                                              ; preds = %840
  %850 = fneg double %841, !dbg !2304
  store double %850, ptr %1, align 8, !dbg !2306, !tbaa !1443
  %851 = fneg double %845, !dbg !2307
  store double %851, ptr %846, align 8, !dbg !2308, !tbaa !1443
  %852 = sub nsw i32 0, %847, !dbg !2309
  br label %853, !dbg !2310

853:                                              ; preds = %840, %100, %35, %40, %22, %27, %849, %114, %108, %13
  %854 = phi i32 [ 0, %13 ], [ %111, %108 ], [ 0, %114 ], [ %852, %849 ], [ 1, %27 ], [ 1, %22 ], [ -1, %40 ], [ -1, %35 ], [ %51, %100 ], [ %847, %840 ], !dbg !1831
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %7) #11, !dbg !2311
  ret i32 %854, !dbg !2311
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_exp(double noundef %0) local_unnamed_addr #4 !dbg !206 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !208, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !210, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !211, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata i32 0, metadata !215, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2313
  %2 = bitcast double %0 to i64, !dbg !2315
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2313
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !218, metadata !DIExpression()), !dbg !2316
  %3 = lshr i64 %2, 32, !dbg !2317
  %4 = trunc i64 %3 to i32, !dbg !2317
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !217, metadata !DIExpression()), !dbg !2312
  %5 = lshr i32 %4, 31, !dbg !2318
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !216, metadata !DIExpression()), !dbg !2312
  %6 = and i32 %4, 2147483647, !dbg !2319
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !217, metadata !DIExpression()), !dbg !2312
  %7 = icmp ugt i32 %6, 1082535489, !dbg !2320
  br i1 %7, label %8, label %31, !dbg !2321

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 2146435071, !dbg !2322
  br i1 %9, label %10, label %19, !dbg !2323

10:                                               ; preds = %8
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2324
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2324
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !225, metadata !DIExpression()), !dbg !2326
  %11 = trunc i64 %2 to i32, !dbg !2327
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !220, metadata !DIExpression()), !dbg !2328
  %12 = and i32 %4, 1048575, !dbg !2329
  %13 = or i32 %12, %11, !dbg !2331
  %14 = icmp eq i32 %13, 0, !dbg !2332
  %15 = fadd double %0, %0, !dbg !2333
  %16 = icmp sgt i64 %2, -1, !dbg !2333
  %17 = select i1 %16, double %0, double 0.000000e+00, !dbg !2333
  %18 = select i1 %14, double %17, double %15, !dbg !2333
  br label %116

19:                                               ; preds = %8
  %20 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2334
  br i1 %20, label %21, label %25, !dbg !2336

21:                                               ; preds = %19
  %22 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2337, !tbaa !1443
  %23 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2338, !tbaa !1443
  %24 = fmul double %22, %23, !dbg !2339
  br label %116, !dbg !2340

25:                                               ; preds = %19
  %26 = fcmp olt double %0, 0xC0874910D52D3051, !dbg !2341
  br i1 %26, label %27, label %58, !dbg !2343

27:                                               ; preds = %25
  %28 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2344, !tbaa !1443
  %29 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2345, !tbaa !1443
  %30 = fmul double %28, %29, !dbg !2346
  br label %116, !dbg !2347

31:                                               ; preds = %1
  %32 = icmp ugt i32 %6, 1071001154, !dbg !2348
  br i1 %32, label %33, label %48, !dbg !2350

33:                                               ; preds = %31
  %34 = icmp ult i32 %6, 1072734898, !dbg !2351
  br i1 %34, label %35, label %58, !dbg !2354

35:                                               ; preds = %33
  %36 = fcmp oeq double %0, 1.000000e+00, !dbg !2355
  br i1 %36, label %116, label %37, !dbg !2358

37:                                               ; preds = %35
  %38 = zext nneg i32 %5 to i64
  %39 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2HI, i64 0, i64 %38, !dbg !2359
  %40 = load double, ptr %39, align 8, !dbg !2359, !tbaa !1443
  %41 = fsub double %0, %40, !dbg !2360
  tail call void @llvm.dbg.value(metadata double %41, metadata !210, metadata !DIExpression()), !dbg !2312
  %42 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2LO, i64 0, i64 %38, !dbg !2361
  %43 = load double, ptr %42, align 8, !dbg !2361, !tbaa !1443
  tail call void @llvm.dbg.value(metadata double %43, metadata !211, metadata !DIExpression()), !dbg !2312
  %44 = xor i32 %5, 1, !dbg !2362
  %45 = sub nsw i32 %44, %5, !dbg !2363
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !215, metadata !DIExpression()), !dbg !2312
  %46 = fsub double %41, %43, !dbg !2364
  tail call void @llvm.dbg.value(metadata double %46, metadata !208, metadata !DIExpression()), !dbg !2312
  %47 = fmul double %46, %46, !dbg !2365
  tail call void @llvm.dbg.value(metadata double %47, metadata !213, metadata !DIExpression()), !dbg !2312
  br label %72, !dbg !2366

48:                                               ; preds = %31
  %49 = icmp ult i32 %6, 1043333120, !dbg !2367
  br i1 %49, label %50, label %56, !dbg !2369

50:                                               ; preds = %48
  %51 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2370, !tbaa !1443
  %52 = fadd double %51, %0, !dbg !2373
  %53 = fcmp ogt double %52, 1.000000e+00, !dbg !2374
  br i1 %53, label %54, label %56, !dbg !2375

54:                                               ; preds = %50
  %55 = fadd double %0, 1.000000e+00, !dbg !2376
  br label %116, !dbg !2377

56:                                               ; preds = %50, %48
  tail call void @llvm.dbg.value(metadata double %0, metadata !208, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !210, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !211, metadata !DIExpression()), !dbg !2312
  tail call void @llvm.dbg.value(metadata i32 0, metadata !215, metadata !DIExpression()), !dbg !2312
  %57 = fmul double %0, %0, !dbg !2365
  tail call void @llvm.dbg.value(metadata double %57, metadata !213, metadata !DIExpression()), !dbg !2312
  br label %72, !dbg !2366

58:                                               ; preds = %25, %33
  %59 = zext nneg i32 %5 to i64
  %60 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.halF, i64 0, i64 %59, !dbg !2378
  %61 = load double, ptr %60, align 8, !dbg !2378, !tbaa !1443
  %62 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %61), !dbg !2380
  %63 = fptosi double %62 to i32, !dbg !2381
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !215, metadata !DIExpression()), !dbg !2312
  %64 = sitofp i32 %63 to double, !dbg !2382
  tail call void @llvm.dbg.value(metadata double %64, metadata !213, metadata !DIExpression()), !dbg !2312
  %65 = fneg double %64, !dbg !2383
  %66 = tail call double @llvm.fmuladd.f64(double %65, double 0x3FE62E42FEE00000, double %0), !dbg !2383
  tail call void @llvm.dbg.value(metadata double %66, metadata !210, metadata !DIExpression()), !dbg !2312
  %67 = fmul double %64, 0x3DEA39EF35793C76, !dbg !2384
  tail call void @llvm.dbg.value(metadata double %67, metadata !211, metadata !DIExpression()), !dbg !2312
  %68 = fsub double %66, %67, !dbg !2364
  tail call void @llvm.dbg.value(metadata double %68, metadata !208, metadata !DIExpression()), !dbg !2312
  %69 = fmul double %68, %68, !dbg !2365
  tail call void @llvm.dbg.value(metadata double %69, metadata !213, metadata !DIExpression()), !dbg !2312
  %70 = icmp sgt i32 %63, -1022, !dbg !2385
  %71 = select i1 %70, i32 1072693248, i32 2121269248, !dbg !2366
  br label %72, !dbg !2366

72:                                               ; preds = %58, %56, %37
  %73 = phi i32 [ 0, %56 ], [ %45, %37 ], [ %63, %58 ]
  %74 = phi i32 [ 1072693248, %56 ], [ 1072693248, %37 ], [ %71, %58 ]
  %75 = phi i1 [ true, %56 ], [ true, %37 ], [ %70, %58 ]
  %76 = phi double [ %57, %56 ], [ %47, %37 ], [ %69, %58 ]
  %77 = phi double [ %0, %56 ], [ %46, %37 ], [ %68, %58 ]
  %78 = phi double [ 0.000000e+00, %56 ], [ %41, %37 ], [ %66, %58 ]
  %79 = phi double [ 0.000000e+00, %56 ], [ %43, %37 ], [ %67, %58 ]
  %80 = shl i32 %73, 20, !dbg !2386
  %81 = add i32 %80, %74, !dbg !2386
  %82 = zext i32 %81 to i64, !dbg !2386
  %83 = shl nuw i64 %82, 32, !dbg !2386
  %84 = bitcast i64 %83 to double, !dbg !2386
  tail call void @llvm.dbg.value(metadata double %84, metadata !214, metadata !DIExpression()), !dbg !2312
  %85 = tail call double @llvm.fmuladd.f64(double %76, double 0x3E66376972BEA4D0, double 0xBEBBBD41C5D26BF1), !dbg !2387
  %86 = tail call double @llvm.fmuladd.f64(double %76, double %85, double 0x3F11566AAF25DE2C), !dbg !2388
  %87 = tail call double @llvm.fmuladd.f64(double %76, double %86, double 0xBF66C16C16BEBD93), !dbg !2389
  %88 = tail call double @llvm.fmuladd.f64(double %76, double %87, double 0x3FC555555555553E), !dbg !2390
  %89 = fneg double %76, !dbg !2391
  %90 = tail call double @llvm.fmuladd.f64(double %89, double %88, double %77), !dbg !2391
  tail call void @llvm.dbg.value(metadata double %90, metadata !212, metadata !DIExpression()), !dbg !2312
  %91 = icmp eq i32 %73, 0, !dbg !2392
  %92 = fmul double %77, %90, !dbg !2394
  br i1 %91, label %93, label %98, !dbg !2395

93:                                               ; preds = %72
  %94 = fadd double %90, -2.000000e+00, !dbg !2396
  %95 = fdiv double %92, %94, !dbg !2398
  %96 = fsub double %77, %95, !dbg !2399
  %97 = fadd double %96, 1.000000e+00, !dbg !2399
  br label %116, !dbg !2400

98:                                               ; preds = %72
  %99 = fsub double 2.000000e+00, %90, !dbg !2401
  %100 = fdiv double %92, %99, !dbg !2403
  %101 = fsub double %79, %100, !dbg !2404
  %102 = fsub double %78, %101, !dbg !2405
  %103 = fadd double %102, 1.000000e+00, !dbg !2405
  tail call void @llvm.dbg.value(metadata double %103, metadata !209, metadata !DIExpression()), !dbg !2312
  br i1 %75, label %104, label %112, !dbg !2406

104:                                              ; preds = %98
  %105 = icmp eq i32 %73, 1024, !dbg !2407
  br i1 %105, label %106, label %110, !dbg !2411

106:                                              ; preds = %104
  %107 = fmul double %103, 2.000000e+00, !dbg !2412
  %108 = load volatile double, ptr @pts_ieee754_exp.two1023, align 8, !dbg !2413, !tbaa !1443
  %109 = fmul double %107, %108, !dbg !2414
  br label %116, !dbg !2415

110:                                              ; preds = %104
  %111 = fmul double %103, %84, !dbg !2416
  br label %116, !dbg !2417

112:                                              ; preds = %98
  %113 = fmul double %103, %84, !dbg !2418
  %114 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2420, !tbaa !1443
  %115 = fmul double %113, %114, !dbg !2421
  br label %116, !dbg !2422

116:                                              ; preds = %35, %112, %110, %106, %93, %54, %27, %21, %10
  %117 = phi double [ %18, %10 ], [ %24, %21 ], [ %30, %27 ], [ %97, %93 ], [ %109, %106 ], [ %111, %110 ], [ %115, %112 ], [ %55, %54 ], [ 0x4005BF0A8B145769, %35 ], !dbg !2312
  ret double %117, !dbg !2423
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_atanh(double noundef %0) local_unnamed_addr #0 !dbg !269 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !271, metadata !DIExpression()), !dbg !2424
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2425
  %2 = bitcast double %0 to i64, !dbg !2427
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2425
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !276, metadata !DIExpression()), !dbg !2428
  %3 = lshr i64 %2, 32, !dbg !2429
  %4 = trunc i64 %3 to i32, !dbg !2429
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !273, metadata !DIExpression()), !dbg !2424
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !275, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2424
  %5 = and i32 %4, 2147483647, !dbg !2430
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !274, metadata !DIExpression()), !dbg !2424
  %6 = and i64 %2, 4294967295, !dbg !2431
  %7 = icmp ne i64 %6, 0, !dbg !2431
  %8 = zext i1 %7 to i32, !dbg !2431
  %9 = or i32 %5, %8, !dbg !2433
  %10 = icmp ugt i32 %9, 1072693248, !dbg !2434
  br i1 %10, label %40, label %11, !dbg !2435

11:                                               ; preds = %1
  %12 = icmp eq i32 %5, 1072693248, !dbg !2436
  br i1 %12, label %13, label %16, !dbg !2438

13:                                               ; preds = %11
  %14 = fcmp ogt double %0, 0.000000e+00, !dbg !2439
  %15 = select i1 %14, double 0x7FF0000000000000, double 0xFFF0000000000000, !dbg !2441
  br label %40, !dbg !2442

16:                                               ; preds = %11
  %17 = icmp ult i32 %5, 1043333120, !dbg !2443
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 0.000000e+00
  %20 = and i1 %19, %17, !dbg !2445
  br i1 %20, label %40, label %21, !dbg !2445

21:                                               ; preds = %16
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2446
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2446
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !278, metadata !DIExpression()), !dbg !2448
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !278, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2448
  %22 = tail call double @llvm.fabs.f64(double %0), !dbg !2449
  tail call void @llvm.dbg.value(metadata double %22, metadata !278, metadata !DIExpression()), !dbg !2448
  tail call void @llvm.dbg.value(metadata double %22, metadata !271, metadata !DIExpression()), !dbg !2424
  %23 = icmp ult i32 %5, 1071644672, !dbg !2450
  %24 = fadd double %22, %22, !dbg !2452
  br i1 %23, label %25, label %30, !dbg !2453

25:                                               ; preds = %21
  tail call void @llvm.dbg.value(metadata double %24, metadata !272, metadata !DIExpression()), !dbg !2424
  %26 = fmul double %22, %24, !dbg !2454
  %27 = fsub double 1.000000e+00, %22, !dbg !2456
  %28 = fdiv double %26, %27, !dbg !2457
  %29 = fadd double %24, %28, !dbg !2458
  tail call void @llvm.dbg.value(metadata double poison, metadata !272, metadata !DIExpression()), !dbg !2424
  br label %33, !dbg !2459

30:                                               ; preds = %21
  %31 = fsub double 1.000000e+00, %22, !dbg !2460
  %32 = fdiv double %24, %31, !dbg !2462
  tail call void @llvm.dbg.value(metadata double poison, metadata !272, metadata !DIExpression()), !dbg !2424
  br label %33

33:                                               ; preds = %30, %25
  %34 = phi double [ %32, %30 ], [ %29, %25 ]
  %35 = tail call double @pts_ieee754_log1p(double noundef %34), !dbg !2452
  %36 = fmul double %35, 5.000000e-01, !dbg !2452
  tail call void @llvm.dbg.value(metadata double %36, metadata !272, metadata !DIExpression()), !dbg !2424
  %37 = fneg double %36
  %38 = icmp slt i64 %2, 0, !dbg !2463
  %39 = select i1 %38, double %37, double %36, !dbg !2463
  br label %40, !dbg !2463

40:                                               ; preds = %33, %16, %1, %13
  %41 = phi double [ %15, %13 ], [ 0x7FF8000000000000, %1 ], [ %0, %16 ], [ %39, %33 ], !dbg !2424
  ret double %41, !dbg !2464
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log2(double noundef %0) local_unnamed_addr #0 !dbg !387 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !389, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2466
  %2 = bitcast double %0 to i64, !dbg !2468
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2466
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !403, metadata !DIExpression()), !dbg !2469
  %3 = lshr i64 %2, 32, !dbg !2470
  %4 = trunc i64 %3 to i32, !dbg !2470
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !401, metadata !DIExpression()), !dbg !2465
  %5 = trunc i64 %2 to i32, !dbg !2470
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !402, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata i32 0, metadata !400, metadata !DIExpression()), !dbg !2465
  %6 = icmp slt i32 %4, 1048576, !dbg !2471
  br i1 %6, label %7, label %18, !dbg !2472

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2473
  %9 = or i32 %8, %5, !dbg !2475
  %10 = icmp eq i32 %9, 0, !dbg !2476
  br i1 %10, label %80, label %11, !dbg !2477

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2478
  br i1 %12, label %80, label %13, !dbg !2480

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !400, metadata !DIExpression()), !dbg !2465
  %14 = fmul double %0, 0x4350000000000000, !dbg !2481
  tail call void @llvm.dbg.value(metadata double %14, metadata !389, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata double %14, metadata !879, metadata !DIExpression()), !dbg !2482
  %15 = bitcast double %14 to i64, !dbg !2484
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !884, metadata !DIExpression()), !dbg !2482
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !405, metadata !DIExpression()), !dbg !2485
  %16 = lshr i64 %15, 32, !dbg !2486
  %17 = trunc i64 %16 to i32, !dbg !2486
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !401, metadata !DIExpression()), !dbg !2465
  br label %18, !dbg !2487

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2465
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2465
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !389, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !400, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !401, metadata !DIExpression()), !dbg !2465
  %22 = icmp sgt i32 %19, 2146435071, !dbg !2488
  br i1 %22, label %23, label %25, !dbg !2490

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !2491
  br label %80, !dbg !2492

25:                                               ; preds = %18
  %26 = icmp eq i32 %19, 1072693248, !dbg !2493
  %27 = icmp eq i32 %5, 0
  %28 = and i1 %27, %26, !dbg !2495
  br i1 %28, label %80, label %29, !dbg !2495

29:                                               ; preds = %25
  %30 = ashr i32 %19, 20, !dbg !2496
  %31 = add nsw i32 %30, -1023, !dbg !2497
  %32 = add nsw i32 %31, %20, !dbg !2498
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !400, metadata !DIExpression()), !dbg !2465
  %33 = and i32 %19, 1048575, !dbg !2499
  tail call void @llvm.dbg.value(metadata i32 %33, metadata !401, metadata !DIExpression()), !dbg !2465
  %34 = add nuw nsw i32 %33, 614244, !dbg !2500
  %35 = and i32 %34, 1048576, !dbg !2501
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !399, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !2465
  tail call void @llvm.dbg.value(metadata double %21, metadata !879, metadata !DIExpression()), !dbg !2502
  %36 = bitcast double %21 to i64, !dbg !2504
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !884, metadata !DIExpression()), !dbg !2502
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !409, metadata !DIExpression()), !dbg !2505
  %37 = and i64 %36, 4294967295, !dbg !2506
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !409, metadata !DIExpression()), !dbg !2505
  %38 = or disjoint i32 %35, %33, !dbg !2506
  %39 = xor i32 %38, 1072693248, !dbg !2506
  %40 = zext nneg i32 %39 to i64
  %41 = shl nuw nsw i64 %40, 32, !dbg !2506
  %42 = or disjoint i64 %41, %37, !dbg !2506
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !409, metadata !DIExpression()), !dbg !2505
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !953, metadata !DIExpression()), !dbg !2507
  %43 = bitcast i64 %42 to double, !dbg !2509
  tail call void @llvm.dbg.value(metadata double %43, metadata !958, metadata !DIExpression()), !dbg !2507
  tail call void @llvm.dbg.value(metadata double %43, metadata !389, metadata !DIExpression()), !dbg !2465
  %44 = lshr i32 %34, 20
  %45 = add nsw i32 %32, %44, !dbg !2510
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !400, metadata !DIExpression()), !dbg !2465
  %46 = sitofp i32 %45 to double, !dbg !2511
  tail call void @llvm.dbg.value(metadata double %46, metadata !398, metadata !DIExpression()), !dbg !2465
  %47 = fadd double %43, -1.000000e+00, !dbg !2512
  tail call void @llvm.dbg.value(metadata double %47, metadata !390, metadata !DIExpression()), !dbg !2465
  %48 = fmul double %47, 5.000000e-01, !dbg !2513
  %49 = fmul double %47, %48, !dbg !2514
  tail call void @llvm.dbg.value(metadata double %49, metadata !391, metadata !DIExpression()), !dbg !2465
  call void @llvm.dbg.value(metadata double %47, metadata !2515, metadata !DIExpression()), !dbg !2525
  %50 = fadd double %47, 2.000000e+00, !dbg !2527
  %51 = fdiv double %47, %50, !dbg !2528
  call void @llvm.dbg.value(metadata double %51, metadata !2519, metadata !DIExpression()), !dbg !2525
  %52 = fmul double %51, %51, !dbg !2529
  call void @llvm.dbg.value(metadata double %52, metadata !2520, metadata !DIExpression()), !dbg !2525
  %53 = fmul double %52, %52, !dbg !2530
  call void @llvm.dbg.value(metadata double %53, metadata !2522, metadata !DIExpression()), !dbg !2525
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !2531
  %55 = tail call double @llvm.fmuladd.f64(double %53, double %54, double 0x3FD999999997FA04), !dbg !2532
  %56 = fmul double %53, %55, !dbg !2533
  call void @llvm.dbg.value(metadata double %56, metadata !2523, metadata !DIExpression()), !dbg !2525
  %57 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !2534
  %58 = tail call double @llvm.fmuladd.f64(double %53, double %57, double 0x3FD2492494229359), !dbg !2535
  %59 = tail call double @llvm.fmuladd.f64(double %53, double %58, double 0x3FE5555555555593), !dbg !2536
  %60 = fmul double %52, %59, !dbg !2537
  call void @llvm.dbg.value(metadata double %60, metadata !2524, metadata !DIExpression()), !dbg !2525
  %61 = fadd double %56, %60, !dbg !2538
  call void @llvm.dbg.value(metadata double %61, metadata !2521, metadata !DIExpression()), !dbg !2525
  call void @llvm.dbg.value(metadata double %49, metadata !2518, metadata !DIExpression()), !dbg !2525
  %62 = fadd double %49, %61, !dbg !2539
  %63 = fmul double %51, %62, !dbg !2540
  tail call void @llvm.dbg.value(metadata double %63, metadata !394, metadata !DIExpression()), !dbg !2465
  %64 = fsub double %47, %49, !dbg !2541
  tail call void @llvm.dbg.value(metadata double %64, metadata !392, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata double %64, metadata !879, metadata !DIExpression()), !dbg !2542
  %65 = bitcast double %64 to i64, !dbg !2544
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !884, metadata !DIExpression()), !dbg !2542
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !411, metadata !DIExpression()), !dbg !2545
  %66 = and i64 %65, -4294967296, !dbg !2546
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !411, metadata !DIExpression()), !dbg !2545
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !411, metadata !DIExpression()), !dbg !2545
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !953, metadata !DIExpression()), !dbg !2547
  %67 = bitcast i64 %66 to double, !dbg !2549
  tail call void @llvm.dbg.value(metadata double %67, metadata !958, metadata !DIExpression()), !dbg !2547
  tail call void @llvm.dbg.value(metadata double %67, metadata !392, metadata !DIExpression()), !dbg !2465
  %68 = fsub double %47, %67, !dbg !2550
  %69 = fsub double %68, %49, !dbg !2551
  %70 = fadd double %69, %63, !dbg !2552
  tail call void @llvm.dbg.value(metadata double %70, metadata !393, metadata !DIExpression()), !dbg !2465
  %71 = fmul double %67, 0x3FF7154765200000, !dbg !2553
  tail call void @llvm.dbg.value(metadata double %71, metadata !395, metadata !DIExpression()), !dbg !2465
  %72 = fadd double %70, %67, !dbg !2554
  %73 = fmul double %70, 0x3FF7154765200000, !dbg !2555
  %74 = tail call double @llvm.fmuladd.f64(double %72, double 0x3DE705FC2EEFA200, double %73), !dbg !2556
  tail call void @llvm.dbg.value(metadata double %74, metadata !396, metadata !DIExpression()), !dbg !2465
  %75 = fadd double %71, %46, !dbg !2557
  tail call void @llvm.dbg.value(metadata double %75, metadata !397, metadata !DIExpression()), !dbg !2465
  %76 = fsub double %46, %75, !dbg !2558
  %77 = fadd double %71, %76, !dbg !2559
  %78 = fadd double %77, %74, !dbg !2560
  tail call void @llvm.dbg.value(metadata double %78, metadata !396, metadata !DIExpression()), !dbg !2465
  tail call void @llvm.dbg.value(metadata double %75, metadata !395, metadata !DIExpression()), !dbg !2465
  %79 = fadd double %75, %78, !dbg !2561
  br label %80, !dbg !2562

80:                                               ; preds = %25, %11, %7, %29, %23
  %81 = phi double [ %24, %23 ], [ %79, %29 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %25 ], !dbg !2465
  ret double %81, !dbg !2563
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log10(double noundef %0) local_unnamed_addr #0 !dbg !419 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !421, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2565
  %2 = bitcast double %0 to i64, !dbg !2567
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2565
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !427, metadata !DIExpression()), !dbg !2568
  %3 = lshr i64 %2, 32, !dbg !2569
  %4 = trunc i64 %3 to i32, !dbg !2569
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !425, metadata !DIExpression()), !dbg !2564
  %5 = trunc i64 %2 to i32, !dbg !2569
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !426, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 0, metadata !424, metadata !DIExpression()), !dbg !2564
  %6 = icmp slt i32 %4, 1048576, !dbg !2570
  br i1 %6, label %7, label %19, !dbg !2571

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2572
  %9 = or i32 %8, %5, !dbg !2574
  %10 = icmp eq i32 %9, 0, !dbg !2575
  br i1 %10, label %51, label %11, !dbg !2576

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2577
  br i1 %12, label %51, label %13, !dbg !2579

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !424, metadata !DIExpression()), !dbg !2564
  %14 = fmul double %0, 0x4350000000000000, !dbg !2580
  tail call void @llvm.dbg.value(metadata double %14, metadata !421, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata double %14, metadata !879, metadata !DIExpression()), !dbg !2581
  %15 = bitcast double %14 to i64, !dbg !2583
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !884, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !429, metadata !DIExpression()), !dbg !2584
  %16 = lshr i64 %15, 32, !dbg !2585
  %17 = trunc i64 %16 to i32, !dbg !2585
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !425, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata double %14, metadata !879, metadata !DIExpression()), !dbg !2586
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !884, metadata !DIExpression()), !dbg !2586
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !433, metadata !DIExpression()), !dbg !2588
  %18 = trunc i64 %15 to i32, !dbg !2589
  tail call void @llvm.dbg.value(metadata i32 %18, metadata !426, metadata !DIExpression()), !dbg !2564
  br label %19, !dbg !2590

19:                                               ; preds = %13, %1
  %20 = phi i32 [ %18, %13 ], [ %5, %1 ], !dbg !2564
  %21 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2564
  %22 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2564
  %23 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %23, metadata !421, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 %22, metadata !424, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !425, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !426, metadata !DIExpression()), !dbg !2564
  %24 = icmp sgt i32 %21, 2146435071, !dbg !2591
  br i1 %24, label %25, label %27, !dbg !2593

25:                                               ; preds = %19
  %26 = fadd double %23, %23, !dbg !2594
  br label %51, !dbg !2595

27:                                               ; preds = %19
  %28 = icmp eq i32 %21, 1072693248, !dbg !2596
  %29 = icmp eq i32 %20, 0
  %30 = and i1 %29, %28, !dbg !2598
  br i1 %30, label %51, label %31, !dbg !2598

31:                                               ; preds = %27
  %32 = ashr i32 %21, 20, !dbg !2599
  %33 = add nsw i32 %32, -1023, !dbg !2600
  %34 = add nsw i32 %33, %22, !dbg !2601
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !424, metadata !DIExpression()), !dbg !2564
  %35 = lshr i32 %34, 31, !dbg !2602
  tail call void @llvm.dbg.value(metadata i32 %35, metadata !423, metadata !DIExpression()), !dbg !2564
  %36 = and i32 %21, 1048575, !dbg !2603
  %37 = shl nuw nsw i32 %35, 20, !dbg !2604
  %38 = or disjoint i32 %37, %36, !dbg !2605
  %39 = xor i32 %38, 1072693248, !dbg !2605
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !425, metadata !DIExpression()), !dbg !2564
  %40 = add nsw i32 %35, %34, !dbg !2606
  %41 = sitofp i32 %40 to double, !dbg !2607
  tail call void @llvm.dbg.value(metadata double %41, metadata !422, metadata !DIExpression()), !dbg !2564
  tail call void @llvm.dbg.value(metadata double %23, metadata !879, metadata !DIExpression()), !dbg !2608
  tail call void @llvm.dbg.value(metadata double %23, metadata !884, metadata !DIExpression()), !dbg !2608
  tail call void @llvm.dbg.value(metadata double %23, metadata !435, metadata !DIExpression()), !dbg !2610
  tail call void @llvm.dbg.value(metadata double %23, metadata !435, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2610
  %42 = zext nneg i32 %39 to i64
  %43 = shl nuw nsw i64 %42, 32, !dbg !2611
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !435, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2610
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !953, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2612
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !958, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2612
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !421, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2564
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !879, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2614
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !884, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2614
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !437, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2616
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !437, metadata !DIExpression()), !dbg !2616
  %44 = zext i32 %20 to i64, !dbg !2617
  %45 = or disjoint i64 %43, %44, !dbg !2617
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !437, metadata !DIExpression()), !dbg !2616
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !953, metadata !DIExpression()), !dbg !2618
  %46 = bitcast i64 %45 to double, !dbg !2620
  tail call void @llvm.dbg.value(metadata double %46, metadata !958, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double %46, metadata !421, metadata !DIExpression()), !dbg !2564
  %47 = tail call double @pts_ieee754_log(double noundef %46), !dbg !2621
  %48 = fmul double %47, 0x3FDBCB7B1526E50E, !dbg !2622
  %49 = tail call double @llvm.fmuladd.f64(double %41, double 0x3D59FEF311F12B36, double %48), !dbg !2623
  tail call void @llvm.dbg.value(metadata double %49, metadata !439, metadata !DIExpression()), !dbg !2564
  %50 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FD34413509F6000, double %49), !dbg !2624
  br label %51

51:                                               ; preds = %27, %11, %7, %31, %25
  %52 = phi double [ %26, %25 ], [ %50, %31 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %27 ], !dbg !2564
  ret double %52, !dbg !2625
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_expm1(double noundef %0) local_unnamed_addr #4 !dbg !448 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !450, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2627
  %2 = bitcast double %0 to i64, !dbg !2629
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2627
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !464, metadata !DIExpression()), !dbg !2630
  %3 = lshr i64 %2, 32, !dbg !2631
  %4 = trunc i64 %3 to i32, !dbg !2631
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !463, metadata !DIExpression()), !dbg !2626
  %5 = and i32 %4, -2147483648, !dbg !2632
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !462, metadata !DIExpression()), !dbg !2626
  %6 = and i32 %4, 2147483647, !dbg !2633
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !463, metadata !DIExpression()), !dbg !2626
  %7 = icmp ugt i32 %6, 1078159481, !dbg !2634
  br i1 %7, label %8, label %32, !dbg !2635

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 1082535489, !dbg !2636
  br i1 %9, label %10, label %27, !dbg !2637

10:                                               ; preds = %8
  %11 = icmp ugt i32 %6, 2146435071, !dbg !2638
  br i1 %11, label %12, label %21, !dbg !2639

12:                                               ; preds = %10
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2640
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2640
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !473, metadata !DIExpression()), !dbg !2642
  %13 = trunc i64 %2 to i32, !dbg !2643
  tail call void @llvm.dbg.value(metadata i32 %13, metadata !466, metadata !DIExpression()), !dbg !2644
  %14 = and i32 %4, 1048575, !dbg !2645
  %15 = or i32 %14, %13, !dbg !2647
  %16 = icmp eq i32 %15, 0, !dbg !2648
  %17 = fadd double %0, %0, !dbg !2649
  %18 = icmp eq i32 %5, 0, !dbg !2649
  %19 = select i1 %18, double %0, double -1.000000e+00, !dbg !2649
  %20 = select i1 %16, double %19, double %17, !dbg !2649
  br label %145

21:                                               ; preds = %10
  %22 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2650
  br i1 %22, label %23, label %27, !dbg !2652

23:                                               ; preds = %21
  %24 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2653, !tbaa !1443
  %25 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2654, !tbaa !1443
  %26 = fmul double %24, %25, !dbg !2655
  br label %145, !dbg !2656

27:                                               ; preds = %21, %8
  %28 = icmp ne i32 %5, 0, !dbg !2657
  %29 = fadd double %0, 1.000000e-300
  %30 = fcmp olt double %29, 0.000000e+00
  %31 = and i1 %30, %28, !dbg !2659
  br i1 %31, label %145, label %42, !dbg !2659

32:                                               ; preds = %1
  %33 = icmp ugt i32 %6, 1071001154, !dbg !2660
  br i1 %33, label %34, label %58, !dbg !2662

34:                                               ; preds = %32
  %35 = icmp ult i32 %6, 1072734898, !dbg !2663
  br i1 %35, label %36, label %42, !dbg !2666

36:                                               ; preds = %34
  %37 = icmp eq i32 %5, 0, !dbg !2667
  br i1 %37, label %38, label %40, !dbg !2670

38:                                               ; preds = %36
  %39 = fadd double %0, 0xBFE62E42FEE00000, !dbg !2671
  tail call void @llvm.dbg.value(metadata double %39, metadata !452, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double 0x3DEA39EF35793C76, metadata !453, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata i32 1, metadata !461, metadata !DIExpression()), !dbg !2626
  br label %51, !dbg !2673

40:                                               ; preds = %36
  %41 = fadd double %0, 0x3FE62E42FEE00000, !dbg !2674
  tail call void @llvm.dbg.value(metadata double %41, metadata !452, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double 0xBDEA39EF35793C76, metadata !453, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !461, metadata !DIExpression()), !dbg !2626
  br label %51

42:                                               ; preds = %27, %34
  %43 = icmp eq i32 %5, 0, !dbg !2676
  %44 = select i1 %43, double 5.000000e-01, double -5.000000e-01, !dbg !2678
  %45 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %44), !dbg !2679
  %46 = fptosi double %45 to i32, !dbg !2680
  tail call void @llvm.dbg.value(metadata i32 %46, metadata !461, metadata !DIExpression()), !dbg !2626
  %47 = sitofp i32 %46 to double, !dbg !2681
  tail call void @llvm.dbg.value(metadata double %47, metadata !455, metadata !DIExpression()), !dbg !2626
  %48 = fneg double %47, !dbg !2682
  %49 = tail call double @llvm.fmuladd.f64(double %48, double 0x3FE62E42FEE00000, double %0), !dbg !2682
  tail call void @llvm.dbg.value(metadata double %49, metadata !452, metadata !DIExpression()), !dbg !2626
  %50 = fmul double %47, 0x3DEA39EF35793C76, !dbg !2683
  tail call void @llvm.dbg.value(metadata double %50, metadata !453, metadata !DIExpression()), !dbg !2626
  br label %51

51:                                               ; preds = %38, %40, %42
  %52 = phi i32 [ 1, %38 ], [ -1, %40 ], [ %46, %42 ], !dbg !2684
  %53 = phi double [ 0x3DEA39EF35793C76, %38 ], [ 0xBDEA39EF35793C76, %40 ], [ %50, %42 ], !dbg !2684
  %54 = phi double [ %39, %38 ], [ %41, %40 ], [ %49, %42 ], !dbg !2684
  tail call void @llvm.dbg.value(metadata double %54, metadata !452, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double %53, metadata !453, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !461, metadata !DIExpression()), !dbg !2626
  %55 = fsub double %54, %53, !dbg !2685
  tail call void @llvm.dbg.value(metadata double %55, metadata !450, metadata !DIExpression()), !dbg !2626
  %56 = fsub double %54, %55, !dbg !2686
  %57 = fsub double %56, %53, !dbg !2687
  tail call void @llvm.dbg.value(metadata double %57, metadata !454, metadata !DIExpression()), !dbg !2626
  br label %67, !dbg !2688

58:                                               ; preds = %32
  %59 = icmp ult i32 %6, 1016070144, !dbg !2689
  br i1 %59, label %60, label %67, !dbg !2691

60:                                               ; preds = %58
  %61 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2692, !tbaa !1443
  %62 = fadd double %61, %0, !dbg !2694
  tail call void @llvm.dbg.value(metadata double %62, metadata !455, metadata !DIExpression()), !dbg !2626
  %63 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2695, !tbaa !1443
  %64 = fadd double %63, %0, !dbg !2696
  %65 = fsub double %62, %64, !dbg !2697
  %66 = fsub double %0, %65, !dbg !2698
  br label %145, !dbg !2699

67:                                               ; preds = %58, %51
  %68 = phi i32 [ %52, %51 ], [ 0, %58 ], !dbg !2700
  %69 = phi double [ %57, %51 ], [ undef, %58 ]
  %70 = phi double [ %55, %51 ], [ %0, %58 ]
  tail call void @llvm.dbg.value(metadata double %70, metadata !450, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double %69, metadata !454, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !461, metadata !DIExpression()), !dbg !2626
  %71 = fmul double %70, 5.000000e-01, !dbg !2701
  tail call void @llvm.dbg.value(metadata double %71, metadata !458, metadata !DIExpression()), !dbg !2626
  %72 = fmul double %70, %71, !dbg !2702
  tail call void @llvm.dbg.value(metadata double %72, metadata !457, metadata !DIExpression()), !dbg !2626
  %73 = tail call double @llvm.fmuladd.f64(double %72, double 0xBE8AFDB76E09C32D, double 0x3ED0CFCA86E65239), !dbg !2703
  %74 = tail call double @llvm.fmuladd.f64(double %72, double %73, double 0xBF14CE199EAADBB7), !dbg !2704
  %75 = tail call double @llvm.fmuladd.f64(double %72, double %74, double 0x3F5A01A019FE5585), !dbg !2705
  %76 = tail call double @llvm.fmuladd.f64(double %72, double %75, double 0xBFA11111111110F4), !dbg !2706
  %77 = tail call double @llvm.fmuladd.f64(double %72, double %76, double 1.000000e+00), !dbg !2707
  tail call void @llvm.dbg.value(metadata double %77, metadata !459, metadata !DIExpression()), !dbg !2626
  %78 = fneg double %77, !dbg !2708
  %79 = tail call double @llvm.fmuladd.f64(double %78, double %71, double 3.000000e+00), !dbg !2708
  tail call void @llvm.dbg.value(metadata double %79, metadata !455, metadata !DIExpression()), !dbg !2626
  %80 = fsub double %77, %79, !dbg !2709
  %81 = fneg double %70, !dbg !2710
  %82 = tail call double @llvm.fmuladd.f64(double %81, double %79, double 6.000000e+00), !dbg !2710
  %83 = fdiv double %80, %82, !dbg !2711
  %84 = fmul double %72, %83, !dbg !2712
  tail call void @llvm.dbg.value(metadata double %84, metadata !456, metadata !DIExpression()), !dbg !2626
  %85 = icmp eq i32 %68, 0, !dbg !2713
  br i1 %85, label %86, label %90, !dbg !2714

86:                                               ; preds = %67
  %87 = fneg double %72, !dbg !2715
  %88 = tail call double @llvm.fmuladd.f64(double %70, double %84, double %87), !dbg !2715
  %89 = fsub double %70, %88, !dbg !2717
  br label %145, !dbg !2718

90:                                               ; preds = %67
  tail call void @llvm.dbg.value(metadata i64 0, metadata !475, metadata !DIExpression()), !dbg !2719
  %91 = shl i32 %68, 20, !dbg !2720
  %92 = add nsw i32 %91, 1072693248, !dbg !2720
  %93 = sext i32 %92 to i64, !dbg !2720
  %94 = shl nsw i64 %93, 32, !dbg !2720
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !475, metadata !DIExpression()), !dbg !2719
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !953, metadata !DIExpression()), !dbg !2721
  %95 = bitcast i64 %94 to double, !dbg !2723
  tail call void @llvm.dbg.value(metadata double %95, metadata !958, metadata !DIExpression()), !dbg !2721
  tail call void @llvm.dbg.value(metadata double %95, metadata !460, metadata !DIExpression()), !dbg !2626
  %96 = fsub double %84, %69, !dbg !2724
  %97 = fneg double %69, !dbg !2725
  %98 = tail call double @llvm.fmuladd.f64(double %70, double %96, double %97), !dbg !2725
  tail call void @llvm.dbg.value(metadata double %98, metadata !456, metadata !DIExpression()), !dbg !2626
  %99 = fsub double %98, %72, !dbg !2726
  tail call void @llvm.dbg.value(metadata double %99, metadata !456, metadata !DIExpression()), !dbg !2626
  switch i32 %68, label %112 [
    i32 -1, label %100
    i32 1, label %103
  ], !dbg !2727

100:                                              ; preds = %90
  %101 = fsub double %70, %99, !dbg !2728
  %102 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double -5.000000e-01), !dbg !2730
  br label %145, !dbg !2731

103:                                              ; preds = %90
  %104 = fcmp olt double %70, -2.500000e-01, !dbg !2732
  br i1 %104, label %105, label %109, !dbg !2736

105:                                              ; preds = %103
  %106 = fadd double %70, 5.000000e-01, !dbg !2737
  %107 = fsub double %99, %106, !dbg !2738
  %108 = fmul double %107, -2.000000e+00, !dbg !2739
  br label %145, !dbg !2740

109:                                              ; preds = %103
  %110 = fsub double %70, %99, !dbg !2741
  %111 = tail call double @llvm.fmuladd.f64(double %110, double 2.000000e+00, double 1.000000e+00), !dbg !2742
  br label %145, !dbg !2743

112:                                              ; preds = %90
  %113 = add i32 %68, -57, !dbg !2744
  %114 = icmp ult i32 %113, -58, !dbg !2744
  br i1 %114, label %115, label %124, !dbg !2744

115:                                              ; preds = %112
  %116 = fsub double %70, %99, !dbg !2746
  %117 = fadd double %116, 1.000000e+00, !dbg !2746
  tail call void @llvm.dbg.value(metadata double %117, metadata !451, metadata !DIExpression()), !dbg !2626
  %118 = icmp eq i32 %68, 1024, !dbg !2748
  %119 = fmul double %117, 2.000000e+00, !dbg !2750
  %120 = fmul double %119, 0x7FE0000000000000, !dbg !2750
  %121 = fmul double %117, %95, !dbg !2750
  %122 = select i1 %118, double %120, double %121, !dbg !2750
  tail call void @llvm.dbg.value(metadata double %122, metadata !451, metadata !DIExpression()), !dbg !2626
  %123 = fadd double %122, -1.000000e+00, !dbg !2751
  br label %145, !dbg !2752

124:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !455, metadata !DIExpression()), !dbg !2626
  %125 = icmp ult i32 %68, 20, !dbg !2753
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !879, metadata !DIExpression()), !dbg !2754
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !879, metadata !DIExpression()), !dbg !2756
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !884, metadata !DIExpression()), !dbg !2754
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !884, metadata !DIExpression()), !dbg !2756
  tail call void @llvm.dbg.value(metadata double poison, metadata !451, metadata !DIExpression()), !dbg !2626
  tail call void @llvm.dbg.value(metadata double poison, metadata !451, metadata !DIExpression()), !dbg !2626
  br i1 %125, label %126, label %134, !dbg !2758

126:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !479, metadata !DIExpression()), !dbg !2759
  %127 = lshr i32 2097152, %68
  %128 = sub nuw nsw i32 1072693248, %127, !dbg !2760
  %129 = zext nneg i32 %128 to i64
  %130 = shl nuw nsw i64 %129, 32, !dbg !2760
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !479, metadata !DIExpression()), !dbg !2759
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !953, metadata !DIExpression()), !dbg !2761
  %131 = bitcast i64 %130 to double, !dbg !2763
  tail call void @llvm.dbg.value(metadata double %131, metadata !958, metadata !DIExpression()), !dbg !2761
  tail call void @llvm.dbg.value(metadata double %131, metadata !455, metadata !DIExpression()), !dbg !2626
  %132 = fsub double %99, %70, !dbg !2764
  %133 = fsub double %131, %132, !dbg !2765
  br label %142, !dbg !2766

134:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !483, metadata !DIExpression()), !dbg !2767
  %135 = sub i32 1072693248, %91, !dbg !2768
  %136 = zext nneg i32 %135 to i64
  %137 = shl nuw nsw i64 %136, 32, !dbg !2768
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !483, metadata !DIExpression()), !dbg !2767
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !953, metadata !DIExpression()), !dbg !2769
  %138 = bitcast i64 %137 to double, !dbg !2771
  tail call void @llvm.dbg.value(metadata double %138, metadata !958, metadata !DIExpression()), !dbg !2769
  tail call void @llvm.dbg.value(metadata double %138, metadata !455, metadata !DIExpression()), !dbg !2626
  %139 = fadd double %99, %138, !dbg !2772
  %140 = fsub double %70, %139, !dbg !2773
  tail call void @llvm.dbg.value(metadata double %140, metadata !451, metadata !DIExpression()), !dbg !2626
  %141 = fadd double %140, 1.000000e+00, !dbg !2774
  br label %142

142:                                              ; preds = %126, %134
  %143 = phi double [ %133, %126 ], [ %141, %134 ]
  %144 = fmul double %143, %95, !dbg !2775
  tail call void @llvm.dbg.value(metadata double %144, metadata !451, metadata !DIExpression()), !dbg !2626
  br label %145, !dbg !2776

145:                                              ; preds = %27, %142, %115, %109, %105, %100, %86, %60, %23, %12
  %146 = phi double [ %20, %12 ], [ %26, %23 ], [ %89, %86 ], [ %102, %100 ], [ %108, %105 ], [ %111, %109 ], [ %123, %115 ], [ %144, %142 ], [ %66, %60 ], [ -1.000000e+00, %27 ], !dbg !2626
  ret double %146, !dbg !2777
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_cbrt(double noundef %0) local_unnamed_addr #0 !dbg !510 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !512, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !516, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2779
  %2 = bitcast double %0 to i64, !dbg !2781
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !2779
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !521, metadata !DIExpression()), !dbg !2782
  %3 = lshr i64 %2, 32, !dbg !2783
  %4 = trunc i64 %3 to i32, !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !513, metadata !DIExpression()), !dbg !2778
  %5 = trunc i64 %2 to i32, !dbg !2783
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !520, metadata !DIExpression()), !dbg !2778
  %6 = and i32 %4, -2147483648, !dbg !2784
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !518, metadata !DIExpression()), !dbg !2778
  %7 = and i32 %4, 2147483647, !dbg !2785
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !513, metadata !DIExpression()), !dbg !2778
  %8 = icmp ugt i32 %7, 2146435071, !dbg !2786
  br i1 %8, label %9, label %11, !dbg !2788

9:                                                ; preds = %1
  %10 = fadd double %0, %0, !dbg !2789
  br label %52, !dbg !2790

11:                                               ; preds = %1
  %12 = icmp ult i32 %7, 1048576, !dbg !2791
  br i1 %12, label %13, label %22, !dbg !2792

13:                                               ; preds = %11
  %14 = or i32 %7, %5, !dbg !2793
  %15 = icmp eq i32 %14, 0, !dbg !2795
  br i1 %15, label %52, label %16, !dbg !2796

16:                                               ; preds = %13
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !879, metadata !DIExpression()), !dbg !2797
  tail call void @llvm.dbg.value(metadata i64 0, metadata !884, metadata !DIExpression()), !dbg !2797
  tail call void @llvm.dbg.value(metadata i64 4850376798678024192, metadata !953, metadata !DIExpression()), !dbg !2799
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !958, metadata !DIExpression()), !dbg !2799
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !516, metadata !DIExpression()), !dbg !2778
  %17 = fmul double %0, 0x4350000000000000, !dbg !2801
  tail call void @llvm.dbg.value(metadata double %17, metadata !516, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata double %17, metadata !879, metadata !DIExpression()), !dbg !2802
  %18 = bitcast double %17 to i64, !dbg !2804
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !884, metadata !DIExpression()), !dbg !2802
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !527, metadata !DIExpression()), !dbg !2805
  %19 = lshr i64 %18, 32, !dbg !2806
  %20 = trunc i64 %19 to i32, !dbg !2806
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !519, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata i64 0, metadata !529, metadata !DIExpression()), !dbg !2807
  %21 = and i32 %20, 2147483647, !dbg !2808
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !529, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2807
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !529, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2807
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !953, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2809
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !958, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2809
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !516, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2778
  br label %22, !dbg !2811

22:                                               ; preds = %11, %16
  %23 = phi i32 [ %21, %16 ], [ %7, %11 ]
  %24 = phi i32 [ 696219795, %16 ], [ 715094163, %11 ]
  %25 = udiv i32 %23, 3
  %26 = add nuw nsw i32 %25, %24, !dbg !2812
  %27 = or disjoint i32 %26, %6, !dbg !2812
  %28 = zext i32 %27 to i64, !dbg !2812
  %29 = shl nuw i64 %28, 32, !dbg !2812
  %30 = bitcast i64 %29 to double, !dbg !2812
  tail call void @llvm.dbg.value(metadata double %30, metadata !516, metadata !DIExpression()), !dbg !2778
  %31 = fmul double %30, %30, !dbg !2813
  %32 = fdiv double %30, %0, !dbg !2814
  %33 = fmul double %31, %32, !dbg !2815
  tail call void @llvm.dbg.value(metadata double %33, metadata !514, metadata !DIExpression()), !dbg !2778
  %34 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FF9F1604A49D6C2, double 0xBFFE28E092F02420), !dbg !2816
  %35 = tail call double @llvm.fmuladd.f64(double %33, double %34, double 0x3FFE03E60F61E692), !dbg !2817
  %36 = fmul double %33, %33, !dbg !2818
  %37 = fmul double %33, %36, !dbg !2819
  %38 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FC2B000D4E4EDD7, double 0xBFE844CBBEE751D9), !dbg !2820
  %39 = tail call double @llvm.fmuladd.f64(double %37, double %38, double %35), !dbg !2821
  %40 = fmul double %39, %30, !dbg !2822
  tail call void @llvm.dbg.value(metadata double %40, metadata !516, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata double %40, metadata !879, metadata !DIExpression()), !dbg !2823
  %41 = bitcast double %40 to i64, !dbg !2825
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !884, metadata !DIExpression()), !dbg !2823
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !534, metadata !DIExpression()), !dbg !2778
  %42 = and i64 %41, -1073741824, !dbg !2826
  %43 = add i64 %42, 2147483648, !dbg !2826
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !534, metadata !DIExpression()), !dbg !2778
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !953, metadata !DIExpression()), !dbg !2827
  %44 = bitcast i64 %43 to double, !dbg !2829
  tail call void @llvm.dbg.value(metadata double %44, metadata !958, metadata !DIExpression()), !dbg !2827
  tail call void @llvm.dbg.value(metadata double %44, metadata !516, metadata !DIExpression()), !dbg !2778
  %45 = fmul double %44, %44, !dbg !2830
  tail call void @llvm.dbg.value(metadata double %45, metadata !515, metadata !DIExpression()), !dbg !2778
  %46 = fdiv double %0, %45, !dbg !2831
  tail call void @llvm.dbg.value(metadata double %46, metadata !514, metadata !DIExpression()), !dbg !2778
  %47 = fadd double %44, %44, !dbg !2832
  tail call void @llvm.dbg.value(metadata double %47, metadata !517, metadata !DIExpression()), !dbg !2778
  %48 = fsub double %46, %44, !dbg !2833
  %49 = fadd double %47, %46, !dbg !2834
  %50 = fdiv double %48, %49, !dbg !2835
  tail call void @llvm.dbg.value(metadata double %50, metadata !514, metadata !DIExpression()), !dbg !2778
  %51 = tail call double @llvm.fmuladd.f64(double %44, double %50, double %44), !dbg !2836
  tail call void @llvm.dbg.value(metadata double %51, metadata !516, metadata !DIExpression()), !dbg !2778
  br label %52

52:                                               ; preds = %13, %22, %9
  %53 = phi double [ %10, %9 ], [ %51, %22 ], [ %0, %13 ], !dbg !2778
  ret double %53, !dbg !2837
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_sin(double noundef %0) local_unnamed_addr #5 !dbg !2838 {
  %2 = alloca [2 x double], align 8, !DIAssignID !2847
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2841, metadata !DIExpression(), metadata !2847, metadata ptr %2, metadata !DIExpression()), !dbg !2848
  tail call void @llvm.dbg.value(metadata double %0, metadata !2840, metadata !DIExpression()), !dbg !2848
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !2849
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2842, metadata !DIExpression()), !dbg !2848
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2850
  %3 = bitcast double %0 to i64, !dbg !2852
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !2850
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !2845, metadata !DIExpression()), !dbg !2853
  %4 = lshr i64 %3, 32, !dbg !2854
  %5 = trunc i64 %4 to i32, !dbg !2854
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2844, metadata !DIExpression()), !dbg !2848
  %6 = and i32 %5, 2147483647, !dbg !2855
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !2844, metadata !DIExpression()), !dbg !2848
  %7 = icmp ult i32 %6, 1072243196, !dbg !2856
  br i1 %7, label %8, label %23, !dbg !2858

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !774, metadata !DIExpression()), !dbg !2859
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !775, metadata !DIExpression()), !dbg !2859
  call void @llvm.dbg.value(metadata i32 0, metadata !776, metadata !DIExpression()), !dbg !2859
  call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !2862
  call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !2862
  call void @llvm.dbg.value(metadata i64 %3, metadata !781, metadata !DIExpression()), !dbg !2864
  call void @llvm.dbg.value(metadata i64 %3, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2859
  call void @llvm.dbg.value(metadata i64 %3, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2859
  %9 = and i64 %3, 9205357638345293824, !dbg !2865
  %10 = icmp ult i64 %9, 4485585228861014016, !dbg !2865
  %11 = fptosi double %0 to i32
  %12 = icmp eq i32 %11, 0
  %13 = select i1 %10, i1 %12, i1 false, !dbg !2866
  br i1 %13, label %167, label %14, !dbg !2866

14:                                               ; preds = %8
  %15 = fmul double %0, %0, !dbg !2867
  call void @llvm.dbg.value(metadata double %15, metadata !777, metadata !DIExpression()), !dbg !2859
  %16 = fmul double %15, %0, !dbg !2868
  call void @llvm.dbg.value(metadata double %16, metadata !779, metadata !DIExpression()), !dbg !2859
  %17 = tail call double @llvm.fmuladd.f64(double %15, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2869
  %18 = tail call double @llvm.fmuladd.f64(double %15, double %17, double 0x3EC71DE357B1FE7D), !dbg !2870
  %19 = tail call double @llvm.fmuladd.f64(double %15, double %18, double 0xBF2A01A019C161D5), !dbg !2871
  %20 = tail call double @llvm.fmuladd.f64(double %15, double %19, double 0x3F8111111110F8A6), !dbg !2872
  call void @llvm.dbg.value(metadata double %20, metadata !778, metadata !DIExpression()), !dbg !2859
  %21 = tail call double @llvm.fmuladd.f64(double %15, double %20, double 0xBFC5555555555549), !dbg !2873
  %22 = tail call double @llvm.fmuladd.f64(double %16, double %21, double %0), !dbg !2875
  br label %167, !dbg !2876

23:                                               ; preds = %1
  %24 = icmp ugt i32 %6, 2146435071, !dbg !2877
  br i1 %24, label %25, label %27, !dbg !2879

25:                                               ; preds = %23
  %26 = fsub double %0, %0, !dbg !2880
  br label %167, !dbg !2882

27:                                               ; preds = %23
  %28 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !2883
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !2843, metadata !DIExpression()), !dbg !2848
  %29 = and i32 %28, 3, !dbg !2885
  %30 = load double, ptr %2, align 8, !dbg !2886, !tbaa !1443
  switch i32 %29, label %122 [
    i32 0, label %31
    i32 1, label %54
    i32 2, label %96
  ], !dbg !2888

31:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !774, metadata !DIExpression()), !dbg !2889
  call void @llvm.dbg.value(metadata double poison, metadata !775, metadata !DIExpression()), !dbg !2889
  call void @llvm.dbg.value(metadata i32 1, metadata !776, metadata !DIExpression()), !dbg !2889
  call void @llvm.dbg.value(metadata double %30, metadata !879, metadata !DIExpression()), !dbg !2891
  %32 = bitcast double %30 to i64, !dbg !2893
  call void @llvm.dbg.value(metadata i64 %32, metadata !884, metadata !DIExpression()), !dbg !2891
  call void @llvm.dbg.value(metadata i64 %32, metadata !781, metadata !DIExpression()), !dbg !2894
  call void @llvm.dbg.value(metadata i64 %32, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2889
  %33 = and i64 %32, 9205357638345293824, !dbg !2895
  %34 = icmp ult i64 %33, 4485585228861014016, !dbg !2895
  %35 = fptosi double %30 to i32
  %36 = icmp eq i32 %35, 0
  %37 = select i1 %34, i1 %36, i1 false, !dbg !2896
  br i1 %37, label %167, label %38, !dbg !2896

38:                                               ; preds = %31
  %39 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2897
  %40 = load double, ptr %39, align 8, !dbg !2897, !tbaa !1443
  call void @llvm.dbg.value(metadata double %40, metadata !775, metadata !DIExpression()), !dbg !2889
  %41 = fmul double %30, %30, !dbg !2898
  call void @llvm.dbg.value(metadata double %41, metadata !777, metadata !DIExpression()), !dbg !2889
  call void @llvm.dbg.value(metadata double poison, metadata !779, metadata !DIExpression()), !dbg !2889
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2899
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0x3EC71DE357B1FE7D), !dbg !2900
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0xBF2A01A019C161D5), !dbg !2901
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0x3F8111111110F8A6), !dbg !2902
  call void @llvm.dbg.value(metadata double %45, metadata !778, metadata !DIExpression()), !dbg !2889
  %46 = fneg double %41, !dbg !2903
  %47 = fmul double %30, %46, !dbg !2903
  %48 = fmul double %47, %45, !dbg !2903
  %49 = tail call double @llvm.fmuladd.f64(double %40, double 5.000000e-01, double %48), !dbg !2903
  %50 = fneg double %40, !dbg !2904
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %49, double %50), !dbg !2904
  %52 = tail call double @llvm.fmuladd.f64(double %47, double 0xBFC5555555555549, double %51), !dbg !2905
  %53 = fsub double %30, %52, !dbg !2906
  br label %167, !dbg !2907

54:                                               ; preds = %27
  %55 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2908
  %56 = load double, ptr %55, align 8, !dbg !2908, !tbaa !1443
  call void @llvm.dbg.value(metadata double %30, metadata !614, metadata !DIExpression()), !dbg !2909
  call void @llvm.dbg.value(metadata double %56, metadata !615, metadata !DIExpression()), !dbg !2909
  call void @llvm.dbg.value(metadata double %30, metadata !879, metadata !DIExpression()), !dbg !2911
  %57 = bitcast double %30 to i64, !dbg !2913
  call void @llvm.dbg.value(metadata i64 %57, metadata !884, metadata !DIExpression()), !dbg !2911
  call void @llvm.dbg.value(metadata i64 %57, metadata !622, metadata !DIExpression()), !dbg !2914
  %58 = lshr i64 %57, 32, !dbg !2915
  %59 = trunc i64 %58 to i32, !dbg !2915
  call void @llvm.dbg.value(metadata i32 %59, metadata !621, metadata !DIExpression()), !dbg !2909
  %60 = and i32 %59, 2147483647, !dbg !2916
  call void @llvm.dbg.value(metadata i32 %60, metadata !621, metadata !DIExpression()), !dbg !2909
  %61 = icmp ult i32 %60, 1044381696, !dbg !2917
  %62 = fptosi double %30 to i32
  %63 = icmp eq i32 %62, 0
  %64 = select i1 %61, i1 %63, i1 false, !dbg !2918
  br i1 %64, label %167, label %65, !dbg !2918

65:                                               ; preds = %54
  %66 = fmul double %30, %30, !dbg !2919
  call void @llvm.dbg.value(metadata double %66, metadata !618, metadata !DIExpression()), !dbg !2909
  %67 = tail call double @llvm.fmuladd.f64(double %66, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2920
  %68 = tail call double @llvm.fmuladd.f64(double %66, double %67, double 0xBE927E4F809C52AD), !dbg !2921
  %69 = tail call double @llvm.fmuladd.f64(double %66, double %68, double 0x3EFA01A019CB1590), !dbg !2922
  %70 = tail call double @llvm.fmuladd.f64(double %66, double %69, double 0xBF56C16C16C15177), !dbg !2923
  %71 = tail call double @llvm.fmuladd.f64(double %66, double %70, double 0x3FA555555555554C), !dbg !2924
  %72 = fmul double %66, %71, !dbg !2925
  call void @llvm.dbg.value(metadata double %72, metadata !619, metadata !DIExpression()), !dbg !2909
  %73 = icmp ult i32 %60, 1070805811, !dbg !2926
  br i1 %73, label %74, label %81, !dbg !2927

74:                                               ; preds = %65
  %75 = fneg double %30, !dbg !2928
  %76 = fmul double %56, %75, !dbg !2928
  %77 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %76), !dbg !2928
  %78 = fneg double %77, !dbg !2929
  %79 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %78), !dbg !2929
  %80 = fsub double 1.000000e+00, %79, !dbg !2930
  br label %167, !dbg !2931

81:                                               ; preds = %65
  %82 = icmp ugt i32 %60, 1072234496, !dbg !2932
  %83 = add nsw i32 %60, -2097152, !dbg !2933
  %84 = zext nneg i32 %83 to i64, !dbg !2933
  %85 = shl nuw nsw i64 %84, 32, !dbg !2933
  %86 = bitcast i64 %85 to double, !dbg !2933
  %87 = select i1 %82, double 2.812500e-01, double %86, !dbg !2933
  call void @llvm.dbg.value(metadata double %87, metadata !620, metadata !DIExpression()), !dbg !2909
  %88 = fneg double %87, !dbg !2934
  %89 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %88), !dbg !2934
  call void @llvm.dbg.value(metadata double %89, metadata !617, metadata !DIExpression()), !dbg !2909
  %90 = fsub double 1.000000e+00, %87, !dbg !2935
  call void @llvm.dbg.value(metadata double %90, metadata !616, metadata !DIExpression()), !dbg !2909
  %91 = fneg double %30, !dbg !2936
  %92 = fmul double %56, %91, !dbg !2936
  %93 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %92), !dbg !2936
  %94 = fsub double %93, %89, !dbg !2937
  %95 = fadd double %90, %94, !dbg !2937
  br label %167, !dbg !2938

96:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !774, metadata !DIExpression()), !dbg !2939
  call void @llvm.dbg.value(metadata double poison, metadata !775, metadata !DIExpression()), !dbg !2939
  call void @llvm.dbg.value(metadata i32 1, metadata !776, metadata !DIExpression()), !dbg !2939
  call void @llvm.dbg.value(metadata double %30, metadata !879, metadata !DIExpression()), !dbg !2941
  %97 = bitcast double %30 to i64, !dbg !2943
  call void @llvm.dbg.value(metadata i64 %97, metadata !884, metadata !DIExpression()), !dbg !2941
  call void @llvm.dbg.value(metadata i64 %97, metadata !781, metadata !DIExpression()), !dbg !2944
  call void @llvm.dbg.value(metadata i64 %97, metadata !780, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2939
  %98 = and i64 %97, 9205357638345293824, !dbg !2945
  %99 = icmp ult i64 %98, 4485585228861014016, !dbg !2945
  %100 = fptosi double %30 to i32
  %101 = icmp eq i32 %100, 0
  %102 = select i1 %99, i1 %101, i1 false, !dbg !2946
  br i1 %102, label %119, label %103, !dbg !2946

103:                                              ; preds = %96
  %104 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2947
  %105 = load double, ptr %104, align 8, !dbg !2947, !tbaa !1443
  call void @llvm.dbg.value(metadata double %105, metadata !775, metadata !DIExpression()), !dbg !2939
  %106 = fmul double %30, %30, !dbg !2948
  call void @llvm.dbg.value(metadata double %106, metadata !777, metadata !DIExpression()), !dbg !2939
  call void @llvm.dbg.value(metadata double poison, metadata !779, metadata !DIExpression()), !dbg !2939
  %107 = tail call double @llvm.fmuladd.f64(double %106, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2949
  %108 = tail call double @llvm.fmuladd.f64(double %106, double %107, double 0x3EC71DE357B1FE7D), !dbg !2950
  %109 = tail call double @llvm.fmuladd.f64(double %106, double %108, double 0xBF2A01A019C161D5), !dbg !2951
  %110 = tail call double @llvm.fmuladd.f64(double %106, double %109, double 0x3F8111111110F8A6), !dbg !2952
  call void @llvm.dbg.value(metadata double %110, metadata !778, metadata !DIExpression()), !dbg !2939
  %111 = fneg double %106, !dbg !2953
  %112 = fmul double %30, %111, !dbg !2953
  %113 = fmul double %112, %110, !dbg !2953
  %114 = tail call double @llvm.fmuladd.f64(double %105, double 5.000000e-01, double %113), !dbg !2953
  %115 = fneg double %105, !dbg !2954
  %116 = tail call double @llvm.fmuladd.f64(double %106, double %114, double %115), !dbg !2954
  %117 = tail call double @llvm.fmuladd.f64(double %112, double 0xBFC5555555555549, double %116), !dbg !2955
  %118 = fsub double %30, %117, !dbg !2956
  br label %119, !dbg !2957

119:                                              ; preds = %96, %103
  %120 = phi double [ %118, %103 ], [ %30, %96 ], !dbg !2939
  %121 = fneg double %120, !dbg !2958
  br label %167, !dbg !2959

122:                                              ; preds = %27
  %123 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2960
  %124 = load double, ptr %123, align 8, !dbg !2960, !tbaa !1443
  call void @llvm.dbg.value(metadata double %30, metadata !614, metadata !DIExpression()), !dbg !2961
  call void @llvm.dbg.value(metadata double %124, metadata !615, metadata !DIExpression()), !dbg !2961
  call void @llvm.dbg.value(metadata double %30, metadata !879, metadata !DIExpression()), !dbg !2963
  %125 = bitcast double %30 to i64, !dbg !2965
  call void @llvm.dbg.value(metadata i64 %125, metadata !884, metadata !DIExpression()), !dbg !2963
  call void @llvm.dbg.value(metadata i64 %125, metadata !622, metadata !DIExpression()), !dbg !2966
  %126 = lshr i64 %125, 32, !dbg !2967
  %127 = trunc i64 %126 to i32, !dbg !2967
  call void @llvm.dbg.value(metadata i32 %127, metadata !621, metadata !DIExpression()), !dbg !2961
  %128 = and i32 %127, 2147483647, !dbg !2968
  call void @llvm.dbg.value(metadata i32 %128, metadata !621, metadata !DIExpression()), !dbg !2961
  %129 = icmp ult i32 %128, 1044381696, !dbg !2969
  %130 = fptosi double %30 to i32
  %131 = icmp eq i32 %130, 0
  %132 = select i1 %129, i1 %131, i1 false, !dbg !2970
  br i1 %132, label %164, label %133, !dbg !2970

133:                                              ; preds = %122
  %134 = fmul double %30, %30, !dbg !2971
  call void @llvm.dbg.value(metadata double %134, metadata !618, metadata !DIExpression()), !dbg !2961
  %135 = tail call double @llvm.fmuladd.f64(double %134, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2972
  %136 = tail call double @llvm.fmuladd.f64(double %134, double %135, double 0xBE927E4F809C52AD), !dbg !2973
  %137 = tail call double @llvm.fmuladd.f64(double %134, double %136, double 0x3EFA01A019CB1590), !dbg !2974
  %138 = tail call double @llvm.fmuladd.f64(double %134, double %137, double 0xBF56C16C16C15177), !dbg !2975
  %139 = tail call double @llvm.fmuladd.f64(double %134, double %138, double 0x3FA555555555554C), !dbg !2976
  %140 = fmul double %134, %139, !dbg !2977
  call void @llvm.dbg.value(metadata double %140, metadata !619, metadata !DIExpression()), !dbg !2961
  %141 = icmp ult i32 %128, 1070805811, !dbg !2978
  br i1 %141, label %142, label %149, !dbg !2979

142:                                              ; preds = %133
  %143 = fneg double %30, !dbg !2980
  %144 = fmul double %124, %143, !dbg !2980
  %145 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %144), !dbg !2980
  %146 = fneg double %145, !dbg !2981
  %147 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %146), !dbg !2981
  %148 = fsub double 1.000000e+00, %147, !dbg !2982
  br label %164, !dbg !2983

149:                                              ; preds = %133
  %150 = icmp ugt i32 %128, 1072234496, !dbg !2984
  %151 = add nsw i32 %128, -2097152, !dbg !2985
  %152 = zext nneg i32 %151 to i64, !dbg !2985
  %153 = shl nuw nsw i64 %152, 32, !dbg !2985
  %154 = bitcast i64 %153 to double, !dbg !2985
  %155 = select i1 %150, double 2.812500e-01, double %154, !dbg !2985
  call void @llvm.dbg.value(metadata double %155, metadata !620, metadata !DIExpression()), !dbg !2961
  %156 = fneg double %155, !dbg !2986
  %157 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %156), !dbg !2986
  call void @llvm.dbg.value(metadata double %157, metadata !617, metadata !DIExpression()), !dbg !2961
  %158 = fsub double 1.000000e+00, %155, !dbg !2987
  call void @llvm.dbg.value(metadata double %158, metadata !616, metadata !DIExpression()), !dbg !2961
  %159 = fneg double %30, !dbg !2988
  %160 = fmul double %124, %159, !dbg !2988
  %161 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %160), !dbg !2988
  %162 = fsub double %161, %157, !dbg !2989
  %163 = fadd double %158, %162, !dbg !2989
  br label %164, !dbg !2990

164:                                              ; preds = %122, %142, %149
  %165 = phi double [ %148, %142 ], [ %163, %149 ], [ 1.000000e+00, %122 ], !dbg !2961
  %166 = fneg double %165, !dbg !2991
  br label %167, !dbg !2992

167:                                              ; preds = %81, %74, %54, %38, %31, %14, %8, %164, %119, %25
  %168 = phi double [ %26, %25 ], [ %166, %164 ], [ %121, %119 ], [ %22, %14 ], [ %0, %8 ], [ %53, %38 ], [ %30, %31 ], [ %80, %74 ], [ %95, %81 ], [ 1.000000e+00, %54 ], !dbg !2993
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !2994
  ret double %168, !dbg !2994
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_tan(double noundef %0) local_unnamed_addr #5 !dbg !2995 {
  %2 = alloca [2 x double], align 8, !DIAssignID !3004
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2998, metadata !DIExpression(), metadata !3004, metadata ptr %2, metadata !DIExpression()), !dbg !3005
  tail call void @llvm.dbg.value(metadata double %0, metadata !2997, metadata !DIExpression()), !dbg !3005
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !3006
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2999, metadata !DIExpression()), !dbg !3005
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !3007
  %3 = bitcast double %0 to i64, !dbg !3009
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !3007
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !3002, metadata !DIExpression()), !dbg !3010
  %4 = lshr i64 %3, 32, !dbg !3011
  %5 = trunc i64 %4 to i32, !dbg !3011
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !3001, metadata !DIExpression()), !dbg !3005
  %6 = and i32 %5, 2147483647, !dbg !3012
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !3001, metadata !DIExpression()), !dbg !3005
  %7 = icmp ult i32 %6, 1072243196, !dbg !3013
  br i1 %7, label %8, label %54, !dbg !3015

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !813, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !814, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata i32 1, metadata !815, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !3019
  call void @llvm.dbg.value(metadata i64 %3, metadata !884, metadata !DIExpression()), !dbg !3019
  call void @llvm.dbg.value(metadata i64 %3, metadata !823, metadata !DIExpression()), !dbg !3021
  call void @llvm.dbg.value(metadata i32 %5, metadata !822, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata i32 %6, metadata !821, metadata !DIExpression()), !dbg !3016
  %9 = icmp ult i32 %6, 1043333120, !dbg !3022
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !3023
  br i1 %12, label %160, label %13, !dbg !3023

13:                                               ; preds = %8
  %14 = icmp ugt i32 %6, 1072010279, !dbg !3024
  br i1 %14, label %15, label %21, !dbg !3026

15:                                               ; preds = %13
  %16 = icmp slt i64 %3, 0, !dbg !3027
  %17 = fneg double %0, !dbg !3030
  %18 = select i1 %16, double %17, double %0, !dbg !3030
  call void @llvm.dbg.value(metadata double %18, metadata !813, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double poison, metadata !814, metadata !DIExpression()), !dbg !3016
  %19 = fsub double 0x3FE921FB54442D18, %18, !dbg !3031
  call void @llvm.dbg.value(metadata double %19, metadata !816, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double 0x3C81A62633145C07, metadata !819, metadata !DIExpression()), !dbg !3016
  %20 = fadd double %19, 0x3C81A62633145C07, !dbg !3032
  call void @llvm.dbg.value(metadata double %20, metadata !813, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !814, metadata !DIExpression()), !dbg !3016
  br label %21, !dbg !3033

21:                                               ; preds = %15, %13
  %22 = phi double [ %20, %15 ], [ %0, %13 ]
  call void @llvm.dbg.value(metadata double %22, metadata !813, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !814, metadata !DIExpression()), !dbg !3016
  %23 = fmul double %22, %22, !dbg !3034
  call void @llvm.dbg.value(metadata double %23, metadata !816, metadata !DIExpression()), !dbg !3016
  %24 = fmul double %23, %23, !dbg !3035
  call void @llvm.dbg.value(metadata double %24, metadata !819, metadata !DIExpression()), !dbg !3016
  %25 = tail call double @llvm.fmuladd.f64(double %24, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3036
  %26 = tail call double @llvm.fmuladd.f64(double %24, double %25, double 0x3F4344D8F2F26501), !dbg !3037
  %27 = tail call double @llvm.fmuladd.f64(double %24, double %26, double 0x3F6D6D22C9560328), !dbg !3038
  %28 = tail call double @llvm.fmuladd.f64(double %24, double %27, double 0x3F9664F48406D637), !dbg !3039
  %29 = tail call double @llvm.fmuladd.f64(double %24, double %28, double 0x3FC111111110FE7A), !dbg !3040
  call void @llvm.dbg.value(metadata double %29, metadata !817, metadata !DIExpression()), !dbg !3016
  %30 = tail call double @llvm.fmuladd.f64(double %24, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3041
  %31 = tail call double @llvm.fmuladd.f64(double %24, double %30, double 0x3F3026F71A8D1068), !dbg !3042
  %32 = tail call double @llvm.fmuladd.f64(double %24, double %31, double 0x3F57DBC8FEE08315), !dbg !3043
  %33 = tail call double @llvm.fmuladd.f64(double %24, double %32, double 0x3F8226E3E96E8493), !dbg !3044
  %34 = tail call double @llvm.fmuladd.f64(double %24, double %33, double 0x3FABA1BA1BB341FE), !dbg !3045
  %35 = fmul double %23, %34, !dbg !3046
  call void @llvm.dbg.value(metadata double %35, metadata !818, metadata !DIExpression()), !dbg !3016
  %36 = fmul double %22, %23, !dbg !3047
  call void @llvm.dbg.value(metadata double %36, metadata !820, metadata !DIExpression()), !dbg !3016
  %37 = fadd double %29, %35, !dbg !3048
  %38 = tail call double @llvm.fmuladd.f64(double %36, double %37, double 0.000000e+00), !dbg !3049
  %39 = tail call double @llvm.fmuladd.f64(double %23, double %38, double 0.000000e+00), !dbg !3050
  call void @llvm.dbg.value(metadata double %39, metadata !817, metadata !DIExpression()), !dbg !3016
  %40 = tail call double @llvm.fmuladd.f64(double %36, double 0x3FD5555555555563, double %39), !dbg !3051
  call void @llvm.dbg.value(metadata double %40, metadata !817, metadata !DIExpression()), !dbg !3016
  %41 = fadd double %22, %40, !dbg !3052
  call void @llvm.dbg.value(metadata double %41, metadata !819, metadata !DIExpression()), !dbg !3016
  br i1 %14, label %42, label %160, !dbg !3053

42:                                               ; preds = %21
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !818, metadata !DIExpression()), !dbg !3016
  %43 = lshr i32 %5, 30, !dbg !3054
  %44 = and i32 %43, 2, !dbg !3057
  %45 = sub nsw i32 1, %44, !dbg !3058
  %46 = sitofp i32 %45 to double, !dbg !3059
  %47 = fmul double %41, %41, !dbg !3060
  %48 = fadd double %41, 1.000000e+00, !dbg !3061
  %49 = fdiv double %47, %48, !dbg !3062
  %50 = fsub double %49, %40, !dbg !3063
  %51 = fsub double %22, %50, !dbg !3064
  %52 = tail call double @llvm.fmuladd.f64(double %51, double -2.000000e+00, double 1.000000e+00), !dbg !3065
  %53 = fmul double %52, %46, !dbg !3066
  br label %160, !dbg !3067

54:                                               ; preds = %1
  %55 = icmp ugt i32 %6, 2146435071, !dbg !3068
  br i1 %55, label %56, label %58, !dbg !3070

56:                                               ; preds = %54
  %57 = fsub double %0, %0, !dbg !3071
  br label %160, !dbg !3073

58:                                               ; preds = %54
  %59 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !3074
  tail call void @llvm.dbg.value(metadata i32 %59, metadata !3000, metadata !DIExpression()), !dbg !3005
  %60 = load double, ptr %2, align 8, !dbg !3076, !tbaa !1443
  %61 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !3077
  %62 = load double, ptr %61, align 8, !dbg !3077, !tbaa !1443
  %63 = shl i32 %59, 1, !dbg !3078
  %64 = and i32 %63, 2, !dbg !3078
  %65 = sub nsw i32 1, %64, !dbg !3079
  call void @llvm.dbg.value(metadata double %60, metadata !813, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %62, metadata !814, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata i32 %65, metadata !815, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %60, metadata !879, metadata !DIExpression()), !dbg !3082
  %66 = bitcast double %60 to i64, !dbg !3084
  call void @llvm.dbg.value(metadata i64 %66, metadata !884, metadata !DIExpression()), !dbg !3082
  call void @llvm.dbg.value(metadata i64 %66, metadata !823, metadata !DIExpression()), !dbg !3085
  %67 = lshr i64 %66, 32, !dbg !3086
  %68 = trunc i64 %67 to i32, !dbg !3086
  call void @llvm.dbg.value(metadata i32 %68, metadata !822, metadata !DIExpression()), !dbg !3080
  %69 = and i32 %68, 2147483647, !dbg !3087
  call void @llvm.dbg.value(metadata i32 %69, metadata !821, metadata !DIExpression()), !dbg !3080
  %70 = icmp ult i32 %69, 1043333120, !dbg !3088
  %71 = fptosi double %60 to i32
  %72 = icmp eq i32 %71, 0
  %73 = select i1 %70, i1 %72, i1 false, !dbg !3089
  br i1 %73, label %74, label %99, !dbg !3089

74:                                               ; preds = %58
  call void @llvm.dbg.value(metadata double %60, metadata !879, metadata !DIExpression()), !dbg !3090
  call void @llvm.dbg.value(metadata i64 %66, metadata !884, metadata !DIExpression()), !dbg !3090
  call void @llvm.dbg.value(metadata i64 %66, metadata !830, metadata !DIExpression()), !dbg !3092
  %75 = trunc i64 %66 to i32, !dbg !3093
  call void @llvm.dbg.value(metadata i32 %75, metadata !825, metadata !DIExpression()), !dbg !3094
  %76 = sub nuw nsw i32 2, %64, !dbg !3095
  %77 = or i32 %76, %75, !dbg !3096
  %78 = or i32 %77, %69, !dbg !3096
  %79 = icmp eq i32 %78, 0, !dbg !3097
  br i1 %79, label %80, label %83, !dbg !3098

80:                                               ; preds = %74
  %81 = tail call double @llvm.fabs.f64(double %60), !dbg !3099
  %82 = fdiv double 1.000000e+00, %81, !dbg !3101
  br label %160, !dbg !3102

83:                                               ; preds = %74
  %84 = icmp eq i32 %64, 0, !dbg !3103
  br i1 %84, label %160, label %85, !dbg !3104

85:                                               ; preds = %83
  %86 = fadd double %60, %62, !dbg !3105
  call void @llvm.dbg.value(metadata double %86, metadata !819, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %86, metadata !816, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %86, metadata !879, metadata !DIExpression()), !dbg !3106
  %87 = bitcast double %86 to i64, !dbg !3108
  call void @llvm.dbg.value(metadata i64 %87, metadata !884, metadata !DIExpression()), !dbg !3106
  call void @llvm.dbg.value(metadata i64 %87, metadata !838, metadata !DIExpression()), !dbg !3109
  %88 = and i64 %87, -4294967296, !dbg !3110
  call void @llvm.dbg.value(metadata i64 %88, metadata !838, metadata !DIExpression()), !dbg !3109
  call void @llvm.dbg.value(metadata i64 %88, metadata !953, metadata !DIExpression()), !dbg !3111
  %89 = bitcast i64 %88 to double, !dbg !3113
  call void @llvm.dbg.value(metadata double %89, metadata !958, metadata !DIExpression()), !dbg !3111
  call void @llvm.dbg.value(metadata double %89, metadata !816, metadata !DIExpression()), !dbg !3080
  %90 = fsub double %89, %60, !dbg !3114
  %91 = fsub double %62, %90, !dbg !3115
  call void @llvm.dbg.value(metadata double %91, metadata !818, metadata !DIExpression()), !dbg !3080
  %92 = fdiv double -1.000000e+00, %86, !dbg !3116
  call void @llvm.dbg.value(metadata double %92, metadata !832, metadata !DIExpression()), !dbg !3117
  call void @llvm.dbg.value(metadata double %92, metadata !837, metadata !DIExpression()), !dbg !3117
  call void @llvm.dbg.value(metadata double %92, metadata !879, metadata !DIExpression()), !dbg !3118
  %93 = bitcast double %92 to i64, !dbg !3120
  call void @llvm.dbg.value(metadata i64 %93, metadata !884, metadata !DIExpression()), !dbg !3118
  call void @llvm.dbg.value(metadata i64 %93, metadata !840, metadata !DIExpression()), !dbg !3121
  %94 = and i64 %93, -4294967296, !dbg !3122
  call void @llvm.dbg.value(metadata i64 %94, metadata !840, metadata !DIExpression()), !dbg !3121
  call void @llvm.dbg.value(metadata i64 %94, metadata !953, metadata !DIExpression()), !dbg !3123
  %95 = bitcast i64 %94 to double, !dbg !3125
  call void @llvm.dbg.value(metadata double %95, metadata !958, metadata !DIExpression()), !dbg !3123
  call void @llvm.dbg.value(metadata double %95, metadata !837, metadata !DIExpression()), !dbg !3117
  %96 = tail call double @llvm.fmuladd.f64(double %95, double %89, double 1.000000e+00), !dbg !3126
  call void @llvm.dbg.value(metadata double %96, metadata !820, metadata !DIExpression()), !dbg !3080
  %97 = tail call double @llvm.fmuladd.f64(double %95, double %91, double %96), !dbg !3127
  %98 = tail call double @llvm.fmuladd.f64(double %92, double %97, double %95), !dbg !3128
  br label %160

99:                                               ; preds = %58
  %100 = icmp ugt i32 %69, 1072010279, !dbg !3129
  br i1 %100, label %101, label %110, !dbg !3130

101:                                              ; preds = %99
  %102 = icmp slt i64 %66, 0, !dbg !3131
  %103 = fneg double %60, !dbg !3132
  %104 = fneg double %62, !dbg !3132
  %105 = select i1 %102, double %104, double %62, !dbg !3132
  %106 = select i1 %102, double %103, double %60, !dbg !3132
  call void @llvm.dbg.value(metadata double %106, metadata !813, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %105, metadata !814, metadata !DIExpression()), !dbg !3080
  %107 = fsub double 0x3FE921FB54442D18, %106, !dbg !3133
  call void @llvm.dbg.value(metadata double %107, metadata !816, metadata !DIExpression()), !dbg !3080
  %108 = fsub double 0x3C81A62633145C07, %105, !dbg !3134
  call void @llvm.dbg.value(metadata double %108, metadata !819, metadata !DIExpression()), !dbg !3080
  %109 = fadd double %107, %108, !dbg !3135
  call void @llvm.dbg.value(metadata double %109, metadata !813, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !814, metadata !DIExpression()), !dbg !3080
  br label %110, !dbg !3136

110:                                              ; preds = %101, %99
  %111 = phi double [ 0.000000e+00, %101 ], [ %62, %99 ]
  %112 = phi double [ %109, %101 ], [ %60, %99 ]
  call void @llvm.dbg.value(metadata double %112, metadata !813, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %111, metadata !814, metadata !DIExpression()), !dbg !3080
  %113 = fmul double %112, %112, !dbg !3137
  call void @llvm.dbg.value(metadata double %113, metadata !816, metadata !DIExpression()), !dbg !3080
  %114 = fmul double %113, %113, !dbg !3138
  call void @llvm.dbg.value(metadata double %114, metadata !819, metadata !DIExpression()), !dbg !3080
  %115 = tail call double @llvm.fmuladd.f64(double %114, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3139
  %116 = tail call double @llvm.fmuladd.f64(double %114, double %115, double 0x3F4344D8F2F26501), !dbg !3140
  %117 = tail call double @llvm.fmuladd.f64(double %114, double %116, double 0x3F6D6D22C9560328), !dbg !3141
  %118 = tail call double @llvm.fmuladd.f64(double %114, double %117, double 0x3F9664F48406D637), !dbg !3142
  %119 = tail call double @llvm.fmuladd.f64(double %114, double %118, double 0x3FC111111110FE7A), !dbg !3143
  call void @llvm.dbg.value(metadata double %119, metadata !817, metadata !DIExpression()), !dbg !3080
  %120 = tail call double @llvm.fmuladd.f64(double %114, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3144
  %121 = tail call double @llvm.fmuladd.f64(double %114, double %120, double 0x3F3026F71A8D1068), !dbg !3145
  %122 = tail call double @llvm.fmuladd.f64(double %114, double %121, double 0x3F57DBC8FEE08315), !dbg !3146
  %123 = tail call double @llvm.fmuladd.f64(double %114, double %122, double 0x3F8226E3E96E8493), !dbg !3147
  %124 = tail call double @llvm.fmuladd.f64(double %114, double %123, double 0x3FABA1BA1BB341FE), !dbg !3148
  %125 = fmul double %113, %124, !dbg !3149
  call void @llvm.dbg.value(metadata double %125, metadata !818, metadata !DIExpression()), !dbg !3080
  %126 = fmul double %112, %113, !dbg !3150
  call void @llvm.dbg.value(metadata double %126, metadata !820, metadata !DIExpression()), !dbg !3080
  %127 = fadd double %119, %125, !dbg !3151
  %128 = tail call double @llvm.fmuladd.f64(double %126, double %127, double %111), !dbg !3152
  %129 = tail call double @llvm.fmuladd.f64(double %113, double %128, double %111), !dbg !3153
  call void @llvm.dbg.value(metadata double %129, metadata !817, metadata !DIExpression()), !dbg !3080
  %130 = tail call double @llvm.fmuladd.f64(double %126, double 0x3FD5555555555563, double %129), !dbg !3154
  call void @llvm.dbg.value(metadata double %130, metadata !817, metadata !DIExpression()), !dbg !3080
  %131 = fadd double %112, %130, !dbg !3155
  call void @llvm.dbg.value(metadata double %131, metadata !819, metadata !DIExpression()), !dbg !3080
  br i1 %100, label %132, label %145, !dbg !3156

132:                                              ; preds = %110
  %133 = sitofp i32 %65 to double, !dbg !3157
  call void @llvm.dbg.value(metadata double %133, metadata !818, metadata !DIExpression()), !dbg !3080
  %134 = lshr i32 %68, 30, !dbg !3158
  %135 = and i32 %134, 2, !dbg !3159
  %136 = sub nsw i32 1, %135, !dbg !3160
  %137 = sitofp i32 %136 to double, !dbg !3161
  %138 = fmul double %131, %131, !dbg !3162
  %139 = fadd double %131, %133, !dbg !3163
  %140 = fdiv double %138, %139, !dbg !3164
  %141 = fsub double %140, %130, !dbg !3165
  %142 = fsub double %112, %141, !dbg !3166
  %143 = tail call double @llvm.fmuladd.f64(double %142, double -2.000000e+00, double %133), !dbg !3167
  %144 = fmul double %143, %137, !dbg !3168
  br label %160, !dbg !3169

145:                                              ; preds = %110
  %146 = icmp eq i32 %64, 0, !dbg !3170
  br i1 %146, label %160, label %147, !dbg !3171

147:                                              ; preds = %145
  call void @llvm.dbg.value(metadata double %131, metadata !816, metadata !DIExpression()), !dbg !3080
  call void @llvm.dbg.value(metadata double %131, metadata !879, metadata !DIExpression()), !dbg !3172
  %148 = bitcast double %131 to i64, !dbg !3174
  call void @llvm.dbg.value(metadata i64 %148, metadata !884, metadata !DIExpression()), !dbg !3172
  call void @llvm.dbg.value(metadata i64 %148, metadata !846, metadata !DIExpression()), !dbg !3175
  %149 = and i64 %148, -4294967296, !dbg !3176
  call void @llvm.dbg.value(metadata i64 %149, metadata !846, metadata !DIExpression()), !dbg !3175
  call void @llvm.dbg.value(metadata i64 %149, metadata !953, metadata !DIExpression()), !dbg !3177
  %150 = bitcast i64 %149 to double, !dbg !3179
  call void @llvm.dbg.value(metadata double %150, metadata !958, metadata !DIExpression()), !dbg !3177
  call void @llvm.dbg.value(metadata double %150, metadata !816, metadata !DIExpression()), !dbg !3080
  %151 = fsub double %150, %112, !dbg !3180
  %152 = fsub double %130, %151, !dbg !3181
  call void @llvm.dbg.value(metadata double %152, metadata !818, metadata !DIExpression()), !dbg !3080
  %153 = fdiv double -1.000000e+00, %131, !dbg !3182
  call void @llvm.dbg.value(metadata double %153, metadata !842, metadata !DIExpression()), !dbg !3183
  call void @llvm.dbg.value(metadata double %153, metadata !845, metadata !DIExpression()), !dbg !3183
  call void @llvm.dbg.value(metadata double %153, metadata !879, metadata !DIExpression()), !dbg !3184
  %154 = bitcast double %153 to i64, !dbg !3186
  call void @llvm.dbg.value(metadata i64 %154, metadata !884, metadata !DIExpression()), !dbg !3184
  call void @llvm.dbg.value(metadata i64 %154, metadata !848, metadata !DIExpression()), !dbg !3187
  %155 = and i64 %154, -4294967296, !dbg !3188
  call void @llvm.dbg.value(metadata i64 %155, metadata !848, metadata !DIExpression()), !dbg !3187
  call void @llvm.dbg.value(metadata i64 %155, metadata !953, metadata !DIExpression()), !dbg !3189
  %156 = bitcast i64 %155 to double, !dbg !3191
  call void @llvm.dbg.value(metadata double %156, metadata !958, metadata !DIExpression()), !dbg !3189
  call void @llvm.dbg.value(metadata double %156, metadata !845, metadata !DIExpression()), !dbg !3183
  %157 = tail call double @llvm.fmuladd.f64(double %156, double %150, double 1.000000e+00), !dbg !3192
  call void @llvm.dbg.value(metadata double %157, metadata !820, metadata !DIExpression()), !dbg !3080
  %158 = tail call double @llvm.fmuladd.f64(double %156, double %152, double %157), !dbg !3193
  %159 = tail call double @llvm.fmuladd.f64(double %153, double %158, double %156), !dbg !3194
  br label %160

160:                                              ; preds = %8, %147, %145, %132, %85, %83, %80, %42, %21, %56
  %161 = phi double [ %57, %56 ], [ %53, %42 ], [ %41, %21 ], [ %144, %132 ], [ %159, %147 ], [ %82, %80 ], [ %98, %85 ], [ %60, %83 ], [ %131, %145 ], [ %0, %8 ], !dbg !3195
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !3196
  ret double %161, !dbg !3196
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_cosh(double noundef %0) local_unnamed_addr #7 !dbg !550 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !552, metadata !DIExpression()), !dbg !3197
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !3198
  %2 = bitcast double %0 to i64, !dbg !3200
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !3198
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !554, metadata !DIExpression()), !dbg !3201
  %3 = lshr i64 %2, 32, !dbg !3202
  %4 = trunc i64 %3 to i32, !dbg !3202
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !553, metadata !DIExpression()), !dbg !3197
  %5 = and i32 %4, 2147483647, !dbg !3203
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !553, metadata !DIExpression()), !dbg !3197
  %6 = icmp ult i32 %5, 1071001155, !dbg !3204
  br i1 %6, label %7, label %17, !dbg !3205

7:                                                ; preds = %1
  %8 = tail call double @llvm.fabs.f64(double %0), !dbg !3206
  %9 = tail call double @pts_ieee754_expm1(double noundef %8), !dbg !3207
  tail call void @llvm.dbg.value(metadata double %9, metadata !556, metadata !DIExpression()), !dbg !3208
  %10 = fadd double %9, 1.000000e+00, !dbg !3209
  tail call void @llvm.dbg.value(metadata double %10, metadata !559, metadata !DIExpression()), !dbg !3208
  %11 = icmp ult i32 %5, 1015021568, !dbg !3210
  br i1 %11, label %45, label %12, !dbg !3212

12:                                               ; preds = %7
  %13 = fmul double %9, %9, !dbg !3213
  %14 = fadd double %10, %10, !dbg !3214
  %15 = fdiv double %13, %14, !dbg !3215
  %16 = fadd double %15, 1.000000e+00, !dbg !3216
  br label %45, !dbg !3217

17:                                               ; preds = %1
  %18 = icmp ult i32 %5, 1077280768, !dbg !3218
  br i1 %18, label %19, label %24, !dbg !3219

19:                                               ; preds = %17
  %20 = tail call double @llvm.fabs.f64(double %0), !dbg !3220
  %21 = tail call double @pts_ieee754_exp(double noundef %20), !dbg !3221
  tail call void @llvm.dbg.value(metadata double %21, metadata !560, metadata !DIExpression()), !dbg !3222
  %22 = fdiv double 5.000000e-01, %21, !dbg !3223
  %23 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %22), !dbg !3224
  br label %45

24:                                               ; preds = %17
  %25 = icmp ult i32 %5, 1082535490, !dbg !3225
  %26 = tail call double @llvm.fabs.f64(double %0), !dbg !3197
  br i1 %25, label %27, label %30, !dbg !3227

27:                                               ; preds = %24
  %28 = tail call double @pts_ieee754_exp(double noundef %26), !dbg !3228
  %29 = fmul double %28, 5.000000e-01, !dbg !3229
  br label %45, !dbg !3230

30:                                               ; preds = %24
  %31 = fcmp ugt double %26, 0x408633CE8FB9F87D, !dbg !3231
  br i1 %31, label %37, label %32, !dbg !3232

32:                                               ; preds = %30
  %33 = fmul double %26, 5.000000e-01, !dbg !3233
  %34 = tail call double @pts_ieee754_exp(double noundef %33), !dbg !3234
  tail call void @llvm.dbg.value(metadata double %34, metadata !563, metadata !DIExpression()), !dbg !3235
  %35 = fmul double %34, 5.000000e-01, !dbg !3236
  tail call void @llvm.dbg.value(metadata double %35, metadata !566, metadata !DIExpression()), !dbg !3235
  %36 = fmul double %34, %35, !dbg !3237
  br label %45

37:                                               ; preds = %30
  %38 = icmp ugt i32 %5, 2146435071, !dbg !3238
  br i1 %38, label %39, label %41, !dbg !3240

39:                                               ; preds = %37
  %40 = fmul double %0, %0, !dbg !3241
  br label %45, !dbg !3242

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3243, !tbaa !1443
  %43 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3244, !tbaa !1443
  %44 = fmul double %42, %43, !dbg !3245
  br label %45, !dbg !3246

45:                                               ; preds = %12, %7, %41, %39, %32, %27, %19
  %46 = phi double [ %23, %19 ], [ %29, %27 ], [ %36, %32 ], [ %40, %39 ], [ %44, %41 ], [ %16, %12 ], [ %10, %7 ], !dbg !3197
  ret double %46, !dbg !3247
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_sinh(double noundef %0) local_unnamed_addr #7 !dbg !575 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !577, metadata !DIExpression()), !dbg !3248
  %2 = fcmp olt double %0, 0.000000e+00, !dbg !3249
  %3 = select i1 %2, double -5.000000e-01, double 5.000000e-01, !dbg !3250
  tail call void @llvm.dbg.value(metadata double %3, metadata !578, metadata !DIExpression()), !dbg !3248
  %4 = tail call double @llvm.fabs.f64(double %0), !dbg !3251
  tail call void @llvm.dbg.value(metadata double %4, metadata !579, metadata !DIExpression()), !dbg !3248
  %5 = fcmp olt double %4, 2.200000e+01, !dbg !3252
  br i1 %5, label %6, label %23, !dbg !3253

6:                                                ; preds = %1
  %7 = fcmp olt double %4, 0x3E30000000000000, !dbg !3254
  br i1 %7, label %37, label %8, !dbg !3256

8:                                                ; preds = %6
  %9 = tail call double @pts_ieee754_expm1(double noundef %4), !dbg !3257
  tail call void @llvm.dbg.value(metadata double %9, metadata !580, metadata !DIExpression()), !dbg !3258
  %10 = fcmp olt double %4, 1.000000e+00, !dbg !3259
  %11 = fadd double %9, 1.000000e+00, !dbg !3258
  br i1 %10, label %12, label %17, !dbg !3261

12:                                               ; preds = %8
  %13 = fneg double %9, !dbg !3262
  %14 = fmul double %9, %13, !dbg !3262
  %15 = fdiv double %14, %11, !dbg !3262
  %16 = tail call double @llvm.fmuladd.f64(double %9, double 2.000000e+00, double %15), !dbg !3262
  br label %20, !dbg !3264

17:                                               ; preds = %8
  %18 = fdiv double %9, %11, !dbg !3265
  %19 = fadd double %9, %18, !dbg !3266
  br label %20, !dbg !3267

20:                                               ; preds = %17, %12
  %21 = phi double [ %16, %12 ], [ %19, %17 ]
  %22 = fmul double %3, %21, !dbg !3258
  br label %37

23:                                               ; preds = %1
  %24 = fcmp olt double %4, 0x40862E4200000000, !dbg !3268
  br i1 %24, label %25, label %28, !dbg !3270

25:                                               ; preds = %23
  %26 = tail call double @pts_ieee754_exp(double noundef %4), !dbg !3271
  %27 = fmul double %3, %26, !dbg !3272
  br label %37, !dbg !3273

28:                                               ; preds = %23
  %29 = fcmp ugt double %4, 0x408633CE8FB9F87D, !dbg !3274
  br i1 %29, label %35, label %30, !dbg !3275

30:                                               ; preds = %28
  %31 = fmul double %4, 5.000000e-01, !dbg !3276
  %32 = tail call double @pts_ieee754_exp(double noundef %31), !dbg !3277
  tail call void @llvm.dbg.value(metadata double %32, metadata !583, metadata !DIExpression()), !dbg !3278
  %33 = fmul double %3, %32, !dbg !3279
  tail call void @llvm.dbg.value(metadata double %33, metadata !586, metadata !DIExpression()), !dbg !3278
  %34 = fmul double %32, %33, !dbg !3280
  br label %37

35:                                               ; preds = %28
  %36 = fmul double %0, 0x7FAC7B1F3CAC7433, !dbg !3281
  br label %37, !dbg !3282

37:                                               ; preds = %6, %35, %30, %25, %20
  %38 = phi double [ %22, %20 ], [ %27, %25 ], [ %34, %30 ], [ %36, %35 ], [ %0, %6 ], !dbg !3248
  ret double %38, !dbg !3283
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_tanh(double noundef %0) local_unnamed_addr #7 !dbg !595 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !597, metadata !DIExpression()), !dbg !3284
  tail call void @llvm.dbg.value(metadata double %0, metadata !879, metadata !DIExpression()), !dbg !3285
  %2 = bitcast double %0 to i64, !dbg !3287
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !884, metadata !DIExpression()), !dbg !3285
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !602, metadata !DIExpression()), !dbg !3288
  %3 = lshr i64 %2, 32, !dbg !3289
  %4 = trunc i64 %3 to i32, !dbg !3289
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !600, metadata !DIExpression()), !dbg !3284
  %5 = and i32 %4, 2147483647, !dbg !3290
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !601, metadata !DIExpression()), !dbg !3284
  %6 = icmp ugt i32 %5, 2146435071, !dbg !3291
  br i1 %6, label %7, label %14, !dbg !3293

7:                                                ; preds = %1
  %8 = icmp sgt i64 %2, -1, !dbg !3294
  %9 = fdiv double 1.000000e+00, %0, !dbg !3297
  br i1 %8, label %10, label %12, !dbg !3298

10:                                               ; preds = %7
  %11 = fadd double %9, 1.000000e+00, !dbg !3299
  br label %44, !dbg !3300

12:                                               ; preds = %7
  %13 = fadd double %9, -1.000000e+00, !dbg !3301
  br label %44, !dbg !3302

14:                                               ; preds = %1
  %15 = icmp ult i32 %5, 1077280768, !dbg !3303
  br i1 %15, label %16, label %36, !dbg !3305

16:                                               ; preds = %14
  %17 = icmp ult i32 %5, 1043333120, !dbg !3306
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 1.000000e+00
  %20 = and i1 %19, %17, !dbg !3309
  br i1 %20, label %44, label %21, !dbg !3309

21:                                               ; preds = %16
  %22 = icmp ugt i32 %5, 1072693247, !dbg !3310
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !3312
  br i1 %22, label %24, label %30, !dbg !3313

24:                                               ; preds = %21
  %25 = fmul double %23, 2.000000e+00, !dbg !3314
  %26 = tail call double @pts_ieee754_expm1(double noundef %25), !dbg !3316
  tail call void @llvm.dbg.value(metadata double %26, metadata !598, metadata !DIExpression()), !dbg !3284
  %27 = fadd double %26, 2.000000e+00, !dbg !3317
  %28 = fdiv double 2.000000e+00, %27, !dbg !3318
  %29 = fsub double 1.000000e+00, %28, !dbg !3319
  tail call void @llvm.dbg.value(metadata double %29, metadata !599, metadata !DIExpression()), !dbg !3284
  br label %39, !dbg !3320

30:                                               ; preds = %21
  %31 = fmul double %23, -2.000000e+00, !dbg !3321
  %32 = tail call double @pts_ieee754_expm1(double noundef %31), !dbg !3323
  tail call void @llvm.dbg.value(metadata double %32, metadata !598, metadata !DIExpression()), !dbg !3284
  %33 = fneg double %32, !dbg !3324
  %34 = fadd double %32, 2.000000e+00, !dbg !3325
  %35 = fdiv double %33, %34, !dbg !3326
  tail call void @llvm.dbg.value(metadata double %35, metadata !599, metadata !DIExpression()), !dbg !3284
  br label %39

36:                                               ; preds = %14
  %37 = load volatile double, ptr @pts_ieee754_tanh.tiny, align 8, !dbg !3327, !tbaa !1443
  %38 = fsub double 1.000000e+00, %37, !dbg !3329
  tail call void @llvm.dbg.value(metadata double %38, metadata !599, metadata !DIExpression()), !dbg !3284
  br label %39

39:                                               ; preds = %24, %30, %36
  %40 = phi double [ %29, %24 ], [ %35, %30 ], [ %38, %36 ], !dbg !3330
  tail call void @llvm.dbg.value(metadata double %40, metadata !599, metadata !DIExpression()), !dbg !3284
  %41 = fneg double %40, !dbg !3331
  %42 = icmp slt i64 %2, 0, !dbg !3331
  %43 = select i1 %42, double %41, double %40, !dbg !3331
  br label %44, !dbg !3332

44:                                               ; preds = %16, %39, %12, %10
  %45 = phi double [ %11, %10 ], [ %13, %12 ], [ %43, %39 ], [ %0, %16 ], !dbg !3284
  ret double %45, !dbg !3333
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #2

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !3334 double @scalbn(double noundef, i32 noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #9

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.vector.reduce.fadd.v2f64(double, <2 x double>) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v4i32(<4 x i32>) #9

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { mustprogress nofree norecurse nounwind willreturn memory(inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #4 = { mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { nofree nosync nounwind memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #6 = { nofree nosync nounwind memory(argmem: write) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #7 = { mustprogress nofree norecurse nounwind willreturn uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #8 = { mustprogress nofree nosync nounwind willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { nounwind }
attributes #12 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!7}
!llvm.module.flags = !{!869, !870, !871, !872, !873, !874, !875, !876}
!llvm.ident = !{!877}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "atanhi", scope: !2, file: !3, line: 1148, type: !161, isLocal: true, isDefinition: true)
!2 = distinct !DISubprogram(name: "pts_ieee754_atan", scope: !3, file: !3, line: 1147, type: !4, scopeLine: 1147, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !853)
!3 = !DIFile(filename: "../src/ieee754_head.c", directory: "/tmp/pts-h36/repro/clang_on", checksumkind: CSK_MD5, checksum: "5651070fafa2d14650842267211b7bd6")
!4 = !DISubroutineType(types: !5)
!5 = !{!6, !6}
!6 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!7 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !8, globals: !24, splitDebugInlining: false, nameTableKind: None)
!8 = !{!9, !14, !17, !18, !21, !6}
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !10, line: 26, baseType: !11)
!10 = !DIFile(filename: "/usr/bin/../lib/gcc-cross/aarch64-linux-gnu/13/../../../../aarch64-linux-gnu/include/bits/stdint-uintn.h", directory: "", checksumkind: CSK_MD5, checksum: "256fcabbefa27ca8cf5e6d37525e6e16")
!11 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint32_t", file: !12, line: 42, baseType: !13)
!12 = !DIFile(filename: "/usr/bin/../lib/gcc-cross/aarch64-linux-gnu/13/../../../../aarch64-linux-gnu/include/bits/types.h", directory: "", checksumkind: CSK_MD5, checksum: "e1865d9fe29fe1b5ced550b7ba458f9e")
!13 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!14 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !15, size: 64)
!15 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !16)
!16 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !6)
!17 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !10, line: 27, baseType: !19)
!19 = !DIDerivedType(tag: DW_TAG_typedef, name: "__uint64_t", file: !12, line: 45, baseType: !20)
!20 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!21 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !22, line: 26, baseType: !23)
!22 = !DIFile(filename: "/usr/bin/../lib/gcc-cross/aarch64-linux-gnu/13/../../../../aarch64-linux-gnu/include/bits/stdint-intn.h", directory: "", checksumkind: CSK_MD5, checksum: "649b383a60bfa3eb90e85840b2b0be20")
!23 = !DIDerivedType(tag: DW_TAG_typedef, name: "__int32_t", file: !12, line: 41, baseType: !17)
!24 = !{!25, !53, !55, !57, !59, !61, !63, !65, !67, !69, !71, !73, !75, !77, !79, !89, !91, !116, !118, !120, !122, !124, !126, !128, !130, !132, !134, !136, !138, !140, !142, !144, !155, !157, !0, !159, !164, !169, !171, !173, !194, !196, !198, !200, !202, !204, !234, !239, !241, !243, !245, !247, !249, !251, !253, !255, !257, !259, !261, !263, !265, !267, !280, !282, !284, !311, !313, !315, !317, !319, !321, !323, !325, !327, !329, !331, !365, !367, !369, !371, !373, !375, !377, !379, !381, !383, !385, !413, !415, !417, !440, !442, !444, !446, !486, !488, !490, !492, !494, !496, !498, !500, !502, !504, !506, !508, !536, !538, !540, !542, !544, !546, !548, !567, !569, !571, !573, !587, !589, !591, !593, !604, !606, !608, !610, !630, !632, !634, !636, !638, !640, !642, !691, !696, !698, !700, !702, !704, !706, !708, !710, !712, !714, !716, !755, !760, !762, !764, !766, !768, !783, !785, !787, !789, !791, !793, !795, !797, !799, !801, !803, !805, !807, !809}
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "one", scope: !27, file: !3, line: 895, type: !52, isLocal: true, isDefinition: true)
!27 = distinct !DISubprogram(name: "pts_ieee754_acos", scope: !3, file: !3, line: 893, type: !4, scopeLine: 893, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !28)
!28 = !{!29, !30, !31, !32, !33, !34, !35, !36, !37, !38, !39, !40, !42, !45, !47}
!29 = !DILocalVariable(name: "x", arg: 1, scope: !27, file: !3, line: 893, type: !6)
!30 = !DILocalVariable(name: "z", scope: !27, file: !3, line: 910, type: !6)
!31 = !DILocalVariable(name: "p", scope: !27, file: !3, line: 910, type: !6)
!32 = !DILocalVariable(name: "q", scope: !27, file: !3, line: 910, type: !6)
!33 = !DILocalVariable(name: "r", scope: !27, file: !3, line: 910, type: !6)
!34 = !DILocalVariable(name: "w", scope: !27, file: !3, line: 910, type: !6)
!35 = !DILocalVariable(name: "s", scope: !27, file: !3, line: 910, type: !6)
!36 = !DILocalVariable(name: "c", scope: !27, file: !3, line: 910, type: !6)
!37 = !DILocalVariable(name: "df", scope: !27, file: !3, line: 910, type: !6)
!38 = !DILocalVariable(name: "hx", scope: !27, file: !3, line: 911, type: !21)
!39 = !DILocalVariable(name: "ix", scope: !27, file: !3, line: 911, type: !21)
!40 = !DILocalVariable(name: "bits", scope: !41, file: !3, line: 912, type: !18)
!41 = distinct !DILexicalBlock(scope: !27, file: !3, line: 912, column: 3)
!42 = !DILocalVariable(name: "lx", scope: !43, file: !3, line: 915, type: !9)
!43 = distinct !DILexicalBlock(scope: !44, file: !3, line: 914, column: 25)
!44 = distinct !DILexicalBlock(scope: !27, file: !3, line: 914, column: 7)
!45 = !DILocalVariable(name: "bits", scope: !46, file: !3, line: 916, type: !18)
!46 = distinct !DILexicalBlock(scope: !43, file: !3, line: 916, column: 5)
!47 = !DILocalVariable(name: "bits", scope: !48, file: !3, line: 944, type: !18)
!48 = distinct !DILexicalBlock(scope: !49, file: !3, line: 944, column: 5)
!49 = distinct !DILexicalBlock(scope: !50, file: !3, line: 940, column: 10)
!50 = distinct !DILexicalBlock(scope: !51, file: !3, line: 932, column: 14)
!51 = distinct !DILexicalBlock(scope: !27, file: !3, line: 925, column: 7)
!52 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!53 = !DIGlobalVariableExpression(var: !54, expr: !DIExpression())
!54 = distinct !DIGlobalVariable(name: "pi", scope: !27, file: !3, line: 896, type: !52, isLocal: true, isDefinition: true)
!55 = !DIGlobalVariableExpression(var: !56, expr: !DIExpression())
!56 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !27, file: !3, line: 897, type: !52, isLocal: true, isDefinition: true)
!57 = !DIGlobalVariableExpression(var: !58, expr: !DIExpression())
!58 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !27, file: !3, line: 898, type: !52, isLocal: true, isDefinition: true)
!59 = !DIGlobalVariableExpression(var: !60, expr: !DIExpression())
!60 = distinct !DIGlobalVariable(name: "pS0", scope: !27, file: !3, line: 899, type: !52, isLocal: true, isDefinition: true)
!61 = !DIGlobalVariableExpression(var: !62, expr: !DIExpression())
!62 = distinct !DIGlobalVariable(name: "pS1", scope: !27, file: !3, line: 900, type: !52, isLocal: true, isDefinition: true)
!63 = !DIGlobalVariableExpression(var: !64, expr: !DIExpression())
!64 = distinct !DIGlobalVariable(name: "pS2", scope: !27, file: !3, line: 901, type: !52, isLocal: true, isDefinition: true)
!65 = !DIGlobalVariableExpression(var: !66, expr: !DIExpression())
!66 = distinct !DIGlobalVariable(name: "pS3", scope: !27, file: !3, line: 902, type: !52, isLocal: true, isDefinition: true)
!67 = !DIGlobalVariableExpression(var: !68, expr: !DIExpression())
!68 = distinct !DIGlobalVariable(name: "pS4", scope: !27, file: !3, line: 903, type: !52, isLocal: true, isDefinition: true)
!69 = !DIGlobalVariableExpression(var: !70, expr: !DIExpression())
!70 = distinct !DIGlobalVariable(name: "pS5", scope: !27, file: !3, line: 904, type: !52, isLocal: true, isDefinition: true)
!71 = !DIGlobalVariableExpression(var: !72, expr: !DIExpression())
!72 = distinct !DIGlobalVariable(name: "qS1", scope: !27, file: !3, line: 905, type: !52, isLocal: true, isDefinition: true)
!73 = !DIGlobalVariableExpression(var: !74, expr: !DIExpression())
!74 = distinct !DIGlobalVariable(name: "qS2", scope: !27, file: !3, line: 906, type: !52, isLocal: true, isDefinition: true)
!75 = !DIGlobalVariableExpression(var: !76, expr: !DIExpression())
!76 = distinct !DIGlobalVariable(name: "qS3", scope: !27, file: !3, line: 907, type: !52, isLocal: true, isDefinition: true)
!77 = !DIGlobalVariableExpression(var: !78, expr: !DIExpression())
!78 = distinct !DIGlobalVariable(name: "qS4", scope: !27, file: !3, line: 908, type: !52, isLocal: true, isDefinition: true)
!79 = !DIGlobalVariableExpression(var: !80, expr: !DIExpression())
!80 = distinct !DIGlobalVariable(name: "one", scope: !81, file: !3, line: 969, type: !52, isLocal: true, isDefinition: true)
!81 = distinct !DISubprogram(name: "pts_ieee754_acosh", scope: !3, file: !3, line: 967, type: !4, scopeLine: 967, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !82)
!82 = !{!83, !84, !85, !86, !87}
!83 = !DILocalVariable(name: "x", arg: 1, scope: !81, file: !3, line: 967, type: !6)
!84 = !DILocalVariable(name: "t", scope: !81, file: !3, line: 971, type: !6)
!85 = !DILocalVariable(name: "hx", scope: !81, file: !3, line: 972, type: !21)
!86 = !DILocalVariable(name: "lx", scope: !81, file: !3, line: 973, type: !9)
!87 = !DILocalVariable(name: "bits", scope: !88, file: !3, line: 974, type: !18)
!88 = distinct !DILexicalBlock(scope: !81, file: !3, line: 974, column: 3)
!89 = !DIGlobalVariableExpression(var: !90, expr: !DIExpression())
!90 = distinct !DIGlobalVariable(name: "ln2", scope: !81, file: !3, line: 970, type: !52, isLocal: true, isDefinition: true)
!91 = !DIGlobalVariableExpression(var: !92, expr: !DIExpression())
!92 = distinct !DIGlobalVariable(name: "one", scope: !93, file: !3, line: 1024, type: !52, isLocal: true, isDefinition: true)
!93 = distinct !DISubprogram(name: "pts_ieee754_asin", scope: !3, file: !3, line: 1022, type: !4, scopeLine: 1022, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !94)
!94 = !{!95, !96, !97, !98, !99, !100, !101, !102, !103, !104, !105, !107, !110, !112}
!95 = !DILocalVariable(name: "x", arg: 1, scope: !93, file: !3, line: 1022, type: !6)
!96 = !DILocalVariable(name: "t", scope: !93, file: !3, line: 1041, type: !6)
!97 = !DILocalVariable(name: "w", scope: !93, file: !3, line: 1041, type: !6)
!98 = !DILocalVariable(name: "p", scope: !93, file: !3, line: 1041, type: !6)
!99 = !DILocalVariable(name: "q", scope: !93, file: !3, line: 1041, type: !6)
!100 = !DILocalVariable(name: "c", scope: !93, file: !3, line: 1041, type: !6)
!101 = !DILocalVariable(name: "r", scope: !93, file: !3, line: 1041, type: !6)
!102 = !DILocalVariable(name: "s", scope: !93, file: !3, line: 1041, type: !6)
!103 = !DILocalVariable(name: "hx", scope: !93, file: !3, line: 1042, type: !21)
!104 = !DILocalVariable(name: "ix", scope: !93, file: !3, line: 1042, type: !21)
!105 = !DILocalVariable(name: "bits", scope: !106, file: !3, line: 1045, type: !18)
!106 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1045, column: 3)
!107 = !DILocalVariable(name: "lx", scope: !108, file: !3, line: 1048, type: !9)
!108 = distinct !DILexicalBlock(scope: !109, file: !3, line: 1047, column: 25)
!109 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1047, column: 7)
!110 = !DILocalVariable(name: "bits", scope: !111, file: !3, line: 1049, type: !18)
!111 = distinct !DILexicalBlock(scope: !108, file: !3, line: 1049, column: 5)
!112 = !DILocalVariable(name: "bits", scope: !113, file: !3, line: 1076, type: !18)
!113 = distinct !DILexicalBlock(scope: !114, file: !3, line: 1076, column: 5)
!114 = distinct !DILexicalBlock(scope: !115, file: !3, line: 1074, column: 10)
!115 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1071, column: 7)
!116 = !DIGlobalVariableExpression(var: !117, expr: !DIExpression())
!117 = distinct !DIGlobalVariable(name: "huge", scope: !93, file: !3, line: 1025, type: !52, isLocal: true, isDefinition: true)
!118 = !DIGlobalVariableExpression(var: !119, expr: !DIExpression())
!119 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !93, file: !3, line: 1026, type: !52, isLocal: true, isDefinition: true)
!120 = !DIGlobalVariableExpression(var: !121, expr: !DIExpression())
!121 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !93, file: !3, line: 1027, type: !52, isLocal: true, isDefinition: true)
!122 = !DIGlobalVariableExpression(var: !123, expr: !DIExpression())
!123 = distinct !DIGlobalVariable(name: "pio4_hi", scope: !93, file: !3, line: 1028, type: !52, isLocal: true, isDefinition: true)
!124 = !DIGlobalVariableExpression(var: !125, expr: !DIExpression())
!125 = distinct !DIGlobalVariable(name: "pS0", scope: !93, file: !3, line: 1030, type: !52, isLocal: true, isDefinition: true)
!126 = !DIGlobalVariableExpression(var: !127, expr: !DIExpression())
!127 = distinct !DIGlobalVariable(name: "pS1", scope: !93, file: !3, line: 1031, type: !52, isLocal: true, isDefinition: true)
!128 = !DIGlobalVariableExpression(var: !129, expr: !DIExpression())
!129 = distinct !DIGlobalVariable(name: "pS2", scope: !93, file: !3, line: 1032, type: !52, isLocal: true, isDefinition: true)
!130 = !DIGlobalVariableExpression(var: !131, expr: !DIExpression())
!131 = distinct !DIGlobalVariable(name: "pS3", scope: !93, file: !3, line: 1033, type: !52, isLocal: true, isDefinition: true)
!132 = !DIGlobalVariableExpression(var: !133, expr: !DIExpression())
!133 = distinct !DIGlobalVariable(name: "pS4", scope: !93, file: !3, line: 1034, type: !52, isLocal: true, isDefinition: true)
!134 = !DIGlobalVariableExpression(var: !135, expr: !DIExpression())
!135 = distinct !DIGlobalVariable(name: "pS5", scope: !93, file: !3, line: 1035, type: !52, isLocal: true, isDefinition: true)
!136 = !DIGlobalVariableExpression(var: !137, expr: !DIExpression())
!137 = distinct !DIGlobalVariable(name: "qS1", scope: !93, file: !3, line: 1036, type: !52, isLocal: true, isDefinition: true)
!138 = !DIGlobalVariableExpression(var: !139, expr: !DIExpression())
!139 = distinct !DIGlobalVariable(name: "qS2", scope: !93, file: !3, line: 1037, type: !52, isLocal: true, isDefinition: true)
!140 = !DIGlobalVariableExpression(var: !141, expr: !DIExpression())
!141 = distinct !DIGlobalVariable(name: "qS3", scope: !93, file: !3, line: 1038, type: !52, isLocal: true, isDefinition: true)
!142 = !DIGlobalVariableExpression(var: !143, expr: !DIExpression())
!143 = distinct !DIGlobalVariable(name: "qS4", scope: !93, file: !3, line: 1039, type: !52, isLocal: true, isDefinition: true)
!144 = !DIGlobalVariableExpression(var: !145, expr: !DIExpression())
!145 = distinct !DIGlobalVariable(name: "one", scope: !146, file: !3, line: 1100, type: !52, isLocal: true, isDefinition: true)
!146 = distinct !DISubprogram(name: "pts_ieee754_asinh", scope: !3, file: !3, line: 1098, type: !4, scopeLine: 1098, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !147)
!147 = !{!148, !149, !150, !151, !152, !153}
!148 = !DILocalVariable(name: "x", arg: 1, scope: !146, file: !3, line: 1098, type: !6)
!149 = !DILocalVariable(name: "t", scope: !146, file: !3, line: 1104, type: !6)
!150 = !DILocalVariable(name: "w", scope: !146, file: !3, line: 1104, type: !6)
!151 = !DILocalVariable(name: "hx", scope: !146, file: !3, line: 1105, type: !21)
!152 = !DILocalVariable(name: "ix", scope: !146, file: !3, line: 1105, type: !21)
!153 = !DILocalVariable(name: "bits", scope: !154, file: !3, line: 1106, type: !18)
!154 = distinct !DILexicalBlock(scope: !146, file: !3, line: 1106, column: 3)
!155 = !DIGlobalVariableExpression(var: !156, expr: !DIExpression())
!156 = distinct !DIGlobalVariable(name: "ln2", scope: !146, file: !3, line: 1101, type: !52, isLocal: true, isDefinition: true)
!157 = !DIGlobalVariableExpression(var: !158, expr: !DIExpression())
!158 = distinct !DIGlobalVariable(name: "huge", scope: !146, file: !3, line: 1102, type: !52, isLocal: true, isDefinition: true)
!159 = !DIGlobalVariableExpression(var: !160, expr: !DIExpression())
!160 = distinct !DIGlobalVariable(name: "atanlo", scope: !2, file: !3, line: 1155, type: !161, isLocal: true, isDefinition: true)
!161 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 256, elements: !162)
!162 = !{!163}
!163 = !DISubrange(count: 4)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(name: "aT", scope: !2, file: !3, line: 1162, type: !166, isLocal: true, isDefinition: true)
!166 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 704, elements: !167)
!167 = !{!168}
!168 = !DISubrange(count: 11)
!169 = !DIGlobalVariableExpression(var: !170, expr: !DIExpression())
!170 = distinct !DIGlobalVariable(name: "one", scope: !2, file: !3, line: 1176, type: !52, isLocal: true, isDefinition: true)
!171 = !DIGlobalVariableExpression(var: !172, expr: !DIExpression())
!172 = distinct !DIGlobalVariable(name: "huge", scope: !2, file: !3, line: 1176, type: !52, isLocal: true, isDefinition: true)
!173 = !DIGlobalVariableExpression(var: !174, expr: !DIExpression())
!174 = distinct !DIGlobalVariable(name: "tiny", scope: !175, file: !3, line: 1260, type: !16, isLocal: true, isDefinition: true)
!175 = distinct !DISubprogram(name: "pts_ieee754_atan2", scope: !3, file: !3, line: 1259, type: !176, scopeLine: 1259, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !178)
!176 = !DISubroutineType(types: !177)
!177 = !{!6, !6, !6}
!178 = !{!179, !180, !181, !182, !183, !184, !185, !186, !187, !188, !189, !190, !192}
!179 = !DILocalVariable(name: "y", arg: 1, scope: !175, file: !3, line: 1259, type: !6)
!180 = !DILocalVariable(name: "x", arg: 2, scope: !175, file: !3, line: 1259, type: !6)
!181 = !DILocalVariable(name: "z", scope: !175, file: !3, line: 1269, type: !6)
!182 = !DILocalVariable(name: "k", scope: !175, file: !3, line: 1270, type: !21)
!183 = !DILocalVariable(name: "m", scope: !175, file: !3, line: 1270, type: !21)
!184 = !DILocalVariable(name: "hx", scope: !175, file: !3, line: 1270, type: !21)
!185 = !DILocalVariable(name: "hy", scope: !175, file: !3, line: 1270, type: !21)
!186 = !DILocalVariable(name: "ix", scope: !175, file: !3, line: 1270, type: !21)
!187 = !DILocalVariable(name: "iy", scope: !175, file: !3, line: 1270, type: !21)
!188 = !DILocalVariable(name: "lx", scope: !175, file: !3, line: 1271, type: !9)
!189 = !DILocalVariable(name: "ly", scope: !175, file: !3, line: 1271, type: !9)
!190 = !DILocalVariable(name: "bits", scope: !191, file: !3, line: 1273, type: !18)
!191 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1273, column: 3)
!192 = !DILocalVariable(name: "bits", scope: !193, file: !3, line: 1275, type: !18)
!193 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1275, column: 3)
!194 = !DIGlobalVariableExpression(var: !195, expr: !DIExpression())
!195 = distinct !DIGlobalVariable(name: "zero", scope: !175, file: !3, line: 1262, type: !52, isLocal: true, isDefinition: true)
!196 = !DIGlobalVariableExpression(var: !197, expr: !DIExpression())
!197 = distinct !DIGlobalVariable(name: "pi_o_4", scope: !175, file: !3, line: 1263, type: !52, isLocal: true, isDefinition: true)
!198 = !DIGlobalVariableExpression(var: !199, expr: !DIExpression())
!199 = distinct !DIGlobalVariable(name: "pi_o_2", scope: !175, file: !3, line: 1264, type: !52, isLocal: true, isDefinition: true)
!200 = !DIGlobalVariableExpression(var: !201, expr: !DIExpression())
!201 = distinct !DIGlobalVariable(name: "pi", scope: !175, file: !3, line: 1265, type: !52, isLocal: true, isDefinition: true)
!202 = !DIGlobalVariableExpression(var: !203, expr: !DIExpression())
!203 = distinct !DIGlobalVariable(name: "pi_lo", scope: !175, file: !3, line: 1266, type: !16, isLocal: true, isDefinition: true)
!204 = !DIGlobalVariableExpression(var: !205, expr: !DIExpression())
!205 = distinct !DIGlobalVariable(name: "one", scope: !206, file: !3, line: 1476, type: !52, isLocal: true, isDefinition: true)
!206 = distinct !DISubprogram(name: "pts_ieee754_exp", scope: !3, file: !3, line: 1474, type: !4, scopeLine: 1474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !207)
!207 = !{!208, !209, !210, !211, !212, !213, !214, !215, !216, !217, !218, !220, !225, !227, !231}
!208 = !DILocalVariable(name: "x", arg: 1, scope: !206, file: !3, line: 1474, type: !6)
!209 = !DILocalVariable(name: "y", scope: !206, file: !3, line: 1497, type: !6)
!210 = !DILocalVariable(name: "hi", scope: !206, file: !3, line: 1497, type: !6)
!211 = !DILocalVariable(name: "lo", scope: !206, file: !3, line: 1497, type: !6)
!212 = !DILocalVariable(name: "c", scope: !206, file: !3, line: 1497, type: !6)
!213 = !DILocalVariable(name: "t", scope: !206, file: !3, line: 1497, type: !6)
!214 = !DILocalVariable(name: "twopk", scope: !206, file: !3, line: 1497, type: !6)
!215 = !DILocalVariable(name: "k", scope: !206, file: !3, line: 1498, type: !21)
!216 = !DILocalVariable(name: "xsb", scope: !206, file: !3, line: 1498, type: !21)
!217 = !DILocalVariable(name: "hx", scope: !206, file: !3, line: 1499, type: !9)
!218 = !DILocalVariable(name: "bits", scope: !219, file: !3, line: 1501, type: !18)
!219 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1501, column: 3)
!220 = !DILocalVariable(name: "lx", scope: !221, file: !3, line: 1508, type: !9)
!221 = distinct !DILexicalBlock(scope: !222, file: !3, line: 1507, column: 27)
!222 = distinct !DILexicalBlock(scope: !223, file: !3, line: 1507, column: 9)
!223 = distinct !DILexicalBlock(scope: !224, file: !3, line: 1506, column: 25)
!224 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1506, column: 7)
!225 = !DILocalVariable(name: "bits", scope: !226, file: !3, line: 1509, type: !18)
!226 = distinct !DILexicalBlock(scope: !221, file: !3, line: 1509, column: 7)
!227 = !DILocalVariable(name: "bits", scope: !228, file: !3, line: 1546, type: !18)
!228 = distinct !DILexicalBlock(scope: !229, file: !3, line: 1546, column: 5)
!229 = distinct !DILexicalBlock(scope: !230, file: !3, line: 1545, column: 19)
!230 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1545, column: 7)
!231 = !DILocalVariable(name: "bits", scope: !232, file: !3, line: 1550, type: !18)
!232 = distinct !DILexicalBlock(scope: !233, file: !3, line: 1550, column: 5)
!233 = distinct !DILexicalBlock(scope: !230, file: !3, line: 1549, column: 10)
!234 = !DIGlobalVariableExpression(var: !235, expr: !DIExpression())
!235 = distinct !DIGlobalVariable(name: "halF", scope: !206, file: !3, line: 1477, type: !236, isLocal: true, isDefinition: true)
!236 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 128, elements: !237)
!237 = !{!238}
!238 = !DISubrange(count: 2)
!239 = !DIGlobalVariableExpression(var: !240, expr: !DIExpression())
!240 = distinct !DIGlobalVariable(name: "o_threshold", scope: !206, file: !3, line: 1478, type: !52, isLocal: true, isDefinition: true)
!241 = !DIGlobalVariableExpression(var: !242, expr: !DIExpression())
!242 = distinct !DIGlobalVariable(name: "u_threshold", scope: !206, file: !3, line: 1479, type: !52, isLocal: true, isDefinition: true)
!243 = !DIGlobalVariableExpression(var: !244, expr: !DIExpression())
!244 = distinct !DIGlobalVariable(name: "ln2HI", scope: !206, file: !3, line: 1480, type: !236, isLocal: true, isDefinition: true)
!245 = !DIGlobalVariableExpression(var: !246, expr: !DIExpression())
!246 = distinct !DIGlobalVariable(name: "ln2LO", scope: !206, file: !3, line: 1482, type: !236, isLocal: true, isDefinition: true)
!247 = !DIGlobalVariableExpression(var: !248, expr: !DIExpression())
!248 = distinct !DIGlobalVariable(name: "invln2", scope: !206, file: !3, line: 1484, type: !52, isLocal: true, isDefinition: true)
!249 = !DIGlobalVariableExpression(var: !250, expr: !DIExpression())
!250 = distinct !DIGlobalVariable(name: "P1", scope: !206, file: !3, line: 1485, type: !52, isLocal: true, isDefinition: true)
!251 = !DIGlobalVariableExpression(var: !252, expr: !DIExpression())
!252 = distinct !DIGlobalVariable(name: "P2", scope: !206, file: !3, line: 1486, type: !52, isLocal: true, isDefinition: true)
!253 = !DIGlobalVariableExpression(var: !254, expr: !DIExpression())
!254 = distinct !DIGlobalVariable(name: "P3", scope: !206, file: !3, line: 1487, type: !52, isLocal: true, isDefinition: true)
!255 = !DIGlobalVariableExpression(var: !256, expr: !DIExpression())
!256 = distinct !DIGlobalVariable(name: "P4", scope: !206, file: !3, line: 1488, type: !52, isLocal: true, isDefinition: true)
!257 = !DIGlobalVariableExpression(var: !258, expr: !DIExpression())
!258 = distinct !DIGlobalVariable(name: "P5", scope: !206, file: !3, line: 1489, type: !52, isLocal: true, isDefinition: true)
!259 = !DIGlobalVariableExpression(var: !260, expr: !DIExpression())
!260 = distinct !DIGlobalVariable(name: "E", scope: !206, file: !3, line: 1490, type: !52, isLocal: true, isDefinition: true)
!261 = !DIGlobalVariableExpression(var: !262, expr: !DIExpression())
!262 = distinct !DIGlobalVariable(name: "huge", scope: !206, file: !3, line: 1493, type: !16, isLocal: true, isDefinition: true)
!263 = !DIGlobalVariableExpression(var: !264, expr: !DIExpression())
!264 = distinct !DIGlobalVariable(name: "twom1000", scope: !206, file: !3, line: 1494, type: !16, isLocal: true, isDefinition: true)
!265 = !DIGlobalVariableExpression(var: !266, expr: !DIExpression())
!266 = distinct !DIGlobalVariable(name: "two1023", scope: !206, file: !3, line: 1495, type: !16, isLocal: true, isDefinition: true)
!267 = !DIGlobalVariableExpression(var: !268, expr: !DIExpression())
!268 = distinct !DIGlobalVariable(name: "one", scope: !269, file: !3, line: 1585, type: !52, isLocal: true, isDefinition: true)
!269 = distinct !DISubprogram(name: "pts_ieee754_atanh", scope: !3, file: !3, line: 1584, type: !4, scopeLine: 1584, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !270)
!270 = !{!271, !272, !273, !274, !275, !276, !278}
!271 = !DILocalVariable(name: "x", arg: 1, scope: !269, file: !3, line: 1584, type: !6)
!272 = !DILocalVariable(name: "t", scope: !269, file: !3, line: 1588, type: !6)
!273 = !DILocalVariable(name: "hx", scope: !269, file: !3, line: 1589, type: !21)
!274 = !DILocalVariable(name: "ix", scope: !269, file: !3, line: 1589, type: !21)
!275 = !DILocalVariable(name: "lx", scope: !269, file: !3, line: 1590, type: !9)
!276 = !DILocalVariable(name: "bits", scope: !277, file: !3, line: 1591, type: !18)
!277 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1591, column: 3)
!278 = !DILocalVariable(name: "bits", scope: !279, file: !3, line: 1602, type: !18)
!279 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1602, column: 3)
!280 = !DIGlobalVariableExpression(var: !281, expr: !DIExpression())
!281 = distinct !DIGlobalVariable(name: "huge", scope: !269, file: !3, line: 1585, type: !52, isLocal: true, isDefinition: true)
!282 = !DIGlobalVariableExpression(var: !283, expr: !DIExpression())
!283 = distinct !DIGlobalVariable(name: "zero", scope: !269, file: !3, line: 1586, type: !52, isLocal: true, isDefinition: true)
!284 = !DIGlobalVariableExpression(var: !285, expr: !DIExpression())
!285 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !286, file: !3, line: 1667, type: !52, isLocal: true, isDefinition: true)
!286 = distinct !DISubprogram(name: "pts_ieee754_log", scope: !3, file: !3, line: 1665, type: !4, scopeLine: 1665, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !287)
!287 = !{!288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !298, !299, !300, !301, !302, !303, !305, !309}
!288 = !DILocalVariable(name: "x", arg: 1, scope: !286, file: !3, line: 1665, type: !6)
!289 = !DILocalVariable(name: "hfsq", scope: !286, file: !3, line: 1680, type: !6)
!290 = !DILocalVariable(name: "f", scope: !286, file: !3, line: 1680, type: !6)
!291 = !DILocalVariable(name: "s", scope: !286, file: !3, line: 1680, type: !6)
!292 = !DILocalVariable(name: "z", scope: !286, file: !3, line: 1680, type: !6)
!293 = !DILocalVariable(name: "R", scope: !286, file: !3, line: 1680, type: !6)
!294 = !DILocalVariable(name: "w", scope: !286, file: !3, line: 1680, type: !6)
!295 = !DILocalVariable(name: "t1", scope: !286, file: !3, line: 1680, type: !6)
!296 = !DILocalVariable(name: "t2", scope: !286, file: !3, line: 1680, type: !6)
!297 = !DILocalVariable(name: "dk", scope: !286, file: !3, line: 1680, type: !6)
!298 = !DILocalVariable(name: "k", scope: !286, file: !3, line: 1681, type: !21)
!299 = !DILocalVariable(name: "hx", scope: !286, file: !3, line: 1681, type: !21)
!300 = !DILocalVariable(name: "i", scope: !286, file: !3, line: 1681, type: !21)
!301 = !DILocalVariable(name: "j", scope: !286, file: !3, line: 1681, type: !21)
!302 = !DILocalVariable(name: "lx", scope: !286, file: !3, line: 1682, type: !9)
!303 = !DILocalVariable(name: "bits", scope: !304, file: !3, line: 1684, type: !18)
!304 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1684, column: 3)
!305 = !DILocalVariable(name: "bits", scope: !306, file: !3, line: 1696, type: !18)
!306 = distinct !DILexicalBlock(scope: !307, file: !3, line: 1696, column: 5)
!307 = distinct !DILexicalBlock(scope: !308, file: !3, line: 1687, column: 24)
!308 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1687, column: 7)
!309 = !DILocalVariable(name: "bits", scope: !310, file: !3, line: 1702, type: !18)
!310 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1702, column: 3)
!311 = !DIGlobalVariableExpression(var: !312, expr: !DIExpression())
!312 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !286, file: !3, line: 1668, type: !52, isLocal: true, isDefinition: true)
!313 = !DIGlobalVariableExpression(var: !314, expr: !DIExpression())
!314 = distinct !DIGlobalVariable(name: "two54", scope: !286, file: !3, line: 1669, type: !52, isLocal: true, isDefinition: true)
!315 = !DIGlobalVariableExpression(var: !316, expr: !DIExpression())
!316 = distinct !DIGlobalVariable(name: "Lg1", scope: !286, file: !3, line: 1670, type: !52, isLocal: true, isDefinition: true)
!317 = !DIGlobalVariableExpression(var: !318, expr: !DIExpression())
!318 = distinct !DIGlobalVariable(name: "Lg2", scope: !286, file: !3, line: 1671, type: !52, isLocal: true, isDefinition: true)
!319 = !DIGlobalVariableExpression(var: !320, expr: !DIExpression())
!320 = distinct !DIGlobalVariable(name: "Lg3", scope: !286, file: !3, line: 1672, type: !52, isLocal: true, isDefinition: true)
!321 = !DIGlobalVariableExpression(var: !322, expr: !DIExpression())
!322 = distinct !DIGlobalVariable(name: "Lg4", scope: !286, file: !3, line: 1673, type: !52, isLocal: true, isDefinition: true)
!323 = !DIGlobalVariableExpression(var: !324, expr: !DIExpression())
!324 = distinct !DIGlobalVariable(name: "Lg5", scope: !286, file: !3, line: 1674, type: !52, isLocal: true, isDefinition: true)
!325 = !DIGlobalVariableExpression(var: !326, expr: !DIExpression())
!326 = distinct !DIGlobalVariable(name: "Lg6", scope: !286, file: !3, line: 1675, type: !52, isLocal: true, isDefinition: true)
!327 = !DIGlobalVariableExpression(var: !328, expr: !DIExpression())
!328 = distinct !DIGlobalVariable(name: "Lg7", scope: !286, file: !3, line: 1676, type: !52, isLocal: true, isDefinition: true)
!329 = !DIGlobalVariableExpression(var: !330, expr: !DIExpression())
!330 = distinct !DIGlobalVariable(name: "zero", scope: !286, file: !3, line: 1678, type: !52, isLocal: true, isDefinition: true)
!331 = !DIGlobalVariableExpression(var: !332, expr: !DIExpression())
!332 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !333, file: !3, line: 1812, type: !52, isLocal: true, isDefinition: true)
!333 = distinct !DISubprogram(name: "pts_ieee754_log1p", scope: !3, file: !3, line: 1810, type: !4, scopeLine: 1810, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !334)
!334 = !{!335, !336, !337, !338, !339, !340, !341, !342, !343, !344, !345, !346, !347, !349, !355, !358, !362}
!335 = !DILocalVariable(name: "x", arg: 1, scope: !333, file: !3, line: 1810, type: !6)
!336 = !DILocalVariable(name: "hfsq", scope: !333, file: !3, line: 1825, type: !6)
!337 = !DILocalVariable(name: "f", scope: !333, file: !3, line: 1825, type: !6)
!338 = !DILocalVariable(name: "c", scope: !333, file: !3, line: 1825, type: !6)
!339 = !DILocalVariable(name: "s", scope: !333, file: !3, line: 1825, type: !6)
!340 = !DILocalVariable(name: "z", scope: !333, file: !3, line: 1825, type: !6)
!341 = !DILocalVariable(name: "R", scope: !333, file: !3, line: 1825, type: !6)
!342 = !DILocalVariable(name: "u", scope: !333, file: !3, line: 1825, type: !6)
!343 = !DILocalVariable(name: "k", scope: !333, file: !3, line: 1826, type: !21)
!344 = !DILocalVariable(name: "hx", scope: !333, file: !3, line: 1826, type: !21)
!345 = !DILocalVariable(name: "hu", scope: !333, file: !3, line: 1826, type: !21)
!346 = !DILocalVariable(name: "ax", scope: !333, file: !3, line: 1826, type: !21)
!347 = !DILocalVariable(name: "bits", scope: !348, file: !3, line: 1828, type: !18)
!348 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1828, column: 3)
!349 = !DILocalVariable(name: "bits", scope: !350, file: !3, line: 1856, type: !18)
!350 = distinct !DILexicalBlock(scope: !351, file: !3, line: 1856, column: 7)
!351 = distinct !DILexicalBlock(scope: !352, file: !3, line: 1854, column: 26)
!352 = distinct !DILexicalBlock(scope: !353, file: !3, line: 1854, column: 9)
!353 = distinct !DILexicalBlock(scope: !354, file: !3, line: 1853, column: 15)
!354 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1853, column: 7)
!355 = !DILocalVariable(name: "bits", scope: !356, file: !3, line: 1862, type: !18)
!356 = distinct !DILexicalBlock(scope: !357, file: !3, line: 1862, column: 7)
!357 = distinct !DILexicalBlock(scope: !352, file: !3, line: 1860, column: 12)
!358 = !DILocalVariable(name: "bits", scope: !359, file: !3, line: 1875, type: !18)
!359 = distinct !DILexicalBlock(scope: !360, file: !3, line: 1875, column: 7)
!360 = distinct !DILexicalBlock(scope: !361, file: !3, line: 1874, column: 23)
!361 = distinct !DILexicalBlock(scope: !353, file: !3, line: 1874, column: 9)
!362 = !DILocalVariable(name: "bits", scope: !363, file: !3, line: 1878, type: !18)
!363 = distinct !DILexicalBlock(scope: !364, file: !3, line: 1878, column: 7)
!364 = distinct !DILexicalBlock(scope: !361, file: !3, line: 1876, column: 12)
!365 = !DIGlobalVariableExpression(var: !366, expr: !DIExpression())
!366 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !333, file: !3, line: 1813, type: !52, isLocal: true, isDefinition: true)
!367 = !DIGlobalVariableExpression(var: !368, expr: !DIExpression())
!368 = distinct !DIGlobalVariable(name: "two54", scope: !333, file: !3, line: 1814, type: !52, isLocal: true, isDefinition: true)
!369 = !DIGlobalVariableExpression(var: !370, expr: !DIExpression())
!370 = distinct !DIGlobalVariable(name: "Lp1", scope: !333, file: !3, line: 1815, type: !52, isLocal: true, isDefinition: true)
!371 = !DIGlobalVariableExpression(var: !372, expr: !DIExpression())
!372 = distinct !DIGlobalVariable(name: "Lp2", scope: !333, file: !3, line: 1816, type: !52, isLocal: true, isDefinition: true)
!373 = !DIGlobalVariableExpression(var: !374, expr: !DIExpression())
!374 = distinct !DIGlobalVariable(name: "Lp3", scope: !333, file: !3, line: 1817, type: !52, isLocal: true, isDefinition: true)
!375 = !DIGlobalVariableExpression(var: !376, expr: !DIExpression())
!376 = distinct !DIGlobalVariable(name: "Lp4", scope: !333, file: !3, line: 1818, type: !52, isLocal: true, isDefinition: true)
!377 = !DIGlobalVariableExpression(var: !378, expr: !DIExpression())
!378 = distinct !DIGlobalVariable(name: "Lp5", scope: !333, file: !3, line: 1819, type: !52, isLocal: true, isDefinition: true)
!379 = !DIGlobalVariableExpression(var: !380, expr: !DIExpression())
!380 = distinct !DIGlobalVariable(name: "Lp6", scope: !333, file: !3, line: 1820, type: !52, isLocal: true, isDefinition: true)
!381 = !DIGlobalVariableExpression(var: !382, expr: !DIExpression())
!382 = distinct !DIGlobalVariable(name: "Lp7", scope: !333, file: !3, line: 1821, type: !52, isLocal: true, isDefinition: true)
!383 = !DIGlobalVariableExpression(var: !384, expr: !DIExpression())
!384 = distinct !DIGlobalVariable(name: "zero", scope: !333, file: !3, line: 1823, type: !52, isLocal: true, isDefinition: true)
!385 = !DIGlobalVariableExpression(var: !386, expr: !DIExpression())
!386 = distinct !DIGlobalVariable(name: "two54", scope: !387, file: !3, line: 2002, type: !52, isLocal: true, isDefinition: true)
!387 = distinct !DISubprogram(name: "pts_ieee754_log2", scope: !3, file: !3, line: 2000, type: !4, scopeLine: 2000, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !388)
!388 = !{!389, !390, !391, !392, !393, !394, !395, !396, !397, !398, !399, !400, !401, !402, !403, !405, !409, !411}
!389 = !DILocalVariable(name: "x", arg: 1, scope: !387, file: !3, line: 2000, type: !6)
!390 = !DILocalVariable(name: "f", scope: !387, file: !3, line: 2006, type: !6)
!391 = !DILocalVariable(name: "hfsq", scope: !387, file: !3, line: 2006, type: !6)
!392 = !DILocalVariable(name: "hi", scope: !387, file: !3, line: 2006, type: !6)
!393 = !DILocalVariable(name: "lo", scope: !387, file: !3, line: 2006, type: !6)
!394 = !DILocalVariable(name: "r", scope: !387, file: !3, line: 2006, type: !6)
!395 = !DILocalVariable(name: "val_hi", scope: !387, file: !3, line: 2006, type: !6)
!396 = !DILocalVariable(name: "val_lo", scope: !387, file: !3, line: 2006, type: !6)
!397 = !DILocalVariable(name: "w", scope: !387, file: !3, line: 2006, type: !6)
!398 = !DILocalVariable(name: "y", scope: !387, file: !3, line: 2006, type: !6)
!399 = !DILocalVariable(name: "i", scope: !387, file: !3, line: 2007, type: !21)
!400 = !DILocalVariable(name: "k", scope: !387, file: !3, line: 2007, type: !21)
!401 = !DILocalVariable(name: "hx", scope: !387, file: !3, line: 2007, type: !21)
!402 = !DILocalVariable(name: "lx", scope: !387, file: !3, line: 2008, type: !9)
!403 = !DILocalVariable(name: "bits", scope: !404, file: !3, line: 2010, type: !18)
!404 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2010, column: 3)
!405 = !DILocalVariable(name: "bits", scope: !406, file: !3, line: 2022, type: !18)
!406 = distinct !DILexicalBlock(scope: !407, file: !3, line: 2022, column: 5)
!407 = distinct !DILexicalBlock(scope: !408, file: !3, line: 2013, column: 24)
!408 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2013, column: 7)
!409 = !DILocalVariable(name: "bits", scope: !410, file: !3, line: 2029, type: !18)
!410 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2029, column: 3)
!411 = !DILocalVariable(name: "bits", scope: !412, file: !3, line: 2067, type: !18)
!412 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2067, column: 3)
!413 = !DIGlobalVariableExpression(var: !414, expr: !DIExpression())
!414 = distinct !DIGlobalVariable(name: "ivln2hi", scope: !387, file: !3, line: 2003, type: !52, isLocal: true, isDefinition: true)
!415 = !DIGlobalVariableExpression(var: !416, expr: !DIExpression())
!416 = distinct !DIGlobalVariable(name: "ivln2lo", scope: !387, file: !3, line: 2004, type: !52, isLocal: true, isDefinition: true)
!417 = !DIGlobalVariableExpression(var: !418, expr: !DIExpression())
!418 = distinct !DIGlobalVariable(name: "two54", scope: !419, file: !3, line: 2108, type: !52, isLocal: true, isDefinition: true)
!419 = distinct !DISubprogram(name: "pts_ieee754_log10", scope: !3, file: !3, line: 2106, type: !4, scopeLine: 2106, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !420)
!420 = !{!421, !422, !423, !424, !425, !426, !427, !429, !433, !435, !437, !439}
!421 = !DILocalVariable(name: "x", arg: 1, scope: !419, file: !3, line: 2106, type: !6)
!422 = !DILocalVariable(name: "y", scope: !419, file: !3, line: 2113, type: !6)
!423 = !DILocalVariable(name: "i", scope: !419, file: !3, line: 2114, type: !21)
!424 = !DILocalVariable(name: "k", scope: !419, file: !3, line: 2114, type: !21)
!425 = !DILocalVariable(name: "hx", scope: !419, file: !3, line: 2114, type: !21)
!426 = !DILocalVariable(name: "lx", scope: !419, file: !3, line: 2115, type: !9)
!427 = !DILocalVariable(name: "bits", scope: !428, file: !3, line: 2117, type: !18)
!428 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2117, column: 3)
!429 = !DILocalVariable(name: "bits", scope: !430, file: !3, line: 2129, type: !18)
!430 = distinct !DILexicalBlock(scope: !431, file: !3, line: 2129, column: 5)
!431 = distinct !DILexicalBlock(scope: !432, file: !3, line: 2120, column: 24)
!432 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2120, column: 7)
!433 = !DILocalVariable(name: "bits", scope: !434, file: !3, line: 2130, type: !18)
!434 = distinct !DILexicalBlock(scope: !431, file: !3, line: 2130, column: 5)
!435 = !DILocalVariable(name: "bits", scope: !436, file: !3, line: 2139, type: !18)
!436 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2139, column: 3)
!437 = !DILocalVariable(name: "bits", scope: !438, file: !3, line: 2140, type: !18)
!438 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2140, column: 3)
!439 = !DILocalVariable(name: "z", scope: !419, file: !3, line: 2142, type: !6)
!440 = !DIGlobalVariableExpression(var: !441, expr: !DIExpression())
!441 = distinct !DIGlobalVariable(name: "ivln10", scope: !419, file: !3, line: 2109, type: !52, isLocal: true, isDefinition: true)
!442 = !DIGlobalVariableExpression(var: !443, expr: !DIExpression())
!443 = distinct !DIGlobalVariable(name: "log10_2hi", scope: !419, file: !3, line: 2110, type: !52, isLocal: true, isDefinition: true)
!444 = !DIGlobalVariableExpression(var: !445, expr: !DIExpression())
!445 = distinct !DIGlobalVariable(name: "log10_2lo", scope: !419, file: !3, line: 2111, type: !52, isLocal: true, isDefinition: true)
!446 = !DIGlobalVariableExpression(var: !447, expr: !DIExpression())
!447 = distinct !DIGlobalVariable(name: "one", scope: !448, file: !3, line: 2242, type: !52, isLocal: true, isDefinition: true)
!448 = distinct !DISubprogram(name: "pts_ieee754_expm1", scope: !3, file: !3, line: 2240, type: !4, scopeLine: 2240, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !449)
!449 = !{!450, !451, !452, !453, !454, !455, !456, !457, !458, !459, !460, !461, !462, !463, !464, !466, !473, !475, !479, !483}
!450 = !DILocalVariable(name: "x", arg: 1, scope: !448, file: !3, line: 2240, type: !6)
!451 = !DILocalVariable(name: "y", scope: !448, file: !3, line: 2258, type: !6)
!452 = !DILocalVariable(name: "hi", scope: !448, file: !3, line: 2258, type: !6)
!453 = !DILocalVariable(name: "lo", scope: !448, file: !3, line: 2258, type: !6)
!454 = !DILocalVariable(name: "c", scope: !448, file: !3, line: 2258, type: !6)
!455 = !DILocalVariable(name: "t", scope: !448, file: !3, line: 2258, type: !6)
!456 = !DILocalVariable(name: "e", scope: !448, file: !3, line: 2258, type: !6)
!457 = !DILocalVariable(name: "hxs", scope: !448, file: !3, line: 2258, type: !6)
!458 = !DILocalVariable(name: "hfx", scope: !448, file: !3, line: 2258, type: !6)
!459 = !DILocalVariable(name: "r1", scope: !448, file: !3, line: 2258, type: !6)
!460 = !DILocalVariable(name: "twopk", scope: !448, file: !3, line: 2258, type: !6)
!461 = !DILocalVariable(name: "k", scope: !448, file: !3, line: 2259, type: !21)
!462 = !DILocalVariable(name: "xsb", scope: !448, file: !3, line: 2259, type: !21)
!463 = !DILocalVariable(name: "hx", scope: !448, file: !3, line: 2260, type: !9)
!464 = !DILocalVariable(name: "bits", scope: !465, file: !3, line: 2262, type: !18)
!465 = distinct !DILexicalBlock(scope: !448, file: !3, line: 2262, column: 3)
!466 = !DILocalVariable(name: "low", scope: !467, file: !3, line: 2270, type: !9)
!467 = distinct !DILexicalBlock(scope: !468, file: !3, line: 2269, column: 29)
!468 = distinct !DILexicalBlock(scope: !469, file: !3, line: 2269, column: 11)
!469 = distinct !DILexicalBlock(scope: !470, file: !3, line: 2268, column: 27)
!470 = distinct !DILexicalBlock(scope: !471, file: !3, line: 2268, column: 9)
!471 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2267, column: 25)
!472 = distinct !DILexicalBlock(scope: !448, file: !3, line: 2267, column: 7)
!473 = !DILocalVariable(name: "bits", scope: !474, file: !3, line: 2271, type: !18)
!474 = distinct !DILexicalBlock(scope: !467, file: !3, line: 2271, column: 9)
!475 = !DILocalVariable(name: "bits", scope: !476, file: !3, line: 2321, type: !18)
!476 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2321, column: 5)
!477 = distinct !DILexicalBlock(scope: !478, file: !3, line: 2320, column: 10)
!478 = distinct !DILexicalBlock(scope: !448, file: !3, line: 2318, column: 7)
!479 = !DILocalVariable(name: "bits", scope: !480, file: !3, line: 2347, type: !18)
!480 = distinct !DILexicalBlock(scope: !481, file: !3, line: 2347, column: 7)
!481 = distinct !DILexicalBlock(scope: !482, file: !3, line: 2346, column: 17)
!482 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2346, column: 9)
!483 = !DILocalVariable(name: "bits", scope: !484, file: !3, line: 2351, type: !18)
!484 = distinct !DILexicalBlock(scope: !485, file: !3, line: 2351, column: 7)
!485 = distinct !DILexicalBlock(scope: !482, file: !3, line: 2350, column: 12)
!486 = !DIGlobalVariableExpression(var: !487, expr: !DIExpression())
!487 = distinct !DIGlobalVariable(name: "tiny", scope: !448, file: !3, line: 2243, type: !52, isLocal: true, isDefinition: true)
!488 = !DIGlobalVariableExpression(var: !489, expr: !DIExpression())
!489 = distinct !DIGlobalVariable(name: "o_threshold", scope: !448, file: !3, line: 2244, type: !52, isLocal: true, isDefinition: true)
!490 = !DIGlobalVariableExpression(var: !491, expr: !DIExpression())
!491 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !448, file: !3, line: 2245, type: !52, isLocal: true, isDefinition: true)
!492 = !DIGlobalVariableExpression(var: !493, expr: !DIExpression())
!493 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !448, file: !3, line: 2246, type: !52, isLocal: true, isDefinition: true)
!494 = !DIGlobalVariableExpression(var: !495, expr: !DIExpression())
!495 = distinct !DIGlobalVariable(name: "invln2", scope: !448, file: !3, line: 2247, type: !52, isLocal: true, isDefinition: true)
!496 = !DIGlobalVariableExpression(var: !497, expr: !DIExpression())
!497 = distinct !DIGlobalVariable(name: "Q1", scope: !448, file: !3, line: 2250, type: !52, isLocal: true, isDefinition: true)
!498 = !DIGlobalVariableExpression(var: !499, expr: !DIExpression())
!499 = distinct !DIGlobalVariable(name: "Q2", scope: !448, file: !3, line: 2251, type: !52, isLocal: true, isDefinition: true)
!500 = !DIGlobalVariableExpression(var: !501, expr: !DIExpression())
!501 = distinct !DIGlobalVariable(name: "Q3", scope: !448, file: !3, line: 2252, type: !52, isLocal: true, isDefinition: true)
!502 = !DIGlobalVariableExpression(var: !503, expr: !DIExpression())
!503 = distinct !DIGlobalVariable(name: "Q4", scope: !448, file: !3, line: 2253, type: !52, isLocal: true, isDefinition: true)
!504 = !DIGlobalVariableExpression(var: !505, expr: !DIExpression())
!505 = distinct !DIGlobalVariable(name: "Q5", scope: !448, file: !3, line: 2254, type: !52, isLocal: true, isDefinition: true)
!506 = !DIGlobalVariableExpression(var: !507, expr: !DIExpression())
!507 = distinct !DIGlobalVariable(name: "huge", scope: !448, file: !3, line: 2256, type: !16, isLocal: true, isDefinition: true)
!508 = !DIGlobalVariableExpression(var: !509, expr: !DIExpression())
!509 = distinct !DIGlobalVariable(name: "B1", scope: !510, file: !3, line: 2362, type: !535, isLocal: true, isDefinition: true)
!510 = distinct !DISubprogram(name: "pts_ieee754_cbrt", scope: !3, file: !3, line: 2360, type: !4, scopeLine: 2360, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !511)
!511 = !{!512, !513, !514, !515, !516, !517, !518, !519, !520, !521, !523, !527, !529, !531, !534}
!512 = !DILocalVariable(name: "x", arg: 1, scope: !510, file: !3, line: 2360, type: !6)
!513 = !DILocalVariable(name: "hx", scope: !510, file: !3, line: 2372, type: !21)
!514 = !DILocalVariable(name: "r", scope: !510, file: !3, line: 2373, type: !6)
!515 = !DILocalVariable(name: "s", scope: !510, file: !3, line: 2373, type: !6)
!516 = !DILocalVariable(name: "t", scope: !510, file: !3, line: 2373, type: !6)
!517 = !DILocalVariable(name: "w", scope: !510, file: !3, line: 2373, type: !6)
!518 = !DILocalVariable(name: "sign", scope: !510, file: !3, line: 2374, type: !9)
!519 = !DILocalVariable(name: "high", scope: !510, file: !3, line: 2375, type: !9)
!520 = !DILocalVariable(name: "low", scope: !510, file: !3, line: 2375, type: !9)
!521 = !DILocalVariable(name: "bits", scope: !522, file: !3, line: 2377, type: !18)
!522 = distinct !DILexicalBlock(scope: !510, file: !3, line: 2377, column: 3)
!523 = !DILocalVariable(name: "bits", scope: !524, file: !3, line: 2399, type: !18)
!524 = distinct !DILexicalBlock(scope: !525, file: !3, line: 2399, column: 5)
!525 = distinct !DILexicalBlock(scope: !526, file: !3, line: 2397, column: 24)
!526 = distinct !DILexicalBlock(scope: !510, file: !3, line: 2397, column: 7)
!527 = !DILocalVariable(name: "bits", scope: !528, file: !3, line: 2401, type: !18)
!528 = distinct !DILexicalBlock(scope: !525, file: !3, line: 2401, column: 5)
!529 = !DILocalVariable(name: "bits", scope: !530, file: !3, line: 2402, type: !18)
!530 = distinct !DILexicalBlock(scope: !525, file: !3, line: 2402, column: 5)
!531 = !DILocalVariable(name: "bits", scope: !532, file: !3, line: 2404, type: !18)
!532 = distinct !DILexicalBlock(scope: !533, file: !3, line: 2404, column: 5)
!533 = distinct !DILexicalBlock(scope: !526, file: !3, line: 2403, column: 10)
!534 = !DILocalVariable(name: "bits", scope: !510, file: !3, line: 2430, type: !18)
!535 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!536 = !DIGlobalVariableExpression(var: !537, expr: !DIExpression())
!537 = distinct !DIGlobalVariable(name: "B2", scope: !510, file: !3, line: 2363, type: !535, isLocal: true, isDefinition: true)
!538 = !DIGlobalVariableExpression(var: !539, expr: !DIExpression())
!539 = distinct !DIGlobalVariable(name: "P0", scope: !510, file: !3, line: 2366, type: !52, isLocal: true, isDefinition: true)
!540 = !DIGlobalVariableExpression(var: !541, expr: !DIExpression())
!541 = distinct !DIGlobalVariable(name: "P1", scope: !510, file: !3, line: 2367, type: !52, isLocal: true, isDefinition: true)
!542 = !DIGlobalVariableExpression(var: !543, expr: !DIExpression())
!543 = distinct !DIGlobalVariable(name: "P2", scope: !510, file: !3, line: 2368, type: !52, isLocal: true, isDefinition: true)
!544 = !DIGlobalVariableExpression(var: !545, expr: !DIExpression())
!545 = distinct !DIGlobalVariable(name: "P3", scope: !510, file: !3, line: 2369, type: !52, isLocal: true, isDefinition: true)
!546 = !DIGlobalVariableExpression(var: !547, expr: !DIExpression())
!547 = distinct !DIGlobalVariable(name: "P4", scope: !510, file: !3, line: 2370, type: !52, isLocal: true, isDefinition: true)
!548 = !DIGlobalVariableExpression(var: !549, expr: !DIExpression())
!549 = distinct !DIGlobalVariable(name: "KCOSH_OVERFLOW", scope: !550, file: !3, line: 2578, type: !52, isLocal: true, isDefinition: true)
!550 = distinct !DISubprogram(name: "pts_ieee754_cosh", scope: !3, file: !3, line: 2577, type: !4, scopeLine: 2577, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !551)
!551 = !{!552, !553, !554, !556, !559, !560, !563, !566}
!552 = !DILocalVariable(name: "x", arg: 1, scope: !550, file: !3, line: 2577, type: !6)
!553 = !DILocalVariable(name: "ix", scope: !550, file: !3, line: 2582, type: !21)
!554 = !DILocalVariable(name: "bits", scope: !555, file: !3, line: 2585, type: !18)
!555 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2585, column: 3)
!556 = !DILocalVariable(name: "t", scope: !557, file: !3, line: 2590, type: !6)
!557 = distinct !DILexicalBlock(scope: !558, file: !3, line: 2589, column: 24)
!558 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2589, column: 7)
!559 = !DILocalVariable(name: "w", scope: !557, file: !3, line: 2591, type: !6)
!560 = !DILocalVariable(name: "t", scope: !561, file: !3, line: 2599, type: !6)
!561 = distinct !DILexicalBlock(scope: !562, file: !3, line: 2598, column: 24)
!562 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2598, column: 7)
!563 = !DILocalVariable(name: "w", scope: !564, file: !3, line: 2608, type: !6)
!564 = distinct !DILexicalBlock(scope: !565, file: !3, line: 2607, column: 34)
!565 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2607, column: 7)
!566 = !DILocalVariable(name: "t", scope: !564, file: !3, line: 2609, type: !6)
!567 = !DIGlobalVariableExpression(var: !568, expr: !DIExpression())
!568 = distinct !DIGlobalVariable(name: "one", scope: !550, file: !3, line: 2579, type: !52, isLocal: true, isDefinition: true)
!569 = !DIGlobalVariableExpression(var: !570, expr: !DIExpression())
!570 = distinct !DIGlobalVariable(name: "half", scope: !550, file: !3, line: 2579, type: !52, isLocal: true, isDefinition: true)
!571 = !DIGlobalVariableExpression(var: !572, expr: !DIExpression())
!572 = distinct !DIGlobalVariable(name: "huge", scope: !550, file: !3, line: 2580, type: !16, isLocal: true, isDefinition: true)
!573 = !DIGlobalVariableExpression(var: !574, expr: !DIExpression())
!574 = distinct !DIGlobalVariable(name: "KSINH_OVERFLOW", scope: !575, file: !3, line: 2642, type: !52, isLocal: true, isDefinition: true)
!575 = distinct !DISubprogram(name: "pts_ieee754_sinh", scope: !3, file: !3, line: 2641, type: !4, scopeLine: 2641, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !576)
!576 = !{!577, !578, !579, !580, !583, !586}
!577 = !DILocalVariable(name: "x", arg: 1, scope: !575, file: !3, line: 2641, type: !6)
!578 = !DILocalVariable(name: "h", scope: !575, file: !3, line: 2648, type: !6)
!579 = !DILocalVariable(name: "ax", scope: !575, file: !3, line: 2650, type: !6)
!580 = !DILocalVariable(name: "t", scope: !581, file: !3, line: 2654, type: !6)
!581 = distinct !DILexicalBlock(scope: !582, file: !3, line: 2651, column: 16)
!582 = distinct !DILexicalBlock(scope: !575, file: !3, line: 2651, column: 7)
!583 = !DILocalVariable(name: "w", scope: !584, file: !3, line: 2665, type: !6)
!584 = distinct !DILexicalBlock(scope: !585, file: !3, line: 2664, column: 29)
!585 = distinct !DILexicalBlock(scope: !575, file: !3, line: 2664, column: 7)
!586 = !DILocalVariable(name: "t", scope: !584, file: !3, line: 2666, type: !6)
!587 = !DIGlobalVariableExpression(var: !588, expr: !DIExpression())
!588 = distinct !DIGlobalVariable(name: "TWO_M28", scope: !575, file: !3, line: 2643, type: !52, isLocal: true, isDefinition: true)
!589 = !DIGlobalVariableExpression(var: !590, expr: !DIExpression())
!590 = distinct !DIGlobalVariable(name: "LOG_MAXD", scope: !575, file: !3, line: 2645, type: !52, isLocal: true, isDefinition: true)
!591 = !DIGlobalVariableExpression(var: !592, expr: !DIExpression())
!592 = distinct !DIGlobalVariable(name: "shuge", scope: !575, file: !3, line: 2646, type: !52, isLocal: true, isDefinition: true)
!593 = !DIGlobalVariableExpression(var: !594, expr: !DIExpression())
!594 = distinct !DIGlobalVariable(name: "tiny", scope: !595, file: !3, line: 2698, type: !15, isLocal: true, isDefinition: true)
!595 = distinct !DISubprogram(name: "pts_ieee754_tanh", scope: !3, file: !3, line: 2697, type: !4, scopeLine: 2697, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !596)
!596 = !{!597, !598, !599, !600, !601, !602}
!597 = !DILocalVariable(name: "x", arg: 1, scope: !595, file: !3, line: 2697, type: !6)
!598 = !DILocalVariable(name: "t", scope: !595, file: !3, line: 2700, type: !6)
!599 = !DILocalVariable(name: "z", scope: !595, file: !3, line: 2700, type: !6)
!600 = !DILocalVariable(name: "jx", scope: !595, file: !3, line: 2701, type: !21)
!601 = !DILocalVariable(name: "ix", scope: !595, file: !3, line: 2701, type: !21)
!602 = !DILocalVariable(name: "bits", scope: !603, file: !3, line: 2703, type: !18)
!603 = distinct !DILexicalBlock(scope: !595, file: !3, line: 2703, column: 3)
!604 = !DIGlobalVariableExpression(var: !605, expr: !DIExpression())
!605 = distinct !DIGlobalVariable(name: "one", scope: !595, file: !3, line: 2699, type: !52, isLocal: true, isDefinition: true)
!606 = !DIGlobalVariableExpression(var: !607, expr: !DIExpression())
!607 = distinct !DIGlobalVariable(name: "two", scope: !595, file: !3, line: 2699, type: !52, isLocal: true, isDefinition: true)
!608 = !DIGlobalVariableExpression(var: !609, expr: !DIExpression())
!609 = distinct !DIGlobalVariable(name: "huge", scope: !595, file: !3, line: 2699, type: !52, isLocal: true, isDefinition: true)
!610 = !DIGlobalVariableExpression(var: !611, expr: !DIExpression())
!611 = distinct !DIGlobalVariable(name: "one", scope: !612, file: !3, line: 338, type: !52, isLocal: true, isDefinition: true)
!612 = distinct !DISubprogram(name: "__kernel_cos", scope: !3, file: !3, line: 336, type: !176, scopeLine: 336, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !613)
!613 = !{!614, !615, !616, !617, !618, !619, !620, !621, !622, !624}
!614 = !DILocalVariable(name: "x", arg: 1, scope: !612, file: !3, line: 336, type: !6)
!615 = !DILocalVariable(name: "y", arg: 2, scope: !612, file: !3, line: 336, type: !6)
!616 = !DILocalVariable(name: "a", scope: !612, file: !3, line: 346, type: !6)
!617 = !DILocalVariable(name: "iz", scope: !612, file: !3, line: 346, type: !6)
!618 = !DILocalVariable(name: "z", scope: !612, file: !3, line: 346, type: !6)
!619 = !DILocalVariable(name: "r", scope: !612, file: !3, line: 346, type: !6)
!620 = !DILocalVariable(name: "qx", scope: !612, file: !3, line: 346, type: !6)
!621 = !DILocalVariable(name: "ix", scope: !612, file: !3, line: 347, type: !21)
!622 = !DILocalVariable(name: "bits", scope: !623, file: !3, line: 348, type: !18)
!623 = distinct !DILexicalBlock(scope: !612, file: !3, line: 348, column: 3)
!624 = !DILocalVariable(name: "bits", scope: !625, file: !3, line: 361, type: !18)
!625 = distinct !DILexicalBlock(scope: !626, file: !3, line: 361, column: 7)
!626 = distinct !DILexicalBlock(scope: !627, file: !3, line: 360, column: 12)
!627 = distinct !DILexicalBlock(scope: !628, file: !3, line: 358, column: 9)
!628 = distinct !DILexicalBlock(scope: !629, file: !3, line: 357, column: 10)
!629 = distinct !DILexicalBlock(scope: !612, file: !3, line: 355, column: 7)
!630 = !DIGlobalVariableExpression(var: !631, expr: !DIExpression())
!631 = distinct !DIGlobalVariable(name: "C1", scope: !612, file: !3, line: 339, type: !52, isLocal: true, isDefinition: true)
!632 = !DIGlobalVariableExpression(var: !633, expr: !DIExpression())
!633 = distinct !DIGlobalVariable(name: "C2", scope: !612, file: !3, line: 340, type: !52, isLocal: true, isDefinition: true)
!634 = !DIGlobalVariableExpression(var: !635, expr: !DIExpression())
!635 = distinct !DIGlobalVariable(name: "C3", scope: !612, file: !3, line: 341, type: !52, isLocal: true, isDefinition: true)
!636 = !DIGlobalVariableExpression(var: !637, expr: !DIExpression())
!637 = distinct !DIGlobalVariable(name: "C4", scope: !612, file: !3, line: 342, type: !52, isLocal: true, isDefinition: true)
!638 = !DIGlobalVariableExpression(var: !639, expr: !DIExpression())
!639 = distinct !DIGlobalVariable(name: "C5", scope: !612, file: !3, line: 343, type: !52, isLocal: true, isDefinition: true)
!640 = !DIGlobalVariableExpression(var: !641, expr: !DIExpression())
!641 = distinct !DIGlobalVariable(name: "C6", scope: !612, file: !3, line: 344, type: !52, isLocal: true, isDefinition: true)
!642 = !DIGlobalVariableExpression(var: !643, expr: !DIExpression())
!643 = distinct !DIGlobalVariable(name: "two_over_pi", scope: !644, file: !3, line: 153, type: !687, isLocal: true, isDefinition: true)
!644 = distinct !DISubprogram(name: "__ieee754_rem_pio2", scope: !3, file: !3, line: 149, type: !645, scopeLine: 149, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !648)
!645 = !DISubroutineType(types: !646)
!646 = !{!21, !6, !647}
!647 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!648 = !{!649, !650, !651, !652, !653, !654, !655, !656, !660, !661, !662, !663, !664, !665, !666, !667, !668, !670, !675, !677, !681, !683, !685}
!649 = !DILocalVariable(name: "x", arg: 1, scope: !644, file: !3, line: 149, type: !6)
!650 = !DILocalVariable(name: "y", arg: 2, scope: !644, file: !3, line: 149, type: !647)
!651 = !DILocalVariable(name: "z", scope: !644, file: !3, line: 197, type: !6)
!652 = !DILocalVariable(name: "w", scope: !644, file: !3, line: 197, type: !6)
!653 = !DILocalVariable(name: "t", scope: !644, file: !3, line: 197, type: !6)
!654 = !DILocalVariable(name: "r", scope: !644, file: !3, line: 197, type: !6)
!655 = !DILocalVariable(name: "fn", scope: !644, file: !3, line: 197, type: !6)
!656 = !DILocalVariable(name: "tx", scope: !644, file: !3, line: 198, type: !657)
!657 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 192, elements: !658)
!658 = !{!659}
!659 = !DISubrange(count: 3)
!660 = !DILocalVariable(name: "e0", scope: !644, file: !3, line: 199, type: !21)
!661 = !DILocalVariable(name: "i", scope: !644, file: !3, line: 199, type: !21)
!662 = !DILocalVariable(name: "j", scope: !644, file: !3, line: 199, type: !21)
!663 = !DILocalVariable(name: "nx", scope: !644, file: !3, line: 199, type: !21)
!664 = !DILocalVariable(name: "n", scope: !644, file: !3, line: 199, type: !21)
!665 = !DILocalVariable(name: "ix", scope: !644, file: !3, line: 199, type: !21)
!666 = !DILocalVariable(name: "hx", scope: !644, file: !3, line: 199, type: !21)
!667 = !DILocalVariable(name: "low", scope: !644, file: !3, line: 200, type: !9)
!668 = !DILocalVariable(name: "bits", scope: !669, file: !3, line: 203, type: !18)
!669 = distinct !DILexicalBlock(scope: !644, file: !3, line: 203, column: 3)
!670 = !DILocalVariable(name: "high", scope: !671, file: !3, line: 244, type: !9)
!671 = distinct !DILexicalBlock(scope: !672, file: !3, line: 243, column: 12)
!672 = distinct !DILexicalBlock(scope: !673, file: !3, line: 241, column: 9)
!673 = distinct !DILexicalBlock(scope: !674, file: !3, line: 235, column: 25)
!674 = distinct !DILexicalBlock(scope: !644, file: !3, line: 235, column: 7)
!675 = !DILocalVariable(name: "bits", scope: !676, file: !3, line: 247, type: !18)
!676 = distinct !DILexicalBlock(scope: !671, file: !3, line: 247, column: 7)
!677 = !DILocalVariable(name: "bits", scope: !678, file: !3, line: 255, type: !18)
!678 = distinct !DILexicalBlock(scope: !679, file: !3, line: 255, column: 9)
!679 = distinct !DILexicalBlock(scope: !680, file: !3, line: 249, column: 19)
!680 = distinct !DILexicalBlock(scope: !671, file: !3, line: 249, column: 11)
!681 = !DILocalVariable(name: "bits", scope: !682, file: !3, line: 283, type: !18)
!682 = distinct !DILexicalBlock(scope: !644, file: !3, line: 283, column: 3)
!683 = !DILocalVariable(name: "bits", scope: !684, file: !3, line: 284, type: !18)
!684 = distinct !DILexicalBlock(scope: !644, file: !3, line: 284, column: 3)
!685 = !DILocalVariable(name: "bits", scope: !686, file: !3, line: 286, type: !18)
!686 = distinct !DILexicalBlock(scope: !644, file: !3, line: 286, column: 3)
!687 = !DICompositeType(tag: DW_TAG_array_type, baseType: !688, size: 2112, elements: !689)
!688 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !21)
!689 = !{!690}
!690 = !DISubrange(count: 66)
!691 = !DIGlobalVariableExpression(var: !692, expr: !DIExpression())
!692 = distinct !DIGlobalVariable(name: "npio2_hw", scope: !644, file: !3, line: 166, type: !693, isLocal: true, isDefinition: true)
!693 = !DICompositeType(tag: DW_TAG_array_type, baseType: !688, size: 1024, elements: !694)
!694 = !{!695}
!695 = !DISubrange(count: 32)
!696 = !DIGlobalVariableExpression(var: !697, expr: !DIExpression())
!697 = distinct !DIGlobalVariable(name: "zero", scope: !644, file: !3, line: 186, type: !52, isLocal: true, isDefinition: true)
!698 = !DIGlobalVariableExpression(var: !699, expr: !DIExpression())
!699 = distinct !DIGlobalVariable(name: "half", scope: !644, file: !3, line: 187, type: !52, isLocal: true, isDefinition: true)
!700 = !DIGlobalVariableExpression(var: !701, expr: !DIExpression())
!701 = distinct !DIGlobalVariable(name: "two24", scope: !644, file: !3, line: 188, type: !52, isLocal: true, isDefinition: true)
!702 = !DIGlobalVariableExpression(var: !703, expr: !DIExpression())
!703 = distinct !DIGlobalVariable(name: "invpio2", scope: !644, file: !3, line: 189, type: !52, isLocal: true, isDefinition: true)
!704 = !DIGlobalVariableExpression(var: !705, expr: !DIExpression())
!705 = distinct !DIGlobalVariable(name: "pio2_1", scope: !644, file: !3, line: 190, type: !52, isLocal: true, isDefinition: true)
!706 = !DIGlobalVariableExpression(var: !707, expr: !DIExpression())
!707 = distinct !DIGlobalVariable(name: "pio2_1t", scope: !644, file: !3, line: 191, type: !52, isLocal: true, isDefinition: true)
!708 = !DIGlobalVariableExpression(var: !709, expr: !DIExpression())
!709 = distinct !DIGlobalVariable(name: "pio2_2", scope: !644, file: !3, line: 192, type: !52, isLocal: true, isDefinition: true)
!710 = !DIGlobalVariableExpression(var: !711, expr: !DIExpression())
!711 = distinct !DIGlobalVariable(name: "pio2_2t", scope: !644, file: !3, line: 193, type: !52, isLocal: true, isDefinition: true)
!712 = !DIGlobalVariableExpression(var: !713, expr: !DIExpression())
!713 = distinct !DIGlobalVariable(name: "pio2_3", scope: !644, file: !3, line: 194, type: !52, isLocal: true, isDefinition: true)
!714 = !DIGlobalVariableExpression(var: !715, expr: !DIExpression())
!715 = distinct !DIGlobalVariable(name: "pio2_3t", scope: !644, file: !3, line: 195, type: !52, isLocal: true, isDefinition: true)
!716 = !DIGlobalVariableExpression(var: !717, expr: !DIExpression())
!717 = distinct !DIGlobalVariable(name: "init_jk", scope: !718, file: !3, line: 482, type: !753, isLocal: true, isDefinition: true)
!718 = distinct !DISubprogram(name: "__kernel_rem_pio2", scope: !3, file: !3, line: 474, type: !719, scopeLine: 475, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !722)
!719 = !DISubroutineType(types: !720)
!720 = !{!17, !647, !647, !17, !17, !17, !721}
!721 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !688, size: 64)
!722 = !{!723, !724, !725, !726, !727, !728, !729, !730, !731, !732, !733, !734, !735, !736, !740, !741, !742, !743, !744, !745, !746, !747, !748, !750, !751, !752}
!723 = !DILocalVariable(name: "x", arg: 1, scope: !718, file: !3, line: 474, type: !647)
!724 = !DILocalVariable(name: "y", arg: 2, scope: !718, file: !3, line: 474, type: !647)
!725 = !DILocalVariable(name: "e0", arg: 3, scope: !718, file: !3, line: 474, type: !17)
!726 = !DILocalVariable(name: "nx", arg: 4, scope: !718, file: !3, line: 474, type: !17)
!727 = !DILocalVariable(name: "prec", arg: 5, scope: !718, file: !3, line: 474, type: !17)
!728 = !DILocalVariable(name: "ipio2", arg: 6, scope: !718, file: !3, line: 475, type: !721)
!729 = !DILocalVariable(name: "jz", scope: !718, file: !3, line: 501, type: !21)
!730 = !DILocalVariable(name: "jx", scope: !718, file: !3, line: 501, type: !21)
!731 = !DILocalVariable(name: "jv", scope: !718, file: !3, line: 501, type: !21)
!732 = !DILocalVariable(name: "jp", scope: !718, file: !3, line: 501, type: !21)
!733 = !DILocalVariable(name: "jk", scope: !718, file: !3, line: 501, type: !21)
!734 = !DILocalVariable(name: "carry", scope: !718, file: !3, line: 501, type: !21)
!735 = !DILocalVariable(name: "n", scope: !718, file: !3, line: 501, type: !21)
!736 = !DILocalVariable(name: "iq", scope: !718, file: !3, line: 501, type: !737)
!737 = !DICompositeType(tag: DW_TAG_array_type, baseType: !21, size: 640, elements: !738)
!738 = !{!739}
!739 = !DISubrange(count: 20)
!740 = !DILocalVariable(name: "i", scope: !718, file: !3, line: 501, type: !21)
!741 = !DILocalVariable(name: "j", scope: !718, file: !3, line: 501, type: !21)
!742 = !DILocalVariable(name: "k", scope: !718, file: !3, line: 501, type: !21)
!743 = !DILocalVariable(name: "m", scope: !718, file: !3, line: 501, type: !21)
!744 = !DILocalVariable(name: "q0", scope: !718, file: !3, line: 501, type: !21)
!745 = !DILocalVariable(name: "ih", scope: !718, file: !3, line: 501, type: !21)
!746 = !DILocalVariable(name: "z", scope: !718, file: !3, line: 502, type: !6)
!747 = !DILocalVariable(name: "fw", scope: !718, file: !3, line: 502, type: !6)
!748 = !DILocalVariable(name: "f", scope: !718, file: !3, line: 502, type: !749)
!749 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 1280, elements: !738)
!750 = !DILocalVariable(name: "fq", scope: !718, file: !3, line: 502, type: !749)
!751 = !DILocalVariable(name: "q", scope: !718, file: !3, line: 502, type: !749)
!752 = !DILabel(scope: !718, name: "recompute", file: !3, line: 528)
!753 = !DICompositeType(tag: DW_TAG_array_type, baseType: !754, size: 128, elements: !162)
!754 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !17)
!755 = !DIGlobalVariableExpression(var: !756, expr: !DIExpression())
!756 = distinct !DIGlobalVariable(name: "PIo2", scope: !718, file: !3, line: 484, type: !757, isLocal: true, isDefinition: true)
!757 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 512, elements: !758)
!758 = !{!759}
!759 = !DISubrange(count: 8)
!760 = !DIGlobalVariableExpression(var: !761, expr: !DIExpression())
!761 = distinct !DIGlobalVariable(name: "zero", scope: !718, file: !3, line: 496, type: !52, isLocal: true, isDefinition: true)
!762 = !DIGlobalVariableExpression(var: !763, expr: !DIExpression())
!763 = distinct !DIGlobalVariable(name: "one", scope: !718, file: !3, line: 497, type: !52, isLocal: true, isDefinition: true)
!764 = !DIGlobalVariableExpression(var: !765, expr: !DIExpression())
!765 = distinct !DIGlobalVariable(name: "two24", scope: !718, file: !3, line: 498, type: !52, isLocal: true, isDefinition: true)
!766 = !DIGlobalVariableExpression(var: !767, expr: !DIExpression())
!767 = distinct !DIGlobalVariable(name: "twon24", scope: !718, file: !3, line: 499, type: !52, isLocal: true, isDefinition: true)
!768 = !DIGlobalVariableExpression(var: !769, expr: !DIExpression())
!769 = distinct !DIGlobalVariable(name: "half", scope: !770, file: !3, line: 706, type: !52, isLocal: true, isDefinition: true)
!770 = distinct !DISubprogram(name: "__kernel_sin", scope: !3, file: !3, line: 704, type: !771, scopeLine: 704, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !773)
!771 = !DISubroutineType(types: !772)
!772 = !{!6, !6, !6, !17}
!773 = !{!774, !775, !776, !777, !778, !779, !780, !781}
!774 = !DILocalVariable(name: "x", arg: 1, scope: !770, file: !3, line: 704, type: !6)
!775 = !DILocalVariable(name: "y", arg: 2, scope: !770, file: !3, line: 704, type: !6)
!776 = !DILocalVariable(name: "iy", arg: 3, scope: !770, file: !3, line: 704, type: !17)
!777 = !DILocalVariable(name: "z", scope: !770, file: !3, line: 714, type: !6)
!778 = !DILocalVariable(name: "r", scope: !770, file: !3, line: 714, type: !6)
!779 = !DILocalVariable(name: "v", scope: !770, file: !3, line: 714, type: !6)
!780 = !DILocalVariable(name: "ix", scope: !770, file: !3, line: 715, type: !21)
!781 = !DILocalVariable(name: "bits", scope: !782, file: !3, line: 716, type: !18)
!782 = distinct !DILexicalBlock(scope: !770, file: !3, line: 716, column: 3)
!783 = !DIGlobalVariableExpression(var: !784, expr: !DIExpression())
!784 = distinct !DIGlobalVariable(name: "S1", scope: !770, file: !3, line: 707, type: !52, isLocal: true, isDefinition: true)
!785 = !DIGlobalVariableExpression(var: !786, expr: !DIExpression())
!786 = distinct !DIGlobalVariable(name: "S2", scope: !770, file: !3, line: 708, type: !52, isLocal: true, isDefinition: true)
!787 = !DIGlobalVariableExpression(var: !788, expr: !DIExpression())
!788 = distinct !DIGlobalVariable(name: "S3", scope: !770, file: !3, line: 709, type: !52, isLocal: true, isDefinition: true)
!789 = !DIGlobalVariableExpression(var: !790, expr: !DIExpression())
!790 = distinct !DIGlobalVariable(name: "S4", scope: !770, file: !3, line: 710, type: !52, isLocal: true, isDefinition: true)
!791 = !DIGlobalVariableExpression(var: !792, expr: !DIExpression())
!792 = distinct !DIGlobalVariable(name: "S5", scope: !770, file: !3, line: 711, type: !52, isLocal: true, isDefinition: true)
!793 = !DIGlobalVariableExpression(var: !794, expr: !DIExpression())
!794 = distinct !DIGlobalVariable(name: "S6", scope: !770, file: !3, line: 712, type: !52, isLocal: true, isDefinition: true)
!795 = !DIGlobalVariableExpression(var: !796, expr: !DIExpression(DW_OP_constu, 4600877379321592324, DW_OP_stack_value))
!796 = distinct !DIGlobalVariable(name: "Lg2", scope: !7, file: !3, line: 1967, type: !52, isLocal: true, isDefinition: true)
!797 = !DIGlobalVariableExpression(var: !798, expr: !DIExpression(DW_OP_constu, 4597174411056806063, DW_OP_stack_value))
!798 = distinct !DIGlobalVariable(name: "Lg4", scope: !7, file: !3, line: 1969, type: !52, isLocal: true, isDefinition: true)
!799 = !DIGlobalVariableExpression(var: !800, expr: !DIExpression(DW_OP_constu, 4594685411790997151, DW_OP_stack_value))
!800 = distinct !DIGlobalVariable(name: "Lg6", scope: !7, file: !3, line: 1971, type: !52, isLocal: true, isDefinition: true)
!801 = !DIGlobalVariableExpression(var: !802, expr: !DIExpression(DW_OP_constu, 4604180019048437139, DW_OP_stack_value))
!802 = distinct !DIGlobalVariable(name: "Lg1", scope: !7, file: !3, line: 1966, type: !52, isLocal: true, isDefinition: true)
!803 = !DIGlobalVariableExpression(var: !804, expr: !DIExpression(DW_OP_constu, 4598818590951641945, DW_OP_stack_value))
!804 = distinct !DIGlobalVariable(name: "Lg3", scope: !7, file: !3, line: 1968, type: !52, isLocal: true, isDefinition: true)
!805 = !DIGlobalVariableExpression(var: !806, expr: !DIExpression(DW_OP_constu, 4595719342595441630, DW_OP_stack_value))
!806 = distinct !DIGlobalVariable(name: "Lg5", scope: !7, file: !3, line: 1970, type: !52, isLocal: true, isDefinition: true)
!807 = !DIGlobalVariableExpression(var: !808, expr: !DIExpression(DW_OP_constu, 4594499633228436036, DW_OP_stack_value))
!808 = distinct !DIGlobalVariable(name: "Lg7", scope: !7, file: !3, line: 1972, type: !52, isLocal: true, isDefinition: true)
!809 = !DIGlobalVariableExpression(var: !810, expr: !DIExpression())
!810 = distinct !DIGlobalVariable(name: "xxx", scope: !811, file: !3, line: 765, type: !850, isLocal: true, isDefinition: true)
!811 = distinct !DISubprogram(name: "__kernel_tan", scope: !3, file: !3, line: 764, type: !771, scopeLine: 764, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !812)
!812 = !{!813, !814, !815, !816, !817, !818, !819, !820, !821, !822, !823, !825, !830, !832, !837, !838, !840, !842, !845, !846, !848}
!813 = !DILocalVariable(name: "x", arg: 1, scope: !811, file: !3, line: 764, type: !6)
!814 = !DILocalVariable(name: "y", arg: 2, scope: !811, file: !3, line: 764, type: !6)
!815 = !DILocalVariable(name: "iy", arg: 3, scope: !811, file: !3, line: 764, type: !17)
!816 = !DILocalVariable(name: "z", scope: !811, file: !3, line: 788, type: !6)
!817 = !DILocalVariable(name: "r", scope: !811, file: !3, line: 788, type: !6)
!818 = !DILocalVariable(name: "v", scope: !811, file: !3, line: 788, type: !6)
!819 = !DILocalVariable(name: "w", scope: !811, file: !3, line: 788, type: !6)
!820 = !DILocalVariable(name: "s", scope: !811, file: !3, line: 788, type: !6)
!821 = !DILocalVariable(name: "ix", scope: !811, file: !3, line: 789, type: !21)
!822 = !DILocalVariable(name: "hx", scope: !811, file: !3, line: 789, type: !21)
!823 = !DILocalVariable(name: "bits", scope: !824, file: !3, line: 791, type: !18)
!824 = distinct !DILexicalBlock(scope: !811, file: !3, line: 791, column: 3)
!825 = !DILocalVariable(name: "low", scope: !826, file: !3, line: 795, type: !9)
!826 = distinct !DILexicalBlock(scope: !827, file: !3, line: 794, column: 24)
!827 = distinct !DILexicalBlock(scope: !828, file: !3, line: 794, column: 9)
!828 = distinct !DILexicalBlock(scope: !829, file: !3, line: 793, column: 24)
!829 = distinct !DILexicalBlock(scope: !811, file: !3, line: 793, column: 7)
!830 = !DILocalVariable(name: "bits", scope: !831, file: !3, line: 796, type: !18)
!831 = distinct !DILexicalBlock(scope: !826, file: !3, line: 796, column: 7)
!832 = !DILocalVariable(name: "a", scope: !833, file: !3, line: 803, type: !6)
!833 = distinct !DILexicalBlock(scope: !834, file: !3, line: 802, column: 16)
!834 = distinct !DILexicalBlock(scope: !835, file: !3, line: 800, column: 13)
!835 = distinct !DILexicalBlock(scope: !836, file: !3, line: 799, column: 14)
!836 = distinct !DILexicalBlock(scope: !826, file: !3, line: 797, column: 11)
!837 = !DILocalVariable(name: "t", scope: !833, file: !3, line: 803, type: !6)
!838 = !DILocalVariable(name: "bits", scope: !839, file: !3, line: 806, type: !18)
!839 = distinct !DILexicalBlock(scope: !833, file: !3, line: 806, column: 11)
!840 = !DILocalVariable(name: "bits", scope: !841, file: !3, line: 809, type: !18)
!841 = distinct !DILexicalBlock(scope: !833, file: !3, line: 809, column: 11)
!842 = !DILocalVariable(name: "a", scope: !843, file: !3, line: 852, type: !6)
!843 = distinct !DILexicalBlock(scope: !844, file: !3, line: 846, column: 10)
!844 = distinct !DILexicalBlock(scope: !811, file: !3, line: 844, column: 7)
!845 = !DILocalVariable(name: "t", scope: !843, file: !3, line: 852, type: !6)
!846 = !DILocalVariable(name: "bits", scope: !847, file: !3, line: 854, type: !18)
!847 = distinct !DILexicalBlock(scope: !843, file: !3, line: 854, column: 5)
!848 = !DILocalVariable(name: "bits", scope: !849, file: !3, line: 857, type: !18)
!849 = distinct !DILexicalBlock(scope: !843, file: !3, line: 857, column: 5)
!850 = !DICompositeType(tag: DW_TAG_array_type, baseType: !52, size: 1024, elements: !851)
!851 = !{!852}
!852 = !DISubrange(count: 16)
!853 = !{!854, !855, !856, !857, !858, !859, !860, !861, !862, !864, !867}
!854 = !DILocalVariable(name: "x", arg: 1, scope: !2, file: !3, line: 1147, type: !6)
!855 = !DILocalVariable(name: "w", scope: !2, file: !3, line: 1178, type: !6)
!856 = !DILocalVariable(name: "s1", scope: !2, file: !3, line: 1178, type: !6)
!857 = !DILocalVariable(name: "s2", scope: !2, file: !3, line: 1178, type: !6)
!858 = !DILocalVariable(name: "z", scope: !2, file: !3, line: 1178, type: !6)
!859 = !DILocalVariable(name: "ix", scope: !2, file: !3, line: 1179, type: !21)
!860 = !DILocalVariable(name: "hx", scope: !2, file: !3, line: 1179, type: !21)
!861 = !DILocalVariable(name: "id", scope: !2, file: !3, line: 1179, type: !21)
!862 = !DILocalVariable(name: "bits", scope: !863, file: !3, line: 1181, type: !18)
!863 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1181, column: 3)
!864 = !DILocalVariable(name: "low", scope: !865, file: !3, line: 1184, type: !9)
!865 = distinct !DILexicalBlock(scope: !866, file: !3, line: 1183, column: 25)
!866 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1183, column: 7)
!867 = !DILocalVariable(name: "bits", scope: !868, file: !3, line: 1185, type: !18)
!868 = distinct !DILexicalBlock(scope: !865, file: !3, line: 1185, column: 5)
!869 = !{i32 7, !"Dwarf Version", i32 5}
!870 = !{i32 2, !"Debug Info Version", i32 3}
!871 = !{i32 1, !"wchar_size", i32 4}
!872 = !{i32 8, !"PIC Level", i32 2}
!873 = !{i32 7, !"PIE Level", i32 2}
!874 = !{i32 7, !"uwtable", i32 2}
!875 = !{i32 7, !"frame-pointer", i32 1}
!876 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!877 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!878 = !DILocation(line: 0, scope: !27)
!879 = !DILocalVariable(name: "d", arg: 1, scope: !880, file: !3, line: 54, type: !6)
!880 = distinct !DISubprogram(name: "bits_of", scope: !3, file: !3, line: 54, type: !881, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !883)
!881 = !DISubroutineType(types: !882)
!882 = !{!18, !6}
!883 = !{!879, !884}
!884 = !DILocalVariable(name: "bits", scope: !880, file: !3, line: 55, type: !18)
!885 = !DILocation(line: 0, scope: !880, inlinedAt: !886)
!886 = distinct !DILocation(line: 912, column: 3, scope: !41)
!887 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !886)
!888 = !DILocation(line: 0, scope: !41)
!889 = !DILocation(line: 912, column: 3, scope: !41)
!890 = !DILocation(line: 913, column: 11, scope: !27)
!891 = !DILocation(line: 914, column: 10, scope: !44)
!892 = !DILocation(line: 914, column: 7, scope: !27)
!893 = !DILocation(line: 0, scope: !880, inlinedAt: !894)
!894 = distinct !DILocation(line: 916, column: 5, scope: !46)
!895 = !DILocation(line: 0, scope: !46)
!896 = !DILocation(line: 916, column: 5, scope: !46)
!897 = !DILocation(line: 0, scope: !43)
!898 = !DILocation(line: 917, column: 14, scope: !899)
!899 = distinct !DILexicalBlock(scope: !43, file: !3, line: 917, column: 9)
!900 = !DILocation(line: 917, column: 28, scope: !899)
!901 = !DILocation(line: 917, column: 34, scope: !899)
!902 = !DILocation(line: 917, column: 9, scope: !43)
!903 = !DILocation(line: 925, column: 10, scope: !51)
!904 = !DILocation(line: 925, column: 7, scope: !27)
!905 = !DILocation(line: 926, column: 12, scope: !906)
!906 = distinct !DILexicalBlock(scope: !907, file: !3, line: 926, column: 9)
!907 = distinct !DILexicalBlock(scope: !51, file: !3, line: 925, column: 24)
!908 = !DILocation(line: 926, column: 9, scope: !907)
!909 = !DILocation(line: 927, column: 11, scope: !907)
!910 = !DILocation(line: 928, column: 62, scope: !907)
!911 = !DILocation(line: 928, column: 51, scope: !907)
!912 = !DILocation(line: 928, column: 40, scope: !907)
!913 = !DILocation(line: 928, column: 29, scope: !907)
!914 = !DILocation(line: 928, column: 18, scope: !907)
!915 = !DILocation(line: 928, column: 11, scope: !907)
!916 = !DILocation(line: 929, column: 46, scope: !907)
!917 = !DILocation(line: 929, column: 35, scope: !907)
!918 = !DILocation(line: 929, column: 24, scope: !907)
!919 = !DILocation(line: 929, column: 13, scope: !907)
!920 = !DILocation(line: 930, column: 11, scope: !907)
!921 = !DILocation(line: 931, column: 36, scope: !907)
!922 = !DILocation(line: 931, column: 20, scope: !907)
!923 = !DILocation(line: 931, column: 5, scope: !907)
!924 = !DILocation(line: 932, column: 17, scope: !50)
!925 = !DILocation(line: 932, column: 14, scope: !51)
!926 = !DILocation(line: 933, column: 14, scope: !927)
!927 = distinct !DILexicalBlock(scope: !50, file: !3, line: 932, column: 22)
!928 = !DILocation(line: 933, column: 19, scope: !927)
!929 = !DILocation(line: 934, column: 62, scope: !927)
!930 = !DILocation(line: 934, column: 51, scope: !927)
!931 = !DILocation(line: 934, column: 40, scope: !927)
!932 = !DILocation(line: 934, column: 29, scope: !927)
!933 = !DILocation(line: 934, column: 18, scope: !927)
!934 = !DILocation(line: 934, column: 11, scope: !927)
!935 = !DILocation(line: 935, column: 46, scope: !927)
!936 = !DILocation(line: 935, column: 35, scope: !927)
!937 = !DILocation(line: 935, column: 24, scope: !927)
!938 = !DILocation(line: 935, column: 13, scope: !927)
!939 = !DILocation(line: 936, column: 9, scope: !927)
!940 = !DILocation(line: 937, column: 11, scope: !927)
!941 = !DILocation(line: 938, column: 15, scope: !927)
!942 = !DILocation(line: 939, column: 26, scope: !927)
!943 = !DILocation(line: 939, column: 15, scope: !927)
!944 = !DILocation(line: 939, column: 5, scope: !927)
!945 = !DILocation(line: 941, column: 14, scope: !49)
!946 = !DILocation(line: 941, column: 19, scope: !49)
!947 = !DILocation(line: 942, column: 9, scope: !49)
!948 = !DILocation(line: 0, scope: !880, inlinedAt: !949)
!949 = distinct !DILocation(line: 944, column: 5, scope: !48)
!950 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !949)
!951 = !DILocation(line: 0, scope: !48)
!952 = !DILocation(line: 944, column: 5, scope: !48)
!953 = !DILocalVariable(name: "bits", arg: 1, scope: !954, file: !3, line: 60, type: !18)
!954 = distinct !DISubprogram(name: "double_of", scope: !3, file: !3, line: 60, type: !955, scopeLine: 60, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !957)
!955 = !DISubroutineType(types: !956)
!956 = !{!6, !18}
!957 = !{!953, !958}
!958 = !DILocalVariable(name: "d", scope: !954, file: !3, line: 61, type: !6)
!959 = !DILocation(line: 0, scope: !954, inlinedAt: !960)
!960 = distinct !DILocation(line: 944, column: 5, scope: !48)
!961 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !960)
!962 = !DILocation(line: 945, column: 12, scope: !49)
!963 = !DILocation(line: 945, column: 28, scope: !49)
!964 = !DILocation(line: 945, column: 23, scope: !49)
!965 = !DILocation(line: 946, column: 62, scope: !49)
!966 = !DILocation(line: 946, column: 51, scope: !49)
!967 = !DILocation(line: 946, column: 40, scope: !49)
!968 = !DILocation(line: 946, column: 29, scope: !49)
!969 = !DILocation(line: 946, column: 18, scope: !49)
!970 = !DILocation(line: 946, column: 11, scope: !49)
!971 = !DILocation(line: 947, column: 46, scope: !49)
!972 = !DILocation(line: 947, column: 35, scope: !49)
!973 = !DILocation(line: 947, column: 24, scope: !49)
!974 = !DILocation(line: 947, column: 13, scope: !49)
!975 = !DILocation(line: 948, column: 11, scope: !49)
!976 = !DILocation(line: 949, column: 15, scope: !49)
!977 = !DILocation(line: 950, column: 22, scope: !49)
!978 = !DILocation(line: 950, column: 16, scope: !49)
!979 = !DILocation(line: 950, column: 5, scope: !49)
!980 = !DILocation(line: 952, column: 1, scope: !27)
!981 = !DILocation(line: 0, scope: !81)
!982 = !DILocation(line: 0, scope: !880, inlinedAt: !983)
!983 = distinct !DILocation(line: 974, column: 3, scope: !88)
!984 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !983)
!985 = !DILocation(line: 0, scope: !88)
!986 = !DILocation(line: 974, column: 3, scope: !88)
!987 = !DILocation(line: 975, column: 10, scope: !988)
!988 = distinct !DILexicalBlock(scope: !81, file: !3, line: 975, column: 7)
!989 = !DILocation(line: 975, column: 7, scope: !81)
!990 = !DILocation(line: 977, column: 17, scope: !991)
!991 = distinct !DILexicalBlock(scope: !988, file: !3, line: 977, column: 14)
!992 = !DILocation(line: 977, column: 14, scope: !988)
!993 = !DILocation(line: 978, column: 12, scope: !994)
!994 = distinct !DILexicalBlock(scope: !995, file: !3, line: 978, column: 9)
!995 = distinct !DILexicalBlock(scope: !991, file: !3, line: 977, column: 32)
!996 = !DILocation(line: 978, column: 9, scope: !995)
!997 = !DILocation(line: 979, column: 16, scope: !998)
!998 = distinct !DILexicalBlock(scope: !994, file: !3, line: 978, column: 27)
!999 = !DILocation(line: 979, column: 7, scope: !998)
!1000 = !DILocation(line: 981, column: 14, scope: !1001)
!1001 = distinct !DILexicalBlock(scope: !994, file: !3, line: 980, column: 12)
!1002 = !DILocation(line: 981, column: 33, scope: !1001)
!1003 = !DILocation(line: 981, column: 7, scope: !1001)
!1004 = !DILocation(line: 983, column: 19, scope: !1005)
!1005 = distinct !DILexicalBlock(scope: !991, file: !3, line: 983, column: 14)
!1006 = !DILocation(line: 983, column: 33, scope: !1005)
!1007 = !DILocation(line: 983, column: 39, scope: !1005)
!1008 = !DILocation(line: 983, column: 14, scope: !991)
!1009 = !DILocation(line: 985, column: 17, scope: !1010)
!1010 = distinct !DILexicalBlock(scope: !1005, file: !3, line: 985, column: 14)
!1011 = !DILocation(line: 985, column: 14, scope: !1005)
!1012 = !DILocation(line: 986, column: 11, scope: !1013)
!1013 = distinct !DILexicalBlock(scope: !1010, file: !3, line: 985, column: 31)
!1014 = !DILocation(line: 987, column: 56, scope: !1013)
!1015 = !DILocation(line: 987, column: 49, scope: !1013)
!1016 = !DILocation(line: 987, column: 47, scope: !1013)
!1017 = !DILocation(line: 987, column: 36, scope: !1013)
!1018 = !DILocation(line: 987, column: 12, scope: !1013)
!1019 = !DILocation(line: 987, column: 5, scope: !1013)
!1020 = !DILocation(line: 989, column: 11, scope: !1021)
!1021 = distinct !DILexicalBlock(scope: !1010, file: !3, line: 988, column: 10)
!1022 = !DILocation(line: 990, column: 51, scope: !1021)
!1023 = !DILocation(line: 990, column: 47, scope: !1021)
!1024 = !DILocation(line: 990, column: 34, scope: !1021)
!1025 = !DILocation(line: 990, column: 32, scope: !1021)
!1026 = !DILocation(line: 990, column: 12, scope: !1021)
!1027 = !DILocation(line: 990, column: 5, scope: !1021)
!1028 = !DILocation(line: 0, scope: !988)
!1029 = !DILocation(line: 992, column: 1, scope: !81)
!1030 = !DILocation(line: 0, scope: !286)
!1031 = !DILocation(line: 0, scope: !880, inlinedAt: !1032)
!1032 = distinct !DILocation(line: 1684, column: 3, scope: !304)
!1033 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1032)
!1034 = !DILocation(line: 0, scope: !304)
!1035 = !DILocation(line: 1684, column: 3, scope: !304)
!1036 = !DILocation(line: 1687, column: 10, scope: !308)
!1037 = !DILocation(line: 1687, column: 7, scope: !286)
!1038 = !DILocation(line: 1688, column: 14, scope: !1039)
!1039 = distinct !DILexicalBlock(scope: !307, file: !3, line: 1688, column: 9)
!1040 = !DILocation(line: 1688, column: 28, scope: !1039)
!1041 = !DILocation(line: 1688, column: 34, scope: !1039)
!1042 = !DILocation(line: 1688, column: 9, scope: !307)
!1043 = !DILocation(line: 1691, column: 12, scope: !1044)
!1044 = distinct !DILexicalBlock(scope: !307, file: !3, line: 1691, column: 9)
!1045 = !DILocation(line: 1691, column: 9, scope: !307)
!1046 = !DILocation(line: 1695, column: 7, scope: !307)
!1047 = !DILocation(line: 0, scope: !880, inlinedAt: !1048)
!1048 = distinct !DILocation(line: 1696, column: 5, scope: !306)
!1049 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1048)
!1050 = !DILocation(line: 0, scope: !306)
!1051 = !DILocation(line: 1696, column: 5, scope: !306)
!1052 = !DILocation(line: 1697, column: 3, scope: !307)
!1053 = !DILocation(line: 1698, column: 10, scope: !1054)
!1054 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1698, column: 7)
!1055 = !DILocation(line: 1698, column: 7, scope: !286)
!1056 = !DILocation(line: 1698, column: 34, scope: !1054)
!1057 = !DILocation(line: 1698, column: 25, scope: !1054)
!1058 = !DILocation(line: 1699, column: 12, scope: !286)
!1059 = !DILocation(line: 1699, column: 19, scope: !286)
!1060 = !DILocation(line: 1699, column: 5, scope: !286)
!1061 = !DILocation(line: 1700, column: 6, scope: !286)
!1062 = !DILocation(line: 1701, column: 11, scope: !286)
!1063 = !DILocation(line: 1701, column: 22, scope: !286)
!1064 = !DILocation(line: 0, scope: !880, inlinedAt: !1065)
!1065 = distinct !DILocation(line: 1702, column: 3, scope: !310)
!1066 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1065)
!1067 = !DILocation(line: 0, scope: !310)
!1068 = !DILocation(line: 1702, column: 3, scope: !310)
!1069 = !DILocation(line: 0, scope: !954, inlinedAt: !1070)
!1070 = distinct !DILocation(line: 1702, column: 3, scope: !310)
!1071 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !1070)
!1072 = !DILocation(line: 1703, column: 5, scope: !286)
!1073 = !DILocation(line: 1704, column: 9, scope: !286)
!1074 = !DILocation(line: 1705, column: 24, scope: !1075)
!1075 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1705, column: 7)
!1076 = !DILocation(line: 1705, column: 19, scope: !1075)
!1077 = !DILocation(line: 1705, column: 31, scope: !1075)
!1078 = !DILocation(line: 1705, column: 7, scope: !286)
!1079 = !DILocation(line: 1706, column: 11, scope: !1080)
!1080 = distinct !DILexicalBlock(scope: !1081, file: !3, line: 1706, column: 9)
!1081 = distinct !DILexicalBlock(scope: !1075, file: !3, line: 1705, column: 36)
!1082 = !DILocation(line: 1706, column: 9, scope: !1081)
!1083 = !DILocation(line: 1707, column: 13, scope: !1084)
!1084 = distinct !DILexicalBlock(scope: !1085, file: !3, line: 1707, column: 11)
!1085 = distinct !DILexicalBlock(scope: !1080, file: !3, line: 1706, column: 20)
!1086 = !DILocation(line: 1707, column: 11, scope: !1085)
!1087 = !DILocation(line: 1710, column: 14, scope: !1088)
!1088 = distinct !DILexicalBlock(scope: !1084, file: !3, line: 1709, column: 14)
!1089 = !DILocation(line: 1711, column: 33, scope: !1088)
!1090 = !DILocation(line: 1711, column: 28, scope: !1088)
!1091 = !DILocation(line: 1711, column: 9, scope: !1088)
!1092 = !DILocation(line: 1714, column: 11, scope: !1081)
!1093 = !DILocation(line: 1714, column: 22, scope: !1081)
!1094 = !DILocation(line: 1714, column: 15, scope: !1081)
!1095 = !DILocation(line: 1715, column: 11, scope: !1096)
!1096 = distinct !DILexicalBlock(scope: !1081, file: !3, line: 1715, column: 9)
!1097 = !DILocation(line: 1715, column: 9, scope: !1081)
!1098 = !DILocation(line: 1716, column: 16, scope: !1099)
!1099 = distinct !DILexicalBlock(scope: !1096, file: !3, line: 1715, column: 17)
!1100 = !DILocation(line: 1716, column: 7, scope: !1099)
!1101 = !DILocation(line: 1718, column: 12, scope: !1102)
!1102 = distinct !DILexicalBlock(scope: !1096, file: !3, line: 1717, column: 12)
!1103 = !DILocation(line: 1719, column: 32, scope: !1102)
!1104 = !DILocation(line: 1719, column: 47, scope: !1102)
!1105 = !DILocation(line: 1719, column: 26, scope: !1102)
!1106 = !DILocation(line: 1719, column: 7, scope: !1102)
!1107 = !DILocation(line: 1722, column: 16, scope: !286)
!1108 = !DILocation(line: 1722, column: 9, scope: !286)
!1109 = !DILocation(line: 1723, column: 8, scope: !286)
!1110 = !DILocation(line: 1724, column: 9, scope: !286)
!1111 = !DILocation(line: 1725, column: 10, scope: !286)
!1112 = !DILocation(line: 1726, column: 9, scope: !286)
!1113 = !DILocation(line: 1727, column: 15, scope: !286)
!1114 = !DILocation(line: 1728, column: 28, scope: !286)
!1115 = !DILocation(line: 1728, column: 17, scope: !286)
!1116 = !DILocation(line: 1728, column: 10, scope: !286)
!1117 = !DILocation(line: 1729, column: 39, scope: !286)
!1118 = !DILocation(line: 1729, column: 28, scope: !286)
!1119 = !DILocation(line: 1729, column: 17, scope: !286)
!1120 = !DILocation(line: 1729, column: 10, scope: !286)
!1121 = !DILocation(line: 1730, column: 5, scope: !286)
!1122 = !DILocation(line: 1731, column: 10, scope: !286)
!1123 = !DILocation(line: 1732, column: 9, scope: !1124)
!1124 = distinct !DILexicalBlock(scope: !286, file: !3, line: 1732, column: 7)
!1125 = !DILocation(line: 1732, column: 7, scope: !286)
!1126 = !DILocation(line: 1733, column: 16, scope: !1127)
!1127 = distinct !DILexicalBlock(scope: !1124, file: !3, line: 1732, column: 14)
!1128 = !DILocation(line: 1733, column: 20, scope: !1127)
!1129 = !DILocation(line: 1734, column: 11, scope: !1130)
!1130 = distinct !DILexicalBlock(scope: !1127, file: !3, line: 1734, column: 9)
!1131 = !DILocation(line: 0, scope: !1130)
!1132 = !DILocation(line: 1734, column: 9, scope: !1127)
!1133 = !DILocation(line: 1735, column: 24, scope: !1130)
!1134 = !DILocation(line: 1735, column: 16, scope: !1130)
!1135 = !DILocation(line: 1735, column: 7, scope: !1130)
!1136 = !DILocation(line: 1737, column: 58, scope: !1130)
!1137 = !DILocation(line: 1737, column: 53, scope: !1130)
!1138 = !DILocation(line: 1737, column: 35, scope: !1130)
!1139 = !DILocation(line: 1737, column: 69, scope: !1130)
!1140 = !DILocation(line: 1737, column: 26, scope: !1130)
!1141 = !DILocation(line: 1737, column: 7, scope: !1130)
!1142 = !DILocation(line: 1739, column: 11, scope: !1143)
!1143 = distinct !DILexicalBlock(scope: !1144, file: !3, line: 1739, column: 9)
!1144 = distinct !DILexicalBlock(scope: !1124, file: !3, line: 1738, column: 10)
!1145 = !DILocation(line: 0, scope: !1143)
!1146 = !DILocation(line: 1739, column: 9, scope: !1144)
!1147 = !DILocation(line: 1740, column: 16, scope: !1143)
!1148 = !DILocation(line: 1740, column: 7, scope: !1143)
!1149 = !DILocation(line: 1742, column: 42, scope: !1143)
!1150 = !DILocation(line: 1742, column: 57, scope: !1143)
!1151 = !DILocation(line: 1742, column: 26, scope: !1143)
!1152 = !DILocation(line: 1742, column: 7, scope: !1143)
!1153 = !DILocation(line: 1744, column: 1, scope: !286)
!1154 = !DILocation(line: 0, scope: !333)
!1155 = !DILocation(line: 0, scope: !880, inlinedAt: !1156)
!1156 = distinct !DILocation(line: 1828, column: 3, scope: !348)
!1157 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1156)
!1158 = !DILocation(line: 0, scope: !348)
!1159 = !DILocation(line: 1828, column: 3, scope: !348)
!1160 = !DILocation(line: 1829, column: 11, scope: !333)
!1161 = !DILocation(line: 1832, column: 10, scope: !1162)
!1162 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1832, column: 7)
!1163 = !DILocation(line: 1832, column: 7, scope: !333)
!1164 = !DILocation(line: 1833, column: 12, scope: !1165)
!1165 = distinct !DILexicalBlock(scope: !1166, file: !3, line: 1833, column: 9)
!1166 = distinct !DILexicalBlock(scope: !1162, file: !3, line: 1832, column: 24)
!1167 = !DILocation(line: 1833, column: 9, scope: !1166)
!1168 = !DILocation(line: 1834, column: 13, scope: !1169)
!1169 = distinct !DILexicalBlock(scope: !1170, file: !3, line: 1834, column: 11)
!1170 = distinct !DILexicalBlock(scope: !1165, file: !3, line: 1833, column: 27)
!1171 = !DILocation(line: 0, scope: !1169)
!1172 = !DILocation(line: 1839, column: 12, scope: !1173)
!1173 = distinct !DILexicalBlock(scope: !1166, file: !3, line: 1839, column: 9)
!1174 = !DILocation(line: 1839, column: 9, scope: !1166)
!1175 = !DILocation(line: 1840, column: 17, scope: !1176)
!1176 = distinct !DILexicalBlock(scope: !1177, file: !3, line: 1840, column: 11)
!1177 = distinct !DILexicalBlock(scope: !1173, file: !3, line: 1839, column: 26)
!1178 = !DILocation(line: 1840, column: 21, scope: !1176)
!1179 = !DILocation(line: 1841, column: 11, scope: !1176)
!1180 = !DILocation(line: 1844, column: 18, scope: !1176)
!1181 = !DILocation(line: 1844, column: 9, scope: !1176)
!1182 = !DILocation(line: 1852, column: 10, scope: !1183)
!1183 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1852, column: 7)
!1184 = !DILocation(line: 1852, column: 7, scope: !333)
!1185 = !DILocation(line: 1852, column: 34, scope: !1183)
!1186 = !DILocation(line: 1852, column: 25, scope: !1183)
!1187 = !DILocation(line: 1846, column: 16, scope: !1188)
!1188 = distinct !DILexicalBlock(scope: !1166, file: !3, line: 1846, column: 9)
!1189 = !DILocation(line: 1853, column: 7, scope: !333)
!1190 = !DILocation(line: 1883, column: 14, scope: !333)
!1191 = !DILocation(line: 1883, column: 18, scope: !333)
!1192 = !DILocation(line: 1884, column: 7, scope: !333)
!1193 = !DILocation(line: 1854, column: 12, scope: !352)
!1194 = !DILocation(line: 1854, column: 9, scope: !353)
!1195 = !DILocation(line: 1855, column: 15, scope: !351)
!1196 = !DILocation(line: 0, scope: !880, inlinedAt: !1197)
!1197 = distinct !DILocation(line: 1856, column: 7, scope: !350)
!1198 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1197)
!1199 = !DILocation(line: 0, scope: !350)
!1200 = !DILocation(line: 1856, column: 7, scope: !350)
!1201 = !DILocation(line: 1857, column: 15, scope: !351)
!1202 = !DILocation(line: 1858, column: 14, scope: !351)
!1203 = !DILocation(line: 1858, column: 11, scope: !351)
!1204 = !DILocation(line: 1859, column: 9, scope: !351)
!1205 = !DILocation(line: 1860, column: 5, scope: !351)
!1206 = !DILocation(line: 0, scope: !880, inlinedAt: !1207)
!1207 = distinct !DILocation(line: 1862, column: 7, scope: !356)
!1208 = !DILocation(line: 1863, column: 15, scope: !357)
!1209 = !DILocation(line: 0, scope: !352)
!1210 = !DILocation(line: 1866, column: 8, scope: !353)
!1211 = !DILocation(line: 1874, column: 12, scope: !361)
!1212 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1213)
!1213 = !DILocation(line: 0, scope: !361)
!1214 = !DILocation(line: 0, scope: !880, inlinedAt: !1215)
!1215 = distinct !DILocation(line: 1875, column: 7, scope: !359)
!1216 = !DILocation(line: 0, scope: !880, inlinedAt: !1217)
!1217 = distinct !DILocation(line: 1878, column: 7, scope: !363)
!1218 = !DILocation(line: 1874, column: 9, scope: !353)
!1219 = !DILocation(line: 0, scope: !359)
!1220 = !DILocation(line: 1875, column: 7, scope: !359)
!1221 = !DILocation(line: 1876, column: 5, scope: !360)
!1222 = !DILocation(line: 1877, column: 9, scope: !364)
!1223 = !DILocation(line: 0, scope: !363)
!1224 = !DILocation(line: 1878, column: 7, scope: !363)
!1225 = !DILocation(line: 1879, column: 24, scope: !364)
!1226 = !DILocation(line: 0, scope: !353)
!1227 = !DILocation(line: 1881, column: 11, scope: !353)
!1228 = !DILocation(line: 1884, column: 10, scope: !1229)
!1229 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1884, column: 7)
!1230 = !DILocation(line: 1885, column: 11, scope: !1231)
!1231 = distinct !DILexicalBlock(scope: !1232, file: !3, line: 1885, column: 9)
!1232 = distinct !DILexicalBlock(scope: !1229, file: !3, line: 1884, column: 16)
!1233 = !DILocation(line: 1885, column: 9, scope: !1232)
!1234 = !DILocation(line: 1886, column: 13, scope: !1235)
!1235 = distinct !DILexicalBlock(scope: !1236, file: !3, line: 1886, column: 11)
!1236 = distinct !DILexicalBlock(scope: !1231, file: !3, line: 1885, column: 20)
!1237 = !DILocation(line: 1886, column: 11, scope: !1236)
!1238 = !DILocation(line: 1889, column: 14, scope: !1239)
!1239 = distinct !DILexicalBlock(scope: !1235, file: !3, line: 1888, column: 14)
!1240 = !DILocation(line: 1889, column: 11, scope: !1239)
!1241 = !DILocation(line: 1890, column: 27, scope: !1239)
!1242 = !DILocation(line: 1890, column: 9, scope: !1239)
!1243 = !DILocation(line: 1893, column: 21, scope: !1232)
!1244 = !DILocation(line: 1893, column: 14, scope: !1232)
!1245 = !DILocation(line: 1894, column: 11, scope: !1246)
!1246 = distinct !DILexicalBlock(scope: !1232, file: !3, line: 1894, column: 9)
!1247 = !DILocation(line: 1894, column: 9, scope: !1232)
!1248 = !DILocation(line: 1895, column: 16, scope: !1246)
!1249 = !DILocation(line: 1895, column: 7, scope: !1246)
!1250 = !DILocation(line: 1897, column: 14, scope: !1246)
!1251 = !DILocation(line: 1897, column: 45, scope: !1246)
!1252 = !DILocation(line: 1897, column: 31, scope: !1246)
!1253 = !DILocation(line: 1897, column: 51, scope: !1246)
!1254 = !DILocation(line: 1897, column: 25, scope: !1246)
!1255 = !DILocation(line: 1897, column: 7, scope: !1246)
!1256 = !DILocation(line: 1899, column: 16, scope: !333)
!1257 = !DILocation(line: 1899, column: 9, scope: !333)
!1258 = !DILocation(line: 1900, column: 9, scope: !333)
!1259 = !DILocation(line: 1902, column: 65, scope: !333)
!1260 = !DILocation(line: 1902, column: 54, scope: !333)
!1261 = !DILocation(line: 1902, column: 43, scope: !333)
!1262 = !DILocation(line: 1902, column: 32, scope: !333)
!1263 = !DILocation(line: 1902, column: 21, scope: !333)
!1264 = !DILocation(line: 1901, column: 16, scope: !333)
!1265 = !DILocation(line: 1901, column: 9, scope: !333)
!1266 = !DILocation(line: 1903, column: 9, scope: !1267)
!1267 = distinct !DILexicalBlock(scope: !333, file: !3, line: 1903, column: 7)
!1268 = !DILocation(line: 1903, column: 7, scope: !333)
!1269 = !DILocation(line: 1904, column: 34, scope: !1267)
!1270 = !DILocation(line: 1904, column: 22, scope: !1267)
!1271 = !DILocation(line: 1904, column: 14, scope: !1267)
!1272 = !DILocation(line: 1904, column: 5, scope: !1267)
!1273 = !DILocation(line: 1906, column: 12, scope: !1267)
!1274 = !DILocation(line: 1906, column: 45, scope: !1267)
!1275 = !DILocation(line: 1906, column: 64, scope: !1267)
!1276 = !DILocation(line: 1906, column: 50, scope: !1267)
!1277 = !DILocation(line: 1906, column: 32, scope: !1267)
!1278 = !DILocation(line: 1906, column: 71, scope: !1267)
!1279 = !DILocation(line: 1906, column: 23, scope: !1267)
!1280 = !DILocation(line: 1906, column: 5, scope: !1267)
!1281 = !DILocation(line: 1907, column: 1, scope: !333)
!1282 = !DILocation(line: 0, scope: !93)
!1283 = !DILocation(line: 0, scope: !880, inlinedAt: !1284)
!1284 = distinct !DILocation(line: 1045, column: 3, scope: !106)
!1285 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1284)
!1286 = !DILocation(line: 0, scope: !106)
!1287 = !DILocation(line: 1045, column: 3, scope: !106)
!1288 = !DILocation(line: 1046, column: 11, scope: !93)
!1289 = !DILocation(line: 1047, column: 10, scope: !109)
!1290 = !DILocation(line: 1047, column: 7, scope: !93)
!1291 = !DILocation(line: 0, scope: !880, inlinedAt: !1292)
!1292 = distinct !DILocation(line: 1049, column: 5, scope: !111)
!1293 = !DILocation(line: 0, scope: !111)
!1294 = !DILocation(line: 1049, column: 5, scope: !111)
!1295 = !DILocation(line: 0, scope: !108)
!1296 = !DILocation(line: 1050, column: 14, scope: !1297)
!1297 = distinct !DILexicalBlock(scope: !108, file: !3, line: 1050, column: 9)
!1298 = !DILocation(line: 1050, column: 28, scope: !1297)
!1299 = !DILocation(line: 1050, column: 34, scope: !1297)
!1300 = !DILocation(line: 1050, column: 9, scope: !108)
!1301 = !DILocation(line: 1054, column: 17, scope: !1302)
!1302 = distinct !DILexicalBlock(scope: !109, file: !3, line: 1054, column: 14)
!1303 = !DILocation(line: 1054, column: 14, scope: !109)
!1304 = !DILocation(line: 1055, column: 12, scope: !1305)
!1305 = distinct !DILexicalBlock(scope: !1306, file: !3, line: 1055, column: 9)
!1306 = distinct !DILexicalBlock(scope: !1302, file: !3, line: 1054, column: 31)
!1307 = !DILocation(line: 1055, column: 9, scope: !1306)
!1308 = !DILocation(line: 1056, column: 16, scope: !1309)
!1309 = distinct !DILexicalBlock(scope: !1310, file: !3, line: 1056, column: 11)
!1310 = distinct !DILexicalBlock(scope: !1305, file: !3, line: 1055, column: 26)
!1311 = !DILocation(line: 1056, column: 20, scope: !1309)
!1312 = !DILocation(line: 1056, column: 11, scope: !1310)
!1313 = !DILocation(line: 1058, column: 13, scope: !1314)
!1314 = distinct !DILexicalBlock(scope: !1305, file: !3, line: 1057, column: 12)
!1315 = !DILocation(line: 1060, column: 62, scope: !1306)
!1316 = !DILocation(line: 1060, column: 51, scope: !1306)
!1317 = !DILocation(line: 1060, column: 40, scope: !1306)
!1318 = !DILocation(line: 1060, column: 29, scope: !1306)
!1319 = !DILocation(line: 1060, column: 18, scope: !1306)
!1320 = !DILocation(line: 1060, column: 11, scope: !1306)
!1321 = !DILocation(line: 1061, column: 46, scope: !1306)
!1322 = !DILocation(line: 1061, column: 35, scope: !1306)
!1323 = !DILocation(line: 1061, column: 24, scope: !1306)
!1324 = !DILocation(line: 1061, column: 13, scope: !1306)
!1325 = !DILocation(line: 1062, column: 11, scope: !1306)
!1326 = !DILocation(line: 1063, column: 14, scope: !1306)
!1327 = !DILocation(line: 1063, column: 5, scope: !1306)
!1328 = !DILocation(line: 1066, column: 13, scope: !93)
!1329 = !DILocation(line: 1066, column: 11, scope: !93)
!1330 = !DILocation(line: 1067, column: 9, scope: !93)
!1331 = !DILocation(line: 1068, column: 60, scope: !93)
!1332 = !DILocation(line: 1068, column: 49, scope: !93)
!1333 = !DILocation(line: 1068, column: 38, scope: !93)
!1334 = !DILocation(line: 1068, column: 27, scope: !93)
!1335 = !DILocation(line: 1068, column: 16, scope: !93)
!1336 = !DILocation(line: 1068, column: 9, scope: !93)
!1337 = !DILocation(line: 1069, column: 44, scope: !93)
!1338 = !DILocation(line: 1069, column: 33, scope: !93)
!1339 = !DILocation(line: 1069, column: 22, scope: !93)
!1340 = !DILocation(line: 1069, column: 11, scope: !93)
!1341 = !DILocation(line: 1070, column: 7, scope: !93)
!1342 = !DILocation(line: 1071, column: 10, scope: !115)
!1343 = !DILocation(line: 1071, column: 7, scope: !93)
!1344 = !DILocation(line: 1072, column: 11, scope: !1345)
!1345 = distinct !DILexicalBlock(scope: !115, file: !3, line: 1071, column: 25)
!1346 = !DILocation(line: 1073, column: 29, scope: !1345)
!1347 = !DILocation(line: 1073, column: 38, scope: !1345)
!1348 = !DILocation(line: 1073, column: 17, scope: !1345)
!1349 = !DILocation(line: 1074, column: 3, scope: !1345)
!1350 = !DILocation(line: 0, scope: !880, inlinedAt: !1351)
!1351 = distinct !DILocation(line: 1076, column: 5, scope: !113)
!1352 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1351)
!1353 = !DILocation(line: 0, scope: !113)
!1354 = !DILocation(line: 1076, column: 5, scope: !113)
!1355 = !DILocation(line: 0, scope: !954, inlinedAt: !1356)
!1356 = distinct !DILocation(line: 1076, column: 5, scope: !113)
!1357 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !1356)
!1358 = !DILocation(line: 1077, column: 12, scope: !114)
!1359 = !DILocation(line: 1077, column: 26, scope: !114)
!1360 = !DILocation(line: 1077, column: 21, scope: !114)
!1361 = !DILocation(line: 1078, column: 11, scope: !114)
!1362 = !DILocation(line: 1079, column: 13, scope: !114)
!1363 = !DILocation(line: 1079, column: 32, scope: !114)
!1364 = !DILocation(line: 1079, column: 21, scope: !114)
!1365 = !DILocation(line: 1080, column: 17, scope: !114)
!1366 = !DILocation(line: 1081, column: 17, scope: !114)
!1367 = !DILocation(line: 0, scope: !115)
!1368 = !DILocation(line: 1083, column: 10, scope: !1369)
!1369 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1083, column: 7)
!1370 = !DILocation(line: 1083, column: 7, scope: !93)
!1371 = !DILocation(line: 1087, column: 1, scope: !93)
!1372 = !DILocation(line: 0, scope: !146)
!1373 = !DILocation(line: 0, scope: !880, inlinedAt: !1374)
!1374 = distinct !DILocation(line: 1106, column: 3, scope: !154)
!1375 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1374)
!1376 = !DILocation(line: 0, scope: !154)
!1377 = !DILocation(line: 1106, column: 3, scope: !154)
!1378 = !DILocation(line: 1107, column: 11, scope: !146)
!1379 = !DILocation(line: 1108, column: 10, scope: !1380)
!1380 = distinct !DILexicalBlock(scope: !146, file: !3, line: 1108, column: 7)
!1381 = !DILocation(line: 1108, column: 7, scope: !146)
!1382 = !DILocation(line: 1108, column: 34, scope: !1380)
!1383 = !DILocation(line: 1108, column: 25, scope: !1380)
!1384 = !DILocation(line: 1109, column: 10, scope: !1385)
!1385 = distinct !DILexicalBlock(scope: !146, file: !3, line: 1109, column: 7)
!1386 = !DILocation(line: 1109, column: 7, scope: !146)
!1387 = !DILocation(line: 1112, column: 10, scope: !1388)
!1388 = distinct !DILexicalBlock(scope: !146, file: !3, line: 1112, column: 7)
!1389 = !DILocation(line: 1112, column: 7, scope: !146)
!1390 = !DILocation(line: 1113, column: 25, scope: !1391)
!1391 = distinct !DILexicalBlock(scope: !1388, file: !3, line: 1112, column: 24)
!1392 = !DILocation(line: 1113, column: 9, scope: !1391)
!1393 = !DILocation(line: 1113, column: 34, scope: !1391)
!1394 = !DILocation(line: 1114, column: 3, scope: !1391)
!1395 = !DILocation(line: 1114, column: 17, scope: !1396)
!1396 = distinct !DILexicalBlock(scope: !1388, file: !3, line: 1114, column: 14)
!1397 = !DILocation(line: 1114, column: 14, scope: !1388)
!1398 = !DILocation(line: 1115, column: 9, scope: !1399)
!1399 = distinct !DILexicalBlock(scope: !1396, file: !3, line: 1114, column: 31)
!1400 = !DILocation(line: 1116, column: 53, scope: !1399)
!1401 = !DILocation(line: 1116, column: 42, scope: !1399)
!1402 = !DILocation(line: 1116, column: 60, scope: !1399)
!1403 = !DILocation(line: 1116, column: 39, scope: !1399)
!1404 = !DILocation(line: 1116, column: 33, scope: !1399)
!1405 = !DILocation(line: 1116, column: 9, scope: !1399)
!1406 = !DILocation(line: 1117, column: 3, scope: !1399)
!1407 = !DILocation(line: 1118, column: 11, scope: !1408)
!1408 = distinct !DILexicalBlock(scope: !1396, file: !3, line: 1117, column: 10)
!1409 = !DILocation(line: 1119, column: 27, scope: !1408)
!1410 = !DILocation(line: 1119, column: 57, scope: !1408)
!1411 = !DILocation(line: 1119, column: 48, scope: !1408)
!1412 = !DILocation(line: 1119, column: 46, scope: !1408)
!1413 = !DILocation(line: 1119, column: 39, scope: !1408)
!1414 = !DILocation(line: 1119, column: 35, scope: !1408)
!1415 = !DILocation(line: 1119, column: 9, scope: !1408)
!1416 = !DILocation(line: 0, scope: !1388)
!1417 = !DILocation(line: 1121, column: 10, scope: !1418)
!1418 = distinct !DILexicalBlock(scope: !146, file: !3, line: 1121, column: 7)
!1419 = !DILocation(line: 1121, column: 7, scope: !146)
!1420 = !DILocation(line: 1126, column: 1, scope: !146)
!1421 = !DILocation(line: 0, scope: !2)
!1422 = !DILocation(line: 0, scope: !880, inlinedAt: !1423)
!1423 = distinct !DILocation(line: 1181, column: 3, scope: !863)
!1424 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1423)
!1425 = !DILocation(line: 0, scope: !863)
!1426 = !DILocation(line: 1181, column: 3, scope: !863)
!1427 = !DILocation(line: 1182, column: 11, scope: !2)
!1428 = !DILocation(line: 1183, column: 10, scope: !866)
!1429 = !DILocation(line: 1183, column: 7, scope: !2)
!1430 = !DILocation(line: 0, scope: !880, inlinedAt: !1431)
!1431 = distinct !DILocation(line: 1185, column: 5, scope: !868)
!1432 = !DILocation(line: 0, scope: !865)
!1433 = !DILocation(line: 1186, column: 12, scope: !1434)
!1434 = distinct !DILexicalBlock(scope: !865, file: !3, line: 1186, column: 9)
!1435 = !DILocation(line: 1186, column: 25, scope: !1434)
!1436 = !DILocation(line: 1186, column: 32, scope: !1434)
!1437 = !DILocation(line: 1186, column: 46, scope: !1434)
!1438 = !DILocation(line: 1187, column: 16, scope: !1434)
!1439 = !DILocation(line: 1187, column: 7, scope: !1434)
!1440 = !DILocation(line: 1188, column: 12, scope: !1441)
!1441 = distinct !DILexicalBlock(scope: !865, file: !3, line: 1188, column: 9)
!1442 = !DILocation(line: 0, scope: !1441)
!1443 = !{!1444, !1444, i64 0}
!1444 = !{!"double", !1445, i64 0}
!1445 = !{!"omnipotent char", !1446, i64 0}
!1446 = !{!"Simple C/C++ TBAA"}
!1447 = !DILocation(line: 1188, column: 9, scope: !865)
!1448 = !DILocation(line: 1189, column: 24, scope: !1441)
!1449 = !DILocation(line: 1189, column: 7, scope: !1441)
!1450 = !DILocation(line: 1191, column: 25, scope: !1441)
!1451 = !DILocation(line: 1191, column: 7, scope: !1441)
!1452 = !DILocation(line: 1193, column: 10, scope: !1453)
!1453 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1193, column: 7)
!1454 = !DILocation(line: 1193, column: 7, scope: !2)
!1455 = !DILocation(line: 1194, column: 12, scope: !1456)
!1456 = distinct !DILexicalBlock(scope: !1457, file: !3, line: 1194, column: 9)
!1457 = distinct !DILexicalBlock(scope: !1453, file: !3, line: 1193, column: 24)
!1458 = !DILocation(line: 1194, column: 9, scope: !1457)
!1459 = !DILocation(line: 1199, column: 9, scope: !1460)
!1460 = distinct !DILexicalBlock(scope: !1453, file: !3, line: 1198, column: 10)
!1461 = !DILocation(line: 1200, column: 12, scope: !1462)
!1462 = distinct !DILexicalBlock(scope: !1460, file: !3, line: 1200, column: 9)
!1463 = !DILocation(line: 1200, column: 9, scope: !1460)
!1464 = !DILocation(line: 1201, column: 14, scope: !1465)
!1465 = distinct !DILexicalBlock(scope: !1466, file: !3, line: 1201, column: 11)
!1466 = distinct !DILexicalBlock(scope: !1462, file: !3, line: 1200, column: 26)
!1467 = !DILocation(line: 1201, column: 11, scope: !1466)
!1468 = !DILocation(line: 1203, column: 22, scope: !1469)
!1469 = distinct !DILexicalBlock(scope: !1465, file: !3, line: 1201, column: 28)
!1470 = !DILocation(line: 1203, column: 36, scope: !1469)
!1471 = !DILocation(line: 1203, column: 29, scope: !1469)
!1472 = !DILocation(line: 1204, column: 7, scope: !1469)
!1473 = !DILocation(line: 1206, column: 16, scope: !1474)
!1474 = distinct !DILexicalBlock(scope: !1465, file: !3, line: 1204, column: 14)
!1475 = !DILocation(line: 1206, column: 28, scope: !1474)
!1476 = !DILocation(line: 1206, column: 23, scope: !1474)
!1477 = !DILocation(line: 1209, column: 14, scope: !1478)
!1478 = distinct !DILexicalBlock(scope: !1479, file: !3, line: 1209, column: 11)
!1479 = distinct !DILexicalBlock(scope: !1462, file: !3, line: 1208, column: 12)
!1480 = !DILocation(line: 1209, column: 11, scope: !1479)
!1481 = !DILocation(line: 1211, column: 16, scope: !1482)
!1482 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 1209, column: 28)
!1483 = !DILocation(line: 1211, column: 30, scope: !1482)
!1484 = !DILocation(line: 1211, column: 23, scope: !1482)
!1485 = !DILocation(line: 1212, column: 7, scope: !1482)
!1486 = !DILocation(line: 1214, column: 18, scope: !1487)
!1487 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 1212, column: 14)
!1488 = !DILocation(line: 0, scope: !1453)
!1489 = !DILocation(line: 1219, column: 9, scope: !2)
!1490 = !DILocation(line: 1220, column: 9, scope: !2)
!1491 = !DILocation(line: 1223, column: 63, scope: !2)
!1492 = !DILocation(line: 1223, column: 50, scope: !2)
!1493 = !DILocation(line: 1223, column: 37, scope: !2)
!1494 = !DILocation(line: 1223, column: 24, scope: !2)
!1495 = !DILocation(line: 1222, column: 19, scope: !2)
!1496 = !DILocation(line: 1222, column: 10, scope: !2)
!1497 = !DILocation(line: 1224, column: 58, scope: !2)
!1498 = !DILocation(line: 1224, column: 45, scope: !2)
!1499 = !DILocation(line: 1224, column: 32, scope: !2)
!1500 = !DILocation(line: 1224, column: 19, scope: !2)
!1501 = !DILocation(line: 1224, column: 10, scope: !2)
!1502 = !DILocation(line: 1225, column: 7, scope: !2)
!1503 = !DILocation(line: 1226, column: 24, scope: !1504)
!1504 = distinct !DILexicalBlock(scope: !1505, file: !3, line: 1225, column: 15)
!1505 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1225, column: 7)
!1506 = !DILocation(line: 1226, column: 14, scope: !1504)
!1507 = !DILocation(line: 1226, column: 5, scope: !1504)
!1508 = !DILocation(line: 1228, column: 9, scope: !1509)
!1509 = distinct !DILexicalBlock(scope: !1505, file: !3, line: 1227, column: 10)
!1510 = !DILocation(line: 1228, column: 32, scope: !1509)
!1511 = !DILocation(line: 1228, column: 40, scope: !1509)
!1512 = !DILocation(line: 1228, column: 38, scope: !1509)
!1513 = !DILocation(line: 1228, column: 52, scope: !1509)
!1514 = !DILocation(line: 1228, column: 20, scope: !1509)
!1515 = !DILocation(line: 1229, column: 16, scope: !1509)
!1516 = !DILocation(line: 1229, column: 12, scope: !1509)
!1517 = !DILocation(line: 1229, column: 5, scope: !1509)
!1518 = !DILocation(line: 1231, column: 1, scope: !2)
!1519 = !DILocation(line: 0, scope: !175)
!1520 = !DILocation(line: 0, scope: !880, inlinedAt: !1521)
!1521 = distinct !DILocation(line: 1273, column: 3, scope: !191)
!1522 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1521)
!1523 = !DILocation(line: 0, scope: !191)
!1524 = !DILocation(line: 1273, column: 3, scope: !191)
!1525 = !DILocation(line: 1274, column: 11, scope: !175)
!1526 = !DILocation(line: 0, scope: !880, inlinedAt: !1527)
!1527 = distinct !DILocation(line: 1275, column: 3, scope: !193)
!1528 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1527)
!1529 = !DILocation(line: 0, scope: !193)
!1530 = !DILocation(line: 1275, column: 3, scope: !193)
!1531 = !DILocation(line: 1276, column: 11, scope: !175)
!1532 = !DILocation(line: 1277, column: 49, scope: !1533)
!1533 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1277, column: 7)
!1534 = !DILocation(line: 1277, column: 12, scope: !1533)
!1535 = !DILocation(line: 1277, column: 57, scope: !1533)
!1536 = !DILocation(line: 1277, column: 71, scope: !1533)
!1537 = !DILocation(line: 1278, column: 49, scope: !1533)
!1538 = !DILocation(line: 1278, column: 12, scope: !1533)
!1539 = !DILocation(line: 1278, column: 57, scope: !1533)
!1540 = !DILocation(line: 1277, column: 7, scope: !175)
!1541 = !DILocation(line: 1279, column: 14, scope: !1542)
!1542 = distinct !DILexicalBlock(scope: !1533, file: !3, line: 1278, column: 72)
!1543 = !DILocation(line: 1279, column: 5, scope: !1542)
!1544 = !DILocalVariable(name: "a", arg: 1, scope: !1545, file: !3, line: 68, type: !21)
!1545 = distinct !DISubprogram(name: "sub_with_wraparound", scope: !3, file: !3, line: 68, type: !1546, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1548)
!1546 = !DISubroutineType(types: !1547)
!1547 = !{!21, !21, !21}
!1548 = !{!1544, !1549}
!1549 = !DILocalVariable(name: "b", arg: 2, scope: !1545, file: !3, line: 68, type: !21)
!1550 = !DILocation(line: 0, scope: !1545, inlinedAt: !1551)
!1551 = distinct !DILocation(line: 1281, column: 8, scope: !1552)
!1552 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1281, column: 7)
!1553 = !DILocation(line: 68, column: 96, scope: !1545, inlinedAt: !1551)
!1554 = !DILocation(line: 1281, column: 44, scope: !1552)
!1555 = !DILocation(line: 1281, column: 50, scope: !1552)
!1556 = !DILocation(line: 1281, column: 7, scope: !175)
!1557 = !DILocation(line: 1282, column: 12, scope: !1558)
!1558 = distinct !DILexicalBlock(scope: !1552, file: !3, line: 1281, column: 56)
!1559 = !DILocation(line: 1282, column: 5, scope: !1558)
!1560 = !DILocation(line: 1284, column: 12, scope: !175)
!1561 = !DILocation(line: 1284, column: 31, scope: !175)
!1562 = !DILocation(line: 1284, column: 38, scope: !175)
!1563 = !DILocation(line: 1284, column: 24, scope: !175)
!1564 = !DILocation(line: 1287, column: 11, scope: !1565)
!1565 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1287, column: 7)
!1566 = !DILocation(line: 1287, column: 17, scope: !1565)
!1567 = !DILocation(line: 1287, column: 7, scope: !175)
!1568 = !DILocation(line: 1288, column: 5, scope: !1569)
!1569 = distinct !DILexicalBlock(scope: !1565, file: !3, line: 1287, column: 23)
!1570 = !DILocation(line: 1293, column: 21, scope: !1571)
!1571 = distinct !DILexicalBlock(scope: !1569, file: !3, line: 1288, column: 16)
!1572 = !DILocation(line: 1293, column: 19, scope: !1571)
!1573 = !DILocation(line: 1293, column: 9, scope: !1571)
!1574 = !DILocation(line: 1295, column: 22, scope: !1571)
!1575 = !DILocation(line: 1295, column: 20, scope: !1571)
!1576 = !DILocation(line: 1295, column: 9, scope: !1571)
!1577 = !DILocation(line: 1299, column: 11, scope: !1578)
!1578 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1299, column: 7)
!1579 = !DILocation(line: 1299, column: 17, scope: !1578)
!1580 = !DILocation(line: 1299, column: 7, scope: !175)
!1581 = !DILocation(line: 1299, column: 34, scope: !1578)
!1582 = !DILocation(line: 1299, scope: !1578)
!1583 = !DILocation(line: 1299, column: 30, scope: !1578)
!1584 = !DILocation(line: 1299, column: 49, scope: !1578)
!1585 = !DILocation(line: 1299, column: 65, scope: !1578)
!1586 = !DILocation(line: 1302, column: 10, scope: !1587)
!1587 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1302, column: 7)
!1588 = !DILocation(line: 1302, column: 7, scope: !175)
!1589 = !DILocation(line: 1303, column: 9, scope: !1590)
!1590 = distinct !DILexicalBlock(scope: !1587, file: !3, line: 1302, column: 25)
!1591 = !DILocation(line: 1304, column: 7, scope: !1592)
!1592 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 1303, column: 27)
!1593 = distinct !DILexicalBlock(scope: !1590, file: !3, line: 1303, column: 9)
!1594 = !DILocation(line: 1306, column: 27, scope: !1595)
!1595 = distinct !DILexicalBlock(scope: !1592, file: !3, line: 1304, column: 18)
!1596 = !DILocation(line: 1306, column: 25, scope: !1595)
!1597 = !DILocation(line: 1306, column: 11, scope: !1595)
!1598 = !DILocation(line: 1308, column: 28, scope: !1595)
!1599 = !DILocation(line: 1308, column: 26, scope: !1595)
!1600 = !DILocation(line: 1308, column: 11, scope: !1595)
!1601 = !DILocation(line: 1310, column: 33, scope: !1595)
!1602 = !DILocation(line: 1310, column: 31, scope: !1595)
!1603 = !DILocation(line: 1310, column: 11, scope: !1595)
!1604 = !DILocation(line: 1312, column: 34, scope: !1595)
!1605 = !DILocation(line: 1312, column: 32, scope: !1595)
!1606 = !DILocation(line: 1312, column: 11, scope: !1595)
!1607 = !DILocation(line: 1315, column: 7, scope: !1608)
!1608 = distinct !DILexicalBlock(scope: !1593, file: !3, line: 1314, column: 12)
!1609 = !DILocation(line: 1319, column: 11, scope: !1610)
!1610 = distinct !DILexicalBlock(scope: !1608, file: !3, line: 1315, column: 18)
!1611 = !DILocation(line: 1321, column: 23, scope: !1610)
!1612 = !DILocation(line: 1321, column: 21, scope: !1610)
!1613 = !DILocation(line: 1321, column: 11, scope: !1610)
!1614 = !DILocation(line: 1323, column: 24, scope: !1610)
!1615 = !DILocation(line: 1323, column: 22, scope: !1610)
!1616 = !DILocation(line: 1323, column: 11, scope: !1610)
!1617 = !DILocation(line: 1328, column: 7, scope: !175)
!1618 = !DILocation(line: 1328, column: 36, scope: !1619)
!1619 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1328, column: 7)
!1620 = !DILocation(line: 1328, scope: !1619)
!1621 = !DILocation(line: 1328, column: 32, scope: !1619)
!1622 = !DILocation(line: 1328, column: 51, scope: !1619)
!1623 = !DILocation(line: 1328, column: 67, scope: !1619)
!1624 = !DILocation(line: 1331, column: 11, scope: !175)
!1625 = !DILocation(line: 1331, column: 17, scope: !175)
!1626 = !DILocation(line: 1332, column: 9, scope: !1627)
!1627 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1332, column: 7)
!1628 = !DILocation(line: 1332, column: 7, scope: !175)
!1629 = !DILocation(line: 1333, column: 24, scope: !1630)
!1630 = distinct !DILexicalBlock(scope: !1627, file: !3, line: 1332, column: 15)
!1631 = !DILocation(line: 1333, column: 16, scope: !1630)
!1632 = !DILocation(line: 1335, column: 3, scope: !1630)
!1633 = !DILocation(line: 1335, column: 17, scope: !1634)
!1634 = distinct !DILexicalBlock(scope: !1627, file: !3, line: 1335, column: 14)
!1635 = !DILocation(line: 1335, column: 21, scope: !1634)
!1636 = !DILocation(line: 1338, column: 33, scope: !1637)
!1637 = distinct !DILexicalBlock(scope: !1634, file: !3, line: 1337, column: 10)
!1638 = !DILocation(line: 1338, column: 26, scope: !1637)
!1639 = !DILocation(line: 1338, column: 9, scope: !1637)
!1640 = !DILocation(line: 0, scope: !1627)
!1641 = !DILocation(line: 1340, column: 3, scope: !175)
!1642 = !DILocation(line: 1344, column: 14, scope: !1643)
!1643 = distinct !DILexicalBlock(scope: !175, file: !3, line: 1340, column: 14)
!1644 = !DILocation(line: 1344, column: 7, scope: !1643)
!1645 = !DILocation(line: 1346, column: 24, scope: !1643)
!1646 = !DILocation(line: 1346, column: 17, scope: !1643)
!1647 = !DILocation(line: 1346, column: 7, scope: !1643)
!1648 = !DILocation(line: 1348, column: 19, scope: !1643)
!1649 = !DILocation(line: 1348, column: 17, scope: !1643)
!1650 = !DILocation(line: 1348, column: 26, scope: !1643)
!1651 = !DILocation(line: 1348, column: 7, scope: !1643)
!1652 = !DILocation(line: 1350, column: 1, scope: !175)
!1653 = distinct !DISubprogram(name: "pts_ieee754_cos", scope: !3, file: !3, line: 1382, type: !4, scopeLine: 1382, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1654)
!1654 = !{!1655, !1656, !1658, !1659, !1660, !1661}
!1655 = !DILocalVariable(name: "x", arg: 1, scope: !1653, file: !3, line: 1382, type: !6)
!1656 = !DILocalVariable(name: "y", scope: !1653, file: !3, line: 1383, type: !1657)
!1657 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 128, elements: !237)
!1658 = !DILocalVariable(name: "z", scope: !1653, file: !3, line: 1383, type: !6)
!1659 = !DILocalVariable(name: "n", scope: !1653, file: !3, line: 1384, type: !21)
!1660 = !DILocalVariable(name: "ix", scope: !1653, file: !3, line: 1384, type: !21)
!1661 = !DILocalVariable(name: "bits", scope: !1662, file: !3, line: 1387, type: !18)
!1662 = distinct !DILexicalBlock(scope: !1653, file: !3, line: 1387, column: 3)
!1663 = distinct !DIAssignID()
!1664 = !DILocation(line: 0, scope: !1653)
!1665 = !DILocation(line: 1383, column: 3, scope: !1653)
!1666 = !DILocation(line: 0, scope: !880, inlinedAt: !1667)
!1667 = distinct !DILocation(line: 1387, column: 3, scope: !1662)
!1668 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1667)
!1669 = !DILocation(line: 0, scope: !1662)
!1670 = !DILocation(line: 1387, column: 3, scope: !1662)
!1671 = !DILocation(line: 1390, column: 6, scope: !1653)
!1672 = !DILocation(line: 1391, column: 10, scope: !1673)
!1673 = distinct !DILexicalBlock(scope: !1653, file: !3, line: 1391, column: 7)
!1674 = !DILocation(line: 1391, column: 7, scope: !1653)
!1675 = !DILocation(line: 0, scope: !612, inlinedAt: !1676)
!1676 = distinct !DILocation(line: 1392, column: 12, scope: !1677)
!1677 = distinct !DILexicalBlock(scope: !1673, file: !3, line: 1391, column: 25)
!1678 = !DILocation(line: 0, scope: !880, inlinedAt: !1679)
!1679 = distinct !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !1676)
!1680 = !DILocation(line: 0, scope: !623, inlinedAt: !1676)
!1681 = !DILocation(line: 350, column: 10, scope: !1682, inlinedAt: !1676)
!1682 = distinct !DILexicalBlock(scope: !612, file: !3, line: 350, column: 7)
!1683 = !DILocation(line: 350, column: 7, scope: !612, inlinedAt: !1676)
!1684 = !DILocation(line: 353, column: 9, scope: !612, inlinedAt: !1676)
!1685 = !DILocation(line: 354, column: 55, scope: !612, inlinedAt: !1676)
!1686 = !DILocation(line: 354, column: 45, scope: !612, inlinedAt: !1676)
!1687 = !DILocation(line: 354, column: 35, scope: !612, inlinedAt: !1676)
!1688 = !DILocation(line: 354, column: 25, scope: !612, inlinedAt: !1676)
!1689 = !DILocation(line: 354, column: 15, scope: !612, inlinedAt: !1676)
!1690 = !DILocation(line: 354, column: 9, scope: !612, inlinedAt: !1676)
!1691 = !DILocation(line: 355, column: 10, scope: !629, inlinedAt: !1676)
!1692 = !DILocation(line: 355, column: 7, scope: !612, inlinedAt: !1676)
!1693 = !DILocation(line: 356, column: 36, scope: !1694, inlinedAt: !1676)
!1694 = distinct !DILexicalBlock(scope: !629, file: !3, line: 355, column: 24)
!1695 = !DILocation(line: 356, column: 27, scope: !1694, inlinedAt: !1676)
!1696 = !DILocation(line: 356, column: 16, scope: !1694, inlinedAt: !1676)
!1697 = !DILocation(line: 356, column: 5, scope: !1694, inlinedAt: !1676)
!1698 = !DILocation(line: 358, column: 12, scope: !627, inlinedAt: !1676)
!1699 = !DILocation(line: 358, column: 9, scope: !628, inlinedAt: !1676)
!1700 = !DILocation(line: 363, column: 18, scope: !628, inlinedAt: !1676)
!1701 = !DILocation(line: 364, column: 13, scope: !628, inlinedAt: !1676)
!1702 = !DILocation(line: 365, column: 29, scope: !628, inlinedAt: !1676)
!1703 = !DILocation(line: 365, column: 14, scope: !628, inlinedAt: !1676)
!1704 = !DILocation(line: 365, column: 5, scope: !628, inlinedAt: !1676)
!1705 = !DILocation(line: 1393, column: 17, scope: !1706)
!1706 = distinct !DILexicalBlock(scope: !1673, file: !3, line: 1393, column: 14)
!1707 = !DILocation(line: 1393, column: 14, scope: !1673)
!1708 = !DILocation(line: 1395, column: 14, scope: !1709)
!1709 = distinct !DILexicalBlock(scope: !1706, file: !3, line: 1393, column: 32)
!1710 = !DILocation(line: 1395, column: 5, scope: !1709)
!1711 = !DILocation(line: 1398, column: 9, scope: !1712)
!1712 = distinct !DILexicalBlock(scope: !1706, file: !3, line: 1396, column: 10)
!1713 = !DILocation(line: 1399, column: 15, scope: !1712)
!1714 = !DILocation(line: 0, scope: !1715)
!1715 = distinct !DILexicalBlock(scope: !1712, file: !3, line: 1399, column: 20)
!1716 = !DILocation(line: 1399, column: 5, scope: !1712)
!1717 = !DILocation(line: 1401, column: 35, scope: !1715)
!1718 = !DILocation(line: 0, scope: !612, inlinedAt: !1719)
!1719 = distinct !DILocation(line: 1401, column: 16, scope: !1715)
!1720 = !DILocation(line: 0, scope: !880, inlinedAt: !1721)
!1721 = distinct !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !1719)
!1722 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1721)
!1723 = !DILocation(line: 0, scope: !623, inlinedAt: !1719)
!1724 = !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !1719)
!1725 = !DILocation(line: 349, column: 6, scope: !612, inlinedAt: !1719)
!1726 = !DILocation(line: 350, column: 10, scope: !1682, inlinedAt: !1719)
!1727 = !DILocation(line: 350, column: 7, scope: !612, inlinedAt: !1719)
!1728 = !DILocation(line: 353, column: 9, scope: !612, inlinedAt: !1719)
!1729 = !DILocation(line: 354, column: 55, scope: !612, inlinedAt: !1719)
!1730 = !DILocation(line: 354, column: 45, scope: !612, inlinedAt: !1719)
!1731 = !DILocation(line: 354, column: 35, scope: !612, inlinedAt: !1719)
!1732 = !DILocation(line: 354, column: 25, scope: !612, inlinedAt: !1719)
!1733 = !DILocation(line: 354, column: 15, scope: !612, inlinedAt: !1719)
!1734 = !DILocation(line: 354, column: 9, scope: !612, inlinedAt: !1719)
!1735 = !DILocation(line: 355, column: 10, scope: !629, inlinedAt: !1719)
!1736 = !DILocation(line: 355, column: 7, scope: !612, inlinedAt: !1719)
!1737 = !DILocation(line: 356, column: 36, scope: !1694, inlinedAt: !1719)
!1738 = !DILocation(line: 356, column: 27, scope: !1694, inlinedAt: !1719)
!1739 = !DILocation(line: 356, column: 16, scope: !1694, inlinedAt: !1719)
!1740 = !DILocation(line: 356, column: 5, scope: !1694, inlinedAt: !1719)
!1741 = !DILocation(line: 358, column: 12, scope: !627, inlinedAt: !1719)
!1742 = !DILocation(line: 358, column: 9, scope: !628, inlinedAt: !1719)
!1743 = !DILocation(line: 363, column: 18, scope: !628, inlinedAt: !1719)
!1744 = !DILocation(line: 364, column: 13, scope: !628, inlinedAt: !1719)
!1745 = !DILocation(line: 365, column: 29, scope: !628, inlinedAt: !1719)
!1746 = !DILocation(line: 365, column: 14, scope: !628, inlinedAt: !1719)
!1747 = !DILocation(line: 365, column: 5, scope: !628, inlinedAt: !1719)
!1748 = !DILocation(line: 0, scope: !770, inlinedAt: !1749)
!1749 = distinct !DILocation(line: 1403, column: 17, scope: !1715)
!1750 = !DILocation(line: 0, scope: !880, inlinedAt: !1751)
!1751 = distinct !DILocation(line: 716, column: 3, scope: !782, inlinedAt: !1749)
!1752 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1751)
!1753 = !DILocation(line: 0, scope: !782, inlinedAt: !1749)
!1754 = !DILocation(line: 718, column: 10, scope: !1755, inlinedAt: !1749)
!1755 = distinct !DILexicalBlock(scope: !770, file: !3, line: 718, column: 7)
!1756 = !DILocation(line: 718, column: 7, scope: !770, inlinedAt: !1749)
!1757 = !DILocation(line: 1403, column: 36, scope: !1715)
!1758 = !DILocation(line: 721, column: 9, scope: !770, inlinedAt: !1749)
!1759 = !DILocation(line: 723, column: 40, scope: !770, inlinedAt: !1749)
!1760 = !DILocation(line: 723, column: 30, scope: !770, inlinedAt: !1749)
!1761 = !DILocation(line: 723, column: 20, scope: !770, inlinedAt: !1749)
!1762 = !DILocation(line: 723, column: 10, scope: !770, inlinedAt: !1749)
!1763 = !DILocation(line: 727, column: 32, scope: !1764, inlinedAt: !1749)
!1764 = distinct !DILexicalBlock(scope: !1765, file: !3, line: 726, column: 10)
!1765 = distinct !DILexicalBlock(scope: !770, file: !3, line: 724, column: 7)
!1766 = !DILocation(line: 727, column: 41, scope: !1764, inlinedAt: !1749)
!1767 = !DILocation(line: 727, column: 46, scope: !1764, inlinedAt: !1749)
!1768 = !DILocation(line: 727, column: 14, scope: !1764, inlinedAt: !1749)
!1769 = !DILocation(line: 727, column: 5, scope: !1764, inlinedAt: !1749)
!1770 = !DILocation(line: 1403, column: 16, scope: !1715)
!1771 = !DILocation(line: 1403, column: 9, scope: !1715)
!1772 = !DILocation(line: 1405, column: 36, scope: !1715)
!1773 = !DILocation(line: 0, scope: !612, inlinedAt: !1774)
!1774 = distinct !DILocation(line: 1405, column: 17, scope: !1715)
!1775 = !DILocation(line: 0, scope: !880, inlinedAt: !1776)
!1776 = distinct !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !1774)
!1777 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1776)
!1778 = !DILocation(line: 0, scope: !623, inlinedAt: !1774)
!1779 = !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !1774)
!1780 = !DILocation(line: 349, column: 6, scope: !612, inlinedAt: !1774)
!1781 = !DILocation(line: 350, column: 10, scope: !1682, inlinedAt: !1774)
!1782 = !DILocation(line: 350, column: 7, scope: !612, inlinedAt: !1774)
!1783 = !DILocation(line: 353, column: 9, scope: !612, inlinedAt: !1774)
!1784 = !DILocation(line: 354, column: 55, scope: !612, inlinedAt: !1774)
!1785 = !DILocation(line: 354, column: 45, scope: !612, inlinedAt: !1774)
!1786 = !DILocation(line: 354, column: 35, scope: !612, inlinedAt: !1774)
!1787 = !DILocation(line: 354, column: 25, scope: !612, inlinedAt: !1774)
!1788 = !DILocation(line: 354, column: 15, scope: !612, inlinedAt: !1774)
!1789 = !DILocation(line: 354, column: 9, scope: !612, inlinedAt: !1774)
!1790 = !DILocation(line: 355, column: 10, scope: !629, inlinedAt: !1774)
!1791 = !DILocation(line: 355, column: 7, scope: !612, inlinedAt: !1774)
!1792 = !DILocation(line: 356, column: 36, scope: !1694, inlinedAt: !1774)
!1793 = !DILocation(line: 356, column: 27, scope: !1694, inlinedAt: !1774)
!1794 = !DILocation(line: 356, column: 16, scope: !1694, inlinedAt: !1774)
!1795 = !DILocation(line: 356, column: 5, scope: !1694, inlinedAt: !1774)
!1796 = !DILocation(line: 358, column: 12, scope: !627, inlinedAt: !1774)
!1797 = !DILocation(line: 358, column: 9, scope: !628, inlinedAt: !1774)
!1798 = !DILocation(line: 363, column: 18, scope: !628, inlinedAt: !1774)
!1799 = !DILocation(line: 364, column: 13, scope: !628, inlinedAt: !1774)
!1800 = !DILocation(line: 365, column: 29, scope: !628, inlinedAt: !1774)
!1801 = !DILocation(line: 365, column: 14, scope: !628, inlinedAt: !1774)
!1802 = !DILocation(line: 365, column: 5, scope: !628, inlinedAt: !1774)
!1803 = !DILocation(line: 1405, column: 16, scope: !1715)
!1804 = !DILocation(line: 1405, column: 9, scope: !1715)
!1805 = !DILocation(line: 0, scope: !770, inlinedAt: !1806)
!1806 = distinct !DILocation(line: 1407, column: 16, scope: !1715)
!1807 = !DILocation(line: 0, scope: !880, inlinedAt: !1808)
!1808 = distinct !DILocation(line: 716, column: 3, scope: !782, inlinedAt: !1806)
!1809 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1808)
!1810 = !DILocation(line: 0, scope: !782, inlinedAt: !1806)
!1811 = !DILocation(line: 718, column: 10, scope: !1755, inlinedAt: !1806)
!1812 = !DILocation(line: 718, column: 7, scope: !770, inlinedAt: !1806)
!1813 = !DILocation(line: 1407, column: 35, scope: !1715)
!1814 = !DILocation(line: 721, column: 9, scope: !770, inlinedAt: !1806)
!1815 = !DILocation(line: 723, column: 40, scope: !770, inlinedAt: !1806)
!1816 = !DILocation(line: 723, column: 30, scope: !770, inlinedAt: !1806)
!1817 = !DILocation(line: 723, column: 20, scope: !770, inlinedAt: !1806)
!1818 = !DILocation(line: 723, column: 10, scope: !770, inlinedAt: !1806)
!1819 = !DILocation(line: 727, column: 32, scope: !1764, inlinedAt: !1806)
!1820 = !DILocation(line: 727, column: 41, scope: !1764, inlinedAt: !1806)
!1821 = !DILocation(line: 727, column: 46, scope: !1764, inlinedAt: !1806)
!1822 = !DILocation(line: 727, column: 14, scope: !1764, inlinedAt: !1806)
!1823 = !DILocation(line: 727, column: 5, scope: !1764, inlinedAt: !1806)
!1824 = !DILocation(line: 0, scope: !1673)
!1825 = !DILocation(line: 1410, column: 1, scope: !1653)
!1826 = distinct !DIAssignID()
!1827 = distinct !DIAssignID()
!1828 = distinct !DIAssignID()
!1829 = distinct !DIAssignID()
!1830 = distinct !DIAssignID()
!1831 = !DILocation(line: 0, scope: !644)
!1832 = !DILocation(line: 198, column: 3, scope: !644)
!1833 = !DILocation(line: 0, scope: !880, inlinedAt: !1834)
!1834 = distinct !DILocation(line: 203, column: 3, scope: !669)
!1835 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1834)
!1836 = !DILocation(line: 0, scope: !669)
!1837 = !DILocation(line: 203, column: 3, scope: !669)
!1838 = !DILocation(line: 204, column: 11, scope: !644)
!1839 = !DILocation(line: 205, column: 10, scope: !1840)
!1840 = distinct !DILexicalBlock(scope: !644, file: !3, line: 205, column: 7)
!1841 = !DILocation(line: 205, column: 7, scope: !644)
!1842 = !DILocation(line: 206, column: 10, scope: !1843)
!1843 = distinct !DILexicalBlock(scope: !1840, file: !3, line: 205, column: 25)
!1844 = !DILocation(line: 207, column: 5, scope: !1843)
!1845 = !DILocation(line: 207, column: 10, scope: !1843)
!1846 = !DILocation(line: 208, column: 5, scope: !1843)
!1847 = !DILocation(line: 210, column: 10, scope: !1848)
!1848 = distinct !DILexicalBlock(scope: !644, file: !3, line: 210, column: 7)
!1849 = !DILocation(line: 210, column: 7, scope: !644)
!1850 = !DILocation(line: 211, column: 12, scope: !1851)
!1851 = distinct !DILexicalBlock(scope: !1852, file: !3, line: 211, column: 9)
!1852 = distinct !DILexicalBlock(scope: !1848, file: !3, line: 210, column: 24)
!1853 = !DILocation(line: 0, scope: !1851)
!1854 = !DILocation(line: 211, column: 9, scope: !1852)
!1855 = !DILocation(line: 212, column: 13, scope: !1856)
!1856 = distinct !DILexicalBlock(scope: !1851, file: !3, line: 211, column: 17)
!1857 = !DILocation(line: 213, column: 11, scope: !1856)
!1858 = !DILocation(line: 214, column: 18, scope: !1859)
!1859 = distinct !DILexicalBlock(scope: !1860, file: !3, line: 213, column: 29)
!1860 = distinct !DILexicalBlock(scope: !1856, file: !3, line: 213, column: 11)
!1861 = !DILocation(line: 214, column: 14, scope: !1859)
!1862 = !DILocation(line: 215, column: 19, scope: !1859)
!1863 = !DILocation(line: 215, column: 27, scope: !1859)
!1864 = !DILocation(line: 215, column: 9, scope: !1859)
!1865 = !DILocation(line: 215, column: 14, scope: !1859)
!1866 = !DILocation(line: 216, column: 7, scope: !1859)
!1867 = !DILocation(line: 217, column: 11, scope: !1868)
!1868 = distinct !DILexicalBlock(scope: !1860, file: !3, line: 216, column: 14)
!1869 = !DILocation(line: 218, column: 18, scope: !1868)
!1870 = !DILocation(line: 218, column: 14, scope: !1868)
!1871 = !DILocation(line: 219, column: 19, scope: !1868)
!1872 = !DILocation(line: 219, column: 27, scope: !1868)
!1873 = !DILocation(line: 219, column: 9, scope: !1868)
!1874 = !DILocation(line: 219, column: 14, scope: !1868)
!1875 = !DILocation(line: 223, column: 13, scope: !1876)
!1876 = distinct !DILexicalBlock(scope: !1851, file: !3, line: 222, column: 12)
!1877 = !DILocation(line: 224, column: 11, scope: !1876)
!1878 = !DILocation(line: 225, column: 18, scope: !1879)
!1879 = distinct !DILexicalBlock(scope: !1880, file: !3, line: 224, column: 29)
!1880 = distinct !DILexicalBlock(scope: !1876, file: !3, line: 224, column: 11)
!1881 = !DILocation(line: 225, column: 14, scope: !1879)
!1882 = !DILocation(line: 226, column: 19, scope: !1879)
!1883 = !DILocation(line: 226, column: 27, scope: !1879)
!1884 = !DILocation(line: 226, column: 9, scope: !1879)
!1885 = !DILocation(line: 226, column: 14, scope: !1879)
!1886 = !DILocation(line: 227, column: 7, scope: !1879)
!1887 = !DILocation(line: 228, column: 11, scope: !1888)
!1888 = distinct !DILexicalBlock(scope: !1880, file: !3, line: 227, column: 14)
!1889 = !DILocation(line: 229, column: 18, scope: !1888)
!1890 = !DILocation(line: 229, column: 14, scope: !1888)
!1891 = !DILocation(line: 230, column: 19, scope: !1888)
!1892 = !DILocation(line: 230, column: 27, scope: !1888)
!1893 = !DILocation(line: 230, column: 9, scope: !1888)
!1894 = !DILocation(line: 230, column: 14, scope: !1888)
!1895 = !DILocation(line: 235, column: 10, scope: !674)
!1896 = !DILocation(line: 235, column: 7, scope: !644)
!1897 = !DILocation(line: 236, column: 9, scope: !673)
!1898 = !DILocation(line: 237, column: 31, scope: !673)
!1899 = !DILocation(line: 237, column: 9, scope: !673)
!1900 = !DILocation(line: 238, column: 10, scope: !673)
!1901 = !DILocation(line: 239, column: 11, scope: !673)
!1902 = !DILocation(line: 240, column: 12, scope: !673)
!1903 = !DILocation(line: 241, column: 11, scope: !672)
!1904 = !DILocation(line: 241, column: 16, scope: !672)
!1905 = !DILocation(line: 241, column: 36, scope: !672)
!1906 = !DILocation(line: 241, column: 25, scope: !672)
!1907 = !{!1908, !1908, i64 0}
!1908 = !{!"int", !1445, i64 0}
!1909 = !DILocation(line: 241, column: 22, scope: !672)
!1910 = !DILocation(line: 241, column: 9, scope: !673)
!1911 = !DILocation(line: 242, column: 16, scope: !1912)
!1912 = distinct !DILexicalBlock(scope: !672, file: !3, line: 241, column: 42)
!1913 = !DILocation(line: 243, column: 5, scope: !1912)
!1914 = !DILocation(line: 246, column: 16, scope: !671)
!1915 = !DILocation(line: 246, column: 12, scope: !671)
!1916 = !DILocation(line: 0, scope: !880, inlinedAt: !1917)
!1917 = distinct !DILocation(line: 247, column: 7, scope: !676)
!1918 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1917)
!1919 = !DILocation(line: 0, scope: !676)
!1920 = !DILocation(line: 0, scope: !671)
!1921 = !DILocation(line: 248, column: 22, scope: !671)
!1922 = !DILocation(line: 248, column: 29, scope: !671)
!1923 = !DILocation(line: 248, column: 13, scope: !671)
!1924 = !DILocation(line: 249, column: 13, scope: !680)
!1925 = !DILocation(line: 249, column: 11, scope: !671)
!1926 = !DILocation(line: 251, column: 16, scope: !679)
!1927 = !DILocation(line: 252, column: 15, scope: !679)
!1928 = !DILocation(line: 253, column: 32, scope: !679)
!1929 = !DILocation(line: 253, column: 37, scope: !679)
!1930 = !DILocation(line: 253, column: 26, scope: !679)
!1931 = !DILocation(line: 254, column: 18, scope: !679)
!1932 = !DILocation(line: 254, column: 14, scope: !679)
!1933 = !DILocation(line: 0, scope: !880, inlinedAt: !1934)
!1934 = distinct !DILocation(line: 255, column: 9, scope: !678)
!1935 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !1934)
!1936 = !DILocation(line: 0, scope: !678)
!1937 = !DILocation(line: 256, column: 24, scope: !679)
!1938 = !DILocation(line: 256, column: 31, scope: !679)
!1939 = !DILocation(line: 256, column: 15, scope: !679)
!1940 = !DILocation(line: 257, column: 15, scope: !1941)
!1941 = distinct !DILexicalBlock(scope: !679, file: !3, line: 257, column: 13)
!1942 = !DILocation(line: 257, column: 13, scope: !679)
!1943 = !DILocation(line: 259, column: 18, scope: !1944)
!1944 = distinct !DILexicalBlock(scope: !1941, file: !3, line: 257, column: 21)
!1945 = !DILocation(line: 260, column: 17, scope: !1944)
!1946 = !DILocation(line: 261, column: 34, scope: !1944)
!1947 = !DILocation(line: 261, column: 39, scope: !1944)
!1948 = !DILocation(line: 261, column: 28, scope: !1944)
!1949 = !DILocation(line: 262, column: 20, scope: !1944)
!1950 = !DILocation(line: 263, column: 9, scope: !1944)
!1951 = !DILocation(line: 0, scope: !672)
!1952 = !DILocation(line: 266, column: 15, scope: !673)
!1953 = !DILocation(line: 266, column: 17, scope: !673)
!1954 = !DILocation(line: 0, scope: !673)
!1955 = !DILocation(line: 266, column: 23, scope: !673)
!1956 = !DILocation(line: 266, column: 5, scope: !673)
!1957 = !DILocation(line: 266, column: 10, scope: !673)
!1958 = !DILocation(line: 267, column: 12, scope: !1959)
!1959 = distinct !DILexicalBlock(scope: !673, file: !3, line: 267, column: 9)
!1960 = !DILocation(line: 267, column: 9, scope: !673)
!1961 = !DILocation(line: 268, column: 14, scope: !1962)
!1962 = distinct !DILexicalBlock(scope: !1959, file: !3, line: 267, column: 17)
!1963 = !DILocation(line: 268, column: 12, scope: !1962)
!1964 = !DILocation(line: 269, column: 14, scope: !1962)
!1965 = !DILocation(line: 269, column: 12, scope: !1962)
!1966 = !DILocation(line: 270, column: 14, scope: !1962)
!1967 = !DILocation(line: 270, column: 7, scope: !1962)
!1968 = !DILocation(line: 278, column: 10, scope: !1969)
!1969 = distinct !DILexicalBlock(scope: !644, file: !3, line: 278, column: 7)
!1970 = !DILocation(line: 278, column: 7, scope: !644)
!1971 = !DILocation(line: 279, column: 21, scope: !1972)
!1972 = distinct !DILexicalBlock(scope: !1969, file: !3, line: 278, column: 25)
!1973 = !DILocation(line: 279, column: 12, scope: !1972)
!1974 = !DILocation(line: 279, column: 17, scope: !1972)
!1975 = !DILocation(line: 279, column: 10, scope: !1972)
!1976 = !DILocation(line: 280, column: 5, scope: !1972)
!1977 = !DILocation(line: 0, scope: !880, inlinedAt: !1978)
!1978 = distinct !DILocation(line: 283, column: 3, scope: !682)
!1979 = !DILocation(line: 0, scope: !880, inlinedAt: !1980)
!1980 = distinct !DILocation(line: 284, column: 3, scope: !684)
!1981 = !DILocation(line: 0, scope: !684)
!1982 = !DILocation(line: 284, column: 3, scope: !684)
!1983 = !DILocation(line: 0, scope: !954, inlinedAt: !1984)
!1984 = distinct !DILocation(line: 284, column: 3, scope: !684)
!1985 = !DILocation(line: 285, column: 19, scope: !644)
!1986 = !DILocation(line: 0, scope: !880, inlinedAt: !1987)
!1987 = distinct !DILocation(line: 286, column: 3, scope: !686)
!1988 = !DILocation(line: 0, scope: !686)
!1989 = !DILocation(line: 286, column: 3, scope: !686)
!1990 = !DILocation(line: 0, scope: !954, inlinedAt: !1991)
!1991 = distinct !DILocation(line: 286, column: 3, scope: !686)
!1992 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !1991)
!1993 = !DILocation(line: 288, column: 22, scope: !1994)
!1994 = distinct !DILexicalBlock(scope: !1995, file: !3, line: 287, column: 27)
!1995 = distinct !DILexicalBlock(scope: !1996, file: !3, line: 287, column: 3)
!1996 = distinct !DILexicalBlock(scope: !644, file: !3, line: 287, column: 3)
!1997 = !DILocation(line: 288, column: 13, scope: !1994)
!1998 = !DILocation(line: 288, column: 11, scope: !1994)
!1999 = !DILocation(line: 289, column: 12, scope: !1994)
!2000 = !DILocation(line: 289, column: 21, scope: !1994)
!2001 = !DILocation(line: 288, column: 5, scope: !1994)
!2002 = !DILocation(line: 291, column: 3, scope: !644)
!2003 = !DILocation(line: 291, column: 9, scope: !644)
!2004 = distinct !DIAssignID()
!2005 = !DILocation(line: 293, column: 3, scope: !644)
!2006 = !DILocation(line: 293, column: 16, scope: !644)
!2007 = !DILocation(line: 293, column: 10, scope: !644)
!2008 = !DILocation(line: 293, column: 21, scope: !644)
!2009 = distinct !{!2009, !2005, !2010, !2011}
!2010 = !DILocation(line: 293, column: 32, scope: !644)
!2011 = !{!"llvm.loop.mustprogress"}
!2012 = !DILocation(line: 501, column: 3, scope: !718, inlinedAt: !2013)
!2013 = distinct !DILocation(line: 294, column: 7, scope: !644)
!2014 = !DILocation(line: 0, scope: !718, inlinedAt: !2013)
!2015 = !DILocation(line: 502, column: 3, scope: !718, inlinedAt: !2013)
!2016 = !DILocation(line: 510, column: 12, scope: !718, inlinedAt: !2013)
!2017 = !DILocation(line: 510, column: 17, scope: !718, inlinedAt: !2013)
!2018 = !DILocation(line: 512, column: 16, scope: !718, inlinedAt: !2013)
!2019 = !DILocation(line: 512, column: 11, scope: !718, inlinedAt: !2013)
!2020 = !DILocation(line: 517, column: 17, scope: !2021, inlinedAt: !2013)
!2021 = distinct !DILexicalBlock(scope: !2022, file: !3, line: 517, column: 3)
!2022 = distinct !DILexicalBlock(scope: !718, file: !3, line: 517, column: 3)
!2023 = !DILocation(line: 517, column: 3, scope: !2022, inlinedAt: !2013)
!2024 = !DILocation(line: 516, column: 10, scope: !718, inlinedAt: !2013)
!2025 = !DILocation(line: 515, column: 10, scope: !718, inlinedAt: !2013)
!2026 = !DILocation(line: 523, column: 5, scope: !2027, inlinedAt: !2013)
!2027 = distinct !DILexicalBlock(scope: !2028, file: !3, line: 523, column: 5)
!2028 = distinct !DILexicalBlock(scope: !2029, file: !3, line: 522, column: 29)
!2029 = distinct !DILexicalBlock(scope: !2030, file: !3, line: 522, column: 3)
!2030 = distinct !DILexicalBlock(scope: !718, file: !3, line: 522, column: 3)
!2031 = !DILocation(line: 518, column: 15, scope: !2032, inlinedAt: !2013)
!2032 = distinct !DILexicalBlock(scope: !2021, file: !3, line: 517, column: 33)
!2033 = !DILocation(line: 518, column: 12, scope: !2032, inlinedAt: !2013)
!2034 = !DILocation(line: 518, column: 38, scope: !2032, inlinedAt: !2013)
!2035 = !DILocation(line: 518, column: 29, scope: !2032, inlinedAt: !2013)
!2036 = !DILocation(line: 518, column: 5, scope: !2032, inlinedAt: !2013)
!2037 = !DILocation(line: 518, column: 10, scope: !2032, inlinedAt: !2013)
!2038 = !DILocation(line: 517, column: 24, scope: !2021, inlinedAt: !2013)
!2039 = !DILocation(line: 517, column: 29, scope: !2021, inlinedAt: !2013)
!2040 = distinct !{!2040, !2023, !2041, !2011}
!2041 = !DILocation(line: 519, column: 3, scope: !2022, inlinedAt: !2013)
!2042 = !DILocation(line: 523, column: 29, scope: !2043, inlinedAt: !2013)
!2043 = distinct !DILexicalBlock(scope: !2027, file: !3, line: 523, column: 5)
!2044 = !DILocation(line: 523, column: 37, scope: !2043, inlinedAt: !2013)
!2045 = !DILocation(line: 523, column: 47, scope: !2043, inlinedAt: !2013)
!2046 = !DILocation(line: 523, column: 63, scope: !2043, inlinedAt: !2013)
!2047 = !DILocation(line: 523, column: 54, scope: !2043, inlinedAt: !2013)
!2048 = distinct !{!2048, !2026, !2049, !2011, !2050, !2051}
!2049 = !DILocation(line: 523, column: 66, scope: !2027, inlinedAt: !2013)
!2050 = !{!"llvm.loop.isvectorized", i32 1}
!2051 = !{!"llvm.loop.unroll.runtime.disable"}
!2052 = !DILocation(line: 523, column: 44, scope: !2043, inlinedAt: !2013)
!2053 = distinct !{!2053, !2026, !2049, !2011, !2050}
!2054 = !DILocation(line: 524, column: 10, scope: !2028, inlinedAt: !2013)
!2055 = distinct !{!2055, !2026, !2049, !2011, !2050, !2051}
!2056 = distinct !{!2056, !2026, !2049, !2011, !2050}
!2057 = !DILocation(line: 524, column: 5, scope: !2028, inlinedAt: !2013)
!2058 = distinct !{!2058, !2026, !2049, !2011, !2050, !2051}
!2059 = distinct !{!2059, !2026, !2049, !2011, !2050}
!2060 = distinct !{!2060, !2026, !2049, !2011, !2050, !2051}
!2061 = distinct !{!2061, !2026, !2049, !2011, !2050}
!2062 = distinct !{!2062, !2026, !2049, !2011, !2050, !2051}
!2063 = distinct !{!2063, !2026, !2049, !2011, !2050}
!2064 = !DILocation(line: 523, scope: !2027, inlinedAt: !2013)
!2065 = !DILocation(line: 530, column: 8, scope: !2066, inlinedAt: !2013)
!2066 = distinct !DILexicalBlock(scope: !718, file: !3, line: 530, column: 3)
!2067 = !DILocation(line: 530, column: 27, scope: !2066, inlinedAt: !2013)
!2068 = !DILocation(line: 592, column: 7, scope: !2069, inlinedAt: !2013)
!2069 = distinct !DILexicalBlock(scope: !2070, file: !3, line: 592, column: 7)
!2070 = distinct !DILexicalBlock(scope: !2071, file: !3, line: 587, column: 17)
!2071 = distinct !DILexicalBlock(scope: !2072, file: !3, line: 587, column: 9)
!2072 = distinct !DILexicalBlock(scope: !2073, file: !3, line: 584, column: 18)
!2073 = distinct !DILexicalBlock(scope: !718, file: !3, line: 584, column: 7)
!2074 = distinct !{!2074, !2068, !2075, !2011}
!2075 = !DILocation(line: 596, column: 7, scope: !2069, inlinedAt: !2013)
!2076 = !DILocation(line: 528, column: 1, scope: !718, inlinedAt: !2013)
!2077 = !DILocation(line: 530, column: 3, scope: !2066, inlinedAt: !2013)
!2078 = !DILocation(line: 531, column: 36, scope: !2079, inlinedAt: !2013)
!2079 = distinct !DILexicalBlock(scope: !2080, file: !3, line: 530, column: 51)
!2080 = distinct !DILexicalBlock(scope: !2066, file: !3, line: 530, column: 3)
!2081 = !DILocation(line: 531, column: 19, scope: !2079, inlinedAt: !2013)
!2082 = !DILocation(line: 531, column: 10, scope: !2079, inlinedAt: !2013)
!2083 = !DILocation(line: 532, column: 25, scope: !2079, inlinedAt: !2013)
!2084 = !DILocation(line: 532, column: 13, scope: !2079, inlinedAt: !2013)
!2085 = !DILocation(line: 532, column: 5, scope: !2079, inlinedAt: !2013)
!2086 = !DILocation(line: 532, column: 11, scope: !2079, inlinedAt: !2013)
!2087 = !DILocation(line: 533, column: 13, scope: !2079, inlinedAt: !2013)
!2088 = !DILocation(line: 533, column: 9, scope: !2079, inlinedAt: !2013)
!2089 = !DILocation(line: 533, column: 18, scope: !2079, inlinedAt: !2013)
!2090 = !DILocation(line: 530, column: 42, scope: !2080, inlinedAt: !2013)
!2091 = !DILocation(line: 530, column: 36, scope: !2080, inlinedAt: !2013)
!2092 = distinct !{!2092, !2077, !2093, !2011}
!2093 = !DILocation(line: 534, column: 3, scope: !2066, inlinedAt: !2013)
!2094 = !DILocation(line: 537, column: 7, scope: !718, inlinedAt: !2013)
!2095 = !DILocation(line: 538, column: 22, scope: !718, inlinedAt: !2013)
!2096 = !DILocation(line: 538, column: 14, scope: !718, inlinedAt: !2013)
!2097 = !DILocation(line: 538, column: 5, scope: !718, inlinedAt: !2013)
!2098 = !DILocation(line: 539, column: 7, scope: !718, inlinedAt: !2013)
!2099 = !DILocation(line: 540, column: 8, scope: !718, inlinedAt: !2013)
!2100 = !DILocation(line: 540, column: 5, scope: !718, inlinedAt: !2013)
!2101 = !DILocation(line: 542, column: 7, scope: !718, inlinedAt: !2013)
!2102 = !DILocation(line: 543, column: 16, scope: !2103, inlinedAt: !2013)
!2103 = distinct !DILexicalBlock(scope: !2104, file: !3, line: 542, column: 15)
!2104 = distinct !DILexicalBlock(scope: !718, file: !3, line: 542, column: 7)
!2105 = !DILocation(line: 543, column: 10, scope: !2103, inlinedAt: !2013)
!2106 = !DILocation(line: 543, column: 21, scope: !2103, inlinedAt: !2013)
!2107 = !DILocation(line: 544, column: 7, scope: !2103, inlinedAt: !2013)
!2108 = !DILocation(line: 545, column: 21, scope: !2103, inlinedAt: !2013)
!2109 = !DILocation(line: 545, column: 16, scope: !2103, inlinedAt: !2013)
!2110 = !DILocation(line: 546, column: 21, scope: !2103, inlinedAt: !2013)
!2111 = !DILocation(line: 547, column: 3, scope: !2103, inlinedAt: !2013)
!2112 = !DILocation(line: 547, column: 14, scope: !2104, inlinedAt: !2013)
!2113 = !DILocation(line: 548, column: 16, scope: !2114, inlinedAt: !2013)
!2114 = distinct !DILexicalBlock(scope: !2115, file: !3, line: 547, column: 23)
!2115 = distinct !DILexicalBlock(scope: !2104, file: !3, line: 547, column: 14)
!2116 = !DILocation(line: 548, column: 10, scope: !2114, inlinedAt: !2013)
!2117 = !DILocation(line: 548, column: 21, scope: !2114, inlinedAt: !2013)
!2118 = !DILocation(line: 549, column: 3, scope: !2114, inlinedAt: !2013)
!2119 = !DILocation(line: 549, column: 16, scope: !2120, inlinedAt: !2013)
!2120 = distinct !DILexicalBlock(scope: !2115, file: !3, line: 549, column: 14)
!2121 = !DILocation(line: 549, column: 14, scope: !2115, inlinedAt: !2013)
!2122 = !DILocation(line: 553, column: 10, scope: !2123, inlinedAt: !2013)
!2123 = distinct !DILexicalBlock(scope: !718, file: !3, line: 553, column: 7)
!2124 = !DILocation(line: 553, column: 7, scope: !718, inlinedAt: !2013)
!2125 = !DILocation(line: 556, column: 5, scope: !2126, inlinedAt: !2013)
!2126 = distinct !DILexicalBlock(scope: !2127, file: !3, line: 556, column: 5)
!2127 = distinct !DILexicalBlock(scope: !2123, file: !3, line: 553, column: 15)
!2128 = !DILocation(line: 557, column: 11, scope: !2129, inlinedAt: !2013)
!2129 = distinct !DILexicalBlock(scope: !2130, file: !3, line: 556, column: 30)
!2130 = distinct !DILexicalBlock(scope: !2126, file: !3, line: 556, column: 5)
!2131 = !DILocation(line: 558, column: 17, scope: !2132, inlinedAt: !2013)
!2132 = distinct !DILexicalBlock(scope: !2129, file: !3, line: 558, column: 11)
!2133 = !DILocation(line: 558, column: 11, scope: !2129, inlinedAt: !2013)
!2134 = !DILocation(line: 559, column: 15, scope: !2135, inlinedAt: !2013)
!2135 = distinct !DILexicalBlock(scope: !2136, file: !3, line: 559, column: 13)
!2136 = distinct !DILexicalBlock(scope: !2132, file: !3, line: 558, column: 23)
!2137 = !DILocation(line: 559, column: 13, scope: !2136, inlinedAt: !2013)
!2138 = !DILocation(line: 0, scope: !2132, inlinedAt: !2013)
!2139 = !DILocation(line: 556, column: 26, scope: !2130, inlinedAt: !2013)
!2140 = !DILocation(line: 0, scope: !2127, inlinedAt: !2013)
!2141 = !DILocation(line: 556, column: 19, scope: !2130, inlinedAt: !2013)
!2142 = distinct !{!2142, !2125, !2143, !2011}
!2143 = !DILocation(line: 566, column: 5, scope: !2126, inlinedAt: !2013)
!2144 = !DILocation(line: 554, column: 7, scope: !2127, inlinedAt: !2013)
!2145 = !DILocation(line: 567, column: 9, scope: !2127, inlinedAt: !2013)
!2146 = !DILocation(line: 568, column: 7, scope: !2147, inlinedAt: !2013)
!2147 = distinct !DILexicalBlock(scope: !2148, file: !3, line: 567, column: 17)
!2148 = distinct !DILexicalBlock(scope: !2127, file: !3, line: 567, column: 9)
!2149 = !DILocation(line: 574, column: 11, scope: !2150, inlinedAt: !2013)
!2150 = distinct !DILexicalBlock(scope: !2147, file: !3, line: 568, column: 19)
!2151 = !DILocation(line: 0, scope: !2150, inlinedAt: !2013)
!2152 = !DILocation(line: 577, column: 12, scope: !2153, inlinedAt: !2013)
!2153 = distinct !DILexicalBlock(scope: !2127, file: !3, line: 577, column: 9)
!2154 = !DILocation(line: 577, column: 9, scope: !2127, inlinedAt: !2013)
!2155 = !DILocation(line: 578, column: 15, scope: !2156, inlinedAt: !2013)
!2156 = distinct !DILexicalBlock(scope: !2153, file: !3, line: 577, column: 18)
!2157 = !DILocation(line: 579, column: 11, scope: !2156, inlinedAt: !2013)
!2158 = !DILocation(line: 579, column: 28, scope: !2159, inlinedAt: !2013)
!2159 = distinct !DILexicalBlock(scope: !2156, file: !3, line: 579, column: 11)
!2160 = !DILocation(line: 579, column: 25, scope: !2159, inlinedAt: !2013)
!2161 = !DILocation(line: 579, column: 23, scope: !2159, inlinedAt: !2013)
!2162 = !DILocation(line: 584, column: 9, scope: !2073, inlinedAt: !2013)
!2163 = !DILocation(line: 584, column: 7, scope: !718, inlinedAt: !2013)
!2164 = !DILocation(line: 586, column: 24, scope: !2165, inlinedAt: !2013)
!2165 = distinct !DILexicalBlock(scope: !2166, file: !3, line: 586, column: 5)
!2166 = distinct !DILexicalBlock(scope: !2072, file: !3, line: 586, column: 5)
!2167 = !DILocation(line: 586, column: 5, scope: !2166, inlinedAt: !2013)
!2168 = !DILocation(line: 586, scope: !2166, inlinedAt: !2013)
!2169 = !DILocation(line: 586, column: 41, scope: !2165, inlinedAt: !2013)
!2170 = !DILocation(line: 586, column: 38, scope: !2165, inlinedAt: !2013)
!2171 = distinct !{!2171, !2167, !2172, !2011, !2050, !2051}
!2172 = !DILocation(line: 586, column: 45, scope: !2166, inlinedAt: !2013)
!2173 = distinct !{!2173, !2167, !2172, !2011, !2051, !2050}
!2174 = !DILocation(line: 587, column: 11, scope: !2071, inlinedAt: !2013)
!2175 = !DILocation(line: 587, column: 9, scope: !2072, inlinedAt: !2013)
!2176 = !DILocation(line: 588, column: 30, scope: !2177, inlinedAt: !2013)
!2177 = distinct !DILexicalBlock(scope: !2178, file: !3, line: 588, column: 7)
!2178 = distinct !DILexicalBlock(scope: !2070, file: !3, line: 588, column: 7)
!2179 = !DILocation(line: 588, column: 41, scope: !2177, inlinedAt: !2013)
!2180 = !DILocation(line: 588, column: 7, scope: !2178, inlinedAt: !2013)
!2181 = !DILocation(line: 588, scope: !2178, inlinedAt: !2013)
!2182 = !DILocation(line: 592, column: 26, scope: !2183, inlinedAt: !2013)
!2183 = distinct !DILexicalBlock(scope: !2069, file: !3, line: 592, column: 7)
!2184 = !DILocation(line: 592, scope: !2069, inlinedAt: !2013)
!2185 = !DILocation(line: 593, column: 21, scope: !2186, inlinedAt: !2013)
!2186 = distinct !DILexicalBlock(scope: !2183, file: !3, line: 592, column: 42)
!2187 = !DILocation(line: 593, column: 14, scope: !2186, inlinedAt: !2013)
!2188 = !DILocation(line: 593, column: 9, scope: !2186, inlinedAt: !2013)
!2189 = !DILocation(line: 593, column: 19, scope: !2186, inlinedAt: !2013)
!2190 = !DILocation(line: 594, column: 9, scope: !2191, inlinedAt: !2013)
!2191 = distinct !DILexicalBlock(scope: !2186, file: !3, line: 594, column: 9)
!2192 = !DILocation(line: 594, column: 41, scope: !2193, inlinedAt: !2013)
!2193 = distinct !DILexicalBlock(scope: !2191, file: !3, line: 594, column: 9)
!2194 = !DILocation(line: 594, column: 51, scope: !2193, inlinedAt: !2013)
!2195 = !DILocation(line: 594, column: 67, scope: !2193, inlinedAt: !2013)
!2196 = !DILocation(line: 594, column: 58, scope: !2193, inlinedAt: !2013)
!2197 = distinct !{!2197, !2190, !2198, !2011, !2050, !2051}
!2198 = !DILocation(line: 594, column: 70, scope: !2191, inlinedAt: !2013)
!2199 = !DILocation(line: 594, column: 48, scope: !2193, inlinedAt: !2013)
!2200 = !DILocation(line: 594, column: 33, scope: !2193, inlinedAt: !2013)
!2201 = distinct !{!2201, !2190, !2198, !2011, !2051, !2050}
!2202 = !DILocation(line: 594, scope: !2191, inlinedAt: !2013)
!2203 = !DILocation(line: 595, column: 9, scope: !2186, inlinedAt: !2013)
!2204 = !DILocation(line: 595, column: 14, scope: !2186, inlinedAt: !2013)
!2205 = distinct !{!2205, !2068, !2075, !2011}
!2206 = !DILocation(line: 0, scope: !2207, inlinedAt: !2013)
!2207 = distinct !DILexicalBlock(scope: !2208, file: !3, line: 603, column: 17)
!2208 = distinct !DILexicalBlock(scope: !718, file: !3, line: 603, column: 7)
!2209 = !DILocation(line: 606, column: 12, scope: !2207, inlinedAt: !2013)
!2210 = !DILocation(line: 606, column: 19, scope: !2207, inlinedAt: !2013)
!2211 = !DILocation(line: 606, column: 5, scope: !2207, inlinedAt: !2013)
!2212 = distinct !{!2212, !2211, !2213, !2011}
!2213 = !DILocation(line: 609, column: 5, scope: !2207, inlinedAt: !2013)
!2214 = !DILocation(line: 611, column: 19, scope: !2215, inlinedAt: !2013)
!2215 = distinct !DILexicalBlock(scope: !2208, file: !3, line: 610, column: 10)
!2216 = !DILocation(line: 611, column: 9, scope: !2215, inlinedAt: !2013)
!2217 = !DILocation(line: 612, column: 11, scope: !2218, inlinedAt: !2013)
!2218 = distinct !DILexicalBlock(scope: !2215, file: !3, line: 612, column: 9)
!2219 = !DILocation(line: 612, column: 9, scope: !2215, inlinedAt: !2013)
!2220 = !DILocation(line: 613, column: 38, scope: !2221, inlinedAt: !2013)
!2221 = distinct !DILexicalBlock(scope: !2218, file: !3, line: 612, column: 21)
!2222 = !DILocation(line: 613, column: 21, scope: !2221, inlinedAt: !2013)
!2223 = !DILocation(line: 613, column: 12, scope: !2221, inlinedAt: !2013)
!2224 = !DILocation(line: 614, column: 18, scope: !2221, inlinedAt: !2013)
!2225 = !DILocation(line: 614, column: 16, scope: !2221, inlinedAt: !2013)
!2226 = !DILocation(line: 614, column: 7, scope: !2221, inlinedAt: !2013)
!2227 = !DILocation(line: 614, column: 14, scope: !2221, inlinedAt: !2013)
!2228 = !DILocation(line: 615, column: 10, scope: !2221, inlinedAt: !2013)
!2229 = !DILocation(line: 617, column: 7, scope: !2221, inlinedAt: !2013)
!2230 = !DILocation(line: 617, column: 14, scope: !2221, inlinedAt: !2013)
!2231 = !DILocation(line: 618, column: 5, scope: !2221, inlinedAt: !2013)
!2232 = !DILocation(line: 619, column: 16, scope: !2233, inlinedAt: !2013)
!2233 = distinct !DILexicalBlock(scope: !2218, file: !3, line: 618, column: 12)
!2234 = !DILocation(line: 619, column: 7, scope: !2233, inlinedAt: !2013)
!2235 = !DILocation(line: 619, column: 14, scope: !2233, inlinedAt: !2013)
!2236 = !DILocation(line: 624, column: 8, scope: !718, inlinedAt: !2013)
!2237 = !DILocation(line: 625, column: 18, scope: !2238, inlinedAt: !2013)
!2238 = distinct !DILexicalBlock(scope: !2239, file: !3, line: 625, column: 3)
!2239 = distinct !DILexicalBlock(scope: !718, file: !3, line: 625, column: 3)
!2240 = !DILocation(line: 625, column: 3, scope: !2239, inlinedAt: !2013)
!2241 = !DILocation(line: 647, column: 18, scope: !2242, inlinedAt: !2013)
!2242 = distinct !DILexicalBlock(scope: !718, file: !3, line: 637, column: 17)
!2243 = !DILocation(line: 647, column: 14, scope: !2242, inlinedAt: !2013)
!2244 = !DILocation(line: 647, column: 12, scope: !2242, inlinedAt: !2013)
!2245 = !DILocation(line: 649, column: 7, scope: !2246, inlinedAt: !2013)
!2246 = distinct !DILexicalBlock(scope: !2242, file: !3, line: 649, column: 7)
!2247 = !DILocation(line: 626, column: 17, scope: !2248, inlinedAt: !2013)
!2248 = distinct !DILexicalBlock(scope: !2238, file: !3, line: 625, column: 29)
!2249 = !DILocation(line: 626, column: 15, scope: !2248, inlinedAt: !2013)
!2250 = !DILocation(line: 626, column: 5, scope: !2248, inlinedAt: !2013)
!2251 = !DILocation(line: 626, column: 10, scope: !2248, inlinedAt: !2013)
!2252 = !DILocation(line: 627, column: 8, scope: !2248, inlinedAt: !2013)
!2253 = !DILocation(line: 625, column: 25, scope: !2238, inlinedAt: !2013)
!2254 = distinct !{!2254, !2240, !2255, !2011}
!2255 = !DILocation(line: 628, column: 3, scope: !2239, inlinedAt: !2013)
!2256 = !DILocation(line: 632, column: 72, scope: !2257, inlinedAt: !2013)
!2257 = distinct !DILexicalBlock(scope: !2258, file: !3, line: 632, column: 5)
!2258 = distinct !DILexicalBlock(scope: !2259, file: !3, line: 632, column: 5)
!2259 = distinct !DILexicalBlock(scope: !2260, file: !3, line: 631, column: 29)
!2260 = distinct !DILexicalBlock(scope: !2261, file: !3, line: 631, column: 3)
!2261 = distinct !DILexicalBlock(scope: !718, file: !3, line: 631, column: 3)
!2262 = !DILocation(line: 632, column: 59, scope: !2257, inlinedAt: !2013)
!2263 = !DILocation(line: 632, column: 35, scope: !2257, inlinedAt: !2013)
!2264 = distinct !{!2264, !2265, !2266, !2011}
!2265 = !DILocation(line: 632, column: 5, scope: !2258, inlinedAt: !2013)
!2266 = !DILocation(line: 632, column: 79, scope: !2258, inlinedAt: !2013)
!2267 = !DILocation(line: 632, column: 76, scope: !2257, inlinedAt: !2013)
!2268 = !DILocation(line: 633, column: 5, scope: !2259, inlinedAt: !2013)
!2269 = !DILocation(line: 633, column: 16, scope: !2259, inlinedAt: !2013)
!2270 = !DILocation(line: 631, column: 25, scope: !2260, inlinedAt: !2013)
!2271 = !DILocation(line: 631, column: 3, scope: !2261, inlinedAt: !2013)
!2272 = !DILocation(line: 631, column: 18, scope: !2260, inlinedAt: !2013)
!2273 = distinct !{!2273, !2271, !2274, !2011}
!2274 = !DILocation(line: 634, column: 3, scope: !2261, inlinedAt: !2013)
!2275 = !DILocation(line: 646, column: 7, scope: !2276, inlinedAt: !2013)
!2276 = distinct !DILexicalBlock(scope: !2242, file: !3, line: 646, column: 7)
!2277 = !DILocation(line: 646, column: 39, scope: !2278, inlinedAt: !2013)
!2278 = distinct !DILexicalBlock(scope: !2276, file: !3, line: 646, column: 7)
!2279 = distinct !{!2279, !2275, !2280, !2011, !2050, !2051}
!2280 = !DILocation(line: 646, column: 43, scope: !2276, inlinedAt: !2013)
!2281 = !DILocation(line: 646, column: 36, scope: !2278, inlinedAt: !2013)
!2282 = !DILocation(line: 646, column: 29, scope: !2278, inlinedAt: !2013)
!2283 = !DILocation(line: 646, column: 22, scope: !2278, inlinedAt: !2013)
!2284 = distinct !{!2284, !2275, !2280, !2011, !2050}
!2285 = !DILocation(line: 648, column: 12, scope: !2242, inlinedAt: !2013)
!2286 = !DILocation(line: 648, column: 18, scope: !2242, inlinedAt: !2013)
!2287 = !DILocation(line: 649, column: 21, scope: !2288, inlinedAt: !2013)
!2288 = distinct !DILexicalBlock(scope: !2246, file: !3, line: 649, column: 7)
!2289 = !DILocation(line: 649, column: 39, scope: !2288, inlinedAt: !2013)
!2290 = distinct !{!2290, !2245, !2291, !2011, !2050, !2051}
!2291 = !DILocation(line: 649, column: 43, scope: !2246, inlinedAt: !2013)
!2292 = !DILocation(line: 649, column: 36, scope: !2288, inlinedAt: !2013)
!2293 = !DILocation(line: 649, column: 29, scope: !2288, inlinedAt: !2013)
!2294 = distinct !{!2294, !2245, !2291, !2011, !2051, !2050}
!2295 = !DILocation(line: 0, scope: !2242, inlinedAt: !2013)
!2296 = !DILocation(line: 650, column: 14, scope: !2242, inlinedAt: !2013)
!2297 = !DILocation(line: 650, column: 7, scope: !2242, inlinedAt: !2013)
!2298 = !DILocation(line: 650, column: 12, scope: !2242, inlinedAt: !2013)
!2299 = !DILocation(line: 674, column: 12, scope: !718, inlinedAt: !2013)
!2300 = !DILocation(line: 675, column: 1, scope: !718, inlinedAt: !2013)
!2301 = !DILocation(line: 295, column: 10, scope: !2302)
!2302 = distinct !DILexicalBlock(scope: !644, file: !3, line: 295, column: 7)
!2303 = !DILocation(line: 295, column: 7, scope: !644)
!2304 = !DILocation(line: 296, column: 12, scope: !2305)
!2305 = distinct !DILexicalBlock(scope: !2302, file: !3, line: 295, column: 15)
!2306 = !DILocation(line: 296, column: 10, scope: !2305)
!2307 = !DILocation(line: 297, column: 12, scope: !2305)
!2308 = !DILocation(line: 297, column: 10, scope: !2305)
!2309 = !DILocation(line: 298, column: 12, scope: !2305)
!2310 = !DILocation(line: 298, column: 5, scope: !2305)
!2311 = !DILocation(line: 301, column: 1, scope: !644)
!2312 = !DILocation(line: 0, scope: !206)
!2313 = !DILocation(line: 0, scope: !880, inlinedAt: !2314)
!2314 = distinct !DILocation(line: 1501, column: 3, scope: !219)
!2315 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2314)
!2316 = !DILocation(line: 0, scope: !219)
!2317 = !DILocation(line: 1501, column: 3, scope: !219)
!2318 = !DILocation(line: 1502, column: 13, scope: !206)
!2319 = !DILocation(line: 1503, column: 6, scope: !206)
!2320 = !DILocation(line: 1506, column: 10, scope: !224)
!2321 = !DILocation(line: 1506, column: 7, scope: !206)
!2322 = !DILocation(line: 1507, column: 12, scope: !222)
!2323 = !DILocation(line: 1507, column: 9, scope: !223)
!2324 = !DILocation(line: 0, scope: !880, inlinedAt: !2325)
!2325 = distinct !DILocation(line: 1509, column: 7, scope: !226)
!2326 = !DILocation(line: 0, scope: !226)
!2327 = !DILocation(line: 1509, column: 7, scope: !226)
!2328 = !DILocation(line: 0, scope: !221)
!2329 = !DILocation(line: 1510, column: 16, scope: !2330)
!2330 = distinct !DILexicalBlock(scope: !221, file: !3, line: 1510, column: 11)
!2331 = !DILocation(line: 1510, column: 27, scope: !2330)
!2332 = !DILocation(line: 1510, column: 33, scope: !2330)
!2333 = !DILocation(line: 1510, column: 11, scope: !221)
!2334 = !DILocation(line: 1515, column: 11, scope: !2335)
!2335 = distinct !DILexicalBlock(scope: !223, file: !3, line: 1515, column: 9)
!2336 = !DILocation(line: 1515, column: 9, scope: !223)
!2337 = !DILocation(line: 1515, column: 33, scope: !2335)
!2338 = !DILocation(line: 1515, column: 40, scope: !2335)
!2339 = !DILocation(line: 1515, column: 38, scope: !2335)
!2340 = !DILocation(line: 1515, column: 26, scope: !2335)
!2341 = !DILocation(line: 1516, column: 11, scope: !2342)
!2342 = distinct !DILexicalBlock(scope: !223, file: !3, line: 1516, column: 9)
!2343 = !DILocation(line: 1516, column: 9, scope: !223)
!2344 = !DILocation(line: 1516, column: 33, scope: !2342)
!2345 = !DILocation(line: 1516, column: 44, scope: !2342)
!2346 = !DILocation(line: 1516, column: 42, scope: !2342)
!2347 = !DILocation(line: 1516, column: 26, scope: !2342)
!2348 = !DILocation(line: 1520, column: 10, scope: !2349)
!2349 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1520, column: 7)
!2350 = !DILocation(line: 1520, column: 7, scope: !206)
!2351 = !DILocation(line: 1521, column: 12, scope: !2352)
!2352 = distinct !DILexicalBlock(scope: !2353, file: !3, line: 1521, column: 9)
!2353 = distinct !DILexicalBlock(scope: !2349, file: !3, line: 1520, column: 24)
!2354 = !DILocation(line: 1521, column: 9, scope: !2353)
!2355 = !DILocation(line: 1526, column: 13, scope: !2356)
!2356 = distinct !DILexicalBlock(scope: !2357, file: !3, line: 1526, column: 11)
!2357 = distinct !DILexicalBlock(scope: !2352, file: !3, line: 1521, column: 26)
!2358 = !DILocation(line: 1526, column: 11, scope: !2357)
!2359 = !DILocation(line: 1527, column: 16, scope: !2357)
!2360 = !DILocation(line: 1527, column: 14, scope: !2357)
!2361 = !DILocation(line: 1528, column: 12, scope: !2357)
!2362 = !DILocation(line: 1529, column: 13, scope: !2357)
!2363 = !DILocation(line: 1529, column: 19, scope: !2357)
!2364 = !DILocation(line: 1536, column: 12, scope: !2353)
!2365 = !DILocation(line: 1544, column: 9, scope: !206)
!2366 = !DILocation(line: 1545, column: 7, scope: !206)
!2367 = !DILocation(line: 1537, column: 17, scope: !2368)
!2368 = distinct !DILexicalBlock(scope: !2349, file: !3, line: 1537, column: 14)
!2369 = !DILocation(line: 1537, column: 14, scope: !2349)
!2370 = !DILocation(line: 1538, column: 9, scope: !2371)
!2371 = distinct !DILexicalBlock(scope: !2372, file: !3, line: 1538, column: 9)
!2372 = distinct !DILexicalBlock(scope: !2368, file: !3, line: 1537, column: 31)
!2373 = !DILocation(line: 1538, column: 14, scope: !2371)
!2374 = !DILocation(line: 1538, column: 18, scope: !2371)
!2375 = !DILocation(line: 1538, column: 9, scope: !2372)
!2376 = !DILocation(line: 1538, column: 36, scope: !2371)
!2377 = !DILocation(line: 1538, column: 25, scope: !2371)
!2378 = !DILocation(line: 1531, column: 30, scope: !2379)
!2379 = distinct !DILexicalBlock(scope: !2352, file: !3, line: 1530, column: 12)
!2380 = !DILocation(line: 1531, column: 28, scope: !2379)
!2381 = !DILocation(line: 1531, column: 11, scope: !2379)
!2382 = !DILocation(line: 1532, column: 11, scope: !2379)
!2383 = !DILocation(line: 1533, column: 14, scope: !2379)
!2384 = !DILocation(line: 1534, column: 14, scope: !2379)
!2385 = !DILocation(line: 1545, column: 9, scope: !230)
!2386 = !DILocation(line: 0, scope: !230)
!2387 = !DILocation(line: 1553, column: 49, scope: !206)
!2388 = !DILocation(line: 1553, column: 39, scope: !206)
!2389 = !DILocation(line: 1553, column: 29, scope: !206)
!2390 = !DILocation(line: 1553, column: 19, scope: !206)
!2391 = !DILocation(line: 1553, column: 9, scope: !206)
!2392 = !DILocation(line: 1554, column: 9, scope: !2393)
!2393 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1554, column: 7)
!2394 = !DILocation(line: 0, scope: !2393)
!2395 = !DILocation(line: 1554, column: 7, scope: !206)
!2396 = !DILocation(line: 1555, column: 32, scope: !2397)
!2397 = distinct !DILexicalBlock(scope: !2393, file: !3, line: 1554, column: 15)
!2398 = !DILocation(line: 1555, column: 27, scope: !2397)
!2399 = !DILocation(line: 1555, column: 16, scope: !2397)
!2400 = !DILocation(line: 1555, column: 5, scope: !2397)
!2401 = !DILocation(line: 1557, column: 37, scope: !2402)
!2402 = distinct !DILexicalBlock(scope: !2393, file: !3, line: 1556, column: 10)
!2403 = !DILocation(line: 1557, column: 30, scope: !2402)
!2404 = !DILocation(line: 1557, column: 20, scope: !2402)
!2405 = !DILocation(line: 1557, column: 13, scope: !2402)
!2406 = !DILocation(line: 1559, column: 7, scope: !206)
!2407 = !DILocation(line: 1560, column: 11, scope: !2408)
!2408 = distinct !DILexicalBlock(scope: !2409, file: !3, line: 1560, column: 9)
!2409 = distinct !DILexicalBlock(scope: !2410, file: !3, line: 1559, column: 19)
!2410 = distinct !DILexicalBlock(scope: !206, file: !3, line: 1559, column: 7)
!2411 = !DILocation(line: 1560, column: 9, scope: !2409)
!2412 = !DILocation(line: 1560, column: 29, scope: !2408)
!2413 = !DILocation(line: 1560, column: 37, scope: !2408)
!2414 = !DILocation(line: 1560, column: 35, scope: !2408)
!2415 = !DILocation(line: 1560, column: 20, scope: !2408)
!2416 = !DILocation(line: 1561, column: 14, scope: !2409)
!2417 = !DILocation(line: 1561, column: 5, scope: !2409)
!2418 = !DILocation(line: 1563, column: 14, scope: !2419)
!2419 = distinct !DILexicalBlock(scope: !2410, file: !3, line: 1562, column: 10)
!2420 = !DILocation(line: 1563, column: 24, scope: !2419)
!2421 = !DILocation(line: 1563, column: 22, scope: !2419)
!2422 = !DILocation(line: 1563, column: 5, scope: !2419)
!2423 = !DILocation(line: 1565, column: 1, scope: !206)
!2424 = !DILocation(line: 0, scope: !269)
!2425 = !DILocation(line: 0, scope: !880, inlinedAt: !2426)
!2426 = distinct !DILocation(line: 1591, column: 3, scope: !277)
!2427 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2426)
!2428 = !DILocation(line: 0, scope: !277)
!2429 = !DILocation(line: 1591, column: 3, scope: !277)
!2430 = !DILocation(line: 1592, column: 11, scope: !269)
!2431 = !DILocation(line: 1593, column: 48, scope: !2432)
!2432 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1593, column: 7)
!2433 = !DILocation(line: 1593, column: 11, scope: !2432)
!2434 = !DILocation(line: 1593, column: 56, scope: !2432)
!2435 = !DILocation(line: 1593, column: 7, scope: !269)
!2436 = !DILocation(line: 1597, column: 10, scope: !2437)
!2437 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1597, column: 7)
!2438 = !DILocation(line: 1597, column: 7, scope: !269)
!2439 = !DILocation(line: 1598, column: 14, scope: !2440)
!2440 = distinct !DILexicalBlock(scope: !2437, file: !3, line: 1597, column: 25)
!2441 = !DILocation(line: 1598, column: 12, scope: !2440)
!2442 = !DILocation(line: 1598, column: 5, scope: !2440)
!2443 = !DILocation(line: 1601, column: 10, scope: !2444)
!2444 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1601, column: 7)
!2445 = !DILocation(line: 1601, column: 23, scope: !2444)
!2446 = !DILocation(line: 0, scope: !880, inlinedAt: !2447)
!2447 = distinct !DILocation(line: 1602, column: 3, scope: !279)
!2448 = !DILocation(line: 0, scope: !279)
!2449 = !DILocation(line: 1602, column: 3, scope: !279)
!2450 = !DILocation(line: 1603, column: 10, scope: !2451)
!2451 = distinct !DILexicalBlock(scope: !269, file: !3, line: 1603, column: 7)
!2452 = !DILocation(line: 0, scope: !2451)
!2453 = !DILocation(line: 1603, column: 7, scope: !269)
!2454 = !DILocation(line: 1605, column: 39, scope: !2455)
!2455 = distinct !DILexicalBlock(scope: !2451, file: !3, line: 1603, column: 24)
!2456 = !DILocation(line: 1605, column: 50, scope: !2455)
!2457 = !DILocation(line: 1605, column: 43, scope: !2455)
!2458 = !DILocation(line: 1605, column: 35, scope: !2455)
!2459 = !DILocation(line: 1606, column: 3, scope: !2455)
!2460 = !DILocation(line: 1607, column: 48, scope: !2461)
!2461 = distinct !DILexicalBlock(scope: !2451, file: !3, line: 1606, column: 10)
!2462 = !DILocation(line: 1607, column: 41, scope: !2461)
!2463 = !DILocation(line: 1609, column: 7, scope: !269)
!2464 = !DILocation(line: 1613, column: 1, scope: !269)
!2465 = !DILocation(line: 0, scope: !387)
!2466 = !DILocation(line: 0, scope: !880, inlinedAt: !2467)
!2467 = distinct !DILocation(line: 2010, column: 3, scope: !404)
!2468 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2467)
!2469 = !DILocation(line: 0, scope: !404)
!2470 = !DILocation(line: 2010, column: 3, scope: !404)
!2471 = !DILocation(line: 2013, column: 10, scope: !408)
!2472 = !DILocation(line: 2013, column: 7, scope: !387)
!2473 = !DILocation(line: 2014, column: 14, scope: !2474)
!2474 = distinct !DILexicalBlock(scope: !407, file: !3, line: 2014, column: 9)
!2475 = !DILocation(line: 2014, column: 28, scope: !2474)
!2476 = !DILocation(line: 2014, column: 34, scope: !2474)
!2477 = !DILocation(line: 2014, column: 9, scope: !407)
!2478 = !DILocation(line: 2017, column: 12, scope: !2479)
!2479 = distinct !DILexicalBlock(scope: !407, file: !3, line: 2017, column: 9)
!2480 = !DILocation(line: 2017, column: 9, scope: !407)
!2481 = !DILocation(line: 2021, column: 7, scope: !407)
!2482 = !DILocation(line: 0, scope: !880, inlinedAt: !2483)
!2483 = distinct !DILocation(line: 2022, column: 5, scope: !406)
!2484 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2483)
!2485 = !DILocation(line: 0, scope: !406)
!2486 = !DILocation(line: 2022, column: 5, scope: !406)
!2487 = !DILocation(line: 2023, column: 3, scope: !407)
!2488 = !DILocation(line: 2024, column: 10, scope: !2489)
!2489 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2024, column: 7)
!2490 = !DILocation(line: 2024, column: 7, scope: !387)
!2491 = !DILocation(line: 2024, column: 34, scope: !2489)
!2492 = !DILocation(line: 2024, column: 25, scope: !2489)
!2493 = !DILocation(line: 2025, column: 10, scope: !2494)
!2494 = distinct !DILexicalBlock(scope: !387, file: !3, line: 2025, column: 7)
!2495 = !DILocation(line: 2025, column: 24, scope: !2494)
!2496 = !DILocation(line: 2026, column: 12, scope: !387)
!2497 = !DILocation(line: 2026, column: 19, scope: !387)
!2498 = !DILocation(line: 2026, column: 5, scope: !387)
!2499 = !DILocation(line: 2027, column: 6, scope: !387)
!2500 = !DILocation(line: 2028, column: 11, scope: !387)
!2501 = !DILocation(line: 2028, column: 22, scope: !387)
!2502 = !DILocation(line: 0, scope: !880, inlinedAt: !2503)
!2503 = distinct !DILocation(line: 2029, column: 3, scope: !410)
!2504 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2503)
!2505 = !DILocation(line: 0, scope: !410)
!2506 = !DILocation(line: 2029, column: 3, scope: !410)
!2507 = !DILocation(line: 0, scope: !954, inlinedAt: !2508)
!2508 = distinct !DILocation(line: 2029, column: 3, scope: !410)
!2509 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2508)
!2510 = !DILocation(line: 2030, column: 5, scope: !387)
!2511 = !DILocation(line: 2031, column: 7, scope: !387)
!2512 = !DILocation(line: 2032, column: 9, scope: !387)
!2513 = !DILocation(line: 2033, column: 14, scope: !387)
!2514 = !DILocation(line: 2033, column: 18, scope: !387)
!2515 = !DILocalVariable(name: "f", arg: 1, scope: !2516, file: !3, line: 1978, type: !6)
!2516 = distinct !DISubprogram(name: "k_log1p", scope: !3, file: !3, line: 1978, type: !4, scopeLine: 1978, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2517)
!2517 = !{!2515, !2518, !2519, !2520, !2521, !2522, !2523, !2524}
!2518 = !DILocalVariable(name: "hfsq", scope: !2516, file: !3, line: 1979, type: !6)
!2519 = !DILocalVariable(name: "s", scope: !2516, file: !3, line: 1979, type: !6)
!2520 = !DILocalVariable(name: "z", scope: !2516, file: !3, line: 1979, type: !6)
!2521 = !DILocalVariable(name: "R", scope: !2516, file: !3, line: 1979, type: !6)
!2522 = !DILocalVariable(name: "w", scope: !2516, file: !3, line: 1979, type: !6)
!2523 = !DILocalVariable(name: "t1", scope: !2516, file: !3, line: 1979, type: !6)
!2524 = !DILocalVariable(name: "t2", scope: !2516, file: !3, line: 1979, type: !6)
!2525 = !DILocation(line: 0, scope: !2516, inlinedAt: !2526)
!2526 = distinct !DILocation(line: 2034, column: 7, scope: !387)
!2527 = !DILocation(line: 1981, column: 16, scope: !2516, inlinedAt: !2526)
!2528 = !DILocation(line: 1981, column: 9, scope: !2516, inlinedAt: !2526)
!2529 = !DILocation(line: 1982, column: 9, scope: !2516, inlinedAt: !2526)
!2530 = !DILocation(line: 1983, column: 9, scope: !2516, inlinedAt: !2526)
!2531 = !DILocation(line: 1984, column: 28, scope: !2516, inlinedAt: !2526)
!2532 = !DILocation(line: 1984, column: 17, scope: !2516, inlinedAt: !2526)
!2533 = !DILocation(line: 1984, column: 10, scope: !2516, inlinedAt: !2526)
!2534 = !DILocation(line: 1985, column: 39, scope: !2516, inlinedAt: !2526)
!2535 = !DILocation(line: 1985, column: 28, scope: !2516, inlinedAt: !2526)
!2536 = !DILocation(line: 1985, column: 17, scope: !2516, inlinedAt: !2526)
!2537 = !DILocation(line: 1985, column: 10, scope: !2516, inlinedAt: !2526)
!2538 = !DILocation(line: 1986, column: 10, scope: !2516, inlinedAt: !2526)
!2539 = !DILocation(line: 1988, column: 20, scope: !2516, inlinedAt: !2526)
!2540 = !DILocation(line: 1988, column: 12, scope: !2516, inlinedAt: !2526)
!2541 = !DILocation(line: 2066, column: 10, scope: !387)
!2542 = !DILocation(line: 0, scope: !880, inlinedAt: !2543)
!2543 = distinct !DILocation(line: 2067, column: 3, scope: !412)
!2544 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2543)
!2545 = !DILocation(line: 0, scope: !412)
!2546 = !DILocation(line: 2067, column: 3, scope: !412)
!2547 = !DILocation(line: 0, scope: !954, inlinedAt: !2548)
!2548 = distinct !DILocation(line: 2067, column: 3, scope: !412)
!2549 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2548)
!2550 = !DILocation(line: 2068, column: 11, scope: !387)
!2551 = !DILocation(line: 2068, column: 17, scope: !387)
!2552 = !DILocation(line: 2068, column: 24, scope: !387)
!2553 = !DILocation(line: 2069, column: 15, scope: !387)
!2554 = !DILocation(line: 2070, column: 16, scope: !387)
!2555 = !DILocation(line: 2070, column: 37, scope: !387)
!2556 = !DILocation(line: 2070, column: 32, scope: !387)
!2557 = !DILocation(line: 2073, column: 9, scope: !387)
!2558 = !DILocation(line: 2074, column: 16, scope: !387)
!2559 = !DILocation(line: 2074, column: 21, scope: !387)
!2560 = !DILocation(line: 2074, column: 10, scope: !387)
!2561 = !DILocation(line: 2077, column: 17, scope: !387)
!2562 = !DILocation(line: 2077, column: 3, scope: !387)
!2563 = !DILocation(line: 2078, column: 1, scope: !387)
!2564 = !DILocation(line: 0, scope: !419)
!2565 = !DILocation(line: 0, scope: !880, inlinedAt: !2566)
!2566 = distinct !DILocation(line: 2117, column: 3, scope: !428)
!2567 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2566)
!2568 = !DILocation(line: 0, scope: !428)
!2569 = !DILocation(line: 2117, column: 3, scope: !428)
!2570 = !DILocation(line: 2120, column: 10, scope: !432)
!2571 = !DILocation(line: 2120, column: 7, scope: !419)
!2572 = !DILocation(line: 2121, column: 14, scope: !2573)
!2573 = distinct !DILexicalBlock(scope: !431, file: !3, line: 2121, column: 9)
!2574 = !DILocation(line: 2121, column: 28, scope: !2573)
!2575 = !DILocation(line: 2121, column: 34, scope: !2573)
!2576 = !DILocation(line: 2121, column: 9, scope: !431)
!2577 = !DILocation(line: 2124, column: 12, scope: !2578)
!2578 = distinct !DILexicalBlock(scope: !431, file: !3, line: 2124, column: 9)
!2579 = !DILocation(line: 2124, column: 9, scope: !431)
!2580 = !DILocation(line: 2128, column: 7, scope: !431)
!2581 = !DILocation(line: 0, scope: !880, inlinedAt: !2582)
!2582 = distinct !DILocation(line: 2129, column: 5, scope: !430)
!2583 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2582)
!2584 = !DILocation(line: 0, scope: !430)
!2585 = !DILocation(line: 2129, column: 5, scope: !430)
!2586 = !DILocation(line: 0, scope: !880, inlinedAt: !2587)
!2587 = distinct !DILocation(line: 2130, column: 5, scope: !434)
!2588 = !DILocation(line: 0, scope: !434)
!2589 = !DILocation(line: 2130, column: 5, scope: !434)
!2590 = !DILocation(line: 2131, column: 3, scope: !431)
!2591 = !DILocation(line: 2132, column: 10, scope: !2592)
!2592 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2132, column: 7)
!2593 = !DILocation(line: 2132, column: 7, scope: !419)
!2594 = !DILocation(line: 2132, column: 34, scope: !2592)
!2595 = !DILocation(line: 2132, column: 25, scope: !2592)
!2596 = !DILocation(line: 2133, column: 10, scope: !2597)
!2597 = distinct !DILexicalBlock(scope: !419, file: !3, line: 2133, column: 7)
!2598 = !DILocation(line: 2133, column: 24, scope: !2597)
!2599 = !DILocation(line: 2134, column: 12, scope: !419)
!2600 = !DILocation(line: 2134, column: 19, scope: !419)
!2601 = !DILocation(line: 2134, column: 5, scope: !419)
!2602 = !DILocation(line: 2136, column: 24, scope: !419)
!2603 = !DILocation(line: 2137, column: 12, scope: !419)
!2604 = !DILocation(line: 2137, column: 41, scope: !419)
!2605 = !DILocation(line: 2137, column: 26, scope: !419)
!2606 = !DILocation(line: 2138, column: 9, scope: !419)
!2607 = !DILocation(line: 2138, column: 7, scope: !419)
!2608 = !DILocation(line: 0, scope: !880, inlinedAt: !2609)
!2609 = distinct !DILocation(line: 2139, column: 3, scope: !436)
!2610 = !DILocation(line: 0, scope: !436)
!2611 = !DILocation(line: 2139, column: 3, scope: !436)
!2612 = !DILocation(line: 0, scope: !954, inlinedAt: !2613)
!2613 = distinct !DILocation(line: 2139, column: 3, scope: !436)
!2614 = !DILocation(line: 0, scope: !880, inlinedAt: !2615)
!2615 = distinct !DILocation(line: 2140, column: 3, scope: !438)
!2616 = !DILocation(line: 0, scope: !438)
!2617 = !DILocation(line: 2140, column: 3, scope: !438)
!2618 = !DILocation(line: 0, scope: !954, inlinedAt: !2619)
!2619 = distinct !DILocation(line: 2140, column: 3, scope: !438)
!2620 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2619)
!2621 = !DILocation(line: 2142, column: 39, scope: !419)
!2622 = !DILocation(line: 2142, column: 37, scope: !419)
!2623 = !DILocation(line: 2142, column: 28, scope: !419)
!2624 = !DILocation(line: 2143, column: 12, scope: !419)
!2625 = !DILocation(line: 2144, column: 1, scope: !419)
!2626 = !DILocation(line: 0, scope: !448)
!2627 = !DILocation(line: 0, scope: !880, inlinedAt: !2628)
!2628 = distinct !DILocation(line: 2262, column: 3, scope: !465)
!2629 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2628)
!2630 = !DILocation(line: 0, scope: !465)
!2631 = !DILocation(line: 2262, column: 3, scope: !465)
!2632 = !DILocation(line: 2263, column: 12, scope: !448)
!2633 = !DILocation(line: 2264, column: 6, scope: !448)
!2634 = !DILocation(line: 2267, column: 10, scope: !472)
!2635 = !DILocation(line: 2267, column: 7, scope: !448)
!2636 = !DILocation(line: 2268, column: 12, scope: !470)
!2637 = !DILocation(line: 2268, column: 9, scope: !471)
!2638 = !DILocation(line: 2269, column: 14, scope: !468)
!2639 = !DILocation(line: 2269, column: 11, scope: !469)
!2640 = !DILocation(line: 0, scope: !880, inlinedAt: !2641)
!2641 = distinct !DILocation(line: 2271, column: 9, scope: !474)
!2642 = !DILocation(line: 0, scope: !474)
!2643 = !DILocation(line: 2271, column: 9, scope: !474)
!2644 = !DILocation(line: 0, scope: !467)
!2645 = !DILocation(line: 2272, column: 18, scope: !2646)
!2646 = distinct !DILexicalBlock(scope: !467, file: !3, line: 2272, column: 13)
!2647 = !DILocation(line: 2272, column: 29, scope: !2646)
!2648 = !DILocation(line: 2272, column: 36, scope: !2646)
!2649 = !DILocation(line: 2272, column: 13, scope: !467)
!2650 = !DILocation(line: 2277, column: 13, scope: !2651)
!2651 = distinct !DILexicalBlock(scope: !469, file: !3, line: 2277, column: 11)
!2652 = !DILocation(line: 2277, column: 11, scope: !469)
!2653 = !DILocation(line: 2277, column: 35, scope: !2651)
!2654 = !DILocation(line: 2277, column: 42, scope: !2651)
!2655 = !DILocation(line: 2277, column: 40, scope: !2651)
!2656 = !DILocation(line: 2277, column: 28, scope: !2651)
!2657 = !DILocation(line: 2279, column: 13, scope: !2658)
!2658 = distinct !DILexicalBlock(scope: !471, file: !3, line: 2279, column: 9)
!2659 = !DILocation(line: 2279, column: 9, scope: !471)
!2660 = !DILocation(line: 2286, column: 10, scope: !2661)
!2661 = distinct !DILexicalBlock(scope: !448, file: !3, line: 2286, column: 7)
!2662 = !DILocation(line: 2286, column: 7, scope: !448)
!2663 = !DILocation(line: 2287, column: 12, scope: !2664)
!2664 = distinct !DILexicalBlock(scope: !2665, file: !3, line: 2287, column: 9)
!2665 = distinct !DILexicalBlock(scope: !2661, file: !3, line: 2286, column: 24)
!2666 = !DILocation(line: 2287, column: 9, scope: !2665)
!2667 = !DILocation(line: 2288, column: 15, scope: !2668)
!2668 = distinct !DILexicalBlock(scope: !2669, file: !3, line: 2288, column: 11)
!2669 = distinct !DILexicalBlock(scope: !2664, file: !3, line: 2287, column: 26)
!2670 = !DILocation(line: 2288, column: 11, scope: !2669)
!2671 = !DILocation(line: 2289, column: 16, scope: !2672)
!2672 = distinct !DILexicalBlock(scope: !2668, file: !3, line: 2288, column: 21)
!2673 = !DILocation(line: 2292, column: 7, scope: !2672)
!2674 = !DILocation(line: 2293, column: 16, scope: !2675)
!2675 = distinct !DILexicalBlock(scope: !2668, file: !3, line: 2292, column: 14)
!2676 = !DILocation(line: 2298, column: 30, scope: !2677)
!2677 = distinct !DILexicalBlock(scope: !2664, file: !3, line: 2297, column: 12)
!2678 = !DILocation(line: 2298, column: 25, scope: !2677)
!2679 = !DILocation(line: 2298, column: 22, scope: !2677)
!2680 = !DILocation(line: 2298, column: 11, scope: !2677)
!2681 = !DILocation(line: 2299, column: 11, scope: !2677)
!2682 = !DILocation(line: 2300, column: 14, scope: !2677)
!2683 = !DILocation(line: 2301, column: 14, scope: !2677)
!2684 = !DILocation(line: 0, scope: !2664)
!2685 = !DILocation(line: 2303, column: 12, scope: !2665)
!2686 = !DILocation(line: 2304, column: 13, scope: !2665)
!2687 = !DILocation(line: 2304, column: 18, scope: !2665)
!2688 = !DILocation(line: 2305, column: 3, scope: !2665)
!2689 = !DILocation(line: 2305, column: 17, scope: !2690)
!2690 = distinct !DILexicalBlock(scope: !2661, file: !3, line: 2305, column: 14)
!2691 = !DILocation(line: 2305, column: 14, scope: !2661)
!2692 = !DILocation(line: 2306, column: 9, scope: !2693)
!2693 = distinct !DILexicalBlock(scope: !2690, file: !3, line: 2305, column: 31)
!2694 = !DILocation(line: 2306, column: 14, scope: !2693)
!2695 = !DILocation(line: 2307, column: 22, scope: !2693)
!2696 = !DILocation(line: 2307, column: 27, scope: !2693)
!2697 = !DILocation(line: 2307, column: 19, scope: !2693)
!2698 = !DILocation(line: 2307, column: 14, scope: !2693)
!2699 = !DILocation(line: 2307, column: 5, scope: !2693)
!2700 = !DILocation(line: 0, scope: !2661)
!2701 = !DILocation(line: 2313, column: 13, scope: !448)
!2702 = !DILocation(line: 2314, column: 11, scope: !448)
!2703 = !DILocation(line: 2315, column: 60, scope: !448)
!2704 = !DILocation(line: 2315, column: 48, scope: !448)
!2705 = !DILocation(line: 2315, column: 36, scope: !448)
!2706 = !DILocation(line: 2315, column: 24, scope: !448)
!2707 = !DILocation(line: 2315, column: 12, scope: !448)
!2708 = !DILocation(line: 2316, column: 11, scope: !448)
!2709 = !DILocation(line: 2317, column: 18, scope: !448)
!2710 = !DILocation(line: 2317, column: 30, scope: !448)
!2711 = !DILocation(line: 2317, column: 23, scope: !448)
!2712 = !DILocation(line: 2317, column: 11, scope: !448)
!2713 = !DILocation(line: 2318, column: 9, scope: !478)
!2714 = !DILocation(line: 2318, column: 7, scope: !448)
!2715 = !DILocation(line: 2319, column: 23, scope: !2716)
!2716 = distinct !DILexicalBlock(scope: !478, file: !3, line: 2318, column: 15)
!2717 = !DILocation(line: 2319, column: 14, scope: !2716)
!2718 = !DILocation(line: 2319, column: 5, scope: !2716)
!2719 = !DILocation(line: 0, scope: !476)
!2720 = !DILocation(line: 2321, column: 5, scope: !476)
!2721 = !DILocation(line: 0, scope: !954, inlinedAt: !2722)
!2722 = distinct !DILocation(line: 2321, column: 5, scope: !476)
!2723 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2722)
!2724 = !DILocation(line: 2325, column: 17, scope: !477)
!2725 = !DILocation(line: 2325, column: 22, scope: !477)
!2726 = !DILocation(line: 2326, column: 7, scope: !477)
!2727 = !DILocation(line: 2327, column: 9, scope: !477)
!2728 = !DILocation(line: 2327, column: 34, scope: !2729)
!2729 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2327, column: 9)
!2730 = !DILocation(line: 2327, column: 39, scope: !2729)
!2731 = !DILocation(line: 2327, column: 18, scope: !2729)
!2732 = !DILocation(line: 2329, column: 13, scope: !2733)
!2733 = distinct !DILexicalBlock(scope: !2734, file: !3, line: 2329, column: 11)
!2734 = distinct !DILexicalBlock(scope: !2735, file: !3, line: 2328, column: 17)
!2735 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2328, column: 9)
!2736 = !DILocation(line: 2329, column: 11, scope: !2734)
!2737 = !DILocation(line: 2330, column: 31, scope: !2733)
!2738 = !DILocation(line: 2330, column: 26, scope: !2733)
!2739 = !DILocation(line: 2330, column: 21, scope: !2733)
!2740 = !DILocation(line: 2330, column: 9, scope: !2733)
!2741 = !DILocation(line: 2332, column: 31, scope: !2733)
!2742 = !DILocation(line: 2332, column: 20, scope: !2733)
!2743 = !DILocation(line: 2332, column: 9, scope: !2733)
!2744 = !DILocation(line: 2334, column: 17, scope: !2745)
!2745 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2334, column: 9)
!2746 = !DILocation(line: 2335, column: 15, scope: !2747)
!2747 = distinct !DILexicalBlock(scope: !2745, file: !3, line: 2334, column: 28)
!2748 = !DILocation(line: 2339, column: 13, scope: !2749)
!2749 = distinct !DILexicalBlock(scope: !2747, file: !3, line: 2339, column: 11)
!2750 = !DILocation(line: 2339, column: 11, scope: !2747)
!2751 = !DILocation(line: 2343, column: 16, scope: !2747)
!2752 = !DILocation(line: 2343, column: 7, scope: !2747)
!2753 = !DILocation(line: 2346, column: 11, scope: !482)
!2754 = !DILocation(line: 0, scope: !880, inlinedAt: !2755)
!2755 = distinct !DILocation(line: 2347, column: 7, scope: !480)
!2756 = !DILocation(line: 0, scope: !880, inlinedAt: !2757)
!2757 = distinct !DILocation(line: 2351, column: 7, scope: !484)
!2758 = !DILocation(line: 2346, column: 9, scope: !477)
!2759 = !DILocation(line: 0, scope: !480)
!2760 = !DILocation(line: 2347, column: 7, scope: !480)
!2761 = !DILocation(line: 0, scope: !954, inlinedAt: !2762)
!2762 = distinct !DILocation(line: 2347, column: 7, scope: !480)
!2763 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2762)
!2764 = !DILocation(line: 2348, column: 18, scope: !481)
!2765 = !DILocation(line: 2348, column: 13, scope: !481)
!2766 = !DILocation(line: 2350, column: 5, scope: !481)
!2767 = !DILocation(line: 0, scope: !484)
!2768 = !DILocation(line: 2351, column: 7, scope: !484)
!2769 = !DILocation(line: 0, scope: !954, inlinedAt: !2770)
!2770 = distinct !DILocation(line: 2351, column: 7, scope: !484)
!2771 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2770)
!2772 = !DILocation(line: 2352, column: 18, scope: !485)
!2773 = !DILocation(line: 2352, column: 13, scope: !485)
!2774 = !DILocation(line: 2353, column: 9, scope: !485)
!2775 = !DILocation(line: 0, scope: !482)
!2776 = !DILocation(line: 2357, column: 3, scope: !448)
!2777 = !DILocation(line: 2358, column: 1, scope: !448)
!2778 = !DILocation(line: 0, scope: !510)
!2779 = !DILocation(line: 0, scope: !880, inlinedAt: !2780)
!2780 = distinct !DILocation(line: 2377, column: 3, scope: !522)
!2781 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2780)
!2782 = !DILocation(line: 0, scope: !522)
!2783 = !DILocation(line: 2377, column: 3, scope: !522)
!2784 = !DILocation(line: 2378, column: 13, scope: !510)
!2785 = !DILocation(line: 2379, column: 6, scope: !510)
!2786 = !DILocation(line: 2380, column: 10, scope: !2787)
!2787 = distinct !DILexicalBlock(scope: !510, file: !3, line: 2380, column: 7)
!2788 = !DILocation(line: 2380, column: 7, scope: !510)
!2789 = !DILocation(line: 2380, column: 35, scope: !2787)
!2790 = !DILocation(line: 2380, column: 25, scope: !2787)
!2791 = !DILocation(line: 2397, column: 10, scope: !526)
!2792 = !DILocation(line: 2397, column: 7, scope: !510)
!2793 = !DILocation(line: 2398, column: 13, scope: !2794)
!2794 = distinct !DILexicalBlock(scope: !525, file: !3, line: 2398, column: 9)
!2795 = !DILocation(line: 2398, column: 20, scope: !2794)
!2796 = !DILocation(line: 2398, column: 9, scope: !525)
!2797 = !DILocation(line: 0, scope: !880, inlinedAt: !2798)
!2798 = distinct !DILocation(line: 2399, column: 5, scope: !524)
!2799 = !DILocation(line: 0, scope: !954, inlinedAt: !2800)
!2800 = distinct !DILocation(line: 2399, column: 5, scope: !524)
!2801 = !DILocation(line: 2400, column: 7, scope: !525)
!2802 = !DILocation(line: 0, scope: !880, inlinedAt: !2803)
!2803 = distinct !DILocation(line: 2401, column: 5, scope: !528)
!2804 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2803)
!2805 = !DILocation(line: 0, scope: !528)
!2806 = !DILocation(line: 2401, column: 5, scope: !528)
!2807 = !DILocation(line: 0, scope: !530)
!2808 = !DILocation(line: 2402, column: 5, scope: !530)
!2809 = !DILocation(line: 0, scope: !954, inlinedAt: !2810)
!2810 = distinct !DILocation(line: 2402, column: 5, scope: !530)
!2811 = !DILocation(line: 2403, column: 3, scope: !525)
!2812 = !DILocation(line: 0, scope: !526)
!2813 = !DILocation(line: 2417, column: 10, scope: !510)
!2814 = !DILocation(line: 2417, column: 20, scope: !510)
!2815 = !DILocation(line: 2417, column: 15, scope: !510)
!2816 = !DILocation(line: 2418, column: 26, scope: !510)
!2817 = !DILocation(line: 2418, column: 16, scope: !510)
!2818 = !DILocation(line: 2418, column: 43, scope: !510)
!2819 = !DILocation(line: 2418, column: 48, scope: !510)
!2820 = !DILocation(line: 2418, column: 59, scope: !510)
!2821 = !DILocation(line: 2418, column: 37, scope: !510)
!2822 = !DILocation(line: 2418, column: 9, scope: !510)
!2823 = !DILocation(line: 0, scope: !880, inlinedAt: !2824)
!2824 = distinct !DILocation(line: 2430, column: 19, scope: !510)
!2825 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2824)
!2826 = !DILocation(line: 2431, column: 30, scope: !510)
!2827 = !DILocation(line: 0, scope: !954, inlinedAt: !2828)
!2828 = distinct !DILocation(line: 2432, column: 7, scope: !510)
!2829 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !2828)
!2830 = !DILocation(line: 2435, column: 9, scope: !510)
!2831 = !DILocation(line: 2436, column: 9, scope: !510)
!2832 = !DILocation(line: 2437, column: 9, scope: !510)
!2833 = !DILocation(line: 2438, column: 10, scope: !510)
!2834 = !DILocation(line: 2438, column: 20, scope: !510)
!2835 = !DILocation(line: 2438, column: 15, scope: !510)
!2836 = !DILocation(line: 2439, column: 9, scope: !510)
!2837 = !DILocation(line: 2442, column: 1, scope: !510)
!2838 = distinct !DISubprogram(name: "pts_ieee754_sin", scope: !3, file: !3, line: 2474, type: !4, scopeLine: 2474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2839)
!2839 = !{!2840, !2841, !2842, !2843, !2844, !2845}
!2840 = !DILocalVariable(name: "x", arg: 1, scope: !2838, file: !3, line: 2474, type: !6)
!2841 = !DILocalVariable(name: "y", scope: !2838, file: !3, line: 2475, type: !1657)
!2842 = !DILocalVariable(name: "z", scope: !2838, file: !3, line: 2475, type: !6)
!2843 = !DILocalVariable(name: "n", scope: !2838, file: !3, line: 2476, type: !21)
!2844 = !DILocalVariable(name: "ix", scope: !2838, file: !3, line: 2476, type: !21)
!2845 = !DILocalVariable(name: "bits", scope: !2846, file: !3, line: 2479, type: !18)
!2846 = distinct !DILexicalBlock(scope: !2838, file: !3, line: 2479, column: 3)
!2847 = distinct !DIAssignID()
!2848 = !DILocation(line: 0, scope: !2838)
!2849 = !DILocation(line: 2475, column: 3, scope: !2838)
!2850 = !DILocation(line: 0, scope: !880, inlinedAt: !2851)
!2851 = distinct !DILocation(line: 2479, column: 3, scope: !2846)
!2852 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2851)
!2853 = !DILocation(line: 0, scope: !2846)
!2854 = !DILocation(line: 2479, column: 3, scope: !2846)
!2855 = !DILocation(line: 2482, column: 6, scope: !2838)
!2856 = !DILocation(line: 2483, column: 10, scope: !2857)
!2857 = distinct !DILexicalBlock(scope: !2838, file: !3, line: 2483, column: 7)
!2858 = !DILocation(line: 2483, column: 7, scope: !2838)
!2859 = !DILocation(line: 0, scope: !770, inlinedAt: !2860)
!2860 = distinct !DILocation(line: 2484, column: 12, scope: !2861)
!2861 = distinct !DILexicalBlock(scope: !2857, file: !3, line: 2483, column: 25)
!2862 = !DILocation(line: 0, scope: !880, inlinedAt: !2863)
!2863 = distinct !DILocation(line: 716, column: 3, scope: !782, inlinedAt: !2860)
!2864 = !DILocation(line: 0, scope: !782, inlinedAt: !2860)
!2865 = !DILocation(line: 718, column: 10, scope: !1755, inlinedAt: !2860)
!2866 = !DILocation(line: 718, column: 7, scope: !770, inlinedAt: !2860)
!2867 = !DILocation(line: 721, column: 9, scope: !770, inlinedAt: !2860)
!2868 = !DILocation(line: 722, column: 9, scope: !770, inlinedAt: !2860)
!2869 = !DILocation(line: 723, column: 40, scope: !770, inlinedAt: !2860)
!2870 = !DILocation(line: 723, column: 30, scope: !770, inlinedAt: !2860)
!2871 = !DILocation(line: 723, column: 20, scope: !770, inlinedAt: !2860)
!2872 = !DILocation(line: 723, column: 10, scope: !770, inlinedAt: !2860)
!2873 = !DILocation(line: 725, column: 24, scope: !2874, inlinedAt: !2860)
!2874 = distinct !DILexicalBlock(scope: !1765, file: !3, line: 724, column: 16)
!2875 = !DILocation(line: 725, column: 14, scope: !2874, inlinedAt: !2860)
!2876 = !DILocation(line: 725, column: 5, scope: !2874, inlinedAt: !2860)
!2877 = !DILocation(line: 2485, column: 17, scope: !2878)
!2878 = distinct !DILexicalBlock(scope: !2857, file: !3, line: 2485, column: 14)
!2879 = !DILocation(line: 2485, column: 14, scope: !2857)
!2880 = !DILocation(line: 2487, column: 14, scope: !2881)
!2881 = distinct !DILexicalBlock(scope: !2878, file: !3, line: 2485, column: 32)
!2882 = !DILocation(line: 2487, column: 5, scope: !2881)
!2883 = !DILocation(line: 2490, column: 9, scope: !2884)
!2884 = distinct !DILexicalBlock(scope: !2878, file: !3, line: 2488, column: 10)
!2885 = !DILocation(line: 2491, column: 15, scope: !2884)
!2886 = !DILocation(line: 0, scope: !2887)
!2887 = distinct !DILexicalBlock(scope: !2884, file: !3, line: 2491, column: 20)
!2888 = !DILocation(line: 2491, column: 5, scope: !2884)
!2889 = !DILocation(line: 0, scope: !770, inlinedAt: !2890)
!2890 = distinct !DILocation(line: 2493, column: 16, scope: !2887)
!2891 = !DILocation(line: 0, scope: !880, inlinedAt: !2892)
!2892 = distinct !DILocation(line: 716, column: 3, scope: !782, inlinedAt: !2890)
!2893 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2892)
!2894 = !DILocation(line: 0, scope: !782, inlinedAt: !2890)
!2895 = !DILocation(line: 718, column: 10, scope: !1755, inlinedAt: !2890)
!2896 = !DILocation(line: 718, column: 7, scope: !770, inlinedAt: !2890)
!2897 = !DILocation(line: 2493, column: 35, scope: !2887)
!2898 = !DILocation(line: 721, column: 9, scope: !770, inlinedAt: !2890)
!2899 = !DILocation(line: 723, column: 40, scope: !770, inlinedAt: !2890)
!2900 = !DILocation(line: 723, column: 30, scope: !770, inlinedAt: !2890)
!2901 = !DILocation(line: 723, column: 20, scope: !770, inlinedAt: !2890)
!2902 = !DILocation(line: 723, column: 10, scope: !770, inlinedAt: !2890)
!2903 = !DILocation(line: 727, column: 32, scope: !1764, inlinedAt: !2890)
!2904 = !DILocation(line: 727, column: 41, scope: !1764, inlinedAt: !2890)
!2905 = !DILocation(line: 727, column: 46, scope: !1764, inlinedAt: !2890)
!2906 = !DILocation(line: 727, column: 14, scope: !1764, inlinedAt: !2890)
!2907 = !DILocation(line: 727, column: 5, scope: !1764, inlinedAt: !2890)
!2908 = !DILocation(line: 2495, column: 35, scope: !2887)
!2909 = !DILocation(line: 0, scope: !612, inlinedAt: !2910)
!2910 = distinct !DILocation(line: 2495, column: 16, scope: !2887)
!2911 = !DILocation(line: 0, scope: !880, inlinedAt: !2912)
!2912 = distinct !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !2910)
!2913 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2912)
!2914 = !DILocation(line: 0, scope: !623, inlinedAt: !2910)
!2915 = !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !2910)
!2916 = !DILocation(line: 349, column: 6, scope: !612, inlinedAt: !2910)
!2917 = !DILocation(line: 350, column: 10, scope: !1682, inlinedAt: !2910)
!2918 = !DILocation(line: 350, column: 7, scope: !612, inlinedAt: !2910)
!2919 = !DILocation(line: 353, column: 9, scope: !612, inlinedAt: !2910)
!2920 = !DILocation(line: 354, column: 55, scope: !612, inlinedAt: !2910)
!2921 = !DILocation(line: 354, column: 45, scope: !612, inlinedAt: !2910)
!2922 = !DILocation(line: 354, column: 35, scope: !612, inlinedAt: !2910)
!2923 = !DILocation(line: 354, column: 25, scope: !612, inlinedAt: !2910)
!2924 = !DILocation(line: 354, column: 15, scope: !612, inlinedAt: !2910)
!2925 = !DILocation(line: 354, column: 9, scope: !612, inlinedAt: !2910)
!2926 = !DILocation(line: 355, column: 10, scope: !629, inlinedAt: !2910)
!2927 = !DILocation(line: 355, column: 7, scope: !612, inlinedAt: !2910)
!2928 = !DILocation(line: 356, column: 36, scope: !1694, inlinedAt: !2910)
!2929 = !DILocation(line: 356, column: 27, scope: !1694, inlinedAt: !2910)
!2930 = !DILocation(line: 356, column: 16, scope: !1694, inlinedAt: !2910)
!2931 = !DILocation(line: 356, column: 5, scope: !1694, inlinedAt: !2910)
!2932 = !DILocation(line: 358, column: 12, scope: !627, inlinedAt: !2910)
!2933 = !DILocation(line: 358, column: 9, scope: !628, inlinedAt: !2910)
!2934 = !DILocation(line: 363, column: 18, scope: !628, inlinedAt: !2910)
!2935 = !DILocation(line: 364, column: 13, scope: !628, inlinedAt: !2910)
!2936 = !DILocation(line: 365, column: 29, scope: !628, inlinedAt: !2910)
!2937 = !DILocation(line: 365, column: 14, scope: !628, inlinedAt: !2910)
!2938 = !DILocation(line: 365, column: 5, scope: !628, inlinedAt: !2910)
!2939 = !DILocation(line: 0, scope: !770, inlinedAt: !2940)
!2940 = distinct !DILocation(line: 2497, column: 17, scope: !2887)
!2941 = !DILocation(line: 0, scope: !880, inlinedAt: !2942)
!2942 = distinct !DILocation(line: 716, column: 3, scope: !782, inlinedAt: !2940)
!2943 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2942)
!2944 = !DILocation(line: 0, scope: !782, inlinedAt: !2940)
!2945 = !DILocation(line: 718, column: 10, scope: !1755, inlinedAt: !2940)
!2946 = !DILocation(line: 718, column: 7, scope: !770, inlinedAt: !2940)
!2947 = !DILocation(line: 2497, column: 36, scope: !2887)
!2948 = !DILocation(line: 721, column: 9, scope: !770, inlinedAt: !2940)
!2949 = !DILocation(line: 723, column: 40, scope: !770, inlinedAt: !2940)
!2950 = !DILocation(line: 723, column: 30, scope: !770, inlinedAt: !2940)
!2951 = !DILocation(line: 723, column: 20, scope: !770, inlinedAt: !2940)
!2952 = !DILocation(line: 723, column: 10, scope: !770, inlinedAt: !2940)
!2953 = !DILocation(line: 727, column: 32, scope: !1764, inlinedAt: !2940)
!2954 = !DILocation(line: 727, column: 41, scope: !1764, inlinedAt: !2940)
!2955 = !DILocation(line: 727, column: 46, scope: !1764, inlinedAt: !2940)
!2956 = !DILocation(line: 727, column: 14, scope: !1764, inlinedAt: !2940)
!2957 = !DILocation(line: 727, column: 5, scope: !1764, inlinedAt: !2940)
!2958 = !DILocation(line: 2497, column: 16, scope: !2887)
!2959 = !DILocation(line: 2497, column: 9, scope: !2887)
!2960 = !DILocation(line: 2499, column: 36, scope: !2887)
!2961 = !DILocation(line: 0, scope: !612, inlinedAt: !2962)
!2962 = distinct !DILocation(line: 2499, column: 17, scope: !2887)
!2963 = !DILocation(line: 0, scope: !880, inlinedAt: !2964)
!2964 = distinct !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !2962)
!2965 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !2964)
!2966 = !DILocation(line: 0, scope: !623, inlinedAt: !2962)
!2967 = !DILocation(line: 348, column: 3, scope: !623, inlinedAt: !2962)
!2968 = !DILocation(line: 349, column: 6, scope: !612, inlinedAt: !2962)
!2969 = !DILocation(line: 350, column: 10, scope: !1682, inlinedAt: !2962)
!2970 = !DILocation(line: 350, column: 7, scope: !612, inlinedAt: !2962)
!2971 = !DILocation(line: 353, column: 9, scope: !612, inlinedAt: !2962)
!2972 = !DILocation(line: 354, column: 55, scope: !612, inlinedAt: !2962)
!2973 = !DILocation(line: 354, column: 45, scope: !612, inlinedAt: !2962)
!2974 = !DILocation(line: 354, column: 35, scope: !612, inlinedAt: !2962)
!2975 = !DILocation(line: 354, column: 25, scope: !612, inlinedAt: !2962)
!2976 = !DILocation(line: 354, column: 15, scope: !612, inlinedAt: !2962)
!2977 = !DILocation(line: 354, column: 9, scope: !612, inlinedAt: !2962)
!2978 = !DILocation(line: 355, column: 10, scope: !629, inlinedAt: !2962)
!2979 = !DILocation(line: 355, column: 7, scope: !612, inlinedAt: !2962)
!2980 = !DILocation(line: 356, column: 36, scope: !1694, inlinedAt: !2962)
!2981 = !DILocation(line: 356, column: 27, scope: !1694, inlinedAt: !2962)
!2982 = !DILocation(line: 356, column: 16, scope: !1694, inlinedAt: !2962)
!2983 = !DILocation(line: 356, column: 5, scope: !1694, inlinedAt: !2962)
!2984 = !DILocation(line: 358, column: 12, scope: !627, inlinedAt: !2962)
!2985 = !DILocation(line: 358, column: 9, scope: !628, inlinedAt: !2962)
!2986 = !DILocation(line: 363, column: 18, scope: !628, inlinedAt: !2962)
!2987 = !DILocation(line: 364, column: 13, scope: !628, inlinedAt: !2962)
!2988 = !DILocation(line: 365, column: 29, scope: !628, inlinedAt: !2962)
!2989 = !DILocation(line: 365, column: 14, scope: !628, inlinedAt: !2962)
!2990 = !DILocation(line: 365, column: 5, scope: !628, inlinedAt: !2962)
!2991 = !DILocation(line: 2499, column: 16, scope: !2887)
!2992 = !DILocation(line: 2499, column: 9, scope: !2887)
!2993 = !DILocation(line: 0, scope: !2857)
!2994 = !DILocation(line: 2502, column: 1, scope: !2838)
!2995 = distinct !DISubprogram(name: "pts_ieee754_tan", scope: !3, file: !3, line: 2533, type: !4, scopeLine: 2533, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2996)
!2996 = !{!2997, !2998, !2999, !3000, !3001, !3002}
!2997 = !DILocalVariable(name: "x", arg: 1, scope: !2995, file: !3, line: 2533, type: !6)
!2998 = !DILocalVariable(name: "y", scope: !2995, file: !3, line: 2534, type: !1657)
!2999 = !DILocalVariable(name: "z", scope: !2995, file: !3, line: 2534, type: !6)
!3000 = !DILocalVariable(name: "n", scope: !2995, file: !3, line: 2535, type: !21)
!3001 = !DILocalVariable(name: "ix", scope: !2995, file: !3, line: 2535, type: !21)
!3002 = !DILocalVariable(name: "bits", scope: !3003, file: !3, line: 2538, type: !18)
!3003 = distinct !DILexicalBlock(scope: !2995, file: !3, line: 2538, column: 3)
!3004 = distinct !DIAssignID()
!3005 = !DILocation(line: 0, scope: !2995)
!3006 = !DILocation(line: 2534, column: 3, scope: !2995)
!3007 = !DILocation(line: 0, scope: !880, inlinedAt: !3008)
!3008 = distinct !DILocation(line: 2538, column: 3, scope: !3003)
!3009 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3008)
!3010 = !DILocation(line: 0, scope: !3003)
!3011 = !DILocation(line: 2538, column: 3, scope: !3003)
!3012 = !DILocation(line: 2541, column: 6, scope: !2995)
!3013 = !DILocation(line: 2542, column: 10, scope: !3014)
!3014 = distinct !DILexicalBlock(scope: !2995, file: !3, line: 2542, column: 7)
!3015 = !DILocation(line: 2542, column: 7, scope: !2995)
!3016 = !DILocation(line: 0, scope: !811, inlinedAt: !3017)
!3017 = distinct !DILocation(line: 2543, column: 12, scope: !3018)
!3018 = distinct !DILexicalBlock(scope: !3014, file: !3, line: 2542, column: 25)
!3019 = !DILocation(line: 0, scope: !880, inlinedAt: !3020)
!3020 = distinct !DILocation(line: 791, column: 3, scope: !824, inlinedAt: !3017)
!3021 = !DILocation(line: 0, scope: !824, inlinedAt: !3017)
!3022 = !DILocation(line: 793, column: 10, scope: !829, inlinedAt: !3017)
!3023 = !DILocation(line: 793, column: 7, scope: !811, inlinedAt: !3017)
!3024 = !DILocation(line: 816, column: 10, scope: !3025, inlinedAt: !3017)
!3025 = distinct !DILexicalBlock(scope: !811, file: !3, line: 816, column: 7)
!3026 = !DILocation(line: 816, column: 7, scope: !811, inlinedAt: !3017)
!3027 = !DILocation(line: 817, column: 12, scope: !3028, inlinedAt: !3017)
!3028 = distinct !DILexicalBlock(scope: !3029, file: !3, line: 817, column: 9)
!3029 = distinct !DILexicalBlock(scope: !3025, file: !3, line: 816, column: 25)
!3030 = !DILocation(line: 817, column: 9, scope: !3029, inlinedAt: !3017)
!3031 = !DILocation(line: 821, column: 14, scope: !3029, inlinedAt: !3017)
!3032 = !DILocation(line: 823, column: 11, scope: !3029, inlinedAt: !3017)
!3033 = !DILocation(line: 825, column: 3, scope: !3029, inlinedAt: !3017)
!3034 = !DILocation(line: 826, column: 9, scope: !811, inlinedAt: !3017)
!3035 = !DILocation(line: 827, column: 9, scope: !811, inlinedAt: !3017)
!3036 = !DILocation(line: 833, column: 60, scope: !811, inlinedAt: !3017)
!3037 = !DILocation(line: 833, column: 48, scope: !811, inlinedAt: !3017)
!3038 = !DILocation(line: 833, column: 36, scope: !811, inlinedAt: !3017)
!3039 = !DILocation(line: 833, column: 24, scope: !811, inlinedAt: !3017)
!3040 = !DILocation(line: 833, column: 12, scope: !811, inlinedAt: !3017)
!3041 = !DILocation(line: 835, column: 62, scope: !811, inlinedAt: !3017)
!3042 = !DILocation(line: 835, column: 49, scope: !811, inlinedAt: !3017)
!3043 = !DILocation(line: 835, column: 37, scope: !811, inlinedAt: !3017)
!3044 = !DILocation(line: 835, column: 25, scope: !811, inlinedAt: !3017)
!3045 = !DILocation(line: 835, column: 13, scope: !811, inlinedAt: !3017)
!3046 = !DILocation(line: 834, column: 9, scope: !811, inlinedAt: !3017)
!3047 = !DILocation(line: 836, column: 9, scope: !811, inlinedAt: !3017)
!3048 = !DILocation(line: 837, column: 23, scope: !811, inlinedAt: !3017)
!3049 = !DILocation(line: 837, column: 28, scope: !811, inlinedAt: !3017)
!3050 = !DILocation(line: 837, column: 9, scope: !811, inlinedAt: !3017)
!3051 = !DILocation(line: 838, column: 5, scope: !811, inlinedAt: !3017)
!3052 = !DILocation(line: 839, column: 9, scope: !811, inlinedAt: !3017)
!3053 = !DILocation(line: 840, column: 7, scope: !811, inlinedAt: !3017)
!3054 = !DILocation(line: 842, column: 22, scope: !3055, inlinedAt: !3017)
!3055 = distinct !DILexicalBlock(scope: !3056, file: !3, line: 840, column: 25)
!3056 = distinct !DILexicalBlock(scope: !811, file: !3, line: 840, column: 7)
!3057 = !DILocation(line: 842, column: 29, scope: !3055, inlinedAt: !3017)
!3058 = !DILocation(line: 842, column: 15, scope: !3055, inlinedAt: !3017)
!3059 = !DILocation(line: 842, column: 12, scope: !3055, inlinedAt: !3017)
!3060 = !DILocation(line: 842, column: 56, scope: !3055, inlinedAt: !3017)
!3061 = !DILocation(line: 842, column: 65, scope: !3055, inlinedAt: !3017)
!3062 = !DILocation(line: 842, column: 60, scope: !3055, inlinedAt: !3017)
!3063 = !DILocation(line: 842, column: 70, scope: !3055, inlinedAt: !3017)
!3064 = !DILocation(line: 842, column: 51, scope: !3055, inlinedAt: !3017)
!3065 = !DILocation(line: 842, column: 40, scope: !3055, inlinedAt: !3017)
!3066 = !DILocation(line: 842, column: 35, scope: !3055, inlinedAt: !3017)
!3067 = !DILocation(line: 842, column: 5, scope: !3055, inlinedAt: !3017)
!3068 = !DILocation(line: 2544, column: 17, scope: !3069)
!3069 = distinct !DILexicalBlock(scope: !3014, file: !3, line: 2544, column: 14)
!3070 = !DILocation(line: 2544, column: 14, scope: !3014)
!3071 = !DILocation(line: 2546, column: 14, scope: !3072)
!3072 = distinct !DILexicalBlock(scope: !3069, file: !3, line: 2544, column: 32)
!3073 = !DILocation(line: 2546, column: 5, scope: !3072)
!3074 = !DILocation(line: 2549, column: 9, scope: !3075)
!3075 = distinct !DILexicalBlock(scope: !3069, file: !3, line: 2547, column: 10)
!3076 = !DILocation(line: 2551, column: 25, scope: !3075)
!3077 = !DILocation(line: 2551, column: 31, scope: !3075)
!3078 = !DILocation(line: 2551, column: 50, scope: !3075)
!3079 = !DILocation(line: 2551, column: 39, scope: !3075)
!3080 = !DILocation(line: 0, scope: !811, inlinedAt: !3081)
!3081 = distinct !DILocation(line: 2551, column: 12, scope: !3075)
!3082 = !DILocation(line: 0, scope: !880, inlinedAt: !3083)
!3083 = distinct !DILocation(line: 791, column: 3, scope: !824, inlinedAt: !3081)
!3084 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3083)
!3085 = !DILocation(line: 0, scope: !824, inlinedAt: !3081)
!3086 = !DILocation(line: 791, column: 3, scope: !824, inlinedAt: !3081)
!3087 = !DILocation(line: 792, column: 11, scope: !811, inlinedAt: !3081)
!3088 = !DILocation(line: 793, column: 10, scope: !829, inlinedAt: !3081)
!3089 = !DILocation(line: 793, column: 7, scope: !811, inlinedAt: !3081)
!3090 = !DILocation(line: 0, scope: !880, inlinedAt: !3091)
!3091 = distinct !DILocation(line: 796, column: 7, scope: !831, inlinedAt: !3081)
!3092 = !DILocation(line: 0, scope: !831, inlinedAt: !3081)
!3093 = !DILocation(line: 796, column: 7, scope: !831, inlinedAt: !3081)
!3094 = !DILocation(line: 0, scope: !826, inlinedAt: !3081)
!3095 = !DILocation(line: 797, column: 29, scope: !836, inlinedAt: !3081)
!3096 = !DILocation(line: 797, column: 23, scope: !836, inlinedAt: !3081)
!3097 = !DILocation(line: 797, column: 35, scope: !836, inlinedAt: !3081)
!3098 = !DILocation(line: 797, column: 11, scope: !826, inlinedAt: !3081)
!3099 = !DILocation(line: 798, column: 22, scope: !3100, inlinedAt: !3081)
!3100 = distinct !DILexicalBlock(scope: !836, file: !3, line: 797, column: 41)
!3101 = !DILocation(line: 798, column: 20, scope: !3100, inlinedAt: !3081)
!3102 = !DILocation(line: 798, column: 9, scope: !3100, inlinedAt: !3081)
!3103 = !DILocation(line: 800, column: 16, scope: !834, inlinedAt: !3081)
!3104 = !DILocation(line: 800, column: 13, scope: !835, inlinedAt: !3081)
!3105 = !DILocation(line: 805, column: 21, scope: !833, inlinedAt: !3081)
!3106 = !DILocation(line: 0, scope: !880, inlinedAt: !3107)
!3107 = distinct !DILocation(line: 806, column: 11, scope: !839, inlinedAt: !3081)
!3108 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3107)
!3109 = !DILocation(line: 0, scope: !839, inlinedAt: !3081)
!3110 = !DILocation(line: 806, column: 11, scope: !839, inlinedAt: !3081)
!3111 = !DILocation(line: 0, scope: !954, inlinedAt: !3112)
!3112 = distinct !DILocation(line: 806, column: 11, scope: !839, inlinedAt: !3081)
!3113 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !3112)
!3114 = !DILocation(line: 807, column: 22, scope: !833, inlinedAt: !3081)
!3115 = !DILocation(line: 807, column: 17, scope: !833, inlinedAt: !3081)
!3116 = !DILocation(line: 808, column: 24, scope: !833, inlinedAt: !3081)
!3117 = !DILocation(line: 0, scope: !833, inlinedAt: !3081)
!3118 = !DILocation(line: 0, scope: !880, inlinedAt: !3119)
!3119 = distinct !DILocation(line: 809, column: 11, scope: !841, inlinedAt: !3081)
!3120 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3119)
!3121 = !DILocation(line: 0, scope: !841, inlinedAt: !3081)
!3122 = !DILocation(line: 809, column: 11, scope: !841, inlinedAt: !3081)
!3123 = !DILocation(line: 0, scope: !954, inlinedAt: !3124)
!3124 = distinct !DILocation(line: 809, column: 11, scope: !841, inlinedAt: !3081)
!3125 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !3124)
!3126 = !DILocation(line: 810, column: 19, scope: !833, inlinedAt: !3081)
!3127 = !DILocation(line: 811, column: 29, scope: !833, inlinedAt: !3081)
!3128 = !DILocation(line: 811, column: 20, scope: !833, inlinedAt: !3081)
!3129 = !DILocation(line: 816, column: 10, scope: !3025, inlinedAt: !3081)
!3130 = !DILocation(line: 816, column: 7, scope: !811, inlinedAt: !3081)
!3131 = !DILocation(line: 817, column: 12, scope: !3028, inlinedAt: !3081)
!3132 = !DILocation(line: 817, column: 9, scope: !3029, inlinedAt: !3081)
!3133 = !DILocation(line: 821, column: 14, scope: !3029, inlinedAt: !3081)
!3134 = !DILocation(line: 822, column: 16, scope: !3029, inlinedAt: !3081)
!3135 = !DILocation(line: 823, column: 11, scope: !3029, inlinedAt: !3081)
!3136 = !DILocation(line: 825, column: 3, scope: !3029, inlinedAt: !3081)
!3137 = !DILocation(line: 826, column: 9, scope: !811, inlinedAt: !3081)
!3138 = !DILocation(line: 827, column: 9, scope: !811, inlinedAt: !3081)
!3139 = !DILocation(line: 833, column: 60, scope: !811, inlinedAt: !3081)
!3140 = !DILocation(line: 833, column: 48, scope: !811, inlinedAt: !3081)
!3141 = !DILocation(line: 833, column: 36, scope: !811, inlinedAt: !3081)
!3142 = !DILocation(line: 833, column: 24, scope: !811, inlinedAt: !3081)
!3143 = !DILocation(line: 833, column: 12, scope: !811, inlinedAt: !3081)
!3144 = !DILocation(line: 835, column: 62, scope: !811, inlinedAt: !3081)
!3145 = !DILocation(line: 835, column: 49, scope: !811, inlinedAt: !3081)
!3146 = !DILocation(line: 835, column: 37, scope: !811, inlinedAt: !3081)
!3147 = !DILocation(line: 835, column: 25, scope: !811, inlinedAt: !3081)
!3148 = !DILocation(line: 835, column: 13, scope: !811, inlinedAt: !3081)
!3149 = !DILocation(line: 834, column: 9, scope: !811, inlinedAt: !3081)
!3150 = !DILocation(line: 836, column: 9, scope: !811, inlinedAt: !3081)
!3151 = !DILocation(line: 837, column: 23, scope: !811, inlinedAt: !3081)
!3152 = !DILocation(line: 837, column: 28, scope: !811, inlinedAt: !3081)
!3153 = !DILocation(line: 837, column: 9, scope: !811, inlinedAt: !3081)
!3154 = !DILocation(line: 838, column: 5, scope: !811, inlinedAt: !3081)
!3155 = !DILocation(line: 839, column: 9, scope: !811, inlinedAt: !3081)
!3156 = !DILocation(line: 840, column: 7, scope: !811, inlinedAt: !3081)
!3157 = !DILocation(line: 841, column: 9, scope: !3055, inlinedAt: !3081)
!3158 = !DILocation(line: 842, column: 22, scope: !3055, inlinedAt: !3081)
!3159 = !DILocation(line: 842, column: 29, scope: !3055, inlinedAt: !3081)
!3160 = !DILocation(line: 842, column: 15, scope: !3055, inlinedAt: !3081)
!3161 = !DILocation(line: 842, column: 12, scope: !3055, inlinedAt: !3081)
!3162 = !DILocation(line: 842, column: 56, scope: !3055, inlinedAt: !3081)
!3163 = !DILocation(line: 842, column: 65, scope: !3055, inlinedAt: !3081)
!3164 = !DILocation(line: 842, column: 60, scope: !3055, inlinedAt: !3081)
!3165 = !DILocation(line: 842, column: 70, scope: !3055, inlinedAt: !3081)
!3166 = !DILocation(line: 842, column: 51, scope: !3055, inlinedAt: !3081)
!3167 = !DILocation(line: 842, column: 40, scope: !3055, inlinedAt: !3081)
!3168 = !DILocation(line: 842, column: 35, scope: !3055, inlinedAt: !3081)
!3169 = !DILocation(line: 842, column: 5, scope: !3055, inlinedAt: !3081)
!3170 = !DILocation(line: 844, column: 10, scope: !844, inlinedAt: !3081)
!3171 = !DILocation(line: 844, column: 7, scope: !811, inlinedAt: !3081)
!3172 = !DILocation(line: 0, scope: !880, inlinedAt: !3173)
!3173 = distinct !DILocation(line: 854, column: 5, scope: !847, inlinedAt: !3081)
!3174 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3173)
!3175 = !DILocation(line: 0, scope: !847, inlinedAt: !3081)
!3176 = !DILocation(line: 854, column: 5, scope: !847, inlinedAt: !3081)
!3177 = !DILocation(line: 0, scope: !954, inlinedAt: !3178)
!3178 = distinct !DILocation(line: 854, column: 5, scope: !847, inlinedAt: !3081)
!3179 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !3178)
!3180 = !DILocation(line: 855, column: 16, scope: !843, inlinedAt: !3081)
!3181 = !DILocation(line: 855, column: 11, scope: !843, inlinedAt: !3081)
!3182 = !DILocation(line: 856, column: 18, scope: !843, inlinedAt: !3081)
!3183 = !DILocation(line: 0, scope: !843, inlinedAt: !3081)
!3184 = !DILocation(line: 0, scope: !880, inlinedAt: !3185)
!3185 = distinct !DILocation(line: 857, column: 5, scope: !849, inlinedAt: !3081)
!3186 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3185)
!3187 = !DILocation(line: 0, scope: !849, inlinedAt: !3081)
!3188 = !DILocation(line: 857, column: 5, scope: !849, inlinedAt: !3081)
!3189 = !DILocation(line: 0, scope: !954, inlinedAt: !3190)
!3190 = distinct !DILocation(line: 857, column: 5, scope: !849, inlinedAt: !3081)
!3191 = !DILocation(line: 62, column: 3, scope: !954, inlinedAt: !3190)
!3192 = !DILocation(line: 858, column: 13, scope: !843, inlinedAt: !3081)
!3193 = !DILocation(line: 859, column: 23, scope: !843, inlinedAt: !3081)
!3194 = !DILocation(line: 859, column: 14, scope: !843, inlinedAt: !3081)
!3195 = !DILocation(line: 0, scope: !3014)
!3196 = !DILocation(line: 2553, column: 1, scope: !2995)
!3197 = !DILocation(line: 0, scope: !550)
!3198 = !DILocation(line: 0, scope: !880, inlinedAt: !3199)
!3199 = distinct !DILocation(line: 2585, column: 3, scope: !555)
!3200 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3199)
!3201 = !DILocation(line: 0, scope: !555)
!3202 = !DILocation(line: 2585, column: 3, scope: !555)
!3203 = !DILocation(line: 2586, column: 6, scope: !550)
!3204 = !DILocation(line: 2589, column: 10, scope: !558)
!3205 = !DILocation(line: 2589, column: 7, scope: !550)
!3206 = !DILocation(line: 2590, column: 34, scope: !557)
!3207 = !DILocation(line: 2590, column: 16, scope: !557)
!3208 = !DILocation(line: 0, scope: !557)
!3209 = !DILocation(line: 2591, column: 20, scope: !557)
!3210 = !DILocation(line: 2593, column: 12, scope: !3211)
!3211 = distinct !DILexicalBlock(scope: !557, file: !3, line: 2593, column: 9)
!3212 = !DILocation(line: 2593, column: 9, scope: !557)
!3213 = !DILocation(line: 2594, column: 21, scope: !557)
!3214 = !DILocation(line: 2594, column: 31, scope: !557)
!3215 = !DILocation(line: 2594, column: 26, scope: !557)
!3216 = !DILocation(line: 2594, column: 16, scope: !557)
!3217 = !DILocation(line: 2594, column: 5, scope: !557)
!3218 = !DILocation(line: 2598, column: 10, scope: !562)
!3219 = !DILocation(line: 2598, column: 7, scope: !550)
!3220 = !DILocation(line: 2599, column: 32, scope: !561)
!3221 = !DILocation(line: 2599, column: 16, scope: !561)
!3222 = !DILocation(line: 0, scope: !561)
!3223 = !DILocation(line: 2600, column: 28, scope: !561)
!3224 = !DILocation(line: 2600, column: 21, scope: !561)
!3225 = !DILocation(line: 2604, column: 10, scope: !3226)
!3226 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2604, column: 7)
!3227 = !DILocation(line: 2604, column: 7, scope: !550)
!3228 = !DILocation(line: 2604, column: 38, scope: !3226)
!3229 = !DILocation(line: 2604, column: 36, scope: !3226)
!3230 = !DILocation(line: 2604, column: 24, scope: !3226)
!3231 = !DILocation(line: 2607, column: 15, scope: !565)
!3232 = !DILocation(line: 2607, column: 7, scope: !550)
!3233 = !DILocation(line: 2608, column: 37, scope: !564)
!3234 = !DILocation(line: 2608, column: 16, scope: !564)
!3235 = !DILocation(line: 0, scope: !564)
!3236 = !DILocation(line: 2609, column: 21, scope: !564)
!3237 = !DILocation(line: 2610, column: 14, scope: !564)
!3238 = !DILocation(line: 2614, column: 10, scope: !3239)
!3239 = distinct !DILexicalBlock(scope: !550, file: !3, line: 2614, column: 7)
!3240 = !DILocation(line: 2614, column: 7, scope: !550)
!3241 = !DILocation(line: 2614, column: 34, scope: !3239)
!3242 = !DILocation(line: 2614, column: 25, scope: !3239)
!3243 = !DILocation(line: 2617, column: 10, scope: !550)
!3244 = !DILocation(line: 2617, column: 17, scope: !550)
!3245 = !DILocation(line: 2617, column: 15, scope: !550)
!3246 = !DILocation(line: 2617, column: 3, scope: !550)
!3247 = !DILocation(line: 2618, column: 1, scope: !550)
!3248 = !DILocation(line: 0, scope: !575)
!3249 = !DILocation(line: 2648, column: 17, scope: !575)
!3250 = !DILocation(line: 2648, column: 14, scope: !575)
!3251 = !DILocation(line: 2650, column: 15, scope: !575)
!3252 = !DILocation(line: 2651, column: 10, scope: !582)
!3253 = !DILocation(line: 2651, column: 7, scope: !575)
!3254 = !DILocation(line: 2653, column: 12, scope: !3255)
!3255 = distinct !DILexicalBlock(scope: !581, file: !3, line: 2653, column: 9)
!3256 = !DILocation(line: 2653, column: 9, scope: !581)
!3257 = !DILocation(line: 2654, column: 16, scope: !581)
!3258 = !DILocation(line: 0, scope: !581)
!3259 = !DILocation(line: 2655, column: 12, scope: !3260)
!3260 = distinct !DILexicalBlock(scope: !581, file: !3, line: 2655, column: 9)
!3261 = !DILocation(line: 2655, column: 9, scope: !581)
!3262 = !DILocation(line: 2656, column: 25, scope: !3263)
!3263 = distinct !DILexicalBlock(scope: !3260, file: !3, line: 2655, column: 17)
!3264 = !DILocation(line: 2656, column: 7, scope: !3263)
!3265 = !DILocation(line: 2658, column: 23, scope: !581)
!3266 = !DILocation(line: 2658, column: 19, scope: !581)
!3267 = !DILocation(line: 2658, column: 5, scope: !581)
!3268 = !DILocation(line: 2661, column: 10, scope: !3269)
!3269 = distinct !DILexicalBlock(scope: !575, file: !3, line: 2661, column: 7)
!3270 = !DILocation(line: 2661, column: 7, scope: !575)
!3271 = !DILocation(line: 2661, column: 33, scope: !3269)
!3272 = !DILocation(line: 2661, column: 31, scope: !3269)
!3273 = !DILocation(line: 2661, column: 22, scope: !3269)
!3274 = !DILocation(line: 2664, column: 10, scope: !585)
!3275 = !DILocation(line: 2664, column: 7, scope: !575)
!3276 = !DILocation(line: 2665, column: 36, scope: !584)
!3277 = !DILocation(line: 2665, column: 16, scope: !584)
!3278 = !DILocation(line: 0, scope: !584)
!3279 = !DILocation(line: 2666, column: 18, scope: !584)
!3280 = !DILocation(line: 2667, column: 14, scope: !584)
!3281 = !DILocation(line: 2671, column: 12, scope: !575)
!3282 = !DILocation(line: 2671, column: 3, scope: !575)
!3283 = !DILocation(line: 2672, column: 1, scope: !575)
!3284 = !DILocation(line: 0, scope: !595)
!3285 = !DILocation(line: 0, scope: !880, inlinedAt: !3286)
!3286 = distinct !DILocation(line: 2703, column: 3, scope: !603)
!3287 = !DILocation(line: 56, column: 3, scope: !880, inlinedAt: !3286)
!3288 = !DILocation(line: 0, scope: !603)
!3289 = !DILocation(line: 2703, column: 3, scope: !603)
!3290 = !DILocation(line: 2704, column: 11, scope: !595)
!3291 = !DILocation(line: 2707, column: 10, scope: !3292)
!3292 = distinct !DILexicalBlock(scope: !595, file: !3, line: 2707, column: 7)
!3293 = !DILocation(line: 2707, column: 7, scope: !595)
!3294 = !DILocation(line: 2708, column: 12, scope: !3295)
!3295 = distinct !DILexicalBlock(scope: !3296, file: !3, line: 2708, column: 9)
!3296 = distinct !DILexicalBlock(scope: !3292, file: !3, line: 2707, column: 25)
!3297 = !DILocation(line: 0, scope: !3295)
!3298 = !DILocation(line: 2708, column: 9, scope: !3296)
!3299 = !DILocation(line: 2709, column: 22, scope: !3295)
!3300 = !DILocation(line: 2709, column: 7, scope: !3295)
!3301 = !DILocation(line: 2711, column: 22, scope: !3295)
!3302 = !DILocation(line: 2711, column: 7, scope: !3295)
!3303 = !DILocation(line: 2715, column: 10, scope: !3304)
!3304 = distinct !DILexicalBlock(scope: !595, file: !3, line: 2715, column: 7)
!3305 = !DILocation(line: 2715, column: 7, scope: !595)
!3306 = !DILocation(line: 2716, column: 12, scope: !3307)
!3307 = distinct !DILexicalBlock(scope: !3308, file: !3, line: 2716, column: 9)
!3308 = distinct !DILexicalBlock(scope: !3304, file: !3, line: 2715, column: 24)
!3309 = !DILocation(line: 2716, column: 9, scope: !3308)
!3310 = !DILocation(line: 2719, column: 12, scope: !3311)
!3311 = distinct !DILexicalBlock(scope: !3308, file: !3, line: 2719, column: 9)
!3312 = !DILocation(line: 0, scope: !3311)
!3313 = !DILocation(line: 2719, column: 9, scope: !3308)
!3314 = !DILocation(line: 2720, column: 33, scope: !3315)
!3315 = distinct !DILexicalBlock(scope: !3311, file: !3, line: 2719, column: 27)
!3316 = !DILocation(line: 2720, column: 11, scope: !3315)
!3317 = !DILocation(line: 2721, column: 26, scope: !3315)
!3318 = !DILocation(line: 2721, column: 21, scope: !3315)
!3319 = !DILocation(line: 2721, column: 15, scope: !3315)
!3320 = !DILocation(line: 2722, column: 5, scope: !3315)
!3321 = !DILocation(line: 2723, column: 34, scope: !3322)
!3322 = distinct !DILexicalBlock(scope: !3311, file: !3, line: 2722, column: 12)
!3323 = !DILocation(line: 2723, column: 11, scope: !3322)
!3324 = !DILocation(line: 2724, column: 11, scope: !3322)
!3325 = !DILocation(line: 2724, column: 19, scope: !3322)
!3326 = !DILocation(line: 2724, column: 14, scope: !3322)
!3327 = !DILocation(line: 2728, column: 15, scope: !3328)
!3328 = distinct !DILexicalBlock(scope: !3304, file: !3, line: 2727, column: 10)
!3329 = !DILocation(line: 2728, column: 13, scope: !3328)
!3330 = !DILocation(line: 0, scope: !3304)
!3331 = !DILocation(line: 2730, column: 10, scope: !595)
!3332 = !DILocation(line: 2730, column: 3, scope: !595)
!3333 = !DILocation(line: 2731, column: 1, scope: !595)
!3334 = !DISubprogram(name: "scalbn", scope: !3335, file: !3335, line: 279, type: !3336, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3335 = !DIFile(filename: "/usr/bin/../lib/gcc-cross/aarch64-linux-gnu/13/../../../../aarch64-linux-gnu/include/bits/mathcalls.h", directory: "", checksumkind: CSK_MD5, checksum: "12f0a7cb98f2ec572091728ebaf4a161")
!3336 = !DISubroutineType(types: !3337)
!3337 = !{!6, !6, !17}
