#pragma once
double fabs(double); double sqrt(double); double floor(double); double scalbn(double, int); double trunc(double); double nextafter(double, double); double fmod(double, double);
#define NAN __builtin_nan("")
#define INFINITY __builtin_inf()
