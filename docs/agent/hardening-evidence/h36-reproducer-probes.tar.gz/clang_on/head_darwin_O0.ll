; ModuleID = '../src/ieee754_head.c'
source_filename = "../src/ieee754_head.c"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "arm64-apple-macosx13.0.0"

@pts_ieee754_acos.one = internal constant double 1.000000e+00, align 8, !dbg !0
@pts_ieee754_acos.pi = internal constant double 0x400921FB54442D18, align 8, !dbg !20
@pts_ieee754_acos.pio2_hi = internal constant double 0x3FF921FB54442D18, align 8, !dbg !23
@pts_ieee754_acos.pio2_lo = internal constant double 0x3C91A62633145C07, align 8, !dbg !25
@pts_ieee754_acos.pS0 = internal constant double 0x3FC5555555555555, align 8, !dbg !27
@pts_ieee754_acos.pS1 = internal constant double 0xBFD4D61203EB6F7D, align 8, !dbg !29
@pts_ieee754_acos.pS2 = internal constant double 0x3FC9C1550E884455, align 8, !dbg !31
@pts_ieee754_acos.pS3 = internal constant double 0xBFA48228B5688F3B, align 8, !dbg !33
@pts_ieee754_acos.pS4 = internal constant double 0x3F49EFE07501B288, align 8, !dbg !35
@pts_ieee754_acos.pS5 = internal constant double 0x3F023DE10DFDF709, align 8, !dbg !37
@pts_ieee754_acos.qS1 = internal constant double 0xC0033A271C8A2D4B, align 8, !dbg !39
@pts_ieee754_acos.qS2 = internal constant double 0x40002AE59C598AC8, align 8, !dbg !41
@pts_ieee754_acos.qS3 = internal constant double 0xBFE6066C1B8D0159, align 8, !dbg !43
@pts_ieee754_acos.qS4 = internal constant double 0x3FB3B8C5B12E9282, align 8, !dbg !45
@pts_ieee754_acosh.one = internal constant double 1.000000e+00, align 8, !dbg !47
@pts_ieee754_acosh.ln2 = internal constant double 0x3FE62E42FEFA39EF, align 8, !dbg !51
@pts_ieee754_asin.one = internal constant double 1.000000e+00, align 8, !dbg !53
@pts_ieee754_asin.huge = internal constant double 1.000000e+300, align 8, !dbg !56
@pts_ieee754_asin.pio2_hi = internal constant double 0x3FF921FB54442D18, align 8, !dbg !58
@pts_ieee754_asin.pio2_lo = internal constant double 0x3C91A62633145C07, align 8, !dbg !60
@pts_ieee754_asin.pio4_hi = internal constant double 0x3FE921FB54442D18, align 8, !dbg !62
@pts_ieee754_asin.pS0 = internal constant double 0x3FC5555555555555, align 8, !dbg !64
@pts_ieee754_asin.pS1 = internal constant double 0xBFD4D61203EB6F7D, align 8, !dbg !66
@pts_ieee754_asin.pS2 = internal constant double 0x3FC9C1550E884455, align 8, !dbg !68
@pts_ieee754_asin.pS3 = internal constant double 0xBFA48228B5688F3B, align 8, !dbg !70
@pts_ieee754_asin.pS4 = internal constant double 0x3F49EFE07501B288, align 8, !dbg !72
@pts_ieee754_asin.pS5 = internal constant double 0x3F023DE10DFDF709, align 8, !dbg !74
@pts_ieee754_asin.qS1 = internal constant double 0xC0033A271C8A2D4B, align 8, !dbg !76
@pts_ieee754_asin.qS2 = internal constant double 0x40002AE59C598AC8, align 8, !dbg !78
@pts_ieee754_asin.qS3 = internal constant double 0xBFE6066C1B8D0159, align 8, !dbg !80
@pts_ieee754_asin.qS4 = internal constant double 0x3FB3B8C5B12E9282, align 8, !dbg !82
@pts_ieee754_asinh.one = internal constant double 1.000000e+00, align 8, !dbg !84
@pts_ieee754_asinh.ln2 = internal constant double 0x3FE62E42FEFA39EF, align 8, !dbg !87
@pts_ieee754_asinh.huge = internal constant double 1.000000e+300, align 8, !dbg !89
@pts_ieee754_atan.atanhi = internal constant [4 x double] [double 0x3FDDAC670561BB4F, double 0x3FE921FB54442D18, double 0x3FEF730BD281F69B, double 0x3FF921FB54442D18], align 8, !dbg !91
@pts_ieee754_atan.atanlo = internal constant [4 x double] [double 0x3C7A2B7F222F65E2, double 0x3C81A62633145C07, double 0x3C7007887AF0CBBD, double 0x3C91A62633145C07], align 8, !dbg !97
@pts_ieee754_atan.aT = internal constant [11 x double] [double 0x3FD555555555550D, double 0xBFC999999998EBC4, double 0x3FC24924920083FF, double 0xBFBC71C6FE231671, double 0x3FB745CDC54C206E, double 0xBFB3B0F2AF749A6D, double 0x3FB10D66A0D03D51, double 0xBFADDE2D52DEFD9A, double 0x3FA97B4B24760DEB, double 0xBFA2B4442C6A6C2F, double 0x3F90AD3AE322DA11], align 8, !dbg !99
@pts_ieee754_atan.one = internal constant double 1.000000e+00, align 8, !dbg !104
@pts_ieee754_atan.huge = internal constant double 1.000000e+300, align 8, !dbg !106
@pts_ieee754_atan2.tiny = internal global double 1.000000e-300, align 8, !dbg !108
@pts_ieee754_atan2.zero = internal constant double 0.000000e+00, align 8, !dbg !113
@pts_ieee754_atan2.pi_o_4 = internal constant double 0x3FE921FB54442D18, align 8, !dbg !115
@pts_ieee754_atan2.pi_o_2 = internal constant double 0x3FF921FB54442D18, align 8, !dbg !117
@pts_ieee754_atan2.pi = internal constant double 0x400921FB54442D18, align 8, !dbg !119
@pts_ieee754_atan2.pi_lo = internal global double 0x3CA1A62633145C07, align 8, !dbg !121
@pts_ieee754_exp.one = internal constant double 1.000000e+00, align 8, !dbg !123
@pts_ieee754_exp.halF = internal constant [2 x double] [double 5.000000e-01, double -5.000000e-01], align 8, !dbg !126
@pts_ieee754_exp.o_threshold = internal constant double 0x40862E42FEFA39EF, align 8, !dbg !131
@pts_ieee754_exp.u_threshold = internal constant double 0xC0874910D52D3051, align 8, !dbg !133
@pts_ieee754_exp.ln2HI = internal constant [2 x double] [double 0x3FE62E42FEE00000, double 0xBFE62E42FEE00000], align 8, !dbg !135
@pts_ieee754_exp.ln2LO = internal constant [2 x double] [double 0x3DEA39EF35793C76, double 0xBDEA39EF35793C76], align 8, !dbg !137
@pts_ieee754_exp.invln2 = internal constant double 0x3FF71547652B82FE, align 8, !dbg !139
@pts_ieee754_exp.P1 = internal constant double 0x3FC555555555553E, align 8, !dbg !141
@pts_ieee754_exp.P2 = internal constant double 0xBF66C16C16BEBD93, align 8, !dbg !143
@pts_ieee754_exp.P3 = internal constant double 0x3F11566AAF25DE2C, align 8, !dbg !145
@pts_ieee754_exp.P4 = internal constant double 0xBEBBBD41C5D26BF1, align 8, !dbg !147
@pts_ieee754_exp.P5 = internal constant double 0x3E66376972BEA4D0, align 8, !dbg !149
@pts_ieee754_exp.E = internal constant double 0x4005BF0A8B145769, align 8, !dbg !151
@pts_ieee754_exp.huge = internal global double 1.000000e+300, align 8, !dbg !153
@pts_ieee754_exp.twom1000 = internal global double 0x170000000000000, align 8, !dbg !155
@pts_ieee754_exp.two1023 = internal global double 0x7FE0000000000000, align 8, !dbg !157
@pts_ieee754_atanh.one = internal constant double 1.000000e+00, align 8, !dbg !159
@pts_ieee754_atanh.huge = internal constant double 1.000000e+300, align 8, !dbg !162
@pts_ieee754_atanh.zero = internal constant double 0.000000e+00, align 8, !dbg !164
@pts_ieee754_log.ln2_hi = internal constant double 0x3FE62E42FEE00000, align 8, !dbg !166
@pts_ieee754_log.ln2_lo = internal constant double 0x3DEA39EF35793C76, align 8, !dbg !169
@pts_ieee754_log.two54 = internal constant double 0x4350000000000000, align 8, !dbg !171
@pts_ieee754_log.Lg1 = internal constant double 0x3FE5555555555593, align 8, !dbg !173
@pts_ieee754_log.Lg2 = internal constant double 0x3FD999999997FA04, align 8, !dbg !175
@pts_ieee754_log.Lg3 = internal constant double 0x3FD2492494229359, align 8, !dbg !177
@pts_ieee754_log.Lg4 = internal constant double 0x3FCC71C51D8E78AF, align 8, !dbg !179
@pts_ieee754_log.Lg5 = internal constant double 0x3FC7466496CB03DE, align 8, !dbg !181
@pts_ieee754_log.Lg6 = internal constant double 0x3FC39A09D078C69F, align 8, !dbg !183
@pts_ieee754_log.Lg7 = internal constant double 0x3FC2F112DF3E5244, align 8, !dbg !185
@pts_ieee754_log.zero = internal constant double 0.000000e+00, align 8, !dbg !187
@pts_ieee754_log1p.ln2_hi = internal constant double 0x3FE62E42FEE00000, align 8, !dbg !189
@pts_ieee754_log1p.ln2_lo = internal constant double 0x3DEA39EF35793C76, align 8, !dbg !192
@pts_ieee754_log1p.two54 = internal constant double 0x4350000000000000, align 8, !dbg !194
@pts_ieee754_log1p.Lp1 = internal constant double 0x3FE5555555555593, align 8, !dbg !196
@pts_ieee754_log1p.Lp2 = internal constant double 0x3FD999999997FA04, align 8, !dbg !198
@pts_ieee754_log1p.Lp3 = internal constant double 0x3FD2492494229359, align 8, !dbg !200
@pts_ieee754_log1p.Lp4 = internal constant double 0x3FCC71C51D8E78AF, align 8, !dbg !202
@pts_ieee754_log1p.Lp5 = internal constant double 0x3FC7466496CB03DE, align 8, !dbg !204
@pts_ieee754_log1p.Lp6 = internal constant double 0x3FC39A09D078C69F, align 8, !dbg !206
@pts_ieee754_log1p.Lp7 = internal constant double 0x3FC2F112DF3E5244, align 8, !dbg !208
@pts_ieee754_log1p.zero = internal constant double 0.000000e+00, align 8, !dbg !210
@pts_ieee754_log2.two54 = internal constant double 0x4350000000000000, align 8, !dbg !212
@pts_ieee754_log2.ivln2hi = internal constant double 0x3FF7154765200000, align 8, !dbg !215
@pts_ieee754_log2.ivln2lo = internal constant double 0x3DE705FC2EEFA200, align 8, !dbg !217
@pts_ieee754_log10.two54 = internal constant double 0x4350000000000000, align 8, !dbg !219
@pts_ieee754_log10.ivln10 = internal constant double 0x3FDBCB7B1526E50E, align 8, !dbg !222
@pts_ieee754_log10.log10_2hi = internal constant double 0x3FD34413509F6000, align 8, !dbg !224
@pts_ieee754_log10.log10_2lo = internal constant double 0x3D59FEF311F12B36, align 8, !dbg !226
@pts_ieee754_expm1.one = internal constant double 1.000000e+00, align 8, !dbg !228
@pts_ieee754_expm1.tiny = internal constant double 1.000000e-300, align 8, !dbg !231
@pts_ieee754_expm1.o_threshold = internal constant double 0x40862E42FEFA39EF, align 8, !dbg !233
@pts_ieee754_expm1.ln2_hi = internal constant double 0x3FE62E42FEE00000, align 8, !dbg !235
@pts_ieee754_expm1.ln2_lo = internal constant double 0x3DEA39EF35793C76, align 8, !dbg !237
@pts_ieee754_expm1.invln2 = internal constant double 0x3FF71547652B82FE, align 8, !dbg !239
@pts_ieee754_expm1.Q1 = internal constant double 0xBFA11111111110F4, align 8, !dbg !241
@pts_ieee754_expm1.Q2 = internal constant double 0x3F5A01A019FE5585, align 8, !dbg !243
@pts_ieee754_expm1.Q3 = internal constant double 0xBF14CE199EAADBB7, align 8, !dbg !245
@pts_ieee754_expm1.Q4 = internal constant double 0x3ED0CFCA86E65239, align 8, !dbg !247
@pts_ieee754_expm1.Q5 = internal constant double 0xBE8AFDB76E09C32D, align 8, !dbg !249
@pts_ieee754_expm1.huge = internal global double 1.000000e+300, align 8, !dbg !251
@pts_ieee754_cbrt.B1 = internal constant i32 715094163, align 4, !dbg !253
@pts_ieee754_cbrt.B2 = internal constant i32 696219795, align 4, !dbg !257
@pts_ieee754_cbrt.P0 = internal constant double 0x3FFE03E60F61E692, align 8, !dbg !259
@pts_ieee754_cbrt.P1 = internal constant double 0xBFFE28E092F02420, align 8, !dbg !261
@pts_ieee754_cbrt.P2 = internal constant double 0x3FF9F1604A49D6C2, align 8, !dbg !263
@pts_ieee754_cbrt.P3 = internal constant double 0xBFE844CBBEE751D9, align 8, !dbg !265
@pts_ieee754_cbrt.P4 = internal constant double 0x3FC2B000D4E4EDD7, align 8, !dbg !267
@pts_ieee754_cosh.KCOSH_OVERFLOW = internal constant double 0x408633CE8FB9F87D, align 8, !dbg !269
@pts_ieee754_cosh.one = internal constant double 1.000000e+00, align 8, !dbg !272
@pts_ieee754_cosh.half = internal constant double 5.000000e-01, align 8, !dbg !274
@pts_ieee754_cosh.huge = internal global double 1.000000e+300, align 8, !dbg !276
@pts_ieee754_sinh.KSINH_OVERFLOW = internal constant double 0x408633CE8FB9F87D, align 8, !dbg !278
@pts_ieee754_sinh.TWO_M28 = internal constant double 0x3E30000000000000, align 8, !dbg !281
@pts_ieee754_sinh.LOG_MAXD = internal constant double 0x40862E4200000000, align 8, !dbg !283
@pts_ieee754_sinh.shuge = internal constant double 0x7FAC7B1F3CAC7433, align 8, !dbg !285
@pts_ieee754_tanh.tiny = internal constant double 1.000000e-300, align 8, !dbg !287
@pts_ieee754_tanh.one = internal constant double 1.000000e+00, align 8, !dbg !290
@pts_ieee754_tanh.two = internal constant double 2.000000e+00, align 8, !dbg !292
@pts_ieee754_tanh.huge = internal constant double 1.000000e+300, align 8, !dbg !294
@__kernel_cos.one = internal constant double 1.000000e+00, align 8, !dbg !296
@__kernel_cos.C1 = internal constant double 0x3FA555555555554C, align 8, !dbg !299
@__kernel_cos.C2 = internal constant double 0xBF56C16C16C15177, align 8, !dbg !301
@__kernel_cos.C3 = internal constant double 0x3EFA01A019CB1590, align 8, !dbg !303
@__kernel_cos.C4 = internal constant double 0xBE927E4F809C52AD, align 8, !dbg !305
@__kernel_cos.C5 = internal constant double 0x3E21EE9EBDB4B1C4, align 8, !dbg !307
@__kernel_cos.C6 = internal constant double 0xBDA8FAE9BE8838D4, align 8, !dbg !309
@__ieee754_rem_pio2.two_over_pi = internal constant [66 x i32] [i32 10680707, i32 7228996, i32 1387004, i32 2578385, i32 16069853, i32 12639074, i32 9804092, i32 4427841, i32 16666979, i32 11263675, i32 12935607, i32 2387514, i32 4345298, i32 14681673, i32 3074569, i32 13734428, i32 16653803, i32 1880361, i32 10960616, i32 8533493, i32 3062596, i32 8710556, i32 7349940, i32 6258241, i32 3772886, i32 3769171, i32 3798172, i32 8675211, i32 12450088, i32 3874808, i32 9961438, i32 366607, i32 15675153, i32 9132554, i32 7151469, i32 3571407, i32 2607881, i32 12013382, i32 4155038, i32 6285869, i32 7677882, i32 13102053, i32 15825725, i32 473591, i32 9065106, i32 15363067, i32 6271263, i32 9264392, i32 5636912, i32 4652155, i32 7056368, i32 13614112, i32 10155062, i32 1944035, i32 9527646, i32 15080200, i32 6658437, i32 6231200, i32 6832269, i32 16767104, i32 5075751, i32 3212806, i32 1398474, i32 7579849, i32 6349435, i32 12618859], align 4, !dbg !311
@__ieee754_rem_pio2.npio2_hw = internal constant [32 x i32] [i32 1073291771, i32 1074340347, i32 1074977148, i32 1075388923, i32 1075800698, i32 1076025724, i32 1076231611, i32 1076437499, i32 1076643386, i32 1076849274, i32 1076971356, i32 1077074300, i32 1077177244, i32 1077280187, i32 1077383131, i32 1077486075, i32 1077589019, i32 1077691962, i32 1077794906, i32 1077897850, i32 1077968460, i32 1078019932, i32 1078071404, i32 1078122876, i32 1078174348, i32 1078225820, i32 1078277292, i32 1078328763, i32 1078380235, i32 1078431707, i32 1078483179, i32 1078534651], align 4, !dbg !321
@__ieee754_rem_pio2.zero = internal constant double 0.000000e+00, align 8, !dbg !326
@__ieee754_rem_pio2.half = internal constant double 5.000000e-01, align 8, !dbg !328
@__ieee754_rem_pio2.two24 = internal constant double 0x4170000000000000, align 8, !dbg !330
@__ieee754_rem_pio2.invpio2 = internal constant double 0x3FE45F306DC9C883, align 8, !dbg !332
@__ieee754_rem_pio2.pio2_1 = internal constant double 0x3FF921FB54400000, align 8, !dbg !334
@__ieee754_rem_pio2.pio2_1t = internal constant double 0x3DD0B4611A626331, align 8, !dbg !336
@__ieee754_rem_pio2.pio2_2 = internal constant double 0x3DD0B4611A600000, align 8, !dbg !338
@__ieee754_rem_pio2.pio2_2t = internal constant double 0x3BA3198A2E037073, align 8, !dbg !340
@__ieee754_rem_pio2.pio2_3 = internal constant double 0x3BA3198A2E000000, align 8, !dbg !342
@__ieee754_rem_pio2.pio2_3t = internal constant double 0x397B839A252049C1, align 8, !dbg !344
@__kernel_rem_pio2.init_jk = internal constant [4 x i32] [i32 2, i32 3, i32 4, i32 6], align 4, !dbg !346
@__kernel_rem_pio2.PIo2 = internal constant [8 x double] [double 0x3FF921FB40000000, double 0x3E74442D00000000, double 0x3CF8469880000000, double 0x3B78CC5160000000, double 0x39F01B8380000000, double 0x387A252040000000, double 0x36E3822280000000, double 0x3569F31D00000000], align 8, !dbg !354
@__kernel_rem_pio2.zero = internal constant double 0.000000e+00, align 8, !dbg !359
@__kernel_rem_pio2.one = internal constant double 1.000000e+00, align 8, !dbg !361
@__kernel_rem_pio2.two24 = internal constant double 0x4170000000000000, align 8, !dbg !363
@__kernel_rem_pio2.twon24 = internal constant double 0x3E70000000000000, align 8, !dbg !365
@__kernel_sin.half = internal constant double 5.000000e-01, align 8, !dbg !367
@__kernel_sin.S1 = internal constant double 0xBFC5555555555549, align 8, !dbg !372
@__kernel_sin.S2 = internal constant double 0x3F8111111110F8A6, align 8, !dbg !374
@__kernel_sin.S3 = internal constant double 0xBF2A01A019C161D5, align 8, !dbg !376
@__kernel_sin.S4 = internal constant double 0x3EC71DE357B1FE7D, align 8, !dbg !378
@__kernel_sin.S5 = internal constant double 0xBE5AE5E68A2B9CEB, align 8, !dbg !380
@__kernel_sin.S6 = internal constant double 0x3DE5D93A5ACFD57C, align 8, !dbg !382
@__kernel_tan.xxx = internal constant [16 x double] [double 0x3FD5555555555563, double 0x3FC111111110FE7A, double 0x3FABA1BA1BB341FE, double 0x3F9664F48406D637, double 0x3F8226E3E96E8493, double 0x3F6D6D22C9560328, double 0x3F57DBC8FEE08315, double 0x3F4344D8F2F26501, double 0x3F3026F71A8D1068, double 0x3F147E88A03792A6, double 0x3F12B80F32F0A7E9, double 0xBEF375CBDB605373, double 0x3EFB2A7074BF7AD4, double 1.000000e+00, double 0x3FE921FB54442D18, double 0x3C81A62633145C07], align 8, !dbg !398

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_acos(double noundef %0) #0 !dbg !2 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i64, align 8
  %15 = alloca i32, align 4
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !411, metadata !DIExpression()), !dbg !412
  call void @llvm.dbg.declare(metadata ptr %4, metadata !413, metadata !DIExpression()), !dbg !414
  call void @llvm.dbg.declare(metadata ptr %5, metadata !415, metadata !DIExpression()), !dbg !416
  call void @llvm.dbg.declare(metadata ptr %6, metadata !417, metadata !DIExpression()), !dbg !418
  call void @llvm.dbg.declare(metadata ptr %7, metadata !419, metadata !DIExpression()), !dbg !420
  call void @llvm.dbg.declare(metadata ptr %8, metadata !421, metadata !DIExpression()), !dbg !422
  call void @llvm.dbg.declare(metadata ptr %9, metadata !423, metadata !DIExpression()), !dbg !424
  call void @llvm.dbg.declare(metadata ptr %10, metadata !425, metadata !DIExpression()), !dbg !426
  call void @llvm.dbg.declare(metadata ptr %11, metadata !427, metadata !DIExpression()), !dbg !428
  call void @llvm.dbg.declare(metadata ptr %12, metadata !429, metadata !DIExpression()), !dbg !430
  call void @llvm.dbg.declare(metadata ptr %13, metadata !431, metadata !DIExpression()), !dbg !432
  br label %18, !dbg !433

18:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %14, metadata !434, metadata !DIExpression()), !dbg !436
  %19 = load double, ptr %3, align 8, !dbg !436
  %20 = call i64 @bits_of(double noundef %19), !dbg !436
  store i64 %20, ptr %14, align 8, !dbg !436
  %21 = load i64, ptr %14, align 8, !dbg !436
  %22 = lshr i64 %21, 32, !dbg !436
  %23 = trunc i64 %22 to i32, !dbg !436
  store i32 %23, ptr %12, align 4, !dbg !436
  br label %24, !dbg !436

24:                                               ; preds = %18
  %25 = load i32, ptr %12, align 4, !dbg !437
  %26 = and i32 %25, 2147483647, !dbg !438
  store i32 %26, ptr %13, align 4, !dbg !439
  %27 = load i32, ptr %13, align 4, !dbg !440
  %28 = icmp sge i32 %27, 1072693248, !dbg !442
  br i1 %28, label %29, label %48, !dbg !443

29:                                               ; preds = %24
  call void @llvm.dbg.declare(metadata ptr %15, metadata !444, metadata !DIExpression()), !dbg !446
  br label %30, !dbg !447

30:                                               ; preds = %29
  call void @llvm.dbg.declare(metadata ptr %16, metadata !448, metadata !DIExpression()), !dbg !450
  %31 = load double, ptr %3, align 8, !dbg !450
  %32 = call i64 @bits_of(double noundef %31), !dbg !450
  store i64 %32, ptr %16, align 8, !dbg !450
  %33 = load i64, ptr %16, align 8, !dbg !450
  %34 = and i64 %33, 4294967295, !dbg !450
  %35 = trunc i64 %34 to i32, !dbg !450
  store i32 %35, ptr %15, align 4, !dbg !450
  br label %36, !dbg !450

36:                                               ; preds = %30
  %37 = load i32, ptr %13, align 4, !dbg !451
  %38 = sub nsw i32 %37, 1072693248, !dbg !453
  %39 = load i32, ptr %15, align 4, !dbg !454
  %40 = or i32 %38, %39, !dbg !455
  %41 = icmp eq i32 %40, 0, !dbg !456
  br i1 %41, label %42, label %47, !dbg !457

42:                                               ; preds = %36
  %43 = load i32, ptr %12, align 4, !dbg !458
  %44 = icmp sgt i32 %43, 0, !dbg !461
  br i1 %44, label %45, label %46, !dbg !462

45:                                               ; preds = %42
  store double 0.000000e+00, ptr %2, align 8, !dbg !463
  br label %185, !dbg !463

46:                                               ; preds = %42
  store double 0x400921FB54442D18, ptr %2, align 8, !dbg !464
  br label %185, !dbg !464

47:                                               ; preds = %36
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !465
  br label %185, !dbg !465

48:                                               ; preds = %24
  %49 = load i32, ptr %13, align 4, !dbg !466
  %50 = icmp slt i32 %49, 1071644672, !dbg !468
  br i1 %50, label %51, label %89, !dbg !469

51:                                               ; preds = %48
  %52 = load i32, ptr %13, align 4, !dbg !470
  %53 = icmp sle i32 %52, 1012924416, !dbg !473
  br i1 %53, label %54, label %55, !dbg !474

54:                                               ; preds = %51
  store double 0x3FF921FB54442D18, ptr %2, align 8, !dbg !475
  br label %185, !dbg !475

55:                                               ; preds = %51
  %56 = load double, ptr %3, align 8, !dbg !476
  %57 = load double, ptr %3, align 8, !dbg !477
  %58 = fmul double %56, %57, !dbg !478
  store double %58, ptr %4, align 8, !dbg !479
  %59 = load double, ptr %4, align 8, !dbg !480
  %60 = load double, ptr %4, align 8, !dbg !481
  %61 = load double, ptr %4, align 8, !dbg !482
  %62 = load double, ptr %4, align 8, !dbg !483
  %63 = load double, ptr %4, align 8, !dbg !484
  %64 = load double, ptr %4, align 8, !dbg !485
  %65 = call double @llvm.fmuladd.f64(double %64, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !486
  %66 = call double @llvm.fmuladd.f64(double %63, double %65, double 0xBFA48228B5688F3B), !dbg !487
  %67 = call double @llvm.fmuladd.f64(double %62, double %66, double 0x3FC9C1550E884455), !dbg !488
  %68 = call double @llvm.fmuladd.f64(double %61, double %67, double 0xBFD4D61203EB6F7D), !dbg !489
  %69 = call double @llvm.fmuladd.f64(double %60, double %68, double 0x3FC5555555555555), !dbg !490
  %70 = fmul double %59, %69, !dbg !491
  store double %70, ptr %5, align 8, !dbg !492
  %71 = load double, ptr %4, align 8, !dbg !493
  %72 = load double, ptr %4, align 8, !dbg !494
  %73 = load double, ptr %4, align 8, !dbg !495
  %74 = load double, ptr %4, align 8, !dbg !496
  %75 = call double @llvm.fmuladd.f64(double %74, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !497
  %76 = call double @llvm.fmuladd.f64(double %73, double %75, double 0x40002AE59C598AC8), !dbg !498
  %77 = call double @llvm.fmuladd.f64(double %72, double %76, double 0xC0033A271C8A2D4B), !dbg !499
  %78 = call double @llvm.fmuladd.f64(double %71, double %77, double 1.000000e+00), !dbg !500
  store double %78, ptr %6, align 8, !dbg !501
  %79 = load double, ptr %5, align 8, !dbg !502
  %80 = load double, ptr %6, align 8, !dbg !503
  %81 = fdiv double %79, %80, !dbg !504
  store double %81, ptr %7, align 8, !dbg !505
  %82 = load double, ptr %3, align 8, !dbg !506
  %83 = load double, ptr %3, align 8, !dbg !507
  %84 = load double, ptr %7, align 8, !dbg !508
  %85 = fneg double %83, !dbg !509
  %86 = call double @llvm.fmuladd.f64(double %85, double %84, double 0x3C91A62633145C07), !dbg !509
  %87 = fsub double %82, %86, !dbg !510
  %88 = fsub double 0x3FF921FB54442D18, %87, !dbg !511
  store double %88, ptr %2, align 8, !dbg !512
  br label %185, !dbg !512

89:                                               ; preds = %48
  %90 = load i32, ptr %12, align 4, !dbg !513
  %91 = icmp slt i32 %90, 0, !dbg !515
  br i1 %91, label %92, label %128, !dbg !516

92:                                               ; preds = %89
  %93 = load double, ptr %3, align 8, !dbg !517
  %94 = fadd double 1.000000e+00, %93, !dbg !519
  %95 = fmul double %94, 5.000000e-01, !dbg !520
  store double %95, ptr %4, align 8, !dbg !521
  %96 = load double, ptr %4, align 8, !dbg !522
  %97 = load double, ptr %4, align 8, !dbg !523
  %98 = load double, ptr %4, align 8, !dbg !524
  %99 = load double, ptr %4, align 8, !dbg !525
  %100 = load double, ptr %4, align 8, !dbg !526
  %101 = load double, ptr %4, align 8, !dbg !527
  %102 = call double @llvm.fmuladd.f64(double %101, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !528
  %103 = call double @llvm.fmuladd.f64(double %100, double %102, double 0xBFA48228B5688F3B), !dbg !529
  %104 = call double @llvm.fmuladd.f64(double %99, double %103, double 0x3FC9C1550E884455), !dbg !530
  %105 = call double @llvm.fmuladd.f64(double %98, double %104, double 0xBFD4D61203EB6F7D), !dbg !531
  %106 = call double @llvm.fmuladd.f64(double %97, double %105, double 0x3FC5555555555555), !dbg !532
  %107 = fmul double %96, %106, !dbg !533
  store double %107, ptr %5, align 8, !dbg !534
  %108 = load double, ptr %4, align 8, !dbg !535
  %109 = load double, ptr %4, align 8, !dbg !536
  %110 = load double, ptr %4, align 8, !dbg !537
  %111 = load double, ptr %4, align 8, !dbg !538
  %112 = call double @llvm.fmuladd.f64(double %111, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !539
  %113 = call double @llvm.fmuladd.f64(double %110, double %112, double 0x40002AE59C598AC8), !dbg !540
  %114 = call double @llvm.fmuladd.f64(double %109, double %113, double 0xC0033A271C8A2D4B), !dbg !541
  %115 = call double @llvm.fmuladd.f64(double %108, double %114, double 1.000000e+00), !dbg !542
  store double %115, ptr %6, align 8, !dbg !543
  %116 = load double, ptr %4, align 8, !dbg !544
  %117 = call double @llvm.sqrt.f64(double %116), !dbg !545
  store double %117, ptr %9, align 8, !dbg !546
  %118 = load double, ptr %5, align 8, !dbg !547
  %119 = load double, ptr %6, align 8, !dbg !548
  %120 = fdiv double %118, %119, !dbg !549
  store double %120, ptr %7, align 8, !dbg !550
  %121 = load double, ptr %7, align 8, !dbg !551
  %122 = load double, ptr %9, align 8, !dbg !552
  %123 = call double @llvm.fmuladd.f64(double %121, double %122, double 0xBC91A62633145C07), !dbg !553
  store double %123, ptr %8, align 8, !dbg !554
  %124 = load double, ptr %9, align 8, !dbg !555
  %125 = load double, ptr %8, align 8, !dbg !556
  %126 = fadd double %124, %125, !dbg !557
  %127 = call double @llvm.fmuladd.f64(double -2.000000e+00, double %126, double 0x400921FB54442D18), !dbg !558
  store double %127, ptr %2, align 8, !dbg !559
  br label %185, !dbg !559

128:                                              ; preds = %89
  %129 = load double, ptr %3, align 8, !dbg !560
  %130 = fsub double 1.000000e+00, %129, !dbg !562
  %131 = fmul double %130, 5.000000e-01, !dbg !563
  store double %131, ptr %4, align 8, !dbg !564
  %132 = load double, ptr %4, align 8, !dbg !565
  %133 = call double @llvm.sqrt.f64(double %132), !dbg !566
  store double %133, ptr %9, align 8, !dbg !567
  %134 = load double, ptr %9, align 8, !dbg !568
  store double %134, ptr %11, align 8, !dbg !569
  br label %135, !dbg !570

135:                                              ; preds = %128
  call void @llvm.dbg.declare(metadata ptr %17, metadata !571, metadata !DIExpression()), !dbg !573
  %136 = load double, ptr %11, align 8, !dbg !573
  %137 = call i64 @bits_of(double noundef %136), !dbg !573
  store i64 %137, ptr %17, align 8, !dbg !573
  %138 = load i64, ptr %17, align 8, !dbg !573
  %139 = and i64 %138, -4294967296, !dbg !573
  store i64 %139, ptr %17, align 8, !dbg !573
  %140 = load i64, ptr %17, align 8, !dbg !573
  %141 = or i64 %140, 0, !dbg !573
  store i64 %141, ptr %17, align 8, !dbg !573
  %142 = load i64, ptr %17, align 8, !dbg !573
  %143 = call double @double_of(i64 noundef %142), !dbg !573
  store double %143, ptr %11, align 8, !dbg !573
  br label %144, !dbg !573

144:                                              ; preds = %135
  %145 = load double, ptr %4, align 8, !dbg !574
  %146 = load double, ptr %11, align 8, !dbg !575
  %147 = load double, ptr %11, align 8, !dbg !576
  %148 = fneg double %146, !dbg !577
  %149 = call double @llvm.fmuladd.f64(double %148, double %147, double %145), !dbg !577
  %150 = load double, ptr %9, align 8, !dbg !578
  %151 = load double, ptr %11, align 8, !dbg !579
  %152 = fadd double %150, %151, !dbg !580
  %153 = fdiv double %149, %152, !dbg !581
  store double %153, ptr %10, align 8, !dbg !582
  %154 = load double, ptr %4, align 8, !dbg !583
  %155 = load double, ptr %4, align 8, !dbg !584
  %156 = load double, ptr %4, align 8, !dbg !585
  %157 = load double, ptr %4, align 8, !dbg !586
  %158 = load double, ptr %4, align 8, !dbg !587
  %159 = load double, ptr %4, align 8, !dbg !588
  %160 = call double @llvm.fmuladd.f64(double %159, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !589
  %161 = call double @llvm.fmuladd.f64(double %158, double %160, double 0xBFA48228B5688F3B), !dbg !590
  %162 = call double @llvm.fmuladd.f64(double %157, double %161, double 0x3FC9C1550E884455), !dbg !591
  %163 = call double @llvm.fmuladd.f64(double %156, double %162, double 0xBFD4D61203EB6F7D), !dbg !592
  %164 = call double @llvm.fmuladd.f64(double %155, double %163, double 0x3FC5555555555555), !dbg !593
  %165 = fmul double %154, %164, !dbg !594
  store double %165, ptr %5, align 8, !dbg !595
  %166 = load double, ptr %4, align 8, !dbg !596
  %167 = load double, ptr %4, align 8, !dbg !597
  %168 = load double, ptr %4, align 8, !dbg !598
  %169 = load double, ptr %4, align 8, !dbg !599
  %170 = call double @llvm.fmuladd.f64(double %169, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !600
  %171 = call double @llvm.fmuladd.f64(double %168, double %170, double 0x40002AE59C598AC8), !dbg !601
  %172 = call double @llvm.fmuladd.f64(double %167, double %171, double 0xC0033A271C8A2D4B), !dbg !602
  %173 = call double @llvm.fmuladd.f64(double %166, double %172, double 1.000000e+00), !dbg !603
  store double %173, ptr %6, align 8, !dbg !604
  %174 = load double, ptr %5, align 8, !dbg !605
  %175 = load double, ptr %6, align 8, !dbg !606
  %176 = fdiv double %174, %175, !dbg !607
  store double %176, ptr %7, align 8, !dbg !608
  %177 = load double, ptr %7, align 8, !dbg !609
  %178 = load double, ptr %9, align 8, !dbg !610
  %179 = load double, ptr %10, align 8, !dbg !611
  %180 = call double @llvm.fmuladd.f64(double %177, double %178, double %179), !dbg !612
  store double %180, ptr %8, align 8, !dbg !613
  %181 = load double, ptr %11, align 8, !dbg !614
  %182 = load double, ptr %8, align 8, !dbg !615
  %183 = fadd double %181, %182, !dbg !616
  %184 = fmul double 2.000000e+00, %183, !dbg !617
  store double %184, ptr %2, align 8, !dbg !618
  br label %185, !dbg !618

185:                                              ; preds = %144, %92, %55, %54, %47, %46, %45
  %186 = load double, ptr %2, align 8, !dbg !619
  ret double %186, !dbg !619
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i64 @bits_of(double noundef %0) #0 !dbg !620 {
  %2 = alloca double, align 8
  %3 = alloca i64, align 8
  store double %0, ptr %2, align 8
  call void @llvm.dbg.declare(metadata ptr %2, metadata !623, metadata !DIExpression()), !dbg !624
  call void @llvm.dbg.declare(metadata ptr %3, metadata !625, metadata !DIExpression()), !dbg !626
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %2, i64 8, i1 false), !dbg !627
  %4 = load i64, ptr %3, align 8, !dbg !628
  ret i64 %4, !dbg !629
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal double @double_of(i64 noundef %0) #0 !dbg !630 {
  %2 = alloca i64, align 8
  %3 = alloca double, align 8
  store i64 %0, ptr %2, align 8
  call void @llvm.dbg.declare(metadata ptr %2, metadata !633, metadata !DIExpression()), !dbg !634
  call void @llvm.dbg.declare(metadata ptr %3, metadata !635, metadata !DIExpression()), !dbg !636
  call void @llvm.memcpy.p0.p0.i64(ptr align 8 %3, ptr align 8 %2, i64 8, i1 false), !dbg !637
  %4 = load double, ptr %3, align 8, !dbg !638
  ret double %4, !dbg !639
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_acosh(double noundef %0) #0 !dbg !49 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !640, metadata !DIExpression()), !dbg !641
  call void @llvm.dbg.declare(metadata ptr %4, metadata !642, metadata !DIExpression()), !dbg !643
  call void @llvm.dbg.declare(metadata ptr %5, metadata !644, metadata !DIExpression()), !dbg !645
  call void @llvm.dbg.declare(metadata ptr %6, metadata !646, metadata !DIExpression()), !dbg !647
  br label %8, !dbg !648

8:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %7, metadata !649, metadata !DIExpression()), !dbg !651
  %9 = load double, ptr %3, align 8, !dbg !651
  %10 = call i64 @bits_of(double noundef %9), !dbg !651
  store i64 %10, ptr %7, align 8, !dbg !651
  %11 = load i64, ptr %7, align 8, !dbg !651
  %12 = lshr i64 %11, 32, !dbg !651
  %13 = trunc i64 %12 to i32, !dbg !651
  store i32 %13, ptr %5, align 4, !dbg !651
  %14 = load i64, ptr %7, align 8, !dbg !651
  %15 = and i64 %14, 4294967295, !dbg !651
  %16 = trunc i64 %15 to i32, !dbg !651
  store i32 %16, ptr %6, align 4, !dbg !651
  br label %17, !dbg !651

17:                                               ; preds = %8
  %18 = load i32, ptr %5, align 4, !dbg !652
  %19 = icmp slt i32 %18, 1072693248, !dbg !654
  br i1 %19, label %20, label %21, !dbg !655

20:                                               ; preds = %17
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !656
  br label %71, !dbg !656

21:                                               ; preds = %17
  %22 = load i32, ptr %5, align 4, !dbg !658
  %23 = icmp sge i32 %22, 1102053376, !dbg !660
  br i1 %23, label %24, label %35, !dbg !661

24:                                               ; preds = %21
  %25 = load i32, ptr %5, align 4, !dbg !662
  %26 = icmp sge i32 %25, 2146435072, !dbg !665
  br i1 %26, label %27, label %31, !dbg !666

27:                                               ; preds = %24
  %28 = load double, ptr %3, align 8, !dbg !667
  %29 = load double, ptr %3, align 8, !dbg !669
  %30 = fadd double %28, %29, !dbg !670
  store double %30, ptr %2, align 8, !dbg !671
  br label %71, !dbg !671

31:                                               ; preds = %24
  %32 = load double, ptr %3, align 8, !dbg !672
  %33 = call double @pts_ieee754_log(double noundef %32), !dbg !674
  %34 = fadd double %33, 0x3FE62E42FEFA39EF, !dbg !675
  store double %34, ptr %2, align 8, !dbg !676
  br label %71, !dbg !676

35:                                               ; preds = %21
  %36 = load i32, ptr %5, align 4, !dbg !677
  %37 = sub nsw i32 %36, 1072693248, !dbg !679
  %38 = load i32, ptr %6, align 4, !dbg !680
  %39 = or i32 %37, %38, !dbg !681
  %40 = icmp eq i32 %39, 0, !dbg !682
  br i1 %40, label %41, label %42, !dbg !683

41:                                               ; preds = %35
  store double 0.000000e+00, ptr %2, align 8, !dbg !684
  br label %71, !dbg !684

42:                                               ; preds = %35
  %43 = load i32, ptr %5, align 4, !dbg !686
  %44 = icmp sgt i32 %43, 1073741824, !dbg !688
  br i1 %44, label %45, label %59, !dbg !689

45:                                               ; preds = %42
  %46 = load double, ptr %3, align 8, !dbg !690
  %47 = load double, ptr %3, align 8, !dbg !692
  %48 = fmul double %46, %47, !dbg !693
  store double %48, ptr %4, align 8, !dbg !694
  %49 = load double, ptr %3, align 8, !dbg !695
  %50 = load double, ptr %3, align 8, !dbg !696
  %51 = load double, ptr %4, align 8, !dbg !697
  %52 = fsub double %51, 1.000000e+00, !dbg !698
  %53 = call double @llvm.sqrt.f64(double %52), !dbg !699
  %54 = fadd double %50, %53, !dbg !700
  %55 = fdiv double 1.000000e+00, %54, !dbg !701
  %56 = fneg double %55, !dbg !702
  %57 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %49, double %56), !dbg !702
  %58 = call double @pts_ieee754_log(double noundef %57), !dbg !703
  store double %58, ptr %2, align 8, !dbg !704
  br label %71, !dbg !704

59:                                               ; preds = %42
  %60 = load double, ptr %3, align 8, !dbg !705
  %61 = fsub double %60, 1.000000e+00, !dbg !707
  store double %61, ptr %4, align 8, !dbg !708
  %62 = load double, ptr %4, align 8, !dbg !709
  %63 = load double, ptr %4, align 8, !dbg !710
  %64 = load double, ptr %4, align 8, !dbg !711
  %65 = load double, ptr %4, align 8, !dbg !712
  %66 = fmul double %64, %65, !dbg !713
  %67 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %63, double %66), !dbg !714
  %68 = call double @llvm.sqrt.f64(double %67), !dbg !715
  %69 = fadd double %62, %68, !dbg !716
  %70 = call double @pts_ieee754_log1p(double noundef %69), !dbg !717
  store double %70, ptr %2, align 8, !dbg !718
  br label %71, !dbg !718

71:                                               ; preds = %59, %45, %41, %31, %27, %20
  %72 = load double, ptr %2, align 8, !dbg !719
  ret double %72, !dbg !719
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_log(double noundef %0) #0 !dbg !168 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i64, align 8
  %19 = alloca i64, align 8
  %20 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !720, metadata !DIExpression()), !dbg !721
  call void @llvm.dbg.declare(metadata ptr %4, metadata !722, metadata !DIExpression()), !dbg !723
  call void @llvm.dbg.declare(metadata ptr %5, metadata !724, metadata !DIExpression()), !dbg !725
  call void @llvm.dbg.declare(metadata ptr %6, metadata !726, metadata !DIExpression()), !dbg !727
  call void @llvm.dbg.declare(metadata ptr %7, metadata !728, metadata !DIExpression()), !dbg !729
  call void @llvm.dbg.declare(metadata ptr %8, metadata !730, metadata !DIExpression()), !dbg !731
  call void @llvm.dbg.declare(metadata ptr %9, metadata !732, metadata !DIExpression()), !dbg !733
  call void @llvm.dbg.declare(metadata ptr %10, metadata !734, metadata !DIExpression()), !dbg !735
  call void @llvm.dbg.declare(metadata ptr %11, metadata !736, metadata !DIExpression()), !dbg !737
  call void @llvm.dbg.declare(metadata ptr %12, metadata !738, metadata !DIExpression()), !dbg !739
  call void @llvm.dbg.declare(metadata ptr %13, metadata !740, metadata !DIExpression()), !dbg !741
  call void @llvm.dbg.declare(metadata ptr %14, metadata !742, metadata !DIExpression()), !dbg !743
  call void @llvm.dbg.declare(metadata ptr %15, metadata !744, metadata !DIExpression()), !dbg !745
  call void @llvm.dbg.declare(metadata ptr %16, metadata !746, metadata !DIExpression()), !dbg !747
  call void @llvm.dbg.declare(metadata ptr %17, metadata !748, metadata !DIExpression()), !dbg !749
  br label %21, !dbg !750

21:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %18, metadata !751, metadata !DIExpression()), !dbg !753
  %22 = load double, ptr %3, align 8, !dbg !753
  %23 = call i64 @bits_of(double noundef %22), !dbg !753
  store i64 %23, ptr %18, align 8, !dbg !753
  %24 = load i64, ptr %18, align 8, !dbg !753
  %25 = lshr i64 %24, 32, !dbg !753
  %26 = trunc i64 %25 to i32, !dbg !753
  store i32 %26, ptr %14, align 4, !dbg !753
  %27 = load i64, ptr %18, align 8, !dbg !753
  %28 = and i64 %27, 4294967295, !dbg !753
  %29 = trunc i64 %28 to i32, !dbg !753
  store i32 %29, ptr %17, align 4, !dbg !753
  br label %30, !dbg !753

30:                                               ; preds = %21
  store i32 0, ptr %13, align 4, !dbg !754
  %31 = load i32, ptr %14, align 4, !dbg !755
  %32 = icmp slt i32 %31, 1048576, !dbg !757
  br i1 %32, label %33, label %56, !dbg !758

33:                                               ; preds = %30
  %34 = load i32, ptr %14, align 4, !dbg !759
  %35 = and i32 %34, 2147483647, !dbg !762
  %36 = load i32, ptr %17, align 4, !dbg !763
  %37 = or i32 %35, %36, !dbg !764
  %38 = icmp eq i32 %37, 0, !dbg !765
  br i1 %38, label %39, label %40, !dbg !766

39:                                               ; preds = %33
  store double 0xFFF0000000000000, ptr %2, align 8, !dbg !767
  br label %235, !dbg !767

40:                                               ; preds = %33
  %41 = load i32, ptr %14, align 4, !dbg !769
  %42 = icmp slt i32 %41, 0, !dbg !771
  br i1 %42, label %43, label %44, !dbg !772

43:                                               ; preds = %40
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !773
  br label %235, !dbg !773

44:                                               ; preds = %40
  %45 = load i32, ptr %13, align 4, !dbg !775
  %46 = sub nsw i32 %45, 54, !dbg !775
  store i32 %46, ptr %13, align 4, !dbg !775
  %47 = load double, ptr %3, align 8, !dbg !776
  %48 = fmul double %47, 0x4350000000000000, !dbg !776
  store double %48, ptr %3, align 8, !dbg !776
  br label %49, !dbg !777

49:                                               ; preds = %44
  call void @llvm.dbg.declare(metadata ptr %19, metadata !778, metadata !DIExpression()), !dbg !780
  %50 = load double, ptr %3, align 8, !dbg !780
  %51 = call i64 @bits_of(double noundef %50), !dbg !780
  store i64 %51, ptr %19, align 8, !dbg !780
  %52 = load i64, ptr %19, align 8, !dbg !780
  %53 = lshr i64 %52, 32, !dbg !780
  %54 = trunc i64 %53 to i32, !dbg !780
  store i32 %54, ptr %14, align 4, !dbg !780
  br label %55, !dbg !780

55:                                               ; preds = %49
  br label %56, !dbg !781

56:                                               ; preds = %55, %30
  %57 = load i32, ptr %14, align 4, !dbg !782
  %58 = icmp sge i32 %57, 2146435072, !dbg !784
  br i1 %58, label %59, label %63, !dbg !785

59:                                               ; preds = %56
  %60 = load double, ptr %3, align 8, !dbg !786
  %61 = load double, ptr %3, align 8, !dbg !787
  %62 = fadd double %60, %61, !dbg !788
  store double %62, ptr %2, align 8, !dbg !789
  br label %235, !dbg !789

63:                                               ; preds = %56
  %64 = load i32, ptr %14, align 4, !dbg !790
  %65 = ashr i32 %64, 20, !dbg !791
  %66 = sub nsw i32 %65, 1023, !dbg !792
  %67 = load i32, ptr %13, align 4, !dbg !793
  %68 = add nsw i32 %67, %66, !dbg !793
  store i32 %68, ptr %13, align 4, !dbg !793
  %69 = load i32, ptr %14, align 4, !dbg !794
  %70 = and i32 %69, 1048575, !dbg !794
  store i32 %70, ptr %14, align 4, !dbg !794
  %71 = load i32, ptr %14, align 4, !dbg !795
  %72 = add nsw i32 %71, 614244, !dbg !796
  %73 = and i32 %72, 1048576, !dbg !797
  store i32 %73, ptr %15, align 4, !dbg !798
  br label %74, !dbg !799

74:                                               ; preds = %63
  call void @llvm.dbg.declare(metadata ptr %20, metadata !800, metadata !DIExpression()), !dbg !802
  %75 = load double, ptr %3, align 8, !dbg !802
  %76 = call i64 @bits_of(double noundef %75), !dbg !802
  store i64 %76, ptr %20, align 8, !dbg !802
  %77 = load i64, ptr %20, align 8, !dbg !802
  %78 = and i64 %77, 4294967295, !dbg !802
  store i64 %78, ptr %20, align 8, !dbg !802
  %79 = load i32, ptr %14, align 4, !dbg !802
  %80 = load i32, ptr %15, align 4, !dbg !802
  %81 = xor i32 %80, 1072693248, !dbg !802
  %82 = or i32 %79, %81, !dbg !802
  %83 = sext i32 %82 to i64, !dbg !802
  %84 = shl i64 %83, 32, !dbg !802
  %85 = load i64, ptr %20, align 8, !dbg !802
  %86 = or i64 %85, %84, !dbg !802
  store i64 %86, ptr %20, align 8, !dbg !802
  %87 = load i64, ptr %20, align 8, !dbg !802
  %88 = call double @double_of(i64 noundef %87), !dbg !802
  store double %88, ptr %3, align 8, !dbg !802
  br label %89, !dbg !802

89:                                               ; preds = %74
  %90 = load i32, ptr %15, align 4, !dbg !803
  %91 = ashr i32 %90, 20, !dbg !804
  %92 = load i32, ptr %13, align 4, !dbg !805
  %93 = add nsw i32 %92, %91, !dbg !805
  store i32 %93, ptr %13, align 4, !dbg !805
  %94 = load double, ptr %3, align 8, !dbg !806
  %95 = fsub double %94, 1.000000e+00, !dbg !807
  store double %95, ptr %5, align 8, !dbg !808
  %96 = load i32, ptr %14, align 4, !dbg !809
  %97 = add nsw i32 2, %96, !dbg !811
  %98 = and i32 1048575, %97, !dbg !812
  %99 = icmp slt i32 %98, 3, !dbg !813
  br i1 %99, label %100, label %139, !dbg !814

100:                                              ; preds = %89
  %101 = load double, ptr %5, align 8, !dbg !815
  %102 = fcmp oeq double %101, 0.000000e+00, !dbg !818
  br i1 %102, label %103, label %114, !dbg !819

103:                                              ; preds = %100
  %104 = load i32, ptr %13, align 4, !dbg !820
  %105 = icmp eq i32 %104, 0, !dbg !823
  br i1 %105, label %106, label %107, !dbg !824

106:                                              ; preds = %103
  store double 0.000000e+00, ptr %2, align 8, !dbg !825
  br label %235, !dbg !825

107:                                              ; preds = %103
  %108 = load i32, ptr %13, align 4, !dbg !827
  %109 = sitofp i32 %108 to double, !dbg !829
  store double %109, ptr %12, align 8, !dbg !830
  %110 = load double, ptr %12, align 8, !dbg !831
  %111 = load double, ptr %12, align 8, !dbg !832
  %112 = fmul double %111, 0x3DEA39EF35793C76, !dbg !833
  %113 = call double @llvm.fmuladd.f64(double %110, double 0x3FE62E42FEE00000, double %112), !dbg !834
  store double %113, ptr %2, align 8, !dbg !835
  br label %235, !dbg !835

114:                                              ; preds = %100
  %115 = load double, ptr %5, align 8, !dbg !836
  %116 = load double, ptr %5, align 8, !dbg !837
  %117 = fmul double %115, %116, !dbg !838
  %118 = load double, ptr %5, align 8, !dbg !839
  %119 = call double @llvm.fmuladd.f64(double 0xBFD5555555555555, double %118, double 5.000000e-01), !dbg !840
  %120 = fmul double %117, %119, !dbg !841
  store double %120, ptr %8, align 8, !dbg !842
  %121 = load i32, ptr %13, align 4, !dbg !843
  %122 = icmp eq i32 %121, 0, !dbg !845
  br i1 %122, label %123, label %127, !dbg !846

123:                                              ; preds = %114
  %124 = load double, ptr %5, align 8, !dbg !847
  %125 = load double, ptr %8, align 8, !dbg !849
  %126 = fsub double %124, %125, !dbg !850
  store double %126, ptr %2, align 8, !dbg !851
  br label %235, !dbg !851

127:                                              ; preds = %114
  %128 = load i32, ptr %13, align 4, !dbg !852
  %129 = sitofp i32 %128 to double, !dbg !854
  store double %129, ptr %12, align 8, !dbg !855
  %130 = load double, ptr %12, align 8, !dbg !856
  %131 = load double, ptr %8, align 8, !dbg !857
  %132 = load double, ptr %12, align 8, !dbg !858
  %133 = fneg double %132, !dbg !859
  %134 = call double @llvm.fmuladd.f64(double %133, double 0x3DEA39EF35793C76, double %131), !dbg !859
  %135 = load double, ptr %5, align 8, !dbg !860
  %136 = fsub double %134, %135, !dbg !861
  %137 = fneg double %136, !dbg !862
  %138 = call double @llvm.fmuladd.f64(double %130, double 0x3FE62E42FEE00000, double %137), !dbg !862
  store double %138, ptr %2, align 8, !dbg !863
  br label %235, !dbg !863

139:                                              ; preds = %89
  %140 = load double, ptr %5, align 8, !dbg !864
  %141 = load double, ptr %5, align 8, !dbg !865
  %142 = fadd double 2.000000e+00, %141, !dbg !866
  %143 = fdiv double %140, %142, !dbg !867
  store double %143, ptr %6, align 8, !dbg !868
  %144 = load i32, ptr %13, align 4, !dbg !869
  %145 = sitofp i32 %144 to double, !dbg !870
  store double %145, ptr %12, align 8, !dbg !871
  %146 = load double, ptr %6, align 8, !dbg !872
  %147 = load double, ptr %6, align 8, !dbg !873
  %148 = fmul double %146, %147, !dbg !874
  store double %148, ptr %7, align 8, !dbg !875
  %149 = load i32, ptr %14, align 4, !dbg !876
  %150 = sub nsw i32 %149, 398458, !dbg !877
  store i32 %150, ptr %15, align 4, !dbg !878
  %151 = load double, ptr %7, align 8, !dbg !879
  %152 = load double, ptr %7, align 8, !dbg !880
  %153 = fmul double %151, %152, !dbg !881
  store double %153, ptr %9, align 8, !dbg !882
  %154 = load i32, ptr %14, align 4, !dbg !883
  %155 = sub nsw i32 440401, %154, !dbg !884
  store i32 %155, ptr %16, align 4, !dbg !885
  %156 = load double, ptr %9, align 8, !dbg !886
  %157 = load double, ptr %9, align 8, !dbg !887
  %158 = load double, ptr %9, align 8, !dbg !888
  %159 = call double @llvm.fmuladd.f64(double %158, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !889
  %160 = call double @llvm.fmuladd.f64(double %157, double %159, double 0x3FD999999997FA04), !dbg !890
  %161 = fmul double %156, %160, !dbg !891
  store double %161, ptr %10, align 8, !dbg !892
  %162 = load double, ptr %7, align 8, !dbg !893
  %163 = load double, ptr %9, align 8, !dbg !894
  %164 = load double, ptr %9, align 8, !dbg !895
  %165 = load double, ptr %9, align 8, !dbg !896
  %166 = call double @llvm.fmuladd.f64(double %165, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !897
  %167 = call double @llvm.fmuladd.f64(double %164, double %166, double 0x3FD2492494229359), !dbg !898
  %168 = call double @llvm.fmuladd.f64(double %163, double %167, double 0x3FE5555555555593), !dbg !899
  %169 = fmul double %162, %168, !dbg !900
  store double %169, ptr %11, align 8, !dbg !901
  %170 = load i32, ptr %16, align 4, !dbg !902
  %171 = load i32, ptr %15, align 4, !dbg !903
  %172 = or i32 %171, %170, !dbg !903
  store i32 %172, ptr %15, align 4, !dbg !903
  %173 = load double, ptr %11, align 8, !dbg !904
  %174 = load double, ptr %10, align 8, !dbg !905
  %175 = fadd double %173, %174, !dbg !906
  store double %175, ptr %8, align 8, !dbg !907
  %176 = load i32, ptr %15, align 4, !dbg !908
  %177 = icmp sgt i32 %176, 0, !dbg !910
  br i1 %177, label %178, label %210, !dbg !911

178:                                              ; preds = %139
  %179 = load double, ptr %5, align 8, !dbg !912
  %180 = fmul double 5.000000e-01, %179, !dbg !914
  %181 = load double, ptr %5, align 8, !dbg !915
  %182 = fmul double %180, %181, !dbg !916
  store double %182, ptr %4, align 8, !dbg !917
  %183 = load i32, ptr %13, align 4, !dbg !918
  %184 = icmp eq i32 %183, 0, !dbg !920
  br i1 %184, label %185, label %195, !dbg !921

185:                                              ; preds = %178
  %186 = load double, ptr %5, align 8, !dbg !922
  %187 = load double, ptr %4, align 8, !dbg !923
  %188 = load double, ptr %6, align 8, !dbg !924
  %189 = load double, ptr %4, align 8, !dbg !925
  %190 = load double, ptr %8, align 8, !dbg !926
  %191 = fadd double %189, %190, !dbg !927
  %192 = fneg double %188, !dbg !928
  %193 = call double @llvm.fmuladd.f64(double %192, double %191, double %187), !dbg !928
  %194 = fsub double %186, %193, !dbg !929
  store double %194, ptr %2, align 8, !dbg !930
  br label %235, !dbg !930

195:                                              ; preds = %178
  %196 = load double, ptr %12, align 8, !dbg !931
  %197 = load double, ptr %4, align 8, !dbg !932
  %198 = load double, ptr %6, align 8, !dbg !933
  %199 = load double, ptr %4, align 8, !dbg !934
  %200 = load double, ptr %8, align 8, !dbg !935
  %201 = fadd double %199, %200, !dbg !936
  %202 = load double, ptr %12, align 8, !dbg !937
  %203 = fmul double %202, 0x3DEA39EF35793C76, !dbg !938
  %204 = call double @llvm.fmuladd.f64(double %198, double %201, double %203), !dbg !939
  %205 = fsub double %197, %204, !dbg !940
  %206 = load double, ptr %5, align 8, !dbg !941
  %207 = fsub double %205, %206, !dbg !942
  %208 = fneg double %207, !dbg !943
  %209 = call double @llvm.fmuladd.f64(double %196, double 0x3FE62E42FEE00000, double %208), !dbg !943
  store double %209, ptr %2, align 8, !dbg !944
  br label %235, !dbg !944

210:                                              ; preds = %139
  %211 = load i32, ptr %13, align 4, !dbg !945
  %212 = icmp eq i32 %211, 0, !dbg !948
  br i1 %212, label %213, label %221, !dbg !949

213:                                              ; preds = %210
  %214 = load double, ptr %5, align 8, !dbg !950
  %215 = load double, ptr %6, align 8, !dbg !951
  %216 = load double, ptr %5, align 8, !dbg !952
  %217 = load double, ptr %8, align 8, !dbg !953
  %218 = fsub double %216, %217, !dbg !954
  %219 = fneg double %215, !dbg !955
  %220 = call double @llvm.fmuladd.f64(double %219, double %218, double %214), !dbg !955
  store double %220, ptr %2, align 8, !dbg !956
  br label %235, !dbg !956

221:                                              ; preds = %210
  %222 = load double, ptr %12, align 8, !dbg !957
  %223 = load double, ptr %6, align 8, !dbg !958
  %224 = load double, ptr %5, align 8, !dbg !959
  %225 = load double, ptr %8, align 8, !dbg !960
  %226 = fsub double %224, %225, !dbg !961
  %227 = load double, ptr %12, align 8, !dbg !962
  %228 = fmul double %227, 0x3DEA39EF35793C76, !dbg !963
  %229 = fneg double %228, !dbg !964
  %230 = call double @llvm.fmuladd.f64(double %223, double %226, double %229), !dbg !964
  %231 = load double, ptr %5, align 8, !dbg !965
  %232 = fsub double %230, %231, !dbg !966
  %233 = fneg double %232, !dbg !967
  %234 = call double @llvm.fmuladd.f64(double %222, double 0x3FE62E42FEE00000, double %233), !dbg !967
  store double %234, ptr %2, align 8, !dbg !968
  br label %235, !dbg !968

235:                                              ; preds = %221, %213, %195, %185, %127, %123, %107, %106, %59, %43, %39
  %236 = load double, ptr %2, align 8, !dbg !969
  ret double %236, !dbg !969
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_log1p(double noundef %0) #0 !dbg !191 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  %18 = alloca i64, align 8
  %19 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !970, metadata !DIExpression()), !dbg !971
  call void @llvm.dbg.declare(metadata ptr %4, metadata !972, metadata !DIExpression()), !dbg !973
  call void @llvm.dbg.declare(metadata ptr %5, metadata !974, metadata !DIExpression()), !dbg !975
  call void @llvm.dbg.declare(metadata ptr %6, metadata !976, metadata !DIExpression()), !dbg !977
  call void @llvm.dbg.declare(metadata ptr %7, metadata !978, metadata !DIExpression()), !dbg !979
  call void @llvm.dbg.declare(metadata ptr %8, metadata !980, metadata !DIExpression()), !dbg !981
  call void @llvm.dbg.declare(metadata ptr %9, metadata !982, metadata !DIExpression()), !dbg !983
  call void @llvm.dbg.declare(metadata ptr %10, metadata !984, metadata !DIExpression()), !dbg !985
  call void @llvm.dbg.declare(metadata ptr %11, metadata !986, metadata !DIExpression()), !dbg !987
  call void @llvm.dbg.declare(metadata ptr %12, metadata !988, metadata !DIExpression()), !dbg !989
  call void @llvm.dbg.declare(metadata ptr %13, metadata !990, metadata !DIExpression()), !dbg !991
  call void @llvm.dbg.declare(metadata ptr %14, metadata !992, metadata !DIExpression()), !dbg !993
  br label %20, !dbg !994

20:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %15, metadata !995, metadata !DIExpression()), !dbg !997
  %21 = load double, ptr %3, align 8, !dbg !997
  %22 = call i64 @bits_of(double noundef %21), !dbg !997
  store i64 %22, ptr %15, align 8, !dbg !997
  %23 = load i64, ptr %15, align 8, !dbg !997
  %24 = lshr i64 %23, 32, !dbg !997
  %25 = trunc i64 %24 to i32, !dbg !997
  store i32 %25, ptr %12, align 4, !dbg !997
  br label %26, !dbg !997

26:                                               ; preds = %20
  %27 = load i32, ptr %12, align 4, !dbg !998
  %28 = and i32 %27, 2147483647, !dbg !999
  store i32 %28, ptr %14, align 4, !dbg !1000
  store i32 1, ptr %11, align 4, !dbg !1001
  %29 = load i32, ptr %12, align 4, !dbg !1002
  %30 = icmp slt i32 %29, 1071284858, !dbg !1004
  br i1 %30, label %31, label %67, !dbg !1005

31:                                               ; preds = %26
  %32 = load i32, ptr %14, align 4, !dbg !1006
  %33 = icmp sge i32 %32, 1072693248, !dbg !1009
  br i1 %33, label %34, label %39, !dbg !1010

34:                                               ; preds = %31
  %35 = load double, ptr %3, align 8, !dbg !1011
  %36 = fcmp oeq double %35, -1.000000e+00, !dbg !1014
  br i1 %36, label %37, label %38, !dbg !1015

37:                                               ; preds = %34
  store double 0xFFF0000000000000, ptr %2, align 8, !dbg !1016
  br label %264, !dbg !1016

38:                                               ; preds = %34
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !1017
  br label %264, !dbg !1017

39:                                               ; preds = %31
  %40 = load i32, ptr %14, align 4, !dbg !1018
  %41 = icmp slt i32 %40, 1042284544, !dbg !1020
  br i1 %41, label %42, label %58, !dbg !1021

42:                                               ; preds = %39
  %43 = load double, ptr %3, align 8, !dbg !1022
  %44 = fadd double 0x4350000000000000, %43, !dbg !1025
  %45 = fcmp ogt double %44, 0.000000e+00, !dbg !1026
  br i1 %45, label %46, label %51, !dbg !1027

46:                                               ; preds = %42
  %47 = load i32, ptr %14, align 4, !dbg !1028
  %48 = icmp slt i32 %47, 1016070144, !dbg !1029
  br i1 %48, label %49, label %51, !dbg !1030

49:                                               ; preds = %46
  %50 = load double, ptr %3, align 8, !dbg !1031
  store double %50, ptr %2, align 8, !dbg !1032
  br label %264, !dbg !1032

51:                                               ; preds = %46, %42
  %52 = load double, ptr %3, align 8, !dbg !1033
  %53 = load double, ptr %3, align 8, !dbg !1034
  %54 = load double, ptr %3, align 8, !dbg !1035
  %55 = fmul double %53, %54, !dbg !1036
  %56 = fneg double %55, !dbg !1037
  %57 = call double @llvm.fmuladd.f64(double %56, double 5.000000e-01, double %52), !dbg !1037
  store double %57, ptr %2, align 8, !dbg !1038
  br label %264, !dbg !1038

58:                                               ; preds = %39
  %59 = load i32, ptr %12, align 4, !dbg !1039
  %60 = icmp sgt i32 %59, 0, !dbg !1041
  br i1 %60, label %64, label %61, !dbg !1042

61:                                               ; preds = %58
  %62 = load i32, ptr %12, align 4, !dbg !1043
  %63 = icmp sle i32 %62, -1076707644, !dbg !1044
  br i1 %63, label %64, label %66, !dbg !1045

64:                                               ; preds = %61, %58
  store i32 0, ptr %11, align 4, !dbg !1046
  %65 = load double, ptr %3, align 8, !dbg !1048
  store double %65, ptr %5, align 8, !dbg !1049
  store i32 1, ptr %13, align 4, !dbg !1050
  br label %66, !dbg !1051

66:                                               ; preds = %64, %61
  br label %67, !dbg !1052

67:                                               ; preds = %66, %26
  %68 = load i32, ptr %12, align 4, !dbg !1053
  %69 = icmp sge i32 %68, 2146435072, !dbg !1055
  br i1 %69, label %70, label %74, !dbg !1056

70:                                               ; preds = %67
  %71 = load double, ptr %3, align 8, !dbg !1057
  %72 = load double, ptr %3, align 8, !dbg !1058
  %73 = fadd double %71, %72, !dbg !1059
  store double %73, ptr %2, align 8, !dbg !1060
  br label %264, !dbg !1060

74:                                               ; preds = %67
  %75 = load i32, ptr %11, align 4, !dbg !1061
  %76 = icmp ne i32 %75, 0, !dbg !1063
  br i1 %76, label %77, label %165, !dbg !1064

77:                                               ; preds = %74
  %78 = load i32, ptr %12, align 4, !dbg !1065
  %79 = icmp slt i32 %78, 1128267776, !dbg !1068
  br i1 %79, label %80, label %110, !dbg !1069

80:                                               ; preds = %77
  %81 = load double, ptr %3, align 8, !dbg !1070
  %82 = fadd double 1.000000e+00, %81, !dbg !1072
  store double %82, ptr %10, align 8, !dbg !1073
  br label %83, !dbg !1074

83:                                               ; preds = %80
  call void @llvm.dbg.declare(metadata ptr %16, metadata !1075, metadata !DIExpression()), !dbg !1077
  %84 = load double, ptr %10, align 8, !dbg !1077
  %85 = call i64 @bits_of(double noundef %84), !dbg !1077
  store i64 %85, ptr %16, align 8, !dbg !1077
  %86 = load i64, ptr %16, align 8, !dbg !1077
  %87 = lshr i64 %86, 32, !dbg !1077
  %88 = trunc i64 %87 to i32, !dbg !1077
  store i32 %88, ptr %13, align 4, !dbg !1077
  br label %89, !dbg !1077

89:                                               ; preds = %83
  %90 = load i32, ptr %13, align 4, !dbg !1078
  %91 = ashr i32 %90, 20, !dbg !1079
  %92 = sub nsw i32 %91, 1023, !dbg !1080
  store i32 %92, ptr %11, align 4, !dbg !1081
  %93 = load i32, ptr %11, align 4, !dbg !1082
  %94 = icmp sgt i32 %93, 0, !dbg !1083
  br i1 %94, label %95, label %100, !dbg !1084

95:                                               ; preds = %89
  %96 = load double, ptr %10, align 8, !dbg !1085
  %97 = load double, ptr %3, align 8, !dbg !1086
  %98 = fsub double %96, %97, !dbg !1087
  %99 = fsub double 1.000000e+00, %98, !dbg !1088
  br label %105, !dbg !1084

100:                                              ; preds = %89
  %101 = load double, ptr %3, align 8, !dbg !1089
  %102 = load double, ptr %10, align 8, !dbg !1090
  %103 = fsub double %102, 1.000000e+00, !dbg !1091
  %104 = fsub double %101, %103, !dbg !1092
  br label %105, !dbg !1084

105:                                              ; preds = %100, %95
  %106 = phi double [ %99, %95 ], [ %104, %100 ], !dbg !1084
  store double %106, ptr %6, align 8, !dbg !1093
  %107 = load double, ptr %10, align 8, !dbg !1094
  %108 = load double, ptr %6, align 8, !dbg !1095
  %109 = fdiv double %108, %107, !dbg !1095
  store double %109, ptr %6, align 8, !dbg !1095
  br label %122, !dbg !1096

110:                                              ; preds = %77
  %111 = load double, ptr %3, align 8, !dbg !1097
  store double %111, ptr %10, align 8, !dbg !1099
  br label %112, !dbg !1100

112:                                              ; preds = %110
  call void @llvm.dbg.declare(metadata ptr %17, metadata !1101, metadata !DIExpression()), !dbg !1103
  %113 = load double, ptr %10, align 8, !dbg !1103
  %114 = call i64 @bits_of(double noundef %113), !dbg !1103
  store i64 %114, ptr %17, align 8, !dbg !1103
  %115 = load i64, ptr %17, align 8, !dbg !1103
  %116 = lshr i64 %115, 32, !dbg !1103
  %117 = trunc i64 %116 to i32, !dbg !1103
  store i32 %117, ptr %13, align 4, !dbg !1103
  br label %118, !dbg !1103

118:                                              ; preds = %112
  %119 = load i32, ptr %13, align 4, !dbg !1104
  %120 = ashr i32 %119, 20, !dbg !1105
  %121 = sub nsw i32 %120, 1023, !dbg !1106
  store i32 %121, ptr %11, align 4, !dbg !1107
  store double 0.000000e+00, ptr %6, align 8, !dbg !1108
  br label %122

122:                                              ; preds = %118, %105
  %123 = load i32, ptr %13, align 4, !dbg !1109
  %124 = and i32 %123, 1048575, !dbg !1109
  store i32 %124, ptr %13, align 4, !dbg !1109
  %125 = load i32, ptr %13, align 4, !dbg !1110
  %126 = icmp slt i32 %125, 434334, !dbg !1112
  br i1 %126, label %127, label %142, !dbg !1113

127:                                              ; preds = %122
  br label %128, !dbg !1114

128:                                              ; preds = %127
  call void @llvm.dbg.declare(metadata ptr %18, metadata !1116, metadata !DIExpression()), !dbg !1118
  %129 = load double, ptr %10, align 8, !dbg !1118
  %130 = call i64 @bits_of(double noundef %129), !dbg !1118
  store i64 %130, ptr %18, align 8, !dbg !1118
  %131 = load i64, ptr %18, align 8, !dbg !1118
  %132 = and i64 %131, 4294967295, !dbg !1118
  store i64 %132, ptr %18, align 8, !dbg !1118
  %133 = load i32, ptr %13, align 4, !dbg !1118
  %134 = or i32 %133, 1072693248, !dbg !1118
  %135 = sext i32 %134 to i64, !dbg !1118
  %136 = shl i64 %135, 32, !dbg !1118
  %137 = load i64, ptr %18, align 8, !dbg !1118
  %138 = or i64 %137, %136, !dbg !1118
  store i64 %138, ptr %18, align 8, !dbg !1118
  %139 = load i64, ptr %18, align 8, !dbg !1118
  %140 = call double @double_of(i64 noundef %139), !dbg !1118
  store double %140, ptr %10, align 8, !dbg !1118
  br label %141, !dbg !1118

141:                                              ; preds = %128
  br label %162, !dbg !1119

142:                                              ; preds = %122
  %143 = load i32, ptr %11, align 4, !dbg !1120
  %144 = add nsw i32 %143, 1, !dbg !1120
  store i32 %144, ptr %11, align 4, !dbg !1120
  br label %145, !dbg !1122

145:                                              ; preds = %142
  call void @llvm.dbg.declare(metadata ptr %19, metadata !1123, metadata !DIExpression()), !dbg !1125
  %146 = load double, ptr %10, align 8, !dbg !1125
  %147 = call i64 @bits_of(double noundef %146), !dbg !1125
  store i64 %147, ptr %19, align 8, !dbg !1125
  %148 = load i64, ptr %19, align 8, !dbg !1125
  %149 = and i64 %148, 4294967295, !dbg !1125
  store i64 %149, ptr %19, align 8, !dbg !1125
  %150 = load i32, ptr %13, align 4, !dbg !1125
  %151 = or i32 %150, 1071644672, !dbg !1125
  %152 = sext i32 %151 to i64, !dbg !1125
  %153 = shl i64 %152, 32, !dbg !1125
  %154 = load i64, ptr %19, align 8, !dbg !1125
  %155 = or i64 %154, %153, !dbg !1125
  store i64 %155, ptr %19, align 8, !dbg !1125
  %156 = load i64, ptr %19, align 8, !dbg !1125
  %157 = call double @double_of(i64 noundef %156), !dbg !1125
  store double %157, ptr %10, align 8, !dbg !1125
  br label %158, !dbg !1125

158:                                              ; preds = %145
  %159 = load i32, ptr %13, align 4, !dbg !1126
  %160 = sub nsw i32 1048576, %159, !dbg !1127
  %161 = ashr i32 %160, 2, !dbg !1128
  store i32 %161, ptr %13, align 4, !dbg !1129
  br label %162

162:                                              ; preds = %158, %141
  %163 = load double, ptr %10, align 8, !dbg !1130
  %164 = fsub double %163, 1.000000e+00, !dbg !1131
  store double %164, ptr %5, align 8, !dbg !1132
  br label %165, !dbg !1133

165:                                              ; preds = %162, %74
  %166 = load double, ptr %5, align 8, !dbg !1134
  %167 = fmul double 5.000000e-01, %166, !dbg !1135
  %168 = load double, ptr %5, align 8, !dbg !1136
  %169 = fmul double %167, %168, !dbg !1137
  store double %169, ptr %4, align 8, !dbg !1138
  %170 = load i32, ptr %13, align 4, !dbg !1139
  %171 = icmp eq i32 %170, 0, !dbg !1141
  br i1 %171, label %172, label %212, !dbg !1142

172:                                              ; preds = %165
  %173 = load double, ptr %5, align 8, !dbg !1143
  %174 = fcmp oeq double %173, 0.000000e+00, !dbg !1146
  br i1 %174, label %175, label %188, !dbg !1147

175:                                              ; preds = %172
  %176 = load i32, ptr %11, align 4, !dbg !1148
  %177 = icmp eq i32 %176, 0, !dbg !1151
  br i1 %177, label %178, label %179, !dbg !1152

178:                                              ; preds = %175
  store double 0.000000e+00, ptr %2, align 8, !dbg !1153
  br label %264, !dbg !1153

179:                                              ; preds = %175
  %180 = load i32, ptr %11, align 4, !dbg !1155
  %181 = sitofp i32 %180 to double, !dbg !1155
  %182 = load double, ptr %6, align 8, !dbg !1157
  %183 = call double @llvm.fmuladd.f64(double %181, double 0x3DEA39EF35793C76, double %182), !dbg !1157
  store double %183, ptr %6, align 8, !dbg !1157
  %184 = load i32, ptr %11, align 4, !dbg !1158
  %185 = sitofp i32 %184 to double, !dbg !1158
  %186 = load double, ptr %6, align 8, !dbg !1159
  %187 = call double @llvm.fmuladd.f64(double %185, double 0x3FE62E42FEE00000, double %186), !dbg !1160
  store double %187, ptr %2, align 8, !dbg !1161
  br label %264, !dbg !1161

188:                                              ; preds = %172
  %189 = load double, ptr %4, align 8, !dbg !1162
  %190 = load double, ptr %5, align 8, !dbg !1163
  %191 = call double @llvm.fmuladd.f64(double 0xBFE5555555555555, double %190, double 1.000000e+00), !dbg !1164
  %192 = fmul double %189, %191, !dbg !1165
  store double %192, ptr %9, align 8, !dbg !1166
  %193 = load i32, ptr %11, align 4, !dbg !1167
  %194 = icmp eq i32 %193, 0, !dbg !1169
  br i1 %194, label %195, label %199, !dbg !1170

195:                                              ; preds = %188
  %196 = load double, ptr %5, align 8, !dbg !1171
  %197 = load double, ptr %9, align 8, !dbg !1172
  %198 = fsub double %196, %197, !dbg !1173
  store double %198, ptr %2, align 8, !dbg !1174
  br label %264, !dbg !1174

199:                                              ; preds = %188
  %200 = load i32, ptr %11, align 4, !dbg !1175
  %201 = sitofp i32 %200 to double, !dbg !1175
  %202 = load double, ptr %9, align 8, !dbg !1176
  %203 = load i32, ptr %11, align 4, !dbg !1177
  %204 = sitofp i32 %203 to double, !dbg !1177
  %205 = load double, ptr %6, align 8, !dbg !1178
  %206 = call double @llvm.fmuladd.f64(double %204, double 0x3DEA39EF35793C76, double %205), !dbg !1179
  %207 = fsub double %202, %206, !dbg !1180
  %208 = load double, ptr %5, align 8, !dbg !1181
  %209 = fsub double %207, %208, !dbg !1182
  %210 = fneg double %209, !dbg !1183
  %211 = call double @llvm.fmuladd.f64(double %201, double 0x3FE62E42FEE00000, double %210), !dbg !1183
  store double %211, ptr %2, align 8, !dbg !1184
  br label %264, !dbg !1184

212:                                              ; preds = %165
  %213 = load double, ptr %5, align 8, !dbg !1185
  %214 = load double, ptr %5, align 8, !dbg !1186
  %215 = fadd double 2.000000e+00, %214, !dbg !1187
  %216 = fdiv double %213, %215, !dbg !1188
  store double %216, ptr %7, align 8, !dbg !1189
  %217 = load double, ptr %7, align 8, !dbg !1190
  %218 = load double, ptr %7, align 8, !dbg !1191
  %219 = fmul double %217, %218, !dbg !1192
  store double %219, ptr %8, align 8, !dbg !1193
  %220 = load double, ptr %8, align 8, !dbg !1194
  %221 = load double, ptr %8, align 8, !dbg !1195
  %222 = load double, ptr %8, align 8, !dbg !1196
  %223 = load double, ptr %8, align 8, !dbg !1197
  %224 = load double, ptr %8, align 8, !dbg !1198
  %225 = load double, ptr %8, align 8, !dbg !1199
  %226 = load double, ptr %8, align 8, !dbg !1200
  %227 = call double @llvm.fmuladd.f64(double %226, double 0x3FC2F112DF3E5244, double 0x3FC39A09D078C69F), !dbg !1201
  %228 = call double @llvm.fmuladd.f64(double %225, double %227, double 0x3FC7466496CB03DE), !dbg !1202
  %229 = call double @llvm.fmuladd.f64(double %224, double %228, double 0x3FCC71C51D8E78AF), !dbg !1203
  %230 = call double @llvm.fmuladd.f64(double %223, double %229, double 0x3FD2492494229359), !dbg !1204
  %231 = call double @llvm.fmuladd.f64(double %222, double %230, double 0x3FD999999997FA04), !dbg !1205
  %232 = call double @llvm.fmuladd.f64(double %221, double %231, double 0x3FE5555555555593), !dbg !1206
  %233 = fmul double %220, %232, !dbg !1207
  store double %233, ptr %9, align 8, !dbg !1208
  %234 = load i32, ptr %11, align 4, !dbg !1209
  %235 = icmp eq i32 %234, 0, !dbg !1211
  br i1 %235, label %236, label %246, !dbg !1212

236:                                              ; preds = %212
  %237 = load double, ptr %5, align 8, !dbg !1213
  %238 = load double, ptr %4, align 8, !dbg !1214
  %239 = load double, ptr %7, align 8, !dbg !1215
  %240 = load double, ptr %4, align 8, !dbg !1216
  %241 = load double, ptr %9, align 8, !dbg !1217
  %242 = fadd double %240, %241, !dbg !1218
  %243 = fneg double %239, !dbg !1219
  %244 = call double @llvm.fmuladd.f64(double %243, double %242, double %238), !dbg !1219
  %245 = fsub double %237, %244, !dbg !1220
  store double %245, ptr %2, align 8, !dbg !1221
  br label %264, !dbg !1221

246:                                              ; preds = %212
  %247 = load i32, ptr %11, align 4, !dbg !1222
  %248 = sitofp i32 %247 to double, !dbg !1222
  %249 = load double, ptr %4, align 8, !dbg !1223
  %250 = load double, ptr %7, align 8, !dbg !1224
  %251 = load double, ptr %4, align 8, !dbg !1225
  %252 = load double, ptr %9, align 8, !dbg !1226
  %253 = fadd double %251, %252, !dbg !1227
  %254 = load i32, ptr %11, align 4, !dbg !1228
  %255 = sitofp i32 %254 to double, !dbg !1228
  %256 = load double, ptr %6, align 8, !dbg !1229
  %257 = call double @llvm.fmuladd.f64(double %255, double 0x3DEA39EF35793C76, double %256), !dbg !1230
  %258 = call double @llvm.fmuladd.f64(double %250, double %253, double %257), !dbg !1231
  %259 = fsub double %249, %258, !dbg !1232
  %260 = load double, ptr %5, align 8, !dbg !1233
  %261 = fsub double %259, %260, !dbg !1234
  %262 = fneg double %261, !dbg !1235
  %263 = call double @llvm.fmuladd.f64(double %248, double 0x3FE62E42FEE00000, double %262), !dbg !1235
  store double %263, ptr %2, align 8, !dbg !1236
  br label %264, !dbg !1236

264:                                              ; preds = %246, %236, %199, %195, %179, %178, %70, %51, %49, %38, %37
  %265 = load double, ptr %2, align 8, !dbg !1237
  ret double %265, !dbg !1237
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_asin(double noundef %0) #0 !dbg !55 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i64, align 8
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !1238, metadata !DIExpression()), !dbg !1239
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1240, metadata !DIExpression()), !dbg !1241
  call void @llvm.dbg.declare(metadata ptr %5, metadata !1242, metadata !DIExpression()), !dbg !1243
  call void @llvm.dbg.declare(metadata ptr %6, metadata !1244, metadata !DIExpression()), !dbg !1245
  call void @llvm.dbg.declare(metadata ptr %7, metadata !1246, metadata !DIExpression()), !dbg !1247
  call void @llvm.dbg.declare(metadata ptr %8, metadata !1248, metadata !DIExpression()), !dbg !1249
  call void @llvm.dbg.declare(metadata ptr %9, metadata !1250, metadata !DIExpression()), !dbg !1251
  call void @llvm.dbg.declare(metadata ptr %10, metadata !1252, metadata !DIExpression()), !dbg !1253
  call void @llvm.dbg.declare(metadata ptr %11, metadata !1254, metadata !DIExpression()), !dbg !1255
  call void @llvm.dbg.declare(metadata ptr %12, metadata !1256, metadata !DIExpression()), !dbg !1257
  store double 0.000000e+00, ptr %4, align 8, !dbg !1258
  br label %17, !dbg !1259

17:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %13, metadata !1260, metadata !DIExpression()), !dbg !1262
  %18 = load double, ptr %3, align 8, !dbg !1262
  %19 = call i64 @bits_of(double noundef %18), !dbg !1262
  store i64 %19, ptr %13, align 8, !dbg !1262
  %20 = load i64, ptr %13, align 8, !dbg !1262
  %21 = lshr i64 %20, 32, !dbg !1262
  %22 = trunc i64 %21 to i32, !dbg !1262
  store i32 %22, ptr %11, align 4, !dbg !1262
  br label %23, !dbg !1262

23:                                               ; preds = %17
  %24 = load i32, ptr %11, align 4, !dbg !1263
  %25 = and i32 %24, 2147483647, !dbg !1264
  store i32 %25, ptr %12, align 4, !dbg !1265
  %26 = load i32, ptr %12, align 4, !dbg !1266
  %27 = icmp sge i32 %26, 1072693248, !dbg !1268
  br i1 %27, label %28, label %47, !dbg !1269

28:                                               ; preds = %23
  call void @llvm.dbg.declare(metadata ptr %14, metadata !1270, metadata !DIExpression()), !dbg !1272
  br label %29, !dbg !1273

29:                                               ; preds = %28
  call void @llvm.dbg.declare(metadata ptr %15, metadata !1274, metadata !DIExpression()), !dbg !1276
  %30 = load double, ptr %3, align 8, !dbg !1276
  %31 = call i64 @bits_of(double noundef %30), !dbg !1276
  store i64 %31, ptr %15, align 8, !dbg !1276
  %32 = load i64, ptr %15, align 8, !dbg !1276
  %33 = and i64 %32, 4294967295, !dbg !1276
  %34 = trunc i64 %33 to i32, !dbg !1276
  store i32 %34, ptr %14, align 4, !dbg !1276
  br label %35, !dbg !1276

35:                                               ; preds = %29
  %36 = load i32, ptr %12, align 4, !dbg !1277
  %37 = sub nsw i32 %36, 1072693248, !dbg !1279
  %38 = load i32, ptr %14, align 4, !dbg !1280
  %39 = or i32 %37, %38, !dbg !1281
  %40 = icmp eq i32 %39, 0, !dbg !1282
  br i1 %40, label %41, label %46, !dbg !1283

41:                                               ; preds = %35
  %42 = load double, ptr %3, align 8, !dbg !1284
  %43 = load double, ptr %3, align 8, !dbg !1286
  %44 = fmul double %43, 0x3C91A62633145C07, !dbg !1287
  %45 = call double @llvm.fmuladd.f64(double %42, double 0x3FF921FB54442D18, double %44), !dbg !1288
  store double %45, ptr %2, align 8, !dbg !1289
  br label %178, !dbg !1289

46:                                               ; preds = %35
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !1290
  br label %178, !dbg !1290

47:                                               ; preds = %23
  %48 = load i32, ptr %12, align 4, !dbg !1291
  %49 = icmp slt i32 %48, 1071644672, !dbg !1293
  br i1 %49, label %50, label %92, !dbg !1294

50:                                               ; preds = %47
  %51 = load i32, ptr %12, align 4, !dbg !1295
  %52 = icmp slt i32 %51, 1044381696, !dbg !1298
  br i1 %52, label %53, label %60, !dbg !1299

53:                                               ; preds = %50
  %54 = load double, ptr %3, align 8, !dbg !1300
  %55 = fadd double 1.000000e+300, %54, !dbg !1303
  %56 = fcmp ogt double %55, 1.000000e+00, !dbg !1304
  br i1 %56, label %57, label %59, !dbg !1305

57:                                               ; preds = %53
  %58 = load double, ptr %3, align 8, !dbg !1306
  store double %58, ptr %2, align 8, !dbg !1307
  br label %178, !dbg !1307

59:                                               ; preds = %53
  br label %64, !dbg !1308

60:                                               ; preds = %50
  %61 = load double, ptr %3, align 8, !dbg !1309
  %62 = load double, ptr %3, align 8, !dbg !1311
  %63 = fmul double %61, %62, !dbg !1312
  store double %63, ptr %4, align 8, !dbg !1313
  br label %64

64:                                               ; preds = %60, %59
  %65 = load double, ptr %4, align 8, !dbg !1314
  %66 = load double, ptr %4, align 8, !dbg !1315
  %67 = load double, ptr %4, align 8, !dbg !1316
  %68 = load double, ptr %4, align 8, !dbg !1317
  %69 = load double, ptr %4, align 8, !dbg !1318
  %70 = load double, ptr %4, align 8, !dbg !1319
  %71 = call double @llvm.fmuladd.f64(double %70, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1320
  %72 = call double @llvm.fmuladd.f64(double %69, double %71, double 0xBFA48228B5688F3B), !dbg !1321
  %73 = call double @llvm.fmuladd.f64(double %68, double %72, double 0x3FC9C1550E884455), !dbg !1322
  %74 = call double @llvm.fmuladd.f64(double %67, double %73, double 0xBFD4D61203EB6F7D), !dbg !1323
  %75 = call double @llvm.fmuladd.f64(double %66, double %74, double 0x3FC5555555555555), !dbg !1324
  %76 = fmul double %65, %75, !dbg !1325
  store double %76, ptr %6, align 8, !dbg !1326
  %77 = load double, ptr %4, align 8, !dbg !1327
  %78 = load double, ptr %4, align 8, !dbg !1328
  %79 = load double, ptr %4, align 8, !dbg !1329
  %80 = load double, ptr %4, align 8, !dbg !1330
  %81 = call double @llvm.fmuladd.f64(double %80, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1331
  %82 = call double @llvm.fmuladd.f64(double %79, double %81, double 0x40002AE59C598AC8), !dbg !1332
  %83 = call double @llvm.fmuladd.f64(double %78, double %82, double 0xC0033A271C8A2D4B), !dbg !1333
  %84 = call double @llvm.fmuladd.f64(double %77, double %83, double 1.000000e+00), !dbg !1334
  store double %84, ptr %7, align 8, !dbg !1335
  %85 = load double, ptr %6, align 8, !dbg !1336
  %86 = load double, ptr %7, align 8, !dbg !1337
  %87 = fdiv double %85, %86, !dbg !1338
  store double %87, ptr %5, align 8, !dbg !1339
  %88 = load double, ptr %3, align 8, !dbg !1340
  %89 = load double, ptr %3, align 8, !dbg !1341
  %90 = load double, ptr %5, align 8, !dbg !1342
  %91 = call double @llvm.fmuladd.f64(double %89, double %90, double %88), !dbg !1343
  store double %91, ptr %2, align 8, !dbg !1344
  br label %178, !dbg !1344

92:                                               ; preds = %47
  br label %93

93:                                               ; preds = %92
  %94 = load double, ptr %3, align 8, !dbg !1345
  %95 = call double @llvm.fabs.f64(double %94), !dbg !1346
  %96 = fsub double 1.000000e+00, %95, !dbg !1347
  store double %96, ptr %5, align 8, !dbg !1348
  %97 = load double, ptr %5, align 8, !dbg !1349
  %98 = fmul double %97, 5.000000e-01, !dbg !1350
  store double %98, ptr %4, align 8, !dbg !1351
  %99 = load double, ptr %4, align 8, !dbg !1352
  %100 = load double, ptr %4, align 8, !dbg !1353
  %101 = load double, ptr %4, align 8, !dbg !1354
  %102 = load double, ptr %4, align 8, !dbg !1355
  %103 = load double, ptr %4, align 8, !dbg !1356
  %104 = load double, ptr %4, align 8, !dbg !1357
  %105 = call double @llvm.fmuladd.f64(double %104, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1358
  %106 = call double @llvm.fmuladd.f64(double %103, double %105, double 0xBFA48228B5688F3B), !dbg !1359
  %107 = call double @llvm.fmuladd.f64(double %102, double %106, double 0x3FC9C1550E884455), !dbg !1360
  %108 = call double @llvm.fmuladd.f64(double %101, double %107, double 0xBFD4D61203EB6F7D), !dbg !1361
  %109 = call double @llvm.fmuladd.f64(double %100, double %108, double 0x3FC5555555555555), !dbg !1362
  %110 = fmul double %99, %109, !dbg !1363
  store double %110, ptr %6, align 8, !dbg !1364
  %111 = load double, ptr %4, align 8, !dbg !1365
  %112 = load double, ptr %4, align 8, !dbg !1366
  %113 = load double, ptr %4, align 8, !dbg !1367
  %114 = load double, ptr %4, align 8, !dbg !1368
  %115 = call double @llvm.fmuladd.f64(double %114, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1369
  %116 = call double @llvm.fmuladd.f64(double %113, double %115, double 0x40002AE59C598AC8), !dbg !1370
  %117 = call double @llvm.fmuladd.f64(double %112, double %116, double 0xC0033A271C8A2D4B), !dbg !1371
  %118 = call double @llvm.fmuladd.f64(double %111, double %117, double 1.000000e+00), !dbg !1372
  store double %118, ptr %7, align 8, !dbg !1373
  %119 = load double, ptr %4, align 8, !dbg !1374
  %120 = call double @llvm.sqrt.f64(double %119), !dbg !1375
  store double %120, ptr %10, align 8, !dbg !1376
  %121 = load i32, ptr %12, align 4, !dbg !1377
  %122 = icmp sge i32 %121, 1072640819, !dbg !1379
  br i1 %122, label %123, label %133, !dbg !1380

123:                                              ; preds = %93
  %124 = load double, ptr %6, align 8, !dbg !1381
  %125 = load double, ptr %7, align 8, !dbg !1383
  %126 = fdiv double %124, %125, !dbg !1384
  store double %126, ptr %5, align 8, !dbg !1385
  %127 = load double, ptr %10, align 8, !dbg !1386
  %128 = load double, ptr %10, align 8, !dbg !1387
  %129 = load double, ptr %5, align 8, !dbg !1388
  %130 = call double @llvm.fmuladd.f64(double %128, double %129, double %127), !dbg !1389
  %131 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %130, double 0xBC91A62633145C07), !dbg !1390
  %132 = fsub double 0x3FF921FB54442D18, %131, !dbg !1391
  store double %132, ptr %4, align 8, !dbg !1392
  br label %170, !dbg !1393

133:                                              ; preds = %93
  %134 = load double, ptr %10, align 8, !dbg !1394
  store double %134, ptr %5, align 8, !dbg !1396
  br label %135, !dbg !1397

135:                                              ; preds = %133
  call void @llvm.dbg.declare(metadata ptr %16, metadata !1398, metadata !DIExpression()), !dbg !1400
  %136 = load double, ptr %5, align 8, !dbg !1400
  %137 = call i64 @bits_of(double noundef %136), !dbg !1400
  store i64 %137, ptr %16, align 8, !dbg !1400
  %138 = load i64, ptr %16, align 8, !dbg !1400
  %139 = and i64 %138, -4294967296, !dbg !1400
  store i64 %139, ptr %16, align 8, !dbg !1400
  %140 = load i64, ptr %16, align 8, !dbg !1400
  %141 = or i64 %140, 0, !dbg !1400
  store i64 %141, ptr %16, align 8, !dbg !1400
  %142 = load i64, ptr %16, align 8, !dbg !1400
  %143 = call double @double_of(i64 noundef %142), !dbg !1400
  store double %143, ptr %5, align 8, !dbg !1400
  br label %144, !dbg !1400

144:                                              ; preds = %135
  %145 = load double, ptr %4, align 8, !dbg !1401
  %146 = load double, ptr %5, align 8, !dbg !1402
  %147 = load double, ptr %5, align 8, !dbg !1403
  %148 = fneg double %146, !dbg !1404
  %149 = call double @llvm.fmuladd.f64(double %148, double %147, double %145), !dbg !1404
  %150 = load double, ptr %10, align 8, !dbg !1405
  %151 = load double, ptr %5, align 8, !dbg !1406
  %152 = fadd double %150, %151, !dbg !1407
  %153 = fdiv double %149, %152, !dbg !1408
  store double %153, ptr %8, align 8, !dbg !1409
  %154 = load double, ptr %6, align 8, !dbg !1410
  %155 = load double, ptr %7, align 8, !dbg !1411
  %156 = fdiv double %154, %155, !dbg !1412
  store double %156, ptr %9, align 8, !dbg !1413
  %157 = load double, ptr %10, align 8, !dbg !1414
  %158 = fmul double 2.000000e+00, %157, !dbg !1415
  %159 = load double, ptr %9, align 8, !dbg !1416
  %160 = load double, ptr %8, align 8, !dbg !1417
  %161 = call double @llvm.fmuladd.f64(double -2.000000e+00, double %160, double 0x3C91A62633145C07), !dbg !1418
  %162 = fneg double %161, !dbg !1419
  %163 = call double @llvm.fmuladd.f64(double %158, double %159, double %162), !dbg !1419
  store double %163, ptr %6, align 8, !dbg !1420
  %164 = load double, ptr %5, align 8, !dbg !1421
  %165 = call double @llvm.fmuladd.f64(double -2.000000e+00, double %164, double 0x3FE921FB54442D18), !dbg !1422
  store double %165, ptr %7, align 8, !dbg !1423
  %166 = load double, ptr %6, align 8, !dbg !1424
  %167 = load double, ptr %7, align 8, !dbg !1425
  %168 = fsub double %166, %167, !dbg !1426
  %169 = fsub double 0x3FE921FB54442D18, %168, !dbg !1427
  store double %169, ptr %4, align 8, !dbg !1428
  br label %170

170:                                              ; preds = %144, %123
  %171 = load i32, ptr %11, align 4, !dbg !1429
  %172 = icmp sgt i32 %171, 0, !dbg !1431
  br i1 %172, label %173, label %175, !dbg !1432

173:                                              ; preds = %170
  %174 = load double, ptr %4, align 8, !dbg !1433
  store double %174, ptr %2, align 8, !dbg !1434
  br label %178, !dbg !1434

175:                                              ; preds = %170
  %176 = load double, ptr %4, align 8, !dbg !1435
  %177 = fneg double %176, !dbg !1436
  store double %177, ptr %2, align 8, !dbg !1437
  br label %178, !dbg !1437

178:                                              ; preds = %175, %173, %64, %57, %46, %41
  %179 = load double, ptr %2, align 8, !dbg !1438
  ret double %179, !dbg !1438
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_asinh(double noundef %0) #0 !dbg !86 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !1439, metadata !DIExpression()), !dbg !1440
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1441, metadata !DIExpression()), !dbg !1442
  call void @llvm.dbg.declare(metadata ptr %5, metadata !1443, metadata !DIExpression()), !dbg !1444
  call void @llvm.dbg.declare(metadata ptr %6, metadata !1445, metadata !DIExpression()), !dbg !1446
  call void @llvm.dbg.declare(metadata ptr %7, metadata !1447, metadata !DIExpression()), !dbg !1448
  br label %9, !dbg !1449

9:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !1450, metadata !DIExpression()), !dbg !1452
  %10 = load double, ptr %3, align 8, !dbg !1452
  %11 = call i64 @bits_of(double noundef %10), !dbg !1452
  store i64 %11, ptr %8, align 8, !dbg !1452
  %12 = load i64, ptr %8, align 8, !dbg !1452
  %13 = lshr i64 %12, 32, !dbg !1452
  %14 = trunc i64 %13 to i32, !dbg !1452
  store i32 %14, ptr %6, align 4, !dbg !1452
  br label %15, !dbg !1452

15:                                               ; preds = %9
  %16 = load i32, ptr %6, align 4, !dbg !1453
  %17 = and i32 %16, 2147483647, !dbg !1454
  store i32 %17, ptr %7, align 4, !dbg !1455
  %18 = load i32, ptr %7, align 4, !dbg !1456
  %19 = icmp sge i32 %18, 2146435072, !dbg !1458
  br i1 %19, label %20, label %24, !dbg !1459

20:                                               ; preds = %15
  %21 = load double, ptr %3, align 8, !dbg !1460
  %22 = load double, ptr %3, align 8, !dbg !1461
  %23 = fadd double %21, %22, !dbg !1462
  store double %23, ptr %2, align 8, !dbg !1463
  br label %81, !dbg !1463

24:                                               ; preds = %15
  %25 = load i32, ptr %7, align 4, !dbg !1464
  %26 = icmp slt i32 %25, 1043333120, !dbg !1466
  br i1 %26, label %27, label %34, !dbg !1467

27:                                               ; preds = %24
  %28 = load double, ptr %3, align 8, !dbg !1468
  %29 = fadd double 1.000000e+300, %28, !dbg !1471
  %30 = fcmp ogt double %29, 1.000000e+00, !dbg !1472
  br i1 %30, label %31, label %33, !dbg !1473

31:                                               ; preds = %27
  %32 = load double, ptr %3, align 8, !dbg !1474
  store double %32, ptr %2, align 8, !dbg !1475
  br label %81, !dbg !1475

33:                                               ; preds = %27
  br label %34, !dbg !1476

34:                                               ; preds = %33, %24
  %35 = load i32, ptr %7, align 4, !dbg !1477
  %36 = icmp sgt i32 %35, 1102053376, !dbg !1479
  br i1 %36, label %37, label %42, !dbg !1480

37:                                               ; preds = %34
  %38 = load double, ptr %3, align 8, !dbg !1481
  %39 = call double @llvm.fabs.f64(double %38), !dbg !1483
  %40 = call double @pts_ieee754_log(double noundef %39), !dbg !1484
  %41 = fadd double %40, 0x3FE62E42FEFA39EF, !dbg !1485
  store double %41, ptr %5, align 8, !dbg !1486
  br label %73, !dbg !1487

42:                                               ; preds = %34
  %43 = load i32, ptr %7, align 4, !dbg !1488
  %44 = icmp sgt i32 %43, 1073741824, !dbg !1490
  br i1 %44, label %45, label %58, !dbg !1491

45:                                               ; preds = %42
  %46 = load double, ptr %3, align 8, !dbg !1492
  %47 = call double @llvm.fabs.f64(double %46), !dbg !1494
  store double %47, ptr %4, align 8, !dbg !1495
  %48 = load double, ptr %4, align 8, !dbg !1496
  %49 = load double, ptr %3, align 8, !dbg !1497
  %50 = load double, ptr %3, align 8, !dbg !1498
  %51 = call double @llvm.fmuladd.f64(double %49, double %50, double 1.000000e+00), !dbg !1499
  %52 = call double @llvm.sqrt.f64(double %51), !dbg !1500
  %53 = load double, ptr %4, align 8, !dbg !1501
  %54 = fadd double %52, %53, !dbg !1502
  %55 = fdiv double 1.000000e+00, %54, !dbg !1503
  %56 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %48, double %55), !dbg !1504
  %57 = call double @pts_ieee754_log(double noundef %56), !dbg !1505
  store double %57, ptr %5, align 8, !dbg !1506
  br label %72, !dbg !1507

58:                                               ; preds = %42
  %59 = load double, ptr %3, align 8, !dbg !1508
  %60 = load double, ptr %3, align 8, !dbg !1510
  %61 = fmul double %59, %60, !dbg !1511
  store double %61, ptr %4, align 8, !dbg !1512
  %62 = load double, ptr %3, align 8, !dbg !1513
  %63 = call double @llvm.fabs.f64(double %62), !dbg !1514
  %64 = load double, ptr %4, align 8, !dbg !1515
  %65 = load double, ptr %4, align 8, !dbg !1516
  %66 = fadd double 1.000000e+00, %65, !dbg !1517
  %67 = call double @llvm.sqrt.f64(double %66), !dbg !1518
  %68 = fadd double 1.000000e+00, %67, !dbg !1519
  %69 = fdiv double %64, %68, !dbg !1520
  %70 = fadd double %63, %69, !dbg !1521
  %71 = call double @pts_ieee754_log1p(double noundef %70), !dbg !1522
  store double %71, ptr %5, align 8, !dbg !1523
  br label %72

72:                                               ; preds = %58, %45
  br label %73

73:                                               ; preds = %72, %37
  %74 = load i32, ptr %6, align 4, !dbg !1524
  %75 = icmp sgt i32 %74, 0, !dbg !1526
  br i1 %75, label %76, label %78, !dbg !1527

76:                                               ; preds = %73
  %77 = load double, ptr %5, align 8, !dbg !1528
  store double %77, ptr %2, align 8, !dbg !1530
  br label %81, !dbg !1530

78:                                               ; preds = %73
  %79 = load double, ptr %5, align 8, !dbg !1531
  %80 = fneg double %79, !dbg !1533
  store double %80, ptr %2, align 8, !dbg !1534
  br label %81, !dbg !1534

81:                                               ; preds = %78, %76, %31, %20
  %82 = load double, ptr %2, align 8, !dbg !1535
  ret double %82, !dbg !1535
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_atan(double noundef %0) #0 !dbg !93 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i64, align 8
  %12 = alloca i32, align 4
  %13 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !1536, metadata !DIExpression()), !dbg !1537
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1538, metadata !DIExpression()), !dbg !1539
  call void @llvm.dbg.declare(metadata ptr %5, metadata !1540, metadata !DIExpression()), !dbg !1541
  call void @llvm.dbg.declare(metadata ptr %6, metadata !1542, metadata !DIExpression()), !dbg !1543
  call void @llvm.dbg.declare(metadata ptr %7, metadata !1544, metadata !DIExpression()), !dbg !1545
  call void @llvm.dbg.declare(metadata ptr %8, metadata !1546, metadata !DIExpression()), !dbg !1547
  call void @llvm.dbg.declare(metadata ptr %9, metadata !1548, metadata !DIExpression()), !dbg !1549
  call void @llvm.dbg.declare(metadata ptr %10, metadata !1550, metadata !DIExpression()), !dbg !1551
  br label %14, !dbg !1552

14:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %11, metadata !1553, metadata !DIExpression()), !dbg !1555
  %15 = load double, ptr %3, align 8, !dbg !1555
  %16 = call i64 @bits_of(double noundef %15), !dbg !1555
  store i64 %16, ptr %11, align 8, !dbg !1555
  %17 = load i64, ptr %11, align 8, !dbg !1555
  %18 = lshr i64 %17, 32, !dbg !1555
  %19 = trunc i64 %18 to i32, !dbg !1555
  store i32 %19, ptr %9, align 4, !dbg !1555
  br label %20, !dbg !1555

20:                                               ; preds = %14
  %21 = load i32, ptr %9, align 4, !dbg !1556
  %22 = and i32 %21, 2147483647, !dbg !1557
  store i32 %22, ptr %8, align 4, !dbg !1558
  %23 = load i32, ptr %8, align 4, !dbg !1559
  %24 = icmp sge i32 %23, 1141899264, !dbg !1561
  br i1 %24, label %25, label %57, !dbg !1562

25:                                               ; preds = %20
  call void @llvm.dbg.declare(metadata ptr %12, metadata !1563, metadata !DIExpression()), !dbg !1565
  br label %26, !dbg !1566

26:                                               ; preds = %25
  call void @llvm.dbg.declare(metadata ptr %13, metadata !1567, metadata !DIExpression()), !dbg !1569
  %27 = load double, ptr %3, align 8, !dbg !1569
  %28 = call i64 @bits_of(double noundef %27), !dbg !1569
  store i64 %28, ptr %13, align 8, !dbg !1569
  %29 = load i64, ptr %13, align 8, !dbg !1569
  %30 = and i64 %29, 4294967295, !dbg !1569
  %31 = trunc i64 %30 to i32, !dbg !1569
  store i32 %31, ptr %12, align 4, !dbg !1569
  br label %32, !dbg !1569

32:                                               ; preds = %26
  %33 = load i32, ptr %8, align 4, !dbg !1570
  %34 = icmp sgt i32 %33, 2146435072, !dbg !1572
  br i1 %34, label %41, label %35, !dbg !1573

35:                                               ; preds = %32
  %36 = load i32, ptr %8, align 4, !dbg !1574
  %37 = icmp eq i32 %36, 2146435072, !dbg !1575
  br i1 %37, label %38, label %45, !dbg !1576

38:                                               ; preds = %35
  %39 = load i32, ptr %12, align 4, !dbg !1577
  %40 = icmp ne i32 %39, 0, !dbg !1578
  br i1 %40, label %41, label %45, !dbg !1579

41:                                               ; preds = %38, %32
  %42 = load double, ptr %3, align 8, !dbg !1580
  %43 = load double, ptr %3, align 8, !dbg !1581
  %44 = fadd double %42, %43, !dbg !1582
  store double %44, ptr %2, align 8, !dbg !1583
  br label %183, !dbg !1583

45:                                               ; preds = %38, %35
  %46 = load i32, ptr %9, align 4, !dbg !1584
  %47 = icmp sgt i32 %46, 0, !dbg !1586
  br i1 %47, label %48, label %52, !dbg !1587

48:                                               ; preds = %45
  %49 = load double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 3), align 8, !dbg !1588
  %50 = load volatile double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 3), align 8, !dbg !1589
  %51 = fadd double %49, %50, !dbg !1590
  store double %51, ptr %2, align 8, !dbg !1591
  br label %183, !dbg !1591

52:                                               ; preds = %45
  %53 = load double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 3), align 8, !dbg !1592
  %54 = fneg double %53, !dbg !1593
  %55 = load volatile double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 3), align 8, !dbg !1594
  %56 = fsub double %54, %55, !dbg !1595
  store double %56, ptr %2, align 8, !dbg !1596
  br label %183, !dbg !1596

57:                                               ; preds = %20
  %58 = load i32, ptr %8, align 4, !dbg !1597
  %59 = icmp slt i32 %58, 1071382528, !dbg !1599
  br i1 %59, label %60, label %71, !dbg !1600

60:                                               ; preds = %57
  %61 = load i32, ptr %8, align 4, !dbg !1601
  %62 = icmp slt i32 %61, 1044381696, !dbg !1604
  br i1 %62, label %63, label %70, !dbg !1605

63:                                               ; preds = %60
  %64 = load double, ptr %3, align 8, !dbg !1606
  %65 = fadd double 1.000000e+300, %64, !dbg !1609
  %66 = fcmp ogt double %65, 1.000000e+00, !dbg !1610
  br i1 %66, label %67, label %69, !dbg !1611

67:                                               ; preds = %63
  %68 = load double, ptr %3, align 8, !dbg !1612
  store double %68, ptr %2, align 8, !dbg !1613
  br label %183, !dbg !1613

69:                                               ; preds = %63
  br label %70, !dbg !1614

70:                                               ; preds = %69, %60
  store i32 -1, ptr %10, align 4, !dbg !1615
  br label %106, !dbg !1616

71:                                               ; preds = %57
  %72 = load double, ptr %3, align 8, !dbg !1617
  %73 = call double @llvm.fabs.f64(double %72), !dbg !1619
  store double %73, ptr %3, align 8, !dbg !1620
  %74 = load i32, ptr %8, align 4, !dbg !1621
  %75 = icmp slt i32 %74, 1072889856, !dbg !1623
  br i1 %75, label %76, label %92, !dbg !1624

76:                                               ; preds = %71
  %77 = load i32, ptr %8, align 4, !dbg !1625
  %78 = icmp slt i32 %77, 1072037888, !dbg !1628
  br i1 %78, label %79, label %85, !dbg !1629

79:                                               ; preds = %76
  store i32 0, ptr %10, align 4, !dbg !1630
  %80 = load double, ptr %3, align 8, !dbg !1632
  %81 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %80, double -1.000000e+00), !dbg !1633
  %82 = load double, ptr %3, align 8, !dbg !1634
  %83 = fadd double 2.000000e+00, %82, !dbg !1635
  %84 = fdiv double %81, %83, !dbg !1636
  store double %84, ptr %3, align 8, !dbg !1637
  br label %91, !dbg !1638

85:                                               ; preds = %76
  store i32 1, ptr %10, align 4, !dbg !1639
  %86 = load double, ptr %3, align 8, !dbg !1641
  %87 = fsub double %86, 1.000000e+00, !dbg !1642
  %88 = load double, ptr %3, align 8, !dbg !1643
  %89 = fadd double %88, 1.000000e+00, !dbg !1644
  %90 = fdiv double %87, %89, !dbg !1645
  store double %90, ptr %3, align 8, !dbg !1646
  br label %91

91:                                               ; preds = %85, %79
  br label %105, !dbg !1647

92:                                               ; preds = %71
  %93 = load i32, ptr %8, align 4, !dbg !1648
  %94 = icmp slt i32 %93, 1073971200, !dbg !1651
  br i1 %94, label %95, label %101, !dbg !1652

95:                                               ; preds = %92
  store i32 2, ptr %10, align 4, !dbg !1653
  %96 = load double, ptr %3, align 8, !dbg !1655
  %97 = fsub double %96, 1.500000e+00, !dbg !1656
  %98 = load double, ptr %3, align 8, !dbg !1657
  %99 = call double @llvm.fmuladd.f64(double 1.500000e+00, double %98, double 1.000000e+00), !dbg !1658
  %100 = fdiv double %97, %99, !dbg !1659
  store double %100, ptr %3, align 8, !dbg !1660
  br label %104, !dbg !1661

101:                                              ; preds = %92
  store i32 3, ptr %10, align 4, !dbg !1662
  %102 = load double, ptr %3, align 8, !dbg !1664
  %103 = fdiv double -1.000000e+00, %102, !dbg !1665
  store double %103, ptr %3, align 8, !dbg !1666
  br label %104

104:                                              ; preds = %101, %95
  br label %105

105:                                              ; preds = %104, %91
  br label %106

106:                                              ; preds = %105, %70
  %107 = load double, ptr %3, align 8, !dbg !1667
  %108 = load double, ptr %3, align 8, !dbg !1668
  %109 = fmul double %107, %108, !dbg !1669
  store double %109, ptr %7, align 8, !dbg !1670
  %110 = load double, ptr %7, align 8, !dbg !1671
  %111 = load double, ptr %7, align 8, !dbg !1672
  %112 = fmul double %110, %111, !dbg !1673
  store double %112, ptr %4, align 8, !dbg !1674
  %113 = load double, ptr %7, align 8, !dbg !1675
  %114 = load double, ptr @pts_ieee754_atan.aT, align 8, !dbg !1676
  %115 = load double, ptr %4, align 8, !dbg !1677
  %116 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 2), align 8, !dbg !1678
  %117 = load double, ptr %4, align 8, !dbg !1679
  %118 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 4), align 8, !dbg !1680
  %119 = load double, ptr %4, align 8, !dbg !1681
  %120 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 6), align 8, !dbg !1682
  %121 = load double, ptr %4, align 8, !dbg !1683
  %122 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 8), align 8, !dbg !1684
  %123 = load double, ptr %4, align 8, !dbg !1685
  %124 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 10), align 8, !dbg !1686
  %125 = call double @llvm.fmuladd.f64(double %123, double %124, double %122), !dbg !1687
  %126 = call double @llvm.fmuladd.f64(double %121, double %125, double %120), !dbg !1688
  %127 = call double @llvm.fmuladd.f64(double %119, double %126, double %118), !dbg !1689
  %128 = call double @llvm.fmuladd.f64(double %117, double %127, double %116), !dbg !1690
  %129 = call double @llvm.fmuladd.f64(double %115, double %128, double %114), !dbg !1691
  %130 = fmul double %113, %129, !dbg !1692
  store double %130, ptr %5, align 8, !dbg !1693
  %131 = load double, ptr %4, align 8, !dbg !1694
  %132 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 1), align 8, !dbg !1695
  %133 = load double, ptr %4, align 8, !dbg !1696
  %134 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 3), align 8, !dbg !1697
  %135 = load double, ptr %4, align 8, !dbg !1698
  %136 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 5), align 8, !dbg !1699
  %137 = load double, ptr %4, align 8, !dbg !1700
  %138 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 7), align 8, !dbg !1701
  %139 = load double, ptr %4, align 8, !dbg !1702
  %140 = load double, ptr getelementptr inbounds ([11 x double], ptr @pts_ieee754_atan.aT, i64 0, i64 9), align 8, !dbg !1703
  %141 = call double @llvm.fmuladd.f64(double %139, double %140, double %138), !dbg !1704
  %142 = call double @llvm.fmuladd.f64(double %137, double %141, double %136), !dbg !1705
  %143 = call double @llvm.fmuladd.f64(double %135, double %142, double %134), !dbg !1706
  %144 = call double @llvm.fmuladd.f64(double %133, double %143, double %132), !dbg !1707
  %145 = fmul double %131, %144, !dbg !1708
  store double %145, ptr %6, align 8, !dbg !1709
  %146 = load i32, ptr %10, align 4, !dbg !1710
  %147 = icmp slt i32 %146, 0, !dbg !1712
  br i1 %147, label %148, label %156, !dbg !1713

148:                                              ; preds = %106
  %149 = load double, ptr %3, align 8, !dbg !1714
  %150 = load double, ptr %3, align 8, !dbg !1716
  %151 = load double, ptr %5, align 8, !dbg !1717
  %152 = load double, ptr %6, align 8, !dbg !1718
  %153 = fadd double %151, %152, !dbg !1719
  %154 = fneg double %150, !dbg !1720
  %155 = call double @llvm.fmuladd.f64(double %154, double %153, double %149), !dbg !1720
  store double %155, ptr %2, align 8, !dbg !1721
  br label %183, !dbg !1721

156:                                              ; preds = %106
  %157 = load i32, ptr %10, align 4, !dbg !1722
  %158 = sext i32 %157 to i64, !dbg !1724
  %159 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 %158, !dbg !1724
  %160 = load double, ptr %159, align 8, !dbg !1724
  %161 = load double, ptr %3, align 8, !dbg !1725
  %162 = load double, ptr %5, align 8, !dbg !1726
  %163 = load double, ptr %6, align 8, !dbg !1727
  %164 = fadd double %162, %163, !dbg !1728
  %165 = load i32, ptr %10, align 4, !dbg !1729
  %166 = sext i32 %165 to i64, !dbg !1730
  %167 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 %166, !dbg !1730
  %168 = load double, ptr %167, align 8, !dbg !1730
  %169 = fneg double %168, !dbg !1731
  %170 = call double @llvm.fmuladd.f64(double %161, double %164, double %169), !dbg !1731
  %171 = load double, ptr %3, align 8, !dbg !1732
  %172 = fsub double %170, %171, !dbg !1733
  %173 = fsub double %160, %172, !dbg !1734
  store double %173, ptr %7, align 8, !dbg !1735
  %174 = load i32, ptr %9, align 4, !dbg !1736
  %175 = icmp slt i32 %174, 0, !dbg !1737
  br i1 %175, label %176, label %179, !dbg !1738

176:                                              ; preds = %156
  %177 = load double, ptr %7, align 8, !dbg !1739
  %178 = fneg double %177, !dbg !1740
  br label %181, !dbg !1738

179:                                              ; preds = %156
  %180 = load double, ptr %7, align 8, !dbg !1741
  br label %181, !dbg !1738

181:                                              ; preds = %179, %176
  %182 = phi double [ %178, %176 ], [ %180, %179 ], !dbg !1738
  store double %182, ptr %2, align 8, !dbg !1742
  br label %183, !dbg !1742

183:                                              ; preds = %181, %148, %67, %52, %48, %41
  %184 = load double, ptr %2, align 8, !dbg !1743
  ret double %184, !dbg !1743
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_atan2(double noundef %0, double noundef %1) #0 !dbg !110 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  store double %0, ptr %4, align 8
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1744, metadata !DIExpression()), !dbg !1745
  store double %1, ptr %5, align 8
  call void @llvm.dbg.declare(metadata ptr %5, metadata !1746, metadata !DIExpression()), !dbg !1747
  call void @llvm.dbg.declare(metadata ptr %6, metadata !1748, metadata !DIExpression()), !dbg !1749
  call void @llvm.dbg.declare(metadata ptr %7, metadata !1750, metadata !DIExpression()), !dbg !1751
  call void @llvm.dbg.declare(metadata ptr %8, metadata !1752, metadata !DIExpression()), !dbg !1753
  call void @llvm.dbg.declare(metadata ptr %9, metadata !1754, metadata !DIExpression()), !dbg !1755
  call void @llvm.dbg.declare(metadata ptr %10, metadata !1756, metadata !DIExpression()), !dbg !1757
  call void @llvm.dbg.declare(metadata ptr %11, metadata !1758, metadata !DIExpression()), !dbg !1759
  call void @llvm.dbg.declare(metadata ptr %12, metadata !1760, metadata !DIExpression()), !dbg !1761
  call void @llvm.dbg.declare(metadata ptr %13, metadata !1762, metadata !DIExpression()), !dbg !1763
  call void @llvm.dbg.declare(metadata ptr %14, metadata !1764, metadata !DIExpression()), !dbg !1765
  br label %17, !dbg !1766

17:                                               ; preds = %2
  call void @llvm.dbg.declare(metadata ptr %15, metadata !1767, metadata !DIExpression()), !dbg !1769
  %18 = load double, ptr %5, align 8, !dbg !1769
  %19 = call i64 @bits_of(double noundef %18), !dbg !1769
  store i64 %19, ptr %15, align 8, !dbg !1769
  %20 = load i64, ptr %15, align 8, !dbg !1769
  %21 = lshr i64 %20, 32, !dbg !1769
  %22 = trunc i64 %21 to i32, !dbg !1769
  store i32 %22, ptr %9, align 4, !dbg !1769
  %23 = load i64, ptr %15, align 8, !dbg !1769
  %24 = and i64 %23, 4294967295, !dbg !1769
  %25 = trunc i64 %24 to i32, !dbg !1769
  store i32 %25, ptr %13, align 4, !dbg !1769
  br label %26, !dbg !1769

26:                                               ; preds = %17
  %27 = load i32, ptr %9, align 4, !dbg !1770
  %28 = and i32 %27, 2147483647, !dbg !1771
  store i32 %28, ptr %11, align 4, !dbg !1772
  br label %29, !dbg !1773

29:                                               ; preds = %26
  call void @llvm.dbg.declare(metadata ptr %16, metadata !1774, metadata !DIExpression()), !dbg !1776
  %30 = load double, ptr %4, align 8, !dbg !1776
  %31 = call i64 @bits_of(double noundef %30), !dbg !1776
  store i64 %31, ptr %16, align 8, !dbg !1776
  %32 = load i64, ptr %16, align 8, !dbg !1776
  %33 = lshr i64 %32, 32, !dbg !1776
  %34 = trunc i64 %33 to i32, !dbg !1776
  store i32 %34, ptr %10, align 4, !dbg !1776
  %35 = load i64, ptr %16, align 8, !dbg !1776
  %36 = and i64 %35, 4294967295, !dbg !1776
  %37 = trunc i64 %36 to i32, !dbg !1776
  store i32 %37, ptr %14, align 4, !dbg !1776
  br label %38, !dbg !1776

38:                                               ; preds = %29
  %39 = load i32, ptr %10, align 4, !dbg !1777
  %40 = and i32 %39, 2147483647, !dbg !1778
  store i32 %40, ptr %12, align 4, !dbg !1779
  %41 = load i32, ptr %11, align 4, !dbg !1780
  %42 = load i32, ptr %13, align 4, !dbg !1782
  %43 = load i32, ptr %13, align 4, !dbg !1783
  %44 = call i32 @negate_with_wraparound(i32 noundef %43), !dbg !1784
  %45 = or i32 %42, %44, !dbg !1785
  %46 = lshr i32 %45, 31, !dbg !1786
  %47 = or i32 %41, %46, !dbg !1787
  %48 = icmp ugt i32 %47, 2146435072, !dbg !1788
  br i1 %48, label %58, label %49, !dbg !1789

49:                                               ; preds = %38
  %50 = load i32, ptr %12, align 4, !dbg !1790
  %51 = load i32, ptr %14, align 4, !dbg !1791
  %52 = load i32, ptr %14, align 4, !dbg !1792
  %53 = call i32 @negate_with_wraparound(i32 noundef %52), !dbg !1793
  %54 = or i32 %51, %53, !dbg !1794
  %55 = lshr i32 %54, 31, !dbg !1795
  %56 = or i32 %50, %55, !dbg !1796
  %57 = icmp ugt i32 %56, 2146435072, !dbg !1797
  br i1 %57, label %58, label %62, !dbg !1798

58:                                               ; preds = %49, %38
  %59 = load double, ptr %5, align 8, !dbg !1799
  %60 = load double, ptr %4, align 8, !dbg !1801
  %61 = fadd double %59, %60, !dbg !1802
  store double %61, ptr %3, align 8, !dbg !1803
  br label %200, !dbg !1803

62:                                               ; preds = %49
  %63 = load i32, ptr %9, align 4, !dbg !1804
  %64 = call i32 @sub_with_wraparound(i32 noundef %63, i32 noundef 1072693248), !dbg !1806
  %65 = load i32, ptr %13, align 4, !dbg !1807
  %66 = or i32 %64, %65, !dbg !1808
  %67 = icmp eq i32 %66, 0, !dbg !1809
  br i1 %67, label %68, label %71, !dbg !1810

68:                                               ; preds = %62
  %69 = load double, ptr %4, align 8, !dbg !1811
  %70 = call double @pts_ieee754_atan(double noundef %69), !dbg !1813
  store double %70, ptr %3, align 8, !dbg !1814
  br label %200, !dbg !1814

71:                                               ; preds = %62
  %72 = load i32, ptr %10, align 4, !dbg !1815
  %73 = ashr i32 %72, 31, !dbg !1816
  %74 = and i32 %73, 1, !dbg !1817
  %75 = load i32, ptr %9, align 4, !dbg !1818
  %76 = ashr i32 %75, 30, !dbg !1819
  %77 = and i32 %76, 2, !dbg !1820
  %78 = or i32 %74, %77, !dbg !1821
  store i32 %78, ptr %8, align 4, !dbg !1822
  %79 = load i32, ptr %12, align 4, !dbg !1823
  %80 = load i32, ptr %14, align 4, !dbg !1825
  %81 = or i32 %79, %80, !dbg !1826
  %82 = icmp eq i32 %81, 0, !dbg !1827
  br i1 %82, label %83, label %94, !dbg !1828

83:                                               ; preds = %71
  %84 = load i32, ptr %8, align 4, !dbg !1829
  switch i32 %84, label %93 [
    i32 0, label %85
    i32 1, label %85
    i32 2, label %87
    i32 3, label %90
  ], !dbg !1831

85:                                               ; preds = %83, %83
  %86 = load double, ptr %4, align 8, !dbg !1832
  store double %86, ptr %3, align 8, !dbg !1834
  br label %200, !dbg !1834

87:                                               ; preds = %83
  %88 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1835
  %89 = fadd double 0x400921FB54442D18, %88, !dbg !1836
  store double %89, ptr %3, align 8, !dbg !1837
  br label %200, !dbg !1837

90:                                               ; preds = %83
  %91 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1838
  %92 = fsub double 0xC00921FB54442D18, %91, !dbg !1839
  store double %92, ptr %3, align 8, !dbg !1840
  br label %200, !dbg !1840

93:                                               ; preds = %83
  br label %94, !dbg !1841

94:                                               ; preds = %93, %71
  %95 = load i32, ptr %11, align 4, !dbg !1842
  %96 = load i32, ptr %13, align 4, !dbg !1844
  %97 = or i32 %95, %96, !dbg !1845
  %98 = icmp eq i32 %97, 0, !dbg !1846
  br i1 %98, label %99, label %110, !dbg !1847

99:                                               ; preds = %94
  %100 = load i32, ptr %10, align 4, !dbg !1848
  %101 = icmp slt i32 %100, 0, !dbg !1849
  br i1 %101, label %102, label %105, !dbg !1850

102:                                              ; preds = %99
  %103 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1851
  %104 = fsub double 0xBFF921FB54442D18, %103, !dbg !1852
  br label %108, !dbg !1850

105:                                              ; preds = %99
  %106 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1853
  %107 = fadd double 0x3FF921FB54442D18, %106, !dbg !1854
  br label %108, !dbg !1850

108:                                              ; preds = %105, %102
  %109 = phi double [ %104, %102 ], [ %107, %105 ], !dbg !1850
  store double %109, ptr %3, align 8, !dbg !1855
  br label %200, !dbg !1855

110:                                              ; preds = %94
  %111 = load i32, ptr %11, align 4, !dbg !1856
  %112 = icmp eq i32 %111, 2146435072, !dbg !1858
  br i1 %112, label %113, label %143, !dbg !1859

113:                                              ; preds = %110
  %114 = load i32, ptr %12, align 4, !dbg !1860
  %115 = icmp eq i32 %114, 2146435072, !dbg !1863
  br i1 %115, label %116, label %131, !dbg !1864

116:                                              ; preds = %113
  %117 = load i32, ptr %8, align 4, !dbg !1865
  switch i32 %117, label %130 [
    i32 0, label %118
    i32 1, label %121
    i32 2, label %124
    i32 3, label %127
  ], !dbg !1867

118:                                              ; preds = %116
  %119 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1868
  %120 = fadd double 0x3FE921FB54442D18, %119, !dbg !1870
  store double %120, ptr %3, align 8, !dbg !1871
  br label %200, !dbg !1871

121:                                              ; preds = %116
  %122 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1872
  %123 = fsub double 0xBFE921FB54442D18, %122, !dbg !1873
  store double %123, ptr %3, align 8, !dbg !1874
  br label %200, !dbg !1874

124:                                              ; preds = %116
  %125 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1875
  %126 = fadd double 0x4002D97C7F3321D2, %125, !dbg !1876
  store double %126, ptr %3, align 8, !dbg !1877
  br label %200, !dbg !1877

127:                                              ; preds = %116
  %128 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1878
  %129 = fsub double 0xC002D97C7F3321D2, %128, !dbg !1879
  store double %129, ptr %3, align 8, !dbg !1880
  br label %200, !dbg !1880

130:                                              ; preds = %116
  br label %142, !dbg !1881

131:                                              ; preds = %113
  %132 = load i32, ptr %8, align 4, !dbg !1882
  switch i32 %132, label %141 [
    i32 0, label %133
    i32 1, label %134
    i32 2, label %135
    i32 3, label %138
  ], !dbg !1884

133:                                              ; preds = %131
  store double 0.000000e+00, ptr %3, align 8, !dbg !1885
  br label %200, !dbg !1885

134:                                              ; preds = %131
  store double -0.000000e+00, ptr %3, align 8, !dbg !1887
  br label %200, !dbg !1887

135:                                              ; preds = %131
  %136 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1888
  %137 = fadd double 0x400921FB54442D18, %136, !dbg !1889
  store double %137, ptr %3, align 8, !dbg !1890
  br label %200, !dbg !1890

138:                                              ; preds = %131
  %139 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1891
  %140 = fsub double 0xC00921FB54442D18, %139, !dbg !1892
  store double %140, ptr %3, align 8, !dbg !1893
  br label %200, !dbg !1893

141:                                              ; preds = %131
  br label %142

142:                                              ; preds = %141, %130
  br label %143, !dbg !1894

143:                                              ; preds = %142, %110
  %144 = load i32, ptr %12, align 4, !dbg !1895
  %145 = icmp eq i32 %144, 2146435072, !dbg !1897
  br i1 %145, label %146, label %157, !dbg !1898

146:                                              ; preds = %143
  %147 = load i32, ptr %10, align 4, !dbg !1899
  %148 = icmp slt i32 %147, 0, !dbg !1900
  br i1 %148, label %149, label %152, !dbg !1901

149:                                              ; preds = %146
  %150 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1902
  %151 = fsub double 0xBFF921FB54442D18, %150, !dbg !1903
  br label %155, !dbg !1901

152:                                              ; preds = %146
  %153 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1904
  %154 = fadd double 0x3FF921FB54442D18, %153, !dbg !1905
  br label %155, !dbg !1901

155:                                              ; preds = %152, %149
  %156 = phi double [ %151, %149 ], [ %154, %152 ], !dbg !1901
  store double %156, ptr %3, align 8, !dbg !1906
  br label %200, !dbg !1906

157:                                              ; preds = %143
  %158 = load i32, ptr %12, align 4, !dbg !1907
  %159 = load i32, ptr %11, align 4, !dbg !1908
  %160 = sub nsw i32 %158, %159, !dbg !1909
  %161 = ashr i32 %160, 20, !dbg !1910
  store i32 %161, ptr %7, align 4, !dbg !1911
  %162 = load i32, ptr %7, align 4, !dbg !1912
  %163 = icmp sgt i32 %162, 60, !dbg !1914
  br i1 %163, label %164, label %169, !dbg !1915

164:                                              ; preds = %157
  %165 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1916
  %166 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %165, double 0x3FF921FB54442D18), !dbg !1918
  store double %166, ptr %6, align 8, !dbg !1919
  %167 = load i32, ptr %8, align 4, !dbg !1920
  %168 = and i32 %167, 1, !dbg !1920
  store i32 %168, ptr %8, align 4, !dbg !1920
  br label %183, !dbg !1921

169:                                              ; preds = %157
  %170 = load i32, ptr %9, align 4, !dbg !1922
  %171 = icmp slt i32 %170, 0, !dbg !1924
  br i1 %171, label %172, label %176, !dbg !1925

172:                                              ; preds = %169
  %173 = load i32, ptr %7, align 4, !dbg !1926
  %174 = icmp slt i32 %173, -60, !dbg !1927
  br i1 %174, label %175, label %176, !dbg !1928

175:                                              ; preds = %172
  store double 0.000000e+00, ptr %6, align 8, !dbg !1929
  br label %182, !dbg !1931

176:                                              ; preds = %172, %169
  %177 = load double, ptr %4, align 8, !dbg !1932
  %178 = load double, ptr %5, align 8, !dbg !1934
  %179 = fdiv double %177, %178, !dbg !1935
  %180 = call double @llvm.fabs.f64(double %179), !dbg !1936
  %181 = call double @pts_ieee754_atan(double noundef %180), !dbg !1937
  store double %181, ptr %6, align 8, !dbg !1938
  br label %182

182:                                              ; preds = %176, %175
  br label %183

183:                                              ; preds = %182, %164
  %184 = load i32, ptr %8, align 4, !dbg !1939
  switch i32 %184, label %195 [
    i32 0, label %185
    i32 1, label %187
    i32 2, label %190
  ], !dbg !1940

185:                                              ; preds = %183
  %186 = load double, ptr %6, align 8, !dbg !1941
  store double %186, ptr %3, align 8, !dbg !1943
  br label %200, !dbg !1943

187:                                              ; preds = %183
  %188 = load double, ptr %6, align 8, !dbg !1944
  %189 = fneg double %188, !dbg !1945
  store double %189, ptr %3, align 8, !dbg !1946
  br label %200, !dbg !1946

190:                                              ; preds = %183
  %191 = load double, ptr %6, align 8, !dbg !1947
  %192 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1948
  %193 = fsub double %191, %192, !dbg !1949
  %194 = fsub double 0x400921FB54442D18, %193, !dbg !1950
  store double %194, ptr %3, align 8, !dbg !1951
  br label %200, !dbg !1951

195:                                              ; preds = %183
  %196 = load double, ptr %6, align 8, !dbg !1952
  %197 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1953
  %198 = fsub double %196, %197, !dbg !1954
  %199 = fsub double %198, 0x400921FB54442D18, !dbg !1955
  store double %199, ptr %3, align 8, !dbg !1956
  br label %200, !dbg !1956

200:                                              ; preds = %195, %190, %187, %185, %155, %138, %135, %134, %133, %127, %124, %121, %118, %108, %90, %87, %85, %68, %58
  %201 = load double, ptr %3, align 8, !dbg !1957
  ret double %201, !dbg !1957
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i32 @negate_with_wraparound(i32 noundef %0) #0 !dbg !1958 {
  %2 = alloca i32, align 4
  store i32 %0, ptr %2, align 4
  call void @llvm.dbg.declare(metadata ptr %2, metadata !1961, metadata !DIExpression()), !dbg !1962
  %3 = load i32, ptr %2, align 4, !dbg !1963
  %4 = sub i32 0, %3, !dbg !1964
  ret i32 %4, !dbg !1965
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i32 @sub_with_wraparound(i32 noundef %0, i32 noundef %1) #0 !dbg !1966 {
  %3 = alloca i32, align 4
  %4 = alloca i32, align 4
  store i32 %0, ptr %3, align 4
  call void @llvm.dbg.declare(metadata ptr %3, metadata !1969, metadata !DIExpression()), !dbg !1970
  store i32 %1, ptr %4, align 4
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1971, metadata !DIExpression()), !dbg !1972
  %5 = load i32, ptr %3, align 4, !dbg !1973
  %6 = load i32, ptr %4, align 4, !dbg !1974
  %7 = sub i32 %5, %6, !dbg !1975
  ret i32 %7, !dbg !1976
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_cos(double noundef %0) #0 !dbg !1977 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca [2 x double], align 8
  %5 = alloca double, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !1978, metadata !DIExpression()), !dbg !1979
  call void @llvm.dbg.declare(metadata ptr %4, metadata !1980, metadata !DIExpression()), !dbg !1982
  call void @llvm.dbg.declare(metadata ptr %5, metadata !1983, metadata !DIExpression()), !dbg !1984
  store double 0.000000e+00, ptr %5, align 8, !dbg !1984
  call void @llvm.dbg.declare(metadata ptr %6, metadata !1985, metadata !DIExpression()), !dbg !1986
  call void @llvm.dbg.declare(metadata ptr %7, metadata !1987, metadata !DIExpression()), !dbg !1988
  br label %9, !dbg !1989

9:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !1990, metadata !DIExpression()), !dbg !1992
  %10 = load double, ptr %3, align 8, !dbg !1992
  %11 = call i64 @bits_of(double noundef %10), !dbg !1992
  store i64 %11, ptr %8, align 8, !dbg !1992
  %12 = load i64, ptr %8, align 8, !dbg !1992
  %13 = lshr i64 %12, 32, !dbg !1992
  %14 = trunc i64 %13 to i32, !dbg !1992
  store i32 %14, ptr %7, align 4, !dbg !1992
  br label %15, !dbg !1992

15:                                               ; preds = %9
  %16 = load i32, ptr %7, align 4, !dbg !1993
  %17 = and i32 %16, 2147483647, !dbg !1993
  store i32 %17, ptr %7, align 4, !dbg !1993
  %18 = load i32, ptr %7, align 4, !dbg !1994
  %19 = icmp sle i32 %18, 1072243195, !dbg !1996
  br i1 %19, label %20, label %24, !dbg !1997

20:                                               ; preds = %15
  %21 = load double, ptr %3, align 8, !dbg !1998
  %22 = load double, ptr %5, align 8, !dbg !2000
  %23 = call double @__kernel_cos(double noundef %21, double noundef %22), !dbg !2001
  store double %23, ptr %2, align 8, !dbg !2002
  br label %63, !dbg !2002

24:                                               ; preds = %15
  %25 = load i32, ptr %7, align 4, !dbg !2003
  %26 = icmp sge i32 %25, 2146435072, !dbg !2005
  br i1 %26, label %27, label %31, !dbg !2006

27:                                               ; preds = %24
  %28 = load double, ptr %3, align 8, !dbg !2007
  %29 = load double, ptr %3, align 8, !dbg !2009
  %30 = fsub double %28, %29, !dbg !2010
  store double %30, ptr %2, align 8, !dbg !2011
  br label %63, !dbg !2011

31:                                               ; preds = %24
  %32 = load double, ptr %3, align 8, !dbg !2012
  %33 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !2014
  %34 = call i32 @__ieee754_rem_pio2(double noundef %32, ptr noundef %33), !dbg !2015
  store i32 %34, ptr %6, align 4, !dbg !2016
  %35 = load i32, ptr %6, align 4, !dbg !2017
  %36 = and i32 %35, 3, !dbg !2018
  switch i32 %36, label %57 [
    i32 0, label %37
    i32 1, label %43
    i32 2, label %50
  ], !dbg !2019

37:                                               ; preds = %31
  %38 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !2020
  %39 = load double, ptr %38, align 8, !dbg !2020
  %40 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !2022
  %41 = load double, ptr %40, align 8, !dbg !2022
  %42 = call double @__kernel_cos(double noundef %39, double noundef %41), !dbg !2023
  store double %42, ptr %2, align 8, !dbg !2024
  br label %63, !dbg !2024

43:                                               ; preds = %31
  %44 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !2025
  %45 = load double, ptr %44, align 8, !dbg !2025
  %46 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !2026
  %47 = load double, ptr %46, align 8, !dbg !2026
  %48 = call double @__kernel_sin(double noundef %45, double noundef %47, i32 noundef 1), !dbg !2027
  %49 = fneg double %48, !dbg !2028
  store double %49, ptr %2, align 8, !dbg !2029
  br label %63, !dbg !2029

50:                                               ; preds = %31
  %51 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !2030
  %52 = load double, ptr %51, align 8, !dbg !2030
  %53 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !2031
  %54 = load double, ptr %53, align 8, !dbg !2031
  %55 = call double @__kernel_cos(double noundef %52, double noundef %54), !dbg !2032
  %56 = fneg double %55, !dbg !2033
  store double %56, ptr %2, align 8, !dbg !2034
  br label %63, !dbg !2034

57:                                               ; preds = %31
  %58 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !2035
  %59 = load double, ptr %58, align 8, !dbg !2035
  %60 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !2036
  %61 = load double, ptr %60, align 8, !dbg !2036
  %62 = call double @__kernel_sin(double noundef %59, double noundef %61, i32 noundef 1), !dbg !2037
  store double %62, ptr %2, align 8, !dbg !2038
  br label %63, !dbg !2038

63:                                               ; preds = %57, %50, %43, %37, %27, %20
  %64 = load double, ptr %2, align 8, !dbg !2039
  ret double %64, !dbg !2039
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal double @__kernel_cos(double noundef %0, double noundef %1) #0 !dbg !298 {
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca i32, align 4
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  store double %0, ptr %4, align 8
  call void @llvm.dbg.declare(metadata ptr %4, metadata !2040, metadata !DIExpression()), !dbg !2041
  store double %1, ptr %5, align 8
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2042, metadata !DIExpression()), !dbg !2043
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2044, metadata !DIExpression()), !dbg !2045
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2046, metadata !DIExpression()), !dbg !2047
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2048, metadata !DIExpression()), !dbg !2049
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2050, metadata !DIExpression()), !dbg !2051
  call void @llvm.dbg.declare(metadata ptr %10, metadata !2052, metadata !DIExpression()), !dbg !2053
  call void @llvm.dbg.declare(metadata ptr %11, metadata !2054, metadata !DIExpression()), !dbg !2055
  br label %14, !dbg !2056

14:                                               ; preds = %2
  call void @llvm.dbg.declare(metadata ptr %12, metadata !2057, metadata !DIExpression()), !dbg !2059
  %15 = load double, ptr %4, align 8, !dbg !2059
  %16 = call i64 @bits_of(double noundef %15), !dbg !2059
  store i64 %16, ptr %12, align 8, !dbg !2059
  %17 = load i64, ptr %12, align 8, !dbg !2059
  %18 = lshr i64 %17, 32, !dbg !2059
  %19 = trunc i64 %18 to i32, !dbg !2059
  store i32 %19, ptr %11, align 4, !dbg !2059
  br label %20, !dbg !2059

20:                                               ; preds = %14
  %21 = load i32, ptr %11, align 4, !dbg !2060
  %22 = and i32 %21, 2147483647, !dbg !2060
  store i32 %22, ptr %11, align 4, !dbg !2060
  %23 = load i32, ptr %11, align 4, !dbg !2061
  %24 = icmp slt i32 %23, 1044381696, !dbg !2063
  br i1 %24, label %25, label %31, !dbg !2064

25:                                               ; preds = %20
  %26 = load double, ptr %4, align 8, !dbg !2065
  %27 = fptosi double %26 to i32, !dbg !2068
  %28 = icmp eq i32 %27, 0, !dbg !2069
  br i1 %28, label %29, label %30, !dbg !2070

29:                                               ; preds = %25
  store double 1.000000e+00, ptr %3, align 8, !dbg !2071
  br label %96, !dbg !2071

30:                                               ; preds = %25
  br label %31, !dbg !2072

31:                                               ; preds = %30, %20
  %32 = load double, ptr %4, align 8, !dbg !2073
  %33 = load double, ptr %4, align 8, !dbg !2074
  %34 = fmul double %32, %33, !dbg !2075
  store double %34, ptr %8, align 8, !dbg !2076
  %35 = load double, ptr %8, align 8, !dbg !2077
  %36 = load double, ptr %8, align 8, !dbg !2078
  %37 = load double, ptr %8, align 8, !dbg !2079
  %38 = load double, ptr %8, align 8, !dbg !2080
  %39 = load double, ptr %8, align 8, !dbg !2081
  %40 = load double, ptr %8, align 8, !dbg !2082
  %41 = call double @llvm.fmuladd.f64(double %40, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2083
  %42 = call double @llvm.fmuladd.f64(double %39, double %41, double 0xBE927E4F809C52AD), !dbg !2084
  %43 = call double @llvm.fmuladd.f64(double %38, double %42, double 0x3EFA01A019CB1590), !dbg !2085
  %44 = call double @llvm.fmuladd.f64(double %37, double %43, double 0xBF56C16C16C15177), !dbg !2086
  %45 = call double @llvm.fmuladd.f64(double %36, double %44, double 0x3FA555555555554C), !dbg !2087
  %46 = fmul double %35, %45, !dbg !2088
  store double %46, ptr %9, align 8, !dbg !2089
  %47 = load i32, ptr %11, align 4, !dbg !2090
  %48 = icmp slt i32 %47, 1070805811, !dbg !2092
  br i1 %48, label %49, label %61, !dbg !2093

49:                                               ; preds = %31
  %50 = load double, ptr %8, align 8, !dbg !2094
  %51 = load double, ptr %8, align 8, !dbg !2096
  %52 = load double, ptr %9, align 8, !dbg !2097
  %53 = load double, ptr %4, align 8, !dbg !2098
  %54 = load double, ptr %5, align 8, !dbg !2099
  %55 = fmul double %53, %54, !dbg !2100
  %56 = fneg double %55, !dbg !2101
  %57 = call double @llvm.fmuladd.f64(double %51, double %52, double %56), !dbg !2101
  %58 = fneg double %57, !dbg !2102
  %59 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %50, double %58), !dbg !2102
  %60 = fsub double 1.000000e+00, %59, !dbg !2103
  store double %60, ptr %3, align 8, !dbg !2104
  br label %96, !dbg !2104

61:                                               ; preds = %31
  %62 = load i32, ptr %11, align 4, !dbg !2105
  %63 = icmp sgt i32 %62, 1072234496, !dbg !2108
  br i1 %63, label %64, label %65, !dbg !2109

64:                                               ; preds = %61
  store double 2.812500e-01, ptr %10, align 8, !dbg !2110
  br label %78, !dbg !2112

65:                                               ; preds = %61
  br label %66, !dbg !2113

66:                                               ; preds = %65
  call void @llvm.dbg.declare(metadata ptr %13, metadata !2115, metadata !DIExpression()), !dbg !2117
  store i64 0, ptr %13, align 8, !dbg !2117
  %67 = load i32, ptr %11, align 4, !dbg !2117
  %68 = sub nsw i32 %67, 2097152, !dbg !2117
  %69 = sext i32 %68 to i64, !dbg !2117
  %70 = shl i64 %69, 32, !dbg !2117
  %71 = load i64, ptr %13, align 8, !dbg !2117
  %72 = or i64 %71, %70, !dbg !2117
  store i64 %72, ptr %13, align 8, !dbg !2117
  %73 = load i64, ptr %13, align 8, !dbg !2117
  %74 = or i64 %73, 0, !dbg !2117
  store i64 %74, ptr %13, align 8, !dbg !2117
  %75 = load i64, ptr %13, align 8, !dbg !2117
  %76 = call double @double_of(i64 noundef %75), !dbg !2117
  store double %76, ptr %10, align 8, !dbg !2117
  br label %77, !dbg !2117

77:                                               ; preds = %66
  br label %78

78:                                               ; preds = %77, %64
  %79 = load double, ptr %8, align 8, !dbg !2118
  %80 = load double, ptr %10, align 8, !dbg !2119
  %81 = fneg double %80, !dbg !2120
  %82 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %79, double %81), !dbg !2120
  store double %82, ptr %7, align 8, !dbg !2121
  %83 = load double, ptr %10, align 8, !dbg !2122
  %84 = fsub double 1.000000e+00, %83, !dbg !2123
  store double %84, ptr %6, align 8, !dbg !2124
  %85 = load double, ptr %6, align 8, !dbg !2125
  %86 = load double, ptr %7, align 8, !dbg !2126
  %87 = load double, ptr %8, align 8, !dbg !2127
  %88 = load double, ptr %9, align 8, !dbg !2128
  %89 = load double, ptr %4, align 8, !dbg !2129
  %90 = load double, ptr %5, align 8, !dbg !2130
  %91 = fmul double %89, %90, !dbg !2131
  %92 = fneg double %91, !dbg !2132
  %93 = call double @llvm.fmuladd.f64(double %87, double %88, double %92), !dbg !2132
  %94 = fsub double %86, %93, !dbg !2133
  %95 = fsub double %85, %94, !dbg !2134
  store double %95, ptr %3, align 8, !dbg !2135
  br label %96, !dbg !2135

96:                                               ; preds = %78, %49, %29
  %97 = load double, ptr %3, align 8, !dbg !2136
  ret double %97, !dbg !2136
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef %1) #0 !dbg !313 {
  %3 = alloca i32, align 4
  %4 = alloca double, align 8
  %5 = alloca ptr, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca [3 x double], align 8
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca i64, align 8
  %21 = alloca i32, align 4
  %22 = alloca i64, align 8
  %23 = alloca i64, align 8
  %24 = alloca i64, align 8
  %25 = alloca i64, align 8
  %26 = alloca i64, align 8
  store double %0, ptr %4, align 8
  call void @llvm.dbg.declare(metadata ptr %4, metadata !2137, metadata !DIExpression()), !dbg !2138
  store ptr %1, ptr %5, align 8
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2139, metadata !DIExpression()), !dbg !2140
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2141, metadata !DIExpression()), !dbg !2142
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2143, metadata !DIExpression()), !dbg !2144
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2145, metadata !DIExpression()), !dbg !2146
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2147, metadata !DIExpression()), !dbg !2148
  call void @llvm.dbg.declare(metadata ptr %10, metadata !2149, metadata !DIExpression()), !dbg !2150
  call void @llvm.dbg.declare(metadata ptr %11, metadata !2151, metadata !DIExpression()), !dbg !2155
  call void @llvm.dbg.declare(metadata ptr %12, metadata !2156, metadata !DIExpression()), !dbg !2157
  call void @llvm.dbg.declare(metadata ptr %13, metadata !2158, metadata !DIExpression()), !dbg !2159
  call void @llvm.dbg.declare(metadata ptr %14, metadata !2160, metadata !DIExpression()), !dbg !2161
  call void @llvm.dbg.declare(metadata ptr %15, metadata !2162, metadata !DIExpression()), !dbg !2163
  call void @llvm.dbg.declare(metadata ptr %16, metadata !2164, metadata !DIExpression()), !dbg !2165
  call void @llvm.dbg.declare(metadata ptr %17, metadata !2166, metadata !DIExpression()), !dbg !2167
  call void @llvm.dbg.declare(metadata ptr %18, metadata !2168, metadata !DIExpression()), !dbg !2169
  call void @llvm.dbg.declare(metadata ptr %19, metadata !2170, metadata !DIExpression()), !dbg !2171
  store double 0.000000e+00, ptr %6, align 8, !dbg !2172
  br label %27, !dbg !2173

27:                                               ; preds = %2
  call void @llvm.dbg.declare(metadata ptr %20, metadata !2174, metadata !DIExpression()), !dbg !2176
  %28 = load double, ptr %4, align 8, !dbg !2176
  %29 = call i64 @bits_of(double noundef %28), !dbg !2176
  store i64 %29, ptr %20, align 8, !dbg !2176
  %30 = load i64, ptr %20, align 8, !dbg !2176
  %31 = lshr i64 %30, 32, !dbg !2176
  %32 = trunc i64 %31 to i32, !dbg !2176
  store i32 %32, ptr %18, align 4, !dbg !2176
  br label %33, !dbg !2176

33:                                               ; preds = %27
  %34 = load i32, ptr %18, align 4, !dbg !2177
  %35 = and i32 %34, 2147483647, !dbg !2178
  store i32 %35, ptr %17, align 4, !dbg !2179
  %36 = load i32, ptr %17, align 4, !dbg !2180
  %37 = icmp sle i32 %36, 1072243195, !dbg !2182
  br i1 %37, label %38, label %44, !dbg !2183

38:                                               ; preds = %33
  %39 = load double, ptr %4, align 8, !dbg !2184
  %40 = load ptr, ptr %5, align 8, !dbg !2186
  %41 = getelementptr inbounds double, ptr %40, i64 0, !dbg !2186
  store double %39, ptr %41, align 8, !dbg !2187
  %42 = load ptr, ptr %5, align 8, !dbg !2188
  %43 = getelementptr inbounds double, ptr %42, i64 1, !dbg !2188
  store double 0.000000e+00, ptr %43, align 8, !dbg !2189
  store i32 0, ptr %3, align 4, !dbg !2190
  br label %370, !dbg !2190

44:                                               ; preds = %33
  %45 = load i32, ptr %17, align 4, !dbg !2191
  %46 = icmp slt i32 %45, 1073928572, !dbg !2193
  br i1 %46, label %47, label %118, !dbg !2194

47:                                               ; preds = %44
  %48 = load i32, ptr %18, align 4, !dbg !2195
  %49 = icmp sgt i32 %48, 0, !dbg !2198
  br i1 %49, label %50, label %84, !dbg !2199

50:                                               ; preds = %47
  %51 = load double, ptr %4, align 8, !dbg !2200
  %52 = fsub double %51, 0x3FF921FB54400000, !dbg !2202
  store double %52, ptr %6, align 8, !dbg !2203
  %53 = load i32, ptr %17, align 4, !dbg !2204
  %54 = icmp ne i32 %53, 1073291771, !dbg !2206
  br i1 %54, label %55, label %68, !dbg !2207

55:                                               ; preds = %50
  %56 = load double, ptr %6, align 8, !dbg !2208
  %57 = fsub double %56, 0x3DD0B4611A626331, !dbg !2210
  %58 = load ptr, ptr %5, align 8, !dbg !2211
  %59 = getelementptr inbounds double, ptr %58, i64 0, !dbg !2211
  store double %57, ptr %59, align 8, !dbg !2212
  %60 = load double, ptr %6, align 8, !dbg !2213
  %61 = load ptr, ptr %5, align 8, !dbg !2214
  %62 = getelementptr inbounds double, ptr %61, i64 0, !dbg !2214
  %63 = load double, ptr %62, align 8, !dbg !2214
  %64 = fsub double %60, %63, !dbg !2215
  %65 = fsub double %64, 0x3DD0B4611A626331, !dbg !2216
  %66 = load ptr, ptr %5, align 8, !dbg !2217
  %67 = getelementptr inbounds double, ptr %66, i64 1, !dbg !2217
  store double %65, ptr %67, align 8, !dbg !2218
  br label %83, !dbg !2219

68:                                               ; preds = %50
  %69 = load double, ptr %6, align 8, !dbg !2220
  %70 = fsub double %69, 0x3DD0B4611A600000, !dbg !2220
  store double %70, ptr %6, align 8, !dbg !2220
  %71 = load double, ptr %6, align 8, !dbg !2222
  %72 = fsub double %71, 0x3BA3198A2E037073, !dbg !2223
  %73 = load ptr, ptr %5, align 8, !dbg !2224
  %74 = getelementptr inbounds double, ptr %73, i64 0, !dbg !2224
  store double %72, ptr %74, align 8, !dbg !2225
  %75 = load double, ptr %6, align 8, !dbg !2226
  %76 = load ptr, ptr %5, align 8, !dbg !2227
  %77 = getelementptr inbounds double, ptr %76, i64 0, !dbg !2227
  %78 = load double, ptr %77, align 8, !dbg !2227
  %79 = fsub double %75, %78, !dbg !2228
  %80 = fsub double %79, 0x3BA3198A2E037073, !dbg !2229
  %81 = load ptr, ptr %5, align 8, !dbg !2230
  %82 = getelementptr inbounds double, ptr %81, i64 1, !dbg !2230
  store double %80, ptr %82, align 8, !dbg !2231
  br label %83

83:                                               ; preds = %68, %55
  store i32 1, ptr %3, align 4, !dbg !2232
  br label %370, !dbg !2232

84:                                               ; preds = %47
  %85 = load double, ptr %4, align 8, !dbg !2233
  %86 = fadd double %85, 0x3FF921FB54400000, !dbg !2235
  store double %86, ptr %6, align 8, !dbg !2236
  %87 = load i32, ptr %17, align 4, !dbg !2237
  %88 = icmp ne i32 %87, 1073291771, !dbg !2239
  br i1 %88, label %89, label %102, !dbg !2240

89:                                               ; preds = %84
  %90 = load double, ptr %6, align 8, !dbg !2241
  %91 = fadd double %90, 0x3DD0B4611A626331, !dbg !2243
  %92 = load ptr, ptr %5, align 8, !dbg !2244
  %93 = getelementptr inbounds double, ptr %92, i64 0, !dbg !2244
  store double %91, ptr %93, align 8, !dbg !2245
  %94 = load double, ptr %6, align 8, !dbg !2246
  %95 = load ptr, ptr %5, align 8, !dbg !2247
  %96 = getelementptr inbounds double, ptr %95, i64 0, !dbg !2247
  %97 = load double, ptr %96, align 8, !dbg !2247
  %98 = fsub double %94, %97, !dbg !2248
  %99 = fadd double %98, 0x3DD0B4611A626331, !dbg !2249
  %100 = load ptr, ptr %5, align 8, !dbg !2250
  %101 = getelementptr inbounds double, ptr %100, i64 1, !dbg !2250
  store double %99, ptr %101, align 8, !dbg !2251
  br label %117, !dbg !2252

102:                                              ; preds = %84
  %103 = load double, ptr %6, align 8, !dbg !2253
  %104 = fadd double %103, 0x3DD0B4611A600000, !dbg !2253
  store double %104, ptr %6, align 8, !dbg !2253
  %105 = load double, ptr %6, align 8, !dbg !2255
  %106 = fadd double %105, 0x3BA3198A2E037073, !dbg !2256
  %107 = load ptr, ptr %5, align 8, !dbg !2257
  %108 = getelementptr inbounds double, ptr %107, i64 0, !dbg !2257
  store double %106, ptr %108, align 8, !dbg !2258
  %109 = load double, ptr %6, align 8, !dbg !2259
  %110 = load ptr, ptr %5, align 8, !dbg !2260
  %111 = getelementptr inbounds double, ptr %110, i64 0, !dbg !2260
  %112 = load double, ptr %111, align 8, !dbg !2260
  %113 = fsub double %109, %112, !dbg !2261
  %114 = fadd double %113, 0x3BA3198A2E037073, !dbg !2262
  %115 = load ptr, ptr %5, align 8, !dbg !2263
  %116 = getelementptr inbounds double, ptr %115, i64 1, !dbg !2263
  store double %114, ptr %116, align 8, !dbg !2264
  br label %117

117:                                              ; preds = %102, %89
  store i32 -1, ptr %3, align 4, !dbg !2265
  br label %370, !dbg !2265

118:                                              ; preds = %44
  %119 = load i32, ptr %17, align 4, !dbg !2266
  %120 = icmp sle i32 %119, 1094263291, !dbg !2268
  br i1 %120, label %121, label %262, !dbg !2269

121:                                              ; preds = %118
  %122 = load double, ptr %4, align 8, !dbg !2270
  %123 = call double @llvm.fabs.f64(double %122), !dbg !2272
  store double %123, ptr %8, align 8, !dbg !2273
  %124 = load double, ptr %8, align 8, !dbg !2274
  %125 = call double @llvm.fmuladd.f64(double %124, double 0x3FE45F306DC9C883, double 5.000000e-01), !dbg !2275
  %126 = fptosi double %125 to i32, !dbg !2276
  store i32 %126, ptr %16, align 4, !dbg !2277
  %127 = load i32, ptr %16, align 4, !dbg !2278
  %128 = sitofp i32 %127 to double, !dbg !2279
  store double %128, ptr %10, align 8, !dbg !2280
  %129 = load double, ptr %8, align 8, !dbg !2281
  %130 = load double, ptr %10, align 8, !dbg !2282
  %131 = fneg double %130, !dbg !2283
  %132 = call double @llvm.fmuladd.f64(double %131, double 0x3FF921FB54400000, double %129), !dbg !2283
  store double %132, ptr %9, align 8, !dbg !2284
  %133 = load double, ptr %10, align 8, !dbg !2285
  %134 = fmul double %133, 0x3DD0B4611A626331, !dbg !2286
  store double %134, ptr %7, align 8, !dbg !2287
  %135 = load i32, ptr %16, align 4, !dbg !2288
  %136 = icmp slt i32 %135, 32, !dbg !2290
  br i1 %136, label %137, label %151, !dbg !2291

137:                                              ; preds = %121
  %138 = load i32, ptr %17, align 4, !dbg !2292
  %139 = load i32, ptr %16, align 4, !dbg !2293
  %140 = sub nsw i32 %139, 1, !dbg !2294
  %141 = sext i32 %140 to i64, !dbg !2295
  %142 = getelementptr inbounds [32 x i32], ptr @__ieee754_rem_pio2.npio2_hw, i64 0, i64 %141, !dbg !2295
  %143 = load i32, ptr %142, align 4, !dbg !2295
  %144 = icmp ne i32 %138, %143, !dbg !2296
  br i1 %144, label %145, label %151, !dbg !2297

145:                                              ; preds = %137
  %146 = load double, ptr %9, align 8, !dbg !2298
  %147 = load double, ptr %7, align 8, !dbg !2300
  %148 = fsub double %146, %147, !dbg !2301
  %149 = load ptr, ptr %5, align 8, !dbg !2302
  %150 = getelementptr inbounds double, ptr %149, i64 0, !dbg !2302
  store double %148, ptr %150, align 8, !dbg !2303
  br label %233, !dbg !2304

151:                                              ; preds = %137, %121
  call void @llvm.dbg.declare(metadata ptr %21, metadata !2305, metadata !DIExpression()), !dbg !2307
  %152 = load i32, ptr %17, align 4, !dbg !2308
  %153 = ashr i32 %152, 20, !dbg !2309
  store i32 %153, ptr %14, align 4, !dbg !2310
  %154 = load double, ptr %9, align 8, !dbg !2311
  %155 = load double, ptr %7, align 8, !dbg !2312
  %156 = fsub double %154, %155, !dbg !2313
  %157 = load ptr, ptr %5, align 8, !dbg !2314
  %158 = getelementptr inbounds double, ptr %157, i64 0, !dbg !2314
  store double %156, ptr %158, align 8, !dbg !2315
  br label %159, !dbg !2316

159:                                              ; preds = %151
  call void @llvm.dbg.declare(metadata ptr %22, metadata !2317, metadata !DIExpression()), !dbg !2319
  %160 = load ptr, ptr %5, align 8, !dbg !2319
  %161 = getelementptr inbounds double, ptr %160, i64 0, !dbg !2319
  %162 = load double, ptr %161, align 8, !dbg !2319
  %163 = call i64 @bits_of(double noundef %162), !dbg !2319
  store i64 %163, ptr %22, align 8, !dbg !2319
  %164 = load i64, ptr %22, align 8, !dbg !2319
  %165 = lshr i64 %164, 32, !dbg !2319
  %166 = trunc i64 %165 to i32, !dbg !2319
  store i32 %166, ptr %21, align 4, !dbg !2319
  br label %167, !dbg !2319

167:                                              ; preds = %159
  %168 = load i32, ptr %14, align 4, !dbg !2320
  %169 = load i32, ptr %21, align 4, !dbg !2321
  %170 = lshr i32 %169, 20, !dbg !2322
  %171 = and i32 %170, 2047, !dbg !2323
  %172 = sub i32 %168, %171, !dbg !2324
  store i32 %172, ptr %13, align 4, !dbg !2325
  %173 = load i32, ptr %13, align 4, !dbg !2326
  %174 = icmp sgt i32 %173, 16, !dbg !2328
  br i1 %174, label %175, label %232, !dbg !2329

175:                                              ; preds = %167
  %176 = load double, ptr %9, align 8, !dbg !2330
  store double %176, ptr %8, align 8, !dbg !2332
  %177 = load double, ptr %10, align 8, !dbg !2333
  %178 = fmul double %177, 0x3DD0B4611A600000, !dbg !2334
  store double %178, ptr %7, align 8, !dbg !2335
  %179 = load double, ptr %8, align 8, !dbg !2336
  %180 = load double, ptr %7, align 8, !dbg !2337
  %181 = fsub double %179, %180, !dbg !2338
  store double %181, ptr %9, align 8, !dbg !2339
  %182 = load double, ptr %10, align 8, !dbg !2340
  %183 = load double, ptr %8, align 8, !dbg !2341
  %184 = load double, ptr %9, align 8, !dbg !2342
  %185 = fsub double %183, %184, !dbg !2343
  %186 = load double, ptr %7, align 8, !dbg !2344
  %187 = fsub double %185, %186, !dbg !2345
  %188 = fneg double %187, !dbg !2346
  %189 = call double @llvm.fmuladd.f64(double %182, double 0x3BA3198A2E037073, double %188), !dbg !2346
  store double %189, ptr %7, align 8, !dbg !2347
  %190 = load double, ptr %9, align 8, !dbg !2348
  %191 = load double, ptr %7, align 8, !dbg !2349
  %192 = fsub double %190, %191, !dbg !2350
  %193 = load ptr, ptr %5, align 8, !dbg !2351
  %194 = getelementptr inbounds double, ptr %193, i64 0, !dbg !2351
  store double %192, ptr %194, align 8, !dbg !2352
  br label %195, !dbg !2353

195:                                              ; preds = %175
  call void @llvm.dbg.declare(metadata ptr %23, metadata !2354, metadata !DIExpression()), !dbg !2356
  %196 = load ptr, ptr %5, align 8, !dbg !2356
  %197 = getelementptr inbounds double, ptr %196, i64 0, !dbg !2356
  %198 = load double, ptr %197, align 8, !dbg !2356
  %199 = call i64 @bits_of(double noundef %198), !dbg !2356
  store i64 %199, ptr %23, align 8, !dbg !2356
  %200 = load i64, ptr %23, align 8, !dbg !2356
  %201 = lshr i64 %200, 32, !dbg !2356
  %202 = trunc i64 %201 to i32, !dbg !2356
  store i32 %202, ptr %21, align 4, !dbg !2356
  br label %203, !dbg !2356

203:                                              ; preds = %195
  %204 = load i32, ptr %14, align 4, !dbg !2357
  %205 = load i32, ptr %21, align 4, !dbg !2358
  %206 = lshr i32 %205, 20, !dbg !2359
  %207 = and i32 %206, 2047, !dbg !2360
  %208 = sub i32 %204, %207, !dbg !2361
  store i32 %208, ptr %13, align 4, !dbg !2362
  %209 = load i32, ptr %13, align 4, !dbg !2363
  %210 = icmp sgt i32 %209, 49, !dbg !2365
  br i1 %210, label %211, label %231, !dbg !2366

211:                                              ; preds = %203
  %212 = load double, ptr %9, align 8, !dbg !2367
  store double %212, ptr %8, align 8, !dbg !2369
  %213 = load double, ptr %10, align 8, !dbg !2370
  %214 = fmul double %213, 0x3BA3198A2E000000, !dbg !2371
  store double %214, ptr %7, align 8, !dbg !2372
  %215 = load double, ptr %8, align 8, !dbg !2373
  %216 = load double, ptr %7, align 8, !dbg !2374
  %217 = fsub double %215, %216, !dbg !2375
  store double %217, ptr %9, align 8, !dbg !2376
  %218 = load double, ptr %10, align 8, !dbg !2377
  %219 = load double, ptr %8, align 8, !dbg !2378
  %220 = load double, ptr %9, align 8, !dbg !2379
  %221 = fsub double %219, %220, !dbg !2380
  %222 = load double, ptr %7, align 8, !dbg !2381
  %223 = fsub double %221, %222, !dbg !2382
  %224 = fneg double %223, !dbg !2383
  %225 = call double @llvm.fmuladd.f64(double %218, double 0x397B839A252049C1, double %224), !dbg !2383
  store double %225, ptr %7, align 8, !dbg !2384
  %226 = load double, ptr %9, align 8, !dbg !2385
  %227 = load double, ptr %7, align 8, !dbg !2386
  %228 = fsub double %226, %227, !dbg !2387
  %229 = load ptr, ptr %5, align 8, !dbg !2388
  %230 = getelementptr inbounds double, ptr %229, i64 0, !dbg !2388
  store double %228, ptr %230, align 8, !dbg !2389
  br label %231, !dbg !2390

231:                                              ; preds = %211, %203
  br label %232, !dbg !2391

232:                                              ; preds = %231, %167
  br label %233

233:                                              ; preds = %232, %145
  %234 = load double, ptr %9, align 8, !dbg !2392
  %235 = load ptr, ptr %5, align 8, !dbg !2393
  %236 = getelementptr inbounds double, ptr %235, i64 0, !dbg !2393
  %237 = load double, ptr %236, align 8, !dbg !2393
  %238 = fsub double %234, %237, !dbg !2394
  %239 = load double, ptr %7, align 8, !dbg !2395
  %240 = fsub double %238, %239, !dbg !2396
  %241 = load ptr, ptr %5, align 8, !dbg !2397
  %242 = getelementptr inbounds double, ptr %241, i64 1, !dbg !2397
  store double %240, ptr %242, align 8, !dbg !2398
  %243 = load i32, ptr %18, align 4, !dbg !2399
  %244 = icmp slt i32 %243, 0, !dbg !2401
  br i1 %244, label %245, label %260, !dbg !2402

245:                                              ; preds = %233
  %246 = load ptr, ptr %5, align 8, !dbg !2403
  %247 = getelementptr inbounds double, ptr %246, i64 0, !dbg !2403
  %248 = load double, ptr %247, align 8, !dbg !2403
  %249 = fneg double %248, !dbg !2405
  %250 = load ptr, ptr %5, align 8, !dbg !2406
  %251 = getelementptr inbounds double, ptr %250, i64 0, !dbg !2406
  store double %249, ptr %251, align 8, !dbg !2407
  %252 = load ptr, ptr %5, align 8, !dbg !2408
  %253 = getelementptr inbounds double, ptr %252, i64 1, !dbg !2408
  %254 = load double, ptr %253, align 8, !dbg !2408
  %255 = fneg double %254, !dbg !2409
  %256 = load ptr, ptr %5, align 8, !dbg !2410
  %257 = getelementptr inbounds double, ptr %256, i64 1, !dbg !2410
  store double %255, ptr %257, align 8, !dbg !2411
  %258 = load i32, ptr %16, align 4, !dbg !2412
  %259 = sub nsw i32 0, %258, !dbg !2413
  store i32 %259, ptr %3, align 4, !dbg !2414
  br label %370, !dbg !2414

260:                                              ; preds = %233
  %261 = load i32, ptr %16, align 4, !dbg !2415
  store i32 %261, ptr %3, align 4, !dbg !2417
  br label %370, !dbg !2417

262:                                              ; preds = %118
  %263 = load i32, ptr %17, align 4, !dbg !2418
  %264 = icmp sge i32 %263, 2146435072, !dbg !2420
  br i1 %264, label %265, label %273, !dbg !2421

265:                                              ; preds = %262
  %266 = load double, ptr %4, align 8, !dbg !2422
  %267 = load double, ptr %4, align 8, !dbg !2424
  %268 = fsub double %266, %267, !dbg !2425
  %269 = load ptr, ptr %5, align 8, !dbg !2426
  %270 = getelementptr inbounds double, ptr %269, i64 1, !dbg !2426
  store double %268, ptr %270, align 8, !dbg !2427
  %271 = load ptr, ptr %5, align 8, !dbg !2428
  %272 = getelementptr inbounds double, ptr %271, i64 0, !dbg !2428
  store double %268, ptr %272, align 8, !dbg !2429
  store i32 0, ptr %3, align 4, !dbg !2430
  br label %370, !dbg !2430

273:                                              ; preds = %262
  br label %274, !dbg !2431

274:                                              ; preds = %273
  call void @llvm.dbg.declare(metadata ptr %24, metadata !2432, metadata !DIExpression()), !dbg !2434
  %275 = load double, ptr %4, align 8, !dbg !2434
  %276 = call i64 @bits_of(double noundef %275), !dbg !2434
  store i64 %276, ptr %24, align 8, !dbg !2434
  %277 = load i64, ptr %24, align 8, !dbg !2434
  %278 = and i64 %277, 4294967295, !dbg !2434
  %279 = trunc i64 %278 to i32, !dbg !2434
  store i32 %279, ptr %19, align 4, !dbg !2434
  br label %280, !dbg !2434

280:                                              ; preds = %274
  br label %281, !dbg !2435

281:                                              ; preds = %280
  call void @llvm.dbg.declare(metadata ptr %25, metadata !2436, metadata !DIExpression()), !dbg !2438
  %282 = load double, ptr %6, align 8, !dbg !2438
  %283 = call i64 @bits_of(double noundef %282), !dbg !2438
  store i64 %283, ptr %25, align 8, !dbg !2438
  %284 = load i64, ptr %25, align 8, !dbg !2438
  %285 = and i64 %284, -4294967296, !dbg !2438
  store i64 %285, ptr %25, align 8, !dbg !2438
  %286 = load i32, ptr %19, align 4, !dbg !2438
  %287 = zext i32 %286 to i64, !dbg !2438
  %288 = load i64, ptr %25, align 8, !dbg !2438
  %289 = or i64 %288, %287, !dbg !2438
  store i64 %289, ptr %25, align 8, !dbg !2438
  %290 = load i64, ptr %25, align 8, !dbg !2438
  %291 = call double @double_of(i64 noundef %290), !dbg !2438
  store double %291, ptr %6, align 8, !dbg !2438
  br label %292, !dbg !2438

292:                                              ; preds = %281
  %293 = load i32, ptr %17, align 4, !dbg !2439
  %294 = ashr i32 %293, 20, !dbg !2440
  %295 = sub nsw i32 %294, 1046, !dbg !2441
  store i32 %295, ptr %12, align 4, !dbg !2442
  br label %296, !dbg !2443

296:                                              ; preds = %292
  call void @llvm.dbg.declare(metadata ptr %26, metadata !2444, metadata !DIExpression()), !dbg !2446
  %297 = load double, ptr %6, align 8, !dbg !2446
  %298 = call i64 @bits_of(double noundef %297), !dbg !2446
  store i64 %298, ptr %26, align 8, !dbg !2446
  %299 = load i64, ptr %26, align 8, !dbg !2446
  %300 = and i64 %299, 4294967295, !dbg !2446
  store i64 %300, ptr %26, align 8, !dbg !2446
  %301 = load i32, ptr %17, align 4, !dbg !2446
  %302 = load i32, ptr %12, align 4, !dbg !2446
  %303 = shl i32 %302, 20, !dbg !2446
  %304 = sub nsw i32 %301, %303, !dbg !2446
  %305 = sext i32 %304 to i64, !dbg !2446
  %306 = shl i64 %305, 32, !dbg !2446
  %307 = load i64, ptr %26, align 8, !dbg !2446
  %308 = or i64 %307, %306, !dbg !2446
  store i64 %308, ptr %26, align 8, !dbg !2446
  %309 = load i64, ptr %26, align 8, !dbg !2446
  %310 = call double @double_of(i64 noundef %309), !dbg !2446
  store double %310, ptr %6, align 8, !dbg !2446
  br label %311, !dbg !2446

311:                                              ; preds = %296
  store i32 0, ptr %13, align 4, !dbg !2447
  br label %312, !dbg !2449

312:                                              ; preds = %329, %311
  %313 = load i32, ptr %13, align 4, !dbg !2450
  %314 = icmp slt i32 %313, 2, !dbg !2452
  br i1 %314, label %315, label %332, !dbg !2453

315:                                              ; preds = %312
  %316 = load double, ptr %6, align 8, !dbg !2454
  %317 = fptosi double %316 to i32, !dbg !2456
  %318 = sitofp i32 %317 to double, !dbg !2457
  %319 = load i32, ptr %13, align 4, !dbg !2458
  %320 = sext i32 %319 to i64, !dbg !2459
  %321 = getelementptr inbounds [3 x double], ptr %11, i64 0, i64 %320, !dbg !2459
  store double %318, ptr %321, align 8, !dbg !2460
  %322 = load double, ptr %6, align 8, !dbg !2461
  %323 = load i32, ptr %13, align 4, !dbg !2462
  %324 = sext i32 %323 to i64, !dbg !2463
  %325 = getelementptr inbounds [3 x double], ptr %11, i64 0, i64 %324, !dbg !2463
  %326 = load double, ptr %325, align 8, !dbg !2463
  %327 = fsub double %322, %326, !dbg !2464
  %328 = fmul double %327, 0x4170000000000000, !dbg !2465
  store double %328, ptr %6, align 8, !dbg !2466
  br label %329, !dbg !2467

329:                                              ; preds = %315
  %330 = load i32, ptr %13, align 4, !dbg !2468
  %331 = add nsw i32 %330, 1, !dbg !2468
  store i32 %331, ptr %13, align 4, !dbg !2468
  br label %312, !dbg !2469, !llvm.loop !2470

332:                                              ; preds = %312
  %333 = load double, ptr %6, align 8, !dbg !2473
  %334 = getelementptr inbounds [3 x double], ptr %11, i64 0, i64 2, !dbg !2474
  store double %333, ptr %334, align 8, !dbg !2475
  store i32 3, ptr %15, align 4, !dbg !2476
  br label %335, !dbg !2477

335:                                              ; preds = %342, %332
  %336 = load i32, ptr %15, align 4, !dbg !2478
  %337 = sub nsw i32 %336, 1, !dbg !2479
  %338 = sext i32 %337 to i64, !dbg !2480
  %339 = getelementptr inbounds [3 x double], ptr %11, i64 0, i64 %338, !dbg !2480
  %340 = load double, ptr %339, align 8, !dbg !2480
  %341 = fcmp oeq double %340, 0.000000e+00, !dbg !2481
  br i1 %341, label %342, label %345, !dbg !2477

342:                                              ; preds = %335
  %343 = load i32, ptr %15, align 4, !dbg !2482
  %344 = add nsw i32 %343, -1, !dbg !2482
  store i32 %344, ptr %15, align 4, !dbg !2482
  br label %335, !dbg !2477, !llvm.loop !2483

345:                                              ; preds = %335
  %346 = getelementptr inbounds [3 x double], ptr %11, i64 0, i64 0, !dbg !2484
  %347 = load ptr, ptr %5, align 8, !dbg !2485
  %348 = load i32, ptr %12, align 4, !dbg !2486
  %349 = load i32, ptr %15, align 4, !dbg !2487
  %350 = call i32 @__kernel_rem_pio2(ptr noundef %346, ptr noundef %347, i32 noundef %348, i32 noundef %349, i32 noundef 2, ptr noundef @__ieee754_rem_pio2.two_over_pi), !dbg !2488
  store i32 %350, ptr %16, align 4, !dbg !2489
  %351 = load i32, ptr %18, align 4, !dbg !2490
  %352 = icmp slt i32 %351, 0, !dbg !2492
  br i1 %352, label %353, label %368, !dbg !2493

353:                                              ; preds = %345
  %354 = load ptr, ptr %5, align 8, !dbg !2494
  %355 = getelementptr inbounds double, ptr %354, i64 0, !dbg !2494
  %356 = load double, ptr %355, align 8, !dbg !2494
  %357 = fneg double %356, !dbg !2496
  %358 = load ptr, ptr %5, align 8, !dbg !2497
  %359 = getelementptr inbounds double, ptr %358, i64 0, !dbg !2497
  store double %357, ptr %359, align 8, !dbg !2498
  %360 = load ptr, ptr %5, align 8, !dbg !2499
  %361 = getelementptr inbounds double, ptr %360, i64 1, !dbg !2499
  %362 = load double, ptr %361, align 8, !dbg !2499
  %363 = fneg double %362, !dbg !2500
  %364 = load ptr, ptr %5, align 8, !dbg !2501
  %365 = getelementptr inbounds double, ptr %364, i64 1, !dbg !2501
  store double %363, ptr %365, align 8, !dbg !2502
  %366 = load i32, ptr %16, align 4, !dbg !2503
  %367 = sub nsw i32 0, %366, !dbg !2504
  store i32 %367, ptr %3, align 4, !dbg !2505
  br label %370, !dbg !2505

368:                                              ; preds = %345
  %369 = load i32, ptr %16, align 4, !dbg !2506
  store i32 %369, ptr %3, align 4, !dbg !2507
  br label %370, !dbg !2507

370:                                              ; preds = %368, %353, %265, %260, %245, %117, %83, %38
  %371 = load i32, ptr %3, align 4, !dbg !2508
  ret i32 %371, !dbg !2508
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal double @__kernel_sin(double noundef %0, double noundef %1, i32 noundef %2) #0 !dbg !369 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca i32, align 4
  %12 = alloca i64, align 8
  store double %0, ptr %5, align 8
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2509, metadata !DIExpression()), !dbg !2510
  store double %1, ptr %6, align 8
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2511, metadata !DIExpression()), !dbg !2512
  store i32 %2, ptr %7, align 4
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2513, metadata !DIExpression()), !dbg !2514
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2515, metadata !DIExpression()), !dbg !2516
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2517, metadata !DIExpression()), !dbg !2518
  call void @llvm.dbg.declare(metadata ptr %10, metadata !2519, metadata !DIExpression()), !dbg !2520
  call void @llvm.dbg.declare(metadata ptr %11, metadata !2521, metadata !DIExpression()), !dbg !2522
  br label %13, !dbg !2523

13:                                               ; preds = %3
  call void @llvm.dbg.declare(metadata ptr %12, metadata !2524, metadata !DIExpression()), !dbg !2526
  %14 = load double, ptr %5, align 8, !dbg !2526
  %15 = call i64 @bits_of(double noundef %14), !dbg !2526
  store i64 %15, ptr %12, align 8, !dbg !2526
  %16 = load i64, ptr %12, align 8, !dbg !2526
  %17 = lshr i64 %16, 32, !dbg !2526
  %18 = trunc i64 %17 to i32, !dbg !2526
  store i32 %18, ptr %11, align 4, !dbg !2526
  br label %19, !dbg !2526

19:                                               ; preds = %13
  %20 = load i32, ptr %11, align 4, !dbg !2527
  %21 = and i32 %20, 2147483647, !dbg !2527
  store i32 %21, ptr %11, align 4, !dbg !2527
  %22 = load i32, ptr %11, align 4, !dbg !2528
  %23 = icmp slt i32 %22, 1044381696, !dbg !2530
  br i1 %23, label %24, label %31, !dbg !2531

24:                                               ; preds = %19
  %25 = load double, ptr %5, align 8, !dbg !2532
  %26 = fptosi double %25 to i32, !dbg !2535
  %27 = icmp eq i32 %26, 0, !dbg !2536
  br i1 %27, label %28, label %30, !dbg !2537

28:                                               ; preds = %24
  %29 = load double, ptr %5, align 8, !dbg !2538
  store double %29, ptr %4, align 8, !dbg !2539
  br label %71, !dbg !2539

30:                                               ; preds = %24
  br label %31, !dbg !2540

31:                                               ; preds = %30, %19
  %32 = load double, ptr %5, align 8, !dbg !2541
  %33 = load double, ptr %5, align 8, !dbg !2542
  %34 = fmul double %32, %33, !dbg !2543
  store double %34, ptr %8, align 8, !dbg !2544
  %35 = load double, ptr %8, align 8, !dbg !2545
  %36 = load double, ptr %5, align 8, !dbg !2546
  %37 = fmul double %35, %36, !dbg !2547
  store double %37, ptr %10, align 8, !dbg !2548
  %38 = load double, ptr %8, align 8, !dbg !2549
  %39 = load double, ptr %8, align 8, !dbg !2550
  %40 = load double, ptr %8, align 8, !dbg !2551
  %41 = load double, ptr %8, align 8, !dbg !2552
  %42 = call double @llvm.fmuladd.f64(double %41, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2553
  %43 = call double @llvm.fmuladd.f64(double %40, double %42, double 0x3EC71DE357B1FE7D), !dbg !2554
  %44 = call double @llvm.fmuladd.f64(double %39, double %43, double 0xBF2A01A019C161D5), !dbg !2555
  %45 = call double @llvm.fmuladd.f64(double %38, double %44, double 0x3F8111111110F8A6), !dbg !2556
  store double %45, ptr %9, align 8, !dbg !2557
  %46 = load i32, ptr %7, align 4, !dbg !2558
  %47 = icmp eq i32 %46, 0, !dbg !2560
  br i1 %47, label %48, label %55, !dbg !2561

48:                                               ; preds = %31
  %49 = load double, ptr %5, align 8, !dbg !2562
  %50 = load double, ptr %10, align 8, !dbg !2564
  %51 = load double, ptr %8, align 8, !dbg !2565
  %52 = load double, ptr %9, align 8, !dbg !2566
  %53 = call double @llvm.fmuladd.f64(double %51, double %52, double 0xBFC5555555555549), !dbg !2567
  %54 = call double @llvm.fmuladd.f64(double %50, double %53, double %49), !dbg !2568
  store double %54, ptr %4, align 8, !dbg !2569
  br label %71, !dbg !2569

55:                                               ; preds = %31
  %56 = load double, ptr %5, align 8, !dbg !2570
  %57 = load double, ptr %8, align 8, !dbg !2572
  %58 = load double, ptr %6, align 8, !dbg !2573
  %59 = load double, ptr %10, align 8, !dbg !2574
  %60 = load double, ptr %9, align 8, !dbg !2575
  %61 = fmul double %59, %60, !dbg !2576
  %62 = fneg double %61, !dbg !2577
  %63 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %58, double %62), !dbg !2577
  %64 = load double, ptr %6, align 8, !dbg !2578
  %65 = fneg double %64, !dbg !2579
  %66 = call double @llvm.fmuladd.f64(double %57, double %63, double %65), !dbg !2579
  %67 = load double, ptr %10, align 8, !dbg !2580
  %68 = fneg double %67, !dbg !2581
  %69 = call double @llvm.fmuladd.f64(double %68, double 0xBFC5555555555549, double %66), !dbg !2581
  %70 = fsub double %56, %69, !dbg !2582
  store double %70, ptr %4, align 8, !dbg !2583
  br label %71, !dbg !2583

71:                                               ; preds = %55, %48, %28
  %72 = load double, ptr %4, align 8, !dbg !2584
  ret double %72, !dbg !2584
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_exp(double noundef %0) #0 !dbg !125 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i64, align 8
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !2585, metadata !DIExpression()), !dbg !2586
  call void @llvm.dbg.declare(metadata ptr %4, metadata !2587, metadata !DIExpression()), !dbg !2588
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2589, metadata !DIExpression()), !dbg !2590
  store double 0.000000e+00, ptr %5, align 8, !dbg !2590
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2591, metadata !DIExpression()), !dbg !2592
  store double 0.000000e+00, ptr %6, align 8, !dbg !2592
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2593, metadata !DIExpression()), !dbg !2594
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2595, metadata !DIExpression()), !dbg !2596
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2597, metadata !DIExpression()), !dbg !2598
  call void @llvm.dbg.declare(metadata ptr %10, metadata !2599, metadata !DIExpression()), !dbg !2600
  store i32 0, ptr %10, align 4, !dbg !2600
  call void @llvm.dbg.declare(metadata ptr %11, metadata !2601, metadata !DIExpression()), !dbg !2602
  call void @llvm.dbg.declare(metadata ptr %12, metadata !2603, metadata !DIExpression()), !dbg !2604
  br label %18, !dbg !2605

18:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %13, metadata !2606, metadata !DIExpression()), !dbg !2608
  %19 = load double, ptr %3, align 8, !dbg !2608
  %20 = call i64 @bits_of(double noundef %19), !dbg !2608
  store i64 %20, ptr %13, align 8, !dbg !2608
  %21 = load i64, ptr %13, align 8, !dbg !2608
  %22 = lshr i64 %21, 32, !dbg !2608
  %23 = trunc i64 %22 to i32, !dbg !2608
  store i32 %23, ptr %12, align 4, !dbg !2608
  br label %24, !dbg !2608

24:                                               ; preds = %18
  %25 = load i32, ptr %12, align 4, !dbg !2609
  %26 = lshr i32 %25, 31, !dbg !2610
  %27 = and i32 %26, 1, !dbg !2611
  store i32 %27, ptr %11, align 4, !dbg !2612
  %28 = load i32, ptr %12, align 4, !dbg !2613
  %29 = and i32 %28, 2147483647, !dbg !2613
  store i32 %29, ptr %12, align 4, !dbg !2613
  %30 = load i32, ptr %12, align 4, !dbg !2614
  %31 = icmp uge i32 %30, 1082535490, !dbg !2616
  br i1 %31, label %32, label %75, !dbg !2617

32:                                               ; preds = %24
  %33 = load i32, ptr %12, align 4, !dbg !2618
  %34 = icmp uge i32 %33, 2146435072, !dbg !2621
  br i1 %34, label %35, label %60, !dbg !2622

35:                                               ; preds = %32
  call void @llvm.dbg.declare(metadata ptr %14, metadata !2623, metadata !DIExpression()), !dbg !2625
  br label %36, !dbg !2626

36:                                               ; preds = %35
  call void @llvm.dbg.declare(metadata ptr %15, metadata !2627, metadata !DIExpression()), !dbg !2629
  %37 = load double, ptr %3, align 8, !dbg !2629
  %38 = call i64 @bits_of(double noundef %37), !dbg !2629
  store i64 %38, ptr %15, align 8, !dbg !2629
  %39 = load i64, ptr %15, align 8, !dbg !2629
  %40 = and i64 %39, 4294967295, !dbg !2629
  %41 = trunc i64 %40 to i32, !dbg !2629
  store i32 %41, ptr %14, align 4, !dbg !2629
  br label %42, !dbg !2629

42:                                               ; preds = %36
  %43 = load i32, ptr %12, align 4, !dbg !2630
  %44 = and i32 %43, 1048575, !dbg !2632
  %45 = load i32, ptr %14, align 4, !dbg !2633
  %46 = or i32 %44, %45, !dbg !2634
  %47 = icmp ne i32 %46, 0, !dbg !2635
  br i1 %47, label %48, label %52, !dbg !2636

48:                                               ; preds = %42
  %49 = load double, ptr %3, align 8, !dbg !2637
  %50 = load double, ptr %3, align 8, !dbg !2638
  %51 = fadd double %49, %50, !dbg !2639
  store double %51, ptr %2, align 8, !dbg !2640
  br label %229, !dbg !2640

52:                                               ; preds = %42
  %53 = load i32, ptr %11, align 4, !dbg !2641
  %54 = icmp eq i32 %53, 0, !dbg !2642
  br i1 %54, label %55, label %57, !dbg !2643

55:                                               ; preds = %52
  %56 = load double, ptr %3, align 8, !dbg !2644
  br label %58, !dbg !2643

57:                                               ; preds = %52
  br label %58, !dbg !2643

58:                                               ; preds = %57, %55
  %59 = phi double [ %56, %55 ], [ 0.000000e+00, %57 ], !dbg !2643
  store double %59, ptr %2, align 8, !dbg !2645
  br label %229, !dbg !2645

60:                                               ; preds = %32
  %61 = load double, ptr %3, align 8, !dbg !2646
  %62 = fcmp ogt double %61, 0x40862E42FEFA39EF, !dbg !2648
  br i1 %62, label %63, label %67, !dbg !2649

63:                                               ; preds = %60
  %64 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2650
  %65 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2651
  %66 = fmul double %64, %65, !dbg !2652
  store double %66, ptr %2, align 8, !dbg !2653
  br label %229, !dbg !2653

67:                                               ; preds = %60
  %68 = load double, ptr %3, align 8, !dbg !2654
  %69 = fcmp olt double %68, 0xC0874910D52D3051, !dbg !2656
  br i1 %69, label %70, label %74, !dbg !2657

70:                                               ; preds = %67
  %71 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2658
  %72 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2659
  %73 = fmul double %71, %72, !dbg !2660
  store double %73, ptr %2, align 8, !dbg !2661
  br label %229, !dbg !2661

74:                                               ; preds = %67
  br label %75, !dbg !2662

75:                                               ; preds = %74, %24
  %76 = load i32, ptr %12, align 4, !dbg !2663
  %77 = icmp ugt i32 %76, 1071001154, !dbg !2665
  br i1 %77, label %78, label %122, !dbg !2666

78:                                               ; preds = %75
  %79 = load i32, ptr %12, align 4, !dbg !2667
  %80 = icmp ult i32 %79, 1072734898, !dbg !2670
  br i1 %80, label %81, label %100, !dbg !2671

81:                                               ; preds = %78
  %82 = load double, ptr %3, align 8, !dbg !2672
  %83 = fcmp oeq double %82, 1.000000e+00, !dbg !2675
  br i1 %83, label %84, label %85, !dbg !2676

84:                                               ; preds = %81
  store double 0x4005BF0A8B145769, ptr %2, align 8, !dbg !2677
  br label %229, !dbg !2677

85:                                               ; preds = %81
  %86 = load double, ptr %3, align 8, !dbg !2678
  %87 = load i32, ptr %11, align 4, !dbg !2679
  %88 = sext i32 %87 to i64, !dbg !2680
  %89 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2HI, i64 0, i64 %88, !dbg !2680
  %90 = load double, ptr %89, align 8, !dbg !2680
  %91 = fsub double %86, %90, !dbg !2681
  store double %91, ptr %5, align 8, !dbg !2682
  %92 = load i32, ptr %11, align 4, !dbg !2683
  %93 = sext i32 %92 to i64, !dbg !2684
  %94 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2LO, i64 0, i64 %93, !dbg !2684
  %95 = load double, ptr %94, align 8, !dbg !2684
  store double %95, ptr %6, align 8, !dbg !2685
  %96 = load i32, ptr %11, align 4, !dbg !2686
  %97 = sub nsw i32 1, %96, !dbg !2687
  %98 = load i32, ptr %11, align 4, !dbg !2688
  %99 = sub nsw i32 %97, %98, !dbg !2689
  store i32 %99, ptr %10, align 4, !dbg !2690
  br label %118, !dbg !2691

100:                                              ; preds = %78
  %101 = load double, ptr %3, align 8, !dbg !2692
  %102 = load i32, ptr %11, align 4, !dbg !2694
  %103 = sext i32 %102 to i64, !dbg !2695
  %104 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.halF, i64 0, i64 %103, !dbg !2695
  %105 = load double, ptr %104, align 8, !dbg !2695
  %106 = call double @llvm.fmuladd.f64(double 0x3FF71547652B82FE, double %101, double %105), !dbg !2696
  %107 = fptosi double %106 to i32, !dbg !2697
  store i32 %107, ptr %10, align 4, !dbg !2698
  %108 = load i32, ptr %10, align 4, !dbg !2699
  %109 = sitofp i32 %108 to double, !dbg !2699
  store double %109, ptr %8, align 8, !dbg !2700
  %110 = load double, ptr %3, align 8, !dbg !2701
  %111 = load double, ptr %8, align 8, !dbg !2702
  %112 = load double, ptr @pts_ieee754_exp.ln2HI, align 8, !dbg !2703
  %113 = fneg double %111, !dbg !2704
  %114 = call double @llvm.fmuladd.f64(double %113, double %112, double %110), !dbg !2704
  store double %114, ptr %5, align 8, !dbg !2705
  %115 = load double, ptr %8, align 8, !dbg !2706
  %116 = load double, ptr @pts_ieee754_exp.ln2LO, align 8, !dbg !2707
  %117 = fmul double %115, %116, !dbg !2708
  store double %117, ptr %6, align 8, !dbg !2709
  br label %118

118:                                              ; preds = %100, %85
  %119 = load double, ptr %5, align 8, !dbg !2710
  %120 = load double, ptr %6, align 8, !dbg !2711
  %121 = fsub double %119, %120, !dbg !2712
  store double %121, ptr %3, align 8, !dbg !2713
  br label %136, !dbg !2714

122:                                              ; preds = %75
  %123 = load i32, ptr %12, align 4, !dbg !2715
  %124 = icmp ult i32 %123, 1043333120, !dbg !2717
  br i1 %124, label %125, label %134, !dbg !2718

125:                                              ; preds = %122
  %126 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2719
  %127 = load double, ptr %3, align 8, !dbg !2722
  %128 = fadd double %126, %127, !dbg !2723
  %129 = fcmp ogt double %128, 1.000000e+00, !dbg !2724
  br i1 %129, label %130, label %133, !dbg !2725

130:                                              ; preds = %125
  %131 = load double, ptr %3, align 8, !dbg !2726
  %132 = fadd double 1.000000e+00, %131, !dbg !2727
  store double %132, ptr %2, align 8, !dbg !2728
  br label %229, !dbg !2728

133:                                              ; preds = %125
  br label %135, !dbg !2729

134:                                              ; preds = %122
  store i32 0, ptr %10, align 4, !dbg !2730
  br label %135

135:                                              ; preds = %134, %133
  br label %136

136:                                              ; preds = %135, %118
  %137 = load double, ptr %3, align 8, !dbg !2732
  %138 = load double, ptr %3, align 8, !dbg !2733
  %139 = fmul double %137, %138, !dbg !2734
  store double %139, ptr %8, align 8, !dbg !2735
  %140 = load i32, ptr %10, align 4, !dbg !2736
  %141 = icmp sge i32 %140, -1021, !dbg !2738
  br i1 %141, label %142, label %156, !dbg !2739

142:                                              ; preds = %136
  br label %143, !dbg !2740

143:                                              ; preds = %142
  call void @llvm.dbg.declare(metadata ptr %16, metadata !2742, metadata !DIExpression()), !dbg !2744
  store i64 0, ptr %16, align 8, !dbg !2744
  %144 = load i32, ptr %10, align 4, !dbg !2744
  %145 = shl i32 %144, 20, !dbg !2744
  %146 = add nsw i32 1072693248, %145, !dbg !2744
  %147 = sext i32 %146 to i64, !dbg !2744
  %148 = shl i64 %147, 32, !dbg !2744
  %149 = load i64, ptr %16, align 8, !dbg !2744
  %150 = or i64 %149, %148, !dbg !2744
  store i64 %150, ptr %16, align 8, !dbg !2744
  %151 = load i64, ptr %16, align 8, !dbg !2744
  %152 = or i64 %151, 0, !dbg !2744
  store i64 %152, ptr %16, align 8, !dbg !2744
  %153 = load i64, ptr %16, align 8, !dbg !2744
  %154 = call double @double_of(i64 noundef %153), !dbg !2744
  store double %154, ptr %9, align 8, !dbg !2744
  br label %155, !dbg !2744

155:                                              ; preds = %143
  br label %171, !dbg !2745

156:                                              ; preds = %136
  br label %157, !dbg !2746

157:                                              ; preds = %156
  call void @llvm.dbg.declare(metadata ptr %17, metadata !2748, metadata !DIExpression()), !dbg !2750
  store i64 0, ptr %17, align 8, !dbg !2750
  %158 = load i32, ptr %10, align 4, !dbg !2750
  %159 = add nsw i32 %158, 1000, !dbg !2750
  %160 = shl i32 %159, 20, !dbg !2750
  %161 = add i32 1072693248, %160, !dbg !2750
  %162 = zext i32 %161 to i64, !dbg !2750
  %163 = shl i64 %162, 32, !dbg !2750
  %164 = load i64, ptr %17, align 8, !dbg !2750
  %165 = or i64 %164, %163, !dbg !2750
  store i64 %165, ptr %17, align 8, !dbg !2750
  %166 = load i64, ptr %17, align 8, !dbg !2750
  %167 = or i64 %166, 0, !dbg !2750
  store i64 %167, ptr %17, align 8, !dbg !2750
  %168 = load i64, ptr %17, align 8, !dbg !2750
  %169 = call double @double_of(i64 noundef %168), !dbg !2750
  store double %169, ptr %9, align 8, !dbg !2750
  br label %170, !dbg !2750

170:                                              ; preds = %157
  br label %171

171:                                              ; preds = %170, %155
  %172 = load double, ptr %3, align 8, !dbg !2751
  %173 = load double, ptr %8, align 8, !dbg !2752
  %174 = load double, ptr %8, align 8, !dbg !2753
  %175 = load double, ptr %8, align 8, !dbg !2754
  %176 = load double, ptr %8, align 8, !dbg !2755
  %177 = load double, ptr %8, align 8, !dbg !2756
  %178 = call double @llvm.fmuladd.f64(double %177, double 0x3E66376972BEA4D0, double 0xBEBBBD41C5D26BF1), !dbg !2757
  %179 = call double @llvm.fmuladd.f64(double %176, double %178, double 0x3F11566AAF25DE2C), !dbg !2758
  %180 = call double @llvm.fmuladd.f64(double %175, double %179, double 0xBF66C16C16BEBD93), !dbg !2759
  %181 = call double @llvm.fmuladd.f64(double %174, double %180, double 0x3FC555555555553E), !dbg !2760
  %182 = fneg double %173, !dbg !2761
  %183 = call double @llvm.fmuladd.f64(double %182, double %181, double %172), !dbg !2761
  store double %183, ptr %7, align 8, !dbg !2762
  %184 = load i32, ptr %10, align 4, !dbg !2763
  %185 = icmp eq i32 %184, 0, !dbg !2765
  br i1 %185, label %186, label %196, !dbg !2766

186:                                              ; preds = %171
  %187 = load double, ptr %3, align 8, !dbg !2767
  %188 = load double, ptr %7, align 8, !dbg !2769
  %189 = fmul double %187, %188, !dbg !2770
  %190 = load double, ptr %7, align 8, !dbg !2771
  %191 = fsub double %190, 2.000000e+00, !dbg !2772
  %192 = fdiv double %189, %191, !dbg !2773
  %193 = load double, ptr %3, align 8, !dbg !2774
  %194 = fsub double %192, %193, !dbg !2775
  %195 = fsub double 1.000000e+00, %194, !dbg !2776
  store double %195, ptr %2, align 8, !dbg !2777
  br label %229, !dbg !2777

196:                                              ; preds = %171
  %197 = load double, ptr %6, align 8, !dbg !2778
  %198 = load double, ptr %3, align 8, !dbg !2780
  %199 = load double, ptr %7, align 8, !dbg !2781
  %200 = fmul double %198, %199, !dbg !2782
  %201 = load double, ptr %7, align 8, !dbg !2783
  %202 = fsub double 2.000000e+00, %201, !dbg !2784
  %203 = fdiv double %200, %202, !dbg !2785
  %204 = fsub double %197, %203, !dbg !2786
  %205 = load double, ptr %5, align 8, !dbg !2787
  %206 = fsub double %204, %205, !dbg !2788
  %207 = fsub double 1.000000e+00, %206, !dbg !2789
  store double %207, ptr %4, align 8, !dbg !2790
  br label %208

208:                                              ; preds = %196
  %209 = load i32, ptr %10, align 4, !dbg !2791
  %210 = icmp sge i32 %209, -1021, !dbg !2793
  br i1 %210, label %211, label %223, !dbg !2794

211:                                              ; preds = %208
  %212 = load i32, ptr %10, align 4, !dbg !2795
  %213 = icmp eq i32 %212, 1024, !dbg !2798
  br i1 %213, label %214, label %219, !dbg !2799

214:                                              ; preds = %211
  %215 = load double, ptr %4, align 8, !dbg !2800
  %216 = fmul double %215, 2.000000e+00, !dbg !2801
  %217 = load volatile double, ptr @pts_ieee754_exp.two1023, align 8, !dbg !2802
  %218 = fmul double %216, %217, !dbg !2803
  store double %218, ptr %2, align 8, !dbg !2804
  br label %229, !dbg !2804

219:                                              ; preds = %211
  %220 = load double, ptr %4, align 8, !dbg !2805
  %221 = load double, ptr %9, align 8, !dbg !2806
  %222 = fmul double %220, %221, !dbg !2807
  store double %222, ptr %2, align 8, !dbg !2808
  br label %229, !dbg !2808

223:                                              ; preds = %208
  %224 = load double, ptr %4, align 8, !dbg !2809
  %225 = load double, ptr %9, align 8, !dbg !2811
  %226 = fmul double %224, %225, !dbg !2812
  %227 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2813
  %228 = fmul double %226, %227, !dbg !2814
  store double %228, ptr %2, align 8, !dbg !2815
  br label %229, !dbg !2815

229:                                              ; preds = %223, %219, %214, %186, %130, %84, %70, %63, %58, %48
  %230 = load double, ptr %2, align 8, !dbg !2816
  ret double %230, !dbg !2816
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_atanh(double noundef %0) #0 !dbg !161 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  %9 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !2817, metadata !DIExpression()), !dbg !2818
  call void @llvm.dbg.declare(metadata ptr %4, metadata !2819, metadata !DIExpression()), !dbg !2820
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2821, metadata !DIExpression()), !dbg !2822
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2823, metadata !DIExpression()), !dbg !2824
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2825, metadata !DIExpression()), !dbg !2826
  br label %10, !dbg !2827

10:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2828, metadata !DIExpression()), !dbg !2830
  %11 = load double, ptr %3, align 8, !dbg !2830
  %12 = call i64 @bits_of(double noundef %11), !dbg !2830
  store i64 %12, ptr %8, align 8, !dbg !2830
  %13 = load i64, ptr %8, align 8, !dbg !2830
  %14 = lshr i64 %13, 32, !dbg !2830
  %15 = trunc i64 %14 to i32, !dbg !2830
  store i32 %15, ptr %5, align 4, !dbg !2830
  %16 = load i64, ptr %8, align 8, !dbg !2830
  %17 = and i64 %16, 4294967295, !dbg !2830
  %18 = trunc i64 %17 to i32, !dbg !2830
  store i32 %18, ptr %7, align 4, !dbg !2830
  br label %19, !dbg !2830

19:                                               ; preds = %10
  %20 = load i32, ptr %5, align 4, !dbg !2831
  %21 = and i32 %20, 2147483647, !dbg !2832
  store i32 %21, ptr %6, align 4, !dbg !2833
  %22 = load i32, ptr %6, align 4, !dbg !2834
  %23 = load i32, ptr %7, align 4, !dbg !2836
  %24 = load i32, ptr %7, align 4, !dbg !2837
  %25 = call i32 @negate_with_wraparound(i32 noundef %24), !dbg !2838
  %26 = or i32 %23, %25, !dbg !2839
  %27 = lshr i32 %26, 31, !dbg !2840
  %28 = or i32 %22, %27, !dbg !2841
  %29 = icmp ugt i32 %28, 1072693248, !dbg !2842
  br i1 %29, label %30, label %31, !dbg !2843

30:                                               ; preds = %19
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !2844
  br label %95, !dbg !2844

31:                                               ; preds = %19
  %32 = load i32, ptr %6, align 4, !dbg !2846
  %33 = icmp eq i32 %32, 1072693248, !dbg !2848
  br i1 %33, label %34, label %39, !dbg !2849

34:                                               ; preds = %31
  %35 = load double, ptr %3, align 8, !dbg !2850
  %36 = fcmp ogt double %35, 0.000000e+00, !dbg !2852
  %37 = zext i1 %36 to i64, !dbg !2850
  %38 = select i1 %36, double 0x7FF0000000000000, double 0xFFF0000000000000, !dbg !2850
  store double %38, ptr %2, align 8, !dbg !2853
  br label %95, !dbg !2853

39:                                               ; preds = %31
  %40 = load i32, ptr %6, align 4, !dbg !2854
  %41 = icmp slt i32 %40, 1043333120, !dbg !2856
  br i1 %41, label %42, label %48, !dbg !2857

42:                                               ; preds = %39
  %43 = load double, ptr %3, align 8, !dbg !2858
  %44 = fadd double 1.000000e+300, %43, !dbg !2859
  %45 = fcmp ogt double %44, 0.000000e+00, !dbg !2860
  br i1 %45, label %46, label %48, !dbg !2861

46:                                               ; preds = %42
  %47 = load double, ptr %3, align 8, !dbg !2862
  store double %47, ptr %2, align 8, !dbg !2863
  br label %95, !dbg !2863

48:                                               ; preds = %42, %39
  br label %49, !dbg !2864

49:                                               ; preds = %48
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2865, metadata !DIExpression()), !dbg !2867
  %50 = load double, ptr %3, align 8, !dbg !2867
  %51 = call i64 @bits_of(double noundef %50), !dbg !2867
  store i64 %51, ptr %9, align 8, !dbg !2867
  %52 = load i64, ptr %9, align 8, !dbg !2867
  %53 = and i64 %52, 4294967295, !dbg !2867
  store i64 %53, ptr %9, align 8, !dbg !2867
  %54 = load i32, ptr %6, align 4, !dbg !2867
  %55 = sext i32 %54 to i64, !dbg !2867
  %56 = shl i64 %55, 32, !dbg !2867
  %57 = load i64, ptr %9, align 8, !dbg !2867
  %58 = or i64 %57, %56, !dbg !2867
  store i64 %58, ptr %9, align 8, !dbg !2867
  %59 = load i64, ptr %9, align 8, !dbg !2867
  %60 = call double @double_of(i64 noundef %59), !dbg !2867
  store double %60, ptr %3, align 8, !dbg !2867
  br label %61, !dbg !2867

61:                                               ; preds = %49
  %62 = load i32, ptr %6, align 4, !dbg !2868
  %63 = icmp slt i32 %62, 1071644672, !dbg !2870
  br i1 %63, label %64, label %78, !dbg !2871

64:                                               ; preds = %61
  %65 = load double, ptr %3, align 8, !dbg !2872
  %66 = load double, ptr %3, align 8, !dbg !2874
  %67 = fadd double %65, %66, !dbg !2875
  store double %67, ptr %4, align 8, !dbg !2876
  %68 = load double, ptr %4, align 8, !dbg !2877
  %69 = load double, ptr %4, align 8, !dbg !2878
  %70 = load double, ptr %3, align 8, !dbg !2879
  %71 = fmul double %69, %70, !dbg !2880
  %72 = load double, ptr %3, align 8, !dbg !2881
  %73 = fsub double 1.000000e+00, %72, !dbg !2882
  %74 = fdiv double %71, %73, !dbg !2883
  %75 = fadd double %68, %74, !dbg !2884
  %76 = call double @pts_ieee754_log1p(double noundef %75), !dbg !2885
  %77 = fmul double 5.000000e-01, %76, !dbg !2886
  store double %77, ptr %4, align 8, !dbg !2887
  br label %87, !dbg !2888

78:                                               ; preds = %61
  %79 = load double, ptr %3, align 8, !dbg !2889
  %80 = load double, ptr %3, align 8, !dbg !2891
  %81 = fadd double %79, %80, !dbg !2892
  %82 = load double, ptr %3, align 8, !dbg !2893
  %83 = fsub double 1.000000e+00, %82, !dbg !2894
  %84 = fdiv double %81, %83, !dbg !2895
  %85 = call double @pts_ieee754_log1p(double noundef %84), !dbg !2896
  %86 = fmul double 5.000000e-01, %85, !dbg !2897
  store double %86, ptr %4, align 8, !dbg !2898
  br label %87

87:                                               ; preds = %78, %64
  %88 = load i32, ptr %5, align 4, !dbg !2899
  %89 = icmp sge i32 %88, 0, !dbg !2901
  br i1 %89, label %90, label %92, !dbg !2902

90:                                               ; preds = %87
  %91 = load double, ptr %4, align 8, !dbg !2903
  store double %91, ptr %2, align 8, !dbg !2904
  br label %95, !dbg !2904

92:                                               ; preds = %87
  %93 = load double, ptr %4, align 8, !dbg !2905
  %94 = fneg double %93, !dbg !2906
  store double %94, ptr %2, align 8, !dbg !2907
  br label %95, !dbg !2907

95:                                               ; preds = %92, %90, %46, %34, %30
  %96 = load double, ptr %2, align 8, !dbg !2908
  ret double %96, !dbg !2908
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_log2(double noundef %0) #0 !dbg !214 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i64, align 8
  %18 = alloca i64, align 8
  %19 = alloca i64, align 8
  %20 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !2909, metadata !DIExpression()), !dbg !2910
  call void @llvm.dbg.declare(metadata ptr %4, metadata !2911, metadata !DIExpression()), !dbg !2912
  call void @llvm.dbg.declare(metadata ptr %5, metadata !2913, metadata !DIExpression()), !dbg !2914
  call void @llvm.dbg.declare(metadata ptr %6, metadata !2915, metadata !DIExpression()), !dbg !2916
  call void @llvm.dbg.declare(metadata ptr %7, metadata !2917, metadata !DIExpression()), !dbg !2918
  call void @llvm.dbg.declare(metadata ptr %8, metadata !2919, metadata !DIExpression()), !dbg !2920
  call void @llvm.dbg.declare(metadata ptr %9, metadata !2921, metadata !DIExpression()), !dbg !2922
  call void @llvm.dbg.declare(metadata ptr %10, metadata !2923, metadata !DIExpression()), !dbg !2924
  call void @llvm.dbg.declare(metadata ptr %11, metadata !2925, metadata !DIExpression()), !dbg !2926
  call void @llvm.dbg.declare(metadata ptr %12, metadata !2927, metadata !DIExpression()), !dbg !2928
  call void @llvm.dbg.declare(metadata ptr %13, metadata !2929, metadata !DIExpression()), !dbg !2930
  call void @llvm.dbg.declare(metadata ptr %14, metadata !2931, metadata !DIExpression()), !dbg !2932
  call void @llvm.dbg.declare(metadata ptr %15, metadata !2933, metadata !DIExpression()), !dbg !2934
  call void @llvm.dbg.declare(metadata ptr %16, metadata !2935, metadata !DIExpression()), !dbg !2936
  br label %21, !dbg !2937

21:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %17, metadata !2938, metadata !DIExpression()), !dbg !2940
  %22 = load double, ptr %3, align 8, !dbg !2940
  %23 = call i64 @bits_of(double noundef %22), !dbg !2940
  store i64 %23, ptr %17, align 8, !dbg !2940
  %24 = load i64, ptr %17, align 8, !dbg !2940
  %25 = lshr i64 %24, 32, !dbg !2940
  %26 = trunc i64 %25 to i32, !dbg !2940
  store i32 %26, ptr %15, align 4, !dbg !2940
  %27 = load i64, ptr %17, align 8, !dbg !2940
  %28 = and i64 %27, 4294967295, !dbg !2940
  %29 = trunc i64 %28 to i32, !dbg !2940
  store i32 %29, ptr %16, align 4, !dbg !2940
  br label %30, !dbg !2940

30:                                               ; preds = %21
  store i32 0, ptr %14, align 4, !dbg !2941
  %31 = load i32, ptr %15, align 4, !dbg !2942
  %32 = icmp slt i32 %31, 1048576, !dbg !2944
  br i1 %32, label %33, label %56, !dbg !2945

33:                                               ; preds = %30
  %34 = load i32, ptr %15, align 4, !dbg !2946
  %35 = and i32 %34, 2147483647, !dbg !2949
  %36 = load i32, ptr %16, align 4, !dbg !2950
  %37 = or i32 %35, %36, !dbg !2951
  %38 = icmp eq i32 %37, 0, !dbg !2952
  br i1 %38, label %39, label %40, !dbg !2953

39:                                               ; preds = %33
  store double 0xFFF0000000000000, ptr %2, align 8, !dbg !2954
  br label %153, !dbg !2954

40:                                               ; preds = %33
  %41 = load i32, ptr %15, align 4, !dbg !2956
  %42 = icmp slt i32 %41, 0, !dbg !2958
  br i1 %42, label %43, label %44, !dbg !2959

43:                                               ; preds = %40
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !2960
  br label %153, !dbg !2960

44:                                               ; preds = %40
  %45 = load i32, ptr %14, align 4, !dbg !2962
  %46 = sub nsw i32 %45, 54, !dbg !2962
  store i32 %46, ptr %14, align 4, !dbg !2962
  %47 = load double, ptr %3, align 8, !dbg !2963
  %48 = fmul double %47, 0x4350000000000000, !dbg !2963
  store double %48, ptr %3, align 8, !dbg !2963
  br label %49, !dbg !2964

49:                                               ; preds = %44
  call void @llvm.dbg.declare(metadata ptr %18, metadata !2965, metadata !DIExpression()), !dbg !2967
  %50 = load double, ptr %3, align 8, !dbg !2967
  %51 = call i64 @bits_of(double noundef %50), !dbg !2967
  store i64 %51, ptr %18, align 8, !dbg !2967
  %52 = load i64, ptr %18, align 8, !dbg !2967
  %53 = lshr i64 %52, 32, !dbg !2967
  %54 = trunc i64 %53 to i32, !dbg !2967
  store i32 %54, ptr %15, align 4, !dbg !2967
  br label %55, !dbg !2967

55:                                               ; preds = %49
  br label %56, !dbg !2968

56:                                               ; preds = %55, %30
  %57 = load i32, ptr %15, align 4, !dbg !2969
  %58 = icmp sge i32 %57, 2146435072, !dbg !2971
  br i1 %58, label %59, label %63, !dbg !2972

59:                                               ; preds = %56
  %60 = load double, ptr %3, align 8, !dbg !2973
  %61 = load double, ptr %3, align 8, !dbg !2974
  %62 = fadd double %60, %61, !dbg !2975
  store double %62, ptr %2, align 8, !dbg !2976
  br label %153, !dbg !2976

63:                                               ; preds = %56
  %64 = load i32, ptr %15, align 4, !dbg !2977
  %65 = icmp eq i32 %64, 1072693248, !dbg !2979
  br i1 %65, label %66, label %70, !dbg !2980

66:                                               ; preds = %63
  %67 = load i32, ptr %16, align 4, !dbg !2981
  %68 = icmp eq i32 %67, 0, !dbg !2982
  br i1 %68, label %69, label %70, !dbg !2983

69:                                               ; preds = %66
  store double 0.000000e+00, ptr %2, align 8, !dbg !2984
  br label %153, !dbg !2984

70:                                               ; preds = %66, %63
  %71 = load i32, ptr %15, align 4, !dbg !2985
  %72 = ashr i32 %71, 20, !dbg !2986
  %73 = sub nsw i32 %72, 1023, !dbg !2987
  %74 = load i32, ptr %14, align 4, !dbg !2988
  %75 = add nsw i32 %74, %73, !dbg !2988
  store i32 %75, ptr %14, align 4, !dbg !2988
  %76 = load i32, ptr %15, align 4, !dbg !2989
  %77 = and i32 %76, 1048575, !dbg !2989
  store i32 %77, ptr %15, align 4, !dbg !2989
  %78 = load i32, ptr %15, align 4, !dbg !2990
  %79 = add nsw i32 %78, 614244, !dbg !2991
  %80 = and i32 %79, 1048576, !dbg !2992
  store i32 %80, ptr %13, align 4, !dbg !2993
  br label %81, !dbg !2994

81:                                               ; preds = %70
  call void @llvm.dbg.declare(metadata ptr %19, metadata !2995, metadata !DIExpression()), !dbg !2997
  %82 = load double, ptr %3, align 8, !dbg !2997
  %83 = call i64 @bits_of(double noundef %82), !dbg !2997
  store i64 %83, ptr %19, align 8, !dbg !2997
  %84 = load i64, ptr %19, align 8, !dbg !2997
  %85 = and i64 %84, 4294967295, !dbg !2997
  store i64 %85, ptr %19, align 8, !dbg !2997
  %86 = load i32, ptr %15, align 4, !dbg !2997
  %87 = load i32, ptr %13, align 4, !dbg !2997
  %88 = xor i32 %87, 1072693248, !dbg !2997
  %89 = or i32 %86, %88, !dbg !2997
  %90 = sext i32 %89 to i64, !dbg !2997
  %91 = shl i64 %90, 32, !dbg !2997
  %92 = load i64, ptr %19, align 8, !dbg !2997
  %93 = or i64 %92, %91, !dbg !2997
  store i64 %93, ptr %19, align 8, !dbg !2997
  %94 = load i64, ptr %19, align 8, !dbg !2997
  %95 = call double @double_of(i64 noundef %94), !dbg !2997
  store double %95, ptr %3, align 8, !dbg !2997
  br label %96, !dbg !2997

96:                                               ; preds = %81
  %97 = load i32, ptr %13, align 4, !dbg !2998
  %98 = ashr i32 %97, 20, !dbg !2999
  %99 = load i32, ptr %14, align 4, !dbg !3000
  %100 = add nsw i32 %99, %98, !dbg !3000
  store i32 %100, ptr %14, align 4, !dbg !3000
  %101 = load i32, ptr %14, align 4, !dbg !3001
  %102 = sitofp i32 %101 to double, !dbg !3002
  store double %102, ptr %12, align 8, !dbg !3003
  %103 = load double, ptr %3, align 8, !dbg !3004
  %104 = fsub double %103, 1.000000e+00, !dbg !3005
  store double %104, ptr %4, align 8, !dbg !3006
  %105 = load double, ptr %4, align 8, !dbg !3007
  %106 = fmul double 5.000000e-01, %105, !dbg !3008
  %107 = load double, ptr %4, align 8, !dbg !3009
  %108 = fmul double %106, %107, !dbg !3010
  store double %108, ptr %5, align 8, !dbg !3011
  %109 = load double, ptr %4, align 8, !dbg !3012
  %110 = call double @k_log1p(double noundef %109), !dbg !3013
  store double %110, ptr %8, align 8, !dbg !3014
  %111 = load double, ptr %4, align 8, !dbg !3015
  %112 = load double, ptr %5, align 8, !dbg !3016
  %113 = fsub double %111, %112, !dbg !3017
  store double %113, ptr %6, align 8, !dbg !3018
  br label %114, !dbg !3019

114:                                              ; preds = %96
  call void @llvm.dbg.declare(metadata ptr %20, metadata !3020, metadata !DIExpression()), !dbg !3022
  %115 = load double, ptr %6, align 8, !dbg !3022
  %116 = call i64 @bits_of(double noundef %115), !dbg !3022
  store i64 %116, ptr %20, align 8, !dbg !3022
  %117 = load i64, ptr %20, align 8, !dbg !3022
  %118 = and i64 %117, -4294967296, !dbg !3022
  store i64 %118, ptr %20, align 8, !dbg !3022
  %119 = load i64, ptr %20, align 8, !dbg !3022
  %120 = or i64 %119, 0, !dbg !3022
  store i64 %120, ptr %20, align 8, !dbg !3022
  %121 = load i64, ptr %20, align 8, !dbg !3022
  %122 = call double @double_of(i64 noundef %121), !dbg !3022
  store double %122, ptr %6, align 8, !dbg !3022
  br label %123, !dbg !3022

123:                                              ; preds = %114
  %124 = load double, ptr %4, align 8, !dbg !3023
  %125 = load double, ptr %6, align 8, !dbg !3024
  %126 = fsub double %124, %125, !dbg !3025
  %127 = load double, ptr %5, align 8, !dbg !3026
  %128 = fsub double %126, %127, !dbg !3027
  %129 = load double, ptr %8, align 8, !dbg !3028
  %130 = fadd double %128, %129, !dbg !3029
  store double %130, ptr %7, align 8, !dbg !3030
  %131 = load double, ptr %6, align 8, !dbg !3031
  %132 = fmul double %131, 0x3FF7154765200000, !dbg !3032
  store double %132, ptr %9, align 8, !dbg !3033
  %133 = load double, ptr %7, align 8, !dbg !3034
  %134 = load double, ptr %6, align 8, !dbg !3035
  %135 = fadd double %133, %134, !dbg !3036
  %136 = load double, ptr %7, align 8, !dbg !3037
  %137 = fmul double %136, 0x3FF7154765200000, !dbg !3038
  %138 = call double @llvm.fmuladd.f64(double %135, double 0x3DE705FC2EEFA200, double %137), !dbg !3039
  store double %138, ptr %10, align 8, !dbg !3040
  %139 = load double, ptr %12, align 8, !dbg !3041
  %140 = load double, ptr %9, align 8, !dbg !3042
  %141 = fadd double %139, %140, !dbg !3043
  store double %141, ptr %11, align 8, !dbg !3044
  %142 = load double, ptr %12, align 8, !dbg !3045
  %143 = load double, ptr %11, align 8, !dbg !3046
  %144 = fsub double %142, %143, !dbg !3047
  %145 = load double, ptr %9, align 8, !dbg !3048
  %146 = fadd double %144, %145, !dbg !3049
  %147 = load double, ptr %10, align 8, !dbg !3050
  %148 = fadd double %147, %146, !dbg !3050
  store double %148, ptr %10, align 8, !dbg !3050
  %149 = load double, ptr %11, align 8, !dbg !3051
  store double %149, ptr %9, align 8, !dbg !3052
  %150 = load double, ptr %10, align 8, !dbg !3053
  %151 = load double, ptr %9, align 8, !dbg !3054
  %152 = fadd double %150, %151, !dbg !3055
  store double %152, ptr %2, align 8, !dbg !3056
  br label %153, !dbg !3056

153:                                              ; preds = %123, %69, %59, %43, %39
  %154 = load double, ptr %2, align 8, !dbg !3057
  ret double %154, !dbg !3057
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal double @k_log1p(double noundef %0) #0 !dbg !3058 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  store double %0, ptr %2, align 8
  call void @llvm.dbg.declare(metadata ptr %2, metadata !3059, metadata !DIExpression()), !dbg !3060
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3061, metadata !DIExpression()), !dbg !3062
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3063, metadata !DIExpression()), !dbg !3064
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3065, metadata !DIExpression()), !dbg !3066
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3067, metadata !DIExpression()), !dbg !3068
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3069, metadata !DIExpression()), !dbg !3070
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3071, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.declare(metadata ptr %9, metadata !3073, metadata !DIExpression()), !dbg !3074
  %10 = load double, ptr %2, align 8, !dbg !3075
  %11 = load double, ptr %2, align 8, !dbg !3076
  %12 = fadd double 2.000000e+00, %11, !dbg !3077
  %13 = fdiv double %10, %12, !dbg !3078
  store double %13, ptr %4, align 8, !dbg !3079
  %14 = load double, ptr %4, align 8, !dbg !3080
  %15 = load double, ptr %4, align 8, !dbg !3081
  %16 = fmul double %14, %15, !dbg !3082
  store double %16, ptr %5, align 8, !dbg !3083
  %17 = load double, ptr %5, align 8, !dbg !3084
  %18 = load double, ptr %5, align 8, !dbg !3085
  %19 = fmul double %17, %18, !dbg !3086
  store double %19, ptr %7, align 8, !dbg !3087
  %20 = load double, ptr %7, align 8, !dbg !3088
  %21 = load double, ptr %7, align 8, !dbg !3089
  %22 = load double, ptr %7, align 8, !dbg !3090
  %23 = call double @llvm.fmuladd.f64(double %22, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !3091
  %24 = call double @llvm.fmuladd.f64(double %21, double %23, double 0x3FD999999997FA04), !dbg !3092
  %25 = fmul double %20, %24, !dbg !3093
  store double %25, ptr %8, align 8, !dbg !3094
  %26 = load double, ptr %5, align 8, !dbg !3095
  %27 = load double, ptr %7, align 8, !dbg !3096
  %28 = load double, ptr %7, align 8, !dbg !3097
  %29 = load double, ptr %7, align 8, !dbg !3098
  %30 = call double @llvm.fmuladd.f64(double %29, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !3099
  %31 = call double @llvm.fmuladd.f64(double %28, double %30, double 0x3FD2492494229359), !dbg !3100
  %32 = call double @llvm.fmuladd.f64(double %27, double %31, double 0x3FE5555555555593), !dbg !3101
  %33 = fmul double %26, %32, !dbg !3102
  store double %33, ptr %9, align 8, !dbg !3103
  %34 = load double, ptr %9, align 8, !dbg !3104
  %35 = load double, ptr %8, align 8, !dbg !3105
  %36 = fadd double %34, %35, !dbg !3106
  store double %36, ptr %6, align 8, !dbg !3107
  %37 = load double, ptr %2, align 8, !dbg !3108
  %38 = fmul double 5.000000e-01, %37, !dbg !3109
  %39 = load double, ptr %2, align 8, !dbg !3110
  %40 = fmul double %38, %39, !dbg !3111
  store double %40, ptr %3, align 8, !dbg !3112
  %41 = load double, ptr %4, align 8, !dbg !3113
  %42 = load double, ptr %3, align 8, !dbg !3114
  %43 = load double, ptr %6, align 8, !dbg !3115
  %44 = fadd double %42, %43, !dbg !3116
  %45 = fmul double %41, %44, !dbg !3117
  ret double %45, !dbg !3118
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_log10(double noundef %0) #0 !dbg !221 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca i32, align 4
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i64, align 8
  %10 = alloca i64, align 8
  %11 = alloca i64, align 8
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  %14 = alloca double, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3119, metadata !DIExpression()), !dbg !3120
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3121, metadata !DIExpression()), !dbg !3122
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3123, metadata !DIExpression()), !dbg !3124
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3125, metadata !DIExpression()), !dbg !3126
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3127, metadata !DIExpression()), !dbg !3128
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3129, metadata !DIExpression()), !dbg !3130
  br label %15, !dbg !3131

15:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %9, metadata !3132, metadata !DIExpression()), !dbg !3134
  %16 = load double, ptr %3, align 8, !dbg !3134
  %17 = call i64 @bits_of(double noundef %16), !dbg !3134
  store i64 %17, ptr %9, align 8, !dbg !3134
  %18 = load i64, ptr %9, align 8, !dbg !3134
  %19 = lshr i64 %18, 32, !dbg !3134
  %20 = trunc i64 %19 to i32, !dbg !3134
  store i32 %20, ptr %7, align 4, !dbg !3134
  %21 = load i64, ptr %9, align 8, !dbg !3134
  %22 = and i64 %21, 4294967295, !dbg !3134
  %23 = trunc i64 %22 to i32, !dbg !3134
  store i32 %23, ptr %8, align 4, !dbg !3134
  br label %24, !dbg !3134

24:                                               ; preds = %15
  store i32 0, ptr %6, align 4, !dbg !3135
  %25 = load i32, ptr %7, align 4, !dbg !3136
  %26 = icmp slt i32 %25, 1048576, !dbg !3138
  br i1 %26, label %27, label %57, !dbg !3139

27:                                               ; preds = %24
  %28 = load i32, ptr %7, align 4, !dbg !3140
  %29 = and i32 %28, 2147483647, !dbg !3143
  %30 = load i32, ptr %8, align 4, !dbg !3144
  %31 = or i32 %29, %30, !dbg !3145
  %32 = icmp eq i32 %31, 0, !dbg !3146
  br i1 %32, label %33, label %34, !dbg !3147

33:                                               ; preds = %27
  store double 0xFFF0000000000000, ptr %2, align 8, !dbg !3148
  br label %123, !dbg !3148

34:                                               ; preds = %27
  %35 = load i32, ptr %7, align 4, !dbg !3150
  %36 = icmp slt i32 %35, 0, !dbg !3152
  br i1 %36, label %37, label %38, !dbg !3153

37:                                               ; preds = %34
  store double 0x7FF8000000000000, ptr %2, align 8, !dbg !3154
  br label %123, !dbg !3154

38:                                               ; preds = %34
  %39 = load i32, ptr %6, align 4, !dbg !3156
  %40 = sub nsw i32 %39, 54, !dbg !3156
  store i32 %40, ptr %6, align 4, !dbg !3156
  %41 = load double, ptr %3, align 8, !dbg !3157
  %42 = fmul double %41, 0x4350000000000000, !dbg !3157
  store double %42, ptr %3, align 8, !dbg !3157
  br label %43, !dbg !3158

43:                                               ; preds = %38
  call void @llvm.dbg.declare(metadata ptr %10, metadata !3159, metadata !DIExpression()), !dbg !3161
  %44 = load double, ptr %3, align 8, !dbg !3161
  %45 = call i64 @bits_of(double noundef %44), !dbg !3161
  store i64 %45, ptr %10, align 8, !dbg !3161
  %46 = load i64, ptr %10, align 8, !dbg !3161
  %47 = lshr i64 %46, 32, !dbg !3161
  %48 = trunc i64 %47 to i32, !dbg !3161
  store i32 %48, ptr %7, align 4, !dbg !3161
  br label %49, !dbg !3161

49:                                               ; preds = %43
  br label %50, !dbg !3162

50:                                               ; preds = %49
  call void @llvm.dbg.declare(metadata ptr %11, metadata !3163, metadata !DIExpression()), !dbg !3165
  %51 = load double, ptr %3, align 8, !dbg !3165
  %52 = call i64 @bits_of(double noundef %51), !dbg !3165
  store i64 %52, ptr %11, align 8, !dbg !3165
  %53 = load i64, ptr %11, align 8, !dbg !3165
  %54 = and i64 %53, 4294967295, !dbg !3165
  %55 = trunc i64 %54 to i32, !dbg !3165
  store i32 %55, ptr %8, align 4, !dbg !3165
  br label %56, !dbg !3165

56:                                               ; preds = %50
  br label %57, !dbg !3166

57:                                               ; preds = %56, %24
  %58 = load i32, ptr %7, align 4, !dbg !3167
  %59 = icmp sge i32 %58, 2146435072, !dbg !3169
  br i1 %59, label %60, label %64, !dbg !3170

60:                                               ; preds = %57
  %61 = load double, ptr %3, align 8, !dbg !3171
  %62 = load double, ptr %3, align 8, !dbg !3172
  %63 = fadd double %61, %62, !dbg !3173
  store double %63, ptr %2, align 8, !dbg !3174
  br label %123, !dbg !3174

64:                                               ; preds = %57
  %65 = load i32, ptr %7, align 4, !dbg !3175
  %66 = icmp eq i32 %65, 1072693248, !dbg !3177
  br i1 %66, label %67, label %71, !dbg !3178

67:                                               ; preds = %64
  %68 = load i32, ptr %8, align 4, !dbg !3179
  %69 = icmp eq i32 %68, 0, !dbg !3180
  br i1 %69, label %70, label %71, !dbg !3181

70:                                               ; preds = %67
  store double 0.000000e+00, ptr %2, align 8, !dbg !3182
  br label %123, !dbg !3182

71:                                               ; preds = %67, %64
  %72 = load i32, ptr %7, align 4, !dbg !3183
  %73 = ashr i32 %72, 20, !dbg !3184
  %74 = sub nsw i32 %73, 1023, !dbg !3185
  %75 = load i32, ptr %6, align 4, !dbg !3186
  %76 = add nsw i32 %75, %74, !dbg !3186
  store i32 %76, ptr %6, align 4, !dbg !3186
  %77 = load i32, ptr %6, align 4, !dbg !3187
  %78 = and i32 %77, -2147483648, !dbg !3188
  %79 = lshr i32 %78, 31, !dbg !3189
  store i32 %79, ptr %5, align 4, !dbg !3190
  %80 = load i32, ptr %7, align 4, !dbg !3191
  %81 = and i32 %80, 1048575, !dbg !3192
  %82 = load i32, ptr %5, align 4, !dbg !3193
  %83 = sub nsw i32 1023, %82, !dbg !3194
  %84 = shl i32 %83, 20, !dbg !3195
  %85 = or i32 %81, %84, !dbg !3196
  store i32 %85, ptr %7, align 4, !dbg !3197
  %86 = load i32, ptr %6, align 4, !dbg !3198
  %87 = load i32, ptr %5, align 4, !dbg !3199
  %88 = add nsw i32 %86, %87, !dbg !3200
  %89 = sitofp i32 %88 to double, !dbg !3198
  store double %89, ptr %4, align 8, !dbg !3201
  br label %90, !dbg !3202

90:                                               ; preds = %71
  call void @llvm.dbg.declare(metadata ptr %12, metadata !3203, metadata !DIExpression()), !dbg !3205
  %91 = load double, ptr %3, align 8, !dbg !3205
  %92 = call i64 @bits_of(double noundef %91), !dbg !3205
  store i64 %92, ptr %12, align 8, !dbg !3205
  %93 = load i64, ptr %12, align 8, !dbg !3205
  %94 = and i64 %93, 4294967295, !dbg !3205
  store i64 %94, ptr %12, align 8, !dbg !3205
  %95 = load i32, ptr %7, align 4, !dbg !3205
  %96 = sext i32 %95 to i64, !dbg !3205
  %97 = shl i64 %96, 32, !dbg !3205
  %98 = load i64, ptr %12, align 8, !dbg !3205
  %99 = or i64 %98, %97, !dbg !3205
  store i64 %99, ptr %12, align 8, !dbg !3205
  %100 = load i64, ptr %12, align 8, !dbg !3205
  %101 = call double @double_of(i64 noundef %100), !dbg !3205
  store double %101, ptr %3, align 8, !dbg !3205
  br label %102, !dbg !3205

102:                                              ; preds = %90
  br label %103, !dbg !3206

103:                                              ; preds = %102
  call void @llvm.dbg.declare(metadata ptr %13, metadata !3207, metadata !DIExpression()), !dbg !3209
  %104 = load double, ptr %3, align 8, !dbg !3209
  %105 = call i64 @bits_of(double noundef %104), !dbg !3209
  store i64 %105, ptr %13, align 8, !dbg !3209
  %106 = load i64, ptr %13, align 8, !dbg !3209
  %107 = and i64 %106, -4294967296, !dbg !3209
  store i64 %107, ptr %13, align 8, !dbg !3209
  %108 = load i32, ptr %8, align 4, !dbg !3209
  %109 = zext i32 %108 to i64, !dbg !3209
  %110 = load i64, ptr %13, align 8, !dbg !3209
  %111 = or i64 %110, %109, !dbg !3209
  store i64 %111, ptr %13, align 8, !dbg !3209
  %112 = load i64, ptr %13, align 8, !dbg !3209
  %113 = call double @double_of(i64 noundef %112), !dbg !3209
  store double %113, ptr %3, align 8, !dbg !3209
  br label %114, !dbg !3209

114:                                              ; preds = %103
  call void @llvm.dbg.declare(metadata ptr %14, metadata !3210, metadata !DIExpression()), !dbg !3211
  %115 = load double, ptr %4, align 8, !dbg !3212
  %116 = load double, ptr %3, align 8, !dbg !3213
  %117 = call double @pts_ieee754_log(double noundef %116), !dbg !3214
  %118 = fmul double 0x3FDBCB7B1526E50E, %117, !dbg !3215
  %119 = call double @llvm.fmuladd.f64(double %115, double 0x3D59FEF311F12B36, double %118), !dbg !3216
  store double %119, ptr %14, align 8, !dbg !3211
  %120 = load double, ptr %14, align 8, !dbg !3217
  %121 = load double, ptr %4, align 8, !dbg !3218
  %122 = call double @llvm.fmuladd.f64(double %121, double 0x3FD34413509F6000, double %120), !dbg !3219
  store double %122, ptr %2, align 8, !dbg !3220
  br label %123, !dbg !3220

123:                                              ; preds = %114, %70, %60, %37, %33
  %124 = load double, ptr %2, align 8, !dbg !3221
  ret double %124, !dbg !3221
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_expm1(double noundef %0) #0 !dbg !230 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca double, align 8
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i64, align 8
  %18 = alloca i32, align 4
  %19 = alloca i64, align 8
  %20 = alloca i64, align 8
  %21 = alloca i64, align 8
  %22 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3222, metadata !DIExpression()), !dbg !3223
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3224, metadata !DIExpression()), !dbg !3225
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3226, metadata !DIExpression()), !dbg !3227
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3228, metadata !DIExpression()), !dbg !3229
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3230, metadata !DIExpression()), !dbg !3231
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3232, metadata !DIExpression()), !dbg !3233
  call void @llvm.dbg.declare(metadata ptr %9, metadata !3234, metadata !DIExpression()), !dbg !3235
  call void @llvm.dbg.declare(metadata ptr %10, metadata !3236, metadata !DIExpression()), !dbg !3237
  call void @llvm.dbg.declare(metadata ptr %11, metadata !3238, metadata !DIExpression()), !dbg !3239
  call void @llvm.dbg.declare(metadata ptr %12, metadata !3240, metadata !DIExpression()), !dbg !3241
  call void @llvm.dbg.declare(metadata ptr %13, metadata !3242, metadata !DIExpression()), !dbg !3243
  call void @llvm.dbg.declare(metadata ptr %14, metadata !3244, metadata !DIExpression()), !dbg !3245
  call void @llvm.dbg.declare(metadata ptr %15, metadata !3246, metadata !DIExpression()), !dbg !3247
  call void @llvm.dbg.declare(metadata ptr %16, metadata !3248, metadata !DIExpression()), !dbg !3249
  br label %23, !dbg !3250

23:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %17, metadata !3251, metadata !DIExpression()), !dbg !3253
  %24 = load double, ptr %3, align 8, !dbg !3253
  %25 = call i64 @bits_of(double noundef %24), !dbg !3253
  store i64 %25, ptr %17, align 8, !dbg !3253
  %26 = load i64, ptr %17, align 8, !dbg !3253
  %27 = lshr i64 %26, 32, !dbg !3253
  %28 = trunc i64 %27 to i32, !dbg !3253
  store i32 %28, ptr %16, align 4, !dbg !3253
  br label %29, !dbg !3253

29:                                               ; preds = %23
  %30 = load i32, ptr %16, align 4, !dbg !3254
  %31 = and i32 %30, -2147483648, !dbg !3255
  store i32 %31, ptr %15, align 4, !dbg !3256
  %32 = load i32, ptr %16, align 4, !dbg !3257
  %33 = and i32 %32, 2147483647, !dbg !3257
  store i32 %33, ptr %16, align 4, !dbg !3257
  %34 = load i32, ptr %16, align 4, !dbg !3258
  %35 = icmp uge i32 %34, 1078159482, !dbg !3260
  br i1 %35, label %36, label %85, !dbg !3261

36:                                               ; preds = %29
  %37 = load i32, ptr %16, align 4, !dbg !3262
  %38 = icmp uge i32 %37, 1082535490, !dbg !3265
  br i1 %38, label %39, label %75, !dbg !3266

39:                                               ; preds = %36
  %40 = load i32, ptr %16, align 4, !dbg !3267
  %41 = icmp uge i32 %40, 2146435072, !dbg !3270
  br i1 %41, label %42, label %67, !dbg !3271

42:                                               ; preds = %39
  call void @llvm.dbg.declare(metadata ptr %18, metadata !3272, metadata !DIExpression()), !dbg !3274
  br label %43, !dbg !3275

43:                                               ; preds = %42
  call void @llvm.dbg.declare(metadata ptr %19, metadata !3276, metadata !DIExpression()), !dbg !3278
  %44 = load double, ptr %3, align 8, !dbg !3278
  %45 = call i64 @bits_of(double noundef %44), !dbg !3278
  store i64 %45, ptr %19, align 8, !dbg !3278
  %46 = load i64, ptr %19, align 8, !dbg !3278
  %47 = and i64 %46, 4294967295, !dbg !3278
  %48 = trunc i64 %47 to i32, !dbg !3278
  store i32 %48, ptr %18, align 4, !dbg !3278
  br label %49, !dbg !3278

49:                                               ; preds = %43
  %50 = load i32, ptr %16, align 4, !dbg !3279
  %51 = and i32 %50, 1048575, !dbg !3281
  %52 = load i32, ptr %18, align 4, !dbg !3282
  %53 = or i32 %51, %52, !dbg !3283
  %54 = icmp ne i32 %53, 0, !dbg !3284
  br i1 %54, label %55, label %59, !dbg !3285

55:                                               ; preds = %49
  %56 = load double, ptr %3, align 8, !dbg !3286
  %57 = load double, ptr %3, align 8, !dbg !3287
  %58 = fadd double %56, %57, !dbg !3288
  store double %58, ptr %2, align 8, !dbg !3289
  br label %310, !dbg !3289

59:                                               ; preds = %49
  %60 = load i32, ptr %15, align 4, !dbg !3290
  %61 = icmp eq i32 %60, 0, !dbg !3291
  br i1 %61, label %62, label %64, !dbg !3292

62:                                               ; preds = %59
  %63 = load double, ptr %3, align 8, !dbg !3293
  br label %65, !dbg !3292

64:                                               ; preds = %59
  br label %65, !dbg !3292

65:                                               ; preds = %64, %62
  %66 = phi double [ %63, %62 ], [ -1.000000e+00, %64 ], !dbg !3292
  store double %66, ptr %2, align 8, !dbg !3294
  br label %310, !dbg !3294

67:                                               ; preds = %39
  %68 = load double, ptr %3, align 8, !dbg !3295
  %69 = fcmp ogt double %68, 0x40862E42FEFA39EF, !dbg !3297
  br i1 %69, label %70, label %74, !dbg !3298

70:                                               ; preds = %67
  %71 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !3299
  %72 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !3300
  %73 = fmul double %71, %72, !dbg !3301
  store double %73, ptr %2, align 8, !dbg !3302
  br label %310, !dbg !3302

74:                                               ; preds = %67
  br label %75, !dbg !3303

75:                                               ; preds = %74, %36
  %76 = load i32, ptr %15, align 4, !dbg !3304
  %77 = icmp ne i32 %76, 0, !dbg !3306
  br i1 %77, label %78, label %84, !dbg !3307

78:                                               ; preds = %75
  %79 = load double, ptr %3, align 8, !dbg !3308
  %80 = fadd double %79, 1.000000e-300, !dbg !3311
  %81 = fcmp olt double %80, 0.000000e+00, !dbg !3312
  br i1 %81, label %82, label %83, !dbg !3313

82:                                               ; preds = %78
  store double -1.000000e+00, ptr %2, align 8, !dbg !3314
  br label %310, !dbg !3314

83:                                               ; preds = %78
  br label %84, !dbg !3315

84:                                               ; preds = %83, %75
  br label %85, !dbg !3316

85:                                               ; preds = %84, %29
  %86 = load i32, ptr %16, align 4, !dbg !3317
  %87 = icmp ugt i32 %86, 1071001154, !dbg !3319
  br i1 %87, label %88, label %126, !dbg !3320

88:                                               ; preds = %85
  %89 = load i32, ptr %16, align 4, !dbg !3321
  %90 = icmp ult i32 %89, 1072734898, !dbg !3324
  br i1 %90, label %91, label %101, !dbg !3325

91:                                               ; preds = %88
  %92 = load i32, ptr %15, align 4, !dbg !3326
  %93 = icmp eq i32 %92, 0, !dbg !3329
  br i1 %93, label %94, label %97, !dbg !3330

94:                                               ; preds = %91
  %95 = load double, ptr %3, align 8, !dbg !3331
  %96 = fsub double %95, 0x3FE62E42FEE00000, !dbg !3333
  store double %96, ptr %5, align 8, !dbg !3334
  store double 0x3DEA39EF35793C76, ptr %6, align 8, !dbg !3335
  store i32 1, ptr %14, align 4, !dbg !3336
  br label %100, !dbg !3337

97:                                               ; preds = %91
  %98 = load double, ptr %3, align 8, !dbg !3338
  %99 = fadd double %98, 0x3FE62E42FEE00000, !dbg !3340
  store double %99, ptr %5, align 8, !dbg !3341
  store double 0xBDEA39EF35793C76, ptr %6, align 8, !dbg !3342
  store i32 -1, ptr %14, align 4, !dbg !3343
  br label %100

100:                                              ; preds = %97, %94
  br label %117, !dbg !3344

101:                                              ; preds = %88
  %102 = load double, ptr %3, align 8, !dbg !3345
  %103 = load i32, ptr %15, align 4, !dbg !3347
  %104 = icmp eq i32 %103, 0, !dbg !3348
  %105 = zext i1 %104 to i64, !dbg !3349
  %106 = select i1 %104, double 5.000000e-01, double -5.000000e-01, !dbg !3349
  %107 = call double @llvm.fmuladd.f64(double 0x3FF71547652B82FE, double %102, double %106), !dbg !3350
  %108 = fptosi double %107 to i32, !dbg !3351
  store i32 %108, ptr %14, align 4, !dbg !3352
  %109 = load i32, ptr %14, align 4, !dbg !3353
  %110 = sitofp i32 %109 to double, !dbg !3353
  store double %110, ptr %8, align 8, !dbg !3354
  %111 = load double, ptr %3, align 8, !dbg !3355
  %112 = load double, ptr %8, align 8, !dbg !3356
  %113 = fneg double %112, !dbg !3357
  %114 = call double @llvm.fmuladd.f64(double %113, double 0x3FE62E42FEE00000, double %111), !dbg !3357
  store double %114, ptr %5, align 8, !dbg !3358
  %115 = load double, ptr %8, align 8, !dbg !3359
  %116 = fmul double %115, 0x3DEA39EF35793C76, !dbg !3360
  store double %116, ptr %6, align 8, !dbg !3361
  br label %117

117:                                              ; preds = %101, %100
  %118 = load double, ptr %5, align 8, !dbg !3362
  %119 = load double, ptr %6, align 8, !dbg !3363
  %120 = fsub double %118, %119, !dbg !3364
  store double %120, ptr %3, align 8, !dbg !3365
  %121 = load double, ptr %5, align 8, !dbg !3366
  %122 = load double, ptr %3, align 8, !dbg !3367
  %123 = fsub double %121, %122, !dbg !3368
  %124 = load double, ptr %6, align 8, !dbg !3369
  %125 = fsub double %123, %124, !dbg !3370
  store double %125, ptr %7, align 8, !dbg !3371
  br label %142, !dbg !3372

126:                                              ; preds = %85
  %127 = load i32, ptr %16, align 4, !dbg !3373
  %128 = icmp ult i32 %127, 1016070144, !dbg !3375
  br i1 %128, label %129, label %140, !dbg !3376

129:                                              ; preds = %126
  %130 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !3377
  %131 = load double, ptr %3, align 8, !dbg !3379
  %132 = fadd double %130, %131, !dbg !3380
  store double %132, ptr %8, align 8, !dbg !3381
  %133 = load double, ptr %3, align 8, !dbg !3382
  %134 = load double, ptr %8, align 8, !dbg !3383
  %135 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !3384
  %136 = load double, ptr %3, align 8, !dbg !3385
  %137 = fadd double %135, %136, !dbg !3386
  %138 = fsub double %134, %137, !dbg !3387
  %139 = fsub double %133, %138, !dbg !3388
  store double %139, ptr %2, align 8, !dbg !3389
  br label %310, !dbg !3389

140:                                              ; preds = %126
  store i32 0, ptr %14, align 4, !dbg !3390
  br label %141

141:                                              ; preds = %140
  br label %142

142:                                              ; preds = %141, %117
  %143 = load double, ptr %3, align 8, !dbg !3392
  %144 = fmul double 5.000000e-01, %143, !dbg !3393
  store double %144, ptr %11, align 8, !dbg !3394
  %145 = load double, ptr %3, align 8, !dbg !3395
  %146 = load double, ptr %11, align 8, !dbg !3396
  %147 = fmul double %145, %146, !dbg !3397
  store double %147, ptr %10, align 8, !dbg !3398
  %148 = load double, ptr %10, align 8, !dbg !3399
  %149 = load double, ptr %10, align 8, !dbg !3400
  %150 = load double, ptr %10, align 8, !dbg !3401
  %151 = load double, ptr %10, align 8, !dbg !3402
  %152 = load double, ptr %10, align 8, !dbg !3403
  %153 = call double @llvm.fmuladd.f64(double %152, double 0xBE8AFDB76E09C32D, double 0x3ED0CFCA86E65239), !dbg !3404
  %154 = call double @llvm.fmuladd.f64(double %151, double %153, double 0xBF14CE199EAADBB7), !dbg !3405
  %155 = call double @llvm.fmuladd.f64(double %150, double %154, double 0x3F5A01A019FE5585), !dbg !3406
  %156 = call double @llvm.fmuladd.f64(double %149, double %155, double 0xBFA11111111110F4), !dbg !3407
  %157 = call double @llvm.fmuladd.f64(double %148, double %156, double 1.000000e+00), !dbg !3408
  store double %157, ptr %12, align 8, !dbg !3409
  %158 = load double, ptr %12, align 8, !dbg !3410
  %159 = load double, ptr %11, align 8, !dbg !3411
  %160 = fneg double %158, !dbg !3412
  %161 = call double @llvm.fmuladd.f64(double %160, double %159, double 3.000000e+00), !dbg !3412
  store double %161, ptr %8, align 8, !dbg !3413
  %162 = load double, ptr %10, align 8, !dbg !3414
  %163 = load double, ptr %12, align 8, !dbg !3415
  %164 = load double, ptr %8, align 8, !dbg !3416
  %165 = fsub double %163, %164, !dbg !3417
  %166 = load double, ptr %3, align 8, !dbg !3418
  %167 = load double, ptr %8, align 8, !dbg !3419
  %168 = fneg double %166, !dbg !3420
  %169 = call double @llvm.fmuladd.f64(double %168, double %167, double 6.000000e+00), !dbg !3420
  %170 = fdiv double %165, %169, !dbg !3421
  %171 = fmul double %162, %170, !dbg !3422
  store double %171, ptr %9, align 8, !dbg !3423
  %172 = load i32, ptr %14, align 4, !dbg !3424
  %173 = icmp eq i32 %172, 0, !dbg !3426
  br i1 %173, label %174, label %182, !dbg !3427

174:                                              ; preds = %142
  %175 = load double, ptr %3, align 8, !dbg !3428
  %176 = load double, ptr %3, align 8, !dbg !3430
  %177 = load double, ptr %9, align 8, !dbg !3431
  %178 = load double, ptr %10, align 8, !dbg !3432
  %179 = fneg double %178, !dbg !3433
  %180 = call double @llvm.fmuladd.f64(double %176, double %177, double %179), !dbg !3433
  %181 = fsub double %175, %180, !dbg !3434
  store double %181, ptr %2, align 8, !dbg !3435
  br label %310, !dbg !3435

182:                                              ; preds = %142
  br label %183, !dbg !3436

183:                                              ; preds = %182
  call void @llvm.dbg.declare(metadata ptr %20, metadata !3438, metadata !DIExpression()), !dbg !3440
  store i64 0, ptr %20, align 8, !dbg !3440
  %184 = load i32, ptr %14, align 4, !dbg !3440
  %185 = shl i32 %184, 20, !dbg !3440
  %186 = add nsw i32 1072693248, %185, !dbg !3440
  %187 = sext i32 %186 to i64, !dbg !3440
  %188 = shl i64 %187, 32, !dbg !3440
  %189 = load i64, ptr %20, align 8, !dbg !3440
  %190 = or i64 %189, %188, !dbg !3440
  store i64 %190, ptr %20, align 8, !dbg !3440
  %191 = load i64, ptr %20, align 8, !dbg !3440
  %192 = or i64 %191, 0, !dbg !3440
  store i64 %192, ptr %20, align 8, !dbg !3440
  %193 = load i64, ptr %20, align 8, !dbg !3440
  %194 = call double @double_of(i64 noundef %193), !dbg !3440
  store double %194, ptr %13, align 8, !dbg !3440
  br label %195, !dbg !3440

195:                                              ; preds = %183
  %196 = load double, ptr %3, align 8, !dbg !3441
  %197 = load double, ptr %9, align 8, !dbg !3442
  %198 = load double, ptr %7, align 8, !dbg !3443
  %199 = fsub double %197, %198, !dbg !3444
  %200 = load double, ptr %7, align 8, !dbg !3445
  %201 = fneg double %200, !dbg !3446
  %202 = call double @llvm.fmuladd.f64(double %196, double %199, double %201), !dbg !3446
  store double %202, ptr %9, align 8, !dbg !3447
  %203 = load double, ptr %10, align 8, !dbg !3448
  %204 = load double, ptr %9, align 8, !dbg !3449
  %205 = fsub double %204, %203, !dbg !3449
  store double %205, ptr %9, align 8, !dbg !3449
  %206 = load i32, ptr %14, align 4, !dbg !3450
  %207 = icmp eq i32 %206, -1, !dbg !3452
  br i1 %207, label %208, label %213, !dbg !3453

208:                                              ; preds = %195
  %209 = load double, ptr %3, align 8, !dbg !3454
  %210 = load double, ptr %9, align 8, !dbg !3455
  %211 = fsub double %209, %210, !dbg !3456
  %212 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %211, double -5.000000e-01), !dbg !3457
  store double %212, ptr %2, align 8, !dbg !3458
  br label %310, !dbg !3458

213:                                              ; preds = %195
  %214 = load i32, ptr %14, align 4, !dbg !3459
  %215 = icmp eq i32 %214, 1, !dbg !3461
  br i1 %215, label %216, label %230, !dbg !3462

216:                                              ; preds = %213
  %217 = load double, ptr %3, align 8, !dbg !3463
  %218 = fcmp olt double %217, -2.500000e-01, !dbg !3466
  br i1 %218, label %219, label %225, !dbg !3467

219:                                              ; preds = %216
  %220 = load double, ptr %9, align 8, !dbg !3468
  %221 = load double, ptr %3, align 8, !dbg !3469
  %222 = fadd double %221, 5.000000e-01, !dbg !3470
  %223 = fsub double %220, %222, !dbg !3471
  %224 = fmul double -2.000000e+00, %223, !dbg !3472
  store double %224, ptr %2, align 8, !dbg !3473
  br label %310, !dbg !3473

225:                                              ; preds = %216
  %226 = load double, ptr %3, align 8, !dbg !3474
  %227 = load double, ptr %9, align 8, !dbg !3475
  %228 = fsub double %226, %227, !dbg !3476
  %229 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %228, double 1.000000e+00), !dbg !3477
  store double %229, ptr %2, align 8, !dbg !3478
  br label %310, !dbg !3478

230:                                              ; preds = %213
  %231 = load i32, ptr %14, align 4, !dbg !3479
  %232 = icmp sle i32 %231, -2, !dbg !3481
  br i1 %232, label %236, label %233, !dbg !3482

233:                                              ; preds = %230
  %234 = load i32, ptr %14, align 4, !dbg !3483
  %235 = icmp sgt i32 %234, 56, !dbg !3484
  br i1 %235, label %236, label %254, !dbg !3485

236:                                              ; preds = %233, %230
  %237 = load double, ptr %9, align 8, !dbg !3486
  %238 = load double, ptr %3, align 8, !dbg !3488
  %239 = fsub double %237, %238, !dbg !3489
  %240 = fsub double 1.000000e+00, %239, !dbg !3490
  store double %240, ptr %4, align 8, !dbg !3491
  %241 = load i32, ptr %14, align 4, !dbg !3492
  %242 = icmp eq i32 %241, 1024, !dbg !3494
  br i1 %242, label %243, label %247, !dbg !3495

243:                                              ; preds = %236
  %244 = load double, ptr %4, align 8, !dbg !3496
  %245 = fmul double %244, 2.000000e+00, !dbg !3497
  %246 = fmul double %245, 0x7FE0000000000000, !dbg !3498
  store double %246, ptr %4, align 8, !dbg !3499
  br label %251, !dbg !3500

247:                                              ; preds = %236
  %248 = load double, ptr %4, align 8, !dbg !3501
  %249 = load double, ptr %13, align 8, !dbg !3502
  %250 = fmul double %248, %249, !dbg !3503
  store double %250, ptr %4, align 8, !dbg !3504
  br label %251

251:                                              ; preds = %247, %243
  %252 = load double, ptr %4, align 8, !dbg !3505
  %253 = fsub double %252, 1.000000e+00, !dbg !3506
  store double %253, ptr %2, align 8, !dbg !3507
  br label %310, !dbg !3507

254:                                              ; preds = %233
  store double 1.000000e+00, ptr %8, align 8, !dbg !3508
  %255 = load i32, ptr %14, align 4, !dbg !3509
  %256 = icmp slt i32 %255, 20, !dbg !3511
  br i1 %256, label %257, label %281, !dbg !3512

257:                                              ; preds = %254
  br label %258, !dbg !3513

258:                                              ; preds = %257
  call void @llvm.dbg.declare(metadata ptr %21, metadata !3515, metadata !DIExpression()), !dbg !3517
  %259 = load double, ptr %8, align 8, !dbg !3517
  %260 = call i64 @bits_of(double noundef %259), !dbg !3517
  store i64 %260, ptr %21, align 8, !dbg !3517
  %261 = load i64, ptr %21, align 8, !dbg !3517
  %262 = and i64 %261, 4294967295, !dbg !3517
  store i64 %262, ptr %21, align 8, !dbg !3517
  %263 = load i32, ptr %14, align 4, !dbg !3517
  %264 = ashr i32 2097152, %263, !dbg !3517
  %265 = sub nsw i32 1072693248, %264, !dbg !3517
  %266 = sext i32 %265 to i64, !dbg !3517
  %267 = shl i64 %266, 32, !dbg !3517
  %268 = load i64, ptr %21, align 8, !dbg !3517
  %269 = or i64 %268, %267, !dbg !3517
  store i64 %269, ptr %21, align 8, !dbg !3517
  %270 = load i64, ptr %21, align 8, !dbg !3517
  %271 = call double @double_of(i64 noundef %270), !dbg !3517
  store double %271, ptr %8, align 8, !dbg !3517
  br label %272, !dbg !3517

272:                                              ; preds = %258
  %273 = load double, ptr %8, align 8, !dbg !3518
  %274 = load double, ptr %9, align 8, !dbg !3519
  %275 = load double, ptr %3, align 8, !dbg !3520
  %276 = fsub double %274, %275, !dbg !3521
  %277 = fsub double %273, %276, !dbg !3522
  store double %277, ptr %4, align 8, !dbg !3523
  %278 = load double, ptr %4, align 8, !dbg !3524
  %279 = load double, ptr %13, align 8, !dbg !3525
  %280 = fmul double %278, %279, !dbg !3526
  store double %280, ptr %4, align 8, !dbg !3527
  br label %307, !dbg !3528

281:                                              ; preds = %254
  br label %282, !dbg !3529

282:                                              ; preds = %281
  call void @llvm.dbg.declare(metadata ptr %22, metadata !3531, metadata !DIExpression()), !dbg !3533
  %283 = load double, ptr %8, align 8, !dbg !3533
  %284 = call i64 @bits_of(double noundef %283), !dbg !3533
  store i64 %284, ptr %22, align 8, !dbg !3533
  %285 = load i64, ptr %22, align 8, !dbg !3533
  %286 = and i64 %285, 4294967295, !dbg !3533
  store i64 %286, ptr %22, align 8, !dbg !3533
  %287 = load i32, ptr %14, align 4, !dbg !3533
  %288 = sub nsw i32 1023, %287, !dbg !3533
  %289 = shl i32 %288, 20, !dbg !3533
  %290 = sext i32 %289 to i64, !dbg !3533
  %291 = shl i64 %290, 32, !dbg !3533
  %292 = load i64, ptr %22, align 8, !dbg !3533
  %293 = or i64 %292, %291, !dbg !3533
  store i64 %293, ptr %22, align 8, !dbg !3533
  %294 = load i64, ptr %22, align 8, !dbg !3533
  %295 = call double @double_of(i64 noundef %294), !dbg !3533
  store double %295, ptr %8, align 8, !dbg !3533
  br label %296, !dbg !3533

296:                                              ; preds = %282
  %297 = load double, ptr %3, align 8, !dbg !3534
  %298 = load double, ptr %9, align 8, !dbg !3535
  %299 = load double, ptr %8, align 8, !dbg !3536
  %300 = fadd double %298, %299, !dbg !3537
  %301 = fsub double %297, %300, !dbg !3538
  store double %301, ptr %4, align 8, !dbg !3539
  %302 = load double, ptr %4, align 8, !dbg !3540
  %303 = fadd double %302, 1.000000e+00, !dbg !3540
  store double %303, ptr %4, align 8, !dbg !3540
  %304 = load double, ptr %4, align 8, !dbg !3541
  %305 = load double, ptr %13, align 8, !dbg !3542
  %306 = fmul double %304, %305, !dbg !3543
  store double %306, ptr %4, align 8, !dbg !3544
  br label %307

307:                                              ; preds = %296, %272
  br label %308

308:                                              ; preds = %307
  %309 = load double, ptr %4, align 8, !dbg !3545
  store double %309, ptr %2, align 8, !dbg !3546
  br label %310, !dbg !3546

310:                                              ; preds = %308, %251, %225, %219, %208, %174, %129, %82, %70, %65, %55
  %311 = load double, ptr %2, align 8, !dbg !3547
  ret double %311, !dbg !3547
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_cbrt(double noundef %0) #0 !dbg !255 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca i32, align 4
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i64, align 8
  %13 = alloca i64, align 8
  %14 = alloca i64, align 8
  %15 = alloca i64, align 8
  %16 = alloca i64, align 8
  %17 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3548, metadata !DIExpression()), !dbg !3549
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3550, metadata !DIExpression()), !dbg !3551
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3552, metadata !DIExpression()), !dbg !3553
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3554, metadata !DIExpression()), !dbg !3555
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3556, metadata !DIExpression()), !dbg !3557
  store double 0.000000e+00, ptr %7, align 8, !dbg !3557
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3558, metadata !DIExpression()), !dbg !3559
  call void @llvm.dbg.declare(metadata ptr %9, metadata !3560, metadata !DIExpression()), !dbg !3561
  call void @llvm.dbg.declare(metadata ptr %10, metadata !3562, metadata !DIExpression()), !dbg !3563
  call void @llvm.dbg.declare(metadata ptr %11, metadata !3564, metadata !DIExpression()), !dbg !3565
  br label %18, !dbg !3566

18:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %12, metadata !3567, metadata !DIExpression()), !dbg !3569
  %19 = load double, ptr %3, align 8, !dbg !3569
  %20 = call i64 @bits_of(double noundef %19), !dbg !3569
  store i64 %20, ptr %12, align 8, !dbg !3569
  %21 = load i64, ptr %12, align 8, !dbg !3569
  %22 = lshr i64 %21, 32, !dbg !3569
  %23 = trunc i64 %22 to i32, !dbg !3569
  store i32 %23, ptr %4, align 4, !dbg !3569
  %24 = load i64, ptr %12, align 8, !dbg !3569
  %25 = and i64 %24, 4294967295, !dbg !3569
  %26 = trunc i64 %25 to i32, !dbg !3569
  store i32 %26, ptr %11, align 4, !dbg !3569
  br label %27, !dbg !3569

27:                                               ; preds = %18
  %28 = load i32, ptr %4, align 4, !dbg !3570
  %29 = and i32 %28, -2147483648, !dbg !3571
  store i32 %29, ptr %9, align 4, !dbg !3572
  %30 = load i32, ptr %9, align 4, !dbg !3573
  %31 = load i32, ptr %4, align 4, !dbg !3574
  %32 = xor i32 %31, %30, !dbg !3574
  store i32 %32, ptr %4, align 4, !dbg !3574
  %33 = load i32, ptr %4, align 4, !dbg !3575
  %34 = icmp sge i32 %33, 2146435072, !dbg !3577
  br i1 %34, label %35, label %39, !dbg !3578

35:                                               ; preds = %27
  %36 = load double, ptr %3, align 8, !dbg !3579
  %37 = load double, ptr %3, align 8, !dbg !3580
  %38 = fadd double %36, %37, !dbg !3581
  store double %38, ptr %2, align 8, !dbg !3582
  br label %152, !dbg !3582

39:                                               ; preds = %27
  %40 = load i32, ptr %4, align 4, !dbg !3583
  %41 = icmp slt i32 %40, 1048576, !dbg !3585
  br i1 %41, label %42, label %86, !dbg !3586

42:                                               ; preds = %39
  %43 = load i32, ptr %4, align 4, !dbg !3587
  %44 = load i32, ptr %11, align 4, !dbg !3590
  %45 = or i32 %43, %44, !dbg !3591
  %46 = icmp eq i32 %45, 0, !dbg !3592
  br i1 %46, label %47, label %49, !dbg !3593

47:                                               ; preds = %42
  %48 = load double, ptr %3, align 8, !dbg !3594
  store double %48, ptr %2, align 8, !dbg !3595
  br label %152, !dbg !3595

49:                                               ; preds = %42
  br label %50, !dbg !3596

50:                                               ; preds = %49
  call void @llvm.dbg.declare(metadata ptr %13, metadata !3597, metadata !DIExpression()), !dbg !3599
  %51 = load double, ptr %7, align 8, !dbg !3599
  %52 = call i64 @bits_of(double noundef %51), !dbg !3599
  store i64 %52, ptr %13, align 8, !dbg !3599
  %53 = load i64, ptr %13, align 8, !dbg !3599
  %54 = and i64 %53, 4294967295, !dbg !3599
  store i64 %54, ptr %13, align 8, !dbg !3599
  %55 = load i64, ptr %13, align 8, !dbg !3599
  %56 = or i64 %55, 4850376798678024192, !dbg !3599
  store i64 %56, ptr %13, align 8, !dbg !3599
  %57 = load i64, ptr %13, align 8, !dbg !3599
  %58 = call double @double_of(i64 noundef %57), !dbg !3599
  store double %58, ptr %7, align 8, !dbg !3599
  br label %59, !dbg !3599

59:                                               ; preds = %50
  %60 = load double, ptr %3, align 8, !dbg !3600
  %61 = load double, ptr %7, align 8, !dbg !3601
  %62 = fmul double %61, %60, !dbg !3601
  store double %62, ptr %7, align 8, !dbg !3601
  br label %63, !dbg !3602

63:                                               ; preds = %59
  call void @llvm.dbg.declare(metadata ptr %14, metadata !3603, metadata !DIExpression()), !dbg !3605
  %64 = load double, ptr %7, align 8, !dbg !3605
  %65 = call i64 @bits_of(double noundef %64), !dbg !3605
  store i64 %65, ptr %14, align 8, !dbg !3605
  %66 = load i64, ptr %14, align 8, !dbg !3605
  %67 = lshr i64 %66, 32, !dbg !3605
  %68 = trunc i64 %67 to i32, !dbg !3605
  store i32 %68, ptr %10, align 4, !dbg !3605
  br label %69, !dbg !3605

69:                                               ; preds = %63
  br label %70, !dbg !3606

70:                                               ; preds = %69
  call void @llvm.dbg.declare(metadata ptr %15, metadata !3607, metadata !DIExpression()), !dbg !3609
  store i64 0, ptr %15, align 8, !dbg !3609
  %71 = load i32, ptr %9, align 4, !dbg !3609
  %72 = load i32, ptr %10, align 4, !dbg !3609
  %73 = and i32 %72, 2147483647, !dbg !3609
  %74 = udiv i32 %73, 3, !dbg !3609
  %75 = add i32 %74, 696219795, !dbg !3609
  %76 = or i32 %71, %75, !dbg !3609
  %77 = zext i32 %76 to i64, !dbg !3609
  %78 = shl i64 %77, 32, !dbg !3609
  %79 = load i64, ptr %15, align 8, !dbg !3609
  %80 = or i64 %79, %78, !dbg !3609
  store i64 %80, ptr %15, align 8, !dbg !3609
  %81 = load i64, ptr %15, align 8, !dbg !3609
  %82 = or i64 %81, 0, !dbg !3609
  store i64 %82, ptr %15, align 8, !dbg !3609
  %83 = load i64, ptr %15, align 8, !dbg !3609
  %84 = call double @double_of(i64 noundef %83), !dbg !3609
  store double %84, ptr %7, align 8, !dbg !3609
  br label %85, !dbg !3609

85:                                               ; preds = %70
  br label %102, !dbg !3610

86:                                               ; preds = %39
  br label %87, !dbg !3611

87:                                               ; preds = %86
  call void @llvm.dbg.declare(metadata ptr %16, metadata !3613, metadata !DIExpression()), !dbg !3615
  store i64 0, ptr %16, align 8, !dbg !3615
  %88 = load i32, ptr %9, align 4, !dbg !3615
  %89 = load i32, ptr %4, align 4, !dbg !3615
  %90 = sdiv i32 %89, 3, !dbg !3615
  %91 = add i32 %90, 715094163, !dbg !3615
  %92 = or i32 %88, %91, !dbg !3615
  %93 = zext i32 %92 to i64, !dbg !3615
  %94 = shl i64 %93, 32, !dbg !3615
  %95 = load i64, ptr %16, align 8, !dbg !3615
  %96 = or i64 %95, %94, !dbg !3615
  store i64 %96, ptr %16, align 8, !dbg !3615
  %97 = load i64, ptr %16, align 8, !dbg !3615
  %98 = or i64 %97, 0, !dbg !3615
  store i64 %98, ptr %16, align 8, !dbg !3615
  %99 = load i64, ptr %16, align 8, !dbg !3615
  %100 = call double @double_of(i64 noundef %99), !dbg !3615
  store double %100, ptr %7, align 8, !dbg !3615
  br label %101, !dbg !3615

101:                                              ; preds = %87
  br label %102

102:                                              ; preds = %101, %85
  %103 = load double, ptr %7, align 8, !dbg !3616
  %104 = load double, ptr %7, align 8, !dbg !3617
  %105 = fmul double %103, %104, !dbg !3618
  %106 = load double, ptr %7, align 8, !dbg !3619
  %107 = load double, ptr %3, align 8, !dbg !3620
  %108 = fdiv double %106, %107, !dbg !3621
  %109 = fmul double %105, %108, !dbg !3622
  store double %109, ptr %5, align 8, !dbg !3623
  %110 = load double, ptr %7, align 8, !dbg !3624
  %111 = load double, ptr %5, align 8, !dbg !3625
  %112 = load double, ptr %5, align 8, !dbg !3626
  %113 = call double @llvm.fmuladd.f64(double %112, double 0x3FF9F1604A49D6C2, double 0xBFFE28E092F02420), !dbg !3627
  %114 = call double @llvm.fmuladd.f64(double %111, double %113, double 0x3FFE03E60F61E692), !dbg !3628
  %115 = load double, ptr %5, align 8, !dbg !3629
  %116 = load double, ptr %5, align 8, !dbg !3630
  %117 = fmul double %115, %116, !dbg !3631
  %118 = load double, ptr %5, align 8, !dbg !3632
  %119 = fmul double %117, %118, !dbg !3633
  %120 = load double, ptr %5, align 8, !dbg !3634
  %121 = call double @llvm.fmuladd.f64(double %120, double 0x3FC2B000D4E4EDD7, double 0xBFE844CBBEE751D9), !dbg !3635
  %122 = call double @llvm.fmuladd.f64(double %119, double %121, double %114), !dbg !3636
  %123 = fmul double %110, %122, !dbg !3637
  store double %123, ptr %7, align 8, !dbg !3638
  call void @llvm.dbg.declare(metadata ptr %17, metadata !3639, metadata !DIExpression()), !dbg !3640
  %124 = load double, ptr %7, align 8, !dbg !3641
  %125 = call i64 @bits_of(double noundef %124), !dbg !3642
  store i64 %125, ptr %17, align 8, !dbg !3640
  %126 = load i64, ptr %17, align 8, !dbg !3643
  %127 = add i64 %126, 2147483648, !dbg !3644
  %128 = and i64 %127, -1073741824, !dbg !3645
  store i64 %128, ptr %17, align 8, !dbg !3646
  %129 = load i64, ptr %17, align 8, !dbg !3647
  %130 = call double @double_of(i64 noundef %129), !dbg !3648
  store double %130, ptr %7, align 8, !dbg !3649
  %131 = load double, ptr %7, align 8, !dbg !3650
  %132 = load double, ptr %7, align 8, !dbg !3651
  %133 = fmul double %131, %132, !dbg !3652
  store double %133, ptr %6, align 8, !dbg !3653
  %134 = load double, ptr %3, align 8, !dbg !3654
  %135 = load double, ptr %6, align 8, !dbg !3655
  %136 = fdiv double %134, %135, !dbg !3656
  store double %136, ptr %5, align 8, !dbg !3657
  %137 = load double, ptr %7, align 8, !dbg !3658
  %138 = load double, ptr %7, align 8, !dbg !3659
  %139 = fadd double %137, %138, !dbg !3660
  store double %139, ptr %8, align 8, !dbg !3661
  %140 = load double, ptr %5, align 8, !dbg !3662
  %141 = load double, ptr %7, align 8, !dbg !3663
  %142 = fsub double %140, %141, !dbg !3664
  %143 = load double, ptr %8, align 8, !dbg !3665
  %144 = load double, ptr %5, align 8, !dbg !3666
  %145 = fadd double %143, %144, !dbg !3667
  %146 = fdiv double %142, %145, !dbg !3668
  store double %146, ptr %5, align 8, !dbg !3669
  %147 = load double, ptr %7, align 8, !dbg !3670
  %148 = load double, ptr %7, align 8, !dbg !3671
  %149 = load double, ptr %5, align 8, !dbg !3672
  %150 = call double @llvm.fmuladd.f64(double %148, double %149, double %147), !dbg !3673
  store double %150, ptr %7, align 8, !dbg !3674
  %151 = load double, ptr %7, align 8, !dbg !3675
  store double %151, ptr %2, align 8, !dbg !3676
  br label %152, !dbg !3676

152:                                              ; preds = %102, %47, %35
  %153 = load double, ptr %2, align 8, !dbg !3677
  ret double %153, !dbg !3677
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_sin(double noundef %0) #0 !dbg !3678 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca [2 x double], align 8
  %5 = alloca double, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3679, metadata !DIExpression()), !dbg !3680
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3681, metadata !DIExpression()), !dbg !3682
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3683, metadata !DIExpression()), !dbg !3684
  store double 0.000000e+00, ptr %5, align 8, !dbg !3684
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3685, metadata !DIExpression()), !dbg !3686
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3687, metadata !DIExpression()), !dbg !3688
  br label %9, !dbg !3689

9:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3690, metadata !DIExpression()), !dbg !3692
  %10 = load double, ptr %3, align 8, !dbg !3692
  %11 = call i64 @bits_of(double noundef %10), !dbg !3692
  store i64 %11, ptr %8, align 8, !dbg !3692
  %12 = load i64, ptr %8, align 8, !dbg !3692
  %13 = lshr i64 %12, 32, !dbg !3692
  %14 = trunc i64 %13 to i32, !dbg !3692
  store i32 %14, ptr %7, align 4, !dbg !3692
  br label %15, !dbg !3692

15:                                               ; preds = %9
  %16 = load i32, ptr %7, align 4, !dbg !3693
  %17 = and i32 %16, 2147483647, !dbg !3693
  store i32 %17, ptr %7, align 4, !dbg !3693
  %18 = load i32, ptr %7, align 4, !dbg !3694
  %19 = icmp sle i32 %18, 1072243195, !dbg !3696
  br i1 %19, label %20, label %24, !dbg !3697

20:                                               ; preds = %15
  %21 = load double, ptr %3, align 8, !dbg !3698
  %22 = load double, ptr %5, align 8, !dbg !3700
  %23 = call double @__kernel_sin(double noundef %21, double noundef %22, i32 noundef 0), !dbg !3701
  store double %23, ptr %2, align 8, !dbg !3702
  br label %63, !dbg !3702

24:                                               ; preds = %15
  %25 = load i32, ptr %7, align 4, !dbg !3703
  %26 = icmp sge i32 %25, 2146435072, !dbg !3705
  br i1 %26, label %27, label %31, !dbg !3706

27:                                               ; preds = %24
  %28 = load double, ptr %3, align 8, !dbg !3707
  %29 = load double, ptr %3, align 8, !dbg !3709
  %30 = fsub double %28, %29, !dbg !3710
  store double %30, ptr %2, align 8, !dbg !3711
  br label %63, !dbg !3711

31:                                               ; preds = %24
  %32 = load double, ptr %3, align 8, !dbg !3712
  %33 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3714
  %34 = call i32 @__ieee754_rem_pio2(double noundef %32, ptr noundef %33), !dbg !3715
  store i32 %34, ptr %6, align 4, !dbg !3716
  %35 = load i32, ptr %6, align 4, !dbg !3717
  %36 = and i32 %35, 3, !dbg !3718
  switch i32 %36, label %56 [
    i32 0, label %37
    i32 1, label %43
    i32 2, label %49
  ], !dbg !3719

37:                                               ; preds = %31
  %38 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3720
  %39 = load double, ptr %38, align 8, !dbg !3720
  %40 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !3722
  %41 = load double, ptr %40, align 8, !dbg !3722
  %42 = call double @__kernel_sin(double noundef %39, double noundef %41, i32 noundef 1), !dbg !3723
  store double %42, ptr %2, align 8, !dbg !3724
  br label %63, !dbg !3724

43:                                               ; preds = %31
  %44 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3725
  %45 = load double, ptr %44, align 8, !dbg !3725
  %46 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !3726
  %47 = load double, ptr %46, align 8, !dbg !3726
  %48 = call double @__kernel_cos(double noundef %45, double noundef %47), !dbg !3727
  store double %48, ptr %2, align 8, !dbg !3728
  br label %63, !dbg !3728

49:                                               ; preds = %31
  %50 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3729
  %51 = load double, ptr %50, align 8, !dbg !3729
  %52 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !3730
  %53 = load double, ptr %52, align 8, !dbg !3730
  %54 = call double @__kernel_sin(double noundef %51, double noundef %53, i32 noundef 1), !dbg !3731
  %55 = fneg double %54, !dbg !3732
  store double %55, ptr %2, align 8, !dbg !3733
  br label %63, !dbg !3733

56:                                               ; preds = %31
  %57 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3734
  %58 = load double, ptr %57, align 8, !dbg !3734
  %59 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !3735
  %60 = load double, ptr %59, align 8, !dbg !3735
  %61 = call double @__kernel_cos(double noundef %58, double noundef %60), !dbg !3736
  %62 = fneg double %61, !dbg !3737
  store double %62, ptr %2, align 8, !dbg !3738
  br label %63, !dbg !3738

63:                                               ; preds = %56, %49, %43, %37, %27, %20
  %64 = load double, ptr %2, align 8, !dbg !3739
  ret double %64, !dbg !3739
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_tan(double noundef %0) #0 !dbg !3740 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca [2 x double], align 8
  %5 = alloca double, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !3741, metadata !DIExpression()), !dbg !3742
  call void @llvm.dbg.declare(metadata ptr %4, metadata !3743, metadata !DIExpression()), !dbg !3744
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3745, metadata !DIExpression()), !dbg !3746
  store double 0.000000e+00, ptr %5, align 8, !dbg !3746
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3747, metadata !DIExpression()), !dbg !3748
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3749, metadata !DIExpression()), !dbg !3750
  br label %9, !dbg !3751

9:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3752, metadata !DIExpression()), !dbg !3754
  %10 = load double, ptr %3, align 8, !dbg !3754
  %11 = call i64 @bits_of(double noundef %10), !dbg !3754
  store i64 %11, ptr %8, align 8, !dbg !3754
  %12 = load i64, ptr %8, align 8, !dbg !3754
  %13 = lshr i64 %12, 32, !dbg !3754
  %14 = trunc i64 %13 to i32, !dbg !3754
  store i32 %14, ptr %7, align 4, !dbg !3754
  br label %15, !dbg !3754

15:                                               ; preds = %9
  %16 = load i32, ptr %7, align 4, !dbg !3755
  %17 = and i32 %16, 2147483647, !dbg !3755
  store i32 %17, ptr %7, align 4, !dbg !3755
  %18 = load i32, ptr %7, align 4, !dbg !3756
  %19 = icmp sle i32 %18, 1072243195, !dbg !3758
  br i1 %19, label %20, label %24, !dbg !3759

20:                                               ; preds = %15
  %21 = load double, ptr %3, align 8, !dbg !3760
  %22 = load double, ptr %5, align 8, !dbg !3762
  %23 = call double @__kernel_tan(double noundef %21, double noundef %22, i32 noundef 1), !dbg !3763
  store double %23, ptr %2, align 8, !dbg !3764
  br label %44, !dbg !3764

24:                                               ; preds = %15
  %25 = load i32, ptr %7, align 4, !dbg !3765
  %26 = icmp sge i32 %25, 2146435072, !dbg !3767
  br i1 %26, label %27, label %31, !dbg !3768

27:                                               ; preds = %24
  %28 = load double, ptr %3, align 8, !dbg !3769
  %29 = load double, ptr %3, align 8, !dbg !3771
  %30 = fsub double %28, %29, !dbg !3772
  store double %30, ptr %2, align 8, !dbg !3773
  br label %44, !dbg !3773

31:                                               ; preds = %24
  %32 = load double, ptr %3, align 8, !dbg !3774
  %33 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3776
  %34 = call i32 @__ieee754_rem_pio2(double noundef %32, ptr noundef %33), !dbg !3777
  store i32 %34, ptr %6, align 4, !dbg !3778
  %35 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 0, !dbg !3779
  %36 = load double, ptr %35, align 8, !dbg !3779
  %37 = getelementptr inbounds [2 x double], ptr %4, i64 0, i64 1, !dbg !3780
  %38 = load double, ptr %37, align 8, !dbg !3780
  %39 = load i32, ptr %6, align 4, !dbg !3781
  %40 = and i32 %39, 1, !dbg !3782
  %41 = shl i32 %40, 1, !dbg !3783
  %42 = sub nsw i32 1, %41, !dbg !3784
  %43 = call double @__kernel_tan(double noundef %36, double noundef %38, i32 noundef %42), !dbg !3785
  store double %43, ptr %2, align 8, !dbg !3786
  br label %44, !dbg !3786

44:                                               ; preds = %31, %27, %20
  %45 = load double, ptr %2, align 8, !dbg !3787
  ret double %45, !dbg !3787
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal double @__kernel_tan(double noundef %0, double noundef %1, i32 noundef %2) #0 !dbg !400 {
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca i32, align 4
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  %11 = alloca double, align 8
  %12 = alloca double, align 8
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i64, align 8
  %16 = alloca i32, align 4
  %17 = alloca i64, align 8
  %18 = alloca double, align 8
  %19 = alloca double, align 8
  %20 = alloca i64, align 8
  %21 = alloca i64, align 8
  %22 = alloca double, align 8
  %23 = alloca double, align 8
  %24 = alloca i64, align 8
  %25 = alloca i64, align 8
  store double %0, ptr %5, align 8
  call void @llvm.dbg.declare(metadata ptr %5, metadata !3788, metadata !DIExpression()), !dbg !3789
  store double %1, ptr %6, align 8
  call void @llvm.dbg.declare(metadata ptr %6, metadata !3790, metadata !DIExpression()), !dbg !3791
  store i32 %2, ptr %7, align 4
  call void @llvm.dbg.declare(metadata ptr %7, metadata !3792, metadata !DIExpression()), !dbg !3793
  call void @llvm.dbg.declare(metadata ptr %8, metadata !3794, metadata !DIExpression()), !dbg !3795
  call void @llvm.dbg.declare(metadata ptr %9, metadata !3796, metadata !DIExpression()), !dbg !3797
  call void @llvm.dbg.declare(metadata ptr %10, metadata !3798, metadata !DIExpression()), !dbg !3799
  call void @llvm.dbg.declare(metadata ptr %11, metadata !3800, metadata !DIExpression()), !dbg !3801
  call void @llvm.dbg.declare(metadata ptr %12, metadata !3802, metadata !DIExpression()), !dbg !3803
  call void @llvm.dbg.declare(metadata ptr %13, metadata !3804, metadata !DIExpression()), !dbg !3805
  call void @llvm.dbg.declare(metadata ptr %14, metadata !3806, metadata !DIExpression()), !dbg !3807
  br label %26, !dbg !3808

26:                                               ; preds = %3
  call void @llvm.dbg.declare(metadata ptr %15, metadata !3809, metadata !DIExpression()), !dbg !3811
  %27 = load double, ptr %5, align 8, !dbg !3811
  %28 = call i64 @bits_of(double noundef %27), !dbg !3811
  store i64 %28, ptr %15, align 8, !dbg !3811
  %29 = load i64, ptr %15, align 8, !dbg !3811
  %30 = lshr i64 %29, 32, !dbg !3811
  %31 = trunc i64 %30 to i32, !dbg !3811
  store i32 %31, ptr %14, align 4, !dbg !3811
  br label %32, !dbg !3811

32:                                               ; preds = %26
  %33 = load i32, ptr %14, align 4, !dbg !3812
  %34 = and i32 %33, 2147483647, !dbg !3813
  store i32 %34, ptr %13, align 4, !dbg !3814
  %35 = load i32, ptr %13, align 4, !dbg !3815
  %36 = icmp slt i32 %35, 1043333120, !dbg !3817
  br i1 %36, label %37, label %111, !dbg !3818

37:                                               ; preds = %32
  %38 = load double, ptr %5, align 8, !dbg !3819
  %39 = fptosi double %38 to i32, !dbg !3822
  %40 = icmp eq i32 %39, 0, !dbg !3823
  br i1 %40, label %41, label %110, !dbg !3824

41:                                               ; preds = %37
  call void @llvm.dbg.declare(metadata ptr %16, metadata !3825, metadata !DIExpression()), !dbg !3827
  br label %42, !dbg !3828

42:                                               ; preds = %41
  call void @llvm.dbg.declare(metadata ptr %17, metadata !3829, metadata !DIExpression()), !dbg !3831
  %43 = load double, ptr %5, align 8, !dbg !3831
  %44 = call i64 @bits_of(double noundef %43), !dbg !3831
  store i64 %44, ptr %17, align 8, !dbg !3831
  %45 = load i64, ptr %17, align 8, !dbg !3831
  %46 = and i64 %45, 4294967295, !dbg !3831
  %47 = trunc i64 %46 to i32, !dbg !3831
  store i32 %47, ptr %16, align 4, !dbg !3831
  br label %48, !dbg !3831

48:                                               ; preds = %42
  %49 = load i32, ptr %13, align 4, !dbg !3832
  %50 = load i32, ptr %16, align 4, !dbg !3834
  %51 = or i32 %49, %50, !dbg !3835
  %52 = load i32, ptr %7, align 4, !dbg !3836
  %53 = add nsw i32 %52, 1, !dbg !3837
  %54 = or i32 %51, %53, !dbg !3838
  %55 = icmp eq i32 %54, 0, !dbg !3839
  br i1 %55, label %56, label %61, !dbg !3840

56:                                               ; preds = %48
  %57 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 13), align 8, !dbg !3841
  %58 = load double, ptr %5, align 8, !dbg !3843
  %59 = call double @llvm.fabs.f64(double %58), !dbg !3844
  %60 = fdiv double %57, %59, !dbg !3845
  store double %60, ptr %4, align 8, !dbg !3846
  br label %260, !dbg !3846

61:                                               ; preds = %48
  %62 = load i32, ptr %7, align 4, !dbg !3847
  %63 = icmp eq i32 %62, 1, !dbg !3850
  br i1 %63, label %64, label %66, !dbg !3851

64:                                               ; preds = %61
  %65 = load double, ptr %5, align 8, !dbg !3852
  store double %65, ptr %4, align 8, !dbg !3854
  br label %260, !dbg !3854

66:                                               ; preds = %61
  call void @llvm.dbg.declare(metadata ptr %18, metadata !3855, metadata !DIExpression()), !dbg !3857
  call void @llvm.dbg.declare(metadata ptr %19, metadata !3858, metadata !DIExpression()), !dbg !3859
  %67 = load double, ptr %5, align 8, !dbg !3860
  %68 = load double, ptr %6, align 8, !dbg !3861
  %69 = fadd double %67, %68, !dbg !3862
  store double %69, ptr %11, align 8, !dbg !3863
  store double %69, ptr %8, align 8, !dbg !3864
  br label %70, !dbg !3865

70:                                               ; preds = %66
  call void @llvm.dbg.declare(metadata ptr %20, metadata !3866, metadata !DIExpression()), !dbg !3868
  %71 = load double, ptr %8, align 8, !dbg !3868
  %72 = call i64 @bits_of(double noundef %71), !dbg !3868
  store i64 %72, ptr %20, align 8, !dbg !3868
  %73 = load i64, ptr %20, align 8, !dbg !3868
  %74 = and i64 %73, -4294967296, !dbg !3868
  store i64 %74, ptr %20, align 8, !dbg !3868
  %75 = load i64, ptr %20, align 8, !dbg !3868
  %76 = or i64 %75, 0, !dbg !3868
  store i64 %76, ptr %20, align 8, !dbg !3868
  %77 = load i64, ptr %20, align 8, !dbg !3868
  %78 = call double @double_of(i64 noundef %77), !dbg !3868
  store double %78, ptr %8, align 8, !dbg !3868
  br label %79, !dbg !3868

79:                                               ; preds = %70
  %80 = load double, ptr %6, align 8, !dbg !3869
  %81 = load double, ptr %8, align 8, !dbg !3870
  %82 = load double, ptr %5, align 8, !dbg !3871
  %83 = fsub double %81, %82, !dbg !3872
  %84 = fsub double %80, %83, !dbg !3873
  store double %84, ptr %10, align 8, !dbg !3874
  %85 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 13), align 8, !dbg !3875
  %86 = fneg double %85, !dbg !3876
  %87 = load double, ptr %11, align 8, !dbg !3877
  %88 = fdiv double %86, %87, !dbg !3878
  store double %88, ptr %18, align 8, !dbg !3879
  store double %88, ptr %19, align 8, !dbg !3880
  br label %89, !dbg !3881

89:                                               ; preds = %79
  call void @llvm.dbg.declare(metadata ptr %21, metadata !3882, metadata !DIExpression()), !dbg !3884
  %90 = load double, ptr %19, align 8, !dbg !3884
  %91 = call i64 @bits_of(double noundef %90), !dbg !3884
  store i64 %91, ptr %21, align 8, !dbg !3884
  %92 = load i64, ptr %21, align 8, !dbg !3884
  %93 = and i64 %92, -4294967296, !dbg !3884
  store i64 %93, ptr %21, align 8, !dbg !3884
  %94 = load i64, ptr %21, align 8, !dbg !3884
  %95 = or i64 %94, 0, !dbg !3884
  store i64 %95, ptr %21, align 8, !dbg !3884
  %96 = load i64, ptr %21, align 8, !dbg !3884
  %97 = call double @double_of(i64 noundef %96), !dbg !3884
  store double %97, ptr %19, align 8, !dbg !3884
  br label %98, !dbg !3884

98:                                               ; preds = %89
  %99 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 13), align 8, !dbg !3885
  %100 = load double, ptr %19, align 8, !dbg !3886
  %101 = load double, ptr %8, align 8, !dbg !3887
  %102 = call double @llvm.fmuladd.f64(double %100, double %101, double %99), !dbg !3888
  store double %102, ptr %12, align 8, !dbg !3889
  %103 = load double, ptr %19, align 8, !dbg !3890
  %104 = load double, ptr %18, align 8, !dbg !3891
  %105 = load double, ptr %12, align 8, !dbg !3892
  %106 = load double, ptr %19, align 8, !dbg !3893
  %107 = load double, ptr %10, align 8, !dbg !3894
  %108 = call double @llvm.fmuladd.f64(double %106, double %107, double %105), !dbg !3895
  %109 = call double @llvm.fmuladd.f64(double %104, double %108, double %103), !dbg !3896
  store double %109, ptr %4, align 8, !dbg !3897
  br label %260, !dbg !3897

110:                                              ; preds = %37
  br label %111, !dbg !3898

111:                                              ; preds = %110, %32
  %112 = load i32, ptr %13, align 4, !dbg !3899
  %113 = icmp sge i32 %112, 1072010280, !dbg !3901
  br i1 %113, label %114, label %132, !dbg !3902

114:                                              ; preds = %111
  %115 = load i32, ptr %14, align 4, !dbg !3903
  %116 = icmp slt i32 %115, 0, !dbg !3906
  br i1 %116, label %117, label %122, !dbg !3907

117:                                              ; preds = %114
  %118 = load double, ptr %5, align 8, !dbg !3908
  %119 = fneg double %118, !dbg !3910
  store double %119, ptr %5, align 8, !dbg !3911
  %120 = load double, ptr %6, align 8, !dbg !3912
  %121 = fneg double %120, !dbg !3913
  store double %121, ptr %6, align 8, !dbg !3914
  br label %122, !dbg !3915

122:                                              ; preds = %117, %114
  %123 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 14), align 8, !dbg !3916
  %124 = load double, ptr %5, align 8, !dbg !3917
  %125 = fsub double %123, %124, !dbg !3918
  store double %125, ptr %8, align 8, !dbg !3919
  %126 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 15), align 8, !dbg !3920
  %127 = load double, ptr %6, align 8, !dbg !3921
  %128 = fsub double %126, %127, !dbg !3922
  store double %128, ptr %11, align 8, !dbg !3923
  %129 = load double, ptr %8, align 8, !dbg !3924
  %130 = load double, ptr %11, align 8, !dbg !3925
  %131 = fadd double %129, %130, !dbg !3926
  store double %131, ptr %5, align 8, !dbg !3927
  store double 0.000000e+00, ptr %6, align 8, !dbg !3928
  br label %132, !dbg !3929

132:                                              ; preds = %122, %111
  %133 = load double, ptr %5, align 8, !dbg !3930
  %134 = load double, ptr %5, align 8, !dbg !3931
  %135 = fmul double %133, %134, !dbg !3932
  store double %135, ptr %8, align 8, !dbg !3933
  %136 = load double, ptr %8, align 8, !dbg !3934
  %137 = load double, ptr %8, align 8, !dbg !3935
  %138 = fmul double %136, %137, !dbg !3936
  store double %138, ptr %11, align 8, !dbg !3937
  %139 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 1), align 8, !dbg !3938
  %140 = load double, ptr %11, align 8, !dbg !3939
  %141 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 3), align 8, !dbg !3940
  %142 = load double, ptr %11, align 8, !dbg !3941
  %143 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 5), align 8, !dbg !3942
  %144 = load double, ptr %11, align 8, !dbg !3943
  %145 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 7), align 8, !dbg !3944
  %146 = load double, ptr %11, align 8, !dbg !3945
  %147 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 9), align 8, !dbg !3946
  %148 = load double, ptr %11, align 8, !dbg !3947
  %149 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 11), align 8, !dbg !3948
  %150 = call double @llvm.fmuladd.f64(double %148, double %149, double %147), !dbg !3949
  %151 = call double @llvm.fmuladd.f64(double %146, double %150, double %145), !dbg !3950
  %152 = call double @llvm.fmuladd.f64(double %144, double %151, double %143), !dbg !3951
  %153 = call double @llvm.fmuladd.f64(double %142, double %152, double %141), !dbg !3952
  %154 = call double @llvm.fmuladd.f64(double %140, double %153, double %139), !dbg !3953
  store double %154, ptr %9, align 8, !dbg !3954
  %155 = load double, ptr %8, align 8, !dbg !3955
  %156 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 2), align 8, !dbg !3956
  %157 = load double, ptr %11, align 8, !dbg !3957
  %158 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 4), align 8, !dbg !3958
  %159 = load double, ptr %11, align 8, !dbg !3959
  %160 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 6), align 8, !dbg !3960
  %161 = load double, ptr %11, align 8, !dbg !3961
  %162 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 8), align 8, !dbg !3962
  %163 = load double, ptr %11, align 8, !dbg !3963
  %164 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 10), align 8, !dbg !3964
  %165 = load double, ptr %11, align 8, !dbg !3965
  %166 = load double, ptr getelementptr inbounds ([16 x double], ptr @__kernel_tan.xxx, i64 0, i64 12), align 8, !dbg !3966
  %167 = call double @llvm.fmuladd.f64(double %165, double %166, double %164), !dbg !3967
  %168 = call double @llvm.fmuladd.f64(double %163, double %167, double %162), !dbg !3968
  %169 = call double @llvm.fmuladd.f64(double %161, double %168, double %160), !dbg !3969
  %170 = call double @llvm.fmuladd.f64(double %159, double %169, double %158), !dbg !3970
  %171 = call double @llvm.fmuladd.f64(double %157, double %170, double %156), !dbg !3971
  %172 = fmul double %155, %171, !dbg !3972
  store double %172, ptr %10, align 8, !dbg !3973
  %173 = load double, ptr %8, align 8, !dbg !3974
  %174 = load double, ptr %5, align 8, !dbg !3975
  %175 = fmul double %173, %174, !dbg !3976
  store double %175, ptr %12, align 8, !dbg !3977
  %176 = load double, ptr %6, align 8, !dbg !3978
  %177 = load double, ptr %8, align 8, !dbg !3979
  %178 = load double, ptr %12, align 8, !dbg !3980
  %179 = load double, ptr %9, align 8, !dbg !3981
  %180 = load double, ptr %10, align 8, !dbg !3982
  %181 = fadd double %179, %180, !dbg !3983
  %182 = load double, ptr %6, align 8, !dbg !3984
  %183 = call double @llvm.fmuladd.f64(double %178, double %181, double %182), !dbg !3985
  %184 = call double @llvm.fmuladd.f64(double %177, double %183, double %176), !dbg !3986
  store double %184, ptr %9, align 8, !dbg !3987
  %185 = load double, ptr @__kernel_tan.xxx, align 8, !dbg !3988
  %186 = load double, ptr %12, align 8, !dbg !3989
  %187 = load double, ptr %9, align 8, !dbg !3990
  %188 = call double @llvm.fmuladd.f64(double %185, double %186, double %187), !dbg !3990
  store double %188, ptr %9, align 8, !dbg !3990
  %189 = load double, ptr %5, align 8, !dbg !3991
  %190 = load double, ptr %9, align 8, !dbg !3992
  %191 = fadd double %189, %190, !dbg !3993
  store double %191, ptr %11, align 8, !dbg !3994
  %192 = load i32, ptr %13, align 4, !dbg !3995
  %193 = icmp sge i32 %192, 1072010280, !dbg !3997
  br i1 %193, label %194, label %216, !dbg !3998

194:                                              ; preds = %132
  %195 = load i32, ptr %7, align 4, !dbg !3999
  %196 = sitofp i32 %195 to double, !dbg !3999
  store double %196, ptr %10, align 8, !dbg !4001
  %197 = load i32, ptr %14, align 4, !dbg !4002
  %198 = ashr i32 %197, 30, !dbg !4003
  %199 = and i32 %198, 2, !dbg !4004
  %200 = sub nsw i32 1, %199, !dbg !4005
  %201 = sitofp i32 %200 to double, !dbg !4006
  %202 = load double, ptr %10, align 8, !dbg !4007
  %203 = load double, ptr %5, align 8, !dbg !4008
  %204 = load double, ptr %11, align 8, !dbg !4009
  %205 = load double, ptr %11, align 8, !dbg !4010
  %206 = fmul double %204, %205, !dbg !4011
  %207 = load double, ptr %11, align 8, !dbg !4012
  %208 = load double, ptr %10, align 8, !dbg !4013
  %209 = fadd double %207, %208, !dbg !4014
  %210 = fdiv double %206, %209, !dbg !4015
  %211 = load double, ptr %9, align 8, !dbg !4016
  %212 = fsub double %210, %211, !dbg !4017
  %213 = fsub double %203, %212, !dbg !4018
  %214 = call double @llvm.fmuladd.f64(double -2.000000e+00, double %213, double %202), !dbg !4019
  %215 = fmul double %201, %214, !dbg !4020
  store double %215, ptr %4, align 8, !dbg !4021
  br label %260, !dbg !4021

216:                                              ; preds = %132
  %217 = load i32, ptr %7, align 4, !dbg !4022
  %218 = icmp eq i32 %217, 1, !dbg !4024
  br i1 %218, label %219, label %221, !dbg !4025

219:                                              ; preds = %216
  %220 = load double, ptr %11, align 8, !dbg !4026
  store double %220, ptr %4, align 8, !dbg !4028
  br label %260, !dbg !4028

221:                                              ; preds = %216
  call void @llvm.dbg.declare(metadata ptr %22, metadata !4029, metadata !DIExpression()), !dbg !4031
  call void @llvm.dbg.declare(metadata ptr %23, metadata !4032, metadata !DIExpression()), !dbg !4033
  %222 = load double, ptr %11, align 8, !dbg !4034
  store double %222, ptr %8, align 8, !dbg !4035
  br label %223, !dbg !4036

223:                                              ; preds = %221
  call void @llvm.dbg.declare(metadata ptr %24, metadata !4037, metadata !DIExpression()), !dbg !4039
  %224 = load double, ptr %8, align 8, !dbg !4039
  %225 = call i64 @bits_of(double noundef %224), !dbg !4039
  store i64 %225, ptr %24, align 8, !dbg !4039
  %226 = load i64, ptr %24, align 8, !dbg !4039
  %227 = and i64 %226, -4294967296, !dbg !4039
  store i64 %227, ptr %24, align 8, !dbg !4039
  %228 = load i64, ptr %24, align 8, !dbg !4039
  %229 = or i64 %228, 0, !dbg !4039
  store i64 %229, ptr %24, align 8, !dbg !4039
  %230 = load i64, ptr %24, align 8, !dbg !4039
  %231 = call double @double_of(i64 noundef %230), !dbg !4039
  store double %231, ptr %8, align 8, !dbg !4039
  br label %232, !dbg !4039

232:                                              ; preds = %223
  %233 = load double, ptr %9, align 8, !dbg !4040
  %234 = load double, ptr %8, align 8, !dbg !4041
  %235 = load double, ptr %5, align 8, !dbg !4042
  %236 = fsub double %234, %235, !dbg !4043
  %237 = fsub double %233, %236, !dbg !4044
  store double %237, ptr %10, align 8, !dbg !4045
  %238 = load double, ptr %11, align 8, !dbg !4046
  %239 = fdiv double -1.000000e+00, %238, !dbg !4047
  store double %239, ptr %22, align 8, !dbg !4048
  store double %239, ptr %23, align 8, !dbg !4049
  br label %240, !dbg !4050

240:                                              ; preds = %232
  call void @llvm.dbg.declare(metadata ptr %25, metadata !4051, metadata !DIExpression()), !dbg !4053
  %241 = load double, ptr %23, align 8, !dbg !4053
  %242 = call i64 @bits_of(double noundef %241), !dbg !4053
  store i64 %242, ptr %25, align 8, !dbg !4053
  %243 = load i64, ptr %25, align 8, !dbg !4053
  %244 = and i64 %243, -4294967296, !dbg !4053
  store i64 %244, ptr %25, align 8, !dbg !4053
  %245 = load i64, ptr %25, align 8, !dbg !4053
  %246 = or i64 %245, 0, !dbg !4053
  store i64 %246, ptr %25, align 8, !dbg !4053
  %247 = load i64, ptr %25, align 8, !dbg !4053
  %248 = call double @double_of(i64 noundef %247), !dbg !4053
  store double %248, ptr %23, align 8, !dbg !4053
  br label %249, !dbg !4053

249:                                              ; preds = %240
  %250 = load double, ptr %23, align 8, !dbg !4054
  %251 = load double, ptr %8, align 8, !dbg !4055
  %252 = call double @llvm.fmuladd.f64(double %250, double %251, double 1.000000e+00), !dbg !4056
  store double %252, ptr %12, align 8, !dbg !4057
  %253 = load double, ptr %23, align 8, !dbg !4058
  %254 = load double, ptr %22, align 8, !dbg !4059
  %255 = load double, ptr %12, align 8, !dbg !4060
  %256 = load double, ptr %23, align 8, !dbg !4061
  %257 = load double, ptr %10, align 8, !dbg !4062
  %258 = call double @llvm.fmuladd.f64(double %256, double %257, double %255), !dbg !4063
  %259 = call double @llvm.fmuladd.f64(double %254, double %258, double %253), !dbg !4064
  store double %259, ptr %4, align 8, !dbg !4065
  br label %260, !dbg !4065

260:                                              ; preds = %249, %219, %194, %98, %64, %56
  %261 = load double, ptr %4, align 8, !dbg !4066
  ret double %261, !dbg !4066
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_cosh(double noundef %0) #0 !dbg !271 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca i32, align 4
  %5 = alloca i64, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  %9 = alloca double, align 8
  %10 = alloca double, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !4067, metadata !DIExpression()), !dbg !4068
  call void @llvm.dbg.declare(metadata ptr %4, metadata !4069, metadata !DIExpression()), !dbg !4070
  br label %11, !dbg !4071

11:                                               ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %5, metadata !4072, metadata !DIExpression()), !dbg !4074
  %12 = load double, ptr %3, align 8, !dbg !4074
  %13 = call i64 @bits_of(double noundef %12), !dbg !4074
  store i64 %13, ptr %5, align 8, !dbg !4074
  %14 = load i64, ptr %5, align 8, !dbg !4074
  %15 = lshr i64 %14, 32, !dbg !4074
  %16 = trunc i64 %15 to i32, !dbg !4074
  store i32 %16, ptr %4, align 4, !dbg !4074
  br label %17, !dbg !4074

17:                                               ; preds = %11
  %18 = load i32, ptr %4, align 4, !dbg !4075
  %19 = and i32 %18, 2147483647, !dbg !4075
  store i32 %19, ptr %4, align 4, !dbg !4075
  %20 = load i32, ptr %4, align 4, !dbg !4076
  %21 = icmp slt i32 %20, 1071001155, !dbg !4078
  br i1 %21, label %22, label %41, !dbg !4079

22:                                               ; preds = %17
  call void @llvm.dbg.declare(metadata ptr %6, metadata !4080, metadata !DIExpression()), !dbg !4082
  %23 = load double, ptr %3, align 8, !dbg !4083
  %24 = call double @llvm.fabs.f64(double %23), !dbg !4084
  %25 = call double @pts_ieee754_expm1(double noundef %24), !dbg !4085
  store double %25, ptr %6, align 8, !dbg !4082
  call void @llvm.dbg.declare(metadata ptr %7, metadata !4086, metadata !DIExpression()), !dbg !4087
  %26 = load double, ptr %6, align 8, !dbg !4088
  %27 = fadd double 1.000000e+00, %26, !dbg !4089
  store double %27, ptr %7, align 8, !dbg !4087
  %28 = load i32, ptr %4, align 4, !dbg !4090
  %29 = icmp slt i32 %28, 1015021568, !dbg !4092
  br i1 %29, label %30, label %32, !dbg !4093

30:                                               ; preds = %22
  %31 = load double, ptr %7, align 8, !dbg !4094
  store double %31, ptr %2, align 8, !dbg !4095
  br label %85, !dbg !4095

32:                                               ; preds = %22
  %33 = load double, ptr %6, align 8, !dbg !4096
  %34 = load double, ptr %6, align 8, !dbg !4097
  %35 = fmul double %33, %34, !dbg !4098
  %36 = load double, ptr %7, align 8, !dbg !4099
  %37 = load double, ptr %7, align 8, !dbg !4100
  %38 = fadd double %36, %37, !dbg !4101
  %39 = fdiv double %35, %38, !dbg !4102
  %40 = fadd double 1.000000e+00, %39, !dbg !4103
  store double %40, ptr %2, align 8, !dbg !4104
  br label %85, !dbg !4104

41:                                               ; preds = %17
  %42 = load i32, ptr %4, align 4, !dbg !4105
  %43 = icmp slt i32 %42, 1077280768, !dbg !4107
  br i1 %43, label %44, label %52, !dbg !4108

44:                                               ; preds = %41
  call void @llvm.dbg.declare(metadata ptr %8, metadata !4109, metadata !DIExpression()), !dbg !4111
  %45 = load double, ptr %3, align 8, !dbg !4112
  %46 = call double @llvm.fabs.f64(double %45), !dbg !4113
  %47 = call double @pts_ieee754_exp(double noundef %46), !dbg !4114
  store double %47, ptr %8, align 8, !dbg !4111
  %48 = load double, ptr %8, align 8, !dbg !4115
  %49 = load double, ptr %8, align 8, !dbg !4116
  %50 = fdiv double 5.000000e-01, %49, !dbg !4117
  %51 = call double @llvm.fmuladd.f64(double 5.000000e-01, double %48, double %50), !dbg !4118
  store double %51, ptr %2, align 8, !dbg !4119
  br label %85, !dbg !4119

52:                                               ; preds = %41
  %53 = load i32, ptr %4, align 4, !dbg !4120
  %54 = icmp slt i32 %53, 1082535490, !dbg !4122
  br i1 %54, label %55, label %60, !dbg !4123

55:                                               ; preds = %52
  %56 = load double, ptr %3, align 8, !dbg !4124
  %57 = call double @llvm.fabs.f64(double %56), !dbg !4125
  %58 = call double @pts_ieee754_exp(double noundef %57), !dbg !4126
  %59 = fmul double 5.000000e-01, %58, !dbg !4127
  store double %59, ptr %2, align 8, !dbg !4128
  br label %85, !dbg !4128

60:                                               ; preds = %52
  %61 = load double, ptr %3, align 8, !dbg !4129
  %62 = call double @llvm.fabs.f64(double %61), !dbg !4131
  %63 = fcmp ole double %62, 0x408633CE8FB9F87D, !dbg !4132
  br i1 %63, label %64, label %74, !dbg !4133

64:                                               ; preds = %60
  call void @llvm.dbg.declare(metadata ptr %9, metadata !4134, metadata !DIExpression()), !dbg !4136
  %65 = load double, ptr %3, align 8, !dbg !4137
  %66 = call double @llvm.fabs.f64(double %65), !dbg !4138
  %67 = fmul double 5.000000e-01, %66, !dbg !4139
  %68 = call double @pts_ieee754_exp(double noundef %67), !dbg !4140
  store double %68, ptr %9, align 8, !dbg !4136
  call void @llvm.dbg.declare(metadata ptr %10, metadata !4141, metadata !DIExpression()), !dbg !4142
  %69 = load double, ptr %9, align 8, !dbg !4143
  %70 = fmul double 5.000000e-01, %69, !dbg !4144
  store double %70, ptr %10, align 8, !dbg !4142
  %71 = load double, ptr %10, align 8, !dbg !4145
  %72 = load double, ptr %9, align 8, !dbg !4146
  %73 = fmul double %71, %72, !dbg !4147
  store double %73, ptr %2, align 8, !dbg !4148
  br label %85, !dbg !4148

74:                                               ; preds = %60
  %75 = load i32, ptr %4, align 4, !dbg !4149
  %76 = icmp sge i32 %75, 2146435072, !dbg !4151
  br i1 %76, label %77, label %81, !dbg !4152

77:                                               ; preds = %74
  %78 = load double, ptr %3, align 8, !dbg !4153
  %79 = load double, ptr %3, align 8, !dbg !4154
  %80 = fmul double %78, %79, !dbg !4155
  store double %80, ptr %2, align 8, !dbg !4156
  br label %85, !dbg !4156

81:                                               ; preds = %74
  %82 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !4157
  %83 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !4158
  %84 = fmul double %82, %83, !dbg !4159
  store double %84, ptr %2, align 8, !dbg !4160
  br label %85, !dbg !4160

85:                                               ; preds = %81, %77, %64, %55, %44, %32, %30
  %86 = load double, ptr %2, align 8, !dbg !4161
  ret double %86, !dbg !4161
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_sinh(double noundef %0) #0 !dbg !280 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca double, align 8
  %7 = alloca double, align 8
  %8 = alloca double, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !4162, metadata !DIExpression()), !dbg !4163
  call void @llvm.dbg.declare(metadata ptr %4, metadata !4164, metadata !DIExpression()), !dbg !4165
  %9 = load double, ptr %3, align 8, !dbg !4166
  %10 = fcmp olt double %9, 0.000000e+00, !dbg !4167
  %11 = zext i1 %10 to i64, !dbg !4168
  %12 = select i1 %10, double -5.000000e-01, double 5.000000e-01, !dbg !4168
  store double %12, ptr %4, align 8, !dbg !4165
  call void @llvm.dbg.declare(metadata ptr %5, metadata !4169, metadata !DIExpression()), !dbg !4170
  %13 = load double, ptr %3, align 8, !dbg !4171
  %14 = call double @llvm.fabs.f64(double %13), !dbg !4172
  store double %14, ptr %5, align 8, !dbg !4170
  %15 = load double, ptr %5, align 8, !dbg !4173
  %16 = fcmp olt double %15, 2.200000e+01, !dbg !4175
  br i1 %16, label %17, label %48, !dbg !4176

17:                                               ; preds = %1
  %18 = load double, ptr %5, align 8, !dbg !4177
  %19 = fcmp olt double %18, 0x3E30000000000000, !dbg !4180
  br i1 %19, label %20, label %22, !dbg !4181

20:                                               ; preds = %17
  %21 = load double, ptr %3, align 8, !dbg !4182
  store double %21, ptr %2, align 8, !dbg !4183
  br label %72, !dbg !4183

22:                                               ; preds = %17
  call void @llvm.dbg.declare(metadata ptr %6, metadata !4184, metadata !DIExpression()), !dbg !4185
  %23 = load double, ptr %5, align 8, !dbg !4186
  %24 = call double @pts_ieee754_expm1(double noundef %23), !dbg !4187
  store double %24, ptr %6, align 8, !dbg !4185
  %25 = load double, ptr %5, align 8, !dbg !4188
  %26 = fcmp olt double %25, 1.000000e+00, !dbg !4190
  br i1 %26, label %27, label %39, !dbg !4191

27:                                               ; preds = %22
  %28 = load double, ptr %4, align 8, !dbg !4192
  %29 = load double, ptr %6, align 8, !dbg !4194
  %30 = load double, ptr %6, align 8, !dbg !4195
  %31 = load double, ptr %6, align 8, !dbg !4196
  %32 = fmul double %30, %31, !dbg !4197
  %33 = load double, ptr %6, align 8, !dbg !4198
  %34 = fadd double %33, 1.000000e+00, !dbg !4199
  %35 = fdiv double %32, %34, !dbg !4200
  %36 = fneg double %35, !dbg !4201
  %37 = call double @llvm.fmuladd.f64(double 2.000000e+00, double %29, double %36), !dbg !4201
  %38 = fmul double %28, %37, !dbg !4202
  store double %38, ptr %2, align 8, !dbg !4203
  br label %72, !dbg !4203

39:                                               ; preds = %22
  %40 = load double, ptr %4, align 8, !dbg !4204
  %41 = load double, ptr %6, align 8, !dbg !4205
  %42 = load double, ptr %6, align 8, !dbg !4206
  %43 = load double, ptr %6, align 8, !dbg !4207
  %44 = fadd double %43, 1.000000e+00, !dbg !4208
  %45 = fdiv double %42, %44, !dbg !4209
  %46 = fadd double %41, %45, !dbg !4210
  %47 = fmul double %40, %46, !dbg !4211
  store double %47, ptr %2, align 8, !dbg !4212
  br label %72, !dbg !4212

48:                                               ; preds = %1
  %49 = load double, ptr %5, align 8, !dbg !4213
  %50 = fcmp olt double %49, 0x40862E4200000000, !dbg !4215
  br i1 %50, label %51, label %56, !dbg !4216

51:                                               ; preds = %48
  %52 = load double, ptr %4, align 8, !dbg !4217
  %53 = load double, ptr %5, align 8, !dbg !4218
  %54 = call double @pts_ieee754_exp(double noundef %53), !dbg !4219
  %55 = fmul double %52, %54, !dbg !4220
  store double %55, ptr %2, align 8, !dbg !4221
  br label %72, !dbg !4221

56:                                               ; preds = %48
  %57 = load double, ptr %5, align 8, !dbg !4222
  %58 = fcmp ole double %57, 0x408633CE8FB9F87D, !dbg !4224
  br i1 %58, label %59, label %69, !dbg !4225

59:                                               ; preds = %56
  call void @llvm.dbg.declare(metadata ptr %7, metadata !4226, metadata !DIExpression()), !dbg !4228
  %60 = load double, ptr %5, align 8, !dbg !4229
  %61 = fmul double 5.000000e-01, %60, !dbg !4230
  %62 = call double @pts_ieee754_exp(double noundef %61), !dbg !4231
  store double %62, ptr %7, align 8, !dbg !4228
  call void @llvm.dbg.declare(metadata ptr %8, metadata !4232, metadata !DIExpression()), !dbg !4233
  %63 = load double, ptr %4, align 8, !dbg !4234
  %64 = load double, ptr %7, align 8, !dbg !4235
  %65 = fmul double %63, %64, !dbg !4236
  store double %65, ptr %8, align 8, !dbg !4233
  %66 = load double, ptr %8, align 8, !dbg !4237
  %67 = load double, ptr %7, align 8, !dbg !4238
  %68 = fmul double %66, %67, !dbg !4239
  store double %68, ptr %2, align 8, !dbg !4240
  br label %72, !dbg !4240

69:                                               ; preds = %56
  %70 = load double, ptr %3, align 8, !dbg !4241
  %71 = fmul double %70, 0x7FAC7B1F3CAC7433, !dbg !4242
  store double %71, ptr %2, align 8, !dbg !4243
  br label %72, !dbg !4243

72:                                               ; preds = %69, %59, %51, %39, %27, %20
  %73 = load double, ptr %2, align 8, !dbg !4244
  ret double %73, !dbg !4244
}

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define double @pts_ieee754_tanh(double noundef %0) #0 !dbg !289 {
  %2 = alloca double, align 8
  %3 = alloca double, align 8
  %4 = alloca double, align 8
  %5 = alloca double, align 8
  %6 = alloca i32, align 4
  %7 = alloca i32, align 4
  %8 = alloca i64, align 8
  store double %0, ptr %3, align 8
  call void @llvm.dbg.declare(metadata ptr %3, metadata !4245, metadata !DIExpression()), !dbg !4246
  call void @llvm.dbg.declare(metadata ptr %4, metadata !4247, metadata !DIExpression()), !dbg !4248
  call void @llvm.dbg.declare(metadata ptr %5, metadata !4249, metadata !DIExpression()), !dbg !4250
  call void @llvm.dbg.declare(metadata ptr %6, metadata !4251, metadata !DIExpression()), !dbg !4252
  call void @llvm.dbg.declare(metadata ptr %7, metadata !4253, metadata !DIExpression()), !dbg !4254
  br label %9, !dbg !4255

9:                                                ; preds = %1
  call void @llvm.dbg.declare(metadata ptr %8, metadata !4256, metadata !DIExpression()), !dbg !4258
  %10 = load double, ptr %3, align 8, !dbg !4258
  %11 = call i64 @bits_of(double noundef %10), !dbg !4258
  store i64 %11, ptr %8, align 8, !dbg !4258
  %12 = load i64, ptr %8, align 8, !dbg !4258
  %13 = lshr i64 %12, 32, !dbg !4258
  %14 = trunc i64 %13 to i32, !dbg !4258
  store i32 %14, ptr %6, align 4, !dbg !4258
  br label %15, !dbg !4258

15:                                               ; preds = %9
  %16 = load i32, ptr %6, align 4, !dbg !4259
  %17 = and i32 %16, 2147483647, !dbg !4260
  store i32 %17, ptr %7, align 4, !dbg !4261
  %18 = load i32, ptr %7, align 4, !dbg !4262
  %19 = icmp sge i32 %18, 2146435072, !dbg !4264
  br i1 %19, label %20, label %31, !dbg !4265

20:                                               ; preds = %15
  %21 = load i32, ptr %6, align 4, !dbg !4266
  %22 = icmp sge i32 %21, 0, !dbg !4269
  br i1 %22, label %23, label %27, !dbg !4270

23:                                               ; preds = %20
  %24 = load double, ptr %3, align 8, !dbg !4271
  %25 = fdiv double 1.000000e+00, %24, !dbg !4272
  %26 = fadd double %25, 1.000000e+00, !dbg !4273
  store double %26, ptr %2, align 8, !dbg !4274
  br label %80, !dbg !4274

27:                                               ; preds = %20
  %28 = load double, ptr %3, align 8, !dbg !4275
  %29 = fdiv double 1.000000e+00, %28, !dbg !4276
  %30 = fsub double %29, 1.000000e+00, !dbg !4277
  store double %30, ptr %2, align 8, !dbg !4278
  br label %80, !dbg !4278

31:                                               ; preds = %15
  %32 = load i32, ptr %7, align 4, !dbg !4279
  %33 = icmp slt i32 %32, 1077280768, !dbg !4281
  br i1 %33, label %34, label %67, !dbg !4282

34:                                               ; preds = %31
  %35 = load i32, ptr %7, align 4, !dbg !4283
  %36 = icmp slt i32 %35, 1043333120, !dbg !4286
  br i1 %36, label %37, label %44, !dbg !4287

37:                                               ; preds = %34
  %38 = load double, ptr %3, align 8, !dbg !4288
  %39 = fadd double 1.000000e+300, %38, !dbg !4291
  %40 = fcmp ogt double %39, 1.000000e+00, !dbg !4292
  br i1 %40, label %41, label %43, !dbg !4293

41:                                               ; preds = %37
  %42 = load double, ptr %3, align 8, !dbg !4294
  store double %42, ptr %2, align 8, !dbg !4295
  br label %80, !dbg !4295

43:                                               ; preds = %37
  br label %44, !dbg !4296

44:                                               ; preds = %43, %34
  %45 = load i32, ptr %7, align 4, !dbg !4297
  %46 = icmp sge i32 %45, 1072693248, !dbg !4299
  br i1 %46, label %47, label %56, !dbg !4300

47:                                               ; preds = %44
  %48 = load double, ptr %3, align 8, !dbg !4301
  %49 = call double @llvm.fabs.f64(double %48), !dbg !4303
  %50 = fmul double 2.000000e+00, %49, !dbg !4304
  %51 = call double @pts_ieee754_expm1(double noundef %50), !dbg !4305
  store double %51, ptr %4, align 8, !dbg !4306
  %52 = load double, ptr %4, align 8, !dbg !4307
  %53 = fadd double %52, 2.000000e+00, !dbg !4308
  %54 = fdiv double 2.000000e+00, %53, !dbg !4309
  %55 = fsub double 1.000000e+00, %54, !dbg !4310
  store double %55, ptr %5, align 8, !dbg !4311
  br label %66, !dbg !4312

56:                                               ; preds = %44
  %57 = load double, ptr %3, align 8, !dbg !4313
  %58 = call double @llvm.fabs.f64(double %57), !dbg !4315
  %59 = fmul double -2.000000e+00, %58, !dbg !4316
  %60 = call double @pts_ieee754_expm1(double noundef %59), !dbg !4317
  store double %60, ptr %4, align 8, !dbg !4318
  %61 = load double, ptr %4, align 8, !dbg !4319
  %62 = fneg double %61, !dbg !4320
  %63 = load double, ptr %4, align 8, !dbg !4321
  %64 = fadd double %63, 2.000000e+00, !dbg !4322
  %65 = fdiv double %62, %64, !dbg !4323
  store double %65, ptr %5, align 8, !dbg !4324
  br label %66

66:                                               ; preds = %56, %47
  br label %70, !dbg !4325

67:                                               ; preds = %31
  %68 = load volatile double, ptr @pts_ieee754_tanh.tiny, align 8, !dbg !4326
  %69 = fsub double 1.000000e+00, %68, !dbg !4328
  store double %69, ptr %5, align 8, !dbg !4329
  br label %70

70:                                               ; preds = %67, %66
  %71 = load i32, ptr %6, align 4, !dbg !4330
  %72 = icmp sge i32 %71, 0, !dbg !4331
  br i1 %72, label %73, label %75, !dbg !4332

73:                                               ; preds = %70
  %74 = load double, ptr %5, align 8, !dbg !4333
  br label %78, !dbg !4332

75:                                               ; preds = %70
  %76 = load double, ptr %5, align 8, !dbg !4334
  %77 = fneg double %76, !dbg !4335
  br label %78, !dbg !4332

78:                                               ; preds = %75, %73
  %79 = phi double [ %74, %73 ], [ %77, %75 ], !dbg !4332
  store double %79, ptr %2, align 8, !dbg !4336
  br label %80, !dbg !4336

80:                                               ; preds = %78, %41, %27, %23
  %81 = load double, ptr %2, align 8, !dbg !4337
  ret double %81, !dbg !4337
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #2

; Function Attrs: noinline nounwind optnone ssp uwtable(sync)
define internal i32 @__kernel_rem_pio2(ptr noundef %0, ptr noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, ptr noundef %5) #0 !dbg !348 {
  %7 = alloca ptr, align 8
  %8 = alloca ptr, align 8
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca ptr, align 8
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 4
  %20 = alloca [20 x i32], align 4
  %21 = alloca i32, align 4
  %22 = alloca i32, align 4
  %23 = alloca i32, align 4
  %24 = alloca i32, align 4
  %25 = alloca i32, align 4
  %26 = alloca i32, align 4
  %27 = alloca double, align 8
  %28 = alloca double, align 8
  %29 = alloca [20 x double], align 8
  %30 = alloca [20 x double], align 8
  %31 = alloca [20 x double], align 8
  store ptr %0, ptr %7, align 8
  call void @llvm.dbg.declare(metadata ptr %7, metadata !4338, metadata !DIExpression()), !dbg !4339
  store ptr %1, ptr %8, align 8
  call void @llvm.dbg.declare(metadata ptr %8, metadata !4340, metadata !DIExpression()), !dbg !4341
  store i32 %2, ptr %9, align 4
  call void @llvm.dbg.declare(metadata ptr %9, metadata !4342, metadata !DIExpression()), !dbg !4343
  store i32 %3, ptr %10, align 4
  call void @llvm.dbg.declare(metadata ptr %10, metadata !4344, metadata !DIExpression()), !dbg !4345
  store i32 %4, ptr %11, align 4
  call void @llvm.dbg.declare(metadata ptr %11, metadata !4346, metadata !DIExpression()), !dbg !4347
  store ptr %5, ptr %12, align 8
  call void @llvm.dbg.declare(metadata ptr %12, metadata !4348, metadata !DIExpression()), !dbg !4349
  call void @llvm.dbg.declare(metadata ptr %13, metadata !4350, metadata !DIExpression()), !dbg !4351
  call void @llvm.dbg.declare(metadata ptr %14, metadata !4352, metadata !DIExpression()), !dbg !4353
  call void @llvm.dbg.declare(metadata ptr %15, metadata !4354, metadata !DIExpression()), !dbg !4355
  call void @llvm.dbg.declare(metadata ptr %16, metadata !4356, metadata !DIExpression()), !dbg !4357
  call void @llvm.dbg.declare(metadata ptr %17, metadata !4358, metadata !DIExpression()), !dbg !4359
  call void @llvm.dbg.declare(metadata ptr %18, metadata !4360, metadata !DIExpression()), !dbg !4361
  call void @llvm.dbg.declare(metadata ptr %19, metadata !4362, metadata !DIExpression()), !dbg !4363
  call void @llvm.dbg.declare(metadata ptr %20, metadata !4364, metadata !DIExpression()), !dbg !4368
  call void @llvm.dbg.declare(metadata ptr %21, metadata !4369, metadata !DIExpression()), !dbg !4370
  call void @llvm.dbg.declare(metadata ptr %22, metadata !4371, metadata !DIExpression()), !dbg !4372
  call void @llvm.dbg.declare(metadata ptr %23, metadata !4373, metadata !DIExpression()), !dbg !4374
  call void @llvm.dbg.declare(metadata ptr %24, metadata !4375, metadata !DIExpression()), !dbg !4376
  call void @llvm.dbg.declare(metadata ptr %25, metadata !4377, metadata !DIExpression()), !dbg !4378
  call void @llvm.dbg.declare(metadata ptr %26, metadata !4379, metadata !DIExpression()), !dbg !4380
  call void @llvm.dbg.declare(metadata ptr %27, metadata !4381, metadata !DIExpression()), !dbg !4382
  call void @llvm.dbg.declare(metadata ptr %28, metadata !4383, metadata !DIExpression()), !dbg !4384
  call void @llvm.dbg.declare(metadata ptr %29, metadata !4385, metadata !DIExpression()), !dbg !4387
  call void @llvm.dbg.declare(metadata ptr %30, metadata !4388, metadata !DIExpression()), !dbg !4389
  call void @llvm.dbg.declare(metadata ptr %31, metadata !4390, metadata !DIExpression()), !dbg !4391
  %32 = load i32, ptr %11, align 4, !dbg !4392
  %33 = sext i32 %32 to i64, !dbg !4393
  %34 = getelementptr inbounds [4 x i32], ptr @__kernel_rem_pio2.init_jk, i64 0, i64 %33, !dbg !4393
  %35 = load i32, ptr %34, align 4, !dbg !4393
  store i32 %35, ptr %17, align 4, !dbg !4394
  %36 = load i32, ptr %17, align 4, !dbg !4395
  store i32 %36, ptr %16, align 4, !dbg !4396
  %37 = load i32, ptr %10, align 4, !dbg !4397
  %38 = sub nsw i32 %37, 1, !dbg !4398
  store i32 %38, ptr %14, align 4, !dbg !4399
  %39 = load i32, ptr %9, align 4, !dbg !4400
  %40 = sub nsw i32 %39, 3, !dbg !4401
  %41 = sdiv i32 %40, 24, !dbg !4402
  store i32 %41, ptr %15, align 4, !dbg !4403
  %42 = load i32, ptr %15, align 4, !dbg !4404
  %43 = icmp slt i32 %42, 0, !dbg !4406
  br i1 %43, label %44, label %45, !dbg !4407

44:                                               ; preds = %6
  store i32 0, ptr %15, align 4, !dbg !4408
  br label %45, !dbg !4409

45:                                               ; preds = %44, %6
  %46 = load i32, ptr %9, align 4, !dbg !4410
  %47 = load i32, ptr %15, align 4, !dbg !4411
  %48 = add nsw i32 %47, 1, !dbg !4412
  %49 = mul nsw i32 24, %48, !dbg !4413
  %50 = sub nsw i32 %46, %49, !dbg !4414
  store i32 %50, ptr %25, align 4, !dbg !4415
  %51 = load i32, ptr %15, align 4, !dbg !4416
  %52 = load i32, ptr %14, align 4, !dbg !4417
  %53 = sub nsw i32 %51, %52, !dbg !4418
  store i32 %53, ptr %22, align 4, !dbg !4419
  %54 = load i32, ptr %14, align 4, !dbg !4420
  %55 = load i32, ptr %17, align 4, !dbg !4421
  %56 = add nsw i32 %54, %55, !dbg !4422
  store i32 %56, ptr %24, align 4, !dbg !4423
  store i32 0, ptr %21, align 4, !dbg !4424
  br label %57, !dbg !4426

57:                                               ; preds = %77, %45
  %58 = load i32, ptr %21, align 4, !dbg !4427
  %59 = load i32, ptr %24, align 4, !dbg !4429
  %60 = icmp sle i32 %58, %59, !dbg !4430
  br i1 %60, label %61, label %82, !dbg !4431

61:                                               ; preds = %57
  %62 = load i32, ptr %22, align 4, !dbg !4432
  %63 = icmp slt i32 %62, 0, !dbg !4434
  br i1 %63, label %64, label %65, !dbg !4435

64:                                               ; preds = %61
  br label %72, !dbg !4435

65:                                               ; preds = %61
  %66 = load ptr, ptr %12, align 8, !dbg !4436
  %67 = load i32, ptr %22, align 4, !dbg !4437
  %68 = sext i32 %67 to i64, !dbg !4436
  %69 = getelementptr inbounds i32, ptr %66, i64 %68, !dbg !4436
  %70 = load i32, ptr %69, align 4, !dbg !4436
  %71 = sitofp i32 %70 to double, !dbg !4438
  br label %72, !dbg !4435

72:                                               ; preds = %65, %64
  %73 = phi double [ 0.000000e+00, %64 ], [ %71, %65 ], !dbg !4435
  %74 = load i32, ptr %21, align 4, !dbg !4439
  %75 = sext i32 %74 to i64, !dbg !4440
  %76 = getelementptr inbounds [20 x double], ptr %29, i64 0, i64 %75, !dbg !4440
  store double %73, ptr %76, align 8, !dbg !4441
  br label %77, !dbg !4442

77:                                               ; preds = %72
  %78 = load i32, ptr %21, align 4, !dbg !4443
  %79 = add nsw i32 %78, 1, !dbg !4443
  store i32 %79, ptr %21, align 4, !dbg !4443
  %80 = load i32, ptr %22, align 4, !dbg !4444
  %81 = add nsw i32 %80, 1, !dbg !4444
  store i32 %81, ptr %22, align 4, !dbg !4444
  br label %57, !dbg !4445, !llvm.loop !4446

82:                                               ; preds = %57
  store i32 0, ptr %21, align 4, !dbg !4448
  br label %83, !dbg !4450

83:                                               ; preds = %116, %82
  %84 = load i32, ptr %21, align 4, !dbg !4451
  %85 = load i32, ptr %17, align 4, !dbg !4453
  %86 = icmp sle i32 %84, %85, !dbg !4454
  br i1 %86, label %87, label %119, !dbg !4455

87:                                               ; preds = %83
  store i32 0, ptr %22, align 4, !dbg !4456
  store double 0.000000e+00, ptr %28, align 8, !dbg !4459
  br label %88, !dbg !4460

88:                                               ; preds = %108, %87
  %89 = load i32, ptr %22, align 4, !dbg !4461
  %90 = load i32, ptr %14, align 4, !dbg !4463
  %91 = icmp sle i32 %89, %90, !dbg !4464
  br i1 %91, label %92, label %111, !dbg !4465

92:                                               ; preds = %88
  %93 = load ptr, ptr %7, align 8, !dbg !4466
  %94 = load i32, ptr %22, align 4, !dbg !4467
  %95 = sext i32 %94 to i64, !dbg !4466
  %96 = getelementptr inbounds double, ptr %93, i64 %95, !dbg !4466
  %97 = load double, ptr %96, align 8, !dbg !4466
  %98 = load i32, ptr %14, align 4, !dbg !4468
  %99 = load i32, ptr %21, align 4, !dbg !4469
  %100 = add nsw i32 %98, %99, !dbg !4470
  %101 = load i32, ptr %22, align 4, !dbg !4471
  %102 = sub nsw i32 %100, %101, !dbg !4472
  %103 = sext i32 %102 to i64, !dbg !4473
  %104 = getelementptr inbounds [20 x double], ptr %29, i64 0, i64 %103, !dbg !4473
  %105 = load double, ptr %104, align 8, !dbg !4473
  %106 = load double, ptr %28, align 8, !dbg !4474
  %107 = call double @llvm.fmuladd.f64(double %97, double %105, double %106), !dbg !4474
  store double %107, ptr %28, align 8, !dbg !4474
  br label %108, !dbg !4475

108:                                              ; preds = %92
  %109 = load i32, ptr %22, align 4, !dbg !4476
  %110 = add nsw i32 %109, 1, !dbg !4476
  store i32 %110, ptr %22, align 4, !dbg !4476
  br label %88, !dbg !4477, !llvm.loop !4478

111:                                              ; preds = %88
  %112 = load double, ptr %28, align 8, !dbg !4480
  %113 = load i32, ptr %21, align 4, !dbg !4481
  %114 = sext i32 %113 to i64, !dbg !4482
  %115 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %114, !dbg !4482
  store double %112, ptr %115, align 8, !dbg !4483
  br label %116, !dbg !4484

116:                                              ; preds = %111
  %117 = load i32, ptr %21, align 4, !dbg !4485
  %118 = add nsw i32 %117, 1, !dbg !4485
  store i32 %118, ptr %21, align 4, !dbg !4485
  br label %83, !dbg !4486, !llvm.loop !4487

119:                                              ; preds = %83
  %120 = load i32, ptr %17, align 4, !dbg !4489
  store i32 %120, ptr %13, align 4, !dbg !4490
  br label %121, !dbg !4491

121:                                              ; preds = %385, %119
  call void @llvm.dbg.label(metadata !4492), !dbg !4493
  store i32 0, ptr %21, align 4, !dbg !4494
  %122 = load i32, ptr %13, align 4, !dbg !4496
  store i32 %122, ptr %22, align 4, !dbg !4497
  %123 = load i32, ptr %13, align 4, !dbg !4498
  %124 = sext i32 %123 to i64, !dbg !4499
  %125 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %124, !dbg !4499
  %126 = load double, ptr %125, align 8, !dbg !4499
  store double %126, ptr %27, align 8, !dbg !4500
  br label %127, !dbg !4501

127:                                              ; preds = %149, %121
  %128 = load i32, ptr %22, align 4, !dbg !4502
  %129 = icmp sgt i32 %128, 0, !dbg !4504
  br i1 %129, label %130, label %154, !dbg !4505

130:                                              ; preds = %127
  %131 = load double, ptr %27, align 8, !dbg !4506
  %132 = fmul double 0x3E70000000000000, %131, !dbg !4508
  %133 = fptosi double %132 to i32, !dbg !4509
  %134 = sitofp i32 %133 to double, !dbg !4510
  store double %134, ptr %28, align 8, !dbg !4511
  %135 = load double, ptr %27, align 8, !dbg !4512
  %136 = load double, ptr %28, align 8, !dbg !4513
  %137 = call double @llvm.fmuladd.f64(double 0xC170000000000000, double %136, double %135), !dbg !4514
  %138 = fptosi double %137 to i32, !dbg !4515
  %139 = load i32, ptr %21, align 4, !dbg !4516
  %140 = sext i32 %139 to i64, !dbg !4517
  %141 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %140, !dbg !4517
  store i32 %138, ptr %141, align 4, !dbg !4518
  %142 = load i32, ptr %22, align 4, !dbg !4519
  %143 = sub nsw i32 %142, 1, !dbg !4520
  %144 = sext i32 %143 to i64, !dbg !4521
  %145 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %144, !dbg !4521
  %146 = load double, ptr %145, align 8, !dbg !4521
  %147 = load double, ptr %28, align 8, !dbg !4522
  %148 = fadd double %146, %147, !dbg !4523
  store double %148, ptr %27, align 8, !dbg !4524
  br label %149, !dbg !4525

149:                                              ; preds = %130
  %150 = load i32, ptr %21, align 4, !dbg !4526
  %151 = add nsw i32 %150, 1, !dbg !4526
  store i32 %151, ptr %21, align 4, !dbg !4526
  %152 = load i32, ptr %22, align 4, !dbg !4527
  %153 = add nsw i32 %152, -1, !dbg !4527
  store i32 %153, ptr %22, align 4, !dbg !4527
  br label %127, !dbg !4528, !llvm.loop !4529

154:                                              ; preds = %127
  %155 = load double, ptr %27, align 8, !dbg !4531
  %156 = load i32, ptr %25, align 4, !dbg !4532
  %157 = call double @scalbn(double noundef %155, i32 noundef %156) #4, !dbg !4533
  store double %157, ptr %27, align 8, !dbg !4534
  %158 = load double, ptr %27, align 8, !dbg !4535
  %159 = fmul double %158, 1.250000e-01, !dbg !4536
  %160 = call double @llvm.floor.f64(double %159), !dbg !4537
  %161 = load double, ptr %27, align 8, !dbg !4538
  %162 = call double @llvm.fmuladd.f64(double -8.000000e+00, double %160, double %161), !dbg !4538
  store double %162, ptr %27, align 8, !dbg !4538
  %163 = load double, ptr %27, align 8, !dbg !4539
  %164 = fptosi double %163 to i32, !dbg !4540
  store i32 %164, ptr %19, align 4, !dbg !4541
  %165 = load i32, ptr %19, align 4, !dbg !4542
  %166 = sitofp i32 %165 to double, !dbg !4543
  %167 = load double, ptr %27, align 8, !dbg !4544
  %168 = fsub double %167, %166, !dbg !4544
  store double %168, ptr %27, align 8, !dbg !4544
  store i32 0, ptr %26, align 4, !dbg !4545
  %169 = load i32, ptr %25, align 4, !dbg !4546
  %170 = icmp sgt i32 %169, 0, !dbg !4548
  br i1 %170, label %171, label %201, !dbg !4549

171:                                              ; preds = %154
  %172 = load i32, ptr %13, align 4, !dbg !4550
  %173 = sub nsw i32 %172, 1, !dbg !4552
  %174 = sext i32 %173 to i64, !dbg !4553
  %175 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %174, !dbg !4553
  %176 = load i32, ptr %175, align 4, !dbg !4553
  %177 = load i32, ptr %25, align 4, !dbg !4554
  %178 = sub nsw i32 24, %177, !dbg !4555
  %179 = ashr i32 %176, %178, !dbg !4556
  store i32 %179, ptr %21, align 4, !dbg !4557
  %180 = load i32, ptr %21, align 4, !dbg !4558
  %181 = load i32, ptr %19, align 4, !dbg !4559
  %182 = add nsw i32 %181, %180, !dbg !4559
  store i32 %182, ptr %19, align 4, !dbg !4559
  %183 = load i32, ptr %21, align 4, !dbg !4560
  %184 = load i32, ptr %25, align 4, !dbg !4561
  %185 = sub nsw i32 24, %184, !dbg !4562
  %186 = shl i32 %183, %185, !dbg !4563
  %187 = load i32, ptr %13, align 4, !dbg !4564
  %188 = sub nsw i32 %187, 1, !dbg !4565
  %189 = sext i32 %188 to i64, !dbg !4566
  %190 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %189, !dbg !4566
  %191 = load i32, ptr %190, align 4, !dbg !4567
  %192 = sub nsw i32 %191, %186, !dbg !4567
  store i32 %192, ptr %190, align 4, !dbg !4567
  %193 = load i32, ptr %13, align 4, !dbg !4568
  %194 = sub nsw i32 %193, 1, !dbg !4569
  %195 = sext i32 %194 to i64, !dbg !4570
  %196 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %195, !dbg !4570
  %197 = load i32, ptr %196, align 4, !dbg !4570
  %198 = load i32, ptr %25, align 4, !dbg !4571
  %199 = sub nsw i32 23, %198, !dbg !4572
  %200 = ashr i32 %197, %199, !dbg !4573
  store i32 %200, ptr %26, align 4, !dbg !4574
  br label %217, !dbg !4575

201:                                              ; preds = %154
  %202 = load i32, ptr %25, align 4, !dbg !4576
  %203 = icmp eq i32 %202, 0, !dbg !4578
  br i1 %203, label %204, label %211, !dbg !4579

204:                                              ; preds = %201
  %205 = load i32, ptr %13, align 4, !dbg !4580
  %206 = sub nsw i32 %205, 1, !dbg !4582
  %207 = sext i32 %206 to i64, !dbg !4583
  %208 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %207, !dbg !4583
  %209 = load i32, ptr %208, align 4, !dbg !4583
  %210 = ashr i32 %209, 23, !dbg !4584
  store i32 %210, ptr %26, align 4, !dbg !4585
  br label %216, !dbg !4586

211:                                              ; preds = %201
  %212 = load double, ptr %27, align 8, !dbg !4587
  %213 = fcmp oge double %212, 5.000000e-01, !dbg !4589
  br i1 %213, label %214, label %215, !dbg !4590

214:                                              ; preds = %211
  store i32 2, ptr %26, align 4, !dbg !4591
  br label %215, !dbg !4593

215:                                              ; preds = %214, %211
  br label %216

216:                                              ; preds = %215, %204
  br label %217

217:                                              ; preds = %216, %171
  %218 = load i32, ptr %26, align 4, !dbg !4594
  %219 = icmp sgt i32 %218, 0, !dbg !4596
  br i1 %219, label %220, label %289, !dbg !4597

220:                                              ; preds = %217
  %221 = load i32, ptr %19, align 4, !dbg !4598
  %222 = add nsw i32 %221, 1, !dbg !4598
  store i32 %222, ptr %19, align 4, !dbg !4598
  store i32 0, ptr %18, align 4, !dbg !4600
  store i32 0, ptr %21, align 4, !dbg !4601
  br label %223, !dbg !4603

223:                                              ; preds = %251, %220
  %224 = load i32, ptr %21, align 4, !dbg !4604
  %225 = load i32, ptr %13, align 4, !dbg !4606
  %226 = icmp slt i32 %224, %225, !dbg !4607
  br i1 %226, label %227, label %254, !dbg !4608

227:                                              ; preds = %223
  %228 = load i32, ptr %21, align 4, !dbg !4609
  %229 = sext i32 %228 to i64, !dbg !4611
  %230 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %229, !dbg !4611
  %231 = load i32, ptr %230, align 4, !dbg !4611
  store i32 %231, ptr %22, align 4, !dbg !4612
  %232 = load i32, ptr %18, align 4, !dbg !4613
  %233 = icmp eq i32 %232, 0, !dbg !4615
  br i1 %233, label %234, label %244, !dbg !4616

234:                                              ; preds = %227
  %235 = load i32, ptr %22, align 4, !dbg !4617
  %236 = icmp ne i32 %235, 0, !dbg !4620
  br i1 %236, label %237, label %243, !dbg !4621

237:                                              ; preds = %234
  store i32 1, ptr %18, align 4, !dbg !4622
  %238 = load i32, ptr %22, align 4, !dbg !4624
  %239 = sub nsw i32 16777216, %238, !dbg !4625
  %240 = load i32, ptr %21, align 4, !dbg !4626
  %241 = sext i32 %240 to i64, !dbg !4627
  %242 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %241, !dbg !4627
  store i32 %239, ptr %242, align 4, !dbg !4628
  br label %243, !dbg !4629

243:                                              ; preds = %237, %234
  br label %250, !dbg !4630

244:                                              ; preds = %227
  %245 = load i32, ptr %22, align 4, !dbg !4631
  %246 = sub nsw i32 16777215, %245, !dbg !4633
  %247 = load i32, ptr %21, align 4, !dbg !4634
  %248 = sext i32 %247 to i64, !dbg !4635
  %249 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %248, !dbg !4635
  store i32 %246, ptr %249, align 4, !dbg !4636
  br label %250

250:                                              ; preds = %244, %243
  br label %251, !dbg !4637

251:                                              ; preds = %250
  %252 = load i32, ptr %21, align 4, !dbg !4638
  %253 = add nsw i32 %252, 1, !dbg !4638
  store i32 %253, ptr %21, align 4, !dbg !4638
  br label %223, !dbg !4639, !llvm.loop !4640

254:                                              ; preds = %223
  %255 = load i32, ptr %25, align 4, !dbg !4642
  %256 = icmp sgt i32 %255, 0, !dbg !4644
  br i1 %256, label %257, label %274, !dbg !4645

257:                                              ; preds = %254
  %258 = load i32, ptr %25, align 4, !dbg !4646
  switch i32 %258, label %273 [
    i32 1, label %259
    i32 2, label %266
  ], !dbg !4648

259:                                              ; preds = %257
  %260 = load i32, ptr %13, align 4, !dbg !4649
  %261 = sub nsw i32 %260, 1, !dbg !4651
  %262 = sext i32 %261 to i64, !dbg !4652
  %263 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %262, !dbg !4652
  %264 = load i32, ptr %263, align 4, !dbg !4653
  %265 = and i32 %264, 8388607, !dbg !4653
  store i32 %265, ptr %263, align 4, !dbg !4653
  br label %273, !dbg !4654

266:                                              ; preds = %257
  %267 = load i32, ptr %13, align 4, !dbg !4655
  %268 = sub nsw i32 %267, 1, !dbg !4656
  %269 = sext i32 %268 to i64, !dbg !4657
  %270 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %269, !dbg !4657
  %271 = load i32, ptr %270, align 4, !dbg !4658
  %272 = and i32 %271, 4194303, !dbg !4658
  store i32 %272, ptr %270, align 4, !dbg !4658
  br label %273, !dbg !4659

273:                                              ; preds = %257, %266, %259
  br label %274, !dbg !4660

274:                                              ; preds = %273, %254
  %275 = load i32, ptr %26, align 4, !dbg !4661
  %276 = icmp eq i32 %275, 2, !dbg !4663
  br i1 %276, label %277, label %288, !dbg !4664

277:                                              ; preds = %274
  %278 = load double, ptr %27, align 8, !dbg !4665
  %279 = fsub double 1.000000e+00, %278, !dbg !4667
  store double %279, ptr %27, align 8, !dbg !4668
  %280 = load i32, ptr %18, align 4, !dbg !4669
  %281 = icmp ne i32 %280, 0, !dbg !4671
  br i1 %281, label %282, label %287, !dbg !4672

282:                                              ; preds = %277
  %283 = load i32, ptr %25, align 4, !dbg !4673
  %284 = call double @scalbn(double noundef 1.000000e+00, i32 noundef %283) #4, !dbg !4674
  %285 = load double, ptr %27, align 8, !dbg !4675
  %286 = fsub double %285, %284, !dbg !4675
  store double %286, ptr %27, align 8, !dbg !4675
  br label %287, !dbg !4676

287:                                              ; preds = %282, %277
  br label %288, !dbg !4677

288:                                              ; preds = %287, %274
  br label %289, !dbg !4678

289:                                              ; preds = %288, %217
  %290 = load double, ptr %27, align 8, !dbg !4679
  %291 = fcmp oeq double %290, 0.000000e+00, !dbg !4681
  br i1 %291, label %292, label %390, !dbg !4682

292:                                              ; preds = %289
  store i32 0, ptr %22, align 4, !dbg !4683
  %293 = load i32, ptr %13, align 4, !dbg !4685
  %294 = sub nsw i32 %293, 1, !dbg !4687
  store i32 %294, ptr %21, align 4, !dbg !4688
  br label %295, !dbg !4689

295:                                              ; preds = %306, %292
  %296 = load i32, ptr %21, align 4, !dbg !4690
  %297 = load i32, ptr %17, align 4, !dbg !4692
  %298 = icmp sge i32 %296, %297, !dbg !4693
  br i1 %298, label %299, label %309, !dbg !4694

299:                                              ; preds = %295
  %300 = load i32, ptr %21, align 4, !dbg !4695
  %301 = sext i32 %300 to i64, !dbg !4696
  %302 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %301, !dbg !4696
  %303 = load i32, ptr %302, align 4, !dbg !4696
  %304 = load i32, ptr %22, align 4, !dbg !4697
  %305 = or i32 %304, %303, !dbg !4697
  store i32 %305, ptr %22, align 4, !dbg !4697
  br label %306, !dbg !4698

306:                                              ; preds = %299
  %307 = load i32, ptr %21, align 4, !dbg !4699
  %308 = add nsw i32 %307, -1, !dbg !4699
  store i32 %308, ptr %21, align 4, !dbg !4699
  br label %295, !dbg !4700, !llvm.loop !4701

309:                                              ; preds = %295
  %310 = load i32, ptr %22, align 4, !dbg !4703
  %311 = icmp eq i32 %310, 0, !dbg !4705
  br i1 %311, label %312, label %389, !dbg !4706

312:                                              ; preds = %309
  store i32 1, ptr %23, align 4, !dbg !4707
  br label %313, !dbg !4710

313:                                              ; preds = %328, %312
  %314 = load i32, ptr %17, align 4, !dbg !4711
  %315 = load i32, ptr %23, align 4, !dbg !4713
  %316 = icmp sge i32 %314, %315, !dbg !4714
  br i1 %316, label %317, label %325, !dbg !4715

317:                                              ; preds = %313
  %318 = load i32, ptr %17, align 4, !dbg !4716
  %319 = load i32, ptr %23, align 4, !dbg !4717
  %320 = sub nsw i32 %318, %319, !dbg !4718
  %321 = sext i32 %320 to i64, !dbg !4719
  %322 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %321, !dbg !4719
  %323 = load i32, ptr %322, align 4, !dbg !4719
  %324 = icmp eq i32 %323, 0, !dbg !4720
  br label %325

325:                                              ; preds = %317, %313
  %326 = phi i1 [ false, %313 ], [ %324, %317 ], !dbg !4721
  br i1 %326, label %327, label %331, !dbg !4722

327:                                              ; preds = %325
  br label %328, !dbg !4723

328:                                              ; preds = %327
  %329 = load i32, ptr %23, align 4, !dbg !4725
  %330 = add nsw i32 %329, 1, !dbg !4725
  store i32 %330, ptr %23, align 4, !dbg !4725
  br label %313, !dbg !4726, !llvm.loop !4727

331:                                              ; preds = %325
  %332 = load i32, ptr %13, align 4, !dbg !4729
  %333 = add nsw i32 %332, 1, !dbg !4731
  store i32 %333, ptr %21, align 4, !dbg !4732
  br label %334, !dbg !4733

334:                                              ; preds = %382, %331
  %335 = load i32, ptr %21, align 4, !dbg !4734
  %336 = load i32, ptr %13, align 4, !dbg !4736
  %337 = load i32, ptr %23, align 4, !dbg !4737
  %338 = add nsw i32 %336, %337, !dbg !4738
  %339 = icmp sle i32 %335, %338, !dbg !4739
  br i1 %339, label %340, label %385, !dbg !4740

340:                                              ; preds = %334
  %341 = load ptr, ptr %12, align 8, !dbg !4741
  %342 = load i32, ptr %15, align 4, !dbg !4743
  %343 = load i32, ptr %21, align 4, !dbg !4744
  %344 = add nsw i32 %342, %343, !dbg !4745
  %345 = sext i32 %344 to i64, !dbg !4741
  %346 = getelementptr inbounds i32, ptr %341, i64 %345, !dbg !4741
  %347 = load i32, ptr %346, align 4, !dbg !4741
  %348 = sitofp i32 %347 to double, !dbg !4741
  %349 = load i32, ptr %14, align 4, !dbg !4746
  %350 = load i32, ptr %21, align 4, !dbg !4747
  %351 = add nsw i32 %349, %350, !dbg !4748
  %352 = sext i32 %351 to i64, !dbg !4749
  %353 = getelementptr inbounds [20 x double], ptr %29, i64 0, i64 %352, !dbg !4749
  store double %348, ptr %353, align 8, !dbg !4750
  store i32 0, ptr %22, align 4, !dbg !4751
  store double 0.000000e+00, ptr %28, align 8, !dbg !4753
  br label %354, !dbg !4754

354:                                              ; preds = %374, %340
  %355 = load i32, ptr %22, align 4, !dbg !4755
  %356 = load i32, ptr %14, align 4, !dbg !4757
  %357 = icmp sle i32 %355, %356, !dbg !4758
  br i1 %357, label %358, label %377, !dbg !4759

358:                                              ; preds = %354
  %359 = load ptr, ptr %7, align 8, !dbg !4760
  %360 = load i32, ptr %22, align 4, !dbg !4761
  %361 = sext i32 %360 to i64, !dbg !4760
  %362 = getelementptr inbounds double, ptr %359, i64 %361, !dbg !4760
  %363 = load double, ptr %362, align 8, !dbg !4760
  %364 = load i32, ptr %14, align 4, !dbg !4762
  %365 = load i32, ptr %21, align 4, !dbg !4763
  %366 = add nsw i32 %364, %365, !dbg !4764
  %367 = load i32, ptr %22, align 4, !dbg !4765
  %368 = sub nsw i32 %366, %367, !dbg !4766
  %369 = sext i32 %368 to i64, !dbg !4767
  %370 = getelementptr inbounds [20 x double], ptr %29, i64 0, i64 %369, !dbg !4767
  %371 = load double, ptr %370, align 8, !dbg !4767
  %372 = load double, ptr %28, align 8, !dbg !4768
  %373 = call double @llvm.fmuladd.f64(double %363, double %371, double %372), !dbg !4768
  store double %373, ptr %28, align 8, !dbg !4768
  br label %374, !dbg !4769

374:                                              ; preds = %358
  %375 = load i32, ptr %22, align 4, !dbg !4770
  %376 = add nsw i32 %375, 1, !dbg !4770
  store i32 %376, ptr %22, align 4, !dbg !4770
  br label %354, !dbg !4771, !llvm.loop !4772

377:                                              ; preds = %354
  %378 = load double, ptr %28, align 8, !dbg !4774
  %379 = load i32, ptr %21, align 4, !dbg !4775
  %380 = sext i32 %379 to i64, !dbg !4776
  %381 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %380, !dbg !4776
  store double %378, ptr %381, align 8, !dbg !4777
  br label %382, !dbg !4778

382:                                              ; preds = %377
  %383 = load i32, ptr %21, align 4, !dbg !4779
  %384 = add nsw i32 %383, 1, !dbg !4779
  store i32 %384, ptr %21, align 4, !dbg !4779
  br label %334, !dbg !4780, !llvm.loop !4781

385:                                              ; preds = %334
  %386 = load i32, ptr %23, align 4, !dbg !4783
  %387 = load i32, ptr %13, align 4, !dbg !4784
  %388 = add nsw i32 %387, %386, !dbg !4784
  store i32 %388, ptr %13, align 4, !dbg !4784
  br label %121, !dbg !4785

389:                                              ; preds = %309
  br label %390, !dbg !4786

390:                                              ; preds = %389, %289
  %391 = load double, ptr %27, align 8, !dbg !4787
  %392 = fcmp oeq double %391, 0.000000e+00, !dbg !4789
  br i1 %392, label %393, label %410, !dbg !4790

393:                                              ; preds = %390
  %394 = load i32, ptr %13, align 4, !dbg !4791
  %395 = sub nsw i32 %394, 1, !dbg !4791
  store i32 %395, ptr %13, align 4, !dbg !4791
  %396 = load i32, ptr %25, align 4, !dbg !4793
  %397 = sub nsw i32 %396, 24, !dbg !4793
  store i32 %397, ptr %25, align 4, !dbg !4793
  br label %398, !dbg !4794

398:                                              ; preds = %404, %393
  %399 = load i32, ptr %13, align 4, !dbg !4795
  %400 = sext i32 %399 to i64, !dbg !4796
  %401 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %400, !dbg !4796
  %402 = load i32, ptr %401, align 4, !dbg !4796
  %403 = icmp eq i32 %402, 0, !dbg !4797
  br i1 %403, label %404, label %409, !dbg !4794

404:                                              ; preds = %398
  %405 = load i32, ptr %13, align 4, !dbg !4798
  %406 = add nsw i32 %405, -1, !dbg !4798
  store i32 %406, ptr %13, align 4, !dbg !4798
  %407 = load i32, ptr %25, align 4, !dbg !4800
  %408 = sub nsw i32 %407, 24, !dbg !4800
  store i32 %408, ptr %25, align 4, !dbg !4800
  br label %398, !dbg !4794, !llvm.loop !4801

409:                                              ; preds = %398
  br label %445, !dbg !4803

410:                                              ; preds = %390
  %411 = load double, ptr %27, align 8, !dbg !4804
  %412 = load i32, ptr %25, align 4, !dbg !4806
  %413 = sub nsw i32 0, %412, !dbg !4807
  %414 = call double @scalbn(double noundef %411, i32 noundef %413) #4, !dbg !4808
  store double %414, ptr %27, align 8, !dbg !4809
  %415 = load double, ptr %27, align 8, !dbg !4810
  %416 = fcmp oge double %415, 0x4170000000000000, !dbg !4812
  br i1 %416, label %417, label %438, !dbg !4813

417:                                              ; preds = %410
  %418 = load double, ptr %27, align 8, !dbg !4814
  %419 = fmul double 0x3E70000000000000, %418, !dbg !4816
  %420 = fptosi double %419 to i32, !dbg !4817
  %421 = sitofp i32 %420 to double, !dbg !4818
  store double %421, ptr %28, align 8, !dbg !4819
  %422 = load double, ptr %27, align 8, !dbg !4820
  %423 = load double, ptr %28, align 8, !dbg !4821
  %424 = call double @llvm.fmuladd.f64(double 0xC170000000000000, double %423, double %422), !dbg !4822
  %425 = fptosi double %424 to i32, !dbg !4820
  %426 = load i32, ptr %13, align 4, !dbg !4823
  %427 = sext i32 %426 to i64, !dbg !4824
  %428 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %427, !dbg !4824
  store i32 %425, ptr %428, align 4, !dbg !4825
  %429 = load i32, ptr %13, align 4, !dbg !4826
  %430 = add nsw i32 %429, 1, !dbg !4826
  store i32 %430, ptr %13, align 4, !dbg !4826
  %431 = load i32, ptr %25, align 4, !dbg !4827
  %432 = add nsw i32 %431, 24, !dbg !4827
  store i32 %432, ptr %25, align 4, !dbg !4827
  %433 = load double, ptr %28, align 8, !dbg !4828
  %434 = fptosi double %433 to i32, !dbg !4828
  %435 = load i32, ptr %13, align 4, !dbg !4829
  %436 = sext i32 %435 to i64, !dbg !4830
  %437 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %436, !dbg !4830
  store i32 %434, ptr %437, align 4, !dbg !4831
  br label %444, !dbg !4832

438:                                              ; preds = %410
  %439 = load double, ptr %27, align 8, !dbg !4833
  %440 = fptosi double %439 to i32, !dbg !4833
  %441 = load i32, ptr %13, align 4, !dbg !4835
  %442 = sext i32 %441 to i64, !dbg !4836
  %443 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %442, !dbg !4836
  store i32 %440, ptr %443, align 4, !dbg !4837
  br label %444

444:                                              ; preds = %438, %417
  br label %445

445:                                              ; preds = %444, %409
  %446 = load i32, ptr %25, align 4, !dbg !4838
  %447 = call double @scalbn(double noundef 1.000000e+00, i32 noundef %446) #4, !dbg !4839
  store double %447, ptr %28, align 8, !dbg !4840
  %448 = load i32, ptr %13, align 4, !dbg !4841
  store i32 %448, ptr %21, align 4, !dbg !4843
  br label %449, !dbg !4844

449:                                              ; preds = %465, %445
  %450 = load i32, ptr %21, align 4, !dbg !4845
  %451 = icmp sge i32 %450, 0, !dbg !4847
  br i1 %451, label %452, label %468, !dbg !4848

452:                                              ; preds = %449
  %453 = load double, ptr %28, align 8, !dbg !4849
  %454 = load i32, ptr %21, align 4, !dbg !4851
  %455 = sext i32 %454 to i64, !dbg !4852
  %456 = getelementptr inbounds [20 x i32], ptr %20, i64 0, i64 %455, !dbg !4852
  %457 = load i32, ptr %456, align 4, !dbg !4852
  %458 = sitofp i32 %457 to double, !dbg !4852
  %459 = fmul double %453, %458, !dbg !4853
  %460 = load i32, ptr %21, align 4, !dbg !4854
  %461 = sext i32 %460 to i64, !dbg !4855
  %462 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %461, !dbg !4855
  store double %459, ptr %462, align 8, !dbg !4856
  %463 = load double, ptr %28, align 8, !dbg !4857
  %464 = fmul double %463, 0x3E70000000000000, !dbg !4857
  store double %464, ptr %28, align 8, !dbg !4857
  br label %465, !dbg !4858

465:                                              ; preds = %452
  %466 = load i32, ptr %21, align 4, !dbg !4859
  %467 = add nsw i32 %466, -1, !dbg !4859
  store i32 %467, ptr %21, align 4, !dbg !4859
  br label %449, !dbg !4860, !llvm.loop !4861

468:                                              ; preds = %449
  %469 = load i32, ptr %13, align 4, !dbg !4863
  store i32 %469, ptr %21, align 4, !dbg !4865
  br label %470, !dbg !4866

470:                                              ; preds = %509, %468
  %471 = load i32, ptr %21, align 4, !dbg !4867
  %472 = icmp sge i32 %471, 0, !dbg !4869
  br i1 %472, label %473, label %512, !dbg !4870

473:                                              ; preds = %470
  store double 0.000000e+00, ptr %28, align 8, !dbg !4871
  store i32 0, ptr %23, align 4, !dbg !4874
  br label %474, !dbg !4875

474:                                              ; preds = %499, %473
  %475 = load i32, ptr %23, align 4, !dbg !4876
  %476 = load i32, ptr %16, align 4, !dbg !4878
  %477 = icmp sle i32 %475, %476, !dbg !4879
  br i1 %477, label %478, label %484, !dbg !4880

478:                                              ; preds = %474
  %479 = load i32, ptr %23, align 4, !dbg !4881
  %480 = load i32, ptr %13, align 4, !dbg !4882
  %481 = load i32, ptr %21, align 4, !dbg !4883
  %482 = sub nsw i32 %480, %481, !dbg !4884
  %483 = icmp sle i32 %479, %482, !dbg !4885
  br label %484

484:                                              ; preds = %478, %474
  %485 = phi i1 [ false, %474 ], [ %483, %478 ], !dbg !4886
  br i1 %485, label %486, label %502, !dbg !4887

486:                                              ; preds = %484
  %487 = load i32, ptr %23, align 4, !dbg !4888
  %488 = sext i32 %487 to i64, !dbg !4889
  %489 = getelementptr inbounds [8 x double], ptr @__kernel_rem_pio2.PIo2, i64 0, i64 %488, !dbg !4889
  %490 = load double, ptr %489, align 8, !dbg !4889
  %491 = load i32, ptr %21, align 4, !dbg !4890
  %492 = load i32, ptr %23, align 4, !dbg !4891
  %493 = add nsw i32 %491, %492, !dbg !4892
  %494 = sext i32 %493 to i64, !dbg !4893
  %495 = getelementptr inbounds [20 x double], ptr %31, i64 0, i64 %494, !dbg !4893
  %496 = load double, ptr %495, align 8, !dbg !4893
  %497 = load double, ptr %28, align 8, !dbg !4894
  %498 = call double @llvm.fmuladd.f64(double %490, double %496, double %497), !dbg !4894
  store double %498, ptr %28, align 8, !dbg !4894
  br label %499, !dbg !4895

499:                                              ; preds = %486
  %500 = load i32, ptr %23, align 4, !dbg !4896
  %501 = add nsw i32 %500, 1, !dbg !4896
  store i32 %501, ptr %23, align 4, !dbg !4896
  br label %474, !dbg !4897, !llvm.loop !4898

502:                                              ; preds = %484
  %503 = load double, ptr %28, align 8, !dbg !4900
  %504 = load i32, ptr %13, align 4, !dbg !4901
  %505 = load i32, ptr %21, align 4, !dbg !4902
  %506 = sub nsw i32 %504, %505, !dbg !4903
  %507 = sext i32 %506 to i64, !dbg !4904
  %508 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %507, !dbg !4904
  store double %503, ptr %508, align 8, !dbg !4905
  br label %509, !dbg !4906

509:                                              ; preds = %502
  %510 = load i32, ptr %21, align 4, !dbg !4907
  %511 = add nsw i32 %510, -1, !dbg !4907
  store i32 %511, ptr %21, align 4, !dbg !4907
  br label %470, !dbg !4908, !llvm.loop !4909

512:                                              ; preds = %470
  %513 = load i32, ptr %11, align 4, !dbg !4911
  switch i32 %513, label %716 [
    i32 0, label %514
    i32 1, label %541
    i32 2, label %541
    i32 3, label %598
  ], !dbg !4912

514:                                              ; preds = %512
  store double 0.000000e+00, ptr %28, align 8, !dbg !4913
  %515 = load i32, ptr %13, align 4, !dbg !4915
  store i32 %515, ptr %21, align 4, !dbg !4917
  br label %516, !dbg !4918

516:                                              ; preds = %526, %514
  %517 = load i32, ptr %21, align 4, !dbg !4919
  %518 = icmp sge i32 %517, 0, !dbg !4921
  br i1 %518, label %519, label %529, !dbg !4922

519:                                              ; preds = %516
  %520 = load i32, ptr %21, align 4, !dbg !4923
  %521 = sext i32 %520 to i64, !dbg !4924
  %522 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %521, !dbg !4924
  %523 = load double, ptr %522, align 8, !dbg !4924
  %524 = load double, ptr %28, align 8, !dbg !4925
  %525 = fadd double %524, %523, !dbg !4925
  store double %525, ptr %28, align 8, !dbg !4925
  br label %526, !dbg !4926

526:                                              ; preds = %519
  %527 = load i32, ptr %21, align 4, !dbg !4927
  %528 = add nsw i32 %527, -1, !dbg !4927
  store i32 %528, ptr %21, align 4, !dbg !4927
  br label %516, !dbg !4928, !llvm.loop !4929

529:                                              ; preds = %516
  %530 = load i32, ptr %26, align 4, !dbg !4931
  %531 = icmp eq i32 %530, 0, !dbg !4932
  br i1 %531, label %532, label %534, !dbg !4933

532:                                              ; preds = %529
  %533 = load double, ptr %28, align 8, !dbg !4934
  br label %537, !dbg !4933

534:                                              ; preds = %529
  %535 = load double, ptr %28, align 8, !dbg !4935
  %536 = fneg double %535, !dbg !4936
  br label %537, !dbg !4933

537:                                              ; preds = %534, %532
  %538 = phi double [ %533, %532 ], [ %536, %534 ], !dbg !4933
  %539 = load ptr, ptr %8, align 8, !dbg !4937
  %540 = getelementptr inbounds double, ptr %539, i64 0, !dbg !4937
  store double %538, ptr %540, align 8, !dbg !4938
  br label %716, !dbg !4939

541:                                              ; preds = %512, %512
  store double 0.000000e+00, ptr %28, align 8, !dbg !4940
  %542 = load i32, ptr %13, align 4, !dbg !4941
  store i32 %542, ptr %21, align 4, !dbg !4943
  br label %543, !dbg !4944

543:                                              ; preds = %553, %541
  %544 = load i32, ptr %21, align 4, !dbg !4945
  %545 = icmp sge i32 %544, 0, !dbg !4947
  br i1 %545, label %546, label %556, !dbg !4948

546:                                              ; preds = %543
  %547 = load i32, ptr %21, align 4, !dbg !4949
  %548 = sext i32 %547 to i64, !dbg !4950
  %549 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %548, !dbg !4950
  %550 = load double, ptr %549, align 8, !dbg !4950
  %551 = load double, ptr %28, align 8, !dbg !4951
  %552 = fadd double %551, %550, !dbg !4951
  store double %552, ptr %28, align 8, !dbg !4951
  br label %553, !dbg !4952

553:                                              ; preds = %546
  %554 = load i32, ptr %21, align 4, !dbg !4953
  %555 = add nsw i32 %554, -1, !dbg !4953
  store i32 %555, ptr %21, align 4, !dbg !4953
  br label %543, !dbg !4954, !llvm.loop !4955

556:                                              ; preds = %543
  %557 = load i32, ptr %26, align 4, !dbg !4957
  %558 = icmp eq i32 %557, 0, !dbg !4958
  br i1 %558, label %559, label %561, !dbg !4959

559:                                              ; preds = %556
  %560 = load double, ptr %28, align 8, !dbg !4960
  br label %564, !dbg !4959

561:                                              ; preds = %556
  %562 = load double, ptr %28, align 8, !dbg !4961
  %563 = fneg double %562, !dbg !4962
  br label %564, !dbg !4959

564:                                              ; preds = %561, %559
  %565 = phi double [ %560, %559 ], [ %563, %561 ], !dbg !4959
  %566 = load ptr, ptr %8, align 8, !dbg !4963
  %567 = getelementptr inbounds double, ptr %566, i64 0, !dbg !4963
  store double %565, ptr %567, align 8, !dbg !4964
  %568 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 0, !dbg !4965
  %569 = load double, ptr %568, align 8, !dbg !4965
  %570 = load double, ptr %28, align 8, !dbg !4966
  %571 = fsub double %569, %570, !dbg !4967
  store double %571, ptr %28, align 8, !dbg !4968
  store i32 1, ptr %21, align 4, !dbg !4969
  br label %572, !dbg !4971

572:                                              ; preds = %583, %564
  %573 = load i32, ptr %21, align 4, !dbg !4972
  %574 = load i32, ptr %13, align 4, !dbg !4974
  %575 = icmp sle i32 %573, %574, !dbg !4975
  br i1 %575, label %576, label %586, !dbg !4976

576:                                              ; preds = %572
  %577 = load i32, ptr %21, align 4, !dbg !4977
  %578 = sext i32 %577 to i64, !dbg !4978
  %579 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %578, !dbg !4978
  %580 = load double, ptr %579, align 8, !dbg !4978
  %581 = load double, ptr %28, align 8, !dbg !4979
  %582 = fadd double %581, %580, !dbg !4979
  store double %582, ptr %28, align 8, !dbg !4979
  br label %583, !dbg !4980

583:                                              ; preds = %576
  %584 = load i32, ptr %21, align 4, !dbg !4981
  %585 = add nsw i32 %584, 1, !dbg !4981
  store i32 %585, ptr %21, align 4, !dbg !4981
  br label %572, !dbg !4982, !llvm.loop !4983

586:                                              ; preds = %572
  %587 = load i32, ptr %26, align 4, !dbg !4985
  %588 = icmp eq i32 %587, 0, !dbg !4986
  br i1 %588, label %589, label %591, !dbg !4987

589:                                              ; preds = %586
  %590 = load double, ptr %28, align 8, !dbg !4988
  br label %594, !dbg !4987

591:                                              ; preds = %586
  %592 = load double, ptr %28, align 8, !dbg !4989
  %593 = fneg double %592, !dbg !4990
  br label %594, !dbg !4987

594:                                              ; preds = %591, %589
  %595 = phi double [ %590, %589 ], [ %593, %591 ], !dbg !4987
  %596 = load ptr, ptr %8, align 8, !dbg !4991
  %597 = getelementptr inbounds double, ptr %596, i64 1, !dbg !4991
  store double %595, ptr %597, align 8, !dbg !4992
  br label %716, !dbg !4993

598:                                              ; preds = %512
  %599 = load i32, ptr %13, align 4, !dbg !4994
  store i32 %599, ptr %21, align 4, !dbg !4996
  br label %600, !dbg !4997

600:                                              ; preds = %631, %598
  %601 = load i32, ptr %21, align 4, !dbg !4998
  %602 = icmp sgt i32 %601, 0, !dbg !5000
  br i1 %602, label %603, label %634, !dbg !5001

603:                                              ; preds = %600
  %604 = load i32, ptr %21, align 4, !dbg !5002
  %605 = sub nsw i32 %604, 1, !dbg !5004
  %606 = sext i32 %605 to i64, !dbg !5005
  %607 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %606, !dbg !5005
  %608 = load double, ptr %607, align 8, !dbg !5005
  %609 = load i32, ptr %21, align 4, !dbg !5006
  %610 = sext i32 %609 to i64, !dbg !5007
  %611 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %610, !dbg !5007
  %612 = load double, ptr %611, align 8, !dbg !5007
  %613 = fadd double %608, %612, !dbg !5008
  store double %613, ptr %28, align 8, !dbg !5009
  %614 = load i32, ptr %21, align 4, !dbg !5010
  %615 = sub nsw i32 %614, 1, !dbg !5011
  %616 = sext i32 %615 to i64, !dbg !5012
  %617 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %616, !dbg !5012
  %618 = load double, ptr %617, align 8, !dbg !5012
  %619 = load double, ptr %28, align 8, !dbg !5013
  %620 = fsub double %618, %619, !dbg !5014
  %621 = load i32, ptr %21, align 4, !dbg !5015
  %622 = sext i32 %621 to i64, !dbg !5016
  %623 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %622, !dbg !5016
  %624 = load double, ptr %623, align 8, !dbg !5017
  %625 = fadd double %624, %620, !dbg !5017
  store double %625, ptr %623, align 8, !dbg !5017
  %626 = load double, ptr %28, align 8, !dbg !5018
  %627 = load i32, ptr %21, align 4, !dbg !5019
  %628 = sub nsw i32 %627, 1, !dbg !5020
  %629 = sext i32 %628 to i64, !dbg !5021
  %630 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %629, !dbg !5021
  store double %626, ptr %630, align 8, !dbg !5022
  br label %631, !dbg !5023

631:                                              ; preds = %603
  %632 = load i32, ptr %21, align 4, !dbg !5024
  %633 = add nsw i32 %632, -1, !dbg !5024
  store i32 %633, ptr %21, align 4, !dbg !5024
  br label %600, !dbg !5025, !llvm.loop !5026

634:                                              ; preds = %600
  %635 = load i32, ptr %13, align 4, !dbg !5028
  store i32 %635, ptr %21, align 4, !dbg !5030
  br label %636, !dbg !5031

636:                                              ; preds = %667, %634
  %637 = load i32, ptr %21, align 4, !dbg !5032
  %638 = icmp sgt i32 %637, 1, !dbg !5034
  br i1 %638, label %639, label %670, !dbg !5035

639:                                              ; preds = %636
  %640 = load i32, ptr %21, align 4, !dbg !5036
  %641 = sub nsw i32 %640, 1, !dbg !5038
  %642 = sext i32 %641 to i64, !dbg !5039
  %643 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %642, !dbg !5039
  %644 = load double, ptr %643, align 8, !dbg !5039
  %645 = load i32, ptr %21, align 4, !dbg !5040
  %646 = sext i32 %645 to i64, !dbg !5041
  %647 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %646, !dbg !5041
  %648 = load double, ptr %647, align 8, !dbg !5041
  %649 = fadd double %644, %648, !dbg !5042
  store double %649, ptr %28, align 8, !dbg !5043
  %650 = load i32, ptr %21, align 4, !dbg !5044
  %651 = sub nsw i32 %650, 1, !dbg !5045
  %652 = sext i32 %651 to i64, !dbg !5046
  %653 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %652, !dbg !5046
  %654 = load double, ptr %653, align 8, !dbg !5046
  %655 = load double, ptr %28, align 8, !dbg !5047
  %656 = fsub double %654, %655, !dbg !5048
  %657 = load i32, ptr %21, align 4, !dbg !5049
  %658 = sext i32 %657 to i64, !dbg !5050
  %659 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %658, !dbg !5050
  %660 = load double, ptr %659, align 8, !dbg !5051
  %661 = fadd double %660, %656, !dbg !5051
  store double %661, ptr %659, align 8, !dbg !5051
  %662 = load double, ptr %28, align 8, !dbg !5052
  %663 = load i32, ptr %21, align 4, !dbg !5053
  %664 = sub nsw i32 %663, 1, !dbg !5054
  %665 = sext i32 %664 to i64, !dbg !5055
  %666 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %665, !dbg !5055
  store double %662, ptr %666, align 8, !dbg !5056
  br label %667, !dbg !5057

667:                                              ; preds = %639
  %668 = load i32, ptr %21, align 4, !dbg !5058
  %669 = add nsw i32 %668, -1, !dbg !5058
  store i32 %669, ptr %21, align 4, !dbg !5058
  br label %636, !dbg !5059, !llvm.loop !5060

670:                                              ; preds = %636
  store double 0.000000e+00, ptr %28, align 8, !dbg !5062
  %671 = load i32, ptr %13, align 4, !dbg !5064
  store i32 %671, ptr %21, align 4, !dbg !5065
  br label %672, !dbg !5066

672:                                              ; preds = %682, %670
  %673 = load i32, ptr %21, align 4, !dbg !5067
  %674 = icmp sge i32 %673, 2, !dbg !5069
  br i1 %674, label %675, label %685, !dbg !5070

675:                                              ; preds = %672
  %676 = load i32, ptr %21, align 4, !dbg !5071
  %677 = sext i32 %676 to i64, !dbg !5072
  %678 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 %677, !dbg !5072
  %679 = load double, ptr %678, align 8, !dbg !5072
  %680 = load double, ptr %28, align 8, !dbg !5073
  %681 = fadd double %680, %679, !dbg !5073
  store double %681, ptr %28, align 8, !dbg !5073
  br label %682, !dbg !5074

682:                                              ; preds = %675
  %683 = load i32, ptr %21, align 4, !dbg !5075
  %684 = add nsw i32 %683, -1, !dbg !5075
  store i32 %684, ptr %21, align 4, !dbg !5075
  br label %672, !dbg !5076, !llvm.loop !5077

685:                                              ; preds = %672
  %686 = load i32, ptr %26, align 4, !dbg !5079
  %687 = icmp eq i32 %686, 0, !dbg !5081
  br i1 %687, label %688, label %700, !dbg !5082

688:                                              ; preds = %685
  %689 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 0, !dbg !5083
  %690 = load double, ptr %689, align 8, !dbg !5083
  %691 = load ptr, ptr %8, align 8, !dbg !5085
  %692 = getelementptr inbounds double, ptr %691, i64 0, !dbg !5085
  store double %690, ptr %692, align 8, !dbg !5086
  %693 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 1, !dbg !5087
  %694 = load double, ptr %693, align 8, !dbg !5087
  %695 = load ptr, ptr %8, align 8, !dbg !5088
  %696 = getelementptr inbounds double, ptr %695, i64 1, !dbg !5088
  store double %694, ptr %696, align 8, !dbg !5089
  %697 = load double, ptr %28, align 8, !dbg !5090
  %698 = load ptr, ptr %8, align 8, !dbg !5091
  %699 = getelementptr inbounds double, ptr %698, i64 2, !dbg !5091
  store double %697, ptr %699, align 8, !dbg !5092
  br label %715, !dbg !5093

700:                                              ; preds = %685
  %701 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 0, !dbg !5094
  %702 = load double, ptr %701, align 8, !dbg !5094
  %703 = fneg double %702, !dbg !5096
  %704 = load ptr, ptr %8, align 8, !dbg !5097
  %705 = getelementptr inbounds double, ptr %704, i64 0, !dbg !5097
  store double %703, ptr %705, align 8, !dbg !5098
  %706 = getelementptr inbounds [20 x double], ptr %30, i64 0, i64 1, !dbg !5099
  %707 = load double, ptr %706, align 8, !dbg !5099
  %708 = fneg double %707, !dbg !5100
  %709 = load ptr, ptr %8, align 8, !dbg !5101
  %710 = getelementptr inbounds double, ptr %709, i64 1, !dbg !5101
  store double %708, ptr %710, align 8, !dbg !5102
  %711 = load double, ptr %28, align 8, !dbg !5103
  %712 = fneg double %711, !dbg !5104
  %713 = load ptr, ptr %8, align 8, !dbg !5105
  %714 = getelementptr inbounds double, ptr %713, i64 2, !dbg !5105
  store double %712, ptr %714, align 8, !dbg !5106
  br label %715

715:                                              ; preds = %700, %688
  br label %716, !dbg !5107

716:                                              ; preds = %715, %512, %594, %537
  %717 = load i32, ptr %19, align 4, !dbg !5108
  %718 = and i32 %717, 7, !dbg !5109
  ret i32 %718, !dbg !5110
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: nounwind willreturn memory(none)
declare double @scalbn(double noundef, i32 noundef) #3

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

attributes #0 = { noinline nounwind optnone ssp uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { nounwind willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #4 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!7}
!llvm.module.flags = !{!404, !405, !406, !407, !408, !409}
!llvm.ident = !{!410}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "one", scope: !2, file: !3, line: 895, type: !22, isLocal: true, isDefinition: true)
!2 = distinct !DISubprogram(name: "pts_ieee754_acos", scope: !3, file: !3, line: 893, type: !4, scopeLine: 893, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!3 = !DIFile(filename: "../src/ieee754_head.c", directory: "/tmp/pts-h36/repro/clang_on")
!4 = !DISubroutineType(types: !5)
!5 = !{!6, !6}
!6 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!7 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !8, globals: !19, splitDebugInlining: false, nameTableKind: Apple, sysroot: "/")
!8 = !{!9, !12, !15, !16, !18, !6}
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !10, line: 198, baseType: !11)
!10 = !DIFile(filename: "/usr/lib/llvm-18/lib/clang/18/include/stdint.h", directory: "")
!11 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !6)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !10, line: 98, baseType: !17)
!17 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !10, line: 193, baseType: !15)
!19 = !{!0, !20, !23, !25, !27, !29, !31, !33, !35, !37, !39, !41, !43, !45, !47, !51, !53, !56, !58, !60, !62, !64, !66, !68, !70, !72, !74, !76, !78, !80, !82, !84, !87, !89, !91, !97, !99, !104, !106, !108, !113, !115, !117, !119, !121, !123, !126, !131, !133, !135, !137, !139, !141, !143, !145, !147, !149, !151, !153, !155, !157, !159, !162, !164, !166, !169, !171, !173, !175, !177, !179, !181, !183, !185, !187, !189, !192, !194, !196, !198, !200, !202, !204, !206, !208, !210, !212, !215, !217, !219, !222, !224, !226, !228, !231, !233, !235, !237, !239, !241, !243, !245, !247, !249, !251, !253, !257, !259, !261, !263, !265, !267, !269, !272, !274, !276, !278, !281, !283, !285, !287, !290, !292, !294, !296, !299, !301, !303, !305, !307, !309, !311, !321, !326, !328, !330, !332, !334, !336, !338, !340, !342, !344, !346, !354, !359, !361, !363, !365, !367, !372, !374, !376, !378, !380, !382, !384, !386, !388, !390, !392, !394, !396, !398}
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "pi", scope: !2, file: !3, line: 896, type: !22, isLocal: true, isDefinition: true)
!22 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!23 = !DIGlobalVariableExpression(var: !24, expr: !DIExpression())
!24 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !2, file: !3, line: 897, type: !22, isLocal: true, isDefinition: true)
!25 = !DIGlobalVariableExpression(var: !26, expr: !DIExpression())
!26 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !2, file: !3, line: 898, type: !22, isLocal: true, isDefinition: true)
!27 = !DIGlobalVariableExpression(var: !28, expr: !DIExpression())
!28 = distinct !DIGlobalVariable(name: "pS0", scope: !2, file: !3, line: 899, type: !22, isLocal: true, isDefinition: true)
!29 = !DIGlobalVariableExpression(var: !30, expr: !DIExpression())
!30 = distinct !DIGlobalVariable(name: "pS1", scope: !2, file: !3, line: 900, type: !22, isLocal: true, isDefinition: true)
!31 = !DIGlobalVariableExpression(var: !32, expr: !DIExpression())
!32 = distinct !DIGlobalVariable(name: "pS2", scope: !2, file: !3, line: 901, type: !22, isLocal: true, isDefinition: true)
!33 = !DIGlobalVariableExpression(var: !34, expr: !DIExpression())
!34 = distinct !DIGlobalVariable(name: "pS3", scope: !2, file: !3, line: 902, type: !22, isLocal: true, isDefinition: true)
!35 = !DIGlobalVariableExpression(var: !36, expr: !DIExpression())
!36 = distinct !DIGlobalVariable(name: "pS4", scope: !2, file: !3, line: 903, type: !22, isLocal: true, isDefinition: true)
!37 = !DIGlobalVariableExpression(var: !38, expr: !DIExpression())
!38 = distinct !DIGlobalVariable(name: "pS5", scope: !2, file: !3, line: 904, type: !22, isLocal: true, isDefinition: true)
!39 = !DIGlobalVariableExpression(var: !40, expr: !DIExpression())
!40 = distinct !DIGlobalVariable(name: "qS1", scope: !2, file: !3, line: 905, type: !22, isLocal: true, isDefinition: true)
!41 = !DIGlobalVariableExpression(var: !42, expr: !DIExpression())
!42 = distinct !DIGlobalVariable(name: "qS2", scope: !2, file: !3, line: 906, type: !22, isLocal: true, isDefinition: true)
!43 = !DIGlobalVariableExpression(var: !44, expr: !DIExpression())
!44 = distinct !DIGlobalVariable(name: "qS3", scope: !2, file: !3, line: 907, type: !22, isLocal: true, isDefinition: true)
!45 = !DIGlobalVariableExpression(var: !46, expr: !DIExpression())
!46 = distinct !DIGlobalVariable(name: "qS4", scope: !2, file: !3, line: 908, type: !22, isLocal: true, isDefinition: true)
!47 = !DIGlobalVariableExpression(var: !48, expr: !DIExpression())
!48 = distinct !DIGlobalVariable(name: "one", scope: !49, file: !3, line: 969, type: !22, isLocal: true, isDefinition: true)
!49 = distinct !DISubprogram(name: "pts_ieee754_acosh", scope: !3, file: !3, line: 967, type: !4, scopeLine: 967, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!50 = !{}
!51 = !DIGlobalVariableExpression(var: !52, expr: !DIExpression())
!52 = distinct !DIGlobalVariable(name: "ln2", scope: !49, file: !3, line: 970, type: !22, isLocal: true, isDefinition: true)
!53 = !DIGlobalVariableExpression(var: !54, expr: !DIExpression())
!54 = distinct !DIGlobalVariable(name: "one", scope: !55, file: !3, line: 1024, type: !22, isLocal: true, isDefinition: true)
!55 = distinct !DISubprogram(name: "pts_ieee754_asin", scope: !3, file: !3, line: 1022, type: !4, scopeLine: 1022, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!56 = !DIGlobalVariableExpression(var: !57, expr: !DIExpression())
!57 = distinct !DIGlobalVariable(name: "huge", scope: !55, file: !3, line: 1025, type: !22, isLocal: true, isDefinition: true)
!58 = !DIGlobalVariableExpression(var: !59, expr: !DIExpression())
!59 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !55, file: !3, line: 1026, type: !22, isLocal: true, isDefinition: true)
!60 = !DIGlobalVariableExpression(var: !61, expr: !DIExpression())
!61 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !55, file: !3, line: 1027, type: !22, isLocal: true, isDefinition: true)
!62 = !DIGlobalVariableExpression(var: !63, expr: !DIExpression())
!63 = distinct !DIGlobalVariable(name: "pio4_hi", scope: !55, file: !3, line: 1028, type: !22, isLocal: true, isDefinition: true)
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(name: "pS0", scope: !55, file: !3, line: 1030, type: !22, isLocal: true, isDefinition: true)
!66 = !DIGlobalVariableExpression(var: !67, expr: !DIExpression())
!67 = distinct !DIGlobalVariable(name: "pS1", scope: !55, file: !3, line: 1031, type: !22, isLocal: true, isDefinition: true)
!68 = !DIGlobalVariableExpression(var: !69, expr: !DIExpression())
!69 = distinct !DIGlobalVariable(name: "pS2", scope: !55, file: !3, line: 1032, type: !22, isLocal: true, isDefinition: true)
!70 = !DIGlobalVariableExpression(var: !71, expr: !DIExpression())
!71 = distinct !DIGlobalVariable(name: "pS3", scope: !55, file: !3, line: 1033, type: !22, isLocal: true, isDefinition: true)
!72 = !DIGlobalVariableExpression(var: !73, expr: !DIExpression())
!73 = distinct !DIGlobalVariable(name: "pS4", scope: !55, file: !3, line: 1034, type: !22, isLocal: true, isDefinition: true)
!74 = !DIGlobalVariableExpression(var: !75, expr: !DIExpression())
!75 = distinct !DIGlobalVariable(name: "pS5", scope: !55, file: !3, line: 1035, type: !22, isLocal: true, isDefinition: true)
!76 = !DIGlobalVariableExpression(var: !77, expr: !DIExpression())
!77 = distinct !DIGlobalVariable(name: "qS1", scope: !55, file: !3, line: 1036, type: !22, isLocal: true, isDefinition: true)
!78 = !DIGlobalVariableExpression(var: !79, expr: !DIExpression())
!79 = distinct !DIGlobalVariable(name: "qS2", scope: !55, file: !3, line: 1037, type: !22, isLocal: true, isDefinition: true)
!80 = !DIGlobalVariableExpression(var: !81, expr: !DIExpression())
!81 = distinct !DIGlobalVariable(name: "qS3", scope: !55, file: !3, line: 1038, type: !22, isLocal: true, isDefinition: true)
!82 = !DIGlobalVariableExpression(var: !83, expr: !DIExpression())
!83 = distinct !DIGlobalVariable(name: "qS4", scope: !55, file: !3, line: 1039, type: !22, isLocal: true, isDefinition: true)
!84 = !DIGlobalVariableExpression(var: !85, expr: !DIExpression())
!85 = distinct !DIGlobalVariable(name: "one", scope: !86, file: !3, line: 1100, type: !22, isLocal: true, isDefinition: true)
!86 = distinct !DISubprogram(name: "pts_ieee754_asinh", scope: !3, file: !3, line: 1098, type: !4, scopeLine: 1098, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!87 = !DIGlobalVariableExpression(var: !88, expr: !DIExpression())
!88 = distinct !DIGlobalVariable(name: "ln2", scope: !86, file: !3, line: 1101, type: !22, isLocal: true, isDefinition: true)
!89 = !DIGlobalVariableExpression(var: !90, expr: !DIExpression())
!90 = distinct !DIGlobalVariable(name: "huge", scope: !86, file: !3, line: 1102, type: !22, isLocal: true, isDefinition: true)
!91 = !DIGlobalVariableExpression(var: !92, expr: !DIExpression())
!92 = distinct !DIGlobalVariable(name: "atanhi", scope: !93, file: !3, line: 1148, type: !94, isLocal: true, isDefinition: true)
!93 = distinct !DISubprogram(name: "pts_ieee754_atan", scope: !3, file: !3, line: 1147, type: !4, scopeLine: 1147, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!94 = !DICompositeType(tag: DW_TAG_array_type, baseType: !22, size: 256, elements: !95)
!95 = !{!96}
!96 = !DISubrange(count: 4)
!97 = !DIGlobalVariableExpression(var: !98, expr: !DIExpression())
!98 = distinct !DIGlobalVariable(name: "atanlo", scope: !93, file: !3, line: 1155, type: !94, isLocal: true, isDefinition: true)
!99 = !DIGlobalVariableExpression(var: !100, expr: !DIExpression())
!100 = distinct !DIGlobalVariable(name: "aT", scope: !93, file: !3, line: 1162, type: !101, isLocal: true, isDefinition: true)
!101 = !DICompositeType(tag: DW_TAG_array_type, baseType: !22, size: 704, elements: !102)
!102 = !{!103}
!103 = !DISubrange(count: 11)
!104 = !DIGlobalVariableExpression(var: !105, expr: !DIExpression())
!105 = distinct !DIGlobalVariable(name: "one", scope: !93, file: !3, line: 1176, type: !22, isLocal: true, isDefinition: true)
!106 = !DIGlobalVariableExpression(var: !107, expr: !DIExpression())
!107 = distinct !DIGlobalVariable(name: "huge", scope: !93, file: !3, line: 1176, type: !22, isLocal: true, isDefinition: true)
!108 = !DIGlobalVariableExpression(var: !109, expr: !DIExpression())
!109 = distinct !DIGlobalVariable(name: "tiny", scope: !110, file: !3, line: 1260, type: !14, isLocal: true, isDefinition: true)
!110 = distinct !DISubprogram(name: "pts_ieee754_atan2", scope: !3, file: !3, line: 1259, type: !111, scopeLine: 1259, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!111 = !DISubroutineType(types: !112)
!112 = !{!6, !6, !6}
!113 = !DIGlobalVariableExpression(var: !114, expr: !DIExpression())
!114 = distinct !DIGlobalVariable(name: "zero", scope: !110, file: !3, line: 1262, type: !22, isLocal: true, isDefinition: true)
!115 = !DIGlobalVariableExpression(var: !116, expr: !DIExpression())
!116 = distinct !DIGlobalVariable(name: "pi_o_4", scope: !110, file: !3, line: 1263, type: !22, isLocal: true, isDefinition: true)
!117 = !DIGlobalVariableExpression(var: !118, expr: !DIExpression())
!118 = distinct !DIGlobalVariable(name: "pi_o_2", scope: !110, file: !3, line: 1264, type: !22, isLocal: true, isDefinition: true)
!119 = !DIGlobalVariableExpression(var: !120, expr: !DIExpression())
!120 = distinct !DIGlobalVariable(name: "pi", scope: !110, file: !3, line: 1265, type: !22, isLocal: true, isDefinition: true)
!121 = !DIGlobalVariableExpression(var: !122, expr: !DIExpression())
!122 = distinct !DIGlobalVariable(name: "pi_lo", scope: !110, file: !3, line: 1266, type: !14, isLocal: true, isDefinition: true)
!123 = !DIGlobalVariableExpression(var: !124, expr: !DIExpression())
!124 = distinct !DIGlobalVariable(name: "one", scope: !125, file: !3, line: 1476, type: !22, isLocal: true, isDefinition: true)
!125 = distinct !DISubprogram(name: "pts_ieee754_exp", scope: !3, file: !3, line: 1474, type: !4, scopeLine: 1474, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!126 = !DIGlobalVariableExpression(var: !127, expr: !DIExpression())
!127 = distinct !DIGlobalVariable(name: "halF", scope: !125, file: !3, line: 1477, type: !128, isLocal: true, isDefinition: true)
!128 = !DICompositeType(tag: DW_TAG_array_type, baseType: !22, size: 128, elements: !129)
!129 = !{!130}
!130 = !DISubrange(count: 2)
!131 = !DIGlobalVariableExpression(var: !132, expr: !DIExpression())
!132 = distinct !DIGlobalVariable(name: "o_threshold", scope: !125, file: !3, line: 1478, type: !22, isLocal: true, isDefinition: true)
!133 = !DIGlobalVariableExpression(var: !134, expr: !DIExpression())
!134 = distinct !DIGlobalVariable(name: "u_threshold", scope: !125, file: !3, line: 1479, type: !22, isLocal: true, isDefinition: true)
!135 = !DIGlobalVariableExpression(var: !136, expr: !DIExpression())
!136 = distinct !DIGlobalVariable(name: "ln2HI", scope: !125, file: !3, line: 1480, type: !128, isLocal: true, isDefinition: true)
!137 = !DIGlobalVariableExpression(var: !138, expr: !DIExpression())
!138 = distinct !DIGlobalVariable(name: "ln2LO", scope: !125, file: !3, line: 1482, type: !128, isLocal: true, isDefinition: true)
!139 = !DIGlobalVariableExpression(var: !140, expr: !DIExpression())
!140 = distinct !DIGlobalVariable(name: "invln2", scope: !125, file: !3, line: 1484, type: !22, isLocal: true, isDefinition: true)
!141 = !DIGlobalVariableExpression(var: !142, expr: !DIExpression())
!142 = distinct !DIGlobalVariable(name: "P1", scope: !125, file: !3, line: 1485, type: !22, isLocal: true, isDefinition: true)
!143 = !DIGlobalVariableExpression(var: !144, expr: !DIExpression())
!144 = distinct !DIGlobalVariable(name: "P2", scope: !125, file: !3, line: 1486, type: !22, isLocal: true, isDefinition: true)
!145 = !DIGlobalVariableExpression(var: !146, expr: !DIExpression())
!146 = distinct !DIGlobalVariable(name: "P3", scope: !125, file: !3, line: 1487, type: !22, isLocal: true, isDefinition: true)
!147 = !DIGlobalVariableExpression(var: !148, expr: !DIExpression())
!148 = distinct !DIGlobalVariable(name: "P4", scope: !125, file: !3, line: 1488, type: !22, isLocal: true, isDefinition: true)
!149 = !DIGlobalVariableExpression(var: !150, expr: !DIExpression())
!150 = distinct !DIGlobalVariable(name: "P5", scope: !125, file: !3, line: 1489, type: !22, isLocal: true, isDefinition: true)
!151 = !DIGlobalVariableExpression(var: !152, expr: !DIExpression())
!152 = distinct !DIGlobalVariable(name: "E", scope: !125, file: !3, line: 1490, type: !22, isLocal: true, isDefinition: true)
!153 = !DIGlobalVariableExpression(var: !154, expr: !DIExpression())
!154 = distinct !DIGlobalVariable(name: "huge", scope: !125, file: !3, line: 1493, type: !14, isLocal: true, isDefinition: true)
!155 = !DIGlobalVariableExpression(var: !156, expr: !DIExpression())
!156 = distinct !DIGlobalVariable(name: "twom1000", scope: !125, file: !3, line: 1494, type: !14, isLocal: true, isDefinition: true)
!157 = !DIGlobalVariableExpression(var: !158, expr: !DIExpression())
!158 = distinct !DIGlobalVariable(name: "two1023", scope: !125, file: !3, line: 1495, type: !14, isLocal: true, isDefinition: true)
!159 = !DIGlobalVariableExpression(var: !160, expr: !DIExpression())
!160 = distinct !DIGlobalVariable(name: "one", scope: !161, file: !3, line: 1585, type: !22, isLocal: true, isDefinition: true)
!161 = distinct !DISubprogram(name: "pts_ieee754_atanh", scope: !3, file: !3, line: 1584, type: !4, scopeLine: 1584, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!162 = !DIGlobalVariableExpression(var: !163, expr: !DIExpression())
!163 = distinct !DIGlobalVariable(name: "huge", scope: !161, file: !3, line: 1585, type: !22, isLocal: true, isDefinition: true)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(name: "zero", scope: !161, file: !3, line: 1586, type: !22, isLocal: true, isDefinition: true)
!166 = !DIGlobalVariableExpression(var: !167, expr: !DIExpression())
!167 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !168, file: !3, line: 1667, type: !22, isLocal: true, isDefinition: true)
!168 = distinct !DISubprogram(name: "pts_ieee754_log", scope: !3, file: !3, line: 1665, type: !4, scopeLine: 1665, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!169 = !DIGlobalVariableExpression(var: !170, expr: !DIExpression())
!170 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !168, file: !3, line: 1668, type: !22, isLocal: true, isDefinition: true)
!171 = !DIGlobalVariableExpression(var: !172, expr: !DIExpression())
!172 = distinct !DIGlobalVariable(name: "two54", scope: !168, file: !3, line: 1669, type: !22, isLocal: true, isDefinition: true)
!173 = !DIGlobalVariableExpression(var: !174, expr: !DIExpression())
!174 = distinct !DIGlobalVariable(name: "Lg1", scope: !168, file: !3, line: 1670, type: !22, isLocal: true, isDefinition: true)
!175 = !DIGlobalVariableExpression(var: !176, expr: !DIExpression())
!176 = distinct !DIGlobalVariable(name: "Lg2", scope: !168, file: !3, line: 1671, type: !22, isLocal: true, isDefinition: true)
!177 = !DIGlobalVariableExpression(var: !178, expr: !DIExpression())
!178 = distinct !DIGlobalVariable(name: "Lg3", scope: !168, file: !3, line: 1672, type: !22, isLocal: true, isDefinition: true)
!179 = !DIGlobalVariableExpression(var: !180, expr: !DIExpression())
!180 = distinct !DIGlobalVariable(name: "Lg4", scope: !168, file: !3, line: 1673, type: !22, isLocal: true, isDefinition: true)
!181 = !DIGlobalVariableExpression(var: !182, expr: !DIExpression())
!182 = distinct !DIGlobalVariable(name: "Lg5", scope: !168, file: !3, line: 1674, type: !22, isLocal: true, isDefinition: true)
!183 = !DIGlobalVariableExpression(var: !184, expr: !DIExpression())
!184 = distinct !DIGlobalVariable(name: "Lg6", scope: !168, file: !3, line: 1675, type: !22, isLocal: true, isDefinition: true)
!185 = !DIGlobalVariableExpression(var: !186, expr: !DIExpression())
!186 = distinct !DIGlobalVariable(name: "Lg7", scope: !168, file: !3, line: 1676, type: !22, isLocal: true, isDefinition: true)
!187 = !DIGlobalVariableExpression(var: !188, expr: !DIExpression())
!188 = distinct !DIGlobalVariable(name: "zero", scope: !168, file: !3, line: 1678, type: !22, isLocal: true, isDefinition: true)
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !191, file: !3, line: 1812, type: !22, isLocal: true, isDefinition: true)
!191 = distinct !DISubprogram(name: "pts_ieee754_log1p", scope: !3, file: !3, line: 1810, type: !4, scopeLine: 1810, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!192 = !DIGlobalVariableExpression(var: !193, expr: !DIExpression())
!193 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !191, file: !3, line: 1813, type: !22, isLocal: true, isDefinition: true)
!194 = !DIGlobalVariableExpression(var: !195, expr: !DIExpression())
!195 = distinct !DIGlobalVariable(name: "two54", scope: !191, file: !3, line: 1814, type: !22, isLocal: true, isDefinition: true)
!196 = !DIGlobalVariableExpression(var: !197, expr: !DIExpression())
!197 = distinct !DIGlobalVariable(name: "Lp1", scope: !191, file: !3, line: 1815, type: !22, isLocal: true, isDefinition: true)
!198 = !DIGlobalVariableExpression(var: !199, expr: !DIExpression())
!199 = distinct !DIGlobalVariable(name: "Lp2", scope: !191, file: !3, line: 1816, type: !22, isLocal: true, isDefinition: true)
!200 = !DIGlobalVariableExpression(var: !201, expr: !DIExpression())
!201 = distinct !DIGlobalVariable(name: "Lp3", scope: !191, file: !3, line: 1817, type: !22, isLocal: true, isDefinition: true)
!202 = !DIGlobalVariableExpression(var: !203, expr: !DIExpression())
!203 = distinct !DIGlobalVariable(name: "Lp4", scope: !191, file: !3, line: 1818, type: !22, isLocal: true, isDefinition: true)
!204 = !DIGlobalVariableExpression(var: !205, expr: !DIExpression())
!205 = distinct !DIGlobalVariable(name: "Lp5", scope: !191, file: !3, line: 1819, type: !22, isLocal: true, isDefinition: true)
!206 = !DIGlobalVariableExpression(var: !207, expr: !DIExpression())
!207 = distinct !DIGlobalVariable(name: "Lp6", scope: !191, file: !3, line: 1820, type: !22, isLocal: true, isDefinition: true)
!208 = !DIGlobalVariableExpression(var: !209, expr: !DIExpression())
!209 = distinct !DIGlobalVariable(name: "Lp7", scope: !191, file: !3, line: 1821, type: !22, isLocal: true, isDefinition: true)
!210 = !DIGlobalVariableExpression(var: !211, expr: !DIExpression())
!211 = distinct !DIGlobalVariable(name: "zero", scope: !191, file: !3, line: 1823, type: !22, isLocal: true, isDefinition: true)
!212 = !DIGlobalVariableExpression(var: !213, expr: !DIExpression())
!213 = distinct !DIGlobalVariable(name: "two54", scope: !214, file: !3, line: 2002, type: !22, isLocal: true, isDefinition: true)
!214 = distinct !DISubprogram(name: "pts_ieee754_log2", scope: !3, file: !3, line: 2000, type: !4, scopeLine: 2000, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!215 = !DIGlobalVariableExpression(var: !216, expr: !DIExpression())
!216 = distinct !DIGlobalVariable(name: "ivln2hi", scope: !214, file: !3, line: 2003, type: !22, isLocal: true, isDefinition: true)
!217 = !DIGlobalVariableExpression(var: !218, expr: !DIExpression())
!218 = distinct !DIGlobalVariable(name: "ivln2lo", scope: !214, file: !3, line: 2004, type: !22, isLocal: true, isDefinition: true)
!219 = !DIGlobalVariableExpression(var: !220, expr: !DIExpression())
!220 = distinct !DIGlobalVariable(name: "two54", scope: !221, file: !3, line: 2108, type: !22, isLocal: true, isDefinition: true)
!221 = distinct !DISubprogram(name: "pts_ieee754_log10", scope: !3, file: !3, line: 2106, type: !4, scopeLine: 2106, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!222 = !DIGlobalVariableExpression(var: !223, expr: !DIExpression())
!223 = distinct !DIGlobalVariable(name: "ivln10", scope: !221, file: !3, line: 2109, type: !22, isLocal: true, isDefinition: true)
!224 = !DIGlobalVariableExpression(var: !225, expr: !DIExpression())
!225 = distinct !DIGlobalVariable(name: "log10_2hi", scope: !221, file: !3, line: 2110, type: !22, isLocal: true, isDefinition: true)
!226 = !DIGlobalVariableExpression(var: !227, expr: !DIExpression())
!227 = distinct !DIGlobalVariable(name: "log10_2lo", scope: !221, file: !3, line: 2111, type: !22, isLocal: true, isDefinition: true)
!228 = !DIGlobalVariableExpression(var: !229, expr: !DIExpression())
!229 = distinct !DIGlobalVariable(name: "one", scope: !230, file: !3, line: 2242, type: !22, isLocal: true, isDefinition: true)
!230 = distinct !DISubprogram(name: "pts_ieee754_expm1", scope: !3, file: !3, line: 2240, type: !4, scopeLine: 2240, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!231 = !DIGlobalVariableExpression(var: !232, expr: !DIExpression())
!232 = distinct !DIGlobalVariable(name: "tiny", scope: !230, file: !3, line: 2243, type: !22, isLocal: true, isDefinition: true)
!233 = !DIGlobalVariableExpression(var: !234, expr: !DIExpression())
!234 = distinct !DIGlobalVariable(name: "o_threshold", scope: !230, file: !3, line: 2244, type: !22, isLocal: true, isDefinition: true)
!235 = !DIGlobalVariableExpression(var: !236, expr: !DIExpression())
!236 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !230, file: !3, line: 2245, type: !22, isLocal: true, isDefinition: true)
!237 = !DIGlobalVariableExpression(var: !238, expr: !DIExpression())
!238 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !230, file: !3, line: 2246, type: !22, isLocal: true, isDefinition: true)
!239 = !DIGlobalVariableExpression(var: !240, expr: !DIExpression())
!240 = distinct !DIGlobalVariable(name: "invln2", scope: !230, file: !3, line: 2247, type: !22, isLocal: true, isDefinition: true)
!241 = !DIGlobalVariableExpression(var: !242, expr: !DIExpression())
!242 = distinct !DIGlobalVariable(name: "Q1", scope: !230, file: !3, line: 2250, type: !22, isLocal: true, isDefinition: true)
!243 = !DIGlobalVariableExpression(var: !244, expr: !DIExpression())
!244 = distinct !DIGlobalVariable(name: "Q2", scope: !230, file: !3, line: 2251, type: !22, isLocal: true, isDefinition: true)
!245 = !DIGlobalVariableExpression(var: !246, expr: !DIExpression())
!246 = distinct !DIGlobalVariable(name: "Q3", scope: !230, file: !3, line: 2252, type: !22, isLocal: true, isDefinition: true)
!247 = !DIGlobalVariableExpression(var: !248, expr: !DIExpression())
!248 = distinct !DIGlobalVariable(name: "Q4", scope: !230, file: !3, line: 2253, type: !22, isLocal: true, isDefinition: true)
!249 = !DIGlobalVariableExpression(var: !250, expr: !DIExpression())
!250 = distinct !DIGlobalVariable(name: "Q5", scope: !230, file: !3, line: 2254, type: !22, isLocal: true, isDefinition: true)
!251 = !DIGlobalVariableExpression(var: !252, expr: !DIExpression())
!252 = distinct !DIGlobalVariable(name: "huge", scope: !230, file: !3, line: 2256, type: !14, isLocal: true, isDefinition: true)
!253 = !DIGlobalVariableExpression(var: !254, expr: !DIExpression())
!254 = distinct !DIGlobalVariable(name: "B1", scope: !255, file: !3, line: 2362, type: !256, isLocal: true, isDefinition: true)
!255 = distinct !DISubprogram(name: "pts_ieee754_cbrt", scope: !3, file: !3, line: 2360, type: !4, scopeLine: 2360, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!256 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!257 = !DIGlobalVariableExpression(var: !258, expr: !DIExpression())
!258 = distinct !DIGlobalVariable(name: "B2", scope: !255, file: !3, line: 2363, type: !256, isLocal: true, isDefinition: true)
!259 = !DIGlobalVariableExpression(var: !260, expr: !DIExpression())
!260 = distinct !DIGlobalVariable(name: "P0", scope: !255, file: !3, line: 2366, type: !22, isLocal: true, isDefinition: true)
!261 = !DIGlobalVariableExpression(var: !262, expr: !DIExpression())
!262 = distinct !DIGlobalVariable(name: "P1", scope: !255, file: !3, line: 2367, type: !22, isLocal: true, isDefinition: true)
!263 = !DIGlobalVariableExpression(var: !264, expr: !DIExpression())
!264 = distinct !DIGlobalVariable(name: "P2", scope: !255, file: !3, line: 2368, type: !22, isLocal: true, isDefinition: true)
!265 = !DIGlobalVariableExpression(var: !266, expr: !DIExpression())
!266 = distinct !DIGlobalVariable(name: "P3", scope: !255, file: !3, line: 2369, type: !22, isLocal: true, isDefinition: true)
!267 = !DIGlobalVariableExpression(var: !268, expr: !DIExpression())
!268 = distinct !DIGlobalVariable(name: "P4", scope: !255, file: !3, line: 2370, type: !22, isLocal: true, isDefinition: true)
!269 = !DIGlobalVariableExpression(var: !270, expr: !DIExpression())
!270 = distinct !DIGlobalVariable(name: "KCOSH_OVERFLOW", scope: !271, file: !3, line: 2578, type: !22, isLocal: true, isDefinition: true)
!271 = distinct !DISubprogram(name: "pts_ieee754_cosh", scope: !3, file: !3, line: 2577, type: !4, scopeLine: 2577, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!272 = !DIGlobalVariableExpression(var: !273, expr: !DIExpression())
!273 = distinct !DIGlobalVariable(name: "one", scope: !271, file: !3, line: 2579, type: !22, isLocal: true, isDefinition: true)
!274 = !DIGlobalVariableExpression(var: !275, expr: !DIExpression())
!275 = distinct !DIGlobalVariable(name: "half", scope: !271, file: !3, line: 2579, type: !22, isLocal: true, isDefinition: true)
!276 = !DIGlobalVariableExpression(var: !277, expr: !DIExpression())
!277 = distinct !DIGlobalVariable(name: "huge", scope: !271, file: !3, line: 2580, type: !14, isLocal: true, isDefinition: true)
!278 = !DIGlobalVariableExpression(var: !279, expr: !DIExpression())
!279 = distinct !DIGlobalVariable(name: "KSINH_OVERFLOW", scope: !280, file: !3, line: 2642, type: !22, isLocal: true, isDefinition: true)
!280 = distinct !DISubprogram(name: "pts_ieee754_sinh", scope: !3, file: !3, line: 2641, type: !4, scopeLine: 2641, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!281 = !DIGlobalVariableExpression(var: !282, expr: !DIExpression())
!282 = distinct !DIGlobalVariable(name: "TWO_M28", scope: !280, file: !3, line: 2643, type: !22, isLocal: true, isDefinition: true)
!283 = !DIGlobalVariableExpression(var: !284, expr: !DIExpression())
!284 = distinct !DIGlobalVariable(name: "LOG_MAXD", scope: !280, file: !3, line: 2645, type: !22, isLocal: true, isDefinition: true)
!285 = !DIGlobalVariableExpression(var: !286, expr: !DIExpression())
!286 = distinct !DIGlobalVariable(name: "shuge", scope: !280, file: !3, line: 2646, type: !22, isLocal: true, isDefinition: true)
!287 = !DIGlobalVariableExpression(var: !288, expr: !DIExpression())
!288 = distinct !DIGlobalVariable(name: "tiny", scope: !289, file: !3, line: 2698, type: !13, isLocal: true, isDefinition: true)
!289 = distinct !DISubprogram(name: "pts_ieee754_tanh", scope: !3, file: !3, line: 2697, type: !4, scopeLine: 2697, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!290 = !DIGlobalVariableExpression(var: !291, expr: !DIExpression())
!291 = distinct !DIGlobalVariable(name: "one", scope: !289, file: !3, line: 2699, type: !22, isLocal: true, isDefinition: true)
!292 = !DIGlobalVariableExpression(var: !293, expr: !DIExpression())
!293 = distinct !DIGlobalVariable(name: "two", scope: !289, file: !3, line: 2699, type: !22, isLocal: true, isDefinition: true)
!294 = !DIGlobalVariableExpression(var: !295, expr: !DIExpression())
!295 = distinct !DIGlobalVariable(name: "huge", scope: !289, file: !3, line: 2699, type: !22, isLocal: true, isDefinition: true)
!296 = !DIGlobalVariableExpression(var: !297, expr: !DIExpression())
!297 = distinct !DIGlobalVariable(name: "one", scope: !298, file: !3, line: 338, type: !22, isLocal: true, isDefinition: true)
!298 = distinct !DISubprogram(name: "__kernel_cos", scope: !3, file: !3, line: 336, type: !111, scopeLine: 336, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!299 = !DIGlobalVariableExpression(var: !300, expr: !DIExpression())
!300 = distinct !DIGlobalVariable(name: "C1", scope: !298, file: !3, line: 339, type: !22, isLocal: true, isDefinition: true)
!301 = !DIGlobalVariableExpression(var: !302, expr: !DIExpression())
!302 = distinct !DIGlobalVariable(name: "C2", scope: !298, file: !3, line: 340, type: !22, isLocal: true, isDefinition: true)
!303 = !DIGlobalVariableExpression(var: !304, expr: !DIExpression())
!304 = distinct !DIGlobalVariable(name: "C3", scope: !298, file: !3, line: 341, type: !22, isLocal: true, isDefinition: true)
!305 = !DIGlobalVariableExpression(var: !306, expr: !DIExpression())
!306 = distinct !DIGlobalVariable(name: "C4", scope: !298, file: !3, line: 342, type: !22, isLocal: true, isDefinition: true)
!307 = !DIGlobalVariableExpression(var: !308, expr: !DIExpression())
!308 = distinct !DIGlobalVariable(name: "C5", scope: !298, file: !3, line: 343, type: !22, isLocal: true, isDefinition: true)
!309 = !DIGlobalVariableExpression(var: !310, expr: !DIExpression())
!310 = distinct !DIGlobalVariable(name: "C6", scope: !298, file: !3, line: 344, type: !22, isLocal: true, isDefinition: true)
!311 = !DIGlobalVariableExpression(var: !312, expr: !DIExpression())
!312 = distinct !DIGlobalVariable(name: "two_over_pi", scope: !313, file: !3, line: 153, type: !317, isLocal: true, isDefinition: true)
!313 = distinct !DISubprogram(name: "__ieee754_rem_pio2", scope: !3, file: !3, line: 149, type: !314, scopeLine: 149, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!314 = !DISubroutineType(types: !315)
!315 = !{!18, !6, !316}
!316 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!317 = !DICompositeType(tag: DW_TAG_array_type, baseType: !318, size: 2112, elements: !319)
!318 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !18)
!319 = !{!320}
!320 = !DISubrange(count: 66)
!321 = !DIGlobalVariableExpression(var: !322, expr: !DIExpression())
!322 = distinct !DIGlobalVariable(name: "npio2_hw", scope: !313, file: !3, line: 166, type: !323, isLocal: true, isDefinition: true)
!323 = !DICompositeType(tag: DW_TAG_array_type, baseType: !318, size: 1024, elements: !324)
!324 = !{!325}
!325 = !DISubrange(count: 32)
!326 = !DIGlobalVariableExpression(var: !327, expr: !DIExpression())
!327 = distinct !DIGlobalVariable(name: "zero", scope: !313, file: !3, line: 186, type: !22, isLocal: true, isDefinition: true)
!328 = !DIGlobalVariableExpression(var: !329, expr: !DIExpression())
!329 = distinct !DIGlobalVariable(name: "half", scope: !313, file: !3, line: 187, type: !22, isLocal: true, isDefinition: true)
!330 = !DIGlobalVariableExpression(var: !331, expr: !DIExpression())
!331 = distinct !DIGlobalVariable(name: "two24", scope: !313, file: !3, line: 188, type: !22, isLocal: true, isDefinition: true)
!332 = !DIGlobalVariableExpression(var: !333, expr: !DIExpression())
!333 = distinct !DIGlobalVariable(name: "invpio2", scope: !313, file: !3, line: 189, type: !22, isLocal: true, isDefinition: true)
!334 = !DIGlobalVariableExpression(var: !335, expr: !DIExpression())
!335 = distinct !DIGlobalVariable(name: "pio2_1", scope: !313, file: !3, line: 190, type: !22, isLocal: true, isDefinition: true)
!336 = !DIGlobalVariableExpression(var: !337, expr: !DIExpression())
!337 = distinct !DIGlobalVariable(name: "pio2_1t", scope: !313, file: !3, line: 191, type: !22, isLocal: true, isDefinition: true)
!338 = !DIGlobalVariableExpression(var: !339, expr: !DIExpression())
!339 = distinct !DIGlobalVariable(name: "pio2_2", scope: !313, file: !3, line: 192, type: !22, isLocal: true, isDefinition: true)
!340 = !DIGlobalVariableExpression(var: !341, expr: !DIExpression())
!341 = distinct !DIGlobalVariable(name: "pio2_2t", scope: !313, file: !3, line: 193, type: !22, isLocal: true, isDefinition: true)
!342 = !DIGlobalVariableExpression(var: !343, expr: !DIExpression())
!343 = distinct !DIGlobalVariable(name: "pio2_3", scope: !313, file: !3, line: 194, type: !22, isLocal: true, isDefinition: true)
!344 = !DIGlobalVariableExpression(var: !345, expr: !DIExpression())
!345 = distinct !DIGlobalVariable(name: "pio2_3t", scope: !313, file: !3, line: 195, type: !22, isLocal: true, isDefinition: true)
!346 = !DIGlobalVariableExpression(var: !347, expr: !DIExpression())
!347 = distinct !DIGlobalVariable(name: "init_jk", scope: !348, file: !3, line: 482, type: !352, isLocal: true, isDefinition: true)
!348 = distinct !DISubprogram(name: "__kernel_rem_pio2", scope: !3, file: !3, line: 474, type: !349, scopeLine: 475, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!349 = !DISubroutineType(types: !350)
!350 = !{!15, !316, !316, !15, !15, !15, !351}
!351 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !318, size: 64)
!352 = !DICompositeType(tag: DW_TAG_array_type, baseType: !353, size: 128, elements: !95)
!353 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !15)
!354 = !DIGlobalVariableExpression(var: !355, expr: !DIExpression())
!355 = distinct !DIGlobalVariable(name: "PIo2", scope: !348, file: !3, line: 484, type: !356, isLocal: true, isDefinition: true)
!356 = !DICompositeType(tag: DW_TAG_array_type, baseType: !22, size: 512, elements: !357)
!357 = !{!358}
!358 = !DISubrange(count: 8)
!359 = !DIGlobalVariableExpression(var: !360, expr: !DIExpression())
!360 = distinct !DIGlobalVariable(name: "zero", scope: !348, file: !3, line: 496, type: !22, isLocal: true, isDefinition: true)
!361 = !DIGlobalVariableExpression(var: !362, expr: !DIExpression())
!362 = distinct !DIGlobalVariable(name: "one", scope: !348, file: !3, line: 497, type: !22, isLocal: true, isDefinition: true)
!363 = !DIGlobalVariableExpression(var: !364, expr: !DIExpression())
!364 = distinct !DIGlobalVariable(name: "two24", scope: !348, file: !3, line: 498, type: !22, isLocal: true, isDefinition: true)
!365 = !DIGlobalVariableExpression(var: !366, expr: !DIExpression())
!366 = distinct !DIGlobalVariable(name: "twon24", scope: !348, file: !3, line: 499, type: !22, isLocal: true, isDefinition: true)
!367 = !DIGlobalVariableExpression(var: !368, expr: !DIExpression())
!368 = distinct !DIGlobalVariable(name: "half", scope: !369, file: !3, line: 706, type: !22, isLocal: true, isDefinition: true)
!369 = distinct !DISubprogram(name: "__kernel_sin", scope: !3, file: !3, line: 704, type: !370, scopeLine: 704, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!370 = !DISubroutineType(types: !371)
!371 = !{!6, !6, !6, !15}
!372 = !DIGlobalVariableExpression(var: !373, expr: !DIExpression())
!373 = distinct !DIGlobalVariable(name: "S1", scope: !369, file: !3, line: 707, type: !22, isLocal: true, isDefinition: true)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "S2", scope: !369, file: !3, line: 708, type: !22, isLocal: true, isDefinition: true)
!376 = !DIGlobalVariableExpression(var: !377, expr: !DIExpression())
!377 = distinct !DIGlobalVariable(name: "S3", scope: !369, file: !3, line: 709, type: !22, isLocal: true, isDefinition: true)
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(name: "S4", scope: !369, file: !3, line: 710, type: !22, isLocal: true, isDefinition: true)
!380 = !DIGlobalVariableExpression(var: !381, expr: !DIExpression())
!381 = distinct !DIGlobalVariable(name: "S5", scope: !369, file: !3, line: 711, type: !22, isLocal: true, isDefinition: true)
!382 = !DIGlobalVariableExpression(var: !383, expr: !DIExpression())
!383 = distinct !DIGlobalVariable(name: "S6", scope: !369, file: !3, line: 712, type: !22, isLocal: true, isDefinition: true)
!384 = !DIGlobalVariableExpression(var: !385, expr: !DIExpression(DW_OP_constu, 4600877379321592324, DW_OP_stack_value))
!385 = distinct !DIGlobalVariable(name: "Lg2", scope: !7, file: !3, line: 1967, type: !22, isLocal: true, isDefinition: true)
!386 = !DIGlobalVariableExpression(var: !387, expr: !DIExpression(DW_OP_constu, 4597174411056806063, DW_OP_stack_value))
!387 = distinct !DIGlobalVariable(name: "Lg4", scope: !7, file: !3, line: 1969, type: !22, isLocal: true, isDefinition: true)
!388 = !DIGlobalVariableExpression(var: !389, expr: !DIExpression(DW_OP_constu, 4594685411790997151, DW_OP_stack_value))
!389 = distinct !DIGlobalVariable(name: "Lg6", scope: !7, file: !3, line: 1971, type: !22, isLocal: true, isDefinition: true)
!390 = !DIGlobalVariableExpression(var: !391, expr: !DIExpression(DW_OP_constu, 4604180019048437139, DW_OP_stack_value))
!391 = distinct !DIGlobalVariable(name: "Lg1", scope: !7, file: !3, line: 1966, type: !22, isLocal: true, isDefinition: true)
!392 = !DIGlobalVariableExpression(var: !393, expr: !DIExpression(DW_OP_constu, 4598818590951641945, DW_OP_stack_value))
!393 = distinct !DIGlobalVariable(name: "Lg3", scope: !7, file: !3, line: 1968, type: !22, isLocal: true, isDefinition: true)
!394 = !DIGlobalVariableExpression(var: !395, expr: !DIExpression(DW_OP_constu, 4595719342595441630, DW_OP_stack_value))
!395 = distinct !DIGlobalVariable(name: "Lg5", scope: !7, file: !3, line: 1970, type: !22, isLocal: true, isDefinition: true)
!396 = !DIGlobalVariableExpression(var: !397, expr: !DIExpression(DW_OP_constu, 4594499633228436036, DW_OP_stack_value))
!397 = distinct !DIGlobalVariable(name: "Lg7", scope: !7, file: !3, line: 1972, type: !22, isLocal: true, isDefinition: true)
!398 = !DIGlobalVariableExpression(var: !399, expr: !DIExpression())
!399 = distinct !DIGlobalVariable(name: "xxx", scope: !400, file: !3, line: 765, type: !401, isLocal: true, isDefinition: true)
!400 = distinct !DISubprogram(name: "__kernel_tan", scope: !3, file: !3, line: 764, type: !370, scopeLine: 764, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!401 = !DICompositeType(tag: DW_TAG_array_type, baseType: !22, size: 1024, elements: !402)
!402 = !{!403}
!403 = !DISubrange(count: 16)
!404 = !{i32 7, !"Dwarf Version", i32 4}
!405 = !{i32 2, !"Debug Info Version", i32 3}
!406 = !{i32 1, !"wchar_size", i32 4}
!407 = !{i32 8, !"PIC Level", i32 2}
!408 = !{i32 7, !"uwtable", i32 1}
!409 = !{i32 7, !"frame-pointer", i32 1}
!410 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!411 = !DILocalVariable(name: "x", arg: 1, scope: !2, file: !3, line: 893, type: !6)
!412 = !DILocation(line: 893, column: 32, scope: !2)
!413 = !DILocalVariable(name: "z", scope: !2, file: !3, line: 910, type: !6)
!414 = !DILocation(line: 910, column: 10, scope: !2)
!415 = !DILocalVariable(name: "p", scope: !2, file: !3, line: 910, type: !6)
!416 = !DILocation(line: 910, column: 13, scope: !2)
!417 = !DILocalVariable(name: "q", scope: !2, file: !3, line: 910, type: !6)
!418 = !DILocation(line: 910, column: 16, scope: !2)
!419 = !DILocalVariable(name: "r", scope: !2, file: !3, line: 910, type: !6)
!420 = !DILocation(line: 910, column: 19, scope: !2)
!421 = !DILocalVariable(name: "w", scope: !2, file: !3, line: 910, type: !6)
!422 = !DILocation(line: 910, column: 22, scope: !2)
!423 = !DILocalVariable(name: "s", scope: !2, file: !3, line: 910, type: !6)
!424 = !DILocation(line: 910, column: 25, scope: !2)
!425 = !DILocalVariable(name: "c", scope: !2, file: !3, line: 910, type: !6)
!426 = !DILocation(line: 910, column: 28, scope: !2)
!427 = !DILocalVariable(name: "df", scope: !2, file: !3, line: 910, type: !6)
!428 = !DILocation(line: 910, column: 31, scope: !2)
!429 = !DILocalVariable(name: "hx", scope: !2, file: !3, line: 911, type: !18)
!430 = !DILocation(line: 911, column: 11, scope: !2)
!431 = !DILocalVariable(name: "ix", scope: !2, file: !3, line: 911, type: !18)
!432 = !DILocation(line: 911, column: 15, scope: !2)
!433 = !DILocation(line: 912, column: 3, scope: !2)
!434 = !DILocalVariable(name: "bits", scope: !435, file: !3, line: 912, type: !16)
!435 = distinct !DILexicalBlock(scope: !2, file: !3, line: 912, column: 3)
!436 = !DILocation(line: 912, column: 3, scope: !435)
!437 = !DILocation(line: 913, column: 8, scope: !2)
!438 = !DILocation(line: 913, column: 11, scope: !2)
!439 = !DILocation(line: 913, column: 6, scope: !2)
!440 = !DILocation(line: 914, column: 7, scope: !441)
!441 = distinct !DILexicalBlock(scope: !2, file: !3, line: 914, column: 7)
!442 = !DILocation(line: 914, column: 10, scope: !441)
!443 = !DILocation(line: 914, column: 7, scope: !2)
!444 = !DILocalVariable(name: "lx", scope: !445, file: !3, line: 915, type: !9)
!445 = distinct !DILexicalBlock(scope: !441, file: !3, line: 914, column: 25)
!446 = !DILocation(line: 915, column: 14, scope: !445)
!447 = !DILocation(line: 916, column: 5, scope: !445)
!448 = !DILocalVariable(name: "bits", scope: !449, file: !3, line: 916, type: !16)
!449 = distinct !DILexicalBlock(scope: !445, file: !3, line: 916, column: 5)
!450 = !DILocation(line: 916, column: 5, scope: !449)
!451 = !DILocation(line: 917, column: 11, scope: !452)
!452 = distinct !DILexicalBlock(scope: !445, file: !3, line: 917, column: 9)
!453 = !DILocation(line: 917, column: 14, scope: !452)
!454 = !DILocation(line: 917, column: 30, scope: !452)
!455 = !DILocation(line: 917, column: 28, scope: !452)
!456 = !DILocation(line: 917, column: 34, scope: !452)
!457 = !DILocation(line: 917, column: 9, scope: !445)
!458 = !DILocation(line: 918, column: 11, scope: !459)
!459 = distinct !DILexicalBlock(scope: !460, file: !3, line: 918, column: 11)
!460 = distinct !DILexicalBlock(scope: !452, file: !3, line: 917, column: 40)
!461 = !DILocation(line: 918, column: 14, scope: !459)
!462 = !DILocation(line: 918, column: 11, scope: !460)
!463 = !DILocation(line: 919, column: 9, scope: !459)
!464 = !DILocation(line: 921, column: 9, scope: !459)
!465 = !DILocation(line: 923, column: 5, scope: !445)
!466 = !DILocation(line: 925, column: 7, scope: !467)
!467 = distinct !DILexicalBlock(scope: !2, file: !3, line: 925, column: 7)
!468 = !DILocation(line: 925, column: 10, scope: !467)
!469 = !DILocation(line: 925, column: 7, scope: !2)
!470 = !DILocation(line: 926, column: 9, scope: !471)
!471 = distinct !DILexicalBlock(scope: !472, file: !3, line: 926, column: 9)
!472 = distinct !DILexicalBlock(scope: !467, file: !3, line: 925, column: 24)
!473 = !DILocation(line: 926, column: 12, scope: !471)
!474 = !DILocation(line: 926, column: 9, scope: !472)
!475 = !DILocation(line: 926, column: 27, scope: !471)
!476 = !DILocation(line: 927, column: 9, scope: !472)
!477 = !DILocation(line: 927, column: 13, scope: !472)
!478 = !DILocation(line: 927, column: 11, scope: !472)
!479 = !DILocation(line: 927, column: 7, scope: !472)
!480 = !DILocation(line: 928, column: 9, scope: !472)
!481 = !DILocation(line: 928, column: 20, scope: !472)
!482 = !DILocation(line: 928, column: 31, scope: !472)
!483 = !DILocation(line: 928, column: 42, scope: !472)
!484 = !DILocation(line: 928, column: 53, scope: !472)
!485 = !DILocation(line: 928, column: 64, scope: !472)
!486 = !DILocation(line: 928, column: 62, scope: !472)
!487 = !DILocation(line: 928, column: 51, scope: !472)
!488 = !DILocation(line: 928, column: 40, scope: !472)
!489 = !DILocation(line: 928, column: 29, scope: !472)
!490 = !DILocation(line: 928, column: 18, scope: !472)
!491 = !DILocation(line: 928, column: 11, scope: !472)
!492 = !DILocation(line: 928, column: 7, scope: !472)
!493 = !DILocation(line: 929, column: 15, scope: !472)
!494 = !DILocation(line: 929, column: 26, scope: !472)
!495 = !DILocation(line: 929, column: 37, scope: !472)
!496 = !DILocation(line: 929, column: 48, scope: !472)
!497 = !DILocation(line: 929, column: 46, scope: !472)
!498 = !DILocation(line: 929, column: 35, scope: !472)
!499 = !DILocation(line: 929, column: 24, scope: !472)
!500 = !DILocation(line: 929, column: 13, scope: !472)
!501 = !DILocation(line: 929, column: 7, scope: !472)
!502 = !DILocation(line: 930, column: 9, scope: !472)
!503 = !DILocation(line: 930, column: 13, scope: !472)
!504 = !DILocation(line: 930, column: 11, scope: !472)
!505 = !DILocation(line: 930, column: 7, scope: !472)
!506 = !DILocation(line: 931, column: 23, scope: !472)
!507 = !DILocation(line: 931, column: 38, scope: !472)
!508 = !DILocation(line: 931, column: 42, scope: !472)
!509 = !DILocation(line: 931, column: 36, scope: !472)
!510 = !DILocation(line: 931, column: 25, scope: !472)
!511 = !DILocation(line: 931, column: 20, scope: !472)
!512 = !DILocation(line: 931, column: 5, scope: !472)
!513 = !DILocation(line: 932, column: 14, scope: !514)
!514 = distinct !DILexicalBlock(scope: !467, file: !3, line: 932, column: 14)
!515 = !DILocation(line: 932, column: 17, scope: !514)
!516 = !DILocation(line: 932, column: 14, scope: !467)
!517 = !DILocation(line: 933, column: 16, scope: !518)
!518 = distinct !DILexicalBlock(scope: !514, file: !3, line: 932, column: 22)
!519 = !DILocation(line: 933, column: 14, scope: !518)
!520 = !DILocation(line: 933, column: 19, scope: !518)
!521 = !DILocation(line: 933, column: 7, scope: !518)
!522 = !DILocation(line: 934, column: 9, scope: !518)
!523 = !DILocation(line: 934, column: 20, scope: !518)
!524 = !DILocation(line: 934, column: 31, scope: !518)
!525 = !DILocation(line: 934, column: 42, scope: !518)
!526 = !DILocation(line: 934, column: 53, scope: !518)
!527 = !DILocation(line: 934, column: 64, scope: !518)
!528 = !DILocation(line: 934, column: 62, scope: !518)
!529 = !DILocation(line: 934, column: 51, scope: !518)
!530 = !DILocation(line: 934, column: 40, scope: !518)
!531 = !DILocation(line: 934, column: 29, scope: !518)
!532 = !DILocation(line: 934, column: 18, scope: !518)
!533 = !DILocation(line: 934, column: 11, scope: !518)
!534 = !DILocation(line: 934, column: 7, scope: !518)
!535 = !DILocation(line: 935, column: 15, scope: !518)
!536 = !DILocation(line: 935, column: 26, scope: !518)
!537 = !DILocation(line: 935, column: 37, scope: !518)
!538 = !DILocation(line: 935, column: 48, scope: !518)
!539 = !DILocation(line: 935, column: 46, scope: !518)
!540 = !DILocation(line: 935, column: 35, scope: !518)
!541 = !DILocation(line: 935, column: 24, scope: !518)
!542 = !DILocation(line: 935, column: 13, scope: !518)
!543 = !DILocation(line: 935, column: 7, scope: !518)
!544 = !DILocation(line: 936, column: 14, scope: !518)
!545 = !DILocation(line: 936, column: 9, scope: !518)
!546 = !DILocation(line: 936, column: 7, scope: !518)
!547 = !DILocation(line: 937, column: 9, scope: !518)
!548 = !DILocation(line: 937, column: 13, scope: !518)
!549 = !DILocation(line: 937, column: 11, scope: !518)
!550 = !DILocation(line: 937, column: 7, scope: !518)
!551 = !DILocation(line: 938, column: 9, scope: !518)
!552 = !DILocation(line: 938, column: 13, scope: !518)
!553 = !DILocation(line: 938, column: 15, scope: !518)
!554 = !DILocation(line: 938, column: 7, scope: !518)
!555 = !DILocation(line: 939, column: 24, scope: !518)
!556 = !DILocation(line: 939, column: 28, scope: !518)
!557 = !DILocation(line: 939, column: 26, scope: !518)
!558 = !DILocation(line: 939, column: 15, scope: !518)
!559 = !DILocation(line: 939, column: 5, scope: !518)
!560 = !DILocation(line: 941, column: 16, scope: !561)
!561 = distinct !DILexicalBlock(scope: !514, file: !3, line: 940, column: 10)
!562 = !DILocation(line: 941, column: 14, scope: !561)
!563 = !DILocation(line: 941, column: 19, scope: !561)
!564 = !DILocation(line: 941, column: 7, scope: !561)
!565 = !DILocation(line: 942, column: 14, scope: !561)
!566 = !DILocation(line: 942, column: 9, scope: !561)
!567 = !DILocation(line: 942, column: 7, scope: !561)
!568 = !DILocation(line: 943, column: 10, scope: !561)
!569 = !DILocation(line: 943, column: 8, scope: !561)
!570 = !DILocation(line: 944, column: 5, scope: !561)
!571 = !DILocalVariable(name: "bits", scope: !572, file: !3, line: 944, type: !16)
!572 = distinct !DILexicalBlock(scope: !561, file: !3, line: 944, column: 5)
!573 = !DILocation(line: 944, column: 5, scope: !572)
!574 = !DILocation(line: 945, column: 10, scope: !561)
!575 = !DILocation(line: 945, column: 14, scope: !561)
!576 = !DILocation(line: 945, column: 19, scope: !561)
!577 = !DILocation(line: 945, column: 12, scope: !561)
!578 = !DILocation(line: 945, column: 26, scope: !561)
!579 = !DILocation(line: 945, column: 30, scope: !561)
!580 = !DILocation(line: 945, column: 28, scope: !561)
!581 = !DILocation(line: 945, column: 23, scope: !561)
!582 = !DILocation(line: 945, column: 7, scope: !561)
!583 = !DILocation(line: 946, column: 9, scope: !561)
!584 = !DILocation(line: 946, column: 20, scope: !561)
!585 = !DILocation(line: 946, column: 31, scope: !561)
!586 = !DILocation(line: 946, column: 42, scope: !561)
!587 = !DILocation(line: 946, column: 53, scope: !561)
!588 = !DILocation(line: 946, column: 64, scope: !561)
!589 = !DILocation(line: 946, column: 62, scope: !561)
!590 = !DILocation(line: 946, column: 51, scope: !561)
!591 = !DILocation(line: 946, column: 40, scope: !561)
!592 = !DILocation(line: 946, column: 29, scope: !561)
!593 = !DILocation(line: 946, column: 18, scope: !561)
!594 = !DILocation(line: 946, column: 11, scope: !561)
!595 = !DILocation(line: 946, column: 7, scope: !561)
!596 = !DILocation(line: 947, column: 15, scope: !561)
!597 = !DILocation(line: 947, column: 26, scope: !561)
!598 = !DILocation(line: 947, column: 37, scope: !561)
!599 = !DILocation(line: 947, column: 48, scope: !561)
!600 = !DILocation(line: 947, column: 46, scope: !561)
!601 = !DILocation(line: 947, column: 35, scope: !561)
!602 = !DILocation(line: 947, column: 24, scope: !561)
!603 = !DILocation(line: 947, column: 13, scope: !561)
!604 = !DILocation(line: 947, column: 7, scope: !561)
!605 = !DILocation(line: 948, column: 9, scope: !561)
!606 = !DILocation(line: 948, column: 13, scope: !561)
!607 = !DILocation(line: 948, column: 11, scope: !561)
!608 = !DILocation(line: 948, column: 7, scope: !561)
!609 = !DILocation(line: 949, column: 9, scope: !561)
!610 = !DILocation(line: 949, column: 13, scope: !561)
!611 = !DILocation(line: 949, column: 17, scope: !561)
!612 = !DILocation(line: 949, column: 15, scope: !561)
!613 = !DILocation(line: 949, column: 7, scope: !561)
!614 = !DILocation(line: 950, column: 19, scope: !561)
!615 = !DILocation(line: 950, column: 24, scope: !561)
!616 = !DILocation(line: 950, column: 22, scope: !561)
!617 = !DILocation(line: 950, column: 16, scope: !561)
!618 = !DILocation(line: 950, column: 5, scope: !561)
!619 = !DILocation(line: 952, column: 1, scope: !2)
!620 = distinct !DISubprogram(name: "bits_of", scope: !3, file: !3, line: 54, type: !621, scopeLine: 54, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!621 = !DISubroutineType(types: !622)
!622 = !{!16, !6}
!623 = !DILocalVariable(name: "d", arg: 1, scope: !620, file: !3, line: 54, type: !6)
!624 = !DILocation(line: 54, column: 39, scope: !620)
!625 = !DILocalVariable(name: "bits", scope: !620, file: !3, line: 55, type: !16)
!626 = !DILocation(line: 55, column: 12, scope: !620)
!627 = !DILocation(line: 56, column: 3, scope: !620)
!628 = !DILocation(line: 57, column: 10, scope: !620)
!629 = !DILocation(line: 57, column: 3, scope: !620)
!630 = distinct !DISubprogram(name: "double_of", scope: !3, file: !3, line: 60, type: !631, scopeLine: 60, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!631 = !DISubroutineType(types: !632)
!632 = !{!6, !16}
!633 = !DILocalVariable(name: "bits", arg: 1, scope: !630, file: !3, line: 60, type: !16)
!634 = !DILocation(line: 60, column: 41, scope: !630)
!635 = !DILocalVariable(name: "d", scope: !630, file: !3, line: 61, type: !6)
!636 = !DILocation(line: 61, column: 10, scope: !630)
!637 = !DILocation(line: 62, column: 3, scope: !630)
!638 = !DILocation(line: 63, column: 10, scope: !630)
!639 = !DILocation(line: 63, column: 3, scope: !630)
!640 = !DILocalVariable(name: "x", arg: 1, scope: !49, file: !3, line: 967, type: !6)
!641 = !DILocation(line: 967, column: 33, scope: !49)
!642 = !DILocalVariable(name: "t", scope: !49, file: !3, line: 971, type: !6)
!643 = !DILocation(line: 971, column: 10, scope: !49)
!644 = !DILocalVariable(name: "hx", scope: !49, file: !3, line: 972, type: !18)
!645 = !DILocation(line: 972, column: 11, scope: !49)
!646 = !DILocalVariable(name: "lx", scope: !49, file: !3, line: 973, type: !9)
!647 = !DILocation(line: 973, column: 12, scope: !49)
!648 = !DILocation(line: 974, column: 3, scope: !49)
!649 = !DILocalVariable(name: "bits", scope: !650, file: !3, line: 974, type: !16)
!650 = distinct !DILexicalBlock(scope: !49, file: !3, line: 974, column: 3)
!651 = !DILocation(line: 974, column: 3, scope: !650)
!652 = !DILocation(line: 975, column: 7, scope: !653)
!653 = distinct !DILexicalBlock(scope: !49, file: !3, line: 975, column: 7)
!654 = !DILocation(line: 975, column: 10, scope: !653)
!655 = !DILocation(line: 975, column: 7, scope: !49)
!656 = !DILocation(line: 976, column: 5, scope: !657)
!657 = distinct !DILexicalBlock(scope: !653, file: !3, line: 975, column: 24)
!658 = !DILocation(line: 977, column: 14, scope: !659)
!659 = distinct !DILexicalBlock(scope: !653, file: !3, line: 977, column: 14)
!660 = !DILocation(line: 977, column: 17, scope: !659)
!661 = !DILocation(line: 977, column: 14, scope: !653)
!662 = !DILocation(line: 978, column: 9, scope: !663)
!663 = distinct !DILexicalBlock(scope: !664, file: !3, line: 978, column: 9)
!664 = distinct !DILexicalBlock(scope: !659, file: !3, line: 977, column: 32)
!665 = !DILocation(line: 978, column: 12, scope: !663)
!666 = !DILocation(line: 978, column: 9, scope: !664)
!667 = !DILocation(line: 979, column: 14, scope: !668)
!668 = distinct !DILexicalBlock(scope: !663, file: !3, line: 978, column: 27)
!669 = !DILocation(line: 979, column: 18, scope: !668)
!670 = !DILocation(line: 979, column: 16, scope: !668)
!671 = !DILocation(line: 979, column: 7, scope: !668)
!672 = !DILocation(line: 981, column: 30, scope: !673)
!673 = distinct !DILexicalBlock(scope: !663, file: !3, line: 980, column: 12)
!674 = !DILocation(line: 981, column: 14, scope: !673)
!675 = !DILocation(line: 981, column: 33, scope: !673)
!676 = !DILocation(line: 981, column: 7, scope: !673)
!677 = !DILocation(line: 983, column: 16, scope: !678)
!678 = distinct !DILexicalBlock(scope: !659, file: !3, line: 983, column: 14)
!679 = !DILocation(line: 983, column: 19, scope: !678)
!680 = !DILocation(line: 983, column: 35, scope: !678)
!681 = !DILocation(line: 983, column: 33, scope: !678)
!682 = !DILocation(line: 983, column: 39, scope: !678)
!683 = !DILocation(line: 983, column: 14, scope: !659)
!684 = !DILocation(line: 984, column: 5, scope: !685)
!685 = distinct !DILexicalBlock(scope: !678, file: !3, line: 983, column: 45)
!686 = !DILocation(line: 985, column: 14, scope: !687)
!687 = distinct !DILexicalBlock(scope: !678, file: !3, line: 985, column: 14)
!688 = !DILocation(line: 985, column: 17, scope: !687)
!689 = !DILocation(line: 985, column: 14, scope: !678)
!690 = !DILocation(line: 986, column: 9, scope: !691)
!691 = distinct !DILexicalBlock(scope: !687, file: !3, line: 985, column: 31)
!692 = !DILocation(line: 986, column: 13, scope: !691)
!693 = !DILocation(line: 986, column: 11, scope: !691)
!694 = !DILocation(line: 986, column: 7, scope: !691)
!695 = !DILocation(line: 987, column: 34, scope: !691)
!696 = !DILocation(line: 987, column: 45, scope: !691)
!697 = !DILocation(line: 987, column: 54, scope: !691)
!698 = !DILocation(line: 987, column: 56, scope: !691)
!699 = !DILocation(line: 987, column: 49, scope: !691)
!700 = !DILocation(line: 987, column: 47, scope: !691)
!701 = !DILocation(line: 987, column: 42, scope: !691)
!702 = !DILocation(line: 987, column: 36, scope: !691)
!703 = !DILocation(line: 987, column: 12, scope: !691)
!704 = !DILocation(line: 987, column: 5, scope: !691)
!705 = !DILocation(line: 989, column: 9, scope: !706)
!706 = distinct !DILexicalBlock(scope: !687, file: !3, line: 988, column: 10)
!707 = !DILocation(line: 989, column: 11, scope: !706)
!708 = !DILocation(line: 989, column: 7, scope: !706)
!709 = !DILocation(line: 990, column: 30, scope: !706)
!710 = !DILocation(line: 990, column: 45, scope: !706)
!711 = !DILocation(line: 990, column: 49, scope: !706)
!712 = !DILocation(line: 990, column: 53, scope: !706)
!713 = !DILocation(line: 990, column: 51, scope: !706)
!714 = !DILocation(line: 990, column: 47, scope: !706)
!715 = !DILocation(line: 990, column: 34, scope: !706)
!716 = !DILocation(line: 990, column: 32, scope: !706)
!717 = !DILocation(line: 990, column: 12, scope: !706)
!718 = !DILocation(line: 990, column: 5, scope: !706)
!719 = !DILocation(line: 992, column: 1, scope: !49)
!720 = !DILocalVariable(name: "x", arg: 1, scope: !168, file: !3, line: 1665, type: !6)
!721 = !DILocation(line: 1665, column: 31, scope: !168)
!722 = !DILocalVariable(name: "hfsq", scope: !168, file: !3, line: 1680, type: !6)
!723 = !DILocation(line: 1680, column: 10, scope: !168)
!724 = !DILocalVariable(name: "f", scope: !168, file: !3, line: 1680, type: !6)
!725 = !DILocation(line: 1680, column: 16, scope: !168)
!726 = !DILocalVariable(name: "s", scope: !168, file: !3, line: 1680, type: !6)
!727 = !DILocation(line: 1680, column: 19, scope: !168)
!728 = !DILocalVariable(name: "z", scope: !168, file: !3, line: 1680, type: !6)
!729 = !DILocation(line: 1680, column: 22, scope: !168)
!730 = !DILocalVariable(name: "R", scope: !168, file: !3, line: 1680, type: !6)
!731 = !DILocation(line: 1680, column: 25, scope: !168)
!732 = !DILocalVariable(name: "w", scope: !168, file: !3, line: 1680, type: !6)
!733 = !DILocation(line: 1680, column: 28, scope: !168)
!734 = !DILocalVariable(name: "t1", scope: !168, file: !3, line: 1680, type: !6)
!735 = !DILocation(line: 1680, column: 31, scope: !168)
!736 = !DILocalVariable(name: "t2", scope: !168, file: !3, line: 1680, type: !6)
!737 = !DILocation(line: 1680, column: 35, scope: !168)
!738 = !DILocalVariable(name: "dk", scope: !168, file: !3, line: 1680, type: !6)
!739 = !DILocation(line: 1680, column: 39, scope: !168)
!740 = !DILocalVariable(name: "k", scope: !168, file: !3, line: 1681, type: !18)
!741 = !DILocation(line: 1681, column: 11, scope: !168)
!742 = !DILocalVariable(name: "hx", scope: !168, file: !3, line: 1681, type: !18)
!743 = !DILocation(line: 1681, column: 14, scope: !168)
!744 = !DILocalVariable(name: "i", scope: !168, file: !3, line: 1681, type: !18)
!745 = !DILocation(line: 1681, column: 18, scope: !168)
!746 = !DILocalVariable(name: "j", scope: !168, file: !3, line: 1681, type: !18)
!747 = !DILocation(line: 1681, column: 21, scope: !168)
!748 = !DILocalVariable(name: "lx", scope: !168, file: !3, line: 1682, type: !9)
!749 = !DILocation(line: 1682, column: 12, scope: !168)
!750 = !DILocation(line: 1684, column: 3, scope: !168)
!751 = !DILocalVariable(name: "bits", scope: !752, file: !3, line: 1684, type: !16)
!752 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1684, column: 3)
!753 = !DILocation(line: 1684, column: 3, scope: !752)
!754 = !DILocation(line: 1686, column: 5, scope: !168)
!755 = !DILocation(line: 1687, column: 7, scope: !756)
!756 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1687, column: 7)
!757 = !DILocation(line: 1687, column: 10, scope: !756)
!758 = !DILocation(line: 1687, column: 7, scope: !168)
!759 = !DILocation(line: 1688, column: 11, scope: !760)
!760 = distinct !DILexicalBlock(scope: !761, file: !3, line: 1688, column: 9)
!761 = distinct !DILexicalBlock(scope: !756, file: !3, line: 1687, column: 24)
!762 = !DILocation(line: 1688, column: 14, scope: !760)
!763 = !DILocation(line: 1688, column: 30, scope: !760)
!764 = !DILocation(line: 1688, column: 28, scope: !760)
!765 = !DILocation(line: 1688, column: 34, scope: !760)
!766 = !DILocation(line: 1688, column: 9, scope: !761)
!767 = !DILocation(line: 1689, column: 7, scope: !768)
!768 = distinct !DILexicalBlock(scope: !760, file: !3, line: 1688, column: 40)
!769 = !DILocation(line: 1691, column: 9, scope: !770)
!770 = distinct !DILexicalBlock(scope: !761, file: !3, line: 1691, column: 9)
!771 = !DILocation(line: 1691, column: 12, scope: !770)
!772 = !DILocation(line: 1691, column: 9, scope: !761)
!773 = !DILocation(line: 1692, column: 7, scope: !774)
!774 = distinct !DILexicalBlock(scope: !770, file: !3, line: 1691, column: 17)
!775 = !DILocation(line: 1694, column: 7, scope: !761)
!776 = !DILocation(line: 1695, column: 7, scope: !761)
!777 = !DILocation(line: 1696, column: 5, scope: !761)
!778 = !DILocalVariable(name: "bits", scope: !779, file: !3, line: 1696, type: !16)
!779 = distinct !DILexicalBlock(scope: !761, file: !3, line: 1696, column: 5)
!780 = !DILocation(line: 1696, column: 5, scope: !779)
!781 = !DILocation(line: 1697, column: 3, scope: !761)
!782 = !DILocation(line: 1698, column: 7, scope: !783)
!783 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1698, column: 7)
!784 = !DILocation(line: 1698, column: 10, scope: !783)
!785 = !DILocation(line: 1698, column: 7, scope: !168)
!786 = !DILocation(line: 1698, column: 32, scope: !783)
!787 = !DILocation(line: 1698, column: 36, scope: !783)
!788 = !DILocation(line: 1698, column: 34, scope: !783)
!789 = !DILocation(line: 1698, column: 25, scope: !783)
!790 = !DILocation(line: 1699, column: 9, scope: !168)
!791 = !DILocation(line: 1699, column: 12, scope: !168)
!792 = !DILocation(line: 1699, column: 19, scope: !168)
!793 = !DILocation(line: 1699, column: 5, scope: !168)
!794 = !DILocation(line: 1700, column: 6, scope: !168)
!795 = !DILocation(line: 1701, column: 8, scope: !168)
!796 = !DILocation(line: 1701, column: 11, scope: !168)
!797 = !DILocation(line: 1701, column: 22, scope: !168)
!798 = !DILocation(line: 1701, column: 5, scope: !168)
!799 = !DILocation(line: 1702, column: 3, scope: !168)
!800 = !DILocalVariable(name: "bits", scope: !801, file: !3, line: 1702, type: !16)
!801 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1702, column: 3)
!802 = !DILocation(line: 1702, column: 3, scope: !801)
!803 = !DILocation(line: 1703, column: 9, scope: !168)
!804 = !DILocation(line: 1703, column: 11, scope: !168)
!805 = !DILocation(line: 1703, column: 5, scope: !168)
!806 = !DILocation(line: 1704, column: 7, scope: !168)
!807 = !DILocation(line: 1704, column: 9, scope: !168)
!808 = !DILocation(line: 1704, column: 5, scope: !168)
!809 = !DILocation(line: 1705, column: 26, scope: !810)
!810 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1705, column: 7)
!811 = !DILocation(line: 1705, column: 24, scope: !810)
!812 = !DILocation(line: 1705, column: 19, scope: !810)
!813 = !DILocation(line: 1705, column: 31, scope: !810)
!814 = !DILocation(line: 1705, column: 7, scope: !168)
!815 = !DILocation(line: 1706, column: 9, scope: !816)
!816 = distinct !DILexicalBlock(scope: !817, file: !3, line: 1706, column: 9)
!817 = distinct !DILexicalBlock(scope: !810, file: !3, line: 1705, column: 36)
!818 = !DILocation(line: 1706, column: 11, scope: !816)
!819 = !DILocation(line: 1706, column: 9, scope: !817)
!820 = !DILocation(line: 1707, column: 11, scope: !821)
!821 = distinct !DILexicalBlock(scope: !822, file: !3, line: 1707, column: 11)
!822 = distinct !DILexicalBlock(scope: !816, file: !3, line: 1706, column: 20)
!823 = !DILocation(line: 1707, column: 13, scope: !821)
!824 = !DILocation(line: 1707, column: 11, scope: !822)
!825 = !DILocation(line: 1708, column: 9, scope: !826)
!826 = distinct !DILexicalBlock(scope: !821, file: !3, line: 1707, column: 19)
!827 = !DILocation(line: 1710, column: 23, scope: !828)
!828 = distinct !DILexicalBlock(scope: !821, file: !3, line: 1709, column: 14)
!829 = !DILocation(line: 1710, column: 14, scope: !828)
!830 = !DILocation(line: 1710, column: 12, scope: !828)
!831 = !DILocation(line: 1711, column: 16, scope: !828)
!832 = !DILocation(line: 1711, column: 30, scope: !828)
!833 = !DILocation(line: 1711, column: 33, scope: !828)
!834 = !DILocation(line: 1711, column: 28, scope: !828)
!835 = !DILocation(line: 1711, column: 9, scope: !828)
!836 = !DILocation(line: 1714, column: 9, scope: !817)
!837 = !DILocation(line: 1714, column: 13, scope: !817)
!838 = !DILocation(line: 1714, column: 11, scope: !817)
!839 = !DILocation(line: 1714, column: 46, scope: !817)
!840 = !DILocation(line: 1714, column: 22, scope: !817)
!841 = !DILocation(line: 1714, column: 15, scope: !817)
!842 = !DILocation(line: 1714, column: 7, scope: !817)
!843 = !DILocation(line: 1715, column: 9, scope: !844)
!844 = distinct !DILexicalBlock(scope: !817, file: !3, line: 1715, column: 9)
!845 = !DILocation(line: 1715, column: 11, scope: !844)
!846 = !DILocation(line: 1715, column: 9, scope: !817)
!847 = !DILocation(line: 1716, column: 14, scope: !848)
!848 = distinct !DILexicalBlock(scope: !844, file: !3, line: 1715, column: 17)
!849 = !DILocation(line: 1716, column: 18, scope: !848)
!850 = !DILocation(line: 1716, column: 16, scope: !848)
!851 = !DILocation(line: 1716, column: 7, scope: !848)
!852 = !DILocation(line: 1718, column: 21, scope: !853)
!853 = distinct !DILexicalBlock(scope: !844, file: !3, line: 1717, column: 12)
!854 = !DILocation(line: 1718, column: 12, scope: !853)
!855 = !DILocation(line: 1718, column: 10, scope: !853)
!856 = !DILocation(line: 1719, column: 14, scope: !853)
!857 = !DILocation(line: 1719, column: 30, scope: !853)
!858 = !DILocation(line: 1719, column: 34, scope: !853)
!859 = !DILocation(line: 1719, column: 32, scope: !853)
!860 = !DILocation(line: 1719, column: 49, scope: !853)
!861 = !DILocation(line: 1719, column: 47, scope: !853)
!862 = !DILocation(line: 1719, column: 26, scope: !853)
!863 = !DILocation(line: 1719, column: 7, scope: !853)
!864 = !DILocation(line: 1722, column: 7, scope: !168)
!865 = !DILocation(line: 1722, column: 18, scope: !168)
!866 = !DILocation(line: 1722, column: 16, scope: !168)
!867 = !DILocation(line: 1722, column: 9, scope: !168)
!868 = !DILocation(line: 1722, column: 5, scope: !168)
!869 = !DILocation(line: 1723, column: 17, scope: !168)
!870 = !DILocation(line: 1723, column: 8, scope: !168)
!871 = !DILocation(line: 1723, column: 6, scope: !168)
!872 = !DILocation(line: 1724, column: 7, scope: !168)
!873 = !DILocation(line: 1724, column: 11, scope: !168)
!874 = !DILocation(line: 1724, column: 9, scope: !168)
!875 = !DILocation(line: 1724, column: 5, scope: !168)
!876 = !DILocation(line: 1725, column: 7, scope: !168)
!877 = !DILocation(line: 1725, column: 10, scope: !168)
!878 = !DILocation(line: 1725, column: 5, scope: !168)
!879 = !DILocation(line: 1726, column: 7, scope: !168)
!880 = !DILocation(line: 1726, column: 11, scope: !168)
!881 = !DILocation(line: 1726, column: 9, scope: !168)
!882 = !DILocation(line: 1726, column: 5, scope: !168)
!883 = !DILocation(line: 1727, column: 17, scope: !168)
!884 = !DILocation(line: 1727, column: 15, scope: !168)
!885 = !DILocation(line: 1727, column: 5, scope: !168)
!886 = !DILocation(line: 1728, column: 8, scope: !168)
!887 = !DILocation(line: 1728, column: 19, scope: !168)
!888 = !DILocation(line: 1728, column: 30, scope: !168)
!889 = !DILocation(line: 1728, column: 28, scope: !168)
!890 = !DILocation(line: 1728, column: 17, scope: !168)
!891 = !DILocation(line: 1728, column: 10, scope: !168)
!892 = !DILocation(line: 1728, column: 6, scope: !168)
!893 = !DILocation(line: 1729, column: 8, scope: !168)
!894 = !DILocation(line: 1729, column: 19, scope: !168)
!895 = !DILocation(line: 1729, column: 30, scope: !168)
!896 = !DILocation(line: 1729, column: 41, scope: !168)
!897 = !DILocation(line: 1729, column: 39, scope: !168)
!898 = !DILocation(line: 1729, column: 28, scope: !168)
!899 = !DILocation(line: 1729, column: 17, scope: !168)
!900 = !DILocation(line: 1729, column: 10, scope: !168)
!901 = !DILocation(line: 1729, column: 6, scope: !168)
!902 = !DILocation(line: 1730, column: 8, scope: !168)
!903 = !DILocation(line: 1730, column: 5, scope: !168)
!904 = !DILocation(line: 1731, column: 7, scope: !168)
!905 = !DILocation(line: 1731, column: 12, scope: !168)
!906 = !DILocation(line: 1731, column: 10, scope: !168)
!907 = !DILocation(line: 1731, column: 5, scope: !168)
!908 = !DILocation(line: 1732, column: 7, scope: !909)
!909 = distinct !DILexicalBlock(scope: !168, file: !3, line: 1732, column: 7)
!910 = !DILocation(line: 1732, column: 9, scope: !909)
!911 = !DILocation(line: 1732, column: 7, scope: !168)
!912 = !DILocation(line: 1733, column: 18, scope: !913)
!913 = distinct !DILexicalBlock(scope: !909, file: !3, line: 1732, column: 14)
!914 = !DILocation(line: 1733, column: 16, scope: !913)
!915 = !DILocation(line: 1733, column: 22, scope: !913)
!916 = !DILocation(line: 1733, column: 20, scope: !913)
!917 = !DILocation(line: 1733, column: 10, scope: !913)
!918 = !DILocation(line: 1734, column: 9, scope: !919)
!919 = distinct !DILexicalBlock(scope: !913, file: !3, line: 1734, column: 9)
!920 = !DILocation(line: 1734, column: 11, scope: !919)
!921 = !DILocation(line: 1734, column: 9, scope: !913)
!922 = !DILocation(line: 1735, column: 14, scope: !919)
!923 = !DILocation(line: 1735, column: 19, scope: !919)
!924 = !DILocation(line: 1735, column: 26, scope: !919)
!925 = !DILocation(line: 1735, column: 31, scope: !919)
!926 = !DILocation(line: 1735, column: 38, scope: !919)
!927 = !DILocation(line: 1735, column: 36, scope: !919)
!928 = !DILocation(line: 1735, column: 24, scope: !919)
!929 = !DILocation(line: 1735, column: 16, scope: !919)
!930 = !DILocation(line: 1735, column: 7, scope: !919)
!931 = !DILocation(line: 1737, column: 14, scope: !919)
!932 = !DILocation(line: 1737, column: 30, scope: !919)
!933 = !DILocation(line: 1737, column: 38, scope: !919)
!934 = !DILocation(line: 1737, column: 43, scope: !919)
!935 = !DILocation(line: 1737, column: 50, scope: !919)
!936 = !DILocation(line: 1737, column: 48, scope: !919)
!937 = !DILocation(line: 1737, column: 55, scope: !919)
!938 = !DILocation(line: 1737, column: 58, scope: !919)
!939 = !DILocation(line: 1737, column: 53, scope: !919)
!940 = !DILocation(line: 1737, column: 35, scope: !919)
!941 = !DILocation(line: 1737, column: 71, scope: !919)
!942 = !DILocation(line: 1737, column: 69, scope: !919)
!943 = !DILocation(line: 1737, column: 26, scope: !919)
!944 = !DILocation(line: 1737, column: 7, scope: !919)
!945 = !DILocation(line: 1739, column: 9, scope: !946)
!946 = distinct !DILexicalBlock(scope: !947, file: !3, line: 1739, column: 9)
!947 = distinct !DILexicalBlock(scope: !909, file: !3, line: 1738, column: 10)
!948 = !DILocation(line: 1739, column: 11, scope: !946)
!949 = !DILocation(line: 1739, column: 9, scope: !947)
!950 = !DILocation(line: 1740, column: 14, scope: !946)
!951 = !DILocation(line: 1740, column: 18, scope: !946)
!952 = !DILocation(line: 1740, column: 23, scope: !946)
!953 = !DILocation(line: 1740, column: 27, scope: !946)
!954 = !DILocation(line: 1740, column: 25, scope: !946)
!955 = !DILocation(line: 1740, column: 16, scope: !946)
!956 = !DILocation(line: 1740, column: 7, scope: !946)
!957 = !DILocation(line: 1742, column: 14, scope: !946)
!958 = !DILocation(line: 1742, column: 30, scope: !946)
!959 = !DILocation(line: 1742, column: 35, scope: !946)
!960 = !DILocation(line: 1742, column: 39, scope: !946)
!961 = !DILocation(line: 1742, column: 37, scope: !946)
!962 = !DILocation(line: 1742, column: 44, scope: !946)
!963 = !DILocation(line: 1742, column: 47, scope: !946)
!964 = !DILocation(line: 1742, column: 42, scope: !946)
!965 = !DILocation(line: 1742, column: 59, scope: !946)
!966 = !DILocation(line: 1742, column: 57, scope: !946)
!967 = !DILocation(line: 1742, column: 26, scope: !946)
!968 = !DILocation(line: 1742, column: 7, scope: !946)
!969 = !DILocation(line: 1744, column: 1, scope: !168)
!970 = !DILocalVariable(name: "x", arg: 1, scope: !191, file: !3, line: 1810, type: !6)
!971 = !DILocation(line: 1810, column: 33, scope: !191)
!972 = !DILocalVariable(name: "hfsq", scope: !191, file: !3, line: 1825, type: !6)
!973 = !DILocation(line: 1825, column: 10, scope: !191)
!974 = !DILocalVariable(name: "f", scope: !191, file: !3, line: 1825, type: !6)
!975 = !DILocation(line: 1825, column: 16, scope: !191)
!976 = !DILocalVariable(name: "c", scope: !191, file: !3, line: 1825, type: !6)
!977 = !DILocation(line: 1825, column: 19, scope: !191)
!978 = !DILocalVariable(name: "s", scope: !191, file: !3, line: 1825, type: !6)
!979 = !DILocation(line: 1825, column: 22, scope: !191)
!980 = !DILocalVariable(name: "z", scope: !191, file: !3, line: 1825, type: !6)
!981 = !DILocation(line: 1825, column: 25, scope: !191)
!982 = !DILocalVariable(name: "R", scope: !191, file: !3, line: 1825, type: !6)
!983 = !DILocation(line: 1825, column: 28, scope: !191)
!984 = !DILocalVariable(name: "u", scope: !191, file: !3, line: 1825, type: !6)
!985 = !DILocation(line: 1825, column: 31, scope: !191)
!986 = !DILocalVariable(name: "k", scope: !191, file: !3, line: 1826, type: !18)
!987 = !DILocation(line: 1826, column: 11, scope: !191)
!988 = !DILocalVariable(name: "hx", scope: !191, file: !3, line: 1826, type: !18)
!989 = !DILocation(line: 1826, column: 14, scope: !191)
!990 = !DILocalVariable(name: "hu", scope: !191, file: !3, line: 1826, type: !18)
!991 = !DILocation(line: 1826, column: 18, scope: !191)
!992 = !DILocalVariable(name: "ax", scope: !191, file: !3, line: 1826, type: !18)
!993 = !DILocation(line: 1826, column: 22, scope: !191)
!994 = !DILocation(line: 1828, column: 3, scope: !191)
!995 = !DILocalVariable(name: "bits", scope: !996, file: !3, line: 1828, type: !16)
!996 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1828, column: 3)
!997 = !DILocation(line: 1828, column: 3, scope: !996)
!998 = !DILocation(line: 1829, column: 8, scope: !191)
!999 = !DILocation(line: 1829, column: 11, scope: !191)
!1000 = !DILocation(line: 1829, column: 6, scope: !191)
!1001 = !DILocation(line: 1831, column: 5, scope: !191)
!1002 = !DILocation(line: 1832, column: 7, scope: !1003)
!1003 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1832, column: 7)
!1004 = !DILocation(line: 1832, column: 10, scope: !1003)
!1005 = !DILocation(line: 1832, column: 7, scope: !191)
!1006 = !DILocation(line: 1833, column: 9, scope: !1007)
!1007 = distinct !DILexicalBlock(scope: !1008, file: !3, line: 1833, column: 9)
!1008 = distinct !DILexicalBlock(scope: !1003, file: !3, line: 1832, column: 24)
!1009 = !DILocation(line: 1833, column: 12, scope: !1007)
!1010 = !DILocation(line: 1833, column: 9, scope: !1008)
!1011 = !DILocation(line: 1834, column: 11, scope: !1012)
!1012 = distinct !DILexicalBlock(scope: !1013, file: !3, line: 1834, column: 11)
!1013 = distinct !DILexicalBlock(scope: !1007, file: !3, line: 1833, column: 27)
!1014 = !DILocation(line: 1834, column: 13, scope: !1012)
!1015 = !DILocation(line: 1834, column: 11, scope: !1013)
!1016 = !DILocation(line: 1835, column: 9, scope: !1012)
!1017 = !DILocation(line: 1837, column: 9, scope: !1012)
!1018 = !DILocation(line: 1839, column: 9, scope: !1019)
!1019 = distinct !DILexicalBlock(scope: !1008, file: !3, line: 1839, column: 9)
!1020 = !DILocation(line: 1839, column: 12, scope: !1019)
!1021 = !DILocation(line: 1839, column: 9, scope: !1008)
!1022 = !DILocation(line: 1840, column: 19, scope: !1023)
!1023 = distinct !DILexicalBlock(scope: !1024, file: !3, line: 1840, column: 11)
!1024 = distinct !DILexicalBlock(scope: !1019, file: !3, line: 1839, column: 26)
!1025 = !DILocation(line: 1840, column: 17, scope: !1023)
!1026 = !DILocation(line: 1840, column: 21, scope: !1023)
!1027 = !DILocation(line: 1841, column: 11, scope: !1023)
!1028 = !DILocation(line: 1841, column: 14, scope: !1023)
!1029 = !DILocation(line: 1841, column: 17, scope: !1023)
!1030 = !DILocation(line: 1840, column: 11, scope: !1024)
!1031 = !DILocation(line: 1842, column: 16, scope: !1023)
!1032 = !DILocation(line: 1842, column: 9, scope: !1023)
!1033 = !DILocation(line: 1844, column: 16, scope: !1023)
!1034 = !DILocation(line: 1844, column: 20, scope: !1023)
!1035 = !DILocation(line: 1844, column: 24, scope: !1023)
!1036 = !DILocation(line: 1844, column: 22, scope: !1023)
!1037 = !DILocation(line: 1844, column: 18, scope: !1023)
!1038 = !DILocation(line: 1844, column: 9, scope: !1023)
!1039 = !DILocation(line: 1846, column: 9, scope: !1040)
!1040 = distinct !DILexicalBlock(scope: !1008, file: !3, line: 1846, column: 9)
!1041 = !DILocation(line: 1846, column: 12, scope: !1040)
!1042 = !DILocation(line: 1846, column: 16, scope: !1040)
!1043 = !DILocation(line: 1846, column: 19, scope: !1040)
!1044 = !DILocation(line: 1846, column: 22, scope: !1040)
!1045 = !DILocation(line: 1846, column: 9, scope: !1008)
!1046 = !DILocation(line: 1847, column: 9, scope: !1047)
!1047 = distinct !DILexicalBlock(scope: !1040, file: !3, line: 1846, column: 48)
!1048 = !DILocation(line: 1848, column: 11, scope: !1047)
!1049 = !DILocation(line: 1848, column: 9, scope: !1047)
!1050 = !DILocation(line: 1849, column: 10, scope: !1047)
!1051 = !DILocation(line: 1850, column: 5, scope: !1047)
!1052 = !DILocation(line: 1851, column: 3, scope: !1008)
!1053 = !DILocation(line: 1852, column: 7, scope: !1054)
!1054 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1852, column: 7)
!1055 = !DILocation(line: 1852, column: 10, scope: !1054)
!1056 = !DILocation(line: 1852, column: 7, scope: !191)
!1057 = !DILocation(line: 1852, column: 32, scope: !1054)
!1058 = !DILocation(line: 1852, column: 36, scope: !1054)
!1059 = !DILocation(line: 1852, column: 34, scope: !1054)
!1060 = !DILocation(line: 1852, column: 25, scope: !1054)
!1061 = !DILocation(line: 1853, column: 7, scope: !1062)
!1062 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1853, column: 7)
!1063 = !DILocation(line: 1853, column: 9, scope: !1062)
!1064 = !DILocation(line: 1853, column: 7, scope: !191)
!1065 = !DILocation(line: 1854, column: 9, scope: !1066)
!1066 = distinct !DILexicalBlock(scope: !1067, file: !3, line: 1854, column: 9)
!1067 = distinct !DILexicalBlock(scope: !1062, file: !3, line: 1853, column: 15)
!1068 = !DILocation(line: 1854, column: 12, scope: !1066)
!1069 = !DILocation(line: 1854, column: 9, scope: !1067)
!1070 = !DILocation(line: 1855, column: 17, scope: !1071)
!1071 = distinct !DILexicalBlock(scope: !1066, file: !3, line: 1854, column: 26)
!1072 = !DILocation(line: 1855, column: 15, scope: !1071)
!1073 = !DILocation(line: 1855, column: 9, scope: !1071)
!1074 = !DILocation(line: 1856, column: 7, scope: !1071)
!1075 = !DILocalVariable(name: "bits", scope: !1076, file: !3, line: 1856, type: !16)
!1076 = distinct !DILexicalBlock(scope: !1071, file: !3, line: 1856, column: 7)
!1077 = !DILocation(line: 1856, column: 7, scope: !1076)
!1078 = !DILocation(line: 1857, column: 12, scope: !1071)
!1079 = !DILocation(line: 1857, column: 15, scope: !1071)
!1080 = !DILocation(line: 1857, column: 22, scope: !1071)
!1081 = !DILocation(line: 1857, column: 9, scope: !1071)
!1082 = !DILocation(line: 1858, column: 12, scope: !1071)
!1083 = !DILocation(line: 1858, column: 14, scope: !1071)
!1084 = !DILocation(line: 1858, column: 11, scope: !1071)
!1085 = !DILocation(line: 1858, column: 28, scope: !1071)
!1086 = !DILocation(line: 1858, column: 32, scope: !1071)
!1087 = !DILocation(line: 1858, column: 30, scope: !1071)
!1088 = !DILocation(line: 1858, column: 25, scope: !1071)
!1089 = !DILocation(line: 1858, column: 37, scope: !1071)
!1090 = !DILocation(line: 1858, column: 42, scope: !1071)
!1091 = !DILocation(line: 1858, column: 44, scope: !1071)
!1092 = !DILocation(line: 1858, column: 39, scope: !1071)
!1093 = !DILocation(line: 1858, column: 9, scope: !1071)
!1094 = !DILocation(line: 1859, column: 12, scope: !1071)
!1095 = !DILocation(line: 1859, column: 9, scope: !1071)
!1096 = !DILocation(line: 1860, column: 5, scope: !1071)
!1097 = !DILocation(line: 1861, column: 11, scope: !1098)
!1098 = distinct !DILexicalBlock(scope: !1066, file: !3, line: 1860, column: 12)
!1099 = !DILocation(line: 1861, column: 9, scope: !1098)
!1100 = !DILocation(line: 1862, column: 7, scope: !1098)
!1101 = !DILocalVariable(name: "bits", scope: !1102, file: !3, line: 1862, type: !16)
!1102 = distinct !DILexicalBlock(scope: !1098, file: !3, line: 1862, column: 7)
!1103 = !DILocation(line: 1862, column: 7, scope: !1102)
!1104 = !DILocation(line: 1863, column: 12, scope: !1098)
!1105 = !DILocation(line: 1863, column: 15, scope: !1098)
!1106 = !DILocation(line: 1863, column: 22, scope: !1098)
!1107 = !DILocation(line: 1863, column: 9, scope: !1098)
!1108 = !DILocation(line: 1864, column: 9, scope: !1098)
!1109 = !DILocation(line: 1866, column: 8, scope: !1067)
!1110 = !DILocation(line: 1874, column: 9, scope: !1111)
!1111 = distinct !DILexicalBlock(scope: !1067, file: !3, line: 1874, column: 9)
!1112 = !DILocation(line: 1874, column: 12, scope: !1111)
!1113 = !DILocation(line: 1874, column: 9, scope: !1067)
!1114 = !DILocation(line: 1875, column: 7, scope: !1115)
!1115 = distinct !DILexicalBlock(scope: !1111, file: !3, line: 1874, column: 23)
!1116 = !DILocalVariable(name: "bits", scope: !1117, file: !3, line: 1875, type: !16)
!1117 = distinct !DILexicalBlock(scope: !1115, file: !3, line: 1875, column: 7)
!1118 = !DILocation(line: 1875, column: 7, scope: !1117)
!1119 = !DILocation(line: 1876, column: 5, scope: !1115)
!1120 = !DILocation(line: 1877, column: 9, scope: !1121)
!1121 = distinct !DILexicalBlock(scope: !1111, file: !3, line: 1876, column: 12)
!1122 = !DILocation(line: 1878, column: 7, scope: !1121)
!1123 = !DILocalVariable(name: "bits", scope: !1124, file: !3, line: 1878, type: !16)
!1124 = distinct !DILexicalBlock(scope: !1121, file: !3, line: 1878, column: 7)
!1125 = !DILocation(line: 1878, column: 7, scope: !1124)
!1126 = !DILocation(line: 1879, column: 26, scope: !1121)
!1127 = !DILocation(line: 1879, column: 24, scope: !1121)
!1128 = !DILocation(line: 1879, column: 30, scope: !1121)
!1129 = !DILocation(line: 1879, column: 10, scope: !1121)
!1130 = !DILocation(line: 1881, column: 9, scope: !1067)
!1131 = !DILocation(line: 1881, column: 11, scope: !1067)
!1132 = !DILocation(line: 1881, column: 7, scope: !1067)
!1133 = !DILocation(line: 1882, column: 3, scope: !1067)
!1134 = !DILocation(line: 1883, column: 16, scope: !191)
!1135 = !DILocation(line: 1883, column: 14, scope: !191)
!1136 = !DILocation(line: 1883, column: 20, scope: !191)
!1137 = !DILocation(line: 1883, column: 18, scope: !191)
!1138 = !DILocation(line: 1883, column: 8, scope: !191)
!1139 = !DILocation(line: 1884, column: 7, scope: !1140)
!1140 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1884, column: 7)
!1141 = !DILocation(line: 1884, column: 10, scope: !1140)
!1142 = !DILocation(line: 1884, column: 7, scope: !191)
!1143 = !DILocation(line: 1885, column: 9, scope: !1144)
!1144 = distinct !DILexicalBlock(scope: !1145, file: !3, line: 1885, column: 9)
!1145 = distinct !DILexicalBlock(scope: !1140, file: !3, line: 1884, column: 16)
!1146 = !DILocation(line: 1885, column: 11, scope: !1144)
!1147 = !DILocation(line: 1885, column: 9, scope: !1145)
!1148 = !DILocation(line: 1886, column: 11, scope: !1149)
!1149 = distinct !DILexicalBlock(scope: !1150, file: !3, line: 1886, column: 11)
!1150 = distinct !DILexicalBlock(scope: !1144, file: !3, line: 1885, column: 20)
!1151 = !DILocation(line: 1886, column: 13, scope: !1149)
!1152 = !DILocation(line: 1886, column: 11, scope: !1150)
!1153 = !DILocation(line: 1887, column: 9, scope: !1154)
!1154 = distinct !DILexicalBlock(scope: !1149, file: !3, line: 1886, column: 19)
!1155 = !DILocation(line: 1889, column: 14, scope: !1156)
!1156 = distinct !DILexicalBlock(scope: !1149, file: !3, line: 1888, column: 14)
!1157 = !DILocation(line: 1889, column: 11, scope: !1156)
!1158 = !DILocation(line: 1890, column: 16, scope: !1156)
!1159 = !DILocation(line: 1890, column: 29, scope: !1156)
!1160 = !DILocation(line: 1890, column: 27, scope: !1156)
!1161 = !DILocation(line: 1890, column: 9, scope: !1156)
!1162 = !DILocation(line: 1893, column: 9, scope: !1145)
!1163 = !DILocation(line: 1893, column: 45, scope: !1145)
!1164 = !DILocation(line: 1893, column: 21, scope: !1145)
!1165 = !DILocation(line: 1893, column: 14, scope: !1145)
!1166 = !DILocation(line: 1893, column: 7, scope: !1145)
!1167 = !DILocation(line: 1894, column: 9, scope: !1168)
!1168 = distinct !DILexicalBlock(scope: !1145, file: !3, line: 1894, column: 9)
!1169 = !DILocation(line: 1894, column: 11, scope: !1168)
!1170 = !DILocation(line: 1894, column: 9, scope: !1145)
!1171 = !DILocation(line: 1895, column: 14, scope: !1168)
!1172 = !DILocation(line: 1895, column: 18, scope: !1168)
!1173 = !DILocation(line: 1895, column: 16, scope: !1168)
!1174 = !DILocation(line: 1895, column: 7, scope: !1168)
!1175 = !DILocation(line: 1897, column: 14, scope: !1168)
!1176 = !DILocation(line: 1897, column: 29, scope: !1168)
!1177 = !DILocation(line: 1897, column: 34, scope: !1168)
!1178 = !DILocation(line: 1897, column: 47, scope: !1168)
!1179 = !DILocation(line: 1897, column: 45, scope: !1168)
!1180 = !DILocation(line: 1897, column: 31, scope: !1168)
!1181 = !DILocation(line: 1897, column: 53, scope: !1168)
!1182 = !DILocation(line: 1897, column: 51, scope: !1168)
!1183 = !DILocation(line: 1897, column: 25, scope: !1168)
!1184 = !DILocation(line: 1897, column: 7, scope: !1168)
!1185 = !DILocation(line: 1899, column: 7, scope: !191)
!1186 = !DILocation(line: 1899, column: 18, scope: !191)
!1187 = !DILocation(line: 1899, column: 16, scope: !191)
!1188 = !DILocation(line: 1899, column: 9, scope: !191)
!1189 = !DILocation(line: 1899, column: 5, scope: !191)
!1190 = !DILocation(line: 1900, column: 7, scope: !191)
!1191 = !DILocation(line: 1900, column: 11, scope: !191)
!1192 = !DILocation(line: 1900, column: 9, scope: !191)
!1193 = !DILocation(line: 1900, column: 5, scope: !191)
!1194 = !DILocation(line: 1901, column: 7, scope: !191)
!1195 = !DILocation(line: 1902, column: 12, scope: !191)
!1196 = !DILocation(line: 1902, column: 23, scope: !191)
!1197 = !DILocation(line: 1902, column: 34, scope: !191)
!1198 = !DILocation(line: 1902, column: 45, scope: !191)
!1199 = !DILocation(line: 1902, column: 56, scope: !191)
!1200 = !DILocation(line: 1902, column: 67, scope: !191)
!1201 = !DILocation(line: 1902, column: 65, scope: !191)
!1202 = !DILocation(line: 1902, column: 54, scope: !191)
!1203 = !DILocation(line: 1902, column: 43, scope: !191)
!1204 = !DILocation(line: 1902, column: 32, scope: !191)
!1205 = !DILocation(line: 1902, column: 21, scope: !191)
!1206 = !DILocation(line: 1901, column: 16, scope: !191)
!1207 = !DILocation(line: 1901, column: 9, scope: !191)
!1208 = !DILocation(line: 1901, column: 5, scope: !191)
!1209 = !DILocation(line: 1903, column: 7, scope: !1210)
!1210 = distinct !DILexicalBlock(scope: !191, file: !3, line: 1903, column: 7)
!1211 = !DILocation(line: 1903, column: 9, scope: !1210)
!1212 = !DILocation(line: 1903, column: 7, scope: !191)
!1213 = !DILocation(line: 1904, column: 12, scope: !1210)
!1214 = !DILocation(line: 1904, column: 17, scope: !1210)
!1215 = !DILocation(line: 1904, column: 24, scope: !1210)
!1216 = !DILocation(line: 1904, column: 29, scope: !1210)
!1217 = !DILocation(line: 1904, column: 36, scope: !1210)
!1218 = !DILocation(line: 1904, column: 34, scope: !1210)
!1219 = !DILocation(line: 1904, column: 22, scope: !1210)
!1220 = !DILocation(line: 1904, column: 14, scope: !1210)
!1221 = !DILocation(line: 1904, column: 5, scope: !1210)
!1222 = !DILocation(line: 1906, column: 12, scope: !1210)
!1223 = !DILocation(line: 1906, column: 27, scope: !1210)
!1224 = !DILocation(line: 1906, column: 35, scope: !1210)
!1225 = !DILocation(line: 1906, column: 40, scope: !1210)
!1226 = !DILocation(line: 1906, column: 47, scope: !1210)
!1227 = !DILocation(line: 1906, column: 45, scope: !1210)
!1228 = !DILocation(line: 1906, column: 53, scope: !1210)
!1229 = !DILocation(line: 1906, column: 66, scope: !1210)
!1230 = !DILocation(line: 1906, column: 64, scope: !1210)
!1231 = !DILocation(line: 1906, column: 50, scope: !1210)
!1232 = !DILocation(line: 1906, column: 32, scope: !1210)
!1233 = !DILocation(line: 1906, column: 73, scope: !1210)
!1234 = !DILocation(line: 1906, column: 71, scope: !1210)
!1235 = !DILocation(line: 1906, column: 23, scope: !1210)
!1236 = !DILocation(line: 1906, column: 5, scope: !1210)
!1237 = !DILocation(line: 1907, column: 1, scope: !191)
!1238 = !DILocalVariable(name: "x", arg: 1, scope: !55, file: !3, line: 1022, type: !6)
!1239 = !DILocation(line: 1022, column: 32, scope: !55)
!1240 = !DILocalVariable(name: "t", scope: !55, file: !3, line: 1041, type: !6)
!1241 = !DILocation(line: 1041, column: 10, scope: !55)
!1242 = !DILocalVariable(name: "w", scope: !55, file: !3, line: 1041, type: !6)
!1243 = !DILocation(line: 1041, column: 13, scope: !55)
!1244 = !DILocalVariable(name: "p", scope: !55, file: !3, line: 1041, type: !6)
!1245 = !DILocation(line: 1041, column: 16, scope: !55)
!1246 = !DILocalVariable(name: "q", scope: !55, file: !3, line: 1041, type: !6)
!1247 = !DILocation(line: 1041, column: 19, scope: !55)
!1248 = !DILocalVariable(name: "c", scope: !55, file: !3, line: 1041, type: !6)
!1249 = !DILocation(line: 1041, column: 22, scope: !55)
!1250 = !DILocalVariable(name: "r", scope: !55, file: !3, line: 1041, type: !6)
!1251 = !DILocation(line: 1041, column: 25, scope: !55)
!1252 = !DILocalVariable(name: "s", scope: !55, file: !3, line: 1041, type: !6)
!1253 = !DILocation(line: 1041, column: 28, scope: !55)
!1254 = !DILocalVariable(name: "hx", scope: !55, file: !3, line: 1042, type: !18)
!1255 = !DILocation(line: 1042, column: 11, scope: !55)
!1256 = !DILocalVariable(name: "ix", scope: !55, file: !3, line: 1042, type: !18)
!1257 = !DILocation(line: 1042, column: 15, scope: !55)
!1258 = !DILocation(line: 1044, column: 5, scope: !55)
!1259 = !DILocation(line: 1045, column: 3, scope: !55)
!1260 = !DILocalVariable(name: "bits", scope: !1261, file: !3, line: 1045, type: !16)
!1261 = distinct !DILexicalBlock(scope: !55, file: !3, line: 1045, column: 3)
!1262 = !DILocation(line: 1045, column: 3, scope: !1261)
!1263 = !DILocation(line: 1046, column: 8, scope: !55)
!1264 = !DILocation(line: 1046, column: 11, scope: !55)
!1265 = !DILocation(line: 1046, column: 6, scope: !55)
!1266 = !DILocation(line: 1047, column: 7, scope: !1267)
!1267 = distinct !DILexicalBlock(scope: !55, file: !3, line: 1047, column: 7)
!1268 = !DILocation(line: 1047, column: 10, scope: !1267)
!1269 = !DILocation(line: 1047, column: 7, scope: !55)
!1270 = !DILocalVariable(name: "lx", scope: !1271, file: !3, line: 1048, type: !9)
!1271 = distinct !DILexicalBlock(scope: !1267, file: !3, line: 1047, column: 25)
!1272 = !DILocation(line: 1048, column: 14, scope: !1271)
!1273 = !DILocation(line: 1049, column: 5, scope: !1271)
!1274 = !DILocalVariable(name: "bits", scope: !1275, file: !3, line: 1049, type: !16)
!1275 = distinct !DILexicalBlock(scope: !1271, file: !3, line: 1049, column: 5)
!1276 = !DILocation(line: 1049, column: 5, scope: !1275)
!1277 = !DILocation(line: 1050, column: 11, scope: !1278)
!1278 = distinct !DILexicalBlock(scope: !1271, file: !3, line: 1050, column: 9)
!1279 = !DILocation(line: 1050, column: 14, scope: !1278)
!1280 = !DILocation(line: 1050, column: 30, scope: !1278)
!1281 = !DILocation(line: 1050, column: 28, scope: !1278)
!1282 = !DILocation(line: 1050, column: 34, scope: !1278)
!1283 = !DILocation(line: 1050, column: 9, scope: !1271)
!1284 = !DILocation(line: 1051, column: 14, scope: !1285)
!1285 = distinct !DILexicalBlock(scope: !1278, file: !3, line: 1050, column: 40)
!1286 = !DILocation(line: 1051, column: 28, scope: !1285)
!1287 = !DILocation(line: 1051, column: 30, scope: !1285)
!1288 = !DILocation(line: 1051, column: 26, scope: !1285)
!1289 = !DILocation(line: 1051, column: 7, scope: !1285)
!1290 = !DILocation(line: 1053, column: 5, scope: !1271)
!1291 = !DILocation(line: 1054, column: 14, scope: !1292)
!1292 = distinct !DILexicalBlock(scope: !1267, file: !3, line: 1054, column: 14)
!1293 = !DILocation(line: 1054, column: 17, scope: !1292)
!1294 = !DILocation(line: 1054, column: 14, scope: !1267)
!1295 = !DILocation(line: 1055, column: 9, scope: !1296)
!1296 = distinct !DILexicalBlock(scope: !1297, file: !3, line: 1055, column: 9)
!1297 = distinct !DILexicalBlock(scope: !1292, file: !3, line: 1054, column: 31)
!1298 = !DILocation(line: 1055, column: 12, scope: !1296)
!1299 = !DILocation(line: 1055, column: 9, scope: !1297)
!1300 = !DILocation(line: 1056, column: 18, scope: !1301)
!1301 = distinct !DILexicalBlock(scope: !1302, file: !3, line: 1056, column: 11)
!1302 = distinct !DILexicalBlock(scope: !1296, file: !3, line: 1055, column: 26)
!1303 = !DILocation(line: 1056, column: 16, scope: !1301)
!1304 = !DILocation(line: 1056, column: 20, scope: !1301)
!1305 = !DILocation(line: 1056, column: 11, scope: !1302)
!1306 = !DILocation(line: 1056, column: 34, scope: !1301)
!1307 = !DILocation(line: 1056, column: 27, scope: !1301)
!1308 = !DILocation(line: 1057, column: 5, scope: !1302)
!1309 = !DILocation(line: 1058, column: 11, scope: !1310)
!1310 = distinct !DILexicalBlock(scope: !1296, file: !3, line: 1057, column: 12)
!1311 = !DILocation(line: 1058, column: 15, scope: !1310)
!1312 = !DILocation(line: 1058, column: 13, scope: !1310)
!1313 = !DILocation(line: 1058, column: 9, scope: !1310)
!1314 = !DILocation(line: 1060, column: 9, scope: !1297)
!1315 = !DILocation(line: 1060, column: 20, scope: !1297)
!1316 = !DILocation(line: 1060, column: 31, scope: !1297)
!1317 = !DILocation(line: 1060, column: 42, scope: !1297)
!1318 = !DILocation(line: 1060, column: 53, scope: !1297)
!1319 = !DILocation(line: 1060, column: 64, scope: !1297)
!1320 = !DILocation(line: 1060, column: 62, scope: !1297)
!1321 = !DILocation(line: 1060, column: 51, scope: !1297)
!1322 = !DILocation(line: 1060, column: 40, scope: !1297)
!1323 = !DILocation(line: 1060, column: 29, scope: !1297)
!1324 = !DILocation(line: 1060, column: 18, scope: !1297)
!1325 = !DILocation(line: 1060, column: 11, scope: !1297)
!1326 = !DILocation(line: 1060, column: 7, scope: !1297)
!1327 = !DILocation(line: 1061, column: 15, scope: !1297)
!1328 = !DILocation(line: 1061, column: 26, scope: !1297)
!1329 = !DILocation(line: 1061, column: 37, scope: !1297)
!1330 = !DILocation(line: 1061, column: 48, scope: !1297)
!1331 = !DILocation(line: 1061, column: 46, scope: !1297)
!1332 = !DILocation(line: 1061, column: 35, scope: !1297)
!1333 = !DILocation(line: 1061, column: 24, scope: !1297)
!1334 = !DILocation(line: 1061, column: 13, scope: !1297)
!1335 = !DILocation(line: 1061, column: 7, scope: !1297)
!1336 = !DILocation(line: 1062, column: 9, scope: !1297)
!1337 = !DILocation(line: 1062, column: 13, scope: !1297)
!1338 = !DILocation(line: 1062, column: 11, scope: !1297)
!1339 = !DILocation(line: 1062, column: 7, scope: !1297)
!1340 = !DILocation(line: 1063, column: 12, scope: !1297)
!1341 = !DILocation(line: 1063, column: 16, scope: !1297)
!1342 = !DILocation(line: 1063, column: 20, scope: !1297)
!1343 = !DILocation(line: 1063, column: 14, scope: !1297)
!1344 = !DILocation(line: 1063, column: 5, scope: !1297)
!1345 = !DILocation(line: 1066, column: 18, scope: !55)
!1346 = !DILocation(line: 1066, column: 13, scope: !55)
!1347 = !DILocation(line: 1066, column: 11, scope: !55)
!1348 = !DILocation(line: 1066, column: 5, scope: !55)
!1349 = !DILocation(line: 1067, column: 7, scope: !55)
!1350 = !DILocation(line: 1067, column: 9, scope: !55)
!1351 = !DILocation(line: 1067, column: 5, scope: !55)
!1352 = !DILocation(line: 1068, column: 7, scope: !55)
!1353 = !DILocation(line: 1068, column: 18, scope: !55)
!1354 = !DILocation(line: 1068, column: 29, scope: !55)
!1355 = !DILocation(line: 1068, column: 40, scope: !55)
!1356 = !DILocation(line: 1068, column: 51, scope: !55)
!1357 = !DILocation(line: 1068, column: 62, scope: !55)
!1358 = !DILocation(line: 1068, column: 60, scope: !55)
!1359 = !DILocation(line: 1068, column: 49, scope: !55)
!1360 = !DILocation(line: 1068, column: 38, scope: !55)
!1361 = !DILocation(line: 1068, column: 27, scope: !55)
!1362 = !DILocation(line: 1068, column: 16, scope: !55)
!1363 = !DILocation(line: 1068, column: 9, scope: !55)
!1364 = !DILocation(line: 1068, column: 5, scope: !55)
!1365 = !DILocation(line: 1069, column: 13, scope: !55)
!1366 = !DILocation(line: 1069, column: 24, scope: !55)
!1367 = !DILocation(line: 1069, column: 35, scope: !55)
!1368 = !DILocation(line: 1069, column: 46, scope: !55)
!1369 = !DILocation(line: 1069, column: 44, scope: !55)
!1370 = !DILocation(line: 1069, column: 33, scope: !55)
!1371 = !DILocation(line: 1069, column: 22, scope: !55)
!1372 = !DILocation(line: 1069, column: 11, scope: !55)
!1373 = !DILocation(line: 1069, column: 5, scope: !55)
!1374 = !DILocation(line: 1070, column: 12, scope: !55)
!1375 = !DILocation(line: 1070, column: 7, scope: !55)
!1376 = !DILocation(line: 1070, column: 5, scope: !55)
!1377 = !DILocation(line: 1071, column: 7, scope: !1378)
!1378 = distinct !DILexicalBlock(scope: !55, file: !3, line: 1071, column: 7)
!1379 = !DILocation(line: 1071, column: 10, scope: !1378)
!1380 = !DILocation(line: 1071, column: 7, scope: !55)
!1381 = !DILocation(line: 1072, column: 9, scope: !1382)
!1382 = distinct !DILexicalBlock(scope: !1378, file: !3, line: 1071, column: 25)
!1383 = !DILocation(line: 1072, column: 13, scope: !1382)
!1384 = !DILocation(line: 1072, column: 11, scope: !1382)
!1385 = !DILocation(line: 1072, column: 7, scope: !1382)
!1386 = !DILocation(line: 1073, column: 27, scope: !1382)
!1387 = !DILocation(line: 1073, column: 31, scope: !1382)
!1388 = !DILocation(line: 1073, column: 35, scope: !1382)
!1389 = !DILocation(line: 1073, column: 29, scope: !1382)
!1390 = !DILocation(line: 1073, column: 38, scope: !1382)
!1391 = !DILocation(line: 1073, column: 17, scope: !1382)
!1392 = !DILocation(line: 1073, column: 7, scope: !1382)
!1393 = !DILocation(line: 1074, column: 3, scope: !1382)
!1394 = !DILocation(line: 1075, column: 9, scope: !1395)
!1395 = distinct !DILexicalBlock(scope: !1378, file: !3, line: 1074, column: 10)
!1396 = !DILocation(line: 1075, column: 7, scope: !1395)
!1397 = !DILocation(line: 1076, column: 5, scope: !1395)
!1398 = !DILocalVariable(name: "bits", scope: !1399, file: !3, line: 1076, type: !16)
!1399 = distinct !DILexicalBlock(scope: !1395, file: !3, line: 1076, column: 5)
!1400 = !DILocation(line: 1076, column: 5, scope: !1399)
!1401 = !DILocation(line: 1077, column: 10, scope: !1395)
!1402 = !DILocation(line: 1077, column: 14, scope: !1395)
!1403 = !DILocation(line: 1077, column: 18, scope: !1395)
!1404 = !DILocation(line: 1077, column: 12, scope: !1395)
!1405 = !DILocation(line: 1077, column: 24, scope: !1395)
!1406 = !DILocation(line: 1077, column: 28, scope: !1395)
!1407 = !DILocation(line: 1077, column: 26, scope: !1395)
!1408 = !DILocation(line: 1077, column: 21, scope: !1395)
!1409 = !DILocation(line: 1077, column: 7, scope: !1395)
!1410 = !DILocation(line: 1078, column: 9, scope: !1395)
!1411 = !DILocation(line: 1078, column: 13, scope: !1395)
!1412 = !DILocation(line: 1078, column: 11, scope: !1395)
!1413 = !DILocation(line: 1078, column: 7, scope: !1395)
!1414 = !DILocation(line: 1079, column: 15, scope: !1395)
!1415 = !DILocation(line: 1079, column: 13, scope: !1395)
!1416 = !DILocation(line: 1079, column: 19, scope: !1395)
!1417 = !DILocation(line: 1079, column: 40, scope: !1395)
!1418 = !DILocation(line: 1079, column: 32, scope: !1395)
!1419 = !DILocation(line: 1079, column: 21, scope: !1395)
!1420 = !DILocation(line: 1079, column: 7, scope: !1395)
!1421 = !DILocation(line: 1080, column: 25, scope: !1395)
!1422 = !DILocation(line: 1080, column: 17, scope: !1395)
!1423 = !DILocation(line: 1080, column: 7, scope: !1395)
!1424 = !DILocation(line: 1081, column: 20, scope: !1395)
!1425 = !DILocation(line: 1081, column: 24, scope: !1395)
!1426 = !DILocation(line: 1081, column: 22, scope: !1395)
!1427 = !DILocation(line: 1081, column: 17, scope: !1395)
!1428 = !DILocation(line: 1081, column: 7, scope: !1395)
!1429 = !DILocation(line: 1083, column: 7, scope: !1430)
!1430 = distinct !DILexicalBlock(scope: !55, file: !3, line: 1083, column: 7)
!1431 = !DILocation(line: 1083, column: 10, scope: !1430)
!1432 = !DILocation(line: 1083, column: 7, scope: !55)
!1433 = !DILocation(line: 1084, column: 12, scope: !1430)
!1434 = !DILocation(line: 1084, column: 5, scope: !1430)
!1435 = !DILocation(line: 1086, column: 13, scope: !1430)
!1436 = !DILocation(line: 1086, column: 12, scope: !1430)
!1437 = !DILocation(line: 1086, column: 5, scope: !1430)
!1438 = !DILocation(line: 1087, column: 1, scope: !55)
!1439 = !DILocalVariable(name: "x", arg: 1, scope: !86, file: !3, line: 1098, type: !6)
!1440 = !DILocation(line: 1098, column: 33, scope: !86)
!1441 = !DILocalVariable(name: "t", scope: !86, file: !3, line: 1104, type: !6)
!1442 = !DILocation(line: 1104, column: 10, scope: !86)
!1443 = !DILocalVariable(name: "w", scope: !86, file: !3, line: 1104, type: !6)
!1444 = !DILocation(line: 1104, column: 13, scope: !86)
!1445 = !DILocalVariable(name: "hx", scope: !86, file: !3, line: 1105, type: !18)
!1446 = !DILocation(line: 1105, column: 11, scope: !86)
!1447 = !DILocalVariable(name: "ix", scope: !86, file: !3, line: 1105, type: !18)
!1448 = !DILocation(line: 1105, column: 15, scope: !86)
!1449 = !DILocation(line: 1106, column: 3, scope: !86)
!1450 = !DILocalVariable(name: "bits", scope: !1451, file: !3, line: 1106, type: !16)
!1451 = distinct !DILexicalBlock(scope: !86, file: !3, line: 1106, column: 3)
!1452 = !DILocation(line: 1106, column: 3, scope: !1451)
!1453 = !DILocation(line: 1107, column: 8, scope: !86)
!1454 = !DILocation(line: 1107, column: 11, scope: !86)
!1455 = !DILocation(line: 1107, column: 6, scope: !86)
!1456 = !DILocation(line: 1108, column: 7, scope: !1457)
!1457 = distinct !DILexicalBlock(scope: !86, file: !3, line: 1108, column: 7)
!1458 = !DILocation(line: 1108, column: 10, scope: !1457)
!1459 = !DILocation(line: 1108, column: 7, scope: !86)
!1460 = !DILocation(line: 1108, column: 32, scope: !1457)
!1461 = !DILocation(line: 1108, column: 36, scope: !1457)
!1462 = !DILocation(line: 1108, column: 34, scope: !1457)
!1463 = !DILocation(line: 1108, column: 25, scope: !1457)
!1464 = !DILocation(line: 1109, column: 7, scope: !1465)
!1465 = distinct !DILexicalBlock(scope: !86, file: !3, line: 1109, column: 7)
!1466 = !DILocation(line: 1109, column: 10, scope: !1465)
!1467 = !DILocation(line: 1109, column: 7, scope: !86)
!1468 = !DILocation(line: 1110, column: 16, scope: !1469)
!1469 = distinct !DILexicalBlock(scope: !1470, file: !3, line: 1110, column: 9)
!1470 = distinct !DILexicalBlock(scope: !1465, file: !3, line: 1109, column: 24)
!1471 = !DILocation(line: 1110, column: 14, scope: !1469)
!1472 = !DILocation(line: 1110, column: 18, scope: !1469)
!1473 = !DILocation(line: 1110, column: 9, scope: !1470)
!1474 = !DILocation(line: 1110, column: 32, scope: !1469)
!1475 = !DILocation(line: 1110, column: 25, scope: !1469)
!1476 = !DILocation(line: 1111, column: 3, scope: !1470)
!1477 = !DILocation(line: 1112, column: 7, scope: !1478)
!1478 = distinct !DILexicalBlock(scope: !86, file: !3, line: 1112, column: 7)
!1479 = !DILocation(line: 1112, column: 10, scope: !1478)
!1480 = !DILocation(line: 1112, column: 7, scope: !86)
!1481 = !DILocation(line: 1113, column: 30, scope: !1482)
!1482 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 1112, column: 24)
!1483 = !DILocation(line: 1113, column: 25, scope: !1482)
!1484 = !DILocation(line: 1113, column: 9, scope: !1482)
!1485 = !DILocation(line: 1113, column: 34, scope: !1482)
!1486 = !DILocation(line: 1113, column: 7, scope: !1482)
!1487 = !DILocation(line: 1114, column: 3, scope: !1482)
!1488 = !DILocation(line: 1114, column: 14, scope: !1489)
!1489 = distinct !DILexicalBlock(scope: !1478, file: !3, line: 1114, column: 14)
!1490 = !DILocation(line: 1114, column: 17, scope: !1489)
!1491 = !DILocation(line: 1114, column: 14, scope: !1478)
!1492 = !DILocation(line: 1115, column: 14, scope: !1493)
!1493 = distinct !DILexicalBlock(scope: !1489, file: !3, line: 1114, column: 31)
!1494 = !DILocation(line: 1115, column: 9, scope: !1493)
!1495 = !DILocation(line: 1115, column: 7, scope: !1493)
!1496 = !DILocation(line: 1116, column: 31, scope: !1493)
!1497 = !DILocation(line: 1116, column: 47, scope: !1493)
!1498 = !DILocation(line: 1116, column: 51, scope: !1493)
!1499 = !DILocation(line: 1116, column: 53, scope: !1493)
!1500 = !DILocation(line: 1116, column: 42, scope: !1493)
!1501 = !DILocation(line: 1116, column: 62, scope: !1493)
!1502 = !DILocation(line: 1116, column: 60, scope: !1493)
!1503 = !DILocation(line: 1116, column: 39, scope: !1493)
!1504 = !DILocation(line: 1116, column: 33, scope: !1493)
!1505 = !DILocation(line: 1116, column: 9, scope: !1493)
!1506 = !DILocation(line: 1116, column: 7, scope: !1493)
!1507 = !DILocation(line: 1117, column: 3, scope: !1493)
!1508 = !DILocation(line: 1118, column: 9, scope: !1509)
!1509 = distinct !DILexicalBlock(scope: !1489, file: !3, line: 1117, column: 10)
!1510 = !DILocation(line: 1118, column: 13, scope: !1509)
!1511 = !DILocation(line: 1118, column: 11, scope: !1509)
!1512 = !DILocation(line: 1118, column: 7, scope: !1509)
!1513 = !DILocation(line: 1119, column: 32, scope: !1509)
!1514 = !DILocation(line: 1119, column: 27, scope: !1509)
!1515 = !DILocation(line: 1119, column: 37, scope: !1509)
!1516 = !DILocation(line: 1119, column: 59, scope: !1509)
!1517 = !DILocation(line: 1119, column: 57, scope: !1509)
!1518 = !DILocation(line: 1119, column: 48, scope: !1509)
!1519 = !DILocation(line: 1119, column: 46, scope: !1509)
!1520 = !DILocation(line: 1119, column: 39, scope: !1509)
!1521 = !DILocation(line: 1119, column: 35, scope: !1509)
!1522 = !DILocation(line: 1119, column: 9, scope: !1509)
!1523 = !DILocation(line: 1119, column: 7, scope: !1509)
!1524 = !DILocation(line: 1121, column: 7, scope: !1525)
!1525 = distinct !DILexicalBlock(scope: !86, file: !3, line: 1121, column: 7)
!1526 = !DILocation(line: 1121, column: 10, scope: !1525)
!1527 = !DILocation(line: 1121, column: 7, scope: !86)
!1528 = !DILocation(line: 1122, column: 12, scope: !1529)
!1529 = distinct !DILexicalBlock(scope: !1525, file: !3, line: 1121, column: 15)
!1530 = !DILocation(line: 1122, column: 5, scope: !1529)
!1531 = !DILocation(line: 1124, column: 13, scope: !1532)
!1532 = distinct !DILexicalBlock(scope: !1525, file: !3, line: 1123, column: 10)
!1533 = !DILocation(line: 1124, column: 12, scope: !1532)
!1534 = !DILocation(line: 1124, column: 5, scope: !1532)
!1535 = !DILocation(line: 1126, column: 1, scope: !86)
!1536 = !DILocalVariable(name: "x", arg: 1, scope: !93, file: !3, line: 1147, type: !6)
!1537 = !DILocation(line: 1147, column: 32, scope: !93)
!1538 = !DILocalVariable(name: "w", scope: !93, file: !3, line: 1178, type: !6)
!1539 = !DILocation(line: 1178, column: 10, scope: !93)
!1540 = !DILocalVariable(name: "s1", scope: !93, file: !3, line: 1178, type: !6)
!1541 = !DILocation(line: 1178, column: 13, scope: !93)
!1542 = !DILocalVariable(name: "s2", scope: !93, file: !3, line: 1178, type: !6)
!1543 = !DILocation(line: 1178, column: 17, scope: !93)
!1544 = !DILocalVariable(name: "z", scope: !93, file: !3, line: 1178, type: !6)
!1545 = !DILocation(line: 1178, column: 21, scope: !93)
!1546 = !DILocalVariable(name: "ix", scope: !93, file: !3, line: 1179, type: !18)
!1547 = !DILocation(line: 1179, column: 11, scope: !93)
!1548 = !DILocalVariable(name: "hx", scope: !93, file: !3, line: 1179, type: !18)
!1549 = !DILocation(line: 1179, column: 15, scope: !93)
!1550 = !DILocalVariable(name: "id", scope: !93, file: !3, line: 1179, type: !18)
!1551 = !DILocation(line: 1179, column: 19, scope: !93)
!1552 = !DILocation(line: 1181, column: 3, scope: !93)
!1553 = !DILocalVariable(name: "bits", scope: !1554, file: !3, line: 1181, type: !16)
!1554 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1181, column: 3)
!1555 = !DILocation(line: 1181, column: 3, scope: !1554)
!1556 = !DILocation(line: 1182, column: 8, scope: !93)
!1557 = !DILocation(line: 1182, column: 11, scope: !93)
!1558 = !DILocation(line: 1182, column: 6, scope: !93)
!1559 = !DILocation(line: 1183, column: 7, scope: !1560)
!1560 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1183, column: 7)
!1561 = !DILocation(line: 1183, column: 10, scope: !1560)
!1562 = !DILocation(line: 1183, column: 7, scope: !93)
!1563 = !DILocalVariable(name: "low", scope: !1564, file: !3, line: 1184, type: !9)
!1564 = distinct !DILexicalBlock(scope: !1560, file: !3, line: 1183, column: 25)
!1565 = !DILocation(line: 1184, column: 14, scope: !1564)
!1566 = !DILocation(line: 1185, column: 5, scope: !1564)
!1567 = !DILocalVariable(name: "bits", scope: !1568, file: !3, line: 1185, type: !16)
!1568 = distinct !DILexicalBlock(scope: !1564, file: !3, line: 1185, column: 5)
!1569 = !DILocation(line: 1185, column: 5, scope: !1568)
!1570 = !DILocation(line: 1186, column: 9, scope: !1571)
!1571 = distinct !DILexicalBlock(scope: !1564, file: !3, line: 1186, column: 9)
!1572 = !DILocation(line: 1186, column: 12, scope: !1571)
!1573 = !DILocation(line: 1186, column: 25, scope: !1571)
!1574 = !DILocation(line: 1186, column: 29, scope: !1571)
!1575 = !DILocation(line: 1186, column: 32, scope: !1571)
!1576 = !DILocation(line: 1186, column: 46, scope: !1571)
!1577 = !DILocation(line: 1186, column: 50, scope: !1571)
!1578 = !DILocation(line: 1186, column: 54, scope: !1571)
!1579 = !DILocation(line: 1186, column: 9, scope: !1564)
!1580 = !DILocation(line: 1187, column: 14, scope: !1571)
!1581 = !DILocation(line: 1187, column: 18, scope: !1571)
!1582 = !DILocation(line: 1187, column: 16, scope: !1571)
!1583 = !DILocation(line: 1187, column: 7, scope: !1571)
!1584 = !DILocation(line: 1188, column: 9, scope: !1585)
!1585 = distinct !DILexicalBlock(scope: !1564, file: !3, line: 1188, column: 9)
!1586 = !DILocation(line: 1188, column: 12, scope: !1585)
!1587 = !DILocation(line: 1188, column: 9, scope: !1564)
!1588 = !DILocation(line: 1189, column: 14, scope: !1585)
!1589 = !DILocation(line: 1189, column: 26, scope: !1585)
!1590 = !DILocation(line: 1189, column: 24, scope: !1585)
!1591 = !DILocation(line: 1189, column: 7, scope: !1585)
!1592 = !DILocation(line: 1191, column: 15, scope: !1585)
!1593 = !DILocation(line: 1191, column: 14, scope: !1585)
!1594 = !DILocation(line: 1191, column: 27, scope: !1585)
!1595 = !DILocation(line: 1191, column: 25, scope: !1585)
!1596 = !DILocation(line: 1191, column: 7, scope: !1585)
!1597 = !DILocation(line: 1193, column: 7, scope: !1598)
!1598 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1193, column: 7)
!1599 = !DILocation(line: 1193, column: 10, scope: !1598)
!1600 = !DILocation(line: 1193, column: 7, scope: !93)
!1601 = !DILocation(line: 1194, column: 9, scope: !1602)
!1602 = distinct !DILexicalBlock(scope: !1603, file: !3, line: 1194, column: 9)
!1603 = distinct !DILexicalBlock(scope: !1598, file: !3, line: 1193, column: 24)
!1604 = !DILocation(line: 1194, column: 12, scope: !1602)
!1605 = !DILocation(line: 1194, column: 9, scope: !1603)
!1606 = !DILocation(line: 1195, column: 18, scope: !1607)
!1607 = distinct !DILexicalBlock(scope: !1608, file: !3, line: 1195, column: 11)
!1608 = distinct !DILexicalBlock(scope: !1602, file: !3, line: 1194, column: 26)
!1609 = !DILocation(line: 1195, column: 16, scope: !1607)
!1610 = !DILocation(line: 1195, column: 20, scope: !1607)
!1611 = !DILocation(line: 1195, column: 11, scope: !1608)
!1612 = !DILocation(line: 1195, column: 34, scope: !1607)
!1613 = !DILocation(line: 1195, column: 27, scope: !1607)
!1614 = !DILocation(line: 1196, column: 5, scope: !1608)
!1615 = !DILocation(line: 1197, column: 8, scope: !1603)
!1616 = !DILocation(line: 1198, column: 3, scope: !1603)
!1617 = !DILocation(line: 1199, column: 14, scope: !1618)
!1618 = distinct !DILexicalBlock(scope: !1598, file: !3, line: 1198, column: 10)
!1619 = !DILocation(line: 1199, column: 9, scope: !1618)
!1620 = !DILocation(line: 1199, column: 7, scope: !1618)
!1621 = !DILocation(line: 1200, column: 9, scope: !1622)
!1622 = distinct !DILexicalBlock(scope: !1618, file: !3, line: 1200, column: 9)
!1623 = !DILocation(line: 1200, column: 12, scope: !1622)
!1624 = !DILocation(line: 1200, column: 9, scope: !1618)
!1625 = !DILocation(line: 1201, column: 11, scope: !1626)
!1626 = distinct !DILexicalBlock(scope: !1627, file: !3, line: 1201, column: 11)
!1627 = distinct !DILexicalBlock(scope: !1622, file: !3, line: 1200, column: 26)
!1628 = !DILocation(line: 1201, column: 14, scope: !1626)
!1629 = !DILocation(line: 1201, column: 11, scope: !1627)
!1630 = !DILocation(line: 1202, column: 12, scope: !1631)
!1631 = distinct !DILexicalBlock(scope: !1626, file: !3, line: 1201, column: 28)
!1632 = !DILocation(line: 1203, column: 20, scope: !1631)
!1633 = !DILocation(line: 1203, column: 22, scope: !1631)
!1634 = !DILocation(line: 1203, column: 38, scope: !1631)
!1635 = !DILocation(line: 1203, column: 36, scope: !1631)
!1636 = !DILocation(line: 1203, column: 29, scope: !1631)
!1637 = !DILocation(line: 1203, column: 11, scope: !1631)
!1638 = !DILocation(line: 1204, column: 7, scope: !1631)
!1639 = !DILocation(line: 1205, column: 12, scope: !1640)
!1640 = distinct !DILexicalBlock(scope: !1626, file: !3, line: 1204, column: 14)
!1641 = !DILocation(line: 1206, column: 14, scope: !1640)
!1642 = !DILocation(line: 1206, column: 16, scope: !1640)
!1643 = !DILocation(line: 1206, column: 26, scope: !1640)
!1644 = !DILocation(line: 1206, column: 28, scope: !1640)
!1645 = !DILocation(line: 1206, column: 23, scope: !1640)
!1646 = !DILocation(line: 1206, column: 11, scope: !1640)
!1647 = !DILocation(line: 1208, column: 5, scope: !1627)
!1648 = !DILocation(line: 1209, column: 11, scope: !1649)
!1649 = distinct !DILexicalBlock(scope: !1650, file: !3, line: 1209, column: 11)
!1650 = distinct !DILexicalBlock(scope: !1622, file: !3, line: 1208, column: 12)
!1651 = !DILocation(line: 1209, column: 14, scope: !1649)
!1652 = !DILocation(line: 1209, column: 11, scope: !1650)
!1653 = !DILocation(line: 1210, column: 12, scope: !1654)
!1654 = distinct !DILexicalBlock(scope: !1649, file: !3, line: 1209, column: 28)
!1655 = !DILocation(line: 1211, column: 14, scope: !1654)
!1656 = !DILocation(line: 1211, column: 16, scope: !1654)
!1657 = !DILocation(line: 1211, column: 38, scope: !1654)
!1658 = !DILocation(line: 1211, column: 30, scope: !1654)
!1659 = !DILocation(line: 1211, column: 23, scope: !1654)
!1660 = !DILocation(line: 1211, column: 11, scope: !1654)
!1661 = !DILocation(line: 1212, column: 7, scope: !1654)
!1662 = !DILocation(line: 1213, column: 12, scope: !1663)
!1663 = distinct !DILexicalBlock(scope: !1649, file: !3, line: 1212, column: 14)
!1664 = !DILocation(line: 1214, column: 20, scope: !1663)
!1665 = !DILocation(line: 1214, column: 18, scope: !1663)
!1666 = !DILocation(line: 1214, column: 11, scope: !1663)
!1667 = !DILocation(line: 1219, column: 7, scope: !93)
!1668 = !DILocation(line: 1219, column: 11, scope: !93)
!1669 = !DILocation(line: 1219, column: 9, scope: !93)
!1670 = !DILocation(line: 1219, column: 5, scope: !93)
!1671 = !DILocation(line: 1220, column: 7, scope: !93)
!1672 = !DILocation(line: 1220, column: 11, scope: !93)
!1673 = !DILocation(line: 1220, column: 9, scope: !93)
!1674 = !DILocation(line: 1220, column: 5, scope: !93)
!1675 = !DILocation(line: 1222, column: 8, scope: !93)
!1676 = !DILocation(line: 1222, column: 13, scope: !93)
!1677 = !DILocation(line: 1223, column: 13, scope: !93)
!1678 = !DILocation(line: 1223, column: 18, scope: !93)
!1679 = !DILocation(line: 1223, column: 26, scope: !93)
!1680 = !DILocation(line: 1223, column: 31, scope: !93)
!1681 = !DILocation(line: 1223, column: 39, scope: !93)
!1682 = !DILocation(line: 1223, column: 44, scope: !93)
!1683 = !DILocation(line: 1223, column: 52, scope: !93)
!1684 = !DILocation(line: 1223, column: 57, scope: !93)
!1685 = !DILocation(line: 1223, column: 65, scope: !93)
!1686 = !DILocation(line: 1223, column: 69, scope: !93)
!1687 = !DILocation(line: 1223, column: 63, scope: !93)
!1688 = !DILocation(line: 1223, column: 50, scope: !93)
!1689 = !DILocation(line: 1223, column: 37, scope: !93)
!1690 = !DILocation(line: 1223, column: 24, scope: !93)
!1691 = !DILocation(line: 1222, column: 19, scope: !93)
!1692 = !DILocation(line: 1222, column: 10, scope: !93)
!1693 = !DILocation(line: 1222, column: 6, scope: !93)
!1694 = !DILocation(line: 1224, column: 8, scope: !93)
!1695 = !DILocation(line: 1224, column: 13, scope: !93)
!1696 = !DILocation(line: 1224, column: 21, scope: !93)
!1697 = !DILocation(line: 1224, column: 26, scope: !93)
!1698 = !DILocation(line: 1224, column: 34, scope: !93)
!1699 = !DILocation(line: 1224, column: 39, scope: !93)
!1700 = !DILocation(line: 1224, column: 47, scope: !93)
!1701 = !DILocation(line: 1224, column: 52, scope: !93)
!1702 = !DILocation(line: 1224, column: 60, scope: !93)
!1703 = !DILocation(line: 1224, column: 64, scope: !93)
!1704 = !DILocation(line: 1224, column: 58, scope: !93)
!1705 = !DILocation(line: 1224, column: 45, scope: !93)
!1706 = !DILocation(line: 1224, column: 32, scope: !93)
!1707 = !DILocation(line: 1224, column: 19, scope: !93)
!1708 = !DILocation(line: 1224, column: 10, scope: !93)
!1709 = !DILocation(line: 1224, column: 6, scope: !93)
!1710 = !DILocation(line: 1225, column: 7, scope: !1711)
!1711 = distinct !DILexicalBlock(scope: !93, file: !3, line: 1225, column: 7)
!1712 = !DILocation(line: 1225, column: 10, scope: !1711)
!1713 = !DILocation(line: 1225, column: 7, scope: !93)
!1714 = !DILocation(line: 1226, column: 12, scope: !1715)
!1715 = distinct !DILexicalBlock(scope: !1711, file: !3, line: 1225, column: 15)
!1716 = !DILocation(line: 1226, column: 16, scope: !1715)
!1717 = !DILocation(line: 1226, column: 21, scope: !1715)
!1718 = !DILocation(line: 1226, column: 26, scope: !1715)
!1719 = !DILocation(line: 1226, column: 24, scope: !1715)
!1720 = !DILocation(line: 1226, column: 14, scope: !1715)
!1721 = !DILocation(line: 1226, column: 5, scope: !1715)
!1722 = !DILocation(line: 1228, column: 16, scope: !1723)
!1723 = distinct !DILexicalBlock(scope: !1711, file: !3, line: 1227, column: 10)
!1724 = !DILocation(line: 1228, column: 9, scope: !1723)
!1725 = !DILocation(line: 1228, column: 24, scope: !1723)
!1726 = !DILocation(line: 1228, column: 29, scope: !1723)
!1727 = !DILocation(line: 1228, column: 34, scope: !1723)
!1728 = !DILocation(line: 1228, column: 32, scope: !1723)
!1729 = !DILocation(line: 1228, column: 47, scope: !1723)
!1730 = !DILocation(line: 1228, column: 40, scope: !1723)
!1731 = !DILocation(line: 1228, column: 38, scope: !1723)
!1732 = !DILocation(line: 1228, column: 54, scope: !1723)
!1733 = !DILocation(line: 1228, column: 52, scope: !1723)
!1734 = !DILocation(line: 1228, column: 20, scope: !1723)
!1735 = !DILocation(line: 1228, column: 7, scope: !1723)
!1736 = !DILocation(line: 1229, column: 13, scope: !1723)
!1737 = !DILocation(line: 1229, column: 16, scope: !1723)
!1738 = !DILocation(line: 1229, column: 12, scope: !1723)
!1739 = !DILocation(line: 1229, column: 24, scope: !1723)
!1740 = !DILocation(line: 1229, column: 23, scope: !1723)
!1741 = !DILocation(line: 1229, column: 28, scope: !1723)
!1742 = !DILocation(line: 1229, column: 5, scope: !1723)
!1743 = !DILocation(line: 1231, column: 1, scope: !93)
!1744 = !DILocalVariable(name: "y", arg: 1, scope: !110, file: !3, line: 1259, type: !6)
!1745 = !DILocation(line: 1259, column: 33, scope: !110)
!1746 = !DILocalVariable(name: "x", arg: 2, scope: !110, file: !3, line: 1259, type: !6)
!1747 = !DILocation(line: 1259, column: 43, scope: !110)
!1748 = !DILocalVariable(name: "z", scope: !110, file: !3, line: 1269, type: !6)
!1749 = !DILocation(line: 1269, column: 10, scope: !110)
!1750 = !DILocalVariable(name: "k", scope: !110, file: !3, line: 1270, type: !18)
!1751 = !DILocation(line: 1270, column: 11, scope: !110)
!1752 = !DILocalVariable(name: "m", scope: !110, file: !3, line: 1270, type: !18)
!1753 = !DILocation(line: 1270, column: 14, scope: !110)
!1754 = !DILocalVariable(name: "hx", scope: !110, file: !3, line: 1270, type: !18)
!1755 = !DILocation(line: 1270, column: 17, scope: !110)
!1756 = !DILocalVariable(name: "hy", scope: !110, file: !3, line: 1270, type: !18)
!1757 = !DILocation(line: 1270, column: 21, scope: !110)
!1758 = !DILocalVariable(name: "ix", scope: !110, file: !3, line: 1270, type: !18)
!1759 = !DILocation(line: 1270, column: 25, scope: !110)
!1760 = !DILocalVariable(name: "iy", scope: !110, file: !3, line: 1270, type: !18)
!1761 = !DILocation(line: 1270, column: 29, scope: !110)
!1762 = !DILocalVariable(name: "lx", scope: !110, file: !3, line: 1271, type: !9)
!1763 = !DILocation(line: 1271, column: 12, scope: !110)
!1764 = !DILocalVariable(name: "ly", scope: !110, file: !3, line: 1271, type: !9)
!1765 = !DILocation(line: 1271, column: 16, scope: !110)
!1766 = !DILocation(line: 1273, column: 3, scope: !110)
!1767 = !DILocalVariable(name: "bits", scope: !1768, file: !3, line: 1273, type: !16)
!1768 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1273, column: 3)
!1769 = !DILocation(line: 1273, column: 3, scope: !1768)
!1770 = !DILocation(line: 1274, column: 8, scope: !110)
!1771 = !DILocation(line: 1274, column: 11, scope: !110)
!1772 = !DILocation(line: 1274, column: 6, scope: !110)
!1773 = !DILocation(line: 1275, column: 3, scope: !110)
!1774 = !DILocalVariable(name: "bits", scope: !1775, file: !3, line: 1275, type: !16)
!1775 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1275, column: 3)
!1776 = !DILocation(line: 1275, column: 3, scope: !1775)
!1777 = !DILocation(line: 1276, column: 8, scope: !110)
!1778 = !DILocation(line: 1276, column: 11, scope: !110)
!1779 = !DILocation(line: 1276, column: 6, scope: !110)
!1780 = !DILocation(line: 1277, column: 9, scope: !1781)
!1781 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1277, column: 7)
!1782 = !DILocation(line: 1277, column: 16, scope: !1781)
!1783 = !DILocation(line: 1277, column: 44, scope: !1781)
!1784 = !DILocation(line: 1277, column: 21, scope: !1781)
!1785 = !DILocation(line: 1277, column: 19, scope: !1781)
!1786 = !DILocation(line: 1277, column: 49, scope: !1781)
!1787 = !DILocation(line: 1277, column: 12, scope: !1781)
!1788 = !DILocation(line: 1277, column: 57, scope: !1781)
!1789 = !DILocation(line: 1277, column: 71, scope: !1781)
!1790 = !DILocation(line: 1278, column: 9, scope: !1781)
!1791 = !DILocation(line: 1278, column: 16, scope: !1781)
!1792 = !DILocation(line: 1278, column: 44, scope: !1781)
!1793 = !DILocation(line: 1278, column: 21, scope: !1781)
!1794 = !DILocation(line: 1278, column: 19, scope: !1781)
!1795 = !DILocation(line: 1278, column: 49, scope: !1781)
!1796 = !DILocation(line: 1278, column: 12, scope: !1781)
!1797 = !DILocation(line: 1278, column: 57, scope: !1781)
!1798 = !DILocation(line: 1277, column: 7, scope: !110)
!1799 = !DILocation(line: 1279, column: 12, scope: !1800)
!1800 = distinct !DILexicalBlock(scope: !1781, file: !3, line: 1278, column: 72)
!1801 = !DILocation(line: 1279, column: 16, scope: !1800)
!1802 = !DILocation(line: 1279, column: 14, scope: !1800)
!1803 = !DILocation(line: 1279, column: 5, scope: !1800)
!1804 = !DILocation(line: 1281, column: 28, scope: !1805)
!1805 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1281, column: 7)
!1806 = !DILocation(line: 1281, column: 8, scope: !1805)
!1807 = !DILocation(line: 1281, column: 46, scope: !1805)
!1808 = !DILocation(line: 1281, column: 44, scope: !1805)
!1809 = !DILocation(line: 1281, column: 50, scope: !1805)
!1810 = !DILocation(line: 1281, column: 7, scope: !110)
!1811 = !DILocation(line: 1282, column: 29, scope: !1812)
!1812 = distinct !DILexicalBlock(scope: !1805, file: !3, line: 1281, column: 56)
!1813 = !DILocation(line: 1282, column: 12, scope: !1812)
!1814 = !DILocation(line: 1282, column: 5, scope: !1812)
!1815 = !DILocation(line: 1284, column: 9, scope: !110)
!1816 = !DILocation(line: 1284, column: 12, scope: !110)
!1817 = !DILocation(line: 1284, column: 19, scope: !110)
!1818 = !DILocation(line: 1284, column: 28, scope: !110)
!1819 = !DILocation(line: 1284, column: 31, scope: !110)
!1820 = !DILocation(line: 1284, column: 38, scope: !110)
!1821 = !DILocation(line: 1284, column: 24, scope: !110)
!1822 = !DILocation(line: 1284, column: 5, scope: !110)
!1823 = !DILocation(line: 1287, column: 8, scope: !1824)
!1824 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1287, column: 7)
!1825 = !DILocation(line: 1287, column: 13, scope: !1824)
!1826 = !DILocation(line: 1287, column: 11, scope: !1824)
!1827 = !DILocation(line: 1287, column: 17, scope: !1824)
!1828 = !DILocation(line: 1287, column: 7, scope: !110)
!1829 = !DILocation(line: 1288, column: 13, scope: !1830)
!1830 = distinct !DILexicalBlock(scope: !1824, file: !3, line: 1287, column: 23)
!1831 = !DILocation(line: 1288, column: 5, scope: !1830)
!1832 = !DILocation(line: 1291, column: 16, scope: !1833)
!1833 = distinct !DILexicalBlock(scope: !1830, file: !3, line: 1288, column: 16)
!1834 = !DILocation(line: 1291, column: 9, scope: !1833)
!1835 = !DILocation(line: 1293, column: 21, scope: !1833)
!1836 = !DILocation(line: 1293, column: 19, scope: !1833)
!1837 = !DILocation(line: 1293, column: 9, scope: !1833)
!1838 = !DILocation(line: 1295, column: 22, scope: !1833)
!1839 = !DILocation(line: 1295, column: 20, scope: !1833)
!1840 = !DILocation(line: 1295, column: 9, scope: !1833)
!1841 = !DILocation(line: 1297, column: 3, scope: !1830)
!1842 = !DILocation(line: 1299, column: 8, scope: !1843)
!1843 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1299, column: 7)
!1844 = !DILocation(line: 1299, column: 13, scope: !1843)
!1845 = !DILocation(line: 1299, column: 11, scope: !1843)
!1846 = !DILocation(line: 1299, column: 17, scope: !1843)
!1847 = !DILocation(line: 1299, column: 7, scope: !110)
!1848 = !DILocation(line: 1299, column: 31, scope: !1843)
!1849 = !DILocation(line: 1299, column: 34, scope: !1843)
!1850 = !DILocation(line: 1299, column: 30, scope: !1843)
!1851 = !DILocation(line: 1299, column: 51, scope: !1843)
!1852 = !DILocation(line: 1299, column: 49, scope: !1843)
!1853 = !DILocation(line: 1299, column: 67, scope: !1843)
!1854 = !DILocation(line: 1299, column: 65, scope: !1843)
!1855 = !DILocation(line: 1299, column: 23, scope: !1843)
!1856 = !DILocation(line: 1302, column: 7, scope: !1857)
!1857 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1302, column: 7)
!1858 = !DILocation(line: 1302, column: 10, scope: !1857)
!1859 = !DILocation(line: 1302, column: 7, scope: !110)
!1860 = !DILocation(line: 1303, column: 9, scope: !1861)
!1861 = distinct !DILexicalBlock(scope: !1862, file: !3, line: 1303, column: 9)
!1862 = distinct !DILexicalBlock(scope: !1857, file: !3, line: 1302, column: 25)
!1863 = !DILocation(line: 1303, column: 12, scope: !1861)
!1864 = !DILocation(line: 1303, column: 9, scope: !1862)
!1865 = !DILocation(line: 1304, column: 15, scope: !1866)
!1866 = distinct !DILexicalBlock(scope: !1861, file: !3, line: 1303, column: 27)
!1867 = !DILocation(line: 1304, column: 7, scope: !1866)
!1868 = !DILocation(line: 1306, column: 27, scope: !1869)
!1869 = distinct !DILexicalBlock(scope: !1866, file: !3, line: 1304, column: 18)
!1870 = !DILocation(line: 1306, column: 25, scope: !1869)
!1871 = !DILocation(line: 1306, column: 11, scope: !1869)
!1872 = !DILocation(line: 1308, column: 28, scope: !1869)
!1873 = !DILocation(line: 1308, column: 26, scope: !1869)
!1874 = !DILocation(line: 1308, column: 11, scope: !1869)
!1875 = !DILocation(line: 1310, column: 33, scope: !1869)
!1876 = !DILocation(line: 1310, column: 31, scope: !1869)
!1877 = !DILocation(line: 1310, column: 11, scope: !1869)
!1878 = !DILocation(line: 1312, column: 34, scope: !1869)
!1879 = !DILocation(line: 1312, column: 32, scope: !1869)
!1880 = !DILocation(line: 1312, column: 11, scope: !1869)
!1881 = !DILocation(line: 1314, column: 5, scope: !1866)
!1882 = !DILocation(line: 1315, column: 15, scope: !1883)
!1883 = distinct !DILexicalBlock(scope: !1861, file: !3, line: 1314, column: 12)
!1884 = !DILocation(line: 1315, column: 7, scope: !1883)
!1885 = !DILocation(line: 1317, column: 11, scope: !1886)
!1886 = distinct !DILexicalBlock(scope: !1883, file: !3, line: 1315, column: 18)
!1887 = !DILocation(line: 1319, column: 11, scope: !1886)
!1888 = !DILocation(line: 1321, column: 23, scope: !1886)
!1889 = !DILocation(line: 1321, column: 21, scope: !1886)
!1890 = !DILocation(line: 1321, column: 11, scope: !1886)
!1891 = !DILocation(line: 1323, column: 24, scope: !1886)
!1892 = !DILocation(line: 1323, column: 22, scope: !1886)
!1893 = !DILocation(line: 1323, column: 11, scope: !1886)
!1894 = !DILocation(line: 1326, column: 3, scope: !1862)
!1895 = !DILocation(line: 1328, column: 7, scope: !1896)
!1896 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1328, column: 7)
!1897 = !DILocation(line: 1328, column: 10, scope: !1896)
!1898 = !DILocation(line: 1328, column: 7, scope: !110)
!1899 = !DILocation(line: 1328, column: 33, scope: !1896)
!1900 = !DILocation(line: 1328, column: 36, scope: !1896)
!1901 = !DILocation(line: 1328, column: 32, scope: !1896)
!1902 = !DILocation(line: 1328, column: 53, scope: !1896)
!1903 = !DILocation(line: 1328, column: 51, scope: !1896)
!1904 = !DILocation(line: 1328, column: 69, scope: !1896)
!1905 = !DILocation(line: 1328, column: 67, scope: !1896)
!1906 = !DILocation(line: 1328, column: 25, scope: !1896)
!1907 = !DILocation(line: 1331, column: 8, scope: !110)
!1908 = !DILocation(line: 1331, column: 13, scope: !110)
!1909 = !DILocation(line: 1331, column: 11, scope: !110)
!1910 = !DILocation(line: 1331, column: 17, scope: !110)
!1911 = !DILocation(line: 1331, column: 5, scope: !110)
!1912 = !DILocation(line: 1332, column: 7, scope: !1913)
!1913 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1332, column: 7)
!1914 = !DILocation(line: 1332, column: 9, scope: !1913)
!1915 = !DILocation(line: 1332, column: 7, scope: !110)
!1916 = !DILocation(line: 1333, column: 24, scope: !1917)
!1917 = distinct !DILexicalBlock(scope: !1913, file: !3, line: 1332, column: 15)
!1918 = !DILocation(line: 1333, column: 16, scope: !1917)
!1919 = !DILocation(line: 1333, column: 7, scope: !1917)
!1920 = !DILocation(line: 1334, column: 7, scope: !1917)
!1921 = !DILocation(line: 1335, column: 3, scope: !1917)
!1922 = !DILocation(line: 1335, column: 14, scope: !1923)
!1923 = distinct !DILexicalBlock(scope: !1913, file: !3, line: 1335, column: 14)
!1924 = !DILocation(line: 1335, column: 17, scope: !1923)
!1925 = !DILocation(line: 1335, column: 21, scope: !1923)
!1926 = !DILocation(line: 1335, column: 24, scope: !1923)
!1927 = !DILocation(line: 1335, column: 26, scope: !1923)
!1928 = !DILocation(line: 1335, column: 14, scope: !1913)
!1929 = !DILocation(line: 1336, column: 7, scope: !1930)
!1930 = distinct !DILexicalBlock(scope: !1923, file: !3, line: 1335, column: 33)
!1931 = !DILocation(line: 1337, column: 3, scope: !1930)
!1932 = !DILocation(line: 1338, column: 31, scope: !1933)
!1933 = distinct !DILexicalBlock(scope: !1923, file: !3, line: 1337, column: 10)
!1934 = !DILocation(line: 1338, column: 35, scope: !1933)
!1935 = !DILocation(line: 1338, column: 33, scope: !1933)
!1936 = !DILocation(line: 1338, column: 26, scope: !1933)
!1937 = !DILocation(line: 1338, column: 9, scope: !1933)
!1938 = !DILocation(line: 1338, column: 7, scope: !1933)
!1939 = !DILocation(line: 1340, column: 11, scope: !110)
!1940 = !DILocation(line: 1340, column: 3, scope: !110)
!1941 = !DILocation(line: 1342, column: 14, scope: !1942)
!1942 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1340, column: 14)
!1943 = !DILocation(line: 1342, column: 7, scope: !1942)
!1944 = !DILocation(line: 1344, column: 15, scope: !1942)
!1945 = !DILocation(line: 1344, column: 14, scope: !1942)
!1946 = !DILocation(line: 1344, column: 7, scope: !1942)
!1947 = !DILocation(line: 1346, column: 20, scope: !1942)
!1948 = !DILocation(line: 1346, column: 24, scope: !1942)
!1949 = !DILocation(line: 1346, column: 22, scope: !1942)
!1950 = !DILocation(line: 1346, column: 17, scope: !1942)
!1951 = !DILocation(line: 1346, column: 7, scope: !1942)
!1952 = !DILocation(line: 1348, column: 15, scope: !1942)
!1953 = !DILocation(line: 1348, column: 19, scope: !1942)
!1954 = !DILocation(line: 1348, column: 17, scope: !1942)
!1955 = !DILocation(line: 1348, column: 26, scope: !1942)
!1956 = !DILocation(line: 1348, column: 7, scope: !1942)
!1957 = !DILocation(line: 1350, column: 1, scope: !110)
!1958 = distinct !DISubprogram(name: "negate_with_wraparound", scope: !3, file: !3, line: 67, type: !1959, scopeLine: 67, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!1959 = !DISubroutineType(types: !1960)
!1960 = !{!18, !18}
!1961 = !DILocalVariable(name: "x", arg: 1, scope: !1958, file: !3, line: 67, type: !18)
!1962 = !DILocation(line: 67, column: 54, scope: !1958)
!1963 = !DILocation(line: 67, column: 91, scope: !1958)
!1964 = !DILocation(line: 67, column: 79, scope: !1958)
!1965 = !DILocation(line: 67, column: 59, scope: !1958)
!1966 = distinct !DISubprogram(name: "sub_with_wraparound", scope: !3, file: !3, line: 68, type: !1967, scopeLine: 68, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!1967 = !DISubroutineType(types: !1968)
!1968 = !{!18, !18, !18}
!1969 = !DILocalVariable(name: "a", arg: 1, scope: !1966, file: !3, line: 68, type: !18)
!1970 = !DILocation(line: 68, column: 51, scope: !1966)
!1971 = !DILocalVariable(name: "b", arg: 2, scope: !1966, file: !3, line: 68, type: !18)
!1972 = !DILocation(line: 68, column: 62, scope: !1966)
!1973 = !DILocation(line: 68, column: 94, scope: !1966)
!1974 = !DILocation(line: 68, column: 108, scope: !1966)
!1975 = !DILocation(line: 68, column: 96, scope: !1966)
!1976 = !DILocation(line: 68, column: 67, scope: !1966)
!1977 = distinct !DISubprogram(name: "pts_ieee754_cos", scope: !3, file: !3, line: 1382, type: !4, scopeLine: 1382, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!1978 = !DILocalVariable(name: "x", arg: 1, scope: !1977, file: !3, line: 1382, type: !6)
!1979 = !DILocation(line: 1382, column: 31, scope: !1977)
!1980 = !DILocalVariable(name: "y", scope: !1977, file: !3, line: 1383, type: !1981)
!1981 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 128, elements: !129)
!1982 = !DILocation(line: 1383, column: 10, scope: !1977)
!1983 = !DILocalVariable(name: "z", scope: !1977, file: !3, line: 1383, type: !6)
!1984 = !DILocation(line: 1383, column: 16, scope: !1977)
!1985 = !DILocalVariable(name: "n", scope: !1977, file: !3, line: 1384, type: !18)
!1986 = !DILocation(line: 1384, column: 11, scope: !1977)
!1987 = !DILocalVariable(name: "ix", scope: !1977, file: !3, line: 1384, type: !18)
!1988 = !DILocation(line: 1384, column: 14, scope: !1977)
!1989 = !DILocation(line: 1387, column: 3, scope: !1977)
!1990 = !DILocalVariable(name: "bits", scope: !1991, file: !3, line: 1387, type: !16)
!1991 = distinct !DILexicalBlock(scope: !1977, file: !3, line: 1387, column: 3)
!1992 = !DILocation(line: 1387, column: 3, scope: !1991)
!1993 = !DILocation(line: 1390, column: 6, scope: !1977)
!1994 = !DILocation(line: 1391, column: 7, scope: !1995)
!1995 = distinct !DILexicalBlock(scope: !1977, file: !3, line: 1391, column: 7)
!1996 = !DILocation(line: 1391, column: 10, scope: !1995)
!1997 = !DILocation(line: 1391, column: 7, scope: !1977)
!1998 = !DILocation(line: 1392, column: 25, scope: !1999)
!1999 = distinct !DILexicalBlock(scope: !1995, file: !3, line: 1391, column: 25)
!2000 = !DILocation(line: 1392, column: 28, scope: !1999)
!2001 = !DILocation(line: 1392, column: 12, scope: !1999)
!2002 = !DILocation(line: 1392, column: 5, scope: !1999)
!2003 = !DILocation(line: 1393, column: 14, scope: !2004)
!2004 = distinct !DILexicalBlock(scope: !1995, file: !3, line: 1393, column: 14)
!2005 = !DILocation(line: 1393, column: 17, scope: !2004)
!2006 = !DILocation(line: 1393, column: 14, scope: !1995)
!2007 = !DILocation(line: 1395, column: 12, scope: !2008)
!2008 = distinct !DILexicalBlock(scope: !2004, file: !3, line: 1393, column: 32)
!2009 = !DILocation(line: 1395, column: 16, scope: !2008)
!2010 = !DILocation(line: 1395, column: 14, scope: !2008)
!2011 = !DILocation(line: 1395, column: 5, scope: !2008)
!2012 = !DILocation(line: 1398, column: 28, scope: !2013)
!2013 = distinct !DILexicalBlock(scope: !2004, file: !3, line: 1396, column: 10)
!2014 = !DILocation(line: 1398, column: 31, scope: !2013)
!2015 = !DILocation(line: 1398, column: 9, scope: !2013)
!2016 = !DILocation(line: 1398, column: 7, scope: !2013)
!2017 = !DILocation(line: 1399, column: 13, scope: !2013)
!2018 = !DILocation(line: 1399, column: 15, scope: !2013)
!2019 = !DILocation(line: 1399, column: 5, scope: !2013)
!2020 = !DILocation(line: 1401, column: 29, scope: !2021)
!2021 = distinct !DILexicalBlock(scope: !2013, file: !3, line: 1399, column: 20)
!2022 = !DILocation(line: 1401, column: 35, scope: !2021)
!2023 = !DILocation(line: 1401, column: 16, scope: !2021)
!2024 = !DILocation(line: 1401, column: 9, scope: !2021)
!2025 = !DILocation(line: 1403, column: 30, scope: !2021)
!2026 = !DILocation(line: 1403, column: 36, scope: !2021)
!2027 = !DILocation(line: 1403, column: 17, scope: !2021)
!2028 = !DILocation(line: 1403, column: 16, scope: !2021)
!2029 = !DILocation(line: 1403, column: 9, scope: !2021)
!2030 = !DILocation(line: 1405, column: 30, scope: !2021)
!2031 = !DILocation(line: 1405, column: 36, scope: !2021)
!2032 = !DILocation(line: 1405, column: 17, scope: !2021)
!2033 = !DILocation(line: 1405, column: 16, scope: !2021)
!2034 = !DILocation(line: 1405, column: 9, scope: !2021)
!2035 = !DILocation(line: 1407, column: 29, scope: !2021)
!2036 = !DILocation(line: 1407, column: 35, scope: !2021)
!2037 = !DILocation(line: 1407, column: 16, scope: !2021)
!2038 = !DILocation(line: 1407, column: 9, scope: !2021)
!2039 = !DILocation(line: 1410, column: 1, scope: !1977)
!2040 = !DILocalVariable(name: "x", arg: 1, scope: !298, file: !3, line: 336, type: !6)
!2041 = !DILocation(line: 336, column: 42, scope: !298)
!2042 = !DILocalVariable(name: "y", arg: 2, scope: !298, file: !3, line: 336, type: !6)
!2043 = !DILocation(line: 336, column: 52, scope: !298)
!2044 = !DILocalVariable(name: "a", scope: !298, file: !3, line: 346, type: !6)
!2045 = !DILocation(line: 346, column: 10, scope: !298)
!2046 = !DILocalVariable(name: "iz", scope: !298, file: !3, line: 346, type: !6)
!2047 = !DILocation(line: 346, column: 13, scope: !298)
!2048 = !DILocalVariable(name: "z", scope: !298, file: !3, line: 346, type: !6)
!2049 = !DILocation(line: 346, column: 17, scope: !298)
!2050 = !DILocalVariable(name: "r", scope: !298, file: !3, line: 346, type: !6)
!2051 = !DILocation(line: 346, column: 20, scope: !298)
!2052 = !DILocalVariable(name: "qx", scope: !298, file: !3, line: 346, type: !6)
!2053 = !DILocation(line: 346, column: 23, scope: !298)
!2054 = !DILocalVariable(name: "ix", scope: !298, file: !3, line: 347, type: !18)
!2055 = !DILocation(line: 347, column: 11, scope: !298)
!2056 = !DILocation(line: 348, column: 3, scope: !298)
!2057 = !DILocalVariable(name: "bits", scope: !2058, file: !3, line: 348, type: !16)
!2058 = distinct !DILexicalBlock(scope: !298, file: !3, line: 348, column: 3)
!2059 = !DILocation(line: 348, column: 3, scope: !2058)
!2060 = !DILocation(line: 349, column: 6, scope: !298)
!2061 = !DILocation(line: 350, column: 7, scope: !2062)
!2062 = distinct !DILexicalBlock(scope: !298, file: !3, line: 350, column: 7)
!2063 = !DILocation(line: 350, column: 10, scope: !2062)
!2064 = !DILocation(line: 350, column: 7, scope: !298)
!2065 = !DILocation(line: 351, column: 15, scope: !2066)
!2066 = distinct !DILexicalBlock(scope: !2067, file: !3, line: 351, column: 9)
!2067 = distinct !DILexicalBlock(scope: !2062, file: !3, line: 350, column: 24)
!2068 = !DILocation(line: 351, column: 9, scope: !2066)
!2069 = !DILocation(line: 351, column: 18, scope: !2066)
!2070 = !DILocation(line: 351, column: 9, scope: !2067)
!2071 = !DILocation(line: 351, column: 24, scope: !2066)
!2072 = !DILocation(line: 352, column: 3, scope: !2067)
!2073 = !DILocation(line: 353, column: 7, scope: !298)
!2074 = !DILocation(line: 353, column: 11, scope: !298)
!2075 = !DILocation(line: 353, column: 9, scope: !298)
!2076 = !DILocation(line: 353, column: 5, scope: !298)
!2077 = !DILocation(line: 354, column: 7, scope: !298)
!2078 = !DILocation(line: 354, column: 17, scope: !298)
!2079 = !DILocation(line: 354, column: 27, scope: !298)
!2080 = !DILocation(line: 354, column: 37, scope: !298)
!2081 = !DILocation(line: 354, column: 47, scope: !298)
!2082 = !DILocation(line: 354, column: 57, scope: !298)
!2083 = !DILocation(line: 354, column: 55, scope: !298)
!2084 = !DILocation(line: 354, column: 45, scope: !298)
!2085 = !DILocation(line: 354, column: 35, scope: !298)
!2086 = !DILocation(line: 354, column: 25, scope: !298)
!2087 = !DILocation(line: 354, column: 15, scope: !298)
!2088 = !DILocation(line: 354, column: 9, scope: !298)
!2089 = !DILocation(line: 354, column: 5, scope: !298)
!2090 = !DILocation(line: 355, column: 7, scope: !2091)
!2091 = distinct !DILexicalBlock(scope: !298, file: !3, line: 355, column: 7)
!2092 = !DILocation(line: 355, column: 10, scope: !2091)
!2093 = !DILocation(line: 355, column: 7, scope: !298)
!2094 = !DILocation(line: 356, column: 25, scope: !2095)
!2095 = distinct !DILexicalBlock(scope: !2091, file: !3, line: 355, column: 24)
!2096 = !DILocation(line: 356, column: 30, scope: !2095)
!2097 = !DILocation(line: 356, column: 34, scope: !2095)
!2098 = !DILocation(line: 356, column: 38, scope: !2095)
!2099 = !DILocation(line: 356, column: 42, scope: !2095)
!2100 = !DILocation(line: 356, column: 40, scope: !2095)
!2101 = !DILocation(line: 356, column: 36, scope: !2095)
!2102 = !DILocation(line: 356, column: 27, scope: !2095)
!2103 = !DILocation(line: 356, column: 16, scope: !2095)
!2104 = !DILocation(line: 356, column: 5, scope: !2095)
!2105 = !DILocation(line: 358, column: 9, scope: !2106)
!2106 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 358, column: 9)
!2107 = distinct !DILexicalBlock(scope: !2091, file: !3, line: 357, column: 10)
!2108 = !DILocation(line: 358, column: 12, scope: !2106)
!2109 = !DILocation(line: 358, column: 9, scope: !2107)
!2110 = !DILocation(line: 359, column: 10, scope: !2111)
!2111 = distinct !DILexicalBlock(scope: !2106, file: !3, line: 358, column: 26)
!2112 = !DILocation(line: 360, column: 5, scope: !2111)
!2113 = !DILocation(line: 361, column: 7, scope: !2114)
!2114 = distinct !DILexicalBlock(scope: !2106, file: !3, line: 360, column: 12)
!2115 = !DILocalVariable(name: "bits", scope: !2116, file: !3, line: 361, type: !16)
!2116 = distinct !DILexicalBlock(scope: !2114, file: !3, line: 361, column: 7)
!2117 = !DILocation(line: 361, column: 7, scope: !2116)
!2118 = !DILocation(line: 363, column: 16, scope: !2107)
!2119 = !DILocation(line: 363, column: 20, scope: !2107)
!2120 = !DILocation(line: 363, column: 18, scope: !2107)
!2121 = !DILocation(line: 363, column: 8, scope: !2107)
!2122 = !DILocation(line: 364, column: 15, scope: !2107)
!2123 = !DILocation(line: 364, column: 13, scope: !2107)
!2124 = !DILocation(line: 364, column: 7, scope: !2107)
!2125 = !DILocation(line: 365, column: 12, scope: !2107)
!2126 = !DILocation(line: 365, column: 17, scope: !2107)
!2127 = !DILocation(line: 365, column: 23, scope: !2107)
!2128 = !DILocation(line: 365, column: 27, scope: !2107)
!2129 = !DILocation(line: 365, column: 31, scope: !2107)
!2130 = !DILocation(line: 365, column: 35, scope: !2107)
!2131 = !DILocation(line: 365, column: 33, scope: !2107)
!2132 = !DILocation(line: 365, column: 29, scope: !2107)
!2133 = !DILocation(line: 365, column: 20, scope: !2107)
!2134 = !DILocation(line: 365, column: 14, scope: !2107)
!2135 = !DILocation(line: 365, column: 5, scope: !2107)
!2136 = !DILocation(line: 367, column: 1, scope: !298)
!2137 = !DILocalVariable(name: "x", arg: 1, scope: !313, file: !3, line: 149, type: !6)
!2138 = !DILocation(line: 149, column: 42, scope: !313)
!2139 = !DILocalVariable(name: "y", arg: 2, scope: !313, file: !3, line: 149, type: !316)
!2140 = !DILocation(line: 149, column: 53, scope: !313)
!2141 = !DILocalVariable(name: "z", scope: !313, file: !3, line: 197, type: !6)
!2142 = !DILocation(line: 197, column: 10, scope: !313)
!2143 = !DILocalVariable(name: "w", scope: !313, file: !3, line: 197, type: !6)
!2144 = !DILocation(line: 197, column: 13, scope: !313)
!2145 = !DILocalVariable(name: "t", scope: !313, file: !3, line: 197, type: !6)
!2146 = !DILocation(line: 197, column: 16, scope: !313)
!2147 = !DILocalVariable(name: "r", scope: !313, file: !3, line: 197, type: !6)
!2148 = !DILocation(line: 197, column: 19, scope: !313)
!2149 = !DILocalVariable(name: "fn", scope: !313, file: !3, line: 197, type: !6)
!2150 = !DILocation(line: 197, column: 22, scope: !313)
!2151 = !DILocalVariable(name: "tx", scope: !313, file: !3, line: 198, type: !2152)
!2152 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 192, elements: !2153)
!2153 = !{!2154}
!2154 = !DISubrange(count: 3)
!2155 = !DILocation(line: 198, column: 10, scope: !313)
!2156 = !DILocalVariable(name: "e0", scope: !313, file: !3, line: 199, type: !18)
!2157 = !DILocation(line: 199, column: 11, scope: !313)
!2158 = !DILocalVariable(name: "i", scope: !313, file: !3, line: 199, type: !18)
!2159 = !DILocation(line: 199, column: 15, scope: !313)
!2160 = !DILocalVariable(name: "j", scope: !313, file: !3, line: 199, type: !18)
!2161 = !DILocation(line: 199, column: 18, scope: !313)
!2162 = !DILocalVariable(name: "nx", scope: !313, file: !3, line: 199, type: !18)
!2163 = !DILocation(line: 199, column: 21, scope: !313)
!2164 = !DILocalVariable(name: "n", scope: !313, file: !3, line: 199, type: !18)
!2165 = !DILocation(line: 199, column: 25, scope: !313)
!2166 = !DILocalVariable(name: "ix", scope: !313, file: !3, line: 199, type: !18)
!2167 = !DILocation(line: 199, column: 28, scope: !313)
!2168 = !DILocalVariable(name: "hx", scope: !313, file: !3, line: 199, type: !18)
!2169 = !DILocation(line: 199, column: 32, scope: !313)
!2170 = !DILocalVariable(name: "low", scope: !313, file: !3, line: 200, type: !9)
!2171 = !DILocation(line: 200, column: 12, scope: !313)
!2172 = !DILocation(line: 202, column: 5, scope: !313)
!2173 = !DILocation(line: 203, column: 3, scope: !313)
!2174 = !DILocalVariable(name: "bits", scope: !2175, file: !3, line: 203, type: !16)
!2175 = distinct !DILexicalBlock(scope: !313, file: !3, line: 203, column: 3)
!2176 = !DILocation(line: 203, column: 3, scope: !2175)
!2177 = !DILocation(line: 204, column: 8, scope: !313)
!2178 = !DILocation(line: 204, column: 11, scope: !313)
!2179 = !DILocation(line: 204, column: 6, scope: !313)
!2180 = !DILocation(line: 205, column: 7, scope: !2181)
!2181 = distinct !DILexicalBlock(scope: !313, file: !3, line: 205, column: 7)
!2182 = !DILocation(line: 205, column: 10, scope: !2181)
!2183 = !DILocation(line: 205, column: 7, scope: !313)
!2184 = !DILocation(line: 206, column: 12, scope: !2185)
!2185 = distinct !DILexicalBlock(scope: !2181, file: !3, line: 205, column: 25)
!2186 = !DILocation(line: 206, column: 5, scope: !2185)
!2187 = !DILocation(line: 206, column: 10, scope: !2185)
!2188 = !DILocation(line: 207, column: 5, scope: !2185)
!2189 = !DILocation(line: 207, column: 10, scope: !2185)
!2190 = !DILocation(line: 208, column: 5, scope: !2185)
!2191 = !DILocation(line: 210, column: 7, scope: !2192)
!2192 = distinct !DILexicalBlock(scope: !313, file: !3, line: 210, column: 7)
!2193 = !DILocation(line: 210, column: 10, scope: !2192)
!2194 = !DILocation(line: 210, column: 7, scope: !313)
!2195 = !DILocation(line: 211, column: 9, scope: !2196)
!2196 = distinct !DILexicalBlock(scope: !2197, file: !3, line: 211, column: 9)
!2197 = distinct !DILexicalBlock(scope: !2192, file: !3, line: 210, column: 24)
!2198 = !DILocation(line: 211, column: 12, scope: !2196)
!2199 = !DILocation(line: 211, column: 9, scope: !2197)
!2200 = !DILocation(line: 212, column: 11, scope: !2201)
!2201 = distinct !DILexicalBlock(scope: !2196, file: !3, line: 211, column: 17)
!2202 = !DILocation(line: 212, column: 13, scope: !2201)
!2203 = !DILocation(line: 212, column: 9, scope: !2201)
!2204 = !DILocation(line: 213, column: 11, scope: !2205)
!2205 = distinct !DILexicalBlock(scope: !2201, file: !3, line: 213, column: 11)
!2206 = !DILocation(line: 213, column: 14, scope: !2205)
!2207 = !DILocation(line: 213, column: 11, scope: !2201)
!2208 = !DILocation(line: 214, column: 16, scope: !2209)
!2209 = distinct !DILexicalBlock(scope: !2205, file: !3, line: 213, column: 29)
!2210 = !DILocation(line: 214, column: 18, scope: !2209)
!2211 = !DILocation(line: 214, column: 9, scope: !2209)
!2212 = !DILocation(line: 214, column: 14, scope: !2209)
!2213 = !DILocation(line: 215, column: 17, scope: !2209)
!2214 = !DILocation(line: 215, column: 21, scope: !2209)
!2215 = !DILocation(line: 215, column: 19, scope: !2209)
!2216 = !DILocation(line: 215, column: 27, scope: !2209)
!2217 = !DILocation(line: 215, column: 9, scope: !2209)
!2218 = !DILocation(line: 215, column: 14, scope: !2209)
!2219 = !DILocation(line: 216, column: 7, scope: !2209)
!2220 = !DILocation(line: 217, column: 11, scope: !2221)
!2221 = distinct !DILexicalBlock(scope: !2205, file: !3, line: 216, column: 14)
!2222 = !DILocation(line: 218, column: 16, scope: !2221)
!2223 = !DILocation(line: 218, column: 18, scope: !2221)
!2224 = !DILocation(line: 218, column: 9, scope: !2221)
!2225 = !DILocation(line: 218, column: 14, scope: !2221)
!2226 = !DILocation(line: 219, column: 17, scope: !2221)
!2227 = !DILocation(line: 219, column: 21, scope: !2221)
!2228 = !DILocation(line: 219, column: 19, scope: !2221)
!2229 = !DILocation(line: 219, column: 27, scope: !2221)
!2230 = !DILocation(line: 219, column: 9, scope: !2221)
!2231 = !DILocation(line: 219, column: 14, scope: !2221)
!2232 = !DILocation(line: 221, column: 7, scope: !2201)
!2233 = !DILocation(line: 223, column: 11, scope: !2234)
!2234 = distinct !DILexicalBlock(scope: !2196, file: !3, line: 222, column: 12)
!2235 = !DILocation(line: 223, column: 13, scope: !2234)
!2236 = !DILocation(line: 223, column: 9, scope: !2234)
!2237 = !DILocation(line: 224, column: 11, scope: !2238)
!2238 = distinct !DILexicalBlock(scope: !2234, file: !3, line: 224, column: 11)
!2239 = !DILocation(line: 224, column: 14, scope: !2238)
!2240 = !DILocation(line: 224, column: 11, scope: !2234)
!2241 = !DILocation(line: 225, column: 16, scope: !2242)
!2242 = distinct !DILexicalBlock(scope: !2238, file: !3, line: 224, column: 29)
!2243 = !DILocation(line: 225, column: 18, scope: !2242)
!2244 = !DILocation(line: 225, column: 9, scope: !2242)
!2245 = !DILocation(line: 225, column: 14, scope: !2242)
!2246 = !DILocation(line: 226, column: 17, scope: !2242)
!2247 = !DILocation(line: 226, column: 21, scope: !2242)
!2248 = !DILocation(line: 226, column: 19, scope: !2242)
!2249 = !DILocation(line: 226, column: 27, scope: !2242)
!2250 = !DILocation(line: 226, column: 9, scope: !2242)
!2251 = !DILocation(line: 226, column: 14, scope: !2242)
!2252 = !DILocation(line: 227, column: 7, scope: !2242)
!2253 = !DILocation(line: 228, column: 11, scope: !2254)
!2254 = distinct !DILexicalBlock(scope: !2238, file: !3, line: 227, column: 14)
!2255 = !DILocation(line: 229, column: 16, scope: !2254)
!2256 = !DILocation(line: 229, column: 18, scope: !2254)
!2257 = !DILocation(line: 229, column: 9, scope: !2254)
!2258 = !DILocation(line: 229, column: 14, scope: !2254)
!2259 = !DILocation(line: 230, column: 17, scope: !2254)
!2260 = !DILocation(line: 230, column: 21, scope: !2254)
!2261 = !DILocation(line: 230, column: 19, scope: !2254)
!2262 = !DILocation(line: 230, column: 27, scope: !2254)
!2263 = !DILocation(line: 230, column: 9, scope: !2254)
!2264 = !DILocation(line: 230, column: 14, scope: !2254)
!2265 = !DILocation(line: 232, column: 7, scope: !2234)
!2266 = !DILocation(line: 235, column: 7, scope: !2267)
!2267 = distinct !DILexicalBlock(scope: !313, file: !3, line: 235, column: 7)
!2268 = !DILocation(line: 235, column: 10, scope: !2267)
!2269 = !DILocation(line: 235, column: 7, scope: !313)
!2270 = !DILocation(line: 236, column: 14, scope: !2271)
!2271 = distinct !DILexicalBlock(scope: !2267, file: !3, line: 235, column: 25)
!2272 = !DILocation(line: 236, column: 9, scope: !2271)
!2273 = !DILocation(line: 236, column: 7, scope: !2271)
!2274 = !DILocation(line: 237, column: 19, scope: !2271)
!2275 = !DILocation(line: 237, column: 31, scope: !2271)
!2276 = !DILocation(line: 237, column: 9, scope: !2271)
!2277 = !DILocation(line: 237, column: 7, scope: !2271)
!2278 = !DILocation(line: 238, column: 19, scope: !2271)
!2279 = !DILocation(line: 238, column: 10, scope: !2271)
!2280 = !DILocation(line: 238, column: 8, scope: !2271)
!2281 = !DILocation(line: 239, column: 9, scope: !2271)
!2282 = !DILocation(line: 239, column: 13, scope: !2271)
!2283 = !DILocation(line: 239, column: 11, scope: !2271)
!2284 = !DILocation(line: 239, column: 7, scope: !2271)
!2285 = !DILocation(line: 240, column: 9, scope: !2271)
!2286 = !DILocation(line: 240, column: 12, scope: !2271)
!2287 = !DILocation(line: 240, column: 7, scope: !2271)
!2288 = !DILocation(line: 241, column: 9, scope: !2289)
!2289 = distinct !DILexicalBlock(scope: !2271, file: !3, line: 241, column: 9)
!2290 = !DILocation(line: 241, column: 11, scope: !2289)
!2291 = !DILocation(line: 241, column: 16, scope: !2289)
!2292 = !DILocation(line: 241, column: 19, scope: !2289)
!2293 = !DILocation(line: 241, column: 34, scope: !2289)
!2294 = !DILocation(line: 241, column: 36, scope: !2289)
!2295 = !DILocation(line: 241, column: 25, scope: !2289)
!2296 = !DILocation(line: 241, column: 22, scope: !2289)
!2297 = !DILocation(line: 241, column: 9, scope: !2271)
!2298 = !DILocation(line: 242, column: 14, scope: !2299)
!2299 = distinct !DILexicalBlock(scope: !2289, file: !3, line: 241, column: 42)
!2300 = !DILocation(line: 242, column: 18, scope: !2299)
!2301 = !DILocation(line: 242, column: 16, scope: !2299)
!2302 = !DILocation(line: 242, column: 7, scope: !2299)
!2303 = !DILocation(line: 242, column: 12, scope: !2299)
!2304 = !DILocation(line: 243, column: 5, scope: !2299)
!2305 = !DILocalVariable(name: "high", scope: !2306, file: !3, line: 244, type: !9)
!2306 = distinct !DILexicalBlock(scope: !2289, file: !3, line: 243, column: 12)
!2307 = !DILocation(line: 244, column: 16, scope: !2306)
!2308 = !DILocation(line: 245, column: 11, scope: !2306)
!2309 = !DILocation(line: 245, column: 14, scope: !2306)
!2310 = !DILocation(line: 245, column: 9, scope: !2306)
!2311 = !DILocation(line: 246, column: 14, scope: !2306)
!2312 = !DILocation(line: 246, column: 18, scope: !2306)
!2313 = !DILocation(line: 246, column: 16, scope: !2306)
!2314 = !DILocation(line: 246, column: 7, scope: !2306)
!2315 = !DILocation(line: 246, column: 12, scope: !2306)
!2316 = !DILocation(line: 247, column: 7, scope: !2306)
!2317 = !DILocalVariable(name: "bits", scope: !2318, file: !3, line: 247, type: !16)
!2318 = distinct !DILexicalBlock(scope: !2306, file: !3, line: 247, column: 7)
!2319 = !DILocation(line: 247, column: 7, scope: !2318)
!2320 = !DILocation(line: 248, column: 11, scope: !2306)
!2321 = !DILocation(line: 248, column: 17, scope: !2306)
!2322 = !DILocation(line: 248, column: 22, scope: !2306)
!2323 = !DILocation(line: 248, column: 29, scope: !2306)
!2324 = !DILocation(line: 248, column: 13, scope: !2306)
!2325 = !DILocation(line: 248, column: 9, scope: !2306)
!2326 = !DILocation(line: 249, column: 11, scope: !2327)
!2327 = distinct !DILexicalBlock(scope: !2306, file: !3, line: 249, column: 11)
!2328 = !DILocation(line: 249, column: 13, scope: !2327)
!2329 = !DILocation(line: 249, column: 11, scope: !2306)
!2330 = !DILocation(line: 250, column: 13, scope: !2331)
!2331 = distinct !DILexicalBlock(scope: !2327, file: !3, line: 249, column: 19)
!2332 = !DILocation(line: 250, column: 11, scope: !2331)
!2333 = !DILocation(line: 251, column: 13, scope: !2331)
!2334 = !DILocation(line: 251, column: 16, scope: !2331)
!2335 = !DILocation(line: 251, column: 11, scope: !2331)
!2336 = !DILocation(line: 252, column: 13, scope: !2331)
!2337 = !DILocation(line: 252, column: 17, scope: !2331)
!2338 = !DILocation(line: 252, column: 15, scope: !2331)
!2339 = !DILocation(line: 252, column: 11, scope: !2331)
!2340 = !DILocation(line: 253, column: 13, scope: !2331)
!2341 = !DILocation(line: 253, column: 30, scope: !2331)
!2342 = !DILocation(line: 253, column: 34, scope: !2331)
!2343 = !DILocation(line: 253, column: 32, scope: !2331)
!2344 = !DILocation(line: 253, column: 39, scope: !2331)
!2345 = !DILocation(line: 253, column: 37, scope: !2331)
!2346 = !DILocation(line: 253, column: 26, scope: !2331)
!2347 = !DILocation(line: 253, column: 11, scope: !2331)
!2348 = !DILocation(line: 254, column: 16, scope: !2331)
!2349 = !DILocation(line: 254, column: 20, scope: !2331)
!2350 = !DILocation(line: 254, column: 18, scope: !2331)
!2351 = !DILocation(line: 254, column: 9, scope: !2331)
!2352 = !DILocation(line: 254, column: 14, scope: !2331)
!2353 = !DILocation(line: 255, column: 9, scope: !2331)
!2354 = !DILocalVariable(name: "bits", scope: !2355, file: !3, line: 255, type: !16)
!2355 = distinct !DILexicalBlock(scope: !2331, file: !3, line: 255, column: 9)
!2356 = !DILocation(line: 255, column: 9, scope: !2355)
!2357 = !DILocation(line: 256, column: 13, scope: !2331)
!2358 = !DILocation(line: 256, column: 19, scope: !2331)
!2359 = !DILocation(line: 256, column: 24, scope: !2331)
!2360 = !DILocation(line: 256, column: 31, scope: !2331)
!2361 = !DILocation(line: 256, column: 15, scope: !2331)
!2362 = !DILocation(line: 256, column: 11, scope: !2331)
!2363 = !DILocation(line: 257, column: 13, scope: !2364)
!2364 = distinct !DILexicalBlock(scope: !2331, file: !3, line: 257, column: 13)
!2365 = !DILocation(line: 257, column: 15, scope: !2364)
!2366 = !DILocation(line: 257, column: 13, scope: !2331)
!2367 = !DILocation(line: 258, column: 15, scope: !2368)
!2368 = distinct !DILexicalBlock(scope: !2364, file: !3, line: 257, column: 21)
!2369 = !DILocation(line: 258, column: 13, scope: !2368)
!2370 = !DILocation(line: 259, column: 15, scope: !2368)
!2371 = !DILocation(line: 259, column: 18, scope: !2368)
!2372 = !DILocation(line: 259, column: 13, scope: !2368)
!2373 = !DILocation(line: 260, column: 15, scope: !2368)
!2374 = !DILocation(line: 260, column: 19, scope: !2368)
!2375 = !DILocation(line: 260, column: 17, scope: !2368)
!2376 = !DILocation(line: 260, column: 13, scope: !2368)
!2377 = !DILocation(line: 261, column: 15, scope: !2368)
!2378 = !DILocation(line: 261, column: 32, scope: !2368)
!2379 = !DILocation(line: 261, column: 36, scope: !2368)
!2380 = !DILocation(line: 261, column: 34, scope: !2368)
!2381 = !DILocation(line: 261, column: 41, scope: !2368)
!2382 = !DILocation(line: 261, column: 39, scope: !2368)
!2383 = !DILocation(line: 261, column: 28, scope: !2368)
!2384 = !DILocation(line: 261, column: 13, scope: !2368)
!2385 = !DILocation(line: 262, column: 18, scope: !2368)
!2386 = !DILocation(line: 262, column: 22, scope: !2368)
!2387 = !DILocation(line: 262, column: 20, scope: !2368)
!2388 = !DILocation(line: 262, column: 11, scope: !2368)
!2389 = !DILocation(line: 262, column: 16, scope: !2368)
!2390 = !DILocation(line: 263, column: 9, scope: !2368)
!2391 = !DILocation(line: 264, column: 7, scope: !2331)
!2392 = !DILocation(line: 266, column: 13, scope: !2271)
!2393 = !DILocation(line: 266, column: 17, scope: !2271)
!2394 = !DILocation(line: 266, column: 15, scope: !2271)
!2395 = !DILocation(line: 266, column: 25, scope: !2271)
!2396 = !DILocation(line: 266, column: 23, scope: !2271)
!2397 = !DILocation(line: 266, column: 5, scope: !2271)
!2398 = !DILocation(line: 266, column: 10, scope: !2271)
!2399 = !DILocation(line: 267, column: 9, scope: !2400)
!2400 = distinct !DILexicalBlock(scope: !2271, file: !3, line: 267, column: 9)
!2401 = !DILocation(line: 267, column: 12, scope: !2400)
!2402 = !DILocation(line: 267, column: 9, scope: !2271)
!2403 = !DILocation(line: 268, column: 15, scope: !2404)
!2404 = distinct !DILexicalBlock(scope: !2400, file: !3, line: 267, column: 17)
!2405 = !DILocation(line: 268, column: 14, scope: !2404)
!2406 = !DILocation(line: 268, column: 7, scope: !2404)
!2407 = !DILocation(line: 268, column: 12, scope: !2404)
!2408 = !DILocation(line: 269, column: 15, scope: !2404)
!2409 = !DILocation(line: 269, column: 14, scope: !2404)
!2410 = !DILocation(line: 269, column: 7, scope: !2404)
!2411 = !DILocation(line: 269, column: 12, scope: !2404)
!2412 = !DILocation(line: 270, column: 15, scope: !2404)
!2413 = !DILocation(line: 270, column: 14, scope: !2404)
!2414 = !DILocation(line: 270, column: 7, scope: !2404)
!2415 = !DILocation(line: 272, column: 14, scope: !2416)
!2416 = distinct !DILexicalBlock(scope: !2400, file: !3, line: 271, column: 12)
!2417 = !DILocation(line: 272, column: 7, scope: !2416)
!2418 = !DILocation(line: 278, column: 7, scope: !2419)
!2419 = distinct !DILexicalBlock(scope: !313, file: !3, line: 278, column: 7)
!2420 = !DILocation(line: 278, column: 10, scope: !2419)
!2421 = !DILocation(line: 278, column: 7, scope: !313)
!2422 = !DILocation(line: 279, column: 19, scope: !2423)
!2423 = distinct !DILexicalBlock(scope: !2419, file: !3, line: 278, column: 25)
!2424 = !DILocation(line: 279, column: 23, scope: !2423)
!2425 = !DILocation(line: 279, column: 21, scope: !2423)
!2426 = !DILocation(line: 279, column: 12, scope: !2423)
!2427 = !DILocation(line: 279, column: 17, scope: !2423)
!2428 = !DILocation(line: 279, column: 5, scope: !2423)
!2429 = !DILocation(line: 279, column: 10, scope: !2423)
!2430 = !DILocation(line: 280, column: 5, scope: !2423)
!2431 = !DILocation(line: 283, column: 3, scope: !313)
!2432 = !DILocalVariable(name: "bits", scope: !2433, file: !3, line: 283, type: !16)
!2433 = distinct !DILexicalBlock(scope: !313, file: !3, line: 283, column: 3)
!2434 = !DILocation(line: 283, column: 3, scope: !2433)
!2435 = !DILocation(line: 284, column: 3, scope: !313)
!2436 = !DILocalVariable(name: "bits", scope: !2437, file: !3, line: 284, type: !16)
!2437 = distinct !DILexicalBlock(scope: !313, file: !3, line: 284, column: 3)
!2438 = !DILocation(line: 284, column: 3, scope: !2437)
!2439 = !DILocation(line: 285, column: 9, scope: !313)
!2440 = !DILocation(line: 285, column: 12, scope: !313)
!2441 = !DILocation(line: 285, column: 19, scope: !313)
!2442 = !DILocation(line: 285, column: 6, scope: !313)
!2443 = !DILocation(line: 286, column: 3, scope: !313)
!2444 = !DILocalVariable(name: "bits", scope: !2445, file: !3, line: 286, type: !16)
!2445 = distinct !DILexicalBlock(scope: !313, file: !3, line: 286, column: 3)
!2446 = !DILocation(line: 286, column: 3, scope: !2445)
!2447 = !DILocation(line: 287, column: 10, scope: !2448)
!2448 = distinct !DILexicalBlock(scope: !313, file: !3, line: 287, column: 3)
!2449 = !DILocation(line: 287, column: 8, scope: !2448)
!2450 = !DILocation(line: 287, column: 15, scope: !2451)
!2451 = distinct !DILexicalBlock(scope: !2448, file: !3, line: 287, column: 3)
!2452 = !DILocation(line: 287, column: 17, scope: !2451)
!2453 = !DILocation(line: 287, column: 3, scope: !2448)
!2454 = !DILocation(line: 288, column: 32, scope: !2455)
!2455 = distinct !DILexicalBlock(scope: !2451, file: !3, line: 287, column: 27)
!2456 = !DILocation(line: 288, column: 22, scope: !2455)
!2457 = !DILocation(line: 288, column: 13, scope: !2455)
!2458 = !DILocation(line: 288, column: 8, scope: !2455)
!2459 = !DILocation(line: 288, column: 5, scope: !2455)
!2460 = !DILocation(line: 288, column: 11, scope: !2455)
!2461 = !DILocation(line: 289, column: 10, scope: !2455)
!2462 = !DILocation(line: 289, column: 17, scope: !2455)
!2463 = !DILocation(line: 289, column: 14, scope: !2455)
!2464 = !DILocation(line: 289, column: 12, scope: !2455)
!2465 = !DILocation(line: 289, column: 21, scope: !2455)
!2466 = !DILocation(line: 289, column: 7, scope: !2455)
!2467 = !DILocation(line: 290, column: 3, scope: !2455)
!2468 = !DILocation(line: 287, column: 23, scope: !2451)
!2469 = !DILocation(line: 287, column: 3, scope: !2451)
!2470 = distinct !{!2470, !2453, !2471, !2472}
!2471 = !DILocation(line: 290, column: 3, scope: !2448)
!2472 = !{!"llvm.loop.mustprogress"}
!2473 = !DILocation(line: 291, column: 11, scope: !313)
!2474 = !DILocation(line: 291, column: 3, scope: !313)
!2475 = !DILocation(line: 291, column: 9, scope: !313)
!2476 = !DILocation(line: 292, column: 6, scope: !313)
!2477 = !DILocation(line: 293, column: 3, scope: !313)
!2478 = !DILocation(line: 293, column: 13, scope: !313)
!2479 = !DILocation(line: 293, column: 16, scope: !313)
!2480 = !DILocation(line: 293, column: 10, scope: !313)
!2481 = !DILocation(line: 293, column: 21, scope: !313)
!2482 = !DILocation(line: 293, column: 32, scope: !313)
!2483 = distinct !{!2483, !2477, !2482, !2472}
!2484 = !DILocation(line: 294, column: 25, scope: !313)
!2485 = !DILocation(line: 294, column: 29, scope: !313)
!2486 = !DILocation(line: 294, column: 32, scope: !313)
!2487 = !DILocation(line: 294, column: 36, scope: !313)
!2488 = !DILocation(line: 294, column: 7, scope: !313)
!2489 = !DILocation(line: 294, column: 5, scope: !313)
!2490 = !DILocation(line: 295, column: 7, scope: !2491)
!2491 = distinct !DILexicalBlock(scope: !313, file: !3, line: 295, column: 7)
!2492 = !DILocation(line: 295, column: 10, scope: !2491)
!2493 = !DILocation(line: 295, column: 7, scope: !313)
!2494 = !DILocation(line: 296, column: 13, scope: !2495)
!2495 = distinct !DILexicalBlock(scope: !2491, file: !3, line: 295, column: 15)
!2496 = !DILocation(line: 296, column: 12, scope: !2495)
!2497 = !DILocation(line: 296, column: 5, scope: !2495)
!2498 = !DILocation(line: 296, column: 10, scope: !2495)
!2499 = !DILocation(line: 297, column: 13, scope: !2495)
!2500 = !DILocation(line: 297, column: 12, scope: !2495)
!2501 = !DILocation(line: 297, column: 5, scope: !2495)
!2502 = !DILocation(line: 297, column: 10, scope: !2495)
!2503 = !DILocation(line: 298, column: 13, scope: !2495)
!2504 = !DILocation(line: 298, column: 12, scope: !2495)
!2505 = !DILocation(line: 298, column: 5, scope: !2495)
!2506 = !DILocation(line: 300, column: 10, scope: !313)
!2507 = !DILocation(line: 300, column: 3, scope: !313)
!2508 = !DILocation(line: 301, column: 1, scope: !313)
!2509 = !DILocalVariable(name: "x", arg: 1, scope: !369, file: !3, line: 704, type: !6)
!2510 = !DILocation(line: 704, column: 42, scope: !369)
!2511 = !DILocalVariable(name: "y", arg: 2, scope: !369, file: !3, line: 704, type: !6)
!2512 = !DILocation(line: 704, column: 52, scope: !369)
!2513 = !DILocalVariable(name: "iy", arg: 3, scope: !369, file: !3, line: 704, type: !15)
!2514 = !DILocation(line: 704, column: 59, scope: !369)
!2515 = !DILocalVariable(name: "z", scope: !369, file: !3, line: 714, type: !6)
!2516 = !DILocation(line: 714, column: 10, scope: !369)
!2517 = !DILocalVariable(name: "r", scope: !369, file: !3, line: 714, type: !6)
!2518 = !DILocation(line: 714, column: 13, scope: !369)
!2519 = !DILocalVariable(name: "v", scope: !369, file: !3, line: 714, type: !6)
!2520 = !DILocation(line: 714, column: 16, scope: !369)
!2521 = !DILocalVariable(name: "ix", scope: !369, file: !3, line: 715, type: !18)
!2522 = !DILocation(line: 715, column: 11, scope: !369)
!2523 = !DILocation(line: 716, column: 3, scope: !369)
!2524 = !DILocalVariable(name: "bits", scope: !2525, file: !3, line: 716, type: !16)
!2525 = distinct !DILexicalBlock(scope: !369, file: !3, line: 716, column: 3)
!2526 = !DILocation(line: 716, column: 3, scope: !2525)
!2527 = !DILocation(line: 717, column: 6, scope: !369)
!2528 = !DILocation(line: 718, column: 7, scope: !2529)
!2529 = distinct !DILexicalBlock(scope: !369, file: !3, line: 718, column: 7)
!2530 = !DILocation(line: 718, column: 10, scope: !2529)
!2531 = !DILocation(line: 718, column: 7, scope: !369)
!2532 = !DILocation(line: 719, column: 15, scope: !2533)
!2533 = distinct !DILexicalBlock(scope: !2534, file: !3, line: 719, column: 9)
!2534 = distinct !DILexicalBlock(scope: !2529, file: !3, line: 718, column: 24)
!2535 = !DILocation(line: 719, column: 9, scope: !2533)
!2536 = !DILocation(line: 719, column: 18, scope: !2533)
!2537 = !DILocation(line: 719, column: 9, scope: !2534)
!2538 = !DILocation(line: 719, column: 31, scope: !2533)
!2539 = !DILocation(line: 719, column: 24, scope: !2533)
!2540 = !DILocation(line: 720, column: 3, scope: !2534)
!2541 = !DILocation(line: 721, column: 7, scope: !369)
!2542 = !DILocation(line: 721, column: 11, scope: !369)
!2543 = !DILocation(line: 721, column: 9, scope: !369)
!2544 = !DILocation(line: 721, column: 5, scope: !369)
!2545 = !DILocation(line: 722, column: 7, scope: !369)
!2546 = !DILocation(line: 722, column: 11, scope: !369)
!2547 = !DILocation(line: 722, column: 9, scope: !369)
!2548 = !DILocation(line: 722, column: 5, scope: !369)
!2549 = !DILocation(line: 723, column: 12, scope: !369)
!2550 = !DILocation(line: 723, column: 22, scope: !369)
!2551 = !DILocation(line: 723, column: 32, scope: !369)
!2552 = !DILocation(line: 723, column: 42, scope: !369)
!2553 = !DILocation(line: 723, column: 40, scope: !369)
!2554 = !DILocation(line: 723, column: 30, scope: !369)
!2555 = !DILocation(line: 723, column: 20, scope: !369)
!2556 = !DILocation(line: 723, column: 10, scope: !369)
!2557 = !DILocation(line: 723, column: 5, scope: !369)
!2558 = !DILocation(line: 724, column: 7, scope: !2559)
!2559 = distinct !DILexicalBlock(scope: !369, file: !3, line: 724, column: 7)
!2560 = !DILocation(line: 724, column: 10, scope: !2559)
!2561 = !DILocation(line: 724, column: 7, scope: !369)
!2562 = !DILocation(line: 725, column: 12, scope: !2563)
!2563 = distinct !DILexicalBlock(scope: !2559, file: !3, line: 724, column: 16)
!2564 = !DILocation(line: 725, column: 16, scope: !2563)
!2565 = !DILocation(line: 725, column: 26, scope: !2563)
!2566 = !DILocation(line: 725, column: 30, scope: !2563)
!2567 = !DILocation(line: 725, column: 24, scope: !2563)
!2568 = !DILocation(line: 725, column: 14, scope: !2563)
!2569 = !DILocation(line: 725, column: 5, scope: !2563)
!2570 = !DILocation(line: 727, column: 12, scope: !2571)
!2571 = distinct !DILexicalBlock(scope: !2559, file: !3, line: 726, column: 10)
!2572 = !DILocation(line: 727, column: 18, scope: !2571)
!2573 = !DILocation(line: 727, column: 30, scope: !2571)
!2574 = !DILocation(line: 727, column: 34, scope: !2571)
!2575 = !DILocation(line: 727, column: 38, scope: !2571)
!2576 = !DILocation(line: 727, column: 36, scope: !2571)
!2577 = !DILocation(line: 727, column: 32, scope: !2571)
!2578 = !DILocation(line: 727, column: 43, scope: !2571)
!2579 = !DILocation(line: 727, column: 41, scope: !2571)
!2580 = !DILocation(line: 727, column: 48, scope: !2571)
!2581 = !DILocation(line: 727, column: 46, scope: !2571)
!2582 = !DILocation(line: 727, column: 14, scope: !2571)
!2583 = !DILocation(line: 727, column: 5, scope: !2571)
!2584 = !DILocation(line: 729, column: 1, scope: !369)
!2585 = !DILocalVariable(name: "x", arg: 1, scope: !125, file: !3, line: 1474, type: !6)
!2586 = !DILocation(line: 1474, column: 31, scope: !125)
!2587 = !DILocalVariable(name: "y", scope: !125, file: !3, line: 1497, type: !6)
!2588 = !DILocation(line: 1497, column: 10, scope: !125)
!2589 = !DILocalVariable(name: "hi", scope: !125, file: !3, line: 1497, type: !6)
!2590 = !DILocation(line: 1497, column: 13, scope: !125)
!2591 = !DILocalVariable(name: "lo", scope: !125, file: !3, line: 1497, type: !6)
!2592 = !DILocation(line: 1497, column: 23, scope: !125)
!2593 = !DILocalVariable(name: "c", scope: !125, file: !3, line: 1497, type: !6)
!2594 = !DILocation(line: 1497, column: 33, scope: !125)
!2595 = !DILocalVariable(name: "t", scope: !125, file: !3, line: 1497, type: !6)
!2596 = !DILocation(line: 1497, column: 36, scope: !125)
!2597 = !DILocalVariable(name: "twopk", scope: !125, file: !3, line: 1497, type: !6)
!2598 = !DILocation(line: 1497, column: 39, scope: !125)
!2599 = !DILocalVariable(name: "k", scope: !125, file: !3, line: 1498, type: !18)
!2600 = !DILocation(line: 1498, column: 11, scope: !125)
!2601 = !DILocalVariable(name: "xsb", scope: !125, file: !3, line: 1498, type: !18)
!2602 = !DILocation(line: 1498, column: 18, scope: !125)
!2603 = !DILocalVariable(name: "hx", scope: !125, file: !3, line: 1499, type: !9)
!2604 = !DILocation(line: 1499, column: 12, scope: !125)
!2605 = !DILocation(line: 1501, column: 3, scope: !125)
!2606 = !DILocalVariable(name: "bits", scope: !2607, file: !3, line: 1501, type: !16)
!2607 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1501, column: 3)
!2608 = !DILocation(line: 1501, column: 3, scope: !2607)
!2609 = !DILocation(line: 1502, column: 10, scope: !125)
!2610 = !DILocation(line: 1502, column: 13, scope: !125)
!2611 = !DILocation(line: 1502, column: 20, scope: !125)
!2612 = !DILocation(line: 1502, column: 7, scope: !125)
!2613 = !DILocation(line: 1503, column: 6, scope: !125)
!2614 = !DILocation(line: 1506, column: 7, scope: !2615)
!2615 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1506, column: 7)
!2616 = !DILocation(line: 1506, column: 10, scope: !2615)
!2617 = !DILocation(line: 1506, column: 7, scope: !125)
!2618 = !DILocation(line: 1507, column: 9, scope: !2619)
!2619 = distinct !DILexicalBlock(scope: !2620, file: !3, line: 1507, column: 9)
!2620 = distinct !DILexicalBlock(scope: !2615, file: !3, line: 1506, column: 25)
!2621 = !DILocation(line: 1507, column: 12, scope: !2619)
!2622 = !DILocation(line: 1507, column: 9, scope: !2620)
!2623 = !DILocalVariable(name: "lx", scope: !2624, file: !3, line: 1508, type: !9)
!2624 = distinct !DILexicalBlock(scope: !2619, file: !3, line: 1507, column: 27)
!2625 = !DILocation(line: 1508, column: 16, scope: !2624)
!2626 = !DILocation(line: 1509, column: 7, scope: !2624)
!2627 = !DILocalVariable(name: "bits", scope: !2628, file: !3, line: 1509, type: !16)
!2628 = distinct !DILexicalBlock(scope: !2624, file: !3, line: 1509, column: 7)
!2629 = !DILocation(line: 1509, column: 7, scope: !2628)
!2630 = !DILocation(line: 1510, column: 13, scope: !2631)
!2631 = distinct !DILexicalBlock(scope: !2624, file: !3, line: 1510, column: 11)
!2632 = !DILocation(line: 1510, column: 16, scope: !2631)
!2633 = !DILocation(line: 1510, column: 29, scope: !2631)
!2634 = !DILocation(line: 1510, column: 27, scope: !2631)
!2635 = !DILocation(line: 1510, column: 33, scope: !2631)
!2636 = !DILocation(line: 1510, column: 11, scope: !2624)
!2637 = !DILocation(line: 1511, column: 16, scope: !2631)
!2638 = !DILocation(line: 1511, column: 20, scope: !2631)
!2639 = !DILocation(line: 1511, column: 18, scope: !2631)
!2640 = !DILocation(line: 1511, column: 9, scope: !2631)
!2641 = !DILocation(line: 1513, column: 17, scope: !2631)
!2642 = !DILocation(line: 1513, column: 21, scope: !2631)
!2643 = !DILocation(line: 1513, column: 16, scope: !2631)
!2644 = !DILocation(line: 1513, column: 29, scope: !2631)
!2645 = !DILocation(line: 1513, column: 9, scope: !2631)
!2646 = !DILocation(line: 1515, column: 9, scope: !2647)
!2647 = distinct !DILexicalBlock(scope: !2620, file: !3, line: 1515, column: 9)
!2648 = !DILocation(line: 1515, column: 11, scope: !2647)
!2649 = !DILocation(line: 1515, column: 9, scope: !2620)
!2650 = !DILocation(line: 1515, column: 33, scope: !2647)
!2651 = !DILocation(line: 1515, column: 40, scope: !2647)
!2652 = !DILocation(line: 1515, column: 38, scope: !2647)
!2653 = !DILocation(line: 1515, column: 26, scope: !2647)
!2654 = !DILocation(line: 1516, column: 9, scope: !2655)
!2655 = distinct !DILexicalBlock(scope: !2620, file: !3, line: 1516, column: 9)
!2656 = !DILocation(line: 1516, column: 11, scope: !2655)
!2657 = !DILocation(line: 1516, column: 9, scope: !2620)
!2658 = !DILocation(line: 1516, column: 33, scope: !2655)
!2659 = !DILocation(line: 1516, column: 44, scope: !2655)
!2660 = !DILocation(line: 1516, column: 42, scope: !2655)
!2661 = !DILocation(line: 1516, column: 26, scope: !2655)
!2662 = !DILocation(line: 1517, column: 3, scope: !2620)
!2663 = !DILocation(line: 1520, column: 7, scope: !2664)
!2664 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1520, column: 7)
!2665 = !DILocation(line: 1520, column: 10, scope: !2664)
!2666 = !DILocation(line: 1520, column: 7, scope: !125)
!2667 = !DILocation(line: 1521, column: 9, scope: !2668)
!2668 = distinct !DILexicalBlock(scope: !2669, file: !3, line: 1521, column: 9)
!2669 = distinct !DILexicalBlock(scope: !2664, file: !3, line: 1520, column: 24)
!2670 = !DILocation(line: 1521, column: 12, scope: !2668)
!2671 = !DILocation(line: 1521, column: 9, scope: !2669)
!2672 = !DILocation(line: 1526, column: 11, scope: !2673)
!2673 = distinct !DILexicalBlock(scope: !2674, file: !3, line: 1526, column: 11)
!2674 = distinct !DILexicalBlock(scope: !2668, file: !3, line: 1521, column: 26)
!2675 = !DILocation(line: 1526, column: 13, scope: !2673)
!2676 = !DILocation(line: 1526, column: 11, scope: !2674)
!2677 = !DILocation(line: 1526, column: 21, scope: !2673)
!2678 = !DILocation(line: 1527, column: 12, scope: !2674)
!2679 = !DILocation(line: 1527, column: 22, scope: !2674)
!2680 = !DILocation(line: 1527, column: 16, scope: !2674)
!2681 = !DILocation(line: 1527, column: 14, scope: !2674)
!2682 = !DILocation(line: 1527, column: 10, scope: !2674)
!2683 = !DILocation(line: 1528, column: 18, scope: !2674)
!2684 = !DILocation(line: 1528, column: 12, scope: !2674)
!2685 = !DILocation(line: 1528, column: 10, scope: !2674)
!2686 = !DILocation(line: 1529, column: 15, scope: !2674)
!2687 = !DILocation(line: 1529, column: 13, scope: !2674)
!2688 = !DILocation(line: 1529, column: 21, scope: !2674)
!2689 = !DILocation(line: 1529, column: 19, scope: !2674)
!2690 = !DILocation(line: 1529, column: 9, scope: !2674)
!2691 = !DILocation(line: 1530, column: 5, scope: !2674)
!2692 = !DILocation(line: 1531, column: 26, scope: !2693)
!2693 = distinct !DILexicalBlock(scope: !2668, file: !3, line: 1530, column: 12)
!2694 = !DILocation(line: 1531, column: 35, scope: !2693)
!2695 = !DILocation(line: 1531, column: 30, scope: !2693)
!2696 = !DILocation(line: 1531, column: 28, scope: !2693)
!2697 = !DILocation(line: 1531, column: 11, scope: !2693)
!2698 = !DILocation(line: 1531, column: 9, scope: !2693)
!2699 = !DILocation(line: 1532, column: 11, scope: !2693)
!2700 = !DILocation(line: 1532, column: 9, scope: !2693)
!2701 = !DILocation(line: 1533, column: 12, scope: !2693)
!2702 = !DILocation(line: 1533, column: 16, scope: !2693)
!2703 = !DILocation(line: 1533, column: 20, scope: !2693)
!2704 = !DILocation(line: 1533, column: 14, scope: !2693)
!2705 = !DILocation(line: 1533, column: 10, scope: !2693)
!2706 = !DILocation(line: 1534, column: 12, scope: !2693)
!2707 = !DILocation(line: 1534, column: 16, scope: !2693)
!2708 = !DILocation(line: 1534, column: 14, scope: !2693)
!2709 = !DILocation(line: 1534, column: 10, scope: !2693)
!2710 = !DILocation(line: 1536, column: 9, scope: !2669)
!2711 = !DILocation(line: 1536, column: 14, scope: !2669)
!2712 = !DILocation(line: 1536, column: 12, scope: !2669)
!2713 = !DILocation(line: 1536, column: 7, scope: !2669)
!2714 = !DILocation(line: 1537, column: 3, scope: !2669)
!2715 = !DILocation(line: 1537, column: 14, scope: !2716)
!2716 = distinct !DILexicalBlock(scope: !2664, file: !3, line: 1537, column: 14)
!2717 = !DILocation(line: 1537, column: 17, scope: !2716)
!2718 = !DILocation(line: 1537, column: 14, scope: !2664)
!2719 = !DILocation(line: 1538, column: 9, scope: !2720)
!2720 = distinct !DILexicalBlock(scope: !2721, file: !3, line: 1538, column: 9)
!2721 = distinct !DILexicalBlock(scope: !2716, file: !3, line: 1537, column: 31)
!2722 = !DILocation(line: 1538, column: 16, scope: !2720)
!2723 = !DILocation(line: 1538, column: 14, scope: !2720)
!2724 = !DILocation(line: 1538, column: 18, scope: !2720)
!2725 = !DILocation(line: 1538, column: 9, scope: !2721)
!2726 = !DILocation(line: 1538, column: 38, scope: !2720)
!2727 = !DILocation(line: 1538, column: 36, scope: !2720)
!2728 = !DILocation(line: 1538, column: 25, scope: !2720)
!2729 = !DILocation(line: 1539, column: 3, scope: !2721)
!2730 = !DILocation(line: 1540, column: 7, scope: !2731)
!2731 = distinct !DILexicalBlock(scope: !2716, file: !3, line: 1539, column: 10)
!2732 = !DILocation(line: 1544, column: 7, scope: !125)
!2733 = !DILocation(line: 1544, column: 11, scope: !125)
!2734 = !DILocation(line: 1544, column: 9, scope: !125)
!2735 = !DILocation(line: 1544, column: 5, scope: !125)
!2736 = !DILocation(line: 1545, column: 7, scope: !2737)
!2737 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1545, column: 7)
!2738 = !DILocation(line: 1545, column: 9, scope: !2737)
!2739 = !DILocation(line: 1545, column: 7, scope: !125)
!2740 = !DILocation(line: 1546, column: 5, scope: !2741)
!2741 = distinct !DILexicalBlock(scope: !2737, file: !3, line: 1545, column: 19)
!2742 = !DILocalVariable(name: "bits", scope: !2743, file: !3, line: 1546, type: !16)
!2743 = distinct !DILexicalBlock(scope: !2741, file: !3, line: 1546, column: 5)
!2744 = !DILocation(line: 1546, column: 5, scope: !2743)
!2745 = !DILocation(line: 1549, column: 3, scope: !2741)
!2746 = !DILocation(line: 1550, column: 5, scope: !2747)
!2747 = distinct !DILexicalBlock(scope: !2737, file: !3, line: 1549, column: 10)
!2748 = !DILocalVariable(name: "bits", scope: !2749, file: !3, line: 1550, type: !16)
!2749 = distinct !DILexicalBlock(scope: !2747, file: !3, line: 1550, column: 5)
!2750 = !DILocation(line: 1550, column: 5, scope: !2749)
!2751 = !DILocation(line: 1553, column: 7, scope: !125)
!2752 = !DILocation(line: 1553, column: 11, scope: !125)
!2753 = !DILocation(line: 1553, column: 21, scope: !125)
!2754 = !DILocation(line: 1553, column: 31, scope: !125)
!2755 = !DILocation(line: 1553, column: 41, scope: !125)
!2756 = !DILocation(line: 1553, column: 51, scope: !125)
!2757 = !DILocation(line: 1553, column: 49, scope: !125)
!2758 = !DILocation(line: 1553, column: 39, scope: !125)
!2759 = !DILocation(line: 1553, column: 29, scope: !125)
!2760 = !DILocation(line: 1553, column: 19, scope: !125)
!2761 = !DILocation(line: 1553, column: 9, scope: !125)
!2762 = !DILocation(line: 1553, column: 5, scope: !125)
!2763 = !DILocation(line: 1554, column: 7, scope: !2764)
!2764 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1554, column: 7)
!2765 = !DILocation(line: 1554, column: 9, scope: !2764)
!2766 = !DILocation(line: 1554, column: 7, scope: !125)
!2767 = !DILocation(line: 1555, column: 20, scope: !2768)
!2768 = distinct !DILexicalBlock(scope: !2764, file: !3, line: 1554, column: 15)
!2769 = !DILocation(line: 1555, column: 24, scope: !2768)
!2770 = !DILocation(line: 1555, column: 22, scope: !2768)
!2771 = !DILocation(line: 1555, column: 30, scope: !2768)
!2772 = !DILocation(line: 1555, column: 32, scope: !2768)
!2773 = !DILocation(line: 1555, column: 27, scope: !2768)
!2774 = !DILocation(line: 1555, column: 41, scope: !2768)
!2775 = !DILocation(line: 1555, column: 39, scope: !2768)
!2776 = !DILocation(line: 1555, column: 16, scope: !2768)
!2777 = !DILocation(line: 1555, column: 5, scope: !2768)
!2778 = !DILocation(line: 1557, column: 17, scope: !2779)
!2779 = distinct !DILexicalBlock(scope: !2764, file: !3, line: 1556, column: 10)
!2780 = !DILocation(line: 1557, column: 23, scope: !2779)
!2781 = !DILocation(line: 1557, column: 27, scope: !2779)
!2782 = !DILocation(line: 1557, column: 25, scope: !2779)
!2783 = !DILocation(line: 1557, column: 39, scope: !2779)
!2784 = !DILocation(line: 1557, column: 37, scope: !2779)
!2785 = !DILocation(line: 1557, column: 30, scope: !2779)
!2786 = !DILocation(line: 1557, column: 20, scope: !2779)
!2787 = !DILocation(line: 1557, column: 45, scope: !2779)
!2788 = !DILocation(line: 1557, column: 43, scope: !2779)
!2789 = !DILocation(line: 1557, column: 13, scope: !2779)
!2790 = !DILocation(line: 1557, column: 7, scope: !2779)
!2791 = !DILocation(line: 1559, column: 7, scope: !2792)
!2792 = distinct !DILexicalBlock(scope: !125, file: !3, line: 1559, column: 7)
!2793 = !DILocation(line: 1559, column: 9, scope: !2792)
!2794 = !DILocation(line: 1559, column: 7, scope: !125)
!2795 = !DILocation(line: 1560, column: 9, scope: !2796)
!2796 = distinct !DILexicalBlock(scope: !2797, file: !3, line: 1560, column: 9)
!2797 = distinct !DILexicalBlock(scope: !2792, file: !3, line: 1559, column: 19)
!2798 = !DILocation(line: 1560, column: 11, scope: !2796)
!2799 = !DILocation(line: 1560, column: 9, scope: !2797)
!2800 = !DILocation(line: 1560, column: 27, scope: !2796)
!2801 = !DILocation(line: 1560, column: 29, scope: !2796)
!2802 = !DILocation(line: 1560, column: 37, scope: !2796)
!2803 = !DILocation(line: 1560, column: 35, scope: !2796)
!2804 = !DILocation(line: 1560, column: 20, scope: !2796)
!2805 = !DILocation(line: 1561, column: 12, scope: !2797)
!2806 = !DILocation(line: 1561, column: 16, scope: !2797)
!2807 = !DILocation(line: 1561, column: 14, scope: !2797)
!2808 = !DILocation(line: 1561, column: 5, scope: !2797)
!2809 = !DILocation(line: 1563, column: 12, scope: !2810)
!2810 = distinct !DILexicalBlock(scope: !2792, file: !3, line: 1562, column: 10)
!2811 = !DILocation(line: 1563, column: 16, scope: !2810)
!2812 = !DILocation(line: 1563, column: 14, scope: !2810)
!2813 = !DILocation(line: 1563, column: 24, scope: !2810)
!2814 = !DILocation(line: 1563, column: 22, scope: !2810)
!2815 = !DILocation(line: 1563, column: 5, scope: !2810)
!2816 = !DILocation(line: 1565, column: 1, scope: !125)
!2817 = !DILocalVariable(name: "x", arg: 1, scope: !161, file: !3, line: 1584, type: !6)
!2818 = !DILocation(line: 1584, column: 33, scope: !161)
!2819 = !DILocalVariable(name: "t", scope: !161, file: !3, line: 1588, type: !6)
!2820 = !DILocation(line: 1588, column: 10, scope: !161)
!2821 = !DILocalVariable(name: "hx", scope: !161, file: !3, line: 1589, type: !18)
!2822 = !DILocation(line: 1589, column: 11, scope: !161)
!2823 = !DILocalVariable(name: "ix", scope: !161, file: !3, line: 1589, type: !18)
!2824 = !DILocation(line: 1589, column: 15, scope: !161)
!2825 = !DILocalVariable(name: "lx", scope: !161, file: !3, line: 1590, type: !9)
!2826 = !DILocation(line: 1590, column: 12, scope: !161)
!2827 = !DILocation(line: 1591, column: 3, scope: !161)
!2828 = !DILocalVariable(name: "bits", scope: !2829, file: !3, line: 1591, type: !16)
!2829 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1591, column: 3)
!2830 = !DILocation(line: 1591, column: 3, scope: !2829)
!2831 = !DILocation(line: 1592, column: 8, scope: !161)
!2832 = !DILocation(line: 1592, column: 11, scope: !161)
!2833 = !DILocation(line: 1592, column: 6, scope: !161)
!2834 = !DILocation(line: 1593, column: 8, scope: !2835)
!2835 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1593, column: 7)
!2836 = !DILocation(line: 1593, column: 15, scope: !2835)
!2837 = !DILocation(line: 1593, column: 43, scope: !2835)
!2838 = !DILocation(line: 1593, column: 20, scope: !2835)
!2839 = !DILocation(line: 1593, column: 18, scope: !2835)
!2840 = !DILocation(line: 1593, column: 48, scope: !2835)
!2841 = !DILocation(line: 1593, column: 11, scope: !2835)
!2842 = !DILocation(line: 1593, column: 56, scope: !2835)
!2843 = !DILocation(line: 1593, column: 7, scope: !161)
!2844 = !DILocation(line: 1595, column: 5, scope: !2845)
!2845 = distinct !DILexicalBlock(scope: !2835, file: !3, line: 1593, column: 70)
!2846 = !DILocation(line: 1597, column: 7, scope: !2847)
!2847 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1597, column: 7)
!2848 = !DILocation(line: 1597, column: 10, scope: !2847)
!2849 = !DILocation(line: 1597, column: 7, scope: !161)
!2850 = !DILocation(line: 1598, column: 12, scope: !2851)
!2851 = distinct !DILexicalBlock(scope: !2847, file: !3, line: 1597, column: 25)
!2852 = !DILocation(line: 1598, column: 14, scope: !2851)
!2853 = !DILocation(line: 1598, column: 5, scope: !2851)
!2854 = !DILocation(line: 1601, column: 7, scope: !2855)
!2855 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1601, column: 7)
!2856 = !DILocation(line: 1601, column: 10, scope: !2855)
!2857 = !DILocation(line: 1601, column: 23, scope: !2855)
!2858 = !DILocation(line: 1601, column: 34, scope: !2855)
!2859 = !DILocation(line: 1601, column: 32, scope: !2855)
!2860 = !DILocation(line: 1601, column: 37, scope: !2855)
!2861 = !DILocation(line: 1601, column: 7, scope: !161)
!2862 = !DILocation(line: 1601, column: 52, scope: !2855)
!2863 = !DILocation(line: 1601, column: 45, scope: !2855)
!2864 = !DILocation(line: 1602, column: 3, scope: !161)
!2865 = !DILocalVariable(name: "bits", scope: !2866, file: !3, line: 1602, type: !16)
!2866 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1602, column: 3)
!2867 = !DILocation(line: 1602, column: 3, scope: !2866)
!2868 = !DILocation(line: 1603, column: 7, scope: !2869)
!2869 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1603, column: 7)
!2870 = !DILocation(line: 1603, column: 10, scope: !2869)
!2871 = !DILocation(line: 1603, column: 7, scope: !161)
!2872 = !DILocation(line: 1604, column: 9, scope: !2873)
!2873 = distinct !DILexicalBlock(scope: !2869, file: !3, line: 1603, column: 24)
!2874 = !DILocation(line: 1604, column: 13, scope: !2873)
!2875 = !DILocation(line: 1604, column: 11, scope: !2873)
!2876 = !DILocation(line: 1604, column: 7, scope: !2873)
!2877 = !DILocation(line: 1605, column: 33, scope: !2873)
!2878 = !DILocation(line: 1605, column: 37, scope: !2873)
!2879 = !DILocation(line: 1605, column: 41, scope: !2873)
!2880 = !DILocation(line: 1605, column: 39, scope: !2873)
!2881 = !DILocation(line: 1605, column: 52, scope: !2873)
!2882 = !DILocation(line: 1605, column: 50, scope: !2873)
!2883 = !DILocation(line: 1605, column: 43, scope: !2873)
!2884 = !DILocation(line: 1605, column: 35, scope: !2873)
!2885 = !DILocation(line: 1605, column: 15, scope: !2873)
!2886 = !DILocation(line: 1605, column: 13, scope: !2873)
!2887 = !DILocation(line: 1605, column: 7, scope: !2873)
!2888 = !DILocation(line: 1606, column: 3, scope: !2873)
!2889 = !DILocation(line: 1607, column: 34, scope: !2890)
!2890 = distinct !DILexicalBlock(scope: !2869, file: !3, line: 1606, column: 10)
!2891 = !DILocation(line: 1607, column: 38, scope: !2890)
!2892 = !DILocation(line: 1607, column: 36, scope: !2890)
!2893 = !DILocation(line: 1607, column: 50, scope: !2890)
!2894 = !DILocation(line: 1607, column: 48, scope: !2890)
!2895 = !DILocation(line: 1607, column: 41, scope: !2890)
!2896 = !DILocation(line: 1607, column: 15, scope: !2890)
!2897 = !DILocation(line: 1607, column: 13, scope: !2890)
!2898 = !DILocation(line: 1607, column: 7, scope: !2890)
!2899 = !DILocation(line: 1609, column: 7, scope: !2900)
!2900 = distinct !DILexicalBlock(scope: !161, file: !3, line: 1609, column: 7)
!2901 = !DILocation(line: 1609, column: 10, scope: !2900)
!2902 = !DILocation(line: 1609, column: 7, scope: !161)
!2903 = !DILocation(line: 1610, column: 12, scope: !2900)
!2904 = !DILocation(line: 1610, column: 5, scope: !2900)
!2905 = !DILocation(line: 1612, column: 13, scope: !2900)
!2906 = !DILocation(line: 1612, column: 12, scope: !2900)
!2907 = !DILocation(line: 1612, column: 5, scope: !2900)
!2908 = !DILocation(line: 1613, column: 1, scope: !161)
!2909 = !DILocalVariable(name: "x", arg: 1, scope: !214, file: !3, line: 2000, type: !6)
!2910 = !DILocation(line: 2000, column: 32, scope: !214)
!2911 = !DILocalVariable(name: "f", scope: !214, file: !3, line: 2006, type: !6)
!2912 = !DILocation(line: 2006, column: 10, scope: !214)
!2913 = !DILocalVariable(name: "hfsq", scope: !214, file: !3, line: 2006, type: !6)
!2914 = !DILocation(line: 2006, column: 13, scope: !214)
!2915 = !DILocalVariable(name: "hi", scope: !214, file: !3, line: 2006, type: !6)
!2916 = !DILocation(line: 2006, column: 19, scope: !214)
!2917 = !DILocalVariable(name: "lo", scope: !214, file: !3, line: 2006, type: !6)
!2918 = !DILocation(line: 2006, column: 23, scope: !214)
!2919 = !DILocalVariable(name: "r", scope: !214, file: !3, line: 2006, type: !6)
!2920 = !DILocation(line: 2006, column: 27, scope: !214)
!2921 = !DILocalVariable(name: "val_hi", scope: !214, file: !3, line: 2006, type: !6)
!2922 = !DILocation(line: 2006, column: 30, scope: !214)
!2923 = !DILocalVariable(name: "val_lo", scope: !214, file: !3, line: 2006, type: !6)
!2924 = !DILocation(line: 2006, column: 38, scope: !214)
!2925 = !DILocalVariable(name: "w", scope: !214, file: !3, line: 2006, type: !6)
!2926 = !DILocation(line: 2006, column: 46, scope: !214)
!2927 = !DILocalVariable(name: "y", scope: !214, file: !3, line: 2006, type: !6)
!2928 = !DILocation(line: 2006, column: 49, scope: !214)
!2929 = !DILocalVariable(name: "i", scope: !214, file: !3, line: 2007, type: !18)
!2930 = !DILocation(line: 2007, column: 11, scope: !214)
!2931 = !DILocalVariable(name: "k", scope: !214, file: !3, line: 2007, type: !18)
!2932 = !DILocation(line: 2007, column: 14, scope: !214)
!2933 = !DILocalVariable(name: "hx", scope: !214, file: !3, line: 2007, type: !18)
!2934 = !DILocation(line: 2007, column: 17, scope: !214)
!2935 = !DILocalVariable(name: "lx", scope: !214, file: !3, line: 2008, type: !9)
!2936 = !DILocation(line: 2008, column: 12, scope: !214)
!2937 = !DILocation(line: 2010, column: 3, scope: !214)
!2938 = !DILocalVariable(name: "bits", scope: !2939, file: !3, line: 2010, type: !16)
!2939 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2010, column: 3)
!2940 = !DILocation(line: 2010, column: 3, scope: !2939)
!2941 = !DILocation(line: 2012, column: 5, scope: !214)
!2942 = !DILocation(line: 2013, column: 7, scope: !2943)
!2943 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2013, column: 7)
!2944 = !DILocation(line: 2013, column: 10, scope: !2943)
!2945 = !DILocation(line: 2013, column: 7, scope: !214)
!2946 = !DILocation(line: 2014, column: 11, scope: !2947)
!2947 = distinct !DILexicalBlock(scope: !2948, file: !3, line: 2014, column: 9)
!2948 = distinct !DILexicalBlock(scope: !2943, file: !3, line: 2013, column: 24)
!2949 = !DILocation(line: 2014, column: 14, scope: !2947)
!2950 = !DILocation(line: 2014, column: 30, scope: !2947)
!2951 = !DILocation(line: 2014, column: 28, scope: !2947)
!2952 = !DILocation(line: 2014, column: 34, scope: !2947)
!2953 = !DILocation(line: 2014, column: 9, scope: !2948)
!2954 = !DILocation(line: 2015, column: 7, scope: !2955)
!2955 = distinct !DILexicalBlock(scope: !2947, file: !3, line: 2014, column: 40)
!2956 = !DILocation(line: 2017, column: 9, scope: !2957)
!2957 = distinct !DILexicalBlock(scope: !2948, file: !3, line: 2017, column: 9)
!2958 = !DILocation(line: 2017, column: 12, scope: !2957)
!2959 = !DILocation(line: 2017, column: 9, scope: !2948)
!2960 = !DILocation(line: 2018, column: 7, scope: !2961)
!2961 = distinct !DILexicalBlock(scope: !2957, file: !3, line: 2017, column: 17)
!2962 = !DILocation(line: 2020, column: 7, scope: !2948)
!2963 = !DILocation(line: 2021, column: 7, scope: !2948)
!2964 = !DILocation(line: 2022, column: 5, scope: !2948)
!2965 = !DILocalVariable(name: "bits", scope: !2966, file: !3, line: 2022, type: !16)
!2966 = distinct !DILexicalBlock(scope: !2948, file: !3, line: 2022, column: 5)
!2967 = !DILocation(line: 2022, column: 5, scope: !2966)
!2968 = !DILocation(line: 2023, column: 3, scope: !2948)
!2969 = !DILocation(line: 2024, column: 7, scope: !2970)
!2970 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2024, column: 7)
!2971 = !DILocation(line: 2024, column: 10, scope: !2970)
!2972 = !DILocation(line: 2024, column: 7, scope: !214)
!2973 = !DILocation(line: 2024, column: 32, scope: !2970)
!2974 = !DILocation(line: 2024, column: 36, scope: !2970)
!2975 = !DILocation(line: 2024, column: 34, scope: !2970)
!2976 = !DILocation(line: 2024, column: 25, scope: !2970)
!2977 = !DILocation(line: 2025, column: 7, scope: !2978)
!2978 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2025, column: 7)
!2979 = !DILocation(line: 2025, column: 10, scope: !2978)
!2980 = !DILocation(line: 2025, column: 24, scope: !2978)
!2981 = !DILocation(line: 2025, column: 27, scope: !2978)
!2982 = !DILocation(line: 2025, column: 30, scope: !2978)
!2983 = !DILocation(line: 2025, column: 7, scope: !214)
!2984 = !DILocation(line: 2025, column: 36, scope: !2978)
!2985 = !DILocation(line: 2026, column: 9, scope: !214)
!2986 = !DILocation(line: 2026, column: 12, scope: !214)
!2987 = !DILocation(line: 2026, column: 19, scope: !214)
!2988 = !DILocation(line: 2026, column: 5, scope: !214)
!2989 = !DILocation(line: 2027, column: 6, scope: !214)
!2990 = !DILocation(line: 2028, column: 8, scope: !214)
!2991 = !DILocation(line: 2028, column: 11, scope: !214)
!2992 = !DILocation(line: 2028, column: 22, scope: !214)
!2993 = !DILocation(line: 2028, column: 5, scope: !214)
!2994 = !DILocation(line: 2029, column: 3, scope: !214)
!2995 = !DILocalVariable(name: "bits", scope: !2996, file: !3, line: 2029, type: !16)
!2996 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2029, column: 3)
!2997 = !DILocation(line: 2029, column: 3, scope: !2996)
!2998 = !DILocation(line: 2030, column: 9, scope: !214)
!2999 = !DILocation(line: 2030, column: 11, scope: !214)
!3000 = !DILocation(line: 2030, column: 5, scope: !214)
!3001 = !DILocation(line: 2031, column: 16, scope: !214)
!3002 = !DILocation(line: 2031, column: 7, scope: !214)
!3003 = !DILocation(line: 2031, column: 5, scope: !214)
!3004 = !DILocation(line: 2032, column: 7, scope: !214)
!3005 = !DILocation(line: 2032, column: 9, scope: !214)
!3006 = !DILocation(line: 2032, column: 5, scope: !214)
!3007 = !DILocation(line: 2033, column: 16, scope: !214)
!3008 = !DILocation(line: 2033, column: 14, scope: !214)
!3009 = !DILocation(line: 2033, column: 20, scope: !214)
!3010 = !DILocation(line: 2033, column: 18, scope: !214)
!3011 = !DILocation(line: 2033, column: 8, scope: !214)
!3012 = !DILocation(line: 2034, column: 15, scope: !214)
!3013 = !DILocation(line: 2034, column: 7, scope: !214)
!3014 = !DILocation(line: 2034, column: 5, scope: !214)
!3015 = !DILocation(line: 2066, column: 8, scope: !214)
!3016 = !DILocation(line: 2066, column: 12, scope: !214)
!3017 = !DILocation(line: 2066, column: 10, scope: !214)
!3018 = !DILocation(line: 2066, column: 6, scope: !214)
!3019 = !DILocation(line: 2067, column: 3, scope: !214)
!3020 = !DILocalVariable(name: "bits", scope: !3021, file: !3, line: 2067, type: !16)
!3021 = distinct !DILexicalBlock(scope: !214, file: !3, line: 2067, column: 3)
!3022 = !DILocation(line: 2067, column: 3, scope: !3021)
!3023 = !DILocation(line: 2068, column: 9, scope: !214)
!3024 = !DILocation(line: 2068, column: 13, scope: !214)
!3025 = !DILocation(line: 2068, column: 11, scope: !214)
!3026 = !DILocation(line: 2068, column: 19, scope: !214)
!3027 = !DILocation(line: 2068, column: 17, scope: !214)
!3028 = !DILocation(line: 2068, column: 26, scope: !214)
!3029 = !DILocation(line: 2068, column: 24, scope: !214)
!3030 = !DILocation(line: 2068, column: 6, scope: !214)
!3031 = !DILocation(line: 2069, column: 12, scope: !214)
!3032 = !DILocation(line: 2069, column: 15, scope: !214)
!3033 = !DILocation(line: 2069, column: 10, scope: !214)
!3034 = !DILocation(line: 2070, column: 13, scope: !214)
!3035 = !DILocation(line: 2070, column: 18, scope: !214)
!3036 = !DILocation(line: 2070, column: 16, scope: !214)
!3037 = !DILocation(line: 2070, column: 34, scope: !214)
!3038 = !DILocation(line: 2070, column: 37, scope: !214)
!3039 = !DILocation(line: 2070, column: 32, scope: !214)
!3040 = !DILocation(line: 2070, column: 10, scope: !214)
!3041 = !DILocation(line: 2073, column: 7, scope: !214)
!3042 = !DILocation(line: 2073, column: 11, scope: !214)
!3043 = !DILocation(line: 2073, column: 9, scope: !214)
!3044 = !DILocation(line: 2073, column: 5, scope: !214)
!3045 = !DILocation(line: 2074, column: 14, scope: !214)
!3046 = !DILocation(line: 2074, column: 18, scope: !214)
!3047 = !DILocation(line: 2074, column: 16, scope: !214)
!3048 = !DILocation(line: 2074, column: 23, scope: !214)
!3049 = !DILocation(line: 2074, column: 21, scope: !214)
!3050 = !DILocation(line: 2074, column: 10, scope: !214)
!3051 = !DILocation(line: 2075, column: 12, scope: !214)
!3052 = !DILocation(line: 2075, column: 10, scope: !214)
!3053 = !DILocation(line: 2077, column: 10, scope: !214)
!3054 = !DILocation(line: 2077, column: 19, scope: !214)
!3055 = !DILocation(line: 2077, column: 17, scope: !214)
!3056 = !DILocation(line: 2077, column: 3, scope: !214)
!3057 = !DILocation(line: 2078, column: 1, scope: !214)
!3058 = distinct !DISubprogram(name: "k_log1p", scope: !3, file: !3, line: 1978, type: !4, scopeLine: 1978, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !7, retainedNodes: !50)
!3059 = !DILocalVariable(name: "f", arg: 1, scope: !3058, file: !3, line: 1978, type: !6)
!3060 = !DILocation(line: 1978, column: 37, scope: !3058)
!3061 = !DILocalVariable(name: "hfsq", scope: !3058, file: !3, line: 1979, type: !6)
!3062 = !DILocation(line: 1979, column: 10, scope: !3058)
!3063 = !DILocalVariable(name: "s", scope: !3058, file: !3, line: 1979, type: !6)
!3064 = !DILocation(line: 1979, column: 16, scope: !3058)
!3065 = !DILocalVariable(name: "z", scope: !3058, file: !3, line: 1979, type: !6)
!3066 = !DILocation(line: 1979, column: 19, scope: !3058)
!3067 = !DILocalVariable(name: "R", scope: !3058, file: !3, line: 1979, type: !6)
!3068 = !DILocation(line: 1979, column: 22, scope: !3058)
!3069 = !DILocalVariable(name: "w", scope: !3058, file: !3, line: 1979, type: !6)
!3070 = !DILocation(line: 1979, column: 25, scope: !3058)
!3071 = !DILocalVariable(name: "t1", scope: !3058, file: !3, line: 1979, type: !6)
!3072 = !DILocation(line: 1979, column: 28, scope: !3058)
!3073 = !DILocalVariable(name: "t2", scope: !3058, file: !3, line: 1979, type: !6)
!3074 = !DILocation(line: 1979, column: 32, scope: !3058)
!3075 = !DILocation(line: 1981, column: 7, scope: !3058)
!3076 = !DILocation(line: 1981, column: 18, scope: !3058)
!3077 = !DILocation(line: 1981, column: 16, scope: !3058)
!3078 = !DILocation(line: 1981, column: 9, scope: !3058)
!3079 = !DILocation(line: 1981, column: 5, scope: !3058)
!3080 = !DILocation(line: 1982, column: 7, scope: !3058)
!3081 = !DILocation(line: 1982, column: 11, scope: !3058)
!3082 = !DILocation(line: 1982, column: 9, scope: !3058)
!3083 = !DILocation(line: 1982, column: 5, scope: !3058)
!3084 = !DILocation(line: 1983, column: 7, scope: !3058)
!3085 = !DILocation(line: 1983, column: 11, scope: !3058)
!3086 = !DILocation(line: 1983, column: 9, scope: !3058)
!3087 = !DILocation(line: 1983, column: 5, scope: !3058)
!3088 = !DILocation(line: 1984, column: 8, scope: !3058)
!3089 = !DILocation(line: 1984, column: 19, scope: !3058)
!3090 = !DILocation(line: 1984, column: 30, scope: !3058)
!3091 = !DILocation(line: 1984, column: 28, scope: !3058)
!3092 = !DILocation(line: 1984, column: 17, scope: !3058)
!3093 = !DILocation(line: 1984, column: 10, scope: !3058)
!3094 = !DILocation(line: 1984, column: 6, scope: !3058)
!3095 = !DILocation(line: 1985, column: 8, scope: !3058)
!3096 = !DILocation(line: 1985, column: 19, scope: !3058)
!3097 = !DILocation(line: 1985, column: 30, scope: !3058)
!3098 = !DILocation(line: 1985, column: 41, scope: !3058)
!3099 = !DILocation(line: 1985, column: 39, scope: !3058)
!3100 = !DILocation(line: 1985, column: 28, scope: !3058)
!3101 = !DILocation(line: 1985, column: 17, scope: !3058)
!3102 = !DILocation(line: 1985, column: 10, scope: !3058)
!3103 = !DILocation(line: 1985, column: 6, scope: !3058)
!3104 = !DILocation(line: 1986, column: 7, scope: !3058)
!3105 = !DILocation(line: 1986, column: 12, scope: !3058)
!3106 = !DILocation(line: 1986, column: 10, scope: !3058)
!3107 = !DILocation(line: 1986, column: 5, scope: !3058)
!3108 = !DILocation(line: 1987, column: 16, scope: !3058)
!3109 = !DILocation(line: 1987, column: 14, scope: !3058)
!3110 = !DILocation(line: 1987, column: 20, scope: !3058)
!3111 = !DILocation(line: 1987, column: 18, scope: !3058)
!3112 = !DILocation(line: 1987, column: 8, scope: !3058)
!3113 = !DILocation(line: 1988, column: 10, scope: !3058)
!3114 = !DILocation(line: 1988, column: 15, scope: !3058)
!3115 = !DILocation(line: 1988, column: 22, scope: !3058)
!3116 = !DILocation(line: 1988, column: 20, scope: !3058)
!3117 = !DILocation(line: 1988, column: 12, scope: !3058)
!3118 = !DILocation(line: 1988, column: 3, scope: !3058)
!3119 = !DILocalVariable(name: "x", arg: 1, scope: !221, file: !3, line: 2106, type: !6)
!3120 = !DILocation(line: 2106, column: 33, scope: !221)
!3121 = !DILocalVariable(name: "y", scope: !221, file: !3, line: 2113, type: !6)
!3122 = !DILocation(line: 2113, column: 10, scope: !221)
!3123 = !DILocalVariable(name: "i", scope: !221, file: !3, line: 2114, type: !18)
!3124 = !DILocation(line: 2114, column: 11, scope: !221)
!3125 = !DILocalVariable(name: "k", scope: !221, file: !3, line: 2114, type: !18)
!3126 = !DILocation(line: 2114, column: 14, scope: !221)
!3127 = !DILocalVariable(name: "hx", scope: !221, file: !3, line: 2114, type: !18)
!3128 = !DILocation(line: 2114, column: 17, scope: !221)
!3129 = !DILocalVariable(name: "lx", scope: !221, file: !3, line: 2115, type: !9)
!3130 = !DILocation(line: 2115, column: 12, scope: !221)
!3131 = !DILocation(line: 2117, column: 3, scope: !221)
!3132 = !DILocalVariable(name: "bits", scope: !3133, file: !3, line: 2117, type: !16)
!3133 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2117, column: 3)
!3134 = !DILocation(line: 2117, column: 3, scope: !3133)
!3135 = !DILocation(line: 2119, column: 5, scope: !221)
!3136 = !DILocation(line: 2120, column: 7, scope: !3137)
!3137 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2120, column: 7)
!3138 = !DILocation(line: 2120, column: 10, scope: !3137)
!3139 = !DILocation(line: 2120, column: 7, scope: !221)
!3140 = !DILocation(line: 2121, column: 11, scope: !3141)
!3141 = distinct !DILexicalBlock(scope: !3142, file: !3, line: 2121, column: 9)
!3142 = distinct !DILexicalBlock(scope: !3137, file: !3, line: 2120, column: 24)
!3143 = !DILocation(line: 2121, column: 14, scope: !3141)
!3144 = !DILocation(line: 2121, column: 30, scope: !3141)
!3145 = !DILocation(line: 2121, column: 28, scope: !3141)
!3146 = !DILocation(line: 2121, column: 34, scope: !3141)
!3147 = !DILocation(line: 2121, column: 9, scope: !3142)
!3148 = !DILocation(line: 2122, column: 7, scope: !3149)
!3149 = distinct !DILexicalBlock(scope: !3141, file: !3, line: 2121, column: 40)
!3150 = !DILocation(line: 2124, column: 9, scope: !3151)
!3151 = distinct !DILexicalBlock(scope: !3142, file: !3, line: 2124, column: 9)
!3152 = !DILocation(line: 2124, column: 12, scope: !3151)
!3153 = !DILocation(line: 2124, column: 9, scope: !3142)
!3154 = !DILocation(line: 2125, column: 7, scope: !3155)
!3155 = distinct !DILexicalBlock(scope: !3151, file: !3, line: 2124, column: 17)
!3156 = !DILocation(line: 2127, column: 7, scope: !3142)
!3157 = !DILocation(line: 2128, column: 7, scope: !3142)
!3158 = !DILocation(line: 2129, column: 5, scope: !3142)
!3159 = !DILocalVariable(name: "bits", scope: !3160, file: !3, line: 2129, type: !16)
!3160 = distinct !DILexicalBlock(scope: !3142, file: !3, line: 2129, column: 5)
!3161 = !DILocation(line: 2129, column: 5, scope: !3160)
!3162 = !DILocation(line: 2130, column: 5, scope: !3142)
!3163 = !DILocalVariable(name: "bits", scope: !3164, file: !3, line: 2130, type: !16)
!3164 = distinct !DILexicalBlock(scope: !3142, file: !3, line: 2130, column: 5)
!3165 = !DILocation(line: 2130, column: 5, scope: !3164)
!3166 = !DILocation(line: 2131, column: 3, scope: !3142)
!3167 = !DILocation(line: 2132, column: 7, scope: !3168)
!3168 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2132, column: 7)
!3169 = !DILocation(line: 2132, column: 10, scope: !3168)
!3170 = !DILocation(line: 2132, column: 7, scope: !221)
!3171 = !DILocation(line: 2132, column: 32, scope: !3168)
!3172 = !DILocation(line: 2132, column: 36, scope: !3168)
!3173 = !DILocation(line: 2132, column: 34, scope: !3168)
!3174 = !DILocation(line: 2132, column: 25, scope: !3168)
!3175 = !DILocation(line: 2133, column: 7, scope: !3176)
!3176 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2133, column: 7)
!3177 = !DILocation(line: 2133, column: 10, scope: !3176)
!3178 = !DILocation(line: 2133, column: 24, scope: !3176)
!3179 = !DILocation(line: 2133, column: 27, scope: !3176)
!3180 = !DILocation(line: 2133, column: 30, scope: !3176)
!3181 = !DILocation(line: 2133, column: 7, scope: !221)
!3182 = !DILocation(line: 2133, column: 36, scope: !3176)
!3183 = !DILocation(line: 2134, column: 9, scope: !221)
!3184 = !DILocation(line: 2134, column: 12, scope: !221)
!3185 = !DILocation(line: 2134, column: 19, scope: !221)
!3186 = !DILocation(line: 2134, column: 5, scope: !221)
!3187 = !DILocation(line: 2136, column: 8, scope: !221)
!3188 = !DILocation(line: 2136, column: 10, scope: !221)
!3189 = !DILocation(line: 2136, column: 24, scope: !221)
!3190 = !DILocation(line: 2136, column: 5, scope: !221)
!3191 = !DILocation(line: 2137, column: 9, scope: !221)
!3192 = !DILocation(line: 2137, column: 12, scope: !221)
!3193 = !DILocation(line: 2137, column: 38, scope: !221)
!3194 = !DILocation(line: 2137, column: 36, scope: !221)
!3195 = !DILocation(line: 2137, column: 41, scope: !221)
!3196 = !DILocation(line: 2137, column: 26, scope: !221)
!3197 = !DILocation(line: 2137, column: 6, scope: !221)
!3198 = !DILocation(line: 2138, column: 7, scope: !221)
!3199 = !DILocation(line: 2138, column: 11, scope: !221)
!3200 = !DILocation(line: 2138, column: 9, scope: !221)
!3201 = !DILocation(line: 2138, column: 5, scope: !221)
!3202 = !DILocation(line: 2139, column: 3, scope: !221)
!3203 = !DILocalVariable(name: "bits", scope: !3204, file: !3, line: 2139, type: !16)
!3204 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2139, column: 3)
!3205 = !DILocation(line: 2139, column: 3, scope: !3204)
!3206 = !DILocation(line: 2140, column: 3, scope: !221)
!3207 = !DILocalVariable(name: "bits", scope: !3208, file: !3, line: 2140, type: !16)
!3208 = distinct !DILexicalBlock(scope: !221, file: !3, line: 2140, column: 3)
!3209 = !DILocation(line: 2140, column: 3, scope: !3208)
!3210 = !DILocalVariable(name: "z", scope: !221, file: !3, line: 2142, type: !6)
!3211 = !DILocation(line: 2142, column: 10, scope: !221)
!3212 = !DILocation(line: 2142, column: 14, scope: !221)
!3213 = !DILocation(line: 2142, column: 55, scope: !221)
!3214 = !DILocation(line: 2142, column: 39, scope: !221)
!3215 = !DILocation(line: 2142, column: 37, scope: !221)
!3216 = !DILocation(line: 2142, column: 28, scope: !221)
!3217 = !DILocation(line: 2143, column: 10, scope: !221)
!3218 = !DILocation(line: 2143, column: 14, scope: !221)
!3219 = !DILocation(line: 2143, column: 12, scope: !221)
!3220 = !DILocation(line: 2143, column: 3, scope: !221)
!3221 = !DILocation(line: 2144, column: 1, scope: !221)
!3222 = !DILocalVariable(name: "x", arg: 1, scope: !230, file: !3, line: 2240, type: !6)
!3223 = !DILocation(line: 2240, column: 33, scope: !230)
!3224 = !DILocalVariable(name: "y", scope: !230, file: !3, line: 2258, type: !6)
!3225 = !DILocation(line: 2258, column: 10, scope: !230)
!3226 = !DILocalVariable(name: "hi", scope: !230, file: !3, line: 2258, type: !6)
!3227 = !DILocation(line: 2258, column: 13, scope: !230)
!3228 = !DILocalVariable(name: "lo", scope: !230, file: !3, line: 2258, type: !6)
!3229 = !DILocation(line: 2258, column: 17, scope: !230)
!3230 = !DILocalVariable(name: "c", scope: !230, file: !3, line: 2258, type: !6)
!3231 = !DILocation(line: 2258, column: 21, scope: !230)
!3232 = !DILocalVariable(name: "t", scope: !230, file: !3, line: 2258, type: !6)
!3233 = !DILocation(line: 2258, column: 24, scope: !230)
!3234 = !DILocalVariable(name: "e", scope: !230, file: !3, line: 2258, type: !6)
!3235 = !DILocation(line: 2258, column: 27, scope: !230)
!3236 = !DILocalVariable(name: "hxs", scope: !230, file: !3, line: 2258, type: !6)
!3237 = !DILocation(line: 2258, column: 30, scope: !230)
!3238 = !DILocalVariable(name: "hfx", scope: !230, file: !3, line: 2258, type: !6)
!3239 = !DILocation(line: 2258, column: 35, scope: !230)
!3240 = !DILocalVariable(name: "r1", scope: !230, file: !3, line: 2258, type: !6)
!3241 = !DILocation(line: 2258, column: 40, scope: !230)
!3242 = !DILocalVariable(name: "twopk", scope: !230, file: !3, line: 2258, type: !6)
!3243 = !DILocation(line: 2258, column: 44, scope: !230)
!3244 = !DILocalVariable(name: "k", scope: !230, file: !3, line: 2259, type: !18)
!3245 = !DILocation(line: 2259, column: 11, scope: !230)
!3246 = !DILocalVariable(name: "xsb", scope: !230, file: !3, line: 2259, type: !18)
!3247 = !DILocation(line: 2259, column: 14, scope: !230)
!3248 = !DILocalVariable(name: "hx", scope: !230, file: !3, line: 2260, type: !9)
!3249 = !DILocation(line: 2260, column: 12, scope: !230)
!3250 = !DILocation(line: 2262, column: 3, scope: !230)
!3251 = !DILocalVariable(name: "bits", scope: !3252, file: !3, line: 2262, type: !16)
!3252 = distinct !DILexicalBlock(scope: !230, file: !3, line: 2262, column: 3)
!3253 = !DILocation(line: 2262, column: 3, scope: !3252)
!3254 = !DILocation(line: 2263, column: 9, scope: !230)
!3255 = !DILocation(line: 2263, column: 12, scope: !230)
!3256 = !DILocation(line: 2263, column: 7, scope: !230)
!3257 = !DILocation(line: 2264, column: 6, scope: !230)
!3258 = !DILocation(line: 2267, column: 7, scope: !3259)
!3259 = distinct !DILexicalBlock(scope: !230, file: !3, line: 2267, column: 7)
!3260 = !DILocation(line: 2267, column: 10, scope: !3259)
!3261 = !DILocation(line: 2267, column: 7, scope: !230)
!3262 = !DILocation(line: 2268, column: 9, scope: !3263)
!3263 = distinct !DILexicalBlock(scope: !3264, file: !3, line: 2268, column: 9)
!3264 = distinct !DILexicalBlock(scope: !3259, file: !3, line: 2267, column: 25)
!3265 = !DILocation(line: 2268, column: 12, scope: !3263)
!3266 = !DILocation(line: 2268, column: 9, scope: !3264)
!3267 = !DILocation(line: 2269, column: 11, scope: !3268)
!3268 = distinct !DILexicalBlock(scope: !3269, file: !3, line: 2269, column: 11)
!3269 = distinct !DILexicalBlock(scope: !3263, file: !3, line: 2268, column: 27)
!3270 = !DILocation(line: 2269, column: 14, scope: !3268)
!3271 = !DILocation(line: 2269, column: 11, scope: !3269)
!3272 = !DILocalVariable(name: "low", scope: !3273, file: !3, line: 2270, type: !9)
!3273 = distinct !DILexicalBlock(scope: !3268, file: !3, line: 2269, column: 29)
!3274 = !DILocation(line: 2270, column: 18, scope: !3273)
!3275 = !DILocation(line: 2271, column: 9, scope: !3273)
!3276 = !DILocalVariable(name: "bits", scope: !3277, file: !3, line: 2271, type: !16)
!3277 = distinct !DILexicalBlock(scope: !3273, file: !3, line: 2271, column: 9)
!3278 = !DILocation(line: 2271, column: 9, scope: !3277)
!3279 = !DILocation(line: 2272, column: 15, scope: !3280)
!3280 = distinct !DILexicalBlock(scope: !3273, file: !3, line: 2272, column: 13)
!3281 = !DILocation(line: 2272, column: 18, scope: !3280)
!3282 = !DILocation(line: 2272, column: 31, scope: !3280)
!3283 = !DILocation(line: 2272, column: 29, scope: !3280)
!3284 = !DILocation(line: 2272, column: 36, scope: !3280)
!3285 = !DILocation(line: 2272, column: 13, scope: !3273)
!3286 = !DILocation(line: 2273, column: 18, scope: !3280)
!3287 = !DILocation(line: 2273, column: 22, scope: !3280)
!3288 = !DILocation(line: 2273, column: 20, scope: !3280)
!3289 = !DILocation(line: 2273, column: 11, scope: !3280)
!3290 = !DILocation(line: 2275, column: 19, scope: !3280)
!3291 = !DILocation(line: 2275, column: 23, scope: !3280)
!3292 = !DILocation(line: 2275, column: 18, scope: !3280)
!3293 = !DILocation(line: 2275, column: 31, scope: !3280)
!3294 = !DILocation(line: 2275, column: 11, scope: !3280)
!3295 = !DILocation(line: 2277, column: 11, scope: !3296)
!3296 = distinct !DILexicalBlock(scope: !3269, file: !3, line: 2277, column: 11)
!3297 = !DILocation(line: 2277, column: 13, scope: !3296)
!3298 = !DILocation(line: 2277, column: 11, scope: !3269)
!3299 = !DILocation(line: 2277, column: 35, scope: !3296)
!3300 = !DILocation(line: 2277, column: 42, scope: !3296)
!3301 = !DILocation(line: 2277, column: 40, scope: !3296)
!3302 = !DILocation(line: 2277, column: 28, scope: !3296)
!3303 = !DILocation(line: 2278, column: 5, scope: !3269)
!3304 = !DILocation(line: 2279, column: 9, scope: !3305)
!3305 = distinct !DILexicalBlock(scope: !3264, file: !3, line: 2279, column: 9)
!3306 = !DILocation(line: 2279, column: 13, scope: !3305)
!3307 = !DILocation(line: 2279, column: 9, scope: !3264)
!3308 = !DILocation(line: 2280, column: 11, scope: !3309)
!3309 = distinct !DILexicalBlock(scope: !3310, file: !3, line: 2280, column: 11)
!3310 = distinct !DILexicalBlock(scope: !3305, file: !3, line: 2279, column: 19)
!3311 = !DILocation(line: 2280, column: 13, scope: !3309)
!3312 = !DILocation(line: 2280, column: 20, scope: !3309)
!3313 = !DILocation(line: 2280, column: 11, scope: !3310)
!3314 = !DILocation(line: 2281, column: 9, scope: !3309)
!3315 = !DILocation(line: 2282, column: 5, scope: !3310)
!3316 = !DILocation(line: 2283, column: 3, scope: !3264)
!3317 = !DILocation(line: 2286, column: 7, scope: !3318)
!3318 = distinct !DILexicalBlock(scope: !230, file: !3, line: 2286, column: 7)
!3319 = !DILocation(line: 2286, column: 10, scope: !3318)
!3320 = !DILocation(line: 2286, column: 7, scope: !230)
!3321 = !DILocation(line: 2287, column: 9, scope: !3322)
!3322 = distinct !DILexicalBlock(scope: !3323, file: !3, line: 2287, column: 9)
!3323 = distinct !DILexicalBlock(scope: !3318, file: !3, line: 2286, column: 24)
!3324 = !DILocation(line: 2287, column: 12, scope: !3322)
!3325 = !DILocation(line: 2287, column: 9, scope: !3323)
!3326 = !DILocation(line: 2288, column: 11, scope: !3327)
!3327 = distinct !DILexicalBlock(scope: !3328, file: !3, line: 2288, column: 11)
!3328 = distinct !DILexicalBlock(scope: !3322, file: !3, line: 2287, column: 26)
!3329 = !DILocation(line: 2288, column: 15, scope: !3327)
!3330 = !DILocation(line: 2288, column: 11, scope: !3328)
!3331 = !DILocation(line: 2289, column: 14, scope: !3332)
!3332 = distinct !DILexicalBlock(scope: !3327, file: !3, line: 2288, column: 21)
!3333 = !DILocation(line: 2289, column: 16, scope: !3332)
!3334 = !DILocation(line: 2289, column: 12, scope: !3332)
!3335 = !DILocation(line: 2290, column: 12, scope: !3332)
!3336 = !DILocation(line: 2291, column: 11, scope: !3332)
!3337 = !DILocation(line: 2292, column: 7, scope: !3332)
!3338 = !DILocation(line: 2293, column: 14, scope: !3339)
!3339 = distinct !DILexicalBlock(scope: !3327, file: !3, line: 2292, column: 14)
!3340 = !DILocation(line: 2293, column: 16, scope: !3339)
!3341 = !DILocation(line: 2293, column: 12, scope: !3339)
!3342 = !DILocation(line: 2294, column: 12, scope: !3339)
!3343 = !DILocation(line: 2295, column: 11, scope: !3339)
!3344 = !DILocation(line: 2297, column: 5, scope: !3328)
!3345 = !DILocation(line: 2298, column: 20, scope: !3346)
!3346 = distinct !DILexicalBlock(scope: !3322, file: !3, line: 2297, column: 12)
!3347 = !DILocation(line: 2298, column: 26, scope: !3346)
!3348 = !DILocation(line: 2298, column: 30, scope: !3346)
!3349 = !DILocation(line: 2298, column: 25, scope: !3346)
!3350 = !DILocation(line: 2298, column: 22, scope: !3346)
!3351 = !DILocation(line: 2298, column: 11, scope: !3346)
!3352 = !DILocation(line: 2298, column: 9, scope: !3346)
!3353 = !DILocation(line: 2299, column: 11, scope: !3346)
!3354 = !DILocation(line: 2299, column: 9, scope: !3346)
!3355 = !DILocation(line: 2300, column: 12, scope: !3346)
!3356 = !DILocation(line: 2300, column: 16, scope: !3346)
!3357 = !DILocation(line: 2300, column: 14, scope: !3346)
!3358 = !DILocation(line: 2300, column: 10, scope: !3346)
!3359 = !DILocation(line: 2301, column: 12, scope: !3346)
!3360 = !DILocation(line: 2301, column: 14, scope: !3346)
!3361 = !DILocation(line: 2301, column: 10, scope: !3346)
!3362 = !DILocation(line: 2303, column: 9, scope: !3323)
!3363 = !DILocation(line: 2303, column: 14, scope: !3323)
!3364 = !DILocation(line: 2303, column: 12, scope: !3323)
!3365 = !DILocation(line: 2303, column: 7, scope: !3323)
!3366 = !DILocation(line: 2304, column: 10, scope: !3323)
!3367 = !DILocation(line: 2304, column: 15, scope: !3323)
!3368 = !DILocation(line: 2304, column: 13, scope: !3323)
!3369 = !DILocation(line: 2304, column: 20, scope: !3323)
!3370 = !DILocation(line: 2304, column: 18, scope: !3323)
!3371 = !DILocation(line: 2304, column: 7, scope: !3323)
!3372 = !DILocation(line: 2305, column: 3, scope: !3323)
!3373 = !DILocation(line: 2305, column: 14, scope: !3374)
!3374 = distinct !DILexicalBlock(scope: !3318, file: !3, line: 2305, column: 14)
!3375 = !DILocation(line: 2305, column: 17, scope: !3374)
!3376 = !DILocation(line: 2305, column: 14, scope: !3318)
!3377 = !DILocation(line: 2306, column: 9, scope: !3378)
!3378 = distinct !DILexicalBlock(scope: !3374, file: !3, line: 2305, column: 31)
!3379 = !DILocation(line: 2306, column: 16, scope: !3378)
!3380 = !DILocation(line: 2306, column: 14, scope: !3378)
!3381 = !DILocation(line: 2306, column: 7, scope: !3378)
!3382 = !DILocation(line: 2307, column: 12, scope: !3378)
!3383 = !DILocation(line: 2307, column: 17, scope: !3378)
!3384 = !DILocation(line: 2307, column: 22, scope: !3378)
!3385 = !DILocation(line: 2307, column: 29, scope: !3378)
!3386 = !DILocation(line: 2307, column: 27, scope: !3378)
!3387 = !DILocation(line: 2307, column: 19, scope: !3378)
!3388 = !DILocation(line: 2307, column: 14, scope: !3378)
!3389 = !DILocation(line: 2307, column: 5, scope: !3378)
!3390 = !DILocation(line: 2309, column: 7, scope: !3391)
!3391 = distinct !DILexicalBlock(scope: !3374, file: !3, line: 2308, column: 10)
!3392 = !DILocation(line: 2313, column: 15, scope: !230)
!3393 = !DILocation(line: 2313, column: 13, scope: !230)
!3394 = !DILocation(line: 2313, column: 7, scope: !230)
!3395 = !DILocation(line: 2314, column: 9, scope: !230)
!3396 = !DILocation(line: 2314, column: 13, scope: !230)
!3397 = !DILocation(line: 2314, column: 11, scope: !230)
!3398 = !DILocation(line: 2314, column: 7, scope: !230)
!3399 = !DILocation(line: 2315, column: 14, scope: !230)
!3400 = !DILocation(line: 2315, column: 26, scope: !230)
!3401 = !DILocation(line: 2315, column: 38, scope: !230)
!3402 = !DILocation(line: 2315, column: 50, scope: !230)
!3403 = !DILocation(line: 2315, column: 62, scope: !230)
!3404 = !DILocation(line: 2315, column: 60, scope: !230)
!3405 = !DILocation(line: 2315, column: 48, scope: !230)
!3406 = !DILocation(line: 2315, column: 36, scope: !230)
!3407 = !DILocation(line: 2315, column: 24, scope: !230)
!3408 = !DILocation(line: 2315, column: 12, scope: !230)
!3409 = !DILocation(line: 2315, column: 6, scope: !230)
!3410 = !DILocation(line: 2316, column: 13, scope: !230)
!3411 = !DILocation(line: 2316, column: 18, scope: !230)
!3412 = !DILocation(line: 2316, column: 11, scope: !230)
!3413 = !DILocation(line: 2316, column: 5, scope: !230)
!3414 = !DILocation(line: 2317, column: 7, scope: !230)
!3415 = !DILocation(line: 2317, column: 15, scope: !230)
!3416 = !DILocation(line: 2317, column: 20, scope: !230)
!3417 = !DILocation(line: 2317, column: 18, scope: !230)
!3418 = !DILocation(line: 2317, column: 32, scope: !230)
!3419 = !DILocation(line: 2317, column: 36, scope: !230)
!3420 = !DILocation(line: 2317, column: 30, scope: !230)
!3421 = !DILocation(line: 2317, column: 23, scope: !230)
!3422 = !DILocation(line: 2317, column: 11, scope: !230)
!3423 = !DILocation(line: 2317, column: 5, scope: !230)
!3424 = !DILocation(line: 2318, column: 7, scope: !3425)
!3425 = distinct !DILexicalBlock(scope: !230, file: !3, line: 2318, column: 7)
!3426 = !DILocation(line: 2318, column: 9, scope: !3425)
!3427 = !DILocation(line: 2318, column: 7, scope: !230)
!3428 = !DILocation(line: 2319, column: 12, scope: !3429)
!3429 = distinct !DILexicalBlock(scope: !3425, file: !3, line: 2318, column: 15)
!3430 = !DILocation(line: 2319, column: 17, scope: !3429)
!3431 = !DILocation(line: 2319, column: 21, scope: !3429)
!3432 = !DILocation(line: 2319, column: 25, scope: !3429)
!3433 = !DILocation(line: 2319, column: 23, scope: !3429)
!3434 = !DILocation(line: 2319, column: 14, scope: !3429)
!3435 = !DILocation(line: 2319, column: 5, scope: !3429)
!3436 = !DILocation(line: 2321, column: 5, scope: !3437)
!3437 = distinct !DILexicalBlock(scope: !3425, file: !3, line: 2320, column: 10)
!3438 = !DILocalVariable(name: "bits", scope: !3439, file: !3, line: 2321, type: !16)
!3439 = distinct !DILexicalBlock(scope: !3437, file: !3, line: 2321, column: 5)
!3440 = !DILocation(line: 2321, column: 5, scope: !3439)
!3441 = !DILocation(line: 2325, column: 10, scope: !3437)
!3442 = !DILocation(line: 2325, column: 15, scope: !3437)
!3443 = !DILocation(line: 2325, column: 19, scope: !3437)
!3444 = !DILocation(line: 2325, column: 17, scope: !3437)
!3445 = !DILocation(line: 2325, column: 24, scope: !3437)
!3446 = !DILocation(line: 2325, column: 22, scope: !3437)
!3447 = !DILocation(line: 2325, column: 7, scope: !3437)
!3448 = !DILocation(line: 2326, column: 10, scope: !3437)
!3449 = !DILocation(line: 2326, column: 7, scope: !3437)
!3450 = !DILocation(line: 2327, column: 9, scope: !3451)
!3451 = distinct !DILexicalBlock(scope: !3437, file: !3, line: 2327, column: 9)
!3452 = !DILocation(line: 2327, column: 11, scope: !3451)
!3453 = !DILocation(line: 2327, column: 9, scope: !3437)
!3454 = !DILocation(line: 2327, column: 32, scope: !3451)
!3455 = !DILocation(line: 2327, column: 36, scope: !3451)
!3456 = !DILocation(line: 2327, column: 34, scope: !3451)
!3457 = !DILocation(line: 2327, column: 39, scope: !3451)
!3458 = !DILocation(line: 2327, column: 18, scope: !3451)
!3459 = !DILocation(line: 2328, column: 9, scope: !3460)
!3460 = distinct !DILexicalBlock(scope: !3437, file: !3, line: 2328, column: 9)
!3461 = !DILocation(line: 2328, column: 11, scope: !3460)
!3462 = !DILocation(line: 2328, column: 9, scope: !3437)
!3463 = !DILocation(line: 2329, column: 11, scope: !3464)
!3464 = distinct !DILexicalBlock(scope: !3465, file: !3, line: 2329, column: 11)
!3465 = distinct !DILexicalBlock(scope: !3460, file: !3, line: 2328, column: 17)
!3466 = !DILocation(line: 2329, column: 13, scope: !3464)
!3467 = !DILocation(line: 2329, column: 11, scope: !3465)
!3468 = !DILocation(line: 2330, column: 24, scope: !3464)
!3469 = !DILocation(line: 2330, column: 29, scope: !3464)
!3470 = !DILocation(line: 2330, column: 31, scope: !3464)
!3471 = !DILocation(line: 2330, column: 26, scope: !3464)
!3472 = !DILocation(line: 2330, column: 21, scope: !3464)
!3473 = !DILocation(line: 2330, column: 9, scope: !3464)
!3474 = !DILocation(line: 2332, column: 29, scope: !3464)
!3475 = !DILocation(line: 2332, column: 33, scope: !3464)
!3476 = !DILocation(line: 2332, column: 31, scope: !3464)
!3477 = !DILocation(line: 2332, column: 20, scope: !3464)
!3478 = !DILocation(line: 2332, column: 9, scope: !3464)
!3479 = !DILocation(line: 2334, column: 9, scope: !3480)
!3480 = distinct !DILexicalBlock(scope: !3437, file: !3, line: 2334, column: 9)
!3481 = !DILocation(line: 2334, column: 11, scope: !3480)
!3482 = !DILocation(line: 2334, column: 17, scope: !3480)
!3483 = !DILocation(line: 2334, column: 20, scope: !3480)
!3484 = !DILocation(line: 2334, column: 22, scope: !3480)
!3485 = !DILocation(line: 2334, column: 9, scope: !3437)
!3486 = !DILocation(line: 2335, column: 18, scope: !3487)
!3487 = distinct !DILexicalBlock(scope: !3480, file: !3, line: 2334, column: 28)
!3488 = !DILocation(line: 2335, column: 22, scope: !3487)
!3489 = !DILocation(line: 2335, column: 20, scope: !3487)
!3490 = !DILocation(line: 2335, column: 15, scope: !3487)
!3491 = !DILocation(line: 2335, column: 9, scope: !3487)
!3492 = !DILocation(line: 2339, column: 11, scope: !3493)
!3493 = distinct !DILexicalBlock(scope: !3487, file: !3, line: 2339, column: 11)
!3494 = !DILocation(line: 2339, column: 13, scope: !3493)
!3495 = !DILocation(line: 2339, column: 11, scope: !3487)
!3496 = !DILocation(line: 2340, column: 13, scope: !3493)
!3497 = !DILocation(line: 2340, column: 15, scope: !3493)
!3498 = !DILocation(line: 2340, column: 21, scope: !3493)
!3499 = !DILocation(line: 2340, column: 11, scope: !3493)
!3500 = !DILocation(line: 2340, column: 9, scope: !3493)
!3501 = !DILocation(line: 2342, column: 13, scope: !3493)
!3502 = !DILocation(line: 2342, column: 17, scope: !3493)
!3503 = !DILocation(line: 2342, column: 15, scope: !3493)
!3504 = !DILocation(line: 2342, column: 11, scope: !3493)
!3505 = !DILocation(line: 2343, column: 14, scope: !3487)
!3506 = !DILocation(line: 2343, column: 16, scope: !3487)
!3507 = !DILocation(line: 2343, column: 7, scope: !3487)
!3508 = !DILocation(line: 2345, column: 7, scope: !3437)
!3509 = !DILocation(line: 2346, column: 9, scope: !3510)
!3510 = distinct !DILexicalBlock(scope: !3437, file: !3, line: 2346, column: 9)
!3511 = !DILocation(line: 2346, column: 11, scope: !3510)
!3512 = !DILocation(line: 2346, column: 9, scope: !3437)
!3513 = !DILocation(line: 2347, column: 7, scope: !3514)
!3514 = distinct !DILexicalBlock(scope: !3510, file: !3, line: 2346, column: 17)
!3515 = !DILocalVariable(name: "bits", scope: !3516, file: !3, line: 2347, type: !16)
!3516 = distinct !DILexicalBlock(scope: !3514, file: !3, line: 2347, column: 7)
!3517 = !DILocation(line: 2347, column: 7, scope: !3516)
!3518 = !DILocation(line: 2348, column: 11, scope: !3514)
!3519 = !DILocation(line: 2348, column: 16, scope: !3514)
!3520 = !DILocation(line: 2348, column: 20, scope: !3514)
!3521 = !DILocation(line: 2348, column: 18, scope: !3514)
!3522 = !DILocation(line: 2348, column: 13, scope: !3514)
!3523 = !DILocation(line: 2348, column: 9, scope: !3514)
!3524 = !DILocation(line: 2349, column: 11, scope: !3514)
!3525 = !DILocation(line: 2349, column: 15, scope: !3514)
!3526 = !DILocation(line: 2349, column: 13, scope: !3514)
!3527 = !DILocation(line: 2349, column: 9, scope: !3514)
!3528 = !DILocation(line: 2350, column: 5, scope: !3514)
!3529 = !DILocation(line: 2351, column: 7, scope: !3530)
!3530 = distinct !DILexicalBlock(scope: !3510, file: !3, line: 2350, column: 12)
!3531 = !DILocalVariable(name: "bits", scope: !3532, file: !3, line: 2351, type: !16)
!3532 = distinct !DILexicalBlock(scope: !3530, file: !3, line: 2351, column: 7)
!3533 = !DILocation(line: 2351, column: 7, scope: !3532)
!3534 = !DILocation(line: 2352, column: 11, scope: !3530)
!3535 = !DILocation(line: 2352, column: 16, scope: !3530)
!3536 = !DILocation(line: 2352, column: 20, scope: !3530)
!3537 = !DILocation(line: 2352, column: 18, scope: !3530)
!3538 = !DILocation(line: 2352, column: 13, scope: !3530)
!3539 = !DILocation(line: 2352, column: 9, scope: !3530)
!3540 = !DILocation(line: 2353, column: 9, scope: !3530)
!3541 = !DILocation(line: 2354, column: 11, scope: !3530)
!3542 = !DILocation(line: 2354, column: 15, scope: !3530)
!3543 = !DILocation(line: 2354, column: 13, scope: !3530)
!3544 = !DILocation(line: 2354, column: 9, scope: !3530)
!3545 = !DILocation(line: 2357, column: 10, scope: !230)
!3546 = !DILocation(line: 2357, column: 3, scope: !230)
!3547 = !DILocation(line: 2358, column: 1, scope: !230)
!3548 = !DILocalVariable(name: "x", arg: 1, scope: !255, file: !3, line: 2360, type: !6)
!3549 = !DILocation(line: 2360, column: 32, scope: !255)
!3550 = !DILocalVariable(name: "hx", scope: !255, file: !3, line: 2372, type: !18)
!3551 = !DILocation(line: 2372, column: 11, scope: !255)
!3552 = !DILocalVariable(name: "r", scope: !255, file: !3, line: 2373, type: !6)
!3553 = !DILocation(line: 2373, column: 10, scope: !255)
!3554 = !DILocalVariable(name: "s", scope: !255, file: !3, line: 2373, type: !6)
!3555 = !DILocation(line: 2373, column: 13, scope: !255)
!3556 = !DILocalVariable(name: "t", scope: !255, file: !3, line: 2373, type: !6)
!3557 = !DILocation(line: 2373, column: 16, scope: !255)
!3558 = !DILocalVariable(name: "w", scope: !255, file: !3, line: 2373, type: !6)
!3559 = !DILocation(line: 2373, column: 25, scope: !255)
!3560 = !DILocalVariable(name: "sign", scope: !255, file: !3, line: 2374, type: !9)
!3561 = !DILocation(line: 2374, column: 12, scope: !255)
!3562 = !DILocalVariable(name: "high", scope: !255, file: !3, line: 2375, type: !9)
!3563 = !DILocation(line: 2375, column: 12, scope: !255)
!3564 = !DILocalVariable(name: "low", scope: !255, file: !3, line: 2375, type: !9)
!3565 = !DILocation(line: 2375, column: 18, scope: !255)
!3566 = !DILocation(line: 2377, column: 3, scope: !255)
!3567 = !DILocalVariable(name: "bits", scope: !3568, file: !3, line: 2377, type: !16)
!3568 = distinct !DILexicalBlock(scope: !255, file: !3, line: 2377, column: 3)
!3569 = !DILocation(line: 2377, column: 3, scope: !3568)
!3570 = !DILocation(line: 2378, column: 10, scope: !255)
!3571 = !DILocation(line: 2378, column: 13, scope: !255)
!3572 = !DILocation(line: 2378, column: 8, scope: !255)
!3573 = !DILocation(line: 2379, column: 9, scope: !255)
!3574 = !DILocation(line: 2379, column: 6, scope: !255)
!3575 = !DILocation(line: 2380, column: 7, scope: !3576)
!3576 = distinct !DILexicalBlock(scope: !255, file: !3, line: 2380, column: 7)
!3577 = !DILocation(line: 2380, column: 10, scope: !3576)
!3578 = !DILocation(line: 2380, column: 7, scope: !255)
!3579 = !DILocation(line: 2380, column: 33, scope: !3576)
!3580 = !DILocation(line: 2380, column: 37, scope: !3576)
!3581 = !DILocation(line: 2380, column: 35, scope: !3576)
!3582 = !DILocation(line: 2380, column: 25, scope: !3576)
!3583 = !DILocation(line: 2397, column: 7, scope: !3584)
!3584 = distinct !DILexicalBlock(scope: !255, file: !3, line: 2397, column: 7)
!3585 = !DILocation(line: 2397, column: 10, scope: !3584)
!3586 = !DILocation(line: 2397, column: 7, scope: !255)
!3587 = !DILocation(line: 2398, column: 10, scope: !3588)
!3588 = distinct !DILexicalBlock(scope: !3589, file: !3, line: 2398, column: 9)
!3589 = distinct !DILexicalBlock(scope: !3584, file: !3, line: 2397, column: 24)
!3590 = !DILocation(line: 2398, column: 15, scope: !3588)
!3591 = !DILocation(line: 2398, column: 13, scope: !3588)
!3592 = !DILocation(line: 2398, column: 20, scope: !3588)
!3593 = !DILocation(line: 2398, column: 9, scope: !3589)
!3594 = !DILocation(line: 2398, column: 34, scope: !3588)
!3595 = !DILocation(line: 2398, column: 26, scope: !3588)
!3596 = !DILocation(line: 2399, column: 5, scope: !3589)
!3597 = !DILocalVariable(name: "bits", scope: !3598, file: !3, line: 2399, type: !16)
!3598 = distinct !DILexicalBlock(scope: !3589, file: !3, line: 2399, column: 5)
!3599 = !DILocation(line: 2399, column: 5, scope: !3598)
!3600 = !DILocation(line: 2400, column: 10, scope: !3589)
!3601 = !DILocation(line: 2400, column: 7, scope: !3589)
!3602 = !DILocation(line: 2401, column: 5, scope: !3589)
!3603 = !DILocalVariable(name: "bits", scope: !3604, file: !3, line: 2401, type: !16)
!3604 = distinct !DILexicalBlock(scope: !3589, file: !3, line: 2401, column: 5)
!3605 = !DILocation(line: 2401, column: 5, scope: !3604)
!3606 = !DILocation(line: 2402, column: 5, scope: !3589)
!3607 = !DILocalVariable(name: "bits", scope: !3608, file: !3, line: 2402, type: !16)
!3608 = distinct !DILexicalBlock(scope: !3589, file: !3, line: 2402, column: 5)
!3609 = !DILocation(line: 2402, column: 5, scope: !3608)
!3610 = !DILocation(line: 2403, column: 3, scope: !3589)
!3611 = !DILocation(line: 2404, column: 5, scope: !3612)
!3612 = distinct !DILexicalBlock(scope: !3584, file: !3, line: 2403, column: 10)
!3613 = !DILocalVariable(name: "bits", scope: !3614, file: !3, line: 2404, type: !16)
!3614 = distinct !DILexicalBlock(scope: !3612, file: !3, line: 2404, column: 5)
!3615 = !DILocation(line: 2404, column: 5, scope: !3614)
!3616 = !DILocation(line: 2417, column: 8, scope: !255)
!3617 = !DILocation(line: 2417, column: 12, scope: !255)
!3618 = !DILocation(line: 2417, column: 10, scope: !255)
!3619 = !DILocation(line: 2417, column: 18, scope: !255)
!3620 = !DILocation(line: 2417, column: 22, scope: !255)
!3621 = !DILocation(line: 2417, column: 20, scope: !255)
!3622 = !DILocation(line: 2417, column: 15, scope: !255)
!3623 = !DILocation(line: 2417, column: 5, scope: !255)
!3624 = !DILocation(line: 2418, column: 7, scope: !255)
!3625 = !DILocation(line: 2418, column: 18, scope: !255)
!3626 = !DILocation(line: 2418, column: 28, scope: !255)
!3627 = !DILocation(line: 2418, column: 26, scope: !255)
!3628 = !DILocation(line: 2418, column: 16, scope: !255)
!3629 = !DILocation(line: 2418, column: 41, scope: !255)
!3630 = !DILocation(line: 2418, column: 45, scope: !255)
!3631 = !DILocation(line: 2418, column: 43, scope: !255)
!3632 = !DILocation(line: 2418, column: 50, scope: !255)
!3633 = !DILocation(line: 2418, column: 48, scope: !255)
!3634 = !DILocation(line: 2418, column: 61, scope: !255)
!3635 = !DILocation(line: 2418, column: 59, scope: !255)
!3636 = !DILocation(line: 2418, column: 37, scope: !255)
!3637 = !DILocation(line: 2418, column: 9, scope: !255)
!3638 = !DILocation(line: 2418, column: 5, scope: !255)
!3639 = !DILocalVariable(name: "bits", scope: !255, file: !3, line: 2430, type: !16)
!3640 = !DILocation(line: 2430, column: 12, scope: !255)
!3641 = !DILocation(line: 2430, column: 27, scope: !255)
!3642 = !DILocation(line: 2430, column: 19, scope: !255)
!3643 = !DILocation(line: 2431, column: 11, scope: !255)
!3644 = !DILocation(line: 2431, column: 16, scope: !255)
!3645 = !DILocation(line: 2431, column: 30, scope: !255)
!3646 = !DILocation(line: 2431, column: 8, scope: !255)
!3647 = !DILocation(line: 2432, column: 17, scope: !255)
!3648 = !DILocation(line: 2432, column: 7, scope: !255)
!3649 = !DILocation(line: 2432, column: 5, scope: !255)
!3650 = !DILocation(line: 2435, column: 7, scope: !255)
!3651 = !DILocation(line: 2435, column: 11, scope: !255)
!3652 = !DILocation(line: 2435, column: 9, scope: !255)
!3653 = !DILocation(line: 2435, column: 5, scope: !255)
!3654 = !DILocation(line: 2436, column: 7, scope: !255)
!3655 = !DILocation(line: 2436, column: 11, scope: !255)
!3656 = !DILocation(line: 2436, column: 9, scope: !255)
!3657 = !DILocation(line: 2436, column: 5, scope: !255)
!3658 = !DILocation(line: 2437, column: 7, scope: !255)
!3659 = !DILocation(line: 2437, column: 11, scope: !255)
!3660 = !DILocation(line: 2437, column: 9, scope: !255)
!3661 = !DILocation(line: 2437, column: 5, scope: !255)
!3662 = !DILocation(line: 2438, column: 8, scope: !255)
!3663 = !DILocation(line: 2438, column: 12, scope: !255)
!3664 = !DILocation(line: 2438, column: 10, scope: !255)
!3665 = !DILocation(line: 2438, column: 18, scope: !255)
!3666 = !DILocation(line: 2438, column: 22, scope: !255)
!3667 = !DILocation(line: 2438, column: 20, scope: !255)
!3668 = !DILocation(line: 2438, column: 15, scope: !255)
!3669 = !DILocation(line: 2438, column: 5, scope: !255)
!3670 = !DILocation(line: 2439, column: 7, scope: !255)
!3671 = !DILocation(line: 2439, column: 11, scope: !255)
!3672 = !DILocation(line: 2439, column: 15, scope: !255)
!3673 = !DILocation(line: 2439, column: 9, scope: !255)
!3674 = !DILocation(line: 2439, column: 5, scope: !255)
!3675 = !DILocation(line: 2441, column: 11, scope: !255)
!3676 = !DILocation(line: 2441, column: 3, scope: !255)
!3677 = !DILocation(line: 2442, column: 1, scope: !255)
!3678 = distinct !DISubprogram(name: "pts_ieee754_sin", scope: !3, file: !3, line: 2474, type: !4, scopeLine: 2474, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!3679 = !DILocalVariable(name: "x", arg: 1, scope: !3678, file: !3, line: 2474, type: !6)
!3680 = !DILocation(line: 2474, column: 31, scope: !3678)
!3681 = !DILocalVariable(name: "y", scope: !3678, file: !3, line: 2475, type: !1981)
!3682 = !DILocation(line: 2475, column: 10, scope: !3678)
!3683 = !DILocalVariable(name: "z", scope: !3678, file: !3, line: 2475, type: !6)
!3684 = !DILocation(line: 2475, column: 16, scope: !3678)
!3685 = !DILocalVariable(name: "n", scope: !3678, file: !3, line: 2476, type: !18)
!3686 = !DILocation(line: 2476, column: 11, scope: !3678)
!3687 = !DILocalVariable(name: "ix", scope: !3678, file: !3, line: 2476, type: !18)
!3688 = !DILocation(line: 2476, column: 14, scope: !3678)
!3689 = !DILocation(line: 2479, column: 3, scope: !3678)
!3690 = !DILocalVariable(name: "bits", scope: !3691, file: !3, line: 2479, type: !16)
!3691 = distinct !DILexicalBlock(scope: !3678, file: !3, line: 2479, column: 3)
!3692 = !DILocation(line: 2479, column: 3, scope: !3691)
!3693 = !DILocation(line: 2482, column: 6, scope: !3678)
!3694 = !DILocation(line: 2483, column: 7, scope: !3695)
!3695 = distinct !DILexicalBlock(scope: !3678, file: !3, line: 2483, column: 7)
!3696 = !DILocation(line: 2483, column: 10, scope: !3695)
!3697 = !DILocation(line: 2483, column: 7, scope: !3678)
!3698 = !DILocation(line: 2484, column: 25, scope: !3699)
!3699 = distinct !DILexicalBlock(scope: !3695, file: !3, line: 2483, column: 25)
!3700 = !DILocation(line: 2484, column: 28, scope: !3699)
!3701 = !DILocation(line: 2484, column: 12, scope: !3699)
!3702 = !DILocation(line: 2484, column: 5, scope: !3699)
!3703 = !DILocation(line: 2485, column: 14, scope: !3704)
!3704 = distinct !DILexicalBlock(scope: !3695, file: !3, line: 2485, column: 14)
!3705 = !DILocation(line: 2485, column: 17, scope: !3704)
!3706 = !DILocation(line: 2485, column: 14, scope: !3695)
!3707 = !DILocation(line: 2487, column: 12, scope: !3708)
!3708 = distinct !DILexicalBlock(scope: !3704, file: !3, line: 2485, column: 32)
!3709 = !DILocation(line: 2487, column: 16, scope: !3708)
!3710 = !DILocation(line: 2487, column: 14, scope: !3708)
!3711 = !DILocation(line: 2487, column: 5, scope: !3708)
!3712 = !DILocation(line: 2490, column: 28, scope: !3713)
!3713 = distinct !DILexicalBlock(scope: !3704, file: !3, line: 2488, column: 10)
!3714 = !DILocation(line: 2490, column: 31, scope: !3713)
!3715 = !DILocation(line: 2490, column: 9, scope: !3713)
!3716 = !DILocation(line: 2490, column: 7, scope: !3713)
!3717 = !DILocation(line: 2491, column: 13, scope: !3713)
!3718 = !DILocation(line: 2491, column: 15, scope: !3713)
!3719 = !DILocation(line: 2491, column: 5, scope: !3713)
!3720 = !DILocation(line: 2493, column: 29, scope: !3721)
!3721 = distinct !DILexicalBlock(scope: !3713, file: !3, line: 2491, column: 20)
!3722 = !DILocation(line: 2493, column: 35, scope: !3721)
!3723 = !DILocation(line: 2493, column: 16, scope: !3721)
!3724 = !DILocation(line: 2493, column: 9, scope: !3721)
!3725 = !DILocation(line: 2495, column: 29, scope: !3721)
!3726 = !DILocation(line: 2495, column: 35, scope: !3721)
!3727 = !DILocation(line: 2495, column: 16, scope: !3721)
!3728 = !DILocation(line: 2495, column: 9, scope: !3721)
!3729 = !DILocation(line: 2497, column: 30, scope: !3721)
!3730 = !DILocation(line: 2497, column: 36, scope: !3721)
!3731 = !DILocation(line: 2497, column: 17, scope: !3721)
!3732 = !DILocation(line: 2497, column: 16, scope: !3721)
!3733 = !DILocation(line: 2497, column: 9, scope: !3721)
!3734 = !DILocation(line: 2499, column: 30, scope: !3721)
!3735 = !DILocation(line: 2499, column: 36, scope: !3721)
!3736 = !DILocation(line: 2499, column: 17, scope: !3721)
!3737 = !DILocation(line: 2499, column: 16, scope: !3721)
!3738 = !DILocation(line: 2499, column: 9, scope: !3721)
!3739 = !DILocation(line: 2502, column: 1, scope: !3678)
!3740 = distinct !DISubprogram(name: "pts_ieee754_tan", scope: !3, file: !3, line: 2533, type: !4, scopeLine: 2533, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !7, retainedNodes: !50)
!3741 = !DILocalVariable(name: "x", arg: 1, scope: !3740, file: !3, line: 2533, type: !6)
!3742 = !DILocation(line: 2533, column: 31, scope: !3740)
!3743 = !DILocalVariable(name: "y", scope: !3740, file: !3, line: 2534, type: !1981)
!3744 = !DILocation(line: 2534, column: 10, scope: !3740)
!3745 = !DILocalVariable(name: "z", scope: !3740, file: !3, line: 2534, type: !6)
!3746 = !DILocation(line: 2534, column: 16, scope: !3740)
!3747 = !DILocalVariable(name: "n", scope: !3740, file: !3, line: 2535, type: !18)
!3748 = !DILocation(line: 2535, column: 11, scope: !3740)
!3749 = !DILocalVariable(name: "ix", scope: !3740, file: !3, line: 2535, type: !18)
!3750 = !DILocation(line: 2535, column: 14, scope: !3740)
!3751 = !DILocation(line: 2538, column: 3, scope: !3740)
!3752 = !DILocalVariable(name: "bits", scope: !3753, file: !3, line: 2538, type: !16)
!3753 = distinct !DILexicalBlock(scope: !3740, file: !3, line: 2538, column: 3)
!3754 = !DILocation(line: 2538, column: 3, scope: !3753)
!3755 = !DILocation(line: 2541, column: 6, scope: !3740)
!3756 = !DILocation(line: 2542, column: 7, scope: !3757)
!3757 = distinct !DILexicalBlock(scope: !3740, file: !3, line: 2542, column: 7)
!3758 = !DILocation(line: 2542, column: 10, scope: !3757)
!3759 = !DILocation(line: 2542, column: 7, scope: !3740)
!3760 = !DILocation(line: 2543, column: 25, scope: !3761)
!3761 = distinct !DILexicalBlock(scope: !3757, file: !3, line: 2542, column: 25)
!3762 = !DILocation(line: 2543, column: 28, scope: !3761)
!3763 = !DILocation(line: 2543, column: 12, scope: !3761)
!3764 = !DILocation(line: 2543, column: 5, scope: !3761)
!3765 = !DILocation(line: 2544, column: 14, scope: !3766)
!3766 = distinct !DILexicalBlock(scope: !3757, file: !3, line: 2544, column: 14)
!3767 = !DILocation(line: 2544, column: 17, scope: !3766)
!3768 = !DILocation(line: 2544, column: 14, scope: !3757)
!3769 = !DILocation(line: 2546, column: 12, scope: !3770)
!3770 = distinct !DILexicalBlock(scope: !3766, file: !3, line: 2544, column: 32)
!3771 = !DILocation(line: 2546, column: 16, scope: !3770)
!3772 = !DILocation(line: 2546, column: 14, scope: !3770)
!3773 = !DILocation(line: 2546, column: 5, scope: !3770)
!3774 = !DILocation(line: 2549, column: 28, scope: !3775)
!3775 = distinct !DILexicalBlock(scope: !3766, file: !3, line: 2547, column: 10)
!3776 = !DILocation(line: 2549, column: 31, scope: !3775)
!3777 = !DILocation(line: 2549, column: 9, scope: !3775)
!3778 = !DILocation(line: 2549, column: 7, scope: !3775)
!3779 = !DILocation(line: 2551, column: 25, scope: !3775)
!3780 = !DILocation(line: 2551, column: 31, scope: !3775)
!3781 = !DILocation(line: 2551, column: 43, scope: !3775)
!3782 = !DILocation(line: 2551, column: 45, scope: !3775)
!3783 = !DILocation(line: 2551, column: 50, scope: !3775)
!3784 = !DILocation(line: 2551, column: 39, scope: !3775)
!3785 = !DILocation(line: 2551, column: 12, scope: !3775)
!3786 = !DILocation(line: 2551, column: 5, scope: !3775)
!3787 = !DILocation(line: 2553, column: 1, scope: !3740)
!3788 = !DILocalVariable(name: "x", arg: 1, scope: !400, file: !3, line: 764, type: !6)
!3789 = !DILocation(line: 764, column: 35, scope: !400)
!3790 = !DILocalVariable(name: "y", arg: 2, scope: !400, file: !3, line: 764, type: !6)
!3791 = !DILocation(line: 764, column: 45, scope: !400)
!3792 = !DILocalVariable(name: "iy", arg: 3, scope: !400, file: !3, line: 764, type: !15)
!3793 = !DILocation(line: 764, column: 52, scope: !400)
!3794 = !DILocalVariable(name: "z", scope: !400, file: !3, line: 788, type: !6)
!3795 = !DILocation(line: 788, column: 10, scope: !400)
!3796 = !DILocalVariable(name: "r", scope: !400, file: !3, line: 788, type: !6)
!3797 = !DILocation(line: 788, column: 13, scope: !400)
!3798 = !DILocalVariable(name: "v", scope: !400, file: !3, line: 788, type: !6)
!3799 = !DILocation(line: 788, column: 16, scope: !400)
!3800 = !DILocalVariable(name: "w", scope: !400, file: !3, line: 788, type: !6)
!3801 = !DILocation(line: 788, column: 19, scope: !400)
!3802 = !DILocalVariable(name: "s", scope: !400, file: !3, line: 788, type: !6)
!3803 = !DILocation(line: 788, column: 22, scope: !400)
!3804 = !DILocalVariable(name: "ix", scope: !400, file: !3, line: 789, type: !18)
!3805 = !DILocation(line: 789, column: 11, scope: !400)
!3806 = !DILocalVariable(name: "hx", scope: !400, file: !3, line: 789, type: !18)
!3807 = !DILocation(line: 789, column: 15, scope: !400)
!3808 = !DILocation(line: 791, column: 3, scope: !400)
!3809 = !DILocalVariable(name: "bits", scope: !3810, file: !3, line: 791, type: !16)
!3810 = distinct !DILexicalBlock(scope: !400, file: !3, line: 791, column: 3)
!3811 = !DILocation(line: 791, column: 3, scope: !3810)
!3812 = !DILocation(line: 792, column: 8, scope: !400)
!3813 = !DILocation(line: 792, column: 11, scope: !400)
!3814 = !DILocation(line: 792, column: 6, scope: !400)
!3815 = !DILocation(line: 793, column: 7, scope: !3816)
!3816 = distinct !DILexicalBlock(scope: !400, file: !3, line: 793, column: 7)
!3817 = !DILocation(line: 793, column: 10, scope: !3816)
!3818 = !DILocation(line: 793, column: 7, scope: !400)
!3819 = !DILocation(line: 794, column: 15, scope: !3820)
!3820 = distinct !DILexicalBlock(scope: !3821, file: !3, line: 794, column: 9)
!3821 = distinct !DILexicalBlock(scope: !3816, file: !3, line: 793, column: 24)
!3822 = !DILocation(line: 794, column: 9, scope: !3820)
!3823 = !DILocation(line: 794, column: 18, scope: !3820)
!3824 = !DILocation(line: 794, column: 9, scope: !3821)
!3825 = !DILocalVariable(name: "low", scope: !3826, file: !3, line: 795, type: !9)
!3826 = distinct !DILexicalBlock(scope: !3820, file: !3, line: 794, column: 24)
!3827 = !DILocation(line: 795, column: 16, scope: !3826)
!3828 = !DILocation(line: 796, column: 7, scope: !3826)
!3829 = !DILocalVariable(name: "bits", scope: !3830, file: !3, line: 796, type: !16)
!3830 = distinct !DILexicalBlock(scope: !3826, file: !3, line: 796, column: 7)
!3831 = !DILocation(line: 796, column: 7, scope: !3830)
!3832 = !DILocation(line: 797, column: 13, scope: !3833)
!3833 = distinct !DILexicalBlock(scope: !3826, file: !3, line: 797, column: 11)
!3834 = !DILocation(line: 797, column: 18, scope: !3833)
!3835 = !DILocation(line: 797, column: 16, scope: !3833)
!3836 = !DILocation(line: 797, column: 26, scope: !3833)
!3837 = !DILocation(line: 797, column: 29, scope: !3833)
!3838 = !DILocation(line: 797, column: 23, scope: !3833)
!3839 = !DILocation(line: 797, column: 35, scope: !3833)
!3840 = !DILocation(line: 797, column: 11, scope: !3826)
!3841 = !DILocation(line: 798, column: 16, scope: !3842)
!3842 = distinct !DILexicalBlock(scope: !3833, file: !3, line: 797, column: 41)
!3843 = !DILocation(line: 798, column: 27, scope: !3842)
!3844 = !DILocation(line: 798, column: 22, scope: !3842)
!3845 = !DILocation(line: 798, column: 20, scope: !3842)
!3846 = !DILocation(line: 798, column: 9, scope: !3842)
!3847 = !DILocation(line: 800, column: 13, scope: !3848)
!3848 = distinct !DILexicalBlock(scope: !3849, file: !3, line: 800, column: 13)
!3849 = distinct !DILexicalBlock(scope: !3833, file: !3, line: 799, column: 14)
!3850 = !DILocation(line: 800, column: 16, scope: !3848)
!3851 = !DILocation(line: 800, column: 13, scope: !3849)
!3852 = !DILocation(line: 801, column: 18, scope: !3853)
!3853 = distinct !DILexicalBlock(scope: !3848, file: !3, line: 800, column: 22)
!3854 = !DILocation(line: 801, column: 11, scope: !3853)
!3855 = !DILocalVariable(name: "a", scope: !3856, file: !3, line: 803, type: !6)
!3856 = distinct !DILexicalBlock(scope: !3848, file: !3, line: 802, column: 16)
!3857 = !DILocation(line: 803, column: 18, scope: !3856)
!3858 = !DILocalVariable(name: "t", scope: !3856, file: !3, line: 803, type: !6)
!3859 = !DILocation(line: 803, column: 21, scope: !3856)
!3860 = !DILocation(line: 805, column: 19, scope: !3856)
!3861 = !DILocation(line: 805, column: 23, scope: !3856)
!3862 = !DILocation(line: 805, column: 21, scope: !3856)
!3863 = !DILocation(line: 805, column: 17, scope: !3856)
!3864 = !DILocation(line: 805, column: 13, scope: !3856)
!3865 = !DILocation(line: 806, column: 11, scope: !3856)
!3866 = !DILocalVariable(name: "bits", scope: !3867, file: !3, line: 806, type: !16)
!3867 = distinct !DILexicalBlock(scope: !3856, file: !3, line: 806, column: 11)
!3868 = !DILocation(line: 806, column: 11, scope: !3867)
!3869 = !DILocation(line: 807, column: 15, scope: !3856)
!3870 = !DILocation(line: 807, column: 20, scope: !3856)
!3871 = !DILocation(line: 807, column: 24, scope: !3856)
!3872 = !DILocation(line: 807, column: 22, scope: !3856)
!3873 = !DILocation(line: 807, column: 17, scope: !3856)
!3874 = !DILocation(line: 807, column: 13, scope: !3856)
!3875 = !DILocation(line: 808, column: 20, scope: !3856)
!3876 = !DILocation(line: 808, column: 19, scope: !3856)
!3877 = !DILocation(line: 808, column: 26, scope: !3856)
!3878 = !DILocation(line: 808, column: 24, scope: !3856)
!3879 = !DILocation(line: 808, column: 17, scope: !3856)
!3880 = !DILocation(line: 808, column: 13, scope: !3856)
!3881 = !DILocation(line: 809, column: 11, scope: !3856)
!3882 = !DILocalVariable(name: "bits", scope: !3883, file: !3, line: 809, type: !16)
!3883 = distinct !DILexicalBlock(scope: !3856, file: !3, line: 809, column: 11)
!3884 = !DILocation(line: 809, column: 11, scope: !3883)
!3885 = !DILocation(line: 810, column: 15, scope: !3856)
!3886 = !DILocation(line: 810, column: 21, scope: !3856)
!3887 = !DILocation(line: 810, column: 25, scope: !3856)
!3888 = !DILocation(line: 810, column: 19, scope: !3856)
!3889 = !DILocation(line: 810, column: 13, scope: !3856)
!3890 = !DILocation(line: 811, column: 18, scope: !3856)
!3891 = !DILocation(line: 811, column: 22, scope: !3856)
!3892 = !DILocation(line: 811, column: 27, scope: !3856)
!3893 = !DILocation(line: 811, column: 31, scope: !3856)
!3894 = !DILocation(line: 811, column: 35, scope: !3856)
!3895 = !DILocation(line: 811, column: 29, scope: !3856)
!3896 = !DILocation(line: 811, column: 20, scope: !3856)
!3897 = !DILocation(line: 811, column: 11, scope: !3856)
!3898 = !DILocation(line: 815, column: 3, scope: !3821)
!3899 = !DILocation(line: 816, column: 7, scope: !3900)
!3900 = distinct !DILexicalBlock(scope: !400, file: !3, line: 816, column: 7)
!3901 = !DILocation(line: 816, column: 10, scope: !3900)
!3902 = !DILocation(line: 816, column: 7, scope: !400)
!3903 = !DILocation(line: 817, column: 9, scope: !3904)
!3904 = distinct !DILexicalBlock(scope: !3905, file: !3, line: 817, column: 9)
!3905 = distinct !DILexicalBlock(scope: !3900, file: !3, line: 816, column: 25)
!3906 = !DILocation(line: 817, column: 12, scope: !3904)
!3907 = !DILocation(line: 817, column: 9, scope: !3905)
!3908 = !DILocation(line: 818, column: 12, scope: !3909)
!3909 = distinct !DILexicalBlock(scope: !3904, file: !3, line: 817, column: 17)
!3910 = !DILocation(line: 818, column: 11, scope: !3909)
!3911 = !DILocation(line: 818, column: 9, scope: !3909)
!3912 = !DILocation(line: 819, column: 12, scope: !3909)
!3913 = !DILocation(line: 819, column: 11, scope: !3909)
!3914 = !DILocation(line: 819, column: 9, scope: !3909)
!3915 = !DILocation(line: 820, column: 5, scope: !3909)
!3916 = !DILocation(line: 821, column: 9, scope: !3905)
!3917 = !DILocation(line: 821, column: 16, scope: !3905)
!3918 = !DILocation(line: 821, column: 14, scope: !3905)
!3919 = !DILocation(line: 821, column: 7, scope: !3905)
!3920 = !DILocation(line: 822, column: 9, scope: !3905)
!3921 = !DILocation(line: 822, column: 18, scope: !3905)
!3922 = !DILocation(line: 822, column: 16, scope: !3905)
!3923 = !DILocation(line: 822, column: 7, scope: !3905)
!3924 = !DILocation(line: 823, column: 9, scope: !3905)
!3925 = !DILocation(line: 823, column: 13, scope: !3905)
!3926 = !DILocation(line: 823, column: 11, scope: !3905)
!3927 = !DILocation(line: 823, column: 7, scope: !3905)
!3928 = !DILocation(line: 824, column: 7, scope: !3905)
!3929 = !DILocation(line: 825, column: 3, scope: !3905)
!3930 = !DILocation(line: 826, column: 7, scope: !400)
!3931 = !DILocation(line: 826, column: 11, scope: !400)
!3932 = !DILocation(line: 826, column: 9, scope: !400)
!3933 = !DILocation(line: 826, column: 5, scope: !400)
!3934 = !DILocation(line: 827, column: 7, scope: !400)
!3935 = !DILocation(line: 827, column: 11, scope: !400)
!3936 = !DILocation(line: 827, column: 9, scope: !400)
!3937 = !DILocation(line: 827, column: 5, scope: !400)
!3938 = !DILocation(line: 833, column: 7, scope: !400)
!3939 = !DILocation(line: 833, column: 14, scope: !400)
!3940 = !DILocation(line: 833, column: 19, scope: !400)
!3941 = !DILocation(line: 833, column: 26, scope: !400)
!3942 = !DILocation(line: 833, column: 31, scope: !400)
!3943 = !DILocation(line: 833, column: 38, scope: !400)
!3944 = !DILocation(line: 833, column: 43, scope: !400)
!3945 = !DILocation(line: 833, column: 50, scope: !400)
!3946 = !DILocation(line: 833, column: 55, scope: !400)
!3947 = !DILocation(line: 833, column: 62, scope: !400)
!3948 = !DILocation(line: 833, column: 66, scope: !400)
!3949 = !DILocation(line: 833, column: 60, scope: !400)
!3950 = !DILocation(line: 833, column: 48, scope: !400)
!3951 = !DILocation(line: 833, column: 36, scope: !400)
!3952 = !DILocation(line: 833, column: 24, scope: !400)
!3953 = !DILocation(line: 833, column: 12, scope: !400)
!3954 = !DILocation(line: 833, column: 5, scope: !400)
!3955 = !DILocation(line: 834, column: 7, scope: !400)
!3956 = !DILocation(line: 835, column: 8, scope: !400)
!3957 = !DILocation(line: 835, column: 15, scope: !400)
!3958 = !DILocation(line: 835, column: 20, scope: !400)
!3959 = !DILocation(line: 835, column: 27, scope: !400)
!3960 = !DILocation(line: 835, column: 32, scope: !400)
!3961 = !DILocation(line: 835, column: 39, scope: !400)
!3962 = !DILocation(line: 835, column: 44, scope: !400)
!3963 = !DILocation(line: 835, column: 51, scope: !400)
!3964 = !DILocation(line: 835, column: 56, scope: !400)
!3965 = !DILocation(line: 835, column: 64, scope: !400)
!3966 = !DILocation(line: 835, column: 68, scope: !400)
!3967 = !DILocation(line: 835, column: 62, scope: !400)
!3968 = !DILocation(line: 835, column: 49, scope: !400)
!3969 = !DILocation(line: 835, column: 37, scope: !400)
!3970 = !DILocation(line: 835, column: 25, scope: !400)
!3971 = !DILocation(line: 835, column: 13, scope: !400)
!3972 = !DILocation(line: 834, column: 9, scope: !400)
!3973 = !DILocation(line: 834, column: 5, scope: !400)
!3974 = !DILocation(line: 836, column: 7, scope: !400)
!3975 = !DILocation(line: 836, column: 11, scope: !400)
!3976 = !DILocation(line: 836, column: 9, scope: !400)
!3977 = !DILocation(line: 836, column: 5, scope: !400)
!3978 = !DILocation(line: 837, column: 7, scope: !400)
!3979 = !DILocation(line: 837, column: 11, scope: !400)
!3980 = !DILocation(line: 837, column: 16, scope: !400)
!3981 = !DILocation(line: 837, column: 21, scope: !400)
!3982 = !DILocation(line: 837, column: 25, scope: !400)
!3983 = !DILocation(line: 837, column: 23, scope: !400)
!3984 = !DILocation(line: 837, column: 30, scope: !400)
!3985 = !DILocation(line: 837, column: 28, scope: !400)
!3986 = !DILocation(line: 837, column: 9, scope: !400)
!3987 = !DILocation(line: 837, column: 5, scope: !400)
!3988 = !DILocation(line: 838, column: 8, scope: !400)
!3989 = !DILocation(line: 838, column: 15, scope: !400)
!3990 = !DILocation(line: 838, column: 5, scope: !400)
!3991 = !DILocation(line: 839, column: 7, scope: !400)
!3992 = !DILocation(line: 839, column: 11, scope: !400)
!3993 = !DILocation(line: 839, column: 9, scope: !400)
!3994 = !DILocation(line: 839, column: 5, scope: !400)
!3995 = !DILocation(line: 840, column: 7, scope: !3996)
!3996 = distinct !DILexicalBlock(scope: !400, file: !3, line: 840, column: 7)
!3997 = !DILocation(line: 840, column: 10, scope: !3996)
!3998 = !DILocation(line: 840, column: 7, scope: !400)
!3999 = !DILocation(line: 841, column: 9, scope: !4000)
!4000 = distinct !DILexicalBlock(scope: !3996, file: !3, line: 840, column: 25)
!4001 = !DILocation(line: 841, column: 7, scope: !4000)
!4002 = !DILocation(line: 842, column: 19, scope: !4000)
!4003 = !DILocation(line: 842, column: 22, scope: !4000)
!4004 = !DILocation(line: 842, column: 29, scope: !4000)
!4005 = !DILocation(line: 842, column: 15, scope: !4000)
!4006 = !DILocation(line: 842, column: 12, scope: !4000)
!4007 = !DILocation(line: 842, column: 38, scope: !4000)
!4008 = !DILocation(line: 842, column: 49, scope: !4000)
!4009 = !DILocation(line: 842, column: 54, scope: !4000)
!4010 = !DILocation(line: 842, column: 58, scope: !4000)
!4011 = !DILocation(line: 842, column: 56, scope: !4000)
!4012 = !DILocation(line: 842, column: 63, scope: !4000)
!4013 = !DILocation(line: 842, column: 67, scope: !4000)
!4014 = !DILocation(line: 842, column: 65, scope: !4000)
!4015 = !DILocation(line: 842, column: 60, scope: !4000)
!4016 = !DILocation(line: 842, column: 72, scope: !4000)
!4017 = !DILocation(line: 842, column: 70, scope: !4000)
!4018 = !DILocation(line: 842, column: 51, scope: !4000)
!4019 = !DILocation(line: 842, column: 40, scope: !4000)
!4020 = !DILocation(line: 842, column: 35, scope: !4000)
!4021 = !DILocation(line: 842, column: 5, scope: !4000)
!4022 = !DILocation(line: 844, column: 7, scope: !4023)
!4023 = distinct !DILexicalBlock(scope: !400, file: !3, line: 844, column: 7)
!4024 = !DILocation(line: 844, column: 10, scope: !4023)
!4025 = !DILocation(line: 844, column: 7, scope: !400)
!4026 = !DILocation(line: 845, column: 12, scope: !4027)
!4027 = distinct !DILexicalBlock(scope: !4023, file: !3, line: 844, column: 16)
!4028 = !DILocation(line: 845, column: 5, scope: !4027)
!4029 = !DILocalVariable(name: "a", scope: !4030, file: !3, line: 852, type: !6)
!4030 = distinct !DILexicalBlock(scope: !4023, file: !3, line: 846, column: 10)
!4031 = !DILocation(line: 852, column: 12, scope: !4030)
!4032 = !DILocalVariable(name: "t", scope: !4030, file: !3, line: 852, type: !6)
!4033 = !DILocation(line: 852, column: 15, scope: !4030)
!4034 = !DILocation(line: 853, column: 9, scope: !4030)
!4035 = !DILocation(line: 853, column: 7, scope: !4030)
!4036 = !DILocation(line: 854, column: 5, scope: !4030)
!4037 = !DILocalVariable(name: "bits", scope: !4038, file: !3, line: 854, type: !16)
!4038 = distinct !DILexicalBlock(scope: !4030, file: !3, line: 854, column: 5)
!4039 = !DILocation(line: 854, column: 5, scope: !4038)
!4040 = !DILocation(line: 855, column: 9, scope: !4030)
!4041 = !DILocation(line: 855, column: 14, scope: !4030)
!4042 = !DILocation(line: 855, column: 18, scope: !4030)
!4043 = !DILocation(line: 855, column: 16, scope: !4030)
!4044 = !DILocation(line: 855, column: 11, scope: !4030)
!4045 = !DILocation(line: 855, column: 7, scope: !4030)
!4046 = !DILocation(line: 856, column: 20, scope: !4030)
!4047 = !DILocation(line: 856, column: 18, scope: !4030)
!4048 = !DILocation(line: 856, column: 11, scope: !4030)
!4049 = !DILocation(line: 856, column: 7, scope: !4030)
!4050 = !DILocation(line: 857, column: 5, scope: !4030)
!4051 = !DILocalVariable(name: "bits", scope: !4052, file: !3, line: 857, type: !16)
!4052 = distinct !DILexicalBlock(scope: !4030, file: !3, line: 857, column: 5)
!4053 = !DILocation(line: 857, column: 5, scope: !4052)
!4054 = !DILocation(line: 858, column: 15, scope: !4030)
!4055 = !DILocation(line: 858, column: 19, scope: !4030)
!4056 = !DILocation(line: 858, column: 13, scope: !4030)
!4057 = !DILocation(line: 858, column: 7, scope: !4030)
!4058 = !DILocation(line: 859, column: 12, scope: !4030)
!4059 = !DILocation(line: 859, column: 16, scope: !4030)
!4060 = !DILocation(line: 859, column: 21, scope: !4030)
!4061 = !DILocation(line: 859, column: 25, scope: !4030)
!4062 = !DILocation(line: 859, column: 29, scope: !4030)
!4063 = !DILocation(line: 859, column: 23, scope: !4030)
!4064 = !DILocation(line: 859, column: 14, scope: !4030)
!4065 = !DILocation(line: 859, column: 5, scope: !4030)
!4066 = !DILocation(line: 866, column: 1, scope: !400)
!4067 = !DILocalVariable(name: "x", arg: 1, scope: !271, file: !3, line: 2577, type: !6)
!4068 = !DILocation(line: 2577, column: 32, scope: !271)
!4069 = !DILocalVariable(name: "ix", scope: !271, file: !3, line: 2582, type: !18)
!4070 = !DILocation(line: 2582, column: 11, scope: !271)
!4071 = !DILocation(line: 2585, column: 3, scope: !271)
!4072 = !DILocalVariable(name: "bits", scope: !4073, file: !3, line: 2585, type: !16)
!4073 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2585, column: 3)
!4074 = !DILocation(line: 2585, column: 3, scope: !4073)
!4075 = !DILocation(line: 2586, column: 6, scope: !271)
!4076 = !DILocation(line: 2589, column: 7, scope: !4077)
!4077 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2589, column: 7)
!4078 = !DILocation(line: 2589, column: 10, scope: !4077)
!4079 = !DILocation(line: 2589, column: 7, scope: !271)
!4080 = !DILocalVariable(name: "t", scope: !4081, file: !3, line: 2590, type: !6)
!4081 = distinct !DILexicalBlock(scope: !4077, file: !3, line: 2589, column: 24)
!4082 = !DILocation(line: 2590, column: 12, scope: !4081)
!4083 = !DILocation(line: 2590, column: 39, scope: !4081)
!4084 = !DILocation(line: 2590, column: 34, scope: !4081)
!4085 = !DILocation(line: 2590, column: 16, scope: !4081)
!4086 = !DILocalVariable(name: "w", scope: !4081, file: !3, line: 2591, type: !6)
!4087 = !DILocation(line: 2591, column: 12, scope: !4081)
!4088 = !DILocation(line: 2591, column: 22, scope: !4081)
!4089 = !DILocation(line: 2591, column: 20, scope: !4081)
!4090 = !DILocation(line: 2593, column: 9, scope: !4091)
!4091 = distinct !DILexicalBlock(scope: !4081, file: !3, line: 2593, column: 9)
!4092 = !DILocation(line: 2593, column: 12, scope: !4091)
!4093 = !DILocation(line: 2593, column: 9, scope: !4081)
!4094 = !DILocation(line: 2593, column: 33, scope: !4091)
!4095 = !DILocation(line: 2593, column: 26, scope: !4091)
!4096 = !DILocation(line: 2594, column: 19, scope: !4081)
!4097 = !DILocation(line: 2594, column: 23, scope: !4081)
!4098 = !DILocation(line: 2594, column: 21, scope: !4081)
!4099 = !DILocation(line: 2594, column: 29, scope: !4081)
!4100 = !DILocation(line: 2594, column: 33, scope: !4081)
!4101 = !DILocation(line: 2594, column: 31, scope: !4081)
!4102 = !DILocation(line: 2594, column: 26, scope: !4081)
!4103 = !DILocation(line: 2594, column: 16, scope: !4081)
!4104 = !DILocation(line: 2594, column: 5, scope: !4081)
!4105 = !DILocation(line: 2598, column: 7, scope: !4106)
!4106 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2598, column: 7)
!4107 = !DILocation(line: 2598, column: 10, scope: !4106)
!4108 = !DILocation(line: 2598, column: 7, scope: !271)
!4109 = !DILocalVariable(name: "t", scope: !4110, file: !3, line: 2599, type: !6)
!4110 = distinct !DILexicalBlock(scope: !4106, file: !3, line: 2598, column: 24)
!4111 = !DILocation(line: 2599, column: 12, scope: !4110)
!4112 = !DILocation(line: 2599, column: 37, scope: !4110)
!4113 = !DILocation(line: 2599, column: 32, scope: !4110)
!4114 = !DILocation(line: 2599, column: 16, scope: !4110)
!4115 = !DILocation(line: 2600, column: 19, scope: !4110)
!4116 = !DILocation(line: 2600, column: 30, scope: !4110)
!4117 = !DILocation(line: 2600, column: 28, scope: !4110)
!4118 = !DILocation(line: 2600, column: 21, scope: !4110)
!4119 = !DILocation(line: 2600, column: 5, scope: !4110)
!4120 = !DILocation(line: 2604, column: 7, scope: !4121)
!4121 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2604, column: 7)
!4122 = !DILocation(line: 2604, column: 10, scope: !4121)
!4123 = !DILocation(line: 2604, column: 7, scope: !271)
!4124 = !DILocation(line: 2604, column: 59, scope: !4121)
!4125 = !DILocation(line: 2604, column: 54, scope: !4121)
!4126 = !DILocation(line: 2604, column: 38, scope: !4121)
!4127 = !DILocation(line: 2604, column: 36, scope: !4121)
!4128 = !DILocation(line: 2604, column: 24, scope: !4121)
!4129 = !DILocation(line: 2607, column: 12, scope: !4130)
!4130 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2607, column: 7)
!4131 = !DILocation(line: 2607, column: 7, scope: !4130)
!4132 = !DILocation(line: 2607, column: 15, scope: !4130)
!4133 = !DILocation(line: 2607, column: 7, scope: !271)
!4134 = !DILocalVariable(name: "w", scope: !4135, file: !3, line: 2608, type: !6)
!4135 = distinct !DILexicalBlock(scope: !4130, file: !3, line: 2607, column: 34)
!4136 = !DILocation(line: 2608, column: 12, scope: !4135)
!4137 = !DILocation(line: 2608, column: 44, scope: !4135)
!4138 = !DILocation(line: 2608, column: 39, scope: !4135)
!4139 = !DILocation(line: 2608, column: 37, scope: !4135)
!4140 = !DILocation(line: 2608, column: 16, scope: !4135)
!4141 = !DILocalVariable(name: "t", scope: !4135, file: !3, line: 2609, type: !6)
!4142 = !DILocation(line: 2609, column: 12, scope: !4135)
!4143 = !DILocation(line: 2609, column: 23, scope: !4135)
!4144 = !DILocation(line: 2609, column: 21, scope: !4135)
!4145 = !DILocation(line: 2610, column: 12, scope: !4135)
!4146 = !DILocation(line: 2610, column: 16, scope: !4135)
!4147 = !DILocation(line: 2610, column: 14, scope: !4135)
!4148 = !DILocation(line: 2610, column: 5, scope: !4135)
!4149 = !DILocation(line: 2614, column: 7, scope: !4150)
!4150 = distinct !DILexicalBlock(scope: !271, file: !3, line: 2614, column: 7)
!4151 = !DILocation(line: 2614, column: 10, scope: !4150)
!4152 = !DILocation(line: 2614, column: 7, scope: !271)
!4153 = !DILocation(line: 2614, column: 32, scope: !4150)
!4154 = !DILocation(line: 2614, column: 36, scope: !4150)
!4155 = !DILocation(line: 2614, column: 34, scope: !4150)
!4156 = !DILocation(line: 2614, column: 25, scope: !4150)
!4157 = !DILocation(line: 2617, column: 10, scope: !271)
!4158 = !DILocation(line: 2617, column: 17, scope: !271)
!4159 = !DILocation(line: 2617, column: 15, scope: !271)
!4160 = !DILocation(line: 2617, column: 3, scope: !271)
!4161 = !DILocation(line: 2618, column: 1, scope: !271)
!4162 = !DILocalVariable(name: "x", arg: 1, scope: !280, file: !3, line: 2641, type: !6)
!4163 = !DILocation(line: 2641, column: 32, scope: !280)
!4164 = !DILocalVariable(name: "h", scope: !280, file: !3, line: 2648, type: !6)
!4165 = !DILocation(line: 2648, column: 10, scope: !280)
!4166 = !DILocation(line: 2648, column: 15, scope: !280)
!4167 = !DILocation(line: 2648, column: 17, scope: !280)
!4168 = !DILocation(line: 2648, column: 14, scope: !280)
!4169 = !DILocalVariable(name: "ax", scope: !280, file: !3, line: 2650, type: !6)
!4170 = !DILocation(line: 2650, column: 10, scope: !280)
!4171 = !DILocation(line: 2650, column: 20, scope: !280)
!4172 = !DILocation(line: 2650, column: 15, scope: !280)
!4173 = !DILocation(line: 2651, column: 7, scope: !4174)
!4174 = distinct !DILexicalBlock(scope: !280, file: !3, line: 2651, column: 7)
!4175 = !DILocation(line: 2651, column: 10, scope: !4174)
!4176 = !DILocation(line: 2651, column: 7, scope: !280)
!4177 = !DILocation(line: 2653, column: 9, scope: !4178)
!4178 = distinct !DILexicalBlock(scope: !4179, file: !3, line: 2653, column: 9)
!4179 = distinct !DILexicalBlock(scope: !4174, file: !3, line: 2651, column: 16)
!4180 = !DILocation(line: 2653, column: 12, scope: !4178)
!4181 = !DILocation(line: 2653, column: 9, scope: !4179)
!4182 = !DILocation(line: 2653, column: 30, scope: !4178)
!4183 = !DILocation(line: 2653, column: 23, scope: !4178)
!4184 = !DILocalVariable(name: "t", scope: !4179, file: !3, line: 2654, type: !6)
!4185 = !DILocation(line: 2654, column: 12, scope: !4179)
!4186 = !DILocation(line: 2654, column: 34, scope: !4179)
!4187 = !DILocation(line: 2654, column: 16, scope: !4179)
!4188 = !DILocation(line: 2655, column: 9, scope: !4189)
!4189 = distinct !DILexicalBlock(scope: !4179, file: !3, line: 2655, column: 9)
!4190 = !DILocation(line: 2655, column: 12, scope: !4189)
!4191 = !DILocation(line: 2655, column: 9, scope: !4179)
!4192 = !DILocation(line: 2656, column: 14, scope: !4193)
!4193 = distinct !DILexicalBlock(scope: !4189, file: !3, line: 2655, column: 17)
!4194 = !DILocation(line: 2656, column: 23, scope: !4193)
!4195 = !DILocation(line: 2656, column: 27, scope: !4193)
!4196 = !DILocation(line: 2656, column: 31, scope: !4193)
!4197 = !DILocation(line: 2656, column: 29, scope: !4193)
!4198 = !DILocation(line: 2656, column: 36, scope: !4193)
!4199 = !DILocation(line: 2656, column: 38, scope: !4193)
!4200 = !DILocation(line: 2656, column: 33, scope: !4193)
!4201 = !DILocation(line: 2656, column: 25, scope: !4193)
!4202 = !DILocation(line: 2656, column: 16, scope: !4193)
!4203 = !DILocation(line: 2656, column: 7, scope: !4193)
!4204 = !DILocation(line: 2658, column: 12, scope: !4179)
!4205 = !DILocation(line: 2658, column: 17, scope: !4179)
!4206 = !DILocation(line: 2658, column: 21, scope: !4179)
!4207 = !DILocation(line: 2658, column: 26, scope: !4179)
!4208 = !DILocation(line: 2658, column: 28, scope: !4179)
!4209 = !DILocation(line: 2658, column: 23, scope: !4179)
!4210 = !DILocation(line: 2658, column: 19, scope: !4179)
!4211 = !DILocation(line: 2658, column: 14, scope: !4179)
!4212 = !DILocation(line: 2658, column: 5, scope: !4179)
!4213 = !DILocation(line: 2661, column: 7, scope: !4214)
!4214 = distinct !DILexicalBlock(scope: !280, file: !3, line: 2661, column: 7)
!4215 = !DILocation(line: 2661, column: 10, scope: !4214)
!4216 = !DILocation(line: 2661, column: 7, scope: !280)
!4217 = !DILocation(line: 2661, column: 29, scope: !4214)
!4218 = !DILocation(line: 2661, column: 49, scope: !4214)
!4219 = !DILocation(line: 2661, column: 33, scope: !4214)
!4220 = !DILocation(line: 2661, column: 31, scope: !4214)
!4221 = !DILocation(line: 2661, column: 22, scope: !4214)
!4222 = !DILocation(line: 2664, column: 7, scope: !4223)
!4223 = distinct !DILexicalBlock(scope: !280, file: !3, line: 2664, column: 7)
!4224 = !DILocation(line: 2664, column: 10, scope: !4223)
!4225 = !DILocation(line: 2664, column: 7, scope: !280)
!4226 = !DILocalVariable(name: "w", scope: !4227, file: !3, line: 2665, type: !6)
!4227 = distinct !DILexicalBlock(scope: !4223, file: !3, line: 2664, column: 29)
!4228 = !DILocation(line: 2665, column: 12, scope: !4227)
!4229 = !DILocation(line: 2665, column: 38, scope: !4227)
!4230 = !DILocation(line: 2665, column: 36, scope: !4227)
!4231 = !DILocation(line: 2665, column: 16, scope: !4227)
!4232 = !DILocalVariable(name: "t", scope: !4227, file: !3, line: 2666, type: !6)
!4233 = !DILocation(line: 2666, column: 12, scope: !4227)
!4234 = !DILocation(line: 2666, column: 16, scope: !4227)
!4235 = !DILocation(line: 2666, column: 20, scope: !4227)
!4236 = !DILocation(line: 2666, column: 18, scope: !4227)
!4237 = !DILocation(line: 2667, column: 12, scope: !4227)
!4238 = !DILocation(line: 2667, column: 16, scope: !4227)
!4239 = !DILocation(line: 2667, column: 14, scope: !4227)
!4240 = !DILocation(line: 2667, column: 5, scope: !4227)
!4241 = !DILocation(line: 2671, column: 10, scope: !280)
!4242 = !DILocation(line: 2671, column: 12, scope: !280)
!4243 = !DILocation(line: 2671, column: 3, scope: !280)
!4244 = !DILocation(line: 2672, column: 1, scope: !280)
!4245 = !DILocalVariable(name: "x", arg: 1, scope: !289, file: !3, line: 2697, type: !6)
!4246 = !DILocation(line: 2697, column: 32, scope: !289)
!4247 = !DILocalVariable(name: "t", scope: !289, file: !3, line: 2700, type: !6)
!4248 = !DILocation(line: 2700, column: 10, scope: !289)
!4249 = !DILocalVariable(name: "z", scope: !289, file: !3, line: 2700, type: !6)
!4250 = !DILocation(line: 2700, column: 13, scope: !289)
!4251 = !DILocalVariable(name: "jx", scope: !289, file: !3, line: 2701, type: !18)
!4252 = !DILocation(line: 2701, column: 11, scope: !289)
!4253 = !DILocalVariable(name: "ix", scope: !289, file: !3, line: 2701, type: !18)
!4254 = !DILocation(line: 2701, column: 15, scope: !289)
!4255 = !DILocation(line: 2703, column: 3, scope: !289)
!4256 = !DILocalVariable(name: "bits", scope: !4257, file: !3, line: 2703, type: !16)
!4257 = distinct !DILexicalBlock(scope: !289, file: !3, line: 2703, column: 3)
!4258 = !DILocation(line: 2703, column: 3, scope: !4257)
!4259 = !DILocation(line: 2704, column: 8, scope: !289)
!4260 = !DILocation(line: 2704, column: 11, scope: !289)
!4261 = !DILocation(line: 2704, column: 6, scope: !289)
!4262 = !DILocation(line: 2707, column: 7, scope: !4263)
!4263 = distinct !DILexicalBlock(scope: !289, file: !3, line: 2707, column: 7)
!4264 = !DILocation(line: 2707, column: 10, scope: !4263)
!4265 = !DILocation(line: 2707, column: 7, scope: !289)
!4266 = !DILocation(line: 2708, column: 9, scope: !4267)
!4267 = distinct !DILexicalBlock(scope: !4268, file: !3, line: 2708, column: 9)
!4268 = distinct !DILexicalBlock(scope: !4263, file: !3, line: 2707, column: 25)
!4269 = !DILocation(line: 2708, column: 12, scope: !4267)
!4270 = !DILocation(line: 2708, column: 9, scope: !4268)
!4271 = !DILocation(line: 2709, column: 20, scope: !4267)
!4272 = !DILocation(line: 2709, column: 18, scope: !4267)
!4273 = !DILocation(line: 2709, column: 22, scope: !4267)
!4274 = !DILocation(line: 2709, column: 7, scope: !4267)
!4275 = !DILocation(line: 2711, column: 20, scope: !4267)
!4276 = !DILocation(line: 2711, column: 18, scope: !4267)
!4277 = !DILocation(line: 2711, column: 22, scope: !4267)
!4278 = !DILocation(line: 2711, column: 7, scope: !4267)
!4279 = !DILocation(line: 2715, column: 7, scope: !4280)
!4280 = distinct !DILexicalBlock(scope: !289, file: !3, line: 2715, column: 7)
!4281 = !DILocation(line: 2715, column: 10, scope: !4280)
!4282 = !DILocation(line: 2715, column: 7, scope: !289)
!4283 = !DILocation(line: 2716, column: 9, scope: !4284)
!4284 = distinct !DILexicalBlock(scope: !4285, file: !3, line: 2716, column: 9)
!4285 = distinct !DILexicalBlock(scope: !4280, file: !3, line: 2715, column: 24)
!4286 = !DILocation(line: 2716, column: 12, scope: !4284)
!4287 = !DILocation(line: 2716, column: 9, scope: !4285)
!4288 = !DILocation(line: 2717, column: 18, scope: !4289)
!4289 = distinct !DILexicalBlock(scope: !4290, file: !3, line: 2717, column: 11)
!4290 = distinct !DILexicalBlock(scope: !4284, file: !3, line: 2716, column: 26)
!4291 = !DILocation(line: 2717, column: 16, scope: !4289)
!4292 = !DILocation(line: 2717, column: 20, scope: !4289)
!4293 = !DILocation(line: 2717, column: 11, scope: !4290)
!4294 = !DILocation(line: 2717, column: 34, scope: !4289)
!4295 = !DILocation(line: 2717, column: 27, scope: !4289)
!4296 = !DILocation(line: 2718, column: 5, scope: !4290)
!4297 = !DILocation(line: 2719, column: 9, scope: !4298)
!4298 = distinct !DILexicalBlock(scope: !4285, file: !3, line: 2719, column: 9)
!4299 = !DILocation(line: 2719, column: 12, scope: !4298)
!4300 = !DILocation(line: 2719, column: 9, scope: !4285)
!4301 = !DILocation(line: 2720, column: 40, scope: !4302)
!4302 = distinct !DILexicalBlock(scope: !4298, file: !3, line: 2719, column: 27)
!4303 = !DILocation(line: 2720, column: 35, scope: !4302)
!4304 = !DILocation(line: 2720, column: 33, scope: !4302)
!4305 = !DILocation(line: 2720, column: 11, scope: !4302)
!4306 = !DILocation(line: 2720, column: 9, scope: !4302)
!4307 = !DILocation(line: 2721, column: 24, scope: !4302)
!4308 = !DILocation(line: 2721, column: 26, scope: !4302)
!4309 = !DILocation(line: 2721, column: 21, scope: !4302)
!4310 = !DILocation(line: 2721, column: 15, scope: !4302)
!4311 = !DILocation(line: 2721, column: 9, scope: !4302)
!4312 = !DILocation(line: 2722, column: 5, scope: !4302)
!4313 = !DILocation(line: 2723, column: 41, scope: !4314)
!4314 = distinct !DILexicalBlock(scope: !4298, file: !3, line: 2722, column: 12)
!4315 = !DILocation(line: 2723, column: 36, scope: !4314)
!4316 = !DILocation(line: 2723, column: 34, scope: !4314)
!4317 = !DILocation(line: 2723, column: 11, scope: !4314)
!4318 = !DILocation(line: 2723, column: 9, scope: !4314)
!4319 = !DILocation(line: 2724, column: 12, scope: !4314)
!4320 = !DILocation(line: 2724, column: 11, scope: !4314)
!4321 = !DILocation(line: 2724, column: 17, scope: !4314)
!4322 = !DILocation(line: 2724, column: 19, scope: !4314)
!4323 = !DILocation(line: 2724, column: 14, scope: !4314)
!4324 = !DILocation(line: 2724, column: 9, scope: !4314)
!4325 = !DILocation(line: 2727, column: 3, scope: !4285)
!4326 = !DILocation(line: 2728, column: 15, scope: !4327)
!4327 = distinct !DILexicalBlock(scope: !4280, file: !3, line: 2727, column: 10)
!4328 = !DILocation(line: 2728, column: 13, scope: !4327)
!4329 = !DILocation(line: 2728, column: 7, scope: !4327)
!4330 = !DILocation(line: 2730, column: 11, scope: !289)
!4331 = !DILocation(line: 2730, column: 14, scope: !289)
!4332 = !DILocation(line: 2730, column: 10, scope: !289)
!4333 = !DILocation(line: 2730, column: 22, scope: !289)
!4334 = !DILocation(line: 2730, column: 27, scope: !289)
!4335 = !DILocation(line: 2730, column: 26, scope: !289)
!4336 = !DILocation(line: 2730, column: 3, scope: !289)
!4337 = !DILocation(line: 2731, column: 1, scope: !289)
!4338 = !DILocalVariable(name: "x", arg: 1, scope: !348, file: !3, line: 474, type: !316)
!4339 = !DILocation(line: 474, column: 38, scope: !348)
!4340 = !DILocalVariable(name: "y", arg: 2, scope: !348, file: !3, line: 474, type: !316)
!4341 = !DILocation(line: 474, column: 49, scope: !348)
!4342 = !DILocalVariable(name: "e0", arg: 3, scope: !348, file: !3, line: 474, type: !15)
!4343 = !DILocation(line: 474, column: 56, scope: !348)
!4344 = !DILocalVariable(name: "nx", arg: 4, scope: !348, file: !3, line: 474, type: !15)
!4345 = !DILocation(line: 474, column: 64, scope: !348)
!4346 = !DILocalVariable(name: "prec", arg: 5, scope: !348, file: !3, line: 474, type: !15)
!4347 = !DILocation(line: 474, column: 72, scope: !348)
!4348 = !DILocalVariable(name: "ipio2", arg: 6, scope: !348, file: !3, line: 475, type: !351)
!4349 = !DILocation(line: 475, column: 38, scope: !348)
!4350 = !DILocalVariable(name: "jz", scope: !348, file: !3, line: 501, type: !18)
!4351 = !DILocation(line: 501, column: 11, scope: !348)
!4352 = !DILocalVariable(name: "jx", scope: !348, file: !3, line: 501, type: !18)
!4353 = !DILocation(line: 501, column: 15, scope: !348)
!4354 = !DILocalVariable(name: "jv", scope: !348, file: !3, line: 501, type: !18)
!4355 = !DILocation(line: 501, column: 19, scope: !348)
!4356 = !DILocalVariable(name: "jp", scope: !348, file: !3, line: 501, type: !18)
!4357 = !DILocation(line: 501, column: 23, scope: !348)
!4358 = !DILocalVariable(name: "jk", scope: !348, file: !3, line: 501, type: !18)
!4359 = !DILocation(line: 501, column: 27, scope: !348)
!4360 = !DILocalVariable(name: "carry", scope: !348, file: !3, line: 501, type: !18)
!4361 = !DILocation(line: 501, column: 31, scope: !348)
!4362 = !DILocalVariable(name: "n", scope: !348, file: !3, line: 501, type: !18)
!4363 = !DILocation(line: 501, column: 38, scope: !348)
!4364 = !DILocalVariable(name: "iq", scope: !348, file: !3, line: 501, type: !4365)
!4365 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 640, elements: !4366)
!4366 = !{!4367}
!4367 = !DISubrange(count: 20)
!4368 = !DILocation(line: 501, column: 41, scope: !348)
!4369 = !DILocalVariable(name: "i", scope: !348, file: !3, line: 501, type: !18)
!4370 = !DILocation(line: 501, column: 49, scope: !348)
!4371 = !DILocalVariable(name: "j", scope: !348, file: !3, line: 501, type: !18)
!4372 = !DILocation(line: 501, column: 52, scope: !348)
!4373 = !DILocalVariable(name: "k", scope: !348, file: !3, line: 501, type: !18)
!4374 = !DILocation(line: 501, column: 55, scope: !348)
!4375 = !DILocalVariable(name: "m", scope: !348, file: !3, line: 501, type: !18)
!4376 = !DILocation(line: 501, column: 58, scope: !348)
!4377 = !DILocalVariable(name: "q0", scope: !348, file: !3, line: 501, type: !18)
!4378 = !DILocation(line: 501, column: 61, scope: !348)
!4379 = !DILocalVariable(name: "ih", scope: !348, file: !3, line: 501, type: !18)
!4380 = !DILocation(line: 501, column: 65, scope: !348)
!4381 = !DILocalVariable(name: "z", scope: !348, file: !3, line: 502, type: !6)
!4382 = !DILocation(line: 502, column: 10, scope: !348)
!4383 = !DILocalVariable(name: "fw", scope: !348, file: !3, line: 502, type: !6)
!4384 = !DILocation(line: 502, column: 13, scope: !348)
!4385 = !DILocalVariable(name: "f", scope: !348, file: !3, line: 502, type: !4386)
!4386 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 1280, elements: !4366)
!4387 = !DILocation(line: 502, column: 17, scope: !348)
!4388 = !DILocalVariable(name: "fq", scope: !348, file: !3, line: 502, type: !4386)
!4389 = !DILocation(line: 502, column: 24, scope: !348)
!4390 = !DILocalVariable(name: "q", scope: !348, file: !3, line: 502, type: !4386)
!4391 = !DILocation(line: 502, column: 32, scope: !348)
!4392 = !DILocation(line: 505, column: 16, scope: !348)
!4393 = !DILocation(line: 505, column: 8, scope: !348)
!4394 = !DILocation(line: 505, column: 6, scope: !348)
!4395 = !DILocation(line: 506, column: 8, scope: !348)
!4396 = !DILocation(line: 506, column: 6, scope: !348)
!4397 = !DILocation(line: 509, column: 8, scope: !348)
!4398 = !DILocation(line: 509, column: 11, scope: !348)
!4399 = !DILocation(line: 509, column: 6, scope: !348)
!4400 = !DILocation(line: 510, column: 9, scope: !348)
!4401 = !DILocation(line: 510, column: 12, scope: !348)
!4402 = !DILocation(line: 510, column: 17, scope: !348)
!4403 = !DILocation(line: 510, column: 6, scope: !348)
!4404 = !DILocation(line: 511, column: 7, scope: !4405)
!4405 = distinct !DILexicalBlock(scope: !348, file: !3, line: 511, column: 7)
!4406 = !DILocation(line: 511, column: 10, scope: !4405)
!4407 = !DILocation(line: 511, column: 7, scope: !348)
!4408 = !DILocation(line: 511, column: 18, scope: !4405)
!4409 = !DILocation(line: 511, column: 15, scope: !4405)
!4410 = !DILocation(line: 512, column: 8, scope: !348)
!4411 = !DILocation(line: 512, column: 19, scope: !348)
!4412 = !DILocation(line: 512, column: 22, scope: !348)
!4413 = !DILocation(line: 512, column: 16, scope: !348)
!4414 = !DILocation(line: 512, column: 11, scope: !348)
!4415 = !DILocation(line: 512, column: 6, scope: !348)
!4416 = !DILocation(line: 515, column: 7, scope: !348)
!4417 = !DILocation(line: 515, column: 12, scope: !348)
!4418 = !DILocation(line: 515, column: 10, scope: !348)
!4419 = !DILocation(line: 515, column: 5, scope: !348)
!4420 = !DILocation(line: 516, column: 7, scope: !348)
!4421 = !DILocation(line: 516, column: 12, scope: !348)
!4422 = !DILocation(line: 516, column: 10, scope: !348)
!4423 = !DILocation(line: 516, column: 5, scope: !348)
!4424 = !DILocation(line: 517, column: 10, scope: !4425)
!4425 = distinct !DILexicalBlock(scope: !348, file: !3, line: 517, column: 3)
!4426 = !DILocation(line: 517, column: 8, scope: !4425)
!4427 = !DILocation(line: 517, column: 15, scope: !4428)
!4428 = distinct !DILexicalBlock(scope: !4425, file: !3, line: 517, column: 3)
!4429 = !DILocation(line: 517, column: 20, scope: !4428)
!4430 = !DILocation(line: 517, column: 17, scope: !4428)
!4431 = !DILocation(line: 517, column: 3, scope: !4425)
!4432 = !DILocation(line: 518, column: 13, scope: !4433)
!4433 = distinct !DILexicalBlock(scope: !4428, file: !3, line: 517, column: 33)
!4434 = !DILocation(line: 518, column: 15, scope: !4433)
!4435 = !DILocation(line: 518, column: 12, scope: !4433)
!4436 = !DILocation(line: 518, column: 38, scope: !4433)
!4437 = !DILocation(line: 518, column: 44, scope: !4433)
!4438 = !DILocation(line: 518, column: 29, scope: !4433)
!4439 = !DILocation(line: 518, column: 7, scope: !4433)
!4440 = !DILocation(line: 518, column: 5, scope: !4433)
!4441 = !DILocation(line: 518, column: 10, scope: !4433)
!4442 = !DILocation(line: 519, column: 3, scope: !4433)
!4443 = !DILocation(line: 517, column: 24, scope: !4428)
!4444 = !DILocation(line: 517, column: 29, scope: !4428)
!4445 = !DILocation(line: 517, column: 3, scope: !4428)
!4446 = distinct !{!4446, !4431, !4447, !2472}
!4447 = !DILocation(line: 519, column: 3, scope: !4425)
!4448 = !DILocation(line: 522, column: 10, scope: !4449)
!4449 = distinct !DILexicalBlock(scope: !348, file: !3, line: 522, column: 3)
!4450 = !DILocation(line: 522, column: 8, scope: !4449)
!4451 = !DILocation(line: 522, column: 15, scope: !4452)
!4452 = distinct !DILexicalBlock(scope: !4449, file: !3, line: 522, column: 3)
!4453 = !DILocation(line: 522, column: 20, scope: !4452)
!4454 = !DILocation(line: 522, column: 17, scope: !4452)
!4455 = !DILocation(line: 522, column: 3, scope: !4449)
!4456 = !DILocation(line: 523, column: 12, scope: !4457)
!4457 = distinct !DILexicalBlock(scope: !4458, file: !3, line: 523, column: 5)
!4458 = distinct !DILexicalBlock(scope: !4452, file: !3, line: 522, column: 29)
!4459 = !DILocation(line: 523, column: 20, scope: !4457)
!4460 = !DILocation(line: 523, column: 10, scope: !4457)
!4461 = !DILocation(line: 523, column: 27, scope: !4462)
!4462 = distinct !DILexicalBlock(scope: !4457, file: !3, line: 523, column: 5)
!4463 = !DILocation(line: 523, column: 32, scope: !4462)
!4464 = !DILocation(line: 523, column: 29, scope: !4462)
!4465 = !DILocation(line: 523, column: 5, scope: !4457)
!4466 = !DILocation(line: 523, column: 47, scope: !4462)
!4467 = !DILocation(line: 523, column: 49, scope: !4462)
!4468 = !DILocation(line: 523, column: 56, scope: !4462)
!4469 = !DILocation(line: 523, column: 61, scope: !4462)
!4470 = !DILocation(line: 523, column: 59, scope: !4462)
!4471 = !DILocation(line: 523, column: 65, scope: !4462)
!4472 = !DILocation(line: 523, column: 63, scope: !4462)
!4473 = !DILocation(line: 523, column: 54, scope: !4462)
!4474 = !DILocation(line: 523, column: 44, scope: !4462)
!4475 = !DILocation(line: 523, column: 41, scope: !4462)
!4476 = !DILocation(line: 523, column: 37, scope: !4462)
!4477 = !DILocation(line: 523, column: 5, scope: !4462)
!4478 = distinct !{!4478, !4465, !4479, !2472}
!4479 = !DILocation(line: 523, column: 66, scope: !4457)
!4480 = !DILocation(line: 524, column: 12, scope: !4458)
!4481 = !DILocation(line: 524, column: 7, scope: !4458)
!4482 = !DILocation(line: 524, column: 5, scope: !4458)
!4483 = !DILocation(line: 524, column: 10, scope: !4458)
!4484 = !DILocation(line: 525, column: 3, scope: !4458)
!4485 = !DILocation(line: 522, column: 25, scope: !4452)
!4486 = !DILocation(line: 522, column: 3, scope: !4452)
!4487 = distinct !{!4487, !4455, !4488, !2472}
!4488 = !DILocation(line: 525, column: 3, scope: !4449)
!4489 = !DILocation(line: 527, column: 8, scope: !348)
!4490 = !DILocation(line: 527, column: 6, scope: !348)
!4491 = !DILocation(line: 527, column: 3, scope: !348)
!4492 = !DILabel(scope: !348, name: "recompute", file: !3, line: 528)
!4493 = !DILocation(line: 528, column: 1, scope: !348)
!4494 = !DILocation(line: 530, column: 10, scope: !4495)
!4495 = distinct !DILexicalBlock(scope: !348, file: !3, line: 530, column: 3)
!4496 = !DILocation(line: 530, column: 19, scope: !4495)
!4497 = !DILocation(line: 530, column: 17, scope: !4495)
!4498 = !DILocation(line: 530, column: 29, scope: !4495)
!4499 = !DILocation(line: 530, column: 27, scope: !4495)
!4500 = !DILocation(line: 530, column: 25, scope: !4495)
!4501 = !DILocation(line: 530, column: 8, scope: !4495)
!4502 = !DILocation(line: 530, column: 34, scope: !4503)
!4503 = distinct !DILexicalBlock(scope: !4495, file: !3, line: 530, column: 3)
!4504 = !DILocation(line: 530, column: 36, scope: !4503)
!4505 = !DILocation(line: 530, column: 3, scope: !4495)
!4506 = !DILocation(line: 531, column: 38, scope: !4507)
!4507 = distinct !DILexicalBlock(scope: !4503, file: !3, line: 530, column: 51)
!4508 = !DILocation(line: 531, column: 36, scope: !4507)
!4509 = !DILocation(line: 531, column: 19, scope: !4507)
!4510 = !DILocation(line: 531, column: 10, scope: !4507)
!4511 = !DILocation(line: 531, column: 8, scope: !4507)
!4512 = !DILocation(line: 532, column: 23, scope: !4507)
!4513 = !DILocation(line: 532, column: 35, scope: !4507)
!4514 = !DILocation(line: 532, column: 25, scope: !4507)
!4515 = !DILocation(line: 532, column: 13, scope: !4507)
!4516 = !DILocation(line: 532, column: 8, scope: !4507)
!4517 = !DILocation(line: 532, column: 5, scope: !4507)
!4518 = !DILocation(line: 532, column: 11, scope: !4507)
!4519 = !DILocation(line: 533, column: 11, scope: !4507)
!4520 = !DILocation(line: 533, column: 13, scope: !4507)
!4521 = !DILocation(line: 533, column: 9, scope: !4507)
!4522 = !DILocation(line: 533, column: 20, scope: !4507)
!4523 = !DILocation(line: 533, column: 18, scope: !4507)
!4524 = !DILocation(line: 533, column: 7, scope: !4507)
!4525 = !DILocation(line: 534, column: 3, scope: !4507)
!4526 = !DILocation(line: 530, column: 42, scope: !4503)
!4527 = !DILocation(line: 530, column: 47, scope: !4503)
!4528 = !DILocation(line: 530, column: 3, scope: !4503)
!4529 = distinct !{!4529, !4505, !4530, !2472}
!4530 = !DILocation(line: 534, column: 3, scope: !4495)
!4531 = !DILocation(line: 537, column: 14, scope: !348)
!4532 = !DILocation(line: 537, column: 17, scope: !348)
!4533 = !DILocation(line: 537, column: 7, scope: !348)
!4534 = !DILocation(line: 537, column: 5, scope: !348)
!4535 = !DILocation(line: 538, column: 20, scope: !348)
!4536 = !DILocation(line: 538, column: 22, scope: !348)
!4537 = !DILocation(line: 538, column: 14, scope: !348)
!4538 = !DILocation(line: 538, column: 5, scope: !348)
!4539 = !DILocation(line: 539, column: 17, scope: !348)
!4540 = !DILocation(line: 539, column: 7, scope: !348)
!4541 = !DILocation(line: 539, column: 5, scope: !348)
!4542 = !DILocation(line: 540, column: 17, scope: !348)
!4543 = !DILocation(line: 540, column: 8, scope: !348)
!4544 = !DILocation(line: 540, column: 5, scope: !348)
!4545 = !DILocation(line: 541, column: 6, scope: !348)
!4546 = !DILocation(line: 542, column: 7, scope: !4547)
!4547 = distinct !DILexicalBlock(scope: !348, file: !3, line: 542, column: 7)
!4548 = !DILocation(line: 542, column: 10, scope: !4547)
!4549 = !DILocation(line: 542, column: 7, scope: !348)
!4550 = !DILocation(line: 543, column: 13, scope: !4551)
!4551 = distinct !DILexicalBlock(scope: !4547, file: !3, line: 542, column: 15)
!4552 = !DILocation(line: 543, column: 16, scope: !4551)
!4553 = !DILocation(line: 543, column: 10, scope: !4551)
!4554 = !DILocation(line: 543, column: 30, scope: !4551)
!4555 = !DILocation(line: 543, column: 28, scope: !4551)
!4556 = !DILocation(line: 543, column: 21, scope: !4551)
!4557 = !DILocation(line: 543, column: 7, scope: !4551)
!4558 = !DILocation(line: 544, column: 10, scope: !4551)
!4559 = !DILocation(line: 544, column: 7, scope: !4551)
!4560 = !DILocation(line: 545, column: 19, scope: !4551)
!4561 = !DILocation(line: 545, column: 30, scope: !4551)
!4562 = !DILocation(line: 545, column: 28, scope: !4551)
!4563 = !DILocation(line: 545, column: 21, scope: !4551)
!4564 = !DILocation(line: 545, column: 8, scope: !4551)
!4565 = !DILocation(line: 545, column: 11, scope: !4551)
!4566 = !DILocation(line: 545, column: 5, scope: !4551)
!4567 = !DILocation(line: 545, column: 16, scope: !4551)
!4568 = !DILocation(line: 546, column: 13, scope: !4551)
!4569 = !DILocation(line: 546, column: 16, scope: !4551)
!4570 = !DILocation(line: 546, column: 10, scope: !4551)
!4571 = !DILocation(line: 546, column: 30, scope: !4551)
!4572 = !DILocation(line: 546, column: 28, scope: !4551)
!4573 = !DILocation(line: 546, column: 21, scope: !4551)
!4574 = !DILocation(line: 546, column: 8, scope: !4551)
!4575 = !DILocation(line: 547, column: 3, scope: !4551)
!4576 = !DILocation(line: 547, column: 14, scope: !4577)
!4577 = distinct !DILexicalBlock(scope: !4547, file: !3, line: 547, column: 14)
!4578 = !DILocation(line: 547, column: 17, scope: !4577)
!4579 = !DILocation(line: 547, column: 14, scope: !4547)
!4580 = !DILocation(line: 548, column: 13, scope: !4581)
!4581 = distinct !DILexicalBlock(scope: !4577, file: !3, line: 547, column: 23)
!4582 = !DILocation(line: 548, column: 16, scope: !4581)
!4583 = !DILocation(line: 548, column: 10, scope: !4581)
!4584 = !DILocation(line: 548, column: 21, scope: !4581)
!4585 = !DILocation(line: 548, column: 8, scope: !4581)
!4586 = !DILocation(line: 549, column: 3, scope: !4581)
!4587 = !DILocation(line: 549, column: 14, scope: !4588)
!4588 = distinct !DILexicalBlock(scope: !4577, file: !3, line: 549, column: 14)
!4589 = !DILocation(line: 549, column: 16, scope: !4588)
!4590 = !DILocation(line: 549, column: 14, scope: !4577)
!4591 = !DILocation(line: 550, column: 8, scope: !4592)
!4592 = distinct !DILexicalBlock(scope: !4588, file: !3, line: 549, column: 24)
!4593 = !DILocation(line: 551, column: 3, scope: !4592)
!4594 = !DILocation(line: 553, column: 7, scope: !4595)
!4595 = distinct !DILexicalBlock(scope: !348, file: !3, line: 553, column: 7)
!4596 = !DILocation(line: 553, column: 10, scope: !4595)
!4597 = !DILocation(line: 553, column: 7, scope: !348)
!4598 = !DILocation(line: 554, column: 7, scope: !4599)
!4599 = distinct !DILexicalBlock(scope: !4595, file: !3, line: 553, column: 15)
!4600 = !DILocation(line: 555, column: 11, scope: !4599)
!4601 = !DILocation(line: 556, column: 12, scope: !4602)
!4602 = distinct !DILexicalBlock(scope: !4599, file: !3, line: 556, column: 5)
!4603 = !DILocation(line: 556, column: 10, scope: !4602)
!4604 = !DILocation(line: 556, column: 17, scope: !4605)
!4605 = distinct !DILexicalBlock(scope: !4602, file: !3, line: 556, column: 5)
!4606 = !DILocation(line: 556, column: 21, scope: !4605)
!4607 = !DILocation(line: 556, column: 19, scope: !4605)
!4608 = !DILocation(line: 556, column: 5, scope: !4602)
!4609 = !DILocation(line: 557, column: 14, scope: !4610)
!4610 = distinct !DILexicalBlock(scope: !4605, file: !3, line: 556, column: 30)
!4611 = !DILocation(line: 557, column: 11, scope: !4610)
!4612 = !DILocation(line: 557, column: 9, scope: !4610)
!4613 = !DILocation(line: 558, column: 11, scope: !4614)
!4614 = distinct !DILexicalBlock(scope: !4610, file: !3, line: 558, column: 11)
!4615 = !DILocation(line: 558, column: 17, scope: !4614)
!4616 = !DILocation(line: 558, column: 11, scope: !4610)
!4617 = !DILocation(line: 559, column: 13, scope: !4618)
!4618 = distinct !DILexicalBlock(scope: !4619, file: !3, line: 559, column: 13)
!4619 = distinct !DILexicalBlock(scope: !4614, file: !3, line: 558, column: 23)
!4620 = !DILocation(line: 559, column: 15, scope: !4618)
!4621 = !DILocation(line: 559, column: 13, scope: !4619)
!4622 = !DILocation(line: 560, column: 17, scope: !4623)
!4623 = distinct !DILexicalBlock(scope: !4618, file: !3, line: 559, column: 21)
!4624 = !DILocation(line: 561, column: 31, scope: !4623)
!4625 = !DILocation(line: 561, column: 29, scope: !4623)
!4626 = !DILocation(line: 561, column: 14, scope: !4623)
!4627 = !DILocation(line: 561, column: 11, scope: !4623)
!4628 = !DILocation(line: 561, column: 17, scope: !4623)
!4629 = !DILocation(line: 562, column: 9, scope: !4623)
!4630 = !DILocation(line: 563, column: 7, scope: !4619)
!4631 = !DILocation(line: 564, column: 28, scope: !4632)
!4632 = distinct !DILexicalBlock(scope: !4614, file: !3, line: 563, column: 14)
!4633 = !DILocation(line: 564, column: 26, scope: !4632)
!4634 = !DILocation(line: 564, column: 12, scope: !4632)
!4635 = !DILocation(line: 564, column: 9, scope: !4632)
!4636 = !DILocation(line: 564, column: 15, scope: !4632)
!4637 = !DILocation(line: 566, column: 5, scope: !4610)
!4638 = !DILocation(line: 556, column: 26, scope: !4605)
!4639 = !DILocation(line: 556, column: 5, scope: !4605)
!4640 = distinct !{!4640, !4608, !4641, !2472}
!4641 = !DILocation(line: 566, column: 5, scope: !4602)
!4642 = !DILocation(line: 567, column: 9, scope: !4643)
!4643 = distinct !DILexicalBlock(scope: !4599, file: !3, line: 567, column: 9)
!4644 = !DILocation(line: 567, column: 12, scope: !4643)
!4645 = !DILocation(line: 567, column: 9, scope: !4599)
!4646 = !DILocation(line: 568, column: 15, scope: !4647)
!4647 = distinct !DILexicalBlock(scope: !4643, file: !3, line: 567, column: 17)
!4648 = !DILocation(line: 568, column: 7, scope: !4647)
!4649 = !DILocation(line: 570, column: 14, scope: !4650)
!4650 = distinct !DILexicalBlock(scope: !4647, file: !3, line: 568, column: 19)
!4651 = !DILocation(line: 570, column: 17, scope: !4650)
!4652 = !DILocation(line: 570, column: 11, scope: !4650)
!4653 = !DILocation(line: 570, column: 22, scope: !4650)
!4654 = !DILocation(line: 571, column: 11, scope: !4650)
!4655 = !DILocation(line: 573, column: 14, scope: !4650)
!4656 = !DILocation(line: 573, column: 17, scope: !4650)
!4657 = !DILocation(line: 573, column: 11, scope: !4650)
!4658 = !DILocation(line: 573, column: 22, scope: !4650)
!4659 = !DILocation(line: 574, column: 11, scope: !4650)
!4660 = !DILocation(line: 576, column: 5, scope: !4647)
!4661 = !DILocation(line: 577, column: 9, scope: !4662)
!4662 = distinct !DILexicalBlock(scope: !4599, file: !3, line: 577, column: 9)
!4663 = !DILocation(line: 577, column: 12, scope: !4662)
!4664 = !DILocation(line: 577, column: 9, scope: !4599)
!4665 = !DILocation(line: 578, column: 17, scope: !4666)
!4666 = distinct !DILexicalBlock(scope: !4662, file: !3, line: 577, column: 18)
!4667 = !DILocation(line: 578, column: 15, scope: !4666)
!4668 = !DILocation(line: 578, column: 9, scope: !4666)
!4669 = !DILocation(line: 579, column: 11, scope: !4670)
!4670 = distinct !DILexicalBlock(scope: !4666, file: !3, line: 579, column: 11)
!4671 = !DILocation(line: 579, column: 17, scope: !4670)
!4672 = !DILocation(line: 579, column: 11, scope: !4666)
!4673 = !DILocation(line: 579, column: 40, scope: !4670)
!4674 = !DILocation(line: 579, column: 28, scope: !4670)
!4675 = !DILocation(line: 579, column: 25, scope: !4670)
!4676 = !DILocation(line: 579, column: 23, scope: !4670)
!4677 = !DILocation(line: 580, column: 5, scope: !4666)
!4678 = !DILocation(line: 581, column: 3, scope: !4599)
!4679 = !DILocation(line: 584, column: 7, scope: !4680)
!4680 = distinct !DILexicalBlock(scope: !348, file: !3, line: 584, column: 7)
!4681 = !DILocation(line: 584, column: 9, scope: !4680)
!4682 = !DILocation(line: 584, column: 7, scope: !348)
!4683 = !DILocation(line: 585, column: 7, scope: !4684)
!4684 = distinct !DILexicalBlock(scope: !4680, file: !3, line: 584, column: 18)
!4685 = !DILocation(line: 586, column: 14, scope: !4686)
!4686 = distinct !DILexicalBlock(scope: !4684, file: !3, line: 586, column: 5)
!4687 = !DILocation(line: 586, column: 17, scope: !4686)
!4688 = !DILocation(line: 586, column: 12, scope: !4686)
!4689 = !DILocation(line: 586, column: 10, scope: !4686)
!4690 = !DILocation(line: 586, column: 22, scope: !4691)
!4691 = distinct !DILexicalBlock(scope: !4686, file: !3, line: 586, column: 5)
!4692 = !DILocation(line: 586, column: 27, scope: !4691)
!4693 = !DILocation(line: 586, column: 24, scope: !4691)
!4694 = !DILocation(line: 586, column: 5, scope: !4686)
!4695 = !DILocation(line: 586, column: 44, scope: !4691)
!4696 = !DILocation(line: 586, column: 41, scope: !4691)
!4697 = !DILocation(line: 586, column: 38, scope: !4691)
!4698 = !DILocation(line: 586, column: 36, scope: !4691)
!4699 = !DILocation(line: 586, column: 32, scope: !4691)
!4700 = !DILocation(line: 586, column: 5, scope: !4691)
!4701 = distinct !{!4701, !4694, !4702, !2472}
!4702 = !DILocation(line: 586, column: 45, scope: !4686)
!4703 = !DILocation(line: 587, column: 9, scope: !4704)
!4704 = distinct !DILexicalBlock(scope: !4684, file: !3, line: 587, column: 9)
!4705 = !DILocation(line: 587, column: 11, scope: !4704)
!4706 = !DILocation(line: 587, column: 9, scope: !4684)
!4707 = !DILocation(line: 588, column: 14, scope: !4708)
!4708 = distinct !DILexicalBlock(scope: !4709, file: !3, line: 588, column: 7)
!4709 = distinct !DILexicalBlock(scope: !4704, file: !3, line: 587, column: 17)
!4710 = !DILocation(line: 588, column: 12, scope: !4708)
!4711 = !DILocation(line: 588, column: 19, scope: !4712)
!4712 = distinct !DILexicalBlock(scope: !4708, file: !3, line: 588, column: 7)
!4713 = !DILocation(line: 588, column: 25, scope: !4712)
!4714 = !DILocation(line: 588, column: 22, scope: !4712)
!4715 = !DILocation(line: 588, column: 27, scope: !4712)
!4716 = !DILocation(line: 588, column: 33, scope: !4712)
!4717 = !DILocation(line: 588, column: 38, scope: !4712)
!4718 = !DILocation(line: 588, column: 36, scope: !4712)
!4719 = !DILocation(line: 588, column: 30, scope: !4712)
!4720 = !DILocation(line: 588, column: 41, scope: !4712)
!4721 = !DILocation(line: 0, scope: !4712)
!4722 = !DILocation(line: 588, column: 7, scope: !4708)
!4723 = !DILocation(line: 590, column: 7, scope: !4724)
!4724 = distinct !DILexicalBlock(scope: !4712, file: !3, line: 588, column: 52)
!4725 = !DILocation(line: 588, column: 48, scope: !4712)
!4726 = !DILocation(line: 588, column: 7, scope: !4712)
!4727 = distinct !{!4727, !4722, !4728, !2472}
!4728 = !DILocation(line: 590, column: 7, scope: !4708)
!4729 = !DILocation(line: 592, column: 16, scope: !4730)
!4730 = distinct !DILexicalBlock(scope: !4709, file: !3, line: 592, column: 7)
!4731 = !DILocation(line: 592, column: 19, scope: !4730)
!4732 = !DILocation(line: 592, column: 14, scope: !4730)
!4733 = !DILocation(line: 592, column: 12, scope: !4730)
!4734 = !DILocation(line: 592, column: 24, scope: !4735)
!4735 = distinct !DILexicalBlock(scope: !4730, file: !3, line: 592, column: 7)
!4736 = !DILocation(line: 592, column: 29, scope: !4735)
!4737 = !DILocation(line: 592, column: 34, scope: !4735)
!4738 = !DILocation(line: 592, column: 32, scope: !4735)
!4739 = !DILocation(line: 592, column: 26, scope: !4735)
!4740 = !DILocation(line: 592, column: 7, scope: !4730)
!4741 = !DILocation(line: 593, column: 21, scope: !4742)
!4742 = distinct !DILexicalBlock(scope: !4735, file: !3, line: 592, column: 42)
!4743 = !DILocation(line: 593, column: 27, scope: !4742)
!4744 = !DILocation(line: 593, column: 32, scope: !4742)
!4745 = !DILocation(line: 593, column: 30, scope: !4742)
!4746 = !DILocation(line: 593, column: 11, scope: !4742)
!4747 = !DILocation(line: 593, column: 16, scope: !4742)
!4748 = !DILocation(line: 593, column: 14, scope: !4742)
!4749 = !DILocation(line: 593, column: 9, scope: !4742)
!4750 = !DILocation(line: 593, column: 19, scope: !4742)
!4751 = !DILocation(line: 594, column: 16, scope: !4752)
!4752 = distinct !DILexicalBlock(scope: !4742, file: !3, line: 594, column: 9)
!4753 = !DILocation(line: 594, column: 24, scope: !4752)
!4754 = !DILocation(line: 594, column: 14, scope: !4752)
!4755 = !DILocation(line: 594, column: 31, scope: !4756)
!4756 = distinct !DILexicalBlock(scope: !4752, file: !3, line: 594, column: 9)
!4757 = !DILocation(line: 594, column: 36, scope: !4756)
!4758 = !DILocation(line: 594, column: 33, scope: !4756)
!4759 = !DILocation(line: 594, column: 9, scope: !4752)
!4760 = !DILocation(line: 594, column: 51, scope: !4756)
!4761 = !DILocation(line: 594, column: 53, scope: !4756)
!4762 = !DILocation(line: 594, column: 60, scope: !4756)
!4763 = !DILocation(line: 594, column: 65, scope: !4756)
!4764 = !DILocation(line: 594, column: 63, scope: !4756)
!4765 = !DILocation(line: 594, column: 69, scope: !4756)
!4766 = !DILocation(line: 594, column: 67, scope: !4756)
!4767 = !DILocation(line: 594, column: 58, scope: !4756)
!4768 = !DILocation(line: 594, column: 48, scope: !4756)
!4769 = !DILocation(line: 594, column: 45, scope: !4756)
!4770 = !DILocation(line: 594, column: 41, scope: !4756)
!4771 = !DILocation(line: 594, column: 9, scope: !4756)
!4772 = distinct !{!4772, !4759, !4773, !2472}
!4773 = !DILocation(line: 594, column: 70, scope: !4752)
!4774 = !DILocation(line: 595, column: 16, scope: !4742)
!4775 = !DILocation(line: 595, column: 11, scope: !4742)
!4776 = !DILocation(line: 595, column: 9, scope: !4742)
!4777 = !DILocation(line: 595, column: 14, scope: !4742)
!4778 = !DILocation(line: 596, column: 7, scope: !4742)
!4779 = !DILocation(line: 592, column: 38, scope: !4735)
!4780 = !DILocation(line: 592, column: 7, scope: !4735)
!4781 = distinct !{!4781, !4740, !4782, !2472}
!4782 = !DILocation(line: 596, column: 7, scope: !4730)
!4783 = !DILocation(line: 597, column: 13, scope: !4709)
!4784 = !DILocation(line: 597, column: 10, scope: !4709)
!4785 = !DILocation(line: 598, column: 7, scope: !4709)
!4786 = !DILocation(line: 600, column: 3, scope: !4684)
!4787 = !DILocation(line: 603, column: 7, scope: !4788)
!4788 = distinct !DILexicalBlock(scope: !348, file: !3, line: 603, column: 7)
!4789 = !DILocation(line: 603, column: 9, scope: !4788)
!4790 = !DILocation(line: 603, column: 7, scope: !348)
!4791 = !DILocation(line: 604, column: 8, scope: !4792)
!4792 = distinct !DILexicalBlock(scope: !4788, file: !3, line: 603, column: 17)
!4793 = !DILocation(line: 605, column: 8, scope: !4792)
!4794 = !DILocation(line: 606, column: 5, scope: !4792)
!4795 = !DILocation(line: 606, column: 15, scope: !4792)
!4796 = !DILocation(line: 606, column: 12, scope: !4792)
!4797 = !DILocation(line: 606, column: 19, scope: !4792)
!4798 = !DILocation(line: 607, column: 9, scope: !4799)
!4799 = distinct !DILexicalBlock(scope: !4792, file: !3, line: 606, column: 25)
!4800 = !DILocation(line: 608, column: 10, scope: !4799)
!4801 = distinct !{!4801, !4794, !4802, !2472}
!4802 = !DILocation(line: 609, column: 5, scope: !4792)
!4803 = !DILocation(line: 610, column: 3, scope: !4792)
!4804 = !DILocation(line: 611, column: 16, scope: !4805)
!4805 = distinct !DILexicalBlock(scope: !4788, file: !3, line: 610, column: 10)
!4806 = !DILocation(line: 611, column: 20, scope: !4805)
!4807 = !DILocation(line: 611, column: 19, scope: !4805)
!4808 = !DILocation(line: 611, column: 9, scope: !4805)
!4809 = !DILocation(line: 611, column: 7, scope: !4805)
!4810 = !DILocation(line: 612, column: 9, scope: !4811)
!4811 = distinct !DILexicalBlock(scope: !4805, file: !3, line: 612, column: 9)
!4812 = !DILocation(line: 612, column: 11, scope: !4811)
!4813 = !DILocation(line: 612, column: 9, scope: !4805)
!4814 = !DILocation(line: 613, column: 40, scope: !4815)
!4815 = distinct !DILexicalBlock(scope: !4811, file: !3, line: 612, column: 21)
!4816 = !DILocation(line: 613, column: 38, scope: !4815)
!4817 = !DILocation(line: 613, column: 21, scope: !4815)
!4818 = !DILocation(line: 613, column: 12, scope: !4815)
!4819 = !DILocation(line: 613, column: 10, scope: !4815)
!4820 = !DILocation(line: 614, column: 16, scope: !4815)
!4821 = !DILocation(line: 614, column: 28, scope: !4815)
!4822 = !DILocation(line: 614, column: 18, scope: !4815)
!4823 = !DILocation(line: 614, column: 10, scope: !4815)
!4824 = !DILocation(line: 614, column: 7, scope: !4815)
!4825 = !DILocation(line: 614, column: 14, scope: !4815)
!4826 = !DILocation(line: 615, column: 10, scope: !4815)
!4827 = !DILocation(line: 616, column: 10, scope: !4815)
!4828 = !DILocation(line: 617, column: 16, scope: !4815)
!4829 = !DILocation(line: 617, column: 10, scope: !4815)
!4830 = !DILocation(line: 617, column: 7, scope: !4815)
!4831 = !DILocation(line: 617, column: 14, scope: !4815)
!4832 = !DILocation(line: 618, column: 5, scope: !4815)
!4833 = !DILocation(line: 619, column: 16, scope: !4834)
!4834 = distinct !DILexicalBlock(scope: !4811, file: !3, line: 618, column: 12)
!4835 = !DILocation(line: 619, column: 10, scope: !4834)
!4836 = !DILocation(line: 619, column: 7, scope: !4834)
!4837 = !DILocation(line: 619, column: 14, scope: !4834)
!4838 = !DILocation(line: 624, column: 20, scope: !348)
!4839 = !DILocation(line: 624, column: 8, scope: !348)
!4840 = !DILocation(line: 624, column: 6, scope: !348)
!4841 = !DILocation(line: 625, column: 12, scope: !4842)
!4842 = distinct !DILexicalBlock(scope: !348, file: !3, line: 625, column: 3)
!4843 = !DILocation(line: 625, column: 10, scope: !4842)
!4844 = !DILocation(line: 625, column: 8, scope: !4842)
!4845 = !DILocation(line: 625, column: 16, scope: !4846)
!4846 = distinct !DILexicalBlock(scope: !4842, file: !3, line: 625, column: 3)
!4847 = !DILocation(line: 625, column: 18, scope: !4846)
!4848 = !DILocation(line: 625, column: 3, scope: !4842)
!4849 = !DILocation(line: 626, column: 12, scope: !4850)
!4850 = distinct !DILexicalBlock(scope: !4846, file: !3, line: 625, column: 29)
!4851 = !DILocation(line: 626, column: 20, scope: !4850)
!4852 = !DILocation(line: 626, column: 17, scope: !4850)
!4853 = !DILocation(line: 626, column: 15, scope: !4850)
!4854 = !DILocation(line: 626, column: 7, scope: !4850)
!4855 = !DILocation(line: 626, column: 5, scope: !4850)
!4856 = !DILocation(line: 626, column: 10, scope: !4850)
!4857 = !DILocation(line: 627, column: 8, scope: !4850)
!4858 = !DILocation(line: 628, column: 3, scope: !4850)
!4859 = !DILocation(line: 625, column: 25, scope: !4846)
!4860 = !DILocation(line: 625, column: 3, scope: !4846)
!4861 = distinct !{!4861, !4848, !4862, !2472}
!4862 = !DILocation(line: 628, column: 3, scope: !4842)
!4863 = !DILocation(line: 631, column: 12, scope: !4864)
!4864 = distinct !DILexicalBlock(scope: !348, file: !3, line: 631, column: 3)
!4865 = !DILocation(line: 631, column: 10, scope: !4864)
!4866 = !DILocation(line: 631, column: 8, scope: !4864)
!4867 = !DILocation(line: 631, column: 16, scope: !4868)
!4868 = distinct !DILexicalBlock(scope: !4864, file: !3, line: 631, column: 3)
!4869 = !DILocation(line: 631, column: 18, scope: !4868)
!4870 = !DILocation(line: 631, column: 3, scope: !4864)
!4871 = !DILocation(line: 632, column: 13, scope: !4872)
!4872 = distinct !DILexicalBlock(scope: !4873, file: !3, line: 632, column: 5)
!4873 = distinct !DILexicalBlock(scope: !4868, file: !3, line: 631, column: 29)
!4874 = !DILocation(line: 632, column: 22, scope: !4872)
!4875 = !DILocation(line: 632, column: 10, scope: !4872)
!4876 = !DILocation(line: 632, column: 27, scope: !4877)
!4877 = distinct !DILexicalBlock(scope: !4872, file: !3, line: 632, column: 5)
!4878 = !DILocation(line: 632, column: 32, scope: !4877)
!4879 = !DILocation(line: 632, column: 29, scope: !4877)
!4880 = !DILocation(line: 632, column: 35, scope: !4877)
!4881 = !DILocation(line: 632, column: 38, scope: !4877)
!4882 = !DILocation(line: 632, column: 43, scope: !4877)
!4883 = !DILocation(line: 632, column: 48, scope: !4877)
!4884 = !DILocation(line: 632, column: 46, scope: !4877)
!4885 = !DILocation(line: 632, column: 40, scope: !4877)
!4886 = !DILocation(line: 0, scope: !4877)
!4887 = !DILocation(line: 632, column: 5, scope: !4872)
!4888 = !DILocation(line: 632, column: 67, scope: !4877)
!4889 = !DILocation(line: 632, column: 62, scope: !4877)
!4890 = !DILocation(line: 632, column: 74, scope: !4877)
!4891 = !DILocation(line: 632, column: 78, scope: !4877)
!4892 = !DILocation(line: 632, column: 76, scope: !4877)
!4893 = !DILocation(line: 632, column: 72, scope: !4877)
!4894 = !DILocation(line: 632, column: 59, scope: !4877)
!4895 = !DILocation(line: 632, column: 56, scope: !4877)
!4896 = !DILocation(line: 632, column: 52, scope: !4877)
!4897 = !DILocation(line: 632, column: 5, scope: !4877)
!4898 = distinct !{!4898, !4887, !4899, !2472}
!4899 = !DILocation(line: 632, column: 79, scope: !4872)
!4900 = !DILocation(line: 633, column: 18, scope: !4873)
!4901 = !DILocation(line: 633, column: 8, scope: !4873)
!4902 = !DILocation(line: 633, column: 13, scope: !4873)
!4903 = !DILocation(line: 633, column: 11, scope: !4873)
!4904 = !DILocation(line: 633, column: 5, scope: !4873)
!4905 = !DILocation(line: 633, column: 16, scope: !4873)
!4906 = !DILocation(line: 634, column: 3, scope: !4873)
!4907 = !DILocation(line: 631, column: 25, scope: !4868)
!4908 = !DILocation(line: 631, column: 3, scope: !4868)
!4909 = distinct !{!4909, !4870, !4910, !2472}
!4910 = !DILocation(line: 634, column: 3, scope: !4864)
!4911 = !DILocation(line: 637, column: 11, scope: !348)
!4912 = !DILocation(line: 637, column: 3, scope: !348)
!4913 = !DILocation(line: 639, column: 10, scope: !4914)
!4914 = distinct !DILexicalBlock(scope: !348, file: !3, line: 637, column: 17)
!4915 = !DILocation(line: 640, column: 16, scope: !4916)
!4916 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 640, column: 7)
!4917 = !DILocation(line: 640, column: 14, scope: !4916)
!4918 = !DILocation(line: 640, column: 12, scope: !4916)
!4919 = !DILocation(line: 640, column: 20, scope: !4920)
!4920 = distinct !DILexicalBlock(scope: !4916, file: !3, line: 640, column: 7)
!4921 = !DILocation(line: 640, column: 22, scope: !4920)
!4922 = !DILocation(line: 640, column: 7, scope: !4916)
!4923 = !DILocation(line: 640, column: 42, scope: !4920)
!4924 = !DILocation(line: 640, column: 39, scope: !4920)
!4925 = !DILocation(line: 640, column: 36, scope: !4920)
!4926 = !DILocation(line: 640, column: 33, scope: !4920)
!4927 = !DILocation(line: 640, column: 29, scope: !4920)
!4928 = !DILocation(line: 640, column: 7, scope: !4920)
!4929 = distinct !{!4929, !4922, !4930, !2472}
!4930 = !DILocation(line: 640, column: 43, scope: !4916)
!4931 = !DILocation(line: 641, column: 15, scope: !4914)
!4932 = !DILocation(line: 641, column: 18, scope: !4914)
!4933 = !DILocation(line: 641, column: 14, scope: !4914)
!4934 = !DILocation(line: 641, column: 26, scope: !4914)
!4935 = !DILocation(line: 641, column: 32, scope: !4914)
!4936 = !DILocation(line: 641, column: 31, scope: !4914)
!4937 = !DILocation(line: 641, column: 7, scope: !4914)
!4938 = !DILocation(line: 641, column: 12, scope: !4914)
!4939 = !DILocation(line: 642, column: 7, scope: !4914)
!4940 = !DILocation(line: 645, column: 10, scope: !4914)
!4941 = !DILocation(line: 646, column: 16, scope: !4942)
!4942 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 646, column: 7)
!4943 = !DILocation(line: 646, column: 14, scope: !4942)
!4944 = !DILocation(line: 646, column: 12, scope: !4942)
!4945 = !DILocation(line: 646, column: 20, scope: !4946)
!4946 = distinct !DILexicalBlock(scope: !4942, file: !3, line: 646, column: 7)
!4947 = !DILocation(line: 646, column: 22, scope: !4946)
!4948 = !DILocation(line: 646, column: 7, scope: !4942)
!4949 = !DILocation(line: 646, column: 42, scope: !4946)
!4950 = !DILocation(line: 646, column: 39, scope: !4946)
!4951 = !DILocation(line: 646, column: 36, scope: !4946)
!4952 = !DILocation(line: 646, column: 33, scope: !4946)
!4953 = !DILocation(line: 646, column: 29, scope: !4946)
!4954 = !DILocation(line: 646, column: 7, scope: !4946)
!4955 = distinct !{!4955, !4948, !4956, !2472}
!4956 = !DILocation(line: 646, column: 43, scope: !4942)
!4957 = !DILocation(line: 647, column: 15, scope: !4914)
!4958 = !DILocation(line: 647, column: 18, scope: !4914)
!4959 = !DILocation(line: 647, column: 14, scope: !4914)
!4960 = !DILocation(line: 647, column: 26, scope: !4914)
!4961 = !DILocation(line: 647, column: 32, scope: !4914)
!4962 = !DILocation(line: 647, column: 31, scope: !4914)
!4963 = !DILocation(line: 647, column: 7, scope: !4914)
!4964 = !DILocation(line: 647, column: 12, scope: !4914)
!4965 = !DILocation(line: 648, column: 12, scope: !4914)
!4966 = !DILocation(line: 648, column: 20, scope: !4914)
!4967 = !DILocation(line: 648, column: 18, scope: !4914)
!4968 = !DILocation(line: 648, column: 10, scope: !4914)
!4969 = !DILocation(line: 649, column: 14, scope: !4970)
!4970 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 649, column: 7)
!4971 = !DILocation(line: 649, column: 12, scope: !4970)
!4972 = !DILocation(line: 649, column: 19, scope: !4973)
!4973 = distinct !DILexicalBlock(scope: !4970, file: !3, line: 649, column: 7)
!4974 = !DILocation(line: 649, column: 24, scope: !4973)
!4975 = !DILocation(line: 649, column: 21, scope: !4973)
!4976 = !DILocation(line: 649, column: 7, scope: !4970)
!4977 = !DILocation(line: 649, column: 42, scope: !4973)
!4978 = !DILocation(line: 649, column: 39, scope: !4973)
!4979 = !DILocation(line: 649, column: 36, scope: !4973)
!4980 = !DILocation(line: 649, column: 33, scope: !4973)
!4981 = !DILocation(line: 649, column: 29, scope: !4973)
!4982 = !DILocation(line: 649, column: 7, scope: !4973)
!4983 = distinct !{!4983, !4976, !4984, !2472}
!4984 = !DILocation(line: 649, column: 43, scope: !4970)
!4985 = !DILocation(line: 650, column: 15, scope: !4914)
!4986 = !DILocation(line: 650, column: 18, scope: !4914)
!4987 = !DILocation(line: 650, column: 14, scope: !4914)
!4988 = !DILocation(line: 650, column: 26, scope: !4914)
!4989 = !DILocation(line: 650, column: 32, scope: !4914)
!4990 = !DILocation(line: 650, column: 31, scope: !4914)
!4991 = !DILocation(line: 650, column: 7, scope: !4914)
!4992 = !DILocation(line: 650, column: 12, scope: !4914)
!4993 = !DILocation(line: 651, column: 7, scope: !4914)
!4994 = !DILocation(line: 653, column: 16, scope: !4995)
!4995 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 653, column: 7)
!4996 = !DILocation(line: 653, column: 14, scope: !4995)
!4997 = !DILocation(line: 653, column: 12, scope: !4995)
!4998 = !DILocation(line: 653, column: 20, scope: !4999)
!4999 = distinct !DILexicalBlock(scope: !4995, file: !3, line: 653, column: 7)
!5000 = !DILocation(line: 653, column: 22, scope: !4999)
!5001 = !DILocation(line: 653, column: 7, scope: !4995)
!5002 = !DILocation(line: 654, column: 17, scope: !5003)
!5003 = distinct !DILexicalBlock(scope: !4999, file: !3, line: 653, column: 32)
!5004 = !DILocation(line: 654, column: 19, scope: !5003)
!5005 = !DILocation(line: 654, column: 14, scope: !5003)
!5006 = !DILocation(line: 654, column: 29, scope: !5003)
!5007 = !DILocation(line: 654, column: 26, scope: !5003)
!5008 = !DILocation(line: 654, column: 24, scope: !5003)
!5009 = !DILocation(line: 654, column: 12, scope: !5003)
!5010 = !DILocation(line: 655, column: 21, scope: !5003)
!5011 = !DILocation(line: 655, column: 23, scope: !5003)
!5012 = !DILocation(line: 655, column: 18, scope: !5003)
!5013 = !DILocation(line: 655, column: 30, scope: !5003)
!5014 = !DILocation(line: 655, column: 28, scope: !5003)
!5015 = !DILocation(line: 655, column: 12, scope: !5003)
!5016 = !DILocation(line: 655, column: 9, scope: !5003)
!5017 = !DILocation(line: 655, column: 15, scope: !5003)
!5018 = !DILocation(line: 656, column: 21, scope: !5003)
!5019 = !DILocation(line: 656, column: 12, scope: !5003)
!5020 = !DILocation(line: 656, column: 14, scope: !5003)
!5021 = !DILocation(line: 656, column: 9, scope: !5003)
!5022 = !DILocation(line: 656, column: 19, scope: !5003)
!5023 = !DILocation(line: 657, column: 7, scope: !5003)
!5024 = !DILocation(line: 653, column: 28, scope: !4999)
!5025 = !DILocation(line: 653, column: 7, scope: !4999)
!5026 = distinct !{!5026, !5001, !5027, !2472}
!5027 = !DILocation(line: 657, column: 7, scope: !4995)
!5028 = !DILocation(line: 658, column: 16, scope: !5029)
!5029 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 658, column: 7)
!5030 = !DILocation(line: 658, column: 14, scope: !5029)
!5031 = !DILocation(line: 658, column: 12, scope: !5029)
!5032 = !DILocation(line: 658, column: 20, scope: !5033)
!5033 = distinct !DILexicalBlock(scope: !5029, file: !3, line: 658, column: 7)
!5034 = !DILocation(line: 658, column: 22, scope: !5033)
!5035 = !DILocation(line: 658, column: 7, scope: !5029)
!5036 = !DILocation(line: 659, column: 17, scope: !5037)
!5037 = distinct !DILexicalBlock(scope: !5033, file: !3, line: 658, column: 32)
!5038 = !DILocation(line: 659, column: 19, scope: !5037)
!5039 = !DILocation(line: 659, column: 14, scope: !5037)
!5040 = !DILocation(line: 659, column: 29, scope: !5037)
!5041 = !DILocation(line: 659, column: 26, scope: !5037)
!5042 = !DILocation(line: 659, column: 24, scope: !5037)
!5043 = !DILocation(line: 659, column: 12, scope: !5037)
!5044 = !DILocation(line: 660, column: 21, scope: !5037)
!5045 = !DILocation(line: 660, column: 23, scope: !5037)
!5046 = !DILocation(line: 660, column: 18, scope: !5037)
!5047 = !DILocation(line: 660, column: 30, scope: !5037)
!5048 = !DILocation(line: 660, column: 28, scope: !5037)
!5049 = !DILocation(line: 660, column: 12, scope: !5037)
!5050 = !DILocation(line: 660, column: 9, scope: !5037)
!5051 = !DILocation(line: 660, column: 15, scope: !5037)
!5052 = !DILocation(line: 661, column: 21, scope: !5037)
!5053 = !DILocation(line: 661, column: 12, scope: !5037)
!5054 = !DILocation(line: 661, column: 14, scope: !5037)
!5055 = !DILocation(line: 661, column: 9, scope: !5037)
!5056 = !DILocation(line: 661, column: 19, scope: !5037)
!5057 = !DILocation(line: 662, column: 7, scope: !5037)
!5058 = !DILocation(line: 658, column: 28, scope: !5033)
!5059 = !DILocation(line: 658, column: 7, scope: !5033)
!5060 = distinct !{!5060, !5035, !5061, !2472}
!5061 = !DILocation(line: 662, column: 7, scope: !5029)
!5062 = !DILocation(line: 663, column: 15, scope: !5063)
!5063 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 663, column: 7)
!5064 = !DILocation(line: 663, column: 26, scope: !5063)
!5065 = !DILocation(line: 663, column: 24, scope: !5063)
!5066 = !DILocation(line: 663, column: 12, scope: !5063)
!5067 = !DILocation(line: 663, column: 30, scope: !5068)
!5068 = distinct !DILexicalBlock(scope: !5063, file: !3, line: 663, column: 7)
!5069 = !DILocation(line: 663, column: 32, scope: !5068)
!5070 = !DILocation(line: 663, column: 7, scope: !5063)
!5071 = !DILocation(line: 663, column: 52, scope: !5068)
!5072 = !DILocation(line: 663, column: 49, scope: !5068)
!5073 = !DILocation(line: 663, column: 46, scope: !5068)
!5074 = !DILocation(line: 663, column: 43, scope: !5068)
!5075 = !DILocation(line: 663, column: 39, scope: !5068)
!5076 = !DILocation(line: 663, column: 7, scope: !5068)
!5077 = distinct !{!5077, !5070, !5078, !2472}
!5078 = !DILocation(line: 663, column: 53, scope: !5063)
!5079 = !DILocation(line: 664, column: 11, scope: !5080)
!5080 = distinct !DILexicalBlock(scope: !4914, file: !3, line: 664, column: 11)
!5081 = !DILocation(line: 664, column: 14, scope: !5080)
!5082 = !DILocation(line: 664, column: 11, scope: !4914)
!5083 = !DILocation(line: 665, column: 16, scope: !5084)
!5084 = distinct !DILexicalBlock(scope: !5080, file: !3, line: 664, column: 20)
!5085 = !DILocation(line: 665, column: 9, scope: !5084)
!5086 = !DILocation(line: 665, column: 14, scope: !5084)
!5087 = !DILocation(line: 666, column: 16, scope: !5084)
!5088 = !DILocation(line: 666, column: 9, scope: !5084)
!5089 = !DILocation(line: 666, column: 14, scope: !5084)
!5090 = !DILocation(line: 667, column: 16, scope: !5084)
!5091 = !DILocation(line: 667, column: 9, scope: !5084)
!5092 = !DILocation(line: 667, column: 14, scope: !5084)
!5093 = !DILocation(line: 668, column: 7, scope: !5084)
!5094 = !DILocation(line: 669, column: 17, scope: !5095)
!5095 = distinct !DILexicalBlock(scope: !5080, file: !3, line: 668, column: 14)
!5096 = !DILocation(line: 669, column: 16, scope: !5095)
!5097 = !DILocation(line: 669, column: 9, scope: !5095)
!5098 = !DILocation(line: 669, column: 14, scope: !5095)
!5099 = !DILocation(line: 670, column: 17, scope: !5095)
!5100 = !DILocation(line: 670, column: 16, scope: !5095)
!5101 = !DILocation(line: 670, column: 9, scope: !5095)
!5102 = !DILocation(line: 670, column: 14, scope: !5095)
!5103 = !DILocation(line: 671, column: 17, scope: !5095)
!5104 = !DILocation(line: 671, column: 16, scope: !5095)
!5105 = !DILocation(line: 671, column: 9, scope: !5095)
!5106 = !DILocation(line: 671, column: 14, scope: !5095)
!5107 = !DILocation(line: 673, column: 3, scope: !4914)
!5108 = !DILocation(line: 674, column: 10, scope: !348)
!5109 = !DILocation(line: 674, column: 12, scope: !348)
!5110 = !DILocation(line: 674, column: 3, scope: !348)
