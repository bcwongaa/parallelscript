; ModuleID = '../src/ieee754_head.c'
source_filename = "../src/ieee754_head.c"
target datalayout = "e-m:o-i64:64-i128:128-n32:64-S128"
target triple = "arm64-apple-macosx13.0.0"

@pts_ieee754_atan.atanhi = internal unnamed_addr constant [4 x double] [double 0x3FDDAC670561BB4F, double 0x3FE921FB54442D18, double 0x3FEF730BD281F69B, double 0x3FF921FB54442D18], align 8, !dbg !0
@pts_ieee754_atan.atanlo = internal constant [4 x double] [double 0x3C7A2B7F222F65E2, double 0x3C81A62633145C07, double 0x3C7007887AF0CBBD, double 0x3C91A62633145C07], align 8, !dbg !154
@pts_ieee754_atan2.tiny = internal global double 1.000000e-300, align 8, !dbg !168
@pts_ieee754_atan2.pi_lo = internal global double 0x3CA1A62633145C07, align 8, !dbg !197
@pts_ieee754_exp.halF = internal unnamed_addr constant [2 x double] [double 5.000000e-01, double -5.000000e-01], align 8, !dbg !229
@pts_ieee754_exp.ln2HI = internal unnamed_addr constant [2 x double] [double 0x3FE62E42FEE00000, double 0xBFE62E42FEE00000], align 8, !dbg !238
@pts_ieee754_exp.ln2LO = internal unnamed_addr constant [2 x double] [double 0x3DEA39EF35793C76, double 0xBDEA39EF35793C76], align 8, !dbg !240
@pts_ieee754_exp.huge = internal global double 1.000000e+300, align 8, !dbg !256
@pts_ieee754_exp.twom1000 = internal global double 0x170000000000000, align 8, !dbg !258
@pts_ieee754_exp.two1023 = internal global double 0x7FE0000000000000, align 8, !dbg !260
@pts_ieee754_expm1.huge = internal global double 1.000000e+300, align 8, !dbg !501
@pts_ieee754_cosh.huge = internal global double 1.000000e+300, align 8, !dbg !566
@pts_ieee754_tanh.tiny = internal constant double 1.000000e-300, align 8, !dbg !588
@__ieee754_rem_pio2.two_over_pi = internal unnamed_addr constant [66 x i32] [i32 10680707, i32 7228996, i32 1387004, i32 2578385, i32 16069853, i32 12639074, i32 9804092, i32 4427841, i32 16666979, i32 11263675, i32 12935607, i32 2387514, i32 4345298, i32 14681673, i32 3074569, i32 13734428, i32 16653803, i32 1880361, i32 10960616, i32 8533493, i32 3062596, i32 8710556, i32 7349940, i32 6258241, i32 3772886, i32 3769171, i32 3798172, i32 8675211, i32 12450088, i32 3874808, i32 9961438, i32 366607, i32 15675153, i32 9132554, i32 7151469, i32 3571407, i32 2607881, i32 12013382, i32 4155038, i32 6285869, i32 7677882, i32 13102053, i32 15825725, i32 473591, i32 9065106, i32 15363067, i32 6271263, i32 9264392, i32 5636912, i32 4652155, i32 7056368, i32 13614112, i32 10155062, i32 1944035, i32 9527646, i32 15080200, i32 6658437, i32 6231200, i32 6832269, i32 16767104, i32 5075751, i32 3212806, i32 1398474, i32 7579849, i32 6349435, i32 12618859], align 4, !dbg !637
@__ieee754_rem_pio2.npio2_hw = internal unnamed_addr constant [32 x i32] [i32 1073291771, i32 1074340347, i32 1074977148, i32 1075388923, i32 1075800698, i32 1076025724, i32 1076231611, i32 1076437499, i32 1076643386, i32 1076849274, i32 1076971356, i32 1077074300, i32 1077177244, i32 1077280187, i32 1077383131, i32 1077486075, i32 1077589019, i32 1077691962, i32 1077794906, i32 1077897850, i32 1077968460, i32 1078019932, i32 1078071404, i32 1078122876, i32 1078174348, i32 1078225820, i32 1078277292, i32 1078328763, i32 1078380235, i32 1078431707, i32 1078483179, i32 1078534651], align 4, !dbg !686

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_acos(double noundef %0) local_unnamed_addr #0 !dbg !22 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !24, metadata !DIExpression()), !dbg !871
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !878
  %2 = bitcast double %0 to i64, !dbg !880
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !878
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !35, metadata !DIExpression()), !dbg !881
  %3 = lshr i64 %2, 32, !dbg !882
  %4 = trunc i64 %3 to i32, !dbg !882
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !33, metadata !DIExpression()), !dbg !871
  %5 = and i32 %4, 2147483647, !dbg !883
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !34, metadata !DIExpression()), !dbg !871
  %6 = icmp ugt i32 %5, 1072693247, !dbg !884
  br i1 %6, label %7, label %15, !dbg !885

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !886
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !886
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !40, metadata !DIExpression()), !dbg !888
  %8 = trunc i64 %2 to i32, !dbg !889
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !37, metadata !DIExpression()), !dbg !890
  %9 = add nsw i32 %5, -1072693248, !dbg !891
  %10 = or i32 %9, %8, !dbg !893
  %11 = icmp eq i32 %10, 0, !dbg !894
  %12 = icmp sgt i32 %4, 0, !dbg !895
  %13 = select i1 %12, double 0.000000e+00, double 0x400921FB54442D18, !dbg !895
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !895
  br label %81

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !896
  br i1 %16, label %17, label %36, !dbg !897

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1012924417, !dbg !898
  br i1 %18, label %81, label %19, !dbg !901

19:                                               ; preds = %17
  %20 = fmul double %0, %0, !dbg !902
  tail call void @llvm.dbg.value(metadata double %20, metadata !25, metadata !DIExpression()), !dbg !871
  %21 = tail call double @llvm.fmuladd.f64(double %20, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !903
  %22 = tail call double @llvm.fmuladd.f64(double %20, double %21, double 0xBFA48228B5688F3B), !dbg !904
  %23 = tail call double @llvm.fmuladd.f64(double %20, double %22, double 0x3FC9C1550E884455), !dbg !905
  %24 = tail call double @llvm.fmuladd.f64(double %20, double %23, double 0xBFD4D61203EB6F7D), !dbg !906
  %25 = tail call double @llvm.fmuladd.f64(double %20, double %24, double 0x3FC5555555555555), !dbg !907
  %26 = fmul double %20, %25, !dbg !908
  tail call void @llvm.dbg.value(metadata double %26, metadata !26, metadata !DIExpression()), !dbg !871
  %27 = tail call double @llvm.fmuladd.f64(double %20, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !909
  %28 = tail call double @llvm.fmuladd.f64(double %20, double %27, double 0x40002AE59C598AC8), !dbg !910
  %29 = tail call double @llvm.fmuladd.f64(double %20, double %28, double 0xC0033A271C8A2D4B), !dbg !911
  %30 = tail call double @llvm.fmuladd.f64(double %20, double %29, double 1.000000e+00), !dbg !912
  tail call void @llvm.dbg.value(metadata double %30, metadata !27, metadata !DIExpression()), !dbg !871
  %31 = fdiv double %26, %30, !dbg !913
  tail call void @llvm.dbg.value(metadata double %31, metadata !28, metadata !DIExpression()), !dbg !871
  %32 = fneg double %0, !dbg !914
  %33 = tail call double @llvm.fmuladd.f64(double %32, double %31, double 0x3C91A62633145C07), !dbg !914
  %34 = fsub double %33, %0, !dbg !915
  %35 = fadd double %34, 0x3FF921FB54442D18, !dbg !915
  br label %81, !dbg !916

36:                                               ; preds = %15
  %37 = icmp slt i64 %2, 0, !dbg !917
  br i1 %37, label %38, label %56, !dbg !918

38:                                               ; preds = %36
  %39 = fadd double %0, 1.000000e+00, !dbg !919
  %40 = fmul double %39, 5.000000e-01, !dbg !921
  tail call void @llvm.dbg.value(metadata double %40, metadata !25, metadata !DIExpression()), !dbg !871
  %41 = tail call double @llvm.fmuladd.f64(double %40, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !922
  %42 = tail call double @llvm.fmuladd.f64(double %40, double %41, double 0xBFA48228B5688F3B), !dbg !923
  %43 = tail call double @llvm.fmuladd.f64(double %40, double %42, double 0x3FC9C1550E884455), !dbg !924
  %44 = tail call double @llvm.fmuladd.f64(double %40, double %43, double 0xBFD4D61203EB6F7D), !dbg !925
  %45 = tail call double @llvm.fmuladd.f64(double %40, double %44, double 0x3FC5555555555555), !dbg !926
  %46 = fmul double %40, %45, !dbg !927
  tail call void @llvm.dbg.value(metadata double %46, metadata !26, metadata !DIExpression()), !dbg !871
  %47 = tail call double @llvm.fmuladd.f64(double %40, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !928
  %48 = tail call double @llvm.fmuladd.f64(double %40, double %47, double 0x40002AE59C598AC8), !dbg !929
  %49 = tail call double @llvm.fmuladd.f64(double %40, double %48, double 0xC0033A271C8A2D4B), !dbg !930
  %50 = tail call double @llvm.fmuladd.f64(double %40, double %49, double 1.000000e+00), !dbg !931
  tail call void @llvm.dbg.value(metadata double %50, metadata !27, metadata !DIExpression()), !dbg !871
  %51 = tail call double @llvm.sqrt.f64(double %40), !dbg !932
  tail call void @llvm.dbg.value(metadata double %51, metadata !30, metadata !DIExpression()), !dbg !871
  %52 = fdiv double %46, %50, !dbg !933
  tail call void @llvm.dbg.value(metadata double %52, metadata !28, metadata !DIExpression()), !dbg !871
  %53 = tail call double @llvm.fmuladd.f64(double %52, double %51, double 0xBC91A62633145C07), !dbg !934
  tail call void @llvm.dbg.value(metadata double %53, metadata !29, metadata !DIExpression()), !dbg !871
  %54 = fadd double %51, %53, !dbg !935
  %55 = tail call double @llvm.fmuladd.f64(double %54, double -2.000000e+00, double 0x400921FB54442D18), !dbg !936
  br label %81, !dbg !937

56:                                               ; preds = %36
  %57 = fsub double 1.000000e+00, %0, !dbg !938
  %58 = fmul double %57, 5.000000e-01, !dbg !939
  tail call void @llvm.dbg.value(metadata double %58, metadata !25, metadata !DIExpression()), !dbg !871
  %59 = tail call double @llvm.sqrt.f64(double %58), !dbg !940
  tail call void @llvm.dbg.value(metadata double %59, metadata !30, metadata !DIExpression()), !dbg !871
  tail call void @llvm.dbg.value(metadata double %59, metadata !32, metadata !DIExpression()), !dbg !871
  tail call void @llvm.dbg.value(metadata double %59, metadata !872, metadata !DIExpression()), !dbg !941
  %60 = bitcast double %59 to i64, !dbg !943
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !877, metadata !DIExpression()), !dbg !941
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !42, metadata !DIExpression()), !dbg !944
  %61 = and i64 %60, -4294967296, !dbg !945
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !42, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !42, metadata !DIExpression()), !dbg !944
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !946, metadata !DIExpression()), !dbg !952
  %62 = bitcast i64 %61 to double, !dbg !954
  tail call void @llvm.dbg.value(metadata double %62, metadata !951, metadata !DIExpression()), !dbg !952
  tail call void @llvm.dbg.value(metadata double %62, metadata !32, metadata !DIExpression()), !dbg !871
  %63 = fneg double %62, !dbg !955
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %58), !dbg !955
  %65 = fadd double %59, %62, !dbg !956
  %66 = fdiv double %64, %65, !dbg !957
  tail call void @llvm.dbg.value(metadata double %66, metadata !31, metadata !DIExpression()), !dbg !871
  %67 = tail call double @llvm.fmuladd.f64(double %58, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !958
  %68 = tail call double @llvm.fmuladd.f64(double %58, double %67, double 0xBFA48228B5688F3B), !dbg !959
  %69 = tail call double @llvm.fmuladd.f64(double %58, double %68, double 0x3FC9C1550E884455), !dbg !960
  %70 = tail call double @llvm.fmuladd.f64(double %58, double %69, double 0xBFD4D61203EB6F7D), !dbg !961
  %71 = tail call double @llvm.fmuladd.f64(double %58, double %70, double 0x3FC5555555555555), !dbg !962
  %72 = fmul double %58, %71, !dbg !963
  tail call void @llvm.dbg.value(metadata double %72, metadata !26, metadata !DIExpression()), !dbg !871
  %73 = tail call double @llvm.fmuladd.f64(double %58, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !964
  %74 = tail call double @llvm.fmuladd.f64(double %58, double %73, double 0x40002AE59C598AC8), !dbg !965
  %75 = tail call double @llvm.fmuladd.f64(double %58, double %74, double 0xC0033A271C8A2D4B), !dbg !966
  %76 = tail call double @llvm.fmuladd.f64(double %58, double %75, double 1.000000e+00), !dbg !967
  tail call void @llvm.dbg.value(metadata double %76, metadata !27, metadata !DIExpression()), !dbg !871
  %77 = fdiv double %72, %76, !dbg !968
  tail call void @llvm.dbg.value(metadata double %77, metadata !28, metadata !DIExpression()), !dbg !871
  %78 = tail call double @llvm.fmuladd.f64(double %77, double %59, double %66), !dbg !969
  tail call void @llvm.dbg.value(metadata double %78, metadata !29, metadata !DIExpression()), !dbg !871
  %79 = fadd double %78, %62, !dbg !970
  %80 = fmul double %79, 2.000000e+00, !dbg !971
  br label %81, !dbg !972

81:                                               ; preds = %17, %56, %38, %19, %7
  %82 = phi double [ %14, %7 ], [ %35, %19 ], [ %55, %38 ], [ %80, %56 ], [ 0x3FF921FB54442D18, %17 ], !dbg !871
  ret double %82, !dbg !973
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.declare(metadata, metadata, metadata) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_acosh(double noundef %0) local_unnamed_addr #0 !dbg !76 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !78, metadata !DIExpression()), !dbg !974
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !975
  %2 = bitcast double %0 to i64, !dbg !977
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !975
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !82, metadata !DIExpression()), !dbg !978
  %3 = lshr i64 %2, 32, !dbg !979
  %4 = trunc i64 %3 to i32, !dbg !979
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !80, metadata !DIExpression()), !dbg !974
  %5 = trunc i64 %2 to i32, !dbg !979
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !81, metadata !DIExpression()), !dbg !974
  %6 = icmp slt i32 %4, 1072693248, !dbg !980
  br i1 %6, label %37, label %7, !dbg !982

7:                                                ; preds = %1
  %8 = icmp ugt i32 %4, 1102053375, !dbg !983
  br i1 %8, label %9, label %16, !dbg !985

9:                                                ; preds = %7
  %10 = icmp ugt i32 %4, 2146435071, !dbg !986
  br i1 %10, label %11, label %13, !dbg !989

11:                                               ; preds = %9
  %12 = fadd double %0, %0, !dbg !990
  br label %37, !dbg !992

13:                                               ; preds = %9
  %14 = tail call double @pts_ieee754_log(double noundef %0), !dbg !993
  %15 = fadd double %14, 0x3FE62E42FEFA39EF, !dbg !995
  br label %37, !dbg !996

16:                                               ; preds = %7
  %17 = add nsw i32 %4, -1072693248, !dbg !997
  %18 = or i32 %17, %5, !dbg !999
  %19 = icmp eq i32 %18, 0, !dbg !1000
  br i1 %19, label %37, label %20, !dbg !1001

20:                                               ; preds = %16
  %21 = icmp ugt i32 %4, 1073741824, !dbg !1002
  br i1 %21, label %22, label %30, !dbg !1004

22:                                               ; preds = %20
  %23 = fmul double %0, %0, !dbg !1005
  tail call void @llvm.dbg.value(metadata double %23, metadata !79, metadata !DIExpression()), !dbg !974
  %24 = fadd double %23, -1.000000e+00, !dbg !1007
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1008
  %26 = fadd double %25, %0, !dbg !1009
  %27 = fdiv double -1.000000e+00, %26, !dbg !1010
  %28 = tail call double @llvm.fmuladd.f64(double %0, double 2.000000e+00, double %27), !dbg !1010
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1011
  br label %37, !dbg !1012

30:                                               ; preds = %20
  %31 = fadd double %0, -1.000000e+00, !dbg !1013
  tail call void @llvm.dbg.value(metadata double %31, metadata !79, metadata !DIExpression()), !dbg !974
  %32 = fmul double %31, %31, !dbg !1015
  %33 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double %32), !dbg !1016
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1017
  %35 = fadd double %31, %34, !dbg !1018
  %36 = tail call double @pts_ieee754_log1p(double noundef %35), !dbg !1019
  br label %37, !dbg !1020

37:                                               ; preds = %16, %1, %30, %22, %13, %11
  %38 = phi double [ %12, %11 ], [ %15, %13 ], [ %29, %22 ], [ %36, %30 ], [ 0x7FF8000000000000, %1 ], [ 0.000000e+00, %16 ], !dbg !1021
  ret double %38, !dbg !1022
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_log(double noundef %0) local_unnamed_addr #0 !dbg !281 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !283, metadata !DIExpression()), !dbg !1023
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1024
  %2 = bitcast double %0 to i64, !dbg !1026
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1024
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !298, metadata !DIExpression()), !dbg !1027
  %3 = lshr i64 %2, 32, !dbg !1028
  %4 = trunc i64 %3 to i32, !dbg !1028
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !294, metadata !DIExpression()), !dbg !1023
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !297, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1023
  tail call void @llvm.dbg.value(metadata i32 0, metadata !293, metadata !DIExpression()), !dbg !1023
  %5 = icmp slt i32 %4, 1048576, !dbg !1029
  br i1 %5, label %6, label %18, !dbg !1030

6:                                                ; preds = %1
  %7 = trunc i64 %2 to i32, !dbg !1028
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !297, metadata !DIExpression()), !dbg !1023
  %8 = and i32 %4, 2147483647, !dbg !1031
  %9 = or i32 %8, %7, !dbg !1033
  %10 = icmp eq i32 %9, 0, !dbg !1034
  br i1 %10, label %114, label %11, !dbg !1035

11:                                               ; preds = %6
  %12 = icmp slt i64 %2, 0, !dbg !1036
  br i1 %12, label %114, label %13, !dbg !1038

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !293, metadata !DIExpression()), !dbg !1023
  %14 = fmul double %0, 0x4350000000000000, !dbg !1039
  tail call void @llvm.dbg.value(metadata double %14, metadata !283, metadata !DIExpression()), !dbg !1023
  tail call void @llvm.dbg.value(metadata double %14, metadata !872, metadata !DIExpression()), !dbg !1040
  %15 = bitcast double %14 to i64, !dbg !1042
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !877, metadata !DIExpression()), !dbg !1040
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !300, metadata !DIExpression()), !dbg !1043
  %16 = lshr i64 %15, 32, !dbg !1044
  %17 = trunc i64 %16 to i32, !dbg !1044
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !294, metadata !DIExpression()), !dbg !1023
  br label %18, !dbg !1045

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !1023
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !1023
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !283, metadata !DIExpression()), !dbg !1023
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !293, metadata !DIExpression()), !dbg !1023
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !294, metadata !DIExpression()), !dbg !1023
  %22 = icmp sgt i32 %19, 2146435071, !dbg !1046
  br i1 %22, label %23, label %25, !dbg !1048

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !1049
  br label %114, !dbg !1050

25:                                               ; preds = %18
  %26 = ashr i32 %19, 20, !dbg !1051
  %27 = add nsw i32 %26, -1023, !dbg !1052
  %28 = add nsw i32 %27, %20, !dbg !1053
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !293, metadata !DIExpression()), !dbg !1023
  %29 = and i32 %19, 1048575, !dbg !1054
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !294, metadata !DIExpression(DW_OP_constu, 1048575, DW_OP_and, DW_OP_stack_value)), !dbg !1023
  %30 = add nuw nsw i32 %29, 614244, !dbg !1055
  %31 = and i32 %30, 1048576, !dbg !1056
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !295, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !1023
  tail call void @llvm.dbg.value(metadata double %21, metadata !872, metadata !DIExpression()), !dbg !1057
  %32 = bitcast double %21 to i64, !dbg !1059
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !877, metadata !DIExpression()), !dbg !1057
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !304, metadata !DIExpression()), !dbg !1060
  %33 = and i64 %32, 4294967295, !dbg !1061
  tail call void @llvm.dbg.value(metadata i64 %33, metadata !304, metadata !DIExpression()), !dbg !1060
  %34 = or disjoint i32 %31, %29, !dbg !1061
  %35 = xor i32 %34, 1072693248, !dbg !1061
  %36 = zext nneg i32 %35 to i64
  %37 = shl nuw nsw i64 %36, 32, !dbg !1061
  %38 = or disjoint i64 %37, %33, !dbg !1061
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !304, metadata !DIExpression()), !dbg !1060
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !946, metadata !DIExpression()), !dbg !1062
  %39 = bitcast i64 %38 to double, !dbg !1064
  tail call void @llvm.dbg.value(metadata double %39, metadata !951, metadata !DIExpression()), !dbg !1062
  tail call void @llvm.dbg.value(metadata double %39, metadata !283, metadata !DIExpression()), !dbg !1023
  %40 = lshr i32 %30, 20
  %41 = add nsw i32 %28, %40, !dbg !1065
  tail call void @llvm.dbg.value(metadata i32 %41, metadata !293, metadata !DIExpression()), !dbg !1023
  %42 = fadd double %39, -1.000000e+00, !dbg !1066
  tail call void @llvm.dbg.value(metadata double %42, metadata !285, metadata !DIExpression()), !dbg !1023
  %43 = add nsw i32 %19, 2, !dbg !1067
  %44 = and i32 %43, 1048575, !dbg !1069
  %45 = icmp ult i32 %44, 3, !dbg !1070
  br i1 %45, label %46, label %68, !dbg !1071

46:                                               ; preds = %25
  %47 = fcmp oeq double %42, 0.000000e+00, !dbg !1072
  br i1 %47, label %48, label %54, !dbg !1075

48:                                               ; preds = %46
  %49 = icmp eq i32 %41, 0, !dbg !1076
  br i1 %49, label %114, label %50, !dbg !1079

50:                                               ; preds = %48
  %51 = sitofp i32 %41 to double, !dbg !1080
  tail call void @llvm.dbg.value(metadata double %51, metadata !292, metadata !DIExpression()), !dbg !1023
  %52 = fmul double %51, 0x3DEA39EF35793C76, !dbg !1082
  %53 = tail call double @llvm.fmuladd.f64(double %51, double 0x3FE62E42FEE00000, double %52), !dbg !1083
  br label %114, !dbg !1084

54:                                               ; preds = %46
  %55 = fmul double %42, %42, !dbg !1085
  %56 = tail call double @llvm.fmuladd.f64(double %42, double 0xBFD5555555555555, double 5.000000e-01), !dbg !1086
  %57 = fmul double %55, %56, !dbg !1087
  tail call void @llvm.dbg.value(metadata double %57, metadata !288, metadata !DIExpression()), !dbg !1023
  %58 = icmp eq i32 %41, 0, !dbg !1088
  br i1 %58, label %59, label %61, !dbg !1090

59:                                               ; preds = %54
  %60 = fsub double %42, %57, !dbg !1091
  br label %114, !dbg !1093

61:                                               ; preds = %54
  %62 = sitofp i32 %41 to double, !dbg !1094
  tail call void @llvm.dbg.value(metadata double %62, metadata !292, metadata !DIExpression()), !dbg !1023
  %63 = fneg double %62, !dbg !1096
  %64 = tail call double @llvm.fmuladd.f64(double %63, double 0x3DEA39EF35793C76, double %57), !dbg !1096
  %65 = fsub double %64, %42, !dbg !1097
  %66 = fneg double %65, !dbg !1098
  %67 = tail call double @llvm.fmuladd.f64(double %62, double 0x3FE62E42FEE00000, double %66), !dbg !1098
  br label %114, !dbg !1099

68:                                               ; preds = %25
  %69 = fadd double %42, 2.000000e+00, !dbg !1100
  %70 = fdiv double %42, %69, !dbg !1101
  tail call void @llvm.dbg.value(metadata double %70, metadata !286, metadata !DIExpression()), !dbg !1023
  %71 = sitofp i32 %41 to double, !dbg !1102
  tail call void @llvm.dbg.value(metadata double %71, metadata !292, metadata !DIExpression()), !dbg !1023
  %72 = fmul double %70, %70, !dbg !1103
  tail call void @llvm.dbg.value(metadata double %72, metadata !287, metadata !DIExpression()), !dbg !1023
  %73 = add nsw i32 %29, -398458, !dbg !1104
  tail call void @llvm.dbg.value(metadata i32 %73, metadata !295, metadata !DIExpression()), !dbg !1023
  %74 = fmul double %72, %72, !dbg !1105
  tail call void @llvm.dbg.value(metadata double %74, metadata !289, metadata !DIExpression()), !dbg !1023
  %75 = sub nsw i32 440401, %29, !dbg !1106
  tail call void @llvm.dbg.value(metadata i32 %75, metadata !296, metadata !DIExpression()), !dbg !1023
  %76 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !1107
  %77 = tail call double @llvm.fmuladd.f64(double %74, double %76, double 0x3FD999999997FA04), !dbg !1108
  %78 = fmul double %74, %77, !dbg !1109
  tail call void @llvm.dbg.value(metadata double %78, metadata !290, metadata !DIExpression()), !dbg !1023
  %79 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !1110
  %80 = tail call double @llvm.fmuladd.f64(double %74, double %79, double 0x3FD2492494229359), !dbg !1111
  %81 = tail call double @llvm.fmuladd.f64(double %74, double %80, double 0x3FE5555555555593), !dbg !1112
  %82 = fmul double %72, %81, !dbg !1113
  tail call void @llvm.dbg.value(metadata double %82, metadata !291, metadata !DIExpression()), !dbg !1023
  %83 = or i32 %73, %75, !dbg !1114
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !295, metadata !DIExpression()), !dbg !1023
  %84 = fadd double %78, %82, !dbg !1115
  tail call void @llvm.dbg.value(metadata double %84, metadata !288, metadata !DIExpression()), !dbg !1023
  %85 = icmp sgt i32 %83, 0, !dbg !1116
  br i1 %85, label %86, label %102, !dbg !1118

86:                                               ; preds = %68
  %87 = fmul double %42, 5.000000e-01, !dbg !1119
  %88 = fmul double %42, %87, !dbg !1121
  tail call void @llvm.dbg.value(metadata double %88, metadata !284, metadata !DIExpression()), !dbg !1023
  %89 = icmp eq i32 %41, 0, !dbg !1122
  %90 = fadd double %88, %84, !dbg !1124
  br i1 %89, label %91, label %95, !dbg !1125

91:                                               ; preds = %86
  %92 = fneg double %70, !dbg !1126
  %93 = tail call double @llvm.fmuladd.f64(double %92, double %90, double %88), !dbg !1126
  %94 = fsub double %42, %93, !dbg !1127
  br label %114, !dbg !1128

95:                                               ; preds = %86
  %96 = fmul double %71, 0x3DEA39EF35793C76, !dbg !1129
  %97 = tail call double @llvm.fmuladd.f64(double %70, double %90, double %96), !dbg !1130
  %98 = fsub double %88, %97, !dbg !1131
  %99 = fsub double %98, %42, !dbg !1132
  %100 = fneg double %99, !dbg !1133
  %101 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %100), !dbg !1133
  br label %114, !dbg !1134

102:                                              ; preds = %68
  %103 = icmp eq i32 %41, 0, !dbg !1135
  %104 = fsub double %42, %84, !dbg !1138
  br i1 %103, label %105, label %108, !dbg !1139

105:                                              ; preds = %102
  %106 = fneg double %70, !dbg !1140
  %107 = tail call double @llvm.fmuladd.f64(double %106, double %104, double %42), !dbg !1140
  br label %114, !dbg !1141

108:                                              ; preds = %102
  %109 = fmul double %71, 0xBDEA39EF35793C76, !dbg !1142
  %110 = tail call double @llvm.fmuladd.f64(double %70, double %104, double %109), !dbg !1142
  %111 = fsub double %110, %42, !dbg !1143
  %112 = fneg double %111, !dbg !1144
  %113 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %112), !dbg !1144
  br label %114, !dbg !1145

114:                                              ; preds = %48, %11, %6, %108, %105, %95, %91, %61, %59, %50, %23
  %115 = phi double [ %24, %23 ], [ %53, %50 ], [ %60, %59 ], [ %67, %61 ], [ %94, %91 ], [ %101, %95 ], [ %107, %105 ], [ %113, %108 ], [ 0xFFF0000000000000, %6 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %48 ], !dbg !1023
  ret double %115, !dbg !1146
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_log1p(double noundef %0) local_unnamed_addr #0 !dbg !328 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !330, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1148
  %2 = bitcast double %0 to i64, !dbg !1150
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1148
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !342, metadata !DIExpression()), !dbg !1151
  %3 = lshr i64 %2, 32, !dbg !1152
  %4 = trunc i64 %3 to i32, !dbg !1152
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !339, metadata !DIExpression()), !dbg !1147
  %5 = and i32 %4, 2147483647, !dbg !1153
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !341, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 1, metadata !338, metadata !DIExpression()), !dbg !1147
  %6 = icmp slt i32 %4, 1071284858, !dbg !1154
  br i1 %6, label %7, label %23, !dbg !1156

7:                                                ; preds = %1
  %8 = icmp ugt i32 %5, 1072693247, !dbg !1157
  br i1 %8, label %9, label %12, !dbg !1160

9:                                                ; preds = %7
  %10 = fcmp oeq double %0, -1.000000e+00, !dbg !1161
  %11 = select i1 %10, double 0xFFF0000000000000, double 0x7FF8000000000000, !dbg !1164
  br label %130, !dbg !1164

12:                                               ; preds = %7
  %13 = icmp ult i32 %5, 1042284544, !dbg !1165
  br i1 %13, label %14, label %27, !dbg !1167

14:                                               ; preds = %12
  %15 = fadd double %0, 0x4350000000000000, !dbg !1168
  %16 = fcmp ogt double %15, 0.000000e+00, !dbg !1171
  %17 = icmp ult i32 %5, 1016070144
  %18 = and i1 %16, %17, !dbg !1172
  br i1 %18, label %130, label %19, !dbg !1172

19:                                               ; preds = %14
  %20 = fneg double %0, !dbg !1173
  %21 = fmul double %20, %0, !dbg !1173
  %22 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %0), !dbg !1173
  br label %130, !dbg !1174

23:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 1, metadata !340, metadata !DIExpression()), !dbg !1147
  %24 = icmp ugt i32 %4, 2146435071, !dbg !1175
  br i1 %24, label %25, label %33, !dbg !1177

25:                                               ; preds = %23
  %26 = fadd double %0, %0, !dbg !1178
  br label %130, !dbg !1179

27:                                               ; preds = %12
  %28 = add i32 %4, -1, !dbg !1180
  %29 = icmp ult i32 %28, -1076707644, !dbg !1180
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 1, metadata !340, metadata !DIExpression()), !dbg !1147
  br i1 %29, label %30, label %35, !dbg !1182

30:                                               ; preds = %27
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double undef, metadata !333, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 0, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !340, metadata !DIExpression()), !dbg !1147
  %31 = fmul double %0, 5.000000e-01, !dbg !1183
  %32 = fmul double %31, %0, !dbg !1184
  tail call void @llvm.dbg.value(metadata double %32, metadata !331, metadata !DIExpression()), !dbg !1147
  br label %100, !dbg !1185

33:                                               ; preds = %23
  %34 = icmp ult i32 %4, 1128267776, !dbg !1186
  br i1 %34, label %35, label %48, !dbg !1187

35:                                               ; preds = %27, %33
  %36 = fadd double %0, 1.000000e+00, !dbg !1188
  tail call void @llvm.dbg.value(metadata double %36, metadata !337, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %36, metadata !872, metadata !DIExpression()), !dbg !1189
  %37 = bitcast double %36 to i64, !dbg !1191
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !877, metadata !DIExpression()), !dbg !1189
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !344, metadata !DIExpression()), !dbg !1192
  %38 = lshr i64 %37, 32, !dbg !1193
  %39 = trunc i64 %38 to i32, !dbg !1193
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !340, metadata !DIExpression()), !dbg !1147
  %40 = ashr i32 %39, 20, !dbg !1194
  tail call void @llvm.dbg.value(metadata i32 %40, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1147
  %41 = icmp sgt i32 %40, 1023, !dbg !1195
  %42 = fsub double %0, %36, !dbg !1196
  %43 = fadd double %42, 1.000000e+00, !dbg !1196
  %44 = fadd double %36, -1.000000e+00, !dbg !1196
  %45 = fsub double %0, %44, !dbg !1196
  %46 = select i1 %41, double %43, double %45, !dbg !1196
  tail call void @llvm.dbg.value(metadata double %46, metadata !333, metadata !DIExpression()), !dbg !1147
  %47 = fdiv double %46, %36, !dbg !1197
  tail call void @llvm.dbg.value(metadata double %47, metadata !333, metadata !DIExpression()), !dbg !1147
  br label %50, !dbg !1198

48:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata double %0, metadata !337, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1199
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1199
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !340, metadata !DIExpression()), !dbg !1147
  %49 = lshr i32 %4, 20, !dbg !1201
  tail call void @llvm.dbg.value(metadata i32 %49, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1147
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !333, metadata !DIExpression()), !dbg !1147
  br label %50

50:                                               ; preds = %48, %35
  %51 = phi i32 [ %39, %35 ], [ %4, %48 ], !dbg !1202
  %52 = phi i32 [ %40, %35 ], [ %49, %48 ]
  %53 = phi double [ %36, %35 ], [ %0, %48 ], !dbg !1202
  %54 = phi double [ %47, %35 ], [ 0.000000e+00, %48 ], !dbg !1202
  tail call void @llvm.dbg.value(metadata double %54, metadata !333, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %53, metadata !337, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !340, metadata !DIExpression()), !dbg !1147
  %55 = and i32 %51, 1048575, !dbg !1203
  tail call void @llvm.dbg.value(metadata i32 %55, metadata !340, metadata !DIExpression()), !dbg !1147
  %56 = icmp ult i32 %55, 434334, !dbg !1204
  %57 = bitcast double %53 to i64, !dbg !1205
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !877, metadata !DIExpression()), !dbg !1207
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !877, metadata !DIExpression()), !dbg !1209
  %58 = and i64 %57, 4294967295, !dbg !1206
  br i1 %56, label %59, label %62, !dbg !1211

59:                                               ; preds = %50
  %60 = add nsw i32 %52, -1023, !dbg !1202
  tail call void @llvm.dbg.value(metadata i32 %60, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %53, metadata !872, metadata !DIExpression()), !dbg !1207
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !353, metadata !DIExpression()), !dbg !1212
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !353, metadata !DIExpression()), !dbg !1212
  %61 = or disjoint i32 %55, 1072693248, !dbg !1213
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !353, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1212
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !337, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1147
  br label %67, !dbg !1214

62:                                               ; preds = %50
  %63 = add nsw i32 %52, -1022, !dbg !1215
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata double %53, metadata !872, metadata !DIExpression()), !dbg !1209
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !357, metadata !DIExpression()), !dbg !1216
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !357, metadata !DIExpression()), !dbg !1216
  %64 = or disjoint i32 %55, 1071644672, !dbg !1217
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !357, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1216
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !337, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1147
  %65 = sub nuw nsw i32 1048576, %55, !dbg !1218
  %66 = lshr i32 %65, 2
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !340, metadata !DIExpression()), !dbg !1147
  br label %67

67:                                               ; preds = %59, %62
  %68 = phi i32 [ %55, %59 ], [ %66, %62 ], !dbg !1219
  %69 = phi i32 [ %60, %59 ], [ %63, %62 ], !dbg !1219
  %70 = phi i32 [ %61, %59 ], [ %64, %62 ]
  %71 = zext i32 %70 to i64
  %72 = shl nuw nsw i64 %71, 32, !dbg !1206
  %73 = or disjoint i64 %58, %72, !dbg !1206
  %74 = bitcast i64 %73 to double, !dbg !1206
  tail call void @llvm.dbg.value(metadata double %74, metadata !337, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 %69, metadata !338, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !340, metadata !DIExpression()), !dbg !1147
  %75 = fadd double %74, -1.000000e+00, !dbg !1220
  tail call void @llvm.dbg.value(metadata double %75, metadata !332, metadata !DIExpression()), !dbg !1147
  %76 = icmp eq i32 %68, 0, !dbg !1221
  tail call void @llvm.dbg.value(metadata double %54, metadata !333, metadata !DIExpression()), !dbg !1147
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !340, metadata !DIExpression()), !dbg !1147
  %77 = fmul double %75, 5.000000e-01, !dbg !1183
  %78 = fmul double %75, %77, !dbg !1184
  tail call void @llvm.dbg.value(metadata double %78, metadata !331, metadata !DIExpression()), !dbg !1147
  br i1 %76, label %79, label %100, !dbg !1185

79:                                               ; preds = %67
  %80 = fcmp oeq double %75, 0.000000e+00, !dbg !1223
  br i1 %80, label %81, label %87, !dbg !1226

81:                                               ; preds = %79
  %82 = icmp eq i32 %69, 0, !dbg !1227
  br i1 %82, label %130, label %83, !dbg !1230

83:                                               ; preds = %81
  %84 = sitofp i32 %69 to double, !dbg !1231
  %85 = tail call double @llvm.fmuladd.f64(double %84, double 0x3DEA39EF35793C76, double %54), !dbg !1233
  tail call void @llvm.dbg.value(metadata double %85, metadata !333, metadata !DIExpression()), !dbg !1147
  %86 = tail call double @llvm.fmuladd.f64(double %84, double 0x3FE62E42FEE00000, double %85), !dbg !1234
  br label %130, !dbg !1235

87:                                               ; preds = %79
  %88 = tail call double @llvm.fmuladd.f64(double %75, double 0xBFE5555555555555, double 1.000000e+00), !dbg !1236
  %89 = fmul double %88, %78, !dbg !1237
  tail call void @llvm.dbg.value(metadata double %89, metadata !336, metadata !DIExpression()), !dbg !1147
  %90 = icmp eq i32 %69, 0, !dbg !1238
  br i1 %90, label %91, label %93, !dbg !1240

91:                                               ; preds = %87
  %92 = fsub double %75, %89, !dbg !1241
  br label %130, !dbg !1242

93:                                               ; preds = %87
  %94 = sitofp i32 %69 to double, !dbg !1243
  %95 = tail call double @llvm.fmuladd.f64(double %94, double 0x3DEA39EF35793C76, double %54), !dbg !1244
  %96 = fsub double %89, %95, !dbg !1245
  %97 = fsub double %96, %75, !dbg !1246
  %98 = fneg double %97, !dbg !1247
  %99 = tail call double @llvm.fmuladd.f64(double %94, double 0x3FE62E42FEE00000, double %98), !dbg !1247
  br label %130, !dbg !1248

100:                                              ; preds = %30, %67
  %101 = phi double [ %32, %30 ], [ %78, %67 ]
  %102 = phi double [ %0, %30 ], [ %75, %67 ]
  %103 = phi double [ undef, %30 ], [ %54, %67 ]
  %104 = phi i32 [ 0, %30 ], [ %69, %67 ]
  %105 = fadd double %102, 2.000000e+00, !dbg !1249
  %106 = fdiv double %102, %105, !dbg !1250
  tail call void @llvm.dbg.value(metadata double %106, metadata !334, metadata !DIExpression()), !dbg !1147
  %107 = fmul double %106, %106, !dbg !1251
  tail call void @llvm.dbg.value(metadata double %107, metadata !335, metadata !DIExpression()), !dbg !1147
  %108 = tail call double @llvm.fmuladd.f64(double %107, double 0x3FC2F112DF3E5244, double 0x3FC39A09D078C69F), !dbg !1252
  %109 = tail call double @llvm.fmuladd.f64(double %107, double %108, double 0x3FC7466496CB03DE), !dbg !1253
  %110 = tail call double @llvm.fmuladd.f64(double %107, double %109, double 0x3FCC71C51D8E78AF), !dbg !1254
  %111 = tail call double @llvm.fmuladd.f64(double %107, double %110, double 0x3FD2492494229359), !dbg !1255
  %112 = tail call double @llvm.fmuladd.f64(double %107, double %111, double 0x3FD999999997FA04), !dbg !1256
  %113 = tail call double @llvm.fmuladd.f64(double %107, double %112, double 0x3FE5555555555593), !dbg !1257
  %114 = fmul double %107, %113, !dbg !1258
  tail call void @llvm.dbg.value(metadata double %114, metadata !336, metadata !DIExpression()), !dbg !1147
  %115 = icmp eq i32 %104, 0, !dbg !1259
  br i1 %115, label %116, label %121, !dbg !1261

116:                                              ; preds = %100
  %117 = fadd double %101, %114, !dbg !1262
  %118 = fneg double %106, !dbg !1263
  %119 = tail call double @llvm.fmuladd.f64(double %118, double %117, double %101), !dbg !1263
  %120 = fsub double %102, %119, !dbg !1264
  br label %130, !dbg !1265

121:                                              ; preds = %100
  %122 = sitofp i32 %104 to double, !dbg !1266
  %123 = fadd double %101, %114, !dbg !1267
  %124 = tail call double @llvm.fmuladd.f64(double %122, double 0x3DEA39EF35793C76, double %103), !dbg !1268
  %125 = tail call double @llvm.fmuladd.f64(double %106, double %123, double %124), !dbg !1269
  %126 = fsub double %101, %125, !dbg !1270
  %127 = fsub double %126, %102, !dbg !1271
  %128 = fneg double %127, !dbg !1272
  %129 = tail call double @llvm.fmuladd.f64(double %122, double 0x3FE62E42FEE00000, double %128), !dbg !1272
  br label %130, !dbg !1273

130:                                              ; preds = %81, %14, %9, %121, %116, %93, %91, %83, %25, %19
  %131 = phi double [ %22, %19 ], [ %26, %25 ], [ %86, %83 ], [ %92, %91 ], [ %99, %93 ], [ %120, %116 ], [ %129, %121 ], [ %11, %9 ], [ %0, %14 ], [ 0.000000e+00, %81 ], !dbg !1147
  ret double %131, !dbg !1274
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_asin(double noundef %0) local_unnamed_addr #0 !dbg !88 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !90, metadata !DIExpression()), !dbg !1275
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !91, metadata !DIExpression()), !dbg !1275
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1276
  %2 = bitcast double %0 to i64, !dbg !1278
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1276
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !100, metadata !DIExpression()), !dbg !1279
  %3 = lshr i64 %2, 32, !dbg !1280
  %4 = trunc i64 %3 to i32, !dbg !1280
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !98, metadata !DIExpression()), !dbg !1275
  %5 = and i32 %4, 2147483647, !dbg !1281
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !99, metadata !DIExpression()), !dbg !1275
  %6 = icmp ugt i32 %5, 1072693247, !dbg !1282
  br i1 %6, label %7, label %15, !dbg !1283

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1284
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1284
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !105, metadata !DIExpression()), !dbg !1286
  %8 = trunc i64 %2 to i32, !dbg !1287
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !102, metadata !DIExpression()), !dbg !1288
  %9 = add nsw i32 %5, -1072693248, !dbg !1289
  %10 = or i32 %9, %8, !dbg !1291
  %11 = icmp eq i32 %10, 0, !dbg !1292
  %12 = fmul double %0, 0x3C91A62633145C07, !dbg !1293
  %13 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF921FB54442D18, double %12), !dbg !1293
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !1293
  br label %80

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !1294
  br i1 %16, label %17, label %38, !dbg !1296

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1044381696, !dbg !1297
  br i1 %18, label %19, label %22, !dbg !1300

19:                                               ; preds = %17
  %20 = fadd double %0, 1.000000e+300, !dbg !1301
  %21 = fcmp ogt double %20, 1.000000e+00, !dbg !1304
  br i1 %21, label %80, label %24, !dbg !1305

22:                                               ; preds = %17
  %23 = fmul double %0, %0, !dbg !1306
  tail call void @llvm.dbg.value(metadata double %23, metadata !91, metadata !DIExpression()), !dbg !1275
  br label %24

24:                                               ; preds = %19, %22
  %25 = phi double [ 0.000000e+00, %19 ], [ %23, %22 ], !dbg !1275
  tail call void @llvm.dbg.value(metadata double %25, metadata !91, metadata !DIExpression()), !dbg !1275
  %26 = tail call double @llvm.fmuladd.f64(double %25, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1308
  %27 = tail call double @llvm.fmuladd.f64(double %25, double %26, double 0xBFA48228B5688F3B), !dbg !1309
  %28 = tail call double @llvm.fmuladd.f64(double %25, double %27, double 0x3FC9C1550E884455), !dbg !1310
  %29 = tail call double @llvm.fmuladd.f64(double %25, double %28, double 0xBFD4D61203EB6F7D), !dbg !1311
  %30 = tail call double @llvm.fmuladd.f64(double %25, double %29, double 0x3FC5555555555555), !dbg !1312
  %31 = fmul double %25, %30, !dbg !1313
  tail call void @llvm.dbg.value(metadata double %31, metadata !93, metadata !DIExpression()), !dbg !1275
  %32 = tail call double @llvm.fmuladd.f64(double %25, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1314
  %33 = tail call double @llvm.fmuladd.f64(double %25, double %32, double 0x40002AE59C598AC8), !dbg !1315
  %34 = tail call double @llvm.fmuladd.f64(double %25, double %33, double 0xC0033A271C8A2D4B), !dbg !1316
  %35 = tail call double @llvm.fmuladd.f64(double %25, double %34, double 1.000000e+00), !dbg !1317
  tail call void @llvm.dbg.value(metadata double %35, metadata !94, metadata !DIExpression()), !dbg !1275
  %36 = fdiv double %31, %35, !dbg !1318
  tail call void @llvm.dbg.value(metadata double %36, metadata !92, metadata !DIExpression()), !dbg !1275
  %37 = tail call double @llvm.fmuladd.f64(double %0, double %36, double %0), !dbg !1319
  br label %80, !dbg !1320

38:                                               ; preds = %15
  %39 = tail call double @llvm.fabs.f64(double %0), !dbg !1321
  %40 = fsub double 1.000000e+00, %39, !dbg !1322
  tail call void @llvm.dbg.value(metadata double %40, metadata !92, metadata !DIExpression()), !dbg !1275
  %41 = fmul double %40, 5.000000e-01, !dbg !1323
  tail call void @llvm.dbg.value(metadata double %41, metadata !91, metadata !DIExpression()), !dbg !1275
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1324
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0xBFA48228B5688F3B), !dbg !1325
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0x3FC9C1550E884455), !dbg !1326
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0xBFD4D61203EB6F7D), !dbg !1327
  %46 = tail call double @llvm.fmuladd.f64(double %41, double %45, double 0x3FC5555555555555), !dbg !1328
  %47 = fmul double %41, %46, !dbg !1329
  tail call void @llvm.dbg.value(metadata double %47, metadata !93, metadata !DIExpression()), !dbg !1275
  %48 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1330
  %49 = tail call double @llvm.fmuladd.f64(double %41, double %48, double 0x40002AE59C598AC8), !dbg !1331
  %50 = tail call double @llvm.fmuladd.f64(double %41, double %49, double 0xC0033A271C8A2D4B), !dbg !1332
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %50, double 1.000000e+00), !dbg !1333
  tail call void @llvm.dbg.value(metadata double %51, metadata !94, metadata !DIExpression()), !dbg !1275
  %52 = tail call double @llvm.sqrt.f64(double %41), !dbg !1334
  tail call void @llvm.dbg.value(metadata double %52, metadata !97, metadata !DIExpression()), !dbg !1275
  %53 = icmp ugt i32 %5, 1072640818, !dbg !1335
  br i1 %53, label %54, label %59, !dbg !1336

54:                                               ; preds = %38
  %55 = fdiv double %47, %51, !dbg !1337
  tail call void @llvm.dbg.value(metadata double %55, metadata !92, metadata !DIExpression()), !dbg !1275
  %56 = tail call double @llvm.fmuladd.f64(double %52, double %55, double %52), !dbg !1339
  %57 = tail call double @llvm.fmuladd.f64(double %56, double 2.000000e+00, double 0xBC91A62633145C07), !dbg !1340
  %58 = fsub double 0x3FF921FB54442D18, %57, !dbg !1341
  tail call void @llvm.dbg.value(metadata double %58, metadata !91, metadata !DIExpression()), !dbg !1275
  br label %75, !dbg !1342

59:                                               ; preds = %38
  tail call void @llvm.dbg.value(metadata double %52, metadata !92, metadata !DIExpression()), !dbg !1275
  tail call void @llvm.dbg.value(metadata double %52, metadata !872, metadata !DIExpression()), !dbg !1343
  %60 = bitcast double %52 to i64, !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !877, metadata !DIExpression()), !dbg !1343
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !107, metadata !DIExpression()), !dbg !1346
  %61 = and i64 %60, -4294967296, !dbg !1347
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !107, metadata !DIExpression()), !dbg !1346
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !107, metadata !DIExpression()), !dbg !1346
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !946, metadata !DIExpression()), !dbg !1348
  %62 = bitcast i64 %61 to double, !dbg !1350
  tail call void @llvm.dbg.value(metadata double %62, metadata !951, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata double %62, metadata !92, metadata !DIExpression()), !dbg !1275
  %63 = fneg double %62, !dbg !1351
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %41), !dbg !1351
  %65 = fadd double %52, %62, !dbg !1352
  %66 = fdiv double %64, %65, !dbg !1353
  tail call void @llvm.dbg.value(metadata double %66, metadata !95, metadata !DIExpression()), !dbg !1275
  %67 = fdiv double %47, %51, !dbg !1354
  tail call void @llvm.dbg.value(metadata double %67, metadata !96, metadata !DIExpression()), !dbg !1275
  %68 = fmul double %52, 2.000000e+00, !dbg !1355
  %69 = tail call double @llvm.fmuladd.f64(double %66, double -2.000000e+00, double 0x3C91A62633145C07), !dbg !1356
  %70 = fneg double %69, !dbg !1357
  %71 = tail call double @llvm.fmuladd.f64(double %68, double %67, double %70), !dbg !1357
  tail call void @llvm.dbg.value(metadata double %71, metadata !93, metadata !DIExpression()), !dbg !1275
  %72 = tail call double @llvm.fmuladd.f64(double %62, double -2.000000e+00, double 0x3FE921FB54442D18), !dbg !1358
  tail call void @llvm.dbg.value(metadata double %72, metadata !94, metadata !DIExpression()), !dbg !1275
  %73 = fsub double %72, %71, !dbg !1359
  %74 = fadd double %73, 0x3FE921FB54442D18, !dbg !1359
  tail call void @llvm.dbg.value(metadata double %74, metadata !91, metadata !DIExpression()), !dbg !1275
  br label %75

75:                                               ; preds = %59, %54
  %76 = phi double [ %58, %54 ], [ %74, %59 ], !dbg !1360
  tail call void @llvm.dbg.value(metadata double %76, metadata !91, metadata !DIExpression()), !dbg !1275
  %77 = icmp sgt i32 %4, 0, !dbg !1361
  %78 = fneg double %76
  %79 = select i1 %77, double %76, double %78, !dbg !1363
  br label %80, !dbg !1363

80:                                               ; preds = %75, %19, %24, %7
  %81 = phi double [ %14, %7 ], [ %37, %24 ], [ %0, %19 ], [ %79, %75 ], !dbg !1275
  ret double %81, !dbg !1364
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_asinh(double noundef %0) local_unnamed_addr #0 !dbg !141 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !143, metadata !DIExpression()), !dbg !1365
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1366
  %2 = bitcast double %0 to i64, !dbg !1368
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1366
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !148, metadata !DIExpression()), !dbg !1369
  %3 = lshr i64 %2, 32, !dbg !1370
  %4 = trunc i64 %3 to i32, !dbg !1370
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !146, metadata !DIExpression()), !dbg !1365
  %5 = and i32 %4, 2147483647, !dbg !1371
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !147, metadata !DIExpression()), !dbg !1365
  %6 = icmp ugt i32 %5, 2146435071, !dbg !1372
  br i1 %6, label %7, label %9, !dbg !1374

7:                                                ; preds = %1
  %8 = fadd double %0, %0, !dbg !1375
  br label %44, !dbg !1376

9:                                                ; preds = %1
  %10 = icmp ult i32 %5, 1043333120, !dbg !1377
  %11 = fadd double %0, 1.000000e+300
  %12 = fcmp ogt double %11, 1.000000e+00
  %13 = and i1 %12, %10, !dbg !1379
  br i1 %13, label %44, label %14, !dbg !1379

14:                                               ; preds = %9
  %15 = icmp ugt i32 %5, 1102053376, !dbg !1380
  br i1 %15, label %16, label %20, !dbg !1382

16:                                               ; preds = %14
  %17 = tail call double @llvm.fabs.f64(double %0), !dbg !1383
  %18 = tail call double @pts_ieee754_log(double noundef %17), !dbg !1385
  %19 = fadd double %18, 0x3FE62E42FEFA39EF, !dbg !1386
  tail call void @llvm.dbg.value(metadata double %19, metadata !145, metadata !DIExpression()), !dbg !1365
  br label %39, !dbg !1387

20:                                               ; preds = %14
  %21 = icmp ugt i32 %5, 1073741824, !dbg !1388
  br i1 %21, label %22, label %30, !dbg !1390

22:                                               ; preds = %20
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !1391
  tail call void @llvm.dbg.value(metadata double %23, metadata !144, metadata !DIExpression()), !dbg !1365
  %24 = tail call double @llvm.fmuladd.f64(double %0, double %0, double 1.000000e+00), !dbg !1393
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1394
  %26 = fadd double %23, %25, !dbg !1395
  %27 = fdiv double 1.000000e+00, %26, !dbg !1396
  %28 = tail call double @llvm.fmuladd.f64(double %23, double 2.000000e+00, double %27), !dbg !1397
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1398
  tail call void @llvm.dbg.value(metadata double %29, metadata !145, metadata !DIExpression()), !dbg !1365
  br label %39, !dbg !1399

30:                                               ; preds = %20
  %31 = fmul double %0, %0, !dbg !1400
  tail call void @llvm.dbg.value(metadata double %31, metadata !144, metadata !DIExpression()), !dbg !1365
  %32 = tail call double @llvm.fabs.f64(double %0), !dbg !1402
  %33 = fadd double %31, 1.000000e+00, !dbg !1403
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1404
  %35 = fadd double %34, 1.000000e+00, !dbg !1405
  %36 = fdiv double %31, %35, !dbg !1406
  %37 = fadd double %32, %36, !dbg !1407
  %38 = tail call double @pts_ieee754_log1p(double noundef %37), !dbg !1408
  tail call void @llvm.dbg.value(metadata double %38, metadata !145, metadata !DIExpression()), !dbg !1365
  br label %39

39:                                               ; preds = %22, %30, %16
  %40 = phi double [ %19, %16 ], [ %29, %22 ], [ %38, %30 ], !dbg !1409
  tail call void @llvm.dbg.value(metadata double %40, metadata !145, metadata !DIExpression()), !dbg !1365
  %41 = icmp sgt i32 %4, 0, !dbg !1410
  %42 = fneg double %40
  %43 = select i1 %41, double %40, double %42, !dbg !1412
  br label %44, !dbg !1412

44:                                               ; preds = %39, %9, %7
  %45 = phi double [ %8, %7 ], [ %0, %9 ], [ %43, %39 ], !dbg !1365
  ret double %45, !dbg !1413
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn memory(inaccessiblemem: readwrite) uwtable(sync)
define double @pts_ieee754_atan(double noundef %0) local_unnamed_addr #3 !dbg !2 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !849, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1415
  %2 = bitcast double %0 to i64, !dbg !1417
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1415
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !857, metadata !DIExpression()), !dbg !1418
  %3 = lshr i64 %2, 32, !dbg !1419
  %4 = trunc i64 %3 to i32, !dbg !1419
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !855, metadata !DIExpression()), !dbg !1414
  %5 = and i32 %4, 2147483647, !dbg !1420
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !854, metadata !DIExpression()), !dbg !1414
  %6 = icmp ugt i32 %5, 1141899263, !dbg !1421
  br i1 %6, label %7, label %23, !dbg !1422

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1423
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !1423
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !859, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1425
  %8 = icmp ugt i32 %5, 2146435072, !dbg !1426
  br i1 %8, label %14, label %9, !dbg !1428

9:                                                ; preds = %7
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !859, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1425
  %10 = icmp eq i32 %5, 2146435072, !dbg !1429
  %11 = and i64 %2, 4294967295
  %12 = icmp ne i64 %11, 0
  %13 = and i1 %12, %10, !dbg !1430
  br i1 %13, label %14, label %16, !dbg !1430

14:                                               ; preds = %9, %7
  %15 = fadd double %0, %0, !dbg !1431
  br label %84, !dbg !1432

16:                                               ; preds = %9
  %17 = icmp sgt i32 %4, 0, !dbg !1433
  %18 = load volatile double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 3), align 8, !dbg !1435, !tbaa !1436
  br i1 %17, label %19, label %21, !dbg !1440

19:                                               ; preds = %16
  %20 = fadd double %18, 0x3FF921FB54442D18, !dbg !1441
  br label %84, !dbg !1442

21:                                               ; preds = %16
  %22 = fsub double 0xBFF921FB54442D18, %18, !dbg !1443
  br label %84, !dbg !1444

23:                                               ; preds = %1
  %24 = icmp ult i32 %5, 1071382528, !dbg !1445
  br i1 %24, label %25, label %30, !dbg !1447

25:                                               ; preds = %23
  %26 = icmp ult i32 %5, 1044381696, !dbg !1448
  %27 = fadd double %0, 1.000000e+300
  %28 = fcmp ogt double %27, 1.000000e+00
  %29 = and i1 %28, %26, !dbg !1451
  br i1 %29, label %84, label %51, !dbg !1451

30:                                               ; preds = %23
  %31 = tail call double @llvm.fabs.f64(double %0), !dbg !1452
  tail call void @llvm.dbg.value(metadata double %31, metadata !849, metadata !DIExpression()), !dbg !1414
  %32 = icmp ult i32 %5, 1072889856, !dbg !1454
  br i1 %32, label %33, label %43, !dbg !1456

33:                                               ; preds = %30
  %34 = icmp ult i32 %5, 1072037888, !dbg !1457
  br i1 %34, label %35, label %39, !dbg !1460

35:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 0, metadata !856, metadata !DIExpression()), !dbg !1414
  %36 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double -1.000000e+00), !dbg !1461
  %37 = fadd double %31, 2.000000e+00, !dbg !1463
  %38 = fdiv double %36, %37, !dbg !1464
  tail call void @llvm.dbg.value(metadata double %38, metadata !849, metadata !DIExpression()), !dbg !1414
  br label %51, !dbg !1465

39:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 1, metadata !856, metadata !DIExpression()), !dbg !1414
  %40 = fadd double %31, -1.000000e+00, !dbg !1466
  %41 = fadd double %31, 1.000000e+00, !dbg !1468
  %42 = fdiv double %40, %41, !dbg !1469
  tail call void @llvm.dbg.value(metadata double %42, metadata !849, metadata !DIExpression()), !dbg !1414
  br label %51

43:                                               ; preds = %30
  %44 = icmp ult i32 %5, 1073971200, !dbg !1470
  br i1 %44, label %45, label %49, !dbg !1473

45:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 2, metadata !856, metadata !DIExpression()), !dbg !1414
  %46 = fadd double %31, -1.500000e+00, !dbg !1474
  %47 = tail call double @llvm.fmuladd.f64(double %31, double 1.500000e+00, double 1.000000e+00), !dbg !1476
  %48 = fdiv double %46, %47, !dbg !1477
  tail call void @llvm.dbg.value(metadata double %48, metadata !849, metadata !DIExpression()), !dbg !1414
  br label %51, !dbg !1478

49:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 3, metadata !856, metadata !DIExpression()), !dbg !1414
  %50 = fdiv double -1.000000e+00, %31, !dbg !1479
  tail call void @llvm.dbg.value(metadata double %50, metadata !849, metadata !DIExpression()), !dbg !1414
  br label %51

51:                                               ; preds = %25, %39, %35, %49, %45
  %52 = phi i64 [ 0, %35 ], [ 1, %39 ], [ 2, %45 ], [ 3, %49 ], [ 4294967295, %25 ], !dbg !1481
  %53 = phi double [ %38, %35 ], [ %42, %39 ], [ %48, %45 ], [ %50, %49 ], [ %0, %25 ]
  tail call void @llvm.dbg.value(metadata double %53, metadata !849, metadata !DIExpression()), !dbg !1414
  tail call void @llvm.dbg.value(metadata i64 %52, metadata !856, metadata !DIExpression()), !dbg !1414
  %54 = fmul double %53, %53, !dbg !1482
  tail call void @llvm.dbg.value(metadata double %54, metadata !853, metadata !DIExpression()), !dbg !1414
  %55 = fmul double %54, %54, !dbg !1483
  tail call void @llvm.dbg.value(metadata double %55, metadata !850, metadata !DIExpression()), !dbg !1414
  %56 = tail call double @llvm.fmuladd.f64(double %55, double 0x3F90AD3AE322DA11, double 0x3FA97B4B24760DEB), !dbg !1484
  %57 = tail call double @llvm.fmuladd.f64(double %55, double %56, double 0x3FB10D66A0D03D51), !dbg !1485
  %58 = tail call double @llvm.fmuladd.f64(double %55, double %57, double 0x3FB745CDC54C206E), !dbg !1486
  %59 = tail call double @llvm.fmuladd.f64(double %55, double %58, double 0x3FC24924920083FF), !dbg !1487
  %60 = tail call double @llvm.fmuladd.f64(double %55, double %59, double 0x3FD555555555550D), !dbg !1488
  %61 = fmul double %54, %60, !dbg !1489
  tail call void @llvm.dbg.value(metadata double %61, metadata !851, metadata !DIExpression()), !dbg !1414
  %62 = tail call double @llvm.fmuladd.f64(double %55, double 0xBFA2B4442C6A6C2F, double 0xBFADDE2D52DEFD9A), !dbg !1490
  %63 = tail call double @llvm.fmuladd.f64(double %55, double %62, double 0xBFB3B0F2AF749A6D), !dbg !1491
  %64 = tail call double @llvm.fmuladd.f64(double %55, double %63, double 0xBFBC71C6FE231671), !dbg !1492
  %65 = tail call double @llvm.fmuladd.f64(double %55, double %64, double 0xBFC999999998EBC4), !dbg !1493
  %66 = fmul double %55, %65, !dbg !1494
  tail call void @llvm.dbg.value(metadata double %66, metadata !852, metadata !DIExpression()), !dbg !1414
  br i1 %24, label %67, label %71, !dbg !1495

67:                                               ; preds = %51
  %68 = fadd double %66, %61, !dbg !1496
  %69 = fneg double %53, !dbg !1499
  %70 = tail call double @llvm.fmuladd.f64(double %69, double %68, double %53), !dbg !1499
  br label %84, !dbg !1500

71:                                               ; preds = %51
  %72 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 %52, !dbg !1501
  %73 = load double, ptr %72, align 8, !dbg !1501, !tbaa !1436
  %74 = fadd double %66, %61, !dbg !1503
  %75 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 %52, !dbg !1504
  %76 = load double, ptr %75, align 8, !dbg !1504, !tbaa !1436
  %77 = fneg double %76, !dbg !1505
  %78 = tail call double @llvm.fmuladd.f64(double %53, double %74, double %77), !dbg !1505
  %79 = fsub double %78, %53, !dbg !1506
  %80 = fsub double %73, %79, !dbg !1507
  tail call void @llvm.dbg.value(metadata double %80, metadata !853, metadata !DIExpression()), !dbg !1414
  %81 = icmp slt i64 %2, 0, !dbg !1508
  %82 = fneg double %80, !dbg !1509
  %83 = select i1 %81, double %82, double %80, !dbg !1509
  br label %84, !dbg !1510

84:                                               ; preds = %25, %14, %19, %21, %71, %67
  %85 = phi double [ %70, %67 ], [ %83, %71 ], [ %15, %14 ], [ %20, %19 ], [ %22, %21 ], [ %0, %25 ], !dbg !1414
  ret double %85, !dbg !1511
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn memory(readwrite, argmem: none) uwtable(sync)
define double @pts_ieee754_atan2(double noundef %0, double noundef %1) local_unnamed_addr #4 !dbg !170 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !174, metadata !DIExpression()), !dbg !1512
  tail call void @llvm.dbg.value(metadata double %1, metadata !175, metadata !DIExpression()), !dbg !1512
  tail call void @llvm.dbg.value(metadata double %1, metadata !872, metadata !DIExpression()), !dbg !1513
  %3 = bitcast double %1 to i64, !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !1513
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !185, metadata !DIExpression()), !dbg !1516
  %4 = lshr i64 %3, 32, !dbg !1517
  %5 = trunc i64 %4 to i32, !dbg !1517
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !179, metadata !DIExpression()), !dbg !1512
  %6 = trunc i64 %3 to i32, !dbg !1517
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !183, metadata !DIExpression()), !dbg !1512
  %7 = and i32 %5, 2147483647, !dbg !1518
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !181, metadata !DIExpression()), !dbg !1512
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1519
  %8 = bitcast double %0 to i64, !dbg !1521
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !877, metadata !DIExpression()), !dbg !1519
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !187, metadata !DIExpression()), !dbg !1522
  %9 = lshr i64 %8, 32, !dbg !1523
  %10 = trunc i64 %9 to i32, !dbg !1523
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !180, metadata !DIExpression()), !dbg !1512
  %11 = trunc i64 %8 to i32, !dbg !1523
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !184, metadata !DIExpression()), !dbg !1512
  %12 = and i32 %10, 2147483647, !dbg !1524
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !182, metadata !DIExpression()), !dbg !1512
  %13 = icmp ne i32 %6, 0, !dbg !1525
  %14 = zext i1 %13 to i32, !dbg !1525
  %15 = or i32 %7, %14, !dbg !1527
  %16 = icmp ugt i32 %15, 2146435072, !dbg !1528
  br i1 %16, label %22, label %17, !dbg !1529

17:                                               ; preds = %2
  %18 = icmp ne i32 %11, 0, !dbg !1530
  %19 = zext i1 %18 to i32, !dbg !1530
  %20 = or i32 %12, %19, !dbg !1531
  %21 = icmp ugt i32 %20, 2146435072, !dbg !1532
  br i1 %21, label %22, label %24, !dbg !1533

22:                                               ; preds = %17, %2
  %23 = fadd double %0, %1, !dbg !1534
  br label %116, !dbg !1536

24:                                               ; preds = %17
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1537, metadata !DIExpression()), !dbg !1543
  tail call void @llvm.dbg.value(metadata i32 1072693248, metadata !1542, metadata !DIExpression()), !dbg !1543
  %25 = add i32 %5, -1072693248, !dbg !1546
  %26 = or i32 %25, %6, !dbg !1547
  %27 = icmp eq i32 %26, 0, !dbg !1548
  br i1 %27, label %28, label %30, !dbg !1549

28:                                               ; preds = %24
  %29 = tail call double @pts_ieee754_atan(double noundef %0), !dbg !1550
  br label %116, !dbg !1552

30:                                               ; preds = %24
  %31 = lshr i32 %10, 31, !dbg !1553
  %32 = lshr i32 %5, 30, !dbg !1554
  %33 = and i32 %32, 2, !dbg !1555
  %34 = or disjoint i32 %33, %31, !dbg !1556
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !178, metadata !DIExpression()), !dbg !1512
  %35 = or i32 %12, %11, !dbg !1557
  %36 = icmp eq i32 %35, 0, !dbg !1559
  br i1 %36, label %37, label %45, !dbg !1560

37:                                               ; preds = %30
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %116
    i32 2, label %38
    i32 3, label %41
  ], !dbg !1561

38:                                               ; preds = %37
  %39 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1563, !tbaa !1436
  %40 = fadd double %39, 0x400921FB54442D18, !dbg !1565
  br label %116, !dbg !1566

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1567, !tbaa !1436
  %43 = fsub double 0xC00921FB54442D18, %42, !dbg !1568
  br label %116, !dbg !1569

44:                                               ; preds = %72, %59, %37
  unreachable

45:                                               ; preds = %30
  %46 = or i32 %7, %6, !dbg !1570
  %47 = icmp eq i32 %46, 0, !dbg !1572
  br i1 %47, label %48, label %55, !dbg !1573

48:                                               ; preds = %45
  %49 = icmp slt i64 %8, 0, !dbg !1574
  %50 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1575, !tbaa !1436
  br i1 %49, label %51, label %53, !dbg !1576

51:                                               ; preds = %48
  %52 = fsub double 0xBFF921FB54442D18, %50, !dbg !1577
  br label %116, !dbg !1576

53:                                               ; preds = %48
  %54 = fadd double %50, 0x3FF921FB54442D18, !dbg !1578
  br label %116, !dbg !1576

55:                                               ; preds = %45
  %56 = icmp eq i32 %7, 2146435072, !dbg !1579
  %57 = icmp eq i32 %12, 2146435072, !dbg !1512
  br i1 %56, label %58, label %80, !dbg !1581

58:                                               ; preds = %55
  br i1 %57, label %59, label %72, !dbg !1582

59:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %60
    i32 1, label %63
    i32 2, label %66
    i32 3, label %69
  ], !dbg !1584

60:                                               ; preds = %59
  %61 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1587, !tbaa !1436
  %62 = fadd double %61, 0x3FE921FB54442D18, !dbg !1589
  br label %116, !dbg !1590

63:                                               ; preds = %59
  %64 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1591, !tbaa !1436
  %65 = fsub double 0xBFE921FB54442D18, %64, !dbg !1592
  br label %116, !dbg !1593

66:                                               ; preds = %59
  %67 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1594, !tbaa !1436
  %68 = fadd double %67, 0x4002D97C7F3321D2, !dbg !1595
  br label %116, !dbg !1596

69:                                               ; preds = %59
  %70 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1597, !tbaa !1436
  %71 = fsub double 0xC002D97C7F3321D2, %70, !dbg !1598
  br label %116, !dbg !1599

72:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %73
    i32 2, label %74
    i32 3, label %77
  ], !dbg !1600

73:                                               ; preds = %72
  br label %116, !dbg !1602

74:                                               ; preds = %72
  %75 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1604, !tbaa !1436
  %76 = fadd double %75, 0x400921FB54442D18, !dbg !1605
  br label %116, !dbg !1606

77:                                               ; preds = %72
  %78 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1607, !tbaa !1436
  %79 = fsub double 0xC00921FB54442D18, %78, !dbg !1608
  br label %116, !dbg !1609

80:                                               ; preds = %55
  br i1 %57, label %81, label %88, !dbg !1610

81:                                               ; preds = %80
  %82 = icmp slt i64 %8, 0, !dbg !1611
  %83 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1613, !tbaa !1436
  br i1 %82, label %84, label %86, !dbg !1614

84:                                               ; preds = %81
  %85 = fsub double 0xBFF921FB54442D18, %83, !dbg !1615
  br label %116, !dbg !1614

86:                                               ; preds = %81
  %87 = fadd double %83, 0x3FF921FB54442D18, !dbg !1616
  br label %116, !dbg !1614

88:                                               ; preds = %80
  %89 = sub nsw i32 %12, %7, !dbg !1617
  %90 = ashr i32 %89, 20, !dbg !1618
  tail call void @llvm.dbg.value(metadata i32 %90, metadata !177, metadata !DIExpression()), !dbg !1512
  %91 = icmp sgt i32 %90, 60, !dbg !1619
  br i1 %91, label %92, label %95, !dbg !1621

92:                                               ; preds = %88
  %93 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1622, !tbaa !1436
  %94 = tail call double @llvm.fmuladd.f64(double %93, double 5.000000e-01, double 0x3FF921FB54442D18), !dbg !1624
  tail call void @llvm.dbg.value(metadata double %94, metadata !176, metadata !DIExpression()), !dbg !1512
  tail call void @llvm.dbg.value(metadata i32 %31, metadata !178, metadata !DIExpression()), !dbg !1512
  br label %103, !dbg !1625

95:                                               ; preds = %88
  %96 = icmp slt i64 %3, 0, !dbg !1626
  %97 = icmp slt i32 %90, -60
  %98 = and i1 %96, %97, !dbg !1628
  br i1 %98, label %103, label %99, !dbg !1628

99:                                               ; preds = %95
  %100 = fdiv double %0, %1, !dbg !1629
  %101 = tail call double @llvm.fabs.f64(double %100), !dbg !1631
  %102 = tail call double @pts_ieee754_atan(double noundef %101), !dbg !1632
  tail call void @llvm.dbg.value(metadata double %102, metadata !176, metadata !DIExpression()), !dbg !1512
  br label %103

103:                                              ; preds = %95, %99, %92
  %104 = phi i32 [ %31, %92 ], [ %34, %99 ], [ %34, %95 ], !dbg !1512
  %105 = phi double [ %94, %92 ], [ %102, %99 ], [ 0.000000e+00, %95 ], !dbg !1633
  tail call void @llvm.dbg.value(metadata double %105, metadata !176, metadata !DIExpression()), !dbg !1512
  tail call void @llvm.dbg.value(metadata i32 %104, metadata !178, metadata !DIExpression()), !dbg !1512
  switch i32 %104, label %112 [
    i32 0, label %116
    i32 1, label %106
    i32 2, label %108
  ], !dbg !1634

106:                                              ; preds = %103
  %107 = fneg double %105, !dbg !1635
  br label %116, !dbg !1637

108:                                              ; preds = %103
  %109 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1638, !tbaa !1436
  %110 = fsub double %109, %105, !dbg !1639
  %111 = fadd double %110, 0x400921FB54442D18, !dbg !1639
  br label %116, !dbg !1640

112:                                              ; preds = %103
  %113 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1641, !tbaa !1436
  %114 = fsub double %105, %113, !dbg !1642
  %115 = fadd double %114, 0xC00921FB54442D18, !dbg !1643
  br label %116, !dbg !1644

116:                                              ; preds = %103, %84, %86, %72, %51, %53, %37, %37, %112, %108, %106, %77, %74, %73, %69, %66, %63, %60, %41, %38, %28, %22
  %117 = phi double [ %23, %22 ], [ %29, %28 ], [ %115, %112 ], [ %111, %108 ], [ %107, %106 ], [ %71, %69 ], [ %68, %66 ], [ %65, %63 ], [ %62, %60 ], [ %79, %77 ], [ %76, %74 ], [ -0.000000e+00, %73 ], [ %43, %41 ], [ %40, %38 ], [ %0, %37 ], [ %0, %37 ], [ %52, %51 ], [ %54, %53 ], [ 0.000000e+00, %72 ], [ %85, %84 ], [ %87, %86 ], [ %105, %103 ], !dbg !1512
  ret double %117, !dbg !1645
}

; Function Attrs: nofree nosync nounwind ssp memory(none) uwtable(sync)
define double @pts_ieee754_cos(double noundef %0) local_unnamed_addr #5 !dbg !1646 {
  %2 = alloca [2 x double], align 8
  tail call void @llvm.dbg.value(metadata double %0, metadata !1648, metadata !DIExpression()), !dbg !1656
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !1657
  call void @llvm.dbg.declare(metadata ptr %2, metadata !1649, metadata !DIExpression()), !dbg !1658
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1651, metadata !DIExpression()), !dbg !1656
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1659
  %3 = bitcast double %0 to i64, !dbg !1661
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !1659
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !1654, metadata !DIExpression()), !dbg !1662
  %4 = lshr i64 %3, 32, !dbg !1663
  %5 = trunc i64 %4 to i32, !dbg !1663
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1653, metadata !DIExpression()), !dbg !1656
  %6 = and i32 %5, 2147483647, !dbg !1664
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1653, metadata !DIExpression()), !dbg !1656
  %7 = icmp ult i32 %6, 1072243196, !dbg !1665
  br i1 %7, label %8, label %42, !dbg !1667

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !609, metadata !DIExpression()), !dbg !1668
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !610, metadata !DIExpression()), !dbg !1668
  call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1671
  call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !1671
  call void @llvm.dbg.value(metadata i64 %3, metadata !617, metadata !DIExpression()), !dbg !1673
  call void @llvm.dbg.value(metadata i32 %5, metadata !616, metadata !DIExpression()), !dbg !1668
  call void @llvm.dbg.value(metadata i32 %6, metadata !616, metadata !DIExpression()), !dbg !1668
  %9 = icmp ult i32 %6, 1044381696, !dbg !1674
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !1676
  br i1 %12, label %186, label %13, !dbg !1676

13:                                               ; preds = %8
  %14 = fmul double %0, %0, !dbg !1677
  call void @llvm.dbg.value(metadata double %14, metadata !613, metadata !DIExpression()), !dbg !1668
  %15 = tail call double @llvm.fmuladd.f64(double %14, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1678
  %16 = tail call double @llvm.fmuladd.f64(double %14, double %15, double 0xBE927E4F809C52AD), !dbg !1679
  %17 = tail call double @llvm.fmuladd.f64(double %14, double %16, double 0x3EFA01A019CB1590), !dbg !1680
  %18 = tail call double @llvm.fmuladd.f64(double %14, double %17, double 0xBF56C16C16C15177), !dbg !1681
  %19 = tail call double @llvm.fmuladd.f64(double %14, double %18, double 0x3FA555555555554C), !dbg !1682
  %20 = fmul double %14, %19, !dbg !1683
  call void @llvm.dbg.value(metadata double %20, metadata !614, metadata !DIExpression()), !dbg !1668
  %21 = icmp ult i32 %6, 1070805811, !dbg !1684
  br i1 %21, label %22, label %28, !dbg !1685

22:                                               ; preds = %13
  %23 = fmul double %0, -0.000000e+00, !dbg !1686
  %24 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %23), !dbg !1686
  %25 = fneg double %24, !dbg !1688
  %26 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %25), !dbg !1688
  %27 = fsub double 1.000000e+00, %26, !dbg !1689
  br label %186, !dbg !1690

28:                                               ; preds = %13
  %29 = icmp ugt i32 %6, 1072234496, !dbg !1691
  %30 = add nsw i32 %6, -2097152, !dbg !1692
  %31 = zext nneg i32 %30 to i64, !dbg !1692
  %32 = shl nuw nsw i64 %31, 32, !dbg !1692
  %33 = bitcast i64 %32 to double, !dbg !1692
  %34 = select i1 %29, double 2.812500e-01, double %33, !dbg !1692
  call void @llvm.dbg.value(metadata double %34, metadata !615, metadata !DIExpression()), !dbg !1668
  %35 = fneg double %34, !dbg !1693
  %36 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %35), !dbg !1693
  call void @llvm.dbg.value(metadata double %36, metadata !612, metadata !DIExpression()), !dbg !1668
  %37 = fsub double 1.000000e+00, %34, !dbg !1694
  call void @llvm.dbg.value(metadata double %37, metadata !611, metadata !DIExpression()), !dbg !1668
  %38 = fmul double %0, -0.000000e+00, !dbg !1695
  %39 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %38), !dbg !1695
  %40 = fsub double %39, %36, !dbg !1696
  %41 = fadd double %37, %40, !dbg !1696
  br label %186, !dbg !1697

42:                                               ; preds = %1
  %43 = icmp ugt i32 %6, 2146435071, !dbg !1698
  br i1 %43, label %44, label %46, !dbg !1700

44:                                               ; preds = %42
  %45 = fsub double %0, %0, !dbg !1701
  br label %186, !dbg !1703

46:                                               ; preds = %42
  %47 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !1704
  tail call void @llvm.dbg.value(metadata i32 %47, metadata !1652, metadata !DIExpression()), !dbg !1656
  %48 = and i32 %47, 3, !dbg !1706
  %49 = load double, ptr %2, align 8, !dbg !1707, !tbaa !1436
  switch i32 %48, label %163 [
    i32 0, label %50
    i32 1, label %92
    i32 2, label %118
  ], !dbg !1709

50:                                               ; preds = %46
  %51 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1710
  %52 = load double, ptr %51, align 8, !dbg !1710, !tbaa !1436
  call void @llvm.dbg.value(metadata double %49, metadata !609, metadata !DIExpression()), !dbg !1711
  call void @llvm.dbg.value(metadata double %52, metadata !610, metadata !DIExpression()), !dbg !1711
  call void @llvm.dbg.value(metadata double %49, metadata !872, metadata !DIExpression()), !dbg !1713
  %53 = bitcast double %49 to i64, !dbg !1715
  call void @llvm.dbg.value(metadata i64 %53, metadata !877, metadata !DIExpression()), !dbg !1713
  call void @llvm.dbg.value(metadata i64 %53, metadata !617, metadata !DIExpression()), !dbg !1716
  %54 = lshr i64 %53, 32, !dbg !1717
  %55 = trunc i64 %54 to i32, !dbg !1717
  call void @llvm.dbg.value(metadata i32 %55, metadata !616, metadata !DIExpression()), !dbg !1711
  %56 = and i32 %55, 2147483647, !dbg !1718
  call void @llvm.dbg.value(metadata i32 %56, metadata !616, metadata !DIExpression()), !dbg !1711
  %57 = icmp ult i32 %56, 1044381696, !dbg !1719
  %58 = fptosi double %49 to i32
  %59 = icmp eq i32 %58, 0
  %60 = select i1 %57, i1 %59, i1 false, !dbg !1720
  br i1 %60, label %186, label %61, !dbg !1720

61:                                               ; preds = %50
  %62 = fmul double %49, %49, !dbg !1721
  call void @llvm.dbg.value(metadata double %62, metadata !613, metadata !DIExpression()), !dbg !1711
  %63 = tail call double @llvm.fmuladd.f64(double %62, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1722
  %64 = tail call double @llvm.fmuladd.f64(double %62, double %63, double 0xBE927E4F809C52AD), !dbg !1723
  %65 = tail call double @llvm.fmuladd.f64(double %62, double %64, double 0x3EFA01A019CB1590), !dbg !1724
  %66 = tail call double @llvm.fmuladd.f64(double %62, double %65, double 0xBF56C16C16C15177), !dbg !1725
  %67 = tail call double @llvm.fmuladd.f64(double %62, double %66, double 0x3FA555555555554C), !dbg !1726
  %68 = fmul double %62, %67, !dbg !1727
  call void @llvm.dbg.value(metadata double %68, metadata !614, metadata !DIExpression()), !dbg !1711
  %69 = icmp ult i32 %56, 1070805811, !dbg !1728
  br i1 %69, label %70, label %77, !dbg !1729

70:                                               ; preds = %61
  %71 = fneg double %49, !dbg !1730
  %72 = fmul double %52, %71, !dbg !1730
  %73 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %72), !dbg !1730
  %74 = fneg double %73, !dbg !1731
  %75 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %74), !dbg !1731
  %76 = fsub double 1.000000e+00, %75, !dbg !1732
  br label %186, !dbg !1733

77:                                               ; preds = %61
  %78 = icmp ugt i32 %56, 1072234496, !dbg !1734
  %79 = add nsw i32 %56, -2097152, !dbg !1735
  %80 = zext nneg i32 %79 to i64, !dbg !1735
  %81 = shl nuw nsw i64 %80, 32, !dbg !1735
  %82 = bitcast i64 %81 to double, !dbg !1735
  %83 = select i1 %78, double 2.812500e-01, double %82, !dbg !1735
  call void @llvm.dbg.value(metadata double %83, metadata !615, metadata !DIExpression()), !dbg !1711
  %84 = fneg double %83, !dbg !1736
  %85 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %84), !dbg !1736
  call void @llvm.dbg.value(metadata double %85, metadata !612, metadata !DIExpression()), !dbg !1711
  %86 = fsub double 1.000000e+00, %83, !dbg !1737
  call void @llvm.dbg.value(metadata double %86, metadata !611, metadata !DIExpression()), !dbg !1711
  %87 = fneg double %49, !dbg !1738
  %88 = fmul double %52, %87, !dbg !1738
  %89 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %88), !dbg !1738
  %90 = fsub double %89, %85, !dbg !1739
  %91 = fadd double %86, %90, !dbg !1739
  br label %186, !dbg !1740

92:                                               ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !769, metadata !DIExpression()), !dbg !1741
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !1741
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !1741
  call void @llvm.dbg.value(metadata double %49, metadata !872, metadata !DIExpression()), !dbg !1743
  %93 = bitcast double %49 to i64, !dbg !1745
  call void @llvm.dbg.value(metadata i64 %93, metadata !877, metadata !DIExpression()), !dbg !1743
  call void @llvm.dbg.value(metadata i64 %93, metadata !776, metadata !DIExpression()), !dbg !1746
  call void @llvm.dbg.value(metadata i64 %93, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1741
  %94 = and i64 %93, 9205357638345293824, !dbg !1747
  %95 = icmp ult i64 %94, 4485585228861014016, !dbg !1747
  %96 = fptosi double %49 to i32
  %97 = icmp eq i32 %96, 0
  %98 = select i1 %95, i1 %97, i1 false, !dbg !1749
  br i1 %98, label %115, label %99, !dbg !1749

99:                                               ; preds = %92
  %100 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1750
  %101 = load double, ptr %100, align 8, !dbg !1750, !tbaa !1436
  call void @llvm.dbg.value(metadata double %101, metadata !770, metadata !DIExpression()), !dbg !1741
  %102 = fmul double %49, %49, !dbg !1751
  call void @llvm.dbg.value(metadata double %102, metadata !772, metadata !DIExpression()), !dbg !1741
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !1741
  %103 = tail call double @llvm.fmuladd.f64(double %102, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1752
  %104 = tail call double @llvm.fmuladd.f64(double %102, double %103, double 0x3EC71DE357B1FE7D), !dbg !1753
  %105 = tail call double @llvm.fmuladd.f64(double %102, double %104, double 0xBF2A01A019C161D5), !dbg !1754
  %106 = tail call double @llvm.fmuladd.f64(double %102, double %105, double 0x3F8111111110F8A6), !dbg !1755
  call void @llvm.dbg.value(metadata double %106, metadata !773, metadata !DIExpression()), !dbg !1741
  %107 = fneg double %102, !dbg !1756
  %108 = fmul double %49, %107, !dbg !1756
  %109 = fmul double %108, %106, !dbg !1756
  %110 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double %109), !dbg !1756
  %111 = fneg double %101, !dbg !1759
  %112 = tail call double @llvm.fmuladd.f64(double %102, double %110, double %111), !dbg !1759
  %113 = tail call double @llvm.fmuladd.f64(double %108, double 0xBFC5555555555549, double %112), !dbg !1760
  %114 = fsub double %49, %113, !dbg !1761
  br label %115, !dbg !1762

115:                                              ; preds = %92, %99
  %116 = phi double [ %114, %99 ], [ %49, %92 ], !dbg !1741
  %117 = fneg double %116, !dbg !1763
  br label %186, !dbg !1764

118:                                              ; preds = %46
  %119 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1765
  %120 = load double, ptr %119, align 8, !dbg !1765, !tbaa !1436
  call void @llvm.dbg.value(metadata double %49, metadata !609, metadata !DIExpression()), !dbg !1766
  call void @llvm.dbg.value(metadata double %120, metadata !610, metadata !DIExpression()), !dbg !1766
  call void @llvm.dbg.value(metadata double %49, metadata !872, metadata !DIExpression()), !dbg !1768
  %121 = bitcast double %49 to i64, !dbg !1770
  call void @llvm.dbg.value(metadata i64 %121, metadata !877, metadata !DIExpression()), !dbg !1768
  call void @llvm.dbg.value(metadata i64 %121, metadata !617, metadata !DIExpression()), !dbg !1771
  %122 = lshr i64 %121, 32, !dbg !1772
  %123 = trunc i64 %122 to i32, !dbg !1772
  call void @llvm.dbg.value(metadata i32 %123, metadata !616, metadata !DIExpression()), !dbg !1766
  %124 = and i32 %123, 2147483647, !dbg !1773
  call void @llvm.dbg.value(metadata i32 %124, metadata !616, metadata !DIExpression()), !dbg !1766
  %125 = icmp ult i32 %124, 1044381696, !dbg !1774
  %126 = fptosi double %49 to i32
  %127 = icmp eq i32 %126, 0
  %128 = select i1 %125, i1 %127, i1 false, !dbg !1775
  br i1 %128, label %160, label %129, !dbg !1775

129:                                              ; preds = %118
  %130 = fmul double %49, %49, !dbg !1776
  call void @llvm.dbg.value(metadata double %130, metadata !613, metadata !DIExpression()), !dbg !1766
  %131 = tail call double @llvm.fmuladd.f64(double %130, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1777
  %132 = tail call double @llvm.fmuladd.f64(double %130, double %131, double 0xBE927E4F809C52AD), !dbg !1778
  %133 = tail call double @llvm.fmuladd.f64(double %130, double %132, double 0x3EFA01A019CB1590), !dbg !1779
  %134 = tail call double @llvm.fmuladd.f64(double %130, double %133, double 0xBF56C16C16C15177), !dbg !1780
  %135 = tail call double @llvm.fmuladd.f64(double %130, double %134, double 0x3FA555555555554C), !dbg !1781
  %136 = fmul double %130, %135, !dbg !1782
  call void @llvm.dbg.value(metadata double %136, metadata !614, metadata !DIExpression()), !dbg !1766
  %137 = icmp ult i32 %124, 1070805811, !dbg !1783
  br i1 %137, label %138, label %145, !dbg !1784

138:                                              ; preds = %129
  %139 = fneg double %49, !dbg !1785
  %140 = fmul double %120, %139, !dbg !1785
  %141 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %140), !dbg !1785
  %142 = fneg double %141, !dbg !1786
  %143 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %142), !dbg !1786
  %144 = fsub double 1.000000e+00, %143, !dbg !1787
  br label %160, !dbg !1788

145:                                              ; preds = %129
  %146 = icmp ugt i32 %124, 1072234496, !dbg !1789
  %147 = add nsw i32 %124, -2097152, !dbg !1790
  %148 = zext nneg i32 %147 to i64, !dbg !1790
  %149 = shl nuw nsw i64 %148, 32, !dbg !1790
  %150 = bitcast i64 %149 to double, !dbg !1790
  %151 = select i1 %146, double 2.812500e-01, double %150, !dbg !1790
  call void @llvm.dbg.value(metadata double %151, metadata !615, metadata !DIExpression()), !dbg !1766
  %152 = fneg double %151, !dbg !1791
  %153 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %152), !dbg !1791
  call void @llvm.dbg.value(metadata double %153, metadata !612, metadata !DIExpression()), !dbg !1766
  %154 = fsub double 1.000000e+00, %151, !dbg !1792
  call void @llvm.dbg.value(metadata double %154, metadata !611, metadata !DIExpression()), !dbg !1766
  %155 = fneg double %49, !dbg !1793
  %156 = fmul double %120, %155, !dbg !1793
  %157 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %156), !dbg !1793
  %158 = fsub double %157, %153, !dbg !1794
  %159 = fadd double %154, %158, !dbg !1794
  br label %160, !dbg !1795

160:                                              ; preds = %118, %138, %145
  %161 = phi double [ %144, %138 ], [ %159, %145 ], [ 1.000000e+00, %118 ], !dbg !1766
  %162 = fneg double %161, !dbg !1796
  br label %186, !dbg !1797

163:                                              ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !769, metadata !DIExpression()), !dbg !1798
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !1798
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !1798
  call void @llvm.dbg.value(metadata double %49, metadata !872, metadata !DIExpression()), !dbg !1800
  %164 = bitcast double %49 to i64, !dbg !1802
  call void @llvm.dbg.value(metadata i64 %164, metadata !877, metadata !DIExpression()), !dbg !1800
  call void @llvm.dbg.value(metadata i64 %164, metadata !776, metadata !DIExpression()), !dbg !1803
  call void @llvm.dbg.value(metadata i64 %164, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1798
  %165 = and i64 %164, 9205357638345293824, !dbg !1804
  %166 = icmp ult i64 %165, 4485585228861014016, !dbg !1804
  %167 = fptosi double %49 to i32
  %168 = icmp eq i32 %167, 0
  %169 = select i1 %166, i1 %168, i1 false, !dbg !1805
  br i1 %169, label %186, label %170, !dbg !1805

170:                                              ; preds = %163
  %171 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1806
  %172 = load double, ptr %171, align 8, !dbg !1806, !tbaa !1436
  call void @llvm.dbg.value(metadata double %172, metadata !770, metadata !DIExpression()), !dbg !1798
  %173 = fmul double %49, %49, !dbg !1807
  call void @llvm.dbg.value(metadata double %173, metadata !772, metadata !DIExpression()), !dbg !1798
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !1798
  %174 = tail call double @llvm.fmuladd.f64(double %173, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1808
  %175 = tail call double @llvm.fmuladd.f64(double %173, double %174, double 0x3EC71DE357B1FE7D), !dbg !1809
  %176 = tail call double @llvm.fmuladd.f64(double %173, double %175, double 0xBF2A01A019C161D5), !dbg !1810
  %177 = tail call double @llvm.fmuladd.f64(double %173, double %176, double 0x3F8111111110F8A6), !dbg !1811
  call void @llvm.dbg.value(metadata double %177, metadata !773, metadata !DIExpression()), !dbg !1798
  %178 = fneg double %173, !dbg !1812
  %179 = fmul double %49, %178, !dbg !1812
  %180 = fmul double %179, %177, !dbg !1812
  %181 = tail call double @llvm.fmuladd.f64(double %172, double 5.000000e-01, double %180), !dbg !1812
  %182 = fneg double %172, !dbg !1813
  %183 = tail call double @llvm.fmuladd.f64(double %173, double %181, double %182), !dbg !1813
  %184 = tail call double @llvm.fmuladd.f64(double %179, double 0xBFC5555555555549, double %183), !dbg !1814
  %185 = fsub double %49, %184, !dbg !1815
  br label %186, !dbg !1816

186:                                              ; preds = %170, %163, %77, %70, %50, %28, %22, %8, %160, %115, %44
  %187 = phi double [ %45, %44 ], [ %162, %160 ], [ %117, %115 ], [ %27, %22 ], [ %41, %28 ], [ 1.000000e+00, %8 ], [ %76, %70 ], [ %91, %77 ], [ 1.000000e+00, %50 ], [ %185, %170 ], [ %49, %163 ], !dbg !1817
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !1818
  ret double %187, !dbg !1818
}

; Function Attrs: nofree nosync nounwind ssp memory(argmem: write) uwtable(sync)
define internal fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr nocapture noundef writeonly %1) unnamed_addr #6 !dbg !639 {
  %3 = alloca [20 x i32], align 4
  %4 = alloca [20 x double], align 8
  %5 = alloca [20 x double], align 8
  %6 = alloca [20 x double], align 8
  %7 = alloca [3 x double], align 8
  tail call void @llvm.dbg.value(metadata double %0, metadata !644, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !645, metadata !DIExpression()), !dbg !1819
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %7) #11, !dbg !1820
  call void @llvm.dbg.declare(metadata ptr %7, metadata !651, metadata !DIExpression()), !dbg !1821
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1822
  %8 = bitcast double %0 to i64, !dbg !1824
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !877, metadata !DIExpression()), !dbg !1822
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !663, metadata !DIExpression()), !dbg !1825
  %9 = lshr i64 %8, 32, !dbg !1826
  %10 = trunc i64 %9 to i32, !dbg !1826
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !661, metadata !DIExpression()), !dbg !1819
  %11 = and i32 %10, 2147483647, !dbg !1827
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !660, metadata !DIExpression()), !dbg !1819
  %12 = icmp ult i32 %11, 1072243196, !dbg !1828
  br i1 %12, label %13, label %15, !dbg !1830

13:                                               ; preds = %2
  store double %0, ptr %1, align 8, !dbg !1831, !tbaa !1436
  %14 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1833
  store double 0.000000e+00, ptr %14, align 8, !dbg !1834, !tbaa !1436
  br label %963, !dbg !1835

15:                                               ; preds = %2
  %16 = icmp ult i32 %11, 1073928572, !dbg !1836
  br i1 %16, label %17, label %46, !dbg !1838

17:                                               ; preds = %15
  %18 = icmp sgt i32 %10, 0, !dbg !1839
  %19 = icmp eq i32 %11, 1073291771, !dbg !1842
  br i1 %18, label %20, label %33, !dbg !1843

20:                                               ; preds = %17
  %21 = fadd double %0, 0xBFF921FB54400000, !dbg !1844
  tail call void @llvm.dbg.value(metadata double %21, metadata !646, metadata !DIExpression()), !dbg !1819
  br i1 %19, label %27, label %22, !dbg !1846

22:                                               ; preds = %20
  %23 = fadd double %21, 0xBDD0B4611A626331, !dbg !1847
  store double %23, ptr %1, align 8, !dbg !1850, !tbaa !1436
  %24 = fsub double %21, %23, !dbg !1851
  %25 = fadd double %24, 0xBDD0B4611A626331, !dbg !1852
  %26 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1853
  store double %25, ptr %26, align 8, !dbg !1854, !tbaa !1436
  br label %963, !dbg !1855

27:                                               ; preds = %20
  %28 = fadd double %21, 0xBDD0B4611A600000, !dbg !1856
  tail call void @llvm.dbg.value(metadata double %28, metadata !646, metadata !DIExpression()), !dbg !1819
  %29 = fadd double %28, 0xBBA3198A2E037073, !dbg !1858
  store double %29, ptr %1, align 8, !dbg !1859, !tbaa !1436
  %30 = fsub double %28, %29, !dbg !1860
  %31 = fadd double %30, 0xBBA3198A2E037073, !dbg !1861
  %32 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1862
  store double %31, ptr %32, align 8, !dbg !1863, !tbaa !1436
  br label %963

33:                                               ; preds = %17
  %34 = fadd double %0, 0x3FF921FB54400000, !dbg !1864
  tail call void @llvm.dbg.value(metadata double %34, metadata !646, metadata !DIExpression()), !dbg !1819
  br i1 %19, label %40, label %35, !dbg !1866

35:                                               ; preds = %33
  %36 = fadd double %34, 0x3DD0B4611A626331, !dbg !1867
  store double %36, ptr %1, align 8, !dbg !1870, !tbaa !1436
  %37 = fsub double %34, %36, !dbg !1871
  %38 = fadd double %37, 0x3DD0B4611A626331, !dbg !1872
  %39 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1873
  store double %38, ptr %39, align 8, !dbg !1874, !tbaa !1436
  br label %963, !dbg !1875

40:                                               ; preds = %33
  %41 = fadd double %34, 0x3DD0B4611A600000, !dbg !1876
  tail call void @llvm.dbg.value(metadata double %41, metadata !646, metadata !DIExpression()), !dbg !1819
  %42 = fadd double %41, 0x3BA3198A2E037073, !dbg !1878
  store double %42, ptr %1, align 8, !dbg !1879, !tbaa !1436
  %43 = fsub double %41, %42, !dbg !1880
  %44 = fadd double %43, 0x3BA3198A2E037073, !dbg !1881
  %45 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1882
  store double %44, ptr %45, align 8, !dbg !1883, !tbaa !1436
  br label %963

46:                                               ; preds = %15
  %47 = icmp ult i32 %11, 1094263292, !dbg !1884
  br i1 %47, label %48, label %112, !dbg !1885

48:                                               ; preds = %46
  %49 = tail call double @llvm.fabs.f64(double %0), !dbg !1886
  tail call void @llvm.dbg.value(metadata double %49, metadata !648, metadata !DIExpression()), !dbg !1819
  %50 = tail call double @llvm.fmuladd.f64(double %49, double 0x3FE45F306DC9C883, double 5.000000e-01), !dbg !1887
  %51 = fptosi double %50 to i32, !dbg !1888
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !659, metadata !DIExpression()), !dbg !1819
  %52 = sitofp i32 %51 to double, !dbg !1889
  tail call void @llvm.dbg.value(metadata double %52, metadata !650, metadata !DIExpression()), !dbg !1819
  %53 = fneg double %52, !dbg !1890
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FF921FB54400000, double %49), !dbg !1890
  tail call void @llvm.dbg.value(metadata double %54, metadata !649, metadata !DIExpression()), !dbg !1819
  %55 = fmul double %52, 0x3DD0B4611A626331, !dbg !1891
  tail call void @llvm.dbg.value(metadata double %55, metadata !647, metadata !DIExpression()), !dbg !1819
  %56 = icmp slt i32 %51, 32, !dbg !1892
  br i1 %56, label %57, label %65, !dbg !1893

57:                                               ; preds = %48
  %58 = add nsw i32 %51, -1, !dbg !1894
  %59 = sext i32 %58 to i64, !dbg !1895
  %60 = getelementptr inbounds [32 x i32], ptr @__ieee754_rem_pio2.npio2_hw, i64 0, i64 %59, !dbg !1895
  %61 = load i32, ptr %60, align 4, !dbg !1895, !tbaa !1896
  %62 = icmp eq i32 %11, %61, !dbg !1898
  br i1 %62, label %65, label %63, !dbg !1899

63:                                               ; preds = %57
  %64 = fsub double %54, %55, !dbg !1900
  br label %96, !dbg !1902

65:                                               ; preds = %57, %48
  %66 = lshr i32 %11, 20
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !657, metadata !DIExpression()), !dbg !1819
  %67 = fsub double %54, %55, !dbg !1903
  store double %67, ptr %1, align 8, !dbg !1904, !tbaa !1436
  tail call void @llvm.dbg.value(metadata double %67, metadata !872, metadata !DIExpression()), !dbg !1905
  %68 = bitcast double %67 to i64, !dbg !1907
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !877, metadata !DIExpression()), !dbg !1905
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !670, metadata !DIExpression()), !dbg !1908
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !665, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1909
  %69 = lshr i64 %68, 52, !dbg !1910
  %70 = trunc i64 %69 to i32, !dbg !1910
  %71 = and i32 %70, 2047, !dbg !1911
  %72 = sub nsw i32 %66, %71, !dbg !1912
  tail call void @llvm.dbg.value(metadata i32 %72, metadata !656, metadata !DIExpression()), !dbg !1819
  %73 = icmp sgt i32 %72, 16, !dbg !1913
  br i1 %73, label %74, label %100, !dbg !1914

74:                                               ; preds = %65
  tail call void @llvm.dbg.value(metadata double %54, metadata !648, metadata !DIExpression()), !dbg !1819
  %75 = fmul double %52, 0x3DD0B4611A600000, !dbg !1915
  tail call void @llvm.dbg.value(metadata double %75, metadata !647, metadata !DIExpression()), !dbg !1819
  %76 = fsub double %54, %75, !dbg !1916
  tail call void @llvm.dbg.value(metadata double %76, metadata !649, metadata !DIExpression()), !dbg !1819
  %77 = fsub double %54, %76, !dbg !1917
  %78 = fsub double %77, %75, !dbg !1918
  %79 = fneg double %78, !dbg !1919
  %80 = tail call double @llvm.fmuladd.f64(double %52, double 0x3BA3198A2E037073, double %79), !dbg !1919
  tail call void @llvm.dbg.value(metadata double %80, metadata !647, metadata !DIExpression()), !dbg !1819
  %81 = fsub double %76, %80, !dbg !1920
  store double %81, ptr %1, align 8, !dbg !1921, !tbaa !1436
  tail call void @llvm.dbg.value(metadata double %81, metadata !872, metadata !DIExpression()), !dbg !1922
  %82 = bitcast double %81 to i64, !dbg !1924
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !877, metadata !DIExpression()), !dbg !1922
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !672, metadata !DIExpression()), !dbg !1925
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !665, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1909
  %83 = lshr i64 %82, 52, !dbg !1926
  %84 = trunc i64 %83 to i32, !dbg !1926
  %85 = and i32 %84, 2047, !dbg !1927
  %86 = sub nsw i32 %66, %85, !dbg !1928
  tail call void @llvm.dbg.value(metadata i32 %86, metadata !656, metadata !DIExpression()), !dbg !1819
  %87 = icmp sgt i32 %86, 49, !dbg !1929
  br i1 %87, label %88, label %100, !dbg !1931

88:                                               ; preds = %74
  tail call void @llvm.dbg.value(metadata double %76, metadata !648, metadata !DIExpression()), !dbg !1819
  %89 = fmul double %52, 0x3BA3198A2E000000, !dbg !1932
  tail call void @llvm.dbg.value(metadata double %89, metadata !647, metadata !DIExpression()), !dbg !1819
  %90 = fsub double %76, %89, !dbg !1934
  tail call void @llvm.dbg.value(metadata double %90, metadata !649, metadata !DIExpression()), !dbg !1819
  %91 = fsub double %76, %90, !dbg !1935
  %92 = fsub double %91, %89, !dbg !1936
  %93 = fneg double %92, !dbg !1937
  %94 = tail call double @llvm.fmuladd.f64(double %52, double 0x397B839A252049C1, double %93), !dbg !1937
  tail call void @llvm.dbg.value(metadata double %94, metadata !647, metadata !DIExpression()), !dbg !1819
  %95 = fsub double %90, %94, !dbg !1938
  br label %96, !dbg !1939

96:                                               ; preds = %63, %88
  %97 = phi double [ %95, %88 ], [ %64, %63 ]
  %98 = phi double [ %90, %88 ], [ %54, %63 ]
  %99 = phi double [ %94, %88 ], [ %55, %63 ]
  store double %97, ptr %1, align 8, !dbg !1940, !tbaa !1436
  br label %100, !dbg !1941

100:                                              ; preds = %96, %65, %74
  %101 = phi double [ %81, %74 ], [ %67, %65 ], [ %97, %96 ], !dbg !1942
  %102 = phi double [ %76, %74 ], [ %54, %65 ], [ %98, %96 ], !dbg !1943
  %103 = phi double [ %80, %74 ], [ %55, %65 ], [ %99, %96 ], !dbg !1943
  tail call void @llvm.dbg.value(metadata double %103, metadata !647, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata double %102, metadata !649, metadata !DIExpression()), !dbg !1819
  %104 = fsub double %102, %101, !dbg !1941
  %105 = fsub double %104, %103, !dbg !1944
  %106 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1945
  store double %105, ptr %106, align 8, !dbg !1946, !tbaa !1436
  %107 = icmp slt i64 %8, 0, !dbg !1947
  br i1 %107, label %108, label %963, !dbg !1949

108:                                              ; preds = %100
  %109 = fneg double %101, !dbg !1950
  store double %109, ptr %1, align 8, !dbg !1952, !tbaa !1436
  %110 = fneg double %105, !dbg !1953
  store double %110, ptr %106, align 8, !dbg !1954, !tbaa !1436
  %111 = sub nsw i32 0, %51, !dbg !1955
  br label %963, !dbg !1956

112:                                              ; preds = %46
  %113 = icmp ugt i32 %11, 2146435071, !dbg !1957
  br i1 %113, label %114, label %117, !dbg !1959

114:                                              ; preds = %112
  %115 = fsub double %0, %0, !dbg !1960
  %116 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1962
  store double %115, ptr %116, align 8, !dbg !1963, !tbaa !1436
  store double %115, ptr %1, align 8, !dbg !1964, !tbaa !1436
  br label %963, !dbg !1965

117:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !1966
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !877, metadata !DIExpression()), !dbg !1966
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !662, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1819
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !872, metadata !DIExpression()), !dbg !1968
  tail call void @llvm.dbg.value(metadata i64 0, metadata !877, metadata !DIExpression()), !dbg !1968
  tail call void @llvm.dbg.value(metadata i64 0, metadata !678, metadata !DIExpression()), !dbg !1970
  tail call void @llvm.dbg.value(metadata i64 0, metadata !678, metadata !DIExpression()), !dbg !1970
  %118 = and i64 %8, 4294967295, !dbg !1971
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !678, metadata !DIExpression()), !dbg !1970
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !946, metadata !DIExpression()), !dbg !1972
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !951, metadata !DIExpression()), !dbg !1972
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !646, metadata !DIExpression()), !dbg !1819
  %119 = lshr i32 %11, 20
  %120 = add nsw i32 %119, -1046, !dbg !1974
  tail call void @llvm.dbg.value(metadata i32 %120, metadata !655, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !872, metadata !DIExpression()), !dbg !1975
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !877, metadata !DIExpression()), !dbg !1975
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !680, metadata !DIExpression()), !dbg !1977
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !680, metadata !DIExpression()), !dbg !1977
  %121 = shl nsw i32 %120, 20, !dbg !1978
  %122 = sub nsw i32 %11, %121, !dbg !1978
  %123 = sext i32 %122 to i64, !dbg !1978
  %124 = shl nsw i64 %123, 32, !dbg !1978
  %125 = or disjoint i64 %124, %118, !dbg !1978
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !680, metadata !DIExpression()), !dbg !1977
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !946, metadata !DIExpression()), !dbg !1979
  %126 = bitcast i64 %125 to double, !dbg !1981
  tail call void @llvm.dbg.value(metadata double %126, metadata !951, metadata !DIExpression()), !dbg !1979
  tail call void @llvm.dbg.value(metadata double %126, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i32 0, metadata !656, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata double %126, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 0, metadata !656, metadata !DIExpression()), !dbg !1819
  %127 = fptosi double %126 to i32, !dbg !1982
  %128 = sitofp i32 %127 to double, !dbg !1986
  store double %128, ptr %7, align 8, !dbg !1987, !tbaa !1436
  %129 = fsub double %126, %128, !dbg !1988
  %130 = fmul double %129, 0x4170000000000000, !dbg !1989
  tail call void @llvm.dbg.value(metadata double %130, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 1, metadata !656, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata double %130, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 1, metadata !656, metadata !DIExpression()), !dbg !1819
  %131 = fptosi double %130 to i32, !dbg !1982
  %132 = sitofp i32 %131 to double, !dbg !1986
  %133 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 1, !dbg !1990
  store double %132, ptr %133, align 8, !dbg !1987, !tbaa !1436
  %134 = fsub double %130, %132, !dbg !1988
  %135 = fmul double %134, 0x4170000000000000, !dbg !1989
  tail call void @llvm.dbg.value(metadata double %135, metadata !646, metadata !DIExpression()), !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 2, metadata !656, metadata !DIExpression()), !dbg !1819
  %136 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 2, !dbg !1991
  store double %135, ptr %136, align 8, !dbg !1992, !tbaa !1436
  tail call void @llvm.dbg.value(metadata i32 3, metadata !658, metadata !DIExpression()), !dbg !1819
  br label %137, !dbg !1993

137:                                              ; preds = %137, %117
  %138 = phi i32 [ %144, %137 ], [ 0, %117 ]
  %139 = phi i64 [ %140, %137 ], [ 3, %117 ], !dbg !1819
  tail call void @llvm.dbg.value(metadata i64 %139, metadata !658, metadata !DIExpression()), !dbg !1819
  %140 = add nsw i64 %139, -1, !dbg !1994
  %141 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 %140, !dbg !1995
  %142 = load double, ptr %141, align 8, !dbg !1995, !tbaa !1436
  %143 = fcmp oeq double %142, 0.000000e+00, !dbg !1996
  %144 = add i32 %138, 1, !dbg !1993
  br i1 %143, label %137, label %145, !dbg !1993, !llvm.loop !1997

145:                                              ; preds = %137
  %146 = trunc i64 %139 to i32, !dbg !2000
  call void @llvm.dbg.value(metadata ptr %7, metadata !718, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata ptr %1, metadata !719, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %120, metadata !720, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %146, metadata !721, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 2, metadata !722, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata ptr @__ieee754_rem_pio2.two_over_pi, metadata !723, metadata !DIExpression()), !dbg !2002
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %3) #11, !dbg !2000
  call void @llvm.dbg.declare(metadata ptr %3, metadata !731, metadata !DIExpression()), !dbg !2003
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %4) #11, !dbg !2004
  call void @llvm.dbg.declare(metadata ptr %4, metadata !743, metadata !DIExpression()), !dbg !2005
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %5) #11, !dbg !2004
  call void @llvm.dbg.declare(metadata ptr %5, metadata !745, metadata !DIExpression()), !dbg !2006
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %6) #11, !dbg !2004
  call void @llvm.dbg.declare(metadata ptr %6, metadata !746, metadata !DIExpression()), !dbg !2007
  call void @llvm.dbg.value(metadata i32 4, metadata !728, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 4, metadata !727, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %140, metadata !725, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2002
  %147 = add nsw i32 %119, -1049, !dbg !2008
  %148 = sdiv i32 %147, 24, !dbg !2009
  call void @llvm.dbg.value(metadata i32 %148, metadata !726, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %148, metadata !726, metadata !DIExpression()), !dbg !2002
  %149 = mul nsw i32 %148, -24, !dbg !2010
  %150 = add nsw i32 %149, %120, !dbg !2010
  %151 = add nsw i32 %150, -24, !dbg !2011
  call void @llvm.dbg.value(metadata i32 %151, metadata !739, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i64 %140), metadata !736, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %146, metadata !738, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i64 %140), metadata !736, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  %152 = icmp slt i32 %146, -3, !dbg !2012
  br i1 %152, label %455, label %153, !dbg !2015

153:                                              ; preds = %145
  %154 = trunc i64 %140 to i32, !dbg !2000
  call void @llvm.dbg.value(metadata i32 %154, metadata !725, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i32 %154), metadata !736, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  %155 = add i32 %146, 3, !dbg !2016
  call void @llvm.dbg.value(metadata i32 %155, metadata !738, metadata !DIExpression()), !dbg !2002
  %156 = sub nsw i32 %148, %154, !dbg !2017
  call void @llvm.dbg.value(metadata i32 %156, metadata !736, metadata !DIExpression()), !dbg !2002
  %157 = tail call i32 @llvm.smax.i32(i32 %155, i32 0), !dbg !2015
  %158 = add nuw i32 %157, 1, !dbg !2015
  %159 = zext i32 %158 to i64, !dbg !2012
  br label %162, !dbg !2015

160:                                              ; preds = %171
  %161 = icmp sgt i32 %146, 0
  call void @llvm.dbg.value(metadata i64 0, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  br i1 %161, label %177, label %455, !dbg !2018

162:                                              ; preds = %171, %153
  %163 = phi i64 [ 0, %153 ], [ %174, %171 ]
  %164 = phi i32 [ %156, %153 ], [ %175, %171 ]
  call void @llvm.dbg.value(metadata i32 %164, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %163, metadata !735, metadata !DIExpression()), !dbg !2002
  %165 = icmp slt i32 %164, 0, !dbg !2023
  br i1 %165, label %171, label %166, !dbg !2025

166:                                              ; preds = %162
  %167 = zext nneg i32 %164 to i64
  %168 = getelementptr inbounds i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %167, !dbg !2026
  %169 = load i32, ptr %168, align 4, !dbg !2026, !tbaa !1896
  %170 = sitofp i32 %169 to double, !dbg !2027
  br label %171, !dbg !2025

171:                                              ; preds = %166, %162
  %172 = phi double [ %170, %166 ], [ 0.000000e+00, %162 ], !dbg !2025
  %173 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %163, !dbg !2028
  store double %172, ptr %173, align 8, !dbg !2029, !tbaa !1436
  %174 = add nuw nsw i64 %163, 1, !dbg !2030
  call void @llvm.dbg.value(metadata i64 %174, metadata !735, metadata !DIExpression()), !dbg !2002
  %175 = add nsw i32 %164, 1, !dbg !2031
  call void @llvm.dbg.value(metadata i32 %175, metadata !736, metadata !DIExpression()), !dbg !2002
  %176 = icmp eq i64 %174, %159, !dbg !2012
  br i1 %176, label %160, label %162, !dbg !2015, !llvm.loop !2032

177:                                              ; preds = %160
  %178 = and i64 %139, 4294967295, !dbg !2034
  %179 = icmp ult i64 %178, 8, !dbg !2018
  br i1 %179, label %229, label %180, !dbg !2018

180:                                              ; preds = %177
  %181 = add nsw i64 %178, -1, !dbg !2018
  %182 = trunc i64 %181 to i32, !dbg !2018
  %183 = sub i32 %154, %182, !dbg !2018
  %184 = icmp sgt i32 %183, %154, !dbg !2018
  %185 = icmp ugt i64 %181, 4294967295, !dbg !2018
  %186 = or i1 %184, %185, !dbg !2018
  br i1 %186, label %229, label %187

187:                                              ; preds = %180
  %188 = and i64 %139, 7, !dbg !2018
  %189 = sub nsw i64 %178, %188, !dbg !2018
  br label %190, !dbg !2018

190:                                              ; preds = %190, %187
  %191 = phi i64 [ 0, %187 ], [ %225, %190 ], !dbg !2036
  %192 = phi double [ 0.000000e+00, %187 ], [ %224, %190 ]
  %193 = getelementptr inbounds double, ptr %7, i64 %191, !dbg !2037
  %194 = getelementptr inbounds double, ptr %193, i64 2, !dbg !2037
  %195 = getelementptr inbounds double, ptr %193, i64 4, !dbg !2037
  %196 = getelementptr inbounds double, ptr %193, i64 6, !dbg !2037
  %197 = load <2 x double>, ptr %193, align 8, !dbg !2037, !tbaa !1436
  %198 = load <2 x double>, ptr %194, align 8, !dbg !2037, !tbaa !1436
  %199 = load <2 x double>, ptr %195, align 8, !dbg !2037, !tbaa !1436
  %200 = load <2 x double>, ptr %196, align 8, !dbg !2037, !tbaa !1436
  %201 = sub i64 %140, %191, !dbg !2038
  %202 = shl i64 %201, 32, !dbg !2039
  %203 = ashr exact i64 %202, 32, !dbg !2039
  %204 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %203, !dbg !2039
  %205 = getelementptr inbounds double, ptr %204, i64 -1, !dbg !2039
  %206 = getelementptr inbounds double, ptr %204, i64 -3, !dbg !2039
  %207 = getelementptr inbounds double, ptr %204, i64 -5, !dbg !2039
  %208 = getelementptr inbounds double, ptr %204, i64 -7, !dbg !2039
  %209 = load <2 x double>, ptr %205, align 8, !dbg !2039, !tbaa !1436
  %210 = shufflevector <2 x double> %209, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %211 = load <2 x double>, ptr %206, align 8, !dbg !2039, !tbaa !1436
  %212 = shufflevector <2 x double> %211, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %213 = load <2 x double>, ptr %207, align 8, !dbg !2039, !tbaa !1436
  %214 = shufflevector <2 x double> %213, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %215 = load <2 x double>, ptr %208, align 8, !dbg !2039, !tbaa !1436
  %216 = shufflevector <2 x double> %215, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %217 = fmul <2 x double> %197, %210
  %218 = fmul <2 x double> %198, %212
  %219 = fmul <2 x double> %199, %214
  %220 = fmul <2 x double> %200, %216
  %221 = tail call double @llvm.vector.reduce.fadd.v2f64(double %192, <2 x double> %217)
  %222 = tail call double @llvm.vector.reduce.fadd.v2f64(double %221, <2 x double> %218)
  %223 = tail call double @llvm.vector.reduce.fadd.v2f64(double %222, <2 x double> %219)
  %224 = tail call double @llvm.vector.reduce.fadd.v2f64(double %223, <2 x double> %220)
  %225 = add nuw i64 %191, 8, !dbg !2036
  %226 = icmp eq i64 %225, %189, !dbg !2036
  br i1 %226, label %227, label %190, !dbg !2036, !llvm.loop !2040

227:                                              ; preds = %190
  %228 = icmp eq i64 %188, 0, !dbg !2018
  br i1 %228, label %245, label %229, !dbg !2018

229:                                              ; preds = %180, %177, %227
  %230 = phi i64 [ 0, %180 ], [ 0, %177 ], [ %189, %227 ]
  %231 = phi double [ 0.000000e+00, %180 ], [ 0.000000e+00, %177 ], [ %224, %227 ]
  br label %232, !dbg !2018

232:                                              ; preds = %229, %232
  %233 = phi i64 [ %243, %232 ], [ %230, %229 ]
  %234 = phi double [ %242, %232 ], [ %231, %229 ]
  call void @llvm.dbg.value(metadata double %234, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %233, metadata !736, metadata !DIExpression()), !dbg !2002
  %235 = getelementptr inbounds double, ptr %7, i64 %233, !dbg !2037
  %236 = load double, ptr %235, align 8, !dbg !2037, !tbaa !1436
  %237 = sub i64 %140, %233, !dbg !2038
  %238 = shl i64 %237, 32, !dbg !2039
  %239 = ashr exact i64 %238, 32, !dbg !2039
  %240 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %239, !dbg !2039
  %241 = load double, ptr %240, align 8, !dbg !2039, !tbaa !1436
  %242 = tail call double @llvm.fmuladd.f64(double %236, double %241, double %234), !dbg !2044
  call void @llvm.dbg.value(metadata double %242, metadata !742, metadata !DIExpression()), !dbg !2002
  %243 = add nuw nsw i64 %233, 1, !dbg !2036
  call void @llvm.dbg.value(metadata i64 %243, metadata !736, metadata !DIExpression()), !dbg !2002
  %244 = icmp eq i64 %243, %178, !dbg !2034
  br i1 %244, label %245, label %232, !dbg !2018, !llvm.loop !2045

245:                                              ; preds = %232, %227
  %246 = phi double [ %224, %227 ], [ %242, %232 ], !dbg !2044
  store double %246, ptr %6, align 8, !dbg !2046, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 1, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  %247 = icmp ult i64 %178, 8, !dbg !2018
  br i1 %247, label %297, label %248, !dbg !2018

248:                                              ; preds = %245
  %249 = add nsw i64 %178, -1, !dbg !2018
  %250 = trunc i64 %249 to i32, !dbg !2018
  %251 = sub i32 %146, %250, !dbg !2018
  %252 = icmp sgt i32 %251, %146, !dbg !2018
  %253 = icmp ugt i64 %249, 4294967295, !dbg !2018
  %254 = or i1 %252, %253, !dbg !2018
  br i1 %254, label %297, label %255

255:                                              ; preds = %248
  %256 = and i64 %139, 7, !dbg !2018
  %257 = sub nsw i64 %178, %256, !dbg !2018
  br label %258, !dbg !2018

258:                                              ; preds = %258, %255
  %259 = phi i64 [ 0, %255 ], [ %293, %258 ], !dbg !2036
  %260 = phi double [ 0.000000e+00, %255 ], [ %292, %258 ]
  %261 = getelementptr inbounds double, ptr %7, i64 %259, !dbg !2037
  %262 = getelementptr inbounds double, ptr %261, i64 2, !dbg !2037
  %263 = getelementptr inbounds double, ptr %261, i64 4, !dbg !2037
  %264 = getelementptr inbounds double, ptr %261, i64 6, !dbg !2037
  %265 = load <2 x double>, ptr %261, align 8, !dbg !2037, !tbaa !1436
  %266 = load <2 x double>, ptr %262, align 8, !dbg !2037, !tbaa !1436
  %267 = load <2 x double>, ptr %263, align 8, !dbg !2037, !tbaa !1436
  %268 = load <2 x double>, ptr %264, align 8, !dbg !2037, !tbaa !1436
  %269 = sub i64 %139, %259, !dbg !2038
  %270 = shl i64 %269, 32, !dbg !2039
  %271 = ashr exact i64 %270, 32, !dbg !2039
  %272 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %271, !dbg !2039
  %273 = getelementptr inbounds double, ptr %272, i64 -1, !dbg !2039
  %274 = getelementptr inbounds double, ptr %272, i64 -3, !dbg !2039
  %275 = getelementptr inbounds double, ptr %272, i64 -5, !dbg !2039
  %276 = getelementptr inbounds double, ptr %272, i64 -7, !dbg !2039
  %277 = load <2 x double>, ptr %273, align 8, !dbg !2039, !tbaa !1436
  %278 = shufflevector <2 x double> %277, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %279 = load <2 x double>, ptr %274, align 8, !dbg !2039, !tbaa !1436
  %280 = shufflevector <2 x double> %279, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %281 = load <2 x double>, ptr %275, align 8, !dbg !2039, !tbaa !1436
  %282 = shufflevector <2 x double> %281, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %283 = load <2 x double>, ptr %276, align 8, !dbg !2039, !tbaa !1436
  %284 = shufflevector <2 x double> %283, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %285 = fmul <2 x double> %265, %278
  %286 = fmul <2 x double> %266, %280
  %287 = fmul <2 x double> %267, %282
  %288 = fmul <2 x double> %268, %284
  %289 = tail call double @llvm.vector.reduce.fadd.v2f64(double %260, <2 x double> %285)
  %290 = tail call double @llvm.vector.reduce.fadd.v2f64(double %289, <2 x double> %286)
  %291 = tail call double @llvm.vector.reduce.fadd.v2f64(double %290, <2 x double> %287)
  %292 = tail call double @llvm.vector.reduce.fadd.v2f64(double %291, <2 x double> %288)
  %293 = add nuw i64 %259, 8, !dbg !2036
  %294 = icmp eq i64 %293, %257, !dbg !2036
  br i1 %294, label %295, label %258, !dbg !2036, !llvm.loop !2047

295:                                              ; preds = %258
  %296 = icmp eq i64 %256, 0, !dbg !2018
  br i1 %296, label %313, label %297, !dbg !2018

297:                                              ; preds = %248, %245, %295
  %298 = phi i64 [ 0, %248 ], [ 0, %245 ], [ %257, %295 ]
  %299 = phi double [ 0.000000e+00, %248 ], [ 0.000000e+00, %245 ], [ %292, %295 ]
  br label %300, !dbg !2018

300:                                              ; preds = %297, %300
  %301 = phi i64 [ %311, %300 ], [ %298, %297 ]
  %302 = phi double [ %310, %300 ], [ %299, %297 ]
  call void @llvm.dbg.value(metadata double %302, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %301, metadata !736, metadata !DIExpression()), !dbg !2002
  %303 = getelementptr inbounds double, ptr %7, i64 %301, !dbg !2037
  %304 = load double, ptr %303, align 8, !dbg !2037, !tbaa !1436
  %305 = sub i64 %139, %301, !dbg !2038
  %306 = shl i64 %305, 32, !dbg !2039
  %307 = ashr exact i64 %306, 32, !dbg !2039
  %308 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %307, !dbg !2039
  %309 = load double, ptr %308, align 8, !dbg !2039, !tbaa !1436
  %310 = tail call double @llvm.fmuladd.f64(double %304, double %309, double %302), !dbg !2044
  call void @llvm.dbg.value(metadata double %310, metadata !742, metadata !DIExpression()), !dbg !2002
  %311 = add nuw nsw i64 %301, 1, !dbg !2036
  call void @llvm.dbg.value(metadata i64 %311, metadata !736, metadata !DIExpression()), !dbg !2002
  %312 = icmp eq i64 %311, %178, !dbg !2034
  br i1 %312, label %313, label %300, !dbg !2018, !llvm.loop !2048

313:                                              ; preds = %300, %295
  %314 = phi double [ %292, %295 ], [ %310, %300 ], !dbg !2044
  %315 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 1, !dbg !2049
  store double %314, ptr %315, align 8, !dbg !2046, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 2, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  %316 = add i64 %139, 1
  %317 = icmp ult i64 %178, 10, !dbg !2018
  br i1 %317, label %368, label %318, !dbg !2018

318:                                              ; preds = %313
  %319 = add nsw i64 %178, -1, !dbg !2018
  %320 = sub i32 4, %138, !dbg !2018
  %321 = trunc i64 %319 to i32, !dbg !2018
  %322 = sub i32 %320, %321, !dbg !2018
  %323 = icmp sgt i32 %322, %320, !dbg !2018
  %324 = icmp ugt i64 %319, 4294967295, !dbg !2018
  %325 = or i1 %323, %324, !dbg !2018
  br i1 %325, label %368, label %326

326:                                              ; preds = %318
  %327 = and i64 %139, 7, !dbg !2018
  %328 = sub nsw i64 %178, %327, !dbg !2018
  br label %329, !dbg !2018

329:                                              ; preds = %329, %326
  %330 = phi i64 [ 0, %326 ], [ %364, %329 ], !dbg !2036
  %331 = phi double [ 0.000000e+00, %326 ], [ %363, %329 ]
  %332 = getelementptr inbounds double, ptr %7, i64 %330, !dbg !2037
  %333 = getelementptr inbounds double, ptr %332, i64 2, !dbg !2037
  %334 = getelementptr inbounds double, ptr %332, i64 4, !dbg !2037
  %335 = getelementptr inbounds double, ptr %332, i64 6, !dbg !2037
  %336 = load <2 x double>, ptr %332, align 8, !dbg !2037, !tbaa !1436
  %337 = load <2 x double>, ptr %333, align 8, !dbg !2037, !tbaa !1436
  %338 = load <2 x double>, ptr %334, align 8, !dbg !2037, !tbaa !1436
  %339 = load <2 x double>, ptr %335, align 8, !dbg !2037, !tbaa !1436
  %340 = sub i64 %316, %330, !dbg !2038
  %341 = shl i64 %340, 32, !dbg !2039
  %342 = ashr exact i64 %341, 32, !dbg !2039
  %343 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %342, !dbg !2039
  %344 = getelementptr inbounds double, ptr %343, i64 -1, !dbg !2039
  %345 = getelementptr inbounds double, ptr %343, i64 -3, !dbg !2039
  %346 = getelementptr inbounds double, ptr %343, i64 -5, !dbg !2039
  %347 = getelementptr inbounds double, ptr %343, i64 -7, !dbg !2039
  %348 = load <2 x double>, ptr %344, align 8, !dbg !2039, !tbaa !1436
  %349 = shufflevector <2 x double> %348, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %350 = load <2 x double>, ptr %345, align 8, !dbg !2039, !tbaa !1436
  %351 = shufflevector <2 x double> %350, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %352 = load <2 x double>, ptr %346, align 8, !dbg !2039, !tbaa !1436
  %353 = shufflevector <2 x double> %352, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %354 = load <2 x double>, ptr %347, align 8, !dbg !2039, !tbaa !1436
  %355 = shufflevector <2 x double> %354, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %356 = fmul <2 x double> %336, %349
  %357 = fmul <2 x double> %337, %351
  %358 = fmul <2 x double> %338, %353
  %359 = fmul <2 x double> %339, %355
  %360 = tail call double @llvm.vector.reduce.fadd.v2f64(double %331, <2 x double> %356)
  %361 = tail call double @llvm.vector.reduce.fadd.v2f64(double %360, <2 x double> %357)
  %362 = tail call double @llvm.vector.reduce.fadd.v2f64(double %361, <2 x double> %358)
  %363 = tail call double @llvm.vector.reduce.fadd.v2f64(double %362, <2 x double> %359)
  %364 = add nuw i64 %330, 8, !dbg !2036
  %365 = icmp eq i64 %364, %328, !dbg !2036
  br i1 %365, label %366, label %329, !dbg !2036, !llvm.loop !2050

366:                                              ; preds = %329
  %367 = icmp eq i64 %327, 0, !dbg !2018
  br i1 %367, label %384, label %368, !dbg !2018

368:                                              ; preds = %318, %313, %366
  %369 = phi i64 [ 0, %318 ], [ 0, %313 ], [ %328, %366 ]
  %370 = phi double [ 0.000000e+00, %318 ], [ 0.000000e+00, %313 ], [ %363, %366 ]
  br label %371, !dbg !2018

371:                                              ; preds = %368, %371
  %372 = phi i64 [ %382, %371 ], [ %369, %368 ]
  %373 = phi double [ %381, %371 ], [ %370, %368 ]
  call void @llvm.dbg.value(metadata double %373, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %372, metadata !736, metadata !DIExpression()), !dbg !2002
  %374 = getelementptr inbounds double, ptr %7, i64 %372, !dbg !2037
  %375 = load double, ptr %374, align 8, !dbg !2037, !tbaa !1436
  %376 = sub i64 %316, %372, !dbg !2038
  %377 = shl i64 %376, 32, !dbg !2039
  %378 = ashr exact i64 %377, 32, !dbg !2039
  %379 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %378, !dbg !2039
  %380 = load double, ptr %379, align 8, !dbg !2039, !tbaa !1436
  %381 = tail call double @llvm.fmuladd.f64(double %375, double %380, double %373), !dbg !2044
  call void @llvm.dbg.value(metadata double %381, metadata !742, metadata !DIExpression()), !dbg !2002
  %382 = add nuw nsw i64 %372, 1, !dbg !2036
  call void @llvm.dbg.value(metadata i64 %382, metadata !736, metadata !DIExpression()), !dbg !2002
  %383 = icmp eq i64 %382, %178, !dbg !2034
  br i1 %383, label %384, label %371, !dbg !2018, !llvm.loop !2051

384:                                              ; preds = %371, %366
  %385 = phi double [ %363, %366 ], [ %381, %371 ], !dbg !2044
  %386 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 2, !dbg !2049
  store double %385, ptr %386, align 8, !dbg !2046, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 3, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  %387 = add i64 %139, 2
  %388 = icmp ult i64 %178, 10, !dbg !2018
  br i1 %388, label %439, label %389, !dbg !2018

389:                                              ; preds = %384
  %390 = add nsw i64 %178, -1, !dbg !2018
  %391 = sub i32 5, %138, !dbg !2018
  %392 = trunc i64 %390 to i32, !dbg !2018
  %393 = sub i32 %391, %392, !dbg !2018
  %394 = icmp sgt i32 %393, %391, !dbg !2018
  %395 = icmp ugt i64 %390, 4294967295, !dbg !2018
  %396 = or i1 %394, %395, !dbg !2018
  br i1 %396, label %439, label %397

397:                                              ; preds = %389
  %398 = and i64 %139, 7, !dbg !2018
  %399 = sub nsw i64 %178, %398, !dbg !2018
  br label %400, !dbg !2018

400:                                              ; preds = %400, %397
  %401 = phi i64 [ 0, %397 ], [ %435, %400 ], !dbg !2036
  %402 = phi double [ 0.000000e+00, %397 ], [ %434, %400 ]
  %403 = getelementptr inbounds double, ptr %7, i64 %401, !dbg !2037
  %404 = getelementptr inbounds double, ptr %403, i64 2, !dbg !2037
  %405 = getelementptr inbounds double, ptr %403, i64 4, !dbg !2037
  %406 = getelementptr inbounds double, ptr %403, i64 6, !dbg !2037
  %407 = load <2 x double>, ptr %403, align 8, !dbg !2037, !tbaa !1436
  %408 = load <2 x double>, ptr %404, align 8, !dbg !2037, !tbaa !1436
  %409 = load <2 x double>, ptr %405, align 8, !dbg !2037, !tbaa !1436
  %410 = load <2 x double>, ptr %406, align 8, !dbg !2037, !tbaa !1436
  %411 = sub i64 %387, %401, !dbg !2038
  %412 = shl i64 %411, 32, !dbg !2039
  %413 = ashr exact i64 %412, 32, !dbg !2039
  %414 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %413, !dbg !2039
  %415 = getelementptr inbounds double, ptr %414, i64 -1, !dbg !2039
  %416 = getelementptr inbounds double, ptr %414, i64 -3, !dbg !2039
  %417 = getelementptr inbounds double, ptr %414, i64 -5, !dbg !2039
  %418 = getelementptr inbounds double, ptr %414, i64 -7, !dbg !2039
  %419 = load <2 x double>, ptr %415, align 8, !dbg !2039, !tbaa !1436
  %420 = shufflevector <2 x double> %419, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %421 = load <2 x double>, ptr %416, align 8, !dbg !2039, !tbaa !1436
  %422 = shufflevector <2 x double> %421, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %423 = load <2 x double>, ptr %417, align 8, !dbg !2039, !tbaa !1436
  %424 = shufflevector <2 x double> %423, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %425 = load <2 x double>, ptr %418, align 8, !dbg !2039, !tbaa !1436
  %426 = shufflevector <2 x double> %425, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %427 = fmul <2 x double> %407, %420
  %428 = fmul <2 x double> %408, %422
  %429 = fmul <2 x double> %409, %424
  %430 = fmul <2 x double> %410, %426
  %431 = tail call double @llvm.vector.reduce.fadd.v2f64(double %402, <2 x double> %427)
  %432 = tail call double @llvm.vector.reduce.fadd.v2f64(double %431, <2 x double> %428)
  %433 = tail call double @llvm.vector.reduce.fadd.v2f64(double %432, <2 x double> %429)
  %434 = tail call double @llvm.vector.reduce.fadd.v2f64(double %433, <2 x double> %430)
  %435 = add nuw i64 %401, 8, !dbg !2036
  %436 = icmp eq i64 %435, %399, !dbg !2036
  br i1 %436, label %437, label %400, !dbg !2036, !llvm.loop !2052

437:                                              ; preds = %400
  %438 = icmp eq i64 %398, 0, !dbg !2018
  br i1 %438, label %457, label %439, !dbg !2018

439:                                              ; preds = %389, %384, %437
  %440 = phi i64 [ 0, %389 ], [ 0, %384 ], [ %399, %437 ]
  %441 = phi double [ 0.000000e+00, %389 ], [ 0.000000e+00, %384 ], [ %434, %437 ]
  br label %442, !dbg !2018

442:                                              ; preds = %439, %442
  %443 = phi i64 [ %453, %442 ], [ %440, %439 ]
  %444 = phi double [ %452, %442 ], [ %441, %439 ]
  call void @llvm.dbg.value(metadata double %444, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %443, metadata !736, metadata !DIExpression()), !dbg !2002
  %445 = getelementptr inbounds double, ptr %7, i64 %443, !dbg !2037
  %446 = load double, ptr %445, align 8, !dbg !2037, !tbaa !1436
  %447 = sub i64 %387, %443, !dbg !2038
  %448 = shl i64 %447, 32, !dbg !2039
  %449 = ashr exact i64 %448, 32, !dbg !2039
  %450 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %449, !dbg !2039
  %451 = load double, ptr %450, align 8, !dbg !2039, !tbaa !1436
  %452 = tail call double @llvm.fmuladd.f64(double %446, double %451, double %444), !dbg !2044
  call void @llvm.dbg.value(metadata double %452, metadata !742, metadata !DIExpression()), !dbg !2002
  %453 = add nuw nsw i64 %443, 1, !dbg !2036
  call void @llvm.dbg.value(metadata i64 %453, metadata !736, metadata !DIExpression()), !dbg !2002
  %454 = icmp eq i64 %453, %178, !dbg !2034
  br i1 %454, label %457, label %442, !dbg !2018, !llvm.loop !2053

455:                                              ; preds = %145, %160
  call void @llvm.dbg.value(metadata i64 1, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 2, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 3, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 4, metadata !735, metadata !DIExpression()), !dbg !2002
  %456 = and i64 %139, 4294967295
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %6, i8 0, i64 32, i1 false), !dbg !2046
  br label %526, !dbg !2018

457:                                              ; preds = %442, %437
  %458 = phi double [ %434, %437 ], [ %452, %442 ], !dbg !2044
  %459 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 3, !dbg !2049
  store double %458, ptr %459, align 8, !dbg !2046, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 4, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  %460 = icmp ult i64 %178, 10, !dbg !2018
  br i1 %460, label %510, label %461, !dbg !2018

461:                                              ; preds = %457
  %462 = add nsw i64 %178, -1, !dbg !2018
  %463 = trunc i64 %462 to i32, !dbg !2018
  %464 = sub i32 %155, %463, !dbg !2018
  %465 = icmp sgt i32 %464, %155, !dbg !2018
  %466 = icmp ugt i64 %462, 4294967295, !dbg !2018
  %467 = or i1 %465, %466, !dbg !2018
  br i1 %467, label %510, label %468

468:                                              ; preds = %461
  %469 = and i64 %139, 7, !dbg !2018
  %470 = sub nsw i64 %178, %469, !dbg !2018
  br label %471, !dbg !2018

471:                                              ; preds = %471, %468
  %472 = phi i64 [ 0, %468 ], [ %506, %471 ], !dbg !2036
  %473 = phi double [ 0.000000e+00, %468 ], [ %505, %471 ]
  %474 = trunc i64 %472 to i32, !dbg !2018
  %475 = getelementptr inbounds double, ptr %7, i64 %472, !dbg !2037
  %476 = getelementptr inbounds double, ptr %475, i64 2, !dbg !2037
  %477 = getelementptr inbounds double, ptr %475, i64 4, !dbg !2037
  %478 = getelementptr inbounds double, ptr %475, i64 6, !dbg !2037
  %479 = load <2 x double>, ptr %475, align 8, !dbg !2037, !tbaa !1436
  %480 = load <2 x double>, ptr %476, align 8, !dbg !2037, !tbaa !1436
  %481 = load <2 x double>, ptr %477, align 8, !dbg !2037, !tbaa !1436
  %482 = load <2 x double>, ptr %478, align 8, !dbg !2037, !tbaa !1436
  %483 = sub i32 %155, %474, !dbg !2038
  %484 = sext i32 %483 to i64, !dbg !2039
  %485 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %484, !dbg !2039
  %486 = getelementptr inbounds double, ptr %485, i64 -1, !dbg !2039
  %487 = getelementptr inbounds double, ptr %485, i64 -3, !dbg !2039
  %488 = getelementptr inbounds double, ptr %485, i64 -5, !dbg !2039
  %489 = getelementptr inbounds double, ptr %485, i64 -7, !dbg !2039
  %490 = load <2 x double>, ptr %486, align 8, !dbg !2039, !tbaa !1436
  %491 = shufflevector <2 x double> %490, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %492 = load <2 x double>, ptr %487, align 8, !dbg !2039, !tbaa !1436
  %493 = shufflevector <2 x double> %492, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %494 = load <2 x double>, ptr %488, align 8, !dbg !2039, !tbaa !1436
  %495 = shufflevector <2 x double> %494, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %496 = load <2 x double>, ptr %489, align 8, !dbg !2039, !tbaa !1436
  %497 = shufflevector <2 x double> %496, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2039
  %498 = fmul <2 x double> %479, %491
  %499 = fmul <2 x double> %480, %493
  %500 = fmul <2 x double> %481, %495
  %501 = fmul <2 x double> %482, %497
  %502 = tail call double @llvm.vector.reduce.fadd.v2f64(double %473, <2 x double> %498)
  %503 = tail call double @llvm.vector.reduce.fadd.v2f64(double %502, <2 x double> %499)
  %504 = tail call double @llvm.vector.reduce.fadd.v2f64(double %503, <2 x double> %500)
  %505 = tail call double @llvm.vector.reduce.fadd.v2f64(double %504, <2 x double> %501)
  %506 = add nuw i64 %472, 8, !dbg !2036
  %507 = icmp eq i64 %506, %470, !dbg !2036
  br i1 %507, label %508, label %471, !dbg !2036, !llvm.loop !2054

508:                                              ; preds = %471
  %509 = icmp eq i64 %469, 0, !dbg !2018
  br i1 %509, label %526, label %510, !dbg !2018

510:                                              ; preds = %461, %457, %508
  %511 = phi i64 [ 0, %461 ], [ 0, %457 ], [ %470, %508 ]
  %512 = phi double [ 0.000000e+00, %461 ], [ 0.000000e+00, %457 ], [ %505, %508 ]
  br label %513, !dbg !2018

513:                                              ; preds = %510, %513
  %514 = phi i64 [ %524, %513 ], [ %511, %510 ]
  %515 = phi double [ %523, %513 ], [ %512, %510 ]
  call void @llvm.dbg.value(metadata double %515, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %514, metadata !736, metadata !DIExpression()), !dbg !2002
  %516 = getelementptr inbounds double, ptr %7, i64 %514, !dbg !2037
  %517 = load double, ptr %516, align 8, !dbg !2037, !tbaa !1436
  %518 = trunc i64 %514 to i32, !dbg !2038
  %519 = sub i32 %155, %518, !dbg !2038
  %520 = sext i32 %519 to i64, !dbg !2039
  %521 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %520, !dbg !2039
  %522 = load double, ptr %521, align 8, !dbg !2039, !tbaa !1436
  %523 = tail call double @llvm.fmuladd.f64(double %517, double %522, double %515), !dbg !2044
  call void @llvm.dbg.value(metadata double %523, metadata !742, metadata !DIExpression()), !dbg !2002
  %524 = add nuw nsw i64 %514, 1, !dbg !2036
  call void @llvm.dbg.value(metadata i64 %524, metadata !736, metadata !DIExpression()), !dbg !2002
  %525 = icmp eq i64 %524, %178, !dbg !2034
  br i1 %525, label %526, label %513, !dbg !2018, !llvm.loop !2055

526:                                              ; preds = %513, %508, %455
  %527 = phi i64 [ %456, %455 ], [ %178, %508 ], [ %178, %513 ]
  %528 = phi i1 [ false, %455 ], [ true, %508 ], [ true, %513 ]
  %529 = phi double [ 0.000000e+00, %455 ], [ %505, %508 ], [ %523, %513 ], !dbg !2056
  %530 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 4, !dbg !2049
  store double %529, ptr %530, align 8, !dbg !2046, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 5, metadata !735, metadata !DIExpression()), !dbg !2002
  %531 = icmp sgt i32 %150, 24
  %532 = icmp eq i32 %151, 0
  %533 = sub nsw i32 48, %150
  %534 = sub nsw i32 47, %150
  %535 = sext i32 %148 to i64, !dbg !2057
  %536 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 3
  %537 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 2
  %538 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 1
  %539 = getelementptr i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %535
  %540 = icmp ult i64 %527, 8
  %541 = and i64 %527, 4294967288
  %542 = icmp eq i64 %527, %541
  br label %546, !dbg !2057

543:                                              ; preds = %772
  %544 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %710
  %545 = load double, ptr %544, align 8, !dbg !2059, !tbaa !1436
  br label %546, !dbg !2060, !llvm.loop !2066

546:                                              ; preds = %543, %526
  %547 = phi double [ %529, %526 ], [ %545, %543 ], !dbg !2059
  %548 = phi i32 [ 4, %526 ], [ %709, %543 ], !dbg !2002
  call void @llvm.dbg.value(metadata i32 %548, metadata !724, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.label(metadata !747), !dbg !2068
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %548, metadata !736, metadata !DIExpression()), !dbg !2002
  %549 = zext nneg i32 %548 to i64, !dbg !2059
  call void @llvm.dbg.value(metadata double %547, metadata !741, metadata !DIExpression()), !dbg !2002
  br label %550, !dbg !2069

550:                                              ; preds = %550, %546
  %551 = phi i64 [ 0, %546 ], [ %564, %550 ]
  %552 = phi i64 [ %549, %546 ], [ %560, %550 ]
  %553 = phi double [ %547, %546 ], [ %563, %550 ]
  call void @llvm.dbg.value(metadata double %553, metadata !741, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %552, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %551, metadata !735, metadata !DIExpression()), !dbg !2002
  %554 = fmul double %553, 0x3E70000000000000, !dbg !2070
  %555 = fptosi double %554 to i32, !dbg !2073
  %556 = sitofp i32 %555 to double, !dbg !2074
  call void @llvm.dbg.value(metadata double %556, metadata !742, metadata !DIExpression()), !dbg !2002
  %557 = tail call double @llvm.fmuladd.f64(double %556, double 0xC170000000000000, double %553), !dbg !2075
  %558 = fptosi double %557 to i32, !dbg !2076
  %559 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %551, !dbg !2077
  store i32 %558, ptr %559, align 4, !dbg !2078, !tbaa !1896
  %560 = add nsw i64 %552, -1, !dbg !2079
  %561 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %560, !dbg !2080
  %562 = load double, ptr %561, align 8, !dbg !2080, !tbaa !1436
  %563 = fadd double %562, %556, !dbg !2081
  call void @llvm.dbg.value(metadata double %563, metadata !741, metadata !DIExpression()), !dbg !2002
  %564 = add nuw nsw i64 %551, 1, !dbg !2082
  call void @llvm.dbg.value(metadata i64 %560, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %564, metadata !735, metadata !DIExpression()), !dbg !2002
  %565 = icmp eq i64 %564, %549, !dbg !2083
  br i1 %565, label %566, label %550, !dbg !2069, !llvm.loop !2084

566:                                              ; preds = %550
  %567 = tail call double @scalbn(double noundef %563, i32 noundef %151) #12, !dbg !2086
  call void @llvm.dbg.value(metadata double %567, metadata !741, metadata !DIExpression()), !dbg !2002
  %568 = fmul double %567, 1.250000e-01, !dbg !2087
  %569 = tail call double @llvm.floor.f64(double %568), !dbg !2088
  %570 = tail call double @llvm.fmuladd.f64(double %569, double -8.000000e+00, double %567), !dbg !2089
  call void @llvm.dbg.value(metadata double %570, metadata !741, metadata !DIExpression()), !dbg !2002
  %571 = fptosi double %570 to i32, !dbg !2090
  call void @llvm.dbg.value(metadata i32 %571, metadata !730, metadata !DIExpression()), !dbg !2002
  %572 = sitofp i32 %571 to double, !dbg !2091
  %573 = fsub double %570, %572, !dbg !2092
  call void @llvm.dbg.value(metadata double %573, metadata !741, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !740, metadata !DIExpression()), !dbg !2002
  br i1 %531, label %574, label %584, !dbg !2093

574:                                              ; preds = %566
  %575 = add nsw i32 %548, -1, !dbg !2094
  %576 = sext i32 %575 to i64, !dbg !2097
  %577 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %576, !dbg !2097
  %578 = load i32, ptr %577, align 4, !dbg !2097, !tbaa !1896
  %579 = ashr i32 %578, %533, !dbg !2098
  call void @llvm.dbg.value(metadata i32 %579, metadata !735, metadata !DIExpression()), !dbg !2002
  %580 = add nsw i32 %579, %571, !dbg !2099
  call void @llvm.dbg.value(metadata i32 %580, metadata !730, metadata !DIExpression()), !dbg !2002
  %581 = shl i32 %579, %533, !dbg !2100
  %582 = sub nsw i32 %578, %581, !dbg !2101
  store i32 %582, ptr %577, align 4, !dbg !2101, !tbaa !1896
  %583 = ashr i32 %582, %534, !dbg !2102
  call void @llvm.dbg.value(metadata i32 %583, metadata !740, metadata !DIExpression()), !dbg !2002
  br label %593, !dbg !2103

584:                                              ; preds = %566
  br i1 %532, label %585, label %591, !dbg !2104

585:                                              ; preds = %584
  %586 = add nsw i32 %548, -1, !dbg !2105
  %587 = sext i32 %586 to i64, !dbg !2108
  %588 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %587, !dbg !2108
  %589 = load i32, ptr %588, align 4, !dbg !2108, !tbaa !1896
  %590 = ashr i32 %589, 23, !dbg !2109
  call void @llvm.dbg.value(metadata i32 %590, metadata !740, metadata !DIExpression()), !dbg !2002
  br label %593, !dbg !2110

591:                                              ; preds = %584
  %592 = fcmp ult double %573, 5.000000e-01, !dbg !2111
  br i1 %592, label %634, label %597, !dbg !2113

593:                                              ; preds = %585, %574
  %594 = phi i32 [ %580, %574 ], [ %571, %585 ], !dbg !2002
  %595 = phi i32 [ %583, %574 ], [ %590, %585 ], !dbg !2002
  call void @llvm.dbg.value(metadata i32 %595, metadata !740, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %594, metadata !730, metadata !DIExpression()), !dbg !2002
  %596 = icmp sgt i32 %595, 0, !dbg !2114
  br i1 %596, label %597, label %634, !dbg !2116

597:                                              ; preds = %593, %591
  %598 = phi i32 [ %595, %593 ], [ 2, %591 ]
  %599 = phi i32 [ %594, %593 ], [ %571, %591 ]
  call void @llvm.dbg.value(metadata i32 %617, metadata !730, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !729, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2002
  br label %600, !dbg !2117

600:                                              ; preds = %611, %597
  %601 = phi i64 [ 0, %597 ], [ %614, %611 ]
  %602 = phi i32 [ 0, %597 ], [ %613, %611 ]
  call void @llvm.dbg.value(metadata i64 %601, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %602, metadata !729, metadata !DIExpression()), !dbg !2002
  %603 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %601, !dbg !2120
  %604 = load i32, ptr %603, align 4, !dbg !2120, !tbaa !1896
  call void @llvm.dbg.value(metadata i32 %604, metadata !736, metadata !DIExpression()), !dbg !2002
  %605 = icmp eq i32 %602, 0, !dbg !2123
  br i1 %605, label %606, label %608, !dbg !2125

606:                                              ; preds = %600
  %607 = icmp eq i32 %604, 0, !dbg !2126
  br i1 %607, label %611, label %608, !dbg !2129

608:                                              ; preds = %606, %600
  %609 = phi i32 [ 16777216, %606 ], [ 16777215, %600 ]
  %610 = sub nsw i32 %609, %604, !dbg !2130
  store i32 %610, ptr %603, align 4, !dbg !2130, !tbaa !1896
  br label %611, !dbg !2131

611:                                              ; preds = %608, %606
  %612 = phi i1 [ true, %606 ], [ false, %608 ], !dbg !2132
  %613 = phi i32 [ 0, %606 ], [ 1, %608 ], !dbg !2132
  call void @llvm.dbg.value(metadata i32 %613, metadata !729, metadata !DIExpression()), !dbg !2002
  %614 = add nuw nsw i64 %601, 1, !dbg !2131
  call void @llvm.dbg.value(metadata i64 %614, metadata !735, metadata !DIExpression()), !dbg !2002
  %615 = icmp eq i64 %614, %549, !dbg !2133
  br i1 %615, label %616, label %600, !dbg !2117, !llvm.loop !2134

616:                                              ; preds = %611
  %617 = add nsw i32 %599, 1, !dbg !2136
  br i1 %531, label %618, label %627, !dbg !2137

618:                                              ; preds = %616
  switch i32 %150, label %627 [
    i32 25, label %620
    i32 26, label %619
  ], !dbg !2138

619:                                              ; preds = %618
  br label %620, !dbg !2141

620:                                              ; preds = %619, %618
  %621 = phi i32 [ 4194303, %619 ], [ 8388607, %618 ]
  %622 = add nsw i32 %548, -1, !dbg !2143
  %623 = sext i32 %622 to i64, !dbg !2143
  %624 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %623, !dbg !2143
  %625 = load i32, ptr %624, align 4, !dbg !2143, !tbaa !1896
  %626 = and i32 %625, %621, !dbg !2143
  store i32 %626, ptr %624, align 4, !dbg !2143, !tbaa !1896
  br label %627, !dbg !2144

627:                                              ; preds = %620, %618, %616
  %628 = icmp eq i32 %598, 2, !dbg !2144
  br i1 %628, label %629, label %634, !dbg !2146

629:                                              ; preds = %627
  %630 = fsub double 1.000000e+00, %573, !dbg !2147
  call void @llvm.dbg.value(metadata double %630, metadata !741, metadata !DIExpression()), !dbg !2002
  br i1 %612, label %634, label %631, !dbg !2149

631:                                              ; preds = %629
  %632 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %151) #12, !dbg !2150
  %633 = fsub double %630, %632, !dbg !2152
  call void @llvm.dbg.value(metadata double %633, metadata !741, metadata !DIExpression()), !dbg !2002
  br label %634, !dbg !2153

634:                                              ; preds = %631, %629, %627, %593, %591
  %635 = phi i32 [ 2, %631 ], [ 2, %629 ], [ 2, %627 ], [ %595, %593 ], [ 0, %591 ]
  %636 = phi i32 [ %617, %631 ], [ %617, %629 ], [ %617, %627 ], [ %594, %593 ], [ %571, %591 ], !dbg !2002
  %637 = phi double [ %633, %631 ], [ %630, %629 ], [ %573, %627 ], [ %573, %593 ], [ %573, %591 ], !dbg !2002
  call void @llvm.dbg.value(metadata double %637, metadata !741, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %636, metadata !730, metadata !DIExpression()), !dbg !2002
  %638 = fcmp oeq double %637, 0.000000e+00, !dbg !2154
  br i1 %638, label %639, label %784, !dbg !2155

639:                                              ; preds = %634
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %548, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  %640 = icmp ugt i32 %548, 4, !dbg !2156
  br i1 %640, label %641, label %694, !dbg !2159

641:                                              ; preds = %639
  %642 = add nsw i64 %549, -4, !dbg !2159
  %643 = icmp ult i64 %642, 16, !dbg !2159
  br i1 %643, label %680, label %644, !dbg !2159

644:                                              ; preds = %641
  %645 = and i64 %642, -16, !dbg !2159
  %646 = sub nsw i64 %549, %645, !dbg !2159
  br label %647, !dbg !2159

647:                                              ; preds = %647, %644
  %648 = phi i64 [ 0, %644 ], [ %672, %647 ]
  %649 = phi <4 x i32> [ zeroinitializer, %644 ], [ %668, %647 ]
  %650 = phi <4 x i32> [ zeroinitializer, %644 ], [ %669, %647 ]
  %651 = phi <4 x i32> [ zeroinitializer, %644 ], [ %670, %647 ]
  %652 = phi <4 x i32> [ zeroinitializer, %644 ], [ %671, %647 ]
  %653 = xor i64 %648, -1, !dbg !2160
  %654 = add i64 %653, %549, !dbg !2160
  %655 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %654, !dbg !2161
  %656 = getelementptr inbounds i32, ptr %655, i64 -3, !dbg !2161
  %657 = getelementptr inbounds i32, ptr %655, i64 -7, !dbg !2161
  %658 = getelementptr inbounds i32, ptr %655, i64 -11, !dbg !2161
  %659 = getelementptr inbounds i32, ptr %655, i64 -15, !dbg !2161
  %660 = load <4 x i32>, ptr %656, align 4, !dbg !2161, !tbaa !1896
  %661 = shufflevector <4 x i32> %660, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2161
  %662 = load <4 x i32>, ptr %657, align 4, !dbg !2161, !tbaa !1896
  %663 = shufflevector <4 x i32> %662, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2161
  %664 = load <4 x i32>, ptr %658, align 4, !dbg !2161, !tbaa !1896
  %665 = shufflevector <4 x i32> %664, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2161
  %666 = load <4 x i32>, ptr %659, align 4, !dbg !2161, !tbaa !1896
  %667 = shufflevector <4 x i32> %666, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2161
  %668 = or <4 x i32> %661, %649, !dbg !2162
  %669 = or <4 x i32> %663, %650, !dbg !2162
  %670 = or <4 x i32> %665, %651, !dbg !2162
  %671 = or <4 x i32> %667, %652, !dbg !2162
  %672 = add nuw i64 %648, 16
  %673 = icmp eq i64 %672, %645
  br i1 %673, label %674, label %647, !llvm.loop !2163

674:                                              ; preds = %647
  %675 = or <4 x i32> %669, %668, !dbg !2159
  %676 = or <4 x i32> %670, %675, !dbg !2159
  %677 = or <4 x i32> %671, %676, !dbg !2159
  %678 = tail call i32 @llvm.vector.reduce.or.v4i32(<4 x i32> %677), !dbg !2159
  %679 = icmp eq i64 %642, %645, !dbg !2159
  br i1 %679, label %691, label %680, !dbg !2159

680:                                              ; preds = %641, %674
  %681 = phi i64 [ %549, %641 ], [ %646, %674 ]
  %682 = phi i32 [ 0, %641 ], [ %678, %674 ]
  br label %683, !dbg !2159

683:                                              ; preds = %680, %683
  %684 = phi i64 [ %686, %683 ], [ %681, %680 ]
  %685 = phi i32 [ %689, %683 ], [ %682, %680 ]
  call void @llvm.dbg.value(metadata i32 %685, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %684, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  %686 = add nsw i64 %684, -1, !dbg !2160
  call void @llvm.dbg.value(metadata i64 %686, metadata !735, metadata !DIExpression()), !dbg !2002
  %687 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %686, !dbg !2161
  %688 = load i32, ptr %687, align 4, !dbg !2161, !tbaa !1896
  %689 = or i32 %688, %685, !dbg !2162
  call void @llvm.dbg.value(metadata i32 %689, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %686, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2002
  %690 = icmp sgt i64 %684, 5, !dbg !2156
  br i1 %690, label %683, label %691, !dbg !2159, !llvm.loop !2165

691:                                              ; preds = %683, %674
  %692 = phi i32 [ %678, %674 ], [ %689, %683 ], !dbg !2162
  %693 = icmp eq i32 %692, 0, !dbg !2166
  br i1 %693, label %694, label %776, !dbg !2167

694:                                              ; preds = %691, %639
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2002
  %695 = load i32, ptr %536, align 4, !dbg !2168, !tbaa !1896
  %696 = icmp eq i32 %695, 0, !dbg !2171
  br i1 %696, label %697, label %707, !dbg !2172

697:                                              ; preds = %694
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2002
  %698 = load i32, ptr %537, align 4, !dbg !2168, !tbaa !1896
  %699 = icmp eq i32 %698, 0, !dbg !2171
  br i1 %699, label %700, label %707, !dbg !2172

700:                                              ; preds = %697
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2002
  %701 = load i32, ptr %538, align 4, !dbg !2168, !tbaa !1896
  %702 = icmp eq i32 %701, 0, !dbg !2171
  br i1 %702, label %703, label %707, !dbg !2172

703:                                              ; preds = %700
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2002
  %704 = load i32, ptr %3, align 4, !dbg !2168, !tbaa !1896
  %705 = icmp eq i32 %704, 0, !dbg !2171
  %706 = select i1 %705, i32 5, i32 4, !dbg !2172
  br label %707, !dbg !2172

707:                                              ; preds = %703, %700, %697, %694
  %708 = phi i32 [ 1, %694 ], [ 2, %697 ], [ 3, %700 ], [ %706, %703 ], !dbg !2173
  call void @llvm.dbg.value(metadata i32 %548, metadata !735, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2002
  %709 = add nuw nsw i32 %708, %548
  %710 = zext nneg i32 %709 to i64, !dbg !2174
  br label %711, !dbg !2060

711:                                              ; preds = %772, %707
  %712 = phi i64 [ %549, %707 ], [ %713, %772 ]
  %713 = add nuw nsw i64 %712, 1, !dbg !2176
  %714 = getelementptr i32, ptr %539, i64 %713, !dbg !2177
  %715 = load i32, ptr %714, align 4, !dbg !2177, !tbaa !1896
  %716 = sitofp i32 %715 to double, !dbg !2177
  %717 = add i64 %139, %712, !dbg !2179
  %718 = shl i64 %717, 32, !dbg !2180
  %719 = ashr exact i64 %718, 32, !dbg !2180
  %720 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %719, !dbg !2180
  store double %716, ptr %720, align 8, !dbg !2181, !tbaa !1436
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  br i1 %528, label %721, label %772, !dbg !2182

721:                                              ; preds = %711
  br i1 %540, label %758, label %722, !dbg !2182

722:                                              ; preds = %721, %722
  %723 = phi i64 [ %755, %722 ], [ 0, %721 ], !dbg !2184
  %724 = phi double [ %754, %722 ], [ 0.000000e+00, %721 ]
  %725 = getelementptr inbounds double, ptr %7, i64 %723, !dbg !2186
  %726 = getelementptr inbounds double, ptr %725, i64 2, !dbg !2186
  %727 = getelementptr inbounds double, ptr %725, i64 4, !dbg !2186
  %728 = getelementptr inbounds double, ptr %725, i64 6, !dbg !2186
  %729 = load <2 x double>, ptr %725, align 8, !dbg !2186, !tbaa !1436
  %730 = load <2 x double>, ptr %726, align 8, !dbg !2186, !tbaa !1436
  %731 = load <2 x double>, ptr %727, align 8, !dbg !2186, !tbaa !1436
  %732 = load <2 x double>, ptr %728, align 8, !dbg !2186, !tbaa !1436
  %733 = sub nsw i64 %719, %723, !dbg !2187
  %734 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %733, !dbg !2188
  %735 = getelementptr inbounds double, ptr %734, i64 -1, !dbg !2188
  %736 = getelementptr inbounds double, ptr %734, i64 -3, !dbg !2188
  %737 = getelementptr inbounds double, ptr %734, i64 -5, !dbg !2188
  %738 = getelementptr inbounds double, ptr %734, i64 -7, !dbg !2188
  %739 = load <2 x double>, ptr %735, align 8, !dbg !2188, !tbaa !1436
  %740 = shufflevector <2 x double> %739, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2188
  %741 = load <2 x double>, ptr %736, align 8, !dbg !2188, !tbaa !1436
  %742 = shufflevector <2 x double> %741, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2188
  %743 = load <2 x double>, ptr %737, align 8, !dbg !2188, !tbaa !1436
  %744 = shufflevector <2 x double> %743, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2188
  %745 = load <2 x double>, ptr %738, align 8, !dbg !2188, !tbaa !1436
  %746 = shufflevector <2 x double> %745, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2188
  %747 = fmul <2 x double> %729, %740
  %748 = fmul <2 x double> %730, %742
  %749 = fmul <2 x double> %731, %744
  %750 = fmul <2 x double> %732, %746
  %751 = tail call double @llvm.vector.reduce.fadd.v2f64(double %724, <2 x double> %747)
  %752 = tail call double @llvm.vector.reduce.fadd.v2f64(double %751, <2 x double> %748)
  %753 = tail call double @llvm.vector.reduce.fadd.v2f64(double %752, <2 x double> %749)
  %754 = tail call double @llvm.vector.reduce.fadd.v2f64(double %753, <2 x double> %750)
  %755 = add nuw i64 %723, 8, !dbg !2184
  %756 = icmp eq i64 %755, %541, !dbg !2184
  br i1 %756, label %757, label %722, !dbg !2184, !llvm.loop !2189

757:                                              ; preds = %722
  br i1 %542, label %772, label %758, !dbg !2182

758:                                              ; preds = %721, %757
  %759 = phi i64 [ 0, %721 ], [ %541, %757 ]
  %760 = phi double [ 0.000000e+00, %721 ], [ %754, %757 ]
  br label %761, !dbg !2182

761:                                              ; preds = %758, %761
  %762 = phi i64 [ %770, %761 ], [ %759, %758 ]
  %763 = phi double [ %769, %761 ], [ %760, %758 ]
  call void @llvm.dbg.value(metadata double %763, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %762, metadata !736, metadata !DIExpression()), !dbg !2002
  %764 = getelementptr inbounds double, ptr %7, i64 %762, !dbg !2186
  %765 = load double, ptr %764, align 8, !dbg !2186, !tbaa !1436
  %766 = sub nsw i64 %719, %762, !dbg !2187
  %767 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %766, !dbg !2188
  %768 = load double, ptr %767, align 8, !dbg !2188, !tbaa !1436
  %769 = tail call double @llvm.fmuladd.f64(double %765, double %768, double %763), !dbg !2191
  call void @llvm.dbg.value(metadata double %769, metadata !742, metadata !DIExpression()), !dbg !2002
  %770 = add nuw nsw i64 %762, 1, !dbg !2184
  call void @llvm.dbg.value(metadata i64 %770, metadata !736, metadata !DIExpression()), !dbg !2002
  %771 = icmp eq i64 %770, %527, !dbg !2192
  br i1 %771, label %772, label %761, !dbg !2182, !llvm.loop !2193

772:                                              ; preds = %761, %757, %711
  %773 = phi double [ 0.000000e+00, %711 ], [ %754, %757 ], [ %769, %761 ], !dbg !2194
  %774 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %713, !dbg !2195
  store double %773, ptr %774, align 8, !dbg !2196, !tbaa !1436
  call void @llvm.dbg.value(metadata i64 %713, metadata !735, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2002
  %775 = icmp ult i64 %713, %710, !dbg !2174
  br i1 %775, label %711, label %543, !dbg !2060, !llvm.loop !2197

776:                                              ; preds = %691, %776
  %777 = phi i64 [ %780, %776 ], [ %549, %691 ]
  %778 = phi i32 [ %779, %776 ], [ %151, %691 ]
  %779 = add nsw i32 %778, -24, !dbg !2198
  %780 = add nsw i64 %777, -1, !dbg !2198
  call void @llvm.dbg.value(metadata i32 %779, metadata !739, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %780, metadata !724, metadata !DIExpression()), !dbg !2002
  %781 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %780, !dbg !2201
  %782 = load i32, ptr %781, align 4, !dbg !2201, !tbaa !1896
  %783 = icmp eq i32 %782, 0, !dbg !2202
  br i1 %783, label %776, label %801, !dbg !2203, !llvm.loop !2204

784:                                              ; preds = %634
  %785 = sub nsw i32 24, %150, !dbg !2206
  %786 = tail call double @scalbn(double noundef %637, i32 noundef %785) #12, !dbg !2208
  call void @llvm.dbg.value(metadata double %786, metadata !741, metadata !DIExpression()), !dbg !2002
  %787 = fcmp ult double %786, 0x4170000000000000, !dbg !2209
  br i1 %787, label %798, label %788, !dbg !2211

788:                                              ; preds = %784
  %789 = fmul double %786, 0x3E70000000000000, !dbg !2212
  %790 = fptosi double %789 to i32, !dbg !2214
  %791 = sitofp i32 %790 to double, !dbg !2215
  call void @llvm.dbg.value(metadata double %791, metadata !742, metadata !DIExpression()), !dbg !2002
  %792 = tail call double @llvm.fmuladd.f64(double %791, double 0xC170000000000000, double %786), !dbg !2216
  %793 = fptosi double %792 to i32, !dbg !2217
  %794 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %549, !dbg !2218
  store i32 %793, ptr %794, align 4, !dbg !2219, !tbaa !1896
  %795 = add nuw nsw i32 %548, 1, !dbg !2220
  call void @llvm.dbg.value(metadata i32 %795, metadata !724, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %150, metadata !739, metadata !DIExpression()), !dbg !2002
  %796 = zext nneg i32 %795 to i64, !dbg !2221
  %797 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %796, !dbg !2221
  store i32 %790, ptr %797, align 4, !dbg !2222, !tbaa !1896
  br label %803, !dbg !2223

798:                                              ; preds = %784
  %799 = fptosi double %786 to i32, !dbg !2224
  %800 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %549, !dbg !2226
  store i32 %799, ptr %800, align 4, !dbg !2227, !tbaa !1896
  br label %803

801:                                              ; preds = %776
  %802 = trunc i64 %780 to i32, !dbg !2228
  br label %803, !dbg !2228

803:                                              ; preds = %801, %798, %788
  %804 = phi i32 [ %795, %788 ], [ %548, %798 ], [ %802, %801 ], !dbg !2002
  %805 = phi i32 [ %150, %788 ], [ %151, %798 ], [ %779, %801 ], !dbg !2002
  call void @llvm.dbg.value(metadata i32 %805, metadata !739, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %804, metadata !724, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double poison, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 %804, metadata !735, metadata !DIExpression()), !dbg !2002
  %806 = icmp sgt i32 %804, -1, !dbg !2229
  br i1 %806, label %810, label %807, !dbg !2232

807:                                              ; preds = %803
  %808 = icmp eq i32 %635, 0, !dbg !2233
  %809 = select i1 %808, double 0.000000e+00, double -0.000000e+00, !dbg !2235
  store double %809, ptr %1, align 8, !dbg !2236, !tbaa !1436
  call void @llvm.dbg.value(metadata double undef, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 1, metadata !735, metadata !DIExpression()), !dbg !2002
  br label %950, !dbg !2237

810:                                              ; preds = %803
  %811 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %805) #12, !dbg !2228
  call void @llvm.dbg.value(metadata double %811, metadata !742, metadata !DIExpression()), !dbg !2002
  %812 = zext nneg i32 %804 to i64, !dbg !2232
  br label %813, !dbg !2232

813:                                              ; preds = %813, %810
  %814 = phi i64 [ %812, %810 ], [ %822, %813 ]
  %815 = phi double [ %811, %810 ], [ %821, %813 ]
  call void @llvm.dbg.value(metadata double %815, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %814, metadata !735, metadata !DIExpression()), !dbg !2002
  %816 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %814, !dbg !2239
  %817 = load i32, ptr %816, align 4, !dbg !2239, !tbaa !1896
  %818 = sitofp i32 %817 to double, !dbg !2239
  %819 = fmul double %815, %818, !dbg !2241
  %820 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %814, !dbg !2242
  store double %819, ptr %820, align 8, !dbg !2243, !tbaa !1436
  %821 = fmul double %815, 0x3E70000000000000, !dbg !2244
  call void @llvm.dbg.value(metadata double %821, metadata !742, metadata !DIExpression()), !dbg !2002
  %822 = add nsw i64 %814, -1, !dbg !2245
  call void @llvm.dbg.value(metadata i64 %822, metadata !735, metadata !DIExpression()), !dbg !2002
  %823 = icmp eq i64 %814, 0, !dbg !2229
  br i1 %823, label %824, label %813, !dbg !2232, !llvm.loop !2246

824:                                              ; preds = %813, %856
  %825 = phi i64 [ %860, %856 ], [ %812, %813 ]
  %826 = phi i32 [ %861, %856 ], [ 0, %813 ]
  call void @llvm.dbg.value(metadata i64 %825, metadata !735, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 0, metadata !737, metadata !DIExpression()), !dbg !2002
  %827 = tail call i32 @llvm.umin.i32(i32 %826, i32 4)
  %828 = add nuw nsw i32 %827, 1
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 0, metadata !737, metadata !DIExpression()), !dbg !2002
  %829 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %825, !dbg !2248
  %830 = load double, ptr %829, align 8, !dbg !2248, !tbaa !1436
  %831 = tail call double @llvm.fmuladd.f64(double %830, double 0x3FF921FB40000000, double 0.000000e+00), !dbg !2254
  call void @llvm.dbg.value(metadata double %831, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2002
  %832 = icmp eq i32 %826, 0, !dbg !2255
  br i1 %832, label %856, label %833, !dbg !2255, !llvm.loop !2256

833:                                              ; preds = %824
  call void @llvm.dbg.value(metadata double %831, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2002
  %834 = add nuw nsw i64 %825, 1, !dbg !2259
  %835 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %834, !dbg !2248
  %836 = load double, ptr %835, align 8, !dbg !2248, !tbaa !1436
  %837 = tail call double @llvm.fmuladd.f64(double %836, double 0x3E74442D00000000, double %831), !dbg !2254
  call void @llvm.dbg.value(metadata double %837, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2002
  %838 = icmp eq i32 %828, 2, !dbg !2255
  br i1 %838, label %856, label %839, !dbg !2255, !llvm.loop !2256

839:                                              ; preds = %833
  call void @llvm.dbg.value(metadata double %837, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2002
  %840 = add nuw nsw i64 %825, 2, !dbg !2259
  %841 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %840, !dbg !2248
  %842 = load double, ptr %841, align 8, !dbg !2248, !tbaa !1436
  %843 = tail call double @llvm.fmuladd.f64(double %842, double 0x3CF8469880000000, double %837), !dbg !2254
  call void @llvm.dbg.value(metadata double %843, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2002
  %844 = icmp eq i32 %828, 3, !dbg !2255
  br i1 %844, label %856, label %845, !dbg !2255, !llvm.loop !2256

845:                                              ; preds = %839
  call void @llvm.dbg.value(metadata double %843, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2002
  %846 = add nuw nsw i64 %825, 3, !dbg !2259
  %847 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %846, !dbg !2248
  %848 = load double, ptr %847, align 8, !dbg !2248, !tbaa !1436
  %849 = tail call double @llvm.fmuladd.f64(double %848, double 0x3B78CC5160000000, double %843), !dbg !2254
  call void @llvm.dbg.value(metadata double %849, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2002
  %850 = icmp eq i32 %828, 4, !dbg !2255
  br i1 %850, label %856, label %851, !dbg !2255, !llvm.loop !2256

851:                                              ; preds = %845
  call void @llvm.dbg.value(metadata double %849, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2002
  %852 = add nuw nsw i64 %825, 4, !dbg !2259
  %853 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %852, !dbg !2248
  %854 = load double, ptr %853, align 8, !dbg !2248, !tbaa !1436
  %855 = tail call double @llvm.fmuladd.f64(double %854, double 0x39F01B8380000000, double %849), !dbg !2254
  call void @llvm.dbg.value(metadata double %855, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 5, metadata !737, metadata !DIExpression()), !dbg !2002
  br label %856

856:                                              ; preds = %851, %845, %839, %833, %824
  %857 = phi double [ %831, %824 ], [ %837, %833 ], [ %843, %839 ], [ %849, %845 ], [ %855, %851 ], !dbg !2254
  %858 = sub nuw nsw i64 %812, %825
  %859 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %858, !dbg !2260
  store double %857, ptr %859, align 8, !dbg !2261, !tbaa !1436
  %860 = add nsw i64 %825, -1, !dbg !2262
  call void @llvm.dbg.value(metadata i64 %860, metadata !735, metadata !DIExpression()), !dbg !2002
  %861 = add nuw i32 %826, 1, !dbg !2263
  %862 = icmp eq i32 %826, %804, !dbg !2264
  br i1 %862, label %863, label %824, !dbg !2263, !llvm.loop !2265

863:                                              ; preds = %856
  %864 = add nuw nsw i64 %812, 1, !dbg !2267
  %865 = icmp ult i32 %804, 3, !dbg !2267
  br i1 %865, label %892, label %866, !dbg !2267

866:                                              ; preds = %863
  %867 = and i64 %864, 4294967292, !dbg !2267
  %868 = sub nsw i64 %812, %867, !dbg !2267
  br label %869, !dbg !2267

869:                                              ; preds = %869, %866
  %870 = phi i64 [ 0, %866 ], [ %888, %869 ]
  %871 = phi double [ 0.000000e+00, %866 ], [ %887, %869 ]
  %872 = sub i64 %812, %870, !dbg !2267
  %873 = add i64 %872, -1, !dbg !2267
  %874 = add i64 %872, -2, !dbg !2267
  %875 = add i64 %872, -3, !dbg !2267
  %876 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %872, !dbg !2269
  %877 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %873, !dbg !2269
  %878 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %874, !dbg !2269
  %879 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %875, !dbg !2269
  %880 = load double, ptr %876, align 8, !dbg !2269, !tbaa !1436
  %881 = load double, ptr %877, align 8, !dbg !2269, !tbaa !1436
  %882 = load double, ptr %878, align 8, !dbg !2269, !tbaa !1436
  %883 = load double, ptr %879, align 8, !dbg !2269, !tbaa !1436
  %884 = fadd double %871, %880, !dbg !2269
  %885 = fadd double %884, %881, !dbg !2269
  %886 = fadd double %885, %882, !dbg !2269
  %887 = fadd double %886, %883, !dbg !2269
  %888 = add nuw i64 %870, 4
  %889 = icmp eq i64 %888, %867
  br i1 %889, label %890, label %869, !llvm.loop !2271

890:                                              ; preds = %869
  %891 = icmp eq i64 %864, %867, !dbg !2267
  br i1 %891, label %903, label %892, !dbg !2267

892:                                              ; preds = %863, %890
  %893 = phi i64 [ %812, %863 ], [ %868, %890 ]
  %894 = phi double [ 0.000000e+00, %863 ], [ %887, %890 ]
  br label %895, !dbg !2267

895:                                              ; preds = %892, %895
  %896 = phi i64 [ %901, %895 ], [ %893, %892 ]
  %897 = phi double [ %900, %895 ], [ %894, %892 ]
  call void @llvm.dbg.value(metadata double %897, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %896, metadata !735, metadata !DIExpression()), !dbg !2002
  %898 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %896, !dbg !2269
  %899 = load double, ptr %898, align 8, !dbg !2269, !tbaa !1436
  %900 = fadd double %897, %899, !dbg !2273
  call void @llvm.dbg.value(metadata double %900, metadata !742, metadata !DIExpression()), !dbg !2002
  %901 = add nsw i64 %896, -1, !dbg !2274
  call void @llvm.dbg.value(metadata i64 %901, metadata !735, metadata !DIExpression()), !dbg !2002
  %902 = icmp eq i64 %896, 0, !dbg !2275
  br i1 %902, label %903, label %895, !dbg !2267, !llvm.loop !2276

903:                                              ; preds = %895, %890
  %904 = phi double [ %887, %890 ], [ %900, %895 ], !dbg !2273
  %905 = load double, ptr %5, align 8, !dbg !2277, !tbaa !1436
  %906 = icmp eq i32 %635, 0, !dbg !2233
  %907 = fneg double %904, !dbg !2235
  %908 = select i1 %906, double %904, double %907, !dbg !2235
  store double %908, ptr %1, align 8, !dbg !2236, !tbaa !1436
  %909 = fsub double %905, %904, !dbg !2278
  call void @llvm.dbg.value(metadata double %909, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i32 1, metadata !735, metadata !DIExpression()), !dbg !2002
  %910 = icmp eq i32 %804, 0, !dbg !2279
  br i1 %910, label %950, label %911, !dbg !2237

911:                                              ; preds = %903
  %912 = add nuw i32 %804, 1, !dbg !2237
  %913 = zext i32 %912 to i64, !dbg !2279
  %914 = add nsw i64 %913, -1, !dbg !2237
  %915 = icmp ult i32 %804, 8, !dbg !2237
  br i1 %915, label %939, label %916, !dbg !2237

916:                                              ; preds = %911
  %917 = and i64 %914, -8, !dbg !2237
  %918 = or disjoint i64 %917, 1, !dbg !2237
  br label %919, !dbg !2237

919:                                              ; preds = %919, %916
  %920 = phi i64 [ 0, %916 ], [ %935, %919 ]
  %921 = phi double [ %909, %916 ], [ %934, %919 ]
  %922 = or disjoint i64 %920, 1, !dbg !2237
  %923 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %922, !dbg !2281
  %924 = getelementptr inbounds double, ptr %923, i64 2, !dbg !2281
  %925 = getelementptr inbounds double, ptr %923, i64 4, !dbg !2281
  %926 = getelementptr inbounds double, ptr %923, i64 6, !dbg !2281
  %927 = load <2 x double>, ptr %923, align 8, !dbg !2281, !tbaa !1436
  %928 = load <2 x double>, ptr %924, align 8, !dbg !2281, !tbaa !1436
  %929 = load <2 x double>, ptr %925, align 8, !dbg !2281, !tbaa !1436
  %930 = load <2 x double>, ptr %926, align 8, !dbg !2281, !tbaa !1436
  %931 = tail call double @llvm.vector.reduce.fadd.v2f64(double %921, <2 x double> %927), !dbg !2281
  %932 = tail call double @llvm.vector.reduce.fadd.v2f64(double %931, <2 x double> %928), !dbg !2281
  %933 = tail call double @llvm.vector.reduce.fadd.v2f64(double %932, <2 x double> %929), !dbg !2281
  %934 = tail call double @llvm.vector.reduce.fadd.v2f64(double %933, <2 x double> %930), !dbg !2281
  %935 = add nuw i64 %920, 8
  %936 = icmp eq i64 %935, %917
  br i1 %936, label %937, label %919, !llvm.loop !2282

937:                                              ; preds = %919
  %938 = icmp eq i64 %914, %917, !dbg !2237
  br i1 %938, label %950, label %939, !dbg !2237

939:                                              ; preds = %911, %937
  %940 = phi i64 [ 1, %911 ], [ %918, %937 ]
  %941 = phi double [ %909, %911 ], [ %934, %937 ]
  br label %942, !dbg !2237

942:                                              ; preds = %939, %942
  %943 = phi i64 [ %948, %942 ], [ %940, %939 ]
  %944 = phi double [ %947, %942 ], [ %941, %939 ]
  call void @llvm.dbg.value(metadata double %944, metadata !742, metadata !DIExpression()), !dbg !2002
  call void @llvm.dbg.value(metadata i64 %943, metadata !735, metadata !DIExpression()), !dbg !2002
  %945 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %943, !dbg !2281
  %946 = load double, ptr %945, align 8, !dbg !2281, !tbaa !1436
  %947 = fadd double %944, %946, !dbg !2284
  call void @llvm.dbg.value(metadata double %947, metadata !742, metadata !DIExpression()), !dbg !2002
  %948 = add nuw nsw i64 %943, 1, !dbg !2285
  call void @llvm.dbg.value(metadata i64 %948, metadata !735, metadata !DIExpression()), !dbg !2002
  %949 = icmp eq i64 %948, %913, !dbg !2279
  br i1 %949, label %950, label %942, !dbg !2237, !llvm.loop !2286

950:                                              ; preds = %942, %937, %807, %903
  %951 = phi double [ %908, %903 ], [ %809, %807 ], [ %908, %937 ], [ %908, %942 ]
  %952 = phi i1 [ %906, %903 ], [ %808, %807 ], [ %906, %937 ], [ %906, %942 ]
  %953 = phi double [ %909, %903 ], [ undef, %807 ], [ %934, %937 ], [ %947, %942 ], !dbg !2287
  %954 = fneg double %953, !dbg !2288
  %955 = select i1 %952, double %953, double %954, !dbg !2288
  %956 = getelementptr inbounds double, ptr %1, i64 1, !dbg !2289
  store double %955, ptr %956, align 8, !dbg !2290, !tbaa !1436
  %957 = and i32 %636, 7, !dbg !2291
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %6) #11, !dbg !2292
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %5) #11, !dbg !2292
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %4) #11, !dbg !2292
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %3) #11, !dbg !2292
  tail call void @llvm.dbg.value(metadata i32 %957, metadata !659, metadata !DIExpression()), !dbg !1819
  %958 = icmp slt i64 %8, 0, !dbg !2293
  br i1 %958, label %959, label %963, !dbg !2295

959:                                              ; preds = %950
  %960 = fneg double %951, !dbg !2296
  store double %960, ptr %1, align 8, !dbg !2298, !tbaa !1436
  %961 = fneg double %955, !dbg !2299
  store double %961, ptr %956, align 8, !dbg !2300, !tbaa !1436
  %962 = sub nsw i32 0, %957, !dbg !2301
  br label %963, !dbg !2302

963:                                              ; preds = %950, %100, %35, %40, %22, %27, %959, %114, %108, %13
  %964 = phi i32 [ 0, %13 ], [ %111, %108 ], [ 0, %114 ], [ %962, %959 ], [ 1, %27 ], [ 1, %22 ], [ -1, %40 ], [ -1, %35 ], [ %51, %100 ], [ %957, %950 ], !dbg !1819
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %7) #11, !dbg !2303
  ret i32 %964, !dbg !2303
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn memory(readwrite, argmem: none) uwtable(sync)
define double @pts_ieee754_exp(double noundef %0) local_unnamed_addr #4 !dbg !201 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !203, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !205, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !206, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2305
  %2 = bitcast double %0 to i64, !dbg !2307
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2305
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !213, metadata !DIExpression()), !dbg !2308
  %3 = lshr i64 %2, 32, !dbg !2309
  %4 = trunc i64 %3 to i32, !dbg !2309
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !212, metadata !DIExpression()), !dbg !2304
  %5 = lshr i32 %4, 31, !dbg !2310
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !211, metadata !DIExpression()), !dbg !2304
  %6 = and i32 %4, 2147483647, !dbg !2311
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !212, metadata !DIExpression()), !dbg !2304
  %7 = icmp ugt i32 %6, 1082535489, !dbg !2312
  br i1 %7, label %8, label %31, !dbg !2313

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 2146435071, !dbg !2314
  br i1 %9, label %10, label %19, !dbg !2315

10:                                               ; preds = %8
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2316
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2316
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !220, metadata !DIExpression()), !dbg !2318
  %11 = trunc i64 %2 to i32, !dbg !2319
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !215, metadata !DIExpression()), !dbg !2320
  %12 = and i32 %4, 1048575, !dbg !2321
  %13 = or i32 %12, %11, !dbg !2323
  %14 = icmp eq i32 %13, 0, !dbg !2324
  %15 = fadd double %0, %0, !dbg !2325
  %16 = icmp sgt i64 %2, -1, !dbg !2325
  %17 = select i1 %16, double %0, double 0.000000e+00, !dbg !2325
  %18 = select i1 %14, double %17, double %15, !dbg !2325
  br label %116

19:                                               ; preds = %8
  %20 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2326
  br i1 %20, label %21, label %25, !dbg !2328

21:                                               ; preds = %19
  %22 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2329, !tbaa !1436
  %23 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2330, !tbaa !1436
  %24 = fmul double %22, %23, !dbg !2331
  br label %116, !dbg !2332

25:                                               ; preds = %19
  %26 = fcmp olt double %0, 0xC0874910D52D3051, !dbg !2333
  br i1 %26, label %27, label %58, !dbg !2335

27:                                               ; preds = %25
  %28 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2336, !tbaa !1436
  %29 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2337, !tbaa !1436
  %30 = fmul double %28, %29, !dbg !2338
  br label %116, !dbg !2339

31:                                               ; preds = %1
  %32 = icmp ugt i32 %6, 1071001154, !dbg !2340
  br i1 %32, label %33, label %48, !dbg !2342

33:                                               ; preds = %31
  %34 = icmp ult i32 %6, 1072734898, !dbg !2343
  br i1 %34, label %35, label %58, !dbg !2346

35:                                               ; preds = %33
  %36 = fcmp oeq double %0, 1.000000e+00, !dbg !2347
  br i1 %36, label %116, label %37, !dbg !2350

37:                                               ; preds = %35
  %38 = zext nneg i32 %5 to i64
  %39 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2HI, i64 0, i64 %38, !dbg !2351
  %40 = load double, ptr %39, align 8, !dbg !2351, !tbaa !1436
  %41 = fsub double %0, %40, !dbg !2352
  tail call void @llvm.dbg.value(metadata double %41, metadata !205, metadata !DIExpression()), !dbg !2304
  %42 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2LO, i64 0, i64 %38, !dbg !2353
  %43 = load double, ptr %42, align 8, !dbg !2353, !tbaa !1436
  tail call void @llvm.dbg.value(metadata double %43, metadata !206, metadata !DIExpression()), !dbg !2304
  %44 = xor i32 %5, 1, !dbg !2354
  %45 = sub nsw i32 %44, %5, !dbg !2355
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !210, metadata !DIExpression()), !dbg !2304
  %46 = fsub double %41, %43, !dbg !2356
  tail call void @llvm.dbg.value(metadata double %46, metadata !203, metadata !DIExpression()), !dbg !2304
  %47 = fmul double %46, %46, !dbg !2357
  tail call void @llvm.dbg.value(metadata double %47, metadata !208, metadata !DIExpression()), !dbg !2304
  br label %72, !dbg !2358

48:                                               ; preds = %31
  %49 = icmp ult i32 %6, 1043333120, !dbg !2359
  br i1 %49, label %50, label %56, !dbg !2361

50:                                               ; preds = %48
  %51 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2362, !tbaa !1436
  %52 = fadd double %51, %0, !dbg !2365
  %53 = fcmp ogt double %52, 1.000000e+00, !dbg !2366
  br i1 %53, label %54, label %56, !dbg !2367

54:                                               ; preds = %50
  %55 = fadd double %0, 1.000000e+00, !dbg !2368
  br label %116, !dbg !2369

56:                                               ; preds = %50, %48
  tail call void @llvm.dbg.value(metadata double %0, metadata !203, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !205, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !206, metadata !DIExpression()), !dbg !2304
  tail call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !2304
  %57 = fmul double %0, %0, !dbg !2357
  tail call void @llvm.dbg.value(metadata double %57, metadata !208, metadata !DIExpression()), !dbg !2304
  br label %72, !dbg !2358

58:                                               ; preds = %25, %33
  %59 = zext nneg i32 %5 to i64
  %60 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.halF, i64 0, i64 %59, !dbg !2370
  %61 = load double, ptr %60, align 8, !dbg !2370, !tbaa !1436
  %62 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %61), !dbg !2372
  %63 = fptosi double %62 to i32, !dbg !2373
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !210, metadata !DIExpression()), !dbg !2304
  %64 = sitofp i32 %63 to double, !dbg !2374
  tail call void @llvm.dbg.value(metadata double %64, metadata !208, metadata !DIExpression()), !dbg !2304
  %65 = fneg double %64, !dbg !2375
  %66 = tail call double @llvm.fmuladd.f64(double %65, double 0x3FE62E42FEE00000, double %0), !dbg !2375
  tail call void @llvm.dbg.value(metadata double %66, metadata !205, metadata !DIExpression()), !dbg !2304
  %67 = fmul double %64, 0x3DEA39EF35793C76, !dbg !2376
  tail call void @llvm.dbg.value(metadata double %67, metadata !206, metadata !DIExpression()), !dbg !2304
  %68 = fsub double %66, %67, !dbg !2356
  tail call void @llvm.dbg.value(metadata double %68, metadata !203, metadata !DIExpression()), !dbg !2304
  %69 = fmul double %68, %68, !dbg !2357
  tail call void @llvm.dbg.value(metadata double %69, metadata !208, metadata !DIExpression()), !dbg !2304
  %70 = icmp sgt i32 %63, -1022, !dbg !2377
  %71 = select i1 %70, i32 1072693248, i32 2121269248, !dbg !2358
  br label %72, !dbg !2358

72:                                               ; preds = %58, %56, %37
  %73 = phi i32 [ 0, %56 ], [ %45, %37 ], [ %63, %58 ]
  %74 = phi i32 [ 1072693248, %56 ], [ 1072693248, %37 ], [ %71, %58 ]
  %75 = phi i1 [ true, %56 ], [ true, %37 ], [ %70, %58 ]
  %76 = phi double [ %57, %56 ], [ %47, %37 ], [ %69, %58 ]
  %77 = phi double [ %0, %56 ], [ %46, %37 ], [ %68, %58 ]
  %78 = phi double [ 0.000000e+00, %56 ], [ %41, %37 ], [ %66, %58 ]
  %79 = phi double [ 0.000000e+00, %56 ], [ %43, %37 ], [ %67, %58 ]
  %80 = shl i32 %73, 20, !dbg !2378
  %81 = add i32 %80, %74, !dbg !2378
  %82 = zext i32 %81 to i64, !dbg !2378
  %83 = shl nuw i64 %82, 32, !dbg !2378
  %84 = bitcast i64 %83 to double, !dbg !2378
  tail call void @llvm.dbg.value(metadata double %84, metadata !209, metadata !DIExpression()), !dbg !2304
  %85 = tail call double @llvm.fmuladd.f64(double %76, double 0x3E66376972BEA4D0, double 0xBEBBBD41C5D26BF1), !dbg !2379
  %86 = tail call double @llvm.fmuladd.f64(double %76, double %85, double 0x3F11566AAF25DE2C), !dbg !2380
  %87 = tail call double @llvm.fmuladd.f64(double %76, double %86, double 0xBF66C16C16BEBD93), !dbg !2381
  %88 = tail call double @llvm.fmuladd.f64(double %76, double %87, double 0x3FC555555555553E), !dbg !2382
  %89 = fneg double %76, !dbg !2383
  %90 = tail call double @llvm.fmuladd.f64(double %89, double %88, double %77), !dbg !2383
  tail call void @llvm.dbg.value(metadata double %90, metadata !207, metadata !DIExpression()), !dbg !2304
  %91 = icmp eq i32 %73, 0, !dbg !2384
  %92 = fmul double %77, %90, !dbg !2386
  br i1 %91, label %93, label %98, !dbg !2387

93:                                               ; preds = %72
  %94 = fadd double %90, -2.000000e+00, !dbg !2388
  %95 = fdiv double %92, %94, !dbg !2390
  %96 = fsub double %77, %95, !dbg !2391
  %97 = fadd double %96, 1.000000e+00, !dbg !2391
  br label %116, !dbg !2392

98:                                               ; preds = %72
  %99 = fsub double 2.000000e+00, %90, !dbg !2393
  %100 = fdiv double %92, %99, !dbg !2395
  %101 = fsub double %79, %100, !dbg !2396
  %102 = fsub double %78, %101, !dbg !2397
  %103 = fadd double %102, 1.000000e+00, !dbg !2397
  tail call void @llvm.dbg.value(metadata double %103, metadata !204, metadata !DIExpression()), !dbg !2304
  br i1 %75, label %104, label %112, !dbg !2398

104:                                              ; preds = %98
  %105 = icmp eq i32 %73, 1024, !dbg !2399
  br i1 %105, label %106, label %110, !dbg !2403

106:                                              ; preds = %104
  %107 = fmul double %103, 2.000000e+00, !dbg !2404
  %108 = load volatile double, ptr @pts_ieee754_exp.two1023, align 8, !dbg !2405, !tbaa !1436
  %109 = fmul double %107, %108, !dbg !2406
  br label %116, !dbg !2407

110:                                              ; preds = %104
  %111 = fmul double %103, %84, !dbg !2408
  br label %116, !dbg !2409

112:                                              ; preds = %98
  %113 = fmul double %103, %84, !dbg !2410
  %114 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2412, !tbaa !1436
  %115 = fmul double %113, %114, !dbg !2413
  br label %116, !dbg !2414

116:                                              ; preds = %35, %112, %110, %106, %93, %54, %27, %21, %10
  %117 = phi double [ %18, %10 ], [ %24, %21 ], [ %30, %27 ], [ %97, %93 ], [ %109, %106 ], [ %111, %110 ], [ %115, %112 ], [ %55, %54 ], [ 0x4005BF0A8B145769, %35 ], !dbg !2304
  ret double %117, !dbg !2415
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_atanh(double noundef %0) local_unnamed_addr #0 !dbg !264 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !266, metadata !DIExpression()), !dbg !2416
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2417
  %2 = bitcast double %0 to i64, !dbg !2419
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2417
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !271, metadata !DIExpression()), !dbg !2420
  %3 = lshr i64 %2, 32, !dbg !2421
  %4 = trunc i64 %3 to i32, !dbg !2421
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !268, metadata !DIExpression()), !dbg !2416
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !270, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2416
  %5 = and i32 %4, 2147483647, !dbg !2422
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !269, metadata !DIExpression()), !dbg !2416
  %6 = and i64 %2, 4294967295, !dbg !2423
  %7 = icmp ne i64 %6, 0, !dbg !2423
  %8 = zext i1 %7 to i32, !dbg !2423
  %9 = or i32 %5, %8, !dbg !2425
  %10 = icmp ugt i32 %9, 1072693248, !dbg !2426
  br i1 %10, label %40, label %11, !dbg !2427

11:                                               ; preds = %1
  %12 = icmp eq i32 %5, 1072693248, !dbg !2428
  br i1 %12, label %13, label %16, !dbg !2430

13:                                               ; preds = %11
  %14 = fcmp ogt double %0, 0.000000e+00, !dbg !2431
  %15 = select i1 %14, double 0x7FF0000000000000, double 0xFFF0000000000000, !dbg !2433
  br label %40, !dbg !2434

16:                                               ; preds = %11
  %17 = icmp ult i32 %5, 1043333120, !dbg !2435
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 0.000000e+00
  %20 = and i1 %19, %17, !dbg !2437
  br i1 %20, label %40, label %21, !dbg !2437

21:                                               ; preds = %16
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2438
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2438
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !273, metadata !DIExpression()), !dbg !2440
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !273, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2440
  %22 = tail call double @llvm.fabs.f64(double %0), !dbg !2441
  tail call void @llvm.dbg.value(metadata double %22, metadata !273, metadata !DIExpression()), !dbg !2440
  tail call void @llvm.dbg.value(metadata double %22, metadata !266, metadata !DIExpression()), !dbg !2416
  %23 = icmp ult i32 %5, 1071644672, !dbg !2442
  %24 = fadd double %22, %22, !dbg !2444
  br i1 %23, label %25, label %30, !dbg !2445

25:                                               ; preds = %21
  tail call void @llvm.dbg.value(metadata double %24, metadata !267, metadata !DIExpression()), !dbg !2416
  %26 = fmul double %22, %24, !dbg !2446
  %27 = fsub double 1.000000e+00, %22, !dbg !2448
  %28 = fdiv double %26, %27, !dbg !2449
  %29 = fadd double %24, %28, !dbg !2450
  tail call void @llvm.dbg.value(metadata double poison, metadata !267, metadata !DIExpression()), !dbg !2416
  br label %33, !dbg !2451

30:                                               ; preds = %21
  %31 = fsub double 1.000000e+00, %22, !dbg !2452
  %32 = fdiv double %24, %31, !dbg !2454
  tail call void @llvm.dbg.value(metadata double poison, metadata !267, metadata !DIExpression()), !dbg !2416
  br label %33

33:                                               ; preds = %30, %25
  %34 = phi double [ %32, %30 ], [ %29, %25 ]
  %35 = tail call double @pts_ieee754_log1p(double noundef %34), !dbg !2444
  %36 = fmul double %35, 5.000000e-01, !dbg !2444
  tail call void @llvm.dbg.value(metadata double %36, metadata !267, metadata !DIExpression()), !dbg !2416
  %37 = fneg double %36
  %38 = icmp slt i64 %2, 0, !dbg !2455
  %39 = select i1 %38, double %37, double %36, !dbg !2455
  br label %40, !dbg !2455

40:                                               ; preds = %33, %16, %1, %13
  %41 = phi double [ %15, %13 ], [ 0x7FF8000000000000, %1 ], [ %0, %16 ], [ %39, %33 ], !dbg !2416
  ret double %41, !dbg !2456
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_log2(double noundef %0) local_unnamed_addr #0 !dbg !382 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !384, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2458
  %2 = bitcast double %0 to i64, !dbg !2460
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2458
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !398, metadata !DIExpression()), !dbg !2461
  %3 = lshr i64 %2, 32, !dbg !2462
  %4 = trunc i64 %3 to i32, !dbg !2462
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !396, metadata !DIExpression()), !dbg !2457
  %5 = trunc i64 %2 to i32, !dbg !2462
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !397, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata i32 0, metadata !395, metadata !DIExpression()), !dbg !2457
  %6 = icmp slt i32 %4, 1048576, !dbg !2463
  br i1 %6, label %7, label %18, !dbg !2464

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2465
  %9 = or i32 %8, %5, !dbg !2467
  %10 = icmp eq i32 %9, 0, !dbg !2468
  br i1 %10, label %80, label %11, !dbg !2469

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2470
  br i1 %12, label %80, label %13, !dbg !2472

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !395, metadata !DIExpression()), !dbg !2457
  %14 = fmul double %0, 0x4350000000000000, !dbg !2473
  tail call void @llvm.dbg.value(metadata double %14, metadata !384, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata double %14, metadata !872, metadata !DIExpression()), !dbg !2474
  %15 = bitcast double %14 to i64, !dbg !2476
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !877, metadata !DIExpression()), !dbg !2474
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !400, metadata !DIExpression()), !dbg !2477
  %16 = lshr i64 %15, 32, !dbg !2478
  %17 = trunc i64 %16 to i32, !dbg !2478
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !396, metadata !DIExpression()), !dbg !2457
  br label %18, !dbg !2479

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2457
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2457
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !384, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !395, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !396, metadata !DIExpression()), !dbg !2457
  %22 = icmp sgt i32 %19, 2146435071, !dbg !2480
  br i1 %22, label %23, label %25, !dbg !2482

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !2483
  br label %80, !dbg !2484

25:                                               ; preds = %18
  %26 = icmp eq i32 %19, 1072693248, !dbg !2485
  %27 = icmp eq i32 %5, 0
  %28 = and i1 %27, %26, !dbg !2487
  br i1 %28, label %80, label %29, !dbg !2487

29:                                               ; preds = %25
  %30 = ashr i32 %19, 20, !dbg !2488
  %31 = add nsw i32 %30, -1023, !dbg !2489
  %32 = add nsw i32 %31, %20, !dbg !2490
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !395, metadata !DIExpression()), !dbg !2457
  %33 = and i32 %19, 1048575, !dbg !2491
  tail call void @llvm.dbg.value(metadata i32 %33, metadata !396, metadata !DIExpression()), !dbg !2457
  %34 = add nuw nsw i32 %33, 614244, !dbg !2492
  %35 = and i32 %34, 1048576, !dbg !2493
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !394, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !2457
  tail call void @llvm.dbg.value(metadata double %21, metadata !872, metadata !DIExpression()), !dbg !2494
  %36 = bitcast double %21 to i64, !dbg !2496
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !877, metadata !DIExpression()), !dbg !2494
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !404, metadata !DIExpression()), !dbg !2497
  %37 = and i64 %36, 4294967295, !dbg !2498
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !404, metadata !DIExpression()), !dbg !2497
  %38 = or disjoint i32 %35, %33, !dbg !2498
  %39 = xor i32 %38, 1072693248, !dbg !2498
  %40 = zext nneg i32 %39 to i64
  %41 = shl nuw nsw i64 %40, 32, !dbg !2498
  %42 = or disjoint i64 %41, %37, !dbg !2498
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !404, metadata !DIExpression()), !dbg !2497
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !946, metadata !DIExpression()), !dbg !2499
  %43 = bitcast i64 %42 to double, !dbg !2501
  tail call void @llvm.dbg.value(metadata double %43, metadata !951, metadata !DIExpression()), !dbg !2499
  tail call void @llvm.dbg.value(metadata double %43, metadata !384, metadata !DIExpression()), !dbg !2457
  %44 = lshr i32 %34, 20
  %45 = add nsw i32 %32, %44, !dbg !2502
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !395, metadata !DIExpression()), !dbg !2457
  %46 = sitofp i32 %45 to double, !dbg !2503
  tail call void @llvm.dbg.value(metadata double %46, metadata !393, metadata !DIExpression()), !dbg !2457
  %47 = fadd double %43, -1.000000e+00, !dbg !2504
  tail call void @llvm.dbg.value(metadata double %47, metadata !385, metadata !DIExpression()), !dbg !2457
  %48 = fmul double %47, 5.000000e-01, !dbg !2505
  %49 = fmul double %47, %48, !dbg !2506
  tail call void @llvm.dbg.value(metadata double %49, metadata !386, metadata !DIExpression()), !dbg !2457
  call void @llvm.dbg.value(metadata double %47, metadata !2507, metadata !DIExpression()), !dbg !2517
  %50 = fadd double %47, 2.000000e+00, !dbg !2519
  %51 = fdiv double %47, %50, !dbg !2520
  call void @llvm.dbg.value(metadata double %51, metadata !2511, metadata !DIExpression()), !dbg !2517
  %52 = fmul double %51, %51, !dbg !2521
  call void @llvm.dbg.value(metadata double %52, metadata !2512, metadata !DIExpression()), !dbg !2517
  %53 = fmul double %52, %52, !dbg !2522
  call void @llvm.dbg.value(metadata double %53, metadata !2514, metadata !DIExpression()), !dbg !2517
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !2523
  %55 = tail call double @llvm.fmuladd.f64(double %53, double %54, double 0x3FD999999997FA04), !dbg !2524
  %56 = fmul double %53, %55, !dbg !2525
  call void @llvm.dbg.value(metadata double %56, metadata !2515, metadata !DIExpression()), !dbg !2517
  %57 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !2526
  %58 = tail call double @llvm.fmuladd.f64(double %53, double %57, double 0x3FD2492494229359), !dbg !2527
  %59 = tail call double @llvm.fmuladd.f64(double %53, double %58, double 0x3FE5555555555593), !dbg !2528
  %60 = fmul double %52, %59, !dbg !2529
  call void @llvm.dbg.value(metadata double %60, metadata !2516, metadata !DIExpression()), !dbg !2517
  %61 = fadd double %56, %60, !dbg !2530
  call void @llvm.dbg.value(metadata double %61, metadata !2513, metadata !DIExpression()), !dbg !2517
  call void @llvm.dbg.value(metadata double %49, metadata !2510, metadata !DIExpression()), !dbg !2517
  %62 = fadd double %49, %61, !dbg !2531
  %63 = fmul double %51, %62, !dbg !2532
  tail call void @llvm.dbg.value(metadata double %63, metadata !389, metadata !DIExpression()), !dbg !2457
  %64 = fsub double %47, %49, !dbg !2533
  tail call void @llvm.dbg.value(metadata double %64, metadata !387, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata double %64, metadata !872, metadata !DIExpression()), !dbg !2534
  %65 = bitcast double %64 to i64, !dbg !2536
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !877, metadata !DIExpression()), !dbg !2534
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !406, metadata !DIExpression()), !dbg !2537
  %66 = and i64 %65, -4294967296, !dbg !2538
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !406, metadata !DIExpression()), !dbg !2537
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !406, metadata !DIExpression()), !dbg !2537
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !946, metadata !DIExpression()), !dbg !2539
  %67 = bitcast i64 %66 to double, !dbg !2541
  tail call void @llvm.dbg.value(metadata double %67, metadata !951, metadata !DIExpression()), !dbg !2539
  tail call void @llvm.dbg.value(metadata double %67, metadata !387, metadata !DIExpression()), !dbg !2457
  %68 = fsub double %47, %67, !dbg !2542
  %69 = fsub double %68, %49, !dbg !2543
  %70 = fadd double %69, %63, !dbg !2544
  tail call void @llvm.dbg.value(metadata double %70, metadata !388, metadata !DIExpression()), !dbg !2457
  %71 = fmul double %67, 0x3FF7154765200000, !dbg !2545
  tail call void @llvm.dbg.value(metadata double %71, metadata !390, metadata !DIExpression()), !dbg !2457
  %72 = fadd double %70, %67, !dbg !2546
  %73 = fmul double %70, 0x3FF7154765200000, !dbg !2547
  %74 = tail call double @llvm.fmuladd.f64(double %72, double 0x3DE705FC2EEFA200, double %73), !dbg !2548
  tail call void @llvm.dbg.value(metadata double %74, metadata !391, metadata !DIExpression()), !dbg !2457
  %75 = fadd double %71, %46, !dbg !2549
  tail call void @llvm.dbg.value(metadata double %75, metadata !392, metadata !DIExpression()), !dbg !2457
  %76 = fsub double %46, %75, !dbg !2550
  %77 = fadd double %71, %76, !dbg !2551
  %78 = fadd double %77, %74, !dbg !2552
  tail call void @llvm.dbg.value(metadata double %78, metadata !391, metadata !DIExpression()), !dbg !2457
  tail call void @llvm.dbg.value(metadata double %75, metadata !390, metadata !DIExpression()), !dbg !2457
  %79 = fadd double %75, %78, !dbg !2553
  br label %80, !dbg !2554

80:                                               ; preds = %25, %11, %7, %29, %23
  %81 = phi double [ %24, %23 ], [ %79, %29 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %25 ], !dbg !2457
  ret double %81, !dbg !2555
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_log10(double noundef %0) local_unnamed_addr #0 !dbg !414 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !416, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2557
  %2 = bitcast double %0 to i64, !dbg !2559
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2557
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !422, metadata !DIExpression()), !dbg !2560
  %3 = lshr i64 %2, 32, !dbg !2561
  %4 = trunc i64 %3 to i32, !dbg !2561
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !420, metadata !DIExpression()), !dbg !2556
  %5 = trunc i64 %2 to i32, !dbg !2561
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !421, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata i32 0, metadata !419, metadata !DIExpression()), !dbg !2556
  %6 = icmp slt i32 %4, 1048576, !dbg !2562
  br i1 %6, label %7, label %19, !dbg !2563

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2564
  %9 = or i32 %8, %5, !dbg !2566
  %10 = icmp eq i32 %9, 0, !dbg !2567
  br i1 %10, label %51, label %11, !dbg !2568

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2569
  br i1 %12, label %51, label %13, !dbg !2571

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !419, metadata !DIExpression()), !dbg !2556
  %14 = fmul double %0, 0x4350000000000000, !dbg !2572
  tail call void @llvm.dbg.value(metadata double %14, metadata !416, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata double %14, metadata !872, metadata !DIExpression()), !dbg !2573
  %15 = bitcast double %14 to i64, !dbg !2575
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !877, metadata !DIExpression()), !dbg !2573
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !424, metadata !DIExpression()), !dbg !2576
  %16 = lshr i64 %15, 32, !dbg !2577
  %17 = trunc i64 %16 to i32, !dbg !2577
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !420, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata double %14, metadata !872, metadata !DIExpression()), !dbg !2578
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !877, metadata !DIExpression()), !dbg !2578
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !428, metadata !DIExpression()), !dbg !2580
  %18 = trunc i64 %15 to i32, !dbg !2581
  tail call void @llvm.dbg.value(metadata i32 %18, metadata !421, metadata !DIExpression()), !dbg !2556
  br label %19, !dbg !2582

19:                                               ; preds = %13, %1
  %20 = phi i32 [ %18, %13 ], [ %5, %1 ], !dbg !2556
  %21 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2556
  %22 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2556
  %23 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %23, metadata !416, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata i32 %22, metadata !419, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !420, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !421, metadata !DIExpression()), !dbg !2556
  %24 = icmp sgt i32 %21, 2146435071, !dbg !2583
  br i1 %24, label %25, label %27, !dbg !2585

25:                                               ; preds = %19
  %26 = fadd double %23, %23, !dbg !2586
  br label %51, !dbg !2587

27:                                               ; preds = %19
  %28 = icmp eq i32 %21, 1072693248, !dbg !2588
  %29 = icmp eq i32 %20, 0
  %30 = and i1 %29, %28, !dbg !2590
  br i1 %30, label %51, label %31, !dbg !2590

31:                                               ; preds = %27
  %32 = ashr i32 %21, 20, !dbg !2591
  %33 = add nsw i32 %32, -1023, !dbg !2592
  %34 = add nsw i32 %33, %22, !dbg !2593
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !419, metadata !DIExpression()), !dbg !2556
  %35 = lshr i32 %34, 31, !dbg !2594
  tail call void @llvm.dbg.value(metadata i32 %35, metadata !418, metadata !DIExpression()), !dbg !2556
  %36 = and i32 %21, 1048575, !dbg !2595
  %37 = shl nuw nsw i32 %35, 20, !dbg !2596
  %38 = or disjoint i32 %37, %36, !dbg !2597
  %39 = xor i32 %38, 1072693248, !dbg !2597
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !420, metadata !DIExpression()), !dbg !2556
  %40 = add nsw i32 %35, %34, !dbg !2598
  %41 = sitofp i32 %40 to double, !dbg !2599
  tail call void @llvm.dbg.value(metadata double %41, metadata !417, metadata !DIExpression()), !dbg !2556
  tail call void @llvm.dbg.value(metadata double %23, metadata !872, metadata !DIExpression()), !dbg !2600
  tail call void @llvm.dbg.value(metadata double %23, metadata !877, metadata !DIExpression()), !dbg !2600
  tail call void @llvm.dbg.value(metadata double %23, metadata !430, metadata !DIExpression()), !dbg !2602
  tail call void @llvm.dbg.value(metadata double %23, metadata !430, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2602
  %42 = zext nneg i32 %39 to i64
  %43 = shl nuw nsw i64 %42, 32, !dbg !2603
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !430, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2602
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !946, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2604
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !951, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2604
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !416, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2556
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !872, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2606
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !877, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2606
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !432, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2608
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !432, metadata !DIExpression()), !dbg !2608
  %44 = zext i32 %20 to i64, !dbg !2609
  %45 = or disjoint i64 %43, %44, !dbg !2609
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !432, metadata !DIExpression()), !dbg !2608
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !946, metadata !DIExpression()), !dbg !2610
  %46 = bitcast i64 %45 to double, !dbg !2612
  tail call void @llvm.dbg.value(metadata double %46, metadata !951, metadata !DIExpression()), !dbg !2610
  tail call void @llvm.dbg.value(metadata double %46, metadata !416, metadata !DIExpression()), !dbg !2556
  %47 = tail call double @pts_ieee754_log(double noundef %46), !dbg !2613
  %48 = fmul double %47, 0x3FDBCB7B1526E50E, !dbg !2614
  %49 = tail call double @llvm.fmuladd.f64(double %41, double 0x3D59FEF311F12B36, double %48), !dbg !2615
  tail call void @llvm.dbg.value(metadata double %49, metadata !434, metadata !DIExpression()), !dbg !2556
  %50 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FD34413509F6000, double %49), !dbg !2616
  br label %51

51:                                               ; preds = %27, %11, %7, %31, %25
  %52 = phi double [ %26, %25 ], [ %50, %31 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %27 ], !dbg !2556
  ret double %52, !dbg !2617
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn memory(readwrite, argmem: none) uwtable(sync)
define double @pts_ieee754_expm1(double noundef %0) local_unnamed_addr #4 !dbg !443 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !445, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2619
  %2 = bitcast double %0 to i64, !dbg !2621
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2619
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !459, metadata !DIExpression()), !dbg !2622
  %3 = lshr i64 %2, 32, !dbg !2623
  %4 = trunc i64 %3 to i32, !dbg !2623
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !458, metadata !DIExpression()), !dbg !2618
  %5 = and i32 %4, -2147483648, !dbg !2624
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !457, metadata !DIExpression()), !dbg !2618
  %6 = and i32 %4, 2147483647, !dbg !2625
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !458, metadata !DIExpression()), !dbg !2618
  %7 = icmp ugt i32 %6, 1078159481, !dbg !2626
  br i1 %7, label %8, label %32, !dbg !2627

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 1082535489, !dbg !2628
  br i1 %9, label %10, label %27, !dbg !2629

10:                                               ; preds = %8
  %11 = icmp ugt i32 %6, 2146435071, !dbg !2630
  br i1 %11, label %12, label %21, !dbg !2631

12:                                               ; preds = %10
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2632
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2632
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !468, metadata !DIExpression()), !dbg !2634
  %13 = trunc i64 %2 to i32, !dbg !2635
  tail call void @llvm.dbg.value(metadata i32 %13, metadata !461, metadata !DIExpression()), !dbg !2636
  %14 = and i32 %4, 1048575, !dbg !2637
  %15 = or i32 %14, %13, !dbg !2639
  %16 = icmp eq i32 %15, 0, !dbg !2640
  %17 = fadd double %0, %0, !dbg !2641
  %18 = icmp eq i32 %5, 0, !dbg !2641
  %19 = select i1 %18, double %0, double -1.000000e+00, !dbg !2641
  %20 = select i1 %16, double %19, double %17, !dbg !2641
  br label %145

21:                                               ; preds = %10
  %22 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2642
  br i1 %22, label %23, label %27, !dbg !2644

23:                                               ; preds = %21
  %24 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2645, !tbaa !1436
  %25 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2646, !tbaa !1436
  %26 = fmul double %24, %25, !dbg !2647
  br label %145, !dbg !2648

27:                                               ; preds = %21, %8
  %28 = icmp ne i32 %5, 0, !dbg !2649
  %29 = fadd double %0, 1.000000e-300
  %30 = fcmp olt double %29, 0.000000e+00
  %31 = and i1 %30, %28, !dbg !2651
  br i1 %31, label %145, label %42, !dbg !2651

32:                                               ; preds = %1
  %33 = icmp ugt i32 %6, 1071001154, !dbg !2652
  br i1 %33, label %34, label %58, !dbg !2654

34:                                               ; preds = %32
  %35 = icmp ult i32 %6, 1072734898, !dbg !2655
  br i1 %35, label %36, label %42, !dbg !2658

36:                                               ; preds = %34
  %37 = icmp eq i32 %5, 0, !dbg !2659
  br i1 %37, label %38, label %40, !dbg !2662

38:                                               ; preds = %36
  %39 = fadd double %0, 0xBFE62E42FEE00000, !dbg !2663
  tail call void @llvm.dbg.value(metadata double %39, metadata !447, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double 0x3DEA39EF35793C76, metadata !448, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata i32 1, metadata !456, metadata !DIExpression()), !dbg !2618
  br label %51, !dbg !2665

40:                                               ; preds = %36
  %41 = fadd double %0, 0x3FE62E42FEE00000, !dbg !2666
  tail call void @llvm.dbg.value(metadata double %41, metadata !447, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double 0xBDEA39EF35793C76, metadata !448, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !456, metadata !DIExpression()), !dbg !2618
  br label %51

42:                                               ; preds = %27, %34
  %43 = icmp eq i32 %5, 0, !dbg !2668
  %44 = select i1 %43, double 5.000000e-01, double -5.000000e-01, !dbg !2670
  %45 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %44), !dbg !2671
  %46 = fptosi double %45 to i32, !dbg !2672
  tail call void @llvm.dbg.value(metadata i32 %46, metadata !456, metadata !DIExpression()), !dbg !2618
  %47 = sitofp i32 %46 to double, !dbg !2673
  tail call void @llvm.dbg.value(metadata double %47, metadata !450, metadata !DIExpression()), !dbg !2618
  %48 = fneg double %47, !dbg !2674
  %49 = tail call double @llvm.fmuladd.f64(double %48, double 0x3FE62E42FEE00000, double %0), !dbg !2674
  tail call void @llvm.dbg.value(metadata double %49, metadata !447, metadata !DIExpression()), !dbg !2618
  %50 = fmul double %47, 0x3DEA39EF35793C76, !dbg !2675
  tail call void @llvm.dbg.value(metadata double %50, metadata !448, metadata !DIExpression()), !dbg !2618
  br label %51

51:                                               ; preds = %38, %40, %42
  %52 = phi i32 [ 1, %38 ], [ -1, %40 ], [ %46, %42 ], !dbg !2676
  %53 = phi double [ 0x3DEA39EF35793C76, %38 ], [ 0xBDEA39EF35793C76, %40 ], [ %50, %42 ], !dbg !2676
  %54 = phi double [ %39, %38 ], [ %41, %40 ], [ %49, %42 ], !dbg !2676
  tail call void @llvm.dbg.value(metadata double %54, metadata !447, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double %53, metadata !448, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !456, metadata !DIExpression()), !dbg !2618
  %55 = fsub double %54, %53, !dbg !2677
  tail call void @llvm.dbg.value(metadata double %55, metadata !445, metadata !DIExpression()), !dbg !2618
  %56 = fsub double %54, %55, !dbg !2678
  %57 = fsub double %56, %53, !dbg !2679
  tail call void @llvm.dbg.value(metadata double %57, metadata !449, metadata !DIExpression()), !dbg !2618
  br label %67, !dbg !2680

58:                                               ; preds = %32
  %59 = icmp ult i32 %6, 1016070144, !dbg !2681
  br i1 %59, label %60, label %67, !dbg !2683

60:                                               ; preds = %58
  %61 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2684, !tbaa !1436
  %62 = fadd double %61, %0, !dbg !2686
  tail call void @llvm.dbg.value(metadata double %62, metadata !450, metadata !DIExpression()), !dbg !2618
  %63 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2687, !tbaa !1436
  %64 = fadd double %63, %0, !dbg !2688
  %65 = fsub double %62, %64, !dbg !2689
  %66 = fsub double %0, %65, !dbg !2690
  br label %145, !dbg !2691

67:                                               ; preds = %58, %51
  %68 = phi i32 [ %52, %51 ], [ 0, %58 ], !dbg !2692
  %69 = phi double [ %57, %51 ], [ undef, %58 ]
  %70 = phi double [ %55, %51 ], [ %0, %58 ]
  tail call void @llvm.dbg.value(metadata double %70, metadata !445, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double %69, metadata !449, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !456, metadata !DIExpression()), !dbg !2618
  %71 = fmul double %70, 5.000000e-01, !dbg !2693
  tail call void @llvm.dbg.value(metadata double %71, metadata !453, metadata !DIExpression()), !dbg !2618
  %72 = fmul double %70, %71, !dbg !2694
  tail call void @llvm.dbg.value(metadata double %72, metadata !452, metadata !DIExpression()), !dbg !2618
  %73 = tail call double @llvm.fmuladd.f64(double %72, double 0xBE8AFDB76E09C32D, double 0x3ED0CFCA86E65239), !dbg !2695
  %74 = tail call double @llvm.fmuladd.f64(double %72, double %73, double 0xBF14CE199EAADBB7), !dbg !2696
  %75 = tail call double @llvm.fmuladd.f64(double %72, double %74, double 0x3F5A01A019FE5585), !dbg !2697
  %76 = tail call double @llvm.fmuladd.f64(double %72, double %75, double 0xBFA11111111110F4), !dbg !2698
  %77 = tail call double @llvm.fmuladd.f64(double %72, double %76, double 1.000000e+00), !dbg !2699
  tail call void @llvm.dbg.value(metadata double %77, metadata !454, metadata !DIExpression()), !dbg !2618
  %78 = fneg double %77, !dbg !2700
  %79 = tail call double @llvm.fmuladd.f64(double %78, double %71, double 3.000000e+00), !dbg !2700
  tail call void @llvm.dbg.value(metadata double %79, metadata !450, metadata !DIExpression()), !dbg !2618
  %80 = fsub double %77, %79, !dbg !2701
  %81 = fneg double %70, !dbg !2702
  %82 = tail call double @llvm.fmuladd.f64(double %81, double %79, double 6.000000e+00), !dbg !2702
  %83 = fdiv double %80, %82, !dbg !2703
  %84 = fmul double %72, %83, !dbg !2704
  tail call void @llvm.dbg.value(metadata double %84, metadata !451, metadata !DIExpression()), !dbg !2618
  %85 = icmp eq i32 %68, 0, !dbg !2705
  br i1 %85, label %86, label %90, !dbg !2706

86:                                               ; preds = %67
  %87 = fneg double %72, !dbg !2707
  %88 = tail call double @llvm.fmuladd.f64(double %70, double %84, double %87), !dbg !2707
  %89 = fsub double %70, %88, !dbg !2709
  br label %145, !dbg !2710

90:                                               ; preds = %67
  tail call void @llvm.dbg.value(metadata i64 0, metadata !470, metadata !DIExpression()), !dbg !2711
  %91 = shl i32 %68, 20, !dbg !2712
  %92 = add nsw i32 %91, 1072693248, !dbg !2712
  %93 = sext i32 %92 to i64, !dbg !2712
  %94 = shl nsw i64 %93, 32, !dbg !2712
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !470, metadata !DIExpression()), !dbg !2711
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !946, metadata !DIExpression()), !dbg !2713
  %95 = bitcast i64 %94 to double, !dbg !2715
  tail call void @llvm.dbg.value(metadata double %95, metadata !951, metadata !DIExpression()), !dbg !2713
  tail call void @llvm.dbg.value(metadata double %95, metadata !455, metadata !DIExpression()), !dbg !2618
  %96 = fsub double %84, %69, !dbg !2716
  %97 = fneg double %69, !dbg !2717
  %98 = tail call double @llvm.fmuladd.f64(double %70, double %96, double %97), !dbg !2717
  tail call void @llvm.dbg.value(metadata double %98, metadata !451, metadata !DIExpression()), !dbg !2618
  %99 = fsub double %98, %72, !dbg !2718
  tail call void @llvm.dbg.value(metadata double %99, metadata !451, metadata !DIExpression()), !dbg !2618
  switch i32 %68, label %112 [
    i32 -1, label %100
    i32 1, label %103
  ], !dbg !2719

100:                                              ; preds = %90
  %101 = fsub double %70, %99, !dbg !2720
  %102 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double -5.000000e-01), !dbg !2722
  br label %145, !dbg !2723

103:                                              ; preds = %90
  %104 = fcmp olt double %70, -2.500000e-01, !dbg !2724
  br i1 %104, label %105, label %109, !dbg !2728

105:                                              ; preds = %103
  %106 = fadd double %70, 5.000000e-01, !dbg !2729
  %107 = fsub double %99, %106, !dbg !2730
  %108 = fmul double %107, -2.000000e+00, !dbg !2731
  br label %145, !dbg !2732

109:                                              ; preds = %103
  %110 = fsub double %70, %99, !dbg !2733
  %111 = tail call double @llvm.fmuladd.f64(double %110, double 2.000000e+00, double 1.000000e+00), !dbg !2734
  br label %145, !dbg !2735

112:                                              ; preds = %90
  %113 = add i32 %68, -57, !dbg !2736
  %114 = icmp ult i32 %113, -58, !dbg !2736
  br i1 %114, label %115, label %124, !dbg !2736

115:                                              ; preds = %112
  %116 = fsub double %70, %99, !dbg !2738
  %117 = fadd double %116, 1.000000e+00, !dbg !2738
  tail call void @llvm.dbg.value(metadata double %117, metadata !446, metadata !DIExpression()), !dbg !2618
  %118 = icmp eq i32 %68, 1024, !dbg !2740
  %119 = fmul double %117, 2.000000e+00, !dbg !2742
  %120 = fmul double %119, 0x7FE0000000000000, !dbg !2742
  %121 = fmul double %117, %95, !dbg !2742
  %122 = select i1 %118, double %120, double %121, !dbg !2742
  tail call void @llvm.dbg.value(metadata double %122, metadata !446, metadata !DIExpression()), !dbg !2618
  %123 = fadd double %122, -1.000000e+00, !dbg !2743
  br label %145, !dbg !2744

124:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !450, metadata !DIExpression()), !dbg !2618
  %125 = icmp ult i32 %68, 20, !dbg !2745
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !872, metadata !DIExpression()), !dbg !2746
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !872, metadata !DIExpression()), !dbg !2748
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !877, metadata !DIExpression()), !dbg !2746
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !877, metadata !DIExpression()), !dbg !2748
  tail call void @llvm.dbg.value(metadata double poison, metadata !446, metadata !DIExpression()), !dbg !2618
  tail call void @llvm.dbg.value(metadata double poison, metadata !446, metadata !DIExpression()), !dbg !2618
  br i1 %125, label %126, label %134, !dbg !2750

126:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !474, metadata !DIExpression()), !dbg !2751
  %127 = lshr i32 2097152, %68
  %128 = sub nuw nsw i32 1072693248, %127, !dbg !2752
  %129 = zext nneg i32 %128 to i64
  %130 = shl nuw nsw i64 %129, 32, !dbg !2752
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !474, metadata !DIExpression()), !dbg !2751
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !946, metadata !DIExpression()), !dbg !2753
  %131 = bitcast i64 %130 to double, !dbg !2755
  tail call void @llvm.dbg.value(metadata double %131, metadata !951, metadata !DIExpression()), !dbg !2753
  tail call void @llvm.dbg.value(metadata double %131, metadata !450, metadata !DIExpression()), !dbg !2618
  %132 = fsub double %99, %70, !dbg !2756
  %133 = fsub double %131, %132, !dbg !2757
  br label %142, !dbg !2758

134:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !478, metadata !DIExpression()), !dbg !2759
  %135 = sub i32 1072693248, %91, !dbg !2760
  %136 = zext nneg i32 %135 to i64
  %137 = shl nuw nsw i64 %136, 32, !dbg !2760
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !478, metadata !DIExpression()), !dbg !2759
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !946, metadata !DIExpression()), !dbg !2761
  %138 = bitcast i64 %137 to double, !dbg !2763
  tail call void @llvm.dbg.value(metadata double %138, metadata !951, metadata !DIExpression()), !dbg !2761
  tail call void @llvm.dbg.value(metadata double %138, metadata !450, metadata !DIExpression()), !dbg !2618
  %139 = fadd double %99, %138, !dbg !2764
  %140 = fsub double %70, %139, !dbg !2765
  tail call void @llvm.dbg.value(metadata double %140, metadata !446, metadata !DIExpression()), !dbg !2618
  %141 = fadd double %140, 1.000000e+00, !dbg !2766
  br label %142

142:                                              ; preds = %126, %134
  %143 = phi double [ %133, %126 ], [ %141, %134 ]
  %144 = fmul double %143, %95, !dbg !2767
  tail call void @llvm.dbg.value(metadata double %144, metadata !446, metadata !DIExpression()), !dbg !2618
  br label %145, !dbg !2768

145:                                              ; preds = %27, %142, %115, %109, %105, %100, %86, %60, %23, %12
  %146 = phi double [ %20, %12 ], [ %26, %23 ], [ %89, %86 ], [ %102, %100 ], [ %108, %105 ], [ %111, %109 ], [ %123, %115 ], [ %144, %142 ], [ %66, %60 ], [ -1.000000e+00, %27 ], !dbg !2618
  ret double %146, !dbg !2769
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync)
define double @pts_ieee754_cbrt(double noundef %0) local_unnamed_addr #0 !dbg !505 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !507, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !511, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2771
  %2 = bitcast double %0 to i64, !dbg !2773
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !2771
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !516, metadata !DIExpression()), !dbg !2774
  %3 = lshr i64 %2, 32, !dbg !2775
  %4 = trunc i64 %3 to i32, !dbg !2775
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !508, metadata !DIExpression()), !dbg !2770
  %5 = trunc i64 %2 to i32, !dbg !2775
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !515, metadata !DIExpression()), !dbg !2770
  %6 = and i32 %4, -2147483648, !dbg !2776
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !513, metadata !DIExpression()), !dbg !2770
  %7 = and i32 %4, 2147483647, !dbg !2777
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !508, metadata !DIExpression()), !dbg !2770
  %8 = icmp ugt i32 %7, 2146435071, !dbg !2778
  br i1 %8, label %9, label %11, !dbg !2780

9:                                                ; preds = %1
  %10 = fadd double %0, %0, !dbg !2781
  br label %52, !dbg !2782

11:                                               ; preds = %1
  %12 = icmp ult i32 %7, 1048576, !dbg !2783
  br i1 %12, label %13, label %22, !dbg !2784

13:                                               ; preds = %11
  %14 = or i32 %7, %5, !dbg !2785
  %15 = icmp eq i32 %14, 0, !dbg !2787
  br i1 %15, label %52, label %16, !dbg !2788

16:                                               ; preds = %13
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !872, metadata !DIExpression()), !dbg !2789
  tail call void @llvm.dbg.value(metadata i64 0, metadata !877, metadata !DIExpression()), !dbg !2789
  tail call void @llvm.dbg.value(metadata i64 4850376798678024192, metadata !946, metadata !DIExpression()), !dbg !2791
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !951, metadata !DIExpression()), !dbg !2791
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !511, metadata !DIExpression()), !dbg !2770
  %17 = fmul double %0, 0x4350000000000000, !dbg !2793
  tail call void @llvm.dbg.value(metadata double %17, metadata !511, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata double %17, metadata !872, metadata !DIExpression()), !dbg !2794
  %18 = bitcast double %17 to i64, !dbg !2796
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !877, metadata !DIExpression()), !dbg !2794
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !522, metadata !DIExpression()), !dbg !2797
  %19 = lshr i64 %18, 32, !dbg !2798
  %20 = trunc i64 %19 to i32, !dbg !2798
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !514, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata i64 0, metadata !524, metadata !DIExpression()), !dbg !2799
  %21 = and i32 %20, 2147483647, !dbg !2800
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !524, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2799
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !524, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2799
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !946, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2801
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !951, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2801
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !511, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2770
  br label %22, !dbg !2803

22:                                               ; preds = %11, %16
  %23 = phi i32 [ %21, %16 ], [ %7, %11 ]
  %24 = phi i32 [ 696219795, %16 ], [ 715094163, %11 ]
  %25 = udiv i32 %23, 3
  %26 = add nuw nsw i32 %25, %24, !dbg !2804
  %27 = or disjoint i32 %26, %6, !dbg !2804
  %28 = zext i32 %27 to i64, !dbg !2804
  %29 = shl nuw i64 %28, 32, !dbg !2804
  %30 = bitcast i64 %29 to double, !dbg !2804
  tail call void @llvm.dbg.value(metadata double %30, metadata !511, metadata !DIExpression()), !dbg !2770
  %31 = fmul double %30, %30, !dbg !2805
  %32 = fdiv double %30, %0, !dbg !2806
  %33 = fmul double %31, %32, !dbg !2807
  tail call void @llvm.dbg.value(metadata double %33, metadata !509, metadata !DIExpression()), !dbg !2770
  %34 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FF9F1604A49D6C2, double 0xBFFE28E092F02420), !dbg !2808
  %35 = tail call double @llvm.fmuladd.f64(double %33, double %34, double 0x3FFE03E60F61E692), !dbg !2809
  %36 = fmul double %33, %33, !dbg !2810
  %37 = fmul double %33, %36, !dbg !2811
  %38 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FC2B000D4E4EDD7, double 0xBFE844CBBEE751D9), !dbg !2812
  %39 = tail call double @llvm.fmuladd.f64(double %37, double %38, double %35), !dbg !2813
  %40 = fmul double %39, %30, !dbg !2814
  tail call void @llvm.dbg.value(metadata double %40, metadata !511, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata double %40, metadata !872, metadata !DIExpression()), !dbg !2815
  %41 = bitcast double %40 to i64, !dbg !2817
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !877, metadata !DIExpression()), !dbg !2815
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !529, metadata !DIExpression()), !dbg !2770
  %42 = and i64 %41, -1073741824, !dbg !2818
  %43 = add i64 %42, 2147483648, !dbg !2818
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !529, metadata !DIExpression()), !dbg !2770
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !946, metadata !DIExpression()), !dbg !2819
  %44 = bitcast i64 %43 to double, !dbg !2821
  tail call void @llvm.dbg.value(metadata double %44, metadata !951, metadata !DIExpression()), !dbg !2819
  tail call void @llvm.dbg.value(metadata double %44, metadata !511, metadata !DIExpression()), !dbg !2770
  %45 = fmul double %44, %44, !dbg !2822
  tail call void @llvm.dbg.value(metadata double %45, metadata !510, metadata !DIExpression()), !dbg !2770
  %46 = fdiv double %0, %45, !dbg !2823
  tail call void @llvm.dbg.value(metadata double %46, metadata !509, metadata !DIExpression()), !dbg !2770
  %47 = fadd double %44, %44, !dbg !2824
  tail call void @llvm.dbg.value(metadata double %47, metadata !512, metadata !DIExpression()), !dbg !2770
  %48 = fsub double %46, %44, !dbg !2825
  %49 = fadd double %47, %46, !dbg !2826
  %50 = fdiv double %48, %49, !dbg !2827
  tail call void @llvm.dbg.value(metadata double %50, metadata !509, metadata !DIExpression()), !dbg !2770
  %51 = tail call double @llvm.fmuladd.f64(double %44, double %50, double %44), !dbg !2828
  tail call void @llvm.dbg.value(metadata double %51, metadata !511, metadata !DIExpression()), !dbg !2770
  br label %52

52:                                               ; preds = %13, %22, %9
  %53 = phi double [ %10, %9 ], [ %51, %22 ], [ %0, %13 ], !dbg !2770
  ret double %53, !dbg !2829
}

; Function Attrs: nofree nosync nounwind ssp memory(none) uwtable(sync)
define double @pts_ieee754_sin(double noundef %0) local_unnamed_addr #5 !dbg !2830 {
  %2 = alloca [2 x double], align 8
  tail call void @llvm.dbg.value(metadata double %0, metadata !2832, metadata !DIExpression()), !dbg !2839
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !2840
  call void @llvm.dbg.declare(metadata ptr %2, metadata !2833, metadata !DIExpression()), !dbg !2841
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2834, metadata !DIExpression()), !dbg !2839
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2842
  %3 = bitcast double %0 to i64, !dbg !2844
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !2842
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !2837, metadata !DIExpression()), !dbg !2845
  %4 = lshr i64 %3, 32, !dbg !2846
  %5 = trunc i64 %4 to i32, !dbg !2846
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2836, metadata !DIExpression()), !dbg !2839
  %6 = and i32 %5, 2147483647, !dbg !2847
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !2836, metadata !DIExpression()), !dbg !2839
  %7 = icmp ult i32 %6, 1072243196, !dbg !2848
  br i1 %7, label %8, label %23, !dbg !2850

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !769, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !770, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata i32 0, metadata !771, metadata !DIExpression()), !dbg !2851
  call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2854
  call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !2854
  call void @llvm.dbg.value(metadata i64 %3, metadata !776, metadata !DIExpression()), !dbg !2856
  call void @llvm.dbg.value(metadata i64 %3, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2851
  call void @llvm.dbg.value(metadata i64 %3, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2851
  %9 = and i64 %3, 9205357638345293824, !dbg !2857
  %10 = icmp ult i64 %9, 4485585228861014016, !dbg !2857
  %11 = fptosi double %0 to i32
  %12 = icmp eq i32 %11, 0
  %13 = select i1 %10, i1 %12, i1 false, !dbg !2858
  br i1 %13, label %167, label %14, !dbg !2858

14:                                               ; preds = %8
  %15 = fmul double %0, %0, !dbg !2859
  call void @llvm.dbg.value(metadata double %15, metadata !772, metadata !DIExpression()), !dbg !2851
  %16 = fmul double %15, %0, !dbg !2860
  call void @llvm.dbg.value(metadata double %16, metadata !774, metadata !DIExpression()), !dbg !2851
  %17 = tail call double @llvm.fmuladd.f64(double %15, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2861
  %18 = tail call double @llvm.fmuladd.f64(double %15, double %17, double 0x3EC71DE357B1FE7D), !dbg !2862
  %19 = tail call double @llvm.fmuladd.f64(double %15, double %18, double 0xBF2A01A019C161D5), !dbg !2863
  %20 = tail call double @llvm.fmuladd.f64(double %15, double %19, double 0x3F8111111110F8A6), !dbg !2864
  call void @llvm.dbg.value(metadata double %20, metadata !773, metadata !DIExpression()), !dbg !2851
  %21 = tail call double @llvm.fmuladd.f64(double %15, double %20, double 0xBFC5555555555549), !dbg !2865
  %22 = tail call double @llvm.fmuladd.f64(double %16, double %21, double %0), !dbg !2867
  br label %167, !dbg !2868

23:                                               ; preds = %1
  %24 = icmp ugt i32 %6, 2146435071, !dbg !2869
  br i1 %24, label %25, label %27, !dbg !2871

25:                                               ; preds = %23
  %26 = fsub double %0, %0, !dbg !2872
  br label %167, !dbg !2874

27:                                               ; preds = %23
  %28 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !2875
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !2835, metadata !DIExpression()), !dbg !2839
  %29 = and i32 %28, 3, !dbg !2877
  %30 = load double, ptr %2, align 8, !dbg !2878, !tbaa !1436
  switch i32 %29, label %122 [
    i32 0, label %31
    i32 1, label %54
    i32 2, label %96
  ], !dbg !2880

31:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !769, metadata !DIExpression()), !dbg !2881
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !2881
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !2881
  call void @llvm.dbg.value(metadata double %30, metadata !872, metadata !DIExpression()), !dbg !2883
  %32 = bitcast double %30 to i64, !dbg !2885
  call void @llvm.dbg.value(metadata i64 %32, metadata !877, metadata !DIExpression()), !dbg !2883
  call void @llvm.dbg.value(metadata i64 %32, metadata !776, metadata !DIExpression()), !dbg !2886
  call void @llvm.dbg.value(metadata i64 %32, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2881
  %33 = and i64 %32, 9205357638345293824, !dbg !2887
  %34 = icmp ult i64 %33, 4485585228861014016, !dbg !2887
  %35 = fptosi double %30 to i32
  %36 = icmp eq i32 %35, 0
  %37 = select i1 %34, i1 %36, i1 false, !dbg !2888
  br i1 %37, label %167, label %38, !dbg !2888

38:                                               ; preds = %31
  %39 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2889
  %40 = load double, ptr %39, align 8, !dbg !2889, !tbaa !1436
  call void @llvm.dbg.value(metadata double %40, metadata !770, metadata !DIExpression()), !dbg !2881
  %41 = fmul double %30, %30, !dbg !2890
  call void @llvm.dbg.value(metadata double %41, metadata !772, metadata !DIExpression()), !dbg !2881
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !2881
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2891
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0x3EC71DE357B1FE7D), !dbg !2892
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0xBF2A01A019C161D5), !dbg !2893
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0x3F8111111110F8A6), !dbg !2894
  call void @llvm.dbg.value(metadata double %45, metadata !773, metadata !DIExpression()), !dbg !2881
  %46 = fneg double %41, !dbg !2895
  %47 = fmul double %30, %46, !dbg !2895
  %48 = fmul double %47, %45, !dbg !2895
  %49 = tail call double @llvm.fmuladd.f64(double %40, double 5.000000e-01, double %48), !dbg !2895
  %50 = fneg double %40, !dbg !2896
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %49, double %50), !dbg !2896
  %52 = tail call double @llvm.fmuladd.f64(double %47, double 0xBFC5555555555549, double %51), !dbg !2897
  %53 = fsub double %30, %52, !dbg !2898
  br label %167, !dbg !2899

54:                                               ; preds = %27
  %55 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2900
  %56 = load double, ptr %55, align 8, !dbg !2900, !tbaa !1436
  call void @llvm.dbg.value(metadata double %30, metadata !609, metadata !DIExpression()), !dbg !2901
  call void @llvm.dbg.value(metadata double %56, metadata !610, metadata !DIExpression()), !dbg !2901
  call void @llvm.dbg.value(metadata double %30, metadata !872, metadata !DIExpression()), !dbg !2903
  %57 = bitcast double %30 to i64, !dbg !2905
  call void @llvm.dbg.value(metadata i64 %57, metadata !877, metadata !DIExpression()), !dbg !2903
  call void @llvm.dbg.value(metadata i64 %57, metadata !617, metadata !DIExpression()), !dbg !2906
  %58 = lshr i64 %57, 32, !dbg !2907
  %59 = trunc i64 %58 to i32, !dbg !2907
  call void @llvm.dbg.value(metadata i32 %59, metadata !616, metadata !DIExpression()), !dbg !2901
  %60 = and i32 %59, 2147483647, !dbg !2908
  call void @llvm.dbg.value(metadata i32 %60, metadata !616, metadata !DIExpression()), !dbg !2901
  %61 = icmp ult i32 %60, 1044381696, !dbg !2909
  %62 = fptosi double %30 to i32
  %63 = icmp eq i32 %62, 0
  %64 = select i1 %61, i1 %63, i1 false, !dbg !2910
  br i1 %64, label %167, label %65, !dbg !2910

65:                                               ; preds = %54
  %66 = fmul double %30, %30, !dbg !2911
  call void @llvm.dbg.value(metadata double %66, metadata !613, metadata !DIExpression()), !dbg !2901
  %67 = tail call double @llvm.fmuladd.f64(double %66, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2912
  %68 = tail call double @llvm.fmuladd.f64(double %66, double %67, double 0xBE927E4F809C52AD), !dbg !2913
  %69 = tail call double @llvm.fmuladd.f64(double %66, double %68, double 0x3EFA01A019CB1590), !dbg !2914
  %70 = tail call double @llvm.fmuladd.f64(double %66, double %69, double 0xBF56C16C16C15177), !dbg !2915
  %71 = tail call double @llvm.fmuladd.f64(double %66, double %70, double 0x3FA555555555554C), !dbg !2916
  %72 = fmul double %66, %71, !dbg !2917
  call void @llvm.dbg.value(metadata double %72, metadata !614, metadata !DIExpression()), !dbg !2901
  %73 = icmp ult i32 %60, 1070805811, !dbg !2918
  br i1 %73, label %74, label %81, !dbg !2919

74:                                               ; preds = %65
  %75 = fneg double %30, !dbg !2920
  %76 = fmul double %56, %75, !dbg !2920
  %77 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %76), !dbg !2920
  %78 = fneg double %77, !dbg !2921
  %79 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %78), !dbg !2921
  %80 = fsub double 1.000000e+00, %79, !dbg !2922
  br label %167, !dbg !2923

81:                                               ; preds = %65
  %82 = icmp ugt i32 %60, 1072234496, !dbg !2924
  %83 = add nsw i32 %60, -2097152, !dbg !2925
  %84 = zext nneg i32 %83 to i64, !dbg !2925
  %85 = shl nuw nsw i64 %84, 32, !dbg !2925
  %86 = bitcast i64 %85 to double, !dbg !2925
  %87 = select i1 %82, double 2.812500e-01, double %86, !dbg !2925
  call void @llvm.dbg.value(metadata double %87, metadata !615, metadata !DIExpression()), !dbg !2901
  %88 = fneg double %87, !dbg !2926
  %89 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %88), !dbg !2926
  call void @llvm.dbg.value(metadata double %89, metadata !612, metadata !DIExpression()), !dbg !2901
  %90 = fsub double 1.000000e+00, %87, !dbg !2927
  call void @llvm.dbg.value(metadata double %90, metadata !611, metadata !DIExpression()), !dbg !2901
  %91 = fneg double %30, !dbg !2928
  %92 = fmul double %56, %91, !dbg !2928
  %93 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %92), !dbg !2928
  %94 = fsub double %93, %89, !dbg !2929
  %95 = fadd double %90, %94, !dbg !2929
  br label %167, !dbg !2930

96:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !769, metadata !DIExpression()), !dbg !2931
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !2931
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !2931
  call void @llvm.dbg.value(metadata double %30, metadata !872, metadata !DIExpression()), !dbg !2933
  %97 = bitcast double %30 to i64, !dbg !2935
  call void @llvm.dbg.value(metadata i64 %97, metadata !877, metadata !DIExpression()), !dbg !2933
  call void @llvm.dbg.value(metadata i64 %97, metadata !776, metadata !DIExpression()), !dbg !2936
  call void @llvm.dbg.value(metadata i64 %97, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2931
  %98 = and i64 %97, 9205357638345293824, !dbg !2937
  %99 = icmp ult i64 %98, 4485585228861014016, !dbg !2937
  %100 = fptosi double %30 to i32
  %101 = icmp eq i32 %100, 0
  %102 = select i1 %99, i1 %101, i1 false, !dbg !2938
  br i1 %102, label %119, label %103, !dbg !2938

103:                                              ; preds = %96
  %104 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2939
  %105 = load double, ptr %104, align 8, !dbg !2939, !tbaa !1436
  call void @llvm.dbg.value(metadata double %105, metadata !770, metadata !DIExpression()), !dbg !2931
  %106 = fmul double %30, %30, !dbg !2940
  call void @llvm.dbg.value(metadata double %106, metadata !772, metadata !DIExpression()), !dbg !2931
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !2931
  %107 = tail call double @llvm.fmuladd.f64(double %106, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2941
  %108 = tail call double @llvm.fmuladd.f64(double %106, double %107, double 0x3EC71DE357B1FE7D), !dbg !2942
  %109 = tail call double @llvm.fmuladd.f64(double %106, double %108, double 0xBF2A01A019C161D5), !dbg !2943
  %110 = tail call double @llvm.fmuladd.f64(double %106, double %109, double 0x3F8111111110F8A6), !dbg !2944
  call void @llvm.dbg.value(metadata double %110, metadata !773, metadata !DIExpression()), !dbg !2931
  %111 = fneg double %106, !dbg !2945
  %112 = fmul double %30, %111, !dbg !2945
  %113 = fmul double %112, %110, !dbg !2945
  %114 = tail call double @llvm.fmuladd.f64(double %105, double 5.000000e-01, double %113), !dbg !2945
  %115 = fneg double %105, !dbg !2946
  %116 = tail call double @llvm.fmuladd.f64(double %106, double %114, double %115), !dbg !2946
  %117 = tail call double @llvm.fmuladd.f64(double %112, double 0xBFC5555555555549, double %116), !dbg !2947
  %118 = fsub double %30, %117, !dbg !2948
  br label %119, !dbg !2949

119:                                              ; preds = %96, %103
  %120 = phi double [ %118, %103 ], [ %30, %96 ], !dbg !2931
  %121 = fneg double %120, !dbg !2950
  br label %167, !dbg !2951

122:                                              ; preds = %27
  %123 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2952
  %124 = load double, ptr %123, align 8, !dbg !2952, !tbaa !1436
  call void @llvm.dbg.value(metadata double %30, metadata !609, metadata !DIExpression()), !dbg !2953
  call void @llvm.dbg.value(metadata double %124, metadata !610, metadata !DIExpression()), !dbg !2953
  call void @llvm.dbg.value(metadata double %30, metadata !872, metadata !DIExpression()), !dbg !2955
  %125 = bitcast double %30 to i64, !dbg !2957
  call void @llvm.dbg.value(metadata i64 %125, metadata !877, metadata !DIExpression()), !dbg !2955
  call void @llvm.dbg.value(metadata i64 %125, metadata !617, metadata !DIExpression()), !dbg !2958
  %126 = lshr i64 %125, 32, !dbg !2959
  %127 = trunc i64 %126 to i32, !dbg !2959
  call void @llvm.dbg.value(metadata i32 %127, metadata !616, metadata !DIExpression()), !dbg !2953
  %128 = and i32 %127, 2147483647, !dbg !2960
  call void @llvm.dbg.value(metadata i32 %128, metadata !616, metadata !DIExpression()), !dbg !2953
  %129 = icmp ult i32 %128, 1044381696, !dbg !2961
  %130 = fptosi double %30 to i32
  %131 = icmp eq i32 %130, 0
  %132 = select i1 %129, i1 %131, i1 false, !dbg !2962
  br i1 %132, label %164, label %133, !dbg !2962

133:                                              ; preds = %122
  %134 = fmul double %30, %30, !dbg !2963
  call void @llvm.dbg.value(metadata double %134, metadata !613, metadata !DIExpression()), !dbg !2953
  %135 = tail call double @llvm.fmuladd.f64(double %134, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2964
  %136 = tail call double @llvm.fmuladd.f64(double %134, double %135, double 0xBE927E4F809C52AD), !dbg !2965
  %137 = tail call double @llvm.fmuladd.f64(double %134, double %136, double 0x3EFA01A019CB1590), !dbg !2966
  %138 = tail call double @llvm.fmuladd.f64(double %134, double %137, double 0xBF56C16C16C15177), !dbg !2967
  %139 = tail call double @llvm.fmuladd.f64(double %134, double %138, double 0x3FA555555555554C), !dbg !2968
  %140 = fmul double %134, %139, !dbg !2969
  call void @llvm.dbg.value(metadata double %140, metadata !614, metadata !DIExpression()), !dbg !2953
  %141 = icmp ult i32 %128, 1070805811, !dbg !2970
  br i1 %141, label %142, label %149, !dbg !2971

142:                                              ; preds = %133
  %143 = fneg double %30, !dbg !2972
  %144 = fmul double %124, %143, !dbg !2972
  %145 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %144), !dbg !2972
  %146 = fneg double %145, !dbg !2973
  %147 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %146), !dbg !2973
  %148 = fsub double 1.000000e+00, %147, !dbg !2974
  br label %164, !dbg !2975

149:                                              ; preds = %133
  %150 = icmp ugt i32 %128, 1072234496, !dbg !2976
  %151 = add nsw i32 %128, -2097152, !dbg !2977
  %152 = zext nneg i32 %151 to i64, !dbg !2977
  %153 = shl nuw nsw i64 %152, 32, !dbg !2977
  %154 = bitcast i64 %153 to double, !dbg !2977
  %155 = select i1 %150, double 2.812500e-01, double %154, !dbg !2977
  call void @llvm.dbg.value(metadata double %155, metadata !615, metadata !DIExpression()), !dbg !2953
  %156 = fneg double %155, !dbg !2978
  %157 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %156), !dbg !2978
  call void @llvm.dbg.value(metadata double %157, metadata !612, metadata !DIExpression()), !dbg !2953
  %158 = fsub double 1.000000e+00, %155, !dbg !2979
  call void @llvm.dbg.value(metadata double %158, metadata !611, metadata !DIExpression()), !dbg !2953
  %159 = fneg double %30, !dbg !2980
  %160 = fmul double %124, %159, !dbg !2980
  %161 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %160), !dbg !2980
  %162 = fsub double %161, %157, !dbg !2981
  %163 = fadd double %158, %162, !dbg !2981
  br label %164, !dbg !2982

164:                                              ; preds = %122, %142, %149
  %165 = phi double [ %148, %142 ], [ %163, %149 ], [ 1.000000e+00, %122 ], !dbg !2953
  %166 = fneg double %165, !dbg !2983
  br label %167, !dbg !2984

167:                                              ; preds = %81, %74, %54, %38, %31, %14, %8, %164, %119, %25
  %168 = phi double [ %26, %25 ], [ %166, %164 ], [ %121, %119 ], [ %22, %14 ], [ %0, %8 ], [ %53, %38 ], [ %30, %31 ], [ %80, %74 ], [ %95, %81 ], [ 1.000000e+00, %54 ], !dbg !2985
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !2986
  ret double %168, !dbg !2986
}

; Function Attrs: nofree nosync nounwind ssp memory(none) uwtable(sync)
define double @pts_ieee754_tan(double noundef %0) local_unnamed_addr #5 !dbg !2987 {
  %2 = alloca [2 x double], align 8
  tail call void @llvm.dbg.value(metadata double %0, metadata !2989, metadata !DIExpression()), !dbg !2996
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !2997
  call void @llvm.dbg.declare(metadata ptr %2, metadata !2990, metadata !DIExpression()), !dbg !2998
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2991, metadata !DIExpression()), !dbg !2996
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !2999
  %3 = bitcast double %0 to i64, !dbg !3001
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !2999
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !2994, metadata !DIExpression()), !dbg !3002
  %4 = lshr i64 %3, 32, !dbg !3003
  %5 = trunc i64 %4 to i32, !dbg !3003
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2993, metadata !DIExpression()), !dbg !2996
  %6 = and i32 %5, 2147483647, !dbg !3004
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !2993, metadata !DIExpression()), !dbg !2996
  %7 = icmp ult i32 %6, 1072243196, !dbg !3005
  br i1 %7, label %8, label %54, !dbg !3007

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !808, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata i32 1, metadata !810, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata i64 %3, metadata !877, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata i64 %3, metadata !818, metadata !DIExpression()), !dbg !3013
  call void @llvm.dbg.value(metadata i32 %5, metadata !817, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata i32 %6, metadata !816, metadata !DIExpression()), !dbg !3008
  %9 = icmp ult i32 %6, 1043333120, !dbg !3014
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !3015
  br i1 %12, label %160, label %13, !dbg !3015

13:                                               ; preds = %8
  %14 = icmp ugt i32 %6, 1072010279, !dbg !3016
  br i1 %14, label %15, label %21, !dbg !3018

15:                                               ; preds = %13
  %16 = icmp slt i64 %3, 0, !dbg !3019
  %17 = fneg double %0, !dbg !3022
  %18 = select i1 %16, double %17, double %0, !dbg !3022
  call void @llvm.dbg.value(metadata double %18, metadata !808, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double poison, metadata !809, metadata !DIExpression()), !dbg !3008
  %19 = fsub double 0x3FE921FB54442D18, %18, !dbg !3023
  call void @llvm.dbg.value(metadata double %19, metadata !811, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double 0x3C81A62633145C07, metadata !814, metadata !DIExpression()), !dbg !3008
  %20 = fadd double %19, 0x3C81A62633145C07, !dbg !3024
  call void @llvm.dbg.value(metadata double %20, metadata !808, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3008
  br label %21, !dbg !3025

21:                                               ; preds = %15, %13
  %22 = phi double [ %20, %15 ], [ %0, %13 ]
  call void @llvm.dbg.value(metadata double %22, metadata !808, metadata !DIExpression()), !dbg !3008
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3008
  %23 = fmul double %22, %22, !dbg !3026
  call void @llvm.dbg.value(metadata double %23, metadata !811, metadata !DIExpression()), !dbg !3008
  %24 = fmul double %23, %23, !dbg !3027
  call void @llvm.dbg.value(metadata double %24, metadata !814, metadata !DIExpression()), !dbg !3008
  %25 = tail call double @llvm.fmuladd.f64(double %24, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3028
  %26 = tail call double @llvm.fmuladd.f64(double %24, double %25, double 0x3F4344D8F2F26501), !dbg !3029
  %27 = tail call double @llvm.fmuladd.f64(double %24, double %26, double 0x3F6D6D22C9560328), !dbg !3030
  %28 = tail call double @llvm.fmuladd.f64(double %24, double %27, double 0x3F9664F48406D637), !dbg !3031
  %29 = tail call double @llvm.fmuladd.f64(double %24, double %28, double 0x3FC111111110FE7A), !dbg !3032
  call void @llvm.dbg.value(metadata double %29, metadata !812, metadata !DIExpression()), !dbg !3008
  %30 = tail call double @llvm.fmuladd.f64(double %24, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3033
  %31 = tail call double @llvm.fmuladd.f64(double %24, double %30, double 0x3F3026F71A8D1068), !dbg !3034
  %32 = tail call double @llvm.fmuladd.f64(double %24, double %31, double 0x3F57DBC8FEE08315), !dbg !3035
  %33 = tail call double @llvm.fmuladd.f64(double %24, double %32, double 0x3F8226E3E96E8493), !dbg !3036
  %34 = tail call double @llvm.fmuladd.f64(double %24, double %33, double 0x3FABA1BA1BB341FE), !dbg !3037
  %35 = fmul double %23, %34, !dbg !3038
  call void @llvm.dbg.value(metadata double %35, metadata !813, metadata !DIExpression()), !dbg !3008
  %36 = fmul double %22, %23, !dbg !3039
  call void @llvm.dbg.value(metadata double %36, metadata !815, metadata !DIExpression()), !dbg !3008
  %37 = fadd double %29, %35, !dbg !3040
  %38 = tail call double @llvm.fmuladd.f64(double %36, double %37, double 0.000000e+00), !dbg !3041
  %39 = tail call double @llvm.fmuladd.f64(double %23, double %38, double 0.000000e+00), !dbg !3042
  call void @llvm.dbg.value(metadata double %39, metadata !812, metadata !DIExpression()), !dbg !3008
  %40 = tail call double @llvm.fmuladd.f64(double %36, double 0x3FD5555555555563, double %39), !dbg !3043
  call void @llvm.dbg.value(metadata double %40, metadata !812, metadata !DIExpression()), !dbg !3008
  %41 = fadd double %22, %40, !dbg !3044
  call void @llvm.dbg.value(metadata double %41, metadata !814, metadata !DIExpression()), !dbg !3008
  br i1 %14, label %42, label %160, !dbg !3045

42:                                               ; preds = %21
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !813, metadata !DIExpression()), !dbg !3008
  %43 = lshr i32 %5, 30, !dbg !3046
  %44 = and i32 %43, 2, !dbg !3049
  %45 = sub nsw i32 1, %44, !dbg !3050
  %46 = sitofp i32 %45 to double, !dbg !3051
  %47 = fmul double %41, %41, !dbg !3052
  %48 = fadd double %41, 1.000000e+00, !dbg !3053
  %49 = fdiv double %47, %48, !dbg !3054
  %50 = fsub double %49, %40, !dbg !3055
  %51 = fsub double %22, %50, !dbg !3056
  %52 = tail call double @llvm.fmuladd.f64(double %51, double -2.000000e+00, double 1.000000e+00), !dbg !3057
  %53 = fmul double %52, %46, !dbg !3058
  br label %160, !dbg !3059

54:                                               ; preds = %1
  %55 = icmp ugt i32 %6, 2146435071, !dbg !3060
  br i1 %55, label %56, label %58, !dbg !3062

56:                                               ; preds = %54
  %57 = fsub double %0, %0, !dbg !3063
  br label %160, !dbg !3065

58:                                               ; preds = %54
  %59 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !3066
  tail call void @llvm.dbg.value(metadata i32 %59, metadata !2992, metadata !DIExpression()), !dbg !2996
  %60 = load double, ptr %2, align 8, !dbg !3068, !tbaa !1436
  %61 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !3069
  %62 = load double, ptr %61, align 8, !dbg !3069, !tbaa !1436
  %63 = shl i32 %59, 1, !dbg !3070
  %64 = and i32 %63, 2, !dbg !3070
  %65 = sub nsw i32 1, %64, !dbg !3071
  call void @llvm.dbg.value(metadata double %60, metadata !808, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %62, metadata !809, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata i32 %65, metadata !810, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %60, metadata !872, metadata !DIExpression()), !dbg !3074
  %66 = bitcast double %60 to i64, !dbg !3076
  call void @llvm.dbg.value(metadata i64 %66, metadata !877, metadata !DIExpression()), !dbg !3074
  call void @llvm.dbg.value(metadata i64 %66, metadata !818, metadata !DIExpression()), !dbg !3077
  %67 = lshr i64 %66, 32, !dbg !3078
  %68 = trunc i64 %67 to i32, !dbg !3078
  call void @llvm.dbg.value(metadata i32 %68, metadata !817, metadata !DIExpression()), !dbg !3072
  %69 = and i32 %68, 2147483647, !dbg !3079
  call void @llvm.dbg.value(metadata i32 %69, metadata !816, metadata !DIExpression()), !dbg !3072
  %70 = icmp ult i32 %69, 1043333120, !dbg !3080
  %71 = fptosi double %60 to i32
  %72 = icmp eq i32 %71, 0
  %73 = select i1 %70, i1 %72, i1 false, !dbg !3081
  br i1 %73, label %74, label %99, !dbg !3081

74:                                               ; preds = %58
  call void @llvm.dbg.value(metadata double %60, metadata !872, metadata !DIExpression()), !dbg !3082
  call void @llvm.dbg.value(metadata i64 %66, metadata !877, metadata !DIExpression()), !dbg !3082
  call void @llvm.dbg.value(metadata i64 %66, metadata !825, metadata !DIExpression()), !dbg !3084
  %75 = trunc i64 %66 to i32, !dbg !3085
  call void @llvm.dbg.value(metadata i32 %75, metadata !820, metadata !DIExpression()), !dbg !3086
  %76 = sub nuw nsw i32 2, %64, !dbg !3087
  %77 = or i32 %76, %75, !dbg !3088
  %78 = or i32 %77, %69, !dbg !3088
  %79 = icmp eq i32 %78, 0, !dbg !3089
  br i1 %79, label %80, label %83, !dbg !3090

80:                                               ; preds = %74
  %81 = tail call double @llvm.fabs.f64(double %60), !dbg !3091
  %82 = fdiv double 1.000000e+00, %81, !dbg !3093
  br label %160, !dbg !3094

83:                                               ; preds = %74
  %84 = icmp eq i32 %64, 0, !dbg !3095
  br i1 %84, label %160, label %85, !dbg !3096

85:                                               ; preds = %83
  %86 = fadd double %60, %62, !dbg !3097
  call void @llvm.dbg.value(metadata double %86, metadata !814, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %86, metadata !811, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %86, metadata !872, metadata !DIExpression()), !dbg !3098
  %87 = bitcast double %86 to i64, !dbg !3100
  call void @llvm.dbg.value(metadata i64 %87, metadata !877, metadata !DIExpression()), !dbg !3098
  call void @llvm.dbg.value(metadata i64 %87, metadata !833, metadata !DIExpression()), !dbg !3101
  %88 = and i64 %87, -4294967296, !dbg !3102
  call void @llvm.dbg.value(metadata i64 %88, metadata !833, metadata !DIExpression()), !dbg !3101
  call void @llvm.dbg.value(metadata i64 %88, metadata !946, metadata !DIExpression()), !dbg !3103
  %89 = bitcast i64 %88 to double, !dbg !3105
  call void @llvm.dbg.value(metadata double %89, metadata !951, metadata !DIExpression()), !dbg !3103
  call void @llvm.dbg.value(metadata double %89, metadata !811, metadata !DIExpression()), !dbg !3072
  %90 = fsub double %89, %60, !dbg !3106
  %91 = fsub double %62, %90, !dbg !3107
  call void @llvm.dbg.value(metadata double %91, metadata !813, metadata !DIExpression()), !dbg !3072
  %92 = fdiv double -1.000000e+00, %86, !dbg !3108
  call void @llvm.dbg.value(metadata double %92, metadata !827, metadata !DIExpression()), !dbg !3109
  call void @llvm.dbg.value(metadata double %92, metadata !832, metadata !DIExpression()), !dbg !3109
  call void @llvm.dbg.value(metadata double %92, metadata !872, metadata !DIExpression()), !dbg !3110
  %93 = bitcast double %92 to i64, !dbg !3112
  call void @llvm.dbg.value(metadata i64 %93, metadata !877, metadata !DIExpression()), !dbg !3110
  call void @llvm.dbg.value(metadata i64 %93, metadata !835, metadata !DIExpression()), !dbg !3113
  %94 = and i64 %93, -4294967296, !dbg !3114
  call void @llvm.dbg.value(metadata i64 %94, metadata !835, metadata !DIExpression()), !dbg !3113
  call void @llvm.dbg.value(metadata i64 %94, metadata !946, metadata !DIExpression()), !dbg !3115
  %95 = bitcast i64 %94 to double, !dbg !3117
  call void @llvm.dbg.value(metadata double %95, metadata !951, metadata !DIExpression()), !dbg !3115
  call void @llvm.dbg.value(metadata double %95, metadata !832, metadata !DIExpression()), !dbg !3109
  %96 = tail call double @llvm.fmuladd.f64(double %95, double %89, double 1.000000e+00), !dbg !3118
  call void @llvm.dbg.value(metadata double %96, metadata !815, metadata !DIExpression()), !dbg !3072
  %97 = tail call double @llvm.fmuladd.f64(double %95, double %91, double %96), !dbg !3119
  %98 = tail call double @llvm.fmuladd.f64(double %92, double %97, double %95), !dbg !3120
  br label %160

99:                                               ; preds = %58
  %100 = icmp ugt i32 %69, 1072010279, !dbg !3121
  br i1 %100, label %101, label %110, !dbg !3122

101:                                              ; preds = %99
  %102 = icmp slt i64 %66, 0, !dbg !3123
  %103 = fneg double %60, !dbg !3124
  %104 = fneg double %62, !dbg !3124
  %105 = select i1 %102, double %104, double %62, !dbg !3124
  %106 = select i1 %102, double %103, double %60, !dbg !3124
  call void @llvm.dbg.value(metadata double %106, metadata !808, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %105, metadata !809, metadata !DIExpression()), !dbg !3072
  %107 = fsub double 0x3FE921FB54442D18, %106, !dbg !3125
  call void @llvm.dbg.value(metadata double %107, metadata !811, metadata !DIExpression()), !dbg !3072
  %108 = fsub double 0x3C81A62633145C07, %105, !dbg !3126
  call void @llvm.dbg.value(metadata double %108, metadata !814, metadata !DIExpression()), !dbg !3072
  %109 = fadd double %107, %108, !dbg !3127
  call void @llvm.dbg.value(metadata double %109, metadata !808, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3072
  br label %110, !dbg !3128

110:                                              ; preds = %101, %99
  %111 = phi double [ 0.000000e+00, %101 ], [ %62, %99 ]
  %112 = phi double [ %109, %101 ], [ %60, %99 ]
  call void @llvm.dbg.value(metadata double %112, metadata !808, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %111, metadata !809, metadata !DIExpression()), !dbg !3072
  %113 = fmul double %112, %112, !dbg !3129
  call void @llvm.dbg.value(metadata double %113, metadata !811, metadata !DIExpression()), !dbg !3072
  %114 = fmul double %113, %113, !dbg !3130
  call void @llvm.dbg.value(metadata double %114, metadata !814, metadata !DIExpression()), !dbg !3072
  %115 = tail call double @llvm.fmuladd.f64(double %114, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3131
  %116 = tail call double @llvm.fmuladd.f64(double %114, double %115, double 0x3F4344D8F2F26501), !dbg !3132
  %117 = tail call double @llvm.fmuladd.f64(double %114, double %116, double 0x3F6D6D22C9560328), !dbg !3133
  %118 = tail call double @llvm.fmuladd.f64(double %114, double %117, double 0x3F9664F48406D637), !dbg !3134
  %119 = tail call double @llvm.fmuladd.f64(double %114, double %118, double 0x3FC111111110FE7A), !dbg !3135
  call void @llvm.dbg.value(metadata double %119, metadata !812, metadata !DIExpression()), !dbg !3072
  %120 = tail call double @llvm.fmuladd.f64(double %114, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3136
  %121 = tail call double @llvm.fmuladd.f64(double %114, double %120, double 0x3F3026F71A8D1068), !dbg !3137
  %122 = tail call double @llvm.fmuladd.f64(double %114, double %121, double 0x3F57DBC8FEE08315), !dbg !3138
  %123 = tail call double @llvm.fmuladd.f64(double %114, double %122, double 0x3F8226E3E96E8493), !dbg !3139
  %124 = tail call double @llvm.fmuladd.f64(double %114, double %123, double 0x3FABA1BA1BB341FE), !dbg !3140
  %125 = fmul double %113, %124, !dbg !3141
  call void @llvm.dbg.value(metadata double %125, metadata !813, metadata !DIExpression()), !dbg !3072
  %126 = fmul double %112, %113, !dbg !3142
  call void @llvm.dbg.value(metadata double %126, metadata !815, metadata !DIExpression()), !dbg !3072
  %127 = fadd double %119, %125, !dbg !3143
  %128 = tail call double @llvm.fmuladd.f64(double %126, double %127, double %111), !dbg !3144
  %129 = tail call double @llvm.fmuladd.f64(double %113, double %128, double %111), !dbg !3145
  call void @llvm.dbg.value(metadata double %129, metadata !812, metadata !DIExpression()), !dbg !3072
  %130 = tail call double @llvm.fmuladd.f64(double %126, double 0x3FD5555555555563, double %129), !dbg !3146
  call void @llvm.dbg.value(metadata double %130, metadata !812, metadata !DIExpression()), !dbg !3072
  %131 = fadd double %112, %130, !dbg !3147
  call void @llvm.dbg.value(metadata double %131, metadata !814, metadata !DIExpression()), !dbg !3072
  br i1 %100, label %132, label %145, !dbg !3148

132:                                              ; preds = %110
  %133 = sitofp i32 %65 to double, !dbg !3149
  call void @llvm.dbg.value(metadata double %133, metadata !813, metadata !DIExpression()), !dbg !3072
  %134 = lshr i32 %68, 30, !dbg !3150
  %135 = and i32 %134, 2, !dbg !3151
  %136 = sub nsw i32 1, %135, !dbg !3152
  %137 = sitofp i32 %136 to double, !dbg !3153
  %138 = fmul double %131, %131, !dbg !3154
  %139 = fadd double %131, %133, !dbg !3155
  %140 = fdiv double %138, %139, !dbg !3156
  %141 = fsub double %140, %130, !dbg !3157
  %142 = fsub double %112, %141, !dbg !3158
  %143 = tail call double @llvm.fmuladd.f64(double %142, double -2.000000e+00, double %133), !dbg !3159
  %144 = fmul double %143, %137, !dbg !3160
  br label %160, !dbg !3161

145:                                              ; preds = %110
  %146 = icmp eq i32 %64, 0, !dbg !3162
  br i1 %146, label %160, label %147, !dbg !3163

147:                                              ; preds = %145
  call void @llvm.dbg.value(metadata double %131, metadata !811, metadata !DIExpression()), !dbg !3072
  call void @llvm.dbg.value(metadata double %131, metadata !872, metadata !DIExpression()), !dbg !3164
  %148 = bitcast double %131 to i64, !dbg !3166
  call void @llvm.dbg.value(metadata i64 %148, metadata !877, metadata !DIExpression()), !dbg !3164
  call void @llvm.dbg.value(metadata i64 %148, metadata !841, metadata !DIExpression()), !dbg !3167
  %149 = and i64 %148, -4294967296, !dbg !3168
  call void @llvm.dbg.value(metadata i64 %149, metadata !841, metadata !DIExpression()), !dbg !3167
  call void @llvm.dbg.value(metadata i64 %149, metadata !946, metadata !DIExpression()), !dbg !3169
  %150 = bitcast i64 %149 to double, !dbg !3171
  call void @llvm.dbg.value(metadata double %150, metadata !951, metadata !DIExpression()), !dbg !3169
  call void @llvm.dbg.value(metadata double %150, metadata !811, metadata !DIExpression()), !dbg !3072
  %151 = fsub double %150, %112, !dbg !3172
  %152 = fsub double %130, %151, !dbg !3173
  call void @llvm.dbg.value(metadata double %152, metadata !813, metadata !DIExpression()), !dbg !3072
  %153 = fdiv double -1.000000e+00, %131, !dbg !3174
  call void @llvm.dbg.value(metadata double %153, metadata !837, metadata !DIExpression()), !dbg !3175
  call void @llvm.dbg.value(metadata double %153, metadata !840, metadata !DIExpression()), !dbg !3175
  call void @llvm.dbg.value(metadata double %153, metadata !872, metadata !DIExpression()), !dbg !3176
  %154 = bitcast double %153 to i64, !dbg !3178
  call void @llvm.dbg.value(metadata i64 %154, metadata !877, metadata !DIExpression()), !dbg !3176
  call void @llvm.dbg.value(metadata i64 %154, metadata !843, metadata !DIExpression()), !dbg !3179
  %155 = and i64 %154, -4294967296, !dbg !3180
  call void @llvm.dbg.value(metadata i64 %155, metadata !843, metadata !DIExpression()), !dbg !3179
  call void @llvm.dbg.value(metadata i64 %155, metadata !946, metadata !DIExpression()), !dbg !3181
  %156 = bitcast i64 %155 to double, !dbg !3183
  call void @llvm.dbg.value(metadata double %156, metadata !951, metadata !DIExpression()), !dbg !3181
  call void @llvm.dbg.value(metadata double %156, metadata !840, metadata !DIExpression()), !dbg !3175
  %157 = tail call double @llvm.fmuladd.f64(double %156, double %150, double 1.000000e+00), !dbg !3184
  call void @llvm.dbg.value(metadata double %157, metadata !815, metadata !DIExpression()), !dbg !3072
  %158 = tail call double @llvm.fmuladd.f64(double %156, double %152, double %157), !dbg !3185
  %159 = tail call double @llvm.fmuladd.f64(double %153, double %158, double %156), !dbg !3186
  br label %160

160:                                              ; preds = %8, %147, %145, %132, %85, %83, %80, %42, %21, %56
  %161 = phi double [ %57, %56 ], [ %53, %42 ], [ %41, %21 ], [ %144, %132 ], [ %159, %147 ], [ %82, %80 ], [ %98, %85 ], [ %60, %83 ], [ %131, %145 ], [ %0, %8 ], !dbg !3187
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !3188
  ret double %161, !dbg !3188
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn uwtable(sync)
define double @pts_ieee754_cosh(double noundef %0) local_unnamed_addr #7 !dbg !545 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !547, metadata !DIExpression()), !dbg !3189
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !3190
  %2 = bitcast double %0 to i64, !dbg !3192
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !3190
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !549, metadata !DIExpression()), !dbg !3193
  %3 = lshr i64 %2, 32, !dbg !3194
  %4 = trunc i64 %3 to i32, !dbg !3194
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !548, metadata !DIExpression()), !dbg !3189
  %5 = and i32 %4, 2147483647, !dbg !3195
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !548, metadata !DIExpression()), !dbg !3189
  %6 = icmp ult i32 %5, 1071001155, !dbg !3196
  br i1 %6, label %7, label %17, !dbg !3197

7:                                                ; preds = %1
  %8 = tail call double @llvm.fabs.f64(double %0), !dbg !3198
  %9 = tail call double @pts_ieee754_expm1(double noundef %8), !dbg !3199
  tail call void @llvm.dbg.value(metadata double %9, metadata !551, metadata !DIExpression()), !dbg !3200
  %10 = fadd double %9, 1.000000e+00, !dbg !3201
  tail call void @llvm.dbg.value(metadata double %10, metadata !554, metadata !DIExpression()), !dbg !3200
  %11 = icmp ult i32 %5, 1015021568, !dbg !3202
  br i1 %11, label %45, label %12, !dbg !3204

12:                                               ; preds = %7
  %13 = fmul double %9, %9, !dbg !3205
  %14 = fadd double %10, %10, !dbg !3206
  %15 = fdiv double %13, %14, !dbg !3207
  %16 = fadd double %15, 1.000000e+00, !dbg !3208
  br label %45, !dbg !3209

17:                                               ; preds = %1
  %18 = icmp ult i32 %5, 1077280768, !dbg !3210
  br i1 %18, label %19, label %24, !dbg !3211

19:                                               ; preds = %17
  %20 = tail call double @llvm.fabs.f64(double %0), !dbg !3212
  %21 = tail call double @pts_ieee754_exp(double noundef %20), !dbg !3213
  tail call void @llvm.dbg.value(metadata double %21, metadata !555, metadata !DIExpression()), !dbg !3214
  %22 = fdiv double 5.000000e-01, %21, !dbg !3215
  %23 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %22), !dbg !3216
  br label %45

24:                                               ; preds = %17
  %25 = icmp ult i32 %5, 1082535490, !dbg !3217
  %26 = tail call double @llvm.fabs.f64(double %0), !dbg !3189
  br i1 %25, label %27, label %30, !dbg !3219

27:                                               ; preds = %24
  %28 = tail call double @pts_ieee754_exp(double noundef %26), !dbg !3220
  %29 = fmul double %28, 5.000000e-01, !dbg !3221
  br label %45, !dbg !3222

30:                                               ; preds = %24
  %31 = fcmp ugt double %26, 0x408633CE8FB9F87D, !dbg !3223
  br i1 %31, label %37, label %32, !dbg !3224

32:                                               ; preds = %30
  %33 = fmul double %26, 5.000000e-01, !dbg !3225
  %34 = tail call double @pts_ieee754_exp(double noundef %33), !dbg !3226
  tail call void @llvm.dbg.value(metadata double %34, metadata !558, metadata !DIExpression()), !dbg !3227
  %35 = fmul double %34, 5.000000e-01, !dbg !3228
  tail call void @llvm.dbg.value(metadata double %35, metadata !561, metadata !DIExpression()), !dbg !3227
  %36 = fmul double %34, %35, !dbg !3229
  br label %45

37:                                               ; preds = %30
  %38 = icmp ugt i32 %5, 2146435071, !dbg !3230
  br i1 %38, label %39, label %41, !dbg !3232

39:                                               ; preds = %37
  %40 = fmul double %0, %0, !dbg !3233
  br label %45, !dbg !3234

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3235, !tbaa !1436
  %43 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3236, !tbaa !1436
  %44 = fmul double %42, %43, !dbg !3237
  br label %45, !dbg !3238

45:                                               ; preds = %12, %7, %41, %39, %32, %27, %19
  %46 = phi double [ %23, %19 ], [ %29, %27 ], [ %36, %32 ], [ %40, %39 ], [ %44, %41 ], [ %16, %12 ], [ %10, %7 ], !dbg !3189
  ret double %46, !dbg !3239
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn uwtable(sync)
define double @pts_ieee754_sinh(double noundef %0) local_unnamed_addr #7 !dbg !570 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !572, metadata !DIExpression()), !dbg !3240
  %2 = fcmp olt double %0, 0.000000e+00, !dbg !3241
  %3 = select i1 %2, double -5.000000e-01, double 5.000000e-01, !dbg !3242
  tail call void @llvm.dbg.value(metadata double %3, metadata !573, metadata !DIExpression()), !dbg !3240
  %4 = tail call double @llvm.fabs.f64(double %0), !dbg !3243
  tail call void @llvm.dbg.value(metadata double %4, metadata !574, metadata !DIExpression()), !dbg !3240
  %5 = fcmp olt double %4, 2.200000e+01, !dbg !3244
  br i1 %5, label %6, label %23, !dbg !3245

6:                                                ; preds = %1
  %7 = fcmp olt double %4, 0x3E30000000000000, !dbg !3246
  br i1 %7, label %37, label %8, !dbg !3248

8:                                                ; preds = %6
  %9 = tail call double @pts_ieee754_expm1(double noundef %4), !dbg !3249
  tail call void @llvm.dbg.value(metadata double %9, metadata !575, metadata !DIExpression()), !dbg !3250
  %10 = fcmp olt double %4, 1.000000e+00, !dbg !3251
  %11 = fadd double %9, 1.000000e+00, !dbg !3250
  br i1 %10, label %12, label %17, !dbg !3253

12:                                               ; preds = %8
  %13 = fneg double %9, !dbg !3254
  %14 = fmul double %9, %13, !dbg !3254
  %15 = fdiv double %14, %11, !dbg !3254
  %16 = tail call double @llvm.fmuladd.f64(double %9, double 2.000000e+00, double %15), !dbg !3254
  br label %20, !dbg !3256

17:                                               ; preds = %8
  %18 = fdiv double %9, %11, !dbg !3257
  %19 = fadd double %9, %18, !dbg !3258
  br label %20, !dbg !3259

20:                                               ; preds = %17, %12
  %21 = phi double [ %16, %12 ], [ %19, %17 ]
  %22 = fmul double %3, %21, !dbg !3250
  br label %37

23:                                               ; preds = %1
  %24 = fcmp olt double %4, 0x40862E4200000000, !dbg !3260
  br i1 %24, label %25, label %28, !dbg !3262

25:                                               ; preds = %23
  %26 = tail call double @pts_ieee754_exp(double noundef %4), !dbg !3263
  %27 = fmul double %3, %26, !dbg !3264
  br label %37, !dbg !3265

28:                                               ; preds = %23
  %29 = fcmp ugt double %4, 0x408633CE8FB9F87D, !dbg !3266
  br i1 %29, label %35, label %30, !dbg !3267

30:                                               ; preds = %28
  %31 = fmul double %4, 5.000000e-01, !dbg !3268
  %32 = tail call double @pts_ieee754_exp(double noundef %31), !dbg !3269
  tail call void @llvm.dbg.value(metadata double %32, metadata !578, metadata !DIExpression()), !dbg !3270
  %33 = fmul double %3, %32, !dbg !3271
  tail call void @llvm.dbg.value(metadata double %33, metadata !581, metadata !DIExpression()), !dbg !3270
  %34 = fmul double %32, %33, !dbg !3272
  br label %37

35:                                               ; preds = %28
  %36 = fmul double %0, 0x7FAC7B1F3CAC7433, !dbg !3273
  br label %37, !dbg !3274

37:                                               ; preds = %6, %35, %30, %25, %20
  %38 = phi double [ %22, %20 ], [ %27, %25 ], [ %34, %30 ], [ %36, %35 ], [ %0, %6 ], !dbg !3240
  ret double %38, !dbg !3275
}

; Function Attrs: mustprogress nofree norecurse nounwind ssp willreturn uwtable(sync)
define double @pts_ieee754_tanh(double noundef %0) local_unnamed_addr #7 !dbg !590 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !592, metadata !DIExpression()), !dbg !3276
  tail call void @llvm.dbg.value(metadata double %0, metadata !872, metadata !DIExpression()), !dbg !3277
  %2 = bitcast double %0 to i64, !dbg !3279
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !877, metadata !DIExpression()), !dbg !3277
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !597, metadata !DIExpression()), !dbg !3280
  %3 = lshr i64 %2, 32, !dbg !3281
  %4 = trunc i64 %3 to i32, !dbg !3281
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !595, metadata !DIExpression()), !dbg !3276
  %5 = and i32 %4, 2147483647, !dbg !3282
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !596, metadata !DIExpression()), !dbg !3276
  %6 = icmp ugt i32 %5, 2146435071, !dbg !3283
  br i1 %6, label %7, label %14, !dbg !3285

7:                                                ; preds = %1
  %8 = icmp sgt i64 %2, -1, !dbg !3286
  %9 = fdiv double 1.000000e+00, %0, !dbg !3289
  br i1 %8, label %10, label %12, !dbg !3290

10:                                               ; preds = %7
  %11 = fadd double %9, 1.000000e+00, !dbg !3291
  br label %44, !dbg !3292

12:                                               ; preds = %7
  %13 = fadd double %9, -1.000000e+00, !dbg !3293
  br label %44, !dbg !3294

14:                                               ; preds = %1
  %15 = icmp ult i32 %5, 1077280768, !dbg !3295
  br i1 %15, label %16, label %36, !dbg !3297

16:                                               ; preds = %14
  %17 = icmp ult i32 %5, 1043333120, !dbg !3298
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 1.000000e+00
  %20 = and i1 %19, %17, !dbg !3301
  br i1 %20, label %44, label %21, !dbg !3301

21:                                               ; preds = %16
  %22 = icmp ugt i32 %5, 1072693247, !dbg !3302
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !3304
  br i1 %22, label %24, label %30, !dbg !3305

24:                                               ; preds = %21
  %25 = fmul double %23, 2.000000e+00, !dbg !3306
  %26 = tail call double @pts_ieee754_expm1(double noundef %25), !dbg !3308
  tail call void @llvm.dbg.value(metadata double %26, metadata !593, metadata !DIExpression()), !dbg !3276
  %27 = fadd double %26, 2.000000e+00, !dbg !3309
  %28 = fdiv double 2.000000e+00, %27, !dbg !3310
  %29 = fsub double 1.000000e+00, %28, !dbg !3311
  tail call void @llvm.dbg.value(metadata double %29, metadata !594, metadata !DIExpression()), !dbg !3276
  br label %39, !dbg !3312

30:                                               ; preds = %21
  %31 = fmul double %23, -2.000000e+00, !dbg !3313
  %32 = tail call double @pts_ieee754_expm1(double noundef %31), !dbg !3315
  tail call void @llvm.dbg.value(metadata double %32, metadata !593, metadata !DIExpression()), !dbg !3276
  %33 = fneg double %32, !dbg !3316
  %34 = fadd double %32, 2.000000e+00, !dbg !3317
  %35 = fdiv double %33, %34, !dbg !3318
  tail call void @llvm.dbg.value(metadata double %35, metadata !594, metadata !DIExpression()), !dbg !3276
  br label %39

36:                                               ; preds = %14
  %37 = load volatile double, ptr @pts_ieee754_tanh.tiny, align 8, !dbg !3319, !tbaa !1436
  %38 = fsub double 1.000000e+00, %37, !dbg !3321
  tail call void @llvm.dbg.value(metadata double %38, metadata !594, metadata !DIExpression()), !dbg !3276
  br label %39

39:                                               ; preds = %24, %30, %36
  %40 = phi double [ %29, %24 ], [ %35, %30 ], [ %38, %36 ], !dbg !3322
  tail call void @llvm.dbg.value(metadata double %40, metadata !594, metadata !DIExpression()), !dbg !3276
  %41 = fneg double %40, !dbg !3323
  %42 = icmp slt i64 %2, 0, !dbg !3323
  %43 = select i1 %42, double %41, double %40, !dbg !3323
  br label %44, !dbg !3324

44:                                               ; preds = %16, %39, %12, %10
  %45 = phi double [ %11, %10 ], [ %13, %12 ], [ %43, %39 ], [ %0, %16 ], !dbg !3276
  ret double %45, !dbg !3325
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #1

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !3326 double @scalbn(double noundef, i32 noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #9

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.vector.reduce.fadd.v2f64(double, <2 x double>) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v4i32(<4 x i32>) #9

attributes #0 = { mustprogress nofree norecurse nosync nounwind ssp willreturn memory(none) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { mustprogress nofree norecurse nounwind ssp willreturn memory(inaccessiblemem: readwrite) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #4 = { mustprogress nofree norecurse nounwind ssp willreturn memory(readwrite, argmem: none) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #5 = { nofree nosync nounwind ssp memory(none) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #6 = { nofree nosync nounwind ssp memory(argmem: write) uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #7 = { mustprogress nofree norecurse nounwind ssp willreturn uwtable(sync) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #8 = { mustprogress nofree nosync nounwind willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="apple-m1" "target-features"="+aes,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fullfp16,+jsconv,+lse,+neon,+pauth,+ras,+rcpc,+rdm,+sha2,+sha3,+v8.1a,+v8.2a,+v8.3a,+v8.4a,+v8.5a,+v8a,+zcm,+zcz" }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { nounwind }
attributes #12 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!7}
!llvm.module.flags = !{!864, !865, !866, !867, !868, !869}
!llvm.ident = !{!870}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "atanhi", scope: !2, file: !3, line: 1148, type: !156, isLocal: true, isDefinition: true)
!2 = distinct !DISubprogram(name: "pts_ieee754_atan", scope: !3, file: !3, line: 1147, type: !4, scopeLine: 1147, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !848)
!3 = !DIFile(filename: "../src/ieee754_head.c", directory: "/tmp/pts-h36/repro/clang_on")
!4 = !DISubroutineType(types: !5)
!5 = !{!6, !6}
!6 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!7 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !8, globals: !19, splitDebugInlining: false, nameTableKind: Apple, sysroot: "/")
!8 = !{!9, !12, !15, !16, !18, !6}
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !10, line: 198, baseType: !11)
!10 = !DIFile(filename: "/usr/lib/llvm-18/lib/clang/18/include/stdint.h", directory: "")
!11 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !6)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !10, line: 98, baseType: !17)
!17 = !DIBasicType(name: "unsigned long long", size: 64, encoding: DW_ATE_unsigned)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !10, line: 193, baseType: !15)
!19 = !{!20, !48, !50, !52, !54, !56, !58, !60, !62, !64, !66, !68, !70, !72, !74, !84, !86, !111, !113, !115, !117, !119, !121, !123, !125, !127, !129, !131, !133, !135, !137, !139, !150, !152, !0, !154, !159, !164, !166, !168, !189, !191, !193, !195, !197, !199, !229, !234, !236, !238, !240, !242, !244, !246, !248, !250, !252, !254, !256, !258, !260, !262, !275, !277, !279, !306, !308, !310, !312, !314, !316, !318, !320, !322, !324, !326, !360, !362, !364, !366, !368, !370, !372, !374, !376, !378, !380, !408, !410, !412, !435, !437, !439, !441, !481, !483, !485, !487, !489, !491, !493, !495, !497, !499, !501, !503, !531, !533, !535, !537, !539, !541, !543, !562, !564, !566, !568, !582, !584, !586, !588, !599, !601, !603, !605, !625, !627, !629, !631, !633, !635, !637, !686, !691, !693, !695, !697, !699, !701, !703, !705, !707, !709, !711, !750, !755, !757, !759, !761, !763, !778, !780, !782, !784, !786, !788, !790, !792, !794, !796, !798, !800, !802, !804}
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "one", scope: !22, file: !3, line: 895, type: !47, isLocal: true, isDefinition: true)
!22 = distinct !DISubprogram(name: "pts_ieee754_acos", scope: !3, file: !3, line: 893, type: !4, scopeLine: 893, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !23)
!23 = !{!24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !37, !40, !42}
!24 = !DILocalVariable(name: "x", arg: 1, scope: !22, file: !3, line: 893, type: !6)
!25 = !DILocalVariable(name: "z", scope: !22, file: !3, line: 910, type: !6)
!26 = !DILocalVariable(name: "p", scope: !22, file: !3, line: 910, type: !6)
!27 = !DILocalVariable(name: "q", scope: !22, file: !3, line: 910, type: !6)
!28 = !DILocalVariable(name: "r", scope: !22, file: !3, line: 910, type: !6)
!29 = !DILocalVariable(name: "w", scope: !22, file: !3, line: 910, type: !6)
!30 = !DILocalVariable(name: "s", scope: !22, file: !3, line: 910, type: !6)
!31 = !DILocalVariable(name: "c", scope: !22, file: !3, line: 910, type: !6)
!32 = !DILocalVariable(name: "df", scope: !22, file: !3, line: 910, type: !6)
!33 = !DILocalVariable(name: "hx", scope: !22, file: !3, line: 911, type: !18)
!34 = !DILocalVariable(name: "ix", scope: !22, file: !3, line: 911, type: !18)
!35 = !DILocalVariable(name: "bits", scope: !36, file: !3, line: 912, type: !16)
!36 = distinct !DILexicalBlock(scope: !22, file: !3, line: 912, column: 3)
!37 = !DILocalVariable(name: "lx", scope: !38, file: !3, line: 915, type: !9)
!38 = distinct !DILexicalBlock(scope: !39, file: !3, line: 914, column: 25)
!39 = distinct !DILexicalBlock(scope: !22, file: !3, line: 914, column: 7)
!40 = !DILocalVariable(name: "bits", scope: !41, file: !3, line: 916, type: !16)
!41 = distinct !DILexicalBlock(scope: !38, file: !3, line: 916, column: 5)
!42 = !DILocalVariable(name: "bits", scope: !43, file: !3, line: 944, type: !16)
!43 = distinct !DILexicalBlock(scope: !44, file: !3, line: 944, column: 5)
!44 = distinct !DILexicalBlock(scope: !45, file: !3, line: 940, column: 10)
!45 = distinct !DILexicalBlock(scope: !46, file: !3, line: 932, column: 14)
!46 = distinct !DILexicalBlock(scope: !22, file: !3, line: 925, column: 7)
!47 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "pi", scope: !22, file: !3, line: 896, type: !47, isLocal: true, isDefinition: true)
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !22, file: !3, line: 897, type: !47, isLocal: true, isDefinition: true)
!52 = !DIGlobalVariableExpression(var: !53, expr: !DIExpression())
!53 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !22, file: !3, line: 898, type: !47, isLocal: true, isDefinition: true)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(name: "pS0", scope: !22, file: !3, line: 899, type: !47, isLocal: true, isDefinition: true)
!56 = !DIGlobalVariableExpression(var: !57, expr: !DIExpression())
!57 = distinct !DIGlobalVariable(name: "pS1", scope: !22, file: !3, line: 900, type: !47, isLocal: true, isDefinition: true)
!58 = !DIGlobalVariableExpression(var: !59, expr: !DIExpression())
!59 = distinct !DIGlobalVariable(name: "pS2", scope: !22, file: !3, line: 901, type: !47, isLocal: true, isDefinition: true)
!60 = !DIGlobalVariableExpression(var: !61, expr: !DIExpression())
!61 = distinct !DIGlobalVariable(name: "pS3", scope: !22, file: !3, line: 902, type: !47, isLocal: true, isDefinition: true)
!62 = !DIGlobalVariableExpression(var: !63, expr: !DIExpression())
!63 = distinct !DIGlobalVariable(name: "pS4", scope: !22, file: !3, line: 903, type: !47, isLocal: true, isDefinition: true)
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(name: "pS5", scope: !22, file: !3, line: 904, type: !47, isLocal: true, isDefinition: true)
!66 = !DIGlobalVariableExpression(var: !67, expr: !DIExpression())
!67 = distinct !DIGlobalVariable(name: "qS1", scope: !22, file: !3, line: 905, type: !47, isLocal: true, isDefinition: true)
!68 = !DIGlobalVariableExpression(var: !69, expr: !DIExpression())
!69 = distinct !DIGlobalVariable(name: "qS2", scope: !22, file: !3, line: 906, type: !47, isLocal: true, isDefinition: true)
!70 = !DIGlobalVariableExpression(var: !71, expr: !DIExpression())
!71 = distinct !DIGlobalVariable(name: "qS3", scope: !22, file: !3, line: 907, type: !47, isLocal: true, isDefinition: true)
!72 = !DIGlobalVariableExpression(var: !73, expr: !DIExpression())
!73 = distinct !DIGlobalVariable(name: "qS4", scope: !22, file: !3, line: 908, type: !47, isLocal: true, isDefinition: true)
!74 = !DIGlobalVariableExpression(var: !75, expr: !DIExpression())
!75 = distinct !DIGlobalVariable(name: "one", scope: !76, file: !3, line: 969, type: !47, isLocal: true, isDefinition: true)
!76 = distinct !DISubprogram(name: "pts_ieee754_acosh", scope: !3, file: !3, line: 967, type: !4, scopeLine: 967, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !77)
!77 = !{!78, !79, !80, !81, !82}
!78 = !DILocalVariable(name: "x", arg: 1, scope: !76, file: !3, line: 967, type: !6)
!79 = !DILocalVariable(name: "t", scope: !76, file: !3, line: 971, type: !6)
!80 = !DILocalVariable(name: "hx", scope: !76, file: !3, line: 972, type: !18)
!81 = !DILocalVariable(name: "lx", scope: !76, file: !3, line: 973, type: !9)
!82 = !DILocalVariable(name: "bits", scope: !83, file: !3, line: 974, type: !16)
!83 = distinct !DILexicalBlock(scope: !76, file: !3, line: 974, column: 3)
!84 = !DIGlobalVariableExpression(var: !85, expr: !DIExpression())
!85 = distinct !DIGlobalVariable(name: "ln2", scope: !76, file: !3, line: 970, type: !47, isLocal: true, isDefinition: true)
!86 = !DIGlobalVariableExpression(var: !87, expr: !DIExpression())
!87 = distinct !DIGlobalVariable(name: "one", scope: !88, file: !3, line: 1024, type: !47, isLocal: true, isDefinition: true)
!88 = distinct !DISubprogram(name: "pts_ieee754_asin", scope: !3, file: !3, line: 1022, type: !4, scopeLine: 1022, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !89)
!89 = !{!90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !102, !105, !107}
!90 = !DILocalVariable(name: "x", arg: 1, scope: !88, file: !3, line: 1022, type: !6)
!91 = !DILocalVariable(name: "t", scope: !88, file: !3, line: 1041, type: !6)
!92 = !DILocalVariable(name: "w", scope: !88, file: !3, line: 1041, type: !6)
!93 = !DILocalVariable(name: "p", scope: !88, file: !3, line: 1041, type: !6)
!94 = !DILocalVariable(name: "q", scope: !88, file: !3, line: 1041, type: !6)
!95 = !DILocalVariable(name: "c", scope: !88, file: !3, line: 1041, type: !6)
!96 = !DILocalVariable(name: "r", scope: !88, file: !3, line: 1041, type: !6)
!97 = !DILocalVariable(name: "s", scope: !88, file: !3, line: 1041, type: !6)
!98 = !DILocalVariable(name: "hx", scope: !88, file: !3, line: 1042, type: !18)
!99 = !DILocalVariable(name: "ix", scope: !88, file: !3, line: 1042, type: !18)
!100 = !DILocalVariable(name: "bits", scope: !101, file: !3, line: 1045, type: !16)
!101 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1045, column: 3)
!102 = !DILocalVariable(name: "lx", scope: !103, file: !3, line: 1048, type: !9)
!103 = distinct !DILexicalBlock(scope: !104, file: !3, line: 1047, column: 25)
!104 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1047, column: 7)
!105 = !DILocalVariable(name: "bits", scope: !106, file: !3, line: 1049, type: !16)
!106 = distinct !DILexicalBlock(scope: !103, file: !3, line: 1049, column: 5)
!107 = !DILocalVariable(name: "bits", scope: !108, file: !3, line: 1076, type: !16)
!108 = distinct !DILexicalBlock(scope: !109, file: !3, line: 1076, column: 5)
!109 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1074, column: 10)
!110 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1071, column: 7)
!111 = !DIGlobalVariableExpression(var: !112, expr: !DIExpression())
!112 = distinct !DIGlobalVariable(name: "huge", scope: !88, file: !3, line: 1025, type: !47, isLocal: true, isDefinition: true)
!113 = !DIGlobalVariableExpression(var: !114, expr: !DIExpression())
!114 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !88, file: !3, line: 1026, type: !47, isLocal: true, isDefinition: true)
!115 = !DIGlobalVariableExpression(var: !116, expr: !DIExpression())
!116 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !88, file: !3, line: 1027, type: !47, isLocal: true, isDefinition: true)
!117 = !DIGlobalVariableExpression(var: !118, expr: !DIExpression())
!118 = distinct !DIGlobalVariable(name: "pio4_hi", scope: !88, file: !3, line: 1028, type: !47, isLocal: true, isDefinition: true)
!119 = !DIGlobalVariableExpression(var: !120, expr: !DIExpression())
!120 = distinct !DIGlobalVariable(name: "pS0", scope: !88, file: !3, line: 1030, type: !47, isLocal: true, isDefinition: true)
!121 = !DIGlobalVariableExpression(var: !122, expr: !DIExpression())
!122 = distinct !DIGlobalVariable(name: "pS1", scope: !88, file: !3, line: 1031, type: !47, isLocal: true, isDefinition: true)
!123 = !DIGlobalVariableExpression(var: !124, expr: !DIExpression())
!124 = distinct !DIGlobalVariable(name: "pS2", scope: !88, file: !3, line: 1032, type: !47, isLocal: true, isDefinition: true)
!125 = !DIGlobalVariableExpression(var: !126, expr: !DIExpression())
!126 = distinct !DIGlobalVariable(name: "pS3", scope: !88, file: !3, line: 1033, type: !47, isLocal: true, isDefinition: true)
!127 = !DIGlobalVariableExpression(var: !128, expr: !DIExpression())
!128 = distinct !DIGlobalVariable(name: "pS4", scope: !88, file: !3, line: 1034, type: !47, isLocal: true, isDefinition: true)
!129 = !DIGlobalVariableExpression(var: !130, expr: !DIExpression())
!130 = distinct !DIGlobalVariable(name: "pS5", scope: !88, file: !3, line: 1035, type: !47, isLocal: true, isDefinition: true)
!131 = !DIGlobalVariableExpression(var: !132, expr: !DIExpression())
!132 = distinct !DIGlobalVariable(name: "qS1", scope: !88, file: !3, line: 1036, type: !47, isLocal: true, isDefinition: true)
!133 = !DIGlobalVariableExpression(var: !134, expr: !DIExpression())
!134 = distinct !DIGlobalVariable(name: "qS2", scope: !88, file: !3, line: 1037, type: !47, isLocal: true, isDefinition: true)
!135 = !DIGlobalVariableExpression(var: !136, expr: !DIExpression())
!136 = distinct !DIGlobalVariable(name: "qS3", scope: !88, file: !3, line: 1038, type: !47, isLocal: true, isDefinition: true)
!137 = !DIGlobalVariableExpression(var: !138, expr: !DIExpression())
!138 = distinct !DIGlobalVariable(name: "qS4", scope: !88, file: !3, line: 1039, type: !47, isLocal: true, isDefinition: true)
!139 = !DIGlobalVariableExpression(var: !140, expr: !DIExpression())
!140 = distinct !DIGlobalVariable(name: "one", scope: !141, file: !3, line: 1100, type: !47, isLocal: true, isDefinition: true)
!141 = distinct !DISubprogram(name: "pts_ieee754_asinh", scope: !3, file: !3, line: 1098, type: !4, scopeLine: 1098, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !142)
!142 = !{!143, !144, !145, !146, !147, !148}
!143 = !DILocalVariable(name: "x", arg: 1, scope: !141, file: !3, line: 1098, type: !6)
!144 = !DILocalVariable(name: "t", scope: !141, file: !3, line: 1104, type: !6)
!145 = !DILocalVariable(name: "w", scope: !141, file: !3, line: 1104, type: !6)
!146 = !DILocalVariable(name: "hx", scope: !141, file: !3, line: 1105, type: !18)
!147 = !DILocalVariable(name: "ix", scope: !141, file: !3, line: 1105, type: !18)
!148 = !DILocalVariable(name: "bits", scope: !149, file: !3, line: 1106, type: !16)
!149 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1106, column: 3)
!150 = !DIGlobalVariableExpression(var: !151, expr: !DIExpression())
!151 = distinct !DIGlobalVariable(name: "ln2", scope: !141, file: !3, line: 1101, type: !47, isLocal: true, isDefinition: true)
!152 = !DIGlobalVariableExpression(var: !153, expr: !DIExpression())
!153 = distinct !DIGlobalVariable(name: "huge", scope: !141, file: !3, line: 1102, type: !47, isLocal: true, isDefinition: true)
!154 = !DIGlobalVariableExpression(var: !155, expr: !DIExpression())
!155 = distinct !DIGlobalVariable(name: "atanlo", scope: !2, file: !3, line: 1155, type: !156, isLocal: true, isDefinition: true)
!156 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 256, elements: !157)
!157 = !{!158}
!158 = !DISubrange(count: 4)
!159 = !DIGlobalVariableExpression(var: !160, expr: !DIExpression())
!160 = distinct !DIGlobalVariable(name: "aT", scope: !2, file: !3, line: 1162, type: !161, isLocal: true, isDefinition: true)
!161 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 704, elements: !162)
!162 = !{!163}
!163 = !DISubrange(count: 11)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(name: "one", scope: !2, file: !3, line: 1176, type: !47, isLocal: true, isDefinition: true)
!166 = !DIGlobalVariableExpression(var: !167, expr: !DIExpression())
!167 = distinct !DIGlobalVariable(name: "huge", scope: !2, file: !3, line: 1176, type: !47, isLocal: true, isDefinition: true)
!168 = !DIGlobalVariableExpression(var: !169, expr: !DIExpression())
!169 = distinct !DIGlobalVariable(name: "tiny", scope: !170, file: !3, line: 1260, type: !14, isLocal: true, isDefinition: true)
!170 = distinct !DISubprogram(name: "pts_ieee754_atan2", scope: !3, file: !3, line: 1259, type: !171, scopeLine: 1259, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !173)
!171 = !DISubroutineType(types: !172)
!172 = !{!6, !6, !6}
!173 = !{!174, !175, !176, !177, !178, !179, !180, !181, !182, !183, !184, !185, !187}
!174 = !DILocalVariable(name: "y", arg: 1, scope: !170, file: !3, line: 1259, type: !6)
!175 = !DILocalVariable(name: "x", arg: 2, scope: !170, file: !3, line: 1259, type: !6)
!176 = !DILocalVariable(name: "z", scope: !170, file: !3, line: 1269, type: !6)
!177 = !DILocalVariable(name: "k", scope: !170, file: !3, line: 1270, type: !18)
!178 = !DILocalVariable(name: "m", scope: !170, file: !3, line: 1270, type: !18)
!179 = !DILocalVariable(name: "hx", scope: !170, file: !3, line: 1270, type: !18)
!180 = !DILocalVariable(name: "hy", scope: !170, file: !3, line: 1270, type: !18)
!181 = !DILocalVariable(name: "ix", scope: !170, file: !3, line: 1270, type: !18)
!182 = !DILocalVariable(name: "iy", scope: !170, file: !3, line: 1270, type: !18)
!183 = !DILocalVariable(name: "lx", scope: !170, file: !3, line: 1271, type: !9)
!184 = !DILocalVariable(name: "ly", scope: !170, file: !3, line: 1271, type: !9)
!185 = !DILocalVariable(name: "bits", scope: !186, file: !3, line: 1273, type: !16)
!186 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1273, column: 3)
!187 = !DILocalVariable(name: "bits", scope: !188, file: !3, line: 1275, type: !16)
!188 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1275, column: 3)
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(name: "zero", scope: !170, file: !3, line: 1262, type: !47, isLocal: true, isDefinition: true)
!191 = !DIGlobalVariableExpression(var: !192, expr: !DIExpression())
!192 = distinct !DIGlobalVariable(name: "pi_o_4", scope: !170, file: !3, line: 1263, type: !47, isLocal: true, isDefinition: true)
!193 = !DIGlobalVariableExpression(var: !194, expr: !DIExpression())
!194 = distinct !DIGlobalVariable(name: "pi_o_2", scope: !170, file: !3, line: 1264, type: !47, isLocal: true, isDefinition: true)
!195 = !DIGlobalVariableExpression(var: !196, expr: !DIExpression())
!196 = distinct !DIGlobalVariable(name: "pi", scope: !170, file: !3, line: 1265, type: !47, isLocal: true, isDefinition: true)
!197 = !DIGlobalVariableExpression(var: !198, expr: !DIExpression())
!198 = distinct !DIGlobalVariable(name: "pi_lo", scope: !170, file: !3, line: 1266, type: !14, isLocal: true, isDefinition: true)
!199 = !DIGlobalVariableExpression(var: !200, expr: !DIExpression())
!200 = distinct !DIGlobalVariable(name: "one", scope: !201, file: !3, line: 1476, type: !47, isLocal: true, isDefinition: true)
!201 = distinct !DISubprogram(name: "pts_ieee754_exp", scope: !3, file: !3, line: 1474, type: !4, scopeLine: 1474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !202)
!202 = !{!203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !215, !220, !222, !226}
!203 = !DILocalVariable(name: "x", arg: 1, scope: !201, file: !3, line: 1474, type: !6)
!204 = !DILocalVariable(name: "y", scope: !201, file: !3, line: 1497, type: !6)
!205 = !DILocalVariable(name: "hi", scope: !201, file: !3, line: 1497, type: !6)
!206 = !DILocalVariable(name: "lo", scope: !201, file: !3, line: 1497, type: !6)
!207 = !DILocalVariable(name: "c", scope: !201, file: !3, line: 1497, type: !6)
!208 = !DILocalVariable(name: "t", scope: !201, file: !3, line: 1497, type: !6)
!209 = !DILocalVariable(name: "twopk", scope: !201, file: !3, line: 1497, type: !6)
!210 = !DILocalVariable(name: "k", scope: !201, file: !3, line: 1498, type: !18)
!211 = !DILocalVariable(name: "xsb", scope: !201, file: !3, line: 1498, type: !18)
!212 = !DILocalVariable(name: "hx", scope: !201, file: !3, line: 1499, type: !9)
!213 = !DILocalVariable(name: "bits", scope: !214, file: !3, line: 1501, type: !16)
!214 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1501, column: 3)
!215 = !DILocalVariable(name: "lx", scope: !216, file: !3, line: 1508, type: !9)
!216 = distinct !DILexicalBlock(scope: !217, file: !3, line: 1507, column: 27)
!217 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1507, column: 9)
!218 = distinct !DILexicalBlock(scope: !219, file: !3, line: 1506, column: 25)
!219 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1506, column: 7)
!220 = !DILocalVariable(name: "bits", scope: !221, file: !3, line: 1509, type: !16)
!221 = distinct !DILexicalBlock(scope: !216, file: !3, line: 1509, column: 7)
!222 = !DILocalVariable(name: "bits", scope: !223, file: !3, line: 1546, type: !16)
!223 = distinct !DILexicalBlock(scope: !224, file: !3, line: 1546, column: 5)
!224 = distinct !DILexicalBlock(scope: !225, file: !3, line: 1545, column: 19)
!225 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1545, column: 7)
!226 = !DILocalVariable(name: "bits", scope: !227, file: !3, line: 1550, type: !16)
!227 = distinct !DILexicalBlock(scope: !228, file: !3, line: 1550, column: 5)
!228 = distinct !DILexicalBlock(scope: !225, file: !3, line: 1549, column: 10)
!229 = !DIGlobalVariableExpression(var: !230, expr: !DIExpression())
!230 = distinct !DIGlobalVariable(name: "halF", scope: !201, file: !3, line: 1477, type: !231, isLocal: true, isDefinition: true)
!231 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 128, elements: !232)
!232 = !{!233}
!233 = !DISubrange(count: 2)
!234 = !DIGlobalVariableExpression(var: !235, expr: !DIExpression())
!235 = distinct !DIGlobalVariable(name: "o_threshold", scope: !201, file: !3, line: 1478, type: !47, isLocal: true, isDefinition: true)
!236 = !DIGlobalVariableExpression(var: !237, expr: !DIExpression())
!237 = distinct !DIGlobalVariable(name: "u_threshold", scope: !201, file: !3, line: 1479, type: !47, isLocal: true, isDefinition: true)
!238 = !DIGlobalVariableExpression(var: !239, expr: !DIExpression())
!239 = distinct !DIGlobalVariable(name: "ln2HI", scope: !201, file: !3, line: 1480, type: !231, isLocal: true, isDefinition: true)
!240 = !DIGlobalVariableExpression(var: !241, expr: !DIExpression())
!241 = distinct !DIGlobalVariable(name: "ln2LO", scope: !201, file: !3, line: 1482, type: !231, isLocal: true, isDefinition: true)
!242 = !DIGlobalVariableExpression(var: !243, expr: !DIExpression())
!243 = distinct !DIGlobalVariable(name: "invln2", scope: !201, file: !3, line: 1484, type: !47, isLocal: true, isDefinition: true)
!244 = !DIGlobalVariableExpression(var: !245, expr: !DIExpression())
!245 = distinct !DIGlobalVariable(name: "P1", scope: !201, file: !3, line: 1485, type: !47, isLocal: true, isDefinition: true)
!246 = !DIGlobalVariableExpression(var: !247, expr: !DIExpression())
!247 = distinct !DIGlobalVariable(name: "P2", scope: !201, file: !3, line: 1486, type: !47, isLocal: true, isDefinition: true)
!248 = !DIGlobalVariableExpression(var: !249, expr: !DIExpression())
!249 = distinct !DIGlobalVariable(name: "P3", scope: !201, file: !3, line: 1487, type: !47, isLocal: true, isDefinition: true)
!250 = !DIGlobalVariableExpression(var: !251, expr: !DIExpression())
!251 = distinct !DIGlobalVariable(name: "P4", scope: !201, file: !3, line: 1488, type: !47, isLocal: true, isDefinition: true)
!252 = !DIGlobalVariableExpression(var: !253, expr: !DIExpression())
!253 = distinct !DIGlobalVariable(name: "P5", scope: !201, file: !3, line: 1489, type: !47, isLocal: true, isDefinition: true)
!254 = !DIGlobalVariableExpression(var: !255, expr: !DIExpression())
!255 = distinct !DIGlobalVariable(name: "E", scope: !201, file: !3, line: 1490, type: !47, isLocal: true, isDefinition: true)
!256 = !DIGlobalVariableExpression(var: !257, expr: !DIExpression())
!257 = distinct !DIGlobalVariable(name: "huge", scope: !201, file: !3, line: 1493, type: !14, isLocal: true, isDefinition: true)
!258 = !DIGlobalVariableExpression(var: !259, expr: !DIExpression())
!259 = distinct !DIGlobalVariable(name: "twom1000", scope: !201, file: !3, line: 1494, type: !14, isLocal: true, isDefinition: true)
!260 = !DIGlobalVariableExpression(var: !261, expr: !DIExpression())
!261 = distinct !DIGlobalVariable(name: "two1023", scope: !201, file: !3, line: 1495, type: !14, isLocal: true, isDefinition: true)
!262 = !DIGlobalVariableExpression(var: !263, expr: !DIExpression())
!263 = distinct !DIGlobalVariable(name: "one", scope: !264, file: !3, line: 1585, type: !47, isLocal: true, isDefinition: true)
!264 = distinct !DISubprogram(name: "pts_ieee754_atanh", scope: !3, file: !3, line: 1584, type: !4, scopeLine: 1584, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !265)
!265 = !{!266, !267, !268, !269, !270, !271, !273}
!266 = !DILocalVariable(name: "x", arg: 1, scope: !264, file: !3, line: 1584, type: !6)
!267 = !DILocalVariable(name: "t", scope: !264, file: !3, line: 1588, type: !6)
!268 = !DILocalVariable(name: "hx", scope: !264, file: !3, line: 1589, type: !18)
!269 = !DILocalVariable(name: "ix", scope: !264, file: !3, line: 1589, type: !18)
!270 = !DILocalVariable(name: "lx", scope: !264, file: !3, line: 1590, type: !9)
!271 = !DILocalVariable(name: "bits", scope: !272, file: !3, line: 1591, type: !16)
!272 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1591, column: 3)
!273 = !DILocalVariable(name: "bits", scope: !274, file: !3, line: 1602, type: !16)
!274 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1602, column: 3)
!275 = !DIGlobalVariableExpression(var: !276, expr: !DIExpression())
!276 = distinct !DIGlobalVariable(name: "huge", scope: !264, file: !3, line: 1585, type: !47, isLocal: true, isDefinition: true)
!277 = !DIGlobalVariableExpression(var: !278, expr: !DIExpression())
!278 = distinct !DIGlobalVariable(name: "zero", scope: !264, file: !3, line: 1586, type: !47, isLocal: true, isDefinition: true)
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !281, file: !3, line: 1667, type: !47, isLocal: true, isDefinition: true)
!281 = distinct !DISubprogram(name: "pts_ieee754_log", scope: !3, file: !3, line: 1665, type: !4, scopeLine: 1665, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !282)
!282 = !{!283, !284, !285, !286, !287, !288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !298, !300, !304}
!283 = !DILocalVariable(name: "x", arg: 1, scope: !281, file: !3, line: 1665, type: !6)
!284 = !DILocalVariable(name: "hfsq", scope: !281, file: !3, line: 1680, type: !6)
!285 = !DILocalVariable(name: "f", scope: !281, file: !3, line: 1680, type: !6)
!286 = !DILocalVariable(name: "s", scope: !281, file: !3, line: 1680, type: !6)
!287 = !DILocalVariable(name: "z", scope: !281, file: !3, line: 1680, type: !6)
!288 = !DILocalVariable(name: "R", scope: !281, file: !3, line: 1680, type: !6)
!289 = !DILocalVariable(name: "w", scope: !281, file: !3, line: 1680, type: !6)
!290 = !DILocalVariable(name: "t1", scope: !281, file: !3, line: 1680, type: !6)
!291 = !DILocalVariable(name: "t2", scope: !281, file: !3, line: 1680, type: !6)
!292 = !DILocalVariable(name: "dk", scope: !281, file: !3, line: 1680, type: !6)
!293 = !DILocalVariable(name: "k", scope: !281, file: !3, line: 1681, type: !18)
!294 = !DILocalVariable(name: "hx", scope: !281, file: !3, line: 1681, type: !18)
!295 = !DILocalVariable(name: "i", scope: !281, file: !3, line: 1681, type: !18)
!296 = !DILocalVariable(name: "j", scope: !281, file: !3, line: 1681, type: !18)
!297 = !DILocalVariable(name: "lx", scope: !281, file: !3, line: 1682, type: !9)
!298 = !DILocalVariable(name: "bits", scope: !299, file: !3, line: 1684, type: !16)
!299 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1684, column: 3)
!300 = !DILocalVariable(name: "bits", scope: !301, file: !3, line: 1696, type: !16)
!301 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1696, column: 5)
!302 = distinct !DILexicalBlock(scope: !303, file: !3, line: 1687, column: 24)
!303 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1687, column: 7)
!304 = !DILocalVariable(name: "bits", scope: !305, file: !3, line: 1702, type: !16)
!305 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1702, column: 3)
!306 = !DIGlobalVariableExpression(var: !307, expr: !DIExpression())
!307 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !281, file: !3, line: 1668, type: !47, isLocal: true, isDefinition: true)
!308 = !DIGlobalVariableExpression(var: !309, expr: !DIExpression())
!309 = distinct !DIGlobalVariable(name: "two54", scope: !281, file: !3, line: 1669, type: !47, isLocal: true, isDefinition: true)
!310 = !DIGlobalVariableExpression(var: !311, expr: !DIExpression())
!311 = distinct !DIGlobalVariable(name: "Lg1", scope: !281, file: !3, line: 1670, type: !47, isLocal: true, isDefinition: true)
!312 = !DIGlobalVariableExpression(var: !313, expr: !DIExpression())
!313 = distinct !DIGlobalVariable(name: "Lg2", scope: !281, file: !3, line: 1671, type: !47, isLocal: true, isDefinition: true)
!314 = !DIGlobalVariableExpression(var: !315, expr: !DIExpression())
!315 = distinct !DIGlobalVariable(name: "Lg3", scope: !281, file: !3, line: 1672, type: !47, isLocal: true, isDefinition: true)
!316 = !DIGlobalVariableExpression(var: !317, expr: !DIExpression())
!317 = distinct !DIGlobalVariable(name: "Lg4", scope: !281, file: !3, line: 1673, type: !47, isLocal: true, isDefinition: true)
!318 = !DIGlobalVariableExpression(var: !319, expr: !DIExpression())
!319 = distinct !DIGlobalVariable(name: "Lg5", scope: !281, file: !3, line: 1674, type: !47, isLocal: true, isDefinition: true)
!320 = !DIGlobalVariableExpression(var: !321, expr: !DIExpression())
!321 = distinct !DIGlobalVariable(name: "Lg6", scope: !281, file: !3, line: 1675, type: !47, isLocal: true, isDefinition: true)
!322 = !DIGlobalVariableExpression(var: !323, expr: !DIExpression())
!323 = distinct !DIGlobalVariable(name: "Lg7", scope: !281, file: !3, line: 1676, type: !47, isLocal: true, isDefinition: true)
!324 = !DIGlobalVariableExpression(var: !325, expr: !DIExpression())
!325 = distinct !DIGlobalVariable(name: "zero", scope: !281, file: !3, line: 1678, type: !47, isLocal: true, isDefinition: true)
!326 = !DIGlobalVariableExpression(var: !327, expr: !DIExpression())
!327 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !328, file: !3, line: 1812, type: !47, isLocal: true, isDefinition: true)
!328 = distinct !DISubprogram(name: "pts_ieee754_log1p", scope: !3, file: !3, line: 1810, type: !4, scopeLine: 1810, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !329)
!329 = !{!330, !331, !332, !333, !334, !335, !336, !337, !338, !339, !340, !341, !342, !344, !350, !353, !357}
!330 = !DILocalVariable(name: "x", arg: 1, scope: !328, file: !3, line: 1810, type: !6)
!331 = !DILocalVariable(name: "hfsq", scope: !328, file: !3, line: 1825, type: !6)
!332 = !DILocalVariable(name: "f", scope: !328, file: !3, line: 1825, type: !6)
!333 = !DILocalVariable(name: "c", scope: !328, file: !3, line: 1825, type: !6)
!334 = !DILocalVariable(name: "s", scope: !328, file: !3, line: 1825, type: !6)
!335 = !DILocalVariable(name: "z", scope: !328, file: !3, line: 1825, type: !6)
!336 = !DILocalVariable(name: "R", scope: !328, file: !3, line: 1825, type: !6)
!337 = !DILocalVariable(name: "u", scope: !328, file: !3, line: 1825, type: !6)
!338 = !DILocalVariable(name: "k", scope: !328, file: !3, line: 1826, type: !18)
!339 = !DILocalVariable(name: "hx", scope: !328, file: !3, line: 1826, type: !18)
!340 = !DILocalVariable(name: "hu", scope: !328, file: !3, line: 1826, type: !18)
!341 = !DILocalVariable(name: "ax", scope: !328, file: !3, line: 1826, type: !18)
!342 = !DILocalVariable(name: "bits", scope: !343, file: !3, line: 1828, type: !16)
!343 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1828, column: 3)
!344 = !DILocalVariable(name: "bits", scope: !345, file: !3, line: 1856, type: !16)
!345 = distinct !DILexicalBlock(scope: !346, file: !3, line: 1856, column: 7)
!346 = distinct !DILexicalBlock(scope: !347, file: !3, line: 1854, column: 26)
!347 = distinct !DILexicalBlock(scope: !348, file: !3, line: 1854, column: 9)
!348 = distinct !DILexicalBlock(scope: !349, file: !3, line: 1853, column: 15)
!349 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1853, column: 7)
!350 = !DILocalVariable(name: "bits", scope: !351, file: !3, line: 1862, type: !16)
!351 = distinct !DILexicalBlock(scope: !352, file: !3, line: 1862, column: 7)
!352 = distinct !DILexicalBlock(scope: !347, file: !3, line: 1860, column: 12)
!353 = !DILocalVariable(name: "bits", scope: !354, file: !3, line: 1875, type: !16)
!354 = distinct !DILexicalBlock(scope: !355, file: !3, line: 1875, column: 7)
!355 = distinct !DILexicalBlock(scope: !356, file: !3, line: 1874, column: 23)
!356 = distinct !DILexicalBlock(scope: !348, file: !3, line: 1874, column: 9)
!357 = !DILocalVariable(name: "bits", scope: !358, file: !3, line: 1878, type: !16)
!358 = distinct !DILexicalBlock(scope: !359, file: !3, line: 1878, column: 7)
!359 = distinct !DILexicalBlock(scope: !356, file: !3, line: 1876, column: 12)
!360 = !DIGlobalVariableExpression(var: !361, expr: !DIExpression())
!361 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !328, file: !3, line: 1813, type: !47, isLocal: true, isDefinition: true)
!362 = !DIGlobalVariableExpression(var: !363, expr: !DIExpression())
!363 = distinct !DIGlobalVariable(name: "two54", scope: !328, file: !3, line: 1814, type: !47, isLocal: true, isDefinition: true)
!364 = !DIGlobalVariableExpression(var: !365, expr: !DIExpression())
!365 = distinct !DIGlobalVariable(name: "Lp1", scope: !328, file: !3, line: 1815, type: !47, isLocal: true, isDefinition: true)
!366 = !DIGlobalVariableExpression(var: !367, expr: !DIExpression())
!367 = distinct !DIGlobalVariable(name: "Lp2", scope: !328, file: !3, line: 1816, type: !47, isLocal: true, isDefinition: true)
!368 = !DIGlobalVariableExpression(var: !369, expr: !DIExpression())
!369 = distinct !DIGlobalVariable(name: "Lp3", scope: !328, file: !3, line: 1817, type: !47, isLocal: true, isDefinition: true)
!370 = !DIGlobalVariableExpression(var: !371, expr: !DIExpression())
!371 = distinct !DIGlobalVariable(name: "Lp4", scope: !328, file: !3, line: 1818, type: !47, isLocal: true, isDefinition: true)
!372 = !DIGlobalVariableExpression(var: !373, expr: !DIExpression())
!373 = distinct !DIGlobalVariable(name: "Lp5", scope: !328, file: !3, line: 1819, type: !47, isLocal: true, isDefinition: true)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "Lp6", scope: !328, file: !3, line: 1820, type: !47, isLocal: true, isDefinition: true)
!376 = !DIGlobalVariableExpression(var: !377, expr: !DIExpression())
!377 = distinct !DIGlobalVariable(name: "Lp7", scope: !328, file: !3, line: 1821, type: !47, isLocal: true, isDefinition: true)
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(name: "zero", scope: !328, file: !3, line: 1823, type: !47, isLocal: true, isDefinition: true)
!380 = !DIGlobalVariableExpression(var: !381, expr: !DIExpression())
!381 = distinct !DIGlobalVariable(name: "two54", scope: !382, file: !3, line: 2002, type: !47, isLocal: true, isDefinition: true)
!382 = distinct !DISubprogram(name: "pts_ieee754_log2", scope: !3, file: !3, line: 2000, type: !4, scopeLine: 2000, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !383)
!383 = !{!384, !385, !386, !387, !388, !389, !390, !391, !392, !393, !394, !395, !396, !397, !398, !400, !404, !406}
!384 = !DILocalVariable(name: "x", arg: 1, scope: !382, file: !3, line: 2000, type: !6)
!385 = !DILocalVariable(name: "f", scope: !382, file: !3, line: 2006, type: !6)
!386 = !DILocalVariable(name: "hfsq", scope: !382, file: !3, line: 2006, type: !6)
!387 = !DILocalVariable(name: "hi", scope: !382, file: !3, line: 2006, type: !6)
!388 = !DILocalVariable(name: "lo", scope: !382, file: !3, line: 2006, type: !6)
!389 = !DILocalVariable(name: "r", scope: !382, file: !3, line: 2006, type: !6)
!390 = !DILocalVariable(name: "val_hi", scope: !382, file: !3, line: 2006, type: !6)
!391 = !DILocalVariable(name: "val_lo", scope: !382, file: !3, line: 2006, type: !6)
!392 = !DILocalVariable(name: "w", scope: !382, file: !3, line: 2006, type: !6)
!393 = !DILocalVariable(name: "y", scope: !382, file: !3, line: 2006, type: !6)
!394 = !DILocalVariable(name: "i", scope: !382, file: !3, line: 2007, type: !18)
!395 = !DILocalVariable(name: "k", scope: !382, file: !3, line: 2007, type: !18)
!396 = !DILocalVariable(name: "hx", scope: !382, file: !3, line: 2007, type: !18)
!397 = !DILocalVariable(name: "lx", scope: !382, file: !3, line: 2008, type: !9)
!398 = !DILocalVariable(name: "bits", scope: !399, file: !3, line: 2010, type: !16)
!399 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2010, column: 3)
!400 = !DILocalVariable(name: "bits", scope: !401, file: !3, line: 2022, type: !16)
!401 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2022, column: 5)
!402 = distinct !DILexicalBlock(scope: !403, file: !3, line: 2013, column: 24)
!403 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2013, column: 7)
!404 = !DILocalVariable(name: "bits", scope: !405, file: !3, line: 2029, type: !16)
!405 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2029, column: 3)
!406 = !DILocalVariable(name: "bits", scope: !407, file: !3, line: 2067, type: !16)
!407 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2067, column: 3)
!408 = !DIGlobalVariableExpression(var: !409, expr: !DIExpression())
!409 = distinct !DIGlobalVariable(name: "ivln2hi", scope: !382, file: !3, line: 2003, type: !47, isLocal: true, isDefinition: true)
!410 = !DIGlobalVariableExpression(var: !411, expr: !DIExpression())
!411 = distinct !DIGlobalVariable(name: "ivln2lo", scope: !382, file: !3, line: 2004, type: !47, isLocal: true, isDefinition: true)
!412 = !DIGlobalVariableExpression(var: !413, expr: !DIExpression())
!413 = distinct !DIGlobalVariable(name: "two54", scope: !414, file: !3, line: 2108, type: !47, isLocal: true, isDefinition: true)
!414 = distinct !DISubprogram(name: "pts_ieee754_log10", scope: !3, file: !3, line: 2106, type: !4, scopeLine: 2106, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !415)
!415 = !{!416, !417, !418, !419, !420, !421, !422, !424, !428, !430, !432, !434}
!416 = !DILocalVariable(name: "x", arg: 1, scope: !414, file: !3, line: 2106, type: !6)
!417 = !DILocalVariable(name: "y", scope: !414, file: !3, line: 2113, type: !6)
!418 = !DILocalVariable(name: "i", scope: !414, file: !3, line: 2114, type: !18)
!419 = !DILocalVariable(name: "k", scope: !414, file: !3, line: 2114, type: !18)
!420 = !DILocalVariable(name: "hx", scope: !414, file: !3, line: 2114, type: !18)
!421 = !DILocalVariable(name: "lx", scope: !414, file: !3, line: 2115, type: !9)
!422 = !DILocalVariable(name: "bits", scope: !423, file: !3, line: 2117, type: !16)
!423 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2117, column: 3)
!424 = !DILocalVariable(name: "bits", scope: !425, file: !3, line: 2129, type: !16)
!425 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2129, column: 5)
!426 = distinct !DILexicalBlock(scope: !427, file: !3, line: 2120, column: 24)
!427 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2120, column: 7)
!428 = !DILocalVariable(name: "bits", scope: !429, file: !3, line: 2130, type: !16)
!429 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2130, column: 5)
!430 = !DILocalVariable(name: "bits", scope: !431, file: !3, line: 2139, type: !16)
!431 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2139, column: 3)
!432 = !DILocalVariable(name: "bits", scope: !433, file: !3, line: 2140, type: !16)
!433 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2140, column: 3)
!434 = !DILocalVariable(name: "z", scope: !414, file: !3, line: 2142, type: !6)
!435 = !DIGlobalVariableExpression(var: !436, expr: !DIExpression())
!436 = distinct !DIGlobalVariable(name: "ivln10", scope: !414, file: !3, line: 2109, type: !47, isLocal: true, isDefinition: true)
!437 = !DIGlobalVariableExpression(var: !438, expr: !DIExpression())
!438 = distinct !DIGlobalVariable(name: "log10_2hi", scope: !414, file: !3, line: 2110, type: !47, isLocal: true, isDefinition: true)
!439 = !DIGlobalVariableExpression(var: !440, expr: !DIExpression())
!440 = distinct !DIGlobalVariable(name: "log10_2lo", scope: !414, file: !3, line: 2111, type: !47, isLocal: true, isDefinition: true)
!441 = !DIGlobalVariableExpression(var: !442, expr: !DIExpression())
!442 = distinct !DIGlobalVariable(name: "one", scope: !443, file: !3, line: 2242, type: !47, isLocal: true, isDefinition: true)
!443 = distinct !DISubprogram(name: "pts_ieee754_expm1", scope: !3, file: !3, line: 2240, type: !4, scopeLine: 2240, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !444)
!444 = !{!445, !446, !447, !448, !449, !450, !451, !452, !453, !454, !455, !456, !457, !458, !459, !461, !468, !470, !474, !478}
!445 = !DILocalVariable(name: "x", arg: 1, scope: !443, file: !3, line: 2240, type: !6)
!446 = !DILocalVariable(name: "y", scope: !443, file: !3, line: 2258, type: !6)
!447 = !DILocalVariable(name: "hi", scope: !443, file: !3, line: 2258, type: !6)
!448 = !DILocalVariable(name: "lo", scope: !443, file: !3, line: 2258, type: !6)
!449 = !DILocalVariable(name: "c", scope: !443, file: !3, line: 2258, type: !6)
!450 = !DILocalVariable(name: "t", scope: !443, file: !3, line: 2258, type: !6)
!451 = !DILocalVariable(name: "e", scope: !443, file: !3, line: 2258, type: !6)
!452 = !DILocalVariable(name: "hxs", scope: !443, file: !3, line: 2258, type: !6)
!453 = !DILocalVariable(name: "hfx", scope: !443, file: !3, line: 2258, type: !6)
!454 = !DILocalVariable(name: "r1", scope: !443, file: !3, line: 2258, type: !6)
!455 = !DILocalVariable(name: "twopk", scope: !443, file: !3, line: 2258, type: !6)
!456 = !DILocalVariable(name: "k", scope: !443, file: !3, line: 2259, type: !18)
!457 = !DILocalVariable(name: "xsb", scope: !443, file: !3, line: 2259, type: !18)
!458 = !DILocalVariable(name: "hx", scope: !443, file: !3, line: 2260, type: !9)
!459 = !DILocalVariable(name: "bits", scope: !460, file: !3, line: 2262, type: !16)
!460 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2262, column: 3)
!461 = !DILocalVariable(name: "low", scope: !462, file: !3, line: 2270, type: !9)
!462 = distinct !DILexicalBlock(scope: !463, file: !3, line: 2269, column: 29)
!463 = distinct !DILexicalBlock(scope: !464, file: !3, line: 2269, column: 11)
!464 = distinct !DILexicalBlock(scope: !465, file: !3, line: 2268, column: 27)
!465 = distinct !DILexicalBlock(scope: !466, file: !3, line: 2268, column: 9)
!466 = distinct !DILexicalBlock(scope: !467, file: !3, line: 2267, column: 25)
!467 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2267, column: 7)
!468 = !DILocalVariable(name: "bits", scope: !469, file: !3, line: 2271, type: !16)
!469 = distinct !DILexicalBlock(scope: !462, file: !3, line: 2271, column: 9)
!470 = !DILocalVariable(name: "bits", scope: !471, file: !3, line: 2321, type: !16)
!471 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2321, column: 5)
!472 = distinct !DILexicalBlock(scope: !473, file: !3, line: 2320, column: 10)
!473 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2318, column: 7)
!474 = !DILocalVariable(name: "bits", scope: !475, file: !3, line: 2347, type: !16)
!475 = distinct !DILexicalBlock(scope: !476, file: !3, line: 2347, column: 7)
!476 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2346, column: 17)
!477 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2346, column: 9)
!478 = !DILocalVariable(name: "bits", scope: !479, file: !3, line: 2351, type: !16)
!479 = distinct !DILexicalBlock(scope: !480, file: !3, line: 2351, column: 7)
!480 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2350, column: 12)
!481 = !DIGlobalVariableExpression(var: !482, expr: !DIExpression())
!482 = distinct !DIGlobalVariable(name: "tiny", scope: !443, file: !3, line: 2243, type: !47, isLocal: true, isDefinition: true)
!483 = !DIGlobalVariableExpression(var: !484, expr: !DIExpression())
!484 = distinct !DIGlobalVariable(name: "o_threshold", scope: !443, file: !3, line: 2244, type: !47, isLocal: true, isDefinition: true)
!485 = !DIGlobalVariableExpression(var: !486, expr: !DIExpression())
!486 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !443, file: !3, line: 2245, type: !47, isLocal: true, isDefinition: true)
!487 = !DIGlobalVariableExpression(var: !488, expr: !DIExpression())
!488 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !443, file: !3, line: 2246, type: !47, isLocal: true, isDefinition: true)
!489 = !DIGlobalVariableExpression(var: !490, expr: !DIExpression())
!490 = distinct !DIGlobalVariable(name: "invln2", scope: !443, file: !3, line: 2247, type: !47, isLocal: true, isDefinition: true)
!491 = !DIGlobalVariableExpression(var: !492, expr: !DIExpression())
!492 = distinct !DIGlobalVariable(name: "Q1", scope: !443, file: !3, line: 2250, type: !47, isLocal: true, isDefinition: true)
!493 = !DIGlobalVariableExpression(var: !494, expr: !DIExpression())
!494 = distinct !DIGlobalVariable(name: "Q2", scope: !443, file: !3, line: 2251, type: !47, isLocal: true, isDefinition: true)
!495 = !DIGlobalVariableExpression(var: !496, expr: !DIExpression())
!496 = distinct !DIGlobalVariable(name: "Q3", scope: !443, file: !3, line: 2252, type: !47, isLocal: true, isDefinition: true)
!497 = !DIGlobalVariableExpression(var: !498, expr: !DIExpression())
!498 = distinct !DIGlobalVariable(name: "Q4", scope: !443, file: !3, line: 2253, type: !47, isLocal: true, isDefinition: true)
!499 = !DIGlobalVariableExpression(var: !500, expr: !DIExpression())
!500 = distinct !DIGlobalVariable(name: "Q5", scope: !443, file: !3, line: 2254, type: !47, isLocal: true, isDefinition: true)
!501 = !DIGlobalVariableExpression(var: !502, expr: !DIExpression())
!502 = distinct !DIGlobalVariable(name: "huge", scope: !443, file: !3, line: 2256, type: !14, isLocal: true, isDefinition: true)
!503 = !DIGlobalVariableExpression(var: !504, expr: !DIExpression())
!504 = distinct !DIGlobalVariable(name: "B1", scope: !505, file: !3, line: 2362, type: !530, isLocal: true, isDefinition: true)
!505 = distinct !DISubprogram(name: "pts_ieee754_cbrt", scope: !3, file: !3, line: 2360, type: !4, scopeLine: 2360, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !506)
!506 = !{!507, !508, !509, !510, !511, !512, !513, !514, !515, !516, !518, !522, !524, !526, !529}
!507 = !DILocalVariable(name: "x", arg: 1, scope: !505, file: !3, line: 2360, type: !6)
!508 = !DILocalVariable(name: "hx", scope: !505, file: !3, line: 2372, type: !18)
!509 = !DILocalVariable(name: "r", scope: !505, file: !3, line: 2373, type: !6)
!510 = !DILocalVariable(name: "s", scope: !505, file: !3, line: 2373, type: !6)
!511 = !DILocalVariable(name: "t", scope: !505, file: !3, line: 2373, type: !6)
!512 = !DILocalVariable(name: "w", scope: !505, file: !3, line: 2373, type: !6)
!513 = !DILocalVariable(name: "sign", scope: !505, file: !3, line: 2374, type: !9)
!514 = !DILocalVariable(name: "high", scope: !505, file: !3, line: 2375, type: !9)
!515 = !DILocalVariable(name: "low", scope: !505, file: !3, line: 2375, type: !9)
!516 = !DILocalVariable(name: "bits", scope: !517, file: !3, line: 2377, type: !16)
!517 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2377, column: 3)
!518 = !DILocalVariable(name: "bits", scope: !519, file: !3, line: 2399, type: !16)
!519 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2399, column: 5)
!520 = distinct !DILexicalBlock(scope: !521, file: !3, line: 2397, column: 24)
!521 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2397, column: 7)
!522 = !DILocalVariable(name: "bits", scope: !523, file: !3, line: 2401, type: !16)
!523 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2401, column: 5)
!524 = !DILocalVariable(name: "bits", scope: !525, file: !3, line: 2402, type: !16)
!525 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2402, column: 5)
!526 = !DILocalVariable(name: "bits", scope: !527, file: !3, line: 2404, type: !16)
!527 = distinct !DILexicalBlock(scope: !528, file: !3, line: 2404, column: 5)
!528 = distinct !DILexicalBlock(scope: !521, file: !3, line: 2403, column: 10)
!529 = !DILocalVariable(name: "bits", scope: !505, file: !3, line: 2430, type: !16)
!530 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!531 = !DIGlobalVariableExpression(var: !532, expr: !DIExpression())
!532 = distinct !DIGlobalVariable(name: "B2", scope: !505, file: !3, line: 2363, type: !530, isLocal: true, isDefinition: true)
!533 = !DIGlobalVariableExpression(var: !534, expr: !DIExpression())
!534 = distinct !DIGlobalVariable(name: "P0", scope: !505, file: !3, line: 2366, type: !47, isLocal: true, isDefinition: true)
!535 = !DIGlobalVariableExpression(var: !536, expr: !DIExpression())
!536 = distinct !DIGlobalVariable(name: "P1", scope: !505, file: !3, line: 2367, type: !47, isLocal: true, isDefinition: true)
!537 = !DIGlobalVariableExpression(var: !538, expr: !DIExpression())
!538 = distinct !DIGlobalVariable(name: "P2", scope: !505, file: !3, line: 2368, type: !47, isLocal: true, isDefinition: true)
!539 = !DIGlobalVariableExpression(var: !540, expr: !DIExpression())
!540 = distinct !DIGlobalVariable(name: "P3", scope: !505, file: !3, line: 2369, type: !47, isLocal: true, isDefinition: true)
!541 = !DIGlobalVariableExpression(var: !542, expr: !DIExpression())
!542 = distinct !DIGlobalVariable(name: "P4", scope: !505, file: !3, line: 2370, type: !47, isLocal: true, isDefinition: true)
!543 = !DIGlobalVariableExpression(var: !544, expr: !DIExpression())
!544 = distinct !DIGlobalVariable(name: "KCOSH_OVERFLOW", scope: !545, file: !3, line: 2578, type: !47, isLocal: true, isDefinition: true)
!545 = distinct !DISubprogram(name: "pts_ieee754_cosh", scope: !3, file: !3, line: 2577, type: !4, scopeLine: 2577, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !546)
!546 = !{!547, !548, !549, !551, !554, !555, !558, !561}
!547 = !DILocalVariable(name: "x", arg: 1, scope: !545, file: !3, line: 2577, type: !6)
!548 = !DILocalVariable(name: "ix", scope: !545, file: !3, line: 2582, type: !18)
!549 = !DILocalVariable(name: "bits", scope: !550, file: !3, line: 2585, type: !16)
!550 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2585, column: 3)
!551 = !DILocalVariable(name: "t", scope: !552, file: !3, line: 2590, type: !6)
!552 = distinct !DILexicalBlock(scope: !553, file: !3, line: 2589, column: 24)
!553 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2589, column: 7)
!554 = !DILocalVariable(name: "w", scope: !552, file: !3, line: 2591, type: !6)
!555 = !DILocalVariable(name: "t", scope: !556, file: !3, line: 2599, type: !6)
!556 = distinct !DILexicalBlock(scope: !557, file: !3, line: 2598, column: 24)
!557 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2598, column: 7)
!558 = !DILocalVariable(name: "w", scope: !559, file: !3, line: 2608, type: !6)
!559 = distinct !DILexicalBlock(scope: !560, file: !3, line: 2607, column: 34)
!560 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2607, column: 7)
!561 = !DILocalVariable(name: "t", scope: !559, file: !3, line: 2609, type: !6)
!562 = !DIGlobalVariableExpression(var: !563, expr: !DIExpression())
!563 = distinct !DIGlobalVariable(name: "one", scope: !545, file: !3, line: 2579, type: !47, isLocal: true, isDefinition: true)
!564 = !DIGlobalVariableExpression(var: !565, expr: !DIExpression())
!565 = distinct !DIGlobalVariable(name: "half", scope: !545, file: !3, line: 2579, type: !47, isLocal: true, isDefinition: true)
!566 = !DIGlobalVariableExpression(var: !567, expr: !DIExpression())
!567 = distinct !DIGlobalVariable(name: "huge", scope: !545, file: !3, line: 2580, type: !14, isLocal: true, isDefinition: true)
!568 = !DIGlobalVariableExpression(var: !569, expr: !DIExpression())
!569 = distinct !DIGlobalVariable(name: "KSINH_OVERFLOW", scope: !570, file: !3, line: 2642, type: !47, isLocal: true, isDefinition: true)
!570 = distinct !DISubprogram(name: "pts_ieee754_sinh", scope: !3, file: !3, line: 2641, type: !4, scopeLine: 2641, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !571)
!571 = !{!572, !573, !574, !575, !578, !581}
!572 = !DILocalVariable(name: "x", arg: 1, scope: !570, file: !3, line: 2641, type: !6)
!573 = !DILocalVariable(name: "h", scope: !570, file: !3, line: 2648, type: !6)
!574 = !DILocalVariable(name: "ax", scope: !570, file: !3, line: 2650, type: !6)
!575 = !DILocalVariable(name: "t", scope: !576, file: !3, line: 2654, type: !6)
!576 = distinct !DILexicalBlock(scope: !577, file: !3, line: 2651, column: 16)
!577 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2651, column: 7)
!578 = !DILocalVariable(name: "w", scope: !579, file: !3, line: 2665, type: !6)
!579 = distinct !DILexicalBlock(scope: !580, file: !3, line: 2664, column: 29)
!580 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2664, column: 7)
!581 = !DILocalVariable(name: "t", scope: !579, file: !3, line: 2666, type: !6)
!582 = !DIGlobalVariableExpression(var: !583, expr: !DIExpression())
!583 = distinct !DIGlobalVariable(name: "TWO_M28", scope: !570, file: !3, line: 2643, type: !47, isLocal: true, isDefinition: true)
!584 = !DIGlobalVariableExpression(var: !585, expr: !DIExpression())
!585 = distinct !DIGlobalVariable(name: "LOG_MAXD", scope: !570, file: !3, line: 2645, type: !47, isLocal: true, isDefinition: true)
!586 = !DIGlobalVariableExpression(var: !587, expr: !DIExpression())
!587 = distinct !DIGlobalVariable(name: "shuge", scope: !570, file: !3, line: 2646, type: !47, isLocal: true, isDefinition: true)
!588 = !DIGlobalVariableExpression(var: !589, expr: !DIExpression())
!589 = distinct !DIGlobalVariable(name: "tiny", scope: !590, file: !3, line: 2698, type: !13, isLocal: true, isDefinition: true)
!590 = distinct !DISubprogram(name: "pts_ieee754_tanh", scope: !3, file: !3, line: 2697, type: !4, scopeLine: 2697, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !591)
!591 = !{!592, !593, !594, !595, !596, !597}
!592 = !DILocalVariable(name: "x", arg: 1, scope: !590, file: !3, line: 2697, type: !6)
!593 = !DILocalVariable(name: "t", scope: !590, file: !3, line: 2700, type: !6)
!594 = !DILocalVariable(name: "z", scope: !590, file: !3, line: 2700, type: !6)
!595 = !DILocalVariable(name: "jx", scope: !590, file: !3, line: 2701, type: !18)
!596 = !DILocalVariable(name: "ix", scope: !590, file: !3, line: 2701, type: !18)
!597 = !DILocalVariable(name: "bits", scope: !598, file: !3, line: 2703, type: !16)
!598 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2703, column: 3)
!599 = !DIGlobalVariableExpression(var: !600, expr: !DIExpression())
!600 = distinct !DIGlobalVariable(name: "one", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!601 = !DIGlobalVariableExpression(var: !602, expr: !DIExpression())
!602 = distinct !DIGlobalVariable(name: "two", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!603 = !DIGlobalVariableExpression(var: !604, expr: !DIExpression())
!604 = distinct !DIGlobalVariable(name: "huge", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!605 = !DIGlobalVariableExpression(var: !606, expr: !DIExpression())
!606 = distinct !DIGlobalVariable(name: "one", scope: !607, file: !3, line: 338, type: !47, isLocal: true, isDefinition: true)
!607 = distinct !DISubprogram(name: "__kernel_cos", scope: !3, file: !3, line: 336, type: !171, scopeLine: 336, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !608)
!608 = !{!609, !610, !611, !612, !613, !614, !615, !616, !617, !619}
!609 = !DILocalVariable(name: "x", arg: 1, scope: !607, file: !3, line: 336, type: !6)
!610 = !DILocalVariable(name: "y", arg: 2, scope: !607, file: !3, line: 336, type: !6)
!611 = !DILocalVariable(name: "a", scope: !607, file: !3, line: 346, type: !6)
!612 = !DILocalVariable(name: "iz", scope: !607, file: !3, line: 346, type: !6)
!613 = !DILocalVariable(name: "z", scope: !607, file: !3, line: 346, type: !6)
!614 = !DILocalVariable(name: "r", scope: !607, file: !3, line: 346, type: !6)
!615 = !DILocalVariable(name: "qx", scope: !607, file: !3, line: 346, type: !6)
!616 = !DILocalVariable(name: "ix", scope: !607, file: !3, line: 347, type: !18)
!617 = !DILocalVariable(name: "bits", scope: !618, file: !3, line: 348, type: !16)
!618 = distinct !DILexicalBlock(scope: !607, file: !3, line: 348, column: 3)
!619 = !DILocalVariable(name: "bits", scope: !620, file: !3, line: 361, type: !16)
!620 = distinct !DILexicalBlock(scope: !621, file: !3, line: 361, column: 7)
!621 = distinct !DILexicalBlock(scope: !622, file: !3, line: 360, column: 12)
!622 = distinct !DILexicalBlock(scope: !623, file: !3, line: 358, column: 9)
!623 = distinct !DILexicalBlock(scope: !624, file: !3, line: 357, column: 10)
!624 = distinct !DILexicalBlock(scope: !607, file: !3, line: 355, column: 7)
!625 = !DIGlobalVariableExpression(var: !626, expr: !DIExpression())
!626 = distinct !DIGlobalVariable(name: "C1", scope: !607, file: !3, line: 339, type: !47, isLocal: true, isDefinition: true)
!627 = !DIGlobalVariableExpression(var: !628, expr: !DIExpression())
!628 = distinct !DIGlobalVariable(name: "C2", scope: !607, file: !3, line: 340, type: !47, isLocal: true, isDefinition: true)
!629 = !DIGlobalVariableExpression(var: !630, expr: !DIExpression())
!630 = distinct !DIGlobalVariable(name: "C3", scope: !607, file: !3, line: 341, type: !47, isLocal: true, isDefinition: true)
!631 = !DIGlobalVariableExpression(var: !632, expr: !DIExpression())
!632 = distinct !DIGlobalVariable(name: "C4", scope: !607, file: !3, line: 342, type: !47, isLocal: true, isDefinition: true)
!633 = !DIGlobalVariableExpression(var: !634, expr: !DIExpression())
!634 = distinct !DIGlobalVariable(name: "C5", scope: !607, file: !3, line: 343, type: !47, isLocal: true, isDefinition: true)
!635 = !DIGlobalVariableExpression(var: !636, expr: !DIExpression())
!636 = distinct !DIGlobalVariable(name: "C6", scope: !607, file: !3, line: 344, type: !47, isLocal: true, isDefinition: true)
!637 = !DIGlobalVariableExpression(var: !638, expr: !DIExpression())
!638 = distinct !DIGlobalVariable(name: "two_over_pi", scope: !639, file: !3, line: 153, type: !682, isLocal: true, isDefinition: true)
!639 = distinct !DISubprogram(name: "__ieee754_rem_pio2", scope: !3, file: !3, line: 149, type: !640, scopeLine: 149, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !643)
!640 = !DISubroutineType(types: !641)
!641 = !{!18, !6, !642}
!642 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!643 = !{!644, !645, !646, !647, !648, !649, !650, !651, !655, !656, !657, !658, !659, !660, !661, !662, !663, !665, !670, !672, !676, !678, !680}
!644 = !DILocalVariable(name: "x", arg: 1, scope: !639, file: !3, line: 149, type: !6)
!645 = !DILocalVariable(name: "y", arg: 2, scope: !639, file: !3, line: 149, type: !642)
!646 = !DILocalVariable(name: "z", scope: !639, file: !3, line: 197, type: !6)
!647 = !DILocalVariable(name: "w", scope: !639, file: !3, line: 197, type: !6)
!648 = !DILocalVariable(name: "t", scope: !639, file: !3, line: 197, type: !6)
!649 = !DILocalVariable(name: "r", scope: !639, file: !3, line: 197, type: !6)
!650 = !DILocalVariable(name: "fn", scope: !639, file: !3, line: 197, type: !6)
!651 = !DILocalVariable(name: "tx", scope: !639, file: !3, line: 198, type: !652)
!652 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 192, elements: !653)
!653 = !{!654}
!654 = !DISubrange(count: 3)
!655 = !DILocalVariable(name: "e0", scope: !639, file: !3, line: 199, type: !18)
!656 = !DILocalVariable(name: "i", scope: !639, file: !3, line: 199, type: !18)
!657 = !DILocalVariable(name: "j", scope: !639, file: !3, line: 199, type: !18)
!658 = !DILocalVariable(name: "nx", scope: !639, file: !3, line: 199, type: !18)
!659 = !DILocalVariable(name: "n", scope: !639, file: !3, line: 199, type: !18)
!660 = !DILocalVariable(name: "ix", scope: !639, file: !3, line: 199, type: !18)
!661 = !DILocalVariable(name: "hx", scope: !639, file: !3, line: 199, type: !18)
!662 = !DILocalVariable(name: "low", scope: !639, file: !3, line: 200, type: !9)
!663 = !DILocalVariable(name: "bits", scope: !664, file: !3, line: 203, type: !16)
!664 = distinct !DILexicalBlock(scope: !639, file: !3, line: 203, column: 3)
!665 = !DILocalVariable(name: "high", scope: !666, file: !3, line: 244, type: !9)
!666 = distinct !DILexicalBlock(scope: !667, file: !3, line: 243, column: 12)
!667 = distinct !DILexicalBlock(scope: !668, file: !3, line: 241, column: 9)
!668 = distinct !DILexicalBlock(scope: !669, file: !3, line: 235, column: 25)
!669 = distinct !DILexicalBlock(scope: !639, file: !3, line: 235, column: 7)
!670 = !DILocalVariable(name: "bits", scope: !671, file: !3, line: 247, type: !16)
!671 = distinct !DILexicalBlock(scope: !666, file: !3, line: 247, column: 7)
!672 = !DILocalVariable(name: "bits", scope: !673, file: !3, line: 255, type: !16)
!673 = distinct !DILexicalBlock(scope: !674, file: !3, line: 255, column: 9)
!674 = distinct !DILexicalBlock(scope: !675, file: !3, line: 249, column: 19)
!675 = distinct !DILexicalBlock(scope: !666, file: !3, line: 249, column: 11)
!676 = !DILocalVariable(name: "bits", scope: !677, file: !3, line: 283, type: !16)
!677 = distinct !DILexicalBlock(scope: !639, file: !3, line: 283, column: 3)
!678 = !DILocalVariable(name: "bits", scope: !679, file: !3, line: 284, type: !16)
!679 = distinct !DILexicalBlock(scope: !639, file: !3, line: 284, column: 3)
!680 = !DILocalVariable(name: "bits", scope: !681, file: !3, line: 286, type: !16)
!681 = distinct !DILexicalBlock(scope: !639, file: !3, line: 286, column: 3)
!682 = !DICompositeType(tag: DW_TAG_array_type, baseType: !683, size: 2112, elements: !684)
!683 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !18)
!684 = !{!685}
!685 = !DISubrange(count: 66)
!686 = !DIGlobalVariableExpression(var: !687, expr: !DIExpression())
!687 = distinct !DIGlobalVariable(name: "npio2_hw", scope: !639, file: !3, line: 166, type: !688, isLocal: true, isDefinition: true)
!688 = !DICompositeType(tag: DW_TAG_array_type, baseType: !683, size: 1024, elements: !689)
!689 = !{!690}
!690 = !DISubrange(count: 32)
!691 = !DIGlobalVariableExpression(var: !692, expr: !DIExpression())
!692 = distinct !DIGlobalVariable(name: "zero", scope: !639, file: !3, line: 186, type: !47, isLocal: true, isDefinition: true)
!693 = !DIGlobalVariableExpression(var: !694, expr: !DIExpression())
!694 = distinct !DIGlobalVariable(name: "half", scope: !639, file: !3, line: 187, type: !47, isLocal: true, isDefinition: true)
!695 = !DIGlobalVariableExpression(var: !696, expr: !DIExpression())
!696 = distinct !DIGlobalVariable(name: "two24", scope: !639, file: !3, line: 188, type: !47, isLocal: true, isDefinition: true)
!697 = !DIGlobalVariableExpression(var: !698, expr: !DIExpression())
!698 = distinct !DIGlobalVariable(name: "invpio2", scope: !639, file: !3, line: 189, type: !47, isLocal: true, isDefinition: true)
!699 = !DIGlobalVariableExpression(var: !700, expr: !DIExpression())
!700 = distinct !DIGlobalVariable(name: "pio2_1", scope: !639, file: !3, line: 190, type: !47, isLocal: true, isDefinition: true)
!701 = !DIGlobalVariableExpression(var: !702, expr: !DIExpression())
!702 = distinct !DIGlobalVariable(name: "pio2_1t", scope: !639, file: !3, line: 191, type: !47, isLocal: true, isDefinition: true)
!703 = !DIGlobalVariableExpression(var: !704, expr: !DIExpression())
!704 = distinct !DIGlobalVariable(name: "pio2_2", scope: !639, file: !3, line: 192, type: !47, isLocal: true, isDefinition: true)
!705 = !DIGlobalVariableExpression(var: !706, expr: !DIExpression())
!706 = distinct !DIGlobalVariable(name: "pio2_2t", scope: !639, file: !3, line: 193, type: !47, isLocal: true, isDefinition: true)
!707 = !DIGlobalVariableExpression(var: !708, expr: !DIExpression())
!708 = distinct !DIGlobalVariable(name: "pio2_3", scope: !639, file: !3, line: 194, type: !47, isLocal: true, isDefinition: true)
!709 = !DIGlobalVariableExpression(var: !710, expr: !DIExpression())
!710 = distinct !DIGlobalVariable(name: "pio2_3t", scope: !639, file: !3, line: 195, type: !47, isLocal: true, isDefinition: true)
!711 = !DIGlobalVariableExpression(var: !712, expr: !DIExpression())
!712 = distinct !DIGlobalVariable(name: "init_jk", scope: !713, file: !3, line: 482, type: !748, isLocal: true, isDefinition: true)
!713 = distinct !DISubprogram(name: "__kernel_rem_pio2", scope: !3, file: !3, line: 474, type: !714, scopeLine: 475, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !717)
!714 = !DISubroutineType(types: !715)
!715 = !{!15, !642, !642, !15, !15, !15, !716}
!716 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !683, size: 64)
!717 = !{!718, !719, !720, !721, !722, !723, !724, !725, !726, !727, !728, !729, !730, !731, !735, !736, !737, !738, !739, !740, !741, !742, !743, !745, !746, !747}
!718 = !DILocalVariable(name: "x", arg: 1, scope: !713, file: !3, line: 474, type: !642)
!719 = !DILocalVariable(name: "y", arg: 2, scope: !713, file: !3, line: 474, type: !642)
!720 = !DILocalVariable(name: "e0", arg: 3, scope: !713, file: !3, line: 474, type: !15)
!721 = !DILocalVariable(name: "nx", arg: 4, scope: !713, file: !3, line: 474, type: !15)
!722 = !DILocalVariable(name: "prec", arg: 5, scope: !713, file: !3, line: 474, type: !15)
!723 = !DILocalVariable(name: "ipio2", arg: 6, scope: !713, file: !3, line: 475, type: !716)
!724 = !DILocalVariable(name: "jz", scope: !713, file: !3, line: 501, type: !18)
!725 = !DILocalVariable(name: "jx", scope: !713, file: !3, line: 501, type: !18)
!726 = !DILocalVariable(name: "jv", scope: !713, file: !3, line: 501, type: !18)
!727 = !DILocalVariable(name: "jp", scope: !713, file: !3, line: 501, type: !18)
!728 = !DILocalVariable(name: "jk", scope: !713, file: !3, line: 501, type: !18)
!729 = !DILocalVariable(name: "carry", scope: !713, file: !3, line: 501, type: !18)
!730 = !DILocalVariable(name: "n", scope: !713, file: !3, line: 501, type: !18)
!731 = !DILocalVariable(name: "iq", scope: !713, file: !3, line: 501, type: !732)
!732 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 640, elements: !733)
!733 = !{!734}
!734 = !DISubrange(count: 20)
!735 = !DILocalVariable(name: "i", scope: !713, file: !3, line: 501, type: !18)
!736 = !DILocalVariable(name: "j", scope: !713, file: !3, line: 501, type: !18)
!737 = !DILocalVariable(name: "k", scope: !713, file: !3, line: 501, type: !18)
!738 = !DILocalVariable(name: "m", scope: !713, file: !3, line: 501, type: !18)
!739 = !DILocalVariable(name: "q0", scope: !713, file: !3, line: 501, type: !18)
!740 = !DILocalVariable(name: "ih", scope: !713, file: !3, line: 501, type: !18)
!741 = !DILocalVariable(name: "z", scope: !713, file: !3, line: 502, type: !6)
!742 = !DILocalVariable(name: "fw", scope: !713, file: !3, line: 502, type: !6)
!743 = !DILocalVariable(name: "f", scope: !713, file: !3, line: 502, type: !744)
!744 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 1280, elements: !733)
!745 = !DILocalVariable(name: "fq", scope: !713, file: !3, line: 502, type: !744)
!746 = !DILocalVariable(name: "q", scope: !713, file: !3, line: 502, type: !744)
!747 = !DILabel(scope: !713, name: "recompute", file: !3, line: 528)
!748 = !DICompositeType(tag: DW_TAG_array_type, baseType: !749, size: 128, elements: !157)
!749 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !15)
!750 = !DIGlobalVariableExpression(var: !751, expr: !DIExpression())
!751 = distinct !DIGlobalVariable(name: "PIo2", scope: !713, file: !3, line: 484, type: !752, isLocal: true, isDefinition: true)
!752 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 512, elements: !753)
!753 = !{!754}
!754 = !DISubrange(count: 8)
!755 = !DIGlobalVariableExpression(var: !756, expr: !DIExpression())
!756 = distinct !DIGlobalVariable(name: "zero", scope: !713, file: !3, line: 496, type: !47, isLocal: true, isDefinition: true)
!757 = !DIGlobalVariableExpression(var: !758, expr: !DIExpression())
!758 = distinct !DIGlobalVariable(name: "one", scope: !713, file: !3, line: 497, type: !47, isLocal: true, isDefinition: true)
!759 = !DIGlobalVariableExpression(var: !760, expr: !DIExpression())
!760 = distinct !DIGlobalVariable(name: "two24", scope: !713, file: !3, line: 498, type: !47, isLocal: true, isDefinition: true)
!761 = !DIGlobalVariableExpression(var: !762, expr: !DIExpression())
!762 = distinct !DIGlobalVariable(name: "twon24", scope: !713, file: !3, line: 499, type: !47, isLocal: true, isDefinition: true)
!763 = !DIGlobalVariableExpression(var: !764, expr: !DIExpression())
!764 = distinct !DIGlobalVariable(name: "half", scope: !765, file: !3, line: 706, type: !47, isLocal: true, isDefinition: true)
!765 = distinct !DISubprogram(name: "__kernel_sin", scope: !3, file: !3, line: 704, type: !766, scopeLine: 704, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !768)
!766 = !DISubroutineType(types: !767)
!767 = !{!6, !6, !6, !15}
!768 = !{!769, !770, !771, !772, !773, !774, !775, !776}
!769 = !DILocalVariable(name: "x", arg: 1, scope: !765, file: !3, line: 704, type: !6)
!770 = !DILocalVariable(name: "y", arg: 2, scope: !765, file: !3, line: 704, type: !6)
!771 = !DILocalVariable(name: "iy", arg: 3, scope: !765, file: !3, line: 704, type: !15)
!772 = !DILocalVariable(name: "z", scope: !765, file: !3, line: 714, type: !6)
!773 = !DILocalVariable(name: "r", scope: !765, file: !3, line: 714, type: !6)
!774 = !DILocalVariable(name: "v", scope: !765, file: !3, line: 714, type: !6)
!775 = !DILocalVariable(name: "ix", scope: !765, file: !3, line: 715, type: !18)
!776 = !DILocalVariable(name: "bits", scope: !777, file: !3, line: 716, type: !16)
!777 = distinct !DILexicalBlock(scope: !765, file: !3, line: 716, column: 3)
!778 = !DIGlobalVariableExpression(var: !779, expr: !DIExpression())
!779 = distinct !DIGlobalVariable(name: "S1", scope: !765, file: !3, line: 707, type: !47, isLocal: true, isDefinition: true)
!780 = !DIGlobalVariableExpression(var: !781, expr: !DIExpression())
!781 = distinct !DIGlobalVariable(name: "S2", scope: !765, file: !3, line: 708, type: !47, isLocal: true, isDefinition: true)
!782 = !DIGlobalVariableExpression(var: !783, expr: !DIExpression())
!783 = distinct !DIGlobalVariable(name: "S3", scope: !765, file: !3, line: 709, type: !47, isLocal: true, isDefinition: true)
!784 = !DIGlobalVariableExpression(var: !785, expr: !DIExpression())
!785 = distinct !DIGlobalVariable(name: "S4", scope: !765, file: !3, line: 710, type: !47, isLocal: true, isDefinition: true)
!786 = !DIGlobalVariableExpression(var: !787, expr: !DIExpression())
!787 = distinct !DIGlobalVariable(name: "S5", scope: !765, file: !3, line: 711, type: !47, isLocal: true, isDefinition: true)
!788 = !DIGlobalVariableExpression(var: !789, expr: !DIExpression())
!789 = distinct !DIGlobalVariable(name: "S6", scope: !765, file: !3, line: 712, type: !47, isLocal: true, isDefinition: true)
!790 = !DIGlobalVariableExpression(var: !791, expr: !DIExpression(DW_OP_constu, 4600877379321592324, DW_OP_stack_value))
!791 = distinct !DIGlobalVariable(name: "Lg2", scope: !7, file: !3, line: 1967, type: !47, isLocal: true, isDefinition: true)
!792 = !DIGlobalVariableExpression(var: !793, expr: !DIExpression(DW_OP_constu, 4597174411056806063, DW_OP_stack_value))
!793 = distinct !DIGlobalVariable(name: "Lg4", scope: !7, file: !3, line: 1969, type: !47, isLocal: true, isDefinition: true)
!794 = !DIGlobalVariableExpression(var: !795, expr: !DIExpression(DW_OP_constu, 4594685411790997151, DW_OP_stack_value))
!795 = distinct !DIGlobalVariable(name: "Lg6", scope: !7, file: !3, line: 1971, type: !47, isLocal: true, isDefinition: true)
!796 = !DIGlobalVariableExpression(var: !797, expr: !DIExpression(DW_OP_constu, 4604180019048437139, DW_OP_stack_value))
!797 = distinct !DIGlobalVariable(name: "Lg1", scope: !7, file: !3, line: 1966, type: !47, isLocal: true, isDefinition: true)
!798 = !DIGlobalVariableExpression(var: !799, expr: !DIExpression(DW_OP_constu, 4598818590951641945, DW_OP_stack_value))
!799 = distinct !DIGlobalVariable(name: "Lg3", scope: !7, file: !3, line: 1968, type: !47, isLocal: true, isDefinition: true)
!800 = !DIGlobalVariableExpression(var: !801, expr: !DIExpression(DW_OP_constu, 4595719342595441630, DW_OP_stack_value))
!801 = distinct !DIGlobalVariable(name: "Lg5", scope: !7, file: !3, line: 1970, type: !47, isLocal: true, isDefinition: true)
!802 = !DIGlobalVariableExpression(var: !803, expr: !DIExpression(DW_OP_constu, 4594499633228436036, DW_OP_stack_value))
!803 = distinct !DIGlobalVariable(name: "Lg7", scope: !7, file: !3, line: 1972, type: !47, isLocal: true, isDefinition: true)
!804 = !DIGlobalVariableExpression(var: !805, expr: !DIExpression())
!805 = distinct !DIGlobalVariable(name: "xxx", scope: !806, file: !3, line: 765, type: !845, isLocal: true, isDefinition: true)
!806 = distinct !DISubprogram(name: "__kernel_tan", scope: !3, file: !3, line: 764, type: !766, scopeLine: 764, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !807)
!807 = !{!808, !809, !810, !811, !812, !813, !814, !815, !816, !817, !818, !820, !825, !827, !832, !833, !835, !837, !840, !841, !843}
!808 = !DILocalVariable(name: "x", arg: 1, scope: !806, file: !3, line: 764, type: !6)
!809 = !DILocalVariable(name: "y", arg: 2, scope: !806, file: !3, line: 764, type: !6)
!810 = !DILocalVariable(name: "iy", arg: 3, scope: !806, file: !3, line: 764, type: !15)
!811 = !DILocalVariable(name: "z", scope: !806, file: !3, line: 788, type: !6)
!812 = !DILocalVariable(name: "r", scope: !806, file: !3, line: 788, type: !6)
!813 = !DILocalVariable(name: "v", scope: !806, file: !3, line: 788, type: !6)
!814 = !DILocalVariable(name: "w", scope: !806, file: !3, line: 788, type: !6)
!815 = !DILocalVariable(name: "s", scope: !806, file: !3, line: 788, type: !6)
!816 = !DILocalVariable(name: "ix", scope: !806, file: !3, line: 789, type: !18)
!817 = !DILocalVariable(name: "hx", scope: !806, file: !3, line: 789, type: !18)
!818 = !DILocalVariable(name: "bits", scope: !819, file: !3, line: 791, type: !16)
!819 = distinct !DILexicalBlock(scope: !806, file: !3, line: 791, column: 3)
!820 = !DILocalVariable(name: "low", scope: !821, file: !3, line: 795, type: !9)
!821 = distinct !DILexicalBlock(scope: !822, file: !3, line: 794, column: 24)
!822 = distinct !DILexicalBlock(scope: !823, file: !3, line: 794, column: 9)
!823 = distinct !DILexicalBlock(scope: !824, file: !3, line: 793, column: 24)
!824 = distinct !DILexicalBlock(scope: !806, file: !3, line: 793, column: 7)
!825 = !DILocalVariable(name: "bits", scope: !826, file: !3, line: 796, type: !16)
!826 = distinct !DILexicalBlock(scope: !821, file: !3, line: 796, column: 7)
!827 = !DILocalVariable(name: "a", scope: !828, file: !3, line: 803, type: !6)
!828 = distinct !DILexicalBlock(scope: !829, file: !3, line: 802, column: 16)
!829 = distinct !DILexicalBlock(scope: !830, file: !3, line: 800, column: 13)
!830 = distinct !DILexicalBlock(scope: !831, file: !3, line: 799, column: 14)
!831 = distinct !DILexicalBlock(scope: !821, file: !3, line: 797, column: 11)
!832 = !DILocalVariable(name: "t", scope: !828, file: !3, line: 803, type: !6)
!833 = !DILocalVariable(name: "bits", scope: !834, file: !3, line: 806, type: !16)
!834 = distinct !DILexicalBlock(scope: !828, file: !3, line: 806, column: 11)
!835 = !DILocalVariable(name: "bits", scope: !836, file: !3, line: 809, type: !16)
!836 = distinct !DILexicalBlock(scope: !828, file: !3, line: 809, column: 11)
!837 = !DILocalVariable(name: "a", scope: !838, file: !3, line: 852, type: !6)
!838 = distinct !DILexicalBlock(scope: !839, file: !3, line: 846, column: 10)
!839 = distinct !DILexicalBlock(scope: !806, file: !3, line: 844, column: 7)
!840 = !DILocalVariable(name: "t", scope: !838, file: !3, line: 852, type: !6)
!841 = !DILocalVariable(name: "bits", scope: !842, file: !3, line: 854, type: !16)
!842 = distinct !DILexicalBlock(scope: !838, file: !3, line: 854, column: 5)
!843 = !DILocalVariable(name: "bits", scope: !844, file: !3, line: 857, type: !16)
!844 = distinct !DILexicalBlock(scope: !838, file: !3, line: 857, column: 5)
!845 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 1024, elements: !846)
!846 = !{!847}
!847 = !DISubrange(count: 16)
!848 = !{!849, !850, !851, !852, !853, !854, !855, !856, !857, !859, !862}
!849 = !DILocalVariable(name: "x", arg: 1, scope: !2, file: !3, line: 1147, type: !6)
!850 = !DILocalVariable(name: "w", scope: !2, file: !3, line: 1178, type: !6)
!851 = !DILocalVariable(name: "s1", scope: !2, file: !3, line: 1178, type: !6)
!852 = !DILocalVariable(name: "s2", scope: !2, file: !3, line: 1178, type: !6)
!853 = !DILocalVariable(name: "z", scope: !2, file: !3, line: 1178, type: !6)
!854 = !DILocalVariable(name: "ix", scope: !2, file: !3, line: 1179, type: !18)
!855 = !DILocalVariable(name: "hx", scope: !2, file: !3, line: 1179, type: !18)
!856 = !DILocalVariable(name: "id", scope: !2, file: !3, line: 1179, type: !18)
!857 = !DILocalVariable(name: "bits", scope: !858, file: !3, line: 1181, type: !16)
!858 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1181, column: 3)
!859 = !DILocalVariable(name: "low", scope: !860, file: !3, line: 1184, type: !9)
!860 = distinct !DILexicalBlock(scope: !861, file: !3, line: 1183, column: 25)
!861 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1183, column: 7)
!862 = !DILocalVariable(name: "bits", scope: !863, file: !3, line: 1185, type: !16)
!863 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1185, column: 5)
!864 = !{i32 7, !"Dwarf Version", i32 4}
!865 = !{i32 2, !"Debug Info Version", i32 3}
!866 = !{i32 1, !"wchar_size", i32 4}
!867 = !{i32 8, !"PIC Level", i32 2}
!868 = !{i32 7, !"uwtable", i32 1}
!869 = !{i32 7, !"frame-pointer", i32 1}
!870 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!871 = !DILocation(line: 0, scope: !22)
!872 = !DILocalVariable(name: "d", arg: 1, scope: !873, file: !3, line: 54, type: !6)
!873 = distinct !DISubprogram(name: "bits_of", scope: !3, file: !3, line: 54, type: !874, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !876)
!874 = !DISubroutineType(types: !875)
!875 = !{!16, !6}
!876 = !{!872, !877}
!877 = !DILocalVariable(name: "bits", scope: !873, file: !3, line: 55, type: !16)
!878 = !DILocation(line: 0, scope: !873, inlinedAt: !879)
!879 = distinct !DILocation(line: 912, column: 3, scope: !36)
!880 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !879)
!881 = !DILocation(line: 0, scope: !36)
!882 = !DILocation(line: 912, column: 3, scope: !36)
!883 = !DILocation(line: 913, column: 11, scope: !22)
!884 = !DILocation(line: 914, column: 10, scope: !39)
!885 = !DILocation(line: 914, column: 7, scope: !22)
!886 = !DILocation(line: 0, scope: !873, inlinedAt: !887)
!887 = distinct !DILocation(line: 916, column: 5, scope: !41)
!888 = !DILocation(line: 0, scope: !41)
!889 = !DILocation(line: 916, column: 5, scope: !41)
!890 = !DILocation(line: 0, scope: !38)
!891 = !DILocation(line: 917, column: 14, scope: !892)
!892 = distinct !DILexicalBlock(scope: !38, file: !3, line: 917, column: 9)
!893 = !DILocation(line: 917, column: 28, scope: !892)
!894 = !DILocation(line: 917, column: 34, scope: !892)
!895 = !DILocation(line: 917, column: 9, scope: !38)
!896 = !DILocation(line: 925, column: 10, scope: !46)
!897 = !DILocation(line: 925, column: 7, scope: !22)
!898 = !DILocation(line: 926, column: 12, scope: !899)
!899 = distinct !DILexicalBlock(scope: !900, file: !3, line: 926, column: 9)
!900 = distinct !DILexicalBlock(scope: !46, file: !3, line: 925, column: 24)
!901 = !DILocation(line: 926, column: 9, scope: !900)
!902 = !DILocation(line: 927, column: 11, scope: !900)
!903 = !DILocation(line: 928, column: 62, scope: !900)
!904 = !DILocation(line: 928, column: 51, scope: !900)
!905 = !DILocation(line: 928, column: 40, scope: !900)
!906 = !DILocation(line: 928, column: 29, scope: !900)
!907 = !DILocation(line: 928, column: 18, scope: !900)
!908 = !DILocation(line: 928, column: 11, scope: !900)
!909 = !DILocation(line: 929, column: 46, scope: !900)
!910 = !DILocation(line: 929, column: 35, scope: !900)
!911 = !DILocation(line: 929, column: 24, scope: !900)
!912 = !DILocation(line: 929, column: 13, scope: !900)
!913 = !DILocation(line: 930, column: 11, scope: !900)
!914 = !DILocation(line: 931, column: 36, scope: !900)
!915 = !DILocation(line: 931, column: 20, scope: !900)
!916 = !DILocation(line: 931, column: 5, scope: !900)
!917 = !DILocation(line: 932, column: 17, scope: !45)
!918 = !DILocation(line: 932, column: 14, scope: !46)
!919 = !DILocation(line: 933, column: 14, scope: !920)
!920 = distinct !DILexicalBlock(scope: !45, file: !3, line: 932, column: 22)
!921 = !DILocation(line: 933, column: 19, scope: !920)
!922 = !DILocation(line: 934, column: 62, scope: !920)
!923 = !DILocation(line: 934, column: 51, scope: !920)
!924 = !DILocation(line: 934, column: 40, scope: !920)
!925 = !DILocation(line: 934, column: 29, scope: !920)
!926 = !DILocation(line: 934, column: 18, scope: !920)
!927 = !DILocation(line: 934, column: 11, scope: !920)
!928 = !DILocation(line: 935, column: 46, scope: !920)
!929 = !DILocation(line: 935, column: 35, scope: !920)
!930 = !DILocation(line: 935, column: 24, scope: !920)
!931 = !DILocation(line: 935, column: 13, scope: !920)
!932 = !DILocation(line: 936, column: 9, scope: !920)
!933 = !DILocation(line: 937, column: 11, scope: !920)
!934 = !DILocation(line: 938, column: 15, scope: !920)
!935 = !DILocation(line: 939, column: 26, scope: !920)
!936 = !DILocation(line: 939, column: 15, scope: !920)
!937 = !DILocation(line: 939, column: 5, scope: !920)
!938 = !DILocation(line: 941, column: 14, scope: !44)
!939 = !DILocation(line: 941, column: 19, scope: !44)
!940 = !DILocation(line: 942, column: 9, scope: !44)
!941 = !DILocation(line: 0, scope: !873, inlinedAt: !942)
!942 = distinct !DILocation(line: 944, column: 5, scope: !43)
!943 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !942)
!944 = !DILocation(line: 0, scope: !43)
!945 = !DILocation(line: 944, column: 5, scope: !43)
!946 = !DILocalVariable(name: "bits", arg: 1, scope: !947, file: !3, line: 60, type: !16)
!947 = distinct !DISubprogram(name: "double_of", scope: !3, file: !3, line: 60, type: !948, scopeLine: 60, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !950)
!948 = !DISubroutineType(types: !949)
!949 = !{!6, !16}
!950 = !{!946, !951}
!951 = !DILocalVariable(name: "d", scope: !947, file: !3, line: 61, type: !6)
!952 = !DILocation(line: 0, scope: !947, inlinedAt: !953)
!953 = distinct !DILocation(line: 944, column: 5, scope: !43)
!954 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !953)
!955 = !DILocation(line: 945, column: 12, scope: !44)
!956 = !DILocation(line: 945, column: 28, scope: !44)
!957 = !DILocation(line: 945, column: 23, scope: !44)
!958 = !DILocation(line: 946, column: 62, scope: !44)
!959 = !DILocation(line: 946, column: 51, scope: !44)
!960 = !DILocation(line: 946, column: 40, scope: !44)
!961 = !DILocation(line: 946, column: 29, scope: !44)
!962 = !DILocation(line: 946, column: 18, scope: !44)
!963 = !DILocation(line: 946, column: 11, scope: !44)
!964 = !DILocation(line: 947, column: 46, scope: !44)
!965 = !DILocation(line: 947, column: 35, scope: !44)
!966 = !DILocation(line: 947, column: 24, scope: !44)
!967 = !DILocation(line: 947, column: 13, scope: !44)
!968 = !DILocation(line: 948, column: 11, scope: !44)
!969 = !DILocation(line: 949, column: 15, scope: !44)
!970 = !DILocation(line: 950, column: 22, scope: !44)
!971 = !DILocation(line: 950, column: 16, scope: !44)
!972 = !DILocation(line: 950, column: 5, scope: !44)
!973 = !DILocation(line: 952, column: 1, scope: !22)
!974 = !DILocation(line: 0, scope: !76)
!975 = !DILocation(line: 0, scope: !873, inlinedAt: !976)
!976 = distinct !DILocation(line: 974, column: 3, scope: !83)
!977 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !976)
!978 = !DILocation(line: 0, scope: !83)
!979 = !DILocation(line: 974, column: 3, scope: !83)
!980 = !DILocation(line: 975, column: 10, scope: !981)
!981 = distinct !DILexicalBlock(scope: !76, file: !3, line: 975, column: 7)
!982 = !DILocation(line: 975, column: 7, scope: !76)
!983 = !DILocation(line: 977, column: 17, scope: !984)
!984 = distinct !DILexicalBlock(scope: !981, file: !3, line: 977, column: 14)
!985 = !DILocation(line: 977, column: 14, scope: !981)
!986 = !DILocation(line: 978, column: 12, scope: !987)
!987 = distinct !DILexicalBlock(scope: !988, file: !3, line: 978, column: 9)
!988 = distinct !DILexicalBlock(scope: !984, file: !3, line: 977, column: 32)
!989 = !DILocation(line: 978, column: 9, scope: !988)
!990 = !DILocation(line: 979, column: 16, scope: !991)
!991 = distinct !DILexicalBlock(scope: !987, file: !3, line: 978, column: 27)
!992 = !DILocation(line: 979, column: 7, scope: !991)
!993 = !DILocation(line: 981, column: 14, scope: !994)
!994 = distinct !DILexicalBlock(scope: !987, file: !3, line: 980, column: 12)
!995 = !DILocation(line: 981, column: 33, scope: !994)
!996 = !DILocation(line: 981, column: 7, scope: !994)
!997 = !DILocation(line: 983, column: 19, scope: !998)
!998 = distinct !DILexicalBlock(scope: !984, file: !3, line: 983, column: 14)
!999 = !DILocation(line: 983, column: 33, scope: !998)
!1000 = !DILocation(line: 983, column: 39, scope: !998)
!1001 = !DILocation(line: 983, column: 14, scope: !984)
!1002 = !DILocation(line: 985, column: 17, scope: !1003)
!1003 = distinct !DILexicalBlock(scope: !998, file: !3, line: 985, column: 14)
!1004 = !DILocation(line: 985, column: 14, scope: !998)
!1005 = !DILocation(line: 986, column: 11, scope: !1006)
!1006 = distinct !DILexicalBlock(scope: !1003, file: !3, line: 985, column: 31)
!1007 = !DILocation(line: 987, column: 56, scope: !1006)
!1008 = !DILocation(line: 987, column: 49, scope: !1006)
!1009 = !DILocation(line: 987, column: 47, scope: !1006)
!1010 = !DILocation(line: 987, column: 36, scope: !1006)
!1011 = !DILocation(line: 987, column: 12, scope: !1006)
!1012 = !DILocation(line: 987, column: 5, scope: !1006)
!1013 = !DILocation(line: 989, column: 11, scope: !1014)
!1014 = distinct !DILexicalBlock(scope: !1003, file: !3, line: 988, column: 10)
!1015 = !DILocation(line: 990, column: 51, scope: !1014)
!1016 = !DILocation(line: 990, column: 47, scope: !1014)
!1017 = !DILocation(line: 990, column: 34, scope: !1014)
!1018 = !DILocation(line: 990, column: 32, scope: !1014)
!1019 = !DILocation(line: 990, column: 12, scope: !1014)
!1020 = !DILocation(line: 990, column: 5, scope: !1014)
!1021 = !DILocation(line: 0, scope: !981)
!1022 = !DILocation(line: 992, column: 1, scope: !76)
!1023 = !DILocation(line: 0, scope: !281)
!1024 = !DILocation(line: 0, scope: !873, inlinedAt: !1025)
!1025 = distinct !DILocation(line: 1684, column: 3, scope: !299)
!1026 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1025)
!1027 = !DILocation(line: 0, scope: !299)
!1028 = !DILocation(line: 1684, column: 3, scope: !299)
!1029 = !DILocation(line: 1687, column: 10, scope: !303)
!1030 = !DILocation(line: 1687, column: 7, scope: !281)
!1031 = !DILocation(line: 1688, column: 14, scope: !1032)
!1032 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1688, column: 9)
!1033 = !DILocation(line: 1688, column: 28, scope: !1032)
!1034 = !DILocation(line: 1688, column: 34, scope: !1032)
!1035 = !DILocation(line: 1688, column: 9, scope: !302)
!1036 = !DILocation(line: 1691, column: 12, scope: !1037)
!1037 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1691, column: 9)
!1038 = !DILocation(line: 1691, column: 9, scope: !302)
!1039 = !DILocation(line: 1695, column: 7, scope: !302)
!1040 = !DILocation(line: 0, scope: !873, inlinedAt: !1041)
!1041 = distinct !DILocation(line: 1696, column: 5, scope: !301)
!1042 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1041)
!1043 = !DILocation(line: 0, scope: !301)
!1044 = !DILocation(line: 1696, column: 5, scope: !301)
!1045 = !DILocation(line: 1697, column: 3, scope: !302)
!1046 = !DILocation(line: 1698, column: 10, scope: !1047)
!1047 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1698, column: 7)
!1048 = !DILocation(line: 1698, column: 7, scope: !281)
!1049 = !DILocation(line: 1698, column: 34, scope: !1047)
!1050 = !DILocation(line: 1698, column: 25, scope: !1047)
!1051 = !DILocation(line: 1699, column: 12, scope: !281)
!1052 = !DILocation(line: 1699, column: 19, scope: !281)
!1053 = !DILocation(line: 1699, column: 5, scope: !281)
!1054 = !DILocation(line: 1700, column: 6, scope: !281)
!1055 = !DILocation(line: 1701, column: 11, scope: !281)
!1056 = !DILocation(line: 1701, column: 22, scope: !281)
!1057 = !DILocation(line: 0, scope: !873, inlinedAt: !1058)
!1058 = distinct !DILocation(line: 1702, column: 3, scope: !305)
!1059 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1058)
!1060 = !DILocation(line: 0, scope: !305)
!1061 = !DILocation(line: 1702, column: 3, scope: !305)
!1062 = !DILocation(line: 0, scope: !947, inlinedAt: !1063)
!1063 = distinct !DILocation(line: 1702, column: 3, scope: !305)
!1064 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !1063)
!1065 = !DILocation(line: 1703, column: 5, scope: !281)
!1066 = !DILocation(line: 1704, column: 9, scope: !281)
!1067 = !DILocation(line: 1705, column: 24, scope: !1068)
!1068 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1705, column: 7)
!1069 = !DILocation(line: 1705, column: 19, scope: !1068)
!1070 = !DILocation(line: 1705, column: 31, scope: !1068)
!1071 = !DILocation(line: 1705, column: 7, scope: !281)
!1072 = !DILocation(line: 1706, column: 11, scope: !1073)
!1073 = distinct !DILexicalBlock(scope: !1074, file: !3, line: 1706, column: 9)
!1074 = distinct !DILexicalBlock(scope: !1068, file: !3, line: 1705, column: 36)
!1075 = !DILocation(line: 1706, column: 9, scope: !1074)
!1076 = !DILocation(line: 1707, column: 13, scope: !1077)
!1077 = distinct !DILexicalBlock(scope: !1078, file: !3, line: 1707, column: 11)
!1078 = distinct !DILexicalBlock(scope: !1073, file: !3, line: 1706, column: 20)
!1079 = !DILocation(line: 1707, column: 11, scope: !1078)
!1080 = !DILocation(line: 1710, column: 14, scope: !1081)
!1081 = distinct !DILexicalBlock(scope: !1077, file: !3, line: 1709, column: 14)
!1082 = !DILocation(line: 1711, column: 33, scope: !1081)
!1083 = !DILocation(line: 1711, column: 28, scope: !1081)
!1084 = !DILocation(line: 1711, column: 9, scope: !1081)
!1085 = !DILocation(line: 1714, column: 11, scope: !1074)
!1086 = !DILocation(line: 1714, column: 22, scope: !1074)
!1087 = !DILocation(line: 1714, column: 15, scope: !1074)
!1088 = !DILocation(line: 1715, column: 11, scope: !1089)
!1089 = distinct !DILexicalBlock(scope: !1074, file: !3, line: 1715, column: 9)
!1090 = !DILocation(line: 1715, column: 9, scope: !1074)
!1091 = !DILocation(line: 1716, column: 16, scope: !1092)
!1092 = distinct !DILexicalBlock(scope: !1089, file: !3, line: 1715, column: 17)
!1093 = !DILocation(line: 1716, column: 7, scope: !1092)
!1094 = !DILocation(line: 1718, column: 12, scope: !1095)
!1095 = distinct !DILexicalBlock(scope: !1089, file: !3, line: 1717, column: 12)
!1096 = !DILocation(line: 1719, column: 32, scope: !1095)
!1097 = !DILocation(line: 1719, column: 47, scope: !1095)
!1098 = !DILocation(line: 1719, column: 26, scope: !1095)
!1099 = !DILocation(line: 1719, column: 7, scope: !1095)
!1100 = !DILocation(line: 1722, column: 16, scope: !281)
!1101 = !DILocation(line: 1722, column: 9, scope: !281)
!1102 = !DILocation(line: 1723, column: 8, scope: !281)
!1103 = !DILocation(line: 1724, column: 9, scope: !281)
!1104 = !DILocation(line: 1725, column: 10, scope: !281)
!1105 = !DILocation(line: 1726, column: 9, scope: !281)
!1106 = !DILocation(line: 1727, column: 15, scope: !281)
!1107 = !DILocation(line: 1728, column: 28, scope: !281)
!1108 = !DILocation(line: 1728, column: 17, scope: !281)
!1109 = !DILocation(line: 1728, column: 10, scope: !281)
!1110 = !DILocation(line: 1729, column: 39, scope: !281)
!1111 = !DILocation(line: 1729, column: 28, scope: !281)
!1112 = !DILocation(line: 1729, column: 17, scope: !281)
!1113 = !DILocation(line: 1729, column: 10, scope: !281)
!1114 = !DILocation(line: 1730, column: 5, scope: !281)
!1115 = !DILocation(line: 1731, column: 10, scope: !281)
!1116 = !DILocation(line: 1732, column: 9, scope: !1117)
!1117 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1732, column: 7)
!1118 = !DILocation(line: 1732, column: 7, scope: !281)
!1119 = !DILocation(line: 1733, column: 16, scope: !1120)
!1120 = distinct !DILexicalBlock(scope: !1117, file: !3, line: 1732, column: 14)
!1121 = !DILocation(line: 1733, column: 20, scope: !1120)
!1122 = !DILocation(line: 1734, column: 11, scope: !1123)
!1123 = distinct !DILexicalBlock(scope: !1120, file: !3, line: 1734, column: 9)
!1124 = !DILocation(line: 0, scope: !1123)
!1125 = !DILocation(line: 1734, column: 9, scope: !1120)
!1126 = !DILocation(line: 1735, column: 24, scope: !1123)
!1127 = !DILocation(line: 1735, column: 16, scope: !1123)
!1128 = !DILocation(line: 1735, column: 7, scope: !1123)
!1129 = !DILocation(line: 1737, column: 58, scope: !1123)
!1130 = !DILocation(line: 1737, column: 53, scope: !1123)
!1131 = !DILocation(line: 1737, column: 35, scope: !1123)
!1132 = !DILocation(line: 1737, column: 69, scope: !1123)
!1133 = !DILocation(line: 1737, column: 26, scope: !1123)
!1134 = !DILocation(line: 1737, column: 7, scope: !1123)
!1135 = !DILocation(line: 1739, column: 11, scope: !1136)
!1136 = distinct !DILexicalBlock(scope: !1137, file: !3, line: 1739, column: 9)
!1137 = distinct !DILexicalBlock(scope: !1117, file: !3, line: 1738, column: 10)
!1138 = !DILocation(line: 0, scope: !1136)
!1139 = !DILocation(line: 1739, column: 9, scope: !1137)
!1140 = !DILocation(line: 1740, column: 16, scope: !1136)
!1141 = !DILocation(line: 1740, column: 7, scope: !1136)
!1142 = !DILocation(line: 1742, column: 42, scope: !1136)
!1143 = !DILocation(line: 1742, column: 57, scope: !1136)
!1144 = !DILocation(line: 1742, column: 26, scope: !1136)
!1145 = !DILocation(line: 1742, column: 7, scope: !1136)
!1146 = !DILocation(line: 1744, column: 1, scope: !281)
!1147 = !DILocation(line: 0, scope: !328)
!1148 = !DILocation(line: 0, scope: !873, inlinedAt: !1149)
!1149 = distinct !DILocation(line: 1828, column: 3, scope: !343)
!1150 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1149)
!1151 = !DILocation(line: 0, scope: !343)
!1152 = !DILocation(line: 1828, column: 3, scope: !343)
!1153 = !DILocation(line: 1829, column: 11, scope: !328)
!1154 = !DILocation(line: 1832, column: 10, scope: !1155)
!1155 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1832, column: 7)
!1156 = !DILocation(line: 1832, column: 7, scope: !328)
!1157 = !DILocation(line: 1833, column: 12, scope: !1158)
!1158 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 1833, column: 9)
!1159 = distinct !DILexicalBlock(scope: !1155, file: !3, line: 1832, column: 24)
!1160 = !DILocation(line: 1833, column: 9, scope: !1159)
!1161 = !DILocation(line: 1834, column: 13, scope: !1162)
!1162 = distinct !DILexicalBlock(scope: !1163, file: !3, line: 1834, column: 11)
!1163 = distinct !DILexicalBlock(scope: !1158, file: !3, line: 1833, column: 27)
!1164 = !DILocation(line: 0, scope: !1162)
!1165 = !DILocation(line: 1839, column: 12, scope: !1166)
!1166 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 1839, column: 9)
!1167 = !DILocation(line: 1839, column: 9, scope: !1159)
!1168 = !DILocation(line: 1840, column: 17, scope: !1169)
!1169 = distinct !DILexicalBlock(scope: !1170, file: !3, line: 1840, column: 11)
!1170 = distinct !DILexicalBlock(scope: !1166, file: !3, line: 1839, column: 26)
!1171 = !DILocation(line: 1840, column: 21, scope: !1169)
!1172 = !DILocation(line: 1841, column: 11, scope: !1169)
!1173 = !DILocation(line: 1844, column: 18, scope: !1169)
!1174 = !DILocation(line: 1844, column: 9, scope: !1169)
!1175 = !DILocation(line: 1852, column: 10, scope: !1176)
!1176 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1852, column: 7)
!1177 = !DILocation(line: 1852, column: 7, scope: !328)
!1178 = !DILocation(line: 1852, column: 34, scope: !1176)
!1179 = !DILocation(line: 1852, column: 25, scope: !1176)
!1180 = !DILocation(line: 1846, column: 16, scope: !1181)
!1181 = distinct !DILexicalBlock(scope: !1159, file: !3, line: 1846, column: 9)
!1182 = !DILocation(line: 1853, column: 7, scope: !328)
!1183 = !DILocation(line: 1883, column: 14, scope: !328)
!1184 = !DILocation(line: 1883, column: 18, scope: !328)
!1185 = !DILocation(line: 1884, column: 7, scope: !328)
!1186 = !DILocation(line: 1854, column: 12, scope: !347)
!1187 = !DILocation(line: 1854, column: 9, scope: !348)
!1188 = !DILocation(line: 1855, column: 15, scope: !346)
!1189 = !DILocation(line: 0, scope: !873, inlinedAt: !1190)
!1190 = distinct !DILocation(line: 1856, column: 7, scope: !345)
!1191 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1190)
!1192 = !DILocation(line: 0, scope: !345)
!1193 = !DILocation(line: 1856, column: 7, scope: !345)
!1194 = !DILocation(line: 1857, column: 15, scope: !346)
!1195 = !DILocation(line: 1858, column: 14, scope: !346)
!1196 = !DILocation(line: 1858, column: 11, scope: !346)
!1197 = !DILocation(line: 1859, column: 9, scope: !346)
!1198 = !DILocation(line: 1860, column: 5, scope: !346)
!1199 = !DILocation(line: 0, scope: !873, inlinedAt: !1200)
!1200 = distinct !DILocation(line: 1862, column: 7, scope: !351)
!1201 = !DILocation(line: 1863, column: 15, scope: !352)
!1202 = !DILocation(line: 0, scope: !347)
!1203 = !DILocation(line: 1866, column: 8, scope: !348)
!1204 = !DILocation(line: 1874, column: 12, scope: !356)
!1205 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1206)
!1206 = !DILocation(line: 0, scope: !356)
!1207 = !DILocation(line: 0, scope: !873, inlinedAt: !1208)
!1208 = distinct !DILocation(line: 1875, column: 7, scope: !354)
!1209 = !DILocation(line: 0, scope: !873, inlinedAt: !1210)
!1210 = distinct !DILocation(line: 1878, column: 7, scope: !358)
!1211 = !DILocation(line: 1874, column: 9, scope: !348)
!1212 = !DILocation(line: 0, scope: !354)
!1213 = !DILocation(line: 1875, column: 7, scope: !354)
!1214 = !DILocation(line: 1876, column: 5, scope: !355)
!1215 = !DILocation(line: 1877, column: 9, scope: !359)
!1216 = !DILocation(line: 0, scope: !358)
!1217 = !DILocation(line: 1878, column: 7, scope: !358)
!1218 = !DILocation(line: 1879, column: 24, scope: !359)
!1219 = !DILocation(line: 0, scope: !348)
!1220 = !DILocation(line: 1881, column: 11, scope: !348)
!1221 = !DILocation(line: 1884, column: 10, scope: !1222)
!1222 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1884, column: 7)
!1223 = !DILocation(line: 1885, column: 11, scope: !1224)
!1224 = distinct !DILexicalBlock(scope: !1225, file: !3, line: 1885, column: 9)
!1225 = distinct !DILexicalBlock(scope: !1222, file: !3, line: 1884, column: 16)
!1226 = !DILocation(line: 1885, column: 9, scope: !1225)
!1227 = !DILocation(line: 1886, column: 13, scope: !1228)
!1228 = distinct !DILexicalBlock(scope: !1229, file: !3, line: 1886, column: 11)
!1229 = distinct !DILexicalBlock(scope: !1224, file: !3, line: 1885, column: 20)
!1230 = !DILocation(line: 1886, column: 11, scope: !1229)
!1231 = !DILocation(line: 1889, column: 14, scope: !1232)
!1232 = distinct !DILexicalBlock(scope: !1228, file: !3, line: 1888, column: 14)
!1233 = !DILocation(line: 1889, column: 11, scope: !1232)
!1234 = !DILocation(line: 1890, column: 27, scope: !1232)
!1235 = !DILocation(line: 1890, column: 9, scope: !1232)
!1236 = !DILocation(line: 1893, column: 21, scope: !1225)
!1237 = !DILocation(line: 1893, column: 14, scope: !1225)
!1238 = !DILocation(line: 1894, column: 11, scope: !1239)
!1239 = distinct !DILexicalBlock(scope: !1225, file: !3, line: 1894, column: 9)
!1240 = !DILocation(line: 1894, column: 9, scope: !1225)
!1241 = !DILocation(line: 1895, column: 16, scope: !1239)
!1242 = !DILocation(line: 1895, column: 7, scope: !1239)
!1243 = !DILocation(line: 1897, column: 14, scope: !1239)
!1244 = !DILocation(line: 1897, column: 45, scope: !1239)
!1245 = !DILocation(line: 1897, column: 31, scope: !1239)
!1246 = !DILocation(line: 1897, column: 51, scope: !1239)
!1247 = !DILocation(line: 1897, column: 25, scope: !1239)
!1248 = !DILocation(line: 1897, column: 7, scope: !1239)
!1249 = !DILocation(line: 1899, column: 16, scope: !328)
!1250 = !DILocation(line: 1899, column: 9, scope: !328)
!1251 = !DILocation(line: 1900, column: 9, scope: !328)
!1252 = !DILocation(line: 1902, column: 65, scope: !328)
!1253 = !DILocation(line: 1902, column: 54, scope: !328)
!1254 = !DILocation(line: 1902, column: 43, scope: !328)
!1255 = !DILocation(line: 1902, column: 32, scope: !328)
!1256 = !DILocation(line: 1902, column: 21, scope: !328)
!1257 = !DILocation(line: 1901, column: 16, scope: !328)
!1258 = !DILocation(line: 1901, column: 9, scope: !328)
!1259 = !DILocation(line: 1903, column: 9, scope: !1260)
!1260 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1903, column: 7)
!1261 = !DILocation(line: 1903, column: 7, scope: !328)
!1262 = !DILocation(line: 1904, column: 34, scope: !1260)
!1263 = !DILocation(line: 1904, column: 22, scope: !1260)
!1264 = !DILocation(line: 1904, column: 14, scope: !1260)
!1265 = !DILocation(line: 1904, column: 5, scope: !1260)
!1266 = !DILocation(line: 1906, column: 12, scope: !1260)
!1267 = !DILocation(line: 1906, column: 45, scope: !1260)
!1268 = !DILocation(line: 1906, column: 64, scope: !1260)
!1269 = !DILocation(line: 1906, column: 50, scope: !1260)
!1270 = !DILocation(line: 1906, column: 32, scope: !1260)
!1271 = !DILocation(line: 1906, column: 71, scope: !1260)
!1272 = !DILocation(line: 1906, column: 23, scope: !1260)
!1273 = !DILocation(line: 1906, column: 5, scope: !1260)
!1274 = !DILocation(line: 1907, column: 1, scope: !328)
!1275 = !DILocation(line: 0, scope: !88)
!1276 = !DILocation(line: 0, scope: !873, inlinedAt: !1277)
!1277 = distinct !DILocation(line: 1045, column: 3, scope: !101)
!1278 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1277)
!1279 = !DILocation(line: 0, scope: !101)
!1280 = !DILocation(line: 1045, column: 3, scope: !101)
!1281 = !DILocation(line: 1046, column: 11, scope: !88)
!1282 = !DILocation(line: 1047, column: 10, scope: !104)
!1283 = !DILocation(line: 1047, column: 7, scope: !88)
!1284 = !DILocation(line: 0, scope: !873, inlinedAt: !1285)
!1285 = distinct !DILocation(line: 1049, column: 5, scope: !106)
!1286 = !DILocation(line: 0, scope: !106)
!1287 = !DILocation(line: 1049, column: 5, scope: !106)
!1288 = !DILocation(line: 0, scope: !103)
!1289 = !DILocation(line: 1050, column: 14, scope: !1290)
!1290 = distinct !DILexicalBlock(scope: !103, file: !3, line: 1050, column: 9)
!1291 = !DILocation(line: 1050, column: 28, scope: !1290)
!1292 = !DILocation(line: 1050, column: 34, scope: !1290)
!1293 = !DILocation(line: 1050, column: 9, scope: !103)
!1294 = !DILocation(line: 1054, column: 17, scope: !1295)
!1295 = distinct !DILexicalBlock(scope: !104, file: !3, line: 1054, column: 14)
!1296 = !DILocation(line: 1054, column: 14, scope: !104)
!1297 = !DILocation(line: 1055, column: 12, scope: !1298)
!1298 = distinct !DILexicalBlock(scope: !1299, file: !3, line: 1055, column: 9)
!1299 = distinct !DILexicalBlock(scope: !1295, file: !3, line: 1054, column: 31)
!1300 = !DILocation(line: 1055, column: 9, scope: !1299)
!1301 = !DILocation(line: 1056, column: 16, scope: !1302)
!1302 = distinct !DILexicalBlock(scope: !1303, file: !3, line: 1056, column: 11)
!1303 = distinct !DILexicalBlock(scope: !1298, file: !3, line: 1055, column: 26)
!1304 = !DILocation(line: 1056, column: 20, scope: !1302)
!1305 = !DILocation(line: 1056, column: 11, scope: !1303)
!1306 = !DILocation(line: 1058, column: 13, scope: !1307)
!1307 = distinct !DILexicalBlock(scope: !1298, file: !3, line: 1057, column: 12)
!1308 = !DILocation(line: 1060, column: 62, scope: !1299)
!1309 = !DILocation(line: 1060, column: 51, scope: !1299)
!1310 = !DILocation(line: 1060, column: 40, scope: !1299)
!1311 = !DILocation(line: 1060, column: 29, scope: !1299)
!1312 = !DILocation(line: 1060, column: 18, scope: !1299)
!1313 = !DILocation(line: 1060, column: 11, scope: !1299)
!1314 = !DILocation(line: 1061, column: 46, scope: !1299)
!1315 = !DILocation(line: 1061, column: 35, scope: !1299)
!1316 = !DILocation(line: 1061, column: 24, scope: !1299)
!1317 = !DILocation(line: 1061, column: 13, scope: !1299)
!1318 = !DILocation(line: 1062, column: 11, scope: !1299)
!1319 = !DILocation(line: 1063, column: 14, scope: !1299)
!1320 = !DILocation(line: 1063, column: 5, scope: !1299)
!1321 = !DILocation(line: 1066, column: 13, scope: !88)
!1322 = !DILocation(line: 1066, column: 11, scope: !88)
!1323 = !DILocation(line: 1067, column: 9, scope: !88)
!1324 = !DILocation(line: 1068, column: 60, scope: !88)
!1325 = !DILocation(line: 1068, column: 49, scope: !88)
!1326 = !DILocation(line: 1068, column: 38, scope: !88)
!1327 = !DILocation(line: 1068, column: 27, scope: !88)
!1328 = !DILocation(line: 1068, column: 16, scope: !88)
!1329 = !DILocation(line: 1068, column: 9, scope: !88)
!1330 = !DILocation(line: 1069, column: 44, scope: !88)
!1331 = !DILocation(line: 1069, column: 33, scope: !88)
!1332 = !DILocation(line: 1069, column: 22, scope: !88)
!1333 = !DILocation(line: 1069, column: 11, scope: !88)
!1334 = !DILocation(line: 1070, column: 7, scope: !88)
!1335 = !DILocation(line: 1071, column: 10, scope: !110)
!1336 = !DILocation(line: 1071, column: 7, scope: !88)
!1337 = !DILocation(line: 1072, column: 11, scope: !1338)
!1338 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1071, column: 25)
!1339 = !DILocation(line: 1073, column: 29, scope: !1338)
!1340 = !DILocation(line: 1073, column: 38, scope: !1338)
!1341 = !DILocation(line: 1073, column: 17, scope: !1338)
!1342 = !DILocation(line: 1074, column: 3, scope: !1338)
!1343 = !DILocation(line: 0, scope: !873, inlinedAt: !1344)
!1344 = distinct !DILocation(line: 1076, column: 5, scope: !108)
!1345 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1344)
!1346 = !DILocation(line: 0, scope: !108)
!1347 = !DILocation(line: 1076, column: 5, scope: !108)
!1348 = !DILocation(line: 0, scope: !947, inlinedAt: !1349)
!1349 = distinct !DILocation(line: 1076, column: 5, scope: !108)
!1350 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !1349)
!1351 = !DILocation(line: 1077, column: 12, scope: !109)
!1352 = !DILocation(line: 1077, column: 26, scope: !109)
!1353 = !DILocation(line: 1077, column: 21, scope: !109)
!1354 = !DILocation(line: 1078, column: 11, scope: !109)
!1355 = !DILocation(line: 1079, column: 13, scope: !109)
!1356 = !DILocation(line: 1079, column: 32, scope: !109)
!1357 = !DILocation(line: 1079, column: 21, scope: !109)
!1358 = !DILocation(line: 1080, column: 17, scope: !109)
!1359 = !DILocation(line: 1081, column: 17, scope: !109)
!1360 = !DILocation(line: 0, scope: !110)
!1361 = !DILocation(line: 1083, column: 10, scope: !1362)
!1362 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1083, column: 7)
!1363 = !DILocation(line: 1083, column: 7, scope: !88)
!1364 = !DILocation(line: 1087, column: 1, scope: !88)
!1365 = !DILocation(line: 0, scope: !141)
!1366 = !DILocation(line: 0, scope: !873, inlinedAt: !1367)
!1367 = distinct !DILocation(line: 1106, column: 3, scope: !149)
!1368 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1367)
!1369 = !DILocation(line: 0, scope: !149)
!1370 = !DILocation(line: 1106, column: 3, scope: !149)
!1371 = !DILocation(line: 1107, column: 11, scope: !141)
!1372 = !DILocation(line: 1108, column: 10, scope: !1373)
!1373 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1108, column: 7)
!1374 = !DILocation(line: 1108, column: 7, scope: !141)
!1375 = !DILocation(line: 1108, column: 34, scope: !1373)
!1376 = !DILocation(line: 1108, column: 25, scope: !1373)
!1377 = !DILocation(line: 1109, column: 10, scope: !1378)
!1378 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1109, column: 7)
!1379 = !DILocation(line: 1109, column: 7, scope: !141)
!1380 = !DILocation(line: 1112, column: 10, scope: !1381)
!1381 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1112, column: 7)
!1382 = !DILocation(line: 1112, column: 7, scope: !141)
!1383 = !DILocation(line: 1113, column: 25, scope: !1384)
!1384 = distinct !DILexicalBlock(scope: !1381, file: !3, line: 1112, column: 24)
!1385 = !DILocation(line: 1113, column: 9, scope: !1384)
!1386 = !DILocation(line: 1113, column: 34, scope: !1384)
!1387 = !DILocation(line: 1114, column: 3, scope: !1384)
!1388 = !DILocation(line: 1114, column: 17, scope: !1389)
!1389 = distinct !DILexicalBlock(scope: !1381, file: !3, line: 1114, column: 14)
!1390 = !DILocation(line: 1114, column: 14, scope: !1381)
!1391 = !DILocation(line: 1115, column: 9, scope: !1392)
!1392 = distinct !DILexicalBlock(scope: !1389, file: !3, line: 1114, column: 31)
!1393 = !DILocation(line: 1116, column: 53, scope: !1392)
!1394 = !DILocation(line: 1116, column: 42, scope: !1392)
!1395 = !DILocation(line: 1116, column: 60, scope: !1392)
!1396 = !DILocation(line: 1116, column: 39, scope: !1392)
!1397 = !DILocation(line: 1116, column: 33, scope: !1392)
!1398 = !DILocation(line: 1116, column: 9, scope: !1392)
!1399 = !DILocation(line: 1117, column: 3, scope: !1392)
!1400 = !DILocation(line: 1118, column: 11, scope: !1401)
!1401 = distinct !DILexicalBlock(scope: !1389, file: !3, line: 1117, column: 10)
!1402 = !DILocation(line: 1119, column: 27, scope: !1401)
!1403 = !DILocation(line: 1119, column: 57, scope: !1401)
!1404 = !DILocation(line: 1119, column: 48, scope: !1401)
!1405 = !DILocation(line: 1119, column: 46, scope: !1401)
!1406 = !DILocation(line: 1119, column: 39, scope: !1401)
!1407 = !DILocation(line: 1119, column: 35, scope: !1401)
!1408 = !DILocation(line: 1119, column: 9, scope: !1401)
!1409 = !DILocation(line: 0, scope: !1381)
!1410 = !DILocation(line: 1121, column: 10, scope: !1411)
!1411 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1121, column: 7)
!1412 = !DILocation(line: 1121, column: 7, scope: !141)
!1413 = !DILocation(line: 1126, column: 1, scope: !141)
!1414 = !DILocation(line: 0, scope: !2)
!1415 = !DILocation(line: 0, scope: !873, inlinedAt: !1416)
!1416 = distinct !DILocation(line: 1181, column: 3, scope: !858)
!1417 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1416)
!1418 = !DILocation(line: 0, scope: !858)
!1419 = !DILocation(line: 1181, column: 3, scope: !858)
!1420 = !DILocation(line: 1182, column: 11, scope: !2)
!1421 = !DILocation(line: 1183, column: 10, scope: !861)
!1422 = !DILocation(line: 1183, column: 7, scope: !2)
!1423 = !DILocation(line: 0, scope: !873, inlinedAt: !1424)
!1424 = distinct !DILocation(line: 1185, column: 5, scope: !863)
!1425 = !DILocation(line: 0, scope: !860)
!1426 = !DILocation(line: 1186, column: 12, scope: !1427)
!1427 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1186, column: 9)
!1428 = !DILocation(line: 1186, column: 25, scope: !1427)
!1429 = !DILocation(line: 1186, column: 32, scope: !1427)
!1430 = !DILocation(line: 1186, column: 46, scope: !1427)
!1431 = !DILocation(line: 1187, column: 16, scope: !1427)
!1432 = !DILocation(line: 1187, column: 7, scope: !1427)
!1433 = !DILocation(line: 1188, column: 12, scope: !1434)
!1434 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1188, column: 9)
!1435 = !DILocation(line: 0, scope: !1434)
!1436 = !{!1437, !1437, i64 0}
!1437 = !{!"double", !1438, i64 0}
!1438 = !{!"omnipotent char", !1439, i64 0}
!1439 = !{!"Simple C/C++ TBAA"}
!1440 = !DILocation(line: 1188, column: 9, scope: !860)
!1441 = !DILocation(line: 1189, column: 24, scope: !1434)
!1442 = !DILocation(line: 1189, column: 7, scope: !1434)
!1443 = !DILocation(line: 1191, column: 25, scope: !1434)
!1444 = !DILocation(line: 1191, column: 7, scope: !1434)
!1445 = !DILocation(line: 1193, column: 10, scope: !1446)
!1446 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1193, column: 7)
!1447 = !DILocation(line: 1193, column: 7, scope: !2)
!1448 = !DILocation(line: 1194, column: 12, scope: !1449)
!1449 = distinct !DILexicalBlock(scope: !1450, file: !3, line: 1194, column: 9)
!1450 = distinct !DILexicalBlock(scope: !1446, file: !3, line: 1193, column: 24)
!1451 = !DILocation(line: 1194, column: 9, scope: !1450)
!1452 = !DILocation(line: 1199, column: 9, scope: !1453)
!1453 = distinct !DILexicalBlock(scope: !1446, file: !3, line: 1198, column: 10)
!1454 = !DILocation(line: 1200, column: 12, scope: !1455)
!1455 = distinct !DILexicalBlock(scope: !1453, file: !3, line: 1200, column: 9)
!1456 = !DILocation(line: 1200, column: 9, scope: !1453)
!1457 = !DILocation(line: 1201, column: 14, scope: !1458)
!1458 = distinct !DILexicalBlock(scope: !1459, file: !3, line: 1201, column: 11)
!1459 = distinct !DILexicalBlock(scope: !1455, file: !3, line: 1200, column: 26)
!1460 = !DILocation(line: 1201, column: 11, scope: !1459)
!1461 = !DILocation(line: 1203, column: 22, scope: !1462)
!1462 = distinct !DILexicalBlock(scope: !1458, file: !3, line: 1201, column: 28)
!1463 = !DILocation(line: 1203, column: 36, scope: !1462)
!1464 = !DILocation(line: 1203, column: 29, scope: !1462)
!1465 = !DILocation(line: 1204, column: 7, scope: !1462)
!1466 = !DILocation(line: 1206, column: 16, scope: !1467)
!1467 = distinct !DILexicalBlock(scope: !1458, file: !3, line: 1204, column: 14)
!1468 = !DILocation(line: 1206, column: 28, scope: !1467)
!1469 = !DILocation(line: 1206, column: 23, scope: !1467)
!1470 = !DILocation(line: 1209, column: 14, scope: !1471)
!1471 = distinct !DILexicalBlock(scope: !1472, file: !3, line: 1209, column: 11)
!1472 = distinct !DILexicalBlock(scope: !1455, file: !3, line: 1208, column: 12)
!1473 = !DILocation(line: 1209, column: 11, scope: !1472)
!1474 = !DILocation(line: 1211, column: 16, scope: !1475)
!1475 = distinct !DILexicalBlock(scope: !1471, file: !3, line: 1209, column: 28)
!1476 = !DILocation(line: 1211, column: 30, scope: !1475)
!1477 = !DILocation(line: 1211, column: 23, scope: !1475)
!1478 = !DILocation(line: 1212, column: 7, scope: !1475)
!1479 = !DILocation(line: 1214, column: 18, scope: !1480)
!1480 = distinct !DILexicalBlock(scope: !1471, file: !3, line: 1212, column: 14)
!1481 = !DILocation(line: 0, scope: !1446)
!1482 = !DILocation(line: 1219, column: 9, scope: !2)
!1483 = !DILocation(line: 1220, column: 9, scope: !2)
!1484 = !DILocation(line: 1223, column: 63, scope: !2)
!1485 = !DILocation(line: 1223, column: 50, scope: !2)
!1486 = !DILocation(line: 1223, column: 37, scope: !2)
!1487 = !DILocation(line: 1223, column: 24, scope: !2)
!1488 = !DILocation(line: 1222, column: 19, scope: !2)
!1489 = !DILocation(line: 1222, column: 10, scope: !2)
!1490 = !DILocation(line: 1224, column: 58, scope: !2)
!1491 = !DILocation(line: 1224, column: 45, scope: !2)
!1492 = !DILocation(line: 1224, column: 32, scope: !2)
!1493 = !DILocation(line: 1224, column: 19, scope: !2)
!1494 = !DILocation(line: 1224, column: 10, scope: !2)
!1495 = !DILocation(line: 1225, column: 7, scope: !2)
!1496 = !DILocation(line: 1226, column: 24, scope: !1497)
!1497 = distinct !DILexicalBlock(scope: !1498, file: !3, line: 1225, column: 15)
!1498 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1225, column: 7)
!1499 = !DILocation(line: 1226, column: 14, scope: !1497)
!1500 = !DILocation(line: 1226, column: 5, scope: !1497)
!1501 = !DILocation(line: 1228, column: 9, scope: !1502)
!1502 = distinct !DILexicalBlock(scope: !1498, file: !3, line: 1227, column: 10)
!1503 = !DILocation(line: 1228, column: 32, scope: !1502)
!1504 = !DILocation(line: 1228, column: 40, scope: !1502)
!1505 = !DILocation(line: 1228, column: 38, scope: !1502)
!1506 = !DILocation(line: 1228, column: 52, scope: !1502)
!1507 = !DILocation(line: 1228, column: 20, scope: !1502)
!1508 = !DILocation(line: 1229, column: 16, scope: !1502)
!1509 = !DILocation(line: 1229, column: 12, scope: !1502)
!1510 = !DILocation(line: 1229, column: 5, scope: !1502)
!1511 = !DILocation(line: 1231, column: 1, scope: !2)
!1512 = !DILocation(line: 0, scope: !170)
!1513 = !DILocation(line: 0, scope: !873, inlinedAt: !1514)
!1514 = distinct !DILocation(line: 1273, column: 3, scope: !186)
!1515 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1514)
!1516 = !DILocation(line: 0, scope: !186)
!1517 = !DILocation(line: 1273, column: 3, scope: !186)
!1518 = !DILocation(line: 1274, column: 11, scope: !170)
!1519 = !DILocation(line: 0, scope: !873, inlinedAt: !1520)
!1520 = distinct !DILocation(line: 1275, column: 3, scope: !188)
!1521 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1520)
!1522 = !DILocation(line: 0, scope: !188)
!1523 = !DILocation(line: 1275, column: 3, scope: !188)
!1524 = !DILocation(line: 1276, column: 11, scope: !170)
!1525 = !DILocation(line: 1277, column: 49, scope: !1526)
!1526 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1277, column: 7)
!1527 = !DILocation(line: 1277, column: 12, scope: !1526)
!1528 = !DILocation(line: 1277, column: 57, scope: !1526)
!1529 = !DILocation(line: 1277, column: 71, scope: !1526)
!1530 = !DILocation(line: 1278, column: 49, scope: !1526)
!1531 = !DILocation(line: 1278, column: 12, scope: !1526)
!1532 = !DILocation(line: 1278, column: 57, scope: !1526)
!1533 = !DILocation(line: 1277, column: 7, scope: !170)
!1534 = !DILocation(line: 1279, column: 14, scope: !1535)
!1535 = distinct !DILexicalBlock(scope: !1526, file: !3, line: 1278, column: 72)
!1536 = !DILocation(line: 1279, column: 5, scope: !1535)
!1537 = !DILocalVariable(name: "a", arg: 1, scope: !1538, file: !3, line: 68, type: !18)
!1538 = distinct !DISubprogram(name: "sub_with_wraparound", scope: !3, file: !3, line: 68, type: !1539, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1541)
!1539 = !DISubroutineType(types: !1540)
!1540 = !{!18, !18, !18}
!1541 = !{!1537, !1542}
!1542 = !DILocalVariable(name: "b", arg: 2, scope: !1538, file: !3, line: 68, type: !18)
!1543 = !DILocation(line: 0, scope: !1538, inlinedAt: !1544)
!1544 = distinct !DILocation(line: 1281, column: 8, scope: !1545)
!1545 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1281, column: 7)
!1546 = !DILocation(line: 68, column: 96, scope: !1538, inlinedAt: !1544)
!1547 = !DILocation(line: 1281, column: 44, scope: !1545)
!1548 = !DILocation(line: 1281, column: 50, scope: !1545)
!1549 = !DILocation(line: 1281, column: 7, scope: !170)
!1550 = !DILocation(line: 1282, column: 12, scope: !1551)
!1551 = distinct !DILexicalBlock(scope: !1545, file: !3, line: 1281, column: 56)
!1552 = !DILocation(line: 1282, column: 5, scope: !1551)
!1553 = !DILocation(line: 1284, column: 12, scope: !170)
!1554 = !DILocation(line: 1284, column: 31, scope: !170)
!1555 = !DILocation(line: 1284, column: 38, scope: !170)
!1556 = !DILocation(line: 1284, column: 24, scope: !170)
!1557 = !DILocation(line: 1287, column: 11, scope: !1558)
!1558 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1287, column: 7)
!1559 = !DILocation(line: 1287, column: 17, scope: !1558)
!1560 = !DILocation(line: 1287, column: 7, scope: !170)
!1561 = !DILocation(line: 1288, column: 5, scope: !1562)
!1562 = distinct !DILexicalBlock(scope: !1558, file: !3, line: 1287, column: 23)
!1563 = !DILocation(line: 1293, column: 21, scope: !1564)
!1564 = distinct !DILexicalBlock(scope: !1562, file: !3, line: 1288, column: 16)
!1565 = !DILocation(line: 1293, column: 19, scope: !1564)
!1566 = !DILocation(line: 1293, column: 9, scope: !1564)
!1567 = !DILocation(line: 1295, column: 22, scope: !1564)
!1568 = !DILocation(line: 1295, column: 20, scope: !1564)
!1569 = !DILocation(line: 1295, column: 9, scope: !1564)
!1570 = !DILocation(line: 1299, column: 11, scope: !1571)
!1571 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1299, column: 7)
!1572 = !DILocation(line: 1299, column: 17, scope: !1571)
!1573 = !DILocation(line: 1299, column: 7, scope: !170)
!1574 = !DILocation(line: 1299, column: 34, scope: !1571)
!1575 = !DILocation(line: 1299, scope: !1571)
!1576 = !DILocation(line: 1299, column: 30, scope: !1571)
!1577 = !DILocation(line: 1299, column: 49, scope: !1571)
!1578 = !DILocation(line: 1299, column: 65, scope: !1571)
!1579 = !DILocation(line: 1302, column: 10, scope: !1580)
!1580 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1302, column: 7)
!1581 = !DILocation(line: 1302, column: 7, scope: !170)
!1582 = !DILocation(line: 1303, column: 9, scope: !1583)
!1583 = distinct !DILexicalBlock(scope: !1580, file: !3, line: 1302, column: 25)
!1584 = !DILocation(line: 1304, column: 7, scope: !1585)
!1585 = distinct !DILexicalBlock(scope: !1586, file: !3, line: 1303, column: 27)
!1586 = distinct !DILexicalBlock(scope: !1583, file: !3, line: 1303, column: 9)
!1587 = !DILocation(line: 1306, column: 27, scope: !1588)
!1588 = distinct !DILexicalBlock(scope: !1585, file: !3, line: 1304, column: 18)
!1589 = !DILocation(line: 1306, column: 25, scope: !1588)
!1590 = !DILocation(line: 1306, column: 11, scope: !1588)
!1591 = !DILocation(line: 1308, column: 28, scope: !1588)
!1592 = !DILocation(line: 1308, column: 26, scope: !1588)
!1593 = !DILocation(line: 1308, column: 11, scope: !1588)
!1594 = !DILocation(line: 1310, column: 33, scope: !1588)
!1595 = !DILocation(line: 1310, column: 31, scope: !1588)
!1596 = !DILocation(line: 1310, column: 11, scope: !1588)
!1597 = !DILocation(line: 1312, column: 34, scope: !1588)
!1598 = !DILocation(line: 1312, column: 32, scope: !1588)
!1599 = !DILocation(line: 1312, column: 11, scope: !1588)
!1600 = !DILocation(line: 1315, column: 7, scope: !1601)
!1601 = distinct !DILexicalBlock(scope: !1586, file: !3, line: 1314, column: 12)
!1602 = !DILocation(line: 1319, column: 11, scope: !1603)
!1603 = distinct !DILexicalBlock(scope: !1601, file: !3, line: 1315, column: 18)
!1604 = !DILocation(line: 1321, column: 23, scope: !1603)
!1605 = !DILocation(line: 1321, column: 21, scope: !1603)
!1606 = !DILocation(line: 1321, column: 11, scope: !1603)
!1607 = !DILocation(line: 1323, column: 24, scope: !1603)
!1608 = !DILocation(line: 1323, column: 22, scope: !1603)
!1609 = !DILocation(line: 1323, column: 11, scope: !1603)
!1610 = !DILocation(line: 1328, column: 7, scope: !170)
!1611 = !DILocation(line: 1328, column: 36, scope: !1612)
!1612 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1328, column: 7)
!1613 = !DILocation(line: 1328, scope: !1612)
!1614 = !DILocation(line: 1328, column: 32, scope: !1612)
!1615 = !DILocation(line: 1328, column: 51, scope: !1612)
!1616 = !DILocation(line: 1328, column: 67, scope: !1612)
!1617 = !DILocation(line: 1331, column: 11, scope: !170)
!1618 = !DILocation(line: 1331, column: 17, scope: !170)
!1619 = !DILocation(line: 1332, column: 9, scope: !1620)
!1620 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1332, column: 7)
!1621 = !DILocation(line: 1332, column: 7, scope: !170)
!1622 = !DILocation(line: 1333, column: 24, scope: !1623)
!1623 = distinct !DILexicalBlock(scope: !1620, file: !3, line: 1332, column: 15)
!1624 = !DILocation(line: 1333, column: 16, scope: !1623)
!1625 = !DILocation(line: 1335, column: 3, scope: !1623)
!1626 = !DILocation(line: 1335, column: 17, scope: !1627)
!1627 = distinct !DILexicalBlock(scope: !1620, file: !3, line: 1335, column: 14)
!1628 = !DILocation(line: 1335, column: 21, scope: !1627)
!1629 = !DILocation(line: 1338, column: 33, scope: !1630)
!1630 = distinct !DILexicalBlock(scope: !1627, file: !3, line: 1337, column: 10)
!1631 = !DILocation(line: 1338, column: 26, scope: !1630)
!1632 = !DILocation(line: 1338, column: 9, scope: !1630)
!1633 = !DILocation(line: 0, scope: !1620)
!1634 = !DILocation(line: 1340, column: 3, scope: !170)
!1635 = !DILocation(line: 1344, column: 14, scope: !1636)
!1636 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1340, column: 14)
!1637 = !DILocation(line: 1344, column: 7, scope: !1636)
!1638 = !DILocation(line: 1346, column: 24, scope: !1636)
!1639 = !DILocation(line: 1346, column: 17, scope: !1636)
!1640 = !DILocation(line: 1346, column: 7, scope: !1636)
!1641 = !DILocation(line: 1348, column: 19, scope: !1636)
!1642 = !DILocation(line: 1348, column: 17, scope: !1636)
!1643 = !DILocation(line: 1348, column: 26, scope: !1636)
!1644 = !DILocation(line: 1348, column: 7, scope: !1636)
!1645 = !DILocation(line: 1350, column: 1, scope: !170)
!1646 = distinct !DISubprogram(name: "pts_ieee754_cos", scope: !3, file: !3, line: 1382, type: !4, scopeLine: 1382, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1647)
!1647 = !{!1648, !1649, !1651, !1652, !1653, !1654}
!1648 = !DILocalVariable(name: "x", arg: 1, scope: !1646, file: !3, line: 1382, type: !6)
!1649 = !DILocalVariable(name: "y", scope: !1646, file: !3, line: 1383, type: !1650)
!1650 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 128, elements: !232)
!1651 = !DILocalVariable(name: "z", scope: !1646, file: !3, line: 1383, type: !6)
!1652 = !DILocalVariable(name: "n", scope: !1646, file: !3, line: 1384, type: !18)
!1653 = !DILocalVariable(name: "ix", scope: !1646, file: !3, line: 1384, type: !18)
!1654 = !DILocalVariable(name: "bits", scope: !1655, file: !3, line: 1387, type: !16)
!1655 = distinct !DILexicalBlock(scope: !1646, file: !3, line: 1387, column: 3)
!1656 = !DILocation(line: 0, scope: !1646)
!1657 = !DILocation(line: 1383, column: 3, scope: !1646)
!1658 = !DILocation(line: 1383, column: 10, scope: !1646)
!1659 = !DILocation(line: 0, scope: !873, inlinedAt: !1660)
!1660 = distinct !DILocation(line: 1387, column: 3, scope: !1655)
!1661 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1660)
!1662 = !DILocation(line: 0, scope: !1655)
!1663 = !DILocation(line: 1387, column: 3, scope: !1655)
!1664 = !DILocation(line: 1390, column: 6, scope: !1646)
!1665 = !DILocation(line: 1391, column: 10, scope: !1666)
!1666 = distinct !DILexicalBlock(scope: !1646, file: !3, line: 1391, column: 7)
!1667 = !DILocation(line: 1391, column: 7, scope: !1646)
!1668 = !DILocation(line: 0, scope: !607, inlinedAt: !1669)
!1669 = distinct !DILocation(line: 1392, column: 12, scope: !1670)
!1670 = distinct !DILexicalBlock(scope: !1666, file: !3, line: 1391, column: 25)
!1671 = !DILocation(line: 0, scope: !873, inlinedAt: !1672)
!1672 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1669)
!1673 = !DILocation(line: 0, scope: !618, inlinedAt: !1669)
!1674 = !DILocation(line: 350, column: 10, scope: !1675, inlinedAt: !1669)
!1675 = distinct !DILexicalBlock(scope: !607, file: !3, line: 350, column: 7)
!1676 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1669)
!1677 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1669)
!1678 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1669)
!1679 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1669)
!1680 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1669)
!1681 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1669)
!1682 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1669)
!1683 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1669)
!1684 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1669)
!1685 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1669)
!1686 = !DILocation(line: 356, column: 36, scope: !1687, inlinedAt: !1669)
!1687 = distinct !DILexicalBlock(scope: !624, file: !3, line: 355, column: 24)
!1688 = !DILocation(line: 356, column: 27, scope: !1687, inlinedAt: !1669)
!1689 = !DILocation(line: 356, column: 16, scope: !1687, inlinedAt: !1669)
!1690 = !DILocation(line: 356, column: 5, scope: !1687, inlinedAt: !1669)
!1691 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1669)
!1692 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1669)
!1693 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1669)
!1694 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1669)
!1695 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1669)
!1696 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1669)
!1697 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1669)
!1698 = !DILocation(line: 1393, column: 17, scope: !1699)
!1699 = distinct !DILexicalBlock(scope: !1666, file: !3, line: 1393, column: 14)
!1700 = !DILocation(line: 1393, column: 14, scope: !1666)
!1701 = !DILocation(line: 1395, column: 14, scope: !1702)
!1702 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 1393, column: 32)
!1703 = !DILocation(line: 1395, column: 5, scope: !1702)
!1704 = !DILocation(line: 1398, column: 9, scope: !1705)
!1705 = distinct !DILexicalBlock(scope: !1699, file: !3, line: 1396, column: 10)
!1706 = !DILocation(line: 1399, column: 15, scope: !1705)
!1707 = !DILocation(line: 0, scope: !1708)
!1708 = distinct !DILexicalBlock(scope: !1705, file: !3, line: 1399, column: 20)
!1709 = !DILocation(line: 1399, column: 5, scope: !1705)
!1710 = !DILocation(line: 1401, column: 35, scope: !1708)
!1711 = !DILocation(line: 0, scope: !607, inlinedAt: !1712)
!1712 = distinct !DILocation(line: 1401, column: 16, scope: !1708)
!1713 = !DILocation(line: 0, scope: !873, inlinedAt: !1714)
!1714 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1712)
!1715 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1714)
!1716 = !DILocation(line: 0, scope: !618, inlinedAt: !1712)
!1717 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1712)
!1718 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !1712)
!1719 = !DILocation(line: 350, column: 10, scope: !1675, inlinedAt: !1712)
!1720 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1712)
!1721 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1712)
!1722 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1712)
!1723 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1712)
!1724 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1712)
!1725 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1712)
!1726 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1712)
!1727 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1712)
!1728 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1712)
!1729 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1712)
!1730 = !DILocation(line: 356, column: 36, scope: !1687, inlinedAt: !1712)
!1731 = !DILocation(line: 356, column: 27, scope: !1687, inlinedAt: !1712)
!1732 = !DILocation(line: 356, column: 16, scope: !1687, inlinedAt: !1712)
!1733 = !DILocation(line: 356, column: 5, scope: !1687, inlinedAt: !1712)
!1734 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1712)
!1735 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1712)
!1736 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1712)
!1737 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1712)
!1738 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1712)
!1739 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1712)
!1740 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1712)
!1741 = !DILocation(line: 0, scope: !765, inlinedAt: !1742)
!1742 = distinct !DILocation(line: 1403, column: 17, scope: !1708)
!1743 = !DILocation(line: 0, scope: !873, inlinedAt: !1744)
!1744 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !1742)
!1745 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1744)
!1746 = !DILocation(line: 0, scope: !777, inlinedAt: !1742)
!1747 = !DILocation(line: 718, column: 10, scope: !1748, inlinedAt: !1742)
!1748 = distinct !DILexicalBlock(scope: !765, file: !3, line: 718, column: 7)
!1749 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !1742)
!1750 = !DILocation(line: 1403, column: 36, scope: !1708)
!1751 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !1742)
!1752 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !1742)
!1753 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !1742)
!1754 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !1742)
!1755 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !1742)
!1756 = !DILocation(line: 727, column: 32, scope: !1757, inlinedAt: !1742)
!1757 = distinct !DILexicalBlock(scope: !1758, file: !3, line: 726, column: 10)
!1758 = distinct !DILexicalBlock(scope: !765, file: !3, line: 724, column: 7)
!1759 = !DILocation(line: 727, column: 41, scope: !1757, inlinedAt: !1742)
!1760 = !DILocation(line: 727, column: 46, scope: !1757, inlinedAt: !1742)
!1761 = !DILocation(line: 727, column: 14, scope: !1757, inlinedAt: !1742)
!1762 = !DILocation(line: 727, column: 5, scope: !1757, inlinedAt: !1742)
!1763 = !DILocation(line: 1403, column: 16, scope: !1708)
!1764 = !DILocation(line: 1403, column: 9, scope: !1708)
!1765 = !DILocation(line: 1405, column: 36, scope: !1708)
!1766 = !DILocation(line: 0, scope: !607, inlinedAt: !1767)
!1767 = distinct !DILocation(line: 1405, column: 17, scope: !1708)
!1768 = !DILocation(line: 0, scope: !873, inlinedAt: !1769)
!1769 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1767)
!1770 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1769)
!1771 = !DILocation(line: 0, scope: !618, inlinedAt: !1767)
!1772 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1767)
!1773 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !1767)
!1774 = !DILocation(line: 350, column: 10, scope: !1675, inlinedAt: !1767)
!1775 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1767)
!1776 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1767)
!1777 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1767)
!1778 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1767)
!1779 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1767)
!1780 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1767)
!1781 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1767)
!1782 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1767)
!1783 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1767)
!1784 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1767)
!1785 = !DILocation(line: 356, column: 36, scope: !1687, inlinedAt: !1767)
!1786 = !DILocation(line: 356, column: 27, scope: !1687, inlinedAt: !1767)
!1787 = !DILocation(line: 356, column: 16, scope: !1687, inlinedAt: !1767)
!1788 = !DILocation(line: 356, column: 5, scope: !1687, inlinedAt: !1767)
!1789 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1767)
!1790 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1767)
!1791 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1767)
!1792 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1767)
!1793 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1767)
!1794 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1767)
!1795 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1767)
!1796 = !DILocation(line: 1405, column: 16, scope: !1708)
!1797 = !DILocation(line: 1405, column: 9, scope: !1708)
!1798 = !DILocation(line: 0, scope: !765, inlinedAt: !1799)
!1799 = distinct !DILocation(line: 1407, column: 16, scope: !1708)
!1800 = !DILocation(line: 0, scope: !873, inlinedAt: !1801)
!1801 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !1799)
!1802 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1801)
!1803 = !DILocation(line: 0, scope: !777, inlinedAt: !1799)
!1804 = !DILocation(line: 718, column: 10, scope: !1748, inlinedAt: !1799)
!1805 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !1799)
!1806 = !DILocation(line: 1407, column: 35, scope: !1708)
!1807 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !1799)
!1808 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !1799)
!1809 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !1799)
!1810 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !1799)
!1811 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !1799)
!1812 = !DILocation(line: 727, column: 32, scope: !1757, inlinedAt: !1799)
!1813 = !DILocation(line: 727, column: 41, scope: !1757, inlinedAt: !1799)
!1814 = !DILocation(line: 727, column: 46, scope: !1757, inlinedAt: !1799)
!1815 = !DILocation(line: 727, column: 14, scope: !1757, inlinedAt: !1799)
!1816 = !DILocation(line: 727, column: 5, scope: !1757, inlinedAt: !1799)
!1817 = !DILocation(line: 0, scope: !1666)
!1818 = !DILocation(line: 1410, column: 1, scope: !1646)
!1819 = !DILocation(line: 0, scope: !639)
!1820 = !DILocation(line: 198, column: 3, scope: !639)
!1821 = !DILocation(line: 198, column: 10, scope: !639)
!1822 = !DILocation(line: 0, scope: !873, inlinedAt: !1823)
!1823 = distinct !DILocation(line: 203, column: 3, scope: !664)
!1824 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1823)
!1825 = !DILocation(line: 0, scope: !664)
!1826 = !DILocation(line: 203, column: 3, scope: !664)
!1827 = !DILocation(line: 204, column: 11, scope: !639)
!1828 = !DILocation(line: 205, column: 10, scope: !1829)
!1829 = distinct !DILexicalBlock(scope: !639, file: !3, line: 205, column: 7)
!1830 = !DILocation(line: 205, column: 7, scope: !639)
!1831 = !DILocation(line: 206, column: 10, scope: !1832)
!1832 = distinct !DILexicalBlock(scope: !1829, file: !3, line: 205, column: 25)
!1833 = !DILocation(line: 207, column: 5, scope: !1832)
!1834 = !DILocation(line: 207, column: 10, scope: !1832)
!1835 = !DILocation(line: 208, column: 5, scope: !1832)
!1836 = !DILocation(line: 210, column: 10, scope: !1837)
!1837 = distinct !DILexicalBlock(scope: !639, file: !3, line: 210, column: 7)
!1838 = !DILocation(line: 210, column: 7, scope: !639)
!1839 = !DILocation(line: 211, column: 12, scope: !1840)
!1840 = distinct !DILexicalBlock(scope: !1841, file: !3, line: 211, column: 9)
!1841 = distinct !DILexicalBlock(scope: !1837, file: !3, line: 210, column: 24)
!1842 = !DILocation(line: 0, scope: !1840)
!1843 = !DILocation(line: 211, column: 9, scope: !1841)
!1844 = !DILocation(line: 212, column: 13, scope: !1845)
!1845 = distinct !DILexicalBlock(scope: !1840, file: !3, line: 211, column: 17)
!1846 = !DILocation(line: 213, column: 11, scope: !1845)
!1847 = !DILocation(line: 214, column: 18, scope: !1848)
!1848 = distinct !DILexicalBlock(scope: !1849, file: !3, line: 213, column: 29)
!1849 = distinct !DILexicalBlock(scope: !1845, file: !3, line: 213, column: 11)
!1850 = !DILocation(line: 214, column: 14, scope: !1848)
!1851 = !DILocation(line: 215, column: 19, scope: !1848)
!1852 = !DILocation(line: 215, column: 27, scope: !1848)
!1853 = !DILocation(line: 215, column: 9, scope: !1848)
!1854 = !DILocation(line: 215, column: 14, scope: !1848)
!1855 = !DILocation(line: 216, column: 7, scope: !1848)
!1856 = !DILocation(line: 217, column: 11, scope: !1857)
!1857 = distinct !DILexicalBlock(scope: !1849, file: !3, line: 216, column: 14)
!1858 = !DILocation(line: 218, column: 18, scope: !1857)
!1859 = !DILocation(line: 218, column: 14, scope: !1857)
!1860 = !DILocation(line: 219, column: 19, scope: !1857)
!1861 = !DILocation(line: 219, column: 27, scope: !1857)
!1862 = !DILocation(line: 219, column: 9, scope: !1857)
!1863 = !DILocation(line: 219, column: 14, scope: !1857)
!1864 = !DILocation(line: 223, column: 13, scope: !1865)
!1865 = distinct !DILexicalBlock(scope: !1840, file: !3, line: 222, column: 12)
!1866 = !DILocation(line: 224, column: 11, scope: !1865)
!1867 = !DILocation(line: 225, column: 18, scope: !1868)
!1868 = distinct !DILexicalBlock(scope: !1869, file: !3, line: 224, column: 29)
!1869 = distinct !DILexicalBlock(scope: !1865, file: !3, line: 224, column: 11)
!1870 = !DILocation(line: 225, column: 14, scope: !1868)
!1871 = !DILocation(line: 226, column: 19, scope: !1868)
!1872 = !DILocation(line: 226, column: 27, scope: !1868)
!1873 = !DILocation(line: 226, column: 9, scope: !1868)
!1874 = !DILocation(line: 226, column: 14, scope: !1868)
!1875 = !DILocation(line: 227, column: 7, scope: !1868)
!1876 = !DILocation(line: 228, column: 11, scope: !1877)
!1877 = distinct !DILexicalBlock(scope: !1869, file: !3, line: 227, column: 14)
!1878 = !DILocation(line: 229, column: 18, scope: !1877)
!1879 = !DILocation(line: 229, column: 14, scope: !1877)
!1880 = !DILocation(line: 230, column: 19, scope: !1877)
!1881 = !DILocation(line: 230, column: 27, scope: !1877)
!1882 = !DILocation(line: 230, column: 9, scope: !1877)
!1883 = !DILocation(line: 230, column: 14, scope: !1877)
!1884 = !DILocation(line: 235, column: 10, scope: !669)
!1885 = !DILocation(line: 235, column: 7, scope: !639)
!1886 = !DILocation(line: 236, column: 9, scope: !668)
!1887 = !DILocation(line: 237, column: 31, scope: !668)
!1888 = !DILocation(line: 237, column: 9, scope: !668)
!1889 = !DILocation(line: 238, column: 10, scope: !668)
!1890 = !DILocation(line: 239, column: 11, scope: !668)
!1891 = !DILocation(line: 240, column: 12, scope: !668)
!1892 = !DILocation(line: 241, column: 11, scope: !667)
!1893 = !DILocation(line: 241, column: 16, scope: !667)
!1894 = !DILocation(line: 241, column: 36, scope: !667)
!1895 = !DILocation(line: 241, column: 25, scope: !667)
!1896 = !{!1897, !1897, i64 0}
!1897 = !{!"int", !1438, i64 0}
!1898 = !DILocation(line: 241, column: 22, scope: !667)
!1899 = !DILocation(line: 241, column: 9, scope: !668)
!1900 = !DILocation(line: 242, column: 16, scope: !1901)
!1901 = distinct !DILexicalBlock(scope: !667, file: !3, line: 241, column: 42)
!1902 = !DILocation(line: 243, column: 5, scope: !1901)
!1903 = !DILocation(line: 246, column: 16, scope: !666)
!1904 = !DILocation(line: 246, column: 12, scope: !666)
!1905 = !DILocation(line: 0, scope: !873, inlinedAt: !1906)
!1906 = distinct !DILocation(line: 247, column: 7, scope: !671)
!1907 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1906)
!1908 = !DILocation(line: 0, scope: !671)
!1909 = !DILocation(line: 0, scope: !666)
!1910 = !DILocation(line: 248, column: 22, scope: !666)
!1911 = !DILocation(line: 248, column: 29, scope: !666)
!1912 = !DILocation(line: 248, column: 13, scope: !666)
!1913 = !DILocation(line: 249, column: 13, scope: !675)
!1914 = !DILocation(line: 249, column: 11, scope: !666)
!1915 = !DILocation(line: 251, column: 16, scope: !674)
!1916 = !DILocation(line: 252, column: 15, scope: !674)
!1917 = !DILocation(line: 253, column: 32, scope: !674)
!1918 = !DILocation(line: 253, column: 37, scope: !674)
!1919 = !DILocation(line: 253, column: 26, scope: !674)
!1920 = !DILocation(line: 254, column: 18, scope: !674)
!1921 = !DILocation(line: 254, column: 14, scope: !674)
!1922 = !DILocation(line: 0, scope: !873, inlinedAt: !1923)
!1923 = distinct !DILocation(line: 255, column: 9, scope: !673)
!1924 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !1923)
!1925 = !DILocation(line: 0, scope: !673)
!1926 = !DILocation(line: 256, column: 24, scope: !674)
!1927 = !DILocation(line: 256, column: 31, scope: !674)
!1928 = !DILocation(line: 256, column: 15, scope: !674)
!1929 = !DILocation(line: 257, column: 15, scope: !1930)
!1930 = distinct !DILexicalBlock(scope: !674, file: !3, line: 257, column: 13)
!1931 = !DILocation(line: 257, column: 13, scope: !674)
!1932 = !DILocation(line: 259, column: 18, scope: !1933)
!1933 = distinct !DILexicalBlock(scope: !1930, file: !3, line: 257, column: 21)
!1934 = !DILocation(line: 260, column: 17, scope: !1933)
!1935 = !DILocation(line: 261, column: 34, scope: !1933)
!1936 = !DILocation(line: 261, column: 39, scope: !1933)
!1937 = !DILocation(line: 261, column: 28, scope: !1933)
!1938 = !DILocation(line: 262, column: 20, scope: !1933)
!1939 = !DILocation(line: 263, column: 9, scope: !1933)
!1940 = !DILocation(line: 0, scope: !667)
!1941 = !DILocation(line: 266, column: 15, scope: !668)
!1942 = !DILocation(line: 266, column: 17, scope: !668)
!1943 = !DILocation(line: 0, scope: !668)
!1944 = !DILocation(line: 266, column: 23, scope: !668)
!1945 = !DILocation(line: 266, column: 5, scope: !668)
!1946 = !DILocation(line: 266, column: 10, scope: !668)
!1947 = !DILocation(line: 267, column: 12, scope: !1948)
!1948 = distinct !DILexicalBlock(scope: !668, file: !3, line: 267, column: 9)
!1949 = !DILocation(line: 267, column: 9, scope: !668)
!1950 = !DILocation(line: 268, column: 14, scope: !1951)
!1951 = distinct !DILexicalBlock(scope: !1948, file: !3, line: 267, column: 17)
!1952 = !DILocation(line: 268, column: 12, scope: !1951)
!1953 = !DILocation(line: 269, column: 14, scope: !1951)
!1954 = !DILocation(line: 269, column: 12, scope: !1951)
!1955 = !DILocation(line: 270, column: 14, scope: !1951)
!1956 = !DILocation(line: 270, column: 7, scope: !1951)
!1957 = !DILocation(line: 278, column: 10, scope: !1958)
!1958 = distinct !DILexicalBlock(scope: !639, file: !3, line: 278, column: 7)
!1959 = !DILocation(line: 278, column: 7, scope: !639)
!1960 = !DILocation(line: 279, column: 21, scope: !1961)
!1961 = distinct !DILexicalBlock(scope: !1958, file: !3, line: 278, column: 25)
!1962 = !DILocation(line: 279, column: 12, scope: !1961)
!1963 = !DILocation(line: 279, column: 17, scope: !1961)
!1964 = !DILocation(line: 279, column: 10, scope: !1961)
!1965 = !DILocation(line: 280, column: 5, scope: !1961)
!1966 = !DILocation(line: 0, scope: !873, inlinedAt: !1967)
!1967 = distinct !DILocation(line: 283, column: 3, scope: !677)
!1968 = !DILocation(line: 0, scope: !873, inlinedAt: !1969)
!1969 = distinct !DILocation(line: 284, column: 3, scope: !679)
!1970 = !DILocation(line: 0, scope: !679)
!1971 = !DILocation(line: 284, column: 3, scope: !679)
!1972 = !DILocation(line: 0, scope: !947, inlinedAt: !1973)
!1973 = distinct !DILocation(line: 284, column: 3, scope: !679)
!1974 = !DILocation(line: 285, column: 19, scope: !639)
!1975 = !DILocation(line: 0, scope: !873, inlinedAt: !1976)
!1976 = distinct !DILocation(line: 286, column: 3, scope: !681)
!1977 = !DILocation(line: 0, scope: !681)
!1978 = !DILocation(line: 286, column: 3, scope: !681)
!1979 = !DILocation(line: 0, scope: !947, inlinedAt: !1980)
!1980 = distinct !DILocation(line: 286, column: 3, scope: !681)
!1981 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !1980)
!1982 = !DILocation(line: 288, column: 22, scope: !1983)
!1983 = distinct !DILexicalBlock(scope: !1984, file: !3, line: 287, column: 27)
!1984 = distinct !DILexicalBlock(scope: !1985, file: !3, line: 287, column: 3)
!1985 = distinct !DILexicalBlock(scope: !639, file: !3, line: 287, column: 3)
!1986 = !DILocation(line: 288, column: 13, scope: !1983)
!1987 = !DILocation(line: 288, column: 11, scope: !1983)
!1988 = !DILocation(line: 289, column: 12, scope: !1983)
!1989 = !DILocation(line: 289, column: 21, scope: !1983)
!1990 = !DILocation(line: 288, column: 5, scope: !1983)
!1991 = !DILocation(line: 291, column: 3, scope: !639)
!1992 = !DILocation(line: 291, column: 9, scope: !639)
!1993 = !DILocation(line: 293, column: 3, scope: !639)
!1994 = !DILocation(line: 293, column: 16, scope: !639)
!1995 = !DILocation(line: 293, column: 10, scope: !639)
!1996 = !DILocation(line: 293, column: 21, scope: !639)
!1997 = distinct !{!1997, !1993, !1998, !1999}
!1998 = !DILocation(line: 293, column: 32, scope: !639)
!1999 = !{!"llvm.loop.mustprogress"}
!2000 = !DILocation(line: 501, column: 3, scope: !713, inlinedAt: !2001)
!2001 = distinct !DILocation(line: 294, column: 7, scope: !639)
!2002 = !DILocation(line: 0, scope: !713, inlinedAt: !2001)
!2003 = !DILocation(line: 501, column: 41, scope: !713, inlinedAt: !2001)
!2004 = !DILocation(line: 502, column: 3, scope: !713, inlinedAt: !2001)
!2005 = !DILocation(line: 502, column: 17, scope: !713, inlinedAt: !2001)
!2006 = !DILocation(line: 502, column: 24, scope: !713, inlinedAt: !2001)
!2007 = !DILocation(line: 502, column: 32, scope: !713, inlinedAt: !2001)
!2008 = !DILocation(line: 510, column: 12, scope: !713, inlinedAt: !2001)
!2009 = !DILocation(line: 510, column: 17, scope: !713, inlinedAt: !2001)
!2010 = !DILocation(line: 512, column: 16, scope: !713, inlinedAt: !2001)
!2011 = !DILocation(line: 512, column: 11, scope: !713, inlinedAt: !2001)
!2012 = !DILocation(line: 517, column: 17, scope: !2013, inlinedAt: !2001)
!2013 = distinct !DILexicalBlock(scope: !2014, file: !3, line: 517, column: 3)
!2014 = distinct !DILexicalBlock(scope: !713, file: !3, line: 517, column: 3)
!2015 = !DILocation(line: 517, column: 3, scope: !2014, inlinedAt: !2001)
!2016 = !DILocation(line: 516, column: 10, scope: !713, inlinedAt: !2001)
!2017 = !DILocation(line: 515, column: 10, scope: !713, inlinedAt: !2001)
!2018 = !DILocation(line: 523, column: 5, scope: !2019, inlinedAt: !2001)
!2019 = distinct !DILexicalBlock(scope: !2020, file: !3, line: 523, column: 5)
!2020 = distinct !DILexicalBlock(scope: !2021, file: !3, line: 522, column: 29)
!2021 = distinct !DILexicalBlock(scope: !2022, file: !3, line: 522, column: 3)
!2022 = distinct !DILexicalBlock(scope: !713, file: !3, line: 522, column: 3)
!2023 = !DILocation(line: 518, column: 15, scope: !2024, inlinedAt: !2001)
!2024 = distinct !DILexicalBlock(scope: !2013, file: !3, line: 517, column: 33)
!2025 = !DILocation(line: 518, column: 12, scope: !2024, inlinedAt: !2001)
!2026 = !DILocation(line: 518, column: 38, scope: !2024, inlinedAt: !2001)
!2027 = !DILocation(line: 518, column: 29, scope: !2024, inlinedAt: !2001)
!2028 = !DILocation(line: 518, column: 5, scope: !2024, inlinedAt: !2001)
!2029 = !DILocation(line: 518, column: 10, scope: !2024, inlinedAt: !2001)
!2030 = !DILocation(line: 517, column: 24, scope: !2013, inlinedAt: !2001)
!2031 = !DILocation(line: 517, column: 29, scope: !2013, inlinedAt: !2001)
!2032 = distinct !{!2032, !2015, !2033, !1999}
!2033 = !DILocation(line: 519, column: 3, scope: !2014, inlinedAt: !2001)
!2034 = !DILocation(line: 523, column: 29, scope: !2035, inlinedAt: !2001)
!2035 = distinct !DILexicalBlock(scope: !2019, file: !3, line: 523, column: 5)
!2036 = !DILocation(line: 523, column: 37, scope: !2035, inlinedAt: !2001)
!2037 = !DILocation(line: 523, column: 47, scope: !2035, inlinedAt: !2001)
!2038 = !DILocation(line: 523, column: 63, scope: !2035, inlinedAt: !2001)
!2039 = !DILocation(line: 523, column: 54, scope: !2035, inlinedAt: !2001)
!2040 = distinct !{!2040, !2018, !2041, !1999, !2042, !2043}
!2041 = !DILocation(line: 523, column: 66, scope: !2019, inlinedAt: !2001)
!2042 = !{!"llvm.loop.isvectorized", i32 1}
!2043 = !{!"llvm.loop.unroll.runtime.disable"}
!2044 = !DILocation(line: 523, column: 44, scope: !2035, inlinedAt: !2001)
!2045 = distinct !{!2045, !2018, !2041, !1999, !2042}
!2046 = !DILocation(line: 524, column: 10, scope: !2020, inlinedAt: !2001)
!2047 = distinct !{!2047, !2018, !2041, !1999, !2042, !2043}
!2048 = distinct !{!2048, !2018, !2041, !1999, !2042}
!2049 = !DILocation(line: 524, column: 5, scope: !2020, inlinedAt: !2001)
!2050 = distinct !{!2050, !2018, !2041, !1999, !2042, !2043}
!2051 = distinct !{!2051, !2018, !2041, !1999, !2042}
!2052 = distinct !{!2052, !2018, !2041, !1999, !2042, !2043}
!2053 = distinct !{!2053, !2018, !2041, !1999, !2042}
!2054 = distinct !{!2054, !2018, !2041, !1999, !2042, !2043}
!2055 = distinct !{!2055, !2018, !2041, !1999, !2042}
!2056 = !DILocation(line: 523, scope: !2019, inlinedAt: !2001)
!2057 = !DILocation(line: 530, column: 8, scope: !2058, inlinedAt: !2001)
!2058 = distinct !DILexicalBlock(scope: !713, file: !3, line: 530, column: 3)
!2059 = !DILocation(line: 530, column: 27, scope: !2058, inlinedAt: !2001)
!2060 = !DILocation(line: 592, column: 7, scope: !2061, inlinedAt: !2001)
!2061 = distinct !DILexicalBlock(scope: !2062, file: !3, line: 592, column: 7)
!2062 = distinct !DILexicalBlock(scope: !2063, file: !3, line: 587, column: 17)
!2063 = distinct !DILexicalBlock(scope: !2064, file: !3, line: 587, column: 9)
!2064 = distinct !DILexicalBlock(scope: !2065, file: !3, line: 584, column: 18)
!2065 = distinct !DILexicalBlock(scope: !713, file: !3, line: 584, column: 7)
!2066 = distinct !{!2066, !2060, !2067, !1999}
!2067 = !DILocation(line: 596, column: 7, scope: !2061, inlinedAt: !2001)
!2068 = !DILocation(line: 528, column: 1, scope: !713, inlinedAt: !2001)
!2069 = !DILocation(line: 530, column: 3, scope: !2058, inlinedAt: !2001)
!2070 = !DILocation(line: 531, column: 36, scope: !2071, inlinedAt: !2001)
!2071 = distinct !DILexicalBlock(scope: !2072, file: !3, line: 530, column: 51)
!2072 = distinct !DILexicalBlock(scope: !2058, file: !3, line: 530, column: 3)
!2073 = !DILocation(line: 531, column: 19, scope: !2071, inlinedAt: !2001)
!2074 = !DILocation(line: 531, column: 10, scope: !2071, inlinedAt: !2001)
!2075 = !DILocation(line: 532, column: 25, scope: !2071, inlinedAt: !2001)
!2076 = !DILocation(line: 532, column: 13, scope: !2071, inlinedAt: !2001)
!2077 = !DILocation(line: 532, column: 5, scope: !2071, inlinedAt: !2001)
!2078 = !DILocation(line: 532, column: 11, scope: !2071, inlinedAt: !2001)
!2079 = !DILocation(line: 533, column: 13, scope: !2071, inlinedAt: !2001)
!2080 = !DILocation(line: 533, column: 9, scope: !2071, inlinedAt: !2001)
!2081 = !DILocation(line: 533, column: 18, scope: !2071, inlinedAt: !2001)
!2082 = !DILocation(line: 530, column: 42, scope: !2072, inlinedAt: !2001)
!2083 = !DILocation(line: 530, column: 36, scope: !2072, inlinedAt: !2001)
!2084 = distinct !{!2084, !2069, !2085, !1999}
!2085 = !DILocation(line: 534, column: 3, scope: !2058, inlinedAt: !2001)
!2086 = !DILocation(line: 537, column: 7, scope: !713, inlinedAt: !2001)
!2087 = !DILocation(line: 538, column: 22, scope: !713, inlinedAt: !2001)
!2088 = !DILocation(line: 538, column: 14, scope: !713, inlinedAt: !2001)
!2089 = !DILocation(line: 538, column: 5, scope: !713, inlinedAt: !2001)
!2090 = !DILocation(line: 539, column: 7, scope: !713, inlinedAt: !2001)
!2091 = !DILocation(line: 540, column: 8, scope: !713, inlinedAt: !2001)
!2092 = !DILocation(line: 540, column: 5, scope: !713, inlinedAt: !2001)
!2093 = !DILocation(line: 542, column: 7, scope: !713, inlinedAt: !2001)
!2094 = !DILocation(line: 543, column: 16, scope: !2095, inlinedAt: !2001)
!2095 = distinct !DILexicalBlock(scope: !2096, file: !3, line: 542, column: 15)
!2096 = distinct !DILexicalBlock(scope: !713, file: !3, line: 542, column: 7)
!2097 = !DILocation(line: 543, column: 10, scope: !2095, inlinedAt: !2001)
!2098 = !DILocation(line: 543, column: 21, scope: !2095, inlinedAt: !2001)
!2099 = !DILocation(line: 544, column: 7, scope: !2095, inlinedAt: !2001)
!2100 = !DILocation(line: 545, column: 21, scope: !2095, inlinedAt: !2001)
!2101 = !DILocation(line: 545, column: 16, scope: !2095, inlinedAt: !2001)
!2102 = !DILocation(line: 546, column: 21, scope: !2095, inlinedAt: !2001)
!2103 = !DILocation(line: 547, column: 3, scope: !2095, inlinedAt: !2001)
!2104 = !DILocation(line: 547, column: 14, scope: !2096, inlinedAt: !2001)
!2105 = !DILocation(line: 548, column: 16, scope: !2106, inlinedAt: !2001)
!2106 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 547, column: 23)
!2107 = distinct !DILexicalBlock(scope: !2096, file: !3, line: 547, column: 14)
!2108 = !DILocation(line: 548, column: 10, scope: !2106, inlinedAt: !2001)
!2109 = !DILocation(line: 548, column: 21, scope: !2106, inlinedAt: !2001)
!2110 = !DILocation(line: 549, column: 3, scope: !2106, inlinedAt: !2001)
!2111 = !DILocation(line: 549, column: 16, scope: !2112, inlinedAt: !2001)
!2112 = distinct !DILexicalBlock(scope: !2107, file: !3, line: 549, column: 14)
!2113 = !DILocation(line: 549, column: 14, scope: !2107, inlinedAt: !2001)
!2114 = !DILocation(line: 553, column: 10, scope: !2115, inlinedAt: !2001)
!2115 = distinct !DILexicalBlock(scope: !713, file: !3, line: 553, column: 7)
!2116 = !DILocation(line: 553, column: 7, scope: !713, inlinedAt: !2001)
!2117 = !DILocation(line: 556, column: 5, scope: !2118, inlinedAt: !2001)
!2118 = distinct !DILexicalBlock(scope: !2119, file: !3, line: 556, column: 5)
!2119 = distinct !DILexicalBlock(scope: !2115, file: !3, line: 553, column: 15)
!2120 = !DILocation(line: 557, column: 11, scope: !2121, inlinedAt: !2001)
!2121 = distinct !DILexicalBlock(scope: !2122, file: !3, line: 556, column: 30)
!2122 = distinct !DILexicalBlock(scope: !2118, file: !3, line: 556, column: 5)
!2123 = !DILocation(line: 558, column: 17, scope: !2124, inlinedAt: !2001)
!2124 = distinct !DILexicalBlock(scope: !2121, file: !3, line: 558, column: 11)
!2125 = !DILocation(line: 558, column: 11, scope: !2121, inlinedAt: !2001)
!2126 = !DILocation(line: 559, column: 15, scope: !2127, inlinedAt: !2001)
!2127 = distinct !DILexicalBlock(scope: !2128, file: !3, line: 559, column: 13)
!2128 = distinct !DILexicalBlock(scope: !2124, file: !3, line: 558, column: 23)
!2129 = !DILocation(line: 559, column: 13, scope: !2128, inlinedAt: !2001)
!2130 = !DILocation(line: 0, scope: !2124, inlinedAt: !2001)
!2131 = !DILocation(line: 556, column: 26, scope: !2122, inlinedAt: !2001)
!2132 = !DILocation(line: 0, scope: !2119, inlinedAt: !2001)
!2133 = !DILocation(line: 556, column: 19, scope: !2122, inlinedAt: !2001)
!2134 = distinct !{!2134, !2117, !2135, !1999}
!2135 = !DILocation(line: 566, column: 5, scope: !2118, inlinedAt: !2001)
!2136 = !DILocation(line: 554, column: 7, scope: !2119, inlinedAt: !2001)
!2137 = !DILocation(line: 567, column: 9, scope: !2119, inlinedAt: !2001)
!2138 = !DILocation(line: 568, column: 7, scope: !2139, inlinedAt: !2001)
!2139 = distinct !DILexicalBlock(scope: !2140, file: !3, line: 567, column: 17)
!2140 = distinct !DILexicalBlock(scope: !2119, file: !3, line: 567, column: 9)
!2141 = !DILocation(line: 574, column: 11, scope: !2142, inlinedAt: !2001)
!2142 = distinct !DILexicalBlock(scope: !2139, file: !3, line: 568, column: 19)
!2143 = !DILocation(line: 0, scope: !2142, inlinedAt: !2001)
!2144 = !DILocation(line: 577, column: 12, scope: !2145, inlinedAt: !2001)
!2145 = distinct !DILexicalBlock(scope: !2119, file: !3, line: 577, column: 9)
!2146 = !DILocation(line: 577, column: 9, scope: !2119, inlinedAt: !2001)
!2147 = !DILocation(line: 578, column: 15, scope: !2148, inlinedAt: !2001)
!2148 = distinct !DILexicalBlock(scope: !2145, file: !3, line: 577, column: 18)
!2149 = !DILocation(line: 579, column: 11, scope: !2148, inlinedAt: !2001)
!2150 = !DILocation(line: 579, column: 28, scope: !2151, inlinedAt: !2001)
!2151 = distinct !DILexicalBlock(scope: !2148, file: !3, line: 579, column: 11)
!2152 = !DILocation(line: 579, column: 25, scope: !2151, inlinedAt: !2001)
!2153 = !DILocation(line: 579, column: 23, scope: !2151, inlinedAt: !2001)
!2154 = !DILocation(line: 584, column: 9, scope: !2065, inlinedAt: !2001)
!2155 = !DILocation(line: 584, column: 7, scope: !713, inlinedAt: !2001)
!2156 = !DILocation(line: 586, column: 24, scope: !2157, inlinedAt: !2001)
!2157 = distinct !DILexicalBlock(scope: !2158, file: !3, line: 586, column: 5)
!2158 = distinct !DILexicalBlock(scope: !2064, file: !3, line: 586, column: 5)
!2159 = !DILocation(line: 586, column: 5, scope: !2158, inlinedAt: !2001)
!2160 = !DILocation(line: 586, scope: !2158, inlinedAt: !2001)
!2161 = !DILocation(line: 586, column: 41, scope: !2157, inlinedAt: !2001)
!2162 = !DILocation(line: 586, column: 38, scope: !2157, inlinedAt: !2001)
!2163 = distinct !{!2163, !2159, !2164, !1999, !2042, !2043}
!2164 = !DILocation(line: 586, column: 45, scope: !2158, inlinedAt: !2001)
!2165 = distinct !{!2165, !2159, !2164, !1999, !2043, !2042}
!2166 = !DILocation(line: 587, column: 11, scope: !2063, inlinedAt: !2001)
!2167 = !DILocation(line: 587, column: 9, scope: !2064, inlinedAt: !2001)
!2168 = !DILocation(line: 588, column: 30, scope: !2169, inlinedAt: !2001)
!2169 = distinct !DILexicalBlock(scope: !2170, file: !3, line: 588, column: 7)
!2170 = distinct !DILexicalBlock(scope: !2062, file: !3, line: 588, column: 7)
!2171 = !DILocation(line: 588, column: 41, scope: !2169, inlinedAt: !2001)
!2172 = !DILocation(line: 588, column: 7, scope: !2170, inlinedAt: !2001)
!2173 = !DILocation(line: 588, scope: !2170, inlinedAt: !2001)
!2174 = !DILocation(line: 592, column: 26, scope: !2175, inlinedAt: !2001)
!2175 = distinct !DILexicalBlock(scope: !2061, file: !3, line: 592, column: 7)
!2176 = !DILocation(line: 592, scope: !2061, inlinedAt: !2001)
!2177 = !DILocation(line: 593, column: 21, scope: !2178, inlinedAt: !2001)
!2178 = distinct !DILexicalBlock(scope: !2175, file: !3, line: 592, column: 42)
!2179 = !DILocation(line: 593, column: 14, scope: !2178, inlinedAt: !2001)
!2180 = !DILocation(line: 593, column: 9, scope: !2178, inlinedAt: !2001)
!2181 = !DILocation(line: 593, column: 19, scope: !2178, inlinedAt: !2001)
!2182 = !DILocation(line: 594, column: 9, scope: !2183, inlinedAt: !2001)
!2183 = distinct !DILexicalBlock(scope: !2178, file: !3, line: 594, column: 9)
!2184 = !DILocation(line: 594, column: 41, scope: !2185, inlinedAt: !2001)
!2185 = distinct !DILexicalBlock(scope: !2183, file: !3, line: 594, column: 9)
!2186 = !DILocation(line: 594, column: 51, scope: !2185, inlinedAt: !2001)
!2187 = !DILocation(line: 594, column: 67, scope: !2185, inlinedAt: !2001)
!2188 = !DILocation(line: 594, column: 58, scope: !2185, inlinedAt: !2001)
!2189 = distinct !{!2189, !2182, !2190, !1999, !2042, !2043}
!2190 = !DILocation(line: 594, column: 70, scope: !2183, inlinedAt: !2001)
!2191 = !DILocation(line: 594, column: 48, scope: !2185, inlinedAt: !2001)
!2192 = !DILocation(line: 594, column: 33, scope: !2185, inlinedAt: !2001)
!2193 = distinct !{!2193, !2182, !2190, !1999, !2043, !2042}
!2194 = !DILocation(line: 594, scope: !2183, inlinedAt: !2001)
!2195 = !DILocation(line: 595, column: 9, scope: !2178, inlinedAt: !2001)
!2196 = !DILocation(line: 595, column: 14, scope: !2178, inlinedAt: !2001)
!2197 = distinct !{!2197, !2060, !2067, !1999}
!2198 = !DILocation(line: 0, scope: !2199, inlinedAt: !2001)
!2199 = distinct !DILexicalBlock(scope: !2200, file: !3, line: 603, column: 17)
!2200 = distinct !DILexicalBlock(scope: !713, file: !3, line: 603, column: 7)
!2201 = !DILocation(line: 606, column: 12, scope: !2199, inlinedAt: !2001)
!2202 = !DILocation(line: 606, column: 19, scope: !2199, inlinedAt: !2001)
!2203 = !DILocation(line: 606, column: 5, scope: !2199, inlinedAt: !2001)
!2204 = distinct !{!2204, !2203, !2205, !1999}
!2205 = !DILocation(line: 609, column: 5, scope: !2199, inlinedAt: !2001)
!2206 = !DILocation(line: 611, column: 19, scope: !2207, inlinedAt: !2001)
!2207 = distinct !DILexicalBlock(scope: !2200, file: !3, line: 610, column: 10)
!2208 = !DILocation(line: 611, column: 9, scope: !2207, inlinedAt: !2001)
!2209 = !DILocation(line: 612, column: 11, scope: !2210, inlinedAt: !2001)
!2210 = distinct !DILexicalBlock(scope: !2207, file: !3, line: 612, column: 9)
!2211 = !DILocation(line: 612, column: 9, scope: !2207, inlinedAt: !2001)
!2212 = !DILocation(line: 613, column: 38, scope: !2213, inlinedAt: !2001)
!2213 = distinct !DILexicalBlock(scope: !2210, file: !3, line: 612, column: 21)
!2214 = !DILocation(line: 613, column: 21, scope: !2213, inlinedAt: !2001)
!2215 = !DILocation(line: 613, column: 12, scope: !2213, inlinedAt: !2001)
!2216 = !DILocation(line: 614, column: 18, scope: !2213, inlinedAt: !2001)
!2217 = !DILocation(line: 614, column: 16, scope: !2213, inlinedAt: !2001)
!2218 = !DILocation(line: 614, column: 7, scope: !2213, inlinedAt: !2001)
!2219 = !DILocation(line: 614, column: 14, scope: !2213, inlinedAt: !2001)
!2220 = !DILocation(line: 615, column: 10, scope: !2213, inlinedAt: !2001)
!2221 = !DILocation(line: 617, column: 7, scope: !2213, inlinedAt: !2001)
!2222 = !DILocation(line: 617, column: 14, scope: !2213, inlinedAt: !2001)
!2223 = !DILocation(line: 618, column: 5, scope: !2213, inlinedAt: !2001)
!2224 = !DILocation(line: 619, column: 16, scope: !2225, inlinedAt: !2001)
!2225 = distinct !DILexicalBlock(scope: !2210, file: !3, line: 618, column: 12)
!2226 = !DILocation(line: 619, column: 7, scope: !2225, inlinedAt: !2001)
!2227 = !DILocation(line: 619, column: 14, scope: !2225, inlinedAt: !2001)
!2228 = !DILocation(line: 624, column: 8, scope: !713, inlinedAt: !2001)
!2229 = !DILocation(line: 625, column: 18, scope: !2230, inlinedAt: !2001)
!2230 = distinct !DILexicalBlock(scope: !2231, file: !3, line: 625, column: 3)
!2231 = distinct !DILexicalBlock(scope: !713, file: !3, line: 625, column: 3)
!2232 = !DILocation(line: 625, column: 3, scope: !2231, inlinedAt: !2001)
!2233 = !DILocation(line: 647, column: 18, scope: !2234, inlinedAt: !2001)
!2234 = distinct !DILexicalBlock(scope: !713, file: !3, line: 637, column: 17)
!2235 = !DILocation(line: 647, column: 14, scope: !2234, inlinedAt: !2001)
!2236 = !DILocation(line: 647, column: 12, scope: !2234, inlinedAt: !2001)
!2237 = !DILocation(line: 649, column: 7, scope: !2238, inlinedAt: !2001)
!2238 = distinct !DILexicalBlock(scope: !2234, file: !3, line: 649, column: 7)
!2239 = !DILocation(line: 626, column: 17, scope: !2240, inlinedAt: !2001)
!2240 = distinct !DILexicalBlock(scope: !2230, file: !3, line: 625, column: 29)
!2241 = !DILocation(line: 626, column: 15, scope: !2240, inlinedAt: !2001)
!2242 = !DILocation(line: 626, column: 5, scope: !2240, inlinedAt: !2001)
!2243 = !DILocation(line: 626, column: 10, scope: !2240, inlinedAt: !2001)
!2244 = !DILocation(line: 627, column: 8, scope: !2240, inlinedAt: !2001)
!2245 = !DILocation(line: 625, column: 25, scope: !2230, inlinedAt: !2001)
!2246 = distinct !{!2246, !2232, !2247, !1999}
!2247 = !DILocation(line: 628, column: 3, scope: !2231, inlinedAt: !2001)
!2248 = !DILocation(line: 632, column: 72, scope: !2249, inlinedAt: !2001)
!2249 = distinct !DILexicalBlock(scope: !2250, file: !3, line: 632, column: 5)
!2250 = distinct !DILexicalBlock(scope: !2251, file: !3, line: 632, column: 5)
!2251 = distinct !DILexicalBlock(scope: !2252, file: !3, line: 631, column: 29)
!2252 = distinct !DILexicalBlock(scope: !2253, file: !3, line: 631, column: 3)
!2253 = distinct !DILexicalBlock(scope: !713, file: !3, line: 631, column: 3)
!2254 = !DILocation(line: 632, column: 59, scope: !2249, inlinedAt: !2001)
!2255 = !DILocation(line: 632, column: 35, scope: !2249, inlinedAt: !2001)
!2256 = distinct !{!2256, !2257, !2258, !1999}
!2257 = !DILocation(line: 632, column: 5, scope: !2250, inlinedAt: !2001)
!2258 = !DILocation(line: 632, column: 79, scope: !2250, inlinedAt: !2001)
!2259 = !DILocation(line: 632, column: 76, scope: !2249, inlinedAt: !2001)
!2260 = !DILocation(line: 633, column: 5, scope: !2251, inlinedAt: !2001)
!2261 = !DILocation(line: 633, column: 16, scope: !2251, inlinedAt: !2001)
!2262 = !DILocation(line: 631, column: 25, scope: !2252, inlinedAt: !2001)
!2263 = !DILocation(line: 631, column: 3, scope: !2253, inlinedAt: !2001)
!2264 = !DILocation(line: 631, column: 18, scope: !2252, inlinedAt: !2001)
!2265 = distinct !{!2265, !2263, !2266, !1999}
!2266 = !DILocation(line: 634, column: 3, scope: !2253, inlinedAt: !2001)
!2267 = !DILocation(line: 646, column: 7, scope: !2268, inlinedAt: !2001)
!2268 = distinct !DILexicalBlock(scope: !2234, file: !3, line: 646, column: 7)
!2269 = !DILocation(line: 646, column: 39, scope: !2270, inlinedAt: !2001)
!2270 = distinct !DILexicalBlock(scope: !2268, file: !3, line: 646, column: 7)
!2271 = distinct !{!2271, !2267, !2272, !1999, !2042, !2043}
!2272 = !DILocation(line: 646, column: 43, scope: !2268, inlinedAt: !2001)
!2273 = !DILocation(line: 646, column: 36, scope: !2270, inlinedAt: !2001)
!2274 = !DILocation(line: 646, column: 29, scope: !2270, inlinedAt: !2001)
!2275 = !DILocation(line: 646, column: 22, scope: !2270, inlinedAt: !2001)
!2276 = distinct !{!2276, !2267, !2272, !1999, !2042}
!2277 = !DILocation(line: 648, column: 12, scope: !2234, inlinedAt: !2001)
!2278 = !DILocation(line: 648, column: 18, scope: !2234, inlinedAt: !2001)
!2279 = !DILocation(line: 649, column: 21, scope: !2280, inlinedAt: !2001)
!2280 = distinct !DILexicalBlock(scope: !2238, file: !3, line: 649, column: 7)
!2281 = !DILocation(line: 649, column: 39, scope: !2280, inlinedAt: !2001)
!2282 = distinct !{!2282, !2237, !2283, !1999, !2042, !2043}
!2283 = !DILocation(line: 649, column: 43, scope: !2238, inlinedAt: !2001)
!2284 = !DILocation(line: 649, column: 36, scope: !2280, inlinedAt: !2001)
!2285 = !DILocation(line: 649, column: 29, scope: !2280, inlinedAt: !2001)
!2286 = distinct !{!2286, !2237, !2283, !1999, !2043, !2042}
!2287 = !DILocation(line: 0, scope: !2234, inlinedAt: !2001)
!2288 = !DILocation(line: 650, column: 14, scope: !2234, inlinedAt: !2001)
!2289 = !DILocation(line: 650, column: 7, scope: !2234, inlinedAt: !2001)
!2290 = !DILocation(line: 650, column: 12, scope: !2234, inlinedAt: !2001)
!2291 = !DILocation(line: 674, column: 12, scope: !713, inlinedAt: !2001)
!2292 = !DILocation(line: 675, column: 1, scope: !713, inlinedAt: !2001)
!2293 = !DILocation(line: 295, column: 10, scope: !2294)
!2294 = distinct !DILexicalBlock(scope: !639, file: !3, line: 295, column: 7)
!2295 = !DILocation(line: 295, column: 7, scope: !639)
!2296 = !DILocation(line: 296, column: 12, scope: !2297)
!2297 = distinct !DILexicalBlock(scope: !2294, file: !3, line: 295, column: 15)
!2298 = !DILocation(line: 296, column: 10, scope: !2297)
!2299 = !DILocation(line: 297, column: 12, scope: !2297)
!2300 = !DILocation(line: 297, column: 10, scope: !2297)
!2301 = !DILocation(line: 298, column: 12, scope: !2297)
!2302 = !DILocation(line: 298, column: 5, scope: !2297)
!2303 = !DILocation(line: 301, column: 1, scope: !639)
!2304 = !DILocation(line: 0, scope: !201)
!2305 = !DILocation(line: 0, scope: !873, inlinedAt: !2306)
!2306 = distinct !DILocation(line: 1501, column: 3, scope: !214)
!2307 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2306)
!2308 = !DILocation(line: 0, scope: !214)
!2309 = !DILocation(line: 1501, column: 3, scope: !214)
!2310 = !DILocation(line: 1502, column: 13, scope: !201)
!2311 = !DILocation(line: 1503, column: 6, scope: !201)
!2312 = !DILocation(line: 1506, column: 10, scope: !219)
!2313 = !DILocation(line: 1506, column: 7, scope: !201)
!2314 = !DILocation(line: 1507, column: 12, scope: !217)
!2315 = !DILocation(line: 1507, column: 9, scope: !218)
!2316 = !DILocation(line: 0, scope: !873, inlinedAt: !2317)
!2317 = distinct !DILocation(line: 1509, column: 7, scope: !221)
!2318 = !DILocation(line: 0, scope: !221)
!2319 = !DILocation(line: 1509, column: 7, scope: !221)
!2320 = !DILocation(line: 0, scope: !216)
!2321 = !DILocation(line: 1510, column: 16, scope: !2322)
!2322 = distinct !DILexicalBlock(scope: !216, file: !3, line: 1510, column: 11)
!2323 = !DILocation(line: 1510, column: 27, scope: !2322)
!2324 = !DILocation(line: 1510, column: 33, scope: !2322)
!2325 = !DILocation(line: 1510, column: 11, scope: !216)
!2326 = !DILocation(line: 1515, column: 11, scope: !2327)
!2327 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1515, column: 9)
!2328 = !DILocation(line: 1515, column: 9, scope: !218)
!2329 = !DILocation(line: 1515, column: 33, scope: !2327)
!2330 = !DILocation(line: 1515, column: 40, scope: !2327)
!2331 = !DILocation(line: 1515, column: 38, scope: !2327)
!2332 = !DILocation(line: 1515, column: 26, scope: !2327)
!2333 = !DILocation(line: 1516, column: 11, scope: !2334)
!2334 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1516, column: 9)
!2335 = !DILocation(line: 1516, column: 9, scope: !218)
!2336 = !DILocation(line: 1516, column: 33, scope: !2334)
!2337 = !DILocation(line: 1516, column: 44, scope: !2334)
!2338 = !DILocation(line: 1516, column: 42, scope: !2334)
!2339 = !DILocation(line: 1516, column: 26, scope: !2334)
!2340 = !DILocation(line: 1520, column: 10, scope: !2341)
!2341 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1520, column: 7)
!2342 = !DILocation(line: 1520, column: 7, scope: !201)
!2343 = !DILocation(line: 1521, column: 12, scope: !2344)
!2344 = distinct !DILexicalBlock(scope: !2345, file: !3, line: 1521, column: 9)
!2345 = distinct !DILexicalBlock(scope: !2341, file: !3, line: 1520, column: 24)
!2346 = !DILocation(line: 1521, column: 9, scope: !2345)
!2347 = !DILocation(line: 1526, column: 13, scope: !2348)
!2348 = distinct !DILexicalBlock(scope: !2349, file: !3, line: 1526, column: 11)
!2349 = distinct !DILexicalBlock(scope: !2344, file: !3, line: 1521, column: 26)
!2350 = !DILocation(line: 1526, column: 11, scope: !2349)
!2351 = !DILocation(line: 1527, column: 16, scope: !2349)
!2352 = !DILocation(line: 1527, column: 14, scope: !2349)
!2353 = !DILocation(line: 1528, column: 12, scope: !2349)
!2354 = !DILocation(line: 1529, column: 13, scope: !2349)
!2355 = !DILocation(line: 1529, column: 19, scope: !2349)
!2356 = !DILocation(line: 1536, column: 12, scope: !2345)
!2357 = !DILocation(line: 1544, column: 9, scope: !201)
!2358 = !DILocation(line: 1545, column: 7, scope: !201)
!2359 = !DILocation(line: 1537, column: 17, scope: !2360)
!2360 = distinct !DILexicalBlock(scope: !2341, file: !3, line: 1537, column: 14)
!2361 = !DILocation(line: 1537, column: 14, scope: !2341)
!2362 = !DILocation(line: 1538, column: 9, scope: !2363)
!2363 = distinct !DILexicalBlock(scope: !2364, file: !3, line: 1538, column: 9)
!2364 = distinct !DILexicalBlock(scope: !2360, file: !3, line: 1537, column: 31)
!2365 = !DILocation(line: 1538, column: 14, scope: !2363)
!2366 = !DILocation(line: 1538, column: 18, scope: !2363)
!2367 = !DILocation(line: 1538, column: 9, scope: !2364)
!2368 = !DILocation(line: 1538, column: 36, scope: !2363)
!2369 = !DILocation(line: 1538, column: 25, scope: !2363)
!2370 = !DILocation(line: 1531, column: 30, scope: !2371)
!2371 = distinct !DILexicalBlock(scope: !2344, file: !3, line: 1530, column: 12)
!2372 = !DILocation(line: 1531, column: 28, scope: !2371)
!2373 = !DILocation(line: 1531, column: 11, scope: !2371)
!2374 = !DILocation(line: 1532, column: 11, scope: !2371)
!2375 = !DILocation(line: 1533, column: 14, scope: !2371)
!2376 = !DILocation(line: 1534, column: 14, scope: !2371)
!2377 = !DILocation(line: 1545, column: 9, scope: !225)
!2378 = !DILocation(line: 0, scope: !225)
!2379 = !DILocation(line: 1553, column: 49, scope: !201)
!2380 = !DILocation(line: 1553, column: 39, scope: !201)
!2381 = !DILocation(line: 1553, column: 29, scope: !201)
!2382 = !DILocation(line: 1553, column: 19, scope: !201)
!2383 = !DILocation(line: 1553, column: 9, scope: !201)
!2384 = !DILocation(line: 1554, column: 9, scope: !2385)
!2385 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1554, column: 7)
!2386 = !DILocation(line: 0, scope: !2385)
!2387 = !DILocation(line: 1554, column: 7, scope: !201)
!2388 = !DILocation(line: 1555, column: 32, scope: !2389)
!2389 = distinct !DILexicalBlock(scope: !2385, file: !3, line: 1554, column: 15)
!2390 = !DILocation(line: 1555, column: 27, scope: !2389)
!2391 = !DILocation(line: 1555, column: 16, scope: !2389)
!2392 = !DILocation(line: 1555, column: 5, scope: !2389)
!2393 = !DILocation(line: 1557, column: 37, scope: !2394)
!2394 = distinct !DILexicalBlock(scope: !2385, file: !3, line: 1556, column: 10)
!2395 = !DILocation(line: 1557, column: 30, scope: !2394)
!2396 = !DILocation(line: 1557, column: 20, scope: !2394)
!2397 = !DILocation(line: 1557, column: 13, scope: !2394)
!2398 = !DILocation(line: 1559, column: 7, scope: !201)
!2399 = !DILocation(line: 1560, column: 11, scope: !2400)
!2400 = distinct !DILexicalBlock(scope: !2401, file: !3, line: 1560, column: 9)
!2401 = distinct !DILexicalBlock(scope: !2402, file: !3, line: 1559, column: 19)
!2402 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1559, column: 7)
!2403 = !DILocation(line: 1560, column: 9, scope: !2401)
!2404 = !DILocation(line: 1560, column: 29, scope: !2400)
!2405 = !DILocation(line: 1560, column: 37, scope: !2400)
!2406 = !DILocation(line: 1560, column: 35, scope: !2400)
!2407 = !DILocation(line: 1560, column: 20, scope: !2400)
!2408 = !DILocation(line: 1561, column: 14, scope: !2401)
!2409 = !DILocation(line: 1561, column: 5, scope: !2401)
!2410 = !DILocation(line: 1563, column: 14, scope: !2411)
!2411 = distinct !DILexicalBlock(scope: !2402, file: !3, line: 1562, column: 10)
!2412 = !DILocation(line: 1563, column: 24, scope: !2411)
!2413 = !DILocation(line: 1563, column: 22, scope: !2411)
!2414 = !DILocation(line: 1563, column: 5, scope: !2411)
!2415 = !DILocation(line: 1565, column: 1, scope: !201)
!2416 = !DILocation(line: 0, scope: !264)
!2417 = !DILocation(line: 0, scope: !873, inlinedAt: !2418)
!2418 = distinct !DILocation(line: 1591, column: 3, scope: !272)
!2419 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2418)
!2420 = !DILocation(line: 0, scope: !272)
!2421 = !DILocation(line: 1591, column: 3, scope: !272)
!2422 = !DILocation(line: 1592, column: 11, scope: !264)
!2423 = !DILocation(line: 1593, column: 48, scope: !2424)
!2424 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1593, column: 7)
!2425 = !DILocation(line: 1593, column: 11, scope: !2424)
!2426 = !DILocation(line: 1593, column: 56, scope: !2424)
!2427 = !DILocation(line: 1593, column: 7, scope: !264)
!2428 = !DILocation(line: 1597, column: 10, scope: !2429)
!2429 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1597, column: 7)
!2430 = !DILocation(line: 1597, column: 7, scope: !264)
!2431 = !DILocation(line: 1598, column: 14, scope: !2432)
!2432 = distinct !DILexicalBlock(scope: !2429, file: !3, line: 1597, column: 25)
!2433 = !DILocation(line: 1598, column: 12, scope: !2432)
!2434 = !DILocation(line: 1598, column: 5, scope: !2432)
!2435 = !DILocation(line: 1601, column: 10, scope: !2436)
!2436 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1601, column: 7)
!2437 = !DILocation(line: 1601, column: 23, scope: !2436)
!2438 = !DILocation(line: 0, scope: !873, inlinedAt: !2439)
!2439 = distinct !DILocation(line: 1602, column: 3, scope: !274)
!2440 = !DILocation(line: 0, scope: !274)
!2441 = !DILocation(line: 1602, column: 3, scope: !274)
!2442 = !DILocation(line: 1603, column: 10, scope: !2443)
!2443 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1603, column: 7)
!2444 = !DILocation(line: 0, scope: !2443)
!2445 = !DILocation(line: 1603, column: 7, scope: !264)
!2446 = !DILocation(line: 1605, column: 39, scope: !2447)
!2447 = distinct !DILexicalBlock(scope: !2443, file: !3, line: 1603, column: 24)
!2448 = !DILocation(line: 1605, column: 50, scope: !2447)
!2449 = !DILocation(line: 1605, column: 43, scope: !2447)
!2450 = !DILocation(line: 1605, column: 35, scope: !2447)
!2451 = !DILocation(line: 1606, column: 3, scope: !2447)
!2452 = !DILocation(line: 1607, column: 48, scope: !2453)
!2453 = distinct !DILexicalBlock(scope: !2443, file: !3, line: 1606, column: 10)
!2454 = !DILocation(line: 1607, column: 41, scope: !2453)
!2455 = !DILocation(line: 1609, column: 7, scope: !264)
!2456 = !DILocation(line: 1613, column: 1, scope: !264)
!2457 = !DILocation(line: 0, scope: !382)
!2458 = !DILocation(line: 0, scope: !873, inlinedAt: !2459)
!2459 = distinct !DILocation(line: 2010, column: 3, scope: !399)
!2460 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2459)
!2461 = !DILocation(line: 0, scope: !399)
!2462 = !DILocation(line: 2010, column: 3, scope: !399)
!2463 = !DILocation(line: 2013, column: 10, scope: !403)
!2464 = !DILocation(line: 2013, column: 7, scope: !382)
!2465 = !DILocation(line: 2014, column: 14, scope: !2466)
!2466 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2014, column: 9)
!2467 = !DILocation(line: 2014, column: 28, scope: !2466)
!2468 = !DILocation(line: 2014, column: 34, scope: !2466)
!2469 = !DILocation(line: 2014, column: 9, scope: !402)
!2470 = !DILocation(line: 2017, column: 12, scope: !2471)
!2471 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2017, column: 9)
!2472 = !DILocation(line: 2017, column: 9, scope: !402)
!2473 = !DILocation(line: 2021, column: 7, scope: !402)
!2474 = !DILocation(line: 0, scope: !873, inlinedAt: !2475)
!2475 = distinct !DILocation(line: 2022, column: 5, scope: !401)
!2476 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2475)
!2477 = !DILocation(line: 0, scope: !401)
!2478 = !DILocation(line: 2022, column: 5, scope: !401)
!2479 = !DILocation(line: 2023, column: 3, scope: !402)
!2480 = !DILocation(line: 2024, column: 10, scope: !2481)
!2481 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2024, column: 7)
!2482 = !DILocation(line: 2024, column: 7, scope: !382)
!2483 = !DILocation(line: 2024, column: 34, scope: !2481)
!2484 = !DILocation(line: 2024, column: 25, scope: !2481)
!2485 = !DILocation(line: 2025, column: 10, scope: !2486)
!2486 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2025, column: 7)
!2487 = !DILocation(line: 2025, column: 24, scope: !2486)
!2488 = !DILocation(line: 2026, column: 12, scope: !382)
!2489 = !DILocation(line: 2026, column: 19, scope: !382)
!2490 = !DILocation(line: 2026, column: 5, scope: !382)
!2491 = !DILocation(line: 2027, column: 6, scope: !382)
!2492 = !DILocation(line: 2028, column: 11, scope: !382)
!2493 = !DILocation(line: 2028, column: 22, scope: !382)
!2494 = !DILocation(line: 0, scope: !873, inlinedAt: !2495)
!2495 = distinct !DILocation(line: 2029, column: 3, scope: !405)
!2496 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2495)
!2497 = !DILocation(line: 0, scope: !405)
!2498 = !DILocation(line: 2029, column: 3, scope: !405)
!2499 = !DILocation(line: 0, scope: !947, inlinedAt: !2500)
!2500 = distinct !DILocation(line: 2029, column: 3, scope: !405)
!2501 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2500)
!2502 = !DILocation(line: 2030, column: 5, scope: !382)
!2503 = !DILocation(line: 2031, column: 7, scope: !382)
!2504 = !DILocation(line: 2032, column: 9, scope: !382)
!2505 = !DILocation(line: 2033, column: 14, scope: !382)
!2506 = !DILocation(line: 2033, column: 18, scope: !382)
!2507 = !DILocalVariable(name: "f", arg: 1, scope: !2508, file: !3, line: 1978, type: !6)
!2508 = distinct !DISubprogram(name: "k_log1p", scope: !3, file: !3, line: 1978, type: !4, scopeLine: 1978, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2509)
!2509 = !{!2507, !2510, !2511, !2512, !2513, !2514, !2515, !2516}
!2510 = !DILocalVariable(name: "hfsq", scope: !2508, file: !3, line: 1979, type: !6)
!2511 = !DILocalVariable(name: "s", scope: !2508, file: !3, line: 1979, type: !6)
!2512 = !DILocalVariable(name: "z", scope: !2508, file: !3, line: 1979, type: !6)
!2513 = !DILocalVariable(name: "R", scope: !2508, file: !3, line: 1979, type: !6)
!2514 = !DILocalVariable(name: "w", scope: !2508, file: !3, line: 1979, type: !6)
!2515 = !DILocalVariable(name: "t1", scope: !2508, file: !3, line: 1979, type: !6)
!2516 = !DILocalVariable(name: "t2", scope: !2508, file: !3, line: 1979, type: !6)
!2517 = !DILocation(line: 0, scope: !2508, inlinedAt: !2518)
!2518 = distinct !DILocation(line: 2034, column: 7, scope: !382)
!2519 = !DILocation(line: 1981, column: 16, scope: !2508, inlinedAt: !2518)
!2520 = !DILocation(line: 1981, column: 9, scope: !2508, inlinedAt: !2518)
!2521 = !DILocation(line: 1982, column: 9, scope: !2508, inlinedAt: !2518)
!2522 = !DILocation(line: 1983, column: 9, scope: !2508, inlinedAt: !2518)
!2523 = !DILocation(line: 1984, column: 28, scope: !2508, inlinedAt: !2518)
!2524 = !DILocation(line: 1984, column: 17, scope: !2508, inlinedAt: !2518)
!2525 = !DILocation(line: 1984, column: 10, scope: !2508, inlinedAt: !2518)
!2526 = !DILocation(line: 1985, column: 39, scope: !2508, inlinedAt: !2518)
!2527 = !DILocation(line: 1985, column: 28, scope: !2508, inlinedAt: !2518)
!2528 = !DILocation(line: 1985, column: 17, scope: !2508, inlinedAt: !2518)
!2529 = !DILocation(line: 1985, column: 10, scope: !2508, inlinedAt: !2518)
!2530 = !DILocation(line: 1986, column: 10, scope: !2508, inlinedAt: !2518)
!2531 = !DILocation(line: 1988, column: 20, scope: !2508, inlinedAt: !2518)
!2532 = !DILocation(line: 1988, column: 12, scope: !2508, inlinedAt: !2518)
!2533 = !DILocation(line: 2066, column: 10, scope: !382)
!2534 = !DILocation(line: 0, scope: !873, inlinedAt: !2535)
!2535 = distinct !DILocation(line: 2067, column: 3, scope: !407)
!2536 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2535)
!2537 = !DILocation(line: 0, scope: !407)
!2538 = !DILocation(line: 2067, column: 3, scope: !407)
!2539 = !DILocation(line: 0, scope: !947, inlinedAt: !2540)
!2540 = distinct !DILocation(line: 2067, column: 3, scope: !407)
!2541 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2540)
!2542 = !DILocation(line: 2068, column: 11, scope: !382)
!2543 = !DILocation(line: 2068, column: 17, scope: !382)
!2544 = !DILocation(line: 2068, column: 24, scope: !382)
!2545 = !DILocation(line: 2069, column: 15, scope: !382)
!2546 = !DILocation(line: 2070, column: 16, scope: !382)
!2547 = !DILocation(line: 2070, column: 37, scope: !382)
!2548 = !DILocation(line: 2070, column: 32, scope: !382)
!2549 = !DILocation(line: 2073, column: 9, scope: !382)
!2550 = !DILocation(line: 2074, column: 16, scope: !382)
!2551 = !DILocation(line: 2074, column: 21, scope: !382)
!2552 = !DILocation(line: 2074, column: 10, scope: !382)
!2553 = !DILocation(line: 2077, column: 17, scope: !382)
!2554 = !DILocation(line: 2077, column: 3, scope: !382)
!2555 = !DILocation(line: 2078, column: 1, scope: !382)
!2556 = !DILocation(line: 0, scope: !414)
!2557 = !DILocation(line: 0, scope: !873, inlinedAt: !2558)
!2558 = distinct !DILocation(line: 2117, column: 3, scope: !423)
!2559 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2558)
!2560 = !DILocation(line: 0, scope: !423)
!2561 = !DILocation(line: 2117, column: 3, scope: !423)
!2562 = !DILocation(line: 2120, column: 10, scope: !427)
!2563 = !DILocation(line: 2120, column: 7, scope: !414)
!2564 = !DILocation(line: 2121, column: 14, scope: !2565)
!2565 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2121, column: 9)
!2566 = !DILocation(line: 2121, column: 28, scope: !2565)
!2567 = !DILocation(line: 2121, column: 34, scope: !2565)
!2568 = !DILocation(line: 2121, column: 9, scope: !426)
!2569 = !DILocation(line: 2124, column: 12, scope: !2570)
!2570 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2124, column: 9)
!2571 = !DILocation(line: 2124, column: 9, scope: !426)
!2572 = !DILocation(line: 2128, column: 7, scope: !426)
!2573 = !DILocation(line: 0, scope: !873, inlinedAt: !2574)
!2574 = distinct !DILocation(line: 2129, column: 5, scope: !425)
!2575 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2574)
!2576 = !DILocation(line: 0, scope: !425)
!2577 = !DILocation(line: 2129, column: 5, scope: !425)
!2578 = !DILocation(line: 0, scope: !873, inlinedAt: !2579)
!2579 = distinct !DILocation(line: 2130, column: 5, scope: !429)
!2580 = !DILocation(line: 0, scope: !429)
!2581 = !DILocation(line: 2130, column: 5, scope: !429)
!2582 = !DILocation(line: 2131, column: 3, scope: !426)
!2583 = !DILocation(line: 2132, column: 10, scope: !2584)
!2584 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2132, column: 7)
!2585 = !DILocation(line: 2132, column: 7, scope: !414)
!2586 = !DILocation(line: 2132, column: 34, scope: !2584)
!2587 = !DILocation(line: 2132, column: 25, scope: !2584)
!2588 = !DILocation(line: 2133, column: 10, scope: !2589)
!2589 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2133, column: 7)
!2590 = !DILocation(line: 2133, column: 24, scope: !2589)
!2591 = !DILocation(line: 2134, column: 12, scope: !414)
!2592 = !DILocation(line: 2134, column: 19, scope: !414)
!2593 = !DILocation(line: 2134, column: 5, scope: !414)
!2594 = !DILocation(line: 2136, column: 24, scope: !414)
!2595 = !DILocation(line: 2137, column: 12, scope: !414)
!2596 = !DILocation(line: 2137, column: 41, scope: !414)
!2597 = !DILocation(line: 2137, column: 26, scope: !414)
!2598 = !DILocation(line: 2138, column: 9, scope: !414)
!2599 = !DILocation(line: 2138, column: 7, scope: !414)
!2600 = !DILocation(line: 0, scope: !873, inlinedAt: !2601)
!2601 = distinct !DILocation(line: 2139, column: 3, scope: !431)
!2602 = !DILocation(line: 0, scope: !431)
!2603 = !DILocation(line: 2139, column: 3, scope: !431)
!2604 = !DILocation(line: 0, scope: !947, inlinedAt: !2605)
!2605 = distinct !DILocation(line: 2139, column: 3, scope: !431)
!2606 = !DILocation(line: 0, scope: !873, inlinedAt: !2607)
!2607 = distinct !DILocation(line: 2140, column: 3, scope: !433)
!2608 = !DILocation(line: 0, scope: !433)
!2609 = !DILocation(line: 2140, column: 3, scope: !433)
!2610 = !DILocation(line: 0, scope: !947, inlinedAt: !2611)
!2611 = distinct !DILocation(line: 2140, column: 3, scope: !433)
!2612 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2611)
!2613 = !DILocation(line: 2142, column: 39, scope: !414)
!2614 = !DILocation(line: 2142, column: 37, scope: !414)
!2615 = !DILocation(line: 2142, column: 28, scope: !414)
!2616 = !DILocation(line: 2143, column: 12, scope: !414)
!2617 = !DILocation(line: 2144, column: 1, scope: !414)
!2618 = !DILocation(line: 0, scope: !443)
!2619 = !DILocation(line: 0, scope: !873, inlinedAt: !2620)
!2620 = distinct !DILocation(line: 2262, column: 3, scope: !460)
!2621 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2620)
!2622 = !DILocation(line: 0, scope: !460)
!2623 = !DILocation(line: 2262, column: 3, scope: !460)
!2624 = !DILocation(line: 2263, column: 12, scope: !443)
!2625 = !DILocation(line: 2264, column: 6, scope: !443)
!2626 = !DILocation(line: 2267, column: 10, scope: !467)
!2627 = !DILocation(line: 2267, column: 7, scope: !443)
!2628 = !DILocation(line: 2268, column: 12, scope: !465)
!2629 = !DILocation(line: 2268, column: 9, scope: !466)
!2630 = !DILocation(line: 2269, column: 14, scope: !463)
!2631 = !DILocation(line: 2269, column: 11, scope: !464)
!2632 = !DILocation(line: 0, scope: !873, inlinedAt: !2633)
!2633 = distinct !DILocation(line: 2271, column: 9, scope: !469)
!2634 = !DILocation(line: 0, scope: !469)
!2635 = !DILocation(line: 2271, column: 9, scope: !469)
!2636 = !DILocation(line: 0, scope: !462)
!2637 = !DILocation(line: 2272, column: 18, scope: !2638)
!2638 = distinct !DILexicalBlock(scope: !462, file: !3, line: 2272, column: 13)
!2639 = !DILocation(line: 2272, column: 29, scope: !2638)
!2640 = !DILocation(line: 2272, column: 36, scope: !2638)
!2641 = !DILocation(line: 2272, column: 13, scope: !462)
!2642 = !DILocation(line: 2277, column: 13, scope: !2643)
!2643 = distinct !DILexicalBlock(scope: !464, file: !3, line: 2277, column: 11)
!2644 = !DILocation(line: 2277, column: 11, scope: !464)
!2645 = !DILocation(line: 2277, column: 35, scope: !2643)
!2646 = !DILocation(line: 2277, column: 42, scope: !2643)
!2647 = !DILocation(line: 2277, column: 40, scope: !2643)
!2648 = !DILocation(line: 2277, column: 28, scope: !2643)
!2649 = !DILocation(line: 2279, column: 13, scope: !2650)
!2650 = distinct !DILexicalBlock(scope: !466, file: !3, line: 2279, column: 9)
!2651 = !DILocation(line: 2279, column: 9, scope: !466)
!2652 = !DILocation(line: 2286, column: 10, scope: !2653)
!2653 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2286, column: 7)
!2654 = !DILocation(line: 2286, column: 7, scope: !443)
!2655 = !DILocation(line: 2287, column: 12, scope: !2656)
!2656 = distinct !DILexicalBlock(scope: !2657, file: !3, line: 2287, column: 9)
!2657 = distinct !DILexicalBlock(scope: !2653, file: !3, line: 2286, column: 24)
!2658 = !DILocation(line: 2287, column: 9, scope: !2657)
!2659 = !DILocation(line: 2288, column: 15, scope: !2660)
!2660 = distinct !DILexicalBlock(scope: !2661, file: !3, line: 2288, column: 11)
!2661 = distinct !DILexicalBlock(scope: !2656, file: !3, line: 2287, column: 26)
!2662 = !DILocation(line: 2288, column: 11, scope: !2661)
!2663 = !DILocation(line: 2289, column: 16, scope: !2664)
!2664 = distinct !DILexicalBlock(scope: !2660, file: !3, line: 2288, column: 21)
!2665 = !DILocation(line: 2292, column: 7, scope: !2664)
!2666 = !DILocation(line: 2293, column: 16, scope: !2667)
!2667 = distinct !DILexicalBlock(scope: !2660, file: !3, line: 2292, column: 14)
!2668 = !DILocation(line: 2298, column: 30, scope: !2669)
!2669 = distinct !DILexicalBlock(scope: !2656, file: !3, line: 2297, column: 12)
!2670 = !DILocation(line: 2298, column: 25, scope: !2669)
!2671 = !DILocation(line: 2298, column: 22, scope: !2669)
!2672 = !DILocation(line: 2298, column: 11, scope: !2669)
!2673 = !DILocation(line: 2299, column: 11, scope: !2669)
!2674 = !DILocation(line: 2300, column: 14, scope: !2669)
!2675 = !DILocation(line: 2301, column: 14, scope: !2669)
!2676 = !DILocation(line: 0, scope: !2656)
!2677 = !DILocation(line: 2303, column: 12, scope: !2657)
!2678 = !DILocation(line: 2304, column: 13, scope: !2657)
!2679 = !DILocation(line: 2304, column: 18, scope: !2657)
!2680 = !DILocation(line: 2305, column: 3, scope: !2657)
!2681 = !DILocation(line: 2305, column: 17, scope: !2682)
!2682 = distinct !DILexicalBlock(scope: !2653, file: !3, line: 2305, column: 14)
!2683 = !DILocation(line: 2305, column: 14, scope: !2653)
!2684 = !DILocation(line: 2306, column: 9, scope: !2685)
!2685 = distinct !DILexicalBlock(scope: !2682, file: !3, line: 2305, column: 31)
!2686 = !DILocation(line: 2306, column: 14, scope: !2685)
!2687 = !DILocation(line: 2307, column: 22, scope: !2685)
!2688 = !DILocation(line: 2307, column: 27, scope: !2685)
!2689 = !DILocation(line: 2307, column: 19, scope: !2685)
!2690 = !DILocation(line: 2307, column: 14, scope: !2685)
!2691 = !DILocation(line: 2307, column: 5, scope: !2685)
!2692 = !DILocation(line: 0, scope: !2653)
!2693 = !DILocation(line: 2313, column: 13, scope: !443)
!2694 = !DILocation(line: 2314, column: 11, scope: !443)
!2695 = !DILocation(line: 2315, column: 60, scope: !443)
!2696 = !DILocation(line: 2315, column: 48, scope: !443)
!2697 = !DILocation(line: 2315, column: 36, scope: !443)
!2698 = !DILocation(line: 2315, column: 24, scope: !443)
!2699 = !DILocation(line: 2315, column: 12, scope: !443)
!2700 = !DILocation(line: 2316, column: 11, scope: !443)
!2701 = !DILocation(line: 2317, column: 18, scope: !443)
!2702 = !DILocation(line: 2317, column: 30, scope: !443)
!2703 = !DILocation(line: 2317, column: 23, scope: !443)
!2704 = !DILocation(line: 2317, column: 11, scope: !443)
!2705 = !DILocation(line: 2318, column: 9, scope: !473)
!2706 = !DILocation(line: 2318, column: 7, scope: !443)
!2707 = !DILocation(line: 2319, column: 23, scope: !2708)
!2708 = distinct !DILexicalBlock(scope: !473, file: !3, line: 2318, column: 15)
!2709 = !DILocation(line: 2319, column: 14, scope: !2708)
!2710 = !DILocation(line: 2319, column: 5, scope: !2708)
!2711 = !DILocation(line: 0, scope: !471)
!2712 = !DILocation(line: 2321, column: 5, scope: !471)
!2713 = !DILocation(line: 0, scope: !947, inlinedAt: !2714)
!2714 = distinct !DILocation(line: 2321, column: 5, scope: !471)
!2715 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2714)
!2716 = !DILocation(line: 2325, column: 17, scope: !472)
!2717 = !DILocation(line: 2325, column: 22, scope: !472)
!2718 = !DILocation(line: 2326, column: 7, scope: !472)
!2719 = !DILocation(line: 2327, column: 9, scope: !472)
!2720 = !DILocation(line: 2327, column: 34, scope: !2721)
!2721 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2327, column: 9)
!2722 = !DILocation(line: 2327, column: 39, scope: !2721)
!2723 = !DILocation(line: 2327, column: 18, scope: !2721)
!2724 = !DILocation(line: 2329, column: 13, scope: !2725)
!2725 = distinct !DILexicalBlock(scope: !2726, file: !3, line: 2329, column: 11)
!2726 = distinct !DILexicalBlock(scope: !2727, file: !3, line: 2328, column: 17)
!2727 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2328, column: 9)
!2728 = !DILocation(line: 2329, column: 11, scope: !2726)
!2729 = !DILocation(line: 2330, column: 31, scope: !2725)
!2730 = !DILocation(line: 2330, column: 26, scope: !2725)
!2731 = !DILocation(line: 2330, column: 21, scope: !2725)
!2732 = !DILocation(line: 2330, column: 9, scope: !2725)
!2733 = !DILocation(line: 2332, column: 31, scope: !2725)
!2734 = !DILocation(line: 2332, column: 20, scope: !2725)
!2735 = !DILocation(line: 2332, column: 9, scope: !2725)
!2736 = !DILocation(line: 2334, column: 17, scope: !2737)
!2737 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2334, column: 9)
!2738 = !DILocation(line: 2335, column: 15, scope: !2739)
!2739 = distinct !DILexicalBlock(scope: !2737, file: !3, line: 2334, column: 28)
!2740 = !DILocation(line: 2339, column: 13, scope: !2741)
!2741 = distinct !DILexicalBlock(scope: !2739, file: !3, line: 2339, column: 11)
!2742 = !DILocation(line: 2339, column: 11, scope: !2739)
!2743 = !DILocation(line: 2343, column: 16, scope: !2739)
!2744 = !DILocation(line: 2343, column: 7, scope: !2739)
!2745 = !DILocation(line: 2346, column: 11, scope: !477)
!2746 = !DILocation(line: 0, scope: !873, inlinedAt: !2747)
!2747 = distinct !DILocation(line: 2347, column: 7, scope: !475)
!2748 = !DILocation(line: 0, scope: !873, inlinedAt: !2749)
!2749 = distinct !DILocation(line: 2351, column: 7, scope: !479)
!2750 = !DILocation(line: 2346, column: 9, scope: !472)
!2751 = !DILocation(line: 0, scope: !475)
!2752 = !DILocation(line: 2347, column: 7, scope: !475)
!2753 = !DILocation(line: 0, scope: !947, inlinedAt: !2754)
!2754 = distinct !DILocation(line: 2347, column: 7, scope: !475)
!2755 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2754)
!2756 = !DILocation(line: 2348, column: 18, scope: !476)
!2757 = !DILocation(line: 2348, column: 13, scope: !476)
!2758 = !DILocation(line: 2350, column: 5, scope: !476)
!2759 = !DILocation(line: 0, scope: !479)
!2760 = !DILocation(line: 2351, column: 7, scope: !479)
!2761 = !DILocation(line: 0, scope: !947, inlinedAt: !2762)
!2762 = distinct !DILocation(line: 2351, column: 7, scope: !479)
!2763 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2762)
!2764 = !DILocation(line: 2352, column: 18, scope: !480)
!2765 = !DILocation(line: 2352, column: 13, scope: !480)
!2766 = !DILocation(line: 2353, column: 9, scope: !480)
!2767 = !DILocation(line: 0, scope: !477)
!2768 = !DILocation(line: 2357, column: 3, scope: !443)
!2769 = !DILocation(line: 2358, column: 1, scope: !443)
!2770 = !DILocation(line: 0, scope: !505)
!2771 = !DILocation(line: 0, scope: !873, inlinedAt: !2772)
!2772 = distinct !DILocation(line: 2377, column: 3, scope: !517)
!2773 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2772)
!2774 = !DILocation(line: 0, scope: !517)
!2775 = !DILocation(line: 2377, column: 3, scope: !517)
!2776 = !DILocation(line: 2378, column: 13, scope: !505)
!2777 = !DILocation(line: 2379, column: 6, scope: !505)
!2778 = !DILocation(line: 2380, column: 10, scope: !2779)
!2779 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2380, column: 7)
!2780 = !DILocation(line: 2380, column: 7, scope: !505)
!2781 = !DILocation(line: 2380, column: 35, scope: !2779)
!2782 = !DILocation(line: 2380, column: 25, scope: !2779)
!2783 = !DILocation(line: 2397, column: 10, scope: !521)
!2784 = !DILocation(line: 2397, column: 7, scope: !505)
!2785 = !DILocation(line: 2398, column: 13, scope: !2786)
!2786 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2398, column: 9)
!2787 = !DILocation(line: 2398, column: 20, scope: !2786)
!2788 = !DILocation(line: 2398, column: 9, scope: !520)
!2789 = !DILocation(line: 0, scope: !873, inlinedAt: !2790)
!2790 = distinct !DILocation(line: 2399, column: 5, scope: !519)
!2791 = !DILocation(line: 0, scope: !947, inlinedAt: !2792)
!2792 = distinct !DILocation(line: 2399, column: 5, scope: !519)
!2793 = !DILocation(line: 2400, column: 7, scope: !520)
!2794 = !DILocation(line: 0, scope: !873, inlinedAt: !2795)
!2795 = distinct !DILocation(line: 2401, column: 5, scope: !523)
!2796 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2795)
!2797 = !DILocation(line: 0, scope: !523)
!2798 = !DILocation(line: 2401, column: 5, scope: !523)
!2799 = !DILocation(line: 0, scope: !525)
!2800 = !DILocation(line: 2402, column: 5, scope: !525)
!2801 = !DILocation(line: 0, scope: !947, inlinedAt: !2802)
!2802 = distinct !DILocation(line: 2402, column: 5, scope: !525)
!2803 = !DILocation(line: 2403, column: 3, scope: !520)
!2804 = !DILocation(line: 0, scope: !521)
!2805 = !DILocation(line: 2417, column: 10, scope: !505)
!2806 = !DILocation(line: 2417, column: 20, scope: !505)
!2807 = !DILocation(line: 2417, column: 15, scope: !505)
!2808 = !DILocation(line: 2418, column: 26, scope: !505)
!2809 = !DILocation(line: 2418, column: 16, scope: !505)
!2810 = !DILocation(line: 2418, column: 43, scope: !505)
!2811 = !DILocation(line: 2418, column: 48, scope: !505)
!2812 = !DILocation(line: 2418, column: 59, scope: !505)
!2813 = !DILocation(line: 2418, column: 37, scope: !505)
!2814 = !DILocation(line: 2418, column: 9, scope: !505)
!2815 = !DILocation(line: 0, scope: !873, inlinedAt: !2816)
!2816 = distinct !DILocation(line: 2430, column: 19, scope: !505)
!2817 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2816)
!2818 = !DILocation(line: 2431, column: 30, scope: !505)
!2819 = !DILocation(line: 0, scope: !947, inlinedAt: !2820)
!2820 = distinct !DILocation(line: 2432, column: 7, scope: !505)
!2821 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !2820)
!2822 = !DILocation(line: 2435, column: 9, scope: !505)
!2823 = !DILocation(line: 2436, column: 9, scope: !505)
!2824 = !DILocation(line: 2437, column: 9, scope: !505)
!2825 = !DILocation(line: 2438, column: 10, scope: !505)
!2826 = !DILocation(line: 2438, column: 20, scope: !505)
!2827 = !DILocation(line: 2438, column: 15, scope: !505)
!2828 = !DILocation(line: 2439, column: 9, scope: !505)
!2829 = !DILocation(line: 2442, column: 1, scope: !505)
!2830 = distinct !DISubprogram(name: "pts_ieee754_sin", scope: !3, file: !3, line: 2474, type: !4, scopeLine: 2474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2831)
!2831 = !{!2832, !2833, !2834, !2835, !2836, !2837}
!2832 = !DILocalVariable(name: "x", arg: 1, scope: !2830, file: !3, line: 2474, type: !6)
!2833 = !DILocalVariable(name: "y", scope: !2830, file: !3, line: 2475, type: !1650)
!2834 = !DILocalVariable(name: "z", scope: !2830, file: !3, line: 2475, type: !6)
!2835 = !DILocalVariable(name: "n", scope: !2830, file: !3, line: 2476, type: !18)
!2836 = !DILocalVariable(name: "ix", scope: !2830, file: !3, line: 2476, type: !18)
!2837 = !DILocalVariable(name: "bits", scope: !2838, file: !3, line: 2479, type: !16)
!2838 = distinct !DILexicalBlock(scope: !2830, file: !3, line: 2479, column: 3)
!2839 = !DILocation(line: 0, scope: !2830)
!2840 = !DILocation(line: 2475, column: 3, scope: !2830)
!2841 = !DILocation(line: 2475, column: 10, scope: !2830)
!2842 = !DILocation(line: 0, scope: !873, inlinedAt: !2843)
!2843 = distinct !DILocation(line: 2479, column: 3, scope: !2838)
!2844 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2843)
!2845 = !DILocation(line: 0, scope: !2838)
!2846 = !DILocation(line: 2479, column: 3, scope: !2838)
!2847 = !DILocation(line: 2482, column: 6, scope: !2830)
!2848 = !DILocation(line: 2483, column: 10, scope: !2849)
!2849 = distinct !DILexicalBlock(scope: !2830, file: !3, line: 2483, column: 7)
!2850 = !DILocation(line: 2483, column: 7, scope: !2830)
!2851 = !DILocation(line: 0, scope: !765, inlinedAt: !2852)
!2852 = distinct !DILocation(line: 2484, column: 12, scope: !2853)
!2853 = distinct !DILexicalBlock(scope: !2849, file: !3, line: 2483, column: 25)
!2854 = !DILocation(line: 0, scope: !873, inlinedAt: !2855)
!2855 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2852)
!2856 = !DILocation(line: 0, scope: !777, inlinedAt: !2852)
!2857 = !DILocation(line: 718, column: 10, scope: !1748, inlinedAt: !2852)
!2858 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2852)
!2859 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2852)
!2860 = !DILocation(line: 722, column: 9, scope: !765, inlinedAt: !2852)
!2861 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2852)
!2862 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2852)
!2863 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2852)
!2864 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2852)
!2865 = !DILocation(line: 725, column: 24, scope: !2866, inlinedAt: !2852)
!2866 = distinct !DILexicalBlock(scope: !1758, file: !3, line: 724, column: 16)
!2867 = !DILocation(line: 725, column: 14, scope: !2866, inlinedAt: !2852)
!2868 = !DILocation(line: 725, column: 5, scope: !2866, inlinedAt: !2852)
!2869 = !DILocation(line: 2485, column: 17, scope: !2870)
!2870 = distinct !DILexicalBlock(scope: !2849, file: !3, line: 2485, column: 14)
!2871 = !DILocation(line: 2485, column: 14, scope: !2849)
!2872 = !DILocation(line: 2487, column: 14, scope: !2873)
!2873 = distinct !DILexicalBlock(scope: !2870, file: !3, line: 2485, column: 32)
!2874 = !DILocation(line: 2487, column: 5, scope: !2873)
!2875 = !DILocation(line: 2490, column: 9, scope: !2876)
!2876 = distinct !DILexicalBlock(scope: !2870, file: !3, line: 2488, column: 10)
!2877 = !DILocation(line: 2491, column: 15, scope: !2876)
!2878 = !DILocation(line: 0, scope: !2879)
!2879 = distinct !DILexicalBlock(scope: !2876, file: !3, line: 2491, column: 20)
!2880 = !DILocation(line: 2491, column: 5, scope: !2876)
!2881 = !DILocation(line: 0, scope: !765, inlinedAt: !2882)
!2882 = distinct !DILocation(line: 2493, column: 16, scope: !2879)
!2883 = !DILocation(line: 0, scope: !873, inlinedAt: !2884)
!2884 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2882)
!2885 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2884)
!2886 = !DILocation(line: 0, scope: !777, inlinedAt: !2882)
!2887 = !DILocation(line: 718, column: 10, scope: !1748, inlinedAt: !2882)
!2888 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2882)
!2889 = !DILocation(line: 2493, column: 35, scope: !2879)
!2890 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2882)
!2891 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2882)
!2892 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2882)
!2893 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2882)
!2894 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2882)
!2895 = !DILocation(line: 727, column: 32, scope: !1757, inlinedAt: !2882)
!2896 = !DILocation(line: 727, column: 41, scope: !1757, inlinedAt: !2882)
!2897 = !DILocation(line: 727, column: 46, scope: !1757, inlinedAt: !2882)
!2898 = !DILocation(line: 727, column: 14, scope: !1757, inlinedAt: !2882)
!2899 = !DILocation(line: 727, column: 5, scope: !1757, inlinedAt: !2882)
!2900 = !DILocation(line: 2495, column: 35, scope: !2879)
!2901 = !DILocation(line: 0, scope: !607, inlinedAt: !2902)
!2902 = distinct !DILocation(line: 2495, column: 16, scope: !2879)
!2903 = !DILocation(line: 0, scope: !873, inlinedAt: !2904)
!2904 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2902)
!2905 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2904)
!2906 = !DILocation(line: 0, scope: !618, inlinedAt: !2902)
!2907 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2902)
!2908 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !2902)
!2909 = !DILocation(line: 350, column: 10, scope: !1675, inlinedAt: !2902)
!2910 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !2902)
!2911 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !2902)
!2912 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !2902)
!2913 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !2902)
!2914 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !2902)
!2915 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !2902)
!2916 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !2902)
!2917 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !2902)
!2918 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !2902)
!2919 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !2902)
!2920 = !DILocation(line: 356, column: 36, scope: !1687, inlinedAt: !2902)
!2921 = !DILocation(line: 356, column: 27, scope: !1687, inlinedAt: !2902)
!2922 = !DILocation(line: 356, column: 16, scope: !1687, inlinedAt: !2902)
!2923 = !DILocation(line: 356, column: 5, scope: !1687, inlinedAt: !2902)
!2924 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !2902)
!2925 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !2902)
!2926 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !2902)
!2927 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !2902)
!2928 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !2902)
!2929 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !2902)
!2930 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !2902)
!2931 = !DILocation(line: 0, scope: !765, inlinedAt: !2932)
!2932 = distinct !DILocation(line: 2497, column: 17, scope: !2879)
!2933 = !DILocation(line: 0, scope: !873, inlinedAt: !2934)
!2934 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2932)
!2935 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2934)
!2936 = !DILocation(line: 0, scope: !777, inlinedAt: !2932)
!2937 = !DILocation(line: 718, column: 10, scope: !1748, inlinedAt: !2932)
!2938 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2932)
!2939 = !DILocation(line: 2497, column: 36, scope: !2879)
!2940 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2932)
!2941 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2932)
!2942 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2932)
!2943 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2932)
!2944 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2932)
!2945 = !DILocation(line: 727, column: 32, scope: !1757, inlinedAt: !2932)
!2946 = !DILocation(line: 727, column: 41, scope: !1757, inlinedAt: !2932)
!2947 = !DILocation(line: 727, column: 46, scope: !1757, inlinedAt: !2932)
!2948 = !DILocation(line: 727, column: 14, scope: !1757, inlinedAt: !2932)
!2949 = !DILocation(line: 727, column: 5, scope: !1757, inlinedAt: !2932)
!2950 = !DILocation(line: 2497, column: 16, scope: !2879)
!2951 = !DILocation(line: 2497, column: 9, scope: !2879)
!2952 = !DILocation(line: 2499, column: 36, scope: !2879)
!2953 = !DILocation(line: 0, scope: !607, inlinedAt: !2954)
!2954 = distinct !DILocation(line: 2499, column: 17, scope: !2879)
!2955 = !DILocation(line: 0, scope: !873, inlinedAt: !2956)
!2956 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2954)
!2957 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !2956)
!2958 = !DILocation(line: 0, scope: !618, inlinedAt: !2954)
!2959 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2954)
!2960 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !2954)
!2961 = !DILocation(line: 350, column: 10, scope: !1675, inlinedAt: !2954)
!2962 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !2954)
!2963 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !2954)
!2964 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !2954)
!2965 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !2954)
!2966 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !2954)
!2967 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !2954)
!2968 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !2954)
!2969 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !2954)
!2970 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !2954)
!2971 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !2954)
!2972 = !DILocation(line: 356, column: 36, scope: !1687, inlinedAt: !2954)
!2973 = !DILocation(line: 356, column: 27, scope: !1687, inlinedAt: !2954)
!2974 = !DILocation(line: 356, column: 16, scope: !1687, inlinedAt: !2954)
!2975 = !DILocation(line: 356, column: 5, scope: !1687, inlinedAt: !2954)
!2976 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !2954)
!2977 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !2954)
!2978 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !2954)
!2979 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !2954)
!2980 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !2954)
!2981 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !2954)
!2982 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !2954)
!2983 = !DILocation(line: 2499, column: 16, scope: !2879)
!2984 = !DILocation(line: 2499, column: 9, scope: !2879)
!2985 = !DILocation(line: 0, scope: !2849)
!2986 = !DILocation(line: 2502, column: 1, scope: !2830)
!2987 = distinct !DISubprogram(name: "pts_ieee754_tan", scope: !3, file: !3, line: 2533, type: !4, scopeLine: 2533, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2988)
!2988 = !{!2989, !2990, !2991, !2992, !2993, !2994}
!2989 = !DILocalVariable(name: "x", arg: 1, scope: !2987, file: !3, line: 2533, type: !6)
!2990 = !DILocalVariable(name: "y", scope: !2987, file: !3, line: 2534, type: !1650)
!2991 = !DILocalVariable(name: "z", scope: !2987, file: !3, line: 2534, type: !6)
!2992 = !DILocalVariable(name: "n", scope: !2987, file: !3, line: 2535, type: !18)
!2993 = !DILocalVariable(name: "ix", scope: !2987, file: !3, line: 2535, type: !18)
!2994 = !DILocalVariable(name: "bits", scope: !2995, file: !3, line: 2538, type: !16)
!2995 = distinct !DILexicalBlock(scope: !2987, file: !3, line: 2538, column: 3)
!2996 = !DILocation(line: 0, scope: !2987)
!2997 = !DILocation(line: 2534, column: 3, scope: !2987)
!2998 = !DILocation(line: 2534, column: 10, scope: !2987)
!2999 = !DILocation(line: 0, scope: !873, inlinedAt: !3000)
!3000 = distinct !DILocation(line: 2538, column: 3, scope: !2995)
!3001 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3000)
!3002 = !DILocation(line: 0, scope: !2995)
!3003 = !DILocation(line: 2538, column: 3, scope: !2995)
!3004 = !DILocation(line: 2541, column: 6, scope: !2987)
!3005 = !DILocation(line: 2542, column: 10, scope: !3006)
!3006 = distinct !DILexicalBlock(scope: !2987, file: !3, line: 2542, column: 7)
!3007 = !DILocation(line: 2542, column: 7, scope: !2987)
!3008 = !DILocation(line: 0, scope: !806, inlinedAt: !3009)
!3009 = distinct !DILocation(line: 2543, column: 12, scope: !3010)
!3010 = distinct !DILexicalBlock(scope: !3006, file: !3, line: 2542, column: 25)
!3011 = !DILocation(line: 0, scope: !873, inlinedAt: !3012)
!3012 = distinct !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3009)
!3013 = !DILocation(line: 0, scope: !819, inlinedAt: !3009)
!3014 = !DILocation(line: 793, column: 10, scope: !824, inlinedAt: !3009)
!3015 = !DILocation(line: 793, column: 7, scope: !806, inlinedAt: !3009)
!3016 = !DILocation(line: 816, column: 10, scope: !3017, inlinedAt: !3009)
!3017 = distinct !DILexicalBlock(scope: !806, file: !3, line: 816, column: 7)
!3018 = !DILocation(line: 816, column: 7, scope: !806, inlinedAt: !3009)
!3019 = !DILocation(line: 817, column: 12, scope: !3020, inlinedAt: !3009)
!3020 = distinct !DILexicalBlock(scope: !3021, file: !3, line: 817, column: 9)
!3021 = distinct !DILexicalBlock(scope: !3017, file: !3, line: 816, column: 25)
!3022 = !DILocation(line: 817, column: 9, scope: !3021, inlinedAt: !3009)
!3023 = !DILocation(line: 821, column: 14, scope: !3021, inlinedAt: !3009)
!3024 = !DILocation(line: 823, column: 11, scope: !3021, inlinedAt: !3009)
!3025 = !DILocation(line: 825, column: 3, scope: !3021, inlinedAt: !3009)
!3026 = !DILocation(line: 826, column: 9, scope: !806, inlinedAt: !3009)
!3027 = !DILocation(line: 827, column: 9, scope: !806, inlinedAt: !3009)
!3028 = !DILocation(line: 833, column: 60, scope: !806, inlinedAt: !3009)
!3029 = !DILocation(line: 833, column: 48, scope: !806, inlinedAt: !3009)
!3030 = !DILocation(line: 833, column: 36, scope: !806, inlinedAt: !3009)
!3031 = !DILocation(line: 833, column: 24, scope: !806, inlinedAt: !3009)
!3032 = !DILocation(line: 833, column: 12, scope: !806, inlinedAt: !3009)
!3033 = !DILocation(line: 835, column: 62, scope: !806, inlinedAt: !3009)
!3034 = !DILocation(line: 835, column: 49, scope: !806, inlinedAt: !3009)
!3035 = !DILocation(line: 835, column: 37, scope: !806, inlinedAt: !3009)
!3036 = !DILocation(line: 835, column: 25, scope: !806, inlinedAt: !3009)
!3037 = !DILocation(line: 835, column: 13, scope: !806, inlinedAt: !3009)
!3038 = !DILocation(line: 834, column: 9, scope: !806, inlinedAt: !3009)
!3039 = !DILocation(line: 836, column: 9, scope: !806, inlinedAt: !3009)
!3040 = !DILocation(line: 837, column: 23, scope: !806, inlinedAt: !3009)
!3041 = !DILocation(line: 837, column: 28, scope: !806, inlinedAt: !3009)
!3042 = !DILocation(line: 837, column: 9, scope: !806, inlinedAt: !3009)
!3043 = !DILocation(line: 838, column: 5, scope: !806, inlinedAt: !3009)
!3044 = !DILocation(line: 839, column: 9, scope: !806, inlinedAt: !3009)
!3045 = !DILocation(line: 840, column: 7, scope: !806, inlinedAt: !3009)
!3046 = !DILocation(line: 842, column: 22, scope: !3047, inlinedAt: !3009)
!3047 = distinct !DILexicalBlock(scope: !3048, file: !3, line: 840, column: 25)
!3048 = distinct !DILexicalBlock(scope: !806, file: !3, line: 840, column: 7)
!3049 = !DILocation(line: 842, column: 29, scope: !3047, inlinedAt: !3009)
!3050 = !DILocation(line: 842, column: 15, scope: !3047, inlinedAt: !3009)
!3051 = !DILocation(line: 842, column: 12, scope: !3047, inlinedAt: !3009)
!3052 = !DILocation(line: 842, column: 56, scope: !3047, inlinedAt: !3009)
!3053 = !DILocation(line: 842, column: 65, scope: !3047, inlinedAt: !3009)
!3054 = !DILocation(line: 842, column: 60, scope: !3047, inlinedAt: !3009)
!3055 = !DILocation(line: 842, column: 70, scope: !3047, inlinedAt: !3009)
!3056 = !DILocation(line: 842, column: 51, scope: !3047, inlinedAt: !3009)
!3057 = !DILocation(line: 842, column: 40, scope: !3047, inlinedAt: !3009)
!3058 = !DILocation(line: 842, column: 35, scope: !3047, inlinedAt: !3009)
!3059 = !DILocation(line: 842, column: 5, scope: !3047, inlinedAt: !3009)
!3060 = !DILocation(line: 2544, column: 17, scope: !3061)
!3061 = distinct !DILexicalBlock(scope: !3006, file: !3, line: 2544, column: 14)
!3062 = !DILocation(line: 2544, column: 14, scope: !3006)
!3063 = !DILocation(line: 2546, column: 14, scope: !3064)
!3064 = distinct !DILexicalBlock(scope: !3061, file: !3, line: 2544, column: 32)
!3065 = !DILocation(line: 2546, column: 5, scope: !3064)
!3066 = !DILocation(line: 2549, column: 9, scope: !3067)
!3067 = distinct !DILexicalBlock(scope: !3061, file: !3, line: 2547, column: 10)
!3068 = !DILocation(line: 2551, column: 25, scope: !3067)
!3069 = !DILocation(line: 2551, column: 31, scope: !3067)
!3070 = !DILocation(line: 2551, column: 50, scope: !3067)
!3071 = !DILocation(line: 2551, column: 39, scope: !3067)
!3072 = !DILocation(line: 0, scope: !806, inlinedAt: !3073)
!3073 = distinct !DILocation(line: 2551, column: 12, scope: !3067)
!3074 = !DILocation(line: 0, scope: !873, inlinedAt: !3075)
!3075 = distinct !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3073)
!3076 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3075)
!3077 = !DILocation(line: 0, scope: !819, inlinedAt: !3073)
!3078 = !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3073)
!3079 = !DILocation(line: 792, column: 11, scope: !806, inlinedAt: !3073)
!3080 = !DILocation(line: 793, column: 10, scope: !824, inlinedAt: !3073)
!3081 = !DILocation(line: 793, column: 7, scope: !806, inlinedAt: !3073)
!3082 = !DILocation(line: 0, scope: !873, inlinedAt: !3083)
!3083 = distinct !DILocation(line: 796, column: 7, scope: !826, inlinedAt: !3073)
!3084 = !DILocation(line: 0, scope: !826, inlinedAt: !3073)
!3085 = !DILocation(line: 796, column: 7, scope: !826, inlinedAt: !3073)
!3086 = !DILocation(line: 0, scope: !821, inlinedAt: !3073)
!3087 = !DILocation(line: 797, column: 29, scope: !831, inlinedAt: !3073)
!3088 = !DILocation(line: 797, column: 23, scope: !831, inlinedAt: !3073)
!3089 = !DILocation(line: 797, column: 35, scope: !831, inlinedAt: !3073)
!3090 = !DILocation(line: 797, column: 11, scope: !821, inlinedAt: !3073)
!3091 = !DILocation(line: 798, column: 22, scope: !3092, inlinedAt: !3073)
!3092 = distinct !DILexicalBlock(scope: !831, file: !3, line: 797, column: 41)
!3093 = !DILocation(line: 798, column: 20, scope: !3092, inlinedAt: !3073)
!3094 = !DILocation(line: 798, column: 9, scope: !3092, inlinedAt: !3073)
!3095 = !DILocation(line: 800, column: 16, scope: !829, inlinedAt: !3073)
!3096 = !DILocation(line: 800, column: 13, scope: !830, inlinedAt: !3073)
!3097 = !DILocation(line: 805, column: 21, scope: !828, inlinedAt: !3073)
!3098 = !DILocation(line: 0, scope: !873, inlinedAt: !3099)
!3099 = distinct !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3073)
!3100 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3099)
!3101 = !DILocation(line: 0, scope: !834, inlinedAt: !3073)
!3102 = !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3073)
!3103 = !DILocation(line: 0, scope: !947, inlinedAt: !3104)
!3104 = distinct !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3073)
!3105 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !3104)
!3106 = !DILocation(line: 807, column: 22, scope: !828, inlinedAt: !3073)
!3107 = !DILocation(line: 807, column: 17, scope: !828, inlinedAt: !3073)
!3108 = !DILocation(line: 808, column: 24, scope: !828, inlinedAt: !3073)
!3109 = !DILocation(line: 0, scope: !828, inlinedAt: !3073)
!3110 = !DILocation(line: 0, scope: !873, inlinedAt: !3111)
!3111 = distinct !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3073)
!3112 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3111)
!3113 = !DILocation(line: 0, scope: !836, inlinedAt: !3073)
!3114 = !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3073)
!3115 = !DILocation(line: 0, scope: !947, inlinedAt: !3116)
!3116 = distinct !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3073)
!3117 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !3116)
!3118 = !DILocation(line: 810, column: 19, scope: !828, inlinedAt: !3073)
!3119 = !DILocation(line: 811, column: 29, scope: !828, inlinedAt: !3073)
!3120 = !DILocation(line: 811, column: 20, scope: !828, inlinedAt: !3073)
!3121 = !DILocation(line: 816, column: 10, scope: !3017, inlinedAt: !3073)
!3122 = !DILocation(line: 816, column: 7, scope: !806, inlinedAt: !3073)
!3123 = !DILocation(line: 817, column: 12, scope: !3020, inlinedAt: !3073)
!3124 = !DILocation(line: 817, column: 9, scope: !3021, inlinedAt: !3073)
!3125 = !DILocation(line: 821, column: 14, scope: !3021, inlinedAt: !3073)
!3126 = !DILocation(line: 822, column: 16, scope: !3021, inlinedAt: !3073)
!3127 = !DILocation(line: 823, column: 11, scope: !3021, inlinedAt: !3073)
!3128 = !DILocation(line: 825, column: 3, scope: !3021, inlinedAt: !3073)
!3129 = !DILocation(line: 826, column: 9, scope: !806, inlinedAt: !3073)
!3130 = !DILocation(line: 827, column: 9, scope: !806, inlinedAt: !3073)
!3131 = !DILocation(line: 833, column: 60, scope: !806, inlinedAt: !3073)
!3132 = !DILocation(line: 833, column: 48, scope: !806, inlinedAt: !3073)
!3133 = !DILocation(line: 833, column: 36, scope: !806, inlinedAt: !3073)
!3134 = !DILocation(line: 833, column: 24, scope: !806, inlinedAt: !3073)
!3135 = !DILocation(line: 833, column: 12, scope: !806, inlinedAt: !3073)
!3136 = !DILocation(line: 835, column: 62, scope: !806, inlinedAt: !3073)
!3137 = !DILocation(line: 835, column: 49, scope: !806, inlinedAt: !3073)
!3138 = !DILocation(line: 835, column: 37, scope: !806, inlinedAt: !3073)
!3139 = !DILocation(line: 835, column: 25, scope: !806, inlinedAt: !3073)
!3140 = !DILocation(line: 835, column: 13, scope: !806, inlinedAt: !3073)
!3141 = !DILocation(line: 834, column: 9, scope: !806, inlinedAt: !3073)
!3142 = !DILocation(line: 836, column: 9, scope: !806, inlinedAt: !3073)
!3143 = !DILocation(line: 837, column: 23, scope: !806, inlinedAt: !3073)
!3144 = !DILocation(line: 837, column: 28, scope: !806, inlinedAt: !3073)
!3145 = !DILocation(line: 837, column: 9, scope: !806, inlinedAt: !3073)
!3146 = !DILocation(line: 838, column: 5, scope: !806, inlinedAt: !3073)
!3147 = !DILocation(line: 839, column: 9, scope: !806, inlinedAt: !3073)
!3148 = !DILocation(line: 840, column: 7, scope: !806, inlinedAt: !3073)
!3149 = !DILocation(line: 841, column: 9, scope: !3047, inlinedAt: !3073)
!3150 = !DILocation(line: 842, column: 22, scope: !3047, inlinedAt: !3073)
!3151 = !DILocation(line: 842, column: 29, scope: !3047, inlinedAt: !3073)
!3152 = !DILocation(line: 842, column: 15, scope: !3047, inlinedAt: !3073)
!3153 = !DILocation(line: 842, column: 12, scope: !3047, inlinedAt: !3073)
!3154 = !DILocation(line: 842, column: 56, scope: !3047, inlinedAt: !3073)
!3155 = !DILocation(line: 842, column: 65, scope: !3047, inlinedAt: !3073)
!3156 = !DILocation(line: 842, column: 60, scope: !3047, inlinedAt: !3073)
!3157 = !DILocation(line: 842, column: 70, scope: !3047, inlinedAt: !3073)
!3158 = !DILocation(line: 842, column: 51, scope: !3047, inlinedAt: !3073)
!3159 = !DILocation(line: 842, column: 40, scope: !3047, inlinedAt: !3073)
!3160 = !DILocation(line: 842, column: 35, scope: !3047, inlinedAt: !3073)
!3161 = !DILocation(line: 842, column: 5, scope: !3047, inlinedAt: !3073)
!3162 = !DILocation(line: 844, column: 10, scope: !839, inlinedAt: !3073)
!3163 = !DILocation(line: 844, column: 7, scope: !806, inlinedAt: !3073)
!3164 = !DILocation(line: 0, scope: !873, inlinedAt: !3165)
!3165 = distinct !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3073)
!3166 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3165)
!3167 = !DILocation(line: 0, scope: !842, inlinedAt: !3073)
!3168 = !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3073)
!3169 = !DILocation(line: 0, scope: !947, inlinedAt: !3170)
!3170 = distinct !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3073)
!3171 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !3170)
!3172 = !DILocation(line: 855, column: 16, scope: !838, inlinedAt: !3073)
!3173 = !DILocation(line: 855, column: 11, scope: !838, inlinedAt: !3073)
!3174 = !DILocation(line: 856, column: 18, scope: !838, inlinedAt: !3073)
!3175 = !DILocation(line: 0, scope: !838, inlinedAt: !3073)
!3176 = !DILocation(line: 0, scope: !873, inlinedAt: !3177)
!3177 = distinct !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3073)
!3178 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3177)
!3179 = !DILocation(line: 0, scope: !844, inlinedAt: !3073)
!3180 = !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3073)
!3181 = !DILocation(line: 0, scope: !947, inlinedAt: !3182)
!3182 = distinct !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3073)
!3183 = !DILocation(line: 62, column: 3, scope: !947, inlinedAt: !3182)
!3184 = !DILocation(line: 858, column: 13, scope: !838, inlinedAt: !3073)
!3185 = !DILocation(line: 859, column: 23, scope: !838, inlinedAt: !3073)
!3186 = !DILocation(line: 859, column: 14, scope: !838, inlinedAt: !3073)
!3187 = !DILocation(line: 0, scope: !3006)
!3188 = !DILocation(line: 2553, column: 1, scope: !2987)
!3189 = !DILocation(line: 0, scope: !545)
!3190 = !DILocation(line: 0, scope: !873, inlinedAt: !3191)
!3191 = distinct !DILocation(line: 2585, column: 3, scope: !550)
!3192 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3191)
!3193 = !DILocation(line: 0, scope: !550)
!3194 = !DILocation(line: 2585, column: 3, scope: !550)
!3195 = !DILocation(line: 2586, column: 6, scope: !545)
!3196 = !DILocation(line: 2589, column: 10, scope: !553)
!3197 = !DILocation(line: 2589, column: 7, scope: !545)
!3198 = !DILocation(line: 2590, column: 34, scope: !552)
!3199 = !DILocation(line: 2590, column: 16, scope: !552)
!3200 = !DILocation(line: 0, scope: !552)
!3201 = !DILocation(line: 2591, column: 20, scope: !552)
!3202 = !DILocation(line: 2593, column: 12, scope: !3203)
!3203 = distinct !DILexicalBlock(scope: !552, file: !3, line: 2593, column: 9)
!3204 = !DILocation(line: 2593, column: 9, scope: !552)
!3205 = !DILocation(line: 2594, column: 21, scope: !552)
!3206 = !DILocation(line: 2594, column: 31, scope: !552)
!3207 = !DILocation(line: 2594, column: 26, scope: !552)
!3208 = !DILocation(line: 2594, column: 16, scope: !552)
!3209 = !DILocation(line: 2594, column: 5, scope: !552)
!3210 = !DILocation(line: 2598, column: 10, scope: !557)
!3211 = !DILocation(line: 2598, column: 7, scope: !545)
!3212 = !DILocation(line: 2599, column: 32, scope: !556)
!3213 = !DILocation(line: 2599, column: 16, scope: !556)
!3214 = !DILocation(line: 0, scope: !556)
!3215 = !DILocation(line: 2600, column: 28, scope: !556)
!3216 = !DILocation(line: 2600, column: 21, scope: !556)
!3217 = !DILocation(line: 2604, column: 10, scope: !3218)
!3218 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2604, column: 7)
!3219 = !DILocation(line: 2604, column: 7, scope: !545)
!3220 = !DILocation(line: 2604, column: 38, scope: !3218)
!3221 = !DILocation(line: 2604, column: 36, scope: !3218)
!3222 = !DILocation(line: 2604, column: 24, scope: !3218)
!3223 = !DILocation(line: 2607, column: 15, scope: !560)
!3224 = !DILocation(line: 2607, column: 7, scope: !545)
!3225 = !DILocation(line: 2608, column: 37, scope: !559)
!3226 = !DILocation(line: 2608, column: 16, scope: !559)
!3227 = !DILocation(line: 0, scope: !559)
!3228 = !DILocation(line: 2609, column: 21, scope: !559)
!3229 = !DILocation(line: 2610, column: 14, scope: !559)
!3230 = !DILocation(line: 2614, column: 10, scope: !3231)
!3231 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2614, column: 7)
!3232 = !DILocation(line: 2614, column: 7, scope: !545)
!3233 = !DILocation(line: 2614, column: 34, scope: !3231)
!3234 = !DILocation(line: 2614, column: 25, scope: !3231)
!3235 = !DILocation(line: 2617, column: 10, scope: !545)
!3236 = !DILocation(line: 2617, column: 17, scope: !545)
!3237 = !DILocation(line: 2617, column: 15, scope: !545)
!3238 = !DILocation(line: 2617, column: 3, scope: !545)
!3239 = !DILocation(line: 2618, column: 1, scope: !545)
!3240 = !DILocation(line: 0, scope: !570)
!3241 = !DILocation(line: 2648, column: 17, scope: !570)
!3242 = !DILocation(line: 2648, column: 14, scope: !570)
!3243 = !DILocation(line: 2650, column: 15, scope: !570)
!3244 = !DILocation(line: 2651, column: 10, scope: !577)
!3245 = !DILocation(line: 2651, column: 7, scope: !570)
!3246 = !DILocation(line: 2653, column: 12, scope: !3247)
!3247 = distinct !DILexicalBlock(scope: !576, file: !3, line: 2653, column: 9)
!3248 = !DILocation(line: 2653, column: 9, scope: !576)
!3249 = !DILocation(line: 2654, column: 16, scope: !576)
!3250 = !DILocation(line: 0, scope: !576)
!3251 = !DILocation(line: 2655, column: 12, scope: !3252)
!3252 = distinct !DILexicalBlock(scope: !576, file: !3, line: 2655, column: 9)
!3253 = !DILocation(line: 2655, column: 9, scope: !576)
!3254 = !DILocation(line: 2656, column: 25, scope: !3255)
!3255 = distinct !DILexicalBlock(scope: !3252, file: !3, line: 2655, column: 17)
!3256 = !DILocation(line: 2656, column: 7, scope: !3255)
!3257 = !DILocation(line: 2658, column: 23, scope: !576)
!3258 = !DILocation(line: 2658, column: 19, scope: !576)
!3259 = !DILocation(line: 2658, column: 5, scope: !576)
!3260 = !DILocation(line: 2661, column: 10, scope: !3261)
!3261 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2661, column: 7)
!3262 = !DILocation(line: 2661, column: 7, scope: !570)
!3263 = !DILocation(line: 2661, column: 33, scope: !3261)
!3264 = !DILocation(line: 2661, column: 31, scope: !3261)
!3265 = !DILocation(line: 2661, column: 22, scope: !3261)
!3266 = !DILocation(line: 2664, column: 10, scope: !580)
!3267 = !DILocation(line: 2664, column: 7, scope: !570)
!3268 = !DILocation(line: 2665, column: 36, scope: !579)
!3269 = !DILocation(line: 2665, column: 16, scope: !579)
!3270 = !DILocation(line: 0, scope: !579)
!3271 = !DILocation(line: 2666, column: 18, scope: !579)
!3272 = !DILocation(line: 2667, column: 14, scope: !579)
!3273 = !DILocation(line: 2671, column: 12, scope: !570)
!3274 = !DILocation(line: 2671, column: 3, scope: !570)
!3275 = !DILocation(line: 2672, column: 1, scope: !570)
!3276 = !DILocation(line: 0, scope: !590)
!3277 = !DILocation(line: 0, scope: !873, inlinedAt: !3278)
!3278 = distinct !DILocation(line: 2703, column: 3, scope: !598)
!3279 = !DILocation(line: 56, column: 3, scope: !873, inlinedAt: !3278)
!3280 = !DILocation(line: 0, scope: !598)
!3281 = !DILocation(line: 2703, column: 3, scope: !598)
!3282 = !DILocation(line: 2704, column: 11, scope: !590)
!3283 = !DILocation(line: 2707, column: 10, scope: !3284)
!3284 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2707, column: 7)
!3285 = !DILocation(line: 2707, column: 7, scope: !590)
!3286 = !DILocation(line: 2708, column: 12, scope: !3287)
!3287 = distinct !DILexicalBlock(scope: !3288, file: !3, line: 2708, column: 9)
!3288 = distinct !DILexicalBlock(scope: !3284, file: !3, line: 2707, column: 25)
!3289 = !DILocation(line: 0, scope: !3287)
!3290 = !DILocation(line: 2708, column: 9, scope: !3288)
!3291 = !DILocation(line: 2709, column: 22, scope: !3287)
!3292 = !DILocation(line: 2709, column: 7, scope: !3287)
!3293 = !DILocation(line: 2711, column: 22, scope: !3287)
!3294 = !DILocation(line: 2711, column: 7, scope: !3287)
!3295 = !DILocation(line: 2715, column: 10, scope: !3296)
!3296 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2715, column: 7)
!3297 = !DILocation(line: 2715, column: 7, scope: !590)
!3298 = !DILocation(line: 2716, column: 12, scope: !3299)
!3299 = distinct !DILexicalBlock(scope: !3300, file: !3, line: 2716, column: 9)
!3300 = distinct !DILexicalBlock(scope: !3296, file: !3, line: 2715, column: 24)
!3301 = !DILocation(line: 2716, column: 9, scope: !3300)
!3302 = !DILocation(line: 2719, column: 12, scope: !3303)
!3303 = distinct !DILexicalBlock(scope: !3300, file: !3, line: 2719, column: 9)
!3304 = !DILocation(line: 0, scope: !3303)
!3305 = !DILocation(line: 2719, column: 9, scope: !3300)
!3306 = !DILocation(line: 2720, column: 33, scope: !3307)
!3307 = distinct !DILexicalBlock(scope: !3303, file: !3, line: 2719, column: 27)
!3308 = !DILocation(line: 2720, column: 11, scope: !3307)
!3309 = !DILocation(line: 2721, column: 26, scope: !3307)
!3310 = !DILocation(line: 2721, column: 21, scope: !3307)
!3311 = !DILocation(line: 2721, column: 15, scope: !3307)
!3312 = !DILocation(line: 2722, column: 5, scope: !3307)
!3313 = !DILocation(line: 2723, column: 34, scope: !3314)
!3314 = distinct !DILexicalBlock(scope: !3303, file: !3, line: 2722, column: 12)
!3315 = !DILocation(line: 2723, column: 11, scope: !3314)
!3316 = !DILocation(line: 2724, column: 11, scope: !3314)
!3317 = !DILocation(line: 2724, column: 19, scope: !3314)
!3318 = !DILocation(line: 2724, column: 14, scope: !3314)
!3319 = !DILocation(line: 2728, column: 15, scope: !3320)
!3320 = distinct !DILexicalBlock(scope: !3296, file: !3, line: 2727, column: 10)
!3321 = !DILocation(line: 2728, column: 13, scope: !3320)
!3322 = !DILocation(line: 0, scope: !3296)
!3323 = !DILocation(line: 2730, column: 10, scope: !590)
!3324 = !DILocation(line: 2730, column: 3, scope: !590)
!3325 = !DILocation(line: 2731, column: 1, scope: !590)
!3326 = !DISubprogram(name: "scalbn", scope: !3327, file: !3327, line: 2, type: !3328, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3327 = !DIFile(filename: "darwin_inc/math.h", directory: "/tmp/pts-h36/repro/clang_on")
!3328 = !DISubroutineType(types: !3329)
!3329 = !{!6, !6, !15}
