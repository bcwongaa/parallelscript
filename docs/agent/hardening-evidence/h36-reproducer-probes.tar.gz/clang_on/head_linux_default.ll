; ModuleID = '../src/ieee754_head.c'
source_filename = "../src/ieee754_head.c"
target datalayout = "e-m:e-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128"
target triple = "aarch64-unknown-linux-gnu"

@pts_ieee754_atan.atanhi = internal unnamed_addr constant [4 x double] [double 0x3FDDAC670561BB4F, double 0x3FE921FB54442D18, double 0x3FEF730BD281F69B, double 0x3FF921FB54442D18], align 8, !dbg !0
@pts_ieee754_atan.atanlo = internal constant [4 x double] [double 0x3C7A2B7F222F65E2, double 0x3C81A62633145C07, double 0x3C7007887AF0CBBD, double 0x3C91A62633145C07], align 8, !dbg !154
@pts_ieee754_atan2.tiny = internal global double 1.000000e-300, align 8, !dbg !168
@pts_ieee754_atan2.pi_lo = internal global double 0x3CA1A62633145C07, align 8, !dbg !197
@pts_ieee754_exp.halF = internal unnamed_addr constant [2 x double] [double 5.000000e-01, double -5.000000e-01], align 8, !dbg !229
@pts_ieee754_exp.ln2HI = internal unnamed_addr constant [2 x double] [double 0x3FE62E42FEE00000, double 0xBFE62E42FEE00000], align 8, !dbg !238
@pts_ieee754_exp.ln2LO = internal unnamed_addr constant [2 x double] [double 0x3DEA39EF35793C76, double 0xBDEA39EF35793C76], align 8, !dbg !240
@pts_ieee754_exp.huge = internal global double 1.000000e+300, align 8, !dbg !256
@pts_ieee754_exp.twom1000 = internal global double 0x170000000000000, align 8, !dbg !258
@pts_ieee754_exp.two1023 = internal global double 0x7FE0000000000000, align 8, !dbg !260
@pts_ieee754_expm1.huge = internal global double 1.000000e+300, align 8, !dbg !501
@pts_ieee754_cosh.huge = internal global double 1.000000e+300, align 8, !dbg !566
@pts_ieee754_tanh.tiny = internal constant double 1.000000e-300, align 8, !dbg !588
@__ieee754_rem_pio2.two_over_pi = internal unnamed_addr constant [66 x i32] [i32 10680707, i32 7228996, i32 1387004, i32 2578385, i32 16069853, i32 12639074, i32 9804092, i32 4427841, i32 16666979, i32 11263675, i32 12935607, i32 2387514, i32 4345298, i32 14681673, i32 3074569, i32 13734428, i32 16653803, i32 1880361, i32 10960616, i32 8533493, i32 3062596, i32 8710556, i32 7349940, i32 6258241, i32 3772886, i32 3769171, i32 3798172, i32 8675211, i32 12450088, i32 3874808, i32 9961438, i32 366607, i32 15675153, i32 9132554, i32 7151469, i32 3571407, i32 2607881, i32 12013382, i32 4155038, i32 6285869, i32 7677882, i32 13102053, i32 15825725, i32 473591, i32 9065106, i32 15363067, i32 6271263, i32 9264392, i32 5636912, i32 4652155, i32 7056368, i32 13614112, i32 10155062, i32 1944035, i32 9527646, i32 15080200, i32 6658437, i32 6231200, i32 6832269, i32 16767104, i32 5075751, i32 3212806, i32 1398474, i32 7579849, i32 6349435, i32 12618859], align 4, !dbg !637
@__ieee754_rem_pio2.npio2_hw = internal unnamed_addr constant [32 x i32] [i32 1073291771, i32 1074340347, i32 1074977148, i32 1075388923, i32 1075800698, i32 1076025724, i32 1076231611, i32 1076437499, i32 1076643386, i32 1076849274, i32 1076971356, i32 1077074300, i32 1077177244, i32 1077280187, i32 1077383131, i32 1077486075, i32 1077589019, i32 1077691962, i32 1077794906, i32 1077897850, i32 1077968460, i32 1078019932, i32 1078071404, i32 1078122876, i32 1078174348, i32 1078225820, i32 1078277292, i32 1078328763, i32 1078380235, i32 1078431707, i32 1078483179, i32 1078534651], align 4, !dbg !686

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_acos(double noundef %0) local_unnamed_addr #0 !dbg !22 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !24, metadata !DIExpression()), !dbg !873
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !880
  %2 = bitcast double %0 to i64, !dbg !882
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !880
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !35, metadata !DIExpression()), !dbg !883
  %3 = lshr i64 %2, 32, !dbg !884
  %4 = trunc i64 %3 to i32, !dbg !884
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !33, metadata !DIExpression()), !dbg !873
  %5 = and i32 %4, 2147483647, !dbg !885
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !34, metadata !DIExpression()), !dbg !873
  %6 = icmp ugt i32 %5, 1072693247, !dbg !886
  br i1 %6, label %7, label %15, !dbg !887

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !888
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !888
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !40, metadata !DIExpression()), !dbg !890
  %8 = trunc i64 %2 to i32, !dbg !891
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !37, metadata !DIExpression()), !dbg !892
  %9 = add nsw i32 %5, -1072693248, !dbg !893
  %10 = or i32 %9, %8, !dbg !895
  %11 = icmp eq i32 %10, 0, !dbg !896
  %12 = icmp sgt i32 %4, 0, !dbg !897
  %13 = select i1 %12, double 0.000000e+00, double 0x400921FB54442D18, !dbg !897
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !897
  br label %81

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !898
  br i1 %16, label %17, label %36, !dbg !899

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1012924417, !dbg !900
  br i1 %18, label %81, label %19, !dbg !903

19:                                               ; preds = %17
  %20 = fmul double %0, %0, !dbg !904
  tail call void @llvm.dbg.value(metadata double %20, metadata !25, metadata !DIExpression()), !dbg !873
  %21 = tail call double @llvm.fmuladd.f64(double %20, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !905
  %22 = tail call double @llvm.fmuladd.f64(double %20, double %21, double 0xBFA48228B5688F3B), !dbg !906
  %23 = tail call double @llvm.fmuladd.f64(double %20, double %22, double 0x3FC9C1550E884455), !dbg !907
  %24 = tail call double @llvm.fmuladd.f64(double %20, double %23, double 0xBFD4D61203EB6F7D), !dbg !908
  %25 = tail call double @llvm.fmuladd.f64(double %20, double %24, double 0x3FC5555555555555), !dbg !909
  %26 = fmul double %20, %25, !dbg !910
  tail call void @llvm.dbg.value(metadata double %26, metadata !26, metadata !DIExpression()), !dbg !873
  %27 = tail call double @llvm.fmuladd.f64(double %20, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !911
  %28 = tail call double @llvm.fmuladd.f64(double %20, double %27, double 0x40002AE59C598AC8), !dbg !912
  %29 = tail call double @llvm.fmuladd.f64(double %20, double %28, double 0xC0033A271C8A2D4B), !dbg !913
  %30 = tail call double @llvm.fmuladd.f64(double %20, double %29, double 1.000000e+00), !dbg !914
  tail call void @llvm.dbg.value(metadata double %30, metadata !27, metadata !DIExpression()), !dbg !873
  %31 = fdiv double %26, %30, !dbg !915
  tail call void @llvm.dbg.value(metadata double %31, metadata !28, metadata !DIExpression()), !dbg !873
  %32 = fneg double %0, !dbg !916
  %33 = tail call double @llvm.fmuladd.f64(double %32, double %31, double 0x3C91A62633145C07), !dbg !916
  %34 = fsub double %33, %0, !dbg !917
  %35 = fadd double %34, 0x3FF921FB54442D18, !dbg !917
  br label %81, !dbg !918

36:                                               ; preds = %15
  %37 = icmp slt i64 %2, 0, !dbg !919
  br i1 %37, label %38, label %56, !dbg !920

38:                                               ; preds = %36
  %39 = fadd double %0, 1.000000e+00, !dbg !921
  %40 = fmul double %39, 5.000000e-01, !dbg !923
  tail call void @llvm.dbg.value(metadata double %40, metadata !25, metadata !DIExpression()), !dbg !873
  %41 = tail call double @llvm.fmuladd.f64(double %40, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !924
  %42 = tail call double @llvm.fmuladd.f64(double %40, double %41, double 0xBFA48228B5688F3B), !dbg !925
  %43 = tail call double @llvm.fmuladd.f64(double %40, double %42, double 0x3FC9C1550E884455), !dbg !926
  %44 = tail call double @llvm.fmuladd.f64(double %40, double %43, double 0xBFD4D61203EB6F7D), !dbg !927
  %45 = tail call double @llvm.fmuladd.f64(double %40, double %44, double 0x3FC5555555555555), !dbg !928
  %46 = fmul double %40, %45, !dbg !929
  tail call void @llvm.dbg.value(metadata double %46, metadata !26, metadata !DIExpression()), !dbg !873
  %47 = tail call double @llvm.fmuladd.f64(double %40, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !930
  %48 = tail call double @llvm.fmuladd.f64(double %40, double %47, double 0x40002AE59C598AC8), !dbg !931
  %49 = tail call double @llvm.fmuladd.f64(double %40, double %48, double 0xC0033A271C8A2D4B), !dbg !932
  %50 = tail call double @llvm.fmuladd.f64(double %40, double %49, double 1.000000e+00), !dbg !933
  tail call void @llvm.dbg.value(metadata double %50, metadata !27, metadata !DIExpression()), !dbg !873
  %51 = tail call double @llvm.sqrt.f64(double %40), !dbg !934
  tail call void @llvm.dbg.value(metadata double %51, metadata !30, metadata !DIExpression()), !dbg !873
  %52 = fdiv double %46, %50, !dbg !935
  tail call void @llvm.dbg.value(metadata double %52, metadata !28, metadata !DIExpression()), !dbg !873
  %53 = tail call double @llvm.fmuladd.f64(double %52, double %51, double 0xBC91A62633145C07), !dbg !936
  tail call void @llvm.dbg.value(metadata double %53, metadata !29, metadata !DIExpression()), !dbg !873
  %54 = fadd double %51, %53, !dbg !937
  %55 = tail call double @llvm.fmuladd.f64(double %54, double -2.000000e+00, double 0x400921FB54442D18), !dbg !938
  br label %81, !dbg !939

56:                                               ; preds = %36
  %57 = fsub double 1.000000e+00, %0, !dbg !940
  %58 = fmul double %57, 5.000000e-01, !dbg !941
  tail call void @llvm.dbg.value(metadata double %58, metadata !25, metadata !DIExpression()), !dbg !873
  %59 = tail call double @llvm.sqrt.f64(double %58), !dbg !942
  tail call void @llvm.dbg.value(metadata double %59, metadata !30, metadata !DIExpression()), !dbg !873
  tail call void @llvm.dbg.value(metadata double %59, metadata !32, metadata !DIExpression()), !dbg !873
  tail call void @llvm.dbg.value(metadata double %59, metadata !874, metadata !DIExpression()), !dbg !943
  %60 = bitcast double %59 to i64, !dbg !945
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !879, metadata !DIExpression()), !dbg !943
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !42, metadata !DIExpression()), !dbg !946
  %61 = and i64 %60, -4294967296, !dbg !947
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !42, metadata !DIExpression()), !dbg !946
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !42, metadata !DIExpression()), !dbg !946
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !948, metadata !DIExpression()), !dbg !954
  %62 = bitcast i64 %61 to double, !dbg !956
  tail call void @llvm.dbg.value(metadata double %62, metadata !953, metadata !DIExpression()), !dbg !954
  tail call void @llvm.dbg.value(metadata double %62, metadata !32, metadata !DIExpression()), !dbg !873
  %63 = fneg double %62, !dbg !957
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %58), !dbg !957
  %65 = fadd double %59, %62, !dbg !958
  %66 = fdiv double %64, %65, !dbg !959
  tail call void @llvm.dbg.value(metadata double %66, metadata !31, metadata !DIExpression()), !dbg !873
  %67 = tail call double @llvm.fmuladd.f64(double %58, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !960
  %68 = tail call double @llvm.fmuladd.f64(double %58, double %67, double 0xBFA48228B5688F3B), !dbg !961
  %69 = tail call double @llvm.fmuladd.f64(double %58, double %68, double 0x3FC9C1550E884455), !dbg !962
  %70 = tail call double @llvm.fmuladd.f64(double %58, double %69, double 0xBFD4D61203EB6F7D), !dbg !963
  %71 = tail call double @llvm.fmuladd.f64(double %58, double %70, double 0x3FC5555555555555), !dbg !964
  %72 = fmul double %58, %71, !dbg !965
  tail call void @llvm.dbg.value(metadata double %72, metadata !26, metadata !DIExpression()), !dbg !873
  %73 = tail call double @llvm.fmuladd.f64(double %58, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !966
  %74 = tail call double @llvm.fmuladd.f64(double %58, double %73, double 0x40002AE59C598AC8), !dbg !967
  %75 = tail call double @llvm.fmuladd.f64(double %58, double %74, double 0xC0033A271C8A2D4B), !dbg !968
  %76 = tail call double @llvm.fmuladd.f64(double %58, double %75, double 1.000000e+00), !dbg !969
  tail call void @llvm.dbg.value(metadata double %76, metadata !27, metadata !DIExpression()), !dbg !873
  %77 = fdiv double %72, %76, !dbg !970
  tail call void @llvm.dbg.value(metadata double %77, metadata !28, metadata !DIExpression()), !dbg !873
  %78 = tail call double @llvm.fmuladd.f64(double %77, double %59, double %66), !dbg !971
  tail call void @llvm.dbg.value(metadata double %78, metadata !29, metadata !DIExpression()), !dbg !873
  %79 = fadd double %78, %62, !dbg !972
  %80 = fmul double %79, 2.000000e+00, !dbg !973
  br label %81, !dbg !974

81:                                               ; preds = %17, %56, %38, %19, %7
  %82 = phi double [ %14, %7 ], [ %35, %19 ], [ %55, %38 ], [ %80, %56 ], [ 0x3FF921FB54442D18, %17 ], !dbg !873
  ret double %82, !dbg !975
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fmuladd.f64(double, double, double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_acosh(double noundef %0) local_unnamed_addr #0 !dbg !76 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !78, metadata !DIExpression()), !dbg !976
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !977
  %2 = bitcast double %0 to i64, !dbg !979
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !977
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !82, metadata !DIExpression()), !dbg !980
  %3 = lshr i64 %2, 32, !dbg !981
  %4 = trunc i64 %3 to i32, !dbg !981
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !80, metadata !DIExpression()), !dbg !976
  %5 = trunc i64 %2 to i32, !dbg !981
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !81, metadata !DIExpression()), !dbg !976
  %6 = icmp slt i32 %4, 1072693248, !dbg !982
  br i1 %6, label %37, label %7, !dbg !984

7:                                                ; preds = %1
  %8 = icmp ugt i32 %4, 1102053375, !dbg !985
  br i1 %8, label %9, label %16, !dbg !987

9:                                                ; preds = %7
  %10 = icmp ugt i32 %4, 2146435071, !dbg !988
  br i1 %10, label %11, label %13, !dbg !991

11:                                               ; preds = %9
  %12 = fadd double %0, %0, !dbg !992
  br label %37, !dbg !994

13:                                               ; preds = %9
  %14 = tail call double @pts_ieee754_log(double noundef %0), !dbg !995
  %15 = fadd double %14, 0x3FE62E42FEFA39EF, !dbg !997
  br label %37, !dbg !998

16:                                               ; preds = %7
  %17 = add nsw i32 %4, -1072693248, !dbg !999
  %18 = or i32 %17, %5, !dbg !1001
  %19 = icmp eq i32 %18, 0, !dbg !1002
  br i1 %19, label %37, label %20, !dbg !1003

20:                                               ; preds = %16
  %21 = icmp ugt i32 %4, 1073741824, !dbg !1004
  br i1 %21, label %22, label %30, !dbg !1006

22:                                               ; preds = %20
  %23 = fmul double %0, %0, !dbg !1007
  tail call void @llvm.dbg.value(metadata double %23, metadata !79, metadata !DIExpression()), !dbg !976
  %24 = fadd double %23, -1.000000e+00, !dbg !1009
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1010
  %26 = fadd double %25, %0, !dbg !1011
  %27 = fdiv double -1.000000e+00, %26, !dbg !1012
  %28 = tail call double @llvm.fmuladd.f64(double %0, double 2.000000e+00, double %27), !dbg !1012
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1013
  br label %37, !dbg !1014

30:                                               ; preds = %20
  %31 = fadd double %0, -1.000000e+00, !dbg !1015
  tail call void @llvm.dbg.value(metadata double %31, metadata !79, metadata !DIExpression()), !dbg !976
  %32 = fmul double %31, %31, !dbg !1017
  %33 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double %32), !dbg !1018
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1019
  %35 = fadd double %31, %34, !dbg !1020
  %36 = tail call double @pts_ieee754_log1p(double noundef %35), !dbg !1021
  br label %37, !dbg !1022

37:                                               ; preds = %16, %1, %30, %22, %13, %11
  %38 = phi double [ %12, %11 ], [ %15, %13 ], [ %29, %22 ], [ %36, %30 ], [ 0x7FF8000000000000, %1 ], [ 0.000000e+00, %16 ], !dbg !1023
  ret double %38, !dbg !1024
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log(double noundef %0) local_unnamed_addr #0 !dbg !281 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !283, metadata !DIExpression()), !dbg !1025
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1026
  %2 = bitcast double %0 to i64, !dbg !1028
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1026
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !298, metadata !DIExpression()), !dbg !1029
  %3 = lshr i64 %2, 32, !dbg !1030
  %4 = trunc i64 %3 to i32, !dbg !1030
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !294, metadata !DIExpression()), !dbg !1025
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !297, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1025
  tail call void @llvm.dbg.value(metadata i32 0, metadata !293, metadata !DIExpression()), !dbg !1025
  %5 = icmp slt i32 %4, 1048576, !dbg !1031
  br i1 %5, label %6, label %18, !dbg !1032

6:                                                ; preds = %1
  %7 = trunc i64 %2 to i32, !dbg !1030
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !297, metadata !DIExpression()), !dbg !1025
  %8 = and i32 %4, 2147483647, !dbg !1033
  %9 = or i32 %8, %7, !dbg !1035
  %10 = icmp eq i32 %9, 0, !dbg !1036
  br i1 %10, label %114, label %11, !dbg !1037

11:                                               ; preds = %6
  %12 = icmp slt i64 %2, 0, !dbg !1038
  br i1 %12, label %114, label %13, !dbg !1040

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !293, metadata !DIExpression()), !dbg !1025
  %14 = fmul double %0, 0x4350000000000000, !dbg !1041
  tail call void @llvm.dbg.value(metadata double %14, metadata !283, metadata !DIExpression()), !dbg !1025
  tail call void @llvm.dbg.value(metadata double %14, metadata !874, metadata !DIExpression()), !dbg !1042
  %15 = bitcast double %14 to i64, !dbg !1044
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !879, metadata !DIExpression()), !dbg !1042
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !300, metadata !DIExpression()), !dbg !1045
  %16 = lshr i64 %15, 32, !dbg !1046
  %17 = trunc i64 %16 to i32, !dbg !1046
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !294, metadata !DIExpression()), !dbg !1025
  br label %18, !dbg !1047

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !1025
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !1025
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !283, metadata !DIExpression()), !dbg !1025
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !293, metadata !DIExpression()), !dbg !1025
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !294, metadata !DIExpression()), !dbg !1025
  %22 = icmp sgt i32 %19, 2146435071, !dbg !1048
  br i1 %22, label %23, label %25, !dbg !1050

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !1051
  br label %114, !dbg !1052

25:                                               ; preds = %18
  %26 = ashr i32 %19, 20, !dbg !1053
  %27 = add nsw i32 %26, -1023, !dbg !1054
  %28 = add nsw i32 %27, %20, !dbg !1055
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !293, metadata !DIExpression()), !dbg !1025
  %29 = and i32 %19, 1048575, !dbg !1056
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !294, metadata !DIExpression(DW_OP_constu, 1048575, DW_OP_and, DW_OP_stack_value)), !dbg !1025
  %30 = add nuw nsw i32 %29, 614244, !dbg !1057
  %31 = and i32 %30, 1048576, !dbg !1058
  tail call void @llvm.dbg.value(metadata i32 %30, metadata !295, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !1025
  tail call void @llvm.dbg.value(metadata double %21, metadata !874, metadata !DIExpression()), !dbg !1059
  %32 = bitcast double %21 to i64, !dbg !1061
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !879, metadata !DIExpression()), !dbg !1059
  tail call void @llvm.dbg.value(metadata i64 %32, metadata !304, metadata !DIExpression()), !dbg !1062
  %33 = and i64 %32, 4294967295, !dbg !1063
  tail call void @llvm.dbg.value(metadata i64 %33, metadata !304, metadata !DIExpression()), !dbg !1062
  %34 = or disjoint i32 %31, %29, !dbg !1063
  %35 = xor i32 %34, 1072693248, !dbg !1063
  %36 = zext nneg i32 %35 to i64
  %37 = shl nuw nsw i64 %36, 32, !dbg !1063
  %38 = or disjoint i64 %37, %33, !dbg !1063
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !304, metadata !DIExpression()), !dbg !1062
  tail call void @llvm.dbg.value(metadata i64 %38, metadata !948, metadata !DIExpression()), !dbg !1064
  %39 = bitcast i64 %38 to double, !dbg !1066
  tail call void @llvm.dbg.value(metadata double %39, metadata !953, metadata !DIExpression()), !dbg !1064
  tail call void @llvm.dbg.value(metadata double %39, metadata !283, metadata !DIExpression()), !dbg !1025
  %40 = lshr i32 %30, 20
  %41 = add nsw i32 %28, %40, !dbg !1067
  tail call void @llvm.dbg.value(metadata i32 %41, metadata !293, metadata !DIExpression()), !dbg !1025
  %42 = fadd double %39, -1.000000e+00, !dbg !1068
  tail call void @llvm.dbg.value(metadata double %42, metadata !285, metadata !DIExpression()), !dbg !1025
  %43 = add nsw i32 %19, 2, !dbg !1069
  %44 = and i32 %43, 1048575, !dbg !1071
  %45 = icmp ult i32 %44, 3, !dbg !1072
  br i1 %45, label %46, label %68, !dbg !1073

46:                                               ; preds = %25
  %47 = fcmp oeq double %42, 0.000000e+00, !dbg !1074
  br i1 %47, label %48, label %54, !dbg !1077

48:                                               ; preds = %46
  %49 = icmp eq i32 %41, 0, !dbg !1078
  br i1 %49, label %114, label %50, !dbg !1081

50:                                               ; preds = %48
  %51 = sitofp i32 %41 to double, !dbg !1082
  tail call void @llvm.dbg.value(metadata double %51, metadata !292, metadata !DIExpression()), !dbg !1025
  %52 = fmul double %51, 0x3DEA39EF35793C76, !dbg !1084
  %53 = tail call double @llvm.fmuladd.f64(double %51, double 0x3FE62E42FEE00000, double %52), !dbg !1085
  br label %114, !dbg !1086

54:                                               ; preds = %46
  %55 = fmul double %42, %42, !dbg !1087
  %56 = tail call double @llvm.fmuladd.f64(double %42, double 0xBFD5555555555555, double 5.000000e-01), !dbg !1088
  %57 = fmul double %55, %56, !dbg !1089
  tail call void @llvm.dbg.value(metadata double %57, metadata !288, metadata !DIExpression()), !dbg !1025
  %58 = icmp eq i32 %41, 0, !dbg !1090
  br i1 %58, label %59, label %61, !dbg !1092

59:                                               ; preds = %54
  %60 = fsub double %42, %57, !dbg !1093
  br label %114, !dbg !1095

61:                                               ; preds = %54
  %62 = sitofp i32 %41 to double, !dbg !1096
  tail call void @llvm.dbg.value(metadata double %62, metadata !292, metadata !DIExpression()), !dbg !1025
  %63 = fneg double %62, !dbg !1098
  %64 = tail call double @llvm.fmuladd.f64(double %63, double 0x3DEA39EF35793C76, double %57), !dbg !1098
  %65 = fsub double %64, %42, !dbg !1099
  %66 = fneg double %65, !dbg !1100
  %67 = tail call double @llvm.fmuladd.f64(double %62, double 0x3FE62E42FEE00000, double %66), !dbg !1100
  br label %114, !dbg !1101

68:                                               ; preds = %25
  %69 = fadd double %42, 2.000000e+00, !dbg !1102
  %70 = fdiv double %42, %69, !dbg !1103
  tail call void @llvm.dbg.value(metadata double %70, metadata !286, metadata !DIExpression()), !dbg !1025
  %71 = sitofp i32 %41 to double, !dbg !1104
  tail call void @llvm.dbg.value(metadata double %71, metadata !292, metadata !DIExpression()), !dbg !1025
  %72 = fmul double %70, %70, !dbg !1105
  tail call void @llvm.dbg.value(metadata double %72, metadata !287, metadata !DIExpression()), !dbg !1025
  %73 = add nsw i32 %29, -398458, !dbg !1106
  tail call void @llvm.dbg.value(metadata i32 %73, metadata !295, metadata !DIExpression()), !dbg !1025
  %74 = fmul double %72, %72, !dbg !1107
  tail call void @llvm.dbg.value(metadata double %74, metadata !289, metadata !DIExpression()), !dbg !1025
  %75 = sub nsw i32 440401, %29, !dbg !1108
  tail call void @llvm.dbg.value(metadata i32 %75, metadata !296, metadata !DIExpression()), !dbg !1025
  %76 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !1109
  %77 = tail call double @llvm.fmuladd.f64(double %74, double %76, double 0x3FD999999997FA04), !dbg !1110
  %78 = fmul double %74, %77, !dbg !1111
  tail call void @llvm.dbg.value(metadata double %78, metadata !290, metadata !DIExpression()), !dbg !1025
  %79 = tail call double @llvm.fmuladd.f64(double %74, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !1112
  %80 = tail call double @llvm.fmuladd.f64(double %74, double %79, double 0x3FD2492494229359), !dbg !1113
  %81 = tail call double @llvm.fmuladd.f64(double %74, double %80, double 0x3FE5555555555593), !dbg !1114
  %82 = fmul double %72, %81, !dbg !1115
  tail call void @llvm.dbg.value(metadata double %82, metadata !291, metadata !DIExpression()), !dbg !1025
  %83 = or i32 %73, %75, !dbg !1116
  tail call void @llvm.dbg.value(metadata i32 %83, metadata !295, metadata !DIExpression()), !dbg !1025
  %84 = fadd double %78, %82, !dbg !1117
  tail call void @llvm.dbg.value(metadata double %84, metadata !288, metadata !DIExpression()), !dbg !1025
  %85 = icmp sgt i32 %83, 0, !dbg !1118
  br i1 %85, label %86, label %102, !dbg !1120

86:                                               ; preds = %68
  %87 = fmul double %42, 5.000000e-01, !dbg !1121
  %88 = fmul double %42, %87, !dbg !1123
  tail call void @llvm.dbg.value(metadata double %88, metadata !284, metadata !DIExpression()), !dbg !1025
  %89 = icmp eq i32 %41, 0, !dbg !1124
  %90 = fadd double %88, %84, !dbg !1126
  br i1 %89, label %91, label %95, !dbg !1127

91:                                               ; preds = %86
  %92 = fneg double %70, !dbg !1128
  %93 = tail call double @llvm.fmuladd.f64(double %92, double %90, double %88), !dbg !1128
  %94 = fsub double %42, %93, !dbg !1129
  br label %114, !dbg !1130

95:                                               ; preds = %86
  %96 = fmul double %71, 0x3DEA39EF35793C76, !dbg !1131
  %97 = tail call double @llvm.fmuladd.f64(double %70, double %90, double %96), !dbg !1132
  %98 = fsub double %88, %97, !dbg !1133
  %99 = fsub double %98, %42, !dbg !1134
  %100 = fneg double %99, !dbg !1135
  %101 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %100), !dbg !1135
  br label %114, !dbg !1136

102:                                              ; preds = %68
  %103 = icmp eq i32 %41, 0, !dbg !1137
  %104 = fsub double %42, %84, !dbg !1140
  br i1 %103, label %105, label %108, !dbg !1141

105:                                              ; preds = %102
  %106 = fneg double %70, !dbg !1142
  %107 = tail call double @llvm.fmuladd.f64(double %106, double %104, double %42), !dbg !1142
  br label %114, !dbg !1143

108:                                              ; preds = %102
  %109 = fmul double %71, 0xBDEA39EF35793C76, !dbg !1144
  %110 = tail call double @llvm.fmuladd.f64(double %70, double %104, double %109), !dbg !1144
  %111 = fsub double %110, %42, !dbg !1145
  %112 = fneg double %111, !dbg !1146
  %113 = tail call double @llvm.fmuladd.f64(double %71, double 0x3FE62E42FEE00000, double %112), !dbg !1146
  br label %114, !dbg !1147

114:                                              ; preds = %48, %11, %6, %108, %105, %95, %91, %61, %59, %50, %23
  %115 = phi double [ %24, %23 ], [ %53, %50 ], [ %60, %59 ], [ %67, %61 ], [ %94, %91 ], [ %101, %95 ], [ %107, %105 ], [ %113, %108 ], [ 0xFFF0000000000000, %6 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %48 ], !dbg !1025
  ret double %115, !dbg !1148
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log1p(double noundef %0) local_unnamed_addr #0 !dbg !328 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !330, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1150
  %2 = bitcast double %0 to i64, !dbg !1152
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1150
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !342, metadata !DIExpression()), !dbg !1153
  %3 = lshr i64 %2, 32, !dbg !1154
  %4 = trunc i64 %3 to i32, !dbg !1154
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !339, metadata !DIExpression()), !dbg !1149
  %5 = and i32 %4, 2147483647, !dbg !1155
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !341, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 1, metadata !338, metadata !DIExpression()), !dbg !1149
  %6 = icmp slt i32 %4, 1071284858, !dbg !1156
  br i1 %6, label %7, label %23, !dbg !1158

7:                                                ; preds = %1
  %8 = icmp ugt i32 %5, 1072693247, !dbg !1159
  br i1 %8, label %9, label %12, !dbg !1162

9:                                                ; preds = %7
  %10 = fcmp oeq double %0, -1.000000e+00, !dbg !1163
  %11 = select i1 %10, double 0xFFF0000000000000, double 0x7FF8000000000000, !dbg !1166
  br label %130, !dbg !1166

12:                                               ; preds = %7
  %13 = icmp ult i32 %5, 1042284544, !dbg !1167
  br i1 %13, label %14, label %27, !dbg !1169

14:                                               ; preds = %12
  %15 = fadd double %0, 0x4350000000000000, !dbg !1170
  %16 = fcmp ogt double %15, 0.000000e+00, !dbg !1173
  %17 = icmp ult i32 %5, 1016070144
  %18 = and i1 %16, %17, !dbg !1174
  br i1 %18, label %130, label %19, !dbg !1174

19:                                               ; preds = %14
  %20 = fneg double %0, !dbg !1175
  %21 = fmul double %20, %0, !dbg !1175
  %22 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %0), !dbg !1175
  br label %130, !dbg !1176

23:                                               ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 1, metadata !340, metadata !DIExpression()), !dbg !1149
  %24 = icmp ugt i32 %4, 2146435071, !dbg !1177
  br i1 %24, label %25, label %33, !dbg !1179

25:                                               ; preds = %23
  %26 = fadd double %0, %0, !dbg !1180
  br label %130, !dbg !1181

27:                                               ; preds = %12
  %28 = add i32 %4, -1, !dbg !1182
  %29 = icmp ult i32 %28, -1076707644, !dbg !1182
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 1, metadata !340, metadata !DIExpression()), !dbg !1149
  br i1 %29, label %30, label %35, !dbg !1184

30:                                               ; preds = %27
  tail call void @llvm.dbg.value(metadata double %0, metadata !332, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double undef, metadata !333, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 0, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !340, metadata !DIExpression()), !dbg !1149
  %31 = fmul double %0, 5.000000e-01, !dbg !1185
  %32 = fmul double %31, %0, !dbg !1186
  tail call void @llvm.dbg.value(metadata double %32, metadata !331, metadata !DIExpression()), !dbg !1149
  br label %100, !dbg !1187

33:                                               ; preds = %23
  %34 = icmp ult i32 %4, 1128267776, !dbg !1188
  br i1 %34, label %35, label %48, !dbg !1189

35:                                               ; preds = %27, %33
  %36 = fadd double %0, 1.000000e+00, !dbg !1190
  tail call void @llvm.dbg.value(metadata double %36, metadata !337, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %36, metadata !874, metadata !DIExpression()), !dbg !1191
  %37 = bitcast double %36 to i64, !dbg !1193
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !879, metadata !DIExpression()), !dbg !1191
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !344, metadata !DIExpression()), !dbg !1194
  %38 = lshr i64 %37, 32, !dbg !1195
  %39 = trunc i64 %38 to i32, !dbg !1195
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !340, metadata !DIExpression()), !dbg !1149
  %40 = ashr i32 %39, 20, !dbg !1196
  tail call void @llvm.dbg.value(metadata i32 %40, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1149
  %41 = icmp sgt i32 %40, 1023, !dbg !1197
  %42 = fsub double %0, %36, !dbg !1198
  %43 = fadd double %42, 1.000000e+00, !dbg !1198
  %44 = fadd double %36, -1.000000e+00, !dbg !1198
  %45 = fsub double %0, %44, !dbg !1198
  %46 = select i1 %41, double %43, double %45, !dbg !1198
  tail call void @llvm.dbg.value(metadata double %46, metadata !333, metadata !DIExpression()), !dbg !1149
  %47 = fdiv double %46, %36, !dbg !1199
  tail call void @llvm.dbg.value(metadata double %47, metadata !333, metadata !DIExpression()), !dbg !1149
  br label %50, !dbg !1200

48:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata double %0, metadata !337, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1201
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1201
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !340, metadata !DIExpression()), !dbg !1149
  %49 = lshr i32 %4, 20, !dbg !1203
  tail call void @llvm.dbg.value(metadata i32 %49, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1149
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !333, metadata !DIExpression()), !dbg !1149
  br label %50

50:                                               ; preds = %48, %35
  %51 = phi i32 [ %39, %35 ], [ %4, %48 ], !dbg !1204
  %52 = phi i32 [ %40, %35 ], [ %49, %48 ]
  %53 = phi double [ %36, %35 ], [ %0, %48 ], !dbg !1204
  %54 = phi double [ %47, %35 ], [ 0.000000e+00, %48 ], !dbg !1204
  tail call void @llvm.dbg.value(metadata double %54, metadata !333, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %53, metadata !337, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !338, metadata !DIExpression(DW_OP_constu, 1023, DW_OP_minus, DW_OP_stack_value)), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !340, metadata !DIExpression()), !dbg !1149
  %55 = and i32 %51, 1048575, !dbg !1205
  tail call void @llvm.dbg.value(metadata i32 %55, metadata !340, metadata !DIExpression()), !dbg !1149
  %56 = icmp ult i32 %55, 434334, !dbg !1206
  %57 = bitcast double %53 to i64, !dbg !1207
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !879, metadata !DIExpression()), !dbg !1209
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !879, metadata !DIExpression()), !dbg !1211
  %58 = and i64 %57, 4294967295, !dbg !1208
  br i1 %56, label %59, label %62, !dbg !1213

59:                                               ; preds = %50
  %60 = add nsw i32 %52, -1023, !dbg !1204
  tail call void @llvm.dbg.value(metadata i32 %60, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %53, metadata !874, metadata !DIExpression()), !dbg !1209
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !353, metadata !DIExpression()), !dbg !1214
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !353, metadata !DIExpression()), !dbg !1214
  %61 = or disjoint i32 %55, 1072693248, !dbg !1215
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !353, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1214
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %61), metadata !337, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1149
  br label %67, !dbg !1216

62:                                               ; preds = %50
  %63 = add nsw i32 %52, -1022, !dbg !1217
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata double %53, metadata !874, metadata !DIExpression()), !dbg !1211
  tail call void @llvm.dbg.value(metadata i64 %57, metadata !357, metadata !DIExpression()), !dbg !1218
  tail call void @llvm.dbg.value(metadata i64 %58, metadata !357, metadata !DIExpression()), !dbg !1218
  %64 = or disjoint i32 %55, 1071644672, !dbg !1219
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !357, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1218
  tail call void @llvm.dbg.value(metadata !DIArgList(i64 %58, i32 %64), metadata !337, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_or, DW_OP_stack_value)), !dbg !1149
  %65 = sub nuw nsw i32 1048576, %55, !dbg !1220
  %66 = lshr i32 %65, 2
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !340, metadata !DIExpression()), !dbg !1149
  br label %67

67:                                               ; preds = %59, %62
  %68 = phi i32 [ %55, %59 ], [ %66, %62 ], !dbg !1221
  %69 = phi i32 [ %60, %59 ], [ %63, %62 ], !dbg !1221
  %70 = phi i32 [ %61, %59 ], [ %64, %62 ]
  %71 = zext i32 %70 to i64
  %72 = shl nuw nsw i64 %71, 32, !dbg !1208
  %73 = or disjoint i64 %58, %72, !dbg !1208
  %74 = bitcast i64 %73 to double, !dbg !1208
  tail call void @llvm.dbg.value(metadata double %74, metadata !337, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 %69, metadata !338, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !340, metadata !DIExpression()), !dbg !1149
  %75 = fadd double %74, -1.000000e+00, !dbg !1222
  tail call void @llvm.dbg.value(metadata double %75, metadata !332, metadata !DIExpression()), !dbg !1149
  %76 = icmp eq i32 %68, 0, !dbg !1223
  tail call void @llvm.dbg.value(metadata double %54, metadata !333, metadata !DIExpression()), !dbg !1149
  tail call void @llvm.dbg.value(metadata i32 poison, metadata !340, metadata !DIExpression()), !dbg !1149
  %77 = fmul double %75, 5.000000e-01, !dbg !1185
  %78 = fmul double %75, %77, !dbg !1186
  tail call void @llvm.dbg.value(metadata double %78, metadata !331, metadata !DIExpression()), !dbg !1149
  br i1 %76, label %79, label %100, !dbg !1187

79:                                               ; preds = %67
  %80 = fcmp oeq double %75, 0.000000e+00, !dbg !1225
  br i1 %80, label %81, label %87, !dbg !1228

81:                                               ; preds = %79
  %82 = icmp eq i32 %69, 0, !dbg !1229
  br i1 %82, label %130, label %83, !dbg !1232

83:                                               ; preds = %81
  %84 = sitofp i32 %69 to double, !dbg !1233
  %85 = tail call double @llvm.fmuladd.f64(double %84, double 0x3DEA39EF35793C76, double %54), !dbg !1235
  tail call void @llvm.dbg.value(metadata double %85, metadata !333, metadata !DIExpression()), !dbg !1149
  %86 = tail call double @llvm.fmuladd.f64(double %84, double 0x3FE62E42FEE00000, double %85), !dbg !1236
  br label %130, !dbg !1237

87:                                               ; preds = %79
  %88 = tail call double @llvm.fmuladd.f64(double %75, double 0xBFE5555555555555, double 1.000000e+00), !dbg !1238
  %89 = fmul double %88, %78, !dbg !1239
  tail call void @llvm.dbg.value(metadata double %89, metadata !336, metadata !DIExpression()), !dbg !1149
  %90 = icmp eq i32 %69, 0, !dbg !1240
  br i1 %90, label %91, label %93, !dbg !1242

91:                                               ; preds = %87
  %92 = fsub double %75, %89, !dbg !1243
  br label %130, !dbg !1244

93:                                               ; preds = %87
  %94 = sitofp i32 %69 to double, !dbg !1245
  %95 = tail call double @llvm.fmuladd.f64(double %94, double 0x3DEA39EF35793C76, double %54), !dbg !1246
  %96 = fsub double %89, %95, !dbg !1247
  %97 = fsub double %96, %75, !dbg !1248
  %98 = fneg double %97, !dbg !1249
  %99 = tail call double @llvm.fmuladd.f64(double %94, double 0x3FE62E42FEE00000, double %98), !dbg !1249
  br label %130, !dbg !1250

100:                                              ; preds = %30, %67
  %101 = phi double [ %32, %30 ], [ %78, %67 ]
  %102 = phi double [ %0, %30 ], [ %75, %67 ]
  %103 = phi double [ undef, %30 ], [ %54, %67 ]
  %104 = phi i32 [ 0, %30 ], [ %69, %67 ]
  %105 = fadd double %102, 2.000000e+00, !dbg !1251
  %106 = fdiv double %102, %105, !dbg !1252
  tail call void @llvm.dbg.value(metadata double %106, metadata !334, metadata !DIExpression()), !dbg !1149
  %107 = fmul double %106, %106, !dbg !1253
  tail call void @llvm.dbg.value(metadata double %107, metadata !335, metadata !DIExpression()), !dbg !1149
  %108 = tail call double @llvm.fmuladd.f64(double %107, double 0x3FC2F112DF3E5244, double 0x3FC39A09D078C69F), !dbg !1254
  %109 = tail call double @llvm.fmuladd.f64(double %107, double %108, double 0x3FC7466496CB03DE), !dbg !1255
  %110 = tail call double @llvm.fmuladd.f64(double %107, double %109, double 0x3FCC71C51D8E78AF), !dbg !1256
  %111 = tail call double @llvm.fmuladd.f64(double %107, double %110, double 0x3FD2492494229359), !dbg !1257
  %112 = tail call double @llvm.fmuladd.f64(double %107, double %111, double 0x3FD999999997FA04), !dbg !1258
  %113 = tail call double @llvm.fmuladd.f64(double %107, double %112, double 0x3FE5555555555593), !dbg !1259
  %114 = fmul double %107, %113, !dbg !1260
  tail call void @llvm.dbg.value(metadata double %114, metadata !336, metadata !DIExpression()), !dbg !1149
  %115 = icmp eq i32 %104, 0, !dbg !1261
  br i1 %115, label %116, label %121, !dbg !1263

116:                                              ; preds = %100
  %117 = fadd double %101, %114, !dbg !1264
  %118 = fneg double %106, !dbg !1265
  %119 = tail call double @llvm.fmuladd.f64(double %118, double %117, double %101), !dbg !1265
  %120 = fsub double %102, %119, !dbg !1266
  br label %130, !dbg !1267

121:                                              ; preds = %100
  %122 = sitofp i32 %104 to double, !dbg !1268
  %123 = fadd double %101, %114, !dbg !1269
  %124 = tail call double @llvm.fmuladd.f64(double %122, double 0x3DEA39EF35793C76, double %103), !dbg !1270
  %125 = tail call double @llvm.fmuladd.f64(double %106, double %123, double %124), !dbg !1271
  %126 = fsub double %101, %125, !dbg !1272
  %127 = fsub double %126, %102, !dbg !1273
  %128 = fneg double %127, !dbg !1274
  %129 = tail call double @llvm.fmuladd.f64(double %122, double 0x3FE62E42FEE00000, double %128), !dbg !1274
  br label %130, !dbg !1275

130:                                              ; preds = %81, %14, %9, %121, %116, %93, %91, %83, %25, %19
  %131 = phi double [ %22, %19 ], [ %26, %25 ], [ %86, %83 ], [ %92, %91 ], [ %99, %93 ], [ %120, %116 ], [ %129, %121 ], [ %11, %9 ], [ %0, %14 ], [ 0.000000e+00, %81 ], !dbg !1149
  ret double %131, !dbg !1276
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_asin(double noundef %0) local_unnamed_addr #0 !dbg !88 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !90, metadata !DIExpression()), !dbg !1277
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !91, metadata !DIExpression()), !dbg !1277
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1278
  %2 = bitcast double %0 to i64, !dbg !1280
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1278
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !100, metadata !DIExpression()), !dbg !1281
  %3 = lshr i64 %2, 32, !dbg !1282
  %4 = trunc i64 %3 to i32, !dbg !1282
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !98, metadata !DIExpression()), !dbg !1277
  %5 = and i32 %4, 2147483647, !dbg !1283
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !99, metadata !DIExpression()), !dbg !1277
  %6 = icmp ugt i32 %5, 1072693247, !dbg !1284
  br i1 %6, label %7, label %15, !dbg !1285

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1286
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1286
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !105, metadata !DIExpression()), !dbg !1288
  %8 = trunc i64 %2 to i32, !dbg !1289
  tail call void @llvm.dbg.value(metadata i32 %8, metadata !102, metadata !DIExpression()), !dbg !1290
  %9 = add nsw i32 %5, -1072693248, !dbg !1291
  %10 = or i32 %9, %8, !dbg !1293
  %11 = icmp eq i32 %10, 0, !dbg !1294
  %12 = fmul double %0, 0x3C91A62633145C07, !dbg !1295
  %13 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF921FB54442D18, double %12), !dbg !1295
  %14 = select i1 %11, double %13, double 0x7FF8000000000000, !dbg !1295
  br label %80

15:                                               ; preds = %1
  %16 = icmp ult i32 %5, 1071644672, !dbg !1296
  br i1 %16, label %17, label %38, !dbg !1298

17:                                               ; preds = %15
  %18 = icmp ult i32 %5, 1044381696, !dbg !1299
  br i1 %18, label %19, label %22, !dbg !1302

19:                                               ; preds = %17
  %20 = fadd double %0, 1.000000e+300, !dbg !1303
  %21 = fcmp ogt double %20, 1.000000e+00, !dbg !1306
  br i1 %21, label %80, label %24, !dbg !1307

22:                                               ; preds = %17
  %23 = fmul double %0, %0, !dbg !1308
  tail call void @llvm.dbg.value(metadata double %23, metadata !91, metadata !DIExpression()), !dbg !1277
  br label %24

24:                                               ; preds = %19, %22
  %25 = phi double [ 0.000000e+00, %19 ], [ %23, %22 ], !dbg !1277
  tail call void @llvm.dbg.value(metadata double %25, metadata !91, metadata !DIExpression()), !dbg !1277
  %26 = tail call double @llvm.fmuladd.f64(double %25, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1310
  %27 = tail call double @llvm.fmuladd.f64(double %25, double %26, double 0xBFA48228B5688F3B), !dbg !1311
  %28 = tail call double @llvm.fmuladd.f64(double %25, double %27, double 0x3FC9C1550E884455), !dbg !1312
  %29 = tail call double @llvm.fmuladd.f64(double %25, double %28, double 0xBFD4D61203EB6F7D), !dbg !1313
  %30 = tail call double @llvm.fmuladd.f64(double %25, double %29, double 0x3FC5555555555555), !dbg !1314
  %31 = fmul double %25, %30, !dbg !1315
  tail call void @llvm.dbg.value(metadata double %31, metadata !93, metadata !DIExpression()), !dbg !1277
  %32 = tail call double @llvm.fmuladd.f64(double %25, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1316
  %33 = tail call double @llvm.fmuladd.f64(double %25, double %32, double 0x40002AE59C598AC8), !dbg !1317
  %34 = tail call double @llvm.fmuladd.f64(double %25, double %33, double 0xC0033A271C8A2D4B), !dbg !1318
  %35 = tail call double @llvm.fmuladd.f64(double %25, double %34, double 1.000000e+00), !dbg !1319
  tail call void @llvm.dbg.value(metadata double %35, metadata !94, metadata !DIExpression()), !dbg !1277
  %36 = fdiv double %31, %35, !dbg !1320
  tail call void @llvm.dbg.value(metadata double %36, metadata !92, metadata !DIExpression()), !dbg !1277
  %37 = tail call double @llvm.fmuladd.f64(double %0, double %36, double %0), !dbg !1321
  br label %80, !dbg !1322

38:                                               ; preds = %15
  %39 = tail call double @llvm.fabs.f64(double %0), !dbg !1323
  %40 = fsub double 1.000000e+00, %39, !dbg !1324
  tail call void @llvm.dbg.value(metadata double %40, metadata !92, metadata !DIExpression()), !dbg !1277
  %41 = fmul double %40, 5.000000e-01, !dbg !1325
  tail call void @llvm.dbg.value(metadata double %41, metadata !91, metadata !DIExpression()), !dbg !1277
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3F023DE10DFDF709, double 0x3F49EFE07501B288), !dbg !1326
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0xBFA48228B5688F3B), !dbg !1327
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0x3FC9C1550E884455), !dbg !1328
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0xBFD4D61203EB6F7D), !dbg !1329
  %46 = tail call double @llvm.fmuladd.f64(double %41, double %45, double 0x3FC5555555555555), !dbg !1330
  %47 = fmul double %41, %46, !dbg !1331
  tail call void @llvm.dbg.value(metadata double %47, metadata !93, metadata !DIExpression()), !dbg !1277
  %48 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FB3B8C5B12E9282, double 0xBFE6066C1B8D0159), !dbg !1332
  %49 = tail call double @llvm.fmuladd.f64(double %41, double %48, double 0x40002AE59C598AC8), !dbg !1333
  %50 = tail call double @llvm.fmuladd.f64(double %41, double %49, double 0xC0033A271C8A2D4B), !dbg !1334
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %50, double 1.000000e+00), !dbg !1335
  tail call void @llvm.dbg.value(metadata double %51, metadata !94, metadata !DIExpression()), !dbg !1277
  %52 = tail call double @llvm.sqrt.f64(double %41), !dbg !1336
  tail call void @llvm.dbg.value(metadata double %52, metadata !97, metadata !DIExpression()), !dbg !1277
  %53 = icmp ugt i32 %5, 1072640818, !dbg !1337
  br i1 %53, label %54, label %59, !dbg !1338

54:                                               ; preds = %38
  %55 = fdiv double %47, %51, !dbg !1339
  tail call void @llvm.dbg.value(metadata double %55, metadata !92, metadata !DIExpression()), !dbg !1277
  %56 = tail call double @llvm.fmuladd.f64(double %52, double %55, double %52), !dbg !1341
  %57 = tail call double @llvm.fmuladd.f64(double %56, double 2.000000e+00, double 0xBC91A62633145C07), !dbg !1342
  %58 = fsub double 0x3FF921FB54442D18, %57, !dbg !1343
  tail call void @llvm.dbg.value(metadata double %58, metadata !91, metadata !DIExpression()), !dbg !1277
  br label %75, !dbg !1344

59:                                               ; preds = %38
  tail call void @llvm.dbg.value(metadata double %52, metadata !92, metadata !DIExpression()), !dbg !1277
  tail call void @llvm.dbg.value(metadata double %52, metadata !874, metadata !DIExpression()), !dbg !1345
  %60 = bitcast double %52 to i64, !dbg !1347
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !879, metadata !DIExpression()), !dbg !1345
  tail call void @llvm.dbg.value(metadata i64 %60, metadata !107, metadata !DIExpression()), !dbg !1348
  %61 = and i64 %60, -4294967296, !dbg !1349
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !107, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !107, metadata !DIExpression()), !dbg !1348
  tail call void @llvm.dbg.value(metadata i64 %61, metadata !948, metadata !DIExpression()), !dbg !1350
  %62 = bitcast i64 %61 to double, !dbg !1352
  tail call void @llvm.dbg.value(metadata double %62, metadata !953, metadata !DIExpression()), !dbg !1350
  tail call void @llvm.dbg.value(metadata double %62, metadata !92, metadata !DIExpression()), !dbg !1277
  %63 = fneg double %62, !dbg !1353
  %64 = tail call double @llvm.fmuladd.f64(double %63, double %62, double %41), !dbg !1353
  %65 = fadd double %52, %62, !dbg !1354
  %66 = fdiv double %64, %65, !dbg !1355
  tail call void @llvm.dbg.value(metadata double %66, metadata !95, metadata !DIExpression()), !dbg !1277
  %67 = fdiv double %47, %51, !dbg !1356
  tail call void @llvm.dbg.value(metadata double %67, metadata !96, metadata !DIExpression()), !dbg !1277
  %68 = fmul double %52, 2.000000e+00, !dbg !1357
  %69 = tail call double @llvm.fmuladd.f64(double %66, double -2.000000e+00, double 0x3C91A62633145C07), !dbg !1358
  %70 = fneg double %69, !dbg !1359
  %71 = tail call double @llvm.fmuladd.f64(double %68, double %67, double %70), !dbg !1359
  tail call void @llvm.dbg.value(metadata double %71, metadata !93, metadata !DIExpression()), !dbg !1277
  %72 = tail call double @llvm.fmuladd.f64(double %62, double -2.000000e+00, double 0x3FE921FB54442D18), !dbg !1360
  tail call void @llvm.dbg.value(metadata double %72, metadata !94, metadata !DIExpression()), !dbg !1277
  %73 = fsub double %72, %71, !dbg !1361
  %74 = fadd double %73, 0x3FE921FB54442D18, !dbg !1361
  tail call void @llvm.dbg.value(metadata double %74, metadata !91, metadata !DIExpression()), !dbg !1277
  br label %75

75:                                               ; preds = %59, %54
  %76 = phi double [ %58, %54 ], [ %74, %59 ], !dbg !1362
  tail call void @llvm.dbg.value(metadata double %76, metadata !91, metadata !DIExpression()), !dbg !1277
  %77 = icmp sgt i32 %4, 0, !dbg !1363
  %78 = fneg double %76
  %79 = select i1 %77, double %76, double %78, !dbg !1365
  br label %80, !dbg !1365

80:                                               ; preds = %75, %19, %24, %7
  %81 = phi double [ %14, %7 ], [ %37, %24 ], [ %0, %19 ], [ %79, %75 ], !dbg !1277
  ret double %81, !dbg !1366
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #2

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_asinh(double noundef %0) local_unnamed_addr #0 !dbg !141 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !143, metadata !DIExpression()), !dbg !1367
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1368
  %2 = bitcast double %0 to i64, !dbg !1370
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1368
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !148, metadata !DIExpression()), !dbg !1371
  %3 = lshr i64 %2, 32, !dbg !1372
  %4 = trunc i64 %3 to i32, !dbg !1372
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !146, metadata !DIExpression()), !dbg !1367
  %5 = and i32 %4, 2147483647, !dbg !1373
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !147, metadata !DIExpression()), !dbg !1367
  %6 = icmp ugt i32 %5, 2146435071, !dbg !1374
  br i1 %6, label %7, label %9, !dbg !1376

7:                                                ; preds = %1
  %8 = fadd double %0, %0, !dbg !1377
  br label %44, !dbg !1378

9:                                                ; preds = %1
  %10 = icmp ult i32 %5, 1043333120, !dbg !1379
  %11 = fadd double %0, 1.000000e+300
  %12 = fcmp ogt double %11, 1.000000e+00
  %13 = and i1 %12, %10, !dbg !1381
  br i1 %13, label %44, label %14, !dbg !1381

14:                                               ; preds = %9
  %15 = icmp ugt i32 %5, 1102053376, !dbg !1382
  br i1 %15, label %16, label %20, !dbg !1384

16:                                               ; preds = %14
  %17 = tail call double @llvm.fabs.f64(double %0), !dbg !1385
  %18 = tail call double @pts_ieee754_log(double noundef %17), !dbg !1387
  %19 = fadd double %18, 0x3FE62E42FEFA39EF, !dbg !1388
  tail call void @llvm.dbg.value(metadata double %19, metadata !145, metadata !DIExpression()), !dbg !1367
  br label %39, !dbg !1389

20:                                               ; preds = %14
  %21 = icmp ugt i32 %5, 1073741824, !dbg !1390
  br i1 %21, label %22, label %30, !dbg !1392

22:                                               ; preds = %20
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !1393
  tail call void @llvm.dbg.value(metadata double %23, metadata !144, metadata !DIExpression()), !dbg !1367
  %24 = tail call double @llvm.fmuladd.f64(double %0, double %0, double 1.000000e+00), !dbg !1395
  %25 = tail call double @llvm.sqrt.f64(double %24), !dbg !1396
  %26 = fadd double %23, %25, !dbg !1397
  %27 = fdiv double 1.000000e+00, %26, !dbg !1398
  %28 = tail call double @llvm.fmuladd.f64(double %23, double 2.000000e+00, double %27), !dbg !1399
  %29 = tail call double @pts_ieee754_log(double noundef %28), !dbg !1400
  tail call void @llvm.dbg.value(metadata double %29, metadata !145, metadata !DIExpression()), !dbg !1367
  br label %39, !dbg !1401

30:                                               ; preds = %20
  %31 = fmul double %0, %0, !dbg !1402
  tail call void @llvm.dbg.value(metadata double %31, metadata !144, metadata !DIExpression()), !dbg !1367
  %32 = tail call double @llvm.fabs.f64(double %0), !dbg !1404
  %33 = fadd double %31, 1.000000e+00, !dbg !1405
  %34 = tail call double @llvm.sqrt.f64(double %33), !dbg !1406
  %35 = fadd double %34, 1.000000e+00, !dbg !1407
  %36 = fdiv double %31, %35, !dbg !1408
  %37 = fadd double %32, %36, !dbg !1409
  %38 = tail call double @pts_ieee754_log1p(double noundef %37), !dbg !1410
  tail call void @llvm.dbg.value(metadata double %38, metadata !145, metadata !DIExpression()), !dbg !1367
  br label %39

39:                                               ; preds = %22, %30, %16
  %40 = phi double [ %19, %16 ], [ %29, %22 ], [ %38, %30 ], !dbg !1411
  tail call void @llvm.dbg.value(metadata double %40, metadata !145, metadata !DIExpression()), !dbg !1367
  %41 = icmp sgt i32 %4, 0, !dbg !1412
  %42 = fneg double %40
  %43 = select i1 %41, double %40, double %42, !dbg !1414
  br label %44, !dbg !1414

44:                                               ; preds = %39, %9, %7
  %45 = phi double [ %8, %7 ], [ %0, %9 ], [ %43, %39 ], !dbg !1367
  ret double %45, !dbg !1415
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(inaccessiblemem: readwrite) uwtable
define dso_local double @pts_ieee754_atan(double noundef %0) local_unnamed_addr #3 !dbg !2 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !849, metadata !DIExpression()), !dbg !1416
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1417
  %2 = bitcast double %0 to i64, !dbg !1419
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1417
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !857, metadata !DIExpression()), !dbg !1420
  %3 = lshr i64 %2, 32, !dbg !1421
  %4 = trunc i64 %3 to i32, !dbg !1421
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !855, metadata !DIExpression()), !dbg !1416
  %5 = and i32 %4, 2147483647, !dbg !1422
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !854, metadata !DIExpression()), !dbg !1416
  %6 = icmp ugt i32 %5, 1141899263, !dbg !1423
  br i1 %6, label %7, label %23, !dbg !1424

7:                                                ; preds = %1
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1425
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !1425
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !859, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1427
  %8 = icmp ugt i32 %5, 2146435072, !dbg !1428
  br i1 %8, label %14, label %9, !dbg !1430

9:                                                ; preds = %7
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !859, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1427
  %10 = icmp eq i32 %5, 2146435072, !dbg !1431
  %11 = and i64 %2, 4294967295
  %12 = icmp ne i64 %11, 0
  %13 = and i1 %12, %10, !dbg !1432
  br i1 %13, label %14, label %16, !dbg !1432

14:                                               ; preds = %9, %7
  %15 = fadd double %0, %0, !dbg !1433
  br label %84, !dbg !1434

16:                                               ; preds = %9
  %17 = icmp sgt i32 %4, 0, !dbg !1435
  %18 = load volatile double, ptr getelementptr inbounds ([4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 3), align 8, !dbg !1437, !tbaa !1438
  br i1 %17, label %19, label %21, !dbg !1442

19:                                               ; preds = %16
  %20 = fadd double %18, 0x3FF921FB54442D18, !dbg !1443
  br label %84, !dbg !1444

21:                                               ; preds = %16
  %22 = fsub double 0xBFF921FB54442D18, %18, !dbg !1445
  br label %84, !dbg !1446

23:                                               ; preds = %1
  %24 = icmp ult i32 %5, 1071382528, !dbg !1447
  br i1 %24, label %25, label %30, !dbg !1449

25:                                               ; preds = %23
  %26 = icmp ult i32 %5, 1044381696, !dbg !1450
  %27 = fadd double %0, 1.000000e+300
  %28 = fcmp ogt double %27, 1.000000e+00
  %29 = and i1 %28, %26, !dbg !1453
  br i1 %29, label %84, label %51, !dbg !1453

30:                                               ; preds = %23
  %31 = tail call double @llvm.fabs.f64(double %0), !dbg !1454
  tail call void @llvm.dbg.value(metadata double %31, metadata !849, metadata !DIExpression()), !dbg !1416
  %32 = icmp ult i32 %5, 1072889856, !dbg !1456
  br i1 %32, label %33, label %43, !dbg !1458

33:                                               ; preds = %30
  %34 = icmp ult i32 %5, 1072037888, !dbg !1459
  br i1 %34, label %35, label %39, !dbg !1462

35:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 0, metadata !856, metadata !DIExpression()), !dbg !1416
  %36 = tail call double @llvm.fmuladd.f64(double %31, double 2.000000e+00, double -1.000000e+00), !dbg !1463
  %37 = fadd double %31, 2.000000e+00, !dbg !1465
  %38 = fdiv double %36, %37, !dbg !1466
  tail call void @llvm.dbg.value(metadata double %38, metadata !849, metadata !DIExpression()), !dbg !1416
  br label %51, !dbg !1467

39:                                               ; preds = %33
  tail call void @llvm.dbg.value(metadata i32 1, metadata !856, metadata !DIExpression()), !dbg !1416
  %40 = fadd double %31, -1.000000e+00, !dbg !1468
  %41 = fadd double %31, 1.000000e+00, !dbg !1470
  %42 = fdiv double %40, %41, !dbg !1471
  tail call void @llvm.dbg.value(metadata double %42, metadata !849, metadata !DIExpression()), !dbg !1416
  br label %51

43:                                               ; preds = %30
  %44 = icmp ult i32 %5, 1073971200, !dbg !1472
  br i1 %44, label %45, label %49, !dbg !1475

45:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 2, metadata !856, metadata !DIExpression()), !dbg !1416
  %46 = fadd double %31, -1.500000e+00, !dbg !1476
  %47 = tail call double @llvm.fmuladd.f64(double %31, double 1.500000e+00, double 1.000000e+00), !dbg !1478
  %48 = fdiv double %46, %47, !dbg !1479
  tail call void @llvm.dbg.value(metadata double %48, metadata !849, metadata !DIExpression()), !dbg !1416
  br label %51, !dbg !1480

49:                                               ; preds = %43
  tail call void @llvm.dbg.value(metadata i32 3, metadata !856, metadata !DIExpression()), !dbg !1416
  %50 = fdiv double -1.000000e+00, %31, !dbg !1481
  tail call void @llvm.dbg.value(metadata double %50, metadata !849, metadata !DIExpression()), !dbg !1416
  br label %51

51:                                               ; preds = %25, %39, %35, %49, %45
  %52 = phi i64 [ 0, %35 ], [ 1, %39 ], [ 2, %45 ], [ 3, %49 ], [ 4294967295, %25 ], !dbg !1483
  %53 = phi double [ %38, %35 ], [ %42, %39 ], [ %48, %45 ], [ %50, %49 ], [ %0, %25 ]
  tail call void @llvm.dbg.value(metadata double %53, metadata !849, metadata !DIExpression()), !dbg !1416
  tail call void @llvm.dbg.value(metadata i64 %52, metadata !856, metadata !DIExpression()), !dbg !1416
  %54 = fmul double %53, %53, !dbg !1484
  tail call void @llvm.dbg.value(metadata double %54, metadata !853, metadata !DIExpression()), !dbg !1416
  %55 = fmul double %54, %54, !dbg !1485
  tail call void @llvm.dbg.value(metadata double %55, metadata !850, metadata !DIExpression()), !dbg !1416
  %56 = tail call double @llvm.fmuladd.f64(double %55, double 0x3F90AD3AE322DA11, double 0x3FA97B4B24760DEB), !dbg !1486
  %57 = tail call double @llvm.fmuladd.f64(double %55, double %56, double 0x3FB10D66A0D03D51), !dbg !1487
  %58 = tail call double @llvm.fmuladd.f64(double %55, double %57, double 0x3FB745CDC54C206E), !dbg !1488
  %59 = tail call double @llvm.fmuladd.f64(double %55, double %58, double 0x3FC24924920083FF), !dbg !1489
  %60 = tail call double @llvm.fmuladd.f64(double %55, double %59, double 0x3FD555555555550D), !dbg !1490
  %61 = fmul double %54, %60, !dbg !1491
  tail call void @llvm.dbg.value(metadata double %61, metadata !851, metadata !DIExpression()), !dbg !1416
  %62 = tail call double @llvm.fmuladd.f64(double %55, double 0xBFA2B4442C6A6C2F, double 0xBFADDE2D52DEFD9A), !dbg !1492
  %63 = tail call double @llvm.fmuladd.f64(double %55, double %62, double 0xBFB3B0F2AF749A6D), !dbg !1493
  %64 = tail call double @llvm.fmuladd.f64(double %55, double %63, double 0xBFBC71C6FE231671), !dbg !1494
  %65 = tail call double @llvm.fmuladd.f64(double %55, double %64, double 0xBFC999999998EBC4), !dbg !1495
  %66 = fmul double %55, %65, !dbg !1496
  tail call void @llvm.dbg.value(metadata double %66, metadata !852, metadata !DIExpression()), !dbg !1416
  br i1 %24, label %67, label %71, !dbg !1497

67:                                               ; preds = %51
  %68 = fadd double %66, %61, !dbg !1498
  %69 = fneg double %53, !dbg !1501
  %70 = tail call double @llvm.fmuladd.f64(double %69, double %68, double %53), !dbg !1501
  br label %84, !dbg !1502

71:                                               ; preds = %51
  %72 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanhi, i64 0, i64 %52, !dbg !1503
  %73 = load double, ptr %72, align 8, !dbg !1503, !tbaa !1438
  %74 = fadd double %66, %61, !dbg !1505
  %75 = getelementptr inbounds [4 x double], ptr @pts_ieee754_atan.atanlo, i64 0, i64 %52, !dbg !1506
  %76 = load double, ptr %75, align 8, !dbg !1506, !tbaa !1438
  %77 = fneg double %76, !dbg !1507
  %78 = tail call double @llvm.fmuladd.f64(double %53, double %74, double %77), !dbg !1507
  %79 = fsub double %78, %53, !dbg !1508
  %80 = fsub double %73, %79, !dbg !1509
  tail call void @llvm.dbg.value(metadata double %80, metadata !853, metadata !DIExpression()), !dbg !1416
  %81 = icmp slt i64 %2, 0, !dbg !1510
  %82 = fneg double %80, !dbg !1511
  %83 = select i1 %81, double %82, double %80, !dbg !1511
  br label %84, !dbg !1512

84:                                               ; preds = %25, %14, %19, %21, %71, %67
  %85 = phi double [ %70, %67 ], [ %83, %71 ], [ %15, %14 ], [ %20, %19 ], [ %22, %21 ], [ %0, %25 ], !dbg !1416
  ret double %85, !dbg !1513
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_atan2(double noundef %0, double noundef %1) local_unnamed_addr #4 !dbg !170 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !174, metadata !DIExpression()), !dbg !1514
  tail call void @llvm.dbg.value(metadata double %1, metadata !175, metadata !DIExpression()), !dbg !1514
  tail call void @llvm.dbg.value(metadata double %1, metadata !874, metadata !DIExpression()), !dbg !1515
  %3 = bitcast double %1 to i64, !dbg !1517
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !1515
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !185, metadata !DIExpression()), !dbg !1518
  %4 = lshr i64 %3, 32, !dbg !1519
  %5 = trunc i64 %4 to i32, !dbg !1519
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !179, metadata !DIExpression()), !dbg !1514
  %6 = trunc i64 %3 to i32, !dbg !1519
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !183, metadata !DIExpression()), !dbg !1514
  %7 = and i32 %5, 2147483647, !dbg !1520
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !181, metadata !DIExpression()), !dbg !1514
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1521
  %8 = bitcast double %0 to i64, !dbg !1523
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !879, metadata !DIExpression()), !dbg !1521
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !187, metadata !DIExpression()), !dbg !1524
  %9 = lshr i64 %8, 32, !dbg !1525
  %10 = trunc i64 %9 to i32, !dbg !1525
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !180, metadata !DIExpression()), !dbg !1514
  %11 = trunc i64 %8 to i32, !dbg !1525
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !184, metadata !DIExpression()), !dbg !1514
  %12 = and i32 %10, 2147483647, !dbg !1526
  tail call void @llvm.dbg.value(metadata i32 %12, metadata !182, metadata !DIExpression()), !dbg !1514
  %13 = icmp ne i32 %6, 0, !dbg !1527
  %14 = zext i1 %13 to i32, !dbg !1527
  %15 = or i32 %7, %14, !dbg !1529
  %16 = icmp ugt i32 %15, 2146435072, !dbg !1530
  br i1 %16, label %22, label %17, !dbg !1531

17:                                               ; preds = %2
  %18 = icmp ne i32 %11, 0, !dbg !1532
  %19 = zext i1 %18 to i32, !dbg !1532
  %20 = or i32 %12, %19, !dbg !1533
  %21 = icmp ugt i32 %20, 2146435072, !dbg !1534
  br i1 %21, label %22, label %24, !dbg !1535

22:                                               ; preds = %17, %2
  %23 = fadd double %0, %1, !dbg !1536
  br label %116, !dbg !1538

24:                                               ; preds = %17
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1539, metadata !DIExpression()), !dbg !1545
  tail call void @llvm.dbg.value(metadata i32 1072693248, metadata !1544, metadata !DIExpression()), !dbg !1545
  %25 = add i32 %5, -1072693248, !dbg !1548
  %26 = or i32 %25, %6, !dbg !1549
  %27 = icmp eq i32 %26, 0, !dbg !1550
  br i1 %27, label %28, label %30, !dbg !1551

28:                                               ; preds = %24
  %29 = tail call double @pts_ieee754_atan(double noundef %0), !dbg !1552
  br label %116, !dbg !1554

30:                                               ; preds = %24
  %31 = lshr i32 %10, 31, !dbg !1555
  %32 = lshr i32 %5, 30, !dbg !1556
  %33 = and i32 %32, 2, !dbg !1557
  %34 = or disjoint i32 %33, %31, !dbg !1558
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !178, metadata !DIExpression()), !dbg !1514
  %35 = or i32 %12, %11, !dbg !1559
  %36 = icmp eq i32 %35, 0, !dbg !1561
  br i1 %36, label %37, label %45, !dbg !1562

37:                                               ; preds = %30
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %116
    i32 2, label %38
    i32 3, label %41
  ], !dbg !1563

38:                                               ; preds = %37
  %39 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1565, !tbaa !1438
  %40 = fadd double %39, 0x400921FB54442D18, !dbg !1567
  br label %116, !dbg !1568

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1569, !tbaa !1438
  %43 = fsub double 0xC00921FB54442D18, %42, !dbg !1570
  br label %116, !dbg !1571

44:                                               ; preds = %72, %59, %37
  unreachable

45:                                               ; preds = %30
  %46 = or i32 %7, %6, !dbg !1572
  %47 = icmp eq i32 %46, 0, !dbg !1574
  br i1 %47, label %48, label %55, !dbg !1575

48:                                               ; preds = %45
  %49 = icmp slt i64 %8, 0, !dbg !1576
  %50 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1577, !tbaa !1438
  br i1 %49, label %51, label %53, !dbg !1578

51:                                               ; preds = %48
  %52 = fsub double 0xBFF921FB54442D18, %50, !dbg !1579
  br label %116, !dbg !1578

53:                                               ; preds = %48
  %54 = fadd double %50, 0x3FF921FB54442D18, !dbg !1580
  br label %116, !dbg !1578

55:                                               ; preds = %45
  %56 = icmp eq i32 %7, 2146435072, !dbg !1581
  %57 = icmp eq i32 %12, 2146435072, !dbg !1514
  br i1 %56, label %58, label %80, !dbg !1583

58:                                               ; preds = %55
  br i1 %57, label %59, label %72, !dbg !1584

59:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %60
    i32 1, label %63
    i32 2, label %66
    i32 3, label %69
  ], !dbg !1586

60:                                               ; preds = %59
  %61 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1589, !tbaa !1438
  %62 = fadd double %61, 0x3FE921FB54442D18, !dbg !1591
  br label %116, !dbg !1592

63:                                               ; preds = %59
  %64 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1593, !tbaa !1438
  %65 = fsub double 0xBFE921FB54442D18, %64, !dbg !1594
  br label %116, !dbg !1595

66:                                               ; preds = %59
  %67 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1596, !tbaa !1438
  %68 = fadd double %67, 0x4002D97C7F3321D2, !dbg !1597
  br label %116, !dbg !1598

69:                                               ; preds = %59
  %70 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1599, !tbaa !1438
  %71 = fsub double 0xC002D97C7F3321D2, %70, !dbg !1600
  br label %116, !dbg !1601

72:                                               ; preds = %58
  switch i32 %34, label %44 [
    i32 0, label %116
    i32 1, label %73
    i32 2, label %74
    i32 3, label %77
  ], !dbg !1602

73:                                               ; preds = %72
  br label %116, !dbg !1604

74:                                               ; preds = %72
  %75 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1606, !tbaa !1438
  %76 = fadd double %75, 0x400921FB54442D18, !dbg !1607
  br label %116, !dbg !1608

77:                                               ; preds = %72
  %78 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1609, !tbaa !1438
  %79 = fsub double 0xC00921FB54442D18, %78, !dbg !1610
  br label %116, !dbg !1611

80:                                               ; preds = %55
  br i1 %57, label %81, label %88, !dbg !1612

81:                                               ; preds = %80
  %82 = icmp slt i64 %8, 0, !dbg !1613
  %83 = load volatile double, ptr @pts_ieee754_atan2.tiny, align 8, !dbg !1615, !tbaa !1438
  br i1 %82, label %84, label %86, !dbg !1616

84:                                               ; preds = %81
  %85 = fsub double 0xBFF921FB54442D18, %83, !dbg !1617
  br label %116, !dbg !1616

86:                                               ; preds = %81
  %87 = fadd double %83, 0x3FF921FB54442D18, !dbg !1618
  br label %116, !dbg !1616

88:                                               ; preds = %80
  %89 = sub nsw i32 %12, %7, !dbg !1619
  %90 = ashr i32 %89, 20, !dbg !1620
  tail call void @llvm.dbg.value(metadata i32 %90, metadata !177, metadata !DIExpression()), !dbg !1514
  %91 = icmp sgt i32 %90, 60, !dbg !1621
  br i1 %91, label %92, label %95, !dbg !1623

92:                                               ; preds = %88
  %93 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1624, !tbaa !1438
  %94 = tail call double @llvm.fmuladd.f64(double %93, double 5.000000e-01, double 0x3FF921FB54442D18), !dbg !1626
  tail call void @llvm.dbg.value(metadata double %94, metadata !176, metadata !DIExpression()), !dbg !1514
  tail call void @llvm.dbg.value(metadata i32 %31, metadata !178, metadata !DIExpression()), !dbg !1514
  br label %103, !dbg !1627

95:                                               ; preds = %88
  %96 = icmp slt i64 %3, 0, !dbg !1628
  %97 = icmp slt i32 %90, -60
  %98 = and i1 %96, %97, !dbg !1630
  br i1 %98, label %103, label %99, !dbg !1630

99:                                               ; preds = %95
  %100 = fdiv double %0, %1, !dbg !1631
  %101 = tail call double @llvm.fabs.f64(double %100), !dbg !1633
  %102 = tail call double @pts_ieee754_atan(double noundef %101), !dbg !1634
  tail call void @llvm.dbg.value(metadata double %102, metadata !176, metadata !DIExpression()), !dbg !1514
  br label %103

103:                                              ; preds = %95, %99, %92
  %104 = phi i32 [ %31, %92 ], [ %34, %99 ], [ %34, %95 ], !dbg !1514
  %105 = phi double [ %94, %92 ], [ %102, %99 ], [ 0.000000e+00, %95 ], !dbg !1635
  tail call void @llvm.dbg.value(metadata double %105, metadata !176, metadata !DIExpression()), !dbg !1514
  tail call void @llvm.dbg.value(metadata i32 %104, metadata !178, metadata !DIExpression()), !dbg !1514
  switch i32 %104, label %112 [
    i32 0, label %116
    i32 1, label %106
    i32 2, label %108
  ], !dbg !1636

106:                                              ; preds = %103
  %107 = fneg double %105, !dbg !1637
  br label %116, !dbg !1639

108:                                              ; preds = %103
  %109 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1640, !tbaa !1438
  %110 = fsub double %109, %105, !dbg !1641
  %111 = fadd double %110, 0x400921FB54442D18, !dbg !1641
  br label %116, !dbg !1642

112:                                              ; preds = %103
  %113 = load volatile double, ptr @pts_ieee754_atan2.pi_lo, align 8, !dbg !1643, !tbaa !1438
  %114 = fsub double %105, %113, !dbg !1644
  %115 = fadd double %114, 0xC00921FB54442D18, !dbg !1645
  br label %116, !dbg !1646

116:                                              ; preds = %103, %84, %86, %72, %51, %53, %37, %37, %112, %108, %106, %77, %74, %73, %69, %66, %63, %60, %41, %38, %28, %22
  %117 = phi double [ %23, %22 ], [ %29, %28 ], [ %115, %112 ], [ %111, %108 ], [ %107, %106 ], [ %71, %69 ], [ %68, %66 ], [ %65, %63 ], [ %62, %60 ], [ %79, %77 ], [ %76, %74 ], [ -0.000000e+00, %73 ], [ %43, %41 ], [ %40, %38 ], [ %0, %37 ], [ %0, %37 ], [ %52, %51 ], [ %54, %53 ], [ 0.000000e+00, %72 ], [ %85, %84 ], [ %87, %86 ], [ %105, %103 ], !dbg !1514
  ret double %117, !dbg !1647
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_cos(double noundef %0) local_unnamed_addr #5 !dbg !1648 {
  %2 = alloca [2 x double], align 8, !DIAssignID !1658
  call void @llvm.dbg.assign(metadata i1 undef, metadata !1651, metadata !DIExpression(), metadata !1658, metadata ptr %2, metadata !DIExpression()), !dbg !1659
  tail call void @llvm.dbg.value(metadata double %0, metadata !1650, metadata !DIExpression()), !dbg !1659
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !1660
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !1653, metadata !DIExpression()), !dbg !1659
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1661
  %3 = bitcast double %0 to i64, !dbg !1663
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !1661
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !1656, metadata !DIExpression()), !dbg !1664
  %4 = lshr i64 %3, 32, !dbg !1665
  %5 = trunc i64 %4 to i32, !dbg !1665
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !1655, metadata !DIExpression()), !dbg !1659
  %6 = and i32 %5, 2147483647, !dbg !1666
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !1655, metadata !DIExpression()), !dbg !1659
  %7 = icmp ult i32 %6, 1072243196, !dbg !1667
  br i1 %7, label %8, label %42, !dbg !1669

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !609, metadata !DIExpression()), !dbg !1670
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !610, metadata !DIExpression()), !dbg !1670
  call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1673
  call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !1673
  call void @llvm.dbg.value(metadata i64 %3, metadata !617, metadata !DIExpression()), !dbg !1675
  call void @llvm.dbg.value(metadata i32 %5, metadata !616, metadata !DIExpression()), !dbg !1670
  call void @llvm.dbg.value(metadata i32 %6, metadata !616, metadata !DIExpression()), !dbg !1670
  %9 = icmp ult i32 %6, 1044381696, !dbg !1676
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !1678
  br i1 %12, label %186, label %13, !dbg !1678

13:                                               ; preds = %8
  %14 = fmul double %0, %0, !dbg !1679
  call void @llvm.dbg.value(metadata double %14, metadata !613, metadata !DIExpression()), !dbg !1670
  %15 = tail call double @llvm.fmuladd.f64(double %14, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1680
  %16 = tail call double @llvm.fmuladd.f64(double %14, double %15, double 0xBE927E4F809C52AD), !dbg !1681
  %17 = tail call double @llvm.fmuladd.f64(double %14, double %16, double 0x3EFA01A019CB1590), !dbg !1682
  %18 = tail call double @llvm.fmuladd.f64(double %14, double %17, double 0xBF56C16C16C15177), !dbg !1683
  %19 = tail call double @llvm.fmuladd.f64(double %14, double %18, double 0x3FA555555555554C), !dbg !1684
  %20 = fmul double %14, %19, !dbg !1685
  call void @llvm.dbg.value(metadata double %20, metadata !614, metadata !DIExpression()), !dbg !1670
  %21 = icmp ult i32 %6, 1070805811, !dbg !1686
  br i1 %21, label %22, label %28, !dbg !1687

22:                                               ; preds = %13
  %23 = fmul double %0, -0.000000e+00, !dbg !1688
  %24 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %23), !dbg !1688
  %25 = fneg double %24, !dbg !1690
  %26 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %25), !dbg !1690
  %27 = fsub double 1.000000e+00, %26, !dbg !1691
  br label %186, !dbg !1692

28:                                               ; preds = %13
  %29 = icmp ugt i32 %6, 1072234496, !dbg !1693
  %30 = add nsw i32 %6, -2097152, !dbg !1694
  %31 = zext nneg i32 %30 to i64, !dbg !1694
  %32 = shl nuw nsw i64 %31, 32, !dbg !1694
  %33 = bitcast i64 %32 to double, !dbg !1694
  %34 = select i1 %29, double 2.812500e-01, double %33, !dbg !1694
  call void @llvm.dbg.value(metadata double %34, metadata !615, metadata !DIExpression()), !dbg !1670
  %35 = fneg double %34, !dbg !1695
  %36 = tail call double @llvm.fmuladd.f64(double %14, double 5.000000e-01, double %35), !dbg !1695
  call void @llvm.dbg.value(metadata double %36, metadata !612, metadata !DIExpression()), !dbg !1670
  %37 = fsub double 1.000000e+00, %34, !dbg !1696
  call void @llvm.dbg.value(metadata double %37, metadata !611, metadata !DIExpression()), !dbg !1670
  %38 = fmul double %0, -0.000000e+00, !dbg !1697
  %39 = tail call double @llvm.fmuladd.f64(double %14, double %20, double %38), !dbg !1697
  %40 = fsub double %39, %36, !dbg !1698
  %41 = fadd double %37, %40, !dbg !1698
  br label %186, !dbg !1699

42:                                               ; preds = %1
  %43 = icmp ugt i32 %6, 2146435071, !dbg !1700
  br i1 %43, label %44, label %46, !dbg !1702

44:                                               ; preds = %42
  %45 = fsub double %0, %0, !dbg !1703
  br label %186, !dbg !1705

46:                                               ; preds = %42
  %47 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !1706
  tail call void @llvm.dbg.value(metadata i32 %47, metadata !1654, metadata !DIExpression()), !dbg !1659
  %48 = and i32 %47, 3, !dbg !1708
  %49 = load double, ptr %2, align 8, !dbg !1709, !tbaa !1438
  switch i32 %48, label %163 [
    i32 0, label %50
    i32 1, label %92
    i32 2, label %118
  ], !dbg !1711

50:                                               ; preds = %46
  %51 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1712
  %52 = load double, ptr %51, align 8, !dbg !1712, !tbaa !1438
  call void @llvm.dbg.value(metadata double %49, metadata !609, metadata !DIExpression()), !dbg !1713
  call void @llvm.dbg.value(metadata double %52, metadata !610, metadata !DIExpression()), !dbg !1713
  call void @llvm.dbg.value(metadata double %49, metadata !874, metadata !DIExpression()), !dbg !1715
  %53 = bitcast double %49 to i64, !dbg !1717
  call void @llvm.dbg.value(metadata i64 %53, metadata !879, metadata !DIExpression()), !dbg !1715
  call void @llvm.dbg.value(metadata i64 %53, metadata !617, metadata !DIExpression()), !dbg !1718
  %54 = lshr i64 %53, 32, !dbg !1719
  %55 = trunc i64 %54 to i32, !dbg !1719
  call void @llvm.dbg.value(metadata i32 %55, metadata !616, metadata !DIExpression()), !dbg !1713
  %56 = and i32 %55, 2147483647, !dbg !1720
  call void @llvm.dbg.value(metadata i32 %56, metadata !616, metadata !DIExpression()), !dbg !1713
  %57 = icmp ult i32 %56, 1044381696, !dbg !1721
  %58 = fptosi double %49 to i32
  %59 = icmp eq i32 %58, 0
  %60 = select i1 %57, i1 %59, i1 false, !dbg !1722
  br i1 %60, label %186, label %61, !dbg !1722

61:                                               ; preds = %50
  %62 = fmul double %49, %49, !dbg !1723
  call void @llvm.dbg.value(metadata double %62, metadata !613, metadata !DIExpression()), !dbg !1713
  %63 = tail call double @llvm.fmuladd.f64(double %62, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1724
  %64 = tail call double @llvm.fmuladd.f64(double %62, double %63, double 0xBE927E4F809C52AD), !dbg !1725
  %65 = tail call double @llvm.fmuladd.f64(double %62, double %64, double 0x3EFA01A019CB1590), !dbg !1726
  %66 = tail call double @llvm.fmuladd.f64(double %62, double %65, double 0xBF56C16C16C15177), !dbg !1727
  %67 = tail call double @llvm.fmuladd.f64(double %62, double %66, double 0x3FA555555555554C), !dbg !1728
  %68 = fmul double %62, %67, !dbg !1729
  call void @llvm.dbg.value(metadata double %68, metadata !614, metadata !DIExpression()), !dbg !1713
  %69 = icmp ult i32 %56, 1070805811, !dbg !1730
  br i1 %69, label %70, label %77, !dbg !1731

70:                                               ; preds = %61
  %71 = fneg double %49, !dbg !1732
  %72 = fmul double %52, %71, !dbg !1732
  %73 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %72), !dbg !1732
  %74 = fneg double %73, !dbg !1733
  %75 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %74), !dbg !1733
  %76 = fsub double 1.000000e+00, %75, !dbg !1734
  br label %186, !dbg !1735

77:                                               ; preds = %61
  %78 = icmp ugt i32 %56, 1072234496, !dbg !1736
  %79 = add nsw i32 %56, -2097152, !dbg !1737
  %80 = zext nneg i32 %79 to i64, !dbg !1737
  %81 = shl nuw nsw i64 %80, 32, !dbg !1737
  %82 = bitcast i64 %81 to double, !dbg !1737
  %83 = select i1 %78, double 2.812500e-01, double %82, !dbg !1737
  call void @llvm.dbg.value(metadata double %83, metadata !615, metadata !DIExpression()), !dbg !1713
  %84 = fneg double %83, !dbg !1738
  %85 = tail call double @llvm.fmuladd.f64(double %62, double 5.000000e-01, double %84), !dbg !1738
  call void @llvm.dbg.value(metadata double %85, metadata !612, metadata !DIExpression()), !dbg !1713
  %86 = fsub double 1.000000e+00, %83, !dbg !1739
  call void @llvm.dbg.value(metadata double %86, metadata !611, metadata !DIExpression()), !dbg !1713
  %87 = fneg double %49, !dbg !1740
  %88 = fmul double %52, %87, !dbg !1740
  %89 = tail call double @llvm.fmuladd.f64(double %62, double %68, double %88), !dbg !1740
  %90 = fsub double %89, %85, !dbg !1741
  %91 = fadd double %86, %90, !dbg !1741
  br label %186, !dbg !1742

92:                                               ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !769, metadata !DIExpression()), !dbg !1743
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !1743
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !1743
  call void @llvm.dbg.value(metadata double %49, metadata !874, metadata !DIExpression()), !dbg !1745
  %93 = bitcast double %49 to i64, !dbg !1747
  call void @llvm.dbg.value(metadata i64 %93, metadata !879, metadata !DIExpression()), !dbg !1745
  call void @llvm.dbg.value(metadata i64 %93, metadata !776, metadata !DIExpression()), !dbg !1748
  call void @llvm.dbg.value(metadata i64 %93, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1743
  %94 = and i64 %93, 9205357638345293824, !dbg !1749
  %95 = icmp ult i64 %94, 4485585228861014016, !dbg !1749
  %96 = fptosi double %49 to i32
  %97 = icmp eq i32 %96, 0
  %98 = select i1 %95, i1 %97, i1 false, !dbg !1751
  br i1 %98, label %115, label %99, !dbg !1751

99:                                               ; preds = %92
  %100 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1752
  %101 = load double, ptr %100, align 8, !dbg !1752, !tbaa !1438
  call void @llvm.dbg.value(metadata double %101, metadata !770, metadata !DIExpression()), !dbg !1743
  %102 = fmul double %49, %49, !dbg !1753
  call void @llvm.dbg.value(metadata double %102, metadata !772, metadata !DIExpression()), !dbg !1743
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !1743
  %103 = tail call double @llvm.fmuladd.f64(double %102, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1754
  %104 = tail call double @llvm.fmuladd.f64(double %102, double %103, double 0x3EC71DE357B1FE7D), !dbg !1755
  %105 = tail call double @llvm.fmuladd.f64(double %102, double %104, double 0xBF2A01A019C161D5), !dbg !1756
  %106 = tail call double @llvm.fmuladd.f64(double %102, double %105, double 0x3F8111111110F8A6), !dbg !1757
  call void @llvm.dbg.value(metadata double %106, metadata !773, metadata !DIExpression()), !dbg !1743
  %107 = fneg double %102, !dbg !1758
  %108 = fmul double %49, %107, !dbg !1758
  %109 = fmul double %108, %106, !dbg !1758
  %110 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double %109), !dbg !1758
  %111 = fneg double %101, !dbg !1761
  %112 = tail call double @llvm.fmuladd.f64(double %102, double %110, double %111), !dbg !1761
  %113 = tail call double @llvm.fmuladd.f64(double %108, double 0xBFC5555555555549, double %112), !dbg !1762
  %114 = fsub double %49, %113, !dbg !1763
  br label %115, !dbg !1764

115:                                              ; preds = %92, %99
  %116 = phi double [ %114, %99 ], [ %49, %92 ], !dbg !1743
  %117 = fneg double %116, !dbg !1765
  br label %186, !dbg !1766

118:                                              ; preds = %46
  %119 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1767
  %120 = load double, ptr %119, align 8, !dbg !1767, !tbaa !1438
  call void @llvm.dbg.value(metadata double %49, metadata !609, metadata !DIExpression()), !dbg !1768
  call void @llvm.dbg.value(metadata double %120, metadata !610, metadata !DIExpression()), !dbg !1768
  call void @llvm.dbg.value(metadata double %49, metadata !874, metadata !DIExpression()), !dbg !1770
  %121 = bitcast double %49 to i64, !dbg !1772
  call void @llvm.dbg.value(metadata i64 %121, metadata !879, metadata !DIExpression()), !dbg !1770
  call void @llvm.dbg.value(metadata i64 %121, metadata !617, metadata !DIExpression()), !dbg !1773
  %122 = lshr i64 %121, 32, !dbg !1774
  %123 = trunc i64 %122 to i32, !dbg !1774
  call void @llvm.dbg.value(metadata i32 %123, metadata !616, metadata !DIExpression()), !dbg !1768
  %124 = and i32 %123, 2147483647, !dbg !1775
  call void @llvm.dbg.value(metadata i32 %124, metadata !616, metadata !DIExpression()), !dbg !1768
  %125 = icmp ult i32 %124, 1044381696, !dbg !1776
  %126 = fptosi double %49 to i32
  %127 = icmp eq i32 %126, 0
  %128 = select i1 %125, i1 %127, i1 false, !dbg !1777
  br i1 %128, label %160, label %129, !dbg !1777

129:                                              ; preds = %118
  %130 = fmul double %49, %49, !dbg !1778
  call void @llvm.dbg.value(metadata double %130, metadata !613, metadata !DIExpression()), !dbg !1768
  %131 = tail call double @llvm.fmuladd.f64(double %130, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !1779
  %132 = tail call double @llvm.fmuladd.f64(double %130, double %131, double 0xBE927E4F809C52AD), !dbg !1780
  %133 = tail call double @llvm.fmuladd.f64(double %130, double %132, double 0x3EFA01A019CB1590), !dbg !1781
  %134 = tail call double @llvm.fmuladd.f64(double %130, double %133, double 0xBF56C16C16C15177), !dbg !1782
  %135 = tail call double @llvm.fmuladd.f64(double %130, double %134, double 0x3FA555555555554C), !dbg !1783
  %136 = fmul double %130, %135, !dbg !1784
  call void @llvm.dbg.value(metadata double %136, metadata !614, metadata !DIExpression()), !dbg !1768
  %137 = icmp ult i32 %124, 1070805811, !dbg !1785
  br i1 %137, label %138, label %145, !dbg !1786

138:                                              ; preds = %129
  %139 = fneg double %49, !dbg !1787
  %140 = fmul double %120, %139, !dbg !1787
  %141 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %140), !dbg !1787
  %142 = fneg double %141, !dbg !1788
  %143 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %142), !dbg !1788
  %144 = fsub double 1.000000e+00, %143, !dbg !1789
  br label %160, !dbg !1790

145:                                              ; preds = %129
  %146 = icmp ugt i32 %124, 1072234496, !dbg !1791
  %147 = add nsw i32 %124, -2097152, !dbg !1792
  %148 = zext nneg i32 %147 to i64, !dbg !1792
  %149 = shl nuw nsw i64 %148, 32, !dbg !1792
  %150 = bitcast i64 %149 to double, !dbg !1792
  %151 = select i1 %146, double 2.812500e-01, double %150, !dbg !1792
  call void @llvm.dbg.value(metadata double %151, metadata !615, metadata !DIExpression()), !dbg !1768
  %152 = fneg double %151, !dbg !1793
  %153 = tail call double @llvm.fmuladd.f64(double %130, double 5.000000e-01, double %152), !dbg !1793
  call void @llvm.dbg.value(metadata double %153, metadata !612, metadata !DIExpression()), !dbg !1768
  %154 = fsub double 1.000000e+00, %151, !dbg !1794
  call void @llvm.dbg.value(metadata double %154, metadata !611, metadata !DIExpression()), !dbg !1768
  %155 = fneg double %49, !dbg !1795
  %156 = fmul double %120, %155, !dbg !1795
  %157 = tail call double @llvm.fmuladd.f64(double %130, double %136, double %156), !dbg !1795
  %158 = fsub double %157, %153, !dbg !1796
  %159 = fadd double %154, %158, !dbg !1796
  br label %160, !dbg !1797

160:                                              ; preds = %118, %138, %145
  %161 = phi double [ %144, %138 ], [ %159, %145 ], [ 1.000000e+00, %118 ], !dbg !1768
  %162 = fneg double %161, !dbg !1798
  br label %186, !dbg !1799

163:                                              ; preds = %46
  call void @llvm.dbg.value(metadata double %49, metadata !769, metadata !DIExpression()), !dbg !1800
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !1800
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !1800
  call void @llvm.dbg.value(metadata double %49, metadata !874, metadata !DIExpression()), !dbg !1802
  %164 = bitcast double %49 to i64, !dbg !1804
  call void @llvm.dbg.value(metadata i64 %164, metadata !879, metadata !DIExpression()), !dbg !1802
  call void @llvm.dbg.value(metadata i64 %164, metadata !776, metadata !DIExpression()), !dbg !1805
  call void @llvm.dbg.value(metadata i64 %164, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !1800
  %165 = and i64 %164, 9205357638345293824, !dbg !1806
  %166 = icmp ult i64 %165, 4485585228861014016, !dbg !1806
  %167 = fptosi double %49 to i32
  %168 = icmp eq i32 %167, 0
  %169 = select i1 %166, i1 %168, i1 false, !dbg !1807
  br i1 %169, label %186, label %170, !dbg !1807

170:                                              ; preds = %163
  %171 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !1808
  %172 = load double, ptr %171, align 8, !dbg !1808, !tbaa !1438
  call void @llvm.dbg.value(metadata double %172, metadata !770, metadata !DIExpression()), !dbg !1800
  %173 = fmul double %49, %49, !dbg !1809
  call void @llvm.dbg.value(metadata double %173, metadata !772, metadata !DIExpression()), !dbg !1800
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !1800
  %174 = tail call double @llvm.fmuladd.f64(double %173, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !1810
  %175 = tail call double @llvm.fmuladd.f64(double %173, double %174, double 0x3EC71DE357B1FE7D), !dbg !1811
  %176 = tail call double @llvm.fmuladd.f64(double %173, double %175, double 0xBF2A01A019C161D5), !dbg !1812
  %177 = tail call double @llvm.fmuladd.f64(double %173, double %176, double 0x3F8111111110F8A6), !dbg !1813
  call void @llvm.dbg.value(metadata double %177, metadata !773, metadata !DIExpression()), !dbg !1800
  %178 = fneg double %173, !dbg !1814
  %179 = fmul double %49, %178, !dbg !1814
  %180 = fmul double %179, %177, !dbg !1814
  %181 = tail call double @llvm.fmuladd.f64(double %172, double 5.000000e-01, double %180), !dbg !1814
  %182 = fneg double %172, !dbg !1815
  %183 = tail call double @llvm.fmuladd.f64(double %173, double %181, double %182), !dbg !1815
  %184 = tail call double @llvm.fmuladd.f64(double %179, double 0xBFC5555555555549, double %183), !dbg !1816
  %185 = fsub double %49, %184, !dbg !1817
  br label %186, !dbg !1818

186:                                              ; preds = %170, %163, %77, %70, %50, %28, %22, %8, %160, %115, %44
  %187 = phi double [ %45, %44 ], [ %162, %160 ], [ %117, %115 ], [ %27, %22 ], [ %41, %28 ], [ 1.000000e+00, %8 ], [ %76, %70 ], [ %91, %77 ], [ 1.000000e+00, %50 ], [ %185, %170 ], [ %49, %163 ], !dbg !1819
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !1820
  ret double %187, !dbg !1820
}

; Function Attrs: nofree nosync nounwind memory(argmem: write) uwtable
define internal fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr nocapture noundef writeonly %1) unnamed_addr #6 !dbg !639 {
  %3 = alloca [20 x i32], align 4, !DIAssignID !1821
  %4 = alloca [20 x double], align 8, !DIAssignID !1822
  %5 = alloca [20 x double], align 8, !DIAssignID !1823
  %6 = alloca [20 x double], align 8, !DIAssignID !1824
  %7 = alloca [3 x double], align 8, !DIAssignID !1825
  call void @llvm.dbg.assign(metadata i1 undef, metadata !651, metadata !DIExpression(), metadata !1825, metadata ptr %7, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata double %0, metadata !644, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata ptr %1, metadata !645, metadata !DIExpression()), !dbg !1826
  call void @llvm.lifetime.start.p0(i64 24, ptr nonnull %7) #11, !dbg !1827
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !646, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1828
  %8 = bitcast double %0 to i64, !dbg !1830
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !879, metadata !DIExpression()), !dbg !1828
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !663, metadata !DIExpression()), !dbg !1831
  %9 = lshr i64 %8, 32, !dbg !1832
  %10 = trunc i64 %9 to i32, !dbg !1832
  tail call void @llvm.dbg.value(metadata i32 %10, metadata !661, metadata !DIExpression()), !dbg !1826
  %11 = and i32 %10, 2147483647, !dbg !1833
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !660, metadata !DIExpression()), !dbg !1826
  %12 = icmp ult i32 %11, 1072243196, !dbg !1834
  br i1 %12, label %13, label %15, !dbg !1836

13:                                               ; preds = %2
  store double %0, ptr %1, align 8, !dbg !1837, !tbaa !1438
  %14 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1839
  store double 0.000000e+00, ptr %14, align 8, !dbg !1840, !tbaa !1438
  br label %853, !dbg !1841

15:                                               ; preds = %2
  %16 = icmp ult i32 %11, 1073928572, !dbg !1842
  br i1 %16, label %17, label %46, !dbg !1844

17:                                               ; preds = %15
  %18 = icmp sgt i32 %10, 0, !dbg !1845
  %19 = icmp eq i32 %11, 1073291771, !dbg !1848
  br i1 %18, label %20, label %33, !dbg !1849

20:                                               ; preds = %17
  %21 = fadd double %0, 0xBFF921FB54400000, !dbg !1850
  tail call void @llvm.dbg.value(metadata double %21, metadata !646, metadata !DIExpression()), !dbg !1826
  br i1 %19, label %27, label %22, !dbg !1852

22:                                               ; preds = %20
  %23 = fadd double %21, 0xBDD0B4611A626331, !dbg !1853
  store double %23, ptr %1, align 8, !dbg !1856, !tbaa !1438
  %24 = fsub double %21, %23, !dbg !1857
  %25 = fadd double %24, 0xBDD0B4611A626331, !dbg !1858
  %26 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1859
  store double %25, ptr %26, align 8, !dbg !1860, !tbaa !1438
  br label %853, !dbg !1861

27:                                               ; preds = %20
  %28 = fadd double %21, 0xBDD0B4611A600000, !dbg !1862
  tail call void @llvm.dbg.value(metadata double %28, metadata !646, metadata !DIExpression()), !dbg !1826
  %29 = fadd double %28, 0xBBA3198A2E037073, !dbg !1864
  store double %29, ptr %1, align 8, !dbg !1865, !tbaa !1438
  %30 = fsub double %28, %29, !dbg !1866
  %31 = fadd double %30, 0xBBA3198A2E037073, !dbg !1867
  %32 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1868
  store double %31, ptr %32, align 8, !dbg !1869, !tbaa !1438
  br label %853

33:                                               ; preds = %17
  %34 = fadd double %0, 0x3FF921FB54400000, !dbg !1870
  tail call void @llvm.dbg.value(metadata double %34, metadata !646, metadata !DIExpression()), !dbg !1826
  br i1 %19, label %40, label %35, !dbg !1872

35:                                               ; preds = %33
  %36 = fadd double %34, 0x3DD0B4611A626331, !dbg !1873
  store double %36, ptr %1, align 8, !dbg !1876, !tbaa !1438
  %37 = fsub double %34, %36, !dbg !1877
  %38 = fadd double %37, 0x3DD0B4611A626331, !dbg !1878
  %39 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1879
  store double %38, ptr %39, align 8, !dbg !1880, !tbaa !1438
  br label %853, !dbg !1881

40:                                               ; preds = %33
  %41 = fadd double %34, 0x3DD0B4611A600000, !dbg !1882
  tail call void @llvm.dbg.value(metadata double %41, metadata !646, metadata !DIExpression()), !dbg !1826
  %42 = fadd double %41, 0x3BA3198A2E037073, !dbg !1884
  store double %42, ptr %1, align 8, !dbg !1885, !tbaa !1438
  %43 = fsub double %41, %42, !dbg !1886
  %44 = fadd double %43, 0x3BA3198A2E037073, !dbg !1887
  %45 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1888
  store double %44, ptr %45, align 8, !dbg !1889, !tbaa !1438
  br label %853

46:                                               ; preds = %15
  %47 = icmp ult i32 %11, 1094263292, !dbg !1890
  br i1 %47, label %48, label %112, !dbg !1891

48:                                               ; preds = %46
  %49 = tail call double @llvm.fabs.f64(double %0), !dbg !1892
  tail call void @llvm.dbg.value(metadata double %49, metadata !648, metadata !DIExpression()), !dbg !1826
  %50 = tail call double @llvm.fmuladd.f64(double %49, double 0x3FE45F306DC9C883, double 5.000000e-01), !dbg !1893
  %51 = fptosi double %50 to i32, !dbg !1894
  tail call void @llvm.dbg.value(metadata i32 %51, metadata !659, metadata !DIExpression()), !dbg !1826
  %52 = sitofp i32 %51 to double, !dbg !1895
  tail call void @llvm.dbg.value(metadata double %52, metadata !650, metadata !DIExpression()), !dbg !1826
  %53 = fneg double %52, !dbg !1896
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FF921FB54400000, double %49), !dbg !1896
  tail call void @llvm.dbg.value(metadata double %54, metadata !649, metadata !DIExpression()), !dbg !1826
  %55 = fmul double %52, 0x3DD0B4611A626331, !dbg !1897
  tail call void @llvm.dbg.value(metadata double %55, metadata !647, metadata !DIExpression()), !dbg !1826
  %56 = icmp slt i32 %51, 32, !dbg !1898
  br i1 %56, label %57, label %65, !dbg !1899

57:                                               ; preds = %48
  %58 = add nsw i32 %51, -1, !dbg !1900
  %59 = sext i32 %58 to i64, !dbg !1901
  %60 = getelementptr inbounds [32 x i32], ptr @__ieee754_rem_pio2.npio2_hw, i64 0, i64 %59, !dbg !1901
  %61 = load i32, ptr %60, align 4, !dbg !1901, !tbaa !1902
  %62 = icmp eq i32 %11, %61, !dbg !1904
  br i1 %62, label %65, label %63, !dbg !1905

63:                                               ; preds = %57
  %64 = fsub double %54, %55, !dbg !1906
  br label %96, !dbg !1908

65:                                               ; preds = %57, %48
  %66 = lshr i32 %11, 20
  tail call void @llvm.dbg.value(metadata i32 %66, metadata !657, metadata !DIExpression()), !dbg !1826
  %67 = fsub double %54, %55, !dbg !1909
  store double %67, ptr %1, align 8, !dbg !1910, !tbaa !1438
  tail call void @llvm.dbg.value(metadata double %67, metadata !874, metadata !DIExpression()), !dbg !1911
  %68 = bitcast double %67 to i64, !dbg !1913
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !879, metadata !DIExpression()), !dbg !1911
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !670, metadata !DIExpression()), !dbg !1914
  tail call void @llvm.dbg.value(metadata i64 %68, metadata !665, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1915
  %69 = lshr i64 %68, 52, !dbg !1916
  %70 = trunc i64 %69 to i32, !dbg !1916
  %71 = and i32 %70, 2047, !dbg !1917
  %72 = sub nsw i32 %66, %71, !dbg !1918
  tail call void @llvm.dbg.value(metadata i32 %72, metadata !656, metadata !DIExpression()), !dbg !1826
  %73 = icmp sgt i32 %72, 16, !dbg !1919
  br i1 %73, label %74, label %100, !dbg !1920

74:                                               ; preds = %65
  tail call void @llvm.dbg.value(metadata double %54, metadata !648, metadata !DIExpression()), !dbg !1826
  %75 = fmul double %52, 0x3DD0B4611A600000, !dbg !1921
  tail call void @llvm.dbg.value(metadata double %75, metadata !647, metadata !DIExpression()), !dbg !1826
  %76 = fsub double %54, %75, !dbg !1922
  tail call void @llvm.dbg.value(metadata double %76, metadata !649, metadata !DIExpression()), !dbg !1826
  %77 = fsub double %54, %76, !dbg !1923
  %78 = fsub double %77, %75, !dbg !1924
  %79 = fneg double %78, !dbg !1925
  %80 = tail call double @llvm.fmuladd.f64(double %52, double 0x3BA3198A2E037073, double %79), !dbg !1925
  tail call void @llvm.dbg.value(metadata double %80, metadata !647, metadata !DIExpression()), !dbg !1826
  %81 = fsub double %76, %80, !dbg !1926
  store double %81, ptr %1, align 8, !dbg !1927, !tbaa !1438
  tail call void @llvm.dbg.value(metadata double %81, metadata !874, metadata !DIExpression()), !dbg !1928
  %82 = bitcast double %81 to i64, !dbg !1930
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !879, metadata !DIExpression()), !dbg !1928
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !672, metadata !DIExpression()), !dbg !1931
  tail call void @llvm.dbg.value(metadata i64 %82, metadata !665, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1915
  %83 = lshr i64 %82, 52, !dbg !1932
  %84 = trunc i64 %83 to i32, !dbg !1932
  %85 = and i32 %84, 2047, !dbg !1933
  %86 = sub nsw i32 %66, %85, !dbg !1934
  tail call void @llvm.dbg.value(metadata i32 %86, metadata !656, metadata !DIExpression()), !dbg !1826
  %87 = icmp sgt i32 %86, 49, !dbg !1935
  br i1 %87, label %88, label %100, !dbg !1937

88:                                               ; preds = %74
  tail call void @llvm.dbg.value(metadata double %76, metadata !648, metadata !DIExpression()), !dbg !1826
  %89 = fmul double %52, 0x3BA3198A2E000000, !dbg !1938
  tail call void @llvm.dbg.value(metadata double %89, metadata !647, metadata !DIExpression()), !dbg !1826
  %90 = fsub double %76, %89, !dbg !1940
  tail call void @llvm.dbg.value(metadata double %90, metadata !649, metadata !DIExpression()), !dbg !1826
  %91 = fsub double %76, %90, !dbg !1941
  %92 = fsub double %91, %89, !dbg !1942
  %93 = fneg double %92, !dbg !1943
  %94 = tail call double @llvm.fmuladd.f64(double %52, double 0x397B839A252049C1, double %93), !dbg !1943
  tail call void @llvm.dbg.value(metadata double %94, metadata !647, metadata !DIExpression()), !dbg !1826
  %95 = fsub double %90, %94, !dbg !1944
  br label %96, !dbg !1945

96:                                               ; preds = %63, %88
  %97 = phi double [ %95, %88 ], [ %64, %63 ]
  %98 = phi double [ %90, %88 ], [ %54, %63 ]
  %99 = phi double [ %94, %88 ], [ %55, %63 ]
  store double %97, ptr %1, align 8, !dbg !1946, !tbaa !1438
  br label %100, !dbg !1947

100:                                              ; preds = %96, %65, %74
  %101 = phi double [ %81, %74 ], [ %67, %65 ], [ %97, %96 ], !dbg !1948
  %102 = phi double [ %76, %74 ], [ %54, %65 ], [ %98, %96 ], !dbg !1949
  %103 = phi double [ %80, %74 ], [ %55, %65 ], [ %99, %96 ], !dbg !1949
  tail call void @llvm.dbg.value(metadata double %103, metadata !647, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata double %102, metadata !649, metadata !DIExpression()), !dbg !1826
  %104 = fsub double %102, %101, !dbg !1947
  %105 = fsub double %104, %103, !dbg !1950
  %106 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1951
  store double %105, ptr %106, align 8, !dbg !1952, !tbaa !1438
  %107 = icmp slt i64 %8, 0, !dbg !1953
  br i1 %107, label %108, label %853, !dbg !1955

108:                                              ; preds = %100
  %109 = fneg double %101, !dbg !1956
  store double %109, ptr %1, align 8, !dbg !1958, !tbaa !1438
  %110 = fneg double %105, !dbg !1959
  store double %110, ptr %106, align 8, !dbg !1960, !tbaa !1438
  %111 = sub nsw i32 0, %51, !dbg !1961
  br label %853, !dbg !1962

112:                                              ; preds = %46
  %113 = icmp ugt i32 %11, 2146435071, !dbg !1963
  br i1 %113, label %114, label %117, !dbg !1965

114:                                              ; preds = %112
  %115 = fsub double %0, %0, !dbg !1966
  %116 = getelementptr inbounds double, ptr %1, i64 1, !dbg !1968
  store double %115, ptr %116, align 8, !dbg !1969, !tbaa !1438
  store double %115, ptr %1, align 8, !dbg !1970, !tbaa !1438
  br label %853, !dbg !1971

117:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !1972
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !879, metadata !DIExpression()), !dbg !1972
  tail call void @llvm.dbg.value(metadata i64 %8, metadata !662, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !1826
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !874, metadata !DIExpression()), !dbg !1974
  tail call void @llvm.dbg.value(metadata i64 0, metadata !879, metadata !DIExpression()), !dbg !1974
  tail call void @llvm.dbg.value(metadata i64 0, metadata !678, metadata !DIExpression()), !dbg !1976
  %118 = and i64 %8, 4294967295, !dbg !1977
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !678, metadata !DIExpression()), !dbg !1976
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !948, metadata !DIExpression()), !dbg !1978
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !953, metadata !DIExpression()), !dbg !1978
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !646, metadata !DIExpression()), !dbg !1826
  %119 = lshr i32 %11, 20
  %120 = add nsw i32 %119, -1046, !dbg !1980
  tail call void @llvm.dbg.value(metadata i32 %120, metadata !655, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !874, metadata !DIExpression()), !dbg !1981
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !879, metadata !DIExpression()), !dbg !1981
  tail call void @llvm.dbg.value(metadata i64 %118, metadata !680, metadata !DIExpression()), !dbg !1983
  %121 = shl nsw i32 %120, 20, !dbg !1984
  %122 = sub nsw i32 %11, %121, !dbg !1984
  %123 = sext i32 %122 to i64, !dbg !1984
  %124 = shl nsw i64 %123, 32, !dbg !1984
  %125 = or disjoint i64 %124, %118, !dbg !1984
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !680, metadata !DIExpression()), !dbg !1983
  tail call void @llvm.dbg.value(metadata i64 %125, metadata !948, metadata !DIExpression()), !dbg !1985
  %126 = bitcast i64 %125 to double, !dbg !1987
  tail call void @llvm.dbg.value(metadata double %126, metadata !953, metadata !DIExpression()), !dbg !1985
  tail call void @llvm.dbg.value(metadata double %126, metadata !646, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata i64 0, metadata !656, metadata !DIExpression()), !dbg !1826
  %127 = fptosi double %126 to i32, !dbg !1988
  %128 = sitofp i32 %127 to double, !dbg !1992
  store double %128, ptr %7, align 8, !dbg !1993, !tbaa !1438
  %129 = fsub double %126, %128, !dbg !1994
  %130 = fmul double %129, 0x4170000000000000, !dbg !1995
  tail call void @llvm.dbg.value(metadata double %130, metadata !646, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata i64 1, metadata !656, metadata !DIExpression()), !dbg !1826
  %131 = fptosi double %130 to i32, !dbg !1988
  %132 = sitofp i32 %131 to double, !dbg !1992
  %133 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 1, !dbg !1996
  store double %132, ptr %133, align 8, !dbg !1993, !tbaa !1438
  %134 = fsub double %130, %132, !dbg !1994
  %135 = fmul double %134, 0x4170000000000000, !dbg !1995
  tail call void @llvm.dbg.value(metadata double %135, metadata !646, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata i64 2, metadata !656, metadata !DIExpression()), !dbg !1826
  %136 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 2, !dbg !1997
  store double %135, ptr %136, align 8, !dbg !1998, !tbaa !1438, !DIAssignID !1999
  call void @llvm.dbg.assign(metadata double %135, metadata !651, metadata !DIExpression(DW_OP_LLVM_fragment, 128, 64), metadata !1999, metadata ptr %136, metadata !DIExpression()), !dbg !1826
  tail call void @llvm.dbg.value(metadata i32 3, metadata !658, metadata !DIExpression()), !dbg !1826
  br label %137, !dbg !2000

137:                                              ; preds = %137, %117
  %138 = phi i32 [ %144, %137 ], [ 0, %117 ]
  %139 = phi i64 [ %140, %137 ], [ 3, %117 ], !dbg !1826
  tail call void @llvm.dbg.value(metadata i64 %139, metadata !658, metadata !DIExpression()), !dbg !1826
  %140 = add nsw i64 %139, -1, !dbg !2001
  %141 = getelementptr inbounds [3 x double], ptr %7, i64 0, i64 %140, !dbg !2002
  %142 = load double, ptr %141, align 8, !dbg !2002, !tbaa !1438
  %143 = fcmp oeq double %142, 0.000000e+00, !dbg !2003
  %144 = add i32 %138, 1, !dbg !2000
  br i1 %143, label %137, label %145, !dbg !2000, !llvm.loop !2004

145:                                              ; preds = %137
  %146 = trunc i64 %139 to i32, !dbg !2007
  call void @llvm.dbg.assign(metadata i1 undef, metadata !731, metadata !DIExpression(), metadata !1821, metadata ptr %3, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.assign(metadata i1 undef, metadata !743, metadata !DIExpression(), metadata !1822, metadata ptr %4, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.assign(metadata i1 undef, metadata !745, metadata !DIExpression(), metadata !1823, metadata ptr %5, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.assign(metadata i1 undef, metadata !746, metadata !DIExpression(), metadata !1824, metadata ptr %6, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata ptr %7, metadata !718, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata ptr %1, metadata !719, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %120, metadata !720, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %146, metadata !721, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 2, metadata !722, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata ptr @__ieee754_rem_pio2.two_over_pi, metadata !723, metadata !DIExpression()), !dbg !2009
  call void @llvm.lifetime.start.p0(i64 80, ptr nonnull %3) #11, !dbg !2007
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %4) #11, !dbg !2010
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %5) #11, !dbg !2010
  call void @llvm.lifetime.start.p0(i64 160, ptr nonnull %6) #11, !dbg !2010
  call void @llvm.dbg.value(metadata i32 4, metadata !728, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 4, metadata !727, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %140, metadata !725, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2009
  %147 = add nsw i32 %119, -1049, !dbg !2011
  %148 = sdiv i32 %147, 24, !dbg !2012
  call void @llvm.dbg.value(metadata i32 %148, metadata !726, metadata !DIExpression()), !dbg !2009
  %149 = mul nsw i32 %148, -24, !dbg !2013
  %150 = add nsw i32 %149, %120, !dbg !2013
  %151 = add nsw i32 %150, -24, !dbg !2014
  call void @llvm.dbg.value(metadata i32 %151, metadata !739, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %146, metadata !738, metadata !DIExpression(DW_OP_plus_uconst, 3, DW_OP_stack_value)), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i64 %140), metadata !736, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_minus, DW_OP_stack_value)), !dbg !2009
  %152 = icmp slt i32 %146, -3, !dbg !2015
  br i1 %152, label %399, label %153, !dbg !2018

153:                                              ; preds = %145
  %154 = trunc i64 %140 to i32, !dbg !2007
  call void @llvm.dbg.value(metadata i32 %154, metadata !725, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata !DIArgList(i32 %148, i32 %154), metadata !736, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2009
  %155 = add i32 %146, 3, !dbg !2019
  call void @llvm.dbg.value(metadata i32 %155, metadata !738, metadata !DIExpression()), !dbg !2009
  %156 = sub nsw i32 %148, %154, !dbg !2020
  call void @llvm.dbg.value(metadata i32 %156, metadata !736, metadata !DIExpression()), !dbg !2009
  %157 = tail call i32 @llvm.smax.i32(i32 %155, i32 0), !dbg !2018
  %158 = add nuw i32 %157, 1, !dbg !2018
  %159 = zext i32 %158 to i64, !dbg !2015
  br label %162, !dbg !2018

160:                                              ; preds = %171
  %161 = icmp sgt i32 %146, 0
  call void @llvm.dbg.value(metadata i64 0, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  br i1 %161, label %177, label %399, !dbg !2021

162:                                              ; preds = %171, %153
  %163 = phi i64 [ 0, %153 ], [ %174, %171 ]
  %164 = phi i32 [ %156, %153 ], [ %175, %171 ]
  call void @llvm.dbg.value(metadata i32 %164, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %163, metadata !735, metadata !DIExpression()), !dbg !2009
  %165 = icmp slt i32 %164, 0, !dbg !2026
  br i1 %165, label %171, label %166, !dbg !2028

166:                                              ; preds = %162
  %167 = zext nneg i32 %164 to i64
  %168 = getelementptr inbounds i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %167, !dbg !2029
  %169 = load i32, ptr %168, align 4, !dbg !2029, !tbaa !1902
  %170 = sitofp i32 %169 to double, !dbg !2030
  br label %171, !dbg !2028

171:                                              ; preds = %166, %162
  %172 = phi double [ %170, %166 ], [ 0.000000e+00, %162 ], !dbg !2028
  %173 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %163, !dbg !2031
  store double %172, ptr %173, align 8, !dbg !2032, !tbaa !1438
  %174 = add nuw nsw i64 %163, 1, !dbg !2033
  call void @llvm.dbg.value(metadata i64 %174, metadata !735, metadata !DIExpression()), !dbg !2009
  %175 = add nsw i32 %164, 1, !dbg !2034
  call void @llvm.dbg.value(metadata i32 %175, metadata !736, metadata !DIExpression()), !dbg !2009
  %176 = icmp eq i64 %174, %159, !dbg !2015
  br i1 %176, label %160, label %162, !dbg !2018, !llvm.loop !2035

177:                                              ; preds = %160
  %178 = and i64 %139, 4294967295, !dbg !2037
  %179 = icmp ult i64 %178, 8, !dbg !2021
  br i1 %179, label %215, label %180, !dbg !2021

180:                                              ; preds = %177
  %181 = add nsw i64 %178, -1, !dbg !2021
  %182 = trunc i64 %181 to i32, !dbg !2021
  %183 = sub i32 %154, %182, !dbg !2021
  %184 = icmp sgt i32 %183, %154, !dbg !2021
  %185 = icmp ugt i64 %181, 4294967295, !dbg !2021
  %186 = or i1 %184, %185, !dbg !2021
  br i1 %186, label %215, label %187

187:                                              ; preds = %180
  %188 = and i64 %139, 3, !dbg !2021
  %189 = sub nsw i64 %178, %188, !dbg !2021
  br label %190, !dbg !2021

190:                                              ; preds = %190, %187
  %191 = phi i64 [ 0, %187 ], [ %211, %190 ], !dbg !2039
  %192 = phi double [ 0.000000e+00, %187 ], [ %210, %190 ]
  %193 = getelementptr inbounds double, ptr %7, i64 %191, !dbg !2040
  %194 = getelementptr inbounds double, ptr %193, i64 2, !dbg !2040
  %195 = load <2 x double>, ptr %193, align 8, !dbg !2040, !tbaa !1438
  %196 = load <2 x double>, ptr %194, align 8, !dbg !2040, !tbaa !1438
  %197 = sub i64 %140, %191, !dbg !2041
  %198 = shl i64 %197, 32, !dbg !2042
  %199 = ashr exact i64 %198, 32, !dbg !2042
  %200 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %199, !dbg !2042
  %201 = getelementptr inbounds double, ptr %200, i64 -1, !dbg !2042
  %202 = getelementptr inbounds double, ptr %200, i64 -3, !dbg !2042
  %203 = load <2 x double>, ptr %201, align 8, !dbg !2042, !tbaa !1438
  %204 = shufflevector <2 x double> %203, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %205 = load <2 x double>, ptr %202, align 8, !dbg !2042, !tbaa !1438
  %206 = shufflevector <2 x double> %205, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %207 = fmul <2 x double> %195, %204
  %208 = fmul <2 x double> %196, %206
  %209 = tail call double @llvm.vector.reduce.fadd.v2f64(double %192, <2 x double> %207)
  %210 = tail call double @llvm.vector.reduce.fadd.v2f64(double %209, <2 x double> %208)
  %211 = add nuw i64 %191, 4, !dbg !2039
  %212 = icmp eq i64 %211, %189, !dbg !2039
  br i1 %212, label %213, label %190, !dbg !2039, !llvm.loop !2043

213:                                              ; preds = %190
  %214 = icmp eq i64 %188, 0, !dbg !2021
  br i1 %214, label %231, label %215, !dbg !2021

215:                                              ; preds = %180, %177, %213
  %216 = phi i64 [ 0, %180 ], [ 0, %177 ], [ %189, %213 ]
  %217 = phi double [ 0.000000e+00, %180 ], [ 0.000000e+00, %177 ], [ %210, %213 ]
  br label %218, !dbg !2021

218:                                              ; preds = %215, %218
  %219 = phi i64 [ %229, %218 ], [ %216, %215 ]
  %220 = phi double [ %228, %218 ], [ %217, %215 ]
  call void @llvm.dbg.value(metadata double %220, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %219, metadata !736, metadata !DIExpression()), !dbg !2009
  %221 = getelementptr inbounds double, ptr %7, i64 %219, !dbg !2040
  %222 = load double, ptr %221, align 8, !dbg !2040, !tbaa !1438
  %223 = sub i64 %140, %219, !dbg !2041
  %224 = shl i64 %223, 32, !dbg !2042
  %225 = ashr exact i64 %224, 32, !dbg !2042
  %226 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %225, !dbg !2042
  %227 = load double, ptr %226, align 8, !dbg !2042, !tbaa !1438
  %228 = tail call double @llvm.fmuladd.f64(double %222, double %227, double %220), !dbg !2047
  call void @llvm.dbg.value(metadata double %228, metadata !742, metadata !DIExpression()), !dbg !2009
  %229 = add nuw nsw i64 %219, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i64 %229, metadata !736, metadata !DIExpression()), !dbg !2009
  %230 = icmp eq i64 %229, %178, !dbg !2037
  br i1 %230, label %231, label %218, !dbg !2021, !llvm.loop !2048

231:                                              ; preds = %218, %213
  %232 = phi double [ %210, %213 ], [ %228, %218 ], !dbg !2047
  store double %232, ptr %6, align 8, !dbg !2049, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 1, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  %233 = icmp ult i64 %178, 8, !dbg !2021
  br i1 %233, label %269, label %234, !dbg !2021

234:                                              ; preds = %231
  %235 = add nsw i64 %178, -1, !dbg !2021
  %236 = trunc i64 %235 to i32, !dbg !2021
  %237 = sub i32 %146, %236, !dbg !2021
  %238 = icmp sgt i32 %237, %146, !dbg !2021
  %239 = icmp ugt i64 %235, 4294967295, !dbg !2021
  %240 = or i1 %238, %239, !dbg !2021
  br i1 %240, label %269, label %241

241:                                              ; preds = %234
  %242 = and i64 %139, 3, !dbg !2021
  %243 = sub nsw i64 %178, %242, !dbg !2021
  br label %244, !dbg !2021

244:                                              ; preds = %244, %241
  %245 = phi i64 [ 0, %241 ], [ %265, %244 ], !dbg !2039
  %246 = phi double [ 0.000000e+00, %241 ], [ %264, %244 ]
  %247 = getelementptr inbounds double, ptr %7, i64 %245, !dbg !2040
  %248 = getelementptr inbounds double, ptr %247, i64 2, !dbg !2040
  %249 = load <2 x double>, ptr %247, align 8, !dbg !2040, !tbaa !1438
  %250 = load <2 x double>, ptr %248, align 8, !dbg !2040, !tbaa !1438
  %251 = sub i64 %139, %245, !dbg !2041
  %252 = shl i64 %251, 32, !dbg !2042
  %253 = ashr exact i64 %252, 32, !dbg !2042
  %254 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %253, !dbg !2042
  %255 = getelementptr inbounds double, ptr %254, i64 -1, !dbg !2042
  %256 = getelementptr inbounds double, ptr %254, i64 -3, !dbg !2042
  %257 = load <2 x double>, ptr %255, align 8, !dbg !2042, !tbaa !1438
  %258 = shufflevector <2 x double> %257, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %259 = load <2 x double>, ptr %256, align 8, !dbg !2042, !tbaa !1438
  %260 = shufflevector <2 x double> %259, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %261 = fmul <2 x double> %249, %258
  %262 = fmul <2 x double> %250, %260
  %263 = tail call double @llvm.vector.reduce.fadd.v2f64(double %246, <2 x double> %261)
  %264 = tail call double @llvm.vector.reduce.fadd.v2f64(double %263, <2 x double> %262)
  %265 = add nuw i64 %245, 4, !dbg !2039
  %266 = icmp eq i64 %265, %243, !dbg !2039
  br i1 %266, label %267, label %244, !dbg !2039, !llvm.loop !2050

267:                                              ; preds = %244
  %268 = icmp eq i64 %242, 0, !dbg !2021
  br i1 %268, label %285, label %269, !dbg !2021

269:                                              ; preds = %234, %231, %267
  %270 = phi i64 [ 0, %234 ], [ 0, %231 ], [ %243, %267 ]
  %271 = phi double [ 0.000000e+00, %234 ], [ 0.000000e+00, %231 ], [ %264, %267 ]
  br label %272, !dbg !2021

272:                                              ; preds = %269, %272
  %273 = phi i64 [ %283, %272 ], [ %270, %269 ]
  %274 = phi double [ %282, %272 ], [ %271, %269 ]
  call void @llvm.dbg.value(metadata double %274, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %273, metadata !736, metadata !DIExpression()), !dbg !2009
  %275 = getelementptr inbounds double, ptr %7, i64 %273, !dbg !2040
  %276 = load double, ptr %275, align 8, !dbg !2040, !tbaa !1438
  %277 = sub i64 %139, %273, !dbg !2041
  %278 = shl i64 %277, 32, !dbg !2042
  %279 = ashr exact i64 %278, 32, !dbg !2042
  %280 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %279, !dbg !2042
  %281 = load double, ptr %280, align 8, !dbg !2042, !tbaa !1438
  %282 = tail call double @llvm.fmuladd.f64(double %276, double %281, double %274), !dbg !2047
  call void @llvm.dbg.value(metadata double %282, metadata !742, metadata !DIExpression()), !dbg !2009
  %283 = add nuw nsw i64 %273, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i64 %283, metadata !736, metadata !DIExpression()), !dbg !2009
  %284 = icmp eq i64 %283, %178, !dbg !2037
  br i1 %284, label %285, label %272, !dbg !2021, !llvm.loop !2051

285:                                              ; preds = %272, %267
  %286 = phi double [ %264, %267 ], [ %282, %272 ], !dbg !2047
  %287 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 1, !dbg !2052
  store double %286, ptr %287, align 8, !dbg !2049, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 2, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  %288 = add i64 %139, 1
  %289 = icmp ult i64 %178, 10, !dbg !2021
  br i1 %289, label %326, label %290, !dbg !2021

290:                                              ; preds = %285
  %291 = add nsw i64 %178, -1, !dbg !2021
  %292 = sub i32 4, %138, !dbg !2021
  %293 = trunc i64 %291 to i32, !dbg !2021
  %294 = sub i32 %292, %293, !dbg !2021
  %295 = icmp sgt i32 %294, %292, !dbg !2021
  %296 = icmp ugt i64 %291, 4294967295, !dbg !2021
  %297 = or i1 %295, %296, !dbg !2021
  br i1 %297, label %326, label %298

298:                                              ; preds = %290
  %299 = and i64 %139, 3, !dbg !2021
  %300 = sub nsw i64 %178, %299, !dbg !2021
  br label %301, !dbg !2021

301:                                              ; preds = %301, %298
  %302 = phi i64 [ 0, %298 ], [ %322, %301 ], !dbg !2039
  %303 = phi double [ 0.000000e+00, %298 ], [ %321, %301 ]
  %304 = getelementptr inbounds double, ptr %7, i64 %302, !dbg !2040
  %305 = getelementptr inbounds double, ptr %304, i64 2, !dbg !2040
  %306 = load <2 x double>, ptr %304, align 8, !dbg !2040, !tbaa !1438
  %307 = load <2 x double>, ptr %305, align 8, !dbg !2040, !tbaa !1438
  %308 = sub i64 %288, %302, !dbg !2041
  %309 = shl i64 %308, 32, !dbg !2042
  %310 = ashr exact i64 %309, 32, !dbg !2042
  %311 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %310, !dbg !2042
  %312 = getelementptr inbounds double, ptr %311, i64 -1, !dbg !2042
  %313 = getelementptr inbounds double, ptr %311, i64 -3, !dbg !2042
  %314 = load <2 x double>, ptr %312, align 8, !dbg !2042, !tbaa !1438
  %315 = shufflevector <2 x double> %314, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %316 = load <2 x double>, ptr %313, align 8, !dbg !2042, !tbaa !1438
  %317 = shufflevector <2 x double> %316, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %318 = fmul <2 x double> %306, %315
  %319 = fmul <2 x double> %307, %317
  %320 = tail call double @llvm.vector.reduce.fadd.v2f64(double %303, <2 x double> %318)
  %321 = tail call double @llvm.vector.reduce.fadd.v2f64(double %320, <2 x double> %319)
  %322 = add nuw i64 %302, 4, !dbg !2039
  %323 = icmp eq i64 %322, %300, !dbg !2039
  br i1 %323, label %324, label %301, !dbg !2039, !llvm.loop !2053

324:                                              ; preds = %301
  %325 = icmp eq i64 %299, 0, !dbg !2021
  br i1 %325, label %342, label %326, !dbg !2021

326:                                              ; preds = %290, %285, %324
  %327 = phi i64 [ 0, %290 ], [ 0, %285 ], [ %300, %324 ]
  %328 = phi double [ 0.000000e+00, %290 ], [ 0.000000e+00, %285 ], [ %321, %324 ]
  br label %329, !dbg !2021

329:                                              ; preds = %326, %329
  %330 = phi i64 [ %340, %329 ], [ %327, %326 ]
  %331 = phi double [ %339, %329 ], [ %328, %326 ]
  call void @llvm.dbg.value(metadata double %331, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %330, metadata !736, metadata !DIExpression()), !dbg !2009
  %332 = getelementptr inbounds double, ptr %7, i64 %330, !dbg !2040
  %333 = load double, ptr %332, align 8, !dbg !2040, !tbaa !1438
  %334 = sub i64 %288, %330, !dbg !2041
  %335 = shl i64 %334, 32, !dbg !2042
  %336 = ashr exact i64 %335, 32, !dbg !2042
  %337 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %336, !dbg !2042
  %338 = load double, ptr %337, align 8, !dbg !2042, !tbaa !1438
  %339 = tail call double @llvm.fmuladd.f64(double %333, double %338, double %331), !dbg !2047
  call void @llvm.dbg.value(metadata double %339, metadata !742, metadata !DIExpression()), !dbg !2009
  %340 = add nuw nsw i64 %330, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i64 %340, metadata !736, metadata !DIExpression()), !dbg !2009
  %341 = icmp eq i64 %340, %178, !dbg !2037
  br i1 %341, label %342, label %329, !dbg !2021, !llvm.loop !2054

342:                                              ; preds = %329, %324
  %343 = phi double [ %321, %324 ], [ %339, %329 ], !dbg !2047
  %344 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 2, !dbg !2052
  store double %343, ptr %344, align 8, !dbg !2049, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 3, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  %345 = add i64 %139, 2
  %346 = icmp ult i64 %178, 10, !dbg !2021
  br i1 %346, label %383, label %347, !dbg !2021

347:                                              ; preds = %342
  %348 = add nsw i64 %178, -1, !dbg !2021
  %349 = sub i32 5, %138, !dbg !2021
  %350 = trunc i64 %348 to i32, !dbg !2021
  %351 = sub i32 %349, %350, !dbg !2021
  %352 = icmp sgt i32 %351, %349, !dbg !2021
  %353 = icmp ugt i64 %348, 4294967295, !dbg !2021
  %354 = or i1 %352, %353, !dbg !2021
  br i1 %354, label %383, label %355

355:                                              ; preds = %347
  %356 = and i64 %139, 3, !dbg !2021
  %357 = sub nsw i64 %178, %356, !dbg !2021
  br label %358, !dbg !2021

358:                                              ; preds = %358, %355
  %359 = phi i64 [ 0, %355 ], [ %379, %358 ], !dbg !2039
  %360 = phi double [ 0.000000e+00, %355 ], [ %378, %358 ]
  %361 = getelementptr inbounds double, ptr %7, i64 %359, !dbg !2040
  %362 = getelementptr inbounds double, ptr %361, i64 2, !dbg !2040
  %363 = load <2 x double>, ptr %361, align 8, !dbg !2040, !tbaa !1438
  %364 = load <2 x double>, ptr %362, align 8, !dbg !2040, !tbaa !1438
  %365 = sub i64 %345, %359, !dbg !2041
  %366 = shl i64 %365, 32, !dbg !2042
  %367 = ashr exact i64 %366, 32, !dbg !2042
  %368 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %367, !dbg !2042
  %369 = getelementptr inbounds double, ptr %368, i64 -1, !dbg !2042
  %370 = getelementptr inbounds double, ptr %368, i64 -3, !dbg !2042
  %371 = load <2 x double>, ptr %369, align 8, !dbg !2042, !tbaa !1438
  %372 = shufflevector <2 x double> %371, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %373 = load <2 x double>, ptr %370, align 8, !dbg !2042, !tbaa !1438
  %374 = shufflevector <2 x double> %373, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %375 = fmul <2 x double> %363, %372
  %376 = fmul <2 x double> %364, %374
  %377 = tail call double @llvm.vector.reduce.fadd.v2f64(double %360, <2 x double> %375)
  %378 = tail call double @llvm.vector.reduce.fadd.v2f64(double %377, <2 x double> %376)
  %379 = add nuw i64 %359, 4, !dbg !2039
  %380 = icmp eq i64 %379, %357, !dbg !2039
  br i1 %380, label %381, label %358, !dbg !2039, !llvm.loop !2055

381:                                              ; preds = %358
  %382 = icmp eq i64 %356, 0, !dbg !2021
  br i1 %382, label %401, label %383, !dbg !2021

383:                                              ; preds = %347, %342, %381
  %384 = phi i64 [ 0, %347 ], [ 0, %342 ], [ %357, %381 ]
  %385 = phi double [ 0.000000e+00, %347 ], [ 0.000000e+00, %342 ], [ %378, %381 ]
  br label %386, !dbg !2021

386:                                              ; preds = %383, %386
  %387 = phi i64 [ %397, %386 ], [ %384, %383 ]
  %388 = phi double [ %396, %386 ], [ %385, %383 ]
  call void @llvm.dbg.value(metadata double %388, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %387, metadata !736, metadata !DIExpression()), !dbg !2009
  %389 = getelementptr inbounds double, ptr %7, i64 %387, !dbg !2040
  %390 = load double, ptr %389, align 8, !dbg !2040, !tbaa !1438
  %391 = sub i64 %345, %387, !dbg !2041
  %392 = shl i64 %391, 32, !dbg !2042
  %393 = ashr exact i64 %392, 32, !dbg !2042
  %394 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %393, !dbg !2042
  %395 = load double, ptr %394, align 8, !dbg !2042, !tbaa !1438
  %396 = tail call double @llvm.fmuladd.f64(double %390, double %395, double %388), !dbg !2047
  call void @llvm.dbg.value(metadata double %396, metadata !742, metadata !DIExpression()), !dbg !2009
  %397 = add nuw nsw i64 %387, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i64 %397, metadata !736, metadata !DIExpression()), !dbg !2009
  %398 = icmp eq i64 %397, %178, !dbg !2037
  br i1 %398, label %401, label %386, !dbg !2021, !llvm.loop !2056

399:                                              ; preds = %145, %160
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 4, metadata !735, metadata !DIExpression()), !dbg !2009
  %400 = and i64 %139, 4294967295
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(32) %6, i8 0, i64 32, i1 false), !dbg !2049
  br label %456, !dbg !2021

401:                                              ; preds = %386, %381
  %402 = phi double [ %378, %381 ], [ %396, %386 ], !dbg !2047
  %403 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 3, !dbg !2052
  store double %402, ptr %403, align 8, !dbg !2049, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 4, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  %404 = icmp ult i64 %178, 10, !dbg !2021
  br i1 %404, label %440, label %405, !dbg !2021

405:                                              ; preds = %401
  %406 = add nsw i64 %178, -1, !dbg !2021
  %407 = trunc i64 %406 to i32, !dbg !2021
  %408 = sub i32 %155, %407, !dbg !2021
  %409 = icmp sgt i32 %408, %155, !dbg !2021
  %410 = icmp ugt i64 %406, 4294967295, !dbg !2021
  %411 = or i1 %409, %410, !dbg !2021
  br i1 %411, label %440, label %412

412:                                              ; preds = %405
  %413 = and i64 %139, 3, !dbg !2021
  %414 = sub nsw i64 %178, %413, !dbg !2021
  br label %415, !dbg !2021

415:                                              ; preds = %415, %412
  %416 = phi i64 [ 0, %412 ], [ %436, %415 ], !dbg !2039
  %417 = phi double [ 0.000000e+00, %412 ], [ %435, %415 ]
  %418 = trunc i64 %416 to i32, !dbg !2021
  %419 = getelementptr inbounds double, ptr %7, i64 %416, !dbg !2040
  %420 = getelementptr inbounds double, ptr %419, i64 2, !dbg !2040
  %421 = load <2 x double>, ptr %419, align 8, !dbg !2040, !tbaa !1438
  %422 = load <2 x double>, ptr %420, align 8, !dbg !2040, !tbaa !1438
  %423 = sub i32 %155, %418, !dbg !2041
  %424 = sext i32 %423 to i64, !dbg !2042
  %425 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %424, !dbg !2042
  %426 = getelementptr inbounds double, ptr %425, i64 -1, !dbg !2042
  %427 = getelementptr inbounds double, ptr %425, i64 -3, !dbg !2042
  %428 = load <2 x double>, ptr %426, align 8, !dbg !2042, !tbaa !1438
  %429 = shufflevector <2 x double> %428, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %430 = load <2 x double>, ptr %427, align 8, !dbg !2042, !tbaa !1438
  %431 = shufflevector <2 x double> %430, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2042
  %432 = fmul <2 x double> %421, %429
  %433 = fmul <2 x double> %422, %431
  %434 = tail call double @llvm.vector.reduce.fadd.v2f64(double %417, <2 x double> %432)
  %435 = tail call double @llvm.vector.reduce.fadd.v2f64(double %434, <2 x double> %433)
  %436 = add nuw i64 %416, 4, !dbg !2039
  %437 = icmp eq i64 %436, %414, !dbg !2039
  br i1 %437, label %438, label %415, !dbg !2039, !llvm.loop !2057

438:                                              ; preds = %415
  %439 = icmp eq i64 %413, 0, !dbg !2021
  br i1 %439, label %456, label %440, !dbg !2021

440:                                              ; preds = %405, %401, %438
  %441 = phi i64 [ 0, %405 ], [ 0, %401 ], [ %414, %438 ]
  %442 = phi double [ 0.000000e+00, %405 ], [ 0.000000e+00, %401 ], [ %435, %438 ]
  br label %443, !dbg !2021

443:                                              ; preds = %440, %443
  %444 = phi i64 [ %454, %443 ], [ %441, %440 ]
  %445 = phi double [ %453, %443 ], [ %442, %440 ]
  call void @llvm.dbg.value(metadata double %445, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %444, metadata !736, metadata !DIExpression()), !dbg !2009
  %446 = getelementptr inbounds double, ptr %7, i64 %444, !dbg !2040
  %447 = load double, ptr %446, align 8, !dbg !2040, !tbaa !1438
  %448 = trunc i64 %444 to i32, !dbg !2041
  %449 = sub i32 %155, %448, !dbg !2041
  %450 = sext i32 %449 to i64, !dbg !2042
  %451 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %450, !dbg !2042
  %452 = load double, ptr %451, align 8, !dbg !2042, !tbaa !1438
  %453 = tail call double @llvm.fmuladd.f64(double %447, double %452, double %445), !dbg !2047
  call void @llvm.dbg.value(metadata double %453, metadata !742, metadata !DIExpression()), !dbg !2009
  %454 = add nuw nsw i64 %444, 1, !dbg !2039
  call void @llvm.dbg.value(metadata i64 %454, metadata !736, metadata !DIExpression()), !dbg !2009
  %455 = icmp eq i64 %454, %178, !dbg !2037
  br i1 %455, label %456, label %443, !dbg !2021, !llvm.loop !2058

456:                                              ; preds = %443, %438, %399
  %457 = phi i64 [ %400, %399 ], [ %178, %438 ], [ %178, %443 ]
  %458 = phi i1 [ false, %399 ], [ true, %438 ], [ true, %443 ]
  %459 = phi double [ 0.000000e+00, %399 ], [ %435, %438 ], [ %453, %443 ], !dbg !2059
  %460 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 4, !dbg !2052
  store double %459, ptr %460, align 8, !dbg !2049, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 5, metadata !735, metadata !DIExpression()), !dbg !2009
  %461 = icmp sgt i32 %150, 24
  %462 = icmp eq i32 %151, 0
  %463 = sub nsw i32 48, %150
  %464 = sub nsw i32 47, %150
  %465 = sext i32 %148 to i64, !dbg !2060
  %466 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 3
  %467 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 2
  %468 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 1
  %469 = getelementptr i32, ptr @__ieee754_rem_pio2.two_over_pi, i64 %465
  %470 = icmp ult i64 %457, 4
  %471 = and i64 %457, 4294967292
  %472 = icmp eq i64 %457, %471
  br label %476, !dbg !2060

473:                                              ; preds = %676
  %474 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %628
  %475 = load double, ptr %474, align 8, !dbg !2062, !tbaa !1438
  br label %476, !dbg !2063, !llvm.loop !2069

476:                                              ; preds = %473, %456
  %477 = phi double [ %459, %456 ], [ %475, %473 ], !dbg !2062
  %478 = phi i32 [ 4, %456 ], [ %627, %473 ], !dbg !2009
  call void @llvm.dbg.value(metadata i32 %478, metadata !724, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.label(metadata !747), !dbg !2071
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %478, metadata !736, metadata !DIExpression()), !dbg !2009
  %479 = zext nneg i32 %478 to i64, !dbg !2062
  call void @llvm.dbg.value(metadata double %477, metadata !741, metadata !DIExpression()), !dbg !2009
  br label %480, !dbg !2072

480:                                              ; preds = %480, %476
  %481 = phi i64 [ 0, %476 ], [ %494, %480 ]
  %482 = phi i64 [ %479, %476 ], [ %490, %480 ]
  %483 = phi double [ %477, %476 ], [ %493, %480 ]
  call void @llvm.dbg.value(metadata double %483, metadata !741, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %482, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %481, metadata !735, metadata !DIExpression()), !dbg !2009
  %484 = fmul double %483, 0x3E70000000000000, !dbg !2073
  %485 = fptosi double %484 to i32, !dbg !2076
  %486 = sitofp i32 %485 to double, !dbg !2077
  call void @llvm.dbg.value(metadata double %486, metadata !742, metadata !DIExpression()), !dbg !2009
  %487 = tail call double @llvm.fmuladd.f64(double %486, double 0xC170000000000000, double %483), !dbg !2078
  %488 = fptosi double %487 to i32, !dbg !2079
  %489 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %481, !dbg !2080
  store i32 %488, ptr %489, align 4, !dbg !2081, !tbaa !1902
  %490 = add nsw i64 %482, -1, !dbg !2082
  %491 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %490, !dbg !2083
  %492 = load double, ptr %491, align 8, !dbg !2083, !tbaa !1438
  %493 = fadd double %492, %486, !dbg !2084
  call void @llvm.dbg.value(metadata double %493, metadata !741, metadata !DIExpression()), !dbg !2009
  %494 = add nuw nsw i64 %481, 1, !dbg !2085
  call void @llvm.dbg.value(metadata i64 %490, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %494, metadata !735, metadata !DIExpression()), !dbg !2009
  %495 = icmp eq i64 %494, %479, !dbg !2086
  br i1 %495, label %496, label %480, !dbg !2072, !llvm.loop !2087

496:                                              ; preds = %480
  %497 = tail call double @scalbn(double noundef %493, i32 noundef %151) #12, !dbg !2089
  call void @llvm.dbg.value(metadata double %497, metadata !741, metadata !DIExpression()), !dbg !2009
  %498 = fmul double %497, 1.250000e-01, !dbg !2090
  %499 = tail call double @llvm.floor.f64(double %498), !dbg !2091
  %500 = tail call double @llvm.fmuladd.f64(double %499, double -8.000000e+00, double %497), !dbg !2092
  call void @llvm.dbg.value(metadata double %500, metadata !741, metadata !DIExpression()), !dbg !2009
  %501 = fptosi double %500 to i32, !dbg !2093
  call void @llvm.dbg.value(metadata i32 %501, metadata !730, metadata !DIExpression()), !dbg !2009
  %502 = sitofp i32 %501 to double, !dbg !2094
  %503 = fsub double %500, %502, !dbg !2095
  call void @llvm.dbg.value(metadata double %503, metadata !741, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !740, metadata !DIExpression()), !dbg !2009
  br i1 %461, label %504, label %514, !dbg !2096

504:                                              ; preds = %496
  %505 = add nsw i32 %478, -1, !dbg !2097
  %506 = sext i32 %505 to i64, !dbg !2100
  %507 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %506, !dbg !2100
  %508 = load i32, ptr %507, align 4, !dbg !2100, !tbaa !1902
  %509 = ashr i32 %508, %463, !dbg !2101
  call void @llvm.dbg.value(metadata i32 %509, metadata !735, metadata !DIExpression()), !dbg !2009
  %510 = add nsw i32 %509, %501, !dbg !2102
  call void @llvm.dbg.value(metadata i32 %510, metadata !730, metadata !DIExpression()), !dbg !2009
  %511 = shl i32 %509, %463, !dbg !2103
  %512 = sub nsw i32 %508, %511, !dbg !2104
  store i32 %512, ptr %507, align 4, !dbg !2104, !tbaa !1902
  %513 = ashr i32 %512, %464, !dbg !2105
  call void @llvm.dbg.value(metadata i32 %513, metadata !740, metadata !DIExpression()), !dbg !2009
  br label %523, !dbg !2106

514:                                              ; preds = %496
  br i1 %462, label %515, label %521, !dbg !2107

515:                                              ; preds = %514
  %516 = add nsw i32 %478, -1, !dbg !2108
  %517 = sext i32 %516 to i64, !dbg !2111
  %518 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %517, !dbg !2111
  %519 = load i32, ptr %518, align 4, !dbg !2111, !tbaa !1902
  %520 = ashr i32 %519, 23, !dbg !2112
  call void @llvm.dbg.value(metadata i32 %520, metadata !740, metadata !DIExpression()), !dbg !2009
  br label %523, !dbg !2113

521:                                              ; preds = %514
  %522 = fcmp ult double %503, 5.000000e-01, !dbg !2114
  br i1 %522, label %564, label %527, !dbg !2116

523:                                              ; preds = %515, %504
  %524 = phi i32 [ %510, %504 ], [ %501, %515 ], !dbg !2009
  %525 = phi i32 [ %513, %504 ], [ %520, %515 ], !dbg !2009
  call void @llvm.dbg.value(metadata i32 %525, metadata !740, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %524, metadata !730, metadata !DIExpression()), !dbg !2009
  %526 = icmp sgt i32 %525, 0, !dbg !2117
  br i1 %526, label %527, label %564, !dbg !2119

527:                                              ; preds = %523, %521
  %528 = phi i32 [ %525, %523 ], [ 2, %521 ]
  %529 = phi i32 [ %524, %523 ], [ %501, %521 ]
  call void @llvm.dbg.value(metadata i32 %547, metadata !730, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !729, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !735, metadata !DIExpression()), !dbg !2009
  br label %530, !dbg !2120

530:                                              ; preds = %541, %527
  %531 = phi i64 [ 0, %527 ], [ %544, %541 ]
  %532 = phi i32 [ 0, %527 ], [ %543, %541 ]
  call void @llvm.dbg.value(metadata i64 %531, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %532, metadata !729, metadata !DIExpression()), !dbg !2009
  %533 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %531, !dbg !2123
  %534 = load i32, ptr %533, align 4, !dbg !2123, !tbaa !1902
  call void @llvm.dbg.value(metadata i32 %534, metadata !736, metadata !DIExpression()), !dbg !2009
  %535 = icmp eq i32 %532, 0, !dbg !2126
  br i1 %535, label %536, label %538, !dbg !2128

536:                                              ; preds = %530
  %537 = icmp eq i32 %534, 0, !dbg !2129
  br i1 %537, label %541, label %538, !dbg !2132

538:                                              ; preds = %536, %530
  %539 = phi i32 [ 16777216, %536 ], [ 16777215, %530 ]
  %540 = sub nsw i32 %539, %534, !dbg !2133
  store i32 %540, ptr %533, align 4, !dbg !2133, !tbaa !1902
  br label %541, !dbg !2134

541:                                              ; preds = %538, %536
  %542 = phi i1 [ true, %536 ], [ false, %538 ], !dbg !2135
  %543 = phi i32 [ 0, %536 ], [ 1, %538 ], !dbg !2135
  call void @llvm.dbg.value(metadata i32 %543, metadata !729, metadata !DIExpression()), !dbg !2009
  %544 = add nuw nsw i64 %531, 1, !dbg !2134
  call void @llvm.dbg.value(metadata i64 %544, metadata !735, metadata !DIExpression()), !dbg !2009
  %545 = icmp eq i64 %544, %479, !dbg !2136
  br i1 %545, label %546, label %530, !dbg !2120, !llvm.loop !2137

546:                                              ; preds = %541
  %547 = add nsw i32 %529, 1, !dbg !2139
  br i1 %461, label %548, label %557, !dbg !2140

548:                                              ; preds = %546
  switch i32 %150, label %557 [
    i32 25, label %550
    i32 26, label %549
  ], !dbg !2141

549:                                              ; preds = %548
  br label %550, !dbg !2144

550:                                              ; preds = %549, %548
  %551 = phi i32 [ 4194303, %549 ], [ 8388607, %548 ]
  %552 = add nsw i32 %478, -1, !dbg !2146
  %553 = sext i32 %552 to i64, !dbg !2146
  %554 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %553, !dbg !2146
  %555 = load i32, ptr %554, align 4, !dbg !2146, !tbaa !1902
  %556 = and i32 %555, %551, !dbg !2146
  store i32 %556, ptr %554, align 4, !dbg !2146, !tbaa !1902
  br label %557, !dbg !2147

557:                                              ; preds = %550, %548, %546
  %558 = icmp eq i32 %528, 2, !dbg !2147
  br i1 %558, label %559, label %564, !dbg !2149

559:                                              ; preds = %557
  %560 = fsub double 1.000000e+00, %503, !dbg !2150
  call void @llvm.dbg.value(metadata double %560, metadata !741, metadata !DIExpression()), !dbg !2009
  br i1 %542, label %564, label %561, !dbg !2152

561:                                              ; preds = %559
  %562 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %151) #12, !dbg !2153
  %563 = fsub double %560, %562, !dbg !2155
  call void @llvm.dbg.value(metadata double %563, metadata !741, metadata !DIExpression()), !dbg !2009
  br label %564, !dbg !2156

564:                                              ; preds = %561, %559, %557, %523, %521
  %565 = phi i32 [ 2, %561 ], [ 2, %559 ], [ 2, %557 ], [ %525, %523 ], [ 0, %521 ]
  %566 = phi i32 [ %547, %561 ], [ %547, %559 ], [ %547, %557 ], [ %524, %523 ], [ %501, %521 ], !dbg !2009
  %567 = phi double [ %563, %561 ], [ %560, %559 ], [ %503, %557 ], [ %503, %523 ], [ %503, %521 ], !dbg !2009
  call void @llvm.dbg.value(metadata double %567, metadata !741, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %566, metadata !730, metadata !DIExpression()), !dbg !2009
  %568 = fcmp oeq double %567, 0.000000e+00, !dbg !2157
  br i1 %568, label %569, label %688, !dbg !2158

569:                                              ; preds = %564
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %478, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2009
  %570 = icmp ugt i32 %478, 4, !dbg !2159
  br i1 %570, label %571, label %612, !dbg !2162

571:                                              ; preds = %569
  %572 = add nsw i64 %479, -4, !dbg !2162
  %573 = icmp ult i64 %572, 8, !dbg !2162
  br i1 %573, label %598, label %574, !dbg !2162

574:                                              ; preds = %571
  %575 = and i64 %572, -8, !dbg !2162
  %576 = sub nsw i64 %479, %575, !dbg !2162
  br label %577, !dbg !2162

577:                                              ; preds = %577, %574
  %578 = phi i64 [ 0, %574 ], [ %592, %577 ]
  %579 = phi <4 x i32> [ zeroinitializer, %574 ], [ %590, %577 ]
  %580 = phi <4 x i32> [ zeroinitializer, %574 ], [ %591, %577 ]
  %581 = xor i64 %578, -1, !dbg !2163
  %582 = add i64 %581, %479, !dbg !2163
  %583 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %582, !dbg !2164
  %584 = getelementptr inbounds i32, ptr %583, i64 -3, !dbg !2164
  %585 = getelementptr inbounds i32, ptr %583, i64 -7, !dbg !2164
  %586 = load <4 x i32>, ptr %584, align 4, !dbg !2164, !tbaa !1902
  %587 = shufflevector <4 x i32> %586, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2164
  %588 = load <4 x i32>, ptr %585, align 4, !dbg !2164, !tbaa !1902
  %589 = shufflevector <4 x i32> %588, <4 x i32> poison, <4 x i32> <i32 3, i32 2, i32 1, i32 0>, !dbg !2164
  %590 = or <4 x i32> %587, %579, !dbg !2165
  %591 = or <4 x i32> %589, %580, !dbg !2165
  %592 = add nuw i64 %578, 8
  %593 = icmp eq i64 %592, %575
  br i1 %593, label %594, label %577, !llvm.loop !2166

594:                                              ; preds = %577
  %595 = or <4 x i32> %591, %590, !dbg !2162
  %596 = tail call i32 @llvm.vector.reduce.or.v4i32(<4 x i32> %595), !dbg !2162
  %597 = icmp eq i64 %572, %575, !dbg !2162
  br i1 %597, label %609, label %598, !dbg !2162

598:                                              ; preds = %571, %594
  %599 = phi i64 [ %479, %571 ], [ %576, %594 ]
  %600 = phi i32 [ 0, %571 ], [ %596, %594 ]
  br label %601, !dbg !2162

601:                                              ; preds = %598, %601
  %602 = phi i64 [ %604, %601 ], [ %599, %598 ]
  %603 = phi i32 [ %607, %601 ], [ %600, %598 ]
  call void @llvm.dbg.value(metadata i32 %603, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %602, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2009
  %604 = add nsw i64 %602, -1, !dbg !2163
  call void @llvm.dbg.value(metadata i64 %604, metadata !735, metadata !DIExpression()), !dbg !2009
  %605 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %604, !dbg !2164
  %606 = load i32, ptr %605, align 4, !dbg !2164, !tbaa !1902
  %607 = or i32 %606, %603, !dbg !2165
  call void @llvm.dbg.value(metadata i32 %607, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %604, metadata !735, metadata !DIExpression(DW_OP_constu, 1, DW_OP_minus, DW_OP_stack_value)), !dbg !2009
  %608 = icmp sgt i64 %602, 5, !dbg !2159
  br i1 %608, label %601, label %609, !dbg !2162, !llvm.loop !2168

609:                                              ; preds = %601, %594
  %610 = phi i32 [ %596, %594 ], [ %607, %601 ], !dbg !2165
  %611 = icmp eq i32 %610, 0, !dbg !2169
  br i1 %611, label %612, label %680, !dbg !2170

612:                                              ; preds = %609, %569
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2009
  %613 = load i32, ptr %466, align 4, !dbg !2171, !tbaa !1902
  %614 = icmp eq i32 %613, 0, !dbg !2174
  br i1 %614, label %615, label %625, !dbg !2175

615:                                              ; preds = %612
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2009
  %616 = load i32, ptr %467, align 4, !dbg !2171, !tbaa !1902
  %617 = icmp eq i32 %616, 0, !dbg !2174
  br i1 %617, label %618, label %625, !dbg !2175

618:                                              ; preds = %615
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2009
  %619 = load i32, ptr %468, align 4, !dbg !2171, !tbaa !1902
  %620 = icmp eq i32 %619, 0, !dbg !2174
  br i1 %620, label %621, label %625, !dbg !2175

621:                                              ; preds = %618
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2009
  %622 = load i32, ptr %3, align 4, !dbg !2171, !tbaa !1902
  %623 = icmp eq i32 %622, 0, !dbg !2174
  %624 = select i1 %623, i32 5, i32 4, !dbg !2175
  br label %625, !dbg !2175

625:                                              ; preds = %621, %618, %615, %612
  %626 = phi i32 [ 1, %612 ], [ 2, %615 ], [ 3, %618 ], [ %624, %621 ], !dbg !2176
  call void @llvm.dbg.value(metadata i32 %478, metadata !735, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2009
  %627 = add nuw nsw i32 %626, %478
  %628 = zext nneg i32 %627 to i64, !dbg !2177
  br label %629, !dbg !2063

629:                                              ; preds = %676, %625
  %630 = phi i64 [ %479, %625 ], [ %631, %676 ]
  %631 = add nuw nsw i64 %630, 1, !dbg !2179
  %632 = getelementptr i32, ptr %469, i64 %631, !dbg !2180
  %633 = load i32, ptr %632, align 4, !dbg !2180, !tbaa !1902
  %634 = sitofp i32 %633 to double, !dbg !2180
  %635 = add i64 %139, %630, !dbg !2182
  %636 = shl i64 %635, 32, !dbg !2183
  %637 = ashr exact i64 %636, 32, !dbg !2183
  %638 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %637, !dbg !2183
  store double %634, ptr %638, align 8, !dbg !2184, !tbaa !1438
  call void @llvm.dbg.value(metadata i32 0, metadata !736, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  br i1 %458, label %639, label %676, !dbg !2185

639:                                              ; preds = %629
  br i1 %470, label %662, label %640, !dbg !2185

640:                                              ; preds = %639, %640
  %641 = phi i64 [ %659, %640 ], [ 0, %639 ], !dbg !2187
  %642 = phi double [ %658, %640 ], [ 0.000000e+00, %639 ]
  %643 = getelementptr inbounds double, ptr %7, i64 %641, !dbg !2189
  %644 = getelementptr inbounds double, ptr %643, i64 2, !dbg !2189
  %645 = load <2 x double>, ptr %643, align 8, !dbg !2189, !tbaa !1438
  %646 = load <2 x double>, ptr %644, align 8, !dbg !2189, !tbaa !1438
  %647 = sub nsw i64 %637, %641, !dbg !2190
  %648 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %647, !dbg !2191
  %649 = getelementptr inbounds double, ptr %648, i64 -1, !dbg !2191
  %650 = getelementptr inbounds double, ptr %648, i64 -3, !dbg !2191
  %651 = load <2 x double>, ptr %649, align 8, !dbg !2191, !tbaa !1438
  %652 = shufflevector <2 x double> %651, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2191
  %653 = load <2 x double>, ptr %650, align 8, !dbg !2191, !tbaa !1438
  %654 = shufflevector <2 x double> %653, <2 x double> poison, <2 x i32> <i32 1, i32 0>, !dbg !2191
  %655 = fmul <2 x double> %645, %652
  %656 = fmul <2 x double> %646, %654
  %657 = tail call double @llvm.vector.reduce.fadd.v2f64(double %642, <2 x double> %655)
  %658 = tail call double @llvm.vector.reduce.fadd.v2f64(double %657, <2 x double> %656)
  %659 = add nuw i64 %641, 4, !dbg !2187
  %660 = icmp eq i64 %659, %471, !dbg !2187
  br i1 %660, label %661, label %640, !dbg !2187, !llvm.loop !2192

661:                                              ; preds = %640
  br i1 %472, label %676, label %662, !dbg !2185

662:                                              ; preds = %639, %661
  %663 = phi i64 [ 0, %639 ], [ %471, %661 ]
  %664 = phi double [ 0.000000e+00, %639 ], [ %658, %661 ]
  br label %665, !dbg !2185

665:                                              ; preds = %662, %665
  %666 = phi i64 [ %674, %665 ], [ %663, %662 ]
  %667 = phi double [ %673, %665 ], [ %664, %662 ]
  call void @llvm.dbg.value(metadata double %667, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %666, metadata !736, metadata !DIExpression()), !dbg !2009
  %668 = getelementptr inbounds double, ptr %7, i64 %666, !dbg !2189
  %669 = load double, ptr %668, align 8, !dbg !2189, !tbaa !1438
  %670 = sub nsw i64 %637, %666, !dbg !2190
  %671 = getelementptr inbounds [20 x double], ptr %4, i64 0, i64 %670, !dbg !2191
  %672 = load double, ptr %671, align 8, !dbg !2191, !tbaa !1438
  %673 = tail call double @llvm.fmuladd.f64(double %669, double %672, double %667), !dbg !2194
  call void @llvm.dbg.value(metadata double %673, metadata !742, metadata !DIExpression()), !dbg !2009
  %674 = add nuw nsw i64 %666, 1, !dbg !2187
  call void @llvm.dbg.value(metadata i64 %674, metadata !736, metadata !DIExpression()), !dbg !2009
  %675 = icmp eq i64 %674, %457, !dbg !2195
  br i1 %675, label %676, label %665, !dbg !2185, !llvm.loop !2196

676:                                              ; preds = %665, %661, %629
  %677 = phi double [ 0.000000e+00, %629 ], [ %658, %661 ], [ %673, %665 ], !dbg !2197
  %678 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %631, !dbg !2198
  store double %677, ptr %678, align 8, !dbg !2199, !tbaa !1438
  call void @llvm.dbg.value(metadata i64 %631, metadata !735, metadata !DIExpression(DW_OP_plus_uconst, 1, DW_OP_stack_value)), !dbg !2009
  %679 = icmp ult i64 %631, %628, !dbg !2177
  br i1 %679, label %629, label %473, !dbg !2063, !llvm.loop !2200

680:                                              ; preds = %609, %680
  %681 = phi i64 [ %684, %680 ], [ %479, %609 ]
  %682 = phi i32 [ %683, %680 ], [ %151, %609 ]
  %683 = add nsw i32 %682, -24, !dbg !2201
  %684 = add nsw i64 %681, -1, !dbg !2201
  call void @llvm.dbg.value(metadata i32 %683, metadata !739, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %684, metadata !724, metadata !DIExpression()), !dbg !2009
  %685 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %684, !dbg !2204
  %686 = load i32, ptr %685, align 4, !dbg !2204, !tbaa !1902
  %687 = icmp eq i32 %686, 0, !dbg !2205
  br i1 %687, label %680, label %705, !dbg !2206, !llvm.loop !2207

688:                                              ; preds = %564
  %689 = sub nsw i32 24, %150, !dbg !2209
  %690 = tail call double @scalbn(double noundef %567, i32 noundef %689) #12, !dbg !2211
  call void @llvm.dbg.value(metadata double %690, metadata !741, metadata !DIExpression()), !dbg !2009
  %691 = fcmp ult double %690, 0x4170000000000000, !dbg !2212
  br i1 %691, label %702, label %692, !dbg !2214

692:                                              ; preds = %688
  %693 = fmul double %690, 0x3E70000000000000, !dbg !2215
  %694 = fptosi double %693 to i32, !dbg !2217
  %695 = sitofp i32 %694 to double, !dbg !2218
  call void @llvm.dbg.value(metadata double %695, metadata !742, metadata !DIExpression()), !dbg !2009
  %696 = tail call double @llvm.fmuladd.f64(double %695, double 0xC170000000000000, double %690), !dbg !2219
  %697 = fptosi double %696 to i32, !dbg !2220
  %698 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %479, !dbg !2221
  store i32 %697, ptr %698, align 4, !dbg !2222, !tbaa !1902
  %699 = add nuw nsw i32 %478, 1, !dbg !2223
  call void @llvm.dbg.value(metadata i32 %699, metadata !724, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %150, metadata !739, metadata !DIExpression()), !dbg !2009
  %700 = zext nneg i32 %699 to i64, !dbg !2224
  %701 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %700, !dbg !2224
  store i32 %694, ptr %701, align 4, !dbg !2225, !tbaa !1902
  br label %707, !dbg !2226

702:                                              ; preds = %688
  %703 = fptosi double %690 to i32, !dbg !2227
  %704 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %479, !dbg !2229
  store i32 %703, ptr %704, align 4, !dbg !2230, !tbaa !1902
  br label %707

705:                                              ; preds = %680
  %706 = trunc i64 %684 to i32, !dbg !2231
  br label %707, !dbg !2231

707:                                              ; preds = %705, %702, %692
  %708 = phi i32 [ %699, %692 ], [ %478, %702 ], [ %706, %705 ], !dbg !2009
  %709 = phi i32 [ %150, %692 ], [ %151, %702 ], [ %683, %705 ], !dbg !2009
  call void @llvm.dbg.value(metadata i32 %709, metadata !739, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %708, metadata !724, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double poison, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 %708, metadata !735, metadata !DIExpression()), !dbg !2009
  %710 = icmp sgt i32 %708, -1, !dbg !2232
  br i1 %710, label %714, label %711, !dbg !2235

711:                                              ; preds = %707
  %712 = icmp eq i32 %565, 0, !dbg !2236
  %713 = select i1 %712, double 0.000000e+00, double -0.000000e+00, !dbg !2238
  store double %713, ptr %1, align 8, !dbg !2239, !tbaa !1438
  call void @llvm.dbg.value(metadata double undef, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 1, metadata !735, metadata !DIExpression()), !dbg !2009
  br label %840, !dbg !2240

714:                                              ; preds = %707
  %715 = tail call double @scalbn(double noundef 1.000000e+00, i32 noundef %709) #12, !dbg !2231
  call void @llvm.dbg.value(metadata double %715, metadata !742, metadata !DIExpression()), !dbg !2009
  %716 = zext nneg i32 %708 to i64, !dbg !2235
  br label %717, !dbg !2235

717:                                              ; preds = %717, %714
  %718 = phi i64 [ %716, %714 ], [ %726, %717 ]
  %719 = phi double [ %715, %714 ], [ %725, %717 ]
  call void @llvm.dbg.value(metadata double %719, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %718, metadata !735, metadata !DIExpression()), !dbg !2009
  %720 = getelementptr inbounds [20 x i32], ptr %3, i64 0, i64 %718, !dbg !2242
  %721 = load i32, ptr %720, align 4, !dbg !2242, !tbaa !1902
  %722 = sitofp i32 %721 to double, !dbg !2242
  %723 = fmul double %719, %722, !dbg !2244
  %724 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %718, !dbg !2245
  store double %723, ptr %724, align 8, !dbg !2246, !tbaa !1438
  %725 = fmul double %719, 0x3E70000000000000, !dbg !2247
  call void @llvm.dbg.value(metadata double %725, metadata !742, metadata !DIExpression()), !dbg !2009
  %726 = add nsw i64 %718, -1, !dbg !2248
  call void @llvm.dbg.value(metadata i64 %726, metadata !735, metadata !DIExpression()), !dbg !2009
  %727 = icmp eq i64 %718, 0, !dbg !2232
  br i1 %727, label %728, label %717, !dbg !2235, !llvm.loop !2249

728:                                              ; preds = %717, %760
  %729 = phi i64 [ %764, %760 ], [ %716, %717 ]
  %730 = phi i32 [ %765, %760 ], [ 0, %717 ]
  call void @llvm.dbg.value(metadata i64 %729, metadata !735, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 0, metadata !737, metadata !DIExpression()), !dbg !2009
  %731 = tail call i32 @llvm.umin.i32(i32 %730, i32 4)
  %732 = add nuw nsw i32 %731, 1
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 0, metadata !737, metadata !DIExpression()), !dbg !2009
  %733 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %729, !dbg !2251
  %734 = load double, ptr %733, align 8, !dbg !2251, !tbaa !1438
  %735 = tail call double @llvm.fmuladd.f64(double %734, double 0x3FF921FB40000000, double 0.000000e+00), !dbg !2257
  call void @llvm.dbg.value(metadata double %735, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2009
  %736 = icmp eq i32 %730, 0, !dbg !2258
  br i1 %736, label %760, label %737, !dbg !2258, !llvm.loop !2259

737:                                              ; preds = %728
  call void @llvm.dbg.value(metadata double %735, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 1, metadata !737, metadata !DIExpression()), !dbg !2009
  %738 = add nuw nsw i64 %729, 1, !dbg !2262
  %739 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %738, !dbg !2251
  %740 = load double, ptr %739, align 8, !dbg !2251, !tbaa !1438
  %741 = tail call double @llvm.fmuladd.f64(double %740, double 0x3E74442D00000000, double %735), !dbg !2257
  call void @llvm.dbg.value(metadata double %741, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2009
  %742 = icmp eq i32 %732, 2, !dbg !2258
  br i1 %742, label %760, label %743, !dbg !2258, !llvm.loop !2259

743:                                              ; preds = %737
  call void @llvm.dbg.value(metadata double %741, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 2, metadata !737, metadata !DIExpression()), !dbg !2009
  %744 = add nuw nsw i64 %729, 2, !dbg !2262
  %745 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %744, !dbg !2251
  %746 = load double, ptr %745, align 8, !dbg !2251, !tbaa !1438
  %747 = tail call double @llvm.fmuladd.f64(double %746, double 0x3CF8469880000000, double %741), !dbg !2257
  call void @llvm.dbg.value(metadata double %747, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2009
  %748 = icmp eq i32 %732, 3, !dbg !2258
  br i1 %748, label %760, label %749, !dbg !2258, !llvm.loop !2259

749:                                              ; preds = %743
  call void @llvm.dbg.value(metadata double %747, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 3, metadata !737, metadata !DIExpression()), !dbg !2009
  %750 = add nuw nsw i64 %729, 3, !dbg !2262
  %751 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %750, !dbg !2251
  %752 = load double, ptr %751, align 8, !dbg !2251, !tbaa !1438
  %753 = tail call double @llvm.fmuladd.f64(double %752, double 0x3B78CC5160000000, double %747), !dbg !2257
  call void @llvm.dbg.value(metadata double %753, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2009
  %754 = icmp eq i32 %732, 4, !dbg !2258
  br i1 %754, label %760, label %755, !dbg !2258, !llvm.loop !2259

755:                                              ; preds = %749
  call void @llvm.dbg.value(metadata double %753, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 4, metadata !737, metadata !DIExpression()), !dbg !2009
  %756 = add nuw nsw i64 %729, 4, !dbg !2262
  %757 = getelementptr inbounds [20 x double], ptr %6, i64 0, i64 %756, !dbg !2251
  %758 = load double, ptr %757, align 8, !dbg !2251, !tbaa !1438
  %759 = tail call double @llvm.fmuladd.f64(double %758, double 0x39F01B8380000000, double %753), !dbg !2257
  call void @llvm.dbg.value(metadata double %759, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 5, metadata !737, metadata !DIExpression()), !dbg !2009
  br label %760

760:                                              ; preds = %755, %749, %743, %737, %728
  %761 = phi double [ %735, %728 ], [ %741, %737 ], [ %747, %743 ], [ %753, %749 ], [ %759, %755 ], !dbg !2257
  %762 = sub nuw nsw i64 %716, %729
  %763 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %762, !dbg !2263
  store double %761, ptr %763, align 8, !dbg !2264, !tbaa !1438
  %764 = add nsw i64 %729, -1, !dbg !2265
  call void @llvm.dbg.value(metadata i64 %764, metadata !735, metadata !DIExpression()), !dbg !2009
  %765 = add nuw i32 %730, 1, !dbg !2266
  %766 = icmp eq i32 %730, %708, !dbg !2267
  br i1 %766, label %767, label %728, !dbg !2266, !llvm.loop !2268

767:                                              ; preds = %760
  %768 = add nuw nsw i64 %716, 1, !dbg !2270
  %769 = icmp eq i32 %708, 0, !dbg !2270
  br i1 %769, label %788, label %770, !dbg !2270

770:                                              ; preds = %767
  %771 = and i64 %768, 4294967294, !dbg !2270
  %772 = sub nsw i64 %716, %771, !dbg !2270
  br label %773, !dbg !2270

773:                                              ; preds = %773, %770
  %774 = phi i64 [ 0, %770 ], [ %784, %773 ]
  %775 = phi double [ 0.000000e+00, %770 ], [ %783, %773 ]
  %776 = sub i64 %716, %774, !dbg !2270
  %777 = add i64 %776, -1, !dbg !2270
  %778 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %776, !dbg !2272
  %779 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %777, !dbg !2272
  %780 = load double, ptr %778, align 8, !dbg !2272, !tbaa !1438
  %781 = load double, ptr %779, align 8, !dbg !2272, !tbaa !1438
  %782 = fadd double %775, %780, !dbg !2272
  %783 = fadd double %782, %781, !dbg !2272
  %784 = add nuw i64 %774, 2
  %785 = icmp eq i64 %784, %771
  br i1 %785, label %786, label %773, !llvm.loop !2274

786:                                              ; preds = %773
  %787 = icmp eq i64 %768, %771, !dbg !2270
  br i1 %787, label %799, label %788, !dbg !2270

788:                                              ; preds = %767, %786
  %789 = phi i64 [ %716, %767 ], [ %772, %786 ]
  %790 = phi double [ 0.000000e+00, %767 ], [ %783, %786 ]
  br label %791, !dbg !2270

791:                                              ; preds = %788, %791
  %792 = phi i64 [ %797, %791 ], [ %789, %788 ]
  %793 = phi double [ %796, %791 ], [ %790, %788 ]
  call void @llvm.dbg.value(metadata double %793, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %792, metadata !735, metadata !DIExpression()), !dbg !2009
  %794 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %792, !dbg !2272
  %795 = load double, ptr %794, align 8, !dbg !2272, !tbaa !1438
  %796 = fadd double %793, %795, !dbg !2276
  call void @llvm.dbg.value(metadata double %796, metadata !742, metadata !DIExpression()), !dbg !2009
  %797 = add nsw i64 %792, -1, !dbg !2277
  call void @llvm.dbg.value(metadata i64 %797, metadata !735, metadata !DIExpression()), !dbg !2009
  %798 = icmp eq i64 %792, 0, !dbg !2278
  br i1 %798, label %799, label %791, !dbg !2270, !llvm.loop !2279

799:                                              ; preds = %791, %786
  %800 = phi double [ %783, %786 ], [ %796, %791 ], !dbg !2276
  %801 = load double, ptr %5, align 8, !dbg !2280, !tbaa !1438
  %802 = icmp eq i32 %565, 0, !dbg !2236
  %803 = fneg double %800, !dbg !2238
  %804 = select i1 %802, double %800, double %803, !dbg !2238
  store double %804, ptr %1, align 8, !dbg !2239, !tbaa !1438
  %805 = fsub double %801, %800, !dbg !2281
  call void @llvm.dbg.value(metadata double %805, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i32 1, metadata !735, metadata !DIExpression()), !dbg !2009
  %806 = icmp eq i32 %708, 0, !dbg !2282
  br i1 %806, label %840, label %807, !dbg !2240

807:                                              ; preds = %799
  %808 = add nuw i32 %708, 1, !dbg !2240
  %809 = zext i32 %808 to i64, !dbg !2282
  %810 = add nsw i64 %809, -1, !dbg !2240
  %811 = icmp ult i32 %708, 4, !dbg !2240
  br i1 %811, label %829, label %812, !dbg !2240

812:                                              ; preds = %807
  %813 = and i64 %810, -4, !dbg !2240
  %814 = or disjoint i64 %813, 1, !dbg !2240
  br label %815, !dbg !2240

815:                                              ; preds = %815, %812
  %816 = phi i64 [ 0, %812 ], [ %825, %815 ]
  %817 = phi double [ %805, %812 ], [ %824, %815 ]
  %818 = or disjoint i64 %816, 1, !dbg !2240
  %819 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %818, !dbg !2284
  %820 = getelementptr inbounds double, ptr %819, i64 2, !dbg !2284
  %821 = load <2 x double>, ptr %819, align 8, !dbg !2284, !tbaa !1438
  %822 = load <2 x double>, ptr %820, align 8, !dbg !2284, !tbaa !1438
  %823 = tail call double @llvm.vector.reduce.fadd.v2f64(double %817, <2 x double> %821), !dbg !2284
  %824 = tail call double @llvm.vector.reduce.fadd.v2f64(double %823, <2 x double> %822), !dbg !2284
  %825 = add nuw i64 %816, 4
  %826 = icmp eq i64 %825, %813
  br i1 %826, label %827, label %815, !llvm.loop !2285

827:                                              ; preds = %815
  %828 = icmp eq i64 %810, %813, !dbg !2240
  br i1 %828, label %840, label %829, !dbg !2240

829:                                              ; preds = %807, %827
  %830 = phi i64 [ 1, %807 ], [ %814, %827 ]
  %831 = phi double [ %805, %807 ], [ %824, %827 ]
  br label %832, !dbg !2240

832:                                              ; preds = %829, %832
  %833 = phi i64 [ %838, %832 ], [ %830, %829 ]
  %834 = phi double [ %837, %832 ], [ %831, %829 ]
  call void @llvm.dbg.value(metadata double %834, metadata !742, metadata !DIExpression()), !dbg !2009
  call void @llvm.dbg.value(metadata i64 %833, metadata !735, metadata !DIExpression()), !dbg !2009
  %835 = getelementptr inbounds [20 x double], ptr %5, i64 0, i64 %833, !dbg !2284
  %836 = load double, ptr %835, align 8, !dbg !2284, !tbaa !1438
  %837 = fadd double %834, %836, !dbg !2287
  call void @llvm.dbg.value(metadata double %837, metadata !742, metadata !DIExpression()), !dbg !2009
  %838 = add nuw nsw i64 %833, 1, !dbg !2288
  call void @llvm.dbg.value(metadata i64 %838, metadata !735, metadata !DIExpression()), !dbg !2009
  %839 = icmp eq i64 %838, %809, !dbg !2282
  br i1 %839, label %840, label %832, !dbg !2240, !llvm.loop !2289

840:                                              ; preds = %832, %827, %711, %799
  %841 = phi double [ %804, %799 ], [ %713, %711 ], [ %804, %827 ], [ %804, %832 ]
  %842 = phi i1 [ %802, %799 ], [ %712, %711 ], [ %802, %827 ], [ %802, %832 ]
  %843 = phi double [ %805, %799 ], [ undef, %711 ], [ %824, %827 ], [ %837, %832 ], !dbg !2290
  %844 = fneg double %843, !dbg !2291
  %845 = select i1 %842, double %843, double %844, !dbg !2291
  %846 = getelementptr inbounds double, ptr %1, i64 1, !dbg !2292
  store double %845, ptr %846, align 8, !dbg !2293, !tbaa !1438
  %847 = and i32 %566, 7, !dbg !2294
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %6) #11, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %5) #11, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 160, ptr nonnull %4) #11, !dbg !2295
  call void @llvm.lifetime.end.p0(i64 80, ptr nonnull %3) #11, !dbg !2295
  tail call void @llvm.dbg.value(metadata i32 %847, metadata !659, metadata !DIExpression()), !dbg !1826
  %848 = icmp slt i64 %8, 0, !dbg !2296
  br i1 %848, label %849, label %853, !dbg !2298

849:                                              ; preds = %840
  %850 = fneg double %841, !dbg !2299
  store double %850, ptr %1, align 8, !dbg !2301, !tbaa !1438
  %851 = fneg double %845, !dbg !2302
  store double %851, ptr %846, align 8, !dbg !2303, !tbaa !1438
  %852 = sub nsw i32 0, %847, !dbg !2304
  br label %853, !dbg !2305

853:                                              ; preds = %840, %100, %35, %40, %22, %27, %849, %114, %108, %13
  %854 = phi i32 [ 0, %13 ], [ %111, %108 ], [ 0, %114 ], [ %852, %849 ], [ 1, %27 ], [ 1, %22 ], [ -1, %40 ], [ -1, %35 ], [ %51, %100 ], [ %847, %840 ], !dbg !1826
  call void @llvm.lifetime.end.p0(i64 24, ptr nonnull %7) #11, !dbg !2306
  ret i32 %854, !dbg !2306
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_exp(double noundef %0) local_unnamed_addr #4 !dbg !201 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !203, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !205, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !206, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2308
  %2 = bitcast double %0 to i64, !dbg !2310
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2308
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !213, metadata !DIExpression()), !dbg !2311
  %3 = lshr i64 %2, 32, !dbg !2312
  %4 = trunc i64 %3 to i32, !dbg !2312
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !212, metadata !DIExpression()), !dbg !2307
  %5 = lshr i32 %4, 31, !dbg !2313
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !211, metadata !DIExpression()), !dbg !2307
  %6 = and i32 %4, 2147483647, !dbg !2314
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !212, metadata !DIExpression()), !dbg !2307
  %7 = icmp ugt i32 %6, 1082535489, !dbg !2315
  br i1 %7, label %8, label %31, !dbg !2316

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 2146435071, !dbg !2317
  br i1 %9, label %10, label %19, !dbg !2318

10:                                               ; preds = %8
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2319
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2319
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !220, metadata !DIExpression()), !dbg !2321
  %11 = trunc i64 %2 to i32, !dbg !2322
  tail call void @llvm.dbg.value(metadata i32 %11, metadata !215, metadata !DIExpression()), !dbg !2323
  %12 = and i32 %4, 1048575, !dbg !2324
  %13 = or i32 %12, %11, !dbg !2326
  %14 = icmp eq i32 %13, 0, !dbg !2327
  %15 = fadd double %0, %0, !dbg !2328
  %16 = icmp sgt i64 %2, -1, !dbg !2328
  %17 = select i1 %16, double %0, double 0.000000e+00, !dbg !2328
  %18 = select i1 %14, double %17, double %15, !dbg !2328
  br label %116

19:                                               ; preds = %8
  %20 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2329
  br i1 %20, label %21, label %25, !dbg !2331

21:                                               ; preds = %19
  %22 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2332, !tbaa !1438
  %23 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2333, !tbaa !1438
  %24 = fmul double %22, %23, !dbg !2334
  br label %116, !dbg !2335

25:                                               ; preds = %19
  %26 = fcmp olt double %0, 0xC0874910D52D3051, !dbg !2336
  br i1 %26, label %27, label %58, !dbg !2338

27:                                               ; preds = %25
  %28 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2339, !tbaa !1438
  %29 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2340, !tbaa !1438
  %30 = fmul double %28, %29, !dbg !2341
  br label %116, !dbg !2342

31:                                               ; preds = %1
  %32 = icmp ugt i32 %6, 1071001154, !dbg !2343
  br i1 %32, label %33, label %48, !dbg !2345

33:                                               ; preds = %31
  %34 = icmp ult i32 %6, 1072734898, !dbg !2346
  br i1 %34, label %35, label %58, !dbg !2349

35:                                               ; preds = %33
  %36 = fcmp oeq double %0, 1.000000e+00, !dbg !2350
  br i1 %36, label %116, label %37, !dbg !2353

37:                                               ; preds = %35
  %38 = zext nneg i32 %5 to i64
  %39 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2HI, i64 0, i64 %38, !dbg !2354
  %40 = load double, ptr %39, align 8, !dbg !2354, !tbaa !1438
  %41 = fsub double %0, %40, !dbg !2355
  tail call void @llvm.dbg.value(metadata double %41, metadata !205, metadata !DIExpression()), !dbg !2307
  %42 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.ln2LO, i64 0, i64 %38, !dbg !2356
  %43 = load double, ptr %42, align 8, !dbg !2356, !tbaa !1438
  tail call void @llvm.dbg.value(metadata double %43, metadata !206, metadata !DIExpression()), !dbg !2307
  %44 = xor i32 %5, 1, !dbg !2357
  %45 = sub nsw i32 %44, %5, !dbg !2358
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !210, metadata !DIExpression()), !dbg !2307
  %46 = fsub double %41, %43, !dbg !2359
  tail call void @llvm.dbg.value(metadata double %46, metadata !203, metadata !DIExpression()), !dbg !2307
  %47 = fmul double %46, %46, !dbg !2360
  tail call void @llvm.dbg.value(metadata double %47, metadata !208, metadata !DIExpression()), !dbg !2307
  br label %72, !dbg !2361

48:                                               ; preds = %31
  %49 = icmp ult i32 %6, 1043333120, !dbg !2362
  br i1 %49, label %50, label %56, !dbg !2364

50:                                               ; preds = %48
  %51 = load volatile double, ptr @pts_ieee754_exp.huge, align 8, !dbg !2365, !tbaa !1438
  %52 = fadd double %51, %0, !dbg !2368
  %53 = fcmp ogt double %52, 1.000000e+00, !dbg !2369
  br i1 %53, label %54, label %56, !dbg !2370

54:                                               ; preds = %50
  %55 = fadd double %0, 1.000000e+00, !dbg !2371
  br label %116, !dbg !2372

56:                                               ; preds = %50, %48
  tail call void @llvm.dbg.value(metadata double %0, metadata !203, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !205, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !206, metadata !DIExpression()), !dbg !2307
  tail call void @llvm.dbg.value(metadata i32 0, metadata !210, metadata !DIExpression()), !dbg !2307
  %57 = fmul double %0, %0, !dbg !2360
  tail call void @llvm.dbg.value(metadata double %57, metadata !208, metadata !DIExpression()), !dbg !2307
  br label %72, !dbg !2361

58:                                               ; preds = %25, %33
  %59 = zext nneg i32 %5 to i64
  %60 = getelementptr inbounds [2 x double], ptr @pts_ieee754_exp.halF, i64 0, i64 %59, !dbg !2373
  %61 = load double, ptr %60, align 8, !dbg !2373, !tbaa !1438
  %62 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %61), !dbg !2375
  %63 = fptosi double %62 to i32, !dbg !2376
  tail call void @llvm.dbg.value(metadata i32 %63, metadata !210, metadata !DIExpression()), !dbg !2307
  %64 = sitofp i32 %63 to double, !dbg !2377
  tail call void @llvm.dbg.value(metadata double %64, metadata !208, metadata !DIExpression()), !dbg !2307
  %65 = fneg double %64, !dbg !2378
  %66 = tail call double @llvm.fmuladd.f64(double %65, double 0x3FE62E42FEE00000, double %0), !dbg !2378
  tail call void @llvm.dbg.value(metadata double %66, metadata !205, metadata !DIExpression()), !dbg !2307
  %67 = fmul double %64, 0x3DEA39EF35793C76, !dbg !2379
  tail call void @llvm.dbg.value(metadata double %67, metadata !206, metadata !DIExpression()), !dbg !2307
  %68 = fsub double %66, %67, !dbg !2359
  tail call void @llvm.dbg.value(metadata double %68, metadata !203, metadata !DIExpression()), !dbg !2307
  %69 = fmul double %68, %68, !dbg !2360
  tail call void @llvm.dbg.value(metadata double %69, metadata !208, metadata !DIExpression()), !dbg !2307
  %70 = icmp sgt i32 %63, -1022, !dbg !2380
  %71 = select i1 %70, i32 1072693248, i32 2121269248, !dbg !2361
  br label %72, !dbg !2361

72:                                               ; preds = %58, %56, %37
  %73 = phi i32 [ 0, %56 ], [ %45, %37 ], [ %63, %58 ]
  %74 = phi i32 [ 1072693248, %56 ], [ 1072693248, %37 ], [ %71, %58 ]
  %75 = phi i1 [ true, %56 ], [ true, %37 ], [ %70, %58 ]
  %76 = phi double [ %57, %56 ], [ %47, %37 ], [ %69, %58 ]
  %77 = phi double [ %0, %56 ], [ %46, %37 ], [ %68, %58 ]
  %78 = phi double [ 0.000000e+00, %56 ], [ %41, %37 ], [ %66, %58 ]
  %79 = phi double [ 0.000000e+00, %56 ], [ %43, %37 ], [ %67, %58 ]
  %80 = shl i32 %73, 20, !dbg !2381
  %81 = add i32 %80, %74, !dbg !2381
  %82 = zext i32 %81 to i64, !dbg !2381
  %83 = shl nuw i64 %82, 32, !dbg !2381
  %84 = bitcast i64 %83 to double, !dbg !2381
  tail call void @llvm.dbg.value(metadata double %84, metadata !209, metadata !DIExpression()), !dbg !2307
  %85 = tail call double @llvm.fmuladd.f64(double %76, double 0x3E66376972BEA4D0, double 0xBEBBBD41C5D26BF1), !dbg !2382
  %86 = tail call double @llvm.fmuladd.f64(double %76, double %85, double 0x3F11566AAF25DE2C), !dbg !2383
  %87 = tail call double @llvm.fmuladd.f64(double %76, double %86, double 0xBF66C16C16BEBD93), !dbg !2384
  %88 = tail call double @llvm.fmuladd.f64(double %76, double %87, double 0x3FC555555555553E), !dbg !2385
  %89 = fneg double %76, !dbg !2386
  %90 = tail call double @llvm.fmuladd.f64(double %89, double %88, double %77), !dbg !2386
  tail call void @llvm.dbg.value(metadata double %90, metadata !207, metadata !DIExpression()), !dbg !2307
  %91 = icmp eq i32 %73, 0, !dbg !2387
  %92 = fmul double %77, %90, !dbg !2389
  br i1 %91, label %93, label %98, !dbg !2390

93:                                               ; preds = %72
  %94 = fadd double %90, -2.000000e+00, !dbg !2391
  %95 = fdiv double %92, %94, !dbg !2393
  %96 = fsub double %77, %95, !dbg !2394
  %97 = fadd double %96, 1.000000e+00, !dbg !2394
  br label %116, !dbg !2395

98:                                               ; preds = %72
  %99 = fsub double 2.000000e+00, %90, !dbg !2396
  %100 = fdiv double %92, %99, !dbg !2398
  %101 = fsub double %79, %100, !dbg !2399
  %102 = fsub double %78, %101, !dbg !2400
  %103 = fadd double %102, 1.000000e+00, !dbg !2400
  tail call void @llvm.dbg.value(metadata double %103, metadata !204, metadata !DIExpression()), !dbg !2307
  br i1 %75, label %104, label %112, !dbg !2401

104:                                              ; preds = %98
  %105 = icmp eq i32 %73, 1024, !dbg !2402
  br i1 %105, label %106, label %110, !dbg !2406

106:                                              ; preds = %104
  %107 = fmul double %103, 2.000000e+00, !dbg !2407
  %108 = load volatile double, ptr @pts_ieee754_exp.two1023, align 8, !dbg !2408, !tbaa !1438
  %109 = fmul double %107, %108, !dbg !2409
  br label %116, !dbg !2410

110:                                              ; preds = %104
  %111 = fmul double %103, %84, !dbg !2411
  br label %116, !dbg !2412

112:                                              ; preds = %98
  %113 = fmul double %103, %84, !dbg !2413
  %114 = load volatile double, ptr @pts_ieee754_exp.twom1000, align 8, !dbg !2415, !tbaa !1438
  %115 = fmul double %113, %114, !dbg !2416
  br label %116, !dbg !2417

116:                                              ; preds = %35, %112, %110, %106, %93, %54, %27, %21, %10
  %117 = phi double [ %18, %10 ], [ %24, %21 ], [ %30, %27 ], [ %97, %93 ], [ %109, %106 ], [ %111, %110 ], [ %115, %112 ], [ %55, %54 ], [ 0x4005BF0A8B145769, %35 ], !dbg !2307
  ret double %117, !dbg !2418
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_atanh(double noundef %0) local_unnamed_addr #0 !dbg !264 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !266, metadata !DIExpression()), !dbg !2419
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2420
  %2 = bitcast double %0 to i64, !dbg !2422
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2420
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !271, metadata !DIExpression()), !dbg !2423
  %3 = lshr i64 %2, 32, !dbg !2424
  %4 = trunc i64 %3 to i32, !dbg !2424
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !268, metadata !DIExpression()), !dbg !2419
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !270, metadata !DIExpression(DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2419
  %5 = and i32 %4, 2147483647, !dbg !2425
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !269, metadata !DIExpression()), !dbg !2419
  %6 = and i64 %2, 4294967295, !dbg !2426
  %7 = icmp ne i64 %6, 0, !dbg !2426
  %8 = zext i1 %7 to i32, !dbg !2426
  %9 = or i32 %5, %8, !dbg !2428
  %10 = icmp ugt i32 %9, 1072693248, !dbg !2429
  br i1 %10, label %40, label %11, !dbg !2430

11:                                               ; preds = %1
  %12 = icmp eq i32 %5, 1072693248, !dbg !2431
  br i1 %12, label %13, label %16, !dbg !2433

13:                                               ; preds = %11
  %14 = fcmp ogt double %0, 0.000000e+00, !dbg !2434
  %15 = select i1 %14, double 0x7FF0000000000000, double 0xFFF0000000000000, !dbg !2436
  br label %40, !dbg !2437

16:                                               ; preds = %11
  %17 = icmp ult i32 %5, 1043333120, !dbg !2438
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 0.000000e+00
  %20 = and i1 %19, %17, !dbg !2440
  br i1 %20, label %40, label %21, !dbg !2440

21:                                               ; preds = %16
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2441
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2441
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !273, metadata !DIExpression()), !dbg !2443
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !273, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2443
  %22 = tail call double @llvm.fabs.f64(double %0), !dbg !2444
  tail call void @llvm.dbg.value(metadata double %22, metadata !273, metadata !DIExpression()), !dbg !2443
  tail call void @llvm.dbg.value(metadata double %22, metadata !266, metadata !DIExpression()), !dbg !2419
  %23 = icmp ult i32 %5, 1071644672, !dbg !2445
  %24 = fadd double %22, %22, !dbg !2447
  br i1 %23, label %25, label %30, !dbg !2448

25:                                               ; preds = %21
  tail call void @llvm.dbg.value(metadata double %24, metadata !267, metadata !DIExpression()), !dbg !2419
  %26 = fmul double %22, %24, !dbg !2449
  %27 = fsub double 1.000000e+00, %22, !dbg !2451
  %28 = fdiv double %26, %27, !dbg !2452
  %29 = fadd double %24, %28, !dbg !2453
  tail call void @llvm.dbg.value(metadata double poison, metadata !267, metadata !DIExpression()), !dbg !2419
  br label %33, !dbg !2454

30:                                               ; preds = %21
  %31 = fsub double 1.000000e+00, %22, !dbg !2455
  %32 = fdiv double %24, %31, !dbg !2457
  tail call void @llvm.dbg.value(metadata double poison, metadata !267, metadata !DIExpression()), !dbg !2419
  br label %33

33:                                               ; preds = %30, %25
  %34 = phi double [ %32, %30 ], [ %29, %25 ]
  %35 = tail call double @pts_ieee754_log1p(double noundef %34), !dbg !2447
  %36 = fmul double %35, 5.000000e-01, !dbg !2447
  tail call void @llvm.dbg.value(metadata double %36, metadata !267, metadata !DIExpression()), !dbg !2419
  %37 = fneg double %36
  %38 = icmp slt i64 %2, 0, !dbg !2458
  %39 = select i1 %38, double %37, double %36, !dbg !2458
  br label %40, !dbg !2458

40:                                               ; preds = %33, %16, %1, %13
  %41 = phi double [ %15, %13 ], [ 0x7FF8000000000000, %1 ], [ %0, %16 ], [ %39, %33 ], !dbg !2419
  ret double %41, !dbg !2459
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log2(double noundef %0) local_unnamed_addr #0 !dbg !382 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !384, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2461
  %2 = bitcast double %0 to i64, !dbg !2463
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2461
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !398, metadata !DIExpression()), !dbg !2464
  %3 = lshr i64 %2, 32, !dbg !2465
  %4 = trunc i64 %3 to i32, !dbg !2465
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !396, metadata !DIExpression()), !dbg !2460
  %5 = trunc i64 %2 to i32, !dbg !2465
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !397, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata i32 0, metadata !395, metadata !DIExpression()), !dbg !2460
  %6 = icmp slt i32 %4, 1048576, !dbg !2466
  br i1 %6, label %7, label %18, !dbg !2467

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2468
  %9 = or i32 %8, %5, !dbg !2470
  %10 = icmp eq i32 %9, 0, !dbg !2471
  br i1 %10, label %80, label %11, !dbg !2472

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2473
  br i1 %12, label %80, label %13, !dbg !2475

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !395, metadata !DIExpression()), !dbg !2460
  %14 = fmul double %0, 0x4350000000000000, !dbg !2476
  tail call void @llvm.dbg.value(metadata double %14, metadata !384, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata double %14, metadata !874, metadata !DIExpression()), !dbg !2477
  %15 = bitcast double %14 to i64, !dbg !2479
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !879, metadata !DIExpression()), !dbg !2477
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !400, metadata !DIExpression()), !dbg !2480
  %16 = lshr i64 %15, 32, !dbg !2481
  %17 = trunc i64 %16 to i32, !dbg !2481
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !396, metadata !DIExpression()), !dbg !2460
  br label %18, !dbg !2482

18:                                               ; preds = %13, %1
  %19 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2460
  %20 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2460
  %21 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %21, metadata !384, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !395, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata i32 %19, metadata !396, metadata !DIExpression()), !dbg !2460
  %22 = icmp sgt i32 %19, 2146435071, !dbg !2483
  br i1 %22, label %23, label %25, !dbg !2485

23:                                               ; preds = %18
  %24 = fadd double %21, %21, !dbg !2486
  br label %80, !dbg !2487

25:                                               ; preds = %18
  %26 = icmp eq i32 %19, 1072693248, !dbg !2488
  %27 = icmp eq i32 %5, 0
  %28 = and i1 %27, %26, !dbg !2490
  br i1 %28, label %80, label %29, !dbg !2490

29:                                               ; preds = %25
  %30 = ashr i32 %19, 20, !dbg !2491
  %31 = add nsw i32 %30, -1023, !dbg !2492
  %32 = add nsw i32 %31, %20, !dbg !2493
  tail call void @llvm.dbg.value(metadata i32 %32, metadata !395, metadata !DIExpression()), !dbg !2460
  %33 = and i32 %19, 1048575, !dbg !2494
  tail call void @llvm.dbg.value(metadata i32 %33, metadata !396, metadata !DIExpression()), !dbg !2460
  %34 = add nuw nsw i32 %33, 614244, !dbg !2495
  %35 = and i32 %34, 1048576, !dbg !2496
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !394, metadata !DIExpression(DW_OP_constu, 1048576, DW_OP_and, DW_OP_stack_value)), !dbg !2460
  tail call void @llvm.dbg.value(metadata double %21, metadata !874, metadata !DIExpression()), !dbg !2497
  %36 = bitcast double %21 to i64, !dbg !2499
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !879, metadata !DIExpression()), !dbg !2497
  tail call void @llvm.dbg.value(metadata i64 %36, metadata !404, metadata !DIExpression()), !dbg !2500
  %37 = and i64 %36, 4294967295, !dbg !2501
  tail call void @llvm.dbg.value(metadata i64 %37, metadata !404, metadata !DIExpression()), !dbg !2500
  %38 = or disjoint i32 %35, %33, !dbg !2501
  %39 = xor i32 %38, 1072693248, !dbg !2501
  %40 = zext nneg i32 %39 to i64
  %41 = shl nuw nsw i64 %40, 32, !dbg !2501
  %42 = or disjoint i64 %41, %37, !dbg !2501
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !404, metadata !DIExpression()), !dbg !2500
  tail call void @llvm.dbg.value(metadata i64 %42, metadata !948, metadata !DIExpression()), !dbg !2502
  %43 = bitcast i64 %42 to double, !dbg !2504
  tail call void @llvm.dbg.value(metadata double %43, metadata !953, metadata !DIExpression()), !dbg !2502
  tail call void @llvm.dbg.value(metadata double %43, metadata !384, metadata !DIExpression()), !dbg !2460
  %44 = lshr i32 %34, 20
  %45 = add nsw i32 %32, %44, !dbg !2505
  tail call void @llvm.dbg.value(metadata i32 %45, metadata !395, metadata !DIExpression()), !dbg !2460
  %46 = sitofp i32 %45 to double, !dbg !2506
  tail call void @llvm.dbg.value(metadata double %46, metadata !393, metadata !DIExpression()), !dbg !2460
  %47 = fadd double %43, -1.000000e+00, !dbg !2507
  tail call void @llvm.dbg.value(metadata double %47, metadata !385, metadata !DIExpression()), !dbg !2460
  %48 = fmul double %47, 5.000000e-01, !dbg !2508
  %49 = fmul double %47, %48, !dbg !2509
  tail call void @llvm.dbg.value(metadata double %49, metadata !386, metadata !DIExpression()), !dbg !2460
  call void @llvm.dbg.value(metadata double %47, metadata !2510, metadata !DIExpression()), !dbg !2520
  %50 = fadd double %47, 2.000000e+00, !dbg !2522
  %51 = fdiv double %47, %50, !dbg !2523
  call void @llvm.dbg.value(metadata double %51, metadata !2514, metadata !DIExpression()), !dbg !2520
  %52 = fmul double %51, %51, !dbg !2524
  call void @llvm.dbg.value(metadata double %52, metadata !2515, metadata !DIExpression()), !dbg !2520
  %53 = fmul double %52, %52, !dbg !2525
  call void @llvm.dbg.value(metadata double %53, metadata !2517, metadata !DIExpression()), !dbg !2520
  %54 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC39A09D078C69F, double 0x3FCC71C51D8E78AF), !dbg !2526
  %55 = tail call double @llvm.fmuladd.f64(double %53, double %54, double 0x3FD999999997FA04), !dbg !2527
  %56 = fmul double %53, %55, !dbg !2528
  call void @llvm.dbg.value(metadata double %56, metadata !2518, metadata !DIExpression()), !dbg !2520
  %57 = tail call double @llvm.fmuladd.f64(double %53, double 0x3FC2F112DF3E5244, double 0x3FC7466496CB03DE), !dbg !2529
  %58 = tail call double @llvm.fmuladd.f64(double %53, double %57, double 0x3FD2492494229359), !dbg !2530
  %59 = tail call double @llvm.fmuladd.f64(double %53, double %58, double 0x3FE5555555555593), !dbg !2531
  %60 = fmul double %52, %59, !dbg !2532
  call void @llvm.dbg.value(metadata double %60, metadata !2519, metadata !DIExpression()), !dbg !2520
  %61 = fadd double %56, %60, !dbg !2533
  call void @llvm.dbg.value(metadata double %61, metadata !2516, metadata !DIExpression()), !dbg !2520
  call void @llvm.dbg.value(metadata double %49, metadata !2513, metadata !DIExpression()), !dbg !2520
  %62 = fadd double %49, %61, !dbg !2534
  %63 = fmul double %51, %62, !dbg !2535
  tail call void @llvm.dbg.value(metadata double %63, metadata !389, metadata !DIExpression()), !dbg !2460
  %64 = fsub double %47, %49, !dbg !2536
  tail call void @llvm.dbg.value(metadata double %64, metadata !387, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata double %64, metadata !874, metadata !DIExpression()), !dbg !2537
  %65 = bitcast double %64 to i64, !dbg !2539
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !879, metadata !DIExpression()), !dbg !2537
  tail call void @llvm.dbg.value(metadata i64 %65, metadata !406, metadata !DIExpression()), !dbg !2540
  %66 = and i64 %65, -4294967296, !dbg !2541
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !406, metadata !DIExpression()), !dbg !2540
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !406, metadata !DIExpression()), !dbg !2540
  tail call void @llvm.dbg.value(metadata i64 %66, metadata !948, metadata !DIExpression()), !dbg !2542
  %67 = bitcast i64 %66 to double, !dbg !2544
  tail call void @llvm.dbg.value(metadata double %67, metadata !953, metadata !DIExpression()), !dbg !2542
  tail call void @llvm.dbg.value(metadata double %67, metadata !387, metadata !DIExpression()), !dbg !2460
  %68 = fsub double %47, %67, !dbg !2545
  %69 = fsub double %68, %49, !dbg !2546
  %70 = fadd double %69, %63, !dbg !2547
  tail call void @llvm.dbg.value(metadata double %70, metadata !388, metadata !DIExpression()), !dbg !2460
  %71 = fmul double %67, 0x3FF7154765200000, !dbg !2548
  tail call void @llvm.dbg.value(metadata double %71, metadata !390, metadata !DIExpression()), !dbg !2460
  %72 = fadd double %70, %67, !dbg !2549
  %73 = fmul double %70, 0x3FF7154765200000, !dbg !2550
  %74 = tail call double @llvm.fmuladd.f64(double %72, double 0x3DE705FC2EEFA200, double %73), !dbg !2551
  tail call void @llvm.dbg.value(metadata double %74, metadata !391, metadata !DIExpression()), !dbg !2460
  %75 = fadd double %71, %46, !dbg !2552
  tail call void @llvm.dbg.value(metadata double %75, metadata !392, metadata !DIExpression()), !dbg !2460
  %76 = fsub double %46, %75, !dbg !2553
  %77 = fadd double %71, %76, !dbg !2554
  %78 = fadd double %77, %74, !dbg !2555
  tail call void @llvm.dbg.value(metadata double %78, metadata !391, metadata !DIExpression()), !dbg !2460
  tail call void @llvm.dbg.value(metadata double %75, metadata !390, metadata !DIExpression()), !dbg !2460
  %79 = fadd double %75, %78, !dbg !2556
  br label %80, !dbg !2557

80:                                               ; preds = %25, %11, %7, %29, %23
  %81 = phi double [ %24, %23 ], [ %79, %29 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %25 ], !dbg !2460
  ret double %81, !dbg !2558
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_log10(double noundef %0) local_unnamed_addr #0 !dbg !414 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !416, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2560
  %2 = bitcast double %0 to i64, !dbg !2562
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2560
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !422, metadata !DIExpression()), !dbg !2563
  %3 = lshr i64 %2, 32, !dbg !2564
  %4 = trunc i64 %3 to i32, !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !420, metadata !DIExpression()), !dbg !2559
  %5 = trunc i64 %2 to i32, !dbg !2564
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !421, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata i32 0, metadata !419, metadata !DIExpression()), !dbg !2559
  %6 = icmp slt i32 %4, 1048576, !dbg !2565
  br i1 %6, label %7, label %19, !dbg !2566

7:                                                ; preds = %1
  %8 = and i32 %4, 2147483647, !dbg !2567
  %9 = or i32 %8, %5, !dbg !2569
  %10 = icmp eq i32 %9, 0, !dbg !2570
  br i1 %10, label %51, label %11, !dbg !2571

11:                                               ; preds = %7
  %12 = icmp slt i64 %2, 0, !dbg !2572
  br i1 %12, label %51, label %13, !dbg !2574

13:                                               ; preds = %11
  tail call void @llvm.dbg.value(metadata i32 -54, metadata !419, metadata !DIExpression()), !dbg !2559
  %14 = fmul double %0, 0x4350000000000000, !dbg !2575
  tail call void @llvm.dbg.value(metadata double %14, metadata !416, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata double %14, metadata !874, metadata !DIExpression()), !dbg !2576
  %15 = bitcast double %14 to i64, !dbg !2578
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !879, metadata !DIExpression()), !dbg !2576
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !424, metadata !DIExpression()), !dbg !2579
  %16 = lshr i64 %15, 32, !dbg !2580
  %17 = trunc i64 %16 to i32, !dbg !2580
  tail call void @llvm.dbg.value(metadata i32 %17, metadata !420, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata double %14, metadata !874, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !879, metadata !DIExpression()), !dbg !2581
  tail call void @llvm.dbg.value(metadata i64 %15, metadata !428, metadata !DIExpression()), !dbg !2583
  %18 = trunc i64 %15 to i32, !dbg !2584
  tail call void @llvm.dbg.value(metadata i32 %18, metadata !421, metadata !DIExpression()), !dbg !2559
  br label %19, !dbg !2585

19:                                               ; preds = %13, %1
  %20 = phi i32 [ %18, %13 ], [ %5, %1 ], !dbg !2559
  %21 = phi i32 [ %17, %13 ], [ %4, %1 ], !dbg !2559
  %22 = phi i32 [ -54, %13 ], [ 0, %1 ], !dbg !2559
  %23 = phi double [ %14, %13 ], [ %0, %1 ]
  tail call void @llvm.dbg.value(metadata double %23, metadata !416, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata i32 %22, metadata !419, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata i32 %21, metadata !420, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !421, metadata !DIExpression()), !dbg !2559
  %24 = icmp sgt i32 %21, 2146435071, !dbg !2586
  br i1 %24, label %25, label %27, !dbg !2588

25:                                               ; preds = %19
  %26 = fadd double %23, %23, !dbg !2589
  br label %51, !dbg !2590

27:                                               ; preds = %19
  %28 = icmp eq i32 %21, 1072693248, !dbg !2591
  %29 = icmp eq i32 %20, 0
  %30 = and i1 %29, %28, !dbg !2593
  br i1 %30, label %51, label %31, !dbg !2593

31:                                               ; preds = %27
  %32 = ashr i32 %21, 20, !dbg !2594
  %33 = add nsw i32 %32, -1023, !dbg !2595
  %34 = add nsw i32 %33, %22, !dbg !2596
  tail call void @llvm.dbg.value(metadata i32 %34, metadata !419, metadata !DIExpression()), !dbg !2559
  %35 = lshr i32 %34, 31, !dbg !2597
  tail call void @llvm.dbg.value(metadata i32 %35, metadata !418, metadata !DIExpression()), !dbg !2559
  %36 = and i32 %21, 1048575, !dbg !2598
  %37 = shl nuw nsw i32 %35, 20, !dbg !2599
  %38 = or disjoint i32 %37, %36, !dbg !2600
  %39 = xor i32 %38, 1072693248, !dbg !2600
  tail call void @llvm.dbg.value(metadata i32 %39, metadata !420, metadata !DIExpression()), !dbg !2559
  %40 = add nsw i32 %35, %34, !dbg !2601
  %41 = sitofp i32 %40 to double, !dbg !2602
  tail call void @llvm.dbg.value(metadata double %41, metadata !417, metadata !DIExpression()), !dbg !2559
  tail call void @llvm.dbg.value(metadata double %23, metadata !874, metadata !DIExpression()), !dbg !2603
  tail call void @llvm.dbg.value(metadata double %23, metadata !879, metadata !DIExpression()), !dbg !2603
  tail call void @llvm.dbg.value(metadata double %23, metadata !430, metadata !DIExpression()), !dbg !2605
  tail call void @llvm.dbg.value(metadata double %23, metadata !430, metadata !DIExpression(DW_OP_constu, 4294967295, DW_OP_and, DW_OP_stack_value)), !dbg !2605
  %42 = zext nneg i32 %39 to i64
  %43 = shl nuw nsw i64 %42, 32, !dbg !2606
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !430, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2605
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !948, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2607
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !953, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2607
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !416, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2559
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !874, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2609
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !879, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2609
  tail call void @llvm.dbg.value(metadata !DIArgList(double %23, i64 %43), metadata !432, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_constu, 4294967295, DW_OP_and, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_stack_value)), !dbg !2611
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !432, metadata !DIExpression()), !dbg !2611
  %44 = zext i32 %20 to i64, !dbg !2612
  %45 = or disjoint i64 %43, %44, !dbg !2612
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !432, metadata !DIExpression()), !dbg !2611
  tail call void @llvm.dbg.value(metadata i64 %45, metadata !948, metadata !DIExpression()), !dbg !2613
  %46 = bitcast i64 %45 to double, !dbg !2615
  tail call void @llvm.dbg.value(metadata double %46, metadata !953, metadata !DIExpression()), !dbg !2613
  tail call void @llvm.dbg.value(metadata double %46, metadata !416, metadata !DIExpression()), !dbg !2559
  %47 = tail call double @pts_ieee754_log(double noundef %46), !dbg !2616
  %48 = fmul double %47, 0x3FDBCB7B1526E50E, !dbg !2617
  %49 = tail call double @llvm.fmuladd.f64(double %41, double 0x3D59FEF311F12B36, double %48), !dbg !2618
  tail call void @llvm.dbg.value(metadata double %49, metadata !434, metadata !DIExpression()), !dbg !2559
  %50 = tail call double @llvm.fmuladd.f64(double %41, double 0x3FD34413509F6000, double %49), !dbg !2619
  br label %51

51:                                               ; preds = %27, %11, %7, %31, %25
  %52 = phi double [ %26, %25 ], [ %50, %31 ], [ 0xFFF0000000000000, %7 ], [ 0x7FF8000000000000, %11 ], [ 0.000000e+00, %27 ], !dbg !2559
  ret double %52, !dbg !2620
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable
define dso_local double @pts_ieee754_expm1(double noundef %0) local_unnamed_addr #4 !dbg !443 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !445, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2622
  %2 = bitcast double %0 to i64, !dbg !2624
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2622
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !459, metadata !DIExpression()), !dbg !2625
  %3 = lshr i64 %2, 32, !dbg !2626
  %4 = trunc i64 %3 to i32, !dbg !2626
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !458, metadata !DIExpression()), !dbg !2621
  %5 = and i32 %4, -2147483648, !dbg !2627
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !457, metadata !DIExpression()), !dbg !2621
  %6 = and i32 %4, 2147483647, !dbg !2628
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !458, metadata !DIExpression()), !dbg !2621
  %7 = icmp ugt i32 %6, 1078159481, !dbg !2629
  br i1 %7, label %8, label %32, !dbg !2630

8:                                                ; preds = %1
  %9 = icmp ugt i32 %6, 1082535489, !dbg !2631
  br i1 %9, label %10, label %27, !dbg !2632

10:                                               ; preds = %8
  %11 = icmp ugt i32 %6, 2146435071, !dbg !2633
  br i1 %11, label %12, label %21, !dbg !2634

12:                                               ; preds = %10
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2635
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2635
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !468, metadata !DIExpression()), !dbg !2637
  %13 = trunc i64 %2 to i32, !dbg !2638
  tail call void @llvm.dbg.value(metadata i32 %13, metadata !461, metadata !DIExpression()), !dbg !2639
  %14 = and i32 %4, 1048575, !dbg !2640
  %15 = or i32 %14, %13, !dbg !2642
  %16 = icmp eq i32 %15, 0, !dbg !2643
  %17 = fadd double %0, %0, !dbg !2644
  %18 = icmp eq i32 %5, 0, !dbg !2644
  %19 = select i1 %18, double %0, double -1.000000e+00, !dbg !2644
  %20 = select i1 %16, double %19, double %17, !dbg !2644
  br label %145

21:                                               ; preds = %10
  %22 = fcmp ogt double %0, 0x40862E42FEFA39EF, !dbg !2645
  br i1 %22, label %23, label %27, !dbg !2647

23:                                               ; preds = %21
  %24 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2648, !tbaa !1438
  %25 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2649, !tbaa !1438
  %26 = fmul double %24, %25, !dbg !2650
  br label %145, !dbg !2651

27:                                               ; preds = %21, %8
  %28 = icmp ne i32 %5, 0, !dbg !2652
  %29 = fadd double %0, 1.000000e-300
  %30 = fcmp olt double %29, 0.000000e+00
  %31 = and i1 %30, %28, !dbg !2654
  br i1 %31, label %145, label %42, !dbg !2654

32:                                               ; preds = %1
  %33 = icmp ugt i32 %6, 1071001154, !dbg !2655
  br i1 %33, label %34, label %58, !dbg !2657

34:                                               ; preds = %32
  %35 = icmp ult i32 %6, 1072734898, !dbg !2658
  br i1 %35, label %36, label %42, !dbg !2661

36:                                               ; preds = %34
  %37 = icmp eq i32 %5, 0, !dbg !2662
  br i1 %37, label %38, label %40, !dbg !2665

38:                                               ; preds = %36
  %39 = fadd double %0, 0xBFE62E42FEE00000, !dbg !2666
  tail call void @llvm.dbg.value(metadata double %39, metadata !447, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double 0x3DEA39EF35793C76, metadata !448, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata i32 1, metadata !456, metadata !DIExpression()), !dbg !2621
  br label %51, !dbg !2668

40:                                               ; preds = %36
  %41 = fadd double %0, 0x3FE62E42FEE00000, !dbg !2669
  tail call void @llvm.dbg.value(metadata double %41, metadata !447, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double 0xBDEA39EF35793C76, metadata !448, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata i32 -1, metadata !456, metadata !DIExpression()), !dbg !2621
  br label %51

42:                                               ; preds = %27, %34
  %43 = icmp eq i32 %5, 0, !dbg !2671
  %44 = select i1 %43, double 5.000000e-01, double -5.000000e-01, !dbg !2673
  %45 = tail call double @llvm.fmuladd.f64(double %0, double 0x3FF71547652B82FE, double %44), !dbg !2674
  %46 = fptosi double %45 to i32, !dbg !2675
  tail call void @llvm.dbg.value(metadata i32 %46, metadata !456, metadata !DIExpression()), !dbg !2621
  %47 = sitofp i32 %46 to double, !dbg !2676
  tail call void @llvm.dbg.value(metadata double %47, metadata !450, metadata !DIExpression()), !dbg !2621
  %48 = fneg double %47, !dbg !2677
  %49 = tail call double @llvm.fmuladd.f64(double %48, double 0x3FE62E42FEE00000, double %0), !dbg !2677
  tail call void @llvm.dbg.value(metadata double %49, metadata !447, metadata !DIExpression()), !dbg !2621
  %50 = fmul double %47, 0x3DEA39EF35793C76, !dbg !2678
  tail call void @llvm.dbg.value(metadata double %50, metadata !448, metadata !DIExpression()), !dbg !2621
  br label %51

51:                                               ; preds = %38, %40, %42
  %52 = phi i32 [ 1, %38 ], [ -1, %40 ], [ %46, %42 ], !dbg !2679
  %53 = phi double [ 0x3DEA39EF35793C76, %38 ], [ 0xBDEA39EF35793C76, %40 ], [ %50, %42 ], !dbg !2679
  %54 = phi double [ %39, %38 ], [ %41, %40 ], [ %49, %42 ], !dbg !2679
  tail call void @llvm.dbg.value(metadata double %54, metadata !447, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double %53, metadata !448, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata i32 %52, metadata !456, metadata !DIExpression()), !dbg !2621
  %55 = fsub double %54, %53, !dbg !2680
  tail call void @llvm.dbg.value(metadata double %55, metadata !445, metadata !DIExpression()), !dbg !2621
  %56 = fsub double %54, %55, !dbg !2681
  %57 = fsub double %56, %53, !dbg !2682
  tail call void @llvm.dbg.value(metadata double %57, metadata !449, metadata !DIExpression()), !dbg !2621
  br label %67, !dbg !2683

58:                                               ; preds = %32
  %59 = icmp ult i32 %6, 1016070144, !dbg !2684
  br i1 %59, label %60, label %67, !dbg !2686

60:                                               ; preds = %58
  %61 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2687, !tbaa !1438
  %62 = fadd double %61, %0, !dbg !2689
  tail call void @llvm.dbg.value(metadata double %62, metadata !450, metadata !DIExpression()), !dbg !2621
  %63 = load volatile double, ptr @pts_ieee754_expm1.huge, align 8, !dbg !2690, !tbaa !1438
  %64 = fadd double %63, %0, !dbg !2691
  %65 = fsub double %62, %64, !dbg !2692
  %66 = fsub double %0, %65, !dbg !2693
  br label %145, !dbg !2694

67:                                               ; preds = %58, %51
  %68 = phi i32 [ %52, %51 ], [ 0, %58 ], !dbg !2695
  %69 = phi double [ %57, %51 ], [ undef, %58 ]
  %70 = phi double [ %55, %51 ], [ %0, %58 ]
  tail call void @llvm.dbg.value(metadata double %70, metadata !445, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double %69, metadata !449, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata i32 %68, metadata !456, metadata !DIExpression()), !dbg !2621
  %71 = fmul double %70, 5.000000e-01, !dbg !2696
  tail call void @llvm.dbg.value(metadata double %71, metadata !453, metadata !DIExpression()), !dbg !2621
  %72 = fmul double %70, %71, !dbg !2697
  tail call void @llvm.dbg.value(metadata double %72, metadata !452, metadata !DIExpression()), !dbg !2621
  %73 = tail call double @llvm.fmuladd.f64(double %72, double 0xBE8AFDB76E09C32D, double 0x3ED0CFCA86E65239), !dbg !2698
  %74 = tail call double @llvm.fmuladd.f64(double %72, double %73, double 0xBF14CE199EAADBB7), !dbg !2699
  %75 = tail call double @llvm.fmuladd.f64(double %72, double %74, double 0x3F5A01A019FE5585), !dbg !2700
  %76 = tail call double @llvm.fmuladd.f64(double %72, double %75, double 0xBFA11111111110F4), !dbg !2701
  %77 = tail call double @llvm.fmuladd.f64(double %72, double %76, double 1.000000e+00), !dbg !2702
  tail call void @llvm.dbg.value(metadata double %77, metadata !454, metadata !DIExpression()), !dbg !2621
  %78 = fneg double %77, !dbg !2703
  %79 = tail call double @llvm.fmuladd.f64(double %78, double %71, double 3.000000e+00), !dbg !2703
  tail call void @llvm.dbg.value(metadata double %79, metadata !450, metadata !DIExpression()), !dbg !2621
  %80 = fsub double %77, %79, !dbg !2704
  %81 = fneg double %70, !dbg !2705
  %82 = tail call double @llvm.fmuladd.f64(double %81, double %79, double 6.000000e+00), !dbg !2705
  %83 = fdiv double %80, %82, !dbg !2706
  %84 = fmul double %72, %83, !dbg !2707
  tail call void @llvm.dbg.value(metadata double %84, metadata !451, metadata !DIExpression()), !dbg !2621
  %85 = icmp eq i32 %68, 0, !dbg !2708
  br i1 %85, label %86, label %90, !dbg !2709

86:                                               ; preds = %67
  %87 = fneg double %72, !dbg !2710
  %88 = tail call double @llvm.fmuladd.f64(double %70, double %84, double %87), !dbg !2710
  %89 = fsub double %70, %88, !dbg !2712
  br label %145, !dbg !2713

90:                                               ; preds = %67
  tail call void @llvm.dbg.value(metadata i64 0, metadata !470, metadata !DIExpression()), !dbg !2714
  %91 = shl i32 %68, 20, !dbg !2715
  %92 = add nsw i32 %91, 1072693248, !dbg !2715
  %93 = sext i32 %92 to i64, !dbg !2715
  %94 = shl nsw i64 %93, 32, !dbg !2715
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !470, metadata !DIExpression()), !dbg !2714
  tail call void @llvm.dbg.value(metadata i64 %94, metadata !948, metadata !DIExpression()), !dbg !2716
  %95 = bitcast i64 %94 to double, !dbg !2718
  tail call void @llvm.dbg.value(metadata double %95, metadata !953, metadata !DIExpression()), !dbg !2716
  tail call void @llvm.dbg.value(metadata double %95, metadata !455, metadata !DIExpression()), !dbg !2621
  %96 = fsub double %84, %69, !dbg !2719
  %97 = fneg double %69, !dbg !2720
  %98 = tail call double @llvm.fmuladd.f64(double %70, double %96, double %97), !dbg !2720
  tail call void @llvm.dbg.value(metadata double %98, metadata !451, metadata !DIExpression()), !dbg !2621
  %99 = fsub double %98, %72, !dbg !2721
  tail call void @llvm.dbg.value(metadata double %99, metadata !451, metadata !DIExpression()), !dbg !2621
  switch i32 %68, label %112 [
    i32 -1, label %100
    i32 1, label %103
  ], !dbg !2722

100:                                              ; preds = %90
  %101 = fsub double %70, %99, !dbg !2723
  %102 = tail call double @llvm.fmuladd.f64(double %101, double 5.000000e-01, double -5.000000e-01), !dbg !2725
  br label %145, !dbg !2726

103:                                              ; preds = %90
  %104 = fcmp olt double %70, -2.500000e-01, !dbg !2727
  br i1 %104, label %105, label %109, !dbg !2731

105:                                              ; preds = %103
  %106 = fadd double %70, 5.000000e-01, !dbg !2732
  %107 = fsub double %99, %106, !dbg !2733
  %108 = fmul double %107, -2.000000e+00, !dbg !2734
  br label %145, !dbg !2735

109:                                              ; preds = %103
  %110 = fsub double %70, %99, !dbg !2736
  %111 = tail call double @llvm.fmuladd.f64(double %110, double 2.000000e+00, double 1.000000e+00), !dbg !2737
  br label %145, !dbg !2738

112:                                              ; preds = %90
  %113 = add i32 %68, -57, !dbg !2739
  %114 = icmp ult i32 %113, -58, !dbg !2739
  br i1 %114, label %115, label %124, !dbg !2739

115:                                              ; preds = %112
  %116 = fsub double %70, %99, !dbg !2741
  %117 = fadd double %116, 1.000000e+00, !dbg !2741
  tail call void @llvm.dbg.value(metadata double %117, metadata !446, metadata !DIExpression()), !dbg !2621
  %118 = icmp eq i32 %68, 1024, !dbg !2743
  %119 = fmul double %117, 2.000000e+00, !dbg !2745
  %120 = fmul double %119, 0x7FE0000000000000, !dbg !2745
  %121 = fmul double %117, %95, !dbg !2745
  %122 = select i1 %118, double %120, double %121, !dbg !2745
  tail call void @llvm.dbg.value(metadata double %122, metadata !446, metadata !DIExpression()), !dbg !2621
  %123 = fadd double %122, -1.000000e+00, !dbg !2746
  br label %145, !dbg !2747

124:                                              ; preds = %112
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !450, metadata !DIExpression()), !dbg !2621
  %125 = icmp ult i32 %68, 20, !dbg !2748
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !874, metadata !DIExpression()), !dbg !2749
  tail call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !874, metadata !DIExpression()), !dbg !2751
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !879, metadata !DIExpression()), !dbg !2749
  tail call void @llvm.dbg.value(metadata i64 4607182418800017408, metadata !879, metadata !DIExpression()), !dbg !2751
  tail call void @llvm.dbg.value(metadata double poison, metadata !446, metadata !DIExpression()), !dbg !2621
  tail call void @llvm.dbg.value(metadata double poison, metadata !446, metadata !DIExpression()), !dbg !2621
  br i1 %125, label %126, label %134, !dbg !2753

126:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !474, metadata !DIExpression()), !dbg !2754
  %127 = lshr i32 2097152, %68
  %128 = sub nuw nsw i32 1072693248, %127, !dbg !2755
  %129 = zext nneg i32 %128 to i64
  %130 = shl nuw nsw i64 %129, 32, !dbg !2755
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !474, metadata !DIExpression()), !dbg !2754
  tail call void @llvm.dbg.value(metadata i64 %130, metadata !948, metadata !DIExpression()), !dbg !2756
  %131 = bitcast i64 %130 to double, !dbg !2758
  tail call void @llvm.dbg.value(metadata double %131, metadata !953, metadata !DIExpression()), !dbg !2756
  tail call void @llvm.dbg.value(metadata double %131, metadata !450, metadata !DIExpression()), !dbg !2621
  %132 = fsub double %99, %70, !dbg !2759
  %133 = fsub double %131, %132, !dbg !2760
  br label %142, !dbg !2761

134:                                              ; preds = %124
  tail call void @llvm.dbg.value(metadata i64 0, metadata !478, metadata !DIExpression()), !dbg !2762
  %135 = sub i32 1072693248, %91, !dbg !2763
  %136 = zext nneg i32 %135 to i64
  %137 = shl nuw nsw i64 %136, 32, !dbg !2763
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !478, metadata !DIExpression()), !dbg !2762
  tail call void @llvm.dbg.value(metadata i64 %137, metadata !948, metadata !DIExpression()), !dbg !2764
  %138 = bitcast i64 %137 to double, !dbg !2766
  tail call void @llvm.dbg.value(metadata double %138, metadata !953, metadata !DIExpression()), !dbg !2764
  tail call void @llvm.dbg.value(metadata double %138, metadata !450, metadata !DIExpression()), !dbg !2621
  %139 = fadd double %99, %138, !dbg !2767
  %140 = fsub double %70, %139, !dbg !2768
  tail call void @llvm.dbg.value(metadata double %140, metadata !446, metadata !DIExpression()), !dbg !2621
  %141 = fadd double %140, 1.000000e+00, !dbg !2769
  br label %142

142:                                              ; preds = %126, %134
  %143 = phi double [ %133, %126 ], [ %141, %134 ]
  %144 = fmul double %143, %95, !dbg !2770
  tail call void @llvm.dbg.value(metadata double %144, metadata !446, metadata !DIExpression()), !dbg !2621
  br label %145, !dbg !2771

145:                                              ; preds = %27, %142, %115, %109, %105, %100, %86, %60, %23, %12
  %146 = phi double [ %20, %12 ], [ %26, %23 ], [ %89, %86 ], [ %102, %100 ], [ %108, %105 ], [ %111, %109 ], [ %123, %115 ], [ %144, %142 ], [ %66, %60 ], [ -1.000000e+00, %27 ], !dbg !2621
  ret double %146, !dbg !2772
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local double @pts_ieee754_cbrt(double noundef %0) local_unnamed_addr #0 !dbg !505 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !507, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !511, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2774
  %2 = bitcast double %0 to i64, !dbg !2776
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !2774
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !516, metadata !DIExpression()), !dbg !2777
  %3 = lshr i64 %2, 32, !dbg !2778
  %4 = trunc i64 %3 to i32, !dbg !2778
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !508, metadata !DIExpression()), !dbg !2773
  %5 = trunc i64 %2 to i32, !dbg !2778
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !515, metadata !DIExpression()), !dbg !2773
  %6 = and i32 %4, -2147483648, !dbg !2779
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !513, metadata !DIExpression()), !dbg !2773
  %7 = and i32 %4, 2147483647, !dbg !2780
  tail call void @llvm.dbg.value(metadata i32 %7, metadata !508, metadata !DIExpression()), !dbg !2773
  %8 = icmp ugt i32 %7, 2146435071, !dbg !2781
  br i1 %8, label %9, label %11, !dbg !2783

9:                                                ; preds = %1
  %10 = fadd double %0, %0, !dbg !2784
  br label %52, !dbg !2785

11:                                               ; preds = %1
  %12 = icmp ult i32 %7, 1048576, !dbg !2786
  br i1 %12, label %13, label %22, !dbg !2787

13:                                               ; preds = %11
  %14 = or i32 %7, %5, !dbg !2788
  %15 = icmp eq i32 %14, 0, !dbg !2790
  br i1 %15, label %52, label %16, !dbg !2791

16:                                               ; preds = %13
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !874, metadata !DIExpression()), !dbg !2792
  tail call void @llvm.dbg.value(metadata i64 0, metadata !879, metadata !DIExpression()), !dbg !2792
  tail call void @llvm.dbg.value(metadata i64 4850376798678024192, metadata !948, metadata !DIExpression()), !dbg !2794
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !953, metadata !DIExpression()), !dbg !2794
  tail call void @llvm.dbg.value(metadata double 0x4350000000000000, metadata !511, metadata !DIExpression()), !dbg !2773
  %17 = fmul double %0, 0x4350000000000000, !dbg !2796
  tail call void @llvm.dbg.value(metadata double %17, metadata !511, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata double %17, metadata !874, metadata !DIExpression()), !dbg !2797
  %18 = bitcast double %17 to i64, !dbg !2799
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !879, metadata !DIExpression()), !dbg !2797
  tail call void @llvm.dbg.value(metadata i64 %18, metadata !522, metadata !DIExpression()), !dbg !2800
  %19 = lshr i64 %18, 32, !dbg !2801
  %20 = trunc i64 %19 to i32, !dbg !2801
  tail call void @llvm.dbg.value(metadata i32 %20, metadata !514, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata i64 0, metadata !524, metadata !DIExpression()), !dbg !2802
  %21 = and i32 %20, 2147483647, !dbg !2803
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !524, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2802
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !524, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2802
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !948, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2804
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !953, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2804
  tail call void @llvm.dbg.value(metadata !DIArgList(i32 %6, i32 %26), metadata !511, metadata !DIExpression(DW_OP_LLVM_arg, 0, DW_OP_LLVM_arg, 1, DW_OP_or, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_constu, 32, DW_OP_shl, DW_OP_stack_value)), !dbg !2773
  br label %22, !dbg !2806

22:                                               ; preds = %11, %16
  %23 = phi i32 [ %21, %16 ], [ %7, %11 ]
  %24 = phi i32 [ 696219795, %16 ], [ 715094163, %11 ]
  %25 = udiv i32 %23, 3
  %26 = add nuw nsw i32 %25, %24, !dbg !2807
  %27 = or disjoint i32 %26, %6, !dbg !2807
  %28 = zext i32 %27 to i64, !dbg !2807
  %29 = shl nuw i64 %28, 32, !dbg !2807
  %30 = bitcast i64 %29 to double, !dbg !2807
  tail call void @llvm.dbg.value(metadata double %30, metadata !511, metadata !DIExpression()), !dbg !2773
  %31 = fmul double %30, %30, !dbg !2808
  %32 = fdiv double %30, %0, !dbg !2809
  %33 = fmul double %31, %32, !dbg !2810
  tail call void @llvm.dbg.value(metadata double %33, metadata !509, metadata !DIExpression()), !dbg !2773
  %34 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FF9F1604A49D6C2, double 0xBFFE28E092F02420), !dbg !2811
  %35 = tail call double @llvm.fmuladd.f64(double %33, double %34, double 0x3FFE03E60F61E692), !dbg !2812
  %36 = fmul double %33, %33, !dbg !2813
  %37 = fmul double %33, %36, !dbg !2814
  %38 = tail call double @llvm.fmuladd.f64(double %33, double 0x3FC2B000D4E4EDD7, double 0xBFE844CBBEE751D9), !dbg !2815
  %39 = tail call double @llvm.fmuladd.f64(double %37, double %38, double %35), !dbg !2816
  %40 = fmul double %39, %30, !dbg !2817
  tail call void @llvm.dbg.value(metadata double %40, metadata !511, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata double %40, metadata !874, metadata !DIExpression()), !dbg !2818
  %41 = bitcast double %40 to i64, !dbg !2820
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !879, metadata !DIExpression()), !dbg !2818
  tail call void @llvm.dbg.value(metadata i64 %41, metadata !529, metadata !DIExpression()), !dbg !2773
  %42 = and i64 %41, -1073741824, !dbg !2821
  %43 = add i64 %42, 2147483648, !dbg !2821
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !529, metadata !DIExpression()), !dbg !2773
  tail call void @llvm.dbg.value(metadata i64 %43, metadata !948, metadata !DIExpression()), !dbg !2822
  %44 = bitcast i64 %43 to double, !dbg !2824
  tail call void @llvm.dbg.value(metadata double %44, metadata !953, metadata !DIExpression()), !dbg !2822
  tail call void @llvm.dbg.value(metadata double %44, metadata !511, metadata !DIExpression()), !dbg !2773
  %45 = fmul double %44, %44, !dbg !2825
  tail call void @llvm.dbg.value(metadata double %45, metadata !510, metadata !DIExpression()), !dbg !2773
  %46 = fdiv double %0, %45, !dbg !2826
  tail call void @llvm.dbg.value(metadata double %46, metadata !509, metadata !DIExpression()), !dbg !2773
  %47 = fadd double %44, %44, !dbg !2827
  tail call void @llvm.dbg.value(metadata double %47, metadata !512, metadata !DIExpression()), !dbg !2773
  %48 = fsub double %46, %44, !dbg !2828
  %49 = fadd double %47, %46, !dbg !2829
  %50 = fdiv double %48, %49, !dbg !2830
  tail call void @llvm.dbg.value(metadata double %50, metadata !509, metadata !DIExpression()), !dbg !2773
  %51 = tail call double @llvm.fmuladd.f64(double %44, double %50, double %44), !dbg !2831
  tail call void @llvm.dbg.value(metadata double %51, metadata !511, metadata !DIExpression()), !dbg !2773
  br label %52

52:                                               ; preds = %13, %22, %9
  %53 = phi double [ %10, %9 ], [ %51, %22 ], [ %0, %13 ], !dbg !2773
  ret double %53, !dbg !2832
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_sin(double noundef %0) local_unnamed_addr #5 !dbg !2833 {
  %2 = alloca [2 x double], align 8, !DIAssignID !2842
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2836, metadata !DIExpression(), metadata !2842, metadata ptr %2, metadata !DIExpression()), !dbg !2843
  tail call void @llvm.dbg.value(metadata double %0, metadata !2835, metadata !DIExpression()), !dbg !2843
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !2844
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2837, metadata !DIExpression()), !dbg !2843
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2845
  %3 = bitcast double %0 to i64, !dbg !2847
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !2845
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !2840, metadata !DIExpression()), !dbg !2848
  %4 = lshr i64 %3, 32, !dbg !2849
  %5 = trunc i64 %4 to i32, !dbg !2849
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2839, metadata !DIExpression()), !dbg !2843
  %6 = and i32 %5, 2147483647, !dbg !2850
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !2839, metadata !DIExpression()), !dbg !2843
  %7 = icmp ult i32 %6, 1072243196, !dbg !2851
  br i1 %7, label %8, label %23, !dbg !2853

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !769, metadata !DIExpression()), !dbg !2854
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !770, metadata !DIExpression()), !dbg !2854
  call void @llvm.dbg.value(metadata i32 0, metadata !771, metadata !DIExpression()), !dbg !2854
  call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !2857
  call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !2857
  call void @llvm.dbg.value(metadata i64 %3, metadata !776, metadata !DIExpression()), !dbg !2859
  call void @llvm.dbg.value(metadata i64 %3, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_stack_value)), !dbg !2854
  call void @llvm.dbg.value(metadata i64 %3, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2854
  %9 = and i64 %3, 9205357638345293824, !dbg !2860
  %10 = icmp ult i64 %9, 4485585228861014016, !dbg !2860
  %11 = fptosi double %0 to i32
  %12 = icmp eq i32 %11, 0
  %13 = select i1 %10, i1 %12, i1 false, !dbg !2861
  br i1 %13, label %167, label %14, !dbg !2861

14:                                               ; preds = %8
  %15 = fmul double %0, %0, !dbg !2862
  call void @llvm.dbg.value(metadata double %15, metadata !772, metadata !DIExpression()), !dbg !2854
  %16 = fmul double %15, %0, !dbg !2863
  call void @llvm.dbg.value(metadata double %16, metadata !774, metadata !DIExpression()), !dbg !2854
  %17 = tail call double @llvm.fmuladd.f64(double %15, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2864
  %18 = tail call double @llvm.fmuladd.f64(double %15, double %17, double 0x3EC71DE357B1FE7D), !dbg !2865
  %19 = tail call double @llvm.fmuladd.f64(double %15, double %18, double 0xBF2A01A019C161D5), !dbg !2866
  %20 = tail call double @llvm.fmuladd.f64(double %15, double %19, double 0x3F8111111110F8A6), !dbg !2867
  call void @llvm.dbg.value(metadata double %20, metadata !773, metadata !DIExpression()), !dbg !2854
  %21 = tail call double @llvm.fmuladd.f64(double %15, double %20, double 0xBFC5555555555549), !dbg !2868
  %22 = tail call double @llvm.fmuladd.f64(double %16, double %21, double %0), !dbg !2870
  br label %167, !dbg !2871

23:                                               ; preds = %1
  %24 = icmp ugt i32 %6, 2146435071, !dbg !2872
  br i1 %24, label %25, label %27, !dbg !2874

25:                                               ; preds = %23
  %26 = fsub double %0, %0, !dbg !2875
  br label %167, !dbg !2877

27:                                               ; preds = %23
  %28 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !2878
  tail call void @llvm.dbg.value(metadata i32 %28, metadata !2838, metadata !DIExpression()), !dbg !2843
  %29 = and i32 %28, 3, !dbg !2880
  %30 = load double, ptr %2, align 8, !dbg !2881, !tbaa !1438
  switch i32 %29, label %122 [
    i32 0, label %31
    i32 1, label %54
    i32 2, label %96
  ], !dbg !2883

31:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !769, metadata !DIExpression()), !dbg !2884
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !2884
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !2884
  call void @llvm.dbg.value(metadata double %30, metadata !874, metadata !DIExpression()), !dbg !2886
  %32 = bitcast double %30 to i64, !dbg !2888
  call void @llvm.dbg.value(metadata i64 %32, metadata !879, metadata !DIExpression()), !dbg !2886
  call void @llvm.dbg.value(metadata i64 %32, metadata !776, metadata !DIExpression()), !dbg !2889
  call void @llvm.dbg.value(metadata i64 %32, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2884
  %33 = and i64 %32, 9205357638345293824, !dbg !2890
  %34 = icmp ult i64 %33, 4485585228861014016, !dbg !2890
  %35 = fptosi double %30 to i32
  %36 = icmp eq i32 %35, 0
  %37 = select i1 %34, i1 %36, i1 false, !dbg !2891
  br i1 %37, label %167, label %38, !dbg !2891

38:                                               ; preds = %31
  %39 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2892
  %40 = load double, ptr %39, align 8, !dbg !2892, !tbaa !1438
  call void @llvm.dbg.value(metadata double %40, metadata !770, metadata !DIExpression()), !dbg !2884
  %41 = fmul double %30, %30, !dbg !2893
  call void @llvm.dbg.value(metadata double %41, metadata !772, metadata !DIExpression()), !dbg !2884
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !2884
  %42 = tail call double @llvm.fmuladd.f64(double %41, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2894
  %43 = tail call double @llvm.fmuladd.f64(double %41, double %42, double 0x3EC71DE357B1FE7D), !dbg !2895
  %44 = tail call double @llvm.fmuladd.f64(double %41, double %43, double 0xBF2A01A019C161D5), !dbg !2896
  %45 = tail call double @llvm.fmuladd.f64(double %41, double %44, double 0x3F8111111110F8A6), !dbg !2897
  call void @llvm.dbg.value(metadata double %45, metadata !773, metadata !DIExpression()), !dbg !2884
  %46 = fneg double %41, !dbg !2898
  %47 = fmul double %30, %46, !dbg !2898
  %48 = fmul double %47, %45, !dbg !2898
  %49 = tail call double @llvm.fmuladd.f64(double %40, double 5.000000e-01, double %48), !dbg !2898
  %50 = fneg double %40, !dbg !2899
  %51 = tail call double @llvm.fmuladd.f64(double %41, double %49, double %50), !dbg !2899
  %52 = tail call double @llvm.fmuladd.f64(double %47, double 0xBFC5555555555549, double %51), !dbg !2900
  %53 = fsub double %30, %52, !dbg !2901
  br label %167, !dbg !2902

54:                                               ; preds = %27
  %55 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2903
  %56 = load double, ptr %55, align 8, !dbg !2903, !tbaa !1438
  call void @llvm.dbg.value(metadata double %30, metadata !609, metadata !DIExpression()), !dbg !2904
  call void @llvm.dbg.value(metadata double %56, metadata !610, metadata !DIExpression()), !dbg !2904
  call void @llvm.dbg.value(metadata double %30, metadata !874, metadata !DIExpression()), !dbg !2906
  %57 = bitcast double %30 to i64, !dbg !2908
  call void @llvm.dbg.value(metadata i64 %57, metadata !879, metadata !DIExpression()), !dbg !2906
  call void @llvm.dbg.value(metadata i64 %57, metadata !617, metadata !DIExpression()), !dbg !2909
  %58 = lshr i64 %57, 32, !dbg !2910
  %59 = trunc i64 %58 to i32, !dbg !2910
  call void @llvm.dbg.value(metadata i32 %59, metadata !616, metadata !DIExpression()), !dbg !2904
  %60 = and i32 %59, 2147483647, !dbg !2911
  call void @llvm.dbg.value(metadata i32 %60, metadata !616, metadata !DIExpression()), !dbg !2904
  %61 = icmp ult i32 %60, 1044381696, !dbg !2912
  %62 = fptosi double %30 to i32
  %63 = icmp eq i32 %62, 0
  %64 = select i1 %61, i1 %63, i1 false, !dbg !2913
  br i1 %64, label %167, label %65, !dbg !2913

65:                                               ; preds = %54
  %66 = fmul double %30, %30, !dbg !2914
  call void @llvm.dbg.value(metadata double %66, metadata !613, metadata !DIExpression()), !dbg !2904
  %67 = tail call double @llvm.fmuladd.f64(double %66, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2915
  %68 = tail call double @llvm.fmuladd.f64(double %66, double %67, double 0xBE927E4F809C52AD), !dbg !2916
  %69 = tail call double @llvm.fmuladd.f64(double %66, double %68, double 0x3EFA01A019CB1590), !dbg !2917
  %70 = tail call double @llvm.fmuladd.f64(double %66, double %69, double 0xBF56C16C16C15177), !dbg !2918
  %71 = tail call double @llvm.fmuladd.f64(double %66, double %70, double 0x3FA555555555554C), !dbg !2919
  %72 = fmul double %66, %71, !dbg !2920
  call void @llvm.dbg.value(metadata double %72, metadata !614, metadata !DIExpression()), !dbg !2904
  %73 = icmp ult i32 %60, 1070805811, !dbg !2921
  br i1 %73, label %74, label %81, !dbg !2922

74:                                               ; preds = %65
  %75 = fneg double %30, !dbg !2923
  %76 = fmul double %56, %75, !dbg !2923
  %77 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %76), !dbg !2923
  %78 = fneg double %77, !dbg !2924
  %79 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %78), !dbg !2924
  %80 = fsub double 1.000000e+00, %79, !dbg !2925
  br label %167, !dbg !2926

81:                                               ; preds = %65
  %82 = icmp ugt i32 %60, 1072234496, !dbg !2927
  %83 = add nsw i32 %60, -2097152, !dbg !2928
  %84 = zext nneg i32 %83 to i64, !dbg !2928
  %85 = shl nuw nsw i64 %84, 32, !dbg !2928
  %86 = bitcast i64 %85 to double, !dbg !2928
  %87 = select i1 %82, double 2.812500e-01, double %86, !dbg !2928
  call void @llvm.dbg.value(metadata double %87, metadata !615, metadata !DIExpression()), !dbg !2904
  %88 = fneg double %87, !dbg !2929
  %89 = tail call double @llvm.fmuladd.f64(double %66, double 5.000000e-01, double %88), !dbg !2929
  call void @llvm.dbg.value(metadata double %89, metadata !612, metadata !DIExpression()), !dbg !2904
  %90 = fsub double 1.000000e+00, %87, !dbg !2930
  call void @llvm.dbg.value(metadata double %90, metadata !611, metadata !DIExpression()), !dbg !2904
  %91 = fneg double %30, !dbg !2931
  %92 = fmul double %56, %91, !dbg !2931
  %93 = tail call double @llvm.fmuladd.f64(double %66, double %72, double %92), !dbg !2931
  %94 = fsub double %93, %89, !dbg !2932
  %95 = fadd double %90, %94, !dbg !2932
  br label %167, !dbg !2933

96:                                               ; preds = %27
  call void @llvm.dbg.value(metadata double %30, metadata !769, metadata !DIExpression()), !dbg !2934
  call void @llvm.dbg.value(metadata double poison, metadata !770, metadata !DIExpression()), !dbg !2934
  call void @llvm.dbg.value(metadata i32 1, metadata !771, metadata !DIExpression()), !dbg !2934
  call void @llvm.dbg.value(metadata double %30, metadata !874, metadata !DIExpression()), !dbg !2936
  %97 = bitcast double %30 to i64, !dbg !2938
  call void @llvm.dbg.value(metadata i64 %97, metadata !879, metadata !DIExpression()), !dbg !2936
  call void @llvm.dbg.value(metadata i64 %97, metadata !776, metadata !DIExpression()), !dbg !2939
  call void @llvm.dbg.value(metadata i64 %97, metadata !775, metadata !DIExpression(DW_OP_constu, 32, DW_OP_shr, DW_OP_LLVM_convert, 64, DW_ATE_unsigned, DW_OP_LLVM_convert, 32, DW_ATE_unsigned, DW_OP_constu, 2143289344, DW_OP_and, DW_OP_stack_value)), !dbg !2934
  %98 = and i64 %97, 9205357638345293824, !dbg !2940
  %99 = icmp ult i64 %98, 4485585228861014016, !dbg !2940
  %100 = fptosi double %30 to i32
  %101 = icmp eq i32 %100, 0
  %102 = select i1 %99, i1 %101, i1 false, !dbg !2941
  br i1 %102, label %119, label %103, !dbg !2941

103:                                              ; preds = %96
  %104 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2942
  %105 = load double, ptr %104, align 8, !dbg !2942, !tbaa !1438
  call void @llvm.dbg.value(metadata double %105, metadata !770, metadata !DIExpression()), !dbg !2934
  %106 = fmul double %30, %30, !dbg !2943
  call void @llvm.dbg.value(metadata double %106, metadata !772, metadata !DIExpression()), !dbg !2934
  call void @llvm.dbg.value(metadata double poison, metadata !774, metadata !DIExpression()), !dbg !2934
  %107 = tail call double @llvm.fmuladd.f64(double %106, double 0x3DE5D93A5ACFD57C, double 0xBE5AE5E68A2B9CEB), !dbg !2944
  %108 = tail call double @llvm.fmuladd.f64(double %106, double %107, double 0x3EC71DE357B1FE7D), !dbg !2945
  %109 = tail call double @llvm.fmuladd.f64(double %106, double %108, double 0xBF2A01A019C161D5), !dbg !2946
  %110 = tail call double @llvm.fmuladd.f64(double %106, double %109, double 0x3F8111111110F8A6), !dbg !2947
  call void @llvm.dbg.value(metadata double %110, metadata !773, metadata !DIExpression()), !dbg !2934
  %111 = fneg double %106, !dbg !2948
  %112 = fmul double %30, %111, !dbg !2948
  %113 = fmul double %112, %110, !dbg !2948
  %114 = tail call double @llvm.fmuladd.f64(double %105, double 5.000000e-01, double %113), !dbg !2948
  %115 = fneg double %105, !dbg !2949
  %116 = tail call double @llvm.fmuladd.f64(double %106, double %114, double %115), !dbg !2949
  %117 = tail call double @llvm.fmuladd.f64(double %112, double 0xBFC5555555555549, double %116), !dbg !2950
  %118 = fsub double %30, %117, !dbg !2951
  br label %119, !dbg !2952

119:                                              ; preds = %96, %103
  %120 = phi double [ %118, %103 ], [ %30, %96 ], !dbg !2934
  %121 = fneg double %120, !dbg !2953
  br label %167, !dbg !2954

122:                                              ; preds = %27
  %123 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !2955
  %124 = load double, ptr %123, align 8, !dbg !2955, !tbaa !1438
  call void @llvm.dbg.value(metadata double %30, metadata !609, metadata !DIExpression()), !dbg !2956
  call void @llvm.dbg.value(metadata double %124, metadata !610, metadata !DIExpression()), !dbg !2956
  call void @llvm.dbg.value(metadata double %30, metadata !874, metadata !DIExpression()), !dbg !2958
  %125 = bitcast double %30 to i64, !dbg !2960
  call void @llvm.dbg.value(metadata i64 %125, metadata !879, metadata !DIExpression()), !dbg !2958
  call void @llvm.dbg.value(metadata i64 %125, metadata !617, metadata !DIExpression()), !dbg !2961
  %126 = lshr i64 %125, 32, !dbg !2962
  %127 = trunc i64 %126 to i32, !dbg !2962
  call void @llvm.dbg.value(metadata i32 %127, metadata !616, metadata !DIExpression()), !dbg !2956
  %128 = and i32 %127, 2147483647, !dbg !2963
  call void @llvm.dbg.value(metadata i32 %128, metadata !616, metadata !DIExpression()), !dbg !2956
  %129 = icmp ult i32 %128, 1044381696, !dbg !2964
  %130 = fptosi double %30 to i32
  %131 = icmp eq i32 %130, 0
  %132 = select i1 %129, i1 %131, i1 false, !dbg !2965
  br i1 %132, label %164, label %133, !dbg !2965

133:                                              ; preds = %122
  %134 = fmul double %30, %30, !dbg !2966
  call void @llvm.dbg.value(metadata double %134, metadata !613, metadata !DIExpression()), !dbg !2956
  %135 = tail call double @llvm.fmuladd.f64(double %134, double 0xBDA8FAE9BE8838D4, double 0x3E21EE9EBDB4B1C4), !dbg !2967
  %136 = tail call double @llvm.fmuladd.f64(double %134, double %135, double 0xBE927E4F809C52AD), !dbg !2968
  %137 = tail call double @llvm.fmuladd.f64(double %134, double %136, double 0x3EFA01A019CB1590), !dbg !2969
  %138 = tail call double @llvm.fmuladd.f64(double %134, double %137, double 0xBF56C16C16C15177), !dbg !2970
  %139 = tail call double @llvm.fmuladd.f64(double %134, double %138, double 0x3FA555555555554C), !dbg !2971
  %140 = fmul double %134, %139, !dbg !2972
  call void @llvm.dbg.value(metadata double %140, metadata !614, metadata !DIExpression()), !dbg !2956
  %141 = icmp ult i32 %128, 1070805811, !dbg !2973
  br i1 %141, label %142, label %149, !dbg !2974

142:                                              ; preds = %133
  %143 = fneg double %30, !dbg !2975
  %144 = fmul double %124, %143, !dbg !2975
  %145 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %144), !dbg !2975
  %146 = fneg double %145, !dbg !2976
  %147 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %146), !dbg !2976
  %148 = fsub double 1.000000e+00, %147, !dbg !2977
  br label %164, !dbg !2978

149:                                              ; preds = %133
  %150 = icmp ugt i32 %128, 1072234496, !dbg !2979
  %151 = add nsw i32 %128, -2097152, !dbg !2980
  %152 = zext nneg i32 %151 to i64, !dbg !2980
  %153 = shl nuw nsw i64 %152, 32, !dbg !2980
  %154 = bitcast i64 %153 to double, !dbg !2980
  %155 = select i1 %150, double 2.812500e-01, double %154, !dbg !2980
  call void @llvm.dbg.value(metadata double %155, metadata !615, metadata !DIExpression()), !dbg !2956
  %156 = fneg double %155, !dbg !2981
  %157 = tail call double @llvm.fmuladd.f64(double %134, double 5.000000e-01, double %156), !dbg !2981
  call void @llvm.dbg.value(metadata double %157, metadata !612, metadata !DIExpression()), !dbg !2956
  %158 = fsub double 1.000000e+00, %155, !dbg !2982
  call void @llvm.dbg.value(metadata double %158, metadata !611, metadata !DIExpression()), !dbg !2956
  %159 = fneg double %30, !dbg !2983
  %160 = fmul double %124, %159, !dbg !2983
  %161 = tail call double @llvm.fmuladd.f64(double %134, double %140, double %160), !dbg !2983
  %162 = fsub double %161, %157, !dbg !2984
  %163 = fadd double %158, %162, !dbg !2984
  br label %164, !dbg !2985

164:                                              ; preds = %122, %142, %149
  %165 = phi double [ %148, %142 ], [ %163, %149 ], [ 1.000000e+00, %122 ], !dbg !2956
  %166 = fneg double %165, !dbg !2986
  br label %167, !dbg !2987

167:                                              ; preds = %81, %74, %54, %38, %31, %14, %8, %164, %119, %25
  %168 = phi double [ %26, %25 ], [ %166, %164 ], [ %121, %119 ], [ %22, %14 ], [ %0, %8 ], [ %53, %38 ], [ %30, %31 ], [ %80, %74 ], [ %95, %81 ], [ 1.000000e+00, %54 ], !dbg !2988
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !2989
  ret double %168, !dbg !2989
}

; Function Attrs: nofree nosync nounwind memory(none) uwtable
define dso_local double @pts_ieee754_tan(double noundef %0) local_unnamed_addr #5 !dbg !2990 {
  %2 = alloca [2 x double], align 8, !DIAssignID !2999
  call void @llvm.dbg.assign(metadata i1 undef, metadata !2993, metadata !DIExpression(), metadata !2999, metadata ptr %2, metadata !DIExpression()), !dbg !3000
  tail call void @llvm.dbg.value(metadata double %0, metadata !2992, metadata !DIExpression()), !dbg !3000
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %2) #11, !dbg !3001
  tail call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !2994, metadata !DIExpression()), !dbg !3000
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !3002
  %3 = bitcast double %0 to i64, !dbg !3004
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !3002
  tail call void @llvm.dbg.value(metadata i64 %3, metadata !2997, metadata !DIExpression()), !dbg !3005
  %4 = lshr i64 %3, 32, !dbg !3006
  %5 = trunc i64 %4 to i32, !dbg !3006
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !2996, metadata !DIExpression()), !dbg !3000
  %6 = and i32 %5, 2147483647, !dbg !3007
  tail call void @llvm.dbg.value(metadata i32 %6, metadata !2996, metadata !DIExpression()), !dbg !3000
  %7 = icmp ult i32 %6, 1072243196, !dbg !3008
  br i1 %7, label %8, label %54, !dbg !3010

8:                                                ; preds = %1
  call void @llvm.dbg.value(metadata double %0, metadata !808, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata i32 1, metadata !810, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !3014
  call void @llvm.dbg.value(metadata i64 %3, metadata !879, metadata !DIExpression()), !dbg !3014
  call void @llvm.dbg.value(metadata i64 %3, metadata !818, metadata !DIExpression()), !dbg !3016
  call void @llvm.dbg.value(metadata i32 %5, metadata !817, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata i32 %6, metadata !816, metadata !DIExpression()), !dbg !3011
  %9 = icmp ult i32 %6, 1043333120, !dbg !3017
  %10 = fptosi double %0 to i32
  %11 = icmp eq i32 %10, 0
  %12 = select i1 %9, i1 %11, i1 false, !dbg !3018
  br i1 %12, label %160, label %13, !dbg !3018

13:                                               ; preds = %8
  %14 = icmp ugt i32 %6, 1072010279, !dbg !3019
  br i1 %14, label %15, label %21, !dbg !3021

15:                                               ; preds = %13
  %16 = icmp slt i64 %3, 0, !dbg !3022
  %17 = fneg double %0, !dbg !3025
  %18 = select i1 %16, double %17, double %0, !dbg !3025
  call void @llvm.dbg.value(metadata double %18, metadata !808, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double poison, metadata !809, metadata !DIExpression()), !dbg !3011
  %19 = fsub double 0x3FE921FB54442D18, %18, !dbg !3026
  call void @llvm.dbg.value(metadata double %19, metadata !811, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double 0x3C81A62633145C07, metadata !814, metadata !DIExpression()), !dbg !3011
  %20 = fadd double %19, 0x3C81A62633145C07, !dbg !3027
  call void @llvm.dbg.value(metadata double %20, metadata !808, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3011
  br label %21, !dbg !3028

21:                                               ; preds = %15, %13
  %22 = phi double [ %20, %15 ], [ %0, %13 ]
  call void @llvm.dbg.value(metadata double %22, metadata !808, metadata !DIExpression()), !dbg !3011
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3011
  %23 = fmul double %22, %22, !dbg !3029
  call void @llvm.dbg.value(metadata double %23, metadata !811, metadata !DIExpression()), !dbg !3011
  %24 = fmul double %23, %23, !dbg !3030
  call void @llvm.dbg.value(metadata double %24, metadata !814, metadata !DIExpression()), !dbg !3011
  %25 = tail call double @llvm.fmuladd.f64(double %24, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3031
  %26 = tail call double @llvm.fmuladd.f64(double %24, double %25, double 0x3F4344D8F2F26501), !dbg !3032
  %27 = tail call double @llvm.fmuladd.f64(double %24, double %26, double 0x3F6D6D22C9560328), !dbg !3033
  %28 = tail call double @llvm.fmuladd.f64(double %24, double %27, double 0x3F9664F48406D637), !dbg !3034
  %29 = tail call double @llvm.fmuladd.f64(double %24, double %28, double 0x3FC111111110FE7A), !dbg !3035
  call void @llvm.dbg.value(metadata double %29, metadata !812, metadata !DIExpression()), !dbg !3011
  %30 = tail call double @llvm.fmuladd.f64(double %24, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3036
  %31 = tail call double @llvm.fmuladd.f64(double %24, double %30, double 0x3F3026F71A8D1068), !dbg !3037
  %32 = tail call double @llvm.fmuladd.f64(double %24, double %31, double 0x3F57DBC8FEE08315), !dbg !3038
  %33 = tail call double @llvm.fmuladd.f64(double %24, double %32, double 0x3F8226E3E96E8493), !dbg !3039
  %34 = tail call double @llvm.fmuladd.f64(double %24, double %33, double 0x3FABA1BA1BB341FE), !dbg !3040
  %35 = fmul double %23, %34, !dbg !3041
  call void @llvm.dbg.value(metadata double %35, metadata !813, metadata !DIExpression()), !dbg !3011
  %36 = fmul double %22, %23, !dbg !3042
  call void @llvm.dbg.value(metadata double %36, metadata !815, metadata !DIExpression()), !dbg !3011
  %37 = fadd double %29, %35, !dbg !3043
  %38 = tail call double @llvm.fmuladd.f64(double %36, double %37, double 0.000000e+00), !dbg !3044
  %39 = tail call double @llvm.fmuladd.f64(double %23, double %38, double 0.000000e+00), !dbg !3045
  call void @llvm.dbg.value(metadata double %39, metadata !812, metadata !DIExpression()), !dbg !3011
  %40 = tail call double @llvm.fmuladd.f64(double %36, double 0x3FD5555555555563, double %39), !dbg !3046
  call void @llvm.dbg.value(metadata double %40, metadata !812, metadata !DIExpression()), !dbg !3011
  %41 = fadd double %22, %40, !dbg !3047
  call void @llvm.dbg.value(metadata double %41, metadata !814, metadata !DIExpression()), !dbg !3011
  br i1 %14, label %42, label %160, !dbg !3048

42:                                               ; preds = %21
  call void @llvm.dbg.value(metadata double 1.000000e+00, metadata !813, metadata !DIExpression()), !dbg !3011
  %43 = lshr i32 %5, 30, !dbg !3049
  %44 = and i32 %43, 2, !dbg !3052
  %45 = sub nsw i32 1, %44, !dbg !3053
  %46 = sitofp i32 %45 to double, !dbg !3054
  %47 = fmul double %41, %41, !dbg !3055
  %48 = fadd double %41, 1.000000e+00, !dbg !3056
  %49 = fdiv double %47, %48, !dbg !3057
  %50 = fsub double %49, %40, !dbg !3058
  %51 = fsub double %22, %50, !dbg !3059
  %52 = tail call double @llvm.fmuladd.f64(double %51, double -2.000000e+00, double 1.000000e+00), !dbg !3060
  %53 = fmul double %52, %46, !dbg !3061
  br label %160, !dbg !3062

54:                                               ; preds = %1
  %55 = icmp ugt i32 %6, 2146435071, !dbg !3063
  br i1 %55, label %56, label %58, !dbg !3065

56:                                               ; preds = %54
  %57 = fsub double %0, %0, !dbg !3066
  br label %160, !dbg !3068

58:                                               ; preds = %54
  %59 = call fastcc i32 @__ieee754_rem_pio2(double noundef %0, ptr noundef nonnull %2), !dbg !3069
  tail call void @llvm.dbg.value(metadata i32 %59, metadata !2995, metadata !DIExpression()), !dbg !3000
  %60 = load double, ptr %2, align 8, !dbg !3071, !tbaa !1438
  %61 = getelementptr inbounds [2 x double], ptr %2, i64 0, i64 1, !dbg !3072
  %62 = load double, ptr %61, align 8, !dbg !3072, !tbaa !1438
  %63 = shl i32 %59, 1, !dbg !3073
  %64 = and i32 %63, 2, !dbg !3073
  %65 = sub nsw i32 1, %64, !dbg !3074
  call void @llvm.dbg.value(metadata double %60, metadata !808, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %62, metadata !809, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata i32 %65, metadata !810, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %60, metadata !874, metadata !DIExpression()), !dbg !3077
  %66 = bitcast double %60 to i64, !dbg !3079
  call void @llvm.dbg.value(metadata i64 %66, metadata !879, metadata !DIExpression()), !dbg !3077
  call void @llvm.dbg.value(metadata i64 %66, metadata !818, metadata !DIExpression()), !dbg !3080
  %67 = lshr i64 %66, 32, !dbg !3081
  %68 = trunc i64 %67 to i32, !dbg !3081
  call void @llvm.dbg.value(metadata i32 %68, metadata !817, metadata !DIExpression()), !dbg !3075
  %69 = and i32 %68, 2147483647, !dbg !3082
  call void @llvm.dbg.value(metadata i32 %69, metadata !816, metadata !DIExpression()), !dbg !3075
  %70 = icmp ult i32 %69, 1043333120, !dbg !3083
  %71 = fptosi double %60 to i32
  %72 = icmp eq i32 %71, 0
  %73 = select i1 %70, i1 %72, i1 false, !dbg !3084
  br i1 %73, label %74, label %99, !dbg !3084

74:                                               ; preds = %58
  call void @llvm.dbg.value(metadata double %60, metadata !874, metadata !DIExpression()), !dbg !3085
  call void @llvm.dbg.value(metadata i64 %66, metadata !879, metadata !DIExpression()), !dbg !3085
  call void @llvm.dbg.value(metadata i64 %66, metadata !825, metadata !DIExpression()), !dbg !3087
  %75 = trunc i64 %66 to i32, !dbg !3088
  call void @llvm.dbg.value(metadata i32 %75, metadata !820, metadata !DIExpression()), !dbg !3089
  %76 = sub nuw nsw i32 2, %64, !dbg !3090
  %77 = or i32 %76, %75, !dbg !3091
  %78 = or i32 %77, %69, !dbg !3091
  %79 = icmp eq i32 %78, 0, !dbg !3092
  br i1 %79, label %80, label %83, !dbg !3093

80:                                               ; preds = %74
  %81 = tail call double @llvm.fabs.f64(double %60), !dbg !3094
  %82 = fdiv double 1.000000e+00, %81, !dbg !3096
  br label %160, !dbg !3097

83:                                               ; preds = %74
  %84 = icmp eq i32 %64, 0, !dbg !3098
  br i1 %84, label %160, label %85, !dbg !3099

85:                                               ; preds = %83
  %86 = fadd double %60, %62, !dbg !3100
  call void @llvm.dbg.value(metadata double %86, metadata !814, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %86, metadata !811, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %86, metadata !874, metadata !DIExpression()), !dbg !3101
  %87 = bitcast double %86 to i64, !dbg !3103
  call void @llvm.dbg.value(metadata i64 %87, metadata !879, metadata !DIExpression()), !dbg !3101
  call void @llvm.dbg.value(metadata i64 %87, metadata !833, metadata !DIExpression()), !dbg !3104
  %88 = and i64 %87, -4294967296, !dbg !3105
  call void @llvm.dbg.value(metadata i64 %88, metadata !833, metadata !DIExpression()), !dbg !3104
  call void @llvm.dbg.value(metadata i64 %88, metadata !948, metadata !DIExpression()), !dbg !3106
  %89 = bitcast i64 %88 to double, !dbg !3108
  call void @llvm.dbg.value(metadata double %89, metadata !953, metadata !DIExpression()), !dbg !3106
  call void @llvm.dbg.value(metadata double %89, metadata !811, metadata !DIExpression()), !dbg !3075
  %90 = fsub double %89, %60, !dbg !3109
  %91 = fsub double %62, %90, !dbg !3110
  call void @llvm.dbg.value(metadata double %91, metadata !813, metadata !DIExpression()), !dbg !3075
  %92 = fdiv double -1.000000e+00, %86, !dbg !3111
  call void @llvm.dbg.value(metadata double %92, metadata !827, metadata !DIExpression()), !dbg !3112
  call void @llvm.dbg.value(metadata double %92, metadata !832, metadata !DIExpression()), !dbg !3112
  call void @llvm.dbg.value(metadata double %92, metadata !874, metadata !DIExpression()), !dbg !3113
  %93 = bitcast double %92 to i64, !dbg !3115
  call void @llvm.dbg.value(metadata i64 %93, metadata !879, metadata !DIExpression()), !dbg !3113
  call void @llvm.dbg.value(metadata i64 %93, metadata !835, metadata !DIExpression()), !dbg !3116
  %94 = and i64 %93, -4294967296, !dbg !3117
  call void @llvm.dbg.value(metadata i64 %94, metadata !835, metadata !DIExpression()), !dbg !3116
  call void @llvm.dbg.value(metadata i64 %94, metadata !948, metadata !DIExpression()), !dbg !3118
  %95 = bitcast i64 %94 to double, !dbg !3120
  call void @llvm.dbg.value(metadata double %95, metadata !953, metadata !DIExpression()), !dbg !3118
  call void @llvm.dbg.value(metadata double %95, metadata !832, metadata !DIExpression()), !dbg !3112
  %96 = tail call double @llvm.fmuladd.f64(double %95, double %89, double 1.000000e+00), !dbg !3121
  call void @llvm.dbg.value(metadata double %96, metadata !815, metadata !DIExpression()), !dbg !3075
  %97 = tail call double @llvm.fmuladd.f64(double %95, double %91, double %96), !dbg !3122
  %98 = tail call double @llvm.fmuladd.f64(double %92, double %97, double %95), !dbg !3123
  br label %160

99:                                               ; preds = %58
  %100 = icmp ugt i32 %69, 1072010279, !dbg !3124
  br i1 %100, label %101, label %110, !dbg !3125

101:                                              ; preds = %99
  %102 = icmp slt i64 %66, 0, !dbg !3126
  %103 = fneg double %60, !dbg !3127
  %104 = fneg double %62, !dbg !3127
  %105 = select i1 %102, double %104, double %62, !dbg !3127
  %106 = select i1 %102, double %103, double %60, !dbg !3127
  call void @llvm.dbg.value(metadata double %106, metadata !808, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %105, metadata !809, metadata !DIExpression()), !dbg !3075
  %107 = fsub double 0x3FE921FB54442D18, %106, !dbg !3128
  call void @llvm.dbg.value(metadata double %107, metadata !811, metadata !DIExpression()), !dbg !3075
  %108 = fsub double 0x3C81A62633145C07, %105, !dbg !3129
  call void @llvm.dbg.value(metadata double %108, metadata !814, metadata !DIExpression()), !dbg !3075
  %109 = fadd double %107, %108, !dbg !3130
  call void @llvm.dbg.value(metadata double %109, metadata !808, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double 0.000000e+00, metadata !809, metadata !DIExpression()), !dbg !3075
  br label %110, !dbg !3131

110:                                              ; preds = %101, %99
  %111 = phi double [ 0.000000e+00, %101 ], [ %62, %99 ]
  %112 = phi double [ %109, %101 ], [ %60, %99 ]
  call void @llvm.dbg.value(metadata double %112, metadata !808, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %111, metadata !809, metadata !DIExpression()), !dbg !3075
  %113 = fmul double %112, %112, !dbg !3132
  call void @llvm.dbg.value(metadata double %113, metadata !811, metadata !DIExpression()), !dbg !3075
  %114 = fmul double %113, %113, !dbg !3133
  call void @llvm.dbg.value(metadata double %114, metadata !814, metadata !DIExpression()), !dbg !3075
  %115 = tail call double @llvm.fmuladd.f64(double %114, double 0xBEF375CBDB605373, double 0x3F147E88A03792A6), !dbg !3134
  %116 = tail call double @llvm.fmuladd.f64(double %114, double %115, double 0x3F4344D8F2F26501), !dbg !3135
  %117 = tail call double @llvm.fmuladd.f64(double %114, double %116, double 0x3F6D6D22C9560328), !dbg !3136
  %118 = tail call double @llvm.fmuladd.f64(double %114, double %117, double 0x3F9664F48406D637), !dbg !3137
  %119 = tail call double @llvm.fmuladd.f64(double %114, double %118, double 0x3FC111111110FE7A), !dbg !3138
  call void @llvm.dbg.value(metadata double %119, metadata !812, metadata !DIExpression()), !dbg !3075
  %120 = tail call double @llvm.fmuladd.f64(double %114, double 0x3EFB2A7074BF7AD4, double 0x3F12B80F32F0A7E9), !dbg !3139
  %121 = tail call double @llvm.fmuladd.f64(double %114, double %120, double 0x3F3026F71A8D1068), !dbg !3140
  %122 = tail call double @llvm.fmuladd.f64(double %114, double %121, double 0x3F57DBC8FEE08315), !dbg !3141
  %123 = tail call double @llvm.fmuladd.f64(double %114, double %122, double 0x3F8226E3E96E8493), !dbg !3142
  %124 = tail call double @llvm.fmuladd.f64(double %114, double %123, double 0x3FABA1BA1BB341FE), !dbg !3143
  %125 = fmul double %113, %124, !dbg !3144
  call void @llvm.dbg.value(metadata double %125, metadata !813, metadata !DIExpression()), !dbg !3075
  %126 = fmul double %112, %113, !dbg !3145
  call void @llvm.dbg.value(metadata double %126, metadata !815, metadata !DIExpression()), !dbg !3075
  %127 = fadd double %119, %125, !dbg !3146
  %128 = tail call double @llvm.fmuladd.f64(double %126, double %127, double %111), !dbg !3147
  %129 = tail call double @llvm.fmuladd.f64(double %113, double %128, double %111), !dbg !3148
  call void @llvm.dbg.value(metadata double %129, metadata !812, metadata !DIExpression()), !dbg !3075
  %130 = tail call double @llvm.fmuladd.f64(double %126, double 0x3FD5555555555563, double %129), !dbg !3149
  call void @llvm.dbg.value(metadata double %130, metadata !812, metadata !DIExpression()), !dbg !3075
  %131 = fadd double %112, %130, !dbg !3150
  call void @llvm.dbg.value(metadata double %131, metadata !814, metadata !DIExpression()), !dbg !3075
  br i1 %100, label %132, label %145, !dbg !3151

132:                                              ; preds = %110
  %133 = sitofp i32 %65 to double, !dbg !3152
  call void @llvm.dbg.value(metadata double %133, metadata !813, metadata !DIExpression()), !dbg !3075
  %134 = lshr i32 %68, 30, !dbg !3153
  %135 = and i32 %134, 2, !dbg !3154
  %136 = sub nsw i32 1, %135, !dbg !3155
  %137 = sitofp i32 %136 to double, !dbg !3156
  %138 = fmul double %131, %131, !dbg !3157
  %139 = fadd double %131, %133, !dbg !3158
  %140 = fdiv double %138, %139, !dbg !3159
  %141 = fsub double %140, %130, !dbg !3160
  %142 = fsub double %112, %141, !dbg !3161
  %143 = tail call double @llvm.fmuladd.f64(double %142, double -2.000000e+00, double %133), !dbg !3162
  %144 = fmul double %143, %137, !dbg !3163
  br label %160, !dbg !3164

145:                                              ; preds = %110
  %146 = icmp eq i32 %64, 0, !dbg !3165
  br i1 %146, label %160, label %147, !dbg !3166

147:                                              ; preds = %145
  call void @llvm.dbg.value(metadata double %131, metadata !811, metadata !DIExpression()), !dbg !3075
  call void @llvm.dbg.value(metadata double %131, metadata !874, metadata !DIExpression()), !dbg !3167
  %148 = bitcast double %131 to i64, !dbg !3169
  call void @llvm.dbg.value(metadata i64 %148, metadata !879, metadata !DIExpression()), !dbg !3167
  call void @llvm.dbg.value(metadata i64 %148, metadata !841, metadata !DIExpression()), !dbg !3170
  %149 = and i64 %148, -4294967296, !dbg !3171
  call void @llvm.dbg.value(metadata i64 %149, metadata !841, metadata !DIExpression()), !dbg !3170
  call void @llvm.dbg.value(metadata i64 %149, metadata !948, metadata !DIExpression()), !dbg !3172
  %150 = bitcast i64 %149 to double, !dbg !3174
  call void @llvm.dbg.value(metadata double %150, metadata !953, metadata !DIExpression()), !dbg !3172
  call void @llvm.dbg.value(metadata double %150, metadata !811, metadata !DIExpression()), !dbg !3075
  %151 = fsub double %150, %112, !dbg !3175
  %152 = fsub double %130, %151, !dbg !3176
  call void @llvm.dbg.value(metadata double %152, metadata !813, metadata !DIExpression()), !dbg !3075
  %153 = fdiv double -1.000000e+00, %131, !dbg !3177
  call void @llvm.dbg.value(metadata double %153, metadata !837, metadata !DIExpression()), !dbg !3178
  call void @llvm.dbg.value(metadata double %153, metadata !840, metadata !DIExpression()), !dbg !3178
  call void @llvm.dbg.value(metadata double %153, metadata !874, metadata !DIExpression()), !dbg !3179
  %154 = bitcast double %153 to i64, !dbg !3181
  call void @llvm.dbg.value(metadata i64 %154, metadata !879, metadata !DIExpression()), !dbg !3179
  call void @llvm.dbg.value(metadata i64 %154, metadata !843, metadata !DIExpression()), !dbg !3182
  %155 = and i64 %154, -4294967296, !dbg !3183
  call void @llvm.dbg.value(metadata i64 %155, metadata !843, metadata !DIExpression()), !dbg !3182
  call void @llvm.dbg.value(metadata i64 %155, metadata !948, metadata !DIExpression()), !dbg !3184
  %156 = bitcast i64 %155 to double, !dbg !3186
  call void @llvm.dbg.value(metadata double %156, metadata !953, metadata !DIExpression()), !dbg !3184
  call void @llvm.dbg.value(metadata double %156, metadata !840, metadata !DIExpression()), !dbg !3178
  %157 = tail call double @llvm.fmuladd.f64(double %156, double %150, double 1.000000e+00), !dbg !3187
  call void @llvm.dbg.value(metadata double %157, metadata !815, metadata !DIExpression()), !dbg !3075
  %158 = tail call double @llvm.fmuladd.f64(double %156, double %152, double %157), !dbg !3188
  %159 = tail call double @llvm.fmuladd.f64(double %153, double %158, double %156), !dbg !3189
  br label %160

160:                                              ; preds = %8, %147, %145, %132, %85, %83, %80, %42, %21, %56
  %161 = phi double [ %57, %56 ], [ %53, %42 ], [ %41, %21 ], [ %144, %132 ], [ %159, %147 ], [ %82, %80 ], [ %98, %85 ], [ %60, %83 ], [ %131, %145 ], [ %0, %8 ], !dbg !3190
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %2) #11, !dbg !3191
  ret double %161, !dbg !3191
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_cosh(double noundef %0) local_unnamed_addr #7 !dbg !545 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !547, metadata !DIExpression()), !dbg !3192
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !3193
  %2 = bitcast double %0 to i64, !dbg !3195
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !3193
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !549, metadata !DIExpression()), !dbg !3196
  %3 = lshr i64 %2, 32, !dbg !3197
  %4 = trunc i64 %3 to i32, !dbg !3197
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !548, metadata !DIExpression()), !dbg !3192
  %5 = and i32 %4, 2147483647, !dbg !3198
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !548, metadata !DIExpression()), !dbg !3192
  %6 = icmp ult i32 %5, 1071001155, !dbg !3199
  br i1 %6, label %7, label %17, !dbg !3200

7:                                                ; preds = %1
  %8 = tail call double @llvm.fabs.f64(double %0), !dbg !3201
  %9 = tail call double @pts_ieee754_expm1(double noundef %8), !dbg !3202
  tail call void @llvm.dbg.value(metadata double %9, metadata !551, metadata !DIExpression()), !dbg !3203
  %10 = fadd double %9, 1.000000e+00, !dbg !3204
  tail call void @llvm.dbg.value(metadata double %10, metadata !554, metadata !DIExpression()), !dbg !3203
  %11 = icmp ult i32 %5, 1015021568, !dbg !3205
  br i1 %11, label %45, label %12, !dbg !3207

12:                                               ; preds = %7
  %13 = fmul double %9, %9, !dbg !3208
  %14 = fadd double %10, %10, !dbg !3209
  %15 = fdiv double %13, %14, !dbg !3210
  %16 = fadd double %15, 1.000000e+00, !dbg !3211
  br label %45, !dbg !3212

17:                                               ; preds = %1
  %18 = icmp ult i32 %5, 1077280768, !dbg !3213
  br i1 %18, label %19, label %24, !dbg !3214

19:                                               ; preds = %17
  %20 = tail call double @llvm.fabs.f64(double %0), !dbg !3215
  %21 = tail call double @pts_ieee754_exp(double noundef %20), !dbg !3216
  tail call void @llvm.dbg.value(metadata double %21, metadata !555, metadata !DIExpression()), !dbg !3217
  %22 = fdiv double 5.000000e-01, %21, !dbg !3218
  %23 = tail call double @llvm.fmuladd.f64(double %21, double 5.000000e-01, double %22), !dbg !3219
  br label %45

24:                                               ; preds = %17
  %25 = icmp ult i32 %5, 1082535490, !dbg !3220
  %26 = tail call double @llvm.fabs.f64(double %0), !dbg !3192
  br i1 %25, label %27, label %30, !dbg !3222

27:                                               ; preds = %24
  %28 = tail call double @pts_ieee754_exp(double noundef %26), !dbg !3223
  %29 = fmul double %28, 5.000000e-01, !dbg !3224
  br label %45, !dbg !3225

30:                                               ; preds = %24
  %31 = fcmp ugt double %26, 0x408633CE8FB9F87D, !dbg !3226
  br i1 %31, label %37, label %32, !dbg !3227

32:                                               ; preds = %30
  %33 = fmul double %26, 5.000000e-01, !dbg !3228
  %34 = tail call double @pts_ieee754_exp(double noundef %33), !dbg !3229
  tail call void @llvm.dbg.value(metadata double %34, metadata !558, metadata !DIExpression()), !dbg !3230
  %35 = fmul double %34, 5.000000e-01, !dbg !3231
  tail call void @llvm.dbg.value(metadata double %35, metadata !561, metadata !DIExpression()), !dbg !3230
  %36 = fmul double %34, %35, !dbg !3232
  br label %45

37:                                               ; preds = %30
  %38 = icmp ugt i32 %5, 2146435071, !dbg !3233
  br i1 %38, label %39, label %41, !dbg !3235

39:                                               ; preds = %37
  %40 = fmul double %0, %0, !dbg !3236
  br label %45, !dbg !3237

41:                                               ; preds = %37
  %42 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3238, !tbaa !1438
  %43 = load volatile double, ptr @pts_ieee754_cosh.huge, align 8, !dbg !3239, !tbaa !1438
  %44 = fmul double %42, %43, !dbg !3240
  br label %45, !dbg !3241

45:                                               ; preds = %12, %7, %41, %39, %32, %27, %19
  %46 = phi double [ %23, %19 ], [ %29, %27 ], [ %36, %32 ], [ %40, %39 ], [ %44, %41 ], [ %16, %12 ], [ %10, %7 ], !dbg !3192
  ret double %46, !dbg !3242
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_sinh(double noundef %0) local_unnamed_addr #7 !dbg !570 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !572, metadata !DIExpression()), !dbg !3243
  %2 = fcmp olt double %0, 0.000000e+00, !dbg !3244
  %3 = select i1 %2, double -5.000000e-01, double 5.000000e-01, !dbg !3245
  tail call void @llvm.dbg.value(metadata double %3, metadata !573, metadata !DIExpression()), !dbg !3243
  %4 = tail call double @llvm.fabs.f64(double %0), !dbg !3246
  tail call void @llvm.dbg.value(metadata double %4, metadata !574, metadata !DIExpression()), !dbg !3243
  %5 = fcmp olt double %4, 2.200000e+01, !dbg !3247
  br i1 %5, label %6, label %23, !dbg !3248

6:                                                ; preds = %1
  %7 = fcmp olt double %4, 0x3E30000000000000, !dbg !3249
  br i1 %7, label %37, label %8, !dbg !3251

8:                                                ; preds = %6
  %9 = tail call double @pts_ieee754_expm1(double noundef %4), !dbg !3252
  tail call void @llvm.dbg.value(metadata double %9, metadata !575, metadata !DIExpression()), !dbg !3253
  %10 = fcmp olt double %4, 1.000000e+00, !dbg !3254
  %11 = fadd double %9, 1.000000e+00, !dbg !3253
  br i1 %10, label %12, label %17, !dbg !3256

12:                                               ; preds = %8
  %13 = fneg double %9, !dbg !3257
  %14 = fmul double %9, %13, !dbg !3257
  %15 = fdiv double %14, %11, !dbg !3257
  %16 = tail call double @llvm.fmuladd.f64(double %9, double 2.000000e+00, double %15), !dbg !3257
  br label %20, !dbg !3259

17:                                               ; preds = %8
  %18 = fdiv double %9, %11, !dbg !3260
  %19 = fadd double %9, %18, !dbg !3261
  br label %20, !dbg !3262

20:                                               ; preds = %17, %12
  %21 = phi double [ %16, %12 ], [ %19, %17 ]
  %22 = fmul double %3, %21, !dbg !3253
  br label %37

23:                                               ; preds = %1
  %24 = fcmp olt double %4, 0x40862E4200000000, !dbg !3263
  br i1 %24, label %25, label %28, !dbg !3265

25:                                               ; preds = %23
  %26 = tail call double @pts_ieee754_exp(double noundef %4), !dbg !3266
  %27 = fmul double %3, %26, !dbg !3267
  br label %37, !dbg !3268

28:                                               ; preds = %23
  %29 = fcmp ugt double %4, 0x408633CE8FB9F87D, !dbg !3269
  br i1 %29, label %35, label %30, !dbg !3270

30:                                               ; preds = %28
  %31 = fmul double %4, 5.000000e-01, !dbg !3271
  %32 = tail call double @pts_ieee754_exp(double noundef %31), !dbg !3272
  tail call void @llvm.dbg.value(metadata double %32, metadata !578, metadata !DIExpression()), !dbg !3273
  %33 = fmul double %3, %32, !dbg !3274
  tail call void @llvm.dbg.value(metadata double %33, metadata !581, metadata !DIExpression()), !dbg !3273
  %34 = fmul double %32, %33, !dbg !3275
  br label %37

35:                                               ; preds = %28
  %36 = fmul double %0, 0x7FAC7B1F3CAC7433, !dbg !3276
  br label %37, !dbg !3277

37:                                               ; preds = %6, %35, %30, %25, %20
  %38 = phi double [ %22, %20 ], [ %27, %25 ], [ %34, %30 ], [ %36, %35 ], [ %0, %6 ], !dbg !3243
  ret double %38, !dbg !3278
}

; Function Attrs: mustprogress nofree norecurse nounwind willreturn uwtable
define dso_local double @pts_ieee754_tanh(double noundef %0) local_unnamed_addr #7 !dbg !590 {
  tail call void @llvm.dbg.value(metadata double %0, metadata !592, metadata !DIExpression()), !dbg !3279
  tail call void @llvm.dbg.value(metadata double %0, metadata !874, metadata !DIExpression()), !dbg !3280
  %2 = bitcast double %0 to i64, !dbg !3282
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !879, metadata !DIExpression()), !dbg !3280
  tail call void @llvm.dbg.value(metadata i64 %2, metadata !597, metadata !DIExpression()), !dbg !3283
  %3 = lshr i64 %2, 32, !dbg !3284
  %4 = trunc i64 %3 to i32, !dbg !3284
  tail call void @llvm.dbg.value(metadata i32 %4, metadata !595, metadata !DIExpression()), !dbg !3279
  %5 = and i32 %4, 2147483647, !dbg !3285
  tail call void @llvm.dbg.value(metadata i32 %5, metadata !596, metadata !DIExpression()), !dbg !3279
  %6 = icmp ugt i32 %5, 2146435071, !dbg !3286
  br i1 %6, label %7, label %14, !dbg !3288

7:                                                ; preds = %1
  %8 = icmp sgt i64 %2, -1, !dbg !3289
  %9 = fdiv double 1.000000e+00, %0, !dbg !3292
  br i1 %8, label %10, label %12, !dbg !3293

10:                                               ; preds = %7
  %11 = fadd double %9, 1.000000e+00, !dbg !3294
  br label %44, !dbg !3295

12:                                               ; preds = %7
  %13 = fadd double %9, -1.000000e+00, !dbg !3296
  br label %44, !dbg !3297

14:                                               ; preds = %1
  %15 = icmp ult i32 %5, 1077280768, !dbg !3298
  br i1 %15, label %16, label %36, !dbg !3300

16:                                               ; preds = %14
  %17 = icmp ult i32 %5, 1043333120, !dbg !3301
  %18 = fadd double %0, 1.000000e+300
  %19 = fcmp ogt double %18, 1.000000e+00
  %20 = and i1 %19, %17, !dbg !3304
  br i1 %20, label %44, label %21, !dbg !3304

21:                                               ; preds = %16
  %22 = icmp ugt i32 %5, 1072693247, !dbg !3305
  %23 = tail call double @llvm.fabs.f64(double %0), !dbg !3307
  br i1 %22, label %24, label %30, !dbg !3308

24:                                               ; preds = %21
  %25 = fmul double %23, 2.000000e+00, !dbg !3309
  %26 = tail call double @pts_ieee754_expm1(double noundef %25), !dbg !3311
  tail call void @llvm.dbg.value(metadata double %26, metadata !593, metadata !DIExpression()), !dbg !3279
  %27 = fadd double %26, 2.000000e+00, !dbg !3312
  %28 = fdiv double 2.000000e+00, %27, !dbg !3313
  %29 = fsub double 1.000000e+00, %28, !dbg !3314
  tail call void @llvm.dbg.value(metadata double %29, metadata !594, metadata !DIExpression()), !dbg !3279
  br label %39, !dbg !3315

30:                                               ; preds = %21
  %31 = fmul double %23, -2.000000e+00, !dbg !3316
  %32 = tail call double @pts_ieee754_expm1(double noundef %31), !dbg !3318
  tail call void @llvm.dbg.value(metadata double %32, metadata !593, metadata !DIExpression()), !dbg !3279
  %33 = fneg double %32, !dbg !3319
  %34 = fadd double %32, 2.000000e+00, !dbg !3320
  %35 = fdiv double %33, %34, !dbg !3321
  tail call void @llvm.dbg.value(metadata double %35, metadata !594, metadata !DIExpression()), !dbg !3279
  br label %39

36:                                               ; preds = %14
  %37 = load volatile double, ptr @pts_ieee754_tanh.tiny, align 8, !dbg !3322, !tbaa !1438
  %38 = fsub double 1.000000e+00, %37, !dbg !3324
  tail call void @llvm.dbg.value(metadata double %38, metadata !594, metadata !DIExpression()), !dbg !3279
  br label %39

39:                                               ; preds = %24, %30, %36
  %40 = phi double [ %29, %24 ], [ %35, %30 ], [ %38, %36 ], !dbg !3325
  tail call void @llvm.dbg.value(metadata double %40, metadata !594, metadata !DIExpression()), !dbg !3279
  %41 = fneg double %40, !dbg !3326
  %42 = icmp slt i64 %2, 0, !dbg !3326
  %43 = select i1 %42, double %41, double %40, !dbg !3326
  br label %44, !dbg !3327

44:                                               ; preds = %16, %39, %12, %10
  %45 = phi double [ %11, %10 ], [ %13, %12 ], [ %43, %39 ], [ %0, %16 ], !dbg !3279
  ret double %45, !dbg !3328
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.label(metadata) #2

; Function Attrs: mustprogress nofree nosync nounwind willreturn memory(none)
declare !dbg !3329 double @scalbn(double noundef, i32 noundef) local_unnamed_addr #8

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.assign(metadata, metadata, metadata, metadata, metadata, metadata) #2

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare void @llvm.dbg.value(metadata, metadata, metadata) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.smax.i32(i32, i32) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #9

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #10

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.vector.reduce.fadd.v2f64(double, <2 x double>) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.vector.reduce.or.v4i32(<4 x i32>) #9

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #3 = { mustprogress nofree norecurse nounwind willreturn memory(inaccessiblemem: readwrite) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #4 = { mustprogress nofree norecurse nounwind willreturn memory(readwrite, argmem: none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #5 = { nofree nosync nounwind memory(none) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #6 = { nofree nosync nounwind memory(argmem: write) uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #7 = { mustprogress nofree norecurse nounwind willreturn uwtable "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #8 = { mustprogress nofree nosync nounwind willreturn memory(none) "frame-pointer"="non-leaf" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+fp-armv8,+neon,+outline-atomics,+v8a,-fmv" }
attributes #9 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #11 = { nounwind }
attributes #12 = { nounwind willreturn memory(none) }

!llvm.dbg.cu = !{!7}
!llvm.module.flags = !{!864, !865, !866, !867, !868, !869, !870, !871}
!llvm.ident = !{!872}

!0 = !DIGlobalVariableExpression(var: !1, expr: !DIExpression())
!1 = distinct !DIGlobalVariable(name: "atanhi", scope: !2, file: !3, line: 1148, type: !156, isLocal: true, isDefinition: true)
!2 = distinct !DISubprogram(name: "pts_ieee754_atan", scope: !3, file: !3, line: 1147, type: !4, scopeLine: 1147, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !848)
!3 = !DIFile(filename: "../src/ieee754_head.c", directory: "/tmp/pts-h36/repro/clang_on", checksumkind: CSK_MD5, checksum: "5651070fafa2d14650842267211b7bd6")
!4 = !DISubroutineType(types: !5)
!5 = !{!6, !6}
!6 = !DIBasicType(name: "double", size: 64, encoding: DW_ATE_float)
!7 = distinct !DICompileUnit(language: DW_LANG_C11, file: !3, producer: "Ubuntu clang version 18.1.3 (1ubuntu1)", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, retainedTypes: !8, globals: !19, splitDebugInlining: false, nameTableKind: None)
!8 = !{!9, !12, !15, !16, !18, !6}
!9 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint32_t", file: !10, line: 198, baseType: !11)
!10 = !DIFile(filename: "/usr/lib/llvm-18/lib/clang/18/include/stdint.h", directory: "", checksumkind: CSK_MD5, checksum: "da031bcff2d0c1d65aa92e7e68a44ef3")
!11 = !DIBasicType(name: "unsigned int", size: 32, encoding: DW_ATE_unsigned)
!12 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !13, size: 64)
!13 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !14)
!14 = !DIDerivedType(tag: DW_TAG_volatile_type, baseType: !6)
!15 = !DIBasicType(name: "int", size: 32, encoding: DW_ATE_signed)
!16 = !DIDerivedType(tag: DW_TAG_typedef, name: "uint64_t", file: !10, line: 98, baseType: !17)
!17 = !DIBasicType(name: "unsigned long", size: 64, encoding: DW_ATE_unsigned)
!18 = !DIDerivedType(tag: DW_TAG_typedef, name: "int32_t", file: !10, line: 193, baseType: !15)
!19 = !{!20, !48, !50, !52, !54, !56, !58, !60, !62, !64, !66, !68, !70, !72, !74, !84, !86, !111, !113, !115, !117, !119, !121, !123, !125, !127, !129, !131, !133, !135, !137, !139, !150, !152, !0, !154, !159, !164, !166, !168, !189, !191, !193, !195, !197, !199, !229, !234, !236, !238, !240, !242, !244, !246, !248, !250, !252, !254, !256, !258, !260, !262, !275, !277, !279, !306, !308, !310, !312, !314, !316, !318, !320, !322, !324, !326, !360, !362, !364, !366, !368, !370, !372, !374, !376, !378, !380, !408, !410, !412, !435, !437, !439, !441, !481, !483, !485, !487, !489, !491, !493, !495, !497, !499, !501, !503, !531, !533, !535, !537, !539, !541, !543, !562, !564, !566, !568, !582, !584, !586, !588, !599, !601, !603, !605, !625, !627, !629, !631, !633, !635, !637, !686, !691, !693, !695, !697, !699, !701, !703, !705, !707, !709, !711, !750, !755, !757, !759, !761, !763, !778, !780, !782, !784, !786, !788, !790, !792, !794, !796, !798, !800, !802, !804}
!20 = !DIGlobalVariableExpression(var: !21, expr: !DIExpression())
!21 = distinct !DIGlobalVariable(name: "one", scope: !22, file: !3, line: 895, type: !47, isLocal: true, isDefinition: true)
!22 = distinct !DISubprogram(name: "pts_ieee754_acos", scope: !3, file: !3, line: 893, type: !4, scopeLine: 893, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !23)
!23 = !{!24, !25, !26, !27, !28, !29, !30, !31, !32, !33, !34, !35, !37, !40, !42}
!24 = !DILocalVariable(name: "x", arg: 1, scope: !22, file: !3, line: 893, type: !6)
!25 = !DILocalVariable(name: "z", scope: !22, file: !3, line: 910, type: !6)
!26 = !DILocalVariable(name: "p", scope: !22, file: !3, line: 910, type: !6)
!27 = !DILocalVariable(name: "q", scope: !22, file: !3, line: 910, type: !6)
!28 = !DILocalVariable(name: "r", scope: !22, file: !3, line: 910, type: !6)
!29 = !DILocalVariable(name: "w", scope: !22, file: !3, line: 910, type: !6)
!30 = !DILocalVariable(name: "s", scope: !22, file: !3, line: 910, type: !6)
!31 = !DILocalVariable(name: "c", scope: !22, file: !3, line: 910, type: !6)
!32 = !DILocalVariable(name: "df", scope: !22, file: !3, line: 910, type: !6)
!33 = !DILocalVariable(name: "hx", scope: !22, file: !3, line: 911, type: !18)
!34 = !DILocalVariable(name: "ix", scope: !22, file: !3, line: 911, type: !18)
!35 = !DILocalVariable(name: "bits", scope: !36, file: !3, line: 912, type: !16)
!36 = distinct !DILexicalBlock(scope: !22, file: !3, line: 912, column: 3)
!37 = !DILocalVariable(name: "lx", scope: !38, file: !3, line: 915, type: !9)
!38 = distinct !DILexicalBlock(scope: !39, file: !3, line: 914, column: 25)
!39 = distinct !DILexicalBlock(scope: !22, file: !3, line: 914, column: 7)
!40 = !DILocalVariable(name: "bits", scope: !41, file: !3, line: 916, type: !16)
!41 = distinct !DILexicalBlock(scope: !38, file: !3, line: 916, column: 5)
!42 = !DILocalVariable(name: "bits", scope: !43, file: !3, line: 944, type: !16)
!43 = distinct !DILexicalBlock(scope: !44, file: !3, line: 944, column: 5)
!44 = distinct !DILexicalBlock(scope: !45, file: !3, line: 940, column: 10)
!45 = distinct !DILexicalBlock(scope: !46, file: !3, line: 932, column: 14)
!46 = distinct !DILexicalBlock(scope: !22, file: !3, line: 925, column: 7)
!47 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !6)
!48 = !DIGlobalVariableExpression(var: !49, expr: !DIExpression())
!49 = distinct !DIGlobalVariable(name: "pi", scope: !22, file: !3, line: 896, type: !47, isLocal: true, isDefinition: true)
!50 = !DIGlobalVariableExpression(var: !51, expr: !DIExpression())
!51 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !22, file: !3, line: 897, type: !47, isLocal: true, isDefinition: true)
!52 = !DIGlobalVariableExpression(var: !53, expr: !DIExpression())
!53 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !22, file: !3, line: 898, type: !47, isLocal: true, isDefinition: true)
!54 = !DIGlobalVariableExpression(var: !55, expr: !DIExpression())
!55 = distinct !DIGlobalVariable(name: "pS0", scope: !22, file: !3, line: 899, type: !47, isLocal: true, isDefinition: true)
!56 = !DIGlobalVariableExpression(var: !57, expr: !DIExpression())
!57 = distinct !DIGlobalVariable(name: "pS1", scope: !22, file: !3, line: 900, type: !47, isLocal: true, isDefinition: true)
!58 = !DIGlobalVariableExpression(var: !59, expr: !DIExpression())
!59 = distinct !DIGlobalVariable(name: "pS2", scope: !22, file: !3, line: 901, type: !47, isLocal: true, isDefinition: true)
!60 = !DIGlobalVariableExpression(var: !61, expr: !DIExpression())
!61 = distinct !DIGlobalVariable(name: "pS3", scope: !22, file: !3, line: 902, type: !47, isLocal: true, isDefinition: true)
!62 = !DIGlobalVariableExpression(var: !63, expr: !DIExpression())
!63 = distinct !DIGlobalVariable(name: "pS4", scope: !22, file: !3, line: 903, type: !47, isLocal: true, isDefinition: true)
!64 = !DIGlobalVariableExpression(var: !65, expr: !DIExpression())
!65 = distinct !DIGlobalVariable(name: "pS5", scope: !22, file: !3, line: 904, type: !47, isLocal: true, isDefinition: true)
!66 = !DIGlobalVariableExpression(var: !67, expr: !DIExpression())
!67 = distinct !DIGlobalVariable(name: "qS1", scope: !22, file: !3, line: 905, type: !47, isLocal: true, isDefinition: true)
!68 = !DIGlobalVariableExpression(var: !69, expr: !DIExpression())
!69 = distinct !DIGlobalVariable(name: "qS2", scope: !22, file: !3, line: 906, type: !47, isLocal: true, isDefinition: true)
!70 = !DIGlobalVariableExpression(var: !71, expr: !DIExpression())
!71 = distinct !DIGlobalVariable(name: "qS3", scope: !22, file: !3, line: 907, type: !47, isLocal: true, isDefinition: true)
!72 = !DIGlobalVariableExpression(var: !73, expr: !DIExpression())
!73 = distinct !DIGlobalVariable(name: "qS4", scope: !22, file: !3, line: 908, type: !47, isLocal: true, isDefinition: true)
!74 = !DIGlobalVariableExpression(var: !75, expr: !DIExpression())
!75 = distinct !DIGlobalVariable(name: "one", scope: !76, file: !3, line: 969, type: !47, isLocal: true, isDefinition: true)
!76 = distinct !DISubprogram(name: "pts_ieee754_acosh", scope: !3, file: !3, line: 967, type: !4, scopeLine: 967, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !77)
!77 = !{!78, !79, !80, !81, !82}
!78 = !DILocalVariable(name: "x", arg: 1, scope: !76, file: !3, line: 967, type: !6)
!79 = !DILocalVariable(name: "t", scope: !76, file: !3, line: 971, type: !6)
!80 = !DILocalVariable(name: "hx", scope: !76, file: !3, line: 972, type: !18)
!81 = !DILocalVariable(name: "lx", scope: !76, file: !3, line: 973, type: !9)
!82 = !DILocalVariable(name: "bits", scope: !83, file: !3, line: 974, type: !16)
!83 = distinct !DILexicalBlock(scope: !76, file: !3, line: 974, column: 3)
!84 = !DIGlobalVariableExpression(var: !85, expr: !DIExpression())
!85 = distinct !DIGlobalVariable(name: "ln2", scope: !76, file: !3, line: 970, type: !47, isLocal: true, isDefinition: true)
!86 = !DIGlobalVariableExpression(var: !87, expr: !DIExpression())
!87 = distinct !DIGlobalVariable(name: "one", scope: !88, file: !3, line: 1024, type: !47, isLocal: true, isDefinition: true)
!88 = distinct !DISubprogram(name: "pts_ieee754_asin", scope: !3, file: !3, line: 1022, type: !4, scopeLine: 1022, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !89)
!89 = !{!90, !91, !92, !93, !94, !95, !96, !97, !98, !99, !100, !102, !105, !107}
!90 = !DILocalVariable(name: "x", arg: 1, scope: !88, file: !3, line: 1022, type: !6)
!91 = !DILocalVariable(name: "t", scope: !88, file: !3, line: 1041, type: !6)
!92 = !DILocalVariable(name: "w", scope: !88, file: !3, line: 1041, type: !6)
!93 = !DILocalVariable(name: "p", scope: !88, file: !3, line: 1041, type: !6)
!94 = !DILocalVariable(name: "q", scope: !88, file: !3, line: 1041, type: !6)
!95 = !DILocalVariable(name: "c", scope: !88, file: !3, line: 1041, type: !6)
!96 = !DILocalVariable(name: "r", scope: !88, file: !3, line: 1041, type: !6)
!97 = !DILocalVariable(name: "s", scope: !88, file: !3, line: 1041, type: !6)
!98 = !DILocalVariable(name: "hx", scope: !88, file: !3, line: 1042, type: !18)
!99 = !DILocalVariable(name: "ix", scope: !88, file: !3, line: 1042, type: !18)
!100 = !DILocalVariable(name: "bits", scope: !101, file: !3, line: 1045, type: !16)
!101 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1045, column: 3)
!102 = !DILocalVariable(name: "lx", scope: !103, file: !3, line: 1048, type: !9)
!103 = distinct !DILexicalBlock(scope: !104, file: !3, line: 1047, column: 25)
!104 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1047, column: 7)
!105 = !DILocalVariable(name: "bits", scope: !106, file: !3, line: 1049, type: !16)
!106 = distinct !DILexicalBlock(scope: !103, file: !3, line: 1049, column: 5)
!107 = !DILocalVariable(name: "bits", scope: !108, file: !3, line: 1076, type: !16)
!108 = distinct !DILexicalBlock(scope: !109, file: !3, line: 1076, column: 5)
!109 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1074, column: 10)
!110 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1071, column: 7)
!111 = !DIGlobalVariableExpression(var: !112, expr: !DIExpression())
!112 = distinct !DIGlobalVariable(name: "huge", scope: !88, file: !3, line: 1025, type: !47, isLocal: true, isDefinition: true)
!113 = !DIGlobalVariableExpression(var: !114, expr: !DIExpression())
!114 = distinct !DIGlobalVariable(name: "pio2_hi", scope: !88, file: !3, line: 1026, type: !47, isLocal: true, isDefinition: true)
!115 = !DIGlobalVariableExpression(var: !116, expr: !DIExpression())
!116 = distinct !DIGlobalVariable(name: "pio2_lo", scope: !88, file: !3, line: 1027, type: !47, isLocal: true, isDefinition: true)
!117 = !DIGlobalVariableExpression(var: !118, expr: !DIExpression())
!118 = distinct !DIGlobalVariable(name: "pio4_hi", scope: !88, file: !3, line: 1028, type: !47, isLocal: true, isDefinition: true)
!119 = !DIGlobalVariableExpression(var: !120, expr: !DIExpression())
!120 = distinct !DIGlobalVariable(name: "pS0", scope: !88, file: !3, line: 1030, type: !47, isLocal: true, isDefinition: true)
!121 = !DIGlobalVariableExpression(var: !122, expr: !DIExpression())
!122 = distinct !DIGlobalVariable(name: "pS1", scope: !88, file: !3, line: 1031, type: !47, isLocal: true, isDefinition: true)
!123 = !DIGlobalVariableExpression(var: !124, expr: !DIExpression())
!124 = distinct !DIGlobalVariable(name: "pS2", scope: !88, file: !3, line: 1032, type: !47, isLocal: true, isDefinition: true)
!125 = !DIGlobalVariableExpression(var: !126, expr: !DIExpression())
!126 = distinct !DIGlobalVariable(name: "pS3", scope: !88, file: !3, line: 1033, type: !47, isLocal: true, isDefinition: true)
!127 = !DIGlobalVariableExpression(var: !128, expr: !DIExpression())
!128 = distinct !DIGlobalVariable(name: "pS4", scope: !88, file: !3, line: 1034, type: !47, isLocal: true, isDefinition: true)
!129 = !DIGlobalVariableExpression(var: !130, expr: !DIExpression())
!130 = distinct !DIGlobalVariable(name: "pS5", scope: !88, file: !3, line: 1035, type: !47, isLocal: true, isDefinition: true)
!131 = !DIGlobalVariableExpression(var: !132, expr: !DIExpression())
!132 = distinct !DIGlobalVariable(name: "qS1", scope: !88, file: !3, line: 1036, type: !47, isLocal: true, isDefinition: true)
!133 = !DIGlobalVariableExpression(var: !134, expr: !DIExpression())
!134 = distinct !DIGlobalVariable(name: "qS2", scope: !88, file: !3, line: 1037, type: !47, isLocal: true, isDefinition: true)
!135 = !DIGlobalVariableExpression(var: !136, expr: !DIExpression())
!136 = distinct !DIGlobalVariable(name: "qS3", scope: !88, file: !3, line: 1038, type: !47, isLocal: true, isDefinition: true)
!137 = !DIGlobalVariableExpression(var: !138, expr: !DIExpression())
!138 = distinct !DIGlobalVariable(name: "qS4", scope: !88, file: !3, line: 1039, type: !47, isLocal: true, isDefinition: true)
!139 = !DIGlobalVariableExpression(var: !140, expr: !DIExpression())
!140 = distinct !DIGlobalVariable(name: "one", scope: !141, file: !3, line: 1100, type: !47, isLocal: true, isDefinition: true)
!141 = distinct !DISubprogram(name: "pts_ieee754_asinh", scope: !3, file: !3, line: 1098, type: !4, scopeLine: 1098, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !142)
!142 = !{!143, !144, !145, !146, !147, !148}
!143 = !DILocalVariable(name: "x", arg: 1, scope: !141, file: !3, line: 1098, type: !6)
!144 = !DILocalVariable(name: "t", scope: !141, file: !3, line: 1104, type: !6)
!145 = !DILocalVariable(name: "w", scope: !141, file: !3, line: 1104, type: !6)
!146 = !DILocalVariable(name: "hx", scope: !141, file: !3, line: 1105, type: !18)
!147 = !DILocalVariable(name: "ix", scope: !141, file: !3, line: 1105, type: !18)
!148 = !DILocalVariable(name: "bits", scope: !149, file: !3, line: 1106, type: !16)
!149 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1106, column: 3)
!150 = !DIGlobalVariableExpression(var: !151, expr: !DIExpression())
!151 = distinct !DIGlobalVariable(name: "ln2", scope: !141, file: !3, line: 1101, type: !47, isLocal: true, isDefinition: true)
!152 = !DIGlobalVariableExpression(var: !153, expr: !DIExpression())
!153 = distinct !DIGlobalVariable(name: "huge", scope: !141, file: !3, line: 1102, type: !47, isLocal: true, isDefinition: true)
!154 = !DIGlobalVariableExpression(var: !155, expr: !DIExpression())
!155 = distinct !DIGlobalVariable(name: "atanlo", scope: !2, file: !3, line: 1155, type: !156, isLocal: true, isDefinition: true)
!156 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 256, elements: !157)
!157 = !{!158}
!158 = !DISubrange(count: 4)
!159 = !DIGlobalVariableExpression(var: !160, expr: !DIExpression())
!160 = distinct !DIGlobalVariable(name: "aT", scope: !2, file: !3, line: 1162, type: !161, isLocal: true, isDefinition: true)
!161 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 704, elements: !162)
!162 = !{!163}
!163 = !DISubrange(count: 11)
!164 = !DIGlobalVariableExpression(var: !165, expr: !DIExpression())
!165 = distinct !DIGlobalVariable(name: "one", scope: !2, file: !3, line: 1176, type: !47, isLocal: true, isDefinition: true)
!166 = !DIGlobalVariableExpression(var: !167, expr: !DIExpression())
!167 = distinct !DIGlobalVariable(name: "huge", scope: !2, file: !3, line: 1176, type: !47, isLocal: true, isDefinition: true)
!168 = !DIGlobalVariableExpression(var: !169, expr: !DIExpression())
!169 = distinct !DIGlobalVariable(name: "tiny", scope: !170, file: !3, line: 1260, type: !14, isLocal: true, isDefinition: true)
!170 = distinct !DISubprogram(name: "pts_ieee754_atan2", scope: !3, file: !3, line: 1259, type: !171, scopeLine: 1259, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !173)
!171 = !DISubroutineType(types: !172)
!172 = !{!6, !6, !6}
!173 = !{!174, !175, !176, !177, !178, !179, !180, !181, !182, !183, !184, !185, !187}
!174 = !DILocalVariable(name: "y", arg: 1, scope: !170, file: !3, line: 1259, type: !6)
!175 = !DILocalVariable(name: "x", arg: 2, scope: !170, file: !3, line: 1259, type: !6)
!176 = !DILocalVariable(name: "z", scope: !170, file: !3, line: 1269, type: !6)
!177 = !DILocalVariable(name: "k", scope: !170, file: !3, line: 1270, type: !18)
!178 = !DILocalVariable(name: "m", scope: !170, file: !3, line: 1270, type: !18)
!179 = !DILocalVariable(name: "hx", scope: !170, file: !3, line: 1270, type: !18)
!180 = !DILocalVariable(name: "hy", scope: !170, file: !3, line: 1270, type: !18)
!181 = !DILocalVariable(name: "ix", scope: !170, file: !3, line: 1270, type: !18)
!182 = !DILocalVariable(name: "iy", scope: !170, file: !3, line: 1270, type: !18)
!183 = !DILocalVariable(name: "lx", scope: !170, file: !3, line: 1271, type: !9)
!184 = !DILocalVariable(name: "ly", scope: !170, file: !3, line: 1271, type: !9)
!185 = !DILocalVariable(name: "bits", scope: !186, file: !3, line: 1273, type: !16)
!186 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1273, column: 3)
!187 = !DILocalVariable(name: "bits", scope: !188, file: !3, line: 1275, type: !16)
!188 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1275, column: 3)
!189 = !DIGlobalVariableExpression(var: !190, expr: !DIExpression())
!190 = distinct !DIGlobalVariable(name: "zero", scope: !170, file: !3, line: 1262, type: !47, isLocal: true, isDefinition: true)
!191 = !DIGlobalVariableExpression(var: !192, expr: !DIExpression())
!192 = distinct !DIGlobalVariable(name: "pi_o_4", scope: !170, file: !3, line: 1263, type: !47, isLocal: true, isDefinition: true)
!193 = !DIGlobalVariableExpression(var: !194, expr: !DIExpression())
!194 = distinct !DIGlobalVariable(name: "pi_o_2", scope: !170, file: !3, line: 1264, type: !47, isLocal: true, isDefinition: true)
!195 = !DIGlobalVariableExpression(var: !196, expr: !DIExpression())
!196 = distinct !DIGlobalVariable(name: "pi", scope: !170, file: !3, line: 1265, type: !47, isLocal: true, isDefinition: true)
!197 = !DIGlobalVariableExpression(var: !198, expr: !DIExpression())
!198 = distinct !DIGlobalVariable(name: "pi_lo", scope: !170, file: !3, line: 1266, type: !14, isLocal: true, isDefinition: true)
!199 = !DIGlobalVariableExpression(var: !200, expr: !DIExpression())
!200 = distinct !DIGlobalVariable(name: "one", scope: !201, file: !3, line: 1476, type: !47, isLocal: true, isDefinition: true)
!201 = distinct !DISubprogram(name: "pts_ieee754_exp", scope: !3, file: !3, line: 1474, type: !4, scopeLine: 1474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !202)
!202 = !{!203, !204, !205, !206, !207, !208, !209, !210, !211, !212, !213, !215, !220, !222, !226}
!203 = !DILocalVariable(name: "x", arg: 1, scope: !201, file: !3, line: 1474, type: !6)
!204 = !DILocalVariable(name: "y", scope: !201, file: !3, line: 1497, type: !6)
!205 = !DILocalVariable(name: "hi", scope: !201, file: !3, line: 1497, type: !6)
!206 = !DILocalVariable(name: "lo", scope: !201, file: !3, line: 1497, type: !6)
!207 = !DILocalVariable(name: "c", scope: !201, file: !3, line: 1497, type: !6)
!208 = !DILocalVariable(name: "t", scope: !201, file: !3, line: 1497, type: !6)
!209 = !DILocalVariable(name: "twopk", scope: !201, file: !3, line: 1497, type: !6)
!210 = !DILocalVariable(name: "k", scope: !201, file: !3, line: 1498, type: !18)
!211 = !DILocalVariable(name: "xsb", scope: !201, file: !3, line: 1498, type: !18)
!212 = !DILocalVariable(name: "hx", scope: !201, file: !3, line: 1499, type: !9)
!213 = !DILocalVariable(name: "bits", scope: !214, file: !3, line: 1501, type: !16)
!214 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1501, column: 3)
!215 = !DILocalVariable(name: "lx", scope: !216, file: !3, line: 1508, type: !9)
!216 = distinct !DILexicalBlock(scope: !217, file: !3, line: 1507, column: 27)
!217 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1507, column: 9)
!218 = distinct !DILexicalBlock(scope: !219, file: !3, line: 1506, column: 25)
!219 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1506, column: 7)
!220 = !DILocalVariable(name: "bits", scope: !221, file: !3, line: 1509, type: !16)
!221 = distinct !DILexicalBlock(scope: !216, file: !3, line: 1509, column: 7)
!222 = !DILocalVariable(name: "bits", scope: !223, file: !3, line: 1546, type: !16)
!223 = distinct !DILexicalBlock(scope: !224, file: !3, line: 1546, column: 5)
!224 = distinct !DILexicalBlock(scope: !225, file: !3, line: 1545, column: 19)
!225 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1545, column: 7)
!226 = !DILocalVariable(name: "bits", scope: !227, file: !3, line: 1550, type: !16)
!227 = distinct !DILexicalBlock(scope: !228, file: !3, line: 1550, column: 5)
!228 = distinct !DILexicalBlock(scope: !225, file: !3, line: 1549, column: 10)
!229 = !DIGlobalVariableExpression(var: !230, expr: !DIExpression())
!230 = distinct !DIGlobalVariable(name: "halF", scope: !201, file: !3, line: 1477, type: !231, isLocal: true, isDefinition: true)
!231 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 128, elements: !232)
!232 = !{!233}
!233 = !DISubrange(count: 2)
!234 = !DIGlobalVariableExpression(var: !235, expr: !DIExpression())
!235 = distinct !DIGlobalVariable(name: "o_threshold", scope: !201, file: !3, line: 1478, type: !47, isLocal: true, isDefinition: true)
!236 = !DIGlobalVariableExpression(var: !237, expr: !DIExpression())
!237 = distinct !DIGlobalVariable(name: "u_threshold", scope: !201, file: !3, line: 1479, type: !47, isLocal: true, isDefinition: true)
!238 = !DIGlobalVariableExpression(var: !239, expr: !DIExpression())
!239 = distinct !DIGlobalVariable(name: "ln2HI", scope: !201, file: !3, line: 1480, type: !231, isLocal: true, isDefinition: true)
!240 = !DIGlobalVariableExpression(var: !241, expr: !DIExpression())
!241 = distinct !DIGlobalVariable(name: "ln2LO", scope: !201, file: !3, line: 1482, type: !231, isLocal: true, isDefinition: true)
!242 = !DIGlobalVariableExpression(var: !243, expr: !DIExpression())
!243 = distinct !DIGlobalVariable(name: "invln2", scope: !201, file: !3, line: 1484, type: !47, isLocal: true, isDefinition: true)
!244 = !DIGlobalVariableExpression(var: !245, expr: !DIExpression())
!245 = distinct !DIGlobalVariable(name: "P1", scope: !201, file: !3, line: 1485, type: !47, isLocal: true, isDefinition: true)
!246 = !DIGlobalVariableExpression(var: !247, expr: !DIExpression())
!247 = distinct !DIGlobalVariable(name: "P2", scope: !201, file: !3, line: 1486, type: !47, isLocal: true, isDefinition: true)
!248 = !DIGlobalVariableExpression(var: !249, expr: !DIExpression())
!249 = distinct !DIGlobalVariable(name: "P3", scope: !201, file: !3, line: 1487, type: !47, isLocal: true, isDefinition: true)
!250 = !DIGlobalVariableExpression(var: !251, expr: !DIExpression())
!251 = distinct !DIGlobalVariable(name: "P4", scope: !201, file: !3, line: 1488, type: !47, isLocal: true, isDefinition: true)
!252 = !DIGlobalVariableExpression(var: !253, expr: !DIExpression())
!253 = distinct !DIGlobalVariable(name: "P5", scope: !201, file: !3, line: 1489, type: !47, isLocal: true, isDefinition: true)
!254 = !DIGlobalVariableExpression(var: !255, expr: !DIExpression())
!255 = distinct !DIGlobalVariable(name: "E", scope: !201, file: !3, line: 1490, type: !47, isLocal: true, isDefinition: true)
!256 = !DIGlobalVariableExpression(var: !257, expr: !DIExpression())
!257 = distinct !DIGlobalVariable(name: "huge", scope: !201, file: !3, line: 1493, type: !14, isLocal: true, isDefinition: true)
!258 = !DIGlobalVariableExpression(var: !259, expr: !DIExpression())
!259 = distinct !DIGlobalVariable(name: "twom1000", scope: !201, file: !3, line: 1494, type: !14, isLocal: true, isDefinition: true)
!260 = !DIGlobalVariableExpression(var: !261, expr: !DIExpression())
!261 = distinct !DIGlobalVariable(name: "two1023", scope: !201, file: !3, line: 1495, type: !14, isLocal: true, isDefinition: true)
!262 = !DIGlobalVariableExpression(var: !263, expr: !DIExpression())
!263 = distinct !DIGlobalVariable(name: "one", scope: !264, file: !3, line: 1585, type: !47, isLocal: true, isDefinition: true)
!264 = distinct !DISubprogram(name: "pts_ieee754_atanh", scope: !3, file: !3, line: 1584, type: !4, scopeLine: 1584, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !265)
!265 = !{!266, !267, !268, !269, !270, !271, !273}
!266 = !DILocalVariable(name: "x", arg: 1, scope: !264, file: !3, line: 1584, type: !6)
!267 = !DILocalVariable(name: "t", scope: !264, file: !3, line: 1588, type: !6)
!268 = !DILocalVariable(name: "hx", scope: !264, file: !3, line: 1589, type: !18)
!269 = !DILocalVariable(name: "ix", scope: !264, file: !3, line: 1589, type: !18)
!270 = !DILocalVariable(name: "lx", scope: !264, file: !3, line: 1590, type: !9)
!271 = !DILocalVariable(name: "bits", scope: !272, file: !3, line: 1591, type: !16)
!272 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1591, column: 3)
!273 = !DILocalVariable(name: "bits", scope: !274, file: !3, line: 1602, type: !16)
!274 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1602, column: 3)
!275 = !DIGlobalVariableExpression(var: !276, expr: !DIExpression())
!276 = distinct !DIGlobalVariable(name: "huge", scope: !264, file: !3, line: 1585, type: !47, isLocal: true, isDefinition: true)
!277 = !DIGlobalVariableExpression(var: !278, expr: !DIExpression())
!278 = distinct !DIGlobalVariable(name: "zero", scope: !264, file: !3, line: 1586, type: !47, isLocal: true, isDefinition: true)
!279 = !DIGlobalVariableExpression(var: !280, expr: !DIExpression())
!280 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !281, file: !3, line: 1667, type: !47, isLocal: true, isDefinition: true)
!281 = distinct !DISubprogram(name: "pts_ieee754_log", scope: !3, file: !3, line: 1665, type: !4, scopeLine: 1665, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !282)
!282 = !{!283, !284, !285, !286, !287, !288, !289, !290, !291, !292, !293, !294, !295, !296, !297, !298, !300, !304}
!283 = !DILocalVariable(name: "x", arg: 1, scope: !281, file: !3, line: 1665, type: !6)
!284 = !DILocalVariable(name: "hfsq", scope: !281, file: !3, line: 1680, type: !6)
!285 = !DILocalVariable(name: "f", scope: !281, file: !3, line: 1680, type: !6)
!286 = !DILocalVariable(name: "s", scope: !281, file: !3, line: 1680, type: !6)
!287 = !DILocalVariable(name: "z", scope: !281, file: !3, line: 1680, type: !6)
!288 = !DILocalVariable(name: "R", scope: !281, file: !3, line: 1680, type: !6)
!289 = !DILocalVariable(name: "w", scope: !281, file: !3, line: 1680, type: !6)
!290 = !DILocalVariable(name: "t1", scope: !281, file: !3, line: 1680, type: !6)
!291 = !DILocalVariable(name: "t2", scope: !281, file: !3, line: 1680, type: !6)
!292 = !DILocalVariable(name: "dk", scope: !281, file: !3, line: 1680, type: !6)
!293 = !DILocalVariable(name: "k", scope: !281, file: !3, line: 1681, type: !18)
!294 = !DILocalVariable(name: "hx", scope: !281, file: !3, line: 1681, type: !18)
!295 = !DILocalVariable(name: "i", scope: !281, file: !3, line: 1681, type: !18)
!296 = !DILocalVariable(name: "j", scope: !281, file: !3, line: 1681, type: !18)
!297 = !DILocalVariable(name: "lx", scope: !281, file: !3, line: 1682, type: !9)
!298 = !DILocalVariable(name: "bits", scope: !299, file: !3, line: 1684, type: !16)
!299 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1684, column: 3)
!300 = !DILocalVariable(name: "bits", scope: !301, file: !3, line: 1696, type: !16)
!301 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1696, column: 5)
!302 = distinct !DILexicalBlock(scope: !303, file: !3, line: 1687, column: 24)
!303 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1687, column: 7)
!304 = !DILocalVariable(name: "bits", scope: !305, file: !3, line: 1702, type: !16)
!305 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1702, column: 3)
!306 = !DIGlobalVariableExpression(var: !307, expr: !DIExpression())
!307 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !281, file: !3, line: 1668, type: !47, isLocal: true, isDefinition: true)
!308 = !DIGlobalVariableExpression(var: !309, expr: !DIExpression())
!309 = distinct !DIGlobalVariable(name: "two54", scope: !281, file: !3, line: 1669, type: !47, isLocal: true, isDefinition: true)
!310 = !DIGlobalVariableExpression(var: !311, expr: !DIExpression())
!311 = distinct !DIGlobalVariable(name: "Lg1", scope: !281, file: !3, line: 1670, type: !47, isLocal: true, isDefinition: true)
!312 = !DIGlobalVariableExpression(var: !313, expr: !DIExpression())
!313 = distinct !DIGlobalVariable(name: "Lg2", scope: !281, file: !3, line: 1671, type: !47, isLocal: true, isDefinition: true)
!314 = !DIGlobalVariableExpression(var: !315, expr: !DIExpression())
!315 = distinct !DIGlobalVariable(name: "Lg3", scope: !281, file: !3, line: 1672, type: !47, isLocal: true, isDefinition: true)
!316 = !DIGlobalVariableExpression(var: !317, expr: !DIExpression())
!317 = distinct !DIGlobalVariable(name: "Lg4", scope: !281, file: !3, line: 1673, type: !47, isLocal: true, isDefinition: true)
!318 = !DIGlobalVariableExpression(var: !319, expr: !DIExpression())
!319 = distinct !DIGlobalVariable(name: "Lg5", scope: !281, file: !3, line: 1674, type: !47, isLocal: true, isDefinition: true)
!320 = !DIGlobalVariableExpression(var: !321, expr: !DIExpression())
!321 = distinct !DIGlobalVariable(name: "Lg6", scope: !281, file: !3, line: 1675, type: !47, isLocal: true, isDefinition: true)
!322 = !DIGlobalVariableExpression(var: !323, expr: !DIExpression())
!323 = distinct !DIGlobalVariable(name: "Lg7", scope: !281, file: !3, line: 1676, type: !47, isLocal: true, isDefinition: true)
!324 = !DIGlobalVariableExpression(var: !325, expr: !DIExpression())
!325 = distinct !DIGlobalVariable(name: "zero", scope: !281, file: !3, line: 1678, type: !47, isLocal: true, isDefinition: true)
!326 = !DIGlobalVariableExpression(var: !327, expr: !DIExpression())
!327 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !328, file: !3, line: 1812, type: !47, isLocal: true, isDefinition: true)
!328 = distinct !DISubprogram(name: "pts_ieee754_log1p", scope: !3, file: !3, line: 1810, type: !4, scopeLine: 1810, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !329)
!329 = !{!330, !331, !332, !333, !334, !335, !336, !337, !338, !339, !340, !341, !342, !344, !350, !353, !357}
!330 = !DILocalVariable(name: "x", arg: 1, scope: !328, file: !3, line: 1810, type: !6)
!331 = !DILocalVariable(name: "hfsq", scope: !328, file: !3, line: 1825, type: !6)
!332 = !DILocalVariable(name: "f", scope: !328, file: !3, line: 1825, type: !6)
!333 = !DILocalVariable(name: "c", scope: !328, file: !3, line: 1825, type: !6)
!334 = !DILocalVariable(name: "s", scope: !328, file: !3, line: 1825, type: !6)
!335 = !DILocalVariable(name: "z", scope: !328, file: !3, line: 1825, type: !6)
!336 = !DILocalVariable(name: "R", scope: !328, file: !3, line: 1825, type: !6)
!337 = !DILocalVariable(name: "u", scope: !328, file: !3, line: 1825, type: !6)
!338 = !DILocalVariable(name: "k", scope: !328, file: !3, line: 1826, type: !18)
!339 = !DILocalVariable(name: "hx", scope: !328, file: !3, line: 1826, type: !18)
!340 = !DILocalVariable(name: "hu", scope: !328, file: !3, line: 1826, type: !18)
!341 = !DILocalVariable(name: "ax", scope: !328, file: !3, line: 1826, type: !18)
!342 = !DILocalVariable(name: "bits", scope: !343, file: !3, line: 1828, type: !16)
!343 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1828, column: 3)
!344 = !DILocalVariable(name: "bits", scope: !345, file: !3, line: 1856, type: !16)
!345 = distinct !DILexicalBlock(scope: !346, file: !3, line: 1856, column: 7)
!346 = distinct !DILexicalBlock(scope: !347, file: !3, line: 1854, column: 26)
!347 = distinct !DILexicalBlock(scope: !348, file: !3, line: 1854, column: 9)
!348 = distinct !DILexicalBlock(scope: !349, file: !3, line: 1853, column: 15)
!349 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1853, column: 7)
!350 = !DILocalVariable(name: "bits", scope: !351, file: !3, line: 1862, type: !16)
!351 = distinct !DILexicalBlock(scope: !352, file: !3, line: 1862, column: 7)
!352 = distinct !DILexicalBlock(scope: !347, file: !3, line: 1860, column: 12)
!353 = !DILocalVariable(name: "bits", scope: !354, file: !3, line: 1875, type: !16)
!354 = distinct !DILexicalBlock(scope: !355, file: !3, line: 1875, column: 7)
!355 = distinct !DILexicalBlock(scope: !356, file: !3, line: 1874, column: 23)
!356 = distinct !DILexicalBlock(scope: !348, file: !3, line: 1874, column: 9)
!357 = !DILocalVariable(name: "bits", scope: !358, file: !3, line: 1878, type: !16)
!358 = distinct !DILexicalBlock(scope: !359, file: !3, line: 1878, column: 7)
!359 = distinct !DILexicalBlock(scope: !356, file: !3, line: 1876, column: 12)
!360 = !DIGlobalVariableExpression(var: !361, expr: !DIExpression())
!361 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !328, file: !3, line: 1813, type: !47, isLocal: true, isDefinition: true)
!362 = !DIGlobalVariableExpression(var: !363, expr: !DIExpression())
!363 = distinct !DIGlobalVariable(name: "two54", scope: !328, file: !3, line: 1814, type: !47, isLocal: true, isDefinition: true)
!364 = !DIGlobalVariableExpression(var: !365, expr: !DIExpression())
!365 = distinct !DIGlobalVariable(name: "Lp1", scope: !328, file: !3, line: 1815, type: !47, isLocal: true, isDefinition: true)
!366 = !DIGlobalVariableExpression(var: !367, expr: !DIExpression())
!367 = distinct !DIGlobalVariable(name: "Lp2", scope: !328, file: !3, line: 1816, type: !47, isLocal: true, isDefinition: true)
!368 = !DIGlobalVariableExpression(var: !369, expr: !DIExpression())
!369 = distinct !DIGlobalVariable(name: "Lp3", scope: !328, file: !3, line: 1817, type: !47, isLocal: true, isDefinition: true)
!370 = !DIGlobalVariableExpression(var: !371, expr: !DIExpression())
!371 = distinct !DIGlobalVariable(name: "Lp4", scope: !328, file: !3, line: 1818, type: !47, isLocal: true, isDefinition: true)
!372 = !DIGlobalVariableExpression(var: !373, expr: !DIExpression())
!373 = distinct !DIGlobalVariable(name: "Lp5", scope: !328, file: !3, line: 1819, type: !47, isLocal: true, isDefinition: true)
!374 = !DIGlobalVariableExpression(var: !375, expr: !DIExpression())
!375 = distinct !DIGlobalVariable(name: "Lp6", scope: !328, file: !3, line: 1820, type: !47, isLocal: true, isDefinition: true)
!376 = !DIGlobalVariableExpression(var: !377, expr: !DIExpression())
!377 = distinct !DIGlobalVariable(name: "Lp7", scope: !328, file: !3, line: 1821, type: !47, isLocal: true, isDefinition: true)
!378 = !DIGlobalVariableExpression(var: !379, expr: !DIExpression())
!379 = distinct !DIGlobalVariable(name: "zero", scope: !328, file: !3, line: 1823, type: !47, isLocal: true, isDefinition: true)
!380 = !DIGlobalVariableExpression(var: !381, expr: !DIExpression())
!381 = distinct !DIGlobalVariable(name: "two54", scope: !382, file: !3, line: 2002, type: !47, isLocal: true, isDefinition: true)
!382 = distinct !DISubprogram(name: "pts_ieee754_log2", scope: !3, file: !3, line: 2000, type: !4, scopeLine: 2000, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !383)
!383 = !{!384, !385, !386, !387, !388, !389, !390, !391, !392, !393, !394, !395, !396, !397, !398, !400, !404, !406}
!384 = !DILocalVariable(name: "x", arg: 1, scope: !382, file: !3, line: 2000, type: !6)
!385 = !DILocalVariable(name: "f", scope: !382, file: !3, line: 2006, type: !6)
!386 = !DILocalVariable(name: "hfsq", scope: !382, file: !3, line: 2006, type: !6)
!387 = !DILocalVariable(name: "hi", scope: !382, file: !3, line: 2006, type: !6)
!388 = !DILocalVariable(name: "lo", scope: !382, file: !3, line: 2006, type: !6)
!389 = !DILocalVariable(name: "r", scope: !382, file: !3, line: 2006, type: !6)
!390 = !DILocalVariable(name: "val_hi", scope: !382, file: !3, line: 2006, type: !6)
!391 = !DILocalVariable(name: "val_lo", scope: !382, file: !3, line: 2006, type: !6)
!392 = !DILocalVariable(name: "w", scope: !382, file: !3, line: 2006, type: !6)
!393 = !DILocalVariable(name: "y", scope: !382, file: !3, line: 2006, type: !6)
!394 = !DILocalVariable(name: "i", scope: !382, file: !3, line: 2007, type: !18)
!395 = !DILocalVariable(name: "k", scope: !382, file: !3, line: 2007, type: !18)
!396 = !DILocalVariable(name: "hx", scope: !382, file: !3, line: 2007, type: !18)
!397 = !DILocalVariable(name: "lx", scope: !382, file: !3, line: 2008, type: !9)
!398 = !DILocalVariable(name: "bits", scope: !399, file: !3, line: 2010, type: !16)
!399 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2010, column: 3)
!400 = !DILocalVariable(name: "bits", scope: !401, file: !3, line: 2022, type: !16)
!401 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2022, column: 5)
!402 = distinct !DILexicalBlock(scope: !403, file: !3, line: 2013, column: 24)
!403 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2013, column: 7)
!404 = !DILocalVariable(name: "bits", scope: !405, file: !3, line: 2029, type: !16)
!405 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2029, column: 3)
!406 = !DILocalVariable(name: "bits", scope: !407, file: !3, line: 2067, type: !16)
!407 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2067, column: 3)
!408 = !DIGlobalVariableExpression(var: !409, expr: !DIExpression())
!409 = distinct !DIGlobalVariable(name: "ivln2hi", scope: !382, file: !3, line: 2003, type: !47, isLocal: true, isDefinition: true)
!410 = !DIGlobalVariableExpression(var: !411, expr: !DIExpression())
!411 = distinct !DIGlobalVariable(name: "ivln2lo", scope: !382, file: !3, line: 2004, type: !47, isLocal: true, isDefinition: true)
!412 = !DIGlobalVariableExpression(var: !413, expr: !DIExpression())
!413 = distinct !DIGlobalVariable(name: "two54", scope: !414, file: !3, line: 2108, type: !47, isLocal: true, isDefinition: true)
!414 = distinct !DISubprogram(name: "pts_ieee754_log10", scope: !3, file: !3, line: 2106, type: !4, scopeLine: 2106, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !415)
!415 = !{!416, !417, !418, !419, !420, !421, !422, !424, !428, !430, !432, !434}
!416 = !DILocalVariable(name: "x", arg: 1, scope: !414, file: !3, line: 2106, type: !6)
!417 = !DILocalVariable(name: "y", scope: !414, file: !3, line: 2113, type: !6)
!418 = !DILocalVariable(name: "i", scope: !414, file: !3, line: 2114, type: !18)
!419 = !DILocalVariable(name: "k", scope: !414, file: !3, line: 2114, type: !18)
!420 = !DILocalVariable(name: "hx", scope: !414, file: !3, line: 2114, type: !18)
!421 = !DILocalVariable(name: "lx", scope: !414, file: !3, line: 2115, type: !9)
!422 = !DILocalVariable(name: "bits", scope: !423, file: !3, line: 2117, type: !16)
!423 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2117, column: 3)
!424 = !DILocalVariable(name: "bits", scope: !425, file: !3, line: 2129, type: !16)
!425 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2129, column: 5)
!426 = distinct !DILexicalBlock(scope: !427, file: !3, line: 2120, column: 24)
!427 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2120, column: 7)
!428 = !DILocalVariable(name: "bits", scope: !429, file: !3, line: 2130, type: !16)
!429 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2130, column: 5)
!430 = !DILocalVariable(name: "bits", scope: !431, file: !3, line: 2139, type: !16)
!431 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2139, column: 3)
!432 = !DILocalVariable(name: "bits", scope: !433, file: !3, line: 2140, type: !16)
!433 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2140, column: 3)
!434 = !DILocalVariable(name: "z", scope: !414, file: !3, line: 2142, type: !6)
!435 = !DIGlobalVariableExpression(var: !436, expr: !DIExpression())
!436 = distinct !DIGlobalVariable(name: "ivln10", scope: !414, file: !3, line: 2109, type: !47, isLocal: true, isDefinition: true)
!437 = !DIGlobalVariableExpression(var: !438, expr: !DIExpression())
!438 = distinct !DIGlobalVariable(name: "log10_2hi", scope: !414, file: !3, line: 2110, type: !47, isLocal: true, isDefinition: true)
!439 = !DIGlobalVariableExpression(var: !440, expr: !DIExpression())
!440 = distinct !DIGlobalVariable(name: "log10_2lo", scope: !414, file: !3, line: 2111, type: !47, isLocal: true, isDefinition: true)
!441 = !DIGlobalVariableExpression(var: !442, expr: !DIExpression())
!442 = distinct !DIGlobalVariable(name: "one", scope: !443, file: !3, line: 2242, type: !47, isLocal: true, isDefinition: true)
!443 = distinct !DISubprogram(name: "pts_ieee754_expm1", scope: !3, file: !3, line: 2240, type: !4, scopeLine: 2240, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !444)
!444 = !{!445, !446, !447, !448, !449, !450, !451, !452, !453, !454, !455, !456, !457, !458, !459, !461, !468, !470, !474, !478}
!445 = !DILocalVariable(name: "x", arg: 1, scope: !443, file: !3, line: 2240, type: !6)
!446 = !DILocalVariable(name: "y", scope: !443, file: !3, line: 2258, type: !6)
!447 = !DILocalVariable(name: "hi", scope: !443, file: !3, line: 2258, type: !6)
!448 = !DILocalVariable(name: "lo", scope: !443, file: !3, line: 2258, type: !6)
!449 = !DILocalVariable(name: "c", scope: !443, file: !3, line: 2258, type: !6)
!450 = !DILocalVariable(name: "t", scope: !443, file: !3, line: 2258, type: !6)
!451 = !DILocalVariable(name: "e", scope: !443, file: !3, line: 2258, type: !6)
!452 = !DILocalVariable(name: "hxs", scope: !443, file: !3, line: 2258, type: !6)
!453 = !DILocalVariable(name: "hfx", scope: !443, file: !3, line: 2258, type: !6)
!454 = !DILocalVariable(name: "r1", scope: !443, file: !3, line: 2258, type: !6)
!455 = !DILocalVariable(name: "twopk", scope: !443, file: !3, line: 2258, type: !6)
!456 = !DILocalVariable(name: "k", scope: !443, file: !3, line: 2259, type: !18)
!457 = !DILocalVariable(name: "xsb", scope: !443, file: !3, line: 2259, type: !18)
!458 = !DILocalVariable(name: "hx", scope: !443, file: !3, line: 2260, type: !9)
!459 = !DILocalVariable(name: "bits", scope: !460, file: !3, line: 2262, type: !16)
!460 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2262, column: 3)
!461 = !DILocalVariable(name: "low", scope: !462, file: !3, line: 2270, type: !9)
!462 = distinct !DILexicalBlock(scope: !463, file: !3, line: 2269, column: 29)
!463 = distinct !DILexicalBlock(scope: !464, file: !3, line: 2269, column: 11)
!464 = distinct !DILexicalBlock(scope: !465, file: !3, line: 2268, column: 27)
!465 = distinct !DILexicalBlock(scope: !466, file: !3, line: 2268, column: 9)
!466 = distinct !DILexicalBlock(scope: !467, file: !3, line: 2267, column: 25)
!467 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2267, column: 7)
!468 = !DILocalVariable(name: "bits", scope: !469, file: !3, line: 2271, type: !16)
!469 = distinct !DILexicalBlock(scope: !462, file: !3, line: 2271, column: 9)
!470 = !DILocalVariable(name: "bits", scope: !471, file: !3, line: 2321, type: !16)
!471 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2321, column: 5)
!472 = distinct !DILexicalBlock(scope: !473, file: !3, line: 2320, column: 10)
!473 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2318, column: 7)
!474 = !DILocalVariable(name: "bits", scope: !475, file: !3, line: 2347, type: !16)
!475 = distinct !DILexicalBlock(scope: !476, file: !3, line: 2347, column: 7)
!476 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2346, column: 17)
!477 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2346, column: 9)
!478 = !DILocalVariable(name: "bits", scope: !479, file: !3, line: 2351, type: !16)
!479 = distinct !DILexicalBlock(scope: !480, file: !3, line: 2351, column: 7)
!480 = distinct !DILexicalBlock(scope: !477, file: !3, line: 2350, column: 12)
!481 = !DIGlobalVariableExpression(var: !482, expr: !DIExpression())
!482 = distinct !DIGlobalVariable(name: "tiny", scope: !443, file: !3, line: 2243, type: !47, isLocal: true, isDefinition: true)
!483 = !DIGlobalVariableExpression(var: !484, expr: !DIExpression())
!484 = distinct !DIGlobalVariable(name: "o_threshold", scope: !443, file: !3, line: 2244, type: !47, isLocal: true, isDefinition: true)
!485 = !DIGlobalVariableExpression(var: !486, expr: !DIExpression())
!486 = distinct !DIGlobalVariable(name: "ln2_hi", scope: !443, file: !3, line: 2245, type: !47, isLocal: true, isDefinition: true)
!487 = !DIGlobalVariableExpression(var: !488, expr: !DIExpression())
!488 = distinct !DIGlobalVariable(name: "ln2_lo", scope: !443, file: !3, line: 2246, type: !47, isLocal: true, isDefinition: true)
!489 = !DIGlobalVariableExpression(var: !490, expr: !DIExpression())
!490 = distinct !DIGlobalVariable(name: "invln2", scope: !443, file: !3, line: 2247, type: !47, isLocal: true, isDefinition: true)
!491 = !DIGlobalVariableExpression(var: !492, expr: !DIExpression())
!492 = distinct !DIGlobalVariable(name: "Q1", scope: !443, file: !3, line: 2250, type: !47, isLocal: true, isDefinition: true)
!493 = !DIGlobalVariableExpression(var: !494, expr: !DIExpression())
!494 = distinct !DIGlobalVariable(name: "Q2", scope: !443, file: !3, line: 2251, type: !47, isLocal: true, isDefinition: true)
!495 = !DIGlobalVariableExpression(var: !496, expr: !DIExpression())
!496 = distinct !DIGlobalVariable(name: "Q3", scope: !443, file: !3, line: 2252, type: !47, isLocal: true, isDefinition: true)
!497 = !DIGlobalVariableExpression(var: !498, expr: !DIExpression())
!498 = distinct !DIGlobalVariable(name: "Q4", scope: !443, file: !3, line: 2253, type: !47, isLocal: true, isDefinition: true)
!499 = !DIGlobalVariableExpression(var: !500, expr: !DIExpression())
!500 = distinct !DIGlobalVariable(name: "Q5", scope: !443, file: !3, line: 2254, type: !47, isLocal: true, isDefinition: true)
!501 = !DIGlobalVariableExpression(var: !502, expr: !DIExpression())
!502 = distinct !DIGlobalVariable(name: "huge", scope: !443, file: !3, line: 2256, type: !14, isLocal: true, isDefinition: true)
!503 = !DIGlobalVariableExpression(var: !504, expr: !DIExpression())
!504 = distinct !DIGlobalVariable(name: "B1", scope: !505, file: !3, line: 2362, type: !530, isLocal: true, isDefinition: true)
!505 = distinct !DISubprogram(name: "pts_ieee754_cbrt", scope: !3, file: !3, line: 2360, type: !4, scopeLine: 2360, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !506)
!506 = !{!507, !508, !509, !510, !511, !512, !513, !514, !515, !516, !518, !522, !524, !526, !529}
!507 = !DILocalVariable(name: "x", arg: 1, scope: !505, file: !3, line: 2360, type: !6)
!508 = !DILocalVariable(name: "hx", scope: !505, file: !3, line: 2372, type: !18)
!509 = !DILocalVariable(name: "r", scope: !505, file: !3, line: 2373, type: !6)
!510 = !DILocalVariable(name: "s", scope: !505, file: !3, line: 2373, type: !6)
!511 = !DILocalVariable(name: "t", scope: !505, file: !3, line: 2373, type: !6)
!512 = !DILocalVariable(name: "w", scope: !505, file: !3, line: 2373, type: !6)
!513 = !DILocalVariable(name: "sign", scope: !505, file: !3, line: 2374, type: !9)
!514 = !DILocalVariable(name: "high", scope: !505, file: !3, line: 2375, type: !9)
!515 = !DILocalVariable(name: "low", scope: !505, file: !3, line: 2375, type: !9)
!516 = !DILocalVariable(name: "bits", scope: !517, file: !3, line: 2377, type: !16)
!517 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2377, column: 3)
!518 = !DILocalVariable(name: "bits", scope: !519, file: !3, line: 2399, type: !16)
!519 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2399, column: 5)
!520 = distinct !DILexicalBlock(scope: !521, file: !3, line: 2397, column: 24)
!521 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2397, column: 7)
!522 = !DILocalVariable(name: "bits", scope: !523, file: !3, line: 2401, type: !16)
!523 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2401, column: 5)
!524 = !DILocalVariable(name: "bits", scope: !525, file: !3, line: 2402, type: !16)
!525 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2402, column: 5)
!526 = !DILocalVariable(name: "bits", scope: !527, file: !3, line: 2404, type: !16)
!527 = distinct !DILexicalBlock(scope: !528, file: !3, line: 2404, column: 5)
!528 = distinct !DILexicalBlock(scope: !521, file: !3, line: 2403, column: 10)
!529 = !DILocalVariable(name: "bits", scope: !505, file: !3, line: 2430, type: !16)
!530 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !9)
!531 = !DIGlobalVariableExpression(var: !532, expr: !DIExpression())
!532 = distinct !DIGlobalVariable(name: "B2", scope: !505, file: !3, line: 2363, type: !530, isLocal: true, isDefinition: true)
!533 = !DIGlobalVariableExpression(var: !534, expr: !DIExpression())
!534 = distinct !DIGlobalVariable(name: "P0", scope: !505, file: !3, line: 2366, type: !47, isLocal: true, isDefinition: true)
!535 = !DIGlobalVariableExpression(var: !536, expr: !DIExpression())
!536 = distinct !DIGlobalVariable(name: "P1", scope: !505, file: !3, line: 2367, type: !47, isLocal: true, isDefinition: true)
!537 = !DIGlobalVariableExpression(var: !538, expr: !DIExpression())
!538 = distinct !DIGlobalVariable(name: "P2", scope: !505, file: !3, line: 2368, type: !47, isLocal: true, isDefinition: true)
!539 = !DIGlobalVariableExpression(var: !540, expr: !DIExpression())
!540 = distinct !DIGlobalVariable(name: "P3", scope: !505, file: !3, line: 2369, type: !47, isLocal: true, isDefinition: true)
!541 = !DIGlobalVariableExpression(var: !542, expr: !DIExpression())
!542 = distinct !DIGlobalVariable(name: "P4", scope: !505, file: !3, line: 2370, type: !47, isLocal: true, isDefinition: true)
!543 = !DIGlobalVariableExpression(var: !544, expr: !DIExpression())
!544 = distinct !DIGlobalVariable(name: "KCOSH_OVERFLOW", scope: !545, file: !3, line: 2578, type: !47, isLocal: true, isDefinition: true)
!545 = distinct !DISubprogram(name: "pts_ieee754_cosh", scope: !3, file: !3, line: 2577, type: !4, scopeLine: 2577, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !546)
!546 = !{!547, !548, !549, !551, !554, !555, !558, !561}
!547 = !DILocalVariable(name: "x", arg: 1, scope: !545, file: !3, line: 2577, type: !6)
!548 = !DILocalVariable(name: "ix", scope: !545, file: !3, line: 2582, type: !18)
!549 = !DILocalVariable(name: "bits", scope: !550, file: !3, line: 2585, type: !16)
!550 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2585, column: 3)
!551 = !DILocalVariable(name: "t", scope: !552, file: !3, line: 2590, type: !6)
!552 = distinct !DILexicalBlock(scope: !553, file: !3, line: 2589, column: 24)
!553 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2589, column: 7)
!554 = !DILocalVariable(name: "w", scope: !552, file: !3, line: 2591, type: !6)
!555 = !DILocalVariable(name: "t", scope: !556, file: !3, line: 2599, type: !6)
!556 = distinct !DILexicalBlock(scope: !557, file: !3, line: 2598, column: 24)
!557 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2598, column: 7)
!558 = !DILocalVariable(name: "w", scope: !559, file: !3, line: 2608, type: !6)
!559 = distinct !DILexicalBlock(scope: !560, file: !3, line: 2607, column: 34)
!560 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2607, column: 7)
!561 = !DILocalVariable(name: "t", scope: !559, file: !3, line: 2609, type: !6)
!562 = !DIGlobalVariableExpression(var: !563, expr: !DIExpression())
!563 = distinct !DIGlobalVariable(name: "one", scope: !545, file: !3, line: 2579, type: !47, isLocal: true, isDefinition: true)
!564 = !DIGlobalVariableExpression(var: !565, expr: !DIExpression())
!565 = distinct !DIGlobalVariable(name: "half", scope: !545, file: !3, line: 2579, type: !47, isLocal: true, isDefinition: true)
!566 = !DIGlobalVariableExpression(var: !567, expr: !DIExpression())
!567 = distinct !DIGlobalVariable(name: "huge", scope: !545, file: !3, line: 2580, type: !14, isLocal: true, isDefinition: true)
!568 = !DIGlobalVariableExpression(var: !569, expr: !DIExpression())
!569 = distinct !DIGlobalVariable(name: "KSINH_OVERFLOW", scope: !570, file: !3, line: 2642, type: !47, isLocal: true, isDefinition: true)
!570 = distinct !DISubprogram(name: "pts_ieee754_sinh", scope: !3, file: !3, line: 2641, type: !4, scopeLine: 2641, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !571)
!571 = !{!572, !573, !574, !575, !578, !581}
!572 = !DILocalVariable(name: "x", arg: 1, scope: !570, file: !3, line: 2641, type: !6)
!573 = !DILocalVariable(name: "h", scope: !570, file: !3, line: 2648, type: !6)
!574 = !DILocalVariable(name: "ax", scope: !570, file: !3, line: 2650, type: !6)
!575 = !DILocalVariable(name: "t", scope: !576, file: !3, line: 2654, type: !6)
!576 = distinct !DILexicalBlock(scope: !577, file: !3, line: 2651, column: 16)
!577 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2651, column: 7)
!578 = !DILocalVariable(name: "w", scope: !579, file: !3, line: 2665, type: !6)
!579 = distinct !DILexicalBlock(scope: !580, file: !3, line: 2664, column: 29)
!580 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2664, column: 7)
!581 = !DILocalVariable(name: "t", scope: !579, file: !3, line: 2666, type: !6)
!582 = !DIGlobalVariableExpression(var: !583, expr: !DIExpression())
!583 = distinct !DIGlobalVariable(name: "TWO_M28", scope: !570, file: !3, line: 2643, type: !47, isLocal: true, isDefinition: true)
!584 = !DIGlobalVariableExpression(var: !585, expr: !DIExpression())
!585 = distinct !DIGlobalVariable(name: "LOG_MAXD", scope: !570, file: !3, line: 2645, type: !47, isLocal: true, isDefinition: true)
!586 = !DIGlobalVariableExpression(var: !587, expr: !DIExpression())
!587 = distinct !DIGlobalVariable(name: "shuge", scope: !570, file: !3, line: 2646, type: !47, isLocal: true, isDefinition: true)
!588 = !DIGlobalVariableExpression(var: !589, expr: !DIExpression())
!589 = distinct !DIGlobalVariable(name: "tiny", scope: !590, file: !3, line: 2698, type: !13, isLocal: true, isDefinition: true)
!590 = distinct !DISubprogram(name: "pts_ieee754_tanh", scope: !3, file: !3, line: 2697, type: !4, scopeLine: 2697, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !591)
!591 = !{!592, !593, !594, !595, !596, !597}
!592 = !DILocalVariable(name: "x", arg: 1, scope: !590, file: !3, line: 2697, type: !6)
!593 = !DILocalVariable(name: "t", scope: !590, file: !3, line: 2700, type: !6)
!594 = !DILocalVariable(name: "z", scope: !590, file: !3, line: 2700, type: !6)
!595 = !DILocalVariable(name: "jx", scope: !590, file: !3, line: 2701, type: !18)
!596 = !DILocalVariable(name: "ix", scope: !590, file: !3, line: 2701, type: !18)
!597 = !DILocalVariable(name: "bits", scope: !598, file: !3, line: 2703, type: !16)
!598 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2703, column: 3)
!599 = !DIGlobalVariableExpression(var: !600, expr: !DIExpression())
!600 = distinct !DIGlobalVariable(name: "one", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!601 = !DIGlobalVariableExpression(var: !602, expr: !DIExpression())
!602 = distinct !DIGlobalVariable(name: "two", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!603 = !DIGlobalVariableExpression(var: !604, expr: !DIExpression())
!604 = distinct !DIGlobalVariable(name: "huge", scope: !590, file: !3, line: 2699, type: !47, isLocal: true, isDefinition: true)
!605 = !DIGlobalVariableExpression(var: !606, expr: !DIExpression())
!606 = distinct !DIGlobalVariable(name: "one", scope: !607, file: !3, line: 338, type: !47, isLocal: true, isDefinition: true)
!607 = distinct !DISubprogram(name: "__kernel_cos", scope: !3, file: !3, line: 336, type: !171, scopeLine: 336, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !608)
!608 = !{!609, !610, !611, !612, !613, !614, !615, !616, !617, !619}
!609 = !DILocalVariable(name: "x", arg: 1, scope: !607, file: !3, line: 336, type: !6)
!610 = !DILocalVariable(name: "y", arg: 2, scope: !607, file: !3, line: 336, type: !6)
!611 = !DILocalVariable(name: "a", scope: !607, file: !3, line: 346, type: !6)
!612 = !DILocalVariable(name: "iz", scope: !607, file: !3, line: 346, type: !6)
!613 = !DILocalVariable(name: "z", scope: !607, file: !3, line: 346, type: !6)
!614 = !DILocalVariable(name: "r", scope: !607, file: !3, line: 346, type: !6)
!615 = !DILocalVariable(name: "qx", scope: !607, file: !3, line: 346, type: !6)
!616 = !DILocalVariable(name: "ix", scope: !607, file: !3, line: 347, type: !18)
!617 = !DILocalVariable(name: "bits", scope: !618, file: !3, line: 348, type: !16)
!618 = distinct !DILexicalBlock(scope: !607, file: !3, line: 348, column: 3)
!619 = !DILocalVariable(name: "bits", scope: !620, file: !3, line: 361, type: !16)
!620 = distinct !DILexicalBlock(scope: !621, file: !3, line: 361, column: 7)
!621 = distinct !DILexicalBlock(scope: !622, file: !3, line: 360, column: 12)
!622 = distinct !DILexicalBlock(scope: !623, file: !3, line: 358, column: 9)
!623 = distinct !DILexicalBlock(scope: !624, file: !3, line: 357, column: 10)
!624 = distinct !DILexicalBlock(scope: !607, file: !3, line: 355, column: 7)
!625 = !DIGlobalVariableExpression(var: !626, expr: !DIExpression())
!626 = distinct !DIGlobalVariable(name: "C1", scope: !607, file: !3, line: 339, type: !47, isLocal: true, isDefinition: true)
!627 = !DIGlobalVariableExpression(var: !628, expr: !DIExpression())
!628 = distinct !DIGlobalVariable(name: "C2", scope: !607, file: !3, line: 340, type: !47, isLocal: true, isDefinition: true)
!629 = !DIGlobalVariableExpression(var: !630, expr: !DIExpression())
!630 = distinct !DIGlobalVariable(name: "C3", scope: !607, file: !3, line: 341, type: !47, isLocal: true, isDefinition: true)
!631 = !DIGlobalVariableExpression(var: !632, expr: !DIExpression())
!632 = distinct !DIGlobalVariable(name: "C4", scope: !607, file: !3, line: 342, type: !47, isLocal: true, isDefinition: true)
!633 = !DIGlobalVariableExpression(var: !634, expr: !DIExpression())
!634 = distinct !DIGlobalVariable(name: "C5", scope: !607, file: !3, line: 343, type: !47, isLocal: true, isDefinition: true)
!635 = !DIGlobalVariableExpression(var: !636, expr: !DIExpression())
!636 = distinct !DIGlobalVariable(name: "C6", scope: !607, file: !3, line: 344, type: !47, isLocal: true, isDefinition: true)
!637 = !DIGlobalVariableExpression(var: !638, expr: !DIExpression())
!638 = distinct !DIGlobalVariable(name: "two_over_pi", scope: !639, file: !3, line: 153, type: !682, isLocal: true, isDefinition: true)
!639 = distinct !DISubprogram(name: "__ieee754_rem_pio2", scope: !3, file: !3, line: 149, type: !640, scopeLine: 149, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !643)
!640 = !DISubroutineType(types: !641)
!641 = !{!18, !6, !642}
!642 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !6, size: 64)
!643 = !{!644, !645, !646, !647, !648, !649, !650, !651, !655, !656, !657, !658, !659, !660, !661, !662, !663, !665, !670, !672, !676, !678, !680}
!644 = !DILocalVariable(name: "x", arg: 1, scope: !639, file: !3, line: 149, type: !6)
!645 = !DILocalVariable(name: "y", arg: 2, scope: !639, file: !3, line: 149, type: !642)
!646 = !DILocalVariable(name: "z", scope: !639, file: !3, line: 197, type: !6)
!647 = !DILocalVariable(name: "w", scope: !639, file: !3, line: 197, type: !6)
!648 = !DILocalVariable(name: "t", scope: !639, file: !3, line: 197, type: !6)
!649 = !DILocalVariable(name: "r", scope: !639, file: !3, line: 197, type: !6)
!650 = !DILocalVariable(name: "fn", scope: !639, file: !3, line: 197, type: !6)
!651 = !DILocalVariable(name: "tx", scope: !639, file: !3, line: 198, type: !652)
!652 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 192, elements: !653)
!653 = !{!654}
!654 = !DISubrange(count: 3)
!655 = !DILocalVariable(name: "e0", scope: !639, file: !3, line: 199, type: !18)
!656 = !DILocalVariable(name: "i", scope: !639, file: !3, line: 199, type: !18)
!657 = !DILocalVariable(name: "j", scope: !639, file: !3, line: 199, type: !18)
!658 = !DILocalVariable(name: "nx", scope: !639, file: !3, line: 199, type: !18)
!659 = !DILocalVariable(name: "n", scope: !639, file: !3, line: 199, type: !18)
!660 = !DILocalVariable(name: "ix", scope: !639, file: !3, line: 199, type: !18)
!661 = !DILocalVariable(name: "hx", scope: !639, file: !3, line: 199, type: !18)
!662 = !DILocalVariable(name: "low", scope: !639, file: !3, line: 200, type: !9)
!663 = !DILocalVariable(name: "bits", scope: !664, file: !3, line: 203, type: !16)
!664 = distinct !DILexicalBlock(scope: !639, file: !3, line: 203, column: 3)
!665 = !DILocalVariable(name: "high", scope: !666, file: !3, line: 244, type: !9)
!666 = distinct !DILexicalBlock(scope: !667, file: !3, line: 243, column: 12)
!667 = distinct !DILexicalBlock(scope: !668, file: !3, line: 241, column: 9)
!668 = distinct !DILexicalBlock(scope: !669, file: !3, line: 235, column: 25)
!669 = distinct !DILexicalBlock(scope: !639, file: !3, line: 235, column: 7)
!670 = !DILocalVariable(name: "bits", scope: !671, file: !3, line: 247, type: !16)
!671 = distinct !DILexicalBlock(scope: !666, file: !3, line: 247, column: 7)
!672 = !DILocalVariable(name: "bits", scope: !673, file: !3, line: 255, type: !16)
!673 = distinct !DILexicalBlock(scope: !674, file: !3, line: 255, column: 9)
!674 = distinct !DILexicalBlock(scope: !675, file: !3, line: 249, column: 19)
!675 = distinct !DILexicalBlock(scope: !666, file: !3, line: 249, column: 11)
!676 = !DILocalVariable(name: "bits", scope: !677, file: !3, line: 283, type: !16)
!677 = distinct !DILexicalBlock(scope: !639, file: !3, line: 283, column: 3)
!678 = !DILocalVariable(name: "bits", scope: !679, file: !3, line: 284, type: !16)
!679 = distinct !DILexicalBlock(scope: !639, file: !3, line: 284, column: 3)
!680 = !DILocalVariable(name: "bits", scope: !681, file: !3, line: 286, type: !16)
!681 = distinct !DILexicalBlock(scope: !639, file: !3, line: 286, column: 3)
!682 = !DICompositeType(tag: DW_TAG_array_type, baseType: !683, size: 2112, elements: !684)
!683 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !18)
!684 = !{!685}
!685 = !DISubrange(count: 66)
!686 = !DIGlobalVariableExpression(var: !687, expr: !DIExpression())
!687 = distinct !DIGlobalVariable(name: "npio2_hw", scope: !639, file: !3, line: 166, type: !688, isLocal: true, isDefinition: true)
!688 = !DICompositeType(tag: DW_TAG_array_type, baseType: !683, size: 1024, elements: !689)
!689 = !{!690}
!690 = !DISubrange(count: 32)
!691 = !DIGlobalVariableExpression(var: !692, expr: !DIExpression())
!692 = distinct !DIGlobalVariable(name: "zero", scope: !639, file: !3, line: 186, type: !47, isLocal: true, isDefinition: true)
!693 = !DIGlobalVariableExpression(var: !694, expr: !DIExpression())
!694 = distinct !DIGlobalVariable(name: "half", scope: !639, file: !3, line: 187, type: !47, isLocal: true, isDefinition: true)
!695 = !DIGlobalVariableExpression(var: !696, expr: !DIExpression())
!696 = distinct !DIGlobalVariable(name: "two24", scope: !639, file: !3, line: 188, type: !47, isLocal: true, isDefinition: true)
!697 = !DIGlobalVariableExpression(var: !698, expr: !DIExpression())
!698 = distinct !DIGlobalVariable(name: "invpio2", scope: !639, file: !3, line: 189, type: !47, isLocal: true, isDefinition: true)
!699 = !DIGlobalVariableExpression(var: !700, expr: !DIExpression())
!700 = distinct !DIGlobalVariable(name: "pio2_1", scope: !639, file: !3, line: 190, type: !47, isLocal: true, isDefinition: true)
!701 = !DIGlobalVariableExpression(var: !702, expr: !DIExpression())
!702 = distinct !DIGlobalVariable(name: "pio2_1t", scope: !639, file: !3, line: 191, type: !47, isLocal: true, isDefinition: true)
!703 = !DIGlobalVariableExpression(var: !704, expr: !DIExpression())
!704 = distinct !DIGlobalVariable(name: "pio2_2", scope: !639, file: !3, line: 192, type: !47, isLocal: true, isDefinition: true)
!705 = !DIGlobalVariableExpression(var: !706, expr: !DIExpression())
!706 = distinct !DIGlobalVariable(name: "pio2_2t", scope: !639, file: !3, line: 193, type: !47, isLocal: true, isDefinition: true)
!707 = !DIGlobalVariableExpression(var: !708, expr: !DIExpression())
!708 = distinct !DIGlobalVariable(name: "pio2_3", scope: !639, file: !3, line: 194, type: !47, isLocal: true, isDefinition: true)
!709 = !DIGlobalVariableExpression(var: !710, expr: !DIExpression())
!710 = distinct !DIGlobalVariable(name: "pio2_3t", scope: !639, file: !3, line: 195, type: !47, isLocal: true, isDefinition: true)
!711 = !DIGlobalVariableExpression(var: !712, expr: !DIExpression())
!712 = distinct !DIGlobalVariable(name: "init_jk", scope: !713, file: !3, line: 482, type: !748, isLocal: true, isDefinition: true)
!713 = distinct !DISubprogram(name: "__kernel_rem_pio2", scope: !3, file: !3, line: 474, type: !714, scopeLine: 475, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !717)
!714 = !DISubroutineType(types: !715)
!715 = !{!15, !642, !642, !15, !15, !15, !716}
!716 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: !683, size: 64)
!717 = !{!718, !719, !720, !721, !722, !723, !724, !725, !726, !727, !728, !729, !730, !731, !735, !736, !737, !738, !739, !740, !741, !742, !743, !745, !746, !747}
!718 = !DILocalVariable(name: "x", arg: 1, scope: !713, file: !3, line: 474, type: !642)
!719 = !DILocalVariable(name: "y", arg: 2, scope: !713, file: !3, line: 474, type: !642)
!720 = !DILocalVariable(name: "e0", arg: 3, scope: !713, file: !3, line: 474, type: !15)
!721 = !DILocalVariable(name: "nx", arg: 4, scope: !713, file: !3, line: 474, type: !15)
!722 = !DILocalVariable(name: "prec", arg: 5, scope: !713, file: !3, line: 474, type: !15)
!723 = !DILocalVariable(name: "ipio2", arg: 6, scope: !713, file: !3, line: 475, type: !716)
!724 = !DILocalVariable(name: "jz", scope: !713, file: !3, line: 501, type: !18)
!725 = !DILocalVariable(name: "jx", scope: !713, file: !3, line: 501, type: !18)
!726 = !DILocalVariable(name: "jv", scope: !713, file: !3, line: 501, type: !18)
!727 = !DILocalVariable(name: "jp", scope: !713, file: !3, line: 501, type: !18)
!728 = !DILocalVariable(name: "jk", scope: !713, file: !3, line: 501, type: !18)
!729 = !DILocalVariable(name: "carry", scope: !713, file: !3, line: 501, type: !18)
!730 = !DILocalVariable(name: "n", scope: !713, file: !3, line: 501, type: !18)
!731 = !DILocalVariable(name: "iq", scope: !713, file: !3, line: 501, type: !732)
!732 = !DICompositeType(tag: DW_TAG_array_type, baseType: !18, size: 640, elements: !733)
!733 = !{!734}
!734 = !DISubrange(count: 20)
!735 = !DILocalVariable(name: "i", scope: !713, file: !3, line: 501, type: !18)
!736 = !DILocalVariable(name: "j", scope: !713, file: !3, line: 501, type: !18)
!737 = !DILocalVariable(name: "k", scope: !713, file: !3, line: 501, type: !18)
!738 = !DILocalVariable(name: "m", scope: !713, file: !3, line: 501, type: !18)
!739 = !DILocalVariable(name: "q0", scope: !713, file: !3, line: 501, type: !18)
!740 = !DILocalVariable(name: "ih", scope: !713, file: !3, line: 501, type: !18)
!741 = !DILocalVariable(name: "z", scope: !713, file: !3, line: 502, type: !6)
!742 = !DILocalVariable(name: "fw", scope: !713, file: !3, line: 502, type: !6)
!743 = !DILocalVariable(name: "f", scope: !713, file: !3, line: 502, type: !744)
!744 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 1280, elements: !733)
!745 = !DILocalVariable(name: "fq", scope: !713, file: !3, line: 502, type: !744)
!746 = !DILocalVariable(name: "q", scope: !713, file: !3, line: 502, type: !744)
!747 = !DILabel(scope: !713, name: "recompute", file: !3, line: 528)
!748 = !DICompositeType(tag: DW_TAG_array_type, baseType: !749, size: 128, elements: !157)
!749 = !DIDerivedType(tag: DW_TAG_const_type, baseType: !15)
!750 = !DIGlobalVariableExpression(var: !751, expr: !DIExpression())
!751 = distinct !DIGlobalVariable(name: "PIo2", scope: !713, file: !3, line: 484, type: !752, isLocal: true, isDefinition: true)
!752 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 512, elements: !753)
!753 = !{!754}
!754 = !DISubrange(count: 8)
!755 = !DIGlobalVariableExpression(var: !756, expr: !DIExpression())
!756 = distinct !DIGlobalVariable(name: "zero", scope: !713, file: !3, line: 496, type: !47, isLocal: true, isDefinition: true)
!757 = !DIGlobalVariableExpression(var: !758, expr: !DIExpression())
!758 = distinct !DIGlobalVariable(name: "one", scope: !713, file: !3, line: 497, type: !47, isLocal: true, isDefinition: true)
!759 = !DIGlobalVariableExpression(var: !760, expr: !DIExpression())
!760 = distinct !DIGlobalVariable(name: "two24", scope: !713, file: !3, line: 498, type: !47, isLocal: true, isDefinition: true)
!761 = !DIGlobalVariableExpression(var: !762, expr: !DIExpression())
!762 = distinct !DIGlobalVariable(name: "twon24", scope: !713, file: !3, line: 499, type: !47, isLocal: true, isDefinition: true)
!763 = !DIGlobalVariableExpression(var: !764, expr: !DIExpression())
!764 = distinct !DIGlobalVariable(name: "half", scope: !765, file: !3, line: 706, type: !47, isLocal: true, isDefinition: true)
!765 = distinct !DISubprogram(name: "__kernel_sin", scope: !3, file: !3, line: 704, type: !766, scopeLine: 704, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !768)
!766 = !DISubroutineType(types: !767)
!767 = !{!6, !6, !6, !15}
!768 = !{!769, !770, !771, !772, !773, !774, !775, !776}
!769 = !DILocalVariable(name: "x", arg: 1, scope: !765, file: !3, line: 704, type: !6)
!770 = !DILocalVariable(name: "y", arg: 2, scope: !765, file: !3, line: 704, type: !6)
!771 = !DILocalVariable(name: "iy", arg: 3, scope: !765, file: !3, line: 704, type: !15)
!772 = !DILocalVariable(name: "z", scope: !765, file: !3, line: 714, type: !6)
!773 = !DILocalVariable(name: "r", scope: !765, file: !3, line: 714, type: !6)
!774 = !DILocalVariable(name: "v", scope: !765, file: !3, line: 714, type: !6)
!775 = !DILocalVariable(name: "ix", scope: !765, file: !3, line: 715, type: !18)
!776 = !DILocalVariable(name: "bits", scope: !777, file: !3, line: 716, type: !16)
!777 = distinct !DILexicalBlock(scope: !765, file: !3, line: 716, column: 3)
!778 = !DIGlobalVariableExpression(var: !779, expr: !DIExpression())
!779 = distinct !DIGlobalVariable(name: "S1", scope: !765, file: !3, line: 707, type: !47, isLocal: true, isDefinition: true)
!780 = !DIGlobalVariableExpression(var: !781, expr: !DIExpression())
!781 = distinct !DIGlobalVariable(name: "S2", scope: !765, file: !3, line: 708, type: !47, isLocal: true, isDefinition: true)
!782 = !DIGlobalVariableExpression(var: !783, expr: !DIExpression())
!783 = distinct !DIGlobalVariable(name: "S3", scope: !765, file: !3, line: 709, type: !47, isLocal: true, isDefinition: true)
!784 = !DIGlobalVariableExpression(var: !785, expr: !DIExpression())
!785 = distinct !DIGlobalVariable(name: "S4", scope: !765, file: !3, line: 710, type: !47, isLocal: true, isDefinition: true)
!786 = !DIGlobalVariableExpression(var: !787, expr: !DIExpression())
!787 = distinct !DIGlobalVariable(name: "S5", scope: !765, file: !3, line: 711, type: !47, isLocal: true, isDefinition: true)
!788 = !DIGlobalVariableExpression(var: !789, expr: !DIExpression())
!789 = distinct !DIGlobalVariable(name: "S6", scope: !765, file: !3, line: 712, type: !47, isLocal: true, isDefinition: true)
!790 = !DIGlobalVariableExpression(var: !791, expr: !DIExpression(DW_OP_constu, 4600877379321592324, DW_OP_stack_value))
!791 = distinct !DIGlobalVariable(name: "Lg2", scope: !7, file: !3, line: 1967, type: !47, isLocal: true, isDefinition: true)
!792 = !DIGlobalVariableExpression(var: !793, expr: !DIExpression(DW_OP_constu, 4597174411056806063, DW_OP_stack_value))
!793 = distinct !DIGlobalVariable(name: "Lg4", scope: !7, file: !3, line: 1969, type: !47, isLocal: true, isDefinition: true)
!794 = !DIGlobalVariableExpression(var: !795, expr: !DIExpression(DW_OP_constu, 4594685411790997151, DW_OP_stack_value))
!795 = distinct !DIGlobalVariable(name: "Lg6", scope: !7, file: !3, line: 1971, type: !47, isLocal: true, isDefinition: true)
!796 = !DIGlobalVariableExpression(var: !797, expr: !DIExpression(DW_OP_constu, 4604180019048437139, DW_OP_stack_value))
!797 = distinct !DIGlobalVariable(name: "Lg1", scope: !7, file: !3, line: 1966, type: !47, isLocal: true, isDefinition: true)
!798 = !DIGlobalVariableExpression(var: !799, expr: !DIExpression(DW_OP_constu, 4598818590951641945, DW_OP_stack_value))
!799 = distinct !DIGlobalVariable(name: "Lg3", scope: !7, file: !3, line: 1968, type: !47, isLocal: true, isDefinition: true)
!800 = !DIGlobalVariableExpression(var: !801, expr: !DIExpression(DW_OP_constu, 4595719342595441630, DW_OP_stack_value))
!801 = distinct !DIGlobalVariable(name: "Lg5", scope: !7, file: !3, line: 1970, type: !47, isLocal: true, isDefinition: true)
!802 = !DIGlobalVariableExpression(var: !803, expr: !DIExpression(DW_OP_constu, 4594499633228436036, DW_OP_stack_value))
!803 = distinct !DIGlobalVariable(name: "Lg7", scope: !7, file: !3, line: 1972, type: !47, isLocal: true, isDefinition: true)
!804 = !DIGlobalVariableExpression(var: !805, expr: !DIExpression())
!805 = distinct !DIGlobalVariable(name: "xxx", scope: !806, file: !3, line: 765, type: !845, isLocal: true, isDefinition: true)
!806 = distinct !DISubprogram(name: "__kernel_tan", scope: !3, file: !3, line: 764, type: !766, scopeLine: 764, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !807)
!807 = !{!808, !809, !810, !811, !812, !813, !814, !815, !816, !817, !818, !820, !825, !827, !832, !833, !835, !837, !840, !841, !843}
!808 = !DILocalVariable(name: "x", arg: 1, scope: !806, file: !3, line: 764, type: !6)
!809 = !DILocalVariable(name: "y", arg: 2, scope: !806, file: !3, line: 764, type: !6)
!810 = !DILocalVariable(name: "iy", arg: 3, scope: !806, file: !3, line: 764, type: !15)
!811 = !DILocalVariable(name: "z", scope: !806, file: !3, line: 788, type: !6)
!812 = !DILocalVariable(name: "r", scope: !806, file: !3, line: 788, type: !6)
!813 = !DILocalVariable(name: "v", scope: !806, file: !3, line: 788, type: !6)
!814 = !DILocalVariable(name: "w", scope: !806, file: !3, line: 788, type: !6)
!815 = !DILocalVariable(name: "s", scope: !806, file: !3, line: 788, type: !6)
!816 = !DILocalVariable(name: "ix", scope: !806, file: !3, line: 789, type: !18)
!817 = !DILocalVariable(name: "hx", scope: !806, file: !3, line: 789, type: !18)
!818 = !DILocalVariable(name: "bits", scope: !819, file: !3, line: 791, type: !16)
!819 = distinct !DILexicalBlock(scope: !806, file: !3, line: 791, column: 3)
!820 = !DILocalVariable(name: "low", scope: !821, file: !3, line: 795, type: !9)
!821 = distinct !DILexicalBlock(scope: !822, file: !3, line: 794, column: 24)
!822 = distinct !DILexicalBlock(scope: !823, file: !3, line: 794, column: 9)
!823 = distinct !DILexicalBlock(scope: !824, file: !3, line: 793, column: 24)
!824 = distinct !DILexicalBlock(scope: !806, file: !3, line: 793, column: 7)
!825 = !DILocalVariable(name: "bits", scope: !826, file: !3, line: 796, type: !16)
!826 = distinct !DILexicalBlock(scope: !821, file: !3, line: 796, column: 7)
!827 = !DILocalVariable(name: "a", scope: !828, file: !3, line: 803, type: !6)
!828 = distinct !DILexicalBlock(scope: !829, file: !3, line: 802, column: 16)
!829 = distinct !DILexicalBlock(scope: !830, file: !3, line: 800, column: 13)
!830 = distinct !DILexicalBlock(scope: !831, file: !3, line: 799, column: 14)
!831 = distinct !DILexicalBlock(scope: !821, file: !3, line: 797, column: 11)
!832 = !DILocalVariable(name: "t", scope: !828, file: !3, line: 803, type: !6)
!833 = !DILocalVariable(name: "bits", scope: !834, file: !3, line: 806, type: !16)
!834 = distinct !DILexicalBlock(scope: !828, file: !3, line: 806, column: 11)
!835 = !DILocalVariable(name: "bits", scope: !836, file: !3, line: 809, type: !16)
!836 = distinct !DILexicalBlock(scope: !828, file: !3, line: 809, column: 11)
!837 = !DILocalVariable(name: "a", scope: !838, file: !3, line: 852, type: !6)
!838 = distinct !DILexicalBlock(scope: !839, file: !3, line: 846, column: 10)
!839 = distinct !DILexicalBlock(scope: !806, file: !3, line: 844, column: 7)
!840 = !DILocalVariable(name: "t", scope: !838, file: !3, line: 852, type: !6)
!841 = !DILocalVariable(name: "bits", scope: !842, file: !3, line: 854, type: !16)
!842 = distinct !DILexicalBlock(scope: !838, file: !3, line: 854, column: 5)
!843 = !DILocalVariable(name: "bits", scope: !844, file: !3, line: 857, type: !16)
!844 = distinct !DILexicalBlock(scope: !838, file: !3, line: 857, column: 5)
!845 = !DICompositeType(tag: DW_TAG_array_type, baseType: !47, size: 1024, elements: !846)
!846 = !{!847}
!847 = !DISubrange(count: 16)
!848 = !{!849, !850, !851, !852, !853, !854, !855, !856, !857, !859, !862}
!849 = !DILocalVariable(name: "x", arg: 1, scope: !2, file: !3, line: 1147, type: !6)
!850 = !DILocalVariable(name: "w", scope: !2, file: !3, line: 1178, type: !6)
!851 = !DILocalVariable(name: "s1", scope: !2, file: !3, line: 1178, type: !6)
!852 = !DILocalVariable(name: "s2", scope: !2, file: !3, line: 1178, type: !6)
!853 = !DILocalVariable(name: "z", scope: !2, file: !3, line: 1178, type: !6)
!854 = !DILocalVariable(name: "ix", scope: !2, file: !3, line: 1179, type: !18)
!855 = !DILocalVariable(name: "hx", scope: !2, file: !3, line: 1179, type: !18)
!856 = !DILocalVariable(name: "id", scope: !2, file: !3, line: 1179, type: !18)
!857 = !DILocalVariable(name: "bits", scope: !858, file: !3, line: 1181, type: !16)
!858 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1181, column: 3)
!859 = !DILocalVariable(name: "low", scope: !860, file: !3, line: 1184, type: !9)
!860 = distinct !DILexicalBlock(scope: !861, file: !3, line: 1183, column: 25)
!861 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1183, column: 7)
!862 = !DILocalVariable(name: "bits", scope: !863, file: !3, line: 1185, type: !16)
!863 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1185, column: 5)
!864 = !{i32 7, !"Dwarf Version", i32 5}
!865 = !{i32 2, !"Debug Info Version", i32 3}
!866 = !{i32 1, !"wchar_size", i32 4}
!867 = !{i32 8, !"PIC Level", i32 2}
!868 = !{i32 7, !"PIE Level", i32 2}
!869 = !{i32 7, !"uwtable", i32 2}
!870 = !{i32 7, !"frame-pointer", i32 1}
!871 = !{i32 7, !"debug-info-assignment-tracking", i1 true}
!872 = !{!"Ubuntu clang version 18.1.3 (1ubuntu1)"}
!873 = !DILocation(line: 0, scope: !22)
!874 = !DILocalVariable(name: "d", arg: 1, scope: !875, file: !3, line: 54, type: !6)
!875 = distinct !DISubprogram(name: "bits_of", scope: !3, file: !3, line: 54, type: !876, scopeLine: 54, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !878)
!876 = !DISubroutineType(types: !877)
!877 = !{!16, !6}
!878 = !{!874, !879}
!879 = !DILocalVariable(name: "bits", scope: !875, file: !3, line: 55, type: !16)
!880 = !DILocation(line: 0, scope: !875, inlinedAt: !881)
!881 = distinct !DILocation(line: 912, column: 3, scope: !36)
!882 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !881)
!883 = !DILocation(line: 0, scope: !36)
!884 = !DILocation(line: 912, column: 3, scope: !36)
!885 = !DILocation(line: 913, column: 11, scope: !22)
!886 = !DILocation(line: 914, column: 10, scope: !39)
!887 = !DILocation(line: 914, column: 7, scope: !22)
!888 = !DILocation(line: 0, scope: !875, inlinedAt: !889)
!889 = distinct !DILocation(line: 916, column: 5, scope: !41)
!890 = !DILocation(line: 0, scope: !41)
!891 = !DILocation(line: 916, column: 5, scope: !41)
!892 = !DILocation(line: 0, scope: !38)
!893 = !DILocation(line: 917, column: 14, scope: !894)
!894 = distinct !DILexicalBlock(scope: !38, file: !3, line: 917, column: 9)
!895 = !DILocation(line: 917, column: 28, scope: !894)
!896 = !DILocation(line: 917, column: 34, scope: !894)
!897 = !DILocation(line: 917, column: 9, scope: !38)
!898 = !DILocation(line: 925, column: 10, scope: !46)
!899 = !DILocation(line: 925, column: 7, scope: !22)
!900 = !DILocation(line: 926, column: 12, scope: !901)
!901 = distinct !DILexicalBlock(scope: !902, file: !3, line: 926, column: 9)
!902 = distinct !DILexicalBlock(scope: !46, file: !3, line: 925, column: 24)
!903 = !DILocation(line: 926, column: 9, scope: !902)
!904 = !DILocation(line: 927, column: 11, scope: !902)
!905 = !DILocation(line: 928, column: 62, scope: !902)
!906 = !DILocation(line: 928, column: 51, scope: !902)
!907 = !DILocation(line: 928, column: 40, scope: !902)
!908 = !DILocation(line: 928, column: 29, scope: !902)
!909 = !DILocation(line: 928, column: 18, scope: !902)
!910 = !DILocation(line: 928, column: 11, scope: !902)
!911 = !DILocation(line: 929, column: 46, scope: !902)
!912 = !DILocation(line: 929, column: 35, scope: !902)
!913 = !DILocation(line: 929, column: 24, scope: !902)
!914 = !DILocation(line: 929, column: 13, scope: !902)
!915 = !DILocation(line: 930, column: 11, scope: !902)
!916 = !DILocation(line: 931, column: 36, scope: !902)
!917 = !DILocation(line: 931, column: 20, scope: !902)
!918 = !DILocation(line: 931, column: 5, scope: !902)
!919 = !DILocation(line: 932, column: 17, scope: !45)
!920 = !DILocation(line: 932, column: 14, scope: !46)
!921 = !DILocation(line: 933, column: 14, scope: !922)
!922 = distinct !DILexicalBlock(scope: !45, file: !3, line: 932, column: 22)
!923 = !DILocation(line: 933, column: 19, scope: !922)
!924 = !DILocation(line: 934, column: 62, scope: !922)
!925 = !DILocation(line: 934, column: 51, scope: !922)
!926 = !DILocation(line: 934, column: 40, scope: !922)
!927 = !DILocation(line: 934, column: 29, scope: !922)
!928 = !DILocation(line: 934, column: 18, scope: !922)
!929 = !DILocation(line: 934, column: 11, scope: !922)
!930 = !DILocation(line: 935, column: 46, scope: !922)
!931 = !DILocation(line: 935, column: 35, scope: !922)
!932 = !DILocation(line: 935, column: 24, scope: !922)
!933 = !DILocation(line: 935, column: 13, scope: !922)
!934 = !DILocation(line: 936, column: 9, scope: !922)
!935 = !DILocation(line: 937, column: 11, scope: !922)
!936 = !DILocation(line: 938, column: 15, scope: !922)
!937 = !DILocation(line: 939, column: 26, scope: !922)
!938 = !DILocation(line: 939, column: 15, scope: !922)
!939 = !DILocation(line: 939, column: 5, scope: !922)
!940 = !DILocation(line: 941, column: 14, scope: !44)
!941 = !DILocation(line: 941, column: 19, scope: !44)
!942 = !DILocation(line: 942, column: 9, scope: !44)
!943 = !DILocation(line: 0, scope: !875, inlinedAt: !944)
!944 = distinct !DILocation(line: 944, column: 5, scope: !43)
!945 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !944)
!946 = !DILocation(line: 0, scope: !43)
!947 = !DILocation(line: 944, column: 5, scope: !43)
!948 = !DILocalVariable(name: "bits", arg: 1, scope: !949, file: !3, line: 60, type: !16)
!949 = distinct !DISubprogram(name: "double_of", scope: !3, file: !3, line: 60, type: !950, scopeLine: 60, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !952)
!950 = !DISubroutineType(types: !951)
!951 = !{!6, !16}
!952 = !{!948, !953}
!953 = !DILocalVariable(name: "d", scope: !949, file: !3, line: 61, type: !6)
!954 = !DILocation(line: 0, scope: !949, inlinedAt: !955)
!955 = distinct !DILocation(line: 944, column: 5, scope: !43)
!956 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !955)
!957 = !DILocation(line: 945, column: 12, scope: !44)
!958 = !DILocation(line: 945, column: 28, scope: !44)
!959 = !DILocation(line: 945, column: 23, scope: !44)
!960 = !DILocation(line: 946, column: 62, scope: !44)
!961 = !DILocation(line: 946, column: 51, scope: !44)
!962 = !DILocation(line: 946, column: 40, scope: !44)
!963 = !DILocation(line: 946, column: 29, scope: !44)
!964 = !DILocation(line: 946, column: 18, scope: !44)
!965 = !DILocation(line: 946, column: 11, scope: !44)
!966 = !DILocation(line: 947, column: 46, scope: !44)
!967 = !DILocation(line: 947, column: 35, scope: !44)
!968 = !DILocation(line: 947, column: 24, scope: !44)
!969 = !DILocation(line: 947, column: 13, scope: !44)
!970 = !DILocation(line: 948, column: 11, scope: !44)
!971 = !DILocation(line: 949, column: 15, scope: !44)
!972 = !DILocation(line: 950, column: 22, scope: !44)
!973 = !DILocation(line: 950, column: 16, scope: !44)
!974 = !DILocation(line: 950, column: 5, scope: !44)
!975 = !DILocation(line: 952, column: 1, scope: !22)
!976 = !DILocation(line: 0, scope: !76)
!977 = !DILocation(line: 0, scope: !875, inlinedAt: !978)
!978 = distinct !DILocation(line: 974, column: 3, scope: !83)
!979 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !978)
!980 = !DILocation(line: 0, scope: !83)
!981 = !DILocation(line: 974, column: 3, scope: !83)
!982 = !DILocation(line: 975, column: 10, scope: !983)
!983 = distinct !DILexicalBlock(scope: !76, file: !3, line: 975, column: 7)
!984 = !DILocation(line: 975, column: 7, scope: !76)
!985 = !DILocation(line: 977, column: 17, scope: !986)
!986 = distinct !DILexicalBlock(scope: !983, file: !3, line: 977, column: 14)
!987 = !DILocation(line: 977, column: 14, scope: !983)
!988 = !DILocation(line: 978, column: 12, scope: !989)
!989 = distinct !DILexicalBlock(scope: !990, file: !3, line: 978, column: 9)
!990 = distinct !DILexicalBlock(scope: !986, file: !3, line: 977, column: 32)
!991 = !DILocation(line: 978, column: 9, scope: !990)
!992 = !DILocation(line: 979, column: 16, scope: !993)
!993 = distinct !DILexicalBlock(scope: !989, file: !3, line: 978, column: 27)
!994 = !DILocation(line: 979, column: 7, scope: !993)
!995 = !DILocation(line: 981, column: 14, scope: !996)
!996 = distinct !DILexicalBlock(scope: !989, file: !3, line: 980, column: 12)
!997 = !DILocation(line: 981, column: 33, scope: !996)
!998 = !DILocation(line: 981, column: 7, scope: !996)
!999 = !DILocation(line: 983, column: 19, scope: !1000)
!1000 = distinct !DILexicalBlock(scope: !986, file: !3, line: 983, column: 14)
!1001 = !DILocation(line: 983, column: 33, scope: !1000)
!1002 = !DILocation(line: 983, column: 39, scope: !1000)
!1003 = !DILocation(line: 983, column: 14, scope: !986)
!1004 = !DILocation(line: 985, column: 17, scope: !1005)
!1005 = distinct !DILexicalBlock(scope: !1000, file: !3, line: 985, column: 14)
!1006 = !DILocation(line: 985, column: 14, scope: !1000)
!1007 = !DILocation(line: 986, column: 11, scope: !1008)
!1008 = distinct !DILexicalBlock(scope: !1005, file: !3, line: 985, column: 31)
!1009 = !DILocation(line: 987, column: 56, scope: !1008)
!1010 = !DILocation(line: 987, column: 49, scope: !1008)
!1011 = !DILocation(line: 987, column: 47, scope: !1008)
!1012 = !DILocation(line: 987, column: 36, scope: !1008)
!1013 = !DILocation(line: 987, column: 12, scope: !1008)
!1014 = !DILocation(line: 987, column: 5, scope: !1008)
!1015 = !DILocation(line: 989, column: 11, scope: !1016)
!1016 = distinct !DILexicalBlock(scope: !1005, file: !3, line: 988, column: 10)
!1017 = !DILocation(line: 990, column: 51, scope: !1016)
!1018 = !DILocation(line: 990, column: 47, scope: !1016)
!1019 = !DILocation(line: 990, column: 34, scope: !1016)
!1020 = !DILocation(line: 990, column: 32, scope: !1016)
!1021 = !DILocation(line: 990, column: 12, scope: !1016)
!1022 = !DILocation(line: 990, column: 5, scope: !1016)
!1023 = !DILocation(line: 0, scope: !983)
!1024 = !DILocation(line: 992, column: 1, scope: !76)
!1025 = !DILocation(line: 0, scope: !281)
!1026 = !DILocation(line: 0, scope: !875, inlinedAt: !1027)
!1027 = distinct !DILocation(line: 1684, column: 3, scope: !299)
!1028 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1027)
!1029 = !DILocation(line: 0, scope: !299)
!1030 = !DILocation(line: 1684, column: 3, scope: !299)
!1031 = !DILocation(line: 1687, column: 10, scope: !303)
!1032 = !DILocation(line: 1687, column: 7, scope: !281)
!1033 = !DILocation(line: 1688, column: 14, scope: !1034)
!1034 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1688, column: 9)
!1035 = !DILocation(line: 1688, column: 28, scope: !1034)
!1036 = !DILocation(line: 1688, column: 34, scope: !1034)
!1037 = !DILocation(line: 1688, column: 9, scope: !302)
!1038 = !DILocation(line: 1691, column: 12, scope: !1039)
!1039 = distinct !DILexicalBlock(scope: !302, file: !3, line: 1691, column: 9)
!1040 = !DILocation(line: 1691, column: 9, scope: !302)
!1041 = !DILocation(line: 1695, column: 7, scope: !302)
!1042 = !DILocation(line: 0, scope: !875, inlinedAt: !1043)
!1043 = distinct !DILocation(line: 1696, column: 5, scope: !301)
!1044 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1043)
!1045 = !DILocation(line: 0, scope: !301)
!1046 = !DILocation(line: 1696, column: 5, scope: !301)
!1047 = !DILocation(line: 1697, column: 3, scope: !302)
!1048 = !DILocation(line: 1698, column: 10, scope: !1049)
!1049 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1698, column: 7)
!1050 = !DILocation(line: 1698, column: 7, scope: !281)
!1051 = !DILocation(line: 1698, column: 34, scope: !1049)
!1052 = !DILocation(line: 1698, column: 25, scope: !1049)
!1053 = !DILocation(line: 1699, column: 12, scope: !281)
!1054 = !DILocation(line: 1699, column: 19, scope: !281)
!1055 = !DILocation(line: 1699, column: 5, scope: !281)
!1056 = !DILocation(line: 1700, column: 6, scope: !281)
!1057 = !DILocation(line: 1701, column: 11, scope: !281)
!1058 = !DILocation(line: 1701, column: 22, scope: !281)
!1059 = !DILocation(line: 0, scope: !875, inlinedAt: !1060)
!1060 = distinct !DILocation(line: 1702, column: 3, scope: !305)
!1061 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1060)
!1062 = !DILocation(line: 0, scope: !305)
!1063 = !DILocation(line: 1702, column: 3, scope: !305)
!1064 = !DILocation(line: 0, scope: !949, inlinedAt: !1065)
!1065 = distinct !DILocation(line: 1702, column: 3, scope: !305)
!1066 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !1065)
!1067 = !DILocation(line: 1703, column: 5, scope: !281)
!1068 = !DILocation(line: 1704, column: 9, scope: !281)
!1069 = !DILocation(line: 1705, column: 24, scope: !1070)
!1070 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1705, column: 7)
!1071 = !DILocation(line: 1705, column: 19, scope: !1070)
!1072 = !DILocation(line: 1705, column: 31, scope: !1070)
!1073 = !DILocation(line: 1705, column: 7, scope: !281)
!1074 = !DILocation(line: 1706, column: 11, scope: !1075)
!1075 = distinct !DILexicalBlock(scope: !1076, file: !3, line: 1706, column: 9)
!1076 = distinct !DILexicalBlock(scope: !1070, file: !3, line: 1705, column: 36)
!1077 = !DILocation(line: 1706, column: 9, scope: !1076)
!1078 = !DILocation(line: 1707, column: 13, scope: !1079)
!1079 = distinct !DILexicalBlock(scope: !1080, file: !3, line: 1707, column: 11)
!1080 = distinct !DILexicalBlock(scope: !1075, file: !3, line: 1706, column: 20)
!1081 = !DILocation(line: 1707, column: 11, scope: !1080)
!1082 = !DILocation(line: 1710, column: 14, scope: !1083)
!1083 = distinct !DILexicalBlock(scope: !1079, file: !3, line: 1709, column: 14)
!1084 = !DILocation(line: 1711, column: 33, scope: !1083)
!1085 = !DILocation(line: 1711, column: 28, scope: !1083)
!1086 = !DILocation(line: 1711, column: 9, scope: !1083)
!1087 = !DILocation(line: 1714, column: 11, scope: !1076)
!1088 = !DILocation(line: 1714, column: 22, scope: !1076)
!1089 = !DILocation(line: 1714, column: 15, scope: !1076)
!1090 = !DILocation(line: 1715, column: 11, scope: !1091)
!1091 = distinct !DILexicalBlock(scope: !1076, file: !3, line: 1715, column: 9)
!1092 = !DILocation(line: 1715, column: 9, scope: !1076)
!1093 = !DILocation(line: 1716, column: 16, scope: !1094)
!1094 = distinct !DILexicalBlock(scope: !1091, file: !3, line: 1715, column: 17)
!1095 = !DILocation(line: 1716, column: 7, scope: !1094)
!1096 = !DILocation(line: 1718, column: 12, scope: !1097)
!1097 = distinct !DILexicalBlock(scope: !1091, file: !3, line: 1717, column: 12)
!1098 = !DILocation(line: 1719, column: 32, scope: !1097)
!1099 = !DILocation(line: 1719, column: 47, scope: !1097)
!1100 = !DILocation(line: 1719, column: 26, scope: !1097)
!1101 = !DILocation(line: 1719, column: 7, scope: !1097)
!1102 = !DILocation(line: 1722, column: 16, scope: !281)
!1103 = !DILocation(line: 1722, column: 9, scope: !281)
!1104 = !DILocation(line: 1723, column: 8, scope: !281)
!1105 = !DILocation(line: 1724, column: 9, scope: !281)
!1106 = !DILocation(line: 1725, column: 10, scope: !281)
!1107 = !DILocation(line: 1726, column: 9, scope: !281)
!1108 = !DILocation(line: 1727, column: 15, scope: !281)
!1109 = !DILocation(line: 1728, column: 28, scope: !281)
!1110 = !DILocation(line: 1728, column: 17, scope: !281)
!1111 = !DILocation(line: 1728, column: 10, scope: !281)
!1112 = !DILocation(line: 1729, column: 39, scope: !281)
!1113 = !DILocation(line: 1729, column: 28, scope: !281)
!1114 = !DILocation(line: 1729, column: 17, scope: !281)
!1115 = !DILocation(line: 1729, column: 10, scope: !281)
!1116 = !DILocation(line: 1730, column: 5, scope: !281)
!1117 = !DILocation(line: 1731, column: 10, scope: !281)
!1118 = !DILocation(line: 1732, column: 9, scope: !1119)
!1119 = distinct !DILexicalBlock(scope: !281, file: !3, line: 1732, column: 7)
!1120 = !DILocation(line: 1732, column: 7, scope: !281)
!1121 = !DILocation(line: 1733, column: 16, scope: !1122)
!1122 = distinct !DILexicalBlock(scope: !1119, file: !3, line: 1732, column: 14)
!1123 = !DILocation(line: 1733, column: 20, scope: !1122)
!1124 = !DILocation(line: 1734, column: 11, scope: !1125)
!1125 = distinct !DILexicalBlock(scope: !1122, file: !3, line: 1734, column: 9)
!1126 = !DILocation(line: 0, scope: !1125)
!1127 = !DILocation(line: 1734, column: 9, scope: !1122)
!1128 = !DILocation(line: 1735, column: 24, scope: !1125)
!1129 = !DILocation(line: 1735, column: 16, scope: !1125)
!1130 = !DILocation(line: 1735, column: 7, scope: !1125)
!1131 = !DILocation(line: 1737, column: 58, scope: !1125)
!1132 = !DILocation(line: 1737, column: 53, scope: !1125)
!1133 = !DILocation(line: 1737, column: 35, scope: !1125)
!1134 = !DILocation(line: 1737, column: 69, scope: !1125)
!1135 = !DILocation(line: 1737, column: 26, scope: !1125)
!1136 = !DILocation(line: 1737, column: 7, scope: !1125)
!1137 = !DILocation(line: 1739, column: 11, scope: !1138)
!1138 = distinct !DILexicalBlock(scope: !1139, file: !3, line: 1739, column: 9)
!1139 = distinct !DILexicalBlock(scope: !1119, file: !3, line: 1738, column: 10)
!1140 = !DILocation(line: 0, scope: !1138)
!1141 = !DILocation(line: 1739, column: 9, scope: !1139)
!1142 = !DILocation(line: 1740, column: 16, scope: !1138)
!1143 = !DILocation(line: 1740, column: 7, scope: !1138)
!1144 = !DILocation(line: 1742, column: 42, scope: !1138)
!1145 = !DILocation(line: 1742, column: 57, scope: !1138)
!1146 = !DILocation(line: 1742, column: 26, scope: !1138)
!1147 = !DILocation(line: 1742, column: 7, scope: !1138)
!1148 = !DILocation(line: 1744, column: 1, scope: !281)
!1149 = !DILocation(line: 0, scope: !328)
!1150 = !DILocation(line: 0, scope: !875, inlinedAt: !1151)
!1151 = distinct !DILocation(line: 1828, column: 3, scope: !343)
!1152 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1151)
!1153 = !DILocation(line: 0, scope: !343)
!1154 = !DILocation(line: 1828, column: 3, scope: !343)
!1155 = !DILocation(line: 1829, column: 11, scope: !328)
!1156 = !DILocation(line: 1832, column: 10, scope: !1157)
!1157 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1832, column: 7)
!1158 = !DILocation(line: 1832, column: 7, scope: !328)
!1159 = !DILocation(line: 1833, column: 12, scope: !1160)
!1160 = distinct !DILexicalBlock(scope: !1161, file: !3, line: 1833, column: 9)
!1161 = distinct !DILexicalBlock(scope: !1157, file: !3, line: 1832, column: 24)
!1162 = !DILocation(line: 1833, column: 9, scope: !1161)
!1163 = !DILocation(line: 1834, column: 13, scope: !1164)
!1164 = distinct !DILexicalBlock(scope: !1165, file: !3, line: 1834, column: 11)
!1165 = distinct !DILexicalBlock(scope: !1160, file: !3, line: 1833, column: 27)
!1166 = !DILocation(line: 0, scope: !1164)
!1167 = !DILocation(line: 1839, column: 12, scope: !1168)
!1168 = distinct !DILexicalBlock(scope: !1161, file: !3, line: 1839, column: 9)
!1169 = !DILocation(line: 1839, column: 9, scope: !1161)
!1170 = !DILocation(line: 1840, column: 17, scope: !1171)
!1171 = distinct !DILexicalBlock(scope: !1172, file: !3, line: 1840, column: 11)
!1172 = distinct !DILexicalBlock(scope: !1168, file: !3, line: 1839, column: 26)
!1173 = !DILocation(line: 1840, column: 21, scope: !1171)
!1174 = !DILocation(line: 1841, column: 11, scope: !1171)
!1175 = !DILocation(line: 1844, column: 18, scope: !1171)
!1176 = !DILocation(line: 1844, column: 9, scope: !1171)
!1177 = !DILocation(line: 1852, column: 10, scope: !1178)
!1178 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1852, column: 7)
!1179 = !DILocation(line: 1852, column: 7, scope: !328)
!1180 = !DILocation(line: 1852, column: 34, scope: !1178)
!1181 = !DILocation(line: 1852, column: 25, scope: !1178)
!1182 = !DILocation(line: 1846, column: 16, scope: !1183)
!1183 = distinct !DILexicalBlock(scope: !1161, file: !3, line: 1846, column: 9)
!1184 = !DILocation(line: 1853, column: 7, scope: !328)
!1185 = !DILocation(line: 1883, column: 14, scope: !328)
!1186 = !DILocation(line: 1883, column: 18, scope: !328)
!1187 = !DILocation(line: 1884, column: 7, scope: !328)
!1188 = !DILocation(line: 1854, column: 12, scope: !347)
!1189 = !DILocation(line: 1854, column: 9, scope: !348)
!1190 = !DILocation(line: 1855, column: 15, scope: !346)
!1191 = !DILocation(line: 0, scope: !875, inlinedAt: !1192)
!1192 = distinct !DILocation(line: 1856, column: 7, scope: !345)
!1193 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1192)
!1194 = !DILocation(line: 0, scope: !345)
!1195 = !DILocation(line: 1856, column: 7, scope: !345)
!1196 = !DILocation(line: 1857, column: 15, scope: !346)
!1197 = !DILocation(line: 1858, column: 14, scope: !346)
!1198 = !DILocation(line: 1858, column: 11, scope: !346)
!1199 = !DILocation(line: 1859, column: 9, scope: !346)
!1200 = !DILocation(line: 1860, column: 5, scope: !346)
!1201 = !DILocation(line: 0, scope: !875, inlinedAt: !1202)
!1202 = distinct !DILocation(line: 1862, column: 7, scope: !351)
!1203 = !DILocation(line: 1863, column: 15, scope: !352)
!1204 = !DILocation(line: 0, scope: !347)
!1205 = !DILocation(line: 1866, column: 8, scope: !348)
!1206 = !DILocation(line: 1874, column: 12, scope: !356)
!1207 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1208)
!1208 = !DILocation(line: 0, scope: !356)
!1209 = !DILocation(line: 0, scope: !875, inlinedAt: !1210)
!1210 = distinct !DILocation(line: 1875, column: 7, scope: !354)
!1211 = !DILocation(line: 0, scope: !875, inlinedAt: !1212)
!1212 = distinct !DILocation(line: 1878, column: 7, scope: !358)
!1213 = !DILocation(line: 1874, column: 9, scope: !348)
!1214 = !DILocation(line: 0, scope: !354)
!1215 = !DILocation(line: 1875, column: 7, scope: !354)
!1216 = !DILocation(line: 1876, column: 5, scope: !355)
!1217 = !DILocation(line: 1877, column: 9, scope: !359)
!1218 = !DILocation(line: 0, scope: !358)
!1219 = !DILocation(line: 1878, column: 7, scope: !358)
!1220 = !DILocation(line: 1879, column: 24, scope: !359)
!1221 = !DILocation(line: 0, scope: !348)
!1222 = !DILocation(line: 1881, column: 11, scope: !348)
!1223 = !DILocation(line: 1884, column: 10, scope: !1224)
!1224 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1884, column: 7)
!1225 = !DILocation(line: 1885, column: 11, scope: !1226)
!1226 = distinct !DILexicalBlock(scope: !1227, file: !3, line: 1885, column: 9)
!1227 = distinct !DILexicalBlock(scope: !1224, file: !3, line: 1884, column: 16)
!1228 = !DILocation(line: 1885, column: 9, scope: !1227)
!1229 = !DILocation(line: 1886, column: 13, scope: !1230)
!1230 = distinct !DILexicalBlock(scope: !1231, file: !3, line: 1886, column: 11)
!1231 = distinct !DILexicalBlock(scope: !1226, file: !3, line: 1885, column: 20)
!1232 = !DILocation(line: 1886, column: 11, scope: !1231)
!1233 = !DILocation(line: 1889, column: 14, scope: !1234)
!1234 = distinct !DILexicalBlock(scope: !1230, file: !3, line: 1888, column: 14)
!1235 = !DILocation(line: 1889, column: 11, scope: !1234)
!1236 = !DILocation(line: 1890, column: 27, scope: !1234)
!1237 = !DILocation(line: 1890, column: 9, scope: !1234)
!1238 = !DILocation(line: 1893, column: 21, scope: !1227)
!1239 = !DILocation(line: 1893, column: 14, scope: !1227)
!1240 = !DILocation(line: 1894, column: 11, scope: !1241)
!1241 = distinct !DILexicalBlock(scope: !1227, file: !3, line: 1894, column: 9)
!1242 = !DILocation(line: 1894, column: 9, scope: !1227)
!1243 = !DILocation(line: 1895, column: 16, scope: !1241)
!1244 = !DILocation(line: 1895, column: 7, scope: !1241)
!1245 = !DILocation(line: 1897, column: 14, scope: !1241)
!1246 = !DILocation(line: 1897, column: 45, scope: !1241)
!1247 = !DILocation(line: 1897, column: 31, scope: !1241)
!1248 = !DILocation(line: 1897, column: 51, scope: !1241)
!1249 = !DILocation(line: 1897, column: 25, scope: !1241)
!1250 = !DILocation(line: 1897, column: 7, scope: !1241)
!1251 = !DILocation(line: 1899, column: 16, scope: !328)
!1252 = !DILocation(line: 1899, column: 9, scope: !328)
!1253 = !DILocation(line: 1900, column: 9, scope: !328)
!1254 = !DILocation(line: 1902, column: 65, scope: !328)
!1255 = !DILocation(line: 1902, column: 54, scope: !328)
!1256 = !DILocation(line: 1902, column: 43, scope: !328)
!1257 = !DILocation(line: 1902, column: 32, scope: !328)
!1258 = !DILocation(line: 1902, column: 21, scope: !328)
!1259 = !DILocation(line: 1901, column: 16, scope: !328)
!1260 = !DILocation(line: 1901, column: 9, scope: !328)
!1261 = !DILocation(line: 1903, column: 9, scope: !1262)
!1262 = distinct !DILexicalBlock(scope: !328, file: !3, line: 1903, column: 7)
!1263 = !DILocation(line: 1903, column: 7, scope: !328)
!1264 = !DILocation(line: 1904, column: 34, scope: !1262)
!1265 = !DILocation(line: 1904, column: 22, scope: !1262)
!1266 = !DILocation(line: 1904, column: 14, scope: !1262)
!1267 = !DILocation(line: 1904, column: 5, scope: !1262)
!1268 = !DILocation(line: 1906, column: 12, scope: !1262)
!1269 = !DILocation(line: 1906, column: 45, scope: !1262)
!1270 = !DILocation(line: 1906, column: 64, scope: !1262)
!1271 = !DILocation(line: 1906, column: 50, scope: !1262)
!1272 = !DILocation(line: 1906, column: 32, scope: !1262)
!1273 = !DILocation(line: 1906, column: 71, scope: !1262)
!1274 = !DILocation(line: 1906, column: 23, scope: !1262)
!1275 = !DILocation(line: 1906, column: 5, scope: !1262)
!1276 = !DILocation(line: 1907, column: 1, scope: !328)
!1277 = !DILocation(line: 0, scope: !88)
!1278 = !DILocation(line: 0, scope: !875, inlinedAt: !1279)
!1279 = distinct !DILocation(line: 1045, column: 3, scope: !101)
!1280 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1279)
!1281 = !DILocation(line: 0, scope: !101)
!1282 = !DILocation(line: 1045, column: 3, scope: !101)
!1283 = !DILocation(line: 1046, column: 11, scope: !88)
!1284 = !DILocation(line: 1047, column: 10, scope: !104)
!1285 = !DILocation(line: 1047, column: 7, scope: !88)
!1286 = !DILocation(line: 0, scope: !875, inlinedAt: !1287)
!1287 = distinct !DILocation(line: 1049, column: 5, scope: !106)
!1288 = !DILocation(line: 0, scope: !106)
!1289 = !DILocation(line: 1049, column: 5, scope: !106)
!1290 = !DILocation(line: 0, scope: !103)
!1291 = !DILocation(line: 1050, column: 14, scope: !1292)
!1292 = distinct !DILexicalBlock(scope: !103, file: !3, line: 1050, column: 9)
!1293 = !DILocation(line: 1050, column: 28, scope: !1292)
!1294 = !DILocation(line: 1050, column: 34, scope: !1292)
!1295 = !DILocation(line: 1050, column: 9, scope: !103)
!1296 = !DILocation(line: 1054, column: 17, scope: !1297)
!1297 = distinct !DILexicalBlock(scope: !104, file: !3, line: 1054, column: 14)
!1298 = !DILocation(line: 1054, column: 14, scope: !104)
!1299 = !DILocation(line: 1055, column: 12, scope: !1300)
!1300 = distinct !DILexicalBlock(scope: !1301, file: !3, line: 1055, column: 9)
!1301 = distinct !DILexicalBlock(scope: !1297, file: !3, line: 1054, column: 31)
!1302 = !DILocation(line: 1055, column: 9, scope: !1301)
!1303 = !DILocation(line: 1056, column: 16, scope: !1304)
!1304 = distinct !DILexicalBlock(scope: !1305, file: !3, line: 1056, column: 11)
!1305 = distinct !DILexicalBlock(scope: !1300, file: !3, line: 1055, column: 26)
!1306 = !DILocation(line: 1056, column: 20, scope: !1304)
!1307 = !DILocation(line: 1056, column: 11, scope: !1305)
!1308 = !DILocation(line: 1058, column: 13, scope: !1309)
!1309 = distinct !DILexicalBlock(scope: !1300, file: !3, line: 1057, column: 12)
!1310 = !DILocation(line: 1060, column: 62, scope: !1301)
!1311 = !DILocation(line: 1060, column: 51, scope: !1301)
!1312 = !DILocation(line: 1060, column: 40, scope: !1301)
!1313 = !DILocation(line: 1060, column: 29, scope: !1301)
!1314 = !DILocation(line: 1060, column: 18, scope: !1301)
!1315 = !DILocation(line: 1060, column: 11, scope: !1301)
!1316 = !DILocation(line: 1061, column: 46, scope: !1301)
!1317 = !DILocation(line: 1061, column: 35, scope: !1301)
!1318 = !DILocation(line: 1061, column: 24, scope: !1301)
!1319 = !DILocation(line: 1061, column: 13, scope: !1301)
!1320 = !DILocation(line: 1062, column: 11, scope: !1301)
!1321 = !DILocation(line: 1063, column: 14, scope: !1301)
!1322 = !DILocation(line: 1063, column: 5, scope: !1301)
!1323 = !DILocation(line: 1066, column: 13, scope: !88)
!1324 = !DILocation(line: 1066, column: 11, scope: !88)
!1325 = !DILocation(line: 1067, column: 9, scope: !88)
!1326 = !DILocation(line: 1068, column: 60, scope: !88)
!1327 = !DILocation(line: 1068, column: 49, scope: !88)
!1328 = !DILocation(line: 1068, column: 38, scope: !88)
!1329 = !DILocation(line: 1068, column: 27, scope: !88)
!1330 = !DILocation(line: 1068, column: 16, scope: !88)
!1331 = !DILocation(line: 1068, column: 9, scope: !88)
!1332 = !DILocation(line: 1069, column: 44, scope: !88)
!1333 = !DILocation(line: 1069, column: 33, scope: !88)
!1334 = !DILocation(line: 1069, column: 22, scope: !88)
!1335 = !DILocation(line: 1069, column: 11, scope: !88)
!1336 = !DILocation(line: 1070, column: 7, scope: !88)
!1337 = !DILocation(line: 1071, column: 10, scope: !110)
!1338 = !DILocation(line: 1071, column: 7, scope: !88)
!1339 = !DILocation(line: 1072, column: 11, scope: !1340)
!1340 = distinct !DILexicalBlock(scope: !110, file: !3, line: 1071, column: 25)
!1341 = !DILocation(line: 1073, column: 29, scope: !1340)
!1342 = !DILocation(line: 1073, column: 38, scope: !1340)
!1343 = !DILocation(line: 1073, column: 17, scope: !1340)
!1344 = !DILocation(line: 1074, column: 3, scope: !1340)
!1345 = !DILocation(line: 0, scope: !875, inlinedAt: !1346)
!1346 = distinct !DILocation(line: 1076, column: 5, scope: !108)
!1347 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1346)
!1348 = !DILocation(line: 0, scope: !108)
!1349 = !DILocation(line: 1076, column: 5, scope: !108)
!1350 = !DILocation(line: 0, scope: !949, inlinedAt: !1351)
!1351 = distinct !DILocation(line: 1076, column: 5, scope: !108)
!1352 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !1351)
!1353 = !DILocation(line: 1077, column: 12, scope: !109)
!1354 = !DILocation(line: 1077, column: 26, scope: !109)
!1355 = !DILocation(line: 1077, column: 21, scope: !109)
!1356 = !DILocation(line: 1078, column: 11, scope: !109)
!1357 = !DILocation(line: 1079, column: 13, scope: !109)
!1358 = !DILocation(line: 1079, column: 32, scope: !109)
!1359 = !DILocation(line: 1079, column: 21, scope: !109)
!1360 = !DILocation(line: 1080, column: 17, scope: !109)
!1361 = !DILocation(line: 1081, column: 17, scope: !109)
!1362 = !DILocation(line: 0, scope: !110)
!1363 = !DILocation(line: 1083, column: 10, scope: !1364)
!1364 = distinct !DILexicalBlock(scope: !88, file: !3, line: 1083, column: 7)
!1365 = !DILocation(line: 1083, column: 7, scope: !88)
!1366 = !DILocation(line: 1087, column: 1, scope: !88)
!1367 = !DILocation(line: 0, scope: !141)
!1368 = !DILocation(line: 0, scope: !875, inlinedAt: !1369)
!1369 = distinct !DILocation(line: 1106, column: 3, scope: !149)
!1370 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1369)
!1371 = !DILocation(line: 0, scope: !149)
!1372 = !DILocation(line: 1106, column: 3, scope: !149)
!1373 = !DILocation(line: 1107, column: 11, scope: !141)
!1374 = !DILocation(line: 1108, column: 10, scope: !1375)
!1375 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1108, column: 7)
!1376 = !DILocation(line: 1108, column: 7, scope: !141)
!1377 = !DILocation(line: 1108, column: 34, scope: !1375)
!1378 = !DILocation(line: 1108, column: 25, scope: !1375)
!1379 = !DILocation(line: 1109, column: 10, scope: !1380)
!1380 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1109, column: 7)
!1381 = !DILocation(line: 1109, column: 7, scope: !141)
!1382 = !DILocation(line: 1112, column: 10, scope: !1383)
!1383 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1112, column: 7)
!1384 = !DILocation(line: 1112, column: 7, scope: !141)
!1385 = !DILocation(line: 1113, column: 25, scope: !1386)
!1386 = distinct !DILexicalBlock(scope: !1383, file: !3, line: 1112, column: 24)
!1387 = !DILocation(line: 1113, column: 9, scope: !1386)
!1388 = !DILocation(line: 1113, column: 34, scope: !1386)
!1389 = !DILocation(line: 1114, column: 3, scope: !1386)
!1390 = !DILocation(line: 1114, column: 17, scope: !1391)
!1391 = distinct !DILexicalBlock(scope: !1383, file: !3, line: 1114, column: 14)
!1392 = !DILocation(line: 1114, column: 14, scope: !1383)
!1393 = !DILocation(line: 1115, column: 9, scope: !1394)
!1394 = distinct !DILexicalBlock(scope: !1391, file: !3, line: 1114, column: 31)
!1395 = !DILocation(line: 1116, column: 53, scope: !1394)
!1396 = !DILocation(line: 1116, column: 42, scope: !1394)
!1397 = !DILocation(line: 1116, column: 60, scope: !1394)
!1398 = !DILocation(line: 1116, column: 39, scope: !1394)
!1399 = !DILocation(line: 1116, column: 33, scope: !1394)
!1400 = !DILocation(line: 1116, column: 9, scope: !1394)
!1401 = !DILocation(line: 1117, column: 3, scope: !1394)
!1402 = !DILocation(line: 1118, column: 11, scope: !1403)
!1403 = distinct !DILexicalBlock(scope: !1391, file: !3, line: 1117, column: 10)
!1404 = !DILocation(line: 1119, column: 27, scope: !1403)
!1405 = !DILocation(line: 1119, column: 57, scope: !1403)
!1406 = !DILocation(line: 1119, column: 48, scope: !1403)
!1407 = !DILocation(line: 1119, column: 46, scope: !1403)
!1408 = !DILocation(line: 1119, column: 39, scope: !1403)
!1409 = !DILocation(line: 1119, column: 35, scope: !1403)
!1410 = !DILocation(line: 1119, column: 9, scope: !1403)
!1411 = !DILocation(line: 0, scope: !1383)
!1412 = !DILocation(line: 1121, column: 10, scope: !1413)
!1413 = distinct !DILexicalBlock(scope: !141, file: !3, line: 1121, column: 7)
!1414 = !DILocation(line: 1121, column: 7, scope: !141)
!1415 = !DILocation(line: 1126, column: 1, scope: !141)
!1416 = !DILocation(line: 0, scope: !2)
!1417 = !DILocation(line: 0, scope: !875, inlinedAt: !1418)
!1418 = distinct !DILocation(line: 1181, column: 3, scope: !858)
!1419 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1418)
!1420 = !DILocation(line: 0, scope: !858)
!1421 = !DILocation(line: 1181, column: 3, scope: !858)
!1422 = !DILocation(line: 1182, column: 11, scope: !2)
!1423 = !DILocation(line: 1183, column: 10, scope: !861)
!1424 = !DILocation(line: 1183, column: 7, scope: !2)
!1425 = !DILocation(line: 0, scope: !875, inlinedAt: !1426)
!1426 = distinct !DILocation(line: 1185, column: 5, scope: !863)
!1427 = !DILocation(line: 0, scope: !860)
!1428 = !DILocation(line: 1186, column: 12, scope: !1429)
!1429 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1186, column: 9)
!1430 = !DILocation(line: 1186, column: 25, scope: !1429)
!1431 = !DILocation(line: 1186, column: 32, scope: !1429)
!1432 = !DILocation(line: 1186, column: 46, scope: !1429)
!1433 = !DILocation(line: 1187, column: 16, scope: !1429)
!1434 = !DILocation(line: 1187, column: 7, scope: !1429)
!1435 = !DILocation(line: 1188, column: 12, scope: !1436)
!1436 = distinct !DILexicalBlock(scope: !860, file: !3, line: 1188, column: 9)
!1437 = !DILocation(line: 0, scope: !1436)
!1438 = !{!1439, !1439, i64 0}
!1439 = !{!"double", !1440, i64 0}
!1440 = !{!"omnipotent char", !1441, i64 0}
!1441 = !{!"Simple C/C++ TBAA"}
!1442 = !DILocation(line: 1188, column: 9, scope: !860)
!1443 = !DILocation(line: 1189, column: 24, scope: !1436)
!1444 = !DILocation(line: 1189, column: 7, scope: !1436)
!1445 = !DILocation(line: 1191, column: 25, scope: !1436)
!1446 = !DILocation(line: 1191, column: 7, scope: !1436)
!1447 = !DILocation(line: 1193, column: 10, scope: !1448)
!1448 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1193, column: 7)
!1449 = !DILocation(line: 1193, column: 7, scope: !2)
!1450 = !DILocation(line: 1194, column: 12, scope: !1451)
!1451 = distinct !DILexicalBlock(scope: !1452, file: !3, line: 1194, column: 9)
!1452 = distinct !DILexicalBlock(scope: !1448, file: !3, line: 1193, column: 24)
!1453 = !DILocation(line: 1194, column: 9, scope: !1452)
!1454 = !DILocation(line: 1199, column: 9, scope: !1455)
!1455 = distinct !DILexicalBlock(scope: !1448, file: !3, line: 1198, column: 10)
!1456 = !DILocation(line: 1200, column: 12, scope: !1457)
!1457 = distinct !DILexicalBlock(scope: !1455, file: !3, line: 1200, column: 9)
!1458 = !DILocation(line: 1200, column: 9, scope: !1455)
!1459 = !DILocation(line: 1201, column: 14, scope: !1460)
!1460 = distinct !DILexicalBlock(scope: !1461, file: !3, line: 1201, column: 11)
!1461 = distinct !DILexicalBlock(scope: !1457, file: !3, line: 1200, column: 26)
!1462 = !DILocation(line: 1201, column: 11, scope: !1461)
!1463 = !DILocation(line: 1203, column: 22, scope: !1464)
!1464 = distinct !DILexicalBlock(scope: !1460, file: !3, line: 1201, column: 28)
!1465 = !DILocation(line: 1203, column: 36, scope: !1464)
!1466 = !DILocation(line: 1203, column: 29, scope: !1464)
!1467 = !DILocation(line: 1204, column: 7, scope: !1464)
!1468 = !DILocation(line: 1206, column: 16, scope: !1469)
!1469 = distinct !DILexicalBlock(scope: !1460, file: !3, line: 1204, column: 14)
!1470 = !DILocation(line: 1206, column: 28, scope: !1469)
!1471 = !DILocation(line: 1206, column: 23, scope: !1469)
!1472 = !DILocation(line: 1209, column: 14, scope: !1473)
!1473 = distinct !DILexicalBlock(scope: !1474, file: !3, line: 1209, column: 11)
!1474 = distinct !DILexicalBlock(scope: !1457, file: !3, line: 1208, column: 12)
!1475 = !DILocation(line: 1209, column: 11, scope: !1474)
!1476 = !DILocation(line: 1211, column: 16, scope: !1477)
!1477 = distinct !DILexicalBlock(scope: !1473, file: !3, line: 1209, column: 28)
!1478 = !DILocation(line: 1211, column: 30, scope: !1477)
!1479 = !DILocation(line: 1211, column: 23, scope: !1477)
!1480 = !DILocation(line: 1212, column: 7, scope: !1477)
!1481 = !DILocation(line: 1214, column: 18, scope: !1482)
!1482 = distinct !DILexicalBlock(scope: !1473, file: !3, line: 1212, column: 14)
!1483 = !DILocation(line: 0, scope: !1448)
!1484 = !DILocation(line: 1219, column: 9, scope: !2)
!1485 = !DILocation(line: 1220, column: 9, scope: !2)
!1486 = !DILocation(line: 1223, column: 63, scope: !2)
!1487 = !DILocation(line: 1223, column: 50, scope: !2)
!1488 = !DILocation(line: 1223, column: 37, scope: !2)
!1489 = !DILocation(line: 1223, column: 24, scope: !2)
!1490 = !DILocation(line: 1222, column: 19, scope: !2)
!1491 = !DILocation(line: 1222, column: 10, scope: !2)
!1492 = !DILocation(line: 1224, column: 58, scope: !2)
!1493 = !DILocation(line: 1224, column: 45, scope: !2)
!1494 = !DILocation(line: 1224, column: 32, scope: !2)
!1495 = !DILocation(line: 1224, column: 19, scope: !2)
!1496 = !DILocation(line: 1224, column: 10, scope: !2)
!1497 = !DILocation(line: 1225, column: 7, scope: !2)
!1498 = !DILocation(line: 1226, column: 24, scope: !1499)
!1499 = distinct !DILexicalBlock(scope: !1500, file: !3, line: 1225, column: 15)
!1500 = distinct !DILexicalBlock(scope: !2, file: !3, line: 1225, column: 7)
!1501 = !DILocation(line: 1226, column: 14, scope: !1499)
!1502 = !DILocation(line: 1226, column: 5, scope: !1499)
!1503 = !DILocation(line: 1228, column: 9, scope: !1504)
!1504 = distinct !DILexicalBlock(scope: !1500, file: !3, line: 1227, column: 10)
!1505 = !DILocation(line: 1228, column: 32, scope: !1504)
!1506 = !DILocation(line: 1228, column: 40, scope: !1504)
!1507 = !DILocation(line: 1228, column: 38, scope: !1504)
!1508 = !DILocation(line: 1228, column: 52, scope: !1504)
!1509 = !DILocation(line: 1228, column: 20, scope: !1504)
!1510 = !DILocation(line: 1229, column: 16, scope: !1504)
!1511 = !DILocation(line: 1229, column: 12, scope: !1504)
!1512 = !DILocation(line: 1229, column: 5, scope: !1504)
!1513 = !DILocation(line: 1231, column: 1, scope: !2)
!1514 = !DILocation(line: 0, scope: !170)
!1515 = !DILocation(line: 0, scope: !875, inlinedAt: !1516)
!1516 = distinct !DILocation(line: 1273, column: 3, scope: !186)
!1517 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1516)
!1518 = !DILocation(line: 0, scope: !186)
!1519 = !DILocation(line: 1273, column: 3, scope: !186)
!1520 = !DILocation(line: 1274, column: 11, scope: !170)
!1521 = !DILocation(line: 0, scope: !875, inlinedAt: !1522)
!1522 = distinct !DILocation(line: 1275, column: 3, scope: !188)
!1523 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1522)
!1524 = !DILocation(line: 0, scope: !188)
!1525 = !DILocation(line: 1275, column: 3, scope: !188)
!1526 = !DILocation(line: 1276, column: 11, scope: !170)
!1527 = !DILocation(line: 1277, column: 49, scope: !1528)
!1528 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1277, column: 7)
!1529 = !DILocation(line: 1277, column: 12, scope: !1528)
!1530 = !DILocation(line: 1277, column: 57, scope: !1528)
!1531 = !DILocation(line: 1277, column: 71, scope: !1528)
!1532 = !DILocation(line: 1278, column: 49, scope: !1528)
!1533 = !DILocation(line: 1278, column: 12, scope: !1528)
!1534 = !DILocation(line: 1278, column: 57, scope: !1528)
!1535 = !DILocation(line: 1277, column: 7, scope: !170)
!1536 = !DILocation(line: 1279, column: 14, scope: !1537)
!1537 = distinct !DILexicalBlock(scope: !1528, file: !3, line: 1278, column: 72)
!1538 = !DILocation(line: 1279, column: 5, scope: !1537)
!1539 = !DILocalVariable(name: "a", arg: 1, scope: !1540, file: !3, line: 68, type: !18)
!1540 = distinct !DISubprogram(name: "sub_with_wraparound", scope: !3, file: !3, line: 68, type: !1541, scopeLine: 68, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1543)
!1541 = !DISubroutineType(types: !1542)
!1542 = !{!18, !18, !18}
!1543 = !{!1539, !1544}
!1544 = !DILocalVariable(name: "b", arg: 2, scope: !1540, file: !3, line: 68, type: !18)
!1545 = !DILocation(line: 0, scope: !1540, inlinedAt: !1546)
!1546 = distinct !DILocation(line: 1281, column: 8, scope: !1547)
!1547 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1281, column: 7)
!1548 = !DILocation(line: 68, column: 96, scope: !1540, inlinedAt: !1546)
!1549 = !DILocation(line: 1281, column: 44, scope: !1547)
!1550 = !DILocation(line: 1281, column: 50, scope: !1547)
!1551 = !DILocation(line: 1281, column: 7, scope: !170)
!1552 = !DILocation(line: 1282, column: 12, scope: !1553)
!1553 = distinct !DILexicalBlock(scope: !1547, file: !3, line: 1281, column: 56)
!1554 = !DILocation(line: 1282, column: 5, scope: !1553)
!1555 = !DILocation(line: 1284, column: 12, scope: !170)
!1556 = !DILocation(line: 1284, column: 31, scope: !170)
!1557 = !DILocation(line: 1284, column: 38, scope: !170)
!1558 = !DILocation(line: 1284, column: 24, scope: !170)
!1559 = !DILocation(line: 1287, column: 11, scope: !1560)
!1560 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1287, column: 7)
!1561 = !DILocation(line: 1287, column: 17, scope: !1560)
!1562 = !DILocation(line: 1287, column: 7, scope: !170)
!1563 = !DILocation(line: 1288, column: 5, scope: !1564)
!1564 = distinct !DILexicalBlock(scope: !1560, file: !3, line: 1287, column: 23)
!1565 = !DILocation(line: 1293, column: 21, scope: !1566)
!1566 = distinct !DILexicalBlock(scope: !1564, file: !3, line: 1288, column: 16)
!1567 = !DILocation(line: 1293, column: 19, scope: !1566)
!1568 = !DILocation(line: 1293, column: 9, scope: !1566)
!1569 = !DILocation(line: 1295, column: 22, scope: !1566)
!1570 = !DILocation(line: 1295, column: 20, scope: !1566)
!1571 = !DILocation(line: 1295, column: 9, scope: !1566)
!1572 = !DILocation(line: 1299, column: 11, scope: !1573)
!1573 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1299, column: 7)
!1574 = !DILocation(line: 1299, column: 17, scope: !1573)
!1575 = !DILocation(line: 1299, column: 7, scope: !170)
!1576 = !DILocation(line: 1299, column: 34, scope: !1573)
!1577 = !DILocation(line: 1299, scope: !1573)
!1578 = !DILocation(line: 1299, column: 30, scope: !1573)
!1579 = !DILocation(line: 1299, column: 49, scope: !1573)
!1580 = !DILocation(line: 1299, column: 65, scope: !1573)
!1581 = !DILocation(line: 1302, column: 10, scope: !1582)
!1582 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1302, column: 7)
!1583 = !DILocation(line: 1302, column: 7, scope: !170)
!1584 = !DILocation(line: 1303, column: 9, scope: !1585)
!1585 = distinct !DILexicalBlock(scope: !1582, file: !3, line: 1302, column: 25)
!1586 = !DILocation(line: 1304, column: 7, scope: !1587)
!1587 = distinct !DILexicalBlock(scope: !1588, file: !3, line: 1303, column: 27)
!1588 = distinct !DILexicalBlock(scope: !1585, file: !3, line: 1303, column: 9)
!1589 = !DILocation(line: 1306, column: 27, scope: !1590)
!1590 = distinct !DILexicalBlock(scope: !1587, file: !3, line: 1304, column: 18)
!1591 = !DILocation(line: 1306, column: 25, scope: !1590)
!1592 = !DILocation(line: 1306, column: 11, scope: !1590)
!1593 = !DILocation(line: 1308, column: 28, scope: !1590)
!1594 = !DILocation(line: 1308, column: 26, scope: !1590)
!1595 = !DILocation(line: 1308, column: 11, scope: !1590)
!1596 = !DILocation(line: 1310, column: 33, scope: !1590)
!1597 = !DILocation(line: 1310, column: 31, scope: !1590)
!1598 = !DILocation(line: 1310, column: 11, scope: !1590)
!1599 = !DILocation(line: 1312, column: 34, scope: !1590)
!1600 = !DILocation(line: 1312, column: 32, scope: !1590)
!1601 = !DILocation(line: 1312, column: 11, scope: !1590)
!1602 = !DILocation(line: 1315, column: 7, scope: !1603)
!1603 = distinct !DILexicalBlock(scope: !1588, file: !3, line: 1314, column: 12)
!1604 = !DILocation(line: 1319, column: 11, scope: !1605)
!1605 = distinct !DILexicalBlock(scope: !1603, file: !3, line: 1315, column: 18)
!1606 = !DILocation(line: 1321, column: 23, scope: !1605)
!1607 = !DILocation(line: 1321, column: 21, scope: !1605)
!1608 = !DILocation(line: 1321, column: 11, scope: !1605)
!1609 = !DILocation(line: 1323, column: 24, scope: !1605)
!1610 = !DILocation(line: 1323, column: 22, scope: !1605)
!1611 = !DILocation(line: 1323, column: 11, scope: !1605)
!1612 = !DILocation(line: 1328, column: 7, scope: !170)
!1613 = !DILocation(line: 1328, column: 36, scope: !1614)
!1614 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1328, column: 7)
!1615 = !DILocation(line: 1328, scope: !1614)
!1616 = !DILocation(line: 1328, column: 32, scope: !1614)
!1617 = !DILocation(line: 1328, column: 51, scope: !1614)
!1618 = !DILocation(line: 1328, column: 67, scope: !1614)
!1619 = !DILocation(line: 1331, column: 11, scope: !170)
!1620 = !DILocation(line: 1331, column: 17, scope: !170)
!1621 = !DILocation(line: 1332, column: 9, scope: !1622)
!1622 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1332, column: 7)
!1623 = !DILocation(line: 1332, column: 7, scope: !170)
!1624 = !DILocation(line: 1333, column: 24, scope: !1625)
!1625 = distinct !DILexicalBlock(scope: !1622, file: !3, line: 1332, column: 15)
!1626 = !DILocation(line: 1333, column: 16, scope: !1625)
!1627 = !DILocation(line: 1335, column: 3, scope: !1625)
!1628 = !DILocation(line: 1335, column: 17, scope: !1629)
!1629 = distinct !DILexicalBlock(scope: !1622, file: !3, line: 1335, column: 14)
!1630 = !DILocation(line: 1335, column: 21, scope: !1629)
!1631 = !DILocation(line: 1338, column: 33, scope: !1632)
!1632 = distinct !DILexicalBlock(scope: !1629, file: !3, line: 1337, column: 10)
!1633 = !DILocation(line: 1338, column: 26, scope: !1632)
!1634 = !DILocation(line: 1338, column: 9, scope: !1632)
!1635 = !DILocation(line: 0, scope: !1622)
!1636 = !DILocation(line: 1340, column: 3, scope: !170)
!1637 = !DILocation(line: 1344, column: 14, scope: !1638)
!1638 = distinct !DILexicalBlock(scope: !170, file: !3, line: 1340, column: 14)
!1639 = !DILocation(line: 1344, column: 7, scope: !1638)
!1640 = !DILocation(line: 1346, column: 24, scope: !1638)
!1641 = !DILocation(line: 1346, column: 17, scope: !1638)
!1642 = !DILocation(line: 1346, column: 7, scope: !1638)
!1643 = !DILocation(line: 1348, column: 19, scope: !1638)
!1644 = !DILocation(line: 1348, column: 17, scope: !1638)
!1645 = !DILocation(line: 1348, column: 26, scope: !1638)
!1646 = !DILocation(line: 1348, column: 7, scope: !1638)
!1647 = !DILocation(line: 1350, column: 1, scope: !170)
!1648 = distinct !DISubprogram(name: "pts_ieee754_cos", scope: !3, file: !3, line: 1382, type: !4, scopeLine: 1382, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !1649)
!1649 = !{!1650, !1651, !1653, !1654, !1655, !1656}
!1650 = !DILocalVariable(name: "x", arg: 1, scope: !1648, file: !3, line: 1382, type: !6)
!1651 = !DILocalVariable(name: "y", scope: !1648, file: !3, line: 1383, type: !1652)
!1652 = !DICompositeType(tag: DW_TAG_array_type, baseType: !6, size: 128, elements: !232)
!1653 = !DILocalVariable(name: "z", scope: !1648, file: !3, line: 1383, type: !6)
!1654 = !DILocalVariable(name: "n", scope: !1648, file: !3, line: 1384, type: !18)
!1655 = !DILocalVariable(name: "ix", scope: !1648, file: !3, line: 1384, type: !18)
!1656 = !DILocalVariable(name: "bits", scope: !1657, file: !3, line: 1387, type: !16)
!1657 = distinct !DILexicalBlock(scope: !1648, file: !3, line: 1387, column: 3)
!1658 = distinct !DIAssignID()
!1659 = !DILocation(line: 0, scope: !1648)
!1660 = !DILocation(line: 1383, column: 3, scope: !1648)
!1661 = !DILocation(line: 0, scope: !875, inlinedAt: !1662)
!1662 = distinct !DILocation(line: 1387, column: 3, scope: !1657)
!1663 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1662)
!1664 = !DILocation(line: 0, scope: !1657)
!1665 = !DILocation(line: 1387, column: 3, scope: !1657)
!1666 = !DILocation(line: 1390, column: 6, scope: !1648)
!1667 = !DILocation(line: 1391, column: 10, scope: !1668)
!1668 = distinct !DILexicalBlock(scope: !1648, file: !3, line: 1391, column: 7)
!1669 = !DILocation(line: 1391, column: 7, scope: !1648)
!1670 = !DILocation(line: 0, scope: !607, inlinedAt: !1671)
!1671 = distinct !DILocation(line: 1392, column: 12, scope: !1672)
!1672 = distinct !DILexicalBlock(scope: !1668, file: !3, line: 1391, column: 25)
!1673 = !DILocation(line: 0, scope: !875, inlinedAt: !1674)
!1674 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1671)
!1675 = !DILocation(line: 0, scope: !618, inlinedAt: !1671)
!1676 = !DILocation(line: 350, column: 10, scope: !1677, inlinedAt: !1671)
!1677 = distinct !DILexicalBlock(scope: !607, file: !3, line: 350, column: 7)
!1678 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1671)
!1679 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1671)
!1680 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1671)
!1681 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1671)
!1682 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1671)
!1683 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1671)
!1684 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1671)
!1685 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1671)
!1686 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1671)
!1687 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1671)
!1688 = !DILocation(line: 356, column: 36, scope: !1689, inlinedAt: !1671)
!1689 = distinct !DILexicalBlock(scope: !624, file: !3, line: 355, column: 24)
!1690 = !DILocation(line: 356, column: 27, scope: !1689, inlinedAt: !1671)
!1691 = !DILocation(line: 356, column: 16, scope: !1689, inlinedAt: !1671)
!1692 = !DILocation(line: 356, column: 5, scope: !1689, inlinedAt: !1671)
!1693 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1671)
!1694 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1671)
!1695 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1671)
!1696 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1671)
!1697 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1671)
!1698 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1671)
!1699 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1671)
!1700 = !DILocation(line: 1393, column: 17, scope: !1701)
!1701 = distinct !DILexicalBlock(scope: !1668, file: !3, line: 1393, column: 14)
!1702 = !DILocation(line: 1393, column: 14, scope: !1668)
!1703 = !DILocation(line: 1395, column: 14, scope: !1704)
!1704 = distinct !DILexicalBlock(scope: !1701, file: !3, line: 1393, column: 32)
!1705 = !DILocation(line: 1395, column: 5, scope: !1704)
!1706 = !DILocation(line: 1398, column: 9, scope: !1707)
!1707 = distinct !DILexicalBlock(scope: !1701, file: !3, line: 1396, column: 10)
!1708 = !DILocation(line: 1399, column: 15, scope: !1707)
!1709 = !DILocation(line: 0, scope: !1710)
!1710 = distinct !DILexicalBlock(scope: !1707, file: !3, line: 1399, column: 20)
!1711 = !DILocation(line: 1399, column: 5, scope: !1707)
!1712 = !DILocation(line: 1401, column: 35, scope: !1710)
!1713 = !DILocation(line: 0, scope: !607, inlinedAt: !1714)
!1714 = distinct !DILocation(line: 1401, column: 16, scope: !1710)
!1715 = !DILocation(line: 0, scope: !875, inlinedAt: !1716)
!1716 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1714)
!1717 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1716)
!1718 = !DILocation(line: 0, scope: !618, inlinedAt: !1714)
!1719 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1714)
!1720 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !1714)
!1721 = !DILocation(line: 350, column: 10, scope: !1677, inlinedAt: !1714)
!1722 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1714)
!1723 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1714)
!1724 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1714)
!1725 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1714)
!1726 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1714)
!1727 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1714)
!1728 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1714)
!1729 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1714)
!1730 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1714)
!1731 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1714)
!1732 = !DILocation(line: 356, column: 36, scope: !1689, inlinedAt: !1714)
!1733 = !DILocation(line: 356, column: 27, scope: !1689, inlinedAt: !1714)
!1734 = !DILocation(line: 356, column: 16, scope: !1689, inlinedAt: !1714)
!1735 = !DILocation(line: 356, column: 5, scope: !1689, inlinedAt: !1714)
!1736 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1714)
!1737 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1714)
!1738 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1714)
!1739 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1714)
!1740 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1714)
!1741 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1714)
!1742 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1714)
!1743 = !DILocation(line: 0, scope: !765, inlinedAt: !1744)
!1744 = distinct !DILocation(line: 1403, column: 17, scope: !1710)
!1745 = !DILocation(line: 0, scope: !875, inlinedAt: !1746)
!1746 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !1744)
!1747 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1746)
!1748 = !DILocation(line: 0, scope: !777, inlinedAt: !1744)
!1749 = !DILocation(line: 718, column: 10, scope: !1750, inlinedAt: !1744)
!1750 = distinct !DILexicalBlock(scope: !765, file: !3, line: 718, column: 7)
!1751 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !1744)
!1752 = !DILocation(line: 1403, column: 36, scope: !1710)
!1753 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !1744)
!1754 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !1744)
!1755 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !1744)
!1756 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !1744)
!1757 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !1744)
!1758 = !DILocation(line: 727, column: 32, scope: !1759, inlinedAt: !1744)
!1759 = distinct !DILexicalBlock(scope: !1760, file: !3, line: 726, column: 10)
!1760 = distinct !DILexicalBlock(scope: !765, file: !3, line: 724, column: 7)
!1761 = !DILocation(line: 727, column: 41, scope: !1759, inlinedAt: !1744)
!1762 = !DILocation(line: 727, column: 46, scope: !1759, inlinedAt: !1744)
!1763 = !DILocation(line: 727, column: 14, scope: !1759, inlinedAt: !1744)
!1764 = !DILocation(line: 727, column: 5, scope: !1759, inlinedAt: !1744)
!1765 = !DILocation(line: 1403, column: 16, scope: !1710)
!1766 = !DILocation(line: 1403, column: 9, scope: !1710)
!1767 = !DILocation(line: 1405, column: 36, scope: !1710)
!1768 = !DILocation(line: 0, scope: !607, inlinedAt: !1769)
!1769 = distinct !DILocation(line: 1405, column: 17, scope: !1710)
!1770 = !DILocation(line: 0, scope: !875, inlinedAt: !1771)
!1771 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1769)
!1772 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1771)
!1773 = !DILocation(line: 0, scope: !618, inlinedAt: !1769)
!1774 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !1769)
!1775 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !1769)
!1776 = !DILocation(line: 350, column: 10, scope: !1677, inlinedAt: !1769)
!1777 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !1769)
!1778 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !1769)
!1779 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !1769)
!1780 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !1769)
!1781 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !1769)
!1782 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !1769)
!1783 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !1769)
!1784 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !1769)
!1785 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !1769)
!1786 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !1769)
!1787 = !DILocation(line: 356, column: 36, scope: !1689, inlinedAt: !1769)
!1788 = !DILocation(line: 356, column: 27, scope: !1689, inlinedAt: !1769)
!1789 = !DILocation(line: 356, column: 16, scope: !1689, inlinedAt: !1769)
!1790 = !DILocation(line: 356, column: 5, scope: !1689, inlinedAt: !1769)
!1791 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !1769)
!1792 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !1769)
!1793 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !1769)
!1794 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !1769)
!1795 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !1769)
!1796 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !1769)
!1797 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !1769)
!1798 = !DILocation(line: 1405, column: 16, scope: !1710)
!1799 = !DILocation(line: 1405, column: 9, scope: !1710)
!1800 = !DILocation(line: 0, scope: !765, inlinedAt: !1801)
!1801 = distinct !DILocation(line: 1407, column: 16, scope: !1710)
!1802 = !DILocation(line: 0, scope: !875, inlinedAt: !1803)
!1803 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !1801)
!1804 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1803)
!1805 = !DILocation(line: 0, scope: !777, inlinedAt: !1801)
!1806 = !DILocation(line: 718, column: 10, scope: !1750, inlinedAt: !1801)
!1807 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !1801)
!1808 = !DILocation(line: 1407, column: 35, scope: !1710)
!1809 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !1801)
!1810 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !1801)
!1811 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !1801)
!1812 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !1801)
!1813 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !1801)
!1814 = !DILocation(line: 727, column: 32, scope: !1759, inlinedAt: !1801)
!1815 = !DILocation(line: 727, column: 41, scope: !1759, inlinedAt: !1801)
!1816 = !DILocation(line: 727, column: 46, scope: !1759, inlinedAt: !1801)
!1817 = !DILocation(line: 727, column: 14, scope: !1759, inlinedAt: !1801)
!1818 = !DILocation(line: 727, column: 5, scope: !1759, inlinedAt: !1801)
!1819 = !DILocation(line: 0, scope: !1668)
!1820 = !DILocation(line: 1410, column: 1, scope: !1648)
!1821 = distinct !DIAssignID()
!1822 = distinct !DIAssignID()
!1823 = distinct !DIAssignID()
!1824 = distinct !DIAssignID()
!1825 = distinct !DIAssignID()
!1826 = !DILocation(line: 0, scope: !639)
!1827 = !DILocation(line: 198, column: 3, scope: !639)
!1828 = !DILocation(line: 0, scope: !875, inlinedAt: !1829)
!1829 = distinct !DILocation(line: 203, column: 3, scope: !664)
!1830 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1829)
!1831 = !DILocation(line: 0, scope: !664)
!1832 = !DILocation(line: 203, column: 3, scope: !664)
!1833 = !DILocation(line: 204, column: 11, scope: !639)
!1834 = !DILocation(line: 205, column: 10, scope: !1835)
!1835 = distinct !DILexicalBlock(scope: !639, file: !3, line: 205, column: 7)
!1836 = !DILocation(line: 205, column: 7, scope: !639)
!1837 = !DILocation(line: 206, column: 10, scope: !1838)
!1838 = distinct !DILexicalBlock(scope: !1835, file: !3, line: 205, column: 25)
!1839 = !DILocation(line: 207, column: 5, scope: !1838)
!1840 = !DILocation(line: 207, column: 10, scope: !1838)
!1841 = !DILocation(line: 208, column: 5, scope: !1838)
!1842 = !DILocation(line: 210, column: 10, scope: !1843)
!1843 = distinct !DILexicalBlock(scope: !639, file: !3, line: 210, column: 7)
!1844 = !DILocation(line: 210, column: 7, scope: !639)
!1845 = !DILocation(line: 211, column: 12, scope: !1846)
!1846 = distinct !DILexicalBlock(scope: !1847, file: !3, line: 211, column: 9)
!1847 = distinct !DILexicalBlock(scope: !1843, file: !3, line: 210, column: 24)
!1848 = !DILocation(line: 0, scope: !1846)
!1849 = !DILocation(line: 211, column: 9, scope: !1847)
!1850 = !DILocation(line: 212, column: 13, scope: !1851)
!1851 = distinct !DILexicalBlock(scope: !1846, file: !3, line: 211, column: 17)
!1852 = !DILocation(line: 213, column: 11, scope: !1851)
!1853 = !DILocation(line: 214, column: 18, scope: !1854)
!1854 = distinct !DILexicalBlock(scope: !1855, file: !3, line: 213, column: 29)
!1855 = distinct !DILexicalBlock(scope: !1851, file: !3, line: 213, column: 11)
!1856 = !DILocation(line: 214, column: 14, scope: !1854)
!1857 = !DILocation(line: 215, column: 19, scope: !1854)
!1858 = !DILocation(line: 215, column: 27, scope: !1854)
!1859 = !DILocation(line: 215, column: 9, scope: !1854)
!1860 = !DILocation(line: 215, column: 14, scope: !1854)
!1861 = !DILocation(line: 216, column: 7, scope: !1854)
!1862 = !DILocation(line: 217, column: 11, scope: !1863)
!1863 = distinct !DILexicalBlock(scope: !1855, file: !3, line: 216, column: 14)
!1864 = !DILocation(line: 218, column: 18, scope: !1863)
!1865 = !DILocation(line: 218, column: 14, scope: !1863)
!1866 = !DILocation(line: 219, column: 19, scope: !1863)
!1867 = !DILocation(line: 219, column: 27, scope: !1863)
!1868 = !DILocation(line: 219, column: 9, scope: !1863)
!1869 = !DILocation(line: 219, column: 14, scope: !1863)
!1870 = !DILocation(line: 223, column: 13, scope: !1871)
!1871 = distinct !DILexicalBlock(scope: !1846, file: !3, line: 222, column: 12)
!1872 = !DILocation(line: 224, column: 11, scope: !1871)
!1873 = !DILocation(line: 225, column: 18, scope: !1874)
!1874 = distinct !DILexicalBlock(scope: !1875, file: !3, line: 224, column: 29)
!1875 = distinct !DILexicalBlock(scope: !1871, file: !3, line: 224, column: 11)
!1876 = !DILocation(line: 225, column: 14, scope: !1874)
!1877 = !DILocation(line: 226, column: 19, scope: !1874)
!1878 = !DILocation(line: 226, column: 27, scope: !1874)
!1879 = !DILocation(line: 226, column: 9, scope: !1874)
!1880 = !DILocation(line: 226, column: 14, scope: !1874)
!1881 = !DILocation(line: 227, column: 7, scope: !1874)
!1882 = !DILocation(line: 228, column: 11, scope: !1883)
!1883 = distinct !DILexicalBlock(scope: !1875, file: !3, line: 227, column: 14)
!1884 = !DILocation(line: 229, column: 18, scope: !1883)
!1885 = !DILocation(line: 229, column: 14, scope: !1883)
!1886 = !DILocation(line: 230, column: 19, scope: !1883)
!1887 = !DILocation(line: 230, column: 27, scope: !1883)
!1888 = !DILocation(line: 230, column: 9, scope: !1883)
!1889 = !DILocation(line: 230, column: 14, scope: !1883)
!1890 = !DILocation(line: 235, column: 10, scope: !669)
!1891 = !DILocation(line: 235, column: 7, scope: !639)
!1892 = !DILocation(line: 236, column: 9, scope: !668)
!1893 = !DILocation(line: 237, column: 31, scope: !668)
!1894 = !DILocation(line: 237, column: 9, scope: !668)
!1895 = !DILocation(line: 238, column: 10, scope: !668)
!1896 = !DILocation(line: 239, column: 11, scope: !668)
!1897 = !DILocation(line: 240, column: 12, scope: !668)
!1898 = !DILocation(line: 241, column: 11, scope: !667)
!1899 = !DILocation(line: 241, column: 16, scope: !667)
!1900 = !DILocation(line: 241, column: 36, scope: !667)
!1901 = !DILocation(line: 241, column: 25, scope: !667)
!1902 = !{!1903, !1903, i64 0}
!1903 = !{!"int", !1440, i64 0}
!1904 = !DILocation(line: 241, column: 22, scope: !667)
!1905 = !DILocation(line: 241, column: 9, scope: !668)
!1906 = !DILocation(line: 242, column: 16, scope: !1907)
!1907 = distinct !DILexicalBlock(scope: !667, file: !3, line: 241, column: 42)
!1908 = !DILocation(line: 243, column: 5, scope: !1907)
!1909 = !DILocation(line: 246, column: 16, scope: !666)
!1910 = !DILocation(line: 246, column: 12, scope: !666)
!1911 = !DILocation(line: 0, scope: !875, inlinedAt: !1912)
!1912 = distinct !DILocation(line: 247, column: 7, scope: !671)
!1913 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1912)
!1914 = !DILocation(line: 0, scope: !671)
!1915 = !DILocation(line: 0, scope: !666)
!1916 = !DILocation(line: 248, column: 22, scope: !666)
!1917 = !DILocation(line: 248, column: 29, scope: !666)
!1918 = !DILocation(line: 248, column: 13, scope: !666)
!1919 = !DILocation(line: 249, column: 13, scope: !675)
!1920 = !DILocation(line: 249, column: 11, scope: !666)
!1921 = !DILocation(line: 251, column: 16, scope: !674)
!1922 = !DILocation(line: 252, column: 15, scope: !674)
!1923 = !DILocation(line: 253, column: 32, scope: !674)
!1924 = !DILocation(line: 253, column: 37, scope: !674)
!1925 = !DILocation(line: 253, column: 26, scope: !674)
!1926 = !DILocation(line: 254, column: 18, scope: !674)
!1927 = !DILocation(line: 254, column: 14, scope: !674)
!1928 = !DILocation(line: 0, scope: !875, inlinedAt: !1929)
!1929 = distinct !DILocation(line: 255, column: 9, scope: !673)
!1930 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !1929)
!1931 = !DILocation(line: 0, scope: !673)
!1932 = !DILocation(line: 256, column: 24, scope: !674)
!1933 = !DILocation(line: 256, column: 31, scope: !674)
!1934 = !DILocation(line: 256, column: 15, scope: !674)
!1935 = !DILocation(line: 257, column: 15, scope: !1936)
!1936 = distinct !DILexicalBlock(scope: !674, file: !3, line: 257, column: 13)
!1937 = !DILocation(line: 257, column: 13, scope: !674)
!1938 = !DILocation(line: 259, column: 18, scope: !1939)
!1939 = distinct !DILexicalBlock(scope: !1936, file: !3, line: 257, column: 21)
!1940 = !DILocation(line: 260, column: 17, scope: !1939)
!1941 = !DILocation(line: 261, column: 34, scope: !1939)
!1942 = !DILocation(line: 261, column: 39, scope: !1939)
!1943 = !DILocation(line: 261, column: 28, scope: !1939)
!1944 = !DILocation(line: 262, column: 20, scope: !1939)
!1945 = !DILocation(line: 263, column: 9, scope: !1939)
!1946 = !DILocation(line: 0, scope: !667)
!1947 = !DILocation(line: 266, column: 15, scope: !668)
!1948 = !DILocation(line: 266, column: 17, scope: !668)
!1949 = !DILocation(line: 0, scope: !668)
!1950 = !DILocation(line: 266, column: 23, scope: !668)
!1951 = !DILocation(line: 266, column: 5, scope: !668)
!1952 = !DILocation(line: 266, column: 10, scope: !668)
!1953 = !DILocation(line: 267, column: 12, scope: !1954)
!1954 = distinct !DILexicalBlock(scope: !668, file: !3, line: 267, column: 9)
!1955 = !DILocation(line: 267, column: 9, scope: !668)
!1956 = !DILocation(line: 268, column: 14, scope: !1957)
!1957 = distinct !DILexicalBlock(scope: !1954, file: !3, line: 267, column: 17)
!1958 = !DILocation(line: 268, column: 12, scope: !1957)
!1959 = !DILocation(line: 269, column: 14, scope: !1957)
!1960 = !DILocation(line: 269, column: 12, scope: !1957)
!1961 = !DILocation(line: 270, column: 14, scope: !1957)
!1962 = !DILocation(line: 270, column: 7, scope: !1957)
!1963 = !DILocation(line: 278, column: 10, scope: !1964)
!1964 = distinct !DILexicalBlock(scope: !639, file: !3, line: 278, column: 7)
!1965 = !DILocation(line: 278, column: 7, scope: !639)
!1966 = !DILocation(line: 279, column: 21, scope: !1967)
!1967 = distinct !DILexicalBlock(scope: !1964, file: !3, line: 278, column: 25)
!1968 = !DILocation(line: 279, column: 12, scope: !1967)
!1969 = !DILocation(line: 279, column: 17, scope: !1967)
!1970 = !DILocation(line: 279, column: 10, scope: !1967)
!1971 = !DILocation(line: 280, column: 5, scope: !1967)
!1972 = !DILocation(line: 0, scope: !875, inlinedAt: !1973)
!1973 = distinct !DILocation(line: 283, column: 3, scope: !677)
!1974 = !DILocation(line: 0, scope: !875, inlinedAt: !1975)
!1975 = distinct !DILocation(line: 284, column: 3, scope: !679)
!1976 = !DILocation(line: 0, scope: !679)
!1977 = !DILocation(line: 284, column: 3, scope: !679)
!1978 = !DILocation(line: 0, scope: !949, inlinedAt: !1979)
!1979 = distinct !DILocation(line: 284, column: 3, scope: !679)
!1980 = !DILocation(line: 285, column: 19, scope: !639)
!1981 = !DILocation(line: 0, scope: !875, inlinedAt: !1982)
!1982 = distinct !DILocation(line: 286, column: 3, scope: !681)
!1983 = !DILocation(line: 0, scope: !681)
!1984 = !DILocation(line: 286, column: 3, scope: !681)
!1985 = !DILocation(line: 0, scope: !949, inlinedAt: !1986)
!1986 = distinct !DILocation(line: 286, column: 3, scope: !681)
!1987 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !1986)
!1988 = !DILocation(line: 288, column: 22, scope: !1989)
!1989 = distinct !DILexicalBlock(scope: !1990, file: !3, line: 287, column: 27)
!1990 = distinct !DILexicalBlock(scope: !1991, file: !3, line: 287, column: 3)
!1991 = distinct !DILexicalBlock(scope: !639, file: !3, line: 287, column: 3)
!1992 = !DILocation(line: 288, column: 13, scope: !1989)
!1993 = !DILocation(line: 288, column: 11, scope: !1989)
!1994 = !DILocation(line: 289, column: 12, scope: !1989)
!1995 = !DILocation(line: 289, column: 21, scope: !1989)
!1996 = !DILocation(line: 288, column: 5, scope: !1989)
!1997 = !DILocation(line: 291, column: 3, scope: !639)
!1998 = !DILocation(line: 291, column: 9, scope: !639)
!1999 = distinct !DIAssignID()
!2000 = !DILocation(line: 293, column: 3, scope: !639)
!2001 = !DILocation(line: 293, column: 16, scope: !639)
!2002 = !DILocation(line: 293, column: 10, scope: !639)
!2003 = !DILocation(line: 293, column: 21, scope: !639)
!2004 = distinct !{!2004, !2000, !2005, !2006}
!2005 = !DILocation(line: 293, column: 32, scope: !639)
!2006 = !{!"llvm.loop.mustprogress"}
!2007 = !DILocation(line: 501, column: 3, scope: !713, inlinedAt: !2008)
!2008 = distinct !DILocation(line: 294, column: 7, scope: !639)
!2009 = !DILocation(line: 0, scope: !713, inlinedAt: !2008)
!2010 = !DILocation(line: 502, column: 3, scope: !713, inlinedAt: !2008)
!2011 = !DILocation(line: 510, column: 12, scope: !713, inlinedAt: !2008)
!2012 = !DILocation(line: 510, column: 17, scope: !713, inlinedAt: !2008)
!2013 = !DILocation(line: 512, column: 16, scope: !713, inlinedAt: !2008)
!2014 = !DILocation(line: 512, column: 11, scope: !713, inlinedAt: !2008)
!2015 = !DILocation(line: 517, column: 17, scope: !2016, inlinedAt: !2008)
!2016 = distinct !DILexicalBlock(scope: !2017, file: !3, line: 517, column: 3)
!2017 = distinct !DILexicalBlock(scope: !713, file: !3, line: 517, column: 3)
!2018 = !DILocation(line: 517, column: 3, scope: !2017, inlinedAt: !2008)
!2019 = !DILocation(line: 516, column: 10, scope: !713, inlinedAt: !2008)
!2020 = !DILocation(line: 515, column: 10, scope: !713, inlinedAt: !2008)
!2021 = !DILocation(line: 523, column: 5, scope: !2022, inlinedAt: !2008)
!2022 = distinct !DILexicalBlock(scope: !2023, file: !3, line: 523, column: 5)
!2023 = distinct !DILexicalBlock(scope: !2024, file: !3, line: 522, column: 29)
!2024 = distinct !DILexicalBlock(scope: !2025, file: !3, line: 522, column: 3)
!2025 = distinct !DILexicalBlock(scope: !713, file: !3, line: 522, column: 3)
!2026 = !DILocation(line: 518, column: 15, scope: !2027, inlinedAt: !2008)
!2027 = distinct !DILexicalBlock(scope: !2016, file: !3, line: 517, column: 33)
!2028 = !DILocation(line: 518, column: 12, scope: !2027, inlinedAt: !2008)
!2029 = !DILocation(line: 518, column: 38, scope: !2027, inlinedAt: !2008)
!2030 = !DILocation(line: 518, column: 29, scope: !2027, inlinedAt: !2008)
!2031 = !DILocation(line: 518, column: 5, scope: !2027, inlinedAt: !2008)
!2032 = !DILocation(line: 518, column: 10, scope: !2027, inlinedAt: !2008)
!2033 = !DILocation(line: 517, column: 24, scope: !2016, inlinedAt: !2008)
!2034 = !DILocation(line: 517, column: 29, scope: !2016, inlinedAt: !2008)
!2035 = distinct !{!2035, !2018, !2036, !2006}
!2036 = !DILocation(line: 519, column: 3, scope: !2017, inlinedAt: !2008)
!2037 = !DILocation(line: 523, column: 29, scope: !2038, inlinedAt: !2008)
!2038 = distinct !DILexicalBlock(scope: !2022, file: !3, line: 523, column: 5)
!2039 = !DILocation(line: 523, column: 37, scope: !2038, inlinedAt: !2008)
!2040 = !DILocation(line: 523, column: 47, scope: !2038, inlinedAt: !2008)
!2041 = !DILocation(line: 523, column: 63, scope: !2038, inlinedAt: !2008)
!2042 = !DILocation(line: 523, column: 54, scope: !2038, inlinedAt: !2008)
!2043 = distinct !{!2043, !2021, !2044, !2006, !2045, !2046}
!2044 = !DILocation(line: 523, column: 66, scope: !2022, inlinedAt: !2008)
!2045 = !{!"llvm.loop.isvectorized", i32 1}
!2046 = !{!"llvm.loop.unroll.runtime.disable"}
!2047 = !DILocation(line: 523, column: 44, scope: !2038, inlinedAt: !2008)
!2048 = distinct !{!2048, !2021, !2044, !2006, !2045}
!2049 = !DILocation(line: 524, column: 10, scope: !2023, inlinedAt: !2008)
!2050 = distinct !{!2050, !2021, !2044, !2006, !2045, !2046}
!2051 = distinct !{!2051, !2021, !2044, !2006, !2045}
!2052 = !DILocation(line: 524, column: 5, scope: !2023, inlinedAt: !2008)
!2053 = distinct !{!2053, !2021, !2044, !2006, !2045, !2046}
!2054 = distinct !{!2054, !2021, !2044, !2006, !2045}
!2055 = distinct !{!2055, !2021, !2044, !2006, !2045, !2046}
!2056 = distinct !{!2056, !2021, !2044, !2006, !2045}
!2057 = distinct !{!2057, !2021, !2044, !2006, !2045, !2046}
!2058 = distinct !{!2058, !2021, !2044, !2006, !2045}
!2059 = !DILocation(line: 523, scope: !2022, inlinedAt: !2008)
!2060 = !DILocation(line: 530, column: 8, scope: !2061, inlinedAt: !2008)
!2061 = distinct !DILexicalBlock(scope: !713, file: !3, line: 530, column: 3)
!2062 = !DILocation(line: 530, column: 27, scope: !2061, inlinedAt: !2008)
!2063 = !DILocation(line: 592, column: 7, scope: !2064, inlinedAt: !2008)
!2064 = distinct !DILexicalBlock(scope: !2065, file: !3, line: 592, column: 7)
!2065 = distinct !DILexicalBlock(scope: !2066, file: !3, line: 587, column: 17)
!2066 = distinct !DILexicalBlock(scope: !2067, file: !3, line: 587, column: 9)
!2067 = distinct !DILexicalBlock(scope: !2068, file: !3, line: 584, column: 18)
!2068 = distinct !DILexicalBlock(scope: !713, file: !3, line: 584, column: 7)
!2069 = distinct !{!2069, !2063, !2070, !2006}
!2070 = !DILocation(line: 596, column: 7, scope: !2064, inlinedAt: !2008)
!2071 = !DILocation(line: 528, column: 1, scope: !713, inlinedAt: !2008)
!2072 = !DILocation(line: 530, column: 3, scope: !2061, inlinedAt: !2008)
!2073 = !DILocation(line: 531, column: 36, scope: !2074, inlinedAt: !2008)
!2074 = distinct !DILexicalBlock(scope: !2075, file: !3, line: 530, column: 51)
!2075 = distinct !DILexicalBlock(scope: !2061, file: !3, line: 530, column: 3)
!2076 = !DILocation(line: 531, column: 19, scope: !2074, inlinedAt: !2008)
!2077 = !DILocation(line: 531, column: 10, scope: !2074, inlinedAt: !2008)
!2078 = !DILocation(line: 532, column: 25, scope: !2074, inlinedAt: !2008)
!2079 = !DILocation(line: 532, column: 13, scope: !2074, inlinedAt: !2008)
!2080 = !DILocation(line: 532, column: 5, scope: !2074, inlinedAt: !2008)
!2081 = !DILocation(line: 532, column: 11, scope: !2074, inlinedAt: !2008)
!2082 = !DILocation(line: 533, column: 13, scope: !2074, inlinedAt: !2008)
!2083 = !DILocation(line: 533, column: 9, scope: !2074, inlinedAt: !2008)
!2084 = !DILocation(line: 533, column: 18, scope: !2074, inlinedAt: !2008)
!2085 = !DILocation(line: 530, column: 42, scope: !2075, inlinedAt: !2008)
!2086 = !DILocation(line: 530, column: 36, scope: !2075, inlinedAt: !2008)
!2087 = distinct !{!2087, !2072, !2088, !2006}
!2088 = !DILocation(line: 534, column: 3, scope: !2061, inlinedAt: !2008)
!2089 = !DILocation(line: 537, column: 7, scope: !713, inlinedAt: !2008)
!2090 = !DILocation(line: 538, column: 22, scope: !713, inlinedAt: !2008)
!2091 = !DILocation(line: 538, column: 14, scope: !713, inlinedAt: !2008)
!2092 = !DILocation(line: 538, column: 5, scope: !713, inlinedAt: !2008)
!2093 = !DILocation(line: 539, column: 7, scope: !713, inlinedAt: !2008)
!2094 = !DILocation(line: 540, column: 8, scope: !713, inlinedAt: !2008)
!2095 = !DILocation(line: 540, column: 5, scope: !713, inlinedAt: !2008)
!2096 = !DILocation(line: 542, column: 7, scope: !713, inlinedAt: !2008)
!2097 = !DILocation(line: 543, column: 16, scope: !2098, inlinedAt: !2008)
!2098 = distinct !DILexicalBlock(scope: !2099, file: !3, line: 542, column: 15)
!2099 = distinct !DILexicalBlock(scope: !713, file: !3, line: 542, column: 7)
!2100 = !DILocation(line: 543, column: 10, scope: !2098, inlinedAt: !2008)
!2101 = !DILocation(line: 543, column: 21, scope: !2098, inlinedAt: !2008)
!2102 = !DILocation(line: 544, column: 7, scope: !2098, inlinedAt: !2008)
!2103 = !DILocation(line: 545, column: 21, scope: !2098, inlinedAt: !2008)
!2104 = !DILocation(line: 545, column: 16, scope: !2098, inlinedAt: !2008)
!2105 = !DILocation(line: 546, column: 21, scope: !2098, inlinedAt: !2008)
!2106 = !DILocation(line: 547, column: 3, scope: !2098, inlinedAt: !2008)
!2107 = !DILocation(line: 547, column: 14, scope: !2099, inlinedAt: !2008)
!2108 = !DILocation(line: 548, column: 16, scope: !2109, inlinedAt: !2008)
!2109 = distinct !DILexicalBlock(scope: !2110, file: !3, line: 547, column: 23)
!2110 = distinct !DILexicalBlock(scope: !2099, file: !3, line: 547, column: 14)
!2111 = !DILocation(line: 548, column: 10, scope: !2109, inlinedAt: !2008)
!2112 = !DILocation(line: 548, column: 21, scope: !2109, inlinedAt: !2008)
!2113 = !DILocation(line: 549, column: 3, scope: !2109, inlinedAt: !2008)
!2114 = !DILocation(line: 549, column: 16, scope: !2115, inlinedAt: !2008)
!2115 = distinct !DILexicalBlock(scope: !2110, file: !3, line: 549, column: 14)
!2116 = !DILocation(line: 549, column: 14, scope: !2110, inlinedAt: !2008)
!2117 = !DILocation(line: 553, column: 10, scope: !2118, inlinedAt: !2008)
!2118 = distinct !DILexicalBlock(scope: !713, file: !3, line: 553, column: 7)
!2119 = !DILocation(line: 553, column: 7, scope: !713, inlinedAt: !2008)
!2120 = !DILocation(line: 556, column: 5, scope: !2121, inlinedAt: !2008)
!2121 = distinct !DILexicalBlock(scope: !2122, file: !3, line: 556, column: 5)
!2122 = distinct !DILexicalBlock(scope: !2118, file: !3, line: 553, column: 15)
!2123 = !DILocation(line: 557, column: 11, scope: !2124, inlinedAt: !2008)
!2124 = distinct !DILexicalBlock(scope: !2125, file: !3, line: 556, column: 30)
!2125 = distinct !DILexicalBlock(scope: !2121, file: !3, line: 556, column: 5)
!2126 = !DILocation(line: 558, column: 17, scope: !2127, inlinedAt: !2008)
!2127 = distinct !DILexicalBlock(scope: !2124, file: !3, line: 558, column: 11)
!2128 = !DILocation(line: 558, column: 11, scope: !2124, inlinedAt: !2008)
!2129 = !DILocation(line: 559, column: 15, scope: !2130, inlinedAt: !2008)
!2130 = distinct !DILexicalBlock(scope: !2131, file: !3, line: 559, column: 13)
!2131 = distinct !DILexicalBlock(scope: !2127, file: !3, line: 558, column: 23)
!2132 = !DILocation(line: 559, column: 13, scope: !2131, inlinedAt: !2008)
!2133 = !DILocation(line: 0, scope: !2127, inlinedAt: !2008)
!2134 = !DILocation(line: 556, column: 26, scope: !2125, inlinedAt: !2008)
!2135 = !DILocation(line: 0, scope: !2122, inlinedAt: !2008)
!2136 = !DILocation(line: 556, column: 19, scope: !2125, inlinedAt: !2008)
!2137 = distinct !{!2137, !2120, !2138, !2006}
!2138 = !DILocation(line: 566, column: 5, scope: !2121, inlinedAt: !2008)
!2139 = !DILocation(line: 554, column: 7, scope: !2122, inlinedAt: !2008)
!2140 = !DILocation(line: 567, column: 9, scope: !2122, inlinedAt: !2008)
!2141 = !DILocation(line: 568, column: 7, scope: !2142, inlinedAt: !2008)
!2142 = distinct !DILexicalBlock(scope: !2143, file: !3, line: 567, column: 17)
!2143 = distinct !DILexicalBlock(scope: !2122, file: !3, line: 567, column: 9)
!2144 = !DILocation(line: 574, column: 11, scope: !2145, inlinedAt: !2008)
!2145 = distinct !DILexicalBlock(scope: !2142, file: !3, line: 568, column: 19)
!2146 = !DILocation(line: 0, scope: !2145, inlinedAt: !2008)
!2147 = !DILocation(line: 577, column: 12, scope: !2148, inlinedAt: !2008)
!2148 = distinct !DILexicalBlock(scope: !2122, file: !3, line: 577, column: 9)
!2149 = !DILocation(line: 577, column: 9, scope: !2122, inlinedAt: !2008)
!2150 = !DILocation(line: 578, column: 15, scope: !2151, inlinedAt: !2008)
!2151 = distinct !DILexicalBlock(scope: !2148, file: !3, line: 577, column: 18)
!2152 = !DILocation(line: 579, column: 11, scope: !2151, inlinedAt: !2008)
!2153 = !DILocation(line: 579, column: 28, scope: !2154, inlinedAt: !2008)
!2154 = distinct !DILexicalBlock(scope: !2151, file: !3, line: 579, column: 11)
!2155 = !DILocation(line: 579, column: 25, scope: !2154, inlinedAt: !2008)
!2156 = !DILocation(line: 579, column: 23, scope: !2154, inlinedAt: !2008)
!2157 = !DILocation(line: 584, column: 9, scope: !2068, inlinedAt: !2008)
!2158 = !DILocation(line: 584, column: 7, scope: !713, inlinedAt: !2008)
!2159 = !DILocation(line: 586, column: 24, scope: !2160, inlinedAt: !2008)
!2160 = distinct !DILexicalBlock(scope: !2161, file: !3, line: 586, column: 5)
!2161 = distinct !DILexicalBlock(scope: !2067, file: !3, line: 586, column: 5)
!2162 = !DILocation(line: 586, column: 5, scope: !2161, inlinedAt: !2008)
!2163 = !DILocation(line: 586, scope: !2161, inlinedAt: !2008)
!2164 = !DILocation(line: 586, column: 41, scope: !2160, inlinedAt: !2008)
!2165 = !DILocation(line: 586, column: 38, scope: !2160, inlinedAt: !2008)
!2166 = distinct !{!2166, !2162, !2167, !2006, !2045, !2046}
!2167 = !DILocation(line: 586, column: 45, scope: !2161, inlinedAt: !2008)
!2168 = distinct !{!2168, !2162, !2167, !2006, !2046, !2045}
!2169 = !DILocation(line: 587, column: 11, scope: !2066, inlinedAt: !2008)
!2170 = !DILocation(line: 587, column: 9, scope: !2067, inlinedAt: !2008)
!2171 = !DILocation(line: 588, column: 30, scope: !2172, inlinedAt: !2008)
!2172 = distinct !DILexicalBlock(scope: !2173, file: !3, line: 588, column: 7)
!2173 = distinct !DILexicalBlock(scope: !2065, file: !3, line: 588, column: 7)
!2174 = !DILocation(line: 588, column: 41, scope: !2172, inlinedAt: !2008)
!2175 = !DILocation(line: 588, column: 7, scope: !2173, inlinedAt: !2008)
!2176 = !DILocation(line: 588, scope: !2173, inlinedAt: !2008)
!2177 = !DILocation(line: 592, column: 26, scope: !2178, inlinedAt: !2008)
!2178 = distinct !DILexicalBlock(scope: !2064, file: !3, line: 592, column: 7)
!2179 = !DILocation(line: 592, scope: !2064, inlinedAt: !2008)
!2180 = !DILocation(line: 593, column: 21, scope: !2181, inlinedAt: !2008)
!2181 = distinct !DILexicalBlock(scope: !2178, file: !3, line: 592, column: 42)
!2182 = !DILocation(line: 593, column: 14, scope: !2181, inlinedAt: !2008)
!2183 = !DILocation(line: 593, column: 9, scope: !2181, inlinedAt: !2008)
!2184 = !DILocation(line: 593, column: 19, scope: !2181, inlinedAt: !2008)
!2185 = !DILocation(line: 594, column: 9, scope: !2186, inlinedAt: !2008)
!2186 = distinct !DILexicalBlock(scope: !2181, file: !3, line: 594, column: 9)
!2187 = !DILocation(line: 594, column: 41, scope: !2188, inlinedAt: !2008)
!2188 = distinct !DILexicalBlock(scope: !2186, file: !3, line: 594, column: 9)
!2189 = !DILocation(line: 594, column: 51, scope: !2188, inlinedAt: !2008)
!2190 = !DILocation(line: 594, column: 67, scope: !2188, inlinedAt: !2008)
!2191 = !DILocation(line: 594, column: 58, scope: !2188, inlinedAt: !2008)
!2192 = distinct !{!2192, !2185, !2193, !2006, !2045, !2046}
!2193 = !DILocation(line: 594, column: 70, scope: !2186, inlinedAt: !2008)
!2194 = !DILocation(line: 594, column: 48, scope: !2188, inlinedAt: !2008)
!2195 = !DILocation(line: 594, column: 33, scope: !2188, inlinedAt: !2008)
!2196 = distinct !{!2196, !2185, !2193, !2006, !2046, !2045}
!2197 = !DILocation(line: 594, scope: !2186, inlinedAt: !2008)
!2198 = !DILocation(line: 595, column: 9, scope: !2181, inlinedAt: !2008)
!2199 = !DILocation(line: 595, column: 14, scope: !2181, inlinedAt: !2008)
!2200 = distinct !{!2200, !2063, !2070, !2006}
!2201 = !DILocation(line: 0, scope: !2202, inlinedAt: !2008)
!2202 = distinct !DILexicalBlock(scope: !2203, file: !3, line: 603, column: 17)
!2203 = distinct !DILexicalBlock(scope: !713, file: !3, line: 603, column: 7)
!2204 = !DILocation(line: 606, column: 12, scope: !2202, inlinedAt: !2008)
!2205 = !DILocation(line: 606, column: 19, scope: !2202, inlinedAt: !2008)
!2206 = !DILocation(line: 606, column: 5, scope: !2202, inlinedAt: !2008)
!2207 = distinct !{!2207, !2206, !2208, !2006}
!2208 = !DILocation(line: 609, column: 5, scope: !2202, inlinedAt: !2008)
!2209 = !DILocation(line: 611, column: 19, scope: !2210, inlinedAt: !2008)
!2210 = distinct !DILexicalBlock(scope: !2203, file: !3, line: 610, column: 10)
!2211 = !DILocation(line: 611, column: 9, scope: !2210, inlinedAt: !2008)
!2212 = !DILocation(line: 612, column: 11, scope: !2213, inlinedAt: !2008)
!2213 = distinct !DILexicalBlock(scope: !2210, file: !3, line: 612, column: 9)
!2214 = !DILocation(line: 612, column: 9, scope: !2210, inlinedAt: !2008)
!2215 = !DILocation(line: 613, column: 38, scope: !2216, inlinedAt: !2008)
!2216 = distinct !DILexicalBlock(scope: !2213, file: !3, line: 612, column: 21)
!2217 = !DILocation(line: 613, column: 21, scope: !2216, inlinedAt: !2008)
!2218 = !DILocation(line: 613, column: 12, scope: !2216, inlinedAt: !2008)
!2219 = !DILocation(line: 614, column: 18, scope: !2216, inlinedAt: !2008)
!2220 = !DILocation(line: 614, column: 16, scope: !2216, inlinedAt: !2008)
!2221 = !DILocation(line: 614, column: 7, scope: !2216, inlinedAt: !2008)
!2222 = !DILocation(line: 614, column: 14, scope: !2216, inlinedAt: !2008)
!2223 = !DILocation(line: 615, column: 10, scope: !2216, inlinedAt: !2008)
!2224 = !DILocation(line: 617, column: 7, scope: !2216, inlinedAt: !2008)
!2225 = !DILocation(line: 617, column: 14, scope: !2216, inlinedAt: !2008)
!2226 = !DILocation(line: 618, column: 5, scope: !2216, inlinedAt: !2008)
!2227 = !DILocation(line: 619, column: 16, scope: !2228, inlinedAt: !2008)
!2228 = distinct !DILexicalBlock(scope: !2213, file: !3, line: 618, column: 12)
!2229 = !DILocation(line: 619, column: 7, scope: !2228, inlinedAt: !2008)
!2230 = !DILocation(line: 619, column: 14, scope: !2228, inlinedAt: !2008)
!2231 = !DILocation(line: 624, column: 8, scope: !713, inlinedAt: !2008)
!2232 = !DILocation(line: 625, column: 18, scope: !2233, inlinedAt: !2008)
!2233 = distinct !DILexicalBlock(scope: !2234, file: !3, line: 625, column: 3)
!2234 = distinct !DILexicalBlock(scope: !713, file: !3, line: 625, column: 3)
!2235 = !DILocation(line: 625, column: 3, scope: !2234, inlinedAt: !2008)
!2236 = !DILocation(line: 647, column: 18, scope: !2237, inlinedAt: !2008)
!2237 = distinct !DILexicalBlock(scope: !713, file: !3, line: 637, column: 17)
!2238 = !DILocation(line: 647, column: 14, scope: !2237, inlinedAt: !2008)
!2239 = !DILocation(line: 647, column: 12, scope: !2237, inlinedAt: !2008)
!2240 = !DILocation(line: 649, column: 7, scope: !2241, inlinedAt: !2008)
!2241 = distinct !DILexicalBlock(scope: !2237, file: !3, line: 649, column: 7)
!2242 = !DILocation(line: 626, column: 17, scope: !2243, inlinedAt: !2008)
!2243 = distinct !DILexicalBlock(scope: !2233, file: !3, line: 625, column: 29)
!2244 = !DILocation(line: 626, column: 15, scope: !2243, inlinedAt: !2008)
!2245 = !DILocation(line: 626, column: 5, scope: !2243, inlinedAt: !2008)
!2246 = !DILocation(line: 626, column: 10, scope: !2243, inlinedAt: !2008)
!2247 = !DILocation(line: 627, column: 8, scope: !2243, inlinedAt: !2008)
!2248 = !DILocation(line: 625, column: 25, scope: !2233, inlinedAt: !2008)
!2249 = distinct !{!2249, !2235, !2250, !2006}
!2250 = !DILocation(line: 628, column: 3, scope: !2234, inlinedAt: !2008)
!2251 = !DILocation(line: 632, column: 72, scope: !2252, inlinedAt: !2008)
!2252 = distinct !DILexicalBlock(scope: !2253, file: !3, line: 632, column: 5)
!2253 = distinct !DILexicalBlock(scope: !2254, file: !3, line: 632, column: 5)
!2254 = distinct !DILexicalBlock(scope: !2255, file: !3, line: 631, column: 29)
!2255 = distinct !DILexicalBlock(scope: !2256, file: !3, line: 631, column: 3)
!2256 = distinct !DILexicalBlock(scope: !713, file: !3, line: 631, column: 3)
!2257 = !DILocation(line: 632, column: 59, scope: !2252, inlinedAt: !2008)
!2258 = !DILocation(line: 632, column: 35, scope: !2252, inlinedAt: !2008)
!2259 = distinct !{!2259, !2260, !2261, !2006}
!2260 = !DILocation(line: 632, column: 5, scope: !2253, inlinedAt: !2008)
!2261 = !DILocation(line: 632, column: 79, scope: !2253, inlinedAt: !2008)
!2262 = !DILocation(line: 632, column: 76, scope: !2252, inlinedAt: !2008)
!2263 = !DILocation(line: 633, column: 5, scope: !2254, inlinedAt: !2008)
!2264 = !DILocation(line: 633, column: 16, scope: !2254, inlinedAt: !2008)
!2265 = !DILocation(line: 631, column: 25, scope: !2255, inlinedAt: !2008)
!2266 = !DILocation(line: 631, column: 3, scope: !2256, inlinedAt: !2008)
!2267 = !DILocation(line: 631, column: 18, scope: !2255, inlinedAt: !2008)
!2268 = distinct !{!2268, !2266, !2269, !2006}
!2269 = !DILocation(line: 634, column: 3, scope: !2256, inlinedAt: !2008)
!2270 = !DILocation(line: 646, column: 7, scope: !2271, inlinedAt: !2008)
!2271 = distinct !DILexicalBlock(scope: !2237, file: !3, line: 646, column: 7)
!2272 = !DILocation(line: 646, column: 39, scope: !2273, inlinedAt: !2008)
!2273 = distinct !DILexicalBlock(scope: !2271, file: !3, line: 646, column: 7)
!2274 = distinct !{!2274, !2270, !2275, !2006, !2045, !2046}
!2275 = !DILocation(line: 646, column: 43, scope: !2271, inlinedAt: !2008)
!2276 = !DILocation(line: 646, column: 36, scope: !2273, inlinedAt: !2008)
!2277 = !DILocation(line: 646, column: 29, scope: !2273, inlinedAt: !2008)
!2278 = !DILocation(line: 646, column: 22, scope: !2273, inlinedAt: !2008)
!2279 = distinct !{!2279, !2270, !2275, !2006, !2045}
!2280 = !DILocation(line: 648, column: 12, scope: !2237, inlinedAt: !2008)
!2281 = !DILocation(line: 648, column: 18, scope: !2237, inlinedAt: !2008)
!2282 = !DILocation(line: 649, column: 21, scope: !2283, inlinedAt: !2008)
!2283 = distinct !DILexicalBlock(scope: !2241, file: !3, line: 649, column: 7)
!2284 = !DILocation(line: 649, column: 39, scope: !2283, inlinedAt: !2008)
!2285 = distinct !{!2285, !2240, !2286, !2006, !2045, !2046}
!2286 = !DILocation(line: 649, column: 43, scope: !2241, inlinedAt: !2008)
!2287 = !DILocation(line: 649, column: 36, scope: !2283, inlinedAt: !2008)
!2288 = !DILocation(line: 649, column: 29, scope: !2283, inlinedAt: !2008)
!2289 = distinct !{!2289, !2240, !2286, !2006, !2046, !2045}
!2290 = !DILocation(line: 0, scope: !2237, inlinedAt: !2008)
!2291 = !DILocation(line: 650, column: 14, scope: !2237, inlinedAt: !2008)
!2292 = !DILocation(line: 650, column: 7, scope: !2237, inlinedAt: !2008)
!2293 = !DILocation(line: 650, column: 12, scope: !2237, inlinedAt: !2008)
!2294 = !DILocation(line: 674, column: 12, scope: !713, inlinedAt: !2008)
!2295 = !DILocation(line: 675, column: 1, scope: !713, inlinedAt: !2008)
!2296 = !DILocation(line: 295, column: 10, scope: !2297)
!2297 = distinct !DILexicalBlock(scope: !639, file: !3, line: 295, column: 7)
!2298 = !DILocation(line: 295, column: 7, scope: !639)
!2299 = !DILocation(line: 296, column: 12, scope: !2300)
!2300 = distinct !DILexicalBlock(scope: !2297, file: !3, line: 295, column: 15)
!2301 = !DILocation(line: 296, column: 10, scope: !2300)
!2302 = !DILocation(line: 297, column: 12, scope: !2300)
!2303 = !DILocation(line: 297, column: 10, scope: !2300)
!2304 = !DILocation(line: 298, column: 12, scope: !2300)
!2305 = !DILocation(line: 298, column: 5, scope: !2300)
!2306 = !DILocation(line: 301, column: 1, scope: !639)
!2307 = !DILocation(line: 0, scope: !201)
!2308 = !DILocation(line: 0, scope: !875, inlinedAt: !2309)
!2309 = distinct !DILocation(line: 1501, column: 3, scope: !214)
!2310 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2309)
!2311 = !DILocation(line: 0, scope: !214)
!2312 = !DILocation(line: 1501, column: 3, scope: !214)
!2313 = !DILocation(line: 1502, column: 13, scope: !201)
!2314 = !DILocation(line: 1503, column: 6, scope: !201)
!2315 = !DILocation(line: 1506, column: 10, scope: !219)
!2316 = !DILocation(line: 1506, column: 7, scope: !201)
!2317 = !DILocation(line: 1507, column: 12, scope: !217)
!2318 = !DILocation(line: 1507, column: 9, scope: !218)
!2319 = !DILocation(line: 0, scope: !875, inlinedAt: !2320)
!2320 = distinct !DILocation(line: 1509, column: 7, scope: !221)
!2321 = !DILocation(line: 0, scope: !221)
!2322 = !DILocation(line: 1509, column: 7, scope: !221)
!2323 = !DILocation(line: 0, scope: !216)
!2324 = !DILocation(line: 1510, column: 16, scope: !2325)
!2325 = distinct !DILexicalBlock(scope: !216, file: !3, line: 1510, column: 11)
!2326 = !DILocation(line: 1510, column: 27, scope: !2325)
!2327 = !DILocation(line: 1510, column: 33, scope: !2325)
!2328 = !DILocation(line: 1510, column: 11, scope: !216)
!2329 = !DILocation(line: 1515, column: 11, scope: !2330)
!2330 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1515, column: 9)
!2331 = !DILocation(line: 1515, column: 9, scope: !218)
!2332 = !DILocation(line: 1515, column: 33, scope: !2330)
!2333 = !DILocation(line: 1515, column: 40, scope: !2330)
!2334 = !DILocation(line: 1515, column: 38, scope: !2330)
!2335 = !DILocation(line: 1515, column: 26, scope: !2330)
!2336 = !DILocation(line: 1516, column: 11, scope: !2337)
!2337 = distinct !DILexicalBlock(scope: !218, file: !3, line: 1516, column: 9)
!2338 = !DILocation(line: 1516, column: 9, scope: !218)
!2339 = !DILocation(line: 1516, column: 33, scope: !2337)
!2340 = !DILocation(line: 1516, column: 44, scope: !2337)
!2341 = !DILocation(line: 1516, column: 42, scope: !2337)
!2342 = !DILocation(line: 1516, column: 26, scope: !2337)
!2343 = !DILocation(line: 1520, column: 10, scope: !2344)
!2344 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1520, column: 7)
!2345 = !DILocation(line: 1520, column: 7, scope: !201)
!2346 = !DILocation(line: 1521, column: 12, scope: !2347)
!2347 = distinct !DILexicalBlock(scope: !2348, file: !3, line: 1521, column: 9)
!2348 = distinct !DILexicalBlock(scope: !2344, file: !3, line: 1520, column: 24)
!2349 = !DILocation(line: 1521, column: 9, scope: !2348)
!2350 = !DILocation(line: 1526, column: 13, scope: !2351)
!2351 = distinct !DILexicalBlock(scope: !2352, file: !3, line: 1526, column: 11)
!2352 = distinct !DILexicalBlock(scope: !2347, file: !3, line: 1521, column: 26)
!2353 = !DILocation(line: 1526, column: 11, scope: !2352)
!2354 = !DILocation(line: 1527, column: 16, scope: !2352)
!2355 = !DILocation(line: 1527, column: 14, scope: !2352)
!2356 = !DILocation(line: 1528, column: 12, scope: !2352)
!2357 = !DILocation(line: 1529, column: 13, scope: !2352)
!2358 = !DILocation(line: 1529, column: 19, scope: !2352)
!2359 = !DILocation(line: 1536, column: 12, scope: !2348)
!2360 = !DILocation(line: 1544, column: 9, scope: !201)
!2361 = !DILocation(line: 1545, column: 7, scope: !201)
!2362 = !DILocation(line: 1537, column: 17, scope: !2363)
!2363 = distinct !DILexicalBlock(scope: !2344, file: !3, line: 1537, column: 14)
!2364 = !DILocation(line: 1537, column: 14, scope: !2344)
!2365 = !DILocation(line: 1538, column: 9, scope: !2366)
!2366 = distinct !DILexicalBlock(scope: !2367, file: !3, line: 1538, column: 9)
!2367 = distinct !DILexicalBlock(scope: !2363, file: !3, line: 1537, column: 31)
!2368 = !DILocation(line: 1538, column: 14, scope: !2366)
!2369 = !DILocation(line: 1538, column: 18, scope: !2366)
!2370 = !DILocation(line: 1538, column: 9, scope: !2367)
!2371 = !DILocation(line: 1538, column: 36, scope: !2366)
!2372 = !DILocation(line: 1538, column: 25, scope: !2366)
!2373 = !DILocation(line: 1531, column: 30, scope: !2374)
!2374 = distinct !DILexicalBlock(scope: !2347, file: !3, line: 1530, column: 12)
!2375 = !DILocation(line: 1531, column: 28, scope: !2374)
!2376 = !DILocation(line: 1531, column: 11, scope: !2374)
!2377 = !DILocation(line: 1532, column: 11, scope: !2374)
!2378 = !DILocation(line: 1533, column: 14, scope: !2374)
!2379 = !DILocation(line: 1534, column: 14, scope: !2374)
!2380 = !DILocation(line: 1545, column: 9, scope: !225)
!2381 = !DILocation(line: 0, scope: !225)
!2382 = !DILocation(line: 1553, column: 49, scope: !201)
!2383 = !DILocation(line: 1553, column: 39, scope: !201)
!2384 = !DILocation(line: 1553, column: 29, scope: !201)
!2385 = !DILocation(line: 1553, column: 19, scope: !201)
!2386 = !DILocation(line: 1553, column: 9, scope: !201)
!2387 = !DILocation(line: 1554, column: 9, scope: !2388)
!2388 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1554, column: 7)
!2389 = !DILocation(line: 0, scope: !2388)
!2390 = !DILocation(line: 1554, column: 7, scope: !201)
!2391 = !DILocation(line: 1555, column: 32, scope: !2392)
!2392 = distinct !DILexicalBlock(scope: !2388, file: !3, line: 1554, column: 15)
!2393 = !DILocation(line: 1555, column: 27, scope: !2392)
!2394 = !DILocation(line: 1555, column: 16, scope: !2392)
!2395 = !DILocation(line: 1555, column: 5, scope: !2392)
!2396 = !DILocation(line: 1557, column: 37, scope: !2397)
!2397 = distinct !DILexicalBlock(scope: !2388, file: !3, line: 1556, column: 10)
!2398 = !DILocation(line: 1557, column: 30, scope: !2397)
!2399 = !DILocation(line: 1557, column: 20, scope: !2397)
!2400 = !DILocation(line: 1557, column: 13, scope: !2397)
!2401 = !DILocation(line: 1559, column: 7, scope: !201)
!2402 = !DILocation(line: 1560, column: 11, scope: !2403)
!2403 = distinct !DILexicalBlock(scope: !2404, file: !3, line: 1560, column: 9)
!2404 = distinct !DILexicalBlock(scope: !2405, file: !3, line: 1559, column: 19)
!2405 = distinct !DILexicalBlock(scope: !201, file: !3, line: 1559, column: 7)
!2406 = !DILocation(line: 1560, column: 9, scope: !2404)
!2407 = !DILocation(line: 1560, column: 29, scope: !2403)
!2408 = !DILocation(line: 1560, column: 37, scope: !2403)
!2409 = !DILocation(line: 1560, column: 35, scope: !2403)
!2410 = !DILocation(line: 1560, column: 20, scope: !2403)
!2411 = !DILocation(line: 1561, column: 14, scope: !2404)
!2412 = !DILocation(line: 1561, column: 5, scope: !2404)
!2413 = !DILocation(line: 1563, column: 14, scope: !2414)
!2414 = distinct !DILexicalBlock(scope: !2405, file: !3, line: 1562, column: 10)
!2415 = !DILocation(line: 1563, column: 24, scope: !2414)
!2416 = !DILocation(line: 1563, column: 22, scope: !2414)
!2417 = !DILocation(line: 1563, column: 5, scope: !2414)
!2418 = !DILocation(line: 1565, column: 1, scope: !201)
!2419 = !DILocation(line: 0, scope: !264)
!2420 = !DILocation(line: 0, scope: !875, inlinedAt: !2421)
!2421 = distinct !DILocation(line: 1591, column: 3, scope: !272)
!2422 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2421)
!2423 = !DILocation(line: 0, scope: !272)
!2424 = !DILocation(line: 1591, column: 3, scope: !272)
!2425 = !DILocation(line: 1592, column: 11, scope: !264)
!2426 = !DILocation(line: 1593, column: 48, scope: !2427)
!2427 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1593, column: 7)
!2428 = !DILocation(line: 1593, column: 11, scope: !2427)
!2429 = !DILocation(line: 1593, column: 56, scope: !2427)
!2430 = !DILocation(line: 1593, column: 7, scope: !264)
!2431 = !DILocation(line: 1597, column: 10, scope: !2432)
!2432 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1597, column: 7)
!2433 = !DILocation(line: 1597, column: 7, scope: !264)
!2434 = !DILocation(line: 1598, column: 14, scope: !2435)
!2435 = distinct !DILexicalBlock(scope: !2432, file: !3, line: 1597, column: 25)
!2436 = !DILocation(line: 1598, column: 12, scope: !2435)
!2437 = !DILocation(line: 1598, column: 5, scope: !2435)
!2438 = !DILocation(line: 1601, column: 10, scope: !2439)
!2439 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1601, column: 7)
!2440 = !DILocation(line: 1601, column: 23, scope: !2439)
!2441 = !DILocation(line: 0, scope: !875, inlinedAt: !2442)
!2442 = distinct !DILocation(line: 1602, column: 3, scope: !274)
!2443 = !DILocation(line: 0, scope: !274)
!2444 = !DILocation(line: 1602, column: 3, scope: !274)
!2445 = !DILocation(line: 1603, column: 10, scope: !2446)
!2446 = distinct !DILexicalBlock(scope: !264, file: !3, line: 1603, column: 7)
!2447 = !DILocation(line: 0, scope: !2446)
!2448 = !DILocation(line: 1603, column: 7, scope: !264)
!2449 = !DILocation(line: 1605, column: 39, scope: !2450)
!2450 = distinct !DILexicalBlock(scope: !2446, file: !3, line: 1603, column: 24)
!2451 = !DILocation(line: 1605, column: 50, scope: !2450)
!2452 = !DILocation(line: 1605, column: 43, scope: !2450)
!2453 = !DILocation(line: 1605, column: 35, scope: !2450)
!2454 = !DILocation(line: 1606, column: 3, scope: !2450)
!2455 = !DILocation(line: 1607, column: 48, scope: !2456)
!2456 = distinct !DILexicalBlock(scope: !2446, file: !3, line: 1606, column: 10)
!2457 = !DILocation(line: 1607, column: 41, scope: !2456)
!2458 = !DILocation(line: 1609, column: 7, scope: !264)
!2459 = !DILocation(line: 1613, column: 1, scope: !264)
!2460 = !DILocation(line: 0, scope: !382)
!2461 = !DILocation(line: 0, scope: !875, inlinedAt: !2462)
!2462 = distinct !DILocation(line: 2010, column: 3, scope: !399)
!2463 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2462)
!2464 = !DILocation(line: 0, scope: !399)
!2465 = !DILocation(line: 2010, column: 3, scope: !399)
!2466 = !DILocation(line: 2013, column: 10, scope: !403)
!2467 = !DILocation(line: 2013, column: 7, scope: !382)
!2468 = !DILocation(line: 2014, column: 14, scope: !2469)
!2469 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2014, column: 9)
!2470 = !DILocation(line: 2014, column: 28, scope: !2469)
!2471 = !DILocation(line: 2014, column: 34, scope: !2469)
!2472 = !DILocation(line: 2014, column: 9, scope: !402)
!2473 = !DILocation(line: 2017, column: 12, scope: !2474)
!2474 = distinct !DILexicalBlock(scope: !402, file: !3, line: 2017, column: 9)
!2475 = !DILocation(line: 2017, column: 9, scope: !402)
!2476 = !DILocation(line: 2021, column: 7, scope: !402)
!2477 = !DILocation(line: 0, scope: !875, inlinedAt: !2478)
!2478 = distinct !DILocation(line: 2022, column: 5, scope: !401)
!2479 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2478)
!2480 = !DILocation(line: 0, scope: !401)
!2481 = !DILocation(line: 2022, column: 5, scope: !401)
!2482 = !DILocation(line: 2023, column: 3, scope: !402)
!2483 = !DILocation(line: 2024, column: 10, scope: !2484)
!2484 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2024, column: 7)
!2485 = !DILocation(line: 2024, column: 7, scope: !382)
!2486 = !DILocation(line: 2024, column: 34, scope: !2484)
!2487 = !DILocation(line: 2024, column: 25, scope: !2484)
!2488 = !DILocation(line: 2025, column: 10, scope: !2489)
!2489 = distinct !DILexicalBlock(scope: !382, file: !3, line: 2025, column: 7)
!2490 = !DILocation(line: 2025, column: 24, scope: !2489)
!2491 = !DILocation(line: 2026, column: 12, scope: !382)
!2492 = !DILocation(line: 2026, column: 19, scope: !382)
!2493 = !DILocation(line: 2026, column: 5, scope: !382)
!2494 = !DILocation(line: 2027, column: 6, scope: !382)
!2495 = !DILocation(line: 2028, column: 11, scope: !382)
!2496 = !DILocation(line: 2028, column: 22, scope: !382)
!2497 = !DILocation(line: 0, scope: !875, inlinedAt: !2498)
!2498 = distinct !DILocation(line: 2029, column: 3, scope: !405)
!2499 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2498)
!2500 = !DILocation(line: 0, scope: !405)
!2501 = !DILocation(line: 2029, column: 3, scope: !405)
!2502 = !DILocation(line: 0, scope: !949, inlinedAt: !2503)
!2503 = distinct !DILocation(line: 2029, column: 3, scope: !405)
!2504 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2503)
!2505 = !DILocation(line: 2030, column: 5, scope: !382)
!2506 = !DILocation(line: 2031, column: 7, scope: !382)
!2507 = !DILocation(line: 2032, column: 9, scope: !382)
!2508 = !DILocation(line: 2033, column: 14, scope: !382)
!2509 = !DILocation(line: 2033, column: 18, scope: !382)
!2510 = !DILocalVariable(name: "f", arg: 1, scope: !2511, file: !3, line: 1978, type: !6)
!2511 = distinct !DISubprogram(name: "k_log1p", scope: !3, file: !3, line: 1978, type: !4, scopeLine: 1978, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2512)
!2512 = !{!2510, !2513, !2514, !2515, !2516, !2517, !2518, !2519}
!2513 = !DILocalVariable(name: "hfsq", scope: !2511, file: !3, line: 1979, type: !6)
!2514 = !DILocalVariable(name: "s", scope: !2511, file: !3, line: 1979, type: !6)
!2515 = !DILocalVariable(name: "z", scope: !2511, file: !3, line: 1979, type: !6)
!2516 = !DILocalVariable(name: "R", scope: !2511, file: !3, line: 1979, type: !6)
!2517 = !DILocalVariable(name: "w", scope: !2511, file: !3, line: 1979, type: !6)
!2518 = !DILocalVariable(name: "t1", scope: !2511, file: !3, line: 1979, type: !6)
!2519 = !DILocalVariable(name: "t2", scope: !2511, file: !3, line: 1979, type: !6)
!2520 = !DILocation(line: 0, scope: !2511, inlinedAt: !2521)
!2521 = distinct !DILocation(line: 2034, column: 7, scope: !382)
!2522 = !DILocation(line: 1981, column: 16, scope: !2511, inlinedAt: !2521)
!2523 = !DILocation(line: 1981, column: 9, scope: !2511, inlinedAt: !2521)
!2524 = !DILocation(line: 1982, column: 9, scope: !2511, inlinedAt: !2521)
!2525 = !DILocation(line: 1983, column: 9, scope: !2511, inlinedAt: !2521)
!2526 = !DILocation(line: 1984, column: 28, scope: !2511, inlinedAt: !2521)
!2527 = !DILocation(line: 1984, column: 17, scope: !2511, inlinedAt: !2521)
!2528 = !DILocation(line: 1984, column: 10, scope: !2511, inlinedAt: !2521)
!2529 = !DILocation(line: 1985, column: 39, scope: !2511, inlinedAt: !2521)
!2530 = !DILocation(line: 1985, column: 28, scope: !2511, inlinedAt: !2521)
!2531 = !DILocation(line: 1985, column: 17, scope: !2511, inlinedAt: !2521)
!2532 = !DILocation(line: 1985, column: 10, scope: !2511, inlinedAt: !2521)
!2533 = !DILocation(line: 1986, column: 10, scope: !2511, inlinedAt: !2521)
!2534 = !DILocation(line: 1988, column: 20, scope: !2511, inlinedAt: !2521)
!2535 = !DILocation(line: 1988, column: 12, scope: !2511, inlinedAt: !2521)
!2536 = !DILocation(line: 2066, column: 10, scope: !382)
!2537 = !DILocation(line: 0, scope: !875, inlinedAt: !2538)
!2538 = distinct !DILocation(line: 2067, column: 3, scope: !407)
!2539 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2538)
!2540 = !DILocation(line: 0, scope: !407)
!2541 = !DILocation(line: 2067, column: 3, scope: !407)
!2542 = !DILocation(line: 0, scope: !949, inlinedAt: !2543)
!2543 = distinct !DILocation(line: 2067, column: 3, scope: !407)
!2544 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2543)
!2545 = !DILocation(line: 2068, column: 11, scope: !382)
!2546 = !DILocation(line: 2068, column: 17, scope: !382)
!2547 = !DILocation(line: 2068, column: 24, scope: !382)
!2548 = !DILocation(line: 2069, column: 15, scope: !382)
!2549 = !DILocation(line: 2070, column: 16, scope: !382)
!2550 = !DILocation(line: 2070, column: 37, scope: !382)
!2551 = !DILocation(line: 2070, column: 32, scope: !382)
!2552 = !DILocation(line: 2073, column: 9, scope: !382)
!2553 = !DILocation(line: 2074, column: 16, scope: !382)
!2554 = !DILocation(line: 2074, column: 21, scope: !382)
!2555 = !DILocation(line: 2074, column: 10, scope: !382)
!2556 = !DILocation(line: 2077, column: 17, scope: !382)
!2557 = !DILocation(line: 2077, column: 3, scope: !382)
!2558 = !DILocation(line: 2078, column: 1, scope: !382)
!2559 = !DILocation(line: 0, scope: !414)
!2560 = !DILocation(line: 0, scope: !875, inlinedAt: !2561)
!2561 = distinct !DILocation(line: 2117, column: 3, scope: !423)
!2562 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2561)
!2563 = !DILocation(line: 0, scope: !423)
!2564 = !DILocation(line: 2117, column: 3, scope: !423)
!2565 = !DILocation(line: 2120, column: 10, scope: !427)
!2566 = !DILocation(line: 2120, column: 7, scope: !414)
!2567 = !DILocation(line: 2121, column: 14, scope: !2568)
!2568 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2121, column: 9)
!2569 = !DILocation(line: 2121, column: 28, scope: !2568)
!2570 = !DILocation(line: 2121, column: 34, scope: !2568)
!2571 = !DILocation(line: 2121, column: 9, scope: !426)
!2572 = !DILocation(line: 2124, column: 12, scope: !2573)
!2573 = distinct !DILexicalBlock(scope: !426, file: !3, line: 2124, column: 9)
!2574 = !DILocation(line: 2124, column: 9, scope: !426)
!2575 = !DILocation(line: 2128, column: 7, scope: !426)
!2576 = !DILocation(line: 0, scope: !875, inlinedAt: !2577)
!2577 = distinct !DILocation(line: 2129, column: 5, scope: !425)
!2578 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2577)
!2579 = !DILocation(line: 0, scope: !425)
!2580 = !DILocation(line: 2129, column: 5, scope: !425)
!2581 = !DILocation(line: 0, scope: !875, inlinedAt: !2582)
!2582 = distinct !DILocation(line: 2130, column: 5, scope: !429)
!2583 = !DILocation(line: 0, scope: !429)
!2584 = !DILocation(line: 2130, column: 5, scope: !429)
!2585 = !DILocation(line: 2131, column: 3, scope: !426)
!2586 = !DILocation(line: 2132, column: 10, scope: !2587)
!2587 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2132, column: 7)
!2588 = !DILocation(line: 2132, column: 7, scope: !414)
!2589 = !DILocation(line: 2132, column: 34, scope: !2587)
!2590 = !DILocation(line: 2132, column: 25, scope: !2587)
!2591 = !DILocation(line: 2133, column: 10, scope: !2592)
!2592 = distinct !DILexicalBlock(scope: !414, file: !3, line: 2133, column: 7)
!2593 = !DILocation(line: 2133, column: 24, scope: !2592)
!2594 = !DILocation(line: 2134, column: 12, scope: !414)
!2595 = !DILocation(line: 2134, column: 19, scope: !414)
!2596 = !DILocation(line: 2134, column: 5, scope: !414)
!2597 = !DILocation(line: 2136, column: 24, scope: !414)
!2598 = !DILocation(line: 2137, column: 12, scope: !414)
!2599 = !DILocation(line: 2137, column: 41, scope: !414)
!2600 = !DILocation(line: 2137, column: 26, scope: !414)
!2601 = !DILocation(line: 2138, column: 9, scope: !414)
!2602 = !DILocation(line: 2138, column: 7, scope: !414)
!2603 = !DILocation(line: 0, scope: !875, inlinedAt: !2604)
!2604 = distinct !DILocation(line: 2139, column: 3, scope: !431)
!2605 = !DILocation(line: 0, scope: !431)
!2606 = !DILocation(line: 2139, column: 3, scope: !431)
!2607 = !DILocation(line: 0, scope: !949, inlinedAt: !2608)
!2608 = distinct !DILocation(line: 2139, column: 3, scope: !431)
!2609 = !DILocation(line: 0, scope: !875, inlinedAt: !2610)
!2610 = distinct !DILocation(line: 2140, column: 3, scope: !433)
!2611 = !DILocation(line: 0, scope: !433)
!2612 = !DILocation(line: 2140, column: 3, scope: !433)
!2613 = !DILocation(line: 0, scope: !949, inlinedAt: !2614)
!2614 = distinct !DILocation(line: 2140, column: 3, scope: !433)
!2615 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2614)
!2616 = !DILocation(line: 2142, column: 39, scope: !414)
!2617 = !DILocation(line: 2142, column: 37, scope: !414)
!2618 = !DILocation(line: 2142, column: 28, scope: !414)
!2619 = !DILocation(line: 2143, column: 12, scope: !414)
!2620 = !DILocation(line: 2144, column: 1, scope: !414)
!2621 = !DILocation(line: 0, scope: !443)
!2622 = !DILocation(line: 0, scope: !875, inlinedAt: !2623)
!2623 = distinct !DILocation(line: 2262, column: 3, scope: !460)
!2624 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2623)
!2625 = !DILocation(line: 0, scope: !460)
!2626 = !DILocation(line: 2262, column: 3, scope: !460)
!2627 = !DILocation(line: 2263, column: 12, scope: !443)
!2628 = !DILocation(line: 2264, column: 6, scope: !443)
!2629 = !DILocation(line: 2267, column: 10, scope: !467)
!2630 = !DILocation(line: 2267, column: 7, scope: !443)
!2631 = !DILocation(line: 2268, column: 12, scope: !465)
!2632 = !DILocation(line: 2268, column: 9, scope: !466)
!2633 = !DILocation(line: 2269, column: 14, scope: !463)
!2634 = !DILocation(line: 2269, column: 11, scope: !464)
!2635 = !DILocation(line: 0, scope: !875, inlinedAt: !2636)
!2636 = distinct !DILocation(line: 2271, column: 9, scope: !469)
!2637 = !DILocation(line: 0, scope: !469)
!2638 = !DILocation(line: 2271, column: 9, scope: !469)
!2639 = !DILocation(line: 0, scope: !462)
!2640 = !DILocation(line: 2272, column: 18, scope: !2641)
!2641 = distinct !DILexicalBlock(scope: !462, file: !3, line: 2272, column: 13)
!2642 = !DILocation(line: 2272, column: 29, scope: !2641)
!2643 = !DILocation(line: 2272, column: 36, scope: !2641)
!2644 = !DILocation(line: 2272, column: 13, scope: !462)
!2645 = !DILocation(line: 2277, column: 13, scope: !2646)
!2646 = distinct !DILexicalBlock(scope: !464, file: !3, line: 2277, column: 11)
!2647 = !DILocation(line: 2277, column: 11, scope: !464)
!2648 = !DILocation(line: 2277, column: 35, scope: !2646)
!2649 = !DILocation(line: 2277, column: 42, scope: !2646)
!2650 = !DILocation(line: 2277, column: 40, scope: !2646)
!2651 = !DILocation(line: 2277, column: 28, scope: !2646)
!2652 = !DILocation(line: 2279, column: 13, scope: !2653)
!2653 = distinct !DILexicalBlock(scope: !466, file: !3, line: 2279, column: 9)
!2654 = !DILocation(line: 2279, column: 9, scope: !466)
!2655 = !DILocation(line: 2286, column: 10, scope: !2656)
!2656 = distinct !DILexicalBlock(scope: !443, file: !3, line: 2286, column: 7)
!2657 = !DILocation(line: 2286, column: 7, scope: !443)
!2658 = !DILocation(line: 2287, column: 12, scope: !2659)
!2659 = distinct !DILexicalBlock(scope: !2660, file: !3, line: 2287, column: 9)
!2660 = distinct !DILexicalBlock(scope: !2656, file: !3, line: 2286, column: 24)
!2661 = !DILocation(line: 2287, column: 9, scope: !2660)
!2662 = !DILocation(line: 2288, column: 15, scope: !2663)
!2663 = distinct !DILexicalBlock(scope: !2664, file: !3, line: 2288, column: 11)
!2664 = distinct !DILexicalBlock(scope: !2659, file: !3, line: 2287, column: 26)
!2665 = !DILocation(line: 2288, column: 11, scope: !2664)
!2666 = !DILocation(line: 2289, column: 16, scope: !2667)
!2667 = distinct !DILexicalBlock(scope: !2663, file: !3, line: 2288, column: 21)
!2668 = !DILocation(line: 2292, column: 7, scope: !2667)
!2669 = !DILocation(line: 2293, column: 16, scope: !2670)
!2670 = distinct !DILexicalBlock(scope: !2663, file: !3, line: 2292, column: 14)
!2671 = !DILocation(line: 2298, column: 30, scope: !2672)
!2672 = distinct !DILexicalBlock(scope: !2659, file: !3, line: 2297, column: 12)
!2673 = !DILocation(line: 2298, column: 25, scope: !2672)
!2674 = !DILocation(line: 2298, column: 22, scope: !2672)
!2675 = !DILocation(line: 2298, column: 11, scope: !2672)
!2676 = !DILocation(line: 2299, column: 11, scope: !2672)
!2677 = !DILocation(line: 2300, column: 14, scope: !2672)
!2678 = !DILocation(line: 2301, column: 14, scope: !2672)
!2679 = !DILocation(line: 0, scope: !2659)
!2680 = !DILocation(line: 2303, column: 12, scope: !2660)
!2681 = !DILocation(line: 2304, column: 13, scope: !2660)
!2682 = !DILocation(line: 2304, column: 18, scope: !2660)
!2683 = !DILocation(line: 2305, column: 3, scope: !2660)
!2684 = !DILocation(line: 2305, column: 17, scope: !2685)
!2685 = distinct !DILexicalBlock(scope: !2656, file: !3, line: 2305, column: 14)
!2686 = !DILocation(line: 2305, column: 14, scope: !2656)
!2687 = !DILocation(line: 2306, column: 9, scope: !2688)
!2688 = distinct !DILexicalBlock(scope: !2685, file: !3, line: 2305, column: 31)
!2689 = !DILocation(line: 2306, column: 14, scope: !2688)
!2690 = !DILocation(line: 2307, column: 22, scope: !2688)
!2691 = !DILocation(line: 2307, column: 27, scope: !2688)
!2692 = !DILocation(line: 2307, column: 19, scope: !2688)
!2693 = !DILocation(line: 2307, column: 14, scope: !2688)
!2694 = !DILocation(line: 2307, column: 5, scope: !2688)
!2695 = !DILocation(line: 0, scope: !2656)
!2696 = !DILocation(line: 2313, column: 13, scope: !443)
!2697 = !DILocation(line: 2314, column: 11, scope: !443)
!2698 = !DILocation(line: 2315, column: 60, scope: !443)
!2699 = !DILocation(line: 2315, column: 48, scope: !443)
!2700 = !DILocation(line: 2315, column: 36, scope: !443)
!2701 = !DILocation(line: 2315, column: 24, scope: !443)
!2702 = !DILocation(line: 2315, column: 12, scope: !443)
!2703 = !DILocation(line: 2316, column: 11, scope: !443)
!2704 = !DILocation(line: 2317, column: 18, scope: !443)
!2705 = !DILocation(line: 2317, column: 30, scope: !443)
!2706 = !DILocation(line: 2317, column: 23, scope: !443)
!2707 = !DILocation(line: 2317, column: 11, scope: !443)
!2708 = !DILocation(line: 2318, column: 9, scope: !473)
!2709 = !DILocation(line: 2318, column: 7, scope: !443)
!2710 = !DILocation(line: 2319, column: 23, scope: !2711)
!2711 = distinct !DILexicalBlock(scope: !473, file: !3, line: 2318, column: 15)
!2712 = !DILocation(line: 2319, column: 14, scope: !2711)
!2713 = !DILocation(line: 2319, column: 5, scope: !2711)
!2714 = !DILocation(line: 0, scope: !471)
!2715 = !DILocation(line: 2321, column: 5, scope: !471)
!2716 = !DILocation(line: 0, scope: !949, inlinedAt: !2717)
!2717 = distinct !DILocation(line: 2321, column: 5, scope: !471)
!2718 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2717)
!2719 = !DILocation(line: 2325, column: 17, scope: !472)
!2720 = !DILocation(line: 2325, column: 22, scope: !472)
!2721 = !DILocation(line: 2326, column: 7, scope: !472)
!2722 = !DILocation(line: 2327, column: 9, scope: !472)
!2723 = !DILocation(line: 2327, column: 34, scope: !2724)
!2724 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2327, column: 9)
!2725 = !DILocation(line: 2327, column: 39, scope: !2724)
!2726 = !DILocation(line: 2327, column: 18, scope: !2724)
!2727 = !DILocation(line: 2329, column: 13, scope: !2728)
!2728 = distinct !DILexicalBlock(scope: !2729, file: !3, line: 2329, column: 11)
!2729 = distinct !DILexicalBlock(scope: !2730, file: !3, line: 2328, column: 17)
!2730 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2328, column: 9)
!2731 = !DILocation(line: 2329, column: 11, scope: !2729)
!2732 = !DILocation(line: 2330, column: 31, scope: !2728)
!2733 = !DILocation(line: 2330, column: 26, scope: !2728)
!2734 = !DILocation(line: 2330, column: 21, scope: !2728)
!2735 = !DILocation(line: 2330, column: 9, scope: !2728)
!2736 = !DILocation(line: 2332, column: 31, scope: !2728)
!2737 = !DILocation(line: 2332, column: 20, scope: !2728)
!2738 = !DILocation(line: 2332, column: 9, scope: !2728)
!2739 = !DILocation(line: 2334, column: 17, scope: !2740)
!2740 = distinct !DILexicalBlock(scope: !472, file: !3, line: 2334, column: 9)
!2741 = !DILocation(line: 2335, column: 15, scope: !2742)
!2742 = distinct !DILexicalBlock(scope: !2740, file: !3, line: 2334, column: 28)
!2743 = !DILocation(line: 2339, column: 13, scope: !2744)
!2744 = distinct !DILexicalBlock(scope: !2742, file: !3, line: 2339, column: 11)
!2745 = !DILocation(line: 2339, column: 11, scope: !2742)
!2746 = !DILocation(line: 2343, column: 16, scope: !2742)
!2747 = !DILocation(line: 2343, column: 7, scope: !2742)
!2748 = !DILocation(line: 2346, column: 11, scope: !477)
!2749 = !DILocation(line: 0, scope: !875, inlinedAt: !2750)
!2750 = distinct !DILocation(line: 2347, column: 7, scope: !475)
!2751 = !DILocation(line: 0, scope: !875, inlinedAt: !2752)
!2752 = distinct !DILocation(line: 2351, column: 7, scope: !479)
!2753 = !DILocation(line: 2346, column: 9, scope: !472)
!2754 = !DILocation(line: 0, scope: !475)
!2755 = !DILocation(line: 2347, column: 7, scope: !475)
!2756 = !DILocation(line: 0, scope: !949, inlinedAt: !2757)
!2757 = distinct !DILocation(line: 2347, column: 7, scope: !475)
!2758 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2757)
!2759 = !DILocation(line: 2348, column: 18, scope: !476)
!2760 = !DILocation(line: 2348, column: 13, scope: !476)
!2761 = !DILocation(line: 2350, column: 5, scope: !476)
!2762 = !DILocation(line: 0, scope: !479)
!2763 = !DILocation(line: 2351, column: 7, scope: !479)
!2764 = !DILocation(line: 0, scope: !949, inlinedAt: !2765)
!2765 = distinct !DILocation(line: 2351, column: 7, scope: !479)
!2766 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2765)
!2767 = !DILocation(line: 2352, column: 18, scope: !480)
!2768 = !DILocation(line: 2352, column: 13, scope: !480)
!2769 = !DILocation(line: 2353, column: 9, scope: !480)
!2770 = !DILocation(line: 0, scope: !477)
!2771 = !DILocation(line: 2357, column: 3, scope: !443)
!2772 = !DILocation(line: 2358, column: 1, scope: !443)
!2773 = !DILocation(line: 0, scope: !505)
!2774 = !DILocation(line: 0, scope: !875, inlinedAt: !2775)
!2775 = distinct !DILocation(line: 2377, column: 3, scope: !517)
!2776 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2775)
!2777 = !DILocation(line: 0, scope: !517)
!2778 = !DILocation(line: 2377, column: 3, scope: !517)
!2779 = !DILocation(line: 2378, column: 13, scope: !505)
!2780 = !DILocation(line: 2379, column: 6, scope: !505)
!2781 = !DILocation(line: 2380, column: 10, scope: !2782)
!2782 = distinct !DILexicalBlock(scope: !505, file: !3, line: 2380, column: 7)
!2783 = !DILocation(line: 2380, column: 7, scope: !505)
!2784 = !DILocation(line: 2380, column: 35, scope: !2782)
!2785 = !DILocation(line: 2380, column: 25, scope: !2782)
!2786 = !DILocation(line: 2397, column: 10, scope: !521)
!2787 = !DILocation(line: 2397, column: 7, scope: !505)
!2788 = !DILocation(line: 2398, column: 13, scope: !2789)
!2789 = distinct !DILexicalBlock(scope: !520, file: !3, line: 2398, column: 9)
!2790 = !DILocation(line: 2398, column: 20, scope: !2789)
!2791 = !DILocation(line: 2398, column: 9, scope: !520)
!2792 = !DILocation(line: 0, scope: !875, inlinedAt: !2793)
!2793 = distinct !DILocation(line: 2399, column: 5, scope: !519)
!2794 = !DILocation(line: 0, scope: !949, inlinedAt: !2795)
!2795 = distinct !DILocation(line: 2399, column: 5, scope: !519)
!2796 = !DILocation(line: 2400, column: 7, scope: !520)
!2797 = !DILocation(line: 0, scope: !875, inlinedAt: !2798)
!2798 = distinct !DILocation(line: 2401, column: 5, scope: !523)
!2799 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2798)
!2800 = !DILocation(line: 0, scope: !523)
!2801 = !DILocation(line: 2401, column: 5, scope: !523)
!2802 = !DILocation(line: 0, scope: !525)
!2803 = !DILocation(line: 2402, column: 5, scope: !525)
!2804 = !DILocation(line: 0, scope: !949, inlinedAt: !2805)
!2805 = distinct !DILocation(line: 2402, column: 5, scope: !525)
!2806 = !DILocation(line: 2403, column: 3, scope: !520)
!2807 = !DILocation(line: 0, scope: !521)
!2808 = !DILocation(line: 2417, column: 10, scope: !505)
!2809 = !DILocation(line: 2417, column: 20, scope: !505)
!2810 = !DILocation(line: 2417, column: 15, scope: !505)
!2811 = !DILocation(line: 2418, column: 26, scope: !505)
!2812 = !DILocation(line: 2418, column: 16, scope: !505)
!2813 = !DILocation(line: 2418, column: 43, scope: !505)
!2814 = !DILocation(line: 2418, column: 48, scope: !505)
!2815 = !DILocation(line: 2418, column: 59, scope: !505)
!2816 = !DILocation(line: 2418, column: 37, scope: !505)
!2817 = !DILocation(line: 2418, column: 9, scope: !505)
!2818 = !DILocation(line: 0, scope: !875, inlinedAt: !2819)
!2819 = distinct !DILocation(line: 2430, column: 19, scope: !505)
!2820 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2819)
!2821 = !DILocation(line: 2431, column: 30, scope: !505)
!2822 = !DILocation(line: 0, scope: !949, inlinedAt: !2823)
!2823 = distinct !DILocation(line: 2432, column: 7, scope: !505)
!2824 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !2823)
!2825 = !DILocation(line: 2435, column: 9, scope: !505)
!2826 = !DILocation(line: 2436, column: 9, scope: !505)
!2827 = !DILocation(line: 2437, column: 9, scope: !505)
!2828 = !DILocation(line: 2438, column: 10, scope: !505)
!2829 = !DILocation(line: 2438, column: 20, scope: !505)
!2830 = !DILocation(line: 2438, column: 15, scope: !505)
!2831 = !DILocation(line: 2439, column: 9, scope: !505)
!2832 = !DILocation(line: 2442, column: 1, scope: !505)
!2833 = distinct !DISubprogram(name: "pts_ieee754_sin", scope: !3, file: !3, line: 2474, type: !4, scopeLine: 2474, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2834)
!2834 = !{!2835, !2836, !2837, !2838, !2839, !2840}
!2835 = !DILocalVariable(name: "x", arg: 1, scope: !2833, file: !3, line: 2474, type: !6)
!2836 = !DILocalVariable(name: "y", scope: !2833, file: !3, line: 2475, type: !1652)
!2837 = !DILocalVariable(name: "z", scope: !2833, file: !3, line: 2475, type: !6)
!2838 = !DILocalVariable(name: "n", scope: !2833, file: !3, line: 2476, type: !18)
!2839 = !DILocalVariable(name: "ix", scope: !2833, file: !3, line: 2476, type: !18)
!2840 = !DILocalVariable(name: "bits", scope: !2841, file: !3, line: 2479, type: !16)
!2841 = distinct !DILexicalBlock(scope: !2833, file: !3, line: 2479, column: 3)
!2842 = distinct !DIAssignID()
!2843 = !DILocation(line: 0, scope: !2833)
!2844 = !DILocation(line: 2475, column: 3, scope: !2833)
!2845 = !DILocation(line: 0, scope: !875, inlinedAt: !2846)
!2846 = distinct !DILocation(line: 2479, column: 3, scope: !2841)
!2847 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2846)
!2848 = !DILocation(line: 0, scope: !2841)
!2849 = !DILocation(line: 2479, column: 3, scope: !2841)
!2850 = !DILocation(line: 2482, column: 6, scope: !2833)
!2851 = !DILocation(line: 2483, column: 10, scope: !2852)
!2852 = distinct !DILexicalBlock(scope: !2833, file: !3, line: 2483, column: 7)
!2853 = !DILocation(line: 2483, column: 7, scope: !2833)
!2854 = !DILocation(line: 0, scope: !765, inlinedAt: !2855)
!2855 = distinct !DILocation(line: 2484, column: 12, scope: !2856)
!2856 = distinct !DILexicalBlock(scope: !2852, file: !3, line: 2483, column: 25)
!2857 = !DILocation(line: 0, scope: !875, inlinedAt: !2858)
!2858 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2855)
!2859 = !DILocation(line: 0, scope: !777, inlinedAt: !2855)
!2860 = !DILocation(line: 718, column: 10, scope: !1750, inlinedAt: !2855)
!2861 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2855)
!2862 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2855)
!2863 = !DILocation(line: 722, column: 9, scope: !765, inlinedAt: !2855)
!2864 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2855)
!2865 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2855)
!2866 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2855)
!2867 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2855)
!2868 = !DILocation(line: 725, column: 24, scope: !2869, inlinedAt: !2855)
!2869 = distinct !DILexicalBlock(scope: !1760, file: !3, line: 724, column: 16)
!2870 = !DILocation(line: 725, column: 14, scope: !2869, inlinedAt: !2855)
!2871 = !DILocation(line: 725, column: 5, scope: !2869, inlinedAt: !2855)
!2872 = !DILocation(line: 2485, column: 17, scope: !2873)
!2873 = distinct !DILexicalBlock(scope: !2852, file: !3, line: 2485, column: 14)
!2874 = !DILocation(line: 2485, column: 14, scope: !2852)
!2875 = !DILocation(line: 2487, column: 14, scope: !2876)
!2876 = distinct !DILexicalBlock(scope: !2873, file: !3, line: 2485, column: 32)
!2877 = !DILocation(line: 2487, column: 5, scope: !2876)
!2878 = !DILocation(line: 2490, column: 9, scope: !2879)
!2879 = distinct !DILexicalBlock(scope: !2873, file: !3, line: 2488, column: 10)
!2880 = !DILocation(line: 2491, column: 15, scope: !2879)
!2881 = !DILocation(line: 0, scope: !2882)
!2882 = distinct !DILexicalBlock(scope: !2879, file: !3, line: 2491, column: 20)
!2883 = !DILocation(line: 2491, column: 5, scope: !2879)
!2884 = !DILocation(line: 0, scope: !765, inlinedAt: !2885)
!2885 = distinct !DILocation(line: 2493, column: 16, scope: !2882)
!2886 = !DILocation(line: 0, scope: !875, inlinedAt: !2887)
!2887 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2885)
!2888 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2887)
!2889 = !DILocation(line: 0, scope: !777, inlinedAt: !2885)
!2890 = !DILocation(line: 718, column: 10, scope: !1750, inlinedAt: !2885)
!2891 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2885)
!2892 = !DILocation(line: 2493, column: 35, scope: !2882)
!2893 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2885)
!2894 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2885)
!2895 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2885)
!2896 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2885)
!2897 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2885)
!2898 = !DILocation(line: 727, column: 32, scope: !1759, inlinedAt: !2885)
!2899 = !DILocation(line: 727, column: 41, scope: !1759, inlinedAt: !2885)
!2900 = !DILocation(line: 727, column: 46, scope: !1759, inlinedAt: !2885)
!2901 = !DILocation(line: 727, column: 14, scope: !1759, inlinedAt: !2885)
!2902 = !DILocation(line: 727, column: 5, scope: !1759, inlinedAt: !2885)
!2903 = !DILocation(line: 2495, column: 35, scope: !2882)
!2904 = !DILocation(line: 0, scope: !607, inlinedAt: !2905)
!2905 = distinct !DILocation(line: 2495, column: 16, scope: !2882)
!2906 = !DILocation(line: 0, scope: !875, inlinedAt: !2907)
!2907 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2905)
!2908 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2907)
!2909 = !DILocation(line: 0, scope: !618, inlinedAt: !2905)
!2910 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2905)
!2911 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !2905)
!2912 = !DILocation(line: 350, column: 10, scope: !1677, inlinedAt: !2905)
!2913 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !2905)
!2914 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !2905)
!2915 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !2905)
!2916 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !2905)
!2917 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !2905)
!2918 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !2905)
!2919 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !2905)
!2920 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !2905)
!2921 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !2905)
!2922 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !2905)
!2923 = !DILocation(line: 356, column: 36, scope: !1689, inlinedAt: !2905)
!2924 = !DILocation(line: 356, column: 27, scope: !1689, inlinedAt: !2905)
!2925 = !DILocation(line: 356, column: 16, scope: !1689, inlinedAt: !2905)
!2926 = !DILocation(line: 356, column: 5, scope: !1689, inlinedAt: !2905)
!2927 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !2905)
!2928 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !2905)
!2929 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !2905)
!2930 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !2905)
!2931 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !2905)
!2932 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !2905)
!2933 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !2905)
!2934 = !DILocation(line: 0, scope: !765, inlinedAt: !2935)
!2935 = distinct !DILocation(line: 2497, column: 17, scope: !2882)
!2936 = !DILocation(line: 0, scope: !875, inlinedAt: !2937)
!2937 = distinct !DILocation(line: 716, column: 3, scope: !777, inlinedAt: !2935)
!2938 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2937)
!2939 = !DILocation(line: 0, scope: !777, inlinedAt: !2935)
!2940 = !DILocation(line: 718, column: 10, scope: !1750, inlinedAt: !2935)
!2941 = !DILocation(line: 718, column: 7, scope: !765, inlinedAt: !2935)
!2942 = !DILocation(line: 2497, column: 36, scope: !2882)
!2943 = !DILocation(line: 721, column: 9, scope: !765, inlinedAt: !2935)
!2944 = !DILocation(line: 723, column: 40, scope: !765, inlinedAt: !2935)
!2945 = !DILocation(line: 723, column: 30, scope: !765, inlinedAt: !2935)
!2946 = !DILocation(line: 723, column: 20, scope: !765, inlinedAt: !2935)
!2947 = !DILocation(line: 723, column: 10, scope: !765, inlinedAt: !2935)
!2948 = !DILocation(line: 727, column: 32, scope: !1759, inlinedAt: !2935)
!2949 = !DILocation(line: 727, column: 41, scope: !1759, inlinedAt: !2935)
!2950 = !DILocation(line: 727, column: 46, scope: !1759, inlinedAt: !2935)
!2951 = !DILocation(line: 727, column: 14, scope: !1759, inlinedAt: !2935)
!2952 = !DILocation(line: 727, column: 5, scope: !1759, inlinedAt: !2935)
!2953 = !DILocation(line: 2497, column: 16, scope: !2882)
!2954 = !DILocation(line: 2497, column: 9, scope: !2882)
!2955 = !DILocation(line: 2499, column: 36, scope: !2882)
!2956 = !DILocation(line: 0, scope: !607, inlinedAt: !2957)
!2957 = distinct !DILocation(line: 2499, column: 17, scope: !2882)
!2958 = !DILocation(line: 0, scope: !875, inlinedAt: !2959)
!2959 = distinct !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2957)
!2960 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !2959)
!2961 = !DILocation(line: 0, scope: !618, inlinedAt: !2957)
!2962 = !DILocation(line: 348, column: 3, scope: !618, inlinedAt: !2957)
!2963 = !DILocation(line: 349, column: 6, scope: !607, inlinedAt: !2957)
!2964 = !DILocation(line: 350, column: 10, scope: !1677, inlinedAt: !2957)
!2965 = !DILocation(line: 350, column: 7, scope: !607, inlinedAt: !2957)
!2966 = !DILocation(line: 353, column: 9, scope: !607, inlinedAt: !2957)
!2967 = !DILocation(line: 354, column: 55, scope: !607, inlinedAt: !2957)
!2968 = !DILocation(line: 354, column: 45, scope: !607, inlinedAt: !2957)
!2969 = !DILocation(line: 354, column: 35, scope: !607, inlinedAt: !2957)
!2970 = !DILocation(line: 354, column: 25, scope: !607, inlinedAt: !2957)
!2971 = !DILocation(line: 354, column: 15, scope: !607, inlinedAt: !2957)
!2972 = !DILocation(line: 354, column: 9, scope: !607, inlinedAt: !2957)
!2973 = !DILocation(line: 355, column: 10, scope: !624, inlinedAt: !2957)
!2974 = !DILocation(line: 355, column: 7, scope: !607, inlinedAt: !2957)
!2975 = !DILocation(line: 356, column: 36, scope: !1689, inlinedAt: !2957)
!2976 = !DILocation(line: 356, column: 27, scope: !1689, inlinedAt: !2957)
!2977 = !DILocation(line: 356, column: 16, scope: !1689, inlinedAt: !2957)
!2978 = !DILocation(line: 356, column: 5, scope: !1689, inlinedAt: !2957)
!2979 = !DILocation(line: 358, column: 12, scope: !622, inlinedAt: !2957)
!2980 = !DILocation(line: 358, column: 9, scope: !623, inlinedAt: !2957)
!2981 = !DILocation(line: 363, column: 18, scope: !623, inlinedAt: !2957)
!2982 = !DILocation(line: 364, column: 13, scope: !623, inlinedAt: !2957)
!2983 = !DILocation(line: 365, column: 29, scope: !623, inlinedAt: !2957)
!2984 = !DILocation(line: 365, column: 14, scope: !623, inlinedAt: !2957)
!2985 = !DILocation(line: 365, column: 5, scope: !623, inlinedAt: !2957)
!2986 = !DILocation(line: 2499, column: 16, scope: !2882)
!2987 = !DILocation(line: 2499, column: 9, scope: !2882)
!2988 = !DILocation(line: 0, scope: !2852)
!2989 = !DILocation(line: 2502, column: 1, scope: !2833)
!2990 = distinct !DISubprogram(name: "pts_ieee754_tan", scope: !3, file: !3, line: 2533, type: !4, scopeLine: 2533, flags: DIFlagPrototyped | DIFlagAllCallsDescribed, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !7, retainedNodes: !2991)
!2991 = !{!2992, !2993, !2994, !2995, !2996, !2997}
!2992 = !DILocalVariable(name: "x", arg: 1, scope: !2990, file: !3, line: 2533, type: !6)
!2993 = !DILocalVariable(name: "y", scope: !2990, file: !3, line: 2534, type: !1652)
!2994 = !DILocalVariable(name: "z", scope: !2990, file: !3, line: 2534, type: !6)
!2995 = !DILocalVariable(name: "n", scope: !2990, file: !3, line: 2535, type: !18)
!2996 = !DILocalVariable(name: "ix", scope: !2990, file: !3, line: 2535, type: !18)
!2997 = !DILocalVariable(name: "bits", scope: !2998, file: !3, line: 2538, type: !16)
!2998 = distinct !DILexicalBlock(scope: !2990, file: !3, line: 2538, column: 3)
!2999 = distinct !DIAssignID()
!3000 = !DILocation(line: 0, scope: !2990)
!3001 = !DILocation(line: 2534, column: 3, scope: !2990)
!3002 = !DILocation(line: 0, scope: !875, inlinedAt: !3003)
!3003 = distinct !DILocation(line: 2538, column: 3, scope: !2998)
!3004 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3003)
!3005 = !DILocation(line: 0, scope: !2998)
!3006 = !DILocation(line: 2538, column: 3, scope: !2998)
!3007 = !DILocation(line: 2541, column: 6, scope: !2990)
!3008 = !DILocation(line: 2542, column: 10, scope: !3009)
!3009 = distinct !DILexicalBlock(scope: !2990, file: !3, line: 2542, column: 7)
!3010 = !DILocation(line: 2542, column: 7, scope: !2990)
!3011 = !DILocation(line: 0, scope: !806, inlinedAt: !3012)
!3012 = distinct !DILocation(line: 2543, column: 12, scope: !3013)
!3013 = distinct !DILexicalBlock(scope: !3009, file: !3, line: 2542, column: 25)
!3014 = !DILocation(line: 0, scope: !875, inlinedAt: !3015)
!3015 = distinct !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3012)
!3016 = !DILocation(line: 0, scope: !819, inlinedAt: !3012)
!3017 = !DILocation(line: 793, column: 10, scope: !824, inlinedAt: !3012)
!3018 = !DILocation(line: 793, column: 7, scope: !806, inlinedAt: !3012)
!3019 = !DILocation(line: 816, column: 10, scope: !3020, inlinedAt: !3012)
!3020 = distinct !DILexicalBlock(scope: !806, file: !3, line: 816, column: 7)
!3021 = !DILocation(line: 816, column: 7, scope: !806, inlinedAt: !3012)
!3022 = !DILocation(line: 817, column: 12, scope: !3023, inlinedAt: !3012)
!3023 = distinct !DILexicalBlock(scope: !3024, file: !3, line: 817, column: 9)
!3024 = distinct !DILexicalBlock(scope: !3020, file: !3, line: 816, column: 25)
!3025 = !DILocation(line: 817, column: 9, scope: !3024, inlinedAt: !3012)
!3026 = !DILocation(line: 821, column: 14, scope: !3024, inlinedAt: !3012)
!3027 = !DILocation(line: 823, column: 11, scope: !3024, inlinedAt: !3012)
!3028 = !DILocation(line: 825, column: 3, scope: !3024, inlinedAt: !3012)
!3029 = !DILocation(line: 826, column: 9, scope: !806, inlinedAt: !3012)
!3030 = !DILocation(line: 827, column: 9, scope: !806, inlinedAt: !3012)
!3031 = !DILocation(line: 833, column: 60, scope: !806, inlinedAt: !3012)
!3032 = !DILocation(line: 833, column: 48, scope: !806, inlinedAt: !3012)
!3033 = !DILocation(line: 833, column: 36, scope: !806, inlinedAt: !3012)
!3034 = !DILocation(line: 833, column: 24, scope: !806, inlinedAt: !3012)
!3035 = !DILocation(line: 833, column: 12, scope: !806, inlinedAt: !3012)
!3036 = !DILocation(line: 835, column: 62, scope: !806, inlinedAt: !3012)
!3037 = !DILocation(line: 835, column: 49, scope: !806, inlinedAt: !3012)
!3038 = !DILocation(line: 835, column: 37, scope: !806, inlinedAt: !3012)
!3039 = !DILocation(line: 835, column: 25, scope: !806, inlinedAt: !3012)
!3040 = !DILocation(line: 835, column: 13, scope: !806, inlinedAt: !3012)
!3041 = !DILocation(line: 834, column: 9, scope: !806, inlinedAt: !3012)
!3042 = !DILocation(line: 836, column: 9, scope: !806, inlinedAt: !3012)
!3043 = !DILocation(line: 837, column: 23, scope: !806, inlinedAt: !3012)
!3044 = !DILocation(line: 837, column: 28, scope: !806, inlinedAt: !3012)
!3045 = !DILocation(line: 837, column: 9, scope: !806, inlinedAt: !3012)
!3046 = !DILocation(line: 838, column: 5, scope: !806, inlinedAt: !3012)
!3047 = !DILocation(line: 839, column: 9, scope: !806, inlinedAt: !3012)
!3048 = !DILocation(line: 840, column: 7, scope: !806, inlinedAt: !3012)
!3049 = !DILocation(line: 842, column: 22, scope: !3050, inlinedAt: !3012)
!3050 = distinct !DILexicalBlock(scope: !3051, file: !3, line: 840, column: 25)
!3051 = distinct !DILexicalBlock(scope: !806, file: !3, line: 840, column: 7)
!3052 = !DILocation(line: 842, column: 29, scope: !3050, inlinedAt: !3012)
!3053 = !DILocation(line: 842, column: 15, scope: !3050, inlinedAt: !3012)
!3054 = !DILocation(line: 842, column: 12, scope: !3050, inlinedAt: !3012)
!3055 = !DILocation(line: 842, column: 56, scope: !3050, inlinedAt: !3012)
!3056 = !DILocation(line: 842, column: 65, scope: !3050, inlinedAt: !3012)
!3057 = !DILocation(line: 842, column: 60, scope: !3050, inlinedAt: !3012)
!3058 = !DILocation(line: 842, column: 70, scope: !3050, inlinedAt: !3012)
!3059 = !DILocation(line: 842, column: 51, scope: !3050, inlinedAt: !3012)
!3060 = !DILocation(line: 842, column: 40, scope: !3050, inlinedAt: !3012)
!3061 = !DILocation(line: 842, column: 35, scope: !3050, inlinedAt: !3012)
!3062 = !DILocation(line: 842, column: 5, scope: !3050, inlinedAt: !3012)
!3063 = !DILocation(line: 2544, column: 17, scope: !3064)
!3064 = distinct !DILexicalBlock(scope: !3009, file: !3, line: 2544, column: 14)
!3065 = !DILocation(line: 2544, column: 14, scope: !3009)
!3066 = !DILocation(line: 2546, column: 14, scope: !3067)
!3067 = distinct !DILexicalBlock(scope: !3064, file: !3, line: 2544, column: 32)
!3068 = !DILocation(line: 2546, column: 5, scope: !3067)
!3069 = !DILocation(line: 2549, column: 9, scope: !3070)
!3070 = distinct !DILexicalBlock(scope: !3064, file: !3, line: 2547, column: 10)
!3071 = !DILocation(line: 2551, column: 25, scope: !3070)
!3072 = !DILocation(line: 2551, column: 31, scope: !3070)
!3073 = !DILocation(line: 2551, column: 50, scope: !3070)
!3074 = !DILocation(line: 2551, column: 39, scope: !3070)
!3075 = !DILocation(line: 0, scope: !806, inlinedAt: !3076)
!3076 = distinct !DILocation(line: 2551, column: 12, scope: !3070)
!3077 = !DILocation(line: 0, scope: !875, inlinedAt: !3078)
!3078 = distinct !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3076)
!3079 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3078)
!3080 = !DILocation(line: 0, scope: !819, inlinedAt: !3076)
!3081 = !DILocation(line: 791, column: 3, scope: !819, inlinedAt: !3076)
!3082 = !DILocation(line: 792, column: 11, scope: !806, inlinedAt: !3076)
!3083 = !DILocation(line: 793, column: 10, scope: !824, inlinedAt: !3076)
!3084 = !DILocation(line: 793, column: 7, scope: !806, inlinedAt: !3076)
!3085 = !DILocation(line: 0, scope: !875, inlinedAt: !3086)
!3086 = distinct !DILocation(line: 796, column: 7, scope: !826, inlinedAt: !3076)
!3087 = !DILocation(line: 0, scope: !826, inlinedAt: !3076)
!3088 = !DILocation(line: 796, column: 7, scope: !826, inlinedAt: !3076)
!3089 = !DILocation(line: 0, scope: !821, inlinedAt: !3076)
!3090 = !DILocation(line: 797, column: 29, scope: !831, inlinedAt: !3076)
!3091 = !DILocation(line: 797, column: 23, scope: !831, inlinedAt: !3076)
!3092 = !DILocation(line: 797, column: 35, scope: !831, inlinedAt: !3076)
!3093 = !DILocation(line: 797, column: 11, scope: !821, inlinedAt: !3076)
!3094 = !DILocation(line: 798, column: 22, scope: !3095, inlinedAt: !3076)
!3095 = distinct !DILexicalBlock(scope: !831, file: !3, line: 797, column: 41)
!3096 = !DILocation(line: 798, column: 20, scope: !3095, inlinedAt: !3076)
!3097 = !DILocation(line: 798, column: 9, scope: !3095, inlinedAt: !3076)
!3098 = !DILocation(line: 800, column: 16, scope: !829, inlinedAt: !3076)
!3099 = !DILocation(line: 800, column: 13, scope: !830, inlinedAt: !3076)
!3100 = !DILocation(line: 805, column: 21, scope: !828, inlinedAt: !3076)
!3101 = !DILocation(line: 0, scope: !875, inlinedAt: !3102)
!3102 = distinct !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3076)
!3103 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3102)
!3104 = !DILocation(line: 0, scope: !834, inlinedAt: !3076)
!3105 = !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3076)
!3106 = !DILocation(line: 0, scope: !949, inlinedAt: !3107)
!3107 = distinct !DILocation(line: 806, column: 11, scope: !834, inlinedAt: !3076)
!3108 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !3107)
!3109 = !DILocation(line: 807, column: 22, scope: !828, inlinedAt: !3076)
!3110 = !DILocation(line: 807, column: 17, scope: !828, inlinedAt: !3076)
!3111 = !DILocation(line: 808, column: 24, scope: !828, inlinedAt: !3076)
!3112 = !DILocation(line: 0, scope: !828, inlinedAt: !3076)
!3113 = !DILocation(line: 0, scope: !875, inlinedAt: !3114)
!3114 = distinct !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3076)
!3115 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3114)
!3116 = !DILocation(line: 0, scope: !836, inlinedAt: !3076)
!3117 = !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3076)
!3118 = !DILocation(line: 0, scope: !949, inlinedAt: !3119)
!3119 = distinct !DILocation(line: 809, column: 11, scope: !836, inlinedAt: !3076)
!3120 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !3119)
!3121 = !DILocation(line: 810, column: 19, scope: !828, inlinedAt: !3076)
!3122 = !DILocation(line: 811, column: 29, scope: !828, inlinedAt: !3076)
!3123 = !DILocation(line: 811, column: 20, scope: !828, inlinedAt: !3076)
!3124 = !DILocation(line: 816, column: 10, scope: !3020, inlinedAt: !3076)
!3125 = !DILocation(line: 816, column: 7, scope: !806, inlinedAt: !3076)
!3126 = !DILocation(line: 817, column: 12, scope: !3023, inlinedAt: !3076)
!3127 = !DILocation(line: 817, column: 9, scope: !3024, inlinedAt: !3076)
!3128 = !DILocation(line: 821, column: 14, scope: !3024, inlinedAt: !3076)
!3129 = !DILocation(line: 822, column: 16, scope: !3024, inlinedAt: !3076)
!3130 = !DILocation(line: 823, column: 11, scope: !3024, inlinedAt: !3076)
!3131 = !DILocation(line: 825, column: 3, scope: !3024, inlinedAt: !3076)
!3132 = !DILocation(line: 826, column: 9, scope: !806, inlinedAt: !3076)
!3133 = !DILocation(line: 827, column: 9, scope: !806, inlinedAt: !3076)
!3134 = !DILocation(line: 833, column: 60, scope: !806, inlinedAt: !3076)
!3135 = !DILocation(line: 833, column: 48, scope: !806, inlinedAt: !3076)
!3136 = !DILocation(line: 833, column: 36, scope: !806, inlinedAt: !3076)
!3137 = !DILocation(line: 833, column: 24, scope: !806, inlinedAt: !3076)
!3138 = !DILocation(line: 833, column: 12, scope: !806, inlinedAt: !3076)
!3139 = !DILocation(line: 835, column: 62, scope: !806, inlinedAt: !3076)
!3140 = !DILocation(line: 835, column: 49, scope: !806, inlinedAt: !3076)
!3141 = !DILocation(line: 835, column: 37, scope: !806, inlinedAt: !3076)
!3142 = !DILocation(line: 835, column: 25, scope: !806, inlinedAt: !3076)
!3143 = !DILocation(line: 835, column: 13, scope: !806, inlinedAt: !3076)
!3144 = !DILocation(line: 834, column: 9, scope: !806, inlinedAt: !3076)
!3145 = !DILocation(line: 836, column: 9, scope: !806, inlinedAt: !3076)
!3146 = !DILocation(line: 837, column: 23, scope: !806, inlinedAt: !3076)
!3147 = !DILocation(line: 837, column: 28, scope: !806, inlinedAt: !3076)
!3148 = !DILocation(line: 837, column: 9, scope: !806, inlinedAt: !3076)
!3149 = !DILocation(line: 838, column: 5, scope: !806, inlinedAt: !3076)
!3150 = !DILocation(line: 839, column: 9, scope: !806, inlinedAt: !3076)
!3151 = !DILocation(line: 840, column: 7, scope: !806, inlinedAt: !3076)
!3152 = !DILocation(line: 841, column: 9, scope: !3050, inlinedAt: !3076)
!3153 = !DILocation(line: 842, column: 22, scope: !3050, inlinedAt: !3076)
!3154 = !DILocation(line: 842, column: 29, scope: !3050, inlinedAt: !3076)
!3155 = !DILocation(line: 842, column: 15, scope: !3050, inlinedAt: !3076)
!3156 = !DILocation(line: 842, column: 12, scope: !3050, inlinedAt: !3076)
!3157 = !DILocation(line: 842, column: 56, scope: !3050, inlinedAt: !3076)
!3158 = !DILocation(line: 842, column: 65, scope: !3050, inlinedAt: !3076)
!3159 = !DILocation(line: 842, column: 60, scope: !3050, inlinedAt: !3076)
!3160 = !DILocation(line: 842, column: 70, scope: !3050, inlinedAt: !3076)
!3161 = !DILocation(line: 842, column: 51, scope: !3050, inlinedAt: !3076)
!3162 = !DILocation(line: 842, column: 40, scope: !3050, inlinedAt: !3076)
!3163 = !DILocation(line: 842, column: 35, scope: !3050, inlinedAt: !3076)
!3164 = !DILocation(line: 842, column: 5, scope: !3050, inlinedAt: !3076)
!3165 = !DILocation(line: 844, column: 10, scope: !839, inlinedAt: !3076)
!3166 = !DILocation(line: 844, column: 7, scope: !806, inlinedAt: !3076)
!3167 = !DILocation(line: 0, scope: !875, inlinedAt: !3168)
!3168 = distinct !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3076)
!3169 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3168)
!3170 = !DILocation(line: 0, scope: !842, inlinedAt: !3076)
!3171 = !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3076)
!3172 = !DILocation(line: 0, scope: !949, inlinedAt: !3173)
!3173 = distinct !DILocation(line: 854, column: 5, scope: !842, inlinedAt: !3076)
!3174 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !3173)
!3175 = !DILocation(line: 855, column: 16, scope: !838, inlinedAt: !3076)
!3176 = !DILocation(line: 855, column: 11, scope: !838, inlinedAt: !3076)
!3177 = !DILocation(line: 856, column: 18, scope: !838, inlinedAt: !3076)
!3178 = !DILocation(line: 0, scope: !838, inlinedAt: !3076)
!3179 = !DILocation(line: 0, scope: !875, inlinedAt: !3180)
!3180 = distinct !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3076)
!3181 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3180)
!3182 = !DILocation(line: 0, scope: !844, inlinedAt: !3076)
!3183 = !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3076)
!3184 = !DILocation(line: 0, scope: !949, inlinedAt: !3185)
!3185 = distinct !DILocation(line: 857, column: 5, scope: !844, inlinedAt: !3076)
!3186 = !DILocation(line: 62, column: 3, scope: !949, inlinedAt: !3185)
!3187 = !DILocation(line: 858, column: 13, scope: !838, inlinedAt: !3076)
!3188 = !DILocation(line: 859, column: 23, scope: !838, inlinedAt: !3076)
!3189 = !DILocation(line: 859, column: 14, scope: !838, inlinedAt: !3076)
!3190 = !DILocation(line: 0, scope: !3009)
!3191 = !DILocation(line: 2553, column: 1, scope: !2990)
!3192 = !DILocation(line: 0, scope: !545)
!3193 = !DILocation(line: 0, scope: !875, inlinedAt: !3194)
!3194 = distinct !DILocation(line: 2585, column: 3, scope: !550)
!3195 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3194)
!3196 = !DILocation(line: 0, scope: !550)
!3197 = !DILocation(line: 2585, column: 3, scope: !550)
!3198 = !DILocation(line: 2586, column: 6, scope: !545)
!3199 = !DILocation(line: 2589, column: 10, scope: !553)
!3200 = !DILocation(line: 2589, column: 7, scope: !545)
!3201 = !DILocation(line: 2590, column: 34, scope: !552)
!3202 = !DILocation(line: 2590, column: 16, scope: !552)
!3203 = !DILocation(line: 0, scope: !552)
!3204 = !DILocation(line: 2591, column: 20, scope: !552)
!3205 = !DILocation(line: 2593, column: 12, scope: !3206)
!3206 = distinct !DILexicalBlock(scope: !552, file: !3, line: 2593, column: 9)
!3207 = !DILocation(line: 2593, column: 9, scope: !552)
!3208 = !DILocation(line: 2594, column: 21, scope: !552)
!3209 = !DILocation(line: 2594, column: 31, scope: !552)
!3210 = !DILocation(line: 2594, column: 26, scope: !552)
!3211 = !DILocation(line: 2594, column: 16, scope: !552)
!3212 = !DILocation(line: 2594, column: 5, scope: !552)
!3213 = !DILocation(line: 2598, column: 10, scope: !557)
!3214 = !DILocation(line: 2598, column: 7, scope: !545)
!3215 = !DILocation(line: 2599, column: 32, scope: !556)
!3216 = !DILocation(line: 2599, column: 16, scope: !556)
!3217 = !DILocation(line: 0, scope: !556)
!3218 = !DILocation(line: 2600, column: 28, scope: !556)
!3219 = !DILocation(line: 2600, column: 21, scope: !556)
!3220 = !DILocation(line: 2604, column: 10, scope: !3221)
!3221 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2604, column: 7)
!3222 = !DILocation(line: 2604, column: 7, scope: !545)
!3223 = !DILocation(line: 2604, column: 38, scope: !3221)
!3224 = !DILocation(line: 2604, column: 36, scope: !3221)
!3225 = !DILocation(line: 2604, column: 24, scope: !3221)
!3226 = !DILocation(line: 2607, column: 15, scope: !560)
!3227 = !DILocation(line: 2607, column: 7, scope: !545)
!3228 = !DILocation(line: 2608, column: 37, scope: !559)
!3229 = !DILocation(line: 2608, column: 16, scope: !559)
!3230 = !DILocation(line: 0, scope: !559)
!3231 = !DILocation(line: 2609, column: 21, scope: !559)
!3232 = !DILocation(line: 2610, column: 14, scope: !559)
!3233 = !DILocation(line: 2614, column: 10, scope: !3234)
!3234 = distinct !DILexicalBlock(scope: !545, file: !3, line: 2614, column: 7)
!3235 = !DILocation(line: 2614, column: 7, scope: !545)
!3236 = !DILocation(line: 2614, column: 34, scope: !3234)
!3237 = !DILocation(line: 2614, column: 25, scope: !3234)
!3238 = !DILocation(line: 2617, column: 10, scope: !545)
!3239 = !DILocation(line: 2617, column: 17, scope: !545)
!3240 = !DILocation(line: 2617, column: 15, scope: !545)
!3241 = !DILocation(line: 2617, column: 3, scope: !545)
!3242 = !DILocation(line: 2618, column: 1, scope: !545)
!3243 = !DILocation(line: 0, scope: !570)
!3244 = !DILocation(line: 2648, column: 17, scope: !570)
!3245 = !DILocation(line: 2648, column: 14, scope: !570)
!3246 = !DILocation(line: 2650, column: 15, scope: !570)
!3247 = !DILocation(line: 2651, column: 10, scope: !577)
!3248 = !DILocation(line: 2651, column: 7, scope: !570)
!3249 = !DILocation(line: 2653, column: 12, scope: !3250)
!3250 = distinct !DILexicalBlock(scope: !576, file: !3, line: 2653, column: 9)
!3251 = !DILocation(line: 2653, column: 9, scope: !576)
!3252 = !DILocation(line: 2654, column: 16, scope: !576)
!3253 = !DILocation(line: 0, scope: !576)
!3254 = !DILocation(line: 2655, column: 12, scope: !3255)
!3255 = distinct !DILexicalBlock(scope: !576, file: !3, line: 2655, column: 9)
!3256 = !DILocation(line: 2655, column: 9, scope: !576)
!3257 = !DILocation(line: 2656, column: 25, scope: !3258)
!3258 = distinct !DILexicalBlock(scope: !3255, file: !3, line: 2655, column: 17)
!3259 = !DILocation(line: 2656, column: 7, scope: !3258)
!3260 = !DILocation(line: 2658, column: 23, scope: !576)
!3261 = !DILocation(line: 2658, column: 19, scope: !576)
!3262 = !DILocation(line: 2658, column: 5, scope: !576)
!3263 = !DILocation(line: 2661, column: 10, scope: !3264)
!3264 = distinct !DILexicalBlock(scope: !570, file: !3, line: 2661, column: 7)
!3265 = !DILocation(line: 2661, column: 7, scope: !570)
!3266 = !DILocation(line: 2661, column: 33, scope: !3264)
!3267 = !DILocation(line: 2661, column: 31, scope: !3264)
!3268 = !DILocation(line: 2661, column: 22, scope: !3264)
!3269 = !DILocation(line: 2664, column: 10, scope: !580)
!3270 = !DILocation(line: 2664, column: 7, scope: !570)
!3271 = !DILocation(line: 2665, column: 36, scope: !579)
!3272 = !DILocation(line: 2665, column: 16, scope: !579)
!3273 = !DILocation(line: 0, scope: !579)
!3274 = !DILocation(line: 2666, column: 18, scope: !579)
!3275 = !DILocation(line: 2667, column: 14, scope: !579)
!3276 = !DILocation(line: 2671, column: 12, scope: !570)
!3277 = !DILocation(line: 2671, column: 3, scope: !570)
!3278 = !DILocation(line: 2672, column: 1, scope: !570)
!3279 = !DILocation(line: 0, scope: !590)
!3280 = !DILocation(line: 0, scope: !875, inlinedAt: !3281)
!3281 = distinct !DILocation(line: 2703, column: 3, scope: !598)
!3282 = !DILocation(line: 56, column: 3, scope: !875, inlinedAt: !3281)
!3283 = !DILocation(line: 0, scope: !598)
!3284 = !DILocation(line: 2703, column: 3, scope: !598)
!3285 = !DILocation(line: 2704, column: 11, scope: !590)
!3286 = !DILocation(line: 2707, column: 10, scope: !3287)
!3287 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2707, column: 7)
!3288 = !DILocation(line: 2707, column: 7, scope: !590)
!3289 = !DILocation(line: 2708, column: 12, scope: !3290)
!3290 = distinct !DILexicalBlock(scope: !3291, file: !3, line: 2708, column: 9)
!3291 = distinct !DILexicalBlock(scope: !3287, file: !3, line: 2707, column: 25)
!3292 = !DILocation(line: 0, scope: !3290)
!3293 = !DILocation(line: 2708, column: 9, scope: !3291)
!3294 = !DILocation(line: 2709, column: 22, scope: !3290)
!3295 = !DILocation(line: 2709, column: 7, scope: !3290)
!3296 = !DILocation(line: 2711, column: 22, scope: !3290)
!3297 = !DILocation(line: 2711, column: 7, scope: !3290)
!3298 = !DILocation(line: 2715, column: 10, scope: !3299)
!3299 = distinct !DILexicalBlock(scope: !590, file: !3, line: 2715, column: 7)
!3300 = !DILocation(line: 2715, column: 7, scope: !590)
!3301 = !DILocation(line: 2716, column: 12, scope: !3302)
!3302 = distinct !DILexicalBlock(scope: !3303, file: !3, line: 2716, column: 9)
!3303 = distinct !DILexicalBlock(scope: !3299, file: !3, line: 2715, column: 24)
!3304 = !DILocation(line: 2716, column: 9, scope: !3303)
!3305 = !DILocation(line: 2719, column: 12, scope: !3306)
!3306 = distinct !DILexicalBlock(scope: !3303, file: !3, line: 2719, column: 9)
!3307 = !DILocation(line: 0, scope: !3306)
!3308 = !DILocation(line: 2719, column: 9, scope: !3303)
!3309 = !DILocation(line: 2720, column: 33, scope: !3310)
!3310 = distinct !DILexicalBlock(scope: !3306, file: !3, line: 2719, column: 27)
!3311 = !DILocation(line: 2720, column: 11, scope: !3310)
!3312 = !DILocation(line: 2721, column: 26, scope: !3310)
!3313 = !DILocation(line: 2721, column: 21, scope: !3310)
!3314 = !DILocation(line: 2721, column: 15, scope: !3310)
!3315 = !DILocation(line: 2722, column: 5, scope: !3310)
!3316 = !DILocation(line: 2723, column: 34, scope: !3317)
!3317 = distinct !DILexicalBlock(scope: !3306, file: !3, line: 2722, column: 12)
!3318 = !DILocation(line: 2723, column: 11, scope: !3317)
!3319 = !DILocation(line: 2724, column: 11, scope: !3317)
!3320 = !DILocation(line: 2724, column: 19, scope: !3317)
!3321 = !DILocation(line: 2724, column: 14, scope: !3317)
!3322 = !DILocation(line: 2728, column: 15, scope: !3323)
!3323 = distinct !DILexicalBlock(scope: !3299, file: !3, line: 2727, column: 10)
!3324 = !DILocation(line: 2728, column: 13, scope: !3323)
!3325 = !DILocation(line: 0, scope: !3299)
!3326 = !DILocation(line: 2730, column: 10, scope: !590)
!3327 = !DILocation(line: 2730, column: 3, scope: !590)
!3328 = !DILocation(line: 2731, column: 1, scope: !590)
!3329 = !DISubprogram(name: "scalbn", scope: !3330, file: !3330, line: 2, type: !3331, flags: DIFlagPrototyped, spFlags: DISPFlagOptimized)
!3330 = !DIFile(filename: "darwin_inc/math.h", directory: "/tmp/pts-h36/repro/clang_on", checksumkind: CSK_MD5, checksum: "d0fc94cedf25aaf5978ba5a6626e8a5b")
!3331 = !DISubroutineType(types: !3332)
!3332 = !{!6, !6, !15}
