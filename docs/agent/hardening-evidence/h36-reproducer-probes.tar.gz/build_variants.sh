#!/bin/bash
# Build the harness against each variant of the Math port.
#   PORT=path/to/ieee754.c (default: src/ieee754_head.c, the port at HEAD)
#   SUFFIX appended to variant names (default empty)
set -euo pipefail
cd /tmp/pts-h36/repro
PORT=${PORT:-src/ieee754_head.c}
SUFFIX=${SUFFIX:-}
PTSFLAGS="-O2 -g -fno-math-errno -falign-functions=32"   # toolchain.go flags() (release), minus -ffp-contract=off
A64="--target=aarch64-linux-gnu"

# Variant sources with a pragma inserted after the includes.
awk '{print} /#include <string.h>/ && !d {print "#pragma clang fp contract(fast)"; d=1}' "$PORT" > src/v_pragma_fast$SUFFIX.c
awk '{print} /#include <string.h>/ && !d {print "#pragma STDC FP_CONTRACT ON"; d=1}' "$PORT" > src/v_stdc_on$SUFFIX.c
grep -c "pragma clang fp contract(fast)" src/v_pragma_fast$SUFFIX.c
grep -c "pragma STDC FP_CONTRACT ON" src/v_stdc_on$SUFFIX.c

clang $A64 -Istub -O2 -c harness.c -o bin/harness_a64.o
clang -Istub -O2 -c harness.c -o bin/harness_x86.o

build_a64() { # name compiler-command...
  local name=$1; shift
  "$@" -Istub -c -o bin/$name.o
  clang $A64 bin/harness_a64.o bin/$name.o -lm -o bin/$name
  aarch64-linux-gnu-objdump -d -C --no-show-raw-insn bin/$name.o > disasm/$name.s
}

build_a64 a_clang_off$SUFFIX        clang $A64 $PTSFLAGS -ffp-contract=off "$PORT"
build_a64 b_clang_pragma_fast$SUFFIX clang $A64 $PTSFLAGS -ffp-contract=off src/v_pragma_fast$SUFFIX.c
build_a64 b2_clang_fast$SUFFIX      clang $A64 $PTSFLAGS -ffp-contract=fast "$PORT"
build_a64 c_clang_on$SUFFIX         clang $A64 $PTSFLAGS -ffp-contract=on "$PORT"
build_a64 c2_clang_stdc_on$SUFFIX   clang $A64 $PTSFLAGS -ffp-contract=off src/v_stdc_on$SUFFIX.c
build_a64 d_gcc_O2_fast$SUFFIX      aarch64-linux-gnu-gcc -O2 -g -fno-strict-aliasing -ffp-contract=fast "$PORT"
build_a64 d_gcc_O3_fast$SUFFIX      aarch64-linux-gnu-gcc -O3 -g -fno-strict-aliasing -ffp-contract=fast "$PORT"
build_a64 d_gcc_O2_off$SUFFIX       aarch64-linux-gnu-gcc -O2 -g -fno-strict-aliasing -ffp-contract=off "$PORT"

clang $PTSFLAGS -ffp-contract=off -Istub -c "$PORT" -o bin/x_clang_off$SUFFIX.o
clang bin/harness_x86.o bin/x_clang_off$SUFFIX.o -lm -o bin/x_clang_off$SUFFIX
echo built
