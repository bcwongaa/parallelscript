/*
 * site_harness INDIR BASEDIR NSITES MAXPERSITE: reads INDIR/<fn>.bin as harness.c does, writes the
 * all-fused results to BASEDIR/<fn>.bin, then for each site s < NSITES recomputes every function
 * with only site s unfused and prints, for each input whose result changes,
 *   site fn index input_bits [input2_bits] fused_bits unfused_bits
 * (at most MAXPERSITE lines per site and function), and per site a summary line
 *   # site s changes N results
 */
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pts.h"

int pts_site_disabled = -1;

typedef double (*unary)(double);
static const struct {
  const char *name;
  unary f;
} unaries[] = {
    {"acos", pts_ieee754_acos},   {"acosh", pts_ieee754_acosh}, {"asin", pts_ieee754_asin},   {"asinh", pts_ieee754_asinh},
    {"atan", pts_ieee754_atan},   {"atanh", pts_ieee754_atanh}, {"cbrt", pts_ieee754_cbrt},   {"cos", pts_ieee754_cos},
    {"cosh", pts_ieee754_cosh},   {"exp", pts_ieee754_exp},     {"expm1", pts_ieee754_expm1}, {"log", pts_ieee754_log},
    {"log10", pts_ieee754_log10}, {"log1p", pts_ieee754_log1p}, {"log2", pts_ieee754_log2},   {"sin", pts_ieee754_sin},
    {"sinh", pts_ieee754_sinh},   {"tan", pts_ieee754_tan},     {"tanh", pts_ieee754_tanh},
};
enum { NUNARY = sizeof unaries / sizeof unaries[0], NFUNC = NUNARY + 1 };

static double *read_all(const char *path, size_t *count) {
  FILE *f = fopen(path, "rb");
  if (!f) {
    perror(path);
    exit(2);
  }
  fseek(f, 0, SEEK_END);
  long size = ftell(f);
  fseek(f, 0, SEEK_SET);
  double *data = malloc((size_t)size);
  if (fread(data, 1, (size_t)size, f) != (size_t)size) {
    perror(path);
    exit(2);
  }
  fclose(f);
  *count = (size_t)size / sizeof(double);
  return data;
}

static uint64_t bits(double d) {
  uint64_t b;
  memcpy(&b, &d, sizeof b);
  return b;
}

static int same(double a, double b) { return (a != a && b != b) || bits(a) == bits(b); }

static double eval(int k, const double *x, size_t i) {
  return k < NUNARY ? unaries[k].f(x[i]) : pts_ieee754_atan2(x[2 * i], x[2 * i + 1]);
}

int main(int argc, char **argv) {
  if (argc != 5 && argc != 6) {
    fprintf(stderr, "usage: site_harness INDIR BASEDIR NSITES MAXPERSITE [SITEFUNCS]\n");
    return 2;
  }
  /* SITEFUNCS lines "site cfunction fn1,fn2,...": evaluate each site only on the functions it can reach. */
  static char reach[1024][NFUNC];
  memset(reach, 1, sizeof reach);
  if (argc == 6) {
    memset(reach, 0, sizeof reach);
    FILE *f = fopen(argv[5], "r");
    int site;
    char cfun[256], fns[1024];
    while (f && fscanf(f, "%d %255s %1023s", &site, cfun, fns) == 3) {
      for (char *tok = strtok(fns, ","); tok; tok = strtok(NULL, ",")) {
        for (int k = 0; k < NFUNC; k++) {
          if (strcmp(tok, k < NUNARY ? unaries[k].name : "atan2") == 0) {
            reach[site][k] = 1;
          }
        }
      }
    }
  }
  int nsites = atoi(argv[3]), maxper = atoi(argv[4]);
  double *in[NFUNC], *base[NFUNC];
  size_t n[NFUNC];
  char path[4096];
  for (int k = 0; k < NFUNC; k++) {
    const char *name = k < NUNARY ? unaries[k].name : "atan2";
    snprintf(path, sizeof path, "%s/%s.bin", argv[1], name);
    size_t count;
    in[k] = read_all(path, &count);
    n[k] = k < NUNARY ? count : count / 2;
    base[k] = malloc(n[k] * sizeof(double));
    pts_site_disabled = -1;
    for (size_t i = 0; i < n[k]; i++) {
      base[k][i] = eval(k, in[k], i);
    }
    snprintf(path, sizeof path, "%s/%s.bin", argv[2], name);
    FILE *f = fopen(path, "wb");
    fwrite(base[k], sizeof(double), n[k], f);
    fclose(f);
  }
  for (int s = 0; s < nsites; s++) {
    pts_site_disabled = s;
    long total = 0;
    for (int k = 0; k < NFUNC; k++) {
      if (!reach[s][k]) {
        continue;
      }
      const char *name = k < NUNARY ? unaries[k].name : "atan2";
      int shown = 0;
      for (size_t i = 0; i < n[k]; i++) {
        double r = eval(k, in[k], i);
        if (!same(r, base[k][i])) {
          total++;
          if (shown++ < maxper) {
            if (k < NUNARY) {
              printf("%d %s %zu %016" PRIx64 " %016" PRIx64 " %016" PRIx64 "\n", s, name, i, bits(in[k][i]), bits(base[k][i]), bits(r));
            } else {
              printf("%d %s %zu %016" PRIx64 ",%016" PRIx64 " %016" PRIx64 " %016" PRIx64 "\n", s, name, i, bits(in[k][2 * i]),
                     bits(in[k][2 * i + 1]), bits(base[k][i]), bits(r));
            }
          }
        }
      }
    }
    printf("# site %d changes %ld results\n", s, total);
    fflush(stdout);
  }
  return 0;
}
