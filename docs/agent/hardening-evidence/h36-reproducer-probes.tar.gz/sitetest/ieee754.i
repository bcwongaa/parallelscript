# 1 "ieee754.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 389 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "ieee754.c" 2
# 48 "ieee754.c"
# 1 "../stub/pts.h" 1

double pts_ieee754_acos(double x);
double pts_ieee754_acosh(double x);
double pts_ieee754_asin(double x);
double pts_ieee754_asinh(double x);
double pts_ieee754_atan(double x);
double pts_ieee754_atan2(double y, double x);
double pts_ieee754_atanh(double x);
double pts_ieee754_cbrt(double x);
double pts_ieee754_cos(double x);
double pts_ieee754_cosh(double x);
double pts_ieee754_exp(double x);
double pts_ieee754_expm1(double x);
double pts_ieee754_log(double x);
double pts_ieee754_log10(double x);
double pts_ieee754_log1p(double x);
double pts_ieee754_log2(double x);
double pts_ieee754_sin(double x);
double pts_ieee754_sinh(double x);
double pts_ieee754_tan(double x);
double pts_ieee754_tanh(double x);
# 49 "ieee754.c" 2
# 1 "./v8_fma_internal.h" 1




extern int pts_site_disabled;
static inline double pts_site_fma(int id, double a, double b, double c) {
  return id == pts_site_disabled ? a * b + c : __builtin_fma(a, b, c);
}
# 50 "ieee754.c" 2

# 1 "/usr/include/math.h" 1 3 4
# 27 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 33 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 3 4
# 1 "/usr/include/features.h" 1 3 4
# 394 "/usr/include/features.h" 3 4
# 1 "/usr/include/features-time64.h" 1 3 4
# 20 "/usr/include/features-time64.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 21 "/usr/include/features-time64.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 22 "/usr/include/features-time64.h" 2 3 4
# 395 "/usr/include/features.h" 2 3 4
# 480 "/usr/include/features.h" 3 4
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 481 "/usr/include/features.h" 2 3 4
# 502 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 1 3 4
# 576 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 577 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 578 "/usr/include/x86_64-linux-gnu/sys/cdefs.h" 2 3 4
# 503 "/usr/include/features.h" 2 3 4
# 526 "/usr/include/features.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 1 3 4
# 10 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/gnu/stubs-64.h" 1 3 4
# 11 "/usr/include/x86_64-linux-gnu/gnu/stubs.h" 2 3 4
# 527 "/usr/include/features.h" 2 3 4
# 34 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 2 3 4
# 28 "/usr/include/math.h" 2 3 4
# 37 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 28 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 1 3 4
# 19 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/timesize.h" 2 3 4
# 29 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned char __u_char;
typedef unsigned short int __u_short;
typedef unsigned int __u_int;
typedef unsigned long int __u_long;


typedef signed char __int8_t;
typedef unsigned char __uint8_t;
typedef signed short int __int16_t;
typedef unsigned short int __uint16_t;
typedef signed int __int32_t;
typedef unsigned int __uint32_t;

typedef signed long int __int64_t;
typedef unsigned long int __uint64_t;






typedef __int8_t __int_least8_t;
typedef __uint8_t __uint_least8_t;
typedef __int16_t __int_least16_t;
typedef __uint16_t __uint_least16_t;
typedef __int32_t __int_least32_t;
typedef __uint32_t __uint_least32_t;
typedef __int64_t __int_least64_t;
typedef __uint64_t __uint_least64_t;



typedef long int __quad_t;
typedef unsigned long int __u_quad_t;







typedef long int __intmax_t;
typedef unsigned long int __uintmax_t;
# 141 "/usr/include/x86_64-linux-gnu/bits/types.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/typesizes.h" 1 3 4
# 142 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/time64.h" 1 3 4
# 143 "/usr/include/x86_64-linux-gnu/bits/types.h" 2 3 4


typedef unsigned long int __dev_t;
typedef unsigned int __uid_t;
typedef unsigned int __gid_t;
typedef unsigned long int __ino_t;
typedef unsigned long int __ino64_t;
typedef unsigned int __mode_t;
typedef unsigned long int __nlink_t;
typedef long int __off_t;
typedef long int __off64_t;
typedef int __pid_t;
typedef struct { int __val[2]; } __fsid_t;
typedef long int __clock_t;
typedef unsigned long int __rlim_t;
typedef unsigned long int __rlim64_t;
typedef unsigned int __id_t;
typedef long int __time_t;
typedef unsigned int __useconds_t;
typedef long int __suseconds_t;
typedef long int __suseconds64_t;

typedef int __daddr_t;
typedef int __key_t;


typedef int __clockid_t;


typedef void * __timer_t;


typedef long int __blksize_t;




typedef long int __blkcnt_t;
typedef long int __blkcnt64_t;


typedef unsigned long int __fsblkcnt_t;
typedef unsigned long int __fsblkcnt64_t;


typedef unsigned long int __fsfilcnt_t;
typedef unsigned long int __fsfilcnt64_t;


typedef long int __fsword_t;

typedef long int __ssize_t;


typedef long int __syscall_slong_t;

typedef unsigned long int __syscall_ulong_t;



typedef __off64_t __loff_t;
typedef char *__caddr_t;


typedef long int __intptr_t;


typedef unsigned int __socklen_t;




typedef int __sig_atomic_t;
# 38 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libm-simd-decl-stubs.h" 1 3 4
# 26 "/usr/include/x86_64-linux-gnu/bits/math-vector.h" 2 3 4
# 41 "/usr/include/math.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 1 3 4
# 119 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/long-double.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 2 3 4
# 214 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef float _Float32;
# 251 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float64;
# 268 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef double _Float32x;
# 285 "/usr/include/x86_64-linux-gnu/bits/floatn-common.h" 3 4
typedef long double _Float64x;
# 120 "/usr/include/x86_64-linux-gnu/bits/floatn.h" 2 3 4
# 44 "/usr/include/math.h" 2 3 4
# 152 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/flt-eval-method.h" 1 3 4
# 153 "/usr/include/math.h" 2 3 4
# 163 "/usr/include/math.h" 3 4
typedef float float_t;
typedef double double_t;
# 204 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-logb.h" 1 3 4
# 205 "/usr/include/math.h" 2 3 4
# 247 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/fp-fast.h" 1 3 4
# 248 "/usr/include/math.h" 2 3 4
# 312 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassify (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbit (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinf (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finite (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnan (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsig (double __x, double __y) __attribute__ ((__nothrow__ ));


extern int __issignaling (double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 313 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acos (double __x) __attribute__ ((__nothrow__ )); extern double __acos (double __x) __attribute__ ((__nothrow__ ));

 extern double asin (double __x) __attribute__ ((__nothrow__ )); extern double __asin (double __x) __attribute__ ((__nothrow__ ));

 extern double atan (double __x) __attribute__ ((__nothrow__ )); extern double __atan (double __x) __attribute__ ((__nothrow__ ));

 extern double atan2 (double __y, double __x) __attribute__ ((__nothrow__ )); extern double __atan2 (double __y, double __x) __attribute__ ((__nothrow__ ));


 extern double cos (double __x) __attribute__ ((__nothrow__ )); extern double __cos (double __x) __attribute__ ((__nothrow__ ));

 extern double sin (double __x) __attribute__ ((__nothrow__ )); extern double __sin (double __x) __attribute__ ((__nothrow__ ));

 extern double tan (double __x) __attribute__ ((__nothrow__ )); extern double __tan (double __x) __attribute__ ((__nothrow__ ));




 extern double cosh (double __x) __attribute__ ((__nothrow__ )); extern double __cosh (double __x) __attribute__ ((__nothrow__ ));

 extern double sinh (double __x) __attribute__ ((__nothrow__ )); extern double __sinh (double __x) __attribute__ ((__nothrow__ ));

 extern double tanh (double __x) __attribute__ ((__nothrow__ )); extern double __tanh (double __x) __attribute__ ((__nothrow__ ));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double acosh (double __x) __attribute__ ((__nothrow__ )); extern double __acosh (double __x) __attribute__ ((__nothrow__ ));

 extern double asinh (double __x) __attribute__ ((__nothrow__ )); extern double __asinh (double __x) __attribute__ ((__nothrow__ ));

 extern double atanh (double __x) __attribute__ ((__nothrow__ )); extern double __atanh (double __x) __attribute__ ((__nothrow__ ));





 extern double exp (double __x) __attribute__ ((__nothrow__ )); extern double __exp (double __x) __attribute__ ((__nothrow__ ));


extern double frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern double __frexp (double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern double ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ )); extern double __ldexp (double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern double log (double __x) __attribute__ ((__nothrow__ )); extern double __log (double __x) __attribute__ ((__nothrow__ ));


 extern double log10 (double __x) __attribute__ ((__nothrow__ )); extern double __log10 (double __x) __attribute__ ((__nothrow__ ));


extern double modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )); extern double __modf (double __x, double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern double expm1 (double __x) __attribute__ ((__nothrow__ )); extern double __expm1 (double __x) __attribute__ ((__nothrow__ ));


 extern double log1p (double __x) __attribute__ ((__nothrow__ )); extern double __log1p (double __x) __attribute__ ((__nothrow__ ));


extern double logb (double __x) __attribute__ ((__nothrow__ )); extern double __logb (double __x) __attribute__ ((__nothrow__ ));




 extern double exp2 (double __x) __attribute__ ((__nothrow__ )); extern double __exp2 (double __x) __attribute__ ((__nothrow__ ));


 extern double log2 (double __x) __attribute__ ((__nothrow__ )); extern double __log2 (double __x) __attribute__ ((__nothrow__ ));






 extern double pow (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __pow (double __x, double __y) __attribute__ ((__nothrow__ ));


extern double sqrt (double __x) __attribute__ ((__nothrow__ )); extern double __sqrt (double __x) __attribute__ ((__nothrow__ ));



 extern double hypot (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __hypot (double __x, double __y) __attribute__ ((__nothrow__ ));




 extern double cbrt (double __x) __attribute__ ((__nothrow__ )); extern double __cbrt (double __x) __attribute__ ((__nothrow__ ));






extern double ceil (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __ceil (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fabs (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __fabs (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double floor (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __floor (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmod (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fmod (double __x, double __y) __attribute__ ((__nothrow__ ));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinf (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));




extern int finite (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern double drem (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __drem (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double significand (double __x) __attribute__ ((__nothrow__ )); extern double __significand (double __x) __attribute__ ((__nothrow__ ));






extern double copysign (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __copysign (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double nan (const char *__tagb) __attribute__ ((__nothrow__ )); extern double __nan (const char *__tagb) __attribute__ ((__nothrow__ ));
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnan (double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));





extern double j0 (double) __attribute__ ((__nothrow__ )); extern double __j0 (double) __attribute__ ((__nothrow__ ));
extern double j1 (double) __attribute__ ((__nothrow__ )); extern double __j1 (double) __attribute__ ((__nothrow__ ));
extern double jn (int, double) __attribute__ ((__nothrow__ )); extern double __jn (int, double) __attribute__ ((__nothrow__ ));
extern double y0 (double) __attribute__ ((__nothrow__ )); extern double __y0 (double) __attribute__ ((__nothrow__ ));
extern double y1 (double) __attribute__ ((__nothrow__ )); extern double __y1 (double) __attribute__ ((__nothrow__ ));
extern double yn (int, double) __attribute__ ((__nothrow__ )); extern double __yn (int, double) __attribute__ ((__nothrow__ ));





 extern double erf (double) __attribute__ ((__nothrow__ )); extern double __erf (double) __attribute__ ((__nothrow__ ));
 extern double erfc (double) __attribute__ ((__nothrow__ )); extern double __erfc (double) __attribute__ ((__nothrow__ ));
extern double lgamma (double) __attribute__ ((__nothrow__ )); extern double __lgamma (double) __attribute__ ((__nothrow__ ));




extern double tgamma (double) __attribute__ ((__nothrow__ )); extern double __tgamma (double) __attribute__ ((__nothrow__ ));





extern double gamma (double) __attribute__ ((__nothrow__ )); extern double __gamma (double) __attribute__ ((__nothrow__ ));







extern double lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__ )); extern double __lgamma_r (double, int *__signgamp) __attribute__ ((__nothrow__ ));






extern double rint (double __x) __attribute__ ((__nothrow__ )); extern double __rint (double __x) __attribute__ ((__nothrow__ ));


extern double nextafter (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __nextafter (double __x, double __y) __attribute__ ((__nothrow__ ));

extern double nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ )); extern double __nexttoward (double __x, long double __y) __attribute__ ((__nothrow__ ));
# 275 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double remainder (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __remainder (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double scalbn (double __x, int __n) __attribute__ ((__nothrow__ )); extern double __scalbn (double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogb (double __x) __attribute__ ((__nothrow__ )); extern int __ilogb (double __x) __attribute__ ((__nothrow__ ));
# 293 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalbln (double __x, long int __n) __attribute__ ((__nothrow__ )); extern double __scalbln (double __x, long int __n) __attribute__ ((__nothrow__ ));



extern double nearbyint (double __x) __attribute__ ((__nothrow__ )); extern double __nearbyint (double __x) __attribute__ ((__nothrow__ ));



extern double round (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __round (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double trunc (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __trunc (double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern double remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ )); extern double __remquo (double __x, double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrint (double __x) __attribute__ ((__nothrow__ )); extern long int __lrint (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrint (double __x) __attribute__ ((__nothrow__ )); extern long long int __llrint (double __x) __attribute__ ((__nothrow__ ));



extern long int lround (double __x) __attribute__ ((__nothrow__ )); extern long int __lround (double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llround (double __x) __attribute__ ((__nothrow__ )); extern long long int __llround (double __x) __attribute__ ((__nothrow__ ));



extern double fdim (double __x, double __y) __attribute__ ((__nothrow__ )); extern double __fdim (double __x, double __y) __attribute__ ((__nothrow__ ));



extern double fmax (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __fmax (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern double fmin (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern double __fmin (double __x, double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern double fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ )); extern double __fma (double __x, double __y, double __z) __attribute__ ((__nothrow__ ));
# 435 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern double scalb (double __x, double __n) __attribute__ ((__nothrow__ )); extern double __scalb (double __x, double __n) __attribute__ ((__nothrow__ ));
# 314 "/usr/include/math.h" 2 3 4
# 329 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinff (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitef (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanf (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern int __issignalingf (float __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 330 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acosf (float __x) __attribute__ ((__nothrow__ )); extern float __acosf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinf (float __x) __attribute__ ((__nothrow__ )); extern float __asinf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanf (float __x) __attribute__ ((__nothrow__ )); extern float __atanf (float __x) __attribute__ ((__nothrow__ ));

 extern float atan2f (float __y, float __x) __attribute__ ((__nothrow__ )); extern float __atan2f (float __y, float __x) __attribute__ ((__nothrow__ ));


 extern float cosf (float __x) __attribute__ ((__nothrow__ )); extern float __cosf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinf (float __x) __attribute__ ((__nothrow__ )); extern float __sinf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanf (float __x) __attribute__ ((__nothrow__ )); extern float __tanf (float __x) __attribute__ ((__nothrow__ ));




 extern float coshf (float __x) __attribute__ ((__nothrow__ )); extern float __coshf (float __x) __attribute__ ((__nothrow__ ));

 extern float sinhf (float __x) __attribute__ ((__nothrow__ )); extern float __sinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float tanhf (float __x) __attribute__ ((__nothrow__ )); extern float __tanhf (float __x) __attribute__ ((__nothrow__ ));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float acoshf (float __x) __attribute__ ((__nothrow__ )); extern float __acoshf (float __x) __attribute__ ((__nothrow__ ));

 extern float asinhf (float __x) __attribute__ ((__nothrow__ )); extern float __asinhf (float __x) __attribute__ ((__nothrow__ ));

 extern float atanhf (float __x) __attribute__ ((__nothrow__ )); extern float __atanhf (float __x) __attribute__ ((__nothrow__ ));





 extern float expf (float __x) __attribute__ ((__nothrow__ )); extern float __expf (float __x) __attribute__ ((__nothrow__ ));


extern float frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ )); extern float __frexpf (float __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern float ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ )); extern float __ldexpf (float __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern float logf (float __x) __attribute__ ((__nothrow__ )); extern float __logf (float __x) __attribute__ ((__nothrow__ ));


 extern float log10f (float __x) __attribute__ ((__nothrow__ )); extern float __log10f (float __x) __attribute__ ((__nothrow__ ));


extern float modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )); extern float __modff (float __x, float *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern float expm1f (float __x) __attribute__ ((__nothrow__ )); extern float __expm1f (float __x) __attribute__ ((__nothrow__ ));


 extern float log1pf (float __x) __attribute__ ((__nothrow__ )); extern float __log1pf (float __x) __attribute__ ((__nothrow__ ));


extern float logbf (float __x) __attribute__ ((__nothrow__ )); extern float __logbf (float __x) __attribute__ ((__nothrow__ ));




 extern float exp2f (float __x) __attribute__ ((__nothrow__ )); extern float __exp2f (float __x) __attribute__ ((__nothrow__ ));


 extern float log2f (float __x) __attribute__ ((__nothrow__ )); extern float __log2f (float __x) __attribute__ ((__nothrow__ ));






 extern float powf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __powf (float __x, float __y) __attribute__ ((__nothrow__ ));


extern float sqrtf (float __x) __attribute__ ((__nothrow__ )); extern float __sqrtf (float __x) __attribute__ ((__nothrow__ ));



 extern float hypotf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __hypotf (float __x, float __y) __attribute__ ((__nothrow__ ));




 extern float cbrtf (float __x) __attribute__ ((__nothrow__ )); extern float __cbrtf (float __x) __attribute__ ((__nothrow__ ));






extern float ceilf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __ceilf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fabsf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __fabsf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float floorf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __floorf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fmodf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fmodf (float __x, float __y) __attribute__ ((__nothrow__ ));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinff (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));




extern int finitef (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern float dremf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __dremf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float significandf (float __x) __attribute__ ((__nothrow__ )); extern float __significandf (float __x) __attribute__ ((__nothrow__ ));






extern float copysignf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __copysignf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float nanf (const char *__tagb) __attribute__ ((__nothrow__ )); extern float __nanf (const char *__tagb) __attribute__ ((__nothrow__ ));
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnanf (float __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));





extern float j0f (float) __attribute__ ((__nothrow__ )); extern float __j0f (float) __attribute__ ((__nothrow__ ));
extern float j1f (float) __attribute__ ((__nothrow__ )); extern float __j1f (float) __attribute__ ((__nothrow__ ));
extern float jnf (int, float) __attribute__ ((__nothrow__ )); extern float __jnf (int, float) __attribute__ ((__nothrow__ ));
extern float y0f (float) __attribute__ ((__nothrow__ )); extern float __y0f (float) __attribute__ ((__nothrow__ ));
extern float y1f (float) __attribute__ ((__nothrow__ )); extern float __y1f (float) __attribute__ ((__nothrow__ ));
extern float ynf (int, float) __attribute__ ((__nothrow__ )); extern float __ynf (int, float) __attribute__ ((__nothrow__ ));





 extern float erff (float) __attribute__ ((__nothrow__ )); extern float __erff (float) __attribute__ ((__nothrow__ ));
 extern float erfcf (float) __attribute__ ((__nothrow__ )); extern float __erfcf (float) __attribute__ ((__nothrow__ ));
extern float lgammaf (float) __attribute__ ((__nothrow__ )); extern float __lgammaf (float) __attribute__ ((__nothrow__ ));




extern float tgammaf (float) __attribute__ ((__nothrow__ )); extern float __tgammaf (float) __attribute__ ((__nothrow__ ));





extern float gammaf (float) __attribute__ ((__nothrow__ )); extern float __gammaf (float) __attribute__ ((__nothrow__ ));







extern float lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__ )); extern float __lgammaf_r (float, int *__signgamp) __attribute__ ((__nothrow__ ));






extern float rintf (float __x) __attribute__ ((__nothrow__ )); extern float __rintf (float __x) __attribute__ ((__nothrow__ ));


extern float nextafterf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __nextafterf (float __x, float __y) __attribute__ ((__nothrow__ ));

extern float nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ )); extern float __nexttowardf (float __x, long double __y) __attribute__ ((__nothrow__ ));
# 275 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float remainderf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __remainderf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float scalbnf (float __x, int __n) __attribute__ ((__nothrow__ )); extern float __scalbnf (float __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbf (float __x) __attribute__ ((__nothrow__ )); extern int __ilogbf (float __x) __attribute__ ((__nothrow__ ));
# 293 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ )); extern float __scalblnf (float __x, long int __n) __attribute__ ((__nothrow__ ));



extern float nearbyintf (float __x) __attribute__ ((__nothrow__ )); extern float __nearbyintf (float __x) __attribute__ ((__nothrow__ ));



extern float roundf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __roundf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float truncf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __truncf (float __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern float remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ )); extern float __remquof (float __x, float __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintf (float __x) __attribute__ ((__nothrow__ )); extern long int __lrintf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llrintf (float __x) __attribute__ ((__nothrow__ ));



extern long int lroundf (float __x) __attribute__ ((__nothrow__ )); extern long int __lroundf (float __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundf (float __x) __attribute__ ((__nothrow__ )); extern long long int __llroundf (float __x) __attribute__ ((__nothrow__ ));



extern float fdimf (float __x, float __y) __attribute__ ((__nothrow__ )); extern float __fdimf (float __x, float __y) __attribute__ ((__nothrow__ ));



extern float fmaxf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __fmaxf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern float fminf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern float __fminf (float __x, float __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern float fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ )); extern float __fmaf (float __x, float __y, float __z) __attribute__ ((__nothrow__ ));
# 435 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern float scalbf (float __x, float __n) __attribute__ ((__nothrow__ )); extern float __scalbf (float __x, float __n) __attribute__ ((__nothrow__ ));
# 331 "/usr/include/math.h" 2 3 4
# 398 "/usr/include/math.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 1 3 4
# 20 "/usr/include/x86_64-linux-gnu/bits/mathcalls-helper-functions.h" 3 4
extern int __fpclassifyl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));


extern int __signbitl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));



extern int __isinfl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __finitel (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __isnanl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern int __iseqsigl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern int __issignalingl (long double __value) __attribute__ ((__nothrow__ ))
     __attribute__ ((__const__));
# 399 "/usr/include/math.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 1 3 4
# 53 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ )); extern long double __atan2l (long double __y, long double __x) __attribute__ ((__nothrow__ ));


 extern long double cosl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cosl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanl (long double __x) __attribute__ ((__nothrow__ ));




 extern long double coshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __coshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double sinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double tanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __tanhl (long double __x) __attribute__ ((__nothrow__ ));
# 85 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double acoshl (long double __x) __attribute__ ((__nothrow__ )); extern long double __acoshl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double asinhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __asinhl (long double __x) __attribute__ ((__nothrow__ ));

 extern long double atanhl (long double __x) __attribute__ ((__nothrow__ )); extern long double __atanhl (long double __x) __attribute__ ((__nothrow__ ));





 extern long double expl (long double __x) __attribute__ ((__nothrow__ )); extern long double __expl (long double __x) __attribute__ ((__nothrow__ ));


extern long double frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ )); extern long double __frexpl (long double __x, int *__exponent) __attribute__ ((__nothrow__ ));


extern long double ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ )); extern long double __ldexpl (long double __x, int __exponent) __attribute__ ((__nothrow__ ));


 extern long double logl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logl (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log10l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log10l (long double __x) __attribute__ ((__nothrow__ ));


extern long double modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )); extern long double __modfl (long double __x, long double *__iptr) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));
# 119 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
 extern long double expm1l (long double __x) __attribute__ ((__nothrow__ )); extern long double __expm1l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log1pl (long double __x) __attribute__ ((__nothrow__ )); extern long double __log1pl (long double __x) __attribute__ ((__nothrow__ ));


extern long double logbl (long double __x) __attribute__ ((__nothrow__ )); extern long double __logbl (long double __x) __attribute__ ((__nothrow__ ));




 extern long double exp2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __exp2l (long double __x) __attribute__ ((__nothrow__ ));


 extern long double log2l (long double __x) __attribute__ ((__nothrow__ )); extern long double __log2l (long double __x) __attribute__ ((__nothrow__ ));






 extern long double powl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __powl (long double __x, long double __y) __attribute__ ((__nothrow__ ));


extern long double sqrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __sqrtl (long double __x) __attribute__ ((__nothrow__ ));



 extern long double hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __hypotl (long double __x, long double __y) __attribute__ ((__nothrow__ ));




 extern long double cbrtl (long double __x) __attribute__ ((__nothrow__ )); extern long double __cbrtl (long double __x) __attribute__ ((__nothrow__ ));






extern long double ceill (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __ceill (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fabsl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __fabsl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double floorl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __floorl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fmodl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 177 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isinfl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));




extern int finitel (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));


extern long double dreml (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __dreml (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double significandl (long double __x) __attribute__ ((__nothrow__ )); extern long double __significandl (long double __x) __attribute__ ((__nothrow__ ));






extern long double copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __copysignl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double nanl (const char *__tagb) __attribute__ ((__nothrow__ )); extern long double __nanl (const char *__tagb) __attribute__ ((__nothrow__ ));
# 213 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern int isnanl (long double __value) __attribute__ ((__nothrow__ ))
  __attribute__ ((__const__));





extern long double j0l (long double) __attribute__ ((__nothrow__ )); extern long double __j0l (long double) __attribute__ ((__nothrow__ ));
extern long double j1l (long double) __attribute__ ((__nothrow__ )); extern long double __j1l (long double) __attribute__ ((__nothrow__ ));
extern long double jnl (int, long double) __attribute__ ((__nothrow__ )); extern long double __jnl (int, long double) __attribute__ ((__nothrow__ ));
extern long double y0l (long double) __attribute__ ((__nothrow__ )); extern long double __y0l (long double) __attribute__ ((__nothrow__ ));
extern long double y1l (long double) __attribute__ ((__nothrow__ )); extern long double __y1l (long double) __attribute__ ((__nothrow__ ));
extern long double ynl (int, long double) __attribute__ ((__nothrow__ )); extern long double __ynl (int, long double) __attribute__ ((__nothrow__ ));





 extern long double erfl (long double) __attribute__ ((__nothrow__ )); extern long double __erfl (long double) __attribute__ ((__nothrow__ ));
 extern long double erfcl (long double) __attribute__ ((__nothrow__ )); extern long double __erfcl (long double) __attribute__ ((__nothrow__ ));
extern long double lgammal (long double) __attribute__ ((__nothrow__ )); extern long double __lgammal (long double) __attribute__ ((__nothrow__ ));




extern long double tgammal (long double) __attribute__ ((__nothrow__ )); extern long double __tgammal (long double) __attribute__ ((__nothrow__ ));





extern long double gammal (long double) __attribute__ ((__nothrow__ )); extern long double __gammal (long double) __attribute__ ((__nothrow__ ));







extern long double lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__ )); extern long double __lgammal_r (long double, int *__signgamp) __attribute__ ((__nothrow__ ));






extern long double rintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __rintl (long double __x) __attribute__ ((__nothrow__ ));


extern long double nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nextafterl (long double __x, long double __y) __attribute__ ((__nothrow__ ));

extern long double nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __nexttowardl (long double __x, long double __y) __attribute__ ((__nothrow__ ));
# 275 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __remainderl (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ )); extern long double __scalbnl (long double __x, int __n) __attribute__ ((__nothrow__ ));



extern int ilogbl (long double __x) __attribute__ ((__nothrow__ )); extern int __ilogbl (long double __x) __attribute__ ((__nothrow__ ));
# 293 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ )); extern long double __scalblnl (long double __x, long int __n) __attribute__ ((__nothrow__ ));



extern long double nearbyintl (long double __x) __attribute__ ((__nothrow__ )); extern long double __nearbyintl (long double __x) __attribute__ ((__nothrow__ ));



extern long double roundl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __roundl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double truncl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __truncl (long double __x) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));




extern long double remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ )); extern long double __remquol (long double __x, long double __y, int *__quo) __attribute__ ((__nothrow__ ));






extern long int lrintl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lrintl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llrintl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llrintl (long double __x) __attribute__ ((__nothrow__ ));



extern long int lroundl (long double __x) __attribute__ ((__nothrow__ )); extern long int __lroundl (long double __x) __attribute__ ((__nothrow__ ));
__extension__
extern long long int llroundl (long double __x) __attribute__ ((__nothrow__ )); extern long long int __llroundl (long double __x) __attribute__ ((__nothrow__ ));



extern long double fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ )); extern long double __fdiml (long double __x, long double __y) __attribute__ ((__nothrow__ ));



extern long double fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __fmaxl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));


extern long double fminl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__)); extern long double __fminl (long double __x, long double __y) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern long double fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ )); extern long double __fmal (long double __x, long double __y, long double __z) __attribute__ ((__nothrow__ ));
# 435 "/usr/include/x86_64-linux-gnu/bits/mathcalls.h" 3 4
extern long double scalbl (long double __x, long double __n) __attribute__ ((__nothrow__ )); extern long double __scalbl (long double __x, long double __n) __attribute__ ((__nothrow__ ));
# 400 "/usr/include/math.h" 2 3 4
# 854 "/usr/include/math.h" 3 4
extern int signgam;
# 934 "/usr/include/math.h" 3 4
enum
  {
    FP_NAN =

      0,
    FP_INFINITE =

      1,
    FP_ZERO =

      2,
    FP_SUBNORMAL =

      3,
    FP_NORMAL =

      4
  };
# 52 "ieee754.c" 2
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 1 3
# 52 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 3
# 1 "/usr/include/stdint.h" 1 3 4
# 26 "/usr/include/stdint.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/stdint.h" 2 3 4

# 1 "/usr/include/x86_64-linux-gnu/bits/wchar.h" 1 3 4
# 29 "/usr/include/stdint.h" 2 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/wordsize.h" 1 3 4
# 30 "/usr/include/stdint.h" 2 3 4




# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-intn.h" 3 4
typedef __int8_t int8_t;
typedef __int16_t int16_t;
typedef __int32_t int32_t;
typedef __int64_t int64_t;
# 35 "/usr/include/stdint.h" 2 3 4


# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 1 3 4
# 24 "/usr/include/x86_64-linux-gnu/bits/stdint-uintn.h" 3 4
typedef __uint8_t uint8_t;
typedef __uint16_t uint16_t;
typedef __uint32_t uint32_t;
typedef __uint64_t uint64_t;
# 38 "/usr/include/stdint.h" 2 3 4



# 1 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 1 3 4
# 25 "/usr/include/x86_64-linux-gnu/bits/stdint-least.h" 3 4
typedef __int_least8_t int_least8_t;
typedef __int_least16_t int_least16_t;
typedef __int_least32_t int_least32_t;
typedef __int_least64_t int_least64_t;


typedef __uint_least8_t uint_least8_t;
typedef __uint_least16_t uint_least16_t;
typedef __uint_least32_t uint_least32_t;
typedef __uint_least64_t uint_least64_t;
# 42 "/usr/include/stdint.h" 2 3 4





typedef signed char int_fast8_t;

typedef long int int_fast16_t;
typedef long int int_fast32_t;
typedef long int int_fast64_t;
# 60 "/usr/include/stdint.h" 3 4
typedef unsigned char uint_fast8_t;

typedef unsigned long int uint_fast16_t;
typedef unsigned long int uint_fast32_t;
typedef unsigned long int uint_fast64_t;
# 76 "/usr/include/stdint.h" 3 4
typedef long int intptr_t;


typedef unsigned long int uintptr_t;
# 90 "/usr/include/stdint.h" 3 4
typedef __intmax_t intmax_t;
typedef __uintmax_t uintmax_t;
# 53 "/usr/lib/llvm-18/lib/clang/18/include/stdint.h" 2 3
# 53 "ieee754.c" 2
# 1 "/usr/include/string.h" 1 3 4
# 26 "/usr/include/string.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/libc-header-start.h" 1 3 4
# 27 "/usr/include/string.h" 2 3 4






# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 18 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 3 4
typedef long unsigned int size_t;
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 92 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_null.h" 1 3 4
# 93 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 34 "/usr/include/string.h" 2 3 4
# 43 "/usr/include/string.h" 3 4
extern void *memcpy (void *__restrict __dest, const void *__restrict __src,
       size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void *memmove (void *__dest, const void *__src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));





extern void *memccpy (void *__restrict __dest, const void *__restrict __src,
        int __c, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;




extern void *memset (void *__s, int __c, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));


extern int memcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 80 "/usr/include/string.h" 3 4
extern int __memcmpeq (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 107 "/usr/include/string.h" 3 4
extern void *memchr (const void *__s, int __c, size_t __n)
      __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 141 "/usr/include/string.h" 3 4
extern char *strcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern char *strcat (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));

extern char *strncat (char *__restrict __dest, const char *__restrict __src,
        size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern int strcmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern int strncmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strcoll (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));

extern size_t strxfrm (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
    __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2))) ;



# 1 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 1 3 4
# 22 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 3 4
# 1 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 1 3 4
# 27 "/usr/include/x86_64-linux-gnu/bits/types/__locale_t.h" 3 4
struct __locale_struct
{

  struct __locale_data *__locales[13];


  const unsigned short int *__ctype_b;
  const int *__ctype_tolower;
  const int *__ctype_toupper;


  const char *__names[13];
};

typedef struct __locale_struct *__locale_t;
# 23 "/usr/include/x86_64-linux-gnu/bits/types/locale_t.h" 2 3 4

typedef __locale_t locale_t;
# 173 "/usr/include/string.h" 2 3 4


extern int strcoll_l (const char *__s1, const char *__s2, locale_t __l)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));


extern size_t strxfrm_l (char *__dest, const char *__src, size_t __n,
    locale_t __l) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 4)))
                                           ;





extern char *strdup (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));






extern char *strndup (const char *__string, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__malloc__)) __attribute__ ((__nonnull__ (1)));
# 246 "/usr/include/string.h" 3 4
extern char *strchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 273 "/usr/include/string.h" 3 4
extern char *strrchr (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 286 "/usr/include/string.h" 3 4
extern char *strchrnul (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));





extern size_t strcspn (const char *__s, const char *__reject)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern size_t strspn (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 323 "/usr/include/string.h" 3 4
extern char *strpbrk (const char *__s, const char *__accept)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));
# 350 "/usr/include/string.h" 3 4
extern char *strstr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));




extern char *strtok (char *__restrict __s, const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)));



extern char *__strtok_r (char *__restrict __s,
    const char *__restrict __delim,
    char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));

extern char *strtok_r (char *__restrict __s, const char *__restrict __delim,
         char **__restrict __save_ptr)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2, 3)));
# 380 "/usr/include/string.h" 3 4
extern char *strcasestr (const char *__haystack, const char *__needle)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));







extern void *memmem (const void *__haystack, size_t __haystacklen,
       const void *__needle, size_t __needlelen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 3)))

                                         ;



extern void *__mempcpy (void *__restrict __dest,
   const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern void *mempcpy (void *__restrict __dest,
        const void *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlen (const char *__s)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern size_t strnlen (const char *__string, size_t __maxlen)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));




extern char *strerror (int __errnum) __attribute__ ((__nothrow__ ));
# 432 "/usr/include/string.h" 3 4
extern int strerror_r (int __errnum, char *__buf, size_t __buflen) __asm__ ("" "__xpg_strerror_r") __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (2)))


                                          ;
# 458 "/usr/include/string.h" 3 4
extern char *strerror_l (int __errnum, locale_t __l) __attribute__ ((__nothrow__ ));



# 1 "/usr/include/strings.h" 1 3 4
# 23 "/usr/include/strings.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 1 3 4
# 77 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 3 4
# 1 "/usr/lib/llvm-18/lib/clang/18/include/__stddef_size_t.h" 1 3 4
# 78 "/usr/lib/llvm-18/lib/clang/18/include/stddef.h" 2 3 4
# 24 "/usr/include/strings.h" 2 3 4
# 34 "/usr/include/strings.h" 3 4
extern int bcmp (const void *__s1, const void *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern void bcopy (const void *__src, void *__dest, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));


extern void bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)));
# 68 "/usr/include/strings.h" 3 4
extern char *index (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));
# 96 "/usr/include/strings.h" 3 4
extern char *rindex (const char *__s, int __c)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1)));






extern int ffs (int __i) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));





extern int ffsl (long int __l) __attribute__ ((__nothrow__ )) __attribute__ ((__const__));
__extension__ extern int ffsll (long long int __ll)
     __attribute__ ((__nothrow__ )) __attribute__ ((__const__));



extern int strcasecmp (const char *__s1, const char *__s2)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));


extern int strncasecmp (const char *__s1, const char *__s2, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2)));






extern int strcasecmp_l (const char *__s1, const char *__s2, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 3)));



extern int strncasecmp_l (const char *__s1, const char *__s2,
     size_t __n, locale_t __loc)
     __attribute__ ((__nothrow__ )) __attribute__ ((__pure__)) __attribute__ ((__nonnull__ (1, 2, 4)));
# 463 "/usr/include/string.h" 2 3 4



extern void explicit_bzero (void *__s, size_t __n) __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1)))
                                                  ;



extern char *strsep (char **__restrict __stringp,
       const char *__restrict __delim)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern char *strsignal (int __sig) __attribute__ ((__nothrow__ ));
# 489 "/usr/include/string.h" 3 4
extern char *__stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpcpy (char *__restrict __dest, const char *__restrict __src)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));



extern char *__stpncpy (char *__restrict __dest,
   const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));
extern char *stpncpy (char *__restrict __dest,
        const char *__restrict __src, size_t __n)
     __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2)));




extern size_t strlcpy (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;



extern size_t strlcat (char *__restrict __dest,
         const char *__restrict __src, size_t __n)
  __attribute__ ((__nothrow__ )) __attribute__ ((__nonnull__ (1, 2))) ;
# 54 "ieee754.c" 2

static inline uint64_t bits_of(double d) {
  uint64_t bits;
  memcpy(&bits, &d, sizeof bits);
  return bits;
}

static inline double double_of(uint64_t bits) {
  double d;
  memcpy(&d, &bits, sizeof d);
  return d;
}


static inline int32_t negate_with_wraparound(int32_t x) { return (int32_t)(0u - (uint32_t)x); }
static inline int32_t sub_with_wraparound(int32_t a, int32_t b) { return (int32_t)((uint32_t)a - (uint32_t)b); }
# 139 "ieee754.c"
static int32_t __ieee754_rem_pio2(double x, double* y);
static int __kernel_rem_pio2(double* x, double* y, int e0, int nx, int prec,
                      const int32_t* ipio2);
static double __kernel_cos(double x, double y);
static double __kernel_sin(double x, double y, int iy);






static int32_t __ieee754_rem_pio2(double x, double *y) {



  static const int32_t two_over_pi[] = {
      0xA2F983, 0x6E4E44, 0x1529FC, 0x2757D1, 0xF534DD, 0xC0DB62, 0x95993C,
      0x439041, 0xFE5163, 0xABDEBB, 0xC561B7, 0x246E3A, 0x424DD2, 0xE00649,
      0x2EEA09, 0xD1921C, 0xFE1DEB, 0x1CB129, 0xA73EE8, 0x8235F5, 0x2EBB44,
      0x84E99C, 0x7026B4, 0x5F7E41, 0x3991D6, 0x398353, 0x39F49C, 0x845F8B,
      0xBDF928, 0x3B1FF8, 0x97FFDE, 0x05980F, 0xEF2F11, 0x8B5A0A, 0x6D1F6D,
      0x367ECF, 0x27CB09, 0xB74F46, 0x3F669E, 0x5FEA2D, 0x7527BA, 0xC7EBE5,
      0xF17B3D, 0x0739F7, 0x8A5292, 0xEA6BFB, 0x5FB11F, 0x8D5D08, 0x560330,
      0x46FC7B, 0x6BABF0, 0xCFBC20, 0x9AF436, 0x1DA9E3, 0x91615E, 0xE61B08,
      0x659985, 0x5F14A0, 0x68408D, 0xFFD880, 0x4D7327, 0x310606, 0x1556CA,
      0x73A8C9, 0x60E27B, 0xC08C6B,
  };

  static const int32_t npio2_hw[] = {
      0x3FF921FB, 0x400921FB, 0x4012D97C, 0x401921FB, 0x401F6A7A, 0x4022D97C,
      0x4025FDBB, 0x402921FB, 0x402C463A, 0x402F6A7A, 0x4031475C, 0x4032D97C,
      0x40346B9C, 0x4035FDBB, 0x40378FDB, 0x403921FB, 0x403AB41B, 0x403C463A,
      0x403DD85A, 0x403F6A7A, 0x40407E4C, 0x4041475C, 0x4042106C, 0x4042D97C,
      0x4043A28C, 0x40446B9C, 0x404534AC, 0x4045FDBB, 0x4046C6CB, 0x40478FDB,
      0x404858EB, 0x404921FB,
  };
# 186 "ieee754.c"
  static const double
      zero = 0.00000000000000000000e+00,
      half = 5.00000000000000000000e-01,
      two24 = 1.67772160000000000000e+07,
      invpio2 = 6.36619772367581382433e-01,
      pio2_1 = 1.57079632673412561417e+00,
      pio2_1t = 6.07710050650619224932e-11,
      pio2_2 = 6.07710050630396597660e-11,
      pio2_2t = 2.02226624879595063154e-21,
      pio2_3 = 2.02226624871116645580e-21,
      pio2_3t = 8.47842766036889956997e-32;

  double z, w, t, r, fn;
  double tx[3];
  int32_t e0, i, j, nx, n, ix, hx;
  uint32_t low;

  z = 0;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix <= 0x3FE921FB) {
    y[0] = x;
    y[1] = 0;
    return 0;
  }
  if (ix < 0x4002D97C) {
    if (hx > 0) {
      z = x - pio2_1;
      if (ix != 0x3FF921FB) {
        y[0] = z - pio2_1t;
        y[1] = (z - y[0]) - pio2_1t;
      } else {
        z -= pio2_2;
        y[0] = z - pio2_2t;
        y[1] = (z - y[0]) - pio2_2t;
      }
      return 1;
    } else {
      z = x + pio2_1;
      if (ix != 0x3FF921FB) {
        y[0] = z + pio2_1t;
        y[1] = (z - y[0]) + pio2_1t;
      } else {
        z += pio2_2;
        y[0] = z + pio2_2t;
        y[1] = (z - y[0]) + pio2_2t;
      }
      return -1;
    }
  }
  if (ix <= 0x413921FB) {
    t = fabs(x);
    n = (int32_t)pts_site_fma(0, (t), (invpio2), (half));
    fn = (double)(n);
    r = pts_site_fma(1, (-fn), (pio2_1), (t));
    w = fn * pio2_1t;
    if (n < 32 && ix != npio2_hw[n - 1]) {
      y[0] = r - w;
    } else {
      uint32_t high;
      j = ix >> 20;
      y[0] = r - w;
      do { uint64_t bits = bits_of(y[0]); (high) = bits >> 32; } while (0);
      i = j - ((high >> 20) & 0x7FF);
      if (i > 16) {
        t = r;
        r = pts_site_fma(2, (-fn), (pio2_2), (t));
        w = pts_site_fma(4, (fn), (pio2_2t), (-pts_site_fma(3, (-fn), (pio2_2), (t - r))));
        y[0] = r - w;
        do { uint64_t bits = bits_of(y[0]); (high) = bits >> 32; } while (0);
        i = j - ((high >> 20) & 0x7FF);
        if (i > 49) {
          t = r;
          r = pts_site_fma(5, (-fn), (pio2_3), (t));
          w = pts_site_fma(7, (fn), (pio2_3t), (-pts_site_fma(6, (-fn), (pio2_3), (t - r))));
          y[0] = r - w;
        }
      }
    }
    y[1] = (r - y[0]) - w;
    if (hx < 0) {
      y[0] = -y[0];
      y[1] = -y[1];
      return -n;
    } else {
      return n;
    }
  }



  if (ix >= 0x7FF00000) {
    y[0] = y[1] = x - x;
    return 0;
  }

  do { uint64_t bits = bits_of(x); (low) = bits & 0xFFFFFFFFu; } while (0);
  do { uint64_t bits = bits_of(z); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(low); (z) = double_of(bits); } while (0);
  e0 = (ix >> 20) - 1046;
  do { uint64_t bits = bits_of(z); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(ix - (int32_t)((uint32_t)(e0) << 20)) << 32; (z) = double_of(bits); } while (0);
  for (i = 0; i < 2; i++) {
    tx[i] = (double)((int32_t)(z));
    z = (z - tx[i]) * two24;
  }
  tx[2] = z;
  nx = 3;
  while (tx[nx - 1] == zero) nx--;
  n = __kernel_rem_pio2(tx, y, e0, nx, 2, two_over_pi);
  if (hx < 0) {
    y[0] = -y[0];
    y[1] = -y[1];
    return -n;
  }
  return n;
}
# 335 "ieee754.c"
static inline double __kernel_cos(double x, double y) {
  static const double
      one = 1.00000000000000000000e+00,
      C1 = 4.16666666666666019037e-02,
      C2 = -1.38888888888741095749e-03,
      C3 = 2.48015872894767294178e-05,
      C4 = -2.75573143513906633035e-07,
      C5 = 2.08757232129817482790e-09,
      C6 = -1.13596475577881948265e-11;

  double a, iz, z, r, qx;
  int32_t ix;
  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);
  ix &= 0x7FFFFFFF;
  if (ix < 0x3E400000) {
    if ((int)(x) == 0) return one;
  }
  z = x * x;
  r = z * pts_site_fma(12, (z), (pts_site_fma(11, (z), (pts_site_fma(10, (z), (pts_site_fma(9, (z), (pts_site_fma(8, (z), (C6), (C5))), (C4))), (C3))), (C2))), (C1));
  if (ix < 0x3FD33333) {
    return one - pts_site_fma(14, (0.5), (z), (-pts_site_fma(13, (z), (r), (-(x * y)))));
  } else {
    if (ix > 0x3FE90000) {
      qx = 0.28125;
    } else {
      do { uint64_t bits = 0; bits |= (uint64_t)(ix - 0x00200000) << 32; bits |= (uint32_t)(0); (qx) = double_of(bits); } while (0);
    }
    iz = pts_site_fma(15, (0.5), (z), (-qx));
    a = one - qx;
    return a - (iz - pts_site_fma(16, (z), (r), (-(x * y))));
  }
}
# 473 "ieee754.c"
static int __kernel_rem_pio2(double *x, double *y, int e0, int nx, int prec,
                      const int32_t *ipio2) {






  static const int init_jk[] = {2, 3, 4, 6};

  static const double PIo2[] = {
      1.57079625129699707031e+00,
      7.54978941586159635335e-08,
      5.39030252995776476554e-15,
      3.28200341580791294123e-22,
      1.27065575308067607349e-29,
      1.22933308981111328932e-36,
      2.73370053816464559624e-44,
      2.16741683877804819444e-51,
  };

  static const double
      zero = 0.0,
      one = 1.0,
      two24 = 1.67772160000000000000e+07,
      twon24 = 5.96046447753906250000e-08;

  int32_t jz, jx, jv, jp, jk, carry, n, iq[20], i, j, k, m, q0, ih;
  double z, fw, f[20], fq[20], q[20];


  jk = init_jk[prec];
  jp = jk;


  jx = nx - 1;
  jv = (e0 - 3) / 24;
  if (jv < 0) jv = 0;
  q0 = e0 - 24 * (jv + 1);


  j = jv - jx;
  m = jx + jk;
  for (i = 0; i <= m; i++, j++) {
    f[i] = (j < 0) ? zero : (double)(ipio2[j]);
  }


  for (i = 0; i <= jk; i++) {
    for (j = 0, fw = 0.0; j <= jx; j++) fw = pts_site_fma(17, (x[j]), (f[jx + i - j]), (fw));
    q[i] = fw;
  }

  jz = jk;
recompute:

  for (i = 0, j = jz, z = q[jz]; j > 0; i++, j--) {
    fw = (double)((int32_t)(twon24 * z));
    iq[i] = (int32_t)pts_site_fma(18, (-two24), (fw), (z));
    z = q[j - 1] + fw;
  }


  z = scalbn(z, q0);
  z = pts_site_fma(19, (-8.0), (floor(z * 0.125)), (z));
  n = (int32_t)(z);
  z -= (double)(n);
  ih = 0;
  if (q0 > 0) {
    i = (iq[jz - 1] >> (24 - q0));
    n += i;
    iq[jz - 1] -= i << (24 - q0);
    ih = iq[jz - 1] >> (23 - q0);
  } else if (q0 == 0) {
    ih = iq[jz - 1] >> 23;
  } else if (z >= 0.5) {
    ih = 2;
  }

  if (ih > 0) {
    n += 1;
    carry = 0;
    for (i = 0; i < jz; i++) {
      j = iq[i];
      if (carry == 0) {
        if (j != 0) {
          carry = 1;
          iq[i] = 0x1000000 - j;
        }
      } else {
        iq[i] = 0xFFFFFF - j;
      }
    }
    if (q0 > 0) {
      switch (q0) {
        case 1:
          iq[jz - 1] &= 0x7FFFFF;
          break;
        case 2:
          iq[jz - 1] &= 0x3FFFFF;
          break;
      }
    }
    if (ih == 2) {
      z = one - z;
      if (carry != 0) z -= scalbn(one, q0);
    }
  }


  if (z == zero) {
    j = 0;
    for (i = jz - 1; i >= jk; i--) j |= iq[i];
    if (j == 0) {
      for (k = 1; jk >= k && iq[jk - k] == 0; k++) {

      }

      for (i = jz + 1; i <= jz + k; i++) {
        f[jx + i] = ipio2[jv + i];
        for (j = 0, fw = 0.0; j <= jx; j++) fw = pts_site_fma(20, (x[j]), (f[jx + i - j]), (fw));
        q[i] = fw;
      }
      jz += k;
      goto recompute;
    }
  }


  if (z == 0.0) {
    jz -= 1;
    q0 -= 24;
    while (iq[jz] == 0) {
      jz--;
      q0 -= 24;
    }
  } else {
    z = scalbn(z, -q0);
    if (z >= two24) {
      fw = (double)((int32_t)(twon24 * z));
      iq[jz] = pts_site_fma(21, (-two24), (fw), (z));
      jz += 1;
      q0 += 24;
      iq[jz] = fw;
    } else {
      iq[jz] = z;
    }
  }


  fw = scalbn(one, q0);
  for (i = jz; i >= 0; i--) {
    q[i] = fw * iq[i];
    fw *= twon24;
  }


  for (i = jz; i >= 0; i--) {
    for (fw = 0.0, k = 0; k <= jp && k <= jz - i; k++) fw = pts_site_fma(22, (PIo2[k]), (q[i + k]), (fw));
    fq[jz - i] = fw;
  }


  switch (prec) {
    case 0:
      fw = 0.0;
      for (i = jz; i >= 0; i--) fw += fq[i];
      y[0] = (ih == 0) ? fw : -fw;
      break;
    case 1:
    case 2:
      fw = 0.0;
      for (i = jz; i >= 0; i--) fw += fq[i];
      y[0] = (ih == 0) ? fw : -fw;
      fw = fq[0] - fw;
      for (i = 1; i <= jz; i++) fw += fq[i];
      y[1] = (ih == 0) ? fw : -fw;
      break;
    case 3:
      for (i = jz; i > 0; i--) {
        fw = fq[i - 1] + fq[i];
        fq[i] += fq[i - 1] - fw;
        fq[i - 1] = fw;
      }
      for (i = jz; i > 1; i--) {
        fw = fq[i - 1] + fq[i];
        fq[i] += fq[i - 1] - fw;
        fq[i - 1] = fw;
      }
      for (fw = 0.0, i = jz; i >= 2; i--) fw += fq[i];
      if (ih == 0) {
        y[0] = fq[0];
        y[1] = fq[1];
        y[2] = fw;
      } else {
        y[0] = -fq[0];
        y[1] = -fq[1];
        y[2] = -fw;
      }
  }
  return n & 7;
}
# 703 "ieee754.c"
static inline double __kernel_sin(double x, double y, int iy) {
  static const double
      half = 5.00000000000000000000e-01,
      S1 = -1.66666666666666324348e-01,
      S2 = 8.33333333332248946124e-03,
      S3 = -1.98412698298579493134e-04,
      S4 = 2.75573137070700676789e-06,
      S5 = -2.50507602534068634195e-08,
      S6 = 1.58969099521155010221e-10;

  double z, r, v;
  int32_t ix;
  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);
  ix &= 0x7FFFFFFF;
  if (ix < 0x3E400000) {
    if ((int)(x) == 0) return x;
  }
  z = x * x;
  v = z * x;
  r = pts_site_fma(26, (z), (pts_site_fma(25, (z), (pts_site_fma(24, (z), (pts_site_fma(23, (z), (S6), (S5))), (S4))), (S3))), (S2));
  if (iy == 0) {
    return pts_site_fma(28, (v), (pts_site_fma(27, (z), (r), (S1))), (x));
  } else {

    return x - pts_site_fma(31, (-v), (S1), (pts_site_fma(30, (z), (pts_site_fma(29, (half), (y), (-(v * r)))), (-y))));
  }
}
# 764 "ieee754.c"
static double __kernel_tan(double x, double y, int iy) {
  static const double xxx[] = {
      3.33333333333334091986e-01,
      1.33333333333201242699e-01,
      5.39682539762260521377e-02,
      2.18694882948595424599e-02,
      8.86323982359930005737e-03,
      3.59207910759131235356e-03,
      1.45620945432529025516e-03,
      5.88041240820264096874e-04,
      2.46463134818469906812e-04,
      7.81794442939557092300e-05,
      7.14072491382608190305e-05,
      -1.85586374855275456654e-05,
      2.59073051863633712884e-05,
                1.00000000000000000000e+00,
                 7.85398163397448278999e-01,
                   3.06161699786838301793e-17
  };





  double z, r, v, w, s;
  int32_t ix, hx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix < 0x3E300000) {
    if ((int)(x) == 0) {
      uint32_t low;
      do { uint64_t bits = bits_of(x); (low) = bits & 0xFFFFFFFFu; } while (0);
      if (((ix | low) | (iy + 1)) == 0) {
        return xxx[13] / fabs(x);
      } else {
        if (iy == 1) {
          return x;
        } else {
          double a, t;

          z = w = x + y;
          do { uint64_t bits = bits_of(z); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (z) = double_of(bits); } while (0);
          v = y - (z - x);
          t = a = -xxx[13] / w;
          do { uint64_t bits = bits_of(t); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (t) = double_of(bits); } while (0);
          s = pts_site_fma(32, (t), (z), (xxx[13]));
          return pts_site_fma(34, (a), (pts_site_fma(33, (t), (v), (s))), (t));
        }
      }
    }
  }
  if (ix >= 0x3FE59428) {
    if (hx < 0) {
      x = -x;
      y = -y;
    }
    z = xxx[14] - x;
    w = xxx[15] - y;
    x = z + w;
    y = 0.0;
  }
  z = x * x;
  w = z * z;





  r = pts_site_fma(39, (w), (pts_site_fma(38, (w), (pts_site_fma(37, (w), (pts_site_fma(36, (w), (pts_site_fma(35, (w), (xxx[11]), (xxx[9]))), (xxx[7]))), (xxx[5]))), (xxx[3]))), (xxx[1]));

  v = pts_site_fma(44, (w), (pts_site_fma(43, (w), (pts_site_fma(42, (w), (pts_site_fma(41, (w), (pts_site_fma(40, (w), (xxx[12]), (xxx[10]))), (xxx[8]))), (xxx[6]))), (xxx[4]))), (xxx[2]));
  s = z * x;
  r = pts_site_fma(47, (z), (pts_site_fma(46, (s), (pts_site_fma(45, (z), (v), (r))), (y))), (y));
  r = pts_site_fma(48, (xxx[0]), (s), (r));
  w = x + r;
  if (ix >= 0x3FE59428) {
    v = iy;
    return (1 - ((hx >> 30) & 2)) * pts_site_fma(49, (-2.0), (x - (w * w / (w + v) - r)), (v));
  }
  if (iy == 1) {
    return w;
  } else {





    double a, t;
    z = w;
    do { uint64_t bits = bits_of(z); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (z) = double_of(bits); } while (0);
    v = r - (z - x);
    t = a = -1.0 / w;
    do { uint64_t bits = bits_of(t); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (t) = double_of(bits); } while (0);
    s = pts_site_fma(50, (t), (z), (1.0));
    return pts_site_fma(52, (a), (pts_site_fma(51, (t), (v), (s))), (t));
  }





}
# 893 "ieee754.c"
double pts_ieee754_acos(double x) {
  static const double
      one = 1.00000000000000000000e+00,
      pi = 3.14159265358979311600e+00,
      pio2_hi = 1.57079632679489655800e+00,
      pio2_lo = 6.12323399573676603587e-17,
      pS0 = 1.66666666666666657415e-01,
      pS1 = -3.25565818622400915405e-01,
      pS2 = 2.01212532134862925881e-01,
      pS3 = -4.00555345006794114027e-02,
      pS4 = 7.91534994289814532176e-04,
      pS5 = 3.47933107596021167570e-05,
      qS1 = -2.40339491173441421878e+00,
      qS2 = 2.02094576023350569471e+00,
      qS3 = -6.88283971605453293030e-01,
      qS4 = 7.70381505559019352791e-02;

  double z, p, q, r, w, s, c, df;
  int32_t hx, ix;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix >= 0x3FF00000) {
    uint32_t lx;
    do { uint64_t bits = bits_of(x); (lx) = bits & 0xFFFFFFFFu; } while (0);
    if (((ix - 0x3FF00000) | lx) == 0) {
      if (hx > 0)
        return 0.0;
      else
        return pi + 2.0 * pio2_lo;
    }
    return (__builtin_nanf (""));
  }
  if (ix < 0x3FE00000) {
    if (ix <= 0x3C600000) return pio2_hi + pio2_lo;
    z = x * x;
    p = z * pts_site_fma(57, (z), (pts_site_fma(56, (z), (pts_site_fma(55, (z), (pts_site_fma(54, (z), (pts_site_fma(53, (z), (pS5), (pS4))), (pS3))), (pS2))), (pS1))), (pS0));
    q = pts_site_fma(61, (z), (pts_site_fma(60, (z), (pts_site_fma(59, (z), (pts_site_fma(58, (z), (qS4), (qS3))), (qS2))), (qS1))), (one));
    r = p / q;
    return pio2_hi - (x - pts_site_fma(62, (-x), (r), (pio2_lo)));
  } else if (hx < 0) {
    z = (one + x) * 0.5;
    p = z * pts_site_fma(67, (z), (pts_site_fma(66, (z), (pts_site_fma(65, (z), (pts_site_fma(64, (z), (pts_site_fma(63, (z), (pS5), (pS4))), (pS3))), (pS2))), (pS1))), (pS0));
    q = pts_site_fma(71, (z), (pts_site_fma(70, (z), (pts_site_fma(69, (z), (pts_site_fma(68, (z), (qS4), (qS3))), (qS2))), (qS1))), (one));
    s = sqrt(z);
    r = p / q;
    w = pts_site_fma(72, (r), (s), (-pio2_lo));
    return pts_site_fma(73, (-2.0), (s + w), (pi));
  } else {
    z = (one - x) * 0.5;
    s = sqrt(z);
    df = s;
    do { uint64_t bits = bits_of(df); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (df) = double_of(bits); } while (0);
    c = pts_site_fma(74, (-df), (df), (z)) / (s + df);
    p = z * pts_site_fma(79, (z), (pts_site_fma(78, (z), (pts_site_fma(77, (z), (pts_site_fma(76, (z), (pts_site_fma(75, (z), (pS5), (pS4))), (pS3))), (pS2))), (pS1))), (pS0));
    q = pts_site_fma(83, (z), (pts_site_fma(82, (z), (pts_site_fma(81, (z), (pts_site_fma(80, (z), (qS4), (qS3))), (qS2))), (qS1))), (one));
    r = p / q;
    w = pts_site_fma(84, (r), (s), (c));
    return 2.0 * (df + w);
  }
}
# 967 "ieee754.c"
double pts_ieee754_acosh(double x) {
  static const double
      one = 1.0,
      ln2 = 6.93147180559945286227e-01;
  double t;
  int32_t hx;
  uint32_t lx;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);
  if (hx < 0x3FF00000) {
    return (__builtin_nanf (""));
  } else if (hx >= 0x41B00000) {
    if (hx >= 0x7FF00000) {
      return x + x;
    } else {
      return pts_ieee754_log(x) + ln2;
    }
  } else if (((hx - 0x3FF00000) | lx) == 0) {
    return 0.0;
  } else if (hx > 0x40000000) {

    return pts_ieee754_log(2.0 * x - one / (x + sqrt(pts_site_fma(85, (x), (x), (-one)))));
  } else {
    t = x - one;
    return pts_ieee754_log1p(t + sqrt(pts_site_fma(86, (2.0), (t), (t * t))));
  }
}
# 1022 "ieee754.c"
double pts_ieee754_asin(double x) {
  static const double
      one = 1.00000000000000000000e+00,
      huge = 1.000e+300,
      pio2_hi = 1.57079632679489655800e+00,
      pio2_lo = 6.12323399573676603587e-17,
      pio4_hi = 7.85398163397448278999e-01,

      pS0 = 1.66666666666666657415e-01,
      pS1 = -3.25565818622400915405e-01,
      pS2 = 2.01212532134862925881e-01,
      pS3 = -4.00555345006794114027e-02,
      pS4 = 7.91534994289814532176e-04,
      pS5 = 3.47933107596021167570e-05,
      qS1 = -2.40339491173441421878e+00,
      qS2 = 2.02094576023350569471e+00,
      qS3 = -6.88283971605453293030e-01,
      qS4 = 7.70381505559019352791e-02;

  double t, w, p, q, c, r, s;
  int32_t hx, ix;

  t = 0;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix >= 0x3FF00000) {
    uint32_t lx;
    do { uint64_t bits = bits_of(x); (lx) = bits & 0xFFFFFFFFu; } while (0);
    if (((ix - 0x3FF00000) | lx) == 0) {
      return pts_site_fma(87, (x), (pio2_hi), (x * pio2_lo));
    }
    return (__builtin_nanf (""));
  } else if (ix < 0x3FE00000) {
    if (ix < 0x3E400000) {
      if (huge + x > one) return x;
    } else {
      t = x * x;
    }
    p = t * pts_site_fma(92, (t), (pts_site_fma(91, (t), (pts_site_fma(90, (t), (pts_site_fma(89, (t), (pts_site_fma(88, (t), (pS5), (pS4))), (pS3))), (pS2))), (pS1))), (pS0));
    q = pts_site_fma(96, (t), (pts_site_fma(95, (t), (pts_site_fma(94, (t), (pts_site_fma(93, (t), (qS4), (qS3))), (qS2))), (qS1))), (one));
    w = p / q;
    return pts_site_fma(97, (x), (w), (x));
  }

  w = one - fabs(x);
  t = w * 0.5;
  p = t * pts_site_fma(102, (t), (pts_site_fma(101, (t), (pts_site_fma(100, (t), (pts_site_fma(99, (t), (pts_site_fma(98, (t), (pS5), (pS4))), (pS3))), (pS2))), (pS1))), (pS0));
  q = pts_site_fma(106, (t), (pts_site_fma(105, (t), (pts_site_fma(104, (t), (pts_site_fma(103, (t), (qS4), (qS3))), (qS2))), (qS1))), (one));
  s = sqrt(t);
  if (ix >= 0x3FEF3333) {
    w = p / q;
    t = pio2_hi - pts_site_fma(108, (2.0), (pts_site_fma(107, (s), (w), (s))), (-pio2_lo));
  } else {
    w = s;
    do { uint64_t bits = bits_of(w); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (w) = double_of(bits); } while (0);
    c = pts_site_fma(109, (-w), (w), (t)) / (s + w);
    r = p / q;
    p = pts_site_fma(111, (2.0 * s), (r), (-pts_site_fma(110, (-2.0), (c), (pio2_lo))));
    q = pts_site_fma(112, (-2.0), (w), (pio4_hi));
    t = pio4_hi - (p - q);
  }
  if (hx > 0)
    return t;
  else
    return -t;
}
# 1098 "ieee754.c"
double pts_ieee754_asinh(double x) {
  static const double
      one = 1.00000000000000000000e+00,
      ln2 = 6.93147180559945286227e-01,
      huge = 1.00000000000000000000e+300;

  double t, w;
  int32_t hx, ix;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix >= 0x7FF00000) return x + x;
  if (ix < 0x3E300000) {
    if (huge + x > one) return x;
  }
  if (ix > 0x41B00000) {
    w = pts_ieee754_log(fabs(x)) + ln2;
  } else if (ix > 0x40000000) {
    t = fabs(x);
    w = pts_ieee754_log(2.0 * t + one / (sqrt(pts_site_fma(113, (x), (x), (one))) + t));
  } else {
    t = x * x;
    w = pts_ieee754_log1p(fabs(x) + t / (one + sqrt(one + t)));
  }
  if (hx > 0) {
    return w;
  } else {
    return -w;
  }
}
# 1147 "ieee754.c"
double pts_ieee754_atan(double x) {
  static const double atanhi[] = {
      4.63647609000806093515e-01,
      7.85398163397448278999e-01,
      9.82793723247329054082e-01,
      1.57079632679489655800e+00,
  };

  static const double atanlo[] = {
      2.26987774529616870924e-17,
      3.06161699786838301793e-17,
      1.39033110312309984516e-17,
      6.12323399573676603587e-17,
  };

  static const double aT[] = {
      3.33333333333329318027e-01,
      -1.99999999998764832476e-01,
      1.42857142725034663711e-01,
      -1.11111104054623557880e-01,
      9.09088713343650656196e-02,
      -7.69187620504482999495e-02,
      6.66107313738753120669e-02,
      -5.83357013379057348645e-02,
      4.97687799461593236017e-02,
      -3.65315727442169155270e-02,
      1.62858201153657823623e-02,
  };

  static const double one = 1.0, huge = 1.0e300;

  double w, s1, s2, z;
  int32_t ix, hx, id;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ix = hx & 0x7FFFFFFF;
  if (ix >= 0x44100000) {
    uint32_t low;
    do { uint64_t bits = bits_of(x); (low) = bits & 0xFFFFFFFFu; } while (0);
    if (ix > 0x7FF00000 || (ix == 0x7FF00000 && (low != 0)))
      return x + x;
    if (hx > 0)
      return atanhi[3] + *(const volatile double *)&atanlo[3];
    else
      return -atanhi[3] - *(const volatile double *)&atanlo[3];
  }
  if (ix < 0x3FDC0000) {
    if (ix < 0x3E400000) {
      if (huge + x > one) return x;
    }
    id = -1;
  } else {
    x = fabs(x);
    if (ix < 0x3FF30000) {
      if (ix < 0x3FE60000) {
        id = 0;
        x = pts_site_fma(114, (2.0), (x), (-one)) / (2.0 + x);
      } else {
        id = 1;
        x = (x - one) / (x + one);
      }
    } else {
      if (ix < 0x40038000) {
        id = 2;
        x = (x - 1.5) / pts_site_fma(115, (1.5), (x), (one));
      } else {
        id = 3;
        x = -1.0 / x;
      }
    }
  }

  z = x * x;
  w = z * z;


  s1 = pts_site_fma(120, (w), (pts_site_fma(119, (w), (pts_site_fma(118, (w), (pts_site_fma(117, (w), (pts_site_fma(116, (w), (aT[10]), (aT[8]))), (aT[6]))), (aT[4]))), (aT[2]))), (aT[0]));
  s2 = w * pts_site_fma(124, (w), (pts_site_fma(123, (w), (pts_site_fma(122, (w), (pts_site_fma(121, (w), (aT[9]), (aT[7]))), (aT[5]))), (aT[3]))), (aT[1]));
  if (id < 0) {
    return x - x * pts_site_fma(125, (z), (s1), (s2));
  } else {
    z = atanhi[id] - ((x * pts_site_fma(126, (z), (s1), (s2)) - atanlo[id]) - x);
    return (hx < 0) ? -z : z;
  }
}
# 1259 "ieee754.c"
double pts_ieee754_atan2(double y, double x) {
  static volatile double tiny = 1.0e-300;
  static const double
      zero = 0.0,
      pi_o_4 = 7.8539816339744827900E-01,
      pi_o_2 = 1.5707963267948965580E+00,
      pi = 3.1415926535897931160E+00;
  static volatile double pi_lo =
      1.2246467991473531772E-16;

  double z;
  int32_t k, m, hx, hy, ix, iy;
  uint32_t lx, ly;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);
  ix = hx & 0x7FFFFFFF;
  do { uint64_t bits = bits_of(y); (hy) = bits >> 32; (ly) = bits & 0xFFFFFFFFu; } while (0);
  iy = hy & 0x7FFFFFFF;
  if (((ix | ((lx | negate_with_wraparound(lx)) >> 31)) > 0x7FF00000) ||
      ((iy | ((ly | negate_with_wraparound(ly)) >> 31)) > 0x7FF00000)) {
    return x + y;
  }
  if ((sub_with_wraparound(hx, 0x3FF00000) | lx) == 0) {
    return pts_ieee754_atan(y);
  }
  m = ((hy >> 31) & 1) | ((hx >> 30) & 2);


  if ((iy | ly) == 0) {
    switch (m) {
      case 0:
      case 1:
        return y;
      case 2:
        return pi + tiny;
      case 3:
        return -pi - tiny;
    }
  }

  if ((ix | lx) == 0) return (hy < 0) ? -pi_o_2 - tiny : pi_o_2 + tiny;


  if (ix == 0x7FF00000) {
    if (iy == 0x7FF00000) {
      switch (m) {
        case 0:
          return pi_o_4 + tiny;
        case 1:
          return -pi_o_4 - tiny;
        case 2:
          return 3.0 * pi_o_4 + tiny;
        case 3:
          return -3.0 * pi_o_4 - tiny;
      }
    } else {
      switch (m) {
        case 0:
          return zero;
        case 1:
          return -zero;
        case 2:
          return pi + tiny;
        case 3:
          return -pi - tiny;
      }
    }
  }

  if (iy == 0x7FF00000) return (hy < 0) ? -pi_o_2 - tiny : pi_o_2 + tiny;


  k = (iy - ix) >> 20;
  if (k > 60) {
    z = pts_site_fma(127, (0.5), (pi_lo), (pi_o_2));
    m &= 1;
  } else if (hx < 0 && k < -60) {
    z = 0.0;
  } else {
    z = pts_ieee754_atan(fabs(y / x));
  }
  switch (m) {
    case 0:
      return z;
    case 1:
      return -z;
    case 2:
      return pi - (z - pi_lo);
    default:
      return (z - pi_lo) - pi;
  }
}
# 1382 "ieee754.c"
double pts_ieee754_cos(double x) {
  double y[2], z = 0.0;
  int32_t n, ix;


  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);


  ix &= 0x7FFFFFFF;
  if (ix <= 0x3FE921FB) {
    return __kernel_cos(x, z);
  } else if (ix >= 0x7FF00000) {

    return x - x;
  } else {

    n = __ieee754_rem_pio2(x, y);
    switch (n & 3) {
      case 0:
        return __kernel_cos(y[0], y[1]);
      case 1:
        return -__kernel_sin(y[0], y[1], 1);
      case 2:
        return -__kernel_cos(y[0], y[1]);
      default:
        return __kernel_sin(y[0], y[1], 1);
    }
  }
}
# 1474 "ieee754.c"
double pts_ieee754_exp(double x) {
  static const double
      one = 1.0,
      halF[2] = {0.5, -0.5},
      o_threshold = 7.09782712893383973096e+02,
      u_threshold = -7.45133219101941108420e+02,
      ln2HI[2] = {6.93147180369123816490e-01,
                  -6.93147180369123816490e-01},
      ln2LO[2] = {1.90821492927058770002e-10,
                  -1.90821492927058770002e-10},
      invln2 = 1.44269504088896338700e+00,
      P1 = 1.66666666666666019037e-01,
      P2 = -2.77777777770155933842e-03,
      P3 = 6.61375632143793436117e-05,
      P4 = -1.65339022054652515390e-06,
      P5 = 4.13813679705723846039e-08,
      E = 2.718281828459045;

  static volatile double
      huge = 1.0e+300,
      twom1000 = 9.33263618503218878990e-302,
      two1023 = 8.988465674311579539e307;

  double y, hi = 0.0, lo = 0.0, c, t, twopk;
  int32_t k = 0, xsb;
  uint32_t hx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  xsb = (hx >> 31) & 1;
  hx &= 0x7FFFFFFF;


  if (hx >= 0x40862E42) {
    if (hx >= 0x7FF00000) {
      uint32_t lx;
      do { uint64_t bits = bits_of(x); (lx) = bits & 0xFFFFFFFFu; } while (0);
      if (((hx & 0xFFFFF) | lx) != 0)
        return x + x;
      else
        return (xsb == 0) ? x : 0.0;
    }
    if (x > o_threshold) return huge * huge;
    if (x < u_threshold) return twom1000 * twom1000;
  }


  if (hx > 0x3FD62E42) {
    if (hx < 0x3FF0A2B2) {




      if (x == 1.0) return E;
      hi = x - ln2HI[xsb];
      lo = ln2LO[xsb];
      k = 1 - xsb - xsb;
    } else {
      k = (int)pts_site_fma(128, (invln2), (x), (halF[xsb]));
      t = k;
      hi = pts_site_fma(129, (-t), (ln2HI[0]), (x));
      lo = t * ln2LO[0];
    }
    x = hi - lo;
  } else if (hx < 0x3E300000) {
    if (huge + x > one) return one + x;
  } else {
    k = 0;
  }


  t = x * x;
  if (k >= -1021) {
    do { uint64_t bits = 0; bits |= (uint64_t)(0x3FF00000 + (int32_t)((uint32_t)(k) << 20)) << 32; bits |= (uint32_t)(0); (twopk) = double_of(bits); } while (0);


  } else {
    do { uint64_t bits = 0; bits |= (uint64_t)(0x3FF00000 + ((uint32_t)(k + 1000) << 20)) << 32; bits |= (uint32_t)(0); (twopk) = double_of(bits); } while (0);

  }
  c = pts_site_fma(134, (-t), (pts_site_fma(133, (t), (pts_site_fma(132, (t), (pts_site_fma(131, (t), (pts_site_fma(130, (t), (P5), (P4))), (P3))), (P2))), (P1))), (x));
  if (k == 0) {
    return one - ((x * c) / (c - 2.0) - x);
  } else {
    y = one - ((lo - (x * c) / (2.0 - c)) - hi);
  }
  if (k >= -1021) {
    if (k == 1024) return y * 2.0 * two1023;
    return y * twopk;
  } else {
    return y * twopk * twom1000;
  }
}
# 1584 "ieee754.c"
double pts_ieee754_atanh(double x) {
  static const double one = 1.0, huge = 1e300;
  static const double zero = 0.0;

  double t;
  int32_t hx, ix;
  uint32_t lx;
  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);
  ix = hx & 0x7FFFFFFF;
  if ((ix | ((lx | negate_with_wraparound(lx)) >> 31)) > 0x3FF00000) {

    return (__builtin_nanf (""));
  }
  if (ix == 0x3FF00000) {
    return x > 0 ? (__builtin_inff ())
                 : -(__builtin_inff ());
  }
  if (ix < 0x3E300000 && (huge + x) > zero) return x;
  do { uint64_t bits = bits_of(x); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(ix) << 32; (x) = double_of(bits); } while (0);
  if (ix < 0x3FE00000) {
    t = x + x;
    t = 0.5 * pts_ieee754_log1p(t + t * x / (one - x));
  } else {
    t = 0.5 * pts_ieee754_log1p((x + x) / (one - x));
  }
  if (hx >= 0)
    return t;
  else
    return -t;
}
# 1665 "ieee754.c"
double pts_ieee754_log(double x) {
  static const double
      ln2_hi = 6.93147180369123816490e-01,
      ln2_lo = 1.90821492927058770002e-10,
      two54 = 1.80143985094819840000e+16,
      Lg1 = 6.666666666666735130e-01,
      Lg2 = 3.999999999940941908e-01,
      Lg3 = 2.857142874366239149e-01,
      Lg4 = 2.222219843214978396e-01,
      Lg5 = 1.818357216161805012e-01,
      Lg6 = 1.531383769920937332e-01,
      Lg7 = 1.479819860511658591e-01;

  static const double zero = 0.0;

  double hfsq, f, s, z, R, w, t1, t2, dk;
  int32_t k, hx, i, j;
  uint32_t lx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);

  k = 0;
  if (hx < 0x00100000) {
    if (((hx & 0x7FFFFFFF) | lx) == 0) {
      return -(__builtin_inff ());
    }
    if (hx < 0) {
      return (__builtin_nanf (""));
    }
    k -= 54;
    x *= two54;
    do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  }
  if (hx >= 0x7FF00000) return x + x;
  k += (hx >> 20) - 1023;
  hx &= 0x000FFFFF;
  i = (hx + 0x95F64) & 0x100000;
  do { uint64_t bits = bits_of(x); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(hx | (i ^ 0x3FF00000)) << 32; (x) = double_of(bits); } while (0);
  k += (i >> 20);
  f = x - 1.0;
  if ((0x000FFFFF & (2 + hx)) < 3) {
    if (f == zero) {
      if (k == 0) {
        return zero;
      } else {
        dk = (double)(k);
        return pts_site_fma(135, (dk), (ln2_hi), (dk * ln2_lo));
      }
    }
    R = f * f * pts_site_fma(136, (-0.33333333333333333), (f), (0.5));
    if (k == 0) {
      return f - R;
    } else {
      dk = (double)(k);
      return pts_site_fma(138, (dk), (ln2_hi), (-(pts_site_fma(137, (-dk), (ln2_lo), (R)) - f)));
    }
  }
  s = f / (2.0 + f);
  dk = (double)(k);
  z = s * s;
  i = hx - 0x6147A;
  w = z * z;
  j = 0x6B851 - hx;

  t1 = pts_site_fma(140, (w), (pts_site_fma(139, (w), (Lg6), (Lg4))), (Lg2));
  t2 = z * pts_site_fma(143, (w), (pts_site_fma(142, (w), (pts_site_fma(141, (w), (Lg7), (Lg5))), (Lg3))), (Lg1));
  i |= j;
  R = pts_site_fma(144, (w), (t1), (t2));
  if (i > 0) {
    hfsq = 0.5 * f * f;
    if (k == 0)
      return f - (hfsq - s * (hfsq + R));
    else
      return pts_site_fma(146, (dk), (ln2_hi), (-((hfsq - pts_site_fma(145, (dk), (ln2_lo), (s * (hfsq + R)))) - f)));
  } else {
    if (k == 0)
      return f - s * (f - R);
    else
      return pts_site_fma(148, (dk), (ln2_hi), (-(pts_site_fma(147, (-dk), (ln2_lo), (s * (f - R))) - f)));
  }
}
# 1811 "ieee754.c"
double pts_ieee754_log1p(double x) {
  static const double
      ln2_hi = 6.93147180369123816490e-01,
      ln2_lo = 1.90821492927058770002e-10,
      two54 = 1.80143985094819840000e+16,
      Lp1 = 6.666666666666735130e-01,
      Lp2 = 3.999999999940941908e-01,
      Lp3 = 2.857142874366239149e-01,
      Lp4 = 2.222219843214978396e-01,
      Lp5 = 1.818357216161805012e-01,
      Lp6 = 1.531383769920937332e-01,
      Lp7 = 1.479819860511658591e-01;

  static const double zero = 0.0;

  double hfsq, f, c, s, z, R, u;
  int32_t k, hx, hu, ax;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  ax = hx & 0x7FFFFFFF;

  k = 1;
  if (hx < 0x3FDA827A) {
    if (ax >= 0x3FF00000) {
      if (x == -1.0)
        return -(__builtin_inff ());
      else
        return (__builtin_nanf (""));
    }
    if (ax < 0x3E200000) {
      if (two54 + x > zero
          && ax < 0x3C900000)
        return x;
      else
        return pts_site_fma(149, (-(x * x)), (0.5), (x));
    }
    if (hx > 0 || hx <= (int32_t)(0xBFD2BEC4)) {
      k = 0;
      f = x;
      hu = 1;
    }
  }
  if (hx >= 0x7FF00000) return x + x;
  if (k != 0) {
    if (hx < 0x43400000) {
      u = 1.0 + x;
      do { uint64_t bits = bits_of(u); (hu) = bits >> 32; } while (0);
      k = (hu >> 20) - 1023;
      c = (k > 0) ? 1.0 - (u - x) : x - (u - 1.0);
      c /= u;
    } else {
      u = x;
      do { uint64_t bits = bits_of(u); (hu) = bits >> 32; } while (0);
      k = (hu >> 20) - 1023;
      c = 0;
    }
    hu &= 0x000FFFFF;







    if (hu < 0x6A09E) {
      do { uint64_t bits = bits_of(u); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(hu | 0x3FF00000) << 32; (u) = double_of(bits); } while (0);
    } else {
      k += 1;
      do { uint64_t bits = bits_of(u); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(hu | 0x3FE00000) << 32; (u) = double_of(bits); } while (0);
      hu = (0x00100000 - hu) >> 2;
    }
    f = u - 1.0;
  }
  hfsq = 0.5 * f * f;
  if (hu == 0) {
    if (f == zero) {
      if (k == 0) {
        return zero;
      } else {
        c = pts_site_fma(150, (k), (ln2_lo), (c));
        return pts_site_fma(151, (k), (ln2_hi), (c));
      }
    }
    R = hfsq * pts_site_fma(152, (-0.66666666666666666), (f), (1.0));
    if (k == 0)
      return f - R;
    else
      return pts_site_fma(154, (k), (ln2_hi), (-((R - pts_site_fma(153, (k), (ln2_lo), (c))) - f)));
  }
  s = f / (2.0 + f);
  z = s * s;

  R = pts_site_fma(160, (z), (pts_site_fma(159, (z), (pts_site_fma(158, (z), (pts_site_fma(157, (z), (pts_site_fma(156, (z), (pts_site_fma(155, (z), (Lp7), (Lp6))), (Lp5))), (Lp4))), (Lp3))), (Lp2))), (Lp1));
  if (k == 0)
    return f - (hfsq - s * pts_site_fma(161, (z), (R), (hfsq)));
  else
    return pts_site_fma(164, (k), (ln2_hi), (-((hfsq - (s * pts_site_fma(162, (z), (R), (hfsq)) + pts_site_fma(163, (k), (ln2_lo), (c)))) - f)));
}
# 1967 "ieee754.c"
static const double Lg1 = 6.666666666666735130e-01,
    Lg2 = 3.999999999940941908e-01,
    Lg3 = 2.857142874366239149e-01,
    Lg4 = 2.222219843214978396e-01,
    Lg5 = 1.818357216161805012e-01,
    Lg6 = 1.531383769920937332e-01,
    Lg7 = 1.479819860511658591e-01;
# 1982 "ieee754.c"
static inline double k_log1p_sum(double f, double *s_out) {
  double s, z, R, w, t1, t2;

  s = f / (2.0 + f);
  z = s * s;
  w = z * z;

  t1 = pts_site_fma(166, (w), (pts_site_fma(165, (w), (Lg6), (Lg4))), (Lg2));
  t2 = z * pts_site_fma(169, (w), (pts_site_fma(168, (w), (pts_site_fma(167, (w), (Lg7), (Lg5))), (Lg3))), (Lg1));
  R = pts_site_fma(170, (w), (t1), (t2));
  *s_out = s;
  return pts_site_fma(171, (0.5 * f), (f), (R));
}
# 2005 "ieee754.c"
double pts_ieee754_log2(double x) {
  static const double
      two54 = 1.80143985094819840000e+16,
      ivln2hi = 1.44269504072144627571e+00,
      ivln2lo = 1.67517131648865118353e-10;

  double f, half_f, s, r_sum, hi, lo, val_lo, w, y;
  int32_t i, k, hx;
  uint32_t lx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);

  k = 0;
  if (hx < 0x00100000) {
    if (((hx & 0x7FFFFFFF) | lx) == 0) {
      return -(__builtin_inff ());
    }
    if (hx < 0) {
      return (__builtin_nanf (""));
    }
    k -= 54;
    x *= two54;
    do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  }
  if (hx >= 0x7FF00000) return x + x;
  if (hx == 0x3FF00000 && lx == 0) return 0.0;
  k += (hx >> 20) - 1023;
  hx &= 0x000FFFFF;
  i = (hx + 0x95F64) & 0x100000;
  do { uint64_t bits = bits_of(x); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(hx | (i ^ 0x3FF00000)) << 32; (x) = double_of(bits); } while (0);
  k += (i >> 20);
  y = (double)(k);
  f = x - 1.0;

  half_f = 0.5 * f;
  r_sum = k_log1p_sum(f, &s);
# 2072 "ieee754.c"
  hi = pts_site_fma(172, (-half_f), (f), (f));
  do { uint64_t bits = bits_of(hi); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(0); (hi) = double_of(bits); } while (0);
  lo = pts_site_fma(174, (s), (r_sum), (pts_site_fma(173, (-half_f), (f), (f - hi))));

  val_lo = pts_site_fma(175, (lo + hi), (ivln2lo), (lo * ivln2hi));


  w = pts_site_fma(176, (hi), (ivln2hi), (y));
  val_lo += pts_site_fma(177, (hi), (ivln2hi), (y - w));

  return val_lo + w;
}
# 2111 "ieee754.c"
double pts_ieee754_log10(double x) {
  static const double
      two54 = 1.80143985094819840000e+16,
      ivln10 = 4.34294481903251816668e-01,
      log10_2hi = 3.01029995663611771306e-01,
      log10_2lo = 3.69423907715893078616e-13;

  double y;
  int32_t i, k, hx;
  uint32_t lx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (lx) = bits & 0xFFFFFFFFu; } while (0);

  k = 0;
  if (hx < 0x00100000) {
    if (((hx & 0x7FFFFFFF) | lx) == 0) {
      return -(__builtin_inff ());
    }
    if (hx < 0) {
      return (__builtin_nanf (""));
    }
    k -= 54;
    x *= two54;
    do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
    do { uint64_t bits = bits_of(x); (lx) = bits & 0xFFFFFFFFu; } while (0);
  }
  if (hx >= 0x7FF00000) return x + x;
  if (hx == 0x3FF00000 && lx == 0) return 0.0;
  k += (hx >> 20) - 1023;

  i = (k & 0x80000000) >> 31;
  hx = (hx & 0x000FFFFF) | ((0x3FF - i) << 20);
  y = k + i;
  do { uint64_t bits = bits_of(x); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(hx) << 32; (x) = double_of(bits); } while (0);
  do { uint64_t bits = bits_of(x); bits &= 0xFFFFFFFF00000000; bits |= (uint32_t)(lx); (x) = double_of(bits); } while (0);

  double z = pts_site_fma(178, (y), (log10_2lo), (ivln10 * pts_ieee754_log(x)));
  return pts_site_fma(179, (y), (log10_2hi), (z));
}
# 2245 "ieee754.c"
double pts_ieee754_expm1(double x) {
  static const double
      one = 1.0,
      tiny = 1.0e-300,
      o_threshold = 7.09782712893383973096e+02,
      ln2_hi = 6.93147180369123816490e-01,
      ln2_lo = 1.90821492927058770002e-10,
      invln2 = 1.44269504088896338700e+00,


      Q1 = -3.33333333333331316428e-02,
      Q2 = 1.58730158725481460165e-03,
      Q3 = -7.93650757867487942473e-05,
      Q4 = 4.00821782732936239552e-06,
      Q5 = -2.01099218183624371326e-07;

  static volatile double huge = 1.0e+300;

  double y, hi, lo, c, t, e, hxs, hfx, r1, twopk;
  int32_t k, xsb;
  uint32_t hx;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; } while (0);
  xsb = hx & 0x80000000;
  hx &= 0x7FFFFFFF;


  if (hx >= 0x4043687A) {
    if (hx >= 0x40862E42) {
      if (hx >= 0x7FF00000) {
        uint32_t low;
        do { uint64_t bits = bits_of(x); (low) = bits & 0xFFFFFFFFu; } while (0);
        if (((hx & 0xFFFFF) | low) != 0)
          return x + x;
        else
          return (xsb == 0) ? x : -1.0;
      }
      if (x > o_threshold) return huge * huge;
    }
    if (xsb != 0) {
      if (x + tiny < 0.0)
        return tiny - one;
    }
  }


  if (hx > 0x3FD62E42) {
    if (hx < 0x3FF0A2B2) {
      if (xsb == 0) {
        hi = x - ln2_hi;
        lo = ln2_lo;
        k = 1;
      } else {
        hi = x + ln2_hi;
        lo = -ln2_lo;
        k = -1;
      }
    } else {
      k = invln2 * x + ((xsb == 0) ? 0.5 : -0.5);
      t = k;
      hi = pts_site_fma(180, (-t), (ln2_hi), (x));
      lo = t * ln2_lo;
    }
    x = hi - lo;
    c = (hi - x) - lo;
  } else if (hx < 0x3C900000) {
    t = huge + x;
    return x - (t - (huge + x));
  } else {
    k = 0;
  }


  hfx = 0.5 * x;
  hxs = x * hfx;
  r1 = pts_site_fma(185, (hxs), (pts_site_fma(184, (hxs), (pts_site_fma(183, (hxs), (pts_site_fma(182, (hxs), (pts_site_fma(181, (hxs), (Q5), (Q4))), (Q3))), (Q2))), (Q1))), (one));
  t = pts_site_fma(186, (-r1), (hfx), (3.0));
  e = hxs * ((r1 - t) / pts_site_fma(187, (-x), (t), (6.0)));
  if (k == 0) {
    return x - pts_site_fma(188, (x), (e), (-hxs));
  } else {
    do { uint64_t bits = 0; bits |= (uint64_t)(0x3FF00000 + (int32_t)((uint32_t)(k) << 20)) << 32; bits |= (uint32_t)(0); (twopk) = double_of(bits); } while (0);



    e = pts_site_fma(189, (x), (e - c), (-c));
    e -= hxs;
    if (k == -1) return pts_site_fma(190, (0.5), (x - e), (-0.5));
    if (k == 1) {
      if (x < -0.25)
        return -2.0 * (e - (x + 0.5));
      else
        return pts_site_fma(191, (2.0), (x - e), (one));
    }
    if (k <= -2 || k > 56) {
      y = one - (e - x);



      if (k == 1024)
        y = y * 2.0 * 8.98846567431158e+307;
      else
        y = y * twopk;
      return y - one;
    }
    t = one;
    if (k < 20) {
      do { uint64_t bits = bits_of(t); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(0x3FF00000 - (0x200000 >> k)) << 32; (t) = double_of(bits); } while (0);
      y = t - (e - x);
      y = y * twopk;
    } else {
      do { uint64_t bits = bits_of(t); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(((0x3FF - k) << 20)) << 32; (t) = double_of(bits); } while (0);
      y = x - (e + t);
      y += one;
      y = y * twopk;
    }
  }
  return y;
}

double pts_ieee754_cbrt(double x) {
  static const uint32_t
      B1 = 715094163,
      B2 = 696219795;


  static const double P0 = 1.87595182427177009643,
      P1 = -1.88497979543377169875,
      P2 = 1.621429720105354466140,
      P3 = -0.758397934778766047437,
      P4 = 0.145996192886612446982;

  int32_t hx;
  double r, s, t = 0.0;
  uint32_t sign;
  uint32_t high, low;

  do { uint64_t bits = bits_of(x); (hx) = bits >> 32; (low) = bits & 0xFFFFFFFFu; } while (0);
  sign = hx & 0x80000000;
  hx ^= sign;
  if (hx >= 0x7FF00000) return (x + x);
# 2402 "ieee754.c"
  if (hx < 0x00100000) {
    if ((hx | low) == 0) return (x);
    do { uint64_t bits = bits_of(t); bits &= 0x00000000FFFFFFFF; bits |= (uint64_t)(0x43500000) << 32; (t) = double_of(bits); } while (0);
    t *= x;
    do { uint64_t bits = bits_of(t); (high) = bits >> 32; } while (0);
    do { uint64_t bits = 0; bits |= (uint64_t)(sign | ((high & 0x7FFFFFFF) / 3 + B2)) << 32; bits |= (uint32_t)(0); (t) = double_of(bits); } while (0);
  } else {
    do { uint64_t bits = 0; bits |= (uint64_t)(sign | (hx / 3 + B1)) << 32; bits |= (uint32_t)(0); (t) = double_of(bits); } while (0);
  }
# 2422 "ieee754.c"
  r = (t * t) * (t / x);
  t = t * pts_site_fma(195, ((r * r) * r), (pts_site_fma(192, (r), (P4), (P3))), (pts_site_fma(194, (r), (pts_site_fma(193, (r), (P2), (P1))), (P0))));
# 2435 "ieee754.c"
  uint64_t bits = bits_of(t);
  bits = (bits + 0x80000000) & 0xFFFFFFFFC0000000ULL;
  t = double_of(bits);


  s = t * t;
  r = x / s;

  r = (r - t) / pts_site_fma(196, (2.0), (t), (r));
  t = pts_site_fma(197, (t), (r), (t));

  return (t);
}
# 2479 "ieee754.c"
double pts_ieee754_sin(double x) {
  double y[2], z = 0.0;
  int32_t n, ix;


  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);


  ix &= 0x7FFFFFFF;
  if (ix <= 0x3FE921FB) {
    return __kernel_sin(x, z, 0);
  } else if (ix >= 0x7FF00000) {

    return x - x;
  } else {

    n = __ieee754_rem_pio2(x, y);
    switch (n & 3) {
      case 0:
        return __kernel_sin(y[0], y[1], 1);
      case 1:
        return __kernel_cos(y[0], y[1]);
      case 2:
        return -__kernel_sin(y[0], y[1], 1);
      default:
        return -__kernel_cos(y[0], y[1]);
    }
  }
}
# 2538 "ieee754.c"
double pts_ieee754_tan(double x) {
  double y[2], z = 0.0;
  int32_t n, ix;


  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);


  ix &= 0x7FFFFFFF;
  if (ix <= 0x3FE921FB) {
    return __kernel_tan(x, z, 1);
  } else if (ix >= 0x7FF00000) {

    return x - x;
  } else {

    n = __ieee754_rem_pio2(x, y);

    return __kernel_tan(y[0], y[1], 1 - ((n & 1) << 1));
  }
}
# 2582 "ieee754.c"
double pts_ieee754_cosh(double x) {
  static const double KCOSH_OVERFLOW = 710.4758600739439;
  static const double one = 1.0, half = 0.5;
  static volatile double huge = 1.0e+300;

  int32_t ix;


  do { uint64_t bits = bits_of(x); (ix) = bits >> 32; } while (0);
  ix &= 0x7FFFFFFF;


  if (ix < 0x3FD62E43) {
    double t = pts_ieee754_expm1(fabs(x));
    double w = one + t;

    if (ix < 0x3C800000) return w;
    return one + (t * t) / (w + w);
  }


  if (ix < 0x40360000) {
    double t = pts_ieee754_exp(fabs(x));
    return pts_site_fma(198, (half), (t), (half / t));
  }


  if (ix < 0x40862E42) return half * pts_ieee754_exp(fabs(x));


  if (fabs(x) <= KCOSH_OVERFLOW) {
    double w = pts_ieee754_exp(half * fabs(x));
    double t = half * w;
    return t * w;
  }


  if (ix >= 0x7FF00000) return x * x;


  return huge * huge;
}
# 2646 "ieee754.c"
double pts_ieee754_sinh(double x) {
  static const double KSINH_OVERFLOW = 710.4758600739439,
                      TWO_M28 =
                          3.725290298461914e-9,
      LOG_MAXD = 709.7822265625;
  static const double shuge = 1.0e307;

  double h = (x < 0) ? -0.5 : 0.5;

  double ax = fabs(x);
  if (ax < 22) {

    if (ax < TWO_M28) return x;
    double t = pts_ieee754_expm1(ax);
    if (ax < 1) {
      return h * pts_site_fma(199, (2), (t), (-(t * t / (t + 1))));
    }
    return h * (t + t / (t + 1));
  }

  if (ax < LOG_MAXD) return h * pts_ieee754_exp(ax);


  if (ax <= KSINH_OVERFLOW) {
    double w = pts_ieee754_exp(0.5 * ax);
    double t = h * w;
    return t * w;
  }


  return x * shuge;
}
# 2702 "ieee754.c"
double pts_ieee754_tanh(double x) {
  static const volatile double tiny = 1.0e-300;
  static const double one = 1.0, two = 2.0, huge = 1.0e300;
  double t, z;
  int32_t jx, ix;

  do { uint64_t bits = bits_of(x); (jx) = bits >> 32; } while (0);
  ix = jx & 0x7FFFFFFF;


  if (ix >= 0x7FF00000) {
    if (jx >= 0)
      return one / x + one;
    else
      return one / x - one;
  }


  if (ix < 0x40360000) {
    if (ix < 0x3E300000) {
      if (huge + x > one) return x;
    }
    if (ix >= 0x3FF00000) {
      t = pts_ieee754_expm1(two * fabs(x));
      z = one - two / (t + two);
    } else {
      t = pts_ieee754_expm1(-two * fabs(x));
      z = -t / (t + two);
    }

  } else {
    z = one - tiny;
  }
  return (jx >= 0) ? z : -z;
}
