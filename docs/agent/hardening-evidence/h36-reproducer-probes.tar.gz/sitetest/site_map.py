#!/usr/bin/env python3
"""site_map.py PREPROCESSED SOURCE: map each pts_site_fma(N, ...) of a clang -E listing to the
source line it came from; prints "N line text" (the number of sites is the largest N + 1)."""
import re
import sys

pre, source = sys.argv[1], sys.argv[2]
src = open(source).read().split("\n")
line_no, cur_file = 0, None
sites = {}
for raw in open(pre):
    m = re.match(r'^# (\d+) "([^"]*)"', raw)
    if m:
        line_no, cur_file = int(m.group(1)), m.group(2)
        continue
    if cur_file and cur_file.endswith("ieee754.c") or (cur_file and cur_file.endswith(".c")):
        for n in re.findall(r"pts_site_fma\((\d+),", raw):
            sites.setdefault(int(n), (line_no, cur_file))
    line_no += 1
for n in sorted(sites):
    ln, f = sites[n]
    text = src[ln - 1].strip() if f.endswith(source.split("/")[-1]) else "(" + f + ")"
    print(n, ln, text)
