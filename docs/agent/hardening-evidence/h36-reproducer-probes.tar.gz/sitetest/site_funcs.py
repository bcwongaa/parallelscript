#!/usr/bin/env python3
"""site_funcs.py SOURCE SITEMAP: for each site, the enclosing C function and the Math functions whose
results it can reach (callers included); prints "site cfunction mathfn1,mathfn2,...". """
import re
import sys

src = open(sys.argv[1]).read().split("\n")
starts = []
for i, line in enumerate(src, 1):
    m = re.match(r"^(?:static (?:inline )?)?(?:double|int32_t|int) (\w+)\(", line)
    if m and (line.rstrip().endswith("{") or (i < len(src) and src[i].rstrip().endswith("{"))):
        starts.append((i, m.group(1)))
CALLERS = {  # helpers and the Math functions that call each one
    "__ieee754_rem_pio2": ["sin", "cos", "tan"], "__kernel_rem_pio2": ["sin", "cos", "tan"],
    "__kernel_cos": ["sin", "cos"], "__kernel_sin": ["sin", "cos"], "__kernel_tan": ["tan"],
    "k_log1p_sum": ["log2"],
    "log": ["log", "acosh", "asinh", "log10"], "log1p": ["log1p", "acosh", "asinh", "atanh"],
    "atan": ["atan", "atan2"], "exp": ["exp", "cosh", "sinh"], "expm1": ["expm1", "cosh", "sinh", "tanh"],
}
for line in open(sys.argv[2]):
    site, ln = line.split()[:2]
    ln = int(ln)
    cfun = None
    for start, name in starts:
        if start <= ln:
            cfun = name
    name = cfun[len("pts_ieee754_"):] if cfun.startswith("pts_ieee754_") else cfun
    print(site, cfun, ",".join(CALLERS.get(name, [name])))
