/* Site-sensitivity build: every PTS_V8_FMA is fused (as on arm64 Linux) except the one numbered
 * pts_site_disabled, which is computed unfused (as on x86-64). Sites are numbered by __COUNTER__. */
#ifndef PTS_V8_FMA_INTERNAL_H
#define PTS_V8_FMA_INTERNAL_H
extern int pts_site_disabled;
static inline double pts_site_fma(int id, double a, double b, double c) {
  return id == pts_site_disabled ? a * b + c : __builtin_fma(a, b, c);
}
#define PTS_V8_FMA(a, b, c) pts_site_fma(__COUNTER__, (a), (b), (c))
#endif
