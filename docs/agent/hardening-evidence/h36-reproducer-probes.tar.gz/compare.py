#!/usr/bin/env python3
"""compare.py INDIR REFDIR DIR... : mismatch counts per function of each DIR against REFDIR.

Two results match when their bits are equal or both are NaN. Prints a table (functions x dirs);
with --examples N, prints up to N mismatching inputs per function for the first DIR.
"""
import struct
import sys
from array import array

FUNCS = ["acos", "acosh", "asin", "asinh", "atan", "atan2", "atanh", "cbrt", "cos", "cosh", "exp", "expm1", "log",
         "log10", "log1p", "log2", "sin", "sinh", "tan", "tanh"]


def load(path):
    a = array("d")
    with open(path, "rb") as f:
        a.frombytes(f.read())
    return a


def bits(d):
    return struct.unpack("<Q", struct.pack("<d", d))[0]


def same(a, b):
    return (a != a and b != b) or bits(a) == bits(b)


def main():
    args = sys.argv[1:]
    examples = 0
    if args[0] == "--examples":
        examples = int(args[1])
        args = args[2:]
    indir, ref, dirs = args[0], args[1], args[2:]
    print("%-8s %7s " % ("function", "inputs") + " ".join("%14s" % d.rstrip("/").split("/")[-1][:14] for d in dirs))
    totals = [0] * len(dirs)
    shown = []
    for fn in FUNCS:
        r = load(f"{ref}/{fn}.bin")
        x = load(f"{indir}/{fn}.bin")
        counts = []
        for k, d in enumerate(dirs):
            v = load(f"{d}/{fn}.bin")
            assert len(v) == len(r), (d, fn)
            c = 0
            for i in range(len(r)):
                if not same(r[i], v[i]):
                    c += 1
                    if k == 0 and examples and sum(1 for s in shown if s[0] == fn) < examples:
                        arg = (x[2 * i], x[2 * i + 1]) if fn == "atan2" else (x[i],)
                        shown.append((fn, arg, r[i], v[i]))
            counts.append(c)
            totals[k] += c
        print("%-8s %7d " % (fn, len(r)) + " ".join("%14d" % c for c in counts))
    print("%-8s %7s " % ("total", "") + " ".join("%14d" % c for c in totals))
    for fn, arg, want, got in shown:
        print("%s(%s): ref %r (%016x) got %r (%016x)" % (fn, ", ".join(repr(a) for a in arg), want, bits(want), got, bits(got)))


main()
