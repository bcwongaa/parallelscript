#!/usr/bin/env python3
"""sites.py DUMP SOURCE: list GCC's fused multiply-adds (.FMA/.FMS/.FNMA/.FNMS from a
-fdump-tree-widening_mul-lineno dump) by source line and column, with the source line.

.FMA(a, b, c) = a*b + c; .FMS = a*b - c; .FNMA = -(a*b) + c; .FNMS = -(a*b) - c.
Duplicates (the same site in several inlined copies) are folded, with their count.
"""
import re
import sys
from collections import OrderedDict, defaultdict

dump, source = sys.argv[1], sys.argv[2]
lines = open(source).read().split("\n")
pat = re.compile(r"\[[^\]]*?:(\d+):(\d+)(?: discrim \d+)?\] (\S+) = \.(FMA|FMS|FNMA|FNMS) \(([^;]*)\);")
sites = OrderedDict()
func = None
funcs = defaultdict(set)
for line in open(dump):
    m = re.match(r"^;; Function (\S+)", line)
    if m:
        func = m.group(1)
        continue
    m = pat.search(line)
    if not m:
        continue
    ln, col, lhs, op, args = int(m.group(1)), int(m.group(2)), m.group(3), m.group(4), m.group(5)
    args = re.sub(r"(\d\.\d{16})\d+e", r"\1..e", args)
    key = (ln, col, op)
    sites.setdefault(key, []).append((func, lhs, args))
    funcs[key].add(func)
by_line = OrderedDict()
for key in sorted(sites):
    by_line.setdefault(key[0], []).append(key)
print("%d sites on %d lines" % (len(sites), len(by_line)))
for ln, keys in by_line.items():
    print("%5d| %s" % (ln, lines[ln - 1].strip()))
    for key in keys:
        uses = sites[key]
        f = ",".join(sorted(funcs[key]))
        print("       col %-3d %-4s x%d %s  in %s" % (key[1], key[2], len(uses), uses[0][2], f))
