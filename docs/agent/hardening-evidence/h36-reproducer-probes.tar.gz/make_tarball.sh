#!/bin/bash
# Pack the probes: scripts, harnesses, sources, site lists, disassemblies, probe programs and their outputs,
# the 2.4M-input set with both Nodes' results, vectors, patches, logs. Left out (rebuildable; sha256 in
# EXCLUDED.sha256): the 4.8M-per-function set and its results, the other variants' results on the 2.4M set,
# binaries, the runtime cache, the HEAD home snapshot and the downloaded GCC 12 packages.
set -euo pipefail
cd /tmp/pts-h36/repro
rm -f h36-reproducer-probes.tar.gz
{
  for d in inputs_big out/big_node_arm64 out/big_node_x86 out/big_proto_a64 out/big_proto_x86 out/big_head_x86 out/site_base_big \
           out/a_clang_off out/b_clang_pragma_fast out/b2_clang_fast out/c_clang_on out/c2_clang_stdc_on out/d_gcc_O2_fast \
           out/d_gcc_O3_fast out/d_gcc_O2_off out/d12_gcc12_O3_fast out/x_clang_off out/proto_a64 out/proto_x86 out/site_base; do
    sha256sum "$d"/*.bin
  done
  sha256sum gcc12/debs/*.deb
} > EXCLUDED.sha256
tar czf /tmp/pts-h36/h36-reproducer-probes.tar.gz.tmp \
  --exclude='./inputs_big' --exclude='./out/big_*' --exclude='./out/site_base_big' --exclude='./out/site_base' \
  --exclude='./out/a_clang_off' --exclude='./out/b_clang_pragma_fast' --exclude='./out/b2_clang_fast' \
  --exclude='./out/c_clang_on' --exclude='./out/c2_clang_stdc_on' --exclude='./out/d_gcc_O2_fast' \
  --exclude='./out/d_gcc_O3_fast' --exclude='./out/d_gcc_O2_off' --exclude='./out/d12_gcc12_O3_fast' \
  --exclude='./out/x_clang_off' --exclude='./out/proto_a64' --exclude='./out/proto_x86' \
  --exclude='./bin' --exclude='./cache' --exclude='./home_head' --exclude='./gcc12/debs' --exclude='./gcc12/root' \
  --exclude='./probes/bin' --exclude='./cmpbits' --exclude='./sitetest/site_harness' --exclude='./sitetest/*.o' \
  --exclude='./probes_extra/estimate_power' --exclude='./h36-reproducer-probes.tar.gz' \
  .
mv /tmp/pts-h36/h36-reproducer-probes.tar.gz.tmp h36-reproducer-probes.tar.gz && ls -la h36-reproducer-probes.tar.gz
