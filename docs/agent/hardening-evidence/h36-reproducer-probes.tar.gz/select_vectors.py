#!/usr/bin/env python3
"""select_vectors.py SITES_TXT PER_SITE OUT_JSON: pick up to PER_SITE inputs per site from the site
harness's records (preferring different functions), as JSON [{site, fn, args:[hex...], fused, unfused}]."""
import json
import sys
from collections import defaultdict

recs = defaultdict(list)
for line in open(sys.argv[1]):
    if line.startswith("#"):
        continue
    site, fn, idx, args, fused, unfused = line.split()
    recs[int(site)].append({"site": int(site), "fn": fn, "args": args.split(","), "fused": fused, "unfused": unfused})
per = int(sys.argv[2])
out = []
for site in sorted(recs):
    chosen, fns = [], set()
    for r in recs[site]:  # one per function first, then more
        if r["fn"] not in fns:
            chosen.append(r)
            fns.add(r["fn"])
        if len(chosen) == per:
            break
    for r in recs[site]:
        if len(chosen) == per:
            break
        if r not in chosen:
            chosen.append(r)
    out.extend(chosen)
json.dump(out, open(sys.argv[3], "w"), indent=0)
print(len(out), "vectors for", len(recs), "sites")
