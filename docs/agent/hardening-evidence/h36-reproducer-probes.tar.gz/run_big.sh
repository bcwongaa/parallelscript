#!/bin/bash
# The 4.8M-inputs-per-function set: arm64 Node, the prototype for aarch64 (qemu) and x86-64, HEAD for x86-64, x86 Node.
set -uo pipefail
cd /tmp/pts-h36/repro
export QEMU_LD_PREFIX=/usr/aarch64-linux-gnu
bash build_proto.sh > out/build_proto_big.log 2>&1 || { echo "build failed"; exit 1; }
clang --target=aarch64-linux-gnu bin/harness_a64.o bin/a_clang_off.o -lm -o bin/a_clang_off
clang bin/harness_x86.o bin/head_x86.o -lm -o bin/head_x86
for d in big_node_arm64 big_node_x86 big_proto_a64 big_proto_x86 big_head_x86; do mkdir -p out/$d; done
/usr/bin/time -f "node arm64 %es" /tmp/pts-h36/arm64-node-bin/node --max-old-space-size=4096 node_harness.mjs inputs_big out/big_node_arm64
/usr/bin/time -f "node x86 %es" /home/bryan/.local/node/bin/node --max-old-space-size=4096 node_harness.mjs inputs_big out/big_node_x86
/usr/bin/time -f "proto a64 %es" ./bin/proto_a64 inputs_big out/big_proto_a64
/usr/bin/time -f "proto x86 %es" ./bin/proto_x86 inputs_big out/big_proto_x86
/usr/bin/time -f "head x86 %es" ./bin/head_x86 inputs_big out/big_head_x86
echo "== arm64 Node vs: prototype-aarch64, all-fused computed natively (site harness)"
python3 -I compare.py inputs_big out/big_node_arm64 out/big_proto_a64 out/site_base_big
echo "== x86 Node vs: prototype-x86, HEAD-x86"
python3 -I compare.py inputs_big out/big_node_x86 out/big_proto_x86 out/big_head_x86
