// node node_harness.mjs INDIR OUTDIR: the same as harness.c, with Node's Math.
import { readFileSync, writeFileSync } from "node:fs";

const [indir, outdir] = process.argv.slice(2);
const unaries = ["acos", "acosh", "asin", "asinh", "atan", "atanh", "cbrt", "cos", "cosh", "exp", "expm1", "log",
  "log10", "log1p", "log2", "sin", "sinh", "tan", "tanh"];

function read(name) {
  const b = readFileSync(`${indir}/${name}.bin`);
  return new Float64Array(b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength));
}

for (const name of unaries) {
  const x = read(name);
  const r = new Float64Array(x.length);
  const f = Math[name];
  for (let i = 0; i < x.length; i++) r[i] = f(x[i]);
  writeFileSync(`${outdir}/${name}.bin`, new Uint8Array(r.buffer));
}
const yx = read("atan2");
const r = new Float64Array(yx.length / 2);
for (let i = 0; i < r.length; i++) r[i] = Math.atan2(yx[2 * i], yx[2 * i + 1]);
writeFileSync(`${outdir}/atan2.bin`, new Uint8Array(r.buffer));
