/* V8's BignumDtoa EstimatePower, fused (Node's arm64 build fuses it: 1 fmadd in BignumDtoa) and not,
 * for every exponent a double's significand can have: does the estimate ever differ? */
#include <math.h>
#include <stdio.h>

int main(void) {
  const double k1Log10 = 0.30102999566398114;
  int differ = 0;
  for (int exponent = -1200; exponent <= 1100; exponent++) {
    double unfused = ceil((double)(exponent + 53 - 1) * k1Log10 - 1e-10);
    double fused = ceil(fma((double)(exponent + 53 - 1), k1Log10, -1e-10));
    if (unfused != fused) {
      printf("exponent %d: unfused %g fused %g\n", exponent, unfused, fused);
      differ++;
    }
  }
  printf("exponents where the estimate differs: %d\n", differ);
  return 0;
}
