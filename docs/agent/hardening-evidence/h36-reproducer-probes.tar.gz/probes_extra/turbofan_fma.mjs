// Does V8's optimizing compiler (or Maglev/Sparkplug) fuse a * b + c in user code on arm64?
// a*b+c with a = b = 1 + 2^-30, c = -(1 + 2^-29): unfused 0, fused 2^-60.
function f(a, b, c) { return a * b + c; }
function g(a, b, c) { return c - a * b; }
const a = 1 + 2 ** -30, c = -(1 + 2 ** -29);
console.log("interpreted", f(a, a, c), g(a, a, -c));
%PrepareFunctionForOptimization(f);
%PrepareFunctionForOptimization(g);
for (let i = 0; i < 1000; i++) { f(i, 1.5, 2); g(i, 1.5, 2); }
%OptimizeMaglevOnNextCall(f);
%OptimizeMaglevOnNextCall(g);
console.log("maglev", f(a, a, c), g(a, a, -c));
%OptimizeFunctionOnNextCall(f);
%OptimizeFunctionOnNextCall(g);
console.log("turbofan", f(a, a, c), g(a, a, -c), %GetOptimizationStatus(f).toString(2));
// A hot loop the tiers reach by themselves.
function h(xs) { let s = 0; for (let i = 0; i < xs.length; i++) s += xs[i] * xs[i] + c; return s; }
const xs = new Float64Array(1000).fill(a);
let last = 0;
for (let k = 0; k < 2000; k++) last = h(xs);
console.log("hot loop", last, %GetOptimizationStatus(h).toString(2));
