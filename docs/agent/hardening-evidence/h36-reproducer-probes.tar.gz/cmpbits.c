/* cmpbits REFDIR DIR...: per-function mismatch counts of each DIR's results against REFDIR's
 * (raw doubles, <fn>.bin), both-NaN counted as equal; the C twin of compare.py for large sets. */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char *funcs[] = {"acos", "acosh", "asin", "asinh", "atan", "atan2", "atanh", "cbrt", "cos", "cosh",
                              "exp", "expm1", "log", "log10", "log1p", "log2", "sin", "sinh", "tan", "tanh"};

static uint64_t *load(const char *dir, const char *fn, size_t *n) {
  char path[4096];
  snprintf(path, sizeof path, "%s/%s.bin", dir, fn);
  FILE *f = fopen(path, "rb");
  if (!f) {
    perror(path);
    exit(2);
  }
  fseek(f, 0, SEEK_END);
  long size = ftell(f);
  fseek(f, 0, SEEK_SET);
  uint64_t *data = malloc((size_t)size);
  if (fread(data, 1, (size_t)size, f) != (size_t)size) {
    exit(2);
  }
  fclose(f);
  *n = (size_t)size / 8;
  return data;
}

static int is_nan(uint64_t b) { return ((b >> 52) & 0x7FF) == 0x7FF && (b & ((1ULL << 52) - 1)) != 0; }

int main(int argc, char **argv) {
  printf("%-8s %9s", "function", "results");
  for (int k = 2; k < argc; k++) {
    const char *base = strrchr(argv[k], '/');
    printf(" %14.14s", base ? base + 1 : argv[k]);
  }
  printf("\n");
  long totals[64] = {0};
  for (size_t f = 0; f < sizeof funcs / sizeof funcs[0]; f++) {
    size_t n;
    uint64_t *ref = load(argv[1], funcs[f], &n);
    printf("%-8s %9zu", funcs[f], n);
    for (int k = 2; k < argc; k++) {
      size_t m;
      uint64_t *v = load(argv[k], funcs[f], &m);
      long c = 0;
      for (size_t i = 0; i < n && i < m; i++) {
        if (ref[i] != v[i] && !(is_nan(ref[i]) && is_nan(v[i]))) {
          c++;
        }
      }
      if (m != n) {
        c = -1;
      }
      totals[k] += c;
      printf(" %14ld", c);
      free(v);
    }
    printf("\n");
    free(ref);
  }
  printf("%-8s %9s", "total", "");
  for (int k = 2; k < argc; k++) {
    printf(" %14ld", totals[k]);
  }
  printf("\n");
  return 0;
}
