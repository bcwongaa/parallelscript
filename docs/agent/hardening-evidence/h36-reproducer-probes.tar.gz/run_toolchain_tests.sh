#!/bin/bash
# Focused upstream-of-change tests on the prototype: the runtime's C unit tests under sanitizers, the
# runtime's aarch64 cross build, number formatting, and cmd/pts's target tests (qemu for aarch64).
OUT=$1
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a115bda57afdd6198
export GOMAXPROCS=4 PTS_CACHE_DIR=/tmp/pts-h36/repro/cache QEMU_LD_PREFIX=/usr/aarch64-linux-gnu PTS_REQUIRE_CROSS=1
: > "$OUT"
echo "=== pts/toolchain" >> "$OUT"
go test -count=1 -timeout 30m -run 'TestRuntimeUnitTestsPassUnderSanitizers|TestRuntimeBuildsAndRunsForAarch64|TestNumberFormattingMatchesJavaScript' ./pts/toolchain/ -v >> "$OUT" 2>&1
echo "exit=$? (pts/toolchain)" >> "$OUT"
echo "=== cmd/pts" >> "$OUT"
go test -count=1 -timeout 30m -run 'Aarch64|Target' ./cmd/pts/ -v >> "$OUT" 2>&1
echo "exit=$? (cmd/pts)" >> "$OUT"
