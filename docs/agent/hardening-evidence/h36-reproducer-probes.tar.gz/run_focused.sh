#!/bin/bash
# The parent's focused RED command, run in the reproducer's worktree (its runtime is the one under test).
#   usage: run_focused.sh OUTFILE [aarch64|x86]
OUT=$1
ARCH=${2:-aarch64}
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a115bda57afdd6198
export GOMAXPROCS=4 PTS_REQUIRE_NODE=1 PTS_CACHE_DIR=/tmp/pts-h36/repro/cache
if [ "$ARCH" = aarch64 ]; then
  export PATH=/tmp/pts-h36/arm64-node-bin:$PATH PTS_TARGET=aarch64-linux QEMU_LD_PREFIX=/usr/aarch64-linux-gnu
else
  export PATH=/home/bryan/.local/node/bin:$PATH
fi
echo "node: $(command -v node) $(node -p 'process.arch')" > "$OUT"
[ -n "${3:-}" ] && export PTS_HOME=$3
echo "PTS_HOME=${PTS_HOME:-(worktree)}" >> "$OUT"
go test -v -count=1 -timeout 30m -run 'TestGeneratedNumberCorpusMatchesNode|TestRunMatchesNode/(number_library|math_library)$' ./pts/tests/ >> "$OUT" 2>&1
echo "exit=$?" >> "$OUT"
