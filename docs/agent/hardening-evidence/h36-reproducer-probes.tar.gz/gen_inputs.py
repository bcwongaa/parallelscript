#!/usr/bin/env python3
"""Generate the Math input sets: inputs/<fn>.bin as raw little-endian doubles (atan2: y, x pairs).

Per function (>= 120,000 inputs):
  30,000 uniform 64-bit patterns (NaN, infinities, subnormals included),
  20,000 in the generated corpus's style (pts/tests/numbers_test.go randomNumber and the math part's
         (rand - 0.5) * 10^k),
  70,000 dense samples around the thresholds where the function's reduction/polynomial branches are,
         at spreads from a few ulps to the width of the branch.
Deterministic (seeded).
"""
import math
import random
import struct
import sys
from array import array

OUT = sys.argv[1] if len(sys.argv) > 1 else "inputs"
rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 20261026)


def from_bits(b):
    return struct.unpack("<d", struct.pack("<Q", b & 0xFFFFFFFFFFFFFFFF))[0]


def bits(d):
    return struct.unpack("<Q", struct.pack("<d", d))[0]


def uniform_bits():
    return from_bits(rng.getrandbits(64))


def corpus_style(i):
    k = i % 5
    if k == 0:
        while True:
            v = uniform_bits()
            if not (math.isnan(v) or math.isinf(v)):
                return v
    if k == 1:
        return float(rng.randrange(201) - 100)
    if k == 2:
        return float(rng.randrange(2_000_000) - 1_000_000) / math.pow(10, rng.randrange(30) - 8)
    if k == 3:
        return math.ldexp(1 + rng.random(), rng.randrange(2098) - 1074)
    return (rng.random() - 0.5) * math.pow(10, rng.randrange(5))


def ulps_from(c, n):
    """c moved by n ulps (n may be negative)."""
    if c == 0:
        return from_bits(abs(n)) * (1 if n >= 0 else -1)
    b = bits(abs(c)) + n
    if b < 0:
        b = 0
    v = from_bits(b)
    return v if c > 0 else -v


def around(c, n_samples, out, signed=True):
    """Samples around c: ulp steps, relative spreads 2^-50 .. 2^-1, both signs if signed."""
    for _ in range(n_samples):
        r = rng.random()
        if r < 0.25:
            v = ulps_from(c, rng.randrange(-4096, 4097))
        else:
            spread = math.ldexp(1, -rng.randrange(1, 51))
            v = c * (1 + (rng.random() * 2 - 1) * spread) if c != 0 else (rng.random() * 2 - 1) * spread
        if signed and rng.random() < 0.5:
            v = -v
        out.append(v)


def interval(lo, hi, n_samples, out, signed=True, log=False):
    for _ in range(n_samples):
        if log:
            v = math.exp(math.log(lo) + rng.random() * (math.log(hi) - math.log(lo)))
        else:
            v = lo + rng.random() * (hi - lo)
        if signed and rng.random() < 0.5:
            v = -v
        out.append(v)


def magnitudes(n_samples, out, lo_exp=-1074, hi_exp=1023, signed=True):
    for _ in range(n_samples):
        v = math.ldexp(1 + rng.random(), rng.randrange(lo_exp, hi_exp + 1))
        if math.isinf(v):
            continue
        if signed and rng.random() < 0.5:
            v = -v
        out.append(v)


def thresholds(points, total, out, signed=True):
    per = max(1, total // len(points))
    for c in points:
        around(c, per, out, signed)


PI = math.pi
LN2 = math.log(2)
TINY = [math.ldexp(1, -28), math.ldexp(1, -27), math.ldexp(1, -29), math.ldexp(1, -54), math.ldexp(1, -26), math.ldexp(1, -33),
        math.ldexp(1, -57), math.ldexp(1, -1022), math.ldexp(1, -1074) * 12345]


def trig_dense(out):
    # |x| <= pi/4 kernel; the medium reduction (< 2^20 * pi/2) near multiples of pi/2; huge arguments (kernel_rem_pio2).
    interval(0, PI / 4, 8000, out)
    thresholds([PI / 4, 3 * PI / 4, 5 * PI / 4, 0.6744, 0.67434, 0.78125, 0.3, 0.5, 1.0] + TINY, 10000, out)
    for _ in range(16000):
        k = rng.randrange(1, 1 << 20) if rng.random() < 0.7 else rng.randrange(1, 64)
        c = k * PI / 2
        out.append(ulps_from(c, rng.randrange(-200, 201)) * (1 if rng.random() < 0.5 else -1))
    for _ in range(10000):  # near multiples of pi/2 with k up to 2^60 (big reductions)
        k = rng.getrandbits(rng.randrange(20, 61)) | 1
        out.append(ulps_from(k * PI / 2, rng.randrange(-8, 9)) * (1 if rng.random() < 0.5 else -1))
    thresholds([math.ldexp(1, 20) * PI / 2, 2 ** 19 * PI / 2], 2000, out)
    interval(-1e4, 1e4, 10000, out, signed=False)
    magnitudes(14000, out, -60, 1023)


def asin_acos_dense(out):
    interval(0, 0.5, 12000, out)
    interval(0.5, 0.975, 12000, out)
    interval(0.975, 1.0, 12000, out)
    for _ in range(10000):
        out.append(ulps_from(1.0, -rng.randrange(1, 1 << 30)) * (1 if rng.random() < 0.5 else -1))
    thresholds([0.5, 0.975, 1.0, 0.25, 0.75] + TINY, 16000, out)
    magnitudes(8000, out, -1074, 0)


def atan_dense(out):
    thresholds([7 / 16, 11 / 16, 19 / 16, 39 / 16, 2 ** 66, 2 ** 64, 1.0, 0.5, 1.5] + TINY, 30000, out)
    interval(0, 7 / 16, 8000, out)
    interval(7 / 16, 11 / 16, 8000, out)
    interval(11 / 16, 19 / 16, 8000, out)
    interval(19 / 16, 39 / 16, 8000, out)
    interval(39 / 16, 1e6, 4000, out, log=True)
    magnitudes(4000, out)


def exp_dense(out):
    interval(-745.2, 709.8, 15000, out, signed=False)
    interval(-1, 1, 10000, out, signed=False)
    thresholds([0.5 * LN2, 1.5 * LN2, 709.782712893384, 745.1332191019411, 708.39641853226408, 1.0, 22.0, 56 * LN2, LN2] + TINY,
               30000, out)
    for _ in range(10000):
        k = rng.randrange(-1100, 1100)
        out.append(ulps_from(k * LN2, rng.randrange(-100, 101)) if k else rng.random() * 1e-10)
    magnitudes(5000, out, -80, 12)


def log_dense(out):
    magnitudes(15000, out, -1074, 1023, signed=False)
    interval(0.5, 2, 15000, out, signed=False)
    thresholds([1.0, math.sqrt(2), math.sqrt(2) / 2, 2.0, 0.5, 10.0, 0.1, math.e, 1 + 2 ** -20, math.ldexp(1, -1022)], 25000, out,
               signed=False)
    for _ in range(15000):
        out.append(1 + (rng.random() * 2 - 1) * math.ldexp(1, -rng.randrange(1, 53)))


def log1p_dense(out):
    interval(-0.2929, 0.41422, 15000, out, signed=False)
    interval(-1, 1, 10000, out, signed=False)
    thresholds([-1.0, -0.2929, 0.41422, math.sqrt(2) - 1, 2 ** 53, 2 ** 29, 1.0, 0.5] + TINY, 30000, out, signed=False)
    magnitudes(15000, out, -80, 1023, signed=False)


def hyper_dense(out):
    interval(0, 22, 15000, out)
    interval(22, 710.5, 8000, out)
    thresholds([0.5 * LN2, 1.0, 22.0, 709.782712893384, 710.4758600739439, 0.55, 2.0, 0.25] + TINY, 30000, out)
    interval(-2, 2, 12000, out, signed=False)
    magnitudes(5000, out, -80, 12)


def asinh_dense(out):
    interval(0, 2, 15000, out)
    interval(2, 2 ** 28, 10000, out, log=True)
    thresholds([2.0, 2 ** 28, 0.5, 1.0, 0.25] + TINY, 25000, out)
    interval(-1, 1, 12000, out, signed=False)
    magnitudes(8000, out)


def acosh_dense(out):
    interval(1, 2, 15000, out, signed=False)
    interval(2, 2 ** 28, 15000, out, signed=False, log=True)
    thresholds([1.0, 2.0, 2 ** 28, 1.5], 25000, out, signed=False)
    for _ in range(10000):
        out.append(ulps_from(1.0, rng.randrange(0, 1 << 30)))
    magnitudes(5000, out, 0, 1023, signed=False)


def atanh_dense(out):
    interval(0, 0.5, 15000, out)
    interval(0.5, 1, 15000, out)
    thresholds([0.5, 1.0, 0.25, 0.75] + TINY, 25000, out)
    for _ in range(10000):
        out.append(ulps_from(1.0, -rng.randrange(1, 1 << 30)) * (1 if rng.random() < 0.5 else -1))
    magnitudes(5000, out, -1074, 0)


def cbrt_dense(out):
    magnitudes(40000, out)
    interval(-10, 10, 15000, out, signed=False)
    thresholds([1.0, 8.0, 27.0, 0.125, math.ldexp(1, -1022), math.ldexp(1, -1060)], 15000, out)


DENSE = {
    "sin": trig_dense, "cos": trig_dense, "tan": trig_dense,
    "asin": asin_acos_dense, "acos": asin_acos_dense, "atan": atan_dense,
    "exp": exp_dense, "expm1": exp_dense,
    "log": log_dense, "log2": log_dense, "log10": log_dense, "log1p": log1p_dense,
    "sinh": hyper_dense, "cosh": hyper_dense, "tanh": hyper_dense,
    "asinh": asinh_dense, "acosh": acosh_dense, "atanh": atanh_dense, "cbrt": cbrt_dense,
}


PINNED = {  # the CI and the parent's residual cases
    "tan": [-4503.8727210219895], "sinh": [-0.20922595734114824], "atanh": [-0.09822103850138031],
    "atan": [-0.25420467463499796, -0.2330663164060135], "asinh": [-0.256649382199552],
}


def unary_set(name):
    out = list(PINNED.get(name, []))
    for _ in range(30000):
        out.append(uniform_bits())
    for i in range(20000):
        out.append(corpus_style(i))
    dense = []
    DENSE[name](dense)
    out.extend(dense)
    while len(out) < 120000:
        out.append(corpus_style(len(out)))
    return out


def atan2_set():
    pairs = []
    for _ in range(30000):
        pairs.append((uniform_bits(), uniform_bits()))
    for i in range(20000):
        pairs.append((corpus_style(i), corpus_style(i + 1)))
    for _ in range(20000):  # ratios near atan's thresholds and in every quadrant
        t = rng.choice([7 / 16, 11 / 16, 19 / 16, 39 / 16, 1.0, 0.5, 2.0, 1e-20, 1e20, rng.random() * 4])
        t *= 1 + (rng.random() * 2 - 1) * math.ldexp(1, -rng.randrange(1, 40))
        x = math.ldexp(1 + rng.random(), rng.randrange(-30, 30))
        pairs.append((t * x * rng.choice([1, -1]), x * rng.choice([1, -1])))
    for _ in range(10000):  # x == 1, exponent differences near 60
        y = math.ldexp(1 + rng.random(), rng.randrange(-70, 70)) * rng.choice([1, -1])
        x = 1.0 if rng.random() < 0.5 else math.ldexp(1 + rng.random(), rng.randrange(-70, 70)) * rng.choice([1, -1])
        pairs.append((y, x))
    for _ in range(40000):
        pairs.append(((rng.random() * 2 - 1) * 10 ** rng.randrange(0, 5), (rng.random() * 2 - 1) * 10 ** rng.randrange(0, 5)))
    flat = []
    for y, x in pairs:
        flat.extend((y, x))
    return flat


def write(name, values):
    a = array("d", values)
    if sys.byteorder != "little":
        a.byteswap()
    with open(f"{OUT}/{name}.bin", "wb") as f:
        a.tofile(f)
    return len(a)


for name in DENSE:
    n = write(name, unary_set(name))
    print(name, n)
print("atan2", write("atan2", atan2_set()) // 2, "pairs")
