#!/bin/bash
# Build the harness against the prototype (the worktree's ieee754.c with PTS_V8_FMA), for aarch64 and x86-64,
# with the runtime's flags (-ffp-contract=off), plus a GCC 12 -O3 -ffp-contract=off object to compare op counts.
set -euo pipefail
cd /tmp/pts-h36/repro
SRC=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a115bda57afdd6198/pts/runtime/src/ieee754.c
NAME=${NAME:-proto}
PTSFLAGS="-O2 -g -ffp-contract=off -fno-math-errno -falign-functions=32 -std=c11 -Wall -Wextra"
A64="--target=aarch64-linux-gnu"
clang $A64 $PTSFLAGS -Istub -c "$SRC" -o bin/${NAME}_a64.o
clang $A64 bin/harness_a64.o bin/${NAME}_a64.o -lm -o bin/${NAME}_a64
aarch64-linux-gnu-objdump -d -C --no-show-raw-insn bin/${NAME}_a64.o > disasm/${NAME}_a64.s
clang $PTSFLAGS -Istub -c "$SRC" -o bin/${NAME}_x86.o
clang bin/harness_x86.o bin/${NAME}_x86.o -lm -o bin/${NAME}_x86
# x86-64 code must not change: compare with HEAD's object built the same way (instructions only).
clang $PTSFLAGS -Istub -c src/ieee754_head.c -o bin/head_x86.o
gcc12/root/usr/bin/aarch64-linux-gnu-gcc-12 -O3 -g -fno-strict-aliasing -ffp-contract=off -Istub \
  -isystem /usr/lib/gcc-cross/aarch64-linux-gnu/13/include -isystem /usr/aarch64-linux-gnu/include -S "$SRC" -o gcc12/${NAME}_O3_off.s
aarch64-linux-gnu-as gcc12/${NAME}_O3_off.s -o gcc12/${NAME}_O3_off.o
aarch64-linux-gnu-objdump -d -C --no-show-raw-insn gcc12/${NAME}_O3_off.o > disasm/gcc12_${NAME}_O3_off.s
echo built
