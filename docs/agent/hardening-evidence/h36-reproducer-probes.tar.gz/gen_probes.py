#!/usr/bin/env python3
"""Generate the JS-level probe programs (valid TypeScript for pts and JavaScript for Node):
probes/<name>.pts, one console.log per line, literals only (so both sides parse the same values).
"""
import math
import random
import struct
import sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "probes"
rng = random.Random(36)
DIGITS = "0123456789abcdefghijklmnopqrstuvwxyz"


def lit(v):
    if v != v:
        return "NaN"
    if v == math.inf:
        return "Infinity"
    if v == -math.inf:
        return "-Infinity"
    if v == 0 and math.copysign(1, v) < 0:
        return "-0"
    r = repr(v)
    return r


def from_bits(b):
    return struct.unpack("<d", struct.pack("<Q", b))[0]


def random_number(i):
    k = i % 5
    if k == 0:
        while True:
            v = from_bits(rng.getrandbits(64))
            if v == v and not math.isinf(v):
                return v
    if k == 1:
        return float(rng.randrange(201) - 100)
    if k == 2:
        return float(rng.randrange(2_000_000) - 1_000_000) / math.pow(10, rng.randrange(30) - 8)
    if k == 3:
        return math.ldexp(1 + rng.random(), rng.randrange(-60, 200))
    return (rng.random() - 0.5) * math.pow(10, rng.randrange(8))


def write(name, lines):
    with open(f"{OUT}/{name}.pts", "w") as f:
        f.write("\n".join(lines) + "\n")
    print(name, len(lines))


# parseInt in every radix with long digit strings (V8's generic case for radixes that are not powers of two).
lines = []
for i in range(3000):
    r = 2 + i % 35
    n = rng.choice([rng.randrange(1, 12), rng.randrange(12, 40), rng.randrange(40, 120), rng.randrange(120, 400)])
    s = "".join(DIGITS[rng.randrange(r)] for _ in range(n))
    if rng.random() < 0.2:
        s = s.upper()
    if rng.random() < 0.1:
        s = "0" * rng.randrange(1, 10) + s
    if rng.random() < 0.1:
        s = "-" + s
    lines.append(f'console.log(parseInt("{s}", {r}));')
lines.append('console.log(parseInt("1877849bg6cba000000000000000000000000", 23));')
write("parseint", lines)

# toString(radix) of integers and fractions, and parseInt of the result.
lines = []
for i in range(2000):
    x = random_number(i)
    if i % 3 == 0:
        x = rng.random() * 10 ** rng.randrange(-5, 25) * rng.choice([1, -1])
    r = 2 + rng.randrange(35)
    lines.append(f"{{ const x = {lit(x)}; console.log(x.toString({r}), parseInt(x.toString({r}), {r}), parseFloat(x.toString({r}))); }}")
write("radix", lines)

# toFixed / toPrecision / toExponential / toLocaleString / String.
lines = []
for i in range(2000):
    x = random_number(i)
    lines.append(f"{{ const x = {lit(x)}; console.log(x.toFixed({rng.randrange(21)}), x.toPrecision({1 + rng.randrange(21)}), "
                 f"x.toExponential({rng.randrange(21)}), x.toExponential(), x.toLocaleString(), String(x)); }}")
for i in range(500):  # many digits: BignumDtoa paths
    x = random_number(i)
    lines.append(f"{{ const x = {lit(x)}; console.log(x.toFixed(100), x.toPrecision(100), x.toExponential(100)); }}")
write("format", lines)

# parseFloat, Number(string), JSON.
lines = []
for i in range(2000):
    x = random_number(i)
    digits = rng.choice("123456789") + "".join(rng.choice("0123456789") for _ in range(rng.randrange(0, 40)))
    frac = "".join(rng.choice("0123456789") for _ in range(rng.randrange(0, 40)))
    e = rng.randrange(-330, 310)
    s = digits + ("." + frac if frac else "") + f"e{e}"
    lines.append(f'console.log(parseFloat("{s}"), Number("{s}"), JSON.parse("{s}"), JSON.stringify({lit(x)}), Number("{lit(x)}"));')
write("parse", lines)

# hypot, **, pow.
lines = []
for i in range(2000):
    x, y, z = random_number(i), random_number(i + 1), random_number(i + 2)
    if i % 2 == 0:
        x, y, z = [(rng.random() - 0.5) * 10 ** rng.randrange(-3, 6) for _ in range(3)]
    lines.append(f"{{ const x = {lit(x)}; const y = {lit(y)}; const z = {lit(z)}; console.log(Math.hypot(x, y), Math.hypot(x, y, z), "
                 f"x ** y, Math.pow(x, z), Math.pow(Math.abs(x), y), Math.sqrt(Math.abs(x)), Math.fround(x), x * y + z, x * y - z); }}")
write("hypot_pow", lines)

# Date: day counts so large that day * 86400000 is inexact, cancelled by a time of the opposite sign.
lines = []
for i in range(1500):
    d = rng.randrange(106_700_000_000, 10 ** 12) * rng.choice([1, -1])  # day * 86400000 needs > 53 bits
    p = float(d * 86400000)  # the product rounded to a double
    small = rng.randrange(-8 * 10 ** 15, 8 * 10 ** 15)
    ms = -p + small  # a double; the exact time is (d * 86400000 - p) + (ms + p) away from it
    form = i % 6
    if form == 0:
        lines.append(f"console.log(Date.UTC(1970, 0, {d + 1}, 0, 0, 0, {lit(ms)}));")
    elif form == 1:
        lines.append(f"console.log(Date.UTC(1970, 0, {d + 1}, {-24 * d}));")
    elif form == 2:
        lines.append(f"console.log(Date.UTC(1970, 0, {d + 1}, 0, {-1440 * d + rng.randrange(-10 ** 9, 10 ** 9)}));")
    elif form == 3:
        lines.append(f"console.log(new Date(Date.UTC(1970, 0, {d + 1}, 0, 0, {-86400 * d + rng.randrange(-10 ** 11, 10 ** 11)})).getTime());")
    elif form == 4:
        lines.append(f"console.log(new Date(2000, 0, {d + 1}, {-24 * d + rng.randrange(-10 ** 6, 10 ** 6)}).getTime());")
    else:
        y = rng.randrange(-270000, 270000)
        lines.append(f"console.log(Date.UTC({y}, {rng.randrange(-100, 100)}, {d}, 0, 0, 0, {lit(-p)}));")
for i in range(500):  # ordinary dates, setters and parsing
    t = rng.randrange(-8640000000000000, 8640000000000000)
    lines.append(f"{{ const d = new Date({t}); console.log(d.getTime(), d.toISOString(), d.getUTCFullYear(), d.getUTCDate(), d.getUTCHours(), "
                 f"Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() + {rng.randrange(-10 ** 6, 10 ** 6)}, {rng.randrange(-10 ** 6, 10 ** 6)}), "
                 f"d.setUTCDate({rng.randrange(-10 ** 8, 10 ** 8)}), d.setUTCHours({rng.randrange(-10 ** 9, 10 ** 9)}), Date.parse(new Date({t}).toISOString())); }}")
write("date", lines)
