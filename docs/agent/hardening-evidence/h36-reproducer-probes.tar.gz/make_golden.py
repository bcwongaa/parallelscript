#!/usr/bin/env python3
"""make_golden.py program EXPRS OUT.mjs | table EXPRS X64_OUT ARM64_OUT GOLDEN
program: the probe program (first line prints platform-arch, then one console.log per expression).
table:   the golden file: sections as '# ...' lines, then 'expression<TAB>linux-x64<TAB>linux-arm64'."""
import sys

mode = sys.argv[1]
exprs = [l for l in open(sys.argv[2]).read().split("\n") if l]
if mode == "program":
    with open(sys.argv[3], "w") as f:
        f.write('console.log(process.platform + "-" + process.arch);\n')
        for e in exprs:
            if not e.startswith("#"):
                f.write("console.log(%s);\n" % e)
else:
    ox = open(sys.argv[3]).read().split("\n")
    oa = open(sys.argv[4]).read().split("\n")
    assert ox[0] == "linux-x64" and oa[0] == "linux-arm64", (ox[0], oa[0])
    out = ["# Expressions whose results Node 24.21.0 prints differently on x86-64 and arm64 Linux, with each one's output",
           "# (expression, linux-x64, linux-arm64; tab-separated), from Node's official binaries (the arm64 one under qemu-aarch64).",
           "# Node's arm64 build fuses multiply-adds in V8's C++ (GCC's default -ffp-contract=fast); x86-64's has no FMA.",
           "# Sections whose heading says the Nodes differ have different outputs on each line."]
    i = 1
    section = ""
    differ = same = 0
    for e in exprs:
        if e.startswith("#"):
            section = e
            out.append(e)
            continue
        if ox[i] == oa[i]:
            same += 1
            assert "Node differ" not in section, (e, ox[i])
        else:
            differ += 1
        out.append("%s\t%s\t%s" % (e, ox[i], oa[i]))
        i += 1
    open(sys.argv[5], "w").write("\n".join(out) + "\n")
    print("cases:", differ + same, "differ between the architectures:", differ, "same:", same)
