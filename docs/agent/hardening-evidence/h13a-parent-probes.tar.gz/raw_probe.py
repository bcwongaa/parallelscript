#!/usr/bin/env python3
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
label = sys.argv[3]
exe = out / f'{label}-server'
env = os.environ.copy()
env.update(PTS_HOME=str(repo), PTS_THREADS='1', GOMAXPROCS='1')
command = [str(repo / 'pts-bin/pts'), 'build', str(repo / 'pts/tests/http/server.pts'), '-o', str(exe)]
build = subprocess.run(command, env=env, capture_output=True, text=True, timeout=120)
(out / f'{label}-probe-build.json').write_text(json.dumps({'command': command, 'exit':build.returncode,'stdout':build.stdout,'stderr':build.stderr},indent=2)+'\n')
if build.returncode:
    sys.exit(build.returncode)
server = subprocess.Popen([str(exe)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env, start_new_session=True)
rows = []
try:
    line = server.stdout.readline().strip()
    if not line.startswith('listening '):
        raise RuntimeError(f'not listening: {line!r}')
    port = int(line.split()[1])
    cases = [
        ('cl-signed', 'Content-Length: +2\r\n', 'ab'),
        ('cl-negative-zero', 'Content-Length: -0\r\n', ''),
        ('cl-duplicate-equal', 'Content-Length: 2\r\nContent-Length: 2\r\n', 'ab'),
        ('cl-te', 'Content-Length: 2\r\nTransfer-Encoding: chunked\r\n', '2\r\nab\r\n0\r\n\r\n'),
        ('te-chunked-gzip', 'Transfer-Encoding: chunked, gzip\r\n', '2\r\nab\r\n0\r\n\r\n'),
        ('te-unsupported-cl', 'Transfer-Encoding: gzip\r\nContent-Length: 2\r\n', 'ab'),
    ]
    for name, headers, body in cases:
        wire = 'POST /echo HTTP/1.1\r\nHost: loopback\r\n' + headers + '\r\n' + body + 'GET /hello HTTP/1.1\r\nHost: loopback\r\nConnection: close\r\n\r\n'
        response = bytearray()
        error = None
        eof = False
        with socket.create_connection(('127.0.0.1', port), timeout=3) as conn:
            conn.settimeout(3)
            conn.sendall(wire.encode('ascii'))
            try:
                while True:
                    data = conn.recv(65536)
                    if not data:
                        eof = True
                        break
                    response.extend(data)
            except OSError as failure:
                error = repr(failure)
        text = response.decode('latin1')
        passed = eof and text.startswith('HTTP/1.1 400 ') and text.count('HTTP/1.1 ') == 1 and 'connection: close\r\n' in text.lower()
        rows.append({'name':name,'wire':wire,'response':text,'eof':eof,'error':error,'expected':'one400+close','pass':passed})
finally:
    os.killpg(server.pid, signal.SIGKILL)
    stdout, stderr = server.communicate(timeout=10)
    (out / f'{label}-probe-server.json').write_text(json.dumps({'stdout':stdout,'stderr':stderr},indent=2)+'\n')
(out / f'{label}-raw-probes.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'pass':sum(r['pass'] for r in rows),'fail':sum(not r['pass'] for r in rows)},indent=2))
sys.exit(0 if all(r['pass'] for r in rows) else 1)
