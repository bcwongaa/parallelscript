#!/bin/bash
# tri.sh file.pts...: run each program with the snapshot CLI, the base CLI and Node; print the three outputs and diff verdicts
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h08c/review3/tri.XXXX)
  cp "$f" "$d/$b.mts"; mkdir -p "$d/s" "$d/b"
  (cd "$d/s" && PTS_HOME=/tmp/h08c/snap3 timeout 120 /tmp/h08c/snap3/pts-bin/pts run "$f" > ../snap.txt 2>&1; echo "[exit $?]" >> ../snap.txt)
  (cd "$d/b" && PTS_HOME=/tmp/h08c/base timeout 120 /tmp/h08c/base/pts-bin/pts run "$f" > ../base.txt 2>&1; echo "[exit $?]" >> ../base.txt)
  (cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" > node.txt 2>&1; echo "[exit $?]" >> node.txt)
  vs=$(cmp -s $d/snap.txt $d/node.txt && echo MATCH || echo DIFFER); vb=$(cmp -s $d/base.txt $d/node.txt && echo MATCH || echo DIFFER)
  echo "== $b: snap $vs node; base $vb node"
  out=/tmp/h08c/review3/out/$b; mkdir -p $out; cp $d/snap.txt $d/base.txt $d/node.txt $out/
  if [ "$vs" = DIFFER ] || [ -n "$TRI_SHOW" ]; then echo "--- diff snap node"; diff $d/snap.txt $d/node.txt | head -${TRI_LINES:-40}; fi
  if [ -n "$TRI_BASE" ]; then echo "--- diff base node"; diff $d/base.txt $d/node.txt | head -40; fi
  rm -rf "$d"; done
