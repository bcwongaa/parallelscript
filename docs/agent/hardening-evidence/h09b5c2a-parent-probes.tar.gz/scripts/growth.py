"""Serial baseline/current returned-source growth probes; retain receipts, not binaries."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

root, out, base, current = map(lambda p: Path(p).resolve(), sys.argv[1:5])
out.mkdir(parents=True, exist_ok=True)
env = os.environ | {'PTS_HOME': str(root), 'GOMAXPROCS': '1', 'PTS_THREADS': '1'}
node = Path.home() / '.local/node/bin/node'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source(size, unknown):
    lines = ['class Box<T> { constructor(public value: T) {} }',
             'type Factory = <T>(value: T) => Box<T>;']
    for i in range(size):
        lines += [f'class C{i} {{ tag = {i}; }}',
                  f'function source{i}<T>(value: T): Box<T> {{ return new Box(value); }}',
                  f'function use{i}(f: Factory): number {{ const box: Box<C{i}> = f(new C{i}()); return box.value.tag; }}']
    lines.append('const held: any[] = [' + ', '.join(f'source{i}' for i in range(size)) + '];')
    for i in range(size):
        returned = f'held[{i}]' if unknown else f'source{i}'
        lines.append(f'function factory{i}(): Factory {{ return {returned}; }}')
    calls = ' + '.join(f'use{i}(factory{i}())' for i in range(size))
    lines.append(f'console.log("sum", {calls});')
    return '\n'.join(lines) + '\n'


def run(command, prefix, timed=False):
    prefix = Path(prefix)
    actual = list(map(str, command))
    if timed:
        actual = ['/usr/bin/time', '-f', '%e %M', '-o', str(prefix) + '.time', *actual]
    started = time.monotonic()
    result = subprocess.run(actual, cwd=root, env=env, capture_output=True, timeout=300)
    Path(str(prefix) + '.stdout').write_bytes(result.stdout)
    Path(str(prefix) + '.stderr').write_bytes(result.stderr)
    record = {'command': actual, 'exit': result.returncode, 'seconds': time.monotonic() - started,
              'stdout': result.stdout.decode(), 'stderr': result.stderr.decode()}
    if timed:
        wall, rss = Path(str(prefix) + '.time').read_text().split()
        record.update(time_wall_seconds=float(wall), max_rss_kib=int(rss))
    Path(str(prefix) + '.json').write_text(json.dumps(record, indent=2) + '\n')
    assert result.returncode == 0, record
    return record


before = {str(p): sha(p) for p in (base, current)}
results = []
for unknown, sizes in [(False, (10, 30, 60)), (True, (10, 30))]:
    for size in sizes:
        name = ('unknown' if unknown else 'known') + str(size)
        case = out / name
        case.mkdir(exist_ok=True)
        entry = case / 'main.pts'
        entry.write_text(source(size, unknown))
        twin = case / 'main.mts'
        shutil.copyfile(entry, twin)
        oracle = run([node, '--experimental-transform-types', twin], case / 'node')
        expected = f'sum {size * (size - 1) // 2}\n'
        assert oracle['stdout'] == expected, oracle
        c_hashes = {}
        for round_number in (1, 2):
            order = [('base', base), ('current', current)]
            if round_number == 2:
                order.reverse()
            for label, cli in order:
                prefix = case / f'{label}-r{round_number}'
                c = Path(str(prefix) + '.c')
                emit = run([cli, 'emit-c', entry, '-o', c], str(prefix) + '-emit', True)
                generated = c.read_text()
                pairs = set(re.findall(r'\bpts_fn_source(\d+)_C(\d+)\(', generated))
                want = size * size if unknown or label == 'base' else size
                assert len(pairs) == want, (name, label, len(pairs), want)
                assert all((str(i), str(i)) in pairs for i in range(size))
                c_hashes[label] = sha(c)
                binary = Path(str(prefix) + '.bin')
                build = run([cli, 'build', entry, '-o', binary], str(prefix) + '-build', True)
                native = run([binary], str(prefix) + '-run')
                assert native['stdout'] == expected, native
                assert not native['stderr'], native
                row = {'case': name, 'round': round_number, 'compiler': label, 'sources': size,
                       'demands': size, 'pairs': len(pairs), 'required_pairs': size,
                       'c_lines': generated.count('\n'), 'c_bytes': c.stat().st_size,
                       'c_sha256': sha(c), 'binary_bytes': binary.stat().st_size,
                       'emit_seconds': emit['seconds'], 'emit_rss_kib': emit['max_rss_kib'],
                       'build_seconds': build['seconds'], 'build_rss_kib': build['max_rss_kib'],
                       'node_match': True}
                binary.unlink()
                results.append(row)
                print(json.dumps(row), flush=True)
                (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
        if unknown:
            assert c_hashes['base'] == c_hashes['current'], (name, c_hashes)
after = {str(p): sha(p) for p in (base, current)}
assert before == after, 'compiler changed during measurements'
(out / 'provenance.json').write_text(json.dumps({'cli_sha256_before': before, 'cli_sha256_after': after,
    'root': str(root), 'node': str(node), 'node_version': subprocess.check_output([node, '--version']).decode().strip(),
    'execution': 'serial, interleaved base/current then current/base, one worker; native binary deleted after each case'}, indent=2) + '\n')
