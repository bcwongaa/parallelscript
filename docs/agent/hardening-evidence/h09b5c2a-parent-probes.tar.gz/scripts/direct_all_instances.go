package main

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: direct_all_instances source.pts output.c output.bin")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	must(err)
	must(os.WriteFile(os.Args[2], []byte(code), 0600))
	tc, err := toolchain.New()
	must(err)
	rt, err := tc.Runtime(ctx, toolchain.Release)
	must(err)
	must(tc.CompileProgram(ctx, rt, []string{os.Args[2]}, os.Args[3]))
	fmt.Printf("direct AllInstances emitted and compiled %d bytes\n", len(code))
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
