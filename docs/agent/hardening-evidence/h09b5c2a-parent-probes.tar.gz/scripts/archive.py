"""Archive explicitly text-validated parent receipts and source snapshots, never binaries."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import sys

root, scratch = map(lambda p: Path(p).resolve(), sys.argv[1:3])
evidence = root / 'docs/agent/hardening-evidence'
target = evidence / 'h09b5c2a-parent-probes.tar.gz'
assert not target.exists(), 'look at an existing archive before replacing it'
files = []
for path in sorted(scratch.iterdir()):
    if path.is_file() and path.name not in ('base-pts', 'current-pts', 'final-pts'):
        files.append((path, 'parent/' + path.name))
workspace = root / 'pts-bin/h09b5c2a'
for name in ('growth.py', 'run_checked.py', 'archive.py', 'direct_all_instances.go'):
    files.append((workspace / name, 'scripts/' + name))
for name in ('enclosing-direct.c', 'enclosing-direct.mts'):
    files.append((workspace / name, 'probes/' + name))
assert not (workspace / 'enclosing-direct.bin').exists()
for label in ('growth', 'growth-final'):
    for path in sorted((workspace / label).rglob('*')):
        if path.is_file():
            assert path.suffix != '.bin', path
            files.append((path, label + '/' + str(path.relative_to(workspace / label))))
for path in sorted((workspace / 'mutants').rglob('*')):
    if path.is_file():
        files.append((path, 'mutants/' + str(path.relative_to(workspace / 'mutants'))))
for name in ('pts/lower/value_flow.go', 'pts/lower/returned_values.go',
             'pts/lower/returned_value_sources_test.go', 'pts/lower/returned_value_bounds_test.go',
             'pts/driver/returned_value_sources_test.go',
             'pts/tests/run/generic_value_flow_returned_sources.pts',
             'pts/tests/run/generic_value_flow_returned_unknowns.pts',
             'pts/tests/run/generic_value_flow_returned_enclosing_captures.pts'):
    files.append((root / name, 'snapshot/' + name))
manifest = {}
with tarfile.open(target, 'w:gz') as archive:
    for path, name in files:
        assert path.is_file() and not path.is_symlink(), path
        data = path.read_bytes()
        data.decode('utf-8')
        assert b'\x00' not in data, path
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(data))
        manifest[name] = hashlib.sha256(data).hexdigest()
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json')
    info.size = len(data)
    info.mode = 0o644
    archive.addfile(info, io.BytesIO(data))
stream_target = evidence / 'h09b5c2a-final-suite.jsonl.gz'
assert not stream_target.exists()
with gzip.GzipFile(filename=str(stream_target), mode='wb', mtime=0) as out:
    out.write((scratch / 'final-suite2.out').read_bytes())
print(json.dumps({'archive': str(target), 'members': len(manifest) + 1,
    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'suite_stream': str(stream_target),
    'suite_sha256': hashlib.sha256(stream_target.read_bytes()).hexdigest()}, indent=2))
