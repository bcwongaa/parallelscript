class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
function use0(f: Factory): number { const box: Box<C0> = f(new C0()); return box.value.tag; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
function use1(f: Factory): number { const box: Box<C1> = f(new C1()); return box.value.tag; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
function use2(f: Factory): number { const box: Box<C2> = f(new C2()); return box.value.tag; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
function use3(f: Factory): number { const box: Box<C3> = f(new C3()); return box.value.tag; }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
function use4(f: Factory): number { const box: Box<C4> = f(new C4()); return box.value.tag; }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
function use5(f: Factory): number { const box: Box<C5> = f(new C5()); return box.value.tag; }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
function use6(f: Factory): number { const box: Box<C6> = f(new C6()); return box.value.tag; }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
function use7(f: Factory): number { const box: Box<C7> = f(new C7()); return box.value.tag; }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
function use8(f: Factory): number { const box: Box<C8> = f(new C8()); return box.value.tag; }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
function use9(f: Factory): number { const box: Box<C9> = f(new C9()); return box.value.tag; }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
function use10(f: Factory): number { const box: Box<C10> = f(new C10()); return box.value.tag; }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
function use11(f: Factory): number { const box: Box<C11> = f(new C11()); return box.value.tag; }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
function use12(f: Factory): number { const box: Box<C12> = f(new C12()); return box.value.tag; }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
function use13(f: Factory): number { const box: Box<C13> = f(new C13()); return box.value.tag; }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
function use14(f: Factory): number { const box: Box<C14> = f(new C14()); return box.value.tag; }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
function use15(f: Factory): number { const box: Box<C15> = f(new C15()); return box.value.tag; }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
function use16(f: Factory): number { const box: Box<C16> = f(new C16()); return box.value.tag; }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
function use17(f: Factory): number { const box: Box<C17> = f(new C17()); return box.value.tag; }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
function use18(f: Factory): number { const box: Box<C18> = f(new C18()); return box.value.tag; }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
function use19(f: Factory): number { const box: Box<C19> = f(new C19()); return box.value.tag; }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
function use20(f: Factory): number { const box: Box<C20> = f(new C20()); return box.value.tag; }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
function use21(f: Factory): number { const box: Box<C21> = f(new C21()); return box.value.tag; }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
function use22(f: Factory): number { const box: Box<C22> = f(new C22()); return box.value.tag; }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
function use23(f: Factory): number { const box: Box<C23> = f(new C23()); return box.value.tag; }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
function use24(f: Factory): number { const box: Box<C24> = f(new C24()); return box.value.tag; }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
function use25(f: Factory): number { const box: Box<C25> = f(new C25()); return box.value.tag; }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
function use26(f: Factory): number { const box: Box<C26> = f(new C26()); return box.value.tag; }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
function use27(f: Factory): number { const box: Box<C27> = f(new C27()); return box.value.tag; }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
function use28(f: Factory): number { const box: Box<C28> = f(new C28()); return box.value.tag; }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
function use29(f: Factory): number { const box: Box<C29> = f(new C29()); return box.value.tag; }
const held: any[] = [source0, source1, source2, source3, source4, source5, source6, source7, source8, source9, source10, source11, source12, source13, source14, source15, source16, source17, source18, source19, source20, source21, source22, source23, source24, source25, source26, source27, source28, source29];
function factory0(): Factory { return source0; }
function factory1(): Factory { return source1; }
function factory2(): Factory { return source2; }
function factory3(): Factory { return source3; }
function factory4(): Factory { return source4; }
function factory5(): Factory { return source5; }
function factory6(): Factory { return source6; }
function factory7(): Factory { return source7; }
function factory8(): Factory { return source8; }
function factory9(): Factory { return source9; }
function factory10(): Factory { return source10; }
function factory11(): Factory { return source11; }
function factory12(): Factory { return source12; }
function factory13(): Factory { return source13; }
function factory14(): Factory { return source14; }
function factory15(): Factory { return source15; }
function factory16(): Factory { return source16; }
function factory17(): Factory { return source17; }
function factory18(): Factory { return source18; }
function factory19(): Factory { return source19; }
function factory20(): Factory { return source20; }
function factory21(): Factory { return source21; }
function factory22(): Factory { return source22; }
function factory23(): Factory { return source23; }
function factory24(): Factory { return source24; }
function factory25(): Factory { return source25; }
function factory26(): Factory { return source26; }
function factory27(): Factory { return source27; }
function factory28(): Factory { return source28; }
function factory29(): Factory { return source29; }
console.log("sum", use0(factory0()) + use1(factory1()) + use2(factory2()) + use3(factory3()) + use4(factory4()) + use5(factory5()) + use6(factory6()) + use7(factory7()) + use8(factory8()) + use9(factory9()) + use10(factory10()) + use11(factory11()) + use12(factory12()) + use13(factory13()) + use14(factory14()) + use15(factory15()) + use16(factory16()) + use17(factory17()) + use18(factory18()) + use19(factory19()) + use20(factory20()) + use21(factory21()) + use22(factory22()) + use23(factory23()) + use24(factory24()) + use25(factory25()) + use26(factory26()) + use27(factory27()) + use28(factory28()) + use29(factory29()));
