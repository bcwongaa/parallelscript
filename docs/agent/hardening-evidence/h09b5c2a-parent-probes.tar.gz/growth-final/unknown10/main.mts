class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
function use0(f: Factory): number { const box: Box<C0> = f(new C0()); return box.value.tag; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
function use1(f: Factory): number { const box: Box<C1> = f(new C1()); return box.value.tag; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
function use2(f: Factory): number { const box: Box<C2> = f(new C2()); return box.value.tag; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
function use3(f: Factory): number { const box: Box<C3> = f(new C3()); return box.value.tag; }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
function use4(f: Factory): number { const box: Box<C4> = f(new C4()); return box.value.tag; }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
function use5(f: Factory): number { const box: Box<C5> = f(new C5()); return box.value.tag; }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
function use6(f: Factory): number { const box: Box<C6> = f(new C6()); return box.value.tag; }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
function use7(f: Factory): number { const box: Box<C7> = f(new C7()); return box.value.tag; }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
function use8(f: Factory): number { const box: Box<C8> = f(new C8()); return box.value.tag; }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
function use9(f: Factory): number { const box: Box<C9> = f(new C9()); return box.value.tag; }
const held: any[] = [source0, source1, source2, source3, source4, source5, source6, source7, source8, source9];
function factory0(): Factory { return held[0]; }
function factory1(): Factory { return held[1]; }
function factory2(): Factory { return held[2]; }
function factory3(): Factory { return held[3]; }
function factory4(): Factory { return held[4]; }
function factory5(): Factory { return held[5]; }
function factory6(): Factory { return held[6]; }
function factory7(): Factory { return held[7]; }
function factory8(): Factory { return held[8]; }
function factory9(): Factory { return held[9]; }
console.log("sum", use0(factory0()) + use1(factory1()) + use2(factory2()) + use3(factory3()) + use4(factory4()) + use5(factory5()) + use6(factory6()) + use7(factory7()) + use8(factory8()) + use9(factory9()));
