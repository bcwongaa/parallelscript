class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
function use0(f: Factory): number { const box: Box<C0> = f(new C0()); return box.value.tag; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
function use1(f: Factory): number { const box: Box<C1> = f(new C1()); return box.value.tag; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
function use2(f: Factory): number { const box: Box<C2> = f(new C2()); return box.value.tag; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
function use3(f: Factory): number { const box: Box<C3> = f(new C3()); return box.value.tag; }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
function use4(f: Factory): number { const box: Box<C4> = f(new C4()); return box.value.tag; }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
function use5(f: Factory): number { const box: Box<C5> = f(new C5()); return box.value.tag; }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
function use6(f: Factory): number { const box: Box<C6> = f(new C6()); return box.value.tag; }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
function use7(f: Factory): number { const box: Box<C7> = f(new C7()); return box.value.tag; }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
function use8(f: Factory): number { const box: Box<C8> = f(new C8()); return box.value.tag; }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
function use9(f: Factory): number { const box: Box<C9> = f(new C9()); return box.value.tag; }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
function use10(f: Factory): number { const box: Box<C10> = f(new C10()); return box.value.tag; }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
function use11(f: Factory): number { const box: Box<C11> = f(new C11()); return box.value.tag; }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
function use12(f: Factory): number { const box: Box<C12> = f(new C12()); return box.value.tag; }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
function use13(f: Factory): number { const box: Box<C13> = f(new C13()); return box.value.tag; }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
function use14(f: Factory): number { const box: Box<C14> = f(new C14()); return box.value.tag; }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
function use15(f: Factory): number { const box: Box<C15> = f(new C15()); return box.value.tag; }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
function use16(f: Factory): number { const box: Box<C16> = f(new C16()); return box.value.tag; }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
function use17(f: Factory): number { const box: Box<C17> = f(new C17()); return box.value.tag; }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
function use18(f: Factory): number { const box: Box<C18> = f(new C18()); return box.value.tag; }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
function use19(f: Factory): number { const box: Box<C19> = f(new C19()); return box.value.tag; }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
function use20(f: Factory): number { const box: Box<C20> = f(new C20()); return box.value.tag; }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
function use21(f: Factory): number { const box: Box<C21> = f(new C21()); return box.value.tag; }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
function use22(f: Factory): number { const box: Box<C22> = f(new C22()); return box.value.tag; }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
function use23(f: Factory): number { const box: Box<C23> = f(new C23()); return box.value.tag; }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
function use24(f: Factory): number { const box: Box<C24> = f(new C24()); return box.value.tag; }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
function use25(f: Factory): number { const box: Box<C25> = f(new C25()); return box.value.tag; }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
function use26(f: Factory): number { const box: Box<C26> = f(new C26()); return box.value.tag; }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
function use27(f: Factory): number { const box: Box<C27> = f(new C27()); return box.value.tag; }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
function use28(f: Factory): number { const box: Box<C28> = f(new C28()); return box.value.tag; }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
function use29(f: Factory): number { const box: Box<C29> = f(new C29()); return box.value.tag; }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
function use30(f: Factory): number { const box: Box<C30> = f(new C30()); return box.value.tag; }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
function use31(f: Factory): number { const box: Box<C31> = f(new C31()); return box.value.tag; }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
function use32(f: Factory): number { const box: Box<C32> = f(new C32()); return box.value.tag; }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
function use33(f: Factory): number { const box: Box<C33> = f(new C33()); return box.value.tag; }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
function use34(f: Factory): number { const box: Box<C34> = f(new C34()); return box.value.tag; }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
function use35(f: Factory): number { const box: Box<C35> = f(new C35()); return box.value.tag; }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
function use36(f: Factory): number { const box: Box<C36> = f(new C36()); return box.value.tag; }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
function use37(f: Factory): number { const box: Box<C37> = f(new C37()); return box.value.tag; }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
function use38(f: Factory): number { const box: Box<C38> = f(new C38()); return box.value.tag; }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
function use39(f: Factory): number { const box: Box<C39> = f(new C39()); return box.value.tag; }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
function use40(f: Factory): number { const box: Box<C40> = f(new C40()); return box.value.tag; }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
function use41(f: Factory): number { const box: Box<C41> = f(new C41()); return box.value.tag; }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
function use42(f: Factory): number { const box: Box<C42> = f(new C42()); return box.value.tag; }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
function use43(f: Factory): number { const box: Box<C43> = f(new C43()); return box.value.tag; }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
function use44(f: Factory): number { const box: Box<C44> = f(new C44()); return box.value.tag; }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
function use45(f: Factory): number { const box: Box<C45> = f(new C45()); return box.value.tag; }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
function use46(f: Factory): number { const box: Box<C46> = f(new C46()); return box.value.tag; }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
function use47(f: Factory): number { const box: Box<C47> = f(new C47()); return box.value.tag; }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
function use48(f: Factory): number { const box: Box<C48> = f(new C48()); return box.value.tag; }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
function use49(f: Factory): number { const box: Box<C49> = f(new C49()); return box.value.tag; }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
function use50(f: Factory): number { const box: Box<C50> = f(new C50()); return box.value.tag; }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
function use51(f: Factory): number { const box: Box<C51> = f(new C51()); return box.value.tag; }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
function use52(f: Factory): number { const box: Box<C52> = f(new C52()); return box.value.tag; }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
function use53(f: Factory): number { const box: Box<C53> = f(new C53()); return box.value.tag; }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
function use54(f: Factory): number { const box: Box<C54> = f(new C54()); return box.value.tag; }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
function use55(f: Factory): number { const box: Box<C55> = f(new C55()); return box.value.tag; }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
function use56(f: Factory): number { const box: Box<C56> = f(new C56()); return box.value.tag; }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
function use57(f: Factory): number { const box: Box<C57> = f(new C57()); return box.value.tag; }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
function use58(f: Factory): number { const box: Box<C58> = f(new C58()); return box.value.tag; }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
function use59(f: Factory): number { const box: Box<C59> = f(new C59()); return box.value.tag; }
const held: any[] = [source0, source1, source2, source3, source4, source5, source6, source7, source8, source9, source10, source11, source12, source13, source14, source15, source16, source17, source18, source19, source20, source21, source22, source23, source24, source25, source26, source27, source28, source29, source30, source31, source32, source33, source34, source35, source36, source37, source38, source39, source40, source41, source42, source43, source44, source45, source46, source47, source48, source49, source50, source51, source52, source53, source54, source55, source56, source57, source58, source59];
function factory0(): Factory { return source0; }
function factory1(): Factory { return source1; }
function factory2(): Factory { return source2; }
function factory3(): Factory { return source3; }
function factory4(): Factory { return source4; }
function factory5(): Factory { return source5; }
function factory6(): Factory { return source6; }
function factory7(): Factory { return source7; }
function factory8(): Factory { return source8; }
function factory9(): Factory { return source9; }
function factory10(): Factory { return source10; }
function factory11(): Factory { return source11; }
function factory12(): Factory { return source12; }
function factory13(): Factory { return source13; }
function factory14(): Factory { return source14; }
function factory15(): Factory { return source15; }
function factory16(): Factory { return source16; }
function factory17(): Factory { return source17; }
function factory18(): Factory { return source18; }
function factory19(): Factory { return source19; }
function factory20(): Factory { return source20; }
function factory21(): Factory { return source21; }
function factory22(): Factory { return source22; }
function factory23(): Factory { return source23; }
function factory24(): Factory { return source24; }
function factory25(): Factory { return source25; }
function factory26(): Factory { return source26; }
function factory27(): Factory { return source27; }
function factory28(): Factory { return source28; }
function factory29(): Factory { return source29; }
function factory30(): Factory { return source30; }
function factory31(): Factory { return source31; }
function factory32(): Factory { return source32; }
function factory33(): Factory { return source33; }
function factory34(): Factory { return source34; }
function factory35(): Factory { return source35; }
function factory36(): Factory { return source36; }
function factory37(): Factory { return source37; }
function factory38(): Factory { return source38; }
function factory39(): Factory { return source39; }
function factory40(): Factory { return source40; }
function factory41(): Factory { return source41; }
function factory42(): Factory { return source42; }
function factory43(): Factory { return source43; }
function factory44(): Factory { return source44; }
function factory45(): Factory { return source45; }
function factory46(): Factory { return source46; }
function factory47(): Factory { return source47; }
function factory48(): Factory { return source48; }
function factory49(): Factory { return source49; }
function factory50(): Factory { return source50; }
function factory51(): Factory { return source51; }
function factory52(): Factory { return source52; }
function factory53(): Factory { return source53; }
function factory54(): Factory { return source54; }
function factory55(): Factory { return source55; }
function factory56(): Factory { return source56; }
function factory57(): Factory { return source57; }
function factory58(): Factory { return source58; }
function factory59(): Factory { return source59; }
console.log("sum", use0(factory0()) + use1(factory1()) + use2(factory2()) + use3(factory3()) + use4(factory4()) + use5(factory5()) + use6(factory6()) + use7(factory7()) + use8(factory8()) + use9(factory9()) + use10(factory10()) + use11(factory11()) + use12(factory12()) + use13(factory13()) + use14(factory14()) + use15(factory15()) + use16(factory16()) + use17(factory17()) + use18(factory18()) + use19(factory19()) + use20(factory20()) + use21(factory21()) + use22(factory22()) + use23(factory23()) + use24(factory24()) + use25(factory25()) + use26(factory26()) + use27(factory27()) + use28(factory28()) + use29(factory29()) + use30(factory30()) + use31(factory31()) + use32(factory32()) + use33(factory33()) + use34(factory34()) + use35(factory35()) + use36(factory36()) + use37(factory37()) + use38(factory38()) + use39(factory39()) + use40(factory40()) + use41(factory41()) + use42(factory42()) + use43(factory43()) + use44(factory44()) + use45(factory45()) + use46(factory46()) + use47(factory47()) + use48(factory48()) + use49(factory49()) + use50(factory50()) + use51(factory51()) + use52(factory52()) + use53(factory53()) + use54(factory54()) + use55(factory55()) + use56(factory56()) + use57(factory57()) + use58(factory58()) + use59(factory59()));
