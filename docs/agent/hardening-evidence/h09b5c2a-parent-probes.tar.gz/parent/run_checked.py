import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/bryan/projects/parallelscript')
out = Path(sys.argv[1])
label = sys.argv[2]
command = sys.argv[3:]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def sources():
    paths = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', 'pts', 'cmd', 'internal', 'go.mod', 'go.sum', 'Makefile'], cwd=ROOT).decode().split('\0')
    return {name: digest(ROOT / name) for name in sorted(set(paths)) if name and (ROOT / name).is_file()}


before = sources()
(out / (label + '.sources-before.json')).write_text(json.dumps(before, indent=2) + '\n')
start = time.monotonic()
with (out / (label + '.out')).open('wb') as stdout, (out / (label + '.err')).open('wb') as stderr:
    result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=2700)
after = sources()
(out / (label + '.sources-after.json')).write_text(json.dumps(after, indent=2) + '\n')
counts = collections.Counter()
packages = {}
corpus = collections.Counter()
for line in (out / (label + '.out')).read_text(errors='replace').splitlines():
    try:
        event = json.loads(line)
    except ValueError:
        continue
    if event.get('Action') not in ('pass', 'skip', 'fail'):
        continue
    if 'Test' in event:
        counts[event['Action']] += 1
        if event['Test'].startswith('TestCorpusMatchesNode/'):
            corpus[event['Action']] += 1
    else:
        packages[event.get('Package', '')] = event['Action']
receipt = {
    'command': command,
    'cwd': str(ROOT),
    'exit': result.returncode,
    'seconds': time.monotonic() - start,
    'test_events': dict(counts),
    'packages': packages,
    'corpus_events': dict(corpus),
    'stderr_bytes': (out / (label + '.err')).stat().st_size,
    'sources_unchanged': before == after,
    'source_file_count': len(before),
    'changed_sources': [name for name in sorted(set(before) | set(after)) if before.get(name) != after.get(name)],
}
(out / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
sys.exit(result.returncode if before == after else 91)
