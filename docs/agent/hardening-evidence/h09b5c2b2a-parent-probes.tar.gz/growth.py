import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

repo = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
root.mkdir()
env = os.environ.copy()
env.update(GOMAXPROCS='1', PTS_HOME=str(repo))
node = str(Path.home() / '.local/node/bin/node')
archive = repo / 'docs/agent/hardening-evidence/h09b5-reproducer-probes.tar.gz'
inputs = root / 'inputs'
inputs.mkdir()
records = []
provenance = {'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'inputs': {}}
with tarfile.open(archive) as tar:
    for n in [10, 30, 60]:
        member = tar.getmember(f'repro/matrix/cases/m4_growth/methods_{n}.pts')
        assert member.isfile()
        data = tar.extractfile(member).read()
        (inputs / f'methods_{n}.pts').write_bytes(data)
        provenance['inputs'][str(n)] = {'member': member.name, 'sha256': hashlib.sha256(data).hexdigest()}
shutil.copy2(repo / 'pts-bin/pts', root / 'current-pts')
clis = {'base': root.parent / 'base-pts', 'current': root / 'current-pts'}
provenance['cli_sha256'] = {k: hashlib.sha256(p.read_bytes()).hexdigest() for k, p in clis.items()}
(root / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')

def run(label, command, stdout):
    stderr = root / (label + '.stderr')
    begin = time.monotonic()
    with stdout.open('wb') as out, stderr.open('wb') as err:
        result = subprocess.run(command, cwd=repo, env=env, stdout=out, stderr=err, timeout=1200)
    record = {'label': label, 'command': list(map(str, command)), 'exit': result.returncode, 'seconds': time.monotonic() - begin, 'stderr_bytes': stderr.stat().st_size}
    records.append(record)
    (root / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(record)
    return record

rows = []
for n in [10, 30, 60]:
    source = inputs / f'methods_{n}.pts'
    for repeat, order in enumerate([['base', 'current'], ['current', 'base']]):
        for version in order:
            c = root / f'{version}-{n}-{repeat}.c'
            r = run(f'emit-{version}-{n}-{repeat}', [str(clis[version]), 'emit-c', str(source)], c)
            data = c.read_text()
            targets = sorted(set(re.findall(r'\b(pts_fn_M\d+_make_V\d+)\(', data)))
            wrappers = sorted(set(re.findall(r'\b(pts_fn_\w*instance\w*)\(', data)))
            row = {'version': version, 'size': n, 'repeat': repeat, 'seconds': r['seconds'], 'target_pairs': len(targets), 'forwarding_functions': len(wrappers), 'lines': data.count('\n'), 'bytes': c.stat().st_size, 'sha256': hashlib.sha256(c.read_bytes()).hexdigest()}
            assert len(targets) == (n * n if version == 'base' else n), row
            rows.append(row)
            (root / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
            print(json.dumps(row), flush=True)
    mts = inputs / f'methods_{n}.mts'
    shutil.copy2(source, mts)
    nodeout = root / f'node-{n}.stdout'
    run(f'node-{n}', [node, '--no-warnings', '--experimental-transform-types', str(mts)], nodeout)
    expected = ''.join(f'{i}\n' for i in range(n))
    assert nodeout.read_text() == expected
    for version in ['base', 'current']:
        binary = root / f'{version}-{n}.bin'
        run(f'build-{version}-{n}', [str(clis[version]), 'build', str(source), '-o', str(binary)], root / f'build-{version}-{n}.stdout')
        native = root / f'native-{version}-{n}.stdout'
        run(f'native-{version}-{n}', [str(binary)], native)
        assert native.read_bytes() == nodeout.read_bytes()
        binary.unlink()
print('Growth and native/Node checks complete.', flush=True)
