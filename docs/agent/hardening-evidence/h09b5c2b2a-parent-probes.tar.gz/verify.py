import collections
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir()
env = os.environ.copy()
env.update(GOMAXPROCS='1', PTS_REQUIRE_NODE='1', PTS_SMOKE_MUTANTS='0', PTS_SMOKE_FILTER='generic', PTS_SMOKE_CLANG='1', PTS_SMOKE_JOBS='1')
env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
commands = [
    ('affected', ['go', 'test', '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '20m', './pts/lower/', './pts/driver/']),
    ('native', ['go', 'test', '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '20m', '-run', '^(TestRun|TestRunMatchesNode)$/^(generic_wrapper_flow_.*|generic_value_flow_.*|generic_values_read_back_from_any|generic_values_any_boundaries|generic_call_forms_any_boundaries|generic_arrow_captures|generic_arrow_factories|generic_method_values|generic_method_bind|generic_method_factories)$', './pts/tests/']),
    ('smoke', ['go', 'test', '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '20m', '-run', '^TestCompilerFailsCleanly$', './pts/tests/']),
]
summary = []
for name, command in commands:
    start = time.monotonic()
    with (out / (name + '.jsonl')).open('w') as stdout, (out / (name + '.stderr')).open('w') as stderr:
        r = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=1400)
    events = [json.loads(l) for l in (out / (name + '.jsonl')).read_text().splitlines()]
    row = {'name': name, 'command': command, 'exit': r.returncode, 'seconds': time.monotonic()-start, 'tests': dict(collections.Counter(e['Action'] for e in events if 'Test' in e and e['Action'] in ['pass', 'skip', 'fail'])), 'stderr_bytes': (out / (name + '.stderr')).stat().st_size, 'notes': [e.get('Output') for e in events if any(k in e.get('Output', '') for k in ['smoked', 'programs', 'FAIL', 'failed'])]}
    summary.append(row)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(row), flush=True)
    if r.returncode:
        sys.exit(r.returncode)
