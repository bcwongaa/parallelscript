import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
review = Path(sys.argv[2]).resolve()
out = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo), PTS_THREADS='1')
env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
records = []

def run(name, command, timeout=600):
    result = subprocess.run(command, cwd=repo, env=env, capture_output=True, text=True, timeout=timeout)
    row = {'name': name, 'command': command, 'exit': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    records.append(row)
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(name, 'exit', result.returncode, flush=True)
    return row

guard = review / 'review_wrapper_sources_test.go'
overlay = out / 'guard-overlay.json'
overlay.write_text(json.dumps({'Replace': {str(repo / 'pts/lower/review_wrapper_sources_test.go'): str(guard)}}) + '\n')
assert run('reviewer-source-guards', ['go', 'test', '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', '-overlay=' + str(overlay), '-run', '^TestReview', './pts/lower/'])['exit'] == 0
strict = {}
for label in ('base', 'current'):
    binary = out / ('strict-' + label)
    command = ['go', 'build', '-o', str(binary)]
    if label == 'base':
        command += ['-overlay=' + str(out.parent / 'base-overlay/overlay.json')]
    command += [str(review / 'strict/main.go')]
    assert run('build-strict-' + label, command)['exit'] == 0
    strict[label] = str(binary)

cases = [str(review / 'cases' / (name + '.pts')) for name in ['shared_bound_receivers', 'shared_object_captures', 'mutable_snapshot_bind', 'captured_bind_chains', 'conditional_generic_context', 'contextual_returned_bind_min']]
cases.append(str(repo / 'pts/tests/run/generic_fallback_spares_unrelated_adapter.pts'))
assert run('reviewer-native-probes', ['python3', '-I', str(review / 'run_cases.py'), '--home', str(repo), '--node', str(Path.home() / '.local/node/bin/node'), '--strict', strict['current'], '--base-strict', strict['base'], '--out', str(out / 'native')] + cases, 1000)['exit'] == 0
native = json.loads((out / 'native/results.json').read_text())
for row in native[:4]:
    assert row['node']['exit'] == 0
    assert all(row[label]['build']['exit'] == 0 and row[label]['node_match'] for label in ['base', 'fix'])
for row in native[4:6]:
    assert row['node']['exit'] == 0
    assert all(row[label]['build']['exit'] == 0 and row[label]['run']['exit'] == 1 and 'got Box<any>' in row[label]['run']['stderr'] for label in ['base', 'fix'])
adapter = native[6]
assert adapter['base']['build']['exit'] != 0
assert adapter['fix']['build']['exit'] == 0 and adapter['fix']['node_match']

boundary = []
for count in [256, 257]:
    for label in ['base', 'current']:
        cfile = out / f'union-{count}-{label}.c'
        row = run(f'boundary-{count}-{label}', [strict[label], '-out', str(cfile), str(review / 'boundary' / f'wrapper_union_{count}.pts')])
        assert row['exit'] == 0
        code = cfile.read_text()
        first = bool(re.search(r'pts_fn_first_C\(', code))
        unused = bool(re.search(r'pts_fn_unused_C\(', code))
        boundary.append({'count': count, 'version': label, 'first_C': first, 'unused_C': unused, 'sha256': hashlib.sha256(cfile.read_bytes()).hexdigest()})
        assert first and unused == (count == 257 or label == 'base')
(out / 'summary.json').write_text(json.dumps({'source_guards_green': True, 'controls_matching_base_current_node': 4, 'unchanged_contextual_generic_divergences': 2, 'obsolete_adapter_exemption_confirmed': True, 'boundaries': boundary}, indent=2) + '\n')
print('All parent review replay assertions passed', flush=True)
