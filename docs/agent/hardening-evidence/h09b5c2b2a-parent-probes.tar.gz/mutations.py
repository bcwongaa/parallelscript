import collections
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
root.mkdir()
env = os.environ.copy()
env['GOMAXPROCS'] = '1'
mutants = [
    ('ignore-wrapper-origin', 'pts/lower/value_flow.go', 'source = v.forward.source', 'source = nil', '^TestMethodWrapperDemandsOnlyInstantiateTheirProvenCreations/direct$'),
    ('lose-captured-source', 'pts/lower/forwarding.go', '&demand{in: fn, source: source, erased:', '&demand{in: fn, source: nil, erased:', '^TestMethodFieldForwardersRetainOnlyTheirCapturedFunctionSources$'),
]
summary = []
for name, relative, old, new, test in mutants:
    text = (repo / relative).read_text()
    assert text.count(old) == 1
    path = root / (name + '.go')
    path.write_text(text.replace(old, new))
    overlay = root / (name + '.json')
    overlay.write_text(json.dumps({'Replace': {str(repo / relative): str(path)}}) + '\n')
    command = ['go', 'test', '-overlay=' + str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', './pts/driver', '-run', test]
    with (root / (name + '.jsonl')).open('w') as stdout, (root / (name + '.stderr')).open('w') as stderr:
        r = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=700)
    raw = (root / (name + '.jsonl')).read_text()
    events = [json.loads(l) for l in raw.splitlines()]
    failed = [e['Test'] for e in events if e.get('Action') == 'fail' and 'Test' in e]
    row = {'name': name, 'command': command, 'exit': r.returncode, 'failed_tests': failed, 'build_failure': 'build failed' in raw.lower() or 'build failed' in (root / (name + '.stderr')).read_text().lower()}
    summary.append(row)
    (root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(row), flush=True)
    assert r.returncode != 0 and failed and not row['build_failure'], row
