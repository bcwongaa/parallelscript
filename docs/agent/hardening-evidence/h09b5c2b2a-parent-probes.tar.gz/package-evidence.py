import difflib
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile

repo = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
evidence = repo / 'docs/agent/hardening-evidence'
base = '3c021e2237b4b5d3841a652e5fa6bb1f2bf84e6a'
final = json.loads((root / 'final/summary.json').read_text())
assert len(final['results']) == 2 and all(r['exit'] == 0 for r in final['results'])
assert final['sources_unchanged'] and final['cli_unchanged'] and final['tests']['fail'] == 0
assert len(final['packages']) == 10 and all(e['Action'] == 'pass' for e in final['packages'])
assert final['stderr_bytes'] == {'build': 0, 'suite': 0}

snapshot = root / 'source-snapshot'
snapshot.mkdir(exist_ok=False)
tracked = subprocess.run(['git', 'diff', '--name-only', base, '--', 'pts/', 'cmd/', 'internal/'], cwd=repo, check=True, capture_output=True, text=True).stdout.splitlines()
untracked = subprocess.run(['git', 'ls-files', '--others', '--exclude-standard'], cwd=repo, check=True, capture_output=True, text=True).stdout.splitlines()
paths = sorted(set(tracked + [p for p in untracked if p.startswith(('pts/', 'cmd/', 'internal/'))]))
patches = []
for name in paths:
    source = repo / name
    assert source.is_file() and not source.is_symlink()
    target = snapshot / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    old = subprocess.run(['git', 'show', f'{base}:{name}'], cwd=repo, capture_output=True, text=True)
    assert old.returncode in (0, 128)
    patches.extend(difflib.unified_diff(old.stdout.splitlines(keepends=True), source.read_text().splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name))
(root / 'final-source.patch').write_text(''.join(patches))
(root / 'provenance.json').write_text(json.dumps({
    'task': 'H09b5c2b2a', 'date': '2026-10-22', 'base': base,
    'source_snapshot_sha256': {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in paths},
    'base_cli_sha256': hashlib.sha256((root / 'base-pts').read_bytes()).hexdigest(),
    'growth_cli_sha256': hashlib.sha256((root / 'growth/current-pts').read_bytes()).hexdigest(),
    'final_cli_sha256': final['cli_after'],
    'models': {'parent': 'gpt-6.1-sol', 'reproducer': 'inherited gpt-6.1-sol', 'reviewer': 'inherited gpt-6.1-sol', 'effort': 'configured/requested xhigh, not independent introspection'},
    'ci': 'Startup-only prior-slice receipts in repository; current work pending, not polled',
    'limitations': ['C254 inline asserted-any adaptation remains preexisting H29', 'C255 contextual returned bind remains preexisting H29', 'H09b5b refused review remains blocked, not replaced', 'Broader receiver and source flow remains H09b5c2b2b'],
}, indent=2) + '\n')

stream = evidence / 'h09b5c2b2a-final-suite.jsonl.gz'
assert not stream.exists()
with stream.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        compressed.write((root / 'final/suite.stdout').read_bytes())

excluded = {'base-pts', 'growth/current-pts', 'review-replay/strict-base', 'review-replay/strict-current', 'final/suite.stdout'}
archive = evidence / 'h09b5c2b2a-parent-probes.tar.gz'
assert not archive.exists()
members = []
with tarfile.open(archive, 'w:gz') as tar:
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in excluded or path.suffix == '.bin':
            continue
        magic = path.open('rb').read(4)
        assert magic != b'\x7fELF', relative
        info = tar.gettarinfo(str(path), arcname=relative)
        info.mode = 0o644
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        assert info.isfile()
        with path.open('rb') as data:
            tar.addfile(info, data)
        members.append(relative)
with tarfile.open(archive) as tar:
    actual = tar.getmembers()
    assert len(actual) == len(members)
    assert all(m.isfile() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in actual)
receipt = {
    'parent_archive': {'name': archive.name, 'regular_members': len(members), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
    'final_stream': {'name': stream.name, 'bytes': stream.stat().st_size, 'sha256': hashlib.sha256(stream.read_bytes()).hexdigest()},
    'source_snapshot_files': len(paths),
    'final': final,
}
(root / 'packaging-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
