import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=True)

def sources():
    result = subprocess.run(['git', 'ls-files', '-co', '--exclude-standard', '-z'], cwd=repo, check=True, capture_output=True)
    paths = sorted(set(result.stdout.decode().split('\0')) - {''})
    selected = [p for p in paths if p.startswith(('pts/', 'cmd/', 'internal/')) and (repo / p).is_file()]
    return {p: hashlib.sha256((repo / p).read_bytes()).hexdigest() for p in selected}

env = os.environ.copy()
env.update(GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
env['PATH'] = str(Path.home() / '.local/node/bin') + ':' + env['PATH']
start = sources()
(out / 'sources-before.json').write_text(json.dumps(start, indent=2) + '\n')
commands = [ ['make', 'build'], ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/'] ]
results = []
for name, command in zip(['build', 'suite'], commands):
    begin = time.monotonic()
    if name == 'suite':
        cli_before = hashlib.sha256((repo / 'pts-bin/pts').read_bytes()).hexdigest()
    with (out / (name + '.stdout')).open('w') as stdout, (out / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=3500)
    results.append({'name': name, 'command': command, 'exit': result.returncode, 'seconds': time.monotonic() - begin})
    if result.returncode:
        break
finish = sources()
(out / 'sources-after.json').write_text(json.dumps(finish, indent=2) + '\n')
summary = {'results': results, 'source_files': len(start), 'sources_unchanged': start == finish, 'changes': sorted(p for p in start.keys() | finish.keys() if start.get(p) != finish.get(p))}
if any(r['name'] == 'suite' for r in results):
    cli_after = hashlib.sha256((repo / 'pts-bin/pts').read_bytes()).hexdigest()
    summary.update(cli_before=cli_before, cli_after=cli_after, cli_unchanged=cli_before == cli_after)
if (out / 'suite.stdout').exists():
    events = []
    for line in (out / 'suite.stdout').read_text().splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            pass
    summary['tests'] = {a: sum(e.get('Action') == a and 'Test' in e for e in events) for a in ['pass', 'skip', 'fail']}
    summary['packages'] = [e for e in events if e.get('Action') in ['pass', 'fail'] and 'Test' not in e]
    summary['corpus'] = {a: sum(e.get('Action') == a and e.get('Test', '').startswith('TestCorpusMatchesNode/') for e in events) for a in ['pass', 'skip', 'fail']}
summary['stderr_bytes'] = {name: (out / (name + '.stderr')).stat().st_size for name in ['build', 'suite'] if (out / (name + '.stderr')).exists()}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
sys.exit(0 if all(r['exit'] == 0 for r in results) and len(results) == 2 and start == finish and summary.get('cli_unchanged', False) else 1)
