import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path(sys.argv[1]).resolve()
root = Path(sys.argv[2]).resolve()
marker = root / 'final/summary.json'
libc = ctypes.CDLL(None, use_errno=True)
fd = libc.inotify_init1(os.O_CLOEXEC)
if fd < 0:
    raise OSError(ctypes.get_errno(), 'inotify_init1')
if libc.inotify_add_watch(fd, os.fsencode(marker.parent), 0x8 | 0x80) < 0:
    raise OSError(ctypes.get_errno(), 'inotify_add_watch')
try:
    while True:
        try:
            json.loads(marker.read_text())
            break
        except (FileNotFoundError, json.JSONDecodeError):
            os.read(fd, 65536)
finally:
    os.close(fd)
subprocess.run(['python3', '-I', str(root / 'package-evidence.py'), str(repo), str(root)], check=True)
