// C172(c): 10 method values, each passed to its own one-type consumer (review round 1's s_N).
class Box<T> {
  constructor(public value: T) {}
}
type Factory = <T>(x: T) => Box<T>;
class V0 { constructor(public n: number) {} }
function use0(f: Factory): number { const b: Box<V0> = f(new V0(0)); return b.value.n; }
class M0 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V1 { constructor(public n: number) {} }
function use1(f: Factory): number { const b: Box<V1> = f(new V1(1)); return b.value.n; }
class M1 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V2 { constructor(public n: number) {} }
function use2(f: Factory): number { const b: Box<V2> = f(new V2(2)); return b.value.n; }
class M2 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V3 { constructor(public n: number) {} }
function use3(f: Factory): number { const b: Box<V3> = f(new V3(3)); return b.value.n; }
class M3 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V4 { constructor(public n: number) {} }
function use4(f: Factory): number { const b: Box<V4> = f(new V4(4)); return b.value.n; }
class M4 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V5 { constructor(public n: number) {} }
function use5(f: Factory): number { const b: Box<V5> = f(new V5(5)); return b.value.n; }
class M5 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V6 { constructor(public n: number) {} }
function use6(f: Factory): number { const b: Box<V6> = f(new V6(6)); return b.value.n; }
class M6 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V7 { constructor(public n: number) {} }
function use7(f: Factory): number { const b: Box<V7> = f(new V7(7)); return b.value.n; }
class M7 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V8 { constructor(public n: number) {} }
function use8(f: Factory): number { const b: Box<V8> = f(new V8(8)); return b.value.n; }
class M8 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class V9 { constructor(public n: number) {} }
function use9(f: Factory): number { const b: Box<V9> = f(new V9(9)); return b.value.n; }
class M9 {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
console.log(use0(new M0().make));
console.log(use1(new M1().make));
console.log(use2(new M2().make));
console.log(use3(new M3().make));
console.log(use4(new M4().make));
console.log(use5(new M5().make));
console.log(use6(new M6().make));
console.log(use7(new M7().make));
console.log(use8(new M8().make));
console.log(use9(new M9().make));
