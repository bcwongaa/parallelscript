class Box<T> { constructor(public value: T, public mark: string) {} }
class A { tag = 1; }
type Factory = <T>(value: T) => Box<T>;
const first = <T>(value: T): Box<T> => new Box(value, 'first');
const second = <T>(value: T): Box<T> => new Box(value, 'second');
let selected: Factory = first;
const snapshot = selected.bind(undefined);
selected = second;
const current = selected.bind(undefined);
function use(f: Factory): void { const result: Box<A> = f(new A()); console.log(result.mark, result.value.tag); }
use(snapshot);
use(current);
const anyValues: any[] = [snapshot, current];
const unknown: Factory = anyValues[1];
use(unknown);
