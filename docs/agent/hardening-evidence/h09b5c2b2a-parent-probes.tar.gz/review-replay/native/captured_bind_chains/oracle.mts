class Box<T> { constructor(public value: T, public mark: string) {} }
class A { tag = 1; }
class B { tag = 2; }
type Factory = <T>(value: T) => Box<T>;
function first<T>(value: T): Box<T> { return new Box(value, 'first'); }
function second<T>(value: T): Box<T> { return new Box(value, 'second'); }
function closed(f: Factory): Factory { return f.bind(undefined).bind(null); }
function useA(f: Factory): void { const result: Box<A> = f(new A()); console.log(result.mark, result.value.tag); }
function useB(f: Factory): void { const result: Box<B> = f(new B()); console.log(result.mark, result.value.tag); }
const object0: { make<T>(value: T): Box<T> } = { make: closed(first) };
const object1: { make<T>(value: T): Box<T> } = { make: closed(second) };
useA(object0.make);
useB(object1.make);
const numberFirst: (value: number) => Box<number> = closed(first);
const stringSecond: (value: string) => Box<string> = closed(second);
const n = numberFirst(7);
const s = stringSecond('x');
console.log(n.mark, n.value, s.mark, s.value);
