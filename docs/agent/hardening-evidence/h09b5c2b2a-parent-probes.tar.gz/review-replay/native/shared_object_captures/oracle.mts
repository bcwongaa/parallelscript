class Box<T> { constructor(public value: T, public mark: string) {} }
class A { tag = 1; }
class B { tag = 2; }
type Factory = <T>(value: T) => Box<T>;
function makeFactory(mark: string): Factory {
  const object = { make<T>(value: T): Box<T> { return new Box(value, mark); } };
  return object.make;
}
function useA(f: Factory): void { const result: Box<A> = f(new A()); console.log(result.mark, result.value.tag); }
function useB(f: Factory): void { const result: Box<B> = f(new B()); console.log(result.mark, result.value.tag); }
const first = makeFactory('one');
const second = makeFactory('two');
useA(first);
useB(second);
useB(first);
useA(second);
