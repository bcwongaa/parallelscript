class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
const contextual: <U>(outer: U) => Factory = outer => {
  const arrow = <T>(value: T): Box<T> => { console.log(outer); return new Box(value); };
  return arrow.bind(undefined);
};
function use(f: Factory): void { const result: Box<number> = f(7); console.log(result.value); }
use(contextual(5));
