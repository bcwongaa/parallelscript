class Box<T> { constructor(public value: T, public mark: number) {} }
class A { tag = 1; }
class B { tag = 2; }
type Factory = <T>(value: T) => Box<T>;
class Maker {
  constructor(public mark: number) {}
  make<T>(value: T): Box<T> { return new Box(value, this.mark); }
}
function makeFactory(mark: number): Factory {
  const receiver = new Maker(mark);
  return receiver.make.bind(receiver);
}
function useA(f: Factory): void { const result: Box<A> = f(new A()); console.log(result.mark, result.value.tag); }
function useB(f: Factory): void { const result: Box<B> = f(new B()); console.log(result.mark, result.value.tag); }
const first = makeFactory(10);
const second = makeFactory(20);
useA(first);
useB(second);
useB(first);
useA(second);
