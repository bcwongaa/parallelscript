class Box<T> { constructor(public value: T, public mark: string) {} }
class A { tag = 1; }
class B { tag = 2; }
type Factory = <T>(value: T) => Box<T>;
class Maker<U> {
  constructor(public outer: U) {}
  get(): Factory {
    const outer = this.outer;
    const arrow = <T>(value: T): Box<T> => { console.log(outer); return new Box(value, 'class'); };
    return arrow.bind(undefined);
  }
}
function enclosing<U>(outer: U): Factory {
  const arrow = <T>(value: T): Box<T> => { console.log(outer); return new Box(value, 'function'); };
  return arrow.bind(undefined);
}
const contextual: <U>(outer: U) => Factory = outer => {
  const arrow = <T>(value: T): Box<T> => { console.log(outer); return new Box(value, 'context'); };
  return arrow.bind(undefined);
};
function useA(f: Factory): void { const result: Box<A> = f(new A()); console.log(result.mark, result.value.tag); }
function useB(f: Factory): void { const result: Box<B> = f(new B()); console.log(result.mark, result.value.tag); }
useA(new Maker(3).get());
useB(new Maker('s').get());
useA(enclosing(4));
useB(enclosing('t'));
useA(contextual(5));
useB(contextual('u'));
