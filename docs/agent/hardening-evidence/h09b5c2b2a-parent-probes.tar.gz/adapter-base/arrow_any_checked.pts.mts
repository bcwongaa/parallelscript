class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
const source = <T,>(value: T): Box<T> => new Box(value, "source");
const bound = source.bind(undefined);
const held: any[] = [source];
const checked: Factory = held[0];
const adapted: (value: number) => Box<number> = checked;
console.log("before adapter");
const box = adapted(4);
console.log("after adapter", box.origin, box.value + 1);
