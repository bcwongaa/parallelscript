class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
const source = <T,>(value: T): Box<T> => new Box(value, "source");
const bound = source.bind(undefined);
const held: Factory[] = [bound];
const adapted: (value: number) => Box<number> = held[0];
console.log("before adapter");
const box = adapted(4);
console.log("after adapter", box.origin, box.value + 1);
