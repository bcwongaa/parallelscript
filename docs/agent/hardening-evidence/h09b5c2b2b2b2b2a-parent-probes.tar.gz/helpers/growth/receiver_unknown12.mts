class Box<T> { constructor(public value: T, public origin: number) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value, 0); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 0); } }
function use0(value: Maker): void { const box = value.make(new C0()); console.log(box.origin, box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value, 1); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 1); } }
function use1(value: Maker): void { const box = value.make(new C1()); console.log(box.origin, box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value, 2); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 2); } }
function use2(value: Maker): void { const box = value.make(new C2()); console.log(box.origin, box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value, 3); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 3); } }
function use3(value: Maker): void { const box = value.make(new C3()); console.log(box.origin, box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value, 4); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 4); } }
function use4(value: Maker): void { const box = value.make(new C4()); console.log(box.origin, box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value, 5); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 5); } }
function use5(value: Maker): void { const box = value.make(new C5()); console.log(box.origin, box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value, 6); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 6); } }
function use6(value: Maker): void { const box = value.make(new C6()); console.log(box.origin, box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value, 7); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 7); } }
function use7(value: Maker): void { const box = value.make(new C7()); console.log(box.origin, box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value, 8); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 8); } }
function use8(value: Maker): void { const box = value.make(new C8()); console.log(box.origin, box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value, 9); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 9); } }
function use9(value: Maker): void { const box = value.make(new C9()); console.log(box.origin, box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value, 10); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 10); } }
function use10(value: Maker): void { const box = value.make(new C10()); console.log(box.origin, box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value, 11); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value, 11); } }
function use11(value: Maker): void { const box = value.make(new C11()); console.log(box.origin, box.value.tag); }
const selected0: Maker = new M0();
const root0 = { branch: [{ value: selected0 }] };
const rootAlias0 = root0;
let rows0 = rootAlias0.branch;
const row0 = rows0[0]; const alias0 = row0;
use0(alias0.value);
const selected1: Maker = new M1();
const root1 = { branch: [{ value: selected1 }] };
const rootAlias1 = root1;
let rows1 = rootAlias1.branch;
const row1 = rows1[0]; const alias1 = row1;
use1(alias1.value);
const selected2: Maker = new M2();
const root2 = { branch: [{ value: selected2 }] };
const rootAlias2 = root2;
let rows2 = rootAlias2.branch;
const row2 = rows2[0]; const alias2 = row2;
use2(alias2.value);
const selected3: Maker = new M3();
const root3 = { branch: [{ value: selected3 }] };
const rootAlias3 = root3;
let rows3 = rootAlias3.branch;
const row3 = rows3[0]; const alias3 = row3;
use3(alias3.value);
const selected4: Maker = new M4();
const root4 = { branch: [{ value: selected4 }] };
const rootAlias4 = root4;
let rows4 = rootAlias4.branch;
const row4 = rows4[0]; const alias4 = row4;
use4(alias4.value);
const selected5: Maker = new M5();
const root5 = { branch: [{ value: selected5 }] };
const rootAlias5 = root5;
let rows5 = rootAlias5.branch;
const row5 = rows5[0]; const alias5 = row5;
use5(alias5.value);
const selected6: Maker = new M6();
const root6 = { branch: [{ value: selected6 }] };
const rootAlias6 = root6;
let rows6 = rootAlias6.branch;
const row6 = rows6[0]; const alias6 = row6;
use6(alias6.value);
const selected7: Maker = new M7();
const root7 = { branch: [{ value: selected7 }] };
const rootAlias7 = root7;
let rows7 = rootAlias7.branch;
const row7 = rows7[0]; const alias7 = row7;
use7(alias7.value);
const selected8: Maker = new M8();
const root8 = { branch: [{ value: selected8 }] };
const rootAlias8 = root8;
let rows8 = rootAlias8.branch;
const row8 = rows8[0]; const alias8 = row8;
use8(alias8.value);
const selected9: Maker = new M9();
const root9 = { branch: [{ value: selected9 }] };
const rootAlias9 = root9;
let rows9 = rootAlias9.branch;
const row9 = rows9[0]; const alias9 = row9;
use9(alias9.value);
const selected10: Maker = new M10();
const root10 = { branch: [{ value: selected10 }] };
const rootAlias10 = root10;
let rows10 = rootAlias10.branch;
const row10 = rows10[0]; const alias10 = row10;
use10(alias10.value);
const selected11: Maker = new M11();
const root11 = { branch: [{ value: selected11 }] };
const rootAlias11 = root11;
let rows11 = rootAlias11.branch;
const row11 = rows11[0]; const alias11 = row11;
use11(alias11.value);
