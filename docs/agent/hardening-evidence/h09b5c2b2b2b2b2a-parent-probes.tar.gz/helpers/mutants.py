import json
import pathlib
import subprocess
import sys

repo, output = map(pathlib.Path, sys.argv[1:3])
output.mkdir(parents=True, exist_ok=True)
original = repo / 'pts/lower/container_sources.go'
text = original.read_text()
cases = [
    ('skip_transitive_uses', 'check(alias, target, selected, depth)', 'true',
     '^TestExtractedContainerUsesPoisonEveryRootAndChildAlias/receivers_false/transitive_write$'),
    ('skip_declared_contract',
     'l.containerDataTypes(l.containerReadType(read, steps, depth), l.checker.GetTypeOfSymbol(target), steps)',
     'true', '^TestExtractedContainerUnsupportedOriginsAndContractsStayUnknown$'),
    ('cache_root_for_children', 'component[declaration] = tree', 'component[declaration] = data',
     '^TestExtractedContainerSourcesResolveSelectedTerminals$'),
]
results = []
for name, before, after, pattern in cases:
    assert text.count(before) == 1, (name, text.count(before))
    replacement = output / (name + '.go')
    replacement.write_text(text.replace(before, after))
    overlay = output / (name + '.overlay.json')
    overlay.write_text(json.dumps({'Replace': {str(original): str(replacement)}}))
    command = ['go', 'test', '-overlay', str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', './pts/lower', '-run', pattern]
    (output / (name + '.command.json')).write_text(json.dumps(command, indent=2)+'\n')
    with (output / (name + '.jsonl')).open('w') as stdout, (output / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(command, cwd=repo, stdout=stdout, stderr=stderr, timeout=660)
    events = []
    for line in (output / (name + '.jsonl')).read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    messages = ''.join(item.get('Output', '') for item in events)
    errors = (output / (name + '.stderr')).read_text()
    failed = [item['Test'] for item in events if item.get('Action') == 'fail' and item.get('Test')]
    assert result.returncode != 0 and failed, (name, result.returncode, messages, errors)
    assert '[build failed]' not in messages and 'build failed' not in errors and 'undefined:' not in errors, (name, errors)
    assert 'assertion failed' in messages.lower(), (name, messages)
    results.append({'name': name, 'exit': result.returncode, 'failed_test_events': len(failed), 'compiles_and_fails_assertions': True})
    (output / 'results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(name, results[-1], flush=True)
