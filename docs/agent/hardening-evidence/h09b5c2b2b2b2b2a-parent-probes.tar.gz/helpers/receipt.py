import collections
import hashlib
import json
import pathlib
import subprocess
import sys


def summarize(path):
    events = [json.loads(line) for line in pathlib.Path(path).read_text().splitlines() if line.startswith('{')]
    counts = collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in ('pass', 'fail', 'skip'))
    packages = {e['Package']: e['Action'] for e in events if not e.get('Test') and e['Action'] in ('pass', 'fail')}
    corpus = collections.Counter(e['Action'] for e in events if e.get('Test', '').startswith('TestCorpusMatchesNode/') and e['Action'] in ('pass', 'fail', 'skip'))
    outputs = [e['Output'].strip() for e in events if 'Output' in e and ('smoke:' in e['Output'] or 'programs' in e['Output'])]
    return {'events': dict(counts), 'packages': packages, 'corpus': dict(corpus), 'notes': outputs}


def manifest(repo):
    files = subprocess.check_output(['git', '-C', str(repo), 'ls-files', '-z', '--cached', '--others', '--exclude-standard', 'pts', 'cmd', 'internal']).decode().split('\0')
    return {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in files if name and pathlib.Path(name).suffix in ('.go', '.pts', '.c', '.h', '.ts', '.out') and (repo / name).is_file()}


if sys.argv[1] == 'summary':
    result = summarize(sys.argv[2])
elif sys.argv[1] == 'manifest':
    result = manifest(pathlib.Path(sys.argv[2]))
else:
    raise SystemExit('usage: receipt.py summary LOG | manifest REPO')
text = json.dumps(result, indent=2, sort_keys=True) + '\n'
if len(sys.argv) > 3:
    pathlib.Path(sys.argv[3]).write_text(text)
    print(sys.argv[3])
else:
    print(text)
