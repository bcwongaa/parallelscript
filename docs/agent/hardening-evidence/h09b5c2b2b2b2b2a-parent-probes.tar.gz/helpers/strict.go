package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) < 3 {
		panic("usage: strict source.pts output.c [output.bin]")
	}
	ctx := context.Background()
	code, err := driver.EmitCWith(ctx, os.Args[1], lower.AllInstances)
	if err == nil {
		err = os.WriteFile(os.Args[2], []byte(code), 0600)
	}
	if err == nil && len(os.Args) == 4 {
		var tc *toolchain.Toolchain
		tc, err = toolchain.New()
		if err == nil {
			var runtime *toolchain.Runtime
			runtime, err = tc.Runtime(ctx, toolchain.Release)
			if err == nil {
				err = tc.CompileProgram(ctx, runtime, []string{os.Args[2]}, os.Args[3])
			}
		}
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
