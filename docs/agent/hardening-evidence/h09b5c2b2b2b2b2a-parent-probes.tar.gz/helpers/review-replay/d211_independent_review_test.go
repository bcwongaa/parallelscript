package lower

import (
	"fmt"
	"slices"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/internal/ast"
	"gotest.tools/v3/assert"
)

// These tests were drafted independently against the accepted D-210 base before
// the D-211 implementation snapshot was supplied. No production file is changed.
func TestD211IndependentWholeRootClosure(t *testing.T) {
	cases := []struct{ name, use string }{
		{"unmodified", ""},
		{"root_write", "root.a.value = second;"},
		{"whole_alias_write", "alias.b.value = second;"},
		{"child_write", "child.value = second;"},
		{"child_alias_write", "childAlias.other = second;"},
		{"sibling_write", "siblingAlias.value = second;"},
		{"root_replacement", "root.a = root.b;"},
		{"child_escape", "consume(childAlias);"},
		{"sibling_escape", "consume(siblingAlias);"},
		{"root_escape", "consume(root);"},
		{"child_return", "function expose(): unknown { return child; }"},
		{"sibling_storage", "const storage = { held: sibling };"},
		{"child_spread", "const copy = { ...child };"},
		{"child_dynamic_alias", "const dynamic: any = child;"},
		{"child_unknown_alias", "const dynamic: unknown = child;"},
		{"child_asserted_alias", "const asserted = child as { value: Value; other: Value; count: number; replace: typeof replace };"},
		{"child_mutable_alias", "let mutable = child;"},
		{"child_destructure", "const { value } = child;"},
		{"child_dynamic_key", "let key: 'value' = 'value'; const ignored = child[key];"},
		{"child_direct_this", "child.replace();"},
		{"child_optional_this", "(childAlias.replace)?.();"},
		{"child_instantiated_this", "((childAlias.replace<number>))(1);"},
		{"child_asserted_this", "(childAlias.replace as typeof replace)();"},
		{"sibling_tag_this", "sibling.replace``;"},
		{"child_wrapped_write", "(child.value as Value) = second;"},
		{"child_pattern_write", "({ selected: child.value } = { selected: second });"},
		{"child_for_of_write", "for (child.value of [second]) {}"},
		{"child_delete", "delete (child as any).value;"},
		{"child_update", "child.count++;"},
		{"escaped_before_child_declaration", "function later(): unknown { return siblingAlias; }"},
	}
	for _, receivers := range []bool{false, true} {
		for _, reverse := range []bool{false, true} {
			for _, tt := range cases {
				t.Run(fmt.Sprintf("receiver_%t/reverse_%t/%s", receivers, reverse, tt.name), func(t *testing.T) {
					l, _ := valueFlowProbe(t, d211IndependentPrelude(receivers)+tt.use+d211IndependentViews())
					views := containerAliasProbeExpressions(l)
					assert.Equal(t, len(views), 8)
					if reverse {
						slices.Reverse(views)
					}
					for _, view := range views {
						steps := maxValueFlowSteps
						got := (sourceProof{l: l, receivers: receivers}).valueSources(view, &steps, 0)
						if tt.use == "" {
							want := "first"
							if receivers {
								want = "A"
							}
							assert.Assert(t, got != nil, "nonvacuous positive control for every poisoned view")
							assert.DeepEqual(t, returnedSourceNames(got), []string{want})
						} else {
							assert.Assert(t, got == nil, "unsafe use invalidates root, child, and sibling views")
						}
					}
					assert.Equal(t, len(l.valueFlow.active), 0)
					assert.Equal(t, len(l.valueFlow.receivers.active), 0)
				})
			}
		}
	}
}

func TestD211IndependentDeclaredExtractionContracts(t *testing.T) {
	for _, tt := range []struct {
		name, annotation string
		known            bool
	}{
		{"inferred", "", true},
		{"same_data", ": { value: Value; other: Value }", true},
		{"readonly_same_data", ": Readonly<{ value: Value; other: Value }>", true},
		{"dynamic_property", ": { value: any; other: Value }", false},
		{"unknown_property", ": { value: unknown; other: Value }", false},
		{"optional_property", ": { value?: Value; other: Value }", false},
		{"method_property", ": { value(): void; other: Value }", false},
		{"dropped_property", ": { value: Value }", false},
		{"union_contract", ": { value: Value; other: Value } | { value: Value; other: Value; marker: number }", false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			body := "const root = { a: { value: first, other: second }, plain: first }; const child" + tt.annotation + " = root.a; const check_root = root.a.value; const check_child = child.value; const check_plain = root.plain; const probe = check_root; probe;"
			l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+body)
			for _, view := range containerAliasProbeExpressions(l) {
				steps := maxValueFlowSteps
				got := l.valueSources(view, &steps, 0)
				if tt.known {
					assert.Assert(t, got != nil)
					assert.DeepEqual(t, returnedSourceNames(got), []string{"first"})
				} else {
					assert.Assert(t, got == nil, "one changed declared extraction edge invalidates whole root")
				}
			}
		})
	}
}

func TestD211IndependentExtractedArrayClosure(t *testing.T) {
	for _, tt := range []struct{ name, use string }{
		{"positive", ""},
		{"write", "child[0] = second;"},
		{"sibling_write", "sideAlias[1] = second;"},
		{"reverse", "child.reverse();"},
		{"length_read", "const count = child.length;"},
		{"length_write", "child.length = 0;"},
		{"dynamic_index", "let key = 0; const ignored = child[key];"},
		{"readonly_alias", "const readonly: readonly Value[] = child;"},
		{"tuple_alias", "// @ts-ignore: defensive source-only contract change\nconst tuple: [Value, Value] = child;"},
		{"escaped", "consume(sideAlias);"},
	} {
		t.Run(tt.name, func(t *testing.T) {
			body := "const root = { a: [first, second], b: [first, second], plain: first }; const child = root.a; const alias = child; const side = root.b; const sideAlias = side;\n" + tt.use + "\nconst check_root = root.a[0]; const check_alias = alias[0]; const check_side = sideAlias[0]; const check_plain = root.plain; const probe = check_root; probe;"
			l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+body)
			for _, view := range containerAliasProbeExpressions(l) {
				steps := maxValueFlowSteps
				got := l.valueSources(view, &steps, 0)
				if tt.use == "" {
					assert.Assert(t, got != nil, "typed array endpoints make the negative-use table nonvacuous")
					assert.DeepEqual(t, returnedSourceNames(got), []string{"first"})
				} else {
					assert.Assert(t, got == nil)
				}
			}
		})
	}
}

func TestD211IndependentCacheKindAndPathSeparation(t *testing.T) {
	for _, reverse := range []bool{false, true} {
		t.Run(fmt.Sprint(reverse), func(t *testing.T) {
			l, _ := valueFlowProbe(t, "class A {} class B {} const root = { a: { value: new A() }, b: { value: new B() } }; const child = root.a; const sibling = root.b; const check_child = child.value; const check_root = root.b.value; const check_sibling = sibling.value; const probe = check_root; probe;")
			views := containerAliasProbeExpressions(l)
			if reverse {
				slices.Reverse(views)
			}
			for _, view := range views {
				steps := maxValueFlowSteps
				assert.Assert(t, l.valueSources(view, &steps, 0) == nil)
				steps = maxValueFlowSteps
				got := l.receiverSources(view, &steps, 0)
				want := "B"
				if view.Expression().Kind == ast.KindIdentifier && view.Expression().Text() == "child" {
					want = "A"
				}
				assert.Assert(t, got != nil)
				assert.DeepEqual(t, returnedSourceNames(got), []string{want})
				steps = maxValueFlowSteps
				assert.Assert(t, l.valueSources(view, &steps, 0) == nil)
			}
		})
	}
}

func TestD211IndependentBudgetCannotPublishPartialRoot(t *testing.T) {
	var fanout strings.Builder
	fanout.WriteString(nestedContainerPrelude(false) + "const root = { a: { value: first }, b: { value: second }, plain: first };\n")
	for i := range maxValueFlowDepth + 8 {
		fmt.Fprintf(&fanout, "const branch%d = root.a; const selected%d = branch%d.value;\n", i, i, i)
	}
	fanout.WriteString("const poison = root.b; consume(poison); const check_first = branch0.value; const check_root = root.plain; const check_poison = poison.value; const probe = check_root; probe;")
	l, _ := valueFlowProbe(t, fanout.String())
	views := containerAliasProbeExpressions(l)
	steps := 16
	assert.Assert(t, l.valueSources(views[0], &steps, 0) == nil)
	for _, view := range views {
		steps = maxValueFlowSteps
		assert.Assert(t, l.valueSources(view, &steps, 0) == nil)
		steps = maxValueFlowSteps
		assert.Assert(t, l.receiverSources(view, &steps, 0) == nil)
	}
	assert.Equal(t, len(l.valueFlow.active), 0)
	assert.Equal(t, len(l.valueFlow.receivers.active), 0)
}

func d211IndependentPrelude(receivers bool) string {
	return nestedContainerPrelude(receivers) + `function replace<T>(this: { value: Value }, input?: T): void { this.value = second; }
const root = { a: { value: first, other: first, count: 0, replace }, b: { value: first, other: first, count: 0, replace }, plain: first };
const alias = root; const child = alias.a; const childAlias = child; const sibling = root.b; const siblingAlias = sibling;
`
}
func d211IndependentViews() string {
	return `
const check_root = root.a.value; const check_root_sibling = root.b.value; const check_plain = root.plain;
const check_alias = alias.a.value; const check_child = child.value; const check_child_alias = childAlias.value;
const check_sibling = sibling.value; const check_sibling_alias = siblingAlias.value; const probe = check_root; probe;
`
}
