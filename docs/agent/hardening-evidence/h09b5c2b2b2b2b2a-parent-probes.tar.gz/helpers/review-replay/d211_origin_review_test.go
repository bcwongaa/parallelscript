package lower

import (
	"fmt"
	"gotest.tools/v3/assert"
	"testing"
)

func TestD211IndependentDeferredContainerOriginsStayUnknown(t *testing.T) {
	cases := []struct{ name, body string }{
		{"fresh_inline_extraction", "const child = ({ a: { value: first } }).a; const probe = child.value; probe;"},
		{"destructured_extraction", "const root = { a: { value: first } }; const { a: child } = root; const probe = child.value; probe;"},
		{"identifier_nested_origin", "const stored = { value: first }; const root = { a: stored }; const child = root.a; const probe = child.value; probe;"},
		{"call_nested_origin", "function create(): { value: Value } { return { value: first }; } const root = { a: create() }; const child = root.a; const probe = child.value; probe;"},
		{"returned_root", "function create(): { a: { value: Value } } { return { a: { value: first } }; } const root = create(); const child = root.a; const probe = child.value; probe;"},
		{"parameter_root", "function inspect(root: { a: { value: Value } }): void { const child = root.a; const probe = child.value; probe; } inspect({ a: { value: first } });"},
		{"asserted_root", "const root = { a: { value: first } } as { a: { value: Value } }; const child = root.a; const probe = child.value; probe;"},
		{"asserted_extraction", "const root = { a: { value: first } }; const child = root.a as { value: Value }; const probe = child.value; probe;"},
		{"nonnull_extraction", "const root = { a: { value: first } }; const child = root.a!; const probe = child.value; probe;"},
		{"satisfies_extraction", "const root = { a: { value: first } }; const child = root.a satisfies { value: Value }; const probe = child.value; probe;"},
		{"mutable_extraction", "const root = { a: { value: first } }; let child = root.a; const probe = root.a.value; probe;"},
		{"exported_extraction", "const root = { a: { value: first } }; export const child = root.a; const probe = root.a.value; probe;"},
		{"dynamic_extraction", "const root = { a: { value: first } }; const child: any = root.a; const probe = root.a.value; probe;"},
		{"unknown_extraction", "const root = { a: { value: first } }; const child: unknown = root.a; const probe = root.a.value; probe;"},
		{"mutable_root", "let root = { a: { value: first } }; const child = root.a; const probe = child.value; probe;"},
		{"generic_literal_root", "function inspect<T>(input: T): void { const root = { a: { value: first } }; const child = root.a; const probe = child.value; probe; } inspect(1);"},
		{"root_call_escape", "const root = { a: { value: first } }; const child = root.a; function escape(): unknown { return root; } const probe = child.value; probe;"},
		{"child_call_escape", "const root = { a: { value: first } }; const child = root.a; function escape(): unknown { return child; } const probe = root.a.value; probe;"},
	}
	for _, receivers := range []bool{false, true} {
		for _, tt := range cases {
			t.Run(fmt.Sprintf("receiver_%t/%s", receivers, tt.name), func(t *testing.T) {
				l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+tt.body)
				steps := maxValueFlowSteps
				got := (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0)
				assert.Assert(t, got == nil, "deferred/escaped/asserted container source remains unknown")
				assert.Equal(t, len(l.valueFlow.active), 0)
				assert.Equal(t, len(l.valueFlow.receivers.active), 0)
			})
		}
	}
}
