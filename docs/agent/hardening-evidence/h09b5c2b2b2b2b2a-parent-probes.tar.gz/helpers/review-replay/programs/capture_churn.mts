class Box<T> { value: T; label: string; constructor(value: T, label: string) { this.value = value; this.label = label; } }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class Parent implements Maker {
  calls = 0; label: string; constructor(label: string) { this.label = label; }
  make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/parent/" + this.calls); }
}
class Child extends Parent {}
class Override extends Parent {
  make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/override/" + this.calls); }
}
function hold(receiver: Maker): Factory {
  const root = { left: { rows: [{ receiver }] }, side: { marker: 5 } };
  const left = root.left; const rows = left.rows; const row = rows[0]; const alias = row;
  return alias.receiver.make.bind(alias.receiver);
}
function closure(label: string): Factory {
  let calls = 0;
  const factory: Factory = <T,>(value: T): Box<T> => { calls++; return new Box(value, label + "/closure/" + calls); };
  const root = { rows: [{ factory }] }; const rows = root.rows; const row = rows[0]; return row.factory;
}
const first = hold(new Child("first")); const second = hold(new Override("second"));
const captureA = closure("a"); const captureB = closure("b");
let checksum = 0;
for (let i = 0; i < 180000; i++) {
  const scratch = { text: "garbage/" + i, values: [i, i+1, i+2] };
  checksum += scratch.values.length;
}
const x: Box<number> = first(3); const y: Box<string> = second("four");
const z: Box<string> = first("again"); const a: Box<number> = captureA(7);
const b: Box<string> = captureB("eight"); const c: Box<string> = captureA("nine");
console.log(x.label,x.value,y.label,y.value,z.label,z.value,a.label,a.value,b.label,b.value,c.label,c.value,checksum);
