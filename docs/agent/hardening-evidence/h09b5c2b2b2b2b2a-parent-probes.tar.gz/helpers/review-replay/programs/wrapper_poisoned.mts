class Box<T> { value: T; label: string; constructor(value: T, label: string) { this.value = value; this.label = label; } }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value, "source0"); }
class M0 implements Maker { calls = 0; label: string; constructor(label: string) { this.label = label; } make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use0(value: Factory): void { const box: Box<C0> = value(new C0()); console.log("use0", box.label, box.value.tag); }
function wrap0(label: string): Factory { const receiver: Maker = new M0(label); return receiver.make.bind(receiver); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value, "source1"); }
class M1 implements Maker { calls = 0; label: string; constructor(label: string) { this.label = label; } make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use1(value: Factory): void { const box: Box<C1> = value(new C1()); console.log("use1", box.label, box.value.tag); }
function wrap1(label: string): Factory { const receiver: Maker = new M1(label); return receiver.make.bind(receiver); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value, "source2"); }
class M2 implements Maker { calls = 0; label: string; constructor(label: string) { this.label = label; } make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/" + this.calls); } }
function use2(value: Factory): void { const box: Box<C2> = value(new C2()); console.log("use2", box.label, box.value.tag); }
function wrap2(label: string): Factory { const receiver: Maker = new M2(label); return receiver.make.bind(receiver); }
const value0: Factory = wrap0("selected0"); const alternate0: Factory = wrap1("alternate0");
const root0 = { left: { rows: [{ selected: value0, other: alternate0 }] }, side: { selected: alternate0 }, plain: value0 };
const rootAlias0 = root0; const left0 = rootAlias0.left; const rows0 = left0.rows; const row0 = rows0[0]; const childAlias0 = row0; const sibling0 = root0.side; const ignored0 = sibling0.selected;
const escaped0: any = left0; escaped0.rows[0].selected = alternate0;
const value1: Factory = wrap1("selected1"); const alternate1: Factory = wrap2("alternate1");
const root1 = { left: { rows: [{ selected: value1, other: alternate1 }] }, side: { selected: alternate1 }, plain: value1 };
const rootAlias1 = root1; const left1 = rootAlias1.left; const rows1 = left1.rows; const row1 = rows1[0]; const childAlias1 = row1; const sibling1 = root1.side; const ignored1 = sibling1.selected;
const escaped1: any = left1; escaped1.rows[0].selected = alternate1;
const value2: Factory = wrap2("selected2"); const alternate2: Factory = wrap0("alternate2");
const root2 = { left: { rows: [{ selected: value2, other: alternate2 }] }, side: { selected: alternate2 }, plain: value2 };
const rootAlias2 = root2; const left2 = rootAlias2.left; const rows2 = left2.rows; const row2 = rows2[0]; const childAlias2 = row2; const sibling2 = root2.side; const ignored2 = sibling2.selected;
const escaped2: any = left2; escaped2.rows[0].selected = alternate2;
use0(childAlias2.selected);
use1(childAlias0.selected);
use2(childAlias1.selected);
