#!/usr/bin/env python3
"""Retain textual parent evidence, without generated native/helper binaries."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile

raw, helpers, destination, receipt_path = map(Path, sys.argv[1:])
assert not destination.exists(), destination
assert not receipt_path.exists(), receipt_path
allowed = {'.json', '.jsonl', '.stdout', '.stderr', '.log', '.c', '.go', '.py', '.sh', '.pts', '.mts', '.md', '.txt', '.patch'}
entries = {}
excluded = []
for prefix, root in [('raw', raw), ('helpers', helpers)]:
    for path in sorted(root.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        name = str(PurePosixPath(prefix) / path.relative_to(root).as_posix())
        if path.suffix not in allowed or (prefix == 'raw' and path.name == 'final-suite.jsonl'):
            excluded.append(name)
            continue
        data = path.read_bytes()
        data.decode('utf-8')
        assert b'\x00' not in data, path
        assert name not in entries, name
        entries[name] = data
manifest = {
    'source_base': '5cc375c5a',
    'planning_commit': 'c8e9e8d0a',
    'reviewed_snapshot': 'helpers/snapshot2/hashes.json',
    'excluded': excluded,
    'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in entries.items()},
}
entries['MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
with destination.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
# Validate the bytes actually written, not only the inputs.
seen = set()
with tarfile.open(destination, 'r:gz') as archive:
    for member in archive:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert member.name not in seen
        seen.add(member.name)
        data = archive.extractfile(member).read()
        data.decode('utf-8')
        assert data == entries[member.name]
assert seen == set(entries)
receipt = {
    'archive': destination.name,
    'bytes': destination.stat().st_size,
    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'utf8_regular_members': len(entries),
    'uncompressed_bytes': sum(map(len, entries.values())),
    'excluded': excluded,
}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
