#!/usr/bin/env bash
set -euo pipefail
repo=$1
out=$2
GOMAXPROCS=4 make -C "$repo" build > "$out/final-build.stdout" 2> "$out/final-build.stderr"
python3 -I "$repo/.claude/worktrees/d211-parent-tools/receipt.py" manifest "$repo" "$out/final-before.json"
python3 -I - "$repo" "$out/final-frozen-before.json" <<'PY'
import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); expected=json.loads((root/'.claude/worktrees/d211-parent-tools/snapshot2/hashes.json').read_text())
observed={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}
assert observed==expected,'frozen snapshot2 mismatch'
observed['pts-bin/pts']=hashlib.sha256((root/'pts-bin/pts').read_bytes()).hexdigest()
pathlib.Path(sys.argv[2]).write_text(json.dumps(observed,indent=2)+'\n')
PY
set +e
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go -C "$repo" test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/ > "$out/final-suite.jsonl" 2> "$out/final-suite.stderr"
status=$?
set -e
python3 -I "$repo/.claude/worktrees/d211-parent-tools/receipt.py" summary "$out/final-suite.jsonl" "$out/final-summary.json"
python3 -I "$repo/.claude/worktrees/d211-parent-tools/receipt.py" manifest "$repo" "$out/final-after.json"
python3 -I - "$repo" "$out" "$status" <<'PY'
import hashlib,json,pathlib,sys
root,out=map(pathlib.Path,sys.argv[1:3]); before=json.loads((out/'final-before.json').read_text()); after=json.loads((out/'final-after.json').read_text())
assert before==after,'source hashes changed during full suite'
frozen=json.loads((out/'final-frozen-before.json').read_text())
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in frozen.items()),'reviewed source or CLI changed'
summary=json.loads((out/'final-summary.json').read_text())
receipt={'exit':int(sys.argv[3]),'source_manifest_unchanged':True,'selected_source_count':len(before),'eight_reviewed_files_and_cli_unchanged':True,'summary':summary}
(out/'final-verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
PY
printf 'Final required suite exit=%s\n' "$status"
exit "$status"
