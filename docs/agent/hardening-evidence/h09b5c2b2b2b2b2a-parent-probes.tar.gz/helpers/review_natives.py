import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys

repo, reviewer, output, base, current = map(pathlib.Path, sys.argv[1:6])
output.mkdir(parents=True, exist_ok=True)
inputs = repo / '.claude/worktrees/d211-parent-tools/review-replay/programs'
inputs.mkdir(parents=True, exist_ok=True)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
node = pathlib.Path.home() / '.local/node/bin/node'
commands = []
results = []


def run(argv, prefix, environment=env):
    with pathlib.Path(str(prefix)+'.stdout').open('wb') as stdout, pathlib.Path(str(prefix)+'.stderr').open('wb') as stderr:
        result = subprocess.run([str(value) for value in argv], cwd=repo, env=environment, stdout=stdout, stderr=stderr, timeout=300)
    commands.append({'argv': [str(value) for value in argv], 'cwd': str(repo), 'exit': result.returncode, 'prefix': str(prefix)})
    (output/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert result.returncode == 0, (argv, pathlib.Path(str(prefix)+'.stderr').read_text())
    return pathlib.Path(str(prefix)+'.stdout').read_text()


for row in json.loads((reviewer/'native-manifest.json').read_text()):
    name, kind = row['name'], row['kind']
    text = (reviewer/'programs'/(name+'.pts')).read_text()
    assert text == (reviewer/'programs'/(name+'.mts')).read_text(), name
    entry = inputs/(name+'.pts')
    twin = entry.with_suffix('.mts')
    entry.write_text(text)
    twin.write_text(text)
    if kind == 'churn':
        expected = 'first/parent/1 3 second/override/1 four first/parent/2 again a/closure/1 7 b/closure/1 eight a/closure/2 nine 540000\n'
    else:
        expected = ''
        for demand, value in enumerate([2, 0, 1]):
            if kind == 'function':
                label = 'source'+str((value+1)%3 if row['poison'] else value)
            else:
                label = ('alternate' if row['poison'] else 'selected')+str(value)+'/1'
            expected += f'use{demand} {label} {demand}\n'
    (output/(name+'.expected.stdout')).write_text(expected)
    assert run([node, '--no-warnings', '--experimental-transform-types', twin], output/(name+'.node')) == expected, name
    observations = {}
    for label, compiler in [('base', base), ('current', current)]:
        prefix = output/(name+'.'+label)
        c = pathlib.Path(str(prefix)+'.c')
        binary = pathlib.Path(str(prefix)+'.bin')
        run([compiler, entry, c, binary], pathlib.Path(str(prefix)+'.compile'))
        emitted = c.read_text()
        pairs = None
        if kind != 'churn':
            pattern = r'pts_fn_source(\d+)_C(\d+)\(' if kind == 'function' else r'pts_fn_M(\d+)_make_C(\d+)\('
            pairs = {(int(a),int(b)) for a,b in re.findall(pattern, emitted)}
            required = {(i,j) for i in range(3) for j in range(3)} if label == 'base' or row['poison'] else {(2,0),(0,1),(1,2)}
            assert pairs == required, (name,label,pairs,required)
            if kind != 'function':
                for i in range(3):
                    for j in range(3):
                        assert (f'return pts_fn_M{i}_make_C{j}(' in emitted) == ((i,j) in required), (name,label,i,j)
        native_env = dict(env, GC_PRINT_STATS='1') if kind == 'churn' else env
        assert run([binary], prefix, native_env) == expected, (name,label)
        stats = pathlib.Path(str(prefix)+'.stderr').read_text()
        collections = len(set(re.findall(r'collection #(\d+)', stats))) if kind == 'churn' else 0
        if kind == 'churn':
            assert collections > 0, (name,label,stats)
        else:
            assert not stats, (name,label,stats)
        observations[label] = {'pairs': sorted(pairs) if pairs is not None else None, 'native_matches_explicit_oracle_and_node': True, 'observed_gc_collections': collections, 'c_sha256': hashlib.sha256(c.read_bytes()).hexdigest()}
        binary.unlink()
    results.append({'name': name, 'source_sha256': hashlib.sha256(text.encode()).hexdigest(), 'observations': observations})
    (output/'results.json').write_text(json.dumps(results, indent=2)+'\n')
    print(name, {label: (len(item['pairs']) if item['pairs'] is not None else 'churn', item['observed_gc_collections']) for label,item in observations.items()}, flush=True)
