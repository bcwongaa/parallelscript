package main

import (
	"context"
	"encoding/json"
	"os"

	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	tc, err := toolchain.New()
	if err != nil {
		panic(err)
	}
	runtime, err := tc.Runtime(context.Background(), toolchain.Release)
	if err != nil {
		panic(err)
	}
	if err := json.NewEncoder(os.Stdout).Encode(runtime); err != nil {
		panic(err)
	}
}
