class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function fallback<T>(value: T): Box<T> { return new Box(value, "fallback"); }
function capture(label: string, start: number): Factory {
    let count = start;
    const source: Factory = <T,>(value: T): Box<T> => { count++; return new Box(value, label + "/" + count); };
    const { branch: { child, side } } = { branch: { child: { factory: source }, side: [fallback] } };
    const unused = side[0];
    return child.factory;
}
function useNumber(label: string, f: Factory): void { const box: Box<number> = f(12); console.log(label, box.origin, box.value + 1); }
function useString(label: string, f: Factory): void { const box: Box<string> = f("value"); console.log(label, box.origin, box.value.length); }
const first = capture("first", 10);
const second = capture("second", 20);
const { one, two } = { one: { source: first }, two: { source: second } };
useNumber("capture a", one.source);
useString("capture b", two.source);
function churn(): number { let total = 0; for (let i = 0; i < 30000; i++) { const s = "gc" + i + "abcdefghijklmnopqrstuvwx"; const a = [s, s + "x", s + "y"]; total += a[1].length; } return total; }
console.log("churn", churn() > 0);
useString("capture a again", one.source);
useNumber("capture b again", two.source);
class Parent implements Maker {
    calls = 0;
    constructor(public label: string) {}
    make<T>(value: T): Box<T> { this.calls++; return new Box(value, "parent/" + this.label + "/" + this.calls); }
}
class Inherited extends Parent {}
class Overridden extends Parent {
    make<T>(value: T): Box<T> { this.calls++; return new Box(value, "override/" + this.label + "/" + this.calls); }
}
function bindFrom(lookup: Maker, receiver: Maker): Factory {
    const { branch: { child } } = { branch: { child: { factory: lookup.make.bind(receiver) } } };
    return child.factory;
}
const lookupParent: Maker = new Parent("lookup-parent");
const thisOverride: Maker = new Overridden("this-override");
const lookupOverride: Maker = new Overridden("lookup-override");
const thisInherited: Maker = new Inherited("this-inherited");
const { first: boundA, second: boundB } = { first: { f: bindFrom(lookupParent, thisOverride) }, second: { f: bindFrom(lookupOverride, thisInherited) } };
useNumber("lookup parent", boundA.f);
useString("lookup override", boundB.f);
console.log("churn two", churn() > 0);
useString("lookup parent again", boundA.f);
useNumber("lookup override again", boundB.f);
const { receivers: direct } = { receivers: { inherited: thisInherited, override: thisOverride } };
const directA: Box<number> = direct.inherited.make(8);
const directB: Box<string> = direct.override.make("abc");
console.log("direct inherited", directA.origin, directA.value + 1);
console.log("direct override", directB.origin, directB.value.length);
