class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
function first<T>(value: T): Box<T> { return new Box(value, "first"); }
function second<T>(value: T): Box<T> { return new Box(value, "second"); }
const firstValue: Factory = first;
const secondValue: Factory = second;
function use(factory: Factory): void { const box: Box<number> = factory(6); console.log(box.origin, box.value + 1); }
const { branch: { child, other } } = { branch: { child: { factory: firstValue }, other: { factory: secondValue } } };
const dynamic: any = child;
const converted: { factory: Factory } = dynamic;
use(converted.factory);
use(other.factory);
try {
    dynamic.factory = 123;
    const impossible: Factory = dynamic.factory;
    const result: Box<number> = impossible(9);
    console.log("bad", result.origin);
} catch (error) {
    console.log("checked type error", error instanceof TypeError);
}
