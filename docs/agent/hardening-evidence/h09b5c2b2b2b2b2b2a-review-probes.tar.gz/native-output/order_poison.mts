class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
function first<T>(value: T): Box<T> { return new Box(value, "first"); }
function second<T>(value: T): Box<T> { return new Box(value, "second"); }
const firstValue: Factory = first;
const secondValue: Factory = second;
let order = "";
function mark(label: string, value: Factory): Factory { order += label; return value; }
function useNumber(label: string, factory: Factory): void { const box: Box<number> = factory(9); console.log(label, box.origin, box.value + 1); }
function useString(label: string, factory: Factory): void { const box: Box<string> = factory("abcdef"); console.log(label, box.origin, box.value.length); }
const effectRoot = {
    branch: { chosen: { f: mark("a", firstValue), ignored: mark("b", secondValue) }, sibling: [mark("c", secondValue)] },
    unselected: { f: mark("d", firstValue) }
};
const { branch: { chosen, sibling } } = effectRoot;
useNumber("order selected", chosen.f);
useString("order sibling", sibling[0]);
console.log("order", order);
const root = { branch: { chosen: { f: firstValue }, sibling: { f: firstValue } }, other: { f: firstValue } };
const { branch: { chosen: leafA, sibling: leafB }, other } = root;
const readBefore: Factory = leafA.f;
useNumber("before mutation", readBefore);
const dynamic: any = leafB;
dynamic.f = secondValue;
useString("dynamic sibling", root.branch.sibling.f);
({ f: leafA.f } = { f: secondValue });
useNumber("pattern selected", leafA.f);
useString("snapshot terminal", readBefore);
function replaceOther(value: { f: Factory }): void { value.f = secondValue; }
replaceOther(other);
useNumber("escape other", root.other.f);
useNumber("selected remains", root.branch.chosen.f);
let defaults = 0;
function makeDefault(): { f: Factory } { defaults++; return { f: secondValue }; }
const { branch: { child = makeDefault() } } = { branch: { child: { f: firstValue } } };
useNumber("nested default", child.f);
console.log("defaults", defaults);
const { child: normal, terminal } = { child: { f: firstValue }, terminal: secondValue };
useString("terminal sibling child", normal.f);
useNumber("terminal sibling fn", terminal);
const { a: duplicate1, a: duplicate2 } = { a: { f: firstValue } };
useNumber("duplicate before", duplicate1.f);
duplicate2.f = secondValue;
useString("duplicate after", duplicate1.f);
