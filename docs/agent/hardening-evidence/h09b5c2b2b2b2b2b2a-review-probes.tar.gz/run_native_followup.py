import collections
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

p = pathlib.Path('/tmp/pts-d213-review-D56redQm')
out = p / 'native-output-followup'
out.mkdir(exist_ok=True)
inputs = [p / "captures_only.pts", p / "receivers_compiling.pts", p / "checked_any_stage.pts"]
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME='/home/bryan/projects/parallelscript', PTS_THREADS='1', GC_MARKERS='1')
rows = []
for src in inputs:
    mts = out / (src.stem + '.mts')
    mts.write_bytes(src.read_bytes())
    node = subprocess.run(['/home/bryan/.local/node/bin/node', '--no-warnings', '--experimental-transform-types', str(mts)], capture_output=True, env=env, timeout=120)
    (out / (src.stem + '.node.stdout')).write_bytes(node.stdout)
    (out / (src.stem + '.node.stderr')).write_bytes(node.stderr)
    node_row = dict(input=str(src), phase='node', exit=node.returncode, stdout=node.stdout.decode(), stderr=node.stderr.decode(), source_sha256=hashlib.sha256(src.read_bytes()).hexdigest())
    rows.append(node_row)
    print(json.dumps(node_row), flush=True)
    for mode in ['base', 'candidate']:
        for api in ['all', 'default']:
            prefix = out / (src.stem + '.' + mode + '.' + api)
            cmd = [str(p / ('emit-' + mode)), str(src), api, str(prefix)]
            build = subprocess.run(cmd, env=env, capture_output=True, timeout=180)
            prefix.with_suffix(prefix.suffix + '.build.stdout').write_bytes(build.stdout)
            prefix.with_suffix(prefix.suffix + '.build.stderr').write_bytes(build.stderr)
            row = dict(input=str(src), mode=mode, api=api, emit_compile_exit=build.returncode, build_stdout=build.stdout.decode(), build_stderr=build.stderr.decode())
            cpath = pathlib.Path(str(prefix) + '.c')
            if cpath.exists(): row.update(c_sha256=hashlib.sha256(cpath.read_bytes()).hexdigest(), c_bytes=cpath.stat().st_size)
            if build.returncode == 0:
                runenv = env.copy()
                if src.stem in ['captures_only', 'receivers_compiling']:
                    runenv.update(GC_PRINT_STATS='1', GC_INITIAL_HEAP_SIZE='65536', GC_FREE_SPACE_DIVISOR='64')
                run = subprocess.run([str(prefix) + '.bin'], env=runenv, capture_output=True, timeout=120)
                pathlib.Path(str(prefix) + '.run.stdout').write_bytes(run.stdout)
                pathlib.Path(str(prefix) + '.run.stderr').write_bytes(run.stderr)
                row.update(native_exit=run.returncode, native_stdout=run.stdout.decode(), node_equal=(run.returncode==node.returncode and run.stdout==node.stdout), gc_collections=len(re.findall(rb'GC #[0-9]+', run.stderr)))
                pathlib.Path(str(prefix) + '.bin').unlink()
            rows.append(row)
            print(json.dumps(row), flush=True)
            (p / 'native-results-followup.json').write_text(json.dumps(rows, indent=2))
print('SUMMARY', json.dumps(collections.Counter(('node' if r.get('phase')=='node' else 'emit-failed' if r['emit_compile_exit'] else 'match' if r.get('node_equal') else 'nonmatch') for r in rows)), flush=True)
