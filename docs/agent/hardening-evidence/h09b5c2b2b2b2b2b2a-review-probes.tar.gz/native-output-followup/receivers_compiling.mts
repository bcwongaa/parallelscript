class Box<T> { constructor(public value: T, public origin: string) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function useNumber(label: string, f: Factory): void { const box: Box<number> = f(12); console.log(label, box.origin, box.value + 1); }
function useString(label: string, f: Factory): void { const box: Box<string> = f("value"); console.log(label, box.origin, box.value.length); }
class Parent implements Maker {
    calls = 0;
    constructor(public label: string) {}
    make<T>(value: T): Box<T> { this.calls++; return new Box(value, "parent/" + this.label + "/" + this.calls); }
}
class Inherited extends Parent {}
class Overridden extends Parent {
    make<T>(value: T): Box<T> { this.calls++; return new Box(value, "override/" + this.label + "/" + this.calls); }
}
function read(receiver: Maker): Factory {
    const { branch: { child } } = { branch: { child: { factory: receiver.make.bind(receiver) } } };
    return child.factory;
}
const inherited: Maker = new Inherited("interface-inherited");
const overridden: Maker = new Overridden("interface-override");
const { first: boundA, second: boundB } = { first: { f: read(inherited) }, second: { f: read(overridden) } };
useNumber("captured inherited", boundA.f);
useString("captured override", boundB.f);
function churn(): number { let total = 0; for (let i = 0; i < 30000; i++) { const s = "gc" + i + "abcdefghijklmnopqrstuvwx"; const a = [s, s + "x", s + "y"]; total += a[1].length; } return total; }
console.log("churn", churn() > 0);
useString("captured inherited again", boundA.f);
useNumber("captured override again", boundB.f);
const { receivers: direct } = { receivers: { inherited, overridden } };
const directA: Box<number> = direct.inherited.make(8);
const directB: Box<string> = direct.overridden.make("abc");
console.log("direct inherited", directA.origin, directA.value + 1);
console.log("direct override", directB.origin, directB.value.length);
const lookup = new Parent("unused-lookup");
const thisArg = new Inherited("actual-thisarg");
const { child: explicitThisArg } = { child: { f: lookup.make.bind(thisArg) } };
useNumber("explicit thisArg", explicitThisArg.f);
useString("explicit thisArg again", explicitThisArg.f);
console.log("lookup untouched", lookup.calls);
