package main

import (
    "context"
    "crypto/sha256"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "os"
    "time"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
    if len(os.Args)!=4 { fmt.Fprintln(os.Stderr,"usage: emit-probe input.pts all|default output-prefix"); os.Exit(64) }
    ctx,cancel:=context.WithTimeout(context.Background(),2*time.Minute);defer cancel()
    var c string; var err error
    if os.Args[2]=="all" { c,err=driver.EmitCWith(ctx,os.Args[1],lower.AllInstances) } else if os.Args[2]=="default" { c,err=driver.EmitC(ctx,os.Args[1]) } else {os.Exit(64)}
    if err!=nil {fmt.Fprintln(os.Stderr,err);os.Exit(10)}
    if err=os.WriteFile(os.Args[3]+".c",[]byte(c),0600);err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(11)}
    sum:=sha256.Sum256([]byte(c))
    _=json.NewEncoder(os.Stdout).Encode(map[string]any{"api":os.Args[2],"input":os.Args[1],"c_sha256":hex.EncodeToString(sum[:]),"c_bytes":len(c)})
    tc,err:=toolchain.New();if err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(12)}
    rt,err:=tc.Runtime(ctx,toolchain.Release);if err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(13)}
    if err=tc.CompileProgram(ctx,rt,[]string{os.Args[3]+".c"},os.Args[3]+".bin");err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(14)}
}
