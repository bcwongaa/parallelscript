package driver_test

import (
    "fmt"
    "strings"
    "testing"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "gotest.tools/v3/assert"
)

func TestReviewerD213ExactAllInstancesAdditionalPatternEdges(t *testing.T) {
    for _,kind:=range []string{"function","receiver","captured_receiver","wrapper"}{
        for _,form:=range []string{"duplicate_keys","downstream_pattern","projected_nested","readonly_alias","duplicate_poison","unsupported_leaf_poison"}{
            t.Run(kind+"/"+form,func(t *testing.T){
                var s strings.Builder;s.WriteString(inlineContainerFlowInventory(kind,3))
                for i:=range 3{
                    typ,value,other:="Factory",fmt.Sprintf("source%d",i),fmt.Sprintf("source%d",(i+1)%3)
                    if kind=="receiver"||kind=="captured_receiver" {typ="Maker";value=fmt.Sprintf("new M%d()",i);other=fmt.Sprintf("new M%d()",(i+1)%3)}
                    if kind=="wrapper" {value=fmt.Sprintf("read%d()",i);other=fmt.Sprintf("read%d()",(i+1)%3)}
                    fmt.Fprintf(&s,"const v%d: %s=%s; const alt%d: %s=%s;\n",i,typ,value,i,typ,other)
                    terminal:=fmt.Sprintf("leaf%d.value",i)
                    switch form{
                    case "duplicate_keys","duplicate_poison":
                        fmt.Fprintf(&s,"const { child: leaf%d, child: duplicate%d }={child:{value:v%d}};\n",i,i,i)
                        if form=="duplicate_poison"{fmt.Fprintf(&s,"consumeContainer(duplicate%d);\n",i)}else{fmt.Fprintf(&s,"const ignored%d=duplicate%d.value;\n",i,i)}
                    case "downstream_pattern":
                        fmt.Fprintf(&s,"const {branch: branch%d}={branch:{inner:{child:{value:v%d}}}}; const {inner:{child:leaf%d}}=branch%d;\n",i,i,i,i)
                    case "projected_nested":
                        fmt.Fprintf(&s,"const {inner:{child:leaf%d}}=(({outer:{inner:{child:{value:v%d}}}}).outer);\n",i,i)
                    case "readonly_alias":
                        fmt.Fprintf(&s,"const {child:original%d}={child:{value:v%d}}; const leaf%d:Readonly<{value:%s}>=original%d;\n",i,i,i,typ,i)
                    case "unsupported_leaf_poison":
                        fmt.Fprintf(&s,"const root%d={child:{value:v%d},side:{terminal:alt%d}}; const {child:leaf%d,side:{terminal:unsupported%d}}=root%d;\n",i,i,i,i,i,i)
                    }
                    if kind=="captured_receiver"{terminal=fmt.Sprintf("read%d(%s)",i,terminal)}
                    fmt.Fprintf(&s,"use%d(%s);\n",i,terminal)
                }
                entry:=writeSource(t,s.String());c,err:=driver.EmitCWith(t.Context(),entry,lower.AllInstances);assert.NilError(t,err)
                poison:=strings.Contains(form,"poison")
                pairs:=destructuredContainerAssertPairs(t,c,kind,func(v,d int)bool{return poison||v==d})
                t.Logf("exact AllInstances %s pairs=%d",form,pairs)
                if !poison&&(kind=="captured_receiver"||kind=="wrapper"){for i:=range 3{assertCapturedReceiverWrapperSignatures(t,c,fmt.Sprintf("read%d_make",i),[]int{i})}}
            })
        }
    }
}
