package lower

import (
    "fmt"
    "slices"
    "strings"
    "testing"
)

func TestReviewerD213AdditionalSourceBoundaries(t *testing.T) {
    cases := []struct{name, body string; known bool; want []string}{
        {"fresh_nested_all_leaves", `const { branch: { a, b: other } } = { branch: { a: { value: first }, b: [second] } }; const ignored = other[0]; const probe = a.value; probe;`, true, []string{"first"}},
        {"fresh_duplicate_key_leaves", `const { child: one, child: two } = { child: { value: first } }; const ignored = two.value; const probe = one.value; probe;`, true, []string{"first"}},
        {"named_duplicate_key_leaves", `const root = { child: { value: first } }; const { child: one, child: two } = root; const ignored = two.value; const probe = one.value; probe;`, true, []string{"first"}},
        {"downstream_pattern", `const { branch } = { branch: { child: { value: first } } }; const { child } = branch; const probe = child.value; probe;`, true, []string{"first"}},
        {"fresh_projected_nested", `const { inner: { child } } = ((({ outside: { inner: { child: { value: first } } } })).outside); const probe = child.value; probe;`, true, []string{"first"}},
        {"quoted_numeric_object_key", `const { "0": child } = { "0": { value: first } }; const probe = child.value; probe;`, true, []string{"first"}},
        {"empty_nested_pattern", `const root = { child: { value: first }, side: {} }; const { child, side: {} } = root; const probe = child.value; probe;`, true, []string{"first"}},
        {"selected_leaf_before_poison_leaf", `const root = { child: { value: first }, side: { value: second } }; const { child, side } = root; const probe = child.value; probe; consume(side);`, false, nil},
        {"duplicate_key_second_escape", `const root = { child: { value: first } }; const { child: one, child: two } = root; const probe = one.value; probe; consume(two);`, false, nil},
        {"duplicate_key_second_write", `const { child: one, child: two } = { child: { value: first } }; const probe = one.value; probe; two.value = second;`, false, nil},
        {"downstream_default_sibling", `const { branch } = { branch: { child: { value: first }, side: { value: second } } }; const { child, side = { value: first } } = branch; const probe = child.value; probe;`, false, nil},
        {"downstream_array_sibling", `const root = { child: { value: first }, side: [second] }; const { child, side: [ignored] } = root; const probe = child.value; probe;`, false, nil},
        {"downstream_nested_terminal_sibling", `const root = { child: { value: first }, side: { value: second } }; const { child, side: { value } } = root; const probe = child.value; probe;`, false, nil},
        {"downstream_numeric_sibling", `const root = { child: { value: first }, side: { 0: { value: second } } }; const { child, side: { 0: ignored } } = root; const probe = child.value; probe;`, false, nil},
        {"downstream_computed_sibling", `const root = { child: { value: first }, side: { value: second } }; const { child, ["side"]: ignored } = root; const probe = child.value; probe;`, false, nil},
        {"downstream_rest_sibling", `const root = { child: { value: first }, side: { value: second } }; const { child, side: { ...ignored } } = root; const probe = child.value; probe;`, false, nil},
        {"fresh_terminal_primitive_sibling", `const { child, terminal } = { child: { value: first }, terminal: 3 }; const probe = child.value; probe;`, false, nil},
        {"nested_annotation_owner", `const { branch: { child } }: { branch: { child: { value: Value } } } = { branch: { child: { value: first } } }; const probe = child.value; probe;`, false, nil},
        {"annotated_named_root", `const root: { child: { value: Value } } = { child: { value: first } }; const { child } = root; const probe = child.value; probe;`, false, nil},
        {"readonly_annotated_named_root", `const root: Readonly<{ child: { value: Value } }> = { child: { value: first } }; const { child } = root; const probe = child.value; probe;`, false, nil},
        {"contextually_typed_default_parameter", `function selected(root: { child: { value: Value } } = { child: { value: first } }): void { const { child } = root; const probe = child.value; probe; } selected();`, false, nil},
        {"contextually_typed_arrow_default", `const selected: (root?: { child: { value: Value } }) => void = (root = { child: { value: first } }) => { const { child } = root; const probe = child.value; probe; }; selected();`, false, nil},
        {"contextually_typed_pattern_default", `const selected: (root?: { child: { value: Value } }) => void = ({ child } = { child: { value: first } }) => { const probe = child.value; probe; }; selected();`, false, nil},
        {"pattern_default_origin", `const { branch: { child } = { child: { value: first } } } = { branch: { child: { value: second } } }; const probe = child.value; probe;`, false, nil},
        {"generic_class_owner", `class Container<T> { selected(): void { const { child } = { child: { value: first } }; const probe = child.value; probe; } }`, false, nil},
        {"contextually_generic_function_owner", `const selected: <T>(x: T) => void = x => { const { child } = { child: { value: first } }; const probe = child.value; probe; }; selected(1);`, false, nil},
        {"export_specifier", `const { child } = { child: { value: first } }; const probe = child.value; probe; export { child };`, false, nil},
        {"export_default", `const { child } = { child: { value: first } }; const probe = child.value; probe; export default child;`, false, nil},
        {"captured_shorthand_escape", `const { child } = { child: { value: first } }; const probe = child.value; probe; function escaped(): unknown { return { child }; }`, false, nil},
        {"array_push_escape", `const { child } = { child: { value: first } }; const probe = child.value; probe; const all: unknown[] = []; all.push(child);`, false, nil},
        {"for_of_assignment", `const { child } = { child: { value: first } }; const probe = child.value; probe; for (child.value of [second]) {}`, false, nil},
        {"logical_assignment", `const { child } = { child: { value: first } }; const probe = child.value; probe; child.value ||= second;`, false, nil},
        {"nested_assignment_target", `const { child } = { child: { value: first } }; const probe = child.value; probe; ({branch: {value: child.value}} = {branch: {value: second}});`, false, nil},
        {"spread_assignment_target", `const { child } = { child: { value: first } }; const probe = child.value; probe; [child.value] = [second];`, false, nil},
        {"projection_as_callee", `const { child } = { child: { value: first } }; const probe = child.value; probe; child.value();`, false, nil},
        {"projection_as_tag", "const { child } = { child: { value: first } }; const probe = child.value; probe; ((child.value) as any)`text`;", false, nil},
    }
    // Tagged-template syntax is assembled outside the Go raw string above.
    for _, receivers := range []bool{false, true} {
        for _, tt := range cases {
            if receivers && (tt.name == "projection_as_callee" || tt.name == "projection_as_tag") { continue }
            t.Run(fmt.Sprintf("receivers_%t/%s", receivers, tt.name), func(t *testing.T) {
                body := strings.ReplaceAll(tt.body, "\\`", "`")
                l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+body)
                for range 2 {
                    steps := maxValueFlowSteps
                    got := (sourceProof{l:l, receivers:receivers}).valueSources(probe,&steps,0)
                    if (got != nil) != tt.known { t.Fatalf("known=%t want=%t budget=%d got=%v",got!=nil,tt.known,steps,returnedSourceNames(got)) }
                    if tt.known && !slices.Equal(returnedSourceNames(got), inlineContainerSourceNames(tt.want,receivers)) { t.Fatalf("sources=%v want=%v",returnedSourceNames(got),inlineContainerSourceNames(tt.want,receivers)) }
                }
            })
        }
    }
}

func TestReviewerD213EveryComponentQueryOrder(t *testing.T) {
    for _, reverse := range []bool{false,true} {
        for _, receiverFirst := range []bool{false,true} {
            for _, poison := range []string{"", "consume(last);", "last.value=second;", "const { value }=last;", "const { child: lastAgain= {value:first} }=root;"} {
                t.Run(fmt.Sprintf("reverse_%t/receiverfirst_%t/poison_%q",reverse,receiverFirst,poison),func(t *testing.T){
                    l,_ := valueFlowProbe(t,nestedContainerPrelude(true)+`const root={child:{value:first},side:{value:first}};
const {child:firstChild,side:last}=root;
const check_root=root.child.value; const check_first=firstChild.value; const check_last=last.value; const probe=check_root; probe;
`+poison)
                    projections:=containerAliasProbeExpressions(l)
                    if reverse {slices.Reverse(projections)}
                    for range 2 {for _,x:=range projections { kinds:=[]bool{false,true};if receiverFirst{slices.Reverse(kinds)};for _,kind:=range kinds{steps:=maxValueFlowSteps; got:=(sourceProof{l:l,receivers:kind}).valueSources(x,&steps,0); want:=poison==""&&kind;if (got!=nil)!=want{t.Fatalf("kind=%t want=%t got=%v",kind,want,returnedSourceNames(got))}}}}
                })
            }
        }
    }
}
