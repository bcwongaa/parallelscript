#!/bin/bash
# usage: run.sh file.pts [bins...]; runs base, final (and others) and node; writes file.out
f=$1; shift
bins=${@:-base final}
d=$(dirname $f); b=$(basename $f .pts)
out=$d/$b.out
: > $out
for bin in $bins; do
  echo "== $bin" >> $out
  ( cd $d && PTS_HOME=/home/bryan/projects/parallelscript timeout 300 /tmp/h09b5d/pts-$bin run $b.pts ) >> $out 2>&1
  echo "[exit $?]" >> $out
  rm -f $d/$b $d/$b.bin $d/$b.exe 2>/dev/null
done
cp $f $d/$b.mts
echo "== node" >> $out
( cd $d && timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $b.mts ) >> $out 2>&1
echo "[exit $?]" >> $out
rm -f $d/$b.mts
cat $out
