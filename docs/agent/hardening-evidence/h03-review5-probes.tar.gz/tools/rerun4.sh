#!/bin/bash
# rerun round-4 probes with the current CLI; compare with round-4 node and new outputs
cd /tmp/pts-h03-review4/probes
for p in $(find . -name '*.pts' | sort); do
  name=$(basename $p .pts)
  [ "$name" = lib ] && continue
  OUTN=0 ERRN=0 /tmp/pts-h03-review5/tools/one.sh new $p > /dev/null 2>&1
  o=/tmp/pts-h03-review5/out1/new/$name/out
  n4=/tmp/pts-h03-review4/out/$name/node.out; w4=/tmp/pts-h03-review4/out/$name/new.out
  [ -f $w4 ] || w4=/tmp/pts-h03-review4/out1/new/$name/out
  vn=$( [ -f $n4 ] && (cmp -s $o $n4 && echo "==node" || echo "!=node") || echo "no-node")
  vw=$( [ -f $w4 ] && (cmp -s $o $w4 && echo "==r4new" || echo "!=r4new") || echo "no-r4new")
  echo "$name $vn $vw"
done
