# sourced: sets cli home cache for $which
R=/home/bryan/projects/parallelscript
B=$R/.claude/worktrees/agent-afb5379bc12f20b9e
case $which in
 new) cli=$R/pts-bin/pts; home=$R; cache=/tmp/pts-h03-review5/cache;;
 base) cli=$B/pts-bin/pts; home=$B; cache=/tmp/pts-h03-review5/basecache;;
 pre4) cli=/tmp/pts-h03/pre4/pts; home=$R; cache=/tmp/pts-h03-review5/pre4cache;;
 fix) cli=/tmp/pts-h03-review5/fixbuild/pts-fix; home=$R; cache=/tmp/pts-h03-review5/fixcache;;
 exp) cli=/home/bryan/projects/parallelscript/pts-bin/pts; home=/tmp/pts-h03-review5/home; cache=/tmp/pts-h03-review5/expcache;;
 *) echo "unknown $which"; exit 2;;
esac
