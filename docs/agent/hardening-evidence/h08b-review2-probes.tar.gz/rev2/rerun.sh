#!/bin/bash
# rerun.sh OUT FILE...: run each program with the round-1 and the round-2 CLI, report SAME or CHANGED
out=$1; shift
for f in "$@"; do
  b=$(basename "$(dirname "$f")")_$(basename "$f" .pts)
  d=$(mktemp -d /tmp/h08b/rev2/rerun/run.XXXX)
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/review1 timeout 120 /tmp/h08b/review1/pts-bin/pts run "$f" > "$out/$b.r1.txt" 2>&1; echo "[exit $?]" >> "$out/$b.r1.txt")
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/review2 timeout 120 /tmp/h08b/rev2/pts-bin/pts run "$f" > "$out/$b.r2.txt" 2>&1; echo "[exit $?]" >> "$out/$b.r2.txt")
  rm -rf "$d"
  if cmp -s "$out/$b.r1.txt" "$out/$b.r2.txt"; then echo "SAME $b"; else echo "CHANGED $b"; fi
done
