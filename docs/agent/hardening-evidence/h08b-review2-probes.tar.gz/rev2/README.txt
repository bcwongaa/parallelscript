H08b review round 2 probes (opus-reviewer). Snapshot /tmp/h08b/review2; CLI built from it into rev2/pts-bin/pts (go build -o, nothing written into the snapshot).
delta.diff        the code delta round 1 -> round 2 (diff of the two `git diff HEAD -- pts/lower`)
tests/            object_spread_suspension.{base,review1,review2}.txt (the new errors test with each CLI);
                  suspension_spread_copies.{base,review1,review2}.txt vs Node; ssc_no_receivers.pts (base variant without receivers: 5 of 7 lines differ);
                  *.r2.txt: the seven run tests with the round-2 CLI vs Node; *.expect vs *.node
rerun.txt, rerun/ round-1 probes (rev1/p, rev1/diag, rev1/explore, rev1/sfirst) run with the round-1 and round-2 CLIs: 60 SAME, 4 CHANGED (all the objectN message fix)
emitc.txt         emit-c round 1 vs round 2 for run/ and errors/: 526 SAME, 92 BOTH-FAIL (identical diagnostics), 1 DIAG-DIFF (the new errors test)
rerun.sh, emitc12.sh  the scripts
