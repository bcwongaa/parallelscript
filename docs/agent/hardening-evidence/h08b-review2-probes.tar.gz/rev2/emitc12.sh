#!/bin/bash
# emitc12.sh OUT FILE...: emit C with the round-1 and the round-2 CLI; SAME, C-DIFF, DIAG-DIFF or BOTH-FAIL
out=$1; shift; mkdir -p "$out"
for f in "$@"; do
  b=$(basename "$f" .pts); d=$(dirname "$f")
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/review1 timeout 120 /tmp/h08b/review1/pts-bin/pts emit-c "$f" -o "$out/$b.r1.c" > "$out/$b.r1.err" 2>&1); e1=$?
  (cd "$d" && GOMAXPROCS=2 PTS_HOME=/tmp/h08b/review2 timeout 120 /tmp/h08b/rev2/pts-bin/pts emit-c "$f" -o "$out/$b.r2.c" > "$out/$b.r2.err" 2>&1); e2=$?
  if [ $e1 -ne $e2 ] || ! cmp -s "$out/$b.r1.err" "$out/$b.r2.err"; then echo "DIAG-DIFF $b ($e1/$e2)";
  elif [ $e1 -ne 0 ]; then echo "BOTH-FAIL $b"; rm -f "$out/$b".*;
  elif cmp -s "$out/$b.r1.c" "$out/$b.r2.c"; then echo "SAME $b"; rm -f "$out/$b".*;
  else echo "C-DIFF $b"; fi
done
