#!/bin/bash
# trimod.sh DIR MAIN... : runs multi-module probes: each MAIN (a file in DIR/split) is copied with
# DIR's other modules into a scratch dir and run with base, round 3 and Node (.mts copies, imports
# rewritten to .mts).
export PATH=$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH
dir=$1; shift
for f in "$@"; do
  d=$(mktemp -d /tmp/h09b3/review3/scratch/mod.XXXX)
  cp $dir/*.pts $d/; rm -f $d/main.pts; cp $f $d/main.pts
  mkdir $d/node; for m in $d/*.pts; do b=$(basename $m .pts); sed -E 's#from "\./([a-z_]+)"#from "./\1.mts"#' $m > $d/node/$b.mts; done
  echo "=== $f"
  echo "--- base"; (cd $d && PTS_HOME=/tmp/h09b3/base timeout 300 /tmp/h09b3/review1/pts-base-dbg run main.pts 2>&1 | grep -v "FALLBACK from [01]\|^/tmp"); echo "[base exit=${PIPESTATUS[0]}]"
  echo "--- new"; (cd $d && PTS_HOME=/tmp/h09b3/snap3r timeout 300 /tmp/h09b3/review3/pts-new3-dbg run main.pts 2>&1 | grep -v "FALLBACK from [01]\|^/tmp"); echo "[new exit=${PIPESTATUS[0]}]"
  echo "--- node"; (cd $d/node && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types main.mts 2>&1); echo "[node exit=$?]"
  rm -rf $d
done
