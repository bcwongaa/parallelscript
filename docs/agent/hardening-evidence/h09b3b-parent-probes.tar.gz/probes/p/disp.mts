class Box<T> {
  constructor(public value: T) {}
}
class Base {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Derived extends Base {
  override make<T>(x: T): Box<T> {
    console.log("derived");
    return new Box(x);
  }
}
const b: Base = new Derived();
const f = b.make;
const v = f(3);
console.log(v.value);
const s: Box<string> = b.make("x");
console.log(s.value);
