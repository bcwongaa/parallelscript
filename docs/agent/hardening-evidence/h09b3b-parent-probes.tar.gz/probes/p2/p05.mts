// Family 4 (C196): element-access calls of a generic method whose key's value isn't known to be
// the method's name. Node calls the method the string names. Controls: a literal key and a const
// key (H09b3a).
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
  wrap<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  wrap<T>(x: T): Box<T> {
    const b = new Box(x);
    console.log("  (wrap ran)");
    return b;
  }
}
const t = new ClassMaker();
const im: Maker = new ClassMaker();
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
  wrap<T>(x: T): Box<T> {
    console.log("  (lit wrap ran)");
    return new Box(x);
  },
};
const K = "make";
attempt("01 control: literal key", () => String(t["make"](5).value + 1));
attempt("02 control: const key", () => String(t[K](5).value + 1));
function unionKey(key: "make" | "wrap"): void {
  attempt("03 union-of-literals parameter key (" + key + ")", () => {
    const b: Box<number> = t[key](5);
    return String(b.value + 1);
  });
}
unionKey("make");
unionKey("wrap");
function paramKey(key: "make"): void {
  attempt("04 parameter key of a literal type", () => {
    const b: Box<number> = t[key](5);
    return String(b.value + 1);
  });
}
paramKey("make");
attempt("05 let key", () => {
  let k: "make" = "make";
  const b: Box<number> = t[k](5);
  return String(b.value + 1);
});
const keys = ["make", "wrap"] as const;
attempt("06 element key keys[1]", () => {
  const b: Box<number> = t[keys[1]](5);
  return String(b.value + 1);
});
attempt("07 asserted string key", () => {
  const s: string = "make";
  const b: Box<number> = t[s as "make"](5);
  return String(b.value + 1);
});
attempt("08 interface receiver, union key", () => {
  const key: "make" | "wrap" = Math.random() < 2 ? "wrap" : "make";
  const b: Box<number> = im[key](5);
  return String(b.value + 1);
});
attempt("09 literal receiver, union key", () => {
  const key: "make" | "wrap" = Math.random() < 2 ? "wrap" : "make";
  const b: Box<number> = lit[key](5);
  return String(b.value + 1);
});
attempt("10 key from any that names another method", () => {
  const anyKey: any = "wrap";
  const b: Box<number> = t[anyKey as "make"](5);
  return String(b.value + 1);
});
attempt("11 keyof key", () => {
  const k: keyof Maker = "wrap";
  const b: Box<string> = im[k]("ab");
  return String(b.value.length);
});
