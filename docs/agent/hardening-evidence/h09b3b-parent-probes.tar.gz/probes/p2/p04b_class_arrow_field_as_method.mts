// Family 3 neighbour: a class whose generic arrow FIELD provides an interface's generic method
// (PTS1001 on HEAD: "using a `Impl` as a `{make(value): value}` ..."; pre-existing, honest).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class Impl {
  make = <T,>(x: T): Box<T> => new Box(x);
}
const fieldImpl: Maker = new Impl();
const n: Box<number> = fieldImpl.make(5);
console.log(n.value + 1);
