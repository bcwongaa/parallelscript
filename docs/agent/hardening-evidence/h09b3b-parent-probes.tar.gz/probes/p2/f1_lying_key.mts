// A key of a string literal type whose value is another name: JS calls the method the value
// names (or throws when there is none); the change calls the one the type names.
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  other<T>(x: T): Box<T> {
    console.log("other called");
    return new Box(x);
  }
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name);
  }
}
function byParameter(m: Maker, key: "make"): string {
  const b: Box<number> = m[key](4);
  return String(b.value);
}
const m: Maker = new ClassMaker();
const c = new ClassMaker();
const missing: any = "missing";
const other: any = "other";
let s: string = "other";
attempt("parameter lied to, no such method", () => byParameter(m, missing));
attempt("parameter lied to, another method", () => byParameter(c, other));
attempt("asserted key", () => String(c[s as "make"](5).value));
