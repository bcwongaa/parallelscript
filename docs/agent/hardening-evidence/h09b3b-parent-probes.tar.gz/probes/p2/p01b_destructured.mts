// Family 1: destructured generic methods (a class's: PTS1001 on HEAD, so each kind is its own file:
// p01b class, p01c interface, p01d object literal, p01e non-generic class method control).
class Box<T> {
  constructor(public value: T) {}
}
class ClassMaker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const { make } = c;
const b: Box<number> = make(5);
console.log(b.value + 1);
