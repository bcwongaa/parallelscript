// A key asserted to a string literal type whose value is another name.
class Box<T> {
  constructor(public value: T) {}
}
class Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  other<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const m = new Maker();
let k: string = "other";
let calls = 0;
class Spy extends Maker {
  other<T>(x: T): Box<T> {
    calls++;
    return new Box(x);
  }
}
const s: Maker = new Spy();
const b: Box<number> = s[k as "make"](5);
console.log(b.value, calls);
function keyOf(): string {
  return "other";
}
const k2 = keyOf() as "make";
const c: Box<number> = s[k2](6);
console.log(c.value, calls);
