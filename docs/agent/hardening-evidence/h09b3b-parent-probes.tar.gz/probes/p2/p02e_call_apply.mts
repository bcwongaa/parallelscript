// Family 2: `bind` with bound arguments, `call` and `apply` of generic functions and methods.
// tsc infers `unknown` for the type parameters of a generic function given to CallableFunction's
// bind (with bound arguments), call and apply (`Box<unknown>`), so the typed forms are written
// as tsc types them (a), with an `as Box<number>` (b), or with an instantiation expression (c).
class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  static smake<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const viaIface: Maker = new ClassMaker();
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const arrow = <T,>(x: T): Box<T> => new Box(x);

attempt("09a decl.bind with a bound argument, as tsc types it", () => {
  const f = make.bind(undefined, 5);
  const b = f();
  return `${(b.value as number) + 1} ${b instanceof Box}`;
});
attempt("09b decl.bind with a bound argument, as Box<number>", () => {
  const f = make.bind(undefined, 5);
  const b = f() as Box<number>;
  return String(b.value + 1);
});
attempt("09c instantiation expression .bind with a bound argument", () => {
  const f = (make<number>).bind(undefined, 5);
  const b: Box<number> = f();
  return String(b.value + 1);
});
attempt("10 class method .bind with a bound argument, as Box<string>", () => {
  const f = c.make.bind(c, "ab");
  const b = f() as Box<string>;
  return String(b.value.length);
});
attempt("11a decl.call, as tsc types it", () => {
  const b = make.call(undefined, 5);
  return `${(b.value as number) + 1} ${b instanceof Box}`;
});
attempt("11b decl.call, as Box<number>", () => {
  const b = make.call(undefined, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("11c instantiation expression .call", () => {
  const b: Box<number> = (make<number>).call(undefined, 5);
  return String(b.value + 1);
});
attempt("12 decl.apply, as Box<number>", () => {
  const b = make.apply(undefined, [5]) as Box<number>;
  return String(b.value + 1);
});
attempt("13 arrow.call, as Box<number>", () => {
  const b = arrow.call(undefined, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("14 class method .call, as Box<number>", () => {
  const b = c.make.call(c, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("15 class method .apply, as Box<number>", () => {
  const b = c.make.apply(c, [5]) as Box<number>;
  return String(b.value + 1);
});
attempt("16 interface method .call, as Box<number>", () => {
  const b = viaIface.make.call(viaIface, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("17 literal method .call, as Box<number>", () => {
  const b = lit.make.call(lit, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("18 static method .call, as Box<number>", () => {
  const b = ClassMaker.smake.call(undefined, 5) as Box<number>;
  return String(b.value + 1);
});
attempt("20 class method .call, as tsc types it", () => {
  const b = c.make.call(c, 5);
  return `${(b.value as number) + 1} ${b instanceof Box}`;
});
