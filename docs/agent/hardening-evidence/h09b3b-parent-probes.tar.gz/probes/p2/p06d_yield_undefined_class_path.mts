// Family 5 neighbour: with next() passing nothing, the class's direct call (which converts the
// resumed value to the instance's parameter type with a check) against the interface's call by
// name (which keeps the erased copy for a dynamic value, D-191).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const im: Maker = c;
function drive(label: string, g: () => Generator<number, void, number>): void {
  try {
    const it = g();
    it.next();
    it.next();
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
drive("01", function* () {
  const b: Box<number> = c.make(yield 1);
  console.log("01 class direct", b.value);
});
drive("02", function* () {
  const b: Box<number> = im.make(yield 1);
  console.log("02 interface by name", b.value);
});
