// Family 2, side finding: `call`/`bind`/`apply` of a class's GENERIC method with another object as
// `this`. JS runs the method on thisArg; a non-generic method does so on PTS too (control).
class Box<T> {
  constructor(public value: T) {}
}
class Tagged {
  constructor(public tag: string) {}
  make<T>(x: T): Box<string> {
    return new Box(`${this.tag}:${x}`);
  }
  plain(x: number): Box<string> {
    return new Box(`${this.tag}:${x}`);
  }
}
const a = new Tagged("a");
const b = new Tagged("b");
console.log("01 control: plain.call(b)", a.plain.call(b, 1).value);
console.log("02 control: plain.bind(b)", a.plain.bind(b)(2).value);
console.log("03 control: plain.apply(b)", a.plain.apply(b, [3]).value);
console.log("04 generic make.call(b)", a.make.call(b, 4).value);
console.log("05 generic make.bind(b)", a.make.bind(b)(5).value);
console.log("06 generic make.apply(b)", a.make.apply(b, [6]).value);
const bound = a.make.bind(b);
console.log("07 generic make.bind(b) stored", bound<number>(7).value);
