// Guards that must KEEP throwing (D-155, D-191): lies through `any`, calls through `any`, dynamic
// arguments, through each value form this slice touches.
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
type Factory = <T>(x: T) => Box<T>;
type NumMaker = (x: number) => Box<number>;
interface Maker {
  make<T>(x: T): Box<T>;
}
class Liar implements Maker {
  make<T>(x: T): Box<T> {
    return new Box("lie") as any;
  }
}
class Honest implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function lie<T>(x: T): Box<T> {
  return new Box("lie") as any;
}
const liar = new Liar();
const liarIface: Maker = new Liar();
const liarLit = {
  make<T>(x: T): Box<T> {
    return new Box("lie") as any;
  },
};
attempt("01 lying method value", () => {
  const f: Factory = liar.make;
  const b: Box<number> = f(5);
  return String(b.value);
});
attempt("02 lying interface method value", () => {
  const f: Factory = liarIface.make;
  const b: Box<number> = f(5);
  return String(b.value);
});
attempt("03 lying literal method value", () => {
  const f: Factory = liarLit.make;
  const b: Box<number> = f(5);
  return String(b.value);
});
attempt("04 lying bound function", () => {
  const f: Factory = lie.bind(undefined);
  const b: Box<number> = f(5);
  return String(b.value);
});
attempt("05 lying bound method", () => {
  const f: Factory = liar.make.bind(liar);
  const b: Box<number> = f(5);
  return String(b.value);
});
attempt("06 lying generic arrow in .map", () => {
  const boxes: Box<number>[] = [1].map(<T,>(x: T): Box<T> => new Box("lie") as any);
  return String(boxes[0].value);
});
attempt("07 lying value to a non-generic const", () => {
  const g = <T,>(x: T): Box<T> => new Box("lie") as any;
  const t: NumMaker = g;
  return String(t(5).value);
});
attempt("08 lying arrow for an interface's method", () => {
  const m: Maker = { make: <T,>(x: T) => new Box("lie") as any };
  const b: Box<number> = m.make(5);
  return String(b.value);
});
attempt("09 a lie through any read as Box<number>", () => {
  const a: any = new Box("s");
  const b: Box<number> = a;
  return String(b.value);
});
attempt("10 method value called through any", () => {
  const a: any = new Honest().make;
  const b: Box<number> = a(5);
  return String(b.value + 1);
});
attempt("11 method called through any", () => {
  const a: any = new Honest();
  const b: Box<number> = a.make(5);
  return String(b.value + 1);
});
attempt("12 method value with an any argument", () => {
  const f: Factory = new Honest().make;
  const loose: any = 3;
  const b: Box<Box<number>> = f<Box<number>>(loose);
  return String(b.value);
});
attempt("13 dynamic results used dynamically", () => {
  const a: any = new Honest();
  const f = a.make;
  const b = f.call(a, 5);
  return String(b.value + 1);
});
