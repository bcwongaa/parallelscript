class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  mk<T>(x: T): Box<T>;
}
class C implements Maker {
  constructor(public tag: string) {}
  mk<T>(x: T): Box<T> {
    return new Box(x);
  }
  tagged<T>(x: T): string {
    return `${this.tag}:${x}`;
  }
}
class D extends C {}
const c = new C("c");
const other: Maker = new C("i");
const loose: any = new C("a");
console.log(c.mk.call({}, 1).value);
console.log(c.mk.call(other, 2).value);
console.log(c.tagged.call(new D("d"), 3));
console.log(c.tagged.bind(new C("e"))(4));
console.log(c.mk.call(loose, 5).value);
console.log(c.mk.bind(null)(6).value);
console.log(c.tagged.apply(c, [7]));
