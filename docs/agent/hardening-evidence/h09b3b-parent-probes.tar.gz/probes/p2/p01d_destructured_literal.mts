// Family 1: a generic method destructured from an object literal.
class Box<T> {
  constructor(public value: T) {}
}
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const { make } = lit;
try {
  const b: Box<number> = make(5);
  console.log(b.value + 1);
} catch (error: any) {
  console.log(error.name, error.message);
}
