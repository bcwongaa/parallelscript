// Family 1 control: a class's non-generic method (not using `this`) destructured: the same
// PTS1001 as the generic one (pre-existing, not specific to generics).
class Twice {
  twice(x: number): number {
    return x * 2;
  }
}
const { twice } = new Twice();
console.log(twice(5));
