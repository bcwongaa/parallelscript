// Family 1: a generic method read as a value and passed on / stored / called later, then
// called with typed results. Controls: a static method value and a generic function declaration.
class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
type Factory = <T>(x: T) => Box<T>;
function exercise(label: string, factory: Factory): void {
  attempt(label, () => {
    const n: Box<number> = factory(9);
    const s: Box<string> = factory("nine");
    return `${n.value + 1} ${s.value.length} ${n instanceof Box}`;
  });
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  tag = "c";
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  static smake<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Holder<U> {
  constructor(public u: U) {}
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const viaIface: Maker = new ClassMaker();
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const litIface: Maker = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const held = new Holder<string>("h");

// controls
exercise("01 control: function declaration", make);
exercise("02 control: static method value", ClassMaker.smake);
// method values passed to a generic function type parameter
exercise("03 class method value", c.make);
exercise("04 interface method value (class instance)", viaIface.make);
exercise("05 object literal method value", lit.make);
exercise("06 interface method value (object literal)", litIface.make);
exercise("07 generic class's generic method value", held.make);
// stored, then called
const stored: Factory = c.make;
attempt("08 stored in a const", () => String(stored(5).value + 1));
// 09 (destructuring) is in p01b_destructured.pts: PTS1001 for a class's generic method on HEAD
function maybe(): ClassMaker | undefined {
  return c;
}
attempt("10 via ?.", () => {
  const f = maybe()?.make;
  const b: Box<number> = f!(5);
  return String(b.value + 1);
});
const inField = { f: c.make };
attempt("11 in a field", () => {
  const b: Box<number> = inField.f(5);
  return String(b.value + 1);
});
const inArray = [c.make];
attempt("12 in an array", () => {
  const b: Box<number> = inArray[0](5);
  return String(b.value + 1);
});
const inMap = new Map<string, Factory>([["k", c.make]]);
attempt("13 in a map", () => {
  const b: Box<number> = inMap.get("k")!(5);
  return String(b.value + 1);
});
const inRecord: Record<string, Factory> = { a: viaIface.make };
attempt("14 in a record", () => {
  const b: Box<number> = inRecord.a(5);
  return String(b.value + 1);
});
function returned(): Factory {
  return lit.make;
}
attempt("15 returned from a function", () => {
  const b: Box<number> = returned()(5);
  return String(b.value + 1);
});
attempt("16 control: static stored", () => {
  const f: Factory = ClassMaker.smake;
  const b: Box<number> = f(5);
  return String(b.value + 1);
});
attempt("17 local generic class's method value", () => {
  const f = new Holder<number>(1).make;
  const b: Box<string[]> = f(["a", "b"]);
  return String(b.value.length);
});
attempt("18 method value array result", () => {
  const f = c.make;
  const b: Box<number>[] = [f(1), f(2)];
  return String(b[0].value + b[1].value);
});
