// Family 2: `bind` of generic functions and methods, then typed calls. (The forms that are
// PTS1001 on HEAD are in p02b_bind_pts1001.pts, so this program compiles.)
class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
type Factory = <T>(x: T) => Box<T>;
function exercise(label: string, factory: Factory): void {
  attempt(label, () => {
    const n: Box<number> = factory(9);
    const s: Box<string> = factory("nine");
    return `${n.value + 1} ${s.value.length}`;
  });
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  static smake<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const viaIface: Maker = new ClassMaker();
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const arrow = <T,>(x: T): Box<T> => new Box(x);

exercise("01 decl.bind(undefined)", make.bind(undefined));
exercise("02 decl.bind(null)", make.bind(null));
exercise("03 generic arrow .bind(undefined)", arrow.bind(undefined));
exercise("04 class method .bind(c)", c.make.bind(c));
exercise("05 interface method .bind(m)", viaIface.make.bind(viaIface));
exercise("06 literal method .bind(lit)", lit.make.bind(lit));
exercise("07 static method .bind(undefined)", ClassMaker.smake.bind(undefined));
exercise("08 class method .bind(other instance)", c.make.bind(new ClassMaker()));
attempt("19 bound then stored as Factory", () => {
  const f: Factory = make.bind(undefined);
  const b: Box<number> = f(5);
  return String(b.value + 1);
});
