class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
function applyNum(f: (x: number) => Box<number>): number {
  return f(41).value + 1;
}
function applyStr(f: (x: string, i: number) => Box<string>): string {
  return f("s", 0).value + "!";
}
function contexts(factory: <T>(x: T) => Box<T>): void {
  attempt("param to user HOF", () => String(applyNum(factory)));
  attempt("param to user HOF with more params", () => applyStr(factory));
  attempt("param typed const", () => {
    const t: (x: number) => Box<number> = factory;
    return String(t(1).value + 1);
  });
  attempt("param optional", () => {
    const u: ((x: string) => Box<string>) | undefined = factory;
    return String(u?.("abc").value.length);
  });
  attempt("param map", () => {
    const bs: Box<number>[] = [1, 2].map(factory);
    return String(bs[0].value + bs[1].value);
  });
  attempt("param flatMap", () => {
    const bs: Box<number>[] = [1, 2].flatMap((x) => [factory(x)]);
    return String(bs[0].value + bs[1].value);
  });
  attempt("param as", () => String((factory as (x: number) => Box<number>)(6).value + 1));
  attempt("param in object of non-generic type", () => {
    const o: { f: (x: number) => Box<number> } = { f: factory };
    return String(o.f(7).value + 1);
  });
  attempt("param in array of non-generic type", () => {
    const fs: ((x: number) => Box<number>)[] = [factory];
    return String(fs[0](8).value + 1);
  });
  attempt("param in Array.from", () => {
    const bs: Box<number>[] = Array.from([1, 2], factory);
    return String(bs[1].value + 1);
  });
  attempt("param in find-less callback (forEach)", () => {
    let total = 0;
    [1, 2].forEach((x) => {
      total += factory(x).value;
    });
    return String(total);
  });
  attempt("param in then", () => {
    Promise.resolve(3).then(factory).then((b: Box<number>) => console.log("then", b.value + 1));
    return "scheduled";
  });
}
function local(): void {
  const localArrow = <T>(x: T) => new Box(x);
  const aliased = make;
  let mutable: <T>(x: T) => Box<T> = localArrow;
  attempt("local arrow to HOF", () => String(applyNum(localArrow)));
  attempt("aliased decl to HOF", () => String(applyNum(aliased)));
  attempt("let to HOF", () => String(applyNum(mutable)));
  mutable = make;
  attempt("let reassigned to map", () => {
    const bs: Box<number>[] = [5].map(mutable);
    return String(bs[0].value + 1);
  });
  attempt("inline arrow to typed const", () => {
    const t: (x: number) => Box<number> = <T>(x: T) => new Box(x);
    return String(t(1).value + 1);
  });
  attempt("inline function expression to map", () => {
    const bs: Box<number>[] = [1].map(function <T>(x: T): Box<T> {
      return new Box(x);
    });
    return String(bs[0].value + 1);
  });
}
contexts(make);
contexts(<T>(x: T) => new Box(x));
local();
