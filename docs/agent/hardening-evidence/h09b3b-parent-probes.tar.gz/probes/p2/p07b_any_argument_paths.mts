// Guards: how an honest `any` argument is treated today by each demand kind (value call of a
// generic function type: D-148, typedArguments converts it with a check and calls the instance;
// call by name through an interface: D-191, keeps the erased copy; a class's direct call: the
// instance with a checked argument).
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
type Factory = <T>(x: T) => Box<T>;
interface Maker {
  make<T>(x: T): Box<T>;
}
class Honest implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
const loose: any = new Box(3);
const looseNumber: any = 3;
const factory: Factory = make;
const honest = new Honest();
const viaIface: Maker = honest;
attempt("01 value call, any argument", () => String(factory<Box<number>>(loose).value.value + 1));
attempt("02 value call, any number argument", () => String(factory<number>(looseNumber).value + 1));
attempt("03 by name (interface), any argument", () => String(viaIface.make<Box<number>>(loose).value.value + 1));
attempt("04 by name (interface), any number argument", () => String(viaIface.make<number>(looseNumber).value + 1));
attempt("05 class direct, any argument", () => String(honest.make<Box<number>>(loose).value.value + 1));
attempt("06 method value, any argument", () => {
  const f: Factory = honest.make;
  return String(f<number>(looseNumber).value + 1);
});
