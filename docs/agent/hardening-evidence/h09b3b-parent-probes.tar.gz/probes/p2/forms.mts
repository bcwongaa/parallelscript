class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class Holder<U> {
  constructor(public u: U) {}
  pair<T>(x: T): Box<[U, T]> {
    return new Box([this.u, x] as [U, T]);
  }
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
function exercise(label: string, factory: <T>(x: T) => Box<T>): void {
  attempt(label, () => {
    const n: Box<number> = factory(9);
    const s: Box<string> = factory("nine");
    return `${n.value + 1} ${s.value.length}`;
  });
}
function applyNum(f: (x: number) => Box<number>): number {
  return f(41).value + 1;
}
const im: Maker = new ClassMaker();
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const litMaker: Maker = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const arrowMaker: Maker = { make: <T>(x: T) => new Box(x) };
const cm = new ClassMaker();
exercise("class method value", cm.make);
exercise("interface method value (class)", im.make);
exercise("interface method value (literal)", litMaker.make);
exercise("interface method value (arrow property)", arrowMaker.make);
exercise("literal method value", lit.make);
exercise("bind null", make.bind(null));
exercise("bound method", cm.make.bind(cm));
exercise("bound interface method", im.make.bind(im));
exercise("bound literal method", lit.make.bind(lit));
const arrow = <T>(x: T) => new Box(x);
exercise("bound arrow", arrow.bind(undefined));
attempt("arrow property call", () => String(arrowMaker.make(5).value + 1));
const h = new Holder("u");
attempt("generic class instance method value", () => {
  const p = h.pair;
  const b: Box<[string, number]> = p(3);
  return `${b.value[0]} ${b.value[1] + 1}`;
});
const makers: (<T>(x: T) => Box<T>)[] = [cm.make, im.make, lit.make];
attempt("method values in an array", () => makers.map((f) => f(2).value).join(","));
attempt("user HOF with inline arrow", () => String(applyNum(<T>(x: T) => new Box(x))));
attempt("user HOF with aliased", () => String(applyNum(arrow)));
attempt("user HOF with method value", () => String(applyNum(im.make)));
attempt("map with method value", () => {
  const bs: Box<number>[] = [1, 2].map(im.make);
  return String(bs[0].value + bs[1].value);
});
attempt("map with literal method value", () => {
  const bs: Box<number>[] = [1, 2].map(lit.make);
  return String(bs[0].value + bs[1].value);
});
attempt("filter/map chain", () => {
  const bs: Box<string>[] = ["a", "bb"].map(arrow).filter((b) => b.value.length > 1);
  return bs.map((b) => b.value).join(",");
});
attempt("typed const of non-generic function type", () => {
  const t: (x: number) => Box<number> = arrow;
  return String(t(1).value + 1);
});
attempt("optional non-generic function type", () => {
  const t: ((x: string) => Box<string>) | undefined = make;
  const u: ((x: string) => Box<string>) | undefined = arrow;
  return `${t!("ab").value.length} ${u?.("abc").value.length}`;
});
function returning(): (x: number) => Box<number> {
  return arrow;
}
attempt("returned as non-generic", () => String(returning()(4).value + 1));
attempt("as cast", () => String((arrow as (x: number) => Box<number>)(6).value + 1));
attempt("object property of non-generic type", () => {
  const o: { f: (x: number) => Box<number> } = { f: arrow };
  return String(o.f(7).value + 1);
});
attempt("Array.from mapper", () => {
  const bs: Box<number>[] = Array.from([1, 2], arrow);
  return String(bs[1].value);
});
