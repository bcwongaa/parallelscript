// Family 1: a generic method destructured from an interface's value (a class instance).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const m: Maker = new ClassMaker();
const { make } = m;
try {
  const b: Box<number> = make(5);
  console.log(b.value + 1);
} catch (error: any) {
  console.log(error.name, error.message);
}
