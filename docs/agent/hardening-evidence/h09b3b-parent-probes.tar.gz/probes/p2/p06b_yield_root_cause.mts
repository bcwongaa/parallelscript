// Family 5 root cause check: is it the suspension, or the resumed value being a dynamic value
// that D-191's gate (passedAsIs: never a dynamic value) keeps off the instance? Compare a yield
// argument with a typed local holding the yield's value, an `as number`, and an `any` argument
// outside any generator (D-191 by design).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const im: Maker = new ClassMaker();
function drive(label: string, g: () => Generator<number, void, number>): void {
  try {
    const it = g();
    it.next();
    it.next(20);
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
drive("01", function* () {
  const b: Box<number> = im.make(yield 1);
  console.log("01 yield argument", b.value + 1);
});
drive("02", function* () {
  const r = yield 1;
  const b: Box<number> = im.make(r);
  console.log("02 typed local of the yield's value", b.value + 1);
});
drive("03", function* () {
  const b: Box<number> = im.make((yield 1) as number);
  console.log("03 yield as number", b.value + 1);
});
drive("04", function* () {
  const b: Box<number> = im.make(0 + (yield 1));
  console.log("04 0 + yield", b.value + 1);
});
drive("05", function* () {
  const b: Box<number> = im.make<number>(yield 1);
  console.log("05 explicit type argument", b.value + 1);
});
try {
  const loose: any = 20;
  const b: Box<number> = im.make<number>(loose);
  console.log("06 any argument (D-191 by design)", b.value + 1);
} catch (error: any) {
  console.log("06 any argument (D-191 by design)", error.name, error.message);
}
