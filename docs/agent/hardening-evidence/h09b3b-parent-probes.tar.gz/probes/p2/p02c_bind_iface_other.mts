// Family 2, PTS1001 neighbour: an interface's method bound with another object of the interface
// as `this`.
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const a: Maker = new ClassMaker();
const z: Maker = new ClassMaker();
const f = a.make.bind(z);
const b: Box<number> = f(5);
console.log(b.value + 1);
