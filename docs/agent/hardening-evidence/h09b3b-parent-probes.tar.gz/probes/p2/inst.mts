class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
const c = new ClassMaker();
const m: Maker = c;
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
attempt("decl instantiation", () => String(make<number>(1).value + 1));
attempt("class method instantiation", () => {
  const f = c.make<number>;
  return String(f(2).value + 1);
});
attempt("interface method instantiation", () => {
  const f = m.make<string>;
  return String(f("ab").value.length);
});
function local(): string {
  const arrow = <T,>(x: T): Box<T> => new Box(x);
  const f = arrow<number>;
  return String(f(3).value + 1);
}
attempt("local arrow instantiation", local);
