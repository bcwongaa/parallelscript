// Family 2, PTS1001 neighbours: an object type's method bound or called with another object as
// `this` (D-044's rule: o's own method may be a closure of o's). One form per program would be
// needed to see each separately; here all three are written and the first reported wins.
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
const lit = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const other = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
const f = lit.make.bind(other);
const b: Box<number> = f(5);
console.log(b.value + 1);
