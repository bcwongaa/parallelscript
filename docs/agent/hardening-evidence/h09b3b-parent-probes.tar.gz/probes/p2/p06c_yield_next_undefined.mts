// Family 5 neighbour: what a yield's value is when next() passes nothing (undefined where tsc
// says number). Shows where HEAD checks the resumed value today: a typed local converts it (and
// throws), console.log takes it as it is. A fix that converts at the yield must not change 02.
function drive(label: string, g: () => Generator<number, void, number>): void {
  try {
    const it = g();
    it.next();
    it.next();
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
drive("01", function* () {
  const r = yield 1;
  console.log("01 typed local", r);
});
drive("02", function* () {
  console.log("02 console.log(yield)", yield 1);
});
drive("03", function* () {
  const r: number = (yield 1) + 1;
  console.log("03 arithmetic", r);
});
