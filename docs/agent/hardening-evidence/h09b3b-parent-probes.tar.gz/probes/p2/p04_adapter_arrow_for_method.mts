// Family 3 (adapter): an arrow property where an interface declares a generic method is wrapped
// in a functionAsMethod adapter (D-191), whose closure lists no instances. Also the same arrow
// where the interface declares a function-typed property (a generic function value: works since
// H09b1), and a method shorthand (control: works since H09b1).
class Box<T> {
  constructor(public value: T) {}
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
interface Maker {
  make<T>(x: T): Box<T>;
}
interface PropMaker {
  make: <T>(x: T) => Box<T>;
}
const arrowForMethod: Maker = { make: <T,>(x: T) => new Box(x) };
const arrowForProp: PropMaker = { make: <T,>(x: T) => new Box(x) };
const methodForMethod: Maker = {
  make<T>(x: T): Box<T> {
    return new Box(x);
  },
};
function mk<T>(x: T): Box<T> {
  return new Box(x);
}
const declForMethod: Maker = { make: mk };
attempt("01 arrow property for an interface's method", () => {
  const n: Box<number> = arrowForMethod.make(5);
  return String(n.value + 1);
});
attempt("02 control: arrow for a function-typed property", () => {
  const n: Box<number> = arrowForProp.make(5);
  return String(n.value + 1);
});
attempt("03 control: method shorthand for an interface's method", () => {
  const n: Box<number> = methodForMethod.make(5);
  return String(n.value + 1);
});
attempt("04 declaration for an interface's method", () => {
  const n: Box<number> = declForMethod.make(5);
  return String(n.value + 1);
});
function locally(): void {
  const local = <T,>(x: T): Box<T> => new Box(x);
  const m: Maker = { make: local };
  attempt("05 local arrow const for an interface's method", () => {
    const n: Box<string> = m.make("ab");
    return String(n.value.length);
  });
}
locally();
