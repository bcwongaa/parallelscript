class Base {
  constructor(public n: number) {}
  twice(x: number): number {
    return x * 2 + this.n;
  }
  get g(): number {
    return 1;
  }
}
class Sub extends Base {
  override twice(x: number): number {
    return x * 3 + this.n;
  }
}
const b: Base = new Sub(100);
const { twice, n, g } = b;
console.log(twice(5), n, g);
function f({ twice: t }: Base): number {
  return t(1);
}
console.log(f(new Base(10)), f(new Sub(20)));
