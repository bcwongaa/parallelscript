class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
  wrap<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
  wrap<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const m: Maker = new ClassMaker();
function* g(key: "make" | "wrap"): Generator<number, void, number> {
  const b: Box<number> = m[key](yield 1);
  console.log(key, b.value + 1);
}
for (const key of ["make", "wrap"] as const) {
  try {
    const it = g(key);
    it.next();
    it.next(20);
  } catch (e: any) {
    console.log(key, e.name, e.message);
  }
}
async function a(key: "make" | "wrap"): Promise<void> {
  const b: Box<number> = m[key](await Promise.resolve(30));
  console.log("async", key, b.value + 1);
}
a("wrap").catch((e: any) => console.log("async", e.name, e.message));
