// Family 3: a generic value given where a non-generic function type goes. Control: a generic
// function declaration named directly in such a context finds its instance (genericValue).
class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
type NumMaker = (x: number) => Box<number>;
function applyHof(f: NumMaker): Box<number> {
  return f(5);
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const c = new ClassMaker();
const moduleArrow = <T,>(x: T): Box<T> => new Box(x);
const aliased = make;

attempt("01 control: decl in .map", () => {
  const boxes: Box<number>[] = [1, 2].map(make);
  return String(boxes[0].value + boxes[1].value);
});
attempt("02 control: decl to a user HOF", () => String(applyHof(make).value + 1));
attempt("03 control: decl to a non-generic const", () => {
  const t: NumMaker = make;
  return String(t(5).value + 1);
});
attempt("04 inline generic arrow in .map", () => {
  const boxes: Box<number>[] = [1, 2].map(<T,>(x: T): Box<T> => new Box(x));
  return String(boxes[0].value + boxes[1].value);
});
attempt("05 inline generic arrow in .flatMap", () => {
  const boxes: Box<number>[] = [1, 2].flatMap(<T,>(x: T): Box<T>[] => [new Box(x)]);
  return String(boxes[0].value + boxes[1].value);
});
attempt("06 inline generic arrow in Array.from", () => {
  const boxes: Box<number>[] = Array.from([1, 2], <T,>(x: T): Box<T> => new Box(x));
  return String(boxes[0].value + boxes[1].value);
});
attempt("07 inline generic arrow to a user HOF", () => String(applyHof(<T,>(x: T): Box<T> => new Box(x)).value + 1));
attempt("08 aliased decl in .map", () => {
  const boxes: Box<number>[] = [3].map(aliased);
  return String(boxes[0].value + 1);
});
attempt("09 module generic arrow const in .map", () => {
  const boxes: Box<number>[] = [3].map(moduleArrow);
  return String(boxes[0].value + 1);
});
attempt("10 module generic arrow const to a user HOF", () => String(applyHof(moduleArrow).value + 1));
function locals(): void {
  const local = <T,>(x: T): Box<T> => new Box(x);
  attempt("11 local generic arrow to a non-generic const", () => {
    const t: NumMaker = local;
    return String(t(5).value + 1);
  });
  attempt("12 local generic arrow in .map", () => {
    const boxes: Box<number>[] = [4].map(local);
    return String(boxes[0].value + 1);
  });
  let mutable = <T,>(x: T): Box<T> => new Box(x);
  attempt("13 let generic arrow to a user HOF", () => String(applyHof(mutable).value + 1));
  function ret(): NumMaker {
    return local;
  }
  attempt("14 returned where a non-generic function type goes", () => String(ret()(5).value + 1));
  attempt("15 object literal property of a non-generic function type", () => {
    const o: { f: NumMaker } = { f: local };
    return String(o.f(5).value + 1);
  });
  attempt("16 array element of a non-generic function type", () => {
    const fs: NumMaker[] = [local];
    return String(fs[0](5).value + 1);
  });
  attempt("17 as a non-generic function type", () => String((local as NumMaker)(5).value + 1));
  attempt("18 | undefined context", () => {
    const t: NumMaker | undefined = local;
    return String(t!(5).value + 1);
  });
}
locals();
function param(g: <T>(x: T) => Box<T>): void {
  attempt("19 generic parameter in .map", () => {
    const boxes: Box<number>[] = [6].map(g);
    return String(boxes[0].value + 1);
  });
  attempt("20 generic parameter to a non-generic const", () => {
    const t: NumMaker = g;
    return String(t(6).value + 1);
  });
}
param(make);
attempt("21 class method value in .map", () => {
  const boxes: Box<number>[] = [1].map(c.make);
  return String(boxes[0].value + 1);
});
attempt("22 class method value to a user HOF", () => String(applyHof(c.make).value + 1));
class WithField {
  f = <T,>(x: T): Box<T> => new Box(x);
}
attempt("23 field generic arrow to a non-generic const", () => {
  const t: NumMaker = new WithField().f;
  return String(t(7).value + 1);
});
attempt("24 control: decl in .map with string", () => {
  const boxes: Box<string>[] = ["a", "bc"].map(make);
  return String(boxes[1].value.length);
});
