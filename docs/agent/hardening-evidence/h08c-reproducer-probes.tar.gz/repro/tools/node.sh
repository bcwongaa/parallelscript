#!/bin/bash
# node.sh FILE.pts...: run each program under Node as a strict-ESM .mts copy; print output and exit code.
set -u
NODE=$HOME/.local/node/bin/node
work=$(mktemp -d /tmp/h08c/repro/nodeonly.XXXX)
for f in "$@"; do
  name=$(basename "$f" .pts)
  cp "$f" "$work/$name.mts"
  echo "##### $name"
  (cd "$work" && timeout 60 "$NODE" --no-warnings --experimental-transform-types "$work/$name.mts" 2>&1)
  echo "[exit $?]"
done
rm -rf "$work"
