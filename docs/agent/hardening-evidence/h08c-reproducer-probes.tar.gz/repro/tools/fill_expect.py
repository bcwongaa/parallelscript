#!/usr/bin/env python3
"""fill_expect.py FILE.pts...: runs each program under Node (a strict-ESM .mts copy, as the
harness does) and rewrites its `// expect:` block (everything after the marker) to Node's
stdout, each line `// ` + text (or `//` for an empty line). Refuses if Node exits nonzero or
writes to stderr."""
import os
import subprocess
import sys
import tempfile

NODE = os.path.expanduser("~/.local/node/bin/node")
for path in sys.argv[1:]:
    src = open(path).read()
    marker = "// expect:\n"
    head = src[: src.index(marker) + len(marker)]
    with tempfile.TemporaryDirectory() as d:
        mts = os.path.join(d, os.path.basename(path)[:-4] + ".mts")
        open(mts, "w").write(src)
        p = subprocess.run([NODE, "--no-warnings", "--experimental-transform-types", mts], capture_output=True, text=True, timeout=60, cwd=d)
    if p.returncode != 0 or p.stderr:
        sys.exit(f"{path}: node exit {p.returncode}, stderr {p.stderr!r}")
    block = "".join(("// " + line if line else "//") + "\n" for line in p.stdout.splitlines())
    open(path, "w").write(head + block)
    print(f"{os.path.basename(path)}: {len(p.stdout.splitlines())} expect lines")
