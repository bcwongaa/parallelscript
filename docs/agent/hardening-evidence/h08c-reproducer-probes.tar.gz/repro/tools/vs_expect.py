#!/usr/bin/env python3
"""vs_expect.py TEST.pts OUTPUT.txt: compares a program's recorded output (cmp.sh's NAME.pts.txt,
whose last line is `[exit N]`) with the test's `// expect:` block plus `[exit 0]`; prints
each differing line and the count."""
import sys

test, output = sys.argv[1], sys.argv[2]
src = open(test).read()
block = src[src.index("// expect:\n") + len("// expect:\n"):]
want = [line[3:] if line.startswith("// ") else "" for line in block.splitlines()] + ["[exit 0]"]
got = open(output).read().splitlines()
bad = 0
for i in range(max(len(want), len(got))):
    w = want[i] if i < len(want) else "<missing>"
    g = got[i] if i < len(got) else "<missing>"
    if w != g:
        bad += 1
        print(f"  want: {w}\n  got:  {g}")
print(f"{test}: {len(want) - bad if bad <= len(want) else 0}/{len(want)} lines as expected, {bad} differ")
sys.exit(1 if bad else 0)
