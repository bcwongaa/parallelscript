#!/bin/bash
# harness.sh OUTFILE NAME...: run the named run tests under TestRun and TestRunMatchesNode in
# this reproducer's worktree (Node first on PATH, Node required), writing the verbose log to
# OUTFILE with the exit code appended.
set -u
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ada8309aafb8cc260
out=$1
shift
names=$(IFS='|'; echo "$*")
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH"
cd "$W" || exit 1
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -timeout 40m -v -run "^(TestRun|TestRunMatchesNode)\$/^($names)\$" ./pts/tests/ > "$out" 2>&1
code=$?
echo "exit=$code" >> "$out"
exit $code
