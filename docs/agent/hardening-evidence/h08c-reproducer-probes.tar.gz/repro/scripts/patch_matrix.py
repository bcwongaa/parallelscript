#!/usr/bin/env python3
"""patch_matrix.py MATRIX.py: H08c's edits to the copy of H08b's matrix.py (see its docstring)."""
import sys

p = sys.argv[1]
s = open(p).read()


def rep(old, new, count=1):
    global s
    if s.count(old) != count:
        raise SystemExit(f"expected {count} of {old!r}, found {s.count(old)}")
    s = s.replace(old, new)


rep('''def S(name, etypes, body, decl="", mut="", needs=None):
    return dict(name=name, etypes=etypes, body=body, decl=decl, mut=mut, needs=needs)
''', '''def S(name, etypes, body, decl="", mut="", needs=None, modes=None):
    return dict(name=name, etypes=etypes, body=body, decl=decl, mut=mut, needs=needs, modes=modes)


PLAIN = ("plain",)
''')

rep('''    S("new Map(literal)", ("pair",), "return fmtMap_N(new Map([SP, VAL]));"),
]
''', '''    S("new Map(literal)", ("pair",), "return fmtMap_N(new Map([SP, VAL]));"),
    # H08c: plain-mode sites (no suspension), appended.
    S("Math.hypot", NUMS, "return String(Math.hypot(SP, VAL));", modes=PLAIN),
    S("String.fromCodePoint", NUMS, "return codes(String.fromCodePoint(SP, VAL));", modes=PLAIN),
    S("super call", ALL, "return new Q_N().s;",
      decl="class Q_N extends P_N {\\n  constructor() {\\n    super(SP, VAL);\\n  }\\n}", modes=PLAIN),
    S("generic method", ALL, "return c_N.gm(SP, VAL);", modes=PLAIN),
    S("union method", ALL, "return u_N.f(SP, VAL);",
      decl="class D_N {\\n  f(...xs: (E)[]): string { return \\"D\\" + fmt_N(xs); }\\n}\\n"
           "const pickU_N = (): C_N | D_N => c_N;\\nconst u_N = pickU_N();", modes=PLAIN),
    S("new Float64Array(literal)", NUMS, "return new Float64Array([SP, VAL]).join(\\"/\\");", modes=PLAIN),
    S("Array.from(literal)", ALL, "return fmt_N(Array.from([SP, VAL]));", modes=PLAIN),
    S("new through any", ALL, "return String(new AP_N(SP, VAL).s);", decl="const AP_N: any = P_N;", modes=PLAIN),
    S("arrow rest fn, spread again after (guard)", ALL, "return f_N(SP, VAL, SP);", modes=PLAIN),
    S("any function, spread again after (guard)", ALL, "return String(af_N(SP, VAL, SP));", modes=PLAIN),
    S("console.log, spread again after (guard)", ALL, "console.log(\\"{{ID/log}}\\", SP, VAL, SP);\\n  return \\"\\";", modes=PLAIN),
]
''')

rep('''  static sf(...xs: (E)[]): string { return fmt_N(xs); }
''', '''  static sf(...xs: (E)[]): string { return fmt_N(xs); }
  gm<T>(...xs: T[]): string { return xs.map((x) => String(x)).join("/"); }
''')

rep('''def susp_text(mode, n, variant):
    if variant in ("const", "pre"):
''', '''def susp_text(mode, n, variant):
    if mode == "plain" and variant == "real":
        raise ValueError("plain mode has no real variant")
    if variant in ("const", "pre"):
''')

# the declarations get every substitution (a site's decl may hold SP and VAL: super call)
rep('''    decl = case["decl"]
    for key in ("E", "FMT", "Z2", "Z"):
        if key in case["subst"]:
            decl = re.sub(r"\\b" + key + r"\\b", lambda m, v=case["subst"][key]: v, decl)
    decl = re.sub(r"_N\\b", f"_{n}", decl)
''', '''    decl = case["decl"]
    for key in ("E", "FMT", "Z2", "Z"):
        if key in case["subst"]:
            decl = re.sub(r"\\b" + key + r"\\b", lambda m, v=case["subst"][key]: v, decl)
    if "SP" in re.findall(r"\\bSP\\b", decl):  # H08c: a site whose declaration holds the spread (super call)
        decl = substitute(decl, case, variant)
    decl = re.sub(r"_N\\b", f"_{n}", decl)
''')

rep('''    if mode == "yield":
        lines.append(f"function* g_{n}(): Generator<number, string, number> {{\\n  {body}\\n}}")
''', '''    if mode == "plain":
        lines.append(f"function g_{n}(): string {{\\n  {body}\\n}}")
        lines.append(f"function run_{n}(): void {{\\n  report(\\"{case['id']}\\", g_{n}());\\n}}")
    elif mode == "yield":
        lines.append(f"function* g_{n}(): Generator<number, string, number> {{\\n  {body}\\n}}")
''')

rep('''    if mode == "yield":
        parts.append("\\n".join(f"try {{ run_{c['n']}(); }}''', '''    if mode in ("yield", "plain"):
        parts.append("\\n".join(f"try {{ run_{c['n']}(); }}''')

rep('''    for mode in ("yield", "await"):
        for kind in ELEMENT_KINDS:
            for mut_name, mut in kind["muts"].items():
                group = []
                for site in SPREAD_SITES:
                    if kind["etype"] in site["etypes"] and site_applies(site, kind):
''', '''    for mode in MODES:
        for kind in ELEMENT_KINDS:
            for mut_name, mut in kind["muts"].items():
                group = []
                for site in SPREAD_SITES:
                    if site["modes"] and mode not in site["modes"]:
                        continue
                    if kind["etype"] in site["etypes"] and site_applies(site, kind):
''')

rep('''NODE = os.path.expanduser("~/.local/node/bin/node")
''', '''NODE = os.path.expanduser("~/.local/node/bin/node")
MODES = tuple(os.environ.get("MODES", "yield,await").split(","))  # H08c: gen's modes (plain, yield, await)
VARIANTS = tuple(os.environ.get("VARIANTS", "real,sync,const").split(","))  # H08c: run's variants
''')

rep('''    for variant in ("real", "sync", "const"):
        ncode, nlines, nerr = node_variant(work, name, mode, cases, variant)''', '''    for variant in VARIANTS:
        ncode, nlines, nerr = node_variant(work, name, mode, cases, variant)''')

rep('''    json.dump(dict(cli=CLI, home=HOME, results=results), open(os.path.join(matrix, "results.json"), "w"), indent=1)
    summarize(matrix, results)
''', '''    json.dump(dict(cli=CLI, home=HOME, results=results), open(os.path.join(matrix, "results.json"), "w"), indent=1)
    if "real" in VARIANTS:
        summarize(matrix, results)
    else:
        summarize_sync(matrix, results)
''')

rep('''def rerun(matrix, names):''', '''def classify_sync(r):
    """H08c: a case run without the real variant: its sync verdict, with its const control's."""
    sync, const = r["sync"], r["const"]
    v = sync["verdict"]
    if v == "OK":
        return "OK" if const["verdict"] == "OK" else f"OK(ctl:{const['verdict']})"
    if v == "WRONG":
        return "WRONG" if const["verdict"] == "OK" else f"WRONG(ctl:{const['verdict']})"
    return f"{v}(ctl:{const['verdict']})"


def summarize_sync(matrix, results):
    """H08c: summary.txt for a sync/const run. WRONG = the sync line differs from Node's while
    the const control matches (the order without a suspension, C152/C153); WRONG(ctl:X) = the
    const control is X too (pre-existing beside the order)."""
    out = []
    verdicts = collections.Counter(r["sync"]["verdict"] for r in results.values())
    out.append(f"cases: {len(results)}  (sync verdicts) " + "  ".join(f"{k}={v}" for k, v in sorted(verdicts.items())))
    cls = collections.Counter(classify_sync(r) for r in results.values())
    out.append("by sync verdict with const control: " + ", ".join(f"{k}={v}" for k, v in sorted(cls.items())))
    for key in ("mode", "site", "kind", "etype", "mut"):
        by = collections.defaultdict(collections.Counter)
        for r in results.values():
            by[(r["dims"]["family"], r["dims"][key])][classify_sync(r)] += 1
        out.append(f"\\nby family and {key}:")
        for k in sorted(by):
            out.append(f"  {k[0]:7s} {k[1]:48s} " + "  ".join(f"{v}={c}" for v, c in sorted(by[k].items())))
    out.append("\\nevery case that isn't OK:")
    for cid in sorted(results, key=lambda c: (classify_sync(results[c]), results[c]["n"])):
        r = results[cid]
        if r["sync"]["verdict"] == "OK":
            continue
        out.append(f"{classify_sync(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['sync'].get('pts')}")
        out.append(f"        node: {r['sync'].get('node')}")
        if r["const"]["verdict"] != "OK":
            out.append(f"        const {r['const']['verdict']}: pts {r['const'].get('pts')} node {r['const'].get('node')}")
    with open(os.path.join(matrix, "summary.txt"), "w") as f:
        f.write("\\n".join(out) + "\\n")
    print("\\n".join(out[:3]))


def classify_sync_causes(matrix, jobs):
    """H08c: for each sync-WRONG case, the Node-only "pre" variant (the mutation before the
    whole statement): LATE when PTS's sync value is the pre value (the spread read what the
    later operand left), OTHER otherwise. Writes causes.json and causes.txt."""
    results = json.load(open(os.path.join(matrix, "results.json")))["results"]
    manifest = json.load(open(os.path.join(matrix, "manifest.json")))
    wanted = {cid for cid, r in results.items() if r["sync"]["verdict"] == "WRONG"}
    jobs_list = [(name, [c for c in cases if c["id"] in wanted]) for name, cases in manifest["programs"].items()]
    jobs_list = [(name, group) for name, group in jobs_list if group]

    def node_pre(item):
        name, group = item
        work = os.path.join(matrix, "work", name)
        os.makedirs(work, exist_ok=True)
        code, nl, err = node_variant(work, name, group[0]["mode"], group, "pre")
        return {c["id"]: case_lines(nl, c["id"]) for c in group}

    pre = {}
    with concurrent.futures.ThreadPoolExecutor(jobs) as pool:
        for res in pool.map(node_pre, jobs_list):
            pre.update(res)
    causes = {}
    for cid in sorted(wanted, key=lambda c: results[c]["n"]):
        got, late = results[cid]["sync"]["pts"], pre.get(cid, [])
        label = "LATE" if [value_of(x) for x in got] == [value_of(x) for x in late] else "OTHER"
        causes[cid] = dict(label=label, pre=late)
    json.dump(causes, open(os.path.join(matrix, "causes.json"), "w"), indent=1)
    out = ["causes of the sync-WRONG cases (Node 'pre' variant: the mutation before the statement):"]
    by = collections.defaultdict(collections.Counter)
    for cid, c in causes.items():
        by[(results[cid]["dims"]["family"], classify_sync(results[cid]))][c["label"]] += 1
    for k in sorted(by):
        out.append(f"  {k[0]:7s} {k[1]:26s} " + "  ".join(f"{v}={n}" for v, n in sorted(by[k].items())))
    others = [cid for cid, c in causes.items() if c["label"] == "OTHER"]
    out.append(f"OTHER cases ({len(others)}):")
    for cid in others:
        r = results[cid]
        out.append(f"  {classify_sync(r):24s} c{r['n']} {cid}")
        out.append(f"        pts:  {r['sync']['pts']}")
        out.append(f"        node: {r['sync']['node']}")
        out.append(f"        pre:  {causes[cid]['pre']}")
    with open(os.path.join(matrix, "causes.txt"), "w") as f:
        f.write("\\n".join(out) + "\\n")
    print("\\n".join(out[:20]))


def rerun(matrix, names):''')

rep('''    elif cmd == "summarize":
        summarize(matrix, json.load(open(os.path.join(matrix, "results.json")))["results"])
''', '''    elif cmd == "summarize":
        summarize(matrix, json.load(open(os.path.join(matrix, "results.json")))["results"])
    elif cmd == "summarize_sync":  # H08c
        summarize_sync(matrix, json.load(open(os.path.join(matrix, "results.json")))["results"])
    elif cmd == "classify_sync":  # H08c
        classify_sync_causes(matrix, int(sys.argv[3]) if len(sys.argv) > 3 else 2)
''')

open(p, "w").write(s)
print("patched")
