#!/usr/bin/env python3
"""gen_console.py OUTDIR: one small program per console spread case (a PTS1001 in one
case would stop a combined program from building)."""
import os
import sys

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
pre = '''class Bag implements Iterable<number> {
  items = [1, 2];
  *[Symbol.iterator](): Iterator<number> {
    for (const x of this.items) yield x;
  }
}
function* gen(): Generator<number> {
  yield 1;
  yield 2;
}
const set = new Set([1, 2]);
const map = new Map([[1, 10], [2, 20]]);
const str = "a😀b";
const tuple: [number, string] = [1, "b"];
const typed = new Float64Array([1, 2]);
const iter: Iterable<number> = set;
const lit = {
  items: [1, 2],
  *[Symbol.iterator](): Iterator<number> {
    for (const x of this.items) yield x;
  },
};
'''
grow = 'const xs = [1, 2];\nconst grow = (): number => {\n  xs.push(100);\n  xs[0] = -5;\n  return 10;\n};\n'
cases = {
    "log_set": 'console.log("set", ...set, 3);',
    "log_map": 'console.log("map", ...map, 3);',
    "log_string": 'console.log("string", ...str, 3);',
    "log_generator": 'console.log("generator", ...gen(), 3);',
    "log_class_iterable": 'console.log("class iterable", ...new Bag(), 3);',
    "log_literal_iterable": 'console.log("literal iterable", ...lit, 3);',
    "log_iterable_iface": 'console.log("Iterable<number>", ...iter, 3);',
    "log_tuple": 'console.log("tuple", ...tuple, 3);',
    "log_typed": 'console.log("typed", ...typed, 3);',
    "log_set_values": 'console.log("set.values()", ...set.values(), 3);',
    "log_map_keys": 'console.log("map.keys()", ...map.keys(), 3);',
    "log_arr_values": 'console.log("arr.values()", ...[1, 2].values(), 3);',
    "log_arr_entries": 'console.log("arr.entries()", ...[1, 2].entries(), 3);',
    "error_set": 'console.error("set", ...set, 3);',
    "info_set": 'console.info("set", ...set, 3);',
    "warn_xs": grow + 'console.warn("warn", ...xs, grow());',
    "error_xs": grow + 'console.error("error", ...xs, grow());',
    "info_xs": grow + 'console.info("info", ...xs, grow());',
    "debug_xs": grow + 'console.debug("debug", ...xs, grow());',
    "group_xs": grow + 'console.group("group", ...xs, grow());\nconsole.groupEnd();\nconsole.log("after");',
    "assert_xs": grow + 'console.assert(false, "assert", ...xs, grow());',
    "log_tuple_write": 'const t: [number, number] = [1, 2];\nconst w = (): number => {\n  t[0] = -5;\n  return 10;\n};\nconsole.log("tuple write", ...t, w());',
    "log_typed_write": 'const ta = new Float64Array([1, 2]);\nconst w = (): number => {\n  ta[0] = -5;\n  return 10;\n};\nconsole.log("typed write", ...ta, w());',
    "log_any_array": 'const ys: any = [1, 2];\nconst g = (): number => {\n  ys.push(100);\n  ys[0] = -5;\n  return 10;\n};\nconsole.log("any array", ...ys, g());',
    "log_values_write": grow + 'console.log("values", ...xs.values(), grow());',
    "log_set_add": 'const s = new Set([1, 2]);\nconst add = (): number => {\n  s.add(100);\n  return 10;\n};\nconsole.log("set add", ...s, add());',
    "log_shrink": 'const zs = [1, 2, 3];\nconst shrink = (): number => {\n  zs.length = 0;\n  return 10;\n};\nconsole.log("shrink", ...zs, shrink());',
    "log_rest_tuple_write": 'const rt: [number, ...number[]] = [1, 2];\nconst w = (): number => {\n  rt.push(100);\n  rt[0] = -5;\n  return 10;\n};\nconsole.log("rest tuple", ...rt, w());',
}
for name, body in cases.items():
    with open(os.path.join(out, name + ".pts"), "w") as f:
        f.write(pre + body + "\n")
print(len(cases), "programs")
