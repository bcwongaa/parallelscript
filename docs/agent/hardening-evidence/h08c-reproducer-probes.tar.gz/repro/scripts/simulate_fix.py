#!/usr/bin/env python3
"""simulate_fix.py IN.pts OUT.pts CALLEE...: a copy of a test in which each spread argument
`...E` of a call `CALLEE(…)` is written `...[...E]`: an array literal of E's items, made at
the spread's position (spreadParts / ValueToArray, which the base already gets right), so
the call through `any` spreads a fresh array no later operand can change. On the base, this
is what a fix of C152/C153 for calls through `any` should print; if Node prints the same as
the original test's expect block, the test asks for nothing but that."""
import re
import sys

src, dst, callees = sys.argv[1], sys.argv[2], sys.argv[3:]
text = open(src).read()
out = []
i = 0
pattern = re.compile("(" + "|".join(re.escape(c) for c in callees) + r")\(")
while True:
    m = pattern.search(text, i)
    if not m:
        out.append(text[i:])
        break
    out.append(text[i:m.end()])
    j = m.end()
    # walk the arguments of this call at depth 0, rewriting each `...E`
    depth = 0
    start = j
    args_out = []
    k = j
    while True:
        ch = text[k]
        if ch in "([{":
            depth += 1
        elif ch in ")]}":
            if depth == 0:
                args_out.append(text[start:k])
                break
            depth -= 1
        elif ch == "," and depth == 0:
            args_out.append(text[start:k])
            start = k + 1
        k += 1
    rewritten = []
    for a in args_out:
        stripped = a.lstrip()
        lead = a[: len(a) - len(stripped)]
        if stripped.startswith("..."):
            rewritten.append(f"{lead}...[...{stripped[3:].rstrip()}]")
        else:
            rewritten.append(a)
    out.append(",".join(rewritten))
    i = k  # the closing paren is copied with the rest
open(dst, "w").write("".join(out))
