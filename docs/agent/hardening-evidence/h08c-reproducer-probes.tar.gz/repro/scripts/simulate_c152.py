#!/usr/bin/env python3
"""simulate_c152.py IN.pts OUT.pts: a copy of a C152 test in which each spread of an array
the later operand changes (`...xs`, `...xs.values()`, `...(maybe() ?? [])`, `...view`,
`...words`, `...boxes`, `...holes`, `...sources`, `...entries`) is written `...[...E]`: an
array literal of E's elements, made at the spread's position, which the base already gets
right (an inner literal is an operand evaluated before the later ones). Spreads of tuples
(the guards that need a tuple type), sets, objects and rest-parameter declarations are left
alone. On the base, the copy prints what a fix of C152 should print."""
import re
import sys

src, dst = sys.argv[1], sys.argv[2]
text = open(src).read()
code, marker, expect = text.partition("// expect:\n")
names = r"(?:xs|view|words|boxes|holes|sources|entries)"
code = re.sub(r"\.\.\.(" + names + r"(?:\.values\(\))?)(?![\w:])", r"...[...\1]", code)
code = code.replace("...(maybe() ?? [])", "...[...(maybe() ?? [])]")
open(dst, "w").write(code + marker + expect)
