#!/usr/bin/env python3
"""Summarize run_matrix.py results: counts per class, and the non-OK cases grouped by
(method, content), each with the representations/modes it hits and one sample of
Node's and pts's text. With --classify, each non-OK case is also put through the
by-design rules of classify.py.

Usage: summarize.py results.json... [--group sort] [--classify] [--samples N]
"""

import argparse
import json
from collections import Counter, defaultdict

import classify


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results", nargs="+")
    ap.add_argument("--group", default=None)
    ap.add_argument("--classify", action="store_true")
    ap.add_argument("--samples", type=int, default=1)
    ap.add_argument("--bucket", default=None, help="only show this bucket (with --classify)")
    a = ap.parse_args()
    by_name = {}
    for path in a.results:  # a later file's run of a program replaces an earlier one's
        for p in json.load(open(path))["programs"]:
            by_name[p["name"]] = p
    progs = [by_name[n] for n in sorted(by_name)]
    if a.group:
        progs = [p for p in progs if p["name"].split("-")[-1] == a.group]
    classes = Counter()
    prog_classes = Counter()
    buckets = Counter()
    groups = defaultdict(list)
    order = ["ICE", "CRASH", "TIMEOUT", "WRONG-EXIT", "WRONG", "MISSING", "PROGRAM-DIAG", "GENERR", "DIAG", "OK"]
    for p in progs:
        rep, mode, group = p["name"].rsplit("-", 2)
        worst = "OK"
        for label, c in p["cases"].items():
            classes[c["class"]] += 1
            if order.index(c["class"]) < order.index(worst):
                worst = c["class"]
            if c["class"] == "OK":
                continue
            content, method = label.split(".", 1)
            bucket, reason = classify.classify(rep, mode, group, content, method, c) if a.classify else ("", "")
            buckets[bucket] += 1
            if a.bucket and bucket != a.bucket:
                continue
            groups[(group, method, content, c["class"], bucket, reason)].append((rep, mode, c))
        prog_classes[worst] += 1
    print("programs:", len(progs), dict(prog_classes))
    print("cases:", sum(classes.values()), dict(classes))
    if a.classify:
        print("non-OK by bucket:", dict(buckets))
    for key in sorted(groups):
        group, method, content, cls, bucket, reason = key
        hits = groups[key]
        where = ", ".join(sorted({f"{r}/{m}" for r, m, _ in hits}))
        print(f"\n## {group} {content}.{method} {cls} [{bucket}] {reason}\n   in: {where}")
        shown = set()
        for r, m, c in hits:
            sig = (c.get("node"), c.get("pts"), c.get("diag"))
            if sig in shown or len(shown) >= a.samples:
                continue
            shown.add(sig)
            print(f"   e.g. {r}/{m}")
            if c.get("diag"):
                print("     diag:", c["diag"].strip().splitlines()[-1][:300])
            if c.get("node") is not None:
                print("     node:", (c.get("node") or "").replace("\n", " ⏎ ")[:400])
            if "pts" in c:
                print("     pts :", c["pts"].replace("\n", " ⏎ ")[:400], ("| " + c["pts_msg"][:160]) if c.get("pts_msg") else "")
            if c.get("pts_stderr"):
                print("     stderr:", c["pts_stderr"].strip().replace("\n", " ⏎ ")[:300])


if __name__ == "__main__":
    main()
