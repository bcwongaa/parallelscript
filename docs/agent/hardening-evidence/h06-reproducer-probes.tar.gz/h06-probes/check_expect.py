#!/usr/bin/env python3
"""Check that each test's `// expect:` block, parsed as pts/tests/README.md says, is
exactly Node's stdout for the test (as .mts) or for its oracle in --oracle-dir.

Usage: check_expect.py [--oracle-dir DIR] test.pts...
"""

import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

NODE = Path.home() / ".local" / "node" / "bin" / "node"
DIRECTIVE = re.compile(r"^// (expect|exit|stderr|error|no-diff|skip|threads):")


def expected(src):
    lines = src.splitlines()
    out = None
    for line in lines:
        if out is None:
            if line == "// expect:":
                out = []
            continue
        if not line.startswith("//") or DIRECTIVE.match(line):
            break
        out.append("" if line == "//" else line[3:] if line.startswith("// ") else line[2:])
    return None if out is None else "\n".join(out) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--oracle-dir")
    ap.add_argument("tests", nargs="+")
    a = ap.parse_args()
    bad = 0
    for t in map(Path, a.tests):
        want = expected(t.read_text())
        oracle = Path(a.oracle_dir) / f"{t.stem}.oracle.mts" if a.oracle_dir else None
        source = oracle if oracle and oracle.exists() else t
        with tempfile.TemporaryDirectory(prefix="h06-check-") as tmp:
            mts = Path(tmp) / (source.name if source.suffix == ".mts" else t.stem + ".mts")
            shutil.copy(source, mts)
            p = subprocess.run([str(NODE), "--no-warnings", "--experimental-transform-types", str(mts)], capture_output=True, text=True, cwd=tmp, timeout=60)
        ok = p.returncode == 0 and p.stdout == want
        bad += not ok
        print(f"{'ok ' if ok else 'BAD'} {t.name} (node exit {p.returncode}, from {source.name})")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
