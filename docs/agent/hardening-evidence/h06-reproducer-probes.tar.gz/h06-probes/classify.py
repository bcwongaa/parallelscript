"""By-design rules for H06's matrix: which non-OK cases are documented differences.

classify(rep, mode, group, content, method, case) -> (bucket, reason)

Buckets:
  D-085     arrays of numbers and booleans have no holes: their slots start as 0 or
            false (D-085, D-038), so any result that shows a hole as undefined or empty
            differs by design. Only for the plain `number[]`/`boolean[]` reps.
  REQUIRED  JS hands a hole to code that needs an element of a type without undefined
            (a typed callback parameter, a for…of binding, a typed iteration), and pts
            throws RangeError: D-038/D-085's "RangeError where an element is required".
            (Whether a typed callback or binding should get undefined there is H11's
            loose-name scope for bindings, C31/D-177.)
  UNREPR    JS's result turns holes into undefined elements of a new array whose type has
            no undefined (toSorted, toReversed, toSpliced, with, spread, Array.from,
            values()/entries() spread): a string[] or P[] can't hold undefined; pts keeps
            the holes (prints `<n empty items>` for `undefined`). A design question.
  D-133     a match array's group that took no part reaching typed code that needs a
            string (a typed callback parameter, for…of): D-133's checked string.
  D-086     Object.values of a match array: its checked copy into tsc's string[] meets
            the match's index/input/groups values.
  UNSUPPORTED  copyWithin: PTS1001 typed, `TypeError: x.copyWithin is not a function`
            through any.
  DEFECT    everything else; family() names the defect family of each.
"""

import gen

NO_HOLES = {name for name, r in gen.REPS.items() if not r["holes"]}
# Element types with holes but no undefined: str, strN, numN, cls, clsN, obj, sn.
NO_UNDEFINED = {name for name, r in gen.REPS.items() if r["holes"] and not r["U"]}
HOLES_AS_UNDEFINED_COPIES = {"toSorted", "toSortedc", "toReversed", "toSpliced", "with", "spread", "from", "valuesIt", "entriesIt"}
HOLES_TO_TYPED_CODE = {"find", "findIndex", "findLast", "findLastIndex", "forOf", "entriesIt"}


def has_hole(content):
    return "H" in content


def classify(rep, mode, group, content, method, c):
    cls = c["class"]
    if cls == "DIAG" and c.get("diag", "").startswith("PTS1001"):
        return "UNSUPPORTED", "PTS1001: " + c["diag"].split(": ", 1)[1]
    if method == "copyWithin" and mode == "any" and "is not a function" in (c.get("pts_msg") or ""):
        return "UNSUPPORTED", "copyWithin through any: TypeError not a function (typed: PTS1001)"
    if cls in ("ICE", "CRASH", "TIMEOUT", "MISSING", "GENERR", "PROGRAM-DIAG"):
        return "DEFECT" if cls != "GENERR" else "GENERR", ""
    if rep in NO_HOLES and has_hole(content):
        return "D-085", "number/boolean slots start as 0/false"
    pts = c.get("pts") or ""
    node = c.get("node") or ""
    msg = c.get("pts_msg") or ""
    if rep in ("match", "mcopy") and mode == "typed":
        if "threw TypeError" in pts and "took no part" in msg:
            return "D-133", "a group that took no part where a string is required: checked string"
        if rep == "mcopy" and "threw RangeError" in pts and group in ("callbacks", "search", "iter"):
            # A match copy's undefined group is a hole (D-133) read where a string is required:
            # D-085's RangeError (exec's own array gives D-133's TypeError instead).
            return "D-133", "a match copy's undefined group where a string is required: RangeError"
        if method == "values" and "Expected string[], got Array" in msg:
            return "D-086", "Object.values' checked copy into tsc's string[] meets index/input/groups"
    if rep in NO_UNDEFINED and has_hole(content):
        # Typed code (a callback parameter, a for…of binding, an entry pair) gets the hole as
        # undefined in JS; Node may then throw on its own (`v.id` of undefined) or not.
        typed_callback = method in HOLES_TO_TYPED_CODE and (mode == "typed" or method == "forOf")
        if typed_callback and "threw RangeError" in pts:
            return "REQUIRED", "JS passes the hole as undefined to typed code"
        if method in HOLES_AS_UNDEFINED_COPIES and "threw" not in pts:
            # Only the hole/undefined rendering may differ: pts shows the holes where Node shows undefined.
            if render_holes_as_undefined(pts) == normalize_node(node):
                return "UNREPR", "a new T[] would hold undefined"
    return "DEFECT", ""


def render_holes_as_undefined(text):
    """pts's text with each `<n empty item(s)>` written as n undefineds."""
    import re

    def expand(m):
        return ", ".join(["undefined"] * int(m.group(1)))

    return re.sub(r"<(\d+) empty items?>", expand, text)


def normalize_node(text):
    return render_holes_as_undefined(text)


FAMILIES = {
    "F1": "sort()/toSorted() without a comparator: undefined, null and holes sort first (all compared as \"\")",
    "F2": "sort(cmp)/toSorted(cmp): undefined passed to the comparator (only holes are skipped)",
    "F3": "toSorted keeps holes where JS reads them as undefined (element type can hold undefined)",
    "F1+F3": "toSorted() over holes: F1's order and F3's kept holes",
    "F2+F3": "toSorted(cmp) over holes: F2's comparator calls and F3's kept holes",
    "F5": "typed map/forEach/filter/some/every/reduce/reduceRight throw RangeError at holes (C74)",
    "F6": "through any, map/forEach/some/every/reduce/reduceRight call the callback for holes (C74)",
    "F7": "typed find/findIndex/findLast/findLastIndex throw RangeError at holes where T admits undefined",
    "F8": "typed includes(undefined) misses holes; through any indexOf/lastIndexOf(undefined) match holes",
    "F9": "Object.keys/Object.values/for…in list holes",
    "F10": "toReversed/toSpliced/with, typed spread/Array.from/values()/entries()/for…of keep holes or throw where JS reads undefined",
    "F11": "concat through any turns holes into undefined",
    "F12": "match arrays: spreads/values turn undefined groups into holes; filter through any drops them (C78)",
}


def family(rep, mode, group, content, method, c):
    """The defect family of a DEFECT case (see FAMILIES), or "F?" when none fits."""
    match = rep in ("match", "mcopy")
    if group == "sort":
        if method == "sort":
            return "F1"
        if method == "sortc":
            return "F2"
        if method == "toSorted":
            return "F1" if not has_hole(content) else "F1+F3"
        if method == "toSortedc":
            return "F2" if not has_hole(content) else "F2+F3"
    if group == "callbacks":
        if match and mode == "any" and method == "filter":
            return "F12"
        return "F5" if mode == "typed" else "F6"
    if group == "search":
        if method in ("find", "findIndex", "findLast", "findLastIndex") and mode == "typed":
            return "F7"
        if method == "includesU" and mode == "typed" or method in ("indexOfU", "lastIndexOfU") and mode == "any":
            return "F8"
    if group == "strings" and method in ("keys", "values"):
        return "F9"
    if group == "copy":
        if method == "concat" and mode == "any":
            return "F11"
        if method in ("toReversed", "toSpliced", "with"):
            return "F10"
    if group == "iter":
        if method == "forIn":
            return "F9"
        if match and method in ("spread", "valuesIt"):
            return "F12"
        if method in ("forOf", "entriesIt", "spread", "from", "valuesIt") and mode == "typed":
            return "F10"
    return "F?"
