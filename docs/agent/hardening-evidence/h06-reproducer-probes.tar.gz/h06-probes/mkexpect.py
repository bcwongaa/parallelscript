#!/usr/bin/env python3
"""Append Node's stdout to a run test as its `// expect:` block (pts/tests/README.md).

The test (without an expect block) runs under Node as a strict-ESM `.mts` copy with
`--no-warnings --experimental-transform-types`, as the differential harness runs it;
with --oracle, that file (an equivalent plain-TypeScript program, for tests that use
pts: features) runs instead. Node must exit 0. Lines that would read as directives
are refused (use a .out file then).

Usage: mkexpect.py test.pts [--oracle oracle.mts] [--write]
"""

import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

NODE = Path.home() / ".local" / "node" / "bin" / "node"
DIRECTIVE = re.compile(r"^(expect|exit|stderr|error|no-diff|skip|threads):")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("test")
    ap.add_argument("--oracle")
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    test = Path(a.test)
    src = test.read_text()
    if re.search(r"^// expect:$", src, re.M):
        sys.exit(f"{test} already has an expect block")
    with tempfile.TemporaryDirectory(prefix="h06-mkexpect-") as tmp:
        mts = Path(tmp) / (Path(a.oracle).name if a.oracle else test.stem + ".mts")
        shutil.copy(a.oracle or test, mts)
        p = subprocess.run([str(NODE), "--no-warnings", "--experimental-transform-types", str(mts)], capture_output=True, text=True, cwd=tmp, timeout=60)
    if p.returncode != 0:
        sys.exit(f"node exited {p.returncode}: {p.stderr}")
    lines = p.stdout.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    block = ["// expect:"]
    for line in lines:
        if DIRECTIVE.match(line):
            sys.exit(f"output line looks like a directive: {line!r}")
        block.append("//" if line == "" else "// " + line)
    text = src.rstrip("\n") + "\n\n" + "\n".join(block) + "\n"
    if a.write:
        test.write_text(text)
    print("\n".join(block))


if __name__ == "__main__":
    main()
