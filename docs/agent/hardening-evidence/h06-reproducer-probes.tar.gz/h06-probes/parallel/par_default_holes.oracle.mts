// Sequential Node oracle for par_default_holes.pts: `.par.sort()` is Array's `sort()`.
function show(label: string, f: () => unknown): void {
    try {
        console.log(label, f());
    } catch (e) {
        console.log(label, "threw", (e as Error).name);
    }
}
show("small union", () => {
    const a = new Array<string | null | undefined>(6);
    a[0] = "nz";
    a[1] = null;
    a[3] = undefined;
    a[4] = "a";
    return a.sort();
});
show("small strings", () => {
    const a = new Array<string>(4);
    a[1] = "b";
    a[3] = "a";
    return a.sort();
});
show("small any", () => {
    const a: any[] = new Array(5);
    a[0] = 3;
    a[1] = undefined;
    a[2] = null;
    a[4] = "b";
    return a.sort();
});
show("big union", () => {
    const a = new Array<string | null | undefined>(6000);
    for (let i = 0; i < 6000; i++) {
        const r = i % 10;
        if (r === 0) {
            a[i] = undefined;
        } else if (r === 1) {
            a[i] = null;
        } else if (r !== 5) {
            a[i] = "n" + ((i * 7919) % 6000);
        }
    }
    a.sort();
    return [a.slice(0, 2), a.slice(4198, 4202), a.slice(4798, 4802), a.slice(5398, 5402), a.slice(5998)];
});
show("big strings", () => {
    const a = new Array<string>(6000);
    for (let i = 0; i < 6000; i++) {
        if (i % 10 !== 5) {
            a[i] = "s" + ((i * 7919) % 6000);
        }
    }
    a.sort();
    return [a.slice(0, 2), a.slice(5398, 5402), a.slice(5998)];
});
