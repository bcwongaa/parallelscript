// Sequential Node oracle for par_cmp_string_holes.pts: `.par.sort(f)` is Array's `sort(f)`.
function make(): string[] {
    const values = new Array<string>(6000);
    for (let i = 0; i < 6000; i++) {
        if (i % 10 !== 5) {
            values[i] = "s" + ((i * 7919) % 6000);
        }
    }
    return values;
}
const values = make();
try {
    values.sort((a, b) => (a < b ? -1 : b < a ? 1 : 0));
    console.log("first", values.slice(0, 3));
    console.log("defined end", values.slice(5398, 5402));
    console.log("last", values.slice(5998));
} catch (e) {
    console.log("threw", (e as Error).name);
}
const small = new Array<string>(5);
small[0] = "b";
small[2] = "a";
console.log("small", small.sort((a, b) => (a < b ? -1 : b < a ? 1 : 0)));
