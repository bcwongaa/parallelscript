// Sequential Node oracle for pts/tests/run/parallel_sort_undefined.pts: `.par.sort(f)`
// is Array's `sort(f)` (D-124) and the AtomicInt is a plain counter.
let undefinedArguments = 0;
function byNumber(a: number | undefined, b: number | undefined): number {
    if (a === undefined || b === undefined) {
        undefinedArguments += 1;
        return 0;
    }
    return a - b;
}
function sawUndefined(): boolean {
    const saw = undefinedArguments > 0;
    undefinedArguments = 0;
    return saw;
}

const big = new Array<number | undefined>(6000);
for (let i = 0; i < 6000; i++) {
    if (i % 10 === 0) {
        big[i] = undefined;
    } else if (i % 10 !== 5) {
        big[i] = (i * 7919) % 6000;
    }
}
big.sort(byNumber);
let ascending = true;
for (let i = 1; i < 4800; i++) {
    const before: number | undefined = big[i - 1];
    const here: number | undefined = big[i];
    if (before === undefined || here === undefined || before > here) {
        ascending = false;
    }
}
console.log("big", big.slice(0, 3), ascending, big.slice(4798, 4802), big.slice(5398, 5402), big.slice(5998));
console.log("big comparator saw undefined:", sawUndefined());

class Item {
    constructor(public key: number, public index: number) {}
}
const items: (Item | undefined)[] = [];
for (let i = 0; i < 6000; i++) {
    items.push(i % 8 === 3 ? undefined : new Item((i * 7919) % 50, i));
}
items.sort((a, b) => {
    if (a === undefined || b === undefined) {
        undefinedArguments += 1;
        return a === undefined ? (b === undefined ? 0 : -1) : 1;
    }
    return a.key - b.key;
});
let stable = true;
for (let i = 1; i < 5250; i++) {
    const p = items[i - 1];
    const q = items[i];
    if (p === undefined || q === undefined || p.key > q.key || (p.key === q.key && p.index > q.index)) {
        stable = false;
    }
}
console.log("items", stable, items[0], items.slice(5249, 5251));
console.log("items comparator saw undefined:", sawUndefined());

const small = new Array<number | undefined>(5);
small[0] = 3;
small[1] = undefined;
small[3] = 1;
console.log("small", small.sort(byNumber), sawUndefined());
