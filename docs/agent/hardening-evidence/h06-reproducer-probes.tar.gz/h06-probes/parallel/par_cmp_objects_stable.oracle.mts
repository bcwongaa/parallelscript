// Sequential Node oracle for par_cmp_objects_stable.pts: `.par.sort(f)` is Array's `sort(f)`.
class Item {
    constructor(public key: number, public index: number) {}
}
const values: (Item | undefined)[] = [];
for (let i = 0; i < 6000; i++) {
    values.push(i % 8 === 3 ? undefined : new Item((i * 7919) % 50, i));
}
let undefinedArguments = 0;
values.sort((a, b) => {
    if (a === undefined || b === undefined) {
        undefinedArguments += 1;
        return a === undefined ? (b === undefined ? 0 : -1) : 1;
    }
    return a.key - b.key;
});
let stable = true;
for (let i = 1; i < 5250; i++) {
    const p = values[i - 1];
    const q = values[i];
    if (p === undefined || q === undefined || p.key > q.key || (p.key === q.key && p.index > q.index)) {
        stable = false;
    }
}
console.log("stable:", stable, "first", values[0], "tail", values.slice(5249, 5251));
console.log("comparator saw undefined:", undefinedArguments > 0);
