// Sequential Node oracle for par_cmp_undefined_holes.pts: `.par.sort(f)` is Array's
// `sort(f)` (pts:parallel documents it as Array's sort); the AtomicInt is a counter.
function make(): (number | undefined)[] {
    const values = new Array<number | undefined>(6000);
    for (let i = 0; i < 6000; i++) {
        if (i % 10 === 0) {
            values[i] = undefined;
        } else if (i % 10 !== 5) {
            values[i] = (i * 7919) % 6000;
        }
    }
    return values;
}
const values = make();
let undefinedArguments = 0;
values.sort((a, b) => {
    if (a === undefined || b === undefined) {
        undefinedArguments += 1;
        return 0;
    }
    return a - b;
});
let ascending = true;
for (let i = 1; i < 4800; i++) {
    const before: number | undefined = values[i - 1];
    const here: number | undefined = values[i];
    if (before === undefined || here === undefined || before > here) {
        ascending = false;
    }
}
console.log("first", values.slice(0, 3), "ascending:", ascending);
console.log("defined end", values.slice(4798, 4802));
console.log("undefined end", values.slice(5398, 5402));
console.log("last", values.slice(5998));
console.log("comparator saw undefined:", undefinedArguments > 0);
