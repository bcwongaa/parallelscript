// Sequential Node oracle for par_small_holes.pts: `.par.sort(f)` is Array's `sort(f)`.
function show(label: string, f: () => unknown): void {
    try {
        console.log(label, f());
    } catch (e) {
        console.log(label, "threw", (e as Error).name);
    }
}
show("maybe numbers", () => {
    const a = new Array<number | undefined>(5);
    a[0] = 3;
    a[1] = undefined;
    a[3] = 1;
    return a.sort((p, q) => (p ?? 0) - (q ?? 0));
});
show("strings", () => {
    const a = new Array<string>(4);
    a[0] = "b";
    a[2] = "a";
    return a.sort((p, q) => (p < q ? -1 : q < p ? 1 : 0));
});
show("objects", () => {
    const a = new Array<{ n: number }>(3);
    a[1] = { n: 2 };
    a[2] = { n: 1 };
    return a.sort((p, q) => p.n - q.n);
});
