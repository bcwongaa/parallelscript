#!/usr/bin/env python3
"""Run H06's generated matrix (gen.py) under ParallelScript and Node, case by case.

Every program runs under Node as `.mts` (strict ESM, `--no-warnings
--experimental-transform-types`); Node must exit 0. Under pts each program is built
and run (4 GiB address space, 60 s timeout). Each case prints one labelled line
(plus continuation lines when console.log wraps, and a `#msg` line after a throw,
which is kept but not compared). Case classes:

  OK     same text as Node
  WRONG  different text (or an uncaught throw that ends the program: WRONG-EXIT)
  CRASH  the program died by a signal while running this case
  DIAG   pts reports a compile error inside this case (GENERR when it's a TSxxxx
         error: the generator wrote invalid TypeScript)
  ICE    PTS9001 / exit code 3 / a compiler panic, isolated by bisection
  TIMEOUT

A case that fails to compile is removed and the program rebuilt; after a crash or
an uncaught throw the remaining cases run again without the culprit, so one failure
can't hide the others.

Usage: run_matrix.py --dir DIR --out results.json [--jobs 2] [--only name,...]
"""

import argparse
import concurrent.futures
import json
import os
import re
import resource
import shutil
import subprocess
import sys
from pathlib import Path

WT = Path(__file__).resolve().parent.parent
PTS = WT / "pts-bin" / "pts"
NODE = Path.home() / ".local" / "node" / "bin" / "node"
CAP = 4 << 30
DIAG_RE = re.compile(r"^(.*?\.pts):(\d+):(\d+) - error (\w+): (.*)$")


def env(extra=None):
    e = dict(os.environ)
    e["PTS_HOME"] = str(WT)
    e["PATH"] = f"{Path.home()}/.local/node/bin:{Path.home()}/.local/go/bin:" + e.get("PATH", "")
    e["TZ"] = "America/New_York"
    if extra:
        e.update(extra)
    return e


def cap():
    resource.setrlimit(resource.RLIMIT_AS, (CAP, CAP))


def run(cmd, timeout, cwd, capped=False, extra=None):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=env(extra), capture_output=True, timeout=timeout,
                           preexec_fn=cap if capped else None)
        return p.returncode, p.stdout.decode("utf8", "replace"), p.stderr.decode("utf8", "replace")
    except subprocess.TimeoutExpired as t:
        out = t.stdout.decode("utf8", "replace") if t.stdout else ""
        return "timeout", out, ""


def split_output(text, labels):
    """Map each label to (compared text, msg) from a program's stdout."""
    known = set(labels)
    result = {}
    current = None
    for line in text.splitlines():
        head = line.split(" ", 1)[0]
        if head in known and head not in result:
            current = head
            result[current] = {"text": [line], "msg": []}
        elif line.startswith("#msg ") and current:
            result[current]["msg"].append(line[5:])
        elif current:
            result[current]["text"].append(line)
    return {k: {"text": "\n".join(v["text"]), "msg": "\n".join(v["msg"])} for k, v in result.items()}


def subset_text(lines, cases, keep, calls_at):
    """The program with only the cases in keep (a set of labels)."""
    first = cases[0]["start"] if cases else calls_at
    out = lines[: first - 1]
    for c in cases:
        if c["label"] in keep:
            out += lines[c["start"] - 1: c["end"]]
    out.append("")
    for c in cases:
        if c["label"] in keep:
            out.append(f"{c['fn']}();")
    return "\n".join(out) + "\n"


class Program:
    def __init__(self, entry, src_dir, scratch):
        self.entry = entry
        self.name = entry["name"]
        self.src = src_dir / f"{self.name}.pts"
        self.lines = self.src.read_text().splitlines()
        self.cases = entry["cases"]
        self.work = scratch / self.name
        self.builds = 0
        self.log = []

    def case_at(self, line, text):
        """The case whose span holds line of the subset program text."""
        # Recompute spans in the subset text by searching for each function's header.
        tl = text.splitlines()
        spans = {}
        for i, l in enumerate(tl, 1):
            m = re.match(r"^function (case_\w+)\(\): void \{$", l)
            if m:
                spans[m.group(1)] = i
        best = None
        for c in self.cases:
            s = spans.get(c["fn"])
            if s is not None and s <= line and (best is None or s > spans[best["fn"]]):
                best = c
        if best is None:
            return None
        length = best["end"] - best["start"]
        return best if line <= spans[best["fn"]] + length else None

    def build(self, keep, tag):
        text = subset_text(self.lines, self.cases, keep, self.entry["calls_at"])
        path = self.work / f"{self.name}-{tag}.pts"
        path.write_text(text)
        binary = self.work / f"{self.name}-{tag}-native"
        self.builds += 1
        code, out, err = run([str(PTS), "build", str(path), "-o", str(binary)], 600, self.work)
        return code, out + err, text, binary

    def go(self):
        if self.work.exists():
            shutil.rmtree(self.work)
        self.work.mkdir(parents=True)
        labels = [c["label"] for c in self.cases]
        mts = self.work / f"{self.name}.mts"
        shutil.copy(self.src, mts)
        ncode, nout, nerr = run([str(NODE), "--no-warnings", "--experimental-transform-types", str(mts)], 60, self.work)
        res = {"name": self.name, "node_exit": ncode, "node_stderr": nerr[-2000:], "cases": {}}
        node = split_output(nout, labels)
        if ncode != 0:
            res["class"] = "NODE-ERR"
            return res
        results = res["cases"]
        pending = set(labels)
        tag = 0
        while pending:
            tag += 1
            code, text_err, text, binary = self.build(pending, f"b{tag}")
            if code != 0:
                if code == 3 or "PTS9001" in text_err or "panic:" in text_err:
                    self.isolate_ice(pending, results, tag)
                    pending = {l for l in pending if l not in results}
                    continue
                hit = set()
                for line in text_err.splitlines():
                    m = DIAG_RE.match(line.strip())
                    if not m:
                        continue
                    c = self.case_at(int(m.group(2)), text)
                    if c is None:
                        res.setdefault("program_diags", []).append(line.strip())
                        continue
                    if c["label"] not in hit:
                        hit.add(c["label"])
                        cls = "GENERR" if m.group(4).startswith("TS") else "DIAG"
                        results[c["label"]] = {"class": cls, "diag": f"{m.group(4)}: {m.group(5)}", "node": node.get(c["label"], {}).get("text")}
                if not hit:
                    res["class"] = "PROGRAM-DIAG"
                    res["build_error"] = text_err[-3000:]
                    for l in pending:
                        results[l] = {"class": "PROGRAM-DIAG", "diag": text_err[-500:]}
                    break
                pending -= hit
                continue
            rcode, rout, rerr = run([str(binary)], 60, self.work, capped=True)
            pts = split_output(rout, labels)
            order = [c["label"] for c in self.cases if c["label"] in pending]
            missing = []
            for l in order:
                if l in pts:
                    same = pts[l]["text"] == node[l]["text"]
                    results[l] = {"class": "OK" if same else "WRONG", "node": node[l]["text"], "pts": pts[l]["text"],
                                  "node_msg": node[l]["msg"], "pts_msg": pts[l]["msg"]}
                else:
                    missing.append(l)
            if not missing:
                break
            culprit = missing[0]
            if rcode == "timeout":
                cls = "TIMEOUT"
            elif isinstance(rcode, int) and rcode < 0:
                cls = "CRASH"
            elif rcode != 0:
                cls = "WRONG-EXIT"
            else:
                cls = "MISSING"
            results[culprit] = {"class": cls, "exit": rcode, "node": node[culprit]["text"], "pts_stderr": rerr[-1500:]}
            pending = set(missing[1:])
        res["builds"] = self.builds
        return res

    def isolate_ice(self, pending, results, tag):
        """Bisect pending for the cases that alone make the compiler fail internally."""
        order = [c["label"] for c in self.cases if c["label"] in pending]
        stack = [order]
        n = 0
        while stack:
            group = stack.pop()
            n += 1
            code, text_err, _, _ = self.build(set(group), f"ice{tag}-{n}")
            ice = code == 3 or "PTS9001" in text_err or "panic:" in text_err
            if not ice:
                continue  # this half builds (or has ordinary diagnostics); the main loop handles it
            if len(group) == 1:
                results[group[0]] = {"class": "ICE", "diag": text_err[-1500:]}
                continue
            mid = len(group) // 2
            stack += [group[:mid], group[mid:]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--scratch", default="/tmp/h06/repro/matrix-work")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--only", default=None)
    a = ap.parse_args()
    src = Path(a.dir)
    manifest = json.loads((src / "manifest.json").read_text())
    scratch = Path(a.scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    progs = manifest["programs"]
    if a.only:
        keep = set(a.only.split(","))
        progs = [p for p in progs if p["name"] in keep]
    out = {"seed": manifest["seed"], "pts": str(PTS), "programs": []}
    with concurrent.futures.ThreadPoolExecutor(a.jobs) as pool:
        futs = {pool.submit(Program(p, src, scratch).go): p["name"] for p in progs}
        for f in concurrent.futures.as_completed(futs):
            r = f.result()
            counts = {}
            for c in r["cases"].values():
                counts[c["class"]] = counts.get(c["class"], 0) + 1
            print(f"{r['name']}: {counts} builds={r.get('builds')}", flush=True)
            out["programs"].append(r)
    out["programs"].sort(key=lambda r: r["name"])
    Path(a.out).write_text(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
