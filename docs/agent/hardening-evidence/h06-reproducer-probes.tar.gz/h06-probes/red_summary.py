#!/usr/bin/env python3
"""Summarize a `go test -json` run of H06's RED tests: each subtest's result and the
first lines of its failure output.

Usage: red_summary.py red.jsonl [--lines N]
"""

import argparse
import json
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl")
    ap.add_argument("--lines", type=int, default=12)
    a = ap.parse_args()
    results = {}
    output = defaultdict(list)
    for line in open(a.jsonl):
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        test = e.get("Test")
        if not test:
            continue
        if e["Action"] in ("pass", "fail", "skip"):
            results[test] = (e["Action"], e.get("Elapsed"))
        elif e["Action"] == "output":
            output[test].append(e["Output"].rstrip("\n"))
    for test in sorted(results):
        if "/" not in test:
            continue
        action, elapsed = results[test]
        print(f"{action.upper():5} {test} ({elapsed}s)")
        if action == "fail":
            lines = [l for l in output[test] if l.strip() and not l.startswith("=== ") and "--- FAIL" not in l]
            for l in lines[: a.lines]:
                print("      " + l[:220])
    tops = {t: r for t, r in results.items() if "/" not in t}
    print("top-level:", {t: r[0] for t, r in tops.items()})
    counts = defaultdict(int)
    for t, r in results.items():
        if "/" in t:
            counts[r[0]] += 1
    print("subtests:", dict(counts))


if __name__ == "__main__":
    main()
