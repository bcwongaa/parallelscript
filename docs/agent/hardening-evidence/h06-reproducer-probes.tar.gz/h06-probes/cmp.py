#!/usr/bin/env python3
"""Compare PTS programs with Node, one by one, and print both outputs.

Each program is copied to <scratch>/<name>.mts and run with
`node --no-warnings --experimental-transform-types` (strict ESM, as the test
harness does), built with `pts build` and run with a 4 GiB address-space cap
and a 60 s timeout. A program may name a Node oracle with a first-lines comment
`// oracle: <file>.mts` (relative to the program), used for pts:-only programs.
`// threads: 1 2 4` runs the binary once per PTS_THREADS value.

Classes: OK (same stdout and exit code), DIAG (pts build failed with a
diagnostic), ICE (PTS9001 or a compiler panic), WRONG (different stdout or exit
code), CRASH (binary killed by a signal), TIMEOUT, NODE-ERR (Node didn't exit 0).

Usage: cmp.py [--quiet] [--scratch DIR] program.pts...
"""

import argparse
import difflib
import os
import re
import resource
import shutil
import subprocess
import sys
from pathlib import Path

WT = Path(__file__).resolve().parent.parent
PTS = WT / "pts-bin" / "pts"
NODE = Path.home() / ".local" / "node" / "bin" / "node"
BUILD_TIMEOUT_S = 600
RUN_TIMEOUT_S = 60
CAP = 4 << 30


def env():
    e = dict(os.environ)
    e["PTS_HOME"] = str(WT)
    e["PATH"] = f"{Path.home()}/.local/node/bin:{Path.home()}/.local/go/bin:" + e.get("PATH", "")
    e["TZ"] = "America/New_York"
    return e


def cap():
    resource.setrlimit(resource.RLIMIT_AS, (CAP, CAP))


def run(cmd, timeout, cwd=None, extra_env=None, capped=False):
    e = env()
    if extra_env:
        e.update(extra_env)
    try:
        p = subprocess.run(cmd, cwd=cwd, env=e, capture_output=True, text=True, timeout=timeout,
                           preexec_fn=cap if capped else None, errors="replace")
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as t:
        return "timeout", (t.stdout or b"").decode("utf8", "replace") if isinstance(t.stdout, bytes) else (t.stdout or ""), ""


def directive(src, name):
    m = re.search(rf"^// {name}: (.*)$", src, re.M)
    return m.group(1).strip() if m else None


def compare(path: Path, scratch: Path, oracle_dir=None):
    src = path.read_text()
    stem = path.stem
    work = scratch / stem
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    oracle = directive(src, "oracle")
    if oracle_dir and (Path(oracle_dir) / f"{stem}.oracle.mts").exists():
        mts = work / f"{stem}.oracle.mts"
        shutil.copy(Path(oracle_dir) / f"{stem}.oracle.mts", mts)
    elif oracle:
        mts = work / Path(oracle).name
        shutil.copy(path.parent / oracle, mts)
    else:
        mts = work / f"{stem}.mts"
        shutil.copy(path, mts)
    nexit, nout, nerr = run([str(NODE), "--no-warnings", "--experimental-transform-types", str(mts)], RUN_TIMEOUT_S, cwd=work)
    binary = work / f"{stem}-native"
    bexit, bout, berr = run([str(PTS), "build", str(path), "-o", str(binary)], BUILD_TIMEOUT_S, cwd=work)
    result = {"name": path.name, "node_exit": nexit, "node_out": nout, "node_err": nerr,
              "build_exit": bexit, "build_err": berr + bout, "runs": []}
    if bexit != 0:
        text = berr + bout
        if "PTS9001" in text or "panic:" in text or bexit == 3:
            result["class"] = "ICE"
        else:
            result["class"] = "DIAG"
        return result
    threads = directive(src, "threads")
    counts = threads.split() if threads else [None]
    classes = []
    for t in counts:
        extra = {"PTS_THREADS": t} if t else None
        rexit, rout, rerr = run([str(binary)], RUN_TIMEOUT_S, cwd=work, extra_env=extra, capped=True)
        result["runs"].append({"threads": t, "exit": rexit, "out": rout, "err": rerr})
        if rexit == "timeout":
            classes.append("TIMEOUT")
        elif isinstance(rexit, int) and rexit < 0:
            classes.append("CRASH")
        elif rexit == nexit and rout == nout:
            classes.append("OK")
        else:
            classes.append("WRONG")
    if nexit != 0:
        result["class"] = "NODE-ERR"
    else:
        order = ["CRASH", "TIMEOUT", "WRONG", "OK"]
        result["class"] = min(classes, key=order.index)
    return result


def report(r, quiet):
    print(f"=== {r['name']}: {r['class']} (node exit {r['node_exit']}, build exit {r['build_exit']})")
    if r["class"] in ("DIAG", "ICE"):
        print("  build:", "\n  ".join(r["build_err"].strip().splitlines()[:12]))
    if quiet and r["class"] == "OK":
        return
    if r["node_err"].strip():
        print("  node stderr:", r["node_err"].strip().splitlines()[-3:])
    for run_ in r["runs"]:
        print(f"  -- pts threads={run_['threads']} exit={run_['exit']}")
        if run_["out"] == r["node_out"]:
            if not quiet:
                print("     (stdout identical to node)")
                for line in r["node_out"].splitlines():
                    print("     |", line)
        else:
            for line in difflib.unified_diff(r["node_out"].splitlines(), run_["out"].splitlines(), "node", "pts", lineterm="", n=0):
                print("    ", line)
        if run_["err"].strip():
            print("     stderr:", " / ".join(run_["err"].strip().splitlines()[:4]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--scratch", default="/tmp/h06/repro/cmp")
    ap.add_argument("--oracle-dir", default=None, help="use <dir>/<stem>.oracle.mts as Node's program when it exists")
    ap.add_argument("programs", nargs="+")
    a = ap.parse_args()
    scratch = Path(a.scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    worst = 0
    for p in a.programs:
        r = compare(Path(p).resolve(), scratch, a.oracle_dir)
        report(r, a.quiet)
        if r["class"] != "OK":
            worst = 1
    sys.exit(worst)


if __name__ == "__main__":
    main()
