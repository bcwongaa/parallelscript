#!/usr/bin/env python3
"""Ad-hoc queries over matrix results (later files win per program).

Usage: query.py results.json... [--holes yes|no|any] [--group G] [--not-group G]
                [--bucket B] [--method M] [--content C] [--rep R] [--mode M]
Prints the non-OK cases grouped by (group, method, content, bucket) with where they
hit and one sample.
"""

import argparse
import json
from collections import defaultdict

import classify


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results", nargs="+")
    ap.add_argument("--holes", default="any")
    ap.add_argument("--group")
    ap.add_argument("--not-group")
    ap.add_argument("--bucket")
    ap.add_argument("--method")
    ap.add_argument("--content")
    ap.add_argument("--rep")
    ap.add_argument("--mode")
    ap.add_argument("--all", action="store_true", help="every sample, not one per group")
    a = ap.parse_args()
    by = {}
    for f in a.results:
        for p in json.load(open(f))["programs"]:
            by[p["name"]] = p
    g = defaultdict(list)
    for n, p in sorted(by.items()):
        rep, mode, group = n.rsplit("-", 2)
        if a.group and group != a.group or a.not_group and group == a.not_group:
            continue
        if a.rep and rep != a.rep or a.mode and mode != a.mode:
            continue
        for label, c in p["cases"].items():
            content, method = label.split(".", 1)
            if c["class"] == "OK":
                continue
            if a.holes == "yes" and "H" not in content or a.holes == "no" and "H" in content:
                continue
            if a.method and method != a.method or a.content and content != a.content:
                continue
            bucket, reason = classify.classify(rep, mode, group, content, method, c)
            if a.bucket and bucket != a.bucket:
                continue
            g[(group, method, content, bucket, reason)].append((rep, mode, c))
    for key, hits in sorted(g.items()):
        print(key, "|", ", ".join(sorted({f"{r}/{m}" for r, m, _ in hits})))
        for r, m, c in hits if a.all else hits[:1]:
            print(f"   [{r}/{m}] node:", (c.get("node") or "")[:260].replace("\n", " "))
            print(f"   [{r}/{m}] pts :", (c.get("pts") or c.get("diag") or "")[:260].replace("\n", " "), "|", (c.get("pts_msg") or "")[:140])


if __name__ == "__main__":
    main()
