#!/usr/bin/env python3
"""Generate H06's differential matrix: small TypeScript programs over arrays holding
undefined, null and holes, for every element representation, typed and through `any`.

Deterministic: the matrix is a fixed product (no randomness is needed to stay small),
and the seed only orders the values each representation uses, so a different seed
gives a different, equally deterministic, matrix. Each program is one
(representation, mode, group); each case is one (content, method) in a function of
its own that prints exactly one line starting with its label (and, if it throws, a
`#msg` line the runner ignores), so a throw in one case can't hide the others.

Usage: gen.py --out DIR [--seed N]
Writes DIR/<rep>-<mode>-<group>.pts and DIR/manifest.json (per program: cases with
their labels, contents, methods and line spans).
"""

import argparse
import json
import random
from pathlib import Path

# ------------------------------------------------------------ element representations
# T: the element type. vals: V0..V4 (V4 ties V1 under the comparator's key, so
# stability shows for objects). U/N: whether undefined/null are in T. key: the
# comparator's numeric key of a value v of type T. lab: a string naming v.
STR_KEY = "v.length * 1000 + v.charCodeAt(0)"


def opt(key, u, n):
    k = key
    if n:
        k = f"v === null ? -1 : {k}"
    if u:
        k = f"v === undefined ? 1e9 : {k}"
    return k


def labopt(lab, u, n):
    k = lab
    if n:
        k = f'v === null ? "null" : {k}'
    if u:
        k = f'v === undefined ? "undefined" : {k}'
    return k


STRS = ['"nz"', '"a"', '"nuk"', '"z"', '"a"']
NUMS = ["20", "3", "100", "1", "3"]
BOOLS = ["true", "false", "true", "false", "false"]
CLS = ['new P(3, "a")', 'new P(1, "b")', 'new P(2, "c")', 'new P(10, "d")', 'new P(1, "e")']
OBJ = ['{ n: 3, id: "a" }', '{ n: 1, id: "b" }', '{ n: 2, id: "c" }', '{ n: 10, id: "d" }', '{ n: 1, id: "e" }']
MIXED = ["3", '"b"', 'new P(2, "c")', '"a"', "3"]
SN = ["3", '"b"', "10", '"a"', "3"]

REPS = {}


def rep(name, T, vals, u, n, key, lab="String(v)", holes=True, kind=None):
    REPS[name] = dict(T=T, vals=vals, U=u, N=n, key=opt(key, u, n) if key else None, lab=labopt(lab, u, n), holes=holes, kind=kind or name.rstrip("UN"))


rep("str", "string", STRS, False, False, STR_KEY)
rep("strU", "string | undefined", STRS, True, False, STR_KEY)
rep("strN", "string | null", STRS, False, True, STR_KEY)
rep("strNU", "string | null | undefined", STRS, True, True, STR_KEY)
rep("num", "number", NUMS, False, False, "v", holes=False)
rep("numU", "number | undefined", NUMS, True, False, "v")
rep("numN", "number | null", NUMS, False, True, "v")
rep("bool", "boolean", BOOLS, False, False, "v ? 1 : 0", holes=False)
rep("boolU", "boolean | undefined", BOOLS, True, False, "v ? 1 : 0")
rep("cls", "P", CLS, False, False, "v.x")
rep("clsU", "P | undefined", CLS, True, False, "v.x")
rep("clsN", "P | null", CLS, False, True, "v.x")
rep("obj", "Rec", OBJ, False, False, "v.n", lab="v.id")
rep("objU", "Rec | undefined", OBJ, True, False, "v.n", lab="v.id")
rep("any", "any", MIXED, True, True, None, kind="any")
rep("unk", "unknown", MIXED, True, True, None, kind="unk")
rep("sn", "string | number", SN, False, False, f'typeof v === "number" ? v : {STR_KEY}')
rep("snU", "string | number | undefined", SN, True, False, f'typeof v === "number" ? v : {STR_KEY}')
# Match arrays (D-133): string[]s whose groups that took no part are holes reading as
# undefined; `match` is exec's result, `mcopy` its slice() (pts_type_match_copy). They
# are made by a regex, so their contents are MATCH_CONTENTS, not token lists.
rep("match", "string", STRS, False, False, STR_KEY, holes=False, kind="match")
rep("mcopy", "string", STRS, False, False, STR_KEY, holes=False, kind="match")
MATCH_CONTENTS = {
    "md": ("/(n)(z)/", '"nz"'),  # [ 'nz', 'n', 'z' ]
    "mU": ("/(b)|(a)/", '"a"'),  # [ 'a', undefined, 'a' ]
    "mUU": ("/(x)?(y)?/", '""'),  # [ '', undefined, undefined ]
    "mmix": ("/(nz)?(q)?(a)?(nuk)?/", '"nza"'),  # [ 'nza', 'nz', undefined, 'a', undefined ]
}

# ------------------------------------------------------------ contents
# Tokens: V0..V4 (values), U (undefined), N (null), H (a hole).
CONTENTS = {
    "e": [],
    "o": ["V1"],
    "oU": ["U"],
    "oH": ["H"],
    "d": ["V0", "V1", "V2", "V3", "V4"],
    "dU": ["V2", "U", "V0", "U", "V1"],
    "dN": ["V2", "N", "V0", "V1"],
    "nN": ["N", "V1", "N"],
    "dH": ["V2", "H", "V0", "H", "V1"],
    "uH": ["H", "V1", "U", "V0", "H", "U"],
    "nuH": ["N", "H", "V1", "U", "V0", "N"],
    "aU": ["U", "U"],
    "aH": ["H", "H", "H"],
}


def contents_for(r):
    if r["kind"] == "match":
        return list(MATCH_CONTENTS)
    out = []
    for name, toks in CONTENTS.items():
        if "U" in toks and not r["U"]:
            continue
        if "N" in toks and not r["N"]:
            continue
        if "H" in toks and not r["holes"] and name not in ("oH", "dH"):
            continue  # arrays of numbers and booleans have no holes (D-085): two contents show it
        out.append(name)
    return out


# ------------------------------------------------------------ methods
# A method is (name, body(ctx)) where ctx gives: A (the receiver expression: `a` typed
# or `x` through any), L (the label literal), T, typed (bool), r (the rep), and helper
# names. Bodies print exactly one line starting with L.

def cmp_expr(c):
    return "cmp" if c["typed"] else "cmpAny"


def lab_fn(c):
    return "lab" if c["typed"] else "labAny"


def cb(c, params):
    """A callback's parameter list: typed callbacks take tsc's contextual types."""
    if c["typed"]:
        return f"({', '.join(params)})"
    return "(" + ", ".join(f"{p}: any" if p != "i" else "i: number" for p in params) + ")"


def m_sort(c):
    return f'const r = {c["A"]}.sort(); console.log({c["L"]}, r, r === a);'


def m_sortc(c):
    return f'reset(); const r = {c["A"]}.sort({cmp_expr(c)}); console.log({c["L"]}, r, r === a, "u=" + ucalls, args());'


def m_tosorted(c):
    return f'const r = {c["A"]}.toSorted(); console.log({c["L"]}, r, a);'


def m_tosortedc(c):
    return f'reset(); const r = {c["A"]}.toSorted({cmp_expr(c)}); console.log({c["L"]}, r, a, "u=" + ucalls, args());'


def visit(method, ret):
    def body(c):
        return (f'const vis: number[] = []; const r = {c["A"]}.{method}({cb(c, ["v", "i"])} => {{ vis.push(i); return {ret}; }}); '
                f'console.log({c["L"]}, r, vis);')
    return body


def m_map(c):
    return f'const r = {c["A"]}.map({cb(c, ["v"])} => {lab_fn(c)}(v) + "!"); console.log({c["L"]}, r);'


def m_foreach(c):
    return f'const vis: number[] = []; {c["A"]}.forEach({cb(c, ["v", "i"])} => {{ vis.push(i); }}); console.log({c["L"]}, vis);'


def m_filter(c):
    return f'const r = {c["A"]}.filter({cb(c, ["v", "i"])} => i !== 1); console.log({c["L"]}, r);'


def m_reduce(method):
    def body(c):
        acc = "acc" if c["typed"] else "acc: any"
        targ = "<string>" if c["typed"] else ""  # typed: the generic overload, whatever T is
        return (f'const r = {c["A"]}.{method}{targ}(({acc}, {"v" if c["typed"] else "v: any"}, i{"" if c["typed"] else ": number"}) => '
                f'acc + i + "=" + {lab_fn(c)}(v) + ";", ""); console.log({c["L"]}, r);')
    return body


def m_reduce_noinit(method):
    def body(c):
        p = "(p, q)" if c["typed"] else "(p: any, q: any)"
        return f'const r = {c["A"]}.{method}({p} => q); console.log({c["L"]}, r);'
    return body


def m_flatmap(c):
    return f'const r = {c["A"]}.flatMap({cb(c, ["v"])} => [{lab_fn(c)}(v)]); console.log({c["L"]}, r);'


def m_search(method, arg):
    def body(c):
        return f'console.log({c["L"]}, {c["A"]}.{method}({arg}));'
    return body


def m_at(c):
    return f'console.log({c["L"]}, {c["A"]}.at(0), {c["A"]}.at(1), {c["A"]}.at(-1));'


def m_index(c):
    t = f'{c["T"]} | undefined' if c["typed"] else "any"
    return f'const v0: {t} = {c["A"]}[0]; const v1: {t} = {c["A"]}[1]; console.log({c["L"]}, v0, v1);'


def simple(expr):
    def body(c):
        return f'console.log({c["L"]}, {expr.replace("$A", c["A"])});'
    return body


def m_splice(c):
    return f'const r = {c["A"]}.splice(1, 2); console.log({c["L"]}, r, a);'


def m_inplace(method, args):
    def body(c):
        return f'const r = {c["A"]}.{method}({args}); console.log({c["L"]}, r, a, r === a);'
    return body


def m_copy(method, args):
    def body(c):
        return f'const r = {c["A"]}.{method}({args}); console.log({c["L"]}, r, a);'
    return body


def m_forof(c):
    return f'const out: string[] = []; for (const v of {c["A"]}) {{ out.push({lab_fn(c)}(v)); }} console.log({c["L"]}, out);'


def m_forin(c):
    return f'const out: string[] = []; for (const k in {c["A"]}) {{ out.push(k); }} console.log({c["L"]}, out);'


def m_destructure(c):
    return f'const [p, q, s] = {c["A"]}; console.log({c["L"]}, p, q, s);'


def m_logged(c):
    return f'console.log({c["L"]}, {c["A"]}, {c["A"]}.length);'


GROUPS = {
    "sort": [("sort", m_sort), ("sortc", m_sortc), ("toSorted", m_tosorted), ("toSortedc", m_tosortedc)],
    "callbacks": [
        ("map", m_map), ("forEach", m_foreach), ("filter", m_filter),
        ("some", visit("some", "false")), ("every", visit("every", "true")),
        ("reduce", m_reduce("reduce")), ("reduceRight", m_reduce("reduceRight")),
        ("reduce0", m_reduce_noinit("reduce")), ("reduceRight0", m_reduce_noinit("reduceRight")),
        ("flatMap", m_flatmap),
    ],
    "search": [
        ("find", visit("find", "false")), ("findIndex", visit("findIndex", "false")),
        ("findLast", visit("findLast", "false")), ("findLastIndex", visit("findLastIndex", "false")),
        ("indexOf", m_search("indexOf", "V1")), ("lastIndexOf", m_search("lastIndexOf", "V1")), ("includes", m_search("includes", "V1")),
        ("indexOfU", m_search("indexOf", "undefined")), ("lastIndexOfU", m_search("lastIndexOf", "undefined")), ("includesU", m_search("includes", "undefined")),
        ("indexOfN", m_search("indexOf", "null")), ("includesN", m_search("includes", "null")),
        ("at", m_at), ("index", m_index),
    ],
    "strings": [
        ("log", m_logged), ("join", simple("$A.join()")), ("join-", simple('$A.join("-")')), ("toString", simple("$A.toString()")),
        ("String", simple("String($A)")), ("template", simple("`[${$A}]`")), ("JSON", simple("JSON.stringify($A)")),
        ("keys", simple("Object.keys($A)")), ("values", simple("Object.values($A)")),
    ],
    "copy": [
        ("concat", m_copy("concat", "[V0]")), ("slice", m_copy("slice", "1")), ("splice", m_splice),
        ("toSpliced", m_copy("toSpliced", "1, 1")), ("toReversed", m_copy("toReversed", "")), ("reverse", m_inplace("reverse", "")),
        ("with", m_copy("with", "0, V0")), ("fill", m_inplace("fill", "V0, 1, 2")), ("copyWithin", m_inplace("copyWithin", "0, 2")),
        ("flat", m_copy("flat", "")),
    ],
    "iter": [
        ("forOf", m_forof), ("forIn", m_forin), ("spread", simple("[...$A]")), ("from", simple("Array.from($A)")),
        ("destructure", m_destructure), ("keysIt", simple("[...$A.keys()]")), ("valuesIt", simple("[...$A.values()]")),
        ("entriesIt", simple("[...$A.entries()]")),
    ],
}


def method_applies(r, typed, method):
    """Leave out calls tsc rejects: undefined/null arguments where T has none."""
    if method in ("indexOfU", "lastIndexOfU", "includesU") and typed and not r["U"]:
        return False
    if method in ("indexOfN", "includesN") and typed and not r["N"]:
        return False
    return True


# ------------------------------------------------------------ program text
PRELUDE = '''class P {
  constructor(public x: number, public id: string) {}
  toString(): string {
    return "P" + this.x;
  }
}
interface Rec {
  n: number;
  id: string;
}
let ucalls = 0;
let seen: string[] = [];
function reset(): void {
  ucalls = 0;
  seen = [];
}
function args(): string {
  const distinct: string[] = [];
  for (const s of seen) {
    if (!distinct.includes(s)) {
      distinct.push(s);
    }
  }
  return "args=" + distinct.sort().join(",");
}
function errText(e: unknown): string {
  return e instanceof Error ? e.name + "\\n#msg " + e.message : "non-error " + String(e);
}
function labAny(v: any): string {
  if (v === undefined) {
    return "undefined";
  }
  if (v === null) {
    return "null";
  }
  if (typeof v === "object") {
    return String(v.id);
  }
  return String(v);
}
function keyAny(v: any): number {
  if (v === undefined) {
    return 1e9;
  }
  if (v === null) {
    return -1;
  }
  if (typeof v === "number") {
    return v;
  }
  if (typeof v === "string") {
    return v.length * 1000 + v.charCodeAt(0);
  }
  if (typeof v === "boolean") {
    return v ? 1 : 0;
  }
  return v.x !== undefined ? v.x : v.n;
}
function cmpAny(p: any, q: any): number {
  if (p === undefined || q === undefined) {
    ucalls++;
  }
  seen.push(labAny(p), labAny(q));
  return keyAny(p) - keyAny(q);
}
'''


def typed_helpers(r):
    T = r["T"]
    if r["kind"] in ("any", "unk"):
        lab = f"function lab(v: {T}): string {{\n  return labAny(v);\n}}\n"
        cmp = (f"function cmp(p: {T}, q: {T}): number {{\n  return cmpAny(p, q);\n}}\n")
        return lab + cmp
    lab = f"function lab(v: {T}): string {{\n  return {r['lab']};\n}}\n"
    key = f"function key(v: {T}): number {{\n  return {r['key']};\n}}\n"
    cmp = (f"function cmp(p: {T}, q: {T}): number {{\n"
           f"  if ((p as unknown) === undefined || (q as unknown) === undefined) {{\n    ucalls++;\n  }}\n"
           f"  seen.push(lab(p), lab(q));\n  return key(p) - key(q);\n}}\n")
    return lab + key + cmp


def array_type(T):
    return f"({T})[]" if "|" in T else f"{T}[]"


def build_array(r, toks):
    T = r["T"]
    if isinstance(toks, tuple):  # a match array: (regex, subject)
        copy = ".slice()" if r is REPS["mcopy"] else ""
        return [f"const a = {toks[0]}.exec({toks[1]})!{copy};"]
    if "H" not in toks:
        items = ", ".join("undefined" if t == "U" else "null" if t == "N" else t for t in toks)
        return [f"const a: {array_type(T)} = [{items}];"]
    lines = [f"const a: {array_type(T)} = new Array<{T}>({len(toks)});"]
    for i, t in enumerate(toks):
        if t == "H":
            continue
        v = "undefined" if t == "U" else "null" if t == "N" else t
        lines.append(f"a[{i}] = {v};")
    return lines


def program(rname, mode, group, seed):
    r = REPS[rname]
    typed = mode == "typed"
    rng = random.Random(f"{seed}:{rname}")
    order = list(range(5))
    if seed != 0:
        rng.shuffle(order)
    vals = [r["vals"][i] for i in order]
    lines = [f"// H06 matrix: {rname} ({r['T']}[]), {mode}, {group}. Generated by h06-probes/gen.py; do not edit."]
    lines += PRELUDE.splitlines()
    lines += typed_helpers(r).splitlines()
    for i, v in enumerate(vals):
        lines.append(f"const V{i}: {r['T']} = {v};")
    cases = []
    for cname in contents_for(r):
        toks = MATCH_CONTENTS[cname] if r["kind"] == "match" else CONTENTS[cname]
        for mname, body in GROUPS[group]:
            if not method_applies(r, typed, mname):
                continue
            label = f"{cname}.{mname}"
            fn = f"case_{cname}_{mname.replace('-', '_dash')}"
            ctx = dict(A="a" if typed else "x", L=json.dumps(label), T=r["T"], typed=typed, r=r)
            start = len(lines) + 1
            lines.append(f"function {fn}(): void {{")
            lines.append("  try {")
            for b in build_array(r, toks):
                lines.append("    " + b)
            if not typed:
                lines.append("    const x: any = a;")
            lines.append("    " + body(ctx))
            lines.append("  } catch (e) {")
            lines.append(f"    console.log({json.dumps(label)}, \"threw\", errText(e));")
            lines.append("  }")
            lines.append("}")
            cases.append(dict(label=label, fn=fn, content=cname, tokens=toks, method=mname, start=start, end=len(lines)))
    lines.append("")
    calls_at = len(lines) + 1
    for c in cases:
        lines.append(f"{c['fn']}();")
    return "\n".join(lines) + "\n", cases, calls_at


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--only", default=None, help="comma list of program names to write")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    manifest = {"seed": a.seed, "programs": []}
    only = set(a.only.split(",")) if a.only else None
    for rname, r in REPS.items():
        for mode in ("typed", "any"):
            for group in GROUPS:
                name = f"{rname}-{mode}-{group}"
                if only and name not in only:
                    continue
                text, cases, calls_at = program(rname, mode, group, a.seed)
                (out / f"{name}.pts").write_text(text)
                manifest["programs"].append(dict(name=name, rep=rname, T=r["T"], U=r["U"], N=r["N"], holes=r["holes"],
                                                 mode=mode, group=group, cases=cases, calls_at=calls_at))
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1))
    n = sum(len(p["cases"]) for p in manifest["programs"])
    print(f"{len(manifest['programs'])} programs, {n} cases in {out}")


if __name__ == "__main__":
    main()
