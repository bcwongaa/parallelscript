#!/usr/bin/env python3
"""Counts for the final matrix: programs and cases per class, non-OK cases per bucket,
DEFECT cases per family (classify.FAMILIES) with where each hits and one sample, and
every DEFECT case no family explains (F?), in full.

Usage: families.py results.json...
"""

import json
import sys
from collections import Counter, defaultdict

import classify


def main():
    by = {}
    for f in sys.argv[1:]:
        for p in json.load(open(f))["programs"]:
            by[p["name"]] = p
    classes, buckets, prog_worst = Counter(), Counter(), Counter()
    fam = defaultdict(list)
    order = ["ICE", "CRASH", "TIMEOUT", "WRONG-EXIT", "WRONG", "MISSING", "PROGRAM-DIAG", "GENERR", "DIAG", "OK"]
    for n, p in sorted(by.items()):
        rep, mode, group = n.rsplit("-", 2)
        worst = "OK"
        for label, c in p["cases"].items():
            classes[c["class"]] += 1
            worst = min(worst, c["class"], key=order.index)
            if c["class"] == "OK":
                continue
            content, method = label.split(".", 1)
            bucket, reason = classify.classify(rep, mode, group, content, method, c)
            buckets[bucket] += 1
            if bucket == "DEFECT":
                fam[classify.family(rep, mode, group, content, method, c)].append((rep, mode, label, c))
        prog_worst[worst] += 1
    print("programs:", len(by), "worst class per program:", dict(prog_worst))
    print("cases:", sum(classes.values()), dict(classes))
    print("non-OK cases by bucket:", dict(buckets))
    for f in sorted(fam, key=lambda k: (k == "F?", k)):
        hits = fam[f]
        names = sorted({f"{r}/{m}" for r, m, _, _ in hits})
        methods = sorted({l.split(".", 1)[1] for _, _, l, _ in hits})
        print(f"\n{f} ({len(hits)} cases): {classify.FAMILIES.get(f, 'UNEXPLAINED')}")
        print("   methods:", ", ".join(methods))
        print("   in:", ", ".join(names))
        shown = hits if f == "F?" else hits[:1]
        for r, m, l, c in shown:
            print(f"   [{r}/{m}] {l}")
            print("     node:", (c.get("node") or "").replace("\n", " ")[:300])
            print("     pts :", (c.get("pts") or c.get("diag") or "").replace("\n", " ")[:300], "|", (c.get("pts_msg") or "")[:120])


if __name__ == "__main__":
    main()
