// How Bun 1.4.3's serve takes tls options (for comparison with the H33b contract).
const dir = import.meta.dir;
const cert = await Bun.file(`${dir}/cert.pem`).text();
const key = await Bun.file(`${dir}/key.pem`).text();
const cases: [string, any][] = [
  ["empty", {}],
  ["certFile/keyFile", { certFile: `${dir}/cert.pem`, keyFile: `${dir}/key.pem` }],
  ["cert/key", { cert, key }],
  ["cert only", { cert }],
  ["key only", { key }],
  ["missing certFile", { certFile: "missing.pem", keyFile: `${dir}/key.pem` }],
  ["bad cert", { cert: "not pem", key }],
  ["passphrase on a plain key", { cert, key, passphrase: "x" }],
  ["cert and certFile", { cert, certFile: `${dir}/cert.pem`, key }],
];
for (const [label, tls] of cases) {
  try {
    const s = Bun.serve({ port: 0, hostname: "127.0.0.1", tls, fetch: () => new Response("x") });
    console.log(label, "->", s.protocol, s.url.href);
    s.stop(true);
  } catch (e: any) {
    console.log(label, "throws", e?.name, e?.constructor?.name, JSON.stringify(e?.message), e?.code, e?.errno, e?.syscall, e?.path);
  }
}
