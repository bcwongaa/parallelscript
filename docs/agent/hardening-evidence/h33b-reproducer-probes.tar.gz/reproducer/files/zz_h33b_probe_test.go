//go:build h33bprobe

// The H33b reproducer's sanity checks of its own tests (never committed): the key and
// certificate files they write, parsed by the vendored mbedTLS (a stand-in built on it) and
// by OpenSSL; the Go side's TLS mechanics against a stand-in server on mbedTLS; and
// checkHTTPSServer against Bun.serve running server_tls.pts adapted.
package tests

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

const standin = "/tmp/h33b/reproducer/standin/mbedtls_standin"

func TestH33bKeyFormats(t *testing.T) {
	dir := t.TempDir()
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	intermediate := newAuthority(t, "PTS Test Intermediate CA", "p256", root, nil)
	p256 := serverCert(t, intermediate, "p256", nil)
	rsaChain := serverCert(t, root, "rsa", nil)
	p384 := serverCert(t, root, "p384", nil)
	_, ed25519Key, _ := ed25519.GenerateKey(rand.Reader)
	ed := certifyDER(t, &x509.Certificate{DNSNames: []string{"localhost"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour)}, ed25519Key, root)
	file := func(name string, data []byte) string { return writeFile(t, dir, name, data) }
	cert := file("p256.pem", chainPEM(p256))
	reversed := file("reversed.pem", append(chainPEM(tlsCertOf(intermediate.cert)), chainPEM(p256)...))
	for _, run := range []struct {
		name, cert, key, password, want string
	}{
		{"pkcs8 p256", cert, file("k1", keyPEM(t, signerOf(p256), "pkcs8")), "", "ok"},
		{"sec1 p256", cert, file("k2", keyPEM(t, signerOf(p256), "sec1")), "", "ok"},
		{"pkcs1 rsa", file("rsa.pem", chainPEM(rsaChain)), file("k3", keyPEM(t, signerOf(rsaChain), "pkcs1")), "", "ok"},
		{"pkcs8 rsa", file("rsa2.pem", chainPEM(rsaChain)), file("k4", keyPEM(t, signerOf(rsaChain), "pkcs8")), "", "ok"},
		{"sec1 p384", file("p384.pem", chainPEM(p384)), file("k5", keyPEM(t, signerOf(p384), "sec1")), "", "ok"},
		{"encrypted pkcs8 right", cert, file("k6", encryptedPKCS8PEM(t, signerOf(p256), tlsPassphrase)), tlsPassphrase, "ok"},
		{"encrypted pkcs8 none", cert, file("k7", encryptedPKCS8PEM(t, signerOf(p256), tlsPassphrase)), "", "key:"},
		{"encrypted pkcs8 wrong", cert, file("k8", encryptedPKCS8PEM(t, signerOf(p256), tlsPassphrase)), "wrong", "key:"},
		{"legacy ec right", cert, file("k9", legacyEncryptedPEM(t, signerOf(p256), tlsPassphrase)), tlsPassphrase, "ok"},
		{"legacy ec none", cert, file("k10", legacyEncryptedPEM(t, signerOf(p256), tlsPassphrase)), "", "key:"},
		{"legacy ec wrong", cert, file("k11", legacyEncryptedPEM(t, signerOf(p256), tlsPassphrase)), "wrong", "key:"},
		{"legacy rsa right", file("rsa3.pem", chainPEM(rsaChain)), file("k12", legacyEncryptedPEM(t, signerOf(rsaChain), tlsPassphrase)), tlsPassphrase, "ok"},
		{"passphrase on plain key", cert, file("k13", keyPEM(t, signerOf(p256), "pkcs8")), "unused", "ok"},
		{"another key", cert, file("k14", keyPEM(t, newKey(t, "p256"), "pkcs8")), "", "pair:"},
		{"rsa cert p256 key", file("rsa4.pem", chainPEM(rsaChain)), file("k15", keyPEM(t, signerOf(p256), "pkcs8")), "", "pair:"},
		{"reversed chain", reversed, file("k16", keyPEM(t, signerOf(p256), "pkcs8")), "", "pair:"},
		{"ed25519 cert", file("ed.pem", pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: ed})), file("k17", keyPEM(t, signerOf(p256), "pkcs8")), "", "cert:"},
		{"not a cert", file("junk.pem", []byte("not a certificate")), file("k18", keyPEM(t, signerOf(p256), "pkcs8")), "", "cert:"},
		{"key as cert", file("k19c", keyPEM(t, signerOf(p256), "pkcs8")), file("k19", keyPEM(t, signerOf(p256), "pkcs8")), "", "cert:"},
		{"cert as key", cert, cert, "", "key:"},
		{"not a key", cert, file("junk-key.pem", []byte("not a key")), "", "key:"},
	} {
		args := []string{"parse", run.cert, run.key}
		if run.password != "" {
			args = append(args, run.password)
		}
		out, _ := exec.Command(standin, args...).CombinedOutput()
		t.Logf("%-26s mbedTLS: %s", run.name, strings.TrimSpace(string(out)))
		assert.Check(t, strings.HasPrefix(string(out), run.want), "%s: %s", run.name, out)
		if strings.HasPrefix(run.name, "encrypted") || strings.HasPrefix(run.name, "legacy") {
			pass := run.password
			if pass == "" {
				pass = "empty-will-fail"
			}
			openssl, err := exec.Command("openssl", "pkey", "-in", run.key, "-passin", "pass:"+pass, "-noout").CombinedOutput()
			t.Logf("%-26s OpenSSL: err=%v %s", run.name, err, strings.TrimSpace(string(openssl)))
			assert.Check(t, (err == nil) == (run.want == "ok"), "%s: openssl disagrees: %s", run.name, openssl)
		}
	}
}

// tlsCertOf is a chain of cert alone.
func tlsCertOf(cert *x509.Certificate) tls.Certificate {
	return tls.Certificate{Certificate: [][]byte{cert.Raw}}
}

// startStandin starts the mbedTLS stand-in with a P-256 chain through an intermediate.
func startStandin(t *testing.T) (address string, roots *x509.CertPool) {
	dir := t.TempDir()
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	intermediate := newAuthority(t, "PTS Test Intermediate CA", "p256", root, nil)
	chain := serverCert(t, intermediate, "p256", nil, intermediate.cert)
	server, fields := startServer(t, standin+"-serve", "STANDIN_CERT="+writeFile(t, dir, "c.pem", chainPEM(chain)), "STANDIN_KEY="+writeFile(t, dir, "k.pem", keyPEM(t, signerOf(chain), "pkcs8")))
	t.Cleanup(func() { t.Logf("stand-in stderr: %s", server.stderr) })
	return "127.0.0.1:" + fields[0], pool(root.cert)
}

func TestH33bStandInMechanics(t *testing.T) {
	address, roots := startStandin(t)
	for _, version := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		cache := tls.NewLRUClientSessionCache(4)
		asked := false
		for i := range 2 {
			conn := dialTLS(t, address, &tls.Config{RootCAs: roots, MinVersion: version, MaxVersion: version, ClientSessionCache: cache, NextProtos: []string{"h2", "http/1.1"},
				GetClientCertificate: func(*tls.CertificateRequestInfo) (*tls.Certificate, error) {
					asked = true
					return &tls.Certificate{}, nil
				}})
			assert.Equal(t, conn.ConnectionState().NegotiatedProtocol, "http/1.1")
			conn.send(t, "GET / HTTP/1.1\r\nHost: a\r\n\r\n")
			_, body := conn.response(t)
			assert.Equal(t, body, "hello")
			assert.Equal(t, conn.rest(t), "")
			t.Logf("%s #%d: records %+v ended=%v resumed=%v", tls.VersionName(version), i, conn.tcp.records, conn.tcp.ended, conn.ConnectionState().DidResume)
			conn.endedWithCloseNotify(t)
			assert.Assert(t, !conn.ConnectionState().DidResume)
		}
		assert.Assert(t, !asked)
	}
	_, err := handshake(t, address, &tls.Config{RootCAs: roots, NextProtos: []string{"h2"}})
	t.Logf("h2 only: %v", err)
	assert.ErrorContains(t, err, "no application protocol")
	_, err = handshake(t, address, &tls.Config{RootCAs: roots, MinVersion: tls.VersionTLS10, MaxVersion: tls.VersionTLS11})
	t.Logf("TLS 1.1: %v", err)
	assert.ErrorContains(t, err, "protocol version")
	conn := dialTLS(t, address, &tls.Config{RootCAs: roots})
	assert.Equal(t, conn.ConnectionState().NegotiatedProtocol, "")
	conn.send(t, "GET / HTTP/1.1\r\nHost: a\r\n\r\n")
	_, _ = conn.response(t)
	_ = conn.rest(t)
	conn.endedWithCloseNotify(t)
	noHTTPAnswer(t, address, []byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
	noHTTPAnswer(t, address, []byte(strings.Repeat("\xff", 4096)))
	noHTTPAnswer(t, address, garbageHello)
	for _, name := range []string{"anything.example", ""} {
		c := dialTLS(t, address, &tls.Config{ServerName: name, InsecureSkipVerify: true, VerifyConnection: func(state tls.ConnectionState) error {
			_, err := state.PeerCertificates[0].Verify(x509.VerifyOptions{DNSName: "localhost", Roots: roots, Intermediates: pool(state.PeerCertificates[1:]...)})
			return err
		}})
		c.send(t, "GET / HTTP/1.1\r\nHost: a\r\n\r\n")
		_, body := c.response(t)
		assert.Equal(t, body, "hello")
	}
}

// TestH33bCloseNotifyNegative checks that endedWithCloseNotify's record check isn't vacuous:
// a Go TLS server that ends the TCP connection without close_notify leaves a last record
// that is the response's.
func TestH33bCloseNotifyNegative(t *testing.T) {
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	chain := serverCert(t, root, "p256", nil)
	for _, version := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		for _, notify := range []bool{true, false} {
			listener := listen(t, "127.0.0.1:0")
			go func() {
				raw, err := listener.Accept()
				if err != nil {
					return
				}
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{chain}})
				buf := make([]byte, 4096)
				_, _ = conn.Read(buf)
				_, _ = io.WriteString(conn, "HTTP/1.1 200 OK\r\ncontent-length: 2\r\nconnection: close\r\n\r\nok")
				if notify {
					_ = conn.Close()
				} else {
					_ = raw.Close()
				}
			}()
			conn := dialTLS(t, listener.Addr().String(), &tls.Config{RootCAs: pool(root.cert), MinVersion: version, MaxVersion: version})
			conn.send(t, "GET / HTTP/1.1\r\nHost: a\r\n\r\n")
			_, body := conn.response(t)
			assert.Equal(t, body, "ok")
			_ = conn.rest(t)
			last, ended := conn.tcp.last()
			t.Logf("%s close_notify=%v: last record %+v, TCP end read by the TLS client: %v", tls.VersionName(version), notify, last, ended)
			assert.Equal(t, !ended, notify)
			if notify {
				conn.endedWithCloseNotify(t)
			}
		}
	}
}

// TestH33bBun runs checkHTTPSServer against Bun.serve running server_tls.pts adapted
// (imports from "bun", url as a URL's href), to see which checks are about the Go side's
// mechanics (which must pass) and which about pts's own server (Bun may differ).
func TestH33bBun(t *testing.T) {
	bun := filepath.Join(os.Getenv("HOME"), ".bun/bin/bun")
	source, err := os.ReadFile(filepath.Join("http", "server_tls.pts"))
	assert.NilError(t, err)
	adapted := strings.Replace(string(source), `import { serve, Server, type TLSOptions } from "pts:http";`, `import { serve, type Server, type TLSOptions } from "bun";`, 1)
	adapted = strings.ReplaceAll(adapted, "server.url === ", "server.url.href === ")
	dir := t.TempDir()
	script := writeFile(t, dir, "server_tls.ts", []byte(adapted))
	wrapper := writeFile(t, dir, "run.sh", []byte(fmt.Sprintf("#!/bin/sh\nexec %s %s\n", bun, script)))
	assert.NilError(t, os.Chmod(wrapper, 0o755))
	checkHTTPSServer(t, startHTTPSServer(t, wrapper))
}

// TestH33bPlainRefusals sends the raw cases of "the protocol inside TLS" that the server
// refuses to the base's plain server.pts, to check the texts the TLS test expects of them
// (and that the oversized head is answered, not reset).
func TestH33bPlainRefusals(t *testing.T) {
	server := startHTTPServer(t)
	for _, raw := range []string{
		"NOT HTTP\r\n\r\n",
		"GET /hello HTTP/1.1\r\nHost: a\r\nX-Split: a\rb\r\n\r\n",
		"POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: 100000000\r\n\r\n",
		oversizedHead(),
		oversizedHead() + strings.Repeat("b", 30000),
	} {
		got := exchange(t, server.main, raw)
		t.Logf("%d bytes -> %q", len(raw), dated.ReplaceAllString(got, ""))
	}
	_, body := request(t, "GET", server.main+"/stop", "")
	assert.Equal(t, body, "bye")
}

// TestH33bPlainConnectionGrowth measures how the plain lifecycle server's VmRSS and VmData
// move over a thousand fresh connections after a warm-up, the noise floor of the TLS
// lifecycle test's bound.
func TestH33bPlainConnectionGrowth(t *testing.T) {
	exe := buildServer(t, "lifecycle")
	for _, threads := range []string{"1", "4"} {
		server, ports := startServer(t, exe, "PTS_THREADS="+threads)
		pid := server.cmd.Process.Pid
		fresh := &http.Client{Transport: &http.Transport{DisableKeepAlives: true}, Timeout: 10 * time.Second}
		base := "http://127.0.0.1:" + ports[0] + "/tiny"
		_ = getAll(t, fresh, base, 16, 10)
		for round := range 3 {
			rss, data := statusKB(t, pid, "VmRSS"), statusKB(t, pid, "VmData")
			_ = getAll(t, fresh, base, 16, 63)
			time.Sleep(200 * time.Millisecond)
			t.Logf("PTS_THREADS=%s round %d: VmRSS %+d kB, VmData %+d kB (now %d / %d kB)", threads, round, statusKB(t, pid, "VmRSS")-rss, statusKB(t, pid, "VmData")-data, statusKB(t, pid, "VmRSS"), statusKB(t, pid, "VmData"))
		}
		_ = server.cmd.Process.Kill()
	}
}

// tlsProxy terminates TLS with cert at a new listener and forwards each connection to
// backend over plain TCP: a client's close_notify alone half-closes the backend
// connection, a client's reset closes it, and the backend's end is close_notify.
func tlsProxy(t *testing.T, backend string, cert tls.Certificate) string {
	listener, err := tls.Listen("tcp", "127.0.0.1:0", &tls.Config{Certificates: []tls.Certificate{cert}})
	assert.NilError(t, err)
	t.Cleanup(func() { _ = listener.Close() })
	go func() {
		for {
			client, err := listener.Accept()
			if err != nil {
				return
			}
			go func() {
				server, err := net.Dial("tcp", backend)
				if err != nil {
					_ = client.Close()
					return
				}
				go func() {
					if _, err := io.Copy(server, client); err == nil {
						_ = server.(*net.TCPConn).CloseWrite()
					} else {
						_ = server.Close()
					}
				}()
				_, _ = io.Copy(client, server)
				_ = client.Close()
				_ = server.Close()
			}()
		}
	}()
	return listener.Addr().String()
}

// TestH33bLifecycleThroughProxy runs checkHTTPSLifecycle against the base-compatible
// lifecycle_tls (plain HTTP) behind tlsProxy, so that the test's TLS client side meets
// pts:http's own semantics. Expected to differ: "connection refused" (the proxy listens on).
func TestH33bLifecycleThroughProxy(t *testing.T) {
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	cert := serverCert(t, root, "p256", nil)
	for _, threads := range []string{"1", "4"} {
		t.Run("PTS_THREADS="+threads, func(t *testing.T) {
			server, ports := startServer(t, "/tmp/h33b/reproducer/basecompat/lifecycle_tls", "PTS_THREADS="+threads)
			main := tlsProxy(t, "127.0.0.1:"+ports[0], cert)
			second := tlsProxy(t, "127.0.0.1:"+ports[1], cert)
			checkHTTPSLifecycle(t, server, main, second, &tls.Config{RootCAs: pool(root.cert)}, false)
		})
	}
}

// TestH33bServerThroughProxy runs checkHTTPSServer against the base-compatible server_tls
// (plain HTTP) behind tlsProxy, so that its HTTP expectations meet pts:http's own server.
// Expected to differ: what is about TLS itself (the proxy's Go TLS, not mbedTLS), and
// request.url and the handler's server, which are http:// on the base.
func TestH33bServerThroughProxy(t *testing.T) {
	server := startHTTPSServer(t, "/tmp/h33b/reproducer/basecompat/server_tls")
	root := newAuthority(t, "PTS Proxy Root CA", "p256", nil, nil)
	intermediate := newAuthority(t, "PTS Proxy Intermediate CA", "p256", root, nil)
	cert := serverCert(t, intermediate, "p256", nil, intermediate.cert)
	for name, address := range server.addresses {
		server.addresses[name] = tlsProxy(t, address, cert)
	}
	server.roots = pool(root.cert)
	server.rootFile = writePEM(t, t.TempDir(), "root.pem", root.cert)
	checkHTTPSServer(t, server)
}

// TestH33bRawThroughProxy runs the raw cases of "the protocol inside TLS" after the HTTP/1.0
// url check (which the proxy's other port fails) against the base-compatible server_tls
// behind tlsProxy, copied from checkHTTPSServer.
func TestH33bRawThroughProxy(t *testing.T) {
	server := startHTTPSServer(t, "/tmp/h33b/reproducer/basecompat/server_tls")
	root := newAuthority(t, "PTS Proxy Root CA", "p256", nil, nil)
	address := tlsProxy(t, server.addresses["main"], serverCert(t, root, "p256", nil))
	for _, version := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		config := &tls.Config{RootCAs: pool(root.cert), MinVersion: version, MaxVersion: version}
		name := tls.VersionName(version)
		kept := dialTLS(t, address, config)
		kept.send(t, "GET /hello HTTP/1.0\r\nConnection: keep-alive\r\n\r\n")
		response, body := kept.response(t)
		assert.Equal(t, response.Header.Get("Connection"), "keep-alive", name)
		assert.Equal(t, body, "hello")
		kept.send(t, "POST /echo HTTP/1.1\r\nHost: a\r\nTransfer-Encoding: chunked\r\nConnection: close\r\n\r\n4\r\nchun\r\n3;ext=1\r\nked\r\n0\r\n\r\n")
		_, body = kept.response(t)
		assert.Equal(t, body, "chunked", "%s: a chunked body", name)
		kept.endedWithCloseNotify(t)

		continued := dialTLS(t, address, config)
		continued.send(t, "POST /echo HTTP/1.1\r\nHost: a\r\nExpect: 100-continue\r\nContent-Length: 4\r\nConnection: close\r\n\r\n")
		assert.NilError(t, continued.SetReadDeadline(time.Now().Add(20*time.Second)))
		interim := make([]byte, len("HTTP/1.1 100 Continue\r\n\r\n"))
		_, err := io.ReadFull(continued.reader, interim)
		assert.NilError(t, err)
		assert.Equal(t, string(interim), "HTTP/1.1 100 Continue\r\n\r\n", name)
		continued.send(t, "body")
		_, body = continued.response(t)
		assert.Equal(t, body, "body", "%s: the body sent after 100 Continue", name)

		for _, run := range []struct{ raw, status string }{
			{"NOT HTTP\r\n\r\n", "400 Bad Request"},
			{"GET /hello HTTP/1.1\r\nHost: a\r\nX-Split: a\rb\r\n\r\n", "400 Bad Request"},
			{"POST /echo HTTP/1.1\r\nHost: a\r\nContent-Length: 100000000\r\n\r\n", "413 Content Too Large"},
			{oversizedHead(), "431 Request Header Fields Too Large"},
		} {
			refused := dialTLS(t, address, config)
			refused.send(t, run.raw)
			got := refused.rest(t)
			assert.Assert(t, dated.MatchString(got), got)
			assert.Equal(t, dated.ReplaceAllString(got, ""), "HTTP/1.1 "+run.status+"\r\ncontent-length: 0\r\nconnection: close\r\n\r\n", name)
			refused.endedWithCloseNotify(t)
		}
	}
	_, body := requestWith(t, httpsClient(pool(root.cert), nil, false), "GET", "https://"+address+"/stop", "")
	assert.Equal(t, body, "bye")
}

// TestH33bStandInKeys checks that the stand-in on mbedTLS's default configuration serves
// RSA (PKCS#1) and P-384 (SEC1) certificates to Go's client under TLS 1.2 and 1.3.
func TestH33bStandInKeys(t *testing.T) {
	root := newAuthority(t, "PTS Test Root CA", "p256", nil, nil)
	for _, run := range []struct{ kind, form string }{{"rsa", "pkcs1"}, {"p384", "sec1"}, {"p256", "sec1"}} {
		dir := t.TempDir()
		chain := serverCert(t, root, run.kind, nil)
		server, fields := startServer(t, standin+"-serve", "STANDIN_CERT="+writeFile(t, dir, "c.pem", chainPEM(chain)), "STANDIN_KEY="+writeFile(t, dir, "k.pem", keyPEM(t, signerOf(chain), run.form)))
		for _, version := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
			conn, err := handshake(t, "127.0.0.1:"+fields[0], &tls.Config{RootCAs: pool(root.cert), MinVersion: version, MaxVersion: version})
			assert.Check(t, err, "%s %s; stand-in: %s", run.kind, tls.VersionName(version), server.stderr)
			if err == nil {
				t.Logf("%s %s: %s", run.kind, tls.VersionName(version), tls.CipherSuiteName(conn.ConnectionState().CipherSuite))
				_ = conn.Close() // the stand-in serves one connection at a time
			}
		}
	}
}

// TestH33bGarbage shows which garbage the mbedTLS stand-in refuses at once and which it
// waits on (an incomplete handshake message), each against a stand-in of its own.
func TestH33bGarbage(t *testing.T) {
	for _, run := range []struct {
		name string
		raw  []byte
	}{
		{"plain HTTP", []byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n")},
		{"handshake record of garbage", []byte("\x16\x03\x01\x00\x10garbage, garbage")},
		{"0xff x 4096", []byte(strings.Repeat("\xff", 4096))},
		{"ClientHello too short", garbageHello},
		{"record too long", append([]byte("\x16\x03\x01\x48\x01"), make([]byte, 18433)...)},
		{"alert record", []byte("\x15\x03\x03\x00\x02\x02\x28")},
	} {
		address, _ := startStandin(t)
		conn, err := net.DialTimeout("tcp", address, 5*time.Second)
		assert.NilError(t, err)
		_, _ = conn.Write(run.raw)
		_ = conn.SetReadDeadline(time.Now().Add(3 * time.Second))
		got, err := io.ReadAll(conn)
		t.Logf("%-28s -> %q closed=%v (%v)", run.name, got, !isTimeout(err), err)
		_ = conn.Close()
	}
}
