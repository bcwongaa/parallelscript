#!/bin/bash
# Copies the reproducer's new test files and probe test into the scratch dir, takes the probe
# test (never committed) out of the worktree, deletes build outputs, and archives the rest.
set -e
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8
R=/tmp/h33b/reproducer
mkdir -p "$R/files/pts/tests/http" "$R/files/pts/tests/errors"
cp "$W/pts/tests/https_server_test.go" "$R/files/pts/tests/"
cp "$W/pts/tests/README.md" "$R/files/pts/tests/"
cp "$W/pts/tests/http/server_tls.pts" "$W/pts/tests/http/every_loop_tls.pts" "$W/pts/tests/http/lifecycle_tls.pts" \
  "$W/pts/tests/http/fetch_self_tls.pts" "$W/pts/tests/http/serve_tls_options.pts" "$R/files/pts/tests/http/"
cp "$W/pts/tests/errors/serve_tls_options.pts" "$R/files/pts/tests/errors/"
(cd "$W" && git diff -- pts/tests/README.md) > "$R/files/README.diff"
if [ -e "$W/pts/tests/zz_h33b_probe_test.go" ]; then
  mv "$W/pts/tests/zz_h33b_probe_test.go" "$R/files/zz_h33b_probe_test.go"
fi
# build outputs: the probes' and base-compatible programs' binaries, the stand-in, the worktree's CLI
for f in "$R"/basecompat/server_tls "$R"/basecompat/every_loop_tls "$R"/basecompat/lifecycle_tls "$R"/basecompat/fetch_self_tls \
  "$R"/basecompat/fetch_self_plain "$R"/basecompat/serve_tls_options "$R"/probes/dir_read "$R"/probes/reuse_fds "$R"/probes/ipv6_url \
  "$R"/standin/mbedtls_standin "$W"/pts-bin/pts; do
  rm -f "$f"
done
rm -rf "$R/basecompat/options-run" "$R/standin/s_client"
tar -czf /tmp/h33b/reproducer-probes.tar.gz -C /tmp/h33b reproducer
tar -tzf /tmp/h33b/reproducer-probes.tar.gz | wc -l
ls -la /tmp/h33b/reproducer-probes.tar.gz
