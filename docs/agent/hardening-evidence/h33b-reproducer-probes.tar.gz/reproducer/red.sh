#!/bin/bash
# The RED run of the reproducer's H33b tests against the worktree's base compiler.
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8 || exit 1
{
  echo "+ git rev-parse HEAD: $(git rev-parse HEAD)"
  echo "+ GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test -count=1 -p 1 -timeout 40m -v -run 'TestHTTPSServer' ./pts/tests/"
  GOMAXPROCS=2 PTS_REQUIRE_NODE=1 taskset -c 0,1,2 go test -count=1 -p 1 -timeout 40m -v -run 'TestHTTPSServer' ./pts/tests/
  echo "exit=$?"
  echo "+ GOMAXPROCS=2 go test -count=1 -p 1 -v -run 'TestErrors/serve_tls_options' ./pts/tests/"
  GOMAXPROCS=2 taskset -c 0,1,2 go test -count=1 -p 1 -timeout 20m -v -run 'TestErrors/serve_tls_options' ./pts/tests/
  echo "exit=$?"
} > /tmp/h33b/reproducer/red.log 2>&1
