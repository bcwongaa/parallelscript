const s = Bun.serve({ port: 0, hostname: "::1", fetch: (r) => new Response(r.url) });
console.log(s.url.href.replace(String(s.port), "PORT"), s.hostname);
const r = await fetch(`http://[::1]:${s.port}/x`); console.log("request.url by fetch:", (await r.text()).replace(String(s.port), "PORT")); s.stop();
