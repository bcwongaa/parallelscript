// What pts:fs's readFileSync throws for a directory and a missing file.
import { readFileSync } from "pts:fs";

for (const path of ["/tmp", "missing.pem"]) {
  try {
    readFileSync(path, "utf8");
  } catch (e) {
    const error = e as NodeJS.ErrnoException;
    console.log(`${error.name}: ${error.message} | ${error.code} ${error.errno} ${error.syscall} ${error.path}`);
  }
}
