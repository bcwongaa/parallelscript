#!/bin/bash
# Runs go test in the reproducer's worktree on at most two cores (three after the parent's
# baseline suite is done): gotest.sh LOG [go test args...]
log=$1
shift
cores=0,1
if [ -e /tmp/h33b/base-suite.done ]; then
  cores=0,1,2
fi
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8 || exit 1
GOMAXPROCS=2 taskset -c "$cores" go test "$@" > "$log" 2>&1
code=$?
echo "go test exit=$code" >> "$log"
exit $code
