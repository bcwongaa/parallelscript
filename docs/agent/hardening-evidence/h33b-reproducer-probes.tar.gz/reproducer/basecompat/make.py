"""Writes base-compatible copies of the H33b test programs (tls and protocol taken out),
so that the base compiler can check that everything else in them is valid ParallelScript."""
import re
import sys

SRC = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8/pts/tests/http/"
OUT = "/tmp/h33b/reproducer/basecompat/"
LOCAL = "interface TLSOptions { cert?: string; certFile?: string; key?: string; keyFile?: string; passphrase?: string }\n"

for name in ["server_tls", "every_loop_tls", "lifecycle_tls", "fetch_self_tls", "serve_tls_options"]:
    s = open(SRC + name + ".pts").read()
    s = s.replace(", type TLSOptions }", " }")
    if "TLSOptions" in s:
        s = re.sub(r'(import [^\n]*"pts:http";\n)', lambda m: m.group(1) + LOCAL, s, count=1)
    s = re.sub(r"\btls: \{[^}]*\}, ", "", s)          # tls: { ... }, inline
    s = re.sub(r"\n  tls: \{[^}]*\},", "", s)          # tls: { ... }, on its own line
    s = re.sub(r"\n  tls,", "", s)                     # tls, shorthand on its own line
    s = s.replace(" tls, fetch", " fetch")             # tls, shorthand inline
    s = s.replace("reusePort, tls, fetch: hello", "reusePort, fetch: hello")
    s = re.sub(r"(\w+)\.protocol\b", '"https"', s)
    s = s.replace("server.url === `https://127.0.0.1:", "server.url === `http://127.0.0.1:")  # the plain server's url
    if name == "server_tls":  # behind the probes' TLS proxy, the URLs the TLS server would give
        s = s.replace("return new Response(request.url);", 'return new Response(request.url.replace("http://", "https://"));')
        s = s.replace("${server.url}", '${server.url.replace("http://", "https://")}')
    open(OUT + name + ".pts", "w").write(s)
    print("wrote", OUT + name + ".pts", file=sys.stderr)
