#!/bin/bash
# Builds the base-compatible copies of the H33b programs with the worktree's base compiler.
P=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8/pts-bin/pts
D=/tmp/h33b/reproducer/basecompat
for n in "$@"; do
  echo "== $n"
  GOMAXPROCS=2 taskset -c 0,1 "$P" build "$D/$n.pts" -o "$D/$n" 2>&1 | tail -8
  echo "exit=${PIPESTATUS[0]}"
done
