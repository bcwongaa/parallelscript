#!/bin/bash
# Runs the base-compatible serve_tls_options in a directory of its own, with dummy files.
D=/tmp/h33b/reproducer/basecompat
W=$D/options-run
rm -rf "$W" && mkdir -p "$W/a-directory"
cp /tmp/h33b/reproducer/bun/cert.pem /tmp/h33b/reproducer/bun/key.pem "$W/"
PORT=$(python3 -c 'import socket; s=socket.socket(); s.bind(("127.0.0.1",0)); print(s.getsockname()[1])')
cd "$W" && FREE_PORT=$PORT CERT_FILE=$W/cert.pem KEY_FILE=$W/key.pem OTHER_KEY_FILE=$W/key.pem ENCRYPTED_KEY_FILE=$W/key.pem \
  LEGACY_KEY_FILE=$W/key.pem PASSPHRASE=x RSA_CERT_FILE=$W/cert.pem ED25519_CERT_FILE=$W/cert.pem REVERSED_CHAIN_FILE=$W/cert.pem \
  DIRECTORY=$W/a-directory timeout 30 "$D/serve_tls_options"
echo "exit=$?"
