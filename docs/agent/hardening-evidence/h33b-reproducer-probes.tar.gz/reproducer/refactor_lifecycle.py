"""Turns the body of TestHTTPSServerLifecycle's subtest into checkHTTPSLifecycle (one-off edit)."""
path = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ae78911cb3d97b8d8/pts/tests/https_server_test.go"
s = open(path).read()
start = s.index("func checkHTTPSLifecycle(")
head_end = s.index("\tpid := server.cmd.Process.Pid\n\t{\n", start)
body_start = head_end + len("\tpid := server.cmd.Process.Pid\n\t{\n")
end_marker = "\t\t\tawaitExit(t, server)\n\t\t\tassert.Equal(t, server.stderr.String(), \"\")\n\t\t})\n\t}\n}\n"
body_end = s.index(end_marker, body_start)
body = s[body_start:body_end] + "\t\t\tawaitExit(t, server)\n\t\t\tassert.Equal(t, server.stderr.String(), \"\")\n"
lines = []
for line in body.split("\n"):
    lines.append(line[2:] if line.startswith("\t\t\t") else line)
body = "\n".join(lines).replace("run.sanitized", "sanitized")
body = body.replace('\t_, err := net.Dial("tcp", main)\n\tassert.ErrorContains(t, err, "connection refused")\n',
                    '\t_, err := net.Dial("tcp", main)\n\tassert.Check(t, cmp.ErrorContains(err, "connection refused"), "stop() closes the listener")\n')
s = s[:head_end] + "\tpid := server.cmd.Process.Pid\n" + body + "}\n" + s[body_end + len(end_marker):]
s = s.replace('\t"gotest.tools/v3/assert"\n)', '\t"gotest.tools/v3/assert"\n\t"gotest.tools/v3/assert/cmp"\n)', 1)
open(path, "w").write(s)
