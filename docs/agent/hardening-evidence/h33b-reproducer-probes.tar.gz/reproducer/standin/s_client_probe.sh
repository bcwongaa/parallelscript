#!/bin/bash
# openssl s_client against the mbedTLS stand-in: ALPN offered h2,http/1.1 and h2 alone, and
# whether the server's close_notify arrives (OpenSSL's -msg prints the decrypted alert).
D=/tmp/h33b/reproducer/standin
W=$D/s_client
rm -rf "$W" && mkdir -p "$W"
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout "$W/key.pem" -out "$W/cert.pem" -days 1 \
  -subj "/CN=localhost" -addext "subjectAltName=DNS:localhost,IP:127.0.0.1" 2>/dev/null
"$D/mbedtls_standin" serve "$W/cert.pem" "$W/key.pem" > "$W/standin.out" 2> "$W/standin.err" &
pid=$!
sleep 0.5
port=$(awk '/listening/ {print $2}' "$W/standin.out")
for alpn in "h2,http/1.1" "h2"; do
  for version in -tls1_2 -tls1_3; do
    echo "=== ALPN $alpn $version"
    printf 'GET / HTTP/1.1\r\nHost: a\r\n\r\n' | timeout 10 openssl s_client -connect "127.0.0.1:$port" -alpn "$alpn" $version -msg -ign_eof -CAfile "$W/cert.pem" 2>&1 \
      | grep -E "ALPN protocol|No ALPN|Alert|close_notify|no_application_protocol|^HTTP/1.1|hello|Verify return code|Protocol  *:" | sort | uniq -c
  done
done
kill "$pid"
echo "stand-in stderr:"; cat "$W/standin.err"
