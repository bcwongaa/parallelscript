/*
 * A stand-in for the H33b server built on the same vendored mbedTLS 3.6.7 and the same
 * pts_mbedtls_config.h, to check what the reproducer's tests expect of mbedTLS itself:
 * ALPN with only http/1.1 (an h2-only client gets no_application_protocol), close_notify's
 * record, no resumption without a cache or tickets, no client certificate requested, and
 * which certificates and keys parse.
 *
 *   mbedtls_standin parse CERT KEY [PASSPHRASE]   prints what parsing and pairing give
 *   mbedtls_standin serve CERT KEY [PASSPHRASE]   prints the port, then serves one
 *       connection at a time: reads a request head, answers "hello" with
 *       connection: close, sends close_notify and closes.
 */
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include <mbedtls/error.h>
#include <mbedtls/pk.h>
#include <mbedtls/psa_util.h>
#include <mbedtls/ssl.h>
#include <mbedtls/x509_crt.h>
#include <psa/crypto.h>

static const char *describe(int ret) {
  static char text[256];
  char buf[200];
  mbedtls_strerror(ret, buf, sizeof buf);
  snprintf(text, sizeof text, "%s (mbedTLS -0x%04X)", buf, (unsigned)-ret);
  return text;
}

static int load(const char *cert_path, const char *key_path, const char *password, mbedtls_x509_crt *crt, mbedtls_pk_context *pk) {
  mbedtls_x509_crt_init(crt);
  mbedtls_pk_init(pk);
  int ret = mbedtls_x509_crt_parse_file(crt, cert_path);
  if (ret != 0) {
    printf("cert: %s\n", describe(ret));
    return 1;
  }
  ret = mbedtls_pk_parse_keyfile(pk, key_path, password, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE);
  if (ret != 0) {
    printf("key: %s\n", describe(ret));
    return 1;
  }
  ret = mbedtls_pk_check_pair(&crt->pk, pk, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE);
  if (ret != 0) {
    printf("pair: %s\n", describe(ret));
    return 1;
  }
  return 0;
}

static int send_fd(void *ctx, const unsigned char *buf, size_t len) {
  ssize_t n = send(*(int *)ctx, buf, len, MSG_NOSIGNAL);
  return n < 0 ? MBEDTLS_ERR_SSL_INTERNAL_ERROR : (int)n;
}

static int recv_fd(void *ctx, unsigned char *buf, size_t len) {
  ssize_t n = recv(*(int *)ctx, buf, len, 0);
  if (n == 0) {
    return MBEDTLS_ERR_SSL_CONN_EOF;
  }
  return n < 0 ? MBEDTLS_ERR_SSL_INTERNAL_ERROR : (int)n;
}

int main(int argc, char **argv) {
  if (argc < 4) {
    fprintf(stderr, "usage: %s parse|serve CERT KEY [PASSPHRASE]\n", argv[0]);
    return 2;
  }
  psa_crypto_init();
  mbedtls_x509_crt crt;
  mbedtls_pk_context pk;
  int loaded = load(argv[2], argv[3], argc > 4 ? argv[4] : NULL, &crt, &pk);
  if (strcmp(argv[1], "parse") == 0 || loaded != 0) {
    if (loaded == 0) {
      printf("ok\n");
    }
    return loaded;
  }
  mbedtls_ssl_config conf;
  mbedtls_ssl_config_init(&conf);
  mbedtls_ssl_config_defaults(&conf, MBEDTLS_SSL_IS_SERVER, MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT);
  mbedtls_ssl_conf_rng(&conf, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE);
  mbedtls_ssl_conf_own_cert(&conf, &crt, &pk);
  static const char *alpn[] = {"http/1.1", NULL};
  mbedtls_ssl_conf_alpn_protocols(&conf, alpn);
  mbedtls_ssl_conf_authmode(&conf, MBEDTLS_SSL_VERIFY_NONE);

  int listener = socket(AF_INET, SOCK_STREAM, 0);
  struct sockaddr_in address = {.sin_family = AF_INET, .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
  socklen_t address_len = sizeof address;
  if (bind(listener, (struct sockaddr *)&address, sizeof address) != 0 || listen(listener, 16) != 0) {
    perror("listen");
    return 1;
  }
  getsockname(listener, (struct sockaddr *)&address, &address_len);
  printf("listening %d\n", ntohs(address.sin_port));
  fflush(stdout);
  for (;;) {
    int fd = accept(listener, NULL, NULL);
    if (fd < 0) {
      continue;
    }
    mbedtls_ssl_context ssl;
    mbedtls_ssl_init(&ssl);
    mbedtls_ssl_setup(&ssl, &conf);
    mbedtls_ssl_set_bio(&ssl, &fd, send_fd, recv_fd, NULL);
    int ret;
    while ((ret = mbedtls_ssl_handshake(&ssl)) == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_WANT_WRITE) {
    }
    if (ret != 0) {
      fprintf(stderr, "handshake: %s\n", describe(ret));
    } else {
      char head[8192];
      size_t len = 0;
      while (len < sizeof head - 1) {
        ret = mbedtls_ssl_read(&ssl, (unsigned char *)head + len, sizeof head - 1 - len);
        if (ret == MBEDTLS_ERR_SSL_WANT_READ || ret == MBEDTLS_ERR_SSL_RECEIVED_NEW_SESSION_TICKET) {
          continue;
        }
        if (ret <= 0) {
          break;
        }
        len += (size_t)ret;
        head[len] = '\0';
        if (strstr(head, "\r\n\r\n") != NULL) {
          break;
        }
      }
      const char *answer = "HTTP/1.1 200 OK\r\ncontent-length: 5\r\nconnection: close\r\n\r\nhello";
      mbedtls_ssl_write(&ssl, (const unsigned char *)answer, strlen(answer));
      mbedtls_ssl_close_notify(&ssl);
    }
    mbedtls_ssl_free(&ssl);
    close(fd);
  }
}
