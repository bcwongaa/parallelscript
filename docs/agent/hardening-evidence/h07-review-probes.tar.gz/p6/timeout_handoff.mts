// A timeout signal made in a `parallel` task and handed to the main loop: it must still
// abort with a TimeoutError, and the main loop's listener must run.
// Node's twin: `parallel e` as `Promise.resolve(e)`.
function make(ms: number): AbortSignal {
  return AbortSignal.timeout(ms);
}
const signals = await Promise.all([0, 1, 2, 3].map((i) => Promise.resolve(make(20 + i))));
const keepAlive = setTimeout(() => console.log("keep-alive timer fired first"), 2_000);
const reasons = await Promise.all(
  signals.map(
    (signal) =>
      new Promise<string>((resolve) => {
        if (signal.aborted) {
          resolve(`already ${(signal.reason as DOMException).name}`);
          return;
        }
        signal.addEventListener("abort", () => resolve((signal.reason as DOMException).name));
      }),
  ),
);
clearTimeout(keepAlive);
console.log(reasons.join(","));
