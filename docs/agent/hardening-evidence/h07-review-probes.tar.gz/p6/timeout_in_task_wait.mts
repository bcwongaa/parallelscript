// `parallel` tasks that each wait for their own AbortSignal.timeout while the main loop keeps
// the process alive with a ref'd timer: every task's signal must fire, as in Node.
// Node's twin: `parallel e` as `Promise.resolve(e)`.
async function waitOwnTimeout(ms: number): Promise<string> {
  const signal = AbortSignal.timeout(ms);
  await new Promise((resolve) => signal.addEventListener("abort", resolve));
  return (signal.reason as DOMException).name;
}
const keepAlive = setTimeout(() => console.log("keep-alive fired: some task's timeout never did"), 3_000);
const names = await Promise.all([0, 1, 2, 3, 4, 5, 6, 7].map((i) => Promise.resolve(waitOwnTimeout(20 + i))));
clearTimeout(keepAlive);
console.log(names.join(","));
