// Which handed-over timeout signals abort within a second, and does a plain ref'd timer a
// task leaves behind fire? Node's twin: `parallel e` as `Promise.resolve(e)`.
function make(ms: number): AbortSignal {
  return AbortSignal.timeout(ms);
}
let fired = 0;
function leaveTimer(): number {
  setTimeout(() => fired++, 20);
  return 0;
}
const signals = await Promise.all([0, 1, 2, 3, 4, 5, 6, 7].map((i) => Promise.resolve(make(20 + i))));
await Promise.all([0, 1, 2, 3, 4, 5, 6, 7].map(() => Promise.resolve(leaveTimer())));
await new Promise((resolve) => setTimeout(resolve, 1_000));
console.log("aborted:", signals.map((s) => (s.aborted ? "y" : "n")).join(""), "left timers fired:", fired);
