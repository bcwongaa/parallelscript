// Sequential Node oracle for c07-red-fetch-signals-par.pts: pts:http's serve is node:http's
// createServer; `range(0, n).par.map(f)` is `Array.from({ length: n }, (_, i) => f(i))` and
// `parallel loopTask(task)` is `loopTask(task)`. The program exits once the server closes,
// so AbortSignal.timeout's timers (unref'd in Node too) don't hold it.
import { createServer } from "node:http";

const server = createServer((_message, response) => {
    response.writeHead(200, { "content-type": "text/plain;charset=UTF-8" });
    response.end("ok");
});
await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
const base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;

// The body of a fetch of path, or how it failed.
function outcome(response: Promise<Response>): Promise<string> {
    return response.then((r) => r.text(), (error) => (error instanceof Error ? `${error.name}: ${error.message}` : "non-Error thrown"));
}

// Fetch i of a task, with one of three kinds of signal, each new: a controller's, a Request's
// own (following a controller's), or AbortSignal.timeout's on a loop (a pool worker can't start
// timers yet, SPEC §4) and AbortSignal.any's on the pool. A synchronous throw counts as a failure.
function fetchWithSignal(path: string, i: number, onLoop: boolean): Promise<string> {
    try {
        if (i % 3 === 0) {
            return outcome(fetch(`${base}${path}`, { signal: new AbortController().signal }));
        }
        if (i % 3 === 1) {
            const signal = onLoop ? AbortSignal.timeout(60_000) : AbortSignal.any([new AbortController().signal]);
            return outcome(fetch(`${base}${path}`, { signal }));
        }
        return outcome(fetch(new Request(`${base}${path}`, { signal: new AbortController().signal })));
    } catch (error) {
        return Promise.resolve(error instanceof Error ? `${error.name}: ${error.message}` : "non-Error thrown");
    }
}

// 200 fetches from a task on a loop, 20 at a time.
async function loopTask(task: number): Promise<string[]> {
    const texts: string[] = [];
    for (let batch = 0; batch < 10; batch++) {
        texts.push(...(await Promise.all(Array.from({ length: 20 }, (_, i) => fetchWithSignal(`/loop/${task}/${batch}`, i, true)))));
    }
    return texts;
}

const texts: string[] = [];
for (let round = 0; round < 4; round++) {
    texts.push(...(await Promise.all(Array.from({ length: 200 }, (_, i) => fetchWithSignal(`/pool/${round}`, i, false)))));
}
texts.push(...(await Promise.all([0, 1, 2, 3].map((task) => loopTask(task)))).flat());
server.closeAllConnections();
server.close();
const counts = new Map<string, number>();
for (const text of texts) {
    counts.set(text, (counts.get(text) ?? 0) + 1);
}
console.log([...counts.keys()].sort().map((text) => `${text}: ${counts.get(text)}`).join("\n"));
