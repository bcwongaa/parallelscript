// AbortSignal.timeout signals that actually fire, on the loops of several `parallel` tasks
// at once, each followed by AbortSignal.any and an onabort handler; every one must abort
// with a TimeoutError DOMException, its trusted event at its own target.
// Node's twin: `parallel e` as `Promise.resolve(e)`.
const PER_TASK = 300;

function waitAbort(signal: AbortSignal): Promise<string> {
  return new Promise((resolve) => {
    signal.addEventListener("abort", (event: Event) => {
      const reason = signal.reason;
      const ok = event.isTrusted && event.type === "abort" && event.target === signal &&
        reason instanceof DOMException && reason.name === "TimeoutError" && reason.code === 23;
      resolve(ok ? "ok" : `wrong ${String(reason)}`);
    });
  });
}

async function task(id: number): Promise<string[]> {
  const waits: Promise<string>[] = [];
  let handlers = 0;
  for (let i = 0; i < PER_TASK; i++) {
    const t = AbortSignal.timeout(1 + (i % 15));
    t.onabort = () => handlers++;
    const either = AbortSignal.any([new AbortController().signal, t]);
    waits.push(waitAbort(t), waitAbort(either));
  }
  // A ref'd timer keeps the loop alive: AbortSignal.timeout's own timers are unref'd.
  const keepAlive = setTimeout(() => {}, 5_000);
  const outcomes = await Promise.all(waits);
  clearTimeout(keepAlive);
  outcomes.push(handlers === PER_TASK ? "ok" : `handlers ${handlers}`);
  return outcomes;
}

function tally(outcomes: string[]): string {
  const counts = new Map<string, number>();
  for (const outcome of outcomes) {
    counts.set(outcome, (counts.get(outcome) ?? 0) + 1);
  }
  return [...counts.keys()].sort().map((outcome) => `${outcome} ${counts.get(outcome)}`).join(", ");
}

const results = await Promise.all([0, 1, 2, 3, 4, 5, 6, 7].map((id) => Promise.resolve(task(id))));
console.log("timeouts on task loops:", tally(results.flat()));
