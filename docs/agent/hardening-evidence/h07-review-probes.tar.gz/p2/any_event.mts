const t = AbortSignal.timeout(5);
const c = new AbortController();
const either = AbortSignal.any([c.signal, t]);
either.addEventListener("abort", (event) => {
  console.log("either", event.isTrusted, event.type, event.target === either, event.currentTarget === either, either.reason === t.reason, (either.reason as any)?.name);
});
t.addEventListener("abort", (event) => {
  console.log("t", event.isTrusted, event.type, event.target === t, event.currentTarget === t);
});
const c2 = new AbortController();
const e2 = AbortSignal.any([c2.signal]);
e2.addEventListener("abort", (event) => console.log("e2 from controller", event.isTrusted));
c2.abort();
setTimeout(() => {}, 50);
