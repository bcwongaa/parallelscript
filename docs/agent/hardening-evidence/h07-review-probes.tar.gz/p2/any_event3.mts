function probe(label: string, s: AbortSignal) {
  s.addEventListener("abort", (event: Event) => {
    console.log(label, event.target === s, event.currentTarget === s, event.currentTarget === null, typeof event.currentTarget);
  });
}
const a = AbortSignal.timeout(3);
probe("timeout plain", a);
const b = AbortSignal.timeout(3);
b.onabort = () => {};
probe("timeout onabort", b);
const c = AbortSignal.timeout(3);
AbortSignal.any([c]);
probe("timeout followed", c);
const d = new AbortController();
probe("controller", d.signal);
d.abort();
const e = new AbortController();
e.signal.onabort = () => {};
probe("controller onabort", e.signal);
e.abort();
setTimeout(() => {}, 50);
