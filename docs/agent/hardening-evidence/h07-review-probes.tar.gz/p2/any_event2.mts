const t = AbortSignal.timeout(3);
t.onabort = () => {};
const either = AbortSignal.any([new AbortController().signal, t]);
for (const s of [t, either]) {
  s.addEventListener("abort", (event: Event) => {
    const reason: any = s.reason;
    console.log(s === t ? "t" : "either", event.isTrusted, event.type === "abort", event.target === s, event.currentTarget === s, reason instanceof DOMException, reason.name, reason.code);
  });
}
setTimeout(() => {}, 50);
