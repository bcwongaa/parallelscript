// A listener that throws while a `.map` callback aborts its own controller: dispatch
// goes on to the next listener and the error is reported as uncaught (queueMicrotask), as
// Node reports it. Node's twin: `.map(f)` as `.map(f)`.
const range = (a: number, b: number) => Array.from({ length: b - a }, (_, i) => a + i);

const results = range(0, 4).map((i) => {
  const controller = new AbortController();
  let after = false;
  controller.signal.addEventListener("abort", () => {
    throw new Error(`boom ${i}`);
  });
  controller.signal.addEventListener("abort", () => {
    after = true;
  });
  controller.abort();
  return controller.signal.aborted && after ? "ok" : "wrong";
});
console.log(results.join(","));
