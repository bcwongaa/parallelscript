// Forging attempts and the observable surface of AbortSignal's constructor, typed paths.
function attempt(label: string, make: () => AbortSignal): void {
  try {
    const made = make();
    console.log(label, "constructed", made instanceof AbortSignal);
  } catch (error) {
    console.log(label, error instanceof TypeError, error instanceof Error ? `${error.name}: ${error.message}` : String(error));
  }
}
const anyKey: any = {};
attempt("no args", () => new AbortSignal());
// @ts-ignore: Node's types take no argument
attempt("ts-ignore {}", () => new AbortSignal({}));
// @ts-ignore
attempt("ts-ignore any", () => new AbortSignal(anyKey));
// @ts-ignore
attempt("ts-ignore undefined", () => new AbortSignal(undefined));
class Sub extends AbortSignal {
  constructor() {
    super();
  }
}
attempt("subclass", () => new Sub());
class Sub2 extends AbortSignal {
  constructor(k: any) {
    // @ts-ignore
    super(k);
  }
}
attempt("subclass with any key", () => new Sub2({}));
const viaStatic = AbortSignal.abort("r");
console.log("static abort instanceof", viaStatic instanceof AbortSignal, viaStatic instanceof EventTarget, viaStatic.reason);
const t = AbortSignal.timeout(10);
console.log("timeout", t instanceof AbortSignal, t.aborted);
const a = AbortSignal.any([viaStatic]);
console.log("any", a instanceof AbortSignal, a.aborted, a.reason);
console.log(new AbortController().signal);
console.log(AbortSignal.abort("why"));
try {
  new AbortSignal();
} catch (error) {
  console.log(error);
}
