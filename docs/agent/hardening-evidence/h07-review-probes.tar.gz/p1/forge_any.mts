// Forging attempts and observable surface of AbortSignal's constructor.
function attempt(label: string, make: () => unknown): void {
  try {
    const made = make();
    console.log(label, "constructed", made instanceof AbortSignal);
  } catch (error) {
    console.log(label, error instanceof TypeError, error instanceof Error ? `${error.name}: ${error.message}` : String(error));
  }
}
const Ctor: any = AbortSignal;
attempt("no args", () => new AbortSignal());
attempt("any, no args", () => new Ctor());
attempt("any, {}", () => new Ctor({}));
attempt("any, undefined", () => new Ctor(undefined));
attempt("any, null", () => new Ctor(null));
attempt("any, 1", () => new Ctor(1));
attempt("any, string", () => new Ctor("key"));
attempt("any, a signal", () => new Ctor(AbortSignal.abort()));
attempt("any, a controller", () => new Ctor(new AbortController()));
attempt("any, two args", () => new Ctor({}, {}));
class Sub extends AbortSignal {
  constructor() {
    super();
  }
}
attempt("subclass", () => new Sub());
const viaStatic = AbortSignal.abort("r");
console.log("static abort instanceof", viaStatic instanceof AbortSignal, viaStatic instanceof EventTarget, viaStatic.reason);
const t = AbortSignal.timeout(10);
console.log("timeout", t instanceof AbortSignal, t.aborted);
const a = AbortSignal.any([viaStatic]);
console.log("any", a instanceof AbortSignal, a.aborted, a.reason);
console.log(new AbortController().signal);
console.log(AbortSignal.abort("why"));
console.log(typeof AbortSignal, AbortSignal.name);
