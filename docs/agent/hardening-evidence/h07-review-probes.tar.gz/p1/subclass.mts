// Subclasses: an implicit constructor passes the program's arguments on, never the key; a
// subclass of AbortController still gets a real signal.
class Quiet extends AbortSignal {}
for (const make of [() => new Quiet(), () => new Quiet()]) {
  try {
    make();
    console.log("constructed");
  } catch (error) {
    console.log(error instanceof TypeError ? `TypeError: ${(error as Error).message}` : "other");
  }
}
class Mine extends AbortController {
  tag = "mine";
}
const mine = new Mine();
mine.abort("why");
console.log(mine.tag, mine.signal instanceof AbortSignal, mine.signal.aborted, mine.signal.reason);
