// Builds a .pts program with the ThreadSanitizer runtime profile (review probe; not repo code).
package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	ctx := context.Background()
	source, exe := os.Args[1], os.Args[2]
	c, err := driver.EmitC(ctx, source)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	tc, err := toolchain.New()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	rt, err := tc.Runtime(ctx, toolchain.ThreadSanitize)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cFile := exe + ".c"
	if err := os.WriteFile(cFile, []byte(c), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := tc.CompileProgram(ctx, rt, []string{cFile}, exe); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
