// AbortSignal.any's follower: when does it abort relative to its source's own listeners?
const c = new AbortController();
const f = AbortSignal.any([c.signal]);
f.addEventListener("abort", () => console.log("follower's listener; source aborted:", c.signal.aborted));
c.signal.addEventListener("abort", () => console.log("source's listener; follower aborted:", f.aborted));
c.abort();
// A follower made after the source's listener was added.
const c2 = new AbortController();
c2.signal.addEventListener("abort", () => console.log("source2's listener; follower2 aborted:", f2.aborted));
const f2 = AbortSignal.any([c2.signal]);
f2.addEventListener("abort", () => console.log("follower2's listener"));
c2.abort();
