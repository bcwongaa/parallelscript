import subprocess, sys, os, urllib.request, collections, concurrent.futures, http.client
exe, threads, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
p = subprocess.Popen([exe], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, PTS_THREADS=threads), text=True)
port = int(p.stdout.readline().split()[1])
def one(i):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    c.request("GET", f"/t/{i}")
    body = c.getresponse().read().decode()
    c.close()
    return body
with concurrent.futures.ThreadPoolExecutor(64) as ex:
    bodies = list(ex.map(one, range(n)))
c = http.client.HTTPConnection("127.0.0.1", port, timeout=10); c.request("GET", "/stop"); c.getresponse().read()
out, err = p.communicate(timeout=15)
print(f"threads={threads} {dict(collections.Counter(bodies))} exit={p.returncode} stderr={err.strip()[:200]!r}")
