# Opens N held connections, waits until all arrived, then GET /stop (stop(true)) and counts the "aborted" lines.
import socket, subprocess, sys, time, os, urllib.request, collections
exe, threads, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
p = subprocess.Popen([exe], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, PTS_THREADS=threads), text=True)
port = int(p.stdout.readline().split()[1])
def get(path):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=10) as r:
        return r.read().decode()
socks = []
for i in range(n):
    s = socket.create_connection(("127.0.0.1", port))
    s.sendall(f"GET /hold/{i} HTTP/1.1\r\nHost: x\r\n\r\n".encode())
    socks.append(s)
deadline = time.time() + 10
while time.time() < deadline and int(get("/count").split()[0]) < n:
    time.sleep(0.02)
arrived = get("/count")
try:
    stop = get("/stop")
except Exception as e:
    stop = f"failed {e}"
try:
    out, err = p.communicate(timeout=15)
except subprocess.TimeoutExpired:
    p.kill(); out, err = p.communicate(); print("server hung")
print(f"threads={threads} arrived={arrived} stop={stop!r} lines={dict(collections.Counter(out.splitlines()))} exit={p.returncode} stderr={err.strip()[:200]!r}")
