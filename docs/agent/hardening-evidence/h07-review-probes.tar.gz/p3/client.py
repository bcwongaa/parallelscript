# Opens N held connections to the server, waits until all arrived, closes them (or asks stop(true)),
# then checks the server's atomic counts.
import socket, subprocess, sys, time, os, urllib.request
exe, threads, n, mode = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
env = dict(os.environ, PTS_THREADS=threads)
p = subprocess.Popen([exe], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, text=True)
line = p.stdout.readline().split()
port = int(line[1])
def get(path):
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=10) as r:
        return r.read().decode()
socks = []
for i in range(n):
    s = socket.create_connection(("127.0.0.1", port))
    s.sendall(f"GET /hold/{i} HTTP/1.1\r\nHost: x\r\n\r\n".encode())
    socks.append(s)
deadline = time.time() + 10
while time.time() < deadline:
    counts = get("/count").split()
    if int(counts[0]) >= n:
        break
    time.sleep(0.02)
arrived_counts = get("/count")
result = None
if mode == "close":
    for s in socks:
        s.close()
    deadline = time.time() + 10
    while time.time() < deadline:
        counts = get("/count").split()
        if int(counts[1]) + int(counts[2]) >= n:
            break
        time.sleep(0.02)
    result = get("/count")
    get("/stop")
else:
    # stop(true): the held connections close, their signals abort
    try:
        get("/stop")
    except Exception as e:
        print("stop failed", e)
try:
    out, err = p.communicate(timeout=15)
except subprocess.TimeoutExpired:
    p.kill(); out, err = p.communicate()
    print("server hung")
print(f"threads={threads} mode={mode} arrived={arrived_counts} final={result} exit={p.returncode} stderr={err.strip()[:300]!r}")
