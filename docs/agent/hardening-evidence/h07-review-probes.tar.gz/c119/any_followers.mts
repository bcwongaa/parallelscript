// Cost of N AbortSignal.any followers of one long-lived signal (C119), then one abort.
const N = Number(process.argv[2] ?? "40000");
const shared = new AbortController();
const started = performance.now();
const followers: AbortSignal[] = [];
for (let i = 0; i < N; i++) {
  followers.push(AbortSignal.any([shared.signal]));
}
const made = performance.now();
shared.abort("stop");
let aborted = 0;
for (const f of followers) {
  if (f.aborted) aborted++;
}
console.log(`followers ${N}: made in ${Math.round(made - started)} ms, aborted ${aborted} in ${Math.round(performance.now() - made)} ms`);
