// Cost of N Requests following one long-lived signal (the parent's C119 measurement), then one abort.
const N = Number(process.argv[2] ?? "40000");
const shared = new AbortController();
const started = performance.now();
const requests: Request[] = [];
for (let i = 0; i < N; i++) {
  requests.push(new Request("http://127.0.0.1/", { signal: shared.signal }));
}
const made = performance.now();
shared.abort("stop");
let aborted = 0;
for (const r of requests) {
  if (r.signal.aborted) aborted++;
}
console.log(`requests ${N}: made in ${Math.round(made - started)} ms, aborted ${aborted} in ${Math.round(performance.now() - made)} ms`);
