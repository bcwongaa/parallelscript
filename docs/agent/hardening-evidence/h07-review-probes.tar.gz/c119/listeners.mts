// Cost of N distinct addEventListener calls on one signal, then one abort.
const N = Number(process.argv[2] ?? "40000");
const shared = new AbortController();
const started = performance.now();
let calls = 0;
for (let i = 0; i < N; i++) {
  shared.signal.addEventListener("abort", () => { calls++; });
}
const made = performance.now();
shared.abort("stop");
console.log(`listeners ${N}: added in ${Math.round(made - started)} ms, called ${calls} in ${Math.round(performance.now() - made)} ms`);
