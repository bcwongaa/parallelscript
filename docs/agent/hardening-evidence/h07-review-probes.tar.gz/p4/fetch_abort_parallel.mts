// Fetches to a server that holds them, each with a signal of its own, aborted mid-flight:
// controllers made in `.map` callbacks and aborted from the main loop afterwards; and in
// `parallel` tasks, controllers aborted by a timer on the task's loop and AbortSignal.timeout
// signals firing there. Every fetch must reject with its signal's reason.
// Node's twin: `.map` as `.map`, `parallel e` as `Promise.resolve(e)`.
import { createServer } from "node:http";
const range = (a: number, b: number) => Array.from({ length: b - a }, (_, i) => a + i);

const held: (() => void)[] = [];
const server = createServer((req, res) => { held.push(() => res.end("late")); });
await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
const base = `http://127.0.0.1:${(server.address() as any).port}`;

function tally(outcomes: string[]): string {
  const counts = new Map<string, number>();
  for (const outcome of outcomes) {
    counts.set(outcome, (counts.get(outcome) ?? 0) + 1);
  }
  return [...counts.keys()].sort().map((outcome) => `${outcome} ${counts.get(outcome)}`).join(", ");
}

function settle(response: Promise<Response>, signal: AbortSignal): Promise<string> {
  return response.then(
    (r) => `fulfilled ${r.status}`,
    (error) => (error === signal.reason ? `rejected with reason ${error instanceof DOMException ? error.name : String(error)}` : `rejected otherwise ${String(error)}`),
  );
}

// From pool threads: each callback makes a controller and starts a fetch; the main loop aborts them all later.
const started = range(0, 200).map((i) => {
  const controller = new AbortController();
  return { controller, outcome: settle(fetch(`${base}/pool/${i}`, { signal: controller.signal }), controller.signal) };
});
await new Promise((resolve) => setTimeout(resolve, 200));
for (const { controller } of started) {
  controller.abort();
}
console.log("from .map, aborted later:", tally(await Promise.all(started.map((s) => s.outcome))));

async function task(id: number): Promise<string[]> {
  const outcomes: Promise<string>[] = [];
  for (let i = 0; i < 50; i++) {
    const controller = new AbortController();
    outcomes.push(settle(fetch(`${base}/task/${id}/${i}`, { signal: controller.signal }), controller.signal));
    setTimeout(() => controller.abort(new Error("timer")), 100 + (i % 10));
    const timeout = AbortSignal.timeout(100 + (i % 10));
    outcomes.push(settle(fetch(`${base}/timeout/${id}/${i}`, { signal: timeout }), timeout));
  }
  return Promise.all(outcomes);
}
const looped = await Promise.all([0, 1, 2, 3].map((id) => Promise.resolve(task(id))));
console.log("from parallel tasks:", tally(looped.flat()));
server.closeAllConnections(); server.close();
for (const release of held) {
  release();
}
