function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
function arm(): Promise<string> {
  return new Promise((resolve) => {
    const order: string[] = [];
    setTimeout(() => {
      setTimeout(() => {
        order.push("timeout");
        if (order.length === 2) resolve(order.join(","));
      }, 1);
      setImmediate(() => {
        order.push("immediate");
        if (order.length === 2) resolve(order.join(","));
      });
      spin(5);
    }, 20).unref();
  });
}
const hold = setTimeout(() => {}, 10_000);
const p = await Promise.all([Promise.resolve(arm())]);
const order = await p[0];
clearTimeout(hold);
console.log(order);
