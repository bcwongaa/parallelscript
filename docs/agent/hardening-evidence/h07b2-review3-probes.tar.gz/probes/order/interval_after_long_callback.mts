// A 10 ms interval due with a callback that works 50 ms just before it: Node counts the
// interval's next tick from just before its own callback ran, so the second tick comes about
// 10 ms after the first.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
setTimeout(() => spin(50), 10);
const ticks: number[] = [];
const interval = setInterval(() => {
  ticks.push(performance.now());
  if (ticks.length === 2) {
    clearInterval(interval);
    const gap = ticks[1] - ticks[0];
    console.log("gap between the first two ticks:", gap >= 8 ? "about 10 ms" : `${Math.round(gap)} ms`);
  }
}, 10);
