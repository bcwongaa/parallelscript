// As interval_after_long_callback, but the interval's first tick also sets (and clears) a
// timer, which reads the loop's time afresh. Node: the second tick comes about 10 ms after the
// first, since an interval counts from just before its callback runs.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
setTimeout(() => spin(50), 10);
const ticks: number[] = [];
const interval = setInterval(() => {
  ticks.push(performance.now());
  clearTimeout(setTimeout(() => {}, 1000));
  if (ticks.length === 2) {
    clearInterval(interval);
    const gap = ticks[1] - ticks[0];
    console.log("gap between the first two ticks:", gap >= 8 ? "about 10 ms" : `${Math.round(gap)} ms`);
  }
}, 10);
