#include <stdio.h>
#include <time.h>
int main(void){struct timespec t; clock_getres(CLOCK_MONOTONIC_COARSE,&t); printf("coarse res %ld.%09ld\n",(long)t.tv_sec,t.tv_nsec); clock_getres(CLOCK_MONOTONIC,&t); printf("mono res %ld.%09ld\n",(long)t.tv_sec,t.tv_nsec); return 0;}
