// A task's unref'd interval, ref'd from the main thread (it then keeps the program running
// and ticks), unref'd again (the program then ends at once, with the interval left).
const ticks = { n: 0 };
function start(): ReturnType<typeof setInterval> {
  const interval = setInterval(() => { ticks.n++; }, 5);
  interval.unref();
  return interval;
}
const hold = setTimeout(() => {}, 10_000);
const interval = await Promise.resolve(start());
interval.ref();
clearTimeout(hold); // only the task's interval is referenced now
console.log("hasRef after ref:", interval.hasRef());
await new Promise<void>((resolve) => {
  const poll = setInterval(() => {
    if (ticks.n >= 10) {
      clearInterval(poll);
      resolve();
    }
  }, 1);
  poll.unref(); // the interval on the other loop keeps the program running
});
interval.unref();
console.log("hasRef after unref:", interval.hasRef(), "ticked at least 10:", ticks.n >= 10);
