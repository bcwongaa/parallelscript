// The program's first turn: top-level code sets timers and immediates (Node's first
// iteration starts with the timers due by then).
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
const order: string[] = [];
setTimeout(() => {
  order.push("A");
  setImmediate(() => order.push("C"));
  setTimeout(() => order.push("D"), 0);
  spin(5);
}, 0);
setImmediate(() => order.push("B"));
setTimeout(() => order.push("E"), 3);
spin(5);
setTimeout(() => console.log("first turn:", order.join(",")), 50);
