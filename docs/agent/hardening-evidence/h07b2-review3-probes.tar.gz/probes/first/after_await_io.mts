// After `await parallel x` (the continuation runs from the loop's inbox, like code after
// I/O), code sets a 0 ms timer and an immediate, then works 5 ms.
function spin(ms: number): number {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
  return ms;
}
import { readFile } from "node:fs/promises";
await readFile("/etc/hostname");
const order: string[] = [];
setTimeout(() => order.push("timeout"), 0);
setImmediate(() => order.push("immediate"));
spin(5);
setTimeout(() => console.log("after await parallel:", order.join(",")), 50);
