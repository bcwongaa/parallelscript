// Interval behaviours Node makes deterministic, each in turn.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
type Scenario = [string, (log: (s: string) => void, done: () => void) => void];
const scenarios: Scenario[] = [
  ["clearInterval in its own callback", (log, done) => {
    let n = 0;
    const i = setInterval(() => { log("I" + ++n); if (n === 2) clearInterval(i); }, 5);
    setTimeout(() => { log("T"); done(); }, 40);
  }],
  ["refresh in its own callback", (log, done) => {
    let n = 0;
    const t0 = performance.now();
    const i = setInterval(() => { n++; i.refresh(); if (n === 3) { clearInterval(i); const per = (performance.now() - t0) / 3; log(per >= 9 ? "period about 10" : `period ${Math.round(per)}`); done(); } }, 10);
  }],
  ["a long callback: next tick counts from its start", (log, done) => {
    let n = 0;
    const ticks: number[] = [];
    const i = setInterval(() => { ticks.push(performance.now()); n++; if (n === 1) spin(25); if (n === 2) { clearInterval(i); const gap = ticks[1] - ticks[0]; log(gap >= 24 && gap < 35 ? "gap = the callback's 25 ms" : `gap ${Math.round(gap)}`); done(); } }, 10);
  }],
  ["two intervals, the first long", (log, done) => {
    let a = 0, b = 0;
    const ia = setInterval(() => { a++; log("A" + a); if (a === 1) spin(15); if (a === 3) clearInterval(ia); }, 10);
    const ib = setInterval(() => { b++; log("B" + b); if (b === 3) { clearInterval(ib); setTimeout(() => done(), 30); } }, 10);
  }],
  ["interval and timeout of the same delay (racy in Node)", (log, done) => {
    let n = 0;
    const i = setInterval(() => { log("I" + ++n); if (n === 2) clearInterval(i); }, 10);
    setTimeout(() => log("T10"), 10);
    setTimeout(() => log("T20"), 20);
    setTimeout(() => done(), 40);
  }],
  ["clearInterval from a timeout due at the same time", (log, done) => {
    let n = 0;
    const i = setInterval(() => { log("I" + ++n); }, 10);
    setTimeout(() => { clearInterval(i); log("cleared"); }, 20);
    setTimeout(() => done(), 50);
  }],
];
for (const [name, run] of scenarios) {
  const order: string[] = [];
  await new Promise<void>((resolve) => run((s) => { order.push(s); }, () => resolve()));
  console.log(`${name}: ${order.join(",")}`);
}
