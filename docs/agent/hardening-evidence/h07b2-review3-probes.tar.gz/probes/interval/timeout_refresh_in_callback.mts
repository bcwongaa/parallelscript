// refresh() of a setTimeout inside its own callback: Node's docs say refresh on a timer that
// has called its callback reactivates it, so it fires again.
let n = 0;
const t = setTimeout(() => {
  n++;
  if (n < 3) t.refresh();
}, 5);
setTimeout(() => console.log("fired", n, "times"), 100);
