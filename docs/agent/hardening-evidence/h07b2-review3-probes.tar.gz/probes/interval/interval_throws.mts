// A task's unref'd interval throws on its third tick while its loop sleeps and the main
// loop's timer keeps the program running: the program ends with the uncaught error.
const ticks = { n: 0 };
function arm(): number {
  setInterval(() => {
    ticks.n++;
    if (ticks.n === 3) throw new RangeError("thrown by an interval's third tick");
  }, 5).unref();
  return 1;
}
const hold = setTimeout(() => {}, 10_000);
console.log(await Promise.resolve(arm()));
setTimeout(() => console.log("the main loop's timer fired first"), 2_000);
clearTimeout(hold);
