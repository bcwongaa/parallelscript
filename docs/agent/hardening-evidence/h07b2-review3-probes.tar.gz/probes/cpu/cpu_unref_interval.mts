// 3 tasks each leave a 1 ms unref'd interval on their loop; the main loop holds the program 2 s.
const ticks = [{ n: 0 }, { n: 0 }, { n: 0 }];
function start(i: number): string {
  setInterval(() => { ticks[i].n++; }, 1).unref();
  return "ok";
}
const hold = setTimeout(() => {}, 10_000);
await Promise.all([0, 1, 2].map((i) => Promise.resolve(start(i))));
clearTimeout(hold);
await new Promise((resolve) => setTimeout(resolve, 2000));
console.log("ticks", ticks[0].n + ticks[1].n + ticks[2].n);
