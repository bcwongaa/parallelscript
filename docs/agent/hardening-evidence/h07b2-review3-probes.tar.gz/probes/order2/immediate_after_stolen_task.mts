// The main loop has an unref'd 10 ms timer and nothing referenced, so it takes (steals) the
// second of two tasks queued on the other loop and works 40 ms in it; its timer comes due
// meanwhile. The timer's callback sets a 1 ms timer, then an immediate, then works 5 ms.
// Node (the sequential twin: the timer's callback runs in the timers phase): the immediate
// runs before the 1 ms timer.
function spin(ms: number): number {
  const end = performance.now() + ms;
  let n = 0;
  while (performance.now() < end) n++;
  return n > 0 ? ms : 0;
}
const order: string[] = [];
let done: () => void = () => {};
const both = new Promise<void>((resolve) => { done = () => resolve(); });
setTimeout(() => {
  setTimeout(() => { order.push("timeout"); if (order.length === 2) done(); }, 1);
  setImmediate(() => { order.push("immediate"); if (order.length === 2) done(); });
  spin(5);
}, 10).unref();
const first = Promise.resolve(spin(200));
const second = Promise.resolve(spin(40));
await Promise.all([first, second]);
await both;
console.log(order.join(","));
