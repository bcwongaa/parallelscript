// A task sets a referenced 1 ms timer A and works 3 ms. A's callback sets a 1 ms timer C,
// then an immediate D, then works 5 ms. A runs in a timers phase, so Node runs D before C
// (the check phase comes before the next timers phase); the sequential twin shows it.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
function task(): Promise<string> {
  return new Promise((resolve) => {
    const order: string[] = [];
    setTimeout(() => {
      setTimeout(() => { order.push("timeout"); if (order.length === 2) resolve(order.join(",")); }, 1);
      setImmediate(() => { order.push("immediate"); if (order.length === 2) resolve(order.join(",")); });
      spin(5);
    }, 1);
    spin(3);
  });
}
console.log(await Promise.resolve(task()));
