// A task's unref'd timer throws while its loop sleeps and the main loop's timer keeps the
// program running: the program ends with the uncaught error (exit 1), not after the main timer.
function arm(): number {
  setTimeout(() => {
    throw new TypeError("thrown by a task's unref'd timer");
  }, 20).unref();
  return 1;
}
const hold = setTimeout(() => {}, 10_000);
console.log(await Promise.resolve(arm()));
setTimeout(() => console.log("the main loop's timer fired first"), 1_000);
clearTimeout(hold);
