// The same with an unhandled rejection made in the unref'd timer's callback.
function arm(): number {
  setTimeout(() => {
    void Promise.reject(new RangeError("rejected in a task's unref'd timer"));
  }, 20).unref();
  return 1;
}
const hold = setTimeout(() => {}, 10_000);
console.log(await Promise.resolve(arm()));
setTimeout(() => console.log("the main loop's timer fired first"), 1_000);
clearTimeout(hold);
