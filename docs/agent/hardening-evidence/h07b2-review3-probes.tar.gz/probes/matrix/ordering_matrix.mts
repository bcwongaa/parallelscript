// Timer orderings that Node makes deterministic, each scenario run in turn; prints each order.
function spin(ms: number): void {
  const end = performance.now() + ms;
  while (performance.now() < end) {}
}
type Scenario = [string, (log: (s: string) => void) => void];
const scenarios: Scenario[] = [
  ["same delay, set apart", (log) => { setTimeout(() => log("A"), 5); spin(3); setTimeout(() => log("B"), 5); }],
  ["shorter set after work", (log) => { setTimeout(() => log("A"), 3); spin(10); setTimeout(() => log("B"), 1); }],
  ["timeout vs immediate in a timer callback", (log) => { setTimeout(() => { setTimeout(() => log("T"), 0); setImmediate(() => log("I")); }, 1); }],
  ["timeout vs immediate in a timer callback, then work", (log) => { setTimeout(() => { setTimeout(() => log("T"), 0); setImmediate(() => log("I")); spin(5); }, 1); }],
  ["timeout vs immediate in an immediate", (log) => { setImmediate(() => { setTimeout(() => log("T"), 0); setImmediate(() => log("I")); spin(5); }); }],
  ["new timer in a callback vs an overdue one", (log) => { setTimeout(() => { spin(15); setTimeout(() => log("C"), 5); }, 10); setTimeout(() => log("B"), 20); }],
  ["Node's lists: a later timer of an earlier list", (log) => { setTimeout(() => log("A"), 10); spin(6); setTimeout(() => log("B"), 10); setTimeout(() => log("C"), 5); spin(14); }],
  ["refresh after work", (log) => { const t = setTimeout(() => log("R"), 10); setTimeout(() => log("S"), 15); spin(8); t.refresh(); }],
  ["interval vs timeout", (log) => { let n = 0; const i = setInterval(() => { log("I" + ++n); if (n === 3) clearInterval(i); }, 10); setTimeout(() => log("T"), 25); }],
  ["interval after a long callback, with a timer set", (log) => { setTimeout(() => spin(50), 10); let n = 0; const i = setInterval(() => { n++; clearTimeout(setTimeout(() => {}, 1000)); log("I" + n); if (n === 2) clearInterval(i); }, 10); setTimeout(() => log("T"), 65); }],
  ["microtasks between timers", (log) => { setTimeout(() => { log("A"); void Promise.resolve().then(() => log("a")); }, 1); setTimeout(() => log("B"), 1); }],
];
for (const [name, run] of scenarios) {
  const order: string[] = [];
  await new Promise<void>((resolve) => {
    run((s) => order.push(s));
    setTimeout(resolve, 150);
  });
  console.log(`${name}: ${order.join(",")}`);
}
