#!/bin/bash
# loop.sh <bin> <threads> <reps> <expected-stdout>: counts runs whose stdout differs or exit != 0, or time out (20 s)
bin=$1; t=$2; n=$3; exp=$4; bad=0; slow=0; maxms=0
for r in $(seq 1 $n); do
  s=$(date +%s%N); out=$(PTS_THREADS=$t timeout 20 $bin 2>&1); code=$?; ms=$(( ($(date +%s%N)-s)/1000000 ))
  [ $ms -gt $maxms ] && maxms=$ms
  if [ "$out" != "$exp" ] || [ $code != 0 ]; then bad=$((bad+1)); echo "  bad r$r exit=$code ${ms}ms: $(echo "$out" | head -3 | tr '\n' '|')"; fi
done
echo "$(basename $bin) t$t: $bad/$n bad, max ${maxms}ms"
