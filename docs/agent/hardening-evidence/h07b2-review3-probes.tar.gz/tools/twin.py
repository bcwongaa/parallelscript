import re, sys
# twin.py <src.pts> <out.mts>: `parallel f(args)` -> `Promise.resolve(f(args))` (balanced parentheses)
src = open(sys.argv[1]).read()
out, i = [], 0
pat = re.compile(r'\bparallel (?=[A-Za-z_][\w.]*\()')
while True:
    m = pat.search(src, i)
    if not m:
        out.append(src[i:]); break
    out.append(src[i:m.start()]); j = src.index('(', m.end()); depth = 0; k = j
    while True:
        if src[k] == '(': depth += 1
        elif src[k] == ')':
            depth -= 1
            if depth == 0: break
        k += 1
    out.append('Promise.resolve(' + src[m.end():k+1] + ')'); i = k + 1
open(sys.argv[2], 'w').write(''.join(out))
