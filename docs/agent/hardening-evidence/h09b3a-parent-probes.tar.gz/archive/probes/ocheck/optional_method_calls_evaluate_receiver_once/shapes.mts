export function area(side: number): number {
  return side * side;
}
