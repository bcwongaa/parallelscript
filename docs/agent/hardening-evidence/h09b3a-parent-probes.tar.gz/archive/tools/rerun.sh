#!/bin/bash
# rerun.sh OUTDIR PROBE... : for each probe, Node, the previous snapshot's CLI (PREV, PREV_HOME) and the
# current CLI (CUR, CUR_HOME); prints per probe: node match of CUR, and whether CUR changed from PREV.
out=$1; shift
export PATH=$HOME/.local/node/bin:$PATH
mkdir -p "$out"
for f in "$@"; do
  b=$(basename "$f" .pts)
  d=$(mktemp -d /tmp/h09b3/rerun/run.XXXX)
  cp "$f" "$d/$b.pts"; cp "$f" "$d/$b.mts"
  (cd "$d" && TZ=America/New_York timeout 60 node --no-warnings --experimental-transform-types "$b.mts" > node.txt 2>&1; echo "[exit $?]" >> node.txt)
  (cd "$d" && PTS_HOME=$PREV_HOME timeout 300 $PREV run "$b.pts" 2>&1 | grep -v '^PTS-FALLBACK' > prev.txt; echo "[exit ${PIPESTATUS[0]}]" >> prev.txt)
  (cd "$d" && PTS_HOME=$CUR_HOME timeout 300 $CUR run "$b.pts" > cur.txt 2>&1; echo "[exit $?]" >> cur.txt)
  sed -i "s#$d/##g" "$d"/*.txt
  n=OK; cmp -s "$d/node.txt" "$d/cur.txt" || n=DIFF
  c=SAME; cmp -s "$d/prev.txt" "$d/cur.txt" || c=CHANGED
  echo "$n $c $f"
  mkdir -p "$out/$b"; cp "$d"/*.txt "$out/$b/"
  rm -rf "$d"
done
