#!/bin/bash
# count.sh TEST FN... : builds the main tree's run test TEST with the current CLI and prints how
# often the functions FN (erased copies) run, via gdb hit counts.
t=$1; shift
cp /home/bryan/projects/parallelscript/pts/tests/run/$t.pts .
PTS_HOME=/home/bryan/projects/parallelscript /home/bryan/projects/parallelscript/pts-bin/pts build $t.pts -o new_$t >/dev/null 2>&1 || echo "new build failed"
{
  echo "set pagination off"
  echo "set breakpoint pending on"
  for fn in "$@"; do echo "break $fn"; done
  echo "python"
  echo "import gdb"
  echo "for bp in gdb.breakpoints():"
  echo "    bp.silent = True"
  echo "    bp.commands = 'continue'"
  echo "end"
  echo "run > /dev/null"
  echo "python"
  echo "for bp in gdb.breakpoints():"
  echo "    print('HIT', bp.location, bp.hit_count)"
  echo "end"
} > cmds.gdb
echo "== $t"
gdb -q -batch -x cmds.gdb ./new_$t 2>&1 | grep "^HIT"
