package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) < 4 {
		fmt.Fprintln(os.Stderr, "usage: emit <all|default|compile> <entry-or-C> <output-C-or-native> [native]")
		os.Exit(2)
	}
	ctx := context.Background()
	mode, input, output := os.Args[1], os.Args[2], os.Args[3]
	if mode == "compile" {
		must(compile(ctx, input, output))
		return
	}
	var code string
	var err error
	switch mode {
	case "all":
		code, err = driver.EmitCWith(ctx, input, lower.AllInstances)
	case "default":
		code, err = driver.EmitC(ctx, input)
	default:
		fmt.Fprintln(os.Stderr, "invalid mode", mode)
		os.Exit(2)
	}
	must(err)
	must(os.WriteFile(output, []byte(code), 0600))
	if len(os.Args) == 5 {
		must(compile(ctx, output, os.Args[4]))
	}
}

func compile(ctx context.Context, code, output string) error {
	tc, err := toolchain.New()
	if err != nil {
		return err
	}
	rt, err := tc.Runtime(ctx, toolchain.Release)
	if err != nil {
		return err
	}
	return tc.CompileProgram(ctx, rt, []string{code}, output)
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
