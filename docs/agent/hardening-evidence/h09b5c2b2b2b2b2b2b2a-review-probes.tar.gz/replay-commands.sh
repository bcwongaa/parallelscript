#!/usr/bin/env bash
# Run only after the parent suite releases its exclusive execution window.
# Requires the exact-base archive already materialized under this scratch root.
set -u
root=/tmp/d215-review-nrhgYUTC
go=/home/bryan/.local/go/bin/go
export GOMAXPROCS=1 PTS_HOME=/home/bryan/projects/parallelscript PTS_THREADS=1

# Expected precision RED; retain and print its real exit status.
"$go" -C "$root/base" test -p=1 -parallel=1 -count=1 -timeout=12m \
  -overlay="$root/base_overlay.json" -json ./pts/lower ./pts/driver \
  -run '^TestD215Review' > "$root/replay-base-probes.jsonl" 2> "$root/replay-base-probes.stderr"
base_rc=$?
printf 'base expected-RED exit=%s\n' "$base_rc"

"$go" -C "$root/base" test -p=1 -parallel=1 -count=1 -timeout=12m \
  -overlay="$root/final_overlay.json" -json ./pts/lower ./pts/driver \
  -run '^(TestD215Review|TestElidedContainer|TestArrayPatternContainerUnsafeUsesPoisonEverySibling|TestArrayPatternContainerUnsafeUsesKeepEveryCompatibleTarget)' \
  > "$root/replay-final-probes.jsonl" 2> "$root/replay-final-probes.stderr" || exit "$?"

"$go" -C "$root/base" build -p=1 -overlay="$root/base_overlay.json" \
  -o "$root/emit-base" "$root/emit.go" || exit "$?"
"$go" -C "$root/base" build -p=1 -overlay="$root/final_overlay.json" \
  -o "$root/emit-current" "$root/emit.go" || exit "$?"
python3 -I "$root/run_native.py"
