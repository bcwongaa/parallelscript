from pathlib import Path
import os
import subprocess
import sys

root = Path('/tmp/d215-review-nrhgYUTC')
env = os.environ.copy()
env.update({'GOMAXPROCS': '1', 'PTS_HOME': '/home/bryan/projects/parallelscript', 'PTS_THREADS': '1'})
node = '/home/bryan/.local/node/bin/node'

def run(label, args, extra_env=None):
    actual = env.copy()
    if extra_env:
        actual.update(extra_env)
    result = subprocess.run(args, cwd=root, env=actual, capture_output=True, timeout=240)
    (root / (label + '.stdout')).write_bytes(result.stdout)
    (root / (label + '.stderr')).write_bytes(result.stderr)
    (root / (label + '.rc')).write_text(str(result.returncode) + '\n')
    print(label, 'exit=' + str(result.returncode), flush=True)
    return result

failed = False
for fixture in ('capture_receiver', 'unknown_mutation', 'permanent_regression'):
    entry = root / (fixture + '.pts')
    mts = root / (fixture + '.mts')
    mts.write_bytes(entry.read_bytes())
    oracle = run(fixture + '-node', [node, '--no-warnings', '--experimental-transform-types', str(mts)])
    if oracle.returncode:
        failed = True
        continue
    if fixture == 'permanent_regression':
        block = entry.read_text().split('// expect:\n', 1)[1]
        expected = ''.join(line[3:] + '\n' for line in block.splitlines() if line.startswith('// ')).encode()
        matches_expected = oracle.stdout == expected
        print(fixture, 'strict-node-expect-match=' + str(matches_expected), 'output-lines=' + str(len(oracle.stdout.splitlines())), flush=True)
        if not matches_expected:
            failed = True
    for variant in ('base', 'current'):
        for api in ('all', 'default'):
            label = fixture + '-' + variant + '-' + api
            code = root / (label + '.c')
            native = root / (label + '.bin')
            build = run(label + '-build', [str(root / ('emit-' + variant)), api, str(entry), str(code), str(native)])
            if build.returncode:
                failed = True
                continue
            extra = {'GC_PRINT_STATS': '1', 'GC_INITIAL_HEAP_SIZE': '1048576'} if fixture == 'capture_receiver' else None
            result = run(label + '-run', [str(native)], extra)
            matches = result.returncode == oracle.returncode and result.stdout == oracle.stdout
            print(label, 'strict-node-match=' + str(matches), 'completed-collections=' + str(result.stderr.count(b'Complete collection')), flush=True)
            if not matches:
                failed = True
            native.unlink()
sys.exit(1 if failed else 0)
