const t: [number, string] = [1, "a"];
function show(v: [number, string] | (number | string)[]): void { console.log(Array.isArray(v), v); }
show(t);
show([2, "b"]);
show([1, 2, 3]);
const c = Math.random() < 2;
show(c ? t : [1]);
