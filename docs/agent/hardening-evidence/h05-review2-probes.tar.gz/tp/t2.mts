const t: readonly [number, string] = [1, "a"];
const v: readonly [number, string] | (number | string)[] = t;
console.log(v === (t as any), v);
