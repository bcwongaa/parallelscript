const t: [number, string] = [1, "a"];
const v: readonly [number, string] | (number | string)[] = t;
console.log(v === (t as any), v);
const w: [number, string] | number[] = t;
console.log(w === (t as any));
