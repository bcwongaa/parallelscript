const t: [x: number, y: string] = [1, "a"];
const v: [number, string] | (number | string)[] = t;
console.log(v === (t as any), v);
