type P = [number, number];
const ps: P[] = [[1, 2], [3, 4]];
const r = ps.map((p, i) => (i > 0 ? [p, p] : p));
console.log(r.length, JSON.stringify(r));
function apply(f: (p: P) => P | P[]): void { console.log(JSON.stringify(f([5, 6]))); }
apply((p) => (p[0] > 1 ? [p, p] : p));
