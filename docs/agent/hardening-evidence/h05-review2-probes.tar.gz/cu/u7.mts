const shared: string[] = ["s", "t"];
const r = [1, 2].flatMap<number | string>((x) => (x > 1 ? shared : x));
console.log(r);
const r2 = [1, 2].flatMap((x): number | string | string[] => (x > 1 ? shared : x));
console.log(r2);
