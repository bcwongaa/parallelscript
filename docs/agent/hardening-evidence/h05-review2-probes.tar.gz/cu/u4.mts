const shared: string[] = ["s", "t"];
const r = [1, 2].map((x) => (x > 1 ? shared : [x]));
console.log(r);
const v: (number | string)[] | boolean = Math.random() < 2 ? shared : [1];
console.log(v);
