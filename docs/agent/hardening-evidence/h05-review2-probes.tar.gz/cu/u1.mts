const tup: [number, string] = [1, "a"];
const r = [1, 2].flatMap((x) => (x > 1 ? tup : [x]));
console.log(r);
