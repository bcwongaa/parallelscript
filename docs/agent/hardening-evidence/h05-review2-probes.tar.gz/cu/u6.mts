const shared: string[] = ["s", "t"];
const r = [1, 2].flatMap<number | string>((x) => (x > 1 ? shared : [x]));
console.log(r);
