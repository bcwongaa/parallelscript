const frozenTup = Object.freeze([1, "a"] as [number, string]);
const c = [1, 2].flatMap((x) => (x > 1 ? frozenTup : x));
console.log(c);
const d = [1, 2].flatMap(() => frozenTup);
console.log(d, Object.isFrozen(frozenTup));
