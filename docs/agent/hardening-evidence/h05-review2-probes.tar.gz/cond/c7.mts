const c = Math.random() < 2;
const p = Promise.resolve(5);
Promise.all(c ? [p, 1] : [2]).then((v) => console.log(v));
