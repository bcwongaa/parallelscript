const shared: number[] = [1];
function f(c: boolean): (number | string)[] | string {
  return c ? ["a"] : shared;
}
const r = f(false);
console.log(r, r === (shared as any));
(r as (number | string)[]).push("pushed");
console.log(shared);
