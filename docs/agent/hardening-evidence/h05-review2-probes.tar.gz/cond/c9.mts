interface Shape { area(): number }
class Circle implements Shape { constructor(public r: number) {} area() { return 3 * this.r * this.r; } }
class Square implements Shape { constructor(public s: number) {} area() { return this.s * this.s; } }
const c = Math.random() < 2;
const v: Shape | Shape[] = c ? [new Circle(1)] : new Square(2);
console.log(Array.isArray(v) ? v.map((s) => s.area()) : v.area());
const w: Circle | Square[] = c ? [new Square(1)] : new Circle(2);
console.log(w);
type Pt = { x: number; y: number };
const pts: Pt | Pt[] = c ? [{ x: 1, y: 2 }] : { x: 0, y: 0 };
console.log(pts);
const nest: number | (number | number[])[] = c ? [1, [2]] : 0;
console.log(nest);
const strs: string | (string | null)[] = c ? ["a", null] : "b";
console.log(strs);
const opt: undefined | [number, string][] = c ? [[1, "a"]] : undefined;
console.log(opt);
