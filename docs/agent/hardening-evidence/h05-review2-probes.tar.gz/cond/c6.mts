const c = Math.random() < 2;
console.log(new Map<string, number>(c ? [["a", 1]] : null).size);
