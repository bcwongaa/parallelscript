const c = Math.random() < 2;
console.log(new Uint8Array(c ? [1, 2] : 3).length);
