const c = Math.random() < 2;
const set = new Set<number>(c ? [1, 2] : undefined);
console.log(set.size);
const u8 = Uint8Array.from(c ? [1, 2] : new Set([4]));
console.log(u8.length);
