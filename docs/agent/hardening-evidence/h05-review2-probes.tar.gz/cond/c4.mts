const c = Math.random() < 2;
console.log(Array.from(c ? [1, 2] : new Set([3])));
