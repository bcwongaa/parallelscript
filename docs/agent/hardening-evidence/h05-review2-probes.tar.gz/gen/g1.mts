class P { constructor(public x: number) {} }
interface I { name: string }
function flatAll<T>(xs: T[][]): T[] { return xs.flat(); }
function flatTo<T>(xs: (T | T[])[]): T[] { return xs.flat() as T[]; }
function chain<T, U>(xs: T[], f: (x: T) => U | U[]): U[] { return xs.flatMap(f); }
function chainLit<T>(xs: T[]): T[] { return xs.flatMap((x) => [x, x]); }
const p = new P(1);
const i: I = { name: "n" };
console.log(flatAll([[p], [p]]).map((v) => v.x), flatAll([[i]])[0].name, flatAll([[1, 2], [3]]));
console.log(flatTo<P>([p, [p]])[1] === p, flatTo<I>([i, [i]]).length, flatTo<string | number>([1, ["a", 2]]));
console.log(chain([1, 2], (x) => (x > 1 ? [x, x] : x)), chain([p], (v) => [v.x]), chain(["a"], (s) => [{ name: s }]).map((o) => o.name));
console.log(chainLit([p])[1] === p, chainLit([i]).length, chainLit([[1]]));
class Box<T> {
  constructor(public items: T[][]) {}
  all(): T[] { return this.items.flat(); }
  pairs(): T[] { return this.items.flatMap((row) => row.concat(row)); }
}
console.log(new Box([[p]]).all()[0] === p, new Box([["a"], ["b"]]).pairs(), new Box<number | string>([[1], ["a"]]).all());
