function flatAll<T>(xs: T[][]): T[] { return xs.flat(); }
function flatTo<T>(xs: (T | T[])[]): T[] { return xs.flat() as T[]; }
const a = flatAll<number[]>([[[1], [2]], [[3]]]);
console.log(a, a[0].length);
const b = flatTo<number[]>([[1], [[2]]]);
console.log(b);
try { console.log(b[0].length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
function viaFlatMap<T>(xs: T[]): T[] { return xs.flatMap((x) => x); }
const c = viaFlatMap<number[]>([[1], [2]]);
console.log(c);
try { console.log(c[0].length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
