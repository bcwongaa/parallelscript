function apply(f: (x: number) => number | (number | string)[]): (number | (number | string)[])[] { return [f(1), f(2)]; }
console.log(apply((x) => (x > 1 ? [x] : x)));
const kept: number[][] = [];
const out = apply((x) => {
  const a = [x];
  kept.push(a);
  return a;
});
console.log(out, kept);
(out[0] as (number | string)[]).push("added");
console.log(kept[0], out[0]);
