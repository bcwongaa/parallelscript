function apply(f: (x: number) => number | (number | string)[]): (number | (number | string)[])[] { return [f(1), f(2)]; }
let last: number[] = [];
const out = apply((x) => {
  const a = [x];
  last = a;
  return a;
});
(out[1] as (number | string)[]).push("added");
console.log(last, out[1], last === (out[1] as any));
