function apply(f: (x: number) => number | (number | string)[]): (number | (number | string)[])[] { return [f(1), f(2)]; }
const shared: number[] = [5];
console.log(apply((x) => (x > 1 ? shared : x)));
