#!/bin/bash
S=/tmp/h05r2.bz2s
for f in $(ls $S/gen2/*.pts | sort); do
  echo "##### $f"
  $S/bin/t.sh $f
done > $S/gen2/all.out 2>&1
echo finished > $S/gen2/DONE
