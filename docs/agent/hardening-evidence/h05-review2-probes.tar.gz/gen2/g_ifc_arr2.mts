class P { constructor(public x: number) {} }
interface I { name: string; n: number }

const src: (I)[][] = [[{ name: "q", n: 1 }], [{ name: "r", n: 2 }, { name: "q", n: 1 }]];
{ const r = src.flat(); const kinds: string[] = []; for (const v of r) kinds.push(Array.isArray(v) ? 'array' : typeof v); console.log('1', r.length, JSON.stringify(r), kinds.join(',')); }
{ const r = src.flat(0); const kinds: string[] = []; for (const v of r) kinds.push(Array.isArray(v) ? 'array' : typeof v); console.log('0', r.length, JSON.stringify(r), kinds.join(',')); }
{ const r = src.flat(1); const kinds: string[] = []; for (const v of r) kinds.push(Array.isArray(v) ? 'array' : typeof v); console.log('1', r.length, JSON.stringify(r), kinds.join(',')); }
{ const r = src.flat(2); const kinds: string[] = []; for (const v of r) kinds.push(Array.isArray(v) ? 'array' : typeof v); console.log('2', r.length, JSON.stringify(r), kinds.join(',')); }
{ const r = src.flat(Infinity); const kinds: string[] = []; for (const v of r) kinds.push(Array.isArray(v) ? 'array' : typeof v); console.log('Infinity', r.length, JSON.stringify(r), kinds.join(',')); }
{ const r = src.flatMap((v) => v); console.log('fm-id', r.length, JSON.stringify(r)); }
{ const r = src.flatMap((v) => [v]); console.log('fm-wrap', r.length, JSON.stringify(r)); }
{ const r = src.flatMap((v, i) => (i % 2 ? [v, v] : [v])); console.log('fm-mix', r.length, JSON.stringify(r)); }
