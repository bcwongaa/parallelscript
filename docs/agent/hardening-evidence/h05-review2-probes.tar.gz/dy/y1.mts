const tup: [number, number[]] = [1, [2, 3]];
const t: any = tup;
const m: any = new Map([["a", 1]]);
try { console.log(m.flat()); } catch (e) { console.log("caught", (e as Error).name); }
const s: any = "abc";
try { console.log(s.flat()); } catch (e) { console.log("caught", (e as Error).name); }
const nested: any = [[1, [2, [3, [4]]]], { length: 1, z: "x" }];
console.log(nested.flat(Infinity));
const f32s: f32[] = [1.5 as f32];
const anyF: any = [f32s, [true, null, undefined]];
console.log(anyF.flat());
