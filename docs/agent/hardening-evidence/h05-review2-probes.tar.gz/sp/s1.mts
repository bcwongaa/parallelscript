const xs = [1, 2];
const a = xs.flatMap((x): [number, string?] => (x > 1 ? [x, "s"] : [x]));
console.log(a);
const b = xs.flatMap((x): [number, ...string[]] => [x, "r", "q"]);
console.log(b);
const c = xs.flatMap((x): readonly [number, number] => [x, x * 10]);
console.log(c);
const d = xs.flatMap<number | string>((x) => (x > 1 ? ([x, "s"] as const) : x));
console.log(d);
