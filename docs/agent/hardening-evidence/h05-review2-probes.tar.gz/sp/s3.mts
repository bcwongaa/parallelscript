const xs = [1, 2];
const a = xs.flatMap((x): [number, (string | undefined)?] => (x > 1 ? [x, undefined] : [x]));
console.log(a, a.length);
