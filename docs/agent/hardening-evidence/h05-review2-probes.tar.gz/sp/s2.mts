const xs = [1, 2];
const a = xs.flatMap<number | string>((x): [number, string?] => (x > 1 ? [x, undefined] : [x]));
console.log(a);
