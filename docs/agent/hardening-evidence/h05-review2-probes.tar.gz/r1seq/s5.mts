const shared: number[] = [7, 8];
const values: number[] = [1, 2];
console.log(values.flatMap<number | string>((x) => shared));
console.log(values.flatMap<number | string>((x) => (x > 1 ? [x] : x)));
console.log(values.flatMap<number | string>((x) => x.toString().split("")));
