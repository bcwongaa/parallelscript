const t: [number, number] = [1, 2];
console.log(t.flatMap((x) => [x, x]));
const pairs: [string, number][] = [["a", 1], ["b", 2]];
console.log(pairs.flatMap((p) => [p[0], p[1]]));
