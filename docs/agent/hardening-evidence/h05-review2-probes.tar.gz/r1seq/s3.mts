const shared: number[] = [7, 8];
const values: number[] = [1, 2];
console.log(values.flatMap((x) => (x > 1 ? shared : x)));
const words: string[] = ["a b", "c"];
console.log(words.flatMap((w) => w.split(" ")));
console.log(words.flatMap((w) => (w.includes(" ") ? w.split(" ") : w)));
