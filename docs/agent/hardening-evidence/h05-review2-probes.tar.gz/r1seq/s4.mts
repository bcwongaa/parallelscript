const shared: number[] = [7, 8];
const values: number[] = [1, 2];
console.log(values.flatMap<number | number[]>((x) => (x > 1 ? [shared] : x)));
const r = values.flatMap<number | number[]>((x) => (x > 1 ? [shared] : x));
console.log(r[1] === shared);
