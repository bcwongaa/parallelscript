function f<D extends number>(xs: number[][][], d: D) {
  return xs.flat(d);
}
const r = f([[[1]], [[2]]], -1);
console.log(r);
const inner = r[0][0][0];
console.log(inner, inner.length);
