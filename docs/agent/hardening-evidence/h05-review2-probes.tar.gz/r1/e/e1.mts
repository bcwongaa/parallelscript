function f<D extends number>(xs: number[][][], d: D) {
  return xs.flat(d);
}
console.log(f([[[1]], [[2]]], 1), f([[[1]], [[2]]], 2));
const n: number = 0;
console.log(f([[[1]], [[2]]], n));
const r2 = f([[[1]], [[2]]], 2);
console.log(r2.map((x) => x + 1));
function g<T>(xs: T[][], k: (t: T) => string) {
  return xs.flat().map(k);
}
console.log(g([[1], [2]], (x) => "v" + x));
console.log(g([[[1]], [[2]]], (x) => "v" + x.length));
