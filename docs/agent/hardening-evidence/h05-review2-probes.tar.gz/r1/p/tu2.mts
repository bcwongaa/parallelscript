const xs = [1, 2];
const r = xs.flatMap<[number, string]>((x) => [x, "a"]);
console.log(r[0][1]);
