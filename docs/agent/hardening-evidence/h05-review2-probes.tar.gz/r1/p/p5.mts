const n = 300_000;
const src = Array.from({ length: n }, (_, i) => i);
const out = src.par.flatMap<number | number[]>((x) => (x % 3 === 0 ? [x, [x]] : x % 3 === 1 ? x : [[x, x], x]));
let sum = 0;
let arrs = 0;
for (const v of out) {
  if (typeof v === "number") sum += v;
  else arrs += v.length;
}
console.log(out.length, sum, arrs);
const holey = new Array<string>(n);
for (let i = 0; i < n; i += 7) holey[i] = "s" + i;
const h = holey.par.flatMap((s) => {
  const r = new Array<string>(3);
  r[0] = s;
  r[2] = s + "!";
  return r;
});
console.log(h.length, h[0], h[1], h[h.length - 1]);
const t = src.par.flatMap((x) => [x, String(x)] as [number, string]);
console.log(t.length, t[t.length - 1], t[t.length - 2]);
