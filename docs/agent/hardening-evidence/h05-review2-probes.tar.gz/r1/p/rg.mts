import { range } from "pts:parallel";
console.log(range(1, 4).par.flatMap<number | number[]>((x) => (x === 1 ? x : [[x]])));
const u8 = new Uint8Array([1, 2]);
console.log(u8.par.flatMap<number | number[]>((x) => (x === 1 ? x : [[x]])));
console.log(range(0, 2).par.flatMap((x) => {
  const r = new Array<string>(2);
  r[1] = "v" + x;
  return r;
}));
