const r = [1, 2, 3].reduce<number | number[] | (number | string | boolean)[]>((acc, x) => (x > 2 ? [String(x), x] : acc), 0);
console.log(r);
