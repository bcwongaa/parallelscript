const c = Math.random() < 2;
const v: number | (number | string | boolean)[] = c ? ["a", 1] : 1;
console.log(v);
function f(): string | (number | string | boolean)[] { return c ? ["a", 1] : "x"; }
console.log(f());
