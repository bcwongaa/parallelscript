function apply<R>(f: () => R): R { return f(); }
const c = Math.random() < 2;
console.log(apply<number | number[] | (number | string | number[])[]>(() => (c ? [String(1), 1] : 1)));
