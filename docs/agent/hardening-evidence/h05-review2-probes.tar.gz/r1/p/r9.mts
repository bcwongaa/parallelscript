type Cell = number | number[] | (number | string | number[])[];
const pick = (x: number): Cell => (x > 1 ? [String(x), x] : x);
console.log(pick(1), pick(2));
