const values: number[] = [1, 2];
console.log(values.par.flatMap<number | string | number[]>((x) => (x > 1 ? [String(x), x] : x)));
