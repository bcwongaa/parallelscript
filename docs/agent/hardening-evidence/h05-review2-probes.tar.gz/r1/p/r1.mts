const xs = [1, 2];
console.log(xs.map<number | (number | string | boolean)[]>((x) => (x > 1 ? [String(x), x] : x)));
