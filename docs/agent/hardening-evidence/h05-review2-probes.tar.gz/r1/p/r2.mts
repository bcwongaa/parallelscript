const xs = [1, 2];
console.log(xs.flatMap((x) => (x > 1 ? [String(x), x] : [true])));
