const xs = ["a", "b"];
console.log(xs.map<string | string[] | (string | number | string[])[]>((s, i) => (i > 0 ? [s, i] : s)));
