function fn(x: number): number | number[][] { return x > 1 ? [[x]] : x; }
const values: number[] = [1, 2];
console.log(values.flatMap<number | number[]>(fn));
