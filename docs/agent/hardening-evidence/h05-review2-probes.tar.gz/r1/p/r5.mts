const words = ["a b", "c"];
const r = words.flatMap<string | number>((w) => (w.includes(" ") ? w.split(" ") : w.length));
console.log(r);
