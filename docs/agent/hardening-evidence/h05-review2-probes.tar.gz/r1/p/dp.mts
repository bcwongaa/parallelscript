const xs = [[1], [2]];
const a: any = 1;
console.log(xs.flat(a));
const u: number | undefined = Math.random() < 2 ? undefined : 1;
console.log(xs.flat(u));
console.log(xs.flat(undefined));
const i: int = 1;
console.log(xs.flat(i));
