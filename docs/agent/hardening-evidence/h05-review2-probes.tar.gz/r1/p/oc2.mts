const c = Math.random() < 2;
const maybe: number[][] | undefined = c ? [[3]] : undefined;
console.log(maybe?.flatMap((x) => x));
