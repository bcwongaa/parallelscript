console.log([1, 2].map<number | number[] | (number | string | number[])[]>((x) => (x > 1 ? [String(x), x] : x)));
