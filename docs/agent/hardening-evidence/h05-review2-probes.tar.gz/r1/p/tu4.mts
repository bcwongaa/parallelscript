const r = [1, 2].flatMap<number[]>((x) => [x]);
console.log(r);
