type Cell = number | number[] | (number | string | number[])[];
const cells: Cell[] = [1, 2].map((x): Cell => (x > 1 ? [String(x), x] : x));
console.log(cells);
