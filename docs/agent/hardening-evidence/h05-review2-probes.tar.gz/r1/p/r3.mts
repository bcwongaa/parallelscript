const xs = [1, 2];
const r = xs.flatMap<string | number | boolean>((x) => (x > 1 ? [String(x), x] : x));
console.log(r);
