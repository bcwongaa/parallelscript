const c = Math.random() < 2;
const xs: (number | number[] | (number | string | number[])[])[] = [1];
xs.push(c ? [String(1), 1] : 1);
console.log(xs);
