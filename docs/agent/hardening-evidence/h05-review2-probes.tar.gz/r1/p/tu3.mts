const nested: [number, string][][] = [[[1, "a"]]];
const r = nested.flat();
console.log(r[0][1], r);
const deep: [number, string][][] = [[[1, "a"]]];
const r2 = deep.flat(2);
console.log(r2);
