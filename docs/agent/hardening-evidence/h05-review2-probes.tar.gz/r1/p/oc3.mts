type Box = { items?: (number | number[])[] };
const b: Box = { items: [1, [2, 3]] };
const n: Box = {};
console.log(b.items?.flat(), n.items?.flat());
const bb: Box | null = Math.random() < 2 ? b : null;
console.log(bb?.items?.flatMap((x) => x));
