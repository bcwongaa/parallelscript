const n = 200_000;
const src = Array.from({ length: n }, (_, i) => i);
const out = src.flatMap<number | string | number[]>((x) => (x % 3 === 0 ? [x, [x]] : x % 3 === 1 ? x : [String(x), x]));
let sum = 0;
let strs = 0;
let arrs = 0;
for (const v of out) {
  if (typeof v === "number") sum += v;
  else if (typeof v === "string") strs++;
  else arrs += (v as number[])[0];
}
console.log(out.length, sum, strs, arrs);
const holey = new Array<string>(n);
for (let i = 0; i < n; i += 7) holey[i] = "s" + i;
const h = holey.flatMap((s) => {
  const r = new Array<string>(3);
  r[0] = s;
  r[2] = s + "!";
  return r;
});
console.log(h.length, h[0], h[1], h[h.length - 1]);
