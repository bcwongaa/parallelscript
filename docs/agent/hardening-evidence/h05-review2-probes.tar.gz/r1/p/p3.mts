const values: number[] = [1, 2];
console.log(values.flatMap<number | string | number[]>((x) => (x > 1 ? [String(x), x] : x)));
