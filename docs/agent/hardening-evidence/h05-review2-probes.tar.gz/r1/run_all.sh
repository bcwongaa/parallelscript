#!/bin/bash
S=/tmp/h05r2.bz2s
for f in $(find $S/r1 -name '*.pts' | sort); do
  echo "##### $f"
  $S/bin/t.sh $f
done > $S/r1/all.out 2>&1
echo finished > $S/r1/DONE
