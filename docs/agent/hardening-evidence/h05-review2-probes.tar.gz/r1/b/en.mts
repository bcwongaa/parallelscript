enum E { Neg = -1, Half = 0.5 }
const cube: number[][][] = [[[1]], [[2]]];
const a = cube.flat(E.Neg);
const b = cube.flat(E.Half);
const d = -1 as const;
const f = cube.flat(d);
const g = cube.flat(-1 as number);
console.log(g);
