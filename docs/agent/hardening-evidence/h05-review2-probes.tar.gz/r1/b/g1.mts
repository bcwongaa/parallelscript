function f<T>(xs: T[]) {
  return xs.flat();
}
const r = f([[1], [2, 3]]);
console.log(r.map((x) => x + 1));
const s = f([1, 2]);
console.log(s.map((x) => x * 3));
const u = f<number | number[]>([1, [2]]);
console.log(u.map((x) => x + 1));
function g<T>(xs: T[][], d: number) {
  return xs.flat(d);
}
console.log(g([[[1]], [[2]]], 2), g([[[1]], [[2]]], 1));
function h<T extends unknown[]>(xs: T[]) {
  return xs.flat();
}
console.log(h([[1, "a"], [2]]));
