function arr(): number[][] { console.log("arr"); return [[1], [2]]; }
function depth(): number { console.log("depth"); return 1; }
console.log(arr().flat(depth()));
let i = 0;
const xs = [[[1]], [[2]]];
const r = [xs, xs][i++].flat(i);
console.log(r, i);
