const n: (number | u8)[][] = [[1.5], [2 as u8]];
console.log(n.flat());
const m: (number[] | u8[])[] = [[1.5], [2 as u8] as u8[]];
console.log(m.flat());
