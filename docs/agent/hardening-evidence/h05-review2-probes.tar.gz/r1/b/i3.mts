const x: i64 = (1 as i64) << (62 as i64);
const a: (i64 | i64[])[] = [x, [x + (1 as i64), 3]];
console.log(a[1]);
const inner: i64[] = [x + (1 as i64), 3];
const a2: (i64 | i64[])[] = [x, inner];
console.log(a2.flat());
