const cube: number[][][] = [[[1]], [[2]]];
const d: number = 2;
try {
  const r = cube.flat(d as 1);
  console.log(r, r[0].length);
} catch (e) {
  console.log("caught", String(e));
}
const d0: number = 0;
try {
  const r0 = cube.flat(d0 as 2);
  console.log(r0, r0[0] + 1);
} catch (e) {
  console.log("caught", String(e));
}
