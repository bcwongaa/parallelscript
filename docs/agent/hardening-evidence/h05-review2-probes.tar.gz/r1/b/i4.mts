const xs: i64[] = [5];
const n: (number | i64[])[] = [1.5, xs];
const rn = n.flat();
console.log(rn);
