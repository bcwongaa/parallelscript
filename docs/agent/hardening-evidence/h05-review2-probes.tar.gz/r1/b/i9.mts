const a: u64[] = [(1 as u64) << (63 as u64)];
const n: (u64[] | number[])[] = [a, [1.5]];
try { console.log(n.flat()); } catch (e) { console.log("threw", String(e)); }
const asNum: number = a[0];
console.log(asNum);
const q: (number | u64)[] = [1.5, a[0]];
console.log(q);
