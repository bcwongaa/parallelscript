const big: i64 = (1 as i64) << (62 as i64);
const xs: i64[] = [big];
const n: (number | i64[])[] = [1.5, xs];
try {
  console.log(n.flat());
} catch (e) {
  console.log("flat threw", String(e));
}
try {
  console.log([1.5].flatMap((v) => (v > 1 ? xs : v)));
} catch (e) {
  console.log("flatMap threw", String(e));
}
const asNumber: number = big;
console.log(asNumber);
const ys: (number | i64)[] = [1.5, big];
console.log(ys);
