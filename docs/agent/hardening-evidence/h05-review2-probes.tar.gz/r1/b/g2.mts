const it: Iterable<number>[] = [[1, 2], new Set([3])];
const r = it.flat();
console.log(r.length);
try {
  for (const x of r) {
    for (const v of x) console.log("v", v);
  }
} catch (e) {
  console.log("caught", (e as Error).name);
}
const o: object[] = [[1, 2], { a: 1 }];
const ro = o.flat();
console.log(ro.map((x) => typeof x), Object.keys(ro[0]));
const e: {}[] = [[1, 2], "s"];
const re = e.flat();
console.log(re, re.map((x) => typeof x));
