const bs: u8[] = [7];
const n: (number | u8[])[] = [1.5, bs];
console.log(n.flat());
console.log([1.5, 2].flatMap((v) => (v > 1.5 ? bs : v)));
