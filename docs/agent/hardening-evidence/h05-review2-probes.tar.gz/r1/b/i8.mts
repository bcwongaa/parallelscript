const a: u64[] = [(1 as u64) << (63 as u64)];
const b: i64[] = [-5];
const m: (u64[] | i64[])[] = [a, b];
try { console.log(m.flat()); } catch (e) { console.log("threw", String(e)); }
const n: (u64[] | number[])[] = [a, [1.5]];
try { console.log(n.flat()); } catch (e) { console.log("threw", String(e)); }
const w: (i8[] | u8[])[] = [[-1], [255]];
const fw = w.flat();
console.log(fw, fw[0] + fw[1]);
