const t: [number, string] = [1, "a"];
const v: string | (number | string)[] = t;
console.log(v === t, v);
