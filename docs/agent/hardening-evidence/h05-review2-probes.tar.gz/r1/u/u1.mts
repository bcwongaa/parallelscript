const t: [number, string] = [1, "a"];
const v: [number, string?] | (number | string)[] = t;
console.log(v === t, v);
