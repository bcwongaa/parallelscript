type Named = { 0: number; 1: string; length: 2 };
const t: [number, string] = [1, "a"];
const c = Math.random() < 2;
function show(v: readonly [number, string] | (number | string)[] | null) { console.log(v); }
show(c ? [1, "a"] : null);
show(c ? t : null);
