interface HasZero { 0: number }
const t: [number, string] = [1, "a"];
const v: HasZero | (number | string)[] = t;
console.log(v === t, v);
