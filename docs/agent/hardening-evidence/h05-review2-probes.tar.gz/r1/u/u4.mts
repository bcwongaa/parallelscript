const c = Math.random() < 2;
const v: string | [number, string] | (number | string)[] = c ? [1, "a"] : "s";
console.log(v);
if (typeof v !== "string") v.push(2);
console.log(v);
