function f(n: number): number { return f(n + 1) + 1; }
try { console.log(f(0)); } catch (e) { console.log("caught", (e as Error).name); }
