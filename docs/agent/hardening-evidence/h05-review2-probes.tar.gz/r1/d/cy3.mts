function deep(n: number): any {
  let x: any = [0];
  for (let i = 0; i < n; i++) x = [x];
  return x;
}
const d: any[] = deep(100000);
console.log(d.flat(Infinity));
