const a: any = [1];
a.push(a);
try {
  console.log(a.flat(Infinity).length);
} catch (e) {
  console.log("caught", (e as Error).name);
}
