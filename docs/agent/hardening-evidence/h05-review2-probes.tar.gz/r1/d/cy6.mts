const o: object[] = [];
o.push(o);
try {
  console.log(o.flat(Infinity).length);
} catch (e) {
  console.log("caught", (e as Error).name);
}
