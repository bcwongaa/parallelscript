const a: any[] = [1];
a.push(a);
console.log(a.flat(3).length);
const b: any[] = [];
b.push(b);
console.log(b.flat(Infinity).length);
