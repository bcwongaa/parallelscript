const cube: number[][][] = [[[1], [2]], [[3]]];
const r25 = cube.flat(25);
console.log(r25, r25.map((x) => x + 1));
enum E { Neg = -1, Two = 2 }
const e: E = Math.random() < 2 ? E.Two : E.Neg;
const re = cube.flat(e as number);
console.log(re);
const one = cube.flat(E.Two);
console.log(one.map((x) => x * 2));
let d: 0 | 2 = Math.random() < 2 ? 2 : 0;
const rd = cube.flat(d);
console.log(rd, rd.length);
