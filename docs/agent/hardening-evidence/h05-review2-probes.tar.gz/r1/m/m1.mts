const a = ["a", "b", "c", "d"];
console.log(a.flatMap((x, i, arr) => {
  if (i === 0) arr.push("e");
  if (i === 1) arr.length = 3;
  return [x, i];
}), a);
const h = new Array<string>(4);
h[0] = "p";
console.log(h.flatMap((x, i, arr) => {
  if (i === 0) arr[2] = "late";
  return [x];
}));
const d: any = ["a", "b", "c", "d"];
console.log(d.flatMap((x: any, i: number, arr: any) => {
  if (i === 0) arr.push("e");
  if (i === 1) arr.length = 3;
  return [x, i];
}));
const dh: any = new Array<string>(4);
dh[0] = "p";
console.log(dh.flatMap((x: any, i: number, arr: any) => {
  if (i === 0) arr[2] = "late";
  return [x];
}));
const inner = ["x", "y"];
console.log(["a", "b"].flatMap((v) => {
  inner.push(v);
  return inner;
}));
