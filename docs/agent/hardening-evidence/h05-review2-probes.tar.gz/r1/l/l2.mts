interface P { x: number }
interface P2 { x: number; y: string }
const p2s: P2[] = [{ x: 2, y: "q" }];
const arr: (P | P2[])[] = [{ x: 1 }, p2s];
const r = arr.flat();
for (const e of r) console.log(e.x + 1);
const fm = [1, 2].flatMap((i): P | P2[] => (i > 1 ? p2s : { x: i }));
for (const e of fm) console.log(e.x * 10);
