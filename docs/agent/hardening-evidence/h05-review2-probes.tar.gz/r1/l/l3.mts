class Base { constructor(public n: number) {} }
class Derived extends Base { constructor(n: number, public s: string) { super(n); } }
const ds: Derived[] = [new Derived(2, "d")];
const arr: (Base | Derived[])[] = [new Base(1), ds];
const r = arr.flat();
for (const e of r) console.log(e.n, e instanceof Derived ? e.s : "-");
