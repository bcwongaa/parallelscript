type A = { x: number; y: string };
type B = { y: string; x: number };
const bs: B[] = [{ y: "b", x: 2 }];
const arr: (A | B[])[] = [{ x: 1, y: "a" }, bs];
const r = arr.flat();
for (const e of r) console.log(e.x + 1, e.y.length);
