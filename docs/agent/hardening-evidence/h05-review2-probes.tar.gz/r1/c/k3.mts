const c = Math.random() < 2;
const x = 1.5;
const a: u8[] | undefined = c ? [x] : undefined;
console.log(a);
const n = 300;
const b: u8[] | string = c ? [n] : "s";
console.log(b);
