function apply(f: () => string | (string | number)[]) { return f(); }
const arr: string[] = ["a"];
console.log(apply(() => arr));
