const c = Math.random() < 2;
function opt<T>(x: T | undefined): T[] { return x === undefined ? [] : [x]; }
const r1 = opt(c ? [1] : undefined);
console.log(r1);
const v: number[] | string[] | undefined = c ? [1] : undefined;
console.log(v);
const w: (number[] | string)[] = [c ? [1, 2] : "a", c ? "b" : [3]];
console.log(w);
const m = new Map<string, number[] | string>();
m.set("k", c ? [4] : "s");
console.log(m.get("k"));
const o: { f: number[] | null } = { f: c ? [5] : null };
o.f?.push(6);
console.log(o);
const arr: number[] = [7];
const z: number[] | string = c ? arr : [8];
z === arr ? console.log("same") : console.log("copy");
const t: [number, string] | null = c ? [1, "a"] : null;
console.log(t);
function ret(): number[] | undefined { return c ? [9] : undefined; }
const rr = ret(); rr?.push(10); console.log(rr);
const u8s: u8[] | undefined = c ? [1, 2] : undefined;
console.log(u8s);
const deep: (number | number[])[] | string = c ? [1, [2]] : "x";
console.log(deep);
