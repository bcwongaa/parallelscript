const kept: number[][] = [];
function run(h: (n: number) => string | (number | string)[]) {
  const r = h(1);
  if (typeof r !== "string") r.push("x");
  return r;
}
console.log(run((n) => {
  const out = [n];
  kept.push(out);
  return out;
}), kept);
const kept2: number[] = [7];
console.log(run((n) => (n > 0 ? kept2 : "s")), kept2);
