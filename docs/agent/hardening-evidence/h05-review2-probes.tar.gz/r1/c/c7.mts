function apply(f: () => string | (string | number)[]) { return f(); }
const arr: string[] = ["a"];
const got = apply(() => arr);
console.log(got === arr);
if (typeof got !== "string") {
  got.push(5);
}
console.log(arr, got);
