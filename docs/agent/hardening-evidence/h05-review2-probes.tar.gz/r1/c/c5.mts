const p = Promise.resolve(1).then((x) => (x > 0 ? [x, x] : "none"));
p.then((v) => console.log(v));
const q = Promise.resolve(2).then((x) => [x, "a"] as [number, string]);
q.then((v) => console.log(v));
