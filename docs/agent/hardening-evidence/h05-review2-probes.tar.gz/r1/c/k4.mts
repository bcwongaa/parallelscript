const x = 1.5;
const a: u8[] = [x];
console.log(a);
