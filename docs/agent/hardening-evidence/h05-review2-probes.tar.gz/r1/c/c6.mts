function call<T>(f: () => T | T[]): T[] {
  const r = f();
  return Array.isArray(r) ? r : [r];
}
console.log(call<number | number[]>(() => [[1]]));
console.log(call(() => [1, 2]));
console.log(call<number | string>(() => ["a", 1]));
