class Base { constructor(public n: number) {} }
class Derived extends Base { m = 2; }
function apply(f: () => string | Base[]) { return f(); }
const ds: Derived[] = [new Derived(1)];
console.log(apply(() => ds));
console.log(apply(() => [new Derived(3)]));
