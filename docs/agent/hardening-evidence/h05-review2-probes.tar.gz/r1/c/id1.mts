function apply(f: () => string | (string | number)[]) { return f(); }
const arr: string[] = ["a"];
console.log(apply(() => arr) === arr);
const s = new Set<unknown>([arr]);
console.log(s.has(apply(() => arr)));
