function apply(f: () => string | (string | number)[]) { return f(); }
console.log(apply(() => ["a"]));
