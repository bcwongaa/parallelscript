const arr: string[] = ["a"];
function apply(f: () => string | (string | number)[]) {
  const r = f();
  if (typeof r !== "string") r.push(1);
}
apply(() => arr);
console.log(arr);
