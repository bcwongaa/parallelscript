class Base { constructor(public n: number) {} }
class Derived extends Base { m = 2; }
class Other extends Base { o = 3; }
function apply(f: () => string | Base[]) { return f(); }
const ds: Derived[] = [new Derived(1)];
const got = apply(() => ds);
console.log(got === ds);
if (typeof got !== "string") {
  got.push(new Other(7));
}
console.log(ds.length, ds[ds.length - 1].m);
