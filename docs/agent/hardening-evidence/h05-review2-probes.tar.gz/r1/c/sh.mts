interface Shape { area(): number }
class Circle implements Shape { constructor(public r: number) {} area() { return 3 * this.r * this.r; } }
function total(make: () => Shape[] | null) { const s = make(); return s === null ? 0 : s.reduce((a, x) => a + x.area(), 0); }
console.log(total(() => [new Circle(1), new Circle(2)]));
console.log(total(() => (Math.random() < 2 ? [new Circle(1)] : null)));
const g: (n: number) => string | Shape[] = (n) => (n > 0 ? [new Circle(n)] : "none");
console.log(g(1), g(0));
const asyncF: () => Promise<number[]> | (number | string)[] = () => [1];
console.log(asyncF());
