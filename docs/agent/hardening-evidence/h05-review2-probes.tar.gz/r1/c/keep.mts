const kept: number[][] = [];
const h: (n: number) => string | (number | string)[] = (n) => {
  const out = [n];
  kept.push(out);
  return out;
};
const r = h(1);
if (typeof r !== "string") r.push("x");
console.log(kept, r);
