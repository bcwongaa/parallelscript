const c = Math.random() < 2;
const a: u8[] | undefined = c ? [1, 300] : undefined;
console.log(a);
