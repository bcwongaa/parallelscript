function apply(f: (b: boolean) => number | number[] | string[]) { return [f(true), f(false)]; }
const keep: number[] = [1, 2];
console.log(apply((b) => (b ? keep : 3)));
const shared = apply((b) => (b ? keep : 3))[0] as number[];
shared.push(9);
console.log(keep, shared === keep);
