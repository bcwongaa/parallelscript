const f: (n: number) => string | (number | string)[] = function g(n): string | (number | string)[] {
  return n > 0 ? g(n - 1) : [n];
};
console.log(f(2));
const h: (n: number) => string | (number | string)[] = (n) => {
  if (n > 5) return "big";
  const out = [n, n + 1];
  return out;
};
console.log(h(1), h(9));
