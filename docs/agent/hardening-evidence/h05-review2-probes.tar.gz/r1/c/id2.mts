function apply(f: () => string | (string | number)[]) { return f() === arr; }
const arr: string[] = ["a"];
console.log(apply(() => arr));
