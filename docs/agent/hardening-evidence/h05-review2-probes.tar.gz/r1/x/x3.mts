const m = /(a)|(b)/.exec("b")!;
const anyM: any = m;
console.log(anyM.flatMap((g: any) => [g ?? "none"]));
console.log(anyM.flat());
