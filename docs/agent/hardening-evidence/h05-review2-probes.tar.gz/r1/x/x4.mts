const m = /(a)|(b)/.exec("b")!;
const f = m.flat();
console.log(f.length, f);
const s = m.slice();
console.log(s.length, s, [s].flat());
