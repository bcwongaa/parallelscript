const m = /(a)|(b)/.exec("b");
if (m) {
  console.log(m.length, [m].flat(), [m].flat().length);
  console.log(["b"].flatMap((s) => /(a)|(b)/.exec(s) ?? []));
}
const all = [..."xbx".matchAll(/(a)|(b)/g)];
console.log(all.flat());
const parts = "a,b".split(/(,)|(;)/);
console.log(parts, [parts].flat());
const anyM: any = /(a)|(b)/.exec("b");
console.log(anyM.flat(), [anyM].flat());
