const m = /(a)|(b)/.exec("b")!;
console.log(m.flatMap((g) => [g ?? "none"]));
console.log(m.map((g) => g ?? "none"));
const parts = "a,b".split(/(,)|(;)/);
console.log(parts.flatMap((p) => [p ?? "none"]));
const anyM: any = m;
console.log(anyM.flatMap((g: any) => [g ?? "none"]));
