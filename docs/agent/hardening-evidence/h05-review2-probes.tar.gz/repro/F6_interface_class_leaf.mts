interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J>(() => [c]);
console.log(r.length, r[0].x);
