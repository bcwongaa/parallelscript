const parts = "a,b;c".split(/(,)|(;)/);
console.log(parts.flat());
