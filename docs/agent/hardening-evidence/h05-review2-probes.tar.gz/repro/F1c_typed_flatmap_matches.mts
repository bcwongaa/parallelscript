console.log(["a", "b"].flatMap((s) => /(a)|(b)/.exec(s)!));
