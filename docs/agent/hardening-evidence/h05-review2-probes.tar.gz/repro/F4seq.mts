const items = ["ab", "b"];
const out = items.flatMap((s) => /(a)?(b)/.exec(s)!);
console.log(out);
