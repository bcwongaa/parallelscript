const groups = ["a", "b"].flatMap((s) => /(a)|(b)/.exec(s)!);
console.log(groups);
