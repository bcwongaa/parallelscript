const inputs: string[] = [];
for (let i = 0; i < 4000; i++) inputs.push(i % 2 === 0 ? "a" : "b");
// even inputs match group 1 only; odd ones group 2 only: every match has one undefined group
const groups = inputs.flatMap((s) => /(a)|(b)/.exec(s)!);
let undef = 0, as = 0, bs = 0;
for (const g of groups) {
  if (g === undefined) undef++;
  else if (g === "a") as++;
  else if (g === "b") bs++;
}
console.log(groups.length, undef, as, bs);
// only late inputs have undefined groups: pieces before them are plain string[]
const late: string[] = [];
for (let i = 0; i < 4000; i++) late.push(i < 3000 ? "ab" : "b");
const lg = late.flatMap((s) => /(a)?(b)/.exec(s)!);
let lu = 0;
for (const g of lg) if (g === undefined) lu++;
console.log(lg.length, lu, String(lg[lg.length - 2]));
