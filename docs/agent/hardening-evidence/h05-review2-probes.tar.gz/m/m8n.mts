const n = Number(undefined ?? "2");
const items: string[] = [];
for (let i = 0; i < n; i++) items.push(i === n - 1 ? "b" : "ab");
const out = items.flatMap((s) => /(a)?(b)/.exec(s)!);
let u = 0;
for (let i = 0; i < out.length; i++) if (out[i] === undefined) u++;
console.log(out.length, u, out.slice(out.length - 3));
