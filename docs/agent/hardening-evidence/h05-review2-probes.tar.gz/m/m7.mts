const m = /(a)|(b)/.exec("b")!;
const n = /(a)|(b)/.exec("a")!;
console.log([m, n].flat());
