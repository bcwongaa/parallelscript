const m = /(a)|(b)|(c)/.exec("c")!;
console.log(m);
console.log([m].flat());
