const m = /(a)|(b)/.exec("b")!;
const r = m.slice(1);
try { console.log(r[0].length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
try { console.log(m[1].length); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
