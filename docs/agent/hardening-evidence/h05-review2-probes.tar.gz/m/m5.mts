const m = /(a)|(b)|(c)/.exec("c")!;
const strings: string[][] = [m, m];
console.log(strings.flat());
