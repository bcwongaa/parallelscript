const m = /(a)?(b)/.exec("b")!;
const a: string[] = ["x"];
a.push(...m);
console.log(a, 2 in a);
const c = m.slice();
const d: string[] = ["y"];
d.push(...c);
console.log(d);
