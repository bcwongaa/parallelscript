const m: any = /(a)|(b)|(c)/.exec("c")!;
console.log(m.flat());
console.log([m, m].flat());
console.log(m.flatMap((g: any) => [g]));
