const m = /(a)|(b)/.exec("b")!;
const r = [m.slice(1)].flat();
console.log(r);
try { console.log(r[0].length); } catch (e) { console.log("caught", (e as Error).name); }
try { console.log(r.map((s) => s.length)); } catch (e) { console.log("caught", (e as Error).name); }
try { for (const s of r) console.log(s.toUpperCase()); } catch (e) { console.log("caught", (e as Error).name); }
console.log(r.join("-"), r.length, r.indexOf("b"));
r.push("q");
const copy = r.slice();
console.log(copy, r.concat(["w"]));
