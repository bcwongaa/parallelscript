const parts = "a,b;c".split(/(,)|(;)/);
console.log(parts.length);
console.log(parts.flat());
