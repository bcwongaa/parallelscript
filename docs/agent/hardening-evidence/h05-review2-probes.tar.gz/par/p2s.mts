class P { constructor(public x: number) {} }
interface S { kind: string; n: number }
const n = 100_000;
const src = Array.from({ length: n }, (_, i) => i);
const shared = [new P(-1), new P(-2)];
const a = src.flatMap((i) => (i % 3 === 0 ? new P(i) : i % 3 === 1 ? [new P(i), new P(i + 1)] : shared));
let sa = 0;
for (const p of a) sa += p.x;
console.log(a.length, sa, a[3] === shared[0]);
const b = src.flatMap<number | string | P>((i) => (i % 4 === 0 ? [i, String(i)] : i % 4 === 1 ? new P(i) : i % 4 === 2 ? "s" : [[i]].length));
let nums = 0, strs = 0, objs = 0;
for (const v of b) {
  if (typeof v === "number") nums += v;
  else if (typeof v === "string") strs += v.length;
  else objs += v.x;
}
console.log(b.length, nums, strs, objs);
const c = src.flatMap((i): S | S[] => (i % 2 === 0 ? { kind: "a", n: i } : [{ kind: "b", n: i }, { kind: "c", n: 1 }]));
let sc = 0;
for (const s of c) sc += s.n + s.kind.length;
console.log(c.length, sc);
const d = src.flatMap<number | string | [number, string]>((i) => (i % 5 === 0 ? ([i, "t"] as [number, string]) : [[i, "u"] as [number, string]]));
let sd = 0;
for (const v of d) sd += typeof v === "number" ? v : typeof v === "string" ? v.length : v[0];
console.log(d.length, sd);
