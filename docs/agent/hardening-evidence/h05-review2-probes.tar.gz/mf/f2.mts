function show(v: (number | string)[] | boolean[]): void { console.log(v); }
const nums: number[] = [1];
show(nums);
show([2]);
show(["a", 3]);
const c = Math.random() < 2;
show(c ? [true] : [1]);
