const nums: number[] = [1];
const other: number[] = [2];
const v: number[] | (number | string)[] = Math.random() < 2 ? nums : ["x"];
v.push(5);
console.log(nums, v);
const w: (number | number[])[] | number[][] = [[1], [2]];
console.log(w);
