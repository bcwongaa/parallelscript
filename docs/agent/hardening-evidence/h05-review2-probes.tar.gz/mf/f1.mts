const nums: number[] = [1];
const v: (number | string)[] | boolean[] = nums;
console.log(v === (nums as any), v);
