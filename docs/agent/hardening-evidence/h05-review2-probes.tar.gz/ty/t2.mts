const inner = [1, 2];
const os: object[] = [inner, { a: 1 }];
const f = os.flat();
const o: object = f[0];
console.log(typeof o, typeof f[2]);
try { console.log(Object.keys(f[0])); } catch (e) { console.log("caught", (e as Error).name); }
const is: Iterable<number>[] = [inner, new Set([5])];
const k = is.flat();
try { for (const x of k[0]) console.log("x", x); } catch (e) { console.log("caught", (e as Error).name); }
try { for (const x of k[2]) console.log("y", x); } catch (e) { console.log("caught", (e as Error).name); }
try { console.log(Array.from(k[0])); } catch (e) { console.log("caught", (e as Error).name); }
