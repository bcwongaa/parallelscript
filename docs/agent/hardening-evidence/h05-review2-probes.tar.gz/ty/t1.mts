const inner = [1, 2];
const os: object[] = [inner, { a: 1 }];
try { const f = os.flat(); console.log(f.length, f); } catch (e) { console.log("caught", (e as Error).name, (e as Error).message); }
const es: {}[] = [inner, { a: 1 }, "s"];
const g = es.flat();
console.log(g.length, g);
const us: unknown[] = [inner, [[3]], 4];
const h = us.flat(2);
console.log(h.length, h);
const is: Iterable<number>[] = [inner, new Set([5])];
const k = is.flat();
console.log(k.length, k);
