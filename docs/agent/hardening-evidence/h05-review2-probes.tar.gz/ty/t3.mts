class A { constructor(public a: number) {} }
class B { constructor(public b: string) {} }
class A2 extends A { constructor(a: number, public extra: boolean) { super(a); } }
const a = new A(1), b = new B("x"), a2 = new A2(2, true);
const xs: (A | B | (A | B)[])[] = [a, [b, a2]];
const f = xs.flat();
console.log(f.length, f[0] === a, f[1] === b, f[2] === a2);
for (const v of f) {
  if (v instanceof A) console.log("A", v.a);
  else if (v instanceof B) console.log("B", v.b);
  else console.log("other", v);
}
const ys: A[][] = [[a, a2], [a2]];
const g = ys.flat();
console.log(g.map((v) => v.a), g[1] === a2);
const zs = [a, a2].flatMap((v) => (v.a > 1 ? [v, v] : v));
console.log(zs.length, zs[1] === a2 && zs[2] === a2);
interface Shape { kind: string; size: number }
const s1: Shape = { kind: "sq", size: 2 };
const sq = { kind: "ci", size: 3, r: 1 };
const shapes: (Shape | Shape[])[] = [s1, [sq, s1]];
const h = shapes.flat();
console.log(h.length, h[1] === sq, h.map((s) => s.kind + s.size));
