const c = Math.random() < 2;
const u: number[][] | string[][] = c ? [[1]] : [["a"]];
console.log(u.flatMap((x: number[] | string[]) => x));
