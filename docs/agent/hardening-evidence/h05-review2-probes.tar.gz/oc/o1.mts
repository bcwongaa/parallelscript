const c = Math.random() < 2;
const maybe: number[][] | undefined = c ? [[3], [4]] : undefined;
const none: number[][] | undefined = c ? undefined : [[1]];
console.log(maybe?.flat(), none?.flat(), maybe?.flat().length, none?.flat().length);
console.log(maybe?.flatMap((x) => x)?.length, none?.flatMap((x) => x));
console.log(maybe?.map((x) => x.length), none?.map((x) => x.length));
interface Box { items?: (number | number[])[] }
const b: Box = { items: [1, [2, 3]] };
const e: Box = {};
console.log(b.items?.flat(), e.items?.flat(), b.items?.flat()[2]);
const n: number[][][] | null = c ? [[[1]]] : null;
console.log(n?.flat(2), n?.flat(Infinity)?.[0]);
const fn = (xs?: string[][]) => xs?.flat().join(",") ?? "none";
console.log(fn([["a"], ["b"]]), fn());
