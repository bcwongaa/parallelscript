interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J>(() => [c]);
console.log(r.length, (r[0] as any) === (c as any));
r[0].x = "changed";
console.log(c.x, r[0].x);
