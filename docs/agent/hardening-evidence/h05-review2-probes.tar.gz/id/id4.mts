interface I { x: number }
const anyData: any = JSON.parse('[[{"x":1}],{"x":2}]');
const v: I | I[] = anyData[1];
console.log(v === anyData[1]);
const w: I = anyData[1];
console.log(w === anyData[1]);
const m = [0, 1].flatMap((i): I | I[] => anyData[i]);
console.log(m.length, m[0] === anyData[0][0], m[1] === anyData[1]);
const m2 = [0, 1].map((i): I | I[] => anyData[i]);
console.log(m2[1] === anyData[1]);
const m3 = [1].flatMap((i): I => anyData[i]);
console.log(m3[0] === anyData[1]);
