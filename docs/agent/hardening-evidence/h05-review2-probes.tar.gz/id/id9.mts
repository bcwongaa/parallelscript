interface J { x: number | string }
const j: J = { x: "lit" };
const anyLit: any = { x: 4 };
const r4 = [1].flatMap<J>(() => [anyLit]);
console.log((r4[0] as any) === anyLit);
const r5 = [1].flatMap<J>(() => anyLit);
console.log((r5[0] as any) === anyLit);
