interface I { x: number }
class P { constructor(public x: number, public y: number) {} }
const p = new P(1, 2);
const q = new P(3, 4);
// union of an interface and an array of it: leaves come from a union slot, checked
const xs: (I | I[])[] = [p, [q]];
const f = xs.flat();
console.log(f.length, f[0] === p, f[1] === q);
f[0].x = 10;
console.log(p.x);
// flatMap returning a leaf or an array
const ys = [p, q].flatMap((v): I | I[] => (v.x > 5 ? v : [v]));
console.log(ys[0] === p, ys[1] === q);
// object literal shape
const o = { x: 5 };
const zs: (I | I[])[] = [o, [o]];
const g = zs.flat();
console.log(g[0] === o, g[1] === o);
