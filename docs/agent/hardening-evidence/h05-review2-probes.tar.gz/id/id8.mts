interface J { x: number | string }
const j: J = { x: "lit" };
const lit = { x: 3 };
const r3 = [1].flatMap<J>(() => [lit]);
console.log((r3[0] as any) === (lit as any));
r3[0].x = "z";
console.log(lit.x, r3[0].x);
const anyLit: any = { x: 4 };
const r4 = [1].flatMap<J>(() => [anyLit]);
console.log((r4[0] as any) === anyLit);
