interface I { x: number }
const data = JSON.parse('[[{"x":1}],[{"x":2}]]') as I[][];
const f = data.flat();
f[0].x = 5;
console.log(data[0][0].x, f[0] === data[0][0]);
const anyData: any = JSON.parse('[[{"x":1}],{"x":2}]');
const u = anyData as (I | I[])[];
const g = u.flat();
g[0].x = 6;
console.log(u[0], g[0] === (u[0] as I[])[0], g[1] === u[1]);
const m = [0, 1].flatMap((i): I | I[] => anyData[i]);
console.log(m.length, m[0] === anyData[0][0], m[1] === anyData[1]);
