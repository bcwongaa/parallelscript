interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const j: J = { x: "lit" };
const r = [1].flatMap<J>(() => [c]);
console.log(r.length, (r[0] as any) === (c as any));
r[0].x = "changed";
console.log(c.x, r[0].x, j.x);
const lit = { x: 3 };
const r3 = [1].flatMap<J>(() => [lit]);
console.log((r3[0] as any) === (lit as any));
r3[0].x = "z";
console.log(lit.x);
