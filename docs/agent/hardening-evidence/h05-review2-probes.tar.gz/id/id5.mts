interface J { x: number | string }
class C { constructor(public x: number) {} }
const c = new C(1);
const r = [1].flatMap<J>(() => [c]);
console.log(r[0] === c);
r[0].x = "changed";
console.log(c.x);
const r2 = [1].flatMap<J>(() => c);
console.log(r2[0] === c);
