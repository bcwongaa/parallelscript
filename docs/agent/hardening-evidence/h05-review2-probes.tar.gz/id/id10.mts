interface J { x: number | string }
const anyLit: any = { x: 4 };
const jj: J = anyLit;
console.log(jj.x, (jj as any) === anyLit);
const arr: J[] = [anyLit];
console.log(arr[0].x);
const r6 = [1].map<J>(() => anyLit);
console.log(r6[0].x);
const anyArr: any = [anyLit];
const r7 = (anyArr as J[][]);
console.log(r7.length);
