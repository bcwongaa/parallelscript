const xs = [1, 2];
const r = xs.flatMap((x): object => [x, x]);
console.log(r.length, r);
