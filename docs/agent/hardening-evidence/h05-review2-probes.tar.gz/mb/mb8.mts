const xs = [1, 2];
const r = xs.flatMap((x): number[] | Iterable<number> => [x, x]);
console.log(r.length, r);
