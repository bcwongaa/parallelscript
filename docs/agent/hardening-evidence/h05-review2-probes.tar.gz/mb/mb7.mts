const xs = [1, 2];
const r = xs.flatMap((x): Object => [x, x]);
console.log(r.length, r);
