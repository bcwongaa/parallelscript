const xs: (number | number[])[] = [1, [2]];
const depth: any = { valueOf() { xs.push(99); return 1; } };
console.log(xs.flat(depth));
