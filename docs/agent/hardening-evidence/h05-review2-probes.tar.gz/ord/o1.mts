const log: string[] = [];
function arr(): (number | number[])[] { log.push("arr"); return [1, [2]]; }
const depth: any = { valueOf() { log.push("depth"); return 1; } };
console.log(arr().flat(depth), log.join(","));
function d(): number { log.push("d"); return 1; }
console.log(arr().flat(d()), log.join(","));
function anyArr(): any { log.push("anyArr"); return [1, [2]]; }
console.log(anyArr().flat(depth), log.join(","));
const m = { n: 0, get depth() { log.push("getter"); return 1; } };
console.log(arr().flat(m.depth), log.join(","));
