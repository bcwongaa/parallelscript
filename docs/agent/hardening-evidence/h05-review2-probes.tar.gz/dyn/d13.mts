interface J { x: number; tags: string[] }
const parsed: any = JSON.parse('[{"x":1,"tags":["a"]},{"x":2,"tags":[]}]');
const js = [0, 1].flatMap<J>((i) => parsed[i]);
console.log(js.length, js[0].tags.length + js[1].x);
