interface J { x: number }
const parsed: any = JSON.parse('[[{"x":1}],[{"x":2}]]');
const js = (parsed as J[][]).flat();
console.log(js.length, js[0].x + js[1].x);
