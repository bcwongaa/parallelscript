interface J { x: number }
const parsed: any = JSON.parse('[{"x":1},{"x":2}]');
const js = [0, 1].flatMap<J>((i) => [parsed[i]]);
console.log(js.length, js[0].x + js[1].x);
const unrelated: J = parsed[0];
console.log(unrelated.x);
