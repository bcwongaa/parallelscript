const parsed: any = JSON.parse('[{"a":1},{"b":2}]');
const rs = [0, 1].flatMap<Record<string, number>>((i) => [parsed[i]]);
console.log(rs.length, rs[0]["a"], rs[1]["b"]);
