interface J { x: number }
function load(): any { return JSON.parse('[{"x":1},{"x":2}]'); }
const groups = [load(), load()];
const js = groups.flatMap<J>((g) => g);
console.log(js.length, js.map((j) => j.x).join(","));
