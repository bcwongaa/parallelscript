class P { constructor(public x: number) {} }
const p = new P(1);
const frozenNums = Object.freeze([1, 2]);
const frozenObjs = Object.freeze([p, p]);
const frozenTup = Object.freeze([1, "a"] as [number, string]);
const a: (readonly number[])[] = [frozenNums, [3]];
console.log(a.flat());
const b: (readonly P[])[] = [frozenObjs];
const fb = b.flat();
console.log(fb.length, fb[0] === p);
fb.push(new P(2));
console.log(fb.length, Object.isFrozen(fb));
const d = [1].flatMap(() => frozenObjs);
console.log(d[1] === p, Object.isFrozen(d));
const e = Object.freeze([[1], [2]]).flat();
e.push(9);
console.log(e);
const anyF: any = frozenNums;
console.log([anyF, anyF].flat(), anyF.flat());
