// A group that took no part in a match is an undefined element of exec's and split's
// arrays (D-133), not a hole: flat and flatMap keep it, as JS does (H05 review round 1,
// finding 2: they were skipped as holes).
const m = /(a)|(b)/.exec("b")!;
console.log(m.flat(), m.flat().length);
console.log([m.slice()].flat());
const anyM: any = m;
console.log(anyM.flat(), anyM.flatMap((g: any) => [g ?? "none"]));
const parts = "a,b".split(/(,)|(;)/);
console.log(parts.flat(), [parts, ["c"]].flat().length);
const anyParts: any = parts;
console.log(anyParts.flatMap((p: any) => (p === undefined ? ["none"] : p)));
const groups: string[][] = [m.slice(1), ["z"]];
console.log(groups.flat());

// expect:
// [ 'b', undefined, 'b' ] 3
// [ 'b', undefined, 'b' ]
// [ 'b', undefined, 'b' ] [ 'b', 'none', 'b' ]
// [ 'a', ',', undefined, 'b' ] 5
// [ 'a', ',', 'none', 'b' ]
// [ undefined, 'b', 'z' ]
