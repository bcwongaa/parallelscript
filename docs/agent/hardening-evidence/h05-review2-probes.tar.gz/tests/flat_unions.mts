// flat() over arrays whose elements are a union of values and arrays: JS spreads every
// element that is an array at run time, whatever its static type, and keeps the others
// whole (strings, objects, class instances, Sets, typed arrays). The lowering typed the
// result as the receiver's array type and the runtime spread only elements of an
// object-kind array, so union elements (dynamic values) came back unflattened (C05, H05).
const numbers: (number | number[])[] = [1, [2, 3], 4, [5]];
console.log(numbers.flat(), numbers.flat().length);
const letters: (string | string[])[] = [["a"], "bc", ["d", "e"]];
console.log(letters.flat());
const mixed: (number | string[])[] = [1, ["x", "y"], 2];
console.log(mixed.flat());
const maybe: (number[] | undefined)[] = [[1], undefined, [2, 3]];
const nullable: (number[] | null)[] = [[1], null, [2, 3]];
console.log(maybe.flat(), nullable.flat());
const flags: (boolean | boolean[])[] = [true, [false, true]];
console.log(flags.flat());
const either: (number[] | string[])[] = [[1, 2], ["a"]];
console.log(either.flat());
type P = { x: number };
const points: (P | P[])[] = [{ x: 1 }, [{ x: 2 }, { x: 3 }]];
console.log(points.flat());
class Q {
  constructor(public y: number) {}
}
const qs: (Q | Q[])[] = [new Q(1), [new Q(2)]];
console.log(qs.flat());
const sets: (Set<number> | Set<number>[])[] = [new Set([1]), [new Set([2]), new Set([3])]];
console.log(sets.flat());
const bytes: (Uint8Array | number[])[] = [new Uint8Array([1, 2]), [3, 4]];
console.log(bytes.flat());
const frozen: ReadonlyArray<number | readonly number[]> = [1, [2, 3]];
console.log(frozen.flat());
const n: number[] = [1, 2];
const t: [string, number] = ["a", 3];
const arrayOrTuple: (number[] | [string, number])[] = [n, t];
console.log(arrayOrTuple.flat());
console.log([1, 2, 3].map((x) => (x > 1 ? [x, x] : x)).flat());

// expect:
// [ 1, 2, 3, 4, 5 ] 5
// [ 'a', 'bc', 'd', 'e' ]
// [ 1, 'x', 'y', 2 ]
// [ 1, undefined, 2, 3 ] [ 1, null, 2, 3 ]
// [ true, false, true ]
// [ 1, 2, 'a' ]
// [ { x: 1 }, { x: 2 }, { x: 3 } ]
// [ Q { y: 1 }, Q { y: 2 } ]
// [ Set(1) { 1 }, Set(1) { 2 }, Set(1) { 3 } ]
// [ Uint8Array(2) [ 1, 2 ], 3, 4 ]
// [ 1, 2, 3 ]
// [ 1, 2, 'a', 3 ]
// [ 1, 2, 2, 3, 3 ]
