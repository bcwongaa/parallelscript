// flat at depth Infinity over an array that holds itself throws RangeError, as Node's does,
// through a typed any[] and through `any`, rather than overflowing the C stack (an
// intermediate H05 version crashed with SIGSEGV); a finite depth stops (H05, D-180).
const a: any[] = [1];
a.push(a);
try {
  console.log(a.flat(Infinity).length);
} catch (e) {
  console.log((e as Error).name, (e as Error).message);
}
const b: any = new Array<any>("x");
b.push(b);
try {
  console.log(b.flat(Infinity).length);
} catch (e) {
  console.log((e as Error).name, (e as Error).message);
}
console.log(a.flat(3).length, b.flat(2).length);

// expect:
// RangeError Maximum call stack size exceeded
// RangeError Maximum call stack size exceeded
// 5 4
