// A typed callback over a match array with a group that took no part: tsc types the group
// as a string, so flatMap's callback, as map's, throws where the group is passed (a TypeError for exec's arrays, the RangeError of a missing element for split's) rather
// than hand the callback an undefined string (D-133). The group isn't skipped as a hole
// (H05 review round 1, finding 2: flatMap printed [ 'b', 'b' ]).
const m = /(a)|(b)/.exec("b")!;
function attempt(what: string, f: () => unknown): void {
  try {
    console.log(what, f());
  } catch (e: any) {
    console.log(what, "->", e.name + ": " + e.message);
  }
}
attempt("map", () => m.map((g) => g ?? "none"));
attempt("flatMap", () => m.flatMap((g) => [g ?? "none"]));
const parts = "a,b".split(/(,)|(;)/);
attempt("split map", () => parts.map((p) => p ?? "none"));
attempt("split flatMap", () => parts.flatMap((p) => [p ?? "none"]));

// no-diff: JS passes the undefined group to the callback; ParallelScript's typed callback takes a string (D-133)
// expect:
// map -> TypeError: Expected string, got undefined (group 1 of the match took no part in it)
// flatMap -> TypeError: Expected string, got undefined (group 1 of the match took no part in it)
// split map -> RangeError: Array index 2 is out of range (length 4); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
// split flatMap -> RangeError: Array index 2 is out of range (length 4); if it may be missing, read it with `?? fallback`, give the element type `| undefined`, or check the length first
