// flat() over arrays of tuples: a tuple is an array to JS, so its elements are spread
// (optional elements it lacks aren't there). Tuples are shapes with fields 0, 1, ...
// (D-053), which the runtime's flat didn't spread (C05, H05).
const entries: [string, number][] = [["b", 2], ["a", 1]];
console.log(entries.flat());
const optional: [number, number?][] = [[1], [2, 3]];
console.log(optional.flat());
const fixed: (readonly [number, string])[] = [[1, "a"], [2, "b"]];
console.log(fixed.flat());
const rest: [string, ...number[]][] = [["a", 1, 2], ["b"]];
console.log(rest.flat());
const columns: [number[], string[]][] = [[[1, 2], ["a"]], [[3], []]];
console.log(columns.flat());
console.log(columns.flat(2));
console.log(Object.entries({ a: 1, b: 2 }).flat());
const m = new Map<string, number>([["a", 1], ["b", 2]]);
console.log([...m].flat(), Array.from(m.entries()).flat());

// expect:
// [ 'b', 2, 'a', 1 ]
// [ 1, 2, 3 ]
// [ 1, 'a', 2, 'b' ]
// [ 'a', 1, 2, 'b' ]
// [ [ 1, 2 ], [ 'a' ], [ 3 ], [] ]
// [ 1, 2, 'a', 3 ]
// [ 'a', 1, 'b', 2 ]
// [ 'a', 1, 'b', 2 ] [ 'a', 1, 'b', 2 ]
