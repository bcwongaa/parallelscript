const t: [number, number[]?] = [1];
console.log(t.flat(), t.flat().length);
const t2: [number[], [string, number]] = [[1, 2], ["a", 3]];
console.log(t2.flat(), t2.flat(2), t2.flatMap((x) => x));
const t3: readonly [number, readonly number[]] = [1, [2]];
console.log(t3.flat());
