type T = [number, string];
const a: T = [1, "t"];
const src: (T | T[])[] = [];
src.push(a);
src.push([a]);
const r = src.flatMap((v, i) => (i % 2 ? [v, v] : [v]));
console.log(r.length, JSON.stringify(r));
