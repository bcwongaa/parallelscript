const t: [number, string] = [1, "a"];
console.log(Array.isArray(t));
const u: [number, string] | number = t;
console.log(Array.isArray(u));
const a: any = t;
console.log(Array.isArray(a));
