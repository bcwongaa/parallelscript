interface Shape { area(): number }
class Circle implements Shape { constructor(public r: number) {} area() { return 3 * this.r * this.r; } }
class Square implements Shape { constructor(public s: number) {} area() { return this.s * this.s; } }
const lit: Shape = { area: () => 7 };
const xs: (Shape | Shape[])[] = [new Circle(1), [new Square(2), lit]];
const f = xs.flat();
console.log(f.map((s) => s.area()));
const fm = [1, 2].flatMap((x): Shape | Shape[] => (x > 1 ? [new Circle(x), lit] : new Square(x)));
console.log(fm.map((s) => s.area()), fm[2] === lit);
interface Two { f(a: number, b: number): number }
class One { f(a: number) { return a * 10; } }
const one: Two = new One();
const ys: (Two | Two[])[] = [one, [one]];
const g = ys.flat();
console.log(g.map((t) => t.f(1, 2)), g[0] === one);
const gm = [1].flatMap((x): Two | Two[] => one);
console.log(gm[0].f(3, 4));
interface WithGetter { readonly v: number }
class G { get v() { return 42; } }
const wg: WithGetter = new G();
const zs: (WithGetter | WithGetter[])[] = [wg, [wg]];
console.log(zs.flat().map((z) => z.v));
