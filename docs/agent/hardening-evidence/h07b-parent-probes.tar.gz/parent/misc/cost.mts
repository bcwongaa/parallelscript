const shared = new AbortController();
for (const n of [10_000, 40_000, 100_000, 400_000]) {
  const source = new AbortController();
  const start = performance.now();
  const followers: AbortSignal[] = [];
  for (let i = 0; i < n; i++) followers.push(AbortSignal.any([source.signal]));
  const made = performance.now();
  source.abort("x");
  const done = performance.now();
  let aborted = 0;
  for (const f of followers) if (f.aborted) aborted++;
  console.log(`${n}: follow ${(made - start).toFixed(0)} ms, abort ${(done - made).toFixed(0)} ms, aborted ${aborted}`);
}
