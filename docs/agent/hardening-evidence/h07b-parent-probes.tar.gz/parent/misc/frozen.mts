const c = new AbortController();
Object.freeze(c.signal);
try { AbortSignal.any([c.signal]); console.log("any ok"); } catch (e) { console.log("any threw", String(e)); }
try { c.signal.onabort = () => console.log("onabort"); console.log("onabort set"); } catch (e) { console.log("onabort threw", String(e)); }
try { c.signal.addEventListener("abort", () => console.log("listener")); console.log("add ok"); } catch (e) { console.log("add threw", String(e)); }
try { c.abort("x"); console.log("abort ok", c.signal.aborted); } catch (e) { console.log("abort threw", String(e)); }
try { c.signal.addEventListener("abort", () => console.log("listener2")); console.log("add2 ok"); } catch (e) { console.log("add2 threw", String(e)); }
console.log("done");
