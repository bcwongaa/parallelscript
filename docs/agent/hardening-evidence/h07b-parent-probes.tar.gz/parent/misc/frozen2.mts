const c = new AbortController();
Object.freeze(c.signal);
try { c.abort("x"); console.log("abort ok"); } catch (e) { console.log("abort threw", String(e), c.signal.aborted, c.signal.reason); }
c.signal.addEventListener("abort", () => console.log("listener"));
console.log("added after the failed abort");
const follower = AbortSignal.any([c.signal]);
console.log("follower", follower.aborted);
const s = new AbortController();
const d = AbortSignal.any([s.signal]);
const e = AbortSignal.any([s.signal]);
d.addEventListener("abort", () => console.log("d listener"));
e.addEventListener("abort", () => console.log("e listener", e.reason));
s.signal.addEventListener("abort", () => console.log("source listener"));
Object.freeze(d);
try { s.abort("y"); console.log("abort ok"); } catch (err) { console.log("abort threw", String(err), s.signal.aborted, d.aborted, e.aborted); }
const g = AbortSignal.any([s.signal]);
console.log("g", g.aborted, g.reason);
const self = new AbortController();
self.signal.addEventListener("abort", () => console.log("SHOULD NOT RUN: self"), { signal: self.signal });
self.abort();
const t = new EventTarget();
const l: EventListener = () => console.log("SHOULD NOT RUN: duplicate");
const owner = new AbortController();
t.addEventListener("ping", l);
t.addEventListener("ping", l, { signal: owner.signal });
owner.abort();
t.dispatchEvent(new Event("ping"));
console.log("done");
