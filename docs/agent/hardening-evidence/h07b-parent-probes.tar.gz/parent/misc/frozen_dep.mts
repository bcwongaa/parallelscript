const c = new AbortController();
const d = AbortSignal.any([c.signal]);
const e = AbortSignal.any([c.signal]);
d.addEventListener("abort", () => console.log("d listener"));
e.addEventListener("abort", () => console.log("e listener", e.reason));
c.signal.addEventListener("abort", () => console.log("source listener"));
Object.freeze(d);
try { c.abort("x"); console.log("abort ok", c.signal.aborted, d.aborted, e.aborted); } catch (err) { console.log("abort threw", String(err), c.signal.aborted, e.aborted); }
