function log(...parts: unknown[]): void { console.log(parts.map(String).join(" ")); }
{
  const owner = new AbortController();
  const target = new EventTarget();
  owner.signal.addEventListener("abort", (event) => { log("an earlier abort listener stops the event"); event.stopImmediatePropagation(); });
  target.addEventListener("ping", () => log("SHOULD NOT RUN: still attached"), { signal: owner.signal });
  owner.signal.addEventListener("abort", () => log("SHOULD NOT RUN: after the stop"));
  owner.abort();
  target.dispatchEvent(new Event("ping"));
  log("stopped, and removed all the same");
}
{
  const owner = new AbortController();
  const target = new EventTarget();
  const listener: EventListener = () => log("the listener ran");
  target.addEventListener("ping", listener, { signal: owner.signal });
  owner.signal.dispatchEvent(new Event("abort"));
  target.addEventListener("ping", listener);
  owner.abort();
  target.dispatchEvent(new Event("ping"));
  log("an untrusted abort event used the removal up");
}
