// H10b: places a program declares with a generic class for `any` (`Box<any>`) holding instances
// for other type arguments, without `instanceof`: a parameter given a Box<number> and a
// Box<string>, an array `Box<any>[]` of both, a return type, a field, a Map's and a Record's
// values, a tuple's element and a cast. Reads, writes, pushes and method calls through them
// reach the objects, as in Node. HEAD was PTS1001 (`using a Box as a Box`).
class Box<T> {
  hits = 0;
  items: T[] = [];
  constructor(public v: T) {
    this.items.push(v);
  }
  get(): T {
    return this.v;
  }
  get first(): T {
    return this.items[0];
  }
}
function describe(b: Box<any>): string {
  b.hits++;
  b.items.push(b.v);
  return `${b.v}:${b.get()}:${b.first}:${b.items.length}:${b.hits}`;
}
const n = new Box(1);
const s = new Box("s");
console.log("param", describe(n), describe(s));
const xs: Box<any>[] = [n, s];
for (const x of xs) x.hits += 10;
console.log("array", xs.map((x) => x.hits), xs[1].get());
function choose(flag: boolean): Box<any> {
  return flag ? n : s;
}
choose(true).v = 2;
console.log("return", choose(true).get(), choose(false).first);
class Shelf {
  slot: Box<any> = new Box(true);
}
const shelf = new Shelf();
shelf.slot = n;
shelf.slot.items.push(3);
console.log("field", shelf.slot.items);
const byName = new Map<string, Box<any>>([["n", n], ["s", s]]);
byName.get("s")!.v = "t";
const rec: Record<string, Box<any>> = { a: n };
rec.a.hits = 0;
const pair: [Box<any>, number] = [s, 1];
pair[0].items.push("u");
const cast = n as Box<any>;
cast.v = cast.v * 10;
console.log("collections", s.v, n.hits, s.items, n.v);
