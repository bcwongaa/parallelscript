// H10b (C285): a row inside a member of a value narrowed by `instanceof` to a generic class,
// handed by a promise to a function given to `.then` by reference: `Promise.resolve(c.matrix[0])`
// and a Promise member (`c.pending`, which resolves to a row). In Node the function gets the
// instance's own row, so its write reaches it. HEAD lost the first write silently and was
// PTS1001 for the second (`giving a function whose parameter is a value[] to a method of the
// object an instanceof narrowing holds as a dynamic value`). Typed code without instanceof
// loses such writes too (`Promise.resolve(rows[0]).then(pushAny)` of a `number[][]`; the
// reproducer's probe q05).
interface Cache<K, V> {
  get(key: K): V | undefined;
}
class MapLRU<K, V> implements Cache<K, V> {
  matrix: V[][] = [[], []];
  pending: Promise<V[]>;
  constructor(public key: K, public val: V) {
    this.pending = Promise.resolve(this.matrix[1]);
  }
  get(key: K): V | undefined {
    return key === this.key ? this.val : undefined;
  }
}
function pushRow(row: any[]): void {
  row.push("ref");
}
async function run(c: Cache<string, number>): Promise<void> {
  if (!(c instanceof MapLRU)) return;
  await Promise.resolve(c.matrix[0]).then(pushRow);
  await c.pending.then(pushRow);
}
const m = new MapLRU<string, number>("k", 0);
await run(m);
console.log(m.matrix);
