// Guard (H10b): the library's generics for `any` (`Promise<any>`, `Map<any, any>`, `Set<any>`,
// `Array<any>`) and untyped `new Map()`/`new Set()`, read, written and passed on. They are not
// classes of the program, so a change to the program's C<any, …> places must leave them as
// they are on HEAD.
function addAll(xs: Array<any>, ys: any[]): number {
  for (const y of ys) xs.push(y);
  return xs.length;
}
const p: Promise<any> = Promise.resolve(JSON.parse('{"a": 1}'));
const m: Map<any, any> = new Map();
m.set(1, "one");
m.set("two", 2);
const s: Set<any> = new Set<any>([1, "1", true]);
s.add([2]);
const arr: Array<any> = [1, "two", [3]];
arr.push({ four: 4 });
console.log("map", m.get(1), m.get("two"), m.size);
console.log("set", s.has("1"), s.size);
console.log("array", addAll(arr, [5, "six"]), arr);
const untyped = new Map();
untyped.set("k", [1]);
untyped.get("k").push(2);
const bag = new Set();
bag.add(untyped.get("k"));
console.log("untyped", untyped.get("k"), bag.size);
const v = await p;
v.b = v.a + 1;
console.log("promise", v, await Promise.all([p, Promise.resolve<any>(2)]));
