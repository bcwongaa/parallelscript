// Probe: typed code, no instanceof, no generic class: a function given by reference whose
// parameter is any[] (or number[]) to Promise#then over number[] rows. (Array#forEach(pushAny)
// over number[][] is D-094's honest PTS1001.)
function pushAny(row: any[]): void {
  row.push("any");
}
function pushNum(row: number[]): void {
  row.push(1);
}
const rows: number[][] = [[], [], [], []];
await Promise.resolve(rows[0]).then(pushAny);
await Promise.resolve(rows[1]).then(pushNum);
await Promise.resolve(rows[2]).then((r: any[]) => r.push("inline"));
console.log(rows);
