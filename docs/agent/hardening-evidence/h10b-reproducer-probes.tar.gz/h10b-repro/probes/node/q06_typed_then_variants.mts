// Probe: where does the typed `.then` copy happen? number[] rows, no instanceof, no generic class.
const rows: number[][] = [[], [], [], []];
await Promise.resolve(rows[0]).then((r) => r.push(1)); // callback typed number[]
await Promise.resolve(rows[1]).then((r: any[]) => r.push(2)); // annotated any[]
await Promise.resolve(rows[2]).then((r: any) => r.push(3)); // annotated any
const p: Promise<any[]> = Promise.resolve(rows[3]); // the promise converted to Promise<any[]>
await p.then((r) => r.push(4));
// (`const got: any[] = await q` of a Promise<number[]> is D-094's honest PTS1001.)
console.log(rows);
