// Probe: Array.from / Object.values / Object.entries over number[][] and Record<string, number[]>, no instanceof.
const raw: number[][] = [[], []];
Array.from(raw)[1].push(2);
const rec: Record<string, number[]> = { a: [] };
Object.values(rec)[0].push(3);
Object.entries(rec)[0][1].push(4);
console.log(raw, rec);
