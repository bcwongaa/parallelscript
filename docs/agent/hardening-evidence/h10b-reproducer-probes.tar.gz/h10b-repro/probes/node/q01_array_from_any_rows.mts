// Probe: Array.from / Object.values / Object.entries over any[][] and Record<string, any[]>, no instanceof.
const raw: any[][] = [[], []];
Array.from(raw)[1].push(2);
const rec: Record<string, any[]> = { a: [] };
Object.values(rec)[0].push(3);
Object.entries(rec)[0][1].push(4);
console.log(raw, rec);
