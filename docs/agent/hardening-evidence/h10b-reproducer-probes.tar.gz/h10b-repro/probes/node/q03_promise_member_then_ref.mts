// Probe: a Promise<number[]> member's .then given a function by reference, no instanceof, and
// through an instance for any held as Box<any>.
class Box<T> {
  rows: T[][] = [[]];
  pending: Promise<T[]>;
  constructor() {
    this.pending = Promise.resolve(this.rows[0]);
  }
}
function pushRow(row: any[]): void {
  row.push("ref");
}
const b = new Box<number>();
await b.pending.then(pushRow);
console.log(b.rows);
