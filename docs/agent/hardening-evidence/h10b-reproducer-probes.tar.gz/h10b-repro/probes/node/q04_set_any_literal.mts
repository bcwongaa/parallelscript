// Probe: a Set<any> place given `new Set([1, "1", true])` (tsc: Set<string | number | boolean>), no generics of the program.
const s: Set<any> = new Set([1, "1", true]);
s.add([2]);
console.log(s.size, s.has("1"));
