class Box<T> { constructor(public value:T){} }
class C0 { tag=7; }
class C1 { tag="nine"; }
type Factory=<T>(value:T)=>Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
function create(label:string):Factory {
  let calls=0;
  return <T>(value:T):Box<T>=>{calls++;console.log("closure",label,calls);return new Box(value);};
}
function hold(value:Factory):Factory {
  const tree=[{row:{items:[{value}]}}]; const alias=tree;
  return alias[0].row.items[0].value;
}
const a=hold(create("a")); const b=hold(create("b"));
const seen:string[]=[];
function make(label:string):Factory { seen.push(label);return create(label); }
const effects={left:[{value:make("selected"),other:make("unselected")}],side:{value:make("side")}};
const selected=effects.left[0].value;
console.log("effects",seen.join("/"));
class Parent implements Maker {
  calls=0;
  constructor(public label:string){}
  make<T>(value:T):Box<T>{this.calls++;console.log("parent",this.label,this.calls);return new Box(value);}
}
class Child extends Parent {}
class Override extends Parent {
  make<T>(value:T):Box<T>{this.calls++;console.log("override",this.label,this.calls);return new Box(value);}
}
function capture(value:Maker):Factory {
  const root={row:[{receiver:value}]};
  const selected=root.row[0].receiver;
  return selected.make.bind(selected);
}
const first:Maker=new Child("first");const second:Maker=new Override("second");
const ca=capture(first);const cb=capture(second);
const lookup:Parent=new Child("lookup"); const actual:Parent=new Child("actual");
const bindTree={row:[{receiver:lookup}]};
const bound=bindTree.row[0].receiver.make.bind(actual);
function use0(value:Factory):void{console.log("C0",value(new C0()).value.tag);}
function use1(value:Factory):void{console.log("C1",value(new C1()).value.tag);}
use0(a);use1(b);use1(a);use0(selected);use0(ca);use1(cb);use1(ca);use0(bound);
let checksum=0;
for(let i=0;i<160000;i++){
  const junk=["garbage/"+i, "more/"+i, "allocation/"+i];
  checksum+=junk[1].length;
}
console.log("churn",checksum);
use1(a);use0(b);use1(ca);use0(cb);use1(bound);
const mutable={row:[{value:create("before"),other:create("after")}]};
const before=mutable.row[0].value;
function replace(part:{value:Factory;other:Factory}):void{part.value=part.other;}
replace(mutable.row[0]);const after=mutable.row[0].value;
use0(before);use1(after);
const dynamic:any=mutable.row[0];dynamic.value=a;
use0(mutable.row[0].value);
