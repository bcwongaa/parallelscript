import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

repo, base, current, destination = map(Path, sys.argv[1:])
destination.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS="2")
commands = []

def run(args, timeout=180):
    started = time.monotonic()
    p = subprocess.run(list(map(str, args)), cwd=repo, env=env, capture_output=True, text=True, timeout=timeout)
    commands.append(dict(command=list(map(str, args)), exit=p.returncode, stdout=p.stdout, stderr=p.stderr, seconds=time.monotonic()-started))
    (destination / "commands.json").write_text(json.dumps(commands, indent=2))
    if p.returncode:
        raise RuntimeError(commands[-1])
    return p.stdout, commands[-1]["seconds"]

def source(kind, n, unknown):
    lines = ["class Box<T> { constructor(public value: T) {} }", "type Factory = <T>(value:T) => Box<T>;", "interface Maker { make<T>(value:T):Box<T>; }"]
    for i in range(n):
        lines += [f"class C{i} {{ tag={i}; }}", f"function source{i}<T>(value:T):Box<T> {{ console.log('source',{i}); return new Box(value); }}", f"class M{i} implements Maker {{ make<T>(value:T):Box<T> {{ console.log('method',{i}); return new Box(value); }} }}"]
        if kind == "receiver":
            lines += [f"function use{i}(receiver:Maker):void {{ const box:Box<C{i}>=receiver.make(new C{i}()); console.log(box.value.tag); }}"]
        else:
            lines += [f"function use{i}(factory:Factory):void {{ const box:Box<C{i}>=factory(new C{i}()); console.log(box.value.tag); }}"]
        if kind == "captured_receiver":
            lines += [f"function read{i}(receiver:Maker):Factory {{ return receiver.make; }}"]
    for i in range(n):
        val = f"source{i}" if kind == "function" else f"new M{i}()"
        typ = "Factory" if kind == "function" else "Maker"
        binding = "let" if unknown else "const"
        lines += [f"{binding} root{i}:{{value:{typ}}}={{value:{val}}};", f"const alias{i}=(root{i}); const leaf{i}=alias{i}; const sibling{i}=root{i}; const spare{i}=sibling{i}.value;"]
        selected = f"leaf{i}.value"
        if kind == "captured_receiver":
            selected = f"read{i}({selected})"
        lines += [f"use{i}({selected});"]
    return "\n".join(lines)+"\n"

rows = []
for kind in ["function", "receiver", "captured_receiver"]:
    for n, unknown in [(10, False), (30, False), (60, False), (12, True)]:
        name = f"{kind}_{'unknown' if unknown else 'known'}{n}"
        entry = destination / (name+".pts")
        entry.write_text(source(kind,n,unknown))
        twin = entry.with_suffix(".mts")
        twin.write_text(entry.read_text())
        node, _ = run([Path.home()/".local/node/bin/node", "--no-warnings", "--experimental-transform-types", twin])
        hashes = {}
        for round_no in range(2):
            for label, helper in ([("base",base),("current",current)] if round_no == 0 else [("current",current),("base",base)]):
                cfile = destination / f"{name}.{label}.{round_no}.c"
                binary = destination / f"{name}.{label}.bin"
                mode = str(binary) if round_no == 0 else "emit"
                _, seconds = run([helper, entry, cfile, mode], timeout=300)
                code = cfile.read_bytes()
                pattern = rb"pts_fn_source(\d+)_C(\d+)\(" if kind == "function" else rb"pts_fn_M(\d+)_make_C(\d+)\("
                pairs = {(int(a),int(b)) for a,b in re.findall(pattern,code)}
                expected = {(i,j) for i in range(n) for j in range(n)} if label == "base" or unknown else {(i,i) for i in range(n)}
                assert pairs == expected, (name,label,round_no,len(pairs),len(expected),pairs.symmetric_difference(expected))
                digest = hashlib.sha256(code).hexdigest()
                if round_no:
                    assert hashes[label] == digest, ("nondeterministic",name,label)
                hashes[label] = digest
                if round_no == 0:
                    native, _ = run([binary])
                    assert native == node, ("native/Node",name,label,native,node)
                    binary.unlink()
                rows.append(dict(name=name,kind=kind,n=n,unknown=unknown,compiler=label,round=round_no,pairs=len(pairs),lines=code.count(b'\n'),bytes=len(code),sha256=digest,seconds=seconds))
                (destination/"rows.json").write_text(json.dumps(rows,indent=2))
        if unknown:
            assert hashes["base"] == hashes["current"], ("unknown changed", name)
        print(name, "PASS", flush=True)
print(json.dumps(dict(rows=len(rows),native_node_matches=24,commands=len(commands))))
