class Box<T> { constructor(public value:T){} }
type Factory = <T>(value:T)=>Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T>{return new Box(value);}
class M0 implements Maker { calls=0; make<T>(value:T):Box<T>{this.calls++;console.log("M0",this.calls);return new Box(value);} }
function use0(value:Factory):void{const box:Box<C0> = value(new C0());console.log("demand",box.value.tag);}
class C1 { tag=1; }
function source1<T>(value:T):Box<T>{return new Box(value);}
class M1 implements Maker { calls=0; make<T>(value:T):Box<T>{this.calls++;console.log("M1",this.calls);return new Box(value);} }
function use1(value:Factory):void{const box:Box<C1> = value(new C1());console.log("demand",box.value.tag);}
class C2 { tag=2; }
function source2<T>(value:T):Box<T>{return new Box(value);}
class M2 implements Maker { calls=0; make<T>(value:T):Box<T>{this.calls++;console.log("M2",this.calls);return new Box(value);} }
function use2(value:Factory):void{const box:Box<C2> = value(new C2());console.log("demand",box.value.tag);}
const selected0:Factory=source0;const other0:Factory=source1;
const root0=[{row:{items:[{value:selected0,other:other0}]}}];
const alias0=root0;const sibling0=alias0;
use0(alias0[0].row.items[0].value);
const selected1:Factory=source1;const other1:Factory=source2;
const root1=[{row:{items:[{value:selected1,other:other1}]}}];
const alias1=root1;const sibling1=alias1;
use1(alias1[0].row.items[0].value);
const selected2:Factory=source2;const other2:Factory=source0;
const root2=[{row:{items:[{value:selected2,other:other2}]}}];
const alias2=root2;const sibling2=alias2;
use2(alias2[0].row.items[0].value);
