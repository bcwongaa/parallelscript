import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, GOMAXPROCS="4", PTS_REQUIRE_NODE="1")
env["PATH"] = str(Path.home()/".local/go/bin")+":"+str(Path.home()/".local/node/bin")+":"+env["PATH"]

def snapshot():
    paths = subprocess.check_output(["git","ls-files","-z","--cached","--others","--exclude-standard","--","pts","cmd","internal"],cwd=repo).split(b'\0')
    return {os.fsdecode(p): hashlib.sha256((repo/os.fsdecode(p)).read_bytes()).hexdigest() for p in paths if p and Path(os.fsdecode(p)).suffix in {".go",".pts",".ts",".c",".h"}}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

start = time.monotonic()
before = snapshot()
(out/"before.json").write_text(json.dumps(before,indent=2))
with (out/"build.log").open("w") as log:
    build = subprocess.run(["make","build"],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert build.returncode == 0, "make build failed"
cli = digest(repo/"pts-bin/pts")
command = ["go","test","-count=1","-json","-p","4","-parallel","4","-timeout","40m","./pts/...","./cmd/pts/"]
with (out/"suite.jsonl").open("w") as stdout, (out/"suite.stderr").open("w") as stderr:
    test = subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr,timeout=3000)
after = snapshot()
(out/"after.json").write_text(json.dumps(after,indent=2))
counts=collections.Counter()
packages={}
corpus=collections.Counter()
failures=[]
for line in (out/"suite.jsonl").open():
    e=json.loads(line)
    action=e["Action"]
    name=e.get("Test","")
    if name and action in {"pass","skip","fail"}:
        counts[action]+=1
        if name.startswith("TestCorpusMatchesNode/"):
            corpus[action]+=1
        if action=="fail": failures.append(e)
    if not name and action in {"pass","skip","fail"}:
        packages[e["Package"]]=action
summary=dict(command=command,build_exit=build.returncode,suite_exit=test.returncode,counts=counts,corpus=corpus,packages=packages,failures=failures,sources=len(before),sources_unchanged=before==after,cli_before=cli,cli_after=digest(repo/"pts-bin/pts"),stderr_bytes=(out/"suite.stderr").stat().st_size,seconds=time.monotonic()-start)
(out/"summary.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2),flush=True)
assert test.returncode==0 and before==after and cli==summary["cli_after"] and all(v!="fail" for v in packages.values()), "frozen suite failed"
