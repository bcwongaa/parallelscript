class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T> { console.log('source',0); return new Box(value); }
class M0 implements Maker { make<T>(value:T):Box<T> { console.log('method',0); return new Box(value); } }
function use0(factory:Factory):void { const box:Box<C0>=factory(new C0()); console.log(box.value.tag); }
function read0(receiver:Maker):Factory { return receiver.make; }
class C1 { tag=1; }
function source1<T>(value:T):Box<T> { console.log('source',1); return new Box(value); }
class M1 implements Maker { make<T>(value:T):Box<T> { console.log('method',1); return new Box(value); } }
function use1(factory:Factory):void { const box:Box<C1>=factory(new C1()); console.log(box.value.tag); }
function read1(receiver:Maker):Factory { return receiver.make; }
class C2 { tag=2; }
function source2<T>(value:T):Box<T> { console.log('source',2); return new Box(value); }
class M2 implements Maker { make<T>(value:T):Box<T> { console.log('method',2); return new Box(value); } }
function use2(factory:Factory):void { const box:Box<C2>=factory(new C2()); console.log(box.value.tag); }
function read2(receiver:Maker):Factory { return receiver.make; }
class C3 { tag=3; }
function source3<T>(value:T):Box<T> { console.log('source',3); return new Box(value); }
class M3 implements Maker { make<T>(value:T):Box<T> { console.log('method',3); return new Box(value); } }
function use3(factory:Factory):void { const box:Box<C3>=factory(new C3()); console.log(box.value.tag); }
function read3(receiver:Maker):Factory { return receiver.make; }
class C4 { tag=4; }
function source4<T>(value:T):Box<T> { console.log('source',4); return new Box(value); }
class M4 implements Maker { make<T>(value:T):Box<T> { console.log('method',4); return new Box(value); } }
function use4(factory:Factory):void { const box:Box<C4>=factory(new C4()); console.log(box.value.tag); }
function read4(receiver:Maker):Factory { return receiver.make; }
class C5 { tag=5; }
function source5<T>(value:T):Box<T> { console.log('source',5); return new Box(value); }
class M5 implements Maker { make<T>(value:T):Box<T> { console.log('method',5); return new Box(value); } }
function use5(factory:Factory):void { const box:Box<C5>=factory(new C5()); console.log(box.value.tag); }
function read5(receiver:Maker):Factory { return receiver.make; }
class C6 { tag=6; }
function source6<T>(value:T):Box<T> { console.log('source',6); return new Box(value); }
class M6 implements Maker { make<T>(value:T):Box<T> { console.log('method',6); return new Box(value); } }
function use6(factory:Factory):void { const box:Box<C6>=factory(new C6()); console.log(box.value.tag); }
function read6(receiver:Maker):Factory { return receiver.make; }
class C7 { tag=7; }
function source7<T>(value:T):Box<T> { console.log('source',7); return new Box(value); }
class M7 implements Maker { make<T>(value:T):Box<T> { console.log('method',7); return new Box(value); } }
function use7(factory:Factory):void { const box:Box<C7>=factory(new C7()); console.log(box.value.tag); }
function read7(receiver:Maker):Factory { return receiver.make; }
class C8 { tag=8; }
function source8<T>(value:T):Box<T> { console.log('source',8); return new Box(value); }
class M8 implements Maker { make<T>(value:T):Box<T> { console.log('method',8); return new Box(value); } }
function use8(factory:Factory):void { const box:Box<C8>=factory(new C8()); console.log(box.value.tag); }
function read8(receiver:Maker):Factory { return receiver.make; }
class C9 { tag=9; }
function source9<T>(value:T):Box<T> { console.log('source',9); return new Box(value); }
class M9 implements Maker { make<T>(value:T):Box<T> { console.log('method',9); return new Box(value); } }
function use9(factory:Factory):void { const box:Box<C9>=factory(new C9()); console.log(box.value.tag); }
function read9(receiver:Maker):Factory { return receiver.make; }
class C10 { tag=10; }
function source10<T>(value:T):Box<T> { console.log('source',10); return new Box(value); }
class M10 implements Maker { make<T>(value:T):Box<T> { console.log('method',10); return new Box(value); } }
function use10(factory:Factory):void { const box:Box<C10>=factory(new C10()); console.log(box.value.tag); }
function read10(receiver:Maker):Factory { return receiver.make; }
class C11 { tag=11; }
function source11<T>(value:T):Box<T> { console.log('source',11); return new Box(value); }
class M11 implements Maker { make<T>(value:T):Box<T> { console.log('method',11); return new Box(value); } }
function use11(factory:Factory):void { const box:Box<C11>=factory(new C11()); console.log(box.value.tag); }
function read11(receiver:Maker):Factory { return receiver.make; }
class C12 { tag=12; }
function source12<T>(value:T):Box<T> { console.log('source',12); return new Box(value); }
class M12 implements Maker { make<T>(value:T):Box<T> { console.log('method',12); return new Box(value); } }
function use12(factory:Factory):void { const box:Box<C12>=factory(new C12()); console.log(box.value.tag); }
function read12(receiver:Maker):Factory { return receiver.make; }
class C13 { tag=13; }
function source13<T>(value:T):Box<T> { console.log('source',13); return new Box(value); }
class M13 implements Maker { make<T>(value:T):Box<T> { console.log('method',13); return new Box(value); } }
function use13(factory:Factory):void { const box:Box<C13>=factory(new C13()); console.log(box.value.tag); }
function read13(receiver:Maker):Factory { return receiver.make; }
class C14 { tag=14; }
function source14<T>(value:T):Box<T> { console.log('source',14); return new Box(value); }
class M14 implements Maker { make<T>(value:T):Box<T> { console.log('method',14); return new Box(value); } }
function use14(factory:Factory):void { const box:Box<C14>=factory(new C14()); console.log(box.value.tag); }
function read14(receiver:Maker):Factory { return receiver.make; }
class C15 { tag=15; }
function source15<T>(value:T):Box<T> { console.log('source',15); return new Box(value); }
class M15 implements Maker { make<T>(value:T):Box<T> { console.log('method',15); return new Box(value); } }
function use15(factory:Factory):void { const box:Box<C15>=factory(new C15()); console.log(box.value.tag); }
function read15(receiver:Maker):Factory { return receiver.make; }
class C16 { tag=16; }
function source16<T>(value:T):Box<T> { console.log('source',16); return new Box(value); }
class M16 implements Maker { make<T>(value:T):Box<T> { console.log('method',16); return new Box(value); } }
function use16(factory:Factory):void { const box:Box<C16>=factory(new C16()); console.log(box.value.tag); }
function read16(receiver:Maker):Factory { return receiver.make; }
class C17 { tag=17; }
function source17<T>(value:T):Box<T> { console.log('source',17); return new Box(value); }
class M17 implements Maker { make<T>(value:T):Box<T> { console.log('method',17); return new Box(value); } }
function use17(factory:Factory):void { const box:Box<C17>=factory(new C17()); console.log(box.value.tag); }
function read17(receiver:Maker):Factory { return receiver.make; }
class C18 { tag=18; }
function source18<T>(value:T):Box<T> { console.log('source',18); return new Box(value); }
class M18 implements Maker { make<T>(value:T):Box<T> { console.log('method',18); return new Box(value); } }
function use18(factory:Factory):void { const box:Box<C18>=factory(new C18()); console.log(box.value.tag); }
function read18(receiver:Maker):Factory { return receiver.make; }
class C19 { tag=19; }
function source19<T>(value:T):Box<T> { console.log('source',19); return new Box(value); }
class M19 implements Maker { make<T>(value:T):Box<T> { console.log('method',19); return new Box(value); } }
function use19(factory:Factory):void { const box:Box<C19>=factory(new C19()); console.log(box.value.tag); }
function read19(receiver:Maker):Factory { return receiver.make; }
class C20 { tag=20; }
function source20<T>(value:T):Box<T> { console.log('source',20); return new Box(value); }
class M20 implements Maker { make<T>(value:T):Box<T> { console.log('method',20); return new Box(value); } }
function use20(factory:Factory):void { const box:Box<C20>=factory(new C20()); console.log(box.value.tag); }
function read20(receiver:Maker):Factory { return receiver.make; }
class C21 { tag=21; }
function source21<T>(value:T):Box<T> { console.log('source',21); return new Box(value); }
class M21 implements Maker { make<T>(value:T):Box<T> { console.log('method',21); return new Box(value); } }
function use21(factory:Factory):void { const box:Box<C21>=factory(new C21()); console.log(box.value.tag); }
function read21(receiver:Maker):Factory { return receiver.make; }
class C22 { tag=22; }
function source22<T>(value:T):Box<T> { console.log('source',22); return new Box(value); }
class M22 implements Maker { make<T>(value:T):Box<T> { console.log('method',22); return new Box(value); } }
function use22(factory:Factory):void { const box:Box<C22>=factory(new C22()); console.log(box.value.tag); }
function read22(receiver:Maker):Factory { return receiver.make; }
class C23 { tag=23; }
function source23<T>(value:T):Box<T> { console.log('source',23); return new Box(value); }
class M23 implements Maker { make<T>(value:T):Box<T> { console.log('method',23); return new Box(value); } }
function use23(factory:Factory):void { const box:Box<C23>=factory(new C23()); console.log(box.value.tag); }
function read23(receiver:Maker):Factory { return receiver.make; }
class C24 { tag=24; }
function source24<T>(value:T):Box<T> { console.log('source',24); return new Box(value); }
class M24 implements Maker { make<T>(value:T):Box<T> { console.log('method',24); return new Box(value); } }
function use24(factory:Factory):void { const box:Box<C24>=factory(new C24()); console.log(box.value.tag); }
function read24(receiver:Maker):Factory { return receiver.make; }
class C25 { tag=25; }
function source25<T>(value:T):Box<T> { console.log('source',25); return new Box(value); }
class M25 implements Maker { make<T>(value:T):Box<T> { console.log('method',25); return new Box(value); } }
function use25(factory:Factory):void { const box:Box<C25>=factory(new C25()); console.log(box.value.tag); }
function read25(receiver:Maker):Factory { return receiver.make; }
class C26 { tag=26; }
function source26<T>(value:T):Box<T> { console.log('source',26); return new Box(value); }
class M26 implements Maker { make<T>(value:T):Box<T> { console.log('method',26); return new Box(value); } }
function use26(factory:Factory):void { const box:Box<C26>=factory(new C26()); console.log(box.value.tag); }
function read26(receiver:Maker):Factory { return receiver.make; }
class C27 { tag=27; }
function source27<T>(value:T):Box<T> { console.log('source',27); return new Box(value); }
class M27 implements Maker { make<T>(value:T):Box<T> { console.log('method',27); return new Box(value); } }
function use27(factory:Factory):void { const box:Box<C27>=factory(new C27()); console.log(box.value.tag); }
function read27(receiver:Maker):Factory { return receiver.make; }
class C28 { tag=28; }
function source28<T>(value:T):Box<T> { console.log('source',28); return new Box(value); }
class M28 implements Maker { make<T>(value:T):Box<T> { console.log('method',28); return new Box(value); } }
function use28(factory:Factory):void { const box:Box<C28>=factory(new C28()); console.log(box.value.tag); }
function read28(receiver:Maker):Factory { return receiver.make; }
class C29 { tag=29; }
function source29<T>(value:T):Box<T> { console.log('source',29); return new Box(value); }
class M29 implements Maker { make<T>(value:T):Box<T> { console.log('method',29); return new Box(value); } }
function use29(factory:Factory):void { const box:Box<C29>=factory(new C29()); console.log(box.value.tag); }
function read29(receiver:Maker):Factory { return receiver.make; }
class C30 { tag=30; }
function source30<T>(value:T):Box<T> { console.log('source',30); return new Box(value); }
class M30 implements Maker { make<T>(value:T):Box<T> { console.log('method',30); return new Box(value); } }
function use30(factory:Factory):void { const box:Box<C30>=factory(new C30()); console.log(box.value.tag); }
function read30(receiver:Maker):Factory { return receiver.make; }
class C31 { tag=31; }
function source31<T>(value:T):Box<T> { console.log('source',31); return new Box(value); }
class M31 implements Maker { make<T>(value:T):Box<T> { console.log('method',31); return new Box(value); } }
function use31(factory:Factory):void { const box:Box<C31>=factory(new C31()); console.log(box.value.tag); }
function read31(receiver:Maker):Factory { return receiver.make; }
class C32 { tag=32; }
function source32<T>(value:T):Box<T> { console.log('source',32); return new Box(value); }
class M32 implements Maker { make<T>(value:T):Box<T> { console.log('method',32); return new Box(value); } }
function use32(factory:Factory):void { const box:Box<C32>=factory(new C32()); console.log(box.value.tag); }
function read32(receiver:Maker):Factory { return receiver.make; }
class C33 { tag=33; }
function source33<T>(value:T):Box<T> { console.log('source',33); return new Box(value); }
class M33 implements Maker { make<T>(value:T):Box<T> { console.log('method',33); return new Box(value); } }
function use33(factory:Factory):void { const box:Box<C33>=factory(new C33()); console.log(box.value.tag); }
function read33(receiver:Maker):Factory { return receiver.make; }
class C34 { tag=34; }
function source34<T>(value:T):Box<T> { console.log('source',34); return new Box(value); }
class M34 implements Maker { make<T>(value:T):Box<T> { console.log('method',34); return new Box(value); } }
function use34(factory:Factory):void { const box:Box<C34>=factory(new C34()); console.log(box.value.tag); }
function read34(receiver:Maker):Factory { return receiver.make; }
class C35 { tag=35; }
function source35<T>(value:T):Box<T> { console.log('source',35); return new Box(value); }
class M35 implements Maker { make<T>(value:T):Box<T> { console.log('method',35); return new Box(value); } }
function use35(factory:Factory):void { const box:Box<C35>=factory(new C35()); console.log(box.value.tag); }
function read35(receiver:Maker):Factory { return receiver.make; }
class C36 { tag=36; }
function source36<T>(value:T):Box<T> { console.log('source',36); return new Box(value); }
class M36 implements Maker { make<T>(value:T):Box<T> { console.log('method',36); return new Box(value); } }
function use36(factory:Factory):void { const box:Box<C36>=factory(new C36()); console.log(box.value.tag); }
function read36(receiver:Maker):Factory { return receiver.make; }
class C37 { tag=37; }
function source37<T>(value:T):Box<T> { console.log('source',37); return new Box(value); }
class M37 implements Maker { make<T>(value:T):Box<T> { console.log('method',37); return new Box(value); } }
function use37(factory:Factory):void { const box:Box<C37>=factory(new C37()); console.log(box.value.tag); }
function read37(receiver:Maker):Factory { return receiver.make; }
class C38 { tag=38; }
function source38<T>(value:T):Box<T> { console.log('source',38); return new Box(value); }
class M38 implements Maker { make<T>(value:T):Box<T> { console.log('method',38); return new Box(value); } }
function use38(factory:Factory):void { const box:Box<C38>=factory(new C38()); console.log(box.value.tag); }
function read38(receiver:Maker):Factory { return receiver.make; }
class C39 { tag=39; }
function source39<T>(value:T):Box<T> { console.log('source',39); return new Box(value); }
class M39 implements Maker { make<T>(value:T):Box<T> { console.log('method',39); return new Box(value); } }
function use39(factory:Factory):void { const box:Box<C39>=factory(new C39()); console.log(box.value.tag); }
function read39(receiver:Maker):Factory { return receiver.make; }
class C40 { tag=40; }
function source40<T>(value:T):Box<T> { console.log('source',40); return new Box(value); }
class M40 implements Maker { make<T>(value:T):Box<T> { console.log('method',40); return new Box(value); } }
function use40(factory:Factory):void { const box:Box<C40>=factory(new C40()); console.log(box.value.tag); }
function read40(receiver:Maker):Factory { return receiver.make; }
class C41 { tag=41; }
function source41<T>(value:T):Box<T> { console.log('source',41); return new Box(value); }
class M41 implements Maker { make<T>(value:T):Box<T> { console.log('method',41); return new Box(value); } }
function use41(factory:Factory):void { const box:Box<C41>=factory(new C41()); console.log(box.value.tag); }
function read41(receiver:Maker):Factory { return receiver.make; }
class C42 { tag=42; }
function source42<T>(value:T):Box<T> { console.log('source',42); return new Box(value); }
class M42 implements Maker { make<T>(value:T):Box<T> { console.log('method',42); return new Box(value); } }
function use42(factory:Factory):void { const box:Box<C42>=factory(new C42()); console.log(box.value.tag); }
function read42(receiver:Maker):Factory { return receiver.make; }
class C43 { tag=43; }
function source43<T>(value:T):Box<T> { console.log('source',43); return new Box(value); }
class M43 implements Maker { make<T>(value:T):Box<T> { console.log('method',43); return new Box(value); } }
function use43(factory:Factory):void { const box:Box<C43>=factory(new C43()); console.log(box.value.tag); }
function read43(receiver:Maker):Factory { return receiver.make; }
class C44 { tag=44; }
function source44<T>(value:T):Box<T> { console.log('source',44); return new Box(value); }
class M44 implements Maker { make<T>(value:T):Box<T> { console.log('method',44); return new Box(value); } }
function use44(factory:Factory):void { const box:Box<C44>=factory(new C44()); console.log(box.value.tag); }
function read44(receiver:Maker):Factory { return receiver.make; }
class C45 { tag=45; }
function source45<T>(value:T):Box<T> { console.log('source',45); return new Box(value); }
class M45 implements Maker { make<T>(value:T):Box<T> { console.log('method',45); return new Box(value); } }
function use45(factory:Factory):void { const box:Box<C45>=factory(new C45()); console.log(box.value.tag); }
function read45(receiver:Maker):Factory { return receiver.make; }
class C46 { tag=46; }
function source46<T>(value:T):Box<T> { console.log('source',46); return new Box(value); }
class M46 implements Maker { make<T>(value:T):Box<T> { console.log('method',46); return new Box(value); } }
function use46(factory:Factory):void { const box:Box<C46>=factory(new C46()); console.log(box.value.tag); }
function read46(receiver:Maker):Factory { return receiver.make; }
class C47 { tag=47; }
function source47<T>(value:T):Box<T> { console.log('source',47); return new Box(value); }
class M47 implements Maker { make<T>(value:T):Box<T> { console.log('method',47); return new Box(value); } }
function use47(factory:Factory):void { const box:Box<C47>=factory(new C47()); console.log(box.value.tag); }
function read47(receiver:Maker):Factory { return receiver.make; }
class C48 { tag=48; }
function source48<T>(value:T):Box<T> { console.log('source',48); return new Box(value); }
class M48 implements Maker { make<T>(value:T):Box<T> { console.log('method',48); return new Box(value); } }
function use48(factory:Factory):void { const box:Box<C48>=factory(new C48()); console.log(box.value.tag); }
function read48(receiver:Maker):Factory { return receiver.make; }
class C49 { tag=49; }
function source49<T>(value:T):Box<T> { console.log('source',49); return new Box(value); }
class M49 implements Maker { make<T>(value:T):Box<T> { console.log('method',49); return new Box(value); } }
function use49(factory:Factory):void { const box:Box<C49>=factory(new C49()); console.log(box.value.tag); }
function read49(receiver:Maker):Factory { return receiver.make; }
class C50 { tag=50; }
function source50<T>(value:T):Box<T> { console.log('source',50); return new Box(value); }
class M50 implements Maker { make<T>(value:T):Box<T> { console.log('method',50); return new Box(value); } }
function use50(factory:Factory):void { const box:Box<C50>=factory(new C50()); console.log(box.value.tag); }
function read50(receiver:Maker):Factory { return receiver.make; }
class C51 { tag=51; }
function source51<T>(value:T):Box<T> { console.log('source',51); return new Box(value); }
class M51 implements Maker { make<T>(value:T):Box<T> { console.log('method',51); return new Box(value); } }
function use51(factory:Factory):void { const box:Box<C51>=factory(new C51()); console.log(box.value.tag); }
function read51(receiver:Maker):Factory { return receiver.make; }
class C52 { tag=52; }
function source52<T>(value:T):Box<T> { console.log('source',52); return new Box(value); }
class M52 implements Maker { make<T>(value:T):Box<T> { console.log('method',52); return new Box(value); } }
function use52(factory:Factory):void { const box:Box<C52>=factory(new C52()); console.log(box.value.tag); }
function read52(receiver:Maker):Factory { return receiver.make; }
class C53 { tag=53; }
function source53<T>(value:T):Box<T> { console.log('source',53); return new Box(value); }
class M53 implements Maker { make<T>(value:T):Box<T> { console.log('method',53); return new Box(value); } }
function use53(factory:Factory):void { const box:Box<C53>=factory(new C53()); console.log(box.value.tag); }
function read53(receiver:Maker):Factory { return receiver.make; }
class C54 { tag=54; }
function source54<T>(value:T):Box<T> { console.log('source',54); return new Box(value); }
class M54 implements Maker { make<T>(value:T):Box<T> { console.log('method',54); return new Box(value); } }
function use54(factory:Factory):void { const box:Box<C54>=factory(new C54()); console.log(box.value.tag); }
function read54(receiver:Maker):Factory { return receiver.make; }
class C55 { tag=55; }
function source55<T>(value:T):Box<T> { console.log('source',55); return new Box(value); }
class M55 implements Maker { make<T>(value:T):Box<T> { console.log('method',55); return new Box(value); } }
function use55(factory:Factory):void { const box:Box<C55>=factory(new C55()); console.log(box.value.tag); }
function read55(receiver:Maker):Factory { return receiver.make; }
class C56 { tag=56; }
function source56<T>(value:T):Box<T> { console.log('source',56); return new Box(value); }
class M56 implements Maker { make<T>(value:T):Box<T> { console.log('method',56); return new Box(value); } }
function use56(factory:Factory):void { const box:Box<C56>=factory(new C56()); console.log(box.value.tag); }
function read56(receiver:Maker):Factory { return receiver.make; }
class C57 { tag=57; }
function source57<T>(value:T):Box<T> { console.log('source',57); return new Box(value); }
class M57 implements Maker { make<T>(value:T):Box<T> { console.log('method',57); return new Box(value); } }
function use57(factory:Factory):void { const box:Box<C57>=factory(new C57()); console.log(box.value.tag); }
function read57(receiver:Maker):Factory { return receiver.make; }
class C58 { tag=58; }
function source58<T>(value:T):Box<T> { console.log('source',58); return new Box(value); }
class M58 implements Maker { make<T>(value:T):Box<T> { console.log('method',58); return new Box(value); } }
function use58(factory:Factory):void { const box:Box<C58>=factory(new C58()); console.log(box.value.tag); }
function read58(receiver:Maker):Factory { return receiver.make; }
class C59 { tag=59; }
function source59<T>(value:T):Box<T> { console.log('source',59); return new Box(value); }
class M59 implements Maker { make<T>(value:T):Box<T> { console.log('method',59); return new Box(value); } }
function use59(factory:Factory):void { const box:Box<C59>=factory(new C59()); console.log(box.value.tag); }
function read59(receiver:Maker):Factory { return receiver.make; }
const selected0:Maker=new M0();
const root0={inner:[{value:selected0}]};
const alias0=(root0); const leaf0=alias0; const sibling0=root0; const spare0=sibling0.inner[0].value;
use0(read0(leaf0.inner[0].value));
const selected1:Maker=new M1();
const root1={inner:[{value:selected1}]};
const alias1=(root1); const leaf1=alias1; const sibling1=root1; const spare1=sibling1.inner[0].value;
use1(read1(leaf1.inner[0].value));
const selected2:Maker=new M2();
const root2={inner:[{value:selected2}]};
const alias2=(root2); const leaf2=alias2; const sibling2=root2; const spare2=sibling2.inner[0].value;
use2(read2(leaf2.inner[0].value));
const selected3:Maker=new M3();
const root3={inner:[{value:selected3}]};
const alias3=(root3); const leaf3=alias3; const sibling3=root3; const spare3=sibling3.inner[0].value;
use3(read3(leaf3.inner[0].value));
const selected4:Maker=new M4();
const root4={inner:[{value:selected4}]};
const alias4=(root4); const leaf4=alias4; const sibling4=root4; const spare4=sibling4.inner[0].value;
use4(read4(leaf4.inner[0].value));
const selected5:Maker=new M5();
const root5={inner:[{value:selected5}]};
const alias5=(root5); const leaf5=alias5; const sibling5=root5; const spare5=sibling5.inner[0].value;
use5(read5(leaf5.inner[0].value));
const selected6:Maker=new M6();
const root6={inner:[{value:selected6}]};
const alias6=(root6); const leaf6=alias6; const sibling6=root6; const spare6=sibling6.inner[0].value;
use6(read6(leaf6.inner[0].value));
const selected7:Maker=new M7();
const root7={inner:[{value:selected7}]};
const alias7=(root7); const leaf7=alias7; const sibling7=root7; const spare7=sibling7.inner[0].value;
use7(read7(leaf7.inner[0].value));
const selected8:Maker=new M8();
const root8={inner:[{value:selected8}]};
const alias8=(root8); const leaf8=alias8; const sibling8=root8; const spare8=sibling8.inner[0].value;
use8(read8(leaf8.inner[0].value));
const selected9:Maker=new M9();
const root9={inner:[{value:selected9}]};
const alias9=(root9); const leaf9=alias9; const sibling9=root9; const spare9=sibling9.inner[0].value;
use9(read9(leaf9.inner[0].value));
const selected10:Maker=new M10();
const root10={inner:[{value:selected10}]};
const alias10=(root10); const leaf10=alias10; const sibling10=root10; const spare10=sibling10.inner[0].value;
use10(read10(leaf10.inner[0].value));
const selected11:Maker=new M11();
const root11={inner:[{value:selected11}]};
const alias11=(root11); const leaf11=alias11; const sibling11=root11; const spare11=sibling11.inner[0].value;
use11(read11(leaf11.inner[0].value));
const selected12:Maker=new M12();
const root12={inner:[{value:selected12}]};
const alias12=(root12); const leaf12=alias12; const sibling12=root12; const spare12=sibling12.inner[0].value;
use12(read12(leaf12.inner[0].value));
const selected13:Maker=new M13();
const root13={inner:[{value:selected13}]};
const alias13=(root13); const leaf13=alias13; const sibling13=root13; const spare13=sibling13.inner[0].value;
use13(read13(leaf13.inner[0].value));
const selected14:Maker=new M14();
const root14={inner:[{value:selected14}]};
const alias14=(root14); const leaf14=alias14; const sibling14=root14; const spare14=sibling14.inner[0].value;
use14(read14(leaf14.inner[0].value));
const selected15:Maker=new M15();
const root15={inner:[{value:selected15}]};
const alias15=(root15); const leaf15=alias15; const sibling15=root15; const spare15=sibling15.inner[0].value;
use15(read15(leaf15.inner[0].value));
const selected16:Maker=new M16();
const root16={inner:[{value:selected16}]};
const alias16=(root16); const leaf16=alias16; const sibling16=root16; const spare16=sibling16.inner[0].value;
use16(read16(leaf16.inner[0].value));
const selected17:Maker=new M17();
const root17={inner:[{value:selected17}]};
const alias17=(root17); const leaf17=alias17; const sibling17=root17; const spare17=sibling17.inner[0].value;
use17(read17(leaf17.inner[0].value));
const selected18:Maker=new M18();
const root18={inner:[{value:selected18}]};
const alias18=(root18); const leaf18=alias18; const sibling18=root18; const spare18=sibling18.inner[0].value;
use18(read18(leaf18.inner[0].value));
const selected19:Maker=new M19();
const root19={inner:[{value:selected19}]};
const alias19=(root19); const leaf19=alias19; const sibling19=root19; const spare19=sibling19.inner[0].value;
use19(read19(leaf19.inner[0].value));
const selected20:Maker=new M20();
const root20={inner:[{value:selected20}]};
const alias20=(root20); const leaf20=alias20; const sibling20=root20; const spare20=sibling20.inner[0].value;
use20(read20(leaf20.inner[0].value));
const selected21:Maker=new M21();
const root21={inner:[{value:selected21}]};
const alias21=(root21); const leaf21=alias21; const sibling21=root21; const spare21=sibling21.inner[0].value;
use21(read21(leaf21.inner[0].value));
const selected22:Maker=new M22();
const root22={inner:[{value:selected22}]};
const alias22=(root22); const leaf22=alias22; const sibling22=root22; const spare22=sibling22.inner[0].value;
use22(read22(leaf22.inner[0].value));
const selected23:Maker=new M23();
const root23={inner:[{value:selected23}]};
const alias23=(root23); const leaf23=alias23; const sibling23=root23; const spare23=sibling23.inner[0].value;
use23(read23(leaf23.inner[0].value));
const selected24:Maker=new M24();
const root24={inner:[{value:selected24}]};
const alias24=(root24); const leaf24=alias24; const sibling24=root24; const spare24=sibling24.inner[0].value;
use24(read24(leaf24.inner[0].value));
const selected25:Maker=new M25();
const root25={inner:[{value:selected25}]};
const alias25=(root25); const leaf25=alias25; const sibling25=root25; const spare25=sibling25.inner[0].value;
use25(read25(leaf25.inner[0].value));
const selected26:Maker=new M26();
const root26={inner:[{value:selected26}]};
const alias26=(root26); const leaf26=alias26; const sibling26=root26; const spare26=sibling26.inner[0].value;
use26(read26(leaf26.inner[0].value));
const selected27:Maker=new M27();
const root27={inner:[{value:selected27}]};
const alias27=(root27); const leaf27=alias27; const sibling27=root27; const spare27=sibling27.inner[0].value;
use27(read27(leaf27.inner[0].value));
const selected28:Maker=new M28();
const root28={inner:[{value:selected28}]};
const alias28=(root28); const leaf28=alias28; const sibling28=root28; const spare28=sibling28.inner[0].value;
use28(read28(leaf28.inner[0].value));
const selected29:Maker=new M29();
const root29={inner:[{value:selected29}]};
const alias29=(root29); const leaf29=alias29; const sibling29=root29; const spare29=sibling29.inner[0].value;
use29(read29(leaf29.inner[0].value));
const selected30:Maker=new M30();
const root30={inner:[{value:selected30}]};
const alias30=(root30); const leaf30=alias30; const sibling30=root30; const spare30=sibling30.inner[0].value;
use30(read30(leaf30.inner[0].value));
const selected31:Maker=new M31();
const root31={inner:[{value:selected31}]};
const alias31=(root31); const leaf31=alias31; const sibling31=root31; const spare31=sibling31.inner[0].value;
use31(read31(leaf31.inner[0].value));
const selected32:Maker=new M32();
const root32={inner:[{value:selected32}]};
const alias32=(root32); const leaf32=alias32; const sibling32=root32; const spare32=sibling32.inner[0].value;
use32(read32(leaf32.inner[0].value));
const selected33:Maker=new M33();
const root33={inner:[{value:selected33}]};
const alias33=(root33); const leaf33=alias33; const sibling33=root33; const spare33=sibling33.inner[0].value;
use33(read33(leaf33.inner[0].value));
const selected34:Maker=new M34();
const root34={inner:[{value:selected34}]};
const alias34=(root34); const leaf34=alias34; const sibling34=root34; const spare34=sibling34.inner[0].value;
use34(read34(leaf34.inner[0].value));
const selected35:Maker=new M35();
const root35={inner:[{value:selected35}]};
const alias35=(root35); const leaf35=alias35; const sibling35=root35; const spare35=sibling35.inner[0].value;
use35(read35(leaf35.inner[0].value));
const selected36:Maker=new M36();
const root36={inner:[{value:selected36}]};
const alias36=(root36); const leaf36=alias36; const sibling36=root36; const spare36=sibling36.inner[0].value;
use36(read36(leaf36.inner[0].value));
const selected37:Maker=new M37();
const root37={inner:[{value:selected37}]};
const alias37=(root37); const leaf37=alias37; const sibling37=root37; const spare37=sibling37.inner[0].value;
use37(read37(leaf37.inner[0].value));
const selected38:Maker=new M38();
const root38={inner:[{value:selected38}]};
const alias38=(root38); const leaf38=alias38; const sibling38=root38; const spare38=sibling38.inner[0].value;
use38(read38(leaf38.inner[0].value));
const selected39:Maker=new M39();
const root39={inner:[{value:selected39}]};
const alias39=(root39); const leaf39=alias39; const sibling39=root39; const spare39=sibling39.inner[0].value;
use39(read39(leaf39.inner[0].value));
const selected40:Maker=new M40();
const root40={inner:[{value:selected40}]};
const alias40=(root40); const leaf40=alias40; const sibling40=root40; const spare40=sibling40.inner[0].value;
use40(read40(leaf40.inner[0].value));
const selected41:Maker=new M41();
const root41={inner:[{value:selected41}]};
const alias41=(root41); const leaf41=alias41; const sibling41=root41; const spare41=sibling41.inner[0].value;
use41(read41(leaf41.inner[0].value));
const selected42:Maker=new M42();
const root42={inner:[{value:selected42}]};
const alias42=(root42); const leaf42=alias42; const sibling42=root42; const spare42=sibling42.inner[0].value;
use42(read42(leaf42.inner[0].value));
const selected43:Maker=new M43();
const root43={inner:[{value:selected43}]};
const alias43=(root43); const leaf43=alias43; const sibling43=root43; const spare43=sibling43.inner[0].value;
use43(read43(leaf43.inner[0].value));
const selected44:Maker=new M44();
const root44={inner:[{value:selected44}]};
const alias44=(root44); const leaf44=alias44; const sibling44=root44; const spare44=sibling44.inner[0].value;
use44(read44(leaf44.inner[0].value));
const selected45:Maker=new M45();
const root45={inner:[{value:selected45}]};
const alias45=(root45); const leaf45=alias45; const sibling45=root45; const spare45=sibling45.inner[0].value;
use45(read45(leaf45.inner[0].value));
const selected46:Maker=new M46();
const root46={inner:[{value:selected46}]};
const alias46=(root46); const leaf46=alias46; const sibling46=root46; const spare46=sibling46.inner[0].value;
use46(read46(leaf46.inner[0].value));
const selected47:Maker=new M47();
const root47={inner:[{value:selected47}]};
const alias47=(root47); const leaf47=alias47; const sibling47=root47; const spare47=sibling47.inner[0].value;
use47(read47(leaf47.inner[0].value));
const selected48:Maker=new M48();
const root48={inner:[{value:selected48}]};
const alias48=(root48); const leaf48=alias48; const sibling48=root48; const spare48=sibling48.inner[0].value;
use48(read48(leaf48.inner[0].value));
const selected49:Maker=new M49();
const root49={inner:[{value:selected49}]};
const alias49=(root49); const leaf49=alias49; const sibling49=root49; const spare49=sibling49.inner[0].value;
use49(read49(leaf49.inner[0].value));
const selected50:Maker=new M50();
const root50={inner:[{value:selected50}]};
const alias50=(root50); const leaf50=alias50; const sibling50=root50; const spare50=sibling50.inner[0].value;
use50(read50(leaf50.inner[0].value));
const selected51:Maker=new M51();
const root51={inner:[{value:selected51}]};
const alias51=(root51); const leaf51=alias51; const sibling51=root51; const spare51=sibling51.inner[0].value;
use51(read51(leaf51.inner[0].value));
const selected52:Maker=new M52();
const root52={inner:[{value:selected52}]};
const alias52=(root52); const leaf52=alias52; const sibling52=root52; const spare52=sibling52.inner[0].value;
use52(read52(leaf52.inner[0].value));
const selected53:Maker=new M53();
const root53={inner:[{value:selected53}]};
const alias53=(root53); const leaf53=alias53; const sibling53=root53; const spare53=sibling53.inner[0].value;
use53(read53(leaf53.inner[0].value));
const selected54:Maker=new M54();
const root54={inner:[{value:selected54}]};
const alias54=(root54); const leaf54=alias54; const sibling54=root54; const spare54=sibling54.inner[0].value;
use54(read54(leaf54.inner[0].value));
const selected55:Maker=new M55();
const root55={inner:[{value:selected55}]};
const alias55=(root55); const leaf55=alias55; const sibling55=root55; const spare55=sibling55.inner[0].value;
use55(read55(leaf55.inner[0].value));
const selected56:Maker=new M56();
const root56={inner:[{value:selected56}]};
const alias56=(root56); const leaf56=alias56; const sibling56=root56; const spare56=sibling56.inner[0].value;
use56(read56(leaf56.inner[0].value));
const selected57:Maker=new M57();
const root57={inner:[{value:selected57}]};
const alias57=(root57); const leaf57=alias57; const sibling57=root57; const spare57=sibling57.inner[0].value;
use57(read57(leaf57.inner[0].value));
const selected58:Maker=new M58();
const root58={inner:[{value:selected58}]};
const alias58=(root58); const leaf58=alias58; const sibling58=root58; const spare58=sibling58.inner[0].value;
use58(read58(leaf58.inner[0].value));
const selected59:Maker=new M59();
const root59={inner:[{value:selected59}]};
const alias59=(root59); const leaf59=alias59; const sibling59=root59; const spare59=sibling59.inner[0].value;
use59(read59(leaf59.inner[0].value));
