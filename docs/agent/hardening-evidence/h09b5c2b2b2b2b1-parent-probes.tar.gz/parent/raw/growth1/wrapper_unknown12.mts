class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value:T) => Box<T>;
interface Maker { make<T>(value:T):Box<T>; }
class C0 { tag=0; }
function source0<T>(value:T):Box<T> { console.log('source',0); return new Box(value); }
class M0 implements Maker { make<T>(value:T):Box<T> { console.log('method',0); return new Box(value); } }
function use0(factory:Factory):void { const box:Box<C0>=factory(new C0()); console.log(box.value.tag); }
function read0():Factory { const receiver:Maker=new M0(); return receiver.make; }
class C1 { tag=1; }
function source1<T>(value:T):Box<T> { console.log('source',1); return new Box(value); }
class M1 implements Maker { make<T>(value:T):Box<T> { console.log('method',1); return new Box(value); } }
function use1(factory:Factory):void { const box:Box<C1>=factory(new C1()); console.log(box.value.tag); }
function read1():Factory { const receiver:Maker=new M1(); return receiver.make; }
class C2 { tag=2; }
function source2<T>(value:T):Box<T> { console.log('source',2); return new Box(value); }
class M2 implements Maker { make<T>(value:T):Box<T> { console.log('method',2); return new Box(value); } }
function use2(factory:Factory):void { const box:Box<C2>=factory(new C2()); console.log(box.value.tag); }
function read2():Factory { const receiver:Maker=new M2(); return receiver.make; }
class C3 { tag=3; }
function source3<T>(value:T):Box<T> { console.log('source',3); return new Box(value); }
class M3 implements Maker { make<T>(value:T):Box<T> { console.log('method',3); return new Box(value); } }
function use3(factory:Factory):void { const box:Box<C3>=factory(new C3()); console.log(box.value.tag); }
function read3():Factory { const receiver:Maker=new M3(); return receiver.make; }
class C4 { tag=4; }
function source4<T>(value:T):Box<T> { console.log('source',4); return new Box(value); }
class M4 implements Maker { make<T>(value:T):Box<T> { console.log('method',4); return new Box(value); } }
function use4(factory:Factory):void { const box:Box<C4>=factory(new C4()); console.log(box.value.tag); }
function read4():Factory { const receiver:Maker=new M4(); return receiver.make; }
class C5 { tag=5; }
function source5<T>(value:T):Box<T> { console.log('source',5); return new Box(value); }
class M5 implements Maker { make<T>(value:T):Box<T> { console.log('method',5); return new Box(value); } }
function use5(factory:Factory):void { const box:Box<C5>=factory(new C5()); console.log(box.value.tag); }
function read5():Factory { const receiver:Maker=new M5(); return receiver.make; }
class C6 { tag=6; }
function source6<T>(value:T):Box<T> { console.log('source',6); return new Box(value); }
class M6 implements Maker { make<T>(value:T):Box<T> { console.log('method',6); return new Box(value); } }
function use6(factory:Factory):void { const box:Box<C6>=factory(new C6()); console.log(box.value.tag); }
function read6():Factory { const receiver:Maker=new M6(); return receiver.make; }
class C7 { tag=7; }
function source7<T>(value:T):Box<T> { console.log('source',7); return new Box(value); }
class M7 implements Maker { make<T>(value:T):Box<T> { console.log('method',7); return new Box(value); } }
function use7(factory:Factory):void { const box:Box<C7>=factory(new C7()); console.log(box.value.tag); }
function read7():Factory { const receiver:Maker=new M7(); return receiver.make; }
class C8 { tag=8; }
function source8<T>(value:T):Box<T> { console.log('source',8); return new Box(value); }
class M8 implements Maker { make<T>(value:T):Box<T> { console.log('method',8); return new Box(value); } }
function use8(factory:Factory):void { const box:Box<C8>=factory(new C8()); console.log(box.value.tag); }
function read8():Factory { const receiver:Maker=new M8(); return receiver.make; }
class C9 { tag=9; }
function source9<T>(value:T):Box<T> { console.log('source',9); return new Box(value); }
class M9 implements Maker { make<T>(value:T):Box<T> { console.log('method',9); return new Box(value); } }
function use9(factory:Factory):void { const box:Box<C9>=factory(new C9()); console.log(box.value.tag); }
function read9():Factory { const receiver:Maker=new M9(); return receiver.make; }
class C10 { tag=10; }
function source10<T>(value:T):Box<T> { console.log('source',10); return new Box(value); }
class M10 implements Maker { make<T>(value:T):Box<T> { console.log('method',10); return new Box(value); } }
function use10(factory:Factory):void { const box:Box<C10>=factory(new C10()); console.log(box.value.tag); }
function read10():Factory { const receiver:Maker=new M10(); return receiver.make; }
class C11 { tag=11; }
function source11<T>(value:T):Box<T> { console.log('source',11); return new Box(value); }
class M11 implements Maker { make<T>(value:T):Box<T> { console.log('method',11); return new Box(value); } }
function use11(factory:Factory):void { const box:Box<C11>=factory(new C11()); console.log(box.value.tag); }
function read11():Factory { const receiver:Maker=new M11(); return receiver.make; }
const selected0:Factory=read0();
let root0={inner:[{value:selected0}]};
const alias0=(root0); const leaf0=alias0; const sibling0=root0; const spare0=sibling0.inner[0].value;
use0(leaf0.inner[0].value);
const selected1:Factory=read1();
let root1={inner:[{value:selected1}]};
const alias1=(root1); const leaf1=alias1; const sibling1=root1; const spare1=sibling1.inner[0].value;
use1(leaf1.inner[0].value);
const selected2:Factory=read2();
let root2={inner:[{value:selected2}]};
const alias2=(root2); const leaf2=alias2; const sibling2=root2; const spare2=sibling2.inner[0].value;
use2(leaf2.inner[0].value);
const selected3:Factory=read3();
let root3={inner:[{value:selected3}]};
const alias3=(root3); const leaf3=alias3; const sibling3=root3; const spare3=sibling3.inner[0].value;
use3(leaf3.inner[0].value);
const selected4:Factory=read4();
let root4={inner:[{value:selected4}]};
const alias4=(root4); const leaf4=alias4; const sibling4=root4; const spare4=sibling4.inner[0].value;
use4(leaf4.inner[0].value);
const selected5:Factory=read5();
let root5={inner:[{value:selected5}]};
const alias5=(root5); const leaf5=alias5; const sibling5=root5; const spare5=sibling5.inner[0].value;
use5(leaf5.inner[0].value);
const selected6:Factory=read6();
let root6={inner:[{value:selected6}]};
const alias6=(root6); const leaf6=alias6; const sibling6=root6; const spare6=sibling6.inner[0].value;
use6(leaf6.inner[0].value);
const selected7:Factory=read7();
let root7={inner:[{value:selected7}]};
const alias7=(root7); const leaf7=alias7; const sibling7=root7; const spare7=sibling7.inner[0].value;
use7(leaf7.inner[0].value);
const selected8:Factory=read8();
let root8={inner:[{value:selected8}]};
const alias8=(root8); const leaf8=alias8; const sibling8=root8; const spare8=sibling8.inner[0].value;
use8(leaf8.inner[0].value);
const selected9:Factory=read9();
let root9={inner:[{value:selected9}]};
const alias9=(root9); const leaf9=alias9; const sibling9=root9; const spare9=sibling9.inner[0].value;
use9(leaf9.inner[0].value);
const selected10:Factory=read10();
let root10={inner:[{value:selected10}]};
const alias10=(root10); const leaf10=alias10; const sibling10=root10; const spare10=sibling10.inner[0].value;
use10(leaf10.inner[0].value);
const selected11:Factory=read11();
let root11={inner:[{value:selected11}]};
const alias11=(root11); const leaf11=alias11; const sibling11=root11; const spare11=sibling11.inner[0].value;
use11(leaf11.inner[0].value);
