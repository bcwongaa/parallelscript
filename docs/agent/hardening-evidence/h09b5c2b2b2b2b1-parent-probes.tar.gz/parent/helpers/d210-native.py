import json
import os
from pathlib import Path
import subprocess
import sys

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS="1")
commands=[]
def run(args):
    p=subprocess.run(list(map(str,args)),cwd=repo,env=env,capture_output=True,text=True,timeout=300)
    commands.append(dict(command=list(map(str,args)),exit=p.returncode,stdout=p.stdout,stderr=p.stderr))
    (out/"commands.json").write_text(json.dumps(commands,indent=2))
    assert p.returncode==0, commands[-1]
    return p.stdout
entry=repo/"pts/tests/run/generic_nested_container_sources.pts"
twin=out/"fixture.mts"
twin.write_bytes(entry.read_bytes())
node=run([Path.home()/".local/node/bin/node","--no-warnings","--experimental-transform-types",twin])
expected="\n".join(line.removeprefix("// ") for line in entry.read_text().split("// expect:\n",1)[1].splitlines())+"\n"
assert node==expected,(node,expected)
for label in ["base","current"]:
    helper=repo/("pts-bin/d210-"+label)
    cli=repo/("pts-bin/d210-base-cli" if label=="base" else "pts-bin/pts")
    for mode in ["strict","default"]:
        binary=out/(label+"-"+mode+".bin")
        if mode=="strict":
            cfile=out/(label+".c")
            run([helper,entry,cfile,binary])
            assert "#line " in cfile.read_text(),"missing source directives"
        else:
            run([cli,"build",entry,"-o",binary])
        native=run([binary])
        assert native==node,(label,mode,native,node)
        binary.unlink()
summary=dict(native_node_matches=4,expected_lines=len(node.splitlines()),commands=len(commands))
(out/"summary.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)
