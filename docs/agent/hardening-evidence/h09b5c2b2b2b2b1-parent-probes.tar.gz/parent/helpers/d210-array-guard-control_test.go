package lower

import (
	"testing"

	"gotest.tools/v3/assert"
)

func TestD210ArrayGuardReachability(t *testing.T) {
	body := "const root = { branch: [first, second], plain: first }; const alias = root; const other = alias;\n"
	t.Run("original_unmodified_control", func(t *testing.T) {
		l, probe := valueFlowProbe(t, literalProjectionPrelude(false)+body+"const probe = other.branch[0]; probe;")
		steps := maxValueFlowSteps
		assert.DeepEqual(t, returnedSourceNames(l.valueSources(probe, &steps, 0)), []string{"first"})
	})
	t.Run("typed_unmodified_control", func(t *testing.T) {
		l, probe := valueFlowProbe(t, nestedContainerPrelude(false)+body+"const probe = other.branch[0]; probe;")
		steps := maxValueFlowSteps
		assert.DeepEqual(t, returnedSourceNames(l.valueSources(probe, &steps, 0)), []string{"first"})
	})
	for _, use := range []string{
		"other.branch[0] = second;", "other.branch.reverse();", "other.branch.length = 0;", "const ignored = other.branch.length;",
		"let index = 0; const ignored = other.branch[index];", "consume(other.branch);", "const copied = [...other.branch];",
		"const extracted = other.branch;", "const extracted: unknown = other.branch;", "const extracted = other.branch as Value[];",
	} {
		t.Run(use, func(t *testing.T) {
			l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+body+use+nestedContainerProbeDeclarations(".branch[0]"))
			for _, projection := range containerAliasProbeExpressions(l) {
				steps := maxValueFlowSteps
				assert.Assert(t, l.valueSources(projection, &steps, 0) == nil)
			}
		})
	}
}
