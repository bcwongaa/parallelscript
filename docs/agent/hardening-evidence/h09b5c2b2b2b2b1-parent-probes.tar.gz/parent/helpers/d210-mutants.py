import json
import os
from pathlib import Path
import subprocess
import sys

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
source = repo / "pts/lower/nested_container_sources.go"
original = source.read_text()
mutants = [
    ("unchecked_component_uses", "return containerProjectionRead(parent, steps, depth)", "return true", "^TestNestedContainerUnsafeUsesPoisonWholeRoot$"),
    ("unchecked_nested_contracts", "if tree != nil && len(tree.children) != 0 &&", "if false && tree != nil && len(tree.children) != 0 &&", "^TestNestedContainerUnsupportedOriginsAndContractsStayUnknown$"),
    ("unchecked_wrapped_sibling", "if wrapped != value && (wrapped.Kind == ast.KindObjectLiteralExpression || wrapped.Kind == ast.KindArrayLiteralExpression) {", "if false && wrapped != value && (wrapped.Kind == ast.KindObjectLiteralExpression || wrapped.Kind == ast.KindArrayLiteralExpression) {", "^TestNestedContainerUnselectedInvalidLiteralPoisonsWholeRoot$"),
]
rows = []
for name, old, new, test in mutants:
    assert original.count(old) == 1, name
    replacement = repo / ("pts-bin/d210-mutant-" + name + ".go")
    replacement.write_text(original.replace(old,new))
    overlay = repo / ("pts-bin/d210-mutant-" + name + ".json")
    overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
    command = ["go", "test", "-overlay", str(overlay), "-count=1", "-json", "-p", "1", "-parallel", "1", "./pts/lower", "-run", test]
    p = subprocess.run(command,cwd=repo,env=dict(os.environ,GOMAXPROCS="1"),capture_output=True,text=True,timeout=300)
    (out/(name+".stdout")).write_text(p.stdout)
    (out/(name+".stderr")).write_text(p.stderr)
    events = [json.loads(line) for line in p.stdout.splitlines() if line.startswith("{")]
    assertion_failures = [e for e in events if "assertion failed" in e.get("Output", "")]
    failed_tests = [e for e in events if e.get("Action")=="fail" and e.get("Test")]
    row = dict(name=name,command=command,exit=p.returncode,failed_tests=len(failed_tests),assertion_failures=len(assertion_failures))
    rows.append(row)
    (out/"summary.json").write_text(json.dumps(rows,indent=2))
    assert p.returncode != 0 and assertion_failures and failed_tests and "build failed" not in p.stdout+p.stderr, row
    print(name,"REJECTED",len(assertion_failures),flush=True)
