import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo, previous, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
rows = json.loads((previous / 'rows.json').read_text())
checks = []
for row in rows:
    if row['compiler'] != 'current' or row['round'] != 0:
        continue
    source = previous / (row['name'] + '.pts')
    destination = out / (row['name'] + '.c')
    command = [str(repo / 'pts-bin/d210-current'), str(source), str(destination), 'emit']
    p = subprocess.run(command, cwd=repo, env=dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo)), capture_output=True, text=True, timeout=300)
    code = destination.read_bytes() if destination.exists() else b''
    digest = hashlib.sha256(code).hexdigest()
    check = dict(name=row['name'], command=command, exit=p.returncode, stdout=p.stdout, stderr=p.stderr, sha256=digest, previous_sha256=row['sha256'], lines=code.count(b'\n'), bytes=len(code))
    checks.append(check)
    (out / 'summary.json').write_text(json.dumps(checks, indent=2))
    assert p.returncode == 0 and digest == row['sha256'], check
    print(row['name'], 'FINAL C IDENTICAL', flush=True)
assert len(checks) == 16
print('All 16 final emissions match the independently executed growth C.', flush=True)
