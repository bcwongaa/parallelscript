import collections
import json
import os
from pathlib import Path
import subprocess
import sys

repo, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
source = repo / 'pts/lower/nested_container_sources.go'
text = source.read_text()
start = text.index('func (tree *literalContainer) projectionRead(')
end = text.index('// Nested proofs', start)
replacement = repo / 'pts-bin/d210-array-mutant.go'
replacement.write_text(text[:start] + 'func (tree *literalContainer) projectionRead(read *ast.Node, steps *int, depth int) bool {\n\treturn true\n}\n\n' + text[end:])
rows = []
for label in ['original_snapshot3', 'strengthened_snapshot4']:
    mapping = {str(source): str(replacement)}
    if label == 'original_snapshot3':
        mapping[str(repo / 'pts/lower/nested_container_sources_test.go')] = str(repo / 'pts-bin/d210-snapshot3/pts/lower/nested_container_sources_test.go')
    overlay = repo / ('pts-bin/d210-array-mutant-' + label + '.json')
    overlay.write_text(json.dumps({'Replace': mapping}))
    command = ['go', 'test', '-overlay', str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', './pts/lower', '-run', '^TestNestedContainerArraysRejectIntermediateEscapeAndMutation$']
    p = subprocess.run(command, cwd=repo, env=dict(os.environ, GOMAXPROCS='1'), capture_output=True, text=True, timeout=180)
    (out / (label + '.jsonl')).write_text(p.stdout)
    (out / (label + '.stderr')).write_text(p.stderr)
    events = [json.loads(line) for line in p.stdout.splitlines() if line.startswith('{')]
    counts = collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in {'pass', 'fail', 'skip'})
    assertions = sum('assertion failed' in e.get('Output', '') for e in events)
    row = dict(label=label, command=command, exit=p.returncode, events=dict(counts), assertion_failures=assertions)
    rows.append(row)
    (out / 'summary.json').write_text(json.dumps(rows, indent=2))
    assert 'build failed' not in p.stdout + p.stderr
    if label == 'original_snapshot3':
        assert p.returncode == 0 and counts['pass'] == 11 and not counts['fail'], row
    else:
        assert p.returncode == 1 and counts['fail'] == 11 and assertions == 10 and counts['pass'] == 1, row
print(json.dumps(rows, indent=2), flush=True)
