package lower

import (
    "fmt"
    "slices"
    "testing"

    "gotest.tools/v3/assert"
)

// Reviewer-owned overlay tests; no supplied tests or implementation are changed.
func TestReviewD210IndependentTrees(t *testing.T) {
    for _, receivers := range []bool{false, true} {
        for _, tt := range []struct{name, body string; known bool; want []string}{
            {"mixed_target_propagation", "const root = [{row: {items: [{value:first,other:second}]}}, {row: {items: [{value:second,other:first}]}}]; const alias=root; const probe=alias[1].row.items[0].value; probe;", true, []string{"second"}},
            {"parenthesis_children", "const root={branch: ((([{row: (({value:first}))}])))};const probe=root.branch[0].row.value;probe;", true, []string{"first"}},
            {"selected_conditional", "const root={branch:[{value:choose()?first:second}]};const probe=root.branch[0].value;probe;", true, []string{"first","second"}},
            {"optional_common_member", "const root={branch:[{value:first,extra:1},{value:second}]};const probe=root.branch[0].value;probe;", false, nil},
            {"union_array_element", "const root={branch:[first,0]};const probe=root.branch[0];probe;", false, nil},
            {"inferred_method_common_contract", "interface Method{value():void;}const method:Method={value:first};const root={branch:[{value:first},method]};const probe=root.branch[0].value;probe;", false, nil},
            {"inferred_accessor_common_contract", "interface Getter{get value():Value;}const getter:Getter={get value(){return second;}};const root={branch:[{value:first},getter]};const probe=root.branch[0].value;probe;", false, nil},
            {"readonly_common_element", "const other:readonly Value[]=[second];const root={branch:[[first],other]};const probe=root.branch[0][0];probe;", false, nil},
            {"readonly_common_object_child", "const other:{row:readonly Value[]}={row:[second]};const root=[{row:[first]},other];const probe=root[0].row[0];probe;", false, nil},
            {"tuple_common_element", "const other:[Value]=[second];const root={branch:[[first],other]};const probe=root.branch[0][0];probe;", false, nil},
            {"inner_identifier_origin", "const inner={value:first};const root={branch:inner};const probe=root.branch.value;probe;", false, nil},
            {"call_origin", "function make(){return {value:first};}const root={branch:make()};const probe=root.branch.value;probe;", false, nil},
            {"nested_nonnull_wrapper", "const root={branch:({value:first})!};const probe=root.branch.value;probe;", false, nil},
            {"nested_satisfies_wrapper", "const root={branch:({value:first} satisfies {value:Value})};const probe=root.branch.value;probe;", false, nil},
            {"outer_satisfies_context", "const root={branch:{value:first}} satisfies {branch:{value:Value}};const probe=root.branch.value;probe;", false, nil},
            {"generic_class_lexical", "class Outer<T>{read(){const root={branch:{value:first}};const probe=root.branch.value;probe;}}", false, nil},
            {"generic_arrow_lexical", "const outer=<T>(x:T)=>{const root={branch:{value:first}};const probe=root.branch.value;probe;};", false, nil},
        } {
            if receivers && tt.name=="inferred_method_common_contract" { continue }
            t.Run(fmt.Sprintf("%t/%s",receivers,tt.name),func(t *testing.T){
                l,probe:=valueFlowProbe(t,nestedContainerPrelude(receivers)+tt.body)
                steps:=maxValueFlowSteps
                got:=(sourceProof{l:l,receivers:receivers}).valueSources(probe,&steps,0)
                if !tt.known {assert.Assert(t,got==nil,"unsupported whole-tree contract remains unknown");return}
                want:=slices.Clone(tt.want)
                if receivers {for i,n:=range want {if n=="first" {want[i]="A"}else{want[i]="B"}}}
                assert.DeepEqual(t,returnedSourceNames(got),want)
                assert.Equal(t,len(l.valueFlow.active),0)
                assert.Equal(t,len(l.valueFlow.receivers.active),0)
            })
        }
    }
}

func TestReviewD210LateSideUses(t *testing.T) {
    for _, receivers:=range []bool{false,true} {
        for _, use:=range []string{
            "function expose(value=other.side):unknown{return value;}",
            "function expose():unknown{return {escaped:other.side};}",
            "const ignored = other.side === alias.branch;",
            "const ignored = void other.side;",
            "const ignored = JSON.stringify(other.side);",
            "const ignored = [other.side];",
            "for(const ignored of [other.side]){}",
            "const ignored = {...other.side};",
            "other.side.value &&= second;",
            "other.side.value ||= second;",
            "other.side.value ??= second;",
            "[other.side.value] = [second];",
            "({side:other.side}={side:root.branch});",
            "((other.side.replace!) as typeof replace)?.();",
            "(other.side.replace satisfies typeof replace)();",
            "(other.side.replace!)``;",
            "(other.side.replace<TemplateStringsArray>)``;",
            "const inner=other.side;function change(){inner.value=second;}",
        } {
            for _,reverse:=range []bool{false,true} {
                t.Run(fmt.Sprintf("%t/%t/%s",receivers,reverse,use),func(t *testing.T){
                    source:=nestedContainerPrelude(receivers)+`function replace<T>(this:{value:Value}, value?:T):void{this.value=second;}
const root={branch:{value:first,replace},side:{value:first,replace},plain:first};const alias=root;const other=alias;
const check_early=root.branch.value;
`+use+`
const check_late=other.side.value;const check_plain=alias.plain;const probe=check_early;probe;`
                    l,_:=valueFlowProbe(t,source)
                    queries:=containerAliasProbeExpressions(l)
                    assert.Equal(t,len(queries),3)
                    if reverse{slices.Reverse(queries)}
                    for _,query:=range queries{steps:=maxValueFlowSteps;assert.Assert(t,(sourceProof{l:l,receivers:receivers}).valueSources(query,&steps,0)==nil,"late side use poisons the complete component")}
                    assert.Equal(t,len(l.valueFlow.active),0)
                    assert.Equal(t,len(l.valueFlow.receivers.active),0)
                })
            }
        }
    }
}

func TestReviewD210CrossKindBudgetAndMemo(t *testing.T) {
    for _,receiverFirst:=range []bool{false,true}{
        t.Run(fmt.Sprint(receiverFirst),func(t *testing.T){
            l,probe:=valueFlowProbe(t,"class A{tag=0;}const root={branch:[{value:new A()}]};const alias=root;const probe=alias.branch[0].value;probe;")
            first:=sourceProof{l:l,receivers:receiverFirst}
            steps:=maxValueFlowSteps
            got:=first.valueSources(probe,&steps,0)
            if receiverFirst{assert.DeepEqual(t,returnedSourceNames(got),[]string{"A"})}else{assert.Assert(t,got==nil)}
            second:=sourceProof{l:l,receivers:!receiverFirst}
            steps=0
            assert.Assert(t,second.valueSources(probe,&steps,0)==nil,"zero-budget opposite proof must not copy sources across source kinds")
            steps=maxValueFlowSteps
            got=first.valueSources(probe,&steps,0)
            if receiverFirst{assert.DeepEqual(t,returnedSourceNames(got),[]string{"A"})}else{assert.Assert(t,got==nil)}
            assert.Equal(t,len(l.valueFlow.active),0);assert.Equal(t,len(l.valueFlow.receivers.active),0)
        })
    }
}
