import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile

repo, review, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo))
commands = []

def run(label, argv, extra=None, timeout=300):
    argv = list(map(str, argv))
    cp = subprocess.run(argv, cwd=repo, env=dict(env, **(extra or {})), capture_output=True, text=True, timeout=timeout)
    (out / (label + '.stdout')).write_text(cp.stdout)
    (out / (label + '.stderr')).write_text(cp.stderr)
    commands.append(dict(label=label, argv=argv, exit=cp.returncode, environment=dict(GOMAXPROCS='1', PTS_HOME=str(repo), **(extra or {}))))
    (out / 'commands.json').write_text(json.dumps(commands, indent=2))
    assert cp.returncode == 0, (label, cp.stdout[-2000:], cp.stderr[-2000:])
    return cp

archive = review.parent / 'review-d210-probes.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '631a5e072d415ccbd21c865e27731025aed3887366ab513071c4d5d7fa5f2b67'
with tarfile.open(archive, 'r:gz') as t:
    members = t.getmembers()
    assert len(members) == 252
    for member in members:
        path = Path(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts and not member.name.endswith('.bin'), member.name
        t.extractfile(member).read().decode('utf-8')
archive_copy = repo / 'docs/agent/hardening-evidence/h09b5c2b2b2b2b1-review-probes.tar.gz'
if archive_copy.exists():
    assert archive_copy.read_bytes() == archive.read_bytes(), 'existing review archive differs'
else:
    shutil.copyfile(archive, archive_copy)
proof = repo / 'pts-bin/d210-reviewer-proof_test.go'
shutil.copyfile(review / 'inputs/proof_test.go', proof)
overlay = repo / 'pts-bin/d210-reviewer-proof-overlay.json'
overlay.write_text(json.dumps({'Replace': {str(repo / 'pts/lower/nested_container_contract_test.go'): str(proof)}}))
cp = run('source-guards', ['go', 'test', '-overlay', overlay, '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', './pts/lower', '-run', '^TestReviewD210'])
events = [json.loads(line) for line in cp.stdout.splitlines() if line.startswith('{')]
counts = collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in {'pass', 'skip', 'fail'})
assert counts['pass'] == 110 and not counts['fail'] and not cp.stderr, counts
cases = json.loads((review / 'cases/manifest.json').read_text()) + [dict(name='captures', kind=None, unsafe=None)]
rows = []
for case in cases:
    name, kind = case['name'], case['kind']
    source = review / 'cases' / (name + '.pts')
    node_source = out / (name + '.mts')
    node_source.write_text(source.read_text())
    node = run(name + '-node', [Path.home() / '.local/node/bin/node', '--experimental-transform-types', node_source])
    row = dict(case, compilers=[])
    for label, helper in [('base', repo / 'pts-bin/d210-base'), ('current', repo / 'pts-bin/d210-current')]:
        c = out / (name + '-' + label + '.c')
        binary = out / (name + '-' + label + '.bin')
        run(name + '-' + label + '-build', [helper, source, c, binary])
        try:
            native = run(name + '-' + label + '-native', [binary], {'GC_PRINT_STATS': '1'} if name == 'captures' else None)
            assert native.stdout == node.stdout, (name, label, 'stdout mismatch')
            text = c.read_text()
            assert '#line ' in text
            record = dict(label=label, stdout_match=True, c_sha256=hashlib.sha256(c.read_bytes()).hexdigest())
            if kind:
                required_pairs = {(i, j) for i in range(3) for j in range(3) if label == 'base' or case['unsafe'] or i == j}
                present, registered = set(), set()
                for i in range(3):
                    for j in range(3):
                        target = f'pts_fn_source{i}_C{j}(' if kind == 'function' else f'pts_fn_M{i}_make_C{j}('
                        if target in text:
                            present.add((i, j))
                        if 'return ' + target in text:
                            registered.add((i, j))
                assert present == required_pairs, (name, label, present, required_pairs)
                record['pairs'] = len(present)
                if kind != 'function':
                    assert registered == required_pairs, (name, label, 'descriptor targets')
                    record['descriptor_matrix_ok'] = True
                if kind in {'captured_receiver', 'wrapper'}:
                    signatures = re.findall(r'(?m)^static [^\n]*\bpts_instance_closure_(read\d_[A-Za-z0-9_]+)_([0-9]+)\(pts_closure \*pts_env, pts_class_C([0-9]+) \*a1\)', text)
                    actual = {(int(site[4]), int(demand)) for site, instance, demand in signatures}
                    required_wrappers = {(i, j) for i in range(3) for j in range(3) if (kind == 'wrapper' and (label == 'base' or case['unsafe'])) or i == j}
                    assert actual == required_wrappers, (name, label, actual, required_wrappers)
                    tables = set(re.findall(r'\.instances = (pts_instances_closure_read\d_[A-Za-z0-9_]+),', text))
                    assert len(tables) == 3
                    assert all('PTS_GC_POINTER_WORDS(PTS_GC_WORD(pts_closure_' + site + ', receiver))' in text for site, instance, demand in signatures)
                    record.update(wrapper_matrix_ok=True, receiver_gc_layout_ok=True)
            else:
                collections_observed = len(re.findall(r'collection #[0-9]+', native.stderr))
                assert collections_observed >= 2, native.stderr[-3000:]
                record['gc_collection_markers'] = collections_observed
            row['compilers'].append(record)
        finally:
            binary.unlink(missing_ok=True)
    rows.append(row)
    (out / 'summary.json').write_text(json.dumps(dict(source_test_events=dict(counts), cases=rows, archive=dict(name=archive_copy.name, members=len(members), bytes=archive_copy.stat().st_size, sha256=hashlib.sha256(archive_copy.read_bytes()).hexdigest())), indent=2))
    print(name + ' base/current replay verified', flush=True)
print(json.dumps(dict(source_test_events=dict(counts), cases=len(rows), native_node_matches=sum(len(r['compilers']) for r in rows), commands=len(commands)), indent=2), flush=True)
