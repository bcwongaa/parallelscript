import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo, frozen, out = map(Path, sys.argv[1:])
out.mkdir(parents=True, exist_ok=False)
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
env.pop('GOFLAGS', None)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest():
    names = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=repo).decode().split('\0')
    suffixes = {'.go', '.c', '.h', '.pts', '.out', '.json', '.ts', '.js', '.mts', '.mjs'}
    return {name: digest(repo / name) for name in sorted(set(names)) if name and Path(name).suffix in suffixes and (repo / name).is_file()}

def execute(name, command, timeout):
    started = time.monotonic()
    with (out / (name + '.stdout')).open('wb') as stdout, (out / (name + '.stderr')).open('wb') as stderr:
        p = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr, timeout=timeout)
    return dict(command=command, exit=p.returncode, seconds=time.monotonic()-started, stderr_bytes=(out / (name + '.stderr')).stat().st_size)

before = manifest()
(out / 'sources-before.json').write_text(json.dumps(before, indent=2))
expected = json.loads(frozen.read_text())
assert all(digest(repo / name) == sha for name, sha in expected.items()), 'reviewed snapshot mismatch before build'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
(out / 'git-status-before.txt').write_text(subprocess.check_output(['git', 'status', '--short'], cwd=repo, text=True))
build = execute('build', ['make', 'build'], 600)
assert build['exit'] == 0, build
cli_before = digest(repo / 'pts-bin/pts')
command = ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']
suite = execute('suite', command, 3600)
after = manifest()
(out / 'sources-after.json').write_text(json.dumps(after, indent=2))
changes = [name for name in sorted(before.keys() | after.keys()) if before.get(name) != after.get(name)]
events = [json.loads(line) for line in (out / 'suite.stdout').read_text().splitlines() if line.startswith('{')]
counts = collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in {'pass', 'skip', 'fail'})
corpus = collections.Counter(e['Action'] for e in events if e.get('Test', '').startswith('TestCorpusMatchesNode/') and e['Action'] in {'pass', 'skip', 'fail'})
packages = [dict(package=e['Package'], action=e['Action']) for e in events if not e.get('Test') and e['Action'] in {'pass', 'skip', 'fail'}]
reviewed_after = {name: digest(repo / name) for name in expected}
summary = dict(head_before=head, environment=dict(GOMAXPROCS='4', PTS_REQUIRE_NODE='1'), build=build, suite=suite, test_events=dict(counts), packages=packages, corpus=dict(corpus), source_count=len(before), source_changes=changes, cli_before=cli_before, cli_after=digest(repo / 'pts-bin/pts'), reviewed_snapshot=expected, reviewed_after=reviewed_after)
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2), flush=True)
assert suite['exit'] == 0 and not counts['fail'] and not changes and cli_before == summary['cli_after'] and expected == reviewed_after, 'final verification failed; inspect retained output'
assert sum(p['action'] == 'pass' for p in packages) == 10, 'not all ten tested packages passed'
assert corpus['pass'] == 263 and corpus['skip'] == 37 and not corpus['fail'], 'unexpected corpus classification'
