import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tarfile

repo, raw, task = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
evidence = repo / 'docs/agent/hardening-evidence'
archive = evidence / (task + '-parent-probes.tar.gz')
assert not archive.exists(), archive
extra = [p for p in (repo / 'pts-bin').glob('d210-*') if p.is_file() and p.suffix in {'.go', '.py', '.json'}]
extra += list((repo / 'pts-bin/d210-base-source').glob('*.go'))
for snapshot in ['d210-snapshot2', 'd210-snapshot3', 'd210-snapshot4']:
    extra += [p for p in (repo / 'pts-bin' / snapshot).rglob('*') if p.is_file()]
with tarfile.open(archive, 'w:gz') as t:
    for path in sorted(raw.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file() and path.suffix != '.bin':
            t.add(path, arcname='parent/raw/' + str(path.relative_to(raw)), recursive=False)
    for path in sorted(extra):
        assert path.is_file() and not path.is_symlink(), path
        t.add(path, arcname='parent/helpers/' + str(path.relative_to(repo / 'pts-bin')), recursive=False)
with tarfile.open(archive, 'r:gz') as t:
    members = t.getmembers()
    for member in members:
        p = Path(member.name)
        assert not p.is_absolute() and '..' not in p.parts and member.isfile(), member.name
records = dict(archive=archive.name, bytes=archive.stat().st_size, members=len(members), sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
for source, suffix in [(raw / 'final/suite.stdout', '-final-suite.jsonl.gz'), (raw / 'final/summary.json', '-final-summary.json')]:
    destination = evidence / (task + suffix)
    assert not destination.exists(), destination
    if suffix.endswith('.gz'):
        with source.open('rb') as src, destination.open('wb') as dst, gzip.GzipFile(fileobj=dst, mode='wb', mtime=0) as gz:
            shutil.copyfileobj(src, gz)
    else:
        shutil.copyfile(source, destination)
    records[destination.name] = dict(bytes=destination.stat().st_size, sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
print(json.dumps(records, indent=2))
