package main

import (
    "context"
    "fmt"
    "os"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "github.com/microsoft/typescript-go/pts/toolchain"
)

// Review helper deliberately calls the strict API: no narrowing or fallback.
func main() {
    if len(os.Args) != 4 && len(os.Args) != 5 {
        fmt.Fprintln(os.Stderr, "usage: strict-tool emit|build source.pts emitted.c [native-output]")
        os.Exit(2)
    }
    ctx := context.Background()
    c, err := driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
    if err == nil { err = os.WriteFile(os.Args[3], []byte(c), 0600) }
    if err == nil && os.Args[1] == "build" {
        var tc *toolchain.Toolchain
        tc, err = toolchain.New()
        if err == nil {
            var rt *toolchain.Runtime
            rt, err = tc.Runtime(ctx, toolchain.Release)
            if err == nil { err = tc.CompileProgram(ctx, rt, []string{os.Args[3]}, os.Args[4]) }
        }
    }
    if err != nil {
        fmt.Fprintln(os.Stderr, err)
        os.Exit(1)
    }
}
