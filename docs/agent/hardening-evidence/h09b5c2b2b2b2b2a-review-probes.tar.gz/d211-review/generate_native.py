import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
programs = root / 'programs'
programs.mkdir(exist_ok=True)
manifest = []
for kind in ['function', 'receiver', 'captured_receiver', 'wrapper']:
    for poison in [False, True]:
        name = kind + ('_poisoned' if poison else '_known')
        lines = [
            'class Box<T> { value: T; label: string; constructor(value: T, label: string) { this.value = value; this.label = label; } }',
            'type Factory = <T>(value: T) => Box<T>;',
            'interface Maker { make<T>(value: T): Box<T>; }',
        ]
        for i in range(3):
            lines += [
                f'class C{i} {{ tag = {i}; }}',
                f'function source{i}<T>(value: T): Box<T> {{ return new Box(value, "source{i}"); }}',
                f'class M{i} implements Maker {{ calls = 0; label: string; constructor(label: string) {{ this.label = label; }} make<T>(value: T): Box<T> {{ this.calls++; return new Box(value, this.label + "/" + this.calls); }} }}',
            ]
            if kind == 'receiver':
                lines += [f'function use{i}(value: Maker): void {{ const box: Box<C{i}> = value.make(new C{i}()); console.log("use{i}", box.label, box.value.tag); }}']
            else:
                lines += [f'function use{i}(value: Factory): void {{ const box: Box<C{i}> = value(new C{i}()); console.log("use{i}", box.label, box.value.tag); }}']
            if kind == 'captured_receiver':
                lines += [f'function read{i}(receiver: Maker): Factory {{ return receiver.make.bind(receiver); }}']
            if kind == 'wrapper':
                lines += [f'function wrap{i}(label: string): Factory {{ const receiver: Maker = new M{i}(label); return receiver.make.bind(receiver); }}']
        value_type = 'Maker' if kind in ['receiver', 'captured_receiver'] else 'Factory'
        for i in range(3):
            value = f'source{i}'
            other = f'source{(i+1)%3}'
            if value_type == 'Maker':
                value, other = f'new M{i}("selected{i}")', f'new M{(i+1)%3}("alternate{i}")'
            if kind == 'wrapper':
                value, other = f'wrap{i}("selected{i}")', f'wrap{(i+1)%3}("alternate{i}")'
            lines += [
                f'const value{i}: {value_type} = {value}; const alternate{i}: {value_type} = {other};',
                f'const root{i} = {{ left: {{ rows: [{{ selected: value{i}, other: alternate{i} }}] }}, side: {{ selected: alternate{i} }}, plain: value{i} }};',
                f'const rootAlias{i} = root{i}; const left{i} = rootAlias{i}.left; const rows{i} = left{i}.rows; const row{i} = rows{i}[0]; const childAlias{i} = row{i}; const sibling{i} = root{i}.side; const ignored{i} = sibling{i}.selected;',
            ]
            if poison:
                lines += [f'const escaped{i}: any = left{i}; escaped{i}.rows[0].selected = alternate{i};']
        permutation = [2, 0, 1]
        for demand, value in enumerate(permutation):
            expression = f'childAlias{value}.selected'
            if kind == 'captured_receiver':
                expression = f'read{demand}({expression})'
            lines += [f'use{demand}({expression});']
        source = '\n'.join(lines) + '\n'
        (programs / (name+'.pts')).write_text(source)
        (programs / (name+'.mts')).write_text(source)
        required = [[v,d] for d,v in enumerate(permutation)]
        manifest += [{'name':name, 'kind':kind, 'poison':poison, 'required_current':required, 'pairs_base':9, 'pairs_current':9 if poison else 3}]

# Independent shared creation-site captures are kept live only by extracted aliases.
churn = '''class Box<T> { value: T; label: string; constructor(value: T, label: string) { this.value = value; this.label = label; } }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class Parent implements Maker {
  calls = 0; label: string; constructor(label: string) { this.label = label; }
  make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/parent/" + this.calls); }
}
class Child extends Parent {}
class Override extends Parent {
  make<T>(value: T): Box<T> { this.calls++; return new Box(value, this.label + "/override/" + this.calls); }
}
function hold(receiver: Maker): Factory {
  const root = { left: { rows: [{ receiver }] }, side: { marker: 5 } };
  const left = root.left; const rows = left.rows; const row = rows[0]; const alias = row;
  return alias.receiver.make.bind(alias.receiver);
}
function closure(label: string): Factory {
  let calls = 0;
  const factory: Factory = <T,>(value: T): Box<T> => { calls++; return new Box(value, label + "/closure/" + calls); };
  const root = { rows: [{ factory }] }; const rows = root.rows; const row = rows[0]; return row.factory;
}
const first = hold(new Child("first")); const second = hold(new Override("second"));
const captureA = closure("a"); const captureB = closure("b");
let checksum = 0;
for (let i = 0; i < 180000; i++) {
  const scratch = { text: "garbage/" + i, values: [i, i+1, i+2] };
  checksum += scratch.values.length;
}
const x: Box<number> = first(3); const y: Box<string> = second("four");
const z: Box<string> = first("again"); const a: Box<number> = captureA(7);
const b: Box<string> = captureB("eight"); const c: Box<string> = captureA("nine");
console.log(x.label,x.value,y.label,y.value,z.label,z.value,a.label,a.value,b.label,b.value,c.label,c.value,checksum);
'''
for ext in ['pts','mts']:
    (programs / ('capture_churn.'+ext)).write_text(churn)
manifest += [{'name':'capture_churn','kind':'churn'}]
(root/'native-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('generated',len(manifest),'native inputs')
