import argparse
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument('--root', required=True)
parser.add_argument('--worktree', required=True)
parser.add_argument('--runtime', required=True)
parser.add_argument('--base', required=True)
parser.add_argument('--current', required=True)
parser.add_argument('--node', required=True)
args = parser.parse_args()
root = pathlib.Path(args.root).resolve()
worktree = pathlib.Path(args.worktree).resolve()
runtime = json.loads(pathlib.Path(args.runtime).read_text())
cases = json.loads((root / 'native-manifest.json').read_text())
results_dir = root / 'native-results'
results_dir.mkdir(exist_ok=True)
commands = []
results = []
failures = []

def save_state():
    (root / 'native-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (root / 'native-results.json').write_text(json.dumps(results, indent=2) + '\n')

def run(label, argv, env_extra, timeout=180):
    env = os.environ.copy()
    env.update(env_extra)
    record = {'label': label, 'cwd': str(worktree), 'argv': list(map(str, argv)), 'env': env_extra}
    prefix = results_dir / label
    try:
        p = subprocess.run(record['argv'], cwd=worktree, env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
        record['exit'] = p.returncode
        record['stdout_sha256'] = hashlib.sha256(p.stdout).hexdigest()
        record['stderr_sha256'] = hashlib.sha256(p.stderr).hexdigest()
        prefix.with_suffix('.stdout').write_bytes(p.stdout)
        prefix.with_suffix('.stderr').write_bytes(p.stderr)
    except subprocess.TimeoutExpired as error:
        record['exit'] = 'timeout'
        prefix.with_suffix('.stdout').write_bytes(error.stdout or b'')
        prefix.with_suffix('.stderr').write_bytes(error.stderr or b'')
        p = None
    commands.append(record)
    save_state()
    if record['exit'] != 0:
        raise RuntimeError(label + ' exited ' + str(record['exit']))
    return p.stdout, p.stderr

def matrix(case, version, c):
    kind = case['kind']
    if kind == 'churn' or kind == 'fixture':
        return {}
    all_pairs = {(v, d) for v in range(3) for d in range(3)}
    expected = all_pairs if version == 'base' or case['poison'] else set(map(tuple, case['required_current']))
    prefix = 'pts_fn_source' if kind == 'function' else 'pts_fn_M'
    found = set()
    registered = set()
    for value in range(3):
        for demand in range(3):
            target = (f'{prefix}{value}_C{demand}(' if kind == 'function'
                      else f'{prefix}{value}_make_C{demand}(')
            if target in c:
                found.add((value, demand))
            if 'return ' + target in c:
                registered.add((value, demand))
    assert found == expected, (case['name'], version, 'targets', found, expected)
    if kind != 'function':
        assert registered == expected, (case['name'], version, 'registrations', registered, expected)
    wrappers = {}
    if kind in ('captured_receiver', 'wrapper'):
        for i in range(3):
            wrapper = f'read{i}_bound_u0020make_' if kind == 'captured_receiver' else f'wrap{i}_bound_u0020make_'
            assert '.instances = pts_instances_closure_' + wrapper + ',' in c, wrapper
            pattern = (r'(?m)^static [^\n]*\bpts_instance_closure_' + re.escape(wrapper) +
                       r'_[0-9]+\(pts_closure \*pts_env, pts_class_C([0-9]+) \*a1\)')
            entries = re.findall(pattern, c)
            actual = set(map(int, entries))
            if kind == 'captured_receiver':
                required = {i}
            elif version == 'base' or case['poison']:
                required = {0, 1, 2}
            else:
                required = {d for value, d in expected if value == i}
            assert actual == required and len(entries) == len(required), (wrapper, actual, entries, required)
            wrappers[wrapper] = sorted(actual)
    return {'targets': sorted(map(list, found)), 'registrations': sorted(map(list, registered)), 'wrappers': wrappers}

for case in cases:
    name = case['name']
    entry = {'name': name, 'kind': case['kind'], 'versions': {}}
    results.append(entry)
    try:
        source = root / 'programs' / (name + '.pts')
        node_source = source.with_suffix('.mts')
        oracle, node_stderr = run(name + '-node', [args.node, '--experimental-transform-types', node_source], {'NODE_NO_WARNINGS': '1'})
        (results_dir / (name + '.expected.txt')).write_bytes(oracle)
        entry['expected_stdout'] = oracle.decode('utf-8')
        if case['kind'] == 'fixture':
            text = source.read_text()
            expected_lines = text.split('// expect:\n', 1)[1].splitlines()
            fixture_expected = ''.join(line[3:] + '\n' for line in expected_lines if line.startswith('// '))
            assert oracle.decode('utf-8') == fixture_expected, 'fixture expect comments disagree with strict Node'
        for version, helper in [('base', args.base), ('current', args.current)]:
            cpath = results_dir / (name + '-' + version + '.c')
            binary = results_dir / (name + '-' + version + '.bin')
            run(name + '-' + version + '-emit', [helper, 'emit', source, cpath], {'GOMAXPROCS': '1', 'PTS_HOME': str(worktree)})
            text = cpath.read_text()
            facts = matrix(case, version, text)
            entry['versions'][version] = facts
            flags = ['-O2', '-g', '-ffp-contract=off', '-fno-math-errno', '-falign-functions=32', '-std=c11']
            includes = [part for path in runtime['include_dirs'] for part in ['-I', path]]
            argv = [runtime.get('cc', 'clang')] + flags + ['-o', binary] + includes + [cpath] + runtime['archives'] + ['-lpthread', '-ldl', '-lm', '-static-libgcc']
            run(name + '-' + version + '-clang', argv, {})
            native_env = {'PTS_THREADS': '1', 'GC_MARKERS': '1'}
            if case['kind'] == 'churn':
                native_env['GC_PRINT_STATS'] = '1'
            actual, native_stderr = run(name + '-' + version + '-run', [binary], native_env)
            assert actual == oracle, (name, version, actual, oracle)
            if case['kind'] == 'churn':
                collections = set(re.findall(rb'(?m)^GC #([0-9]+) ', native_stderr))
                facts['gc_collections'] = len(collections)
                assert collections, 'no collection observed; GC capture control not demonstrated'
            binary.unlink()
        entry['status'] = 'pass'
        print(name + ' PASS', flush=True)
    except Exception as error:
        entry['status'] = 'fail'
        entry['error'] = repr(error)
        failures.append(name)
        print(name + ' FAIL ' + repr(error), flush=True)
    save_state()
print('completed=' + str(len(cases)) + ' failed=' + str(len(failures)), flush=True)
sys.exit(bool(failures))
