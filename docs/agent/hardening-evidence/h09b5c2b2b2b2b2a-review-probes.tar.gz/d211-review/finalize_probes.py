import collections
import hashlib
import json
import pathlib
import shutil
import subprocess
import tarfile

worktree = pathlib.Path('/home/bryan/projects/parallelscript/.claude/worktrees/agent-a12c99c879aeaedfd')
root = worktree / 'scratch/d211-review'
hashes = json.loads((root / 'snapshot2-hashes.json').read_text())
for rel, digest in hashes.items():
    data = (worktree / rel).read_bytes()
    assert hashlib.sha256(data).hexdigest() == digest
    destination = root / 'snapshot2' / rel
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
(root / 'snapshot2/hashes.json').write_text(json.dumps(hashes, indent=2) + '\n')

common_test = ['-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '15m']
commands = []
def record(label, argv, stdout, stderr, expected_exit=0, env=None):
    commands.append({'label': label, 'cwd': str(worktree), 'env': env or {'GOMAXPROCS': '1'},
                     'argv': list(map(str, argv)), 'stdout': str(root / stdout),
                     'stderr': str(root / stderr), 'expected_exit': expected_exit})
record('current-independent', ['go', '-C', worktree, 'test', '-overlay', root / 'review-overlay.json'] + common_test + ['./pts/lower', '-run', '^TestD211Independent'], 'current-independent.jsonl', 'current-independent.stderr')
record('base-independent-positive-control-red', ['go', '-C', worktree, 'test', '-overlay', root / 'base-review-overlay.json'] + common_test + ['./pts/lower', '-run', '^TestD211Independent'], 'base-independent.jsonl', 'base-independent.stderr', 1)
record('current-supplied-focused', ['go', '-C', worktree, 'test'] + common_test + ['./pts/lower', './pts/driver', '-run', '^Test.*Extracted'], 'current-supplied-focused.jsonl', 'current-supplied-focused.stderr')
record('build-current-strict-helper', ['go', '-C', worktree, 'build', '-p', '1', '-o', root / 'strict-current', './scratch/d211-review/tool'], 'build-current.stdout', 'build-current.stderr')
record('build-base-strict-helper', ['go', '-C', worktree, 'build', '-overlay', root / 'base-production-overlay.json', '-p', '1', '-o', root / 'strict-base', './scratch/d211-review/tool'], 'build-base.stdout', 'build-base.stderr')
record('native-run-attempt1-probe-name-error', ['python3', '-I', root / 'run_natives.py', '--root', root, '--worktree', worktree, '--runtime', root / 'runtime.json', '--base', root / 'strict-base', '--current', root / 'strict-current', '--node', '/home/bryan/.local/node/bin/node'], 'native-attempt1/native-run.stdout', 'native-attempt1/native-run.stderr', 1, {})
record('native-run-final', ['python3', '-I', root / 'run_natives.py', '--root', root, '--worktree', worktree, '--runtime', root / 'runtime.json', '--base', root / 'strict-base', '--current', root / 'strict-current', '--node', '/home/bryan/.local/node/bin/node'], 'native-run.stdout', 'native-run.stderr', 0, {})
versions = {}
for name, argv in [('go', ['go', 'version']), ('node', ['/home/bryan/.local/node/bin/node', '--version']), ('clang', ['clang', '--version'])]:
    p = subprocess.run(argv, cwd=worktree, check=True, capture_output=True, text=True)
    versions[name] = p.stdout
receipt = {
    'base_sha': '5cc375c5abc21aa1f739b4c4faeadefc0876fafc',
    'scope': 'D-211 H09b5c2b2b2b2b2a immutable extracted nested-container aliases rooted in named direct literal const bindings only',
    'model': 'gpt-6.1-sol (inherited runtime)',
    'cwd': str(worktree),
    'versions': versions,
    'candidate_hashes': hashes,
    'commands': commands,
    'per_native_argv': str(root / 'native-commands.json'),
    'native_manifest': str(root / 'native-manifest.json'),
    'expected_stdout_and_targets': str(root / 'native-results.json'),
    'runtime': str(root / 'runtime.json'),
    'runtime_archive_hashes': str(root / 'runtime-archive-hashes.json'),
    'replay_note': 'On a different checkout, consistently remap this worktree prefix in overlay JSON, metadata and argv. Inspect source/scripts before executing. Do not run the first-attempt instrumentation except to reproduce its documented wrapper-name assertion error. Regenerate no fixture: programs/supplied_fixture.pts is the exact candidate fixture.',
    'attempt1_correction': 'First native attempt used unbound wrapper names for explicit bind and double-counted GC markers. Final script uses actual bound wrapper names and counts unique completed GC numbers. Original script and every raw first-attempt result are retained under native-attempt1.',
    'serial_constraint': 'One heavy slot: GOMAXPROCS=1, Go -p1/-parallel1, serial clang, PTS_THREADS=1/GC_MARKERS=1. Runtime archives reused; no runtime build.',
    'limits': 'No full suite, CI, sanitizer or parallel race stress. Explicit-this and wrapped assignment source controls are proof-only, not native support claims. H09b5b and parameter-/returned-/fresh-inline-/destructured-/nonliteral-container source expansion remain outside scope.'
}
(root / 'replay.json').write_text(json.dumps(receipt, indent=2) + '\n')

inventory = {}
excluded = []
for path in sorted(root.rglob('*')):
    if path.is_symlink():
        raise RuntimeError('symlink in probe payload: ' + str(path))
    if not path.is_file():
        continue
    rel = str(path.relative_to(root))
    data = path.read_bytes()
    if data.startswith(b'\x7fELF') or path.suffix in ('.bin', '.gz'):
        excluded.append(rel)
        continue
    data.decode('utf-8')
    assert b'\x00' not in data, rel
    if rel == 'archive-file-hashes.json':
        continue
    inventory[rel] = hashlib.sha256(data).hexdigest()
(root / 'archive-file-hashes.json').write_text(json.dumps(inventory, indent=2) + '\n')
archive = worktree / 'scratch/d211-review-probes.tar.gz'
with tarfile.open(archive, 'w:gz') as target:
    for rel in list(inventory) + ['archive-file-hashes.json']:
        target.add(root / rel, arcname='d211-review/' + rel, recursive=False)
with tarfile.open(archive, 'r:gz') as check:
    for member in check.getmembers():
        assert member.isfile(), member.name
        assert not pathlib.PurePosixPath(member.name).is_absolute()
        assert '..' not in pathlib.PurePosixPath(member.name).parts
        data = check.extractfile(member).read()
        data.decode('utf-8')
        assert b'\x00' not in data
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
print('archive=' + str(archive))
print('sha256=' + sha)
print('regular_utf8_files=' + str(len(inventory) + 1))
print('excluded=' + json.dumps(excluded))
print('all_candidate_hashes_verified=true')
