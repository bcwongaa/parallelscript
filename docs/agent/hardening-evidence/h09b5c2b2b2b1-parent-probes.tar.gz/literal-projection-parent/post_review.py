import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo, scratch = map(Path, sys.argv[1:3])
scratch.mkdir(exist_ok=True)
rows=[]
env=dict(os.environ,GOMAXPROCS='1',PTS_REQUIRE_NODE='1')
for name,packages,extra,overrides in [
    ('affected',['./pts/lower','./pts/driver'],[],{}),
    ('clang',['./pts/tests'],['-run','^TestCompilerFailsCleanly$'],{'PTS_SMOKE_MUTANTS':'0','PTS_SMOKE_FILTER':'generic','PTS_SMOKE_CLANG':'1','PTS_SMOKE_JOBS':'1'}),
]:
    argv=['go','test','-count=1','-json','-p','1','-parallel','1','-timeout','20m']+packages+extra
    p=subprocess.run(argv,cwd=repo,env=dict(env,**overrides),capture_output=True,timeout=1200)
    (scratch/(name+'.jsonl')).write_bytes(p.stdout);(scratch/(name+'.err')).write_bytes(p.stderr)
    events=[json.loads(x) for x in p.stdout.splitlines()]
    row={'name':name,'argv':argv,'env':overrides,'exit':p.returncode,'counts':{a:sum(e['Action']==a and bool(e.get('Test')) for e in events) for a in ['pass','fail','skip']},'stderr_bytes':len(p.stderr)}
    rows.append(row);print(json.dumps(row),flush=True)
    (scratch/'gates.json').write_text(json.dumps(rows,indent=2)+'\n')
    assert p.returncode==0
p=subprocess.run(['python3','-I',str(scratch.parent/'mutants.py'),str(repo),str(scratch/'mutants')],cwd=repo,env=env,capture_output=True,timeout=600)
(scratch/'mutants.out').write_bytes(p.stdout);(scratch/'mutants.err').write_bytes(p.stderr);assert p.returncode==0,(p.stdout,p.stderr)
growth=json.loads((scratch.parent/'growth/measurements.json').read_text());checks=[]
for row in growth:
    if row['version']!='current' or row['round']!=0:continue
    source=scratch.parent/'growth'/(row['name']+'.pts');code=scratch/(row['name']+'.c')
    argv=[str(scratch.parent/'strict-current'),'emit',str(source),str(code)]
    p=subprocess.run(argv,cwd=repo,env=dict(env,PTS_HOME=str(repo)),capture_output=True,timeout=120)
    (scratch/(row['name']+'.out')).write_bytes(p.stdout);(scratch/(row['name']+'.err')).write_bytes(p.stderr)
    sha=hashlib.sha256(code.read_bytes()).hexdigest() if code.exists() else None
    check={'name':row['name'],'argv':argv,'exit':p.returncode,'sha256':sha,'matches_measured_current':sha==row['sha256']};checks.append(check)
    assert p.returncode==0 and check['matches_measured_current'],check
(scratch/'growth-final-check.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'growth_inputs_reemitted':len(checks),'all_measured_current_c_hashes_unchanged':True,'behavioral_mutants_rejected':2}),flush=True)
