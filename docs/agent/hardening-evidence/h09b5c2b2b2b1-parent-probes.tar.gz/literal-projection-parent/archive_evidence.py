import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile

repo, scratch, target = map(Path,sys.argv[1:4])
name='h09b5c2b2b2b1'
summary=json.loads((scratch/'final/summary.json').read_text())
assert summary['build_exit']==summary['suite_exit']==0 and not summary['changed'] and not summary['failures']
manifest=json.loads((scratch/'review-snapshot5.json').read_text())
for relative,expected in manifest['files'].items():
    source=repo/relative
    assert hashlib.sha256(source.read_bytes()).hexdigest()==expected,relative
    dest=scratch/'frozen-final'/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(source.read_bytes())
(scratch/'parent-final.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','.',':(exclude)tools/agent'],cwd=repo))
# Only this session's authored text/probe receipts are selected. Executables,
# nested compressed archives and the separately retained final raw stream are excluded.
allowed={'.go','.pts','.mts','.c','.h','.py','.json','.jsonl','.out','.err','.exit','.md','.txt','.patch'}
files=[]
excluded=[]
for p in sorted(scratch.rglob('*')):
    if p.is_symlink():
        raise AssertionError('unexpected link '+str(p))
    if not p.is_file():continue
    relative=p.relative_to(scratch).as_posix()
    if relative=='final/suite.jsonl' or p.suffix not in allowed:
        excluded.append(relative);continue
    raw=p.read_bytes()
    if raw.startswith(b'\x7fELF'):
        excluded.append(relative);continue
    try:raw.decode('utf-8')
    except UnicodeDecodeError:
        excluded.append(relative);continue
    files.append((relative,raw))
archive_manifest={'root':'literal-projection-parent/','files':[{'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in files],'excluded':excluded}
manifest_raw=(json.dumps(archive_manifest,indent=2)+'\n').encode()
manifest_path=target/(name+'-parent-manifest.json')
assert not manifest_path.exists()
manifest_path.write_bytes(manifest_raw)
archive_path=target/(name+'-parent-probes.tar.gz')
assert not archive_path.exists()
with tarfile.open(archive_path,'w:gz') as tar:
    for p,raw in files+[('ARCHIVE_CONTENTS.json',manifest_raw)]:
        info=tarfile.TarInfo('literal-projection-parent/'+p);info.size=len(raw);info.mode=0o600;info.mtime=0
        tar.addfile(info,io.BytesIO(raw))
# Validate exact regular safe UTF-8 payloads and hashes without extracting or running them.
expected={f['path']:f for f in archive_manifest['files']}
with tarfile.open(archive_path,'r:gz') as tar:
    members=tar.getmembers()
    assert len(members)==len(expected)+1
    for info in members:
        p=PurePosixPath(info.name)
        assert info.isfile() and not p.is_absolute() and '..' not in p.parts
        raw=tar.extractfile(info).read();raw.decode('utf-8');assert not raw.startswith(b'\x7fELF')
        relative=info.name.removeprefix('literal-projection-parent/')
        if relative=='ARCHIVE_CONTENTS.json':assert raw==manifest_raw
        else:
            row=expected[relative];assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
raw_path=target/(name+'-final-suite.jsonl.gz')
assert not raw_path.exists()
with raw_path.open('wb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0) as z:z.write((scratch/'final/suite.jsonl').read_bytes())
summary_path=target/(name+'-final-summary.json')
assert not summary_path.exists();summary_path.write_bytes((scratch/'final/summary.json').read_bytes())
rows=[{'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [archive_path,manifest_path,raw_path,summary_path]]
(scratch/'archive-receipt.json').write_text(json.dumps({'members':len(files)+1,'artifacts':rows},indent=2)+'\n')
print(json.dumps({'members':len(files)+1,'artifacts':rows},indent=2))
