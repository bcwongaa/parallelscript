class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
const held0: { value: Factory; other: Factory } = { value: source0, other: source1 };
const alias0 = held0;
use0(held0.value);
const held1: { value: Factory; other: Factory } = { value: source1, other: source2 };
const alias1 = held1;
use1(held1.value);
const held2: { value: Factory; other: Factory } = { value: source2, other: source3 };
const alias2 = held2;
use2(held2.value);
const held3: { value: Factory; other: Factory } = { value: source3, other: source4 };
const alias3 = held3;
use3(held3.value);
const held4: { value: Factory; other: Factory } = { value: source4, other: source5 };
const alias4 = held4;
use4(held4.value);
const held5: { value: Factory; other: Factory } = { value: source5, other: source6 };
const alias5 = held5;
use5(held5.value);
const held6: { value: Factory; other: Factory } = { value: source6, other: source7 };
const alias6 = held6;
use6(held6.value);
const held7: { value: Factory; other: Factory } = { value: source7, other: source8 };
const alias7 = held7;
use7(held7.value);
const held8: { value: Factory; other: Factory } = { value: source8, other: source9 };
const alias8 = held8;
use8(held8.value);
const held9: { value: Factory; other: Factory } = { value: source9, other: source10 };
const alias9 = held9;
use9(held9.value);
const held10: { value: Factory; other: Factory } = { value: source10, other: source11 };
const alias10 = held10;
use10(held10.value);
const held11: { value: Factory; other: Factory } = { value: source11, other: source0 };
const alias11 = held11;
use11(held11.value);
