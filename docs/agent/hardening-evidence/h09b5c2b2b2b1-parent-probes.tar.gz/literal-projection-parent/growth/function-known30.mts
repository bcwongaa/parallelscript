class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(f: Factory): void { const box: Box<C12> = f(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(f: Factory): void { const box: Box<C13> = f(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(f: Factory): void { const box: Box<C14> = f(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(f: Factory): void { const box: Box<C15> = f(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(f: Factory): void { const box: Box<C16> = f(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(f: Factory): void { const box: Box<C17> = f(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(f: Factory): void { const box: Box<C18> = f(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(f: Factory): void { const box: Box<C19> = f(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(f: Factory): void { const box: Box<C20> = f(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(f: Factory): void { const box: Box<C21> = f(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(f: Factory): void { const box: Box<C22> = f(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(f: Factory): void { const box: Box<C23> = f(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(f: Factory): void { const box: Box<C24> = f(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(f: Factory): void { const box: Box<C25> = f(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(f: Factory): void { const box: Box<C26> = f(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(f: Factory): void { const box: Box<C27> = f(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(f: Factory): void { const box: Box<C28> = f(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(f: Factory): void { const box: Box<C29> = f(new C29()); console.log(box.value.tag); }
const held0: { value: Factory; other: Factory } = { value: source0, other: source1 };
use0(held0.value);
const held1: { value: Factory; other: Factory } = { value: source1, other: source2 };
use1(held1.value);
const held2: { value: Factory; other: Factory } = { value: source2, other: source3 };
use2(held2.value);
const held3: { value: Factory; other: Factory } = { value: source3, other: source4 };
use3(held3.value);
const held4: { value: Factory; other: Factory } = { value: source4, other: source5 };
use4(held4.value);
const held5: { value: Factory; other: Factory } = { value: source5, other: source6 };
use5(held5.value);
const held6: { value: Factory; other: Factory } = { value: source6, other: source7 };
use6(held6.value);
const held7: { value: Factory; other: Factory } = { value: source7, other: source8 };
use7(held7.value);
const held8: { value: Factory; other: Factory } = { value: source8, other: source9 };
use8(held8.value);
const held9: { value: Factory; other: Factory } = { value: source9, other: source10 };
use9(held9.value);
const held10: { value: Factory; other: Factory } = { value: source10, other: source11 };
use10(held10.value);
const held11: { value: Factory; other: Factory } = { value: source11, other: source12 };
use11(held11.value);
const held12: { value: Factory; other: Factory } = { value: source12, other: source13 };
use12(held12.value);
const held13: { value: Factory; other: Factory } = { value: source13, other: source14 };
use13(held13.value);
const held14: { value: Factory; other: Factory } = { value: source14, other: source15 };
use14(held14.value);
const held15: { value: Factory; other: Factory } = { value: source15, other: source16 };
use15(held15.value);
const held16: { value: Factory; other: Factory } = { value: source16, other: source17 };
use16(held16.value);
const held17: { value: Factory; other: Factory } = { value: source17, other: source18 };
use17(held17.value);
const held18: { value: Factory; other: Factory } = { value: source18, other: source19 };
use18(held18.value);
const held19: { value: Factory; other: Factory } = { value: source19, other: source20 };
use19(held19.value);
const held20: { value: Factory; other: Factory } = { value: source20, other: source21 };
use20(held20.value);
const held21: { value: Factory; other: Factory } = { value: source21, other: source22 };
use21(held21.value);
const held22: { value: Factory; other: Factory } = { value: source22, other: source23 };
use22(held22.value);
const held23: { value: Factory; other: Factory } = { value: source23, other: source24 };
use23(held23.value);
const held24: { value: Factory; other: Factory } = { value: source24, other: source25 };
use24(held24.value);
const held25: { value: Factory; other: Factory } = { value: source25, other: source26 };
use25(held25.value);
const held26: { value: Factory; other: Factory } = { value: source26, other: source27 };
use26(held26.value);
const held27: { value: Factory; other: Factory } = { value: source27, other: source28 };
use27(held27.value);
const held28: { value: Factory; other: Factory } = { value: source28, other: source29 };
use28(held28.value);
const held29: { value: Factory; other: Factory } = { value: source29, other: source0 };
use29(held29.value);
