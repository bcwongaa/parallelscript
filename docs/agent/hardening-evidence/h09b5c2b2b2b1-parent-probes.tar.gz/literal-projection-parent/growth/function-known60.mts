class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(f: Factory): void { const box: Box<C12> = f(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(f: Factory): void { const box: Box<C13> = f(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(f: Factory): void { const box: Box<C14> = f(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(f: Factory): void { const box: Box<C15> = f(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(f: Factory): void { const box: Box<C16> = f(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(f: Factory): void { const box: Box<C17> = f(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(f: Factory): void { const box: Box<C18> = f(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(f: Factory): void { const box: Box<C19> = f(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(f: Factory): void { const box: Box<C20> = f(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(f: Factory): void { const box: Box<C21> = f(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(f: Factory): void { const box: Box<C22> = f(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(f: Factory): void { const box: Box<C23> = f(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(f: Factory): void { const box: Box<C24> = f(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(f: Factory): void { const box: Box<C25> = f(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(f: Factory): void { const box: Box<C26> = f(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(f: Factory): void { const box: Box<C27> = f(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(f: Factory): void { const box: Box<C28> = f(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(f: Factory): void { const box: Box<C29> = f(new C29()); console.log(box.value.tag); }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(f: Factory): void { const box: Box<C30> = f(new C30()); console.log(box.value.tag); }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(f: Factory): void { const box: Box<C31> = f(new C31()); console.log(box.value.tag); }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(f: Factory): void { const box: Box<C32> = f(new C32()); console.log(box.value.tag); }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(f: Factory): void { const box: Box<C33> = f(new C33()); console.log(box.value.tag); }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(f: Factory): void { const box: Box<C34> = f(new C34()); console.log(box.value.tag); }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(f: Factory): void { const box: Box<C35> = f(new C35()); console.log(box.value.tag); }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(f: Factory): void { const box: Box<C36> = f(new C36()); console.log(box.value.tag); }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(f: Factory): void { const box: Box<C37> = f(new C37()); console.log(box.value.tag); }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(f: Factory): void { const box: Box<C38> = f(new C38()); console.log(box.value.tag); }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(f: Factory): void { const box: Box<C39> = f(new C39()); console.log(box.value.tag); }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(f: Factory): void { const box: Box<C40> = f(new C40()); console.log(box.value.tag); }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(f: Factory): void { const box: Box<C41> = f(new C41()); console.log(box.value.tag); }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(f: Factory): void { const box: Box<C42> = f(new C42()); console.log(box.value.tag); }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(f: Factory): void { const box: Box<C43> = f(new C43()); console.log(box.value.tag); }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(f: Factory): void { const box: Box<C44> = f(new C44()); console.log(box.value.tag); }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(f: Factory): void { const box: Box<C45> = f(new C45()); console.log(box.value.tag); }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(f: Factory): void { const box: Box<C46> = f(new C46()); console.log(box.value.tag); }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(f: Factory): void { const box: Box<C47> = f(new C47()); console.log(box.value.tag); }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(f: Factory): void { const box: Box<C48> = f(new C48()); console.log(box.value.tag); }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(f: Factory): void { const box: Box<C49> = f(new C49()); console.log(box.value.tag); }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(f: Factory): void { const box: Box<C50> = f(new C50()); console.log(box.value.tag); }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(f: Factory): void { const box: Box<C51> = f(new C51()); console.log(box.value.tag); }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(f: Factory): void { const box: Box<C52> = f(new C52()); console.log(box.value.tag); }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(f: Factory): void { const box: Box<C53> = f(new C53()); console.log(box.value.tag); }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(f: Factory): void { const box: Box<C54> = f(new C54()); console.log(box.value.tag); }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(f: Factory): void { const box: Box<C55> = f(new C55()); console.log(box.value.tag); }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(f: Factory): void { const box: Box<C56> = f(new C56()); console.log(box.value.tag); }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(f: Factory): void { const box: Box<C57> = f(new C57()); console.log(box.value.tag); }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(f: Factory): void { const box: Box<C58> = f(new C58()); console.log(box.value.tag); }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(f: Factory): void { const box: Box<C59> = f(new C59()); console.log(box.value.tag); }
const held0: { value: Factory; other: Factory } = { value: source0, other: source1 };
use0(held0.value);
const held1: { value: Factory; other: Factory } = { value: source1, other: source2 };
use1(held1.value);
const held2: { value: Factory; other: Factory } = { value: source2, other: source3 };
use2(held2.value);
const held3: { value: Factory; other: Factory } = { value: source3, other: source4 };
use3(held3.value);
const held4: { value: Factory; other: Factory } = { value: source4, other: source5 };
use4(held4.value);
const held5: { value: Factory; other: Factory } = { value: source5, other: source6 };
use5(held5.value);
const held6: { value: Factory; other: Factory } = { value: source6, other: source7 };
use6(held6.value);
const held7: { value: Factory; other: Factory } = { value: source7, other: source8 };
use7(held7.value);
const held8: { value: Factory; other: Factory } = { value: source8, other: source9 };
use8(held8.value);
const held9: { value: Factory; other: Factory } = { value: source9, other: source10 };
use9(held9.value);
const held10: { value: Factory; other: Factory } = { value: source10, other: source11 };
use10(held10.value);
const held11: { value: Factory; other: Factory } = { value: source11, other: source12 };
use11(held11.value);
const held12: { value: Factory; other: Factory } = { value: source12, other: source13 };
use12(held12.value);
const held13: { value: Factory; other: Factory } = { value: source13, other: source14 };
use13(held13.value);
const held14: { value: Factory; other: Factory } = { value: source14, other: source15 };
use14(held14.value);
const held15: { value: Factory; other: Factory } = { value: source15, other: source16 };
use15(held15.value);
const held16: { value: Factory; other: Factory } = { value: source16, other: source17 };
use16(held16.value);
const held17: { value: Factory; other: Factory } = { value: source17, other: source18 };
use17(held17.value);
const held18: { value: Factory; other: Factory } = { value: source18, other: source19 };
use18(held18.value);
const held19: { value: Factory; other: Factory } = { value: source19, other: source20 };
use19(held19.value);
const held20: { value: Factory; other: Factory } = { value: source20, other: source21 };
use20(held20.value);
const held21: { value: Factory; other: Factory } = { value: source21, other: source22 };
use21(held21.value);
const held22: { value: Factory; other: Factory } = { value: source22, other: source23 };
use22(held22.value);
const held23: { value: Factory; other: Factory } = { value: source23, other: source24 };
use23(held23.value);
const held24: { value: Factory; other: Factory } = { value: source24, other: source25 };
use24(held24.value);
const held25: { value: Factory; other: Factory } = { value: source25, other: source26 };
use25(held25.value);
const held26: { value: Factory; other: Factory } = { value: source26, other: source27 };
use26(held26.value);
const held27: { value: Factory; other: Factory } = { value: source27, other: source28 };
use27(held27.value);
const held28: { value: Factory; other: Factory } = { value: source28, other: source29 };
use28(held28.value);
const held29: { value: Factory; other: Factory } = { value: source29, other: source30 };
use29(held29.value);
const held30: { value: Factory; other: Factory } = { value: source30, other: source31 };
use30(held30.value);
const held31: { value: Factory; other: Factory } = { value: source31, other: source32 };
use31(held31.value);
const held32: { value: Factory; other: Factory } = { value: source32, other: source33 };
use32(held32.value);
const held33: { value: Factory; other: Factory } = { value: source33, other: source34 };
use33(held33.value);
const held34: { value: Factory; other: Factory } = { value: source34, other: source35 };
use34(held34.value);
const held35: { value: Factory; other: Factory } = { value: source35, other: source36 };
use35(held35.value);
const held36: { value: Factory; other: Factory } = { value: source36, other: source37 };
use36(held36.value);
const held37: { value: Factory; other: Factory } = { value: source37, other: source38 };
use37(held37.value);
const held38: { value: Factory; other: Factory } = { value: source38, other: source39 };
use38(held38.value);
const held39: { value: Factory; other: Factory } = { value: source39, other: source40 };
use39(held39.value);
const held40: { value: Factory; other: Factory } = { value: source40, other: source41 };
use40(held40.value);
const held41: { value: Factory; other: Factory } = { value: source41, other: source42 };
use41(held41.value);
const held42: { value: Factory; other: Factory } = { value: source42, other: source43 };
use42(held42.value);
const held43: { value: Factory; other: Factory } = { value: source43, other: source44 };
use43(held43.value);
const held44: { value: Factory; other: Factory } = { value: source44, other: source45 };
use44(held44.value);
const held45: { value: Factory; other: Factory } = { value: source45, other: source46 };
use45(held45.value);
const held46: { value: Factory; other: Factory } = { value: source46, other: source47 };
use46(held46.value);
const held47: { value: Factory; other: Factory } = { value: source47, other: source48 };
use47(held47.value);
const held48: { value: Factory; other: Factory } = { value: source48, other: source49 };
use48(held48.value);
const held49: { value: Factory; other: Factory } = { value: source49, other: source50 };
use49(held49.value);
const held50: { value: Factory; other: Factory } = { value: source50, other: source51 };
use50(held50.value);
const held51: { value: Factory; other: Factory } = { value: source51, other: source52 };
use51(held51.value);
const held52: { value: Factory; other: Factory } = { value: source52, other: source53 };
use52(held52.value);
const held53: { value: Factory; other: Factory } = { value: source53, other: source54 };
use53(held53.value);
const held54: { value: Factory; other: Factory } = { value: source54, other: source55 };
use54(held54.value);
const held55: { value: Factory; other: Factory } = { value: source55, other: source56 };
use55(held55.value);
const held56: { value: Factory; other: Factory } = { value: source56, other: source57 };
use56(held56.value);
const held57: { value: Factory; other: Factory } = { value: source57, other: source58 };
use57(held57.value);
const held58: { value: Factory; other: Factory } = { value: source58, other: source59 };
use58(held58.value);
const held59: { value: Factory; other: Factory } = { value: source59, other: source0 };
use59(held59.value);
