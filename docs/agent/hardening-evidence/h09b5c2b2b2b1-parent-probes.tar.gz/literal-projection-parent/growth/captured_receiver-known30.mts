class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(f: Factory): void { const box: Box<C0> = f(new C0()); console.log(box.value.tag); }
function read0(r: Maker): Factory { return r.make; }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(f: Factory): void { const box: Box<C1> = f(new C1()); console.log(box.value.tag); }
function read1(r: Maker): Factory { return r.make; }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(f: Factory): void { const box: Box<C2> = f(new C2()); console.log(box.value.tag); }
function read2(r: Maker): Factory { return r.make; }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(f: Factory): void { const box: Box<C3> = f(new C3()); console.log(box.value.tag); }
function read3(r: Maker): Factory { return r.make; }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(f: Factory): void { const box: Box<C4> = f(new C4()); console.log(box.value.tag); }
function read4(r: Maker): Factory { return r.make; }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(f: Factory): void { const box: Box<C5> = f(new C5()); console.log(box.value.tag); }
function read5(r: Maker): Factory { return r.make; }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(f: Factory): void { const box: Box<C6> = f(new C6()); console.log(box.value.tag); }
function read6(r: Maker): Factory { return r.make; }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(f: Factory): void { const box: Box<C7> = f(new C7()); console.log(box.value.tag); }
function read7(r: Maker): Factory { return r.make; }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(f: Factory): void { const box: Box<C8> = f(new C8()); console.log(box.value.tag); }
function read8(r: Maker): Factory { return r.make; }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(f: Factory): void { const box: Box<C9> = f(new C9()); console.log(box.value.tag); }
function read9(r: Maker): Factory { return r.make; }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(f: Factory): void { const box: Box<C10> = f(new C10()); console.log(box.value.tag); }
function read10(r: Maker): Factory { return r.make; }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(f: Factory): void { const box: Box<C11> = f(new C11()); console.log(box.value.tag); }
function read11(r: Maker): Factory { return r.make; }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(f: Factory): void { const box: Box<C12> = f(new C12()); console.log(box.value.tag); }
function read12(r: Maker): Factory { return r.make; }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(f: Factory): void { const box: Box<C13> = f(new C13()); console.log(box.value.tag); }
function read13(r: Maker): Factory { return r.make; }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(f: Factory): void { const box: Box<C14> = f(new C14()); console.log(box.value.tag); }
function read14(r: Maker): Factory { return r.make; }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(f: Factory): void { const box: Box<C15> = f(new C15()); console.log(box.value.tag); }
function read15(r: Maker): Factory { return r.make; }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(f: Factory): void { const box: Box<C16> = f(new C16()); console.log(box.value.tag); }
function read16(r: Maker): Factory { return r.make; }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(f: Factory): void { const box: Box<C17> = f(new C17()); console.log(box.value.tag); }
function read17(r: Maker): Factory { return r.make; }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(f: Factory): void { const box: Box<C18> = f(new C18()); console.log(box.value.tag); }
function read18(r: Maker): Factory { return r.make; }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(f: Factory): void { const box: Box<C19> = f(new C19()); console.log(box.value.tag); }
function read19(r: Maker): Factory { return r.make; }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(f: Factory): void { const box: Box<C20> = f(new C20()); console.log(box.value.tag); }
function read20(r: Maker): Factory { return r.make; }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(f: Factory): void { const box: Box<C21> = f(new C21()); console.log(box.value.tag); }
function read21(r: Maker): Factory { return r.make; }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(f: Factory): void { const box: Box<C22> = f(new C22()); console.log(box.value.tag); }
function read22(r: Maker): Factory { return r.make; }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(f: Factory): void { const box: Box<C23> = f(new C23()); console.log(box.value.tag); }
function read23(r: Maker): Factory { return r.make; }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(f: Factory): void { const box: Box<C24> = f(new C24()); console.log(box.value.tag); }
function read24(r: Maker): Factory { return r.make; }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(f: Factory): void { const box: Box<C25> = f(new C25()); console.log(box.value.tag); }
function read25(r: Maker): Factory { return r.make; }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(f: Factory): void { const box: Box<C26> = f(new C26()); console.log(box.value.tag); }
function read26(r: Maker): Factory { return r.make; }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(f: Factory): void { const box: Box<C27> = f(new C27()); console.log(box.value.tag); }
function read27(r: Maker): Factory { return r.make; }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(f: Factory): void { const box: Box<C28> = f(new C28()); console.log(box.value.tag); }
function read28(r: Maker): Factory { return r.make; }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(f: Factory): void { const box: Box<C29> = f(new C29()); console.log(box.value.tag); }
function read29(r: Maker): Factory { return r.make; }
const held0: { value: Maker; other: Maker } = { value: new M0(), other: new M1() };
use0(read0(held0.value));
const held1: { value: Maker; other: Maker } = { value: new M1(), other: new M2() };
use1(read1(held1.value));
const held2: { value: Maker; other: Maker } = { value: new M2(), other: new M3() };
use2(read2(held2.value));
const held3: { value: Maker; other: Maker } = { value: new M3(), other: new M4() };
use3(read3(held3.value));
const held4: { value: Maker; other: Maker } = { value: new M4(), other: new M5() };
use4(read4(held4.value));
const held5: { value: Maker; other: Maker } = { value: new M5(), other: new M6() };
use5(read5(held5.value));
const held6: { value: Maker; other: Maker } = { value: new M6(), other: new M7() };
use6(read6(held6.value));
const held7: { value: Maker; other: Maker } = { value: new M7(), other: new M8() };
use7(read7(held7.value));
const held8: { value: Maker; other: Maker } = { value: new M8(), other: new M9() };
use8(read8(held8.value));
const held9: { value: Maker; other: Maker } = { value: new M9(), other: new M10() };
use9(read9(held9.value));
const held10: { value: Maker; other: Maker } = { value: new M10(), other: new M11() };
use10(read10(held10.value));
const held11: { value: Maker; other: Maker } = { value: new M11(), other: new M12() };
use11(read11(held11.value));
const held12: { value: Maker; other: Maker } = { value: new M12(), other: new M13() };
use12(read12(held12.value));
const held13: { value: Maker; other: Maker } = { value: new M13(), other: new M14() };
use13(read13(held13.value));
const held14: { value: Maker; other: Maker } = { value: new M14(), other: new M15() };
use14(read14(held14.value));
const held15: { value: Maker; other: Maker } = { value: new M15(), other: new M16() };
use15(read15(held15.value));
const held16: { value: Maker; other: Maker } = { value: new M16(), other: new M17() };
use16(read16(held16.value));
const held17: { value: Maker; other: Maker } = { value: new M17(), other: new M18() };
use17(read17(held17.value));
const held18: { value: Maker; other: Maker } = { value: new M18(), other: new M19() };
use18(read18(held18.value));
const held19: { value: Maker; other: Maker } = { value: new M19(), other: new M20() };
use19(read19(held19.value));
const held20: { value: Maker; other: Maker } = { value: new M20(), other: new M21() };
use20(read20(held20.value));
const held21: { value: Maker; other: Maker } = { value: new M21(), other: new M22() };
use21(read21(held21.value));
const held22: { value: Maker; other: Maker } = { value: new M22(), other: new M23() };
use22(read22(held22.value));
const held23: { value: Maker; other: Maker } = { value: new M23(), other: new M24() };
use23(read23(held23.value));
const held24: { value: Maker; other: Maker } = { value: new M24(), other: new M25() };
use24(read24(held24.value));
const held25: { value: Maker; other: Maker } = { value: new M25(), other: new M26() };
use25(read25(held25.value));
const held26: { value: Maker; other: Maker } = { value: new M26(), other: new M27() };
use26(read26(held26.value));
const held27: { value: Maker; other: Maker } = { value: new M27(), other: new M28() };
use27(read27(held27.value));
const held28: { value: Maker; other: Maker } = { value: new M28(), other: new M29() };
use28(read28(held28.value));
const held29: { value: Maker; other: Maker } = { value: new M29(), other: new M0() };
use29(read29(held29.value));
