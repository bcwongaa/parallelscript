import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

repo, out = map(Path, sys.argv[1:3])
out.mkdir(parents=True, exist_ok=True)
def source_hashes():
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=repo).decode().split('\0')
    result = {}
    for name in names:
        path = repo / name
        if name.startswith(('pts/', 'cmd/', 'internal/')) and path.is_file() and path.suffix in ('.go', '.pts', '.ts', '.c', '.h'):
            result[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
before = source_hashes()
(out/'sources-before.json').write_text(json.dumps(before, indent=2)+'\n')
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')
start = time.monotonic()
with (out/'build.out').open('wb') as stdout, (out/'build.err').open('wb') as stderr:
    build = subprocess.run(['make','build'], cwd=repo, env=env, stdout=stdout, stderr=stderr)
cli = digest(repo/'pts-bin/pts')
code = None
if build.returncode == 0:
    with (out/'suite.jsonl').open('wb') as stdout, (out/'suite.err').open('wb') as stderr:
        code = subprocess.run(['go','test','-count=1','-json','-p','4','-parallel','4','-timeout','40m','./pts/...','./cmd/pts/'], cwd=repo, env=env, stdout=stdout, stderr=stderr).returncode
counts = collections.Counter()
corpus = collections.Counter()
packages = {}
failures = []
if (out/'suite.jsonl').exists():
    for line in (out/'suite.jsonl').open():
        try: event = json.loads(line)
        except ValueError: continue
        action = event.get('Action')
        test = event.get('Test')
        if test and action in ('pass','skip','fail'):
            counts[action]+=1
            if test.startswith('TestCorpusMatchesNode/'):
                corpus[action]+=1
        if not test and action in ('pass','skip','fail'):
            packages[event['Package']] = action
        if action == 'fail': failures.append(event)
after = source_hashes()
changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
receipt = {'build_exit':build.returncode, 'suite_exit':code, 'seconds':time.monotonic()-start, 'tests':dict(counts), 'corpus':dict(corpus), 'packages':packages, 'failures':failures, 'sources':len(before), 'changed':changed, 'cli_before':cli, 'cli_after':digest(repo/'pts-bin/pts'), 'stderr_bytes':(out/'suite.err').stat().st_size if (out/'suite.err').exists() else None}
(out/'summary.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
assert build.returncode == 0 and code == 0 and not changed and receipt['cli_before']==receipt['cli_after'] and not failures
