import json
import os
from pathlib import Path
import subprocess
import sys

repo, scratch = map(Path, sys.argv[1:3])
scratch.mkdir(parents=True, exist_ok=True)
path = repo/'pts/lower/container_sources.go'
original = path.read_text()
mutants = [
    ('ignore_container_uses','for _, read := range uses.reads {','for _, read := range uses.reads[:0] {','^TestLiteralProjectionUncertainContainersHaveUnknownSources$/receivers_false/^(property_write|method_call_this_escape|object_alias|array_method)$'),
    ('ignore_unselected_nondatum','\t\t\tdefault:\n\t\t\t\treturn nil\n\t\t\t}\n\t\t\tkey, ok := literalDataKey','\t\t\tdefault:\n\t\t\t\tcontinue\n\t\t\t}\n\t\t\tkey, ok := literalDataKey','^TestLiteralProjectionUncertainContainersHaveUnknownSources$/receivers_false/^unselected_getter$'),
]
rows = []
for name, before, after, selection in mutants:
    assert original.count(before) == 1
    source = scratch/(name+'.go')
    source.write_text(original.replace(before,after))
    overlay = scratch/(name+'.json')
    overlay.write_text(json.dumps({'Replace':{str(path):str(source)}}))
    argv=['go','test','-count=1','-json','-p','1','-parallel','1','-timeout','10m','-overlay',str(overlay),'./pts/lower','-run',selection]
    p = subprocess.run(argv,cwd=repo,env=dict(os.environ,GOMAXPROCS='1',PTS_REQUIRE_NODE='1'),capture_output=True,timeout=600)
    (scratch/(name+'.jsonl')).write_bytes(p.stdout)
    (scratch/(name+'.err')).write_bytes(p.stderr)
    events=[json.loads(line) for line in p.stdout.splitlines()]
    failed=[e.get('Test') for e in events if e['Action']=='fail' and e.get('Test')]
    assert p.returncode==1 and failed and b'build failed' not in p.stdout+p.stderr, (name,p.returncode,p.stderr)
    row={'name':name,'argv':argv,'exit':p.returncode,'failed_assertions':failed,'stderr_bytes':len(p.stderr)}
    rows.append(row)
    print(json.dumps(row),flush=True)
(scratch/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
