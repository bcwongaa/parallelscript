package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: strict emit|compile input output")
		os.Exit(2)
	}
	ctx := context.Background()
	var err error
	if os.Args[1] == "emit" {
		var code string
		code, err = driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
		if err == nil {
			err = os.WriteFile(os.Args[3], []byte(code), 0o600)
		}
	} else if os.Args[1] == "compile" {
		var tc *toolchain.Toolchain
		tc, err = toolchain.New()
		if err == nil {
			var rt *toolchain.Runtime
			rt, err = tc.Runtime(ctx, toolchain.Release)
			if err == nil {
				err = tc.CompileProgram(ctx, rt, []string{os.Args[2]}, os.Args[3])
			}
		}
	} else {
		err = fmt.Errorf("unknown action %q", os.Args[1])
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
