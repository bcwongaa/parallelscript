import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

repo, scratch, base, current = map(Path, sys.argv[1:5])
scratch.mkdir(parents=True, exist_ok=True)
env = dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
rows, commands = [], []
def run(argv, stem, timeout=180):
    start = time.monotonic()
    p = subprocess.run(list(map(str, argv)), env=env, capture_output=True, timeout=timeout)
    (scratch / (stem + '.out')).write_bytes(p.stdout)
    (scratch / (stem + '.err')).write_bytes(p.stderr)
    commands.append({'argv':list(map(str,argv)), 'exit':p.returncode, 'seconds':time.monotonic()-start, 'stem':stem})
    (scratch / 'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert p.returncode == 0, (stem, p.returncode, p.stderr.decode())
    return p

for kind in ('function', 'receiver', 'captured_receiver'):
    for unknown, n in [(False, 10), (False, 30), (False, 60), (True, 12)]:
        name = kind + '-' + ('unknown' if unknown else 'known') + str(n)
        source = ['class Box<T> { constructor(public value: T) {} }', 'type Factory = <T>(value: T) => Box<T>;', 'interface Maker { make<T>(value: T): Box<T>; }']
        for i in range(n):
            source.extend([f'class C{i} {{ tag = {i}; }}', f'function source{i}<T>(value: T): Box<T> {{ return new Box(value); }}', f'class M{i} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value); }} }}'])
            if kind == 'receiver':
                source.append(f'function use{i}(r: Maker): void {{ const box: Box<C{i}> = r.make(new C{i}()); console.log(box.value.tag); }}')
            else:
                source.append(f'function use{i}(f: Factory): void {{ const box: Box<C{i}> = f(new C{i}()); console.log(box.value.tag); }}')
            if kind == 'captured_receiver':
                source.append(f'function read{i}(r: Maker): Factory {{ return r.make; }}')
        for i in range(n):
            a, b = (f'source{i}', f'source{(i+1)%n}') if kind == 'function' else (f'new M{i}()', f'new M{(i+1)%n}()')
            value_type = 'Factory' if kind == 'function' else 'Maker'
            source.append(f'const held{i}: {{ value: {value_type}; other: {value_type} }} = {{ value: {a}, other: {b} }};')
            if unknown:
                source.append(f'const alias{i} = held{i};')
            expression = f'held{i}.value'
            if kind == 'captured_receiver':
                expression = f'read{i}({expression})'
            source.append(f'use{i}({expression});')
        path = scratch / (name + '.pts')
        path.write_text('\n'.join(source) + '\n')
        mts = path.with_suffix('.mts')
        mts.write_bytes(path.read_bytes())
        node = run([Path.home()/'.local/node/bin/node', '--no-warnings', '--experimental-transform-types', mts], name+'-node', 90)
        for round in range(2):
            versions = [('base',base),('current',current)] if round == 0 else [('current',current),('base',base)]
            for version, helper in versions:
                stem = f'{name}-{version}-{round}'
                cpath = scratch / (stem+'.c')
                run([helper, 'emit', path, cpath], stem)
                elapsed = commands[-1]['seconds']
                c = cpath.read_bytes()
                regex = rb'pts_fn_source(\d+)_C(\d+)\(' if kind == 'function' else rb'pts_fn_M(\d+)_make_C(\d+)\('
                pairs = len(set(re.findall(regex,c)))
                want = n*n if version == 'base' or unknown else n
                assert pairs == want, (name,version,pairs,want)
                row = {'name':name,'kind':kind,'n':n,'unknown':unknown,'round':round,'version':version,'pairs':pairs,'lines':c.count(b'\n'),'bytes':len(c),'sha256':hashlib.sha256(c).hexdigest(),'seconds':elapsed,'AllInstances':True}
                if round == 0:
                    binary = scratch / f'{name}-{version}.bin'
                    run([current,'compile',cpath,binary], stem+'-compile')
                    native = run([binary], stem+'-native', 45)
                    assert native.stdout == node.stdout, (name,version,native.stdout,node.stdout)
                    row['native_matches_strict_node'] = True
                    binary.unlink()
                rows.append(row)
                print(json.dumps(row),flush=True)
        if unknown:
            for round in range(2):
                assert (scratch/f'{name}-base-{round}.c').read_bytes() == (scratch/f'{name}-current-{round}.c').read_bytes(), 'unknown C changed'
        (scratch/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
