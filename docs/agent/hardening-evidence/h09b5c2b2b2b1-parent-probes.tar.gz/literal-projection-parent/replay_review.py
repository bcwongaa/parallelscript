import collections
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

repo, review, out, base, current = map(Path, sys.argv[1:6])
out.mkdir(parents=True, exist_ok=True)
env = dict(os.environ, GOMAXPROCS='1', PTS_HOME=str(repo), PTS_REQUIRE_NODE='1')
commands = []
def run(argv, name, timeout=180):
    argv = list(map(str, argv))
    p = subprocess.run(argv, cwd=repo, env=env, capture_output=True, timeout=timeout)
    (out/(name+'.out')).write_bytes(p.stdout)
    (out/(name+'.err')).write_bytes(p.stderr)
    row = {'argv':argv, 'name':name, 'exit':p.returncode}
    commands.append(row)
    (out/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    return p

overlay = {'Replace':{}}
for name in ['review_container_sources_test.go','review_container_keys_test.go','review_instantiation_sources_test.go']:
    target = out/name
    target.write_bytes((review/name).read_bytes())
    overlay['Replace'][str(repo/'pts/lower'/name)] = str(target)
overlay_path = out/'source-overlay.json'
overlay_path.write_text(json.dumps(overlay,indent=2)+'\n')
p = run(['go','test','-count=1','-json','-p','1','-parallel','1','-timeout','10m','-overlay',overlay_path,'./pts/lower','-run','^TestReviewContainer'], 'source-controls', 600)
events=[json.loads(x) for x in p.stdout.splitlines()]
counts={a:sum(e['Action']==a and bool(e.get('Test')) for e in events) for a in ['pass','fail','skip']}
assert p.returncode==0 and counts['fail']==0
records=json.loads((review/'native-matrix-results.json').read_text())['records']
rows=[]
for record in records:
    name=record['name']; source=Path(record['source']); raw=source.read_bytes()
    if 'sha256' in record: assert hashlib.sha256(raw).hexdigest()==record['sha256']
    (out/(name+'.pts')).write_bytes(raw)
    mts=out/(name+'.mts'); mts.write_bytes(raw)
    node=run([Path.home()/'.local/node/bin/node','--no-warnings','--experimental-transform-types',mts],name+'-node')
    assert node.returncode==record['node']['returncode']==0 and node.stdout.decode()==record['node']['stdout']
    row={'name':name,'source_sha256':hashlib.sha256(raw).hexdigest()}
    for version, helper in [('base',base),('current',current)]:
        c=out/(name+'-'+version+'.c')
        emitted=run([helper,'emit',source,c],name+'-'+version+'-emit')
        assert emitted.returncode==record[version]['build']['returncode'],(name,version,emitted.stderr)
        status={'emit_exit':emitted.returncode}
        if emitted.returncode==0:
            binary=out/(name+'-'+version+'.bin')
            compiled=run([current,'compile',c,binary],name+'-'+version+'-compile')
            assert compiled.returncode==0,(name,compiled.stderr)
            native=run([binary],name+'-'+version+'-native')
            binary.unlink()
            assert native.returncode==0 and native.stdout==node.stdout and not native.stderr,(name,version,native.stdout,node.stdout)
            status['node_match']=True
            code=c.read_text()
            status['c_sha256']=hashlib.sha256(c.read_bytes()).hexdigest()
            if 'expected_rows' in record and record['expected_rows'] is not None:
                pattern=r'\bpts_fn_source([0-2])_C0\(' if record['kind']=='function' else r'\bpts_fn_M([0-2])_make_C0\('
                actual=sorted(set(int(x) for x in re.findall(pattern,code)))
                assert actual==record[version]['rows'],(name,version,actual,record[version]['rows'])
                if version=='current': assert actual==record['expected_rows']
                status['rows']=actual
        else:
            assert b'PTS1001' in emitted.stderr,(name,version,emitted.stderr)
            status['node_match']=False
        row[version]=status
    rows.append(row)
    (out/'native-replay.json').write_text(json.dumps(rows,indent=2)+'\n')

source=review/'instantiation_this.pts'
raw=source.read_bytes(); (out/'instantiation_this.pts').write_bytes(raw)
mts=out/'instantiation_this.mts';mts.write_bytes(raw)
node=run([Path.home()/'.local/node/bin/node','--no-warnings','--experimental-transform-types',mts],'instantiation-node')
assert node.returncode==0 and node.stdout==b'second\n7\n'
for version,helper in [('base',base),('current',current)]:
    emitted=run([helper,'emit',source,out/('instantiation-'+version+'.c')],'instantiation-'+version)
    assert emitted.returncode==1 and b'PTS1001' in emitted.stderr and b'`this` outside a class' in emitted.stderr
summary={'source_tests':counts,'native_inputs':len(rows),'base_node_matches':sum(x['base']['node_match'] for x in rows),'current_node_matches':sum(x['current']['node_match'] for x in rows),'pair_assertions_match_review':True,'instantiation_classification':'proof gap; native unsupported on both, Node mutates to second','commands':len(commands)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
