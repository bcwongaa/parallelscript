import json
import os
from pathlib import Path
import subprocess
import sys

repo, scratch, base, current = map(Path, sys.argv[1:5])
scratch.mkdir(parents=True, exist_ok=True)
env=dict(os.environ, PTS_HOME=str(repo), GOMAXPROCS='1')
commands=[]
def run(argv, stem):
    p=subprocess.run(list(map(str,argv)),env=env,capture_output=True,timeout=180)
    (scratch/(stem+'.out')).write_bytes(p.stdout)
    (scratch/(stem+'.err')).write_bytes(p.stderr)
    commands.append({'argv':list(map(str,argv)), 'stem':stem, 'exit':p.returncode})
    (scratch/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    return p
for name in ['generic_literal_projection_sources','generic_literal_projection_unknowns','generic_fallback_spares_unrelated_total']:
    path=repo/'pts/tests/run'/(name+'.pts')
    mts=scratch/(name+'.mts');mts.write_bytes(path.read_bytes())
    node=run([Path.home()/'.local/node/bin/node','--no-warnings','--experimental-transform-types',mts],name+'-node')
    expected='\n'.join(line.removeprefix('// ').removeprefix('//') for line in path.read_text().split('// expect:\n')[1].splitlines())+'\n'
    assert node.returncode==0 and node.stdout.decode()==expected
    for version,helper in [('base',base),('current',current)]:
        stem=name+'-'+version;cpath=scratch/(stem+'.c')
        emitted=run([helper,'emit',path,cpath],stem+'-emit')
        if name=='generic_fallback_spares_unrelated_total' and version=='base':
            assert emitted.returncode==1 and b'PTS1001' in emitted.stderr
            # This is a historical delayed-failure control, not a base native RED.
            continue
        assert emitted.returncode==0,(stem,emitted.stderr)
        binary=scratch/(stem+'.bin')
        compiled=run([current,'compile',cpath,binary],stem+'-compile')
        assert compiled.returncode==0,(stem,compiled.stderr)
        native=run([binary],stem+'-native')
        assert native.returncode==0 and native.stdout==node.stdout,(stem,native.stderr)
        binary.unlink()
print(json.dumps({'commands':len(commands),'strict_native_node_matches':5,'old_allinstances_delayed_failure_preserved':True},indent=2))
