H11b review round 5 probes (reviewer). Snapshot 7 = /tmp/h11b/snap7 (da004a459 + /tmp/h11b/snap7.patch); snapshot 6 and base as before.
scripts/run.sh [-w "snap7 snap6 base"] file.pts : builds with each CLI, runs, prints Node's output (.mts copy).
  replay/   all 94 earlier probes (r4/ = round 4's archive with rounds 1-3 inside) on snap7, snap6, base, Node; summary.txt
  s/        k01: string-like and non-string-like kinds in the both-missing `+` and loose `+=` (valueOf unions, string enums, branded strings, template literals, literal unions)
  cost/     rc3_element_pairs, rc3_string_index_pairs on snap7
  sweep_snap6_vs_snap7_diffs.txt  emit-c sweep of the 1,062 run tests: no C file differs from snapshot 6
