#!/bin/bash
# emit-c of each listed program (base copies) with snap7, for a diff against round 4 snap6 sweep.
list=$1
out=/tmp/h11b/review5/sweep/snap7
while read f; do
  n=$(basename "$f" .pts)
  ( cd "$(dirname "$f")" && PTS_HOME=/tmp/h11b/snap7 timeout 120 /tmp/h11b/snap7/pts-bin/pts emit-c "$f" -o "$out/$n.c" > "$out/$n.log" 2>&1 ) || echo "fail $?" >> "$out/$n.log"
done < "$list"
