H11b review round 4 probes (reviewer). Snapshot 6 = /tmp/h11b/snap6 (873ef9448 + /tmp/h11b/snap6.patch); snapshot 5 and base as before.
scripts/run.sh [-w "snap6 snap5 base"] file.pts : builds with each CLI, runs, prints Node's output (.mts copy).
  replay/   all 92 earlier probes (r3/ = round 3's archive with rounds 1-2 inside) on snap6, snap5, base, Node; summary.txt
  s/        h01: order and single evaluation of both sides of missingConcatenation, loose `+=` of elements/records/strings/typed arrays;
            h02: classes with valueOf in the both-missing fast path (R4-F1)
  cost/     rc3_element_pairs, rc3_string_index_pairs on snap6 (base/snap3/snap5 numbers: round 3's cost/results.txt)
  sweep_snap5_vs_snap6_diffs.txt  emit-c sweep of 1,062 run tests: 4 C files differ, all concatenations; no new diagnostics
