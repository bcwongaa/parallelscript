#!/bin/bash
# Usage: run.sh [-w "snap6 snap5 base"] file.pts...  Builds each with the listed CLIs (default
# snap6 snap5 base), runs them, prints Node output (.mts copy, --experimental-transform-types).
# Sequential; binaries deleted after running.
whichs="snap6 snap5 base"
if [ "$1" = "-w" ]; then whichs="$2"; shift 2; fi
B=/tmp/h11b/review4/bin
for f in "$@"; do
  n=$(basename "$f" .pts)
  echo "======== $f"
  for which in $whichs; do
    bin="$B/$n.$which.bin"
    if PTS_HOME=/tmp/h11b/$which /tmp/h11b/$which/pts-bin/pts build "$f" -o "$bin" > "$B/$n.$which.build.log" 2>&1; then
      out=$(cd /tmp && timeout 20 "$bin" 2>&1 | head -60; echo "exit=${PIPESTATUS[0]}")
      echo "-- $which:"; echo "$out"
      rm -f "$bin"
    else
      echo "-- $which build failed:"; grep -v '^\s*$' "$B/$n.$which.build.log" | head -8
    fi
  done
  tmp=$(mktemp -d $B/node-XXXX)
  cp "$f" "$tmp/$n.mts"
  echo "-- node:"
  (cd "$tmp" && timeout 20 ~/.local/node/bin/node --no-warnings --experimental-transform-types "$n.mts" 2>&1 | grep -v '^\s*at \|^Node.js v\|^$' | head -40; echo "exit=${PIPESTATUS[0]}")
  rm -rf "$tmp"
done
