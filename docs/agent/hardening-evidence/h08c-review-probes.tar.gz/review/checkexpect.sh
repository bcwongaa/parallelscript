#!/bin/bash
# checkexpect.sh file.pts...: compare Node's stdout to the file's expect block
for f in "$@"; do b=$(basename $f .pts); d=$(mktemp -d /tmp/h08c/review/ce.XXXX); cp $f $d/$b.mts
  (cd $d && ~/.local/node/bin/node --no-warnings --experimental-transform-types $b.mts > out.txt 2> err.txt; echo "exit $?" > code.txt)
  sed -n '/^\/\/ expect:$/,$p' $f | tail -n +2 | sed 's#^// \?##' > $d/exp.txt
  if cmp -s $d/exp.txt $d/out.txt; then echo "$b: expect==node ($(cat $d/code.txt), stderr $(wc -c < $d/err.txt)B)"; else echo "$b: EXPECT DIFFERS FROM NODE"; diff $d/exp.txt $d/out.txt | head; fi
  rm -rf $d; done
