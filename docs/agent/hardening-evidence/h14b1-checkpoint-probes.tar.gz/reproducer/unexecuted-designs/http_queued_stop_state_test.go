package tests

import (
	"path/filepath"
	"testing"

	"github.com/microsoft/typescript-go/pts/toolchain"
	"gotest.tools/v3/assert"
)

// Public libuv queue counters let these tests reach the active-second/queued-first
// state deterministically, without claiming a socket buffering race proves that state.
func TestHTTPServerQueuedStopLifecycleStates(t *testing.T) {
	heavyJobs <- struct{}{}
	defer func() { <-heavyJobs }()
	tc, err := toolchain.New()
	assert.NilError(t, err)
	for _, profile := range []toolchain.Profile{toolchain.Release, toolchain.Sanitize} {
		t.Run(profile.String(), func(t *testing.T) {
			rt, err := tc.Runtime(t.Context(), profile)
			assert.NilError(t, err)
			dir := t.TempDir()
			exe := filepath.Join(dir, "queued-stop-state")
			assert.NilError(t, tc.CompileProgram(t.Context(), rt, []string{"testdata/http_queued_stop/queued_stop.c"}, exe))
			for _, name := range []string{
				"idle", "queued_graceful", "queued_force", "reset_while_draining", "active_force",
				"queued_first_active_second_force", "queued_first_active_second_graceful",
			} {
				t.Run(name, func(t *testing.T) {
					got := execute(t, dir, []string{"ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0", "UBSAN_OPTIONS=halt_on_error=1"}, exe, name)
					t.Logf("exit=%d stdout=%q stderr=%q", got.exitCode, got.stdout, got.stderr)
					assert.Equal(t, got.exitCode, 0, "stdout: %s\nstderr: %s", got.stdout, got.stderr)
					assert.Equal(t, got.stdout, "queued stop lifecycle controls passed\n")
					assert.Equal(t, got.stderr, "")
				})
			}
		})
	}
}
