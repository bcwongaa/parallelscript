/* Deterministic lifecycle states; raw-wire tests separately prove byte delivery and TLS. */
#include "../../../runtime/src/http.c"

static unsigned aborted;
static pts_value aborted_request;

static void require(bool condition, const char *message) {
  if (!condition) {
    fprintf(stderr, "queued stop assertion: %s\n", message);
    exit(1);
  }
}

static void record_abort(pts_closure *self, pts_value request) {
  (void)self;
  aborted++;
  aborted_request = request;
}

static connection *make_connection(listener *l, bool active, size_t pending) {
  connection *c = checked(calloc(1, sizeof *c));
  require(uv_tcp_init(pts_uv_loop(), &c->tcp) == 0, "TCP handle initialization failed");
  c->listener = l;
  c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
  c->roots->request = active ? pts_value_from_number(17) : PTS_VALUE_ABSENT;
  c->busy = active;
  c->keep_alive = true;
  c->headers_pending = !active;
  /* libuv's public queue counter is the seam; no pretend socket writes are enqueued. */
  c->tcp.write_queue_size = pending;
  add_to_table(c);
  l->connections = c;
  return c;
}

static void complete_write(connection *c, size_t remaining, int status) {
  write_request *w = checked(calloc(1, sizeof *w));
  w->connection = c;
  w->bytes = checked(malloc(1));
  c->tcp.write_queue_size = remaining;
  on_written(&w->req, status);
}

static void drain_closing_handle(connection *c) {
  /* These fake requests are not in libuv's list, so its destroy invariant needs zero. */
  c->tcp.write_queue_size = 0;
  if (!c->closing) {
    close_connection(c);
  }
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
}

static void require_closed(connection *c, listener *l, uint32_t slot) {
  require(c->closing, "connection did not close after its last queued byte");
  require(l->connections == NULL, "closed connection remained in the listener list");
  require(table.connections[slot] == NULL, "closed connection retained its request id");
}

static void check_idle(listener *l) {
  connection *c = make_connection(l, false, 0);
  uint32_t slot = c->slot;
  stop_listening(l);
  require_closed(c, l, slot);
  require(aborted == 0, "idle close reported a handler abort");
  drain_closing_handle(c);
}

static void check_queued(listener *l, bool reset) {
  connection *c = make_connection(l, false, 4096);
  uint32_t slot = c->slot;
  for (unsigned i = 0; i < 3; i++) {
    stop_listening(l);
    require(!c->closing, "stop discarded a response whose libuv write queue is nonempty");
    require(table.connections[slot] == c, "queued connection lost its id before drain");
  }
  require(aborted == 0, "an answered request was aborted");
  if (reset) {
    complete_write(c, 1024, UV_ECONNRESET);
  } else {
    complete_write(c, 1024, 0);
    require(!c->closing, "an earlier write callback cut a later queued write");
    complete_write(c, 0, 0);
  }
  require_closed(c, l, slot);
  drain_closing_handle(c);
}

static void check_active(listener *l, bool queued_first, bool force) {
  connection *c = make_connection(l, true, queued_first ? 4096 : 0);
  uint32_t slot = c->slot;
  double id = id_of(c);
  pts_value request = c->roots->request;
  stop_listening(l);
  if (!force) {
    require(!c->closing && aborted == 0, "graceful stop aborted the active second handler");
    require(c->roots->request == request, "graceful stop lost the active request");
    if (queued_first) {
      complete_write(c, 0, 0);
      require(!c->closing, "first response drain closed an unanswered second request");
    }
  } else {
    require(aborted == 1 && aborted_request == request, "stop(true) did not abort the active request exactly once");
    require(c->roots->request == PTS_VALUE_ABSENT, "aborted request remained live");
    if (queued_first) {
      require(!c->closing, "aborting the active second handler discarded the queued first response");
      require(queued(c) == 4096, "aborting the handler changed the first response's write queue");
      pts_string *empty = pts_string_from_cstr("");
      pts_array *headers = pts_array_of(&pts_array_types[PTS_FIELD_STRING], NULL, 0);
      pts_http_respond(id, 200, empty, headers, pts_string_from_cstr("late"));
      require(!c->closing && queued(c) == 4096, "the aborted second handler's late answer was not ignored");
      stop_listening(l);
      require(aborted == 1 && !c->closing, "repeated stop aborted twice or cut the queued first response");
      complete_write(c, 1024, 0);
      require(!c->closing, "partial first response drain closed too early");
      complete_write(c, 0, 0);
    }
    require_closed(c, l, slot);
  }
  drain_closing_handle(c);
}

int main(int argc, char **argv) {
  require(argc == 2, "one lifecycle case is required");
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  pts_closure on_abort = {.code = (pts_function)record_abort};
  server s = {.on_disconnect = &on_abort};
  atomic_store(&s.stopped, true);
  bool force = strstr(argv[1], "force") != NULL;
  atomic_store(&s.close_active, force);
  listener l = {.server = &s};
  if (strcmp(argv[1], "idle") == 0) {
    check_idle(&l);
  } else if (strcmp(argv[1], "queued_graceful") == 0 || strcmp(argv[1], "queued_force") == 0) {
    check_queued(&l, false);
  } else if (strcmp(argv[1], "reset_while_draining") == 0) {
    check_queued(&l, true);
  } else if (strcmp(argv[1], "active_force") == 0) {
    check_active(&l, false, true);
  } else if (strcmp(argv[1], "queued_first_active_second_force") == 0) {
    check_active(&l, true, true);
  } else if (strcmp(argv[1], "queued_first_active_second_graceful") == 0) {
    check_active(&l, true, false);
  } else {
    require(false, "unknown lifecycle case");
  }
  puts("queued stop lifecycle controls passed");
  return 0;
}
