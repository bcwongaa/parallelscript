package tests

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"path/filepath"
	"syscall"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

// queuedBodySize is the body queued_stop.pts serves for GET /large: 8 MiB of 'Q'.
// A 4 MiB body can fit in the host's 4 MiB tcp_wmem maximum and survive uv_close in the
// kernel, which would hide C351. Do not shrink this, and do not accept a short read.
const queuedBodySize = 8 * 1024 * 1024

// queuedReadBuffer is the large client's SO_RCVBUF, set before connect. It is large
// enough for a TLS handshake and far too small to absorb queuedBodySize.
const queuedReadBuffer = 32 * 1024

// TestQueuedStop is C351: an exact 8 MiB keep-alive response must survive both
// stop modes and repeated stops. Pending handlers still abort; reset readers clean up.
// HTTP and verified HTTPS run with one loop and four reusePort loops.
func TestQueuedStop(t *testing.T) {
	t.Parallel()
	checkQueuedStopMatrix(t, buildServer(t, "queued_stop"))
}

func TestQueuedStopUnderSanitizers(t *testing.T) {
	t.Parallel()
	source, err := filepath.Abs(filepath.Join("http", "queued_stop.pts"))
	assert.NilError(t, err)
	checkQueuedStopMatrix(t, buildSanitized(t, source))
}

func checkQueuedStopMatrix(t *testing.T, exe string) {
	t.Helper()
	for _, threads := range []int{1, 4} {
		for _, secure := range []bool{false, true} {
			t.Run(fmt.Sprintf("threads=%d/TLS=%v", threads, secure), func(t *testing.T) {
				for _, stopPath := range []string{"/stop", "/abort", "/stop-repeat", "/abort-repeat"} {
					t.Run(stopPath[1:]+"_queued", func(t *testing.T) {
						checkQueuedResponseSurvivesStop(t, exe, secure, threads, stopPath, false)
					})
				}
				t.Run("abort_pending_handler", func(t *testing.T) {
					checkStopTrueAbortsBlockedHandler(t, exe, secure, threads)
				})
				t.Run("reset_while_draining", func(t *testing.T) {
					checkQueuedResponseSurvivesStop(t, exe, secure, threads, "/stop", true)
				})
			})
		}
	}
}

func startQueuedStop(t *testing.T, exe string, secure bool, threads int) (server *httpServer, address string, config *tls.Config) {
	t.Helper()
	env := []string{
		fmt.Sprintf("PTS_THREADS=%d", threads),
		"ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0",
		"UBSAN_OPTIONS=halt_on_error=1",
	}
	if secure {
		certFile, keyFile, root := serverFiles(t, t.TempDir())
		env = append(env, "QUEUED_STOP_CERT_FILE="+certFile, "QUEUED_STOP_KEY_FILE="+keyFile)
		config = &tls.Config{RootCAs: pool(root.cert), ServerName: "127.0.0.1", NextProtos: []string{"http/1.1"}}
	}
	var ports []string
	server, ports = startServer(t, exe, env...)
	assert.Equal(t, len(ports), 1)
	return server, "127.0.0.1:" + ports[0], config
}

func checkQueuedResponseSurvivesStop(t *testing.T, exe string, secure bool, threads int, stopPath string, reset bool) {
	t.Helper()
	server, address, config := startQueuedStop(t, exe, secure, threads)
	app := dialQueuedClient(t, address, config)
	assert.NilError(t, app.SetWriteDeadline(time.Now().Add(5*time.Second)))
	_, err := io.WriteString(app, httpRequest("/large", false))
	assert.NilError(t, err)
	assert.NilError(t, app.SetWriteDeadline(time.Time{}))

	gotCount, countErr := waitForCount(t, address, config, "1")
	assert.Assert(t, countErr == nil && gotCount == "1",
		"GET /large had not queued its response before stop: count=%q err=%v stderr:\n%s", gotCount, countErr, server.stderr)

	// Fully read, then left open: a genuinely idle connection must still close promptly.
	idleBody, idleClosed := readIdle(t, address, config)
	assert.Equal(t, idleBody, "idle")

	stopping, err := tryGet(address, stopPath, config)
	assert.NilError(t, err)
	wantStopBody := "stopping"
	if stopPath == "/abort" || stopPath == "/abort-repeat" {
		wantStopBody = "aborting"
	}
	assert.Equal(t, stopping, wantStopBody)
	expectServerLine(t, server, "stopped")
	waitQueuedListenerClosed(t, address)
	assert.Check(t, idleClosed(), "stop left a finished keep-alive connection open")

	if reset {
		resetQueuedClient(t, app)
	} else {
		status, body, reader, readErr := readLimitedBody(app)
		t.Logf("%s TLS=%v threads=%d: status=%d bytes=%d want=%d read_error=%v", stopPath, secure, threads, status, len(body), queuedBodySize, readErr)
		want := bytes.Repeat([]byte("Q"), queuedBodySize)
		if status != http.StatusOK || readErr != nil || len(body) != queuedBodySize || !bytes.Equal(body, want) {
			t.Fatalf("%s cut the queued keep-alive response: TLS=%v threads=%d status=%d got %d bytes, want %d, err=%v, stderr:\n%s",
				stopPath, secure, threads, status, len(body), queuedBodySize, readErr, server.stderr)
		}
		assertQueuedClosed(t, app, reader)
	}
	awaitExit(t, server)
	assert.Equal(t, server.stderr.String(), "")
}

func checkStopTrueAbortsBlockedHandler(t *testing.T, exe string, secure bool, threads int) {
	t.Helper()
	server, address, config := startQueuedStop(t, exe, secure, threads)
	var held interface{ closedByServer(*testing.T) bool }
	if secure {
		conn := dialTLS(t, address, config)
		conn.send(t, httpRequest("/hold", false))
		held = conn
	} else {
		conn := dialRaw(t, address)
		conn.send(t, httpRequest("/hold", false))
		held = conn
	}
	expectServerLine(t, server, "holding")
	aborting, err := tryGet(address, "/abort-repeat", config)
	assert.NilError(t, err)
	assert.Equal(t, aborting, "aborting")
	expectServerLines(t, server, "stopped", "aborted")
	assert.Assert(t, held.closedByServer(t), "stop(true) did not close the pending handler's connection without its late answer")
	awaitExit(t, server)
	assert.Equal(t, server.stderr.String(), "")
}

func waitQueuedListenerClosed(t *testing.T, address string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		conn, err := net.DialTimeout("tcp", address, time.Second)
		if errors.Is(err, syscall.ECONNREFUSED) {
			return
		}
		assert.NilError(t, err)
		_ = conn.Close()
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatal("stop did not close every reusePort listener before the queued response was read")
}

func resetQueuedClient(t *testing.T, conn net.Conn) {
	t.Helper()
	if secured, ok := conn.(*tlsConn); ok {
		conn = secured.tcp.Conn
	}
	tcp := conn.(*net.TCPConn)
	assert.NilError(t, tcp.SetLinger(0))
	assert.NilError(t, tcp.Close())
}

func expectServerLines(t *testing.T, server *httpServer, lines ...string) {
	t.Helper()
	wanted := make(map[string]bool, len(lines))
	for _, line := range lines {
		wanted[line] = true
	}
	watchdog := time.AfterFunc(20*time.Second, func() { _ = server.cmd.Process.Kill() })
	defer watchdog.Stop()
	for len(wanted) > 0 {
		assert.Assert(t, server.lines.Scan(), "missing lines %v; stderr:\n%s", wanted, server.stderr)
		line := server.lines.Text()
		assert.Assert(t, wanted[line], "unexpected or repeated server line %q", line)
		delete(wanted, line)
	}
}

func expectServerLine(t *testing.T, server *httpServer, want string) {
	t.Helper()
	watchdog := time.AfterFunc(20*time.Second, func() { _ = server.cmd.Process.Kill() })
	defer watchdog.Stop()
	assert.Assert(t, server.lines.Scan(), "no line %q; stderr:\n%s", want, server.stderr)
	assert.Equal(t, server.lines.Text(), want)
}

func httpRequest(path string, closeAfter bool) string {
	connection := ""
	if closeAfter {
		connection = "Connection: close\r\n"
	}
	return "GET " + path + " HTTP/1.1\r\nHost: 127.0.0.1\r\n" + connection + "\r\n"
}

// dialQueuedClient connects with a small receive buffer and does not read.
// HTTPS verifies the throwaway CA.
func dialQueuedClient(t *testing.T, address string, config *tls.Config) net.Conn {
	t.Helper()
	dialer := &net.Dialer{
		Timeout: 5 * time.Second,
		Control: func(network, addr string, raw syscall.RawConn) error {
			var sockErr error
			err := raw.Control(func(fd uintptr) {
				sockErr = syscall.SetsockoptInt(int(fd), syscall.SOL_SOCKET, syscall.SO_RCVBUF, queuedReadBuffer)
			})
			if err != nil {
				return err
			}
			return sockErr
		},
	}
	conn, err := dialer.Dial("tcp", address)
	assert.NilError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	if config == nil {
		return conn
	}
	recorder := &recordingConn{Conn: conn}
	secured := tls.Client(recorder, config.Clone())
	ctx, cancel := context.WithTimeout(t.Context(), 10*time.Second)
	defer cancel()
	assert.NilError(t, secured.HandshakeContext(ctx))
	assert.Assert(t, len(secured.ConnectionState().VerifiedChains) > 0, "HTTPS client did not verify the throwaway CA")
	return &tlsConn{Conn: secured, tcp: recorder}
}

// readIdle reads GET /tiny on a keep-alive connection and reports whether stop closed it.
func readIdle(t *testing.T, address string, config *tls.Config) (string, func() bool) {
	t.Helper()
	if config == nil {
		conn := dialRaw(t, address)
		conn.send(t, httpRequest("/tiny", false))
		_, body := conn.response(t)
		return body, func() bool { return conn.closedByServer(t) }
	}
	conn := dialTLS(t, address, config)
	conn.send(t, httpRequest("/tiny", false))
	_, body := conn.response(t)
	return body, func() bool { return conn.closedByServer(t) }
}

// waitForCount polls GET /count until the body is want or the deadline passes.
// The last body and error are returned either way.
func waitForCount(t *testing.T, address string, config *tls.Config, want string) (string, error) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	var last string
	var lastErr error
	for {
		last, lastErr = tryGet(address, "/count", config)
		if lastErr == nil && last == want {
			return last, nil
		}
		if time.Now().After(deadline) {
			return last, lastErr
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func tryGet(address, path string, config *tls.Config) (string, error) {
	tcp, err := net.DialTimeout("tcp", address, 2*time.Second)
	if err != nil {
		return "", err
	}
	defer tcp.Close()
	var conn net.Conn = tcp
	if config != nil {
		secured := tls.Client(tcp, config.Clone())
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := secured.HandshakeContext(ctx); err != nil {
			return "", err
		}
		conn = secured
	}
	if err := conn.SetDeadline(time.Now().Add(2 * time.Second)); err != nil {
		return "", err
	}
	if _, err := io.WriteString(conn, httpRequest(path, true)); err != nil {
		return "", err
	}
	reader := bufio.NewReader(conn)
	response, err := http.ReadResponse(reader, nil)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil {
		return string(body), err
	}
	if response.StatusCode != http.StatusOK {
		return string(body), fmt.Errorf("status %d", response.StatusCode)
	}
	return string(body), nil
}

// readLimitedBody reads whatever the large client can still get after stop.
// A short body, unexpected EOF, or reset is returned, not asserted, so the caller
// can record the byte count. reader is the same buffer, for the following close check.
func readLimitedBody(conn net.Conn) (status int, body []byte, reader *bufio.Reader, err error) {
	if err := conn.SetReadDeadline(time.Now().Add(20 * time.Second)); err != nil {
		return 0, nil, nil, err
	}
	reader = bufio.NewReaderSize(conn, 4096)
	response, err := http.ReadResponse(reader, nil)
	if err != nil {
		buffered := reader.Buffered()
		pending, _ := reader.Peek(buffered)
		return 0, append([]byte(nil), pending...), reader, err
	}
	defer response.Body.Close()
	body, err = io.ReadAll(io.LimitReader(response.Body, queuedBodySize+1))
	return response.StatusCode, body, reader, err
}

func assertQueuedClosed(t *testing.T, conn net.Conn, reader *bufio.Reader) {
	t.Helper()
	if secured, ok := conn.(*tlsConn); ok {
		secured.reader = reader
		secured.endedWithCloseNotify(t)
		return
	}
	assert.NilError(t, conn.SetReadDeadline(time.Now().Add(5*time.Second)))
	n, err := reader.Read(make([]byte, 1))
	assert.Assert(t, n == 0 && err != nil && !isTimeout(err), "the queued connection stayed open after the full response: n=%d err=%v", n, err)
}
