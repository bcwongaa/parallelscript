package tests

import (
	"bufio"
	"bytes"
	"context"
	"crypto/tls"
	"fmt"
	"io"
	"net"
	"net/http"
	"syscall"
	"testing"
	"time"

	"gotest.tools/v3/assert"
)

// queuedBodySize is the body queued_stop.pts serves for GET /large: 8 MiB of 'Q'.
// A 4 MiB body can fit in the host's 4 MiB tcp_wmem maximum and survive uv_close in the
// kernel, which would hide C351. Do not shrink this, and do not accept a short read.
const queuedBodySize = 8 * 1024 * 1024

// queuedReadBuffer is the large client's SO_RCVBUF, set before connect. It is large
// enough for a TLS handshake and far too small to absorb queuedBodySize.
const queuedReadBuffer = 32 * 1024

// TestQueuedStop is C351. stop(false) must deliver a keep-alive response that the
// handler has already produced and that the client has not read, then close that
// connection so the process can exit. A keep-alive connection whose small response
// was already read must still be closed. stop(true) while a handler is blocked must
// still abort that request. HTTP and verified HTTPS, one loop. The short read is the
// base failure; do not weaken it to match the bug.
func TestQueuedStop(t *testing.T) {
	t.Parallel()
	exe := buildServer(t, "queued_stop")
	for _, secure := range []bool{false, true} {
		secure := secure
		name := "http"
		if secure {
			name = "https"
		}
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			t.Run("queued", func(t *testing.T) {
				t.Parallel()
				checkQueuedResponseSurvivesStop(t, exe, secure)
			})
			t.Run("abort", func(t *testing.T) {
				t.Parallel()
				checkStopTrueAbortsBlockedHandler(t, exe, secure)
			})
		})
	}
}

func startQueuedStop(t *testing.T, exe string, secure bool) (server *httpServer, address string, config *tls.Config) {
	t.Helper()
	env := []string{"PTS_THREADS=1"}
	if secure {
		certFile, keyFile, root := serverFiles(t, t.TempDir())
		env = append(env, "QUEUED_STOP_CERT_FILE="+certFile, "QUEUED_STOP_KEY_FILE="+keyFile)
		config = &tls.Config{RootCAs: pool(root.cert), ServerName: "127.0.0.1", NextProtos: []string{"http/1.1"}}
	}
	var ports []string
	server, ports = startServer(t, exe, env...)
	assert.Equal(t, len(ports), 1)
	return server, "127.0.0.1:" + ports[0], config
}

func checkQueuedResponseSurvivesStop(t *testing.T, exe string, secure bool) {
	server, address, config := startQueuedStop(t, exe, secure)
	scheme := "http"
	if secure {
		scheme = "https"
	}
	app := dialQueuedClient(t, address, config)
	assert.NilError(t, app.SetWriteDeadline(time.Now().Add(5*time.Second)))
	_, err := io.WriteString(app, httpRequest("/large", false))
	assert.NilError(t, err)
	assert.NilError(t, app.SetWriteDeadline(time.Time{}))

	gotCount, countErr := waitForCount(t, address, config, "1")
	assert.Assert(t, countErr == nil && gotCount == "1",
		"GET /large had not produced a response before stop: count=%q err=%v stderr:\n%s", gotCount, countErr, server.stderr)

	// Fully read, then left open. stop(false) must close this one on the base.
	idleBody, idleClosed := readIdle(t, address, config)
	assert.Equal(t, idleBody, "idle")

	stopping, err := tryGet(address, "/stop", config)
	assert.NilError(t, err)
	assert.Equal(t, stopping, "stopping", "stop(false) did not answer; stderr:\n%s", server.stderr)
	assert.Check(t, idleClosed(), "stop(false) left a finished keep-alive connection open")

	status, body, reader, readErr := readLimitedBody(app)
	want := bytes.Repeat([]byte("Q"), queuedBodySize)
	if status != http.StatusOK || readErr != nil || len(body) != queuedBodySize || !bytes.Equal(body, want) {
		head := body
		if len(head) > 48 {
			head = head[:48]
		}
		t.Fatalf("stop(false) cut the queued keep-alive %s response: status=%d got %d bytes, want %d, err=%v, head=%q, stderr:\n%s",
			scheme, status, len(body), queuedBodySize, readErr, head, server.stderr)
	}
	assertQueuedClosed(t, app, reader)
	awaitExit(t, server)
}

func checkStopTrueAbortsBlockedHandler(t *testing.T, exe string, secure bool) {
	server, address, config := startQueuedStop(t, exe, secure)
	var held interface{ closedByServer(*testing.T) bool }
	if secure {
		conn := dialTLS(t, address, config)
		conn.send(t, httpRequest("/hold", false))
		held = conn
	} else {
		conn := dialRaw(t, address)
		conn.send(t, httpRequest("/hold", false))
		held = conn
	}
	expectServerLine(t, server, "holding")
	aborting, err := tryGet(address, "/abort", config)
	assert.NilError(t, err)
	assert.Equal(t, aborting, "aborting")
	expectServerLine(t, server, "aborted")
	assert.Assert(t, held.closedByServer(t), "stop(true) did not close the connection whose handler was blocked")
	awaitExit(t, server)
}

func expectServerLine(t *testing.T, server *httpServer, want string) {
	t.Helper()
	watchdog := time.AfterFunc(20*time.Second, func() { _ = server.cmd.Process.Kill() })
	defer watchdog.Stop()
	assert.Assert(t, server.lines.Scan(), "no line %q; stderr:\n%s", want, server.stderr)
	assert.Equal(t, server.lines.Text(), want)
}

func httpRequest(path string, closeAfter bool) string {
	connection := ""
	if closeAfter {
		connection = "Connection: close\r\n"
	}
	return "GET " + path + " HTTP/1.1\r\nHost: 127.0.0.1\r\n" + connection + "\r\n"
}

// dialQueuedClient connects with a small receive buffer and does not read.
// HTTPS verifies the throwaway CA.
func dialQueuedClient(t *testing.T, address string, config *tls.Config) net.Conn {
	t.Helper()
	dialer := &net.Dialer{
		Timeout: 5 * time.Second,
		Control: func(network, addr string, raw syscall.RawConn) error {
			var sockErr error
			err := raw.Control(func(fd uintptr) {
				sockErr = syscall.SetsockoptInt(int(fd), syscall.SOL_SOCKET, syscall.SO_RCVBUF, queuedReadBuffer)
			})
			if err != nil {
				return err
			}
			return sockErr
		},
	}
	conn, err := dialer.Dial("tcp", address)
	assert.NilError(t, err)
	t.Cleanup(func() { _ = conn.Close() })
	if config == nil {
		return conn
	}
	secured := tls.Client(conn, config.Clone())
	ctx, cancel := context.WithTimeout(t.Context(), 10*time.Second)
	defer cancel()
	assert.NilError(t, secured.HandshakeContext(ctx))
	assert.Assert(t, len(secured.ConnectionState().VerifiedChains) > 0, "HTTPS client did not verify the throwaway CA")
	return secured
}

// readIdle reads GET /tiny on a keep-alive connection and reports whether stop closed it.
func readIdle(t *testing.T, address string, config *tls.Config) (string, func() bool) {
	t.Helper()
	if config == nil {
		conn := dialRaw(t, address)
		conn.send(t, httpRequest("/tiny", false))
		_, body := conn.response(t)
		return body, func() bool { return conn.closedByServer(t) }
	}
	conn := dialTLS(t, address, config)
	conn.send(t, httpRequest("/tiny", false))
	_, body := conn.response(t)
	return body, func() bool { return conn.closedByServer(t) }
}

// waitForCount polls GET /count until the body is want or the deadline passes.
// The last body and error are returned either way.
func waitForCount(t *testing.T, address string, config *tls.Config, want string) (string, error) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	var last string
	var lastErr error
	for {
		last, lastErr = tryGet(address, "/count", config)
		if lastErr == nil && last == want {
			return last, nil
		}
		if time.Now().After(deadline) {
			return last, lastErr
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func tryGet(address, path string, config *tls.Config) (string, error) {
	tcp, err := net.DialTimeout("tcp", address, 2*time.Second)
	if err != nil {
		return "", err
	}
	defer tcp.Close()
	var conn net.Conn = tcp
	if config != nil {
		secured := tls.Client(tcp, config.Clone())
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := secured.HandshakeContext(ctx); err != nil {
			return "", err
		}
		conn = secured
	}
	if err := conn.SetDeadline(time.Now().Add(2 * time.Second)); err != nil {
		return "", err
	}
	if _, err := io.WriteString(conn, httpRequest(path, true)); err != nil {
		return "", err
	}
	reader := bufio.NewReader(conn)
	response, err := http.ReadResponse(reader, nil)
	if err != nil {
		return "", err
	}
	defer response.Body.Close()
	body, err := io.ReadAll(response.Body)
	if err != nil {
		return string(body), err
	}
	if response.StatusCode != http.StatusOK {
		return string(body), fmt.Errorf("status %d", response.StatusCode)
	}
	return string(body), nil
}

// readLimitedBody reads whatever the large client can still get after stop.
// A short body, unexpected EOF, or reset is returned, not asserted, so the caller
// can record the byte count. reader is the same buffer, for the following close check.
func readLimitedBody(conn net.Conn) (status int, body []byte, reader *bufio.Reader, err error) {
	if err := conn.SetReadDeadline(time.Now().Add(20 * time.Second)); err != nil {
		return 0, nil, nil, err
	}
	reader = bufio.NewReaderSize(conn, 4096)
	response, err := http.ReadResponse(reader, nil)
	if err != nil {
		buffered := reader.Buffered()
		pending, _ := reader.Peek(buffered)
		return 0, append([]byte(nil), pending...), reader, err
	}
	defer response.Body.Close()
	body, err = io.ReadAll(response.Body)
	return response.StatusCode, body, reader, err
}

func assertQueuedClosed(t *testing.T, conn net.Conn, reader *bufio.Reader) {
	t.Helper()
	assert.NilError(t, conn.SetReadDeadline(time.Now().Add(5*time.Second)))
	n, err := reader.Read(make([]byte, 1))
	assert.Assert(t, n == 0 && err != nil && !isTimeout(err), "the queued connection stayed open after the full response: n=%d err=%v", n, err)
}
