// Build one include-http.c review probe without changing production source.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"time"

	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	source := flag.String("source", "", "absolute path of reviewed http.c")
	probe := flag.String("probe", "", "absolute path of the C test input")
	home := flag.String("home", "", "runtime and dependencies root")
	out := flag.String("out", "", "executable output path")
	sanitize := flag.Bool("sanitize", false, "use AddressSanitizer and UndefinedBehaviorSanitizer")
	flag.Parse()
	if *source == "" || *probe == "" || *home == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "source, probe, home and out are required")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	must(os.Setenv("PTS_HOME", *home))
	tc, err := toolchain.New()
	must(err)
	profile := toolchain.Release
	if *sanitize {
		profile = toolchain.Sanitize
	}
	rt, err := tc.Runtime(ctx, profile)
	must(err)
	wrapper := *out + ".c"
	must(os.MkdirAll(filepath.Dir(*out), 0755))
	must(os.WriteFile(wrapper, []byte(fmt.Sprintf("#define REVIEW_HTTP_SOURCE %q\n#include %q\n", *source, *probe)), 0644))
	must(tc.CompileProgram(ctx, rt, []string{wrapper}, *out))
	command := exec.CommandContext(ctx, *out)
	command.Env = append(os.Environ(), "ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=0", "UBSAN_OPTIONS=halt_on_error=1")
	command.Stdout, command.Stderr = os.Stdout, os.Stderr
	if err := command.Run(); err != nil {
		if exit, ok := err.(*exec.ExitError); ok {
			os.Exit(exit.ExitCode())
		}
		must(err)
	}
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}
