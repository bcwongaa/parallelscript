"""Bounded plain-HTTP public-API review probe; run with python3 -I and a prebuilt fixture."""
import argparse
import json
import os
import selectors
import signal
import socket
import subprocess
import time


def line(process, timeout=3):
    selector = selectors.DefaultSelector()
    selector.register(process.stdout, selectors.EVENT_READ)
    try:
        if not selector.select(timeout):
            raise TimeoutError("server stdout marker timed out")
        result = process.stdout.readline()
        if not result:
            raise RuntimeError("server stdout ended before marker")
        return result.decode().strip()
    finally:
        selector.close()


def connect(port):
    conn = socket.socket()
    conn.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 32768)
    conn.settimeout(3)
    conn.connect(("127.0.0.1", port))
    return conn


def request(path):
    return ("GET " + path + " HTTP/1.1\r\nHost: loopback\r\n\r\n").encode()


def read_to_end(conn):
    parts = []
    error = None
    try:
        while True:
            data = conn.recv(65536)
            if not data:
                break
            parts.append(data)
    except OSError as exc:
        error = repr(exc)
    return b"".join(parts), error


def run(exe, mode, size, threads, close_active):
    env = os.environ.copy()
    env.update({"PTS_THREADS": str(threads), "REVIEW_BODY_SIZE": str(size),
                "REVIEW_REUSE": "1" if threads > 1 else "0",
                "REVIEW_STOP_ACTIVE": "1" if close_active else "0"})
    process = subprocess.Popen([exe], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               start_new_session=True, bufsize=0)
    conn = None
    result = {"mode": mode, "size": size, "threads": threads, "stop_active": close_active}
    try:
        listening = line(process)
        port = int(listening.split()[1])
        conn = connect(port)
        if mode == "self":
            conn.sendall(request("/self-stop"))
            wire, error = read_to_end(conn)
            stdout, stderr = process.communicate(timeout=4)
            result.update({"wire": wire.decode(errors="replace"), "read_error": error,
                           "stdout": stdout.decode(), "stderr": stderr.decode(),
                           "exit": process.returncode})
        else:
            conn.sendall(request("/piece"))
            produced = line(process)
            if produced != "piece " + str(size):
                raise RuntimeError("unexpected marker: " + produced)
            time.sleep(0.03)  # The one-loop runtime finishes dispatch's response microtasks first.
            with connect(port) as stopper:
                stopper.sendall(request("/stop"))
                stop_wire, stop_error = read_to_end(stopper)
                if b"stopped" not in stop_wire or stop_error is not None:
                    raise RuntimeError("stop did not finish: " + repr((stop_wire, stop_error)))
            stopped = line(process)
            if stopped != "stopped":
                raise RuntimeError("unexpected stop marker: " + stopped)
            try:
                conn.sendall(request("/sentinel"))
                send_error = None
            except OSError as exc:
                send_error = repr(exc)
            time.sleep(0.03)  # Leave queued output blocked while the incoming follower is readable.
            wire, read_error = read_to_end(conn)
            stdout, stderr = process.communicate(timeout=4)
            head, separator, body = wire.partition(b"\r\n\r\n")
            result.update({"body_read": len(body), "has_headers": bool(separator),
                           "head": head.decode(errors="replace"), "read_error": read_error,
                           "send_error": send_error, "stdout": stdout.decode(),
                           "stderr": stderr.decode(), "exit": process.returncode,
                           "dispatch_after_stop": b"DISPATCH_AFTER_STOP" in stdout})
        return result
    finally:
        if conn is not None:
            conn.close()
        if process.poll() is None:
            os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=3)
        process.stdout.close()
        process.stderr.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("executable")
    parser.add_argument("--mode", choices=["self", "dispatch"], default="dispatch")
    parser.add_argument("--sizes", default="2097152,2359296,2621440,2883584,3145728,3407872,3670016,3932160")
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--stop-active", action="store_true")
    args = parser.parse_args()
    for size in ([1024] if args.mode == "self" else map(int, args.sizes.split(","))):
        try:
            print(json.dumps(run(args.executable, args.mode, size, args.threads, args.stop_active)), flush=True)
        except Exception as exc:
            print(json.dumps({"mode": args.mode, "size": size, "error": repr(exc)}), flush=True)
            raise


if __name__ == "__main__":
    main()
