// Build emitted public-API probe C with one explicitly selected HTTP runtime source.
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	source := flag.String("source", "", "absolute path of selected http.c")
	program := flag.String("program", "", "absolute path of emitted probe C")
	home := flag.String("home", "", "runtime and dependencies root")
	out := flag.String("out", "", "executable output path")
	flag.Parse()
	if *source == "" || *program == "" || *home == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "source, program, home and out are required")
		os.Exit(2)
	}
	must(os.Setenv("PTS_HOME", *home))
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()
	tc, err := toolchain.New()
	must(err)
	rt, err := tc.Runtime(ctx, toolchain.Release)
	must(err)
	must(os.MkdirAll(filepath.Dir(*out), 0755))
	wrapper := *out + ".http.c"
	must(os.WriteFile(wrapper, []byte(fmt.Sprintf("#include %q\n", *source)), 0644))
	must(tc.CompileProgram(ctx, rt, []string{*program, wrapper}, *out))
}

func must(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
}
