/* Deterministic C351 review regression: draining a stopped connection must never dispatch a follower. */
#ifndef REVIEW_HTTP_SOURCE
#define REVIEW_HTTP_SOURCE "../../../runtime/src/http.c"
#endif
#include REVIEW_HTTP_SOURCE

static unsigned dispatched;

static pts_value observe_request(pts_closure *self, double id, pts_string *method, pts_string *target,
                                 pts_array *headers, pts_string *body) {
  (void)self, (void)id, (void)method, (void)target, (void)headers, (void)body;
  dispatched++;
  return PTS_VALUE_UNDEFINED;
}

static void observe_disconnect(pts_closure *self, pts_value request) {
  (void)self, (void)request;
}

static void put_request(connection *c) {
  static const char request_bytes[] = "GET /must-not-dispatch HTTP/1.1\r\nHost: loopback\r\n\r\n";
  c->in = checked(malloc(sizeof request_bytes));
  memcpy(c->in, request_bytes, sizeof request_bytes);
  c->in_cap = sizeof request_bytes;
  c->in_len = sizeof request_bytes - 1;
}

static bool check_stopped_connection(bool close_active, bool buffered, size_t output_queued) {
  pts_closure on_request = {.code = (pts_function)observe_request};
  pts_closure on_disconnect = {.code = (pts_function)observe_disconnect};
  server s = {.on_request = &on_request, .on_disconnect = &on_disconnect};
  atomic_store(&s.stopped, true); /* pts_http_stop publishes this before stop_listening runs. */
  atomic_store(&s.close_active, close_active);
  listener l = {.server = &s};
  connection *c = checked(calloc(1, sizeof *c));
  uv_tcp_init(pts_uv_loop(), &c->tcp);
  c->listener = &l;
  c->headers_pending = true;
  c->roots = checked(GC_MALLOC_UNCOLLECTABLE(sizeof *c->roots));
  add_to_table(c);
  l.connections = c;
  /* A legal queue state before backpressure engages; no real write is needed to test dispatch gating. */
  c->tcp.write_queue_size = output_queued;
  if (buffered) {
    put_request(c);
  }
  dispatched = 0;
  stop_listening(&l);
  if (!buffered) {
    put_request(c); /* process is also called for a read already scheduled when stop ran. */
  }
  process(c);
  printf("close_active=%d buffered=%d queued=%zu dispatched=%u closing=%d\n",
         close_active, buffered, output_queued, dispatched, c->closing);
  bool passed = dispatched == 0;
  c->tcp.write_queue_size = 0; /* The synthetic queue has no uv_write request/callback. */
  close_connection(c);
  uv_run(pts_uv_loop(), UV_RUN_NOWAIT);
  return passed;
}

int main(int argc, char **argv) {
  setenv("PTS_THREADS", "1", 1);
  pts_runtime_init(argc, argv);
  unsigned failed = 0;
  const size_t output_sizes[] = {1, MAX_QUEUED};
  for (unsigned active = 0; active < 2; active++) {
    for (unsigned buffered = 0; buffered < 2; buffered++) {
      for (unsigned size = 0; size < sizeof output_sizes / sizeof *output_sizes; size++) {
        if (!check_stopped_connection(active != 0, buffered != 0, output_sizes[size])) {
          failed++;
        }
      }
    }
  }
  fprintf(failed != 0 ? stderr : stdout, "post-stop dispatch controls: %u/8 failed\n", failed);
  return failed != 0;
}
