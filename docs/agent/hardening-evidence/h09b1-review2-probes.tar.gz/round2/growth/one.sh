#!/bin/bash
# one.sh file.pts: emit C with each tree and mode alone (no fallback): base All/Declared, snap3 All/Value/Declared.
# Prints file, tree, mode, exit, C lines; keeps the C of Declared for a diff.
f=$1
out=/tmp/h09b1-review/round2/growth/c
mkdir -p $out
n=$(echo "$f" | sed 's|/tmp/h09b/snap3/pts/tests/||; s|/|__|g')
for spec in "base_tree all" "base_tree declared" "snap3 all" "snap3 value" "snap3 declared"; do
  set -- $spec
  t=$1; m=$2; arg=""; [ $m != all ] && arg=$m
  timeout 300 /tmp/h09b1-review/allinst/ptsall_$t "$f" $arg > $out/$n.$t.$m.c 2> $out/$n.$t.$m.err
  e=$?
  printf "%s\t%s\t%s\t%s\t%s\n" "$n" "$t" "$m" "$e" "$(wc -l < $out/$n.$t.$m.c)"
  [ $m != declared ] && rm -f $out/$n.$t.$m.c
done
