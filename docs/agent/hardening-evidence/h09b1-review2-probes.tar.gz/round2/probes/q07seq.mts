// One call site meets many descriptors at once on several threads: literals of four shapes
// (the site caches each one's field), a class with entries (never cached), a frozen class
// instance (a twin descriptor) and a class whose method isn't generic (cached: no field).
class Box<T> {
  constructor(public value: T) {}
}
interface Maker {
  make<T>(x: T): Box<T>;
}
class ClassMaker implements Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
class PlainMaker implements Maker {
  make(x: any): any {
    return new Box(x);
  }
}
const a = { a: 1, make<T>(x: T): Box<T> { return new Box(x); } };
const b = { b: "two", c: 3, make<T>(x: T): Box<T> { return new Box(x); } };
const c = { make<T>(x: T): Box<T> { return new Box(x); }, z: true };
const d = { d1: 1, d2: 2, d3: 3, d4: 4, make<T>(x: T): Box<T> { return new Box(x); } };
const frozen = Object.freeze(new ClassMaker());
const makers: Maker[] = [a, b, new ClassMaker(), c, frozen, d, new PlainMaker()];
const indexes: number[] = [];
for (let i = 0; i < 70000; i++) {
  indexes.push(i);
}
const sums = indexes.map((i) => {
  const m = makers[i % makers.length];
  try {
    const n: Box<number> = m.make(i);
    return n.value % 7;
  } catch (error: any) {
    return 100;
  }
});
let total = 0;
for (const s of sums) {
  total += s;
}
console.log(sums.length, total);
