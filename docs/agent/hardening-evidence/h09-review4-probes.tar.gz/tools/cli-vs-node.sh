#!/bin/bash
# cli-vs-node.sh CLI FILE...: any CLI (PTS_HOME=${PH:-/tmp/h09/snap6}) vs Node (.mts copy)
cli=$1; shift; node=$HOME/.local/node/bin/node; PH=${PH:-/tmp/h09/snap6}
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review4/run/c.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  so=$(cd "$d" && PTS_HOME=$PH timeout 300 $cli run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  if [ "$so" == "$no" ]; then echo "== $b: X=N"; else echo "== $b: X!N"; echo "-- cli"; echo "$so"; echo "-- node"; echo "$no"; fi
  rm -rf "$d"
done
