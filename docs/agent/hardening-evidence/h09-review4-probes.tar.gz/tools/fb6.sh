#!/bin/bash
# fb6.sh FILE5...: emit-c of each file with the snap5 trace CLI (the file as given, under snap5 or not) and the
# snap6 trace CLI (the same path with /tmp/h09/snap5 -> /tmp/h09/snap6): fallback used, exit codes, C lines, C same?
for f in "$@"; do f6=${f/\/tmp\/h09\/snap5\//\/tmp\/h09\/snap6\/}; d=$(mktemp -d /tmp/h09/review4/run/fb.XXXX)
  a=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap5 timeout 300 /tmp/h09/review3/ov/pts-trace emit-c "$f" -o $d/a.c 2>&1); ea=$?
  b=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap6 timeout 300 /tmp/h09/review4/ov/pts-trace6 emit-c "$f6" -o $d/b.c 2>&1); eb=$?
  fa=$(echo "$a" | grep -c '^PTS_FALLBACK'); fb=$(echo "$b" | grep -c '^PTS_FALLBACK')
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  same=$( [ -f $d/a.c ] && [ -f $d/b.c ] && cmp -s <(sed "s#/tmp/h09/snap5/#X/#g" $d/a.c) <(sed "s#/tmp/h09/snap6/#X/#g" $d/b.c) && echo Csame || echo Cdiff)
  echo "s5FB=$fa s6FB=$fb exit=$ea/$eb lines=$la/$lb $same $f6"
  rm -rf $d
done
