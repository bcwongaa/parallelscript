#!/bin/bash
# sweep4.sh OUTDIR FILE...: base, snap5, snap6 and Node outputs into OUTDIR/<name>.{b,5,6,n}; one status line each
out=$1; shift; mkdir -p $out; node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); tag=$(basename $(dirname $f))__$b; d=$(mktemp -d /tmp/h09/review4/run/s.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  [ -f $out/$tag.b ] || (cd "$d" && PTS_HOME=/tmp/h09/base timeout 300 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.b
  [ -f $out/$tag.5 ] || (cd "$d" && PTS_HOME=/tmp/h09/snap5 timeout 300 /tmp/h09/snap5/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.5
  (cd "$d" && PTS_HOME=/tmp/h09/snap6 timeout 300 /tmp/h09/snap6/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.6
  [ -f $out/$tag.n ] || (cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]") > $out/$tag.n
  rm -rf "$d"
  c() { cmp -s $out/$tag.$1 $out/$tag.$2 && echo "$1=$2" || echo "$1!$2"; }
  echo "$(c b n) $(c 5 n) $(c 6 n) $(c 5 6) $(c b 6) $tag"
done
