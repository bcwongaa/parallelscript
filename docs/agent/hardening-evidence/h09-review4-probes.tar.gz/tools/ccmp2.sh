#!/bin/bash
# ccmp2.sh CLI_A CLI_B FILE...: emit-c with two CLIs (PTS_HOME=/tmp/h09/snap6); Csame/Cdiff, exits, lines
A=$1; B=$2; shift 2
for f in "$@"; do d=$(mktemp -d /tmp/h09/review4/run/cc.XXXX)
  (cd $d && PTS_HOME=/tmp/h09/snap6 timeout 300 $A emit-c "$f" -o $d/a.c >$d/a.err 2>&1); ea=$?
  (cd $d && PTS_HOME=/tmp/h09/snap6 timeout 300 $B emit-c "$f" -o $d/b.c >$d/b.err 2>&1); eb=$?
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  if [ -f $d/a.c ] && [ -f $d/b.c ]; then cmp -s $d/a.c $d/b.c && s=Csame || s=Cdiff; else cmp -s $d/a.err $d/b.err && s=Esame || s=Ediff; fi
  echo "$s exit=$ea/$eb lines=$la/$lb $f"; rm -rf $d
done
