#!/bin/bash
# quad.sh FILE...: base, snap5, snap6 ($FIX) and Node (.mts copy). Status line: B/5/6 vs N, and 5 vs 6.
# QUIET=1 prints outputs only when something differs from Node or 5 != 6.
FIX=${FIX:-/tmp/h09/snap6}; S5=${S5:-/tmp/h09/snap5}; BASE=${BASE:-/tmp/h09/base}
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review4/run/q.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  bo=$(cd "$d" && PTS_HOME=$BASE timeout 300 $BASE/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  fo=$(cd "$d" && PTS_HOME=$S5 timeout 300 $S5/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  so=$(cd "$d" && PTS_HOME=$FIX timeout 300 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  st="B$([ "$bo" == "$no" ] && echo = || echo '!')N 5$([ "$fo" == "$no" ] && echo = || echo '!')N 6$([ "$so" == "$no" ] && echo = || echo '!')N 5$([ "$fo" == "$so" ] && echo = || echo '!')6 B$([ "$bo" == "$so" ] && echo = || echo '!')6"
  echo "== $b: $st"
  if [ "${QUIET:-}" != 1 ] || [ "$fo" != "$so" ] || [ "$so" != "$no" ]; then
    echo "-- base"; echo "$bo"
    if [ "$fo" == "$so" ]; then echo "-- snap5=snap6"; echo "$so"; else echo "-- snap5"; echo "$fo"; echo "-- snap6"; echo "$so"; fi
    [ "$so" != "$no" ] && { echo "-- node"; echo "$no"; }
  fi
  rm -rf "$d"
done
