#!/bin/bash
# Runs TestHTTPSServerAnswersCloseNotify five times while an HTTPS server on the same cores takes fresh and keep-alive clients (bounded).
D=/tmp/h33b/review4/srv
CPUS=${CPUS:-0,1}
GOMAXPROCS=2 /tmp/h33b/snap4/pts-bin/pts build $D/probe_server.pts -o $D/load.bin >/dev/null || exit 1
CERT_FILE=/tmp/h33b/review4/certs/ec.pem KEY_FILE=/tmp/h33b/review4/certs/ec-key.pem PTS_THREADS=2 REUSE=1 taskset -c $CPUS $D/load.bin > $D/ld.out 2> $D/ld.err &
spid=$!
for i in $(seq 1 100); do grep -q '^port' $D/ld.out 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2}' $D/ld.out)
GOMAXPROCS=2 taskset -c $CPUS /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca /tmp/h33b/review4/certs/ca.pem -workers 24 -d ${DUR:-60s} -modes fresh,keepalive,pipeline > $D/ld.stress 2>&1 &
lpid=$!
sleep 2
cd /tmp/h33b/snap4 && GOMAXPROCS=2 timeout 600 taskset -c $CPUS go test -count=5 -p 1 -v -run 'TestHTTPSServerSendsNothingAfterAFatalAlert|TestHTTPSServerAnswersCloseNotify|TestHTTPServersSurviveClientsThatResetMidPipeline' ./pts/tests/ 2>&1 | grep -E "^--- |^ok|^FAIL|alerts" | sort | uniq -c
wait $lpid
echo "load: $(head -1 $D/ld.stress)"
kill $spid; wait $spid 2>/dev/null; rm -f $D/load.bin
