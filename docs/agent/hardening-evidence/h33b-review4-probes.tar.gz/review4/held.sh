#!/bin/bash
# The held-request failure cases on snapshot 4: does the program's request get aborted?
D=/tmp/h33b/review4
GOMAXPROCS=2 taskset -c 0,1 /tmp/h33b/snap4/pts-bin/pts build $D/srv/probe_server.pts -o $D/srv/h.bin >/dev/null || exit 1
CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 $D/srv/h.bin > $D/srv/h.out 2> $D/srv/h.err &
pid=$!
for i in $(seq 1 100); do grep -q '^port' $D/srv/h.out 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2}' $D/srv/h.out)
for s in hold-garbage-held hold-then-garbage; do for t in 1.2 1.3; do $D/cnpaths/cnpaths 127.0.0.1:$port $s $t > /dev/null; done; done
sleep 0.3
echo "4 held requests whose session failed; the program saw $(grep -c aborted $D/srv/h.out) aborts; stderr $(wc -c < $D/srv/h.err) bytes"
kill $pid; wait $pid 2>/dev/null; rm -f $D/srv/h.bin
