#!/bin/bash
# expectcheck.sh TEST.pts...: compare the test's // expect: block with Node's stdout, base's and fix's.
export PATH="$HOME/.local/node/bin:$PATH"
out=/tmp/h08/rev2/out/expect; mkdir -p "$out"
for f in "$@"; do
  n=$(basename "$f" .pts)
  python3 -I -c '
import sys
lines=open(sys.argv[1]).read().split("\n")
i=lines.index("// expect:")
res=[]
for l in lines[i+1:]:
    if l.startswith("// "): res.append(l[3:])
    elif l=="//": res.append("")
    elif l=="": continue
    else: break
print("\n".join(res))' "$f" > "$out/$n.expect"
  sed 's/\.pts"/.mts"/g' "$f" | grep -v '^// skip:' > "$out/$n.mts"
  timeout 30 node --no-warnings --experimental-transform-types "$out/$n.mts" > "$out/$n.node" 2>&1
  for side in base fix; do
    if [ $side = base ]; then cli=/tmp/h08/base/pts-bin/pts; home=/tmp/h08/base; else cli=/tmp/h08/review2/pts-bin/pts; home=/tmp/h08/review2; fi
    grep -v '^// skip:' "$f" > "$out/$n.pts"
    PTS_HOME=$home timeout 300 $cli build "$out/$n.pts" -o "$out/$n.$side.bin" > "$out/$n.$side" 2>&1 && (timeout 30 "$out/$n.$side.bin" > "$out/$n.$side" 2>&1); rm -f "$out/$n.$side.bin"
  done
  printf "%-55s node==expect:%s base==expect:%s fix==expect:%s\n" "$n" \
    "$(cmp -s $out/$n.node $out/$n.expect && echo Y || echo N)" \
    "$(cmp -s $out/$n.base $out/$n.expect && echo Y || echo N)" \
    "$(cmp -s $out/$n.fix $out/$n.expect && echo Y || echo N)"
done
