#!/bin/bash
# emitall.sh: emit C for every pts/tests/{run,errors}/*.pts of the round-2 snapshot with the base and fixed compilers.
cd /tmp/h08/review2/pts/tests
for f in run/*.pts errors/*.pts; do
  n=$(echo $f | tr / _)
  PTS_HOME=/tmp/h08/base /tmp/h08/base/pts-bin/pts emit-c $f -o /tmp/h08/rev2/emitc/base/$n.c > /tmp/h08/rev2/emitc/base/$n.err 2>&1; echo "exit $?" >> /tmp/h08/rev2/emitc/base/$n.err
  PTS_HOME=/tmp/h08/review2 /tmp/h08/review2/pts-bin/pts emit-c $f -o /tmp/h08/rev2/emitc/fix/$n.c > /tmp/h08/rev2/emitc/fix/$n.err 2>&1; echo "exit $?" >> /tmp/h08/rev2/emitc/fix/$n.err
done
touch /tmp/h08/rev2/emitc/DONE
