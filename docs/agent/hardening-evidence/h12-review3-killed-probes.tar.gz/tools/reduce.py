#!/usr/bin/env python3
# usage: reduce.py IN.pts OUT.pts — greedily drops lines (and try/log lines) while snap4 prints an
# uncaught error that Node doesn't (the fuzz case's divergence)
import sys, subprocess, tempfile, shutil, os
def fails(lines):
    d = tempfile.mkdtemp(dir="/tmp/h12/review3/work")
    try:
        open(os.path.join(d, "p.pts"), "w").write("\n".join(lines) + "\n")
        shutil.copy(os.path.join(d, "p.pts"), os.path.join(d, "p.mts"))
        n = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=30)
        p = subprocess.run(["/tmp/h12/snap4/pts-bin/pts", "run", "p.pts"], cwd=d, capture_output=True, text=True, timeout=120, env=dict(os.environ, PTS_HOME="/tmp/h12/snap4"))
        return "Uncaught" in p.stdout + p.stderr and "Uncaught" not in n.stdout + n.stderr and "error TS" not in p.stdout + p.stderr
    finally:
        shutil.rmtree(d, ignore_errors=True)
lines = open(sys.argv[1]).read().rstrip("\n").split("\n")
assert fails(lines)
i = len(lines) - 1
while i >= 0:
    trial = lines[:i] + lines[i + 1:]
    if fails(trial):
        lines = trial
    i -= 1
open(sys.argv[2], "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
