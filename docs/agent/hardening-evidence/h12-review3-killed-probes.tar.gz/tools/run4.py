#!/usr/bin/env python3
# usage: run4.py OUT.json probe.pts...  — node (.mts copy), base, snap3, snap4 per probe; W workers (default 4)
import sys, json, subprocess, tempfile, shutil, os, concurrent.futures
CLIS = {"base": ("/tmp/h12/base/pts-bin/pts", "/tmp/h12/base"),
        "snap3": ("/tmp/h12/snap3/pts-bin/pts", "/tmp/h12/snap3"),
        "snap4": ("/tmp/h12/snap4/pts-bin/pts", "/tmp/h12/snap4")}
def run(path):
    d = tempfile.mkdtemp(dir="/tmp/h12/review3/work")
    try:
        shutil.copy(path, os.path.join(d, "p.mts")); shutil.copy(path, os.path.join(d, "p.pts"))
        res = {}
        try:
            r = subprocess.run(["/home/bryan/.local/node/bin/node", "--experimental-transform-types", "--no-warnings", "p.mts"], cwd=d, capture_output=True, text=True, timeout=30)
            res["node"] = (r.returncode, r.stdout + r.stderr)
        except subprocess.TimeoutExpired:
            res["node"] = (124, "")
        for name, (cli, home) in CLIS.items():
            try:
                r = subprocess.run([cli, "run", "p.pts"], cwd=d, capture_output=True, text=True, timeout=int(os.environ.get("T", "180")), env=dict(os.environ, PTS_HOME=home))
                res[name] = (r.returncode, (r.stdout + r.stderr).replace(d, "<d>"))
            except subprocess.TimeoutExpired:
                res[name] = (124, "TIMEOUT")
        return path, res
    finally:
        shutil.rmtree(d, ignore_errors=True)
out = {}
with concurrent.futures.ThreadPoolExecutor(max_workers=int(os.environ.get("W", "4"))) as ex:
    for path, res in ex.map(run, sys.argv[2:]):
        out[path] = res
        n = res["node"]
        tag = lambda k: "=" if res[k] == n else ("x%d" % res[k][0])
        print(f"{os.path.basename(path):45s} base{tag('base'):5s} snap3{tag('snap3'):5s} snap4{tag('snap4'):5s}" + ("   <-- snap4 differs from snap3" if res['snap4'] != res['snap3'] else ""), flush=True)
json.dump(out, open(sys.argv[1], "w"), indent=1)
