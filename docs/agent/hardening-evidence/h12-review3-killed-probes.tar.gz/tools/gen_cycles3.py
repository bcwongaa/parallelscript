#!/usr/bin/env python3
# Generates straight-line programs whose declared `string | undefined` variables write each
# other in cycles, with missing values entering through element reads, loose bindings,
# parameters and rest-tuple patterns; every read is narrowed by tsc to string.
import random, sys, os
out, n, seed = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
rng = random.Random(seed)
for case in range(n):
    k = rng.randint(3, 7)
    names = [f"v{i}" for i in range(k)]
    order = names[:]; rng.shuffle(order)
    lines = ["const arr: string[] = [];", "const full: string[] = ['xy'];", "const [lb] = arr;",
             "const r: [number, ...string[]] = [1];", "const ro: { k: [number, ...string[]] } = { k: [1] };", "const rows: [number, ...string[]][] = [[1]];", "const ros: { k: [number, ...string[]] }[] = [{ k: [1] }];", "let hh = 0;",
             ]
    in_fn = rng.random() < 0.4
    body = []
    decl = []
    for nm in order:
        init = rng.choice(['"init"', '"init"', '"init"', 'arr[5]', 'full[0]', 'lb'])
        if init == 'arr[5]' or init == 'lb':
            # initializer that may be missing; read only after another write so tsc narrows
            pass
        decl.append(f"let {nm}: string | undefined = {init};")
    # cycle edges first (in random order), with reads
    stmts = []
    for _ in range(rng.randint(k, 3 * k)):
        a, b = rng.sample(names, 2)
        kind = rng.random()
        if kind < 0.35:
            stmts.append(f"{a} = {b};")
        elif kind < 0.45:
            c = rng.choice(names)
            stmts.append(f"{a} = arr.length === {rng.randint(0, 1)} ? {b} : {c};")
        elif kind < 0.52:
            stmts.append(f"{{ const w = (): void => {{ {a} = {b}; }}; w(); }}")
        elif kind < 0.6:
            stmts.append(f"{a} ||= {b};")
        elif kind < 0.7:
            stmts.append(f"{a} = arr[{rng.randint(0, 3)}];")
        elif kind < 0.8:
            stmts.append(f"{a} = lb;")
        elif kind < 0.84:
            stmts.append(f"[hh, {a}] = r;")
        elif kind < 0.87:
            stmts.append(f"({{ k: [hh, {a}] }} = ro);")
        elif kind < 0.9:
            stmts.append(rng.choice([f"[[hh, {a}] = r] = rows;", f"[{{ k: [hh, ({a})] }}] = ros;", f"[[hh, {a}] = [0, 'dd']] = rows;"]))
        else:
            stmts.append(f"{a} = full[0];")
        # read only if a was written from something tsc types string
        stmts.append(f"try {{ console.log('{a}', {a}.length); }} catch (e) {{ console.log('{a}', (e as Error).name); }}")
    if in_fn:
        params = ", ".join(f"{nm}: string | undefined" for nm in names)
        body = [f"function run({params}): void {{"] + [f"  {nm} = {rng.choice(['full[0]', 'lb', 'arr[2]', '\"q\"'])};" for nm in names] + ["  " + s for s in stmts] + ["}", "run(" + ", ".join('"p"' for _ in names) + ");"]
        prog = lines + body
    else:
        prog = lines + decl + stmts
    open(os.path.join(out, f"cyc{seed}_{case:03d}.pts"), "w").write("\n".join(prog) + "\n")
