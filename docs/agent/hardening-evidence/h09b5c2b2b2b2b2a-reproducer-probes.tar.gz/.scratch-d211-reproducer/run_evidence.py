#!/usr/bin/env python3
"""Run one command and retain its exact argv, output and exit code."""
import argparse
import json
from pathlib import Path
import subprocess
import time


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cwd", required=True, type=Path)
    parser.add_argument("--label", required=True)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        parser.error("missing command")
    args.output.mkdir(parents=True, exist_ok=True)
    prefix = args.output / args.label
    started = time.time()
    with prefix.with_suffix(".stdout").open("wb") as stdout, prefix.with_suffix(".stderr").open("wb") as stderr:
        result = subprocess.run(command, cwd=args.cwd, stdout=stdout, stderr=stderr, check=False)
    metadata = {
        "argv": command,
        "cwd": str(args.cwd),
        "exit_code": result.returncode,
        "elapsed_seconds": time.time() - started,
    }
    prefix.with_suffix(".json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata))
    print(f"stdout={prefix.with_suffix('.stdout')}")
    print(f"stderr={prefix.with_suffix('.stderr')}")
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
