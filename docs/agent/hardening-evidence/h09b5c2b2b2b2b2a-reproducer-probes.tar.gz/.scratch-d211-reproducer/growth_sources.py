#!/usr/bin/env python3
"""Generate exact immutable-child extraction growth inputs, not measurements."""
import argparse
from pathlib import Path


def growth_source(kind: str, count: int, unknown: bool) -> str:
    lines = [
        "class Box<T> { constructor(public value: T, public origin: string) {} }",
        "type Factory = <T>(value: T) => Box<T>;",
        "interface Maker { make<T>(value: T): Box<T>; }",
    ]
    for index in range(count):
        lines += [
            f"class C{index} {{ tag = {index}; }}",
            f'function source{index}<T>(value: T): Box<T> {{ return new Box(value, "source{index}"); }}',
            f'class M{index} implements Maker {{ make<T>(value: T): Box<T> {{ return new Box(value, "M{index}"); }} }}',
        ]
        if kind == "receiver":
            lines.append(f"function use{index}(receiver: Maker): void {{ const box: Box<C{index}> = receiver.make(new C{index}()); console.log(box.origin, box.value.tag); }}")
        else:
            lines.append(f"function use{index}(factory: Factory): void {{ const box: Box<C{index}> = factory(new C{index}()); console.log(box.origin, box.value.tag); }}")
        if kind == "captured_receiver":
            lines.append(f"function read{index}(receiver: Maker): Factory {{ return receiver.make; }}")
        elif kind == "wrapper":
            lines.append(f"function read{index}(): Factory {{ const receiver: Maker = new M{index}(); return receiver.make; }}")
    for index in range(count):
        value = f"source{index}"
        value_type = "Factory"
        if kind in ("receiver", "captured_receiver"):
            value, value_type = f"new M{index}()", "Maker"
        elif kind == "wrapper":
            value = f"read{index}()"
        lines.append(f"const selected{index}: {value_type} = {value};")
        root_binding = "let" if unknown else "const"
        lines.append(f"{root_binding} root{index} = {{ branch: {{ rows: [{{ value: selected{index} }}] }} }};")
        lines.append(f"const rootAlias{index} = root{index}; const branch{index} = rootAlias{index}.branch; const rows{index} = branch{index}.rows; const child{index} = rows{index}[0]; const alias{index} = child{index};")
        selected = f"alias{index}.value"
        if kind == "captured_receiver":
            selected = f"read{index}({selected})"
        lines.append(f"use{index}({selected});")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    for kind in ("function", "receiver", "captured_receiver", "wrapper"):
        for count, unknown in ((10, False), (30, False), (60, False), (12, True)):
            mode = "unknown" if unknown else "known"
            path = args.output / f"{kind}_{mode}{count}.pts"
            path.write_text(growth_source(kind, count, unknown))
            print(path)


if __name__ == "__main__":
    main()
