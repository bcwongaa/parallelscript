#!/usr/bin/env python3
"""Summarize retained go-test JSON without dropping raw evidence."""
import json
from pathlib import Path
import sys

for path_text in sys.argv[1:]:
    path = Path(path_text)
    counts = {}
    failures = []
    messages = []
    for raw_line in path.read_text().splitlines():
        try:
            event = json.loads(raw_line)
        except json.JSONDecodeError:
            messages.append(raw_line)
            continue
        action = event.get("Action")
        if action in ("pass", "fail", "skip"):
            key = "test" if event.get("Test") else "package"
            label = f"{key}_{action}"
            counts[label] = counts.get(label, 0) + 1
            if action == "fail":
                failures.append(f"{event.get('Package', '')} {event.get('Test', '')}")
        if "Output" in event and any(marker in event["Output"] for marker in ("Error:", "error ", "target pairs", "assertion failed", "build failed")):
            messages.append(event["Output"].rstrip())
    print(path)
    print(json.dumps(counts, sort_keys=True))
    for failure in failures:
        print("FAIL", failure)
    for message in messages:
        print(message)
