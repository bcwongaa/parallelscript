#!/usr/bin/env python3
"""Check exact retained native, strict-ESM Node and fixture-oracle outputs."""
from pathlib import Path
import sys

fixture = Path(sys.argv[1])
evidence = Path(sys.argv[2])
lines = fixture.read_text().splitlines()
marker = lines.index("// expect:")
expected = "\n".join(line.removeprefix("// ") for line in lines[marker + 1:] if line.startswith("// ")) + "\n"
native = (evidence / "strict-fixture-native.stdout").read_text()
node = (evidence / "strict-fixture-node.stdout").read_text()
if native != node or native != expected:
    print("MISMATCH")
    print("EXPECTED", repr(expected))
    print("NATIVE", repr(native))
    print("NODE", repr(node))
    raise SystemExit(1)
for name in ("strict-fixture-native.stderr", "strict-fixture-node.stderr"):
    if (evidence / name).read_bytes():
        print(f"unexpected stderr: {name}")
        raise SystemExit(1)
print(f"MATCH: native == strict-ESM Node == explicit fixture oracle ({len(native.splitlines())} lines)")
print(native, end="")
