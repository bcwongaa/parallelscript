#!/usr/bin/env python3
"""Archive only owned sources and raw nonbinary evidence."""
from pathlib import Path
import tarfile
import sys

root = Path(sys.argv[1]).resolve()
scratch = root / ".scratch-d211-reproducer"
archive = scratch / "reproducer-d211-probes.tar.gz"
owned = [
    root / "pts/lower/extracted_container_sources_test.go",
    root / "pts/driver/extracted_container_flow_test.go",
    root / "pts/tests/run/generic_extracted_literal_container_sources.pts",
]
allowed = {".py", ".go", ".json", ".stdout", ".stderr", ".txt", ".sha", ".sha256", ".c", ".pts", ".mts"}
files = owned + sorted(path for path in scratch.rglob("*") if path.is_file() and not path.is_symlink() and path.suffix in allowed)
with tarfile.open(archive, "w:gz") as output:
    for path in files:
        output.add(path, arcname=str(path.relative_to(root)), recursive=False)
print(f"{archive}: {len(files)} files; {archive.stat().st_size} bytes; binaries excluded")
