#!/bin/bash
# multi.sh FILE...: run each with the trees in $TREES (default "base snap6 snap7 snap8"; each /tmp/h09/<t>, PTS_HOME the same)
# and Node (.mts copy). Status: <tree>=N or <tree>!N for each, then L=P or L!P (last tree vs the one before).
# QUIET=1 prints outputs only when the last tree differs from Node or from the one before.
TREES=${TREES:-"base snap6 snap7 snap8"}; node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review7/run/m.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  declare -A out; st=""; prev=""; last=""
  for t in $TREES; do o=$(cd "$d" && PTS_HOME=/tmp/h09/$t timeout 300 /tmp/h09/$t/pts-bin/pts run "$f" 2>&1; echo "[exit $?]"); out[$t]="$o"
    st="$st $t$([ "$o" == "$no" ] && echo = || echo '!')N"; prev=$last; last=$t; done
  lp=$([ "${out[$last]}" == "${out[$prev]}" ] && echo "L=P" || echo "L!P")
  echo "== $b:$st $lp"
  if [ "${QUIET:-}" != 1 ] || [ "${out[$last]}" != "$no" ] || [ "${out[$last]}" != "${out[$prev]}" ]; then
    for t in $TREES; do echo "-- $t"; echo "${out[$t]}"; done; echo "-- node"; echo "$no"; fi
  unset out; rm -rf "$d"
done
