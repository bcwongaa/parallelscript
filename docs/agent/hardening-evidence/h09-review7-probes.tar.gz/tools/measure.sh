#!/bin/bash
# measure.sh FILE TREE...: emit-c wall time (s) and peak RSS (MB) for each tree (/tmp/h09/<tree>, PTS_HOME the same)
f=$1; shift
for t in "$@"; do d=$(mktemp -d /tmp/h09/review7/run/ms.XXXX)
  /usr/bin/time -f "%e %M" -o $d/time env PTS_HOME=/tmp/h09/$t /tmp/h09/$t/pts-bin/pts emit-c "$f" -o $d/x.c >$d/err 2>&1; e=$?
  read s kb < $d/time; echo "$t exit=$e s=$s rss_mb=$((kb/1024)) lines=$([ -f $d/x.c ] && wc -l < $d/x.c || echo 0) $(basename $f)"; rm -rf $d
done
