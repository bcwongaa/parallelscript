#!/bin/bash
# ccmp2.sh CLI_A CLI_B FILE...: emit-c with two CLIs (PTS_HOME=${PH:-/tmp/h09/snap9}); Csame/Cdiff, exits, lines, ms
A=$1; B=$2; shift 2; PH=${PH:-/tmp/h09/snap9}
for f in "$@"; do d=$(mktemp -d /tmp/h09/review7/run/cc.XXXX)
  ta=$(date +%s%N); (cd $d && PTS_HOME=$PH timeout 300 $A emit-c "$f" -o $d/a.c >$d/a.err 2>&1); ea=$?; ta=$(( ($(date +%s%N)-ta)/1000000 ))
  tb=$(date +%s%N); (cd $d && PTS_HOME=$PH timeout 300 $B emit-c "$f" -o $d/b.c >$d/b.err 2>&1); eb=$?; tb=$(( ($(date +%s%N)-tb)/1000000 ))
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  if [ -f $d/a.c ] && [ -f $d/b.c ]; then cmp -s $d/a.c $d/b.c && s=Csame || s=Cdiff; else cmp -s $d/a.err $d/b.err && s=Esame || s=Ediff; fi
  echo "$s exit=$ea/$eb lines=$la/$lb ms=$ta/$tb $f"; rm -rf $d
done
