#!/bin/bash
# ccmp89.sh FILE...: emit-c with snap8 and snap9 CLIs: Csame/Cdiff (or Esame/Ediff on errors), exits, lines, ms
for f in "$@"; do d=$(mktemp -d /tmp/h09/review7/run/cc.XXXX)
  ta=$(date +%s%N); (cd $d && PTS_HOME=/tmp/h09/snap8 timeout 300 /tmp/h09/snap8/pts-bin/pts emit-c "$f" -o $d/a.c >$d/a.err 2>&1); ea=$?; ta=$(( ($(date +%s%N)-ta)/1000000 ))
  tb=$(date +%s%N); (cd $d && PTS_HOME=/tmp/h09/snap9 timeout 300 /tmp/h09/snap9/pts-bin/pts emit-c "$f" -o $d/b.c >$d/b.err 2>&1); eb=$?; tb=$(( ($(date +%s%N)-tb)/1000000 ))
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  if [ -f $d/a.c ] && [ -f $d/b.c ]; then cmp -s $d/a.c $d/b.c && s=Csame || s=Cdiff; else cmp -s $d/a.err $d/b.err && s=Esame || s=Ediff; fi
  echo "$s exit=$ea/$eb lines=$la/$lb ms=$ta/$tb $f"; rm -rf $d
done
