#!/bin/bash
# gotest.sh OVERLAY LOG: run the run/ tests, their Node comparison and the corpus with a
# compiler overlay (2 heavy jobs), from the reproducer's worktree.
set -uo pipefail
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a1febe54d0bef208f || exit 1
export PATH=/home/bryan/.local/node/bin:$PATH GOMAXPROCS=2
go test -overlay "$1" -count=1 -timeout 40m -run 'TestRun$|TestRunMatchesNode$|TestCorpusMatchesNode$' ./pts/tests/ > "$2" 2>&1
echo "exit $?" >> "$2"
