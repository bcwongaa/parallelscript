#!/bin/bash
# csize.sh CLI OUTDIR: emit the C of every corpus program and run test with CLI, and print
# "path bytes instances" per program (instances: lines of pts_instance tables).
set -uo pipefail
cli=$1; out=$2; mkdir -p "$out"
home=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a1febe54d0bef208f
export PTS_HOME=$home
ls $home/pts/tests/corpus/*/*.pts $home/pts/tests/run/*.pts | xargs -P 2 -I{} bash -c '
  f={}; n=$(echo "$f" | sed "s|.*/tests/||; s|/|__|g"); c='"$out"'/$n.c
  if '"$cli"' emit-c "$f" -o "$c" > /dev/null 2>&1; then
    echo "$n $(wc -c < "$c") $(grep -c "^  {.*(pts_function)pts_instance_" "$c")"
  else
    echo "$n FAILED 0"
  fi
  rm -f "$c"'
