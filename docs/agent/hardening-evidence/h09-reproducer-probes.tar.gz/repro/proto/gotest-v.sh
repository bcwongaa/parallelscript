#!/bin/bash
# gotest-v.sh OVERLAY RUNREGEX LOG: run some of pts/tests verbosely with a compiler overlay.
set -uo pipefail
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-a1febe54d0bef208f || exit 1
export PATH=/home/bryan/.local/node/bin:$PATH GOMAXPROCS=2
go test -overlay "$1" -count=1 -timeout 40m -v -run "$2" ./pts/tests/ > "$3" 2>&1
echo "exit $?" >> "$3"
