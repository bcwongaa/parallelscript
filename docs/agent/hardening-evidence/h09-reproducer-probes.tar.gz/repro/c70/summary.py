"""Summarize the C70 sibling results: verdict by form, by rest type and by result, and the
distinct diagnostics and outputs.

Usage: python3 -I summary.py RESULTS.json
"""
import collections
import json
import sys

results = json.load(open(sys.argv[1]))
dims = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
for name, r in results.items():
    form, rest, result = name.split("__")
    for key, value in (("form", form), ("rest", rest), ("result", result)):
        dims[key][value][r["verdict"]] += 1
print("overall", dict(collections.Counter(r["verdict"] for r in results.values())))
for key, table in dims.items():
    verdicts = sorted({v for c in table.values() for v in c})
    print(f"\n## by {key}")
    print(f"{key:22s} " + " ".join(f"{v:>8s}" for v in verdicts))
    for k in sorted(table):
        print(f"{k:22s} " + " ".join(f"{table[k][v]:8d}" for v in verdicts))
print("\n## diagnostics")
for d, n in collections.Counter(r["diag"][:220] for r in results.values() if r["diag"]).most_common():
    print(n, d)
print("\n## TYPEERR / WRONG outputs (pts | node)")
for d, n in collections.Counter((r["verdict"], r["pts"].strip()[:120], r["node"].strip()[:60]) for r in results.values() if r["verdict"] in ("TYPEERR", "WRONG")).most_common():
    print(n, d)
