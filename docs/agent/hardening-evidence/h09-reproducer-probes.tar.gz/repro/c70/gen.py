"""C70 siblings: generic callables whose rest parameter is a tuple (or rest tuple), returning
it (or something made from it) as an array type, reached through each kind of call.

Usage: python3 -I gen.py OUTDIR   (one program per case)
"""
import os
import sys

# (rest parameter type, call arguments, result type, body)
RESTS = {
    "pair": ("[T, T]", "1, 2"),
    "single": ("[T]", "1"),
    "triple": ("[T, T, T]", "1, 2, 3"),
    "optional": ("[T, T?]", "1, 2"),
    "optional_left_out": ("[T, T?]", "1"),
    "rest_elem": ("[T, ...T[]]", "1, 2, 3"),
    "plain_array": ("T[]", "1, 2"),
}
RESULTS = {
    "array": ("T[]", "items"),
    "readonly": ("readonly T[]", "items"),
    "Array": ("Array<T>", "items"),
    "tuple_same": (None, "items"),  # the rest type itself
    "spread_new": ("T[]", "[...items]"),
    "slice": ("T[]", "items.slice()"),
    "spread_call": ("T[]", "collect(...items)"),
}
HELPER = "function collect<U>(...xs: U[]): U[] {\n  return xs;\n}\n"

FORMS = {
    # The generic callable's definition and a call of it typed with T = number.
    "iface_class": ("interface Pairs {{\n  pair<T>(...items: {rest}): {res};\n}}\nclass P implements Pairs {{\n  pair<T>(...items: {rest}): {res} {{\n    return {body};\n  }}\n}}\nconst p: Pairs = new P();\n", "p.pair({args})"),
    "class_direct": ("class P {{\n  pair<T>(...items: {rest}): {res} {{\n    return {body};\n  }}\n}}\nconst p = new P();\n", "p.pair({args})"),
    "object_method": ("const p = {{\n  pair<T>(...items: {rest}): {res} {{\n    return {body};\n  }},\n}};\n", "p.pair({args})"),
    "iface_object_method": ("interface Pairs {{\n  pair<T>(...items: {rest}): {res};\n}}\nconst p: Pairs = {{\n  pair<T>(...items: {rest}): {res} {{\n    return {body};\n  }},\n}};\n", "p.pair({args})"),
    "decl_direct": ("function pair<T>(...items: {rest}): {res} {{\n  return {body};\n}}\n", "pair({args})"),
    "decl_value": ("function pair<T>(...items: {rest}): {res} {{\n  return {body};\n}}\nconst f: <T>(...items: {rest}) => {res} = pair;\n", "f({args})"),
    "const_arrow": ("const pair = <T>(...items: {rest}): {res} => {body};\n", "pair({args})"),
    "const_arrow_value": ("const pair = <T>(...items: {rest}): {res} => {body};\nconst f: <T>(...items: {rest}) => {res} = pair;\n", "f({args})"),
    "abstract_dispatched": ("abstract class Base {{\n  abstract pair<T>(...items: {rest}): {res};\n}}\nclass P extends Base {{\n  pair<T>(...items: {rest}): {res} {{\n    return {body};\n  }}\n}}\nconst p: Base = new P();\n", "p.pair({args})"),
}


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    n = 0
    for fname, (definition, call) in FORMS.items():
        for rname, (rest, args) in RESTS.items():
            for resname, (res, body) in RESULTS.items():
                if res is None:
                    res = rest
                    if rest == "T[]":
                        continue
                rest_t = rest.replace("T", "T")
                res_n = res.replace("T", "number")
                src = HELPER + definition.format(rest=rest, res=res, body=body) + \
                    f"try {{\n  const r: {res_n} = {call.format(args=args)};\n  console.log(r, r.length);\n}} catch (error: any) {{\n  console.log(error.name, error.message);\n}}\n"
                with open(os.path.join(out, f"{fname}__{rname}__{resname}.pts"), "w") as f:
                    f.write(src)
                n += 1
    print(n, "cases")


if __name__ == "__main__":
    main()
