"""Print a definition x use table of one shape's verdicts (O OK, T TYPEERR, W WRONG,
D DIAG, I ICE, C CRASH, s TSERR) for one or more results files, as Markdown.

Usage: python3 -I table.py SHAPE cases.json RESULTS.json[=label]...
"""
import json
import sys

LETTER = {"OK": "O", "TYPEERR": "T", "WRONG": "W", "DIAG": "D", "ICE": "I", "CRASH": "C", "TSERR": "s", "NODEERR": "n"}
shape, meta = sys.argv[1], json.load(open(sys.argv[2]))
runs = []
for arg in sys.argv[3:]:
    path, _, label = arg.partition("=")
    runs.append((label or path, json.load(open(path))))
uses = ["direct", "explicit", "param", "var", "field", "iface_sig", "through_decl", "through_value", "map_ctx", "bind"]
defs = sorted({m["definition"] for m in meta.values() if m["shape"] == shape})
print("| definition | " + " | ".join(uses) + " |")
print("|---|" + "---|" * len(uses))
for d in defs:
    cells = []
    for u in uses:
        name = f"{shape}__{d}__{u}"
        cells.append("/".join(LETTER[r[name]["verdict"]] if name in r else "-" for _, r in runs))
    print(f"| {d} | " + " | ".join(cells) + " |")
print("\nCells: " + "/".join(label for label, _ in runs))
