"""Cost probes for H09: instructions per typed call of a generic factory, directly
(monomorphized), through a value of a generic function type that finds its instance
(pts_instance_find with one entry, or with many entries before the one it finds), and
through an erased copy (shape result, which converts by a checked copy).

Usage: python3 -I gen.py OUTDIR   (writes <case>_<n>.pts for n in 1e6 and 2e6)
"""
import os
import sys

HEAD = """class Box<T> {
  constructor(public value: T) {}
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function shape<T>(x: T): { value: T } {
  return { value: x };
}
"""
LOOP_VALUE = """function viaValue(f: <T>(x: T) => Box<T>, n: number): number {
  let s = 0;
  for (let i = 0; i < n; i++) {
    const b: Box<number> = f(i);
    s += b.value;
  }
  return s;
}
"""
LOOP_SHAPE = """function viaShape(f: <T>(x: T) => { value: T }, n: number): number {
  let s = 0;
  for (let i = 0; i < n; i++) {
    const b: { value: number } = f(i);
    s += b.value;
  }
  return s;
}
"""
# Demands for other type arguments, made before the number one, so make's descriptor lists
# their instances first.
MANY = "".join(f"""function other{i}(f: <T>(x: T) => Box<T>): void {{
  const b: Box<{t}> = f({v});
  if (b.value === undefined) console.log("never");
}}
""" for i, (t, v) in enumerate([("string", '"s"'), ("boolean", "true"), ("number[]", "[1]"), ("string[]", '["s"]'),
                                  ("Box<number>", "new Box(1)"), ("Box<string>", 'new Box("s")'), ("boolean[]", "[true]"),
                                  ("number[][]", "[[1]]"), ("Map<string, number>", "new Map<string, number>()"),
                                  ("Set<number>", "new Set<number>()"), ("[number, string]", '[1, "s"] as [number, string]'),
                                  ("Box<boolean>", "new Box(true)"), ("string[][]", '[["s"]]'), ("Box<number[]>", "new Box([1])"),
                                  ("Set<string>", "new Set<string>()")]))
MANY_CALLS = "".join(f"other{i}(make);\n" for i in range(15))

CASES = {
    "c1_direct": HEAD + "let s = 0;\nfor (let i = 0; i < N; i++) {\n  const b: Box<number> = make(i);\n  s += b.value;\n}\nconsole.log(s);\n",
    "c2_value_instance": HEAD + LOOP_VALUE + "console.log(viaValue(make, N));\n",
    "c3_value_instance_16": HEAD + MANY + LOOP_VALUE + MANY_CALLS + "console.log(viaValue(make, N));\n",
    "c4_shape_erased": HEAD + LOOP_SHAPE + "console.log(viaShape(<T>(x: T): { value: T } => ({ value: x }), N));\n",
    "c5_shape_instance": HEAD + LOOP_SHAPE + "console.log(viaShape(shape, N));\n",
}


def main():
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    for name, src in CASES.items():
        for n in (1000000, 2000000):
            with open(os.path.join(out, f"{name}_{n}.pts"), "w") as f:
                f.write(f"const N = {n};\n" + src)


if __name__ == "__main__":
    main()
