#!/bin/bash
# run.sh: build each cost case with the base CLI and count its instructions under callgrind
# (PTS_THREADS=1, the collector's instructions included); prints "case instructions".
set -uo pipefail
home=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a1febe54d0bef208f
cli=${PTS_CLI:-$home/pts-bin/pts}
out=/tmp/h09/repro/cost/bin; mkdir -p "$out"
for f in /tmp/h09/repro/cost/cases/*.pts; do
  b=$(basename "$f" .pts)
  PTS_HOME=$home "$cli" build "$f" -o "$out/$b" > "$out/$b.build.txt" 2>&1 || { echo "$b BUILD-FAILED"; continue; }
  PTS_THREADS=1 valgrind --tool=callgrind --callgrind-out-file="$out/$b.callgrind" "$out/$b" > "$out/$b.stdout" 2> "$out/$b.valgrind.txt"
  echo "$b $(grep -o 'Collected : [0-9]*' "$out/$b.valgrind.txt" | grep -o '[0-9]*') $(cat "$out/$b.stdout")"
done
