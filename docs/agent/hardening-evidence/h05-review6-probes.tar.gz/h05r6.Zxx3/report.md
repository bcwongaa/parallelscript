NOT READY

Scratch: /tmp/h05r6.Zxx3. Final CLI run with PTS_HOME=/tmp/h05r6.Zxx3/home: lib and runtime copied from /tmp/h05-close, third_party copied from review-home5. `diff -rq` showed both identical to the repo's. I built it because /tmp/h05-close lacked its submodules when I started. No result below comes from the broken home.
Compare helper: /tmp/h05r6.Zxx3/bin/cmp.sh <dir> runs each .pts in <dir> on final, R5 and base, and on Node from a .mts copy, one compile at a time. Outputs go to <dir>/out/.

1. MEDIUM-LOW, VERIFIED. F3's fix covers returned values only. A single-use const used as an element of a returned array literal is still copied at each call, so identity is lost silently.
   p1/a1_single_use_const_elem.pts:
     const out = [1];
     const r = [1, 2].flatMap<(number | string)[]>(() => [out]);
     console.log(r.length, r[0] === r[1]);
     r[0].push(9);
     console.log(JSON.stringify(r));
   final, R5 and base: `2 false` / `[[1,9],[1]]`. Node: `2 true` / `[[1,9],[1,9]]`.
   Same result:
   - a3 (`[out.sort()]`)
   - a4 (`[[out]]` into `flatMap<(number|string)[][]>`)
   - p5/n6 (`[[i, ws]]` into `[number, (string|number)[]]`: final `false`, Node `true`)
   Regression vs R5: a2 (`(i) => [i > 0 ? out : [i]]`) was PTS1001 on R5. Final prints `2 false`, Node `2 true`; base is the same as final.
   Cause: arrays.go:659 `l.keepsLeaf(t, elem, l.isNewArray(element), element)`. isNewArray calls isSingleUseConst (:1142), which counts uses in the source, not calls. makesNewArrays (:681) excludes consts for a returned value, but keepsElement doesn't. This contradicts D-180's own rule ("a const's arrays, even one used once, are the same at each call").
   The regular D-094 analog in a loop (a6) loses identity on every tree, so that part is shared and pre-existing.
   A const declared inside the callback (w1, `const a = [i]; return [a];`) is genuinely new and must stay accepted.

2. LOW-MEDIUM, VERIFIED. A spread inside a nested tuple literal shifts the field check: target(i) uses the literal's index, not the tuple's position (arrays.go:648-653, with the spread skipped at :639).
   - False negative, p2/c1_spread_shift_tuple.pts:
       interface J { x: number | string }
       class C { constructor(public x: number) {} }
       const c = new C(1);
       const p: [number, number] = [1, 2];
       const r = [1].flatMap<[number, number, J]>(() => [[...p, c]]);
       c.x = 5;
       console.log(r.length, r[0][2].x);
     final: `1 1`, R5: `1 1`, base: TypeError, Node: `1 5`. The regular analog p2/c1b_regular (`const r: [number, number, J][] = [[...p, c]]`) is PTS1001 on every tree.
   - False positive, regression vs R5: p3/c12_spread_shift_fp.pts uses `const q: [J, J]` and `flatMap<[J, J, C]>(() => [[...q, c]])`. c is checked against J.
     final: `5:48 PTS1001 using a C as a {x: number | string}…`, R5: `1 5` (= Node), base: TypeError.

3. LOW, VERIFIED, regression vs R5 and base (a compile error, never wrong code). makesNewArrays accepts only `xs.map(cb)` whose cb returns bare array literals. These new-at-each-call returns are now PTS1001 "using a number[] as a (number | string)[] where it may be changed or kept…", where R5 and base printed Node's output:
   - p1/b1 `ns.map((m) => (m > 1 ? [m] : []))`
   - b2 `ns.map((m) => [m] as number[])`
   - b3 `ns.map((m) => [m]).reverse()`
   - b4 `Array.from({ length: 2 }, (_, i) => [i])`
   - b5 `ns.map((m) => m.slice())`
   - b6, a const declared inside the callback:
       const r = [1, 2].flatMap<(number | string)[]>((i) => {
         const a = [[i], [i + 1]];
         return a;
       });
     Node, R5 and base print `[[1],[2],[2],[3]]`.
   Round 5 suggested counting consts declared inside the callback as new. The single-call `[1].flatMap(() => out)` in round 4's H1/p05 is also PTS1001 now; D-180 does that on purpose.

4. LOW, VERIFIED, pre-existing on R5. `as const` and `satisfies` around a nested tuple literal skip F4's field check: the node isn't an ArrayLiteral, so it reaches `case made: return true` (arrays.go:756) for tuple to tuple.
   p5/n1_as_const_tuple_elem.pts: `[1].flatMap<readonly [J, number]>(() => [[c, 1] as const])`, then `c.x = 5`.
   final and R5: `1 1`, base: TypeError, Node: `1 5`. The regular analog n1b is PTS1001. p6/o4 does the same with `satisfies [C, number]`.
   Copies of map-made tuples (p6/o2 and o2b) are silent on every tree; D-180 already lists that gap.

5. LOW, VERIFIED, pre-existing on every tree. A nested literal shorter than an optional tuple fails at run time.
   p7/v2_short_optional_tuple.pts: `[1, 2].flatMap<[number, string?]>((i) => [[i], [i, "s"]])`.
   final, R5 and base: `TypeError: Expected [number, string | undefined], got Array`. Node: `[[1],[1,"s"],[2],[2,"s"]]`. The regular p8/w2 works. Memory-safe. It isn't in D-180's known gaps.

6. Nits, VERIFIED.
   - D-180's known gap "a nested array literal where a union with two array members goes isn't checked" also covers two tuple members. p2/c5 (`flatMap<[J, number] | [string, number]>(() => [[c, 1]])`) prints `1 1` on final and R5, Node `1 5`.
   - For a tuple leaf that isn't made (F5's `pairs`), the message is reportKeptCopy's. It says "a new array … is copied", but even new tuples are rejected.

Round 5 status
- F1 fixed. The F1 repro and it/i01, i06, i07 and i09 line 4 equal Node; so do p3/i3 (a kept array of results) and i5 (a getter object).
  Unions of results with other members (`| undefined` in p3/i1, `| number` in i6) are still PTS1001, as the regular conversion is (i1b).
- F2 fixed. The F2 repro and fp2/u01, u02 and fp3/v01, v02, v06, v07 equal Node.
- F3 partly fixed. The returned-value forms are PTS1001 now: the F3 repro, mk/m02–m05, g/g08, p1/b7 (Object.values) and p4/k8 (readonly target); R5 lost identity on all of them. Literal elements are not fixed (finding 1).
- F4 partly fixed. Plain nested tuple literals are checked: the F4 repro, nl/n02, n09, n10, p2/c6, c9 and p5/n4. Spreads (finding 2), `as const` and `satisfies` (finding 4), and two tuple members (finding 6) slip past.
- F5 fixed, as PTS1001 (a documented gap). The F5 repro, tu/t01, t02 and cm/t1_tuple_leaves give it.

Checked and fine
- Round 3's 301-probe corpus (bin/r3all.sh): only cm/t1_tuple_leaves differs from R5 (F5, now PTS1001 as on R4).
- Round 5's 116 probes (bin/rerun.sh, logs r5p-a.log and r5p-b.log): 22 changed. All are the fixes above; g05's error moved to the branch.
- Round 4's 79 probes (r4.log): only H1/p05 line 5 (by design), g05 (position) and g08 (now PTS1001) differ from R5.
- No segfault, PTS9001 or panic in any final output.
- `.par.flatMap` (par/q1.pts) at PTS_THREADS=1, 2 and 4 equals Node's sequential run, including identity for kept arrays, objects and iterator results. q2 is C73's documented PTS1001.
- Valid nested tuples with function, enum, subclass, null-union and kept same-type array fields: p5/n2, n3, n5 and p2/c7.
- Also fine: interface unions (j1), let, closure and method returns (j5, j6), block-bodied map (b8), an inner const element (w1), any[] and unknown[] targets (k1–k3, k7, now PTS1001 where R5 threw or lost identity).
- lower.go's change is message-identical.
- Tests: flatmap_leaf_identity's expect equals Node's output and final's. flatmap_leaf_conversions' expected 12 errors equal final's output, in order. They pin F1, F2, F3 (returned const only), F4 (plain literal) and F5.
  They don't pin F3's `hs.map((h) => h.arr)` (a mapper that isn't a literal), and nothing covers findings 1 and 2.
