console.log([1, 2, 3].flatMap((x) => (x === 1 ? x : [[x]])));
console.log([1, 2].flatMap((x) => (x === 1 ? x : [[x]])));
console.log([0, 1].flatMap((x) => { const r = new Array(2); r[1] = "v" + x; return r; }));
