#!/usr/bin/env python3
"""combine.py OUT.tsv IN.tsv...: one row per case, later files overriding earlier ones (reruns)."""
import csv, sys

rows, header = {}, None
for path in sys.argv[2:]:
    with open(path) as f:
        reader = csv.DictReader(f, delimiter="\t")
        header = header or reader.fieldnames
        for r in reader:
            rows[r["case"]] = r
with open(sys.argv[1], "w") as f:
    w = csv.DictWriter(f, header, delimiter="\t")
    w.writeheader()
    for r in rows.values():
        w.writerow(r)
print(len(rows), "rows")
