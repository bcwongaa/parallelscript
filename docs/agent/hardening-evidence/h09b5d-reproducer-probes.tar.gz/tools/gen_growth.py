#!/usr/bin/env python3
"""H09b5d growth family (m15): many demand types that share one IR type, paired with M generic
values, so the parent can compare a fix's code size and build cost with HEAD's.

  gen_growth.py OUTDIR

  promise_N_M  M async generic values (Promise<Box<Awaited<T>>>, a dynamic result) called through
               one generic function type for Promise<1> ... Promise<N> (IR value each): HEAD
               keeps at most maxDynamicVariants (4) instances per value; calls past them throw.
  twin_N_M     M generic values with a typed result Out<T> (one IR type for every twin) called
               for { kind: "k1" } ... { kind: "kN" }: HEAD lists one instance per value.
  literal_N_M  M generic values returning Box<T> called for the literal types 1 ... N: HEAD makes
               an instance per literal (D-089), the cost a checker-structure key would have for
               the families above.
The output is a checksum per value (a call that throws adds 1000).
"""
import os, sys

OUT = sys.argv[1]
os.makedirs(OUT, exist_ok=True)
BOX = "class Box<T> {\n  constructor(public value: T) {}\n}\n"


def promise(n, m):
    s = f"// H09b5d growth: {m} async generic values x Promise<1> ... Promise<{n}>.\n" + BOX
    for j in range(m):
        s += f"async function v{j}<T>(x: T): Promise<Box<Awaited<T>>> {{\n  return new Box(await x);\n}}\n"
    s += "async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<number> {\n  let s = 0;\n"
    for i in range(1, n + 1):
        s += f"  try {{ s += (await f(Promise.resolve({i} as const))).value; }} catch {{ s += 1000; }}\n"
    s += "  return s;\n}\nasync function main(): Promise<void> {\n"
    for j in range(m):
        s += f"  console.log({j}, await use(v{j}));\n"
    s += "}\nmain();\n"
    return s


def twin(n, m):
    s = f"// H09b5d growth: {m} generic values x the twins {{ kind: \"k1\" }} ... {{ kind: \"k{n}\" }}.\n"
    s += "class Out<T> {\n  constructor(public x: T, public n: number) {}\n}\n"
    for j in range(m):
        s += f"function v{j}<T extends {{ kind: string }}>(x: T): Out<T> {{\n  return new Out(x, x.kind.length + {j});\n}}\n"
    s += "function use(f: <T extends { kind: string }>(x: T) => Out<T>): number {\n  let s = 0;\n"
    for i in range(1, n + 1):
        s += f"  s += f({{ kind: \"k{i}\" as const }}).n;\n"
    s += "  return s;\n}\n"
    for j in range(m):
        s += f"console.log({j}, use(v{j}));\n"
    return s


def literal(n, m):
    s = f"// H09b5d growth: {m} generic values x the literal types 1 ... {n} (D-089: an instance each).\n" + BOX
    for j in range(m):
        s += f"function v{j}<T>(x: T): Box<T> {{\n  return new Box(x);\n}}\n"
    s += "function use(f: <T>(x: T) => Box<T>): number {\n  let s = 0;\n"
    for i in range(1, n + 1):
        s += f"  s += f({i} as const).value;\n"
    s += "  return s;\n}\n"
    for j in range(m):
        s += f"console.log({j}, use(v{j}));\n"
    return s


def direct_twin(n, m):
    s = f"// H09b5d growth: {m} generic functions called directly for the twins {{ kind: \"k1\" }} ... {{ kind: \"k{n}\" }}.\n"
    s += "class Out<T> {\n  constructor(public x: T, public n: number) {}\n}\n"
    for j in range(m):
        s += f"function v{j}<T extends {{ kind: string }}>(x: T): Out<T> {{\n  return new Out(x, x.kind.length + {j});\n}}\n"
    s += "let s = 0;\n"
    for j in range(m):
        for i in range(1, n + 1):
            s += f"s += v{j}({{ kind: \"k{i}\" as const }}).n;\n"
    s += "console.log(s);\n"
    return s


def direct_literal(n, m):
    s = f"// H09b5d growth: {m} generic functions called directly for the literal types 1 ... {n} (D-089: an instance each).\n" + BOX
    for j in range(m):
        s += f"function v{j}<T>(x: T): Box<T> {{\n  return new Box(x);\n}}\n"
    s += "let s = 0;\n"
    for j in range(m):
        for i in range(1, n + 1):
            s += f"s += v{j}({i} as const).value;\n"
    s += "console.log(s);\n"
    return s


def direct_promise(n, m):
    s = f"// H09b5d growth: {m} async generic functions called directly for Promise<1> ... Promise<{n}>.\n" + BOX
    for j in range(m):
        s += f"async function v{j}<T>(x: T): Promise<Box<Awaited<T>>> {{\n  return new Box(await x);\n}}\n"
    s += "async function main(): Promise<void> {\n  let s = 0;\n"
    for j in range(m):
        for i in range(1, n + 1):
            s += f"  s += (await v{j}(Promise.resolve({i} as const))).value;\n"
    s += "  console.log(s);\n}\nmain();\n"
    return s


count = 0
for n, m in ((10, 1), (30, 1), (10, 10), (30, 10)):
    for name, gen in (("promise", promise), ("twin", twin), ("literal", literal), ("dtwin", direct_twin), ("dliteral", direct_literal), ("dpromise", direct_promise)):
        open(os.path.join(OUT, f"{name}_{n}_{m}.pts"), "w").write(gen(n, m))
        count += 1
print(count, "growth cases")
