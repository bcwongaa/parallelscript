#!/usr/bin/env python3
"""Writes the prototypes' `go build -overlay` JSON files (PTS-PROTO, never applied to the tree).

  pa_fn.json   A for functions: genericInstanceFor keyed by the type arguments' bounded checker
               structure (keyPart) with brands kept; no maxDynamicVariants.
  pa_val.json  pa_fn + every demand's entries keyed by its checker types (instanceKey).
  pa_cls.json  pa_val + generic class instances told apart by their members' IR types.
  pb.json      B: functions keyed by IR arguments plus the deep IR identity of the instantiated
               signature (brands kept, no cap) + pa_cls's class split; demands as HEAD.
"""
import json, os

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e/pts/lower/"
P = "/tmp/h09b5d/reproducer/proto/"
sets = {
    "pa_fn": {"generics.go": P + "pa/generics.go"},
    "pa_val": {"generics.go": P + "pa/generics.go", "instances.go": P + "pa/instances.go", "forwarding.go": P + "pa/forwarding.go"},
    "pa_cls": {"generics.go": P + "pa/generics.go", "instances.go": P + "pa/instances.go", "forwarding.go": P + "pa/forwarding.go", "generic_classes.go": P + "pa/generic_classes.go"},
    "pb": {"generics.go": P + "pb/generics.go", "generic_classes.go": P + "pb/generic_classes.go"},
}
for name, files in sets.items():
    missing = [f for f in files.values() if not os.path.exists(f)]
    if missing:
        print("skip", name, "missing", missing)
        continue
    with open(P + name + ".json", "w") as f:
        json.dump({"Replace": {WT + k: v for k, v in files.items()}}, f, indent=1)
    print("wrote", P + name + ".json")
