#!/bin/bash
# run_all.sh LABEL PTS PTS_HOME JOBS: the matrices and probe families (no growth) with one CLI.
R=/tmp/h09b5d/reproducer
label=$1
export PTS=$2 PTS_HOME=$3
python3 -I $R/tools/run_matrix.py --jobs "$4" --out $R/matrix/results_${label}_all.tsv \
  $R/matrix/cases/m5_variants $R/matrix/cases/m7_ir $R/matrix/cases/m9_forms $R/matrix/cases/m10_body \
  $R/probes/cls $R/probes/brand $R/probes/dyn $R/probes/nest $R/probes/narrow $R/probes/lit $R/probes/poly \
  > $R/logs/${label}_all.log 2>&1
tail -1 $R/logs/${label}_all.log
