#!/usr/bin/env python3
"""emitc_compare.py LABEL...: totals of matrix/emitc_<label>.tsv against the first label's, over
the programs every label emitted, and the programs whose C changed most; also emit-c failures
that differ."""
import sys

R = "/tmp/h09b5d/reproducer/matrix/"
labels = sys.argv[1:]
data = {l: dict(line.rstrip("\n").split("\t") for line in open(R + f"emitc_{l}.tsv")) for l in labels}
base = labels[0]
common = [p for p in data[base] if all(data[l].get(p, "").isdigit() for l in labels)]
for l in labels:
    total = sum(int(data[l][p]) for p in common)
    changed = [p for p in common if data[l][p] != data[base][p]]
    print(f"{l:8s} programs {len(common)} total lines {total} changed programs {len(changed)}")
for l in labels[1:]:
    diffs = sorted(((int(data[l][p]) - int(data[base][p]), p) for p in common if data[l][p] != data[base][p]), reverse=True)
    print(f"\n{l} vs {base}: largest growth")
    for d, p in diffs[:12]:
        print(f"  {d:+7d}  {data[base][p]:>6s} -> {data[l][p]:>6s}  {p}")
    if diffs and diffs[-1][0] < 0:
        print("  smallest:")
        for d, p in diffs[-5:]:
            print(f"  {d:+7d}  {data[base][p]:>6s} -> {data[l][p]:>6s}  {p}")
    failed = [(p, data[base].get(p), data[l].get(p)) for p in data[base] if not (data[base].get(p, "").isdigit() and data[l].get(p, "").isdigit()) and data[base].get(p) != data[l].get(p)]
    for p, a, b in failed:
        print("  emit-c differs:", p, a, "->", b)
