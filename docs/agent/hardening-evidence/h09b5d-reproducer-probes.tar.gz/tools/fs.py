#!/usr/bin/env python3
"""Small file operations for the reproducer's scratch dirs (the sandbox refuses shell globs).

  fs.py copy SRC_DIR DST_DIR PATTERN    copy files matching a glob pattern (fnmatch)
  fs.py rm DIR PATTERN                  delete files matching a pattern in DIR
  fs.py rmtree DIR                      delete a directory under /tmp/h09b5d/reproducer
  fs.py unskip SRC.pts DST.pts          copy a test without its first `// skip:` line
"""
import fnmatch, os, shutil, sys

ROOT = "/tmp/h09b5d/reproducer"
cmd = sys.argv[1]
if cmd == "copy":
    src, dst, pat = sys.argv[2:5]
    os.makedirs(dst, exist_ok=True)
    n = 0
    for f in sorted(os.listdir(src)):
        if fnmatch.fnmatch(f, pat):
            shutil.copy(os.path.join(src, f), os.path.join(dst, f))
            n += 1
    print("copied", n)
elif cmd == "rm":
    d, pat = sys.argv[2:4]
    n = 0
    for f in sorted(os.listdir(d)):
        if fnmatch.fnmatch(f, pat):
            os.remove(os.path.join(d, f))
            n += 1
    print("removed", n)
elif cmd == "rmtree":
    d = os.path.abspath(sys.argv[2])
    assert d.startswith(ROOT + "/"), d
    shutil.rmtree(d)
    print("removed", d)
elif cmd == "unskip":
    src, dst = sys.argv[2:4]
    lines = open(src).read().split("\n")
    if lines and lines[0].startswith("// skip:"):
        lines = lines[1:]
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    open(dst, "w").write("\n".join(lines))
    print("wrote", dst)
else:
    sys.exit("unknown command " + cmd)
