#!/usr/bin/env python3
"""Second batch of H09b5d probes: rewritten guards (cls/g3b, brand/g3b, dyn/g10b) and direct
calls with dynamic results (dyn/r15-r18), polymorphic recursion through one IR type (poly/)."""
import os

ROOT = "/tmp/h09b5d/reproducer/probes"
BOX = """class Box<T> {
  constructor(public value: T) {}
}
"""
UNWRAP = """async function unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
  return new Box(await x);
}
"""
FILES = {}
FILES["cls/g3b_instanceof"] = """// H09b5d guard (classes): instanceof across Box<1>, Box<number>, Box<"a">, Box<string>, and
// typed reads after it.
""" + BOX + """const xs: unknown[] = [new Box(1 as const), new Box(2), new Box("a" as const), new Box("b"), { value: 1 }];
for (const x of xs) {
  console.log(x instanceof Box);
}
function isOne(b: Box<number> | Box<string>): boolean {
  return b instanceof Box && b.value === 1;
}
console.log(isOne(new Box(1 as const)), isOne(new Box("x" as const)));
const nb: Box<number> = new Box(1 as const);
console.log(nb instanceof Box, nb.value + 1);
"""
FILES["brand/g3b_branded_string_union"] = """// H09b5d guard (brands): a branded string union (`("up" | "down") & { __brand }`) as a type
// argument, beside a plain string literal.
""" + BOX + """type Dir = ("up" | "down") & { readonly __brand: "dir" };
function flip<T extends string>(x: T): Box<T> {
  return new Box(x);
}
const d = "up" as Dir;
console.log(flip(d).value, flip("left").value);
const ds: Dir[] = ["up" as Dir, "down" as Dir];
console.log(ds.map((x) => flip(x).value.toUpperCase()).join(","));
const boxed: Box<string> = flip(d);
console.log(boxed.value.length);
"""
FILES["dyn/g10b_any_unknown_within_cap"] = """// H09b5d guard (dynamic results): any and unknown type arguments keep instances of their own
// (Box<any> holds a string) beside Promise<number> and Promise<1>: four variants, within the cap.
""" + BOX + UNWRAP + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
  const show = (label: string, v: unknown): void => console.log(label, typeof v, String(v));
  try { show("number", (await f(Promise.resolve(1))).value); } catch (e: any) { console.log("number threw", e.message); }
  try { show("any", (await f<any>("s")).value); } catch (e: any) { console.log("any threw", e.message); }
  try { show("unknown", (await f<unknown>(true)).value); } catch (e: any) { console.log("unknown threw", e.message); }
  try { show("1", (await f(Promise.resolve(1 as const))).value); } catch (e: any) { console.log("1 threw", e.message); }
}
use(unwrap);
"""
FILES["dyn/r15_direct_promise_number_string"] = """// H09b5d RED? (C177, direct calls with a dynamic result): unwrap(Promise<number>) then
// unwrap(Promise<string>): one IR type argument (value); a direct call isn't `dynamic`, so it
// shares the first instance, whose Box<number> takes the string.
""" + BOX + UNWRAP + """async function main(): Promise<void> {
  try { console.log("number", (await unwrap(Promise.resolve(1))).value + 1); } catch (e: any) { console.log("number threw", e.message); }
  try { console.log("string", (await unwrap(Promise.resolve("s"))).value + "!"); } catch (e: any) { console.log("string threw", e.message); }
}
main();
"""
FILES["dyn/r16_direct_unknown_after_promise"] = """// H09b5d RED? (C177, direct calls with a dynamic result): unwrap<unknown>(true) after
// unwrap(Promise<number>).
""" + BOX + UNWRAP + """async function main(): Promise<void> {
  const show = (label: string, v: unknown): void => console.log(label, typeof v, String(v));
  try { show("number", (await unwrap(Promise.resolve(1))).value); } catch (e: any) { console.log("number threw", e.message); }
  try { show("unknown", (await unwrap<unknown>(true)).value); } catch (e: any) { console.log("unknown threw", e.message); }
}
main();
"""
FILES["dyn/r17_direct_method_promise_number_string"] = """// H09b5d RED? (C177, a class's generic async method called directly): Promise<number> then
// Promise<string>.
""" + BOX + """class Unwrapper {
  async unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
    return new Box(await x);
  }
}
const u = new Unwrapper();
async function main(): Promise<void> {
  try { console.log("number", (await u.unwrap(Promise.resolve(1))).value + 1); } catch (e: any) { console.log("number threw", e.message); }
  try { console.log("string", (await u.unwrap(Promise.resolve("s"))).value + "!"); } catch (e: any) { console.log("string threw", e.message); }
}
main();
"""
FILES["dyn/r18_direct_generator_twins"] = """// H09b5d RED? (C177, a generator called directly, twins): gen<{ kind: "a" }> then
// gen<{ kind: "b" }> whose yielded Box<K<T>> differs.
""" + BOX + """type K<T> = T extends { kind: "a" } ? number : string;
function* gen<T>(x: T, v: K<T>): Generator<Box<K<T>>> {
  yield new Box(v);
}
for (const b of gen<{ kind: "a" }>({ kind: "a" }, 3)) {
  console.log("a", b.value + 1);
}
try {
  for (const b of gen<{ kind: "b" }>({ kind: "b" }, "s")) {
    console.log("b", b.value + "!");
  }
} catch (e: any) {
  console.log("b threw", e.message);
}
"""
FILES["dyn/r19_value_promise_number_string_dynamic"] = """// H09b5d RED? (dynamic results through a value): Promise<number> and Promise<string>: told
// apart by madeFor (D-190), within the cap: guard.
""" + BOX + UNWRAP + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
  try { console.log("number", (await f(Promise.resolve(1))).value + 1); } catch (e: any) { console.log("number threw", e.message); }
  try { console.log("string", (await f(Promise.resolve("s"))).value + "!"); } catch (e: any) { console.log("string threw", e.message); }
}
use(unwrap);
"""
FILES["poly/g1_promise_recursion"] = """// H09b5d guard (growth risk): polymorphic recursion through one IR type: nest<T> calls
// nest<Promise<T>> (value at every level); HEAD makes one instance. Keyed by checker structure it
// makes one per level up to keyPart's depth.
""" + BOX + """async function nest<T>(x: T, n: number): Promise<Box<Awaited<T>>> {
  if (n === 0) {
    return new Box(await x);
  }
  const inner = await nest<Promise<T>>(Promise.resolve(x), n - 1);
  return new Box(inner.value);
}
async function main(): Promise<void> {
  console.log((await nest(Promise.resolve(5), 20)).value + 1);
  console.log((await nest(Promise.resolve("s"), 3)).value + "!");
}
main();
"""
FILES["poly/g2_twin_recursion"] = """// H09b5d guard (growth risk): polymorphic recursion through twins of one IR shape: step<T>
// calls step<{ kind: "x"; n: number }> ... with a new literal each level only in tsc's types.
""" + BOX + """type Tag<T> = T extends { kind: infer K } ? K : never;
function step<T extends { kind: string; n: number }>(x: T, n: number): Box<number> {
  if (n === 0) {
    return new Box(x.n);
  }
  const next: { kind: `${Tag<T>}x`; n: number } = { kind: `${x.kind}x` as `${Tag<T>}x`, n: x.n + 1 };
  return step(next, n - 1);
}
console.log(step({ kind: "a" as const, n: 0 }, 10).value);
"""
for rel, text in FILES.items():
    path = os.path.join(ROOT, rel + ".pts")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)
print(len(FILES), "probes")
