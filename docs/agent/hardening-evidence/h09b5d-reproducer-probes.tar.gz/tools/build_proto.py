#!/usr/bin/env python3
"""build_proto.py NAME: builds the pts CLI of the worktree with proto/NAME.json as a go
-overlay into proto/pts-NAME (GOMAXPROCS=2); also vets that the lowerer compiles."""
import os, subprocess, sys

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
P = "/tmp/h09b5d/reproducer/proto/"
name = sys.argv[1]
env = dict(os.environ, GOMAXPROCS="2")
env["PATH"] = os.path.expanduser("~/.local/go/bin") + ":" + env["PATH"]
p = subprocess.run(["go", "build", "-overlay=" + P + name + ".json", "-o", P + "pts-" + name, "./cmd/pts"], cwd=WT, env=env, capture_output=True, text=True)
print(p.stdout + p.stderr)
print("exit", p.returncode)
