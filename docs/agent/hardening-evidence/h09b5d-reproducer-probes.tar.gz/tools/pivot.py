#!/usr/bin/env python3
"""pivot.py RESULTS.tsv [FAMILY_PREFIX]: tables a matrix's results by <shape>__<pair> rows and
<form>[/variant] columns (case names <shape>__<pair>__<form>[__variant]); prints the TSERR and
the distinct first differences too."""
import csv, sys, collections

rows = list(csv.DictReader(open(sys.argv[1]), delimiter="\t"))
table = collections.OrderedDict()
cols = []
for r in rows:
    parts = r["case"].split("__")
    if len(parts) < 3:
        continue
    key = parts[0] + "__" + parts[1]
    col = parts[2] + ("/" + parts[3] if len(parts) > 3 else "")
    if col not in cols:
        cols.append(col)
    table.setdefault(key, {})[col] = r["class"]
short = {"OK": "OK", "TYPEERR": "TYPE", "PTS1001": "1001", "PTS9001": "9001", "WRONG": "WRNG", "TSERR": "TSER", "CRASH": "CRSH", "BUILDFAIL": "BFAIL"}
cols.sort(key=lambda c: (c.split("/")[0], c))
w = max(len(k) for k in table) + 1
print("pair".ljust(w) + " ".join(c[:14].ljust(14) for c in cols))
for key, v in table.items():
    print(key.ljust(w) + " ".join(short.get(v.get(c, "-"), v.get(c, "-")).ljust(14) for c in cols))
print()
counts = collections.Counter(r["class"] for r in rows)
print("TOTAL", len(rows), dict(counts))
print()
seen = collections.Counter()
for r in rows:
    if r["class"] != "OK":
        msg = r["first_difference"]
        msg = msg.split(":", 1)[1].strip() if r["class"] in ("TYPEERR", "WRONG") and ":" in msg else msg
        seen[(r["class"], msg[:150])] += 1
for (cls, msg), n in seen.most_common():
    print(f"{n:4d} {cls:8s} {msg}")
