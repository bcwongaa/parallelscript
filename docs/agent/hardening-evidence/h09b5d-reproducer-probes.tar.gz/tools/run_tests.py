#!/usr/bin/env python3
"""run_tests.py NAMES.txt LOG [OVERLAY.json]: runs TestRun and TestRunMatchesNode for the named
run tests in the reproducer's worktree (PTS_REQUIRE_NODE=1, -parallel 2), optionally against a
`go build -overlay` prototype, writes the go test -v output to LOG, and prints each subtest's
result."""
import os, re, subprocess, sys

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
names = [n.strip() for n in open(sys.argv[1]) if n.strip()]
log = sys.argv[2]
overlay = sys.argv[3] if len(sys.argv) > 3 else ""
pattern = "^(TestRun|TestRunMatchesNode)$/^(" + "|".join(re.escape(n) for n in names) + ")$"
env = dict(os.environ)
env["PATH"] = os.path.expanduser("~/.local/go/bin") + ":" + os.path.expanduser("~/.local/node/bin") + ":" + env["PATH"]
env["PTS_REQUIRE_NODE"] = "1"
env["PTS_HOME"] = WT
env["GOMAXPROCS"] = "2"
cmd = ["go", "test", "-count=1", "-parallel", "2", "-timeout", "40m", "-v", "-run", pattern]
if overlay:
    cmd.append("-overlay=" + overlay)
cmd.append("./pts/tests/")
p = subprocess.run(cmd, cwd=WT, env=env, capture_output=True, text=True)
open(log, "w").write(p.stdout + p.stderr)
results = {}
for line in (p.stdout + p.stderr).splitlines():
    m = re.match(r"\s*--- (PASS|FAIL|SKIP): (TestRun|TestRunMatchesNode)/(\S+)", line)
    if m:
        results.setdefault(m.group(3), {})[m.group(2)] = m.group(1)
for n in names:
    r = results.get(n, {})
    print(f"{n:60s} TestRun={r.get('TestRun', '?'):5s} MatchesNode={r.get('TestRunMatchesNode', '?')}")
print("exit", p.returncode)
