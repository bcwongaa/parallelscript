#!/usr/bin/env python3
"""run_go.py LABEL OVERLAY|- RUN_PATTERN PACKAGE...: go test -json in the reproducer's worktree
(PTS_REQUIRE_NODE=1, -parallel 2, GOMAXPROCS=2, -timeout 60m), optionally with a prototype's
-overlay; writes logs/go_LABEL.jsonl and prints the counts and every failed test (leaf names)."""
import collections, json, os, subprocess, sys

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
R = "/tmp/h09b5d/reproducer"
label, overlay, pattern, packages = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4:]
env = dict(os.environ)
env["PATH"] = os.path.expanduser("~/.local/go/bin") + ":" + os.path.expanduser("~/.local/node/bin") + ":" + env["PATH"]
env.update(PTS_REQUIRE_NODE="1", PTS_HOME=WT, GOMAXPROCS="2")
cmd = ["go", "test", "-count=1", "-json", "-parallel", "2", "-timeout", "60m", "-run", pattern]
if overlay != "-":
    cmd.append("-overlay=" + overlay)
cmd += packages
out = os.path.join(R, "logs", "go_" + label + ".jsonl")
with open(out, "w") as f:
    p = subprocess.run(cmd, cwd=WT, env=env, stdout=f, stderr=subprocess.STDOUT, text=True)
counts = collections.Counter()
failed = []
for line in open(out):
    try:
        e = json.loads(line)
    except ValueError:
        continue
    test = e.get("Test")
    if not test or e.get("Action") not in ("pass", "fail", "skip"):
        continue
    counts[e["Action"]] += 1
    if e["Action"] == "fail":
        failed.append(test)
leaves = [t for t in failed if not any(o != t and o.startswith(t + "/") for o in failed)]
print(label, "exit", p.returncode, dict(counts))
for t in sorted(leaves):
    print("FAIL", t)
