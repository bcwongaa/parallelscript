#!/usr/bin/env python3
"""test_table.py: the RED tests and guards (red/NAMES.txt, the six committed REDs, the split and
side probes) by HEAD, the parent's candidate, prototype A and prototype B (results_*_redrun.tsv)."""
import csv

R = "/tmp/h09b5d/reproducer/matrix/"
labels = ["head", "parent", "pa_cls2", "pb"]
runs = {l: {r["case"]: r for r in csv.DictReader(open(R + f"results_{l}_redrun.tsv"), delimiter="\t")} for l in labels}
names = [n.strip() for n in open("/tmp/h09b5d/reproducer/red/NAMES.txt") if n.strip()]
six = ["generic_instances_same_ir_type_promises", "generic_instances_same_ir_type_twins", "generic_class_instances_literal_type_arguments",
       "generic_instances_branded_type_arguments", "generic_values_same_ir_type_promises", "generic_dynamic_variants_past_cap"]
others = [c for c in runs["head"] if c not in names and c not in six]
short = {"OK": "ok", "TYPEERR": "TYPE", "PTS1001": "1001", "PTS9001": "9001", "WRONG": "WRONG", "TSERR": "TSERR"}
print("test".ljust(56) + "HEAD   parent A      B")
for group, cases in (("committed six (unskipped)", six), ("new tests", names), ("other probes", others)):
    print("--", group)
    for c in cases:
        cells = [short.get(runs[l].get(c, {}).get("class", "-"), "-") for l in labels]
        print(c.ljust(56) + " ".join(x.ljust(6) for x in cells))
