#!/usr/bin/env python3
"""H09b5d probes (split risk): narrowings in a generic body that are dead for a type argument
whose instance HEAD shares with an earlier type argument of the same IR type (unknown or any
first), so HEAD lowers them once, for the earlier one; separate instances lower them for the
later one too. Into probes/split/."""
import os

DIR = "/tmp/h09b5d/reproducer/probes/split"
os.makedirs(DIR, exist_ok=True)
ATTEMPT = """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""
CASES = {
    "isarray_promise": ("Array.isArray(x)", "x.length", "0",
                        [("unknown", "[1, 2] as unknown"), ("Promise<number>", "Promise.resolve(1)")]),
    "isarray_any_then_promise": ("Array.isArray(x)", "x.length", "0",
                                 [("any", "[1, 2, 3] as any"), ("Promise<number>", "Promise.resolve(1)")]),
    "typeof_string_promise": ('typeof x === "string"', "x.length", "-1",
                              [("unknown", '"abc" as unknown'), ("Promise<number>", "Promise.resolve(1)")]),
    "typeof_string_brand": ('typeof x === "string"', "x.length", "-1",
                            [("unknown", '"abcd" as unknown'), ("Id", "5 as Id")]),
    "instanceof_map_promise": ("x instanceof Map", "x.size", "-1",
                               [("unknown", "new Map([[1, 2]]) as unknown"), ("Promise<number>", "Promise.resolve(1)")]),
    "in_twins": ('"extra" in x', "String(x.extra).length", "-1",
                 [("{ kind: string }", '{ kind: "z", extra: 1 } as { kind: string }'), ('{ kind: "a" }', '{ kind: "a" as const }')]),
    "isarray_promise_array": ("Array.isArray(x)", "x.length", "0",
                              [("unknown[]", "[1, 2] as unknown[]"), ("Promise<number>[]", "[Promise.resolve(1)]")]),
}
for name, (test, read, other, calls) in CASES.items():
    s = (f"// H09b5d guard? (split risk): `if ({test}) return {read}` in a generic body, called for {calls[0][0]}\n"
         f"// then {calls[1][0]} (one IR type): HEAD shares the first's instance.\n")
    s += 'type Id = number & { readonly __brand: "id" };\n' + ATTEMPT
    s += f"function probe<T>(x: T): number {{\n  if ({test}) {{\n    return {read};\n  }}\n  return {other};\n}}\n"
    for targ, arg in calls:
        s += f'attempt("{targ.replace(chr(34), chr(39))}:", () => String(probe<{targ}>({arg})));\n'
    open(os.path.join(DIR, name + ".pts"), "w").write(s)
print(len(CASES), "probes")
