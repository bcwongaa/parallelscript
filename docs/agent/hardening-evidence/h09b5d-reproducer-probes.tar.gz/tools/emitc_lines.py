#!/usr/bin/env python3
"""emitc_lines.py LABEL JOBS: `pts emit-c` of every run test and corpus program of the worktree
with one CLI (head, parent, pa_cls2, pb), lines of C per program -> matrix/emitc_LABEL.tsv
(lines, or the exit code when emit-c fails). The C files are deleted at once."""
import concurrent.futures, glob, os, subprocess, sys, tempfile

R = "/tmp/h09b5d/reproducer"
WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
label, jobs = sys.argv[1], int(sys.argv[2])
pts, home = {
    "head": (WT + "/pts-bin/pts", WT),
    "parent": (R + "/proto/pts-parent", "/home/bryan/projects/parallelscript"),
}.get(label, (R + "/proto/pts-" + label, WT))
files = sorted(glob.glob(WT + "/pts/tests/run/*.pts") + glob.glob(WT + "/pts/tests/corpus/*/*.pts"))


def lines(path):
    d = tempfile.mkdtemp(dir=R + "/tmp")
    out = os.path.join(d, "x.c")
    try:
        p = subprocess.run([pts, "emit-c", path, "-o", out], cwd=d, env=dict(os.environ, PTS_HOME=home), capture_output=True, text=True, timeout=300)
        if p.returncode != 0 or not os.path.exists(out):
            return path, "exit%d" % p.returncode
        with open(out) as f:
            return path, str(sum(1 for _ in f))
    except subprocess.TimeoutExpired:
        return path, "timeout"
    finally:
        subprocess.run(["rm", "-rf", d])


with concurrent.futures.ThreadPoolExecutor(jobs) as pool, open(R + f"/matrix/emitc_{label}.tsv", "w") as f:
    for path, n in pool.map(lines, files):
        f.write(os.path.relpath(path, WT) + "\t" + n + "\n")
print(label, "done", len(files))
