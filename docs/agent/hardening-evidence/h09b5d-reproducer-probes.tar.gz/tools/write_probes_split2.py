#!/usr/bin/env python3
"""H09b5d probes: the instanceof-Map internal error's controls, and `in` on twins with an object
constraint. Into probes/split2/."""
import os

DIR = "/tmp/h09b5d/reproducer/probes/split2"
os.makedirs(DIR, exist_ok=True)
ATTEMPT = """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""
PROBE = """function probe<T>(x: T): number {
  if (x instanceof Map) {
    return x.size;
  }
  return -1;
}
"""
F = {}
F["instanceof_map_unknown_alone"] = "// H09b5d side probe: x instanceof Map in a generic body, for unknown alone.\n" + ATTEMPT + PROBE + \
    'attempt("unknown:", () => String(probe<unknown>(new Map([[1, 2]]) as unknown)));\n'
F["instanceof_map_promise_alone"] = "// H09b5d side probe: x instanceof Map in a generic body, for Promise<number> alone.\n" + ATTEMPT + PROBE + \
    'attempt("Promise<number>:", () => String(probe<Promise<number>>(Promise.resolve(1))));\n'
F["instanceof_map_plain_unknown"] = "// H09b5d side probe: x instanceof Map for an unknown x in plain code.\n" + \
    'const x: unknown = new Map([[1, 2]]);\nif (x instanceof Map) {\n  console.log(x.size);\n}\n'
F["in_twins_object"] = """// H09b5d guard? (split risk): `"extra" in x` in a generic body (T extends object), for
// { kind: string } then { kind: "a" } (one IR shape): HEAD shares the first's instance.
""" + ATTEMPT + """function probe<T extends object>(x: T): number {
  if ("extra" in x) {
    return String(x.extra).length;
  }
  return -1;
}
attempt("{ kind: string }:", () => String(probe<{ kind: string }>({ kind: "z", extra: 1 } as { kind: string })));
attempt("{ kind: 'a' }:", () => String(probe<{ kind: "a" }>({ kind: "a" as const })));
"""
for name, text in F.items():
    open(os.path.join(DIR, name + ".pts"), "w").write(text)
print(len(F), "probes")
