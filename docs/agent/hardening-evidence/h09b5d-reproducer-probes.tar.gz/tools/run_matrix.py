#!/usr/bin/env python3
"""Runs every case (*.pts) of the case directories given with Node (the oracle) and with pts,
and writes a results table.

  run_matrix.py [--jobs N] [--loc] [--out results.tsv] DIR...

For each case: Node runs a .mts copy (cached beside the case as .node: stdout, then
"exit=N"); pts builds it (`pts build`, timed with /usr/bin/time: wall s, user s, max RSS KB;
300 s limit), runs the binary (60 s limit) and deletes it at once (the disk filled before).
With --loc it also counts the lines of `pts emit-c`'s C. Classes:
  OK             stdout and exit code as Node's
  TSERR          tsc rejected the case (a generator bug, not a finding)
  PTS1001        a compile error PTS1001 (the first line is kept)
  PTS9001        an internal compiler error
  BUILD-TIMEOUT  the build ran past its limit
  BUILDFAIL      any other build failure
  TYPEERR        ran, and printed or threw a TypeError "Expected …" that Node didn't
  CRASH          ran, and died of a signal or a timeout
  WRONG          ran, with other output or exit code
Environment: PTS (the CLI, default the reproducer's worktree build), PTS_HOME (its runtime),
NODE.
"""
import argparse, concurrent.futures, os, re, shutil, subprocess, sys, tempfile

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
PTS = os.environ.get("PTS", WT + "/pts-bin/pts")
PTS_HOME = os.environ.get("PTS_HOME", WT)
NODE = os.environ.get("NODE", os.path.expanduser("~/.local/node/bin/node"))
SCRATCH = "/tmp/h09b5d/reproducer/tmp"


def run(cmd, cwd, timeout, env=None):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        return p.returncode, p.stdout, p.stderr, False
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        err = e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
        return -1, out, err, True


def node_result(case):
    cache = case[:-4] + ".node"
    if os.path.exists(cache):
        text = open(cache).read()
        out, _, code = text.rpartition("exit=")
        return out, int(code.strip())
    d = tempfile.mkdtemp(dir=SCRATCH)
    try:
        b = os.path.basename(case)[:-4]
        shutil.copy(case, os.path.join(d, b + ".mts"))
        env = dict(os.environ, TZ="America/New_York")
        code, out, err, timed = run([NODE, "--no-warnings", "--experimental-transform-types", b + ".mts"], d, 60, env)
        if timed:
            code = 124
        with open(cache, "w") as f:
            f.write(out + "exit=%d\n" % code)
        return out, code
    finally:
        shutil.rmtree(d, ignore_errors=True)


def pts_result(case, loc):
    d = tempfile.mkdtemp(dir=SCRATCH)
    env = dict(os.environ, PTS_HOME=PTS_HOME, TZ="America/New_York")
    res = {}
    try:
        exe = os.path.join(d, "case.bin")
        timing = os.path.join(d, "time.txt")
        code, out, err, timed = run(["/usr/bin/time", "-o", timing, "-f", "%e %U %M", PTS, "build", case, "-o", exe], d, 300, env)
        res["build_out"] = (out + err).strip()
        if os.path.exists(timing):
            parts = open(timing).read().split()
            if len(parts) >= 3:
                res["wall"], res["user"], res["rss"] = parts[-3], parts[-2], parts[-1]
        if timed:
            res["cls"] = "BUILD-TIMEOUT"
            return res
        if code != 0:
            text = res["build_out"]
            if re.search(r"error TS\d+", text):
                res["cls"] = "TSERR"
            elif "PTS9001" in text:
                res["cls"] = "PTS9001"
            elif "PTS1001" in text:
                res["cls"] = "PTS1001"
            else:
                res["cls"] = "BUILDFAIL"
            return res
        if loc:
            cfile = os.path.join(d, "case.c")
            c2, _, _, _ = run([PTS, "emit-c", case, "-o", cfile], d, 300, env)
            if c2 == 0 and os.path.exists(cfile):
                with open(cfile) as f:
                    res["loc"] = str(sum(1 for _ in f))
                os.remove(cfile)
        code, out, err, timed = run([exe], d, 60, env)
        os.remove(exe)
        res["run_out"], res["run_err"], res["run_code"] = out, err, (124 if timed else code)
        res["timed"] = timed
        return res
    finally:
        shutil.rmtree(d, ignore_errors=True)


def classify(case, loc):
    nout, ncode = node_result(case)
    r = pts_result(case, loc)
    if "cls" not in r:
        out, code = r["run_out"], r["run_code"]
        if out == nout and code == ncode:
            r["cls"] = "OK"
        elif r["timed"] or code < 0 or code >= 128:
            r["cls"] = "CRASH"
        elif re.search(r"TypeError:? .*Expected", out + r["run_err"]) and not re.search(r"Expected", nout):
            r["cls"] = "TYPEERR"
        else:
            r["cls"] = "WRONG"
    first = ""
    if r["cls"] in ("PTS1001", "PTS9001", "BUILDFAIL", "TSERR"):
        lines = [l for l in r["build_out"].splitlines() if "error" in l]
        first = lines[0] if lines else r["build_out"][:200]
        first = first.replace(os.path.dirname(case) + "/", "")
    elif r["cls"] in ("TYPEERR", "WRONG", "CRASH"):
        diff = [l for l in (r["run_out"] + r["run_err"]).splitlines() if l not in nout.splitlines()]
        first = (diff[0] if diff else "exit=%s" % r["run_code"])[:200]
    return os.path.basename(case)[:-4], r["cls"], r.get("loc", ""), r.get("wall", ""), r.get("user", ""), r.get("rss", ""), first


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--loc", action="store_true")
    ap.add_argument("--out", default="results.tsv")
    ap.add_argument("dirs", nargs="+")
    a = ap.parse_args()
    os.makedirs(SCRATCH, exist_ok=True)
    cases = sorted(os.path.join(os.path.abspath(d), f) for d in a.dirs for f in os.listdir(d) if f.endswith(".pts"))
    rows = []
    with concurrent.futures.ThreadPoolExecutor(a.jobs) as pool:
        for row in pool.map(lambda c: classify(c, a.loc), cases):
            rows.append(row)
            print("\t".join(row), flush=True)
    with open(a.out, "w") as f:
        f.write("case\tclass\tloc\tbuild_wall_s\tbuild_user_s\tbuild_maxrss_kb\tfirst_difference\n")
        for row in rows:
            f.write("\t".join(row) + "\n")
    counts = {}
    for row in rows:
        counts[row[1]] = counts.get(row[1], 0) + 1
    print("TOTAL", len(rows), " ".join("%s=%d" % kv for kv in sorted(counts.items())))


if __name__ == "__main__":
    main()
