#!/usr/bin/env python3
"""Writes the H09b5d class probes (finding (b)) into probes/cls/."""
import os

DIR = "/tmp/h09b5d/reproducer/probes/cls"
os.makedirs(DIR, exist_ok=True)

ATTEMPT = """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""
BOX = """class Box<T> {
  constructor(public value: T) {}
}
"""

P = {}
P["g1_tagged_store"] = """// H09b5d guard (classes): a literal type argument whose members' IR types are its base's.
// Tagged<"circle"> (inferred) is stored where Tagged<string> goes, tested with instanceof and
// printed; on HEAD it is Tagged<string>'s class.
class Tagged<K extends string> {
  constructor(public kind: K) {}
  describe(): string {
    return "tag " + this.kind;
  }
}
const all: Tagged<string>[] = [];
all.push(new Tagged("circle"));
all.push(new Tagged("square"));
const t: Tagged<string> = new Tagged("tri");
all.push(t);
for (const x of all) {
  console.log(x.describe(), x instanceof Tagged);
}
const c = new Tagged("circle");
console.log(c.kind.length, all.length, all.includes(t));
console.log(c);
"""
P["g2_box_literal_to_base"] = """// H09b5d guard (classes): Box<1> where Box<number> goes (assignment, parameter, array element),
// Box<"a"> where Box<string> goes; the same object (===) after it.
class Box<T> {
  constructor(public value: T) {}
  get(): T {
    return this.value;
  }
}
const one = new Box(1 as const);
const b: Box<number> = one;
console.log(b.get() + 1, b === one);
const s = new Box("a" as const);
const bs: Box<string> = s;
console.log(bs.get() + "!");
function take(x: Box<number>): number {
  return x.value * 2;
}
console.log(take(one), take(new Box<2>(2)));
const list: Box<number>[] = [one, new Box(3), new Box<4>(4)];
console.log(list.map((x) => x.value).join(","));
b.value = 7;
console.log(one.value, one);
"""
P["g3_instanceof"] = """// H09b5d guard (classes): instanceof across Box<1>, Box<number>, Box<"a">, Box<string>.
""" + BOX + """const xs: unknown[] = [new Box(1 as const), new Box(2), new Box("a" as const), new Box("b"), { value: 1 }];
for (const x of xs) {
  console.log(x instanceof Box, x instanceof Box ? String((x as Box<unknown>).value) : "-");
}
function isOne(b: Box<number> | Box<string>): boolean {
  return b instanceof Box && b.value === 1;
}
console.log(isOne(new Box(1 as const)), isOne(new Box("x" as const)));
"""
P["g4_statics"] = """// H09b5d guard (classes): statics are shared by Counter<1>, Counter<number>, Counter<"a">,
// Counter<string> (D-089).
class Counter<T> {
  static count = 0;
  static label(): string {
    return "Counter" + Counter.count;
  }
  constructor(public v: T) {
    Counter.count++;
  }
}
new Counter(1 as const);
new Counter<number>(2);
new Counter("a" as const);
new Counter<string>("b");
console.log(Counter.count, Counter.label());
"""
P["g5_subclass_shared"] = """// H09b5d guard (classes): a generic subclass of a generic class, for a literal and its base,
// whose members' IR types are the same; Sub<1> where Holder<number> goes.
class Holder<T> {
  constructor(public x: T) {}
  show(): string {
    return "x=" + String(this.x);
  }
}
class Sub<T> extends Holder<T> {
  twice(): string {
    return this.show() + this.show();
  }
}
const a = new Sub(1 as const);
const b = new Sub<number>(2);
const hs: Holder<number>[] = [a, b];
console.log(hs.map((h) => h.show()).join(" "), a.twice(), b instanceof Holder, a instanceof Sub);
"""
P["g6_generic_methods"] = """// H09b5d guard (classes): generic methods of Tagged<"circle"> and Tagged<string>, one class.
""" + BOX + """class Tagged<K extends string> {
  constructor(public kind: K) {}
  map<U>(f: (k: K) => U): Box<U> {
    return new Box(f(this.kind));
  }
}
const a = new Tagged("circle");
const b: Tagged<string> = new Tagged("sq");
console.log(a.map((k) => k.length).value, b.map((k) => k + "!").value);
const ts: Tagged<string>[] = [a, b];
console.log(ts.map((t) => t.map((k) => k.toUpperCase()).value).join(","));
"""
P["r5_subclass_members_differ"] = """// H09b5d RED? (classes): a generic subclass whose inherited member's IR types differ for a
// literal type argument and its base (R<1> = Box<string>, R<number> = Box<number>).
""" + BOX + ATTEMPT + """type R<T> = Box<T extends 1 ? string : number>;
class Holder<T> {
  constructor(public x: T) {}
  pick(v: R<T>): R<T> {
    return new Box(v.value);
  }
}
class Sub<T> extends Holder<T> {
  again(v: R<T>): R<T> {
    return this.pick(v);
  }
}
attempt("1:", () => String(new Sub<1>(1).again(new Box("s")).value + "!"));
attempt("number:", () => String(new Sub<number>(5).again(new Box(7)).value + 1));
"""
P["r6_generic_method_member_differs"] = """// H09b5d RED? (classes): a generic method of Holder<1> and Holder<number> whose signature
// differs by the class's literal type argument.
""" + BOX + ATTEMPT + """type R<T> = Box<T extends 1 ? string : number>;
class Holder<T> {
  constructor(public x: T) {}
  pick<U>(u: U, v: R<T>): [U, R<T>] {
    return [u, new Box(v.value)];
  }
}
attempt("1:", () => {
  const [u, r] = new Holder<1>(1).pick(true, new Box("s"));
  return String(u) + " " + (r.value + "!");
});
attempt("number:", () => {
  const [u, r] = new Holder<number>(5).pick(false, new Box(7));
  return String(u) + " " + (r.value + 1);
});
"""
P["r7_keyof_member"] = """// H09b5d RED? (classes): Tagged<K extends keyof Shapes> whose data member is Shapes[K]: its
// IR type differs for "circle" and "square" (both IR string).
interface Shapes {
  circle: { r: number };
  square: { side: number };
}
class Tagged<K extends keyof Shapes> {
  constructor(public kind: K, public data: Shapes[K]) {}
}
const c = new Tagged("circle", { r: 1 });
const s = new Tagged("square", { side: 2 });
console.log(c.kind, c.data.r, s.kind, s.data.side);
"""
P["r8_keyof_member_stored"] = """// H09b5d guard/risk (classes): as r7, and both stored where Tagged<keyof Shapes> goes, which
// tsc allows: a class split by the members' IR types must still convert them there.
interface Shapes {
  circle: { r: number };
  square: { side: number };
}
class Tagged<K extends keyof Shapes> {
  constructor(public kind: K, public data: Shapes[K]) {}
}
const c = new Tagged("circle", { r: 1 });
const s = new Tagged("square", { side: 2 });
const all: Tagged<keyof Shapes>[] = [c, s];
for (const t of all) {
  console.log(t.kind, JSON.stringify(t.data), t instanceof Tagged);
}
console.log(all[0] === c);
"""
P["r9_any_member_assignable"] = """// H09b5d guard/risk (classes): H<1>'s member is any and H<number>'s number (other IR types); tsc
// allows H<1> where H<number> goes. HEAD shares one class; a split must still convert there.
class H<T> {
  constructor(public v: T extends 1 ? any : number) {}
}
const one = new H<1>("s");
const h: H<number> = one;
console.log(typeof h.v, String(h.v), h === one);
const n = new H<number>(5);
console.log(n.v + 1);
"""
P["r10_twin_class_args"] = """// H09b5d RED? (classes): twins as a generic class's type arguments, with a member whose IR type
// differs (Box<number> vs Box<string>).
""" + BOX + ATTEMPT + """type K<T> = T extends { kind: "a" } ? number : string;
class Holder<T> {
  constructor(public x: T, public k: Box<K<T>>) {}
}
attempt("a:", () => String(new Holder<{ kind: "a" }>({ kind: "a" }, new Box(3)).k.value + 1));
attempt("b:", () => String(new Holder<{ kind: "b" }>({ kind: "b" }, new Box("s")).k.value + "!"));
"""
P["r11_promise_class_args"] = """// H09b5d RED? (classes): Holder<Promise<number>> and Holder<Promise<string>> (IR value), whose
// member Box<Awaited<T>> differs.
""" + BOX + ATTEMPT + """class Holder<T> {
  constructor(public x: T, public k: Box<Awaited<T>>) {}
}
attempt("number:", () => String(new Holder<Promise<number>>(Promise.resolve(1), new Box(3)).k.value + 1));
attempt("string:", () => String(new Holder<Promise<string>>(Promise.resolve("s"), new Box("s")).k.value + "!"));
"""
P["r12_brand_class_args"] = """// H09b5d RED? (classes): Holder<Id> (Id a branded number) and Holder<number>, whose member
// Box<T extends Id ? string : number> differs.
""" + BOX + ATTEMPT + """type Id = number & { readonly __brand: "id" };
class Holder<T> {
  constructor(public x: T, public k: Box<T extends Id ? string : number>) {}
}
attempt("Id:", () => String(new Holder<Id>(5 as Id, new Box("s")).k.value + "!"));
attempt("number:", () => String(new Holder<number>(5, new Box(3)).k.value + 1));
"""
P["r13_literal_field_class"] = """// H09b5d RED? (classes): Holder<1> and Holder<number> with a field (not a method) whose IR type
// differs.
""" + BOX + ATTEMPT + """class Holder<T> {
  constructor(public x: T, public k: Box<T extends 1 ? string : number>) {}
}
attempt("1:", () => String(new Holder<1>(1, new Box("s")).k.value + "!"));
attempt("number:", () => String(new Holder<number>(5, new Box(3)).k.value + 1));
"""
P["g7_literal_class_mixed_store"] = """// H09b5d guard (classes): Holder<1>, Holder<2> and Holder<number> whose members don't differ,
// mixed in one Holder<number>[]; a method that returns T; JSON and console.log of them.
class Holder<T> {
  constructor(public x: T) {}
  get(): T {
    return this.x;
  }
}
const hs: Holder<number>[] = [new Holder(1 as const), new Holder<2>(2), new Holder(3)];
console.log(hs.map((h) => h.get() * 10).join(","), JSON.stringify(hs));
console.log(hs[0]);
"""
for name, text in P.items():
    with open(os.path.join(DIR, name + ".pts"), "w") as f:
        f.write(text)
print(len(P), "class probes")
