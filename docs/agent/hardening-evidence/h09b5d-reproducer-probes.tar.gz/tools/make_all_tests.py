#!/usr/bin/env python3
"""Writes the H09b5d reproducer's RED tests and guards into the worktree's pts/tests/run/ from
their probes (each probe's .node is its expect block), and copies them to red/.

  make_all_tests.py
"""
import os, shutil

WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
RUN = WT + "/pts/tests/run"
R = "/tmp/h09b5d/reproducer"
M9, M10 = R + "/matrix/cases/m9_forms", R + "/matrix/cases/m10_body"
P = R + "/probes"

TESTS = [
    # ------------------------------------------------------------- (a) body only
    ("generic_instances_body_only_twins", M10 + "/cast__twin__decl", [
        "H09b5d RED (C177, body only): { kind: \"a\" } and { kind: \"b\" } are one IR shape, and pick's IR",
        "signature (shape, string) => Out<shape> is the same for both, so the direct calls shared the",
        "instance made for the first, whose body parses the text as K<T> = number: the second call threw",
        "`Expected number, got string`. Each call alone matches Node. A key of IR arguments plus the IR",
        "signature can't tell them apart; only the type arguments' checker identity can."]),
    ("generic_instances_body_only_promises", M10 + "/local__promise__decl", [
        "H09b5d RED (C177, body only): pick<Promise<number>> and pick<Promise<string>> (IR value) have one",
        "IR signature; the shared instance's local `const k: K<T>` is a number, so the second call threw",
        "`Expected number, got string`. Each call alone matches Node."]),
    ("generic_instances_body_only_nested_call", M10 + "/nested__twin__decl", [
        "H09b5d RED (C177, body only): pick's own IR signature is the same for the twins, but the nested",
        "call inner<T> it makes has another (K<T> = number or string): the shared instance calls",
        "inner<{ kind: \"a\" }> for both, so the second call threw `Expected number, got string`."]),
    ("generic_methods_body_only_promises", M10 + "/local__promise__method", [
        "H09b5d RED (C177, body only): a class's generic method called directly for Promise<number> and",
        "Promise<string>: one IR signature, so one instance, whose `const k: K<T>` is a number: the second",
        "call threw `Expected number, got string`."]),
    ("generic_values_body_only_twins", M10 + "/cast__twin__value", [
        "H09b5d RED (C177, body only, a generic value): f<{ kind: \"a\" }> and f<{ kind: \"b\" }> look up",
        "their instance by the IR signature alone (Instance.Key is only for dynamic results), which is the",
        "same, so the second demand found the first's entry and its body: `Expected number, got string`.",
        "Keying instances by checker identity in genericInstanceFor alone doesn't fix this; the",
        "descriptor's entries must be told apart too."]),
    ("generic_dispatched_methods_body_only_twins", M10 + "/cast__twin__dispatched", [
        "H09b5d RED (C177, body only, a dispatched generic method): the method table's entry is found by",
        "the IR signature, the same for both twins: the second call ran the first's instance and threw",
        "`Expected number, got string`."]),
    ("generic_interface_methods_body_only_twins", M10 + "/cast__twin__iface", [
        "H09b5d RED (C177, body only, a class's generic method through an interface, a demand by name):",
        "both twins found one entry and instance: the second call threw `Expected number, got string`."]),
    ("generic_literal_methods_body_only_twins", M10 + "/cast__twin__objlit", [
        "H09b5d RED (C177, body only, an object literal's generic method through its own type): both",
        "twins found one entry and instance: the second call threw `Expected number, got string`."]),
    ("generic_local_arrows_body_only_twins", M10 + "/cast__twin__localarrow", [
        "H09b5d RED (C177, body only, a function-local generic arrow called by name): one instance for",
        "both twins: the second call threw `Expected number, got string`."]),
    ("generic_class_instances_body_only_twins", M10 + "/cast__twin__klass", [
        "H09b5d RED (C177, body only, a generic class): Holder<{ kind: \"a\" }> and Holder<{ kind: \"b\" }>",
        "are one class (IR arguments; no member's IR type differs), whose pick parses the text as",
        "K<T> = number for both: the second threw `Expected number, got string`. Splitting classes only",
        "where their members' IR types differ doesn't fix this."]),
    # ------------------------------------------------------------- C177 through more forms (m9)
    ("generic_dispatched_methods_same_ir_type_twins", M9 + "/twin__a_b__dispatched", [
        "H09b5d RED (C177, a dispatched generic method): the twins' demands have other IR signatures",
        "(Box<number>, Box<string>), but genericInstanceFor returns the first's instance for the second,",
        "which doesn't fit, so the second call kept the erased copy: `Expected Box<string>, got",
        "Box<string | number>`. Each call alone matches Node."]),
    ("generic_interface_methods_same_ir_type_twins", M9 + "/twin__a_b__iface", [
        "H09b5d RED (C177, a class's generic method through an interface): as the dispatched form, the",
        "second twin kept the erased copy: `Expected Box<string>, got Box<string | number>`."]),
    ("generic_literal_methods_same_ir_type_twins", M9 + "/twin__a_b__objiface", [
        "H09b5d RED (C177, an object literal's generic method through an interface): the second twin kept",
        "the erased copy: `Expected Box<string>, got Box<string | number>`."]),
    ("generic_local_arrows_same_ir_type_promises", M9 + "/infer__promise_promise__localarrow", [
        "H09b5d RED (C177, a function-local generic arrow called by name): Promise<number> and",
        "Promise<string> share an instance; the second kept the erased copy: `Expected Box<string>, got",
        "Box<any>`. Each call alone matches Node."]),
    ("generic_inline_arrows_same_ir_type_twins", M9 + "/twin__a_b__valuearrow", [
        "H09b5d RED (C177, an inline generic arrow given as a generic value): the second twin kept the",
        "erased copy: `Expected Box<string>, got Box<string | number>`."]),
    # ------------------------------------------------------------- (b) classes
    ("generic_class_instances_keyof_members", P + "/cls/r7_keyof_member", [
        "H09b5d RED (C177, classes): Tagged<\"circle\"> and Tagged<\"square\"> (IR string) were one class,",
        "made for the first, whose data is Shapes[\"circle\"]: `new Tagged(\"square\", { side: 2 })` was",
        "PTS1001 `using a object2 as a {r: number}`. A realistic keyof pattern."]),
    ("generic_class_instances_keyof_members_stored", P + "/cls/r8_keyof_member_stored", [
        "H09b5d RED (C177, classes; design risk): as generic_class_instances_keyof_members, and both",
        "stored where Tagged<keyof Shapes> goes, as tsc allows. HEAD: the same PTS1001. A fix that splits",
        "classes by their members' IR types makes Tagged<\"circle\">, Tagged<\"square\"> and",
        "Tagged<keyof Shapes> three classes, and must still convert them where tsc allows it."]),
    ("generic_class_instances_any_member_assignable", P + "/cls/r9_any_member_assignable", [
        "H09b5d RED (C177, classes; design risk): H<1>'s member is any and H<number>'s number; HEAD shares",
        "one class, typed for H<number>, so `new H<1>(\"s\")` threw `Expected number, got string`. tsc",
        "allows H<1> where H<number> goes, so split classes would have to convert there."]),
    ("generic_class_instances_twin_type_arguments", P + "/cls/r10_twin_class_args", [
        "H09b5d RED (C177, classes): Holder<{ kind: \"a\" }> and Holder<{ kind: \"b\" }> were one class whose",
        "field k is Box<number>: the second `new Holder` was PTS1001 `using a Box as a Box`."]),
    ("generic_class_instances_promise_type_arguments", P + "/cls/r11_promise_class_args", [
        "H09b5d RED (C177, classes): Holder<Promise<number>> and Holder<Promise<string>> were one class",
        "whose field k is Box<number>: PTS1001 `using a Box as a Box`."]),
    ("generic_subclass_instances_literal_type_arguments", P + "/cls/r5_subclass_members_differ", [
        "H09b5d RED (C177, classes): Sub<1> and Sub<number>, generic subclasses of Holder<T> whose",
        "inherited pick's R<T> differs, were one class (and Holder<1>, Holder<number> one superclass):",
        "PTS1001 `using a Box as a Box`."]),
    ("generic_class_instances_literal_generic_method", P + "/cls/r6_generic_method_member_differs", [
        "H09b5d RED (C177, classes): a generic method of Holder<1> and Holder<number> whose signature",
        "differs by the class's literal type argument: one class, so PTS1001 `using a Box as a Box`."]),
    ("generic_class_instances_split_behaviours", P + "/cls2/r14_split_class_behaviours", [
        "H09b5d RED (C177, classes; what a split class must keep): Holder<{ kind: \"a\" }> and",
        "Sub<{ kind: \"b\" }>, whose field k is Box<number> or Box<string>, were one class: PTS1001 `using",
        "a Box as a Box`. Split, they must still be instances of Holder, share Holder's statics, run",
        "their generic method and print as Node prints them."]),
    ("generic_instances_narrowed_arrays_after_unknown", P + "/split/isarray_promise", [
        "H09b5d guard (split risk): probe<unknown> then probe<Promise<number>> (one IR type) of a body",
        "that returns x.length after Array.isArray(x). HEAD shares unknown's instance and prints Node's",
        "output. An instance of its own for Promise<number> (the parent's candidate, both reproducer",
        "prototypes) narrows x to Promise<number> & any[] and is PTS1001 `x.length`, as",
        "probe<Promise<number>> alone already is on HEAD (D-195/D-197's gap for dynamic type arguments)."]),
    ("generic_class_instances_literal_arguments_tagged", P + "/cls/g1_tagged_store", [
        "H09b5d guard (classes): Tagged<\"circle\"> (inferred), whose members' IR types are",
        "Tagged<string>'s, goes where Tagged<string> goes, is tested with instanceof and printed. A fix",
        "that tells classes apart by literal type arguments must keep this one class."]),
    ("generic_class_instances_literal_to_base", P + "/cls/g2_box_literal_to_base", [
        "H09b5d guard (classes): Box<1> where Box<number> goes (assignment, parameter, array element)",
        "and Box<\"a\"> where Box<string> goes, the same object after it."]),
    ("generic_class_instances_literal_instanceof", P + "/cls/g3b_instanceof", [
        "H09b5d guard (classes): instanceof across Box<1>, Box<number>, Box<\"a\"> and Box<string>."]),
    ("generic_class_instances_literal_statics", P + "/cls/g4_statics", [
        "H09b5d guard (classes): Counter<1>, Counter<number>, Counter<\"a\"> and Counter<string> share",
        "their statics (D-089)."]),
    ("generic_subclass_instances_literal_shared", P + "/cls/g5_subclass_shared", [
        "H09b5d guard (classes): Sub<1> and Sub<number> (members of the same IR types) go where",
        "Holder<number> goes."]),
    ("generic_class_instances_literal_generic_methods", P + "/cls/g6_generic_methods", [
        "H09b5d guard (classes): generic methods of Tagged<\"circle\"> and Tagged<string>, one class, also",
        "through a Tagged<string>[]."]),
    ("generic_class_instances_literal_mixed_array", P + "/cls/g7_literal_class_mixed_store", [
        "H09b5d guard (classes): Holder<1>, Holder<2> and Holder<number> in one Holder<number>[], read,",
        "stringified and printed."]),
    # ------------------------------------------------------------- (c) brands
    ("generic_values_branded_type_arguments", P + "/brand/r1_brand_value_result", [
        "H09b5d RED (C177, brands, a generic value): f<Id> alone: the instance is made for number",
        "(instantiate unbrands Id), whose R<T> is Box<number>, which doesn't fit the call's Box<string>,",
        "so it kept the erased copy: `Expected Box<string>, got Box<string | number>`."]),
    ("generic_instances_branded_body_only", P + "/brand/r2_brand_keyed_lookup", [
        "H09b5d RED (C177, brands, body only): describe<Id>'s instance is number's (instantiate unbrands",
        "Id), so its local Lookup<T> is { count: number }: `Expected {count: number}, got Object`."]),
    ("generic_class_instances_branded_type_arguments", P + "/cls/r12_brand_class_args", [
        "H09b5d RED (C177, brands, classes): Holder<Id> and Holder<number> are one class, made for number:",
        "the Id one's Box<string> field was PTS1001 `using a Box as a Box`."]),
    ("generic_instances_two_brands", P + "/brand/r4_two_brands", [
        "H09b5d RED (C177, brands): UserId and OrderId, two brands of number, are both number's instance,",
        "whose R<T> is Box<boolean>: PTS1001 `using a Box as a Box`."]),
    ("generic_instances_nested_brands", P + "/brand/g1_nested_brands", [
        "H09b5d guard (brands): brands nested in type arguments (Box<Id>, Id[], Map<Id, V>, Set<Id>,",
        "Record<string, Id>) share their primitive's instances and classes: Box<Id> where Box<number>",
        "goes is the same object."]),
    ("generic_values_branded_share_primitive", P + "/brand/g2_brand_values", [
        "H09b5d guard (brands): a generic value and a dispatched generic method called for Id and number,",
        "and Holder<Id> where Holder<number> goes."]),
    ("generic_instances_branded_string_union", P + "/brand/g3b_branded_string_union", [
        "H09b5d guard (brands): a branded string union as a type argument, beside a plain literal, and",
        "Box<Dir> where Box<string> goes."]),
    # ------------------------------------------------------------- (d) dynamic results
    ("generic_dynamic_variants_past_cap_dispatched", P + "/dyn/r2_dispatched_8", [
        "H09b5d RED (C172, maxDynamicVariants, a dispatched generic method): Promise<1> ... Promise<8>;",
        "past four instances of one IR type the 5th to 8th calls kept the erased copy: `Expected",
        "Box<1>, got Box<any>`."]),
    ("generic_dynamic_variants_past_cap_local_arrow", P + "/dyn/r5_localarrow_8", [
        "H09b5d RED (C172, maxDynamicVariants, a function-local generic arrow called by name):",
        "Promise<1> ... Promise<8>: the 5th to 8th threw `Expected Box<1>, got Box<any>`."]),
    ("generic_dynamic_variants_past_cap_async_generators", P + "/dyn/r7_async_generator_8", [
        "H09b5d RED (C172, maxDynamicVariants, a generic async generator value): Promise<1> ...",
        "Promise<8>: the 5th to 8th threw `Expected Box<1>, got Box<any>`."]),
    ("generic_dynamic_variants_past_cap_generators", P + "/dyn/r8_generator_8", [
        "H09b5d RED (C172, maxDynamicVariants, a generic generator value): Promise<1> ... Promise<8> as",
        "the type argument: the 5th to 8th threw `Expected Box<1>, got Box<any>`."]),
    ("generic_dynamic_variants_past_cap_twins", P + "/dyn/r14_twins_dynamic_8", [
        "H09b5d RED (C172, maxDynamicVariants): Promise<{ kind: \"k1\" }> ... Promise<{ kind: \"k8\" }>",
        "through a value: the 5th to 8th threw `Expected Box<{ kind: \"k1\"; }>, got Box<any>`."]),
    ("generic_dynamic_variants_any_after_literals", P + "/dyn/r11_any_after_literals", [
        "H09b5d RED (C172, maxDynamicVariants): after four Promise<k> calls, the any and unknown calls",
        "(right: the erased copy is any's) and Promise<5>'s (wrong: `Expected Box<1>, got Box<any>`) kept",
        "the erased copy."]),
    ("generic_dynamic_variants_mixed_past_cap", P + "/dyn/g10_any_unknown_mixed", [
        "H09b5d RED (C172, maxDynamicVariants): Promise<number>, any, unknown and Promise<1> use up the",
        "four variants, so Promise<2> threw `Expected Box<number>, got Box<any>`: any and unknown count",
        "against the cap."]),
    ("generic_instances_dynamic_results_same_ir_type", P + "/dyn/r15_direct_promise_number_string", [
        "H09b5d RED (C177, direct calls with a dynamic result): unwrap(Promise<number>) then",
        "unwrap(Promise<string>): a direct call isn't `dynamic` (genericInstanceFor), so the second shared",
        "the first's instance, whose Box<number> took the string at run time: `Expected number, got",
        "string`. No PTS1001 catches it: the result is a dynamic value."]),
    ("generic_instances_dynamic_results_unknown", P + "/dyn/r16_direct_unknown_after_promise", [
        "H09b5d RED (C177, direct calls with a dynamic result): unwrap<unknown>(true) after",
        "unwrap(Promise<number>) shared its instance: `Expected number, got boolean`."]),
    ("generic_methods_dynamic_results_same_ir_type", P + "/dyn/r17_direct_method_promise_number_string", [
        "H09b5d RED (C177, a class's generic async method called directly): Promise<number> then",
        "Promise<string> share an instance: `Expected number, got string`."]),
    ("generic_generators_same_ir_type_twins", P + "/dyn/r18_direct_generator_twins", [
        "H09b5d RED (C177, a generic generator called directly): gen<{ kind: \"a\" }> and",
        "gen<{ kind: \"b\" }> share the first's instance, whose v is a number: PTS1001 `converting string",
        "to number`."]),
    ("generic_dynamic_variants_any_unknown_within_cap", P + "/dyn/g10b_any_unknown_within_cap", [
        "H09b5d guard (dynamic results): any and unknown keep instances of their own (a Box<any> holding",
        "a string or a boolean) beside Promise<number> and Promise<1>, four variants."]),
    ("generic_dynamic_variants_literal_generators", P + "/dyn/g9_literal_generator_8", [
        "H09b5d guard (dynamic results): a generic generator value for the literal types 1 ... 8."]),
    ("generic_instances_dynamic_results_literal_promises", P + "/dyn/r6_direct_8", [
        "H09b5d guard (dynamic results): direct calls of a generic async function for Promise<1> ...",
        "Promise<8>, whose instances all make Box<number>s."]),
    ("generic_values_dynamic_results_promise_number_string", P + "/dyn/r19_value_promise_number_string_dynamic", [
        "H09b5d guard (dynamic results): a generic value called for Promise<number> and Promise<string>,",
        "told apart by madeFor (D-190)."]),
    # ------------------------------------------------------------- (e) nested literals
    ("generic_instances_tuple_literal_type_arguments", P + "/nest/tuple__decl", [
        "H09b5d RED (C177, nested literal type arguments): pick<[\"a\"]> and pick<[\"b\"]> are one IR type",
        "([string]) and literals[] only holds top-level literal types: one instance, PTS1001 `using a Box",
        "as a Box`."]),
    ("generic_values_promise_literal_type_arguments", P + "/nest/promise_lit__value", [
        "H09b5d RED (C177, nested literal type arguments, a generic value): f<Promise<\"a\">> and",
        "f<Promise<\"b\">>: the second kept the erased copy: `Expected Box<string>, got Box<string |",
        "number>`."]),
    ("generic_class_instances_union_literal_type_arguments", P + "/nest/union_lit__klass", [
        "H09b5d RED (C177, classes): Holder<\"a\" | \"b\"> and Holder<\"c\" | \"d\"> (literal unions, which",
        "functions tell apart) are one class: PTS1001 `using a Box as a Box`."]),
    ("generic_instances_literal_union_type_arguments", P + "/nest/union_lit__decl", [
        "H09b5d guard (literal type arguments): pick<\"a\" | \"b\"> and pick<\"c\" | \"d\"> are told apart",
        "by D-089's literals."]),
    # ------------------------------------------------------------- narrowing and recursion guards
    ("generic_instances_twin_discriminant_narrowing", P + "/narrow/discriminant__decl", [
        "H09b5d guard (body only): twins A and B (one IR shape) narrowed by their discriminant in a",
        "generic function: the branch dead for one type argument has no trap for twins (D-195)."]),
    ("generic_values_twin_discriminant_narrowing", P + "/narrow/discriminant__value__rev", [
        "H09b5d guard (body only): as generic_instances_twin_discriminant_narrowing, through a value,",
        "B first."]),
    ("generic_class_instances_twin_discriminant_narrowing", P + "/narrow/discriminant__klass", [
        "H09b5d guard (body only): as generic_instances_twin_discriminant_narrowing, in a generic",
        "class's method."]),
    ("generic_instances_twin_switch_narrowing", P + "/narrow/switch_exhaustive__decl", [
        "H09b5d guard (body only): a switch over three twins' discriminant, through a nested generic call."]),
    ("generic_polymorphic_recursion_one_ir_type", P + "/poly/g1_promise_recursion", [
        "H09b5d guard (growth): nest<T> calls nest<Promise<T>>, value at every level: one instance on",
        "HEAD; a checker-structure key makes one per level up to keyPart's depth, and must still compile",
        "and run 20 deep."]),
    ("generic_polymorphic_recursion_one_ir_shape", P + "/poly/g2_twin_recursion", [
        "H09b5d guard (growth): step<T> calls itself for a new literal kind each level (template literal",
        "types), one IR shape."]),
]


def make(src, dest, header):
    lines = open(src + ".pts").read().splitlines()
    while lines and lines[0].startswith("//"):
        lines.pop(0)
    node = open(src + ".node").read().splitlines()
    assert node and node[-1] == "exit=0", src + ": Node must exit 0: " + node[-1]
    node = node[:-1]
    out = ["// " + h for h in header] + lines + ["// expect:"] + [("// " + l) if l else "//" for l in node]
    with open(dest, "w") as f:
        f.write("\n".join(out) + "\n")


os.makedirs(R + "/red", exist_ok=True)
names = []
for name, src, header in TESTS:
    dest = os.path.join(RUN, name + ".pts")
    assert not os.path.exists(dest) or open(dest).read().startswith("// H09b5d"), "would overwrite " + dest
    make(src, dest, header)
    shutil.copy(dest, os.path.join(R, "red", name + ".pts"))
    names.append(name)
open(R + "/red/NAMES.txt", "w").write("\n".join(names) + "\n")
print(len(names), "tests")
