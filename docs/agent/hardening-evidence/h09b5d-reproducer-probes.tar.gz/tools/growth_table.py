#!/usr/bin/env python3
"""growth_table.py LABEL=results.tsv ...: one row per growth case: class, lines of C, build wall
seconds and max RSS (MB) for each labelled run."""
import csv, sys

runs = []
for arg in sys.argv[1:]:
    label, path = arg.split("=", 1)
    runs.append((label, {r["case"]: r for r in csv.DictReader(open(path), delimiter="\t")}))
cases = list(runs[0][1])
order = lambda c: (c.split("_")[0], [int(x) if x.isdigit() else x for x in c.split("_")[1:]])
cases.sort(key=order)
print("case".ljust(16) + "".join(f"{label}: class loc s MB".ljust(34) for label, _ in runs))
for c in cases:
    line = c.ljust(16)
    for _, rows in runs:
        r = rows.get(c)
        if not r:
            line += "-".ljust(34)
            continue
        rss = f"{int(r['build_maxrss_kb']) / 1024:.0f}" if r["build_maxrss_kb"] else "-"
        line += f"{r['class'][:5]} {r['loc'] or '-'} {r['build_wall_s'] or '-'} {rss}".ljust(34)
    print(line)
