#!/bin/bash
# run_growth.sh LABEL: the growth families (m4, m15, m15b) with --loc and 1 job, CLI as run_dirs.sh.
R=/tmp/h09b5d/reproducer
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e
label=$1
case $label in
  head) export PTS=$WT/pts-bin/pts PTS_HOME=$WT ;;
  parent) export PTS=$R/proto/pts-parent PTS_HOME=/home/bryan/projects/parallelscript ;;
  *) export PTS=$R/proto/pts-$label PTS_HOME=$WT ;;
esac
python3 -I $R/tools/run_matrix.py --jobs 1 --loc --out $R/matrix/results_${label}_growth_all.tsv \
  $R/matrix/cases/m4_growth $R/matrix/cases/m15_growth_one_ir > $R/logs/${label}_growth_all.log 2>&1
echo "$label: $(tail -1 $R/logs/${label}_growth_all.log)"
