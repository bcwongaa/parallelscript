#!/usr/bin/env python3
"""H09b5d probes: literal keys a body reads statically (D-089's reason to key literals), at the
top level (guards) and nested in a type argument (body-only REDs?), into probes/lit/."""
import os

DIR = "/tmp/h09b5d/reproducer/probes/lit"
os.makedirs(DIR, exist_ok=True)
F = {}
F["g1_keyof_literal_same_type"] = """// H09b5d guard (D-089): get(o, "a") and get(o, "b") return the same IR type (number); the
// body reads o[k] for a literal K, so the instances must stay apart (literals are keyed).
function get<T, K extends keyof T>(o: T, k: K): T[K] {
  return o[k];
}
const o = { a: 1, b: 2 };
console.log(get(o, "a"), get(o, "b"));
const keys: ("a" | "b")[] = ["b", "a"];
for (const k of keys) {
  console.log(get(o, k));
}
"""
F["r2_nested_literal_key"] = """// H09b5d RED? (C177, body only, a literal nested in a type argument): P = { key: "a" } and
// { key: "b" } are one IR shape and getAt's IR signature is the same; the body reads o[p.key].
function getAt<T, P extends { key: keyof T }>(o: T, p: P): T[P["key"]] {
  return o[p.key];
}
const o = { a: 1, b: 2 };
console.log(getAt(o, { key: "a" as const }), getAt(o, { key: "b" as const }));
"""
F["r3_tuple_literal_key"] = """// H09b5d RED? (C177, body only, a literal in a tuple type argument): P = ["a"] and ["b"].
function getFirst<T, P extends [keyof T]>(o: T, p: P): T[P[0]] {
  return o[p[0]];
}
const o = { a: 1, b: 2 };
console.log(getFirst(o, ["a"]), getFirst(o, ["b"]));
"""
F["r4_nested_literal_key_value"] = """// H09b5d RED? (C177, body only, through a generic value): as r2_nested_literal_key, called as
// a value of a generic function type, whose result holds a generic class instance.
class Box<T> {
  constructor(public value: T) {}
}
function getAt<T, P extends { key: keyof T }>(o: T, p: P): Box<T[P["key"]]> {
  return new Box(o[p.key]);
}
function use(f: <T, P extends { key: keyof T }>(o: T, p: P) => Box<T[P["key"]]>): void {
  const o = { a: 1, b: 2 };
  console.log(f(o, { key: "a" as const }).value, f(o, { key: "b" as const }).value);
}
use(getAt);
"""
F["r5_nested_literal_record_write"] = """// H09b5d RED? (C177, body only): a nested literal key a body writes: set(o, { key: "a" }, 5)
// and set(o, { key: "b" }, 6).
function set<T, P extends { key: keyof T }>(o: T, p: P, v: T[P["key"]]): void {
  o[p.key] = v;
}
const o = { a: 1, b: 2 };
set(o, { key: "a" as const }, 5);
set(o, { key: "b" as const }, 6);
console.log(o.a, o.b);
"""
for name, text in F.items():
    open(os.path.join(DIR, name + ".pts"), "w").write(text)
print(len(F), "probes")
