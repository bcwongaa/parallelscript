#!/usr/bin/env python3
"""H09b5d reproducer: C177 pairs through the demand forms the H09b5 matrix (m7) left out,
and body-only dependence through every form.

  gen_forms.py OUTDIR

Writes two families:
  m9_forms/<shape>__<pair>__<form>[__rev|__soloN].pts
      R<T> (the result and a parameter) differs by checker type for two type arguments of one
      IR type, as in m7, through: dispatched (an abstract class's generic method, overridden),
      iface (a class's generic method through an interface), objlit (an object literal's
      generic method through its own type), objiface (through an interface), localarrow (a
      function-local generic arrow called by name), valuearrow (an inline generic arrow given
      as a value of a generic function type).
  m10_body/<shape>__<pair>__<form>[__rev|__soloN].pts
      the instance's IR signature is the same for both type arguments; only the body depends
      on the checker type: cast (`text` parsed `as K<T>`), local (`const k: K<T> =
      JSON.parse(text)`), nested (a nested generic call `inner<T>(x, JSON.parse(text))` whose
      own signature differs), narrow (a twin's discriminant narrowing: `x.kind === "b"`), for
      every form: decl, method, arrowconst, value, dispatched, iface, objlit, objiface,
      localarrow, valuearrow, klass (a generic class's method).
Each call is wrapped in attempt(), which prints the result or the error, so Node's output is
the oracle for both calls.
"""
import os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "."

PRELUDE = """class Box<T> {
  constructor(public value: T) {}
}
type Id = number & { readonly __brand: "id" };
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""

# ---------------------------------------------------------------- m9: C177 through more forms
SHAPES9 = {
    "infer": "Box<T extends Promise<infer U> ? U : T>",
    "awaited": "Box<Awaited<T>>",
    "brand": "Box<T extends Id ? string : number>",
    "literal": "Box<T extends 1 ? string : number>",
    "twin": 'Box<T extends { kind: "a" } ? number : string>',
}
# (type argument, argument expression, value boxed for v, how to show r.value)
PAIRS9 = {
    "infer": ("promise_promise", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("Promise<string>", 'Promise.resolve("s")', '"t"', 'r.value + "!"')),
    "awaited": ("promise_promise", ("Promise<number>", "Promise.resolve(1)", "2", "r.value + 1"), ("Promise<string>", 'Promise.resolve("s")', '"t"', 'r.value + "!"')),
    "brand": ("brand_number", ("Id", "5 as Id", '"s"', 'r.value + "!"'), ("number", "5", "7", "r.value + 1")),
    "literal": ("one_number", ("1", "1 as const", '"s"', 'r.value + "!"'), ("number", "5", "7", "r.value + 1")),
    "twin": ("a_b", ('{ kind: "a" }', '{ kind: "a" as const }', "3", "r.value + 1"), ('{ kind: "b" }', '{ kind: "b" as const }', '"s"', 'r.value + "!"')),
}

SIG9 = "pick<T>(x: T, v: R<T>): R<T>"
BODY9 = "return new Box(v.value);"


def declare(form, sig, body, result_note=""):
    """Declares `pick` (or Holder) for a form; returns (declaration code, call prefix, wrap)."""
    name, rest = sig.split("<T>", 1)  # "pick", "(x: T, v: R<T>): R<T>"
    if form in ("decl", "value"):
        return f"function {name}<T>{rest} {{\n  {body}\n}}\n"
    if form == "arrowconst":
        return f"const {name} = <T,>{rest} => {{\n  {body}\n}};\n"
    if form == "method":
        return f"class Picker {{\n  {name}<T>{rest} {{\n    {body}\n  }}\n}}\nconst picker = new Picker();\n"
    if form == "dispatched":
        return (f"abstract class Base {{\n  abstract {name}<T>{rest};\n}}\n"
                f"class Picker extends Base {{\n  {name}<T>{rest} {{\n    {body}\n  }}\n}}\nconst picker: Base = new Picker();\n")
    if form == "iface":
        return (f"interface Picks {{\n  {name}<T>{rest};\n}}\n"
                f"class Picker implements Picks {{\n  {name}<T>{rest} {{\n    {body}\n  }}\n}}\nconst picker: Picks = new Picker();\n")
    if form == "objlit":
        return f"const picker = {{\n  {name}<T>{rest} {{\n    {body}\n  }},\n}};\n"
    if form == "objiface":
        return (f"interface Picks {{\n  {name}<T>{rest};\n}}\n"
                f"const picker: Picks = {{\n  {name}<T>{rest} {{\n    {body}\n  }},\n}};\n")
    if form in ("localarrow", "valuearrow"):
        return ""  # declared where it is used
    raise ValueError(form)


def call_of(form, name, targ, args):
    if form in ("decl", "arrowconst", "localarrow"):
        return f"{name}<{targ}>({args})"
    if form in ("value", "valuearrow"):
        return f"f<{targ}>({args})"
    if form in ("method", "dispatched", "iface", "objlit", "objiface"):
        return f"picker.{name}<{targ}>({args})"
    raise ValueError(form)


def wrap_calls(form, sig, body, calls_code):
    """Wraps the calls for forms that need a function around them."""
    name, rest = sig.split("<T>", 1)
    if form == "value":
        ftype = rest.replace("): ", ") => ", 1)
        return f"function use(f: <T>{ftype}): void {{\n{indent(calls_code)}}}\nuse({name});\n"
    if form == "valuearrow":
        ftype = rest.replace("): ", ") => ", 1)
        return (f"function use(f: <T>{ftype}): void {{\n{indent(calls_code)}}}\n"
                f"use(<T,>{rest} => {{\n  {body}\n}});\n")
    if form == "localarrow":
        return (f"function main(): void {{\n  const {name} = <T,>{rest} => {{\n    {body}\n  }};\n"
                f"{indent(calls_code)}}}\nmain();\n")
    return calls_code


def indent(code):
    return "".join("  " + line + "\n" if line else "\n" for line in code.splitlines())


def attempt_code(label, call, show):
    return f'attempt("{label}:", () => {{\n  const r = {call};\n  return String({show});\n}});\n'


def m9(out):
    os.makedirs(out, exist_ok=True)
    names = []
    for shape, (label, first, second) in PAIRS9.items():
        for form in ("dispatched", "iface", "objlit", "objiface", "localarrow", "valuearrow"):
            for variant in ("", "rev", "solo1", "solo2"):
                calls = [first, second]
                if variant == "rev":
                    calls.reverse()
                elif variant == "solo1":
                    calls = [first]
                elif variant == "solo2":
                    calls = [second]
                s = (f"// H09b5d m9 (C177 through a {form} demand): {shape}/{label}, type arguments {first[0]} and\n"
                     f"// {second[0]} of one IR type, R<T> = {SHAPES9[shape]}{' (second first)' if variant == 'rev' else ''}{' (' + variant + ' control)' if variant.startswith('solo') else ''}.\n")
                s += PRELUDE + f"type R<T> = {SHAPES9[shape]};\n"
                s += declare(form, SIG9, BODY9)
                code = ""
                for targ, arg, v, show in calls:
                    code += attempt_code(targ.replace('"', "'"), call_of(form, "pick", targ, f"{arg}, new Box({v})"), show)
                s += wrap_calls(form, SIG9, BODY9, code)
                name = f"{shape}__{label}__{form}" + (f"__{variant}" if variant else "")
                open(os.path.join(out, name + ".pts"), "w").write(s)
                names.append(name)
    return names


# ---------------------------------------------------------------- m10: body-only dependence
# K<T> differs by checker type for each pair; the signature (x: T, text: string): Out<T>
# is the same IR type for both type arguments.
PAIRS10 = {
    "twin": ('T extends { kind: "a" } ? number : string',
             ('{ kind: "a" }', '{ kind: "a" as const }', "3"), ('{ kind: "b" }', '{ kind: "b" as const }', '"s"')),
    "promise": ("Awaited<T>",
                ("Promise<number>", "Promise.resolve(1)", "3"), ("Promise<string>", 'Promise.resolve("s")', '"s"')),
    "brand": ("T extends Id ? string : number",
              ("Id", "5 as Id", '"s"'), ("number", "5", "3")),
}
OUT_CLASS = """class Out<T> {
  constructor(public x: T, public note: string) {}
}
"""
BODIES10 = {
    # the text parsed and cast to K<T>, which a checked conversion makes of the parsed value
    "cast": ("pick<T>(x: T, text: string): Out<T>",
             "const k = JSON.parse(text) as K<T>;\n    return new Out(x, typeof k + \" \" + String(k));"),
    # a local of type K<T> holding the parsed value
    "local": ("pick<T>(x: T, text: string): Out<T>",
              "const k: K<T> = JSON.parse(text);\n    return new Out(x, typeof k + \" \" + String(k));"),
    # a nested generic call whose own signature differs by T's checker type
    "nested": ("pick<T>(x: T, text: string): Out<T>",
               "const b = inner<T>(x, JSON.parse(text));\n    return new Out(x, typeof b.value + \" \" + String(b.value));"),
}
INNER = "function inner<T>(x: T, v: K<T>): Box<K<T>> {\n  return new Box(v);\n}\n"


def body_decl(form, sig, body):
    """declare() for a body with a statement list (the bodies above are two statements)."""
    flat = body.replace("\n    ", "\n  ")
    name, rest = sig.split("<T>", 1)
    if form == "klass":
        return ("class Holder<T> {\n  constructor(public x: T) {}\n"
                f"  pick(text: string): Out<T> {{\n    {body.replace('new Out(x,', 'new Out(this.x,').replace('inner<T>(x,', 'inner<T>(this.x,')}\n  }}\n}}\n")
    if form in ("decl", "value"):
        return f"function {name}<T>{rest} {{\n  {flat}\n}}\n"
    if form == "arrowconst":
        return f"const {name} = <T,>{rest} => {{\n  {flat}\n}};\n"
    return declare(form, sig, body)


def m10(out):
    os.makedirs(out, exist_ok=True)
    names = []
    forms = ("decl", "method", "arrowconst", "value", "dispatched", "iface", "objlit", "objiface", "localarrow", "valuearrow", "klass")
    for bname, (sig, body) in BODIES10.items():
        for pname, (k, first, second) in PAIRS10.items():
            for form in forms:
                variants = ["", "rev"]
                if form in ("decl", "value", "klass", "dispatched"):
                    variants += ["solo1", "solo2"]
                elif pname == "brand":
                    variants += ["solo1"]
                for variant in variants:
                    calls = [first, second]
                    if variant == "rev":
                        calls.reverse()
                    elif variant == "solo1":
                        calls = [first]
                    elif variant == "solo2":
                        calls = [second]
                    s = (f"// H09b5d m10 (body-only, {bname}, {form}): {first[0]} and {second[0]}, one IR type and one IR\n"
                         f"// signature; only the body's K<T> = {k} differs{' (second first)' if variant == 'rev' else ''}{' (' + variant + ' control)' if variant.startswith('solo') else ''}.\n")
                    s += PRELUDE + OUT_CLASS + f"type K<T> = {k};\n"
                    if bname == "nested":
                        s += INNER
                    s += body_decl(form, sig, body)
                    code = ""
                    for targ, arg, text in calls:
                        label = targ.replace('"', "'")
                        jtext = "JSON.stringify(" + text + ")"
                        if form == "klass":
                            call = f"new Holder<{targ}>({arg}).pick({jtext})"
                        else:
                            call = call_of(form, "pick", targ, f"{arg}, {jtext}")
                        code += attempt_code(label, call, "r.note")
                    s += wrap_calls(form, sig, body.replace("\n    ", "\n  "), code) if form != "klass" else code
                    name = f"{bname}__{pname}__{form}" + (f"__{variant}" if variant else "")
                    open(os.path.join(out, name + ".pts"), "w").write(s)
                    names.append(name)
    return names


a = m9(os.path.join(OUT, "m9_forms"))
b = m10(os.path.join(OUT, "m10_body"))
print(len(a), "m9 cases,", len(b), "m10 cases")
