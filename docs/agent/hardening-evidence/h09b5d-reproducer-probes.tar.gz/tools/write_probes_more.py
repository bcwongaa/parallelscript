#!/usr/bin/env python3
"""Writes the H09b5d brand (c), dynamic-variant (d), nested-literal (e) and narrowing (a, body
only) probes into probes/{brand,dyn,nest,narrow}/."""
import os

ROOT = "/tmp/h09b5d/reproducer/probes"
ATTEMPT = """function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
"""
BOX = """class Box<T> {
  constructor(public value: T) {}
}
"""
ID = 'type Id = number & { readonly __brand: "id" };\n'
FILES = {}

# ------------------------------------------------------------------------- (c) brands
FILES["brand/g1_nested_brands"] = """// H09b5d guard (brands): brands nested in type arguments (Box<Id>, Id[], Map<Id, V>, Set<Id>,
// Record<string, Id>) share their primitive's instances and classes on HEAD.
""" + BOX + ID + """function wrap<T>(x: T): Box<T> {
  return new Box(x);
}
function first<T>(xs: T[]): T {
  return xs[0];
}
const id = 5 as Id;
const b: Box<Id> = wrap(id);
const bn: Box<number> = wrap(7);
const widened: Box<number> = b;
console.log(b.value + 1, bn.value + 1, widened === b);
const ids: Id[] = [1 as Id, 2 as Id];
console.log(first(ids) + first([10, 20]));
const m = new Map<Id, string>([[id, "five"]]);
function get<K, V>(m: Map<K, V>, k: K): V | undefined {
  return m.get(k);
}
console.log(get(m, id), get(new Map([[1, "one"]]), 1));
const s = new Set<Id>([id]);
function has<T>(s: Set<T>, x: T): boolean {
  return s.has(x);
}
console.log(has(s, id), has(new Set([1]), 2));
const r: Record<string, Id> = { a: id };
function val<T>(r: Record<string, T>, k: string): T {
  return r[k];
}
console.log(val(r, "a") + 0, val({ b: 3 }, "b"));
const boxes: Box<Id>[] = [wrap(1 as Id), wrap(2 as Id)];
console.log(boxes.map((x) => x.value * 2).join(","));
"""
FILES["brand/g2_brand_values"] = """// H09b5d guard (brands): a generic value called for Id and number, a dispatched generic method,
// and a generic class instance for Id where one for number goes.
""" + BOX + ID + """function wrap<T>(x: T): Box<T> {
  return new Box(x);
}
function use(f: <T>(x: T) => Box<T>): void {
  console.log(f<Id>(5 as Id).value + 1, f<number>(6).value + 1, f(7 as Id).value);
}
use(wrap);
abstract class Maker {
  abstract make<T>(x: T): Box<T>;
}
class BoxMaker extends Maker {
  make<T>(x: T): Box<T> {
    return new Box(x);
  }
}
const maker: Maker = new BoxMaker();
console.log(maker.make<Id>(3 as Id).value, maker.make(4).value);
class Holder<T> {
  constructor(public x: T) {}
}
const h: Holder<number> = new Holder<Id>(9 as Id);
console.log(h.x + 1);
"""
FILES["brand/g3_branded_string_union"] = """// H09b5d guard (brands): a branded string union (`("up" | "down") & { __brand }`) as a type
// argument, beside a plain string literal.
""" + BOX + """type Dir = ("up" | "down") & { readonly __brand: "dir" };
function flip<T extends string>(x: T): Box<T> {
  return new Box(x);
}
const d = "up" as Dir;
console.log(flip(d).value, flip("left").value);
const ds: Dir[] = ["up" as Dir, "down" as Dir];
console.log(ds.map((x) => flip(x).value.toUpperCase()).join(","));
function keyed<K extends string>(k: K, n: number): Record<K, number> {
  return { [k]: n } as Record<K, number>;
}
console.log(JSON.stringify(keyed(d, 1)), JSON.stringify(keyed("x", 2)));
"""
FILES["brand/r1_brand_value_result"] = """// H09b5d RED? (brands): R<Id> differs from R<number> through a generic value: each call alone.
""" + BOX + ID + ATTEMPT + """type R<T> = Box<T extends Id ? string : number>;
function pick<T>(x: T, v: R<T>): R<T> {
  return new Box(v.value);
}
function use(f: <T>(x: T, v: R<T>) => R<T>): void {
  attempt("Id:", () => String(f<Id>(5 as Id, new Box("s")).value + "!"));
}
use(pick);
"""
FILES["brand/r2_brand_keyed_lookup"] = """// H09b5d RED? (brands): an instance whose body depends on the brand (a keyof-style lookup):
// Lookup<Id> is a string record, Lookup<number> a number one.
""" + ID + ATTEMPT + """type Lookup<T> = T extends Id ? { name: string } : { count: number };
function describe<T>(x: T, raw: string): string {
  const v: Lookup<T> = JSON.parse(raw);
  return JSON.stringify(v);
}
attempt("Id:", () => describe<Id>(5 as Id, '{"name":"five"}'));
attempt("number:", () => describe<number>(5, '{"count":5}'));
"""
FILES["brand/r3_brand_alone_direct"] = """// H09b5d RED? (brands): pick<Id> alone (no number call), R<Id> = Box<string>.
""" + BOX + ID + ATTEMPT + """type R<T> = Box<T extends Id ? string : number>;
function pick<T>(x: T, v: R<T>): R<T> {
  return new Box(v.value);
}
attempt("Id:", () => String(pick<Id>(5 as Id, new Box("s")).value + "!"));
"""
FILES["brand/r4_two_brands"] = """// H09b5d RED? (brands): two brands of number, UserId and OrderId, whose R<T> differ.
""" + BOX + ATTEMPT + """type UserId = number & { readonly __brand: "user" };
type OrderId = number & { readonly __brand: "order" };
type R<T> = Box<T extends UserId ? string : boolean>;
function pick<T>(x: T, v: R<T>): R<T> {
  return new Box(v.value);
}
attempt("UserId:", () => String(pick<UserId>(1 as UserId, new Box("u")).value + "!"));
attempt("OrderId:", () => String(pick<OrderId>(2 as OrderId, new Box(true)).value === true));
"""

# ------------------------------------------------------------------------- (d) dynamic results
DYN_VALUE = """async function unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
  return new Box(await x);
}
"""


def dyn_calls(n, prefix, indent="  "):
    out = ""
    for i in range(1, n + 1):
        out += f'{indent}try {{ show("{i}", (await {prefix}(Promise.resolve({i} as const))).value); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n'
    return out


SHOW = '  const show = (label: string, n: number): void => console.log(label, n + 1);\n'
FILES["dyn/r1_value_8"] = """// H09b5d RED (C172 maxDynamicVariants, q08's shape): a generic value with a dynamic result,
// called for Promise<1> ... Promise<8>.
""" + BOX + DYN_VALUE + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
""" + SHOW + dyn_calls(8, "f") + """}
use(unwrap);
"""
FILES["dyn/r2_dispatched_8"] = """// H09b5d RED? (maxDynamicVariants): a dispatched (overridden) generic async method called for
// Promise<1> ... Promise<8>.
""" + BOX + """abstract class Base {
  abstract unwrap<T>(x: T): Promise<Box<Awaited<T>>>;
}
class Impl extends Base {
  async unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
    return new Box(await x);
  }
}
const o: Base = new Impl();
async function main(): Promise<void> {
""" + SHOW + dyn_calls(8, "o.unwrap") + """}
main();
"""
FILES["dyn/r3_interface_8"] = """// H09b5d RED? (maxDynamicVariants): an interface's generic async method (a class implements it)
// called for Promise<1> ... Promise<8>.
""" + BOX + """interface Unwraps {
  unwrap<T>(x: T): Promise<Box<Awaited<T>>>;
}
class Impl implements Unwraps {
  async unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
    return new Box(await x);
  }
}
const o: Unwraps = new Impl();
async function main(): Promise<void> {
""" + SHOW + dyn_calls(8, "o.unwrap") + """}
main();
"""
FILES["dyn/r4_objlit_8"] = """// H09b5d RED? (maxDynamicVariants): an object literal's generic async method through an
// interface, called for Promise<1> ... Promise<8>.
""" + BOX + """interface Unwraps {
  unwrap<T>(x: T): Promise<Box<Awaited<T>>>;
}
const o: Unwraps = {
  async unwrap<T>(x: T): Promise<Box<Awaited<T>>> {
    return new Box(await x);
  },
};
async function main(): Promise<void> {
""" + SHOW + dyn_calls(8, "o.unwrap") + """}
main();
"""
FILES["dyn/r5_localarrow_8"] = """// H09b5d RED? (maxDynamicVariants): a function-local generic async arrow called by name for
// Promise<1> ... Promise<8>.
""" + BOX + """async function main(): Promise<void> {
  const unwrap = async <T,>(x: T): Promise<Box<Awaited<T>>> => new Box(await x);
""" + SHOW + dyn_calls(8, "unwrap") + """}
main();
"""
FILES["dyn/r6_direct_8"] = """// H09b5d guard? (maxDynamicVariants): direct calls of a generic async function declaration for
// Promise<1> ... Promise<8> (a direct call isn't dynamic: genericInstanceFor's dynamic=false).
""" + BOX + DYN_VALUE + """async function main(): Promise<void> {
""" + SHOW + dyn_calls(8, "unwrap") + """}
main();
"""
FILES["dyn/r7_async_generator_8"] = """// H09b5d RED? (maxDynamicVariants): a generic async generator value for Promise<1> ...
// Promise<8>.
""" + BOX + """async function* gen<T>(x: T): AsyncGenerator<Box<Awaited<T>>> {
  yield new Box(await x);
}
async function use(f: <T>(x: T) => AsyncGenerator<Box<Awaited<T>>>): Promise<void> {
  for (let i = 1; i <= 8; i++) {
    void i;
  }
""" + "".join(f'  try {{ for await (const b of f(Promise.resolve({i} as const))) console.log("{i}", b.value + 1); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n' for i in range(1, 9)) + """}
use(gen);
"""
FILES["dyn/r8_generator_8"] = """// H09b5d RED? (maxDynamicVariants): a generic generator value whose Box<Unwrap<T>> holds the
// promise's type: Promise<1> ... Promise<8>.
""" + BOX + """type Unwrap<T> = T extends Promise<infer U> ? U : T;
function* gen<T>(x: T, u: Unwrap<T>): Generator<Box<Unwrap<T>>> {
  yield new Box(u);
}
function use(f: <T>(x: T, u: Unwrap<T>) => Generator<Box<Unwrap<T>>>): void {
""" + "".join(f'  try {{ for (const b of f(Promise.resolve({i} as const), {i})) console.log("{i}", b.value + 1); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n' for i in range(1, 9)) + """}
use(gen);
"""
FILES["dyn/g9_literal_generator_8"] = """// H09b5d guard (dynamic results): a generic generator value for literal type arguments 1 ... 8
// (literal type arguments are told apart: no cap).
""" + BOX + """function* gen<T>(x: T): Generator<Box<T>> {
  yield new Box(x);
}
function use(f: <T>(x: T) => Generator<Box<T>>): void {
""" + "".join(f'  for (const b of f({i} as const)) console.log("{i}", b.value + 1);\n' for i in range(1, 9)) + """}
use(gen);
"""
FILES["dyn/g10_any_unknown_mixed"] = """// H09b5d guard (dynamic results): any and unknown type arguments keep instances of their own
// (Box<any> holds a string) beside Promise<number> and Promise<1>, Promise<2>.
""" + BOX + DYN_VALUE + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
  const show = (label: string, v: unknown): void => console.log(label, typeof v, String(v));
  try { show("number", (await f(Promise.resolve(1))).value); } catch (e: any) { console.log("number threw", e.message); }
  try { show("any", (await f<any>("s")).value); } catch (e: any) { console.log("any threw", e.message); }
  try { show("unknown", (await f<unknown>(true)).value); } catch (e: any) { console.log("unknown threw", e.message); }
  try { show("1", (await f(Promise.resolve(1 as const))).value); } catch (e: any) { console.log("1 threw", e.message); }
  try { show("2", (await f(Promise.resolve(2 as const))).value); } catch (e: any) { console.log("2 threw", e.message); }
  try { show("any2", (await f<any>(Promise.resolve([1]))).value); } catch (e: any) { console.log("any2 threw", e.message); }
}
use(unwrap);
"""
FILES["dyn/r11_any_after_literals"] = """// H09b5d RED? (dynamic results): an any call after four literal Promise<k> calls: past the cap
// it keeps the erased copy (right for any), and the literal calls after it too.
""" + BOX + DYN_VALUE + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
  const show = (label: string, v: unknown): void => console.log(label, typeof v, String(v));
""" + "".join(f'  try {{ show("{i}", (await f(Promise.resolve({i} as const))).value); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n' for i in range(1, 5)) + """  try { show("any", (await f<any>("s")).value); } catch (e: any) { console.log("any threw", e.message); }
  try { show("unknown", (await f<unknown>(true)).value); } catch (e: any) { console.log("unknown threw", e.message); }
  try { show("5", (await f(Promise.resolve(5 as const))).value); } catch (e: any) { console.log("5 threw", e.message); }
}
use(unwrap);
"""
FILES["dyn/r12_direct_any_shares"] = """// H09b5d RED? (direct calls, dynamic results): unwrap<Promise<number>> then unwrap<any> with a
// string: a direct call isn't dynamic, so the any call may share Promise<number>'s instance.
""" + BOX + DYN_VALUE + """async function main(): Promise<void> {
  const show = (label: string, v: unknown): void => console.log(label, typeof v, String(v));
  try { show("number", (await unwrap(Promise.resolve(1))).value); } catch (e: any) { console.log("number threw", e.message); }
  try { show("any", (await unwrap<any>("s")).value); } catch (e: any) { console.log("any threw", e.message); }
}
main();
"""
FILES["dyn/r13_value_strings_8"] = """// H09b5d RED (maxDynamicVariants): string literal promises "k1" ... "k8" through a value.
""" + BOX + DYN_VALUE + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
""" + "".join(f'  try {{ console.log("{i}", (await f(Promise.resolve("k{i}" as const))).value + "!"); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n' for i in range(1, 9)) + """}
use(unwrap);
"""
FILES["dyn/r14_twins_dynamic_8"] = """// H09b5d RED? (maxDynamicVariants): Promise<{ kind: "k1" }> ... Promise<{ kind: "k8" }> (twins in
// a promise) through a value.
""" + BOX + DYN_VALUE + """async function use(f: <T>(x: T) => Promise<Box<Awaited<T>>>): Promise<void> {
""" + "".join(f'  try {{ console.log("{i}", (await f(Promise.resolve({{ kind: "k{i}" as const }}))).value.kind + "!"); }} catch (e: any) {{ console.log("{i} threw", e.message); }}\n' for i in range(1, 9)) + """}
use(unwrap);
"""

# ------------------------------------------------------------------------- (e) nested literals


def nested(name, desc, k, a, b, forms=("decl", "value", "klass")):
    for form in forms:
        for rev in (False, True):
            calls = [a, b] if not rev else [b, a]
            s = f"// H09b5d (nested literal type arguments, {form}{', second first' if rev else ''}): {desc}.\n" + BOX + ATTEMPT
            s += f"type R<T> = Box<{k}>;\n"
            if form in ("decl", "value"):
                s += "function pick<T>(x: T, v: R<T>): R<T> {\n  return new Box(v.value);\n}\n"
            else:
                s += "class Holder<T> {\n  constructor(public x: T) {}\n  pick(v: R<T>): R<T> {\n    return new Box(v.value);\n  }\n}\n"
            code = ""
            for targ, arg, v, show in calls:
                if form == "decl":
                    call = f"pick<{targ}>({arg}, new Box({v}))"
                elif form == "value":
                    call = f"f<{targ}>({arg}, new Box({v}))"
                else:
                    call = f"new Holder<{targ}>({arg}).pick(new Box({v}))"
                code += f'attempt("{targ.replace(chr(34), chr(39))}:", () => {{\n  const r = {call};\n  return String({show});\n}});\n'
            if form == "value":
                s += "function use(f: <T>(x: T, v: R<T>) => R<T>): void {\n" + "".join("  " + l + "\n" for l in code.splitlines()) + "}\nuse(pick);\n"
            else:
                s += code
            FILES[f"nest/{name}__{form}" + ("__rev" if rev else "")] = s


nested("tuple", '["a"] and ["b"] (tuple literals, IR [string])', 'T extends ["a"] ? number : string',
       ('["a"]', '["a"]', "3", "r.value + 1"), ('["b"]', '["b"]', '"s"', 'r.value + "!"'))
nested("promise_lit", 'Promise<"a"> and Promise<"b">', 'T extends Promise<"a"> ? number : string',
       ('Promise<"a">', 'Promise.resolve("a" as const)', "3", "r.value + 1"), ('Promise<"b">', 'Promise.resolve("b" as const)', '"s"', 'r.value + "!"'))
nested("array_lit", '"a"[] and "b"[]', 'T extends "a"[] ? number : string',
       ('"a"[]', '["a" as const]', "3", "r.value + 1"), ('"b"[]', '["b" as const]', '"s"', 'r.value + "!"'))
nested("fn_lit", '() => "a" and () => "b" (function types)', 'T extends () => "a" ? number : string',
       ('() => "a"', '() => "a" as const', "3", "r.value + 1"), ('() => "b"', '() => "b" as const', '"s"', 'r.value + "!"'))
nested("map_lit", 'Map<"a", number> and Map<"b", number>', 'T extends Map<"a", number> ? number : string',
       ('Map<"a", number>', 'new Map<"a", number>()', "3", "r.value + 1"), ('Map<"b", number>', 'new Map<"b", number>()', '"s"', 'r.value + "!"'))
nested("obj_lit", '{ k: "a" } and { k: "b" } (object literal types)', 'T extends { k: "a" } ? number : string',
       ('{ k: "a" }', '{ k: "a" as const }', "3", "r.value + 1"), ('{ k: "b" }', '{ k: "b" as const }', '"s"', 'r.value + "!"'))
nested("union_lit", '"a" | "b" and "c" | "d" (literal unions: told apart by literals, guard)', 'T extends "a" | "b" ? number : string',
       ('"a" | "b"', '"a" as "a" | "b"', "3", "r.value + 1"), ('"c" | "d"', '"c" as "c" | "d"', '"s"', 'r.value + "!"'))

# ------------------------------------------------------------------------- (a) body-only narrowing
NARROW_HEAD = """class Out<T> {
  constructor(public x: T, public note: string) {}
}
type A = { kind: "a"; n: number };
type B = { kind: "b"; n: number };
"""
for form in ("decl", "value", "klass"):
    for rev in (False, True):
        calls = [("A", '{ kind: "a", n: 1 }'), ("B", '{ kind: "b", n: 2 }')]
        if rev:
            calls.reverse()
        s = (f"// H09b5d (body-only, narrowing, {form}{', second first' if rev else ''}): A and B are twins (one IR shape); the\n"
             f"// instance's body narrows x by its discriminant: dead for one type argument (D-195).\n") + ATTEMPT + NARROW_HEAD
        if form in ("decl", "value"):
            s += """function describe<T extends A | B>(x: T): Out<T> {
  if (x.kind === "b") {
    const y: B = x;
    return new Out(x, "b " + y.n);
  }
  return new Out(x, "a " + x.n);
}
"""
        else:
            s += """class Holder<T extends A | B> {
  constructor(public x: T) {}
  describe(): Out<T> {
    const x = this.x;
    if (x.kind === "b") {
      const y: B = x;
      return new Out(x, "b " + y.n);
    }
    return new Out(x, "a " + x.n);
  }
}
"""
        code = ""
        for targ, arg in calls:
            if form == "decl":
                call = f"describe<{targ}>({arg})"
            elif form == "value":
                call = f"f<{targ}>({arg})"
            else:
                call = f"new Holder<{targ}>({arg}).describe()"
            code += f'attempt("{targ}:", () => {call}.note);\n'
        if form == "value":
            s += "function use(f: <T extends A | B>(x: T) => Out<T>): void {\n" + "".join("  " + l + "\n" for l in code.splitlines()) + "}\nuse(describe);\n"
        else:
            s += code
        FILES[f"narrow/discriminant__{form}" + ("__rev" if rev else "")] = s

FILES["narrow/switch_exhaustive__decl"] = """// H09b5d (body-only, narrowing): a switch over twins' discriminant whose other cases are dead
// for each type argument; one IR shape and one IR signature.
""" + ATTEMPT + """type A = { kind: "a"; n: number };
type B = { kind: "b"; n: number };
type C = { kind: "c"; n: number };
function area<T extends A | B | C>(x: T): string {
  switch (x.kind) {
    case "a":
      return "a" + x.n;
    case "b":
      return "b" + x.n * 2;
    default:
      return "c" + x.n * 3;
  }
}
function wrapped<T extends A | B | C>(x: T): string[] {
  return [area<T>(x)];
}
attempt("A:", () => wrapped<A>({ kind: "a", n: 1 }).join());
attempt("B:", () => wrapped<B>({ kind: "b", n: 2 }).join());
attempt("C:", () => wrapped<C>({ kind: "c", n: 3 }).join());
"""

for rel, text in FILES.items():
    path = os.path.join(ROOT, rel + ".pts")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(text)
print(len(FILES), "probes")
