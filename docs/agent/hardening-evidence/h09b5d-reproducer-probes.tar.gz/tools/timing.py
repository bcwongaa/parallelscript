#!/usr/bin/env python3
"""timing.py ROUNDS CASE.pts...: builds each case with each CLI (head, parent, A = pts-pa_cls2,
B = pts-pb), interleaved, ROUNDS times, one build at a time; prints wall seconds, user seconds
and max RSS per build and the median wall per CLI and case. Binaries are deleted at once."""
import os, statistics, subprocess, sys, tempfile

R = "/tmp/h09b5d/reproducer"
WT = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e"
CLIS = {
    "HEAD": (WT + "/pts-bin/pts", WT),
    "parent": (R + "/proto/pts-parent", "/home/bryan/projects/parallelscript"),
    "A": (R + "/proto/pts-pa_cls2", WT),
    "B": (R + "/proto/pts-pb", WT),
}
rounds = int(sys.argv[1])
results = {}
for _ in range(rounds):
    for case in sys.argv[2:]:
        for label, (pts, home) in CLIS.items():
            d = tempfile.mkdtemp(dir=R + "/tmp")
            exe, timing = os.path.join(d, "case.bin"), os.path.join(d, "time.txt")
            env = dict(os.environ, PTS_HOME=home)
            p = subprocess.run(["/usr/bin/time", "-o", timing, "-f", "%e %U %M", pts, "build", case, "-o", exe], cwd=d, env=env, capture_output=True, text=True)
            wall, user, rss = open(timing).read().split()[-3:]
            name = os.path.basename(case)
            print(f"{name:20s} {label:7s} exit={p.returncode} wall={wall} user={user} rss_mb={int(rss) // 1024}", flush=True)
            results.setdefault((name, label), []).append(float(wall))
            subprocess.run(["rm", "-rf", d])
print()
for (name, label), walls in sorted(results.items()):
    print(f"{name:20s} {label:7s} median wall {statistics.median(walls):.2f} s over {len(walls)}")
