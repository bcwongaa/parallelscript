#!/usr/bin/env python3
"""compare.py LABEL=results.tsv ...: per-family counts for each labelled run (the first is the
base), the cases each later run fixed (base not OK -> OK) and broke (base OK -> not OK), and the
cases still not OK in each run, with their first difference."""
import collections, csv, sys

FAMILIES = [
    ("m5", lambda c: c.startswith("literal_num") or c.startswith("literal_str") or c.startswith("unions_")),
    ("m7", lambda c: c.split("__")[0] in ("infer", "awaited", "brand", "literal", "twin", "narrowed") and (len(c.split("__")) < 3 or c.split("__")[2].split("/")[0] in ("decl", "method", "arrowconst", "value", "klass"))),
    ("m9", lambda c: c.split("__")[0] in ("infer", "awaited", "brand", "literal", "twin") and len(c.split("__")) >= 3 and c.split("__")[2] in ("dispatched", "iface", "objlit", "objiface", "localarrow", "valuearrow")),
    ("m10", lambda c: c.split("__")[0] in ("cast", "local", "nested")),
    ("nest", lambda c: c.split("__")[0] in ("tuple", "promise_lit", "array_lit", "fn_lit", "map_lit", "obj_lit", "union_lit")),
    ("narrow", lambda c: c.startswith("discriminant") or c.startswith("switch_")),
    ("other probes", lambda c: True),
]


def family(case):
    for name, test in FAMILIES:
        if test(case):
            return name


runs = []
for arg in sys.argv[1:]:
    label, path = arg.split("=", 1)
    runs.append((label, {r["case"]: r for r in csv.DictReader(open(path), delimiter="\t")}))
base_label, base = runs[0]
cases = list(base)
print("family".ljust(14) + "".join(label.ljust(34) for label, _ in runs))
for name, _ in FAMILIES:
    members = [c for c in cases if family(c) == name]
    line = f"{name} ({len(members)})".ljust(14)
    for label, rows in runs:
        counts = collections.Counter(rows[c]["class"] if c in rows else "-" for c in members)
        line += " ".join(f"{k}={v}" for k, v in sorted(counts.items())).ljust(34)
    print(line)
for label, rows in runs[1:]:
    fixed = [c for c in cases if c in rows and base[c]["class"] != "OK" and rows[c]["class"] == "OK"]
    broke = [c for c in cases if c in rows and base[c]["class"] == "OK" and rows[c]["class"] != "OK"]
    print(f"\n{label}: fixed {len(fixed)}, broke {len(broke)}")
    for c in broke:
        print("  BROKE", c, rows[c]["class"], rows[c]["first_difference"][:160])
    still = [c for c in cases if c in rows and rows[c]["class"] != "OK"]
    print(f"  still not OK: {len(still)}")
    for c in still:
        print("   ", c, rows[c]["class"], rows[c]["first_difference"][:140])
