#!/bin/bash
# run_dirs.sh LABEL OUTNAME DIR...: run_matrix (1 job) over DIRs with the CLI LABEL names:
# head (the worktree's), parent (snapshot, main tree's runtime), or a prototype pts-LABEL.
R=/tmp/h09b5d/reproducer
WT=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a4f68737cf2abea6e
label=$1; outname=$2; shift 2
case $label in
  head) export PTS=$WT/pts-bin/pts PTS_HOME=$WT ;;
  parent) export PTS=$R/proto/pts-parent PTS_HOME=/home/bryan/projects/parallelscript ;;
  *) export PTS=$R/proto/pts-$label PTS_HOME=$WT ;;
esac
python3 -I $R/tools/run_matrix.py --jobs 1 --out $R/matrix/results_${label}_${outname}.tsv "$@" > $R/logs/${label}_${outname}.log 2>&1
echo "$label $outname: $(tail -1 $R/logs/${label}_${outname}.log)"
