#!/bin/bash
# usage: run3.sh file.pts [threads]  -- runs new PTS, base PTS and Node (.mts copy or .oracle.mts twin)
f="$1"; t="${2:-1}"
d=$(dirname "$f"); b=$(basename "$f" .pts)
ulimit -v 4194304
echo "--- NEW (PTS_THREADS=$t)"
PTS_THREADS=$t PTS_HOME=/home/bryan/projects/parallelscript timeout 120 /tmp/h06/review3/pts run "$f" 2>&1; echo "[exit=$?]"
if [ -z "$NOBASE" ]; then
echo "--- BASE (PTS_THREADS=$t)"
PTS_THREADS=$t PTS_HOME=/tmp/h06-base timeout 120 /tmp/h06-base/pts-bin/pts run "$f" 2>&1; echo "[exit=$?]"
fi
if [ -z "$NONODE" ]; then
echo "--- NODE"
if [ -f "$d/$b.oracle.mts" ]; then m="$d/$b.oracle.mts"; else m="$d/$b.mts"; cp "$f" "$m"; fi
ulimit -v unlimited 2>/dev/null
timeout 60 $HOME/.local/node/bin/node --no-warnings --experimental-transform-types "$m" 2>&1; echo "[exit=$?]"
fi
