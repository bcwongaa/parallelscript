# H06a review 3: delta since round 2 (opus-reviewer, claude-opus-5-5)

The tree's code diff hash (`git diff -- pts | sha256sum`) was `6401ab53…a17c` both when I built the CLI (`/tmp/h06/review3/pts`) and when I finished. The helper `/tmp/h06/review3/run3.sh` runs the new CLI, base and Node. The probe archive is `/tmp/h06/review3/h06-review3-probes.tar.gz`, without binaries.

## Verdict

**Ready to commit.** R2-1 is fixed, and the gather shortcut is safe by construction and in practice. The matrix is clean at 2 and 4 threads, and the docs' claims are backed by the code and by my measurements. One note: the archive the `.par` tests cite doesn't exist yet.

## Verified evidence

### R2-1: fixed
`/tmp/h06/review3/probes/r21_variants.pts` matches Node line for line. It covers:
- a typed `sort(req())` whose argument writes `a[0] = 0`: `[ 0, 1, 2 ]`, where it was `[ 1, 2, 3 ]`;
- an optional comparator, both a function and undefined;
- typed `toSorted(cmp)`;
- a comparator that needs an adapter (`(x: number|undefined, …)`);
- an `any` comparator;
- a generic `<T extends Int32Array>` caller;
- receiver-then-comparator logging.

Base rejects two of those lines with PTS1001. Base's result for the original case (`[ 1, 2, 3 ]`) is in round 2's `typed_compare_order_base.pts`.

The new `typed sort` line in `run/copying_methods_argument_order.pts`: Node's output equals the expect block, the test passes on the new CLI and fails on base.

### R2-2: the gather shortcut is safe
**By construction.** `pts_array_gather_sortable` (`array.c:928-930`) returns the length when `!holds_pointers(kind)`. For those kinds:
- `is_hole` is false, since it requires `holds_pointers`;
- `sort_place_of`'s undefined test applies only to `PTS_FIELD_VALUE`.

So the old loop classified every element as compared, stored each in place and also returned the length. The shortcut is equivalent for number, bool, f32 and i8 through u64.

**In practice.** `/tmp/h06/review3/probes/par_int_kinds.pts` runs `.par.sort()` and `.par.sort(cmp)` on:
- `int[]`, `i8[]`, `u8[]`, `i16[]`, `u16[]`, `i32[]`, `u32[]`, `i64[]`, `f32[]` and `boolean[]`;
- sizes 0, 1, 7, 2047, 2049 and 5000;
- digests of every position.

The Node twin declares the types as `number` aliases, and every value stays in its type's range. Result: 84 lines, 0 differences at 1, 2 and 4 threads. `u64[]` isn't in the probe; it is covered by the construction argument.

**A pitfall I hit on the way.** My first version used `(a, b) => a - b`. On `u8`, `i8` and `u16` that subtraction wraps, as SPEC §121–129 specifies: `3 - 5` is 254 as a `u8`. That makes the comparator inconsistent, and its results differ from Node and between thread counts. Base gives byte-identical output, so it's not a sort defect. The probe now uses three-way comparisons. This is worth remembering when writing tests with integer comparators.

### Matrix and tests
- **Matrix:** `gen.pts` (seed 12345) at 2 and 4 threads: 231 lines each, 0 differences from Node.
- **Parent oracles** (`/tmp/h06/parent/oracles/`): each reproduces its test's expect block exactly, for `parallel_sort_undefined`, `parallel_sort_holes` and `parallel_sort_all_or_nothing`. All three tests pass on the new CLI at 1, 2 and 4 threads and fail on base.

### Performance
`bench2.pts`, best of 5 runs inside each program, 1M elements, 4 threads, new and base interleaved ×3:

| Case | New | Base |
|---|---|---|
| Comparator, numbers | 128–133 ms | 110–141 ms |
| Default order, strings | 755–823 ms | 879–921 ms |
| 10% undefined, comparator | 155–160 ms | 163–171 ms |

This is consistent with D-182's known-gaps text: about 12% slower with a comparator and about 13% faster in the default order. My undefined case is within noise of base.

### Docs
I skimmed D-182, C95–C98 in CONSOLIDATED.md and SPEC §9.124. They match the code:
- the frozen rule;
- `(string | null)[]` copies get undefined;
- the typed array's comparator is evaluated before the copy;
- decisions are made by the lowered type;
- the copy and write-back of `.par.sort`, and its performance numbers;
- C98's repro: `probes/shadowed_operand.pts` is in `docs/agent/hardening-evidence/h06-review2-probes.tar.gz`.

## Findings

### R3-1: note. The archive the `.par` tests cite doesn't exist yet
`pts/tests/run/parallel_sort_undefined.pts:7-8`, `parallel_sort_holes.pts:7-8` and `parallel_sort_all_or_nothing.pts:8` cite `oracles/*.oracle.mts` in `docs/agent/hardening-evidence/h06-parent-probes.tar.gz`. That file isn't in the tree yet; the evidence directory holds `h06-baseline`, `h06-reproducer*`, `h06-review*`, `h06-review2-probes` and `h06.md`. The coordinator says it will be archived at commit time; the commit needs it so the comments don't point at nothing.

### R3-2: note, wording
D-182 and SPEC §9.124 say the gather skips "numbers and booleans". The code also skips the integer kinds and f32 (`!holds_pointers`), and that is safe. The code comment says the same as the docs. "numbers (and the integer kinds), booleans" would be exact. Optional.

### R3-3: note, ledger status
C95 still reads "open — H06a". C06 still reads "open — H06". I assume both become fixed at commit time, like the earlier fixed rows (C06 perhaps "fixed — H06a", with H06b covering the rest of the audit).
