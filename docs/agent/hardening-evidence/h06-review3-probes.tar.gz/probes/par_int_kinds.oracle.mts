type int = number; type i8 = number; type i16 = number; type i32 = number; type i64 = number; type u8 = number; type u16 = number; type u32 = number; type u64 = number; type f32 = number;
// .sort on arrays of ParallelScript's integer types, f32 and booleans: no holes, no
// undefined, so the gather returns the length at once. Values stay in each type's range,
// so the Node twin (these types as number aliases) computes the same results.
function digest(label: string, a: number[]): void {
  let h = 7;
  for (let i = 0; i < a.length; i++) {
    const s = String(a[i]);
    for (let j = 0; j < s.length; j++) h = (h * 31 + s.charCodeAt(j)) % 1000000007;
    h = (h * 31 + 44) % 1000000007;
  }
  console.log(label, a.length, h, a.slice(0, 6).join(","), a.slice(a.length - 3).join(","));
}
let seed = 4242;
function next(n: number): number {
  seed = (seed * 48271) % 2147483647;
  return seed % n;
}
for (const n of [0, 1, 7, 2047, 2049, 5000]) {
  const ints: int[] = [];
  const i8s: i8[] = [];
  const u8s: u8[] = [];
  const i16s: i16[] = [];
  const u16s: u16[] = [];
  const i32s: i32[] = [];
  const u32s: u32[] = [];
  const i64s: i64[] = [];
  const f32s: f32[] = [];
  const flags: boolean[] = [];
  for (let i = 0; i < n; i++) {
    ints.push((next(20001) - 10000) as int);
    i8s.push((next(256) - 128) as i8);
    u8s.push((next(256)) as u8);
    i16s.push((next(65536) - 32768) as i16);
    u16s.push((next(65536)) as u16);
    i32s.push((next(2000000001) - 1000000000) as i32);
    u32s.push((next(2000000001)) as u32);
    i64s.push((next(2000000001) - 1000000000) as i64);
    f32s.push(((next(4001) - 2000) / 2) as f32);
    flags.push(next(2) === 0);
  }
  digest("int default " + n, ints.slice().sort());
  digest("int cmp " + n, ints.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  digest("i8 default " + n, i8s.slice().sort());
  digest("i8 cmp " + n, i8s.slice().sort((a, b) => (a < b ? 1 : a > b ? -1 : 0)));
  digest("u8 cmp " + n, u8s.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  digest("i16 default " + n, i16s.slice().sort());
  digest("u16 cmp " + n, u16s.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  digest("i32 cmp " + n, i32s.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  digest("u32 default " + n, u32s.slice().sort());
  digest("i64 cmp " + n, i64s.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  digest("f32 default " + n, f32s.slice().sort());
  digest("f32 cmp " + n, f32s.slice().sort((a, b) => (a < b ? -1 : a > b ? 1 : 0)));
  const fs = flags.slice().sort();
  console.log("bool default " + n, fs.length, fs.indexOf(true), fs.lastIndexOf(false));
  const fc = flags.slice().sort((a, b) => Number(b) - Number(a));
  console.log("bool cmp " + n, fc.length, fc.indexOf(false), fc.lastIndexOf(true));
}
