// R2-1: the comparator expression is evaluated before the typed array's elements are copied.
type C = (a: number, b: number) => number;
const a = new Int32Array([3, 1, 2]);
function req(): C { a[0] = 0; return (x, y) => x - y; }
console.log("sort(req)", a.sort(req()));
const b = new Int32Array([3, 1, 2]);
function opt(): C | undefined { b[0] = 0; return (x, y) => x - y; }
console.log("sort(opt fn)", b.sort(opt()));
const b2 = new Int32Array([3, 1, 2]);
function optU(): C | undefined { b2[0] = 0; return undefined; }
console.log("sort(opt undefined)", b2.sort(optU()));
const c = new Float64Array([3, 1, 2]);
function reqC(): C { c[0] = 0; return (x, y) => y - x; }
console.log("toSorted(req)", c.toSorted(reqC()), c);
const d = new Float64Array([3, 1, 2]);
function adapt(): (x: number | undefined, y: number | undefined) => number { d[0] = 0; return (x, y) => (x ?? 0) - (y ?? 0); }
console.log("sort(adapter)", d.sort(adapt()));
const e: any = new Float64Array([3, 1, 2]);
function anyCmp(): any { return undefined; }
const f = new Uint8Array([3, 1, 2]);
function dyn(): any { f[0] = 0; return (x: number, y: number) => x - y; }
console.log("sort(any fn)", f.sort(dyn()));
function gen<T extends Int32Array>(t: T, mk: () => C): T { return t.sort(mk()) as T; }
const g = new Int32Array([3, 1, 2]);
console.log("generic", gen(g, () => { g[0] = 0; return (x, y) => x - y; }));
const log: string[] = [];
function recv(): Int16Array { log.push("receiver"); return new Int16Array([2, 10, 1]); }
function cmp(): C { log.push("comparator"); return (x, y) => x - y; }
console.log(recv().sort(cmp()), recv().toSorted(cmp()), log);
