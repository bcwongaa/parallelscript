import json
import pathlib
import sys

scratch=pathlib.Path(sys.argv[1]).resolve()
results=json.loads((scratch/"native-results.json").read_text())
cases={case["name"]:case for case in json.loads((scratch/"native-probes/cases.json").read_text())}
corrections=json.loads((scratch/"bind-expectation-corrections.json").read_text())["overrides"]
summary={version:dict(supported_native_matches=0,unsupported_matches=0,pair_checks=0,descriptor_checks=0) for version in ["base","current"]}
normalized=[]
for result in results:
    name=result["name"]
    expected=dict(cases[name])
    expected.update(corrections.get(name,{}))
    row=dict(name=name,correction_applied=name in corrections,versions={})
    for version,data in result["versions"].items():
        diagnostic=expected.get("unchanged_unsupported_diagnostic")
        if diagnostic:
            error=(scratch/"native-probes"/(name+"."+version+".build.err")).read_text()
            assert data["build_rc"]!=0 and diagnostic in error,(name,version,error)
            summary[version]["unsupported_matches"]+=1
            row["versions"][version]=dict(unchanged_unsupported=True)
            continue
        assert data["build_rc"]==0 and data["node_match"] and data["native_stderr_empty"],(name,version,data)
        summary[version]["supported_native_matches"]+=1
        wanted=expected[version]
        if wanted is not None:
            assert data["pairs"]==sorted(wanted),(name,version,data["pairs"],wanted)
            summary[version]["pair_checks"]+=1
            if expected["descriptors"]:
                assert data["registered_pairs"]==sorted(wanted),(name,version,data["registered_pairs"],wanted)
                summary[version]["descriptor_checks"]+=1
        row["versions"][version]=dict(node_match=True,pair_check=None if wanted is None else True,descriptor_check=True if wanted is not None and expected["descriptors"] else None)
    normalized.append(row)
(scratch/"validated-native-results.json").write_text(json.dumps(dict(derivation="Validation of previously executed raw native-results.json; this is not another native execution.",summary=summary,results=normalized),indent=2)+"\n")
print(json.dumps(summary))
