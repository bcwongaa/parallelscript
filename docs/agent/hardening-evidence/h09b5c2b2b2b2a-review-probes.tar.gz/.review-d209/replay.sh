#!/bin/sh
# Run inside an isolated repository containing the frozen five-file patch and
# reviewer-owned inputs. This script does not edit production or commit anything.
# Heavy work stays within two slots; do not run alongside an unrestricted suite.
set -eu
root=${1:?usage: replay.sh ABSOLUTE_REVIEW_WORKTREE}
scratch="$root/.review-d209"
out=$(mktemp -d "$scratch/replay.XXXXXX")
export GOMAXPROCS=1 PTS_HOME="$root"
export PTS_CC="$scratch/serial-clang.sh" D209_COMPILER_LOCK="$scratch/compiler.lock"
chmod +x "$scratch/serial-clang.sh"
python3 -I - "$root" <<'PY'
import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1])
expected=json.loads((root/'.review-d209/final-snapshot-hashes.json').read_text())
actual={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected}
assert actual==expected,(actual,expected)
assert hashlib.sha256((root/'pts/lower/review_d209_alias_test.go').read_bytes()).hexdigest()=='8072b02e51c20133e856a444a5208b70dd26ae4e8ee938a72e9fdc17526b87d3'
PY
git -C "$root" submodule update --init --jobs 1 -- pts/third_party/bdwgc pts/third_party/libbacktrace pts/third_party/libuv pts/third_party/pcre2 pts/third_party/ryu
git -C "$root" show cc17630fb:pts/lower/container_sources.go > "$out/base-container_sources.go"
python3 -I - "$root" "$out" <<'PY'
import json,pathlib,sys
root,out=map(pathlib.Path,sys.argv[1:])
(out/'base-overlay.json').write_text(json.dumps({'Replace':{str(root/'pts/lower/container_sources.go'):str(out/'base-container_sources.go')}},indent=2)+'\n')
PY
go -C "$root" test -count=1 -p 1 -parallel 1 -timeout 10m -json -run '^TestReviewD209' ./pts/lower > "$out/lower-current.jsonl" 2> "$out/lower-current.stderr"
D209_REVIEW_BASE=1 go -C "$root" test -count=1 -p 1 -parallel 1 -timeout 10m -overlay "$out/base-overlay.json" -json -run '^TestReviewD209' ./pts/lower > "$out/lower-base.jsonl" 2> "$out/lower-base.stderr"
GOMAXPROCS=2 go -C "$root" test -count=1 -p 1 -parallel 2 -timeout 15m -json -run '^Test(ContainerAlias|LiteralProjection)' ./pts/lower ./pts/driver > "$out/frozen-focused.jsonl" 2> "$out/frozen-focused.stderr"
go -C "$root" build -p 1 -o "$scratch/strict-current" ./.review-d209/cmd
go -C "$root" build -p 1 -overlay "$out/base-overlay.json" -o "$scratch/strict-base" ./.review-d209/cmd
python3 -I "$scratch/replay_native.py" "$root" native-probes "$out/native" "$scratch/bind-expectation-corrections.json" > "$out/native-run.jsonl"
python3 -I "$scratch/replay_native.py" "$root" capture-probes "$out/capture" > "$out/capture-run.jsonl"
# The GC runner expects the original capture-results Node stdout retained in this
# archive. It writes separately named gc-stress outputs under the scratch dir.
python3 -I "$scratch/gc_stress.py" "$root" > "$out/gc-run.jsonl"
printf 'Replay evidence: %s\n' "$out"
