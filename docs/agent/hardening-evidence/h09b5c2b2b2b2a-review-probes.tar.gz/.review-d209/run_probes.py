import hashlib
import json
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(sys.argv[1]).resolve()
scratch = root / ".review-d209"
cases_dir = scratch / "native-probes"
cases = json.loads((cases_dir / "cases.json").read_text())
env = dict(os.environ, PTS_HOME=str(root), GOMAXPROCS="1", PTS_CC=str(scratch / "serial-clang.sh"), D209_COMPILER_LOCK=str(scratch / "compiler.lock"))
commands = []
results = []

def run(argv, prefix, timeout=180):
    commands.append(dict(argv=list(map(str, argv)), cwd=str(root), env={k:env[k] for k in ["PTS_HOME", "GOMAXPROCS", "PTS_CC", "D209_COMPILER_LOCK"]}))
    try:
        cp = subprocess.run(list(map(str, argv)), env=env, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        rc, stdout, stderr = cp.returncode, cp.stdout, cp.stderr
    except subprocess.TimeoutExpired as e:
        rc, stdout, stderr = 124, e.stdout or b"", (e.stderr or b"") + b"\nREVIEW TIMEOUT\n"
    pathlib.Path(str(prefix) + ".out").write_bytes(stdout)
    pathlib.Path(str(prefix) + ".err").write_bytes(stderr)
    return rc, stdout, stderr

for case in cases:
    name = case["name"]
    node_rc, node_out, node_err = run(["/home/bryan/.local/node/bin/node", "--no-warnings", "--experimental-transform-types", cases_dir / (name+".mts")], cases_dir / (name+".node"))
    result = dict(name=name, node_rc=node_rc, versions={})
    for version in ["base", "current"]:
        prefix = cases_dir / (name+"."+version)
        build_rc, build_out, build_err = run([scratch / ("strict-"+version), "build", cases_dir / (name+".pts"), prefix], pathlib.Path(str(prefix)+".build"))
        c_path = pathlib.Path(str(prefix)+".c")
        data = dict(build_rc=build_rc, c_sha256=None, pairs=None, pair_check=None, descriptor_check=None, native_rc=None, node_match=False)
        if c_path.exists():
            code = c_path.read_text()
            data["c_sha256"] = hashlib.sha256(c_path.read_bytes()).hexdigest()
            stem = "pts_fn_source" if case["kind"] == "function" else "pts_fn_M"
            names = {(value,demand):(f"{stem}{value}_C{demand}(" if case["kind"] == "function" else f"{stem}{value}_make_C{demand}(") for value in range(3) for demand in range(2)}
            actual = sorted([list(pair) for pair,target in names.items() if target in code])
            data["pairs"] = actual
            expected = case[version]
            if expected is not None:
                data["pair_check"] = actual == sorted(expected)
                if case["descriptors"]:
                    registered = sorted([list(pair) for pair,target in names.items() if "return "+target in code])
                    data["registered_pairs"] = registered
                    data["descriptor_check"] = registered == sorted(expected)
        binary = pathlib.Path(str(prefix)+".bin")
        if build_rc == 0:
            native_rc, native_out, native_err = run([binary], prefix, timeout=30)
            data["native_rc"] = native_rc
            data["node_match"] = node_rc == native_rc == 0 and node_out == native_out
            data["native_stderr_empty"] = native_err == b""
        binary.unlink(missing_ok=True)
        result["versions"][version] = data
    result["same_c"] = result["versions"]["base"]["c_sha256"] is not None and result["versions"]["base"]["c_sha256"] == result["versions"]["current"]["c_sha256"]
    results.append(result)
    (scratch / "native-results.json").write_text(json.dumps(results, indent=2)+"\n")
    (scratch / "native-commands.json").write_text(json.dumps(commands, indent=2)+"\n")
    print(json.dumps(result), flush=True)
