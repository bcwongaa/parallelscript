package main

import (
    "context"
    "fmt"
    "os"
    "time"

    "github.com/microsoft/typescript-go/pts/driver"
    "github.com/microsoft/typescript-go/pts/lower"
    "github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
    if len(os.Args) < 4 { fmt.Fprintln(os.Stderr, "usage: strict <emit|build|default> <entry.pts> <output.c> [output.bin]"); os.Exit(2) }
    ctx, cancel := context.WithTimeout(context.Background(), 150*time.Second)
    defer cancel()
    mode, entry, out := os.Args[1], os.Args[2], os.Args[3]
    var code string
    var err error
    if mode == "default" { code, err = driver.EmitC(ctx, entry) } else { code, err = driver.EmitCWith(ctx, entry, lower.AllInstances) }
    if err != nil { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
    if err = os.WriteFile(out, []byte(code), 0644); err != nil { panic(err) }
    fmt.Printf("emitted %d bytes\n", len(code))
    if mode == "build" || mode == "default" {
        if len(os.Args) != 5 { fmt.Fprintln(os.Stderr, "build requires executable output"); os.Exit(2) }
        tc, e := toolchain.New(); if e != nil { panic(e) }
        rt, e := tc.Runtime(ctx, toolchain.Release); if e != nil { panic(e) }
        if e = tc.CompileProgram(ctx, rt, []string{out}, os.Args[4]); e != nil { fmt.Fprintln(os.Stderr, e); os.Exit(1) }
        fmt.Println("compiled exact emitted C")
    }
}
