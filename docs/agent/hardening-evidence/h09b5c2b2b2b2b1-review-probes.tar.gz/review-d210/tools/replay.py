"""Replay reviewer probes serially against a supplied e631cca68-based worktree.
Usage: python3 -I /absolute/archive/review-d210/tools/replay.py /absolute/worktree /absolute/archive/review-d210
This writes only evidence inputs/results and build outputs, never production files.
"""
import pathlib, json, subprocess, sys, os, hashlib

w=pathlib.Path(sys.argv[1]).resolve();e=pathlib.Path(sys.argv[2]).resolve()
env=dict(os.environ,GOMAXPROCS='1')
final='snapshot4' if (e/'results/snapshot4-manifest.json').exists() else 'snapshot3'
manifest=json.loads((e/'results'/f'{final}-manifest.json').read_text())
for rel,want in manifest.items():
    assert hashlib.sha256((e/'inputs'/final/pathlib.Path(rel).name).read_bytes()).hexdigest()==want,rel

def overlay(name,rep):
    path=e/'inputs'/name;path.write_text(json.dumps({'Replace':rep},indent=2)+'\n');return path

def snapshot_rep(label):
    m=json.loads((e/'results'/f'{label}-manifest.json').read_text())
    return {str(w/rel):str(e/'inputs'/label/pathlib.Path(rel).name) for rel in m}

own={str(w/'pts/lower/review_d210_probe_test.go'):str(e/'inputs/proof_test.go')}
final_rep=snapshot_rep(final)|own|{str(w/'pts/lower/review_d210_array_controls_test.go'):str(e/'inputs/array_controls_test.go')}
final_overlay=overlay('replay-final-overlay.json',final_rep)
snapshot3=snapshot_rep('snapshot3')|own
overlay('snapshot3-overlay.json',snapshot3)
snapshot1=snapshot3.copy()
for filename in ('nested_container_sources.go','nested_container_contract_test.go'):
    snapshot1[str(w/'pts/lower'/filename)]=str(e/'inputs/snapshot1'/filename)
overlay('snapshot1-overlay.json',snapshot1)
overlay('base-overlay.json',{str(w/'pts/lower'/n):str(e/'inputs/base'/n) for n in ('container_sources.go','value_flow.go')}|{str(w/'pts/lower/nested_container_sources.go'):''})
arrays=snapshot3|{str(w/'pts/lower/review_d210_array_controls_test.go'):str(e/'inputs/array_controls_test.go')}
array_overlay=overlay('array-controls-overlay.json',arrays)
overlay('mutant-array-overlay.json',arrays|{str(w/'pts/lower/nested_container_sources.go'):str(e/'inputs/mutant_projection.go')})
mutant_final=overlay('mutant-final-overlay.json',final_rep|{str(w/'pts/lower/nested_container_sources.go'):str(e/'inputs/mutant_projection.go')})
commands=[]

def run(name,args,expected=0,timeout=600):
    args=list(map(str,args));commands.append({'name':name,'argv':args,'environment':{'GOMAXPROCS':'1','PTS_HOME':env.get('PTS_HOME','')},'cwd':str(w)})
    print(name,flush=True)
    cp=subprocess.run(args,cwd=w,env=env,capture_output=True,text=True,timeout=timeout)
    (e/'results'/(name+'.stdout')).write_text(cp.stdout);(e/'results'/(name+'.stderr')).write_text(cp.stderr)
    (e/'results/replay-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    assert cp.returncode==expected,(name,cp.returncode,cp.stdout[-3000:],cp.stderr[-3000:])
    return cp

def gotest(ov,pattern,packages):
    return ['go','-C',w,'test','-overlay',ov,'-count=1','-json','-p','1','-parallel','1','-timeout','8m',*packages,'-run',pattern]

pattern='^(TestNestedContainer|TestReviewD210(IndependentTrees|LateSideUses|CrossKindBudgetAndMemo|ArrayFixtureControls))'
run('replay-final-focused',gotest(final_overlay,pattern,['./pts/lower','./pts/driver']))
run('replay-build-helper',['go','-C',w,'build','-overlay',final_overlay,'-p','1','-o',e/'tools/strict-bin',e/'tools/strict.go'])
run('replay-native',['python3','-I',e/'tools/run_native.py',w,e])
run('replay-comparison',['python3','-I',e/'tools/compare.py',w,e])
red=run('replay-original-array-control-expected-red',gotest(array_overlay,'^TestReviewD210OriginalArrayFixtureShouldBeKnown$',['./pts/lower']),expected=1)
assert '--- FAIL: TestReviewD210OriginalArrayFixtureShouldBeKnown' in red.stdout and 'assertion failed' in red.stdout
run('replay-typed-array-control-green',gotest(array_overlay,'^TestReviewD210ArrayFixtureControls$',['./pts/lower']))
if final=='snapshot4':
    red=run('replay-final-mutant-expected-red',gotest(mutant_final,'^TestNestedContainerArraysRejectIntermediateEscapeAndMutation$',['./pts/lower']),expected=1)
    assert '--- FAIL' in red.stdout and 'assertion failed' in red.stdout
print('All replay assertions satisfied, including intentionally RED controls.',flush=True)
