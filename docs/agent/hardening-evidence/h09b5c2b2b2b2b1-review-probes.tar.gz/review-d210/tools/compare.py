import pathlib, json, subprocess, os, sys

work=pathlib.Path(sys.argv[1]).resolve(); e=pathlib.Path(sys.argv[2]).resolve()
r=e/'results/comparison';r.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,GOMAXPROCS='1')
commands=[]
def run(name,args,timeout=300,extraenv=None):
    commands.append({'name':name,'argv':list(map(str,args)),'cwd':str(work),'environment':{'GOMAXPROCS':'1','PTS_HOME':env.get('PTS_HOME',''),**(extraenv or {})}})
    print(name,flush=True)
    cp=subprocess.run(list(map(str,args)),capture_output=True,text=True,cwd=work,env=dict(env,**(extraenv or {})),timeout=timeout)
    (r/(name+'.stdout')).write_text(cp.stdout);(r/(name+'.stderr')).write_text(cp.stderr)
    (r/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    return cp
base=e/'tools/strict-base-bin'
cp=run('build-base',['go','-C',work,'build','-overlay',e/'inputs/base-overlay.json','-p','1','-o',base,e/'tools/strict.go'])
assert cp.returncode==0,cp.stderr
matrices=[]
for case in json.loads((e/'cases/manifest.json').read_text()):
    name=case['name'];output=r/(name+'.base.c')
    cp=run(name+'-emit-base',[base,'emit',e/'cases'/(name+'.pts'),output])
    assert cp.returncode==0,cp.stderr
    basec=output.read_text();now=(e/'results/native'/(name+'.c')).read_text()
    expected_current=9 if case['unsafe'] else 3
    base_count=current_count=0
    for value in range(3):
        for demand in range(3):
            target=f'pts_fn_source{value}_C{demand}(' if case['kind']=='function' else f'pts_fn_M{value}_make_C{demand}('
            assert target in basec,(name,target,'base missing')
            base_count+=target in basec;current_count+=target in now
    assert base_count==9 and current_count==expected_current,(name,base_count,current_count)
    matrices.append({'name':name,'base_pairs':base_count,'current_pairs':current_count})
cp=run('snapshot1-readonly-expected-red',['go','-C',work,'test','-overlay',e/'inputs/snapshot1-overlay.json','-count=1','-json','-p','1','-parallel','1','-timeout','5m','./pts/lower','-run','^TestReviewD210IndependentTrees/false/readonly_common_element$'])
assert cp.returncode==1 and 'unsupported whole-tree contract remains unknown' in cp.stdout and '--- FAIL' in cp.stdout,cp.stdout+cp.stderr
cp=run('snapshot3-readonly-green',['go','-C',work,'test','-overlay',e/'inputs/snapshot3-overlay.json','-count=1','-json','-p','1','-parallel','1','-timeout','5m','./pts/lower','-run','^TestReviewD210IndependentTrees/false/readonly_common_element$'])
assert cp.returncode==0,cp.stdout+cp.stderr
cp=run('snapshot3-driver-focused',['go','-C',work,'test','-overlay',e/'inputs/snapshot3-overlay.json','-count=1','-json','-p','1','-parallel','1','-timeout','5m','./pts/driver','-run','^TestNestedContainer'])
assert cp.returncode==0,cp.stdout+cp.stderr
for label,helper in [('base',base),('snapshot3',e/'tools/strict-bin')]:
    binary=r/('captures-'+label+'.bin');c=r/('captures-'+label+'.c')
    cp=run('captures-'+label+'-build',[helper,'build',e/'cases/captures.pts',c,binary])
    assert cp.returncode==0,cp.stdout+cp.stderr
    cp=run('captures-'+label+'-gc',[binary],extraenv={'GC_PRINT_STATS':'1'})
    assert cp.returncode==0,cp.stdout+cp.stderr
    assert cp.stdout==(e/'results/native/captures.node.stdout').read_text(),cp.stdout
    binary.unlink()
(r/'summary.json').write_text(json.dumps({'matrices':matrices,'readonly_snapshot1_expected_red':True,'readonly_snapshot3_green':True,'driver_final_green':True,'captures_baseline_and_final_stdout_match':True},indent=2)+'\n')
print(json.dumps({'matrices':matrices,'all_expected':True}),flush=True)
