import pathlib, json, sys

root = pathlib.Path(sys.argv[1])
root.mkdir(parents=True, exist_ok=True)
cases = []
for kind in ('function', 'receiver', 'captured_receiver', 'wrapper'):
    for unsafe in (False, True):
        source = [
            'class Box<T> { constructor(public value:T){} }',
            'type Factory = <T>(value:T)=>Box<T>;',
            'interface Maker { make<T>(value:T):Box<T>; }',
        ]
        for i in range(3):
            source += [
                f'class C{i} {{ tag={i}; }}',
                f'function source{i}<T>(value:T):Box<T>{{return new Box(value);}}',
                f'class M{i} implements Maker {{ calls=0; make<T>(value:T):Box<T>{{this.calls++;console.log("M{i}",this.calls);return new Box(value);}} }}',
                f'function use{i}(value:{"Maker" if kind=="receiver" else "Factory"}):void{{const box:Box<C{i}> = '+('value.make' if kind=='receiver' else 'value')+f'(new C{i}());console.log("demand",box.value.tag);}}',
            ]
            if kind=='captured_receiver':
                source += [f'function read{i}(value:Maker):Factory{{return value.make.bind(value);}}']
            if kind=='wrapper':
                source += [f'function read{i}():Factory{{const value:Maker=new M{i}();return value.make.bind(value);}}']
        for i in range(3):
            typ='Maker' if kind in ('receiver','captured_receiver') else 'Factory'
            selected=f'source{i}' if kind=='function' else (f'read{i}()' if kind=='wrapper' else f'new M{i}()')
            other=f'source{(i+1)%3}' if kind=='function' else (f'read{(i+1)%3}()' if kind=='wrapper' else f'new M{(i+1)%3}()')
            source += [f'const selected{i}:{typ}={selected};const other{i}:{typ}={other};',
                       f'const root{i}=[{{row:{{items:[{{value:selected{i},other:other{i}}}]}}}}];',
                       f'const alias{i}=root{i};const sibling{i}=alias{i};']
            if unsafe:
                source += [f'function escape{i}(part:{{value:{typ};other:{typ}}}):void{{part.value=part.other;}}escape{i}(sibling{i}[0].row.items[0]);']
            expr=f'alias{i}[0].row.items[0].value'
            if kind=='captured_receiver': expr=f'read{i}({expr})'
            source += [f'use{i}({expr});']
        name=kind+('_escaped' if unsafe else '_closed')
        path=root/(name+'.pts')
        text='\n'.join(source)+'\n'
        path.write_text(text)
        path.with_suffix('.mts').write_text(text)
        cases.append({'name':name,'kind':kind,'unsafe':unsafe})
(root/'manifest.json').write_text(json.dumps(cases,indent=2)+'\n')
print(json.dumps({'cases':len(cases),'dir':str(root)}))
