import pathlib, json, subprocess, os, sys, re

work = pathlib.Path(sys.argv[1]).resolve()
evidence = pathlib.Path(sys.argv[2]).resolve()
helper = evidence/'tools/strict-bin'
results = evidence/'results/native'
results.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,GOMAXPROCS='1')
records=[]
cases=json.loads((evidence/'cases/manifest.json').read_text())+[{'name':'captures','kind':None,'unsafe':None}]
for case in cases:
    name=case['name']; source=evidence/'cases'/(name+'.pts')
    c=results/(name+'.c'); binary=results/(name+'.bin')
    print('BUILD '+name,flush=True)
    record=dict(case)
    try:
        built=subprocess.run([str(helper),'build',str(source),str(c),str(binary)],capture_output=True,text=True,env=env,timeout=200)
        (results/(name+'.build.stdout')).write_text(built.stdout);(results/(name+'.build.stderr')).write_text(built.stderr)
        record['build_status']=built.returncode
        if built.returncode==0:
            native=subprocess.run([str(binary)],capture_output=True,text=True,timeout=35,env=env)
            record['native_status']=native.returncode
            (results/(name+'.native.stdout')).write_text(native.stdout);(results/(name+'.native.stderr')).write_text(native.stderr)
            node=subprocess.run([str(pathlib.Path.home()/'.local/node/bin/node'),str(source.with_suffix('.mts'))],capture_output=True,text=True,timeout=35,env=env)
            record['node_status']=node.returncode
            (results/(name+'.node.stdout')).write_text(node.stdout);(results/(name+'.node.stderr')).write_text(node.stderr)
            record['stdout_match']=native.stdout==node.stdout
            if case['kind']:
                text=c.read_text(); prefix='source' if case['kind']=='function' else 'M'
                pair_results=[]
                for value in range(3):
                    for demand in range(3):
                        target=f'pts_fn_source{value}_C{demand}(' if case['kind']=='function' else f'pts_fn_M{value}_make_C{demand}('
                        present=target in text; required=case['unsafe'] or value==demand
                        pair_results.append({'value':value,'demand':demand,'present':present,'required':required,'registered':('return '+target) in text})
                record['pairs']=pair_results
                record['target_matrix_ok']=all(p['present']==p['required'] for p in pair_results)
                if case['kind']!='function':record['descriptor_target_matrix_ok']=all(p['registered']==p['required'] for p in pair_results)
                wrappers=re.findall(r'(?m)^static [^\n]*\bpts_instance_closure_(read\d_[A-Za-z_]+)_([0-9]+)\(pts_closure \*pts_env, pts_class_C([0-9]+) \*a1\)',text)
                record['wrapper_signatures']=[{'site':site,'instance':int(instance),'demand':int(demand)} for site,instance,demand in wrappers]
                record['wrapper_tables']=sorted(set(re.findall(r'\.instances = (pts_instances_closure_read\d_[A-Za-z_]+),',text)))
        if binary.exists():binary.unlink()
    except subprocess.TimeoutExpired as exc:
        record['timeout']=str(exc)
        if binary.exists():binary.unlink()
    records.append(record)
    (results/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps({k:v for k,v in record.items() if k not in ('pairs','wrapper_signatures')}),flush=True)
failed=[r for r in records if r.get('build_status')!=0 or r.get('native_status')!=0 or r.get('node_status')!=0 or not r.get('stdout_match') or not r.get('target_matrix_ok',True) or not r.get('descriptor_target_matrix_ok',True)]
print(json.dumps({'cases':len(records),'failed':[r['name'] for r in failed]}),flush=True)
sys.exit(bool(failed))
