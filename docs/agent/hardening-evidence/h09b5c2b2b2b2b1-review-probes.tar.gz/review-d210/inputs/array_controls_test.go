package lower

import (
  "testing"
  "gotest.tools/v3/assert"
)

func TestReviewD210ArrayFixtureControls(t *testing.T) {
  const origin="const root={branch:[first,second],plain:first};const alias=root;const other=alias;"
  for _,typed:=range []bool{false,true} {
    prelude:=literalProjectionPrelude(false)
    if typed { prelude=nestedContainerPrelude(false) }
    l,probe:=valueFlowProbe(t,prelude+origin+"const probe=other.branch[0];probe;")
    steps:=maxValueFlowSteps
    sources:=l.valueSources(probe,&steps,0)
    if !typed { assert.Assert(t,sources==nil,"the supplied negative-array fixture is already unknown without any unsafe use");t.Log("original fixture: unmodified array control is unknown") } else { assert.DeepEqual(t,returnedSourceNames(sources),[]string{"first"});t.Log("shared-Value fixture: unmodified control resolves first") }
  }
  for _,use:=range []string{
    "other.branch[0]=second;", "other.branch.reverse();", "other.branch.length=0;", "const ignored=other.branch.length;",
    "let index=0;const ignored=other.branch[index];", "consume(other.branch);", "const copied=[...other.branch];",
    "const extracted=other.branch;", "const extracted:unknown=other.branch;", "const extracted=other.branch as Value[];",
  } {
    t.Run(use,func(t *testing.T){
      l,probe:=valueFlowProbe(t,nestedContainerPrelude(false)+origin+use+"const probe=other.branch[0];probe;")
      steps:=maxValueFlowSteps
      assert.Assert(t,l.valueSources(probe,&steps,0)==nil,"a supported immutable array must lose its proof after the unsafe use")
    })
  }
}

// This deliberately fails against the supplied fixture, demonstrating a missing
// positive control in TestNestedContainerArraysRejectIntermediateEscapeAndMutation.
func TestReviewD210OriginalArrayFixtureShouldBeKnown(t *testing.T) {
  l,probe:=valueFlowProbe(t,literalProjectionPrelude(false)+"const root={branch:[first,second],plain:first};const alias=root;const other=alias;const probe=other.branch[0];probe;")
  steps:=maxValueFlowSteps
  assert.DeepEqual(t,returnedSourceNames(l.valueSources(probe,&steps,0)),[]string{"first"})
}
