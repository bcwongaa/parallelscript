#!/bin/bash
# cg.sh relpath: callgrind instruction counts of emit-c, fix vs base
rel=$1; key=$(echo $rel | tr '/' '_'); O=/tmp/h09b4b2/review1/cg
for which in fix base; do
  if [ $which = fix ]; then home=/tmp/h09b4b2/s/snap1; else home=/tmp/h09b4b2/base; fi
  ( cd $(dirname /tmp/h09b4b2/s/snap1/$rel) && GOMAXPROCS=1 PTS_HOME=$home valgrind --tool=callgrind --callgrind-out-file=/dev/null $home/pts-bin/pts emit-c $(basename $rel) -o /dev/null 2>&1 | grep -E "Collected" | sed "s/^/$which $key /" ) >> $O/counts.txt
done
