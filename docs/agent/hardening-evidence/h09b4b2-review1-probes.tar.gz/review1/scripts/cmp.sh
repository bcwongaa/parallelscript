#!/bin/bash
# usage: cmp.sh file.pts  -> prints node / fix / base outputs
f="$1"; name=$(basename "$f" .pts); d=/tmp/h09b4b2/review1
out=$d/out/$name; mkdir -p $out
cp "$f" $out/$name.mts
( cd $out && TZ=America/New_York timeout 20 ~/.local/node/bin/node --no-warnings --experimental-transform-types $name.mts > node.txt 2>&1; echo "exit=$?" >> node.txt )
for which in fix base; do
  if [ $which = fix ]; then home=/tmp/h09b4b2/s/snap1; else home=/tmp/h09b4b2/base; fi
  bin=$d/bin/$name.$which.bin
  PTS_HOME=$home timeout 300 $home/pts-bin/pts build "$f" -o $bin > $out/$which.txt 2>&1
  rc=$?
  if [ $rc -eq 0 ]; then
    ( cd $out && TZ=America/New_York timeout 20 $bin >> $out/$which.txt 2>&1; echo "exit=$?" >> $out/$which.txt )
  else
    echo "BUILD exit=$rc" >> $out/$which.txt
  fi
  rm -f $bin
done
for which in node fix base; do echo "=== $which"; cat $out/$which.txt; done
