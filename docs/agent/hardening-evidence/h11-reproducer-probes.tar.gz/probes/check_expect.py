"""Build each run test with pts, run it, and compare stdout with its `// expect:` block.

Usage: python3 -I check_expect.py [--unskip] file.pts...
Prints PASS or FAIL per file and, on FAIL, a unified diff (expected -> pts). --unskip
builds a copy without its `// skip:` line (in /tmp/h11/repro/bin).
"""

import difflib
import os
import subprocess
import sys

W = "/home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83"
BIN = "/tmp/h11/repro/bin"


def expected(text):
    lines, inside = [], False
    for line in text.split("\n"):
        if line.strip() == "// expect:":
            inside = True
            continue
        if inside:
            if not line.startswith("//"):
                break
            body = line[2:]
            lines.append(body[1:] if body.startswith(" ") else body)
    return "\n".join(lines) + "\n" if lines else ""


def main():
    args = sys.argv[1:]
    unskip = "--unskip" in args
    files = [a for a in args if a != "--unskip"]
    env = dict(os.environ, TZ="America/New_York", PTS_HOME=W)
    for path in files:
        text = open(path).read()
        source = path
        if unskip:
            source = os.path.join(BIN, os.path.basename(path))
            with open(source, "w") as f:
                f.write("\n".join(l for l in text.split("\n") if not l.startswith("// skip:")))
        binary = os.path.join(BIN, os.path.basename(path) + ".bin")
        b = subprocess.run([os.environ.get("PTS_BIN", W + "/pts-bin/pts"), "build", source, "-o", binary], capture_output=True, env=env)
        if b.returncode != 0:
            print("FAIL (build exit {})".format(b.returncode), path)
            print((b.stdout + b.stderr).decode()[:3000])
            continue
        r = subprocess.run([binary], capture_output=True, env=env, timeout=60)
        os.remove(binary)
        if unskip:
            os.remove(source)
        out = r.stdout.decode("utf-8", "replace")
        want = expected(text)
        if out == want and r.returncode == 0:
            print("PASS", path)
            continue
        print("FAIL (exit {})".format(r.returncode), path)
        sys.stdout.writelines(difflib.unified_diff(want.splitlines(True), out.splitlines(True), "expect", "pts"))
        err = r.stderr.decode("utf-8", "replace").strip()
        if err:
            print("stderr:", err[:1500])


if __name__ == "__main__":
    main()
