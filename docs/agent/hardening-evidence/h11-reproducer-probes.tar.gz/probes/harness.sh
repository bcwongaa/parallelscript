#!/bin/bash
# Runs named run tests through the real harness (TestRun and TestRunMatchesNode).
# usage: harness.sh name1 name2 ...
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83 || exit 1
names=$(IFS='|'; echo "$*")
export PATH="$HOME/.local/node/bin:$HOME/.local/go/bin:$PATH" PTS_REQUIRE_NODE=1 GOMAXPROCS=2
go test ./pts/tests/ -count=1 -timeout 40m -run "TestRun(MatchesNode)?/($names)\$" -v 2>&1 |
  grep -E "^(=== RUN|\s*--- |PASS|FAIL|ok)" | grep -v "=== RUN"
