#!/bin/bash
# usage: run1.sh file.pts [more.pts...] -> prints Node's and pts's outputs for each file
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83
for f in "$@"; do
  base="${f%.pts}"
  echo "##### $f"
  cp -- "$f" "$base.mts"
  echo "=== node"
  TZ=America/New_York ~/.local/node/bin/node --no-warnings --experimental-transform-types "$base.mts" 2>&1
  echo "[node exit=$?]"
  echo "=== pts"
  TZ=America/New_York PTS_HOME="$W" "$W/pts-bin/pts" build "$f" -o "/tmp/h11/repro/bin/$(basename "$base").bin" 2>&1
  b=$?
  if [ $b -eq 0 ]; then
    TZ=America/New_York "/tmp/h11/repro/bin/$(basename "$base").bin" 2>&1
    echo "[pts exit=$?]"
  else
    echo "[pts build exit=$b]"
  fi
  rm -f -- "$base.mts" "/tmp/h11/repro/bin/$(basename "$base").bin"
done
