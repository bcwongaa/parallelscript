#!/bin/bash
# usage: node1.sh file.pts [more.pts...] -> Node's output for each file, from an .mts copy
for f in "$@"; do
  base="${f%.pts}"
  echo "##### $f"
  cp -- "$f" "$base.mts"
  TZ=America/New_York ~/.local/node/bin/node --no-warnings --experimental-transform-types "$base.mts" 2>&1
  echo "[node exit=$?]"
  rm -f -- "$base.mts"
done
