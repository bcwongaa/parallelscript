#!/bin/bash
# Builds the perf probes, checks each prints what Node prints, and measures them:
# callgrind instruction counts (Ir) and hyperfine wall times. Binaries are deleted after.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83
PTS="${PTS_BIN:-$W/pts-bin/pts}"
D="${PERF_DIR:-/tmp/h11/repro/perf}"

mkdir -p "$D"
names="perf_loose_decl perf_typed_index perf_forof_pattern perf_param_pattern"
for n in $names; do
  PTS_HOME="$W" "$PTS" build "/tmp/h11/repro/probes/$n.pts" -o "$D/$n.bin" || exit 1
  cp "/tmp/h11/repro/probes/$n.pts" "$D/$n.mts"
  echo "$n pts=$("$D/$n.bin") node=$(~/.local/node/bin/node --no-warnings --experimental-transform-types "$D/$n.mts")"
  rm -f "$D/$n.mts"
done
for n in $names; do
  valgrind --tool=callgrind --callgrind-out-file="$D/$n.callgrind" "$D/$n.bin" > /dev/null 2> "$D/$n.vg"
  echo "$n Ir=$(grep -o 'Collected : [0-9]*' "$D/$n.vg" | grep -o '[0-9]*')"
  rm -f "$D/$n.callgrind"
done
cd "$D" && hyperfine -N -w 2 -r 15 ./perf_loose_decl.bin ./perf_typed_index.bin ./perf_forof_pattern.bin ./perf_param_pattern.bin 2>&1 | grep -E "Benchmark|Time|±"
for n in $names; do rm -f "$D/$n.bin"; done
