#!/bin/bash
# TestCompilerFailsCleanly over the new tests only (and 3 mutants each).
cd /home/bryan/projects/parallelscript/.claude/worktrees/agent-ab8a9f5ac0c519f83 || exit 1
export PATH="$HOME/.local/go/bin:$PATH" GOMAXPROCS=2 PTS_SMOKE_MUTANTS=3 PTS_SMOKE_JOBS=3
export PTS_SMOKE_FILTER='(loose_locals_undefined_destinations|loose_locals_required_destinations|loose_locals_declared_shorthand|pattern_names_past_end_parameters|pattern_names_past_end_for_of|pattern_names_past_end_nested|array_pattern_defaults_at_holes|array_pattern_defaults_maybe_elements|array_patterns_typed_sources|optional_callback_parameters_at_holes|find_shrinking_array|element_reads_unknown_contexts|element_reads_required_places|for_of_reads_holes_typed)\.pts'
go test ./pts/tests/ -count=1 -timeout 40m -run 'TestCompilerFailsCleanly$' -v 2>&1 | grep -E "^(\s*--- |PASS|FAIL|ok)|compiled|programs|mutant" | head -20
