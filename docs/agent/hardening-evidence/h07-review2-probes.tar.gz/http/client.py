# Drives http/signals_every_loop.pts as TestHTTPServerSignalsEveryLoop does, but reports instead of stopping at the first failure.
import collections, concurrent.futures, http.client, os, socket, subprocess, sys, time
exe, threads = sys.argv[1], sys.argv[2]
p = subprocess.Popen([exe], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=dict(os.environ, PTS_THREADS=threads), text=True)
port = int(p.stdout.readline().split()[1])
def get(path):
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    c.request("GET", path, headers={"Connection": "close"})
    body = c.getresponse().read().decode()
    c.close()
    return body
with concurrent.futures.ThreadPoolExecutor(16) as ex:
    ok = collections.Counter(ex.map(lambda i: get("/"), range(800)))
    timeouts = collections.Counter(ex.map(lambda i: get("/timeout"), range(64)))
socks = []
for i in range(16):
    s = socket.create_connection(("127.0.0.1", port)); s.sendall(b"GET /hold HTTP/1.1\r\nHost: a\r\n\r\n"); socks.append(s)
deadline = time.time() + 5
while time.time() < deadline and get("/count").split()[0] != "16":
    time.sleep(0.01)
arrived = get("/count")
for s in socks:
    s.close()
deadline = time.time() + 5
while time.time() < deadline and get("/count") != "16 16":
    time.sleep(0.01)
final = get("/count")
get("/stop")
try:
    out, err = p.communicate(timeout=15)
except subprocess.TimeoutExpired:
    p.kill(); out, err = p.communicate(); print("hung")
print(f"threads={threads} ok={dict(ok)} timeout={dict(timeouts)} arrived={arrived!r} final={final!r} exit={p.returncode} stderr_lines={len(err.splitlines())}")
