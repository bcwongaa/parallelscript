// C120's scope: a plain unref'd setTimeout in a `parallel` task (no AbortSignal), while the
// main loop's ref'd timer keeps the program running. Node's twin: `parallel e` as `Promise.resolve(e)`.
function waitUnref(ms: number): Promise<string> {
  return new Promise((resolve) => {
    setTimeout(() => resolve("fired"), ms).unref();
  });
}
const keepAlive = setTimeout(() => console.log("a task's unref'd timer never fired"), 2_000);
const results = await Promise.all([0, 1, 2, 3].map((i) => Promise.resolve(waitUnref(20 + i))));
clearTimeout(keepAlive);
console.log(results.join(","));
