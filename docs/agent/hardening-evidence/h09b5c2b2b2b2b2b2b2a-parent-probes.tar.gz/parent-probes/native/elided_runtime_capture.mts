class Box<T> { constructor(public value: T) {} }
interface Factory { <T>(value: T): Box<T>; }
interface Maker { make<T>(value: T): Box<T>; }
class C0 { tag = 0; }
class C1 { tag = 1; }
class C2 { tag = 2; }
class M0 implements Maker {
  state = "left";
  calls = 0;
  make<T>(value: T): Box<T> {
    this.calls++;
    console.log("m0", this.state, this.calls);
    return new Box(value);
  }
}
class M1 implements Maker {
  state = "right";
  calls = 0;
  make<T>(value: T): Box<T> {
    this.calls++;
    console.log("m1", this.state, this.calls);
    return new Box(value);
  }
}
function read(receiver: Maker): Factory { return receiver.make.bind(receiver); }
function use0(factory: Factory): void { console.log(factory(new C0()).value.tag); }
function use1(factory: Factory): void { console.log(factory(new C1()).value.tag); }
function use2(factory: Factory): void { console.log(factory(new C2()).value.tag); }
const leftObject = new M0();
const rightObject = new M1();
const left: Maker = leftObject;
const right: Maker = rightObject;
const root = { rows: [{ value: left }, { value: right }, { value: left }, { value: right }], skipped: [1, 2] };
const { rows: [, selected, , sibling], skipped: [, ,] } = root;
const alias = selected;
const captured = read(alias.value);
rightObject.state = "changed";
use0(captured);
use1(read(sibling.value));
use2(read(root.rows[0].value));

// expect:
// m1 changed 1
// 0
// m1 changed 2
// 1
// m0 left 1
// 2
