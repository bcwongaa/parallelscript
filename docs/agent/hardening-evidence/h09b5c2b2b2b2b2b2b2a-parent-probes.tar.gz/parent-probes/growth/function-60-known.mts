class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(factory: Factory): void { const box: Box<C0> = factory(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(factory: Factory): void { const box: Box<C1> = factory(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(factory: Factory): void { const box: Box<C2> = factory(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(factory: Factory): void { const box: Box<C3> = factory(new C3()); console.log(box.value.tag); }
class C4 { tag = 4; }
function source4<T>(value: T): Box<T> { return new Box(value); }
class M4 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use4(factory: Factory): void { const box: Box<C4> = factory(new C4()); console.log(box.value.tag); }
class C5 { tag = 5; }
function source5<T>(value: T): Box<T> { return new Box(value); }
class M5 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use5(factory: Factory): void { const box: Box<C5> = factory(new C5()); console.log(box.value.tag); }
class C6 { tag = 6; }
function source6<T>(value: T): Box<T> { return new Box(value); }
class M6 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use6(factory: Factory): void { const box: Box<C6> = factory(new C6()); console.log(box.value.tag); }
class C7 { tag = 7; }
function source7<T>(value: T): Box<T> { return new Box(value); }
class M7 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use7(factory: Factory): void { const box: Box<C7> = factory(new C7()); console.log(box.value.tag); }
class C8 { tag = 8; }
function source8<T>(value: T): Box<T> { return new Box(value); }
class M8 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use8(factory: Factory): void { const box: Box<C8> = factory(new C8()); console.log(box.value.tag); }
class C9 { tag = 9; }
function source9<T>(value: T): Box<T> { return new Box(value); }
class M9 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use9(factory: Factory): void { const box: Box<C9> = factory(new C9()); console.log(box.value.tag); }
class C10 { tag = 10; }
function source10<T>(value: T): Box<T> { return new Box(value); }
class M10 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use10(factory: Factory): void { const box: Box<C10> = factory(new C10()); console.log(box.value.tag); }
class C11 { tag = 11; }
function source11<T>(value: T): Box<T> { return new Box(value); }
class M11 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use11(factory: Factory): void { const box: Box<C11> = factory(new C11()); console.log(box.value.tag); }
class C12 { tag = 12; }
function source12<T>(value: T): Box<T> { return new Box(value); }
class M12 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use12(factory: Factory): void { const box: Box<C12> = factory(new C12()); console.log(box.value.tag); }
class C13 { tag = 13; }
function source13<T>(value: T): Box<T> { return new Box(value); }
class M13 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use13(factory: Factory): void { const box: Box<C13> = factory(new C13()); console.log(box.value.tag); }
class C14 { tag = 14; }
function source14<T>(value: T): Box<T> { return new Box(value); }
class M14 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use14(factory: Factory): void { const box: Box<C14> = factory(new C14()); console.log(box.value.tag); }
class C15 { tag = 15; }
function source15<T>(value: T): Box<T> { return new Box(value); }
class M15 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use15(factory: Factory): void { const box: Box<C15> = factory(new C15()); console.log(box.value.tag); }
class C16 { tag = 16; }
function source16<T>(value: T): Box<T> { return new Box(value); }
class M16 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use16(factory: Factory): void { const box: Box<C16> = factory(new C16()); console.log(box.value.tag); }
class C17 { tag = 17; }
function source17<T>(value: T): Box<T> { return new Box(value); }
class M17 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use17(factory: Factory): void { const box: Box<C17> = factory(new C17()); console.log(box.value.tag); }
class C18 { tag = 18; }
function source18<T>(value: T): Box<T> { return new Box(value); }
class M18 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use18(factory: Factory): void { const box: Box<C18> = factory(new C18()); console.log(box.value.tag); }
class C19 { tag = 19; }
function source19<T>(value: T): Box<T> { return new Box(value); }
class M19 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use19(factory: Factory): void { const box: Box<C19> = factory(new C19()); console.log(box.value.tag); }
class C20 { tag = 20; }
function source20<T>(value: T): Box<T> { return new Box(value); }
class M20 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use20(factory: Factory): void { const box: Box<C20> = factory(new C20()); console.log(box.value.tag); }
class C21 { tag = 21; }
function source21<T>(value: T): Box<T> { return new Box(value); }
class M21 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use21(factory: Factory): void { const box: Box<C21> = factory(new C21()); console.log(box.value.tag); }
class C22 { tag = 22; }
function source22<T>(value: T): Box<T> { return new Box(value); }
class M22 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use22(factory: Factory): void { const box: Box<C22> = factory(new C22()); console.log(box.value.tag); }
class C23 { tag = 23; }
function source23<T>(value: T): Box<T> { return new Box(value); }
class M23 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use23(factory: Factory): void { const box: Box<C23> = factory(new C23()); console.log(box.value.tag); }
class C24 { tag = 24; }
function source24<T>(value: T): Box<T> { return new Box(value); }
class M24 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use24(factory: Factory): void { const box: Box<C24> = factory(new C24()); console.log(box.value.tag); }
class C25 { tag = 25; }
function source25<T>(value: T): Box<T> { return new Box(value); }
class M25 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use25(factory: Factory): void { const box: Box<C25> = factory(new C25()); console.log(box.value.tag); }
class C26 { tag = 26; }
function source26<T>(value: T): Box<T> { return new Box(value); }
class M26 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use26(factory: Factory): void { const box: Box<C26> = factory(new C26()); console.log(box.value.tag); }
class C27 { tag = 27; }
function source27<T>(value: T): Box<T> { return new Box(value); }
class M27 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use27(factory: Factory): void { const box: Box<C27> = factory(new C27()); console.log(box.value.tag); }
class C28 { tag = 28; }
function source28<T>(value: T): Box<T> { return new Box(value); }
class M28 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use28(factory: Factory): void { const box: Box<C28> = factory(new C28()); console.log(box.value.tag); }
class C29 { tag = 29; }
function source29<T>(value: T): Box<T> { return new Box(value); }
class M29 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use29(factory: Factory): void { const box: Box<C29> = factory(new C29()); console.log(box.value.tag); }
class C30 { tag = 30; }
function source30<T>(value: T): Box<T> { return new Box(value); }
class M30 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use30(factory: Factory): void { const box: Box<C30> = factory(new C30()); console.log(box.value.tag); }
class C31 { tag = 31; }
function source31<T>(value: T): Box<T> { return new Box(value); }
class M31 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use31(factory: Factory): void { const box: Box<C31> = factory(new C31()); console.log(box.value.tag); }
class C32 { tag = 32; }
function source32<T>(value: T): Box<T> { return new Box(value); }
class M32 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use32(factory: Factory): void { const box: Box<C32> = factory(new C32()); console.log(box.value.tag); }
class C33 { tag = 33; }
function source33<T>(value: T): Box<T> { return new Box(value); }
class M33 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use33(factory: Factory): void { const box: Box<C33> = factory(new C33()); console.log(box.value.tag); }
class C34 { tag = 34; }
function source34<T>(value: T): Box<T> { return new Box(value); }
class M34 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use34(factory: Factory): void { const box: Box<C34> = factory(new C34()); console.log(box.value.tag); }
class C35 { tag = 35; }
function source35<T>(value: T): Box<T> { return new Box(value); }
class M35 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use35(factory: Factory): void { const box: Box<C35> = factory(new C35()); console.log(box.value.tag); }
class C36 { tag = 36; }
function source36<T>(value: T): Box<T> { return new Box(value); }
class M36 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use36(factory: Factory): void { const box: Box<C36> = factory(new C36()); console.log(box.value.tag); }
class C37 { tag = 37; }
function source37<T>(value: T): Box<T> { return new Box(value); }
class M37 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use37(factory: Factory): void { const box: Box<C37> = factory(new C37()); console.log(box.value.tag); }
class C38 { tag = 38; }
function source38<T>(value: T): Box<T> { return new Box(value); }
class M38 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use38(factory: Factory): void { const box: Box<C38> = factory(new C38()); console.log(box.value.tag); }
class C39 { tag = 39; }
function source39<T>(value: T): Box<T> { return new Box(value); }
class M39 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use39(factory: Factory): void { const box: Box<C39> = factory(new C39()); console.log(box.value.tag); }
class C40 { tag = 40; }
function source40<T>(value: T): Box<T> { return new Box(value); }
class M40 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use40(factory: Factory): void { const box: Box<C40> = factory(new C40()); console.log(box.value.tag); }
class C41 { tag = 41; }
function source41<T>(value: T): Box<T> { return new Box(value); }
class M41 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use41(factory: Factory): void { const box: Box<C41> = factory(new C41()); console.log(box.value.tag); }
class C42 { tag = 42; }
function source42<T>(value: T): Box<T> { return new Box(value); }
class M42 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use42(factory: Factory): void { const box: Box<C42> = factory(new C42()); console.log(box.value.tag); }
class C43 { tag = 43; }
function source43<T>(value: T): Box<T> { return new Box(value); }
class M43 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use43(factory: Factory): void { const box: Box<C43> = factory(new C43()); console.log(box.value.tag); }
class C44 { tag = 44; }
function source44<T>(value: T): Box<T> { return new Box(value); }
class M44 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use44(factory: Factory): void { const box: Box<C44> = factory(new C44()); console.log(box.value.tag); }
class C45 { tag = 45; }
function source45<T>(value: T): Box<T> { return new Box(value); }
class M45 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use45(factory: Factory): void { const box: Box<C45> = factory(new C45()); console.log(box.value.tag); }
class C46 { tag = 46; }
function source46<T>(value: T): Box<T> { return new Box(value); }
class M46 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use46(factory: Factory): void { const box: Box<C46> = factory(new C46()); console.log(box.value.tag); }
class C47 { tag = 47; }
function source47<T>(value: T): Box<T> { return new Box(value); }
class M47 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use47(factory: Factory): void { const box: Box<C47> = factory(new C47()); console.log(box.value.tag); }
class C48 { tag = 48; }
function source48<T>(value: T): Box<T> { return new Box(value); }
class M48 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use48(factory: Factory): void { const box: Box<C48> = factory(new C48()); console.log(box.value.tag); }
class C49 { tag = 49; }
function source49<T>(value: T): Box<T> { return new Box(value); }
class M49 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use49(factory: Factory): void { const box: Box<C49> = factory(new C49()); console.log(box.value.tag); }
class C50 { tag = 50; }
function source50<T>(value: T): Box<T> { return new Box(value); }
class M50 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use50(factory: Factory): void { const box: Box<C50> = factory(new C50()); console.log(box.value.tag); }
class C51 { tag = 51; }
function source51<T>(value: T): Box<T> { return new Box(value); }
class M51 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use51(factory: Factory): void { const box: Box<C51> = factory(new C51()); console.log(box.value.tag); }
class C52 { tag = 52; }
function source52<T>(value: T): Box<T> { return new Box(value); }
class M52 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use52(factory: Factory): void { const box: Box<C52> = factory(new C52()); console.log(box.value.tag); }
class C53 { tag = 53; }
function source53<T>(value: T): Box<T> { return new Box(value); }
class M53 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use53(factory: Factory): void { const box: Box<C53> = factory(new C53()); console.log(box.value.tag); }
class C54 { tag = 54; }
function source54<T>(value: T): Box<T> { return new Box(value); }
class M54 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use54(factory: Factory): void { const box: Box<C54> = factory(new C54()); console.log(box.value.tag); }
class C55 { tag = 55; }
function source55<T>(value: T): Box<T> { return new Box(value); }
class M55 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use55(factory: Factory): void { const box: Box<C55> = factory(new C55()); console.log(box.value.tag); }
class C56 { tag = 56; }
function source56<T>(value: T): Box<T> { return new Box(value); }
class M56 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use56(factory: Factory): void { const box: Box<C56> = factory(new C56()); console.log(box.value.tag); }
class C57 { tag = 57; }
function source57<T>(value: T): Box<T> { return new Box(value); }
class M57 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use57(factory: Factory): void { const box: Box<C57> = factory(new C57()); console.log(box.value.tag); }
class C58 { tag = 58; }
function source58<T>(value: T): Box<T> { return new Box(value); }
class M58 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use58(factory: Factory): void { const box: Box<C58> = factory(new C58()); console.log(box.value.tag); }
class C59 { tag = 59; }
function source59<T>(value: T): Box<T> { return new Box(value); }
class M59 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use59(factory: Factory): void { const box: Box<C59> = factory(new C59()); console.log(box.value.tag); }
const selected0: Factory = source0; const alternate0: Factory = source1;
const root0 = [{ value: alternate0 }, { value: selected0 }, { value: alternate0 }];
const [, child0, ,] = root0;
use0(child0.value);
const selected1: Factory = source1; const alternate1: Factory = source2;
const root1 = [{ value: alternate1 }, { value: selected1 }, { value: alternate1 }];
const [, child1, ,] = root1;
use1(child1.value);
const selected2: Factory = source2; const alternate2: Factory = source3;
const root2 = [{ value: alternate2 }, { value: selected2 }, { value: alternate2 }];
const [, child2, ,] = root2;
use2(child2.value);
const selected3: Factory = source3; const alternate3: Factory = source4;
const root3 = [{ value: alternate3 }, { value: selected3 }, { value: alternate3 }];
const [, child3, ,] = root3;
use3(child3.value);
const selected4: Factory = source4; const alternate4: Factory = source5;
const root4 = [{ value: alternate4 }, { value: selected4 }, { value: alternate4 }];
const [, child4, ,] = root4;
use4(child4.value);
const selected5: Factory = source5; const alternate5: Factory = source6;
const root5 = [{ value: alternate5 }, { value: selected5 }, { value: alternate5 }];
const [, child5, ,] = root5;
use5(child5.value);
const selected6: Factory = source6; const alternate6: Factory = source7;
const root6 = [{ value: alternate6 }, { value: selected6 }, { value: alternate6 }];
const [, child6, ,] = root6;
use6(child6.value);
const selected7: Factory = source7; const alternate7: Factory = source8;
const root7 = [{ value: alternate7 }, { value: selected7 }, { value: alternate7 }];
const [, child7, ,] = root7;
use7(child7.value);
const selected8: Factory = source8; const alternate8: Factory = source9;
const root8 = [{ value: alternate8 }, { value: selected8 }, { value: alternate8 }];
const [, child8, ,] = root8;
use8(child8.value);
const selected9: Factory = source9; const alternate9: Factory = source10;
const root9 = [{ value: alternate9 }, { value: selected9 }, { value: alternate9 }];
const [, child9, ,] = root9;
use9(child9.value);
const selected10: Factory = source10; const alternate10: Factory = source11;
const root10 = [{ value: alternate10 }, { value: selected10 }, { value: alternate10 }];
const [, child10, ,] = root10;
use10(child10.value);
const selected11: Factory = source11; const alternate11: Factory = source12;
const root11 = [{ value: alternate11 }, { value: selected11 }, { value: alternate11 }];
const [, child11, ,] = root11;
use11(child11.value);
const selected12: Factory = source12; const alternate12: Factory = source13;
const root12 = [{ value: alternate12 }, { value: selected12 }, { value: alternate12 }];
const [, child12, ,] = root12;
use12(child12.value);
const selected13: Factory = source13; const alternate13: Factory = source14;
const root13 = [{ value: alternate13 }, { value: selected13 }, { value: alternate13 }];
const [, child13, ,] = root13;
use13(child13.value);
const selected14: Factory = source14; const alternate14: Factory = source15;
const root14 = [{ value: alternate14 }, { value: selected14 }, { value: alternate14 }];
const [, child14, ,] = root14;
use14(child14.value);
const selected15: Factory = source15; const alternate15: Factory = source16;
const root15 = [{ value: alternate15 }, { value: selected15 }, { value: alternate15 }];
const [, child15, ,] = root15;
use15(child15.value);
const selected16: Factory = source16; const alternate16: Factory = source17;
const root16 = [{ value: alternate16 }, { value: selected16 }, { value: alternate16 }];
const [, child16, ,] = root16;
use16(child16.value);
const selected17: Factory = source17; const alternate17: Factory = source18;
const root17 = [{ value: alternate17 }, { value: selected17 }, { value: alternate17 }];
const [, child17, ,] = root17;
use17(child17.value);
const selected18: Factory = source18; const alternate18: Factory = source19;
const root18 = [{ value: alternate18 }, { value: selected18 }, { value: alternate18 }];
const [, child18, ,] = root18;
use18(child18.value);
const selected19: Factory = source19; const alternate19: Factory = source20;
const root19 = [{ value: alternate19 }, { value: selected19 }, { value: alternate19 }];
const [, child19, ,] = root19;
use19(child19.value);
const selected20: Factory = source20; const alternate20: Factory = source21;
const root20 = [{ value: alternate20 }, { value: selected20 }, { value: alternate20 }];
const [, child20, ,] = root20;
use20(child20.value);
const selected21: Factory = source21; const alternate21: Factory = source22;
const root21 = [{ value: alternate21 }, { value: selected21 }, { value: alternate21 }];
const [, child21, ,] = root21;
use21(child21.value);
const selected22: Factory = source22; const alternate22: Factory = source23;
const root22 = [{ value: alternate22 }, { value: selected22 }, { value: alternate22 }];
const [, child22, ,] = root22;
use22(child22.value);
const selected23: Factory = source23; const alternate23: Factory = source24;
const root23 = [{ value: alternate23 }, { value: selected23 }, { value: alternate23 }];
const [, child23, ,] = root23;
use23(child23.value);
const selected24: Factory = source24; const alternate24: Factory = source25;
const root24 = [{ value: alternate24 }, { value: selected24 }, { value: alternate24 }];
const [, child24, ,] = root24;
use24(child24.value);
const selected25: Factory = source25; const alternate25: Factory = source26;
const root25 = [{ value: alternate25 }, { value: selected25 }, { value: alternate25 }];
const [, child25, ,] = root25;
use25(child25.value);
const selected26: Factory = source26; const alternate26: Factory = source27;
const root26 = [{ value: alternate26 }, { value: selected26 }, { value: alternate26 }];
const [, child26, ,] = root26;
use26(child26.value);
const selected27: Factory = source27; const alternate27: Factory = source28;
const root27 = [{ value: alternate27 }, { value: selected27 }, { value: alternate27 }];
const [, child27, ,] = root27;
use27(child27.value);
const selected28: Factory = source28; const alternate28: Factory = source29;
const root28 = [{ value: alternate28 }, { value: selected28 }, { value: alternate28 }];
const [, child28, ,] = root28;
use28(child28.value);
const selected29: Factory = source29; const alternate29: Factory = source30;
const root29 = [{ value: alternate29 }, { value: selected29 }, { value: alternate29 }];
const [, child29, ,] = root29;
use29(child29.value);
const selected30: Factory = source30; const alternate30: Factory = source31;
const root30 = [{ value: alternate30 }, { value: selected30 }, { value: alternate30 }];
const [, child30, ,] = root30;
use30(child30.value);
const selected31: Factory = source31; const alternate31: Factory = source32;
const root31 = [{ value: alternate31 }, { value: selected31 }, { value: alternate31 }];
const [, child31, ,] = root31;
use31(child31.value);
const selected32: Factory = source32; const alternate32: Factory = source33;
const root32 = [{ value: alternate32 }, { value: selected32 }, { value: alternate32 }];
const [, child32, ,] = root32;
use32(child32.value);
const selected33: Factory = source33; const alternate33: Factory = source34;
const root33 = [{ value: alternate33 }, { value: selected33 }, { value: alternate33 }];
const [, child33, ,] = root33;
use33(child33.value);
const selected34: Factory = source34; const alternate34: Factory = source35;
const root34 = [{ value: alternate34 }, { value: selected34 }, { value: alternate34 }];
const [, child34, ,] = root34;
use34(child34.value);
const selected35: Factory = source35; const alternate35: Factory = source36;
const root35 = [{ value: alternate35 }, { value: selected35 }, { value: alternate35 }];
const [, child35, ,] = root35;
use35(child35.value);
const selected36: Factory = source36; const alternate36: Factory = source37;
const root36 = [{ value: alternate36 }, { value: selected36 }, { value: alternate36 }];
const [, child36, ,] = root36;
use36(child36.value);
const selected37: Factory = source37; const alternate37: Factory = source38;
const root37 = [{ value: alternate37 }, { value: selected37 }, { value: alternate37 }];
const [, child37, ,] = root37;
use37(child37.value);
const selected38: Factory = source38; const alternate38: Factory = source39;
const root38 = [{ value: alternate38 }, { value: selected38 }, { value: alternate38 }];
const [, child38, ,] = root38;
use38(child38.value);
const selected39: Factory = source39; const alternate39: Factory = source40;
const root39 = [{ value: alternate39 }, { value: selected39 }, { value: alternate39 }];
const [, child39, ,] = root39;
use39(child39.value);
const selected40: Factory = source40; const alternate40: Factory = source41;
const root40 = [{ value: alternate40 }, { value: selected40 }, { value: alternate40 }];
const [, child40, ,] = root40;
use40(child40.value);
const selected41: Factory = source41; const alternate41: Factory = source42;
const root41 = [{ value: alternate41 }, { value: selected41 }, { value: alternate41 }];
const [, child41, ,] = root41;
use41(child41.value);
const selected42: Factory = source42; const alternate42: Factory = source43;
const root42 = [{ value: alternate42 }, { value: selected42 }, { value: alternate42 }];
const [, child42, ,] = root42;
use42(child42.value);
const selected43: Factory = source43; const alternate43: Factory = source44;
const root43 = [{ value: alternate43 }, { value: selected43 }, { value: alternate43 }];
const [, child43, ,] = root43;
use43(child43.value);
const selected44: Factory = source44; const alternate44: Factory = source45;
const root44 = [{ value: alternate44 }, { value: selected44 }, { value: alternate44 }];
const [, child44, ,] = root44;
use44(child44.value);
const selected45: Factory = source45; const alternate45: Factory = source46;
const root45 = [{ value: alternate45 }, { value: selected45 }, { value: alternate45 }];
const [, child45, ,] = root45;
use45(child45.value);
const selected46: Factory = source46; const alternate46: Factory = source47;
const root46 = [{ value: alternate46 }, { value: selected46 }, { value: alternate46 }];
const [, child46, ,] = root46;
use46(child46.value);
const selected47: Factory = source47; const alternate47: Factory = source48;
const root47 = [{ value: alternate47 }, { value: selected47 }, { value: alternate47 }];
const [, child47, ,] = root47;
use47(child47.value);
const selected48: Factory = source48; const alternate48: Factory = source49;
const root48 = [{ value: alternate48 }, { value: selected48 }, { value: alternate48 }];
const [, child48, ,] = root48;
use48(child48.value);
const selected49: Factory = source49; const alternate49: Factory = source50;
const root49 = [{ value: alternate49 }, { value: selected49 }, { value: alternate49 }];
const [, child49, ,] = root49;
use49(child49.value);
const selected50: Factory = source50; const alternate50: Factory = source51;
const root50 = [{ value: alternate50 }, { value: selected50 }, { value: alternate50 }];
const [, child50, ,] = root50;
use50(child50.value);
const selected51: Factory = source51; const alternate51: Factory = source52;
const root51 = [{ value: alternate51 }, { value: selected51 }, { value: alternate51 }];
const [, child51, ,] = root51;
use51(child51.value);
const selected52: Factory = source52; const alternate52: Factory = source53;
const root52 = [{ value: alternate52 }, { value: selected52 }, { value: alternate52 }];
const [, child52, ,] = root52;
use52(child52.value);
const selected53: Factory = source53; const alternate53: Factory = source54;
const root53 = [{ value: alternate53 }, { value: selected53 }, { value: alternate53 }];
const [, child53, ,] = root53;
use53(child53.value);
const selected54: Factory = source54; const alternate54: Factory = source55;
const root54 = [{ value: alternate54 }, { value: selected54 }, { value: alternate54 }];
const [, child54, ,] = root54;
use54(child54.value);
const selected55: Factory = source55; const alternate55: Factory = source56;
const root55 = [{ value: alternate55 }, { value: selected55 }, { value: alternate55 }];
const [, child55, ,] = root55;
use55(child55.value);
const selected56: Factory = source56; const alternate56: Factory = source57;
const root56 = [{ value: alternate56 }, { value: selected56 }, { value: alternate56 }];
const [, child56, ,] = root56;
use56(child56.value);
const selected57: Factory = source57; const alternate57: Factory = source58;
const root57 = [{ value: alternate57 }, { value: selected57 }, { value: alternate57 }];
const [, child57, ,] = root57;
use57(child57.value);
const selected58: Factory = source58; const alternate58: Factory = source59;
const root58 = [{ value: alternate58 }, { value: selected58 }, { value: alternate58 }];
const [, child58, ,] = root58;
use58(child58.value);
const selected59: Factory = source59; const alternate59: Factory = source0;
const root59 = [{ value: alternate59 }, { value: selected59 }, { value: alternate59 }];
const [, child59, ,] = root59;
use59(child59.value);
