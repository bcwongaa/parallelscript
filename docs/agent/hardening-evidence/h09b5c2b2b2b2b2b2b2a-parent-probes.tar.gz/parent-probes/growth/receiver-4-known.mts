class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
function consumeContainer(value: unknown): void {}
class C0 { tag = 0; }
function source0<T>(value: T): Box<T> { return new Box(value); }
class M0 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use0(receiver: Maker): void { const box: Box<C0> = receiver.make(new C0()); console.log(box.value.tag); }
class C1 { tag = 1; }
function source1<T>(value: T): Box<T> { return new Box(value); }
class M1 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use1(receiver: Maker): void { const box: Box<C1> = receiver.make(new C1()); console.log(box.value.tag); }
class C2 { tag = 2; }
function source2<T>(value: T): Box<T> { return new Box(value); }
class M2 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use2(receiver: Maker): void { const box: Box<C2> = receiver.make(new C2()); console.log(box.value.tag); }
class C3 { tag = 3; }
function source3<T>(value: T): Box<T> { return new Box(value); }
class M3 implements Maker { make<T>(value: T): Box<T> { return new Box(value); } }
function use3(receiver: Maker): void { const box: Box<C3> = receiver.make(new C3()); console.log(box.value.tag); }
const selected0: Maker = new M0(); const alternate0: Maker = new M1();
const root0 = [{ value: alternate0 }, { value: selected0 }, { value: alternate0 }];
const [, child0, ,] = root0;
use0(child0.value);
const selected1: Maker = new M1(); const alternate1: Maker = new M2();
const root1 = [{ value: alternate1 }, { value: selected1 }, { value: alternate1 }];
const [, child1, ,] = root1;
use1(child1.value);
const selected2: Maker = new M2(); const alternate2: Maker = new M3();
const root2 = [{ value: alternate2 }, { value: selected2 }, { value: alternate2 }];
const [, child2, ,] = root2;
use2(child2.value);
const selected3: Maker = new M3(); const alternate3: Maker = new M0();
const root3 = [{ value: alternate3 }, { value: selected3 }, { value: alternate3 }];
const [, child3, ,] = root3;
use3(child3.value);
