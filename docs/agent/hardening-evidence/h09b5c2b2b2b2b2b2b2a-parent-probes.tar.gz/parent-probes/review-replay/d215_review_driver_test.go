package driver_test

import (
	"fmt"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"gotest.tools/v3/assert"
)

func TestD215ReviewAllInstancesExactTargetMatrices(t *testing.T) {
	for _, kind := range []string{"function", "receiver", "captured_receiver", "wrapper"} {
		for _, shape := range []string{"leading", "trailing", "nested", "all_elided_sibling", "late_all_elided", "missing", "skipped_mutation", "skipped_contract"} {
			t.Run(kind+"_"+shape, func(t *testing.T) {
				var source strings.Builder
				source.WriteString(inlineContainerFlowInventory(kind, 3))
				valueType := "Factory"
				if kind == "receiver" || kind == "captured_receiver" {
					valueType = "Maker"
				}
				for i := range 3 {
					value, alternate := fmt.Sprintf("source%d", i), fmt.Sprintf("source%d", (i+1)%3)
					if valueType == "Maker" {
						value, alternate = fmt.Sprintf("new M%d()", i), fmt.Sprintf("new M%d()", (i+1)%3)
					} else if kind == "wrapper" {
						value, alternate = fmt.Sprintf("read%d()", i), fmt.Sprintf("read%d()", (i+1)%3)
					}
					fmt.Fprintf(&source, "const selected%d: %s = %s; const alternate%d: %s = %s;\n", i, valueType, value, i, valueType, alternate)
					switch shape {
					case "trailing":
						fmt.Fprintf(&source, "const root%d=[{value:selected%d},{value:alternate%d}]; const [child%d,,]=root%d;\n", i, i, i, i, i)
					case "nested":
						fmt.Fprintf(&source, "const root%d=[[{value:alternate%d},{value:selected%d}],[{value:alternate%d},{value:selected%d}]]; const [, [,child%d]]=root%d;\n", i, i, i, i, i, i, i)
					case "all_elided_sibling":
						fmt.Fprintf(&source, "const root%d={rows:[alternate%d,selected%d],child:{value:selected%d}}; const {rows:[,,],child:child%d}=root%d;\n", i, i, i, i, i, i)
					case "missing":
						fmt.Fprintf(&source, "const root%d=[{value:selected%d}]; const [child%d,,]=root%d;\n", i, i, i, i)
					default:
						fmt.Fprintf(&source, "const root%d=[{value:alternate%d},{value:selected%d}]; const [,child%d]=root%d;\n", i, i, i, i, i)
					}
					expression := fmt.Sprintf("child%d.value", i)
					if kind == "captured_receiver" {
						expression = fmt.Sprintf("read%d(%s)", i, expression)
					}
					fmt.Fprintf(&source, "use%d(%s);\n", i, expression)
					switch shape {
					case "late_all_elided":
						fmt.Fprintf(&source, "const [,,]=root%d;\n", i)
					case "skipped_mutation":
						fmt.Fprintf(&source, "root%d[0].value=selected%d;\n", i, i)
					case "skipped_contract":
						fmt.Fprintf(&source, "const changed%d: {value:any}=root%d[0];\n", i, i)
					}
				}
				entry := writeSource(t, source.String())
				c, err := driver.EmitCWith(t.Context(), entry, lower.AllInstances)
				if shape == "skipped_contract" {
					// The identical input is PTS1001 on both source versions, so this
					// is an unsupported-API control, not a compiled pair assertion.
					assert.ErrorContains(t, err, "PTS1001")
					assert.ErrorContains(t, err, "whose `value` it doesn't provide with the same types")
					return
				}
				assert.NilError(t, err)
				unknown := shape == "missing" || shape == "skipped_mutation"
				pairs := inlineContainerAssertPairs(t, c, kind, 3, func(value, demand int) bool { return unknown || value == demand })
				want := 3
				if unknown {
					want = 9
				}
				assert.Equal(t, pairs, want)
				if !unknown && (kind == "captured_receiver" || kind == "wrapper") {
					for i := range 3 {
						assertCapturedReceiverWrapperSignatures(t, c, fmt.Sprintf("read%d_make", i), []int{i})
					}
				}
			})
		}
	}
}
