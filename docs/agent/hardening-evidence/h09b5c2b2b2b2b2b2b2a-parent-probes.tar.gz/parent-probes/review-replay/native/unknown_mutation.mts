class Box<T> { constructor(public value: T) {} }
class Tag0 { tag = 0; }
class Tag1 { tag = 1; }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
let events = "";
function sourceA<T>(value: T): Box<T> { events += "A"; return new Box(value); }
function sourceB<T>(value: T): Box<T> { events += "B"; return new Box(value); }
const first: Factory = sourceA;
const second: Factory = sourceB;
const root = [{ factory: first }, { factory: second }];
const [, child] = root;
const alias = child;
const before = child.factory;
alias.factory = first;
const after = child.factory;
console.log("functions", before(new Tag0()).value.tag, after(new Tag1()).value.tag, events);
class Alpha implements Maker {
  count = 10;
  make<T>(value: T): Box<T> { this.count++; events += "X"; return new Box(value); }
}
class Beta implements Maker {
  count = 20;
  make<T>(value: T): Box<T> { this.count++; events += "Y"; return new Box(value); }
}
const alpha = new Alpha();
const beta = new Beta();
const firstMaker: Maker = alpha;
const secondMaker: Maker = beta;
const receivers = [{ maker: firstMaker }, { maker: secondMaker }];
const [, receiverChild] = receivers;
const receiverAlias = receiverChild;
const saved = receiverChild.maker;
receiverAlias.maker = firstMaker;
const changed = receiverChild.maker;
console.log("receivers", saved.make(new Tag0()).value.tag, changed.make(new Tag1()).value.tag, alpha.count, beta.count, events);
