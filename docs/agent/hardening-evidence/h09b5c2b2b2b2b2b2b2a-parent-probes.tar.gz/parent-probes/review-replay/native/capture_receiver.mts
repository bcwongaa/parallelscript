class Box<T> { constructor(public value: T) {} }
type Factory = <T>(value: T) => Box<T>;
interface Maker { make<T>(value: T): Box<T>; }
let events = "";
function closure(start: number): Factory {
  let count = start;
  return <T>(value: T): Box<T> => {
    count++;
    events += "[" + count + "]";
    return new Box(value);
  };
}
function mark(factory: Factory, label: string): Factory { events += label; return factory; }
const first: Factory = closure(10);
const second: Factory = closure(20);
const root = { rows: [{ factory: mark(first, "L") }, { factory: mark(second, "R") }], other: { factory: first }, skipped: [first, second] };
const { rows: [, child], other, skipped: [,,] } = root;
const alias = child;
const left = other.factory;
const right = alias.factory;
class Alpha implements Maker {
  count = 30;
  make<T>(value: T): Box<T> { this.count++; events += "A" + this.count; return new Box(value); }
}
class Beta implements Maker {
  count = 40;
  make<T>(value: T): Box<T> { this.count++; events += "B" + this.count; return new Box(value); }
}
const alpha = new Alpha();
const beta = new Beta();
const alphaValue: Maker = alpha;
const betaValue: Maker = beta;
const makers = [[{ maker: alphaValue }, { maker: betaValue }], [{ maker: alphaValue }, { maker: betaValue }]];
const [, [, receiverChild]] = makers;
const held = receiverChild.maker;
const bound = held.make.bind(held);
let checksum = 0;
for (let i = 0; i < 60000; i++) {
  const garbage = [i, i + 1, i + 2, i + 3, i + 4, i + 5, i + 6, i + 7];
  checksum += garbage[0];
}
console.log("capture", left("a").value, right(2).value, left(true).value, events);
console.log("receiver", held.make("direct").value, bound(7).value, alpha.count, beta.count, events);
console.log("churn", checksum);
