package lower

import (
	"fmt"
	"slices"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/internal/ast"
	"gotest.tools/v3/assert"
)

func TestD215ReviewElisionShapeAndWholeComponent(t *testing.T) {
	cases := []struct {
		name string
		body string
		want []string
	}{
		{"leading", "const root = [{value:first},{value:second}]; const [,child] = root; const probe = child.value; probe;", []string{"second"}},
		{"middle_and_trailing", "const root = [{value:first},{value:second},{value:first},{value:second}]; const [,child,,] = root; const probe = child.value; probe;", []string{"second"}},
		{"trailing_comma_not_omission", "const root = [{value:first}]; const [child,] = root; const probe = child.value; probe;", []string{"first"}},
		{"trailing_elision_present", "const root = [{value:first},{value:second}]; const [child,,] = root; const probe = child.value; probe;", []string{"first"}},
		{"all_elided_root", "const root = [{value:first},{value:second}]; const [,,] = root; const probe = root[1].value; probe;", []string{"second"}},
		{"all_elided_terminal_row", "const root = {rows:[first,second], child:{value:first}}; const {rows:[,,], child} = root; const probe = child.value; probe;", []string{"first"}},
		{"empty_row_control", "const root = {rows:[], child:{value:first}}; const {rows:[], child} = root; const probe = child.value; probe;", []string{"first"}},
		{"nested_arrays", "const root = [[{value:first},{value:second}],[{value:second},{value:first}]]; const [, [,child]] = root; const probe = child.value; probe;", []string{"first"}},
		{"nested_object_array", "const root = {rows:[{branch:{value:second}},{branch:{value:first}}]}; const {rows:[,{branch:child}]} = root; const probe = child.value; probe;", []string{"first"}},
		{"fresh_object_projection", "const [,child] = ({rows:[{value:first},{value:second}]}).rows; const probe = child.value; probe;", []string{"second"}},
		{"array_child", "const root = [[first,second],[second,first]]; const [,child] = root; const probe = child[1]; probe;", []string{"first"}},
		{"repeated_extractions", "const root = [{value:first},{value:second}]; const [,child] = root; const [other,,] = root; const ignored = other.value; const probe = child.value; probe;", []string{"second"}},
		{"missing_trailing_index", "const root = [{value:first}]; const [child,,] = root; const probe = child.value; probe;", nil},
		{"all_elided_missing_index", "const root = [{value:first}]; const [,,] = root; const probe = root[0].value; probe;", nil},
		{"empty_row_missing_index", "const root = {rows:[], child:{value:first}}; const {rows:[,], child} = root; const probe = child.value; probe;", nil},
		{"nested_missing_index", "const root = {rows:[{value:first}], child:{value:first}}; const {rows:[,,], child} = root; const probe = child.value; probe;", nil},
		{"terminal_leaf", "const root = [{value:first},{value:second}]; const [, {value}] = root; const probe = root[0].value; probe;", nil},
		{"default_after_elision", "const root = [{value:first},{value:second}]; const [, child = {value:first}] = root; const probe = root[0].value; probe;", nil},
		{"rest_after_elision", "const root = [{value:first},{value:second}]; const [, ...children] = root; const probe = root[0].value; probe;", nil},
		{"fresh_tuple", "const [,child] = [{value:first},{value:second}]; const probe = child.value; probe;", nil},
		{"annotated_owner", "const root = [{value:first},{value:second}]; const [,child]: {value:Value}[] = root; const probe = child.value; probe;", nil},
		{"skipped_getter", "const root = [{get value(): Value {return first;}},{value:second}]; const [,child] = root; const probe = child.value; probe;", nil},
		{"skipped_sibling_raw_mismatch", "const root = {rows:[{value:first},{value:second}], ignored:[{value:first},{value:second,tag:1}]}; const [,child] = root.rows; const probe = child.value; probe;", nil},
		{"skipped_sibling_literal_hole", "const root = {rows:[{value:first},{value:second}], ignored:[first,,second]}; const [,child] = root.rows; const probe = child.value; probe;", nil},
		{"skipped_sibling_literal_spread", "const root = {rows:[{value:first},{value:second}], ignored:[first,...[second]]}; const [,child] = root.rows; const probe = child.value; probe;", nil},
		{"skipped_alias_changed_contract", "const root = [{value:first},{value:second}]; const [,child] = root; const changed: {value:any} = root[0]; const probe = child.value; probe;", nil},
		{"skipped_alias_mutated", "const root = [{value:first},{value:second}]; const [,child] = root; const skipped = root[0]; const skippedAlias = skipped; skippedAlias.value = second; const probe = child.value; probe;", nil},
		{"skipped_alias_escaped", "const root = [{value:first},{value:second}]; const [,child] = root; const skipped = root[0]; consume(skipped); const probe = child.value; probe;", nil},
		{"root_mutated_in_nested_function", "const root = [{value:first},{value:second}]; const [,child] = root; function later(): void {root[0].value = second;} const probe = child.value; probe;", nil},
		{"contextual_generic", "const run: <T>(x:T)=>void = x => {const root = [{value:first},{value:second}]; const [,child] = root; const probe = child.value; probe;}; run(1);", nil},
	}
	for _, tt := range cases {
		t.Run(tt.name, func(t *testing.T) {
			for _, receivers := range []bool{false, true} {
				t.Run(fmt.Sprintf("receivers_%t", receivers), func(t *testing.T) {
					l, probe := valueFlowProbe(t, nestedContainerPrelude(receivers)+tt.body)
					steps := maxValueFlowSteps
					sources := (sourceProof{l: l, receivers: receivers}).valueSources(probe, &steps, 0)
					assert.Equal(t, sources != nil, tt.want != nil)
					if tt.want != nil {
						assert.DeepEqual(t, returnedSourceNames(sources), inlineContainerSourceNames(tt.want, receivers))
					}
					assert.Equal(t, len(l.valueFlow.active), 0)
					assert.Equal(t, len(l.valueFlow.receivers.active), 0)
				})
			}
		})
	}
}

func TestD215ReviewElidedSiblingCacheAndKindOrder(t *testing.T) {
	for _, reverse := range []bool{false, true} {
		for _, receiverFirst := range []bool{false, true} {
			t.Run(fmt.Sprintf("reverse_%t_receiver_first_%t", reverse, receiverFirst), func(t *testing.T) {
				l, _ := valueFlowProbe(t, nestedContainerPrelude(true)+`const badRoot=[{value:first},{value:second}]; const goodRoot=[{value:first},{value:second}];
const [,bad]=badRoot; const [,good]=goodRoot;
const check_bad=bad.value; const check_good=good.value;
const skipped=badRoot[0]; const another=skipped; consume(another); const probe=check_good; probe;`)
				projections := containerAliasProbeExpressions(l)
				assert.Equal(t, len(projections), 2)
				if reverse {
					slices.Reverse(projections)
				}
				for range 2 {
					for _, projection := range projections {
						kinds := []bool{false, true}
						if receiverFirst {
							slices.Reverse(kinds)
						}
						for _, receivers := range kinds {
							steps := maxValueFlowSteps
							sources := (sourceProof{l: l, receivers: receivers}).valueSources(projection, &steps, 0)
							known := receivers && projection.Expression().Text() == "good"
							assert.Equal(t, sources != nil, known)
							if known {
								assert.DeepEqual(t, returnedSourceNames(sources), []string{"B"})
							}
						}
					}
				}
			})
		}
	}
}

func TestD215ReviewNamelessBindingAST(t *testing.T) {
	l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+"const root=[{value:first},{value:second}]; const [,,]=root; const probe=root[0].value; probe;")
	omissions := 0
	var visit ast.Visitor
	visit = func(n *ast.Node) bool {
		if n.Kind == ast.KindBindingElement && n.Name() == nil {
			omissions++
			assert.Assert(t, n.Initializer() == nil && n.AsBindingElement().DotDotDotToken == nil && n.AsBindingElement().PropertyName == nil)
		}
		n.ForEachChild(visit)
		return false
	}
	for _, file := range l.valueFlow.files {
		file.AsNode().ForEachChild(visit)
	}
	assert.Equal(t, omissions, 2)
}

func TestD215ReviewDirectOmissionBudget(t *testing.T) {
	for _, width := range []int{2, 180} {
		t.Run(fmt.Sprintf("width_%d", width), func(t *testing.T) {
			body := "const root=[" + strings.Repeat("first,", width) + "]; const [" + strings.Repeat(",", width) + "]=root; const probe=first; probe;"
			l, _ := valueFlowProbe(t, nestedContainerPrelude(false)+body)
			var root, pattern *ast.Node
			var visit ast.Visitor
			visit = func(n *ast.Node) bool {
				if n.Kind == ast.KindVariableDeclaration && n.Name().Kind == ast.KindIdentifier && n.Name().Text() == "root" {
					root = n
				}
				if n.Kind == ast.KindArrayBindingPattern {
					pattern = n
				}
				n.ForEachChild(visit)
				return false
			}
			for _, file := range l.valueFlow.files {
				file.AsNode().ForEachChild(visit)
			}
			assert.Assert(t, root != nil && pattern != nil)
			steps := maxValueFlowSteps
			tree := l.containerTree(root.Initializer(), &steps, 0)
			_, symbol := l.containerBinding(root.Name())
			assert.Assert(t, tree != nil && symbol != nil)
			contract := l.checker.GetTypeOfSymbol(symbol)
			called := 0
			check := func(*ast.Node, *ast.Symbol, *literalContainer, int) bool { called++; return true }
			steps = width + 1
			assert.Assert(t, l.containerPatternUse(pattern, tree, contract, false, &steps, maxValueFlowDepth-2, check), "shallow nameless siblings do not accumulate recursion depth")
			assert.Equal(t, steps, 0, "one pattern step plus one step per omitted cell")
			assert.Equal(t, called, 0, "omissions create no binding/source")
			steps = width
			assert.Assert(t, !l.containerPatternUse(pattern, tree, contract, false, &steps, 0, check), "one-step exhaustion must not accept an unchecked omitted cell")
			assert.Equal(t, called, 0)
		})
	}
}

func TestD215ReviewWideOmissionsAndLateWork(t *testing.T) {
	const width = 180
	body := "const root=[" + strings.Repeat("{value:first},", width) + "]; const [" + strings.Repeat(",", width-1) + "child]=root; const probe=child.value; probe;"
	l, probe := valueFlowProbe(t, nestedContainerPrelude(false)+body)
	steps := maxValueFlowSteps
	sources := l.valueSources(probe, &steps, 0)
	assert.Assert(t, sources != nil, "shallow omissions spend work, not accumulated depth")
	assert.DeepEqual(t, returnedSourceNames(sources), []string{"first"})
	assert.Assert(t, steps > 0)
	// The no-binding pattern is intentionally after the selected projection. Even
	// cached trees must charge its omitted cells before publishing the root fact.
	body = "const root=[{value:first}]; const [child]=root; const probe=child.value; probe; " + strings.Repeat("const [,]=root;", 160)
	l, probe = valueFlowProbe(t, nestedContainerPrelude(false)+body)
	steps = 120
	assert.Assert(t, l.valueSources(probe, &steps, 0) == nil)
	steps = maxValueFlowSteps
	assert.Assert(t, l.valueSources(probe, &steps, 0) == nil, "budget failure may cache only unknown")
	assert.Equal(t, steps, maxValueFlowSteps)
}
