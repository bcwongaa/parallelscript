import runpy
import sys


inherited = runpy.run_path(sys.argv.pop(1))


def source(kind, count, unknown):
    lines = inherited["inventory"](kind, count)
    value_type = "Maker" if kind in ("receiver", "captured_receiver") else "Factory"
    for i in range(count):
        other = (i + 1) % count
        value = f"new M{i}()" if value_type == "Maker" else f"read{i}()" if kind == "wrapper" else f"source{i}"
        alternate = f"new M{other}()" if value_type == "Maker" else f"read{other}()" if kind == "wrapper" else f"source{other}"
        lines += [
            f"const selected{i}: {value_type} = {value}; const alternate{i}: {value_type} = {alternate};",
            f"const root{i} = [{{ value: alternate{i} }}, {{ value: selected{i} }}, {{ value: alternate{i} }}];",
            f"const [, child{i}, ,] = root{i};",
        ]
        if unknown:
            lines.append(f"consumeContainer(child{i});")
        terminal = f"child{i}.value"
        if kind == "captured_receiver":
            terminal = f"read{i}({terminal})"
        lines.append(f"use{i}({terminal});")
    return "\n".join(lines) + "\n"


original_run = inherited["run"]


def adapted_run(command, path, env):
    if len(command) == 5 and command[-1] == "all":
        command = [command[0], "all", *command[1:4]]
    return original_run(command, path, env)


main = inherited["main"]
main.__globals__["source"] = source
main.__globals__["run"] = adapted_run
main()
