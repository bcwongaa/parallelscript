package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) < 4 {
		panic("usage: emit <all|default|compile> <entry-or-C> <C-output-or-native> [native]")
	}
	ctx := context.Background()
	if os.Args[1] == "compile" {
		compile(ctx, os.Args[2], os.Args[3])
		return
	}
	var code string
	var err error
	if os.Args[1] == "all" {
		code, err = driver.EmitCWith(ctx, os.Args[2], lower.AllInstances)
	} else if os.Args[1] == "default" {
		code, err = driver.EmitC(ctx, os.Args[2])
	} else {
		panic("unknown API")
	}
	check(err)
	check(os.WriteFile(os.Args[3], []byte(code), 0600))
	if len(os.Args) == 5 {
		compile(ctx, os.Args[3], os.Args[4])
	}
}

func compile(ctx context.Context, source, output string) {
	tc, err := toolchain.New()
	check(err)
	rt, err := tc.Runtime(ctx, toolchain.Release)
	check(err)
	check(tc.CompileProgram(ctx, rt, []string{source}, output))
}

func check(err error) {
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
