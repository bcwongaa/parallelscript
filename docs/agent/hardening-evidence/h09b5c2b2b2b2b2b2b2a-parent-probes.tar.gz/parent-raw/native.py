import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo, scratch, *entries = map(Path, sys.argv[1:])
out = Path(os.environ.get('PTS_NATIVE_OUT', str(scratch / 'native')))
out.mkdir(exist_ok=False)
env = dict(os.environ, GOMAXPROCS='1', PTS_THREADS='1', PTS_HOME=str(repo))
results = []

def run(command, prefix):
    result = subprocess.run(list(map(str, command)), cwd=repo, env=env, capture_output=True, timeout=600)
    prefix.with_suffix(prefix.suffix + '.stdout').write_bytes(result.stdout)
    prefix.with_suffix(prefix.suffix + '.stderr').write_bytes(result.stderr)
    prefix.with_suffix(prefix.suffix + '.command.json').write_text(json.dumps(list(map(str, command))) + '\n')
    assert result.returncode == 0, (command, result.returncode, result.stderr.decode()[-4000:])
    return result.stdout

for entry in entries:
    name = entry.stem
    twin = out / (name + '.mts')
    twin.write_bytes(entry.read_bytes())
    oracle = run([Path.home() / '.local/node/bin/node', '--experimental-transform-types', twin], out / (name + '.node'))
    text = entry.read_text()
    if '// expect:\n' in text:
        expected = '\n'.join(line.removeprefix('// ') for line in text.split('// expect:\n', 1)[1].splitlines() if line.startswith('// ')) + '\n'
        assert oracle.decode() == expected, (name, oracle, expected)
    for label in ('base', 'current'):
        for mode in ('all', 'default'):
            prefix = out / f'{name}.{label}.{mode}'
            c = prefix.with_suffix(prefix.suffix + '.c')
            binary = prefix.with_suffix(prefix.suffix + '.bin')
            run([scratch / ('emit-' + label), mode, entry, c, binary], prefix.with_suffix(prefix.suffix + '.emit'))
            native = run([binary], prefix.with_suffix(prefix.suffix + '.native'))
            binary.unlink()
            assert native == oracle, (name, label, mode, native, oracle)
            assert '#line ' in c.read_text(), c
            results.append(dict(name=name, compiler=label, api=mode, native_node_match=True, c_sha256=hashlib.sha256(c.read_bytes()).hexdigest(), lines=c.read_text().count('\n')))
            print(name, label, mode, 'native == strict Node', flush=True)
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
