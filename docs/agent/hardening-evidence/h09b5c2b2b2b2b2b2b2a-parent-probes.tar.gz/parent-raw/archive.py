import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys
import tarfile

repo, scratch = map(Path, sys.argv[1:3])
task = 'h09b5c2b2b2b2b2b2b2a'
dest = repo / 'docs/agent/hardening-evidence'
allowed = {'.go', '.py', '.pts', '.mts', '.c', '.json', '.jsonl', '.stdout', '.stderr', '.err', '.out', '.exit', '.sha256', '.patch'}
files = [(p, 'parent-raw/' + p.name) for p in scratch.iterdir() if p.is_file() and not p.is_symlink() and p.suffix in allowed and p.name != 'artifact-results.stdout']
for root in ['original-tests', 'frozen', 'native', 'growth', 'repeated-c', 'mutants', 'review-replay', 'inherited']:
    for p in sorted((scratch / root).rglob('*')):
        if p.is_file() and not p.is_symlink() and p.suffix in allowed:
            files.append((p, 'parent-probes/' + str(p.relative_to(scratch))))
for name in ['sources.before.json', 'sources.after.json', 'summary.json', 'command.json', 'build.stdout', 'build.stderr', 'suite.stderr']:
    files.append((scratch / 'final' / name, 'final/' + name))
archive = dest / (task + '-parent-probes.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as t:
    for source, target in sorted(files, key=lambda x: x[1]):
        assert source.is_file() and not source.is_symlink(), source
        t.add(source, arcname=target, recursive=False)
with tarfile.open(archive) as t:
    members = t.getmembers()
    expected = {target: source for source, target in files}
    assert len(members) == len(expected)
    for member in members:
        path = PurePosixPath(member.name)
        assert member.isfile() and not path.is_absolute() and '..' not in path.parts
        assert t.extractfile(member).read() == expected[member.name].read_bytes()
raw = dest / (task + '-final-suite.jsonl.gz')
assert not raw.exists()
with (scratch / 'final/suite.jsonl').open('rb') as src, gzip.open(raw, 'wb') as output:
    shutil.copyfileobj(src, output)
assert gzip.decompress(raw.read_bytes()) == (scratch / 'final/suite.jsonl').read_bytes()
shutil.copyfile(scratch / 'final/summary.json', dest / (task + '-final-summary.json'))
rows = []
for suffix in ['parent-probes.tar.gz', 'reproducer-probes.tar.gz', 'review-probes.tar.gz', 'final-suite.jsonl.gz', 'final-summary.json']:
    p = dest / (task + '-' + suffix)
    row = dict(path=p.name, bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    if suffix.endswith('.tar.gz'):
        with tarfile.open(p) as t:
            entries = t.getmembers()
            assert all(x.isfile() and not PurePosixPath(x.name).is_absolute() and '..' not in PurePosixPath(x.name).parts for x in entries)
            row['regular_files'] = len(entries)
    rows.append(row)
manifest = dict(task=task, artifacts=rows, reviewed_files={line.split('  ', 1)[1]:line.split('  ', 1)[0] for line in (scratch / 'frozen/manifest.sha256').read_text().splitlines()}, archive_bytes_verified=True)
(dest / (task + '-artifacts.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2), flush=True)
