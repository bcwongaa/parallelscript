import collections
import json
from pathlib import Path
import sys

rows = {}
for name in sys.argv[1:]:
    path = Path(name)
    events = [json.loads(line) for line in path.read_text().splitlines()]
    counts = collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in ('pass', 'skip', 'fail'))
    packages = {e['Package']: e['Action'] for e in events if not e.get('Test') and e['Action'] in ('pass', 'skip', 'fail')}
    failures = [e['Test'] for e in events if e.get('Test') and e['Action'] == 'fail']
    rows[path.name] = dict(counts=dict(counts), packages=packages, failed_tests=failures)
print(json.dumps(rows, indent=2))
