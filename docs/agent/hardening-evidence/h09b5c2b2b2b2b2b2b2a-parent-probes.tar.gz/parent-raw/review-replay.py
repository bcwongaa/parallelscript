import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

repo, scratch, reviewer = map(Path, sys.argv[1:4])
out = scratch / 'review-replay'
out.mkdir(exist_ok=False)
mapping = {}
for package in ['lower', 'driver']:
    source = reviewer / ('d215_review_' + package + '_test.go')
    target = out / source.name
    shutil.copyfile(source, target)
    mapping[str(repo / 'pts' / package / source.name)] = str(target)
for label in ['base', 'current']:
    replaces = dict(mapping)
    if label == 'base':
        replaces[str(repo / 'pts/lower/destructured_container_sources.go')] = str(scratch / 'destructured-base.go')
    overlay = out / (label + '.overlay.json')
    overlay.write_text(json.dumps({'Replace': replaces}) + '\n')
    command = ['go', 'test', '-overlay', str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', '-run', '^TestD215Review', './pts/lower', './pts/driver']
    (out / (label + '.command.json')).write_text(json.dumps(command) + '\n')
    run = subprocess.run(command, cwd=repo, env=dict(os.environ, GOMAXPROCS='1'), capture_output=True, timeout=660)
    (out / (label + '.jsonl')).write_bytes(run.stdout)
    (out / (label + '.stderr')).write_bytes(run.stderr)
    (out / (label + '.exit')).write_text(str(run.returncode) + '\n')
    assert run.returncode == (1 if label == 'base' else 0), (label, run.returncode, run.stderr.decode())
    assert not run.stderr and b'build failed' not in run.stdout and b'panic:' not in run.stdout
    print(label, 'reviewer-input replay exit', run.returncode, flush=True)
