import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

scratch = Path(sys.argv[1])
out = scratch / 'repeated-c'
out.mkdir(exist_ok=False)
rows = json.loads((scratch / 'growth/results.json').read_text())
results = []
for row in rows:
    name = row['name']
    c = out / (name + '.c')
    command = [str(scratch / 'emit-current'), 'all', str(scratch / 'growth' / (name + '.pts')), str(c)]
    run = subprocess.run(command, env=dict(os.environ, GOMAXPROCS='1', PTS_HOME=sys.argv[2]), capture_output=True, timeout=600)
    (out / (name + '.stdout')).write_bytes(run.stdout)
    (out / (name + '.stderr')).write_bytes(run.stderr)
    assert run.returncode == 0, (command, run.returncode, run.stderr)
    digest = hashlib.sha256(c.read_bytes()).hexdigest()
    assert digest == row['current']['sha256'], (name, digest, row['current']['sha256'])
    results.append(dict(name=name, sha256=digest, reproduced=True))
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print('All', len(results), 'current C hashes reproduced exactly', flush=True)
