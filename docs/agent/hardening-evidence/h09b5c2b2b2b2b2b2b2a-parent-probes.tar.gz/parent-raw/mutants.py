import json
import os
from pathlib import Path
import subprocess
import sys

repo, out = map(Path, sys.argv[1:3])
out.mkdir(exist_ok=False)
pattern_file = 'pts/lower/destructured_container_sources.go'
cases = [
    ('compact_indices', pattern_file, 'key := strconv.Itoa(index)', 'key := strconv.Itoa(index * 0)', '^TestElidedContainerSourcesSelectTheirOriginalLiteralIndices$/^receivers_false$/^leading$'),
    ('uncharged_omissions', pattern_file, 'if !containerStep(steps, &memberDepth) || element.Kind != ast.KindBindingElement ||', 'if !(element.Name() == nil || containerStep(steps, &memberDepth)) || element.Kind != ast.KindBindingElement ||', '^TestElidedContainerOmissionsSpendWorkWithoutInventingBindings$'),
    ('skip_pattern_siblings', pattern_file, 'for index, element := range pattern.AsBindingPattern().Elements.Nodes {', 'for index, element := range pattern.AsBindingPattern().Elements.Nodes {\n\t\tif index > 0 { break }', '^TestArrayPatternContainerUnsafeUsesPoisonEverySibling$/^passed_sibling$'),
    ('ignore_raw_contract', 'pts/lower/container_sources.go', 'if from == to {', 'if true {', '^TestElidedContainerRawContractsPoisonTheWholeRoot$'),
    ('publish_partial_component', 'pts/lower/container_sources.go', 'if !complete {', 'if !complete && tree == nil {', '^TestElidedContainerUnsafeUsesPoisonSkippedAndSelectedSubtrees$/^passed_sibling$'),
]
results = []
for name, source, old, new, pattern in cases:
    text = (repo / source).read_text()
    assert text.count(old) == 1, (name, old)
    mutant = out / (name + '.go')
    mutant.write_text(text.replace(old, new))
    overlay = out / (name + '.overlay.json')
    overlay.write_text(json.dumps({'Replace': {str(repo / source): str(mutant)}}) + '\n')
    command = ['go', 'test', '-overlay', str(overlay), '-count=1', '-json', '-p', '1', '-parallel', '1', '-timeout', '10m', '-run', pattern, './pts/lower']
    result = subprocess.run(command, cwd=repo, env=dict(os.environ, GOMAXPROCS='1'), text=True, capture_output=True, timeout=660)
    (out / (name + '.jsonl')).write_text(result.stdout)
    (out / (name + '.stderr')).write_text(result.stderr)
    (out / (name + '.command.json')).write_text(json.dumps(command) + '\n')
    events = [json.loads(line) for line in result.stdout.splitlines()]
    failures = [e['Test'] for e in events if e.get('Action') == 'fail' and e.get('Test')]
    assert result.returncode == 1 and failures, (name, result.returncode, failures, result.stderr)
    assert 'build failed' not in result.stdout + result.stderr and 'panic:' not in result.stdout + result.stderr, name
    assert 'assertion failed' in result.stdout, name
    results.append(dict(mutant=name, exit=result.returncode, compiles=True, assertion_killed=True, failed_tests=failures))
    (out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print(name, 'compiled and assertion-killed', flush=True)
