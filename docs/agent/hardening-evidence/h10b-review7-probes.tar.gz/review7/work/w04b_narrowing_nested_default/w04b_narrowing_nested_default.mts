// A nested pattern with a default from an `object` narrowing (D-218's PTS1001 expected).
class Box<T> {
  meta: { tags?: T[] } = { tags: [] };
  constructor(public v: T) {}
}
function run(o: object): number {
  if (!(o instanceof Box)) return -1;
  let tags: any[] = [];
  ({ meta: { tags = [] } } = o);
  tags.push(1);
  return tags.length;
}
const n = new Box<number>(0);
console.log(run(n), JSON.stringify(n.meta.tags));
