// Defaults in destructuring assignments with side effects: order of target references,
// source getters and defaults (JS: for each property, the target's reference, then the
// read, then the default if undefined, then the store), for a typed source and a Box<any>
// place's value; defaults that are used and not; nested defaults; a default reading an
// earlier target.
const log: string[] = [];
const def = <X>(tag: string, x: X): X => { log.push("def:" + tag); return x; };
const holder = { p: 0, q: 0 };
const target = (tag: string) => { log.push("target:" + tag); return holder; };
class Src { get a(): number | undefined { log.push("get:a"); return undefined; } get b(): number | undefined { log.push("get:b"); return 5; } }
class Box<T> {
  get a(): T | undefined { log.push("get:a"); return undefined; }
  get b(): number | undefined { log.push("get:b"); return 5; }
  meta?: { tags?: T[] };
  constructor(public v: T) {}
}
function show(name: string): void { console.log(name, JSON.stringify(holder), log.join(",")); log.length = 0; holder.p = 0; holder.q = 0; }
const s = new Src();
({ a: target("1").p = def("1", 1), b: target("2").q = def("2", 2) } = s);
show("typed");
const b: Box<any> = new Box<any>(0);
({ a: target("1").p = def("1", 1), b: target("2").q = def("2", 2) } = b);
show("place");
let x = 0, y = 0;
({ a: x = def("x", 3), b: y = def("y", 4) } = b);
console.log("locals", x, y, log.join(",")); log.length = 0;
let tags: any[] = [];
({ meta: { tags = def("tags", [7] as any[]) } = def("meta", {} as { tags?: any[] }) } = b);
console.log("nested", JSON.stringify(tags), log.join(",")); log.length = 0;
b.meta = { tags: [8] as any[] };
({ meta: { tags = def("tags", [7] as any[]) } = def("meta", {} as { tags?: any[] }) } = b);
console.log("nested present", JSON.stringify(tags), log.join(",")); log.length = 0;
let c = 0, d = 0;
({ a: c = 1, b: d = c + 1 } = { a: undefined, b: undefined } as { a?: number; b?: number });
console.log("earlier target", c, d);
let first: number | undefined = 0, second: number | undefined = 0;
[first = def("f", 1), second = def("s", 2)] = [undefined, 9] as (number | undefined)[];
console.log("array", first, second, log.join(",")); log.length = 0;
