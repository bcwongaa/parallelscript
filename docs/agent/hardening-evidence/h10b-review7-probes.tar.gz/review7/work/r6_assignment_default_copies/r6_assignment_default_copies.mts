// R6-F1: a destructuring assignment whose target has a default (`({ opt = [] } = b)`) copies
// the member silently for a Box<number> in a Box<any> place, also renamed, nested and from
// an `unknown` narrowing: dynamicWithDefault converts the present value plainly before
// convertMember's rule (R5-F4's as-is TypeError) sees it. Without the default, and in
// declarations with a default, it is the as-is TypeError.
class Box<T> {
  opt?: T[];
  items: T[] = [];
  meta: { tags?: T[] } = {};
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
function forms(b: Box<any>): void {
  t("shorthand default", () => { let opt: any[] = []; ({ opt = [] } = b); opt.push("s"); return opt.length; });
  t("renamed default", () => { let o: any[] = []; ({ opt: o = [] } = b); o.push("r"); return o.length; });
  t("nested default", () => { let tags: any[] = []; ({ meta: { tags = [] } } = b); tags.push("n"); return tags.length; });
  t("no default", () => { let items: any[] = []; ({ items } = b); return items.length; });
  t("declaration default", () => { const { opt = [] } = b; return opt.length; });
}
function fromUnknown(u: unknown): void {
  if (u instanceof Box) t("unknown default", () => { let opt: any[] = []; ({ opt = [] } = u); opt.push("u"); return opt.length; });
}
const n = new Box<number>(0); n.opt = []; n.meta.tags = [];
forms(n);
fromUnknown(n);
console.log(JSON.stringify(n.opt), JSON.stringify(n.meta.tags));
// Node: shorthand default 1 / renamed default 2 / nested default 1 / no default 0 /
// declaration default 2 / unknown default 3 / ["s","r","u"] ["n"]
