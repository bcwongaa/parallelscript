// Pre-existing: `new Array<number>(n)` has holes in JS (`0 in a` false); written elements aren't.
const a: number[] = new Array<number>(3);
a[1] = 5;
console.log(0 in a, 1 in a, a.length);
