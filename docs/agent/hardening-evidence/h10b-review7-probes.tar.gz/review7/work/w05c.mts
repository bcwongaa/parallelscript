// Cost of `k in o` on plain objects and maps through `any` and with a computed key.
const o: Record<string, number> = { a: 1, b: 2 };
const plain = { a: 1, b: 2 };
const anyObj: any = plain;
const m: any = new Map([["a", 1]]);
const keys = ["a", "b", "c"];
let hits = 0;
const t0 = Date.now();
for (let r = 0; r < 1000000; r++) for (const k of keys) if (k in anyObj) hits++;
const t1 = Date.now();
for (let r = 0; r < 1000000; r++) for (const k of keys) if (k in m) hits++;
const t2 = Date.now();
for (let r = 0; r < 1000000; r++) for (const k of keys) if (k in o) hits++;
const t3 = Date.now();
console.log(hits);
console.error("object ms", t1 - t0, "map ms", t2 - t1, "record ms", t3 - t2);
