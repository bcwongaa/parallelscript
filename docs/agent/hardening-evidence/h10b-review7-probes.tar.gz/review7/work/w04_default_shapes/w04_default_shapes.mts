// Defaults in destructuring assignments under the new rule: a default used for a
// Box<number> whose member is absent (a fresh default, must not throw), a member target
// (`{ opt: holder.list = [] }`), scalar parts, and a default over a present scalar.
class Box<T> {
  opt?: T[];
  label?: string;
  count?: number;
  constructor(public v: T) {}
}
const t = (name: string, f: () => unknown) => {
  try { console.log(name, JSON.stringify(f())); } catch (e) { console.log(name, (e as Error).name); }
};
const holder: { list: any[] } = { list: [] };
function forms(b: Box<any>, tag: string): void {
  t("absent default", () => { let opt: any[] = ["x"]; ({ opt = [] } = b); opt.push(tag); return opt; });
  t("member target", () => { ({ opt: holder.list = [] } = b); holder.list.push(tag + "m"); return holder.list.length; });
  t("scalars", () => { let label = "", count = 0; ({ label = "dflt", count = 9 } = b); return [label, count]; });
}
const nAbsent = new Box<number>(0);
forms(nAbsent, "na");
const nSet = new Box<number>(0); nSet.opt = []; nSet.label = "L"; nSet.count = 1;
forms(nSet, "ns");
const aSet = new Box<any>(0); aSet.opt = []; aSet.label = "A";
forms(aSet, "as");
console.log(JSON.stringify(nAbsent.opt), JSON.stringify(nSet.opt), JSON.stringify(aSet.opt));
