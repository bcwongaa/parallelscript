// R6-F1, narrowing form: `({ opt = [] } = o)` for an `object` narrowing copies the array
// silently (base too), where the same assignment without the default is D-218's PTS1001 on
// snapshot 8 (`({ opt } = o)`), as `opt = o.opt` is on the base.
class Box<T> {
  opt?: T[];
  constructor(public v: T) {}
}
function run(o: object): number {
  if (!(o instanceof Box)) return -1;
  let opt: any[] = [];
  ({ opt = [] } = o);
  opt.push(1);
  return opt.length;
}
const n = new Box<number>(0); n.opt = [];
console.log(run(n), JSON.stringify(n.opt));
// Node: 1 [1]
