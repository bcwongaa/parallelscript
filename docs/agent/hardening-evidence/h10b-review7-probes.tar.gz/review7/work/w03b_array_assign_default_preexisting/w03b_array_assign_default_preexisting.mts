// Pre-existing (all builds): defaults in array patterns of destructuring assignments.
let a: number | undefined = 0;
[a = 1] = [undefined] as (number | undefined)[];
let b = 0;
[b = 2] = [] as number[];
let c: number | undefined = 0, d = 0;
[c = 3, d = 4] = [undefined, 5] as any[];
const e = 6;
let f = 0;
({ f = 7 } = {} as { f?: number });
console.log(a, b, c, d, e, f);
