// R6-F2's broader `in`: keys through `any` on every library kind, ones JS finds on the
// prototype (or the object) and ones it doesn't: which answers changed from the base, and
// whether Node agrees.
class Item { n = 1; get g(): number { return 2; } m(): number { return 3; } }
function* gen(): Generator<number> { yield 1; }
function declared(a: number, b: number): number { return a + b; }
const cases: [string, any, string[]][] = [
  ["array", [1, 2], ["push", "map", "length", "0", "5", "toString", "constructor", "hasOwnProperty", "copyWithin", "valueOf", "nope", "size"]],
  ["match", /a(b)/.exec("ab"), ["index", "input", "groups", "push", "1", "nope"]],
  ["tuple", [1, "a"] as [number, string], ["push", "length", "1", "nope"]],
  ["map", new Map([["k", 1]]), ["size", "get", "set", "forEach", "entries", "constructor", "k", "nope", "push"]],
  ["set", new Set([1]), ["size", "add", "has", "union", "1", "nope"]],
  ["function", declared, ["call", "apply", "bind", "length", "name", "prototype", "toString", "nope"]],
  ["arrow", (x: number) => x, ["call", "length", "name", "prototype", "nope"]],
  ["promise", Promise.resolve(1), ["then", "catch", "finally", "constructor", "nope"]],
  ["date", new Date(0), ["getTime", "toISOString", "toLocaleDateString", "constructor", "nope"]],
  ["regexp", /a/g, ["exec", "test", "lastIndex", "source", "flags", "global", "toString", "nope"]],
  ["typed", new Uint8Array(2), ["subarray", "fill", "length", "map", "set", "0", "2", "byteLength", "nope"]],
  ["generator", gen(), ["next", "return", "throw", "nope"]],
  ["object", { a: 1 }, ["a", "toString", "hasOwnProperty", "constructor", "nope"]],
  ["record", { z: 1 } as Record<string, number>, ["z", "toString", "nope"]],
  ["instance", new Item(), ["n", "g", "m", "toString", "constructor", "nope"]],
  ["error", new Error("x"), ["message", "name", "stack", "toString", "nope"]],
];
for (const [name, value, keys] of cases) {
  console.log(name, keys.map((k) => k + "=" + (k in value ? 1 : 0)).join(" "));
}
