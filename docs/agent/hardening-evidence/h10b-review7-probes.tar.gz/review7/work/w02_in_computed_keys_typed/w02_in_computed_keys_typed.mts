// `k in o` with a key computed at run time on typed values (computedKeyIn boxes them into
// DynamicHas): arrays, maps, sets, functions, promises, a union-typed value, a typed class
// instance; also a loop over keys as a program checking capabilities would write.
const keys: string[] = ["push", "size", "get", "length", "then", "nope"];
const arr: number[] = [1];
const map = new Map<string, number>();
const set = new Set<number>();
const fn = (x: number): number => x;
const p: Promise<number> = Promise.resolve(1);
const either: number[] | Map<string, number> = Math.random() > 2 ? arr : map;
for (const k of keys) {
  console.log(k, k in arr, k in map, k in set, k in fn, k in p, k in either);
}
function capabilities(x: object): string[] { return ["forEach", "then", "size", "length"].filter((k) => k in x); }
console.log(capabilities(arr).join(","), "|", capabilities(map).join(","), "|", capabilities(p).join(","), "|", capabilities({ length: 1 }).join(","));
