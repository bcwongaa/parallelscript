// Cost of `i in arr` (a computed key: DynamicHas) in a hot loop, now that pts_dynamic_has
// looks the key up among the builtin methods before the index test; and through `any`.
const arr: number[] = new Array<number>(1000);
for (let i = 0; i < 1000; i++) if (i % 3 !== 0) arr[i] = i;
const anyArr: any = arr;
let hits = 0;
const t0 = Date.now();
for (let r = 0; r < 5000; r++) for (let i = 0; i < 1000; i++) if (i in arr) hits++;
const t1 = Date.now();
for (let r = 0; r < 5000; r++) for (let i = 0; i < 1000; i++) if (i in anyArr) hits++;
const t2 = Date.now();
console.log(hits);
console.error("typed ms", t1 - t0, "any ms", t2 - t1);
