// A default over a scalar member of an `object` narrowing: nothing to copy, so it runs.
class Box<T> {
  label?: string;
  constructor(public v: T) {}
}
function run(o: object): string {
  if (!(o instanceof Box)) return "";
  let label = "";
  ({ label = "dflt" } = o);
  return label;
}
const n = new Box<number>(0); const m = new Box<number>(0); m.label = "set";
console.log(run(n), run(m));
