#!/bin/bash
# fb7.sh FILE6...: emit-c with the snap6 and snap7 fallback-trace CLIs (path /tmp/h09/snap6/ -> /tmp/h09/snap7/ for the
# second): fallback used, exit codes, C lines, C same (paths normalized)
for f in "$@"; do f7=${f/\/tmp\/h09\/snap6\//\/tmp\/h09\/snap7\/}; d=$(mktemp -d /tmp/h09/review5/run/fb.XXXX)
  a=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap6 timeout 300 /tmp/h09/review4/ov/pts-trace6 emit-c "$f" -o $d/a.c 2>&1); ea=$?
  b=$(cd $d && PTS_TRACE_FALLBACK=1 PTS_HOME=/tmp/h09/snap7 timeout 300 /tmp/h09/review5/ov/pts-trace7 emit-c "$f7" -o $d/b.c 2>&1); eb=$?
  fa=$(echo "$a" | grep -c '^PTS_FALLBACK'); fb=$(echo "$b" | grep -c '^PTS_FALLBACK')
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  same=$( [ -f $d/a.c ] && [ -f $d/b.c ] && cmp -s <(sed "s#/tmp/h09/snap6/#X/#g" $d/a.c) <(sed "s#/tmp/h09/snap7/#X/#g" $d/b.c) && echo Csame || echo Cdiff)
  echo "s6FB=$fa s7FB=$fb exit=$ea/$eb lines=$la/$lb $same $f7"
  rm -rf $d
done
