#!/bin/bash
# sweep5.sh OUT FILE...: base, snap6, snap7 and Node outputs into OUT/<dir>__<name>.{b,6,7,n} (b, 6, n reused if present)
out=$1; shift; mkdir -p $out; node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); tag=$(basename $(dirname $f))__$b; d=$(mktemp -d /tmp/h09/review5/run/s.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  [ -f $out/$tag.b ] || (cd "$d" && PTS_HOME=/tmp/h09/base timeout 300 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.b
  [ -f $out/$tag.6 ] || (cd "$d" && PTS_HOME=/tmp/h09/snap6 timeout 300 /tmp/h09/snap6/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.6
  (cd "$d" && PTS_HOME=/tmp/h09/snap7 timeout 300 /tmp/h09/snap7/pts-bin/pts run "$f" 2>&1; echo "[exit $?]") > $out/$tag.7
  [ -f $out/$tag.n ] || (cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]") > $out/$tag.n
  rm -rf "$d"
  c() { cmp -s $out/$tag.$1 $out/$tag.$2 && echo "$1=$2" || echo "$1!$2"; }
  echo "$(c b n) $(c 6 n) $(c 7 n) $(c 6 7) $(c b 7) $tag"
done
