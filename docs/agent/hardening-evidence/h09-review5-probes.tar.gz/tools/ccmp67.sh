#!/bin/bash
# ccmp67.sh FILE...: emit-c with snap6 and snap7 CLIs; "Csame"/"Cdiff" (or Esame/Ediff on errors), exit codes, lines
for f in "$@"; do d=$(mktemp -d /tmp/h09/review5/run/cc.XXXX)
  (cd $d && PTS_HOME=/tmp/h09/snap6 timeout 300 /tmp/h09/snap6/pts-bin/pts emit-c "$f" -o $d/a.c >$d/a.err 2>&1); ea=$?
  (cd $d && PTS_HOME=/tmp/h09/snap7 timeout 300 /tmp/h09/snap7/pts-bin/pts emit-c "$f" -o $d/b.c >$d/b.err 2>&1); eb=$?
  la=$([ -f $d/a.c ] && wc -l < $d/a.c || echo 0); lb=$([ -f $d/b.c ] && wc -l < $d/b.c || echo 0)
  if [ -f $d/a.c ] && [ -f $d/b.c ]; then cmp -s $d/a.c $d/b.c && s=Csame || s=Cdiff; else cmp -s $d/a.err $d/b.err && s=Esame || s=Ediff; fi
  echo "$s exit=$ea/$eb lines=$la/$lb $f"; rm -rf $d
done
