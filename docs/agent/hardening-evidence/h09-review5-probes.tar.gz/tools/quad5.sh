#!/bin/bash
# quad5.sh FILE...: base, snap6 ($S5), snap7 ($FIX) and Node (.mts copy). Status: B/6/7 vs N, 6 vs 7, B vs 7.
# QUIET=1 prints outputs only when something differs from Node or 6 != 7.
FIX=${FIX:-/tmp/h09/snap7}; S5=${S5:-/tmp/h09/snap6}; BASE=${BASE:-/tmp/h09/base}
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review5/run/q.XXXX)
  cp "$f" "$d/$b.mts"; [ -d "$(dirname $f)/mods" ] && cp -r "$(dirname $f)/mods" "$d/"
  bo=$(cd "$d" && PTS_HOME=$BASE timeout 300 $BASE/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  fo=$(cd "$d" && PTS_HOME=$S5 timeout 300 $S5/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  so=$(cd "$d" && PTS_HOME=$FIX timeout 300 $FIX/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  st="B$([ "$bo" == "$no" ] && echo = || echo '!')N 6$([ "$fo" == "$no" ] && echo = || echo '!')N 7$([ "$so" == "$no" ] && echo = || echo '!')N 6$([ "$fo" == "$so" ] && echo = || echo "!")7 B$([ "$bo" == "$so" ] && echo = || echo "!")7"
  echo "== $b: $st"
  if [ "${QUIET:-}" != 1 ] || [ "$fo" != "$so" ] || [ "$so" != "$no" ]; then
    echo "-- base"; echo "$bo"
    if [ "$fo" == "$so" ]; then echo "-- snap6=snap7"; echo "$so"; else echo "-- snap6"; echo "$fo"; echo "-- snap7"; echo "$so"; fi
    [ "$so" != "$no" ] && { echo "-- node"; echo "$no"; }
  fi
  rm -rf "$d"
done
