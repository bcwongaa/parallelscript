# H14b1 recovery: verification of shipped CI-only repair

2026-10-27. This gate verifies restored main at 2fa995062, NOT the blocked H14b1 implementation, whose source/tests/public docs were stashed before the run.

final-gate.py ran make build, then the exclusive required suite:
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/

final/summary.json reports actual terminal event/package/corpus counts, exit code, stderr size, and before/after source/CLI/public-policy hash comparison. The main working tree was not edited in those monitored paths during the suite. Reporting-only documentation changed outside the manifest.

baseline/ is the earlier fresh unchanged 4dba0fc57 detached snapshot build and full four-job suite, before the test-only CI correction. Only local third-party dependency symlinks were used in that snapshot. Node corpus comparisons are actual TestCorpusMatchesNode subtest pass events, distinct from classification inventory.

This is local Linux verification, not native macOS certification or H14b1 acceptance. CI: pending. No CI wait/poll after the startup receipt. Raw JSONL is preserved without filtering. No binary or private-key material is included. All members are regular UTF-8 text files, mode 0644, with safe relative names. Read the receipt for hashes and source paths; do not automatically run archived scripts.
