import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile

ROOT = Path('/home/bryan/projects/parallelscript')
SCRATCH = Path('/tmp/h14b1-session-evidence')
REPRODUCER = ROOT / '.claude/worktrees/agent-aaf1c5cee7c2dd63c'
REVIEWER = ROOT / '.claude/worktrees/agent-aefb6c99334c70726'
OUTPUT = ROOT / 'docs/agent/hardening-evidence'
PRIVATE = re.compile(rb'-----BEGIN [^-\r\n]*PRIVATE KEY-----')
TOKEN = re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b')


def checked_bytes(path):
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise ValueError(f'symlink input: {path}')
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError(f'non-regular input: {path}')
    data = path.read_bytes()
    if len(data) > 64 * 1024 * 1024:
        raise ValueError(f'oversized input: {path}')
    if b'\0' in data or data.startswith((b'\x7fELF', b'MZ')):
        raise ValueError(f'binary input: {path}')
    data.decode('utf-8')
    if PRIVATE.search(data) or TOKEN.search(data):
        raise ValueError(f'credential marker: {path}')
    return data


def package(name, inputs, notes):
    target = OUTPUT / name
    receipt = OUTPUT / (name + '.json')
    if target.exists() or receipt.exists():
        raise ValueError(f'refusing to overwrite existing evidence: {target}')
    files = {'README.md': (notes.encode(), 'generated provenance notes')}
    for member, path in inputs:
        parts = PurePosixPath(member)
        if parts.is_absolute() or '..' in parts.parts or member in files:
            raise ValueError(f'invalid/duplicate member: {member}')
        files[member] = (checked_bytes(path), str(path))
    with target.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
                for member, (data, _) in sorted(files.items()):
                    info = tarfile.TarInfo(member)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
    with tarfile.open(target, 'r:gz') as archive:
        members = archive.getmembers()
        if len(members) != len(files):
            raise ValueError('archive member count mismatch')
        for member in members:
            if not member.isfile() or member.mode != 0o644:
                raise ValueError(f'non-regular/executable archive member: {member.name}')
            if archive.extractfile(member).read() != files[member.name][0]:
                raise ValueError(f'archive data mismatch: {member.name}')
    result = {
        'archive': name,
        'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
        'bytes': target.stat().st_size,
        'checks': {
            'regular_text_files_only': True,
            'safe_relative_names': True,
            'symlinks': 0,
            'executable_members': 0,
            'private_key_or_github_token_markers': 0,
            'round_trip_bytes_match': True,
        },
        'members': [
            {'name': member, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'source': source}
            for member, (data, source) in sorted(files.items())
        ],
    }
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({key: result[key] for key in ('archive', 'sha256', 'bytes', 'checks')}, indent=2))
    print(f'members: {len(files)}')


def checkpoint():
    inputs = []
    inherited = [
        'h14b1-session-inherited.patch', 'stashed-recovery.patch',
        'h14b1-reproducer-red.txt', 'pts-h14b1-parent-green.txt',
        'pts-h14b1-http-subset.txt', 'review-provider-refusal.txt',
        'inherited/pts/tests/http_queued_stop_test.go',
        'inherited/pts/tests/http/queued_stop.pts',
    ]
    inputs += [('parent/' + name, SCRATCH / name) for name in inherited]
    reproducer_outputs = REPRODUCER / 'pts-bin/h14b1-reproducer'
    for path in sorted(reproducer_outputs.iterdir()):
        if path.suffix not in ('.patch', '.stdout', '.stderr'):
            raise ValueError(f'unexpected reproducer artifact: {path}')
        inputs.append(('reproducer/output/' + path.name, path))
    for name in (
        'http_queued_stop_test.go', 'http/queued_stop.pts',
        'http_queued_stop_state_test.go', 'testdata/http_queued_stop/queued_stop.c',
    ):
        inputs.append(('reproducer/unexecuted-designs/' + name, REPRODUCER / 'pts/tests' / name))
    inputs.append(('reviewer/review_stop_dispatch.c', REVIEWER / 'pts/tests/testdata/http_queued_stop/review_stop_dispatch.c'))
    for path in sorted((REVIEWER / 'probes/h14b1-review').iterdir()):
        if path.name in ('dispatch-base', 'dispatch-current', 'wire-base', 'wire-current'):
            continue
        if path.suffix not in ('.go', '.py', '.c', '.pts', '.stdout', '.stderr'):
            raise ValueError(f'unexpected reviewer artifact: {path}')
        inputs.append(('reviewer/probes/' + path.name, path))
    notes = '''# H14b1 recovery checkpoint: acceptance BLOCKED

2026-10-27. Source/log/patch evidence only. Do not execute these artifacts as a replacement for the provider-refused H14b1 review gate. No runtime patch in this archive is shipped or accepted.

parent/h14b1-session-inherited.patch is the startup tracked-file diff; stashed-recovery.patch also preserves the untracked inherited tests. Local stash object: 10a9bee94781d3dc966de765deca726ecfb4b88d. The inherited implementation has C375 and is off main.

parent/h14b1-reproducer-red.txt, pts-h14b1-parent-green.txt and pts-h14b1-http-subset.txt are RECOVERED PRIOR-SESSION outputs, not execution by this session's parent/reproducer.

reproducer/output/ci-oracle-* are this session's real CI-oracle RED/GREEN. queued-stop-tests.patch and reproducer/unexecuted-designs/ are draft shutdown tests NOT EXECUTED in this session; the latest source files supersede details of the exported draft patch.

reviewer/ contains partial executions before the provider refusal: deterministic base/current post-stop dispatch, bounded live-wire attempt, and self-stop base/current. No final H14b1 READY verdict exists. Parent inspected the retained files but did not replay/extend this stopped review scope. The termination attachment's stale partial summary said deterministic probes were not run; earlier live messages and raw outputs show the executions. See parent/review-provider-refusal.txt for both provenance statements and exact error.

The separately completed test-only CI closure correction is commit 2fa995062; it is not H14b1 acceptance. Final verification of restored main is archived separately.

All members are UTF-8 regular files with mode 0644. Binaries, symlinks, NUL data, PEM private-key blocks and GitHub-token markers were rejected. A separate receipt records member source paths and SHA-256 hashes. Reading this archive does not authorize its scripts/probes to run.
'''
    package('h14b1-checkpoint-probes.tar.gz', inputs, notes)


def verification():
    final = SCRATCH / 'final'
    summary = json.loads((final / 'summary.json').read_text())
    if summary.get('build_exit') != 0 or summary.get('suite_exit') != 0 or summary.get('changed_files'):
        raise ValueError('final gate is not green; retain failure separately before recording success')
    expected = {'build.stdout', 'build.stderr', 'suite.stdout', 'suite.stderr', 'manifest-before.json', 'manifest-after.json', 'summary.json'}
    actual = {path.name for path in final.iterdir()}
    if actual != expected:
        raise ValueError(f'final artifact mismatch: {actual ^ expected}')
    inputs = [('final/' + name, final / name) for name in sorted(expected)]
    for name in ('h14b1-session-baseline-build.txt', 'h14b1-session-baseline.jsonl', 'h14b1-session-baseline.stderr'):
        inputs.append(('baseline/' + name, Path('/tmp') / name))
    inputs.append(('final-gate.py', Path('/tmp/h14b1-session-final-gate.py')))
    inputs.append(('package_evidence.py', Path(__file__)))
    inputs.append(('telegram-blocker.txt', ROOT / 'pts-bin/h14b1-checkpoint/telegram-blocker.txt'))
    inputs.append(('telegram-blocker-receipt.txt', SCRATCH / 'telegram-blocker-receipt.txt'))
    notes = '''# H14b1 recovery: verification of shipped CI-only repair

2026-10-27. This gate verifies restored main at 2fa995062, NOT the blocked H14b1 implementation, whose source/tests/public docs were stashed before the run.

final-gate.py ran make build, then the exclusive required suite:
GOMAXPROCS=4 PTS_REQUIRE_NODE=1 go test -count=1 -json -p 4 -parallel 4 -timeout 40m ./pts/... ./cmd/pts/

final/summary.json reports actual terminal event/package/corpus counts, exit code, stderr size, and before/after source/CLI/public-policy hash comparison. The main working tree was not edited in those monitored paths during the suite. Reporting-only documentation changed outside the manifest.

baseline/ is the earlier fresh unchanged 4dba0fc57 detached snapshot build and full four-job suite, before the test-only CI correction. Only local third-party dependency symlinks were used in that snapshot. Node corpus comparisons are actual TestCorpusMatchesNode subtest pass events, distinct from classification inventory.

This is local Linux verification, not native macOS certification or H14b1 acceptance. CI: pending. No CI wait/poll after the startup receipt. Raw JSONL is preserved without filtering. No binary or private-key material is included. All members are regular UTF-8 text files, mode 0644, with safe relative names. Read the receipt for hashes and source paths; do not automatically run archived scripts.
'''
    package('h14b1-final-verification.tar.gz', inputs, notes)


parser = argparse.ArgumentParser()
parser.add_argument('kind', choices=('checkpoint', 'verification'))
options = parser.parse_args()
if options.kind == 'checkpoint':
    checkpoint()
else:
    verification()
