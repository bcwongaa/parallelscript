import collections
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root = Path('/home/bryan/projects/parallelscript')
out = Path('/tmp/h14b1-session-evidence/final')
out.mkdir()
env = dict(os.environ, GOMAXPROCS='4', PTS_REQUIRE_NODE='1')

def run(command, prefix, timeout):
    with (out / (prefix + '.stdout')).open('wb') as stdout, (out / (prefix + '.stderr')).open('wb') as stderr:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            return process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
            return 124

def manifest():
    paths = []
    index = subprocess.check_output(['git', 'ls-files', '-s', '-z', '--', 'pts', 'cmd/pts', 'docs/SPEC.md', 'docs/GUIDE.md', 'docs/ARCHITECTURE.md'], cwd=root)
    for item in index.split(b'\0'):
        if not item:
            continue
        metadata, path = item.split(b'\t', 1)
        if metadata.startswith(b'160000'):
            continue
        paths.append(os.fsdecode(path))
    paths.append('pts-bin/pts')
    return {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in paths if (root / path).is_file()}

started = time.monotonic()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
build = run(['make', 'build'], 'build', 600)
if build:
    (out / 'summary.json').write_text(json.dumps({'head': head, 'build_exit': build, 'suite': 'not run'}, indent=2) + '\n')
    raise SystemExit(build)
before = manifest()
(out / 'manifest-before.json').write_text(json.dumps(before, indent=2) + '\n')
command = ['go', 'test', '-count=1', '-json', '-p', '4', '-parallel', '4', '-timeout', '40m', './pts/...', './cmd/pts/']
result = run(command, 'suite', 2500)
after = manifest()
(out / 'manifest-after.json').write_text(json.dumps(after, indent=2) + '\n')
counts = collections.Counter()
corpus = collections.Counter()
packages = {}
failures = []
for line in (out / 'suite.stdout').open():
    try:
        event = json.loads(line)
    except json.JSONDecodeError:
        continue
    action, test = event.get('Action'), event.get('Test')
    if test and action in ('pass', 'skip', 'fail'):
        counts[action] += 1
        if test.startswith('TestCorpusMatchesNode/'):
            corpus[action] += 1
        if action == 'fail':
            failures.append(test)
    elif not test and action in ('pass', 'skip', 'fail'):
        packages[event.get('Package')] = action
changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
summary = {'head': head, 'build_exit': build, 'suite_exit': result, 'elapsed_seconds': time.monotonic() - started, 'events': dict(counts), 'corpus': dict(corpus), 'packages': packages, 'failures': failures, 'monitored_files': len(before), 'changed_files': changed, 'suite_stderr_bytes': (out / 'suite.stderr').stat().st_size}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
raise SystemExit(result or bool(changed))
