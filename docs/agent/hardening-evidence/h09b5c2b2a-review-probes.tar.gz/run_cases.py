import argparse
import json
import os
from pathlib import Path
import subprocess


def execute(command, env):
    try:
        result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                env=env, timeout=120, check=False)
        return {"command": command, "exit": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    except subprocess.TimeoutExpired as error:
        return {"command": command, "exit": "timeout", "stdout": str(error.stdout), "stderr": str(error.stderr)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--home", required=True)
    parser.add_argument("--node", required=True)
    parser.add_argument("--strict", required=True)
    parser.add_argument("--base-strict")
    parser.add_argument("--out", required=True)
    parser.add_argument("cases", nargs="+")
    args = parser.parse_args()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, PTS_HOME=args.home, GOMAXPROCS="1", PTS_THREADS="1")
    records = []
    for source_arg in args.cases:
        source = Path(source_arg).resolve()
        case = out / source.stem
        case.mkdir()
        node_source = case / "oracle.mts"
        node_source.write_text(source.read_text())
        record = {"source": str(source), "node": execute([args.node, "--no-warnings", "--experimental-transform-types", str(node_source)], env)}
        for name, strict in [("base", args.base_strict), ("fix", args.strict)]:
            if strict is None:
                continue
            binary = case / (name + ".bin")
            cfile = case / (name + ".c")
            build = execute([strict, "-out", str(cfile), "-build", str(binary), str(source)], env)
            result = {"build": build}
            if build["exit"] == 0:
                result["run"] = execute([str(binary)], env)
                result["node_match"] = (result["run"]["exit"] == record["node"]["exit"] and result["run"]["stdout"] == record["node"]["stdout"])
            record[name] = result
            binary.unlink(missing_ok=True)
        records.append(record)
        print(json.dumps({"case": source.stem, "node_exit": record["node"]["exit"], **{
            name: {"build_exit": record[name]["build"]["exit"], "node_match": record[name].get("node_match"), "run_exit": record[name].get("run", {}).get("exit")}
            for name in ("base", "fix") if name in record
        }}), flush=True)
    (out / "results.json").write_text(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
