package lower

import (
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/internal/ast"
	"github.com/microsoft/typescript-go/internal/checker"
	"github.com/microsoft/typescript-go/pts/ir"
	"gotest.tools/v3/assert"
)

const reviewWrapperPrelude = `class Box<T> { constructor(public value: T) {} }
function first<T>(value: T): Box<T> { return new Box(value); }
`

func TestReviewWrapperOriginsRespectCheckerAndAncestorBudgets(t *testing.T) {
	for _, tt := range []struct {
		name, body string
		known bool
	}{
		{"top_level", "const probe = first.bind(undefined); probe;", true},
		{"parenthesized_bind", "const probe = (((first.bind)))(undefined); probe;", true},
		{"plain_function", "function outer(): void { const probe = first.bind(undefined); probe; } outer();", true},
		{"plain_class", "class Outer { run(): void { const probe = first.bind(undefined); probe; } }", true},
		{"generic_function", "function outer<U>(marker: U): void { const probe = first.bind(undefined); probe; } outer(0);", false},
		{"generic_class", "class Outer<U> { run(): void { const probe = first.bind(undefined); probe; } }", false},
		{"contextual_generic_arrow", "const outer: <U>(marker: U) => void = marker => { const probe = first.bind(undefined); probe; }; outer(0);", false},
		{"contextual_generic_expression", "const outer: <U>(marker: U) => void = function(marker) { const probe = first.bind(undefined); probe; }; outer(0);", false},
		{"nested_plain_arrow_in_generic", "function outer<U>(marker: U): void { const run = (): void => { const probe = first.bind(undefined); probe; }; run(); } outer(0);", false},
		{"deep_ancestry", strings.Repeat("if (true) {", maxValueFlowDepth+1) + "const probe = first.bind(undefined); probe;" + strings.Repeat("}", maxValueFlowDepth+1), false},
		{"deep_parenthesized_callee", "const probe = " + strings.Repeat("(", maxValueFlowDepth+2) + "first.bind" + strings.Repeat(")", maxValueFlowDepth+2) + "(undefined); probe;", false},
	} {
		t.Run(tt.name, func(t *testing.T) {
			l, probe := valueFlowProbe(t, reviewWrapperPrelude+tt.body)
			call := l.target(probe).ValueDeclaration.Initializer()
			assert.Equal(t, call.Kind, ast.KindCallExpression)
			source := l.wrapperSource(call.Expression())
			if tt.known {
				assert.Assert(t, source == call, "bind origin must be the complete call, not its .bind member")
			} else {
				assert.Assert(t, source == nil, "unknown generic or exhausted ancestor proof cannot become an origin")
			}
		})
	}
}

func TestReviewOnlyRegisteredWrappersHaveSourcesAndCachedUnknownIsSafe(t *testing.T) {
	l, probe := valueFlowProbe(t, reviewWrapperPrelude+"const probe = first.bind(undefined); probe;")
	call := l.target(probe).ValueDeclaration.Initializer()
	steps := maxValueFlowSteps
	assert.Assert(t, l.valueSources(probe, &steps, 0) == nil, "a bind-shaped call without actual registration stays unknown")
	l.specialization = AllInstances
	l.addForwarder(&ir.Func{}, &forwarder{source: l.wrapperSource(call.Expression())})
	steps = maxValueFlowSteps
	assert.Assert(t, l.valueSources(probe, &steps, 0) == nil, "a pre-registration cached unknown must not become empty or a stale exclusion")
	assert.Equal(t, len(l.valueFlow.active), 0)

	l, probe = valueFlowProbe(t, reviewWrapperPrelude+"const probe = first.bind(undefined); probe;")
	call = l.target(probe).ValueDeclaration.Initializer()
	l.specialization = AllInstances
	l.addForwarder(&ir.Func{}, &forwarder{source: l.wrapperSource(call.Expression())})
	steps = 0
	assert.Assert(t, l.valueSources(call, &steps, 0) == nil, "even an exact token requires proof budget")
	steps = 1
	sources := l.valueSources(call, &steps, 0)
	assert.Assert(t, sources != nil && sources[call])
	assert.Equal(t, len(sources), 1)
	assert.Equal(t, steps, 0)
}

func TestReviewRegistrationHonorsLevelAndErasureAndSurvivesRetakenCodeConservatively(t *testing.T) {
	for _, specialization := range []Specialization{ValueInstances, DeclaredInstances} {
		l, probe := valueFlowProbe(t, reviewWrapperPrelude+"const probe = first.bind(undefined); probe;")
		call := l.target(probe).ValueDeclaration.Initializer()
		l.specialization = specialization
		l.addForwarder(&ir.Func{}, &forwarder{source: l.wrapperSource(call.Expression())})
		assert.Equal(t, len(l.valueFlow.wrappers), 0)
		assert.Equal(t, len(l.erasedValues), 0)
	}
	l, probe := valueFlowProbe(t, reviewWrapperPrelude+"const probe = first.bind(undefined); probe;")
	call := l.target(probe).ValueDeclaration.Initializer()
	l.specialization = AllInstances
	l.subst = &substitution{erased: []*checker.Type{nil}}
	l.addForwarder(&ir.Func{}, &forwarder{source: l.wrapperSource(call.Expression())})
	assert.Equal(t, len(l.valueFlow.wrappers), 0)
	assert.Equal(t, len(l.erasedValues), 0)
	l.subst = nil
	l.droppedFuncs = map[*ir.Func]bool{}
	mark := l.tentatively()
	fn := &ir.Func{}
	l.addForwarder(fn, &forwarder{source: l.wrapperSource(call.Expression())})
	l.takeBack(mark, fn)
	assert.Equal(t, len(l.erasedValues), 1)
	assert.Assert(t, l.erasedValues[0].dropped)
	assert.Assert(t, l.valueFlow.wrappers[call], "tokens can remain sticky: they name AST families, not individual failed closures")
	l.addForwarder(&ir.Func{}, &forwarder{source: l.wrapperSource(call.Expression())})
	steps := maxValueFlowSteps
	sources := l.valueSources(probe, &steps, 0)
	assert.Assert(t, sources != nil && sources[call])
}

func TestReviewUnknownForwarderAndNamedDemandAreNeverFiltered(t *testing.T) {
	l, probe := valueFlowProbe(t, reviewWrapperPrelude+"const probe = first; probe;")
	assert.Assert(t, l.sourceMayReach(&demand{source: probe}, &erasedValue{forward: &forwarder{}}))
	foreign := &ast.Node{Kind: ast.KindCallExpression}
	assert.Assert(t, l.sourceMayReach(&demand{source: probe, name: "make"}, &erasedValue{forward: &forwarder{source: foreign}}))
	assert.Assert(t, l.sourceMayReach(&demand{source: probe, method: &genericFunc{}}, &erasedValue{forward: &forwarder{source: foreign}}))
}
