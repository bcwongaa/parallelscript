import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('root')
parser.add_argument('patch')
parser.add_argument('snapshot')
parser.add_argument('overlay')
args = parser.parse_args()
root = Path(args.root).resolve()
snapshot = Path(args.snapshot).resolve()
snapshot.mkdir(parents=True, exist_ok=False)
patch = Path(args.patch).resolve()
paths = re.findall(r'^diff --git a/(\S+) b/\1$', patch.read_text(), re.MULTILINE)
if not paths:
    raise RuntimeError('patch has no paths')
for name in paths:
    if not (name.startswith('pts/lower/') or name.startswith('pts/driver/') or name.startswith('pts/tests/run/')):
        raise RuntimeError(f'out-of-scope patch input: {name}')
    target = snapshot / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if (root / name).is_file():
        shutil.copy2(root / name, target)
subprocess.run(['patch', '--batch', '--fuzz=0', '-p1', '--directory', str(snapshot), '--input', str(patch)], check=True)
replace = {str(root / name): str(snapshot / name) for name in paths if name.endswith('.go')}
Path(args.overlay).write_text(json.dumps({'Replace': replace}, indent=2))
print(json.dumps({'files': len(paths), 'go_overlay_files': len(replace), 'snapshot': str(snapshot)}))
