import argparse
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('out')
args = parser.parse_args()
out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
for count in (256, 257):
    source = [
        'class Box<T> { constructor(public value: T) {} }',
        'class C { tag = 3; }',
        'type Factory = <T>(value: T) => Box<T>;',
        'function first<T>(value: T): Box<T> { return new Box(value); }',
        'function unused<T>(value: T): Box<T> { return new Box(value); }',
        'const kept: any[] = [unused];',
        'function use(f: Factory): void { const b: Box<C> = f(new C()); console.log(b.value.tag); }',
    ]
    for index in range(count):
        source.append(f'const bound{index} = first.bind(undefined);')
        source.append(f'use(bound{index});')
    source.append('console.log(kept.length);')
    (out / f'wrapper_union_{count}.pts').write_text('\n'.join(source) + '\n')
