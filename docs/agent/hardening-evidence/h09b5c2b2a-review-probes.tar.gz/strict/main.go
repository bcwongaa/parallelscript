package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	out := flag.String("out", "", "write AllInstances C")
	build := flag.String("build", "", "compile AllInstances C directly, without fallback")
	flag.Parse()
	if flag.NArg() != 1 {
		fmt.Fprintln(os.Stderr, "usage: strict [-out CFILE] [-build BIN] ENTRY.pts")
		os.Exit(2)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	code, err := driver.EmitCWith(ctx, flag.Arg(0), lower.AllInstances)
	if err != nil {
		fmt.Fprintf(os.Stderr, "%+v\n", err)
		os.Exit(1)
	}
	if *out != "" {
		if err = os.WriteFile(*out, []byte(code), 0600); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	if *build == "" {
		if *out == "" {
			fmt.Print(code)
		}
		return
	}
	cFile := *out
	if cFile == "" {
		cFile = *build + ".c"
		if err = os.WriteFile(cFile, []byte(code), 0600); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	tc, err := toolchain.New()
	if err == nil {
		runtime, runtimeErr := tc.Runtime(ctx, toolchain.Release)
		err = runtimeErr
		if err == nil {
			var binary string
			binary, err = filepath.Abs(*build)
			if err == nil {
				err = tc.CompileProgram(ctx, runtime, []string{cFile}, binary)
			}
		}
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
