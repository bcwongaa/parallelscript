#!/bin/bash
# After the D/E/G run on HEAD (PID $1) ends: build prototypes A and B (overlay builds, the
# worktree's sources untouched), then run the new matrix on HEAD. One heavy step at a time.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
while kill -0 "$1" 2>/dev/null; do sleep 5; done
echo "deg done $(date +%T)"
cd "$W" || exit 1
for d in A B; do
  mkdir -p /tmp/h11b/repro/proto/$d/bin
  GOMAXPROCS=2 go build -overlay /tmp/h11b/repro/proto/$d/overlay.json -o /tmp/h11b/repro/proto/$d/bin/pts ./cmd/pts > /tmp/h11b/repro/proto/$d/build.log 2>&1
  echo "proto $d build exit=$? $(date +%T)"
done
cd /tmp/h11b/repro/matrix || exit 1
python3 -I run_matrix.py cases.jsonl results_head.jsonl --jobs 2 > run_head.log 2>&1
echo "new matrix head exit=$? $(date +%T)"
