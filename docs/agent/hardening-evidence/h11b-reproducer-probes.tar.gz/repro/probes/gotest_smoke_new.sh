#!/bin/bash
# TestCompilerFailsCleanly over H11b's new tests and their mutants only (2 jobs).
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
cd "$W" || exit 1
names='callback_parameter_defaults_at_holes|find_shrinking_array_more|for_of_hole_patterns_and_entries|for_of_holes_tested_bindings|for_of_holes_untested_bindings|for_of_typed_sources_unchanged|holes_where_an_element_is_required'
GOMAXPROCS=2 PTS_SMOKE_JOBS=2 PTS_SMOKE_FILTER="/run/($names)\\.pts\$" go test -count=1 -run '^TestCompilerFailsCleanly$' ./pts/tests/ -v > /tmp/h11b/repro/probes/gotest_smoke_new.full 2>&1
code=$?
grep -E "compiled [0-9]+ programs|^(--- |ok|FAIL|PASS)|failed to compile" /tmp/h11b/repro/probes/gotest_smoke_new.full
echo "go test exit=$code"
