#!/bin/bash
# TestRun and TestRunMatchesNode over every run test with a `for (const|let x of …)` binding,
# with the worktree's sources or a prototype's overlay (2 jobs).
# Usage: gotest_forof_set.sh LABEL [-overlay FILE]
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
label="$1"
shift
cd "$W/pts/tests/run" || exit 1
names=$(grep -l "for (\(const\|let\) [A-Za-z_]* of" *.pts | sed 's/\.pts$//' | paste -sd'|')
cd "$W" || exit 1
out=/tmp/h11b/repro/probes/gotest_forof_$label
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test "$@" -count=1 -p 1 -parallel 2 -timeout 60m -run "^(TestRun|TestRunMatchesNode)\$/^($names)\$" ./pts/tests/ -v > "$out.full" 2>&1
code=$?
grep -E "^    --- (PASS|FAIL|SKIP)" "$out.full" | sed 's/ (.*//' | sort > "$out.txt"
echo "go test exit=$code"
grep -c "PASS" "$out.txt"; grep -c "FAIL" "$out.txt"; grep -c "SKIP" "$out.txt"
grep "FAIL" "$out.txt"
