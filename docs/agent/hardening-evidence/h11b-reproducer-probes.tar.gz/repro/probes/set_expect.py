"""Replace a test's `// expect:` block (the file's last lines) with Node's output.

Usage: python3 -I set_expect.py file.pts...
Runs Node as the harness does (node_out.sh: a strict-ESM .mts copy); refuses if Node exits non-zero.
"""

import subprocess
import sys

HERE = "/tmp/h11b/repro/probes"


def main():
    for path in sys.argv[1:]:
        r = subprocess.run(["bash", HERE + "/node_out.sh", path], capture_output=True, text=True)
        if r.returncode != 0:
            print("node exit", r.returncode, path, r.stderr[:500])
            continue
        lines = open(path).read().rstrip("\n").split("\n")
        cut = lines.index("// expect:")
        expect = ["// expect:"] + ["// " + l if l else "//" for l in r.stdout.rstrip("\n").split("\n")]
        open(path, "w").write("\n".join(lines[:cut] + expect) + "\n")
        print("set", len(expect) - 1, "lines", path)


if __name__ == "__main__":
    main()
