#!/bin/bash
# TestRun and TestRunMatchesNode for H11b's new tests only, in the worktree (2 jobs).
# Usage: gotest_new.sh OUT.txt [extra go test flags, e.g. -overlay FILE]
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
out="$1"
shift
names='callback_parameter_defaults_at_holes|find_shrinking_array_more|for_of_hole_patterns_and_entries|for_of_holes_tested_bindings|for_of_holes_untested_bindings|for_of_typed_sources_unchanged|holes_where_an_element_is_required'
cd "$W" || exit 1
GOMAXPROCS=2 PTS_REQUIRE_NODE=1 go test "$@" -count=1 -p 1 -parallel 2 -run "^(TestRun|TestRunMatchesNode)\$/^($names)\$" ./pts/tests/ -v > "$out.full" 2>&1
code=$?
grep -E "^(--- |    --- |ok|FAIL|PASS)" "$out.full" > "$out"
echo "go test exit=$code" >> "$out"
cat "$out"
