#!/bin/bash
# Print Node's output for a .pts file, run as the test harness runs it: a strict-ESM .mts copy.
# Usage: node_out.sh file.pts
tmp=$(mktemp -d /tmp/h11b/repro/node-XXXX)
base=$(basename "$1" .pts)
cp "$1" "$tmp/$base.mts"
TZ=America/New_York ~/.local/node/bin/node --no-warnings --experimental-transform-types "$tmp/$base.mts"
code=$?
rm -rf "$tmp"
exit $code
