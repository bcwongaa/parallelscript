#!/bin/bash
# Run each given .pts under Node (node_out.sh) and report any non-zero exit (a generator bug).
for f in "$@"; do
  if ! bash /tmp/h11b/repro/probes/node_out.sh "$f" > /dev/null 2> /tmp/h11b/repro/nodeerr.txt; then
    echo "NODE FAIL $f"
    head -3 /tmp/h11b/repro/nodeerr.txt
  fi
done
echo checked $#
