#!/bin/bash
# emit-c each given .pts with a CLI (PTS_BIN, default the worktree's), printing the first
# lines of any diagnostic. Light: lowering and C generation only, no clang.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
PTS="${PTS_BIN:-$W/pts-bin/pts}"
for f in "$@"; do
  echo "== $f"
  PTS_HOME="$W" "$PTS" emit-c "$f" -o /dev/null 2>&1 | head -4
done
