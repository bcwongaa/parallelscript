#!/bin/bash
# Build and run each given .pts with a CLI (PTS_BIN, default the worktree's) and print
# Node's output next to it. Binaries are deleted after. Heavy: one build at a time.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
PTS="${PTS_BIN:-$W/pts-bin/pts}"
for f in "$@"; do
  echo "== $f"
  bin="/tmp/h11b/repro/bin/$(basename "$f" .pts).probe.bin"
  if PTS_HOME="$W" "$PTS" build "$f" -o "$bin" > /tmp/h11b/repro/bin/build.log 2>&1; then
    echo "-- pts:"
    TZ=America/New_York "$bin" 2>&1 | head -40
    echo "exit=${PIPESTATUS[0]}"
    rm -f "$bin"
  else
    echo "-- pts build failed:"
    head -5 /tmp/h11b/repro/bin/build.log
  fi
  echo "-- node:"
  bash /tmp/h11b/repro/probes/node_out.sh "$f" 2>&1 | head -40
done
