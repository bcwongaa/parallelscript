"""One-off: mark the by-design cases the first HEAD run showed (labels only; texts unchanged).

- I over number[]: holes are 0 (D-085), unknown and any parameters too.
- map with a number result keeps 0 where JS keeps holes (D-085, D-183): J's map control,
  K's callback controls, L's map_optional.
- new Set(string[]) leaves holes out (D-130, D-183): K's and L's.
- spreads of values() of a string[] keep holes (D-182, D-183): L's values_spread.
- K's includes(undefined as unknown as string): a cast that lies is checked.
"""

p = "/tmp/h11b/repro/matrix/gen_h11b.py"
s = open(p).read()


def sub(old, new):
    global s
    assert old in s, old
    s = s.replace(old, new)


sub('    if sname == "number" and pname not in ("unknown", "any"):\n        expected = "by-design"  # D-085: a number array\'s holes are 0',
    '    if sname == "number":\n        expected = "by-design"  # D-085: a number array\'s holes are 0')
sub('''            cases.append(dict(family="J", finding="C112-control", source=sname, form=method, dest="inferred/length",
                              expected="node", text=program(TOP, body)))''',
    '''            cases.append(dict(family="J", finding="C112-control", source=sname, form=method, dest="inferred/length",
                              expected="by-design" if method == "map" else "node", text=program(TOP, body)))''')
sub('("set", "forof", "from holes", "  const s = new Set(strs());\\n  for (const x of s) console.log(x);", "node"),',
    '("set", "forof", "from holes", "  const s = new Set(strs());\\n  for (const x of s) console.log(x);", "by-design"),')
sub('''"  console.log(s.reduce((a, x) => a + x.length, 0), s.reduceRight((a, x) => a + x, \\"\\"));\\n  console.log(s.flatMap((x) => [x, x]));", "node"),''',
    '''"  console.log(s.reduce((a, x) => a + x.length, 0), s.reduceRight((a, x) => a + x, \\"\\"));\\n  console.log(s.flatMap((x) => [x, x]));", "by-design"),''')
sub('''"  console.log(s.reduce((a, p) => a + p.x, 0));", "node"),''', '''"  console.log(s.reduce((a, p) => a + p.x, 0));", "by-design"),''')
sub('''s.indexOf("b"), s.lastIndexOf("b"));', "node"),''', '''s.indexOf("b"), s.lastIndexOf("b"));', "by-design"),''')
sub('''"  console.log(points().map((p?: P) => p?.x ?? -1));", "node"),''', '''"  console.log(points().map((p?: P) => p?.x ?? -1));", "by-design"),''')
sub('''("set_from_holes", "string", "new Set(strs())", "  for (const x of new Set(strs())) console.log(x);", "node"),''',
    '''("set_from_holes", "string", "new Set(strs())", "  for (const x of new Set(strs())) console.log(x);", "by-design"),''')
sub('''("values_spread", "string", "[...values()]", "  console.log([...strs().values()]);", "node"),''',
    '''("values_spread", "string", "[...values()]", "  console.log([...strs().values()]);", "by-design"),''')
open(p, "w").write(s)
print("ok")
