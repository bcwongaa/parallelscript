"""Compare two result files of the same cases: class transitions and regressions.

Usage: python3 -I compare.py BASE.jsonl OTHER.jsonl [--family X] [--list FROM->TO]
Prints a table of (base class -> other class) counts per family and expectation, then
the cases that were OK in BASE and aren't in OTHER (regressions).
"""

import argparse
import collections
import json


def load(path):
    latest = {}
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            latest[r["id"]] = r
    return latest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("other")
    ap.add_argument("--family")
    ap.add_argument("--list")
    args = ap.parse_args()
    base, other = load(args.base), load(args.other)
    counts = collections.Counter()
    regressions = []
    for ident, r in sorted(other.items()):
        b = base.get(ident)
        if b is None or args.family and r["family"] != args.family:
            continue
        counts[(r["family"], r["expected"], b["cls"], r["cls"])] += 1
        if b["cls"] == "OK" and r["cls"] != "OK":
            regressions.append((ident, r))
        if args.list and args.list == b["cls"] + "->" + r["cls"]:
            print(ident, r["expected"], r["source"], r["form"], r["dest"], "|", (r["pts_message"] or r["build"][:200]).replace("\n", " ")[:160])
    if args.list:
        return
    print("| family | expected | base | other | cases |")
    print("|---|---|---|---|---|")
    for (fam, exp, b, o), n in sorted(counts.items()):
        print(f"| {fam} | {exp} | {b} | {o} | {n} |")
    print()
    print("regressions (OK in base, not in other):", len(regressions))
    for ident, r in regressions:
        print(" ", ident, r["expected"], r["source"], r["form"], r["dest"], r["cls"], "|",
              (r["pts_message"] or r["build"][:200]).replace("\n", " ")[:160])


if __name__ == "__main__":
    main()
