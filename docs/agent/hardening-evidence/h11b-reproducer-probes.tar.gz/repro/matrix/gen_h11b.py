"""Generate H11b's differential matrix: tiny programs run under pts and Node.

Families (new; H11's D, E and G come from gen_h11.py, regenerated on HEAD):
  H  for...of at holes: sources x bindings x uses x contexts, patterns, values()/entries()
  I  C111+: callback parameters of find & kin and Array.from's mapper at holes
  J  C112+: find & kin over an array the callback shortens or grows
  K  controls that must not change: number/boolean for...of, tuples, Map/Set, the
     callback methods skipping holes, (T | undefined)[] loops

Each case is cases/<family>/<id>.pts plus a line in cases.jsonl:
  {"id", "family", "finding", "source", "form", "dest", "expected", "path"}
expected: "node" (must print what Node prints), "by-design" (pts throws D-085's
RangeError or D-090's TypeError where Node goes on), "node|range" (Node's output or
D-085's RangeError where the callback's parameter can't take undefined).

Sampling is seeded (SEED), so the same command makes the same cases.
Usage: python3 -I gen_h11b.py OUTDIR
"""

import json
import os
import random
import sys

SEED = 20261025

PRELUDE = """function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}
"""


def program(top, body, run=None):
    """A case: top-level declarations, then main's body, run under a catch (or run's code)."""
    tail = ["try {", "  main();", "} catch (e) {", "  report(e);", "}"] if run is None else [run]
    return "\n".join([PRELUDE, top, "function main(): void {", body, "}"] + tail + [""])


# ------------------------------------------------------------------ shared declarations

TOP = """class P {
  constructor(public x: number, public tag = "P") {}
}
class Q {
  constructor(public q: string, public tag = "Q") {}
}
interface I {
  name: string;
}
function strs(): string[] {
  const a = new Array<string>(3);
  a[1] = "b";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function items(): I[] {
  const a = new Array<I>(3);
  a[1] = { name: "i" };
  return a;
}
function unions(): (P | Q)[] {
  const a = new Array<P | Q>(3);
  a[1] = new Q("q");
  return a;
}
function nullables(): (string | null)[] {
  const a = new Array<string | null>(4);
  a[1] = "b";
  a[2] = null;
  return a;
}
function funcs(): (() => string)[] {
  const a = new Array<() => string>(3);
  a[1] = () => "f";
  return a;
}
function rows(): string[][] {
  const a = new Array<string[]>(3);
  a[1] = ["r"];
  return a;
}
function maybes(): (string | undefined)[] {
  const a = new Array<string | undefined>(3);
  a[1] = "b";
  return a;
}
function nums(): number[] {
  const a = new Array<number>(3);
  a[1] = 1;
  return a;
}
class Holder {
  items: string[] = strs();
  readonly points: readonly P[] = points();
}
"""

# ------------------------------------------------------------------ family H (for...of)

# name: (expression, element type E, member(x) for a present element, default D)
H_SOURCES = {
    "string": ("strs()", "string", "{x}.length", '"d"'),
    "class": ("points()", "P", "{x}.x", "new P(9)"),
    "interface": ("items()", "I", "{x}.name", '{ name: "d" }'),
    "union_obj": ("unions()", "P | Q", "{x}.tag", "new P(9)"),
    "nullable": ("nullables()", "string | null", '({x} !== null ? {x}.length : "null")', '"d"'),
    "funcs": ("funcs()", "() => string", "{x}()", '(() => "d")'),
    "rows": ("rows()", "string[]", "{x}.length", "[]"),
    "readonly": ("(strs() as readonly string[])", "string", "{x}.length", '"d"'),
    "field": ("new Holder().items", "string", "{x}.length", '"d"'),
    "readonly_field": ("new Holder().points", "P", "{x}.x", "new P(9)"),
    "values": ("strs().values()", "string", "{x}.length", '"d"'),
    "maybe_control": ("maybes()", "string | undefined", "{x}?.length", '"d"'),
}

# use: (body with {x}, {E}, {M} (member), {D}; extra top; expected; needs)
H_USES = {
    "log": ("console.log({x});", "", "node"),
    "template": ("console.log(`<${{x}}>`);", "", "node"),
    "member": ("console.log({M});", "", "node"),  # Node: TypeError at the hole (as D-090's check)
    "eq": ('console.log({x} === undefined ? "hole" : "has");', "", "node"),
    "optchain": ('console.log({x} === undefined ? "hole" : {M});', "", "node"),
    "iftest": ('if ({x}) console.log("yes", {M});\n    else console.log("no");', "", "node"),
    "nullish": ("console.log({x} ?? {D});", "", "node"),
    "typeof": ("console.log(typeof {x});", "", "node"),
    "not": ("console.log(!{x});", "", "node"),
    "optfn": ("opt({x});", 'function opt(v?: {E}): void {\n  console.log(v === undefined ? "missing" : "present");\n}\n', "node"),
    "unionlocal": ("const u: ({E}) | undefined = {x};\n    console.log(u === undefined);", "", "node"),
    "unknownlocal": ("const u: unknown = {x};\n    console.log(u);", "", "node"),
    "closure": ("fns.push(() => console.log({x}));", "", "node"),
    "closure_tested": ("fns.push(() => console.log({x} === undefined));", "", "node"),
    "assign_outer": ("last = {x};\n    console.log(last === undefined);", "", "node"),
    "passfn": ("takes({x});", "function takes(v: {E}): void {\n  console.log(typeof v);\n}\n", "by-design"),
    "store": ("out.push({x});\n    console.log(out.length);", "", "by-design"),
}

H_BINDINGS = {"const": "const {x}", "let": "let {x}"}

# A context wraps the loop: {LOOP} is `for (BIND of SRC) { BODY }`, {PRE} declarations the
# uses need before the loop, {POST} what they do after it.
H_CONTEXTS = {
    "plain": "  {PRE}\n  {LOOP}\n  {POST}",
    "generator": ("  function* g(): Generator<number> {\n    {PRE}\n    {LOOP}\n    {POST}\n    yield 0;\n  }\n"
                  "  for (const _ of g()) console.log(\"gen done\");"),
    "async": "ASYNC",
    "break_continue": "  {PRE}\n  let n = 0;\n  {LOOP_BC}\n  {POST}",
    "labeled": "  {PRE}\n  outer: for (const r of [0, 1]) {\n    {LOOP_LABEL}\n  }\n  {POST}",
}


def h_body(use_body, x, member, dflt, etype):
    m = member.replace("{x}", x)
    return use_body.replace("{x}", x).replace("{M}", m).replace("{D}", dflt).replace("{E}", etype)


def h_case(sname, uname, bname, cname):
    expr, etype, member, dflt = H_SOURCES[sname]
    ubody, utop, expected = H_USES[uname]
    if sname == "maybe_control" and expected == "by-design":
        expected = "node"  # a (T | undefined)[]'s element type holds undefined
    x = "x"
    bind = H_BINDINGS[bname].replace("{x}", x)
    body = h_body(ubody, x, member, dflt, etype)
    pre, post = [], []
    if uname.startswith("closure"):
        pre.append("const fns: (() => void)[] = [];")
        post.append("for (const f of fns) f();")
    if uname == "assign_outer":
        pre.append("let last: ({E}) | undefined;".replace("{E}", etype))
    if uname == "store":
        pre.append("const out: ({E})[] = [];".replace("{E}", etype))
    loop = "for ({B} of {S}) {\n    {BODY}\n  }".replace("{B}", bind).replace("{S}", expr).replace("{BODY}", body)
    loop_bc = ("for ({B} of {S}) {\n    n++;\n    if (n === 2) continue;\n    {BODY}\n    if (n === 3) break;\n  }"
               .replace("{B}", bind).replace("{S}", expr).replace("{BODY}", body))
    loop_label = ("for ({B} of {S}) {\n      {BODY}\n      if (r === 0) continue outer;\n    }"
                  .replace("{B}", bind).replace("{S}", expr).replace("{BODY}", body.replace("\n    ", "\n      ")))
    top = TOP + utop.replace("{E}", etype)
    pre_s, post_s = "\n  ".join(pre), "\n  ".join(post)
    if cname == "async":
        inner = loop.replace("{\n    ", "{\n    await null;\n    ", 1)
        top += "async function run(): Promise<void> {\n  " + pre_s + "\n  " + inner + "\n  " + post_s + "\n}\n"
        text = program(top, "  return;", run="main();\nrun().catch(report);")
    else:
        ctx = H_CONTEXTS[cname]
        ctx = ctx.replace("{LOOP}", loop).replace("{LOOP_BC}", loop_bc).replace("{LOOP_LABEL}", loop_label)
        if cname == "generator":
            ctx = ctx.replace("{LOOP}", loop)
            ctx = ctx.replace("{PRE}", pre_s.replace("\n  ", "\n    ")).replace("{POST}", post_s.replace("\n  ", "\n    "))
        ctx = ctx.replace("{PRE}", pre_s).replace("{POST}", post_s)
        text = program(top, ctx)
    return dict(family="H", finding="forof", source=sname, form=f"{bname}/{cname}", dest=uname,
                expected=expected, text=text)


# patterns, entries(), generics and any: whole bodies
H_EXTRA = [
    # object patterns over holes: JS throws TypeError (cannot destructure undefined)
    ("obj_pattern", "class", "const { x }", "  for (const { x } of points()) console.log(x);", "node"),
    ("obj_pattern", "class", "const { x = 0 }", "  for (const { x = 0 } of points()) console.log(x);", "node"),
    ("obj_pattern", "interface", "const { name }", "  for (const { name } of items()) console.log(name);", "node"),
    ("obj_pattern", "union_obj", "const { tag }", "  for (const { tag } of unions()) console.log(tag);", "node"),
    ("obj_pattern", "string", "const { length }", "  for (const { length } of strs()) console.log(length);", "node"),
    ("obj_pattern", "class", "let { x }", "  for (let { x } of points()) console.log(x);", "node"),
    # array patterns over hole rows: JS throws TypeError (undefined is not iterable)
    ("arr_pattern", "rows", "const [a, b]", "  for (const [a, b] of rows()) console.log(a, b);", "node"),
    ("arr_pattern", "rows", "const [a = \"d\"]", '  for (const [a = "d"] of rows()) console.log(a);', "node"),
    ("arr_pattern", "string", "const [c]", "  for (const [c] of strs()) console.log(c);", "node"),
    ("arr_pattern", "rows_inner", "const [a, b]",
     '  const rs: string[][] = [["a"], new Array<string>(2)];\n  for (const [a, b] of rs) console.log(a, b);', "node"),
    ("arr_pattern", "rows_maybe", "const [a, b]",
     "  for (const [a, b] of [maybes()]) console.log(a, b);", "node"),
    # entries() and keys()
    ("entries", "string", "const [i, x]", "  for (const [i, x] of strs().entries()) console.log(i, x);", "node"),
    ("entries", "string", "const [i, x] tested",
     '  for (const [i, x] of strs().entries()) console.log(i, x === undefined ? "hole" : x.length);', "node"),
    ("entries", "class", "const [i, p]", "  for (const [i, p] of points().entries()) console.log(i, p?.x);", "node"),
    ("entries", "class", "const pair", "  for (const pair of points().entries()) console.log(pair);", "node"),
    ("entries", "string", "const pair", "  for (const pair of strs().entries()) console.log(pair[0], pair[1]);", "node"),
    ("keys", "string", "const i", "  for (const i of strs().keys()) console.log(i);", "node"),
    ("values", "class", "const p", "  for (const p of points().values()) console.log(p?.x);", "node"),
    ("values", "class", "const p untested", "  for (const p of points().values()) console.log(p);", "node"),
    # generic T[] instances
    ("generic", "string", "T = string",
     "  each(strs());", "node", "function each<T>(xs: T[]): void {\n  for (const x of xs) console.log(x === undefined ? \"hole\" : x);\n}\n"),
    ("generic", "class", "T = P",
     "  each(points());", "node", "function each<T>(xs: T[]): void {\n  for (const x of xs) console.log(x);\n}\n"),
    ("generic", "string+number", "T = string, number",
     "  each(strs());\n  each([1, 2]);", "node", "function each<T>(xs: T[]): void {\n  for (const x of xs) console.log(x);\n}\n"),
    ("generic", "number_holes", "T = number",
     "  each(nums());", "by-design", "function each<T>(xs: T[]): void {\n  for (const x of xs) console.log(x);\n}\n"),
    ("generic", "string", "T = string typed",
     "  console.log(count(strs()));", "node",
     "function count<T>(xs: T[]): number {\n  let n = 0;\n  for (const x of xs) if (x !== undefined) n++;\n  return n;\n}\n"),
    # held in any
    ("any", "string", "const x", "  const a: any = strs();\n  for (const x of a) console.log(x);", "node"),
    ("any", "string", "const x tested", "  const a: any = strs();\n  for (const x of a) console.log(x === undefined);", "node"),
    ("any", "class", "const p", "  const a: any = points();\n  for (const p of a) console.log(p?.x);", "node"),
    ("any", "string", "member", "  const a: any = strs();\n  for (const x of a) console.log(x.length);", "node"),
    # spreads and Array.from of a string[] keep holes / read them (D-182, D-183)
    ("spread_forof", "string", "const x", "  for (const x of [...strs()]) console.log(x);", "node"),
    ("from_forof", "string", "const x", "  for (const x of Array.from(strs())) console.log(x);", "node"),
    # a binding narrowed then used: no crash (C99's shape)
    ("narrowed", "nullable", "x !== null", "  for (const x of nullables()) if (x !== null) console.log(x.length);", "node"),
    ("narrowed", "nullable", "typeof x === \"string\"",
     '  for (const x of nullables()) if (typeof x === "string") console.log(x.length);\n  console.log("end");', "node"),
    ("narrowed", "union_obj", "instanceof",
     '  for (const x of unions()) console.log(x instanceof Q ? x.q : "not Q");', "node"),
    ("narrowed", "union_obj", "in",
     '  for (const x of unions()) console.log(x !== undefined && "q" in x ? x.q : "no");', "node"),
    # the binding returned / given / stored
    ("returned", "string", "return x",
     "  console.log(first(strs()));", "node",
     "function first(xs: string[]): string | undefined {\n  for (const x of xs) return x;\n  return \"none\";\n}\n"),
    ("returned", "string", "return x as string",
     "  console.log(first(strs()));", "by-design",
     "function first(xs: string[]): string {\n  for (const x of xs) return x;\n  return \"none\";\n}\n"),
    ("stored", "string", "maybe array",
     "  const out: (string | undefined)[] = [];\n  for (const x of strs()) out.push(x);\n  console.log(out);", "node"),
    ("stored", "string", "map set",
     "  const m = new Map<number, string | undefined>();\n  let i = 0;\n  for (const x of strs()) m.set(i++, x);\n  console.log(m);", "node"),
    ("stored", "class", "object literal optional",
     "  interface Box {\n    p?: P;\n  }\n  const out: Box[] = [];\n  for (const p of points()) out.push({ p });\n  console.log(out);", "node"),
    ("arith", "string", "x + 1",
     "  for (const x of strs()) console.log(x + 1);", "node"),
    ("arith", "string", "x.concat",
     '  for (const x of strs()) console.log(x?.concat("!"));', "node"),
    ("compare", "string", "x < \"c\"",
     '  for (const x of strs()) console.log(x < "c");', "node"),
    ("switch", "string", "switch (x)",
     '  for (const x of strs()) {\n    switch (x) {\n      case "b":\n        console.log("b");\n        break;\n      case undefined:\n        console.log("hole");\n        break;\n    }\n  }', "node"),
    ("json", "string", "JSON.stringify(x)",
     "  for (const x of strs()) console.log(JSON.stringify(x));", "node"),
    ("string_fn", "string", "String(x)",
     "  for (const x of strs()) console.log(String(x));", "node"),
    ("nested_loops", "string", "for of for of",
     '  for (const x of strs()) for (const y of strs()) console.log(x ?? "-", y ?? "-");', "node"),
    ("reassign", "string", "let x = x ?? d",
     '  for (let x of strs()) {\n    x = x ?? "d";\n    console.log(x.length);\n  }', "node"),
    ("destructure_later", "rows", "const [a] = row",
     "  for (const row of rows()) {\n    if (row === undefined) continue;\n    const [a] = row;\n    console.log(a);\n  }", "node"),
]


def family_h():
    cases = []
    for sname in H_SOURCES:
        for uname in H_USES:
            for bname in H_BINDINGS:
                cases.append(h_case(sname, uname, bname, "plain"))
    rng = random.Random(SEED)
    others = [c for c in H_CONTEXTS if c != "plain"]
    for sname in H_SOURCES:
        for uname in H_USES:
            cname = rng.choice(others)
            bname = rng.choice(list(H_BINDINGS))
            cases.append(h_case(sname, uname, bname, cname))
    for entry in H_EXTRA:
        form, sname, dest, body, expected = entry[:5]
        top = TOP + (entry[5] if len(entry) > 5 else "")
        cases.append(dict(family="H", finding="forof", source=sname, form=form, dest=dest,
                          expected=expected, text=program(top, body)))
    return cases


# ------------------------------------------------------------------ family I (C111+)

# name: (expression, element type E, default D, present test of p)
I_SOURCES = {
    "class": ("points()", "P", "new P(9)"),
    "interface": ("items()", "I", '{ name: "d" }'),
    "string": ("strs()", "string", '"d"'),
    "union_obj": ("unions()", "P | Q", "new P(9)"),
    "nullable": ("nullables()", "string | null", '"d"'),
    "funcs": ("funcs()", "() => string", '() => "d"'),
    "rows": ("rows()", "string[]", "[]"),
    "number": ("nums()", "number", "9"),
}

I_METHODS = {
    "find": ("{S}.find({CB})", "pred"),
    "findIndex": ("{S}.findIndex({CB})", "pred"),
    "findLast": ("{S}.findLast({CB})", "pred"),
    "findLastIndex": ("{S}.findLastIndex({CB})", "pred"),
    "Array.from": ("Array.from({S}, {CB})", "map"),
}

# name: (params, predicate body, mapper body, top, expected)
I_PARAMS = {
    "optional": ("(p?: {E})", "p === undefined", "p === undefined ? -1 : 1", "", "node"),
    "optional_index": ("(p?: {E}, i?: number)", "p === undefined && i !== 0", "p === undefined ? -i! : i!", "", "node"),
    "union_index": ("(p: ({E}) | undefined, i: number)", "p === undefined && i !== 0", "p === undefined ? -i : i", "", "node"),
    "default": ("(p: {E} = {D})", "p === {DV}", "p === {DV} ? 0 : 1", "", "node"),
    "default_index": ("(p: {E} = {D}, i: number = 7)", "p === {DV} && i > 0", "p === {DV} ? i : -i", "", "node"),
    "nullable_param": ("(p: ({E}) | null)", "p === null", "p === null ? 0 : 1", "", "by-design"),
    "unknown": ("(p: unknown)", "p === undefined", "p === undefined ? -1 : 1", "", "node"),
    "any": ("(p: any)", "p === undefined", "p === undefined ? -1 : 1", "", "node"),
    "function_expr": ("function (p?: {E})", "{ return p === undefined; }", "{ return p === undefined ? -1 : 1; }", "", "node"),
    "named_function": ("NAMED", "", "", "", "node"),
    "const_arrow": ("CONST", "", "", "", "node"),
    "static_method": ("STATIC", "", "", "", "node"),
    "instance_method": ("METHOD", "", "", "", "node"),
    "object_method": ("OBJECT", "", "", "", "node"),
    "predicate": ("(p?: {E}): p is {EP}", "p !== undefined", None, "", "node"),
    "generic_helper": ("GENERIC", "", "", "", "node"),
    "required": ("(p: {E})", "p === undefined", "p === undefined ? -1 : 1", "", "by-design"),
    "inferred": ("(p)", "p === undefined", "p === undefined ? -1 : 1", "", "by-design"),
}


def i_case(sname, mname, pname):
    expr, etype, dflt = I_SOURCES[sname]
    call, kind = I_METHODS[mname]
    params, pred, mapper, ptop, expected = I_PARAMS[pname]
    if sname == "number":
        expected = "by-design"  # D-085: a number array's holes are 0
    if sname == "nullable" and pname == "nullable_param":
        expected = "by-design"
    top = TOP
    dv = "DFLT"
    top += "const DFLT: {E} = {D};\n".replace("{E}", etype).replace("{D}", dflt)
    body_kind = pred if kind == "pred" else mapper
    ret = "boolean" if kind == "pred" else "number"
    test = "p === undefined" if kind == "pred" else "p === undefined ? -1 : 1"
    if params == "NAMED":
        top += f"function cb(p?: {etype}): {ret} {{\n  return {test};\n}}\n"
        cb = "cb"
    elif params == "CONST":
        top += f"const cb = (p?: {etype}): {ret} => {test};\n"
        cb = "cb"
    elif params == "STATIC":
        top += f"class C {{\n  static cb(p?: {etype}): {ret} {{\n    return {test};\n  }}\n}}\n"
        cb = "C.cb"
    elif params == "METHOD":
        top += f"class C {{\n  cb(p?: {etype}): {ret} {{\n    return {test};\n  }}\n}}\nconst c = new C();\n"
        cb = "c.cb"
    elif params == "OBJECT":
        top += f"const helpers = {{\n  cb(p?: {etype}): {ret} {{\n    return {test};\n  }},\n}};\n"
        cb = "helpers.cb"
    elif params == "GENERIC":
        if kind == "pred":
            m = mname
            top += (f"function via<T>(xs: T[], f: (x?: T) => boolean): unknown {{\n  return xs.{m}(f);\n}}\n")
            cb = None
            text_call = f"via({expr}, (p?: {etype}) => p === undefined)"
        else:
            top += "function via<T>(xs: T[], f: (x?: T) => number): number[] {\n  return Array.from(xs, f);\n}\n"
            cb = None
            text_call = f"via({expr}, (p?: {etype}) => (p === undefined ? -1 : 1))"
    else:
        if body_kind is None:
            return None  # a type predicate maps nothing
        b = body_kind.replace("{DV}", dv)
        if params.startswith("function"):
            cb = params.replace("{E}", etype) + " " + b
        else:
            cb = params.replace("{EP}", f"({etype})" if "=>" in etype else etype).replace("{E}", etype).replace("{D}", "DFLT") + " => " + (f"({b})" if "?" in b and ":" in b else b)
    if params == "GENERIC":
        line = text_call
    else:
        line = call.replace("{S}", expr).replace("{CB}", cb)
    if pname == "predicate" and mname not in ("find", "findLast"):
        return None
    body = f"  console.log({line});"
    return dict(family="I", finding="C111", source=sname, form=mname, dest=pname, expected=expected,
                text=program(top, body))


def family_i():
    cases = []
    for sname in I_SOURCES:
        for mname in I_METHODS:
            for pname in I_PARAMS:
                c = i_case(sname, mname, pname)
                if c is not None:
                    cases.append(c)
    return cases


# ------------------------------------------------------------------ family J (C112+)

J_SOURCES = {
    "string": ("string", '["a", "b", "c"]', '"z"'),
    "number": ("number", "[1, 2, 3]", "9"),
    "boolean": ("boolean", "[true, false, true]", "false"),
    "class": ("P", "[new P(1), new P(2), new P(3)]", "new P(9)"),
    "interface": ("I", '[{ name: "a" }, { name: "b" }, { name: "c" }]', '{ name: "z" }'),
    "nullable": ("string | null", '["a", null, "c"]', '"z"'),
}

J_SHRINKS = {
    "length": "xs.length = 1",
    "pop": "xs.pop(); xs.pop()",
    "splice": "xs.splice(1)",
    "shift": "xs.shift()",
    "grow": "xs.push({D})",
    "length0": "xs.length = 0",
}

J_METHODS = ["find", "findIndex", "findLast", "findLastIndex"]

J_PARAMS = {
    "inferred": ("(x, i)", "node|range"),
    "optional": ("(x?: {E}, i?: number)", "node"),
    "union": ("(x: ({E}) | undefined, i: number)", "node"),
    "default": ("(x: {E} = {D}, i: number = -1)", "node"),
    "unknown": ("(x: unknown, i: number)", "node"),
    "any": ("(x: any, i: number)", "node"),
    "through_any": ("ANY", "node"),
}


def family_j():
    cases = []
    rng = random.Random(SEED + 1)
    for sname, (etype, literal, dflt) in J_SOURCES.items():
        for method in J_METHODS:
            for pname, (params, expected) in J_PARAMS.items():
                # every combination shrinks by `length = 1`, and by one other change chosen by the seed
                other = rng.choice([s for s in J_SHRINKS if s != "length"])
                for shname, shrink in J_SHRINKS.items():
                    if shname not in ("length", other):
                        continue
                    exp = expected
                    if shname == "grow":
                        exp = "node"  # nothing is cut off
                    if pname == "inferred" and sname in ("number", "boolean") and shname not in ("grow",):
                        exp = "node|range"
                    shrink_s = shrink.replace("{D}", dflt)
                    recv = "xs"
                    p = params.replace("{E}", etype).replace("{D}", dflt)
                    if params == "ANY":
                        recv = "ys"
                        p = "(x: any, i: number)"
                    body = (f"  const xs: ({etype})[] = {literal};\n"
                            + ("  const ys: any = xs;\n" if params == "ANY" else "")
                            + "  const seen: unknown[] = [];\n"
                            "  let first = true;\n"
                            f"  const r = {recv}.{method}({p} => {{\n"
                            f"    if (first) {{\n      first = false;\n      {shrink_s};\n    }}\n"
                            "    seen.push(i, x);\n"
                            "    return false;\n"
                            "  });\n"
                            "  console.log(seen, r, xs.length);")
                    cases.append(dict(family="J", finding="C112", source=sname, form=method,
                                      dest=f"{pname}/{shname}", expected=exp, text=program(TOP, body)))
    # the callback methods that skip what a callback cut off (controls), and reduce
    for sname in ("string", "class", "number"):
        etype, literal, dflt = J_SOURCES[sname]
        for method, ret in (("forEach", ""), ("some", "return false;"), ("every", "return true;"),
                            ("map", "return 1;"), ("filter", "return true;"), ("flatMap", "return [1];")):
            body = (f"  const xs: ({etype})[] = {literal};\n  const seen: unknown[] = [];\n  let first = true;\n"
                    f"  const r = xs.{method}((x, i) => {{\n    if (first) {{\n      first = false;\n      xs.length = 1;\n    }}\n"
                    f"    seen.push(i, x);\n    {ret}\n  }});\n  console.log(seen, r, xs.length);")
            cases.append(dict(family="J", finding="C112-control", source=sname, form=method, dest="inferred/length",
                              expected="by-design" if method == "map" else "node", text=program(TOP, body)))
        body = (f"  const xs: ({etype})[] = {literal};\n  const seen: unknown[] = [];\n"
                "  const r = xs.reduce((acc: number, x, i) => {\n    if (i === 0) xs.length = 1;\n"
                "    seen.push(i, x);\n    return acc + 1;\n  }, 0);\n  console.log(seen, r, xs.length);")
        cases.append(dict(family="J", finding="C112-control", source=sname, form="reduce", dest="inferred/length",
                          expected="node", text=program(TOP, body)))
    return cases


# ------------------------------------------------------------------ family K (controls)

K_CASES = [
    ("number", "forof", "sum", "  const xs = [1, 2, 3];\n  let s = 0;\n  for (const x of xs) s += x;\n  console.log(s);", "node"),
    ("number", "forof", "holes", "  for (const x of nums()) console.log(x);", "by-design"),
    ("number", "forof_let", "sum", "  let s = 0;\n  for (let x of [1, 2, 3]) {\n    x *= 2;\n    s += x;\n  }\n  console.log(s);", "node"),
    ("boolean", "forof", "count", "  let n = 0;\n  for (const b of [true, false, true]) if (b) n++;\n  console.log(n);", "node"),
    ("int", "forof", "typed", "  const xs: number[] = [];\n  for (let i = 0; i < 5; i++) xs.push(i);\n  let s = 0;\n  for (const x of xs) s += x * x;\n  console.log(s);", "node"),
    ("tuple", "forof", "elements", '  const t: [string, number] = ["a", 1];\n  for (const x of t) console.log(x);', "node"),
    ("tuple", "forof_rows", "pattern", '  const rows: [string, number][] = [["a", 1], ["b", 2]];\n  for (const [k, v] of rows) console.log(k.length + v);', "node"),
    ("map", "forof", "entries", '  const m = new Map([["a", 1], ["b", 2]]);\n  for (const [k, v] of m) console.log(k, v);', "node"),
    ("map", "forof", "keys", '  const m = new Map([["a", 1], ["b", 2]]);\n  for (const k of m.keys()) console.log(k.length);', "node"),
    ("map", "forof", "values", '  const m = new Map([["a", 1], ["b", 2]]);\n  for (const v of m.values()) console.log(v + 1);', "node"),
    ("map", "forEach", "entries", '  const m = new Map([["a", 1]]);\n  m.forEach((v, k) => console.log(k, v));', "node"),
    ("set", "forof", "values", '  const s = new Set(["a", "b"]);\n  for (const x of s) console.log(x.length);', "node"),
    ("set", "forof", "from holes", "  const s = new Set(strs());\n  for (const x of s) console.log(x);", "by-design"),
    ("string", "forof", "code points", '  for (const c of "a😀b") console.log(c.length);', "node"),
    ("maybe", "forof", "control", "  for (const x of maybes()) console.log(x);", "node"),
    ("string", "callbacks", "skip holes",
     "  const s = strs();\n  s.forEach((x) => console.log(\"each\", x.length));\n  console.log(s.map((x) => x.length));\n"
     "  console.log(s.filter((x) => x.length > 0));\n  console.log(s.some((x) => x.length > 5), s.every((x) => x.length === 1));\n"
     "  console.log(s.reduce((a, x) => a + x.length, 0), s.reduceRight((a, x) => a + x, \"\"));\n  console.log(s.flatMap((x) => [x, x]));", "by-design"),
    ("class", "callbacks", "skip holes",
     "  const s = points();\n  s.forEach((p) => console.log(\"each\", p.x));\n  console.log(s.map((p) => p.x));\n"
     "  console.log(s.filter((p) => p.x > 0));\n  console.log(s.some((p) => p.x > 5), s.every((p) => p.x === 1));\n"
     "  console.log(s.reduce((a, p) => a + p.x, 0));", "by-design"),
    ("class", "callbacks", "reduce no initial", "  console.log(points().reduce((a, p) => (a.x > p.x ? a : p)).x);", "node"),
    ("string", "search", "includes indexOf",
     '  const s = strs();\n  console.log(s.includes(undefined as unknown as string), s.indexOf("b"), s.lastIndexOf("b"));', "by-design"),
    ("string", "index_loop", "typed hole read", "  const s = strs();\n  for (let i = 0; i < s.length; i++) console.log(s[i].length);", "by-design"),
    ("string", "index_loop", "tested hole read", "  const s = strs();\n  for (let i = 0; i < s.length; i++) {\n    const x = s[i];\n    console.log(x === undefined ? \"hole\" : x);\n  }", "node"),
    ("string", "spread", "keeps holes", "  console.log([...strs()]);", "by-design"),
    ("string", "find_no_holes", "inferred", '  console.log(["a", "b"].find((x) => x === "b"), ["a", "b"].findLastIndex((x) => x.length === 1));', "node"),
    ("class", "find_no_holes", "inferred", "  console.log([new P(1), new P(2)].find((p) => p.x === 2)?.x);", "node"),
    ("number", "find", "inferred", "  console.log([1, 2, 3].find((x) => x > 1), [1, 2, 3].findLast((x) => x < 3));", "node"),
    ("typed_array", "forof", "Float64Array", "  let s = 0;\n  for (const x of new Float64Array([1, 2])) s += x;\n  console.log(s);", "node"),
]


def family_k():
    return [dict(family="K", finding="control", source=s, form=f, dest=d, expected=e, text=program(TOP, body))
            for (s, f, d, body, e) in K_CASES]


# ------------------------------------------------------------------ family L (extras)

L_CASES = [
    # Array.from(array, mapper) iterates the array's iterator, which reads the length at each
    # step: a mapper that grows the array is called for the new elements too (JS)
    ("from_grow", "string", "mapper pushes",
     '  const xs = ["a"];\n  console.log(Array.from(xs, (x, i) => {\n    if (i < 2) xs.push("n" + i);\n    return x;\n  }));', "node"),
    ("from_shrink", "string", "mapper pops",
     '  const xs = ["a", "b", "c"];\n  console.log(Array.from(xs, (x, i) => {\n    if (i === 0) xs.pop();\n    return x;\n  }));', "node"),
    ("from_shrink", "string", "optional mapper pops",
     '  const xs = ["a", "b", "c"];\n  console.log(Array.from(xs, (x?: string, i?: number) => {\n    if (i === 0) xs.pop();\n    return x ?? "-";\n  }));', "node"),
    ("forof_grow", "string", "body pushes",
     '  const xs = ["a"];\n  for (const x of xs) {\n    if (xs.length < 3) xs.push(x + "!");\n    console.log(x);\n  }', "node"),
    ("forof_shrink", "string", "body pops",
     '  const xs = ["a", "b", "c"];\n  for (const x of xs) {\n    xs.pop();\n    console.log(x);\n  }', "node"),
    ("find_grow", "string", "callback pushes",
     '  const xs = ["a"];\n  const seen: string[] = [];\n  xs.find((x) => {\n    xs.push("z");\n    seen.push(x);\n    return false;\n  });\n  console.log(seen, xs.length);', "node"),
    ("entries_spread", "string", "[...entries()]", "  console.log([...strs().entries()]);", "node"),
    ("entries_from", "string", "Array.from(entries())", "  console.log(Array.from(strs().entries()));", "node"),
    ("values_spread", "string", "[...values()]", "  console.log([...strs().values()]);", "by-design"),
    ("find_bang", "class", "find(optional)!",
     "  console.log(points().find((p?: P) => p !== undefined)!.x);", "node"),
    ("some_optional", "string", "some skips holes",
     "  console.log(strs().some((w?: string) => w === undefined), strs().every((w?: string) => w !== undefined));", "node"),
    ("filter_optional", "string", "filter skips holes",
     "  console.log(strs().filter((w?: string) => w === undefined).length);", "node"),
    ("map_optional", "class", "map keeps holes",
     "  console.log(points().map((p?: P) => p?.x ?? -1));", "by-design"),
    ("reduce_optional", "string", "reduce skips holes",
     '  console.log(strs().reduce((acc: string, w?: string) => acc + (w ?? "-"), ""));', "node"),
    ("forEach_default", "string", "forEach skips holes",
     '  strs().forEach((w: string = "d") => console.log(w));', "node"),
    ("set_from_holes", "string", "new Set(strs())", "  for (const x of new Set(strs())) console.log(x);", "by-design"),
    ("from_default_index", "string", "Array.from default + index",
     '  console.log(Array.from(strs(), (w: string = "d", i: number) => w + i));', "node"),
    ("findLast_union_default", "class", "findLast default P",
     "  console.log(points().findLast((p: P = new P(7)) => p.x === 7));", "node"),
    ("from_any_source", "string", "Array.from(any, optional)",
     '  const a: any = strs();\n  console.log(Array.from(a, (w?: string) => w ?? "-"));', "node"),
]


def family_l():
    return [dict(family="L", finding="extra", source=s, form=f, dest=d, expected=e, text=program(TOP, body))
            for (f, s, d, body, e) in L_CASES]


def main():
    out = sys.argv[1]
    cases = []
    for family in (family_h, family_i, family_j, family_k, family_l):
        cases.extend(family())
    seen = set()
    with open(os.path.join(out, "cases.jsonl"), "w") as index:
        for n, case in enumerate(cases):
            ident = "{}{:04d}".format(case["family"], n)
            assert ident not in seen
            seen.add(ident)
            directory = os.path.join(out, "cases", case["family"])
            os.makedirs(directory, exist_ok=True)
            path = os.path.join(directory, ident + ".pts")
            header = "// {} {} source={} form={} dest={} expected={}\n".format(
                ident, case["finding"], case["source"], case["form"], case["dest"], case["expected"])
            text = header + case["text"]
            old = open(path).read() if os.path.exists(path) else None
            if old != text:
                with open(path + ".tmp", "w") as f:
                    f.write(text)
                os.replace(path + ".tmp", path)
            meta = {k: v for k, v in case.items() if k != "text"}
            meta.update(id=ident, path=path)
            index.write(json.dumps(meta) + "\n")
    counts = {}
    for case in cases:
        counts[case["family"]] = counts.get(case["family"], 0) + 1
    print(len(cases), "cases", counts)


if __name__ == "__main__":
    main()
