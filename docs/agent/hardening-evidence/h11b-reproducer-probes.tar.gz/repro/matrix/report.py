"""Summarise H11's matrix results.

Usage: python3 -I report.py RESULTS.jsonl [--by source|form|dest] [--family X] [--list CLASS]
Prints counts per family and class, split by the expected class; with --by, a table of
one dimension for a family; with --list, the cases of a class (id, source, form, dest,
pts message).
"""

import argparse
import collections
import json
import os

CLASSES = ["OK", "WRONG", "TYPEERR", "RANGEERR", "THREW", "PTS1001", "PTS9001", "TSERR", "BUILDERR", "CRASH", "TIMEOUT"]


def load(path):
    latest = {}
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            latest[r["id"]] = r  # a re-run's line wins
    index = os.path.join(os.path.dirname(os.path.abspath(path)), "cases.jsonl")
    if os.path.exists(index):  # the generator's current expectation wins
        with open(index) as f:
            for line in f:
                c = json.loads(line)
                if c["id"] in latest:
                    latest[c["id"]]["expected"] = c["expected"]
    return list(latest.values())


def table(rows, key, title):
    counts = collections.defaultdict(collections.Counter)
    for r in rows:
        counts[key(r)][r["cls"]] += 1
    used = [c for c in CLASSES if any(counts[k][c] for k in counts)]
    print(title)
    print("| " + " | ".join(["group", "total"] + used) + " |")
    print("|" + "---|" * (len(used) + 2))
    for k in sorted(counts):
        total = sum(counts[k].values())
        print("| " + " | ".join([k, str(total)] + [str(counts[k][c]) for c in used]) + " |")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--by")
    ap.add_argument("--family")
    ap.add_argument("--list")
    args = ap.parse_args()
    rows = load(args.results)
    if args.family:
        rows = [r for r in rows if r["family"] == args.family]
    if args.list:
        for r in sorted(rows, key=lambda r: r["id"]):
            if r["cls"] == args.list:
                print(r["id"], r["expected"], r["source"], r["form"], r["dest"], "|", r["pts_message"][:120] or r["build"][:200].replace("\n", " "))
        return
    if args.by:
        key = {"src": "source"}.get(args.by, args.by)
        table(rows, lambda r: "{} / {}".format(r[key], r["expected"]), "by " + key)
        return
    table(rows, lambda r: "{} {} / {}".format(r["family"], r["finding"], r["expected"]), "family / expected")
    table(rows, lambda r: r["expected"], "expected")


if __name__ == "__main__":
    main()
