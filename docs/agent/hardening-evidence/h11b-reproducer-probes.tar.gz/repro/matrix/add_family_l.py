"""One-off: append family L (extras) to gen_h11b.py."""

p = "/tmp/h11b/repro/matrix/gen_h11b.py"
s = open(p).read()
add = r'''

# ------------------------------------------------------------------ family L (extras)

L_CASES = [
    # Array.from(array, mapper) iterates the array's iterator, which reads the length at each
    # step: a mapper that grows the array is called for the new elements too (JS)
    ("from_grow", "string", "mapper pushes",
     '  const xs = ["a"];\n  console.log(Array.from(xs, (x, i) => {\n    if (i < 2) xs.push("n" + i);\n    return x;\n  }));', "node"),
    ("from_shrink", "string", "mapper pops",
     '  const xs = ["a", "b", "c"];\n  console.log(Array.from(xs, (x, i) => {\n    if (i === 0) xs.pop();\n    return x;\n  }));', "node"),
    ("from_shrink", "string", "optional mapper pops",
     '  const xs = ["a", "b", "c"];\n  console.log(Array.from(xs, (x?: string, i?: number) => {\n    if (i === 0) xs.pop();\n    return x ?? "-";\n  }));', "node"),
    ("forof_grow", "string", "body pushes",
     '  const xs = ["a"];\n  for (const x of xs) {\n    if (xs.length < 3) xs.push(x + "!");\n    console.log(x);\n  }', "node"),
    ("forof_shrink", "string", "body pops",
     '  const xs = ["a", "b", "c"];\n  for (const x of xs) {\n    xs.pop();\n    console.log(x);\n  }', "node"),
    ("find_grow", "string", "callback pushes",
     '  const xs = ["a"];\n  const seen: string[] = [];\n  xs.find((x) => {\n    xs.push("z");\n    seen.push(x);\n    return false;\n  });\n  console.log(seen, xs.length);', "node"),
    ("entries_spread", "string", "[...entries()]", "  console.log([...strs().entries()]);", "node"),
    ("entries_from", "string", "Array.from(entries())", "  console.log(Array.from(strs().entries()));", "node"),
    ("values_spread", "string", "[...values()]", "  console.log([...strs().values()]);", "node"),
    ("find_bang", "class", "find(optional)!",
     "  console.log(points().find((p?: P) => p !== undefined)!.x);", "node"),
    ("some_optional", "string", "some skips holes",
     "  console.log(strs().some((w?: string) => w === undefined), strs().every((w?: string) => w !== undefined));", "node"),
    ("filter_optional", "string", "filter skips holes",
     "  console.log(strs().filter((w?: string) => w === undefined).length);", "node"),
    ("map_optional", "class", "map keeps holes",
     "  console.log(points().map((p?: P) => p?.x ?? -1));", "node"),
    ("reduce_optional", "string", "reduce skips holes",
     '  console.log(strs().reduce((acc: string, w?: string) => acc + (w ?? "-"), ""));', "node"),
    ("forEach_default", "string", "forEach skips holes",
     '  strs().forEach((w: string = "d") => console.log(w));', "node"),
    ("set_from_holes", "string", "new Set(strs())", "  for (const x of new Set(strs())) console.log(x);", "node"),
    ("from_default_index", "string", "Array.from default + index",
     '  console.log(Array.from(strs(), (w: string = "d", i: number) => w + i));', "node"),
    ("findLast_union_default", "class", "findLast default P",
     "  console.log(points().findLast((p: P = new P(7)) => p.x === 7));", "node"),
    ("from_any_source", "string", "Array.from(any, optional)",
     '  const a: any = strs();\n  console.log(Array.from(a, (w?: string) => w ?? "-"));', "node"),
]


def family_l():
    return [dict(family="L", finding="extra", source=s, form=f, dest=d, expected=e, text=program(TOP, body))
            for (f, s, d, body, e) in L_CASES]
'''
assert "family_l" not in s
s = s.replace("\n\ndef main():", add + "\n\ndef main():")
s = s.replace("for family in (family_h, family_i, family_j, family_k):",
              "for family in (family_h, family_i, family_j, family_k, family_l):")
open(p, "w").write(s)
print("ok")
