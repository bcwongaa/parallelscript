"""Write the cases of the given families from CASES.jsonl to OUT.jsonl.

Usage: python3 -I filter_family.py CASES.jsonl OUT.jsonl FAMILY...
"""

import json
import sys

src, out, families = sys.argv[1], sys.argv[2], set(sys.argv[3:])
rows = [json.loads(line) for line in open(src)]
keep = [r for r in rows if r["family"] in families]
with open(out, "w") as f:
    for r in keep:
        f.write(json.dumps(r) + "\n")
print(len(keep), "cases")
