"""Pivot a results file: rows by one field (or a field's part), classes as columns.

Usage: python3 -I pivot.py RESULTS.jsonl FAMILY ROWFIELD [--expected node|by-design|...] [--part N]
       [--exclude-source S,...]
ROWFIELD is source, form, dest or finding; --part N takes the N-th '/'-separated part.
Expectations come from cases.jsonl next to RESULTS (the generator's current labels).
"""

import argparse
import collections
import json
import os

CLASSES = ["OK", "WRONG", "TYPEERR", "RANGEERR", "THREW", "PTS1001", "PTS9001", "TSERR", "BUILDERR", "CRASH", "TIMEOUT"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("family")
    ap.add_argument("row")
    ap.add_argument("--expected")
    ap.add_argument("--part", type=int)
    ap.add_argument("--exclude-source", default="")
    args = ap.parse_args()
    latest = {}
    for line in open(args.results):
        r = json.loads(line)
        latest[r["id"]] = r
    index = os.path.join(os.path.dirname(os.path.abspath(args.results)), "cases.jsonl")
    if os.path.exists(index):
        for line in open(index):
            c = json.loads(line)
            if c["id"] in latest:
                latest[c["id"]]["expected"] = c["expected"]
    excluded = set(filter(None, args.exclude_source.split(",")))
    table = collections.defaultdict(collections.Counter)
    for r in latest.values():
        if r["family"] != args.family or args.expected and r["expected"] != args.expected or r["source"] in excluded:
            continue
        key = r[{"src": "source"}.get(args.row, args.row)]
        if args.part is not None:
            key = key.split("/")[args.part]
        table[key][r["cls"]] += 1
    used = [c for c in CLASSES if any(table[k][c] for k in table)]
    print("| " + " | ".join([args.row, "cases"] + used) + " |")
    print("|" + "---|" * (len(used) + 2))
    for k in sorted(table):
        print("| " + " | ".join([k, str(sum(table[k].values()))] + [str(table[k][c]) for c in used]) + " |")


if __name__ == "__main__":
    main()
