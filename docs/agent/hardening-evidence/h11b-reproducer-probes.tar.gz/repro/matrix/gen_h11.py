"""Generate H11's differential matrix: tiny programs run under pts and Node.

Families:
  A  C11   loose locals (sources) x destinations that admit undefined (or require T)
  B  C31   names array patterns bind past the end, by binding form and source
  C  C102  array patterns at holes: defaults, rest elements
  D  C111  optional callback parameters of find & kin at holes
  E  C112  find & kin over an array the callback shortens
  F  C224  element reads out of range in unknown/any contexts

Each case is cases/<family>/<id>.pts plus a line in cases.jsonl:
  {"id", "family", "finding", "source", "form", "dest", "expected"}
expected is "node" (must print what Node prints), "by-design" (D-090/D-085/D-015:
pts throws the documented error where Node goes on), or "node|range" (C112: Node's
output or D-085's RangeError).

Usage: python3 -I gen.py OUTDIR
"""

import json
import os
import sys

PRELUDE = """function report(e: unknown): void {
  console.log("threw", (e as Error).name);
  console.error("message:", (e as Error).message);
}
"""


def program(top, body):
    """A case: top-level declarations, then main's body, run under a catch."""
    lines = [PRELUDE, top, "function main(): void {", body, "}",
             "try {", "  main();", "} catch (e) {", "  report(e);", "}", ""]
    return "\n".join(lines)


# ---------------------------------------------------------------- family A (C11)

# Each source binds k (present) and v (missing: undefined in JS), of element type E.
A_SOURCES_STRING = {
    "split": ("", 'const [k, v] = "count".split(":");'),
    "array": ("", 'const src: string[] = ["count"];\n  const [k, v] = src;'),
    "set": ("", 'const [k, v] = new Set(["count"]);'),
    "string": ("", 'const [k, v] = "c";'),
    "generator": ('function* gen(): Generator<string> {\n  yield "count";\n}\n',
                  "const [k, v] = gen();"),
    "tested": ("", 'const src = ["count"];\n  const k = src[0];\n  const v = src[1];\n'
                   '  if (v === undefined) console.log("tested");'),
    "declared": ("", 'const src = ["count"];\n  const k = src[0];\n  const v: string | undefined = src[1];'),
    "record": ("", 'const rec: Record<string, string> = { a: "count" };\n  const k = rec["a"];\n'
                   '  const v = rec["b"];\n  if (!v) console.log("tested");'),
    "string_elem": ("", 'const text = "c";\n  const k = text[0];\n  const v = text[1];\n'
                        '  if (v === undefined) console.log("tested");'),
}

A_SOURCES_NUMBER = {
    "array": ("", "const src: number[] = [1];\n  const [k, v] = src;"),
    "set": ("", "const [k, v] = new Set([1]);"),
    "f64": ("", "const [k, v] = new Float64Array([1]);"),
    "tested": ("", "const src = [1];\n  const k = src[0];\n  const v = src[1];\n"
                   '  if (v === undefined) console.log("tested");'),
    "declared": ("", "const src = [1];\n  const k = src[0];\n  const v: number | undefined = src[1];"),
}

# A destination: (top-level code, code in main after the source, expected).  "{E}" is
# the element type, "{SRC}" the source's code (for destinations that wrap it in their own
# function), "{X}" a present value of E.
A_DESTS = {
    # properties
    "shorthand": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\n", "const a: Agg = { k, v };\n  console.log(a);", "node"),
    "prop": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\n", "const a: Agg = { k: k, v: v };\n  console.log(a);", "node"),
    "push_obj": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\n", "const xs: Agg[] = [];\n  xs.push({ k, v });\n  console.log(xs);", "node"),
    "return_obj": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\nfunction make(): Agg {\n  {SRC}\n  return { k, v };\n}\n",
                   "console.log(make());", "node"),
    "arrow_obj": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\n", "const make = (): Agg => ({ k, v });\n  console.log(make());", "node"),
    "partial": ("interface Agg {\n  k: {E};\n  v: {E};\n}\n", "const a: Partial<Agg> = { v };\n  console.log(a);", "node"),
    "union_prop": ("interface U {\n  k: {E};\n  v: {E} | undefined;\n}\n", "const u: U = { k, v };\n  console.log(u);", "node"),
    "class_ctor_obj": ("interface Agg {\n  k: {E};\n  v?: {E};\n}\nclass Holder {\n  constructor(public agg: Agg) {}\n}\n",
                       "console.log(new Holder({ k, v }).agg);", "node"),
    "json": ("", "console.log(JSON.stringify({ k, v }));", "node"),
    "tuple_opt": ("", "const t: [{E}, {E}?] = [k, v];\n  console.log(t);", "node"),
    # parameters
    "opt_param": ("function opt(x?: {E}): void {\n  console.log(\"opt\", x);\n}\n", "opt(v);", "node"),
    "union_param": ("function un(x: {E} | undefined): void {\n  console.log(\"un\", x);\n}\n", "un(v);", "node"),
    "default_param": ("function dflt(x: {E} = {X}): void {\n  console.log(\"dflt\", x);\n}\n", "dflt(v);", "node"),
    "method_opt": ("class C {\n  m(x?: {E}): void {\n    console.log(\"m\", x);\n  }\n}\n", "new C().m(v);", "node"),
    "static_opt": ("class S {\n  static m(x?: {E}): void {\n    console.log(\"s\", x);\n  }\n}\n", "S.m(v);", "node"),
    "ctor_opt": ("class D {\n  constructor(public x?: {E}) {}\n}\n", "console.log(new D(v).x);", "node"),
    "arrow_opt": ("const arrow = (x?: {E}): void => {\n  console.log(\"arrow\", x);\n};\n", "arrow(v);", "node"),
    "local_arrow_opt": ("", "const f = (x?: {E}) => console.log(\"local\", x);\n  f(v);", "node"),
    "fnvar_opt": ("const cb: (x?: {E}) => void = (x) => console.log(\"cb\", x);\n", "cb(v);", "node"),
    "callback_arg": ("function each(f: (x?: {E}) => void, x?: {E}): void {\n  f(x);\n}\n",
                     "each((x) => console.log(\"each\", x), v);", "node"),
    "unknown_param": ("function tu(x: unknown): void {\n  console.log(\"tu\", x);\n}\n", "tu(v);", "node"),
    "any_param": ("function ta(x: any): void {\n  console.log(\"ta\", x);\n}\n", "ta(v);", "node"),
    "rest_param": ("function rest(...xs: ({E} | undefined)[]): void {\n  console.log(\"rest\", xs);\n}\n", "rest(k, v);", "node"),
    # locals
    "let_union": ("", "let t: {E} | undefined = v;\n  console.log(t);", "node"),
    "const_nullish": ("", "const t: {E} | null | undefined = v;\n  console.log(t);", "node"),
    "unknown_local": ("", "const t: unknown = v;\n  console.log(t);", "node"),
    "any_local": ("", "const t: any = v;\n  console.log(t);", "node"),
    # results
    "return_union": ("function get(): {E} | undefined {\n  {SRC}\n  return v;\n}\n", "console.log(get());", "node"),
    "return_unknown": ("function get(): unknown {\n  {SRC}\n  return v;\n}\n", "console.log(get());", "node"),
    "return_any": ("function get(): any {\n  {SRC}\n  return v;\n}\n", "console.log(get());", "node"),
    "arrow_result_union": ("", "const r = (): {E} | undefined => v;\n  console.log(r());", "node"),
    "arrow_result_unknown": ("", "const r = (): unknown => v;\n  console.log(r());", "node"),
    # collections and generics
    "array_union": ("", "const xs: ({E} | undefined)[] = [v];\n  console.log(xs);", "node"),
    "array_unknown": ("", "const xs: unknown[] = [v];\n  console.log(xs);", "node"),
    "push_union": ("", "const xs: ({E} | undefined)[] = [];\n  xs.push(v);\n  console.log(xs);", "node"),
    "map_set": ("", "const m = new Map<string, {E} | undefined>();\n  m.set(\"k\", v);\n  console.log(m);", "node"),
    "set_add": ("", "const s = new Set<{E} | undefined>();\n  s.add(v);\n  console.log(s);", "node"),
    "generic_explicit": ("function id<T>(x: T): T {\n  return x;\n}\n", "console.log(id<{E} | undefined>(v));", "node"),
    "generic_box": ("interface Box<T> {\n  val: T;\n}\n", "const b: Box<{E} | undefined> = { val: v };\n  console.log(b);", "node"),
    # assignments
    "assign_local": ("", "let t: {E} | undefined = {X};\n  t = v;\n  console.log(t);", "node"),
    "assign_field": ("class H {\n  f: {E} | undefined = {X};\n}\n", "const h = new H();\n  h.f = v;\n  console.log(h.f);", "node"),
    "assign_opt_field": ("class H {\n  f?: {E};\n}\n", "const h = new H();\n  h.f = v;\n  console.log(h.f);", "node"),
    # conditionals
    "cond_branch": ("", "const t: {E} | undefined = Math.random() < 2 ? v : {X};\n  console.log(t);", "node"),
    "cond_arg": ("function opt(x?: {E}): void {\n  console.log(\"opt\", x);\n}\n", "opt(Math.random() < 2 ? v : {X});", "node"),
    "nullish": ("", "console.log(v ?? {X});", "node"),
    "or": ("", "console.log(v || {X});", "node"),
    "and_arg": ("function opt(x?: {E}): void {\n  console.log(\"opt\", x);\n}\n", "opt(k && v);", "node"),
    # controls: any value goes
    "log": ("", "console.log(k, v);", "node"),
    "log_array_literal": ("", "console.log([k, v]);", "node"),
    "template": ("", "console.log(`${k}:${v}`);", "node"),
    "eq": ("", "console.log(v === undefined);", "node"),
    # by design: a destination that requires E (D-090's TypeError)
    "T_const": ("", "const t: {E} = v;\n  console.log(t);", "by-design"),
    "T_param": ("function need(x: {E}): void {\n  console.log(\"need\", x);\n}\n", "need(v);", "by-design"),
    "T_return": ("function get(): {E} {\n  {SRC}\n  return v;\n}\n", "console.log(get());", "by-design"),
    "T_array": ("", "const xs: {E}[] = [v];\n  console.log(xs);", "by-design"),
    "T_prop": ("interface R {\n  v: {E};\n}\n", "const r: R = { v };\n  console.log(r);", "by-design"),
    "T_generic_inferred": ("function id<T>(x: T): T {\n  return x;\n}\n", "console.log(id(v));", "by-design"),
}

A_PRESENT = {"string": '"x"', "number": "7"}

# Number sources take a subset of the destinations (one of each kind).
A_NUMBER_DESTS = {"shorthand", "prop", "return_obj", "opt_param", "union_param", "default_param", "method_opt",
                  "ctor_opt", "fnvar_opt", "unknown_param", "let_union", "unknown_local", "return_union",
                  "arrow_result_unknown", "array_union", "map_set", "generic_explicit", "assign_local",
                  "cond_branch", "nullish", "or", "log", "T_const", "T_param", "T_array"}


def family_a(out):
    cases = []
    for etype, sources in (("string", A_SOURCES_STRING), ("number", A_SOURCES_NUMBER)):
        for sname, (stop, src) in sources.items():
            for dname, (dtop, dbody, expected) in A_DESTS.items():
                if etype == "number" and dname not in A_NUMBER_DESTS:
                    continue
                fill = lambda text: text.replace("{E}", etype).replace("{X}", A_PRESENT[etype]).replace("{SRC}", src)
                top = stop + fill(dtop)
                if "{SRC}" in dtop:
                    body = "  " + fill(dbody)
                else:
                    body = "  " + src + "\n  " + fill(dbody)
                cases.append(dict(family="A", finding="C11", source=f"{etype}:{sname}", form="-", dest=dname,
                                  expected=expected, text=program(top, body)))
    return cases


# ---------------------------------------------------------------- family B (C31)

# A source: (type T, a value of T with one item, element type E, a present E, top code).
B_SOURCES = {
    "array": ("string[]", '["x"]', "string", '"y"', ""),
    "maybe": ("(string | undefined)[]", '["x"]', "string | undefined", '"y"', ""),
    "nums": ("number[]", "[1]", "number", "7", ""),
    "split": ("string[]", '"x".split(",")', "string", '"y"', ""),
    "string": ("string", '"x"', "string", '"y"', ""),
    "set": ("Set<string>", 'new Set(["x"])', "string", '"y"', ""),
    "map": ("Map<string, number>", 'new Map([["x", 1]])', "[string, number]", '["y", 2]', ""),
    "f64": ("Float64Array", "new Float64Array([1])", "number", "7", ""),
    "generator": ("Generator<string>", "gen()", "string", '"y"', 'function* gen(): Generator<string> {\n  yield "x";\n}\n'),
    "iterable": ("Iterable<string>", 'iterOf(["x"])', "string", '"y"',
                 "function iterOf(xs: string[]): Iterable<string> {\n  return xs;\n}\n"),
    "any": ("any", '["x"]', "any", '"y"', ""),
}

# A form binds a (present) and b (past the end) and runs {USE}.
B_FORMS = {
    "param": ("function f([a, b]: {T}): void {\n  {USE}\n}\n", "f({V});"),
    "param_default": ("function f([a, b]: {T} = {V}): void {\n  {USE}\n}\n", "f();"),
    "param_generic": ("function f<S extends {T}>([a, b]: S): void {\n  {USE}\n}\n", "f({V});"),
    "arrow": ("const f = ([a, b]: {T}): void => {\n  {USE}\n};\n", "f({V});"),
    "method": ("class C {\n  m([a, b]: {T}): void {\n    {USE}\n  }\n}\n", "new C().m({V});"),
    "ctor": ("class C {\n  constructor([a, b]: {T}) {\n    {USE}\n  }\n}\n", "new C({V});"),
    "callback": ("", "const rows: {T}[] = [{V}];\n  rows.forEach(([a, b]) => {\n    {USE}\n  });"),
    "forof_const": ("", "const rows: {T}[] = [{V}];\n  for (const [a, b] of rows) {\n    {USE}\n  }"),
    "forof_let": ("", "const rows: {T}[] = [{V}];\n  for (let [a, b] of rows) {\n    {USE}\n  }"),
    "nested": ("", "const rows: {T}[] = [{V}];\n  const [[a, b]] = rows;\n  {USE}"),
    "nested_tuple": ("", "const pair: [{T}] = [{V}];\n  const [[a, b]] = pair;\n  {USE}"),
    "rest_pattern": ("", "const src: {T} = {V};\n  const [a, ...[b]] = src;\n  {USE}"),
    "object_nested": ("", "const o: { p: {T} } = { p: {V} };\n  const { p: [a, b] } = o;\n  {USE}"),
    "param_object_nested": ("function f({ p: [a, b] }: { p: {T} }): void {\n  {USE}\n}\n", "f({ p: {V} });"),
    "decl_const": ("", "const src: {T} = {V};\n  const [a, b] = src;\n  {USE}"),
    "decl_let": ("", "const src: {T} = {V};\n  let [a, b] = src;\n  {USE}"),
}

B_USES = {
    "log": ('console.log("got", a, b);', "node"),
    "opt": ('opt(b);', "node"),
    "typed": ('const t: {E} = b;\n  console.log("typed", t);', "by-design"),
}

B_OPT = "function opt(x?: {E}): void {\n  console.log(\"opt\", x);\n}\n"


def family_b(out):
    cases = []
    for sname, (t, value, etype, present, stop) in B_SOURCES.items():
        for fname, (ftop, fbody) in B_FORMS.items():
            for uname, (use, expected) in B_USES.items():
                if uname == "typed" and ("undefined" in etype or etype == "any"):
                    expected = "node"  # E holds undefined: not a required-T destination
                fill = lambda text: text.replace("{T}", t).replace("{V}", value).replace("{E}", etype)
                use_text = fill(use)
                top = stop + fill(B_OPT) + fill(ftop).replace("{USE}", use_text)
                body = "  " + fill(fbody).replace("{USE}", use_text)
                cases.append(dict(family="B", finding="C31", source=sname, form=fname, dest=uname,
                                  expected=expected, text=program(top, body)))
    return cases


# ---------------------------------------------------------------- family C (C102)

C_TOP = """class P {
  constructor(public x: number) {}
}
function strs(): string[] {
  const a = new Array<string>(3);
  a[1] = "b";
  return a;
}
function maybe(): (string | undefined)[] {
  const a = new Array<string | undefined>(3);
  a[1] = "b";
  return a;
}
function points(): P[] {
  const a = new Array<P>(3);
  a[1] = new P(1);
  return a;
}
function nums(): number[] {
  const a = new Array<number>(3);
  a[1] = 1;
  return a;
}
"""

# (type T, expression, element type E, default D, expected-override for rest forms)
C_SOURCES = {
    "holes_string": ("string[]", "strs()", "string", '"D"'),
    "holes_maybe": ("(string | undefined)[]", "maybe()", "string | undefined", '"D"'),
    "holes_points": ("P[]", "points()", "P", "new P(9)"),
    "holes_numbers": ("number[]", "nums()", "number", "9"),
    "match": ("RegExpExecArray", '/(a)|(b)/.exec("xb")!', "string", '"D"'),
    "match_copy": ("string[]", '/(a)|(b)/.exec("xb")!.slice()', "string", '"D"'),
}

C_FORMS = {
    "decl_default": ("", "const [p = {D}, q = {D}, r = {D}] = {S};\n  console.log(p, q, r);"),
    "assign_default": ("", "let p: {E} | undefined, q: {E} | undefined, r: {E} | undefined;\n  [p = {D}, q = {D}, r = {D}] = {S};\n  console.log(p, q, r);"),
    "param_default": ("function f([p = {D}, q = {D}, r = {D}]: {T}): void {\n  console.log(p, q, r);\n}\n", "f({S});"),
    "forof_default": ("", "for (const [p = {D}, q = {D}, r = {D}] of [{S}]) console.log(p, q, r);"),
    "nested_default": ("", "const [[p = {D}, q = {D}, r = {D}]] = [{S}];\n  console.log(p, q, r);"),
    "object_nested_default": ("", "const { s: [p = {D}, q = {D}, r = {D}] } = { s: {S} };\n  console.log(p, q, r);"),
    "rest": ("", "const [, ...rest] = {S};\n  console.log(rest);"),
    "nested_rest": ("", "const [[x, ...ys]] = [{S}];\n  console.log(x, ys);"),
    "rest_default": ("", "const [x, ...[y = {D}, z = {D}]] = {S};\n  console.log(x, y, z);"),
    "spread": ("", "console.log([...{S}]);"),
}


def family_c(out):
    cases = []
    for sname, (t, expr, etype, dflt) in C_SOURCES.items():
        for fname, (ftop, fbody) in C_FORMS.items():
            expected = "node"
            if sname == "holes_numbers":
                expected = "by-design"  # D-085: a number array's slots start as 0, not holes
            elif sname in ("holes_string", "holes_points") and fname in ("rest", "nested_rest", "spread"):
                expected = "by-design"  # D-182, D-183: a string[]'s or object array's rest and spread keep holes
            fill = lambda text: text.replace("{T}", t).replace("{S}", expr).replace("{E}", etype).replace("{D}", dflt)
            cases.append(dict(family="C", finding="C102", source=sname, form=fname, dest="-",
                              expected=expected, text=program(C_TOP + fill(ftop), "  " + fill(fbody))))
    return cases


# ---------------------------------------------------------------- family D (C111)

D_TOP = C_TOP + """interface I {
  name: string;
}
function items(): I[] {
  const a = new Array<I>(3);
  a[1] = { name: "i" };
  return a;
}
"""

D_SOURCES = {
    "class": ("P", "points()"),
    "interface": ("I", "items()"),
    "string": ("string", "strs()"),
    "number": ("number", "nums()"),
}

D_METHODS = {
    "find": "{S}.find({CB})",
    "findIndex": "{S}.findIndex({CB})",
    "findLast": "{S}.findLast({CB})",
    "findLastIndex": "{S}.findLastIndex({CB})",
    "Array.from": "Array.from({S}, {CB})",
}

# (callback, top code, expected)
D_PARAMS = {
    "optional": ("(p?: {E}) => p === undefined", "", "node"),
    "union": ("(p: {E} | undefined) => p === undefined", "", "node"),
    "optional_index": ("(p?: {E}, i?: number) => p === undefined && i !== 1", "", "node"),
    "function_expr": ("function (p?: {E}) {\n    return p === undefined;\n  }", "", "node"),
    "named_optional": ("isMissing", "function isMissing(p?: {E}): boolean {\n  return p === undefined;\n}\n", "node"),
    "required": ("(p: {E}) => p === undefined", "", "by-design"),
}


def family_d(out):
    cases = []
    for sname, (etype, expr) in D_SOURCES.items():
        for mname, call in D_METHODS.items():
            for pname, (cb, ptop, expected) in D_PARAMS.items():
                if sname == "number":
                    expected = "by-design"  # D-085: number arrays have no holes
                fill = lambda text: text.replace("{E}", etype)
                body = "  console.log(" + call.replace("{S}", expr).replace("{CB}", fill(cb)) + ");"
                cases.append(dict(family="D", finding="C111", source=sname, form=mname, dest=pname,
                                  expected=expected, text=program(D_TOP + fill(ptop), body)))
    return cases


# ---------------------------------------------------------------- family E (C112)

E_SOURCES = {
    "string": ("string", '["a", "b", "c"]'),
    "number": ("number", "[1, 2, 3]"),
    "class": ("P", "[new P(1), new P(2), new P(3)]"),
}

E_METHODS = ["find", "findIndex", "findLast", "findLastIndex", "forEach", "some", "every", "map", "filter"]

E_PARAMS = {
    "inferred": ("(x, i)", "node|range"),
    "optional": ("(x?: {E}, i?: number)", "node"),
    "union": ("(x: {E} | undefined, i: number)", "node"),
}

E_SHRINKS = {
    "length": "xs.length = 1",
    "pop": "xs.pop(); xs.pop()",
}


def family_e(out):
    cases = []
    for sname, (etype, literal) in E_SOURCES.items():
        for method in E_METHODS:
            for pname, (params, expected) in E_PARAMS.items():
                for shname, shrink in E_SHRINKS.items():
                    if shname == "pop" and method not in ("find", "findLast"):
                        continue
                    # findLast* start at the end: shrink at the first call either way.
                    first = "first" if True else ""
                    result = "false" if method != "every" else "true"
                    if method == "map":
                        result = '"m"'  # a string[] result can hold map's holes (a number[] can't, D-085)
                    body = (f"  const xs: {etype}[] = {literal};\n"
                            "  const seen: unknown[] = [];\n"
                            "  let first = true;\n"
                            f"  const r = xs.{method}({params.replace('{E}', etype)} => {{\n"
                            f"    if (first) {{\n      first = false;\n      {shrink};\n    }}\n"
                            "    seen.push(i, x);\n"
                            f"    return {result};\n"
                            "  });\n"
                            "  console.log(seen, r, xs.length);")
                    if method == "forEach":
                        body = body.replace(f"    return {result};\n", "")
                    cases.append(dict(family="E", finding="C112", source=sname, form=method, dest=f"{pname}/{shname}",
                                      expected=expected, text=program(C_TOP, body)))
    return cases


# ---------------------------------------------------------------- family F (C224)

F_TOP = C_TOP + """function takesUnknown(x: unknown): void {
  console.log("unknown", x);
}
function takesAny(x: any): void {
  console.log("any", x);
}
function takesOptionalUnknown(x?: unknown): void {
  console.log("optional unknown", x);
}
function takesOptional(x?: {E}): void {
  console.log("optional", x);
}
function takesUnion(x: {E} | undefined): void {
  console.log("union", x);
}
function id<T>(x: T): T {
  return x;
}
"""

# (declarations in main, the read, element type E)
F_SOURCES = {
    "string": ('const s = "ab";', "s[5]", "string"),
    "array": ('const arr = ["a"];', "arr[5]", "string"),
    "numbers": ("const ns = [1];", "ns[5]", "number"),
    "points": ("const ps = [new P(1)];", "ps[5]", "P"),
    "record": ('const rec: Record<string, string> = { a: "a" };', 'rec["zz"]', "string"),
    "f64": ("const fs = new Float64Array([1]);", "fs[5]", "number"),
    "hole": ("const hs = strs();", "hs[0]", "string"),
}

F_CONTEXTS = {
    "unknown_param": ("takesUnknown({R});", "node"),
    "any_param": ("takesAny({R});", "node"),
    "optional_unknown_param": ("takesOptionalUnknown({R});", "node"),
    "unknown_result_fn": ("function r(): unknown {\n    return {R};\n  }\n  console.log(r());", "node"),
    "any_result_fn": ("function r(): any {\n    return {R};\n  }\n  console.log(r());", "node"),
    "unknown_result_arrow": ("const r = (): unknown => {R};\n  console.log(r());", "node"),
    "any_result_arrow": ("const r = (): any => {R};\n  console.log(r());", "node"),
    "unknown_array_literal": ("const xs: unknown[] = [{R}];\n  console.log(xs);", "node"),
    "any_array_literal": ("const xs: any[] = [{R}];\n  console.log(xs);", "node"),
    "unknown_push": ("const xs: unknown[] = [];\n  xs.push({R});\n  console.log(xs);", "node"),
    "unknown_prop": ("const o: { v: unknown } = { v: {R} };\n  console.log(o);", "node"),
    "any_prop": ("const o: { v: any } = { v: {R} };\n  console.log(o);", "node"),
    "unknown_record": ("const o: Record<string, unknown> = { v: {R} };\n  console.log(o);", "node"),
    "unknown_tuple": ("const t: [unknown] = [{R}];\n  console.log(t);", "node"),
    "unknown_map_set": ("const m = new Map<string, unknown>();\n  m.set(\"k\", {R});\n  console.log(m);", "node"),
    "unknown_assign": ("let u: unknown = 1;\n  u = {R};\n  console.log(u);", "node"),
    "unknown_cond": ("const u: unknown = Math.random() < 2 ? {R} : 1;\n  console.log(u);", "node"),
    "generic_unknown": ("console.log(id<unknown>({R}));", "node"),
    # controls
    "const_unknown": ("const u: unknown = {R};\n  console.log(u);", "node"),
    "const_any": ("const u: any = {R};\n  console.log(u);", "node"),
    "String": ("console.log(String({R}));", "node"),
    "log": ("console.log({R});", "node"),
    "optional_param": ("takesOptional({R});", "node"),
    "union_param": ("takesUnion({R});", "node"),
    # by design: D-015's RangeError where an E is required
    "T_const": ("const t: {E} = {R};\n  console.log(t);", "by-design"),
}


def family_f(out):
    cases = []
    for sname, (decl, read, etype) in F_SOURCES.items():
        for cname, (code, expected) in F_CONTEXTS.items():
            body = "  " + decl + "\n  " + code.replace("{R}", read).replace("{E}", etype)
            cases.append(dict(family="F", finding="C224", source=sname, form="-", dest=cname,
                              expected=expected, text=program(F_TOP.replace("{E}", etype), body)))
    return cases


# ---------------------------------------------------------------- family G (extras)

# Appended last so the earlier families' ids stay stable.
G_CASES = [
    # for...of over holes (D-183 leaves a string[]'s and object array's to H11)
    ("C102", "holes_string", "forof_plain", "-", "node", C_TOP, "  for (const x of strs()) console.log(x);"),
    ("C102", "holes_points", "forof_plain", "-", "node", C_TOP, "  for (const x of points()) console.log(x);"),
    ("C102", "holes_maybe", "forof_plain", "-", "node", C_TOP, "  for (const x of maybe()) console.log(x);"),
    ("C102", "match", "forof_plain", "-", "node", C_TOP, '  for (const x of /(a)|(b)/.exec("xb")!) console.log(x);'),
    ("C102", "holes_string", "forof_plain_tested", "-", "node", C_TOP,
     '  for (const x of strs()) console.log(x === undefined ? "hole" : x);'),
    ("C102", "holes_string", "forof_optional", "-", "node",
     C_TOP + "function opt(x?: string): void {\n  console.log(\"opt\", x);\n}\n", "  for (const x of strs()) opt(x);"),
    # the hint of a (number | undefined)[] parameter pattern's RangeError (H03a review round 6)
    ("C31-hint", "maybe_numbers", "param", "log", "node",
     "function f([a, b]: (number | undefined)[]): void {\n  console.log(a, b);\n}\n", "  f([1]);"),
    ("C31-hint", "maybe_numbers", "forof_const", "log", "node", "",
     "  const rows: (number | undefined)[][] = [[1]];\n  for (const [a, b] of rows) console.log(a, b);"),
    ("C31-hint", "maybe_numbers", "nested", "log", "node", "",
     "  const rows: (number | undefined)[][] = [[1]];\n  const [[a, b]] = rows;\n  console.log(a, b);"),
    # a nested pattern over an element that isn't there: JS throws TypeError (not iterable)
    ("C31", "array", "nested_missing", "log", "node", "",
     '  const rows: string[][] = [["x"]];\n  const [[a], [c, d]] = rows;\n  console.log(a, c, d);'),
    ("C31", "array", "nested_missing_object", "log", "node", "class Pt {\n  constructor(public x: number) {}\n}\n",
     "  const pts: Pt[] = [new Pt(1)];\n  const [{ x }, { x: y }] = pts;\n  console.log(x, y);"),
    ("C31", "array", "param_nested_missing", "log", "node", "function f([[a], [c, d]]: string[][]): void {\n  console.log(a, c, d);\n}\n",
     '  f([["x"]]);'),
    # guards: tuples stay typed and match Node
    ("guard", "tuple", "decl_const", "typed", "node", "",
     '  const pair: [string, number] = ["a", 1];\n  const [a, b] = pair;\n  const t: number = b;\n  console.log(a, t + 1);'),
    ("guard", "tuple", "param", "typed", "node", "function f([a, b]: [string, number]): number {\n  return a.length + b;\n}\n",
     '  console.log(f(["ab", 1]));'),
    ("guard", "map_entries", "forof_const", "typed", "node", "",
     '  const m = new Map([["a", 1], ["b", 2]]);\n  let sum = 0;\n  for (const [k, v] of m) sum += k.length + v;\n  console.log(sum);'),
    ("guard", "entries", "forof_const", "typed", "node", "",
     '  let sum = 0;\n  for (const [i, x] of ["a", "bc"].entries()) sum += i + x.length;\n  console.log(sum);'),
    ("guard", "tuple_rows", "forof_const", "typed", "node", "",
     '  const rows: [string, number][] = [["a", 1], ["b", 2]];\n  let sum = 0;\n  for (const [k, v] of rows) sum += v;\n  console.log(sum);'),
    ("guard", "array", "hot_loop", "typed", "node", "",
     "  const xs = [1, 2, 3];\n  let sum = 0;\n  for (let i = 0; i < xs.length; i++) sum += xs[i];\n  console.log(sum);"),
    ("guard", "array", "required_range", "typed", "by-design", "",
     "  const xs = [1];\n  const n: number = xs[5];\n  console.log(n);"),
]


def family_g(out):
    return [dict(family="G", finding=f, source=s, form=fm, dest=d, expected=e, text=program(top, body))
            for (f, s, fm, d, e, top, body) in G_CASES]


def main():
    out = sys.argv[1]
    cases = []
    for family in (family_a, family_b, family_c, family_d, family_e, family_f, family_g):
        cases.extend(family(out))
    seen = set()
    with open(os.path.join(out, "cases.jsonl"), "w") as index:
        for n, case in enumerate(cases):
            ident = "{}{:04d}".format(case["family"], n)
            assert ident not in seen
            seen.add(ident)
            directory = os.path.join(out, "cases", case["family"])
            os.makedirs(directory, exist_ok=True)
            path = os.path.join(directory, ident + ".pts")
            header = "// {} {} source={} form={} dest={} expected={}\n".format(
                ident, case["finding"], case["source"], case["form"], case["dest"], case["expected"])
            text = header + case["text"]
            old = open(path).read() if os.path.exists(path) else None
            if old != text:  # rewrite only what changed, so a run in progress reads whole files
                with open(path + ".tmp", "w") as f:
                    f.write(text)
                os.replace(path + ".tmp", path)
            meta = {k: v for k, v in case.items() if k != "text"}
            meta.update(id=ident, path=path)
            index.write(json.dumps(meta) + "\n")
    counts = {}
    for case in cases:
        counts[case["family"]] = counts.get(case["family"], 0) + 1
    print(len(cases), "cases", counts)


if __name__ == "__main__":
    main()
