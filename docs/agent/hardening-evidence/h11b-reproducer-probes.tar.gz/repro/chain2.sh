#!/bin/bash
# After the HEAD matrix: rerun the generator-fixed cases and family L on HEAD; build
# prototype A2; run the for…of families (H, K, L) with prototype A; cost measurements
# (HEAD, A, A2); then H with prototype B. One heavy step (≤ 2 jobs) at a time.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
M=/tmp/h11b/repro/matrix
until grep -q "new matrix head exit" /tmp/h11b/repro/chain1.log; do sleep 10; done
cd "$M" || exit 1
python3 -I filter_family.py cases.jsonl cases_hkl.jsonl H K L
python3 -I run_matrix.py cases.jsonl results_head.jsonl --jobs 2 --force --filter '"dest": "predicate"|"id": "H0(182|183|499)"' > run_head_fix.log 2>&1
python3 -I run_matrix.py cases.jsonl results_head.jsonl --jobs 2 > run_head_l.log 2>&1
echo "head fixes and L done $(date +%T)"
cd "$W" || exit 1
mkdir -p /tmp/h11b/repro/proto/A2/bin
GOMAXPROCS=2 go build -overlay /tmp/h11b/repro/proto/A2/overlay.json -o /tmp/h11b/repro/proto/A2/bin/pts ./cmd/pts > /tmp/h11b/repro/proto/A2/build.log 2>&1
echo "proto A2 build exit=$? $(date +%T)"
cd "$M" || exit 1
python3 -I run_matrix.py cases_hkl.jsonl results_A.jsonl --jobs 2 --pts /tmp/h11b/repro/proto/A/bin/pts > run_A.log 2>&1
echo "A matrix done $(date +%T)"
bash /tmp/h11b/repro/cost/cost.sh head "$W/pts-bin/pts" > /tmp/h11b/repro/cost/cost_head.log 2>&1
bash /tmp/h11b/repro/cost/cost.sh A /tmp/h11b/repro/proto/A/bin/pts > /tmp/h11b/repro/cost/cost_A.log 2>&1
bash /tmp/h11b/repro/cost/cost.sh A2 /tmp/h11b/repro/proto/A2/bin/pts > /tmp/h11b/repro/cost/cost_A2.log 2>&1
echo "cost done $(date +%T)"
python3 -I filter_family.py cases.jsonl cases_h.jsonl H
python3 -I run_matrix.py cases_h.jsonl results_B.jsonl --jobs 2 --pts /tmp/h11b/repro/proto/B/bin/pts > run_B.log 2>&1
echo "B matrix done $(date +%T)"
