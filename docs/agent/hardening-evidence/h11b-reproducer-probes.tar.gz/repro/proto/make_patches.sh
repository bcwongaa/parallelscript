#!/bin/bash
# The prototypes as patches against the worktree's (unchanged) sources.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
P=/tmp/h11b/repro/proto
for d in A B A2; do
  out="$P/$d/forof_design_$d.patch"
  diff -u "$W/pts/lower/loose_locals.go" "$P/$d/loose_locals.go" > "$out"
  diff -u "$W/pts/lower/arrays.go" "$P/$d/arrays.go" >> "$out"
  wc -l "$out"
done
