#!/bin/bash
# emit-c of the cost probes with HEAD's CLI and prototype A's, for reading the loops.
W=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a626b83f05c2c9be2
D=/tmp/h11b/repro/cost
for n in strings points multi_use closure tested points_iface numbers; do
  PTS_HOME="$W" "$W/pts-bin/pts" emit-c "$D/cost_$n.pts" -o "$D/emit/$n.head.c"
  PTS_HOME="$W" /tmp/h11b/repro/proto/A/bin/pts emit-c "$D/cost_$n.pts" -o "$D/emit/$n.A.c"
done
ls "$D/emit"
