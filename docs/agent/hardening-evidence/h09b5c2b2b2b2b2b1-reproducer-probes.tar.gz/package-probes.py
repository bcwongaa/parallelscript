import difflib
import hashlib
import json
import pathlib
import shutil
import tarfile

repo = pathlib.Path("/home/bryan/projects/parallelscript/.claude/worktrees/agent-a41c84f2e415eee69")
out = pathlib.Path("/tmp/pts-inline-reproducer.aOeo8E")
owned = ["pts/lower/inline_container_sources_test.go", "pts/driver/inline_container_flow_test.go", "pts/tests/run/generic_inline_container_sources.pts"]
manifest = dict(base="50d8ed087bf5836cb2fc912076e905d629b570e6", task="H09b5c2b2b2b2b2b1", runtime_model="gpt-6.1-sol", requested_effort="xhigh (inherited; no model override)", files=[])
patch = []
for relative in owned:
    source = repo / relative
    target = out / "inputs" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    content = source.read_bytes()
    manifest["files"].append(dict(path=str(source), sha256=hashlib.sha256(content).hexdigest(), bytes=len(content), lines=content.count(b"\n")))
    patch.append("diff --git a/" + relative + " b/" + relative + "\nnew file mode 100644\n")
    patch.extend(difflib.unified_diff([], content.decode().splitlines(keepends=True), fromfile="/dev/null", tofile="b/" + relative))
(out / "frozen-inputs.json").write_text(json.dumps(manifest, indent=2) + "\n")
(out / "inputs.patch").write_text("".join(patch))
archive = out.parent / (out.name + ".tar.gz")
with tarfile.open(archive, "w:gz") as packed:
    for path in sorted(out.rglob("*")):
        if path.is_file() and path.name != "strict-native" and not path.name.endswith(".bin"):
            packed.add(path, arcname=path.relative_to(out), recursive=False)
print(json.dumps(manifest, indent=2))
print("ARCHIVE", archive, "SHA256", hashlib.sha256(archive.read_bytes()).hexdigest(), "BYTES", archive.stat().st_size)
