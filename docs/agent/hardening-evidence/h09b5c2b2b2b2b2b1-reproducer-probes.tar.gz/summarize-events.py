import collections
import json
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
counts = collections.Counter()
failures = []
leaf = collections.Counter()
for line in path.read_text().splitlines():
    event = json.loads(line)
    if event.get("Test") and event.get("Action") in ("pass", "fail", "skip"):
        counts[event["Action"]] += 1
        if event["Action"] == "fail":
            failures.append(event["Test"])
            leaf[event["Test"].split("/")[0]] += 1
    if event.get("Action") == "output":
        output = event.get("Output", "")
        if any(part in output for part in ("Error:", "build failed", "panic:", "direct AllInstances:", "the fresh inline literal", "identical unmodified fixture", "screen declared alias", "same fixture", "shared Value")):
            print(output, end="")
print("COUNTS", dict(counts))
print("FAILURE_GROUPS", json.dumps(leaf, sort_keys=True))
print("FAILURE_TESTS", json.dumps(failures))
