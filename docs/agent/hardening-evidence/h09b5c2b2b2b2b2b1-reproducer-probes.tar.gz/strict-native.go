package main

import (
	"context"
	"fmt"
	"os"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: strict-native emit|strict|default entry output")
		os.Exit(2)
	}
	if err := compile(os.Args[1], os.Args[2], os.Args[3]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func compile(mode, entry, output string) error {
	ctx := context.Background()
	if mode == "default" {
		return driver.Build(ctx, entry, output)
	}
	code, err := driver.EmitCWith(ctx, entry, lower.AllInstances)
	if err != nil {
		return err
	}
	cFile := output
	if mode == "strict" {
		cFile += ".c"
	} else if mode != "emit" {
		return fmt.Errorf("unsupported mode %q", mode)
	}
	if err := os.WriteFile(cFile, []byte(code), 0o600); err != nil {
		return err
	}
	if mode == "emit" {
		return nil
	}
	compiler, err := toolchain.New()
	if err != nil {
		return err
	}
	runtime, err := compiler.Runtime(ctx, toolchain.Release)
	if err != nil {
		return err
	}
	return compiler.CompileProgram(ctx, runtime, []string{cFile}, output)
}
