import json
import os
import pathlib
import subprocess
import sys

repo = pathlib.Path("/home/bryan/projects/parallelscript/.claude/worktrees/agent-a41c84f2e415eee69")
out = pathlib.Path("/tmp/pts-inline-reproducer.aOeo8E")
source = repo / "pts/tests/run/generic_inline_container_sources.pts"
helper = out / "strict-native"
if pathlib.Path.cwd() != repo:
    raise SystemExit("run only from the assigned worktree")
text = source.read_text()
expected = "\n".join(line.removeprefix("// ") for line in text.split("// expect:\n", 1)[1].splitlines()) + "\n"
(out / "fixture.expected").write_text(expected)
node_source = out / "generic_inline_container_sources.mts"
node_source.write_text(text)
env = os.environ.copy()
env.update(GOMAXPROCS="1", PTS_HOME="/home/bryan/projects/parallelscript")
receipts = []

def run(name, command):
    stdout = out / (name + ".stdout")
    stderr = out / (name + ".stderr")
    if stdout.exists() or stderr.exists():
        raise SystemExit("refusing to overwrite original evidence: " + name)
    result = subprocess.run(command, cwd=repo, env=env, text=True, capture_output=True, timeout=600)
    stdout.write_text(result.stdout)
    stderr.write_text(result.stderr)
    (out / (name + ".exit")).write_text(str(result.returncode) + "\n")
    receipt = dict(name=name, command=[str(arg) for arg in command], exit=result.returncode)
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    return result

node = run("base-node", ["/home/bryan/.local/node/bin/node", "--no-warnings", "--experimental-transform-types", node_source])
for mode in ("strict", "default"):
    binary = out / ("fixture-base-" + mode + ".bin")
    compiled = run("base-" + mode + "-compile", [helper, mode, source, binary])
    if compiled.returncode == 0:
        native = run("base-" + mode + "-native", [binary])
        receipts.append(dict(name="base-" + mode + "-comparison", expected=native.stdout == expected,
                             node=native.stdout == node.stdout, native_exit=native.returncode, node_exit=node.returncode))
        binary.unlink()
receipts.append(dict(name="base-node-expected", expected=node.stdout == expected, node_exit=node.returncode))
(out / "semantic-receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")
print(json.dumps(receipts, indent=2))
if any(receipt.get("exit", 0) != 0 or receipt.get("expected", True) is False or receipt.get("node", True) is False for receipt in receipts):
    sys.exit(1)
