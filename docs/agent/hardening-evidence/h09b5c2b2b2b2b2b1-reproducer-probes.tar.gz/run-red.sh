#!/usr/bin/env bash
set -u
set -o pipefail
repo=/home/bryan/projects/parallelscript/.claude/worktrees/agent-a41c84f2e415eee69
out=/tmp/pts-inline-reproducer.aOeo8E
if [[ "$PWD" != "$repo" ]]; then
  printf 'Run from assigned worktree: %s\n' "$repo" >&2
  exit 2
fi
if [[ -e "$out/red.jsonl" || -e "$out/red.exit" ]]; then
  printf 'Refusing to overwrite original RED evidence\n' >&2
  exit 2
fi
printf '%s\n' 'GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 20m -run ^TestInlineContainer ./pts/lower ./pts/driver' > "$out/red.command.txt"
GOMAXPROCS=1 go test -count=1 -json -p 1 -parallel 1 -timeout 20m -run '^TestInlineContainer' ./pts/lower ./pts/driver > "$out/red.jsonl" 2> "$out/red.stderr"
status=$?
printf '%s\n' "$status" > "$out/red.exit"
exit "$status"
