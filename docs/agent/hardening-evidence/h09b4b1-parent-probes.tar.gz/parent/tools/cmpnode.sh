#!/bin/bash
# cmpnode.sh LABEL CLI PTS_HOME files... : run each with Node (.mts) and the CLI; SAME/DIFF and the first lines
label=$1; cli=$2; home=$3; shift 3
work=/tmp/h09b4b/s2/cn-$label; mkdir -p $work
for f in "$@"; do
  f=$(realpath $f); n=$(basename $f .pts)
  cp $f $work/$n.mts
  (cd $work && TZ=America/New_York timeout 60 ~/.local/node/bin/node --no-warnings --experimental-transform-types $n.mts > $n.node 2>&1; echo "exit=$?" >> $n.node)
  (cd $work && TZ=America/New_York PTS_HOME=$home PTS_CACHE_DIR=/tmp/h09b4b/.cache-$label timeout 300 $cli run $f > $n.out 2>&1; echo "exit=$?" >> $n.out)
  if cmp -s $work/$n.node $work/$n.out; then echo "SAME $n"; else echo "DIFF $n :: $(diff $work/$n.node $work/$n.out | grep '^>' | head -2 | cut -c1-200 | tr '\n' ' ')"; fi
done
