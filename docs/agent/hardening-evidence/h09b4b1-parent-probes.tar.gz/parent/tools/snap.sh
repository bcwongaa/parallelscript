#!/bin/bash
# snap.sh NAME : a byte-checked worktree of main's HEAD plus the working tree's change, at /tmp/h09b4b/s2/NAME
set -e
R=/home/bryan/projects/parallelscript; S=/tmp/h09b4b/s2/$1
git -C $R worktree add --detach $S HEAD >/dev/null 2>&1
for lib in ryu bdwgc libuv libbacktrace pcre2; do git -C $S submodule update --init --reference $R/.git/modules/pts/third_party/$lib pts/third_party/$lib >/dev/null 2>&1; done
git -C $R diff HEAD --binary > $S.patch
[ -s $S.patch ] && git -C $S apply $S.patch
(cd $R && git ls-files --others --exclude-standard -z | xargs -0 -r -I{} cp --parents {} $S/)
(cd $R && { git diff HEAD --name-only; git ls-files --others --exclude-standard; } | sort -u) > $S.files
bad=0; while read f; do cmp -s "$R/$f" "$S/$f" || { echo "DIFF $f"; bad=1; }; done < $S.files
echo "snapshot $1: byte-check bad=$bad files=$(wc -l < $S.files) head=$(git -C $S rev-parse --short HEAD)"
