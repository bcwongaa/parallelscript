#!/bin/bash
# rg.sh LABEL CLI PTS_HOME tests... : per test: exit, matches expect, matches node, first error
label=$1; cli=$2; home=$3; shift 3
work=/tmp/h09b4b/s2/rg-$label; mkdir -p $work
for t in "$@"; do
  name=$(basename $t .pts)
  sed -n '/^\/\/ expect:/,$p' $t | sed '1d; s#^// \{0,1\}##' > $work/$name.exp
  cp $t $work/$name.mts
  (cd $work && TZ=America/New_York ~/.local/node/bin/node --no-warnings --experimental-transform-types $name.mts > $name.node 2>$name.nodeerr)
  PTS_HOME=$home PTS_CACHE_DIR=/tmp/h09b4b/.cache-$label timeout 300 $cli run $t > $work/$name.out 2> $work/$name.err; rc=$?
  e=$(cmp -s $work/$name.out $work/$name.exp && echo expect-ok || echo expect-DIFF)
  n=$(cmp -s $work/$name.out $work/$name.node && echo node-ok || echo node-DIFF)
  ne=$(cmp -s $work/$name.node $work/$name.exp && echo node=expect || echo node!=expect)
  first=$(cat $work/$name.err $work/$name.out | grep -m1 -E "error|Error" | cut -c1-220)
  echo "$name exit=$rc $e $n $ne :: $first"
done
