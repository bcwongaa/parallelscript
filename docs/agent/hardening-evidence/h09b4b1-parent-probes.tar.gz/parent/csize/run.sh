#!/bin/bash
# emit-c of every run, errors, corpus and docs program with the base and final CLIs: status, bytes, md5 per program
out=/tmp/h09b4b/s2/csize/results.tsv; : > $out
cd /home/bryan/projects/parallelscript
for f in pts/tests/run/*.pts pts/tests/errors/*.pts pts/tests/corpus/*/*.pts docs/examples/*.pts; do
  line="$f"
  for side in base:/tmp/h09b4b/base final:/tmp/h09b4b/s2/snap6; do
    label=${side%%:*}; home=${side#*:}
    c=$(PTS_HOME=$home PTS_CACHE_DIR=/tmp/h09b4b/.cache-cs-$label timeout 120 $home/pts-bin/pts emit-c $f 2>/dev/null); rc=$?
    line="$line	$rc	${#c}	$(printf %s "$c" | md5sum | cut -c1-12)"
  done
  echo "$line" >> $out
done
echo done > /tmp/h09b4b/s2/csize/done
