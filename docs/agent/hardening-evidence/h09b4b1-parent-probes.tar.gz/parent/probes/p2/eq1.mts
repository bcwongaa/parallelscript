class P1 { p = 1; }
class P2 { q = 2; }
interface Holder { v: P1 | P2 | null; n: string | number; s: string | null }
const a = new P1();
function cmp(h: Holder, other: P1): string {
  if (h.v instanceof P1) {
    const same = h.v === other;
    const diff = h.v !== a;
    return "same " + same + " diff " + diff + " typeof " + typeof h.v;
  }
  return "no";
}
function nums(h: Holder): string {
  let count = 0;
  for (let i = 0; i < 1000; i++) {
    if (typeof h.n === "number") {
      if (h.n === 5) count++;
      if (h.n !== 6) count++;
    }
  }
  return "count " + count;
}
function strs(h: Holder): string {
  if (h.s !== null) {
    if (h.s === "x") return "x " + h.s.length;
    return "not x " + (h.s === "y");
  }
  return "null";
}
function els(h: Holder): string {
  if (typeof h["n"] === "string") {
    return "str " + (h["n"] === "q") + " " + typeof h["n"] + " " + h["n"].length;
  }
  return "num " + (h["n"] === 5);
}
const h: Holder = { v: a, n: 5, s: "x" };
console.log(cmp(h, a), cmp({ v: new P2(), n: 1, s: null }, a), nums(h), strs(h), strs({ v: null, n: "q", s: "y" }), els(h), els({ v: null, n: "q", s: null }));
class Node2 { next: Node2 | null = null; val: number | string = 1; }
function walk(n: Node2): string {
  let out = "";
  let cur: Node2 | null = n;
  while (cur !== null) {
    if (typeof cur.val === "number" && cur.val === 1) out += "one ";
    if (cur.next !== null && cur.next === cur.next) out += "self ";
    cur = cur.next;
  }
  return out;
}
const n1 = new Node2(); n1.next = new Node2(); n1.next.val = "s";
console.log(walk(n1));
