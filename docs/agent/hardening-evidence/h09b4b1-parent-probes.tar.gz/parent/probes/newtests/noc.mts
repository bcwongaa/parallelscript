// An optional chain that a test narrows to the undefined of its `?.` (`o?.v === undefined`,
// `o?.v == null`, a predicate's `v is number | undefined` for a string v, in plain code and
// in an instance of a generic function: H09b4a review round 1's s19b) holds either the
// property's value or undefined, and converts to its narrowed type with a check (C226), also
// where a type with undefined goes: an annotated const, an argument, an array element, a
// result (H09b4b1 review round 1's o06). Each was PTS1001 (`converting string to
// undefined`, `converting number | string to undefined`; the typed places, in the first
// version of the fix, `converting string | undefined to number | undefined`), though the
// branch runs when the object is undefined. (`optional_chains_narrowed_by_predicates.pts`
// has the predicates' other forms.)
function isNumOrUndefined(v: unknown): v is number | undefined {
  return v === undefined || typeof v === "number";
}
function show(n: number | undefined): string {
  return "show " + n;
}
function annotated(o: { v: string } | undefined): string {
  if (isNumOrUndefined(o?.v)) {
    const n: number | undefined = o?.v;
    const arr: (number | undefined)[] = [o?.v];
    return "annotated " + n + " " + show(o?.v) + " " + arr.length;
  }
  return "other";
}
function returned(o: { v: string } | undefined): number | undefined {
  if (isNumOrUndefined(o?.v)) {
    return o?.v;
  }
  return -1;
}
function generic<T>(o: { v: T } | undefined): number | undefined {
  if (isNumOrUndefined(o?.v)) {
    const n: number | undefined = o?.v;
    return n;
  }
  return -1;
}
console.log("typed", annotated(undefined), annotated({ v: "s" }), returned(undefined), returned({ v: "s" }), generic<string>(undefined), generic<string>({ v: "s" }), generic<number>({ v: 2 }));
function kinds(o: { v: string | number } | undefined): string {
  if (typeof o?.v === "number") {
    return "num " + (o?.v + 1);
  }
  if (o?.v === undefined) {
    return "undef " + o?.v;
  }
  return "str " + o?.v.length;
}
console.log("kinds", kinds(undefined), kinds({ v: 2 }), kinds({ v: "abc" }));
function nullish(o: { v: string | null } | undefined): string {
  if (o?.v == null) {
    const missing: null | undefined = o?.v;
    return "missing " + missing;
  }
  return "has " + o.v;
}
console.log("nullish", nullish(undefined), nullish({ v: null }), nullish({ v: "x" }));

// expect:
// typed annotated undefined show undefined 1 other undefined -1 undefined -1 2
// kinds undef undefined num 3 str 3
// nullish missing undefined missing null has x
