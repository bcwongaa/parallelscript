"""Run the H09b4 matrix: build and run each case with pts and with Node, classify, write JSON.

Run: python3 -I run.py CASES_JSON RESULTS_JSON [--jobs 2] [--pts PATH] [--filter REGEX]

Classes: OK, WRONG, TYPEERR, RANGEERR, PTS1001, PTS9001, TSERR, CRASH, TIMEOUT, BUILDFAIL, NODEFAIL.
"""

import argparse
import concurrent.futures
import json
import os
import re
import shutil
import subprocess

WT = os.environ.get("MX_PTS_HOME", "/home/bryan/projects/parallelscript")
HOME = os.path.expanduser("~")
ENV = dict(os.environ)
ENV.update({
    "PATH": "%s/.local/node/bin:%s/.local/go/bin:%s" % (HOME, HOME, os.environ.get("PATH", "")),
    "PTS_HOME": WT,
    "PTS_CACHE_DIR": os.environ.get("MX_CACHE", "/tmp/h09b4b/.cache-mx"),
    "TZ": "America/New_York",
    "GOMAXPROCS": "2",
})


def run(cmd, cwd, timeout):
    try:
        p = subprocess.run(cmd, cwd=cwd, env=ENV, capture_output=True, timeout=timeout)
        return p.returncode, p.stdout.decode(errors="replace"), p.stderr.decode(errors="replace"), False
    except subprocess.TimeoutExpired as e:
        return None, (e.stdout or b"").decode(errors="replace"), (e.stderr or b"").decode(errors="replace"), True


def first_error(text, code):
    for line in text.splitlines():
        if code in line:
            return re.sub(r"^.*?error %s: " % code, "", line).strip()[:200]
    return ""


def classify(case, pts_bin, workroot):
    src = case["file"]
    cid = case["id"]
    work = os.path.join(workroot, cid)
    os.makedirs(work, exist_ok=True)
    shutil.copy(src, os.path.join(work, cid + ".pts"))
    shutil.copy(src, os.path.join(work, cid + ".mts"))
    res = {"id": cid}
    nc, nout, nerr, nto = run(["node", "--no-warnings", "--experimental-transform-types", cid + ".mts"], work, 30)
    res.update(node_exit=nc, node_stdout=nout, node_stderr=nerr[-400:])
    bc, bout, berr, bto = run([pts_bin, "build", cid + ".pts", "-o", cid + ".bin"], work, 300)
    build = (bout + berr).replace(work + "/", "")
    res["build_exit"] = bc
    if bto:
        res.update(cls="TIMEOUT", detail="build timeout")
        return res
    if bc != 0:
        res["build_output"] = build[-1500:]
        if re.search(r"error TS\d+", build):
            res.update(cls="TSERR", detail=re.search(r"error TS\d+:.*", build).group(0)[:200])
        elif "PTS9001" in build:
            res.update(cls="PTS9001", detail=first_error(build, "PTS9001"))
        elif "PTS1001" in build:
            res.update(cls="PTS1001", detail=first_error(build, "PTS1001"))
        elif re.search(r"error PTS\d+", build):
            code = re.search(r"error (PTS\d+)", build).group(1)
            res.update(cls=code, detail=first_error(build, code))
        else:
            res.update(cls="BUILDFAIL", detail=build[-200:])
        return res
    pc, pout, perr, pto = run(["./" + cid + ".bin"], work, 30)
    os.remove(os.path.join(work, cid + ".bin"))  # ~3-4 MB each: matrices filled the disk once
    res.update(pts_exit=pc, pts_stdout=pout, pts_stderr=perr[-600:])
    if pto:
        res.update(cls="TIMEOUT", detail="run timeout")
    elif pout == nout and pc == nc:
        res.update(cls="OK", detail="")
        if nc != 0:
            res.update(cls="NODEFAIL", detail="both exit %s" % nc)
    elif pc is not None and (pc < 0 or pc >= 128):
        res.update(cls="CRASH", detail="exit %s: %s" % (pc, perr.strip().splitlines()[0][:200] if perr.strip() else ""))
    else:
        both = pout + perr
        if "TypeError" in both and "TypeError" not in nout:
            m = re.search(r"TypeError:? [^\n]*", both)
            res.update(cls="TYPEERR", detail=m.group(0)[:200] if m else "")
        elif "RangeError" in both and "RangeError" not in nout:
            m = re.search(r"RangeError:? [^\n]*", both)
            res.update(cls="RANGEERR", detail=m.group(0)[:120] if m else "")
        else:
            res.update(cls="WRONG", detail=("pts exit %s; " % pc) + (perr.strip().splitlines()[0][:200] if perr.strip() else ""))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cases")
    ap.add_argument("results")
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--pts", default=os.path.join(WT, "pts-bin/pts"))
    ap.add_argument("--filter", default="")
    ap.add_argument("--work", default="/tmp/h09b4b/repro/work/matrix")
    ap.add_argument("--merge", action="store_true", help="update RESULTS_JSON's entries for the filtered cases")
    a = ap.parse_args()
    with open(a.cases) as f:
        cases = json.load(f)
    if a.filter:
        cases = [c for c in cases if re.search(a.filter, c["id"])]
    results = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(a.jobs, 4)) as ex:
        futs = {ex.submit(classify, c, a.pts, a.work): c for c in cases}
        for fut in concurrent.futures.as_completed(futs):
            c = futs[fut]
            r = fut.result()
            r.update(family=c["family"], dims=c["dims"], note=c.get("note", ""))
            results[c["id"]] = r
    if a.merge and os.path.exists(a.results):
        with open(a.results) as f:
            old = {r["id"]: r for r in json.load(f)}
        with open(a.cases) as f:
            every = json.load(f)
        merged = {c["id"]: results.get(c["id"], old.get(c["id"])) for c in every}
        cases = [c for c in every if merged[c["id"]] is not None]
        results = merged
    ordered = [results[c["id"]] for c in cases]
    with open(a.results, "w") as f:
        json.dump(ordered, f, indent=1)
    counts = {}
    for r in ordered:
        counts[r["cls"]] = counts.get(r["cls"], 0) + 1
    print(len(ordered), counts)


if __name__ == "__main__":
    main()
