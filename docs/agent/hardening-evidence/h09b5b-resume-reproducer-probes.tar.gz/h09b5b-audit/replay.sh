#!/usr/bin/env bash
# Input to a replay tool, not a report. One heavy job at a time.
set -u
AUDIT=$(dirname -- "$(realpath -- "$0")")
ROOT=$(dirname -- "$(dirname -- "$AUDIT")")
OUT=${1:?Pass a new output directory under an isolated worktree}
CLI=${2:?Pass the checkpoint CLI}
HOME_DIR=${3:?Pass its PTS_HOME with initialized third-party runtime sources}
BASE_CLI=${4:-/tmp/h09b5b/base/pts-bin/pts}
BASE_HOME=${5:-/tmp/h09b5b/base}
mkdir -p -- "$OUT"
export GOMAXPROCS=1
python3 -I "$AUDIT/run_probe.py" --out "$OUT/runtime" \
  --compiler base "$BASE_CLI" "$BASE_HOME" \
  --compiler checkpoint "$CLI" "$HOME_DIR" \
  "$AUDIT/pairing_same_call_function.pts" \
  "$AUDIT/pairing_same_call_class_method.pts" \
  "$AUDIT/pairing_same_call_relaxed_cast.pts" \
  "$AUDIT/pairing_same_method_different_outer.pts" \
  "$AUDIT/shared_class_failure_stands.pts" \
  "$AUDIT/outer_cycle_method_instances.pts" \
  "$AUDIT/constant_key_trial_site_precedence.pts"
RUNTIME_STATUS=$?
printf 'runtime_harness_exit=%d\n' "$RUNTIME_STATUS"
go -C "$ROOT" build -p 1 -o "$OUT/levels" "$AUDIT/levels.go" || exit $?
"$OUT/levels" -must-fail "$AUDIT/shared_class_failure_stands.pts" || exit $?
"$OUT/levels" -must-fail -narrowed "$AUDIT/shared_class_failure_stands.pts" || exit $?
python3 -I "$AUDIT/make_identity_overlay.py" || exit $?
export AUDIT_IDENTITY_SOURCES="$AUDIT/pairing_same_call_function.pts:$AUDIT/pairing_same_call_class_method.pts:$AUDIT/pairing_same_call_relaxed_cast.pts"
export AUDIT_TARGET_SOURCE="$AUDIT/pairing_same_method_different_outer.pts"
go -C "$ROOT" test -p 1 -overlay "$AUDIT/identity-overlay.json" ./pts/lower \
  -run '^TestAudit(Demand|Target)IdentityAcrossRelowerings$' -count=1 -v -timeout 5m || exit $?
exit "$RUNTIME_STATUS"
