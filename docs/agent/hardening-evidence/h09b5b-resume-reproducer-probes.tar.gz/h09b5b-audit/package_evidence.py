#!/usr/bin/env python3
"""Package retained audit inputs and raw evidence, never executable binaries."""
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

AUDIT = Path(__file__).resolve().parent
ROOT = AUDIT.parents[1]
P = lambda name: str(AUDIT / name)
ledger = []


def command(argv, status, env=None, stdout=None, stderr=None):
    ledger.append({"command": argv, "cwd": str(ROOT), "returncode": status,
                   "environment_overrides": env or {}, "stdout": stdout, "stderr": stderr})


command(["gofmt", "-w", P("levels.go")], 0)
command(["go", "-C", str(ROOT), "build", "-p", "2", "-o", P("pts"), "./cmd/pts"], 0,
        {"GOMAXPROCS": "2"})
command(["go", "-C", str(ROOT), "build", "-p", "1", "-o", P("levels"), P("levels.go")], 0,
        {"GOMAXPROCS": "1"})
for narrowed in [False, True]:
    label = "guard-every-level-narrowed" if narrowed else "guard-every-level"
    argv = [P("levels"), "-must-fail"] + (["-narrowed"] if narrowed else [])
    command(argv + [P("shared_class_failure_stands.pts")], 0, {"GOMAXPROCS": "1"},
            P(label + ".stdout"), P(label + ".stderr"))

original_sources = [
    "pairing_same_call_function.pts", "pairing_same_call_class_method.pts",
    "pairing_same_call_relaxed_cast.pts", "shared_class_failure_stands.pts",
    "outer_cycle_method_instances.pts", "constant_key_trial_site_precedence.pts",
]
command(["python3", "-I", P("run_probe.py"), "--out", P("checkpoint-v-base"),
         "--compiler", "base", "/tmp/h09b5b/base/pts-bin/pts", "/tmp/h09b5b/base",
         "--compiler", "checkpoint", "/tmp/h09b5b/snap-f/pts-bin/pts", "/tmp/h09b5b/snap-f"]
        + [P(source) for source in original_sources], 1, {"GOMAXPROCS": "2"})
command(["python3", "-I", P("run_probe.py"), "--out", P("outer-target"),
         "--compiler", "base", "/tmp/h09b5b/base/pts-bin/pts", "/tmp/h09b5b/base",
         "--compiler", "checkpoint", P("pts"), str(ROOT),
         P("pairing_same_method_different_outer.pts")], 1, {"GOMAXPROCS": "1"},
        P("outer-target-run.stdout"), P("outer-target-run.stderr"))
command(["python3", "-I", P("run_probe.py"), "--out", P("own-cli"),
         "--compiler", "checkpoint", P("pts"), "/tmp/h09b5b/snap-f"]
        + [P(source) for source in original_sources[:3]]
        + [P("pairing_same_method_different_outer.pts")], 1, {"GOMAXPROCS": "1"},
        P("own-cli-run.stdout"), P("own-cli-run.stderr"))

for target in [False, True]:
    name = "TestAuditTargetIdentityAcrossRelowerings" if target else "TestAuditDemandIdentityAcrossRelowerings"
    label = "target-identity-trace" if target else "identity-trace"
    env = {"GOMAXPROCS": "1"}
    if target:
        env["AUDIT_TARGET_SOURCE"] = P("pairing_same_method_different_outer.pts")
    else:
        env["AUDIT_IDENTITY_SOURCES"] = ":".join(P(source) for source in original_sources[:3])
    command(["python3", "-I", P("make_identity_overlay.py")], 0)
    command(["gofmt", "-w", P("instances-observed.go"), P("identity_trace_test.go")], 0)
    command(["go", "-C", str(ROOT), "test", "-p", "1", "-overlay", P("identity-overlay.json"),
             "./pts/lower", "-run", "^" + name + "$", "-count=1", "-v", "-timeout", "5m"], 0,
            env, P(label + ".stdout"), P(label + ".stderr"))
(AUDIT / "extra-commands.json").write_text(json.dumps(ledger, indent=2) + "\n")

provenance = {
    "checkpoint": subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"], text=True).strip(),
    "working_tree": subprocess.check_output(["git", "-C", str(ROOT), "status", "--short"], text=True),
    "node_version": subprocess.check_output(["/home/bryan/.local/node/bin/node", "--version"], text=True).strip(),
    "cli_sha256": {},
}
for binary in [AUDIT / "pts", Path("/tmp/h09b5b/base/pts-bin/pts"), Path("/tmp/h09b5b/snap-f/pts-bin/pts")]:
    provenance["cli_sha256"][str(binary)] = hashlib.file_digest(binary.open("rb"), "sha256").hexdigest()
(AUDIT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")

included = []
for path in sorted(AUDIT.rglob("*")):
    if not path.is_file() or path.is_symlink():
        continue
    relative = path.relative_to(AUDIT)
    if "tmp" in relative.parts or "__pycache__" in relative.parts or path.suffix == ".bin":
        continue
    with path.open("rb") as source:
        magic = source.read(4)
    if magic == b"\x7fELF":
        continue
    included.append(path)
manifest = {str(path.relative_to(AUDIT)): hashlib.file_digest(path.open("rb"), "sha256").hexdigest()
            for path in included if path.name != "sha256.json"}
(AUDIT / "sha256.json").write_text(json.dumps(manifest, indent=2) + "\n")
if AUDIT / "sha256.json" not in included:
    included.append(AUDIT / "sha256.json")
archive = AUDIT.parent / "h09b5b-independent-audit.tar.gz"
with tarfile.open(archive, "w:gz") as output:
    for path in included:
        output.add(path, arcname=str(Path(AUDIT.name) / path.relative_to(AUDIT)), recursive=False)
print(json.dumps({"archive": str(archive), "files": len(included), "bytes": archive.stat().st_size,
                  "sha256": hashlib.file_digest(archive.open("rb"), "sha256").hexdigest()}))
