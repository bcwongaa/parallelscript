package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"

	"github.com/microsoft/typescript-go/pts/diagnostic"
	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/lower"
)

type result struct {
	Source      string `json:"source"`
	Level       int    `json:"level"`
	Narrowed    bool   `json:"narrowed"`
	CodeBytes   int    `json:"code_bytes"`
	Error       string `json:"error,omitempty"`
	CompileFail bool   `json:"compile_fail"`
	Internal    bool   `json:"internal"`
}

func checkSource(source, output string, narrowed, mustFail bool) bool {
	clean := true
	for _, level := range lower.Fallbacks {
		var code string
		var err error
		if narrowed {
			code, err = driver.EmitCNarrowedWith(context.Background(), source, level)
		} else {
			code, err = driver.EmitCWith(context.Background(), source, level)
		}
		var compileError *diagnostic.Error
		var internalError *diagnostic.InternalError
		record := result{
			Source: source, Level: int(level), Narrowed: narrowed, CodeBytes: len(code),
			CompileFail: errors.As(err, &compileError), Internal: errors.As(err, &internalError),
		}
		if err != nil {
			record.Error = err.Error()
		}
		if mustFail && (!record.CompileFail || record.Internal) {
			clean = false
		}
		if code != "" && output != "" {
			name := fmt.Sprintf("%s.level-%d.narrowed-%v.c", filepath.Base(source), level, narrowed)
			if err := os.WriteFile(filepath.Join(output, name), []byte(code), 0o644); err != nil {
				panic(err)
			}
		}
		if err := json.NewEncoder(os.Stdout).Encode(record); err != nil {
			panic(err)
		}
	}
	return clean
}

func main() {
	output := flag.String("out", "", "directory for successful levels' C")
	narrowed := flag.Bool("narrowed", false, "allow the level's selective narrowing")
	mustFail := flag.Bool("must-fail", false, "require a clean compile error at every level")
	flag.Parse()
	if *output != "" {
		if err := os.MkdirAll(*output, 0o755); err != nil {
			panic(err)
		}
	}
	clean := true
	for _, source := range flag.Args() {
		clean = checkSource(source, *output, *narrowed, *mustFail) && clean
	}
	if !clean {
		os.Exit(1)
	}
}
