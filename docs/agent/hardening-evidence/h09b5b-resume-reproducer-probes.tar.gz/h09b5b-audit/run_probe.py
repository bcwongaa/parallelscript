#!/usr/bin/env python3
"""Record a small H09b5b differential audit; delete each program binary after running it."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time


def record(command, environment, directory, stem):
    started = time.monotonic()
    completed = subprocess.run(
        command, cwd=directory, env=environment, capture_output=True, timeout=240
    )
    Path(str(stem) + ".stdout").write_bytes(completed.stdout)
    Path(str(stem) + ".stderr").write_bytes(completed.stderr)
    evidence = {
        "command": command,
        "cwd": str(directory),
        "returncode": completed.returncode,
        "seconds": round(time.monotonic() - started, 3),
        "stdout": str(stem) + ".stdout",
        "stderr": str(stem) + ".stderr",
    }
    with (stem.parent / "commands.jsonl").open("a") as output:
        output.write(json.dumps(evidence) + "\n")
    print(json.dumps(evidence), flush=True)
    return completed


def expected_output(source):
    after = source.split("// expect:\n", 1)
    if len(after) == 1:
        return None
    return "".join(line.removeprefix("// ") + "\n" for line in after[1].splitlines())


def check_node(source, oracle, args, environment, directory, output):
    twin = output / (source.stem + ".mts")
    twin.write_bytes(source.read_bytes())
    try:
        completed = record(
            [args.node, "--no-warnings", "--experimental-transform-types", str(twin)],
            environment, directory, output / (source.stem + ".node")
        )
    finally:
        twin.unlink(missing_ok=True)
    return completed.returncode == 0 and completed.stdout.decode() == oracle


def check_compiler(source, oracle, side, cli, home, environment, directory, output):
    environment = dict(environment, PTS_HOME=home)
    environment["AUDIT_CAPTURE_C"] = str(output / (source.stem + "." + side + ".emitted.c"))
    emitted = record([cli, "emit-c", str(source)], environment, directory,
                     output / (source.stem + "." + side + ".emit"))
    environment["AUDIT_CAPTURE_C"] = str(output / (source.stem + "." + side + ".built.c"))
    binary = output / (source.stem + "." + side + ".bin")
    try:
        built = record([cli, "build", str(source), "-o", str(binary)], environment,
                       directory, output / (source.stem + "." + side + ".build"))
        if oracle is None:
            clean_error = all(item.returncode == 1 and b"PTS1001" in item.stderr
                              and b"PTS9001" not in item.stderr for item in [emitted, built])
            return clean_error
        if built.returncode != 0 or emitted.returncode != 0:
            return False
        ran = record([str(binary)], environment, directory,
                     output / (source.stem + "." + side + ".run"))
        same_c = emitted.stdout == Path(environment["AUDIT_CAPTURE_C"]).read_bytes()
        matches = ran.returncode == 0 and ran.stdout.decode() == oracle
        print(json.dumps({"case": source.stem, "side": side,
                          "node_match": matches, "emit_build_same_c": same_c}), flush=True)
        return matches and same_c
    finally:
        binary.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--node", default="/home/bryan/.local/node/bin/node")
    parser.add_argument("--out", required=True)
    parser.add_argument("--compiler", action="append", nargs=3, default=[],
                        metavar=("SIDE", "CLI", "HOME"))
    parser.add_argument("sources", nargs="+")
    args = parser.parse_args()
    directory = Path(__file__).resolve().parents[2]
    output = Path(args.out).resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "tmp").mkdir(exist_ok=True)
    environment = dict(os.environ, TMPDIR=str(output / "tmp"), PTS_THREADS="1")
    if args.compiler:
        environment["PTS_CC"] = str(Path(__file__).with_name("record_cc.sh"))
    failed = []
    for path in args.sources:
        source = Path(path).resolve()
        oracle = expected_output(source.read_text())
        if oracle is not None and not check_node(source, oracle, args, environment, directory, output):
            failed.append(source.stem + ":node")
        for side, cli, home in args.compiler:
            clean = check_compiler(source, oracle, side, cli, home,
                                   environment, directory, output)
            if not clean:
                failed.append(source.stem + ":" + side)
    print(json.dumps({"failed": failed}), flush=True)
    return int(any(not case.endswith(":base") for case in failed))


if __name__ == "__main__":
    raise SystemExit(main())
