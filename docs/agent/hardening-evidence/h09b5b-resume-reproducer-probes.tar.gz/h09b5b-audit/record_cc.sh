#!/bin/sh
syntax=no
for arg in "$@"; do
  if [ "$arg" = -fsyntax-only ]; then syntax=yes; fi
done
for arg in "$@"; do
  case "$arg" in
    */main.c)
      if [ -n "${AUDIT_REJECT_MARKER:-}" ] && grep -Fq "$AUDIT_REJECT_MARKER" "$arg"; then
        printf '%s:1:1: error: rejected by independent H09b5b audit\n' "$arg" >&2
        exit 1
      fi
      if [ "$syntax" = no ] && [ -n "${AUDIT_LINK_FAIL_MARKER:-}" ] && grep -Fq "$AUDIT_LINK_FAIL_MARKER" "$arg"; then
        printf "/usr/bin/ld: undefined reference to \140pts_fn_audit_missing'\n" >&2
        exit 1
      fi
      if [ -n "${AUDIT_CAPTURE_C:-}" ]; then cp "$arg" "$AUDIT_CAPTURE_C" || exit; fi
      ;;
  esac
done
exec clang "$@"
