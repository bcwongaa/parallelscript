package lower

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/microsoft/typescript-go/internal/vfs/vfstest"
	"github.com/microsoft/typescript-go/pts/check"
	"github.com/microsoft/typescript-go/pts/frontend"
)

// TestAuditDemandIdentityAcrossRelowerings is a tests-only tracing experiment. The
// overlay adds an observer at demandAt, but does not change pairing or lowering.
func TestAuditDemandIdentityAcrossRelowerings(t *testing.T) {
	sources := strings.Split(os.Getenv("AUDIT_IDENTITY_SOURCES"), string(os.PathListSeparator))
	if len(sources) == 0 || sources[0] == "" {
		t.Fatal("AUDIT_IDENTITY_SOURCES is required")
	}
	for _, source := range sources {
		t.Run(filepath.Base(source), func(t *testing.T) {
			text, err := os.ReadFile(source)
			if err != nil {
				t.Fatal(err)
			}
			fs := vfstest.FromMap(map[string]string{"/p/main.pts": string(text)}, true)
			program, diagnostics := frontend.Load(t.Context(), fs, "/p/main.pts")
			if len(diagnostics) != 0 {
				t.Fatalf("load: %v", diagnostics)
			}
			info, diagnostics := check.Program(t.Context(), program)
			if len(diagnostics) != 0 {
				t.Fatalf("check: %v", diagnostics)
			}
			identities := map[string]string{}
			checkers := map[string]bool{}
			wants := map[string]map[string]bool{}
			callVariants := map[int]map[string]bool{}
			for _, level := range Fallbacks {
				var initial []auditDemandRecord
				var narrowing *Narrowing
				for pass := 0; pass < 4; pass++ {
					auditDemands = nil
					_, reports, next := ProgramWith(t.Context(), program, info, level, narrowing)
					records := append([]auditDemandRecord(nil), auditDemands...)
					if pass == 0 {
						initial = records
					} else if pass == 1 {
						if !reflect.DeepEqual(auditStableRecords(initial), auditStableRecords(records)) {
							t.Fatalf("same level %d changed identities on repeat", level)
						}
					}
					for _, record := range records {
						semantic := fmt.Sprintf("%d|%s", record.Pos, record.Types)
						if previous, exists := identities[semantic]; exists && previous != record.Key {
							t.Fatalf("identity changed for %s: %s -> %s", semantic, previous, record.Key)
						}
						identities[semantic] = record.Key
						checkers[record.Checker] = true
						if wants[semantic] == nil {
							wants[semantic] = map[string]bool{}
						}
						wants[semantic][record.Want] = true
						if callVariants[record.Pos] == nil {
							callVariants[record.Pos] = map[string]bool{}
						}
						callVariants[record.Pos][record.Key] = true
						encoded, err := json.Marshal(record)
						if err != nil {
							t.Fatal(err)
						}
						t.Logf("level=%d pass=%d narrowing=%d demand=%s", level, pass, narrowing.Len(), encoded)
					}
					t.Logf("level=%d pass=%d reports=%d next=%d", level, pass, len(reports), next.Len())
					if pass > 0 {
						if next.Len() == 0 || next.Len() == narrowing.Len() {
							break
						}
						narrowing = next
					}
				}
			}
			if len(checkers) != 1 {
				t.Fatalf("checker count across relowerings = %d, want 1", len(checkers))
			}
			var multipleAtOneCall, freshIR bool
			for _, keys := range callVariants {
				multipleAtOneCall = multipleAtOneCall || len(keys) > 1
			}
			for _, pointers := range wants {
				freshIR = freshIR || len(pointers) > 1
			}
			if !multipleAtOneCall || !freshIR {
				t.Fatalf("expected distinct instantiated keys at one call and fresh IR pointers: distinct=%v fresh=%v", multipleAtOneCall, freshIR)
			}
			t.Logf("checked %d semantic demand identities; checker reused; instantiated IDs stable; fresh IR observed", len(identities))
		})
	}
}

// TestAuditTargetIdentityAcrossRelowerings observes two target owners of the
// same declaration and the same demand, then repeats and selectively narrows.
func TestAuditTargetIdentityAcrossRelowerings(t *testing.T) {
	source := os.Getenv("AUDIT_TARGET_SOURCE")
	text, err := os.ReadFile(source)
	if err != nil {
		t.Fatal(err)
	}
	fs := vfstest.FromMap(map[string]string{"/p/main.pts": string(text)}, true)
	program, diagnostics := frontend.Load(t.Context(), fs, "/p/main.pts")
	if len(diagnostics) != 0 {
		t.Fatalf("load: %v", diagnostics)
	}
	info, diagnostics := check.Program(t.Context(), program)
	if len(diagnostics) != 0 {
		t.Fatalf("check: %v", diagnostics)
	}
	var narrowing *Narrowing
	identities := map[string]string{}
	pointers := map[string]map[string]bool{}
	for pass := 0; pass < 3; pass++ {
		auditTargets = nil
		_, reports, next := ProgramWith(t.Context(), program, info, AllInstances, narrowing)
		keys := map[string]bool{}
		wants := map[string]bool{}
		declarations := map[int]bool{}
		for _, record := range auditTargets {
			if previous, exists := identities[record.OuterTypes]; exists && previous != record.OuterKey {
				t.Fatalf("outer identity changed for %s: %s -> %s", record.OuterTypes, previous, record.OuterKey)
			}
			identities[record.OuterTypes] = record.OuterKey
			keys[record.OuterKey] = true
			wants[record.Want] = true
			declarations[record.Declaration] = true
			if pointers[record.OuterKey] == nil {
				pointers[record.OuterKey] = map[string]bool{}
			}
			pointers[record.OuterKey][record.OuterPointer] = true
			encoded, err := json.Marshal(record)
			if err != nil {
				t.Fatal(err)
			}
			t.Logf("pass=%d narrowing=%d target=%s", pass, narrowing.Len(), encoded)
		}
		if len(keys) < 2 || len(wants) != 1 || len(declarations) != 1 {
			t.Fatalf("want distinct owners for one declaration and one demand: keys=%d wants=%d declarations=%d", len(keys), len(wants), len(declarations))
		}
		t.Logf("pass=%d reports=%d next=%d", pass, len(reports), next.Len())
		if pass == 1 {
			if next.Len() == 0 {
				t.Fatal("expected selective narrowing")
			}
			narrowing = next
		}
	}
	for key, seen := range pointers {
		if len(seen) < 2 {
			t.Fatalf("expected fresh outer substitutions for key %s", key)
		}
	}
}

func auditStableRecords(records []auditDemandRecord) []string {
	stable := make([]string, len(records))
	for i, record := range records {
		stable[i] = fmt.Sprintf("%d|%s|%s", record.Pos, record.Key, record.Types)
	}
	return stable
}
