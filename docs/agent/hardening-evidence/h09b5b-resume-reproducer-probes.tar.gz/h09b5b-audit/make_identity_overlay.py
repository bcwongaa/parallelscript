#!/usr/bin/env python3
"""Make an observation-only Go overlay; leave production files unchanged."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
output = Path(__file__).resolve().parent
source = root / "pts/lower/instances.go"
text = source.read_text()
old = '\treturn d\n}\n\n// siteDemandAt'
new = '\tauditRecordDemand(l, d)\n\treturn d\n}\n\n// siteDemandAt'
assert text.count(old) == 1
text = text.replace(old, new)
old_target = '\tp := pairingOf(d, g.node, DeclaredInstances)\n'
assert text.count(old_target) == 1
text = text.replace(old_target, old_target + '\tauditRecordTarget(l, d, g)\n')
text += r'''

// Audit-only observer. It neither changes pairing identities nor filters trials.
type auditDemandRecord struct {
    Pos int `json:"pos"`
    Key string `json:"key"`
    Types string `json:"types"`
    Checker string `json:"checker"`
    Want string `json:"want"`
    Signature string `json:"signature"`
    Subst string `json:"subst"`
}

var auditDemands []auditDemandRecord

func auditRecordDemand(l *lowerer, d *demand) {
    var key, types strings.Builder
    part := func(t *checker.Type) {
        t = l.instantiate(t)
        fmt.Fprintf(&key, ",%d", t.Id())
        fmt.Fprintf(&types, ",%s", l.checker.TypeToString(t))
    }
    for _, t := range l.checker.PtsTypeArgumentsOfSignature(d.signature) {
        part(t)
    }
    key.WriteString("|")
    types.WriteString("|")
    for _, p := range d.signature.Parameters() {
        part(l.checker.GetTypeOfSymbol(p))
    }
    key.WriteString("|")
    types.WriteString("|")
    part(l.checker.GetReturnTypeOfSignature(d.signature))
    fmt.Fprintf(&key, "|rest=%v,min=%d,chain=%v", d.signature.HasRestParameter(), d.signature.MinArgumentCount(), d.chained)
    auditDemands = append(auditDemands, auditDemandRecord{
        Pos: d.node.Pos(), Key: key.String(), Types: types.String(),
        Checker: fmt.Sprintf("%p", l.checker), Want: fmt.Sprintf("%p", d.want),
        Signature: fmt.Sprintf("%p", d.signature), Subst: fmt.Sprintf("%p", d.subst),
    })
}

type auditTargetRecord struct {
    Pos int `json:"pos"`
    Declaration int `json:"declaration"`
    OuterKey string `json:"outer_key"`
    OuterTypes string `json:"outer_types"`
    OuterPointer string `json:"outer_pointer"`
    Want string `json:"want"`
}

var auditTargets []auditTargetRecord

func auditRecordTarget(l *lowerer, d *demand, g *genericFunc) {
    var key, types strings.Builder
    if outer := g.outer; outer != nil {
        for i, p := range outer.parameters {
            fmt.Fprintf(&key, ",%d=%d", p.Id(), outer.arguments[i].Id())
            fmt.Fprintf(&types, ",%s=%s", l.checker.TypeToString(p), l.checker.TypeToString(outer.arguments[i]))
        }
        key.WriteString("|erased")
        for _, p := range outer.erased {
            fmt.Fprintf(&key, ",%d", p.Id())
        }
    }
    auditTargets = append(auditTargets, auditTargetRecord{
        Pos: d.node.Pos(), Declaration: g.node.Pos(), OuterKey: key.String(), OuterTypes: types.String(),
        OuterPointer: fmt.Sprintf("%p", g.outer), Want: fmt.Sprintf("%p", d.want),
    })
}
'''
replacement = output / "instances-observed.go"
replacement.write_text(text)
(output / "identity-overlay.json").write_text(json.dumps({"Replace": {
    str(source): str(replacement),
    str(root / "pts/lower/zz_audit_identity_test.go"): str(output / "identity_trace_test.go"),
}}, indent=2) + "\n")
