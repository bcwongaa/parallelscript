# Speculative-pairing regression generator: a local generic arrow with body B is used only
# through `any` (so the base's erased copy runs it), while a declaration is passed to a
# function whose typed calls demand instances for types D. The snapshot pairs the arrow
# with every demand; the program must behave as on the base.
import sys, os
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
prelude = '''class Box<T> {
  constructor(public value: T) {}
}
class Cell<T> {
  constructor(public value: T) {}
  show(): string {
    const v = this.value;
    if (typeof v === "number") {
      return "n" + (v + 1);
    }
    return "o" + String(v);
  }
}
class Item {
  tag = 1;
}
interface Tagged {
  tag: number;
  label?: string;
}
class Labelled extends Item {
  label = 5;
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
'''
bodies = {
 "typeof_branch": 'if (typeof x === "number") { console.log("num", x + 1); }',
 "typeof_ternary": 'const y = typeof x === "string" ? x.length : 0; console.log("len", y);',
 "isarray": 'if (Array.isArray(x)) { console.log("arr", x.length); }',
 "instanceof": 'if (x instanceof Item) { console.log("item", x.tag); }',
 "in_op": 'if (typeof x === "object" && x !== null && "tag" in x) { console.log("has tag"); }',
 "switch_typeof": 'switch (typeof x) { case "string": console.log("s", x.length); break; case "number": console.log("n", x + 1); break; }',
 "cell_class": 'console.log(new Cell(x).show());',
 "relaxed": 'if (x instanceof Item) { const t: Tagged = x; console.log(t.tag); }',
 "template": 'console.log(`t ${x}`);',
 "json": 'console.log(JSON.stringify(x));',
 "nullish": 'console.log(x ?? "none", x == null);',
 "spread_array": 'const xs = [x, x]; console.log(xs.length);',
 "map_set": 'const m = new Map<string, T>([["k", x]]); console.log(m.size);',
 "closure_inside": 'const again = () => x; console.log(typeof again());',
 "inner_generic": 'const wrap = <U>(u: U): Box<U> => new Box(u); console.log(typeof wrap(x).value);',
 "optional_chain": 'const o = x as unknown as { tag?: number } | undefined; console.log(o?.tag);',
 "string_methods": 'if (typeof x === "string") { console.log(x.toUpperCase()); }',
 "number_methods": 'if (typeof x === "number") { console.log(x.toFixed(1)); }',
 "array_methods": 'if (Array.isArray(x)) { console.log(x.map((e) => e).length); }',
 "object_keys": 'if (typeof x === "object" && x !== null) { console.log(Object.keys(x).length); }',
}
demands = {
 "number": ("1", "number"),
 "string": ('"s"', "string"),
 "item": ("new Item()", "Item"),
 "array": ("[1, 2]", "number[]"),
 "union": ('(Math.random() > 2 ? 1 : "u") as number | string', "number | string"),
 "nullable": ("null as Item | null", "Item | null"),
 "tuple": ('[1, "a"] as [number, string]', "[number, string]"),
}
idx = []
for bname, body in bodies.items():
    for dname, (expr, ty) in demands.items():
        src = prelude
        src += "function use(f: <T>(x: T) => Box<T>): void {\n"
        src += f"  const b: Box<{ty}> = f({expr});\n  console.log(\"demand\", typeof b.value);\n}}\n"
        src += "function main(): void {\n"
        src += f"  const local = <T>(x: T): Box<T> => {{\n    {body}\n    return new Box(x);\n  }};\n"
        src += "  const d: any = local;\n"
        src += f"  console.log(\"via any\", typeof d({expr}).value);\n"
        src += "  use(make);\n}\nmain();\n"
        name = f"{bname}__{dname}.pts"
        open(os.path.join(out, name), "w").write(src)
        idx.append(name)
print(len(idx))
