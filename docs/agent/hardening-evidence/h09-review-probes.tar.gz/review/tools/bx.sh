#!/bin/bash
# bx.sh CLI file.pts: base vs CLI (PTS_HOME snap3) outputs
cli=$1; f=$(realpath "$2"); d=$(mktemp -d /tmp/h09/review/run.XXXX)
bo=$(cd "$d" && PTS_HOME=/tmp/h09/base timeout 180 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
so=$(cd "$d" && PTS_HOME=/tmp/h09/snap3 timeout 180 $cli run "$f" 2>&1; echo "[exit $?]")
rm -rf "$d"
be=$(echo "$bo" | tail -1); se=$(echo "$so" | tail -1)
if [ "$bo" == "$so" ]; then echo "SAME $be $(basename $f)"; else echo "DIFF base$be x$se $(basename $f)"; fi
