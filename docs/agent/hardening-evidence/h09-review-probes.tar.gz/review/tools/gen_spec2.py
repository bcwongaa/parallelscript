# Speculative pairing, part 2: narrowed branches that declare locals (cascading failures),
# real demands (the arrow passed to the typed caller), and arrows in other places.
import sys, os
out = sys.argv[1]
os.makedirs(out, exist_ok=True)
prelude = '''class Box<T> {
  constructor(public value: T) {}
}
class Item {
  tag = 1;
}
function make<T>(x: T): Box<T> {
  return new Box(x);
}
function attempt(label: string, f: () => string): void {
  try {
    console.log(label, f());
  } catch (error: any) {
    console.log(label, error.name, error.message);
  }
}
'''
bodies = {
 "isarray_decl": 'if (Array.isArray(x)) { const n = x.length; console.log("arr", n); }',
 "typeof_string_decl": 'if (typeof x === "string") { const u = x.toUpperCase(); console.log("str", u); }',
 "typeof_number_decl": 'if (typeof x === "number") { const n = x * 2; console.log("num", n); }',
 "typeof_object_decl": 'if (typeof x === "object" && x !== null) { const k = Object.keys(x); console.log("obj", k.length); }',
 "instanceof_decl": 'if (x instanceof Item) { const t = x.tag; console.log("item", t); }',
 "ternary_len": 'const y = typeof x === "string" ? x.length : -1; console.log("len", y);',
 "early_return": 'if (typeof x === "string") { const s = x.trim(); console.log(s); return new Box(x); }',
 "while_narrow": 'let n = 0; while (typeof x === "number" && n < 1) { const m = x + n; console.log("m", m); n++; }',
 "and_narrow": 'const ok = typeof x === "string" && x.startsWith("a"); console.log("ok", ok);',
}
demands = {
 "number": ("1", "number"),
 "string": ('"ab"', "string"),
 "item": ("new Item()", "Item"),
 "array": ("[1, 2]", "number[]"),
}
places = ["local", "passed"]
n = 0
for bname, body in bodies.items():
    for dname, (expr, ty) in demands.items():
        for place in places:
            src = prelude
            src += "function use(label: string, f: <T>(x: T) => Box<T>): void {\n"
            src += f"  attempt(label, () => {{\n    const b: Box<{ty}> = f({expr});\n    return typeof b.value;\n  }});\n}}\n"
            src += "function main(): void {\n"
            src += f"  const local = <T>(x: T): Box<T> => {{\n    {body}\n    return new Box(x);\n  }};\n"
            src += "  const d: any = local;\n"
            for e2, _ in demands.values():
                src += f"  console.log(\"via any\", typeof d({e2}).value);\n"
            src += "  use(\"make\", make);\n"
            if place == "passed":
                src += "  use(\"local\", local);\n"
            src += "}\nmain();\n"
            open(os.path.join(out, f"{bname}__{dname}__{place}.pts"), "w").write(src)
            n += 1
print(n)
