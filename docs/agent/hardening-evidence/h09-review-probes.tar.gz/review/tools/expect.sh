#!/bin/bash
# expect.sh HOME file.pts...: compare `pts run` stdout with the file's // expect: block
home=$1; shift
for f0 in "$@"; do f=$(realpath "$f0")
  exp=$(awk '/^\/\/ expect:/{p=1; next} p && /^\/\/ ?/{sub(/^\/\/ ?/, ""); print; next} p{exit}' "$f")
  d=$(mktemp -d /tmp/h09/review/run.XXXX)
  out=$(cd "$d" && PTS_HOME=$home timeout 180 $home/pts-bin/pts run "$f" 2>/dev/null)
  rm -rf "$d"
  if [ "$out" == "$exp" ]; then echo "PASS $(basename $f)"; else echo "FAIL $(basename $f)"; diff <(echo "$exp") <(echo "$out") | head -20; fi
done
