# Compile-time probe: many ordinary locals (filler functions) and many recorded generic
# arrows, each paired with D demands: the scope snapshot clones l.locals per arrow and
# again per instance.
import sys
fillers, locals_, arrows, types, out = map(str, sys.argv[1:6]) if False else sys.argv[1:6]
fillers, locals_, arrows, types = int(fillers), int(locals_), int(arrows), int(types)
L = ["class Box<T> {", "  constructor(public value: T) {}", "}"]
for j in range(types):
    L += [f"class C{j} {{", f"  tag = {j};", "}"]
for i in range(fillers):
    L.append(f"function filler{i}(seed: number): number {{")
    L.append(f"  let acc = seed;")
    for k in range(locals_):
        L.append(f"  const v{k} = acc + {k};")
        L.append(f"  acc = v{k} % 7;")
    L.append("  return acc;")
    L.append("}")
L.append("let total = 0;")
L.append("function use(f: <T>(x: T) => Box<T>): void {")
for j in range(types):
    L.append(f"  const b{j}: Box<C{j}> = f(new C{j}());")
    L.append(f"  total += b{j}.value.tag;")
L.append("}")
L.append("function main(): void {")
for i in range(arrows):
    L.append(f"  use(<T>(x: T): Box<T> => new Box(x));")
L.append("}")
L.append("main();")
for i in range(fillers):
    L.append(f"total += filler{i}({i});")
L.append("console.log(total);")
open(out, "w").write("\n".join(L) + "\n")
