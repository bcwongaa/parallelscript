import sys
n, m, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
lines = ["class Box<T> {", "  constructor(public value: T) {}", "}"]
for j in range(m):
    lines += [f"class C{j} {{", f"  tag = {j};", "}"]
lines.append("let total = 0;")
lines.append("function use(f: <T>(x: T) => Box<T>): void {")
for j in range(m):
    lines.append(f"  const b{j}: Box<C{j}> = f(new C{j}());")
    lines.append(f"  total += b{j}.value.tag;")
lines.append("}")
lines.append("function main(): void {")
for i in range(n):
    lines.append(f"  const a{i} = <T>(x: T): Box<T> => new Box(x);")
    lines.append(f"  const r{i}: Box<number> = a{i}({i});")
    lines.append(f"  total += r{i}.value;")
lines.append("  use(a0);")
lines.append("}")
lines.append("main();")
lines.append("console.log(total);")
open(out, "w").write("\n".join(lines) + "\n")
