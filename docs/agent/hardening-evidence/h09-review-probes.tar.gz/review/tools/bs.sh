#!/bin/bash
# bs.sh file.pts: base vs snap3 outputs; prints SAME/DIFF line, saves outputs next to the file on DIFF
f=$(realpath "$1"); d=$(mktemp -d /tmp/h09/review/run.XXXX)
bo=$(cd "$d" && PTS_HOME=/tmp/h09/base timeout 180 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
so=$(cd "$d" && PTS_HOME=/tmp/h09/snap3 timeout 180 /tmp/h09/snap3/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
rm -rf "$d"
be=$(echo "$bo" | tail -1); se=$(echo "$so" | tail -1)
if [ "$bo" == "$so" ]; then echo "SAME $be $(basename $f)"; else echo "DIFF base$be snap$se $(basename $f)"; echo "$bo" > "$f.base.out"; echo "$so" > "$f.snap.out"; fi
