#!/bin/bash
# csize.sh file: emit C with base and snap3, print "lines_base lines_snap exit_base exit_snap file"
f=$1; d=$(mktemp -d /tmp/h09/review/csize/x.XXXX)
cd "$d"
PTS_HOME=/tmp/h09/base timeout 120 /tmp/h09/base/pts-bin/pts emit-c "$f" -o b.c >b.err 2>&1; eb=$?
PTS_HOME=/tmp/h09/snap3 timeout 120 /tmp/h09/snap3/pts-bin/pts emit-c "$f" -o s.c >s.err 2>&1; es=$?
lb=$( [ -f b.c ] && wc -l < b.c || echo 0); ls=$( [ -f s.c ] && wc -l < s.c || echo 0)
echo "$lb $ls $eb $es $f"
if [ "$eb" != "$es" ]; then echo "--- $f"; cat b.err; echo "+++"; cat s.err; fi >> /tmp/h09/review/csize/exitdiff.txt
cd /; rm -rf "$d"
