#!/bin/bash
# tri.sh file.pts...: run each with base CLI, snap3 CLI, Node; print a status line and outputs on differences.
node=$HOME/.local/node/bin/node
for f0 in "$@"; do f=$(realpath "$f0"); b=$(basename "$f" .pts); d=$(mktemp -d /tmp/h09/review/run.XXXX)
  cp "$f" "$d/$b.mts"
  bo=$(cd "$d" && PTS_HOME=/tmp/h09/base timeout 180 /tmp/h09/base/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  so=$(cd "$d" && PTS_HOME=/tmp/h09/snap3 timeout 180 /tmp/h09/snap3/pts-bin/pts run "$f" 2>&1; echo "[exit $?]")
  no=$(cd "$d" && timeout 60 "$node" --no-warnings --experimental-transform-types "$b.mts" 2>&1; echo "[exit $?]")
  bs=$([ "$bo" == "$no" ] && echo B=node || echo B!=node); ss=$([ "$so" == "$no" ] && echo S=node || echo S!=node); bss=$([ "$bo" == "$so" ] && echo B=S || echo B!=S)
  echo "== $b: $bs $ss $bss"
  if [ "${QUIET:-}" != 1 ] || [ "$bo" != "$so" ]; then
    if [ "$bo" == "$so" ]; then echo "-- base=snap"; echo "$bo"; else echo "-- base"; echo "$bo"; echo "-- snap"; echo "$so"; fi
    [ "$so" != "$no" ] && { echo "-- node"; echo "$no"; }
  fi
  rm -rf "$d"
done
