#!/bin/bash
# How often does the new test's client logic (20 x: 100 pipelined /big?100000, 20 ms, reset) fail to kill snapshot 1's server?
D=/tmp/h33b/review2/srv
GOMAXPROCS=4 /tmp/h33b/snap1/pts-bin/pts build $D/probe_server.pts -o $D/rr.snap1 >/dev/null || exit 1
for mode in plain tls; do
  P=0; [ $mode = plain ] && P=1
  survived=0
  for run in $(seq 1 ${RUNS:-10}); do
    PLAIN=$P CERT_FILE=/tmp/h33b/review2/certs/ec.pem KEY_FILE=/tmp/h33b/review2/certs/ec-key.pem PTS_THREADS=1 $D/rr.snap1 > $D/rr.out 2> $D/rr.err &
    pid=$!
    for i in $(seq 1 100); do grep -q '^port' $D/rr.out 2>/dev/null && break; sleep 0.05; done
    out=$(/tmp/h33b/review1/sigpipe/sigpipe 127.0.0.1:$(awk '/^port/{print $2}' $D/rr.out) $mode)
    if kill -0 $pid 2>/dev/null; then survived=$((survived+1)); kill $pid; fi
    wait $pid 2>/dev/null
  done
  echo "$mode: snapshot 1's server survived the test's 20 resets in $survived of ${RUNS:-10} runs"
done
rm -f $D/rr.snap1
