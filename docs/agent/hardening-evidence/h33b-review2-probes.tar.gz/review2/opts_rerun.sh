#!/bin/bash
# Round 1's option probes, on both snapshots, from a copy of round 1's opts directory.
D=/tmp/h33b/review2/opts1
rm -rf $D; mkdir -p $D; cd /tmp/h33b/review1/opts
cp cert.pem key.pem combined.pem junky.pem rsa.pem chain-*.pem opts.pts leak2.pts partial.pts $D/
cd $D
cp cert.pem unreadable.pem; chmod 000 unreadable.pem
ln -s cert.pem link.pem; ln -s nowhere.pem dangling.pem; ln -s loop2.pem loop1.pem; ln -s loop1.pem loop2.pem
head -c 5000000 /dev/urandom > huge.bin
for v in snap1 snap2; do
  for p in opts partial leak2; do GOMAXPROCS=4 /tmp/h33b/$v/pts-bin/pts build $p.pts -o $p.$v >/dev/null || exit 1; done
  timeout 60 ./opts.$v > opts.$v.txt 2>&1; timeout 60 ./partial.$v > partial.$v.txt 2>&1
  PTS_THREADS=4 ROUNDS=3000 timeout 300 ./leak2.$v > leak2.$v.txt 2>&1
done
echo "opts identical across snapshots: $(cmp -s opts.snap1.txt opts.snap2.txt && echo yes || echo NO)"; diff opts.snap1.txt opts.snap2.txt | head
echo "partial identical: $(cmp -s partial.snap1.txt partial.snap2.txt && echo yes || echo NO)"; cat partial.snap2.txt
echo "leak2 on snapshot 2 (PTS_THREADS=4, 3000 rounds each):"; cat leak2.snap2.txt
chmod 600 unreadable.pem; rm -f huge.bin *.snap1 *.snap2
