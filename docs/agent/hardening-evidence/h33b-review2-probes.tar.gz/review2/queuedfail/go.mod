module queuedfail

go 1.26
