// Asks for 6 MB, then sends a garbage record (or close_notify) at once, then reads slowly: how much of the answer arrives?
package main

import (
	"crypto/tls"
	"fmt"
	"net"
	"os"
	"strings"
	"time"
)

func main() {
	for _, kind := range []string{"garbage", "close_notify"} {
		tcp, _ := net.Dial("tcp", os.Args[1])
		tcp.(*net.TCPConn).SetReadBuffer(32 * 1024)
		c := tls.Client(tcp, &tls.Config{InsecureSkipVerify: true, MaxVersion: tls.VersionTLS13})
		c.Handshake()
		c.Write([]byte("GET /big?" + os.Args[2] + " HTTP/1.1\r\nHost: a\r\n\r\n"))
		time.Sleep(100 * time.Millisecond)
		if kind == "garbage" {
			tcp.Write([]byte("\x17\x03\x03\x00\x20" + strings.Repeat("g", 32)))
		} else {
			c.CloseWrite()
		}
		c.SetReadDeadline(time.Now().Add(30 * time.Second))
		total := 0
		buf := make([]byte, 16*1024)
		var err error
		for {
			var n int
			n, err = c.Read(buf)
			total += n
			if err != nil {
				break
			}
			time.Sleep(200 * time.Microsecond)
		}
		fmt.Printf("%-13s: read %d bytes (%d), then %v\n", kind, total, 0, err)
		tcp.Close()
	}
}
