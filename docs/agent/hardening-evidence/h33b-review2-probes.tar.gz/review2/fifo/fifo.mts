import { writeFileSync, appendFileSync, promises } from "node:fs";
const path = process.env.FIFO ?? "f";
const big = "z".repeat(1 << 20);
function show(e: unknown): string {
  const error = e as NodeJS.ErrnoException;
  return `${error.name}: ${error.message} | ${error.code} ${error.errno} ${error.syscall} ${error.path}`;
}
const how = process.env.HOW ?? "sync";
try {
  if (how === "sync") writeFileSync(path, big);
  else if (how === "append") appendFileSync(path, big);
  else await promises.writeFile(path, big);
  console.log(how, "wrote");
} catch (e) {
  console.log(how, "threw", show(e));
}
console.log("still running");
