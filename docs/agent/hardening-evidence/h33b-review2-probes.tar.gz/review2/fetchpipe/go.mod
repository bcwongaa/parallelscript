module fetchpipe

go 1.26
