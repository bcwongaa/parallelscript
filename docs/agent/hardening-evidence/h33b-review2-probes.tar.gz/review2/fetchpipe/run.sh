#!/bin/bash
D=/tmp/h33b/review2/fetchpipe
cd $D
GOMAXPROCS=2 go build -o resetter . || exit 1
GOMAXPROCS=4 /tmp/h33b/snap2/pts-bin/pts build fetchpipe.pts -o fp.snap2 >/dev/null || exit 1
./resetter > port.txt &
rpid=$!
for i in $(seq 1 50); do [ -s port.txt ] && break; sleep 0.1; done
PORT=$(cat port.txt) ./fp.snap2; echo "exit $?"
kill $rpid; rm -f fp.snap2
