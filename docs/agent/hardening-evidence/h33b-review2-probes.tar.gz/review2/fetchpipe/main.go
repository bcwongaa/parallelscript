// A server that reads a little of each request and resets the connection.
package main

import (
	"fmt"
	"net"
)

func main() {
	l, _ := net.Listen("tcp", "127.0.0.1:0")
	fmt.Println(l.Addr().(*net.TCPAddr).Port)
	for {
		c, err := l.Accept()
		if err != nil {
			return
		}
		go func() {
			buf := make([]byte, 1024)
			c.Read(buf)
			c.(*net.TCPConn).SetLinger(0)
			c.Close()
		}()
	}
}
