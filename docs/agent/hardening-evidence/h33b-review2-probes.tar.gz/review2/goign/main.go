package main

import "fmt"

func main() {
	for i := 0; i < 300000; i++ {
		fmt.Println("line", i)
	}
}
