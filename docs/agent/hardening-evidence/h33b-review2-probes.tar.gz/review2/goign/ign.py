import os, signal, subprocess, sys
def run(cmd, restore):
    r, w = os.pipe()
    p = subprocess.Popen(cmd, stdout=w, stderr=subprocess.PIPE, restore_signals=restore)
    os.close(w)
    with os.fdopen(r, "rb") as f:
        f.readline()
    err = p.stderr.read()
    s = p.wait()
    return ("killed by " + signal.Signals(-s).name if s < 0 else "exit %d" % s) + (" stderr=%r" % err[:60] if err else "")
for name, cmd in [("go", ["./goprint"]), ("yes (coreutils)", ["yes"]), ("python", [sys.executable, "-I", "-c", "import sys\nfor i in range(300000): print('line', i)"]), ("pts snap1", ["../out/p_log.snap1"]), ("pts snap2", ["../out/p_log.snap2"])]:
    env_cmd = cmd
    print("%-16s default SIGPIPE: %-40s inherited SIG_IGN: %s" % (name, run(env_cmd, True), run(env_cmd, False)))
