import os, signal, subprocess
node = os.path.expanduser("~/.local/node/bin/node")
for name, src in [("console.log", "for (let i = 0; i < 300000; i++) console.log('line', i); console.error('finished');"),
                  ("process.stdout.write", "for (let i = 0; i < 300000; i++) process.stdout.write('w ' + i + '\\n'); console.error('finished');")]:
    r, w = os.pipe()
    p = subprocess.Popen([node, "-e", src], stdout=w, stderr=subprocess.PIPE)
    os.close(w)
    with os.fdopen(r, "rb") as f:
        f.readline()
    err = p.stderr.read().decode()
    s = p.wait()
    print("%-22s %s; stderr: %s" % (name, "killed by " + signal.Signals(-s).name if s < 0 else "exit %d" % s, err.strip().splitlines()[:2]))
