module goign

go 1.26
