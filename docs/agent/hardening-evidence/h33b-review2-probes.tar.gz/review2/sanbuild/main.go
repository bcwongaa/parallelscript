// Review tool: builds a .pts program with the snapshot's sanitized runtime (as buildSanitized does).
package main

import (
	"context"
	"fmt"
	"os"
	"path/filepath"

	"github.com/microsoft/typescript-go/pts/driver"
	"github.com/microsoft/typescript-go/pts/toolchain"
)

func main() {
	if len(os.Args) != 4 {
		fmt.Fprintln(os.Stderr, "usage: sanbuild asan|tsan <file.pts> <exe>")
		os.Exit(2)
	}
	ctx := context.Background()
	source, _ := filepath.Abs(os.Args[2])
	c, err := driver.EmitC(ctx, source)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	tc, err := toolchain.New()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	profile := toolchain.Sanitize
	if os.Args[1] == "tsan" {
		profile = toolchain.ThreadSanitize
	}
	rt, err := tc.Runtime(ctx, profile)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	dir, _ := os.MkdirTemp("", "sanbuild")
	defer os.RemoveAll(dir)
	cFile := filepath.Join(dir, "main.c")
	if err := os.WriteFile(cFile, []byte(c), 0o644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := tc.CompileProgram(ctx, rt, []string{cFile}, os.Args[3]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
