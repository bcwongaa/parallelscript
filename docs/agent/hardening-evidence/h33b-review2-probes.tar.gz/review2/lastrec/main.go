// After a good handshake and request, the client sends something that ends the session (garbage records, or
// close_notify followed by junk) with lots of input left unread, then reports the records it gets and how TCP ends.
package main

import (
	"bufio"
	"crypto/tls"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"syscall"
	"time"
)

func main() {
	addr := os.Args[1]
	for _, kind := range []string{"garbage-1k", "garbage-200k", "notify-then-junk-200k", "notify-alone"} {
		for _, v := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
			tcp, _ := net.Dial("tcp", addr)
			c := tls.Client(tcp, &tls.Config{InsecureSkipVerify: true, MinVersion: v, MaxVersion: v})
			c.SetDeadline(time.Now().Add(5 * time.Second))
			c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\n\r\n"))
			br := bufio.NewReader(c)
			resp, err := http.ReadResponse(br, nil)
			if err != nil {
				fmt.Println(kind, err)
				continue
			}
			io.ReadAll(resp.Body)
			switch kind {
			case "garbage-1k":
				tcp.Write([]byte("\x17\x03\x03\x04\x00" + strings.Repeat("g", 1024)))
			case "garbage-200k":
				for i := 0; i < 13; i++ {
					tcp.Write([]byte("\x17\x03\x03\x3f\xf0" + strings.Repeat("g", 0x3ff0)))
				}
			case "notify-then-junk-200k":
				c.CloseWrite()
				tcp.Write([]byte(strings.Repeat("j", 200000)))
			case "notify-alone":
				c.CloseWrite()
			}
			time.Sleep(200 * time.Millisecond)
			raw := make([]byte, 0, 4096)
			buf := make([]byte, 4096)
			var end error
			for {
				n, err := tcp.Read(buf) // what the server sent after, as raw records
				raw = append(raw, buf[:n]...)
				if err != nil {
					end = err
					break
				}
			}
			ending := "FIN"
			if errors.Is(end, syscall.ECONNRESET) {
				ending = "RST"
			} else if end != io.EOF {
				ending = end.Error()
			}
			types := []byte{}
			for p := raw; len(p) >= 5; {
				l := int(p[3])<<8 | int(p[4])
				types = append(types, p[0])
				if len(p) < 5+l {
					break
				}
				p = p[5+l:]
			}
			fmt.Printf("%-22s %s: server sent records %v (%d bytes), then %s\n", kind, tls.VersionName(v), types, len(raw), ending)
			tcp.Close()
		}
	}
}
