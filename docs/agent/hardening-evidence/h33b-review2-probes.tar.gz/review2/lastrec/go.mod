module lastrec

go 1.26
