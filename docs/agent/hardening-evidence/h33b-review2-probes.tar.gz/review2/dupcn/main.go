// Sends "Connection: close" request and close_notify back to back, then reads the raw records the server sends.
package main

import (
	"crypto/tls"
	"fmt"
	"net"
	"os"
	"time"
)

type tap struct {
	net.Conn
	raw []byte
}

func (t *tap) Read(p []byte) (int, error) {
	n, err := t.Conn.Read(p)
	t.raw = append(t.raw, p[:n]...)
	return n, err
}

func main() {
	for _, v := range []uint16{tls.VersionTLS12, tls.VersionTLS13} {
		tcp, _ := net.Dial("tcp", os.Args[1])
		tp := &tap{Conn: tcp}
		c := tls.Client(tp, &tls.Config{InsecureSkipVerify: true, MinVersion: v, MaxVersion: v})
		c.Handshake()
		start := len(tp.raw)
		c.Write([]byte("GET /hello HTTP/1.1\r\nHost: a\r\nConnection: close\r\n\r\n"))
		c.CloseWrite()
		time.Sleep(300 * time.Millisecond)
		buf := make([]byte, 65536)
		tcp.SetReadDeadline(time.Now().Add(3 * time.Second))
		for {
			n, err := tcp.Read(buf)
			tp.raw = append(tp.raw, buf[:n]...)
			if err != nil {
				break
			}
		}
		types := []string{}
		for p := tp.raw[start:]; len(p) >= 5; {
			l := int(p[3])<<8 | int(p[4])
			types = append(types, fmt.Sprintf("%d(%d)", p[0], l))
			if len(p) < 5+l {
				break
			}
			p = p[5+l:]
		}
		fmt.Println(tls.VersionName(v), "records after the request:", types)
		tcp.Close()
	}
}
