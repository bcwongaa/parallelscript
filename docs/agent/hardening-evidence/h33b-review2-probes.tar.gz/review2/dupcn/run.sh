#!/bin/bash
D=/tmp/h33b/review2
for v in snap1 snap2; do
  GOMAXPROCS=4 /tmp/h33b/$v/pts-bin/pts build $D/srv/probe_server.pts -o $D/dupcn/s.$v >/dev/null
  CERT_FILE=$D/certs/ec.pem KEY_FILE=$D/certs/ec-key.pem PTS_THREADS=1 $D/dupcn/s.$v > $D/dupcn/s.out 2> $D/dupcn/s.err &
  pid=$!
  for i in $(seq 1 50); do grep -q '^port' $D/dupcn/s.out 2>/dev/null && break; sleep 0.1; done
  echo "== $v"; $D/dupcn/dupcn 127.0.0.1:$(awk '/^port/{print $2}' $D/dupcn/s.out)
  kill $pid; wait $pid 2>/dev/null; rm -f $D/dupcn/s.$v
done
