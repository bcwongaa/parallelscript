module dupcn

go 1.26
