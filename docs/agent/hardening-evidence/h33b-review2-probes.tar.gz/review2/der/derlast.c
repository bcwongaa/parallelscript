/* Prints the length and last byte of the DER mbedTLS writes for a key (PEM or DER file, optional passphrase),
 * then parses that DER back the way http.c's other loops do and checks the pair against the original. */
#include <mbedtls/pk.h>
#include <mbedtls/psa_util.h>
#include <psa/crypto.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {
  psa_crypto_init();
  FILE *f = fopen(argv[1], "rb");
  static unsigned char buf[65536];
  size_t n = fread(buf, 1, sizeof buf - 1, f);
  fclose(f);
  buf[n++] = 0;
  const char *pw = argc > 2 ? argv[2] : NULL;
  mbedtls_pk_context key, again;
  mbedtls_pk_init(&key), mbedtls_pk_init(&again);
  int r = mbedtls_pk_parse_key(&key, buf, n, (const unsigned char *)pw, pw ? strlen(pw) : 0, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE);
  if (r != 0) { printf("parse -0x%04X\n", -r); return 1; }
  static unsigned char der[16384];
  int w = mbedtls_pk_write_key_der(&key, der, sizeof der);
  if (w <= 0) { printf("write -0x%04X\n", -w); return 1; }
  unsigned char *start = der + sizeof der - w;
  r = mbedtls_pk_parse_key(&again, start, w, NULL, 0, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE);
  int pair = r == 0 ? mbedtls_pk_check_pair(&key, &again, mbedtls_psa_get_random, MBEDTLS_PSA_RANDOM_STATE) : r;
  printf("der %d bytes, last 0x%02x, reparse %s, pair %s\n", w, start[w - 1], r == 0 ? "ok" : "FAIL", pair == 0 ? "ok" : "FAIL");
  return 0;
}
