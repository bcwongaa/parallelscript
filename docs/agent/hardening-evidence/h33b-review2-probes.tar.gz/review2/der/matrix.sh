#!/bin/bash
# For each key and form: serve on 1 loop and on 8 loops (reusePort), make fresh TLS connections, report ok/bad.
cd /tmp/h33b/review2/der
for k in ${KEYS:-p256 p256-zero p384 p384-zero p521 p521-zero rsa2048-zero rsa3072 rsa4096 rsa8192}; do
  for form in pem trad.pem enc8.pem legacy.pem; do
    pw=""; [ $form = enc8.pem -o $form = legacy.pem ] && pw=pw
    line="$k $form:"
    for mode in "1 0" "8 1"; do
      set -- $mode
      CERT_FILE=$k.crt KEY_FILE=$k.$form PASSPHRASE=$pw PTS_THREADS=$1 REUSE=$2 taskset -c ${CPUS:-0,1} ./keyserver.bin > ks.out 2> ks.err &
      pid=$!
      for i in $(seq 1 200); do grep -q '^port\|^refused' ks.out 2>/dev/null && break; sleep 0.05; done
      if grep -q '^refused' ks.out; then line="$line [$1 loops: $(cat ks.out)]"; wait $pid; continue; fi
      port=$(awk '/^port/{print $2}' ks.out)
      res=$(GOMAXPROCS=2 taskset -c ${CPUS:-0,1} /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca ../certs/ca.pem -workers 8 -d ${DUR:-1500ms} -modes fresh | head -1)
      curl -s -m 5 --cacert ../certs/ca.pem https://localhost:$port/stop -o /dev/null
      for i in $(seq 1 100); do kill -0 $pid 2>/dev/null || break; sleep 0.05; done
      kill -0 $pid 2>/dev/null && { kill $pid; res="$res HANG"; }
      wait $pid; st=$?
      line="$line [$1 loops: $res exit $st stderr $(wc -c < ks.err)]"
    done
    echo "$line"
  done
done
