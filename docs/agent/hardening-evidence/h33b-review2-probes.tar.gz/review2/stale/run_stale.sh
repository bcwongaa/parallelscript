#!/bin/bash
# usage: run_stale.sh /dev/full|pipe 0|1 : logserver with stdout there, under resetting clients; reports its exit status
out=$1; plain=$2; D=/tmp/h33b/review2/stale
flag=""; s=https; [ $plain = 1 ] && { flag=-plain; s=http; }
rm -f $D/ls.err $D/ls.status
if [ $out = pipe ]; then
  ( PLAIN=$plain CERT_FILE=$D/../certs/ec.pem KEY_FILE=$D/../certs/ec-key.pem PTS_THREADS=${THREADS:-1} $D/logserver.bin 2> $D/ls.err; echo $? > $D/ls.status ) | cat > /dev/null &
else
  ( PLAIN=$plain CERT_FILE=$D/../certs/ec.pem KEY_FILE=$D/../certs/ec-key.pem PTS_THREADS=${THREADS:-1} $D/logserver.bin > $out 2> $D/ls.err; echo $? > $D/ls.status ) &
fi
for i in $(seq 1 100); do grep -q '^port' $D/ls.err 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2}' $D/ls.err)
res=$(GOMAXPROCS=2 taskset -c ${CPUS:-0,1} /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca $D/../certs/ca.pem $flag -workers 8 -d ${DUR:-5s} -modes pipeline-reset,bigread-reset,fresh | head -1)
curl -s -m 5 -k $s://127.0.0.1:$port/stop -o /dev/null
for i in $(seq 1 100); do [ -s $D/ls.status ] && break; sleep 0.05; done
st=$(cat $D/ls.status 2>/dev/null)
echo "stdout=$out plain=$plain: $res; server status ${st:-STILL RUNNING} $( [ -n "$st" ] && [ "$st" -gt 128 ] && kill -l $((st-128)) ); stderr lines $(wc -l < $D/ls.err)"
