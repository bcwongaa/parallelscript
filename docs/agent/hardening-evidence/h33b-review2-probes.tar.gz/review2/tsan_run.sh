#!/bin/bash
D=/tmp/h33b/review2/srv
sed 's/^    count++;$/    \/\/ count++ removed for TSan/' $D/probe_server.pts > $D/probe_server_nocount.pts
grep -c "count++;" $D/probe_server_nocount.pts
GOMAXPROCS=4 PTS_HOME=/tmp/h33b/snap2 /tmp/h33b/review2/sanbuild/sanbuild tsan $D/probe_server_nocount.pts $D/probe_server.tsan || exit 1
GC_DONT_GC=1 TSAN_OPTIONS="halt_on_error=0 report_signal_unsafe=0" CERT_FILE=/tmp/h33b/review2/der/rsa2048-zero.crt KEY_FILE=/tmp/h33b/review2/der/rsa2048-zero.pem PTS_THREADS=4 REUSE=1 taskset -c 0-3 $D/probe_server.tsan > $D/ts.out 2> $D/ts.err &
pid=$!
for i in $(seq 1 200); do grep -q '^port' $D/ts.out 2>/dev/null && break; sleep 0.1; done
port=$(awk '/^port/{print $2}' $D/ts.out)
echo "port $port"
GOMAXPROCS=4 taskset -c 0-3 /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca /tmp/h33b/review2/certs/ca.pem -workers 16 -d 15s -modes fresh,keepalive,pipeline,pipeline-reset,closewrite-hold,closewrite-after-request,hold-reset,handshake-mid,garbage,split,badreq,tls-then-garbage | head -1
curl -s -m 5 --cacert /tmp/h33b/review2/certs/ca.pem "https://localhost:$port/stopother?true"; echo
for i in $(seq 1 100); do kill -0 $pid 2>/dev/null || break; sleep 0.1; done
kill -0 $pid 2>/dev/null && { echo HANG; kill -9 $pid; }
wait $pid; echo "exit $?"
echo "TSan reports: $(grep -c 'WARNING: ThreadSanitizer' $D/ts.err)"
grep -A 8 "WARNING: ThreadSanitizer" $D/ts.err | head -40
