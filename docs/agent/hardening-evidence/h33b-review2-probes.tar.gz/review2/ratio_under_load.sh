#!/bin/bash
# Runs TestHTTPSServerDecryptsItsKeyOnce five times while an RSA HTTPS server on four loops takes fresh and keep-alive clients (bounded to 70 s).
D=/tmp/h33b/review2/srv
CERT_FILE=/tmp/h33b/review2/certs/rsa.pem KEY_FILE=/tmp/h33b/review2/certs/rsa-key.pem PTS_THREADS=4 REUSE=1 taskset -c 0-3 $D/probe_server.bin > $D/ld.out 2> $D/ld.err &
spid=$!
for i in $(seq 1 100); do grep -q '^port' $D/ld.out 2>/dev/null && break; sleep 0.05; done
port=$(awk '/^port/{print $2}' $D/ld.out)
GOMAXPROCS=4 taskset -c 0-3 /tmp/h33b/review1/stress/stress -addr 127.0.0.1:$port -ca /tmp/h33b/review2/certs/ca.pem -workers 32 -d 70s -modes fresh,keepalive > $D/ld.stress 2>&1 &
lpid=$!
sleep 3
cd /tmp/h33b/snap2 && GOMAXPROCS=4 timeout 600 taskset -c 0-3 go test -count=5 -p 1 -timeout 10m -v -run 'TestHTTPSServerDecryptsItsKeyOnce' ./pts/tests/ 2>&1 | grep -E "times as long|^--- |^ok|FAIL"
wait $lpid
echo "load: $(head -1 $D/ld.stress)"
kill $spid; wait $spid 2>/dev/null
